"""Data Domain 46 - Managed Portfolios & Rebalancing (wealth-manager reference model; new domain, CW-009).
Content module for taxonomy_builder.py."""

META = {
 "title": "Managed Portfolios & Rebalancing Data Taxonomy",
 "subtitle": "Business domain 46 - Managed Portfolios & Rebalancing | Wealth manager (direct) | Scope: US | Draft v0.1 | 2026-10-14",
 "output": "46_Managed_Portfolios_and_Rebalancing/Managed_Portfolios_and_Rebalancing_Data_Taxonomy.xlsx",
 "overview": [
  ("Purpose", "A reference taxonomy for the managed account operations of a US wealth manager that runs discretionary advisory programs for individual clients: digital advice, hybrid and human-advised managed accounts, workplace participant managed accounts and, optionally, fiduciary accounts of its trust company. Each managed account is a 15 brokerage or participant account, held in the 49 brokerage book of record and managed to an 01 model portfolio whose weights 24 maintains, but with its own targets, restrictions, tax situation, cash flows and household context. The domain masters which model each account follows, how the account deviates from it, when it drifts and is rebalanced, the tax-loss-harvesting, wash-sale and asset location decisions taken for it, and the trade proposals and cash instructions handed to 48, 16 and 50. It is stitched together from Investment Company Act Rule 3a-4 and its adopting release, Form ADV (Part 1A Item 5.F and Part 2A Appendix 1), Advisers Act section 206(3), Rules 206(3)-2, 206(4)-7 and 204-2, the Internal Revenue Code sections 1091, 1222 and 6045 with Treas. Reg. 1.1091-1 and 1.1012-1, IRS Publication 550 and Rev. Rul. 2008-5, the SEC staff guidance and examination observations on robo-advisers and wrap fee programs, the GIPS standards, and public documentation of rebalancing platforms as a cross-check. Use it as a starting point for a rebalancer and tax-overlay data model, a managed account operations data store, Rule 3a-4 evidence design or a business glossary."),
  ("Scope", "In scope: model assignments per managed account (with sleeves for multi-sleeve accounts), household managed groups and each assignment's tax management setting, including the tax-loss-harvesting election; managed account targets, account target override lines and account investment constraints (Rule 3a-4 reasonable restrictions and trust investment terms as implemented); rebalance trigger rules, drift assessments and their lines, account rebalance events and model change implementations; account tax budgets, tax-loss harvest decisions, substantially identical security groups, wash sale control windows and asset location decisions; trade proposal batches, trade proposals, proposed client lot selections and trade proposal exceptions, up to release; managed account cash instructions; managed account composites and their membership. Out of scope (referenced by ID): the model portfolio and the program offered (01 MDL-, OFFR-); model weights over time and fund or institutional rebalancing (24 TGT-, RBAL-); accounts, program enrollments and standing instructions (15 ACC-, ENRL-, SIN-); households, client restrictions and investor profiles (02 PTY-HH-, CRX-, INPR-); recommendations (45 RECOM-); fee debits (47 FDBT-); client orders and executions (48); participant investment transfers (16); Client Holdings, Client Tax Lots, cash balances and client account activity (49); money movements (50); trust term provisions (51); returns (32); instruments (17); the rebalancing engine as a model (37); employees (20); surveillance of managed accounts (08)."),
  ("Structure", "Four levels: Data Domain > Data Family > Data Business Object > Data Business Attribute. The Hierarchy tab shows the first three levels with definitions; the Taxonomy tab lists every attribute with its definition, data type, code list, example and reference standard."),
  ("Core model", "Model Assignment (MASGN-) hangs from a 15 Program Enrollment (ENRL-) and names the 01 Model Portfolio (MDL-) the account follows for a period, how discretion is exercised and how its assets count in regulatory AUM; Sleeve Assignment names the sleeve models and managers of a multi-sleeve account, which share the account target; Tax Management Setting (attribute group) holds the harvest election and tax parameters. Household Managed Group places accounts of one 02 household (PTY-HH-) under joint asset location and wash-sale control. Managed Account Target versions the 24 Target Allocation Set (TGT-) applied plus Account Target Override Lines; Account Investment Constraint implements a 02 Client Restriction (CRX-) or a 51 trust term. Rebalance Trigger Rule says when an account is assessed and rebalanced; Drift Assessment (DRFT-) and its lines compare actual weights (Derived copies of 49) with the target. Account Rebalance Event (ARBE-) records the decision; Model Change Implementation phases a 24 target change across accounts. Account Tax Budget, Tax-Loss Harvest Decision (TLH-), Substantially Identical Security Group, Wash Sale Control Window and Asset Location Decision hold account-level tax management (CW-048). Trade Proposal Batch (TPBAT-) groups Trade Proposals (TRPR-), each with Proposed Client Lot Selections over 49 Client Tax Lots and Trade Proposal Exceptions; a released proposal becomes a 48 Client Order or, for a participant managed account, a 16 Participant Investment Transfer that 16 nets into the plan-level 29 Fund Order. Managed Account Cash Instruction (CSHI-) raises or invests cash for a 15 standing instruction or RMD, or for the 50 money movement or 47 fee debit that references it. Managed Account Composite (MACP-) and its membership group client accounts for 32 returns and the advisory slice of Firm AUM."),
  ("Design principles", "1) The model is 01, its weights are 24, the account's deviation is 46 (CW-009, CW-047): a Managed Account Target holds only the 24 target set version applied and the account's overrides, never re-mastered model weights. 2) Account grain: every business object carries the account, the model assignment or a program or model key; Rule 3a-4 individualized management is why the record is kept per account and separate from 24. 3) No holdings, no lots, no returns (CW-007, CW-011): actual weights, market values, realized gains and cash are Derived copies of 49 with an as-of timestamp; lots are always 'Client Tax Lot' (49), never 18 Tax Lot (LOT-); returns are 32. 4) Proposal, not order (CW-010, CW-049): a Trade Proposal ends at release and holds only the released order reference; routing, execution, allocation and confirmation are 48. 5) Restrictions are referenced, not re-coded: a constraint names its 02 Client Restriction or 51 trust term and says how it is implemented. 6) Effective-date assignments, sleeves, group memberships, targets, overrides, constraints, rules, security groups, asset location decisions and composite memberships. 7) Personal data: every object states its PII tier; the account-level records are 'PII - financial'; rules, model changes, security groups, batches and composites hold no personal data. 8) Flag Critical Data Elements (CDE)."),
  ("Applies To", "Shows the record each attribute belongs to: Model Assignment, Sleeve Assignment, Household Managed Group, Tax Management Setting, Managed Account Target, Account Target Override Line, Account Investment Constraint, Rebalance Trigger Rule, Drift Assessment, Drift Assessment Line, Account Rebalance Event, Model Change Implementation, Account Tax Budget, Tax-Loss Harvest Decision, Substantially Identical Security Group, Wash Sale Control Window, Asset Location Decision, Trade Proposal Batch, Trade Proposal, Proposed Client Lot Selection, Trade Proposal Exception, Managed Account Cash Instruction, Managed Account Composite or Managed Account Composite Membership."),
  ("CDE", "Y = proposed Critical Data Element: needed to know which model and target an account follows and with what discretion, to count regulatory and firm AUM, to evidence individualized management and reasonable restrictions under Rule 3a-4, to decide and evidence a rebalance or harvest, to control wash sales across a household, to hand a correct proposal to 48 or 16, or to build composite membership. Confirm with data owners."),
  ("Primary / Secondary Reference", "Standard or source the attribute definition is aligned to. 'Internal' = firm-defined; there is no authoritative external definition. Vendor rebalancing platforms (Envestnet, Orion, Vestmark, Aladdin Wealth) are cross-checks of structure only, not a license to reproduce their schemas. Next step: map each attribute to the rebalancer, tax overlay and order management fields and to the rule paragraph it evidences."),
  ("Notes", "PII = personal data under the GLBA, Regulation S-P and US state privacy laws. Each object's PII tier is stated in the Notes of its first attribute: 'PII - financial' or 'No PII'. Tax figures, account weights and trade quantities of an individual's account are personal financial data. No special-category data is held here."),
  ("Tabs", "Hierarchy: families, object groups and objects with definitions and live counts | Taxonomy: full attribute list (filterable) | Code Lists: starter controlled vocabularies | Relationships: object-level cardinalities, including references to other Data Domains | Sources: standards used, owners, licenses and links."),
  ("Suggested next steps", "1) Validate families, objects and CDEs with Managed Account Operations, the digital advice platform team, the investment team that maintains models (24), Tax, Advisory Compliance and Data Management. 2) Agree with 15 that Program Enrollment is the only key a Model Assignment hangs from, and with 02 how Client Restrictions flow into Account Investment Constraints. 3) Agree with 49 (W3) the Client Tax Lot (CTLOT-), Client Holding (CLHLD-) and Account Cash Balance contracts, and the as-of contract of the Derived copies. 4) Agree with 48 (W3) the release contract (Trade Proposal to Client Order) and with 16 the participant investment transfer route. 5) Agree with 24 the W3 re-cut of Tax Budget, Proposed Trade and Proposed Lot Selection to 18 portfolios only. 6) Agree with 32 how Managed Account Composite Membership feeds Client Account Performance. 7) Map attributes to the rebalancing engine, the tax overlay, the order management system and the managed account data store. 8) Turn the Relationships tab into a logical data model."),
 ],
}

T = []

def D(name, code, definition, subs):
    T.append((name, code, definition, subs))

# ---------------------------------------------------------------------------
D("Model Assignment", "MA-ASG",
  "Which model portfolio each managed account follows, for which period and with what discretion (CW-009, CW-047): the model assignment hung from the 15 program enrollment, the sleeves of a multi-sleeve account, the household groups whose accounts are managed together for asset location and wash-sale control, and the tax management setting of each assignment. The model is 01, the enrollment 15 and the household 02; they are referenced, never copied.",
  [
   ("Model Assignment", "The assignment of a managed account to a model portfolio for a period (Rule 3a-4 individualized management). One account has at most one active assignment; a model change on the account ends one assignment and starts the next.", [
     ("Model Assignment", [
       ("Model Assignment ID", "Unique identifier of the assignment of one account to one model for one period.", "Model Assignment", "Identifier", "", "MASGN-000418822", "Internal", "ICA Rule 3a-4", "Y", "Object PII tier: PII - financial. PII."),
       ("Assigned Account", "Managed account the assignment applies to (mastered in 15).", "Model Assignment", "Reference (Account)", "", "ACC-0049812", "ICA Rule 3a-4", "", "Y", "PII. Row rule: equals the Enrolled Account of the Assignment Program Enrollment (15); kept as the account key of the assignment."),
       ("Assignment Program Enrollment", "15 program enrollment under which the account is managed; the program offered and the discretionary authority the client granted are read from it (CW-031).", "Model Assignment", "Reference (Program Enrollment, 15)", "", "ENRL-2025-0004418", "SEC Form ADV", "", "Y", "PII. The program is not repeated here: it is the enrollment's Enrolled Service Offering (01 OFFR-)."),
       ("Assigned Model Portfolio", "Model portfolio (01) the account is managed to during the assignment.", "Model Assignment", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "ICA Rule 3a-4", "Y", "PII (linked to an individual's account)."),
       ("Source Recommendation", "Recommendation (45) that proposed this model or a change to it, where the assignment followed advice; blank for an assignment made by the program's rules.", "Model Assignment", "Reference (Recommendation, 45)", "", "RECOM-2025-0018342", "SEC Reg BI", "Advisers Act fiduciary interpretation", "", "PII. The rationale and best-interest evidence stay in 45 (CW-042)."),
       ("Assignment Reason", "Why the account was assigned to this model at this time.", "Model Assignment", "Code", "Assignment Reason", "Risk Profile Change", "Internal", "", "", "PII."),
       ("Discretion Exercised", "How the program exercises the discretionary authority granted on the 15 enrollment for this account: full discretion, discretion limited to rebalancing within the model, or no discretion (each trade approved by the client).", "Model Assignment", "Code", "Account Discretion Type", "Full Discretion", "SEC Form ADV", "ICA Rule 3a-4", "Y", "PII. Full or limited discretion requires Program Enrollment.Discretionary Authority Indicator = Y (15)."),
       ("Regulatory AUM Classification", "How the account's assets count in the adviser's regulatory assets under management on Form ADV Part 1A Item 5.F: discretionary, non-discretionary, or not counted because the account does not receive continuous and regular supervisory or management services.", "Model Assignment", "Code", "Regulatory AUM Classification", "Discretionary", "SEC Form ADV", "", "Y", "PII. The advisory slice of Firm AUM reads this classification; values come from 49 (CW-011)."),
       ("Assignment Status", "Lifecycle status of the assignment: Proposed while awaiting client acceptance or funding, Active while the account is managed to the model, Paused while management is suspended (for example during an account transfer), Inactive once ended.", "Model Assignment", "Code", "Record Status", "Active", "Internal", "", "Y", "PII. Usable Record Status values: Proposed, Active, Paused, Inactive (Draft, Pending, Deprecated and Retired are not used for assignments)."),
       ("Assignment Effective From", "Date from which the account is managed to the model.", "Model Assignment", "Date", "ISO 8601", "2025-11-10", "Internal", "", "Y", "PII."),
       ("Assignment Effective To", "Date the account stopped being managed to the model (model change, program termination, account closure).", "Model Assignment", "Date", "ISO 8601", "", "Internal", "", "Y", "PII."),
       ("Previous Model Assignment", "Assignment this one replaced on the same account, which gives the model change history of the account.", "Model Assignment", "Reference (Model Assignment, 46)", "", "MASGN-000301144", "Internal", "", "", "PII."),
       ("Assignment Approved By", "Advisor or managed account operations employee who approved the assignment, where the program requires a human approval (human and hybrid advice, custom models).", "Model Assignment", "Reference (Employee)", "", "EMP-30412", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
     ]),
     ("Tax Management Setting", [
       ("Tax-Loss Harvesting Elected", "Whether the client elected tax-loss harvesting for the account under this assignment; the program must offer it as a 01 Offering Feature (Tax-Loss Harvesting).", "Tax Management Setting", "Boolean", "", "Y", "Internal", "IRC Section 1091", "Y", "Object PII tier: PII - financial. PII. Held here, not on the 15 enrollment (CW-032; 15 brief SME question 7). The setting is an attribute group without history: earlier values of the election are kept in the record audit trail (21) and the disclosure is a 13 communication (lever: make the setting an effective-dated object)."),
       ("Minimum Harvest Loss Amount", "Smallest unrealized loss on a security, in USD, that the harvest scan acts on for this account.", "Tax Management Setting", "Amount", "", "USD 250", "Internal", "Vestmark", "", "PII."),
       ("Minimum Harvest Loss Percentage", "Smallest unrealized loss, as a share of the lots' cost basis, that the harvest scan acts on.", "Tax Management Setting", "Percentage", "", "5.00%", "Internal", "Vestmark", "", "PII."),
       ("Short-Term Gain Avoidance Indicator", "Whether rebalancing sales avoid realizing net short-term capital gains unless the drift exceeds the hard tolerance.", "Tax Management Setting", "Boolean", "", "Y", "IRC Section 1222", "", "", "PII."),
       ("Asset Location Enabled Indicator", "Whether the account takes part in household asset location through a Household Managed Group.", "Tax Management Setting", "Boolean", "", "Y", "Internal", "", "", "PII."),
       ("Managed Sale Lot Selection Method", "Method the program uses to choose the lots each managed sale relieves; the lots are named to the broker at the time of sale. The account's default cost basis method stays the 15 Cost Basis Election.", "Tax Management Setting", "Code", "Lot Relief Method", "Tax-Optimized", "Treas. Reg. 1.1012-1", "IRC Section 6045", "", "PII."),
       ("Tax Rate Source Profile", "Investor profile version (02) whose tax status the setting uses.", "Tax Management Setting", "Reference (Investor Profile)", "", "INPR-104588-03", "FINRA Rule 2111", "", "", "PII."),
       ("Applied Federal Marginal Tax Rate", "Federal marginal income tax rate used to estimate tax savings and the tax cost of gains, copied from the investor profile version named in Tax Rate Source Profile.", "Tax Management Setting", "Percentage", "", "24%", "IRS Publication 550", "", "", "PII - financial. Derived copy of 02 Investor Profile.Federal Marginal Tax Rate."),
       ("Tax Setting Effective From", "Date the current values of the setting took effect.", "Tax Management Setting", "Date", "ISO 8601", "2026-02-01", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Sleeves", "Sleeves of a multi-sleeve (unified managed account style) assignment: each sleeve follows its own model and may be managed by an external sub-adviser. Sleeves share the account target: the assigned model is an 01 multi-sleeve model whose 24 target set carries the sleeve weights, so targets, drift and proposals stay at account level (the leaner cut; sleeve-grain targets are a lever).", [
     ("Sleeve Assignment", [
       ("Sleeve Model Assignment", "Model assignment the sleeve belongs to.", "Sleeve Assignment", "Reference (Model Assignment, 46)", "", "MASGN-000418822", "Internal", "Envestnet", "Y", "Object PII tier: PII - financial. PII. Sleeves share the account target: the assigned model is an 01 multi-sleeve model whose 24 target set carries the sleeve weights, and targets, drift and proposals are kept at account level (lever: sleeve-grain targets)."),
       ("Sleeve Sequence", "Number of the sleeve within the assignment.", "Sleeve Assignment", "Integer", "", "2", "Internal", "", "", "PII."),
       ("Sleeve Model Portfolio", "Model portfolio (01) the sleeve follows.", "Sleeve Assignment", "Reference (Model Portfolio)", "", "MDL-0078", "Internal", "Envestnet", "Y", "PII."),
       ("Sleeve Sub-Adviser Engagement", "Sub-adviser engagement (52) under which an external sub-adviser manages the sleeve's model, where one does.", "Sleeve Assignment", "Reference (Sub-Adviser Engagement, 52)", "", "SADV-00412", "SEC Form ADV", "", "", "PII. The sub-adviser and its oversight are 52."),
       ("Sleeve Effective From", "Date the sleeve took effect in the account.", "Sleeve Assignment", "Date", "ISO 8601", "2025-11-10", "Internal", "", "", "PII."),
       ("Sleeve Effective To", "Date the sleeve was removed from the account.", "Sleeve Assignment", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Household Managed Group", "Accounts of one Client Household (02 PTY-HH-) managed together for asset location and wash-sale control. Not the 13 Mailing Household (MHG-) and not the 47 Fee Household.", [
     ("Household Managed Group", [
       ("Managed Group Household", "Client Household (02) whose accounts are managed together.", "Household Managed Group", "Reference (Party)", "", "PTY-HH-55012", "Internal", "Salesforce FSC", "Y", "Object PII tier: PII - financial. PII."),
       ("Group Member Account", "Account (15) that belongs to the group: the household's managed accounts and, for wash-sale monitoring only, self-directed accounts of the seller and spouse, including their IRAs.", "Household Managed Group", "Reference (Account)", "", "ACC-0049813", "Internal", "Rev. Rul. 2008-5", "Y", "PII."),
       ("Managed-Together Basis", "Purposes for which the account is grouped with the household's other accounts.", "Household Managed Group", "Code (multi)", "Household Managed Group Basis", "Asset Location; Wash Sale Scope", "Internal", "", "Y", "PII."),
       ("Account Tax Treatment", "Tax character of the member account used in asset location, set by rule from its 15 registration type (for example a Roth IRA is Tax-Exempt).", "Household Managed Group", "Code", "Account Tax Treatment", "Tax-Deferred", "IRS Publication 550", "", "", "PII. Set per account by rule from the 15 Account Registration Type (row rule); designated Roth sources within a plan account are not split (lever)."),
       ("Client Consent Date", "Date the client agreed that the accounts be managed together for asset location.", "Household Managed Group", "Date", "ISO 8601", "2025-11-10", "Internal", "", "", "PII."),
       ("Group Membership Status", "Whether the membership is active, proposed by the program and awaiting consent, or ended.", "Household Managed Group", "Code", "Record Status", "Active", "Internal", "", "", "PII. Usable Record Status values: Proposed (awaiting client consent), Active, Inactive."),
       ("Group Effective From", "Date the account joined the group.", "Household Managed Group", "Date", "ISO 8601", "2025-11-10", "Internal", "", "", "PII."),
       ("Group Effective To", "Date the account left the group.", "Household Managed Group", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Targets & Constraints", "MA-TGT",
  "What each managed account should hold and may not do: the versioned account target (the 24 target set version applied plus the account's overrides), the override lines, and the account investment constraints that implement 02 client restrictions accepted under Rule 3a-4 and 51 trust investment terms. Model weights stay 24 (TGT-); restriction text stays 02 or 51.",
  [
   ("Account Targets", "Versioned targets of a managed account: which 24 target set version applies, and where and why the account deviates from it.", [
     ("Managed Account Target", [
       ("Target Model Assignment", "Model assignment the target version belongs to.", "Managed Account Target", "Reference (Model Assignment, 46)", "", "MASGN-000418822", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Account Target Version", "Sequential version of the account's target within the assignment.", "Managed Account Target", "Integer", "", "7", "Internal", "", "", "PII."),
       ("Applied Model Target Set", "Version of the model's target allocation set (24) the account target is derived from; its weights are read from 24, never copied here as mastered weights.", "Managed Account Target", "Reference (Target Allocation Set, 24)", "", "TGT-00041207", "Internal", "", "Y", "PII (linked to an individual's account). CW-047 boundary rule 1."),
       ("Custom Target Indicator", "Whether the account target departs from the model through at least one Account Target Override Line.", "Managed Account Target", "Boolean", "", "Y", "ICA Rule 3a-4", "", "", "PII."),
       ("Account Cash Target", "Cash weight the account should hold, where it differs from the model's cash line (for example a client-requested reserve).", "Managed Account Target", "Percentage", "", "3.00%", "Internal", "", "", "PII."),
       ("Asset Class Drift Tolerance", "Largest absolute difference, in percentage points of account value, between an asset class's actual and target weight before the account is out of tolerance. Precedence where several apply: the Override Tolerance of an Account Target Override Line, then this account tolerance, then the Lower and Upper Tolerance Bands of the 24 Target Allocation Lines of the applied model, then the Drift Threshold of the program's trigger rule.", "Managed Account Target", "Percentage", "", "5.00%", "Internal", "Orion", "Y", "PII."),
       ("Target Approval Status", "Approval state of the target version; custom targets need an advisor's approval.", "Managed Account Target", "Code", "Approval Status", "Approved", "SEC Rule 206(4)-7", "", "", "PII."),
       ("Target Approved By", "Advisor or employee who approved the target version.", "Managed Account Target", "Reference (Employee)", "", "EMP-30412", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
       ("Target Effective From", "Moment from which the version is the account's target; it stops being effective when the next version starts.", "Managed Account Target", "Timestamp", "ISO 8601", "2026-10-05T09:30:00-04:00", "Internal", "", "Y", "PII."),
     ]),
     ("Account Target Override Line", [
       ("Override Account Target", "Account target version the override belongs to.", "Account Target Override Line", "Reference (Managed Account Target, 46)", "", "MASGN-000418822 / 7", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Override Asset Class", "Instrument asset class (17) whose target the line overrides, for asset class lines; blank on instrument lines.", "Account Target Override Line", "Code", "Instrument Asset Class", "Equity", "Internal", "", "", "PII. Exactly one of Override Asset Class and Override Instrument is filled."),
       ("Override Instrument", "Instrument whose target the line overrides or adds, for instrument lines (for example a legacy security transferred in and kept as a 49 Client Holding).", "Account Target Override Line", "Reference (Instrument, 17)", "", "INS-00412873", "Internal", "", "", "PII."),
       ("Override Weight", "Target weight of the asset class or instrument in this account, replacing the model's weight.", "Account Target Override Line", "Percentage", "", "12.00%", "Internal", "", "Y", "PII."),
       ("Override Tolerance", "Tolerance band, in percentage points, that applies to the overridden line; it takes precedence over the account's asset class tolerance and the 24 line bands.", "Account Target Override Line", "Percentage", "", "2.00%", "Internal", "", "", "PII."),
       ("Override Reason", "Why the account deviates from the model on this line.", "Account Target Override Line", "Code", "Account Target Override Reason", "Legacy Security", "ICA Rule 3a-4", "", "", "PII."),
     ]),
   ]),
   ("Account Investment Constraints", "Restrictions on the management of one account as the rebalancer implements them. The restriction itself is a 02 Client Restriction (CRX-) or a 51 Trust Term Provision; the constraint holds its coded effect only.", [
     ("Account Investment Constraint", [
       ("Constrained Account", "Managed account the constraint applies to.", "Account Investment Constraint", "Reference (Account)", "", "ACC-0049812", "ICA Rule 3a-4", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Source Client Restriction", "Client restriction (02) the constraint implements, such as a Rule 3a-4 reasonable restriction the program accepted.", "Account Investment Constraint", "Reference (Client Restriction)", "", "CRX-002318", "ICA Rule 3a-4", "", "Y", "PII. Exactly one of Source Client Restriction and Source Trust Term Provision is filled, except for program-imposed constraints (Constraint Type 'Minimum Cash')."),
       ("Source Trust Term Provision", "Trust term provision (51) the constraint implements, for fiduciary accounts whose trust instrument restricts investment.", "Account Investment Constraint", "Reference (Trust Term Provision, 51)", "", "", "Uniform Prudent Investor Act", "", "", "PII."),
       ("Constraint Type", "Kind of effect the constraint has on the account.", "Account Investment Constraint", "Code", "Account Constraint Type", "Exclude Security", "Internal", "Vestmark", "Y", "PII."),
       ("Constrained Instruments", "Instruments the constraint names, for security-level constraints.", "Account Investment Constraint", "Reference (Instrument, 17) (multi)", "", "INS-00104477", "Internal", "", "", "PII."),
       ("Constrained Classification Scheme", "Registered classification scheme version (09) the constrained sector or industry belongs to, for sector exclusions.", "Account Investment Constraint", "Reference (Classification Scheme)", "", "ICS-GICS-2023", "Internal", "GICS", "", "PII."),
       ("Constrained Classification Value", "Sector or industry the constraint excludes, as a node code of the Constrained Classification Scheme.", "Account Investment Constraint", "Code", "External (code of the 09 scheme named)", "10", "Internal", "GICS", "", "PII."),
       ("Constraint Limit Value", "Numeric limit of the constraint, such as the minimum cash amount or the maximum realized gain; blank for exclusions.", "Account Investment Constraint", "Decimal", "", "5000", "Internal", "", "", "PII."),
       ("Constraint Measurement Basis", "Unit in which the limit value is expressed.", "Account Investment Constraint", "Code", "Measurement Basis", "Absolute Amount", "Internal", "", "", "PII."),
       ("Implementation Rule", "How the rebalancer applies the constraint, for example by freezing the restricted Client Holding or substituting another security.", "Account Investment Constraint", "Code", "Constraint Implementation Rule", "Substitute with Alternate", "ICA Rule 3a-4", "", "", "PII."),
       ("Substitute Instrument", "Instrument bought in place of an excluded one, where the rule is substitution.", "Account Investment Constraint", "Reference (Instrument, 17)", "", "INS-00211903", "Internal", "", "", "PII."),
       ("Constraint Status", "Whether the constraint is active, pending setup or ended.", "Account Investment Constraint", "Code", "Record Status", "Active", "Internal", "", "", "PII. Usable Record Status values: Pending (being set up), Active, Inactive."),
       ("Constraint Effective From", "Date the constraint took effect in management of the account.", "Account Investment Constraint", "Date", "ISO 8601", "2026-03-02", "ICA Rule 3a-4", "", "", "PII."),
       ("Constraint Effective To", "Date the constraint stopped applying.", "Account Investment Constraint", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Drift Monitoring", "MA-DRF",
  "When managed accounts are assessed and how far each has drifted from its target: the rebalance trigger rules of each program or model, and the drift assessments of each account with their asset class lines. Actual weights and values are Derived copies of the 49 brokerage book of record at a stated as-of timestamp. Asset classes use the 17 Instrument Asset Class list that 24 targets and 49 holdings use.",
  [
   ("Trigger Rules", "Rules that say when an account is assessed and when it should be rebalanced.", [
     ("Rebalance Trigger Rule", [
       ("Rule Program", "Advisory program (01 service offering) the rule applies to.", "Rebalance Trigger Rule", "Reference (Service Offering, 01)", "", "OFFR-0012", "SEC Form ADV", "", "", "Object PII tier: No PII."),
       ("Rule Model Portfolio", "Model portfolio (01) the rule applies to; blank when it applies to every model of the program.", "Rebalance Trigger Rule", "Reference (Model Portfolio)", "", "", "Internal", "", "", ""),
       ("Trigger Type", "Kind of event or condition the rule reacts to.", "Rebalance Trigger Rule", "Code", "Rebalance Trigger Type", "Threshold", "Internal", "SEC IM Guidance 2017-02", "", ""),
       ("Drift Threshold", "Total drift above which the rule triggers a rebalance, for threshold rules; it is the last tolerance in the precedence stated on Managed Account Target.Asset Class Drift Tolerance.", "Rebalance Trigger Rule", "Percentage", "", "5.00%", "Internal", "", "", ""),
       ("Evaluation Frequency", "How often accounts under the rule are assessed.", "Rebalance Trigger Rule", "Code", "Frequency", "Daily", "Internal", "", "", ""),
       ("Cash Flow Threshold Amount", "Deposit or withdrawal amount, in USD, above which the rule invests or raises cash at once rather than at the next cycle.", "Rebalance Trigger Rule", "Amount", "", "USD 100", "Internal", "", "", ""),
       ("Minimum Trade Amount", "Smallest trade, in USD, the rule lets a rebalance propose.", "Rebalance Trigger Rule", "Amount", "", "USD 10", "Internal", "", "", ""),
       ("Rule Status", "Lifecycle status of the rule.", "Rebalance Trigger Rule", "Code", "Record Status", "Active", "Internal", "", "", ""),
       ("Rule Effective From", "Date the rule took effect.", "Rebalance Trigger Rule", "Date", "ISO 8601", "2026-01-01", "Internal", "", "", ""),
       ("Rule Effective To", "Date the rule stopped applying.", "Rebalance Trigger Rule", "Date", "ISO 8601", "", "Internal", "", "", ""),
       ("Rule Approved By", "Employee who approved the rule under the adviser's rebalancing policies.", "Rebalance Trigger Rule", "Reference (Employee)", "", "EMP-30412", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
     ]),
   ]),
   ("Drift Assessments", "One comparison of an account's actual weights with its target at a moment.", [
     ("Drift Assessment", [
       ("Drift Assessment ID", "Unique identifier of the assessment of one account at one moment.", "Drift Assessment", "Identifier", "", "DRFT-20261005-00418822", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Assessed Account", "Account assessed.", "Drift Assessment", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII."),
       ("Assessed Account Target", "Account target version the actual weights were compared with; it names the model assignment.", "Drift Assessment", "Reference (Managed Account Target, 46)", "", "MASGN-000418822 / 7", "Internal", "", "", "PII."),
       ("Assessment Timestamp", "Moment the assessment was made.", "Drift Assessment", "Timestamp", "ISO 8601", "2026-10-05T06:15:00-04:00", "Internal", "", "", "PII."),
       ("Holdings As-Of Timestamp", "Moment of the 49 Client Holding view the assessment read.", "Drift Assessment", "Timestamp", "ISO 8601", "2026-10-04T20:00:00-04:00", "Internal", "SEC Rule 17a-3", "", "PII."),
       ("Account Market Value", "Market value of the account at the 49 Client Holdings as-of timestamp, in USD.", "Drift Assessment", "Amount", "", "USD 184,220.15", "Internal", "", "", "PII - financial. Derived copy of 49 (Client Holding valuation) as of Holdings As-Of Timestamp."),
       ("Total Drift", "Half the sum of the absolute differences between actual and target asset class weights, whatever the Drift Method of the lines.", "Drift Assessment", "Percentage", "", "6.10%", "Internal", "Orion", "Y", "PII."),
       ("Maximum Asset Class Drift", "Largest absolute difference between an asset class's actual and target weight.", "Drift Assessment", "Percentage", "", "5.40%", "Internal", "", "", "PII."),
       ("Cash Drift", "Actual cash weight minus the account's cash target.", "Drift Assessment", "Percentage", "", "1.20%", "Internal", "", "", "PII."),
       ("Tolerance Breached Indicator", "Whether any drift measure exceeded the tolerance that applies to the account.", "Drift Assessment", "Boolean", "", "Y", "Internal", "", "Y", "PII."),
       ("Drift Method", "Method by which the line drift values were measured.", "Drift Assessment", "Code", "Drift Method", "Absolute Asset Class Weight", "Internal", "", "", "PII."),
       ("Pending Activity Indicator", "Whether unsettled orders or money movements were pending in the account at the as-of timestamp, which may defer a rebalance.", "Drift Assessment", "Boolean", "", "N", "Internal", "", "", "PII. Derived copy of 49: pending client account activity (CLACT-), which reflects 48 orders and 50 movements, as of Holdings As-Of Timestamp."),
     ]),
     ("Drift Assessment Line", [
       ("Line Drift Assessment", "Assessment the line belongs to.", "Drift Assessment Line", "Reference (Drift Assessment, 46)", "", "DRFT-20261005-00418822", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Line Asset Class", "Instrument asset class (17) the line measures; blank on instrument lines.", "Drift Assessment Line", "Code", "Instrument Asset Class", "Fixed Income", "Internal", "", "Y", "PII. Exactly one of Line Asset Class and Line Instrument is filled."),
       ("Line Instrument", "Instrument the line measures, for instrument lines: an Account Target Override Line on an instrument (such as a legacy security) or Security Level drift.", "Drift Assessment Line", "Reference (Instrument, 17)", "", "", "Internal", "", "", "PII."),
       ("Actual Weight", "Share of account value held in the asset class at the 49 Client Holdings as-of timestamp.", "Drift Assessment Line", "Percentage", "", "34.60%", "Internal", "", "", "PII - financial. Derived copy of 49 (Client Holding) as of the assessment's Holdings As-Of Timestamp."),
       ("Line Target Weight", "Target weight of the asset class or instrument for the account at the assessment, after overrides.", "Drift Assessment Line", "Percentage", "", "40.00%", "Internal", "", "", "PII. Derived copy: see the row rule."),
       ("Line Drift", "Actual weight minus target weight.", "Drift Assessment Line", "Percentage", "", "-5.40%", "Internal", "", "Y", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Rebalancing", "MA-RBL",
  "Decisions to rebalance managed accounts: the account rebalance event that records what triggered a decision, what was decided and why, and the model change implementation that phases a change of a model's 24 target set across the accounts that follow it. Not the 24 Rebalance Run (RBAL-), which rebalances fund and institutional portfolios in 18.",
  [
   ("Account Rebalance Events", "One rebalance decision for one account.", [
     ("Account Rebalance Event", [
       ("Rebalance Event ID", "Unique identifier of the rebalance event.", "Account Rebalance Event", "Identifier", "", "ARBE-20261005-00031207", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Rebalanced Account", "Account the decision is for.", "Account Rebalance Event", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII."),
       ("Event Trigger Type", "What triggered the event.", "Account Rebalance Event", "Code", "Rebalance Trigger Type", "Threshold", "Internal", "", "", "PII."),
       ("Triggering Rule", "Trigger rule that fired, keyed by program, trigger type and rule effective date.", "Account Rebalance Event", "Reference (Rebalance Trigger Rule, 46)", "", "OFFR-0012 / Threshold / 2026-01-01", "Internal", "", "", "PII."),
       ("Triggering Drift Assessment", "Drift assessment that found the account out of tolerance, for threshold events.", "Account Rebalance Event", "Reference (Drift Assessment, 46)", "", "DRFT-20261005-00418822", "Internal", "", "", "PII."),
       ("Triggering Model Change", "Model change implementation the event carries out, for model change events.", "Account Rebalance Event", "Reference (Model Change Implementation, 46)", "", "", "Internal", "", "", "PII."),
       ("Triggering Cash Instruction", "Cash instruction the event carries out, for cash flow events.", "Account Rebalance Event", "Reference (Managed Account Cash Instruction, 46)", "", "", "Internal", "", "", "PII."),
       ("Applied Account Target", "Account target version the account was rebalanced to.", "Account Rebalance Event", "Reference (Managed Account Target, 46)", "", "MASGN-000418822 / 7", "Internal", "", "", "PII."),
       ("Rebalance Decision", "What was decided for the account.", "Account Rebalance Event", "Code", "Rebalance Decision", "Rebalance", "Internal", "SEC Wrap Fee Risk Alert 2021", "Y", "PII."),
       ("Rebalance Skip Reason", "Why the account was not rebalanced or only partly rebalanced.", "Account Rebalance Event", "Code", "Rebalance Skip Reason", "", "Internal", "", "", "PII."),
       ("Estimated Turnover", "One-way turnover of the proposed trades as a share of account value.", "Account Rebalance Event", "Percentage", "", "4.80%", "Internal", "", "", "PII."),
       ("Estimated Realized Gain", "Net capital gain (negative for a loss) the proposed sales would realize.", "Account Rebalance Event", "Amount", "", "USD 1,240.00", "IRS Publication 550", "", "", "PII."),
       ("Rebalance Event Timestamp", "Moment the decision was made.", "Account Rebalance Event", "Timestamp", "ISO 8601", "2026-10-05T07:02:11-04:00", "SEC Rule 204-2", "", "Y", "PII."),
       ("Event Proposal Batch", "Trade proposal batch that carries the event's proposals.", "Account Rebalance Event", "Reference (Trade Proposal Batch, 46)", "", "TPBAT-20261005-0007", "Internal", "", "", "PII."),
       ("Decision Reviewed By", "Advisor or operations employee who reviewed the decision, where the program requires review.", "Account Rebalance Event", "Reference (Employee)", "", "", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
     ]),
   ]),
   ("Model Change Implementations", "How a change of a model's targets (24) is carried into the accounts that follow the model.", [
     ("Model Change Implementation", [
       ("Changed Model Portfolio", "Model portfolio (01) whose targets changed.", "Model Change Implementation", "Reference (Model Portfolio)", "", "MDL-0077", "Internal", "", "", "Object PII tier: No PII."),
       ("From Target Set", "Target set version (24) the accounts move from.", "Model Change Implementation", "Reference (Target Allocation Set, 24)", "", "TGT-00041188", "Internal", "", "", ""),
       ("To Target Set", "Target set version (24) the accounts move to.", "Model Change Implementation", "Reference (Target Allocation Set, 24)", "", "TGT-00041207", "Internal", "", "", ""),
       ("Implementation Window Start", "First day accounts may be traded to the new targets.", "Model Change Implementation", "Date", "ISO 8601", "2026-10-05", "Internal", "", "", ""),
       ("Implementation Window End", "Last day by which every account in scope should be implemented or deferred.", "Model Change Implementation", "Date", "ISO 8601", "2026-10-16", "Internal", "", "", ""),
       ("Phasing Method", "How the change is spread across accounts and days.", "Model Change Implementation", "Code", "Model Change Phasing", "Tax-Aware Phased", "Internal", "", "", ""),
       ("Tax-Aware Transition Indicator", "Whether account tax budgets and short-term gain avoidance limit the sales the change may cause.", "Model Change Implementation", "Boolean", "", "Y", "IRS Publication 550", "", "", ""),
       ("Accounts in Scope Count", "Number of accounts assigned to the model when the implementation started.", "Model Change Implementation", "Integer", "", "48211", "Internal", "", "", ""),
       ("Accounts Deferred Count", "Number of accounts whose implementation was deferred (tax budget, wash-sale window, restriction, pending activity).", "Model Change Implementation", "Integer", "", "2231", "Internal", "", "", ""),
       ("Implementation Status", "Where the implementation stands.", "Model Change Implementation", "Code", "Implementation Status", "In Progress", "Internal", "", "", ""),
       ("Implementation Approved By", "Employee who approved the implementation plan.", "Model Change Implementation", "Reference (Employee)", "", "EMP-30412", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Tax Management", "MA-TAX",
  "Account-level tax management of retail managed accounts (CW-048): the account tax budget, tax-loss harvest decisions, the firm's substantially identical security groups, wash sale control windows over the seller's and spouse's accounts, including IRAs (IRC section 1091; Rev. Rul. 2008-5) and asset location decisions. Lots are 49 Client Tax Lots, never 18 Tax Lots (LOT-); realized amounts are Derived copies of 49. The 24 Tax Budget keeps 18 portfolios only.",
  [
   ("Tax Budgets", "Limits on realized gains and loss harvesting goals for one account and tax year.", [
     ("Account Tax Budget", [
       ("Budget Account", "Managed account the budget protects.", "Account Tax Budget", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Budget Tax Year", "Tax year the budget applies to.", "Account Tax Budget", "Integer", "", "2026", "IRS Publication 550", "", "Y", "PII."),
       ("Net Realized Gain Budget", "Largest net capital gain the program may realize in the account in the year.", "Account Tax Budget", "Amount", "", "USD 5,000", "IRS Publication 550", "", "Y", "PII."),
       ("Short-Term Gain Budget", "Largest net short-term capital gain the program may realize in the year.", "Account Tax Budget", "Amount", "", "USD 0", "IRC Section 1222", "", "", "PII."),
       ("Loss Harvesting Target", "Realized losses the program aims to harvest in the account in the year.", "Account Tax Budget", "Amount", "", "USD 3,000", "IRC Section 1091", "", "", "PII."),
       ("Realized Net Gain to Date", "Net capital gain realized in the account so far in the year.", "Account Tax Budget", "Amount", "", "USD 1,980.40", "IRS Form 8949", "", "", "PII - financial. Derived copy of 49 (Client Lot Relief) as of Realized As-Of Date."),
       ("Realized Short-Term Gain to Date", "Net short-term capital gain realized in the account so far in the year.", "Account Tax Budget", "Amount", "", "USD 0", "IRS Form 8949", "", "", "PII - financial. Derived copy of 49 (Client Lot Relief) as of Realized As-Of Date."),
       ("Realized As-Of Date", "Business date of the 49 realized gain figures.", "Account Tax Budget", "Date", "ISO 8601", "2026-10-02", "Internal", "", "", "PII."),
       ("Budget Instructed By", "Client or authorized agent (02) who gave the budget instruction.", "Account Tax Budget", "Reference (Party)", "", "PTY-104588", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Tax-Loss Harvesting", "Harvest opportunities found by the scan and what was decided for each.", [
     ("Tax-Loss Harvest Decision", [
       ("Harvest Decision ID", "Unique identifier of the decision on one harvest opportunity.", "Tax-Loss Harvest Decision", "Identifier", "", "TLH-20261005-00004512", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Harvest Account", "Account in which the loss was found.", "Tax-Loss Harvest Decision", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII."),
       ("Scan Timestamp", "Moment the harvest scan found the opportunity.", "Tax-Loss Harvest Decision", "Timestamp", "ISO 8601", "2026-10-05T06:20:00-04:00", "Internal", "", "", "PII."),
       ("Security Sold", "Security whose lots would be sold at a loss.", "Tax-Loss Harvest Decision", "Reference (Instrument, 17)", "", "INS-00104477", "IRC Section 1091", "", "Y", "PII."),
       ("Harvest Client Tax Lots", "Client tax lots (49) whose sale would realize the loss.", "Tax-Loss Harvest Decision", "Reference (Client Tax Lot, 49) (multi)", "", "CTLOT-00418822173; CTLOT-00418822174", "IRC Section 6045", "Treas. Reg. 1.1012-1", "Y", "PII. Always the 49 Client Tax Lot, never 18 LOT- (CW-048)."),
       ("Replacement Security", "Security bought to keep the account's exposure, chosen so that it is not substantially identical to the security sold under the firm's security groups.", "Tax-Loss Harvest Decision", "Reference (Instrument, 17)", "", "INS-00211903", "IRC Section 1091", "IRS Publication 550", "", "PII."),
       ("Unrealized Loss at Scan", "Unrealized loss on the lots at the scan, in USD.", "Tax-Loss Harvest Decision", "Amount", "", "USD -2,415.60", "IRS Publication 550", "", "Y", "PII - financial. Derived copy of 49 (Client Tax Lot cost basis and price); the scan reads lots and prices as of Scan Timestamp."),
       ("Harvest Loss Term", "Whether the loss would be short-term or long-term.", "Tax-Loss Harvest Decision", "Code", "External (18 list Holding Period Term)", "Short-Term", "IRC Section 1222", "", "", "PII."),
       ("Estimated Tax Saving", "Estimated reduction in the client's tax from realizing the loss.", "Tax-Loss Harvest Decision", "Amount", "", "USD 579.74", "Internal", "SEC EIA Risk Alert 2021", "", "PII."),
       ("Tax Saving Method", "How the estimated tax saving was computed.", "Tax-Loss Harvest Decision", "Code", "Tax Saving Method", "Client Marginal Rate", "Internal", "SEC IM Guidance 2017-02", "", "PII."),
       ("Harvest Decision", "What was decided for the opportunity.", "Tax-Loss Harvest Decision", "Code", "Harvest Decision", "Harvest", "Internal", "", "Y", "PII."),
       ("Harvest Skip Reason", "Why the opportunity was not harvested.", "Tax-Loss Harvest Decision", "Code", "Harvest Skip Reason", "", "IRC Section 1091", "", "", "PII."),
       ("Resulting Wash Sale Window", "Wash sale control window opened by the harvest sale, keyed by group or account, security group and window start.", "Tax-Loss Harvest Decision", "Reference (Wash Sale Control Window, 46)", "", "PTY-HH-55012 / SPX500 / 2026-09-05", "IRC Section 1091", "", "", "PII."),
     ]),
   ]),
   ("Wash Sale Control", "The firm's grouping of substantially identical securities and the windows in which purchases are blocked after a loss sale.", [
     ("Substantially Identical Security Group", [
       ("Security Group Code", "Firm-defined code of the group of securities the firm's tax policy treats as substantially identical to each other.", "Substantially Identical Security Group", "Code", "Firm-defined", "SPX500", "IRC Section 1091", "Treas. Reg. 1.1091-1", "Y", "Object PII tier: No PII."),
       ("Security Group Name", "Name of the group.", "Substantially Identical Security Group", "Text", "", "S&P 500 index trackers", "Internal", "", "", ""),
       ("Group Member Instrument", "Instrument that belongs to the group.", "Substantially Identical Security Group", "Reference (Instrument, 17)", "", "INS-00104477", "IRC Section 1091", "", "Y", ""),
       ("Security Group Basis", "Why the members are grouped as substantially identical.", "Substantially Identical Security Group", "Code", "Security Group Basis", "Same Index Tracked", "IRS Publication 550", "", "", ""),
       ("Tracked Index", "Benchmark index the members track, for index-based groups.", "Substantially Identical Security Group", "Reference (Benchmark)", "", "BMK-0001", "Internal", "", "", ""),
       ("Group Policy Approval Status", "Approval of the grouping under the firm's tax policy (tax counsel review).", "Substantially Identical Security Group", "Code", "Approval Status", "Approved", "Internal", "", "", ""),
       ("Member Effective From", "Date the instrument joined the group.", "Substantially Identical Security Group", "Date", "ISO 8601", "2024-01-02", "Internal", "", "", ""),
       ("Member Effective To", "Date the instrument left the group.", "Substantially Identical Security Group", "Date", "ISO 8601", "", "Internal", "", "", ""),
     ]),
     ("Wash Sale Control Window", [
       ("Window Household", "Client Household (02) whose household managed group the window covers; blank when the window covers one account only.", "Wash Sale Control Window", "Reference (Party)", "", "PTY-HH-55012", "Internal", "IRS Publication 550", "Y", "Object PII tier: PII - financial. PII. Exactly one of Window Household and Window Account is filled. The household window is firm policy over the legal scope: IRC section 1091 reaches purchases by the seller and spouse (IRS Publication 550) and in the seller's own IRAs (Rev. Rul. 2008-5); accounts of other household members are not put in scope."),
       ("Window Account", "Account the window covers, where it covers one account only.", "Wash Sale Control Window", "Reference (Account)", "", "", "IRC Section 1091", "", "", "PII."),
       ("Window Security Group", "Substantially identical security group whose purchase the window blocks.", "Wash Sale Control Window", "Reference (Substantially Identical Security Group, 46)", "", "SPX500", "IRC Section 1091", "", "Y", "PII."),
       ("Triggering Harvest Decision", "Harvest decision whose loss sale opened the window; blank for a loss sale outside the program, such as a client-directed sale.", "Wash Sale Control Window", "Reference (Tax-Loss Harvest Decision, 46)", "", "TLH-20261005-00004512", "IRC Section 1091", "", "", "PII."),
       ("Triggering Sale Date", "Trade date of the loss sale.", "Wash Sale Control Window", "Date", "ISO 8601", "2026-10-05", "IRC Section 1091", "", "", "PII."),
       ("Window Start Date", "First day of the window: 30 days before the loss sale.", "Wash Sale Control Window", "Date", "ISO 8601", "2026-09-05", "IRC Section 1091", "Treas. Reg. 1.1091-1", "Y", "PII."),
       ("Window End Date", "Last day of the window: 30 days after the loss sale.", "Wash Sale Control Window", "Date", "ISO 8601", "2026-11-04", "IRC Section 1091", "Treas. Reg. 1.1091-1", "Y", "PII."),
       ("Controlled Accounts in Scope", "Accounts managed under a Model Assignment in which the program blocks purchases of the security group during the window: managed accounts of the seller and spouse, including managed IRAs.", "Wash Sale Control Window", "Reference (Account) (multi)", "", "ACC-0049812; ACC-0049813", "IRC Section 1091", "Rev. Rul. 2008-5", "Y", "PII."),
       ("Monitored Accounts in Scope", "Accounts the program does not control (self-directed accounts and IRAs of the seller or spouse) in which a purchase of the group is flagged to the client and advisor, never blocked.", "Wash Sale Control Window", "Reference (Account) (multi)", "", "ACC-0050211", "Rev. Rul. 2008-5", "IRS Publication 550", "Y", "PII."),
       ("Window Status", "Where the window stands.", "Wash Sale Control Window", "Code", "Wash Sale Window Status", "Open", "Internal", "", "Y", "PII."),
     ]),
   ]),
   ("Asset Location", "Placement of asset classes across the taxable and tax-advantaged accounts of a household managed group.", [
     ("Asset Location Decision", [
       ("Location Household", "Client Household (02) whose managed group the decision is for.", "Asset Location Decision", "Reference (Party)", "", "PTY-HH-55012", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Location Asset Class", "Asset class placed.", "Asset Location Decision", "Code", "Instrument Asset Class", "Fixed Income", "Internal", "", "Y", "PII."),
       ("Location Account", "Account in which the asset class is placed.", "Asset Location Decision", "Reference (Account)", "", "ACC-0049813", "Internal", "", "Y", "PII."),
       ("Placement Weight", "Share of the household's target for the asset class that this account holds.", "Asset Location Decision", "Percentage", "", "70.00%", "Internal", "", "Y", "PII."),
       ("Asset Location Basis", "Tax characteristic that drove the placement.", "Asset Location Decision", "Code", "Asset Location Basis", "Ordinary Income Yield", "IRS Publication 550", "", "", "PII."),
       ("Location Engine", "Model inventory entry (37) of the optimizer that proposed the placement.", "Asset Location Decision", "Reference (Model Inventory Entry, 37)", "", "MODEL-0433", "SR 11-7", "", "", "PII (linked to an individual's accounts)."),
       ("Location Effective From", "Date the placement took effect.", "Asset Location Decision", "Date", "ISO 8601", "2026-02-01", "Internal", "", "", "PII."),
       ("Location Effective To", "Date the placement was replaced.", "Asset Location Decision", "Date", "ISO 8601", "", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Trade Proposals", "MA-TRP",
  "Trades the program proposes for managed accounts, up to release (CW-049): batches, proposals, the client tax lots chosen for each proposed sale, and the pre-trade exceptions raised. A released proposal becomes a 48 Client Order, or a 16 Participant Investment Transfer for a participant managed account (16 nets transfers into the plan-level 29 Fund Order); routing, execution, allocation and confirmation are 48. Not the 24 Proposed Trade, which serves 18 portfolios.",
  [
   ("Batches", "Groups of proposals generated and released together.", [
     ("Trade Proposal Batch", [
       ("Batch ID", "Unique identifier of the batch.", "Trade Proposal Batch", "Identifier", "", "TPBAT-20261005-0007", "Internal", "", "Y", "Object PII tier: No PII."),
       ("Batch Program", "Advisory program (01 service offering) the batch serves.", "Trade Proposal Batch", "Reference (Service Offering, 01)", "", "OFFR-0012", "Internal", "", "", ""),
       ("Batch Cycle Date", "Business date of the rebalancing cycle the batch belongs to.", "Trade Proposal Batch", "Date", "ISO 8601", "2026-10-05", "Internal", "", "", ""),
       ("Rebalancing Engine", "Model inventory entry (37) of the rebalancing engine that generated the proposals.", "Trade Proposal Batch", "Reference (Model Inventory Entry, 37)", "", "MODEL-0412", "SR 11-7", "SEC IM Guidance 2017-02", "", "CW-057: algorithmic and human-advised programs use the same objects; the engine is named here."),
       ("Batch Created Timestamp", "Moment the batch was generated.", "Trade Proposal Batch", "Timestamp", "ISO 8601", "2026-10-05T07:00:00-04:00", "Internal", "", "", ""),
       ("Batch Account Count", "Number of accounts with at least one proposal in the batch.", "Trade Proposal Batch", "Integer", "", "12407", "Internal", "", "", ""),
       ("Batch Released Timestamp", "Moment the batch was released for order creation.", "Trade Proposal Batch", "Timestamp", "ISO 8601", "2026-10-05T09:15:00-04:00", "SEC Rule 204-2", "", "", ""),
       ("Batch Proposal Count", "Number of proposals in the batch.", "Trade Proposal Batch", "Integer", "", "38915", "Internal", "", "", ""),
       ("Batch Status", "Where the batch stands.", "Trade Proposal Batch", "Code", "Batch Status", "Released", "Internal", "", "", ""),
       ("Batch Released By", "Employee who released the batch; blank for an automatic release.", "Trade Proposal Batch", "Reference (Employee)", "", "EMP-30588", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
     ]),
   ]),
   ("Proposals", "Proposed trades in one account and the lots chosen for sales.", [
     ("Trade Proposal", [
       ("Trade Proposal ID", "Unique identifier of the proposal line for one account and instrument.", "Trade Proposal", "Identifier", "", "TRPR-20261005-000418822", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Proposal Batch", "Batch the proposal belongs to.", "Trade Proposal", "Reference (Trade Proposal Batch, 46)", "", "TPBAT-20261005-0007", "Internal", "", "", "PII."),
       ("Proposal Account", "Account the trade is proposed for.", "Trade Proposal", "Reference (Account)", "", "ACC-0049812", "FIX Protocol", "", "Y", "PII."),
       ("Proposal Instrument", "Instrument to be traded.", "Trade Proposal", "Reference (Instrument, 17)", "", "INS-00211903", "FIX Protocol", "", "Y", "PII."),
       ("Proposal Side", "Direction of the proposed trade.", "Trade Proposal", "Code", "Order Side", "Buy", "FIX Protocol", "", "Y", "PII."),
       ("Proposed Quantity", "Quantity to be traded, unsigned, which may be fractional; blank when the trade is proposed by amount.", "Trade Proposal", "Decimal", "", "12.4831", "FIX Protocol", "", "Y", "PII."),
       ("Proposed Amount", "Amount in USD to be traded, where the trade is proposed by value (dollar-based and fractional trading).", "Trade Proposal", "Amount", "", "USD 1,250.00", "FIX Protocol", "", "Y", "PII."),
       ("Fractional Quantity Indicator", "Whether the proposal is for a fractional share quantity.", "Trade Proposal", "Boolean", "", "Y", "Internal", "", "", "PII."),
       ("Proposal Reason", "Why the trade is proposed.", "Trade Proposal", "Code", "Proposal Reason", "Rebalance", "Internal", "", "", "PII."),
       ("Source Rebalance Event", "Rebalance event that generated the proposal.", "Trade Proposal", "Reference (Account Rebalance Event, 46)", "", "ARBE-20261005-00031207", "Internal", "", "", "PII. One of Source Rebalance Event, Source Harvest Decision and Source Cash Instruction is filled."),
       ("Source Harvest Decision", "Harvest decision that generated the proposal.", "Trade Proposal", "Reference (Tax-Loss Harvest Decision, 46)", "", "", "Internal", "", "", "PII."),
       ("Source Cash Instruction", "Cash instruction that generated the proposal.", "Trade Proposal", "Reference (Managed Account Cash Instruction, 46)", "", "", "Internal", "", "", "PII."),
       ("Proposal Status", "Where the proposal stands; Released is the last status held here.", "Trade Proposal", "Code", "Proposal Status", "Released", "Internal", "", "Y", "PII. Every state after release is 48 (or 29)."),
       ("Execution Route", "Which kind of record the proposal is released as.", "Trade Proposal", "Code", "Proposal Execution Route", "Brokerage Client Order", "Internal", "", "", "PII."),
       ("Released Client Order", "Client order (48) the proposal became on release.", "Trade Proposal", "Reference (Client Order, 48)", "", "CLORD-20261005-004188221", "SEC Rule 204-2", "", "Y", "PII."),
       ("Released Participant Investment Transfer", "Participant investment transfer (16) the proposal was released into, for participant managed accounts; many trade proposals can net into one transfer (n : 1), and 16 nets the transfers into the plan-level 29 Fund Order. The link is held on the 46 side only.", "Trade Proposal", "Reference (Participant Investment Transfer, 16)", "", "PEXC-2026-0041877", "Internal", "", "Y", "PII. Exactly one of Released Client Order and Released Participant Investment Transfer is filled once Released."),
       ("Release Timestamp", "Moment the proposal was released.", "Trade Proposal", "Timestamp", "ISO 8601", "2026-10-05T09:15:02-04:00", "SEC Rule 204-2", "", "", "PII."),
     ]),
     ("Proposed Client Lot Selection", [
       ("Lot Selection Proposal", "Proposed sale the lot selection belongs to.", "Proposed Client Lot Selection", "Reference (Trade Proposal, 46)", "", "TRPR-20261005-000418823", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Selected Client Tax Lot", "Client tax lot (49) the sale should relieve, named to the broker as a specific identification at the time of sale.", "Proposed Client Lot Selection", "Reference (Client Tax Lot, 49)", "", "CTLOT-00418822173", "Treas. Reg. 1.1012-1", "IRC Section 6045", "Y", "PII. Never 18 LOT- (CW-048)."),
       ("Quantity to Relieve", "Quantity of the lot the sale should relieve.", "Proposed Client Lot Selection", "Decimal", "", "8.2500", "Treas. Reg. 1.1012-1", "", "Y", "PII."),
       ("Estimated Lot Gain", "Gain (negative for a loss) expected from relieving the lot at the proposal price.", "Proposed Client Lot Selection", "Amount", "", "USD -812.40", "IRS Form 8949", "", "", "PII."),
       ("Lot Holding Period Term", "Whether the lot's gain or loss would be short-term or long-term on the proposal date.", "Proposed Client Lot Selection", "Code", "External (18 list Holding Period Term)", "Long-Term", "IRC Section 1222", "", "", "PII. Derived copy of 49: from the Client Tax Lot holding period start as of Lot Data As-Of Timestamp."),
       ("Lot Data As-Of Timestamp", "Moment of the 49 lot view the selection read.", "Proposed Client Lot Selection", "Timestamp", "ISO 8601", "2026-10-04T20:00:00-04:00", "Internal", "", "", "PII."),
     ]),
   ]),
   ("Exceptions", "Pre-trade checks a proposal failed and how each was resolved.", [
     ("Trade Proposal Exception", [
       ("Exception Trade Proposal", "Proposal the exception was raised on.", "Trade Proposal Exception", "Reference (Trade Proposal, 46)", "", "TRPR-20261005-000418822", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Pre-Trade Check Type", "Check that raised the exception.", "Trade Proposal Exception", "Code", "Pre-Trade Check Type", "Wash Sale Window", "Internal", "Advisers Act Section 206(3)", "Y", "PII."),
       ("Exception Outcome", "How the exception was resolved.", "Trade Proposal Exception", "Code", "Exception Outcome", "Proposal Blocked", "Internal", "", "Y", "PII."),
       ("Exception Detail", "Short description of what the check found.", "Trade Proposal Exception", "Text", "", "Purchase of SPX500 group blocked until 2026-11-04", "Internal", "", "", "PII."),
       ("Exception Raised Timestamp", "Moment the exception was raised.", "Trade Proposal Exception", "Timestamp", "ISO 8601", "2026-10-05T07:00:41-04:00", "Internal", "", "", "PII."),
       ("Override Approver", "Employee who approved an override of the exception.", "Trade Proposal Exception", "Reference (Employee)", "", "", "SEC Rule 206(4)-7", "", "", "PII (internal staff)."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Cash Management", "MA-CSH",
  "Instructions to raise or invest cash in a managed account (CW-049): a withdrawal, a deposit, a fee payment or a required minimum distribution needs the program to sell or buy before the 50 money movement or the 49 fee posting can complete. The money movement is 50 and the fee debit 47, and each references the instruction from its side; the standing instruction and RMD are 15 and the cash balance is 49 (Account Cash Balance).",
  [
   ("Cash Instructions", "One instruction to raise or invest cash in one account.", [
     ("Managed Account Cash Instruction", [
       ("Cash Instruction ID", "Unique identifier of the instruction.", "Managed Account Cash Instruction", "Identifier", "", "CSHI-2026-00318273", "Internal", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Instruction Account", "Managed account in which cash is raised or invested.", "Managed Account Cash Instruction", "Reference (Account)", "", "ACC-0049812", "Internal", "", "Y", "PII."),
       ("Cash Instruction Type", "What the cash is raised or invested for.", "Managed Account Cash Instruction", "Code", "Cash Instruction Type", "Raise for Withdrawal", "Internal", "", "Y", "PII."),
       ("Instruction Amount", "Amount of cash to raise or invest, in USD.", "Managed Account Cash Instruction", "Amount", "", "USD 15,000.00", "Internal", "", "Y", "PII."),
       ("Source Standing Instruction", "Standing instruction (15) whose scheduled withdrawal or contribution the instruction serves.", "Managed Account Cash Instruction", "Reference (Account Standing Instruction, 15)", "", "", "Internal", "", "", "PII. At most one of Source Standing Instruction and Source RMD Record is filled. Withdrawals, deposits and fee payments are linked from the other side: 50 Money Movement and 47 Fee Debit reference this CSHI- key (links held once)."),
       ("Source RMD Record", "Required minimum distribution record (15) the instruction raises cash for.", "Managed Account Cash Instruction", "Reference (RMD Record, 15)", "", "", "IRC Section 401(a)(9)", "", "", "PII."),
       ("Required By Date", "Date by which the cash must be available or invested.", "Managed Account Cash Instruction", "Date", "ISO 8601", "2026-10-07", "Internal", "", "", "PII."),
       ("Available Cash Used", "Cash already available in the account that reduced the amount to raise.", "Managed Account Cash Instruction", "Amount", "", "USD 2,140.00", "Internal", "", "", "PII - financial. Derived copy of 49 (Account Cash Balance) as of Available Cash As-Of Timestamp."),
       ("Available Cash As-Of Timestamp", "Moment of the 49 cash balance view the instruction read.", "Managed Account Cash Instruction", "Timestamp", "ISO 8601", "2026-10-05T06:00:00-04:00", "Internal", "", "", "PII."),
       ("Cash Instruction Status", "Where the instruction stands.", "Managed Account Cash Instruction", "Code", "Cash Instruction Status", "Proposals Released", "Internal", "", "Y", "PII."),
       ("Proposals Generated Count", "Number of trade proposals generated to carry out the instruction.", "Managed Account Cash Instruction", "Integer", "", "4", "Internal", "", "", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
D("Managed Account Composites", "MA-CMP",
  "Program-level composites of client managed accounts (CW-050): which accounts of a program and model count together, for how long and why an account was excluded. 32 computes composite and account returns from this membership (Personal Rate of Return and Performance Return, W3); the 01 GIPS Composite (CMP-) is linked only under the wrap-composite lever, since advice programs sit outside the GIPS firm by default; 32 Composite Membership keys on 18 portfolios and is a different record.",
  [
   ("Composites", "Definition of a managed account composite.", [
     ("Managed Account Composite", [
       ("Managed Account Composite ID", "Unique identifier of the composite.", "Managed Account Composite", "Identifier", "", "MACP-0012", "Internal", "GIPS 2020", "Y", "Object PII tier: No PII."),
       ("Composite Name", "Name of the composite.", "Managed Account Composite", "Text", "", "Digital Advice - Moderate Growth (60/40)", "GIPS 2020", "", "", ""),
       ("Composite Program", "Advisory program (01 service offering) whose accounts the composite groups.", "Managed Account Composite", "Reference (Service Offering, 01)", "", "OFFR-0012", "Internal", "", "", ""),
       ("Composite Model Portfolio", "Model portfolio (01) the member accounts follow.", "Managed Account Composite", "Reference (Model Portfolio)", "", "MDL-0077", "GIPS 2020", "", "", ""),
       ("Composite Membership Rules", "Rules an account must meet to be a member.", "Managed Account Composite", "Code (multi)", "Composite Membership Rule", "Discretionary; Fully Invested; Minimum Account Value", "GIPS 2020", "", "", ""),
       ("Composite Minimum Account Value", "Smallest account value, in USD, for membership.", "Managed Account Composite", "Amount", "", "USD 3,000", "GIPS 2020", "", "", ""),
       ("Significant Cash Flow Threshold", "External cash flow, as a share of account value, above which an account is removed from the composite for the period.", "Managed Account Composite", "Percentage", "", "10.00%", "GIPS 2020", "", "", ""),
       ("Linked GIPS Composite", "GIPS composite (01) the managed account composite is presented as. Filled only under the wrap-composite lever: by default advice programs sit outside the GIPS firm and no composite is linked (24/32 review ruling).", "Managed Account Composite", "Reference (GIPS Composite, 01)", "", "CMP-0045", "GIPS 2020", "", "", ""),
       ("Composite Status", "Lifecycle status of the composite.", "Managed Account Composite", "Code", "Record Status", "Active", "Internal", "", "", ""),
       ("Composite Effective From", "Date the composite was created.", "Managed Account Composite", "Date", "ISO 8601", "2021-01-01", "GIPS 2020", "", "", ""),
       ("Composite Effective To", "Date the composite was terminated.", "Managed Account Composite", "Date", "ISO 8601", "", "GIPS 2020", "", "", ""),
     ]),
   ]),
   ("Composite Membership", "Effective-dated membership of client accounts in managed account composites.", [
     ("Managed Account Composite Membership", [
       ("Membership Composite", "Composite the account belongs to.", "Managed Account Composite Membership", "Reference (Managed Account Composite, 46)", "", "MACP-0012", "GIPS 2020", "", "Y", "Object PII tier: PII - financial. PII."),
       ("Member Account", "Client account (15) in the composite.", "Managed Account Composite Membership", "Reference (Account)", "", "ACC-0049812", "GIPS 2020", "", "Y", "PII."),
       ("Membership Model Assignment", "Model assignment under which the account qualified.", "Managed Account Composite Membership", "Reference (Model Assignment, 46)", "", "MASGN-000418822", "Internal", "", "", "PII."),
       ("Membership Start Date", "First day the account counts in the composite.", "Managed Account Composite Membership", "Date", "ISO 8601", "2026-01-01", "GIPS 2020", "", "Y", "PII."),
       ("Membership End Date", "Last day the account counts in the composite.", "Managed Account Composite Membership", "Date", "ISO 8601", "", "GIPS 2020", "", "Y", "PII."),
       ("Discretion Check Passed Indicator", "Whether the account was confirmed discretionary and unrestricted enough to represent the model when it joined.", "Managed Account Composite Membership", "Boolean", "", "Y", "GIPS 2020", "", "", "PII."),
       ("Composite Exclusion Reason", "Why the account left, or was kept out of, the composite.", "Managed Account Composite Membership", "Code", "Composite Exclusion Reason", "", "GIPS 2020", "", "Y", "PII."),
     ]),
   ]),
  ])

# ---------------------------------------------------------------------------
# Code lists: name -> (source, [(code, description)])
# ---------------------------------------------------------------------------
CL = {
 # Copies of enterprise shared lists (exact names and values; see proposals_w2_46.SHARED_MEMBERSHIPS)
 "Record Status": ("Enterprise shared list 'Record Status' (steward 09; ISO/IEC 11179-6 registration status concepts) - values copied", [("Draft","Being authored; not yet submitted"),("Proposed","Submitted for approval"),("Pending","Approved or created but not yet effective"),("Active","Current and usable for new records"),("Paused","Temporarily not in use; expected to resume"),("Inactive","Not currently in use but may be reactivated"),("Deprecated","Valid for history, not for new records"),("Retired","Permanently withdrawn")]),
 "Approval Status": ("Enterprise shared list 'Approval Status' (steward 09) - values copied", [("Not Required","No approval needed under the applicable policy"),("Pending","Submitted and awaiting decision"),("Approved",""),("Approved with Conditions","Approved subject to stated changes or conditions"),("Retrospectively Approved","Approved after the event (policy breach to be recorded)"),("Rejected",""),("Expired","Approval lapsed (e.g. past its review or expiry date)"),("Withdrawn","Withdrawn by the requester")]),
 "Frequency": ("Enterprise shared list 'Frequency' (steward 09; aligned to ISO 20022) - subset copied", [("Intraday","More than once per day (ISO 20022 INDA)"),("Daily","Once per business or calendar day (ISO 20022 DAIL)"),("Weekly","Once per week (ISO 20022 WEEK)"),("Monthly","Once per month (ISO 20022 MNTH)"),("Quarterly","Once per quarter (ISO 20022 QURT)"),("Semi-Annual","Twice per year (ISO 20022 MIAN)"),("Annual","Once per year (ISO 20022 YEAR)"),("On Event","Triggered by a defined business event rather than a calendar")]),
 "Order Side": ("Enterprise shared list 'Order Side' (steward 25; FIX Protocol Side (54)) - subset copied", [("Buy","FIX 1"),("Sell","FIX 2")]),
 "Lot Relief Method": ("Enterprise shared list 'Lot Relief Method' (steward 18; IRS Publication 550 / Treas. Reg. 1.1012-1) - values copied", [("FIFO","First in, first out"),("LIFO","Last in, first out"),("High Cost","Highest-cost lots first"),("Low Cost","Lowest-cost lots first"),("Specific Lot Identification","Lots named on the trade"),("Tax-Optimized","Minimizes tax given gain budget and holding periods"),("Average Cost","Average cost of all units")]),
 "Instrument Asset Class": ("Enterprise shared list 'Instrument Asset Class' (steward 17) - subset copied", [("Equity",""),("Fixed Income",""),("Cash & Money Market",""),("Multi-Asset","Funds whose look-through spans asset classes"),("Real Assets",""),("Commodity","")]),
 "Measurement Basis": ("Enterprise shared list 'Measurement Basis' (steward 01) - subset copied", [("% of Market Value",""),("Absolute Amount",""),("Count","")]),
 # Model Assignment
 "Assignment Reason": ("Internal", [("Initial Enrollment","First assignment after the 15 program enrollment"),("Risk Profile Change","New 02 investor profile version or 15 account investment profile"),("Client Request","Client asked for a different model"),("Advisor Recommendation","Followed a 45 recommendation"),("Model Retirement","The 01 model was retired and accounts mapped to a successor"),("Program Change","Account moved to another program; a new enrollment"),("Glide Path Step","Age- or date-based move to the next model of a series")]),
 "Account Discretion Type": ("SEC Form ADV / Investment Company Act Rule 3a-4 (named to avoid the 01 Discretion Type list of the offering)", [("Full Discretion","The program selects, buys and sells without prior client approval"),("Limited Discretion - Rebalance Only","The program may rebalance within the assigned model; model changes need client approval"),("Non-Discretionary","Each trade is approved by the client before release")]),
 "Regulatory AUM Classification": ("SEC Form ADV Part 1A Item 5.F and instructions (confirm wording)", [("Discretionary","Regulatory AUM over which the adviser has discretionary authority"),("Non-Discretionary","Regulatory AUM managed on a non-discretionary basis with continuous and regular supervisory or management services"),("Not Regulatory AUM","Assets that do not receive continuous and regular supervisory or management services")]),
 "Household Managed Group Basis": ("Internal", [("Asset Location","Asset classes placed across the group's accounts"),("Wash Sale Scope","Account of the seller or spouse whose purchases are blocked (managed) or flagged (self-directed) during wash sale windows (IRC section 1091; Rev. Rul. 2008-5)"),("Household Drift","Drift and rebalancing measured at household level as well as account level")]),
 "Account Tax Treatment": ("IRS Publication 550 / IRC sections 408 and 408A (classification for asset location, set per account from the 15 registration type; designated Roth plan sources not split)", [("Taxable","Individual, joint, trust and entity accounts"),("Tax-Deferred","Traditional, rollover, SEP and SIMPLE IRAs; workplace plan accounts"),("Tax-Exempt","Roth IRAs and other accounts whose qualified withdrawals are untaxed"),("Tax-Advantaged Education or Health","529 and HSA accounts")]),
 # Targets & Constraints
 "Account Target Override Reason": ("Internal / ICA Rule 3a-4", [("Legacy Security","Low-basis or transferred-in security (49 Client Holding) kept to avoid realizing gains"),("Client Preference","Client asked for a different weight"),("Concentration Limit","Reduces exposure to a single security or to employer stock held elsewhere"),("Restriction Implementation","Reweighting needed to implement an account investment constraint"),("Income Need","More income-producing assets for withdrawals"),("Held-Away Assets","Offsets assets the client holds outside the firm (45 aggregated assets)")]),
 "Account Constraint Type": ("Internal / ICA Rule 3a-4 (reasonable restrictions)", [("Exclude Security","Do not buy the named securities"),("Exclude Sector","Do not buy securities in the named GICS sector or industry"),("Do Not Sell","Keep the named securities; never sell them"),("Minimum Cash","Keep at least the stated cash amount or weight"),("Realized Gain Cap","Do not realize gains above the stated amount outside the tax budget"),("No Trading Window","Do not trade during a stated period")]),
 "Constraint Implementation Rule": ("Internal", [("Freeze Client Holding","Keep the restricted Client Holding (49) and rebalance around it"),("Substitute with Alternate","Buy the named substitute instead"),("Redistribute Pro Rata","Spread the excluded weight over the other holdings of the asset class"),("Hold as Cash","Leave the excluded weight in cash"),("Manual Review","Each affected proposal goes to an operations review")]),
 # Drift Monitoring
 "Rebalance Trigger Type": ("Internal / SEC IM Guidance Update 2017-02", [("Calendar","Scheduled date"),("Threshold","Drift beyond tolerance"),("Cash Flow","Deposit, withdrawal, fee or RMD"),("Model Change","New 24 target set version for the model"),("Tax Opportunity","Harvestable loss found by the scan"),("Client Request","Client or advisor asked for a rebalance"),("Restriction Change","New or ended account investment constraint")]),
 "Drift Method": ("Internal", [("Absolute Asset Class Weight","Actual minus target weight by asset class, in percentage points"),("Relative Asset Class Weight","Difference as a share of the target weight"),("Security Level","Actual minus target weight by instrument")]),
 # Rebalancing
 "Rebalance Decision": ("Internal", [("Rebalance","Full rebalance to the account target"),("Partial Rebalance","Trades limited by tax budget, minimum trade or a constraint"),("Cash Flow Only","Invest or raise cash without other trades"),("Skip","No trades proposed")]),
 "Rebalance Skip Reason": ("Internal", [("Within Tolerance","Drift below the trigger after recalculation"),("Below Minimum Trade","Required trades smaller than the minimum trade amount"),("Wash Sale Window","Required purchases blocked by an open window"),("Tax Budget Exhausted","Sales would exceed the account tax budget"),("Pending Activity","Unsettled orders or money movements in the account"),("Account Restriction","A 15 account restriction or freeze applies"),("Insufficient Cash","Cash short and no sale permitted")]),
 "Model Change Phasing": ("Internal", [("Immediate","All accounts in the first cycle"),("Phased by Cohort","Accounts split into cohorts traded on successive days"),("Tax-Aware Phased","Taxable accounts traded within their budgets; deferrals carried to later cycles"),("Next Natural Rebalance","Applied when each account next rebalances or has a cash flow")]),
 "Implementation Status": ("Internal", [("Planned",""),("In Progress",""),("Complete","Every account implemented or deferred with a reason"),("Canceled","")]),
 # Tax Management
 "Harvest Decision": ("Internal", [("Harvest","Sell the lots and buy the replacement"),("Partial Harvest","Sell some lots only"),("Skip","Do not harvest")]),
 "Harvest Skip Reason": ("Internal / IRC section 1091", [("Below Threshold","Loss below the minimum amount or percentage"),("Wash Sale Risk","A purchase of the group in scope within 30 days would disallow the loss"),("No Suitable Replacement","No replacement outside the security group is available"),("Transaction Cost Exceeds Saving",""),("Client Not Elected","Tax-loss harvesting not elected"),("Restriction","A constraint prevents the sale or the replacement purchase"),("Year-End Freeze","Firm policy freezes harvesting at year end")]),
 "Tax Saving Method": ("Internal / SEC IM Guidance Update 2017-02 (disclosure of assumptions)", [("Client Marginal Rate","Loss times the applied federal marginal rate, by term"),("Flat Assumed Rate","Loss times a firm-wide assumed rate"),("Gain Offset","Saving on gains realized year to date only")]),
 "Security Group Basis": ("Internal / IRS Publication 550 (substantially identical property)", [("Same Issuer Security","Shares of the same issuer and class"),("Same Index Tracked","Funds or ETFs tracking the same index"),("Share Classes of One Fund","Classes of the same fund"),("Tax Counsel Determination","Grouped on tax counsel's advice")]),
 "Wash Sale Window Status": ("Internal", [("Open","Window running; purchases blocked"),("Closed","Window ended without a wash sale"),("Wash Sale Incurred","A purchase in scope occurred in the window (for example a dividend reinvestment or a purchase in a monitored account); the basis adjustment is recorded on the 49 Client Tax Lot"),("Canceled","Loss sale canceled or corrected")]),
 "Asset Location Basis": ("Internal / IRS Publication 550", [("Ordinary Income Yield","Interest taxed as ordinary income placed in tax-deferred accounts"),("Qualified Dividend Treatment",""),("Expected Growth","High-growth assets placed in tax-exempt accounts"),("Tax-Exempt Income","Municipal bonds placed in taxable accounts"),("Foreign Tax Credit Eligibility","Foreign equity placed in taxable accounts so the foreign tax credit can be claimed")]),
 # Trade Proposals
 "Batch Status": ("Internal", [("Generated",""),("In Review","Exceptions or sample review open"),("Released","Sent for order creation"),("Partially Released","Some proposals held back"),("Canceled","")]),
 "Proposal Reason": ("Internal", [("Rebalance",""),("Tax-Loss Harvest",""),("Harvest Replacement","Purchase of the replacement security"),("Cash Raise",""),("Cash Invest",""),("Restriction Implementation",""),("Model Change","")]),
 "Proposal Status": ("Internal", [("Proposed",""),("Exception","Failed a pre-trade check"),("Approved",""),("Released","Handed to 48 or 16; last status held here"),("Canceled","")]),
 "Proposal Execution Route": ("Internal", [("Brokerage Client Order","Released as a 48 client order"),("Participant Investment Transfer","Participant managed account: released as a 16 participant investment transfer, which 16 nets into the plan-level 29 fund order")]),
 "Pre-Trade Check Type": ("Internal / Advisers Act section 206(3)", [("Account Investment Constraint",""),("Wash Sale Window",""),("Minimum Trade",""),("Insufficient Cash",""),("Account Restriction","15 account restriction or freeze"),("Principal Trade","Trade with the adviser's or a controlled affiliate's own account (here the affiliated broker-dealer); needs written disclosure and consent under section 206(3)"),("Agency Cross Trade","Trade crossed with another client; Rule 206(3)-2 conditions"),("Excessive Turnover","Turnover above the program's limit")]),
 "Exception Outcome": ("Internal", [("Proposal Blocked",""),("Proposal Adjusted","Quantity or instrument changed"),("Overridden","Released after approval"),("Deferred","Carried to a later cycle")]),
 # Cash Management
 "Cash Instruction Type": ("Internal", [("Raise for Withdrawal",""),("Invest Deposit",""),("Raise for Fee Payment","47 fee debit"),("Raise for RMD","15 RMD record; IRC section 401(a)(9)"),("Raise for Transfer Out","Cash needed before an account transfer"),("Maintain Cash Reserve","Restore the account's cash target")]),
 "Cash Instruction Status": ("Internal", [("Received",""),("Proposals Generated",""),("Proposals Released",""),("Cash Available","Proceeds settled and available in 49"),("Invested",""),("Canceled","")]),
 # Composites
 "Composite Membership Rule": ("GIPS 2020 / Internal", [("Discretionary","Full or limited discretion"),("Fully Invested","Invested to the model within tolerance"),("Minimum Account Value",""),("No Material Restrictions","No constraint that prevents the account from representing the model"),("Taxable Only",""),("Tax-Deferred Only","")]),
 "Composite Exclusion Reason": ("GIPS 2020 / Internal (first four values aligned with 32's list of the same name; candidate shared list)", [("Below Minimum Size","Account value below the composite minimum account value"),("Non-Discretionary","Discretion removed, or a constraint prevents the account from representing the model"),("Strategy or Mandate Change","Account moved to another model or program"),("Terminated","Account closed or left the program"),("Significant Cash Flow","Removed for the period under the significant cash flow policy"),("Not Fully Invested","Not yet invested to the model within tolerance")]),
}

# ---------------------------------------------------------------------------
REL = [
 ("Program Enrollment [15]","is managed under","Model Assignment","1 : 0..n","One active assignment at a time; the enrollment carries the program (01 OFFR-) and the discretionary authority (CW-031)."),
 ("Model Assignment","assigns","Model Portfolio [01]","n : 1","The model offered; weights are 24."),
 ("Model Assignment","applies to","Account [15]","n : 1",""),
 ("Model Assignment","follows","Recommendation [45]","n : 0..1","Rationale and best-interest evidence stay in 45."),
 ("Model Assignment","replaces","Model Assignment","0..1 : 0..1","Model change history of an account."),
 ("Model Assignment","is split into","Sleeve Assignment","1 : 0..n","Multi-sleeve accounts only."),
 ("Sleeve Assignment","follows","Model Portfolio [01]","n : 1","Sleeve model; its weight is read from the 24 target set of the account's multi-sleeve model."),
 ("Sleeve Assignment","is managed under","Sub-Adviser Engagement [52]","n : 0..1","Sub-advised sleeves."),
 ("Tax Management Setting","describes","Model Assignment","1 : 1","Attribute group."),
 ("Tax Management Setting","reads tax status of","Investor Profile [02]","n : 0..1","Applied rate is a Derived copy."),
 ("Household Managed Group","groups accounts of","Party (Household) [02]","n : 1","Not the 13 Mailing Household or the 47 Fee Household."),
 ("Model Assignment","is targeted by","Managed Account Target","1 : 1..n","Versioned."),
 ("Managed Account Target","applies","Target Allocation Set [24]","n : 1","Weights read from 24, never copied (CW-047)."),
 ("Managed Account Target","is adjusted by","Account Target Override Line","1 : 0..n",""),
 ("Account Investment Constraint","applies to","Account [15]","n : 1",""),
 ("Account Investment Constraint","implements","Client Restriction [02]","n : 0..1","Rule 3a-4 reasonable restriction."),
 ("Account Investment Constraint","implements","Trust Term Provision [51]","n : 0..1","Fiduciary accounts."),
 ("Rebalance Trigger Rule","applies to","Service Offering [01] / Model Portfolio [01]","n : 1",""),
 ("Drift Assessment","compares","Managed Account Target","n : 1",""),
 ("Drift Assessment","reads","Client Holding [49]","n : n","Derived copies as of Holdings As-Of Timestamp."),
 ("Drift Assessment","has","Drift Assessment Line","1 : 1..n","One line per asset class."),
 ("Account Rebalance Event","is triggered by","Drift Assessment / Model Change Implementation / Managed Account Cash Instruction","n : 0..1",""),
 ("Account Rebalance Event","proposes in","Trade Proposal Batch","n : 0..1","Skipped events have no batch."),
 ("Model Change Implementation","moves accounts from and to","Target Allocation Set [24]","n : 2","From and to versions."),
 ("Account Tax Budget","limits","Account Rebalance Event / Tax-Loss Harvest Decision","1 : 0..n","Per account and tax year."),
 ("Tax-Loss Harvest Decision","sells","Client Tax Lot [49]","n : 1..n","Never 18 LOT- (CW-048)."),
 ("Tax-Loss Harvest Decision","opens","Wash Sale Control Window","1 : 0..1","IRC section 1091."),
 ("Wash Sale Control Window","blocks purchases of","Substantially Identical Security Group","n : 1",""),
 ("Wash Sale Control Window","covers","Account [15]","n : 1..n","Controlled (blocked) and monitored (flagged) accounts of the seller and spouse, including IRAs (Rev. Rul. 2008-5)."),
 ("Asset Location Decision","places in","Account [15]","n : 1","Within a household managed group."),
 ("Trade Proposal Batch","is generated by","Model Inventory Entry [37]","n : 1","Rebalancing engine (CW-057)."),
 ("Trade Proposal Batch","contains","Trade Proposal","1 : 1..n",""),
 ("Trade Proposal","is sourced from","Account Rebalance Event / Tax-Loss Harvest Decision / Managed Account Cash Instruction","n : 1",""),
 ("Trade Proposal","is released as","Client Order [48]","1 : 0..1","Proposal ends at release (CW-049)."),
 ("Trade Proposal","is released into","Participant Investment Transfer [16]","n : 1","Participant managed accounts: many proposals net into one transfer; 16 nets transfers into the plan-level 29 Fund Order. Held on the 46 side only (16 review ruling)."),
 ("Trade Proposal","relieves","Client Tax Lot [49] via Proposed Client Lot Selection","1 : 0..n","Sales only."),
 ("Trade Proposal","raises","Trade Proposal Exception","1 : 0..n","Includes section 206(3) principal and cross trade checks."),
 ("Managed Account Cash Instruction","serves","Account Standing Instruction [15] / RMD Record [15]","n : 0..1",""),
 ("Money Movement [50]","is sourced from","Managed Account Cash Instruction","n : 0..1","Link held once, on the 50 side (MMVMT- references CSHI-)."),
 ("Fee Debit [47]","raises","Managed Account Cash Instruction","0..1 : 0..1","Link held once, on the 47 side (Fee Debit.Cash Raise Instruction)."),
 ("Managed Account Composite","groups accounts of","Service Offering [01] / Model Portfolio [01]","n : 1",""),
 ("Managed Account Composite","is presented as","GIPS Composite [01]","n : 0..1","Only under the wrap-composite lever (advice programs sit outside the GIPS firm by default); 32 Composite Period Statistic counts the 46 members only under the lever."),
 ("Managed Account Composite Membership","places","Account [15]","n : 1","Effective dated; 32 computes returns (W3)."),
 ("Account Rebalance Event / Trade Proposal","is surveilled by","Sales Practice Alert [08]","n : 0..n","Reverse churning and drift exception review (08 brief)."),
]

# ---------------------------------------------------------------------------
SRC = [
 ("Investment Company Act Rule 3a-4 (status of investment advisory programs) and adopting release IC-22579 (1997)","US SEC","https://www.ecfr.gov/current/title-17/section-270.3a-4","Regulation (public)","Individualized management on the basis of the client's financial situation and objectives, reasonable restrictions, annual contact, quarterly notice, client retains indicia of ownership; adopting release IC-22579 / IA-1623 (March 24, 1997; 62 FR 15098) at https://www.sec.gov/rules/final/ic-22579.txt","Model Assignment, Account Investment Constraint, Account Target Override Line, Household Managed Group",["ICA Rule 3a-4"]),
 ("Form ADV Part 1A (Item 5.F regulatory assets under management) and instructions; Part 2A Appendix 1 (wrap fee program brochure)","US SEC","https://www.sec.gov/about/forms/formadv-part2.pdf","Form and instructions (public; confirm paths)","Discretionary and non-discretionary regulatory AUM; continuous and regular supervisory or management services; program description","Model Assignment (Regulatory AUM Classification, Discretion Exercised), Sleeve Assignment",["SEC Form ADV"]),
 ("Investment Advisers Act section 206(3) (15 U.S.C. 80b-6) and Rule 206(3)-2 (agency cross transactions)","US Congress / US SEC","https://www.ecfr.gov/current/title-17/section-275.206(3)-2","Statute and regulation (public)","Written disclosure and client consent for principal trades; conditions for agency cross transactions (temporary Rule 206(3)-3T expired on December 31, 2016 and was not extended)","Trade Proposal Exception, Pre-Trade Check Type",["Advisers Act Section 206(3)","SEC Rule 206(3)-2"]),
 ("Advisers Act Rule 206(4)-7 (compliance programs) and Rule 204-2 (books and records)","US SEC","https://www.ecfr.gov/current/title-17/section-275.206(4)-7","Regulation (public)","Policies over rebalancing, trading and allocation; records of orders given and of the basis of trading decisions","Rebalance Trigger Rule, Managed Account Target, Account Rebalance Event, Trade Proposal Batch, Trade Proposal",["SEC Rule 206(4)-7","SEC Rule 204-2"]),
 ("Internal Revenue Code section 1091 (wash sales) and Treas. Reg. 1.1091-1","US Congress / US Treasury (via Legal Information Institute)","https://www.law.cornell.edu/uscode/text/26/1091","Statute and regulation (public)","61-day window (30 days before and after the loss sale), substantially identical stock or securities, disallowed loss and basis adjustment","Wash Sale Control Window, Substantially Identical Security Group, Tax-Loss Harvest Decision",["IRC Section 1091","Treas. Reg. 1.1091-1"]),
 ("Rev. Rul. 2008-5, 2008-3 I.R.B. 271","US IRS","https://www.irs.gov/irb/2008-03_IRB","Revenue ruling (public)","A purchase in the taxpayer's own IRA or Roth IRA within the window makes the taxable-account loss sale a wash sale, and the IRA basis is not increased; with IRS Publication 550 (spouse purchases), the legal scope of the window","Wash Sale Control Window (Controlled and Monitored Accounts in Scope), Household Managed Group",["Rev. Rul. 2008-5"]),
 ("IRS Publication 550 Investment Income and Expenses","US IRS","https://www.irs.gov/publications/p550","Public guidance","Capital gains and losses, holding periods, wash sales and substantially identical property, specific identification of shares","Account Tax Budget, Tax-Loss Harvest Decision, Asset Location Decision, Security Group Basis",["IRS Publication 550","IRS Form 8949"]),
 ("Internal Revenue Code section 1222 (short-term and long-term capital gain)","US Congress (via Legal Information Institute)","https://www.law.cornell.edu/uscode/text/26/1222","Statute (public)","Holding period terms","Holding Period Term, Account Tax Budget, Tax Management Setting",["IRC Section 1222"]),
 ("Internal Revenue Code section 6045 (broker reporting) and Treas. Reg. 1.1012-1(c) (specific identification)","US Congress / US Treasury","https://www.ecfr.gov/current/title-26/section-1.1012-1","Statute and regulation (public)","Adequate identification of lots at the time of sale; broker cost basis reporting on Form 1099-B (the lot record is 49)","Proposed Client Lot Selection, Tax Management Setting (Managed Sale Lot Selection Method)",["IRC Section 6045","Treas. Reg. 1.1012-1"]),
 ("Internal Revenue Code section 401(a)(9) (required minimum distributions)","US Congress (via Legal Information Institute)","https://www.law.cornell.edu/uscode/text/26/401","Statute (public)","RMD cash raises (the RMD record is 15)","Managed Account Cash Instruction",["IRC Section 401(a)(9)"]),
 ("SEC Division of Investment Management Guidance Update 2017-02 (robo-advisers)","US SEC","https://www.sec.gov/investment/im-guidance-2017-02.pdf","Public guidance (confirm path)","Disclosure of the algorithm, rebalancing and tax-loss-harvesting features and their limits; suitability of automated advice","Tax Management Setting, Rebalance Trigger Rule, Tax Saving Method",["SEC IM Guidance 2017-02"]),
 ("SEC Division of Examinations Risk Alert: Observations from Examinations of Advisers that Provide Electronic Investment Advice (November 9, 2021)","US SEC","https://www.sec.gov/files/exams-eia-risk-alert.pdf","Examination observations (public)","Portfolio management and fiduciary obligations of robo-advisers, reliance on Rule 3a-4, tax-loss-harvesting disclosures","Tax-Loss Harvest Decision, Model Assignment",["SEC EIA Risk Alert 2021"]),
 ("SEC Division of Examinations Risk Alert: Observations from Examinations of Investment Advisers Managing Client Accounts That Participate in Wrap Fee Programs (July 21, 2021)","US SEC","https://www.sec.gov/exams/announcement/risk-alert-wrap-fee-programs","Examination observations (public)","Monitoring of trading activity and suitability of wrap accounts (reverse churning), policies for trading away and best execution","Account Rebalance Event, Rebalance Decision",["SEC Wrap Fee Risk Alert 2021"]),
 ("Global Investment Performance Standards (GIPS) 2020 for Firms","CFA Institute","https://www.gipsstandards.org","Industry standard (public)","Composite construction, discretion, minimum asset levels, significant cash flow policy, membership timing","Managed Account Composite, Managed Account Composite Membership",["GIPS 2020"]),
 ("Federal Reserve / OCC SR 11-7 Supervisory Guidance on Model Risk Management","Board of Governors of the Federal Reserve System","https://www.federalreserve.gov/supervisionreg/srletters/sr1107.htm","Supervisory guidance (public)","Model inventory and validation context for rebalancing and asset location engines (governed in 37)","Trade Proposal Batch, Asset Location Decision",["SR 11-7"]),
 ("Uniform Prudent Investor Act","Uniform Law Commission","https://www.uniformlaws.org","Model act (public; confirm the act page)","Trust investment duties read through 51 trust terms","Account Investment Constraint (Source Trust Term Provision)",["Uniform Prudent Investor Act"]),
 ("FIX Protocol (NewOrderSingle, Side, OrderQty, CashOrderQty)","FIX Trading Community","https://www.fixtrading.org","Industry standard (public)","Side, quantity and cash amount of the proposal handed to the order system","Trade Proposal",["FIX Protocol"]),
 ("GICS Global Industry Classification Standard","MSCI / S&P Dow Jones Indices","https://www.msci.com/our-solutions/indexes/gics","Industry classification (licensed)","Sector and industry codes for sector exclusions","Account Investment Constraint (Constrained Classification Value)",["GICS"]),
 ("NACHA Operating Rules","Nacha","https://www.nacha.org/rules","Industry rules (members)","ACH withdrawals and deposits behind money movements (50)","Managed Account Cash Instruction (through the 50 money movement that references it)",["NACHA Operating Rules"]),
 ("Rebalancing and tax overlay platform documentation: Envestnet, Orion, Vestmark, Aladdin Wealth","Vendors","https://www.vestmark.com","Vendor documentation (public; confirm paths)","Cross-check of model assignment, sleeve, drift, tolerance band, harvest threshold and household structures only","Sleeve Assignment, Managed Account Target, Tax Management Setting, Account Investment Constraint",["Envestnet","Orion","Vestmark","Aladdin Wealth"]),
 ("Salesforce Financial Services Cloud household model","Salesforce","https://developer.salesforce.com/docs/platform/data-models/guide/fsc-customer.html","Vendor documentation (public; confirm path)","Household grouping cross-check","Household Managed Group",["Salesforce FSC"]),
 ("SEC Regulation Best Interest (Exchange Act Rule 15l-1) and the Advisers Act fiduciary interpretation (IA-5248)","US SEC","https://www.ecfr.gov/current/title-17/section-240.15l-1","Regulation and interpretation (public)","Context for the 45 recommendation an assignment follows; not re-mastered here","Model Assignment (Source Recommendation)",["SEC Reg BI","Advisers Act fiduciary interpretation"]),
 ("FINRA Rule 2111 Suitability; SEC Rule 17a-3","FINRA / US SEC","https://www.finra.org/rules-guidance/rulebooks/finra-rules/2111","Rules (public)","Tax status as an element of the investment profile (02); books and records behind the Client Holding view read (49)","Tax Management Setting (Tax Rate Source Profile), Drift Assessment",["FINRA Rule 2111","SEC Rule 17a-3"]),
]
