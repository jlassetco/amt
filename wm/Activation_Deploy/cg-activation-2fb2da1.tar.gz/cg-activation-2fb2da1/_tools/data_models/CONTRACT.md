# Logical data model standard

Each data product's logical model shows how its inputs fit together as entities, keys and relationships. It is logical, not physical: it carries no table names, data-platform types, indexes or partitions.

It is built from two layers:

1. **Shared key and link registry** (`keys.py`). This is defined once per taxonomy object and reused by every model:
   - each object's primary key
   - whether each Attribute Group folds into its parent or becomes a child entity
   - the target object of each `Reference (...)` attribute
2. **Product models** (`models_*.py`). One `MODELS[pid]` per data product, assembling that product's input objects into entities and relationships.

`dm_model.py` validates both layers against the consolidated taxonomy and the product specs. `build_data_models.py` publishes them.

## Modeling style

| Product tier | Style | Shape |
|---|---|---|
| Foundational | `ER` (normalized) | One entity per core business object, with child entities for repeating detail and relationships following the registry's links. |
| Consumer-aligned | `Star` | One or more **Fact** entities at the product's grain, joined to **Dimension** entities. Use **Bridge** entities only for many-to-many links, such as credit splits. |

Use the same dimension name for the same concept in every product, e.g. "Distributor", "Territory", "Share Class", "Salesperson", "Reporting Period". This keeps star schemas conformed across products.

## 1. Key and link registry: `keys.py`

```python
KEYS = {("NN", "Object"): dict(pk=[...], key_type="Natural" | "Composite" | "Surrogate", fold=None | True | False, note="")}
REFS = {("NN", "Object", "Reference attribute"): ("NN", "Target Object")}
```

**Business Objects**
- `pk` lists attribute names of the object, usually its ID attribute.
- When the object has no single identifier, use the attributes its grain names (`Composite`).
- When nothing in the object identifies a row, use `["<Object> Key"]` (`Surrogate`).
- `fold` is `None`.

**Attribute Groups**
- `fold=True` when the group's grain is its parent's grain (one row per parent). The group's attributes become columns of the parent entity, and `pk` is `[]`.
- `fold=False` when the grain repeats within the parent, e.g. "attribution record x credited salesperson". The group becomes a child entity. Its key is the parent key plus the attributes named in `pk` (the discriminator).

**References**
- `REFS` maps each `Reference (...)` attribute to the object it points to.
- Point to the mastering object, e.g. Distributor Firm points to `("02", "Party")` or to the specific 02 object that masters it.
- Leave out references to objects outside the taxonomy.

## 2. Product models: `models_*.py`

```python
MODELS = {"DP-nnn": dict(
    style="ER" | "Star",
    entities=[dict(name="Fact Flow & AUM", role="Fact" | "Dimension" | "Bridge" | "Entity",
                   objects=[("06", "Measure Value"), ("06", "Flow Measures")],   # product input objects held by this entity
                   pk=["Measure", "Period End Date"],   # attribute names held by the entity, or "<Entity name> Key"
                   grain="one row = ...", measures=False, note="")],
    relationships=[dict(child="Fact Flow & AUM", parent="Distributor", fk=["Distributor Firm"],
                        card="M:1" | "1:1" | "M:N", optional=False, note="")],
    notes="")}
```

**Entities**
- Every product input object appears in exactly one entity's `objects`. An entity's attributes are the product's input attributes from those objects.
- Put the product's measures on one entity by setting `measures=True` (usually the main Fact). They appear there as derived attributes.

**Relationships**
- `fk` names child-entity attributes that carry the parent's key.
- When the parent has a surrogate key, write `"<Parent name> Key"`. It is added to the child as a foreign-key attribute.
- A child whose own attributes don't identify its parent may borrow the parent's key the same way, and list `"<Parent name> Key"` in its `pk`.
- A product measure with the same name as an input attribute on that entity is published once, as the input attribute.
- The model must be connected: every entity is reachable from every other through relationships.
- Where `REFS` says an `fk` attribute points to object X, the parent entity should hold X.

## Conformed (shared) dimensions

A consumer model should not rebuild a dimension that a foundational product already models. Instead, declare it as conformed:

```python
dict(name="Salesperson", role="Dimension", conformed=("DP-009", "Employee"), objects=[])
```

- The entity inherits every attribute and the primary key of the named entity in the source product's model.
- The source product must be in the consumer's spec `upstream`.
- `_conformed.txt` lists every foundational entity available for reuse. Regenerate it with `python data_models/dm_model.py --conformed`.
- Relationships to a conformed dimension use the same `fk` rules as any other entity.
- A conformed entity may also list product input objects in `objects`, typically the same concept. Their attributes merge with the inherited ones without duplicates.

## Rules

1. Model only what the product's spec inputs contain.
   - If the model needs an object the spec lacks, add it to the spec first.
   - If no attribute can carry a key or link, use a surrogate key and record a "Model gap:" in the notes.
2. Prefer conformed dimension names and keys that other products can share.
3. Write `grain` for every Fact and Bridge entity.
4. Use US spelling and plain language. Notes say why a modeling choice was made, not what the code does.
5. Validate before finishing: run `python data_models/dm_model.py` from `_tools/`.

**Models of products pending WP0 re-scope (wealth-manager branch, CW-041).** The model of a product in `framework.RESCOPE_PENDING` stays in its `models_*.py` file but is not validated, built or shown; `dm_model.py` still assembles it so that nothing else breaks while it waits. A live model should not take a conformed entity from a pending product's model: `dm_model.py` warns "live product X depends on pending product Y; re-point at WP0; CW-041" until the entity is conformed from a live foundational model instead.
