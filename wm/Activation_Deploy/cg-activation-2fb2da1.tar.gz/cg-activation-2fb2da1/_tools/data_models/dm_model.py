"""Loads the key and link registry (keys.py) and the product logical models (models_*.py), validates them against the
consolidated taxonomy and the data product specs, and assembles each model into entities, attributes and relationships.

Usage (from _tools/):
  python data_models/dm_model.py                 validate keys.py and every models_*.py
  python data_models/dm_model.py --keys-for DP-001 DP-008 ...   list the objects (and reference attributes) those
                                                 products need in keys.py, marking what is missing
"""
import importlib, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(HERE)
for p in (TOOLS, HERE, os.path.join(TOOLS, "data_products")):
    sys.path.insert(0, p)
sys.dont_write_bytecode = True

from taxonomy_builder import CONTENT, Consolidated, load_consolidation, model  # noqa: E402
import dp_model  # noqa: E402
import framework as fw  # noqa: E402

ROLES = {"Fact", "Dimension", "Bridge", "Entity"}
CARDS = {"M:1", "1:1", "M:N"}
STYLES = {"ER", "Star"}


def load_keys():
    """Merge KEYS and REFS from keys.py and every keys_*.py; returns (KEYS, REFS, duplicates)."""
    KEYS, REFS, dup = {}, {}, []
    files = ["keys"] + sorted(x[:-3] for x in os.listdir(HERE) if x.startswith("keys_") and x.endswith(".py"))
    for f in files:
        if not os.path.exists(os.path.join(HERE, f + ".py")):
            continue
        mod = importlib.import_module(f)
        for src, dst in ((mod.KEYS, KEYS), (getattr(mod, "REFS", {}), REFS)):
            for k, v in src.items():
                if k in dst:
                    dup.append(k)
                dst[k] = v
    return KEYS, REFS, dup


def load_parents():
    scl, par = load_consolidation(), {}
    for f in sorted(os.listdir(CONTENT)):
        if f.startswith("content_") and f.endswith(".py"):
            m = Consolidated(importlib.import_module(f[:-3]), scl)
            n = m.__name__.split("_")[1]
            for fam in model(m):
                for o in fam["objects"]:
                    par[(n, o["name"])] = o["parent"]
    return par


def load_all():
    objs = dp_model.load_taxonomy()
    for k, p in load_parents().items():
        objs[k]["parent"] = p
    specs, _, _ = dp_model.load_specs()
    KEYS, REFS, dup = load_keys()
    if dup:
        raise SystemExit("keys defined in more than one registry file: " + ", ".join(map(str, dup[:10])))
    models, where = {}, {}
    for f in sorted(x[:-3] for x in os.listdir(HERE) if x.startswith("models_") and x.endswith(".py")):
        for pid, m in importlib.import_module(f).MODELS.items():
            models[pid], where[pid] = m, f
    return objs, specs, KEYS, REFS, models


def parent_key(objs, k):
    """The business object an Attribute Group describes, in the same Data Domain."""
    p = objs[k].get("parent")
    return (k[0], p) if p and (k[0], p) in objs else None


def validate_keys(objs, KEYS, REFS):
    errs, warns = [], []
    for k, v in KEYS.items():
        if k not in objs:
            errs.append(f"keys: unknown object {k}"); continue
        o = objs[k]
        if v.get("key_type") not in ("Natural", "Composite", "Surrogate"):
            errs.append(f"keys {k}: key_type must be Natural, Composite or Surrogate")
        for a in v.get("pk", []):
            if a not in o["attrs"] and a != f"{k[1]} Key":
                errs.append(f"keys {k}: pk attribute '{a}' not in object (surrogate must be '{k[1]} Key')")
        if o["kind"] == "Attribute Group":
            if v.get("fold") not in (True, False):
                errs.append(f"keys {k}: Attribute Group needs fold=True or False")
            if v.get("fold") is True and v.get("pk"):
                errs.append(f"keys {k}: folded group must have pk=[]")
            if v.get("fold") is False and not v.get("pk"):
                errs.append(f"keys {k}: child group needs discriminator pk attributes")
            if not parent_key(objs, k):
                warns.append(f"keys {k}: parent object '{o.get('parent')}' not resolved in domain {k[0]}")
        else:
            if v.get("fold") is not None:
                errs.append(f"keys {k}: fold applies only to Attribute Groups")
            if not v.get("pk"):
                errs.append(f"keys {k}: business object needs a pk")
    for (n, on, a), tgt in REFS.items():
        if (n, on) not in objs or a not in objs[(n, on)]["attrs"]:
            errs.append(f"refs: unknown attribute {(n, on, a)}")
        elif not objs[(n, on)]["attrs"][a]["type"].startswith("Reference"):
            warns.append(f"refs {(n, on, a)}: attribute is not a Reference type")
        if tgt not in objs:
            errs.append(f"refs {(n, on, a)}: unknown target {tgt}")
    return errs, warns


LENIENT = False      # --models: a conformed source model that is not loaded (a sibling agent's file) is a warning, not an error


def assemble(pid, m, objs, specs, KEYS, REFS, done=None):
    """Resolve a model into entities with attributes. Returns (model dict, errors, warnings)."""
    errs, warns = [], []
    spec = specs.get(pid)
    if not spec:
        return None, [f"{pid}: no product spec"], []
    reg = {p[0]: p for p in fw.PRODUCTS}
    if m.get("style") not in STYLES:
        errs.append(f"{pid}: style must be ER or Star")
    elif m["style"] == "Star" and reg[pid][2] == "Foundational":
        warns.append(f"{pid}: foundational product modeled as Star (standard is ER)")
    inputs = {(n, on): an for n, on, an in spec["inputs"]}
    placed, ents = {}, {}
    for e in m.get("entities", []):
        name = e.get("name")
        if not name or name in ents:
            errs.append(f"{pid}: entity name missing or duplicated: {name!r}"); continue
        if e.get("role") not in ROLES:
            errs.append(f"{pid}: {name}: role must be one of {sorted(ROLES)}")
        attrs, conf_objs = [], []
        if e.get("conformed"):
            src_pid, src_ent = e["conformed"]
            src = (done or {}).get(src_pid)
            srce = next((x for x in src["entities"] if x["name"] == src_ent), None) if src else None
            if not srce and LENIENT and not src and src_pid in reg:
                warns.append(f"{pid}: {name}: conformed source {src_pid} is not loaded in this check (another module); its attributes are not inherited here")
                if not e.get("pk"):
                    e = dict(e, pk=[f"{name} Key"])      # placeholder until the source is loaded; the full run inherits the real key
            elif not srce:
                errs.append(f"{pid}: {name}: conformed source {src_pid} '{src_ent}' is not a modeled entity"); 
            else:
                if src_pid not in spec["upstream"]:
                    warns.append(f"{pid}: {name}: conformed from {src_pid}, which is not in the product's upstream")
                attrs = [dict(x, fk="") for x in srce["attrs"] if not x["derived"] and x["type"] != "Foreign key"]
                conf_objs = srce["objects"]
                if not e.get("pk"):
                    e = dict(e, pk=[x["name"] for x in srce["attrs"] if x["pk"] and x["type"] != "Foreign key"])
                for x in attrs:
                    x["pk"] = False
        for k in e.get("objects", []):
            k = tuple(k)
            if k not in inputs:
                errs.append(f"{pid}: {name}: object {k} is not a product input"); continue
            if k in placed:
                errs.append(f"{pid}: object {k} placed in both {placed[k]} and {name}")
            placed[k] = name
            if k not in objs:
                errs.append(f"{pid}: {name}: input object {k} is not in the consolidated taxonomy"); continue
            for a in inputs[k]:
                if any(y["obj"] == k and y["name"] == a for y in attrs):
                    continue                  # already inherited from the conformed source
                if a not in objs[k]["attrs"]:
                    errs.append(f"{pid}: {name}: input attribute '{a}' is not in {k}"); continue
                x = objs[k]["attrs"][a]
                attrs.append({"name": a, "obj": k, "type": x["type"], "cde": x["cde"], "pii": x["pii"], "def": x["def"],
                              "id": x["id"], "pk": False, "fk": "", "derived": False})
        if e.get("measures"):
            for mn, md, _ in spec["measures"]:
                same = next((x for x in attrs if x["name"] == mn), None)
                if same:                      # the input already carries this measure; publish it once
                    same["derived"] = True
                    continue
                attrs.append({"name": mn, "obj": None, "type": "Derived measure", "cde": False, "pii": False, "def": md,
                              "id": "", "pk": False, "fk": "", "derived": True})
        names = {a["name"] for a in attrs}
        for a in e.get("pk", []):
            if a.endswith(" Key") and a != f"{name} Key" and a not in names:
                continue                      # a parent's surrogate/borrowed key; resolved after relationships
            if a == f"{name} Key":
                attrs.insert(0, {"name": a, "obj": None, "type": "Surrogate key", "cde": False, "pii": False,
                                 "def": f"Surrogate key of {name}.", "id": "", "pk": True, "fk": "", "derived": False})
            elif a in names:
                next(x for x in attrs if x["name"] == a)["pk"] = True
            else:
                errs.append(f"{pid}: {name}: pk '{a}' is not an attribute of the entity (or '{name} Key')")
        if not e.get("pk"):
            errs.append(f"{pid}: {name}: no pk")
        if e.get("role") in ("Fact", "Bridge") and not e.get("grain"):
            errs.append(f"{pid}: {name}: Fact/Bridge entity needs a grain")
        # registry checks: folded groups should sit with their parent
        for k in e.get("objects", []):
            k = tuple(k)
            kv = KEYS.get(k)
            if k not in objs:
                continue                      # reported above
            if kv is None:
                warns.append(f"{pid}: {k} has no entry in keys.py"); continue
            pk_ = parent_key(objs, k)
            if objs[k]["kind"] == "Attribute Group" and kv.get("fold") and pk_ in inputs and placed.get(pk_, name) != name:
                warns.append(f"{pid}: folded group {k[1]} is not in the same entity as its parent {pk_[1]}")
        ents[name] = {"name": name, "role": e.get("role"), "grain": e.get("grain", ""), "note": e.get("note", ""),
                      "objects": list(dict.fromkeys([tuple(k) for k in e.get("objects", [])] + list(conf_objs))), "attrs": attrs,
                      "conformed": list(e["conformed"]) if e.get("conformed") else None}
    for k in inputs:
        if k not in placed:
            errs.append(f"{pid}: input object {k} is not placed in any entity")
    rels = []
    for r in m.get("relationships", []):
        c, p = r.get("child"), r.get("parent")
        if c not in ents or p not in ents:
            errs.append(f"{pid}: relationship {c} -> {p}: unknown entity"); continue
        if r.get("card") not in CARDS:
            errs.append(f"{pid}: relationship {c} -> {p}: card must be one of {sorted(CARDS)}")
        if not r.get("fk"):
            errs.append(f"{pid}: relationship {c} -> {p}: fk required")
        for a in r.get("fk", []):
            ch = ents[c]["attrs"]
            hit = next((x for x in ch if x["name"] == a), None)
            if hit:
                hit["fk"] = p
                tgt = REFS.get((*hit["obj"], a)) if hit["obj"] else None
                if tgt and tgt not in ents[p]["objects"]:
                    warns.append(f"{pid}: fk {c}.{a} -> {p}, but keys.REFS points it to {tgt[1]}")
            elif a == f"{p} Key":
                ch.insert(0, {"name": a, "obj": None, "type": "Foreign key", "cde": False, "pii": False,
                              "def": f"Key of {p}.", "id": "", "pk": False, "fk": p, "derived": False})
            else:
                errs.append(f"{pid}: relationship {c} -> {p}: fk '{a}' is not an attribute of {c} (or '{p} Key')")
        rels.append({"child": c, "parent": p, "fk": r.get("fk", []), "card": r.get("card"),
                     "optional": bool(r.get("optional")), "note": r.get("note", "")})
    # primary keys that borrow a parent's key ("<Parent> Key") must be carried by a relationship
    for e in m.get("entities", []):
        en = ents.get(e.get("name"))
        if not en:
            continue
        for a in e.get("pk", []):
            if a.endswith(" Key") and a != f"{en['name']} Key":
                hit = next((x for x in en["attrs"] if x["name"] == a), None)
                if hit:
                    hit["pk"] = True
                elif a not in {x["name"] for x in en["attrs"]}:
                    errs.append(f"{pid}: {en['name']}: pk '{a}' is not carried by any relationship fk")
    # connectivity
    if ents:
        adj = {n: set() for n in ents}
        for r in rels:
            adj[r["child"]].add(r["parent"]); adj[r["parent"]].add(r["child"])
        seen, todo = set(), [next(iter(ents))]
        while todo:
            x = todo.pop()
            if x not in seen:
                seen.add(x); todo += adj[x] - seen
        if len(seen) != len(ents):
            errs.append(f"{pid}: model is not connected; unreachable: {sorted(set(ents) - seen)}")
    if m.get("style") == "Star":
        if not any(e["role"] == "Fact" for e in ents.values()):
            errs.append(f"{pid}: Star model has no Fact entity")
    if not any(e.get("measures") for e in m.get("entities", [])):
        warns.append(f"{pid}: product measures are not placed on any entity (set measures=True)")
    return {"pid": pid, "style": m.get("style"), "entities": list(ents.values()), "relationships": rels,
            "notes": m.get("notes", "")}, errs, warns


def pending_deps(models):
    """Warnings (until WP0) for live models that reuse a conformed entity from the model of a product pending WP0
    re-scope (CW-041)."""
    errs = []
    for pid, m in models.items():
        if dp_model.is_pending(pid):
            continue
        for e in m.get("entities", []):
            src = (e.get("conformed") or (None,))[0]
            if src and dp_model.is_pending(src):
                errs.append(f"{pid}: " + dp_model.PENDING_DEP.format(pid=pid, up=src, dec=dp_model.PENDING[src])
                            + f" (conformed entity '{e['conformed'][1]}' in {e.get('name')})")
    return errs


def validate():
    """(live models, errors, warnings). Models of products pending WP0 re-scope (CW-041) are assembled only so that a
    live model's conformed entities still resolve; their errors and warnings are dropped and they are not returned."""
    objs, specs, KEYS, REFS, models = load_all()
    errs, warns = validate_keys(objs, KEYS, REFS)
    warns += pending_deps(models)
    out, pending = {}, dict(models)
    deps = {pid: {e["conformed"][0] for e in m.get("entities", []) if e.get("conformed")} for pid, m in models.items()}
    while pending:
        ready = [p for p in pending if not (deps[p] - set(out)) or not (deps[p] & set(pending))]
        if not ready:
            errs.append("conformed-dimension cycle among: " + ", ".join(sorted(pending))); break
        for pid in ready:
            a, e, w = assemble(pid, pending.pop(pid), objs, specs, KEYS, REFS, out)
            if not dp_model.is_pending(pid):
                errs += e; warns += w
            if a:
                out[pid] = a
    PENDING_OUT.clear()
    PENDING_OUT.update({pid: m for pid, m in out.items() if dp_model.is_pending(pid)})
    return {pid: m for pid, m in out.items() if not dp_model.is_pending(pid)}, errs, warns


PENDING_OUT = {}     # the assembled models of pending products from the last validate(), for the baseline check only


def pending_models():
    """The ids of the models whose product is pending WP0 re-scope (CW-041), as found in models_*.py."""
    ids = set()
    for f in sorted(x[:-3] for x in os.listdir(HERE) if x.startswith("models_") and x.endswith(".py")):
        ids |= {pid for pid in importlib.import_module(f).MODELS if dp_model.is_pending(pid)}
    return sorted(ids)


def keys_needed(pids):
    objs = dp_model.load_taxonomy()
    for k, p in load_parents().items():
        objs[k]["parent"] = p
    specs, _, _ = dp_model.load_specs()
    K, R, _ = load_keys()
    need = {}
    for pid in pids:
        for n, on, an in specs[pid]["inputs"]:
            need.setdefault((n, on), set()).update(an)
            pk = parent_key(objs, (n, on))
            if objs[(n, on)]["kind"] == "Attribute Group" and pk:
                need.setdefault(pk, set())
    for k in sorted(need):
        o = objs[k]
        print(f'{"  " if k in K else "* "}("{k[0]}", "{k[1]}")  [{o["kind"]}{", parent: " + o["parent"] if o.get("parent") else ""}]'
              f'  grain: {o["grain"]}')
        print("      attrs: " + "; ".join(a + ("*" if v["cde"] else "") + (f" <{v['type']}>" if v["type"] in ("Identifier",) or v["type"].startswith("Reference") else "")
                                         for a, v in o["attrs"].items()))
        for a, v in o["attrs"].items():
            if v["type"].startswith("Reference") and (k[0], k[1], a) not in R:
                print(f"      * ref needed: {a} <{v['type']}> owner {v['owner'] or k[0]}")
    print(f"\n{len(need)} objects; '*' = missing from keys.py")


def write_conformed(path):
    out, _, _ = validate()
    with open(path, "w", encoding="utf-8") as f:
        f.write("Entities in foundational product models, available to consumer models as conformed dimensions:\n"
                "dict(name=..., role=\"Dimension\", conformed=(\"DP-nnn\", \"<Entity>\"), objects=[...])\n")
        for p in fw.PRODUCTS:
            if p[2] != "Foundational" or p[0] not in out:
                continue
            f.write(f"\n## {p[0]} {p[1]}\n")
            for e in out[p[0]]["entities"]:
                f.write(f'  ("{p[0]}", "{e["name"]}")  pk: {", ".join(a["name"] for a in e["attrs"] if a["pk"])} | objects: '
                        + "; ".join(f"{k[0]} {k[1]}" for k in e["objects"]) + "\n")


def keys_check(modules):
    """Validate the key registry with only keys.py, the merged registry files (keys_g*, keys_w_*) and the named keys_*.py
    modules loaded (each file once), and report the coverage of the named modules' Data Domains. For a key registry author: python dm_model.py --keys keys_e7_17_18"""
    objs = dp_model.load_taxonomy()
    for k, p in load_parents().items():
        objs[k]["parent"] = p
    # the merged registry files (keys_g*, and the wealth-manager keys_w_* that the full run also loads) form the base; a
    # named module that is itself a base file is loaded once, not twice (a second load reported every entry as a duplicate)
    modules = [m[:-3] if m.endswith(".py") else m for m in modules]
    base = ["keys"] + sorted(x[:-3] for x in os.listdir(HERE)
                             if (x.startswith("keys_g") or x.startswith("keys_w_")) and x.endswith(".py"))
    KEYS, REFS, dup, doms = {}, {}, [], set()
    for f in base + [m for m in dict.fromkeys(modules) if m not in base]:
        mod = importlib.import_module(f)
        for src, dst in ((mod.KEYS, KEYS), (getattr(mod, "REFS", {}), REFS)):
            for k, v in src.items():
                if k in dst:
                    dup.append((f, k))
                dst[k] = v
        if f in modules:
            doms |= {k[0] for k in mod.KEYS}
    errs, warns = validate_keys(objs, KEYS, REFS)
    mine = lambda m: any(f"('{d}', " in m for d in doms)
    errs = [f"duplicate key {k} (also in a registry file)" for f, k in dup] + [e for e in errs if mine(e)]
    warns = [w for w in warns if mine(w)]
    for x in warns: print("WARN ", x)
    for x in errs: print("ERROR", x)
    for d in sorted(doms):
        allo = [k for k in objs if k[0] == d]; missing = [k for k in allo if k not in KEYS]
        refs_all = [(k[0], k[1], a) for k in allo for a, x in objs[k]["attrs"].items() if x["type"].startswith("Reference")]
        refs_missing = [r for r in refs_all if r not in REFS]
        print(f"{d}: {len(allo) - len(missing)}/{len(allo)} objects keyed" + (f"; not keyed: {'; '.join(k[1] for k in missing)}" if missing else "")
              + f" | {len(refs_all) - len(refs_missing)}/{len(refs_all)} Reference attributes in REFS" + (f"; missing: {'; '.join(f'{on}.{a}' for _, on, a in refs_missing[:12])}{' ...' if len(refs_missing) > 12 else ''}" if refs_missing else ""))
    print(f"{len(errs)} error(s), {len(warns)} warning(s) in {', '.join(modules)}")
    return 1 if errs else 0


def models_check(modules, exclude_prefix="models_e8c"):     # the consumer-model wave writes models_e8c_*; foundational models_e8_* are loaded
    """Validate the named models_*.py modules with the key registry and every committed model loaded, leaving out sibling
    modules whose names start with exclude_prefix (files other agents are still writing). A conformed source that is not
    loaded is a warning. For a model author: python dm_model.py --models models_e8_foundations"""
    global LENIENT
    LENIENT = True
    objs = dp_model.load_taxonomy()
    for k, p in load_parents().items():
        objs[k]["parent"] = p
    specs, _, _ = dp_model.load_specs()
    KEYS, REFS, dup = load_keys()
    if dup:
        print("WARN  keys defined in more than one registry file: " + ", ".join(map(str, dup[:10])))
    files = sorted(x[:-3] for x in os.listdir(HERE) if x.startswith("models_") and x.endswith(".py")
                   and (not x.startswith(exclude_prefix) or x[:-3] in modules))
    models, mine = {}, set()
    for f in files:
        for pid, m in importlib.import_module(f).MODELS.items():
            if pid in models:
                print(f"ERROR {pid}: modeled in more than one module")
            models[pid] = m
            if f in modules:
                mine.add(pid)
    errs, warns = validate_keys(objs, KEYS, REFS)
    warns += pending_deps(models)
    out, pending = {}, dict(models)
    deps = {pid: {e["conformed"][0] for e in m.get("entities", []) if e.get("conformed")} for pid, m in models.items()}
    while pending:
        ready = [p for p in pending if not (deps[p] - set(out)) or not (deps[p] & set(pending))]
        if not ready:
            errs.append("conformed-dimension cycle among: " + ", ".join(sorted(pending))); break
        for pid in ready:
            a, e, w = assemble(pid, pending.pop(pid), objs, specs, KEYS, REFS, out)
            if not dp_model.is_pending(pid):            # pending WP0 re-scope (CW-041): assembled, not validated
                errs += e; warns += w
            if a:
                out[pid] = a
    own = lambda x: any(x.startswith(p + ":") or x.startswith(p + " ") for p in mine) or x.startswith("conformed-dimension cycle")
    for x in [w for w in warns if own(w)]: print("WARN ", x)
    for x in [e for e in errs if own(e)]: print("ERROR", x)
    print(f"{len(mine)} model(s) in {', '.join(modules)}: {len([e for e in errs if own(e)])} error(s), {len([w for w in warns if own(w)])} warning(s)")
    return 1 if [e for e in errs if own(e)] else 0


if __name__ == "__main__":
    if sys.argv[1:2] == ["--models"]:
        sys.exit(models_check(sys.argv[2:]))
    if sys.argv[1:2] == ["--keys"]:
        sys.exit(keys_check(sys.argv[2:]))
    if sys.argv[1:2] == ["--conformed"]:
        write_conformed(os.path.join(HERE, "_conformed.txt")); print("wrote data_models/_conformed.txt"); sys.exit(0)
    if sys.argv[1:2] == ["--keys-for"]:
        keys_needed(sys.argv[2:]); sys.exit(0)
    out, errs, warns = validate()
    for x in warns: print("WARN ", x)
    for x in errs: print("ERROR", x)
    held = pending_models()
    if held:
        print(f"{len(held)} model(s) of products pending WP0 re-scope, not validated (CW-041): {', '.join(held)}")
    dep = [x for x in warns if "depends on pending product" in x]
    if dep:
        print(f"{len(dep)} warning(s) are live models that reuse a conformed entity of a pending product's model")
    print(f"{len(out)} model(s) checked: {len(errs)} error(s), {len(warns)} warning(s)")
    sys.exit(1 if errs else 0)
