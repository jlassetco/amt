"""Shared key and link registry for logical data models. See CONTRACT.md section 1.

KEYS: primary key of each taxonomy object, and whether each Attribute Group folds into its parent (fold=True)
or becomes a child entity keyed by parent key + pk (fold=False).
REFS: the mastering object each Reference (...) attribute points to.

Notes are kept only where the choice is not obvious. "Scoped within <X>" means the object carries no attribute for
its owning X; the model completes the key with X's key.

W2-W4 combined merge (2026-10-15): this file keeps the 06, 09 and 10 entries it held. The 03, 05 and 08 entries moved
to keys_w_03_05_08.py (CW-062), the retired 07 Compensation & Territory entries are deleted (CW-907), and the 06
references re-point to the restored 05 partner objects, the 12 Institutional Client (CW-132, CW-133) and the renamed
Fund Shareholder Position (CW-151).
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


KEYS = {
    # 02 Client & Household: the whole 02 registry is in keys_g1_01_02.py since the W1 merge (CW-021); 03, 05 and 08 are
    # in keys_w_03_05_08.py since the W2-W4 merge (CW-062).

    # ------------------------------------------------------------------ 06 Client Assets, Flows & Channel Attribution
    ("06", "Attribution Record"): _k(["Attribution Record ID"], "Natural"),
    ("06", "Distributor Hierarchy"): _fold(),
    ("06", "Market & Client Dimensions"): _fold(),
    ("06", "Measure Definition"): _k(["Measure ID"], "Natural"),
    ("06", "Flow Treatment Rule"): _fold(),
    ("06", "Measure Value"): _k(["Measure", "Period End Date", "Dimension Type", "Dimension Key",
                                 "Data Basis", "Snapshot"], "Composite",
                                note="Keyed by dimension type and key (W4 06 ruling); Dimension Grain and the "
                                     "per-dimension columns are gone."),
    ("06", "Flow Measures"): _fold("A wide (pivoted) set of measure columns at the measure-set grain, not a repeat "
                                   "within one Measure Value row; it sits on the same Fact."),
    ("06", "Asset Measures"): _fold("A wide (pivoted) set of measure columns at the measure-set grain, not a repeat "
                                    "within one Measure Value row; it sits on the same Fact."),
    ("06", "Reporting Period"): _k(["Reporting Period ID"], "Natural"),
    ("06", "Snapshot"): _k(["Snapshot ID"], "Natural"),
    ("06", "Restatement"): _k(["Restatement ID"], "Natural"),

    # ------------------------------------------------------------------ 09 Shared & Enterprise Reference Data
    ("09", "Reporting Period Definition"): _k(["Reporting Period Definition Code"], "Natural",
                                              note="The code (MTD, QTD, YTD ...) is the identifier."),
    ("09", "Code Mapping"): _k(["Code Mapping ID"], "Natural"),

    # ------------------------------------------------------------- 10 Client Revenue, Pricing Economics & Profitability
    ("10", "Distribution Revenue Record"): _k(["Paying Share Class", "Receiving Entity", "Distribution Revenue Type"],
                                              "Composite",
                                              note="Grain also names the accounting period, which no attribute "
                                                   "carries: model gap."),
    ("10", "Adviser-Borne Cost"): _k(["Related Payment Arrangement", "Adviser-Borne Cost Type"], "Composite",
                                     note="Grain also names the accounting period, which no attribute carries: "
                                          "model gap."),
    ("10", "Distribution Cost Item"): _k(["Distribution Cost Item ID"], "Natural"),
    ("10", "Accrual"): _k(["Accrual ID"], "Natural"),
}


PARTY = ("02", "Party")
# Distributor Firm and Financial Professional are role profiles of the 02 Party restored in 05 at W4 (CW-132), keyed
# by the PTY- reference, so the join value is unchanged.
DISTRIBUTOR = ("05", "Distributor Firm")  # restored to 05 at W4 (CW-132)
FIN_PRO = ("05", "Financial Professional")  # restored to 05 at W4 (CW-132)
EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")

REFS = {
    # ------------------------------------------------------------------ 06 Client Assets, Flows & Channel Attribution
    ("06", "Attribution Record", "Source Transaction"): ("06", "Transaction"),
    ("06", "Attribution Record", "Source Position"): ("06", "Fund Shareholder Position"),
    ("06", "Attribution Record", "Source Account Asset Summary"): ("06", "Account Asset Summary"),
    ("06", "Distributor Hierarchy", "Distributor Firm"): DISTRIBUTOR,
    ("06", "Distributor Hierarchy", "Distributor Office / Branch"): ("05", "Branch / Office"),
    ("06", "Distributor Hierarchy", "Advisor Team"): ("05", "Advisor Team"),
    ("06", "Distributor Hierarchy", "Advisor / Rep"): FIN_PRO,
    ("06", "Market & Client Dimensions", "Retirement Plan"): ("02", "Retirement Plan"),
    ("06", "Market & Client Dimensions", "Institutional Client"): ("12", "Institutional Client"),  # restored in 12 (CW-133)
    ("06", "Market & Client Dimensions", "Consultant"): ("05", "Consultant Profile"),
    ("06", "Market & Client Dimensions", "Service Offering"): ("01", "Service Offering"),
    ("06", "Market & Client Dimensions", "Covering Advisor"): ("03", "Advisor"),
    ("06", "Market & Client Dimensions", "Advisor Coverage Assignment"): ("03", "Party Coverage Assignment"),
    ("06", "Market & Client Dimensions", "Client Household"): PARTY,
    ("06", "Market & Client Dimensions", "Attributed Campaign"): ("04", "Campaign"),
    ("06", "Market & Client Dimensions", "Source Attributed Outcome"): ("04", "Attributed Outcome"),
    ("06", "Measure Value", "Measure"): ("06", "Measure Definition"),
    ("06", "Measure Value", "Snapshot"): ("06", "Snapshot"),
    ("06", "Measure Value", "Reporting Period"): ("06", "Reporting Period"),
    ("06", "Snapshot", "Supersedes Snapshot"): ("06", "Snapshot"),
    ("06", "Snapshot", "Approved By"): EMPLOYEE,
    ("06", "Restatement", "Restatement Approved By"): EMPLOYEE,

    # ------------------------------------------------------------------ 09 Shared & Enterprise Reference Data
    ("09", "Code Mapping", "Target Code List"): ("09", "Code List"),
    ("09", "Code Mapping", "Source System"): ("41", "Application"),
    ("09", "Reporting Period Definition", "Period Basis Calendar"): ("09", "Calendar"),

    # ------------------------------------------------------------- 10 Client Revenue, Pricing Economics & Profitability
    ("10", "Distribution Revenue Record", "Receiving Entity"): LEGAL_ENTITY,
    ("10", "Distribution Revenue Record", "Paying Share Class"): ("01", "Share Class"),
    ("10", "Distribution Revenue Record", "Sales Charge Source Transactions"): ("29", "Register Transaction"),
    ("10", "Adviser-Borne Cost", "Related Payment Arrangement"): ("05", "Payment Arrangement"),
    ("10", "Distribution Cost Item", "Cost Counterparty"): PARTY,
    ("10", "Distribution Cost Item", "Bearing Legal Entity"): LEGAL_ENTITY,
    ("10", "Distribution Cost Item", "Cost Center"): ORG_UNIT,
    ("10", "Distribution Cost Item", "Profit Center"): ORG_UNIT,
    ("10", "Distribution Cost Item", "Direct Product / Share Class"): ("01", "Share Class"),
    ("10", "Accrual", "Accrued Cost Item"): ("10", "Distribution Cost Item"),
}

# Unresolved references (left out of REFS: no single object masters the target)
#   ("10", "Distribution Cost Item", "Source Record")  <Reference (Payment Calculation, 05 / Partner Payment, 05 /
#       Compensation Statement, 03 / Campaign, 04 / Data License Agreement, 14 / Payable Invoice, 19) (multi)>
#       Points to whichever record generated the cost, with Source Domain as the discriminator. Model it as a
#       polymorphic lineage link or split it into typed references.
