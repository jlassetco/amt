"""Key and link registry extension: Data Domains 17 Instrument & Issuer Reference and 18 Portfolio & Investment Book of
Record (enterprise expansion, Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Keys follow the grain in enrichment/enrich_17.py and
enrich_18.py. Every Reference attribute of both domains resolves to an object in the taxonomy, so every one is in REFS.
"Model gap" means the grain or a reference needs something no attribute carries; the taxonomy is left unchanged.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


PARTY = ("02", "Party")
EMPLOYEE = ("20", "Employee")
INSTRUMENT = ("17", "Instrument")
CA_EVENT = ("17", "Corporate Action Event")
PORTFOLIO = ("18", "Portfolio")
PORTFOLIO_TXN = ("18", "Portfolio Transaction")
TAX_LOT = ("18", "Tax Lot")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
CALENDAR = ("09", "Calendar")
CLASS_SCHEME = ("09", "Classification Scheme")
ACCOUNT = ("15", "Account")
SAFEKEEPING = ("28", "Safekeeping Account")
APPLICATION = ("41", "Application")
DATASET = ("14", "Dataset")
TRANSITION = ("12", "Transition Event")

KEYS = {
    # ------------------------------------------------------------------ 17 Instrument Master
    ("17", "Instrument"): _k(["Instrument ID"], "Natural"),
    ("17", "Instrument Identifier"): _k(["Instrument Identifier ID"], "Natural",
                                        note="The ID identifies the row; instrument x scheme x value x Identifier "
                                             "Effective From is the alternate key the grain names."),
    ("17", "Instrument Relationship"): _k(["Subject Instrument", "Related Instrument", "Related Index",
                                           "Instrument Relationship Type", "Relationship Effective From"], "Composite",
                                          note="Exactly one of Related Instrument and Related Index is filled, as the "
                                               "grain's 'related instrument (or index)' says."),
    ("17", "Instrument Setup Request"): _k(["Setup Request ID"], "Natural"),
    # ------------------------------------------------------------------ 17 Instrument Classification
    ("17", "Instrument Classification Assignment"): _k(["Classified Instrument", "Instrument Classification Scheme",
                                                        "Instrument Classification Code",
                                                        "Instrument Classification Effective From"], "Composite"),
    ("17", "Issuer Classification Assignment"): _k(["Classified Issuer", "Issuer Classification Scheme",
                                                    "Issuer Sector Code", "Issuer Classification Effective From"],
                                                   "Composite"),
    ("17", "Regulatory Instrument Classification"): _k(["Regulatory Classified Instrument",
                                                        "Regulatory Classification Effective From"], "Composite",
                                                       note="Effective-dated so NAIC, Rule 2a-7 and other US "
                                                            "eligibility classifications keep history."),
    # ------------------------------------------------------------------ 17 Equity, fund, debt, derivative and private terms
    ("17", "Equity Terms"): _fold(),
    ("17", "Fund Instrument Terms"): _fold(),
    ("17", "Municipal Fund Security Terms"): _fold("Populated for 529 and ABLE plan portfolios only (CW-917)."),
    ("17", "Debt Terms"): _fold("Fixed or initial terms only; step rates repeat on Coupon Schedule."),
    ("17", "Municipal Security Terms"): _fold("Populated for US municipal bonds and notes only (CW-917)."),
    ("17", "Securitized Product Terms"): _fold(),
    ("17", "Listed Derivative Contract Terms"): _fold(),
    ("17", "OTC Derivative Product Terms"): _fold("Product (UPI) level; the UPI itself is an Instrument Identifier row."),
    ("17", "Private Asset Terms"): _fold(),
    ("17", "Fund Interest Terms"): _fold(),
    ("17", "Coupon Schedule"): _k(["Coupon Instrument", "Coupon Period Number"], "Composite",
                                  note="The period number is the sequence from the first coupon, so it names the "
                                       "coupon period within the instrument."),
    ("17", "Redemption Schedule"): _k(["Redemption Instrument", "Redemption Event Type", "Redemption Start Date"],
                                      "Composite"),
    # ------------------------------------------------------------------ 17 Listings
    ("17", "Instrument Listing"): _k(["Listing ID"], "Natural",
                                     note="The ID identifies the row; instrument x Listing Venue MIC x Listing Date is "
                                          "the alternate key the grain names."),
    # ------------------------------------------------------------------ 17 Issuers & Ratings
    ("17", "Issuer Profile"): _k(["Issuer Party"], "Composite",
                                 note="An issuer-role extension of 02 Party (1:1); the key is the Party ID."),
    ("17", "Issuer Relationship"): _k(["Subject Issuer", "Related Party", "Issuer Relationship Type",
                                       "Issuer Relationship Effective From"], "Composite"),
    ("17", "Credit Rating Assignment"): _k(["Rated Instrument", "Rated Issuer", "Credit Rating Agency",
                                            "Credit Rating Type", "Credit Rating Action Date"], "Composite",
                                           note="Rated Instrument is filled for issue ratings and Rated Issuer for "
                                                "issuer ratings, so the pair tells the two kinds apart."),
    # ------------------------------------------------------------------ 17 Corporate Action Events
    ("17", "Corporate Action Event"): _k(["Corporate Action Event ID"], "Natural",
                                         note="Official Corporate Action Event Reference (COAF) is the cross-custodian "
                                              "alternate key."),
    ("17", "Corporate Action Option"): _k(["Option Event", "Option Number"], "Composite"),

    # ------------------------------------------------------------------ 18 Portfolio Master
    ("18", "Portfolio"): _k(["Portfolio ID"], "Natural"),
    ("18", "Portfolio Identifier"): _k(["Identified Portfolio", "Portfolio Identifier Scheme", "Portfolio Identifier Value",
                                        "Identifier Effective From"], "Composite"),
    ("18", "Portfolio Implementation Link"): _k(["Implementing Portfolio", "Implementation Link Type",
                                                 "Implemented Product", "Implemented Mandate", "Managed Account",
                                                 "Followed Model Portfolio", "Implementation Effective From"],
                                                "Composite",
                                                note="One reference per link type: Implementation Link Type says which "
                                                     "one of the four targets is filled."),
    ("18", "Portfolio Hierarchy Link"): _k(["Parent Portfolio", "Child Portfolio", "Portfolio Hierarchy Link Type",
                                            "Hierarchy Effective From"], "Composite"),
    ("18", "Portfolio Accounting Basis"): _fold("Current conventions only; history comes from Portfolio Lifecycle Event "
                                                "(Accounting Basis Change)."),
    ("18", "Portfolio Lifecycle Event"): _k(["Event Portfolio", "Portfolio Lifecycle Event Type", "Event Effective Date"],
                                            "Composite"),
    # ------------------------------------------------------------------ 18 Business-Line Detail
    ("18", "Fund Portfolio Detail"): _fold(),
    ("18", "SMA Portfolio Detail"): _fold(),
    ("18", "Private Fund Portfolio Detail"): _fold(),
    # ------------------------------------------------------------------ 18 Holdings
    ("18", "Portfolio Holding"): _k(["Holding ID"], "Natural",
                                    note="The ID identifies the row; portfolio x instrument x Holding Date x Holding "
                                         "View is the alternate key the grain names."),
    ("18", "Holding Valuation"): _fold(),
    ("18", "Derivative Holding Detail"): _fold(),
    ("18", "Fund Interest Holding Detail"): _fold(),
    # ------------------------------------------------------------------ 18 Tax Lots
    ("18", "Tax Lot"): _k(["Tax Lot ID"], "Natural",
                          note="Current state of the lot; its history is rebuilt from Lot Relief."),
    ("18", "Lot Relief"): _k(["Relieved Tax Lot", "Closing Transaction"], "Composite"),
    # ------------------------------------------------------------------ 18 Cash
    ("18", "Cash Balance"): _k(["Cash Balance Portfolio", "Balance Currency", "Cash Safekeeping Account", "Balance Date",
                                "Cash Balance Type"], "Composite",
                               note="The grain's cash account is the 28 safekeeping cash account."),
    ("18", "Projected Cash Movement"): _k(["Projection Portfolio", "Projected Currency", "Projected Value Date",
                                           "Projected Cash Source", "Source Portfolio Transaction",
                                           "Source Corporate Action Event"], "Composite",
                                          note="The grain's source item is the source type plus the transaction or "
                                               "corporate action it comes from; sources that are neither (fees, "
                                               "capital activity, maturities) have no item reference: model gap."),
    ("18", "Portfolio Capital Activity"): _k(["Activity Portfolio", "Activity Share Class", "Activity Account",
                                              "Activity Trade Date", "Capital Activity Type"], "Composite",
                                             note="Share class for pooled funds, client account for mandate and SMA "
                                                  "books (one is blank). Model gap: no ID attribute, yet Portfolio "
                                                  "Transaction.Related Capital Activity references one activity."),
    # ------------------------------------------------------------------ 18 Portfolio Activity
    ("18", "Portfolio Transaction"): _k(["Portfolio Transaction ID"], "Natural"),
    ("18", "Transaction Cost & Charge"): _fold("Explicit costs only, one set per transaction."),
    ("18", "Portfolio Transaction Event"): _k(["Event Transaction", "Portfolio Transaction Event Type", "Event Timestamp"],
                                              "Composite"),
    # ------------------------------------------------------------------ 18 Book Control
    ("18", "Portfolio Position Snapshot"): _k(["Snapshot Portfolio", "Snapshot Type", "Snapshot As-Of Timestamp"],
                                              "Composite",
                                              note="Members (holdings and cash) are found by business date and holding "
                                                   "view, not by a snapshot reference on each row."),
    ("18", "Position Adjustment"): _k(["Adjusted Portfolio", "Adjusted Instrument", "Adjustment Date",
                                       "Adjusting Transaction"], "Composite",
                                      note="The adjusting transaction tells apart adjustments of the same day and "
                                           "reason."),
    ("18", "Portfolio Valuation Summary"): _k(["Valued Portfolio", "Valuation As-Of Date", "Valuation View"],
                                              "Composite"),
}

REFS = {
    # ------------------------------------------------------------------ 17 Instrument Master
    ("17", "Instrument", "Issuer"): PARTY,
    ("17", "Instrument", "Own Share Class"): ("01", "Share Class"),
    ("17", "Instrument", "Source Dataset"): DATASET,
    ("17", "Instrument", "Fractional Trading Eligibility Rule"): ("01", "Tradable Universe Policy Rule"),
    ("17", "Instrument", "Extended-Hours Eligibility Rule"): ("01", "Tradable Universe Policy Rule"),
    ("17", "Instrument Identifier", "Identified Instrument"): INSTRUMENT,
    ("17", "Instrument Identifier", "Identifier Listing"): ("17", "Instrument Listing"),
    ("17", "Instrument Identifier", "Issuing Agency"): PARTY,
    ("17", "Instrument Relationship", "Subject Instrument"): INSTRUMENT,
    ("17", "Instrument Relationship", "Related Instrument"): INSTRUMENT,
    ("17", "Instrument Relationship", "Related Index"): ("01", "Benchmark"),
    ("17", "Instrument Setup Request", "Requested By"): EMPLOYEE,
    ("17", "Instrument Setup Request", "Approved By"): EMPLOYEE,
    ("17", "Instrument Setup Request", "Resulting Instrument"): INSTRUMENT,
    # ------------------------------------------------------------------ 17 Instrument Classification
    ("17", "Instrument Classification Assignment", "Classified Instrument"): INSTRUMENT,
    ("17", "Instrument Classification Assignment", "Instrument Classification Scheme"): CLASS_SCHEME,
    ("17", "Issuer Classification Assignment", "Classified Issuer"): PARTY,
    ("17", "Issuer Classification Assignment", "Issuer Classification Scheme"): CLASS_SCHEME,
    ("17", "Regulatory Instrument Classification", "Regulatory Classified Instrument"): INSTRUMENT,
    # ------------------------------------------------------------------ 17 Terms
    ("17", "Equity Terms", "Depositary Bank"): PARTY,
    ("17", "Fund Instrument Terms", "Fund Manager or General Partner"): PARTY,
    ("17", "Fund Instrument Terms", "Own Investment Product"): ("01", "Investment Product"),
    ("17", "Fund Instrument Terms", "Peer Fund"): ("11", "Peer Fund"),
    ("17", "Municipal Fund Security Terms", "Program Manager"): PARTY,
    ("17", "Debt Terms", "Payment Calendar"): CALENDAR,
    ("17", "Debt Terms", "Debt Guarantor"): PARTY,
    ("17", "Municipal Security Terms", "Bond Insurer"): PARTY,
    ("17", "Coupon Schedule", "Coupon Instrument"): INSTRUMENT,
    ("17", "Redemption Schedule", "Redemption Instrument"): INSTRUMENT,
    ("17", "Securitized Product Terms", "Collateral Manager or Servicer"): PARTY,
    ("17", "Listed Derivative Contract Terms", "Clearing House"): PARTY,
    ("17", "Private Asset Terms", "Administrative Agent"): PARTY,
    # ------------------------------------------------------------------ 17 Listings
    ("17", "Instrument Listing", "Listed Instrument"): INSTRUMENT,
    ("17", "Instrument Listing", "Trading Calendar"): CALENDAR,
    # ------------------------------------------------------------------ 17 Issuers & Ratings
    ("17", "Issuer Profile", "Issuer Party"): PARTY,
    ("17", "Issuer Profile", "Primary Equity Instrument"): INSTRUMENT,
    ("17", "Issuer Relationship", "Subject Issuer"): PARTY,
    ("17", "Issuer Relationship", "Related Party"): PARTY,
    ("17", "Issuer Relationship", "Relationship Approved By"): EMPLOYEE,
    ("17", "Credit Rating Assignment", "Rated Instrument"): INSTRUMENT,
    ("17", "Credit Rating Assignment", "Rated Issuer"): PARTY,
    ("17", "Credit Rating Assignment", "Credit Rating Source Dataset"): DATASET,
    # ------------------------------------------------------------------ 17 Corporate Action Events
    ("17", "Corporate Action Event", "Event Instrument"): INSTRUMENT,
    ("17", "Corporate Action Event", "Offeror"): PARTY,
    ("17", "Corporate Action Event", "Linked Event"): CA_EVENT,
    ("17", "Corporate Action Event", "Scrubbed By"): EMPLOYEE,
    ("17", "Corporate Action Option", "Option Event"): CA_EVENT,
    ("17", "Corporate Action Option", "Resulting Instrument"): INSTRUMENT,

    # ------------------------------------------------------------------ 18 Portfolio Master
    ("18", "Portfolio", "Legal Owner Entity"): LEGAL_ENTITY,
    ("18", "Portfolio", "Managing Entity"): LEGAL_ENTITY,
    ("18", "Portfolio", "Book of Record System"): APPLICATION,
    ("18", "Portfolio", "Middle Office Provider"): PARTY,
    ("18", "Portfolio", "Safekeeping Custody Account"): SAFEKEEPING,
    ("18", "Portfolio Identifier", "Identified Portfolio"): PORTFOLIO,
    ("18", "Portfolio Identifier", "Identifier Issuer"): PARTY,
    ("18", "Portfolio Implementation Link", "Implementing Portfolio"): PORTFOLIO,
    ("18", "Portfolio Implementation Link", "Implemented Product"): ("01", "Investment Product"),
    ("18", "Portfolio Implementation Link", "Implemented Mandate"): ("01", "Investment Mandate"),
    ("18", "Portfolio Implementation Link", "Managed Account"): ACCOUNT,
    ("18", "Portfolio Implementation Link", "Followed Model Portfolio"): ("01", "Model Portfolio"),
    ("18", "Portfolio Hierarchy Link", "Parent Portfolio"): PORTFOLIO,
    ("18", "Portfolio Hierarchy Link", "Child Portfolio"): PORTFOLIO,
    ("18", "Portfolio Accounting Basis", "Valuation Calendar"): CALENDAR,
    ("18", "Portfolio Accounting Basis", "FX Rate Type Used"): ("09", "FX Rate Type"),
    ("18", "Portfolio Lifecycle Event", "Event Portfolio"): PORTFOLIO,
    ("18", "Portfolio Lifecycle Event", "Counterpart Portfolio"): PORTFOLIO,
    ("18", "Portfolio Lifecycle Event", "Related Transition Event"): TRANSITION,
    ("18", "Portfolio Lifecycle Event", "Event Recorded By"): EMPLOYEE,
    # ------------------------------------------------------------------ 18 Business-Line Detail
    ("18", "Fund Portfolio Detail", "Cash Sweep Vehicle"): INSTRUMENT,
    # SMA sponsor programs are 05 distribution agreements (as 06 SMA Flow.Sponsor Program in keys_g3).
    ("18", "SMA Portfolio Detail", "Sponsor Program Agreement"): ("05", "Distribution Agreement"),
    # ------------------------------------------------------------------ 18 Holdings
    ("18", "Portfolio Holding", "Holding Portfolio"): PORTFOLIO,
    ("18", "Portfolio Holding", "Held Instrument"): INSTRUMENT,
    ("18", "Portfolio Holding", "Corresponding Shareholder Position"): ("06", "Fund Shareholder Position"),
    ("18", "Derivative Holding Detail", "OTC Counterparty"): PARTY,
    ("18", "Derivative Holding Detail", "Clearing Broker"): PARTY,
    # ------------------------------------------------------------------ 18 Tax Lots
    ("18", "Tax Lot", "Lot Portfolio"): PORTFOLIO,
    ("18", "Tax Lot", "Lot Instrument"): INSTRUMENT,
    ("18", "Tax Lot", "Opening Transaction"): PORTFOLIO_TXN,
    ("18", "Lot Relief", "Relieved Tax Lot"): TAX_LOT,
    ("18", "Lot Relief", "Closing Transaction"): PORTFOLIO_TXN,
    ("18", "Lot Relief", "Wash-Sale Replacement Lot"): TAX_LOT,
    # ------------------------------------------------------------------ 18 Cash
    ("18", "Cash Balance", "Cash Balance Portfolio"): PORTFOLIO,
    ("18", "Cash Balance", "Cash Safekeeping Account"): SAFEKEEPING,
    ("18", "Cash Balance", "Cash Custodian"): PARTY,
    ("18", "Projected Cash Movement", "Projection Portfolio"): PORTFOLIO,
    ("18", "Projected Cash Movement", "Source Portfolio Transaction"): PORTFOLIO_TXN,
    ("18", "Projected Cash Movement", "Source Corporate Action Event"): CA_EVENT,
    ("18", "Portfolio Capital Activity", "Activity Portfolio"): PORTFOLIO,
    ("18", "Portfolio Capital Activity", "Activity Share Class"): ("01", "Share Class"),
    ("18", "Portfolio Capital Activity", "Activity Account"): ACCOUNT,
    ("18", "Portfolio Capital Activity", "Source Cash Flow Notification"): ("12", "Cash Flow Notification"),
    # ------------------------------------------------------------------ 18 Portfolio Activity
    ("18", "Portfolio Transaction", "Transaction Portfolio"): PORTFOLIO,
    ("18", "Portfolio Transaction", "Transaction Instrument"): INSTRUMENT,
    ("18", "Portfolio Transaction", "Executing Broker"): PARTY,
    ("18", "Portfolio Transaction", "Transaction Counterparty"): PARTY,
    ("18", "Portfolio Transaction", "Source Allocation ID"): ("25", "Trade Allocation"),
    ("18", "Portfolio Transaction", "Source Corporate Action Event"): CA_EVENT,
    ("18", "Portfolio Transaction", "Related Transition Event"): TRANSITION,
    # Points at a composite-keyed object through one attribute: see the Portfolio Capital Activity model gap note.
    ("18", "Portfolio Transaction", "Related Capital Activity"): ("18", "Portfolio Capital Activity"),
    ("18", "Portfolio Transaction Event", "Event Transaction"): PORTFOLIO_TXN,
    ("18", "Portfolio Transaction Event", "Rebooked As Transaction"): PORTFOLIO_TXN,
    ("18", "Portfolio Transaction Event", "Event Source System"): APPLICATION,
    ("18", "Portfolio Transaction Event", "Event Performed By"): EMPLOYEE,
    # ------------------------------------------------------------------ 18 Book Control
    ("18", "Portfolio Position Snapshot", "Snapshot Portfolio"): PORTFOLIO,
    ("18", "Position Adjustment", "Adjusted Portfolio"): PORTFOLIO,
    ("18", "Position Adjustment", "Adjusted Instrument"): INSTRUMENT,
    ("18", "Position Adjustment", "Adjusted Holding"): ("18", "Portfolio Holding"),
    ("18", "Position Adjustment", "Adjustment Approved By"): EMPLOYEE,
    ("18", "Position Adjustment", "Adjusting Transaction"): PORTFOLIO_TXN,
    # The definition says the snapshot is "keyed by portfolio, snapshot type and as-of timestamp", the composite key above.
    ("18", "Portfolio Valuation Summary", "Valued Portfolio"): PORTFOLIO,
    ("18", "Portfolio Valuation Summary", "Summary Snapshot"): ("18", "Portfolio Position Snapshot"),
}
