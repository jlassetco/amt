"""Key and link registry extension: Data Domains 19-21 (enterprise expansion, Phase 2, Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Keys every object of 19 Finance & Accounting, 20 Human
Capital and 21 Data Governance & Analytics not already keyed in keys_g7_17_21.py (Journal Entry, GL Posting, Accounting
Period Status, Financial Statement Line Mapping, Employee, Employee Reporting Line, Org Unit Assignment, Data Quality Rule
and Data Quality Result stay there), and registers every Reference attribute of the three domains that keys_g7 left out,
including the references on the objects it keys.

Versioned masters that other records reference by their ID alone (Workforce Position, Benefit Plan, Mandatory Training
Requirement) are keyed Natural on the ID, as keys.py does for Territory: the referencing attributes carry only the ID, so
the effective-period or plan-year column is added to the key only where a model keeps history.

W2-W4 merge (2026-10-15): 21 Retention Rule (RET-) replaces the wholesale 08 Retention Rule as the target of the
records-retention references; 19 Receivable Item.Source Fee Invoice points at the 47 Fee Invoice (CW-052) and 20
Payroll Result.Incentive Payout Statements at the 03 Compensation Statement (CW-907).
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
PRODUCT = ("01", "Investment Product")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
OFFICE = ("09", "Office Location")
CALENDAR = ("09", "Calendar")
CODE_LIST = ("09", "Code List")
CHART = ("19", "Chart of Accounts")
GL_ACCOUNT = ("19", "GL Account")
SEGMENT_VALUE = ("19", "Chart Segment Value")
LEDGER = ("19", "Ledger")
JOURNAL = ("19", "Journal Entry")
STATEMENT_LINE = ("19", "Financial Statement Line")
EMPLOYEE = ("20", "Employee")
POSITION = ("20", "Workforce Position")
JOB_PROFILE = ("20", "Job Profile")
TAXONOMY_ELEMENT = ("21", "Taxonomy Element")
RELEASE = ("21", "Taxonomy Release")
DATA_ASSET = ("21", "Data Asset")
DATA_PRODUCT = ("21", "Data Product")
DQ_RULE = ("21", "Data Quality Rule")
METRIC = ("21", "Metric Definition")
APPLICATION = ("41", "Application")
LOAD = ("06", "Load")
DATASET = ("14", "Dataset")

KEYS = {
    # ------------------------------------------------------------------ 19 Chart of Accounts & Ledgers
    ("19", "Chart of Accounts"): _k(["Chart of Accounts Code"], "Natural"),
    ("19", "GL Account"): _k(["GL Account ID"], "Natural",
                             note="The enterprise ID stands for chart x natural account and is what every posting, "
                                  "balance and mapping carries."),
    ("19", "Chart Segment Value"): _k(["Segment Value Chart", "Chart Segment", "Segment Value Code",
                                       "Segment Value Effective From"], "Composite",
                                      note="No ID attribute; references carry the bare segment value code, so models "
                                           "join on the code within the chart and segment the referencing attribute "
                                           "implies (cost center)."),
    ("19", "Ledger"): _k(["Ledger ID"], "Natural"),
    ("19", "Financial Statement Line"): _k(["Statement Line Code"], "Natural",
                                           note="The firm line code is unique across frameworks and is what Mapped "
                                                "Statement Line and Value Statement Line carry."),
    # ------------------------------------------------------------------ 19 Journals & Balances
    ("19", "GL Account Balance"): _k(["Balance Ledger", "Balance GL Account", "Balance Segment Combination",
                                      "Balance Fiscal Period", "Balance Type", "Balance Currency"], "Composite",
                                     note="The account combination is a concatenated text key of segment value codes "
                                          "(Source Notes); the GL account is kept in the key so balances join to "
                                          "GL Account directly."),
    # ------------------------------------------------------------------ 19 Period Close & Consolidation
    ("19", "Close Task"): _k(["Close Cycle Period", "Close Task Ledger", "Close Task ID"], "Composite",
                             note="Close Task ID identifies the task within a close cycle, so the cycle period and "
                                  "ledger complete the key."),
    ("19", "Consolidation Scope Entity"): _k(["Consolidation Group", "Scope Legal Entity", "Consolidated Fund Product",
                                              "Seed Portfolio", "Scope Fiscal Period"], "Composite",
                                             note="Exactly one of the three consolidated unit references (legal "
                                                  "entity, fund product, seed portfolio) is populated."),
    ("19", "Intercompany Balance"): _k(["Reporting Entity", "Counterparty Entity", "Intercompany GL Account",
                                        "Intercompany Period"], "Composite"),
    # ------------------------------------------------------------------ 19 Payables
    ("19", "Payable Invoice"): _k(["Payable Invoice ID"], "Natural"),
    ("19", "Payable Invoice Line"): _k(["Line Payable Invoice", "Invoice Line Number"], "Composite"),
    ("19", "Indirect Tax Detail"): _child(["Indirect Tax Type"],
                                          "Repeats per indirect tax type within one invoice line."),
    ("19", "Supplier Payment"): _k(["Supplier Payment Document Number"], "Natural"),
    ("19", "Supplier Payment Application"): _k(["Applied Supplier Payment", "Settled Payable Invoice"], "Composite"),
    # ------------------------------------------------------------------ 19 Receivables
    ("19", "Receivable Item"): _k(["Receivable Document Number"], "Natural",
                                  note="The ERP document number identifies the debtor x source document row."),
    ("19", "Cash Receipt Application"): _k(["Cash Receipt Reference", "Applied Receivable Item"], "Composite"),
    # ------------------------------------------------------------------ 19 Financial & Regulatory Reporting
    ("19", "Financial Statement"): _k(["Financial Statement ID"], "Natural"),
    ("19", "Financial Statement Line Value"): _k(["Line Financial Statement", "Value Statement Line"], "Composite"),
    ("19", "Regulatory Financial Return"): _k(["Return Filing Entity", "Return Regulator", "Regulatory Return Type",
                                               "Return Reporting Period End"], "Composite"),
    # ------------------------------------------------------------------ 19 Planning & Forecasting
    ("19", "Financial Plan Version"): _k(["Financial Plan Version ID"], "Natural"),
    ("19", "Financial Plan Line"): _k(["Line Plan Version", "Plan Legal Entity", "Plan GL Account",
                                       "Plan Segment Values", "Plan Line Period"], "Composite",
                                      note="Model gap: the account combination is a multi-valued segment reference "
                                           "with no concatenated text form as on GL Account Balance; models hold the "
                                           "segment value codes in chart segment order as one key column."),
    # ------------------------------------------------------------------ 19 Corporate Tax
    ("19", "Entity Tax Registration"): _k(["Registered Legal Entity", "Registration Tax Jurisdiction",
                                           "Registration Tax Type", "Registration Effective From"], "Composite",
                                          note="The tax registration number is unique only per issuing authority, so "
                                               "the grain attributes form the key."),
    ("19", "Tax Return"): _k(["Tax Return ID"], "Natural"),
    ("19", "Tax Provision"): _k(["Provision Legal Entity", "Provision Fiscal Period", "Provision Tax Jurisdiction",
                                 "Provision Component"], "Composite"),
    ("19", "Transfer Pricing Documentation"): _k(["TP Documentation ID"], "Natural"),

    # ------------------------------------------------------------------ 20 Employee Master
    ("20", "Employee Personal Detail"): _fold(),
    ("20", "Employee Diversity Profile"): _fold(),
    ("20", "Contingent Worker Detail"): _fold("Current engagement only, so at most one row per employee."),
    # ------------------------------------------------------------------ 20 Jobs, Positions & Assignments
    ("20", "Job Profile"): _k(["Job Profile ID"], "Natural"),
    ("20", "Workforce Position"): _k(["Workforce Position ID"], "Natural",
                                     note="Grain is versioned by effective period; add Position Effective From to the "
                                          "key where history is kept."),
    ("20", "Employee Job Assignment"): _k(["Assigned Worker", "Assigned Workforce Position", "Assigned Job Profile",
                                           "Assignment Type", "Assignment Effective From"], "Composite",
                                          note="The assignment is to a position or, where none exists, to a job "
                                               "profile alone, so both references sit in the key."),
    # ------------------------------------------------------------------ 20 Lifecycle & Recruiting
    ("20", "Employee Lifecycle Event"): _k(["Lifecycle Event ID"], "Natural"),
    ("20", "Leave of Absence"): _k(["Leave Employee", "Leave Type", "Leave Start Date"], "Composite"),
    ("20", "Job Requisition"): _k(["Job Requisition ID"], "Natural"),
    ("20", "Candidate Application"): _k(["Candidate Application ID"], "Natural",
                                        note="The ATS application ID stands for candidate x requisition (Candidate "
                                             "ID + Applied Requisition)."),
    ("20", "Background Screening"): _k(["Screened Employee", "Screened Candidate Application", "Screening Type",
                                        "Screening Completed Date"], "Composite",
                                       note="Exactly one of the screened employee and the screened candidate "
                                            "application is populated."),
    # ------------------------------------------------------------------ 20 Compensation, Benefits & Payroll
    ("20", "Base Pay Record"): _k(["Paid Employee", "Pay Component", "Pay Effective From"], "Composite"),
    ("20", "Variable Compensation Award"): _k(["Variable Compensation Award ID"], "Natural"),
    ("20", "Deferred Award Tranche"): _k(["Tranche Award", "Tranche Number"], "Composite"),
    # Material Risk Taker Identification removed (EU/UK remuneration codes; CW-920).
    ("20", "Benefit Plan"): _k(["Benefit Plan ID"], "Natural",
                               note="Grain adds the plan year; add Benefit Plan Year to the key where plan years are "
                                    "kept as separate rows (enrollments reference the ID alone)."),
    ("20", "Benefit Enrollment"): _k(["Enrolled Employee", "Enrolled Benefit Plan", "Coverage Start Date"],
                                     "Composite"),
    ("20", "Payroll Run"): _k(["Payroll Run Identifier"], "Natural",
                              note="The firm identifier encodes legal entity, pay period and run sequence and is "
                                   "what 19 journal lines carry."),
    ("20", "Payroll Result"): _k(["Payroll Employee", "Payroll Run"], "Composite"),
    # ------------------------------------------------------------------ 20 Performance & Talent
    ("20", "Performance Review"): _k(["Reviewed Employee", "Review Cycle", "Review Type"], "Composite"),
    ("20", "Performance Objective"): _k(["Objective Employee", "Objective Review Cycle", "Objective Title"],
                                        "Composite",
                                        note="Model gap: no objective identifier; the title stands in as the "
                                             "discriminator within the employee's review cycle."),
    ("20", "Succession Plan Entry"): _k(["Succession Position", "Successor Employee"], "Composite"),
    # ------------------------------------------------------------------ 20 Learning & Competence
    ("20", "Learning Item"): _k(["Learning Item ID"], "Natural"),
    ("20", "Learning Completion"): _k(["Learner Employee", "Completed Learning Item", "Completion Due Date",
                                       "Completion Date"], "Composite",
                                      note="A row is an assignment (identified by its due date) or an unassigned "
                                           "completion (identified by its completion date)."),
    ("20", "Mandatory Training Requirement"): _k(["Training Requirement ID"], "Natural",
                                                 note="Grain is versioned by effective period; add Requirement "
                                                      "Effective From to the key where history is kept."),
    # ------------------------------------------------------------------ 20 Workforce Analytics
    ("20", "Human Capital Metric Value"): _k(["Metric Definition", "Metric Org Unit", "Metric Legal Entity",
                                              "Metric Country", "Metric Breakdown", "Metric Period Type",
                                              "Metric Period End Date"], "Composite",
                                             note="One of org unit, legal entity or country is populated; the "
                                                  "breakdown is empty for a total."),

    # ------------------------------------------------------------------ 21 Ownership & Stewardship
    ("21", "Data Governance Body"): _k(["Governance Body ID"], "Natural"),
    ("21", "Data Ownership Assignment"): _k(["Ownership Assignment ID"], "Natural"),
    # ------------------------------------------------------------------ 21 Glossary & Taxonomy Registry
    ("21", "Business Term"): _k(["Business Term ID"], "Natural"),
    ("21", "Business Term Relationship"): _k(["Source Business Term", "Term Relationship Type", "Related Business Term",
                                              "Related Taxonomy Element"], "Composite",
                                             note="Exactly one of the related term and the related taxonomy element "
                                                  "is populated."),
    ("21", "Taxonomy Element"): _k(["Taxonomy Element Key"], "Natural",
                                   note="The stable 'NN | Family | Object | Attribute' key, kept across releases."),
    ("21", "Taxonomy Release"): _k(["Taxonomy Release ID"], "Natural"),
    ("21", "Taxonomy Element Registration"): _k(["Registered Taxonomy Element", "Registering Release"], "Composite",
                                                note="Published Element Code is a release-specific label, never a "
                                                     "key (Source Notes)."),
    ("21", "Governance Decision"): _k(["Governance Decision ID"], "Natural"),
    # ------------------------------------------------------------------ 21 CDEs & Classification
    ("21", "Critical Data Element"): _k(["CDE ID"], "Natural"),
    ("21", "Data Classification Assignment"): _k(["Classified Taxonomy Element", "Classified Data Asset",
                                                  "Classification Scheme", "Classification Effective From"],
                                                 "Composite",
                                                 note="Exactly one of the classified taxonomy element and the "
                                                      "classified data asset is populated."),
    # ------------------------------------------------------------------ 21 Data Quality
    ("21", "Data Quality Issue"): _k(["DQ Issue ID"], "Natural"),
    # ------------------------------------------------------------------ 21 Catalog & Lineage
    ("21", "Data Asset"): _k(["Data Asset ID"], "Natural"),
    ("21", "Analytics Report & Dashboard Detail"): _fold("Only assets of type analytics report or dashboard carry it."),
    ("21", "Data Element Mapping"): _k(["Mapped Data Asset", "Physical Element Name", "Mapped Taxonomy Attribute"],
                                       "Composite"),
    ("21", "Lineage Link"): _k(["Lineage Link ID"], "Natural"),
    ("21", "System of Record Designation"): _k(["SoR Designation ID"], "Natural"),
    # ------------------------------------------------------------------ 21 Record Governance Metadata
    ("21", "Object Governance Profile"): _k(["Governed Business Object", "Profile Effective From"], "Composite"),
    ("21", "Record Governance Metadata"): _k(["Governed Record Object", "Governed Record Key", "Record Version Number"],
                                             "Composite",
                                             note="The record key is unique only within its object, so the governed "
                                                  "object completes the key."),
    # ------------------------------------------------------------------ 21 Metrics, Data Products & Contracts
    ("21", "Metric Definition"): _k(["Metric ID"], "Natural"),
    ("21", "Data Product"): _k(["Data Product ID"], "Natural"),
    ("21", "Data Product Input"): _k(["Input Data Product", "Input Taxonomy Element"], "Composite"),
    ("21", "Data Contract"): _k(["Data Contract ID"], "Natural"),
    ("21", "Semantic Model Binding"): _fold(),
    # ------------------------------------------------------------------ 21 AI & Model Data Governance
    ("21", "AI Use Case"): _k(["AI Use Case ID"], "Natural"),
    ("21", "AI Risk Classification"): _fold(),
    ("21", "AI Data Usage Approval"): _k(["Approved AI Use Case", "Approved Data Asset", "AI Data Usage Approved Date"],
                                         "Composite",
                                         note="The approval date tells successive approvals of the same use case and "
                                              "asset apart."),
    # W2-W4 merge (2026-10-15): 21 objects restored or added
    ("21", "Retention Rule"): _k(["Retention Rule ID"], "Natural",
                                 note="RET- (record class x governing requirement x effective period); replaces "
                                      "the wholesale 08 Retention Rule."),
}

REFS = {
    # ------------------------------------------------------------------ 19 Chart of Accounts & Ledgers
    ("19", "GL Account", "GL Account Chart"): CHART,
    ("19", "GL Account", "Parent Summary Account"): GL_ACCOUNT,
    ("19", "Chart Segment Value", "Segment Value Chart"): CHART,
    ("19", "Chart Segment Value", "Parent Segment Value"): SEGMENT_VALUE,
    ("19", "Chart Segment Value", "Represented Org Unit"): ORG_UNIT,
    ("19", "Chart Segment Value", "Represented Legal Entity"): LEGAL_ENTITY,
    ("19", "Chart Segment Value", "Represented Product"): PRODUCT,
    ("19", "Ledger", "Ledger Legal Entity"): LEGAL_ENTITY,
    ("19", "Ledger", "Ledger Chart of Accounts"): CHART,
    ("19", "Ledger", "Ledger Fiscal Calendar"): CALENDAR,      # Fiscal Calendar folds into 09 Calendar
    ("19", "Ledger", "Source Ledger"): LEDGER,
    ("19", "Financial Statement Line Mapping", "Mapped GL Account"): GL_ACCOUNT,
    ("19", "Financial Statement Line Mapping", "Mapped Statement Line"): STATEMENT_LINE,
    # ------------------------------------------------------------------ 19 Journals & Balances
    ("19", "Journal Entry", "Journal Ledger"): LEDGER,
    ("19", "Journal Entry", "Journal Prepared By"): EMPLOYEE,
    ("19", "Journal Entry", "Journal Approved By"): EMPLOYEE,
    ("19", "Journal Entry", "Reversed Journal"): JOURNAL,
    ("19", "GL Posting", "Posted Account"): GL_ACCOUNT,
    ("19", "GL Posting", "Cost Center Segment Value"): SEGMENT_VALUE,
    ("19", "GL Posting", "Other Segment Values"): SEGMENT_VALUE,
    ("19", "GL Posting", "Source Payable Invoice"): ("19", "Payable Invoice"),
    ("19", "GL Posting", "Source Supplier Payment"): ("19", "Supplier Payment"),
    ("19", "GL Posting", "Source Receivable Item"): ("19", "Receivable Item"),
    ("19", "GL Posting", "Source Payroll Run"): ("20", "Payroll Run"),
    ("19", "GL Account Balance", "Balance Ledger"): LEDGER,
    ("19", "GL Account Balance", "Balance GL Account"): GL_ACCOUNT,
    # ------------------------------------------------------------------ 19 Period Close & Consolidation
    ("19", "Accounting Period Status", "Status Ledger"): LEDGER,
    ("19", "Accounting Period Status", "Period Closed By"): EMPLOYEE,
    ("19", "Close Task", "Close Task Ledger"): LEDGER,
    ("19", "Close Task", "Close Task Owner"): EMPLOYEE,
    ("19", "Consolidation Scope Entity", "Scope Legal Entity"): LEGAL_ENTITY,
    ("19", "Consolidation Scope Entity", "Consolidated Fund Product"): PRODUCT,
    ("19", "Consolidation Scope Entity", "Seed Portfolio"): ("18", "Portfolio"),
    ("19", "Intercompany Balance", "Reporting Entity"): LEGAL_ENTITY,
    ("19", "Intercompany Balance", "Counterparty Entity"): LEGAL_ENTITY,
    ("19", "Intercompany Balance", "Intercompany GL Account"): GL_ACCOUNT,
    ("19", "Intercompany Balance", "Elimination Journal"): JOURNAL,
    ("19", "Intercompany Balance", "Source Intercompany Charge"): ("10", "Intercompany Charge"),
    # ------------------------------------------------------------------ 19 Payables
    ("19", "Payable Invoice", "Supplier"): PARTY,
    ("19", "Payable Invoice", "Invoice Legal Entity"): LEGAL_ENTITY,
    ("19", "Payable Invoice", "Source Data Invoice"): ("14", "Data Invoice"),
    ("19", "Payable Invoice", "Source Intermediary Communication Fee Invoice"):
        ("05", "Intermediary Communication Fee Invoice"),
    ("19", "Payable Invoice", "Source Partner Invoice"): ("05", "Partner Invoice"),
    ("19", "Payable Invoice", "Purchase Order Reference"): ("40", "Purchase Order"),
    ("19", "Payable Invoice Line", "Line Payable Invoice"): ("19", "Payable Invoice"),
    ("19", "Payable Invoice Line", "Line Expense Account"): GL_ACCOUNT,
    ("19", "Payable Invoice Line", "Line Cost Center"): SEGMENT_VALUE,
    ("19", "Payable Invoice Line", "Line Other Segment Values"): SEGMENT_VALUE,
    ("19", "Supplier Payment", "Payee Supplier"): PARTY,
    ("19", "Supplier Payment", "Paying Legal Entity"): LEGAL_ENTITY,
    ("19", "Supplier Payment", "Paying Bank Account"): ("43", "Corporate Bank Account"),
    ("19", "Supplier Payment", "Settled Partner Payment"): ("05", "Partner Payment"),
    ("19", "Supplier Payment Application", "Applied Supplier Payment"): ("19", "Supplier Payment"),
    ("19", "Supplier Payment Application", "Settled Payable Invoice"): ("19", "Payable Invoice"),
    # ------------------------------------------------------------------ 19 Receivables
    ("19", "Receivable Item", "Customer Party"): PARTY,
    ("19", "Receivable Item", "Debtor Fund Product"): PRODUCT,
    ("19", "Receivable Item", "Receivable Legal Entity"): LEGAL_ENTITY,
    ("19", "Receivable Item", "Source Fee Invoice"): ("47", "Fee Invoice"),
    ("19", "Receivable Item", "Source Fee Revenue Record"): ("10", "Fee Revenue Record"),
    ("19", "Receivable Item", "Source Intercompany Charge"): ("10", "Intercompany Charge"),
    ("19", "Cash Receipt Application", "Applied Receivable Item"): ("19", "Receivable Item"),
    ("19", "Cash Receipt Application", "Remitting Party"): PARTY,
    ("19", "Cash Receipt Application", "Bank Statement Entry Reference"): ("43", "Bank Statement Entry"),
    # ------------------------------------------------------------------ 19 Financial & Regulatory Reporting
    ("19", "Financial Statement", "Statement Reporting Entity"): LEGAL_ENTITY,
    ("19", "Financial Statement", "Statement Auditor"): PARTY,
    ("19", "Financial Statement Line Value", "Line Financial Statement"): ("19", "Financial Statement"),
    ("19", "Financial Statement Line Value", "Value Statement Line"): STATEMENT_LINE,
    ("19", "Regulatory Financial Return", "Return Filing Entity"): LEGAL_ENTITY,
    # ------------------------------------------------------------------ 19 Planning & Forecasting
    ("19", "Financial Plan Version", "Plan Approved By"): EMPLOYEE,
    ("19", "Financial Plan Line", "Line Plan Version"): ("19", "Financial Plan Version"),
    ("19", "Financial Plan Line", "Plan Legal Entity"): LEGAL_ENTITY,
    ("19", "Financial Plan Line", "Plan GL Account"): GL_ACCOUNT,
    ("19", "Financial Plan Line", "Plan Segment Values"): SEGMENT_VALUE,
    # ------------------------------------------------------------------ 19 Corporate Tax
    ("19", "Entity Tax Registration", "Registered Legal Entity"): LEGAL_ENTITY,
    ("19", "Entity Tax Registration", "Registering Tax Authority"): PARTY,
    ("19", "Tax Return", "Return Legal Entity"): LEGAL_ENTITY,
    ("19", "Tax Provision", "Provision Legal Entity"): LEGAL_ENTITY,
    ("19", "Tax Provision", "Provision Journal"): JOURNAL,
    ("19", "Transfer Pricing Documentation", "Documented Legal Entity"): LEGAL_ENTITY,
    ("19", "Transfer Pricing Documentation", "Documentation Owner"): EMPLOYEE,

    # ------------------------------------------------------------------ 20 Employee Master
    ("20", "Employee Personal Detail", "Client Party Cross-Reference"): PARTY,
    ("20", "Contingent Worker Detail", "Supplier Agency"): PARTY,
    ("20", "Contingent Worker Detail", "Supplier Contract Reference"): ("39", "Contract"),
    ("20", "Contingent Worker Detail", "Secondment Home Entity"): LEGAL_ENTITY,
    # ------------------------------------------------------------------ 20 Jobs, Positions & Assignments
    ("20", "Workforce Position", "Position Job Profile"): JOB_PROFILE,
    ("20", "Workforce Position", "Position Org Unit"): ORG_UNIT,
    ("20", "Workforce Position", "Position Legal Entity"): LEGAL_ENTITY,
    ("20", "Workforce Position", "Position Location"): OFFICE,
    ("20", "Workforce Position", "Position Cost Center"): SEGMENT_VALUE,
    ("20", "Workforce Position", "Budget Plan Line"): ("19", "Financial Plan Line"),
    ("20", "Employee Job Assignment", "Assigned Worker"): EMPLOYEE,
    ("20", "Employee Job Assignment", "Assigned Workforce Position"): POSITION,
    ("20", "Employee Job Assignment", "Assigned Job Profile"): JOB_PROFILE,
    # ------------------------------------------------------------------ 20 Lifecycle & Recruiting
    ("20", "Employee Lifecycle Event", "Event Employee"): EMPLOYEE,
    ("20", "Employee Lifecycle Event", "Related Reorganization"): ("09", "Reorganization Event"),
    ("20", "Leave of Absence", "Leave Employee"): EMPLOYEE,
    ("20", "Job Requisition", "Requisition Position"): POSITION,
    ("20", "Job Requisition", "Hiring Manager"): EMPLOYEE,
    ("20", "Candidate Application", "Applied Requisition"): ("20", "Job Requisition"),
    ("20", "Candidate Application", "Internal Candidate Employee"): EMPLOYEE,
    ("20", "Candidate Application", "Hired As Employee"): EMPLOYEE,
    ("20", "Background Screening", "Screened Employee"): EMPLOYEE,
    ("20", "Background Screening", "Screened Candidate Application"): ("20", "Candidate Application"),
    ("20", "Background Screening", "Screening Vendor"): PARTY,
    ("20", "Background Screening", "Related Individual Registration"): ("08", "Individual Registration"),
    # ------------------------------------------------------------------ 20 Compensation, Benefits & Payroll
    ("20", "Base Pay Record", "Paid Employee"): EMPLOYEE,
    ("20", "Variable Compensation Award", "Award Recipient"): EMPLOYEE,
    ("20", "Variable Compensation Award", "Linked Fund"): PRODUCT,
    ("20", "Deferred Award Tranche", "Tranche Award"): ("20", "Variable Compensation Award"),
    # Material Risk Taker Identification references removed with the object (CW-920).
    ("20", "Benefit Plan", "Offering Legal Entity"): LEGAL_ENTITY,
    ("20", "Benefit Plan", "Benefit Provider"): PARTY,
    ("20", "Benefit Enrollment", "Enrolled Employee"): EMPLOYEE,
    ("20", "Benefit Enrollment", "Enrolled Benefit Plan"): ("20", "Benefit Plan"),
    ("20", "Benefit Enrollment", "Own Plan Membership"): ("16", "Participant Plan Membership"),
    ("20", "Payroll Run", "Payroll Run Legal Entity"): LEGAL_ENTITY,
    ("20", "Payroll Run", "Payroll Provider"): PARTY,
    ("20", "Payroll Run", "Payroll Journal Entries"): JOURNAL,
    ("20", "Payroll Result", "Payroll Employee"): EMPLOYEE,
    ("20", "Payroll Result", "Payroll Run"): ("20", "Payroll Run"),
    ("20", "Payroll Result", "Incentive Payout Statements"): ("03", "Compensation Statement"),
    # ------------------------------------------------------------------ 20 Performance & Talent
    ("20", "Performance Review", "Reviewed Employee"): EMPLOYEE,
    ("20", "Performance Review", "Reviewer"): EMPLOYEE,
    ("20", "Performance Objective", "Objective Employee"): EMPLOYEE,
    ("20", "Performance Objective", "Linked Metric Definition"): METRIC,
    ("20", "Succession Plan Entry", "Succession Position"): POSITION,
    ("20", "Succession Plan Entry", "Successor Employee"): EMPLOYEE,
    # ------------------------------------------------------------------ 20 Learning & Competence
    ("20", "Learning Item", "Learning Provider"): PARTY,
    ("20", "Learning Completion", "Learner Employee"): EMPLOYEE,
    ("20", "Learning Completion", "Completed Learning Item"): ("20", "Learning Item"),
    ("20", "Learning Completion", "Satisfied Training Requirement"): ("20", "Mandatory Training Requirement"),
    ("20", "Mandatory Training Requirement", "Required Learning Item"): ("20", "Learning Item"),
    # ------------------------------------------------------------------ 20 Workforce Analytics
    ("20", "Human Capital Metric Value", "Metric Definition"): METRIC,
    ("20", "Human Capital Metric Value", "Metric Org Unit"): ORG_UNIT,
    ("20", "Human Capital Metric Value", "Metric Legal Entity"): LEGAL_ENTITY,

    # ------------------------------------------------------------------ 21 Ownership & Stewardship
    ("21", "Data Governance Body", "Governance Body Chair"): EMPLOYEE,
    ("21", "Data Governance Body", "Parent Governance Body"): ("21", "Data Governance Body"),
    ("21", "Data Ownership Assignment", "Assigned Employee"): EMPLOYEE,
    ("21", "Data Ownership Assignment", "Governed Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "Data Ownership Assignment", "Governed Element Registered In Release"): RELEASE,
    ("21", "Data Ownership Assignment", "Governed Code List"): CODE_LIST,
    ("21", "Data Ownership Assignment", "Governed Business Term"): ("21", "Business Term"),
    ("21", "Data Ownership Assignment", "Governed Data Product"): DATA_PRODUCT,
    ("21", "Data Ownership Assignment", "Governed Data Asset"): DATA_ASSET,
    ("21", "Data Ownership Assignment", "Governed Data Quality Rule"): DQ_RULE,
    ("21", "Data Ownership Assignment", "Governed Metric"): METRIC,
    ("21", "Data Ownership Assignment", "Appointing Governance Body"): ("21", "Data Governance Body"),
    # ------------------------------------------------------------------ 21 Glossary & Taxonomy Registry
    ("21", "Business Term", "Governing Code List"): CODE_LIST,
    ("21", "Business Term", "Defining Metric"): METRIC,
    ("21", "Business Term Relationship", "Source Business Term"): ("21", "Business Term"),
    ("21", "Business Term Relationship", "Related Business Term"): ("21", "Business Term"),
    ("21", "Business Term Relationship", "Related Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "Business Term Relationship", "Related Element Registered In Release"): RELEASE,
    ("21", "Taxonomy Element", "First Registered Release"): RELEASE,
    ("21", "Taxonomy Element", "Successor Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "Taxonomy Release", "Predecessor Release"): RELEASE,
    ("21", "Taxonomy Element Registration", "Registered Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "Taxonomy Element Registration", "Registering Release"): RELEASE,
    ("21", "Taxonomy Element Registration", "Parent Business Object"): TAXONOMY_ELEMENT,
    ("21", "Taxonomy Element Registration", "Element Code List"): CODE_LIST,
    ("21", "Governance Decision", "Applied In Release"): RELEASE,
    # ------------------------------------------------------------------ 21 CDEs & Classification
    ("21", "Critical Data Element", "CDE Taxonomy Attribute"): TAXONOMY_ELEMENT,
    ("21", "Critical Data Element", "CDE Registered In Release"): RELEASE,
    ("21", "Critical Data Element", "CDE Scoped Data Product"): DATA_PRODUCT,
    ("21", "Critical Data Element", "CDE Owner"): EMPLOYEE,
    ("21", "Data Classification Assignment", "Classified Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "Data Classification Assignment", "Classified Element Registered In Release"): RELEASE,
    ("21", "Data Classification Assignment", "Classified Data Asset"): DATA_ASSET,
    # ------------------------------------------------------------------ 21 Data Quality
    ("21", "Data Quality Rule", "DQ Rule Target Element"): TAXONOMY_ELEMENT,
    ("21", "Data Quality Rule", "DQ Rule Target Registered In Release"): RELEASE,
    ("21", "Data Quality Rule", "DQ Rule Target Data Asset"): DATA_ASSET,
    ("21", "Data Quality Result", "Tested Data Asset"): DATA_ASSET,
    ("21", "Data Quality Result", "Tested Load"): LOAD,
    ("21", "Data Quality Issue", "Raising DQ Result"): ("21", "Data Quality Result"),
    ("21", "Data Quality Issue", "Related DQ Rule"): DQ_RULE,
    ("21", "Data Quality Issue", "Affected Data Asset"): DATA_ASSET,
    ("21", "Data Quality Issue", "Affected CDE"): ("21", "Critical Data Element"),
    ("21", "Data Quality Issue", "DQ Issue Owner"): EMPLOYEE,
    ("21", "Data Quality Issue", "Linked Vendor Data Issue"): ("14", "Vendor Data Issue"),
    # ------------------------------------------------------------------ 21 Catalog & Lineage
    ("21", "Data Asset", "Hosting System"): APPLICATION,
    ("21", "Data Asset", "Cataloged Licensed Dataset"): DATASET,
    ("21", "Data Asset", "Cataloged Technical Feed"): ("06", "Data Feed"),
    ("21", "Data Asset", "Providing Party"): PARTY,
    ("21", "Analytics Report & Dashboard Detail", "Report Primary Data Product"): DATA_PRODUCT,
    ("21", "Data Element Mapping", "Mapped Data Asset"): DATA_ASSET,
    ("21", "Data Element Mapping", "Mapped Taxonomy Attribute"): TAXONOMY_ELEMENT,
    ("21", "Data Element Mapping", "Mapped Attribute Registered In Release"): RELEASE,
    ("21", "Lineage Link", "Lineage Source Data Asset"): DATA_ASSET,
    ("21", "Lineage Link", "Lineage Target Data Asset"): DATA_ASSET,
    ("21", "Lineage Link", "Lineage Target Client Data Feed"): ("12", "Client Data Feed"),
    ("21", "Lineage Link", "Lineage Target Client Report"): ("12", "Report Definition"),
    ("21", "System of Record Designation", "Designated Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "System of Record Designation", "Designated Element Registered In Release"): RELEASE,
    ("21", "System of Record Designation", "Designated System"): APPLICATION,
    ("21", "System of Record Designation", "Designated Data Asset"): DATA_ASSET,
    ("21", "System of Record Designation", "Designating Decision"): ("21", "Governance Decision"),
    # ------------------------------------------------------------------ 21 Record Governance Metadata
    ("21", "Object Governance Profile", "Governed Business Object"): TAXONOMY_ELEMENT,
    ("21", "Object Governance Profile", "Profile Registered In Release"): RELEASE,
    ("21", "Object Governance Profile", "Object Records Retention Rule"): ("21", "Retention Rule"),
    ("21", "Record Governance Metadata", "Governed Record Object"): TAXONOMY_ELEMENT,
    ("21", "Record Governance Metadata", "Governed Record Object Release"): RELEASE,
    ("21", "Record Governance Metadata", "Record Data Owner"): EMPLOYEE,
    ("21", "Record Governance Metadata", "Record Data Steward"): EMPLOYEE,
    ("21", "Record Governance Metadata", "System of Record"): APPLICATION,
    ("21", "Record Governance Metadata", "Source System"): APPLICATION,
    ("21", "Record Governance Metadata", "Records Retention Rule"): ("21", "Retention Rule"),
    ("21", "Record Governance Metadata", "Source Dataset"): DATASET,
    ("21", "Record Governance Metadata", "Source Load"): LOAD,
    # ------------------------------------------------------------------ 21 Metrics, Data Products & Contracts
    ("21", "Metric Definition", "Registered Measure Definition"): ("06", "Measure Definition"),
    ("21", "Metric Definition", "Registered Market Share Definition"): ("11", "Market Share Definition"),
    ("21", "Metric Definition", "Registered Profitability Measure"): ("10", "Profitability Measure Definition"),
    ("21", "Metric Definition", "Metric Source Data Product"): DATA_PRODUCT,
    ("21", "Data Product", "Upstream Data Products"): DATA_PRODUCT,
    ("21", "Data Product Input", "Input Data Product"): DATA_PRODUCT,
    ("21", "Data Product Input", "Input Taxonomy Element"): TAXONOMY_ELEMENT,
    ("21", "Data Product Input", "Input Registered In Release"): RELEASE,
    ("21", "Data Contract", "Contracted Data Product"): DATA_PRODUCT,
    ("21", "Data Contract", "Consumer Org Unit"): ORG_UNIT,
    ("21", "Data Contract", "Consumer External Party"): PARTY,
    ("21", "Data Contract", "Contracted DQ Rules"): DQ_RULE,
    ("21", "Semantic Model Binding", "Bound Certified Metrics"): METRIC,
    # ------------------------------------------------------------------ 21 AI & Model Data Governance
    ("21", "AI Use Case", "AI Use Case Business Owner"): EMPLOYEE,
    ("21", "AI Use Case", "Model Name"): ("37", "Model Inventory Entry"),
    ("21", "AI Use Case", "Model Provider"): PARTY,
    ("21", "AI Data Usage Approval", "Approved AI Use Case"): ("21", "AI Use Case"),
    ("21", "AI Data Usage Approval", "Approved Data Asset"): DATA_ASSET,
    ("21", "AI Data Usage Approval", "Covering Permitted Use Grant"): ("14", "Permitted Use Grant"),
    ("21", "Retention Rule", "Governing Records Policy"): ("38", "Policy"),
}

# Reference left out of REFS (no single object masters the target):
#   ("19", "GL Posting", "Source Finance Record")  <Reference (FRR- / WVR- / DCO- / ACR- / CCA- / ARN- / ICC-)>, owner 10:
#       polymorphic over 10 Fee Revenue Record, Waiver Record, Distribution Cost Item, Accrual, Contract Cost Asset,
#       Allocation Run and Intercompany Charge; already recorded as unresolved in keys_g3_06_07_10.py.
#
# Registered here although keys_g7_17_21.py left them out while 19 GL Account was in no data product: GL Posting.Posted
# Account and Financial Statement Line Mapping.Mapped GL Account now point to 19 GL Account, and Accounting Period
# Status.Status Ledger to 19 Ledger. Models that still join Posted Account or Mapped GL Account to 10 Account Mapping
# (models_f3.py, models_c6_planning_finance.py) will warn until they move the join to a GL Account entity.
