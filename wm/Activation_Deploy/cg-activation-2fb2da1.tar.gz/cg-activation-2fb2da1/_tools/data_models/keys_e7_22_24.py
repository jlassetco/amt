"""Key and link registry extension: Data Domains 22-24 (enterprise expansion, Phase 2 Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Keys every object of 22 Market Data & Pricing,
23 Investment Research and 24 Portfolio Management & Construction; keys_g8_22_30.py keys none of them.

Conventions used here:
- Versioned objects whose stable code is a separate attribute from the version (pricing policy, research model, research
  signal, research publication) are Composite on code + version. Their inbound references hold the code (or the code and
  version in one value); the model resolves the version in effect.
- Objects whose grain names a subject that one of several typed attributes carries (issuer, instrument, sector, country;
  portfolio or model portfolio; manager or team) list every subject attribute in the key: only the attribute(s) of the
  row's subject type are populated, the others are blank.
- Several in-domain references hold a composite key as one value ("USFUNDS-VC / 2026-10-06", "STR-00123 v7"); the model
  splits it into the target's key columns.

W2-W4 merge (2026-10-15): the 24 W3 pass is applied. Tax Budget is keyed Budget Portfolio / Tax Year (retail SMA
budgets are 46 Account Tax Budget, CW-048); Capital Market Assumption Set (CMASET-) and Model Lineup (MLNUP-) are keyed
by ID and version, and the CMA assumption lines, Model Lineup Position and Model Building Block by their grains. The
30 private-markets objects 24 held (Commitment Pacing Plan, Private Asset Valuation Detail) are removed with 30 (CW-930).
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


INSTRUMENT = ("17", "Instrument")
CORP_ACTION = ("17", "Corporate Action Event")
PARTY = ("02", "Party")
EMPLOYEE = ("20", "Employee")
PORTFOLIO = ("18", "Portfolio")
DATASET = ("14", "Dataset")
BENCHMARK = ("01", "Benchmark")
STRATEGY = ("01", "Investment Strategy")
MODEL_PORTFOLIO = ("01", "Model Portfolio")
MODEL_INVENTORY = ("37", "Model Inventory Entry")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
GEO = ("09", "Geographic Unit")
CLASS_SCHEME = ("09", "Classification Scheme")
CALENDAR = ("09", "Calendar")
AI_USE_CASE = ("21", "AI Use Case")
SHARE_CLASS_NAV = ("27", "Share Class NAV")

PRICING_POLICY = ("22", "Pricing Policy")
PRICING_POINT = ("22", "Pricing Point")
PRICE_OBS = ("22", "Price Observation")
APPROVED_PRICE = ("22", "Approved Price")
FVD = ("22", "Fair Value Determination")
TRIGGER_EVENT = ("22", "Fair Value Trigger Event")
VAL_COMMITTEE = ("22", "Valuation Committee")
CURVE = ("22", "Curve Definition")
RESEARCH_MODEL = ("23", "Research Model")
RESEARCH_UNIVERSE = ("23", "Research Universe")
RESEARCH_PUB = ("23", "Research Publication")
ISSUER_MEETING = ("23", "Issuer Meeting")
INV_COMMITTEE = ("24", "Investment Committee")
IC_DECISION = ("24", "Investment Committee Decision")
ALLOC_POLICY = ("24", "Asset Allocation Policy")
TARGET_SET = ("24", "Target Allocation Set")
INV_DECISION = ("24", "Investment Decision")
REBALANCE_RUN = ("24", "Rebalance Run")

KEYS = {
    # ------------------------------------------------------------------ 22 Pricing Policy
    ("22", "Pricing Policy"): _k(["Pricing Policy Code", "Pricing Policy Version"], "Composite",
                                 note="The code is stable across versions; references hold the code only and resolve "
                                      "to the version in effect."),
    ("22", "Pricing Source Hierarchy Rule"): _k(["Hierarchy Rule Code", "Source Rank", "Hierarchy Rule Effective From"],
                                                "Composite",
                                                note="The rule code names the policy and instrument scope; one row per "
                                                     "source rank and effective period."),
    ("22", "Price Tolerance Rule"): _k(["Tolerance Rule Code", "Tolerance Rule Effective From"], "Composite",
                                       note="The rule code names the policy, scope and check type, and is stable across "
                                            "effective periods; references hold the code only."),
    ("22", "Pricing Point"): _k(["Pricing Point Code"], "Natural"),
    # ------------------------------------------------------------------ 22 Price Observations
    ("22", "Price Observation"): _k(["Price Observation Key"], "Surrogate",
                                    note="System-assigned surrogate carried as an attribute (Source Notes); the grain "
                                         "columns (instrument, price type, origin, dataset or broker, timestamp) are "
                                         "unique but no other domain matches on them."),
    ("22", "Evaluated Price Detail"): _fold(),
    ("22", "Broker Quote Detail"): _fold(),
    # ------------------------------------------------------------------ 22 Approved Prices & Controls
    ("22", "Approved Price"): _k(["Approved Price ID"], "Natural",
                                 note="PRICE- encodes instrument, pricing point, price date and version."),
    ("22", "Price Validation Exception"): _k(["Exception Approved Price", "Breached Tolerance Rule",
                                              "Exception Raised Timestamp"], "Composite"),
    ("22", "Price Override"): _k(["Overridden Approved Price", "Override Sequence"], "Composite"),
    ("22", "Price Challenge"): _k(["Price Challenge ID"], "Natural"),
    # ------------------------------------------------------------------ 22 Fair Value & Valuation Governance
    ("22", "Valuation Committee"): _k(["Valuation Committee Code"], "Natural"),
    ("22", "Valuation Committee Member"): _k(["Membership Committee", "Committee Member", "Membership Effective From"],
                                             "Composite"),
    ("22", "Valuation Committee Meeting"): _k(["Meeting Committee", "Meeting Date"], "Composite"),
    ("22", "Fair Value Determination"): _k(["Fair Value Determination ID"], "Natural",
                                           note="Each attempt keeps its own FVD- ID; at most one approved per "
                                                "instrument x valuation date x pricing point x portfolio."),
    ("22", "Valuation Input"): _k(["Input Determination", "Valuation Input Type"], "Composite"),
    ("22", "Fair Value Trigger Event"): _k(["Trigger Event Key"], "Surrogate",
                                           note="System-assigned surrogate carried as an attribute; the affected market, "
                                                "issuer or instrument has no single attribute to key on."),
    ("22", "Fair Value Factor"): _k(["Fair Value Factor Key"], "Surrogate",
                                    note="System-assigned surrogate carried as an attribute; it is what Approved Price."
                                         "Applied Fair Value Factor holds."),
    ("22", "Valuation Back-Test"): _k(["Back-Tested Approved Price", "Back-Test Comparison Type", "Comparison Date"],
                                      "Composite",
                                      note="Back-Tested Determination is left out: it follows from the approved price "
                                           "version tested."),
    # ------------------------------------------------------------------ 22 FX & Reference Rates
    ("22", "FX Rate Observation"): _k(["FX Rate Observation ID"], "Natural"),
    ("22", "Reference Rate Fixing"): _k(["Fixed Reference Rate", "Fixing Tenor", "Fixing Value Type", "Fixing Date"],
                                        "Composite"),
    # ------------------------------------------------------------------ 22 Curves & Surfaces
    ("22", "Curve Definition"): _k(["Curve ID"], "Natural"),
    ("22", "Curve Point Observation"): _k(["Observed Curve", "Curve As-Of Date", "Curve Point Tenor"], "Composite"),
    ("22", "Volatility Surface Point"): _k(["Observed Surface", "Surface As-Of Date", "Expiry Tenor", "Strike Coordinate"],
                                          "Composite"),
    # ------------------------------------------------------------------ 22 Index Data
    ("22", "Index Level Observation"): _k(["Index Benchmark", "Level Date", "Index Level Variant", "Level Currency"],
                                          "Composite"),
    ("22", "Index Constituent"): _k(["Constituent Benchmark", "Constituent Instrument", "Vendor Constituent Identifier",
                                     "Constituent Effective Date"], "Composite",
                                    note="Exactly one of Constituent Instrument and Vendor Constituent Identifier is "
                                         "populated (the latter for members 17 has not set up)."),
    ("22", "Index Change Announcement"): _k(["Changed Benchmark", "Affected Index Instrument", "Index Change Type",
                                             "Change Effective Date", "Announcement Date"], "Composite",
                                            note="24 Rebalance Index Change Trigger references it without the "
                                                 "announcement date; the model takes the latest announcement."),
    # ------------------------------------------------------------------ 22 Instrument Market Data
    ("22", "Pricing Analytics Observation"): _k(["Analytics Instrument", "Analytics As-Of Date", "Analytics Source Dataset",
                                                 "Pricing Analytic Measure"], "Composite",
                                                note="The grain's source is the 14 dataset; Approved Analytics Value "
                                                     "Indicator marks the one approved row per instrument x date x "
                                                     "measure."),
    ("22", "Instrument Factor Observation"): _k(["Factor Observation Instrument", "Instrument Factor Type",
                                                 "Factor Effective Date"], "Composite"),
    ("22", "ETF Market Statistic"): _k(["ETF Instrument", "Statistic Date"], "Composite"),

    # ------------------------------------------------------------------ 23 Research Coverage
    ("23", "Research Coverage Assignment"): _k(["Research Coverage Assignment ID"], "Natural"),
    ("23", "Research Universe"): _k(["Research Universe Code"], "Natural"),
    ("23", "Research Universe Member"): _k(["Member Universe", "Member Subject Type", "Member Issuer", "Member Instrument",
                                            "Member Sector Scheme", "Member Sector Code", "Member Geography",
                                            "Member Market Segment", "Membership Effective From"], "Composite",
                                           note="Only the subject attributes of the row's Member Subject Type are "
                                                "populated."),
    # ------------------------------------------------------------------ 23 Recommendations & Credit Views
    ("23", "Research Recommendation"): _k(["Research Recommendation ID"], "Natural"),
    ("23", "Recommendation Valuation Basis"): _fold(),
    ("23", "Internal Credit Assessment"): _k(["Assessed Party", "Assessed Instrument", "Credit Analyst",
                                              "Internal Credit Rating Scale", "Assessment Effective From"], "Composite",
                                             note="Assessed Instrument is blank for a party-level assessment; the party "
                                                  "is always populated (derived from the issuer on instrument rows)."),
    # ------------------------------------------------------------------ 23 Estimates, Models & Signals
    ("23", "Analyst Estimate"): _k(["Estimated Issuer", "Estimating Analyst", "Estimate Metric", "Fiscal Period Type",
                                    "Fiscal Period End Date", "Adjusted Basis Indicator", "Estimate Date"], "Composite"),
    ("23", "Research Model"): _k(["Research Model Key", "Research Model Version"], "Composite",
                                 note="The key is stable across versions; references hold the key only and resolve to "
                                      "the version in effect."),
    ("23", "Economic Forecast"): _k(["Forecast Geography", "Economic Indicator", "Forecast Period Type",
                                     "Forecast Period End Date", "Forecast Date"], "Composite"),
    ("23", "Research Signal Definition"): _k(["Research Signal Code", "Research Signal Version"], "Composite",
                                             note="The code is stable across versions; Research Signal Score holds code "
                                                  "and version in one value."),
    ("23", "Research Signal Score"): _k(["Scored Signal", "Scored Instrument", "Score As-Of Date"], "Composite"),
    # ------------------------------------------------------------------ 23 Research Publications
    ("23", "Research Publication"): _k(["Research Publication ID", "Publication Version"], "Composite",
                                       note="A correction is a new version of the same RPUB- ID; references hold the ID "
                                            "only."),
    ("23", "Publication Subject"): _k(["Subject Publication", "Publication Subject Type", "Subject Issuer",
                                       "Subject Instrument", "Subject Sector Scheme", "Subject Sector Code",
                                       "Subject Geography", "Subject Theme"], "Composite",
                                      note="Only the subject attributes of the row's Publication Subject Type are "
                                           "populated; subjects are held per publication, not per version."),
    ("23", "Publication Review"): _fold("Its grain is the publication version, the parent's grain."),
    # ------------------------------------------------------------------ 23 Issuer Meetings
    ("23", "Issuer Meeting"): _k(["Issuer Meeting ID"], "Natural"),
    ("23", "Issuer Meeting Participant"): _k(["Participant Meeting", "Internal Participant", "External Participant",
                                              "Meeting Participant Role"], "Composite",
                                             note="Exactly one of Internal Participant and External Participant is "
                                                  "populated."),
    ("23", "Issuer Meeting Topic"): _k(["Topic Meeting", "Topic Sequence"], "Composite"),
    ("23", "Meeting MNPI Assessment"): _fold(),
    # ------------------------------------------------------------------ 23 Third-Party Research
    ("23", "Research Provider Profile"): _k(["Research Provider Party"], "Composite",
                                            note="A role profile of the 02 party, one per provider."),
    ("23", "Research Service Subscription"): _k(["Subscribed Provider", "Subscribed Service Type",
                                                 "Subscribing Research Team", "Subscription Start Date"], "Composite"),
    ("23", "Research Consumption Record"): _k(["Consuming Employee", "Consumed Provider", "Research Interaction Type",
                                               "Interaction Timestamp"], "Composite"),
    ("23", "Research Evaluation Round"): _k(["Evaluated Provider", "Evaluation Period Type", "Evaluation Period End Date",
                                             "Evaluator"], "Composite"),
    ("23", "Evaluation Criterion Score"): _k(["Scored Evaluation Round", "Evaluation Criterion"], "Composite",
                                             note="Scored Evaluation Round holds the round's composite key in one "
                                                  "value (provider / period end / evaluator)."),

    # ------------------------------------------------------------------ 24 Investment Governance
    ("24", "Investment Committee"): _k(["Investment Committee Code"], "Natural"),
    ("24", "Investment Committee Member"): _k(["Member Committee", "Committee Member", "Committee Member Role",
                                               "Member Effective From"], "Composite"),
    ("24", "Investment Committee Meeting"): _k(["Meeting Committee", "Meeting Date"], "Composite"),
    ("24", "Investment Committee Decision"): _k(["Decision Committee", "Decision Meeting Date", "Decision Item Number"],
                                                "Composite",
                                                note="Referenced as one value: committee / meeting date / item."),
    # ------------------------------------------------------------------ 24 Portfolio Management Assignment
    ("24", "Portfolio Management Assignment"): _k(["Assigned Portfolio", "Assigned Manager", "Assigned Investment Team",
                                                   "Portfolio Management Role", "Assignment Effective From"],
                                                  "Composite",
                                                  note="Assigned Manager is blank when only a team is assigned."),
    # ------------------------------------------------------------------ 24 Asset Allocation
    ("24", "Asset Allocation Policy"): _k(["Policy Strategy", "Policy Product", "Policy Model Portfolio",
                                           "Policy Version Number"], "Composite",
                                          note="Only the subject attribute of the policy (strategy, product or model "
                                               "portfolio) is populated; references hold subject and version in one "
                                               "value (STR-00123 v7)."),
    ("24", "Asset Allocation Policy Line"): _k(["Line Allocation Policy", "Policy Asset Class", "Policy Sub-Class"],
                                               "Composite"),
    ("24", "Glide Path Point"): _k(["Glide Path Policy", "Years to Target Date", "Glide Path Asset Class",
                                    "Glide Path Sub-Class"], "Composite"),
    ("24", "Tactical Allocation View"): _k(["View Strategy", "View Asset Class", "View Segment", "View Date"],
                                           "Composite",
                                           note="View Strategy is blank for a house view."),
    # ------------------------------------------------------------------ 24 Targets & Constraints
    ("24", "Target Allocation Set"): _k(["Target Set ID"], "Natural"),
    ("24", "Target Allocation Line"): _k(["Line Target Set", "Target Component Type", "Target Instrument",
                                          "Target Asset Class", "Target Classification Scheme",
                                          "Target Classification Value", "Target Country", "Target Currency",
                                          "Target Sleeve Portfolio"], "Composite",
                                         note="Only the component attributes of the line's Target Component Type are "
                                              "populated (for classification lines: scheme and node)."),
    ("24", "Model Change Summary"): _fold("Model portfolio subjects only."),
    ("24", "Portfolio Construction Constraint"): _k(["Constrained Portfolio", "Constrained Model Portfolio",
                                                     "Constraint Type", "Constraint Scope", "Constraint Effective From"],
                                                    "Composite",
                                                    note="Exactly one of the portfolio and the model portfolio is "
                                                         "populated."),
    # ------------------------------------------------------------------ 24 Investment Decisions
    ("24", "Investment Decision"): _k(["Investment Decision ID"], "Natural"),
    ("24", "Decision Rationale"): _fold(),
    ("24", "Investment Decision Scope"): _k(["Scoped Decision", "Scope Portfolio", "Scope Model Portfolio"], "Composite",
                                            note="Exactly one of the portfolio and the model portfolio is populated."),
    # ------------------------------------------------------------------ 24 Rebalancing & Trade Proposals
    ("24", "Rebalance Run"): _k(["Rebalance Run ID"], "Natural"),
    ("24", "Rebalance Index Change Trigger"): _k(["Index Change Rebalance Run", "Triggering Index Change Announcement"],
                                                 "Composite"),
    ("24", "Rebalance Portfolio Result"): _k(["Result Rebalance Run", "Result Portfolio"], "Composite"),
    ("24", "Proposed Trade"): _k(["Proposed Trade ID"], "Natural",
                                 note="System key with no prefix; covers run-generated and manual proposals."),
    ("24", "Proposed Lot Selection"): _k(["Lot Selection Trade", "Selected Tax Lot"], "Composite"),
    ("24", "Tax Budget"): _k(["Budget Portfolio", "Tax Year"], "Composite",
                             note="Institutional separate-account portfolio (or sleeve) budgets only; retail SMA "
                                  "budgets are 46 Account Tax Budget (CW-048)."),
    # ------------------------------------------------------------------ 24 Cash Planning
    ("24", "Investable Cash Forecast"): _k(["Forecast Portfolio", "Forecast Date", "Forecast Value Date",
                                            "Forecast Currency"], "Composite"),
    ("24", "Cash Forecast Adjustment"): _k(["Adjusted Cash Forecast", "Cash Forecast Adjustment Source",
                                            "Adjustment Sequence"], "Composite"),
    # ------------------------------------------------------------------ 24 ETF Baskets
    ("24", "ETF Basket"): _k(["Basket ID"], "Natural",
                             note="BSKT- tells apart several custom baskets of one share class on one day."),
    ("24", "ETF Basket Constituent"): _k(["Constituent Basket", "Constituent Instrument"], "Composite"),
    ("24", "Custom Basket Approval"): _fold("Custom baskets only."),
    # W2-W4 merge (2026-10-15): 24 objects restored or added
    ("24", "Capital Market Assumption Set"): _k(["Capital Market Assumption Set ID", "CMA Set Version"], "Composite",
                                                note="CMASET- / version."),
    ("24", "Asset Class Return Assumption"): _k(["Return Assumption CMA Set", "Assumption Asset Class",
                                                 "Assumption Sub-Class"], "Composite",
                                                note="The set reference carries the CMASET- id and version; "
                                                     "Assumption Sub-Class is empty for an asset-class-level line."),
    ("24", "Asset Class Correlation Assumption"): _k(["Correlation CMA Set", "First Assumption Line",
                                                      "Second Assumption Line"], "Composite"),
    ("24", "Model Lineup"): _k(["Model Lineup ID", "Model Lineup Version"], "Composite", note="MLNUP- / version."),
    ("24", "Model Lineup Position"): _k(["Position Model Lineup", "Position Model Portfolio"], "Composite"),
    ("24", "Model Building Block"): _k(["Building Block Model Portfolio", "Building Block Share Class",
                                        "Building Block Instrument", "Building Block Role",
                                        "Building Block Effective From"], "Composite",
                                       note="Exactly one of the share class or instrument is populated."),
}

REFS = {
    # ------------------------------------------------------------------ 22 Pricing Policy
    ("22", "Pricing Policy", "Policy Owner Entity"): LEGAL_ENTITY,
    ("22", "Pricing Policy", "Outsourced Pricing Provider"): PARTY,
    ("22", "Pricing Source Hierarchy Rule", "Hierarchy Policy Code"): PRICING_POLICY,
    ("22", "Pricing Source Hierarchy Rule", "Hierarchy Pricing Point"): PRICING_POINT,
    ("22", "Pricing Source Hierarchy Rule", "Ranked Source Dataset"): DATASET,
    ("22", "Price Tolerance Rule", "Tolerance Policy Code"): PRICING_POLICY,
    ("22", "Price Tolerance Rule", "Cataloged Data Quality Rule"): ("21", "Data Quality Rule"),
    ("22", "Pricing Point", "Pricing Calendar"): CALENDAR,
    # ------------------------------------------------------------------ 22 Price Observations
    ("22", "Price Observation", "Observed Instrument"): INSTRUMENT,
    ("22", "Price Observation", "Observed Listing"): ("17", "Instrument Listing"),
    ("22", "Price Observation", "Source Dataset"): DATASET,
    ("22", "Price Observation", "Adjusting Corporate Action Event"): CORP_ACTION,
    ("22", "Broker Quote Detail", "Quoting Broker"): PARTY,
    # ------------------------------------------------------------------ 22 Approved Prices & Controls
    ("22", "Approved Price", "Priced Instrument"): INSTRUMENT,
    ("22", "Approved Price", "Approved Pricing Point"): PRICING_POINT,
    ("22", "Approved Price", "Supersedes Approved Price"): APPROVED_PRICE,
    ("22", "Approved Price", "Own Fund Swing Decision"): ("27", "Swing Pricing Decision"),
    ("22", "Approved Price", "Selected Observation"): PRICE_OBS,
    ("22", "Approved Price", "Applied Price Override"): ("22", "Price Override"),
    ("22", "Approved Price", "Applied Fair Value Determination"): FVD,
    ("22", "Approved Price", "Applied Fair Value Factor"): ("22", "Fair Value Factor"),
    ("22", "Approved Price", "Own Fund NAV Record"): SHARE_CLASS_NAV,
    ("22", "Approved Price", "Price Approved By"): EMPLOYEE,
    ("22", "Price Validation Exception", "Exception Approved Price"): APPROVED_PRICE,
    ("22", "Price Validation Exception", "Breached Tolerance Rule"): ("22", "Price Tolerance Rule"),
    ("22", "Price Validation Exception", "Exception Resolved By"): EMPLOYEE,
    ("22", "Price Validation Exception", "Resulting Price Challenge"): ("22", "Price Challenge"),
    ("22", "Price Override", "Overridden Approved Price"): APPROVED_PRICE,
    ("22", "Price Override", "Override Requested By"): EMPLOYEE,
    ("22", "Price Override", "Override Approved By"): EMPLOYEE,
    ("22", "Price Challenge", "Challenged Observation"): PRICE_OBS,
    ("22", "Price Challenge", "Challenged Vendor"): PARTY,
    ("22", "Price Challenge", "Challenge Raised By"): EMPLOYEE,
    ("22", "Price Challenge", "Related Vendor Data Issue"): ("14", "Vendor Data Issue"),
    # ------------------------------------------------------------------ 22 Fair Value & Valuation Governance
    ("22", "Valuation Committee", "Governing Pricing Policy"): PRICING_POLICY,
    ("22", "Valuation Committee", "Committee Owner Entity"): LEGAL_ENTITY,
    ("22", "Valuation Committee Member", "Membership Committee"): VAL_COMMITTEE,
    ("22", "Valuation Committee Member", "Committee Member"): EMPLOYEE,
    ("22", "Valuation Committee Meeting", "Meeting Committee"): VAL_COMMITTEE,
    ("22", "Fair Value Determination", "Fair Valued Instrument"): INSTRUMENT,
    ("22", "Fair Value Determination", "Determination Pricing Point"): PRICING_POINT,
    ("22", "Fair Value Determination", "Valued Portfolio"): PORTFOLIO,
    ("22", "Fair Value Determination", "Triggering Event"): TRIGGER_EVENT,
    ("22", "Fair Value Determination", "Valuation Model Name"): MODEL_INVENTORY,
    ("22", "Fair Value Determination", "Valuation Prepared By"): EMPLOYEE,
    ("22", "Fair Value Determination", "External Valuation Agent"): PARTY,
    ("22", "Fair Value Determination", "Approving Meeting"): ("22", "Valuation Committee Meeting"),
    ("22", "Valuation Input", "Input Determination"): FVD,
    ("22", "Fair Value Trigger Event", "Affected Instrument"): INSTRUMENT,
    ("22", "Fair Value Trigger Event", "Move Reference Benchmark"): BENCHMARK,
    ("22", "Fair Value Factor", "Factor Instrument"): INSTRUMENT,
    ("22", "Fair Value Factor", "Factor Pricing Point"): PRICING_POINT,
    ("22", "Fair Value Factor", "Factor Source Dataset"): DATASET,
    ("22", "Fair Value Factor", "Factor Triggering Event"): TRIGGER_EVENT,
    ("22", "Valuation Back-Test", "Back-Tested Approved Price"): APPROVED_PRICE,
    ("22", "Valuation Back-Test", "Back-Tested Determination"): FVD,
    ("22", "Valuation Back-Test", "Comparison Transaction"): ("18", "Portfolio Transaction"),
    ("22", "Valuation Back-Test", "Back-Test Reviewed By"): EMPLOYEE,
    # ------------------------------------------------------------------ 22 FX & Reference Rates
    ("22", "FX Rate Observation", "Observed FX Rate Type"): ("09", "FX Rate Type"),
    ("22", "Reference Rate Fixing", "Rate Administrator"): PARTY,
    ("22", "Reference Rate Fixing", "Fixing Source Dataset"): DATASET,
    # ------------------------------------------------------------------ 22 Curves & Surfaces
    ("22", "Curve Definition", "Surface Underlying Instrument"): INSTRUMENT,
    ("22", "Curve Definition", "Surface Underlying Benchmark"): BENCHMARK,
    ("22", "Curve Definition", "Curve Source Dataset"): DATASET,
    ("22", "Curve Point Observation", "Observed Curve"): CURVE,
    ("22", "Volatility Surface Point", "Observed Surface"): CURVE,
    # ------------------------------------------------------------------ 22 Index Data
    ("22", "Index Level Observation", "Index Benchmark"): BENCHMARK,
    ("22", "Index Level Observation", "Index Level Source Dataset"): DATASET,
    ("22", "Index Constituent", "Constituent Benchmark"): BENCHMARK,
    ("22", "Index Constituent", "Constituent Instrument"): INSTRUMENT,
    ("22", "Index Constituent", "Constituent Source Dataset"): DATASET,
    ("22", "Index Change Announcement", "Changed Benchmark"): BENCHMARK,
    ("22", "Index Change Announcement", "Affected Index Instrument"): INSTRUMENT,
    ("22", "Index Change Announcement", "Related Corporate Action Event"): CORP_ACTION,
    ("22", "Index Change Announcement", "Change Source Dataset"): DATASET,
    # ------------------------------------------------------------------ 22 Instrument Market Data
    ("22", "Pricing Analytics Observation", "Analytics Instrument"): INSTRUMENT,
    ("22", "Pricing Analytics Observation", "Analytics Source Dataset"): DATASET,
    ("22", "Instrument Factor Observation", "Factor Observation Instrument"): INSTRUMENT,
    ("22", "Instrument Factor Observation", "Factor Source Party"): PARTY,
    ("22", "ETF Market Statistic", "ETF Instrument"): INSTRUMENT,
    ("22", "ETF Market Statistic", "Premium / Discount NAV"): SHARE_CLASS_NAV,
    ("22", "ETF Market Statistic", "Intraday Quote Source Dataset"): DATASET,

    # ------------------------------------------------------------------ 23 Research Coverage
    ("23", "Research Coverage Assignment", "Covering Analyst"): EMPLOYEE,
    ("23", "Research Coverage Assignment", "Covered Issuer"): PARTY,
    ("23", "Research Coverage Assignment", "Covered Instrument"): INSTRUMENT,
    ("23", "Research Coverage Assignment", "Covered Sector Scheme"): CLASS_SCHEME,
    ("23", "Research Coverage Assignment", "Covered Geography"): GEO,
    ("23", "Research Coverage Assignment", "Covering Research Team"): ORG_UNIT,
    ("23", "Research Coverage Assignment", "Served Investment Strategy"): STRATEGY,
    ("23", "Research Universe", "Universe Owner"): EMPLOYEE,
    ("23", "Research Universe Member", "Member Universe"): RESEARCH_UNIVERSE,
    ("23", "Research Universe Member", "Member Issuer"): PARTY,
    ("23", "Research Universe Member", "Member Instrument"): INSTRUMENT,
    ("23", "Research Universe Member", "Member Sector Scheme"): CLASS_SCHEME,
    ("23", "Research Universe Member", "Member Geography"): GEO,
    # ------------------------------------------------------------------ 23 Recommendations & Credit Views
    ("23", "Research Recommendation", "Recommending Analyst"): EMPLOYEE,
    ("23", "Research Recommendation", "Recommended Issuer"): PARTY,
    ("23", "Research Recommendation", "Recommended Instrument"): INSTRUMENT,
    ("23", "Research Recommendation", "Recommended Sector Scheme"): CLASS_SCHEME,
    ("23", "Research Recommendation", "Recommended Geography"): GEO,
    ("23", "Research Recommendation", "Source Coverage Assignment"): ("23", "Research Coverage Assignment"),
    ("23", "Research Recommendation", "Previous Recommendation"): ("23", "Research Recommendation"),
    ("23", "Research Recommendation", "Announcing Publication"): RESEARCH_PUB,
    ("23", "Recommendation Valuation Basis", "Valuation Model"): RESEARCH_MODEL,
    ("23", "Recommendation Valuation Basis", "Reference Approved Price"): APPROVED_PRICE,
    ("23", "Internal Credit Assessment", "Assessed Party"): PARTY,
    ("23", "Internal Credit Assessment", "Assessed Instrument"): INSTRUMENT,
    ("23", "Internal Credit Assessment", "Credit Analyst"): EMPLOYEE,
    ("23", "Internal Credit Assessment", "Assessment Approved By"): EMPLOYEE,
    # ------------------------------------------------------------------ 23 Estimates, Models & Signals
    ("23", "Analyst Estimate", "Estimated Issuer"): PARTY,
    ("23", "Analyst Estimate", "Estimating Analyst"): EMPLOYEE,
    ("23", "Analyst Estimate", "Source Research Model"): RESEARCH_MODEL,
    ("23", "Research Model", "Modeled Issuer"): PARTY,
    ("23", "Research Model", "Model Author"): EMPLOYEE,
    ("23", "Research Model", "Model Inventory Entry"): MODEL_INVENTORY,
    ("23", "Economic Forecast", "Forecast Geography"): GEO,
    ("23", "Economic Forecast", "Forecasting Economist"): EMPLOYEE,
    ("23", "Research Signal Definition", "Primary Input Dataset"): DATASET,
    ("23", "Research Signal Definition", "Signal Universe"): RESEARCH_UNIVERSE,
    ("23", "Research Signal Definition", "Signal Owner"): EMPLOYEE,
    ("23", "Research Signal Definition", "Related AI Use Case"): AI_USE_CASE,
    ("23", "Research Signal Definition", "Model Inventory Entry"): MODEL_INVENTORY,
    ("23", "Research Signal Score", "Scored Signal"): ("23", "Research Signal Definition"),
    ("23", "Research Signal Score", "Scored Instrument"): INSTRUMENT,
    # ------------------------------------------------------------------ 23 Research Publications
    ("23", "Research Publication", "Lead Author"): EMPLOYEE,
    ("23", "Research Publication", "Drafting AI Use Case"): AI_USE_CASE,
    ("23", "Publication Subject", "Subject Publication"): RESEARCH_PUB,
    ("23", "Publication Subject", "Subject Issuer"): PARTY,
    ("23", "Publication Subject", "Subject Instrument"): INSTRUMENT,
    ("23", "Publication Subject", "Subject Sector Scheme"): CLASS_SCHEME,
    ("23", "Publication Subject", "Subject Geography"): GEO,
    ("23", "Publication Review", "Supervisory Reviewer"): EMPLOYEE,
    ("23", "Publication Review", "Released As Commentary"): ("01", "Investment Commentary"),
    ("23", "Publication Review", "Released As Content Asset"): ("04", "Content Asset"),
    # ------------------------------------------------------------------ 23 Issuer Meetings
    ("23", "Issuer Meeting", "Meeting Issuer"): PARTY,
    ("23", "Issuer Meeting", "Arranging Provider"): PARTY,
    ("23", "Issuer Meeting", "Summary AI Use Case"): AI_USE_CASE,
    ("23", "Issuer Meeting Participant", "Participant Meeting"): ISSUER_MEETING,
    ("23", "Issuer Meeting Participant", "Internal Participant"): EMPLOYEE,
    ("23", "Issuer Meeting Participant", "External Participant"): PARTY,
    ("23", "Issuer Meeting Topic", "Topic Meeting"): ISSUER_MEETING,
    ("23", "Meeting MNPI Assessment", "MNPI Escalation Reference"): ("38", "MNPI Escalation"),
    # ------------------------------------------------------------------ 23 Third-Party Research
    ("23", "Research Provider Profile", "Research Provider Party"): PARTY,
    ("23", "Research Service Subscription", "Subscribed Provider"): PARTY,
    ("23", "Research Service Subscription", "Subscribing Research Team"): ORG_UNIT,
    ("23", "Research Service Subscription", "Licensed Dataset"): DATASET,
    ("23", "Research Consumption Record", "Consuming Employee"): EMPLOYEE,
    ("23", "Research Consumption Record", "Consumed Provider"): PARTY,
    ("23", "Research Consumption Record", "Provider Contact"): PARTY,
    ("23", "Research Consumption Record", "Related Issuer"): PARTY,
    ("23", "Research Consumption Record", "Related Issuer Meeting"): ISSUER_MEETING,
    ("23", "Research Evaluation Round", "Evaluated Provider"): PARTY,
    ("23", "Research Evaluation Round", "Evaluator"): EMPLOYEE,
    ("23", "Research Evaluation Round", "Evaluation Approved By"): EMPLOYEE,
    ("23", "Evaluation Criterion Score", "Scored Evaluation Round"): ("23", "Research Evaluation Round"),

    # ------------------------------------------------------------------ 24 Investment Governance
    ("24", "Investment Committee", "Committee Owning Entity"): LEGAL_ENTITY,
    ("24", "Investment Committee", "Parent Committee"): INV_COMMITTEE,
    ("24", "Investment Committee Member", "Member Committee"): INV_COMMITTEE,
    ("24", "Investment Committee Member", "Committee Member"): EMPLOYEE,
    ("24", "Investment Committee Meeting", "Meeting Committee"): INV_COMMITTEE,
    ("24", "Investment Committee Decision", "Decision Committee"): INV_COMMITTEE,
    ("24", "Investment Committee Decision", "Decision Scope Strategy"): STRATEGY,
    # ------------------------------------------------------------------ 24 Portfolio Management Assignment
    ("24", "Portfolio Management Assignment", "Assigned Portfolio"): PORTFOLIO,
    ("24", "Portfolio Management Assignment", "Assigned Manager"): EMPLOYEE,
    ("24", "Portfolio Management Assignment", "Assigned Investment Team"): ORG_UNIT,
    ("24", "Portfolio Management Assignment", "Assignment Approved By"): EMPLOYEE,
    # ------------------------------------------------------------------ 24 Asset Allocation
    ("24", "Asset Allocation Policy", "Policy Strategy"): STRATEGY,
    ("24", "Asset Allocation Policy", "Policy Product"): ("01", "Investment Product"),
    ("24", "Asset Allocation Policy", "Policy Model Portfolio"): MODEL_PORTFOLIO,
    ("24", "Asset Allocation Policy", "Policy Benchmark"): BENCHMARK,
    ("24", "Asset Allocation Policy", "Approving Committee Decision"): IC_DECISION,
    ("24", "Asset Allocation Policy", "Policy Mandate"): ("01", "Investment Mandate"),
    ("24", "Asset Allocation Policy", "Policy CMA Set"): ("24", "Capital Market Assumption Set"),
    ("24", "Asset Allocation Policy Line", "Line Allocation Policy"): ALLOC_POLICY,
    ("24", "Asset Allocation Policy Line", "Line Proxy Benchmark"): BENCHMARK,
    ("24", "Glide Path Point", "Glide Path Policy"): ALLOC_POLICY,
    ("24", "Tactical Allocation View", "View Committee Decision"): IC_DECISION,
    ("24", "Tactical Allocation View", "View Strategy"): STRATEGY,
    # ------------------------------------------------------------------ 24 Targets & Constraints
    ("24", "Target Allocation Set", "Target Portfolio"): PORTFOLIO,
    ("24", "Target Allocation Set", "Target Model Portfolio"): MODEL_PORTFOLIO,
    ("24", "Target Allocation Set", "Target Set Approved By"): EMPLOYEE,
    ("24", "Target Allocation Set", "Active Weight Benchmark"): BENCHMARK,
    ("24", "Target Allocation Set", "Governing Allocation Policy"): ALLOC_POLICY,
    ("24", "Target Allocation Set", "Originating Investment Decision"): INV_DECISION,
    ("24", "Target Allocation Set", "Copied From Target Set"): TARGET_SET,
    ("24", "Target Allocation Line", "Line Target Set"): TARGET_SET,
    ("24", "Target Allocation Line", "Target Instrument"): INSTRUMENT,
    ("24", "Target Allocation Line", "Target Classification Scheme"): CLASS_SCHEME,
    ("24", "Target Allocation Line", "Target Sleeve Portfolio"): PORTFOLIO,
    ("24", "Portfolio Construction Constraint", "Constrained Portfolio"): PORTFOLIO,
    ("24", "Portfolio Construction Constraint", "Constrained Model Portfolio"): MODEL_PORTFOLIO,
    ("24", "Portfolio Construction Constraint", "Buffered Investment Restriction"): ("01", "Investment Restriction"),
    ("24", "Portfolio Construction Constraint", "Constraint Set By"): EMPLOYEE,
    # ------------------------------------------------------------------ 24 Investment Decisions
    ("24", "Investment Decision", "Decision Strategy"): STRATEGY,
    ("24", "Investment Decision", "Decision Instrument"): INSTRUMENT,
    ("24", "Investment Decision", "Switch To Instrument"): INSTRUMENT,
    ("24", "Investment Decision", "Decision Maker"): EMPLOYEE,
    ("24", "Investment Decision", "Decision Investment Team"): ORG_UNIT,
    ("24", "Investment Decision", "Decision Algorithm"): MODEL_INVENTORY,
    ("24", "Decision Rationale", "Primary Research Recommendation"): ("23", "Research Recommendation"),
    ("24", "Decision Rationale", "Linked Committee Decision"): IC_DECISION,
    ("24", "Investment Decision Scope", "Scoped Decision"): INV_DECISION,
    ("24", "Investment Decision Scope", "Scope Portfolio"): PORTFOLIO,
    ("24", "Investment Decision Scope", "Scope Model Portfolio"): MODEL_PORTFOLIO,
    # ------------------------------------------------------------------ 24 Rebalancing & Trade Proposals
    ("24", "Rebalance Run", "Run Initiated By"): EMPLOYEE,
    ("24", "Rebalance Run", "Driving Target Set"): TARGET_SET,
    ("24", "Rebalance Run", "Triggering Investment Decision"): INV_DECISION,
    ("24", "Rebalance Run", "Triggering Transition Event"): ("12", "Transition Event"),
    ("24", "Rebalance Run", "Model Inventory Entry"): MODEL_INVENTORY,
    ("24", "Rebalance Index Change Trigger", "Index Change Rebalance Run"): REBALANCE_RUN,
    ("24", "Rebalance Index Change Trigger", "Triggering Index Change Announcement"): ("22", "Index Change Announcement"),
    ("24", "Rebalance Portfolio Result", "Result Rebalance Run"): REBALANCE_RUN,
    ("24", "Rebalance Portfolio Result", "Result Portfolio"): PORTFOLIO,
    ("24", "Rebalance Portfolio Result", "Applied Target Set"): TARGET_SET,
    ("24", "Rebalance Portfolio Result", "Result Reviewed By"): EMPLOYEE,
    ("24", "Proposed Trade", "Proposing Rebalance Run"): REBALANCE_RUN,
    ("24", "Proposed Trade", "Originating Investment Decision"): INV_DECISION,
    ("24", "Proposed Trade", "Proposed Trade Portfolio"): PORTFOLIO,
    ("24", "Proposed Trade", "Proposed Trade Instrument"): INSTRUMENT,
    ("24", "Proposed Lot Selection", "Lot Selection Trade"): ("24", "Proposed Trade"),
    ("24", "Proposed Lot Selection", "Selected Tax Lot"): ("18", "Tax Lot"),
    ("24", "Tax Budget", "Budget Portfolio"): PORTFOLIO,
    ("24", "Tax Budget", "Budget Instructed By"): PARTY,
    # ------------------------------------------------------------------ 24 Cash Planning
    ("24", "Investable Cash Forecast", "Forecast Portfolio"): PORTFOLIO,
    ("24", "Investable Cash Forecast", "Forecast Calendar"): CALENDAR,
    ("24", "Cash Forecast Adjustment", "Adjusted Cash Forecast"): ("24", "Investable Cash Forecast"),
    ("24", "Cash Forecast Adjustment", "Planned Investment Decision"): INV_DECISION,
    ("24", "Cash Forecast Adjustment", "Adjustment Entered By"): EMPLOYEE,
    # ------------------------------------------------------------------ 24 ETF Baskets
    ("24", "ETF Basket", "Basket Share Class"): ("01", "Share Class"),
    ("24", "ETF Basket", "Basket Portfolio"): PORTFOLIO,
    ("24", "ETF Basket", "Basket Constructed By"): EMPLOYEE,
    ("24", "ETF Basket Constituent", "Constituent Basket"): ("24", "ETF Basket"),
    ("24", "ETF Basket Constituent", "Constituent Instrument"): INSTRUMENT,
    ("24", "Custom Basket Approval", "Custom Basket Approver"): EMPLOYEE,
    ("24", "Capital Market Assumption Set", "CMA Generating Model"): MODEL_INVENTORY,
    ("24", "Capital Market Assumption Set", "CMA Approving Committee Decision"): IC_DECISION,
    ("24", "Asset Class Return Assumption", "Return Assumption CMA Set"): ("24", "Capital Market Assumption Set"),
    ("24", "Asset Class Return Assumption", "Assumption Proxy Benchmark"): BENCHMARK,
    ("24", "Asset Class Correlation Assumption", "Correlation CMA Set"): ("24", "Capital Market Assumption Set"),
    ("24", "Asset Class Correlation Assumption", "First Assumption Line"): ("24", "Asset Class Return Assumption"),
    ("24", "Asset Class Correlation Assumption", "Second Assumption Line"): ("24", "Asset Class Return Assumption"),
    ("24", "Model Lineup", "Lineup Service Offering"): ("01", "Service Offering"),
    ("24", "Model Lineup", "Lineup Allocation Policy"): ALLOC_POLICY,
    ("24", "Model Lineup", "Lineup CMA Set"): ("24", "Capital Market Assumption Set"),
    ("24", "Model Lineup", "Lineup Approving Committee Decision"): IC_DECISION,
    ("24", "Model Lineup Position", "Position Model Lineup"): ("24", "Model Lineup"),
    ("24", "Model Lineup Position", "Position Model Portfolio"): MODEL_PORTFOLIO,
    ("24", "Model Building Block", "Building Block Model Portfolio"): MODEL_PORTFOLIO,
    ("24", "Model Building Block", "Alternate For Building Block"): ("24", "Model Building Block"),
    ("24", "Model Building Block", "Building Block Share Class"): ("01", "Share Class"),
    ("24", "Model Building Block", "Building Block Instrument"): INSTRUMENT,
}

# Every Reference attribute of 22-24 resolves to an object in the taxonomy, so none is left out. Not in REFS because
# they are not typed Reference: 24 Investment Decision.Decision Algorithm Code (Identifier, ->37) and the Derived copies
# (22 Ranked Data Provider, 24 Rebalance Run.Optimizer Used, Decision Supervising Branch Country, ...).
