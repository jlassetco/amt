"""Key and link registry extension: Data Domains 25 Trading & Execution and 26 Trade Operations, Settlement & Collateral
(enterprise expansion, Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Every object of 25 and 26 is keyed here except the
26 Standing Settlement Instruction, which keys_g8_22_30.py registers (with its 'SSI Mandate' and 'Safekeeping Account'
references). Objects without an ID attribute are keyed on the attributes their grain names; the single-attribute
references that point at them (for example Research Payment.Funding Research Budget) carry the composed key value, as
the taxonomy examples show ("2026 / LEN-0011", "PTY-100221 / CS 0091 / 2025-01-01").
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


PARTY = ("02", "Party")
INSTRUMENT = ("17", "Instrument")
PORTFOLIO = ("18", "Portfolio")
ACCOUNT = ("15", "Account")
EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
FUND = ("01", "Investment Product")
TRADE_ORDER = ("25", "Trade Order")
BLOCK_ORDER = ("25", "Block Order")
EXECUTION = ("25", "Execution")
TRADE_ALLOCATION = ("25", "Trade Allocation")
OFFERING = ("25", "New Issue Offering")
CSA = ("25", "Commission Sharing Arrangement")
SETTLEMENT_INSTRUCTION = ("26", "Settlement Instruction")
SSI = ("26", "Standing Settlement Instruction")
OTC_TRADE = ("26", "OTC Derivative Trade")
REPO_TRADE = ("26", "Repo Trade")
TRADING_AGREEMENT = ("26", "Trading Agreement")
SAFEKEEPING_ACCOUNT = ("28", "Safekeeping Account")
AP_ORDER = ("29", "AP Creation / Redemption Order")

KEYS = {
    # ------------------------------------------------------------------ 25 Order Management
    ("25", "Trade Order"): _k(["Trade Order ID"], "Natural"),
    ("25", "Order Handling Instruction"): _fold(),
    ("25", "Trade Order Event"): _k(["Event Trade Order", "Trade Order Event Type", "Event Timestamp"], "Composite"),
    # ------------------------------------------------------------------ 25 Execution
    ("25", "Block Order"): _k(["Block Order ID"], "Natural"),
    ("25", "Block Order Membership"): _k(["Member Block Order", "Member Trade Order"], "Composite"),
    ("25", "Broker Placement"): _k(["Placement Block Order", "Placement Broker", "Placement Sequence Number"], "Composite",
                                   note="Broker Client Order ID is assigned by the broker and is not guaranteed unique "
                                        "across brokers, so the grain attributes key the placement."),
    ("25", "Execution"): _k(["Execution ID"], "Natural",
                            note="Firm execution ID; Broker Execution ID is the broker's own reference and stays an "
                                 "attribute."),
    # ------------------------------------------------------------------ 25 Allocation
    ("25", "Trade Allocation"): _k(["Trade Allocation ID"], "Natural",
                                   note="The ID stands for the grain block (or cross) x executing broker x trade order x "
                                        "portfolio or SMA account."),
    ("25", "Allocation Cost Detail"): _fold(),
    # MiFIR Transaction Report removed (no MiFIR reporting entity; CW-925).
    ("25", "Cross Trade"): _k(["Cross Trade Reference"], "Natural"),
    ("25", "Trade Error"): _k(["Trade Error Reference"], "Natural"),
    # ------------------------------------------------------------------ 25 New Issues
    ("25", "New Issue Offering"): _k(["New Issue Offering Reference"], "Natural"),
    ("25", "New Issue Indication"): _k(["Indication Offering", "Indicating Portfolio", "Indicating Account",
                                        "Indication Timestamp"], "Composite",
                                       note="Indicating Account is populated only for an SMA account indication; models "
                                            "hold an explicit 'none' member so the key has no empty part."),
    ("25", "New Issue Allocation"): _k(["Allocation Offering", "Receiving Portfolio", "Receiving Account"], "Composite",
                                       note="Receiving Account is populated only for an SMA account allocation; models "
                                            "hold an explicit 'none' member so the key has no empty part."),
    ("25", "Rule 10f-3 Purchase"): _k(["Rule 10f-3 Offering", "Purchasing Fund", "Purchase Trade Allocation"],
                                      "Composite"),
    ("25", "New Issue Eligibility Certification"): _k(["Certified Portfolio", "Certified Account", "Certification Date"],
                                                      "Composite",
                                                      note="Certified Account is populated only for an SMA account "
                                                           "certification; the reference example is portfolio / date."),
    # ------------------------------------------------------------------ 25 Counterparty Approval
    ("25", "Approved Counterparty Profile"): _k(["Counterparty Party"], "Natural",
                                                note="A role profile keyed by the 02 Party ID (17 Issuer Profile "
                                                     "pattern); models may hold it in the Party entity."),
    ("25", "Counterparty Approval Scope"): _k(["Scope Counterparty", "Approved Activity", "Scope Trading Entity",
                                               "Scope Fund", "Scope Effective From"], "Composite",
                                              note="Scope Fund is optional (empty for an entity-wide scope); countries "
                                                   "were removed from the grain (Source_Notes review item D)."),
    ("25", "Counterparty Trading Limit"): _k(["Limit Counterparty", "Limit Type", "Limit Trading Entity", "Limit Fund",
                                              "Limit Effective From"], "Composite",
                                             note="Limit Fund is optional (empty for an entity-wide limit)."),
    ("25", "Counterparty Review"): _k(["Reviewed Counterparty", "Counterparty Review Date"], "Composite"),
    # ------------------------------------------------------------------ 25 Commissions & Research Payments
    ("25", "Commission Schedule"): _k(["Schedule Broker", "Schedule Asset Class", "Schedule Market",
                                       "Schedule Effective From"], "Composite"),
    ("25", "Commission Sharing Arrangement"): _k(["Arrangement Executing Broker", "Arrangement Reference",
                                                  "Arrangement Effective From"], "Composite",
                                                 note="The arrangement reference is the broker's, so the broker and the "
                                                      "effective period complete the key, as the reference examples show."),
    ("25", "Commission Sharing Balance"): _k(["Balance Arrangement", "Balance Statement Date"], "Composite"),
    ("25", "Research Budget"): _k(["Budget Year", "Budget Legal Entity", "Budget Strategy"], "Composite",
                                  note="Budget Strategy is empty for an entity-wide budget."),
    ("25", "Research Payment"): _k(["Paid Research Provider", "Payment Period Type", "Payment Period End Date",
                                    "Research Payment Source"], "Composite"),
    # ------------------------------------------------------------------ 25 Best Execution & TCA
    ("25", "Best Execution Policy"): _k(["Policy Name", "Policy Asset Class", "Policy Legal Entity", "Policy Version"],
                                        "Composite",
                                        note="No policy ID; the name and version (the Reviewed Policy example) are "
                                             "completed by the asset class and legal entity the grain names."),
    ("25", "TCA Result"): _k(["TCA Result ID"], "Natural"),
    ("25", "TCA Benchmark Result"): _k(["Benchmark TCA Result", "TCA Benchmark"], "Composite"),
    ("25", "Broker Execution Review"): _k(["Reviewed Broker", "Broker Review Period Type", "Broker Review Period End Date",
                                           "Broker Review Asset Class"], "Composite"),
    ("25", "Best Execution Review"): _k(["Review Meeting Date", "Review Period End Date", "Review Asset Class",
                                         "Review Legal Entity"], "Composite",
                                        note="The committee is the firm's single best execution committee, so the "
                                             "meeting date stands for the committee review."),

    # ------------------------------------------------------------------ 26 Confirmation & Matching
    ("26", "Trade Confirmation"): _k(["Trade Confirmation ID"], "Natural"),
    ("26", "Confirmation Match Exception"): _k(["Exception Confirmation", "Mismatched Field", "Exception Raised Timestamp"],
                                               "Composite"),
    # ------------------------------------------------------------------ 26 Settlement
    ("26", "Settlement Instruction"): _k(["Settlement Instruction ID"], "Natural",
                                         note="One SETL- key for every settlement type so 27, 28 and 29 reference one "
                                              "object."),
    ("26", "Cash Payment Detail"): _fold("Populated only for cash-only payments and FX settlements."),
    ("26", "Loan Settlement Detail"): _fold("Populated only for syndicated loan trades."),
    ("26", "Settlement Status Event"): _k(["Status Instruction", "Status Timestamp"], "Composite"),
    ("26", "Settlement Fail"): _k(["Failed Instruction", "Fail Start Date"], "Composite"),
    ("26", "Buy-In Notice"): _fold("Populated only for fails that went to buy-in."),
    ("26", "Settlement Penalty"): _k(["Settlement Penalty ID"], "Natural"),
    # ------------------------------------------------------------------ 26 Settlement Instructions & Cycles
    # Standing Settlement Instruction is keyed in keys_g8_22_30.py.
    ("26", "SSI Verification"): _fold(),
    ("26", "Settlement Cycle Rule"): _k(["Cycle Market", "Cycle Instrument Type", "Cycle Settlement Type",
                                         "Cycle Effective From"], "Composite"),
    # ------------------------------------------------------------------ 26 OTC Derivative & Financing Lifecycle
    ("26", "OTC Derivative Trade"): _k(["OTC Trade ID"], "Natural",
                                       note="Firm trade ID; the UTI is optional before reporting and changes on "
                                            "clearing, so it stays an attribute."),
    ("26", "Clearing Detail"): _fold(),
    ("26", "OTC Trade Leg"): _k(["Leg OTC Trade", "Leg Number"], "Composite"),
    ("26", "OTC Lifecycle Event"): _k(["Event OTC Trade", "OTC Event Date", "Event Sequence"], "Composite"),
    ("26", "OTC Cash Flow"): _k(["Cash Flow OTC Trade", "Cash Flow Leg Number", "Cash Flow Payment Date",
                                 "OTC Cash Flow Type"], "Composite"),
    ("26", "Repo Trade"): _k(["Repo Trade Reference"], "Natural",
                             note="Firm repo reference; no regulatory transaction identifier keys a fund repo (SFTR "
                                  "does not apply, CW-926)."),
    ("26", "Derivative Trade Report"): _k(["Reported UTI", "Trade Report Regime", "Report Submission Timestamp"],
                                          "Composite",
                                          note="The reported UTI identifies the OTC or repo trade on either path, so it "
                                               "stands for the reported trade in the key."),
    # ------------------------------------------------------------------ 26 Trading Agreements
    ("26", "Trading Agreement"): _k(["Trading Agreement ID"], "Natural"),
    ("26", "Credit Support Terms"): _k(["Terms Agreement", "Terms Margin Type", "Terms Direction", "Terms Effective From"],
                                       "Composite"),
    ("26", "Eligible Collateral Schedule"): _k(["Schedule Agreement", "Schedule Margin Type", "Schedule Direction",
                                                "Eligible Collateral Type", "Eligibility Effective From"], "Composite"),
    ("26", "Termination Event Trigger"): _k(["Trigger Agreement", "Termination Trigger Type", "Trigger Applies To",
                                             "Measurement Period Months", "Trigger Effective From"], "Composite",
                                            note="Measurement period is in the key because a NAV decline trigger has one "
                                                 "row per tier."),
    # ------------------------------------------------------------------ 26 Margin & Collateral
    ("26", "Margin Call"): _k(["Margin Call ID"], "Natural"),
    ("26", "Margin Call Dispute"): _fold(),
    ("26", "Collateral Movement"): _k(["Movement Agreement", "Collateral Movement Reference", "Collateral Value Date"],
                                      "Composite",
                                      note="The collateral system reference is unique only within that system, so the "
                                           "grain's agreement and value date complete the key."),
    ("26", "Collateral Balance"): _k(["Balance Agreement", "Collateral Source Portfolio", "Balance Date",
                                      "Balance Margin Type", "Balance Direction", "Balance Instrument", "Balance Currency"],
                                     "Composite",
                                     note="The collateral asset is the instrument, or the currency for cash (Balance "
                                          "Instrument empty); both are in the key."),
    ("26", "Initial Margin Calculation"): _k(["IM Calculation Agreement", "IM Calculation Date", "IM Direction"],
                                             "Composite"),
}

REFS = {
    # ------------------------------------------------------------------ 25 Order Management
    ("25", "Trade Order", "Order Portfolio"): PORTFOLIO,
    ("25", "Trade Order", "Order Instrument"): INSTRUMENT,
    ("25", "Trade Order", "Originating Investment Decision"): ("24", "Investment Decision"),
    ("25", "Trade Order", "Originating Proposed Trade"): ("24", "Proposed Trade"),
    ("25", "Trade Order", "Order Originator"): EMPLOYEE,
    ("25", "Trade Order", "Assigned Trader"): EMPLOYEE,
    ("25", "Trade Order", "Trading Legal Entity"): LEGAL_ENTITY,
    ("25", "Trade Order", "Related Transition Event"): ("12", "Transition Event"),
    ("25", "Trade Order", "Related AP Order"): AP_ORDER,
    ("25", "Trade Order", "Hedged Share Class"): ("01", "Share Class"),
    ("25", "Order Handling Instruction", "Directed Broker"): PARTY,
    ("25", "Order Handling Instruction", "Step-Out Broker"): PARTY,
    ("25", "Order Handling Instruction", "Trade Rotation Program"): ("05", "Distribution Agreement"),
    ("25", "Trade Order Event", "Event Trade Order"): TRADE_ORDER,
    ("25", "Trade Order Event", "Event Performed By"): EMPLOYEE,
    # ------------------------------------------------------------------ 25 Execution
    ("25", "Block Order", "Block Instrument"): INSTRUMENT,
    ("25", "Block Order", "Block Trader"): EMPLOYEE,
    ("25", "Block Order Membership", "Member Block Order"): BLOCK_ORDER,
    ("25", "Block Order Membership", "Member Trade Order"): TRADE_ORDER,
    ("25", "Broker Placement", "Placement Block Order"): BLOCK_ORDER,
    ("25", "Broker Placement", "Placement Broker"): PARTY,
    ("25", "Execution", "Execution Placement"): ("25", "Broker Placement"),
    ("25", "Execution", "Corrected Execution"): EXECUTION,
    # ------------------------------------------------------------------ 25 Allocation
    ("25", "Trade Allocation", "Allocated Block Order"): BLOCK_ORDER,
    ("25", "Trade Allocation", "Allocated Trade Order"): TRADE_ORDER,
    ("25", "Trade Allocation", "Allocated Portfolio"): PORTFOLIO,
    ("25", "Trade Allocation", "Allocated Account"): ACCOUNT,
    ("25", "Trade Allocation", "Executing Broker"): PARTY,
    ("25", "Allocation Cost Detail", "Applied Commission Schedule"): ("25", "Commission Schedule"),
    ("25", "Allocation Cost Detail", "Applied Commission Sharing Arrangement"): CSA,
    # MiFIR Transaction Report references removed with the object (CW-925).
    ("25", "Cross Trade", "Buying Portfolio"): PORTFOLIO,
    ("25", "Cross Trade", "Selling Portfolio"): PORTFOLIO,
    ("25", "Cross Trade", "Cross Instrument"): INSTRUMENT,
    ("25", "Cross Trade", "Independent Price Observation"): ("22", "Price Observation"),
    ("25", "Cross Trade", "Buying Trade Allocation"): TRADE_ALLOCATION,
    ("25", "Cross Trade", "Selling Trade Allocation"): TRADE_ALLOCATION,
    ("25", "Trade Error", "Affected Trade Order"): TRADE_ORDER,
    ("25", "Trade Error", "Affected Trade Allocation"): TRADE_ALLOCATION,
    ("25", "Trade Error", "Affected Portfolio"): PORTFOLIO,
    # ------------------------------------------------------------------ 25 New Issues
    ("25", "New Issue Offering", "Offering Instrument"): INSTRUMENT,
    ("25", "New Issue Offering", "Offering Setup Request"): ("17", "Instrument Setup Request"),
    ("25", "New Issue Offering", "Lead Bookrunner"): PARTY,
    ("25", "New Issue Indication", "Indication Offering"): OFFERING,
    ("25", "New Issue Indication", "Indicating Portfolio"): PORTFOLIO,
    ("25", "New Issue Indication", "Indicating Account"): ACCOUNT,
    ("25", "New Issue Allocation", "Allocation Offering"): OFFERING,
    ("25", "New Issue Allocation", "Receiving Portfolio"): PORTFOLIO,
    ("25", "New Issue Allocation", "Receiving Account"): ACCOUNT,
    ("25", "New Issue Allocation", "Booked Trade Allocation"): TRADE_ALLOCATION,
    ("25", "New Issue Allocation", "Supporting Eligibility Certification"): ("25", "New Issue Eligibility Certification"),
    ("25", "Rule 10f-3 Purchase", "Rule 10f-3 Offering"): OFFERING,
    ("25", "Rule 10f-3 Purchase", "Purchasing Fund"): FUND,
    ("25", "Rule 10f-3 Purchase", "Purchase Trade Allocation"): TRADE_ALLOCATION,
    ("25", "Rule 10f-3 Purchase", "Purchased From"): PARTY,
    ("25", "New Issue Eligibility Certification", "Certified Portfolio"): PORTFOLIO,
    ("25", "New Issue Eligibility Certification", "Certified Account"): ACCOUNT,
    # ------------------------------------------------------------------ 25 Counterparty Approval
    ("25", "Approved Counterparty Profile", "Counterparty Party"): PARTY,
    ("25", "Counterparty Approval Scope", "Scope Counterparty"): PARTY,
    ("25", "Counterparty Approval Scope", "Scope Trading Entity"): LEGAL_ENTITY,
    ("25", "Counterparty Approval Scope", "Scope Fund"): FUND,
    ("25", "Counterparty Approval Scope", "Governing Trading Agreement"): TRADING_AGREEMENT,
    ("25", "Counterparty Trading Limit", "Limit Counterparty"): PARTY,
    ("25", "Counterparty Trading Limit", "Limit Trading Entity"): LEGAL_ENTITY,
    ("25", "Counterparty Trading Limit", "Limit Fund"): FUND,
    ("25", "Counterparty Review", "Reviewed Counterparty"): PARTY,
    ("25", "Counterparty Review", "Credit View"): ("23", "Internal Credit Assessment"),
    ("25", "Counterparty Review", "Counterparty Reviewer"): EMPLOYEE,
    # ------------------------------------------------------------------ 25 Commissions & Research Payments
    ("25", "Commission Schedule", "Schedule Broker"): PARTY,
    ("25", "Commission Sharing Arrangement", "Arrangement Executing Broker"): PARTY,
    ("25", "Commission Sharing Balance", "Balance Arrangement"): CSA,
    ("25", "Research Budget", "Budget Legal Entity"): LEGAL_ENTITY,
    ("25", "Research Budget", "Budget Strategy"): ("01", "Investment Strategy"),
    ("25", "Research Payment", "Paid Research Provider"): PARTY,
    ("25", "Research Payment", "Funding Research Budget"): ("25", "Research Budget"),
    ("25", "Research Payment", "Funding Commission Sharing Arrangement"): CSA,
    ("25", "Research Payment", "Research Evaluation Round"): ("23", "Research Evaluation Round"),
    ("25", "Research Payment", "Research Invoice"): ("19", "Payable Invoice"),
    # ------------------------------------------------------------------ 25 Best Execution & TCA
    ("25", "Best Execution Policy", "Policy Legal Entity"): LEGAL_ENTITY,
    ("25", "Best Execution Policy", "Outsourced Trading Provider"): PARTY,
    ("25", "TCA Result", "Measured Trade Order"): TRADE_ORDER,
    ("25", "TCA Result", "Measured Block Order"): BLOCK_ORDER,
    ("25", "TCA Result", "Measured Execution"): EXECUTION,
    ("25", "TCA Result", "TCA Provider"): PARTY,
    ("25", "TCA Benchmark Result", "Benchmark TCA Result"): ("25", "TCA Result"),
    ("25", "Broker Execution Review", "Reviewed Broker"): PARTY,
    ("25", "Best Execution Review", "Review Legal Entity"): LEGAL_ENTITY,
    ("25", "Best Execution Review", "Reviewed Policy"): ("25", "Best Execution Policy"),
    ("25", "Best Execution Review", "Committee Chair"): EMPLOYEE,

    # ------------------------------------------------------------------ 26 Confirmation & Matching
    ("26", "Trade Confirmation", "Confirmed Allocation"): TRADE_ALLOCATION,
    ("26", "Trade Confirmation", "Confirming Party"): PARTY,
    ("26", "Trade Confirmation", "Affirmed By"): EMPLOYEE,
    ("26", "Confirmation Match Exception", "Exception Confirmation"): ("26", "Trade Confirmation"),
    # ------------------------------------------------------------------ 26 Settlement
    ("26", "Settlement Instruction", "Settled Allocation"): TRADE_ALLOCATION,
    ("26", "Settlement Instruction", "Settled Portfolio Transaction"): ("18", "Portfolio Transaction"),
    ("26", "Settlement Instruction", "Settlement Portfolio"): PORTFOLIO,
    ("26", "Settlement Instruction", "Settlement SMA Account"): ACCOUNT,
    ("26", "Settlement Instruction", "Related AP Order"): AP_ORDER,
    ("26", "Settlement Instruction", "Settlement Instrument"): INSTRUMENT,
    ("26", "Settlement Instruction", "Applied Own SSI"): SSI,
    ("26", "Settlement Instruction", "Applied Counterparty SSI"): SSI,
    ("26", "Settlement Instruction", "Settlement Counterparty"): PARTY,
    ("26", "Settlement Instruction", "Settlement Safekeeping Account"): SAFEKEEPING_ACCOUNT,
    ("26", "Settlement Instruction", "Operations Provider"): PARTY,
    ("26", "Loan Settlement Detail", "Loan Administrative Agent"): PARTY,
    ("26", "Settlement Status Event", "Status Instruction"): SETTLEMENT_INSTRUCTION,
    ("26", "Settlement Fail", "Failed Instruction"): SETTLEMENT_INSTRUCTION,
    ("26", "Settlement Penalty", "Penalized Instruction"): SETTLEMENT_INSTRUCTION,
    ("26", "Settlement Penalty", "Penalty Calculating CSD"): PARTY,
    ("26", "Settlement Penalty", "Penalty Allocated Portfolio"): PORTFOLIO,
    # ------------------------------------------------------------------ 26 Settlement Instructions & Cycles
    # 'SSI Mandate' and 'Safekeeping Account' are registered in keys_g8_22_30.py.
    ("26", "Standing Settlement Instruction", "SSI Portfolio"): PORTFOLIO,
    ("26", "Standing Settlement Instruction", "SSI Fund"): FUND,
    ("26", "Standing Settlement Instruction", "SSI Counterparty"): PARTY,
    ("26", "Standing Settlement Instruction", "Own Safekeeping Account"): SAFEKEEPING_ACCOUNT,
    ("26", "SSI Verification", "Verified By"): EMPLOYEE,
    ("26", "SSI Verification", "SSI Approved By"): EMPLOYEE,
    ("26", "Settlement Cycle Rule", "Settlement Calendar"): ("09", "Calendar"),
    # ------------------------------------------------------------------ 26 OTC Derivative & Financing Lifecycle
    ("26", "OTC Derivative Trade", "OTC Product Instrument"): INSTRUMENT,
    ("26", "OTC Derivative Trade", "OTC Portfolio"): PORTFOLIO,
    ("26", "OTC Derivative Trade", "OTC Counterparty"): PARTY,
    ("26", "OTC Derivative Trade", "Governing Trading Agreement"): TRADING_AGREEMENT,
    ("26", "OTC Derivative Trade", "Source Allocation"): TRADE_ALLOCATION,
    ("26", "OTC Derivative Trade", "CDS Reference Entity"): PARTY,
    ("26", "Clearing Detail", "Central Counterparty"): PARTY,
    ("26", "Clearing Detail", "Clearing Member"): PARTY,
    ("26", "Clearing Detail", "Clearing Agreement"): TRADING_AGREEMENT,
    ("26", "OTC Trade Leg", "Leg OTC Trade"): OTC_TRADE,
    ("26", "OTC Lifecycle Event", "Event OTC Trade"): OTC_TRADE,
    ("26", "OTC Lifecycle Event", "Step-In Party"): PARTY,
    ("26", "OTC Cash Flow", "Cash Flow OTC Trade"): OTC_TRADE,
    ("26", "OTC Cash Flow", "Rate Fixing Used"): ("22", "Reference Rate Fixing"),
    ("26", "OTC Cash Flow", "Payment Settlement Instruction"): SETTLEMENT_INSTRUCTION,
    ("26", "Repo Trade", "Repo Source Allocation"): TRADE_ALLOCATION,
    ("26", "Repo Trade", "Repo Portfolio"): PORTFOLIO,
    ("26", "Repo Trade", "Repo Counterparty"): PARTY,
    ("26", "Repo Trade", "Governing Repo Agreement"): TRADING_AGREEMENT,
    ("26", "Repo Trade", "Tri-Party Agent"): PARTY,
    ("26", "Repo Trade", "Opening Leg Settlement"): SETTLEMENT_INSTRUCTION,
    ("26", "Repo Trade", "Closing Leg Settlement"): SETTLEMENT_INSTRUCTION,
    ("26", "Derivative Trade Report", "Reported OTC Trade"): OTC_TRADE,
    ("26", "Derivative Trade Report", "Reporting Counterparty"): PARTY,
    # Reported Repo Trade (SFTR) and Entity Responsible for Reporting (EMIR) removed from Derivative Trade Report (CW-926).
    ("26", "Derivative Trade Report", "Report Submitting Entity"): PARTY,
    ("26", "Derivative Trade Report", "Trade Repository"): PARTY,
    # ------------------------------------------------------------------ 26 Trading Agreements
    ("26", "Trading Agreement", "Parent Agreement"): TRADING_AGREEMENT,
    ("26", "Trading Agreement", "Fund Party"): FUND,
    ("26", "Trading Agreement", "Principal Account"): ACCOUNT,
    ("26", "Trading Agreement", "Firm Contracting Entity"): LEGAL_ENTITY,
    ("26", "Trading Agreement", "Agreement Counterparty"): PARTY,
    ("26", "Trading Agreement", "Give-Up Executing Broker"): PARTY,
    ("26", "Trading Agreement", "Agreement Operations Provider"): PARTY,
    ("26", "Credit Support Terms", "Terms Agreement"): TRADING_AGREEMENT,
    ("26", "Credit Support Terms", "Segregation Custodian"): PARTY,
    ("26", "Eligible Collateral Schedule", "Schedule Agreement"): TRADING_AGREEMENT,
    ("26", "Termination Event Trigger", "Trigger Agreement"): TRADING_AGREEMENT,
    # ------------------------------------------------------------------ 26 Margin & Collateral
    ("26", "Margin Call", "Call Agreement"): TRADING_AGREEMENT,
    ("26", "Margin Call", "Supporting IM Calculation"): ("26", "Initial Margin Calculation"),
    ("26", "Collateral Movement", "Movement Agreement"): TRADING_AGREEMENT,
    ("26", "Collateral Movement", "Satisfied Margin Call"): ("26", "Margin Call"),
    ("26", "Collateral Movement", "Related Repo Trade"): REPO_TRADE,
    ("26", "Collateral Movement", "Moved Instrument"): INSTRUMENT,
    ("26", "Collateral Movement", "Movement Settlement Instruction"): SETTLEMENT_INSTRUCTION,
    ("26", "Collateral Balance", "Balance Agreement"): TRADING_AGREEMENT,
    ("26", "Collateral Balance", "Collateral Source Portfolio"): PORTFOLIO,
    ("26", "Collateral Balance", "Balance Instrument"): INSTRUMENT,
    ("26", "Collateral Balance", "Related Repo Trade"): REPO_TRADE,
    ("26", "Collateral Balance", "Valuation Price Record"): ("22", "Approved Price"),
    ("26", "Collateral Balance", "Collateral Holding Account"): SAFEKEEPING_ACCOUNT,
    ("26", "Initial Margin Calculation", "IM Calculation Agreement"): TRADING_AGREEMENT,
}

# Every Reference attribute of 25 and 26 targets an object in the taxonomy; none is left out. Attributes the catalog
# marks ->NN but types as Identifier, Code or a copied value (Investment Decision Maker ->24, Large Trader ID ->38,
# Independent Current Market Price ->22, Research Payment Status ->19, Settlement Quantity / Amount ->25, Loan Trade
# Date ->25, OTC Trade Date ->25) are not references and are not registered.
