"""Key and link registry extension: Data Domains 27-29 (enterprise expansion, Phase 2 Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Keys every object of 27 Fund Accounting &
Valuation, 28 Custody & Asset Servicing and 29 Transfer Agency Operations, and links every Reference attribute whose
target is in the taxonomy. Several keys name two mutually exclusive references (exactly one populated, as the grain
says "X or Y"); the model completes such a key by coalescing the populated one. Fund-level rows of objects whose grain
says "share class (or fund level)" leave the share class blank in the key.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PRODUCT = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
PARTY = ("02", "Party")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ACCOUNT = ("15", "Account")
ACCOUNT_RESTRICTION = ("15", "Account Restriction")
INSTRUMENT = ("17", "Instrument")
CA_EVENT = ("17", "Corporate Action Event")
PORTFOLIO = ("18", "Portfolio")
EMPLOYEE = ("20", "Employee")
APPROVED_PRICE = ("22", "Approved Price")
FX_RATE = ("22", "FX Rate Observation")
SETTLEMENT_INSTRUCTION = ("26", "Settlement Instruction")
BOOK = ("27", "Fund Accounting Book")
NAV_CALC = ("27", "Fund NAV Calculation")
CLASS_NAV = ("27", "Share Class NAV")
NAV_ERROR = ("27", "NAV Error Case")
SKA = ("28", "Safekeeping Account")
ENTITLEMENT = ("28", "Corporate Action Entitlement")
CA_PAYMENT = ("28", "Corporate Action Payment")
LENDING_PROGRAM = ("28", "Securities Lending Program")
LOAN = ("28", "Securities Loan")
FUND_ORDER = ("29", "Fund Order")
AP_ORDER = ("29", "AP Creation / Redemption Order")
OBLIGATION = ("29", "Settlement Obligation")
SETTLEMENT_BATCH = ("29", "Intermediary Settlement Batch")

KEYS = {
    # ------------------------------------------------------------------ 27 Fund Books & Ledgers
    ("27", "Fund Accounting Book"): _k(["Book Fund", "Accounting Basis"], "Composite",
                                       note="Grain is fund x accounting basis; Book Code is an alternate key held "
                                            "in copy by the 18 identifier scheme."),
    ("27", "Fund Book Operating Period"): _k(["Operated Book", "Operating Period Effective From"], "Composite"),
    ("27", "Fund Book Portfolio Link"): _k(["Linked Book", "Accounted Portfolio", "Portfolio Link Effective From"],
                                           "Composite"),
    ("27", "Fund Ledger Account"): _k(["Fund Chart of Accounts", "Fund Ledger Account Number"], "Composite",
                                      note="The account number is unique only within its fund chart of accounts."),
    ("27", "Fund Journal Entry"): _k(["Fund Journal Entry ID"], "Natural"),
    ("27", "Fund Journal Line"): _k(["Line Journal", "Journal Line Number"], "Composite",
                                    note="Journal x line; Line Journal references the Fund Journal Entry header."),
    ("27", "Fund Trial Balance"): _k(["Balance Book", "Balance Fund Ledger Account", "Balance Share Class",
                                      "Balance Date"], "Composite",
                                     note="Balance Share Class is blank for fund-level balances; the ledger account's "
                                          "chart of accounts is the book's."),

    # ------------------------------------------------------------------ 27 ABOR Investment Accounting
    ("27", "ABOR Valuation Record"): _k(["Valuation Book", "Valued Instrument", "ABOR Valuation Date"], "Composite"),
    ("27", "ABOR to IBOR Reconciliation"): _k(["Reconciled Book", "Reconciled Portfolio", "Reconciled Instrument",
                                               "Reconciliation Date"], "Composite",
                                              note="The portfolio is in the key because one book can be linked to "
                                                   "several 18 portfolios."),
    ("27", "Income Accrual"): _k(["Accrual Book", "Accrual Instrument", "Income Type", "Income Accrual Date"],
                                 "Composite",
                                 note="Book (fund x basis) rather than 28's book / ISIN form; the 28 Income Collection "
                                      "joins through Related Income Collection and Expected Income Accrual."),

    # ------------------------------------------------------------------ 27 NAV Calculation
    ("27", "Fund NAV Calculation"): _k(["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number"],
                                       "Composite",
                                       note="Calculation source and version are separate grain members (Source_Notes "
                                            "27); Parent NAV Calculation and Checked Fund NAV carry this key."),
    ("27", "Share Class NAV"): _k(["Share Class NAV ID"], "Natural"),
    ("27", "CIT Unit Value Detail"): _fold("One detail row per CIT unit class NAV."),
    ("27", "Class Allocation"): _k(["Allocation NAV Calculation", "Allocation Share Class", "Class Allocation Item"],
                                   "Composite"),
    ("27", "NAV Dissemination"): _k(["Released NAV", "Release Sequence"], "Composite",
                                    note="The release only; per-channel transmission is 29 Price & Rate Transmission."),

    # ------------------------------------------------------------------ 27 Swing Pricing & Anti-Dilution
    ("27", "Swing Pricing Parameter"): _k(["Parameter Fund", "Parameter Effective From"], "Composite"),
    ("27", "Swing Pricing Decision"): _k(["Swing Pricing Decision ID"], "Natural"),

    # ------------------------------------------------------------------ 27 Fund Expenses
    ("27", "Fund Expense Budget"): _k(["Budget Fund", "Budget Expense Type", "Budget Fiscal Year End"], "Composite"),
    ("27", "Fund Expense Accrual"): _k(["Accrual Fund", "Accrual Share Class", "Accrual Expense Type",
                                        "Expense Accrual Date"], "Composite",
                                       note="Accrual Share Class is blank for fund-level accruals."),
    ("27", "Expense Cap & Waiver Accrual"): _k(["Waiver Share Class", "Waiver Type", "Waiver Accrual Date"],
                                               "Composite"),
    ("27", "Fund Expense Payment"): _k(["Paying Fund", "Expense Payee", "Fund Payment Reference"], "Composite",
                                       note="The payment reference is unique only per fund and payee, as the grain says."),

    # ------------------------------------------------------------------ 27 Income & Distributions
    ("27", "Distribution Declaration"): _k(["Distribution Declaration ID"], "Natural"),
    ("27", "Distribution Character"): _child(["Distribution Character Type", "Character Data Basis"],
                                             "Estimated and final rows coexist, so the data basis is a discriminator."),
    ("27", "Distributable Income Estimate"): _k(["Estimate Fund", "Distribution Requirement Period", "Estimate Date"],
                                                "Composite"),

    # ------------------------------------------------------------------ 27 Fund Tax
    ("27", "Fund Tax Year Record"): _k(["Fund Tax Year Record ID"], "Natural"),
    ("27", "Book-Tax Difference"): _k(["Difference Tax Year", "Book-Tax Difference Type", "Difference Instrument"],
                                      "Composite",
                                      note="Difference Instrument is blank for differences that are not "
                                           "instrument-specific."),
    ("27", "RIC Test Result"): _k(["Tested Fund", "RIC Test Type", "RIC Test Date"], "Composite"),

    # ------------------------------------------------------------------ 27 NAV Errors & Corrections
    ("27", "NAV Error Case"): _k(["NAV Error Case ID"], "Natural"),
    ("27", "NAV Error Impact"): _k(["Impact Case", "Impacted Share Class", "Impacted Valuation Date"], "Composite"),

    # ------------------------------------------------------------------ 27 NAV Controls & Fund Reporting
    ("27", "NAV Control Check"): _k(["Checked Fund NAV", "Checked Class NAV", "NAV Control Check Type",
                                     "Check Run Sequence"], "Composite",
                                    note="Exactly one of Checked Fund NAV and Checked Class NAV is populated."),
    ("27", "Fund Financial Statement"): _k(["Statement Book", "Statement Period End Date"], "Composite",
                                           note="Model gap: the grain names a statement set, but no attribute "
                                                "identifies it (Statements Included describes it), so two sets for "
                                                "one book and period end cannot be told apart."),
    ("27", "Financial Highlights"): _child(["Highlights Share Class"], "One per share class within the statement set."),

    # ------------------------------------------------------------------ 28 Custody Network
    ("28", "Custody Provider Profile"): _k(["Provider Party", "Provider Legal Entity", "Custody Provider Role",
                                            "Profile Effective From"], "Composite",
                                           note="Exactly one of Provider Party (02) and Provider Legal Entity (09, a "
                                                "self-custodying CIT trustee) is populated."),
    ("28", "Sub-Custodian Network Arrangement"): _k(["Arrangement Global Custodian", "Arrangement Market",
                                                     "Sub-Custodian", "Arrangement Effective From"], "Composite"),
    ("28", "Foreign Custody Assessment"): _k(["Assessed Arrangement", "Assessed Depository",
                                              "Foreign Custody Assessment Type", "Assessment Date"], "Composite",
                                             note="Exactly one of Assessed Arrangement and Assessed Depository is "
                                                  "populated."),
    ("28", "Custodian Service Review"): _k(["Reviewed Provider", "Reviewed Provider Role", "Review Period Start"],
                                           "Composite"),

    # ------------------------------------------------------------------ 28 Safekeeping Accounts
    ("28", "Safekeeping Account"): _k(["Safekeeping Account ID"], "Natural"),
    ("28", "Safekeeping Account Assignment"): _k(["Assigned Safekeeping Account", "Owning Fund", "Owning Portfolio",
                                                  "Owning Client Account", "Account Assignment Purpose",
                                                  "Assignment Effective From"], "Composite",
                                                 note="One owner reference per owner type, populated by the "
                                                      "assignment rule (fund + portfolio, or client account + "
                                                      "portfolio); blanks are part of the key."),
    # Client Asset Designation removed (FCA CASS; CW-928).

    # ------------------------------------------------------------------ 28 Custodian Statements & Reconciliation
    ("28", "Custodian Statement"): _k(["Statement Safekeeping Account", "Custodian Statement Type", "Statement Date",
                                       "Statement Number"], "Composite"),
    ("28", "Custodian Holding Statement Line"): _k(["Holding Line Statement", "Custodian Security Identifier",
                                                    "Place of Safekeeping", "Custodian Balance Type"], "Composite",
                                                   note="Keyed on the custodian's identifier as delivered; the mapped "
                                                        "17 instrument is an attribute."),
    ("28", "Custodian Cash Statement Entry"): _k(["Cash Entry Statement", "Custodian Entry Reference"], "Composite"),
    ("28", "Custody Reconciliation Run"): _k(["Custody Reconciliation Run ID"], "Natural"),
    ("28", "Custody Reconciliation Break"): _k(["Break ID"], "Natural"),

    # ------------------------------------------------------------------ 28 Corporate Action Processing
    ("28", "Corporate Action Notification Receipt"): _k(["Notified Safekeeping Account", "Custodian Message Reference"],
                                                        "Composite",
                                                        note="The message reference (SEME) is unique only per "
                                                             "sending custodian, which the safekeeping account fixes."),
    ("28", "Corporate Action Entitlement"): _k(["Corporate Action Entitlement ID"], "Natural"),
    ("28", "Corporate Action Election"): _k(["Corporate Action Election ID"], "Natural"),
    ("28", "Corporate Action Payment"): _k(["Paid Entitlement", "Payment Confirmation Reference"], "Composite"),

    # ------------------------------------------------------------------ 28 Income & Tax Recovery
    ("28", "Income Collection"): _k(["Income Entitlement"], "Composite",
                                    note="One control record per income entitlement; the entitlement reference is "
                                         "the key."),
    ("28", "Tax Relief Documentation"): _k(["Beneficial Owner Fund", "Relief Market", "Tax Relief Method",
                                            "Relief Effective From"], "Composite"),
    ("28", "Withholding Tax Reclaim"): _k(["Withholding Tax Reclaim ID"], "Natural"),
    ("28", "Class Action Claim"): _k(["Class Action Claim ID"], "Natural"),

    # ------------------------------------------------------------------ 28 Securities Lending
    ("28", "Securities Lending Program"): _k(["Lending Fund", "Lending Portfolio", "Agent Lender",
                                              "Program Effective From"], "Composite",
                                             note="Lending Portfolio is blank for a fund-level program."),
    ("28", "Securities Lending Agreement"): _k(["Agreement Program", "Agreement Agent", "Agreement Counterparty"],
                                               "Composite",
                                               note="Agreement Counterparty is blank for the authorization agreement."),
    ("28", "Securities Loan"): _k(["Securities Loan ID"], "Natural", note="Current state at the latest mark."),
    ("28", "Lending Collateral Received"): _k(["Collateralized Loan", "Collateral Pool Borrower",
                                               "Lending Collateral Type", "Collateral Instrument",
                                               "Collateral Mark Date"], "Composite",
                                              note="Exactly one of loan and borrower pool is populated; the collateral "
                                                   "item is type + instrument. Model gap: no collateral currency, so "
                                                   "cash collateral in two currencies cannot be told apart."),
    ("28", "Loan Regulatory Report"): _k(["Reported Loan", "Loan Reporting Regime"], "Composite"),
    ("28", "Lending Revenue Allocation"): _k(["Revenue Program", "Revenue Period Start"], "Composite"),

    # 28 Client Assets & Money family removed (FCA CASS; the Rule 15c3-3 customer-protection record is 49's; CW-928, CW-007).

    # ------------------------------------------------------------------ 29 Fund Order Capture
    ("29", "Fund Order"): _k(["Fund Order ID"], "Natural"),
    ("29", "Order Routing Detail"): _fold(),
    ("29", "As-Of Order Detail"): _fold("Populated only for as-of and correction orders."),
    ("29", "Order Event"): _k(["Event Fund Order", "Order Event Type", "Event Timestamp"], "Composite"),
    ("29", "Order Exception"): _k(["Exception Fund Order", "Order Exception Type", "Exception Raised Timestamp"],
                                  "Composite"),
    ("29", "Exchange Link"): _k(["Exchange Out Order", "Exchange In Order"], "Composite"),

    # ------------------------------------------------------------------ 29 Order Settlement
    ("29", "Settlement Obligation"): _k(["Settlement Obligation ID"], "Natural",
                                        note="The grain's obligation sequence has no attribute of its own; the ID "
                                             "stands for order x sequence."),
    ("29", "Intermediary Settlement Batch"): _k(["Settlement Batch ID"], "Natural",
                                                note="Grain includes Batch Data Basis, so estimated and final batches "
                                                     "have separate IDs."),
    ("29", "Cash Movement"): _k(["Cash Movement ID"], "Natural"),
    ("29", "Settlement Exception"): _k(["Exception Settlement Obligation", "Exception Settlement Batch",
                                        "Settlement Exception Type", "Exception Detected Date"], "Composite",
                                       note="Exactly one of obligation and batch is populated."),

    # ------------------------------------------------------------------ 29 ETF Primary Market
    ("29", "AP Creation / Redemption Order"): _k(["AP Order ID"], "Natural"),
    ("29", "AP Order Fee"): _fold(),
    ("29", "Basket Settlement Line"): _k(["Line AP Order", "Basket Constituent"], "Composite"),

    # ------------------------------------------------------------------ 29 Investor Identity & Financial Crime
    ("29", "Account Monitoring Alert"): _k(["Account Monitoring Alert ID"], "Natural"),
    ("29", "Alert Disposition"): _fold("One review and decision per alert."),
    ("29", "Shareholder Information Request"): _k(["Information Request Reference", "Requested Intermediary",
                                                   "Request Period Start Date"], "Composite",
                                                  note="One request reference can cover several intermediaries, as "
                                                       "the grain says."),

    # ------------------------------------------------------------------ 29 TA Controls
    ("29", "TA Control Check"): _k(["TA Control Check ID"], "Natural"),
    ("29", "TA Control Exception"): _k(["Exception Control Check", "Control Exception Number"], "Composite"),
    ("29", "TA Processing Calendar Event"): _k(["Governing Dealing Calendar", "Event Share Class", "Event Business Date",
                                                "Processing Calendar Event Type"], "Composite",
                                               note="Event Share Class is blank for calendar-wide events."),

    # ------------------------------------------------------------------ 29 Intermediary Order Interfaces
    ("29", "Order Interface Session"): _k(["Interface Session Key"], "Natural",
                                          note="The session key stands for dealing route x business date x cycle."),
    ("29", "Price & Rate Transmission"): _k(["Price Transmission Key"], "Natural",
                                            note="The transmission key stands for dissemination x channel x attempt."),
    # W2-W4 merge (2026-10-15): 29 objects restored or added
    ("29", "Brokerage Omnibus Order Detail"): _fold(),
    ("29", "Share Register Balance"): _k(["Register Account", "Register Share Class",
                                          "Register Business Date"], "Composite"),
    ("29", "Register Transaction"): _k(["Register Transaction ID"], "Natural"),
    ("29", "Intermediary Distribution Request"): _k(["Intermediary Distribution ID"], "Natural"),
    ("29", "NOBO List Request"): _fold(),
    ("29", "Servicing Provider Engagement"): _k(["Servicing Provider", "Servicing Role",
                                                 "Engagement Start Date"], "Composite"),
}

REFS = {
    # ------------------------------------------------------------------ 27 Fund Books & Ledgers
    ("27", "Fund Accounting Book", "Book Fund"): PRODUCT,
    ("27", "Fund Accounting Book", "Book Owner Entity"): LEGAL_ENTITY,
    ("27", "Fund Book Operating Period", "Operated Book"): BOOK,
    ("27", "Fund Book Operating Period", "Fund Administrator of Record"): PARTY,
    ("27", "Fund Book Portfolio Link", "Linked Book"): BOOK,
    ("27", "Fund Book Portfolio Link", "Accounted Portfolio"): PORTFOLIO,
    ("27", "Fund Journal Entry", "Journal Book"): BOOK,
    ("27", "Fund Journal Entry", "Reversed Journal"): ("27", "Fund Journal Entry"),
    ("27", "Fund Journal Entry", "Related NAV Error Case"): NAV_ERROR,
    ("27", "Fund Journal Entry", "Journal Approved By"): EMPLOYEE,
    ("27", "Fund Journal Line", "Line Journal"): ("27", "Fund Journal Entry"),
    ("27", "Fund Journal Line", "Line Fund Ledger Account"): ("27", "Fund Ledger Account"),
    ("27", "Fund Journal Line", "Line FX Rate"): FX_RATE,
    ("27", "Fund Journal Line", "Line Share Class"): SHARE_CLASS,
    ("27", "Fund Journal Line", "Line Instrument"): INSTRUMENT,
    ("27", "Fund Journal Line", "Source Portfolio Transaction"): ("18", "Portfolio Transaction"),
    ("27", "Fund Journal Line", "Source Settlement Instruction"): SETTLEMENT_INSTRUCTION,
    ("27", "Fund Journal Line", "Source Fund Order"): FUND_ORDER,
    ("27", "Fund Journal Line", "Source AP Order"): AP_ORDER,
    ("27", "Fund Journal Line", "Source Distribution Declaration"): ("27", "Distribution Declaration"),
    ("27", "Fund Trial Balance", "Balance Book"): BOOK,
    ("27", "Fund Trial Balance", "Balance Fund Ledger Account"): ("27", "Fund Ledger Account"),
    ("27", "Fund Trial Balance", "Balance Share Class"): SHARE_CLASS,

    # ------------------------------------------------------------------ 27 ABOR Investment Accounting
    ("27", "ABOR Valuation Record", "Valuation Book"): BOOK,
    ("27", "ABOR Valuation Record", "Valued Instrument"): INSTRUMENT,
    ("27", "ABOR Valuation Record", "Applied Price"): APPROVED_PRICE,
    ("27", "ABOR Valuation Record", "Applied Fair Value Determination"): ("22", "Fair Value Determination"),
    ("27", "ABOR Valuation Record", "Applied FX Rate"): FX_RATE,
    ("27", "ABOR to IBOR Reconciliation", "Reconciled Book"): BOOK,
    ("27", "ABOR to IBOR Reconciliation", "Reconciled Portfolio"): PORTFOLIO,
    ("27", "ABOR to IBOR Reconciliation", "Reconciled Instrument"): INSTRUMENT,
    ("27", "ABOR to IBOR Reconciliation", "Compared Holding"): ("18", "Portfolio Holding"),
    ("27", "Income Accrual", "Accrual Book"): BOOK,
    ("27", "Income Accrual", "Accrual Instrument"): INSTRUMENT,
    ("27", "Income Accrual", "Accrual Coupon Period"): ("17", "Coupon Schedule"),
    ("27", "Income Accrual", "Applied Rate Fixing"): ("22", "Reference Rate Fixing"),
    ("27", "Income Accrual", "Related Corporate Action Event"): CA_EVENT,
    ("27", "Income Accrual", "Related Income Collection"): ("28", "Income Collection"),

    # ------------------------------------------------------------------ 27 NAV Calculation
    ("27", "Fund NAV Calculation", "NAV Book"): BOOK,
    ("27", "Fund NAV Calculation", "NAV Approved By"): EMPLOYEE,
    ("27", "Share Class NAV", "NAV Share Class"): SHARE_CLASS,
    ("27", "Share Class NAV", "Parent NAV Calculation"): NAV_CALC,
    ("27", "Share Class NAV", "Applied Swing Decision"): ("27", "Swing Pricing Decision"),
    ("27", "Class Allocation", "Allocation NAV Calculation"): NAV_CALC,
    ("27", "Class Allocation", "Allocation Share Class"): SHARE_CLASS,
    ("27", "NAV Dissemination", "Released NAV"): CLASS_NAV,
    ("27", "NAV Dissemination", "Corrected Release"): ("27", "NAV Dissemination"),

    # ------------------------------------------------------------------ 27 Swing Pricing & Anti-Dilution
    ("27", "Swing Pricing Parameter", "Parameter Fund"): PRODUCT,
    ("27", "Swing Pricing Decision", "Decision Fund"): PRODUCT,
    ("27", "Swing Pricing Decision", "Applied Swing Parameter"): ("27", "Swing Pricing Parameter"),
    ("27", "Swing Pricing Decision", "Decision Approved By"): EMPLOYEE,

    # ------------------------------------------------------------------ 27 Fund Expenses
    ("27", "Fund Expense Budget", "Budget Fund"): PRODUCT,
    ("27", "Fund Expense Accrual", "Accrual Fund"): PRODUCT,
    ("27", "Fund Expense Accrual", "Accrual Share Class"): SHARE_CLASS,
    ("27", "Fund Expense Accrual", "Applied Fee Schedule"): ("01", "Management Fee"),
    ("27", "Expense Cap & Waiver Accrual", "Waiver Share Class"): SHARE_CLASS,
    ("27", "Expense Cap & Waiver Accrual", "Adviser Recoupment Receivable"): ("19", "Receivable Item"),
    ("27", "Expense Cap & Waiver Accrual", "Adviser Reimbursement Payable"): ("19", "Payable Invoice"),
    ("27", "Fund Expense Payment", "Paying Fund"): PRODUCT,
    ("27", "Fund Expense Payment", "Expense Payee"): PARTY,
    ("27", "Fund Expense Payment", "Paying Safekeeping Account"): SKA,

    # ------------------------------------------------------------------ 27 Income & Distributions, Fund Tax
    ("27", "Distribution Declaration", "Declaring Share Class"): SHARE_CLASS,
    ("27", "Distribution Declaration", "Reinvest NAV"): CLASS_NAV,
    ("27", "Distributable Income Estimate", "Estimate Fund"): PRODUCT,
    ("27", "Fund Tax Year Record", "Tax Year Fund"): PRODUCT,
    ("27", "Book-Tax Difference", "Difference Tax Year"): ("27", "Fund Tax Year Record"),
    ("27", "Book-Tax Difference", "Difference Instrument"): INSTRUMENT,
    ("27", "RIC Test Result", "Tested Fund"): PRODUCT,

    # ------------------------------------------------------------------ 27 NAV Errors, Controls & Fund Reporting
    ("27", "NAV Error Case", "Error Fund"): PRODUCT,
    ("27", "NAV Error Case", "Reimbursing Entity"): LEGAL_ENTITY,
    ("27", "NAV Error Case", "Reimbursing Third Party"): PARTY,
    ("27", "NAV Error Case", "Case Owner"): EMPLOYEE,
    ("27", "NAV Error Impact", "Impact Case"): NAV_ERROR,
    ("27", "NAV Error Impact", "Impacted Share Class"): SHARE_CLASS,
    ("27", "NAV Error Impact", "Published NAV"): CLASS_NAV,
    ("27", "NAV Error Impact", "Corrected NAV"): CLASS_NAV,
    ("27", "NAV Control Check", "Checked Fund NAV"): NAV_CALC,
    ("27", "NAV Control Check", "Checked Class NAV"): CLASS_NAV,
    ("27", "NAV Control Check", "Relied-On TA Control Check"): ("29", "TA Control Check"),
    ("27", "NAV Control Check", "Check Performed By"): EMPLOYEE,
    ("27", "Fund Financial Statement", "Statement Book"): BOOK,
    ("27", "Fund Financial Statement", "Statement Auditor"): PARTY,
    ("27", "Financial Highlights", "Highlights Share Class"): SHARE_CLASS,

    # ------------------------------------------------------------------ 28 Custody Network
    ("28", "Custody Provider Profile", "Provider Party"): PARTY,
    ("28", "Custody Provider Profile", "Provider Legal Entity"): LEGAL_ENTITY,
    ("28", "Custody Provider Profile", "Service Agreement Reference"): ("39", "Contract"),
    ("28", "Sub-Custodian Network Arrangement", "Arrangement Global Custodian"): PARTY,
    ("28", "Sub-Custodian Network Arrangement", "Sub-Custodian"): PARTY,
    ("28", "Sub-Custodian Network Arrangement", "Securities Depository"): PARTY,
    ("28", "Foreign Custody Assessment", "Assessed Arrangement"): ("28", "Sub-Custodian Network Arrangement"),
    ("28", "Foreign Custody Assessment", "Assessed Depository"): PARTY,
    ("28", "Foreign Custody Assessment", "Assessing Party"): PARTY,
    ("28", "Custodian Service Review", "Reviewed Provider"): PARTY,
    ("28", "Custodian Service Review", "Reviewer"): EMPLOYEE,

    # ------------------------------------------------------------------ 28 Safekeeping Accounts
    ("28", "Safekeeping Account", "Account Provider"): PARTY,
    ("28", "Safekeeping Account", "Internal Account Provider"): LEGAL_ENTITY,
    ("28", "Safekeeping Account", "Registered Nominee"): PARTY,
    ("28", "Safekeeping Account Assignment", "Assigned Safekeeping Account"): SKA,
    ("28", "Safekeeping Account Assignment", "Owning Fund"): PRODUCT,
    ("28", "Safekeeping Account Assignment", "Owning Portfolio"): PORTFOLIO,
    ("28", "Safekeeping Account Assignment", "Owning Client Account"): ACCOUNT,

    # ------------------------------------------------------------------ 28 Custodian Statements & Reconciliation
    ("28", "Custodian Statement", "Statement Safekeeping Account"): SKA,
    ("28", "Custodian Holding Statement Line", "Holding Line Statement"): ("28", "Custodian Statement"),
    ("28", "Custodian Holding Statement Line", "Statement Line Instrument"): INSTRUMENT,
    ("28", "Custodian Holding Statement Line", "Place of Safekeeping"): PARTY,
    ("28", "Custodian Cash Statement Entry", "Cash Entry Statement"): ("28", "Custodian Statement"),
    ("28", "Custody Reconciliation Run", "Reconciled Portfolio"): PORTFOLIO,
    ("28", "Custody Reconciliation Run", "Reconciled Safekeeping Account"): SKA,
    ("28", "Custody Reconciliation Run", "Compared Custodian Statement"): ("28", "Custodian Statement"),
    ("28", "Custody Reconciliation Run", "Signed Off By"): EMPLOYEE,
    ("28", "Custody Reconciliation Break", "Break Run"): ("28", "Custody Reconciliation Run"),
    ("28", "Custody Reconciliation Break", "Break Instrument"): INSTRUMENT,
    ("28", "Custody Reconciliation Break", "Book Holding"): ("18", "Portfolio Holding"),
    ("28", "Custody Reconciliation Break", "Book Cash Balance"): ("18", "Cash Balance"),
    ("28", "Custody Reconciliation Break", "ABOR Valuation Record"): ("27", "ABOR Valuation Record"),
    ("28", "Custody Reconciliation Break", "Custodian Statement Line"): ("28", "Custodian Holding Statement Line"),
    ("28", "Custody Reconciliation Break", "Difference Valuation Price"): APPROVED_PRICE,
    ("28", "Custody Reconciliation Break", "Break Owner"): EMPLOYEE,
    ("28", "Custody Reconciliation Break", "Related Settlement Instruction"): SETTLEMENT_INSTRUCTION,
    ("28", "Custody Reconciliation Break", "Related AP Order"): AP_ORDER,

    # ------------------------------------------------------------------ 28 Corporate Action Processing
    ("28", "Corporate Action Notification Receipt", "Notified Event"): CA_EVENT,
    ("28", "Corporate Action Notification Receipt", "Notified Safekeeping Account"): SKA,
    ("28", "Corporate Action Entitlement", "Entitlement Event"): CA_EVENT,
    ("28", "Corporate Action Entitlement", "Entitled Safekeeping Account"): SKA,
    ("28", "Corporate Action Entitlement", "Entitled Portfolio"): PORTFOLIO,
    ("28", "Corporate Action Election", "Elected Entitlement"): ENTITLEMENT,
    ("28", "Corporate Action Election", "Elected Option"): ("17", "Corporate Action Option"),
    ("28", "Corporate Action Election", "Election Decision Maker"): EMPLOYEE,
    ("28", "Corporate Action Election", "Election Investment Decision"): ("24", "Investment Decision"),
    ("28", "Corporate Action Payment", "Paid Entitlement"): ENTITLEMENT,
    ("28", "Corporate Action Payment", "Delivered Instrument"): INSTRUMENT,
    ("28", "Corporate Action Payment", "Booked Portfolio Transaction"): ("18", "Portfolio Transaction"),

    # ------------------------------------------------------------------ 28 Income & Tax Recovery
    ("28", "Income Collection", "Income Entitlement"): ENTITLEMENT,
    ("28", "Income Collection", "Expected Income Accrual"): ("27", "Income Accrual"),
    ("28", "Income Collection", "Received Payment"): CA_PAYMENT,
    ("28", "Tax Relief Documentation", "Beneficial Owner Fund"): PRODUCT,
    ("28", "Withholding Tax Reclaim", "Reclaiming Fund"): PRODUCT,
    ("28", "Withholding Tax Reclaim", "Source Payment"): CA_PAYMENT,
    ("28", "Withholding Tax Reclaim", "Filing Agent"): PARTY,
    ("28", "Class Action Claim", "Class Action Event"): CA_EVENT,
    ("28", "Class Action Claim", "Claiming Fund"): PRODUCT,
    ("28", "Class Action Claim", "Claiming Client Account"): ACCOUNT,
    ("28", "Class Action Claim", "Claim Filing Agent"): PARTY,

    # ------------------------------------------------------------------ 28 Securities Lending
    ("28", "Securities Lending Program", "Lending Fund"): PRODUCT,
    ("28", "Securities Lending Program", "Lending Portfolio"): PORTFOLIO,
    ("28", "Securities Lending Program", "Agent Lender"): PARTY,
    ("28", "Securities Lending Program", "Cash Collateral Reinvestment Portfolio"): PORTFOLIO,
    ("28", "Securities Lending Agreement", "Agreement Program"): LENDING_PROGRAM,
    ("28", "Securities Lending Agreement", "Agreement Agent"): PARTY,
    ("28", "Securities Lending Agreement", "Agreement Counterparty"): PARTY,
    ("28", "Securities Loan", "Loan Program"): LENDING_PROGRAM,
    ("28", "Securities Loan", "Governing Agreement"): ("28", "Securities Lending Agreement"),
    ("28", "Securities Loan", "Lent From Account"): SKA,
    ("28", "Securities Loan", "Borrower"): PARTY,
    ("28", "Securities Loan", "Loaned Instrument"): INSTRUMENT,
    ("28", "Lending Collateral Received", "Collateralized Loan"): LOAN,
    ("28", "Lending Collateral Received", "Collateral Pool Borrower"): PARTY,
    ("28", "Lending Collateral Received", "Collateral Instrument"): INSTRUMENT,
    ("28", "Lending Collateral Received", "Tri-Party Agent"): PARTY,
    ("28", "Loan Regulatory Report", "Reported Loan"): LOAN,
    ("28", "Loan Regulatory Report", "Reporting Party"): PARTY,
    ("28", "Lending Revenue Allocation", "Revenue Program"): LENDING_PROGRAM,
    ("28", "Lending Revenue Allocation", "Booked Fund Journal Entry"): ("27", "Fund Journal Entry"),

    # References of Client Asset Designation and the Client Assets & Money family removed with the objects (CW-928).

    # ------------------------------------------------------------------ 29 Fund Order Capture
    ("29", "Fund Order", "Order Share Class"): SHARE_CLASS,
    ("29", "Fund Order", "Order Account"): ACCOUNT,
    ("29", "Fund Order", "Receiving Party"): PARTY,
    ("29", "Fund Order", "Originating Service Request"): ("13", "Service Request"),
    ("29", "Fund Order", "Originating Standing Instruction"): ("15", "Account Standing Instruction"),
    ("29", "Fund Order", "Source Plan Contribution Batch"): ("16", "Payroll Contribution Batch"),
    ("29", "Fund Order", "Resulting Transaction"): ("29", "Register Transaction"),
    ("29", "Fund Order", "Processing Provider"): PARTY,
    ("29", "Order Routing Detail", "Receiving Interface Session"): ("29", "Order Interface Session"),
    ("29", "As-Of Order Detail", "Original Fund Order"): FUND_ORDER,
    ("29", "As-Of Order Detail", "Related NAV Error Case"): NAV_ERROR,
    ("29", "As-Of Order Detail", "Related Servicing Error"): ("13", "Servicing Error"),
    ("29", "As-Of Order Detail", "As-Of Approver"): EMPLOYEE,
    ("29", "Order Event", "Event Fund Order"): FUND_ORDER,
    ("29", "Order Event", "Event Performed By"): EMPLOYEE,
    ("29", "Order Exception", "Exception Fund Order"): FUND_ORDER,
    ("29", "Order Exception", "Blocking Account Restriction"): ACCOUNT_RESTRICTION,
    ("29", "Exchange Link", "Exchange Out Order"): FUND_ORDER,
    ("29", "Exchange Link", "Exchange In Order"): FUND_ORDER,

    # ------------------------------------------------------------------ 29 Order Settlement
    ("29", "Settlement Obligation", "Obligation Fund Order"): FUND_ORDER,
    ("29", "Settlement Obligation", "Obligation AP Order"): AP_ORDER,
    ("29", "Settlement Obligation", "Settling Party"): PARTY,
    ("29", "Settlement Obligation", "Obligation Settlement Batch"): SETTLEMENT_BATCH,
    ("29", "Intermediary Settlement Batch", "Batch Settling Party"): PARTY,
    ("29", "Cash Movement", "Settled Batch"): SETTLEMENT_BATCH,
    ("29", "Cash Movement", "Settled Obligation"): OBLIGATION,
    ("29", "Cash Movement", "Fund Cash Account"): SKA,
    ("29", "Cash Movement", "Client Money Movement"): ("50", "Money Movement"),
    ("29", "Settlement Exception", "Exception Settlement Obligation"): OBLIGATION,
    ("29", "Settlement Exception", "Exception Settlement Batch"): SETTLEMENT_BATCH,

    # ------------------------------------------------------------------ 29 ETF Primary Market
    ("29", "AP Creation / Redemption Order", "Authorized Participant"): PARTY,
    ("29", "AP Creation / Redemption Order", "AP Agreement"): ("05", "Distribution Agreement"),
    ("29", "AP Creation / Redemption Order", "ETF Share Class"): SHARE_CLASS,
    ("29", "AP Creation / Redemption Order", "Applied ETF Basket"): ("24", "ETF Basket"),
    ("29", "AP Creation / Redemption Order", "AP Order Processing Provider"): PARTY,
    ("29", "AP Creation / Redemption Order", "AP Resulting Transaction"): ("29", "Register Transaction"),
    ("29", "Basket Settlement Line", "Line AP Order"): AP_ORDER,
    ("29", "Basket Settlement Line", "Basket Constituent"): ("24", "ETF Basket Constituent"),
    ("29", "Basket Settlement Line", "Line Delivery Settlement"): SETTLEMENT_INSTRUCTION,

    # ------------------------------------------------------------------ 29 Investor Identity & Financial Crime
    ("29", "Account Monitoring Alert", "Alert Account"): ACCOUNT,
    ("29", "Account Monitoring Alert", "Alert Subject Party"): PARTY,
    ("29", "Account Monitoring Alert", "Triggering Fund Order"): FUND_ORDER,
    ("29", "Account Monitoring Alert", "Triggering Cash Movement"): ("29", "Cash Movement"),
    ("29", "Account Monitoring Alert", "Triggering Money Movement"): ("50", "Money Movement"),
    ("29", "Alert Disposition", "Alert Reviewer"): EMPLOYEE,
    ("29", "Alert Disposition", "Second Reviewer"): EMPLOYEE,
    ("29", "Alert Disposition", "Escalation Case Reference"): ("38", "AML Case"),
    ("29", "Alert Disposition", "Alert Resulting Account Restriction"): ACCOUNT_RESTRICTION,
    ("29", "Shareholder Information Request", "Requested Intermediary"): PARTY,
    ("29", "Shareholder Information Request", "Shareholder Information Agreement"): ("05", "Distribution Agreement"),
    ("29", "Shareholder Information Request", "Omnibus Account Covered"): ACCOUNT,
    ("29", "Shareholder Information Request", "Requested Share Classes"): SHARE_CLASS,
    ("29", "Shareholder Information Request", "Response Data Load"): ("06", "Load"),
    ("29", "Shareholder Information Request", "Related Frequent Trading Case"): ("08", "Frequent Trading Case"),

    # ------------------------------------------------------------------ 29 TA Controls, Intermediary Order Interfaces
    ("29", "TA Control Check", "Control Share Class"): SHARE_CLASS,
    ("29", "TA Control Check", "Control Fund"): PRODUCT,
    ("29", "TA Control Check", "Compared NAV Record"): CLASS_NAV,
    ("29", "TA Control Check", "Control Processing Provider"): PARTY,
    ("29", "TA Control Check", "Control Signed Off By"): EMPLOYEE,
    ("29", "TA Control Exception", "Exception Control Check"): ("29", "TA Control Check"),
    ("29", "TA Control Exception", "Control Exception Owner"): EMPLOYEE,
    ("29", "TA Control Exception", "Exception Related Fund Order"): FUND_ORDER,
    ("29", "TA Control Exception", "Exception Servicing Error"): ("13", "Servicing Error"),
    ("29", "TA Processing Calendar Event", "Governing Dealing Calendar"): ("09", "Calendar"),
    ("29", "TA Processing Calendar Event", "Event Share Class"): SHARE_CLASS,
    ("29", "Order Interface Session", "Session Counterparty"): PARTY,
    ("29", "Order Interface Session", "Related Feed Load"): ("06", "Load"),
    ("29", "Price & Rate Transmission", "Transmitted Dissemination"): ("27", "NAV Dissemination"),
    ("29", "Share Register Balance", "Register Account"): ACCOUNT,
    ("29", "Share Register Balance", "Register Share Class"): SHARE_CLASS,
    ("29", "Share Register Balance", "Governing Account Restriction"): ACCOUNT_RESTRICTION,
    ("29", "Share Register Balance", "Last Register Transaction"): ("29", "Register Transaction"),
    ("29", "Share Register Balance", "Register Keeper"): PARTY,
    ("29", "Register Transaction", "Posting Account"): ACCOUNT,
    ("29", "Register Transaction", "Posting Share Class"): SHARE_CLASS,
    ("29", "Register Transaction", "Applied NAV Record"): CLASS_NAV,
    ("29", "Register Transaction", "Originating Fund Order"): FUND_ORDER,
    ("29", "Register Transaction", "Originating AP Order"): AP_ORDER,
    ("29", "Register Transaction", "Originating Distribution Declaration"): ("27", "Distribution Declaration"),
    ("29", "Register Transaction", "Transfer Counter Account"): ACCOUNT,
    ("29", "Register Transaction", "Reversed Register Transaction"): ("29", "Register Transaction"),
    ("29", "Intermediary Distribution Request", "BOD Communication"): ("13", "Shareholder Communication"),
    ("29", "Intermediary Distribution Request", "Intermediary"): PARTY,
    ("29", "Servicing Provider Engagement", "Servicing Provider"): PARTY,
    ("29", "Servicing Provider Engagement", "Provider Service Levels"): ("13", "Service Level Definition"),
}

# W2-W4 merge (2026-10-15): ("27", "Fund Expense Accrual", "Applied Fee Schedule") is now typed Reference (Fund Fee
# Schedule, 01) (CW-051 re-cut) and registered to 01 Management Fee, the fund fee terms group. It folds into 01 Share
# Class, so models still join the accrual through Accrual Share Class. The 47 Fee Schedule is the client fee schedule
# and is not the target. CIP Verification (CIP-) is retired with the 29 W3 pass; 29 Register Transaction (RGTX-) and
# Share Register Balance are keyed, and the CW-088 objects moved from 13 (Intermediary Distribution Request, NOBO List
# Request, Servicing Provider Engagement) are keyed here.
