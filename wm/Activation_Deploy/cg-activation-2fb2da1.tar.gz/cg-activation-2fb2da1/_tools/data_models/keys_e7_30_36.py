"""Key and link registry extension: Data Domains 30 Private Markets and 36 Product Development & Lifecycle (Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). keys_g8_22_30.py keys no 30 object, so every 30 and
36 object is keyed here. Grains are those of enrichment/enrich_30.py and enrich_36.py GRAIN.

30 objects without an ID attribute are keyed on the references and dates their grain names; references to them (for
example Purpose Investment -> Private Investment) carry that composite key. Attribute Groups that repeat within their
parent are child entities keyed by the parent key plus the discriminators below; the attribute that points back to the
parent (Purpose Capital Call, Source Distribution, Detail Capital Account, Ownership Investment, Real Asset Investment,
Tier Calculation, Evidence Business Case) is the parent key itself and is not repeated in pk.

W2-W4 merge (2026-10-15): the 30 Private Markets entries are deleted, not folded (CW-930). The 36 objects keep their
wholesale kinds (the nine kind changes were reverted by the 36 fix pass), Changed Product Scope and Proposed Term Change
gain the service offering and service tier levels, Product Review keeps PRVW- (with the subject prefix), Target Market
Review Result and Value Assessment Criterion Result are removed (CW-936), and Service Offering Specification, Platform
Feature Specification and Product Review Criterion Result are added (proposals_w4_36 KEY_ROWS).
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PRODUCT = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
MODEL_PORTFOLIO = ("01", "Model Portfolio")
PARTY = ("02", "Party")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
EMPLOYEE = ("20", "Employee")
SAFEKEEPING_ACCOUNT = ("28", "Safekeeping Account")
AGREEMENT = ("05", "Distribution Agreement")
FEE_STUDY = ("11", "Fee Benchmark Study")
PROFITABILITY = ("10", "Profitability Record")
PRODUCT_DOCUMENT = ("01", "Product Document")


PROPOSAL = ("36", "Product Proposal")
BUSINESS_CASE = ("36", "Product Business Case")
COMMITTEE = ("36", "Product Governance Committee")
CHANGE = ("36", "Product Change Initiative")
READINESS_PLAN = ("36", "Product Readiness Plan")
REVIEW = ("36", "Product Review")

KEYS = {
    # ------------------------------------------------------------------ 36 Product Ideas & Proposals
    ("36", "Product Proposal"): _k(["Product Proposal ID"], "Natural", note="PPSL- identifier."),
    ("36", "Proposal Stage History"): _k(["Stage Proposal", "Proposal Stage", "Stage Entered Date"], "Composite"),
    ("36", "Product Business Case"): _k(["Business Case Proposal", "Business Case Version"], "Composite"),
    ("36", "Business Case Market Evidence"): _child(["Evidence Sequence"]),
    # ------------------------------------------------------------------ 36 Product Governance
    ("36", "Product Governance Committee"): _k(["Product Committee Code"], "Natural"),
    ("36", "Product Committee Membership"): _k(["Membership Committee", "Product Committee Member",
                                                "Product Committee Member Role", "Membership Effective From"], "Composite"),
    ("36", "Product Committee Meeting"): _k(["Meeting Product Committee", "Product Committee Meeting Date",
                                             "Product Committee Meeting Sequence"], "Composite"),
    ("36", "Product Approval Decision"): _k(["Product Approval Decision ID"], "Natural",
                                            note="PAPR- identifier; Decision Meeting + Agenda Item Number is the alternate "
                                                 "key."),
    # ------------------------------------------------------------------ 36 Product Change & Lifecycle Events
    ("36", "Product Change Initiative"): _k(["Product Change Initiative ID"], "Natural", note="LCHG- identifier."),
    ("36", "Changed Product Scope"): _k(["Scope Change Initiative", "Scope Product",
                                         "Scope Share Class", "Scope Model Portfolio",
                                         "Scope Service Offering", "Scope Service Tier",
                                         "Change Scope Role"], "Composite",
                                        note="A row is at one scope level (product, share class, model portfolio, "
                                             "service offering or service tier); the levels it does not use are "
                                             "empty."),
    ("36", "Proposed Term Change"): _k(["Term Change Initiative", "Product Term Name", "Term Product",
                                        "Term Share Class", "Term Model Portfolio",
                                        "Term Service Offering", "Term Service Tier"], "Composite",
                                       note="A row is at one term level (product, share class, model portfolio, "
                                            "service offering or service tier); the levels it does not use are empty."),
    ("36", "Share Class Specification"): _k(["Specification Change Initiative", "Specification Product",
                                             "Proposed Class Designation"], "Composite"),
    ("36", "Fund Reorganization Detail"): _fold("Present only on merger and shell reorganization initiatives."),
    ("36", "ETF Conversion Detail"): _fold("Present only on mutual fund to ETF conversion initiatives."),
    ("36", "Liquidation Detail"): _fold("Present only on liquidation initiatives."),
    ("36", "Change Impact Assessment"): _k(["Impact Change Initiative", "Impact Area"], "Composite"),
    ("36", "Change Regulatory Requirement"): _k(["Requirement Change Initiative", "Regulatory Requirement Type",
                                                 "Requirement Product", "Requirement Country"], "Composite"),
    # ------------------------------------------------------------------ 36 Launch & Readiness
    ("36", "Product Readiness Plan"): _k(["Readiness Change Initiative", "Readiness Plan Version"], "Composite"),
    ("36", "Readiness Check"): _k(["Check Readiness Plan", "Readiness Workstream", "Readiness Check Name"], "Composite",
                                  note="Check Readiness Plan carries the two-part readiness plan version key."),
    # ------------------------------------------------------------------ 36 Product Reviews
    ("36", "Product Review"): _k(["Product Review ID"], "Natural",
                                 note="PRVW- identifier with the subject prefix and a sequence suffix, so two "
                                      "reviews of one type in a period do not collide."),
    ("36", "Review Action"): _k(["Action Review", "Review Action Sequence"], "Composite"),
    # W2-W4 merge (2026-10-15): 36 objects restored or added
    ("36", "Service Offering Specification"): _child(["Offering Specification Sequence"],
                                                     "Several offerings per initiative."),
    ("36", "Platform Feature Specification"): _child(["Specified Feature Type"], "One row per feature type per "
                                                     "initiative."),
    ("36", "Product Review Criterion Result"): _k(["Criterion Review", "Product Review Criterion",
                                                   "Criterion Share Class"], "Composite",
                                                  note="Criterion Share Class is empty when the subject is "
                                                       "assessed as a whole."),
}

REFS = {
    # ------------------------------------------------------------------ 36 Product Ideas & Proposals
    ("36", "Product Proposal", "Proposed Strategy"): ("01", "Investment Strategy"),
    ("36", "Product Proposal", "Proposed Model Portfolio"): MODEL_PORTFOLIO,
    ("36", "Product Proposal", "Proposed Manufacturer Entity"): LEGAL_ENTITY,
    ("36", "Product Proposal", "Proposal Sponsor"): EMPLOYEE,
    ("36", "Proposal Stage History", "Stage Proposal"): PROPOSAL,
    ("36", "Proposal Stage History", "Stage Changed By"): EMPLOYEE,
    ("36", "Product Business Case", "Business Case Proposal"): PROPOSAL,
    ("36", "Business Case Market Evidence", "Evidence Business Case"): BUSINESS_CASE,
    ("36", "Business Case Market Evidence", "Evidence Peer Universe"): ("11", "Peer Universe"),
    ("36", "Business Case Market Evidence", "Evidence Fee Benchmark Study"): FEE_STUDY,
    ("36", "Business Case Market Evidence", "Evidence Market Sizing Record"): ("11", "Market Sizing Record"),
    ("36", "Business Case Market Evidence", "Evidence Competitor Event"): ("11", "Competitor Event"),
    ("36", "Business Case Market Evidence", "Evidence Profitability Record"): PROFITABILITY,
    ("36", "Business Case Market Evidence", "Evidence Flow and Revenue Forecast"): ("10", "Flow & Revenue Forecast"),
    ("36", "Business Case Market Evidence", "Evidence Competitor Pricing Observation"):
        ("11", "Competitor Pricing Observation"),
    ("36", "Business Case Market Evidence", "Evidence Pricing Scenario"): ("10", "Pricing Scenario"),
    # ------------------------------------------------------------------ 36 Product Governance
    ("36", "Product Governance Committee", "Committee Manufacturer Entity"): LEGAL_ENTITY,
    ("36", "Product Governance Committee", "Parent Product Committee"): COMMITTEE,
    ("36", "Product Committee Membership", "Membership Committee"): COMMITTEE,
    ("36", "Product Committee Membership", "Product Committee Member"): EMPLOYEE,
    ("36", "Product Committee Meeting", "Meeting Product Committee"): COMMITTEE,
    ("36", "Product Approval Decision", "Decision Meeting"): ("36", "Product Committee Meeting"),
    ("36", "Product Approval Decision", "Decision Subject Proposal"): PROPOSAL,
    ("36", "Product Approval Decision", "Decision Subject Change Initiative"): CHANGE,
    ("36", "Product Approval Decision", "Decision Subject Review"): REVIEW,
    # ------------------------------------------------------------------ 36 Product Change & Lifecycle Events
    ("36", "Product Change Initiative", "Originating Proposal"): PROPOSAL,
    ("36", "Product Change Initiative", "Change Sponsor"): EMPLOYEE,
    ("36", "Changed Product Scope", "Scope Change Initiative"): CHANGE,
    ("36", "Changed Product Scope", "Scope Product"): PRODUCT,
    ("36", "Changed Product Scope", "Scope Share Class"): SHARE_CLASS,
    ("36", "Changed Product Scope", "Scope Model Portfolio"): MODEL_PORTFOLIO,
    ("36", "Changed Product Scope", "Mapped Successor Share Class"): SHARE_CLASS,
    ("36", "Changed Product Scope", "Scope Service Offering"): ("01", "Service Offering"),
    ("36", "Changed Product Scope", "Scope Service Tier"): ("01", "Service Tier"),
    ("36", "Proposed Term Change", "Term Change Initiative"): CHANGE,
    ("36", "Proposed Term Change", "Term Product"): PRODUCT,
    ("36", "Proposed Term Change", "Term Share Class"): SHARE_CLASS,
    ("36", "Proposed Term Change", "Term Model Portfolio"): MODEL_PORTFOLIO,
    ("36", "Proposed Term Change", "Proposed Benchmark"): ("01", "Benchmark"),
    ("36", "Proposed Term Change", "Term Service Offering"): ("01", "Service Offering"),
    ("36", "Proposed Term Change", "Term Service Tier"): ("01", "Service Tier"),
    ("36", "Proposed Term Change", "Proposed Fee Schedule"): ("47", "Fee Schedule"),
    ("36", "Share Class Specification", "Specification Change Initiative"): CHANGE,
    ("36", "Share Class Specification", "Specification Product"): PRODUCT,
    ("36", "Share Class Specification", "Created Share Class"): SHARE_CLASS,
    ("36", "Change Impact Assessment", "Impact Change Initiative"): CHANGE,
    ("36", "Change Impact Assessment", "Liquidity Evidence Profile"): ("31", "Fund Liquidity Profile"),
    ("36", "Change Impact Assessment", "Impact Assessed By"): EMPLOYEE,
    ("36", "Change Regulatory Requirement", "Requirement Change Initiative"): CHANGE,
    ("36", "Change Regulatory Requirement", "Requirement Product"): PRODUCT,
    ("36", "Change Regulatory Requirement", "Satisfying Filing"): ("35", "Fund Regulatory Filing"),
    ("36", "Change Regulatory Requirement", "Satisfying Exemptive Relief"): ("35", "Exemptive Relief Reliance"),
    ("36", "Change Regulatory Requirement", "Satisfying Shareholder Communication"): ("13", "Shareholder Communication"),
    ("36", "Change Regulatory Requirement", "Satisfying Proxy Proposal"): ("13", "Proxy Proposal"),
    ("36", "Change Regulatory Requirement", "Satisfying Firm Filing"): ("38", "Firm Regulatory Filing"),
    # ------------------------------------------------------------------ 36 Launch & Readiness
    ("36", "Product Readiness Plan", "Readiness Change Initiative"): CHANGE,
    ("36", "Product Readiness Plan", "Seed Portfolio"): ("18", "Portfolio"),
    ("36", "Product Readiness Plan", "Seed Investor"): PARTY,
    ("36", "Product Readiness Plan", "Readiness Plan Owner"): EMPLOYEE,
    ("36", "Readiness Check", "Check Readiness Plan"): READINESS_PLAN,
    ("36", "Readiness Check", "Readiness Check Owner"): EMPLOYEE,
    ("36", "Readiness Check", "Evidence Fund Accounting Book"): ("27", "Fund Accounting Book"),
    ("36", "Readiness Check", "Evidence Safekeeping Account"): SAFEKEEPING_ACCOUNT,
    ("36", "Readiness Check", "Evidence TA Control Check"): ("29", "TA Control Check"),
    ("36", "Readiness Check", "Evidence Pricing Policy"): ("22", "Pricing Policy"),
    ("36", "Readiness Check", "Evidence Index Use"): ("14", "Index Use"),
    ("36", "Readiness Check", "Evidence Distribution Agreement"): AGREEMENT,
    ("36", "Readiness Check", "Evidence Shelf Placement"): ("05", "Shelf Placement"),
    ("36", "Readiness Check", "Evidence Model Program Placement"): ("05", "Model Program Placement"),
    # ("36", "Readiness Check", "Evidence Country Registration") dropped: 01 Country Registration was removed with no
    # successor (CW-901, US only); the attribute is left without a link until 36 re-types or drops it.
    ("36", "Readiness Check", "Evidence Listing"): ("01", "Listing"),
    ("36", "Readiness Check", "Evidence Product Document"): PRODUCT_DOCUMENT,
    ("36", "Readiness Check", "Evidence Rule Coding Request"): ("33", "Rule Coding Request"),
    ("36", "Readiness Check", "Evidence Platform Product Availability"): ("01", "Platform Product Availability"),
    ("36", "Readiness Check", "Evidence Supervisory Policy"): ("38", "Policy"),
    ("36", "Readiness Check", "Evidence Release"): ("41", "Release"),
    # ------------------------------------------------------------------ 36 Product Reviews
    ("36", "Product Review", "Review Product"): PRODUCT,
    ("36", "Product Review", "Review Share Class"): SHARE_CLASS,
    ("36", "Product Review", "Review Model Portfolio"): MODEL_PORTFOLIO,
    ("36", "Product Review", "Review Approver"): EMPLOYEE,
    ("36", "Product Review", "Review Report Document"): PRODUCT_DOCUMENT,
    ("36", "Product Review", "Review Service Offering"): ("01", "Service Offering"),
    ("36", "Product Review", "Review Platform Feature"): ("36", "Platform Feature Specification"),
    ("36", "Review Action", "Action Review"): REVIEW,
    ("36", "Review Action", "Action Share Class"): SHARE_CLASS,
    ("36", "Review Action", "Review Action Owner"): EMPLOYEE,
    ("36", "Review Action", "Resulting Change Initiative"): CHANGE,
    ("36", "Service Offering Specification", "Offering Specification Change Initiative"): CHANGE,
    ("36", "Service Offering Specification", "Proposed Model Portfolios"): MODEL_PORTFOLIO,
    ("36", "Service Offering Specification", "Proposed Offering Fee Schedule"): ("47", "Fee Schedule"),
    ("36", "Service Offering Specification", "Created Service Offering"): ("01", "Service Offering"),
    ("36", "Platform Feature Specification", "Feature Specification Change Initiative"): CHANGE,
    ("36", "Platform Feature Specification", "Governing Policy Rule"): ("01", "Tradable Universe Policy Rule"),
    ("36", "Platform Feature Specification", "Created Platform Feature"): ("01", "Platform Feature"),
    ("36", "Platform Feature Specification", "Eligible Offerings"): ("01", "Service Offering"),
    ("36", "Product Review Criterion Result", "Criterion Review"): REVIEW,
    ("36", "Product Review Criterion Result", "Criterion Share Class"): SHARE_CLASS,
    ("36", "Product Review Criterion Result", "Performance Evidence Return"): ("32", "Performance Return"),
    ("36", "Product Review Criterion Result", "Benchmark Evidence Return"): ("32", "Benchmark Return"),
    ("36", "Product Review Criterion Result", "Peer Evidence Universe"): ("11", "Peer Universe"),
    ("36", "Product Review Criterion Result", "Fee Evidence Study"): FEE_STUDY,
    ("36", "Product Review Criterion Result", "Cost Evidence Profitability Record"): PROFITABILITY,
    ("36", "Product Review Criterion Result", "Flow Evidence Measure Value"): ("06", "Measure Value"),
    ("36", "Product Review Criterion Result", "Evidence Metric Definition"): ("21", "Metric Definition"),
}

# Every Reference attribute of 36 resolves to a taxonomy object, so none is left out of REFS. Notes:
#   Attributes marked ->NN in the catalog but not typed Reference (Launch Project Code ->41, Requirement Status /
#       Satisfied Date ->35, AFM Board Approval Date ->35, Current Term Rate / Text ->01, Affected AUM ->06 ...) are
#       derived copies, not links, and are not registered. Launch Project Code (CD-239) holds the 41 Project code as
#       a copy; a model may join it by value to ("41", "Project").
