"""Key and link registry extension: Data Domains 31 Investment Risk, 32 Performance & Attribution and 33 Investment
Compliance (enterprise expansion, Phase 2, Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Every object of the three domains is keyed; none was
keyed in keys_g7/g8/g9.

Conventions specific to these domains:
- Versioned masters (risk model, stress scenario, compliance rule, rule library, attribution model, calculation policy,
  rule instrument list) are keyed code or ID x version. A reference to one of them holds the composite value (for example
  "STRESS-0042 / 2"), or the ID alone with the version in a sibling attribute (Linked Rule + Linked Rule Version).
- Typed subject references (exactly one filled per row, the Subject Type is the discriminator) are all in the key; an
  unfilled key part is written '(none)', as the 31 and 32 grain key formats say. The same holds for the grain's "blank
  for absolute" benchmark, "blank when no model is used" run and "blank for firm" scope parts.
- Fund-keyed program results (Rule 22e-4, Rule 18f-4) are keyed by the 01 fund (Investment Product);
  measures, exposures and results are keyed by the 18 portfolio.

W2-W4 merge (2026-10-15): the 32 private-markets objects (Private Markets Performance Measure, Investor Performance
Measure, Public Market Equivalent) are removed with 30 (CW-930). The 32 W3 pass adds Personal Rate of Return (PRROR-),
Household Performance Group (HPGRP-) and Member, Client Performance Profile and Client Return Exception.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


# Frequent targets
FUND = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
BENCHMARK = ("01", "Benchmark")
COMPOSITE = ("01", "GIPS Composite")
MODEL_PORTFOLIO = ("01", "Model Portfolio")
STRATEGY = ("01", "Investment Strategy")
RESTRICTION = ("01", "Investment Restriction")
PARTY = ("02", "Party")
CLIENT_RESTRICTION = ("02", "Client Restriction")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
CLASS_SCHEME = ("09", "Classification Scheme")
DATASET = ("14", "Dataset")
ACCOUNT = ("15", "Account")
INSTRUMENT = ("17", "Instrument")
PORTFOLIO = ("18", "Portfolio")
EMPLOYEE = ("20", "Employee")
CURVE = ("22", "Curve Definition")
ETF_STAT = ("22", "ETF Market Statistic")
FAIR_VALUE = ("22", "Fair Value Determination")
INDEX_LEVEL = ("22", "Index Level Observation")
TRADE_ORDER = ("25", "Trade Order")
CPTY_LIMIT = ("25", "Counterparty Trading Limit")
FUND_NAV = ("27", "Fund NAV Calculation")
NAV_ERROR = ("27", "NAV Error Case")
CHANGE_INITIATIVE = ("36", "Product Change Initiative")
MODEL_INVENTORY = ("37", "Model Inventory Entry")

# Own objects used as targets
RISK_MODEL = ("31", "Risk Model")
RISK_FACTOR = ("31", "Risk Factor")
RISK_RUN = ("31", "Risk Calculation Run")
RISK_MEASURE = ("31", "Portfolio Risk Measure")
STRESS_SCENARIO = ("31", "Stress Scenario")
RISK_LIMIT = ("31", "Risk Limit")
PERF_RETURN = ("32", "Performance Return")
BMK_RETURN = ("32", "Benchmark Return")
ATTRIB_RESULT = ("32", "Attribution Result")
RULE = ("33", "Compliance Rule")
RULE_LIBRARY = ("33", "Rule Library")
RULE_LIST = ("33", "Rule Instrument List")
CODING_REQUEST = ("33", "Rule Coding Request")
CHECK_RUN = ("33", "Compliance Check Run")
ALERT = ("33", "Compliance Alert")
BREACH = ("33", "Investment Breach")

KEYS = {
    # ------------------------------------------------------------------ 31 Risk Models & Factors
    ("31", "Risk Model"): _k(["Risk Model Code", "Risk Model Version"], "Composite",
                             note="A new version keeps the code; references hold 'code / version'."),
    ("31", "Risk Factor"): _k(["Factor Risk Model", "Risk Factor Code"], "Composite",
                              note="Factor codes repeat across model versions; the factor is dated by its model version."),
    ("31", "Risk Factor Return"): _k(["Return Risk Factor", "Factor Return Date"], "Composite"),
    ("31", "Instrument Factor Loading"): _k(["Loading Risk Model", "Loaded Instrument", "Loading Risk Factor",
                                             "Factor Loading Date"], "Composite"),
    # ------------------------------------------------------------------ 31 Risk Measurement
    ("31", "Risk Calculation Run"): _k(["Run Risk Model", "Run As-Of Date", "Run Scope"], "Composite",
                                       note="No run ID: the grain is model version x as-of date x scope."),
    ("31", "Portfolio Risk Measure"): _k(["Measure Calculation Run", "Measured Portfolio", "Risk Measure",
                                          "Risk Horizon Days", "Confidence Level", "Measure Benchmark"], "Composite",
                                         note="Measure Benchmark is '(none)' for absolute measures, so 1-day and "
                                              "20-day VaR and tracking error against two benchmarks stay distinct."),
    ("31", "Risk Decomposition"): _k(["Decomposed Measure", "Risk Dimension", "Risk Bucket"], "Composite",
                                     note="Decomposed Measure holds the full Portfolio Risk Measure key."),
    ("31", "VaR Back-Test"): _k(["Back-Tested Portfolio", "Back-Test Risk Model", "Back-Test Date",
                                 "Back-Test P&L Basis"], "Composite"),
    # ------------------------------------------------------------------ 31 Exposures
    ("31", "Portfolio Exposure"): _k(["Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run",
                                      "Exposure Dimension", "Exposure Bucket", "Exposure Measure", "Exposure Benchmark"],
                                     "Composite",
                                     note="Run is '(none)' when no model is used and benchmark '(none)' for absolute "
                                          "exposures."),
    ("31", "Counterparty Exposure"): _k(["Exposure Counterparty", "Counterparty Exposure Date",
                                         "Counterparty Exposure Measure", "Counterparty Exposure Portfolio",
                                         "Exposure Trading Entity", "Netting Set Agreement"], "Composite",
                                        note="The scope is the portfolio or the trading entity ('(none)' for both at "
                                             "firm level); the netting set is '(none)' when not netted."),
    ("31", "Leverage & Exposure Measurement"): _k(["Measured Fund", "Leverage Measurement Date", "Exposure Method"],
                                                  "Composite",
                                                  note="Fund-keyed program result measured on the fund's whole 18 book."),
    # ------------------------------------------------------------------ 31 Stress Testing
    ("31", "Stress Scenario"): _k(["Stress Scenario ID", "Stress Scenario Version"], "Composite",
                                  note="STRESS- is stable across versions; a change of shocks creates a new version."),
    ("31", "Stress Scenario Shock"): _k(["Shock Scenario", "Shocked Risk Factor", "Shocked Curve", "Shock Tenor",
                                         "Shocked Index"], "Composite",
                                        note="Exactly one of factor, curve (with tenor) or index is set per row. Model "
                                             "gap: the grain's 'market variable' other than a 01 index (an FX rate or "
                                             "volatility not modeled as a factor) has no attribute of its own."),
    ("31", "Stress Test Result"): _k(["Result Scenario", "Stressed Portfolio", "Stress Test Date"], "Composite"),
    ("31", "Liquidity Stress Detail"): _fold("One per stress test result, populated on liquidity scenarios only."),
    # ------------------------------------------------------------------ 31 Liquidity Risk
    ("31", "Liquidity Classification"): _k(["Classified Fund", "Classified Instrument", "Classification Date",
                                            "Classification Portion Number"], "Composite",
                                           note="Rule 22e-4 classifies the fund's investments, so the fund (not the "
                                                "portfolio) keys the row; a position split across categories has one "
                                                "row per portion."),
    ("31", "Highly Liquid Investment Minimum"): _k(["HLIM Fund", "HLIM Effective From"], "Composite"),
    ("31", "Fund Liquidity Profile"): _k(["Profile Fund", "Profile Measurement Date"], "Composite"),
    ("31", "Liquidity Horizon Bucket"): _k(["Bucket Fund", "Bucket Measurement Date", "Liquidity Horizon Bucket"],
                                           "Composite"),
    # ------------------------------------------------------------------ 31 Derivatives Risk
    ("31", "Designated Reference Portfolio"): _k(["DRP Fund", "DRP Effective From"], "Composite"),
    ("31", "VaR Test Result"): _k(["VaR Test Fund", "VaR Test Date", "VaR Test Regime"], "Composite"),
    # ------------------------------------------------------------------ 31 Risk Programs & Limits
    ("31", "Risk Program Designation"): _k(["Program Fund", "Risk Program Type", "Program Effective From"],
                                           "Composite"),
    ("31", "Risk Limit"): _k(["Risk Limit ID"], "Natural"),
    ("31", "Risk Limit Utilization"): _k(["Utilized Risk Limit", "Utilized Counterparty Trading Limit",
                                          "Utilization Date", "Utilized Portfolio"], "Composite",
                                         note="Exactly one of the 31 limit and the 25 counterparty trading limit is "
                                              "set; the portfolio is '(none)' only for fund-, entity- or firm-level "
                                              "measurements."),
    ("31", "Risk Limit Exceedance"): _k(["Risk Limit Exceedance ID"], "Natural"),
    # 31 Product Risk Indicators family removed (UCITS and PRIIPs; CW-931).

    # ------------------------------------------------------------------ 32 Measurement Setup
    ("32", "Performance Calculation Policy"): _k(["Calculation Policy Code", "Calculation Policy Version"],
                                                 "Composite"),
    ("32", "Performance Measurement Profile"): _k(["Profiled Subject Type", "Profiled Portfolio",
                                                   "Profiled Share Class", "Profiled Account", "Profiled Composite",
                                                   "Profiled Model Portfolio", "Profile Effective From"], "Composite",
                                                  note="The subject is a set of typed references with exactly one "
                                                       "filled, discriminated by the Subject Type."),
    # ------------------------------------------------------------------ 32 Returns & Statistics
    ("32", "Performance Return"): _k(["Performance Return ID", "Return Version"], "Composite",
                                     note="RETURN- is stable across versions and stands for the subject, period and "
                                          "basis parts of the grain; a correction creates a new version."),
    ("32", "Return Component Detail"): _fold("One set of components per return version (portfolio, account and share "
                                             "class rows; blank on composite rows)."),
    ("32", "Hypothetical Performance Detail"): _fold("One per hypothetical (model or back-tested) return version."),
    ("32", "Benchmark Return"): _k(["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                    "Benchmark Return Type", "Benchmark Return Currency",
                                    "Benchmark Hedged Basis Indicator", "Benchmark Return Version"], "Composite",
                                   note="No ID attribute: references (Benchmark Return Record, Supersedes Benchmark "
                                        "Return) hold the full grain key."),
    ("32", "Ex-Post Risk Statistic"): _k(["Statistic Subject Type", "Statistic Portfolio", "Statistic Share Class",
                                          "Statistic Composite", "Statistic Benchmark", "Ex-Post Statistic Type",
                                          "Statistic Period Start Date", "Statistic Period End Date",
                                          "Observation Frequency", "Statistic Fee Basis", "Statistic Price Basis",
                                          "Statistic Currency", "Comparison Benchmark", "Statistic Version"],
                                         "Composite",
                                         note="Full grain: typed subject (one filled) x statistic x period x frequency "
                                              "x bases x currency x comparison benchmark ('(none)' when not relative) "
                                              "x version."),
    # ------------------------------------------------------------------ 32 GIPS & Composites
    ("32", "GIPS Firm"): _k(["GIPS Firm Code", "Firm Definition Effective From"], "Composite",
                            note="The firm definition is versioned by its effective date; GIPS Verification references "
                                 "the code."),
    ("32", "GIPS Firm Assets"): _child(["Firm Assets Period End Date"],
                                       "Repeats per period end within a GIPS firm definition."),
    ("32", "Composite Membership"): _k(["Membership Composite", "Member Portfolio", "Membership Start Date"],
                                       "Composite"),
    ("32", "Composite Period Statistic"): _k(["Statistic Composite", "Composite Period End Date",
                                              "Composite Period Type"], "Composite"),
    ("32", "Significant Cash Flow Event"): _k(["Flow Portfolio", "Flow Composite", "Significant Flow Date"],
                                              "Composite",
                                              note="Joined to the Composite Membership whose dates contain the flow "
                                                   "date; the membership start date is not an attribute."),
    ("32", "Carve-Out Allocation"): _k(["Carve-Out Portfolio", "Carve-Out Period Start Date"], "Composite"),
    ("32", "GIPS Verification"): _k(["GIPS Verification ID"], "Natural"),
    # ------------------------------------------------------------------ 32 Attribution
    ("32", "Attribution Model"): _k(["Attribution Model Code", "Attribution Model Version"], "Composite"),
    ("32", "Attribution Result"): _k(["Attribution Result ID", "Attribution Version"], "Composite",
                                     note="PAAN- is stable across versions and stands for the portfolio return, "
                                          "benchmark return and model parts of the grain; a rerun creates a new "
                                          "version."),
    ("32", "Attribution Segment Result"): _k(["Segment Attribution Result", "Attribution Segment Code"], "Composite",
                                             note="Model gap: the reference holds the PAAN- ID only, so segment rows "
                                                  "of two result versions collide; the result version is not an "
                                                  "attribute."),
    ("32", "Attribution Effect"): _k(["Effect Attribution Result", "Effect Segment Code", "Attribution Effect Type"],
                                     "Composite",
                                     note="Model gap: as for Attribution Segment Result, the result version is not an "
                                          "attribute."),
    ("32", "Contribution to Return"): _k(["Contribution Portfolio Return Record", "Contribution Instrument",
                                          "Contribution Classification Scheme", "Contribution Segment Code",
                                          "Contribution Calculation Basis"], "Composite",
                                         note="A row is for an instrument or for a segment of a classification scheme; "
                                              "the parts not used are '(none)'."),
    # ------------------------------------------------------------------ 32 Performance Governance
    ("32", "Performance Period Close"): _k(["Close Group", "Close Period End Date", "Close Period Type"],
                                           "Composite"),
    ("32", "Performance Restatement"): _k(["Restated Return", "Restatement Sequence"], "Composite",
                                          note="Restated Return holds the RETURN- ID; the versions are in Superseded "
                                               "and Restating Return Version."),
    # W2-W4 merge (2026-10-15): 32 objects restored or added
    ("32", "Client Performance Profile"): _k(["Client Profile Account", "Client Profile Group",
                                              "Client Profile Effective From"], "Composite",
                                             note="Exactly one of the account or group is populated."),
    ("32", "Household Performance Group"): _k(["Household Performance Group ID"], "Natural"),
    ("32", "Household Performance Group Member"): _k(["Member Performance Group", "Member Account",
                                                      "Member Inclusion Date"], "Composite"),
    ("32", "Personal Rate of Return"): _k(["Personal Rate of Return ID"], "Natural"),
    ("32", "Client Return Exception"): _k(["Exception Account", "Exception Date",
                                           "Client Return Exception Type"], "Composite"),

    # ------------------------------------------------------------------ 33 Rule Library
    ("33", "Regulatory Limit Provision"): _k(["Provision Code", "Provision Effective From"], "Composite",
                                             note="The code identifies one limit component of one provision; the "
                                                  "effective period completes the grain. References hold the code "
                                                  "only and resolve to the version in force."),
    ("33", "Rule Library"): _k(["Rule Library Code", "Rule Library Version"], "Composite"),
    ("33", "Rule Library Membership"): _k(["Membership Library", "Membership Library Version", "Member Rule",
                                           "Member Rule Version"], "Composite"),
    ("33", "Compliance Rule"): _k(["Compliance Rule ID", "Rule Version"], "Composite",
                                  note="CRULE- is stable across versions; references hold the ID with the version in a "
                                       "sibling attribute where the row is pinned to one."),
    ("33", "Rule Source Link"): _k(["Linked Rule", "Linked Rule Version", "Rule Source Type",
                                    "Source Investment Restriction", "Source Client Restriction",
                                    "Source Regulatory Provision"], "Composite",
                                   note="At most one source reference is filled, by Rule Source Type. Model gap: a "
                                        "Firm Policy source has no reference attribute, so a rule version can hold "
                                        "only one firm-policy row."),
    # ------------------------------------------------------------------ 33 Rule Coding & Assignment
    ("33", "Rule Assignment"): _k(["Assigned Rule", "Assigned Rule Version", "Assigned Rule Library",
                                   "Assigned Library Version", "Assigned Portfolio", "Assignment Effective From"],
                                  "Composite",
                                  note="Exactly one of a rule version and a library version is assigned; the other "
                                       "pair is '(none)'."),
    ("33", "Rule Instrument List"): _k(["Rule Instrument List Code", "Rule Instrument List Version"], "Composite"),
    ("33", "Rule Instrument List Member"): _k(["Member List", "Member Instrument", "Member Issuer",
                                               "Member Effective From"], "Composite",
                                              note="Exactly one of instrument and issuer is set. Member List holds the "
                                                   "list code without its version: members are dated by their own "
                                                   "effective period."),
    ("33", "Rule Coding Request"): _k(["Coding Request Reference"], "Natural",
                                      note="Internal reference (RCR yyyy/nnnn), no enterprise prefix."),
    ("33", "Restriction Coding Status"): _k(["Status Investment Restriction", "Status Client Restriction",
                                             "Coding Status Effective From"], "Composite",
                                            note="Exactly one of the 01 and 02 restriction references is set."),
    # ------------------------------------------------------------------ 33 Checks & Results
    ("33", "Compliance Check Run"): _k(["Compliance Check Run ID"], "Natural"),
    ("33", "Pre-Trade Check Subject"): _fold("A pre-trade run has exactly one subject (proposed trade, trade order, "
                                             "block order or deal)."),
    ("33", "Check Subject Member"): _k(["Member Check Run", "Checked Trade Order"], "Composite",
                                       note="One row per tested 25 order, including each member order of a block."),
    ("33", "Compliance Rule Result"): _k(["Result Check Run", "Result Portfolio", "Evaluated Rule",
                                          "Evaluated Rule Version", "Evaluated Issuer", "Evaluated Instrument",
                                          "Evaluated Group Key"], "Composite",
                                         note="Issuer, instrument and group are '(none)' for whole-portfolio rules, so "
                                              "two issuers over the same limit give two results."),
    # ------------------------------------------------------------------ 33 Alerts & Overrides
    ("33", "Compliance Alert"): _k(["Compliance Alert ID"], "Natural"),
    ("33", "Alert Disposition"): _k(["Disposed Alert", "Disposition Sequence"], "Composite"),
    ("33", "Pre-Trade Override Approval"): _k(["Override Alert", "Override Approval Sequence"], "Composite"),
    # ------------------------------------------------------------------ 33 Breaches & Remediation
    ("33", "Investment Breach"): _k(["Investment Breach ID"], "Natural",
                                    note="Business key is portfolio x rule x issuer, instrument or group x breach start "
                                         "date."),
    ("33", "Breached Source Restriction"): _k(["Source Breach", "Additional Breached Restriction",
                                               "Additional Breached Client Restriction"], "Composite",
                                              note="Exactly one of the 01 and 02 restriction references is set."),
    ("33", "Breach Remediation Action"): _k(["Remediated Breach", "Remediation Action Sequence"], "Composite"),
    ("33", "Breach Loss Calculation"): _k(["Calculated Breach", "Loss Calculation Version"], "Composite"),
    ("33", "Breach Review"): _k(["Reviewed Breach", "Breach Review Sequence"], "Composite"),
    # ------------------------------------------------------------------ 33 Waivers & Program Oversight
    ("33", "Guideline Waiver"): _k(["Guideline Waiver Reference"], "Natural",
                                   note="Internal reference (GW yyyy/nnnn); business key is rule x portfolio x scope x "
                                        "waiver period."),
    ("33", "Periodic Rule Review"): _k(["Reviewed Rule", "Reviewed Rule Library", "Rule Review Date"], "Composite",
                                       note="Exactly one of rule and library is set."),
    ("33", "Manual Compliance Check"): _k(["Checked Investment Restriction", "Checked Client Restriction",
                                           "Checked Portfolio", "Check Period Start Date"], "Composite",
                                          note="Exactly one of the 01 and 02 restriction references is set."),
}

REFS = {
    # ------------------------------------------------------------------ 31 Risk Models & Factors
    ("31", "Risk Model", "Model Vendor"): PARTY,
    ("31", "Risk Model", "Vendor Model Dataset"): DATASET,
    ("31", "Risk Model", "Model Inventory Reference"): MODEL_INVENTORY,
    ("31", "Risk Model", "Risk Model Owner"): EMPLOYEE,
    ("31", "Risk Factor", "Factor Risk Model"): RISK_MODEL,
    ("31", "Risk Factor", "Mapped Curve"): CURVE,
    ("31", "Risk Factor", "Factor Classification Scheme"): CLASS_SCHEME,
    ("31", "Risk Factor Return", "Return Risk Factor"): RISK_FACTOR,
    ("31", "Risk Factor Return", "Covariance Matrix Dataset"): DATASET,
    ("31", "Instrument Factor Loading", "Loading Risk Model"): RISK_MODEL,
    ("31", "Instrument Factor Loading", "Loaded Instrument"): INSTRUMENT,
    ("31", "Instrument Factor Loading", "Loading Risk Factor"): RISK_FACTOR,
    ("31", "Instrument Factor Loading", "Proxy Instrument"): INSTRUMENT,
    # ------------------------------------------------------------------ 31 Risk Measurement
    ("31", "Risk Calculation Run", "Run Risk Model"): RISK_MODEL,
    ("31", "Portfolio Risk Measure", "Measure Calculation Run"): RISK_RUN,
    ("31", "Portfolio Risk Measure", "Measured Portfolio"): PORTFOLIO,
    ("31", "Portfolio Risk Measure", "Measure Benchmark"): BENCHMARK,
    ("31", "Risk Decomposition", "Decomposed Measure"): RISK_MEASURE,
    ("31", "VaR Back-Test", "Back-Tested Portfolio"): PORTFOLIO,
    ("31", "VaR Back-Test", "Back-Test Risk Model"): RISK_MODEL,
    ("31", "VaR Back-Test", "Back-Tested VaR Measure"): RISK_MEASURE,
    # ------------------------------------------------------------------ 31 Exposures
    ("31", "Portfolio Exposure", "Exposure Portfolio"): PORTFOLIO,
    ("31", "Portfolio Exposure", "Exposure Calculation Run"): RISK_RUN,
    ("31", "Portfolio Exposure", "Exposure Benchmark"): BENCHMARK,
    ("31", "Counterparty Exposure", "Exposure Counterparty"): PARTY,
    ("31", "Counterparty Exposure", "Counterparty Exposure Portfolio"): PORTFOLIO,
    ("31", "Counterparty Exposure", "Exposure Trading Entity"): LEGAL_ENTITY,
    ("31", "Counterparty Exposure", "Netting Set Agreement"): ("26", "Trading Agreement"),
    ("31", "Counterparty Exposure", "Applicable Trading Limit"): CPTY_LIMIT,
    ("31", "Counterparty Exposure", "Counterparty Credit View"): ("23", "Internal Credit Assessment"),
    ("31", "Leverage & Exposure Measurement", "Measured Fund"): FUND,
    ("31", "Leverage & Exposure Measurement", "Net Assets Source NAV"): FUND_NAV,
    ("31", "Leverage & Exposure Measurement", "Measurement Calculation Run"): RISK_RUN,
    # ------------------------------------------------------------------ 31 Stress Testing
    ("31", "Stress Scenario Shock", "Shock Scenario"): STRESS_SCENARIO,
    ("31", "Stress Scenario Shock", "Shocked Risk Factor"): RISK_FACTOR,
    ("31", "Stress Scenario Shock", "Shocked Curve"): CURVE,
    ("31", "Stress Scenario Shock", "Shocked Index"): BENCHMARK,
    ("31", "Stress Test Result", "Result Scenario"): STRESS_SCENARIO,
    ("31", "Stress Test Result", "Stressed Portfolio"): PORTFOLIO,
    ("31", "Stress Test Result", "Stress Calculation Run"): RISK_RUN,
    ("31", "Stress Test Result", "Climate Metric Input"): ("34", "Portfolio Sustainability Metric"),
    ("31", "Liquidity Stress Detail", "Model Inventory Entry"): MODEL_INVENTORY,
    # ------------------------------------------------------------------ 31 Liquidity Risk
    ("31", "Liquidity Classification", "Classified Fund"): FUND,
    ("31", "Liquidity Classification", "Classified Instrument"): INSTRUMENT,
    ("31", "Liquidity Classification", "Liquidity Data Source Dataset"): DATASET,
    ("31", "Liquidity Classification", "Supporting Fair Value Determination"): FAIR_VALUE,
    ("31", "Liquidity Classification", "Model Inventory Entry"): MODEL_INVENTORY,
    ("31", "Highly Liquid Investment Minimum", "HLIM Fund"): FUND,
    ("31", "Fund Liquidity Profile", "Profile Fund"): FUND,
    ("31", "Fund Liquidity Profile", "Applied HLIM"): ("31", "Highly Liquid Investment Minimum"),
    ("31", "Fund Liquidity Profile", "Own ETF Market Statistic"): ETF_STAT,
    ("31", "Liquidity Horizon Bucket", "Bucket Fund"): FUND,
    ("31", "Liquidity Horizon Bucket", "Bucket Feeder Access Terms"): ("01", "Feeder Access Terms"),
    # ------------------------------------------------------------------ 31 Derivatives Risk
    ("31", "Designated Reference Portfolio", "DRP Fund"): FUND,
    ("31", "Designated Reference Portfolio", "Designated Reference Index"): BENCHMARK,
    ("31", "Designated Reference Portfolio", "Reference Securities Portfolio"): PORTFOLIO,
    ("31", "VaR Test Result", "VaR Test Fund"): FUND,
    ("31", "VaR Test Result", "Fund VaR Measure"): RISK_MEASURE,
    ("31", "VaR Test Result", "Applied Reference Portfolio"): ("31", "Designated Reference Portfolio"),
    ("31", "VaR Test Result", "Applied VaR Limit"): RISK_LIMIT,
    # ------------------------------------------------------------------ 31 Risk Programs & Limits
    ("31", "Risk Program Designation", "Program Fund"): FUND,
    ("31", "Risk Program Designation", "Administrator Appointment"): ("35", "Fund Officer Appointment"),
    ("31", "Risk Program Designation", "Program Risk Lead"): EMPLOYEE,
    ("31", "Risk Limit", "Limit Benchmark"): BENCHMARK,
    ("31", "Risk Limit", "Limit Stress Scenario"): STRESS_SCENARIO,
    ("31", "Risk Limit", "Limited Fund"): FUND,
    ("31", "Risk Limit", "Limited Portfolio"): PORTFOLIO,
    ("31", "Risk Limit", "Limited Strategy"): STRATEGY,
    ("31", "Risk Limit", "Limit Setting Entity"): LEGAL_ENTITY,
    ("31", "Risk Limit", "Limit Approved By"): EMPLOYEE,
    ("31", "Risk Limit Utilization", "Utilized Risk Limit"): RISK_LIMIT,
    ("31", "Risk Limit Utilization", "Utilized Counterparty Trading Limit"): CPTY_LIMIT,
    ("31", "Risk Limit Utilization", "Utilized Portfolio"): PORTFOLIO,
    ("31", "Risk Limit Exceedance", "Exceeded Risk Limit"): RISK_LIMIT,
    ("31", "Risk Limit Exceedance", "Exceeded Counterparty Trading Limit"): CPTY_LIMIT,
    ("31", "Risk Limit Exceedance", "Exceedance Portfolio"): PORTFOLIO,
    ("31", "Risk Limit Exceedance", "Triggering Utilization"): ("31", "Risk Limit Utilization"),
    ("31", "Risk Limit Exceedance", "Exceedance Owner"): EMPLOYEE,
    # 31 Product Risk Indicators references removed with the family (CW-931).

    # ------------------------------------------------------------------ 32 Measurement Setup
    ("32", "Performance Measurement Profile", "Profiled Portfolio"): PORTFOLIO,
    ("32", "Performance Measurement Profile", "Profiled Share Class"): SHARE_CLASS,
    ("32", "Performance Measurement Profile", "Profiled Account"): ACCOUNT,
    ("32", "Performance Measurement Profile", "Profiled Composite"): COMPOSITE,
    ("32", "Performance Measurement Profile", "Profiled Model Portfolio"): MODEL_PORTFOLIO,
    ("32", "Performance Measurement Profile", "Applied Calculation Policy"): ("32", "Performance Calculation Policy"),
    ("32", "Performance Measurement Profile", "Track Record Continuity Change"): CHANGE_INITIATIVE,
    ("32", "Performance Measurement Profile", "Profiled Managed Account Composite"):
        ("46", "Managed Account Composite"),
    # ------------------------------------------------------------------ 32 Returns & Statistics
    ("32", "Performance Return", "Return Portfolio"): PORTFOLIO,
    ("32", "Performance Return", "Return Share Class"): SHARE_CLASS,
    ("32", "Performance Return", "Return Account"): ACCOUNT,
    ("32", "Performance Return", "Return Composite"): COMPOSITE,
    ("32", "Performance Return", "Return Model Portfolio"): MODEL_PORTFOLIO,
    ("32", "Performance Return", "Return Managed Account Composite"): ("46", "Managed Account Composite"),
    ("32", "Return Component Detail", "Start NAV Record"): ("27", "Share Class NAV"),
    ("32", "Return Component Detail", "End NAV Record"): ("27", "Share Class NAV"),
    ("32", "Return Component Detail", "Start Market Price Statistic"): ETF_STAT,
    ("32", "Return Component Detail", "End Market Price Statistic"): ETF_STAT,
    ("32", "Return Component Detail", "Applied FX Rate Type"): ("09", "FX Rate Type"),
    ("32", "Hypothetical Performance Detail", "Hypothetical Compliance Review"): ("08", "Compliance Review"),
    ("32", "Benchmark Return", "Return Benchmark"): BENCHMARK,
    ("32", "Benchmark Return", "Supersedes Benchmark Return"): BMK_RETURN,
    ("32", "Benchmark Return", "Start Index Level"): INDEX_LEVEL,
    ("32", "Benchmark Return", "End Index Level"): INDEX_LEVEL,
    ("32", "Benchmark Return", "Index Data Dataset"): DATASET,
    ("32", "Ex-Post Risk Statistic", "Statistic Portfolio"): PORTFOLIO,
    ("32", "Ex-Post Risk Statistic", "Statistic Share Class"): SHARE_CLASS,
    ("32", "Ex-Post Risk Statistic", "Statistic Composite"): COMPOSITE,
    ("32", "Ex-Post Risk Statistic", "Statistic Benchmark"): BENCHMARK,
    ("32", "Ex-Post Risk Statistic", "Comparison Benchmark"): BENCHMARK,
    ("32", "Ex-Post Risk Statistic", "Risk-Free Rate Benchmark"): BENCHMARK,
    # ------------------------------------------------------------------ 32 GIPS & Composites
    # Firm Legal Entities is multi-valued: the model needs a bridge from GIPS Firm to the 09 legal entity.
    ("32", "GIPS Firm", "Firm Legal Entities"): LEGAL_ENTITY,
    ("32", "GIPS Firm", "GIPS Compliance Officer"): EMPLOYEE,
    ("32", "Composite Membership", "Membership Composite"): COMPOSITE,
    ("32", "Composite Membership", "Member Portfolio"): PORTFOLIO,
    # Multi-valued; each removal event also joins back to the membership by portfolio, composite and flow date.
    ("32", "Composite Membership", "Significant Cash Flow Removals"): ("32", "Significant Cash Flow Event"),
    ("32", "Composite Membership", "Membership Approver"): EMPLOYEE,
    ("32", "Composite Period Statistic", "Statistic Composite"): COMPOSITE,
    ("32", "Significant Cash Flow Event", "Flow Portfolio"): PORTFOLIO,
    ("32", "Significant Cash Flow Event", "Flow Composite"): COMPOSITE,
    ("32", "Significant Cash Flow Event", "Source Capital Activity"): ("18", "Portfolio Capital Activity"),
    ("32", "Carve-Out Allocation", "Carve-Out Portfolio"): PORTFOLIO,
    ("32", "Carve-Out Allocation", "Parent Portfolio"): PORTFOLIO,
    ("32", "GIPS Verification", "Verified GIPS Firm"): ("32", "GIPS Firm"),
    ("32", "GIPS Verification", "Verifier"): PARTY,
    ("32", "GIPS Verification", "Performance Examination Composites"): COMPOSITE,  # multi-valued: bridge
    # ------------------------------------------------------------------ 32 Attribution
    ("32", "Attribution Model", "Segment Classification Scheme"): CLASS_SCHEME,
    ("32", "Attribution Model", "Factor Risk Model"): RISK_MODEL,
    ("32", "Attribution Model", "Model Inventory Reference"): MODEL_INVENTORY,
    ("32", "Attribution Result", "Portfolio Return Record"): PERF_RETURN,
    ("32", "Attribution Result", "Benchmark Return Record"): BMK_RETURN,
    ("32", "Attribution Result", "Applied Attribution Model"): ("32", "Attribution Model"),
    ("32", "Attribution Result", "Reference Target Allocation"): ("24", "Target Allocation Set"),
    ("32", "Attribution Segment Result", "Segment Attribution Result"): ATTRIB_RESULT,
    ("32", "Attribution Effect", "Effect Attribution Result"): ATTRIB_RESULT,
    ("32", "Contribution to Return", "Contribution Portfolio Return Record"): PERF_RETURN,
    ("32", "Contribution to Return", "Contribution Instrument"): INSTRUMENT,
    ("32", "Contribution to Return", "Contribution Classification Scheme"): CLASS_SCHEME,
    # ------------------------------------------------------------------ 32 Performance Governance
    ("32", "Performance Period Close", "Close Signed Off By"): EMPLOYEE,
    ("32", "Performance Restatement", "Restated Return"): PERF_RETURN,
    ("32", "Performance Restatement", "Related NAV Error Case"): NAV_ERROR,
    ("32", "Performance Restatement", "Restatement Approver"): EMPLOYEE,
    ("32", "Client Performance Profile", "Client Profile Account"): ACCOUNT,
    ("32", "Client Performance Profile", "Client Profile Group"): ("32", "Household Performance Group"),
    ("32", "Client Performance Profile", "Client Comparison Benchmark"): BENCHMARK,
    ("32", "Client Performance Profile", "Client Applied Calculation Policy"): ("32", "Performance Calculation Policy"),
    ("32", "Household Performance Group", "Group Household"): PARTY,
    ("32", "Household Performance Group Member", "Member Performance Group"): ("32", "Household Performance Group"),
    ("32", "Household Performance Group Member", "Member Account"): ACCOUNT,
    ("32", "Personal Rate of Return", "Personal Return Account"): ACCOUNT,
    ("32", "Personal Rate of Return", "Personal Return Group"): ("32", "Household Performance Group"),
    ("32", "Personal Rate of Return", "Supersedes Personal Return"): ("32", "Personal Rate of Return"),
    ("32", "Client Return Exception", "Exception Account"): ACCOUNT,

    # ------------------------------------------------------------------ 33 Rule Library
    ("33", "Rule Library", "Library Owner"): EMPLOYEE,
    ("33", "Rule Library Membership", "Membership Library"): RULE_LIBRARY,
    ("33", "Rule Library Membership", "Member Rule"): RULE,
    ("33", "Compliance Rule", "Rule Instrument Lists Read"): RULE_LIST,  # multi-valued: bridge
    ("33", "Compliance Rule", "Originating Coding Request"): CODING_REQUEST,
    ("33", "Compliance Rule", "Version Approved By"): EMPLOYEE,
    ("33", "Rule Source Link", "Linked Rule"): RULE,
    ("33", "Rule Source Link", "Source Investment Restriction"): RESTRICTION,
    ("33", "Rule Source Link", "Source Client Restriction"): CLIENT_RESTRICTION,
    ("33", "Rule Source Link", "Source Regulatory Provision"): ("33", "Regulatory Limit Provision"),
    # ------------------------------------------------------------------ 33 Rule Coding & Assignment
    ("33", "Rule Assignment", "Assigned Rule"): RULE,
    ("33", "Rule Assignment", "Assigned Rule Library"): RULE_LIBRARY,
    ("33", "Rule Assignment", "Assigned Portfolio"): PORTFOLIO,
    ("33", "Rule Instrument List", "Source Sustainability Exclusion List"): ("34", "Sustainability Exclusion List"),
    ("33", "Rule Instrument List", "Restricted List Source"): ("38", "Firm Restricted List"),
    ("33", "Rule Instrument List", "Source Client Restriction"): CLIENT_RESTRICTION,
    ("33", "Rule Instrument List", "List Source Dataset"): DATASET,
    ("33", "Rule Instrument List Member", "Member List"): RULE_LIST,
    ("33", "Rule Instrument List Member", "Member Instrument"): INSTRUMENT,
    ("33", "Rule Instrument List Member", "Member Issuer"): PARTY,
    ("33", "Rule Coding Request", "Triggering Investment Restriction"): RESTRICTION,
    ("33", "Rule Coding Request", "Triggering Client Restriction"): CLIENT_RESTRICTION,
    ("33", "Rule Coding Request", "Triggering Product Change"): CHANGE_INITIATIVE,
    ("33", "Rule Coding Request", "Coded By"): EMPLOYEE,
    ("33", "Rule Coding Request", "Coding Approved By"): EMPLOYEE,
    ("33", "Restriction Coding Status", "Status Investment Restriction"): RESTRICTION,
    ("33", "Restriction Coding Status", "Status Client Restriction"): CLIENT_RESTRICTION,
    # ------------------------------------------------------------------ 33 Checks & Results
    ("33", "Pre-Trade Check Subject", "Tested Proposed Trade"): ("24", "Proposed Trade"),
    ("33", "Pre-Trade Check Subject", "Tested Trade Order"): TRADE_ORDER,
    ("33", "Pre-Trade Check Subject", "Tested Block Order"): ("25", "Block Order"),
    ("33", "Check Subject Member", "Member Check Run"): CHECK_RUN,
    ("33", "Check Subject Member", "Checked Trade Order"): TRADE_ORDER,
    ("33", "Check Subject Member", "Releasing Override"): ("33", "Pre-Trade Override Approval"),
    ("33", "Compliance Rule Result", "Result Check Run"): CHECK_RUN,
    ("33", "Compliance Rule Result", "Result Portfolio"): PORTFOLIO,
    ("33", "Compliance Rule Result", "Evaluated Rule"): RULE,
    ("33", "Compliance Rule Result", "Evaluated Issuer"): PARTY,
    ("33", "Compliance Rule Result", "Evaluated Instrument"): INSTRUMENT,
    ("33", "Compliance Rule Result", "Applied Guideline Waiver"): ("33", "Guideline Waiver"),
    # ------------------------------------------------------------------ 33 Alerts & Overrides
    ("33", "Compliance Alert", "Source Rule Result"): ("33", "Compliance Rule Result"),
    ("33", "Compliance Alert", "Alert Assigned To"): EMPLOYEE,
    ("33", "Alert Disposition", "Disposed Alert"): ALERT,
    ("33", "Alert Disposition", "Disposed By"): EMPLOYEE,
    ("33", "Alert Disposition", "Disposition Reviewed By"): EMPLOYEE,
    ("33", "Alert Disposition", "Related Data Quality Issue"): ("21", "Data Quality Issue"),
    ("33", "Pre-Trade Override Approval", "Override Alert"): ALERT,
    ("33", "Pre-Trade Override Approval", "Override Requested By"): EMPLOYEE,
    ("33", "Pre-Trade Override Approval", "Override Approver"): EMPLOYEE,
    # ------------------------------------------------------------------ 33 Breaches & Remediation
    ("33", "Investment Breach", "Breached Portfolio"): PORTFOLIO,
    ("33", "Investment Breach", "Breached Rule"): RULE,
    ("33", "Investment Breach", "Breached Issuer"): PARTY,
    ("33", "Investment Breach", "Breached Instrument"): INSTRUMENT,
    ("33", "Investment Breach", "Breached Restriction"): RESTRICTION,
    ("33", "Investment Breach", "Breached Client Restriction"): CLIENT_RESTRICTION,
    ("33", "Investment Breach", "Originating Alert"): ALERT,
    ("33", "Investment Breach", "Originating Manual Check"): ("33", "Manual Compliance Check"),
    ("33", "Investment Breach", "Related Trade Error"): ("25", "Trade Error"),
    ("33", "Investment Breach", "Related NAV Error Case"): NAV_ERROR,
    ("33", "Breached Source Restriction", "Source Breach"): BREACH,
    ("33", "Breached Source Restriction", "Additional Breached Restriction"): RESTRICTION,
    ("33", "Breached Source Restriction", "Additional Breached Client Restriction"): CLIENT_RESTRICTION,
    ("33", "Breach Remediation Action", "Remediated Breach"): BREACH,
    ("33", "Breach Remediation Action", "Remediation Action Owner"): EMPLOYEE,
    ("33", "Breach Remediation Action", "Implementing Trade Order"): TRADE_ORDER,
    ("33", "Breach Loss Calculation", "Calculated Breach"): BREACH,
    ("33", "Breach Loss Calculation", "Compensating Entity"): LEGAL_ENTITY,
    ("33", "Breach Loss Calculation", "Loss Calculation Approved By"): EMPLOYEE,
    ("33", "Breach Review", "Reviewed Breach"): BREACH,
    ("33", "Breach Review", "Resulting Reportable Fund Event"): ("35", "Reportable Fund Event"),
    ("33", "Breach Review", "CCO Sign-Off By"): EMPLOYEE,
    # ------------------------------------------------------------------ 33 Waivers & Program Oversight
    ("33", "Guideline Waiver", "Waived Rule"): RULE,
    ("33", "Guideline Waiver", "Waived Portfolio"): PORTFOLIO,
    ("33", "Guideline Waiver", "Waiver Scope Issuer"): PARTY,
    ("33", "Guideline Waiver", "Client Approver"): PARTY,
    ("33", "Guideline Waiver", "Internal Approver"): EMPLOYEE,
    ("33", "Periodic Rule Review", "Reviewed Rule"): RULE,
    ("33", "Periodic Rule Review", "Reviewed Rule Library"): RULE_LIBRARY,
    ("33", "Periodic Rule Review", "Rule Reviewer"): EMPLOYEE,
    ("33", "Periodic Rule Review", "Resulting Coding Request"): CODING_REQUEST,
    ("33", "Manual Compliance Check", "Checked Investment Restriction"): RESTRICTION,
    ("33", "Manual Compliance Check", "Checked Client Restriction"): CLIENT_RESTRICTION,
    ("33", "Manual Compliance Check", "Checked Portfolio"): PORTFOLIO,
    ("33", "Manual Compliance Check", "Attested By"): EMPLOYEE,
}

# Reference left out of REFS (no single object masters the target):
#   ("33", "Compliance Rule Result", "Source Risk Measurement")
#       <Reference (Leverage & Exposure Measurement / Counterparty Exposure / Portfolio Risk Measure, 31)>
#       Polymorphic across three 31 objects; the rule version's Risk Measure Read or Exposure Method Read says which one
#       is meant. Model it as three typed links or a polymorphic lineage link.
# Attributes marked ->NN in the catalog that are Derived copies, not Reference types, are not in REFS: for example
# 31 Net Assets Used, Profile Net Assets, Realized Daily P&L, Counterparty Exposure Amount, Recommended Holding Period
# Used; 32 Beginning / Ending Portfolio Value, Net External Cash Flow, Fees Deducted Amount, Model Fee Rate, Blend
# Components Applied, Significant Flow Amount, Applied Significant Flow Threshold; 33 Board Approval Date.
