"""Key and link registry, Wave E7 group 34_35: Data Domains 34 Stewardship & Sustainable Investing and 35 Fund Governance &
Regulatory Reporting. See CONTRACT.md section 1.

Same conventions as keys.py. "Exactly one of ... is populated" means the grain names alternatives (for example a 17
investee meeting or a 13 own-fund proxy campaign); the key carries every alternative column and the empty ones hold a
default value so the key stays complete. "Model gap" means the grain names something no attribute can carry in a key.
A reference to a 34 or 35 object with a composite key (agenda item, ballot, voting authority) holds that object's
composite key value, as the 34 and 35 enrichment OWNERSHIP_OVERRIDES describe.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
PRODUCT = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
PORTFOLIO = ("18", "Portfolio")
ACCOUNT = ("15", "Account")
INSTRUMENT = ("17", "Instrument")
DATASET = ("14", "Dataset")
CA_EVENT = ("17", "Corporate Action Event")
PROXY_PROPOSAL = ("13", "Proxy Proposal")
MODEL_ENTRY = ("37", "Model Inventory Entry")
UNIT = ("09", "Unit of Measure")
# 34
VOTING_POLICY = ("34", "Voting Policy")
AGENDA_ITEM = ("34", "Investee Meeting Agenda Item")
ENGAGEMENT = ("34", "Engagement")
INDICATOR = ("34", "Sustainability Indicator Definition")
OBSERVATION = ("34", "Issuer Sustainability Observation")
PROXY_VOTING_REPORT = ("34", "Proxy Voting Report")
# 35
GOVERNING_BODY = ("35", "Fund Governing Body")
BOARD_MEETING = ("35", "Board Meeting")
RESOLUTION = ("35", "Board Resolution")
ADVISORY_AGREEMENT = ("35", "Fund Advisory Agreement")
RENEWAL = ("35", "Advisory Contract Renewal")
FILING = ("35", "Fund Regulatory Filing")

KEYS = {
    # ------------------------------------------------------------------ 34 Stewardship Policies
    ("34", "Voting Policy"): _k(["Voting Policy ID"], "Natural",
                                note="The VPOL- identifier is per policy version, so the version needs no column."),
    ("34", "Voting Guideline"): _k(["Guideline Policy", "Guideline Code"], "Composite"),
    ("34", "Voting Authority Arrangement"): _k(["Authority Portfolio", "Authority Account", "Authority Effective From"],
                                               "Composite",
                                               note="Scope is a portfolio or a client account: Authority Portfolio is "
                                                    "blank for an account-only arrangement, so both columns are in the key."),
    # ------------------------------------------------------------------ 34 Investee Meetings & Votes
    ("34", "Investee Meeting Agenda Item"): _k(["Agenda Meeting", "Agenda Item Number"], "Composite",
                                               note="The meeting is the 17 Corporate Action Event (CD-226); 34 holds "
                                                    "no meeting object."),
    ("34", "Proxy Advisor Recommendation"): _k(["Recommended Agenda Item", "Proxy Advisor", "Advisor Policy"],
                                               "Composite"),
    ("34", "Ballot"): _k(["Ballot Meeting", "Own Fund Proxy Campaign", "Ballot Safekeeping Account"], "Composite",
                         note="Exactly one of Ballot Meeting (17 investee meeting) and Own Fund Proxy Campaign (13, "
                              "own-fund meeting) is populated; Ballot Control Number is the agent's number, not the "
                              "grain."),
    ("34", "Vote Rationale"): _k(["Rationale Agenda Item", "Rationale Fund Proxy Proposal", "Rationale Voting Policy"],
                                 "Composite",
                                 note="Exactly one of the agenda item and the 13 proxy proposal is populated; one "
                                      "rationale is shared by every ballot voted on the item under the policy."),
    ("34", "Vote Instruction"): _k(["Vote Instruction ID"], "Natural"),
    ("34", "Lending Recall Decision"): _k(["Recall Meeting", "Recall Securities Loan"], "Composite"),
    # ------------------------------------------------------------------ 34 Engagement
    ("34", "Engagement"): _k(["Engagement ID"], "Natural"),
    ("34", "Engagement Objective"): _k(["Objective Engagement", "Objective Sequence"], "Composite"),
    ("34", "Engagement Interaction"): _k(["Interaction ID"], "Natural",
                                         note="The interaction ID is engagement ID plus interaction number."),
    ("34", "Escalation Action"): _k(["Escalated Engagement", "Escalation Sequence"], "Composite"),
    ("34", "Collaborative Initiative Membership"): _k(["Membership Initiative", "Member Legal Entity",
                                                      "Membership Effective From"], "Composite",
                                                     note="The initiative is a 02 party (role Collaborative "
                                                          "Engagement Initiative)."),
    # ------------------------------------------------------------------ 34 ESG Data & Assessments
    ("34", "Sustainability Indicator Definition"): _k(["Indicator Code", "Indicator Version"], "Composite",
                                                     note="Indicator references (Observed, Metric, Target, Input "
                                                          "Indicator) hold the code and version."),
    ("34", "Issuer Sustainability Observation"): _k(["Observation Key"], "Surrogate",
                                                   note="The taxonomy carries a system-assigned surrogate; the grain "
                                                        "(issuer or instrument x indicator x period end x dataset x "
                                                        "as-of date) is the alternate key."),
    ("34", "ESG Rating Observation"): _k(["Rated Issuer", "Rating Source Dataset", "ESG Rating Type", "Rating As-Of Date"],
                                         "Composite"),
    ("34", "Firm ESG Assessment"): _k(["ESG Assessment ID"], "Natural",
                                      note="The ESGA- identifier is per assessment version."),
    # Sustainable Investment Determination removed (SFDR; CW-934).
    ("34", "Sustainability Exclusion List"): _k(["Exclusion List Code", "Exclusion List Version"], "Composite"),
    ("34", "Exclusion List Member"): _k(["Member List", "Excluded Issuer", "Excluded Instrument", "Member Effective From"],
                                        "Composite",
                                        note="Member List holds the list code only (members are effective-dated across "
                                             "list versions); Excluded Instrument is blank for an issuer-level member."),
    # ------------------------------------------------------------------ 34 Portfolio Sustainability Metrics & Product Outcomes
    # PAI Calculation removed (SFDR principal adverse impact statement; CW-934).
    ("34", "Portfolio Sustainability Metric"): _k(["Metric Portfolio", "Metric Product", "Metric Legal Entity",
                                                  "Metric Period End Date", "Metric Indicator", "Emission Scopes Included",
                                                  "Metric Measurement Basis"], "Composite",
                                                 note="Exactly one of portfolio, product and legal entity is the scope; "
                                                      "31 Climate Metric Input references the metric by this key."),
    # Product Sustainability Outcome removed (SFDR periodic and UK SDR product outcomes; CW-934).
    # ------------------------------------------------------------------ 34 Financed Emissions & Climate Targets
    ("34", "Financed Emissions Holding Detail"): _child(["Detail Holding"],
                                                       "One row per 18 portfolio holding within a financed emissions "
                                                       "metric."),
    ("34", "Climate Target"): _k(["Climate Target Code"], "Natural"),
    # ------------------------------------------------------------------ 34 Stewardship Disclosure & Reporting
    ("34", "Proxy Voting Report"): _k(["Proxy Voting Report ID"], "Natural",
                                      note="Firm-defined ID: period end year, report type and reporting person."),
    ("34", "Stewardship Report"): _k(["Stewardship Report ID"], "Natural",
                                     note="Firm-defined ID: period end year, framework and reporting entity."),
    # Signatory Status removed (UK Stewardship Code signatory status; CW-934).
    ("34", "Reported Engagement"): _child(["Reported Engagement Case"], "One row per engagement featured in the report."),

    # ------------------------------------------------------------------ 35 Governing Bodies
    ("35", "Fund Governing Body"): _k(["Governing Body ID"], "Natural"),
    ("35", "Governed Fund Coverage"): _k(["Coverage Governing Body", "Governed Product", "Coverage Effective From"],
                                         "Composite"),
    ("35", "Governing Body Membership"): _k(["Membership Governing Body", "External Member Party",
                                            "Interested Member Employee", "Member Role", "Membership Effective From"],
                                           "Composite",
                                           note="Exactly one of External Member Party (02) and Interested Member "
                                                "Employee (20) is populated."),
    ("35", "Fund Officer Appointment"): _k(["Officer Registrant", "Officer Entity", "Fund Officer Role", "Appointed Officer",
                                           "External Officer Party", "Officer Effective From"], "Composite",
                                          note="Exactly one of registrant and entity, and exactly one of employee and "
                                               "external party, is populated."),
    ("35", "Governance Standards Profile"): _child(["Standards Assessment Date"],
                                                   "One row per standards assessment of the body."),
    # ------------------------------------------------------------------ 35 Board Meetings & Reports
    ("35", "Board Meeting"): _k(["Board Meeting ID"], "Natural",
                                note="Includes actions by written consent, dated on the consent's effective date."),
    ("35", "Board Agenda Item"): _k(["Agenda Meeting", "Agenda Item Number"], "Composite"),
    ("35", "Board Report Received"): _k(["Board Report Received Key"], "Surrogate",
                                        note="Model gap: the grain names the reported funds, a multi-valued reference "
                                             "that cannot sit in a key; the alternate key is meeting x report type x "
                                             "period x the fund set or 31 risk program."),
    ("35", "Board Report Source Item"): _child(["Related Investment Breach", "Related Risk Limit Exceedance",
                                                "Related Fair Value Determination", "Source Record Description"],
                                               "Exactly one source column is populated (Source Record Description "
                                               "where no typed reference applies)."),
    ("35", "Board Self-Assessment"): _k(["Assessed Governing Body", "Assessment Year"], "Composite"),
    # ------------------------------------------------------------------ 35 Board Approvals & Resolutions
    ("35", "Board Resolution"): _k(["Board Resolution ID"], "Natural"),
    ("35", "Resolution Subject Link"): _k(["Resolution Subject Link Key"], "Surrogate",
                                          note="The subject is one of 15 typed references or a description, chosen by "
                                               "Resolution Subject Type; the alternate key is resolution x subject "
                                               "type x the populated subject column, too wide to carry as the key."),
    ("35", "Resolution Vote Count"): _fold(),
    ("35", "Fund Fidelity Bond"): _k(["Fidelity Bond Policy Number", "Coverage Period Start"], "Composite",
                                     note="The insurer's policy number is renewed across coverage periods."),
    # ------------------------------------------------------------------ 35 Advisory Contract Oversight
    ("35", "Fund Advisory Agreement"): _k(["Advisory Agreement ID"], "Natural"),
    ("35", "Agreement Fund Schedule"): _k(["Schedule Agreement", "Covered Fund", "Schedule Renewal"], "Composite",
                                          note="Schedule Renewal is blank for the initial approval; use an 'initial' "
                                               "default value so the key stays complete."),
    ("35", "Advisory Contract Renewal"): _k(["Renewal ID"], "Natural",
                                            note="The RENEW- identifier is agreement x renewal year."),
    ("35", "Renewal Material Item"): _k(["Material Renewal", "Renewal Material Type", "Source Fee Benchmark Study",
                                         "Source Peer Universe", "Source Profitability Record",
                                         "Source Performance Return", "Source Benchmark Return"], "Composite",
                                        note="Exactly one source record reference is populated, as the material type "
                                             "says."),
    ("35", "Board 15(c) Finding"): _k(["Finding Renewal", "15(c) Factor"], "Composite"),
    # ------------------------------------------------------------------ 35 Regulatory Filings & Disclosures
    ("35", "Filing Obligation"): _k(["Obligated Product", "Obligated Entity", "Obligation Form Type",
                                     "Obligation Filing State", "Obligation Effective From"], "Composite",
                                    note="Exactly one of product and entity is the filer; the filing state is "
                                         "'(none)' except on state notice filings, one obligation per state (CW-935)."),
    ("35", "Fund Regulatory Filing"): _k(["Regulatory Filing ID"], "Natural",
                                         note="REGF- per submission; the grain (filer x form x filing state x period or "
                                              "event date x event reference x submission sequence) is the alternate "
                                              "key."),
    ("35", "Filing Document"): _child(["Filed Shareholder Communication", "Filed Product Document",
                                       "Filed Proxy Voting Report"],
                                      "Exactly one filed document reference is populated; the share class qualifies "
                                      "it."),
    ("35", "Filing Certification"): _child(["Certification Type", "Certifying Officer", "Certifying External Party"],
                                           "Exactly one of the employee and the external party signs."),
    ("35", "Filing Data Source"): _k(["Source Filing", "Filing Data Source Type", "Source Record Key"], "Composite"),
    ("35", "Fund Public Disclosure"): _k(["Disclosing Product", "Disclosing Share Class", "Public Disclosure Type",
                                          "Disclosure As-Of Date"], "Composite",
                                         note="Disclosing Share Class is blank for a fund-level disclosure; use an "
                                              "'all share classes' default value."),
    # ------------------------------------------------------------------ 35 Fund Regulatory Status
    ("35", "RIC Qualification Determination"): _k(["Determined Fund", "Determination Tax Year"], "Composite",
                                                  note="Determined Fund must equal the fund of the 27 tax year record."),
    ("35", "Reportable Fund Event"): _k(["Event Fund", "Reportable Event Type", "Event Date"], "Composite"),
    ("35", "Exemptive Relief Reliance"): _k(["Relying Fund", "Exemptive Relief Type", "Order or Rule Citation",
                                             "Reliance Effective From"], "Composite",
                                            note="The relief is identified by its type and its order or rule citation."),
}

REFS = {
    # ------------------------------------------------------------------ 34 Stewardship Policies
    ("34", "Voting Policy", "Benchmark Proxy Advisor"): PARTY,
    ("34", "Voting Policy", "Policy Client"): PARTY,
    ("34", "Voting Policy", "Policy Approved By"): EMPLOYEE,
    ("34", "Voting Policy", "Voting Choice Offered Funds"): PRODUCT,  # W1b addition (CW-934); elections are 13's
    ("34", "Voting Guideline", "Guideline Policy"): VOTING_POLICY,
    ("34", "Voting Guideline", "Guideline Market"): ("09", "Geographic Unit"),
    ("34", "Voting Authority Arrangement", "Authority Portfolio"): PORTFOLIO,
    ("34", "Voting Authority Arrangement", "Authority Account"): ACCOUNT,
    ("34", "Voting Authority Arrangement", "Authority Holder Party"): PARTY,
    ("34", "Voting Authority Arrangement", "Trustee Legal Entity"): LEGAL_ENTITY,
    ("34", "Voting Authority Arrangement", "Exercising Legal Entity"): LEGAL_ENTITY,
    ("34", "Voting Authority Arrangement", "Applied Voting Policy"): VOTING_POLICY,
    ("34", "Voting Authority Arrangement", "Voting Platform Provider"): PARTY,
    # ------------------------------------------------------------------ 34 Investee Meetings & Votes
    ("34", "Investee Meeting Agenda Item", "Agenda Meeting"): CA_EVENT,
    ("34", "Investee Meeting Agenda Item", "Proponent Party"): PARTY,
    ("34", "Proxy Advisor Recommendation", "Recommended Agenda Item"): AGENDA_ITEM,
    ("34", "Proxy Advisor Recommendation", "Proxy Advisor"): PARTY,
    ("34", "Proxy Advisor Recommendation", "Recommendation Source Dataset"): DATASET,
    ("34", "Ballot", "Ballot Meeting"): CA_EVENT,
    ("34", "Ballot", "Own Fund Proxy Campaign"): ("13", "Proxy Campaign"),
    ("34", "Ballot", "Ballot Safekeeping Account"): ("28", "Safekeeping Account"),
    ("34", "Ballot", "Governing Voting Authority"): ("34", "Voting Authority Arrangement"),
    ("34", "Ballot", "Ballot Entitlement"): ("28", "Corporate Action Entitlement"),
    ("34", "Vote Rationale", "Rationale Agenda Item"): AGENDA_ITEM,
    ("34", "Vote Rationale", "Rationale Fund Proxy Proposal"): PROXY_PROPOSAL,
    ("34", "Vote Rationale", "Rationale Voting Policy"): VOTING_POLICY,
    ("34", "Vote Rationale", "Linked Engagement"): ENGAGEMENT,
    ("34", "Vote Rationale", "Override Approved By"): EMPLOYEE,
    ("34", "Vote Instruction", "Voted Ballot"): ("34", "Ballot"),
    ("34", "Vote Instruction", "Voted Agenda Item"): AGENDA_ITEM,
    ("34", "Vote Instruction", "Voted Fund Proxy Proposal"): PROXY_PROPOSAL,
    ("34", "Vote Instruction", "Applied Vote Rationale"): ("34", "Vote Rationale"),
    ("34", "Vote Instruction", "Vote Decision Maker"): EMPLOYEE,
    ("34", "Lending Recall Decision", "Recall Meeting"): CA_EVENT,
    ("34", "Lending Recall Decision", "Recall Securities Loan"): ("28", "Securities Loan"),
    ("34", "Lending Recall Decision", "Recall Decision Maker"): EMPLOYEE,
    # ------------------------------------------------------------------ 34 Engagement
    ("34", "Engagement", "Engaged Party"): PARTY,
    ("34", "Engagement", "Engagement Lead"): EMPLOYEE,
    ("34", "Engagement", "Collaborative Initiative"): PARTY,
    ("34", "Engagement Objective", "Objective Engagement"): ENGAGEMENT,
    ("34", "Engagement Interaction", "Interaction Engagement"): ENGAGEMENT,
    ("34", "Engagement Interaction", "Interaction Issuer Meeting"): ("23", "Issuer Meeting"),
    ("34", "Engagement Interaction", "Interaction Employee"): EMPLOYEE,
    ("34", "Engagement Interaction", "Issuer Contact"): PARTY,
    ("34", "Engagement Interaction", "Discussed Objective"): ("34", "Engagement Objective"),
    ("34", "Escalation Action", "Escalated Engagement"): ENGAGEMENT,
    ("34", "Escalation Action", "Escalation Approver"): EMPLOYEE,
    ("34", "Escalation Action", "Escalation Agenda Item"): AGENDA_ITEM,
    ("34", "Escalation Action", "Resulting Investment Decision"): ("24", "Investment Decision"),
    ("34", "Collaborative Initiative Membership", "Membership Initiative"): PARTY,
    ("34", "Collaborative Initiative Membership", "Member Legal Entity"): LEGAL_ENTITY,
    # ------------------------------------------------------------------ 34 ESG Data & Assessments
    ("34", "Sustainability Indicator Definition", "Indicator Unit"): UNIT,
    ("34", "Sustainability Indicator Definition", "Input Indicator"): INDICATOR,
    ("34", "Issuer Sustainability Observation", "Observed Issuer"): PARTY,
    ("34", "Issuer Sustainability Observation", "Observed Instrument"): INSTRUMENT,
    ("34", "Issuer Sustainability Observation", "Observed Indicator"): INDICATOR,
    ("34", "Issuer Sustainability Observation", "Observation Source Dataset"): DATASET,
    ("34", "ESG Rating Observation", "Rated Issuer"): PARTY,
    ("34", "ESG Rating Observation", "Rating Source Dataset"): DATASET,
    ("34", "Firm ESG Assessment", "Assessed Issuer"): PARTY,
    ("34", "Firm ESG Assessment", "Assessment Strategy"): ("01", "Investment Strategy"),
    ("34", "Firm ESG Assessment", "Assessing Analyst"): EMPLOYEE,
    ("34", "Firm ESG Assessment", "Assessment Methodology Name"): MODEL_ENTRY,
    ("34", "Sustainability Exclusion List", "List Approved By"): EMPLOYEE,
    ("34", "Exclusion List Member", "Member List"): ("34", "Sustainability Exclusion List"),
    ("34", "Exclusion List Member", "Excluded Issuer"): PARTY,
    ("34", "Exclusion List Member", "Excluded Instrument"): INSTRUMENT,
    ("34", "Exclusion List Member", "Supporting Observation"): OBSERVATION,
    # ------------------------------------------------------------------ 34 Portfolio Sustainability Metrics & Product Outcomes
    # References of PAI Calculation, Sustainable Investment Determination, Product Sustainability Outcome and Signatory
    # Status removed with the objects, as is Portfolio Sustainability Metric.Reporting PAI Calculation (CW-934).
    ("34", "Portfolio Sustainability Metric", "Metric Portfolio"): PORTFOLIO,
    ("34", "Portfolio Sustainability Metric", "Metric Product"): PRODUCT,
    ("34", "Portfolio Sustainability Metric", "Metric Legal Entity"): LEGAL_ENTITY,
    ("34", "Portfolio Sustainability Metric", "Metric Indicator"): INDICATOR,
    ("34", "Portfolio Sustainability Metric", "Metric Unit"): UNIT,
    ("34", "Portfolio Sustainability Metric", "Metric Model Name"): MODEL_ENTRY,
    # ------------------------------------------------------------------ 34 Financed Emissions & Climate Targets
    ("34", "Financed Emissions Holding Detail", "Detail Holding"): ("18", "Portfolio Holding"),
    ("34", "Financed Emissions Holding Detail", "Detail Issuer"): PARTY,
    ("34", "Financed Emissions Holding Detail", "Source Observation"): OBSERVATION,
    ("34", "Climate Target", "Target Legal Entity"): LEGAL_ENTITY,
    ("34", "Climate Target", "Target Portfolio"): PORTFOLIO,
    ("34", "Climate Target", "Target Indicator"): INDICATOR,
    ("34", "Climate Target", "Latest Progress Metric"): ("34", "Portfolio Sustainability Metric"),
    # ------------------------------------------------------------------ 34 Stewardship Disclosure & Reporting
    ("34", "Proxy Voting Report", "Reporting Fund Series"): PRODUCT,
    ("34", "Proxy Voting Report", "Reporting Manager Entity"): LEGAL_ENTITY,
    ("34", "Proxy Voting Report", "Reporting Client Account"): ACCOUNT,
    ("34", "Proxy Voting Report", "Voting Report Approved By"): EMPLOYEE,
    ("34", "Stewardship Report", "Stewardship Reporting Entity"): LEGAL_ENTITY,
    ("34", "Stewardship Report", "Stewardship Report Product"): PRODUCT,
    ("34", "Stewardship Report", "Stewardship Report Approved By"): EMPLOYEE,
    ("34", "Reported Engagement", "Reported Engagement Case"): ENGAGEMENT,

    # ------------------------------------------------------------------ 35 Governing Bodies
    ("35", "Fund Governing Body", "Parent Governing Body"): GOVERNING_BODY,
    ("35", "Fund Governing Body", "Governed Registrant"): PRODUCT,
    ("35", "Fund Governing Body", "Governed Entity"): LEGAL_ENTITY,
    ("35", "Fund Governing Body", "Governed Trustee Party"): PARTY,
    ("35", "Governed Fund Coverage", "Coverage Governing Body"): GOVERNING_BODY,
    ("35", "Governed Fund Coverage", "Governed Product"): PRODUCT,
    ("35", "Governing Body Membership", "Membership Governing Body"): GOVERNING_BODY,
    ("35", "Governing Body Membership", "External Member Party"): PARTY,
    ("35", "Governing Body Membership", "Interested Member Employee"): EMPLOYEE,
    ("35", "Fund Officer Appointment", "Officer Registrant"): PRODUCT,
    ("35", "Fund Officer Appointment", "Officer Entity"): LEGAL_ENTITY,
    ("35", "Fund Officer Appointment", "Appointed Officer"): EMPLOYEE,
    ("35", "Fund Officer Appointment", "External Officer Party"): PARTY,
    ("35", "Fund Officer Appointment", "Designated Entity"): LEGAL_ENTITY,
    ("35", "Fund Officer Appointment", "Appointing Resolution"): RESOLUTION,
    ("35", "Governance Standards Profile", "Independent Counsel Party"): PARTY,
    # ------------------------------------------------------------------ 35 Board Meetings & Reports
    ("35", "Board Meeting", "Meeting Governing Body"): GOVERNING_BODY,
    ("35", "Board Agenda Item", "Agenda Meeting"): BOARD_MEETING,
    ("35", "Board Agenda Item", "Presenter Employee"): EMPLOYEE,
    ("35", "Board Report Received", "Receiving Meeting"): BOARD_MEETING,
    ("35", "Board Report Received", "Reported Products"): PRODUCT,
    ("35", "Board Report Received", "Reported Risk Program"): ("31", "Risk Program Designation"),
    ("35", "Board Report Received", "Report Preparer"): EMPLOYEE,
    ("35", "Board Report Source Item", "Related Investment Breach"): ("33", "Investment Breach"),
    ("35", "Board Report Source Item", "Related Risk Limit Exceedance"): ("31", "Risk Limit Exceedance"),
    ("35", "Board Report Source Item", "Related Fair Value Determination"): ("22", "Fair Value Determination"),
    ("35", "Board Self-Assessment", "Assessed Governing Body"): GOVERNING_BODY,
    # ------------------------------------------------------------------ 35 Board Approvals & Resolutions
    ("35", "Board Resolution", "Adopting Meeting"): BOARD_MEETING,
    ("35", "Board Resolution", "Superseded Resolution"): RESOLUTION,
    ("35", "Resolution Subject Link", "Linked Resolution"): RESOLUTION,
    ("35", "Resolution Subject Link", "Subject Advisory Agreement"): ADVISORY_AGREEMENT,
    ("35", "Resolution Subject Link", "Subject Product"): PRODUCT,
    ("35", "Resolution Subject Link", "Subject Share Class"): SHARE_CLASS,
    ("35", "Resolution Subject Link", "Subject Service Provider Role"): ("01", "Product Party Role"),
    ("35", "Resolution Subject Link", "Subject Product Proposal"): ("36", "Product Proposal"),
    ("35", "Resolution Subject Link", "Subject Change Initiative"): ("36", "Product Change Initiative"),
    ("35", "Resolution Subject Link", "Subject Product Review"): ("36", "Product Review"),
    ("35", "Resolution Subject Link", "Subject Voting Policy"): VOTING_POLICY,
    ("35", "Resolution Subject Link", "Subject Highly Liquid Investment Minimum"): ("31", "Highly Liquid Investment Minimum"),
    ("35", "Resolution Subject Link", "Subject Risk Program Designation"): ("31", "Risk Program Designation"),
    ("35", "Resolution Subject Link", "Subject Guideline Waiver"): ("33", "Guideline Waiver"),
    ("35", "Resolution Subject Link", "Subject Proxy Voting Report"): PROXY_VOTING_REPORT,
    ("35", "Resolution Subject Link", "Subject Shareholder Communication"): ("13", "Shareholder Communication"),
    ("35", "Resolution Subject Link", "Subject Fund Financial Statement"): ("27", "Fund Financial Statement"),
    ("35", "Resolution Subject Link", "Subject RIC Determination Tax Year"): ("27", "Fund Tax Year Record"),
    ("35", "Fund Fidelity Bond", "Insured Funds"): PRODUCT,
    ("35", "Fund Fidelity Bond", "Bond Insurer"): PARTY,
    ("35", "Fund Fidelity Bond", "Bond Approving Resolution"): RESOLUTION,
    ("35", "Fund Fidelity Bond", "Bond Filing"): FILING,
    # ------------------------------------------------------------------ 35 Advisory Contract Oversight
    ("35", "Fund Advisory Agreement", "Adviser Entity"): LEGAL_ENTITY,
    ("35", "Fund Advisory Agreement", "External Sub-Adviser"): PARTY,
    ("35", "Fund Advisory Agreement", "Parent Advisory Agreement"): ADVISORY_AGREEMENT,
    ("35", "Agreement Fund Schedule", "Schedule Agreement"): ADVISORY_AGREEMENT,
    ("35", "Agreement Fund Schedule", "Covered Fund"): PRODUCT,
    ("35", "Agreement Fund Schedule", "Schedule Renewal"): RENEWAL,
    ("35", "Agreement Fund Schedule", "Shareholder Approval Proxy Proposal"): PROXY_PROPOSAL,
    ("35", "Agreement Fund Schedule", "Fund Fee Schedule"): ("01", "Management Fee"),
    ("35", "Advisory Contract Renewal", "Renewed Agreement"): ADVISORY_AGREEMENT,
    ("35", "Advisory Contract Renewal", "Materials Preparer"): PARTY,
    ("35", "Advisory Contract Renewal", "Renewal Approving Resolution"): RESOLUTION,
    ("35", "Renewal Material Item", "Material Renewal"): RENEWAL,
    ("35", "Renewal Material Item", "Source Fee Benchmark Study"): ("11", "Fee Benchmark Study"),
    ("35", "Renewal Material Item", "Source Peer Universe"): ("11", "Peer Universe"),
    ("35", "Renewal Material Item", "Source Profitability Record"): ("10", "Profitability Record"),
    ("35", "Renewal Material Item", "Source Performance Return"): ("32", "Performance Return"),
    ("35", "Renewal Material Item", "Source Benchmark Return"): ("32", "Benchmark Return"),
    ("35", "Board 15(c) Finding", "Finding Renewal"): RENEWAL,
    # ------------------------------------------------------------------ 35 Regulatory Filings & Disclosures
    ("35", "Filing Obligation", "Obligated Product"): PRODUCT,
    ("35", "Filing Obligation", "Obligated Entity"): LEGAL_ENTITY,
    ("35", "Filing Obligation", "Filing Calendar"): ("09", "Calendar"),
    ("35", "Fund Regulatory Filing", "Filer Product"): PRODUCT,
    ("35", "Fund Regulatory Filing", "Filer Entity"): LEGAL_ENTITY,
    ("35", "Fund Regulatory Filing", "Met Obligation"): ("35", "Filing Obligation"),
    ("35", "Fund Regulatory Filing", "Covered Series"): PRODUCT,
    ("35", "Fund Regulatory Filing", "Amended Filing"): FILING,
    ("35", "Fund Regulatory Filing", "Filing Agent Party"): PARTY,
    ("35", "Filing Document", "Filed Shareholder Communication"): ("13", "Shareholder Communication"),
    ("35", "Filing Document", "Filed Product Document"): ("01", "Product Document"),
    ("35", "Filing Document", "Filed Proxy Voting Report"): PROXY_VOTING_REPORT,
    ("35", "Filing Document", "Filed Document Share Class"): SHARE_CLASS,
    ("35", "Filing Certification", "Certifying Officer"): EMPLOYEE,
    ("35", "Filing Certification", "Certifying External Party"): PARTY,
    ("35", "Filing Data Source", "Source Filing"): FILING,
    ("35", "Filing Data Source", "Source Sign-Off Employee"): EMPLOYEE,
    ("35", "Filing Data Source", "Related Data Quality Result"): ("21", "Data Quality Result"),
    ("35", "Fund Public Disclosure", "Disclosing Product"): PRODUCT,
    ("35", "Fund Public Disclosure", "Disclosing Share Class"): SHARE_CLASS,
    ("35", "Fund Public Disclosure", "Source ETF Basket"): ("24", "ETF Basket"),
    ("35", "Fund Public Disclosure", "Source ETF Market Statistic"): ("22", "ETF Market Statistic"),
    # ------------------------------------------------------------------ 35 Fund Regulatory Status
    ("35", "RIC Qualification Determination", "Determined Fund"): PRODUCT,
    ("35", "RIC Qualification Determination", "Determination Tax Year"): ("27", "Fund Tax Year Record"),
    ("35", "RIC Qualification Determination", "Relied RIC Test Results"): ("27", "RIC Test Result"),
    ("35", "RIC Qualification Determination", "Determination Approver"): EMPLOYEE,
    ("35", "RIC Qualification Determination", "Audit Committee Review Meeting"): BOARD_MEETING,
    ("35", "Reportable Fund Event", "Event Fund"): PRODUCT,
    ("35", "Reportable Fund Event", "Source Investment Breach"): ("33", "Investment Breach"),
    ("35", "Reportable Fund Event", "Source Risk Limit Exceedance"): ("31", "Risk Limit Exceedance"),
    ("35", "Reportable Fund Event", "Source Fund Liquidity Profile"): ("31", "Fund Liquidity Profile"),
    ("35", "Reportable Fund Event", "Source VaR Test Result"): ("31", "VaR Test Result"),
    ("35", "Reportable Fund Event", "Resulting Filing"): FILING,
    ("35", "Exemptive Relief Reliance", "Relying Fund"): PRODUCT,
    ("35", "Exemptive Relief Reliance", "Board Finding Resolution"): RESOLUTION,
}

# W2-W4 merge (2026-10-15): ("35", "Agreement Fund Schedule", "Fund Fee Schedule") is now typed Reference (Fund Fee
# Schedule, 01) (CW-051 re-cut) and registered to 01 Management Fee, the fund fee terms group (FSCH-, CD-232). It folds
# into 01 Share Class, so models join it through the share class. Board Consent Record (30 private-fund deals) is
# removed with 30 (CW-930).
