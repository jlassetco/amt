"""Key and link registry extension: Data Domains 37 Enterprise & Operational Risk and 38 Corporate Compliance &
Regulatory Affairs (enterprise expansion, Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). keys_g9_37_44.py already keys the objects moved into
38 (Entity Authorization, Cross-Border Passport, Regulatory Obligation, Attestation) and their references; they are not
repeated here.

Conventions used in the notes:
- A reference to a versioned object (Control, Model Inventory Entry, Key Risk Indicator, Business Continuity Plan, Policy
  Version) carries the code and version in one value ("CNTRL-004120 / 3", "MODEL-0412 / 3"); the model splits it to join
  on the target's composite key.
- "Exactly one of ... is filled" keys keep every alternative column in the key; the blank ones are empty, not unknown.

W2-W4 merge (2026-10-15): the 38 W4 pass is applied. AML and Sanctions Report is keyed by AML Report Key (case-less
OFAC reports have no case); Suspicious Transaction and Order Report and AML Case.Source Account Monitoring Alert are
removed; the five 38 attribute groups (Regulatory Change Impact, Regulator Request Item, Examination Finding, Policy
Version, Conflict Mitigation) are child entities; Form CRS Filing Detail, Adviser Custody Profile and Custody Surprise
Examination are added.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
EMPLOYEE = ("20", "Employee")
INSTRUMENT = ("17", "Instrument")
PRODUCT = ("01", "Investment Product")
RISK = ("37", "Enterprise Risk")
RISK_CATEGORY = ("37", "Risk Taxonomy Category")
CONTROL = ("37", "Control")
INCIDENT = ("37", "Operational Incident")
MODEL = ("37", "Model Inventory Entry")
TPRA = ("37", "Third-Party Risk Assessment")
POLICY = ("38", "Policy")
POLICY_VERSION = ("38", "Policy Version")
RESTRICTED_LIST = ("38", "Firm Restricted List")
MNPI = ("38", "MNPI Escalation")
PERSONAL_ACCOUNT = ("38", "Personal Trading Account")
PERSONAL_REPORT = ("38", "Personal Securities Report")
SURV_ALERT = ("38", "Trade Surveillance Alert")

KEYS = {
    # ------------------------------------------------------------------ 37 Risk Framework & Register
    ("37", "Risk Taxonomy Category"): _k(["Risk Category Code", "Risk Taxonomy Version"], "Composite",
                                         note="The code is stable across taxonomy versions, so the version completes the key."),
    ("37", "Enterprise Risk"): _k(["Risk ID"], "Natural"),
    ("37", "Risk Assessment"): _k(["Assessed Risk", "Risk Assessment Date"], "Composite"),
    ("37", "Risk Appetite Statement"): _k(["Appetite Statement Code", "Appetite Scope Entity", "Appetite Effective From"],
                                          "Composite",
                                          note="Appetite Scope Entity is blank for the firm-wide statement; blank is a "
                                               "key value, not unknown."),

    # ------------------------------------------------------------------ 37 Risk & Control Self-Assessment
    ("37", "RCSA Campaign"): _k(["RCSA Campaign Code", "Assessed Org Unit"], "Composite",
                                note="One campaign code runs across many org units; the org unit completes the key."),
    ("37", "Control"): _k(["Control ID", "Control Version"], "Composite",
                          note="The control library is versioned; references carry ID and version in one value."),
    ("37", "Risk Control Link"): _k(["Linked Risk", "Linked Control", "Link Effective From"], "Composite",
                                    note="Linked Control carries the control ID only; the link applies to the version "
                                         "in effect."),
    ("37", "Control Test"): _k(["Tested Control", "Control Test Date", "Control Test Sequence"], "Composite",
                               note="Tested Control carries control ID and version in one value."),

    # ------------------------------------------------------------------ 37 Operational Incidents & Losses
    ("37", "Operational Incident"): _k(["Operational Incident ID"], "Natural"),
    ("37", "Incident Source Record"): _k(["Incident Source Record Key"], "Surrogate",
                                         note="Incident x source type x the one filled typed source reference (15 "
                                              "alternative columns) identifies a row; a surrogate stands in for that "
                                              "coalesced key. Model gap: no single source record reference attribute."),
    ("37", "Incident Classification"): _fold(),
    ("37", "Incident Regulatory Notification"): _k(["Notified Incident", "Notification Authority",
                                                    "Incident Notification Regime", "Incident Notification Stage"],
                                                   "Composite",
                                                   note="The regime was split from the stage (CW-937), so one incident "
                                                        "can be notified under several regimes; the authority is "
                                                        "'(none)' for a notice only to affected customers."),
    ("37", "Operational Loss Event"): _k(["Loss Event ID"], "Natural"),
    ("37", "Loss Event Amount"): _k(["Amount Loss Event", "Loss Amount Sequence"], "Composite"),

    # ------------------------------------------------------------------ 37 Key Risk Indicators
    ("37", "Key Risk Indicator"): _k(["KRI Code", "KRI Version"], "Composite"),
    ("37", "KRI Threshold"): _fold("Thresholds are set per KRI version, the parent's grain."),
    ("37", "KRI Observation"): _k(["Observed KRI", "KRI Observation Date"], "Composite",
                                  note="Observed KRI carries code and version in one value; the version fixes the "
                                       "thresholds applied."),

    # ------------------------------------------------------------------ 37 Issues & Actions
    ("37", "Risk Issue"): _k(["Risk Issue ID"], "Natural"),
    ("37", "Issue Action"): _k(["Action Issue", "Issue Action Sequence"], "Composite"),

    # ------------------------------------------------------------------ 37 Operational Resilience & Continuity
    # Important Business Service and Impact Tolerance removed (UK operational resilience regime; CW-937).
    ("37", "Critical or Important Function"): _k(["Critical Function Code", "Designating Entity",
                                                 "Function Effective From"], "Composite"),
    ("37", "Resilience Resource Mapping"): _k(["Resilience Resource Mapping Key"], "Surrogate",
                                              note="Function x the one filled typed resource (eight alternative "
                                                   "columns) x period identifies a row; a surrogate stands in for that "
                                                   "coalesced key. Model gap: no single resource reference attribute."),
    ("37", "Business Impact Analysis"): _k(["Analyzed Business Process", "BIA Date"], "Composite",
                                           note="The business process is a capability map code with no master object."),
    ("37", "Business Continuity Plan"): _k(["Business Continuity Plan Code", "Business Continuity Plan Version"],
                                           "Composite"),
    ("37", "Resilience Test"): _k(["Resilience Test Reference", "Resilience Test Date"], "Composite",
                                  note="The grain names reference x date, so a reference reused across test dates "
                                       "stays unique."),

    # ------------------------------------------------------------------ 37 Third-Party Risk
    ("37", "Third-Party Risk Assessment"): _k(["Third-Party Risk Assessment Reference"], "Natural",
                                              note="The firm reference key stands for the grain third party x supplier "
                                                   "engagement x assessment cycle, so dependents do not embed party keys."),
    ("37", "Third-Party Risk Domain Result"): _k(["Result Assessment", "Third-Party Risk Domain"], "Composite"),

    # ------------------------------------------------------------------ 37 Model Risk Management
    ("37", "Model Inventory Entry"): _k(["Model ID", "Model Version"], "Composite",
                                        note="Model x version per the grain; products join on Model ID alone where they "
                                             "need the model across versions."),
    ("37", "Model Tier Assignment"): _k(["Tiered Model", "Tier Effective From"], "Composite",
                                        note="The tier applies to the model across versions; Tiered Model carries the "
                                             "Model ID only."),
    ("37", "Model Validation"): _k(["Validated Model", "Model Validation Sequence"], "Composite",
                                   note="Validated Model carries model ID and version in one value."),
    ("37", "Model Performance Monitoring"): _k(["Monitored Model", "Monitoring Test", "Monitoring Period End Date"],
                                               "Composite",
                                               note="Monitored Model carries model ID and version in one value."),

    # ------------------------------------------------------------------ 37 Internal Audit
    ("37", "Auditable Entity"): _k(["Auditable Entity Code", "Auditable Entity Effective From"], "Composite"),
    ("37", "Audit Plan"): _k(["Audit Plan Year", "Audit Plan Version"], "Composite"),
    ("37", "Audit Engagement"): _k(["Audit Engagement ID"], "Natural"),
    ("37", "Audit Finding"): _k(["Audit Finding ID"], "Natural"),
    ("37", "Finding Closure Validation"): _k(["Validated Finding", "Validation Attempt Sequence"], "Composite"),

    # ------------------------------------------------------------------ 38 Registrations & Firm Filings
    ("38", "Firm Regulatory Filing"): _k(["Firm Filing ID"], "Natural"),
    ("38", "Ownership Disclosure Determination"): _k(["Disclosure Security Class", "Disclosure Regime",
                                                      "Aggregation Entity", "Determination Date"], "Composite",
                                                     note="The grain's issuer is measured per security class, which "
                                                          "determines the issuer."),

    # ------------------------------------------------------------------ 38 Regulatory Obligations & Change
    ("38", "Regulatory Change Item"): _k(["Regulatory Change ID"], "Natural"),
    ("38", "Regulatory Change Impact"): _child(["Impacted Entity", "Impacted Business Line", "Impacted Data Domain"],
                                               "Exactly one of the three scope columns is filled per row."),

    # ------------------------------------------------------------------ 38 Examinations & Inquiries
    ("38", "Regulatory Examination"): _k(["Examination ID"], "Natural"),
    ("38", "Regulator Request Item"): _child(["Request Sequence"]),
    ("38", "Examination Finding"): _child(["Finding Sequence"]),

    # ------------------------------------------------------------------ 38 Policies & Attestations
    ("38", "Policy"): _k(["Policy ID"], "Natural"),
    ("38", "Policy Version"): _child(["Policy Version Number"], "References to a version carry policy ID and "
                                     "version in one value (\"POLCY-0118 v7.0\")."),
    ("38", "Compliance Program Review"): _k(["Reviewed Entity", "Program Review Type", "Review Period End"],
                                            "Composite",
                                            note="Model gap: the grain allows a fund complex as the reviewed scope, but "
                                                 "only Reviewed Entity (a legal entity) can carry it; Covered Products "
                                                 "lists the funds."),

    # ------------------------------------------------------------------ 38 Code of Ethics & Personal Trading
    ("38", "Conduct Population Designation"): _k(["Designated Employee", "Conduct Designation Type",
                                                  "Designating Entity", "Designating Fund", "Designation Effective From"],
                                                 "Composite",
                                                 note="Exactly one of Designating Entity and Designating Fund is filled."),
    ("38", "Personal Trading Account"): _k(["Personal Account Key"], "Natural",
                                           note="Firm key for employee x reportable account at a broker; the masked "
                                                "broker number is descriptive only."),
    ("38", "Personal Securities Report"): _k(["Reporting Access Person", "Personal Report Type", "Report As-Of Date"],
                                             "Composite"),
    ("38", "Reported Personal Holding"): _child(["Holding Account", "Held Security", "Held Security Description"],
                                                "One row per account x security line of the report; Held Security is "
                                                "blank where the security master lacks it, and the description then "
                                                "identifies the line."),
    ("38", "Personal Transaction"): _k(["Transaction Account", "Broker Transaction Reference"], "Composite",
                                       note="The broker reference is unique within the account only."),
    ("38", "Pre-Clearance Request"): _k(["Requesting Employee", "Request Timestamp"], "Composite"),
    ("38", "Code of Ethics Violation"): _k(["Violating Employee", "Violation Detected Date", "Violation Sequence"],
                                           "Composite"),

    # ------------------------------------------------------------------ 38 Political Contributions
    ("38", "Political Contribution"): _k(["Political Contribution ID"], "Natural",
                                         note="Firm identifier (PCON <year>-<sequence>) for contributor x recipient x date."),
    ("38", "Pay-to-Play Review"): _fold(),

    # ------------------------------------------------------------------ 38 Conflicts of Interest
    ("38", "Conflict of Interest"): _k(["Conflict ID"], "Natural"),
    ("38", "Conflict Mitigation"): _child(["Mitigation Sequence"], "Key CONFL-<n> / M<nn>, read by 08 Incentive "
                                          "Conflict Review."),
    ("38", "Outside Business Activity"): _k(["OBA Employee", "OBA Type", "OBA Organization", "OBA Effective From"],
                                            "Composite",
                                            note="The grain's outside activity has no identifier; type and organization "
                                                 "stand for it."),

    # ------------------------------------------------------------------ 38 AML & Sanctions Program
    ("38", "AML Program Assessment"): _k(["Assessed Entity", "Assessed Fund", "Assessment Year"], "Composite",
                                         note="Exactly one of Assessed Entity and Assessed Fund is filled."),
    ("38", "AML Case"): _k(["AML Case Number"], "Natural",
                           note="The restricted firm case number, with no prefix."),
    ("38", "AML and Sanctions Report"): _k(["AML Report Key"], "Natural",
                                           note="Restricted firm key without a prefix; Reported Case + Report "
                                                "Sequence is the alternate key for case-based reports (case-less "
                                                "OFAC reports have no case)."),

    # ------------------------------------------------------------------ 38 Market Conduct & Information Barriers
    ("38", "Firm Restricted List"): _k(["Restricted List Code"], "Natural",
                                       note="The short list code is the key 33 compliance rules read."),
    ("38", "Restricted List Entry"): _k(["Restricted List Entry ID"], "Natural"),
    ("38", "MNPI Escalation"): _k(["MNPI Escalation ID"], "Natural"),
    ("38", "Insider List Entry"): _k(["Insider List", "Insider Escalation", "Internal Insider", "External Insider",
                                      "Access Obtained Timestamp"], "Composite",
                                     note="Insider Escalation is blank for the permanent insiders section; exactly one "
                                          "of Internal Insider and External Insider is filled."),
    ("38", "Trade Surveillance Alert"): _k(["Trade Surveillance Alert ID"], "Natural"),
    # W2-W4 merge (2026-10-15): 38 objects restored or added
    ("38", "Form CRS Filing Detail"): _fold(),
    ("38", "Adviser Custody Profile"): _k(["Custody Adviser Entity", "Custody Profile Effective From"], "Composite"),
    ("38", "Custody Surprise Examination"): _k(["Surprise Examined Adviser",
                                                "Surprise Examination Date"], "Composite"),
}

REFS = {
    # ------------------------------------------------------------------ 37 Risk Framework & Register
    ("37", "Risk Taxonomy Category", "Parent Risk Category"): RISK_CATEGORY,
    ("37", "Enterprise Risk", "Risk Category"): RISK_CATEGORY,
    ("37", "Enterprise Risk", "Risk Owning Org Unit"): ORG_UNIT,
    ("37", "Enterprise Risk", "Risk Legal Entities"): LEGAL_ENTITY,
    ("37", "Enterprise Risk", "Risk Owner"): EMPLOYEE,
    ("37", "Risk Assessment", "Assessed Risk"): RISK,
    ("37", "Risk Assessment", "Source RCSA Campaign"): ("37", "RCSA Campaign"),
    ("37", "Risk Assessment", "Risk Assessor"): EMPLOYEE,
    ("37", "Risk Appetite Statement", "Appetite Scope Entity"): LEGAL_ENTITY,
    # ------------------------------------------------------------------ 37 Risk & Control Self-Assessment
    ("37", "RCSA Campaign", "Assessed Org Unit"): ORG_UNIT,
    ("37", "RCSA Campaign", "RCSA Sign-Off By"): EMPLOYEE,
    ("37", "Control", "Control Owning Legal Entity"): LEGAL_ENTITY,
    ("37", "Control", "Control Owner"): EMPLOYEE,
    ("37", "Risk Control Link", "Linked Risk"): RISK,
    ("37", "Risk Control Link", "Linked Control"): CONTROL,
    ("37", "Control Test", "Tested Control"): CONTROL,
    ("37", "Control Test", "Control Tester"): EMPLOYEE,
    # ------------------------------------------------------------------ 37 Operational Incidents & Losses
    ("37", "Operational Incident", "Incident Legal Entity"): LEGAL_ENTITY,
    # Operational Incident.Impacted Business Services removed with Important Business Service (CW-937).
    ("37", "Operational Incident", "Impacted Products"): PRODUCT,
    ("37", "Operational Incident", "Impacted Portfolios"): ("18", "Portfolio"),
    ("37", "Operational Incident", "Incident Owner"): EMPLOYEE,
    ("37", "Incident Source Record", "Source Incident"): INCIDENT,
    ("37", "Incident Source Record", "Source Trade Error"): ("25", "Trade Error"),
    ("37", "Incident Source Record", "Source NAV Error Case"): ("27", "NAV Error Case"),
    ("37", "Incident Source Record", "Source Investment Breach"): ("33", "Investment Breach"),
    ("37", "Incident Source Record", "Source Risk Limit Exceedance"): ("31", "Risk Limit Exceedance"),
    ("37", "Incident Source Record", "Source Servicing Error"): ("13", "Servicing Error"),
    ("37", "Incident Source Record", "Source IT Incident"): ("41", "IT Incident"),
    ("37", "Incident Source Record", "Source Physical Security Incident"): ("44", "Physical Security Incident"),
    ("37", "Incident Source Record", "Source Health and Safety Incident"): ("44", "Health & Safety Incident"),
    ("37", "Incident Source Record", "Source Plan Correction"): ("16", "Plan Correction"),
    ("37", "Incident Source Record", "Source AP Order"): ("29", "AP Creation / Redemption Order"),
    ("37", "Incident Source Record", "Source Model Portfolio"): ("01", "Model Portfolio"),
    ("37", "Incident Source Record", "Source Account Monitoring Alert"): ("29", "Account Monitoring Alert"),
    ("37", "Incident Classification", "Incident Risk Category"): RISK_CATEGORY,
    ("37", "Incident Regulatory Notification", "Notified Incident"): INCIDENT,
    ("37", "Incident Regulatory Notification", "Notifying Legal Entity"): LEGAL_ENTITY,
    ("37", "Operational Loss Event", "Originating Incident"): INCIDENT,
    ("37", "Operational Loss Event", "Loss Legal Entity"): LEGAL_ENTITY,
    ("37", "Operational Loss Event", "Impact Source Servicing Error"): ("13", "Servicing Error"),
    ("37", "Operational Loss Event", "Related Legal Matter"): ("39", "Legal Matter"),
    ("37", "Loss Event Amount", "Amount Loss Event"): ("37", "Operational Loss Event"),
    ("37", "Loss Event Amount", "GL Evidence Journal"): ("19", "Journal Entry"),
    ("37", "Loss Event Amount", "Amount Source Trade Error"): ("25", "Trade Error"),
    ("37", "Loss Event Amount", "Amount Source NAV Error Case"): ("27", "NAV Error Case"),
    ("37", "Loss Event Amount", "Amount Source Breach Loss Calculation"): ("33", "Breach Loss Calculation"),
    ("37", "Loss Event Amount", "Amount Source Settlement Penalty"): ("26", "Settlement Penalty"),
    # ------------------------------------------------------------------ 37 Key Risk Indicators
    ("37", "Key Risk Indicator", "Measured Risk"): RISK,
    ("37", "Key Risk Indicator", "Source Metric Definition"): ("21", "Metric Definition"),
    ("37", "KRI Threshold", "Linked Appetite Statement"): ("37", "Risk Appetite Statement"),
    ("37", "KRI Observation", "Observed KRI"): ("37", "Key Risk Indicator"),
    # ------------------------------------------------------------------ 37 Issues & Actions
    ("37", "Risk Issue", "Source Audit Finding"): ("37", "Audit Finding"),
    ("37", "Risk Issue", "Source Examination Finding"): ("38", "Examination Finding"),
    ("37", "Risk Issue", "Source Compliance Program Review"): ("38", "Compliance Program Review"),
    ("37", "Risk Issue", "Source Operational Incident"): INCIDENT,
    ("37", "Risk Issue", "Source Control Test"): ("37", "Control Test"),
    ("37", "Risk Issue", "Source Model Validation"): ("37", "Model Validation"),
    ("37", "Risk Issue", "Source Third-Party Risk Assessment"): TPRA,
    ("37", "Risk Issue", "Source Resilience Test"): ("37", "Resilience Test"),
    ("37", "Risk Issue", "Source Vulnerability Finding"): ("41", "Vulnerability Finding"),
    ("37", "Risk Issue", "Issue Related Risk"): RISK,
    ("37", "Risk Issue", "Issue Owner"): EMPLOYEE,
    ("37", "Issue Action", "Action Issue"): ("37", "Risk Issue"),
    ("37", "Issue Action", "Issue Action Owner"): EMPLOYEE,
    ("37", "Issue Action", "Risk Acceptance Approver"): EMPLOYEE,
    # ------------------------------------------------------------------ 37 Operational Resilience & Continuity
    # Important Business Service and Impact Tolerance references removed with the objects, as are the links to them
    # from Critical or Important Function, Resilience Resource Mapping and Resilience Test (CW-937).
    ("37", "Critical or Important Function", "Designating Entity"): LEGAL_ENTITY,
    ("37", "Resilience Resource Mapping", "Mapped Function"): ("37", "Critical or Important Function"),
    ("37", "Resilience Resource Mapping", "Mapped Workforce Position"): ("20", "Workforce Position"),
    ("37", "Resilience Resource Mapping", "Mapped Application"): ("41", "Application"),
    ("37", "Resilience Resource Mapping", "Mapped IT Service"): ("41", "IT Service"),
    ("37", "Resilience Resource Mapping", "Mapped Site"): ("09", "Office Location"),
    ("37", "Resilience Resource Mapping", "Mapped Supplier Engagement"): ("40", "Supplier Engagement"),
    ("37", "Resilience Resource Mapping", "Mapped Data Asset"): ("21", "Data Asset"),
    ("37", "Business Continuity Plan", "Plan Owner"): EMPLOYEE,
    ("37", "Resilience Test", "Tested Continuity Plan"): ("37", "Business Continuity Plan"),
    ("37", "Resilience Test", "Source Security and Resilience Test"): ("41", "Security & Resilience Test"),
    # ------------------------------------------------------------------ 37 Third-Party Risk
    ("37", "Third-Party Risk Assessment", "Assessed Supplier Engagement"): ("40", "Supplier Engagement"),
    ("37", "Third-Party Risk Assessment", "Assessed Third Party"): PARTY,
    ("37", "Third-Party Risk Assessment", "Third-Party Assessor"): EMPLOYEE,
    ("37", "Third-Party Risk Domain Result", "Result Assessment"): TPRA,
    ("37", "Third-Party Risk Domain Result", "Domain Evidence Assurance Report"): ("14", "Assurance Report"),
    # ------------------------------------------------------------------ 37 Model Risk Management
    ("37", "Model Inventory Entry", "Model Owner"): EMPLOYEE,
    ("37", "Model Inventory Entry", "Model Vendor"): PARTY,
    ("37", "Model Tier Assignment", "Tiered Model"): MODEL,
    ("37", "Model Validation", "Validated Model"): MODEL,
    ("37", "Model Validation", "Internal Validator"): EMPLOYEE,
    ("37", "Model Validation", "External Validator"): PARTY,
    ("37", "Model Performance Monitoring", "Monitored Model"): MODEL,
    ("37", "Model Performance Monitoring", "Back-Test Evidence"): ("31", "VaR Back-Test"),
    # ------------------------------------------------------------------ 37 Internal Audit
    ("37", "Auditable Entity", "Covered Org Unit"): ORG_UNIT,
    ("37", "Auditable Entity", "Covered Legal Entity"): LEGAL_ENTITY,
    ("37", "Auditable Entity", "Covered Third Party"): PARTY,
    ("37", "Audit Plan", "Co-Sourced Provider"): PARTY,
    ("37", "Audit Engagement", "Engagement Audit Plan"): ("37", "Audit Plan"),
    ("37", "Audit Engagement", "Covered Auditable Entities"): ("37", "Auditable Entity"),
    ("37", "Audit Engagement", "Engagement Lead"): EMPLOYEE,
    ("37", "Audit Finding", "Finding Engagement"): ("37", "Audit Engagement"),
    ("37", "Finding Closure Validation", "Validated Finding"): ("37", "Audit Finding"),
    ("37", "Finding Closure Validation", "Closure Validated By"): EMPLOYEE,

    # ------------------------------------------------------------------ 38 Registrations & Firm Filings
    ("38", "Firm Regulatory Filing", "Filer Entity"): LEGAL_ENTITY,
    ("38", "Firm Regulatory Filing", "Amended Firm Filing"): ("38", "Firm Regulatory Filing"),
    ("38", "Ownership Disclosure Determination", "Disclosure Issuer"): PARTY,
    ("38", "Ownership Disclosure Determination", "Disclosure Security Class"): INSTRUMENT,
    ("38", "Ownership Disclosure Determination", "Aggregation Entity"): LEGAL_ENTITY,
    ("38", "Ownership Disclosure Determination", "Reviewed Engagement"): ("34", "Engagement"),
    ("38", "Ownership Disclosure Determination", "Resulting Firm Filing"): ("38", "Firm Regulatory Filing"),
    # ------------------------------------------------------------------ 38 Regulatory Obligations & Change
    ("38", "Regulatory Obligation", "Monitoring Control"): CONTROL,
    ("38", "Regulatory Change Item", "Source Horizon Item"): ("11", "Regulatory Horizon Item"),
    ("38", "Regulatory Change Impact", "Impacted Change Item"): ("38", "Regulatory Change Item"),
    ("38", "Regulatory Change Impact", "Impacted Entity"): LEGAL_ENTITY,
    ("38", "Regulatory Change Impact", "Affected Obligations"): ("38", "Regulatory Obligation"),
    ("38", "Regulatory Change Impact", "Policies to Update"): POLICY,
    # ------------------------------------------------------------------ 38 Examinations & Inquiries
    ("38", "Regulatory Examination", "Examined Entities"): LEGAL_ENTITY,
    ("38", "Regulator Request Item", "Request Examination"): ("38", "Regulatory Examination"),
    ("38", "Examination Finding", "Finding Examination"): ("38", "Regulatory Examination"),
    # ------------------------------------------------------------------ 38 Policies & Attestations
    ("38", "Policy", "Policy Owner"): EMPLOYEE,
    ("38", "Policy", "Policy Applicable Entities"): LEGAL_ENTITY,
    ("38", "Policy", "Policy Regulatory Basis"): ("38", "Regulatory Obligation"),
    ("38", "Policy Version", "Versioned Policy"): POLICY,
    ("38", "Policy Version", "Required Training"): ("20", "Mandatory Training Requirement"),
    ("38", "Attestation", "Attested Policy Version"): POLICY_VERSION,
    ("38", "Compliance Program Review", "Reviewed Entity"): LEGAL_ENTITY,
    ("38", "Compliance Program Review", "Covered Products"): PRODUCT,
    ("38", "Compliance Program Review", "Review Lead"): EMPLOYEE,
    # ------------------------------------------------------------------ 38 Code of Ethics & Personal Trading
    ("38", "Conduct Population Designation", "Designated Employee"): EMPLOYEE,
    ("38", "Conduct Population Designation", "Designating Entity"): LEGAL_ENTITY,
    ("38", "Conduct Population Designation", "Designating Fund"): PRODUCT,
    ("38", "Personal Trading Account", "Account Holder Employee"): EMPLOYEE,
    ("38", "Personal Trading Account", "Personal Account Broker"): PARTY,
    ("38", "Personal Trading Account", "Firm Brokerage Account"): ("15", "Account"),
    ("38", "Personal Securities Report", "Reporting Access Person"): EMPLOYEE,
    ("38", "Reported Personal Holding", "Holding Report"): PERSONAL_REPORT,
    ("38", "Reported Personal Holding", "Holding Account"): PERSONAL_ACCOUNT,
    ("38", "Reported Personal Holding", "Held Security"): INSTRUMENT,
    ("38", "Personal Transaction", "Transaction Account"): PERSONAL_ACCOUNT,
    ("38", "Personal Transaction", "Traded Security"): INSTRUMENT,
    ("38", "Personal Transaction", "Matched Pre-Clearance"): ("38", "Pre-Clearance Request"),
    ("38", "Personal Transaction", "Reported On Report"): PERSONAL_REPORT,
    ("38", "Pre-Clearance Request", "Requesting Employee"): EMPLOYEE,
    ("38", "Pre-Clearance Request", "Pre-Clearance Security"): INSTRUMENT,
    ("38", "Pre-Clearance Request", "Blocking Restricted List Entry"): ("38", "Restricted List Entry"),
    ("38", "Code of Ethics Violation", "Violating Employee"): EMPLOYEE,
    ("38", "Code of Ethics Violation", "Violated Policy Version"): POLICY_VERSION,
    ("38", "Code of Ethics Violation", "Source Surveillance Alert"): SURV_ALERT,
    # ------------------------------------------------------------------ 38 Political Contributions
    ("38", "Political Contribution", "Contributor Employee"): EMPLOYEE,
    ("38", "Political Contribution", "Contributing Entity"): LEGAL_ENTITY,
    ("38", "Political Contribution", "Contribution Recipient"): PARTY,
    ("38", "Pay-to-Play Review", "Affected Government Clients"): PARTY,
    # ------------------------------------------------------------------ 38 Conflicts of Interest
    ("38", "Conflict of Interest", "Conflict Entities"): LEGAL_ENTITY,
    ("38", "Conflict Mitigation", "Mitigated Conflict"): ("38", "Conflict of Interest"),
    ("38", "Conflict Mitigation", "Mitigating Control"): CONTROL,
    ("38", "Conflict Mitigation", "Mitigating Policy"): POLICY,
    ("38", "Outside Business Activity", "OBA Employee"): EMPLOYEE,
    ("38", "Outside Business Activity", "OBA Organization"): PARTY,
    ("38", "Outside Business Activity", "OBA Related Conflict"): ("38", "Conflict of Interest"),
    # ------------------------------------------------------------------ 38 AML & Sanctions Program
    ("38", "AML Program Assessment", "Assessed Entity"): LEGAL_ENTITY,
    ("38", "AML Program Assessment", "Assessed Fund"): PRODUCT,
    ("38", "AML Program Assessment", "Designated AML Officer"): ("39", "Corporate Officer Appointment"),
    ("38", "AML Case", "Source KYC Profile"): ("02", "KYC Profile"),
    ("38", "AML Case", "Source Supplier Onboarding Case"): ("40", "Supplier Onboarding Case"),
    ("38", "AML Case", "Source Trade Surveillance Alert"): SURV_ALERT,
    ("38", "AML Case", "Case Subject Parties"): PARTY,
    ("38", "AML Case", "Case Subject Accounts"): ("15", "Account"),
    ("38", "AML and Sanctions Report", "Reported Case"): ("38", "AML Case"),
    # ------------------------------------------------------------------ 38 Market Conduct & Information Barriers
    ("38", "Firm Restricted List", "List Scope Entities"): LEGAL_ENTITY,
    ("38", "Restricted List Entry", "Entry List"): RESTRICTED_LIST,
    ("38", "Restricted List Entry", "Restricted Issuer"): PARTY,
    ("38", "Restricted List Entry", "Restricted Instruments"): INSTRUMENT,
    ("38", "Restricted List Entry", "Source MNPI Escalation"): MNPI,
    ("38", "MNPI Escalation", "Source Issuer Meeting"): ("23", "Issuer Meeting"),
    ("38", "MNPI Escalation", "Source Engagement"): ("34", "Engagement"),
    ("38", "MNPI Escalation", "MNPI Issuer"): PARTY,
    ("38", "MNPI Escalation", "MNPI Decided By"): EMPLOYEE,
    ("38", "Insider List Entry", "Insider List"): RESTRICTED_LIST,
    ("38", "Insider List Entry", "Insider Escalation"): MNPI,
    ("38", "Insider List Entry", "Internal Insider"): EMPLOYEE,
    ("38", "Insider List Entry", "External Insider"): PARTY,
    ("38", "Trade Surveillance Alert", "Subject Trade Orders"): ("25", "Trade Order"),
    ("38", "Trade Surveillance Alert", "Subject Executions"): ("25", "Execution"),
    ("38", "Trade Surveillance Alert", "Subject Personal Transactions"): ("38", "Personal Transaction"),
    ("38", "Trade Surveillance Alert", "Related Communications Alert"): ("08", "Surveillance Alert"),
    ("38", "Form CRS Filing Detail", "Form CRS Filing"): ("38", "Firm Regulatory Filing"),
    ("38", "Adviser Custody Profile", "Custody Adviser Entity"): LEGAL_ENTITY,
    ("38", "Adviser Custody Profile", "Related Person Qualified Custodians"): LEGAL_ENTITY,
    ("38", "Adviser Custody Profile", "Other Qualified Custodians"): PARTY,
    ("38", "Custody Surprise Examination", "Surprise Examined Adviser"): LEGAL_ENTITY,
    ("38", "Custody Surprise Examination", "Examining Accountant"): PARTY,
    ("38", "Custody Surprise Examination", "Form ADV-E Filing"): ("38", "Firm Regulatory Filing"),
    ("38", "Trade Surveillance Alert", "Subject Client Orders"): ("48", "Client Order"),
    ("38", "Trade Surveillance Alert", "Subject Client Executions"): ("48", "Client Execution"),
}

# Every Reference attribute of 37 and 38 targets an object in the taxonomy, so none is left out. Attributes shown as
# "->NN" in the catalog without a Reference type (Appetite Approval Date, Audit Plan Approval Status and Version Approval
# Date ->39, Impact Amount ->27, Loss Amount ->25, KRI Definition and KRI Threshold Direction ->21, Access Obtained
# Timestamp ->23) are Derived copies, not references, so they have no REFS entry.
