"""Key and link registry extension: Data Domains 39-41 (enterprise expansion, Phase 2, Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Every object of 39 Legal & Corporate Governance,
40 Procurement & Vendor Management and 41 Technology & Information Security is keyed (none of them is in keys_g9_37_44.py),
and every Reference attribute of the three domains is registered in REFS.

"One of ... is populated" means the grain names a polymorphic member (an employee or an external party, an internal
entity or an external party ...); all the alternatives are in the key and exactly one is non-null in each row.
"Model gap:" notes name single Reference attributes that point at an object keyed on several attributes, so the model
cannot carry the full foreign key from the referencing attribute alone; the taxonomy is unchanged.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
EMPLOYEE = ("20", "Employee")
CONTRACT = ("39", "Contract")
LEGAL_MATTER = ("39", "Legal Matter")
CORPORATE_BODY = ("39", "Corporate Governing Body")
SUPPLIER_ENGAGEMENT = ("40", "Supplier Engagement")
PURCHASE_ORDER = ("40", "Purchase Order")
APPLICATION = ("41", "Application")
CONFIG_ITEM = ("41", "Configuration Item")
IT_SERVICE = ("41", "IT Service")
CHANGE_REQUEST = ("41", "Change Request")

KEYS = {
    # ------------------------------------------------------------------ 39 Contracts
    ("39", "Contract"): _k(["Contract ID"], "Natural"),
    ("39", "Typed Contract Link"): _fold("A contract holds at most one typed link (Source_Notes 39), so the group is "
                                         "one row per contract."),
    ("39", "Contract Party"): _k(["Party Contract", "Contract Party Role", "External Contract Party",
                                  "Internal Contract Party", "Party Effective From"], "Composite",
                                 note="One of External Contract Party (02) or Internal Contract Party (09) is populated."),
    ("39", "Contract Signatory"): _k(["Signed Contract", "Signing Employee", "External Signatory"], "Composite",
                                     note="One of Signing Employee or External Signatory is populated."),
    ("39", "Contract Document Version"): _k(["Document Version Contract", "Document Version Number", "Document Sequence"],
                                            "Composite"),
    ("39", "Contract Key Date"): _k(["Key Date Contract", "Key Date Type", "Key Date Sequence"], "Composite"),
    ("39", "Contract Clause Position"): _k(["Clause Contract", "Clause Type"], "Composite"),
    # ------------------------------------------------------------------ 39 Legal requests and matters
    ("39", "Legal Service Request"): _k(["Legal Request Number"], "Natural",
                                        note="The request number encodes the grain's year x sequence."),
    ("39", "Legal Matter"): _k(["Legal Matter ID"], "Natural"),
    ("39", "Matter Party"): _k(["Party Matter", "Matter Party Role", "External Matter Party", "Internal Matter Entity",
                                "Employee Matter Party"], "Composite",
                               note="One of the external party, internal entity or employee is populated."),
    ("39", "Matter Event"): _k(["Event Matter", "Matter Event Sequence"], "Composite"),
    ("39", "Matter Financial Assessment"): _k(["Assessed Matter", "Assessment Reporting Entity", "Assessment Date"],
                                              "Composite"),
    ("39", "Outside Counsel Engagement"): _k(["Engagement Letter", "Engaged Matter"], "Composite",
                                             note="Engaged Matter is empty for general advisory engagements. Model gap: "
                                                  "no single ID, so Outside Counsel Invoice Review.Reviewed Engagement "
                                                  "cannot carry the full key."),
    ("39", "Outside Counsel Invoice Review"): _k(["Reviewed Engagement", "Counsel Invoice Number"], "Composite"),
    # ------------------------------------------------------------------ 39 Legal holds
    ("39", "Legal Hold"): _k(["Legal Hold ID"], "Natural"),
    ("39", "Legal Hold Custodian"): _k(["Custodian Hold", "Custodian Employee"], "Composite"),
    ("39", "Legal Hold Scope"): _k(["Scope Hold", "Hold Scope Type", "Scoped Retention Rule", "Scoped Application",
                                    "Scoped Data Asset", "Scoped Party", "Scope Date From"], "Composite",
                                   note="The grain's data source is whichever of the four Scoped references the scope "
                                        "type uses; the date range is keyed on its start."),
    # ------------------------------------------------------------------ 39 Corporate governance
    ("39", "Corporate Governing Body"): _k(["Corporate Body ID"], "Natural",
                                           note="Model gap: Body Constitution Document is a single reference to the "
                                                "composite-keyed Contract Document Version."),
    ("39", "Corporate Body Membership"): _k(["Membership Body", "Member Employee", "Member External Party",
                                             "Corporate Member Role", "Membership Effective From"], "Composite",
                                            note="One of Member Employee or Member External Party is populated."),
    ("39", "Corporate Officer Appointment"): _k(["Officer Entity", "Corporate Officer Role", "Officer Employee",
                                                 "Officer Effective From"], "Composite"),
    ("39", "Corporate Board Meeting"): _k(["Meeting Body", "Corporate Meeting Date", "Corporate Meeting Sequence"],
                                          "Composite",
                                          note="Model gap: no single ID, so Corporate Resolution.Adopting Corporate "
                                               "Meeting cannot carry the full key."),
    ("39", "Corporate Resolution"): _k(["Corporate Resolution ID"], "Natural"),
    ("39", "Corporate Resolution Subject Link"): _k(["Corporate Resolution Subject Link Key"], "Surrogate",
                                                    note="The approved subject is one of twelve typed references "
                                                         "chosen by the subject type; a surrogate keeps the key narrow. "
                                                         "The natural key is resolution x subject type x the populated "
                                                         "subject reference."),
    ("39", "Entity Statutory Filing"): _k(["Filing Entity", "Statutory Filing Type", "Filing Period End"], "Composite"),
    ("39", "Power of Attorney"): _k(["Power of Attorney ID"], "Natural"),
    ("39", "Signing Authority Grant"): _k(["Authorized Employee", "Authority Type", "Authority Entity",
                                           "Grant Effective From"], "Composite",
                                          note="Model gap: no single ID, so Contract Signatory.Relied-On Authority Grant "
                                               "and Corporate Resolution Subject Link.Subject Authority Grant cannot "
                                               "carry the full key."),
    # ------------------------------------------------------------------ 39 Trademarks
    ("39", "Trademark Registration"): _k(["Trademark Registration ID"], "Natural"),
    ("39", "Trademark Docket Deadline"): _k(["Docket Registration", "Docket Deadline Type", "Docket Due Date"],
                                            "Composite"),
    ("39", "Trademark License Grant"): _k(["Licensed Registration", "Licensee Entity", "Licensee Party",
                                           "License Effective From"], "Composite",
                                          note="One of Licensee Entity (internal) or Licensee Party (external) is "
                                               "populated."),

    # ------------------------------------------------------------------ 40 Supplier master and onboarding
    ("40", "Supplier Profile"): _k(["Supplier Party"], "Composite",
                                   note="A role of Party (1:1); the key is the Party ID, as for 14 Data Vendor. "
                                        "ERP Supplier Number is an alternate key."),
    ("40", "Supplier Remittance Detail"): _child(["Remittance Sequence", "Remittance Effective From"],
                                                 "Repeats per remittance account and effective period within the "
                                                 "supplier; Remittance Supplier repeats the parent key."),
    ("40", "Supplier Onboarding Case"): _k(["Onboarding Supplier", "Onboarding Sequence"], "Composite"),
    # ------------------------------------------------------------------ 40 Engagements and categories
    ("40", "Supplier Engagement"): _k(["Supplier Engagement ID"], "Natural"),
    ("40", "Supplier Category Assignment"): _k(["Categorized Engagement", "Procurement Category",
                                                "Category Effective From"], "Composite"),
    ("40", "Supplier Risk Tiering"): _k(["Tiered Engagement", "Tier Effective From"], "Composite"),
    ("40", "Supplier Performance Review"): _k(["Reviewed Engagement", "Review Period End"], "Composite"),
    # ------------------------------------------------------------------ 40 Sourcing
    ("40", "Sourcing Event"): _k(["Sourcing Event ID"], "Natural"),
    ("40", "Sourcing Invitation"): _k(["Invitation Sourcing Event", "Invited Supplier"], "Composite"),
    ("40", "Sourcing Award"): _k(["Award Sourcing Event", "Awarded Supplier"], "Composite"),
    # ------------------------------------------------------------------ 40 Purchase to pay
    ("40", "Purchase Requisition"): _k(["Purchase Requisition ID"], "Natural"),
    ("40", "Purchase Order"): _k(["Purchase Order ID"], "Natural"),
    ("40", "Purchase Order Line"): _k(["Line Purchase Order", "PO Line Number"], "Composite"),
    ("40", "Goods and Service Receipt"): _k(["Receipt Purchase Order", "Receipt PO Line Number", "Receipt Sequence"],
                                            "Composite"),
    ("40", "Invoice Match Result"): _k(["Matched Payable Invoice", "Matched Invoice Line Number",
                                        "Matched Purchase Order", "Matched PO Line Number"], "Composite",
                                       note="Latest match run only; the invoice line is the 19 Payable Invoice x line "
                                            "number."),
    ("40", "Supplier Spend Summary"): _k(["Spend Supplier", "Spend Legal Entity", "Spend Fiscal Period"], "Composite"),
    # ------------------------------------------------------------------ 40 Supplier contracts and service levels
    ("40", "Supplier Contract Profile"): _k(["Profiled Contract"], "Composite",
                                            note="One profile per 39 Contract (1:1 extension); the key is the "
                                                 "Contract ID."),
    ("40", "Contracted Service Level"): _k(["Service Level Contract", "Service Level Metric Name",
                                            "Service Level Effective From"], "Composite"),
    ("40", "Service Level Measurement Result"): _k(["Measured Contract", "Measured Metric Name",
                                                    "Measured Service Level Effective From", "Measurement Period End"],
                                                   "Composite",
                                                   note="The first three attributes carry the Contracted Service Level "
                                                        "key."),
    # ------------------------------------------------------------------ 40 Outsourcing
    ("40", "Outsourcing Arrangement"): _k(["Outsourcing Arrangement ID"], "Natural"),
    ("40", "Exit Plan"): _fold("One exit plan per outsourcing arrangement."),
    # Outsourcing Notification, ICT Register Arrangement Header, ICT Register of Information Entry and Supply Chain
    # Subcontractor removed (EBA outsourcing notification and the DORA register of information; CW-940).

    # ------------------------------------------------------------------ 41 Application portfolio
    ("41", "Application"): _k(["Application ID"], "Natural"),
    ("41", "Application Recovery Profile"): _fold(),
    ("41", "AI System Profile"): _fold("Populated only for applications that are AI systems; one row per application."),
    ("41", "Application Ownership Assignment"): _k(["Owned Application", "Application Ownership Role",
                                                    "Application Role Holder", "Ownership Effective From"], "Composite"),
    ("41", "Application Capability Mapping"): _k(["Mapped Application", "Supported Business Capability",
                                                  "Capability Mapping Effective From"], "Composite"),
    ("41", "Application Lifecycle Assessment"): _k(["Assessed Application", "Lifecycle Assessment Date"], "Composite"),
    ("41", "Application Interface"): _k(["Source Application", "Target Application", "External Endpoint Party",
                                         "Interface Code"], "Composite",
                                        note="The grain scopes the interface code within source x target; one of Target "
                                             "Application or External Endpoint Party is populated."),
    ("41", "AI System Use Case Link"): _k(["Linked AI System", "Served AI Use Case", "Use Case Link Effective From"],
                                          "Composite"),
    ("41", "AI System Model Deployment"): _k(["Model Deploying AI System", "Deployed Model",
                                              "Model Deployment Effective From"], "Composite"),
    ("41", "Software License Position"): _k(["Licensed Application", "Licensing Metric", "License Measurement Date"],
                                            "Composite"),
    # ------------------------------------------------------------------ 41 Configuration and IT assets
    ("41", "Configuration Item"): _k(["Configuration Item ID"], "Natural"),
    ("41", "Configuration Item Relationship"): _k(["Parent Configuration Item", "Child Configuration Item",
                                                   "CI Relationship Type", "CI Relationship Effective From"],
                                                  "Composite"),
    ("41", "IT Asset Assignment"): _k(["Assigned Configuration Item", "Device Assignee", "Assigned Date"], "Composite",
                                      note="The assignment period is keyed on its start."),
    # ------------------------------------------------------------------ 41 Identity and access
    ("41", "Digital Identity"): _k(["Digital Identity ID"], "Natural"),
    ("41", "Application Access Role"): _k(["Role Application", "Access Role Code"], "Composite",
                                          note="Role codes are unique only within an application. Model gap: System "
                                               "Access Grant.Granted Access Role is a single reference to this "
                                               "two-part key."),
    ("41", "System Access Grant"): _k(["System Access Grant ID"], "Natural"),
    ("41", "Access Review Campaign"): _k(["Access Review Campaign Code"], "Natural"),
    ("41", "Access Review Decision"): _k(["Decision Campaign", "Reviewed Grant"], "Composite"),
    # ------------------------------------------------------------------ 41 IT service management
    ("41", "IT Service"): _k(["IT Service Code"], "Natural"),
    ("41", "IT Incident"): _k(["IT Incident ID"], "Natural"),
    ("41", "Security Incident Detail"): _fold("Populated only for incidents of class Security Event; one row per "
                                              "incident."),
    ("41", "Information Security Program"): _k(["Security Program Code"], "Natural",
                                               note="W1b addition (CW-941): one row per written program (Regulation "
                                                    "S-P, Regulation S-ID, NIST CSF, Regulation SCI)."),
    ("41", "Problem Record"): _k(["Problem Code"], "Natural"),
    ("41", "Change Request"): _k(["Change Request ID"], "Natural"),
    ("41", "Change Approval"): _k(["Approved Change", "Change Approval Step"], "Composite"),
    ("41", "Release"): _k(["Release ID"], "Natural", note="RLSE- identifies the release on its own; the application is "
                                                          "an attribute."),
    ("41", "Release Deployment"): _k(["Deployed Release", "Deployment Environment", "Deployment Timestamp"],
                                     "Composite"),
    # ------------------------------------------------------------------ 41 Change programs and projects
    ("41", "Change Program"): _k(["Change Program Code"], "Natural"),
    ("41", "Project"): _k(["Project ID"], "Natural"),
    ("41", "Project Milestone"): _k(["Milestone Project", "Milestone Name"], "Composite"),
    ("41", "Project Status Report"): _k(["Reported Project", "Status Reporting Date"], "Composite"),
    ("41", "Project Scope Link"): _k(["Scoping Project", "Delivered Object Type", "Delivered Change Initiative",
                                      "Delivered Data Product", "Delivered Data Quality Issue", "Delivered Application",
                                      "Delivered Regulatory Change Item", "Scope Link Effective From"], "Composite",
                                     note="The delivered object is whichever of the five Delivered references the object "
                                          "type uses."),
    # ------------------------------------------------------------------ 41 Security testing and vulnerabilities
    ("41", "Security & Resilience Test"): _k(["Test Code"], "Natural"),
    ("41", "Vulnerability Finding"): _k(["Vulnerability Finding ID"], "Natural"),
}

REFS = {
    # ------------------------------------------------------------------ 39
    ("39", "Contract", "Parent Contract"): CONTRACT,
    ("39", "Contract", "Contracting Entity"): LEGAL_ENTITY,
    ("39", "Contract", "Contracting Product"): ("01", "Investment Product"),
    ("39", "Contract", "Related Corporate Bank Account"): ("43", "Corporate Bank Account"),
    ("39", "Contract", "Legal Owner"): EMPLOYEE,
    ("39", "Typed Contract Link", "Linked Distribution Agreement"): ("05", "Distribution Agreement"),
    ("39", "Typed Contract Link", "Linked Agreement Amendment"): ("05", "Agreement Amendment"),
    ("39", "Typed Contract Link", "Linked Data License Agreement"): ("14", "Data License Agreement"),
    ("39", "Typed Contract Link", "Linked Trading Agreement"): ("26", "Trading Agreement"),
    ("39", "Typed Contract Link", "Linked Fund Advisory Agreement"): ("35", "Fund Advisory Agreement"),
    ("39", "Typed Contract Link", "Linked Securities Lending Agreement"): ("28", "Securities Lending Agreement"),
    ("39", "Typed Contract Link", "Linked Intercompany Agreement"): ("10", "Intercompany Agreement"),
    ("39", "Typed Contract Link", "Linked Service Arrangement"): ("16", "Service Arrangement"),
    ("39", "Typed Contract Link", "Linked Investment Mandate"): ("01", "Investment Mandate"),
    ("39", "Typed Contract Link", "Linked Debt Facility"): ("43", "Debt Facility"),
    ("39", "Typed Contract Link", "Linked Insurance Policy"): ("43", "Corporate Insurance Policy"),
    ("39", "Contract Party", "Party Contract"): CONTRACT,
    ("39", "Contract Party", "External Contract Party"): PARTY,
    ("39", "Contract Party", "Internal Contract Party"): LEGAL_ENTITY,
    ("39", "Contract Party", "Notice Contact Point"): ("02", "Contact Point"),  # CTP- (CW-021)
    ("39", "Contract Signatory", "Signed Contract"): CONTRACT,
    ("39", "Contract Signatory", "Signing Employee"): EMPLOYEE,
    ("39", "Contract Signatory", "External Signatory"): PARTY,
    ("39", "Contract Signatory", "Relied-On Power of Attorney"): ("39", "Power of Attorney"),
    ("39", "Contract Signatory", "Relied-On Authority Grant"): ("39", "Signing Authority Grant"),
    ("39", "Contract Document Version", "Document Version Contract"): CONTRACT,
    ("39", "Contract Key Date", "Key Date Contract"): CONTRACT,
    ("39", "Contract Clause Position", "Clause Contract"): CONTRACT,
    ("39", "Legal Service Request", "Requesting Employee"): EMPLOYEE,
    ("39", "Legal Service Request", "Assigned Lawyer"): EMPLOYEE,
    ("39", "Legal Service Request", "Resulting Contract"): CONTRACT,
    ("39", "Legal Matter", "Originating Examination"): ("38", "Regulatory Examination"),
    ("39", "Legal Matter", "Responsible Lawyer"): EMPLOYEE,
    ("39", "Matter Party", "Party Matter"): LEGAL_MATTER,
    ("39", "Matter Party", "External Matter Party"): PARTY,
    ("39", "Matter Party", "Internal Matter Entity"): LEGAL_ENTITY,
    ("39", "Matter Party", "Employee Matter Party"): EMPLOYEE,
    ("39", "Matter Event", "Event Matter"): LEGAL_MATTER,
    ("39", "Matter Financial Assessment", "Assessed Matter"): LEGAL_MATTER,
    ("39", "Matter Financial Assessment", "Assessment Reporting Entity"): LEGAL_ENTITY,
    ("39", "Matter Financial Assessment", "Reserve Journal Entry"): ("19", "Journal Entry"),
    ("39", "Outside Counsel Engagement", "Engaged Matter"): LEGAL_MATTER,
    ("39", "Outside Counsel Engagement", "Outside Counsel Firm"): PARTY,
    ("39", "Outside Counsel Engagement", "Engagement Letter"): CONTRACT,
    ("39", "Outside Counsel Invoice Review", "Reviewed Engagement"): ("39", "Outside Counsel Engagement"),
    ("39", "Outside Counsel Invoice Review", "Payable Invoice"): ("19", "Payable Invoice"),
    ("39", "Legal Hold", "Hold Matter"): LEGAL_MATTER,
    ("39", "Legal Hold", "Hold Examination"): ("38", "Regulatory Examination"),
    ("39", "Legal Hold", "Issuing Lawyer"): EMPLOYEE,
    ("39", "Legal Hold Custodian", "Custodian Hold"): ("39", "Legal Hold"),
    ("39", "Legal Hold Custodian", "Custodian Employee"): EMPLOYEE,
    ("39", "Legal Hold Scope", "Scope Hold"): ("39", "Legal Hold"),
    ("39", "Legal Hold Scope", "Scoped Retention Rule"): ("21", "Retention Rule"),
    ("39", "Legal Hold Scope", "Scoped Application"): APPLICATION,
    ("39", "Legal Hold Scope", "Scoped Data Asset"): ("21", "Data Asset"),
    ("39", "Legal Hold Scope", "Scoped Party"): PARTY,
    ("39", "Corporate Governing Body", "Governed Entity"): LEGAL_ENTITY,
    ("39", "Corporate Governing Body", "Parent Corporate Body"): CORPORATE_BODY,
    ("39", "Corporate Governing Body", "Body Constitution Document"): ("39", "Contract Document Version"),
    ("39", "Corporate Body Membership", "Membership Body"): CORPORATE_BODY,
    ("39", "Corporate Body Membership", "Member Employee"): EMPLOYEE,
    ("39", "Corporate Body Membership", "Member External Party"): PARTY,
    ("39", "Corporate Officer Appointment", "Officer Entity"): LEGAL_ENTITY,
    ("39", "Corporate Officer Appointment", "Officer Employee"): EMPLOYEE,
    ("39", "Corporate Officer Appointment", "Regulatory Notification Filing"): ("38", "Firm Regulatory Filing"),
    ("39", "Corporate Board Meeting", "Meeting Body"): CORPORATE_BODY,
    ("39", "Corporate Resolution", "Adopting Corporate Meeting"): ("39", "Corporate Board Meeting"),
    ("39", "Corporate Resolution", "Superseded Corporate Resolution"): ("39", "Corporate Resolution"),
    ("39", "Corporate Resolution Subject Link", "Linked Corporate Resolution"): ("39", "Corporate Resolution"),
    ("39", "Corporate Resolution Subject Link", "Subject Contract"): CONTRACT,
    ("39", "Corporate Resolution Subject Link", "Subject Body Membership"): ("39", "Corporate Body Membership"),
    ("39", "Corporate Resolution Subject Link", "Subject Officer Appointment"): ("39", "Corporate Officer Appointment"),
    ("39", "Corporate Resolution Subject Link", "Subject Power of Attorney"): ("39", "Power of Attorney"),
    ("39", "Corporate Resolution Subject Link", "Subject Authority Grant"): ("39", "Signing Authority Grant"),
    ("39", "Corporate Resolution Subject Link", "Subject Risk Appetite Statement"): ("37", "Risk Appetite Statement"),
    ("39", "Corporate Resolution Subject Link", "Subject Audit Plan"): ("37", "Audit Plan"),
    ("39", "Corporate Resolution Subject Link", "Subject Policy Version"): ("38", "Policy Version"),
    ("39", "Corporate Resolution Subject Link", "Subject Debt Facility"): ("43", "Debt Facility"),
    ("39", "Corporate Resolution Subject Link", "Subject Capital Transaction"): ("43", "Intra-Group Capital Transaction"),
    # Corporate Resolution Subject Link.Subject ICARA Assessment removed with 43 ICARA Assessment (CW-939, CW-943).
    ("39", "Corporate Resolution Subject Link", "Subject Corporate Publication"): ("42", "Corporate Publication"),
    ("39", "Entity Statutory Filing", "Filing Entity"): LEGAL_ENTITY,
    ("39", "Power of Attorney", "Grantor Entity"): LEGAL_ENTITY,
    ("39", "Power of Attorney", "Attorney Employee"): EMPLOYEE,
    ("39", "Power of Attorney", "Attorney Party"): PARTY,
    ("39", "Signing Authority Grant", "Authorized Employee"): EMPLOYEE,
    ("39", "Signing Authority Grant", "Authority Entity"): LEGAL_ENTITY,
    ("39", "Trademark Registration", "Trademark Owner Entity"): LEGAL_ENTITY,
    ("39", "Trademark Registration", "Protected Brand"): ("42", "Brand"),
    ("39", "Trademark Docket Deadline", "Docket Registration"): ("39", "Trademark Registration"),
    ("39", "Trademark License Grant", "Licensed Registration"): ("39", "Trademark Registration"),
    ("39", "Trademark License Grant", "Licensee Entity"): LEGAL_ENTITY,
    ("39", "Trademark License Grant", "Licensee Party"): PARTY,
    ("39", "Trademark License Grant", "Licensing Contract"): CONTRACT,
    # ------------------------------------------------------------------ 40
    ("40", "Supplier Profile", "Supplier Party"): PARTY,
    ("40", "Supplier Profile", "Supplier Relationship Manager"): EMPLOYEE,
    ("40", "Supplier Remittance Detail", "Remittance Supplier"): PARTY,
    ("40", "Supplier Onboarding Case", "Onboarding Supplier"): PARTY,
    ("40", "Supplier Engagement", "Engaged Supplier"): PARTY,
    ("40", "Supplier Engagement", "Engagement Business Owner"): EMPLOYEE,
    ("40", "Supplier Engagement", "Requesting Org Unit"): ("09", "Org Unit"),
    ("40", "Supplier Engagement", "Engagement Buying Entity"): LEGAL_ENTITY,
    ("40", "Supplier Engagement", "Specialized Data Vendor"): ("14", "Data Vendor"),
    ("40", "Supplier Engagement", "Specialized Servicing Provider Engagement"): ("29", "Servicing Provider Engagement"),
    ("40", "Supplier Engagement", "Specialized Custody Provider Profile"): ("28", "Custody Provider Profile"),
    ("40", "Supplier Engagement", "Fund Service Provider Role"): ("01", "Product Party Role"),
    ("40", "Supplier Engagement", "Shared Data Assets"): ("21", "Data Asset"),
    ("40", "Supplier Category Assignment", "Categorized Engagement"): SUPPLIER_ENGAGEMENT,
    ("40", "Sourcing Event", "Sourcing Owner"): EMPLOYEE,
    ("40", "Sourcing Event", "Originating Requisition"): ("40", "Purchase Requisition"),
    ("40", "Sourcing Invitation", "Invitation Sourcing Event"): ("40", "Sourcing Event"),
    ("40", "Sourcing Invitation", "Invited Supplier"): PARTY,
    ("40", "Sourcing Award", "Award Sourcing Event"): ("40", "Sourcing Event"),
    ("40", "Sourcing Award", "Awarded Supplier"): PARTY,
    ("40", "Sourcing Award", "Resulting Supplier Engagement"): SUPPLIER_ENGAGEMENT,
    ("40", "Sourcing Award", "Resulting Contract"): CONTRACT,
    ("40", "Purchase Requisition", "Requester"): EMPLOYEE,
    ("40", "Purchase Requisition", "Requisition Cost Center"): ("19", "Chart Segment Value"),
    ("40", "Purchase Order", "Ordered Supplier"): PARTY,
    ("40", "Purchase Order", "Ordering Legal Entity"): LEGAL_ENTITY,
    ("40", "Purchase Order", "Ordered Engagement"): SUPPLIER_ENGAGEMENT,
    ("40", "Purchase Order", "Governing Contract"): CONTRACT,
    ("40", "Purchase Order Line", "Line Purchase Order"): PURCHASE_ORDER,
    ("40", "Purchase Order Line", "Line GL Account"): ("19", "GL Account"),
    ("40", "Purchase Order Line", "Line Cost Center"): ("19", "Chart Segment Value"),
    ("40", "Purchase Order Line", "Source Requisition"): ("40", "Purchase Requisition"),
    ("40", "Purchase Order Line", "Contingent Workers"): EMPLOYEE,
    ("40", "Goods and Service Receipt", "Receipt Purchase Order"): PURCHASE_ORDER,
    ("40", "Goods and Service Receipt", "Receiver"): EMPLOYEE,
    ("40", "Invoice Match Result", "Matched Payable Invoice"): ("19", "Payable Invoice"),
    ("40", "Invoice Match Result", "Matched Purchase Order"): PURCHASE_ORDER,
    ("40", "Supplier Contract Profile", "Profiled Contract"): CONTRACT,
    ("40", "Supplier Contract Profile", "Contracted Engagements"): SUPPLIER_ENGAGEMENT,
    ("40", "Contracted Service Level", "Service Level Contract"): CONTRACT,
    ("40", "Supplier Performance Review", "Reviewed Engagement"): SUPPLIER_ENGAGEMENT,
    ("40", "Service Level Measurement Result", "Measured Contract"): CONTRACT,
    ("40", "Supplier Spend Summary", "Spend Supplier"): PARTY,
    ("40", "Supplier Spend Summary", "Spend Legal Entity"): LEGAL_ENTITY,
    ("40", "Supplier Spend Summary", "Spend Fiscal Period"): ("09", "Fiscal Period"),
    ("40", "Supplier Risk Tiering", "Tiered Engagement"): SUPPLIER_ENGAGEMENT,
    ("40", "Outsourcing Arrangement", "Outsourcing Engagement"): SUPPLIER_ENGAGEMENT,
    ("40", "Outsourcing Arrangement", "Outsourcing Entity"): LEGAL_ENTITY,
    ("40", "Outsourcing Arrangement", "Supported Critical or Important Functions"): ("37", "Critical or Important Function"),
    # Outsourcing Arrangement.Supported Important Business Services removed with 37 Important Business Service (CW-937, CW-940).
    ("40", "Outsourcing Arrangement", "Outsourcing Contract"): CONTRACT,
    ("40", "Outsourcing Arrangement", "Related Plan Service Arrangement"): ("16", "Service Arrangement"),
    ("40", "Exit Plan", "Alternative Providers"): PARTY,
    # References of the four removed outsourcing notification and DORA register objects removed with them (CW-940).
    # ------------------------------------------------------------------ 41
    ("41", "Application", "Software Vendor"): PARTY,
    ("41", "Application", "Owning Org Unit"): ("09", "Org Unit"),
    ("41", "Application", "Owning Legal Entity"): LEGAL_ENTITY,
    ("41", "Application Ownership Assignment", "Owned Application"): APPLICATION,
    ("41", "Application Ownership Assignment", "Application Role Holder"): EMPLOYEE,
    ("41", "Application Capability Mapping", "Mapped Application"): APPLICATION,
    ("41", "Application Lifecycle Assessment", "Assessed Application"): APPLICATION,
    ("41", "Application Lifecycle Assessment", "Successor Application"): APPLICATION,
    ("41", "Application Interface", "Source Application"): APPLICATION,
    ("41", "Application Interface", "Target Application"): APPLICATION,
    ("41", "Application Interface", "External Endpoint Party"): PARTY,
    ("41", "Application Interface", "Carried Data Feed"): ("06", "Data Feed"),
    ("41", "AI System Profile", "AI System Provider"): PARTY,
    ("41", "AI System Profile", "Human Oversight Assignee"): EMPLOYEE,
    ("41", "AI System Use Case Link", "Linked AI System"): APPLICATION,
    ("41", "AI System Use Case Link", "Served AI Use Case"): ("21", "AI Use Case"),
    ("41", "AI System Model Deployment", "Model Deploying AI System"): APPLICATION,
    ("41", "AI System Model Deployment", "Deployed Model"): ("37", "Model Inventory Entry"),
    ("41", "Configuration Item", "Instantiated Application"): APPLICATION,
    ("41", "Configuration Item", "Hosting Site"): ("09", "Office Location"),
    ("41", "Configuration Item Relationship", "Parent Configuration Item"): CONFIG_ITEM,
    ("41", "Configuration Item Relationship", "Child Configuration Item"): CONFIG_ITEM,
    ("41", "IT Asset Assignment", "Assigned Configuration Item"): CONFIG_ITEM,
    ("41", "IT Asset Assignment", "Device Assignee"): EMPLOYEE,
    ("41", "Software License Position", "Licensed Application"): APPLICATION,
    ("41", "Software License Position", "Governing Software Contract"): CONTRACT,
    ("41", "Digital Identity", "Identity Owner Employee"): EMPLOYEE,
    ("41", "Digital Identity", "Identity Owner Party"): PARTY,
    ("41", "Digital Identity", "Service Account Sponsor"): EMPLOYEE,
    ("41", "Application Access Role", "Role Application"): APPLICATION,
    ("41", "System Access Grant", "Grantee Identity"): ("41", "Digital Identity"),
    ("41", "System Access Grant", "Granted Access Role"): ("41", "Application Access Role"),
    ("41", "System Access Grant", "Access Approver"): EMPLOYEE,
    ("41", "System Access Grant", "Granting Lifecycle Event"): ("20", "Employee Lifecycle Event"),
    ("41", "System Access Grant", "Revoking Lifecycle Event"): ("20", "Employee Lifecycle Event"),
    ("41", "System Access Grant", "Provisioned Data Entitlement"): ("14", "Entitlement"),
    ("41", "Access Review Campaign", "Reviewed Application"): APPLICATION,
    ("41", "Access Review Campaign", "Governing Access Policy"): ("38", "Policy"),
    ("41", "Access Review Decision", "Decision Campaign"): ("41", "Access Review Campaign"),
    ("41", "Access Review Decision", "Reviewed Grant"): ("41", "System Access Grant"),
    ("41", "Access Review Decision", "Access Reviewer"): EMPLOYEE,
    ("41", "IT Service", "Supporting Applications"): APPLICATION,
    ("41", "IT Service", "IT Service Owner"): EMPLOYEE,
    ("41", "IT Service", "Third-Party Service Provider"): PARTY,
    ("41", "IT Incident", "Affected IT Services"): IT_SERVICE,
    ("41", "IT Incident", "Affected Applications"): APPLICATION,
    ("41", "IT Incident", "Affected Configuration Items"): CONFIG_ITEM,
    ("41", "IT Incident", "Affected Legal Entities"): LEGAL_ENTITY,
    ("41", "IT Incident", "Causing Change"): CHANGE_REQUEST,
    ("41", "IT Incident", "Incident Manager"): EMPLOYEE,
    ("41", "Security Incident Detail", "Notifying Service Provider"): PARTY,
    ("41", "Security Incident Detail", "Governing Response Program"): ("41", "Information Security Program"),
    ("41", "Information Security Program", "Covered Legal Entities"): LEGAL_ENTITY,
    ("41", "Information Security Program", "Program Policy"): ("38", "Policy"),
    ("41", "Information Security Program", "Program Owner"): EMPLOYEE,
    ("41", "Problem Record", "Linked IT Incidents"): ("41", "IT Incident"),
    ("41", "Problem Record", "Resolving Change"): CHANGE_REQUEST,
    ("41", "Problem Record", "Problem Owner"): EMPLOYEE,
    ("41", "Change Request", "Changed Applications"): APPLICATION,
    ("41", "Change Request", "Changed Configuration Items"): CONFIG_ITEM,
    ("41", "Change Request", "Change Freeze Calendar"): ("09", "Calendar"),
    ("41", "Change Request", "Implemented Release"): ("41", "Release"),
    ("41", "Change Request", "Change Requester"): EMPLOYEE,
    ("41", "Change Approval", "Approved Change"): CHANGE_REQUEST,
    ("41", "Change Approval", "Change Approver"): EMPLOYEE,
    ("41", "Release", "Released Application"): APPLICATION,
    ("41", "Release Deployment", "Deployed Release"): ("41", "Release"),
    ("41", "Release Deployment", "Deployed By"): EMPLOYEE,
    ("41", "Change Program", "Program Sponsor"): EMPLOYEE,
    ("41", "Project", "Parent Change Program"): ("41", "Change Program"),
    ("41", "Project", "Project Sponsor"): EMPLOYEE,
    ("41", "Project", "Project Manager"): EMPLOYEE,
    ("41", "Project", "Budget Plan Version"): ("19", "Financial Plan Version"),
    ("41", "Project Milestone", "Milestone Project"): ("41", "Project"),
    ("41", "Project Status Report", "Reported Project"): ("41", "Project"),
    ("41", "Project Scope Link", "Scoping Project"): ("41", "Project"),
    ("41", "Project Scope Link", "Delivered Change Initiative"): ("36", "Product Change Initiative"),
    ("41", "Project Scope Link", "Delivered Data Product"): ("21", "Data Product"),
    ("41", "Project Scope Link", "Delivered Data Quality Issue"): ("21", "Data Quality Issue"),
    ("41", "Project Scope Link", "Delivered Application"): APPLICATION,
    ("41", "Project Scope Link", "Delivered Regulatory Change Item"): ("38", "Regulatory Change Item"),
    ("41", "Security & Resilience Test", "Tested Applications"): APPLICATION,
    ("41", "Security & Resilience Test", "Tested IT Services"): IT_SERVICE,
    ("41", "Security & Resilience Test", "Tested Configuration Items"): CONFIG_ITEM,
    ("41", "Security & Resilience Test", "Tested Financial Entity"): LEGAL_ENTITY,
    ("41", "Security & Resilience Test", "External Tester"): PARTY,
    ("41", "Vulnerability Finding", "Vulnerable Configuration Item"): CONFIG_ITEM,
    ("41", "Vulnerability Finding", "Vulnerable Application"): APPLICATION,
    ("41", "Vulnerability Finding", "Source Test"): ("41", "Security & Resilience Test"),
    ("41", "Vulnerability Finding", "Governing Vulnerability Policy"): ("38", "Policy"),
}

# Mapping notes for REFS:
# - "Reference (Legal Entity)" (09) resolves to 09 Internal Legal Entity; "Reference (Agreement)" (05) to 05 Distribution
#   Agreement; "Reference (Mandate)" (01) to 01 Investment Mandate; "Reference (Contact Point)" (02) to 02 Contact Point
#   (CTP-, the W1 re-cut contact point object).
# - Multi-valued references (... (multi)) point at the same target; models resolve them through a bridge.
# No Reference attribute of 39, 40 or 41 targets an object outside the taxonomy.
