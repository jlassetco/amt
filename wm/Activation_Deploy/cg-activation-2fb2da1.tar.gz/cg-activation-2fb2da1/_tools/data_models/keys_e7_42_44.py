"""Key and link registry extension: Data Domains 42-44 (enterprise expansion, Phase 2 Wave E7).

Same format and conventions as keys.py (see CONTRACT.md section 1). Keys every object of 42 Corporate Communications &
Public Affairs, 43 Corporate Treasury & Capital and 44 Workplace & Corporate Services except 42 Brand (keys_g9_37_44.py,
which also registers Brand.Parent Brand), and every Reference attribute of the three domains. Every reference target is
in the taxonomy, so none is left out.

Key choices follow the Source_Notes "design decisions": 44 sites are the 09 Office Location (SITE-) key (CD-279 rule 1);
43 bank statements, cash positions and coverage layers are keyed exactly as the 43 notes state; drawdowns and seed
movements carry a firm reference unique within their parent, so the parent is part of the key. Where a single Reference
attribute points at an object keyed on several attributes, the note says "Model gap:" (the reference carries the
composite key as one value); the taxonomy is not changed here.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
SITE = ("09", "Office Location")
UOM = ("09", "Unit of Measure")
EMPLOYEE = ("20", "Employee")
PRODUCT = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
ACCOUNT = ("15", "Account")
JOURNAL = ("19", "Journal Entry")

KEYS = {
    # ------------------------------------------------------------------ 42 Brand Governance (Brand is in keys_g9_37_44)
    ("42", "Brand Standard Version"): _k(["Standard Brand", "Standard Version Number"], "Composite"),
    ("42", "Brand Use Authorization"): _k(["Authorized Brand", "Licensee Entity", "Licensee Party", "Brand Use Effective From"],
                                         "Composite",
                                         note="The licensee is either an internal legal entity or a party; exactly one of "
                                              "the two is populated."),
    ("42", "Reputation Measurement"): _k(["Measured Brand", "Reputation Measure", "Measurement Provider",
                                          "Measurement Stakeholder Group", "Measurement Period Start",
                                          "Measurement Period End"], "Composite"),
    # ------------------------------------------------------------------ 42 Media Relations
    ("42", "Media Contact Profile"): _k(["Media Party", "Media Profile Effective From"], "Composite",
                                        note="Keyed by the 02 PTY- of the journalist or outlet, following the 17 Issuer "
                                             "Profile pattern (42 notes, decision 8)."),
    ("42", "Media Inquiry"): _k(["Media Inquiry ID"], "Natural"),
    ("42", "Press Release"): _k(["Press Release ID"], "Natural"),
    ("42", "Media Coverage Item"): _k(["Coverage Item ID"], "Natural"),
    ("42", "Spokesperson Authorization"): _k(["Spokesperson", "Spokesperson Effective From"], "Composite"),
    # ------------------------------------------------------------------ 42 Corporate Publications
    ("42", "Corporate Publication"): _k(["Corporate Publication ID"], "Natural",
                                        note="The ID encodes type x publishing entity x period end x version, so one ID "
                                             "identifies one publication version."),
    ("42", "Publication Source Link"): _k(["Linked Publication", "Source Human Capital Metric Value",
                                           "Source Capital Requirement Calculation", "Source Operational Emission Record",
                                           "Other Source Record Key"], "Composite",
                                          note="Exactly one source column is populated per row (one typed reference per "
                                               "source master, or the Other Source Record Key). Model gap: Source "
                                               "Operational Emission Record points at a 44 object keyed on six attributes "
                                               "and carries its key as one value (proposals_44 KEY_FORMATS)."),
    # ------------------------------------------------------------------ 42 Internal Communications
    ("42", "Internal Communication"): _k(["Internal Communication ID"], "Natural"),
    ("42", "Internal Communication Audience"): _k(["Audience Communication", "Audience Segment Type", "Audience Org Unit",
                                                   "Audience Office", "Audience Legal Entity", "Audience Job Profile"],
                                                  "Composite",
                                                  note="The audience segment is its type plus the one org unit, office, "
                                                       "legal entity or job profile that the type uses (blank for "
                                                       "firm-wide segments)."),
    ("42", "Internal Communication Engagement"): _k(["Engagement Communication", "Engagement Channel",
                                                     "Engagement Measurement Date"], "Composite"),
    # ------------------------------------------------------------------ 42 Issues & Crisis Communications
    ("42", "Communications Issue"): _k(["Communications Issue ID"], "Natural"),
    ("42", "Issue Statement"): _k(["Statement Issue", "Statement Type", "Statement Audience", "Statement Version"],
                                  "Composite"),
    ("42", "Crisis Communication Plan"): _k(["Crisis Plan Code", "Crisis Plan Version"], "Composite",
                                            note="Model gap: Communications Issue.Activated Crisis Plan is one attribute "
                                                 "and carries the plan code and version as one value."),
    # ------------------------------------------------------------------ 42 Government Relations & Public Policy
    ("42", "Public Policy Position"): _k(["Policy Position ID", "Policy Position Version"], "Composite",
                                         note="The PUBP- ID is stable across versions. Model gap: Consultation "
                                              "Response.Response Position and Government Official Contact.Discussed "
                                              "Position are single attributes and carry ID and version as one value."),
    ("42", "Consultation Response"): _k(["Consultation Reference", "Responding Entity"], "Composite",
                                        note="No separate consultation object (42 notes); the consultation is identified "
                                             "by the reference the consulting body publishes."),
    ("42", "Government Official Contact"): _k(["Official Contact ID"], "Natural"),
    ("42", "Trade Association Membership"): _k(["Trade Association", "Member Entity", "Membership Effective From"],
                                               "Composite"),
    # ------------------------------------------------------------------ 42 Lobbying Disclosure
    ("42", "Lobbying Registration"): _k(["Lobbying Registration ID"], "Natural"),
    ("42", "Registered Lobbyist"): _k(["Lobbyist", "Lobbyist Registration", "Lobbyist Effective From"], "Composite"),
    ("42", "Lobbying Disclosure Report"): _k(["Lobbying Report ID"], "Natural",
                                             note="The LOBR- key carries registration, filer, report type, period and "
                                                  "amendment sequence (LD-203 lobbyist rows included)."),
    ("42", "Lobbying Report Issue Line"): _k(["Issue Line Report", "General Issue Area Code"], "Composite"),
    # ------------------------------------------------------------------ 42 Corporate Events & Recognition
    ("42", "Corporate Event"): _k(["Corporate Event ID"], "Natural"),
    ("42", "Corporate Award Entry"): _k(["Award Program Name", "Entry Category", "Award Year", "Entrant Entity",
                                         "Entrant Product", "Entrant Employee"], "Composite",
                                        note="The entrant is the one populated of entity, product or employee. Model gap: "
                                             "the award program has no identifier, so its name is part of the key."),

    # ------------------------------------------------------------------ 43 Bank Accounts & Relationships
    ("43", "Corporate Bank Account"): _k(["Corporate Bank Account ID"], "Natural"),
    ("43", "Bank Account Signatory"): _k(["Signatory Account", "Signatory Employee", "Signatory Party",
                                          "Signatory Authority Level", "Signatory Effective From"], "Composite",
                                         note="The signatory is an employee or an external party; exactly one of the two "
                                              "is populated."),
    ("43", "Cash Pool Membership"): _k(["Pool Participant Account", "Pool Header Account", "Membership Effective From"],
                                       "Composite"),
    ("43", "Bank Relationship Profile"): _k(["Relationship Bank", "Profile Effective From"], "Composite"),
    ("43", "Bank Fee Statement"): _k(["Fee Statement Account", "Fee Billing Period End"], "Composite"),
    # ------------------------------------------------------------------ 43 Cash Management & Forecasting
    ("43", "Bank Statement"): _k(["Statement Account", "Bank Statement Type", "Statement Date", "Statement Sequence Number"],
                                 "Composite",
                                 note="Account x type x date x sequence, so several camt.052 intraday reports a day stay "
                                      "distinct (43 notes)."),
    ("43", "Bank Statement Entry"): _k(["Entry Statement", "Entry Sequence Number"], "Composite",
                                       note="Model gap: Entry Statement is one attribute pointing at a Bank Statement "
                                            "keyed on four attributes, so it carries the statement key as one value."),
    ("43", "Cash Position"): _k(["Position Bank Account", "Position Value Date", "Position Version", "Position Data Basis"],
                                "Composite", note="Entity and currency are read through the account (43 notes)."),
    ("43", "Cash Forecast"): _k(["Cash Forecast ID"], "Natural",
                                note="The ID is the forecast name, as-of date and version (no hyphenated prefix)."),
    ("43", "Cash Forecast Line"): _k(["Line Cash Forecast", "Line Legal Entity", "Line Currency", "Cash Flow Category",
                                      "Bucket Start Date"], "Composite"),
    ("43", "Short-Term Investment"): _k(["Short-Term Investment Reference"], "Natural"),
    # ------------------------------------------------------------------ 43 Funding & Intercompany
    ("43", "Debt Facility"): _k(["Debt Facility ID"], "Natural"),
    ("43", "Debt Facility Drawdown"): _k(["Drawn Debt Facility", "Drawdown Reference"], "Composite",
                                         note="The drawdown reference is unique within the facility only."),
    ("43", "Corporate Covenant Test"): _k(["Tested Debt Facility", "Covenant Metric", "Covenant Test Date"], "Composite"),
    ("43", "Intercompany Loan"): _k(["Intercompany Loan ID"], "Natural"),
    ("43", "Intra-Group Capital Transaction"): _k(["Capital Transaction Reference"], "Natural"),
    # ------------------------------------------------------------------ 43 Seed & Co-Investment Capital
    ("43", "Seed Capital Commitment"): _k(["Seed Capital Commitment ID"], "Natural"),
    ("43", "Seed Capital Movement"): _k(["Movement Seed Commitment", "Movement Reference"], "Composite",
                                        note="The movement reference (SDCAP-00041 / 01) is numbered within the commitment."),
    ("43", "Seed Position Valuation"): _k(["Valued Seed Commitment", "Seed Valuation Date"], "Composite"),
    ("43", "Seed Product Holding"): _k(["Held Seeded Product", "Ownership Measurement Date"], "Composite"),
    # ------------------------------------------------------------------ 43 Regulatory Capital & Liquidity
    ("43", "Regulated Entity Capital Profile"): _k(["Capital Regulated Entity", "Capital Regime",
                                                    "Capital Profile Effective From"], "Composite"),
    ("43", "Capital Requirement Calculation"): _k(["Capital Calculation ID"], "Natural",
                                                  note="The RCAP- key includes the regime code, so an entity under two "
                                                       "regimes on one date has two keys."),
    ("43", "Capital Requirement Component"): _k(["Component Calculation", "Component Sequence"], "Composite"),
    # ICARA Assessment removed (UK IFPR / MIFIDPRU; CW-943).
    ("43", "Capital Adequacy Notification"): _k(["Notifying Entity", "Capital Notification Trigger",
                                                 "Notification Sent Timestamp"], "Composite"),
    # ------------------------------------------------------------------ 43 Corporate FX & Hedging
    ("43", "Corporate Exposure"): _k(["Exposure Legal Entity", "Corporate Exposure Type", "Exposure Currency",
                                      "Exposure Rate Index", "Exposure Seed Commitment", "Exposure Debt Facility",
                                      "Exposure Period Start"], "Composite",
                                     note="Rate index, seed commitment and debt facility are blank where not linked. "
                                          "Model gap: Hedge Relationship.Hedged Exposure carries this seven-part key "
                                          "as one value."),
    ("43", "Treasury Deal"): _k(["Treasury Deal ID"], "Natural"),
    ("43", "Treasury Deal Valuation"): _k(["Valued Treasury Deal", "Deal Valuation Date"], "Composite"),
    ("43", "Hedge Relationship"): _k(["Hedge Relationship ID"], "Natural"),
    ("43", "Hedge Effectiveness Test"): _k(["Tested Hedge Relationship", "Effectiveness Test Date"], "Composite"),
    # ------------------------------------------------------------------ 43 Insurance Program
    ("43", "Corporate Insurance Policy"): _k(["Insurance Policy ID"], "Natural",
                                             note="One INPOL- ID per policy period."),
    ("43", "Insurance Coverage Layer"): _k(["Layer Policy", "Layer Number", "Layer Carrier"], "Composite",
                                           note="The carrier is in the key for quota-share layers (43 notes)."),
    ("43", "Insurance Claim"): _k(["Insurance Claim Reference"], "Natural"),

    # ------------------------------------------------------------------ 44 Real Estate & Sites
    ("44", "Site Profile"): _k(["Profiled Site", "Profile Effective From"], "Composite",
                               note="09 keeps the SITE- key and 44 profiles it (CD-279 rule 1)."),
    ("44", "Building Space"): _k(["Space ID"], "Natural"),
    ("44", "Space Assignment"): _k(["Assigned Space", "Assigned Org Unit", "Assignment Effective From"], "Composite"),
    ("44", "Site Occupancy Measurement"): _k(["Measured Site", "Measured Space", "Occupancy Measurement Date"], "Composite",
                                             note="Measured Space is blank on site-level rows."),
    # ------------------------------------------------------------------ 44 Leases
    ("44", "Lease"): _k(["Lease ID"], "Natural"),
    ("44", "Leased Space"): _k(["Space Lease", "Leased Site", "Leased Building Space", "Leased Space Effective From"],
                               "Composite", note="Leased Building Space is blank where a whole site is leased."),
    ("44", "Lease Payment Schedule Line"): _k(["Schedule Lease", "Payment Period Start", "Lease Charge Type"], "Composite"),
    ("44", "Lease Option & Critical Date"): _k(["Option Lease", "Lease Option Type", "Option Effective Date"], "Composite",
                                               note="The option effective date separates repeated options of one type "
                                                    "(for example successive renewal options)."),
    ("44", "Lease Accounting Measurement"): _child(["Measurement Ledger", "Lease Measurement Date"],
                                                   "Repeats within Lease per 19 ledger and measurement date; rows are "
                                                   "produced by the 19 Controller (CD-279)."),
    # ------------------------------------------------------------------ 44 Facilities & Workplace Services
    ("44", "Facility Asset"): _k(["Facility Asset Tag"], "Natural"),
    ("44", "Planned Maintenance Schedule"): _k(["Maintained Asset", "Maintenance Task Type"], "Composite"),
    ("44", "Facility Work Order"): _k(["Work Order ID"], "Natural"),
    ("44", "Space Reservation"): _k(["Reserved Space", "Reservation Start", "Booker"], "Composite"),
    # ------------------------------------------------------------------ 44 Physical Security
    ("44", "Access Badge"): _k(["Badge ID"], "Natural"),
    ("44", "Physical Access Zone Grant"): _k(["Granted Badge", "Zone Site", "Access Zone", "Zone Space",
                                              "Grant Effective From"], "Composite",
                                             note="Zone Space is blank for site-wide zones."),
    ("44", "Visitor Registration"): _k(["Visit Reference"], "Natural"),
    ("44", "Physical Security Incident"): _k(["Security Incident Reference"], "Natural",
                                             note="Uses 37's key format ('PSI 2026-0007')."),
    # ------------------------------------------------------------------ 44 Health & Safety
    ("44", "Health & Safety Incident"): _k(["H&S Incident ID"], "Natural"),
    ("44", "Workplace Risk Assessment"): _k(["Risk Assessment Reference"], "Natural",
                                            note="The health and safety system's reference identifies the assessed site, "
                                                 "workstation or employee x type x date that the grain names."),
    ("44", "Emergency Role Assignment"): _k(["Role Holder", "Emergency Role Site", "Emergency Role",
                                             "Emergency Role Effective From"], "Composite"),
    # ------------------------------------------------------------------ 44 Travel & Expense
    ("44", "Expense Report"): _k(["Expense Report ID"], "Natural"),
    ("44", "Expense Line"): _k(["Line Expense Report", "Expense Line Number"], "Composite"),
    ("44", "Corporate Card"): _k(["Card Account ID"], "Natural",
                                 note="Issuer card account ID or platform token, never the masked number (program lead "
                                      "decision)."),
    ("44", "Card Transaction"): _k(["Transaction Card", "Issuer Transaction Reference"], "Composite",
                                   note="Model gap: Expense Line.Matched Card Transaction is one attribute and carries "
                                        "card and issuer reference as one value."),
    ("44", "Travel Booking"): _k(["Trip ID"], "Natural"),
    ("44", "Expense Policy Limit"): _k(["Limited Expense Type", "Location Band", "Applicable Job Level",
                                        "Limit Effective From"], "Composite"),
    # ------------------------------------------------------------------ 44 Operational Sustainability
    ("44", "Utility Consumption Record"): _k(["Consumption Site", "Meter Identifier", "Utility Resource",
                                              "Consumption Period Start"], "Composite"),
    ("44", "Operational Emission Record"): _k(["Emission Reporting Entity", "Emission Record Level", "Emission Site",
                                               "Reporting Year", "GHG Scope Category", "Calculation Method"], "Composite",
                                              note="Emission Site is blank on Entity Total rows, so entity totals and "
                                                   "site rows never collide (44 notes, decision 7)."),
}

REFS = {
    # ------------------------------------------------------------------ 42 Brand Governance
    ("42", "Brand", "Brand Owning Entity"): LEGAL_ENTITY,
    ("42", "Brand Standard Version", "Standard Brand"): ("42", "Brand"),
    ("42", "Brand Standard Version", "Standard Approved By"): EMPLOYEE,
    ("42", "Brand Use Authorization", "Authorized Brand"): ("42", "Brand"),
    ("42", "Brand Use Authorization", "Licensee Entity"): LEGAL_ENTITY,
    ("42", "Brand Use Authorization", "Licensee Party"): PARTY,
    ("42", "Brand Use Authorization", "Brand Use Contract"): ("39", "Contract"),
    ("42", "Reputation Measurement", "Measured Brand"): ("42", "Brand"),
    ("42", "Reputation Measurement", "Measurement Provider"): PARTY,
    # ------------------------------------------------------------------ 42 Media Relations
    ("42", "Media Contact Profile", "Media Party"): PARTY,
    ("42", "Media Contact Profile", "Media Outlet"): PARTY,
    ("42", "Media Contact Profile", "Media Relationship Owner"): EMPLOYEE,
    ("42", "Media Inquiry", "Inquiring Journalist"): PARTY,
    ("42", "Media Inquiry", "Inquiring Outlet"): PARTY,
    ("42", "Media Inquiry", "Inquiry Handled By"): EMPLOYEE,
    ("42", "Media Inquiry", "Inquiry Communications Issue"): ("42", "Communications Issue"),
    ("42", "Press Release", "Issuing Entity"): LEGAL_ENTITY,
    ("42", "Press Release", "Release Subject Products"): PRODUCT,
    ("42", "Press Release", "Release Change Initiative"): ("36", "Product Change Initiative"),
    ("42", "Press Release", "Release Publication Property"): ("04", "Digital Property"),
    ("42", "Press Release", "Release Compliance Review"): ("08", "Compliance Review"),
    ("42", "Press Release", "Release Approved By"): EMPLOYEE,
    ("42", "Press Release", "Coordinated Shareholder Communication"): ("13", "Shareholder Communication"),
    ("42", "Media Coverage Item", "Coverage Outlet"): PARTY,
    ("42", "Media Coverage Item", "Coverage Author"): PARTY,
    ("42", "Media Coverage Item", "Coverage Mentioned Brands"): ("42", "Brand"),
    ("42", "Media Coverage Item", "Quoted Spokesperson"): EMPLOYEE,
    ("42", "Media Coverage Item", "Originating Press Release"): ("42", "Press Release"),
    ("42", "Media Coverage Item", "Originating Media Inquiry"): ("42", "Media Inquiry"),
    ("42", "Spokesperson Authorization", "Spokesperson"): EMPLOYEE,
    # ------------------------------------------------------------------ 42 Corporate Publications
    ("42", "Corporate Publication", "Publishing Entity"): LEGAL_ENTITY,
    ("42", "Corporate Publication", "Publication Signatory"): EMPLOYEE,
    ("42", "Corporate Publication", "Publication Property"): ("04", "Digital Property"),
    ("42", "Publication Source Link", "Linked Publication"): ("42", "Corporate Publication"),
    ("42", "Publication Source Link", "Source Human Capital Metric Value"): ("20", "Human Capital Metric Value"),
    # Publication Source Link.Source PAI Calculation removed with 34 PAI Calculation (CW-934, CW-942).
    ("42", "Publication Source Link", "Source Capital Requirement Calculation"):
        ("43", "Capital Requirement Calculation"),
    ("42", "Publication Source Link", "Source Operational Emission Record"): ("44", "Operational Emission Record"),
    # ------------------------------------------------------------------ 42 Internal Communications
    ("42", "Internal Communication", "Internal Communication Sender"): EMPLOYEE,
    ("42", "Internal Communication", "Internal Communication Issue"): ("42", "Communications Issue"),
    ("42", "Internal Communication", "Announced Policy"): ("38", "Policy"),
    ("42", "Internal Communication Audience", "Audience Communication"): ("42", "Internal Communication"),
    ("42", "Internal Communication Audience", "Audience Org Unit"): ORG_UNIT,
    ("42", "Internal Communication Audience", "Audience Office"): SITE,
    ("42", "Internal Communication Audience", "Audience Legal Entity"): LEGAL_ENTITY,
    ("42", "Internal Communication Audience", "Audience Job Profile"): ("20", "Job Profile"),
    ("42", "Internal Communication Engagement", "Engagement Communication"): ("42", "Internal Communication"),
    # ------------------------------------------------------------------ 42 Issues & Crisis Communications
    ("42", "Communications Issue", "Trigger Operational Incident"): ("37", "Operational Incident"),
    ("42", "Communications Issue", "Trigger IT Incident"): ("41", "IT Incident"),
    ("42", "Communications Issue", "Trigger Legal Matter"): ("39", "Legal Matter"),
    ("42", "Communications Issue", "Trigger Health and Safety Incident"): ("44", "Health & Safety Incident"),
    ("42", "Communications Issue", "Trigger Physical Security Incident"): ("44", "Physical Security Incident"),
    ("42", "Communications Issue", "Issue Lead"): EMPLOYEE,
    ("42", "Communications Issue", "Related Social Mentions"): ("04", "Social Listening Mention"),
    ("42", "Communications Issue", "Activated Crisis Plan"): ("42", "Crisis Communication Plan"),
    ("42", "Issue Statement", "Statement Issue"): ("42", "Communications Issue"),
    ("42", "Issue Statement", "Statement Approved By"): EMPLOYEE,
    ("42", "Crisis Communication Plan", "Crisis Plan Owner"): EMPLOYEE,
    ("42", "Crisis Communication Plan", "Linked Business Continuity Plan"): ("37", "Business Continuity Plan"),
    # ------------------------------------------------------------------ 42 Government Relations & Public Policy
    ("42", "Consultation Response", "Consulting Body"): PARTY,
    ("42", "Consultation Response", "Responding Entity"): LEGAL_ENTITY,
    ("42", "Consultation Response", "Response Position"): ("42", "Public Policy Position"),
    ("42", "Consultation Response", "Joint Response Association"): PARTY,
    ("42", "Government Official Contact", "Contacted Official"): PARTY,
    ("42", "Government Official Contact", "Official Agency"): PARTY,
    ("42", "Government Official Contact", "Firm Attendees"): EMPLOYEE,
    ("42", "Government Official Contact", "Discussed Position"): ("42", "Public Policy Position"),
    ("42", "Government Official Contact", "Related Hospitality Item"): ("08", "Gift / Entertainment Item"),
    ("42", "Trade Association Membership", "Trade Association"): PARTY,
    ("42", "Trade Association Membership", "Member Entity"): LEGAL_ENTITY,
    # ------------------------------------------------------------------ 42 Lobbying Disclosure
    ("42", "Lobbying Registration", "Registrant Entity"): LEGAL_ENTITY,
    ("42", "Lobbying Registration", "Outside Lobbying Firm"): PARTY,
    ("42", "Registered Lobbyist", "Lobbyist"): EMPLOYEE,
    ("42", "Registered Lobbyist", "Lobbyist Registration"): ("42", "Lobbying Registration"),
    ("42", "Lobbying Disclosure Report", "Report Registration"): ("42", "Lobbying Registration"),
    ("42", "Lobbying Disclosure Report", "Filing Lobbyist"): EMPLOYEE,
    ("42", "Lobbying Disclosure Report", "Amended Report"): ("42", "Lobbying Disclosure Report"),
    ("42", "Lobbying Disclosure Report", "Reported Political Contributions"): ("38", "Political Contribution"),
    ("42", "Lobbying Report Issue Line", "Issue Line Report"): ("42", "Lobbying Disclosure Report"),
    ("42", "Lobbying Report Issue Line", "Issue Line Lobbyists"): EMPLOYEE,
    # ------------------------------------------------------------------ 42 Corporate Events & Recognition
    ("42", "Corporate Event", "Corporate Event Venue"): SITE,
    ("42", "Corporate Event", "Event Press Release"): ("42", "Press Release"),
    ("42", "Corporate Award Entry", "Award Organizer"): PARTY,
    ("42", "Corporate Award Entry", "Entrant Entity"): LEGAL_ENTITY,
    ("42", "Corporate Award Entry", "Entrant Product"): PRODUCT,
    ("42", "Corporate Award Entry", "Entrant Employee"): EMPLOYEE,
    ("42", "Corporate Award Entry", "Fund or Manager Award Record"): ("11", "Award"),
    # ------------------------------------------------------------------ 43 Bank Accounts & Relationships
    ("43", "Corporate Bank Account", "Account Holder Entity"): LEGAL_ENTITY,
    ("43", "Corporate Bank Account", "Account Servicing Bank"): PARTY,
    ("43", "Corporate Bank Account", "Cash GL Account"): ("19", "GL Account"),
    ("43", "Bank Account Signatory", "Signatory Account"): ("43", "Corporate Bank Account"),
    ("43", "Bank Account Signatory", "Signatory Employee"): EMPLOYEE,
    ("43", "Bank Account Signatory", "Signatory Party"): PARTY,
    ("43", "Cash Pool Membership", "Pool Participant Account"): ("43", "Corporate Bank Account"),
    ("43", "Cash Pool Membership", "Pool Header Account"): ("43", "Corporate Bank Account"),
    ("43", "Cash Pool Membership", "Pool Intercompany Loan"): ("43", "Intercompany Loan"),
    ("43", "Bank Relationship Profile", "Relationship Bank"): PARTY,
    ("43", "Bank Relationship Profile", "Relationship Owner"): EMPLOYEE,
    ("43", "Bank Fee Statement", "Fee Statement Account"): ("43", "Corporate Bank Account"),
    # ------------------------------------------------------------------ 43 Cash Management & Forecasting
    ("43", "Bank Statement", "Statement Account"): ("43", "Corporate Bank Account"),
    ("43", "Bank Statement Entry", "Entry Statement"): ("43", "Bank Statement"),
    ("43", "Bank Statement Entry", "Matched Journal Entry"): JOURNAL,
    ("43", "Cash Position", "Position Bank Account"): ("43", "Corporate Bank Account"),
    ("43", "Cash Forecast", "Forecast Preparer"): EMPLOYEE,
    ("43", "Cash Forecast", "Aligned Financial Plan Version"): ("19", "Financial Plan Version"),
    ("43", "Cash Forecast Line", "Line Cash Forecast"): ("43", "Cash Forecast"),
    ("43", "Cash Forecast Line", "Line Legal Entity"): LEGAL_ENTITY,
    ("43", "Cash Forecast Line", "Linked Seed Commitment"): ("43", "Seed Capital Commitment"),
    ("43", "Short-Term Investment", "Placing Entity"): LEGAL_ENTITY,
    ("43", "Short-Term Investment", "Deposit Counterparty"): PARTY,
    ("43", "Short-Term Investment", "Money Market Fund Share Class"): SHARE_CLASS,
    ("43", "Short-Term Investment", "Holding Account"): ACCOUNT,
    # ------------------------------------------------------------------ 43 Funding & Intercompany
    ("43", "Debt Facility", "Borrowing Entity"): LEGAL_ENTITY,
    ("43", "Debt Facility", "Lender Parties"): PARTY,
    ("43", "Debt Facility Drawdown", "Drawn Debt Facility"): ("43", "Debt Facility"),
    ("43", "Debt Facility Drawdown", "Rate Fixing Used"): ("22", "Reference Rate Fixing"),
    ("43", "Corporate Covenant Test", "Tested Debt Facility"): ("43", "Debt Facility"),
    ("43", "Intercompany Loan", "Lending Entity"): LEGAL_ENTITY,
    ("43", "Intercompany Loan", "Intercompany Borrowing Entity"): LEGAL_ENTITY,
    ("43", "Intercompany Loan", "Pricing Documentation"): ("19", "Transfer Pricing Documentation"),
    ("43", "Intercompany Loan", "Loan Intercompany Agreement"): ("10", "Intercompany Agreement"),
    ("43", "Intra-Group Capital Transaction", "Paying Entity"): LEGAL_ENTITY,
    ("43", "Intra-Group Capital Transaction", "Receiving Entity"): LEGAL_ENTITY,
    # ------------------------------------------------------------------ 43 Seed & Co-Investment Capital
    ("43", "Seed Capital Commitment", "Seeded Product"): PRODUCT,
    ("43", "Seed Capital Commitment", "Seeded Share Class"): SHARE_CLASS,
    ("43", "Seed Capital Commitment", "Investing Entity"): LEGAL_ENTITY,
    ("43", "Seed Capital Commitment", "Launch Change Initiative"): ("36", "Product Change Initiative"),
    ("43", "Seed Capital Commitment", "Seed Holding Account"): ACCOUNT,
    ("43", "Seed Capital Commitment", "Seed Book"): ("18", "Portfolio"),
    ("43", "Seed Capital Movement", "Movement Seed Commitment"): ("43", "Seed Capital Commitment"),
    ("43", "Seed Capital Movement", "Resulting Fund Order"): ("29", "Fund Order"),
    ("43", "Seed Capital Movement", "Resulting AP Order"): ("29", "AP Creation / Redemption Order"),
    ("43", "Seed Capital Movement", "Transfer Counterparty Entity"): LEGAL_ENTITY,
    ("43", "Seed Position Valuation", "Valued Seed Commitment"): ("43", "Seed Capital Commitment"),
    ("43", "Seed Position Valuation", "Source Shareholder Position"): ("06", "Fund Shareholder Position"),
    ("43", "Seed Position Valuation", "Source NAV Record"): ("27", "Share Class NAV"),
    ("43", "Seed Product Holding", "Held Seeded Product"): PRODUCT,
    # ------------------------------------------------------------------ 43 Regulatory Capital & Liquidity
    ("43", "Regulated Entity Capital Profile", "Capital Regulated Entity"): LEGAL_ENTITY,
    ("43", "Regulated Entity Capital Profile", "Governing Authorization"): ("38", "Entity Authorization"),
    ("43", "Regulated Entity Capital Profile", "Capital Appetite Statement"): ("37", "Risk Appetite Statement"),
    ("43", "Capital Requirement Calculation", "Calculation Entity"): LEGAL_ENTITY,
    # W1b net capital addition (CW-943), re-typed by CW-103: alternative standard rows read the 49 Rule 15c3-3 reserve
    # computation (RESRV-); Aggregate Debit Items Amount is a Derived copy from it, not a reference.
    ("43", "Capital Requirement Calculation", "Reserve Computation"): ("49", "Reserve Computation"),
    ("43", "Capital Requirement Component", "Component Calculation"): ("43", "Capital Requirement Calculation"),
    # ICARA Assessment references removed with the object (CW-943).
    ("43", "Capital Adequacy Notification", "Notifying Entity"): LEGAL_ENTITY,
    ("43", "Capital Adequacy Notification", "Triggering Calculation"): ("43", "Capital Requirement Calculation"),
    ("43", "Capital Adequacy Notification", "Related Capital Transaction"): ("43", "Intra-Group Capital Transaction"),
    # ------------------------------------------------------------------ 43 Corporate FX & Hedging
    ("43", "Corporate Exposure", "Exposure Legal Entity"): LEGAL_ENTITY,
    ("43", "Corporate Exposure", "Exposure Seed Commitment"): ("43", "Seed Capital Commitment"),
    ("43", "Corporate Exposure", "Exposure Debt Facility"): ("43", "Debt Facility"),
    ("43", "Treasury Deal", "Dealing Entity"): LEGAL_ENTITY,
    ("43", "Treasury Deal", "Deal Counterparty Bank"): PARTY,
    ("43", "Treasury Deal", "Governing Trading Agreement"): ("26", "Trading Agreement"),
    ("43", "Treasury Deal Valuation", "Valued Treasury Deal"): ("43", "Treasury Deal"),
    ("43", "Treasury Deal Valuation", "Valuation FX Rate Observation"): ("22", "FX Rate Observation"),
    ("43", "Treasury Deal Valuation", "Valuation Curve"): ("22", "Curve Definition"),
    ("43", "Hedge Relationship", "Hedged Exposure"): ("43", "Corporate Exposure"),
    ("43", "Hedge Relationship", "Hedged Debt Facility"): ("43", "Debt Facility"),
    ("43", "Hedge Relationship", "Hedged Net Investment Entity"): LEGAL_ENTITY,
    ("43", "Hedge Relationship", "Hedged Seed Commitment"): ("43", "Seed Capital Commitment"),
    ("43", "Hedge Relationship", "Hedging Treasury Deals"): ("43", "Treasury Deal"),
    ("43", "Hedge Relationship", "Hedging OTC Derivative Trades"): ("26", "OTC Derivative Trade"),
    ("43", "Hedge Relationship", "Hedging Executions"): ("25", "Execution"),
    ("43", "Hedge Effectiveness Test", "Tested Hedge Relationship"): ("43", "Hedge Relationship"),
    ("43", "Hedge Effectiveness Test", "Ineffectiveness Journal"): JOURNAL,
    # ------------------------------------------------------------------ 43 Insurance Program
    ("43", "Corporate Insurance Policy", "Lead Insurer"): PARTY,
    ("43", "Corporate Insurance Policy", "Insurance Broker"): PARTY,
    ("43", "Corporate Insurance Policy", "Named Insured Entities"): LEGAL_ENTITY,
    ("43", "Corporate Insurance Policy", "Joint Fund Fidelity Bond"): ("35", "Fund Fidelity Bond"),
    ("43", "Insurance Coverage Layer", "Layer Policy"): ("43", "Corporate Insurance Policy"),
    ("43", "Insurance Coverage Layer", "Layer Carrier"): PARTY,
    ("43", "Insurance Claim", "Claimed Policy"): ("43", "Corporate Insurance Policy"),
    ("43", "Insurance Claim", "Related Operational Loss Event"): ("37", "Operational Loss Event"),
    ("43", "Insurance Claim", "Related Legal Matter"): ("39", "Legal Matter"),
    ("43", "Insurance Claim", "Related IT Incident"): ("41", "IT Incident"),
    # ------------------------------------------------------------------ 44 Real Estate & Sites
    ("44", "Site Profile", "Profiled Site"): SITE,
    ("44", "Site Profile", "Site Area Unit"): UOM,
    ("44", "Building Space", "Space Site"): SITE,
    ("44", "Building Space", "Parent Space"): ("44", "Building Space"),
    ("44", "Space Assignment", "Assigned Space"): ("44", "Building Space"),
    ("44", "Space Assignment", "Assigned Org Unit"): ORG_UNIT,
    ("44", "Space Assignment", "Chargeback Cost Center"): ("19", "Chart Segment Value"),
    ("44", "Site Occupancy Measurement", "Measured Site"): SITE,
    ("44", "Site Occupancy Measurement", "Measured Space"): ("44", "Building Space"),
    # ------------------------------------------------------------------ 44 Leases
    ("44", "Lease", "Lease Counterparty"): PARTY,
    ("44", "Lease", "Firm Legal Entity"): LEGAL_ENTITY,
    ("44", "Lease", "Head Lease"): ("44", "Lease"),
    ("44", "Lease", "Lease Contract"): ("39", "Contract"),
    ("44", "Leased Space", "Space Lease"): ("44", "Lease"),
    ("44", "Leased Space", "Leased Site"): SITE,
    ("44", "Leased Space", "Leased Building Space"): ("44", "Building Space"),
    ("44", "Lease Payment Schedule Line", "Schedule Lease"): ("44", "Lease"),
    ("44", "Lease Option & Critical Date", "Option Lease"): ("44", "Lease"),
    ("44", "Lease Accounting Measurement", "Measured Lease"): ("44", "Lease"),
    ("44", "Lease Accounting Measurement", "Measurement Ledger"): ("19", "Ledger"),
    ("44", "Lease Accounting Measurement", "Measurement Approver"): EMPLOYEE,
    # ------------------------------------------------------------------ 44 Facilities & Workplace Services
    ("44", "Facility Asset", "Asset Site"): SITE,
    ("44", "Facility Asset", "Asset Location Space"): ("44", "Building Space"),
    ("44", "Facility Asset", "Asset Lease"): ("44", "Lease"),
    ("44", "Planned Maintenance Schedule", "Maintained Asset"): ("44", "Facility Asset"),
    ("44", "Planned Maintenance Schedule", "Maintenance Vendor"): PARTY,
    ("44", "Facility Work Order", "Work Order Site"): SITE,
    ("44", "Facility Work Order", "Work Order Space"): ("44", "Building Space"),
    ("44", "Facility Work Order", "Work Order Asset"): ("44", "Facility Asset"),
    ("44", "Facility Work Order", "Requested By"): EMPLOYEE,
    ("44", "Facility Work Order", "Assigned Vendor"): PARTY,
    ("44", "Facility Work Order", "Vendor Invoice"): ("19", "Payable Invoice"),
    ("44", "Facility Work Order", "Work Order Purchase Order"): ("40", "Purchase Order"),
    ("44", "Space Reservation", "Reserved Space"): ("44", "Building Space"),
    ("44", "Space Reservation", "Booker"): EMPLOYEE,
    ("44", "Space Reservation", "Reserved For Marketing Event"): ("04", "Marketing Event"),
    ("44", "Space Reservation", "Reserved For Corporate Event"): ("42", "Corporate Event"),
    # ------------------------------------------------------------------ 44 Physical Security
    ("44", "Access Badge", "Badge Holder"): EMPLOYEE,
    ("44", "Access Badge", "Badge Visit"): ("44", "Visitor Registration"),
    ("44", "Access Badge", "Deactivating Lifecycle Event"): ("20", "Employee Lifecycle Event"),
    ("44", "Physical Access Zone Grant", "Granted Badge"): ("44", "Access Badge"),
    ("44", "Physical Access Zone Grant", "Zone Site"): SITE,
    ("44", "Physical Access Zone Grant", "Zone Space"): ("44", "Building Space"),
    ("44", "Physical Access Zone Grant", "Grant Approver"): EMPLOYEE,
    ("44", "Visitor Registration", "Visited Site"): SITE,
    ("44", "Visitor Registration", "Host Employee"): EMPLOYEE,
    ("44", "Visitor Registration", "Visitor Party"): PARTY,
    ("44", "Physical Security Incident", "Security Incident Site"): SITE,
    ("44", "Physical Security Incident", "Involved Badge"): ("44", "Access Badge"),
    # ------------------------------------------------------------------ 44 Health & Safety
    ("44", "Health & Safety Incident", "H&S Incident Site"): SITE,
    ("44", "Health & Safety Incident", "Affected Employee"): EMPLOYEE,
    ("44", "Workplace Risk Assessment", "Assessed Site"): SITE,
    ("44", "Workplace Risk Assessment", "Assessed Workstation"): ("44", "Building Space"),
    ("44", "Workplace Risk Assessment", "Assessed Employee"): EMPLOYEE,
    ("44", "Emergency Role Assignment", "Role Holder"): EMPLOYEE,
    ("44", "Emergency Role Assignment", "Emergency Role Site"): SITE,
    ("44", "Emergency Role Assignment", "Emergency Role Floor"): ("44", "Building Space"),
    ("44", "Emergency Role Assignment", "Certifying Learning Completion"): ("20", "Learning Completion"),
    # ------------------------------------------------------------------ 44 Travel & Expense
    ("44", "Expense Report", "Claimant"): EMPLOYEE,
    ("44", "Expense Report", "Expense Approver"): EMPLOYEE,
    ("44", "Expense Report", "Cost Owner Org Unit"): ORG_UNIT,
    ("44", "Expense Report", "Reimbursement Supplier Payment"): ("19", "Supplier Payment"),
    ("44", "Expense Report", "Reimbursement Payroll Result"): ("20", "Payroll Result"),
    ("44", "Expense Report", "Posting Journal Entry"): JOURNAL,
    ("44", "Expense Line", "Line Expense Report"): ("44", "Expense Report"),
    ("44", "Expense Line", "External Attendees"): PARTY,
    ("44", "Expense Line", "Related Gift / Entertainment Items"): ("08", "Gift / Entertainment Item"),
    ("44", "Expense Line", "Matched Card Transaction"): ("44", "Card Transaction"),
    ("44", "Expense Line", "Recharge Fund"): PRODUCT,
    ("44", "Corporate Card", "Cardholder"): EMPLOYEE,
    ("44", "Corporate Card", "Card Issuer"): PARTY,
    ("44", "Corporate Card", "Card Billing Entity"): LEGAL_ENTITY,
    ("44", "Card Transaction", "Transaction Card"): ("44", "Corporate Card"),
    ("44", "Travel Booking", "Traveler"): EMPLOYEE,
    ("44", "Travel Booking", "Booking Agency"): PARTY,
    ("44", "Expense Policy Limit", "Governing Policy"): ("38", "Policy"),
    # ------------------------------------------------------------------ 44 Operational Sustainability
    ("44", "Utility Consumption Record", "Consumption Site"): SITE,
    ("44", "Utility Consumption Record", "Consumption Unit"): UOM,
    ("44", "Utility Consumption Record", "Source Utility Invoice"): ("19", "Payable Invoice"),
    ("44", "Operational Emission Record", "Emission Reporting Entity"): LEGAL_ENTITY,
    ("44", "Operational Emission Record", "Emission Site"): SITE,
    ("44", "Operational Emission Record", "Activity Unit"): UOM,
    ("44", "Operational Emission Record", "Reported Indicator"): ("34", "Sustainability Indicator Definition"),
}
