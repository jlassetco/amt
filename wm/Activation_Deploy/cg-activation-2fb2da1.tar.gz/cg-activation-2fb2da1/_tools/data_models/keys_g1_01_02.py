"""Key and link registry extension: Data Domains 01 Investment Product & Service Offering and 02 Client & Household.

Same format and conventions as keys.py (see CONTRACT.md section 1). "Scoped within <X>" means the object carries no
attribute for its owning X; the model completes the key with X's key.

Wealth-manager W1 merge (2026-10-14): this file holds the whole 02 registry. The 02 Client & Household module
(content_02_client_and_household.py, CW-021, CW-902) replaces the wholesale 02 Client & Customer; the wholesale 02
entries that were split between keys.py and this file are retired here. Objects that moved out of 02 (Distributor Firm,
Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Gatekeeper Profile, Financial Professional, Advisor
Practice, Employment Affiliation, Team Membership, External Classification, Consultant Profile and Consultant Advisory
Relationship to 05 at W4; Institutional Client to 12 at W4; Recordkeeper Profile and Plan Service Provider to 16 at W3)
are keyed again by the stage that restores them. Dropped objects (End Investor, Digital Profile, Retention, UK & EU
Regulatory Identifier, Processing Legal Basis) and the re-cut contact-point objects (Contact Point Address, Email,
Phone, Usage; now Contact Point and Postal Address) and Data Subject Request (now Consumer Privacy Request) are gone.

01 follows CW-901: Target Market, Country Registration and Share Class Tax Reporting are removed; the wealth service
offering objects (OFFR-, ELIG-, TUP-, OFWN-) are added.

References whose target sat in a wealth Data Domain with no module yet (45 to 52) were held in PENDING_REFS; they moved
to REFS at the W2-W4 merge (2026-10-15), which also re-points 01 Investment Mandate.Client to the restored 12
Institutional Client (CW-133) and keys the 01 Platform Feature (CW-936 fix pass).
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


KEYS = {
    # ------------------------------------------------------------------ 01 Investment Product & Service Offering
    # Strategy
    ("01", "Investment Strategy"): _k(["Strategy ID"], "Natural"),
    ("01", "Strategy Classification"): _fold(),
    ("01", "GIPS Composite"): _k(["Composite ID"], "Natural"),

    # Product & vehicle
    ("01", "Investment Product"): _k(["Product ID"], "Natural"),
    ("01", "Fund Legal Structure"): _fold(),
    ("01", "Feeder Access Terms"): _fold("Populated for feeder, tender-offer and interval funds only; one set of "
                                         "access terms per product."),
    ("01", "Investment Mandate"): _k(["Mandate ID"], "Natural"),
    ("01", "Model Portfolio"): _k(["Model Portfolio ID"], "Natural"),
    ("01", "Product Relationship"): _k(["Source Product", "Target Product", "Relationship Type",
                                        "Relationship Effective From"], "Composite"),
    ("01", "Firm Product Classification"): _fold(),
    ("01", "Regulatory Classification"): _fold(),
    ("01", "ESG Classification"): _fold(),
    ("01", "Investment Objective & Policy"): _fold(),
    ("01", "Investment Restriction"): _k(["Restriction ID"], "Natural"),
    ("01", "Dealing Terms"): _fold(),
    ("01", "Valuation Terms"): _fold(),
    ("01", "ETF Characteristics"): _fold("Populated for ETFs only."),
    ("01", "Product Party Role"): _k(["Party", "Party Role Type", "Role Effective From"], "Composite",
                                     note="Scoped within Investment Product."),
    ("01", "Portfolio Manager Assignment"): _k(["Portfolio Manager", "PM Start Date"], "Composite",
                                               note="Scoped within the Investment Product or Investment Mandate "
                                                    "(polymorphic owner, not carried by any attribute)."),
    ("01", "Regulatory Authorization"): _fold(),
    ("01", "Product Tax Status"): _fold(),
    ("01", "Product Governance"): _fold(),
    ("01", "Lifecycle Event"): _k(["Lifecycle Event Type", "Event Effective Date"], "Composite",
                                  note="Scoped within the Investment Product or Share Class (polymorphic owner, not "
                                       "carried by any attribute)."),
    ("01", "Product Document"): _k(["Document Type", "Document Language", "Document Jurisdiction",
                                    "Document Version Date"], "Composite",
                                   note="Scoped within the Investment Product or Share Class (polymorphic owner, not "
                                        "carried by any attribute). Document Jurisdiction is optional; use a "
                                        "'US' default value where blank so the key stays complete."),
    ("01", "Investment Commentary"): _k(["Commentary ID"], "Natural"),
    ("01", "Commentary Approval"): _fold(),

    # Share class
    ("01", "Share Class"): _k(["Share Class ID"], "Natural"),
    ("01", "Currency Hedging"): _fold(),
    ("01", "Income Distribution"): _fold(),
    ("01", "Investor Eligibility"): _fold(),
    ("01", "Security Identifier"): _fold(),
    ("01", "Regulatory Filing Identifier"): _fold(),
    ("01", "External Cross-Reference"): _fold(),
    ("01", "System Cross-Reference"): _k(["Source System", "Source System Code", "Cross-Reference Effective From"],
                                         "Composite",
                                         note="System + code + effective date is unique on its own; the owning "
                                              "product or share class is not needed in the key."),
    ("01", "External Classification"): _fold(),
    ("01", "Product Risk Indicator"): _fold(),
    ("01", "Performance Track Record"): _fold(),
    ("01", "Management Fee"): _fold("Folds into Share Class; for separate account mandates the same terms sit at "
                                    "mandate level."),
    ("01", "Other Ongoing Fees"): _fold(),
    ("01", "Performance Fee"): _fold(),
    ("01", "Investor Transaction Charge"): _fold(),
    ("01", "Cost Disclosure"): _k(["Cost Reference Date"], "Composite", note="Scoped within Share Class."),
    ("01", "Listing"): _k(["Listing Exchange"], "Composite", note="Scoped within Share Class."),
    ("01", "Distribution Availability"): _fold(),
    # Target Market, Country Registration and Share Class Tax Reporting removed (EU/UK only; CW-901).

    # Benchmark
    ("01", "Benchmark"): _k(["Benchmark ID"], "Natural"),
    ("01", "Product Benchmark Assignment"): _k(["Assigned Product / Share Class", "Assigned Benchmark",
                                                "Benchmark Role", "Assignment Effective From"], "Composite"),

    # Service offerings, tiers and platform shelf (wealth adaptation, CW-028, CW-901)
    ("01", "Service Offering"): _k(["Offering ID"], "Natural", note="OFFR- key."),
    ("01", "Offering Feature"): _child(["Offering Feature Type"],
                                       "One row per feature type within the offering, as the grain says."),
    ("01", "Offering Eligibility Rule"): _k(["Eligibility Rule ID"], "Natural",
                                            note="ELIG- key; Eligibility Offering x Eligibility Criterion x "
                                                 "Eligibility Effective From is the alternate key."),
    ("01", "Offering Fee Schedule Link"): _k(["Linked Offering", "Linked Fee Schedule", "Link Effective From"],
                                             "Composite"),
    ("01", "Service Tier"): _k(["Service Tier Code"], "Natural",
                               note="The tier code (for example PREMIER) is the identifier (proposals_w1_01 key "
                                    "formats); 02 Service Tier Assignment references it."),
    ("01", "Tradable Universe Policy Rule"): _k(["Policy Rule ID"], "Natural", note="TUP- key."),
    ("01", "Platform Product Availability"): _k(["Platform Availability ID"], "Natural",
                                                note="PLAVL- key (W5 ruling 3, GAP-01-027; prefix proposed). Exactly one "
                                                     "of Available Share Class (own fund) and Available Third-Party "
                                                     "Instrument is filled, as the grain says."),
    ("01", "Offering Window"): _k(["Offering Window ID"], "Natural", note="OFWN- key."),
    # W2-W4 merge (2026-10-15): 01 objects restored or added
    ("01", "Platform Feature"): _k(["Platform Feature Type", "Feature Effective From"], "Composite",
                                   note="Keyed by the 15 Feature Type code and effective date (CW-936 fix pass)."),

    # ------------------------------------------------------------------ 02 Client & Household
    # Party
    ("02", "Party"): _k(["Party ID"], "Natural", note="PTY- key; households are parties (PTY-HH-)."),
    ("02", "Individual"): _fold(),
    ("02", "Organization"): _fold(),
    ("02", "Legal Entity Hierarchy"): _k(["Subsidiary Party", "Direct Parent", "Parent Relationship Basis",
                                          "Hierarchy Effective From"], "Composite"),
    ("02", "Party Role"): _k(["Role Party", "Role Type", "Role Effective From"], "Composite"),
    ("02", "Retirement Plan"): _fold("A plan is a party (PTY-); Sponsor EIN x Plan Number is its alternate key. Plan "
                                     "administration detail is 16's."),
    ("02", "Party Identifier"): _k(["Identifier Scheme", "Identifier Value", "Identifier Effective From"], "Composite",
                                   note="Scheme + value + effective date is unique on its own; the owning party is not "
                                        "needed in the key."),
    ("02", "LEI Record"): _fold("Populated for the LEI scheme only."),
    ("02", "US Regulatory Identifier"): _fold(),
    ("02", "Market Infrastructure & Vendor Identifier"): _fold(),

    # Household & relationships
    ("02", "Household"): _fold("A household is a party (PTY-HH-); the group holds its household-only columns."),
    ("02", "Household Membership"): _k(["Household", "Household Member", "Membership Effective From"], "Composite"),
    ("02", "Party Relationship"): _k(["From Party", "To Party", "Relationship Type", "Relationship Effective From"],
                                     "Composite"),
    ("02", "Authority Grant"): _k(["Authority Grant ID"], "Natural",
                                  note="AGNT- key; grantor x holder x authority type x Grant Effective From is the "
                                       "alternate key."),
    ("02", "Trusted Contact Designation"): _k(["Trusted Contact Designation ID"], "Natural", note="TCNT- key."),
    ("02", "Death Notification"): _k(["Death Notification ID"], "Natural", note="DTHN- key."),

    # Investor profile & suitability
    ("02", "Investor Profile"): _k(["Investor Profile ID"], "Natural",
                                   note="INPR- key carries the client's party number and the profile version, so one "
                                        "row is one version (Profile Client x Profile Version Number)."),
    ("02", "Investment Experience"): _k(["Experience Profile", "Product Experience Type"], "Composite"),
    ("02", "Investor Qualification"): _child(["Qualification Standard"],
                                             "Latest determination per standard (accredited investor, qualified "
                                             "purchaser ...), so the group repeats within the party."),

    # KYC & due diligence
    ("02", "Onboarding Case"): _k(["Onboarding Case ID"], "Natural"),
    ("02", "KYC Profile"): _fold("Current profile only; KYC history is not modeled in this group."),
    ("02", "Identity Verification"): _k(["Identity Verification ID"], "Natural", note="KYCV- key."),
    ("02", "Beneficial Ownership Certification"): _k(["Beneficial Ownership Certification ID"], "Natural",
                                                      note="BOWN- key."),
    ("02", "Beneficial Ownership"): _k(["Ownership Certification", "Beneficial Owner", "Ownership Prong"],
                                       "Composite"),
    ("02", "Tax Profile"): _fold(),

    # Classification & segmentation
    ("02", "Regulatory Classification"): _k(["Classified Party", "Categorization Date"], "Composite"),
    ("02", "Segment Assignment"): _k(["Segmented Party", "Segmentation Scheme", "Segment Effective From"],
                                     "Composite"),
    ("02", "Service Tier Assignment"): _k(["Tier Party", "Assigned Service Tier", "Tier Effective From"],
                                          "Composite"),

    # Contact points & preferences
    ("02", "Contact Point"): _k(["Contact Point ID"], "Natural",
                                note="CTP- key; one contact point is one channel value with one usage."),
    ("02", "Postal Address"): _fold("Populated for postal contact points only."),
    ("02", "Contact Preference"): _k(["Preference Holder", "Preference Effective From"], "Composite"),
    ("02", "Communication Preference"): _k(["Preference Party", "Preference Topic", "Preference Channel"],
                                           "Composite",
                                           note="Preference Topic is optional; a blank topic means a channel-wide "
                                                "preference and needs a default value to keep the key complete."),

    # Privacy & consent
    ("02", "Privacy Profile"): _fold(),
    ("02", "Consent Record"): _k(["Consent Record ID"], "Natural", note="CNS- key."),
    ("02", "Consumer Privacy Request"): _k(["Privacy Request ID"], "Natural"),

    # Restrictions & vulnerable clients
    ("02", "Client Restriction"): _k(["Client Restriction ID"], "Natural", note="CRX- key."),
    ("02", "Restricted Client Status"): _k(["Status Party", "Status Effective From"], "Composite"),
    ("02", "Specified Adult Status"): _child(["Specified Adult Basis", "Specified Adult Status Effective From"],
                                             "The grain names an effective period; Specified Adult Status Effective "
                                             "From (W5, GAP-02-034) is the period start."),
    ("02", "Vulnerability Concern"): _k(["Vulnerability Concern ID"], "Natural", note="VCON- key."),
}


PARTY = ("02", "Party")
EMPLOYEE = ("20", "Employee")
ACCOUNT = ("15", "Account")
INSTRUMENT = ("17", "Instrument")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
SERVICE_REQUEST = ("13", "Service Request")
STRATEGY = ("01", "Investment Strategy")
PRODUCT = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
BENCHMARK = ("01", "Benchmark")
OFFERING = ("01", "Service Offering")
INVESTOR_PROFILE = ("02", "Investor Profile")
IDV = ("02", "Identity Verification")

REFS = {
    # ------------------------------------------------------------------ 01 Investment Product & Service Offering
    ("01", "Investment Strategy", "Investment Team"): ("09", "Org Unit"),
    ("01", "Investment Strategy", "Lead Portfolio Manager"): EMPLOYEE,
    ("01", "Investment Strategy", "Investment Affiliate / Boutique"): LEGAL_ENTITY,
    ("01", "GIPS Composite", "Composite Benchmark"): BENCHMARK,
    # Composite Member is no longer a reference: since CD-218 (Stage 3) it is a Derived copy (Text) rolled up from the 32
    # Composite Membership (composite x 18 portfolio), so it carries no link here.
    ("01", "Investment Product", "Implemented Strategy"): STRATEGY,
    ("01", "Fund Legal Structure", "Umbrella Fund"): PRODUCT,
    ("01", "Fund Legal Structure", "Master Fund"): PRODUCT,
    ("01", "Feeder Access Terms", "Underlying Fund Instrument"): INSTRUMENT,
    # The client is the restored 12 Institutional Client, a role profile of the 02 Party keyed by PTY- (CW-133).
    ("01", "Investment Mandate", "Client"): ("12", "Institutional Client"),
    ("01", "Investment Mandate", "Implemented Strategy"): STRATEGY,
    ("01", "Model Portfolio", "Implemented Strategy"): STRATEGY,
    # The sponsor is the restored 05 Distributor Firm, a role profile of the 02 Party keyed by PTY- (CW-132).
    ("01", "Model Portfolio", "Model Sponsor / Platform"): ("05", "Distributor Firm"),
    ("01", "Product Relationship", "Source Product"): PRODUCT,
    ("01", "Product Relationship", "Target Product"): PRODUCT,
    ("01", "Dealing Terms", "Dealing Calendar"): ("09", "Calendar"),
    ("01", "ETF Characteristics", "Index Tracked"): BENCHMARK,
    ("01", "Product Party Role", "Party"): PARTY,
    ("01", "Portfolio Manager Assignment", "Portfolio Manager"): EMPLOYEE,
    ("01", "Regulatory Authorization", "Competent Authority"): PARTY,
    ("01", "Product Governance", "Product Owner"): EMPLOYEE,
    ("01", "Product Governance", "Governing Body"): LEGAL_ENTITY,
    # "Product / Share Class" references are polymorphic; as in keys.py ("Direct Product / Share Class") they map to
    # the finer-grained Share Class. Product-level rows need their own link to Investment Product in the model.
    ("01", "Lifecycle Event", "Successor Product / Share Class"): SHARE_CLASS,
    ("01", "Performance Track Record", "Track Record Source"): SHARE_CLASS,
    ("01", "Investment Commentary", "Subject Strategy"): STRATEGY,
    # Polymorphic: a product or a mandate; the model resolves the mandate through 01 Investment Mandate.
    ("01", "Investment Commentary", "Subject Product / Mandate"): PRODUCT,
    ("01", "Investment Commentary", "Commentary Author"): EMPLOYEE,
    ("01", "Investment Commentary", "Translated From"): ("01", "Investment Commentary"),
    ("01", "Commentary Approval", "Investment Sign-Off By"): EMPLOYEE,
    ("01", "Commentary Approval", "Supersedes Commentary"): ("01", "Investment Commentary"),
    ("01", "Product Benchmark Assignment", "Assigned Product / Share Class"): SHARE_CLASS,
    ("01", "Product Benchmark Assignment", "Assigned Benchmark"): BENCHMARK,
    ("01", "Share Class", "Parent Product"): PRODUCT,
    ("01", "System Cross-Reference", "Source System"): ("41", "Application"),
    ("01", "Performance Fee", "Hurdle Benchmark"): BENCHMARK,
    # Platform Availability is owned by 05 (platform partners, re-cut at W4); until then it points at the 02 Party.
    ("01", "Distribution Availability", "Platform Availability"): PARTY,
    ("01", "Benchmark", "Benchmark Administrator"): PARTY,
    ("01", "Benchmark", "Blend Components"): BENCHMARK,
    # Service offerings, tiers and platform shelf
    ("01", "Service Offering", "Sponsoring Entity"): LEGAL_ENTITY,
    ("01", "Service Offering", "Model Portfolios Used"): ("01", "Model Portfolio"),
    ("01", "Offering Eligibility Rule", "Eligibility Offering"): OFFERING,
    ("01", "Offering Fee Schedule Link", "Linked Offering"): OFFERING,
    ("01", "Offering Fee Schedule Link", "Linked Fee Schedule"): ("47", "Fee Schedule"),
    ("01", "Platform Product Availability", "Available Share Class"): SHARE_CLASS,
    ("01", "Platform Product Availability", "Available Third-Party Instrument"): INSTRUMENT,
    ("01", "Platform Product Availability", "Due Diligence Approval"): ("52", "Product Due Diligence"),
    ("01", "Offering Window", "Window Feeder Product"): PRODUCT,
    ("01", "Management Fee", "Approving Board Resolution"): ("35", "Board Resolution"),
    ("01", "Platform Feature", "Eligible Offerings"): OFFERING,
    ("01", "Platform Feature", "Feature Governing Policy Rule"): ("01", "Tradable Universe Policy Rule"),

    # ------------------------------------------------------------------ 02 Client & Household
    # Party
    ("02", "Party", "Merged Into Party"): PARTY,
    ("02", "Party", "Employee Cross-Reference"): EMPLOYEE,
    ("02", "Legal Entity Hierarchy", "Subsidiary Party"): PARTY,
    ("02", "Legal Entity Hierarchy", "Direct Parent"): PARTY,
    ("02", "Legal Entity Hierarchy", "Ultimate Parent"): PARTY,
    ("02", "Party Role", "Role Party"): PARTY,
    ("02", "Retirement Plan", "Plan Sponsor"): PARTY,
    ("02", "Party Identifier", "Identified Party"): PARTY,
    # Household & relationships (households are parties, PTY-HH-)
    ("02", "Household", "Primary Member"): PARTY,
    ("02", "Household Membership", "Household"): PARTY,
    ("02", "Household Membership", "Household Member"): PARTY,
    ("02", "Party Relationship", "From Party"): PARTY,
    ("02", "Party Relationship", "To Party"): PARTY,
    ("02", "Authority Grant", "Grantor Party"): PARTY,
    ("02", "Authority Grant", "Authority Holder"): PARTY,
    ("02", "Authority Grant", "Accounts Covered"): ACCOUNT,
    ("02", "Authority Grant", "Intake Service Request"): SERVICE_REQUEST,
    ("02", "Trusted Contact Designation", "Designating Client"): PARTY,
    ("02", "Trusted Contact Designation", "Trusted Contact Person"): PARTY,
    ("02", "Trusted Contact Designation", "Account Scope"): ACCOUNT,
    ("02", "Death Notification", "Deceased Party"): PARTY,
    ("02", "Death Notification", "Estate Representative"): PARTY,
    ("02", "Death Notification", "Representative Authority Grant"): ("02", "Authority Grant"),
    ("02", "Death Notification", "Intake Service Request"): SERVICE_REQUEST,
    # Investor profile & suitability
    ("02", "Investor Profile", "Profile Client"): PARTY,
    ("02", "Investment Experience", "Experience Profile"): INVESTOR_PROFILE,
    ("02", "Investor Qualification", "Qualified Party"): PARTY,
    # KYC & due diligence
    ("02", "Onboarding Case", "Case Party"): PARTY,
    ("02", "Onboarding Case", "Related Accounts"): ACCOUNT,
    ("02", "Identity Verification", "Verified Party"): PARTY,
    ("02", "Identity Verification", "CIP Program Entity"): LEGAL_ENTITY,
    ("02", "Identity Verification", "Shared Evidence Verification"): IDV,
    ("02", "Beneficial Ownership Certification", "Certified Entity"): PARTY,
    ("02", "Beneficial Ownership Certification", "Certifying Individual"): PARTY,
    ("02", "Beneficial Ownership Certification", "Certifying Onboarding Case"): ("02", "Onboarding Case"),
    ("02", "Beneficial Ownership", "Ownership Certification"): ("02", "Beneficial Ownership Certification"),
    ("02", "Beneficial Ownership", "Beneficial Owner"): PARTY,
    ("02", "Beneficial Ownership", "Owner Identity Verification"): IDV,
    ("02", "Tax Profile", "Tax Status Evidence"): ("15", "Account Tax Certification"),
    # Classification & segmentation
    ("02", "Regulatory Classification", "Classified Party"): PARTY,
    ("02", "Segment Assignment", "Segmented Party"): PARTY,
    ("02", "Service Tier Assignment", "Tier Party"): PARTY,
    ("02", "Service Tier Assignment", "Assigned Service Tier"): ("01", "Service Tier"),
    ("02", "Service Tier Assignment", "Override Approver"): EMPLOYEE,
    # Contact points & preferences
    ("02", "Contact Point", "Contact Point Party"): PARTY,
    ("02", "Contact Preference", "Preference Holder"): PARTY,
    ("02", "Contact Preference", "Preferred Contact Point"): ("02", "Contact Point"),
    ("02", "Communication Preference", "Preference Party"): PARTY,
    ("02", "Communication Preference", "Preference Topic"): ("04", "Subscription Topic"),
    ("02", "Communication Preference", "Consent Record Reference"): ("02", "Consent Record"),
    # Privacy & consent
    ("02", "Privacy Profile", "Initial Privacy Notice"): ("13", "Shareholder Communication"),
    ("02", "Consent Record", "Consenting Party"): PARTY,
    ("02", "Consent Record", "Data Recipient"): PARTY,
    ("02", "Consumer Privacy Request", "Requesting Party"): PARTY,
    # Restrictions & vulnerable clients
    ("02", "Client Restriction", "Restricted Party"): PARTY,
    ("02", "Client Restriction", "Restricted Accounts"): ACCOUNT,
    ("02", "Client Restriction", "Excluded Instruments"): INSTRUMENT,
    ("02", "Restricted Client Status", "Status Party"): PARTY,
    ("02", "Restricted Client Status", "Related AML Case"): ("38", "AML Case"),
    ("02", "Restricted Client Status", "Status Approved By"): EMPLOYEE,
    ("02", "Specified Adult Status", "Determined By"): EMPLOYEE,
    ("02", "Vulnerability Concern", "Concern Party"): PARTY,
    ("02", "Vulnerability Concern", "Trusted Contact Designation Used"): ("02", "Trusted Contact Designation"),
    ("02", "Vulnerability Concern", "Escalation Case Reference"): ("08", "Senior Investor Case"),
}


# Unresolved references (left out of REFS: no object masters the target)
#   ("01", "Management Fee", "Fee Breakpoint Schedule")  <Reference (Fee Tier)>, owner 01
#       There is no Fee Tier / fee breakpoint object in the taxonomy. Add a "Fee Breakpoint Tier" object
#       (share class x tier sequence) to 01 or carry the schedule as a child group of Management Fee. 47 has merged,
#       but its Fee Schedule Tier is the client fee schedule, not a fund breakpoint schedule, so the gap stays open.
