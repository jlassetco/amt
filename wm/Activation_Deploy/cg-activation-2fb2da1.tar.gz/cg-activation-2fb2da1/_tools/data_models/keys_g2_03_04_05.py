"""Key and link registry extension for Data Domains 03 Sales, 04 Marketing & Digital and
05 Distribution Agreements & Partners. Same format and conventions as keys.py (CONTRACT.md section 1).

Notes are kept only where the choice is not obvious. "Scoped within <X>" means the object carries no attribute for
its owning X; the model completes the key with X's key. "Model gap" means the grain names something no attribute
carries.

W2-W4 merge (2026-10-15): this file now holds 04 Marketing, Digital & Client Engagement only. The 03 Sales and 05
Distribution Agreements & Partners entries moved to keys_w_03_05_08.py or were retired with the replaced modules
(CW-062, CW-131). The 04 W2 pass is applied: the 03/07 targets re-point to 03 Advisor Activity, Advisor and Coverage
Team, and the new acquisition, nudge, experiment, promotion, referral and survey objects are keyed.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


def _child_surrogate(obj, note=""):
    return dict(pk=[f"{obj} Key"], key_type="Surrogate", fold=False, note=note)


KEYS = {
    # ------------------------------------------------------------------ 04 Marketing, Digital & Client Engagement
    ("04", "Marketing Theme"): _k(["Theme ID"], "Natural"),
    ("04", "Messaging Pillar"): _child(["Key Message Statement"]),
    ("04", "Campaign"): _k(["Campaign ID"], "Natural"),
    ("04", "Campaign Targeting"): _fold(),
    ("04", "Campaign Budget"): _child(["Budget Currency"]),
    ("04", "Campaign Product"): _child(["Campaign Product / Share Class"]),
    ("04", "Campaign Tracking Code"): _child(["Tracked URL"], "The tagged URL carries the full UTM combination."),
    ("04", "Spend Line"): _child_surrogate("Spend Line", "Several lines can share a Spend Category; no line "
                                                         "identifier attribute."),
    ("04", "Campaign Member"): _k(["Member Party", "Member Lead"], "Composite",
                                  note="Scoped within Campaign, but no attribute carries the campaign: model gap. "
                                       "Member is a Party or, before matching, a Lead."),
    ("04", "Content Asset"): _k(["Asset ID"], "Natural"),
    ("04", "Asset Classification"): _fold(),
    ("04", "Audience Restriction"): _fold(),
    ("04", "Asset Rights"): _child_surrogate("Asset Rights", "No attribute identifies the licensed component."),
    ("04", "Asset Accessibility & Rendition"): _child_surrogate("Asset Accessibility & Rendition",
                                                                "No attribute identifies the rendition (format): "
                                                                "model gap."),
    ("04", "Asset Version"): _k(["Version Number"], "Composite",
                                note="Scoped within Content Asset, but no attribute carries the asset: model gap."),
    ("04", "Asset Compliance Reference"): _child(["Compliance Review Reference"]),
    ("04", "Marketing Event"): _k(["Event ID"], "Natural"),
    ("04", "Event Session"): _k(["Event Session Key"], "Surrogate",
                                note="Scoped within Marketing Event; no session identifier attribute."),
    ("04", "Event Speaker"): _child(["Speaker"]),
    ("04", "Event Registration"): _k(["Registrant Party"], "Composite",
                                     note="Scoped within Marketing Event, but no attribute carries the event: "
                                          "model gap."),
    ("04", "Digital Property"): _k(["Property ID"], "Natural"),
    ("04", "Web Page"): _k(["Page URL"], "Natural", note="The URL is the identifier."),
    ("04", "Web Form"): _k(["Form ID"], "Natural"),
    ("04", "Web Visitor / Known User"): _k(["Visitor ID", "Identity Namespace"], "Composite"),
    ("04", "Session"): _k(["Session ID"], "Natural"),
    ("04", "Engagement Event"): _k(["Event Visitor / Party", "Engagement Event Type", "Event Timestamp"],
                                   "Composite"),
    ("04", "Media Engagement"): _fold("Its grain is one media-view engagement event, i.e. the parent's grain."),
    ("04", "Engagement Score"): _k(["Engagement Score Party", "Engagement Score Model",
                                    "Score As-Of Date"], "Composite"),
    ("04", "Email Send"): _k(["Email Send Key"], "Surrogate", note="No deployment identifier attribute."),
    ("04", "Email Interaction"): _k(["Recipient Email Address"], "Composite",
                                    note="Scoped within Email Send, but no attribute carries the deployment: model "
                                         "gap. Email address, not Recipient Party, because recipients may be "
                                         "unmatched."),
    ("04", "Subscription Topic"): _k(["Subscription Topic ID"], "Natural"),
    ("04", "Suppression Entry"): _k(["Suppressed Identifier", "Suppression Scope"], "Composite"),
    ("04", "Marketing Lead"): _k(["Lead ID"], "Natural"),
    ("04", "Lead Qualification"): _child(["Lead Status Effective Timestamp"]),
    ("04", "Lead Assignment"): _child(["Assigned Advisor"], "No assignment timestamp; a reassignment back to the "
                                      "same advisor cannot be told apart."),
    ("04", "Lead Conversion"): _fold(),
    ("04", "Marketing Segment"): _k(["Segment ID"], "Natural"),
    ("04", "Segment Membership"): _k(["Member Party", "Membership Effective From"], "Composite",
                                     note="Scoped within Marketing Segment, but no attribute carries the segment: "
                                          "model gap."),
    ("04", "Social Media Account"): _k(["Social Account ID"], "Natural"),
    ("04", "Social Post"): _k(["Platform Post ID"], "Natural"),
    ("04", "Social Engagement Metrics"): _child_surrogate("Social Engagement Metrics",
                                                          "Grain names a metrics as-of date, which no attribute "
                                                          "carries: model gap."),
    ("04", "Social Listening Mention"): _k(["Social Listening Mention Key"], "Surrogate"),
    ("04", "Media Placement"): _k(["Placement ID"], "Natural"),
    ("04", "Paid Media Delivery"): _child_surrogate("Paid Media Delivery",
                                                    "Grain names a delivery date, which no attribute carries: "
                                                    "model gap."),
    ("04", "Marketing Touchpoint"): _k(["Touchpoint Party", "Touchpoint Type", "Touchpoint Timestamp"], "Composite"),
    ("04", "Attribution Model"): _k(["Attribution Model Key"], "Surrogate",
                                    note="Attribution Model Type alone is not unique if one type is run with "
                                         "different lookback windows."),
    ("04", "Attributed Outcome"): _k(["Attributed Milestone", "Attributed Campaign",
                                      "Applied Attribution Model"], "Composite"),
    ("04", "Marketing System"): _k(["System Name"], "Natural", note="The system name is the identifier."),
    # W2-W4 merge (2026-10-15): 04 objects restored or added
    ("04", "Digital Profile"): _k(["Digital Profile ID"], "Natural"),
    ("04", "Tracking Consent Choice"): _k(["Choice Visitor", "Choice Timestamp"], "Composite"),
    ("04", "Application Journey"): _k(["Journey ID"], "Natural"),
    ("04", "Acquisition Milestone"): _k(["Milestone Party", "Milestone Type", "Milestone Date",
                                         "Milestone Account"], "Composite",
                                        note="Milestone Account is empty for party-level milestones."),
    ("04", "Nudge Definition"): _k(["Nudge ID"], "Natural"),
    ("04", "Nudge Delivery"): _k(["Delivered Nudge", "Delivery Party", "Delivered Timestamp"], "Composite"),
    ("04", "Experiment"): _k(["Experiment ID"], "Natural"),
    ("04", "Experiment Assignment"): _k(["Assigned Experiment", "Assigned Visitor / Party"], "Composite"),
    ("04", "Promotion Offer"): _k(["Promotion ID"], "Natural"),
    ("04", "Promotion Enrollment"): _k(["Enrolled Promotion", "Enrolled Party", "Enrolled Account"], "Composite",
                                       note="Enrolled Account is empty for party-level enrollments."),
    ("04", "Client Referral"): _k(["Referral ID"], "Natural"),
    ("04", "Client Survey"): _k(["Survey ID"], "Natural"),
    ("04", "Survey Response"): _k(["Response ID"], "Natural"),
}


PARTY = ("02", "Party")
ACCOUNT = ("15", "Account")
EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
STRATEGY = ("01", "Investment Strategy")
SHARE_CLASS = ("01", "Share Class")
COMPLIANCE_REVIEW = ("08", "Compliance Review")
AGREEMENT = ("05", "Distribution Agreement")
CAMPAIGN = ("04", "Campaign")
CONTENT = ("04", "Content Asset")
LEAD = ("04", "Marketing Lead")
VISITOR = ("04", "Web Visitor / Known User")

# Polymorphic product references follow the pilot: "... / Share Class" points to Share Class (the finest grain, which
# rolls up to product and strategy); "Strategy / Product" points to Investment Strategy (consultant and institutional
# work is strategy-level); a model alternative needs its own link to Model Portfolio in the product model.
REFS = {
    # ------------------------------------------------------------------ 04 Marketing, Digital & Client Engagement
    ("04", "Marketing Theme", "Theme Strategies / Products"): STRATEGY,
    ("04", "Messaging Pillar", "Messaging Compliance Review"): COMPLIANCE_REVIEW,
    ("04", "Campaign", "Parent Campaign"): CAMPAIGN,
    ("04", "Campaign", "Campaign Owner"): EMPLOYEE,
    ("04", "Campaign", "Marketing Theme"): ("04", "Marketing Theme"),
    ("04", "Campaign", "Co-Marketing Agreement"): AGREEMENT,
    ("04", "Campaign Product", "Campaign Product / Share Class"): SHARE_CLASS,
    ("04", "Campaign Member", "Member Party"): PARTY,
    ("04", "Campaign Member", "Member Lead"): LEAD,
    ("04", "Content Asset", "Asset Owner"): EMPLOYEE,
    # Asset Authors and Event Speaker are Employee or external Party; mapped to the owner-domain case (Employee).
    # External authors / speakers need their own link to 02 Party in the model.
    ("04", "Content Asset", "Asset Authors"): EMPLOYEE,
    ("04", "Content Asset", "Publishing Entity"): LEGAL_ENTITY,
    ("04", "Content Asset", "Parent / Source Asset"): CONTENT,
    ("04", "Content Asset", "Source Commentary"): ("01", "Investment Commentary"),
    ("04", "Asset Classification", "Featured Products / Share Classes"): SHARE_CLASS,
    ("04", "Asset Compliance Reference", "Compliance Review Reference"): COMPLIANCE_REVIEW,
    ("04", "Marketing Event", "Organizer"): PARTY,
    ("04", "Marketing Event", "Owning Campaign"): CAMPAIGN,
    ("04", "Event Session", "Session Presentation Asset"): CONTENT,
    ("04", "Event Speaker", "Speaker"): EMPLOYEE,
    ("04", "Event Registration", "Registrant Party"): PARTY,
    ("04", "Event Registration", "Invited By Advisor"): ("03", "Advisor"),
    ("04", "Web Page", "Page Product / Share Class"): SHARE_CLASS,
    ("04", "Web Form", "Linked Campaign"): CAMPAIGN,
    ("04", "Web Visitor / Known User", "Matched Party"): PARTY,
    ("04", "Session", "Session Campaign"): CAMPAIGN,
    ("04", "Session", "Session Visitor"): VISITOR,
    # Visitor / Party: the visitor record carries the matched Party, so the visitor is the target.
    ("04", "Engagement Event", "Event Visitor / Party"): VISITOR,
    ("04", "Engagement Event", "Event Content Asset"): CONTENT,
    ("04", "Engagement Event", "Event Session"): ("04", "Session"),
    ("04", "Engagement Event", "Event Application Journey"): ("04", "Application Journey"),
    ("04", "Engagement Event", "Exposed Experiment"): ("04", "Experiment"),
    ("04", "Engagement Score", "Engagement Score Party"): PARTY,
    ("04", "Email Send", "Email Template Asset"): CONTENT,
    ("04", "Email Send", "Email Campaign"): CAMPAIGN,
    ("04", "Email Send", "Email Subscription Topic"): ("04", "Subscription Topic"),
    ("04", "Email Interaction", "Recipient Party"): PARTY,
    ("04", "Marketing Lead", "Lead Party"): PARTY,
    ("04", "Marketing Lead", "Original Campaign"): CAMPAIGN,
    ("04", "Lead Assignment", "First Sales Activity"): ("03", "Advisor Activity"),
    ("04", "Segment Membership", "Member Party"): PARTY,
    ("04", "Social Post", "Post Campaign"): CAMPAIGN,
    ("04", "Social Post", "Post Compliance Review"): COMPLIANCE_REVIEW,
    ("04", "Social Listening Mention", "Escalated Complaint"): ("08", "Complaint"),
    ("04", "Media Placement", "Placement Campaign"): CAMPAIGN,
    ("04", "Media Placement", "Ad Creative Asset"): CONTENT,
    ("04", "Marketing Touchpoint", "Touchpoint Party"): PARTY,
    ("04", "Marketing Touchpoint", "Touchpoint Campaign"): CAMPAIGN,
    # Source Event is an Engagement Event or a 03 Sales Activity; mapped to the owner-domain case.
    ("04", "Marketing Touchpoint", "Source Event"): ("04", "Engagement Event"),
    ("04", "Attributed Outcome", "Attributed Campaign"): CAMPAIGN,
    ("04", "Campaign Targeting", "Target Segments"): ("04", "Marketing Segment"),
    ("04", "Marketing System", "Inventoried Application"): ("41", "Application"),
    ("04", "Digital Profile", "Digital Profile Party"): PARTY,
    ("04", "Tracking Consent Choice", "Choice Visitor"): VISITOR,
    ("04", "Suppression Entry", "Revoked Consent Record"): ("02", "Consent Record"),
    ("04", "Lead Conversion", "Converted Party"): PARTY,
    ("04", "Lead Conversion", "Resulting Application Journey"): ("04", "Application Journey"),
    ("04", "Application Journey", "Journey Applicant Party"): PARTY,
    ("04", "Application Journey", "Resulting Onboarding Case"): ("02", "Onboarding Case"),
    ("04", "Application Journey", "Resulting Account"): ACCOUNT,
    ("04", "Acquisition Milestone", "Milestone Party"): PARTY,
    ("04", "Acquisition Milestone", "Milestone Account"): ACCOUNT,
    ("04", "Nudge Definition", "Nudge Content Asset"): CONTENT,
    ("04", "Nudge Definition", "Nudge Compliance Review"): COMPLIANCE_REVIEW,
    ("04", "Nudge Delivery", "Delivered Nudge"): ("04", "Nudge Definition"),
    ("04", "Nudge Delivery", "Delivery Party"): PARTY,
    ("04", "Nudge Delivery", "Linked Recommendation"): ("45", "Recommendation"),
    ("04", "Experiment", "Primary Metric"): ("21", "Metric Definition"),
    ("04", "Experiment Assignment", "Assigned Experiment"): ("04", "Experiment"),
    ("04", "Experiment Assignment", "Assigned Visitor / Party"): VISITOR,
    ("04", "Promotion Offer", "Promotion Campaign"): CAMPAIGN,
    ("04", "Promotion Offer", "Promotion Compliance Review"): COMPLIANCE_REVIEW,
    ("04", "Promotion Enrollment", "Enrolled Promotion"): ("04", "Promotion Offer"),
    ("04", "Promotion Enrollment", "Enrolled Party"): PARTY,
    ("04", "Promotion Enrollment", "Enrolled Account"): ACCOUNT,
    ("04", "Promotion Enrollment", "Award Fee Waiver"): ("47", "Fee Waiver"),
    ("04", "Client Referral", "Referrer Party"): PARTY,
    ("04", "Client Referral", "Referral Reward Enrollment"): ("04", "Promotion Enrollment"),
    ("04", "Survey Response", "Response Survey"): ("04", "Client Survey"),
    ("04", "Survey Response", "Respondent Party"): PARTY,
    ("04", "Survey Response", "Triggering Interaction"): ("13", "Contact Center Interaction"),
    ("04", "Survey Response", "Complaint Referral"): ("08", "Complaint"),
    ("04", "Attributed Outcome", "Attributed Milestone"): ("04", "Acquisition Milestone"),
    ("04", "Attributed Outcome", "Applied Attribution Model"): ("04", "Attribution Model"),
}

# Unresolved references after the W2-W4 merge (left out of REFS: no single object masters the target)
#   ("04", "Lead Assignment", "Assigned Advisor")  <Reference (Advisor / Coverage Team, 03)>
#       polymorphic Advisor / Coverage Team (03).
#   ("04", "Client Referral", "Referee Party")  <Reference (Party / Lead)>
#       polymorphic Party / Marketing Lead.
