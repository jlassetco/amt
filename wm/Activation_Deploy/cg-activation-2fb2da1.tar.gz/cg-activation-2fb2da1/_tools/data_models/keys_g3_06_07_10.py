"""Key and link registry, group 3: Data Domains 06, 07 and 10 (objects not already in keys.py). See CONTRACT.md section 1.

Same conventions as keys.py. "Scoped within <X>" means the object carries no attribute for its owning X; the model
completes the key with X's key. "Model gap" means the grain names something no attribute carries.

W2-W4 merge (2026-10-15): the 07 Compensation & Territory entries are deleted (CW-907; the coverage and incentive
objects 03 absorbed are keyed in keys_w_03_05_08.py). 06 follows the W4 06 pass: Position is renamed Fund Shareholder
Position (POS-, CW-151), Transaction Sales Charge is removed, Unattributed Item becomes a business object (UNA-), and
Account Asset Summary, Client Asset Measures and Account Channel Assignment are added. 10 follows the W4 10 pass:
Hierarchy Node becomes the Management Hierarchy Node group, the planning and allocation groups become child entities of
their parents, the Territory and Salesperson references are removed, and Client Revenue Record (CLREV-), Lifetime Value
Model (LTVM-), Pricing Scenario (PRSC-) and the other new 10 objects are keyed. DISTRIBUTOR and FIN_PRO point at the
restored 05 objects (CW-132).
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


KEYS = {
    # ------------------------------------------------------------------ 06 Client Assets, Flows & Channel Attribution
    ("06", "Transaction"): _k(["Transaction ID"], "Natural"),
    ("06", "Transaction Dates"): _fold(),
    ("06", "Transaction Amounts"): _fold(),
    ("06", "Order Source"): _fold(),
    ("06", "Intermediary As Delivered"): _fold(),
    ("06", "Linked Transaction"): _child(["Linked Transaction ID"]),
    ("06", "ETF Creation / Redemption"): _fold(),
    ("06", "SMA Flow"): _fold(),
    ("06", "Transaction Status"): _fold("Transaction is already one row per cancel/correct version, so the status "
                                        "version is the transaction row itself."),
    ("06", "Omnibus Look-Through"): _fold("The Position row is the sub-account position; the group records the "
                                          "omnibus parent it was looked through from."),
    ("06", "ETF Holding"): _fold("The DTC participant / custodian holding is loaded as the Position's account, so "
                                 "there is one ETF holding per position."),
    ("06", "Plan Position"): _fold("The Position row is the plan's account position; one plan per position."),
    ("06", "Sponsor-Reported Assets"): _fold("Sponsor-reported holdings are loaded as positions (Position Source = the "
                                             "sponsor feed); one sponsor record per position."),
    ("06", "Salesperson Credit"): _child(["Credited Salesperson", "Credit Role"]),
    ("06", "Attribution Method"): _fold(),
    ("06", "Unattributed Item"): _k(["Unattributed Item ID"], "Natural",
                                    note="UNA- suspense item; a business object since the W4 06 pass."),
    ("06", "Attribution Override"): _k(["Override ID"], "Natural"),
    ("06", "Identifier Crosswalk"): _k(["Source Feed", "Source Identifier Type", "Source Identifier Value",
                                        "Crosswalk Effective From"], "Composite"),
    ("06", "Match Rule"): _k(["Match Rule ID"], "Natural"),
    ("06", "Match Result"): _child(["Match Date"],
                                   "Grain also names the candidate party, which no attribute carries: model gap."),
    ("06", "Data Feed"): _k(["Feed ID"], "Natural"),
    ("06", "Load"): _k(["Load ID"], "Natural"),
    ("06", "Reconciliation"): _k(["Reconciliation ID"], "Natural"),
    ("06", "Reconciliation Run"): _child(["Run Business Date"]),
    ("06", "Break"): _k(["Break ID"], "Natural"),
    # W2-W4 merge (2026-10-15): 06 objects restored or added
    ("06", "Fund Shareholder Position"): _k(["Position ID"], "Natural",
                                            note="POS- (unchanged; renamed from Position, CW-151)."),
    ("06", "Account Asset Summary"): _k(["Summary Account", "Summary As-Of Date",
                                         "Summary Holding Type"], "Composite"),
    ("06", "Client Asset Measures"): _fold("A wide (pivoted) set of measure columns at the measure-set grain; it "
                                           "sits on the same Fact."),
    ("06", "Account Channel Assignment"): _k(["Channel Assignment ID"], "Natural"),

    # ------------------------------------------------------------- 10 Client Revenue, Pricing Economics & Profitability
    ("10", "Revenue Contract"): _k(["Revenue Contract ID"], "Natural"),
    ("10", "Performance Obligation"): _fold(),
    ("10", "Fee Revenue Record"): _k(["Fee Revenue Record ID"], "Natural"),
    ("10", "Performance Fee Record"): _k(["Performance Fee Record ID"], "Natural"),
    ("10", "Waiver Record"): _k(["Waiver Record ID"], "Natural"),
    ("10", "Contract Cost Asset"): _k(["Contract Cost Asset ID"], "Natural"),
    ("10", "Capitalization Assessment"): _child(["Assessed Cost Source"], "One current assessment per cost source; "
                                                "no date attribute carries re-assessments: model gap."),
    ("10", "Account Mapping"): _k(["Account Mapping ID"], "Natural"),
    ("10", "Cost Pool"): _k(["Cost Pool ID"], "Natural"),
    ("10", "Allocation Method"): _k(["Allocation Method ID"], "Natural"),
    ("10", "Allocation Driver"): _k(["Allocation Driver ID"], "Natural"),
    ("10", "Allocation Rule"): _k(["Allocation Rule ID"], "Natural"),
    ("10", "Allocation Run"): _k(["Allocation Run ID"], "Natural"),
    ("10", "Allocation Result"): _child(["Allocated Rule", "Target Dimension Member"]),
    ("10", "Profitability Record"): _k(["Profitability Record ID"], "Natural"),
    ("10", "Profitability Measure"): _fold(),
    ("10", "Profitability Measure Definition"): _k(["Profitability Measure Code"], "Natural",
                                                   note="The code is the identifier."),
    ("10", "Cost-to-Serve Profile"): _fold("One cost-to-serve profile per profitability record."),
    ("10", "Management Hierarchy"): _k(["Management Hierarchy ID"], "Natural"),
    ("10", "Hierarchy Restatement"): _k(["Restatement ID"], "Natural"),
    ("10", "Plan Version"): _k(["Plan Version ID"], "Natural"),
    ("10", "Plan Line"): _child(["Plan P&L Line", "Plan Cost Center", "Plan Dimension Members", "Plan Period"],
                                "Plan Dimension Members is multi-valued; models should split it into one column "
                                "per dimension."),
    ("10", "Flow & Revenue Forecast"): _child(["Forecast Share Class / Product", "Forecast Channel"],
                                              "Grain also names the plan period, which no attribute carries: model "
                                              "gap."),
    ("10", "Variance"): _child(["Compared Plan Version"], "Grain also names the P&L line, dimension members and "
                               "period, which no attribute carries: model gap."),
    ("10", "Intercompany Agreement"): _k(["Intercompany Agreement ID"], "Natural"),
    ("10", "TP Policy"): _fold(),
    ("10", "Intercompany Charge"): _k(["Intercompany Charge ID"], "Natural"),
    ("10", "Control"): _k(["Reconciliation Type", "Control Period"], "Composite"),
    # W2-W4 merge (2026-10-15): 10 objects restored or added
    ("10", "Client Revenue Record"): _k(["Client Revenue Record ID"], "Natural",
                                        note="CLREV- (account x revenue stream x month)."),
    ("10", "Cash Program Economics"): _k(["Economics Sweep Program", "Economics Program Bank",
                                          "Economics Period"], "Composite"),
    ("10", "Client Acquisition Cost Record"): _k(["Acquisition Channel", "Acquisition Campaign",
                                                  "Cohort Month"], "Composite",
                                                 note="Acquisition Campaign is empty for the channel-wide (ALL) "
                                                      "row."),
    ("10", "Lifetime Value Model"): _k(["Lifetime Value Model ID", "Lifetime Value Model Version"], "Composite",
                                       note="LTVM- x version."),
    ("10", "Client Lifetime Value Estimate"): _k(["Valued Household", "Valuation Model Version",
                                                  "Estimate As-Of Date"], "Composite"),
    ("10", "Pricing Scenario"): _k(["Pricing Scenario ID"], "Natural", note="PRSC-."),
    ("10", "Pricing Scenario Result"): _child(["Projection Year"]),
    ("10", "Management Hierarchy Node"): _child(["Node ID"]),
}


PARTY = ("02", "Party")
DISTRIBUTOR = ("05", "Distributor Firm")  # restored to 05 at W4 (CW-132)
FIN_PRO = ("05", "Financial Professional")  # restored to 05 at W4 (CW-132)
ACCOUNT = ("15", "Account")
EMPLOYEE = ("20", "Employee")
DATA_FEED = ("06", "Data Feed")
AGREEMENT = ("05", "Distribution Agreement")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
SHARE_CLASS = ("01", "Share Class")
PRODUCT = ("01", "Investment Product")
TRANSACTION = ("06", "Transaction")
MGMT_HIERARCHY = ("10", "Management Hierarchy")

REFS = {
    # ------------------------------------------------------------------ 06 Client Assets, Flows & Channel Attribution
    ("06", "Transaction", "Source Feed"): DATA_FEED,
    ("06", "Transaction", "Share Class"): SHARE_CLASS,
    ("06", "Transaction", "Product"): PRODUCT,
    ("06", "Transaction", "Account"): ACCOUNT,
    ("06", "Transaction", "Originating Fund Order"): ("29", "Fund Order"),
    ("06", "Transaction", "Originating AP Order"): ("29", "AP Creation / Redemption Order"),
    ("06", "Intermediary As Delivered", "Resolved Distributor Firm"): DISTRIBUTOR,
    ("06", "Intermediary As Delivered", "Resolved Office / Branch"): ("05", "Branch / Office"),
    ("06", "Intermediary As Delivered", "Resolved Advisor / Rep"): FIN_PRO,
    ("06", "Linked Transaction", "Linked Transaction ID"): TRANSACTION,
    ("06", "Linked Transaction", "Contra Share Class"): SHARE_CLASS,
    ("06", "Linked Transaction", "Contra Firm"): DISTRIBUTOR,
    ("06", "ETF Creation / Redemption", "Authorized Participant"): PARTY,
    ("06", "SMA Flow", "Sponsor Program"): AGREEMENT,
    ("06", "SMA Flow", "Model Portfolio"): ("01", "Model Portfolio"),
    ("06", "Transaction Status", "Original Transaction ID"): TRANSACTION,
    ("06", "Omnibus Look-Through", "Omnibus Parent Account"): ACCOUNT,
    ("06", "ETF Holding", "Holding Custodian / Broker"): PARTY,
    ("06", "Plan Position", "Retirement Plan"): ("02", "Retirement Plan"),
    ("06", "Plan Position", "Recordkeeper"): ("16", "Recordkeeper Profile"),
    ("06", "Plan Position", "Plan Advisor"): FIN_PRO,
    # Wrap / SMA sponsors are distributor firms (wirehouse or TAMP platforms).
    ("06", "Sponsor-Reported Assets", "Sponsor"): DISTRIBUTOR,
    ("06", "Salesperson Credit", "Credited Salesperson"): EMPLOYEE,
    ("06", "Salesperson Credit", "Source Partner Coverage Assignment"): ("05", "Partner Coverage Assignment"),
    ("06", "Attribution Method", "Attribution Source"): DATA_FEED,
    ("06", "Attribution Override", "Approved By"): EMPLOYEE,
    ("06", "Identifier Crosswalk", "Source Feed"): DATA_FEED,
    ("06", "Identifier Crosswalk", "Resolved Party"): PARTY,
    ("06", "Identifier Crosswalk", "Resolved Account"): ACCOUNT,
    ("06", "Match Rule", "Applicable Feeds"): DATA_FEED,
    ("06", "Match Result", "Match Rule Applied"): ("06", "Match Rule"),
    ("06", "Data Feed", "Data Provider"): PARTY,
    ("06", "Data Feed", "Governing Agreement"): AGREEMENT,
    ("06", "Load", "Feed"): DATA_FEED,
    ("06", "Reconciliation", "Left Source"): DATA_FEED,
    ("06", "Reconciliation", "Right Source"): DATA_FEED,
    ("06", "Order Source", "Source Client Account Activity"): ("49", "Client Account Activity"),
    ("06", "Order Source", "Source Account Transfer"): ("49", "Account Transfer"),
    ("06", "Order Source", "Source Register Transaction"): ("29", "Register Transaction"),
    ("06", "Order Source", "Source Participant Ledger Posting"): ("16", "Participant Ledger Posting"),
    ("06", "Order Source", "Source Portfolio Capital Activity"): ("18", "Portfolio Capital Activity"),
    ("06", "Order Source", "Source Channel Assignment"): ("06", "Account Channel Assignment"),
    ("06", "Fund Shareholder Position", "Account"): ACCOUNT,
    ("06", "Fund Shareholder Position", "Share Class"): SHARE_CLASS,
    ("06", "Fund Shareholder Position", "Source Client Holding"): ("49", "Client Holding"),
    ("06", "Fund Shareholder Position", "Source Share Register Balance"): ("29", "Share Register Balance"),
    ("06", "Fund Shareholder Position", "Valuation NAV"): ("27", "Share Class NAV"),
    ("06", "Fund Shareholder Position", "Position Source"): DATA_FEED,
    ("06", "Account Asset Summary", "Summary Account"): ACCOUNT,
    ("06", "Account Channel Assignment", "Assigned Account"): ACCOUNT,
    ("06", "Account Channel Assignment", "Basis Program Enrollment"): ("15", "Program Enrollment"),

    # ------------------------------------------------------------- 10 Client Revenue, Pricing Economics & Profitability
    ("10", "Revenue Contract", "Identified Customer"): PARTY,
    # Agreement / Mandate: mapped to the 01 mandate (example MND-); contracts based on a 05 agreement or a fund's
    # management agreement need their own link in the model.
    ("10", "Revenue Contract", "Underlying Agreement"): ("01", "Investment Mandate"),
    ("10", "Revenue Contract", "Contracting Legal Entity"): LEGAL_ENTITY,
    # Share Class / Mandate: mapped to the share class (fund revenue, the common case); mandate revenue needs its
    # own link to ("01", "Investment Mandate").
    ("10", "Fee Revenue Record", "Revenue Share Class / Mandate"): SHARE_CLASS,
    ("10", "Fee Revenue Record", "Sub-Adviser Engagement"): ("52", "Sub-Adviser Engagement"),
    ("10", "Performance Fee Record", "Performance Fee Share Class / Mandate"): SHARE_CLASS,
    ("10", "Waiver Record", "Supported Share Class"): SHARE_CLASS,
    # The expense cap terms (Expense Cap Rate, Waiver Expiry Date) are held in 01 Cost Disclosure.
    ("10", "Waiver Record", "Expense Cap Terms Reference"): ("01", "Cost Disclosure"),
    ("10", "Contract Cost Asset", "Related Revenue Contract"): ("10", "Revenue Contract"),
    ("10", "Contract Cost Asset", "Related Share Class"): SHARE_CLASS,
    ("10", "Contract Cost Asset", "Originating Cost Items"): ("10", "Distribution Cost Item"),
    # Polymorphic (Plan Component / Payment Arrangement). Mapped to the most common case, a sales commission
    # plan component (example ICP-...-C02); payment arrangements need their own link to ("05", "Payment Arrangement").
    ("10", "Cost Pool", "Contributing Cost Centers"): ("19", "Chart Segment Value"),  # typed Reference (Chart Segment Value) since CD-152
    ("10", "Allocation Rule", "Source Cost Pool"): ("10", "Cost Pool"),
    ("10", "Allocation Rule", "Applied Allocation Method"): ("10", "Allocation Method"),
    ("10", "Allocation Rule", "Applied Driver"): ("10", "Allocation Driver"),
    ("10", "Allocation Result", "Allocated Rule"): ("10", "Allocation Rule"),
    ("10", "Profitability Record", "Partner Firm"): DISTRIBUTOR,
    ("10", "Profitability Record", "Product / Share Class"): SHARE_CLASS,
    # Party / Account: mapped to the client party; account-level profitability needs its own link to Account.
    ("10", "Profitability Record", "Client / Account"): PARTY,
    ("10", "Profitability Record", "Reporting Legal Entity"): LEGAL_ENTITY,
    ("10", "Profitability Record", "Hierarchy Version"): MGMT_HIERARCHY,
    ("10", "Profitability Record", "Source Allocation Run"): ("10", "Allocation Run"),
    ("10", "Profitability Record", "Service Offering"): ("01", "Service Offering"),
    ("10", "Profitability Record", "Service Tier"): ("01", "Service Tier"),
    ("10", "Profitability Record", "Advisor"): ("03", "Advisor"),
    ("10", "Cost-to-Serve Profile", "Served Party"): PARTY,
    ("10", "Hierarchy Restatement", "Prior Hierarchy Version"): MGMT_HIERARCHY,
    ("10", "Plan Line", "Plan Cost Center"): ORG_UNIT,
    ("10", "Flow & Revenue Forecast", "Forecast Share Class / Product"): SHARE_CLASS,
    ("10", "Variance", "Compared Plan Version"): ("10", "Plan Version"),
    ("10", "Intercompany Agreement", "Service Provider Entity"): LEGAL_ENTITY,
    ("10", "Intercompany Agreement", "Service Recipient Entity"): LEGAL_ENTITY,
    ("10", "Intercompany Agreement", "Covered Products"): PRODUCT,
    ("10", "TP Policy", "Tested Party"): LEGAL_ENTITY,
    ("10", "TP Policy", "TP Documentation Reference"): ("19", "Transfer Pricing Documentation"),
    ("10", "Intercompany Charge", "Charging Agreement"): ("10", "Intercompany Agreement"),
    ("10", "Client Revenue Record", "Revenue Account / Household"): ACCOUNT,
    ("10", "Client Revenue Record", "Revenue Service Offering"): ("01", "Service Offering"),
    ("10", "Client Revenue Record", "Recognizing Legal Entity"): LEGAL_ENTITY,
    ("10", "Cash Program Economics", "Economics Sweep Program"): ("50", "Sweep Program"),
    ("10", "Cash Program Economics", "Economics Program Bank"): ("50", "Program Bank"),
    ("10", "Cash Program Economics", "Money Market Sweep Fund Revenue"): ("10", "Fee Revenue Record"),
    ("10", "Account Mapping", "GL Natural Account"): ("19", "GL Account"),
    ("10", "Account Mapping", "Applicable Ledger"): ("19", "Ledger"),
    ("10", "Client Acquisition Cost Record", "Acquisition Campaign"): ("04", "Campaign"),
    ("10", "Client Lifetime Value Estimate", "Valued Household"): PARTY,
    ("10", "Client Lifetime Value Estimate", "Valuation Model Version"): ("10", "Lifetime Value Model"),
    ("10", "Pricing Scenario", "Related Change Initiative"): ("36", "Product Change Initiative"),
    ("10", "Pricing Scenario", "Competitor Pricing Evidence"): ("11", "Competitor Pricing Observation"),
    ("10", "Management Hierarchy Node", "Parent Node"): ("10", "Management Hierarchy Node"),
    ("10", "Plan Version", "Enterprise Financial Plan Version"): ("19", "Financial Plan Version"),
}

# Unresolved references (left out of REFS: no single object masters the target)
#   ("19", "GL Posting", "Source Finance Record")  <Reference (FRR- / WVR- / DCO- / ACR- / CCA- / ARN- / ICC-)>, owner 10
#       (GL Posting moved from 10 to 19 under CD-152.)
#       Points to whichever finance record generated the journal line (Fee Revenue Record, Distribution Cost Item,
#       Accrual, Allocation Run, Intercompany Charge). Model it as a polymorphic lineage link or split it into typed
#       references.
#   ("10", "Allocation Result", "Target Dimension Member")  <Reference (Dimension Member)>, owner 02
#   ("10", "Plan Line", "Plan Dimension Members")  <Reference (Dimension Member) (multi)>, owner 02
#   ("10", "Management Hierarchy Node", "Leaf Member")  <Reference (Dimension Member)>, owner 10
#       "Dimension Member" is any member of a management dimension (channel code, partner PTY-, SHC-, TER-, OU-,
#       GEO-). There is no Dimension Member object; model a conformed dimension-member entity or typed references
#       per dimension.
#   ("10", "Performance Fee Record", "Performance Fee Terms Reference")  <Reference (Fund Fee Schedule, 01 / Fee
#       Schedule, 47)>
#       polymorphic 01 fund fee terms / 47 Fee Schedule.
#   ("10", "Client Revenue Record", "Source Calculation Record")  <Reference (Account Fee Calculation, 47 / Fee Invoice,
#       47 / Fee Debit, 47 / Fee Adjustment, 47 / Client Trade Confirmation, 48 / Client Account Activity, 49 / Fully
#       Paid Securities Loan, 49 / Sweep Allocation, 50) (multi)>
#       polymorphic over 47, 48, 49 and 50 source records.
#   ("10", "Pricing Scenario", "Priced Subject")  <Reference (Service Offering / Share Class)>
#       polymorphic 01 Service Offering / Share Class.
#   ("10", "Pricing Scenario", "Proposed Schedule Version")  <Reference (Fee Schedule, 47 / Proposed Term Change, 36)>
#       polymorphic 47 Fee Schedule / 36 Proposed Term Change.
#   ("10", "Capitalization Assessment", "Assessed Cost Source")  <Reference (Incentive Plan Component, 03 / Payment
#       Arrangement, 05)>
#       polymorphic 03 Incentive Plan Component / 05 Payment Arrangement.
