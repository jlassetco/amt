"""Key and link registry extension: Data Domains 08 Distribution Compliance and 09 Shared Reference Data.

Same format and conventions as keys.py (see CONTRACT.md section 1). Objects already in keys.py are not repeated.
Notes are kept only where the choice is not obvious. "Scoped within <X>" means the object carries no attribute for
its owning X; the model completes the key with X's key.

W2-W4 merge (2026-10-15): this file now holds 09 Shared & Enterprise Reference Data only. The 08 Distribution
Compliance entries moved to keys_w_03_05_08.py with the 08 Retail Conduct & Supervision module (CW-062) or were retired
with the dropped objects.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


KEYS = {
    # ------------------------------------------------------------------ 09 Shared & Enterprise Reference Data
    # Geography
    ("09", "Country"): _k(["Country Code (Alpha-2)"], "Natural"),
    ("09", "Country Subdivision"): _k(["Subdivision Code"], "Natural"),
    ("09", "Geographic Unit"): _k(["Geographic Unit ID"], "Natural"),
    ("09", "US County"): _fold(),
    ("09", "Core Based Statistical Area"): _fold("The delineation vintage is part of the Geographic Unit grain "
                                                 "(Scheme Vintage), so there is one row per unit."),
    ("09", "ZIP Code & ZCTA"): _fold(),
    # UK Postcode, ITL Region and NUTS Region removed by the 09 US-only pass (CW-909).
    ("09", "Geographic Hierarchy"): _k(["Geographic Hierarchy Type", "Parent Geographic Unit", "Child Geographic Unit",
                                        "Hierarchy Effective From"], "Composite"),
    ("09", "Geographic Group"): _k(["Geographic Group ID"], "Natural"),
    ("09", "Geographic Group Membership"): _k(["Member Geographic Unit", "Membership Effective From"], "Composite",
                                              note="Scoped within Geographic Group."),
    ("09", "Time Zone"): _k(["IANA Time Zone ID"], "Natural"),

    # Calendars
    ("09", "Calendar"): _k(["Calendar ID"], "Natural"),
    ("09", "Composite Calendar"): _k(["Component Calendar"], "Composite",
                                     note="Scoped within the composite Calendar."),
    ("09", "Calendar Date"): _k(["Calendar Date"], "Composite", note="Scoped within Calendar."),
    ("09", "Dealing Calendar Rule"): _fold(),
    ("09", "Fiscal Calendar"): _fold(),
    ("09", "Fiscal Period"): _k(["Fiscal Period ID"], "Natural"),

    # Currency, language, units
    ("09", "Currency"): _k(["Currency Code"], "Natural"),
    ("09", "Currency Pair Convention"): _k(["Currency Pair"], "Natural"),
    ("09", "FX Rate Type"): _k(["FX Rate Type Code"], "Natural"),
    ("09", "FX Rate Source"): _fold(),
    ("09", "Language"): _k(["Language Code (ISO 639-1)"], "Natural",
                           note="Languages without an ISO 639-1 code would need ISO 639-3 as the key."),
    ("09", "Locale"): _k(["Locale Tag"], "Natural"),
    ("09", "Number & Date Convention"): _fold(),
    ("09", "Unit of Measure"): _k(["Unit Code"], "Natural"),

    # Internal legal entities
    ("09", "Internal Legal Entity"): _k(["Legal Entity ID"], "Natural"),
    ("09", "Legal Entity Identifier"): _fold(),
    ("09", "Entity Ownership Relationship"): _k(["Child Entity", "Parent Entity", "Relationship Type",
                                                 "Ownership Effective From"], "Composite"),
    ("09", "Entity Distribution Role"): _k(["Role Entity", "Distribution Role", "Role Market Scope",
                                            "Role Effective From"], "Composite"),

    # Internal organization (the employee master moved to 20 under CD-151; see keys_g7_17_21.py)
    ("09", "Org Unit"): _k(["Org Unit ID"], "Natural"),
    ("09", "Cost & Profit Center"): _fold(),
    ("09", "Office Location"): _k(["Office ID"], "Natural"),
    ("09", "Org Hierarchy Link"): _k(["Org Hierarchy Type", "Parent Org Unit", "Child Org Unit",
                                      "Link Effective From"], "Composite"),
    ("09", "Reorganization Event"): _k(["Reorganization ID"], "Natural"),

    # Classifications and code lists
    ("09", "Classification Scheme"): _k(["Classification Scheme ID"], "Natural"),
    ("09", "Classification Code"): _k(["Classification Code"], "Natural",
                                      note="Scoped within Classification Scheme (version)."),
    ("09", "Classification Concordance"): _k(["Source Classification Code", "Target Classification Code"],
                                             "Composite"),
    ("09", "Code List"): _k(["Code List ID"], "Natural"),
    ("09", "Code List Consumer"): _k(["Consuming Domain", "Consuming Attribute"], "Composite",
                                     note="Scoped within Code List."),
    ("09", "Code List Version"): _k(["Code List Version ID"], "Natural"),
    ("09", "Code Value"): _k(["Code"], "Natural", note="Scoped within Code List Version."),
    ("09", "Code List Change Request"): _k(["Change Request Reference"], "Natural"),
    ("09", "Reference Data Subscription"): _k(["Reference Data Set", "Subscribing System"], "Composite"),
}


PARTY = ("02", "Party")
EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
CALENDAR = ("09", "Calendar")
GEO_UNIT = ("09", "Geographic Unit")

REFS = {
    # ------------------------------------------------------------------ 09 Shared & Enterprise Reference Data
    ("09", "Geographic Unit", "Successor Geographic Unit"): GEO_UNIT,
    ("09", "Geographic Hierarchy", "Parent Geographic Unit"): GEO_UNIT,
    ("09", "Geographic Hierarchy", "Child Geographic Unit"): GEO_UNIT,
    ("09", "Geographic Group Membership", "Member Geographic Unit"): GEO_UNIT,

    ("09", "Composite Calendar", "Component Calendar"): CALENDAR,
    ("09", "Dealing Calendar Rule", "Base Business Calendar"): CALENDAR,
    ("09", "Dealing Calendar Rule", "Market Closure Calendars"): CALENDAR,
    ("09", "FX Rate Type", "Publication Calendar"): CALENDAR,
    ("09", "FX Rate Source", "Licensed Dataset"): ("14", "Dataset"),

    ("09", "Internal Legal Entity", "Head Office Entity"): LEGAL_ENTITY,
    ("09", "Internal Legal Entity", "Party Master Cross-Reference"): PARTY,
    ("09", "Entity Ownership Relationship", "Child Entity"): LEGAL_ENTITY,
    ("09", "Entity Ownership Relationship", "Parent Entity"): LEGAL_ENTITY,
    ("09", "Entity Distribution Role", "Role Entity"): LEGAL_ENTITY,
    ("09", "Entity Distribution Role", "Role Market Scope"): ("09", "Geographic Group"),

    ("09", "Org Unit", "Employing / Booking Entity"): LEGAL_ENTITY,
    ("09", "Org Unit", "Unit Head"): EMPLOYEE,
    ("09", "Office Location", "Office Legal Entity"): LEGAL_ENTITY,
    ("09", "Org Hierarchy Link", "Parent Org Unit"): ORG_UNIT,
    ("09", "Org Hierarchy Link", "Child Org Unit"): ORG_UNIT,
    ("09", "Reorganization Event", "Source Org Units"): ORG_UNIT,
    ("09", "Reorganization Event", "Target Org Units"): ORG_UNIT,

    ("09", "Classification Concordance", "Source Classification Code"): ("09", "Classification Code"),
    ("09", "Classification Concordance", "Target Classification Code"): ("09", "Classification Code"),
    ("09", "Code List", "Data Owner"): EMPLOYEE,
    ("09", "Code List", "Data Steward"): EMPLOYEE,
    ("09", "Code List", "Current Version"): ("09", "Code List Version"),
    ("09", "Reference Data Subscription", "Reference Data Set"): ("09", "Code List"),
    ("09", "Cost & Profit Center", "Cost Center Code"): ("19", "Chart Segment Value"),
    ("09", "Cost & Profit Center", "Profit Center Code"): ("19", "Chart Segment Value"),
    ("09", "Reference Data Subscription", "Subscribing System"): ("41", "Application"),
}

# Unresolved references: none. Every "ref needed" attribute in 09 has a mastering object in the taxonomy.
