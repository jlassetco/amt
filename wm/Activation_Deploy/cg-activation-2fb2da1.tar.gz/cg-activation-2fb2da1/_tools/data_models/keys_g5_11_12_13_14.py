"""Key and link registry for Data Domains 11-14. See CONTRACT.md section 1 and keys.py (same format and conventions).

11 Market & Competitive Intelligence, 12 Institutional Client Servicing & Reporting, 13 Investor Servicing &
Shareholder Communications, 14 Third-Party Data & Licensing.

Notes are kept only where the choice is not obvious. "Scoped within <X>" means the object carries no attribute for
its owning X; the model completes the key with X's key.

W2-W4 merge (2026-10-15): INST_CLIENT points at the restored 12 Institutional Client and DISTRIBUTOR at the 05
Distributor Firm (CW-132, CW-133); 11 Mandate Search Event.Asset Owner stays on the 02 Party (prospects need not be
clients, CW-133 amendment). The 12 billing family moved to 47 (CW-052, keys_w_45_47.py) and FEE_INVOICE follows it;
Service Tier is now Institutional Service Tier, and Institutional Client, Investment Policy Statement (IPSV-), Mandate
Onboarding, OCIO Service Detail, Plan Sponsor Servicing Detail and Client Custodian Account (CUA-) are keyed. 11 follows
the W4 11 pass (Industry Ranking is a group of Market Share Record; Manager Rating removed; Competitor Offering and
Competitor Pricing Observation added). 13 follows the W2 13 pass: Trade Confirmation is replaced by Confirmation
Delivery, the EU/UK objects and Notice Cascade are removed, and the CW-088 objects moved to 29.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


KEYS = {
    # ------------------------------------------------------------------ 11 Market & Competitive Intelligence
    ("11", "Award"): _k(["Award ID"], "Natural"),
    ("11", "Category Mapping"): _k(["Category Scheme", "External Category Value", "Mapped Share Class",
                                    "Mapping Effective From"], "Composite"),
    ("11", "Competitor Distribution Footprint"): _child(["Channel"], "Market removed (CW-911)."),
    ("11", "Competitor Event"): _k(["Competitor Event ID"], "Natural"),
    ("11", "Competitor Metric Snapshot"): _child(["As-of Date"]),
    ("11", "Competitor Personnel Move"): _k(["Individual", "Move Date"], "Composite"),
    ("11", "Competitor Profile"): _k(["Competitor Profile ID"], "Natural"),
    ("11", "Fee Benchmark Result"): _fold(),
    ("11", "Fee Benchmark Study"): _k(["Fee Study ID"], "Natural"),
    ("11", "Industry Data Release"): _k(["Data Release ID"], "Natural"),
    ("11", "Industry Dataset Profile"): _k(["Licensed Dataset"], "Composite",
                                           note="An industry-data extension of 14 Dataset (1:1); the key is the "
                                                "Dataset ID."),
    ("11", "Industry Flow Observation"): _k(["Data Release", "Industry Category", "Distribution Channel", "Vehicle Type",
                                             "Region / Market", "Distributor Firm", "Fund Manager Firm",
                                             "Fund / Share Class"], "Composite",
                                            note="Dimension members not provided at the release's grain are null; "
                                                 "models should use an 'all / not applicable' member rather than "
                                                 "a null in the key."),
    ("11", "Industry Ranking"): _child(["Ranked Firm"], "Attribute group of Market Share Record (MSH- / Ranked "
                                       "Firm); the parent's Period End Date closes the old period gap."),
    ("11", "Intelligence Item"): _k(["Intelligence Item ID"], "Natural"),
    ("11", "Mandate Search Event"): _k(["Search Event ID"], "Natural"),
    ("11", "Market Research Report"): _k(["Research Report ID"], "Natural"),
    ("11", "Market Share Definition"): _k(["Share Definition Code"], "Natural"),
    ("11", "Market Share Record"): _k(["Market Share Record ID"], "Natural"),
    ("11", "Market Sizing Record"): _k(["Market Sizing Record ID"], "Natural"),
    ("11", "Market Trend"): _k(["Market Trend ID"], "Natural",
                               note="Grain is trend x indicator as-of date; add Indicator As-of Date to the key "
                                    "where the ID identifies the trend rather than the reading."),
    ("11", "Medalist Rating Detail"): _fold(),
    ("11", "Opportunity Potential"): _k(["Target Party", "Potential As-of Date"], "Composite"),
    ("11", "Peer Fund"): _k(["Peer Fund ID"], "Natural"),
    ("11", "Peer Metric Snapshot"): _k(["Snapshot Subject", "Snapshot Date", "Return Period",
                                        "Peer Universe"], "Composite",
                                       note="Own share class rows are Derived copies of 01/32 (row rule)."),
    ("11", "Peer Universe"): _k(["Peer Universe ID"], "Natural",
                                note="Grain is versioned by effective period; add Universe Effective From to the key "
                                     "where history is kept."),
    ("11", "Peer Universe Member"): _child(["Member Fund"]),
    ("11", "Plan Market Record"): _k(["Plan Party", "Form 5500 Plan Year"], "Composite"),
    ("11", "Pricing Input"): _fold(),
    ("11", "Rating Observation"): _k(["Rating Observation ID"], "Natural"),
    ("11", "Rating Scheme"): _k(["Rating Scheme Code"], "Natural", note="The code is the identifier."),
    ("11", "Regulatory Horizon Item"): _k(["Regulator / Body", "Regulatory Initiative"], "Composite"),
    ("11", "Sustainability Rating Detail"): _fold(),
    ("11", "Win/Loss Analysis"): _k(["Analysis Segment", "Analysis Period End"], "Composite"),
    # W2-W4 merge (2026-10-15): 11 objects restored or added
    ("11", "Competitor Offering"): _k(["Competitor Offering ID"], "Natural"),
    ("11", "Competitor Pricing Observation"): _k(["Priced Offering", "Price Component",
                                                  "Observation As-of Date", "Balance Tier Lower Bound"], "Composite",
                                                 note="Balance Tier Lower Bound is empty for untiered prices."),
    ("11", "Redistribution Restriction"): _fold(),

    # ------------------------------------------------------------------ 12 Institutional Client Servicing & Reporting
    ("12", "Breach Notification"): _k(["Breach Notification ID"], "Natural"),
    ("12", "Cash Flow Arrangement"): _k(["Arrangement Mandate"], "Composite", note="One per mandate."),
    ("12", "Cash Flow Notification"): _k(["Cash Flow Notification ID"], "Natural"),
    ("12", "Client Data Feed"): _k(["Client Data Feed ID"], "Natural"),
    ("12", "Client Review"): _k(["Client Review ID"], "Natural"),
    ("12", "Client Service Request"): _k(["Service Request ID"], "Natural"),
    ("12", "Compliance Certificate"): _k(["Certificate Period End"], "Composite",
                                         note="Scoped within Guideline Monitoring Arrangement (the monitored mandate), "
                                              "but no attribute carries the mandate: model gap."),
    ("12", "Distribution List"): _k(["Distribution List ID"], "Natural"),
    ("12", "GIPS Report Provision"): _child(["Related GIPS Composite"]),
    ("12", "Guideline Monitoring Arrangement"): _k(["Monitored Mandate"], "Composite", note="One per mandate."),
    ("12", "Portfolio Holdings Presentation"): _fold(),  # W5 ruling 3 rename
    ("12", "Mandate Termination"): _k(["Termination ID"], "Natural"),
    ("12", "Presentation Profile"): _k(["Presentation Profile ID"], "Natural"),
    ("12", "Relationship Health Score"): _k(["Scored Relationship", "Health Score Date"], "Composite"),
    ("12", "Report Component"): _k(["Component ID"], "Natural"),
    ("12", "Report Definition"): _k(["Report Definition ID"], "Natural"),
    ("12", "Report Delivery"): _k(["Delivered Run", "Delivery Recipient"], "Composite",
                                  note="Re-deliveries of the same run to the same recipient need Delivered Timestamp "
                                       "added to the key."),
    ("12", "Report Package"): _k(["Report Package ID"], "Natural"),
    ("12", "Report Run"): _k(["Report Run ID"], "Natural"),
    ("12", "Report Schedule"): _fold("One schedule per package (or definition); Scheduled Package / Report repeats "
                                     "the parent."),
    ("12", "Report Template"): _k(["Template ID"], "Natural"),
    ("12", "Service Coverage Assignment"): _k(["Service Assignment ID"], "Natural"),
    ("12", "Service Relationship"): _k(["Service Relationship ID"], "Natural"),
    ("12", "Service Standard"): _k(["Service Standard ID"], "Natural"),
    ("12", "Service Team"): _k(["Service Team ID"], "Natural"),
    ("12", "Transition Event"): _k(["Transition ID"], "Natural"),
    # W2-W4 merge (2026-10-15): 12 objects restored or added
    ("12", "Institutional Client"): _k(["Institutional Client Party"], "Composite",
                                       note="Role profile of the 02 Party; keyed by the PTY- reference (CW-133)."),
    ("12", "Investment Policy Statement"): _k(["IPS Version ID"], "Natural"),
    ("12", "OCIO Service Detail"): _fold(),
    ("12", "Plan Sponsor Servicing Detail"): _k(["Sponsor Service Relationship",
                                                 "Serviced Retirement Plan"], "Composite",
                                                note="SVR- / plan PTY-."),
    ("12", "Institutional Service Tier"): _k(["Service Tier Code"], "Natural", note="The code is the identifier."),
    ("12", "Mandate Onboarding"): _k(["Onboarded Mandate", "Onboarding Start Date"], "Composite",
                                     note="MND- / onboarding start date."),
    ("12", "Client Custodian Account"): _k(["Client Custodian Account Set-Up ID"], "Natural", note="CUA-."),

    # ------------------------------------------------------------------ 13 Client Service & Communications
    ("13", "Account Maintenance Change"): _child(["Maintained Data Element"]),
    # Account Standing Instruction moved to 15 Account (keys_g6_15_16.py).
    ("13", "Communication Distribution"): _k(["Distribution Job ID"], "Natural"),
    ("13", "Contact Center Interaction"): _k(["Interaction ID"], "Natural"),
    # Cost Basis Election moved to 15 Account (keys_g6_15_16.py), where it now carries account, share class and effective date.
    ("13", "Dormancy Assessment"): _k(["Dormancy Assessment Key"], "Surrogate",
                                      note="Grain is account x reporting state x assessment cycle; only the state "
                                           "(Owner State of Last Known Address) is carried: model gap."),
    ("13", "E-Delivery Election"): _k(["Delivery Election ID"], "Natural"),
    ("13", "Escheatment Report & Remittance"): _k(["Escheatment Report ID"], "Natural"),
    ("13", "Householding Group"): _k(["Householding Group ID"], "Natural"),
    ("13", "Intermediary Vote Instruction"): _k(["Voting Intermediary"], "Composite",
                                                note="Scoped within Proxy Proposal; grain also names an as-of date, "
                                                     "and no attribute carries the proposal or the date: model gap."),
    ("13", "Investor Document"): _k(["Investor Document ID"], "Natural"),
    ("13", "Investor Document Definition"): _k(["Document Definition Code"], "Natural"),
    ("13", "Lost Shareholder Status"): _k(["Status Account", "First Returned Mail Date"], "Composite",
                                          note="First Returned Mail Date stands in for the status-period start."),
    ("13", "Mail Hold"): _fold(),
    ("13", "Production Run"): _k(["Production Run ID"], "Natural"),
    ("13", "Prospectus Delivery"): _fold(),
    ("13", "Proxy Campaign"): _k(["Proxy Campaign ID"], "Natural"),
    ("13", "Proxy Proposal"): _k(["Proposal ID"], "Natural",
                                 note="Belongs to a Proxy Campaign, but no attribute carries the campaign: model gap."),
    ("13", "QA Review"): _k(["Reviewed Item"], "Composite",
                            note="Assumes one QA review per reviewed item; no review ID exists."),
    ("13", "Recipient Delivery Record"): _k(["Distribution Job", "Delivered Investor Document", "Recipient Account"],
                                            "Composite",
                                            note="Grain: distribution job x recipient account, or investor document x "
                                                 "recipient account; one of Distribution Job and Delivered Investor "
                                                 "Document is populated, the other needs a default member."),
    ("13", "Request Controls"): _fold(),
    ("13", "Service Level Definition"): _k(["SLA ID"], "Natural"),
    ("13", "Service Level Measurement"): _child(["Measurement Period"]),
    ("13", "Service Request"): _k(["Service Request ID"], "Natural"),
    ("13", "Servicing Error"): _k(["Servicing Error ID"], "Natural"),
    ("13", "Shareholder Communication"): _k(["Communication ID"], "Natural"),
    ("13", "Shareholder Notice"): _fold(),
    ("13", "Shareholder Remediation"): _k(["Remediation ID"], "Natural"),
    ("13", "Tailored Shareholder Report"): _fold(),
    ("13", "Tax Form Record"): _k(["Payer Fund", "Tax Year", "Tax Document Type", "Tax Form Version", "Form Box Code"],
                                  "Composite",
                                  note="Grain also names the account, which no attribute carries (Recipient TIN is "
                                       "masked and not a key): model gap."),
    ("13", "Transfer of Ownership & Estate"): _fold(),
    ("13", "Unclaimed Property Reclaim"): _k(["Reclaim ID"], "Natural"),
    ("13", "Vote Tally"): _k(["Tally As-Of Date"], "Composite",
                             note="Scoped within Proxy Proposal, but no attribute carries the proposal: model gap."),
    # W2-W4 merge (2026-10-15): 13 objects restored or added
    ("13", "Interaction Authentication"): _k(["Authenticated Interaction",
                                              "Authentication Attempt Number"], "Composite"),
    ("13", "Confirmation Delivery"): _child(["Client Trade Confirmation", "Confirmed Fund Order"],
                                            "Exactly one of the client trade confirmation or fund order is "
                                            "populated."),
    ("13", "Beneficial Owner Disclosure Election"): _k(["Disclosure Election Account",
                                                        "Disclosure Election Effective From"], "Composite"),
    ("13", "Voting Choice Election"): _k(["Voting Choice Election ID"], "Natural"),
    ("13", "Issuer Proxy Pass-Through"): _k(["Issuer Meeting", "Pass-Through Account"], "Composite"),

    # ------------------------------------------------------------------ 14 Third-Party Data & Licensing
    ("14", "Assurance Report"): _k(["Assurance Report Type", "Report Period End"], "Composite",
                                   note="Scoped within Data Vendor, but no attribute carries the vendor: model gap."),
    ("14", "Attribution Requirement"): _k(["Attribution Agreement", "Applies To Output Types"], "Composite"),
    ("14", "Commercial Terms"): _fold(),
    ("14", "Compliance Clauses"): _fold(),
    ("14", "Consuming Application"): _k(["Consuming Application ID"], "Natural"),
    ("14", "Data Cost Allocation"): _k(["Allocated Agreement", "Allocated Org Unit", "Allocation Effective From"],
                                       "Composite"),
    ("14", "Data Invoice"): _k(["Data Invoice ID"], "Natural"),
    ("14", "Data License Agreement"): _k(["Data License Agreement ID"], "Natural"),
    ("14", "Data Vendor"): _k(["Vendor Party"], "Composite",
                              note="A role of Party (1:1); the key is the Party ID, as for Distributor Firm."),
    ("14", "Dataset"): _k(["Dataset ID"], "Natural"),
    ("14", "Dataset Consumption"): _k(["Consumed Dataset", "Consuming Application", "Use Case",
                                       "Consumption Effective From"], "Composite"),
    ("14", "Dataset Coverage"): _fold(),
    ("14", "Dataset Delivery"): _fold(),
    ("14", "Dataset Key Field"): _k(["Field Name"], "Composite",
                                    note="Scoped within Dataset, but no attribute carries the dataset: model gap."),
    ("14", "Entitlement"): _k(["Entitlement ID"], "Natural"),
    ("14", "Market Data Subscriber"): _k(["Subscriber Client", "Subscriber Status Effective From"], "Composite",
                                         note="W1b addition (CW-914): client x status period; a change of "
                                              "professional or non-professional status is a new row."),
    # ICT Third-Party Register Entry removed (DORA register of information; CW-914).
    ("14", "Index Product Coverage"): _k(["Covered Product", "Covered Share Class", "Coverage Effective From"],
                                         "Composite",
                                         note="Scoped within Index Use, but no attribute carries it: model gap. "
                                              "Covered Share Class is null for product-level coverage."),
    ("14", "Index Use"): _k(["Index License Agreement", "Licensed Index", "Index Use Type"], "Composite"),
    ("14", "License Audit"): _k(["License Audit ID"], "Natural"),
    ("14", "License Compliance Finding"): _k(["Finding Reference"], "Natural",
                                             note="Scoped within License Audit, but no attribute carries the audit: "
                                                  "model gap."),
    ("14", "Licensed Dataset Schedule"): _k(["Licensed Dataset", "Scope Effective From"], "Composite",
                                            note="Scoped within Data License Agreement, but no attribute carries the "
                                                 "agreement: model gap."),
    ("14", "Permitted Use Grant"): _k(["Grant Agreement", "Grant Dataset", "Permitted Use Category",
                                       "Grant Effective From"], "Composite"),
    ("14", "Renewal Case"): _k(["Renewal Case ID"], "Natural"),
    ("14", "Termination Obligations"): _fold(),
    ("14", "Usage Declaration"): _k(["Usage Declaration ID"], "Natural"),
    ("14", "Vendor Contact Role"): _k(["Vendor Contact", "Vendor Contact Role Type", "Contact Role Effective From"],
                                      "Composite",
                                      note="Scoped within Data Vendor, but no attribute carries the vendor: model gap."),
    ("14", "Vendor Data Issue"): _k(["Vendor Data Issue ID"], "Natural"),
    ("14", "Vendor Data SLA"): _k(["SLA Dataset", "SLA Metric", "Measurement Period"], "Composite"),
    ("14", "Vendor Performance Review"): _k(["Review Period"], "Composite",
                                            note="Scoped within Data Vendor, but no attribute carries the vendor: "
                                                 "model gap."),
    ("14", "Vendor Risk Assessment"): _k(["Risk Assessment ID"], "Natural"),
}


PARTY = ("02", "Party")
DISTRIBUTOR = ("05", "Distributor Firm")  # restored to 05 at W4 (CW-132)
ACCOUNT = ("15", "Account")
CONTACT_POINT = ("02", "Contact Point")  # wealth 02 contact point (CTP-); replaces Contact Point Address / Email / Phone (CW-021)
INST_CLIENT = ("12", "Institutional Client")  # restored to 12 at W4 (CW-133)
EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
STRATEGY = ("01", "Investment Strategy")
PRODUCT = ("01", "Investment Product")
SHARE_CLASS = ("01", "Share Class")
MANDATE = ("01", "Investment Mandate")
BENCHMARK = ("01", "Benchmark")
AGREEMENT = ("05", "Distribution Agreement")
TRANSACTION = ("06", "Transaction")
COMPLAINT = ("08", "Complaint")
COMPLIANCE_REVIEW = ("08", "Compliance Review")
COMPETITOR = ("11", "Competitor Profile")
PEER_FUND = ("11", "Peer Fund")
SERVICE_REL = ("12", "Service Relationship")
REPORT_PACKAGE = ("12", "Report Package")
REPORT_RUN = ("12", "Report Run")
FEE_INVOICE = ("47", "Fee Invoice")  # moved from 12 to 47 (CW-052)
SHAREHOLDER_COMM = ("13", "Shareholder Communication")
DLA = ("14", "Data License Agreement")
DATASET = ("14", "Dataset")
DATA_VENDOR = ("14", "Data Vendor")

REFS = {
    # ------------------------------------------------------------------ 11 Market & Competitive Intelligence
    # Recipient is polymorphic (Share Class / Peer Fund / Competitor Profile / Party). Mapped to the taxonomy owner
    # (01, own share classes); peer and firm awards need their own link in the model.
    ("11", "Award", "Recipient"): SHARE_CLASS,
    ("11", "Award", "Citation Approval"): COMPLIANCE_REVIEW,
    ("11", "Category Mapping", "Mapped Share Class"): SHARE_CLASS,
    ("11", "Competitor Distribution Footprint", "Key Distribution Partners"): DISTRIBUTOR,
    ("11", "Competitor Event", "Competitor"): COMPETITOR,
    ("11", "Competitor Event", "Affected Peer Funds"): PEER_FUND,
    ("11", "Competitor Personnel Move", "Individual"): PARTY,
    ("11", "Competitor Personnel Move", "From Competitor"): COMPETITOR,
    ("11", "Competitor Personnel Move", "To Competitor"): COMPETITOR,
    ("11", "Competitor Personnel Move", "Affected Strategies / Funds"): PEER_FUND,
    ("11", "Competitor Profile", "Competitor Party"): PARTY,
    ("11", "Competitor Profile", "Competing Strategies"): STRATEGY,
    ("11", "Fee Benchmark Study", "Subject Share Class"): SHARE_CLASS,
    ("11", "Fee Benchmark Study", "Peer Universe"): ("11", "Peer Universe"),
    ("11", "Fee Benchmark Study", "Subject Service Offering"): ("01", "Service Offering"),
    ("11", "Fee Benchmark Study", "Subject Fee Schedule"): ("47", "Fee Schedule"),
    ("11", "Fee Benchmark Study", "Comparison Offerings"): ("11", "Competitor Offering"),
    ("11", "Industry Data Release", "Supersedes Release"): ("11", "Industry Data Release"),
    ("11", "Industry Data Release", "Source Load"): ("06", "Load"),
    ("11", "Industry Dataset Profile", "Licensed Dataset"): DATASET,
    ("11", "Industry Flow Observation", "Data Release"): ("11", "Industry Data Release"),
    ("11", "Industry Flow Observation", "Distributor Firm"): DISTRIBUTOR,
    ("11", "Industry Flow Observation", "Fund Manager Firm"): COMPETITOR,
    # Peer Fund / Share Class: mapped to the owner (11, Peer Fund); rows for own share classes link via Share Class.
    ("11", "Industry Flow Observation", "Fund / Share Class"): PEER_FUND,
    ("11", "Industry Ranking", "Ranked Firm"): COMPETITOR,
    ("11", "Intelligence Item", "Linked Competitors"): COMPETITOR,
    ("11", "Intelligence Item", "Linked Own Products"): PRODUCT,  # Strategy / Product: mapped to the product
    ("11", "Mandate Search Event", "Asset Owner"): PARTY,
    ("11", "Mandate Search Event", "Consultant"): ("05", "Consultant Profile"),
    ("11", "Mandate Search Event", "Winning / Hired Manager"): COMPETITOR,
    ("11", "Mandate Search Event", "Terminated Manager"): COMPETITOR,
    ("11", "Mandate Search Event", "Linked Opportunity"): ("05", "Sales Opportunity"),
    ("11", "Market Research Report", "Licensed Dataset"): DATASET,
    ("11", "Market Share Definition", "Denominator Dataset"): DATASET,
    ("11", "Market Share Record", "Share Definition"): ("11", "Market Share Definition"),
    ("11", "Market Share Record", "Distributor Firm"): DISTRIBUTOR,
    ("11", "Market Sizing Record", "Geography"): ("09", "Geographic Unit"),
    ("11", "Market Sizing Record", "Source Dataset"): DATASET,
    ("11", "Market Trend", "Evidence Reports"): ("11", "Market Research Report"),
    ("11", "Opportunity Potential", "Target Party"): PARTY,
    ("11", "Peer Fund", "Managing Firm"): COMPETITOR,
    ("11", "Peer Metric Snapshot", "Peer Universe"): ("11", "Peer Universe"),
    ("11", "Peer Metric Snapshot", "Snapshot Subject"): PEER_FUND,
    ("11", "Peer Universe", "Own Strategy Compared"): STRATEGY,
    ("11", "Peer Universe Member", "Member Fund"): PEER_FUND,  # Peer Fund / Share Class: mapped to the owner (11)
    ("11", "Plan Market Record", "Plan Party"): ("02", "Retirement Plan"),
    ("11", "Plan Market Record", "Recordkeeper"): PARTY,
    # Share Class / Peer Fund: mapped to the taxonomy owner (01); peer-fund ratings need their own link.
    ("11", "Rating Observation", "Rated Share Class / Fund"): SHARE_CLASS,
    ("11", "Win/Loss Analysis", "Most Frequent Winning Competitor"): COMPETITOR,
    ("11", "Competitor Offering", "Offering Competitor"): COMPETITOR,
    ("11", "Competitor Offering", "Comparable Own Offering"): ("01", "Service Offering"),
    ("11", "Competitor Pricing Observation", "Priced Offering"): ("11", "Competitor Offering"),
    ("11", "Regulatory Horizon Item", "Source Intelligence Items"): ("11", "Intelligence Item"),

    # ------------------------------------------------------------------ 12 Institutional Client Servicing & Reporting
    ("12", "Breach Notification", "Breached Mandate"): MANDATE,
    ("12", "Breach Notification", "Breached Restriction"): ("01", "Investment Restriction"),
    ("12", "Breach Notification", "Related Investment Breach"): ("33", "Investment Breach"),
    ("12", "Cash Flow Arrangement", "Arrangement Mandate"): MANDATE,
    ("12", "Cash Flow Notification", "Notified Mandate"): MANDATE,
    ("12", "Cash Flow Notification", "Authorized Signatory"): PARTY,
    ("12", "Cash Flow Notification", "Linked Transaction"): TRANSACTION,
    ("12", "Client Data Feed", "Feed Recipient"): PARTY,
    ("12", "Client Data Feed", "Data-Sharing Agreement"): AGREEMENT,
    ("12", "Client Review", "Reviewed Relationship"): SERVICE_REL,
    ("12", "Client Review", "Reviewed Mandates"): MANDATE,
    ("12", "Client Review", "Meeting Activity"): ("03", "Advisor Activity"),
    ("12", "Client Review", "Reviewed IPS Version"): ("12", "Investment Policy Statement"),
    ("12", "Client Service Request", "Requesting Party"): PARTY,
    ("12", "Client Service Request", "Request Service Relationship"): SERVICE_REL,
    ("12", "Client Service Request", "Request Mandate"): MANDATE,
    ("12", "Client Service Request", "Request Owner"): EMPLOYEE,
    ("12", "Client Service Request", "Related Complaint"): COMPLAINT,
    ("12", "Compliance Certificate", "Certifying Officer"): EMPLOYEE,
    ("12", "Compliance Certificate", "Certified Mandate"): MANDATE,
    ("12", "Distribution List", "Distribution Package"): REPORT_PACKAGE,
    ("12", "Distribution List", "Recipient"): PARTY,
    ("12", "Distribution List", "Delivery Contact Point"): CONTACT_POINT,
    ("12", "GIPS Report Provision", "Related GIPS Composite"): ("01", "GIPS Composite"),
    ("12", "Guideline Monitoring Arrangement", "Monitored Mandate"): MANDATE,
    ("12", "Guideline Monitoring Arrangement", "Monitored Restrictions"): ("01", "Investment Restriction"),
    ("12", "Mandate Termination", "Terminated Mandate"): MANDATE,
    ("12", "Mandate Termination", "Transition-Out Event"): ("12", "Transition Event"),
    ("12", "Mandate Termination", "Final Report Run"): REPORT_RUN,
    ("12", "Mandate Termination", "Final Invoice"): FEE_INVOICE,
    # Report Package / Mandate: mapped to the owner (12, Report Package); mandate-level profiles need their own link.
    ("12", "Presentation Profile", "Applies To Package / Mandate"): REPORT_PACKAGE,
    ("12", "Presentation Profile", "Primary Benchmark Shown"): BENCHMARK,
    ("12", "Relationship Health Score", "Scored Relationship"): SERVICE_REL,
    ("12", "Relationship Health Score", "Survey Inputs"): ("04", "Survey Response"),
    ("12", "Report Definition", "Report Template"): ("12", "Report Template"),
    ("12", "Report Delivery", "Delivered Run"): REPORT_RUN,
    ("12", "Report Delivery", "Delivery Recipient"): PARTY,
    ("12", "Report Package", "Package Client"): SERVICE_REL,
    ("12", "Report Package", "Included Report Definitions"): ("12", "Report Definition"),
    ("12", "Report Package", "Covered Mandates / Vehicles"): MANDATE,
    ("12", "Report Package", "Covered Retirement Plans"): ("02", "Retirement Plan"),
    # Report Package / Report Definition: mapped to the package (the usual unit of production).
    ("12", "Report Run", "Run Package / Report"): REPORT_PACKAGE,
    ("12", "Report Run", "Signed Off By"): EMPLOYEE,
    ("12", "Report Run", "Compliance Review"): COMPLIANCE_REVIEW,
    ("12", "Report Run", "Commentary Used"): ("01", "Investment Commentary"),
    ("12", "Report Schedule", "Scheduled Package / Report"): REPORT_PACKAGE,
    ("12", "Report Schedule", "Business Calendar"): ("09", "Calendar"),
    ("12", "Report Template", "Brand"): ("42", "Brand"),
    ("12", "Service Coverage Assignment", "Assigned Service Employee"): EMPLOYEE,
    ("12", "Service Coverage Assignment", "Covered Service Relationship"): SERVICE_REL,
    ("12", "Service Coverage Assignment", "Covered Mandate"): MANDATE,
    ("12", "Service Coverage Assignment", "Service Team"): ("12", "Service Team"),
    ("12", "Service Relationship", "Client"): INST_CLIENT,
    ("12", "Service Relationship", "Serviced Mandates"): MANDATE,
    ("12", "Service Relationship", "Advising Consultant"): ("05", "Consultant Advisory Relationship"),
    ("12", "Service Relationship", "Servicing Legal Entity"): LEGAL_ENTITY,
    ("12", "Service Relationship", "Serviced Pooled Vehicles"): SHARE_CLASS,
    # Service Tier / Service Relationship: mapped to the tier (standard case); contractual relationship-specific
    # standards need their own link.
    ("12", "Service Standard", "Applies To Tier / Relationship"): ("12", "Institutional Service Tier"),
    ("12", "Service Team", "Service Team Lead"): EMPLOYEE,
    ("12", "Transition Event", "Transition Mandate"): MANDATE,
    ("12", "Transition Event", "Transition Manager"): PARTY,
    ("12", "Institutional Client", "Institutional Client Party"): PARTY,
    ("12", "Investment Policy Statement", "IPS Client"): INST_CLIENT,
    ("12", "Investment Policy Statement", "Policy Allocation"): ("24", "Asset Allocation Policy"),
    ("12", "Investment Policy Statement", "Governed Mandates"): MANDATE,
    ("12", "OCIO Service Detail", "OCIO Service Offering"): ("01", "Service Offering"),
    ("12", "OCIO Service Detail", "Managers in Scope"): ("52", "Sub-Adviser Engagement"),
    ("12", "OCIO Service Detail", "Governing IPS"): ("12", "Investment Policy Statement"),
    ("12", "Plan Sponsor Servicing Detail", "Sponsor Service Relationship"): SERVICE_REL,
    ("12", "Plan Sponsor Servicing Detail", "Serviced Retirement Plan"): ("02", "Retirement Plan"),
    ("12", "Plan Sponsor Servicing Detail", "Recordkeeping Service Arrangement"): ("16", "Service Arrangement"),
    ("12", "Plan Sponsor Servicing Detail", "Plan Fiduciary Committee"): ("16", "Plan Role Assignment"),
    ("12", "Mandate Onboarding", "Onboarded Mandate"): MANDATE,
    ("12", "Mandate Onboarding", "Won Opportunity"): ("05", "Sales Opportunity"),
    ("12", "Mandate Onboarding", "Onboarding Service Relationship"): SERVICE_REL,
    ("12", "Mandate Onboarding", "Investment Management Agreement"): ("39", "Contract"),
    ("12", "Mandate Onboarding", "Opened Account"): ACCOUNT,
    ("12", "Mandate Onboarding", "Client Custodian Set-Up"): ("12", "Client Custodian Account"),
    ("12", "Mandate Onboarding", "Onboarding Owner"): EMPLOYEE,
    ("12", "Client Custodian Account", "Client Account"): ACCOUNT,
    ("12", "Client Custodian Account", "Client Custodian Mandate"): MANDATE,
    ("12", "Client Custodian Account", "Custodian"): PARTY,
    ("12", "Client Custodian Account", "Created Safekeeping Account"): ("28", "Safekeeping Account"),
    ("12", "Client Custodian Account", "Created Standing Settlement Instructions"):
        ("26", "Standing Settlement Instruction"),

    # ------------------------------------------------------------------ 13 Client Service & Communications
    ("13", "Account Maintenance Change", "Updated Master Record"): ACCOUNT,  # Party / Account: mapped to the account
    ("13", "Account Maintenance Change", "Change Notification Document"): ("13", "Investor Document"),
    ("13", "Communication Distribution", "Distributed Communication"): SHAREHOLDER_COMM,
    ("13", "Contact Center Interaction", "Interaction Account"): ACCOUNT,
    ("13", "Contact Center Interaction", "Linked Service Request"): ("13", "Service Request"),
    ("13", "Contact Center Interaction", "Interaction Party"): PARTY,
    ("13", "Contact Center Interaction", "Interaction Agent"): EMPLOYEE,
    ("13", "E-Delivery Election", "Election Account"): ACCOUNT,
    ("13", "E-Delivery Election", "Delivery Email Contact Point"): CONTACT_POINT,
    ("13", "E-Delivery Election", "Linked Consent Record"): ("02", "Consent Record"),
    ("13", "Householding Group", "Member Accounts"): ACCOUNT,
    ("13", "Householding Group", "Householding Address"): ("02", "Postal Address"),
    # Communication / Proxy Campaign: mapped to the communication; proxy-campaign fees need their own link.
    ("13", "Intermediary Vote Instruction", "Voting Intermediary"): PARTY,
    ("13", "Investor Document", "Document Definition"): ("13", "Investor Document Definition"),
    ("13", "Investor Document", "Document Account"): ACCOUNT,
    ("13", "Investor Document", "Document Recipient"): PARTY,
    ("13", "Investor Document", "Original Document"): ("13", "Investor Document"),
    ("13", "Investor Document", "Issuing Entity"): LEGAL_ENTITY,
    ("13", "Lost Shareholder Status", "Status Account"): ACCOUNT,
    ("13", "Lost Shareholder Status", "Searching Entity"): LEGAL_ENTITY,
    ("13", "Production Run", "Print / Delivery Vendor"): PARTY,
    ("13", "Proxy Campaign", "Registrant / Fund"): PRODUCT,
    ("13", "Proxy Campaign", "Solicitation Agent"): PARTY,
    # Service Request / Interaction: mapped to the service request; interaction QA needs its own link.
    ("13", "QA Review", "Reviewed Item"): ("13", "Service Request"),
    ("13", "Recipient Delivery Record", "Recipient Account"): ACCOUNT,
    ("13", "Recipient Delivery Record", "Distribution Job"): ("13", "Communication Distribution"),
    ("13", "Recipient Delivery Record", "Delivered Investor Document"): ("13", "Investor Document"),
    ("13", "Service Request", "Account"): ACCOUNT,
    ("13", "Service Request", "Requesting Party"): PARTY,
    ("13", "Service Request", "Servicing Provider"): PARTY,
    ("13", "Service Request", "Escalated Complaint"): COMPLAINT,
    ("13", "Service Request", "Assisting Advisor"): ("03", "Advisor"),
    ("13", "Service Request", "Originating Advisor Activity"): ("03", "Advisor Activity"),
    ("13", "Service Request", "Resulting Order"): ("29", "Fund Order"),
    ("13", "Service Request", "Resulting Client Account Activity"): ("49", "Client Account Activity"),
    ("13", "Service Request", "Resulting Money Movement"): ("50", "Money Movement"),
    ("13", "Servicing Error", "Responsible Party"): PARTY,
    ("13", "Servicing Error", "Correction Transactions"): ("29", "Register Transaction"),
    ("13", "Servicing Error", "Related NAV Error Case"): ("27", "NAV Error Case"),
    ("13", "Shareholder Communication", "Covered Share Classes"): SHARE_CLASS,
    ("13", "Shareholder Communication", "Source Product Document"): ("01", "Product Document"),
    ("13", "Shareholder Communication", "Triggering Lifecycle Event"): ("01", "Lifecycle Event"),
    ("13", "Shareholder Communication", "Communicating Entity"): LEGAL_ENTITY,
    ("13", "Shareholder Communication", "Source Plan Notice"): ("16", "Plan Notice"),
    ("13", "Shareholder Remediation", "Remediated Account"): ACCOUNT,
    ("13", "Shareholder Remediation", "Remediation Money Movement"): ("50", "Money Movement"),
    ("13", "Tax Form Record", "Payer Fund"): PRODUCT,
    ("13", "Tax Form Record", "Tax Form Account"): ACCOUNT,
    ("13", "Tax Form Record", "Payer Entity"): LEGAL_ENTITY,
    ("13", "Unclaimed Property Reclaim", "Claimant"): PARTY,
    ("13", "Transfer of Ownership & Estate", "Related Death Notification"): ("02", "Death Notification"),
    ("13", "Transfer of Ownership & Estate", "Claimed Beneficiary Designation"): ("15", "Beneficiary Designation"),
    ("13", "Transfer of Ownership & Estate", "Estate Settlement Case"): ("51", "Estate Settlement Case"),
    ("13", "Transfer of Ownership & Estate", "Deceased-Account Restriction"): ("15", "Account Restriction"),
    ("13", "Interaction Authentication", "Authenticated Interaction"): ("13", "Contact Center Interaction"),
    ("13", "Interaction Authentication", "Authenticated Party"): PARTY,
    ("13", "Interaction Authentication", "Linked Identity Verification"): ("02", "Identity Verification"),
    ("13", "Confirmation Delivery", "Client Trade Confirmation"): ("48", "Client Trade Confirmation"),
    ("13", "Confirmation Delivery", "Confirmed Fund Order"): ("29", "Fund Order"),
    ("13", "Beneficial Owner Disclosure Election", "Disclosure Election Account"): ACCOUNT,
    ("13", "Voting Choice Election", "Voting Choice Account"): ACCOUNT,
    ("13", "Voting Choice Election", "Voting Choice Fund"): PRODUCT,
    ("13", "Voting Choice Election", "Chosen Voting Policy"): ("34", "Voting Policy"),
    ("13", "Issuer Proxy Pass-Through", "Issuer Meeting"): ("17", "Corporate Action Event"),
    ("13", "Issuer Proxy Pass-Through", "Pass-Through Account"): ACCOUNT,
    ("13", "Dormancy Assessment", "Dormancy Account"): ACCOUNT,
    ("13", "Escheatment Report & Remittance", "Remittance Money Movement"): ("50", "Money Movement"),

    # ------------------------------------------------------------------ 14 Third-Party Data & Licensing
    ("14", "Attribution Requirement", "Attribution Agreement"): DLA,
    ("14", "Data Cost Allocation", "Allocated Agreement"): DLA,
    ("14", "Data Cost Allocation", "Allocated Org Unit"): ORG_UNIT,
    ("14", "Data Cost Allocation", "Allocation Method Reference"): ("10", "Allocation Method"),
    ("14", "Data Invoice", "Invoiced Agreement"): DLA,
    # Vendor-side Party references point to Data Vendor (the 14 role of Party), as distributor firms point to
    # Distributor Firm.
    ("14", "Data License Agreement", "Licensor"): DATA_VENDOR,
    ("14", "Data License Agreement", "Licensee Legal Entity"): LEGAL_ENTITY,
    ("14", "Data License Agreement", "Parent Agreement"): DLA,
    ("14", "Data License Agreement", "Agreement Business Owner"): EMPLOYEE,
    ("14", "Data Vendor", "Vendor Party"): PARTY,
    ("14", "Data Vendor", "Vendor Group"): PARTY,
    ("14", "Data Vendor", "Relationship Owner"): EMPLOYEE,
    ("14", "Dataset", "Dataset Vendor"): DATA_VENDOR,
    ("14", "Dataset", "Dataset Business Owner"): EMPLOYEE,
    ("14", "Dataset Consumption", "Consumed Dataset"): DATASET,
    ("14", "Dataset Consumption", "Consuming Application"): ("14", "Consuming Application"),
    ("14", "Dataset Delivery", "Technical Feed"): ("06", "Data Feed"),
    ("14", "Entitlement", "Entitled User"): EMPLOYEE,
    ("14", "Entitlement", "Entitled Application"): ("14", "Consuming Application"),
    ("14", "Entitlement", "Entitled Dataset"): DATASET,
    ("14", "Entitlement", "Governing License"): DLA,
    ("14", "Entitlement", "Approver"): EMPLOYEE,
    # ICT Third-Party Register Entry references removed with the object (CW-914).
    ("14", "Entitlement", "Entitled Client"): PARTY,  # W1b addition (CW-914): client subscriber, a 02 party
    ("14", "Market Data Subscriber", "Subscriber Client"): PARTY,
    ("14", "Consuming Application", "Consuming Application ID"): ("41", "Application"),  # keyed by APPL- (CD-264)
    ("14", "Index Product Coverage", "Covered Product"): PRODUCT,
    ("14", "Index Product Coverage", "Covered Share Class"): SHARE_CLASS,
    ("14", "Index Use", "Index License Agreement"): DLA,
    ("14", "Index Use", "Licensed Index"): BENCHMARK,
    ("14", "Index Use", "Index Provider"): DATA_VENDOR,
    ("14", "License Audit", "Audited Vendor"): DATA_VENDOR,
    ("14", "Licensed Dataset Schedule", "Licensed Dataset"): DATASET,
    ("14", "Licensed Dataset Schedule", "Licensed Legal Entities"): LEGAL_ENTITY,
    ("14", "Licensed Dataset Schedule", "Licensed Business Units"): ORG_UNIT,
    ("14", "Permitted Use Grant", "Grant Agreement"): DLA,
    ("14", "Permitted Use Grant", "Grant Dataset"): DATASET,
    ("14", "Renewal Case", "Renewing Agreement"): DLA,
    ("14", "Renewal Case", "Overlapping Datasets"): DATASET,
    ("14", "Usage Declaration", "Declaration Agreement"): DLA,
    ("14", "Vendor Contact Role", "Vendor Contact"): PARTY,
    ("14", "Vendor Data Issue", "Issue Dataset"): DATASET,
    ("14", "Vendor Data SLA", "SLA Dataset"): DATASET,
    ("14", "Vendor Risk Assessment", "Assessed Vendor"): DATA_VENDOR,
}

# Unresolved references: none. The billing family (Billing Arrangement, Fee Invoice, Billing Dispute, Fee Adjustment,
# Performance Fee Calculation) moved to 47 (CW-052); Billing Arrangement.Applied Fee Schedule now resolves to the 47 Fee
# Schedule (keys_w_45_47.py), which closes the old 01 Fee Schedule gap.
