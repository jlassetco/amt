"""Key and link registry, group 6: 15 Account and 16 Retirement Plan Administration. Merged into keys.py by dm_model.

Wealth-manager W1 merge (2026-10-14): the 15 entries are re-cut for the replaced 15 Account module (CW-021): the
kept prefixes (ACC-, ACI-, ABD-, ATC-, SIN-, ABI-, ALE-, ARX-), the new AFEA-, AAG-, ENRL- and AISB- keys and the
composite keys that proposals_w1_15.py KEY_FORMATS publishes. Platform Program Enrollment (now Program Enrollment) and
Account Privilege (now Account Feature) are retired. References whose target sat in a wealth Data Domain
with no module yet (45 to 52) moved from PENDING_REFS to REFS at the W2-W4 merge (2026-10-15).

W2-W4 merge (2026-10-15): the 16 W3 pass is applied (CW-125 to CW-128, CW-051): Plan Fee Schedule is keyed by PFEE-
Plan Fee Line ID; the restored role profiles (Plan Sponsor Profile, Recordkeeper Profile), Retirement Plan Profile,
Participant Balance, the participant elections, Participant Ledger Posting (PLPST-), Participant Investment Transfer
(PEXC-) and Participant Retail Hand-Off (PRTHO-) are added; the 06 Transaction and Position targets re-point to 16
Participant Ledger Posting and Participant Balance, and Service Arrangement.Governing Agreement to 39 Contract.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
ACCOUNT = ("15", "Account")
EMPLOYEE = ("20", "Employee")
SHARE_CLASS = ("01", "Share Class")
RETIREMENT_PLAN = ("02", "Retirement Plan")

MANDATE = ("01", "Investment Mandate")
MODEL_PORTFOLIO = ("01", "Model Portfolio")
ONBOARDING_CASE = ("02", "Onboarding Case")
SERVICE_REQUEST = ("13", "Service Request")
BANK_INSTRUCTION = ("15", "Bank Instruction")
LIFECYCLE_EVENT = ("15", "Account Lifecycle Event")
LEGAL_ENTITY = ("09", "Internal Legal Entity")
INSTRUMENT = ("17", "Instrument")
INVESTOR_PROFILE = ("02", "Investor Profile")
ACCOUNT_AGREEMENT = ("15", "Account Agreement")
DISCLOSURE_DELIVERY = ("15", "Account Disclosure Delivery")

KEYS = {
    # ------------------------------------------------------------------ 15 Account (wealth re-cut, W1 merge)
    # Account Master
    ("15", "Account"): _k(["Account ID"], "Natural", note="ACC- key."),
    ("15", "Account Identifier"): _k(["Account Identifier ID"], "Natural",
                                     note="ACI- key; Identified Account x Account Identifier Scheme x Account Identifier "
                                          "Value x Identifier Effective From is the alternate key."),
    ("15", "Account Hierarchy Link"): _k(["Parent Account", "Child Account", "Account Link Type", "Link Effective From"],
                                         "Composite"),
    ("15", "Account Party Role"): _k(["Role Account", "Role Party", "Account Role Type", "Account Role Effective From"],
                                     "Composite"),
    # Registration, Ownership & Beneficiaries
    ("15", "Account Registration Detail"): _fold(),
    ("15", "Custodial Account Detail"): _fold("Populated for UTMA / UGMA and guardianship accounts only."),
    ("15", "Retirement Account Detail"): _fold("Populated for IRA-family and inherited IRA accounts only."),
    ("15", "Education & Health Savings Account Detail"): _fold("Populated for 529, Coverdell and HSA accounts only."),
    ("15", "Beneficiary Designation"): _k(["Beneficiary Designation ID"], "Natural",
                                          note="ABD- key; Designated Account x Beneficiary x Beneficiary Designation Type "
                                               "x Beneficiary Type x Designation Effective From is the alternate key."),
    # Suitability, features & agreements
    ("15", "Account Investment Profile"): _k(["Profile Account", "Account Profile Effective From"], "Composite",
                                             note="One row per profile version (SEC Rule 17a-3(a)(17)), as the grain "
                                                  "says."),
    ("15", "Account Feature"): _k(["Account Feature ID"], "Natural",
                                  note="AFEA- key; Feature Account x Feature Type x Feature Effective From is the "
                                       "alternate key."),
    ("15", "Options Approval Detail"): _fold("Populated for the options feature only."),
    ("15", "Margin Account Detail"): _fold("Populated for the margin feature only."),
    ("15", "Cash Sweep Election"): _k(["Sweep Election Account", "Sweep Vehicle Type", "Sweep Election Effective From"],
                                      "Composite", note="Composite key as proposals_w1_15 KEY_FORMATS publishes it."),
    ("15", "Account Agreement"): _k(["Account Agreement ID"], "Natural",
                                    note="AAG- key; Agreement Account x Account Agreement Type x Agreement Version is "
                                         "the alternate key."),
    ("15", "Account Disclosure Delivery"): _k(["Disclosure Account", "Disclosure Type", "Disclosure Version",
                                               "Disclosure Delivered Date"], "Composite",
                                              note="Composite key as proposals_w1_15 KEY_FORMATS publishes it."),
    ("15", "New Issue Eligibility"): _fold(),
    # Programs & alternative investments
    ("15", "Program Enrollment"): _k(["Program Enrollment ID"], "Natural",
                                     note="ENRL- key; Enrolled Account x Enrolled Service Offering x Enrollment "
                                          "Effective Date is the alternate key."),
    ("15", "Alternative Investment Subscription"): _k(["Subscription ID"], "Natural",
                                                      note="AISB- key; Subscribing Account x Feeder Product x Offering "
                                                           "Window is the alternate key."),
    # Intermediary, Institutional & Plan Participant Accounts
    ("15", "Intermediary Account Servicing"): _fold(),
    ("15", "Institutional Account"): _fold(),
    ("15", "Plan Participant Account"): _fold("Populated for Account Type 'Participant Account' only; 16 references the "
                                              "Account and reads Participant and Retirement Plan from this group."),
    # Account Tax Status & retirement distributions
    ("15", "Account Tax Certification"): _k(["Tax Certification ID"], "Natural",
                                            note="ATC- key; Certified Account x Certifying Party x Tax Form Type x "
                                                 "Certification Signed Date is the alternate key."),
    ("15", "Account Tax Reporting Status"): _fold(),
    ("15", "Cost Basis Election"): _k(["Election Account", "Election Share Class", "Election Effective From"], "Composite",
                                      note="Election Share Class is optional (blank = account default or a fund / DRIP "
                                           "scope); use a default value where blank so the key stays complete."),
    ("15", "RMD Record"): _k(["RMD Account", "RMD Distribution Year"], "Composite",
                             note="Composite key ACC- / distribution year, as proposals_w1_15 KEY_FORMATS publishes it."),
    ("15", "Retirement Distribution Election"): _k(["Withholding Election Account", "Withholding Election Type",
                                                    "Withholding Election Effective From"], "Composite",
                                                   note="Composite key as proposals_w1_15 KEY_FORMATS publishes it."),
    # Standing Instructions, Bank Instructions & Preferences
    ("15", "Account Standing Instruction"): _k(["Standing Instruction ID"], "Natural", note="SIN- key."),
    ("15", "Bank Instruction"): _k(["Bank Instruction ID"], "Natural", note="ABI- key."),
    ("15", "Account Preference"): _fold(),
    # Account Lifecycle & Status
    ("15", "Account Opening"): _fold(),
    ("15", "Account Lifecycle Event"): _k(["Lifecycle Event ID"], "Natural", note="ALE- key."),
    ("15", "Account Status History"): _k(["Status Account", "Historical Account Status", "Status Effective From"],
                                         "Composite", note="One row per status period."),
    ("15", "Account Closure"): _fold("Populated for closed accounts only."),
    # Account Restrictions
    ("15", "Account Restriction"): _k(["Account Restriction ID"], "Natural", note="ARX- key."),
    # ------------------------------------------------------------------ 16 Retirement Plan Administration
    # Plan Document & Provisions
    ("16", "Plan Document"): _k(["Plan Document ID"], "Natural"),
    ("16", "Plan Amendment"): _k(["Amendment ID"], "Natural"),
    ("16", "Plan Type Detail"): _fold(),
    ("16", "Eligibility Provisions"): _fold(),
    ("16", "Deferral & Automatic Features"): _fold(),
    ("16", "Employer Contribution Formula"): _child(["Formula Contribution Source", "Formula Effective From"]),
    ("16", "Vesting Schedule"): _child(["Vesting Contribution Source", "Vesting Schedule Effective From"]),
    ("16", "Withdrawal & Forfeiture Provisions"): _fold(),
    ("16", "SIMPLE IRA & SEP Program Detail"): _fold("Populated only for SIMPLE IRA and SEP programs."),
    # Plan Fiduciaries, Service Roles & Fee Arrangement
    ("16", "Plan Role Assignment"): _k(["Plan Role ID"], "Natural"),
    ("16", "Service Arrangement"): _k(["Service Arrangement ID"], "Natural"),
    ("16", "Plan Fee Schedule"): _k(["Plan Fee Line ID"], "Natural", note="PFEE- (CW-051)."),
    ("16", "Plan Notice"): _k(["Plan Notice ID"], "Natural"),
    # Plan Investment Menu
    ("16", "Plan Investment Option"): _k(["Investment Option ID"], "Natural"),
    ("16", "Fund Change Event"): _k(["Fund Change ID"], "Natural"),
    # Participant Eligibility, Enrollment & Elections
    ("16", "Participant Plan Membership"): _k(["Membership ID"], "Natural"),
    ("16", "Employment Event"): _k(["Event Membership", "Employment Event Type", "Employment Event Date"], "Composite"),
    ("16", "Deferral Election"): _k(["Deferral Election ID"], "Natural"),
    ("16", "Investment Election"): _k(["Investment Election Membership", "Elected Investment Option",
                                      "Investment Election Effective From"], "Composite"),
    # Contributions & Limits
    ("16", "Payroll Contribution Batch"): _k(["Contribution Batch ID"], "Natural"),
    ("16", "Contribution Record"): _k(["Contribution ID"], "Natural",
                                      note="CONT-: membership x contribution source x receipt; the batch is blank "
                                           "for non-payroll receipts (CW-126)."),
    ("16", "Annual Limit Tracking"): _k(["Limit Membership", "Limit Type", "Limit Plan Year"], "Composite"),
    ("16", "Late Deposit Case"): _k(["Late Deposit Case ID"], "Natural"),
    # Participant Loans
    ("16", "Plan Loan Provisions"): _fold("Loan rules of the plan document; lives in the Participant Loans family."),
    ("16", "Participant Loan"): _k(["Loan ID"], "Natural"),
    ("16", "Loan Repayment"): _k(["Repaid Loan", "Repayment Date"], "Composite",
                                 note="Two repayments of one loan on the same date (payroll plus payoff) need a sequence."),
    ("16", "Loan Default & Offset"): _fold(),
    # Vesting & Forfeitures
    ("16", "Vesting Service Record"): _k(["Vesting Membership", "Vesting Plan Year"], "Composite"),
    ("16", "Vested Balance by Source"): _k(["Vested Balance Membership", "Vested Contribution Source",
                                            "Vested Balance As-Of Date"], "Composite"),
    ("16", "Forfeiture Record"): _k(["Forfeiture ID"], "Natural"),
    # Distributions, Rollovers & Tax Reporting
    ("16", "Distribution Request"): _k(["Distribution ID"], "Natural"),
    ("16", "Tax Withholding & 1099-R Detail"): _fold(),
    ("16", "RMD Calculation"): _k(["RMD Membership", "RMD Distribution Year"], "Composite"),
    ("16", "QDRO Case"): _k(["QDRO Case ID"], "Natural"),
    # Compliance Testing & Plan Corrections
    ("16", "Nondiscrimination Test"): _k(["Test ID"], "Natural"),
    ("16", "Test Correction"): _k(["Test Correction ID"], "Natural"),
    ("16", "Plan Correction"): _k(["Plan Correction ID"], "Natural"),
    # Government Filings & Plan Audit
    ("16", "Government Filing"): _k(["Filing ID"], "Natural"),
    ("16", "Form 5500 Detail"): _fold("Populated for Form 5500, 5500-SF and 5500-EZ filings."),
    ("16", "Separated Participant Entry"): _child(["Reported Membership"], "Form 8955-SSA filings only."),
    ("16", "Plan Audit"): _k(["Plan Audit ID"], "Natural"),
    # Plan Onboarding, Conversion & Termination
    ("16", "Plan Conversion"): _k(["Conversion ID"], "Natural"),
    ("16", "Plan Termination"): _k(["Plan Termination ID"], "Natural"),
    # W2-W4 merge (2026-10-15): 16 objects restored or added
    ("16", "Plan Sponsor Profile"): _k(["Sponsor Party"], "Composite",
                                       note="Role profile of the 02 Party; keyed by the PTY- reference (CD-143)."),
    ("16", "Recordkeeper Profile"): _k(["Recordkeeper Party"], "Composite",
                                       note="Role profile of the 02 Party; keyed by the PTY- reference (CD-143)."),
    ("16", "Retirement Plan Profile"): _k(["Profile Plan", "Profile Plan Year"], "Composite"),
    ("16", "Plan Service Provider"): _fold(),
    ("16", "Plan Managed Account Service"): _k(["Managed Account Service Plan",
                                                "Managed Account Service Offering",
                                                "Service Effective From"], "Composite"),
    ("16", "Participant Distribution Election"): _k(["Distribution Election Membership",
                                                     "Distribution Election Type",
                                                     "Distribution Election Effective From"], "Composite"),
    ("16", "Participant Service Election"): _k(["Service Election Membership", "Service Election Type",
                                                "Service Election Effective From"], "Composite"),
    ("16", "Rollover Contribution Detail"): _fold(),
    ("16", "Participant Balance"): _k(["Balance Membership", "Balance Contribution Source",
                                       "Balance Investment Option", "Valuation Date"], "Composite"),
    ("16", "Participant Ledger Posting"): _k(["Ledger Posting ID"], "Natural"),
    ("16", "Participant Investment Transfer"): _k(["Investment Transfer ID"], "Natural"),
    ("16", "Participant Retail Hand-Off"): _k(["Hand-Off ID"], "Natural"),
}

COMPLAINT = ("08", "Complaint")
SHAREHOLDER_COMM = ("13", "Shareholder Communication")
INVESTOR_DOCUMENT = ("13", "Investor Document")
BENEFICIARY_DESIGNATION = ("15", "Beneficiary Designation")
PLAN_DOCUMENT = ("16", "Plan Document")
MEMBERSHIP = ("16", "Participant Plan Membership")
INVESTMENT_OPTION = ("16", "Plan Investment Option")
CONTRIBUTION_BATCH = ("16", "Payroll Contribution Batch")
DISTRIBUTION = ("16", "Distribution Request")

REFS = {
    # ------------------------------------------------------------------ 15 Account (wealth re-cut, W1 merge)
    ("15", "Account", "Carrying Entity"): LEGAL_ENTITY,
    ("15", "Account Identifier", "Identified Account"): ACCOUNT,
    ("15", "Account Identifier", "Issuing Party"): PARTY,
    ("15", "Account Hierarchy Link", "Parent Account"): ACCOUNT,
    ("15", "Account Hierarchy Link", "Child Account"): ACCOUNT,
    ("15", "Account Party Role", "Role Party"): PARTY,
    ("15", "Account Party Role", "Role Account"): ACCOUNT,
    ("15", "Custodial Account Detail", "Successor Custodian"): PARTY,
    ("15", "Retirement Account Detail", "Inherited IRA Decedent"): PARTY,
    ("15", "Retirement Account Detail", "IRA Custodian Entity"): LEGAL_ENTITY,
    ("15", "Retirement Account Detail", "IRA Custodial Agreement"): ACCOUNT_AGREEMENT,
    ("15", "Retirement Account Detail", "Rollover Source Plan"): RETIREMENT_PLAN,
    ("15", "Education & Health Savings Account Detail", "529 Plan Portfolio"): INSTRUMENT,
    ("15", "Beneficiary Designation", "Designated Account"): ACCOUNT,
    ("15", "Beneficiary Designation", "Beneficiary"): PARTY,
    ("15", "Account Investment Profile", "Profile Account"): ACCOUNT,
    ("15", "Account Investment Profile", "Investor Profile Version Applied"): INVESTOR_PROFILE,
    ("15", "Account Feature", "Feature Account"): ACCOUNT,
    ("15", "Account Feature", "Feature Approved By"): EMPLOYEE,
    ("15", "Account Feature", "Feature Profile Version Used"): INVESTOR_PROFILE,
    ("15", "Account Feature", "Feature Agreements"): ACCOUNT_AGREEMENT,
    ("15", "Options Approval Detail", "Options Disclosure Delivery"): DISCLOSURE_DELIVERY,
    ("15", "Margin Account Detail", "Margin Disclosure Delivery"): DISCLOSURE_DELIVERY,
    ("15", "Cash Sweep Election", "Sweep Election Account"): ACCOUNT,
    ("15", "Cash Sweep Election", "Elected Sweep Fund"): SHARE_CLASS,
    ("15", "Cash Sweep Election", "Elected Sweep Program"): ("50", "Sweep Program"),
    ("15", "Cash Sweep Election", "Excluded Program Banks"): ("50", "Program Bank"),
    ("15", "Account Agreement", "Agreement Account"): ACCOUNT,
    ("15", "Account Disclosure Delivery", "Disclosure Account"): ACCOUNT,
    ("15", "Account Disclosure Delivery", "Related Account Feature"): ("15", "Account Feature"),
    ("15", "Account Disclosure Delivery", "Related Program Enrollment"): ("15", "Program Enrollment"),
    ("15", "Program Enrollment", "Enrolled Account"): ACCOUNT,
    ("15", "Program Enrollment", "Enrolled Service Offering"): ("01", "Service Offering"),
    ("15", "Program Enrollment", "Advisory Agreement"): ACCOUNT_AGREEMENT,
    ("15", "Program Enrollment", "Reasonable Restrictions"): ("02", "Client Restriction"),
    ("15", "Program Enrollment", "Source Recommendation"): ("45", "Recommendation"),
    ("15", "Alternative Investment Subscription", "Subscribing Account"): ACCOUNT,
    ("15", "Alternative Investment Subscription", "Feeder Product"): ("01", "Investment Product"),
    ("15", "Alternative Investment Subscription", "Offering Window"): ("01", "Offering Window"),
    ("15", "Alternative Investment Subscription", "Investor Qualification Relied On"): ("02", "Investor Qualification"),
    # Dealer, branch and rep of record point at the restored 05 Distributor Firm, Branch / Office and Financial
    # Professional, role profiles of the 02 Party keyed by PTY- (CW-132).
    ("15", "Intermediary Account Servicing", "Dealer of Record"): ("05", "Distributor Firm"),
    ("15", "Intermediary Account Servicing", "Branch of Record"): ("05", "Branch / Office"),
    ("15", "Intermediary Account Servicing", "Rep of Record"): ("05", "Financial Professional"),
    ("15", "Institutional Account", "Related Mandate"): MANDATE,
    ("15", "Institutional Account", "Related Retirement Plan"): RETIREMENT_PLAN,
    ("15", "Institutional Account", "Custodian"): PARTY,
    ("15", "Institutional Account", "Governing Agreement"): ("39", "Contract"),
    # Participant carries the participant's PTY- key, so it joins to the 02 Party; the link to 16 is Participant Plan
    # Membership.
    ("15", "Plan Participant Account", "Participant"): PARTY,
    ("15", "Plan Participant Account", "Retirement Plan"): RETIREMENT_PLAN,
    ("15", "Plan Participant Account", "Plan Account"): ACCOUNT,
    ("15", "Plan Participant Account", "Participant Plan Membership"): MEMBERSHIP,
    ("15", "Account Tax Certification", "Certified Account"): ACCOUNT,
    ("15", "Account Tax Certification", "Certifying Party"): PARTY,
    ("15", "Cost Basis Election", "Election Account"): ACCOUNT,
    ("15", "Cost Basis Election", "Election Share Class"): SHARE_CLASS,
    ("15", "RMD Record", "RMD Account"): ACCOUNT,
    ("15", "Retirement Distribution Election", "Withholding Election Account"): ACCOUNT,
    ("15", "Account Standing Instruction", "Instruction Account"): ACCOUNT,
    ("15", "Account Standing Instruction", "Instruction Share Class"): SHARE_CLASS,
    ("15", "Account Standing Instruction", "Linked Bank Instruction"): BANK_INSTRUCTION,
    ("15", "Account Standing Instruction", "Instruction Destination Account"): ACCOUNT,
    ("15", "Bank Instruction", "Bank Instruction Account"): ACCOUNT,
    ("15", "Account Preference", "Duplicate Statement Recipient"): PARTY,
    ("15", "Account Preference", "Default Bank Instruction"): BANK_INSTRUCTION,
    ("15", "Account Opening", "Opening Intermediary"): PARTY,
    ("15", "Account Opening", "Opened By"): EMPLOYEE,
    ("15", "Account Opening", "Opening KYC Case"): ONBOARDING_CASE,
    ("15", "Account Opening", "Opening Identity Verification"): ("02", "Identity Verification"),
    ("15", "Account Opening", "Account Approved By"): EMPLOYEE,
    ("15", "Account Opening", "Originating Recommendation"): ("45", "Recommendation"),
    ("15", "Account Opening", "Initial Funding Transaction"): ("50", "Money Movement"),
    ("15", "Account Lifecycle Event", "Event Account"): ACCOUNT,
    ("15", "Account Lifecycle Event", "Triggering Service Request"): SERVICE_REQUEST,
    ("15", "Account Lifecycle Event", "Recorded By"): EMPLOYEE,
    ("15", "Account Lifecycle Event", "Triggering Transaction"): ("50", "Money Movement"),
    ("15", "Account Status History", "Status Account"): ACCOUNT,
    ("15", "Account Status History", "Status Set By Event"): LIFECYCLE_EVENT,
    ("15", "Account Closure", "Transfer-Out Receiving Firm"): PARTY,
    ("15", "Account Closure", "Closing Account Transfer"): ("49", "Account Transfer"),
    ("15", "Account Closure", "Final Transaction"): ("50", "Money Movement"),
    ("15", "Account Restriction", "Restricted Account"): ACCOUNT,
    ("15", "Account Restriction", "Lift Approved By"): EMPLOYEE,
    ("15", "Account Restriction", "Source Vulnerability Concern"): ("02", "Vulnerability Concern"),
    ("15", "Account Registration Detail", "Governing Trust"): ("51", "Trust"),
    # ------------------------------------------------------------------ 16 Retirement Plan Administration
    ("16", "Plan Document", "Administered Plan"): RETIREMENT_PLAN,
    ("16", "Plan Amendment", "Amended Plan Document"): PLAN_DOCUMENT,
    ("16", "Plan Role Assignment", "Role Plan"): RETIREMENT_PLAN,
    ("16", "Plan Role Assignment", "Role Party"): PARTY,
    ("16", "Service Arrangement", "Arrangement Plan"): RETIREMENT_PLAN,
    ("16", "Service Arrangement", "Governing Agreement"): ("39", "Contract"),
    ("16", "Plan Fee Schedule", "Fee Service Arrangement"): ("16", "Service Arrangement"),
    ("16", "Plan Notice", "Notice Plan"): RETIREMENT_PLAN,
    ("16", "Plan Notice", "Delivery Communication"): SHAREHOLDER_COMM,
    ("16", "Plan Investment Option", "Menu Plan"): RETIREMENT_PLAN,
    ("16", "Plan Investment Option", "Offered Share Class"): SHARE_CLASS,
    ("16", "Plan Investment Option", "Model Portfolio"): MODEL_PORTFOLIO,
    ("16", "Fund Change Event", "Change Plan"): RETIREMENT_PLAN,
    ("16", "Fund Change Event", "From Investment Option"): INVESTMENT_OPTION,
    ("16", "Fund Change Event", "To Investment Option"): INVESTMENT_OPTION,
    ("16", "Fund Change Event", "Mapping Transactions"): ("16", "Participant Ledger Posting"),
    ("16", "Participant Plan Membership", "Participant"): PARTY,
    ("16", "Participant Plan Membership", "Membership Plan"): RETIREMENT_PLAN,
    ("16", "Participant Plan Membership", "Participant Account"): ACCOUNT,
    ("16", "Participant Plan Membership", "Beneficiary Designation on File"): BENEFICIARY_DESIGNATION,
    ("16", "Employment Event", "Event Membership"): MEMBERSHIP,
    ("16", "Deferral Election", "Election Membership"): MEMBERSHIP,
    ("16", "Investment Election", "Investment Election Membership"): MEMBERSHIP,
    ("16", "Investment Election", "Elected Investment Option"): INVESTMENT_OPTION,
    ("16", "Payroll Contribution Batch", "Batch Plan"): RETIREMENT_PLAN,
    ("16", "Contribution Record", "Contribution Batch"): CONTRIBUTION_BATCH,
    ("16", "Contribution Record", "Contribution Membership"): MEMBERSHIP,
    ("16", "Contribution Record", "Contribution Account"): ACCOUNT,
    ("16", "Contribution Record", "Posting Transaction"): ("16", "Participant Ledger Posting"),
    ("16", "Contribution Record", "Related Plan Correction"): ("16", "Plan Correction"),
    ("16", "Annual Limit Tracking", "Limit Membership"): MEMBERSHIP,
    ("16", "Late Deposit Case", "Late Batch"): CONTRIBUTION_BATCH,
    ("16", "Participant Loan", "Loan Membership"): MEMBERSHIP,
    ("16", "Participant Loan", "Loan Account"): ACCOUNT,
    ("16", "Participant Loan", "Disbursement Transaction"): ("16", "Participant Ledger Posting"),
    ("16", "Loan Default & Offset", "Related Offset Distribution"): DISTRIBUTION,
    ("16", "Loan Repayment", "Repaid Loan"): ("16", "Participant Loan"),
    ("16", "Loan Repayment", "Repayment Batch"): CONTRIBUTION_BATCH,
    ("16", "Vesting Service Record", "Vesting Membership"): MEMBERSHIP,
    ("16", "Vested Balance by Source", "Vested Balance Membership"): MEMBERSHIP,
    ("16", "Vested Balance by Source", "Source Participant Balance"): ("16", "Participant Balance"),
    ("16", "Forfeiture Record", "Forfeiture Plan"): RETIREMENT_PLAN,
    ("16", "Forfeiture Record", "Forfeiting Membership"): MEMBERSHIP,
    ("16", "Forfeiture Record", "Forfeiture Transaction"): ("16", "Participant Ledger Posting"),
    ("16", "Distribution Request", "Distribution Membership"): MEMBERSHIP,
    ("16", "Distribution Request", "Distribution Account"): ACCOUNT,
    ("16", "Distribution Request", "Receiving Institution"): PARTY,
    ("16", "Distribution Request", "Settlement Transactions"): ("16", "Participant Ledger Posting"),
    ("16", "Distribution Request", "Auto-Rollover IRA Provider"): PARTY,
    ("16", "Distribution Request", "Receiving Account"): ACCOUNT,
    ("16", "Distribution Request", "Originating Hand-Off"): ("16", "Participant Retail Hand-Off"),
    ("16", "Tax Withholding & 1099-R Detail", "Tax Form Document"): INVESTOR_DOCUMENT,
    ("16", "RMD Calculation", "RMD Membership"): MEMBERSHIP,
    ("16", "QDRO Case", "QDRO Membership"): MEMBERSHIP,
    ("16", "QDRO Case", "Alternate Payee"): PARTY,
    ("16", "QDRO Case", "Alternate Payee Account"): ACCOUNT,
    ("16", "QDRO Case", "Resulting Distribution"): DISTRIBUTION,
    ("16", "Nondiscrimination Test", "Tested Plan"): RETIREMENT_PLAN,
    ("16", "Nondiscrimination Test", "Test Performed By"): PARTY,
    ("16", "Test Correction", "Corrected Test"): ("16", "Nondiscrimination Test"),
    ("16", "Test Correction", "Resulting Distributions"): DISTRIBUTION,
    ("16", "Plan Correction", "Corrected Plan"): RETIREMENT_PLAN,
    ("16", "Plan Correction", "Related Complaint"): COMPLAINT,
    ("16", "Government Filing", "Filing Plan"): RETIREMENT_PLAN,
    ("16", "Government Filing", "Filing Signer"): PARTY,
    ("16", "Separated Participant Entry", "Reported Membership"): MEMBERSHIP,
    ("16", "Plan Audit", "Audited Plan"): RETIREMENT_PLAN,
    ("16", "Plan Audit", "Audit Firm"): PARTY,
    ("16", "Plan Conversion", "Converted Plan"): RETIREMENT_PLAN,
    ("16", "Plan Conversion", "Counterparty Recordkeeper"): PARTY,
    ("16", "Plan Conversion", "Investment Mapping Event"): ("16", "Fund Change Event"),
    ("16", "Plan Conversion", "Conversion Project Owner"): EMPLOYEE,
    ("16", "Plan Termination", "Terminated Plan"): RETIREMENT_PLAN,
    ("16", "Plan Termination", "Final Form 5500 Filing"): ("16", "Government Filing"),
    ("16", "Plan Sponsor Profile", "Sponsor Party"): PARTY,
    ("16", "Plan Sponsor Profile", "Controlled Group Members"): PARTY,
    ("16", "Recordkeeper Profile", "Recordkeeper Party"): PARTY,
    ("16", "Retirement Plan Profile", "Profile Plan"): RETIREMENT_PLAN,
    ("16", "Plan Managed Account Service", "Managed Account Service Plan"): RETIREMENT_PLAN,
    ("16", "Plan Managed Account Service", "Managed Account Service Offering"): ("01", "Service Offering"),
    ("16", "Plan Managed Account Service", "Managed Account Fee Schedule"): ("47", "Fee Schedule"),
    ("16", "Participant Distribution Election", "Distribution Election Membership"): MEMBERSHIP,
    ("16", "Participant Distribution Election", "Distribution Election Source Interaction"):
        ("13", "Contact Center Interaction"),
    ("16", "Participant Service Election", "Service Election Membership"): MEMBERSHIP,
    ("16", "Participant Service Election", "Service Election Source Interaction"): ("13", "Contact Center Interaction"),
    ("16", "Rollover Contribution Detail", "Distributing Institution"): PARTY,
    ("16", "Participant Balance", "Balance Membership"): MEMBERSHIP,
    ("16", "Participant Balance", "Balance Investment Option"): INVESTMENT_OPTION,
    ("16", "Participant Ledger Posting", "Posting Membership"): MEMBERSHIP,
    ("16", "Participant Ledger Posting", "Posting Investment Option"): INVESTMENT_OPTION,
    ("16", "Participant Ledger Posting", "Resulting Plan Fund Order"): ("29", "Fund Order"),
    ("16", "Participant Investment Transfer", "Transfer Membership"): MEMBERSHIP,
    ("16", "Participant Investment Transfer", "Transfer From Option"): INVESTMENT_OPTION,
    ("16", "Participant Investment Transfer", "Transfer To Option"): INVESTMENT_OPTION,
    ("16", "Participant Retail Hand-Off", "Hand-Off Membership"): MEMBERSHIP,
    ("16", "Participant Retail Hand-Off", "Contact Consent"): ("02", "Consent Record"),
    ("16", "Participant Retail Hand-Off", "Referral Advice Engagement"): ("45", "Advice Engagement"),
    ("16", "Participant Retail Hand-Off", "Referred Advisor"): ("03", "Advisor"),
    ("16", "Participant Retail Hand-Off", "Linked Distribution Request"): DISTRIBUTION,
}


# Unresolved references after the W2-W4 merge (left out of REFS: no single object masters the target)
#   ("16", "Participant Ledger Posting", "Posting Source Record")  <Reference (Contribution Record / Participant Loan /
#       Loan Repayment / Distribution Request / Forfeiture Record / Fund Change Event / Participant Investment Transfer
#       / Plan Correction)>
#       polymorphic over eight 16 source records.
