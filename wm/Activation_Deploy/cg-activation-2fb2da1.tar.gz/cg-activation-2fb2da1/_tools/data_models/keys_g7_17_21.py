"""Key and link registry extension: Data Domains 17-21 (enterprise expansion, Stage 1).

Same format and conventions as keys.py (see CONTRACT.md section 1). Only the objects that data products read are
registered: the employee master moved from 09 to 20 under CD-151, the journal, GL posting and accounting period status
moved from 10 to 19 under CD-152 (with the financial statement line mapping that took over 10's revenue
disaggregation category), and the data quality rule and result moved from 06 to 21 under CD-156.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


LEGAL_ENTITY = ("09", "Internal Legal Entity")
ORG_UNIT = ("09", "Org Unit")
EMPLOYEE = ("20", "Employee")

KEYS = {
    # ------------------------------------------------------------------ 20 Human Capital (moved from 09, CD-151)
    ("20", "Employee"): _k(["Employee ID"], "Natural"),
    ("20", "Employee Reporting Line"): _k(["Reporting Employee", "Line Manager", "Reporting Line Type",
                                           "Reporting Effective From"], "Composite"),
    ("20", "Org Unit Assignment"): _k(["Assigned Employee", "Assigned Org Unit", "Assignment Effective From / To"],
                                      "Composite",
                                      note="The effective period is one attribute; the model uses its start date."),
    # ------------------------------------------------------------------ 19 Finance & Accounting (moved from 10, CD-152)
    ("19", "Journal Entry"): _k(["Journal ID"], "Natural"),
    ("19", "GL Posting"): _k(["Journal ID", "Journal Line Number"], "Composite",
                             note="Journal x line; Journal ID references the Journal Entry header."),
    ("19", "Accounting Period Status"): _k(["Status Ledger", "Status Fiscal Period"], "Composite"),
    ("19", "Financial Statement Line Mapping"): _k(["Mapped GL Account", "Mapped Statement Line",
                                                    "Line Mapping Effective From"], "Composite"),
    # ------------------------------------------------------------------ 21 Data Governance & Analytics (moved from 06, CD-156)
    ("21", "Data Quality Rule"): _k(["DQ Rule ID"], "Natural"),
    ("21", "Data Quality Result"): _k(["DQ Result ID"], "Natural"),
}

REFS = {
    ("20", "Employee", "Employing Legal Entity"): LEGAL_ENTITY,
    ("20", "Employee", "Home Org Unit"): ORG_UNIT,
    ("20", "Employee", "Work Location"): ("09", "Office Location"),
    ("20", "Employee Reporting Line", "Reporting Employee"): EMPLOYEE,
    ("20", "Employee Reporting Line", "Line Manager"): EMPLOYEE,
    ("20", "Org Unit Assignment", "Assigned Employee"): EMPLOYEE,
    ("20", "Org Unit Assignment", "Assigned Org Unit"): ORG_UNIT,
    ("19", "Journal Entry", "Posting Legal Entity"): LEGAL_ENTITY,
    ("19", "GL Posting", "Journal ID"): ("19", "Journal Entry"),
    ("19", "GL Posting", "Intercompany Partner Entity"): LEGAL_ENTITY,
    ("21", "Data Quality Result", "Tested DQ Rule"): ("21", "Data Quality Rule"),
}

# References left out of REFS: their 19 targets (GL Account, Ledger, Chart Segment Value, Financial Plan Version,
# Financial Statement Line) are in no data product yet, so the product models still join them by value to the objects
# they read:
#   ("19", "GL Posting", "Posted Account"), ("19", "Financial Statement Line Mapping", "Mapped GL Account") and
#   ("10", "Account Mapping", "GL Natural Account")  -> 19 GL Account; models join Posted Account to 10 Account Mapping.
#   ("10", "Account Mapping", "Applicable Ledger"), ("19", "Accounting Period Status", "Status Ledger")  -> 19 Ledger.
#   ("10", "Plan Version", "Enterprise Financial Plan Version")  -> 19 Financial Plan Version.
#   ("09", "Cost & Profit Center", "Cost Center Code" / "Profit Center Code") and ("07", "Compensation Accrual",
#   "GL Account")  -> 19 Chart Segment Value / GL Account.
# 10 Distribution Cost Item.Cost Center and Plan Line.Plan Cost Center are typed
# Reference (Chart Segment Value) since CD-152; their REFS stay on 09 Org Unit (keys.py, keys_g3_06_07_10.py) because the
# models join cost centers to the DP-013 Org Unit dimension, through 19 Chart Segment Value.Represented Org Unit.
#   Update 2026-10-15: Cost Pool.Contributing Cost Centers now points at 19 Chart Segment Value (keys_g3_06_07_10.py).
#   Update 2026-10-14 (Wave E7): these references are now registered in keys_e7_19_21.py, pointing at 19 GL Account and
#   19 Ledger. The DP-012 and DP-056 joins to 10 Account Mapping warn until those products are re-pointed in Phase 2 (CD-343).

# Unresolved references after the W2-W4 merge (left out of REFS: no single object masters the target)
#   ("19", "GL Posting", "Source Finance Record")  <Reference (FRR- / WVR- / DCO- / ACR- / CCA- / ARN- / ICC-)>
#       polymorphic over 10 finance records.
