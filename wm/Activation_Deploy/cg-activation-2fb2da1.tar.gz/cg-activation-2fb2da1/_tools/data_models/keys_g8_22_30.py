"""Key and link registry extension: Data Domains 22-30 (enterprise expansion, Stage 2).

Same format and conventions as keys.py (see CONTRACT.md section 1). Only the objects that data products read are
registered: the standing settlement instruction moved from 12 to 26 under CD-155 option A (DP-086 Mandate Readiness).
The 26 SSI keeps the 12 names, so the DP-086 join to the 12 Custody Account through 'Safekeeping Account' is unchanged.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


MANDATE = ("01", "Investment Mandate")

KEYS = {
    # ------------------------------------------------------------------ 26 Trade Operations (moved from 12, CD-155)
    ("26", "Standing Settlement Instruction"): _k(["SSI ID"], "Natural"),
}

REFS = {
    ("26", "Standing Settlement Instruction", "SSI Mandate"): MANDATE,
    ("26", "Standing Settlement Instruction", "Safekeeping Account"): ("12", "Client Custodian Account"),
}
