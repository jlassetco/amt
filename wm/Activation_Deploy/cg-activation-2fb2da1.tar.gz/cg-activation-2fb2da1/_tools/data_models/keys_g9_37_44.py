"""Key and link registry extension: Data Domains 37-44 (enterprise expansion, Stage 4).

Same format and conventions as keys.py (see CONTRACT.md section 1). Only the objects that data products read are
registered: the objects moved into Stage 4 domains with names unchanged, so the data products that read them keep their
joins and only the owning domain changes:
- Entity Authorization and Cross-Border Passport, moved from 09 to 38 (CD-250): DP-013, DP-041, DP-083
- Regulatory Obligation and Attestation, moved from 08 to 38 (CD-252): DP-083
- Brand, moved from 04 to 42 (CD-271): DP-090, and the 12 Report Template link (DP-042 family of reports)
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


EMPLOYEE = ("20", "Employee")
LEGAL_ENTITY = ("09", "Internal Legal Entity")

KEYS = {
    # ------------------------------------------------------------------ 38 Corporate Compliance (moved from 08 and 09)
    ("38", "Entity Authorization"): _k(["Authorization ID"], "Natural"),
    ("38", "Regulatory Obligation"): _k(["Obligation ID"], "Natural"),
    ("38", "Attestation"): _k(["Attester", "Attestation Type"], "Composite",
                              note="Grain also names the attestation period, which no attribute carries: model gap."),
    # ------------------------------------------------------------------ 42 Corporate Communications (moved from 04)
    ("42", "Brand"): _k(["Brand ID"], "Natural"),
}

REFS = {
    ("38", "Entity Authorization", "Authorized Entity"): LEGAL_ENTITY,
    ("38", "Regulatory Obligation", "Obligation Owner"): EMPLOYEE,
    ("38", "Regulatory Obligation", "Applicable Legal Entity"): LEGAL_ENTITY,
    ("38", "Attestation", "Attester"): EMPLOYEE,
    ("42", "Brand", "Parent Brand"): ("42", "Brand"),
}
