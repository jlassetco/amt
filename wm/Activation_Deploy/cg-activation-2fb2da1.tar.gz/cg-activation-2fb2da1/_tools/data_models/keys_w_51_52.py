"""Key and link registry, wealth W2-W3 merge: Data Domains 51 Trust & Estate Services and 52 External Manager &
Sub-Adviser Oversight. Merged into keys.py by dm_model.

Same format and conventions as keys.py (see CONTRACT.md section 1). Composite keys follow the GRAIN_KEY_FORMATS of
proposals_w3_oversight.py. 52 External Manager Profile is a role profile of the 02 Party keyed by its PTY- reference.
"""


def _k(pk, key_type, fold=None, note=""):
    return dict(pk=pk, key_type=key_type, fold=fold, note=note)


def _fold(note=""):
    return dict(pk=[], key_type="Composite", fold=True, note=note)


def _child(pk, note=""):
    return dict(pk=pk, key_type="Composite", fold=False, note=note)


PARTY = ("02", "Party")
TRUST = ("51", "Trust")
EMPLOYEE = ("20", "Employee")
SUB_ADVISER_ENGAGEMENT = ("52", "Sub-Adviser Engagement")
EXTERNAL_MANAGER_PROFILE = ("52", "External Manager Profile")
EXTERNAL_MANAGER_STRATEGY = ("52", "External Manager Strategy")
MANAGER_DUE_DILIGENCE_REVIEW = ("52", "Manager Due Diligence Review")
OVERSIGHT_REVIEW = ("52", "Oversight Review")
PRODUCT = ("01", "Investment Product")
INVESTMENT_COMMITTEE_DECISION = ("24", "Investment Committee Decision")
PRODUCT_DUE_DILIGENCE = ("52", "Product Due Diligence")

KEYS = {
    # ------------------------------------------------------------------ 51 Trust & Estate Services
    ("51", "Trust"): _k(["Trust ID"], "Natural"),
    ("51", "Trust Instrument Document"): _child(["Instrument Version Number"]),
    ("51", "Trust Term Provision"): _k(["Provision Trust", "Provision Type", "Provision Sequence",
                                        "Provision Instrument Version"], "Composite"),
    ("51", "Trust Role"): _k(["Role Trust", "Role Holder Party", "Role Holder Entity",
                              "Trust Role Type", "Role Effective From"], "Composite",
                             note="Exactly one of the party or internal legal entity is populated."),
    ("51", "Beneficial Interest"): _k(["Interest Trust", "Beneficiary Party",
                                       "Beneficial Interest Type", "Interest Effective From"], "Composite"),
    ("51", "Trust Distribution Request"): _k(["Distribution Request ID"], "Natural"),
    ("51", "Distribution Decision"): _fold(),
    ("51", "Principal and Income Allocation"): _k(["Allocation Trust", "Source Account Activity",
                                                   "Source Money Movement", "Allocation Sequence"], "Composite",
                                                  note="Exactly one source event is populated."),
    ("51", "Fiduciary Accounting Statement"): _k(["Statement Trust", "Accounting Period End"], "Composite"),
    ("51", "Fiduciary Account Review"): _k(["Fiduciary Review ID"], "Natural"),
    ("51", "Fiduciary Review Exception"): _child(["Exception Sequence"]),
    ("51", "Estate Settlement Case"): _k(["Estate Settlement Case ID"], "Natural"),
    ("51", "Estate Settlement Task"): _child(["Estate Milestone", "Task Sequence"]),
    ("51", "Fiduciary Tax Return"): _k(["Fiduciary Tax Return ID"], "Natural"),
    ("51", "Beneficiary Tax Allocation"): _child(["K-1 Beneficiary"]),

    # ------------------------------------------------------------------ 52 External Manager & Sub-Adviser Oversight
    ("52", "External Manager Profile"): _k(["Profiled Manager"], "Composite",
                                           note="Role profile of the 02 Party; keyed by the PTY- reference."),
    ("52", "Manager Key Person"): _k(["Key Person Manager", "Key Person", "Key Person Role",
                                      "Role Start Date"], "Composite"),
    ("52", "External Manager Strategy"): _k(["External Manager Strategy ID"], "Natural"),
    ("52", "Manager Search"): _k(["Manager Search ID"], "Natural"),
    ("52", "Search Outcome"): _fold(),
    ("52", "Search Candidate"): _k(["Candidate Search", "Candidate Strategy"], "Composite"),
    ("52", "Due Diligence Questionnaire Template"): _k(["Questionnaire Template Code",
                                                        "Questionnaire Template Version"], "Composite"),
    ("52", "Manager Due Diligence Review"): _k(["Manager Due Diligence Review ID"], "Natural"),
    ("52", "Due Diligence Score"): _k(["Scored Review", "Scoring Factor"], "Composite"),
    ("52", "Onsite Visit"): _k(["Visited Review", "Visit Date"], "Composite"),
    ("52", "Background Check Result"): _k(["Checked Key Person", "Background Check Type", "Check Date"], "Composite"),
    ("52", "Sub-Adviser Engagement"): _k(["Sub-Adviser Engagement ID"], "Natural"),
    ("52", "Manager-of-Managers Hire Condition"): _fold(),
    ("52", "Sub-Adviser Guideline Set"): _k(["Guideline Set ID"], "Natural"),
    ("52", "Guideline Rule Inclusion"): _k(["Inclusion Guideline Set", "Included Compliance Rule",
                                            "Included Investment Restriction"], "Composite",
                                           note="Exactly one of the compliance rule or investment restriction is "
                                                "populated."),
    ("52", "Sub-Adviser Compliance Certification"): _k(["Certifying Manager", "Certifying Engagement",
                                                        "Certification Type",
                                                        "Certification Period End"], "Composite",
                                                       note="Exactly one of the manager or engagement is "
                                                            "populated, by certification type."),
    ("52", "Oversight Review"): _k(["Oversight Review ID"], "Natural"),
    ("52", "Oversight Metric Reading"): _k(["Reading Review", "Oversight Metric"], "Composite"),
    ("52", "Oversight Metric Threshold"): _k(["Threshold Engagement", "Threshold Metric",
                                              "Threshold Effective From"], "Composite"),
    ("52", "Sub-Adviser Watch Status"): _k(["Watched Engagement", "Watch Effective From"], "Composite"),
    ("52", "Section 15(c) Renewal Submission"): _k(["Submission Engagement", "Submission Renewal"], "Composite"),
    ("52", "Oversight Finding"): _k(["Oversight Finding ID"], "Natural"),
    ("52", "Remediation Action"): _k(["Remediated Finding", "Action Sequence"], "Composite"),
    ("52", "Product Due Diligence"): _k(["Product Due Diligence ID"], "Natural"),
    ("52", "Product Due Diligence Criterion Result"): _k(["Criterion Product Review",
                                                          "Product Due Diligence Criterion"], "Composite"),
    ("52", "Fund of Funds Use Detail"): _k(["Fund of Funds Product Review", "Acquiring Fund"], "Composite"),
    ("52", "Product List Status"): _k(["Listed Instrument", "List Scope", "List Status Effective From"], "Composite"),
    ("52", "Manager Termination"): _k(["Terminated Engagement", "Termination Effective Date"], "Composite"),
}

REFS = {
    # ------------------------------------------------------------------ 51 Trust & Estate Services
    ("51", "Trust", "Trust Party"): PARTY,
    ("51", "Trust", "Administering Trust Officer"): ("03", "Advisor"),
    ("51", "Trust Instrument Document", "Instrument Trust"): TRUST,
    ("51", "Trust Term Provision", "Provision Trust"): TRUST,
    ("51", "Trust Role", "Role Trust"): TRUST,
    ("51", "Trust Role", "Role Holder Party"): PARTY,
    ("51", "Trust Role", "Role Holder Entity"): ("09", "Internal Legal Entity"),
    ("51", "Beneficial Interest", "Interest Trust"): TRUST,
    ("51", "Beneficial Interest", "Beneficiary Party"): PARTY,
    ("51", "Trust Distribution Request", "Request Trust"): TRUST,
    ("51", "Trust Distribution Request", "Request Beneficiary"): PARTY,
    ("51", "Trust Distribution Request", "Intake Service Request"): ("13", "Service Request"),
    ("51", "Distribution Decision", "Decision Request"): ("51", "Trust Distribution Request"),
    ("51", "Distribution Decision", "Provision Applied"): ("51", "Trust Term Provision"),
    ("51", "Distribution Decision", "Decided By"): EMPLOYEE,
    ("51", "Principal and Income Allocation", "Allocation Trust"): TRUST,
    ("51", "Principal and Income Allocation", "Source Account Activity"): ("49", "Client Account Activity"),
    ("51", "Principal and Income Allocation", "Source Money Movement"): ("50", "Money Movement"),
    ("51", "Fiduciary Accounting Statement", "Statement Trust"): TRUST,
    ("51", "Fiduciary Account Review", "Review Trust"): TRUST,
    ("51", "Fiduciary Account Review", "Accounts Reviewed"): ("15", "Account"),
    ("51", "Fiduciary Account Review", "Reviewer"): EMPLOYEE,
    ("51", "Fiduciary Account Review", "Reviewing Committee"): ("39", "Corporate Governing Body"),
    ("51", "Fiduciary Review Exception", "Exception Review"): ("51", "Fiduciary Account Review"),
    ("51", "Fiduciary Review Exception", "Related Conflict"): ("38", "Conflict of Interest"),
    ("51", "Estate Settlement Case", "Decedent"): PARTY,
    ("51", "Estate Settlement Case", "Case Death Notification"): ("02", "Death Notification"),
    ("51", "Estate Settlement Case", "Fiduciary Entity"): ("09", "Internal Legal Entity"),
    ("51", "Estate Settlement Case", "Personal Representative"): PARTY,
    ("51", "Estate Settlement Case", "Representative Authority Grant"): ("02", "Authority Grant"),
    ("51", "Estate Settlement Case", "Testamentary Trust"): TRUST,
    ("51", "Estate Settlement Case", "Estate Litigation Matter"): ("39", "Legal Matter"),
    ("51", "Estate Settlement Task", "Task Case"): ("51", "Estate Settlement Case"),
    ("51", "Fiduciary Tax Return", "Return Trust"): TRUST,
    ("51", "Fiduciary Tax Return", "Return Estate Case"): ("51", "Estate Settlement Case"),
    ("51", "Fiduciary Tax Return", "Filing Entity Party"): PARTY,
    ("51", "Beneficiary Tax Allocation", "Allocation Return"): ("51", "Fiduciary Tax Return"),
    ("51", "Beneficiary Tax Allocation", "K-1 Beneficiary"): PARTY,

    # ------------------------------------------------------------------ 52 External Manager & Sub-Adviser Oversight
    ("52", "External Manager Profile", "Profiled Manager"): PARTY,
    ("52", "External Manager Profile", "Coverage Analyst"): EMPLOYEE,
    ("52", "External Manager Profile", "AUM Source Dataset"): ("14", "Dataset"),
    ("52", "Manager Key Person", "Key Person Manager"): EXTERNAL_MANAGER_PROFILE,
    ("52", "Manager Key Person", "Key Person"): PARTY,
    ("52", "Manager Key Person", "Key Person Strategies"): EXTERNAL_MANAGER_STRATEGY,
    ("52", "External Manager Strategy", "Strategy Manager"): EXTERNAL_MANAGER_PROFILE,
    ("52", "Manager Search", "Target Product"): PRODUCT,
    ("52", "Manager Search", "Target Mandate"): ("01", "Investment Mandate"),
    ("52", "Manager Search", "Search Owner"): EMPLOYEE,
    ("52", "Search Outcome", "Selected Strategy"): EXTERNAL_MANAGER_STRATEGY,
    ("52", "Search Outcome", "Approving Committee Decision"): INVESTMENT_COMMITTEE_DECISION,
    ("52", "Search Outcome", "Resulting Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Search Candidate", "Candidate Search"): ("52", "Manager Search"),
    ("52", "Search Candidate", "Candidate Strategy"): EXTERNAL_MANAGER_STRATEGY,
    ("52", "Search Candidate", "Candidate Due Diligence Reviews"): MANAGER_DUE_DILIGENCE_REVIEW,
    ("52", "Manager Due Diligence Review", "Reviewed Manager"): EXTERNAL_MANAGER_PROFILE,
    ("52", "Manager Due Diligence Review", "Reviewed Strategy"): EXTERNAL_MANAGER_STRATEGY,
    ("52", "Manager Due Diligence Review", "Questionnaire Template Used"):
        ("52", "Due Diligence Questionnaire Template"),
    ("52", "Manager Due Diligence Review", "Lead Reviewer"): EMPLOYEE,
    ("52", "Due Diligence Score", "Scored Review"): MANAGER_DUE_DILIGENCE_REVIEW,
    ("52", "Onsite Visit", "Visited Review"): MANAGER_DUE_DILIGENCE_REVIEW,
    ("52", "Onsite Visit", "Firm Attendees"): EMPLOYEE,
    ("52", "Onsite Visit", "Manager Attendees"): PARTY,
    ("52", "Background Check Result", "Checked Key Person"): ("52", "Manager Key Person"),
    ("52", "Background Check Result", "Check Provider"): PARTY,
    ("52", "Sub-Adviser Engagement", "Engaged Sub-Adviser"): EXTERNAL_MANAGER_PROFILE,
    ("52", "Sub-Adviser Engagement", "Engaged Strategy"): EXTERNAL_MANAGER_STRATEGY,
    ("52", "Sub-Adviser Engagement", "Governing Fund Agreement"): ("35", "Fund Advisory Agreement"),
    ("52", "Sub-Adviser Engagement", "Governing Contract"): ("39", "Contract"),
    ("52", "Sub-Adviser Engagement", "Overseeing Adviser Entity"): ("09", "Internal Legal Entity"),
    ("52", "Sub-Adviser Engagement", "Engaged Fund"): PRODUCT,
    ("52", "Sub-Adviser Engagement", "Delegated Mandate"): ("01", "Investment Mandate"),
    ("52", "Sub-Adviser Engagement", "Sleeve Portfolio"): ("18", "Portfolio"),
    ("52", "Manager-of-Managers Hire Condition", "Relied-On Exemptive Relief"): ("35", "Exemptive Relief Reliance"),
    ("52", "Manager-of-Managers Hire Condition", "Information Statement Communication"):
        ("13", "Shareholder Communication"),
    ("52", "Sub-Adviser Guideline Set", "Guideline Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Sub-Adviser Guideline Set", "Acknowledged By"): PARTY,
    ("52", "Guideline Rule Inclusion", "Inclusion Guideline Set"): ("52", "Sub-Adviser Guideline Set"),
    ("52", "Guideline Rule Inclusion", "Included Compliance Rule"): ("33", "Compliance Rule"),
    ("52", "Guideline Rule Inclusion", "Included Investment Restriction"): ("01", "Investment Restriction"),
    ("52", "Sub-Adviser Compliance Certification", "Certifying Manager"): EXTERNAL_MANAGER_PROFILE,
    ("52", "Sub-Adviser Compliance Certification", "Certifying Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Sub-Adviser Compliance Certification", "Certified By"): PARTY,
    ("52", "Sub-Adviser Compliance Certification", "Linked Investment Breaches"): ("33", "Investment Breach"),
    ("52", "Oversight Review", "Reviewed Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Oversight Review", "Reviewed Product"): ("17", "Instrument"),
    ("52", "Oversight Review", "Oversight Reviewer"): EMPLOYEE,
    ("52", "Oversight Metric Reading", "Reading Review"): OVERSIGHT_REVIEW,
    ("52", "Oversight Metric Reading", "Source Performance Return"): ("32", "Performance Return"),
    ("52", "Oversight Metric Reading", "Source Benchmark Return"): ("32", "Benchmark Return"),
    ("52", "Oversight Metric Reading", "Source Ex-Post Risk Statistic"): ("32", "Ex-Post Risk Statistic"),
    ("52", "Oversight Metric Reading", "Source Risk Measure"): ("31", "Portfolio Risk Measure"),
    ("52", "Oversight Metric Reading", "Source Peer Metric Snapshot"): ("11", "Peer Metric Snapshot"),
    ("52", "Oversight Metric Reading", "Source Fee Benchmark Result"): ("11", "Fee Benchmark Result"),
    ("52", "Oversight Metric Reading", "Source Financial Highlights"): ("27", "Financial Highlights"),
    ("52", "Oversight Metric Reading", "Breach Count Guideline Set"): ("52", "Sub-Adviser Guideline Set"),
    ("52", "Oversight Metric Reading", "Source Investment Breaches"): ("33", "Investment Breach"),
    ("52", "Oversight Metric Threshold", "Threshold Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Oversight Metric Threshold", "Threshold Approving Decision"): INVESTMENT_COMMITTEE_DECISION,
    ("52", "Sub-Adviser Watch Status", "Watched Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Sub-Adviser Watch Status", "Deciding Oversight Review"): OVERSIGHT_REVIEW,
    ("52", "Section 15(c) Renewal Submission", "Submission Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Section 15(c) Renewal Submission", "Submission Renewal"): ("35", "Advisory Contract Renewal"),
    ("52", "Section 15(c) Renewal Submission", "Included Oversight Reviews"): OVERSIGHT_REVIEW,
    ("52", "Oversight Finding", "Source Due Diligence Review"): MANAGER_DUE_DILIGENCE_REVIEW,
    ("52", "Oversight Finding", "Source Onsite Visit"): ("52", "Onsite Visit"),
    ("52", "Oversight Finding", "Source Oversight Review"): OVERSIGHT_REVIEW,
    ("52", "Oversight Finding", "Source Product Due Diligence"): PRODUCT_DUE_DILIGENCE,
    ("52", "Oversight Finding", "Source Certification"): ("52", "Sub-Adviser Compliance Certification"),
    ("52", "Oversight Finding", "Finding Manager"): EXTERNAL_MANAGER_PROFILE,
    ("52", "Oversight Finding", "Finding Owner"): EMPLOYEE,
    ("52", "Remediation Action", "Remediated Finding"): ("52", "Oversight Finding"),
    ("52", "Remediation Action", "Action Owner Party"): PARTY,
    ("52", "Remediation Action", "Action Owner Employee"): EMPLOYEE,
    ("52", "Product Due Diligence", "Reviewed Instrument"): ("17", "Instrument"),
    ("52", "Product Due Diligence", "Feeder Product"): PRODUCT,
    ("52", "Product Due Diligence", "Sponsor Due Diligence Review"): MANAGER_DUE_DILIGENCE_REVIEW,
    ("52", "Product Due Diligence", "Product Approving Decision"): INVESTMENT_COMMITTEE_DECISION,
    ("52", "Product Due Diligence", "Product Reviewer"): EMPLOYEE,
    ("52", "Product Due Diligence Criterion Result", "Criterion Product Review"): PRODUCT_DUE_DILIGENCE,
    ("52", "Fund of Funds Use Detail", "Fund of Funds Product Review"): PRODUCT_DUE_DILIGENCE,
    ("52", "Fund of Funds Use Detail", "Acquiring Fund"): PRODUCT,
    ("52", "Fund of Funds Use Detail", "Fund of Funds Investment Agreement"): ("39", "Contract"),
    ("52", "Product List Status", "Listed Instrument"): ("17", "Instrument"),
    ("52", "Product List Status", "Deciding Product Review"): PRODUCT_DUE_DILIGENCE,
    ("52", "Product List Status", "Deciding Oversight Review"): OVERSIGHT_REVIEW,
    ("52", "Manager Termination", "Terminated Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Manager Termination", "Deciding Committee Decision"): INVESTMENT_COMMITTEE_DECISION,
    ("52", "Manager Termination", "Replacement Engagement"): SUB_ADVISER_ENGAGEMENT,
    ("52", "Manager Termination", "Originating Search"): ("52", "Manager Search"),
    ("52", "Manager Termination", "Transition Event"): ("12", "Transition Event"),
}
