"""Logical data models: consumer-aligned Star model for privacy rights (DP-080). See CONTRACT.md.

Conventions used in these stars:
- Dimensions mastered by a foundational product in the spec's upstream are declared conformed (conformed=(DP, entity))
  and named for their role. Product input objects of the same concept sit in that conformed entity.
- Where the mastering product is not in the spec's upstream, the dimension is built from the product's own inputs, or
  kept with a surrogate key only, and the notes record "Model gap: <DP> not in upstream".
- Scores and recommendations have no home in the taxonomy. Each is modeled as a main Fact at the product grain with no
  input objects of its own; it carries the product measures (measures=True) and joins to the dimensions by
  "<Dimension> Key".
- Where a reference attribute's REFS target is held by the parent, the attribute itself is the foreign key; otherwise
  the attribute stays descriptive and the join is "<Parent> Key".
"""
# DP-046, DP-047, DP-048, DP-049, DP-052 and DP-053 retired at WP0 (framework.RETIRED_PRODUCTS); their models were deleted with their specs in the WP2 retirement sweep.

MODELS = {






    # ------------------------------------------------------------------------------------------------------------------
    "DP-080": dict(
        # WP1 re-point (CW-210): re-cut to the specs_w1c_cla_a.py DP-080 inputs; see notes.
        style='Star',
        entities=[
            dict(name='Fact Request Status',
                 role='Fact',
                 objects=[],
                 pk=['Consumer Privacy Request Key', 'Calendar Date Key'],
                 measures=True,
                 grain='one row = consumer privacy request x request status as-of date (daily snapshot; the product grain)',
                 note='Daily status snapshot; closure dates are inferred from status changes until the taxonomy carries them.'),
            dict(name='Fact Retention Schedule',
                 role='Fact',
                 objects=[],
                 pk=['Data Subject Key'],
                 grain='one row = party x retention schedule (current Scheduled Erasure Date; the companion grain)',
                 note='The 02 Retention columns fold into Data Subject (registry), so this companion fact holds keys only and joins to the governing retention rule and the erasure date.'),
            dict(name='Fact Erasure Propagation Check',
                 role='Fact',
                 objects=[],
                 pk=['Fact Erasure Propagation Check Key'],
                 grain='one row = data subject request x holding record checked (consent, communication preference, lead, web visitor, suppression entry or vendor dataset)',
                 note='Feeds Erasure Propagation Exceptions and Suppression Coverage. Taxonomy gap: no record of which systems an erasure reached, so this fact is built by the product.'),
            dict(name='Data Subject',
                 role='Dimension',
                 objects=[('02', 'Party'), ('02', 'Privacy Profile')],
                 pk=['Party ID'],
                 note="Built from inputs rather than DP-002 Financial Professional, because data subjects include any individual (leads, consultants' staff, investors), not only financial professionals. Privacy Profile and Retention fold here."),
            dict(name='Consent Record',
                 role='Dimension',
                 conformed=('DP-011', 'Consent Record'),
                 objects=[('02', 'Consent Record')]),
            dict(name='Communication Preference',
                 role='Dimension',
                 objects=[('02', 'Communication Preference')],
                 pk=['Communication Preference Key'],
                 note='Model gap: Preference Topic (part of the registry key) is not an input, so a surrogate key is used.'),
            dict(name='Web Visitor',
                 role='Dimension',
                 conformed=('DP-011', 'Web Visitor'),
                 objects=[('04', 'Web Visitor / Known User')]),
            dict(name='Marketing Lead',
                 role='Dimension',
                 objects=[('04', 'Marketing Lead')],
                 pk=['Lead ID'],
                 note='Not modeled by DP-011, so built from inputs.'),
            dict(name='Country',
                 role='Dimension',
                 conformed=('DP-013', 'Country'),
                 objects=[]),
            dict(name='Calendar Date',
                 role='Dimension',
                 conformed=('DP-013', 'Calendar Date'),
                 objects=[]),
            dict(name='Consumer Privacy Request',
                 role='Dimension',
                 objects=[('02', 'Consumer Privacy Request')],
                 pk=['Privacy Request ID']),
            dict(name='Tracking Consent Choice',
                 role='Dimension',
                 objects=[('04', 'Tracking Consent Choice')],
                 pk=['Choice Visitor', 'Choice Timestamp']),
            dict(name='Retention Rule',
                 role='Dimension',
                 objects=[('21', 'Retention Rule')],
                 pk=['Retention Rule ID']),
            dict(name='Investor Document',
                 role='Dimension',
                 objects=[('13', 'Investor Document')],
                 pk=['Investor Document ID']),
        ],
        relationships=[
            dict(child='Fact Request Status', parent='Calendar Date', fk=['Calendar Date Key'], card='M:1', note='Status as-of date.'),
            dict(child='Fact Request Status', parent='Consumer Privacy Request', fk=['Consumer Privacy Request Key'], card='M:1', note='WP1 re-point (CW-210): the 02 Consumer Privacy Request replaces the GDPR Data Subject Request.'),
            dict(child='Data Subject', parent='Country', fk=['Country Key'], card='M:1', optional=True, note='From Primary Country.'),
            dict(child='Fact Retention Schedule', parent='Data Subject', fk=['Data Subject Key'], card='M:1'),
            dict(child='Fact Retention Schedule', parent='Retention Rule', fk=['Retention Rule Key'], card='M:1', optional=True, note='Model gap: Retention Category has no reference to 08 Retention Rule; mapped by the product.'),
            dict(child='Fact Retention Schedule', parent='Calendar Date', fk=['Calendar Date Key'], card='M:1', optional=True, note='From Scheduled Erasure Date.'),
            dict(child='Consent Record', parent='Data Subject', fk=['Data Subject Key'], card='M:1', note='Model gap: Consent Record carries no party attribute in the inputs; the key is borrowed.'),
            dict(child='Communication Preference', parent='Data Subject', fk=['Preference Party'], card='M:1'),
            dict(child='Web Visitor', parent='Data Subject', fk=['Matched Party'], card='M:1', optional=True),
            dict(child='Marketing Lead', parent='Data Subject', fk=['Lead Party'], card='M:1', optional=True),
            dict(child='Fact Erasure Propagation Check', parent='Consent Record', fk=['Consent Record Key'], card='M:1', optional=True),
            dict(child='Fact Erasure Propagation Check', parent='Communication Preference', fk=['Communication Preference Key'], card='M:1', optional=True),
            dict(child='Fact Erasure Propagation Check', parent='Marketing Lead', fk=['Marketing Lead Key'], card='M:1', optional=True),
            dict(child='Fact Erasure Propagation Check', parent='Web Visitor', fk=['Web Visitor Key'], card='M:1', optional=True),
            dict(child='Consent Record', parent='Data Subject', fk=['Consenting Party'], card='M:1', optional=True),
            dict(child='Consent Record', parent='Data Subject', fk=['Data Recipient'], card='M:1', optional=True),
            dict(child='Consumer Privacy Request', parent='Data Subject', fk=['Requesting Party'], card='M:1', optional=True),
            dict(child='Tracking Consent Choice', parent='Web Visitor', fk=['Choice Visitor'], card='M:1'),
            dict(child='Investor Document', parent='Fact Request Status', fk=['Fact Request Status Key'], card='M:1', optional=True, note='Model gap: no input attribute of Investor Document carries its link to Fact Request Status; the placeholder key stands for the lineage join.'),
        ],
        notes="Privacy rights star: Fact Request Status (daily request snapshot) carries the measures; Fact Retention Schedule is the party-level companion; Fact Erasure Propagation Check links each request to the holding records it must reach. Consent Record, Web Visitor, Dataset, Country and Calendar Date are conformed from DP-011, DP-075 and DP-013. Taxonomy gap: Data Subject Request lacks ID, party, received date, regime and outcome; no propagation record (spec notes). Model gap: no party link on Data Subject Request or Consent Record, and no link from Retention Category to Retention Rule; Communication Preference lacks Preference Topic as an input. Decision for data owners: Data Subject is built from 02 Party rather than conformed to DP-002 Financial Professional, because the scope is every individual; a foundational individual-party dimension would let this conform. WP1 re-point (CW-210): re-cut to Consumer Privacy Rights & Opt-Out Evidence (US only): the GDPR, Data Subject Request, Retention, Processing Legal Basis and 14 Dataset entities leave with their inputs; the US privacy-rights objects are placed. Measures 'Objection Applied Flag' and 'Erasure Backlog' are now 'Opt-Out Applied Flag' and 'Retention-Limited Deletions'.",
    ),
}
