"""Logical data models: consumer Star model for DP-083 (re-specified at WP1 in specs_w1c_fop_corp.py). See CONTRACT.md.

Conventions used in these stars:
- Dimensions that a foundational product already models are conformed (conformed=("DP-nnn", "<Entity>")) and named for
  their role, e.g. "Distributor Firm" and "Distributor Office" both come from DP-001 Party.
- Where a product input is the same concept as a conformed dimension, it sits in that dimension's objects.
- Transactions and positions that are themselves the tested population are conformed entities with the Fact role:
  DP-006 / DP-007 already certify them at the needed grain, so they are reused rather than rebuilt.
- Where a reference attribute's REFS target is held in the model, the attribute itself is the foreign key. Where no
  attribute carries the link, the child borrows "<Parent> Key" and a "Model gap:" is recorded.
- Calendar roles (detection, received, approval, as-of, period end dates) are the DP-013 Calendar Date, joined on the
  date; the calendar is the firm's standard business calendar.
"""
# DP-060, DP-061, DP-062, DP-063, DP-065 and DP-084 retired at WP0 (framework.RETIRED_PRODUCTS); their models were deleted with their specs in the WP2 retirement sweep.

MODELS = {





    # ------------------------------------------------------------------------------------------------------------------
    "DP-083": dict(
        style='Star',
        entities=[
            dict(name='Fact Regulatory Obligation',
                 role='Fact',
                 objects=[('38', 'Regulatory Obligation')],
                 pk=['Obligation ID', 'As-of Date Key'],
                 measures=True,
                 grain='one row = regulatory obligation (rule citation x applicable legal entity) x as-of date (the product grain)',
                 note='A dated snapshot of the register, because obligations have no effective dates (spec taxonomy gap) and retirements show only as removal.'),
            dict(name='Fact Attestation',
                 role='Fact',
                 objects=[('38', 'Attestation')],
                 pk=['Attester', 'Attestation Type', 'Attestation Period End Key'],
                 grain='one row = attester x attestation type x attestation period',
                 note='Registry key plus the period, which no attribute carries (derived from the attestation calendar).'),
            dict(name='Employee Reporting Line',
                 role='Bridge',
                 conformed=('DP-192', 'Employee Reporting Line'),
                 objects=[('20', 'Employee Reporting Line')],
                 grain='one row = reporting employee x line manager x reporting line type x effective from',
                 note="Gives the attester's line manager for Overdue Attestation Count."),
            dict(name='Employee',
                 role='Dimension',
                 conformed=('DP-192', 'Employee'),
                 objects=[('20', 'Employee')],
                 note='Plays the obligation owner, attester and line manager roles. One entity because 20 Employee can be placed once.'),
            dict(name='Org Unit',
                 role='Dimension',
                 conformed=('DP-192', 'Org Unit'),
                 objects=[('09', 'Org Unit')]),
            dict(name='Legal Entity',
                 role='Dimension',
                 conformed=('DP-013', 'Internal Legal Entity'),
                 objects=[('09', 'Internal Legal Entity')]),
            dict(name='Entity Authorization',
                 role='Dimension',
                 conformed=('DP-013', 'Entity Authorization'),
                 objects=[('38', 'Entity Authorization')],
                 note='Outrigger of Legal Entity: regulator, authorization type and filing due dates.'),
            dict(name='As-of Date',
                 role='Dimension',
                 conformed=('DP-013', 'Calendar Date'),
                 objects=[]),
            dict(name='Attestation Period End',
                 role='Dimension',
                 conformed=('DP-013', 'Calendar Date'),
                 objects=[]),
            dict(name='Regulatory Change Item',
                 role='Dimension',
                 objects=[('38', 'Regulatory Change Item')],
                 pk=['Regulatory Change ID']),
            dict(name='Regulatory Change Impact',
                 role='Dimension',
                 objects=[('38', 'Regulatory Change Impact')],
                 pk=['Impacted Entity', 'Impacted Change Item']),
            dict(name='Investment Product',
                 role='Dimension',
                 conformed=('DP-004', 'Investment Product'),
                 objects=[('01', 'Investment Product'), ('01', 'Fund Legal Structure')]),
        ],
        relationships=[
            dict(child='Fact Regulatory Obligation', parent='As-of Date', fk=['As-of Date Key'], card='M:1'),
            dict(child='Fact Regulatory Obligation', parent='Legal Entity', fk=['Applicable Legal Entity'], card='M:1', note='Per CD-010 and CD-011, Applicable Legal Entity holds the Legal Entity ID of the conformed DP-013 Internal Legal Entity (the firm-defined code list maps to LEN- IDs), so no crosswalk is needed. The registry has no link for it yet because 08 still types the attribute as a Code.'),
            dict(child='Fact Regulatory Obligation', parent='Employee', fk=['Obligation Owner'], card='M:1', optional=True, note='Empty owner raises Unowned Obligation Flag.'),
            dict(child='Fact Attestation', parent='Employee', fk=['Attester'], card='M:1'),
            dict(child='Fact Attestation', parent='Attestation Period End', fk=['Attestation Period End Key'], card='M:1', note='Model gap: Attestation has no period; derived from Attestation Type and the attestation calendar.'),
            dict(child='Employee Reporting Line', parent='Employee', fk=['Reporting Employee'], card='M:1'),
            dict(child='Employee Reporting Line', parent='Employee', fk=['Line Manager'], card='M:1'),
            dict(child='Employee', parent='Org Unit', fk=['Home Org Unit'], card='M:1', optional=True),
            dict(child='Employee', parent='Legal Entity', fk=['Employing Legal Entity'], card='M:1', optional=True),
            dict(child='Entity Authorization', parent='Legal Entity', fk=['Authorized Entity'], card='M:1'),
            dict(child='Regulatory Change Impact', parent='Regulatory Change Item', fk=['Impacted Change Item'], card='M:1'),
            dict(child='Regulatory Change Impact', parent='Legal Entity', fk=['Impacted Entity'], card='M:1'),
            dict(child='Regulatory Change Impact', parent='Fact Regulatory Obligation', fk=['Affected Obligations'], card='M:1', optional=True),
            dict(child='Investment Product', parent='Fact Regulatory Obligation', fk=['Fact Regulatory Obligation Key'], card='M:1', optional=True, note='Model gap: no input attribute of Investment Product carries its link to Fact Regulatory Obligation; the placeholder key stands for the lineage join.'),
        ],
        notes="Regulatory obligations star. The obligation register snapshot is the main fact; attestations and horizon items are facts at their own grains. Employee, Employee Reporting Line (DP-009), Org Unit, Legal Entity, Entity Authorization, As-of Date and Attestation Period End (DP-013), Investment Product (DP-004) and Competent Authority (DP-001) are conformed. DP-041 is in upstream but is not a foundational model, so authorization context comes from the DP-013 Entity Authorization. Model gap: Attestation has no ID, period or obligation link; the period is borrowed and the obligation is matched by Attestation Type to Source Regulation. Model gap: Regulatory Horizon Item has no ID or links, and obligations have no product attribute, so both crosswalk bridges hold only keys and are maintained by Compliance Risk & Controls. Applicable Legal Entity joins Legal Entity on the Legal Entity ID, as CD-010 decides (GAP-08-026). Taxonomy gap: 08 Regulatory Obligation still types Applicable Legal Entity as a Code on the firm-defined Legal Entity list, so keys.REFS cannot point it to 09 Internal Legal Entity until 08 makes it Reference (Legal Entity) and retires the list (CD-011). Decision for data owners: who owns the two crosswalks. WP1 re-point (CW-260): re-cut to Regulatory Obligations & Attestations. Fact Regulatory Obligation, Fact Attestation, Employee, Employee Reporting Line, Org Unit, Legal Entity and Entity Authorization keep their objects; Employee, Employee Reporting Line and Org Unit now conform DP-192 (upstream) instead of DP-009 and DP-013. Fact Regulatory Horizon Item, Horizon Obligation Crosswalk, Obligation Fund Crosswalk, Investment Product and Competent Authority are dropped with their inputs (the horizon view moved to DP-509; fund regimes are DP-004's and DP-184's; DP-001 and DP-004 left the upstream); 09 Legal Entity Identifier left Legal Entity. The new 38 Regulatory Change Item and Regulatory Change Impact are a fact and its impact rows. WP1 re-point (CW-260, C-4 fix pass): 01 Investment Product with Fund Legal Structure (the fund regime of an obligation's products) is read again and is a dimension conformed from DP-004 Investment Product.",
    ),

}
