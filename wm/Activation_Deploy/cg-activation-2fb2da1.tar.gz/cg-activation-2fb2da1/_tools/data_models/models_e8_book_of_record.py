"""Logical data models, Wave E8 group "book_of_record": ER models for the foundational investment book of record products
DP-140 to DP-147 (portfolio master, transactions, holdings, prices, index data, official returns, risk measures, trading
agreements and SSIs) and DP-165 to DP-167 (NAV and fund financials, fund ledger, custody network). See CONTRACT.md.

Conventions used in these models:
- Each product's own master objects are entities keyed as the registry says; Attribute Groups with fold=True sit on their
  parent's entity, and the one fold=False group (27 Financial Highlights) is a child entity.
- Objects another foundational product publishes are conformed entities (role "Entity") named with the plain conformed
  name, e.g. Portfolio (DP-140), Instrument (DP-097), Party (DP-240), Share Class (DP-004). Where the product reads that
  object as an input, the input sits on the conformed entity. Where every key attribute of the source entity is among the
  product's inputs, the key is also written out (it is the registry key the source uses); otherwise it is inherited.
- Within this group the dependency order of the specs is kept: DP-140 publishes Portfolio, Portfolio Implementation Link
  and (until CD-322 extends DP-004) Investment Mandate; DP-143 publishes Approved Price and the other 22 masters; DP-144
  publishes Benchmark (until CD-322); DP-166 masters Fund Accounting Book (CD-186) and DP-165, which lists DP-166 upstream,
  republishes it under the same name; DP-165 publishes Fund NAV Calculation and Share Class NAV; DP-167 publishes
  Custodian and Safekeeping Account.
- A reference whose target product is not upstream (or is downstream, which would make a cycle) stays an attribute and is
  listed under "External references" in the model notes; it is resolved by joining to the named product.
- A single reference attribute that points to an entity with a composite key (e.g. Risk Model code x version) is drawn
  as the foreign key; the rest of the key comes from the context named in the relationship note.
"""


def ent(name, objects, pk, grain="", note="", measures=False):
    return dict(name=name, role="Entity", objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def conf(name, src, objects=(), pk=None, note=""):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role="Entity", conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources outside this group
PARTY = ("DP-240", "Party")
CPTY = ("DP-115", "Counterparty")
INSTR = ("DP-097", "Instrument")
CAE = ("DP-099", "Corporate Action Event")
EMP = ("DP-192", "Employee")
APP = ("DP-211", "Application")
MODEL = ("DP-212", "Model")
CONTRACT = ("DP-213", "Contract")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
STRAT = ("DP-004", "Investment Strategy")
MODELPF = ("DP-004", "Model Portfolio")
AGMT = ("DP-005", "Distribution Agreement")
LE = ("DP-013", "Internal Legal Entity")
CAL = ("DP-013", "Calendar")
FXTYPE = ("DP-013", "FX Rate Type")
CCY = ("DP-013", "Currency")
CLSCHEME = ("DP-013", "Classification Scheme")
ACCT = ("DP-093", "Account")
# conformed sources inside this group
PORT = ("DP-140", "Portfolio")
PIL = ("DP-140", "Portfolio Implementation Link")
MANDATE = ("DP-140", "Investment Mandate")
PTXN = ("DP-141", "Portfolio Transaction")
HOLD = ("DP-142", "Portfolio Holding")
PVS = ("DP-142", "Portfolio Valuation Summary")
INSTR142 = ("DP-142", "Instrument")
PRICE = ("DP-143", "Approved Price")
FVD = ("DP-143", "Fair Value Determination")
FXR = ("DP-143", "FX Rate Observation")
FIXING = ("DP-143", "Reference Rate Fixing")
CURVE = ("DP-143", "Curve Definition")
ETFSTAT = ("DP-143", "ETF Market Statistic")
BMK = ("DP-144", "Benchmark")
BMKASSIGN = ("DP-144", "Product Benchmark Assignment")
INDEXLVL = ("DP-144", "Index Level Observation")
NAVCALC = ("DP-165", "Fund NAV Calculation")
CLASSNAV = ("DP-165", "Share Class NAV")
BOOK = ("DP-166", "Fund Accounting Book")
BOOKOP = ("DP-166", "Fund Book Operating Period")
SKA = ("DP-167", "Safekeeping Account")


MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-140": dict(
        style="ER",
        entities=[
            ent("Portfolio",
                [("18", "Portfolio"), ("18", "Portfolio Accounting Basis"), ("18", "Fund Portfolio Detail"),
                 ("18", "SMA Portfolio Detail"), ("18", "Private Fund Portfolio Detail")],
                ["Portfolio ID"], measures=True,
                grain="one row = portfolio (managed book) x effective period",
                note="The conformed Portfolio dimension (PORT-, CD-145) every book of record, risk, performance, "
                     "compliance and fund accounting product slices by. The IBOR conventions and the fund, SMA and "
                     "private fund detail groups have one row per portfolio and fold here; only the matching group is "
                     "populated for a book. The effective period in the grain is the SCD type 2 version period added at "
                     "publication. Holds the measures because they are all counted per portfolio."),
            ent("Portfolio Identifier", [("18", "Portfolio Identifier")],
                ["Identified Portfolio", "Portfolio Identifier Scheme", "Portfolio Identifier Value",
                 "Identifier Effective From"],
                grain="one row = portfolio x identifier scheme x identifier value x effective period",
                note="Platform, custodian, administrator and sponsor codes for the book, used to match external files."),
            ent("Portfolio Implementation Link", [("18", "Portfolio Implementation Link")],
                ["Implementing Portfolio", "Implementation Link Type", "Implemented Product", "Implemented Mandate",
                 "Managed Account", "Followed Model Portfolio", "Implementation Effective From"],
                grain="one row = portfolio x implemented product / mandate / account / model x link type x effective "
                      "period",
                note="The one portfolio-to-fund, mandate, account and model mapping in the catalog (CD-324), published "
                     "for every product that rolls portfolio values up to a fund or client. Polymorphic: exactly one of "
                     "Implemented Product, Implemented Mandate and Managed Account is set by link type, and the unused "
                     "key parts are blank; Followed Model Portfolio is set on model-following books."),
            ent("Portfolio Hierarchy Link", [("18", "Portfolio Hierarchy Link")],
                ["Parent Portfolio", "Child Portfolio", "Portfolio Hierarchy Link Type", "Hierarchy Effective From"],
                grain="one row = parent portfolio x child portfolio x link type x effective period",
                note="Sleeve, carve-out, aggregate and successor links between books; an associative entity on "
                     "Portfolio."),
            ent("Portfolio Lifecycle Event", [("18", "Portfolio Lifecycle Event")],
                ["Event Portfolio", "Portfolio Lifecycle Event Type", "Event Effective Date"],
                grain="one row = portfolio x lifecycle event type x event effective date",
                note="Set-up, funding, transition, merger and termination events with their approval status; "
                     "Counterpart Portfolio names the other book of a merger or transition."),
            ent("Investment Mandate", [("01", "Investment Mandate")], ["Mandate ID"],
                grain="one row = investment mandate (segregated account or SMA)",
                note="Read directly from 01 because DP-004 does not yet carry Investment Mandate (CD-322); this product "
                     "publishes it for the book of record group until the DP-004 extension is built, after which it "
                     "becomes a conformed entity from DP-004 with no change to the inputs. DP-003 also models the "
                     "mandate (client side) but is not upstream here."),
            ent("Mandate Termination", [("12", "Mandate Termination")], ["Termination ID"],
                grain="one row = mandate termination notice",
                note="Read directly because the mandate's end date lives only in 12 (rule 2 exception); feeds Open "
                     "Mandates Without Portfolio."),
            conf("Investment Product", PROD, [("01", "Investment Product")],
                 note="Conformed from DP-004; the fund or pooled vehicle a book implements."),
            conf("Share Class", SHARE, [("01", "Share Class")],
                 note="Conformed from DP-004; read for Live Products Without Portfolio (an active class marks a live "
                      "product)."),
            conf("Model Portfolio", MODELPF, [("01", "Model Portfolio")],
                 note="Conformed from DP-004; the model a model-following book tracks."),
            conf("Investment Strategy", STRAT, note="Conformed from DP-004; the strategy a product or mandate implements."),
            conf("Account", ACCT, note="Conformed from DP-093; the SMA or institutional account a book manages."),
            conf("Distribution Agreement", AGMT,
                 note="Conformed from DP-005; the sponsor program agreement an SMA book runs under."),
            conf("Internal Legal Entity", LE,
                 note="Conformed from DP-013; the legal owner and the managing entity of the book."),
            conf("Calendar", CAL, note="Conformed from DP-013; the valuation calendar of the book."),
            conf("FX Rate Type", FXTYPE, note="Conformed from DP-013; the FX rate type the IBOR uses for the book."),
            conf("Application", APP, note="Conformed from DP-211; the book of record system."),
            conf("Party", PARTY,
                 note="Conformed from DP-240; middle office providers, identifier issuers and mandate clients."),
        ],
        relationships=[
            rel("Portfolio", "Internal Legal Entity", ["Legal Owner Entity"], optional=True),
            rel("Portfolio", "Internal Legal Entity", ["Managing Entity"], optional=True),
            rel("Portfolio", "Application", ["Book of Record System"], optional=True),
            rel("Portfolio", "Party", ["Middle Office Provider"], optional=True,
                note="Set when the IBOR Operating Model is outsourced, hybrid or a shadow of a client custodian record."),
            rel("Portfolio", "Calendar", ["Valuation Calendar"], optional=True),
            rel("Portfolio", "FX Rate Type", ["FX Rate Type Used"], optional=True),
            rel("Portfolio", "Distribution Agreement", ["Sponsor Program Agreement"], optional=True,
                note="SMA and UMA books only."),
            rel("Portfolio Identifier", "Portfolio", ["Identified Portfolio"]),
            rel("Portfolio Identifier", "Party", ["Identifier Issuer"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True,
                note="Implements Product links."),
            rel("Portfolio Implementation Link", "Investment Mandate", ["Implemented Mandate"], optional=True,
                note="Implements Mandate links."),
            rel("Portfolio Implementation Link", "Account", ["Managed Account"], optional=True,
                note="Manages Account links (SMA and institutional accounts)."),
            rel("Portfolio Implementation Link", "Model Portfolio", ["Followed Model Portfolio"], optional=True),
            rel("Portfolio Hierarchy Link", "Portfolio", ["Parent Portfolio"]),
            rel("Portfolio Hierarchy Link", "Portfolio", ["Child Portfolio"]),
            rel("Portfolio Lifecycle Event", "Portfolio", ["Event Portfolio"]),
            rel("Portfolio Lifecycle Event", "Portfolio", ["Counterpart Portfolio"], optional=True,
                note="The other book of a merger, transition or succession."),
            rel("Share Class", "Investment Product", ["Parent Product"]),
            rel("Investment Product", "Investment Strategy", ["Implemented Strategy"]),
            rel("Investment Mandate", "Investment Strategy", ["Implemented Strategy"]),
            rel("Investment Mandate", "Party", ["Party Key"],
                note="Model gap: derived link. Client names the 12 Institutional Client, the client role profile keyed "
                     "by its party (Institutional Client Party); no 12 object is an input and DP-003, which models it, "
                     "is not upstream, so Client stays an attribute and Party Key carries the same Party ID to the "
                     "DP-240 Party."),
            rel("Mandate Termination", "Investment Mandate", ["Terminated Mandate"]),
        ],
        notes=("Foundational master, ER around the conformed Portfolio entity (PORT-) with its identifiers, lifecycle "
               "events and two associative entities: Portfolio Implementation Link (book to fund, mandate, account and "
               "model, CD-324) and Portfolio Hierarchy Link (book to book). Entity names other products conform: "
               "Portfolio, Portfolio Implementation Link, Portfolio Hierarchy Link and, until CD-322 is built, Investment "
               "Mandate. "
               "External references (resolved by joining to the named product, not linked here): Portfolio.Safekeeping "
               "Custody Account to DP-167 Safekeeping Account (DP-167 depends on this product, so it is not upstream and "
               "only the SKA- key is published); Fund Portfolio Detail.Cash Sweep Vehicle to DP-097 Instrument (Model "
               "gap: DP-097 is not in this product's upstream; the lead may add it, DP-097 does not read DP-140); "
               "Portfolio Lifecycle Event.Related Transition Event to the 12 Transition Event (no 12 product upstream). "
               "Warnings in the per-module check: conformed sources DP-211 and DP-240 are other E8 groups' models and are "
               "not loaded, so their fks warn that the parent does not hold Application or Party; Investment "
               "Mandate.Client targets 12 Institutional Client in the registry, so the mandate reaches the conformed "
               "Party on a derived Party Key that carries the institutional client's Party ID."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-141": dict(
        style="ER",
        entities=[
            ent("Portfolio Transaction", [("18", "Portfolio Transaction"), ("18", "Transaction Cost & Charge")],
                ["Portfolio Transaction ID"], measures=True,
                grain="one row = portfolio transaction (PTXN-) as booked in the IBOR",
                note="The booked transaction; its explicit cost components (one set per transaction) fold here. "
                     "Commission Amount, Research Payment Component, Trade FX Rate and Settlement Confirmed Indicator are "
                     "the values applied to this booking and are read as held. Holds the measures because they count "
                     "and sum bookings, with the event and capital activity measures read through the relationships."),
            ent("Portfolio Transaction Event", [("18", "Portfolio Transaction Event")],
                ["Event Transaction", "Portfolio Transaction Event Type", "Event Timestamp"],
                grain="one row = portfolio transaction x event type x event timestamp",
                note="The booking's event trail (new, amend, cancel, rebook); feeds Amendment Rate and Back-Dated "
                     "Bookings."),
            ent("Portfolio Capital Activity", [("18", "Portfolio Capital Activity")],
                ["Activity Portfolio", "Activity Share Class", "Activity Account", "Activity Trade Date",
                 "Capital Activity Type"],
                grain="one row = portfolio x (share class or client account) x trade date x capital activity type",
                note="Subscriptions, redemptions, contributions and withdrawals as booked to the portfolio; never "
                     "published as flows (DP-008 certifies net flows, CD-292). Either Activity Share Class or Activity "
                     "Account is set, and the other key part is blank."),
            conf("Portfolio", PORT, [("18", "Portfolio")], note="Conformed from DP-140."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; the transacted instrument."),
            conf("Counterparty", CPTY,
                 note="Conformed from DP-115 for the executing broker and the transaction counterparty. The registry "
                      "points both to 02 Party; DP-115's approved counterparty entity is keyed by that party, and DP-115 "
                      "is upstream for these roles (restored at the E1 merge)."),
            conf("Corporate Action Event", CAE, note="Conformed from DP-099; the event behind a corporate action booking."),
            conf("Share Class", SHARE, note="Conformed from DP-004; the class a fund capital activity row is booked for."),
            conf("Account", ACCT, note="Conformed from DP-093; the client account of SMA and mandate capital activity."),
        ],
        relationships=[
            rel("Portfolio Transaction", "Portfolio", ["Transaction Portfolio"]),
            rel("Portfolio Transaction", "Instrument", ["Transaction Instrument"]),
            rel("Portfolio Transaction", "Counterparty", ["Executing Broker"], optional=True),
            rel("Portfolio Transaction", "Counterparty", ["Transaction Counterparty"], optional=True),
            rel("Portfolio Transaction", "Corporate Action Event", ["Source Corporate Action Event"], optional=True),
            rel("Portfolio Transaction", "Portfolio Capital Activity", ["Related Capital Activity"], optional=True,
                note="The cash leg of a subscription or redemption booked to the portfolio. The capital activity key is "
                     "composite; the transaction's portfolio, trade date and type supply the rest of it."),
            rel("Portfolio Transaction Event", "Portfolio Transaction", ["Event Transaction"]),
            rel("Portfolio Transaction Event", "Portfolio Transaction", ["Rebooked As Transaction"], optional=True,
                note="Cancel and rebook: the replacement booking."),
            rel("Portfolio Capital Activity", "Portfolio", ["Activity Portfolio"]),
            rel("Portfolio Capital Activity", "Share Class", ["Activity Share Class"], optional=True),
            rel("Portfolio Capital Activity", "Account", ["Activity Account"], optional=True),
        ],
        notes=("Foundational ER: Portfolio Transaction (PTXN-) with its event trail as a child entity and Portfolio "
               "Capital Activity as a second booked record on the same portfolio. Entity names other products conform: "
               "Portfolio Transaction, Portfolio Transaction Event, Portfolio Capital Activity. "
               "External references (keys carried, not linked): Source Allocation ID to the 25 Trade Allocation (order "
               "and execution product, not upstream); Related Transition Event to 12 Transition Event; Event Source "
               "System to DP-211 Application (Model gap: DP-211 is not in this product's upstream); Source Cash Flow "
               "Notification to 12 Cash Flow Notification. "
               "Warnings in the per-module check: conformed sources DP-097, DP-099 and DP-115 are other E8 groups' models "
               "and are not loaded, so their fks warn that the parent does not hold Instrument, Corporate Action Event "
               "or Party; they resolve when the full build loads those models."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-142": dict(
        style="ER",
        entities=[
            ent("Portfolio Holding",
                [("18", "Portfolio Holding"), ("18", "Holding Valuation"), ("18", "Derivative Holding Detail"),
                 ("18", "Fund Interest Holding Detail")],
                ["Holding ID"], measures=True,
                grain="one row = portfolio x instrument x holding date x holding view (HLD-)",
                note="The IBOR holding with its valuation, derivative exposure and private fund interest detail folded "
                     "(one row each per holding; only the matching detail is populated). Price Used, Price Date, Price "
                     "Source, Holding FX Rate, Delta Used, Encumbered Quantity, Initial Margin Posted and Adjusted NAV are "
                     "the values applied to the holding and are read as held. Holds the measures; Portfolio Market Value "
                     "(IBOR) is never labeled AUM (CD-292)."),
            ent("Tax Lot", [("18", "Tax Lot")], ["Tax Lot ID"],
                grain="one row = portfolio x instrument x acquisition lot (current state)",
                note="History of each lot is kept through Lot Relief, not by versioning the lot."),
            ent("Lot Relief", [("18", "Lot Relief")], ["Relieved Tax Lot", "Closing Transaction"],
                grain="one row = tax lot x closing portfolio transaction",
                note="Associative entity between the lot and the closing transaction; carries realized gain and wash-sale "
                     "results."),
            ent("Cash Balance", [("18", "Cash Balance")],
                ["Cash Balance Portfolio", "Balance Currency", "Cash Safekeeping Account", "Balance Date",
                 "Cash Balance Type"],
                grain="one row = portfolio x currency x cash account x balance date x balance type"),
            ent("Projected Cash Movement", [("18", "Projected Cash Movement")],
                ["Projection Portfolio", "Projected Currency", "Projected Value Date", "Projected Cash Source",
                 "Source Portfolio Transaction", "Source Corporate Action Event"],
                grain="one row = portfolio x currency x projected value date x source item",
                note="The source item is a pending transaction or an announced corporate action; the unused source key "
                     "part is blank. Feeds the 24 investable cash forecast (CD-178)."),
            ent("Portfolio Position Snapshot", [("18", "Portfolio Position Snapshot")],
                ["Snapshot Portfolio", "Snapshot Type", "Snapshot As-Of Timestamp"],
                grain="one row = portfolio x snapshot type x as-of timestamp",
                note="Header of a locked set of holdings and cash for a business date and holding view; the member rows "
                     "are the holdings and balances of that date and view."),
            ent("Portfolio Valuation Summary", [("18", "Portfolio Valuation Summary")],
                ["Valued Portfolio", "Valuation As-Of Date", "Valuation View"],
                grain="one row = portfolio x valuation as-of date x valuation view",
                note="Portfolio total of holdings, cash and accrued income; Valuation Summary Tie-Out checks it against "
                     "the holdings."),
            conf("Portfolio", PORT, note="Conformed from DP-140."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; the held, lotted and priced instrument. DP-165 conforms it from here."),
            conf("Approved Price", PRICE, [("22", "Approved Price")],
                 note="Conformed from DP-143; read for Holdings at Approved Price % and Stale Priced Holdings, which "
                      "match the holding's instrument and Price Date to the approved price of the pricing point of the "
                      "portfolio's business line (see Model gap in the notes)."),
            conf("Portfolio Transaction", PTXN,
                 note="Conformed from DP-141; the opening and closing transactions of lots and the source of projected "
                      "cash."),
            conf("Safekeeping Account", SKA, note="Conformed from DP-167; the custody cash account of a cash balance."),
            conf("Corporate Action Event", CAE, note="Conformed from DP-099; the source of projected corporate action cash."),
        ],
        relationships=[
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Tax Lot", "Portfolio", ["Lot Portfolio"]),
            rel("Tax Lot", "Instrument", ["Lot Instrument"]),
            rel("Tax Lot", "Portfolio Transaction", ["Opening Transaction"], optional=True,
                note="Blank for lots taken on in kind or migrated without their opening booking."),
            rel("Lot Relief", "Tax Lot", ["Relieved Tax Lot"]),
            rel("Lot Relief", "Portfolio Transaction", ["Closing Transaction"]),
            rel("Lot Relief", "Tax Lot", ["Wash-Sale Replacement Lot"], optional=True,
                note="The replacement lot that takes the disallowed wash-sale loss into its basis."),
            rel("Cash Balance", "Portfolio", ["Cash Balance Portfolio"]),
            rel("Cash Balance", "Safekeeping Account", ["Cash Safekeeping Account"], optional=True),
            rel("Projected Cash Movement", "Portfolio", ["Projection Portfolio"]),
            rel("Projected Cash Movement", "Portfolio Transaction", ["Source Portfolio Transaction"], optional=True),
            rel("Projected Cash Movement", "Corporate Action Event", ["Source Corporate Action Event"], optional=True),
            rel("Portfolio Position Snapshot", "Portfolio", ["Snapshot Portfolio"]),
            rel("Portfolio Valuation Summary", "Portfolio", ["Valued Portfolio"]),
            rel("Portfolio Valuation Summary", "Portfolio Position Snapshot", ["Summary Snapshot"], optional=True,
                note="The locked snapshot the summary was struck from; the snapshot key is composite and the summary's "
                     "portfolio supplies the rest of it."),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
        ],
        notes=("Foundational ER: Portfolio Holding (HLD-) and Tax Lot (LOT-) are the masters (CD-146), with Lot Relief, "
               "Cash Balance, Projected Cash Movement, Portfolio Position Snapshot and Portfolio Valuation Summary as "
               "companion entities on the conformed Portfolio. Entity names other products conform: Portfolio Holding, "
               "Tax Lot, Lot Relief, Cash Balance, Projected Cash Movement, Portfolio Position Snapshot, Portfolio "
               "Valuation Summary, and Instrument (republished from DP-097 for DP-165). "
               "Model gap: Portfolio Holding carries no pricing point and no reference to the Approved Price used, so the "
               "approved price is matched by instrument, price date and the business line's pricing point convention "
               "(spec taxonomy gap); Approved Price therefore joins the model through Instrument only. "
               "External references (keys carried, not linked): Corresponding Shareholder Position to the 06 Position "
               "(DP-007); OTC Counterparty, Clearing Broker and Cash Custodian to 02 Party (Model gap: neither DP-240 nor "
               "DP-115 is in this product's upstream; the lead may add DP-240, which does not read DP-142). "
               "Warnings in the per-module check: conformed sources DP-097 and DP-099 are other E8 groups' models and are "
               "not loaded, so their fks warn that the parent does not hold Instrument or Corporate Action Event; they "
               "resolve in the full build."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-143": dict(
        style="ER",
        entities=[
            ent("Approved Price", [("22", "Approved Price")], ["Approved Price ID"], measures=True,
                grain="one row = instrument x pricing point x price date x approved price version",
                note="The conformed price (PRICE-, CD-167): one current version per instrument, pricing point and price "
                     "date, with superseded versions kept. Own fund share class rows carry the 27 NAV as the 22 record "
                     "holds it (CD-321). Holds the measures; the FX, fixing and ETF measures are read through the "
                     "companion entities."),
            ent("Pricing Policy", [("22", "Pricing Policy")], ["Pricing Policy Code", "Pricing Policy Version"],
                grain="one row = pricing policy x version",
                note="Records the pricing operating model and the outsourced pricing provider, if any."),
            ent("Pricing Point", [("22", "Pricing Point")], ["Pricing Point Code"],
                grain="one row = pricing point (purpose x snap time x calendar)"),
            ent("Fair Value Determination", [("22", "Fair Value Determination")], ["Fair Value Determination ID"],
                grain="one row = fair value determination (instrument x valuation date x pricing point, per portfolio "
                      "where set)",
                note="Level 3 and committee determinations (FVD-, CD-170); Valued Portfolio is mandatory for private fund "
                     "interests."),
            ent("FX Rate Observation", [("22", "FX Rate Observation")], ["FX Rate Observation ID"],
                grain="one row = rate type x currency pair x rate basis x tenor x as-of timestamp",
                note="The approved FX rate (FXR-, CD-168), spot, forward and period average."),
            ent("Reference Rate Fixing", [("22", "Reference Rate Fixing")],
                ["Fixed Reference Rate", "Fixing Tenor", "Fixing Value Type", "Fixing Date"],
                grain="one row = reference rate x tenor x value type x fixing date"),
            ent("Curve Definition", [("22", "Curve Definition")], ["Curve ID"],
                grain="one row = curve or volatility surface (CURVE-)",
                note="Holds both curves and volatility surfaces; a surface names its underlying instrument or "
                     "benchmark."),
            ent("Curve Point Observation", [("22", "Curve Point Observation")],
                ["Observed Curve", "Curve As-Of Date", "Curve Point Tenor"],
                grain="one row = curve x as-of date x tenor"),
            ent("Volatility Surface Point", [("22", "Volatility Surface Point")],
                ["Observed Surface", "Surface As-Of Date", "Expiry Tenor", "Strike Coordinate"],
                grain="one row = surface x as-of date x expiry tenor x strike coordinate"),
            ent("Pricing Analytics Observation", [("22", "Pricing Analytics Observation")],
                ["Analytics Instrument", "Analytics As-Of Date", "Analytics Source Dataset", "Pricing Analytic Measure"],
                grain="one row = instrument x as-of date x source dataset x analytic measure",
                note="Vendor duration, spread and yield analytics; Approved Analytics Value Indicator marks the value "
                     "the firm uses."),
            ent("Instrument Factor Observation", [("22", "Instrument Factor Observation")],
                ["Factor Observation Instrument", "Instrument Factor Type", "Factor Effective Date"],
                grain="one row = instrument x factor type x factor effective date",
                note="Pool, inflation and index factors."),
            ent("ETF Market Statistic", [("22", "ETF Market Statistic")], ["ETF Instrument", "Statistic Date"],
                grain="one row = ETF instrument x statistic date",
                note="Closing price, NBBO midpoint, premium / discount and median spread of own ETFs; Premium / "
                     "Discount NAV is the 27 NAV used, read as held."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; the priced, fair-valued and analytics instrument."),
            conf("Portfolio", PORT, note="Conformed from DP-140; the portfolio a fair value determination applies to."),
            conf("Party", PARTY,
                 note="Conformed from DP-240; pricing providers, rate administrators and factor sources."),
            conf("Calendar", CAL, note="Conformed from DP-013; the pricing calendar of a pricing point."),
            conf("FX Rate Type", FXTYPE, note="Conformed from DP-013; the rate type of an FX observation."),
            conf("Currency", CCY,
                 note="Conformed from DP-013; the currency pair of an FX observation and the currency of a price or "
                      "curve, which is how FX rates join the prices they translate."),
        ],
        relationships=[
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
            rel("Approved Price", "Pricing Point", ["Approved Pricing Point"]),
            rel("Approved Price", "Approved Price", ["Supersedes Approved Price"], card="1:1", optional=True,
                note="The prior version a restatement replaces."),
            rel("Approved Price", "Fair Value Determination", ["Applied Fair Value Determination"], optional=True),
            rel("Pricing Policy", "Party", ["Outsourced Pricing Provider"], optional=True,
                note="Set when pricing is outsourced to a fund administrator."),
            rel("Pricing Point", "Calendar", ["Pricing Calendar"]),
            rel("Fair Value Determination", "Instrument", ["Fair Valued Instrument"]),
            rel("Fair Value Determination", "Pricing Point", ["Determination Pricing Point"]),
            rel("Fair Value Determination", "Portfolio", ["Valued Portfolio"], optional=True),
            rel("FX Rate Observation", "FX Rate Type", ["Observed FX Rate Type"]),
            rel("FX Rate Observation", "Currency", ["Base Currency"]),
            rel("FX Rate Observation", "Currency", ["Quote Currency"]),
            rel("Approved Price", "Currency", ["Approved Price Currency"]),
            rel("Curve Definition", "Currency", ["Curve Currency"], optional=True),
            rel("Reference Rate Fixing", "Party", ["Rate Administrator"], optional=True),
            rel("Curve Definition", "Instrument", ["Surface Underlying Instrument"], optional=True,
                note="Volatility surfaces on a single instrument."),
            rel("Curve Point Observation", "Curve Definition", ["Observed Curve"]),
            rel("Volatility Surface Point", "Curve Definition", ["Observed Surface"]),
            rel("Pricing Analytics Observation", "Instrument", ["Analytics Instrument"]),
            rel("Instrument Factor Observation", "Instrument", ["Factor Observation Instrument"]),
            rel("Instrument Factor Observation", "Party", ["Factor Source Party"], optional=True),
            rel("ETF Market Statistic", "Instrument", ["ETF Instrument"]),
        ],
        notes=("Foundational ER for the 22 masters (CD-167, CD-168, CD-170, CD-206): Approved Price with its policy, "
               "pricing points and fair value determinations, and the FX, fixing, curve, surface, analytics, factor and "
               "ETF statistic observations as companion entities, joined on the conformed Instrument. Entity names other "
               "products conform: Approved Price, Pricing Point, Fair Value Determination, FX Rate Observation, Reference "
               "Rate Fixing, Curve Definition, Curve Point Observation, ETF Market Statistic. "
               "External references (keys carried, not linked): Approved Price.Selected Observation, Applied Price "
               "Override and Applied Fair Value Factor to 22 objects published only to DP-148; Own Fund Swing Decision "
               "and Own Fund NAV Record, and ETF Market Statistic.Premium / Discount NAV, to 27 (DP-165 is downstream, "
               "CD-321); Fair Value Determination.Valuation Model Name to 37 Model Inventory Entry and Approving Meeting "
               "to the 22 Valuation Committee Meeting (not inputs); Curve Definition.Surface Underlying Benchmark to 01 "
               "Benchmark (Model gap: DP-144, which publishes Benchmark, is not upstream; DP-144 does not read DP-143, so "
               "the lead may add it); the 14 Dataset references (Fixing, Curve, Analytics and Intraday Quote Source "
               "Dataset) to DP-014 Dataset, not upstream; Instrument.Own Share Class to DP-004 Share Class, not upstream. "
               "Fixed Reference Rate is a code, not a reference. "
               "Warnings in the per-module check: conformed sources DP-097 and DP-240 are other E8 groups' models and are "
               "not loaded, so their fks warn that the parent does not hold Instrument or Party."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-144": dict(
        style="ER",
        entities=[
            ent("Index Level Observation", [("22", "Index Level Observation")],
                ["Index Benchmark", "Level Date", "Index Level Variant", "Level Currency"], measures=True,
                grain="one row = benchmark x level date x index level variant x level currency",
                note="Daily index levels by price, net and gross total return variant; corrected levels are kept as "
                     "superseded rows. Holds the measures."),
            ent("Index Constituent", [("22", "Index Constituent")],
                ["Constituent Benchmark", "Constituent Instrument", "Vendor Constituent Identifier",
                 "Constituent Effective Date"],
                grain="one row = benchmark x instrument x effective date",
                note="Vendor Constituent Identifier is in the key because a constituent not yet set up in the security "
                     "master carries only the vendor identifier (Unresolved Constituent Rate)."),
            ent("Index Change Announcement", [("22", "Index Change Announcement")],
                ["Changed Benchmark", "Affected Index Instrument", "Index Change Type", "Change Effective Date",
                 "Announcement Date"],
                grain="one row = benchmark x instrument x change type x effective date x announcement date"),
            ent("Benchmark", [("01", "Benchmark")], ["Benchmark ID"],
                grain="one row = benchmark or index (BMK-)",
                note="Read directly from 01 because DP-004 does not yet carry Benchmark (CD-322); this product "
                     "publishes the Benchmark entity for the book of record group until the extension is built, then it "
                     "becomes a conformed entity from DP-004 with no change to the inputs."),
            ent("Product Benchmark Assignment", [("01", "Product Benchmark Assignment")],
                ["Assigned Product / Share Class", "Assigned Benchmark", "Benchmark Role", "Assignment Effective From"],
                grain="one row = share class x benchmark x benchmark role x effective period",
                note="Associative entity between share class and benchmark (primary, secondary, performance fee "
                     "hurdle); read directly until CD-322, like Benchmark."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; constituent and changed instruments."),
            conf("Corporate Action Event", CAE,
                 note="Conformed from DP-099; the corporate action behind an index change."),
            conf("Share Class", SHARE, note="Conformed from DP-004; the share class a benchmark is assigned to."),
        ],
        relationships=[
            rel("Index Level Observation", "Benchmark", ["Index Benchmark"]),
            rel("Index Constituent", "Benchmark", ["Constituent Benchmark"]),
            rel("Index Constituent", "Instrument", ["Constituent Instrument"], optional=True,
                note="Blank while the constituent is unresolved."),
            rel("Index Change Announcement", "Benchmark", ["Changed Benchmark"]),
            rel("Index Change Announcement", "Instrument", ["Affected Index Instrument"]),
            rel("Index Change Announcement", "Corporate Action Event", ["Related Corporate Action Event"],
                optional=True),
            rel("Benchmark", "Benchmark", ["Blend Components"], card="M:N", optional=True,
                note="A blended benchmark lists its component benchmarks; drawn M:N because the attribute holds several "
                     "members."),
            rel("Product Benchmark Assignment", "Share Class", ["Assigned Product / Share Class"]),
            rel("Product Benchmark Assignment", "Benchmark", ["Assigned Benchmark"]),
        ],
        notes=("Foundational ER for the 22 index data (CD-169 option A) keyed by the 01 Benchmark: levels, constituents "
               "and change announcements on the Benchmark entity, which this product publishes until CD-322 moves it to "
               "DP-004. Entity names other products conform: Benchmark, Product Benchmark Assignment, Index Level "
               "Observation, Index Constituent, Index Change Announcement. DP-097 also reads 01 Benchmark (for an "
               "instrument's related index); DP-144 is the product that publishes the benchmark with its levels. "
               "External references (keys carried, not linked): the 14 Dataset references (Index Level, Constituent and "
               "Change Source Dataset) to DP-014 Dataset, not upstream; Benchmark.Benchmark Administrator to 02 Party "
               "(Model gap: DP-240 is not in this product's upstream; Missing Level Days slices by the administrator key). "
               "Warnings in the per-module check: conformed sources DP-097 and DP-099 are other E8 groups' models and are "
               "not loaded, so their fks warn that the parent does not hold Instrument or Corporate Action Event."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-145": dict(
        # WP1 re-point (CW-129, CW-011): re-cut to the specs_w1f_certified.py DP-145 inputs; see notes.
        style='ER',
        entities=[
            dict(name='Performance Return',
                 role='Entity',
                 objects=[('32', 'Performance Return'), ('32', 'Return Component Detail'), ('32', 'Hypothetical Performance Detail')],
                 pk=['Performance Return ID', 'Return Version'],
                 measures=True,
                 grain='one row = return subject x period start x period end x fee basis x net fee basis x calculation type x price basis x tax basis x sales charge basis x currency x version (RETURN-)',
                 note='The certified Official Return (CD-217, CD-320). Polymorphic subject: one of Return Portfolio, Share Class, Account, Composite or Model Portfolio is set by Return Subject Type. Component values and the hypothetical detail have one row per return and fold here; the component values record what the return used and are read as held. Holds the measures.'),
            dict(name='Benchmark Return',
                 role='Entity',
                 objects=[('32', 'Benchmark Return')],
                 pk=['Return Benchmark', 'Benchmark Period Start Date', 'Benchmark Period End Date', 'Benchmark Return Type', 'Benchmark Return Currency', 'Benchmark Hedged Basis Indicator', 'Benchmark Return Version'],
                 grain='one row = benchmark x period x return type x currency x hedged basis x version',
                 note='The certified Benchmark Return; Start and End Index Level record the levels used (Benchmark Return Tie-Out).'),
            dict(name='Performance Calculation Policy',
                 role='Entity',
                 objects=[('32', 'Performance Calculation Policy')],
                 pk=['Calculation Policy Code', 'Calculation Policy Version'],
                 grain='one row = performance calculation policy x version'),
            dict(name='Performance Measurement Profile',
                 role='Entity',
                 objects=[('32', 'Performance Measurement Profile')],
                 pk=['Profiled Subject Type', 'Profiled Portfolio', 'Profiled Share Class', 'Profiled Account', 'Profiled Composite', 'Profiled Model Portfolio', 'Profile Effective From'],
                 grain='one row = return subject x profile effective period',
                 note='How each subject is measured (frequency, methodology, net fee treatments, close group); polymorphic subject like Performance Return.'),
            dict(name='Performance Period Close',
                 role='Entity',
                 objects=[('32', 'Performance Period Close')],
                 pk=['Close Group', 'Close Period End Date', 'Close Period Type'],
                 grain='one row = close group x period end date x period type'),
            dict(name='Performance Restatement',
                 role='Entity',
                 objects=[('32', 'Performance Restatement')],
                 pk=['Restated Return', 'Restatement Sequence'],
                 grain='one row = restated return x restatement sequence'),
            dict(name='Share Class NAV',
                 role='Entity',
                 conformed=('DP-165', 'Share Class NAV'),
                 objects=[('27', 'Share Class NAV')],
                 note='Conformed from DP-165; the NAV of record the share class return starts and ends on (Share Class Returns on NAV of Record %).'),
            dict(name='Fund NAV Calculation',
                 role='Entity',
                 conformed=('DP-165', 'Fund NAV Calculation'),
                 objects=[('27', 'Fund NAV Calculation')],
                 note='Conformed from DP-165; the parent of the class NAV and the residual value of a private fund measure.'),
            dict(name='Index Level Observation',
                 role='Entity',
                 conformed=('DP-144', 'Index Level Observation'),
                 objects=[('22', 'Index Level Observation')],
                 note='Conformed from DP-144; the start and end levels of a benchmark return.'),
            dict(name='Benchmark',
                 role='Entity',
                 conformed=('DP-144', 'Benchmark'),
                 objects=[('01', 'Benchmark')],
                 note='Conformed from DP-144 (01 Benchmark until CD-322); Blend Components drive blended returns.'),
            dict(name='Product Benchmark Assignment',
                 role='Entity',
                 conformed=('DP-144', 'Product Benchmark Assignment'),
                 objects=[('01', 'Product Benchmark Assignment')],
                 note='Conformed from DP-144; pairs each share class return with its benchmark return for Excess Return.'),
            dict(name='ETF Market Statistic',
                 role='Entity',
                 conformed=('DP-143', 'ETF Market Statistic'),
                 objects=[],
                 note='Conformed from DP-143; the market price statistic a market-price ETF return starts and ends on.'),
            dict(name='Portfolio',
                 role='Entity',
                 conformed=('DP-140', 'Portfolio'),
                 objects=[],
                 note='Conformed from DP-140; portfolio return subjects.'),
            dict(name='Share Class',
                 role='Entity',
                 conformed=('DP-004', 'Share Class'),
                 objects=[],
                 note='Conformed from DP-004; share class return subjects.'),
            dict(name='Account',
                 role='Entity',
                 conformed=('DP-093', 'Account'),
                 objects=[],
                 note='Conformed from DP-093; account return subjects (personal data, CD-220).'),
            dict(name='Model Portfolio',
                 role='Entity',
                 conformed=('DP-004', 'Model Portfolio'),
                 objects=[],
                 note='Conformed from DP-004; model portfolio return subjects.'),
            dict(name='Client Performance Profile',
                 role='Entity',
                 objects=[('32', 'Client Performance Profile')],
                 pk=['Client Profile Account', 'Client Profile Group', 'Client Profile Effective From']),
            dict(name='Household Performance Group',
                 role='Entity',
                 objects=[('32', 'Household Performance Group')],
                 pk=['Household Performance Group ID']),
            dict(name='Household Performance Group Member',
                 role='Entity',
                 objects=[('32', 'Household Performance Group Member')],
                 pk=['Member Performance Group', 'Member Account', 'Member Inclusion Date']),
            dict(name='Personal Rate of Return',
                 role='Entity',
                 objects=[('32', 'Personal Rate of Return')],
                 pk=['Personal Rate of Return ID']),
            dict(name='Client Return Exception',
                 role='Entity',
                 objects=[('32', 'Client Return Exception')],
                 pk=['Exception Account', 'Exception Date', 'Client Return Exception Type']),
            dict(name='Managed Account Composite',
                 role='Entity',
                 objects=[('46', 'Managed Account Composite')],
                 pk=['Managed Account Composite ID']),
            dict(name='Managed Account Composite Membership',
                 role='Entity',
                 objects=[('46', 'Managed Account Composite Membership')],
                 pk=['Membership Composite', 'Member Account', 'Membership Start Date']),
            dict(name='Client Holding',
                 role='Entity',
                 objects=[('49', 'Client Holding'), ('49', 'Client Holding Valuation')],
                 pk=['Client Holding ID']),
            dict(name='Account Cash Balance',
                 role='Entity',
                 objects=[('49', 'Account Cash Balance')],
                 pk=['Account Cash Balance Key']),
            dict(name='Margin Balance Snapshot',
                 role='Entity',
                 objects=[('49', 'Margin Balance Snapshot')],
                 pk=['Margin Snapshot Account', 'Margin Snapshot Business Date', 'Margin Snapshot Type', 'Margin Snapshot As-Of Timestamp']),
            dict(name='Client Account Activity',
                 role='Entity',
                 objects=[('49', 'Client Account Activity')],
                 pk=['Client Account Activity ID']),
            dict(name='Share Register Balance',
                 role='Entity',
                 objects=[('29', 'Share Register Balance')],
                 pk=['Register Account', 'Register Share Class', 'Register Business Date']),
            dict(name='Register Transaction',
                 role='Entity',
                 objects=[('29', 'Register Transaction')],
                 pk=['Register Transaction ID']),
            dict(name='Participant Balance',
                 role='Entity',
                 objects=[('16', 'Participant Balance')],
                 pk=['Participant Balance Key']),
            dict(name='Participant Plan Membership',
                 role='Entity',
                 objects=[('16', 'Participant Plan Membership')],
                 pk=['Membership ID']),
            dict(name='Participant Ledger Posting',
                 role='Entity',
                 objects=[('16', 'Participant Ledger Posting')],
                 pk=['Ledger Posting ID']),
            dict(name='Fee Debit',
                 role='Entity',
                 objects=[('47', 'Fee Debit')],
                 pk=['Fee Debit ID']),
            dict(name='Fee Invoice',
                 role='Entity',
                 objects=[('47', 'Fee Invoice')],
                 pk=['Invoice ID']),
            dict(name='Household Membership',
                 role='Entity',
                 objects=[('02', 'Household Membership')],
                 pk=['Household', 'Household Member', 'Membership Effective From']),
            dict(name='Account Party Role',
                 role='Entity',
                 objects=[('15', 'Account Party Role')],
                 pk=['Account Party Role Key']),
            dict(name='Party',
                 role='Entity',
                 conformed=('DP-240', 'Party'),
                 objects=[]),
            dict(name='Service Offering',
                 role='Entity',
                 conformed=('DP-004', 'Service Offering'),
                 objects=[]),
        ],
        relationships=[
            dict(child='Performance Return', parent='Portfolio', fk=['Return Portfolio'], card='M:1', optional=True),
            dict(child='Performance Return', parent='Share Class', fk=['Return Share Class'], card='M:1', optional=True),
            dict(child='Performance Return', parent='Account', fk=['Return Account'], card='M:1', optional=True),
            dict(child='Performance Return', parent='Model Portfolio', fk=['Return Model Portfolio'], card='M:1', optional=True),
            dict(child='Performance Return', parent='Share Class NAV', fk=['Start NAV Record'], card='M:1', optional=True),
            dict(child='Performance Return', parent='Share Class NAV', fk=['End NAV Record'], card='M:1', optional=True),
            dict(child='Performance Return', parent='ETF Market Statistic', fk=['Start Market Price Statistic'], card='M:1', optional=True, note="The statistic key is ETF instrument x date; the return's share class resolves the instrument."),
            dict(child='Performance Return', parent='ETF Market Statistic', fk=['End Market Price Statistic'], card='M:1', optional=True),
            dict(child='Performance Restatement', parent='Performance Return', fk=['Restated Return'], card='M:1', note="Restated Return names the return; Superseded and Restating Return Version complete the two versions' keys."),
            dict(child='Performance Measurement Profile', parent='Portfolio', fk=['Profiled Portfolio'], card='M:1', optional=True),
            dict(child='Performance Measurement Profile', parent='Share Class', fk=['Profiled Share Class'], card='M:1', optional=True),
            dict(child='Performance Measurement Profile', parent='Account', fk=['Profiled Account'], card='M:1', optional=True),
            dict(child='Performance Measurement Profile', parent='Model Portfolio', fk=['Profiled Model Portfolio'], card='M:1', optional=True),
            dict(child='Performance Measurement Profile', parent='Performance Calculation Policy', fk=['Applied Calculation Policy'], card='M:1', note="The policy key is code x version; the version effective on the profile's dates completes it."),
            dict(child='Performance Measurement Profile', parent='Performance Period Close', fk=['Performance Close Group'], card='M:N', note='A profile is closed in every period of its close group, and a close group closes many profiles; Performance Close Group matches Close Group (Periods Closed On Time %).'),
            dict(child='Benchmark Return', parent='Benchmark', fk=['Return Benchmark'], card='M:1'),
            dict(child='Benchmark Return', parent='Benchmark Return', fk=['Supersedes Benchmark Return'], card='1:1', optional=True),
            dict(child='Benchmark Return', parent='Index Level Observation', fk=['Start Index Level'], card='M:1', optional=True, note='Blank for blended benchmarks, which are built from their components.'),
            dict(child='Benchmark Return', parent='Index Level Observation', fk=['End Index Level'], card='M:1', optional=True),
            dict(child='Share Class NAV', parent='Fund NAV Calculation', fk=['Parent NAV Calculation'], card='M:1'),
            dict(child='Share Class NAV', parent='Share Class', fk=['NAV Share Class'], card='M:1'),
            dict(child='Index Level Observation', parent='Benchmark', fk=['Index Benchmark'], card='M:1'),
            dict(child='Benchmark', parent='Benchmark', fk=['Blend Components'], card='M:N', optional=True),
            dict(child='Product Benchmark Assignment', parent='Share Class', fk=['Assigned Product / Share Class'], card='M:1'),
            dict(child='Product Benchmark Assignment', parent='Benchmark', fk=['Assigned Benchmark'], card='M:1'),
            dict(child='Performance Return', parent='Managed Account Composite', fk=['Return Managed Account Composite'], card='M:1', optional=True),
            dict(child='Performance Measurement Profile', parent='Managed Account Composite', fk=['Profiled Managed Account Composite'], card='M:1', optional=True),
            dict(child='Client Performance Profile', parent='Account', fk=['Client Profile Account'], card='M:1'),
            dict(child='Client Performance Profile', parent='Household Performance Group', fk=['Client Profile Group'], card='M:1'),
            dict(child='Client Performance Profile', parent='Benchmark', fk=['Client Comparison Benchmark'], card='M:1', optional=True),
            dict(child='Client Performance Profile', parent='Performance Calculation Policy', fk=['Client Applied Calculation Policy'], card='M:1', optional=True),
            dict(child='Household Performance Group', parent='Party', fk=['Group Household'], card='M:1', optional=True),
            dict(child='Household Performance Group Member', parent='Household Performance Group', fk=['Member Performance Group'], card='M:1'),
            dict(child='Household Performance Group Member', parent='Account', fk=['Member Account'], card='M:1'),
            dict(child='Personal Rate of Return', parent='Account', fk=['Personal Return Account'], card='M:1', optional=True),
            dict(child='Personal Rate of Return', parent='Household Performance Group', fk=['Personal Return Group'], card='M:1', optional=True),
            dict(child='Personal Rate of Return', parent='Personal Rate of Return', fk=['Supersedes Personal Return'], card='M:1', optional=True),
            dict(child='Client Return Exception', parent='Account', fk=['Exception Account'], card='M:1'),
            dict(child='Managed Account Composite', parent='Service Offering', fk=['Composite Program'], card='M:1', optional=True),
            dict(child='Managed Account Composite', parent='Model Portfolio', fk=['Composite Model Portfolio'], card='M:1', optional=True),
            dict(child='Managed Account Composite Membership', parent='Managed Account Composite', fk=['Membership Composite'], card='M:1'),
            dict(child='Managed Account Composite Membership', parent='Account', fk=['Member Account'], card='M:1'),
            dict(child='Client Holding', parent='Account', fk=['Holding Account'], card='M:1', optional=True),
            dict(child='Account Cash Balance', parent='Account', fk=['Cash Balance Account'], card='M:1', optional=True),
            dict(child='Margin Balance Snapshot', parent='Account', fk=['Margin Snapshot Account'], card='M:1'),
            dict(child='Client Account Activity', parent='Account', fk=['Activity Account'], card='M:1', optional=True),
            dict(child='Share Register Balance', parent='Account', fk=['Register Account'], card='M:1'),
            dict(child='Share Register Balance', parent='Share Class', fk=['Register Share Class'], card='M:1'),
            dict(child='Register Transaction', parent='Account', fk=['Posting Account'], card='M:1', optional=True),
            dict(child='Register Transaction', parent='Account', fk=['Transfer Counter Account'], card='M:1', optional=True),
            dict(child='Participant Balance', parent='Participant Plan Membership', fk=['Balance Membership'], card='M:1', optional=True),
            dict(child='Participant Plan Membership', parent='Account', fk=['Participant Account'], card='M:1', optional=True),
            dict(child='Participant Ledger Posting', parent='Participant Plan Membership', fk=['Posting Membership'], card='M:1', optional=True),
            dict(child='Fee Debit', parent='Account', fk=['Debited Account'], card='M:1', optional=True),
            dict(child='Household Membership', parent='Party', fk=['Household'], card='M:1'),
            dict(child='Household Membership', parent='Party', fk=['Household Member'], card='M:1'),
            dict(child='Account Party Role', parent='Party', fk=['Role Party'], card='M:1', optional=True),
            dict(child='Account Party Role', parent='Account', fk=['Role Account'], card='M:1', optional=True),
            dict(child='Fee Invoice', parent='Personal Rate of Return', fk=['Personal Rate of Return Key'], card='M:1', optional=True, note='Model gap: no input attribute of Fee Invoice carries its link to Personal Rate of Return; the placeholder key stands for the lineage join.'),
        ],
        notes="W4 re-point (CW-930): the Private Markets Performance Measure entity and the conformed Capital Call and Distribution (DP-117), Fair Value Determination and Investment Product (read only by it) are removed with their relationships; the 32 object and the 30 inputs left the spec. Personal Rate of Return (PRROR-, CW-129) is added to this model at WP1 with the spec. Foundational ER for the 32 certified returns (CD-217, CD-320): Performance Return and Benchmark Return, with the policy, measurement profile, period close and restatement entities, and the masters each certified number is tied out against conformed from DP-165 (NAV), DP-144 (index levels, benchmarks), DP-143 (ETF statistics, fair value). Entity names other products conform: Performance Return, Benchmark Return, Performance Measurement Profile, Performance Period Close, Performance Restatement. Model gap: Return Composite and Profiled Composite point to 01 GIPS Composite, which no foundational model publishes yet (CD-322 adds it to DP-004); the keys are carried, not linked. External references (keys carried, not linked): Applied FX Rate Type to DP-013 FX Rate Type (Model gap: DP-013 is not in this product's upstream); Hypothetical Compliance Review to 08 Compliance Review; Track Record Continuity Change to 36 Product Change Initiative; Related NAV Error Case to 27 NAV Error Case.  WP1 re-point (CW-129, CW-011): re-cut for the Personal Rate of Return extension. Performance Return, Benchmark Return, Performance Measurement Profile, Performance Restatement and the conformed benchmark and NAV entities keep their objects and keys (7 to 10 live conformers each). The 32 Client Account Performance objects (Client Performance Profile, Household Performance Group and Member, Personal Rate of Return, Client Return Exception), the 46 Managed Account Composite and Membership and the 49, 29, 16, 47, 02 and 15 tie-out inputs are entities keyed by the registry, joined to the conformed DP-093 Account, DP-240 Party and DP-004 Share Class by their references. Model gap: no input attribute links a 47 Fee Invoice to the personal return whose fee tie-out reads it; a placeholder key stands for that join.",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-146": dict(
        style="ER",
        entities=[
            ent("Portfolio Risk Measure", [("31", "Portfolio Risk Measure")],
                ["Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Horizon Days",
                 "Confidence Level", "Measure Benchmark"], measures=True,
                grain="one row = risk calculation run x portfolio x risk measure x horizon days x confidence level x "
                      "benchmark (blank for absolute measures)",
                note="Ex-ante VaR and tracking error are certified from approved runs only (CD-293, CD-320). Holds the "
                     "measures."),
            ent("Risk Model", [("31", "Risk Model")], ["Risk Model Code", "Risk Model Version"],
                grain="one row = risk model x version",
                note="The conformed Risk Model; Model Inventory Reference ties it to the 37 model inventory (CD-294)."),
            ent("Risk Factor", [("31", "Risk Factor")], ["Factor Risk Model", "Risk Factor Code"],
                grain="one row = risk model x risk factor"),
            ent("Risk Factor Return", [("31", "Risk Factor Return")], ["Return Risk Factor", "Factor Return Date"],
                grain="one row = risk factor x factor return date"),
            ent("Instrument Factor Loading", [("31", "Instrument Factor Loading")],
                ["Loading Risk Model", "Loaded Instrument", "Loading Risk Factor", "Factor Loading Date"],
                grain="one row = risk model x instrument x risk factor x loading date",
                note="Proxy Instrument is set when the loading is borrowed from a proxy (Proxied Loading Share)."),
            ent("Risk Calculation Run", [("31", "Risk Calculation Run")],
                ["Run Risk Model", "Run As-Of Date", "Run Scope"],
                grain="one row = risk model x run as-of date x run scope",
                note="Model gap (spec taxonomy gap): no run identifier attribute, so the run is keyed by model, as-of "
                     "date and scope."),
            ent("Risk Decomposition", [("31", "Risk Decomposition")],
                ["Decomposed Measure", "Risk Dimension", "Risk Bucket"],
                grain="one row = portfolio risk measure x risk dimension x bucket"),
            ent("Portfolio Exposure", [("31", "Portfolio Exposure")],
                ["Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run", "Exposure Dimension",
                 "Exposure Bucket", "Exposure Measure", "Exposure Benchmark"],
                grain="one row = portfolio x as-of date x run x dimension x bucket x exposure measure x benchmark"),
            ent("VaR Back-Test", [("31", "VaR Back-Test")],
                ["Back-Tested Portfolio", "Back-Test Risk Model", "Back-Test Date", "Back-Test P&L Basis"],
                grain="one row = portfolio x risk model x back-test date x P&L basis",
                note="Realized Daily P&L is the 27 P&L the back-test used, read as held."),
            conf("Portfolio", PORT, [("18", "Portfolio")], note="Conformed from DP-140."),
            conf("Instrument", INSTR, note="Conformed from DP-097; loaded and proxy instruments."),
            conf("Benchmark", BMK, note="Conformed from DP-144; the benchmark of relative measures and exposures."),
            conf("Curve Definition", CURVE, note="Conformed from DP-143; the curve a rates factor is mapped to."),
            conf("Classification Scheme", CLSCHEME,
                 note="Conformed from DP-013; the scheme a factor's classification code belongs to."),
            conf("Party", PARTY, note="Conformed from DP-240; the risk model vendor."),
            conf("Model", MODEL,
                 note="Conformed from DP-212 (upstream since the E1 merge, CD-294); the model inventory entry of the "
                      "risk model. Entity name Model assumed for DP-212."),
        ],
        relationships=[
            rel("Risk Model", "Party", ["Model Vendor"], optional=True),
            rel("Risk Model", "Model", ["Model Inventory Reference"], optional=True),
            rel("Risk Factor", "Risk Model", ["Factor Risk Model"],
                note="The model key is code x version; the version effective on the factor's dates completes it."),
            rel("Risk Factor", "Curve Definition", ["Mapped Curve"], optional=True),
            rel("Risk Factor", "Classification Scheme", ["Factor Classification Scheme"], optional=True),
            rel("Risk Factor Return", "Risk Factor", ["Return Risk Factor"],
                note="The factor key is model x factor code; the factor reference carries both."),
            rel("Instrument Factor Loading", "Risk Model", ["Loading Risk Model"]),
            rel("Instrument Factor Loading", "Instrument", ["Loaded Instrument"]),
            rel("Instrument Factor Loading", "Instrument", ["Proxy Instrument"], optional=True),
            rel("Instrument Factor Loading", "Risk Factor", ["Loading Risk Factor"]),
            rel("Risk Calculation Run", "Risk Model", ["Run Risk Model"]),
            rel("Portfolio Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            rel("Portfolio Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Portfolio Risk Measure", "Benchmark", ["Measure Benchmark"], optional=True,
                note="Relative measures (tracking error, active risk) only."),
            rel("Risk Decomposition", "Portfolio Risk Measure", ["Decomposed Measure"]),
            rel("Portfolio Exposure", "Portfolio", ["Exposure Portfolio"]),
            rel("Portfolio Exposure", "Risk Calculation Run", ["Exposure Calculation Run"]),
            rel("Portfolio Exposure", "Benchmark", ["Exposure Benchmark"], optional=True),
            rel("VaR Back-Test", "Portfolio", ["Back-Tested Portfolio"]),
            rel("VaR Back-Test", "Risk Model", ["Back-Test Risk Model"]),
            rel("VaR Back-Test", "Portfolio Risk Measure", ["Back-Tested VaR Measure"]),
        ],
        notes=("Foundational ER for the 31 risk masters (CD-211): Risk Model with its factors, factor returns and "
               "instrument loadings, and the run-based results (Portfolio Risk Measure with its decomposition, Portfolio "
               "Exposure, VaR Back-Test) on the conformed Portfolio. Entity names other products conform: Risk Model, Risk "
               "Factor, Risk Calculation Run, Portfolio Risk Measure, Portfolio Exposure, VaR Back-Test. "
               "External references (keys carried, not linked): Vendor Model Dataset and Covariance Matrix Dataset to "
               "DP-014 Dataset (not upstream; a vendor engine changes the dataset, not the grain). Factor Classification "
               "Code is read with its scheme; the DP-013 Classification Code entity is not drawn because the scheme link "
               "already places it. "
               "Warnings in the per-module check: conformed sources DP-097, DP-212 and DP-240 are other E8 groups' models "
               "and are not loaded, so their fks warn that the parent does not hold Instrument, Model Inventory Entry or "
               "Party."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-147": dict(
        style="ER",
        entities=[
            ent("Trading Agreement", [("26", "Trading Agreement")], ["Trading Agreement ID"], measures=True,
                grain="one row = trading agreement (TAGR-)",
                note="The conformed Trading Agreement (CD-182): ISDA, CSA, GMRA, MSFTA, give-up and prime brokerage "
                     "agreements with a fund or account as principal. Holds the measures; the SSI and settlement cycle "
                     "measures are read through the relationships."),
            ent("Credit Support Terms", [("26", "Credit Support Terms")],
                ["Terms Agreement", "Terms Margin Type", "Terms Direction", "Terms Effective From"],
                grain="one row = trading agreement x margin type x direction x effective period",
                note="Amendments appear as new effective-dated rows (26 has no amendment object)."),
            ent("Eligible Collateral Schedule", [("26", "Eligible Collateral Schedule")],
                ["Schedule Agreement", "Schedule Margin Type", "Schedule Direction", "Eligible Collateral Type",
                 "Eligibility Effective From"],
                grain="one row = trading agreement x margin type x direction x collateral type x effective period"),
            ent("Termination Event Trigger", [("26", "Termination Event Trigger")],
                ["Trigger Agreement", "Termination Trigger Type", "Trigger Applies To", "Measurement Period Months",
                 "Trigger Effective From"],
                grain="one row = trading agreement x trigger type x party the trigger applies to x measurement period x "
                      "effective period"),
            ent("Standing Settlement Instruction",
                [("26", "Standing Settlement Instruction"), ("26", "SSI Verification")],
                ["SSI ID"],
                grain="one row = standing settlement instruction (owner x market or settlement currency x asset class x "
                      "effective period, SSI-)",
                note="The conformed Standing Settlement Instruction (CD-155 option A). Polymorphic owner: SSI Portfolio, "
                     "SSI Fund, SSI Mandate or SSI Counterparty by SSI Owner Type. The verification group (source, "
                     "call-back, four-eyes approval) has one row per SSI and folds here."),
            ent("Settlement Cycle Rule", [("26", "Settlement Cycle Rule")],
                ["Cycle Market", "Cycle Instrument Type", "Cycle Settlement Type", "Cycle Effective From"],
                grain="one row = market x instrument type x settlement type x effective period"),
            conf("Portfolio", PORT, [("18", "Portfolio")], note="Conformed from DP-140; SSI owner portfolios."),
            conf("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")],
                 note="Conformed from DP-140; finds the fund or mandate of an active portfolio without its own SSI "
                      "(Active Portfolios Without Own SSI)."),
            conf("Investment Mandate", MANDATE,
                 note="Conformed from DP-140, which publishes 01 Investment Mandate until CD-322 extends DP-004."),
            conf("Investment Product", PROD, note="Conformed from DP-004; the fund principal and SSI owner fund."),
            conf("Account", ACCT, note="Conformed from DP-093; the principal account of a mandate agreement."),
            conf("Internal Legal Entity", LE, note="Conformed from DP-013; the firm contracting entity."),
            conf("Party", PARTY,
                 note="Conformed from DP-240; counterparties, give-up brokers, operations providers and segregation "
                      "custodians. Counterparty identity is the 02 party key, never DP-115 (CD-321: DP-115 reads this "
                      "product)."),
            conf("Safekeeping Account", SKA, note="Conformed from DP-167; the firm's own safekeeping account on an SSI."),
            conf("Employee", EMP, note="Conformed from DP-192; SSI verifiers and approvers (four-eyes)."),
            conf("Calendar", CAL, note="Conformed from DP-013; the settlement calendar of a cycle rule."),
        ],
        relationships=[
            rel("Trading Agreement", "Trading Agreement", ["Parent Agreement"], optional=True,
                note="A CSA or annex under its master agreement."),
            rel("Trading Agreement", "Investment Product", ["Fund Party"], optional=True),
            rel("Trading Agreement", "Account", ["Principal Account"], optional=True),
            rel("Trading Agreement", "Internal Legal Entity", ["Firm Contracting Entity"]),
            rel("Trading Agreement", "Party", ["Agreement Counterparty"]),
            rel("Trading Agreement", "Party", ["Give-Up Executing Broker"], optional=True),
            rel("Trading Agreement", "Party", ["Agreement Operations Provider"], optional=True),
            rel("Credit Support Terms", "Trading Agreement", ["Terms Agreement"]),
            rel("Credit Support Terms", "Party", ["Segregation Custodian"], optional=True),
            rel("Eligible Collateral Schedule", "Trading Agreement", ["Schedule Agreement"]),
            rel("Termination Event Trigger", "Trading Agreement", ["Trigger Agreement"]),
            rel("Standing Settlement Instruction", "Portfolio", ["SSI Portfolio"], optional=True),
            rel("Standing Settlement Instruction", "Investment Product", ["SSI Fund"], optional=True),
            rel("Standing Settlement Instruction", "Investment Mandate", ["SSI Mandate"], optional=True),
            rel("Standing Settlement Instruction", "Party", ["SSI Counterparty"], optional=True),
            rel("Standing Settlement Instruction", "Safekeeping Account", ["Own Safekeeping Account"], optional=True),
            rel("Standing Settlement Instruction", "Employee", ["Verified By"], optional=True),
            rel("Standing Settlement Instruction", "Employee", ["SSI Approved By"], optional=True),
            rel("Settlement Cycle Rule", "Calendar", ["Settlement Calendar"]),
            rel("Standing Settlement Instruction", "Settlement Cycle Rule", ["SSI Market"], card="M:N", optional=True,
                note="SSI Market matches Cycle Market, a partial key of the rule: an SSI settles under every rule of its "
                     "market (by instrument type and settlement type), and a rule covers many SSIs."),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Portfolio Implementation Link", "Investment Mandate", ["Implemented Mandate"], optional=True),
        ],
        notes=("Foundational ER for the 26 masters: Trading Agreement (TAGR-, CD-182) with credit support terms, eligible "
               "collateral and termination triggers as effective-dated child entities, Standing Settlement Instruction "
               "(SSI-, CD-155), and Settlement Cycle Rule, which joins the SSIs on market only (a partial key), because "
               "no attribute ties a market rule to an agreement or SSI. Entity names other products conform: "
               "Trading Agreement, Standing Settlement Instruction, Settlement Cycle Rule, Credit Support Terms. "
               "The SSI attribute Safekeeping Account (a 12 Custody Account copy) is not read (CD-194). "
               "Warnings in the per-module check: conformed sources DP-192 and DP-240 are other E8 groups' models and are not "
               "loaded, so their fks warn that the parent does not hold Employee or Party."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-165": dict(
        # WP1 re-point (CW-206, CW-011): re-cut to the specs_w1f_certified.py DP-165 inputs; see notes.
        style='ER',
        entities=[
            dict(name='Share Class NAV',
                 role='Entity',
                 objects=[('27', 'Share Class NAV'), ('27', 'CIT Unit Value Detail')],
                 pk=['Share Class NAV ID'],
                 measures=True,
                 grain='one row = share class x fund NAV calculation (NAV-)',
                 note='The conformed Share Class NAV (CD-187): NAV per share, class net assets and shares outstanding of every calculation version; the NAV of Record Flag is derived from the parent calculation. CIT unit value detail has one row per class NAV and folds here. Holds the measures, including the certified Firm AUM and expense ratios, which read the companion entities.'),
            dict(name='Fund NAV Calculation',
                 role='Entity',
                 objects=[('27', 'Fund NAV Calculation')],
                 pk=['NAV Book', 'Valuation Date', 'NAV Calculation Source', 'NAV Version Number'],
                 grain='one row = fund accounting book x valuation date x NAV calculation source x NAV version',
                 note='The conformed Fund NAV Calculation; administrator, in-house and firm shadow sources are rows, never separate products (CD-331).'),
            dict(name='Class Allocation',
                 role='Entity',
                 objects=[('27', 'Class Allocation')],
                 pk=['Allocation NAV Calculation', 'Allocation Share Class', 'Class Allocation Item'],
                 grain='one row = fund NAV calculation x share class x allocation item',
                 note='Associative entity between a NAV calculation and its share classes.'),
            dict(name='NAV Dissemination',
                 role='Entity',
                 objects=[('27', 'NAV Dissemination')],
                 pk=['Released NAV', 'Release Sequence'],
                 grain='one row = share class NAV x release sequence'),
            dict(name='Fund Financial Statement',
                 role='Entity',
                 objects=[('27', 'Fund Financial Statement')],
                 pk=['Statement Book', 'Statement Period End Date'],
                 grain='one row = fund accounting book x statement period end date'),
            dict(name='Financial Highlights',
                 role='Entity',
                 objects=[('27', 'Financial Highlights')],
                 pk=['Fund Financial Statement Key', 'Highlights Share Class'],
                 grain='one row = fund financial statement x share class',
                 note='Child group (fold=False): one row per share class of the statement set. The group has no attribute for its statement, so the key is completed by the borrowed Fund Financial Statement Key (Statement Book + Statement Period End Date).'),
            dict(name='Fund Expense Accrual',
                 role='Entity',
                 objects=[('27', 'Fund Expense Accrual')],
                 pk=['Accrual Fund', 'Accrual Share Class', 'Accrual Expense Type', 'Expense Accrual Date'],
                 grain='one row = fund x share class x expense type x accrual date'),
            dict(name='Expense Cap & Waiver Accrual',
                 role='Entity',
                 objects=[('27', 'Expense Cap & Waiver Accrual')],
                 pk=['Waiver Share Class', 'Waiver Type', 'Waiver Accrual Date'],
                 grain='one row = share class x waiver type x accrual date'),
            dict(name='Fund Accounting Book',
                 role='Entity',
                 conformed=('DP-166', 'Fund Accounting Book'),
                 objects=[('27', 'Fund Accounting Book')],
                 note='Conformed from DP-166, which masters the book (CD-186) and is upstream here; republished under the same name so NAV consumers can conform it from DP-165.'),
            dict(name='Fund Book Operating Period',
                 role='Entity',
                 conformed=('DP-166', 'Fund Book Operating Period'),
                 objects=[('27', 'Fund Book Operating Period')],
                 note='Conformed from DP-166; the operating model and administrator of record that set the official NAV Calculation Source.'),
            dict(name='Investment Product',
                 role='Entity',
                 conformed=('DP-004', 'Investment Product'),
                 objects=[('01', 'Investment Product'), ('01', 'Fund Legal Structure')],
                 note='Conformed from DP-004; Fund Legal Structure folds here (Master-Feeder Role and Fund of Funds Indicator decide the Firm AUM double-counting rules).'),
            dict(name='Share Class',
                 role='Entity',
                 conformed=('DP-004', 'Share Class'),
                 objects=[('01', 'Share Class')],
                 note='Conformed from DP-004.'),
            dict(name='Currency',
                 role='Entity',
                 conformed=('DP-013', 'Currency'),
                 objects=[],
                 note='Conformed from DP-013; joins FX rate observations to fund and class currencies for Firm AUM translation.'),
        ],
        relationships=[
            dict(child='Share Class NAV', parent='Fund NAV Calculation', fk=['Parent NAV Calculation'], card='M:1', note='The calculation key is book x date x source x version; the class NAV reference carries it.'),
            dict(child='Share Class NAV', parent='Share Class', fk=['NAV Share Class'], card='M:1'),
            dict(child='Fund NAV Calculation', parent='Fund Accounting Book', fk=['NAV Book'], card='M:1'),
            dict(child='Class Allocation', parent='Fund NAV Calculation', fk=['Allocation NAV Calculation'], card='M:1'),
            dict(child='Class Allocation', parent='Share Class', fk=['Allocation Share Class'], card='M:1'),
            dict(child='NAV Dissemination', parent='Share Class NAV', fk=['Released NAV'], card='M:1'),
            dict(child='NAV Dissemination', parent='NAV Dissemination', fk=['Corrected Release'], card='1:1', optional=True, note='The earlier release a corrected release replaces.'),
            dict(child='Fund Financial Statement', parent='Fund Accounting Book', fk=['Statement Book'], card='M:1'),
            dict(child='Financial Highlights', parent='Fund Financial Statement', fk=['Fund Financial Statement Key'], card='M:1', note='Borrowed key: Statement Book + Statement Period End Date.'),
            dict(child='Financial Highlights', parent='Share Class', fk=['Highlights Share Class'], card='M:1'),
            dict(child='Fund Expense Accrual', parent='Investment Product', fk=['Accrual Fund'], card='M:1'),
            dict(child='Fund Expense Accrual', parent='Share Class', fk=['Accrual Share Class'], card='M:1', optional=True, note='Blank for fund-level expenses.'),
            dict(child='Expense Cap & Waiver Accrual', parent='Share Class', fk=['Waiver Share Class'], card='M:1'),
            dict(child='Fund Accounting Book', parent='Investment Product', fk=['Book Fund'], card='M:1'),
            dict(child='Fund Book Operating Period', parent='Fund Accounting Book', fk=['Operated Book'], card='M:1'),
            dict(child='Share Class', parent='Investment Product', fk=['Parent Product'], card='M:1'),
            dict(child='Investment Product', parent='Investment Product', fk=['Master Fund'], card='M:1', optional=True, note='Feeder funds name their master; feeders are excluded from Firm AUM.'),
            dict(child='Investment Product', parent='Currency', fk=['Base Currency'], card='M:1'),
            dict(child='Share Class', parent='Currency', fk=['Share Class Currency'], card='M:1'),
        ],
        notes="Foundational ER for the 27 NAV masters (CD-187, CD-207): Fund NAV Calculation and Share Class NAV with class allocations, releases, the financial statement set with its per-class highlights, and the expense and waiver accruals, on the Fund Accounting Book conformed from DP-166. Firm AUM (CD-292) reads two slices through conformed entities: fund net assets here and mandate and SMA market value from DP-142 through DP-140's primary implementation link. Entity names other products conform: Share Class NAV, Fund NAV Calculation, Fund Accounting Book (republished from DP-166), Class Allocation, NAV Dissemination, Fund Financial Statement, Fund Expense Accrual, Expense Cap & Waiver Accrual. Fund Accounting Book is mastered by DP-166 (CD-186), and this product lists DP-166 upstream, so it is conformed here rather than modeled twice; the reverse would make a conformed-dimension cycle. External references (keys carried, not linked): Share Class NAV.Applied Swing Decision to 27 Swing Pricing Decision (not an input); Fund Expense Accrual.Applied Fee Schedule to 01 Management Fee (the fund fee terms, FSCH-, CW-051; not an input); Fund Book Operating Period.Fund Administrator of Record and Fund Financial Statement.Statement Auditor to 02 Party (Model gap: DP-240 is not in this product's upstream); Portfolio Implementation Link.Implemented Mandate and Managed Account (the mandate and account are reached through DP-140, Model gap: DP-093 is not upstream); Portfolio Valuation Summary.Summary Snapshot to DP-142's snapshot (not needed for AUM). W4 re-point (CW-930, CW-011): the six conformed 30 entities of the private fund slice (Investor Commitment, Investor Capital Account, Capital Call, Capital Call Allocation, Distribution, Distribution Allocation) are removed with their relationships. WP1 re-point (CW-206, CW-011): Firm AUM and the mandate and SMA slice move to DP-241, so the entities that served only the slices and their translation (Portfolio, Portfolio Implementation Link, Portfolio Valuation Summary, Portfolio Holding and Instrument conformed from DP-140 and DP-142, FX Rate Observation and FX Rate Type) are dropped with their inputs and the upstream DP-140 and DP-142 (which also clears the five 'not in the product's upstream' warnings). Fund NAV Calculation (21 conformers), Share Class NAV (17), Fund Accounting Book (15) and the expense, highlights and statement entities keep their objects and keys.",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-166": dict(
        style="ER",
        entities=[
            ent("Fund Journal Line", [("27", "Fund Journal Line")], ["Line Journal", "Journal Line Number"],
                measures=True,
                grain="one row = fund journal entry x line number",
                note="Optional for administrator-kept books, which are certified at trial balance and ABOR valuation "
                     "grain (CD-331). Source keys (18, 26, 29, 27, 30) are published as keys only. Holds the measures; the "
                     "trial balance, ABOR and accrual measures read the companion entities."),
            ent("Fund Journal Entry", [("27", "Fund Journal Entry")], ["Fund Journal Entry ID"],
                grain="one row = fund journal entry (FJNL-)"),
            ent("Fund Accounting Book", [("27", "Fund Accounting Book")], ["Book Fund", "Accounting Basis"],
                grain="one row = fund x accounting basis",
                note="The conformed Fund Accounting Book (CD-186), mastered here; DP-165 republishes it. Business Line "
                     "and Book Reporting Currency are the book's own slicing attributes, read as held."),
            ent("Fund Book Operating Period", [("27", "Fund Book Operating Period")],
                ["Operated Book", "Operating Period Effective From"],
                grain="one row = fund accounting book x operating period",
                note="In house or administrator, and the administrator of record, per book and period."),
            ent("Fund Book Portfolio Link", [("27", "Fund Book Portfolio Link")],
                ["Linked Book", "Accounted Portfolio", "Portfolio Link Effective From"],
                grain="one row = fund accounting book x portfolio x effective period",
                note="Associative entity between the ABOR book and the IBOR portfolios it accounts for."),
            ent("Fund Ledger Account", [("27", "Fund Ledger Account")],
                ["Fund Chart of Accounts", "Fund Ledger Account Number"],
                grain="one row = fund chart of accounts x ledger account number"),
            ent("Fund Trial Balance", [("27", "Fund Trial Balance")],
                ["Balance Book", "Balance Fund Ledger Account", "Balance Share Class", "Balance Date"],
                grain="one row = book x fund ledger account x share class (blank at fund level) x balance date"),
            ent("ABOR Valuation Record", [("27", "ABOR Valuation Record")],
                ["Valuation Book", "Valued Instrument", "ABOR Valuation Date"],
                grain="one row = book x instrument x valuation date",
                note="ABOR quantity and value; compared with the IBOR in DP-172, not here (CD-335)."),
            ent("Income Accrual", [("27", "Income Accrual")],
                ["Accrual Book", "Accrual Instrument", "Income Type", "Income Accrual Date"],
                grain="one row = book x instrument x income type x accrual date"),
            conf("Approved Price", PRICE, [("22", "Approved Price")],
                 note="Conformed from DP-143; the price applied in an ABOR valuation (ABOR at Approved Price %)."),
            conf("Fair Value Determination", FVD, note="Conformed from DP-143."),
            conf("FX Rate Observation", FXR, note="Conformed from DP-143; the rate applied to a valuation or line."),
            conf("Reference Rate Fixing", FIXING, note="Conformed from DP-143; the fixing applied to a floating accrual."),
            conf("Instrument", INSTR, note="Conformed from DP-097."),
            conf("Corporate Action Event", CAE, note="Conformed from DP-099; the dividend or income event of an accrual."),
            conf("Portfolio", PORT, note="Conformed from DP-140; the IBOR portfolio a book accounts for."),
            conf("Portfolio Transaction", PTXN, note="Conformed from DP-141; the booking a journal line is traced to."),
            conf("Investment Product", PROD, note="Conformed from DP-004; the fund of the book."),
            conf("Share Class", SHARE, note="Conformed from DP-004; class-specific lines and balances."),
            conf("Internal Legal Entity", LE, note="Conformed from DP-013; the book owner entity."),
        ],
        relationships=[
            rel("Fund Journal Line", "Fund Journal Entry", ["Line Journal"]),
            rel("Fund Journal Line", "Fund Ledger Account", ["Line Fund Ledger Account"],
                note="The account key is chart x number; the chart is the journal book's Book Fund Chart of Accounts."),
            rel("Fund Journal Line", "FX Rate Observation", ["Line FX Rate"], optional=True),
            rel("Fund Journal Line", "Share Class", ["Line Share Class"], optional=True,
                note="Required when the account is class-specific."),
            rel("Fund Journal Line", "Instrument", ["Line Instrument"], optional=True),
            rel("Fund Journal Line", "Portfolio Transaction", ["Source Portfolio Transaction"], optional=True),
            rel("Fund Journal Entry", "Fund Accounting Book", ["Journal Book"]),
            rel("Fund Journal Entry", "Fund Journal Entry", ["Reversed Journal"], optional=True),
            rel("Fund Accounting Book", "Investment Product", ["Book Fund"]),
            rel("Fund Accounting Book", "Internal Legal Entity", ["Book Owner Entity"], optional=True),
            rel("Fund Accounting Book", "Fund Ledger Account", ["Book Fund Chart of Accounts"], card="M:N",
                note="A book uses one chart of accounts, which holds many ledger accounts; the chart is a partial key "
                     "of Fund Ledger Account."),
            rel("Fund Book Operating Period", "Fund Accounting Book", ["Operated Book"]),
            rel("Fund Book Portfolio Link", "Fund Accounting Book", ["Linked Book"]),
            rel("Fund Book Portfolio Link", "Portfolio", ["Accounted Portfolio"]),
            rel("Fund Trial Balance", "Fund Accounting Book", ["Balance Book"]),
            rel("Fund Trial Balance", "Fund Ledger Account", ["Balance Fund Ledger Account"]),
            rel("Fund Trial Balance", "Share Class", ["Balance Share Class"], optional=True),
            rel("ABOR Valuation Record", "Fund Accounting Book", ["Valuation Book"]),
            rel("ABOR Valuation Record", "Instrument", ["Valued Instrument"]),
            rel("ABOR Valuation Record", "Approved Price", ["Applied Price"], optional=True),
            rel("ABOR Valuation Record", "Fair Value Determination", ["Applied Fair Value Determination"],
                optional=True),
            rel("ABOR Valuation Record", "FX Rate Observation", ["Applied FX Rate"], optional=True),
            rel("Income Accrual", "Fund Accounting Book", ["Accrual Book"]),
            rel("Income Accrual", "Instrument", ["Accrual Instrument"]),
            rel("Income Accrual", "Reference Rate Fixing", ["Applied Rate Fixing"], optional=True),
            rel("Income Accrual", "Corporate Action Event", ["Related Corporate Action Event"], optional=True),
        ],
        notes=("W4 re-point (CW-930): the four 30 journal line source references are gone from the spec and from the external "
               "references below. Fee accruals reference the 01 fund fee terms (Reference (Management Fee, 01), CW-051). "
               "Foundational ER for the 27 fund ledger masters (CD-186): Fund Accounting Book with its operating periods, "
               "portfolio links, chart of accounts, journals, trial balance, ABOR valuations and income accruals. Entity "
               "names other products conform: Fund Accounting Book, Fund Book Operating Period, Fund Book Portfolio Link, "
               "Fund Ledger Account, Fund Journal Entry, Fund Journal Line, Fund Trial Balance, ABOR Valuation Record, "
               "Income Accrual. "
               "External references (keys carried, not linked; the spec reads none of their values): Fund Journal "
               "Line.Source Settlement Instruction (26), Source Fund Order and Source AP Order (29), Source Distribution "
               "Declaration (27); Fund Journal Entry.Related NAV Error Case (27); Income Accrual.Accrual Coupon "
               "Period (17 Coupon Schedule, through DP-097) and Related Income Collection (28); Fund Book Operating "
               "Period.Fund Administrator of Record to 02 Party (Model gap: DP-240 is not in this product's upstream). "
               "Warnings in the per-module check: conformed sources DP-097 and DP-099 are other E8 groups' models and are "
               "not loaded, so their fks warn that the parent does not hold Instrument or Corporate Action Event."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-167": dict(
        style="ER",
        entities=[
            ent("Safekeeping Account", [("28", "Safekeeping Account")], ["Safekeeping Account ID"], measures=True,
                grain="one row = safekeeping account (SKA-) x effective period",
                note="The conformed Safekeeping Account (CD-194 option A): the account as opened at a custodian, "
                     "sub-custodian, bank or depositary; Internal Account Provider is set instead of Account Provider "
                     "when a CIT trustee self-custodies. Holds the measures."),
            ent("Safekeeping Account Assignment", [("28", "Safekeeping Account Assignment")],
                ["Assigned Safekeeping Account", "Owning Fund", "Owning Portfolio", "Owning Client Account",
                 "Account Assignment Purpose", "Assignment Effective From"],
                grain="one row = safekeeping account x owner (fund, portfolio or client account) x purpose x effective "
                      "period",
                note="Associative entity; polymorphic owner, one of the three owner key parts is set."),
            ent("Custodian", [("28", "Custody Provider Profile")],
                ["Provider Party", "Provider Legal Entity", "Custody Provider Role", "Profile Effective From"],
                grain="one row = provider (party, or internal legal entity for a self-custodying CIT trustee) x custody "
                      "provider role x effective period",
                note="The Custodian dimension CD-296 names for SM-00, built on 28 Custody Provider Profile. Consumers "
                     "that hold only a custodian party key join on Provider Party."),
            ent("Sub-Custodian Network Arrangement", [("28", "Sub-Custodian Network Arrangement")],
                ["Arrangement Global Custodian", "Arrangement Market", "Sub-Custodian", "Arrangement Effective From"],
                grain="one row = global custodian x market x sub-custodian x effective period"),
            ent("Product Party Role", [("01", "Product Party Role")],
                ["Investment Product Key", "Party", "Party Role Type", "Role Effective From"],
                grain="one row = investment product x party x party role type x effective period",
                note="The 01 custodian and depositary appointments of a fund, read directly because DP-004 does not "
                     "publish Product Party Role (Custodian Appointment Mismatch). Scoped within Investment Product: no "
                     "input attribute carries the product, so the key is completed by the borrowed Investment Product "
                     "Key (Product ID)."),
            conf("Portfolio", PORT, [("18", "Portfolio")],
                 note="Conformed from DP-140; Safekeeping Custody Account is checked against the assignments "
                      "(Portfolio Custody Account Mismatch)."),
            conf("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")],
                 note="Conformed from DP-140; reaches the fund of a portfolio for Custodian Appointment Mismatch."),
            conf("Investment Product", PROD, note="Conformed from DP-004; owning funds and appointing funds."),
            conf("Account", ACCT, note="Conformed from DP-093; owning client accounts."),
            conf("Internal Legal Entity", LE,
                 note="Conformed from DP-013; self-custodying providers."),
            conf("Party", PARTY,
                 note="Conformed from DP-240; custodians, sub-custodians, depositories, nominees and appointed parties."),
            conf("Contract", CONTRACT,
                 note="Conformed from DP-213 (upstream since the E1 merge); the custodian service agreement. Entity name "
                      "Contract assumed for DP-213."),
        ],
        relationships=[
            rel("Safekeeping Account", "Party", ["Account Provider"], optional=True),
            rel("Safekeeping Account", "Internal Legal Entity", ["Internal Account Provider"], optional=True),
            rel("Safekeeping Account", "Party", ["Registered Nominee"], optional=True),
            rel("Safekeeping Account Assignment", "Safekeeping Account", ["Assigned Safekeeping Account"]),
            rel("Safekeeping Account Assignment", "Investment Product", ["Owning Fund"], optional=True),
            rel("Safekeeping Account Assignment", "Portfolio", ["Owning Portfolio"], optional=True),
            rel("Safekeeping Account Assignment", "Account", ["Owning Client Account"], optional=True),
            rel("Custodian", "Party", ["Provider Party"], optional=True),
            rel("Custodian", "Internal Legal Entity", ["Provider Legal Entity"], optional=True),
            rel("Custodian", "Contract", ["Service Agreement Reference"], optional=True),
            rel("Sub-Custodian Network Arrangement", "Party", ["Arrangement Global Custodian"]),
            rel("Sub-Custodian Network Arrangement", "Party", ["Sub-Custodian"]),
            rel("Sub-Custodian Network Arrangement", "Party", ["Securities Depository"], optional=True),
            rel("Product Party Role", "Investment Product", ["Investment Product Key"],
                note="Carries the Product ID (Product Party Role is scoped within Investment Product)."),
            rel("Product Party Role", "Party", ["Party"]),
            rel("Portfolio", "Safekeeping Account", ["Safekeeping Custody Account"], optional=True,
                note="The book's main custody account as 18 records it."),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
        ],
        notes=("W1b re-point (CW-928): the Client Asset Designation entity and its two relationships are removed with the 28 object; no other entity changes. "
               "Foundational ER for the 28 custody network (CD-194, CD-296): Safekeeping Account with its owner "
               "assignments, the Custodian entity on Custody Provider Profile, and the "
               "sub-custodian network. The custodian, sub-custodian and global custodian are related to Custodian only "
               "through their party: Sub-Custodian Network Arrangement and Safekeeping Account carry party keys, and a "
               "party's custodian profile is found by matching Provider Party, which is a partial key of Custodian, so "
               "those links are drawn to Party. Entity names other products conform: Safekeeping Account, Custodian, "
               "Safekeeping Account Assignment, Sub-Custodian Network Arrangement. "
               "DP-210 Vendor Master is upstream for the supplier record of each provider, but no input attribute "
               "carries a 40 key, so no Vendor entity is drawn; the supplier record joins through the provider party. "
               "Warnings in the per-module check: conformed sources DP-213 and DP-240 are other E8 groups' models and are "
               "not loaded, so their fks warn that the parent does not hold Contract or Party."),
    ),
}
