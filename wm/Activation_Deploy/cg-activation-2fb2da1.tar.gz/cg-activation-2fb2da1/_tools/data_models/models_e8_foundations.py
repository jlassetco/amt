"""Logical data models, Phase 2 Wave E8, foundational products (ER): DP-097 Security Master & Identifiers, DP-098 Issuer
Hierarchy, Classifications & Ratings, DP-099 Corporate Action Event Golden Copy (Data Domain 17); DP-100 Taxonomy,
Glossary & Data Ownership Register, DP-101 Governance Metadata & Enterprise Catalog (Data Domain 21); DP-240 Enterprise
Party & Role Master (Data Domain 02). See CONTRACT.md.

Conformed dimensions published here for other products: Instrument, Instrument Identifier, Instrument Listing (DP-097);
Issuer (DP-098); Corporate Action Event, Corporate Action Option (DP-099); Taxonomy Element, Taxonomy Release, Business
Term, Governance Decision, Data Governance Body (DP-100); Data Asset, Data Product, Metric Definition, Data Contract
(DP-101); Party, Party Role, Party Identifier (DP-240).
"""

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-097": dict(
        style="ER",
        entities=[
            dict(name="Instrument", role="Entity",
                 objects=[("17", "Instrument"), ("17", "Equity Terms"), ("17", "Fund Instrument Terms"),
                          ("17", "Debt Terms"), ("17", "Securitized Product Terms"),
                          ("17", "Listed Derivative Contract Terms"), ("17", "OTC Derivative Product Terms"),
                          ("17", "Private Asset Terms"), ("17", "Fund Interest Terms")],
                 pk=["Instrument ID"], measures=True,
                 grain="one row = instrument x effective period (SCD type 2)",
                 note="The firm's one conformed Instrument dimension: holdings, prices, orders, settlements, corporate "
                      "actions, risk and compliance key on Instrument ID. The asset-class term groups each have one row "
                      "per instrument and fold here; only the group matching the Instrument Type is populated, which "
                      "keeps one dimension row per instrument instead of a subtype table per asset class. The effective "
                      "period in the grain is the SCD type 2 version period added at publication; no input attribute "
                      "carries it. Holds the product measures because every one of them counts or rates instruments."),
            dict(name="Instrument Identifier", role="Entity", objects=[("17", "Instrument Identifier")],
                 pk=["Instrument Identifier ID"],
                 grain="one row = instrument x identifier scheme x identifier value x effective period",
                 note="Every ISIN, CUSIP, SEDOL (17 scheme; 01 no longer carries it, CW-901), FIGI, ticker-based and UPI identifier, effective-dated so a reused or "
                      "reassigned code resolves to the right instrument on any date. Instrument x scheme x value x "
                      "Identifier Effective From is the alternate key; Duplicate Identifier Count tests it."),
            dict(name="Instrument Listing", role="Entity", objects=[("17", "Instrument Listing")],
                 pk=["Listing ID"],
                 grain="one row = instrument x venue MIC x effective period",
                 note="Venue-level listing; a SEDOL or exchange ticker identifier can point to the listing it belongs "
                      "to."),
            dict(name="Instrument Relationship", role="Entity", objects=[("17", "Instrument Relationship")],
                 pk=["Subject Instrument", "Related Instrument", "Related Index", "Instrument Relationship Type",
                     "Relationship Effective From"],
                 grain="one row = subject instrument x related instrument (or index) x relationship type x effective "
                       "period",
                 note="Underlyings, conversions, depositary receipt to ordinary share and basket constituents. Exactly "
                      "one of Related Instrument and Related Index is filled."),
            dict(name="Instrument Classification Assignment", role="Entity",
                 objects=[("17", "Instrument Classification Assignment")],
                 pk=["Classified Instrument", "Instrument Classification Scheme", "Instrument Classification Code",
                     "Instrument Classification Effective From"],
                 grain="one row = instrument x classification scheme x classification code x effective period",
                 note="Firm asset class, CFI and vendor sector schemes side by side, with overrides kept as their own "
                      "rows so the vendor value and the firm's correction are both visible."),
            dict(name="Regulatory Instrument Classification", role="Entity",
                 objects=[("17", "Regulatory Instrument Classification")],
                 pk=["Regulatory Classified Instrument", "Regulatory Classification Effective From"],
                 grain="one row = instrument x regulatory classification effective period",
                 note="Kept apart from Instrument because Rule 2a-7, 144A, Regulation S, restricted security and NAIC "
                      "eligibility change on their own regulatory timeline, not with the instrument's terms. W1 (CW-917): "
                      "the UCITS, MiFID II, EU or UK trading venue and Solvency II CIC attributes are gone."),
            dict(name="Coupon Schedule", role="Entity", objects=[("17", "Coupon Schedule")],
                 pk=["Coupon Instrument", "Coupon Period Number"],
                 grain="one row = instrument x coupon period"),
            dict(name="Redemption Schedule", role="Entity", objects=[("17", "Redemption Schedule")],
                 pk=["Redemption Instrument", "Redemption Event Type", "Redemption Start Date"],
                 grain="one row = instrument x redemption event type x redemption start date",
                 note="Call, put, sinking fund and maturity schedule; Debt Terms keeps only the callable and puttable "
                      "flags."),
            dict(name="Share Class", role="Entity", conformed=("DP-004", "Share Class"),
                 objects=[("01", "Share Class"), ("01", "Security Identifier")],
                 grain="one row = own share class",
                 note="Conformed from DP-004, the master of own share classes; the 01 attributes read here are the "
                      "ones DP-097 checks own-fund instrument rows against (identifier and status mismatches)."),
            dict(name="Share Class Listing", role="Entity", objects=[("01", "Listing")],
                 pk=["Share Class Key", "Listing Exchange"],
                 grain="one row = own share class x listing exchange",
                 note="01 Listing is read directly because DP-004 does not publish it. It is scoped within Share Class "
                      "and carries no share class attribute, so its key is completed by the Share Class Key (Share "
                      "Class ID)."),
            dict(name="Investment Product", role="Entity", conformed=("DP-004", "Investment Product"), objects=[],
                 note="Conformed from DP-004 so Share Class.Parent Product and Fund Instrument Terms.Own Investment "
                      "Product resolve to the product master."),
            dict(name="Benchmark", role="Entity", objects=[("01", "Benchmark")],
                 pk=["Benchmark ID"],
                 grain="one row = benchmark (single or blended index)",
                 note="Read from 01 directly: DP-004 does not publish Benchmark yet (its extension is deferred to "
                      "Phase 2, CD-322). Once it does, conform it from DP-004 instead."),
            dict(name="Classification Scheme", role="Entity", conformed=("DP-013", "Classification Scheme"),
                 objects=[("09", "Classification Scheme")]),
            dict(name="Classification Code", role="Entity", conformed=("DP-013", "Classification Code"),
                 objects=[("09", "Classification Code")],
                 pk=["Classification Scheme Key", "Classification Code"],
                 note="Conformed from DP-013; the code is unique only within its scheme version, so the key is "
                      "completed by the Classification Scheme Key as in DP-013."),
            dict(name="Calendar", role="Entity", conformed=("DP-013", "Calendar"), objects=[],
                 note="Conformed from DP-013 so the payment and trading calendars resolve to the calendar master."),
            dict(name="Dataset", role="Entity", objects=[("14", "Dataset")],
                 pk=["Dataset ID"],
                 grain="one row = licensed vendor dataset",
                 note="The vendor dataset an instrument record was sourced from. Read from 14 directly: DP-014 and "
                      "DP-075 publish Dataset but neither is upstream of DP-097, so it is not conformed here."),
        ],
        relationships=[
            dict(child="Instrument Identifier", parent="Instrument", fk=["Identified Instrument"], card="M:1"),
            dict(child="Instrument Identifier", parent="Instrument Listing", fk=["Identifier Listing"], card="M:1",
                 optional=True, note="Only venue-level identifiers (SEDOL, exchange ticker) carry a listing."),
            dict(child="Instrument Listing", parent="Instrument", fk=["Listed Instrument"], card="M:1"),
            dict(child="Instrument Listing", parent="Calendar", fk=["Trading Calendar"], card="M:1", optional=True),
            dict(child="Instrument Relationship", parent="Instrument", fk=["Subject Instrument"], card="M:1"),
            dict(child="Instrument Relationship", parent="Instrument", fk=["Related Instrument"], card="M:1",
                 optional=True, note="Blank when the related side is an index."),
            dict(child="Instrument Relationship", parent="Benchmark", fk=["Related Index"], card="M:1", optional=True,
                 note="Index underlyings of derivatives and index-linked notes."),
            dict(child="Instrument Classification Assignment", parent="Instrument", fk=["Classified Instrument"],
                 card="M:1"),
            dict(child="Instrument Classification Assignment", parent="Classification Scheme",
                 fk=["Instrument Classification Scheme"], card="M:1"),
            dict(child="Instrument Classification Assignment", parent="Classification Code",
                 fk=["Instrument Classification Code"], card="M:1", optional=True,
                 note="The code resolves within the assignment's scheme; firm overrides may carry a code not yet in "
                      "the DP-013 scheme, hence optional."),
            dict(child="Classification Code", parent="Classification Scheme", fk=["Classification Scheme Key"],
                 card="M:1", note="Classification Scheme Key carries the Classification Scheme ID (scheme version)."),
            dict(child="Regulatory Instrument Classification", parent="Instrument",
                 fk=["Regulatory Classified Instrument"], card="M:1"),
            dict(child="Coupon Schedule", parent="Instrument", fk=["Coupon Instrument"], card="M:1"),
            dict(child="Redemption Schedule", parent="Instrument", fk=["Redemption Instrument"], card="M:1"),
            dict(child="Instrument", parent="Share Class", fk=["Own Share Class"], card="M:1", optional=True,
                 note="Only rows of Instrument Type = Own Fund Share Class; the instrument row republishes the DP-004 "
                      "share class as a holdable instrument."),
            dict(child="Instrument", parent="Investment Product", fk=["Own Investment Product"], card="M:1",
                 optional=True, note="Held funds that are the firm's own products (fund-of-funds, feeder holdings)."),
            dict(child="Instrument", parent="Calendar", fk=["Payment Calendar"], card="M:1", optional=True,
                 note="Debt Terms payment calendar."),
            dict(child="Instrument", parent="Dataset", fk=["Source Dataset"], card="M:1", optional=True),
            dict(child="Share Class", parent="Investment Product", fk=["Parent Product"], card="M:1"),
            dict(child="Share Class Listing", parent="Share Class", fk=["Share Class Key"], card="M:1",
                 note="Share Class Key carries the Share Class ID; no attribute of 01 Listing holds it."),
        ],
        notes=("Foundational master, modeled ER around Instrument: the instrument and its asset-class term groups form "
               "one entity keyed by Instrument ID, with effective-dated children for identifiers, listings, "
               "classifications, regulatory eligibility, coupon and redemption schedules and instrument relationships. "
               "Own share classes, their products and the classification schemes and calendars are conformed from "
               "DP-004 and DP-013 rather than rebuilt. "
               "External references (resolved by joining to another product, not linked here): Instrument.Issuer, Debt "
               "Guarantor, Depositary Bank, Fund Manager or General Partner, Collateral Manager or Servicer, Clearing "
               "House and Administrative Agent, and Instrument Identifier.Issuing Agency to Party (DP-240; issuer "
               "attributes from DP-098, which depends on DP-097 and so cannot be upstream of it); Fund Instrument "
               "Terms.Peer Fund to Peer Fund (11); Dataset.Dataset Vendor to Data Vendor (14). "
               "Model gap: DP-240 is not upstream of DP-097, so the issuer and the other party roles on Instrument stay "
               "unresolved keys in this product; consumers join Instrument.Issuer to the Issuer dimension of DP-098. "
               "Model gap: 01 Benchmark and 01 Listing are read from their master because DP-004 does not publish them; "
               "conform them from DP-004 once its CD-322 extension is modeled."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-098": dict(
        style="ER",
        entities=[
            dict(name="Issuer", role="Entity", conformed=("DP-240", "Party"),
                 objects=[("17", "Issuer Profile"), ("02", "Party"), ("02", "Organization")],
                 pk=["Party ID"], measures=True,
                 grain="one row = party that issues, guarantees or stands behind an instrument x effective period (SCD "
                       "type 2)",
                 note="The conformed Issuer dimension. Party identity, organization profile and legal hierarchy are "
                      "conformed from DP-240, so a bank that is both issuer and counterparty is one party. Issuer "
                      "Profile is a 1:1 issuer-role extension of Party keyed by the Party ID (Issuer Party carries the "
                      "same value) and folds here; it is populated only for parties with an issuer profile, which is "
                      "how Instruments Without Issuer Profile finds the gaps. Legal parents, guarantors and credit "
                      "parents are rows too, so the parent and override links resolve inside this entity. Holds the "
                      "product measures because they are counted or rated per issuer. PII: the wealth 02 flags Party "
                      "attributes as personal data because a party may be an individual; issuers are organizations."),
            dict(name="Legal Entity Hierarchy", role="Entity", objects=[("02", "Legal Entity Hierarchy")],
                 pk=["Subsidiary Party", "Direct Parent", "Parent Relationship Basis", "Hierarchy Effective From"],
                 grain="one row = subsidiary party x direct parent party x relationship basis x effective period",
                 note="W1 re-point (CW-902): a business object with its own Subsidiary Party key and effective dates in "
                      "the wealth 02, so it no longer folds into Issuer; the legal rollup is read from here."),
            dict(name="Party Role", role="Entity", objects=[("02", "Party Role")],
                 pk=["Role Party", "Role Type", "Role Effective From"],
                 grain="one row = issuer party x role type x role effective period",
                 note="The issuer and guarantor roles from the party master, keyed by Role Party (W1, CW-902)."),
            dict(name="Party Identifier", role="Entity", objects=[("02", "Party Identifier"), ("02", "LEI Record")],
                 pk=["Identifier Scheme", "Identifier Value", "Identifier Effective From"],
                 grain="one row = party identifier (scheme x value x effective period)",
                 note="LEI Record folds here (its parent is Party Identifier), populated on LEI-scheme rows; Issuers "
                      "Without LEI % reads it. The owning issuer is the Identified Party reference (W1, CW-902)."),
            dict(name="Issuer Relationship", role="Entity", objects=[("17", "Issuer Relationship")],
                 pk=["Subject Issuer", "Related Party", "Issuer Relationship Type", "Issuer Relationship Effective From"],
                 grain="one row = issuer party x related party x issuer relationship type x effective period",
                 note="Credit parent overrides and guarantees that research maintains on top of the legal hierarchy; "
                      "kept apart from Legal Entity Hierarchy because they can differ from it on purpose."),
            dict(name="Issuer Classification Assignment", role="Entity",
                 objects=[("17", "Issuer Classification Assignment")],
                 pk=["Classified Issuer", "Issuer Classification Scheme", "Issuer Sector Code",
                     "Issuer Classification Effective From"],
                 grain="one row = issuer party x classification scheme x sector code x effective period"),
            dict(name="Credit Rating Assignment", role="Entity", objects=[("17", "Credit Rating Assignment")],
                 pk=["Rated Instrument", "Rated Issuer", "Credit Rating Agency", "Credit Rating Type",
                     "Credit Rating Action Date"],
                 grain="one row = rated instrument (issue rating) or rated issuer (issuer rating) x credit rating "
                       "agency x credit rating type x action date",
                 note="Issue and issuer ratings in one entity: which of Rated Instrument and Rated Issuer is filled "
                      "tells them apart, and Composite Agency Rating Notch falls back from issue to issuer rating."),
            dict(name="Instrument", role="Entity", conformed=("DP-097", "Instrument"), objects=[("17", "Instrument")],
                 note="Conformed from DP-097; read for issue ratings and to find instruments whose issuer has no "
                      "profile."),
            dict(name="Classification Scheme", role="Entity", conformed=("DP-013", "Classification Scheme"),
                 objects=[("09", "Classification Scheme")]),
            dict(name="Classification Code", role="Entity", conformed=("DP-013", "Classification Code"),
                 objects=[("09", "Classification Code")],
                 pk=["Classification Scheme Key", "Classification Code"],
                 note="Conformed from DP-013; unique only within its scheme version."),
            dict(name="Dataset", role="Entity", objects=[("14", "Dataset")],
                 pk=["Dataset ID"],
                 grain="one row = licensed vendor dataset",
                 note="The rating agency or vendor feed a rating came from. Read from 14 directly: DP-014 and DP-075 "
                      "publish Dataset but neither is upstream of DP-098."),
        ],
        relationships=[
            dict(child="Legal Entity Hierarchy", parent="Issuer", fk=["Subsidiary Party"], card="M:1"),
            dict(child="Legal Entity Hierarchy", parent="Issuer", fk=["Direct Parent"], card="M:1",
                 note="Legal direct parent."),
            dict(child="Legal Entity Hierarchy", parent="Issuer", fk=["Ultimate Parent"], card="M:1", optional=True),
            dict(child="Issuer", parent="Issuer", fk=["Merged Into Party"], card="M:1", optional=True,
                 note="Survivor of a party merge in DP-240."),
            dict(child="Issuer", parent="Instrument", fk=["Primary Equity Instrument"], card="M:1", optional=True,
                 note="The issuer's primary listed equity, for equity-based issuer analytics."),
            dict(child="Party Role", parent="Issuer", fk=["Role Party"], card="M:1"),
            dict(child="Party Identifier", parent="Issuer", fk=["Identified Party"], card="M:1"),
            dict(child="Issuer Relationship", parent="Issuer", fk=["Subject Issuer"], card="M:1"),
            dict(child="Issuer Relationship", parent="Issuer", fk=["Related Party"], card="M:1",
                 note="Credit parent or guarantor; a row of Issuer because it stands behind the subject's instruments."),
            dict(child="Issuer Classification Assignment", parent="Issuer", fk=["Classified Issuer"], card="M:1"),
            dict(child="Issuer Classification Assignment", parent="Classification Scheme",
                 fk=["Issuer Classification Scheme"], card="M:1"),
            dict(child="Issuer Classification Assignment", parent="Classification Code", fk=["Issuer Sector Code"],
                 card="M:1", optional=True, note="The sector code resolves within the assignment's scheme."),
            dict(child="Classification Code", parent="Classification Scheme", fk=["Classification Scheme Key"],
                 card="M:1", note="Classification Scheme Key carries the Classification Scheme ID."),
            dict(child="Credit Rating Assignment", parent="Instrument", fk=["Rated Instrument"], card="M:1",
                 optional=True, note="Issue ratings only."),
            dict(child="Credit Rating Assignment", parent="Issuer", fk=["Rated Issuer"], card="M:1", optional=True,
                 note="Issuer ratings only."),
            dict(child="Credit Rating Assignment", parent="Dataset", fk=["Credit Rating Source Dataset"], card="M:1",
                 optional=True),
            dict(child="Instrument", parent="Issuer", fk=["Issuer"], card="M:1", optional=True,
                 note="Blank for own share classes and derivative contracts; an issuer with no profile still has a "
                      "party row here."),
        ],
        notes=("Foundational master, modeled ER around one Issuer entity conformed from the DP-240 Party (identity, "
               "organization) and extended 1:1 by the Issuer Profile, with effective-dated children for the legal "
               "hierarchy, credit parent and guarantee overrides, sector classifications and credit ratings. W1 "
               "re-point (CW-902): Party Role, Party Identifier and Legal Entity Hierarchy carry their own party "
               "references (Role Party, Identified Party, Subsidiary Party), so the borrowed Issuer Key is gone. Consumers "
               "conform ('DP-098', 'Issuer') for issuer, guarantor and ultimate parent roles. "
               "External references (not linked here): Dataset.Dataset Vendor to Data Vendor (14); Organization.Legal "
               "Jurisdiction and Industry Classification are codes resolved through DP-013. "
               "Decision for data owners: the Issuer entity's rows are every party that issues, guarantees or stands "
               "behind an instrument (as the definition says), not every DP-240 party; parties outside that set "
               "resolve through DP-240."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-099": dict(
        style="ER",
        entities=[
            dict(name="Corporate Action Event", role="Entity", objects=[("17", "Corporate Action Event")],
                 pk=["Corporate Action Event ID"], measures=True,
                 grain="one row = corporate action event on one instrument x announcement version (preliminary, "
                       "confirmed, canceled, withdrawn)",
                 note="The conformed Corporate Action Event dimension (golden copy). Official Corporate Action Event "
                      "Reference (COAF) is the cross-custodian alternate key used to match custodian notifications. "
                      "The announcement version is the SCD type 2 version added at publication. Holds the product "
                      "measures because they count events, or options and receipts per event."),
            dict(name="Corporate Action Option", role="Entity", objects=[("17", "Corporate Action Option")],
                 pk=["Option Event", "Option Number"],
                 grain="one row = corporate action event x option number",
                 note="The product's published grain (event x option, with event attributes repeated) is this entity "
                      "joined to its event; events without options publish one row with a blank option."),
            dict(name="Custodian Notification", role="Entity", objects=[("28", "Corporate Action Notification Receipt")],
                 pk=["Custodian Notification Key"],
                 grain="one row = custodian notification message for one corporate action event x safekeeping account",
                 note="Model gap: surrogate key. The registry key is Notified Safekeeping Account + Custodian Message "
                      "Reference (the message reference is unique only per sending custodian), but the spec does not "
                      "read Notified Safekeeping Account."),
            dict(name="Instrument", role="Entity", conformed=("DP-097", "Instrument"), objects=[("17", "Instrument")],
                 note="Conformed from DP-097: the event instrument and the resulting instrument of an option."),
            dict(name="Instrument Identifier", role="Entity", conformed=("DP-097", "Instrument Identifier"),
                 objects=[("17", "Instrument Identifier")],
                 note="Conformed from DP-097; used to match the ISIN or CUSIP a custodian or vendor announces against "
                      "the golden copy instrument."),
        ],
        relationships=[
            dict(child="Corporate Action Event", parent="Instrument", fk=["Event Instrument"], card="M:1"),
            dict(child="Corporate Action Event", parent="Corporate Action Event", fk=["Linked Event"], card="M:1",
                 optional=True, note="Two-step events (e.g. a rights issue followed by its subscription)."),
            dict(child="Corporate Action Option", parent="Corporate Action Event", fk=["Option Event"], card="M:1"),
            dict(child="Corporate Action Option", parent="Instrument", fk=["Resulting Instrument"], card="M:1",
                 optional=True, note="New securities delivered by the option; blank for cash options."),
            dict(child="Custodian Notification", parent="Corporate Action Event", fk=["Notified Event"], card="M:1",
                 optional=True, note="Optional because Orphan Custodian Notifications measures the receipts that do "
                                     "not resolve to an event."),
            dict(child="Instrument Identifier", parent="Instrument", fk=["Identified Instrument"], card="M:1"),
        ],
        notes=("Foundational master, modeled ER around the golden-copy Corporate Action Event with its options and the "
               "custodian notifications reconciled against it; the instrument and its identifiers are conformed from "
               "DP-097. "
               "External references (not linked here): Corporate Action Event.Offeror to Party (DP-240, not upstream; "
               "read through the Issuer dimension of DP-098 or DP-240 by consumers). "
               "Model gap: Custodian Notification uses a surrogate key because Notified Safekeeping Account (part of "
               "the registry key, and the link to 28 Safekeeping Account) is not a spec input; add it to the DP-099 "
               "inputs for 28 Corporate Action Notification Receipt."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-100": dict(
        style="ER",
        entities=[
            dict(name="Taxonomy Element", role="Entity", objects=[("21", "Taxonomy Element")],
                 pk=["Taxonomy Element Key"],
                 grain="one row = taxonomy element (Data Domain, family, object or attribute), stable across releases",
                 note="The conformed Taxonomy Element dimension. The 'NN | Family | Object | Attribute' key is kept "
                      "across releases, so ownership, CDE and classification rows survive renumbering; the "
                      "release-specific code and wording sit on Taxonomy Element Registration."),
            dict(name="Taxonomy Release", role="Entity", objects=[("21", "Taxonomy Release")],
                 pk=["Taxonomy Release ID"],
                 grain="one row = taxonomy release"),
            dict(name="Taxonomy Element Registration", role="Entity", objects=[("21", "Taxonomy Element Registration")],
                 pk=["Registered Taxonomy Element", "Registering Release"], measures=True,
                 grain="one row = taxonomy element x taxonomy release",
                 note="The product grain: what an element was called, defined and flagged in each release. Holds the "
                      "product measures because coverage and change counts are taken per element in the current "
                      "release."),
            dict(name="Business Term", role="Entity", objects=[("21", "Business Term")],
                 pk=["Business Term ID"],
                 grain="one row = business glossary term"),
            dict(name="Business Term Relationship", role="Entity", objects=[("21", "Business Term Relationship")],
                 pk=["Source Business Term", "Term Relationship Type", "Related Business Term",
                     "Related Taxonomy Element"],
                 grain="one row = source business term x relationship type x related term or taxonomy element",
                 note="Term-to-term and term-to-element links in one entity; exactly one of the related term and the "
                      "related element is populated."),
            dict(name="Governance Decision", role="Entity", objects=[("21", "Governance Decision")],
                 pk=["Governance Decision ID"],
                 grain="one row = governance decision"),
            dict(name="Data Governance Body", role="Entity", objects=[("21", "Data Governance Body")],
                 pk=["Governance Body ID"],
                 grain="one row = data governance body (council, forum, working group)"),
            dict(name="Data Ownership Assignment", role="Entity", objects=[("21", "Data Ownership Assignment")],
                 pk=["Ownership Assignment ID"],
                 grain="one row = governed scope x governance role x employee x effective period",
                 note="One entity for every governed scope type (Data Domain, element, capability, code list, term, "
                      "data product, data asset, DQ rule, metric); Governed Scope Type says which scope reference is "
                      "filled."),
            dict(name="Critical Data Element", role="Entity", objects=[("21", "Critical Data Element")],
                 pk=["CDE ID"],
                 grain="one row = CDE x scope x effective period"),
            dict(name="Data Classification Assignment", role="Entity",
                 objects=[("21", "Data Classification Assignment")],
                 pk=["Classified Taxonomy Element", "Classified Data Asset", "Classification Scheme",
                     "Classification Effective From"],
                 grain="one row = taxonomy element or data asset x classification scheme x effective period",
                 note="Exactly one of the classified element and the classified data asset is populated."),
            dict(name="Code List", role="Entity", conformed=("DP-013", "Code List"), objects=[("09", "Code List")]),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[("20", "Employee")],
                 pk=["Employee ID"],
                 note="Conformed from DP-192, the employee master (Employment Status drives Assignments Held by "
                      "Leavers)."),
            dict(name="Org Unit", role="Entity", conformed=("DP-013", "Org Unit"), objects=[("09", "Org Unit")]),
        ],
        relationships=[
            dict(child="Taxonomy Element", parent="Taxonomy Release", fk=["First Registered Release"], card="M:1"),
            dict(child="Taxonomy Element", parent="Taxonomy Element", fk=["Successor Taxonomy Element"], card="M:1",
                 optional=True, note="Retired or moved elements point to the element that replaced them."),
            dict(child="Taxonomy Release", parent="Taxonomy Release", fk=["Predecessor Release"], card="M:1",
                 optional=True),
            dict(child="Taxonomy Element Registration", parent="Taxonomy Element", fk=["Registered Taxonomy Element"],
                 card="M:1"),
            dict(child="Taxonomy Element Registration", parent="Taxonomy Release", fk=["Registering Release"],
                 card="M:1"),
            dict(child="Taxonomy Element Registration", parent="Taxonomy Element", fk=["Parent Business Object"],
                 card="M:1", optional=True, note="Attributes and groups only: the L3 object they belong to."),
            dict(child="Taxonomy Element Registration", parent="Code List", fk=["Element Code List"], card="M:1",
                 optional=True),
            dict(child="Business Term", parent="Code List", fk=["Governing Code List"], card="M:1", optional=True),
            dict(child="Business Term Relationship", parent="Business Term", fk=["Source Business Term"], card="M:1"),
            dict(child="Business Term Relationship", parent="Business Term", fk=["Related Business Term"], card="M:1",
                 optional=True),
            dict(child="Business Term Relationship", parent="Taxonomy Element", fk=["Related Taxonomy Element"],
                 card="M:1", optional=True),
            dict(child="Business Term Relationship", parent="Taxonomy Release",
                 fk=["Related Element Registered In Release"], card="M:1", optional=True),
            dict(child="Governance Decision", parent="Taxonomy Release", fk=["Applied In Release"], card="M:1",
                 optional=True),
            dict(child="Data Governance Body", parent="Employee", fk=["Governance Body Chair"], card="M:1",
                 optional=True),
            dict(child="Data Governance Body", parent="Data Governance Body", fk=["Parent Governance Body"],
                 card="M:1", optional=True),
            dict(child="Data Ownership Assignment", parent="Employee", fk=["Assigned Employee"], card="M:1"),
            dict(child="Data Ownership Assignment", parent="Data Governance Body", fk=["Appointing Governance Body"],
                 card="M:1", optional=True),
            dict(child="Data Ownership Assignment", parent="Taxonomy Element", fk=["Governed Taxonomy Element"],
                 card="M:1", optional=True),
            dict(child="Data Ownership Assignment", parent="Taxonomy Release",
                 fk=["Governed Element Registered In Release"], card="M:1", optional=True),
            dict(child="Data Ownership Assignment", parent="Code List", fk=["Governed Code List"], card="M:1",
                 optional=True),
            dict(child="Data Ownership Assignment", parent="Business Term", fk=["Governed Business Term"], card="M:1",
                 optional=True),
            dict(child="Critical Data Element", parent="Taxonomy Element", fk=["CDE Taxonomy Attribute"], card="M:1"),
            dict(child="Critical Data Element", parent="Taxonomy Release", fk=["CDE Registered In Release"],
                 card="M:1", optional=True),
            dict(child="Critical Data Element", parent="Employee", fk=["CDE Owner"], card="M:1", optional=True),
            dict(child="Data Classification Assignment", parent="Taxonomy Element",
                 fk=["Classified Taxonomy Element"], card="M:1", optional=True),
            dict(child="Data Classification Assignment", parent="Taxonomy Release",
                 fk=["Classified Element Registered In Release"], card="M:1", optional=True),
            dict(child="Employee", parent="Org Unit", fk=["Home Org Unit"], card="M:1"),
        ],
        notes=("Foundational register, modeled ER around Taxonomy Element (stable key) and its per-release "
               "registrations, with the glossary, governance decisions, governance bodies, ownership assignments, "
               "CDEs and classifications pointing at elements. Every '... Registered In Release' attribute pins the "
               "release whose wording the governing row refers to; it links to Taxonomy Release alongside the element "
               "link rather than through a composite key on the registration, as the registry maps the two references "
               "separately. Employee, Org Unit and Code List are conformed from DP-192 and DP-013. "
               "External references (resolved in DP-101 or elsewhere, not linked here): Business Term.Defining Metric "
               "and Data Ownership Assignment.Governed Metric to Metric Definition, Governed Data Product and Critical "
               "Data Element.CDE Scoped Data Product to Data Product, Governed Data Asset and Data Classification "
               "Assignment.Classified Data Asset to Data Asset (all DP-101, which depends on DP-100); Data Ownership "
               "Assignment.Governed Data Quality Rule to Data Quality Rule (DP-075). "
               "Note: the Employee conformed dimension assumes DP-192 publishes an entity named 'Employee' keyed by "
               "Employee ID (the E1 shared-dimension list); until DP-192's model is loaded the per-module check warns "
               "that its source is not loaded."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-101": dict(
        style="ER",
        entities=[
            dict(name="Data Asset", role="Entity",
                 objects=[("21", "Data Asset"), ("21", "Analytics Report & Dashboard Detail")],
                 pk=["Data Asset ID"], measures=True,
                 grain="one row = data asset (table, view, file, feed, API, analytics report or dashboard) x version",
                 note="The conformed Data Asset dimension. Analytics Report & Dashboard Detail has one row per asset "
                      "and folds here, populated only for reports and dashboards. Holds the product measures because "
                      "most of them count or trace catalog entries from the asset side (mapping, lineage and system "
                      "of record coverage)."),
            dict(name="Data Product", role="Entity", objects=[("21", "Data Product"), ("21", "Semantic Model Binding")],
                 pk=["Data Product ID"],
                 grain="one row = data product x specification version",
                 note="Semantic Model Binding has one row per data product (its publication in a semantic model) and "
                      "folds here."),
            dict(name="Data Product Input", role="Entity", objects=[("21", "Data Product Input")],
                 pk=["Input Data Product", "Input Taxonomy Element"],
                 grain="one row = data product x input taxonomy element"),
            dict(name="Data Element Mapping", role="Entity", objects=[("21", "Data Element Mapping")],
                 pk=["Mapped Data Asset", "Physical Element Name", "Mapped Taxonomy Attribute"],
                 grain="one row = data asset x physical element x taxonomy element"),
            dict(name="Lineage Link", role="Entity", objects=[("21", "Lineage Link")],
                 pk=["Lineage Link ID"],
                 grain="one row = lineage edge from a source data asset (or element) to a target asset, client feed "
                       "or client report",
                 note="A directed edge; Downstream Impact Count walks these edges with Data Product.Upstream Data "
                      "Products."),
            dict(name="System of Record Designation", role="Entity", objects=[("21", "System of Record Designation")],
                 pk=["SoR Designation ID"],
                 grain="one row = taxonomy element x system x designation type x business line x effective period"),
            dict(name="Object Governance Profile", role="Entity", objects=[("21", "Object Governance Profile")],
                 pk=["Governed Business Object", "Profile Effective From"],
                 grain="one row = L3 business object x effective period"),
            dict(name="Data Contract", role="Entity", objects=[("21", "Data Contract")],
                 pk=["Data Contract ID"],
                 grain="one row = data contract x version"),
            dict(name="Metric Definition", role="Entity", objects=[("21", "Metric Definition")],
                 pk=["Metric ID"],
                 grain="one row = registered metric definition"),
            dict(name="Taxonomy Element", role="Entity", conformed=("DP-100", "Taxonomy Element"),
                 objects=[("21", "Taxonomy Element")]),
            dict(name="Taxonomy Release", role="Entity", conformed=("DP-100", "Taxonomy Release"), objects=[],
                 note="Conformed from DP-100 so the '... Registered In Release' references resolve."),
            dict(name="Governance Decision", role="Entity", conformed=("DP-100", "Governance Decision"), objects=[],
                 note="Conformed from DP-100: the decision that made a system of record designation."),
            dict(name="Application", role="Entity", conformed=("DP-211", "Application"),
                 objects=[("41", "Application")], pk=["Application ID"],
                 note="Conformed from DP-211, the application inventory; hosting and designated systems resolve here "
                      "(Unresolved System References counts the ones that do not)."),
            dict(name="Org Unit", role="Entity", conformed=("DP-013", "Org Unit"), objects=[],
                 note="Conformed from DP-013: the internal consumer of a data contract and the application owner."),
            dict(name="Dataset", role="Entity", objects=[("14", "Dataset")],
                 pk=["Dataset ID"],
                 grain="one row = licensed vendor dataset",
                 note="Read from 14 directly: DP-014 and DP-075 publish Dataset but neither is upstream of DP-101."),
            dict(name="Data Feed", role="Entity", objects=[("06", "Data Feed")],
                 pk=["Feed ID"],
                 grain="one row = inbound data feed",
                 note="Read from 06 directly: the products that publish Data Feed (DP-006, DP-007, DP-075) are not "
                      "upstream of DP-101."),
            dict(name="Measure Definition", role="Entity", objects=[("06", "Measure Definition")],
                 pk=["Measure ID"],
                 grain="one row = 06 measure definition",
                 note="Read from 06 directly for Certification Copy Mismatches; DP-008 and DP-075 publish it but are "
                      "not upstream of DP-101."),
        ],
        relationships=[
            dict(child="Data Asset", parent="Application", fk=["Hosting System"], card="M:1", optional=True),
            dict(child="Data Asset", parent="Dataset", fk=["Cataloged Licensed Dataset"], card="M:1", optional=True,
                 note="Assets that catalog a licensed vendor dataset."),
            dict(child="Data Asset", parent="Data Feed", fk=["Cataloged Technical Feed"], card="M:1", optional=True),
            dict(child="Data Asset", parent="Data Product", fk=["Report Primary Data Product"], card="M:1",
                 optional=True, note="Analytics reports and dashboards only."),
            dict(child="Data Product", parent="Data Product", fk=["Upstream Data Products"], card="M:N",
                 optional=True, note="Multi-valued: the product dependency graph used by Foundational Dependency "
                                     "Breaches and Downstream Impact Count."),
            dict(child="Data Product", parent="Metric Definition", fk=["Bound Certified Metrics"], card="M:N",
                 optional=True, note="Semantic Model Binding (multi-valued): the certified metrics a product's "
                                     "semantic model publishes."),
            dict(child="Data Product Input", parent="Data Product", fk=["Input Data Product"], card="M:1"),
            dict(child="Data Product Input", parent="Taxonomy Element", fk=["Input Taxonomy Element"], card="M:1"),
            dict(child="Data Product Input", parent="Taxonomy Release", fk=["Input Registered In Release"],
                 card="M:1", optional=True),
            dict(child="Data Element Mapping", parent="Data Asset", fk=["Mapped Data Asset"], card="M:1"),
            dict(child="Data Element Mapping", parent="Taxonomy Element", fk=["Mapped Taxonomy Attribute"],
                 card="M:1"),
            dict(child="Data Element Mapping", parent="Taxonomy Release", fk=["Mapped Attribute Registered In Release"],
                 card="M:1", optional=True),
            dict(child="Lineage Link", parent="Data Asset", fk=["Lineage Source Data Asset"], card="M:1"),
            dict(child="Lineage Link", parent="Data Asset", fk=["Lineage Target Data Asset"], card="M:1",
                 optional=True, note="Blank when the target is a client data feed or client report (Data Domain 12)."),
            dict(child="System of Record Designation", parent="Taxonomy Element", fk=["Designated Taxonomy Element"],
                 card="M:1"),
            dict(child="System of Record Designation", parent="Taxonomy Release",
                 fk=["Designated Element Registered In Release"], card="M:1", optional=True),
            dict(child="System of Record Designation", parent="Application", fk=["Designated System"], card="M:1"),
            dict(child="System of Record Designation", parent="Data Asset", fk=["Designated Data Asset"], card="M:1",
                 optional=True),
            dict(child="System of Record Designation", parent="Governance Decision", fk=["Designating Decision"],
                 card="M:1", optional=True),
            dict(child="Object Governance Profile", parent="Taxonomy Element", fk=["Governed Business Object"],
                 card="M:1"),
            dict(child="Object Governance Profile", parent="Taxonomy Release", fk=["Profile Registered In Release"],
                 card="M:1", optional=True),
            dict(child="Data Contract", parent="Data Product", fk=["Contracted Data Product"], card="M:1"),
            dict(child="Data Contract", parent="Org Unit", fk=["Consumer Org Unit"], card="M:1", optional=True),
            dict(child="Metric Definition", parent="Data Product", fk=["Metric Source Data Product"], card="M:1",
                 optional=True),
            dict(child="Metric Definition", parent="Measure Definition", fk=["Registered Measure Definition"],
                 card="M:1", optional=True, note="The 06 measure a certified metric registers."),
            dict(child="Application", parent="Org Unit", fk=["Owning Org Unit"], card="M:1", optional=True),
        ],
        notes=("Foundational catalog, modeled ER with four catalog entry entities (Data Asset, Data Product, Metric "
               "Definition, Data Contract) and the governance links between them and the taxonomy: product inputs, "
               "physical-to-taxonomy mappings, lineage edges, system of record designations and object governance "
               "profiles. Taxonomy Element, Taxonomy Release and Governance Decision are conformed from DP-100, "
               "Application from DP-211 and Org Unit from DP-013. "
               "External references (not linked here): Data Asset.Providing Party, Data Contract.Consumer External "
               "Party and Data Feed.Data Provider to Party (DP-240, not upstream); Lineage Link.Lineage Target Client "
               "Data Feed and Lineage Target Client Report to Client Data Feed and Report Definition (12); Data "
               "Contract.Contracted DQ Rules to Data Quality Rule (DP-075); Object Governance Profile.Object Records "
               "Retention Rule to Retention Rule (21, RET-; the 08 and 39 retention references resolve to 21 since W4); Metric Definition.Registered Market Share Definition and "
               "Registered Profitability Measure to 11 Market Share Definition and 10 Profitability Measure "
               "Definition; Dataset.Dataset Vendor to Data Vendor (14). Lineage Source Element and Lineage Target "
               "Element are physical element names, not taxonomy references. "
               "Note: Application is conformed from DP-211, modeled in the same wave; until its model is loaded the "
               "per-module check warns that the source is not loaded and Application carries only the 41 attributes "
               "DP-101 reads."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-240": dict(
        style='ER',
        entities=[
            dict(name='Party',
                 role='Entity',
                 objects=[('02', 'Party'), ('02', 'Organization'), ('02', 'Individual'), ('02', 'US Regulatory Identifier'), ('02', 'Household'), ('02', 'KYC Profile'), ('02', 'Tax Profile'), ('02', 'Privacy Profile')],
                 pk=['Party ID'],
                 measures=True,
                 grain='one row = party (one real-world external organization, individual or Client Household) x effective period (SCD type 2)',
                 note='The enterprise conformed Party dimension: one row per real-world party whatever roles it plays (client, distributor, issuer, counterparty, supplier), so DP-098 Issuer and the counterparty, vendor and custodian masters conform from it. Organization, Individual and the US regulatory and market infrastructure identifier groups have one row per party and fold here (registry fold); only the group matching the Party Type is populated. Holds the product measures because they count parties (by role, identifier and hierarchy completeness). PII tier: identity (names, Date of Death, regulatory identifiers of individuals); no financial or special-category attribute is read.'),
            dict(name='Legal Entity Hierarchy',
                 role='Entity',
                 objects=[('02', 'Legal Entity Hierarchy')],
                 pk=['Subsidiary Party', 'Direct Parent', 'Parent Relationship Basis', 'Hierarchy Effective From'],
                 grain='one row = subsidiary party x direct parent party x relationship basis x effective period',
                 note='W1 re-point (CW-902): the wealth 02 makes the hierarchy a business object with its own Subsidiary Party key and effective dates, so it leaves the Party entity; Ownership Percentage is gone.'),
            dict(name='Party Role',
                 role='Entity',
                 objects=[('02', 'Party Role')],
                 pk=['Role Party', 'Role Type', 'Role Effective From'],
                 grain='one row = party x role type x role effective period',
                 note="The product's headline grain. W1 re-point (CW-902): keyed by its own Role Party reference; the borrowed Party Key is no longer needed. PII tier: identity (a role names the party)."),
            dict(name='Party Identifier',
                 role='Entity',
                 objects=[('02', 'Party Identifier'), ('02', 'LEI Record')],
                 pk=['Identifier Scheme', 'Identifier Value', 'Identifier Effective From'],
                 grain='one row = party x identifier scheme x identifier value x effective period',
                 note='LEI Record folds here (its parent is Party Identifier), populated on LEI-scheme rows. BIC and SEC CIK are identifier schemes here since W1 (CW-902). W1 re-point: the owning party is the Identified Party reference. PII tier: identity.'),
            dict(name='Party Relationship',
                 role='Entity',
                 objects=[('02', 'Party Relationship')],
                 pk=['From Party', 'To Party', 'Relationship Type', 'Relationship Effective From'],
                 grain='one row = from party x to party x relationship type x effective period',
                 note='PII tier: identity (family and control relationships of individuals).'),
            dict(name='Beneficial Ownership Certification',
                 role='Entity',
                 objects=[('02', 'Beneficial Ownership Certification')],
                 pk=['Beneficial Ownership Certification ID'],
                 grain='one row = legal entity customer x certification (BOWN-)',
                 note='W1 (CW-902): the certification is the parent of the owner rows in the wealth 02 (31 CFR 1010.230); the certified entity is its Certified Entity reference. PII tier: identity.'),
            dict(name='Beneficial Ownership',
                 role='Entity',
                 objects=[('02', 'Beneficial Ownership')],
                 pk=['Ownership Certification', 'Beneficial Owner', 'Ownership Prong'],
                 grain='one row = beneficial ownership certification x beneficial owner x prong',
                 note="W1 re-point (CW-902): Control Person Indicator is Ownership Prong = Control; the row hangs from its certification instead of borrowing the owned party's key. PII tier: identity."),
            dict(name='Internal Legal Entity',
                 role='Entity',
                 conformed=('DP-013', 'Internal Legal Entity'),
                 objects=[('09', 'Internal Legal Entity')],
                 note="Conformed from DP-013; read so each of the firm's own legal entities can be checked against its mirror Party (Own Entity Mirror Coverage %)."),
            dict(name='Household Membership',
                 role='Entity',
                 objects=[('02', 'Household Membership')],
                 pk=['Household', 'Household Member', 'Membership Effective From']),
            dict(name='Authority Grant',
                 role='Entity',
                 objects=[('02', 'Authority Grant')],
                 pk=['Authority Grant ID']),
            dict(name='Trusted Contact Designation',
                 role='Entity',
                 objects=[('02', 'Trusted Contact Designation')],
                 pk=['Trusted Contact Designation ID']),
            dict(name='Death Notification',
                 role='Entity',
                 objects=[('02', 'Death Notification')],
                 pk=['Death Notification ID']),
            dict(name='Investor Profile',
                 role='Entity',
                 objects=[('02', 'Investor Profile')],
                 pk=['Investor Profile ID']),
            dict(name='Investment Experience',
                 role='Entity',
                 objects=[('02', 'Investment Experience')],
                 pk=['Experience Profile', 'Product Experience Type']),
            dict(name='Investor Qualification',
                 role='Entity',
                 objects=[('02', 'Investor Qualification')],
                 pk=['Qualification Standard', 'Qualified Party']),
            dict(name='Identity Verification',
                 role='Entity',
                 objects=[('02', 'Identity Verification')],
                 pk=['Identity Verification ID']),
            dict(name='Regulatory Classification',
                 role='Entity',
                 objects=[('02', 'Regulatory Classification')],
                 pk=['Classified Party', 'Categorization Date']),
            dict(name='Segment Assignment',
                 role='Entity',
                 objects=[('02', 'Segment Assignment')],
                 pk=['Segmented Party', 'Segmentation Scheme', 'Segment Effective From']),
            dict(name='Service Tier Assignment',
                 role='Entity',
                 objects=[('02', 'Service Tier Assignment')],
                 pk=['Tier Party', 'Assigned Service Tier', 'Tier Effective From']),
            dict(name='Contact Point',
                 role='Entity',
                 objects=[('02', 'Contact Point'), ('02', 'Postal Address')],
                 pk=['Contact Point ID']),
            dict(name='Consent Record',
                 role='Entity',
                 objects=[('02', 'Consent Record')],
                 pk=['Consent Record ID']),
            dict(name='Client Restriction',
                 role='Entity',
                 objects=[('02', 'Client Restriction')],
                 pk=['Client Restriction ID']),
        ],
        relationships=[
            dict(child='Party', parent='Party', fk=['Merged Into Party'], card='M:1', optional=True, note='Survivor of a merge of duplicate party records.'),
            dict(child='Legal Entity Hierarchy', parent='Party', fk=['Subsidiary Party'], card='M:1'),
            dict(child='Legal Entity Hierarchy', parent='Party', fk=['Direct Parent'], card='M:1', note='Legal-entity ownership tree.'),
            dict(child='Legal Entity Hierarchy', parent='Party', fk=['Ultimate Parent'], card='M:1', optional=True),
            dict(child='Party Role', parent='Party', fk=['Role Party'], card='M:1'),
            dict(child='Party Identifier', parent='Party', fk=['Identified Party'], card='M:1'),
            dict(child='Party Relationship', parent='Party', fk=['From Party'], card='M:1'),
            dict(child='Party Relationship', parent='Party', fk=['To Party'], card='M:1'),
            dict(child='Beneficial Ownership Certification', parent='Party', fk=['Certified Entity'], card='M:1', note='The legal entity customer whose owners are certified.'),
            dict(child='Beneficial Ownership', parent='Beneficial Ownership Certification', fk=['Ownership Certification'], card='M:1'),
            dict(child='Beneficial Ownership', parent='Party', fk=['Beneficial Owner'], card='M:1'),
            dict(child='Internal Legal Entity', parent='Party', fk=['Party Master Cross-Reference'], card='1:1', optional=True, note="The firm's own legal entity mirrored as a party (for intercompany counterparties and issuers of own debt)."),
            dict(child='Party', parent='Party', fk=['Primary Member'], card='M:1', optional=True),
            dict(child='Household Membership', parent='Party', fk=['Household'], card='M:1'),
            dict(child='Household Membership', parent='Party', fk=['Household Member'], card='M:1'),
            dict(child='Authority Grant', parent='Party', fk=['Grantor Party'], card='M:1', optional=True),
            dict(child='Authority Grant', parent='Party', fk=['Authority Holder'], card='M:1', optional=True),
            dict(child='Trusted Contact Designation', parent='Party', fk=['Designating Client'], card='M:1', optional=True),
            dict(child='Trusted Contact Designation', parent='Party', fk=['Trusted Contact Person'], card='M:1', optional=True),
            dict(child='Death Notification', parent='Party', fk=['Deceased Party'], card='M:1', optional=True),
            dict(child='Investor Profile', parent='Party', fk=['Profile Client'], card='M:1', optional=True),
            dict(child='Investment Experience', parent='Investor Profile', fk=['Experience Profile'], card='M:1'),
            dict(child='Investor Qualification', parent='Party', fk=['Qualified Party'], card='M:1'),
            dict(child='Identity Verification', parent='Party', fk=['Verified Party'], card='M:1', optional=True),
            dict(child='Regulatory Classification', parent='Party', fk=['Classified Party'], card='M:1'),
            dict(child='Segment Assignment', parent='Party', fk=['Segmented Party'], card='M:1'),
            dict(child='Service Tier Assignment', parent='Party', fk=['Tier Party'], card='M:1'),
            dict(child='Contact Point', parent='Party', fk=['Contact Point Party'], card='M:1', optional=True),
            dict(child='Consent Record', parent='Party', fk=['Consenting Party'], card='M:1', optional=True),
            dict(child='Client Restriction', parent='Party', fk=['Restricted Party'], card='M:1', optional=True),
        ],
        notes="Foundational master, modeled ER around one Party entity keyed by Party ID that holds organizations and individuals with their one-row-per-party profile groups, and children for the legal hierarchy, roles, identifiers, party-to-party relationships and beneficial ownership certifications with their owners. This is the enterprise successor to the distribution-scoped Party of DP-001; consumers conform ('DP-240', 'Party'). W1 re-point (CW-902, CW-021): the wealth 02 gives Party Role, Party Identifier and Legal Entity Hierarchy their own party references (Role Party, Identified Party, Subsidiary Party), so the borrowed Party Key and the earlier model gap are gone; Legal Entity Hierarchy becomes its own entity; UK & EU Regulatory Identifier is removed (BIC survives as a Party Identifier scheme); Beneficial Ownership hangs from the new Beneficial Ownership Certification. External references (not linked here): Organization.Legal Jurisdiction, Industry Classification and Party.Primary Country are codes resolved through DP-013. WP1 re-point (CW-204): re-cut to the Client, Household & Party Master. The Party entity (52 conformers, 51 live) keeps Party ID and loses 02 Market Infrastructure & Vendor Identifier (now published by DP-001); it gains the folded 02 Household, KYC Profile, Tax Profile and Privacy Profile groups. The new client objects (Household Membership, Authority Grant, Trusted Contact Designation, Death Notification, Investor Profile and Investment Experience, Investor Qualification, Identity Verification, Regulatory Classification, Segment Assignment, Service Tier Assignment, Contact Point with Postal Address, Consent Record, Client Restriction) are entities keyed by the registry and linked to Party by their 02 party references; Legal Entity Hierarchy, Party Role, Party Identifier and Party Relationship keep their objects and keys (SM-00 bridges). The household is a Party with Party Type Household (household dimension stays here). The DP-002 conformers of Contact Point and Household re-point here. WP1 lineage addition (CW-264, C-4): Trusted Contact Designation adds Account Scope (read by DP-583).",
    ),
}
