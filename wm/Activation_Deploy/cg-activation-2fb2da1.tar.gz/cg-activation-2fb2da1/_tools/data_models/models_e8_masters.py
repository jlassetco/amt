"""Logical data models, Wave E8 group "masters": ER models for the foundational masters of the investment and corporate
functions. DP-115 Approved Broker & Counterparty Master, DP-116 Investor Capital Accounts, DP-117 Private Fund Capital
Calls & Distributions, DP-190 Chart of Accounts & Ledger, DP-191 General Ledger Journals & Balances, DP-192 Employee &
Position Master, DP-210 Vendor Master, DP-211 Application & System Inventory, DP-212 Model Inventory & Validation and
DP-213 Enterprise Contract Register. See CONTRACT.md.

Conformed entities published here for other models: Counterparty (DP-115); Alternative Investment Subscription (DP-116,
W4 residual; the 30 entities and DP-117's call and distribution entities left with CW-930); GL Account, Cost Center, Ledger,
Chart of Accounts, Financial Statement Line (DP-190); Employee, Workforce Position, Job Profile, Employee Reporting Line,
Org Unit Assignment (DP-192); Vendor, Supplier Engagement (DP-210); Application, IT Service, Configuration Item (DP-211);
Model (DP-212); Contract (DP-213).
"""

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-115": dict(
        style="ER",
        entities=[
            dict(name="Counterparty", role="Entity", conformed=("DP-240", "Party"),
                 objects=[("25", "Approved Counterparty Profile"), ("02", "Party"), ("02", "Organization"),
                          ("02", "LEI Record"), ("02", "Legal Entity Hierarchy")],
                 pk=["Party ID"], measures=True,
                 grain="one row = counterparty party (02 PTY-) with an approved counterparty profile x effective period",
                 note="The conformed Counterparty and Broker dimension (CD-315). Party identity, LEI and legal parents are "
                      "conformed from DP-240 Party and never copied; the 25 Approved Counterparty Profile is a 1:1 role "
                      "profile keyed by the Party ID (registry), so it is held here and Counterparty Party repeats the "
                      "Party ID. Organization, LEI Record and Legal Entity Hierarchy are read one row per party and fold here "
                      "(the hierarchy is a business object in the wealth 02 but only the current parents are read); "
                      "LEI Record's parent (Party Identifier) is not an input, so the current LEI is a column. Holds the "
                      "product measures because approval, review, LEI and parent-group measures are all per counterparty."),
            dict(name="Counterparty Party Role", role="Entity", objects=[("02", "Party Role")],
                 pk=["Role Party", "Role Type", "Role Effective From"],
                 grain="one row = counterparty x role type x role effective period",
                 note="W1 re-point (CW-902): keyed by its own Role Party reference, so the borrowed Counterparty Key is "
                      "gone. "
                      "These are the broker and counterparty role rows of the DP-240 party roles; 02 Party Role has no "
                      "link to the 25 profile, so the trading role is matched by party and role type (spec taxonomy gap)."),
            dict(name="Counterparty Approval Scope", role="Entity", objects=[("25", "Counterparty Approval Scope")],
                 pk=["Scope Counterparty", "Approved Activity", "Scope Trading Entity", "Scope Fund", "Scope Effective From"],
                 grain="one row = counterparty x approved activity x trading entity x fund (optional) x effective period",
                 note="The product grain. Scope Fund is empty for an entity-wide approval; the registry keeps it in the "
                      "key with that meaning. Governing Trading Agreement links the scope to the agreement it requires."),
            dict(name="Counterparty Trading Limit", role="Entity", objects=[("25", "Counterparty Trading Limit")],
                 pk=["Limit Counterparty", "Limit Type", "Limit Trading Entity", "Limit Fund", "Limit Effective From"],
                 grain="one row = counterparty x limit type x trading entity x fund (optional) x effective period",
                 note="Limit Amount carries its own currency; no FX conversion here, so parent-group sums are per "
                      "currency. Utilization and exceedance are 31's (CD-215)."),
            dict(name="Counterparty Review", role="Entity", objects=[("25", "Counterparty Review")],
                 pk=["Reviewed Counterparty", "Counterparty Review Date"],
                 grain="one row = counterparty x review date",
                 note="Credit View is the key of the 23 internal credit assessment, carried as a key only so the product "
                      "stays foundational."),
            dict(name="Issuer", role="Entity", conformed=("DP-098", "Issuer"), objects=[("17", "Issuer Profile")],
                 pk=["Issuer Party"],
                 grain="one row = issuer party (17 issuer profile keyed by 02 PTY-)",
                 note="Conformed from DP-098 for counterparties that also issue (Country of Risk). The issuer profile is "
                      "a 1:1 extension of the party, so it joins the counterparty 1:1 on the Party ID."),
            dict(name="Issuer Credit Rating", role="Entity", objects=[("17", "Credit Rating Assignment")],
                 pk=["Rated Issuer", "Credit Rating Agency", "Credit Rating Type", "Credit Rating Action Date"],
                 grain="one row = rated issuer x credit rating agency x rating type x action date",
                 note="Only issuer ratings are read (Rated Instrument is not a product input and is empty on issuer "
                      "ratings), so the registry key is used without Rated Instrument. DP-098 masters the ratings; this "
                      "entity is the issuer-rating slice it reads for Issuer Counterparties Without Agency Rating."),
            dict(name="Trading Agreement", role="Entity", conformed=("DP-147", "Trading Agreement"),
                 objects=[("26", "Trading Agreement")], pk=["Trading Agreement ID"],
                 grain="one row = trading agreement (ISDA, GMRA, prime brokerage, give-up, terms of business)",
                 note="Conformed from DP-147, the owner of agreement status (CD-321). DP-147 keys the counterparty as the "
                      "02 party and never lists this product."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"),
                 objects=[("09", "Internal Legal Entity")],
                 note="Conformed from DP-013: the firm trading entity an approval or limit applies to and the firm "
                      "contracting entity of an agreement."),
            dict(name="Investment Product", role="Entity", conformed=("DP-004", "Investment Product"), objects=[],
                 note="Conformed from DP-004: the fund an approval scope, limit or agreement is restricted to."),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[("20", "Employee")],
                 note="Conformed from DP-192 for the counterparty reviewer; Employment Status tests reviewer departures."),
        ],
        relationships=[
            dict(child="Counterparty", parent="Counterparty", fk=["Merged Into Party"], card="M:1", optional=True,
                 note="Survivor of a merge of duplicate party records; a survivor that is not an approved counterparty "
                      "resolves to DP-240 Party."),
            dict(child="Counterparty", parent="Counterparty", fk=["Direct Parent"], card="M:1", optional=True,
                 note="Legal parent; parents that are not approved counterparties resolve to DP-240 Party."),
            dict(child="Counterparty", parent="Counterparty", fk=["Ultimate Parent"], card="M:1", optional=True,
                 note="Parent group used by Approved Limit by Parent Group."),
            dict(child="Counterparty Party Role", parent="Counterparty", fk=["Role Party"], card="M:1"),
            dict(child="Counterparty Approval Scope", parent="Counterparty", fk=["Scope Counterparty"], card="M:1"),
            dict(child="Counterparty Approval Scope", parent="Internal Legal Entity", fk=["Scope Trading Entity"],
                 card="M:1"),
            dict(child="Counterparty Approval Scope", parent="Investment Product", fk=["Scope Fund"], card="M:1",
                 optional=True, note="Empty for an entity-wide approval."),
            dict(child="Counterparty Approval Scope", parent="Trading Agreement", fk=["Governing Trading Agreement"],
                 card="M:1", optional=True,
                 note="Required where Trading Agreement Required Indicator is set (Scopes Missing Required Agreement)."),
            dict(child="Counterparty Trading Limit", parent="Counterparty", fk=["Limit Counterparty"], card="M:1"),
            dict(child="Counterparty Trading Limit", parent="Internal Legal Entity", fk=["Limit Trading Entity"],
                 card="M:1", optional=True),
            dict(child="Counterparty Trading Limit", parent="Investment Product", fk=["Limit Fund"], card="M:1",
                 optional=True),
            dict(child="Counterparty Review", parent="Counterparty", fk=["Reviewed Counterparty"], card="M:1"),
            dict(child="Counterparty Review", parent="Employee", fk=["Counterparty Reviewer"], card="M:1", optional=True),
            dict(child="Issuer", parent="Counterparty", fk=["Issuer Party"], card="1:1", optional=True,
                 note="Only counterparties that also issue securities have an issuer profile."),
            dict(child="Issuer Credit Rating", parent="Counterparty", fk=["Rated Issuer"], card="M:1",
                 note="Rated Issuer carries the 02 Party ID, so issuer ratings join the counterparty directly."),
            dict(child="Trading Agreement", parent="Counterparty", fk=["Agreement Counterparty"], card="M:1"),
            dict(child="Trading Agreement", parent="Investment Product", fk=["Fund Party"], card="M:1"),
            dict(child="Trading Agreement", parent="Internal Legal Entity", fk=["Firm Contracting Entity"], card="M:1",
                 optional=True),
        ],
        notes=("Foundational master, modeled ER around one Counterparty entity: the DP-240 party core (conformed, never "
               "copied) extended with the 25 approved counterparty profile, with the approval scopes (the product grain), "
               "trading limits and periodic reviews as children, and the trading agreements of DP-147, the issuer profile "
               "and issuer ratings of DP-098, the firm trading entities and funds and the reviewer as parents. "
               "External references (resolved by joining to the named product, not linked here): Counterparty "
               "Review.Credit View to 23 Internal Credit Assessment (carried as a key only, so the product stays "
               "foundational); Organization.Legal Jurisdiction and Party.Primary Country to Country (DP-013, code values). "
               "Validation warnings expected in the per-module check: DP-240 Party, DP-098 Issuer and DP-147 Trading "
               "Agreement are other Wave E8 groups' models and are not loaded, so their attributes are not inherited "
               "there; the pk of each is set explicitly so the model holds once they load. "
               "Model gap: 25 Counterparty Trading Limit has no limit approver or approval date (spec taxonomy gap), so "
               "limit approval is not modeled."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-116 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-117 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ------------------------------------------------------------------------------------------------------------------
    "DP-190": dict(
        style="ER",
        entities=[
            dict(name="Chart of Accounts", role="Entity", objects=[("19", "Chart of Accounts")],
                 pk=["Chart of Accounts Code"],
                 grain="one row = chart of accounts",
                 note="Chart Segment Structure is free text; DP-191 reads the segment order from it to parse Balance "
                      "Segment Combination (spec taxonomy gap)."),
            dict(name="GL Account", role="Entity", objects=[("19", "GL Account")], pk=["GL Account ID"], measures=True,
                 grain="one row = chart of accounts x natural account (GLA-) x effective period",
                 note="The conformed GL Account dimension (CD-296). The enterprise ID stands for chart x natural account "
                      "and is what every posting, balance and mapping carries. Holds the product measures because most "
                      "are counts of accounts, segment values, ledgers or periods published with the chart."),
            dict(name="Cost Center", role="Entity", objects=[("19", "Chart Segment Value")],
                 pk=["Segment Value Chart", "Chart Segment", "Segment Value Code", "Segment Value Effective From"],
                 grain="one row = chart of accounts x chart segment x segment value x effective period",
                 note="The conformed Cost Center dimension, named for its main use (CD-296). Rows are every 19 chart "
                      "segment value: Chart Segment = cost center gives the cost centers, and the company, profit center, "
                      "product, channel and intercompany segments share the same structure and key. Represented Org "
                      "Unit, Legal Entity and Product say what each value stands for. References elsewhere carry the "
                      "bare Segment Value Code; they join within the chart and the segment the referencing attribute "
                      "implies (registry)."),
            dict(name="Ledger", role="Entity", objects=[("19", "Ledger")], pk=["Ledger ID"],
                 grain="one row = legal entity x accounting basis x ledger currency x ledger role (LDG-)",
                 note="The conformed Ledger dimension; Entities Without One Primary Ledger tests Ledger Role per entity."),
            dict(name="Financial Statement Line", role="Entity", objects=[("19", "Financial Statement Line")],
                 pk=["Statement Line Code"],
                 grain="one row = reporting framework x statement line",
                 note="The firm line code is unique across frameworks (registry)."),
            dict(name="Financial Statement Line Mapping", role="Entity",
                 objects=[("19", "Financial Statement Line Mapping")],
                 pk=["Mapped GL Account", "Mapped Statement Line", "Line Mapping Effective From"],
                 grain="one row = GL account x statement line x effective period",
                 note="Associative entity through which DP-191's certified P&L is presented."),
            dict(name="Accounting Period Status", role="Entity", objects=[("19", "Accounting Period Status")],
                 pk=["Status Ledger", "Status Fiscal Period"],
                 grain="one row = ledger x fiscal period",
                 note="Close state per ledger and period; Period Closed By is deliberately not read, so the product "
                      "carries no personal data."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"),
                 objects=[("09", "Internal Legal Entity")],
                 note="Conformed from DP-013. Accounting Company Code is a derived copy of the company segment value, "
                      "read only for Company Code Mismatches (CONTRACT.md rule 2 exception)."),
            dict(name="Org Unit", role="Entity", conformed=("DP-013", "Org Unit"),
                 objects=[("09", "Org Unit"), ("09", "Cost & Profit Center")],
                 note="Conformed from DP-013. The folded 09 Cost & Profit Center codes are derived copies of the 19 "
                      "segment values, read only to test them against the master (cost center rule)."),
            dict(name="Fiscal Period", role="Entity", conformed=("DP-013", "Fiscal Period"),
                 objects=[("09", "Fiscal Period")],
                 note="Conformed from DP-013, which keeps the fiscal calendar."),
            dict(name="Calendar", role="Entity", conformed=("DP-013", "Calendar"), objects=[],
                 note="Conformed from DP-013: the fiscal calendar a ledger follows."),
            dict(name="Investment Product", role="Entity", conformed=("DP-004", "Investment Product"), objects=[],
                 note="Conformed from DP-004: the product a product segment value represents."),
        ],
        relationships=[
            dict(child="GL Account", parent="Chart of Accounts", fk=["GL Account Chart"], card="M:1"),
            dict(child="GL Account", parent="GL Account", fk=["Parent Summary Account"], card="M:1", optional=True,
                 note="Summary account roll-up."),
            dict(child="Cost Center", parent="Chart of Accounts", fk=["Segment Value Chart"], card="M:1"),
            dict(child="Cost Center", parent="Cost Center", fk=["Parent Segment Value"], card="M:1", optional=True,
                 note="Segment value hierarchy; the parent code joins within the same chart and segment."),
            dict(child="Cost Center", parent="Org Unit", fk=["Represented Org Unit"], card="M:1", optional=True,
                 note="Cost Centers Without Org Unit counts cost center values where this is empty."),
            dict(child="Cost Center", parent="Internal Legal Entity", fk=["Represented Legal Entity"], card="M:1",
                 optional=True, note="Company segment values."),
            dict(child="Cost Center", parent="Investment Product", fk=["Represented Product"], card="M:1",
                 optional=True, note="Product segment values."),
            dict(child="Org Unit", parent="Cost Center", fk=["Cost Center Code"], card="M:1", optional=True,
                 note="The 09 copy of the org unit's cost center; joins on the code within the cost center segment and "
                      "is tested against Represented Org Unit."),
            dict(child="Ledger", parent="Internal Legal Entity", fk=["Ledger Legal Entity"], card="M:1"),
            dict(child="Ledger", parent="Chart of Accounts", fk=["Ledger Chart of Accounts"], card="M:1", optional=True),
            dict(child="Ledger", parent="Calendar", fk=["Ledger Fiscal Calendar"], card="M:1", optional=True),
            dict(child="Ledger", parent="Ledger", fk=["Source Ledger"], card="M:1", optional=True,
                 note="Secondary and reporting ledgers derived from a primary ledger."),
            dict(child="Financial Statement Line Mapping", parent="GL Account", fk=["Mapped GL Account"], card="M:1"),
            dict(child="Financial Statement Line Mapping", parent="Financial Statement Line",
                 fk=["Mapped Statement Line"], card="M:1"),
            dict(child="Accounting Period Status", parent="Ledger", fk=["Status Ledger"], card="M:1"),
            dict(child="Accounting Period Status", parent="Fiscal Period", fk=["Status Fiscal Period"], card="M:1",
                 note="Status Fiscal Period is a code that carries the Fiscal Period ID (no registry reference)."),
        ],
        notes=("Foundational master, modeled ER: the chart of accounts with its GL accounts and segment values, the ledgers "
               "that use the chart, the financial statement lines and their GL mapping, and the close state of each "
               "ledger period. Publishes the conformed GL Account, Cost Center and Ledger dimensions (CD-296) and the "
               "Chart of Accounts and Financial Statement Line entities DP-191 conforms. Legal entity, org unit, fiscal "
               "period and calendar are conformed from DP-013 and never repeated; the 09 company and cost center codes "
               "are read only to test the copies (CONTRACT.md rule 2 exception). Fund ledgers are 27 and out of scope. "
               "Model gap: the Cost Center entity holds every chart segment, not only cost centers, because 19 has one "
               "Chart Segment Value object; a consumer conforming Cost Center filters Chart Segment = cost center."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-191": dict(
        style="ER",
        entities=[
            dict(name="Journal Entry", role="Entity", objects=[("19", "Journal Entry")], pk=["Journal ID"],
                 grain="one row = journal entry (JNL-)",
                 note="Journal Prepared By and Journal Approved By are employee keys used only for the segregation of "
                      "duties checks; the wide BI view drops both."),
            dict(name="GL Posting", role="Entity", objects=[("19", "GL Posting")], pk=["Journal ID", "Journal Line Number"],
                 grain="one row = journal entry x journal line",
                 note="The detail posting. Payroll posts in summary per run, so there is no employee-level cost."),
            dict(name="GL Account Balance", role="Entity", objects=[("19", "GL Account Balance")],
                 pk=["Balance Ledger", "Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period",
                     "Balance Type", "Balance Currency"], measures=True,
                 grain="one row = ledger x account combination x fiscal period x balance type x balance currency",
                 note="The product grain and the source of the certified P&L and operating expense family (CD-340): "
                      "primary ledgers, Actual balances, hard-closed periods. The cost center sits only inside Balance "
                      "Segment Combination and is parsed in the segment order of the chart (spec taxonomy gap); period "
                      "activity is Closing - Opening. Holds the product measures."),
            dict(name="Accounting Period Status", role="Entity", conformed=("DP-190", "Accounting Period Status"),
                 objects=[("19", "Accounting Period Status")],
                 note="Conformed from DP-190; Hard Close Date drives Postings After Hard Close and the certified period "
                      "filter."),
            dict(name="GL Account", role="Entity", conformed=("DP-190", "GL Account"), objects=[("19", "GL Account")],
                 note="Conformed from DP-190; Normal Balance checks the debit-positive sign assumption."),
            dict(name="Financial Statement Line Mapping", role="Entity",
                 conformed=("DP-190", "Financial Statement Line Mapping"),
                 objects=[("19", "Financial Statement Line Mapping")],
                 note="Conformed from DP-190; the mapping through which revenue, expense and operating income are "
                      "certified, and Unmapped Activity is found."),
            dict(name="Financial Statement Line", role="Entity", conformed=("DP-190", "Financial Statement Line"),
                 objects=[], note="Conformed from DP-190 so mapped balances reach their statement line."),
            dict(name="Ledger", role="Entity", conformed=("DP-190", "Ledger"), objects=[("19", "Ledger")],
                 note="Conformed from DP-190; Ledger Role selects the primary ledgers for the certified numbers."),
            dict(name="Chart of Accounts", role="Entity", conformed=("DP-190", "Chart of Accounts"),
                 objects=[("19", "Chart of Accounts")],
                 note="Conformed from DP-190; Chart Segment Structure gives the segment order for parsing."),
            dict(name="Cost Center", role="Entity", conformed=("DP-190", "Cost Center"), objects=[],
                 note="Conformed from DP-190: the cost center segment value of each posting."),
            dict(name="Fiscal Period", role="Entity", conformed=("DP-013", "Fiscal Period"),
                 objects=[("09", "Fiscal Period")], note="Conformed from DP-013."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"), objects=[],
                 note="Conformed from DP-013: the posting entity, intercompany partner and ledger entity."),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[],
                 note="Conformed from DP-192 for the journal preparer and approver (Self-Approved Manual Journals)."),
        ],
        relationships=[
            dict(child="Journal Entry", parent="Ledger", fk=["Journal Ledger"], card="M:1"),
            dict(child="Journal Entry", parent="Fiscal Period", fk=["Posting Accounting Period"], card="M:1",
                 note="A code carrying the Fiscal Period ID (no registry reference)."),
            dict(child="Journal Entry", parent="Internal Legal Entity", fk=["Posting Legal Entity"], card="M:1",
                 optional=True),
            dict(child="Journal Entry", parent="Employee", fk=["Journal Prepared By"], card="M:1", optional=True),
            dict(child="Journal Entry", parent="Employee", fk=["Journal Approved By"], card="M:1", optional=True),
            dict(child="Journal Entry", parent="Journal Entry", fk=["Reversed Journal"], card="M:1", optional=True),
            dict(child="GL Posting", parent="Journal Entry", fk=["Journal ID"], card="M:1"),
            dict(child="GL Posting", parent="GL Account", fk=["Posted Account"], card="M:1"),
            dict(child="GL Posting", parent="Cost Center", fk=["Cost Center Segment Value"], card="M:1", optional=True,
                 note="Carries the bare segment value code; joins within the ledger's chart and the cost center segment."),
            dict(child="GL Posting", parent="Internal Legal Entity", fk=["Intercompany Partner Entity"], card="M:1",
                 optional=True),
            dict(child="GL Account Balance", parent="Ledger", fk=["Balance Ledger"], card="M:1"),
            dict(child="GL Account Balance", parent="GL Account", fk=["Balance GL Account"], card="M:1"),
            dict(child="GL Account Balance", parent="Fiscal Period", fk=["Balance Fiscal Period"], card="M:1",
                 note="A code carrying the Fiscal Period ID."),
            dict(child="Accounting Period Status", parent="Ledger", fk=["Status Ledger"], card="M:1"),
            dict(child="Accounting Period Status", parent="Fiscal Period", fk=["Status Fiscal Period"], card="M:1"),
            dict(child="Financial Statement Line Mapping", parent="GL Account", fk=["Mapped GL Account"], card="M:1"),
            dict(child="Financial Statement Line Mapping", parent="Financial Statement Line",
                 fk=["Mapped Statement Line"], card="M:1"),
            dict(child="Ledger", parent="Internal Legal Entity", fk=["Ledger Legal Entity"], card="M:1"),
            dict(child="GL Account", parent="Chart of Accounts", fk=["GL Account Chart"], card="M:1",
                 note="GL Account Chart is inherited from the DP-190 GL Account."),
        ],
        notes=("Foundational, modeled ER: journal entries and their posting lines as the detail, GL account balances as "
               "the certified grain, and the chart, ledger, mapping and period status conformed from DP-190 so the "
               "certified P&L uses the master's accounts and close state. The certified numbers (CD-293, CD-340) are "
               "read from GL Account Balance; DP-056, DP-035, DP-057 and DP-194 take expense by cost center from here. "
               "External references (carried as keys, not linked here): GL Posting.Source Finance Record to the 10 "
               "finance records; Source Payable Invoice, Source Supplier Payment and Source Receivable Item to the 19 "
               "subledger objects (not inputs); Source Payroll Run to 20 Payroll Run (DP-198); Other Segment Values "
               "(multi) to the DP-190 segment values. "
               "Model gap: GL Account Balance has no cost center attribute (only the Balance Segment Combination text), "
               "so balances have no relationship to Cost Center; expense by cost center is parsed from the combination."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-192": dict(
        style="ER",
        entities=[
            dict(name="Employee", role="Entity",
                 objects=[("20", "Employee"), ("20", "Employee Personal Detail"), ("20", "Contingent Worker Detail")],
                 pk=["Employee ID"], measures=True,
                 grain="one row = worker (EMP-) x effective period (SCD type 2)",
                 note="The conformed Employee dimension (CD-342). It publishes every 20 Employee attribute DP-009 reads "
                      "(Employee ID, Preferred Name, Legal Last Name, Business Email Address, Job Title, Employing Legal "
                      "Entity, Home Org Unit, Work Location, Employment Status, Hire Date, Termination Date). Employee "
                      "Personal Detail (country of residence, national identifier, work authorization) and Contingent "
                      "Worker Detail (current engagement) are one row per worker and fold here; the personal detail "
                      "columns are a Restricted - Personal Data extension (CD-344). Holds the product measures: "
                      "headcount, FTE and workforce events are counted per worker."),
            dict(name="Employee Reporting Line", role="Entity", objects=[("20", "Employee Reporting Line")],
                 pk=["Reporting Employee", "Line Manager", "Reporting Line Type", "Reporting Effective From"],
                 grain="one row = reporting employee x line manager x reporting line type x effective period",
                 note="Published with every attribute DP-009 reads; DP-009 conforms it from here."),
            dict(name="Job Profile", role="Entity", objects=[("20", "Job Profile")], pk=["Job Profile ID"],
                 grain="one row = job profile (JOB-)"),
            dict(name="Workforce Position", role="Entity", objects=[("20", "Workforce Position")],
                 pk=["Workforce Position ID"],
                 grain="one row = workforce position (WFP-) x effective period",
                 note="The conformed Workforce Position. Keyed on the ID per the registry; where position history is "
                      "published the key becomes Workforce Position ID + Position Effective From."),
            dict(name="Employee Job Assignment", role="Entity", objects=[("20", "Employee Job Assignment")],
                 pk=["Assigned Worker", "Assigned Workforce Position", "Assigned Job Profile", "Assignment Type",
                     "Assignment Effective From"],
                 grain="one row = worker x position or job profile x assignment type x effective period",
                 note="Assignment FTE is the FTE as recorded (no standard weekly hours to recompute it). The position is "
                      "empty where position management is not used, so both references sit in the key."),
            dict(name="Org Unit Assignment", role="Entity", objects=[("20", "Org Unit Assignment")],
                 pk=["Assigned Employee", "Assigned Org Unit", "Assignment Effective From / To"],
                 grain="one row = employee x org unit x effective period",
                 note="Published with every attribute DP-009 reads. The effective period is one text attribute; the key "
                      "uses it as delivered."),
            dict(name="Employee Lifecycle Event", role="Entity", objects=[("20", "Employee Lifecycle Event")],
                 pk=["Lifecycle Event ID"],
                 grain="one row = lifecycle event (ELE-): hire, transfer, promotion, leave, termination",
                 note="Joiners, movers and leavers and the regulatory notification flag are counted from these rows."),
            dict(name="Org Unit", role="Entity", conformed=("DP-013", "Org Unit"), objects=[("09", "Org Unit")],
                 note="Conformed from DP-013."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"),
                 objects=[("09", "Internal Legal Entity")], note="Conformed from DP-013."),
            dict(name="Office Location", role="Entity", conformed=("DP-013", "Office Location"),
                 objects=[("09", "Office Location")], note="Conformed from DP-013: work location and position location."),
            dict(name="Fiscal Period", role="Entity", conformed=("DP-013", "Fiscal Period"),
                 objects=[("09", "Fiscal Period")],
                 note="Conformed from DP-013: the period end at which certified headcount and FTE are measured."),
            dict(name="Cost Center", role="Entity", conformed=("DP-190", "Cost Center"),
                 objects=[("19", "Chart Segment Value")],
                 note="Conformed from DP-190: the cost center a position is budgeted in."),
        ],
        relationships=[
            dict(child="Employee", parent="Internal Legal Entity", fk=["Employing Legal Entity"], card="M:1"),
            dict(child="Employee", parent="Org Unit", fk=["Home Org Unit"], card="M:1", optional=True),
            dict(child="Employee", parent="Office Location", fk=["Work Location"], card="M:1", optional=True),
            dict(child="Employee", parent="Internal Legal Entity", fk=["Secondment Home Entity"], card="M:1",
                 optional=True, note="Secondees only (Contingent Worker Detail)."),
            dict(child="Employee Reporting Line", parent="Employee", fk=["Reporting Employee"], card="M:1"),
            dict(child="Employee Reporting Line", parent="Employee", fk=["Line Manager"], card="M:1"),
            dict(child="Workforce Position", parent="Job Profile", fk=["Position Job Profile"], card="M:1"),
            dict(child="Workforce Position", parent="Org Unit", fk=["Position Org Unit"], card="M:1"),
            dict(child="Workforce Position", parent="Internal Legal Entity", fk=["Position Legal Entity"], card="M:1"),
            dict(child="Workforce Position", parent="Office Location", fk=["Position Location"], card="M:1",
                 optional=True),
            dict(child="Workforce Position", parent="Cost Center", fk=["Position Cost Center"], card="M:1",
                 optional=True, note="Carries the bare cost center code; joins within the cost center segment."),
            dict(child="Employee Job Assignment", parent="Employee", fk=["Assigned Worker"], card="M:1"),
            dict(child="Employee Job Assignment", parent="Workforce Position", fk=["Assigned Workforce Position"],
                 card="M:1", optional=True),
            dict(child="Employee Job Assignment", parent="Job Profile", fk=["Assigned Job Profile"], card="M:1",
                 optional=True),
            dict(child="Org Unit Assignment", parent="Employee", fk=["Assigned Employee"], card="M:1"),
            dict(child="Org Unit Assignment", parent="Org Unit", fk=["Assigned Org Unit"], card="M:1"),
            dict(child="Employee Lifecycle Event", parent="Employee", fk=["Event Employee"], card="M:1"),
            dict(child="Employee Lifecycle Event", parent="Fiscal Period", fk=["Fiscal Period Key"], card="M:1",
                 note="Model gap: no attribute carries the period; Fiscal Period Key is derived by placing Event "
                      "Effective Date within the period's start and end dates."),
            dict(child="Org Unit", parent="Internal Legal Entity", fk=["Employing / Booking Entity"], card="M:1"),
            dict(child="Office Location", parent="Internal Legal Entity", fk=["Office Legal Entity"], card="M:1",
                 optional=True),
            dict(child="Cost Center", parent="Org Unit", fk=["Represented Org Unit"], card="M:1", optional=True),
        ],
        notes=("Foundational master, modeled ER around one Employee entity keyed by Employee ID that folds the personal "
               "detail and current contingent engagement, with job profiles and workforce positions, effective-dated "
               "job assignments, reporting lines, org unit assignments and lifecycle events. Publishes the conformed "
               "Employee and Workforce Position (CD-342); DP-009 will conform Employee, Employee Reporting Line and Org "
               "Unit Assignment from here, and every attribute it reads is published. Org unit, legal entity, office and "
               "fiscal period are conformed from DP-013; the cost center from DP-190. "
               "External references (carried as keys only, not linked): Contingent Worker Detail.Supplier Agency to 02 "
               "Party and Supplier Contract Reference to 39 Contract, because this product must not depend on DP-210, "
               "DP-213 or DP-240 (they list it upstream); Workforce Position.Budget Plan Line to 19 Financial Plan Line; "
               "Employee Lifecycle Event.Related Reorganization to 09 Reorganization Event (DP-009). "
               "Model gap: Employee Lifecycle Event borrows Fiscal Period Key (derived from the event date) to place "
               "events in the measurement period; no input attribute holds the period."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-213": dict(
        style="ER",
        entities=[
            dict(name="Contract", role="Entity", objects=[("39", "Contract"), ("39", "Typed Contract Link")],
                 pk=["Contract ID"], measures=True,
                 grain="one row = contract (CTRCT-) x effective period (SCD type 2)",
                 note="The conformed Contract dimension (CD-296, CD-354). Typed Contract Link is one row per contract "
                      "(registry) and folds here: at most one of its references names the typed record (distribution, "
                      "data license, trading, advisory, lending, side letter, commitment, facility, intercompany, "
                      "service, mandate, debt, insurance). On typed rows status, dates and governing law are copies of "
                      "the typed record published as received (CD-257, CD-289). Holds the product measures."),
            dict(name="Contract Party", role="Entity", objects=[("39", "Contract Party")],
                 pk=["Party Contract", "Contract Party Role", "External Contract Party", "Internal Contract Party",
                     "Party Effective From"],
                 grain="one row = contract x party role x party (external or internal) x effective period",
                 note="One of External Contract Party (02) or Internal Contract Party (09) is populated."),
            dict(name="Contract Signatory", role="Entity", objects=[("39", "Contract Signatory")],
                 pk=["Signed Contract", "Signing Employee", "External Signatory"],
                 grain="one row = contract x signatory (employee or external party)",
                 note="One of Signing Employee or External Signatory is populated. Employee Signatures Without Authority "
                      "tests Relied-On Power of Attorney and Relied-On Authority Grant."),
            dict(name="Contract Document Version", role="Entity", objects=[("39", "Contract Document Version")],
                 pk=["Document Version Contract", "Document Version Number", "Document Sequence"],
                 grain="one row = contract x document version x document sequence"),
            dict(name="Contract Key Date", role="Entity", objects=[("39", "Contract Key Date")],
                 pk=["Key Date Contract", "Key Date Type", "Key Date Sequence"],
                 grain="one row = contract x key date type x sequence",
                 note="Notice, renewal and termination deadlines behind Open Notice Deadlines."),
            dict(name="Contract Clause Position", role="Entity", objects=[("39", "Contract Clause Position")],
                 pk=["Clause Contract", "Clause Type"],
                 grain="one row = contract x clause type"),
            dict(name="Supplier Contract Link", role="Entity", objects=[("40", "Supplier Contract Profile")],
                 pk=["Profiled Contract"],
                 grain="one row = contract with a 40 supplier contract profile",
                 note="Only the contract key of the 40 profile is read, to test the supplier typed link that 40 holds. "
                      "DP-210 masters the profile; this entity is not a conformed source for it."),
            dict(name="Party", role="Entity", conformed=("DP-240", "Party"),
                 objects=[("02", "Party"), ("02", "Organization")], pk=["Party ID"],
                 note="Conformed from DP-240 (CD-360): external contract parties and external signatories."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"),
                 objects=[("09", "Internal Legal Entity")],
                 note="Conformed from DP-013: the firm contracting entity and internal contract parties."),
            dict(name="Investment Product", role="Entity", conformed=("DP-004", "Investment Product"), objects=[],
                 note="Conformed from DP-004: the fund or product a contract is made for."),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[("20", "Employee")],
                 note="Conformed from DP-192: legal owner and employee signatories; Employment Status tests departures."),
        ],
        relationships=[
            dict(child="Contract", parent="Contract", fk=["Parent Contract"], card="M:1", optional=True,
                 note="Master agreement to schedule, amendment or order form."),
            dict(child="Contract", parent="Internal Legal Entity", fk=["Contracting Entity"], card="M:1"),
            dict(child="Contract", parent="Investment Product", fk=["Contracting Product"], card="M:1", optional=True),
            dict(child="Contract", parent="Employee", fk=["Legal Owner"], card="M:1", optional=True),
            dict(child="Contract Party", parent="Contract", fk=["Party Contract"], card="M:1"),
            dict(child="Contract Party", parent="Party", fk=["External Contract Party"], card="M:1", optional=True),
            dict(child="Contract Party", parent="Internal Legal Entity", fk=["Internal Contract Party"], card="M:1",
                 optional=True),
            dict(child="Contract Signatory", parent="Contract", fk=["Signed Contract"], card="M:1"),
            dict(child="Contract Signatory", parent="Employee", fk=["Signing Employee"], card="M:1", optional=True),
            dict(child="Contract Signatory", parent="Party", fk=["External Signatory"], card="M:1", optional=True),
            dict(child="Contract Document Version", parent="Contract", fk=["Document Version Contract"], card="M:1"),
            dict(child="Contract Key Date", parent="Contract", fk=["Key Date Contract"], card="M:1"),
            dict(child="Contract Clause Position", parent="Contract", fk=["Clause Contract"], card="M:1"),
            dict(child="Supplier Contract Link", parent="Contract", fk=["Profiled Contract"], card="1:1"),
            dict(child="Party", parent="Party", fk=["Merged Into Party"], card="M:1", optional=True),
        ],
        notes=("Foundational master, modeled ER around one Contract entity keyed by Contract ID with its typed link "
               "folded, and the parties, signatories, document versions, key dates and clause positions as children. "
               "Publishes the conformed Contract (CD-296, CD-354). Party identity is conformed from DP-240 and the firm "
               "entity from DP-013. The typed-record products (DP-005, DP-147 and others) are deliberately not upstream "
               "so they may list this product without a cycle; the Typed Contract Link references (05, 14, 26, 35, 28, "
               "30, 10, 16, 01, 43) are therefore carried as keys and not linked here. Other external references not "
               "linked: Contract Party.Notice Contact Point to 02 Contact Point Address (DP-240); Contract "
               "Signatory.Relied-On Power of Attorney and Relied-On Authority Grant to 39 objects that are not inputs. "
               "Validation warning expected in the per-module check: DP-240 Party is another Wave E8 group's model and "
               "is not loaded; its pk is set explicitly. "
               "Model gap: the 44 Lease link is held on the 44 side and is not read (spec)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-210": dict(
        style="ER",
        entities=[
            dict(name="Vendor", role="Entity", conformed=("DP-240", "Party"),
                 objects=[("40", "Supplier Profile"), ("02", "Party"), ("02", "Organization"), ("02", "LEI Record")],
                 pk=["Party ID"],
                 grain="one row = supplier party (02 PTY-) with a 40 supplier profile x effective period",
                 note="The conformed Vendor dimension (CD-296): the DP-240 party core (conformed, never copied) extended "
                      "with the 40 Supplier Profile, a 1:1 role of the party keyed by the Party ID (registry), so "
                      "Supplier Party repeats the Party ID. ERP Supplier Number is an alternate key. Organization and the "
                      "current LEI fold here."),
            dict(name="Vendor Party Role", role="Entity", objects=[("02", "Party Role")],
                 pk=["Vendor Key", "Role Type", "Role Effective From"],
                 grain="one row = supplier party x role type x role effective period",
                 note="Scoped within Party; the key is completed by the Vendor Key, which carries the Party ID."),
            dict(name="Supplier Onboarding Case", role="Entity", objects=[("40", "Supplier Onboarding Case")],
                 pk=["Onboarding Supplier", "Onboarding Sequence"],
                 grain="one row = supplier x onboarding sequence",
                 note="Sanctions screening result and onboarding approval behind Suppliers Without Completed Onboarding."),
            dict(name="Supplier Engagement", role="Entity", objects=[("40", "Supplier Engagement")],
                 pk=["Supplier Engagement ID"], measures=True,
                 grain="one row = supplier engagement (VENG-) x effective period",
                 note="The product grain, published with Vendor for consumers that need the engagement (outsourcing register, "
                      "third-party risk). The specialized provider references link the engagement to the 14 data "
                      "vendor, 29 servicing provider, 28 custody provider or 01 fund service provider role. Holds the "
                      "product measures because tiering, contract, owner and category measures are per engagement."),
            dict(name="Supplier Category Assignment", role="Entity", objects=[("40", "Supplier Category Assignment")],
                 pk=["Categorized Engagement", "Procurement Category", "Category Effective From"],
                 grain="one row = engagement x procurement category x effective period"),
            dict(name="Supplier Risk Tiering", role="Entity", objects=[("40", "Supplier Risk Tiering")],
                 pk=["Tiered Engagement", "Tier Effective From"],
                 grain="one row = engagement x tier effective period",
                 note="The 40 inherent tier only; the residual risk rating is 37's (CD-248)."),
            dict(name="Supplier Contract Profile", role="Entity", objects=[("40", "Supplier Contract Profile")],
                 pk=["Profiled Contract"],
                 grain="one row = 39 contract with a supplier contract profile",
                 note="A 1:1 extension of the 39 Contract keyed by the Contract ID; Contracted Engagements lists the "
                      "engagements the contract governs (many-to-many)."),
            dict(name="Data Vendor", role="Entity", objects=[("14", "Data Vendor")], pk=["Vendor Party"],
                 grain="one row = data vendor (14 role of the party)",
                 note="Read only for the data vendor to supplier link; a 1:1 role of the party keyed by the Party ID."),
            dict(name="Servicing Provider Engagement", role="Entity", objects=[("29", "Servicing Provider Engagement")],
                 pk=["Servicing Provider", "Servicing Role", "Engagement Start Date"],
                 grain="one row = servicing provider x servicing role x engagement start date (29, CW-088)",
                 note="Read only for the servicing provider to supplier link."),
            dict(name="Custody Provider Profile", role="Entity", objects=[("28", "Custody Provider Profile")],
                 pk=["Provider Party", "Custody Provider Role"],
                 grain="one row = custody provider party x custody provider role (current profile)",
                 note="Model gap: the registry key is Provider Party + Provider Legal Entity + Custody Provider Role + "
                      "Profile Effective From, but the spec reads neither Provider Legal Entity (only populated for a "
                      "self-custodying CIT trustee, which is not a supplier) nor Profile Effective From, so the key is "
                      "the current profile per party and role. Add Profile Effective From to the spec input to keep "
                      "history."),
            dict(name="Contract", role="Entity", conformed=("DP-213", "Contract"), objects=[("39", "Contract")],
                 note="Conformed from DP-213 (CD-354): the governing contract's status and dates; the 40 Contract Status "
                      "copy is not read."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"),
                 objects=[("09", "Internal Legal Entity")],
                 note="Conformed from DP-013: the buying entity and the contracting entity."),
            dict(name="Org Unit", role="Entity", conformed=("DP-013", "Org Unit"), objects=[],
                 note="Conformed from DP-013: the requesting org unit."),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[("20", "Employee")],
                 note="Conformed from DP-192: business owner and supplier relationship manager; Employment Status drives "
                      "Engagements With Departed Owner."),
        ],
        relationships=[
            dict(child="Vendor", parent="Vendor", fk=["Merged Into Party"], card="M:1", optional=True),
            dict(child="Vendor", parent="Employee", fk=["Supplier Relationship Manager"], card="M:1", optional=True),
            dict(child="Vendor Party Role", parent="Vendor", fk=["Vendor Key"], card="M:1",
                 note="Vendor Key carries the Party ID; 02 Party Role holds no party attribute of its own."),
            dict(child="Supplier Onboarding Case", parent="Vendor", fk=["Onboarding Supplier"], card="M:1"),
            dict(child="Supplier Engagement", parent="Vendor", fk=["Engaged Supplier"], card="M:1"),
            dict(child="Supplier Engagement", parent="Employee", fk=["Engagement Business Owner"], card="M:1",
                 optional=True),
            dict(child="Supplier Engagement", parent="Org Unit", fk=["Requesting Org Unit"], card="M:1", optional=True),
            dict(child="Supplier Engagement", parent="Internal Legal Entity", fk=["Engagement Buying Entity"],
                 card="M:1"),
            dict(child="Supplier Engagement", parent="Data Vendor", fk=["Specialized Data Vendor"], card="M:1",
                 optional=True),
            dict(child="Supplier Engagement", parent="Servicing Provider Engagement",
                 fk=["Specialized Servicing Provider Engagement"], card="M:1", optional=True,
                 note="One reference value carries the two-part servicing provider engagement key."),
            dict(child="Supplier Engagement", parent="Custody Provider Profile", fk=["Specialized Custody Provider Profile"],
                 card="M:1", optional=True, note="One reference value carries the custody provider profile key."),
            dict(child="Supplier Category Assignment", parent="Supplier Engagement", fk=["Categorized Engagement"],
                 card="M:1"),
            dict(child="Supplier Risk Tiering", parent="Supplier Engagement", fk=["Tiered Engagement"], card="M:1"),
            dict(child="Supplier Contract Profile", parent="Contract", fk=["Profiled Contract"], card="1:1"),
            dict(child="Supplier Contract Profile", parent="Supplier Engagement", fk=["Contracted Engagements"],
                 card="M:N", note="Multi-valued: one contract governs several engagements and an engagement may be "
                                  "governed by several contracts over time."),
            dict(child="Contract", parent="Internal Legal Entity", fk=["Contracting Entity"], card="M:1"),
            dict(child="Data Vendor", parent="Vendor", fk=["Vendor Party"], card="1:1",
                 note="Unlinked Specialized Providers counts data vendors with no supplier profile or engagement."),
            dict(child="Servicing Provider Engagement", parent="Vendor", fk=["Servicing Provider"], card="M:1"),
            dict(child="Custody Provider Profile", parent="Vendor", fk=["Provider Party"], card="M:1"),
        ],
        notes=("Foundational master, modeled ER around the Vendor (the DP-240 party in the supplier role, conformed, with "
               "the 40 supplier profile) and its engagements, which carry category, inherent tier and the governing "
               "contract (conformed from DP-213). Publishes the conformed Vendor (CD-296); Supplier Engagement is "
               "published beside it for consumers that need the engagement grain. The 14, 29 (moved from 13, CW-088) and 28 provider objects are "
               "read only for the link to the supplier and are not conformed, because their masters are not upstream. "
               "External references not linked here: Supplier Engagement.Fund Service Provider Role to 01 Product Party "
               "Role (read through DP-004 by key; not a DP-004 entity). Remittance details, spend and commercial terms "
               "are left out (DP-221). "
               "Validation warning expected in the per-module check: DP-240 Party is another Wave E8 group's model and is "
               "not loaded; Vendor's pk is set explicitly. "
               "Model gap: Custody Provider Profile is keyed without Provider Legal Entity and Profile Effective From, "
               "which the spec does not read (see the entity note)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-211": dict(
        style="ER",
        entities=[
            dict(name="Application", role="Entity",
                 objects=[("41", "Application"), ("41", "Application Recovery Profile"), ("41", "AI System Profile")],
                 pk=["Application ID"], measures=True,
                 grain="one row = application (APPL-) x effective period (SCD type 2)",
                 note="The conformed Application dimension (CD-296). Recovery Profile and AI System Profile are one row "
                      "per application and fold here; the AI columns are populated only for AI systems. Holds the "
                      "product measures because coverage, lifecycle and recovery measures are per application."),
            dict(name="Application Ownership Assignment", role="Entity", objects=[("41", "Application Ownership Assignment")],
                 pk=["Owned Application", "Application Ownership Role", "Application Role Holder", "Ownership Effective From"],
                 grain="one row = application x ownership role x role holder x effective period"),
            dict(name="Application Capability Mapping", role="Entity", objects=[("41", "Application Capability Mapping")],
                 pk=["Mapped Application", "Supported Business Capability", "Capability Mapping Effective From"],
                 grain="one row = application x business capability x effective period",
                 note="Supported Business Capability is text until the capability map is registered as data (spec "
                      "taxonomy gap), so it is not linked."),
            dict(name="Application Lifecycle Assessment", role="Entity", objects=[("41", "Application Lifecycle Assessment")],
                 pk=["Assessed Application", "Lifecycle Assessment Date"],
                 grain="one row = application x assessment date"),
            dict(name="Application Interface", role="Entity", objects=[("41", "Application Interface")],
                 pk=["Source Application", "Target Application", "External Endpoint Party", "Interface Code"],
                 grain="one row = source application x target application or external endpoint x interface code",
                 note="One of Target Application or External Endpoint Party is populated."),
            dict(name="AI System Use Case Link", role="Entity", objects=[("41", "AI System Use Case Link")],
                 pk=["Linked AI System", "Served AI Use Case", "Use Case Link Effective From"],
                 grain="one row = AI system x AI use case x effective period"),
            dict(name="IT Service", role="Entity", objects=[("41", "IT Service")], pk=["IT Service Code"],
                 grain="one row = IT service",
                 note="Supporting Applications is multi-valued, so the link to Application is many-to-many."),
            dict(name="Configuration Item", role="Entity", objects=[("41", "Configuration Item")],
                 pk=["Configuration Item ID"],
                 grain="one row = configuration item (CFGI-)"),
            dict(name="Configuration Item Relationship", role="Entity", objects=[("41", "Configuration Item Relationship")],
                 pk=["Parent Configuration Item", "Child Configuration Item", "CI Relationship Type",
                     "CI Relationship Effective From"],
                 grain="one row = parent CI x child CI x relationship type x effective period"),
            dict(name="Vendor", role="Entity", conformed=("DP-210", "Vendor"), objects=[("40", "Supplier Profile")],
                 note="Conformed from DP-210: the software vendor, AI system provider, third-party service provider and "
                      "external interface endpoint, matched by party (Vendor Applications Without Approved Supplier)."),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[("20", "Employee")],
                 note="Conformed from DP-192: application role holders, IT service owners and human oversight assignees."),
            dict(name="Org Unit", role="Entity", conformed=("DP-013", "Org Unit"), objects=[("09", "Org Unit")],
                 note="Conformed from DP-013: the owning org unit."),
            dict(name="Internal Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"), objects=[],
                 note="Conformed from DP-013: the owning legal entity."),
            dict(name="Office Location", role="Entity", conformed=("DP-013", "Office Location"), objects=[],
                 note="Conformed from DP-013: the hosting site of a configuration item."),
        ],
        relationships=[
            dict(child="Application", parent="Vendor", fk=["Software Vendor"], card="M:1", optional=True,
                 note="A vendor party with no supplier profile resolves to DP-240 Party (not upstream); that is the "
                      "Vendor Applications Without Approved Supplier case."),
            dict(child="Application", parent="Org Unit", fk=["Owning Org Unit"], card="M:1", optional=True),
            dict(child="Application", parent="Internal Legal Entity", fk=["Owning Legal Entity"], card="M:1",
                 optional=True),
            dict(child="Application", parent="Vendor", fk=["AI System Provider"], card="M:1", optional=True),
            dict(child="Application", parent="Employee", fk=["Human Oversight Assignee"], card="M:1", optional=True),
            dict(child="Application Ownership Assignment", parent="Application", fk=["Owned Application"], card="M:1"),
            dict(child="Application Ownership Assignment", parent="Employee", fk=["Application Role Holder"], card="M:1"),
            dict(child="Application Capability Mapping", parent="Application", fk=["Mapped Application"], card="M:1"),
            dict(child="Application Lifecycle Assessment", parent="Application", fk=["Assessed Application"], card="M:1"),
            dict(child="Application Lifecycle Assessment", parent="Application", fk=["Successor Application"],
                 card="M:1", optional=True),
            dict(child="Application Interface", parent="Application", fk=["Source Application"], card="M:1"),
            dict(child="Application Interface", parent="Application", fk=["Target Application"], card="M:1",
                 optional=True),
            dict(child="Application Interface", parent="Vendor", fk=["External Endpoint Party"], card="M:1",
                 optional=True, note="External endpoints that are not suppliers resolve to DP-240 Party."),
            dict(child="AI System Use Case Link", parent="Application", fk=["Linked AI System"], card="M:1"),
            dict(child="IT Service", parent="Application", fk=["Supporting Applications"], card="M:N",
                 note="Multi-valued reference."),
            dict(child="IT Service", parent="Employee", fk=["IT Service Owner"], card="M:1", optional=True),
            dict(child="IT Service", parent="Vendor", fk=["Third-Party Service Provider"], card="M:1", optional=True),
            dict(child="Configuration Item", parent="Application", fk=["Instantiated Application"], card="M:1",
                 optional=True),
            dict(child="Configuration Item", parent="Office Location", fk=["Hosting Site"], card="M:1", optional=True),
            dict(child="Configuration Item Relationship", parent="Configuration Item", fk=["Parent Configuration Item"],
                 card="M:1"),
            dict(child="Configuration Item Relationship", parent="Configuration Item", fk=["Child Configuration Item"],
                 card="M:1"),
        ],
        notes=("Foundational master, modeled ER around one Application entity (recovery and AI system profiles folded) "
               "with ownership, capability mapping, lifecycle assessments, interfaces and AI use case links as children, "
               "and the IT services and configuration items that run on it. Publishes the conformed Application "
               "(CD-296); IT Service and Configuration Item are available to DP-231 to DP-234. Vendor is conformed from "
               "DP-210 and Employee from DP-192. DP-101 lists this product upstream, so it is never conformed here "
               "(CD-361). External references not linked here: Application Interface.Carried Data Feed to 06 Data Feed; "
               "AI System Use Case Link.Served AI Use Case to 21 AI Use Case (DP-101). "
               "Model gap: Application has no link to the 40 Supplier Engagement that supplies it; the supplier is "
               "matched by the Software Vendor party (spec taxonomy gap)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-212": dict(
        style="ER",
        entities=[
            dict(name="Model", role="Entity", objects=[("37", "Model Inventory Entry")], pk=["Model ID", "Model Version"],
                 measures=True,
                 grain="one row = model (MODEL-) x model version",
                 note="The conformed Model dimension (CD-296, CD-354). Products that need the model across versions join "
                      "on Model ID alone (registry). Holds the product measures because use, validation and deployment "
                      "measures are per model version."),
            dict(name="Model Tier Assignment", role="Entity", objects=[("37", "Model Tier Assignment")],
                 pk=["Tiered Model", "Tier Effective From"],
                 grain="one row = model x tier effective period",
                 note="The tier applies across versions; Tiered Model carries the Model ID only."),
            dict(name="Model Validation", role="Entity", objects=[("37", "Model Validation")],
                 pk=["Validated Model", "Model Validation Sequence"],
                 grain="one row = model version x validation sequence"),
            dict(name="Model Performance Monitoring", role="Entity", objects=[("37", "Model Performance Monitoring")],
                 pk=["Monitored Model", "Monitoring Test", "Monitoring Period End Date"],
                 grain="one row = model version x monitoring test x period end date",
                 note="Only the breach indicator is held, no observed value or threshold (spec taxonomy gap)."),
            dict(name="AI System Model Deployment", role="Entity", objects=[("41", "AI System Model Deployment")],
                 pk=["Model Deploying AI System", "Deployed Model", "Model Deployment Effective From"],
                 grain="one row = AI system (application) x model version x effective period",
                 note="Associative entity between Application and Model; only AI systems record deployments (spec "
                      "taxonomy gap)."),
            dict(name="Application", role="Entity", conformed=("DP-211", "Application"),
                 objects=[("41", "Application")],
                 note="Conformed from DP-211: the AI system a model version is deployed in."),
            dict(name="Employee", role="Entity", conformed=("DP-192", "Employee"), objects=[("20", "Employee")],
                 note="Conformed from DP-192: model owner and internal validator."),
        ],
        relationships=[
            dict(child="Model", parent="Employee", fk=["Model Owner"], card="M:1", optional=True),
            dict(child="Model Tier Assignment", parent="Model", fk=["Tiered Model"], card="M:1",
                 note="Joins on Model ID across versions."),
            dict(child="Model Validation", parent="Model", fk=["Validated Model"], card="M:1",
                 note="Validated Model carries model ID and version in one value."),
            dict(child="Model Validation", parent="Employee", fk=["Internal Validator"], card="M:1", optional=True),
            dict(child="Model Performance Monitoring", parent="Model", fk=["Monitored Model"], card="M:1",
                 note="Monitored Model carries model ID and version in one value."),
            dict(child="AI System Model Deployment", parent="Application", fk=["Model Deploying AI System"], card="M:1"),
            dict(child="AI System Model Deployment", parent="Model", fk=["Deployed Model"], card="M:1"),
        ],
        notes=("Foundational master, modeled ER around the Model (model x version) with tiering, validations, "
               "performance monitoring and AI system deployments as children; Application is conformed from DP-211 and "
               "Employee from DP-192. Publishes the conformed Model (CD-296); 31 Risk Model and the scoring products "
               "cite it by Model ID and version. "
               "External references (carried as keys, not linked here): Model.Model Vendor and Model "
               "Validation.External Validator to 02 Party (DP-240 is not upstream); Model Performance "
               "Monitoring.Back-Test Evidence to 31 VaR Back-Test."),
    ),
}
