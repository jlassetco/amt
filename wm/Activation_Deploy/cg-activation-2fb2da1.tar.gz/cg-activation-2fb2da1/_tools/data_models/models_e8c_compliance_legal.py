"""Logical data models: Wave E8 consumer-aligned Star models for Corporate Compliance & Regulatory Affairs (38: DP-222 to
DP-228) and Legal & Corporate Governance (39: DP-229, DP-230). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` (Internal Legal Entity and Calendar Date from
  DP-013, Employee from DP-192, Party from DP-240, Instrument from DP-097, Issuer from DP-098, Contract from DP-213 and so
  on) and are named for their role. Product input objects of the same concept sit on the conformed dimension and merge with
  its inherited attributes.
- Facts and the 38 and 39 objects are built from the product's own inputs. So are objects published by consumer products
  (DP-123 orders and executions, DP-180 account monitoring alerts, DP-216 risk issues, DP-234 projects, DP-078
  communications alerts, DP-214 controls, and the 38 and 39 objects one product in this group reads from a sibling): no
  foundational model publishes them, so they are kept as the product's own dimensions with the registry's natural keys.
- Where a reference attribute's REFS target is held in the model, the attribute itself is the foreign key. A reference whose
  target is not a product input is a descriptive column, listed in the model notes.
- Where the concept is needed for a join but no input masters it, the dimension is kept with a surrogate key and no
  attributes (a "Model gap"), and facts join to it through "<Dimension> Key".
- Snapshot facts (the spec grain says "x as-of date") borrow "As-of Date Key" from the conformed DP-013 Calendar Date into
  their key. Their child facts reference the parent by its natural identifier and are read at the same as-of date.
- Multi-valued references (e.g. Examined Entities) are drawn as M:N relationships; the build explodes them into one row per
  referenced member. Where the spec names the explosion as its own grain, it is a Bridge.
"""


def dim(name, src, objects=(), note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


LE = ("DP-013", "Internal Legal Entity")
CAL = ("DP-013", "Calendar Date")
EMP = ("DP-192", "Employee")
ORG = ("DP-192", "Org Unit")
PARTY = ("DP-240", "Party")
INSTR = ("DP-097", "Instrument")
ISSUER = ("DP-098", "Issuer")
PROD = ("DP-004", "Investment Product")
CONTRACT = ("DP-213", "Contract")

MODELS = {
    # ================================== 38 Corporate Compliance & Regulatory Affairs ==================================
    "DP-222": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Entity Authorization", role="Fact", objects=[("38", "Entity Authorization")],
                 pk=["Authorization ID", "As-of Date Key"], measures=True,
                 grain="one row = entity authorization (legal entity x regulator x authorization type x authorization "
                       "jurisdiction) x as-of date (the product grain)",
                 note="Built from the input rather than conformed from DP-013's Entity Authorization so that the status "
                      "can be snapshotted daily; it keeps the same Authorization ID. Regulator, Authorization Type and "
                      "Authorization Jurisdiction are degenerate dimensions (free values, not references). Measures that "
                      "read the child grains (filing timeliness, threshold crossings, passports) are computed there and "
                      "published here."),
            dict(name="Fact Firm Regulatory Filing", role="Fact", objects=[("38", "Firm Regulatory Filing")],
                 pk=["Firm Filing ID"],
                 grain="one row = firm filing submission (filer entity x form type x period x submission sequence)",
                 note="Feeds Upcoming Entity Filing, Firm Filing Timeliness %, Overdue Firm Filings and Amendment Rate. "
                      "Filing Form Type and Filing Submission Type are degenerate dimensions."),
            dict(name="Fact Ownership Disclosure Determination", role="Fact",
                 objects=[("38", "Ownership Disclosure Determination")],
                 pk=["Disclosure Security Class", "Disclosure Regime", "Aggregation Entity", "Determination Date"],
                 grain="one row = security class x disclosure regime x aggregation entity x determination date",
                 note="Aggregated Ownership Percentage is the 38 mastered figure; Recomputed Ownership % and Aggregation "
                      "Variance are a reconciliation against the holdings fact and never replace it."),
            dict(name="Fact Portfolio Holding", role="Fact", objects=[("18", "Portfolio Holding")],
                 pk=["Holding ID"],
                 grain="one row = portfolio x instrument x holding date x holding view",
                 note="Read from DP-142 (same Holding ID) and kept as a fact because the reconciliation sums Holding "
                      "Quantity across portfolios owned or managed by the aggregation entity. Quantity only: no market "
                      "value or AUM is read."),
            dict(name="Entity Ownership Relationship", role="Bridge",
                 conformed=("DP-013", "Entity Ownership Relationship"),
                 objects=[("09", "Entity Ownership Relationship")],
                 grain="one row = child entity x parent entity x relationship type x ownership effective from",
                 note="Rolls portfolios' owning and managing entities up to the aggregation entity of each regime."),
            # -- dimensions
            dim("Legal Entity", LE, [("09", "Internal Legal Entity"), ("09", "Legal Entity Identifier")],
                note="Plays the authorized, filer, passport home and aggregation entity roles. The LEI, SEC CIK, CRD "
                     "and FCA FRN fold in."),
            dim("Instrument", INSTR, [("17", "Instrument"), ("17", "Equity Terms")],
                note="The security class of a determination and the held instrument. Equity Terms gives Shares "
                     "Outstanding and voting rights for Recomputed Ownership %."),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")], note="Conformed Issuer from DP-098."),
            dim("Party", PARTY, [("02", "Party")],
                note="The issuer's enterprise party record (display name and status) from DP-240."),
            dim("Portfolio", ("DP-140", "Portfolio"), [("18", "Portfolio")],
                note="Conformed Portfolio from DP-140; its legal owner and managing entity drive aggregation."),
            dim("As-of Date", CAL, note="Conformed Calendar Date for the daily status snapshot."),
        ],
        relationships=[
            rel("Fact Entity Authorization", "Legal Entity", ["Authorized Entity"]),
            rel("Fact Entity Authorization", "As-of Date", ["As-of Date Key"]),
            rel("Fact Firm Regulatory Filing", "Legal Entity", ["Filer Entity"]),
            rel("Fact Firm Regulatory Filing", "Fact Firm Regulatory Filing", ["Amended Firm Filing"], optional=True,
                note="An amendment points to the filing it amends; feeds Amendment Rate."),
            rel("Fact Ownership Disclosure Determination", "Issuer", ["Disclosure Issuer"]),
            rel("Fact Ownership Disclosure Determination", "Instrument", ["Disclosure Security Class"]),
            rel("Fact Ownership Disclosure Determination", "Legal Entity", ["Aggregation Entity"]),
            rel("Fact Ownership Disclosure Determination", "Fact Firm Regulatory Filing", ["Resulting Firm Filing"],
                optional=True, note="Empty when no filing was required or one is missing (Unfiled Required Disclosure "
                                    "Flag)."),
            rel("Fact Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Fact Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio", "Legal Entity", ["Legal Owner Entity"], optional=True),
            rel("Portfolio", "Legal Entity", ["Managing Entity"], optional=True),
            rel("Entity Ownership Relationship", "Legal Entity", ["Child Entity"]),
            rel("Entity Ownership Relationship", "Legal Entity", ["Parent Entity"]),
            rel("Instrument", "Issuer", ["Issuer"]),
            rel("Issuer", "Party", ["Issuer Party"], card="1:1"),
        ],
        notes=("W4 re-point (CW-938): Fact Cross-Border Passport and the Host Country dimension are removed with 38 "
               "Cross-Border Passport. "
               "Authorization register as the snapshot fact, with filings, ownership determinations and the "
               "holdings they reconcile to as facts at their own grains. Legal entities, ownership links and dates are "
               "conformed from DP-013, the portfolio from DP-140, the instrument from DP-097, the issuer from DP-098 and "
               "the party from DP-240. "
               "Descriptive column, not joined: Ownership Disclosure Determination.Reviewed Engagement (34 Engagement; no "
               "stewardship product is upstream). "
               "Model gap: the determination carries no shares-held numerator, threshold crossed or shares outstanding "
               "used, so Recomputed Ownership % uses the latest Equity Terms.Shares Outstanding (spec taxonomy gap)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-223": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Regulatory Examination", role="Fact", objects=[("38", "Regulatory Examination")],
                 pk=["Examination ID", "As-of Date Key"], measures=True,
                 grain="one row = examination, sweep or inquiry x as-of date (the product grain)",
                 note="Examination Type, Examining Regulator and Examination Status are degenerate dimensions. Measures "
                      "for change items are computed on Fact Regulatory Change Impact and published here."),
            dict(name="Fact Regulator Request Item", role="Fact", objects=[("38", "Regulator Request Item")],
                 pk=["Request Examination", "Request Sequence"],
                 grain="one row = examination x request sequence",
                 note="Feeds Request Timeliness % and Overdue Requests."),
            dict(name="Fact Examination Finding", role="Fact", objects=[("38", "Examination Finding")],
                 pk=["Finding Examination", "Finding Sequence"],
                 grain="one row = examination x finding sequence",
                 note="Feeds Finding Response Timeliness % and, with the risk issues raised from it, Findings Without "
                      "Remediation Issue and Overdue Finding Remediation."),
            dict(name="Fact Regulatory Change Impact", role="Fact", objects=[("38", "Regulatory Change Impact")],
                 pk=["Impacted Change Item", "Impacted Entity", "Impacted Business Line", "Impacted Data Domain",
                     "As-of Date Key"],
                 grain="one row = regulatory change item x impacted scope (legal entity, business line or Data Domain) "
                       "x as-of date",
                 note="Impacted Business Line and Impacted Data Domain are degenerate dimensions; only one scope "
                      "attribute is set per row. Feeds Unassessed Change Flag."),
            dict(name="Project Scope Link", role="Bridge", objects=[("41", "Project Scope Link")],
                 pk=["Scoping Project", "Delivered Regulatory Change Item", "Scope Link Effective From"],
                 grain="one row = project x delivered regulatory change item x effective from",
                 note="Read through DP-234. The registry key also names the other delivered-object references (change "
                      "initiative, data product, data quality issue, application); they are not product inputs and are "
                      "empty on the rows this product reads (Delivered Object Type = regulatory change item). Feeds "
                      "Undelivered Change Flag."),
            # -- dimensions
            dict(name="Regulatory Change Item", role="Dimension", objects=[("38", "Regulatory Change Item")],
                 pk=["Regulatory Change ID"],
                 note="The change item (REGCH-); Change Compliance Date drives Change Items Due 12m."),
            dict(name="Regulatory Horizon Item", role="Dimension", objects=[("11", "Regulatory Horizon Item")],
                 pk=["Regulator / Body", "Regulatory Initiative"],
                 note="The market-intelligence horizon item; horizon items with no change item give Horizon Items "
                      "Without Change Item."),
            dict(name="Project", role="Dimension", objects=[("41", "Project")], pk=["Project ID"],
                 note="Read through DP-234 (a consumer product), so kept as an own dimension with the 41 key."),
            dict(name="Legal Matter", role="Dimension", objects=[("39", "Legal Matter")], pk=["Legal Matter ID"],
                 note="Read through DP-229; an enforcement matter whose Originating Examination is set gives "
                      "Examinations Referred to Enforcement."),
            dict(name="Risk Issue", role="Dimension", objects=[("37", "Risk Issue")], pk=["Risk Issue ID"],
                 note="Read through DP-216 (a consumer product); the remediation issue raised from a finding."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")],
                note="The examined and impacted entities."),
            dim("As-of Date", CAL, note="Conformed Calendar Date for the daily snapshot."),
        ],
        relationships=[
            rel("Fact Regulatory Examination", "Legal Entity", ["Examined Entities"], card="M:N",
                note="Multi-valued; an examination or sweep may cover several entities."),
            rel("Fact Regulatory Examination", "As-of Date", ["As-of Date Key"]),
            rel("Fact Regulator Request Item", "Fact Regulatory Examination", ["Request Examination"]),
            rel("Fact Examination Finding", "Fact Regulatory Examination", ["Finding Examination"]),
            rel("Risk Issue", "Fact Examination Finding", ["Source Examination Finding"], optional=True,
                note="Only issues whose source type is an examination finding."),
            rel("Legal Matter", "Fact Regulatory Examination", ["Originating Examination"], optional=True),
            rel("Fact Regulatory Change Impact", "Regulatory Change Item", ["Impacted Change Item"]),
            rel("Fact Regulatory Change Impact", "Legal Entity", ["Impacted Entity"], optional=True),
            rel("Fact Regulatory Change Impact", "As-of Date", ["As-of Date Key"]),
            rel("Regulatory Change Item", "Regulatory Horizon Item", ["Source Horizon Item"], optional=True),
            rel("Project Scope Link", "Project", ["Scoping Project"]),
            rel("Project Scope Link", "Regulatory Change Item", ["Delivered Regulatory Change Item"]),
        ],
        notes=("Two snapshot facts, examinations and change impacts, with request and finding facts under the "
               "examination. Risk issues (DP-216), projects (DP-234) and legal matters (DP-229) are consumer-published, "
               "so they are own dimensions keyed as in the registry. Legal entity and dates are conformed from DP-013. "
               "Descriptive columns, not joined: Regulatory Change Impact.Affected Obligations and Policies to Update "
               "(38 Regulatory Obligation and Policy, not inputs here; DP-224 owns them)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-224": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Regulatory Obligation", role="Fact", objects=[("38", "Regulatory Obligation")],
                 pk=["Obligation ID", "As-of Date Key"], measures=True,
                 grain="one row = regulatory obligation x as-of date (the product grain)",
                 note="Source Regulation, Rule Citation and Compliance Assessment are degenerate dimensions. Policy, "
                      "attestation, training and program review measures are computed on their own facts and published "
                      "here."),
            dict(name="Fact Policy Version", role="Fact", objects=[("38", "Policy Version")],
                 pk=["Versioned Policy", "Policy Version Number"],
                 grain="one row = policy x version number",
                 note="Feeds Policies Overdue for Review and Policy Version Without Recorded Approval."),
            dict(name="Fact Attestation", role="Fact", objects=[("38", "Attestation")],
                 pk=["Attester", "Attestation Type", "Attestation Period"],
                 grain="one row = attester x attestation type x attestation period",
                 note="Attestation Period is added to the registry key (attester x attestation type) because the object's "
                      "grain repeats each period. Feeds Attestation Completion %, Overdue Attestation Count and Policy "
                      "Attestation Coverage %."),
            dict(name="Fact Compliance Program Review", role="Fact", objects=[("38", "Compliance Program Review")],
                 pk=["Reviewed Entity", "Program Review Type", "Review Period End"],
                 grain="one row = reviewed entity (or fund complex) x program review type x review period",
                 note="Feeds Program Review Currency Flag and Program Review Conclusions."),
            dict(name="Fact Control Test", role="Fact", objects=[("37", "Control Test")],
                 pk=["Tested Control", "Control Test Date"],
                 grain="one row = control version x test date",
                 note="Model gap: the registry key adds Control Test Sequence, which is not a product input, so two "
                      "tests of one control on one day collapse. Feeds Compliance Testing Coverage %."),
            dict(name="Fact Learning Completion", role="Fact", objects=[("20", "Learning Completion")],
                 pk=["Learner Employee", "Completed Learning Item", "Completion Due Date", "Completion Date"],
                 grain="one row = employee x learning item x assignment (due date) or completion",
                 note="Feeds Required Training Completion %."),
            dict(name="Corporate Resolution Subject Link", role="Bridge",
                 objects=[("39", "Corporate Resolution Subject Link")],
                 pk=["Corporate Resolution Subject Link Key"],
                 grain="one row = corporate resolution x approved subject (here: policy versions)",
                 note="Surrogate key, as in the registry. Gives the approving resolution of a policy version."),
            dict(name="Employee Reporting Line", role="Bridge", conformed=("DP-192", "Employee Reporting Line"),
                 objects=[("20", "Employee Reporting Line")],
                 grain="one row = reporting employee x line manager x reporting line type x effective from",
                 note="Gives the attester's and learner's line manager for escalation of overdue items."),
            # -- dimensions
            dict(name="Policy", role="Dimension", objects=[("38", "Policy")], pk=["Policy ID"],
                 note="Policy Domain and Policy Status are slicers."),
            dict(name="Control", role="Dimension", objects=[("37", "Control")], pk=["Control ID", "Control Version"],
                 note="Read through DP-214 (a consumer product), so kept as an own dimension with the 37 key."),
            dict(name="Risk Issue", role="Dimension", objects=[("37", "Risk Issue")], pk=["Risk Issue ID"],
                 note="Read through DP-216; remediation issues raised from program reviews (Open Program Review "
                      "Remediation)."),
            dict(name="Corporate Resolution", role="Dimension", objects=[("39", "Corporate Resolution")],
                 pk=["Corporate Resolution ID"],
                 note="Read through DP-230 (a consumer product)."),
            dim("Entity Authorization", ("DP-013", "Entity Authorization"), [("38", "Entity Authorization")],
                note="Conformed from DP-013; an entity's authorizations decide which obligations should apply (Entity "
                     "Without Obligations Flag)."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", EMP, [("20", "Employee")],
                note="Plays the obligation owner, policy owner, attester, review lead, learner and line manager roles."),
            dim("Org Unit", ORG, [("09", "Org Unit")], note="The employee's home org unit."),
            dim("Investment Product", PROD, [("01", "Investment Product")],
                note="The funds covered by a compliance program review (fund complex reviews)."),
            dim("As-of Date", CAL, note="Conformed Calendar Date for the daily snapshot."),
        ],
        relationships=[
            rel("Fact Regulatory Obligation", "As-of Date", ["As-of Date Key"]),
            rel("Fact Regulatory Obligation", "Employee", ["Obligation Owner"], optional=True,
                note="Empty owner gives Unowned Obligation Flag."),
            rel("Fact Regulatory Obligation", "Control", ["Monitoring Control"], optional=True),
            rel("Fact Regulatory Obligation", "Legal Entity", ["Applicable Legal Entity"], optional=True,
                note="Model gap: Applicable Legal Entity is not typed as a reference in the taxonomy; it is joined on the "
                     "Legal Entity ID it holds."),
            rel("Policy", "Employee", ["Policy Owner"], optional=True),
            rel("Policy", "Legal Entity", ["Policy Applicable Entities"], card="M:N"),
            rel("Policy", "Fact Regulatory Obligation", ["Policy Regulatory Basis"], card="M:N", optional=True,
                note="Gives Obligation Coverage (obligations with a policy)."),
            rel("Fact Policy Version", "Policy", ["Versioned Policy"]),
            rel("Fact Attestation", "Employee", ["Attester"]),
            rel("Fact Attestation", "Fact Policy Version", ["Attested Policy Version"], optional=True),
            rel("Fact Compliance Program Review", "Legal Entity", ["Reviewed Entity"]),
            rel("Fact Compliance Program Review", "Investment Product", ["Covered Products"], card="M:N",
                optional=True),
            rel("Fact Compliance Program Review", "Employee", ["Review Lead"], optional=True),
            rel("Risk Issue", "Fact Compliance Program Review", ["Source Compliance Program Review"], optional=True),
            rel("Fact Control Test", "Control", ["Tested Control"]),
            rel("Fact Learning Completion", "Employee", ["Learner Employee"]),
            rel("Corporate Resolution Subject Link", "Corporate Resolution", ["Linked Corporate Resolution"]),
            rel("Corporate Resolution Subject Link", "Fact Policy Version", ["Subject Policy Version"], optional=True),
            rel("Entity Authorization", "Legal Entity", ["Authorized Entity"]),
            rel("Employee", "Legal Entity", ["Employing Legal Entity"]),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee Reporting Line", "Employee", ["Reporting Employee"]),
            rel("Employee Reporting Line", "Employee", ["Line Manager"]),
        ],
        notes=("Obligation register as the snapshot fact, with policy versions, attestations, program reviews, control "
               "tests and training completions as facts at their own grains. Controls (DP-214), risk issues (DP-216) and "
               "corporate resolutions (DP-230) are consumer-published, so they are own dimensions. Legal entity, entity "
               "authorization and dates are conformed from DP-013, employees, reporting lines and org units from DP-192, "
               "funds from DP-004. "
               "Descriptive columns, not joined: Policy Version.Required Training (20 Mandatory Training Requirement) "
               "and Learning Completion.Completed Learning Item (20 Learning Item), neither an input. "
               "Model gap: Required Training Completion % matches the policy version's required training to completions "
               "by value, because no input carries Learning Completion.Satisfied Training Requirement."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-225": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Conduct Population Designation", role="Fact",
                 objects=[("38", "Conduct Population Designation")],
                 pk=["Designated Employee", "Conduct Designation Type", "Designating Entity", "Designating Fund",
                     "Designation Effective From", "Reporting Period End Key"], measures=True,
                 grain="one row = conduct population member (employee x designation type x designating entity or fund x "
                       "effective period) x reporting period (the product grain)",
                 note="Access persons, supervised persons and covered associates. Measures that read the child grains "
                      "(reports, trades, pre-clearances, violations, contributions, OBAs, conflicts) are computed there "
                      "and published here."),
            dict(name="Fact Personal Securities Report", role="Fact", objects=[("38", "Personal Securities Report")],
                 pk=["Reporting Access Person", "Personal Report Type", "Report As-Of Date"],
                 grain="one row = access person x report type (initial, annual holdings or quarterly transactions) x "
                       "report as-of date",
                 note="Feeds Report Timeliness % and Late or Missing Reports."),
            dict(name="Fact Reported Personal Holding", role="Fact", objects=[("38", "Reported Personal Holding")],
                 pk=["Holding Report", "Holding Account", "Held Security"],
                 grain="one row = personal securities report x account x security held",
                 note="Child of the report (registry fold=False). Model gap: the registry key adds Held Security "
                      "Description for securities with no instrument record; it is not a product input."),
            dict(name="Fact Personal Transaction", role="Fact", objects=[("38", "Personal Transaction")],
                 pk=["Transaction Account", "Broker Transaction Reference"],
                 grain="one row = personal trading account x broker transaction",
                 note="Feeds Unprecleared Trade Flag, Restricted List Trade Flag and Unreported Transaction Flag."),
            dict(name="Fact Pre-Clearance Request", role="Fact", objects=[("38", "Pre-Clearance Request")],
                 pk=["Requesting Employee", "Request Timestamp"],
                 grain="one row = employee x pre-clearance request timestamp",
                 note="Feeds Pre-Clearance Denial Rate."),
            dict(name="Fact Code of Ethics Violation", role="Fact", objects=[("38", "Code of Ethics Violation")],
                 pk=["Violating Employee", "Violation Detected Date", "Violation Sequence"],
                 grain="one row = employee x violation detected date x sequence",
                 note="Feeds Violations by Sanction."),
            dict(name="Fact Political Contribution", role="Fact",
                 objects=[("38", "Political Contribution"), ("38", "Pay-to-Play Review")],
                 pk=["Political Contribution ID"],
                 grain="one row = political contribution",
                 note="The pay-to-play review folds here (one review per contribution). Feeds Contribution Over De "
                      "Minimis Flag, Time-Outs Triggered and Contributions Without Pre-Clearance."),
            dict(name="Fact Outside Business Activity", role="Fact", objects=[("38", "Outside Business Activity")],
                 pk=["OBA Employee", "OBA Type", "OBA Organization", "OBA Effective From"],
                 grain="one row = employee x OBA type x organization x effective from",
                 note="Feeds Unapproved Active OBA."),
            dict(name="Fact Conflict Mitigation", role="Fact", objects=[("38", "Conflict Mitigation")],
                 pk=["Mitigated Conflict", "Mitigation Type", "Mitigating Control", "Mitigating Policy",
                     "Mitigation Effective From"],
                 grain="one row = firm conflict x mitigation x effective period",
                 note="Feeds Conflicts Without Effective Mitigation, together with the mitigating control's tests."),
            dict(name="Fact Control Test", role="Fact", objects=[("37", "Control Test")],
                 pk=["Tested Control", "Control Test Date"],
                 grain="one row = control version x test date",
                 note="Tests of the controls that mitigate conflicts. Model gap: the registry key adds Control Test "
                      "Sequence, which is not a product input."),
            # -- dimensions
            dict(name="Personal Trading Account", role="Dimension", objects=[("38", "Personal Trading Account")],
                 pk=["Personal Account Key"],
                 note="Covered accounts of access persons and their household members."),
            dict(name="Conflict of Interest", role="Dimension", objects=[("38", "Conflict of Interest")],
                 pk=["Conflict ID"], note="The firm conflict register (CONFL-)."),
            dict(name="Firm Restricted List", role="Dimension", objects=[("38", "Firm Restricted List")],
                 pk=["Restricted List Code"], note="Read through DP-227."),
            dict(name="Restricted List Entry", role="Dimension", objects=[("38", "Restricted List Entry")],
                 pk=["Restricted List Entry ID"],
                 note="Read through DP-227; the entry valid on the trade date gives Restricted List Trade Flag."),
            dict(name="Control", role="Dimension", objects=[], pk=["Control Key"],
                 note="Model gap: 37 Control is not a product input (DP-214 publishes it), so the mitigating and tested "
                      "control join through a surrogate key that carries the Control ID they hold."),
            dim("Instrument", INSTR, [("17", "Instrument")],
                note="The traded, held, pre-cleared and restricted securities."),
            dim("Government Client", ("DP-240", "Party"), [("02", "Party")],
                note="Conformed Party from DP-240; the parties affected by a contribution."),
            dict(name="Institutional Client", role="Dimension", objects=[("12", "Institutional Client")],
                 pk=["Institutional Client Party"],
                 note="W4 re-point (CW-151, CW-912): the 12 institutional client profile is restored; its Government "
                      "Entity Indicator marks the government clients. Read from 12 (no foundational product publishes "
                      "it), keyed by the party."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Plays every employee role: designated person, account holder, reporter, requester, violator, "
                     "contributor and OBA holder."),
            dim("Org Unit", ORG, note="The employee's home org unit, for supervision roll-ups."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")],
                note="Designating, contributing and conflicted entities."),
            dim("Investment Product", PROD, [("01", "Investment Product")],
                note="The fund whose code of ethics designates the person."),
            dim("Reporting Period End", CAL, note="Conformed Calendar Date for the reporting period."),
        ],
        relationships=[
            rel("Fact Conduct Population Designation", "Employee", ["Designated Employee"]),
            rel("Fact Conduct Population Designation", "Legal Entity", ["Designating Entity"], optional=True),
            rel("Fact Conduct Population Designation", "Investment Product", ["Designating Fund"], optional=True),
            rel("Fact Conduct Population Designation", "Reporting Period End", ["Reporting Period End Key"]),
            rel("Personal Trading Account", "Employee", ["Account Holder Employee"]),
            rel("Fact Personal Securities Report", "Employee", ["Reporting Access Person"]),
            rel("Fact Reported Personal Holding", "Fact Personal Securities Report", ["Holding Report"]),
            rel("Fact Reported Personal Holding", "Personal Trading Account", ["Holding Account"]),
            rel("Fact Reported Personal Holding", "Instrument", ["Held Security"], optional=True),
            rel("Fact Personal Transaction", "Personal Trading Account", ["Transaction Account"]),
            rel("Fact Personal Transaction", "Instrument", ["Traded Security"], optional=True),
            rel("Fact Personal Transaction", "Fact Pre-Clearance Request", ["Matched Pre-Clearance"], optional=True,
                note="Empty on a trade that needed pre-clearance gives Unprecleared Trade Flag."),
            rel("Fact Personal Transaction", "Fact Personal Securities Report", ["Reported On Report"], optional=True,
                note="Empty gives Unreported Transaction Flag."),
            rel("Fact Pre-Clearance Request", "Employee", ["Requesting Employee"]),
            rel("Fact Pre-Clearance Request", "Instrument", ["Pre-Clearance Security"], optional=True),
            rel("Fact Pre-Clearance Request", "Restricted List Entry", ["Blocking Restricted List Entry"],
                optional=True),
            rel("Fact Code of Ethics Violation", "Employee", ["Violating Employee"]),
            rel("Fact Political Contribution", "Employee", ["Contributor Employee"]),
            rel("Fact Political Contribution", "Legal Entity", ["Contributing Entity"], optional=True),
            rel("Fact Political Contribution", "Government Client", ["Affected Government Clients"], card="M:N",
                optional=True),
            rel("Institutional Client", "Government Client", ["Institutional Client Party"], card="1:1"),
            rel("Fact Outside Business Activity", "Employee", ["OBA Employee"]),
            rel("Fact Outside Business Activity", "Conflict of Interest", ["OBA Related Conflict"], optional=True),
            rel("Conflict of Interest", "Legal Entity", ["Conflict Entities"], card="M:N"),
            rel("Fact Conflict Mitigation", "Conflict of Interest", ["Mitigated Conflict"]),
            rel("Fact Conflict Mitigation", "Control", ["Control Key"], optional=True,
                note="Carries Mitigating Control."),
            rel("Fact Control Test", "Control", ["Control Key"], note="Carries Tested Control."),
            rel("Restricted List Entry", "Firm Restricted List", ["Entry List"]),
            rel("Restricted List Entry", "Instrument", ["Restricted Instruments"], card="M:N", optional=True),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee", "Legal Entity", ["Employing Legal Entity"]),
        ],
        notes=("Conduct population as the period fact, with personal reporting, trading, pre-clearance, violations, "
               "political contributions, OBAs and conflict mitigations as facts at their own grains. The restricted list "
               "is read through DP-227 and the conflict register is 38, so both are own dimensions. Employees and org "
               "units are conformed from DP-192, instruments from DP-097, government clients from DP-240, legal entities "
               "and dates from DP-013, funds from DP-004. "
               "Descriptive columns, not joined (02 Party; DP-240 is upstream since W1 but these are left as text "
               "columns until their owners confirm the party keys): Personal Trading Account."
               "Personal Account Broker, Political Contribution.Contribution Recipient, Outside Business Activity.OBA "
               "Organization, Restricted List Entry.Restricted Issuer. "
               "Descriptive columns, not joined (not inputs): Code of Ethics Violation.Violated Policy Version (38 "
               "Policy Version), Source Surveillance Alert (38 Trade Surveillance Alert, published by DP-228, which reads "
               "this product), Conflict Mitigation.Mitigating Policy (38 Policy). "
               "Model gap: 37 Control is not an input, so Control is a surrogate-keyed dimension (see the entity)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-226": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact AML Case", role="Fact", objects=[("38", "AML Case")],
                 pk=["AML Case Number", "As-of Date Key"], measures=True,
                 grain="one row = AML case x as-of date (the product grain)",
                 note="AML Case Type, AML Case Source, AML Case Status and SAR Decision are degenerate dimensions. "
                      "Report and program measures are computed on their own facts and published here."),
            dict(name="Fact AML and Sanctions Report", role="Fact", objects=[("38", "AML and Sanctions Report")],
                 pk=["AML Report Key"],
                 grain="one row = AML or sanctions report (AML Report Key; case x report sequence within a case)",
                 note="SARs, STRs and blocking or rejection reports. Feeds Report Filing Timeliness %, Overdue Reports "
                      "and SAR Conversion Rate."),
            dict(name="Fact AML Program Assessment", role="Fact", objects=[("38", "AML Program Assessment")],
                 pk=["Assessed Entity", "Assessed Fund", "Assessment Year"],
                 grain="one row = assessed entity or fund x assessment year",
                 note="Feeds Independent Test Currency Flag and Program Without Designated Officer."),
            # -- dimensions
            dict(name="Account Monitoring Alert", role="Dimension",
                 objects=[("29", "Account Monitoring Alert"), ("29", "Alert Disposition")],
                 pk=["Account Monitoring Alert ID"],
                 note="Read through DP-180 (a consumer product). The disposition folds here. An escalated alert with no "
                      "case gives Unlinked Escalations."),
            dict(name="Money Movement Monitoring Alert", role="Dimension", objects=[("50", "Money Movement Monitoring Alert")],
                 pk=["Money Movement Monitoring Alert ID"],
                 note="W4 (ruling 2): the 50 brokerage money movement alert links to its case from the alert side "
                      "(Escalated AML Case); no 50 product exists yet, so it is an own dimension."),
            dict(name="Trade Surveillance Alert", role="Dimension", objects=[("38", "Trade Surveillance Alert")],
                 pk=["Trade Surveillance Alert ID"], note="Read through DP-228; an alert source of a case."),
            dict(name="Corporate Officer Appointment", role="Dimension",
                 objects=[("39", "Corporate Officer Appointment")],
                 pk=["Officer Entity", "Corporate Officer Role", "Officer Employee", "Officer Effective From"],
                 note="Read through DP-230; the designated AML officer appointment."),
            dim("Party", PARTY, [("02", "Party"), ("02", "KYC Profile")],
                note="Conformed Party from DP-240 for case subjects and suppliers. The KYC profile folds here (read "
                     "through DP-077); its risk rating gives High-Risk Subject Share % and its screening result "
                     "Unescalated Screening Hits."),
            dim("Supplier Onboarding Case", ("DP-210", "Supplier Onboarding Case"),
                [("40", "Supplier Onboarding Case")],
                note="Conformed from DP-210; sanctions hits at supplier onboarding."),
            dim("Account", ("DP-093", "Account"), [("15", "Account")], note="Conformed Account from DP-093."),
            dim("Employee", EMP, [("20", "Employee")], note="The officer appointed; Employment Status checks a leaver."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Investment Product", PROD, [("01", "Investment Product")], note="The assessed fund."),
            dim("As-of Date", CAL, note="Conformed Calendar Date for the daily snapshot."),
        ],
        relationships=[
            rel("Fact AML Case", "As-of Date", ["As-of Date Key"]),
            rel("Fact AML Case", "Party", ["Source KYC Profile"], optional=True,
                note="The KYC profile is folded into the party it describes."),
            rel("Fact AML Case", "Supplier Onboarding Case", ["Source Supplier Onboarding Case"], optional=True),
            rel("Fact AML Case", "Trade Surveillance Alert", ["Source Trade Surveillance Alert"], optional=True),
            rel("Fact AML Case", "Party", ["Case Subject Parties"], card="M:N"),
            rel("Fact AML Case", "Account", ["Case Subject Accounts"], card="M:N", optional=True),
            rel("Fact AML Case", "Legal Entity", ["Legal Entity Key"], optional=True,
                note="Model gap: AML Case holds no obligated legal entity (the entity whose program files the report), "
                     "so the link to the entity, and through it to the program assessment, is a borrowed key."),
            rel("Fact AML and Sanctions Report", "Fact AML Case", ["Reported Case"], optional=True,
                note="Empty for case-less OFAC blocked and rejected property reports (W4, AML Report Key)."),
            rel("Fact AML Program Assessment", "Legal Entity", ["Assessed Entity"], optional=True),
            rel("Fact AML Program Assessment", "Investment Product", ["Assessed Fund"], optional=True),
            rel("Fact AML Program Assessment", "Corporate Officer Appointment", ["Designated AML Officer"],
                optional=True, note="Empty gives Program Without Designated Officer."),
            rel("Account Monitoring Alert", "Account", ["Alert Account"]),
            rel("Account Monitoring Alert", "Fact AML Case", ["Escalation Case Reference"], optional=True,
                note="The case the alert was escalated to (the only link since W4: 38 AML Case.Source Account "
                     "Monitoring Alert was removed, ruling 2); an escalated alert with no case gives Unlinked Escalations."),
            rel("Money Movement Monitoring Alert", "Fact AML Case", ["Escalated AML Case"], optional=True),
            rel("Supplier Onboarding Case", "Party", ["Onboarding Supplier"]),
            rel("Corporate Officer Appointment", "Legal Entity", ["Officer Entity"]),
            rel("Corporate Officer Appointment", "Employee", ["Officer Employee"]),
        ],
        notes=("AML case register as the snapshot fact, with reports and program assessments as facts at their own "
               "grains. Account monitoring alerts (DP-180), trade surveillance alerts (DP-228) and officer appointments "
               "(DP-230) are consumer-published, so they are own dimensions. Party and the folded KYC profile are "
               "conformed from DP-240, supplier onboarding from DP-210, accounts from DP-093, employees from DP-192, "
               "legal entities and dates from DP-013, funds from DP-004. DP-077 is upstream for the KYC profile only and "
               "publishes no model entity this star needs. Case subjects are restricted (SAR confidentiality). "
               "Model gap: no input carries the obligated legal entity of an AML case; Fact AML Case borrows "
               "\"Legal Entity Key\" so cases can be counted by the entity and fund program assessed (proposed: an "
               "Obligated Entity reference on 38 AML Case)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-227": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Restricted List Entry", role="Fact", objects=[("38", "Restricted List Entry")],
                 pk=["Restricted List Entry ID"], measures=True,
                 grain="one row = restricted list entry (list x issuer x added timestamp), valid from Entry Added "
                       "Timestamp to Entry Removed Timestamp (the product grain)",
                 note="Bitemporal by its valid time; Restriction Reason and Entry Classification are degenerate "
                      "dimensions."),
            dict(name="Restricted Entry Instrument", role="Bridge", objects=[], pk=["Fact Restricted List Entry Key",
                                                                                   "Instrument Key"],
                 grain="one row = restricted list entry x restricted instrument (the intraday current-content view at "
                       "list x issuer x instrument)",
                 note="Resolves the multi-valued Restricted Instruments, expanded from the issuer to every instrument it "
                      "issued. An entry with no row here gives Unexpanded Entry Flag."),
            dict(name="Fact MNPI Escalation", role="Fact", objects=[("38", "MNPI Escalation")],
                 pk=["MNPI Escalation ID"],
                 grain="one row = MNPI escalation (MNPI-)",
                 note="Feeds Escalation-to-Restriction Minutes and Restrict Decision Without Entry. MNPI Source Type and "
                      "MNPI Decision are degenerate dimensions."),
            dict(name="Fact Insider List Entry", role="Fact", objects=[("38", "Insider List Entry")],
                 pk=["Insider List", "Insider Escalation", "Internal Insider", "External Insider",
                     "Access Obtained Timestamp"],
                 grain="one row = insider list x section (escalation) x person x access obtained timestamp",
                 note="Feeds Insider Section Gap and Open Insider Access After Cleansing or Departure."),
            # -- dimensions
            dict(name="Firm Restricted List", role="Dimension", objects=[("38", "Firm Restricted List")],
                 pk=["Restricted List Code"],
                 note="Restricted, watch and insider lists; the insider list is one list type."),
            dim("Instrument", INSTR, [("17", "Instrument")], note="Conformed Instrument from DP-097."),
            dim("Instrument Identifier", ("DP-097", "Instrument Identifier"), [("17", "Instrument Identifier")],
                note="Outrigger of Instrument: the identifiers front-office and surveillance systems match on."),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")], note="Conformed Issuer from DP-098."),
            dim("Party", PARTY, [("02", "Party")],
                note="Conformed Party from DP-240; Merged Into Party gives Entries on Retired Parties. Also the "
                     "external insider."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Internal insiders and MNPI deciders; Employment Status gives departures."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")], note="The entities a list applies to."),
        ],
        relationships=[
            rel("Fact Restricted List Entry", "Firm Restricted List", ["Entry List"]),
            rel("Fact Restricted List Entry", "Issuer", ["Restricted Issuer"]),
            rel("Fact Restricted List Entry", "Fact MNPI Escalation", ["Source MNPI Escalation"], optional=True),
            rel("Restricted Entry Instrument", "Fact Restricted List Entry", ["Fact Restricted List Entry Key"],
                note="Carries the Restricted List Entry ID."),
            rel("Restricted Entry Instrument", "Instrument", ["Instrument Key"], note="Carries the Instrument ID."),
            rel("Fact MNPI Escalation", "Issuer", ["MNPI Issuer"]),
            rel("Fact MNPI Escalation", "Employee", ["MNPI Decided By"], optional=True),
            rel("Fact Insider List Entry", "Firm Restricted List", ["Insider List"]),
            rel("Fact Insider List Entry", "Fact MNPI Escalation", ["Insider Escalation"]),
            rel("Fact Insider List Entry", "Employee", ["Internal Insider"], optional=True),
            rel("Fact Insider List Entry", "Party", ["External Insider"], optional=True),
            rel("Firm Restricted List", "Legal Entity", ["List Scope Entities"], card="M:N"),
            rel("Instrument", "Issuer", ["Issuer"]),
            rel("Instrument Identifier", "Instrument", ["Identified Instrument"]),
            rel("Issuer", "Party", ["Issuer Party"], card="1:1"),
            rel("Party", "Party", ["Merged Into Party"], optional=True),
        ],
        notes=("Restricted list entries as the valid-time fact, expanded to instruments through a bridge, with MNPI "
               "escalations and insider list entries as facts. Instruments and identifiers are conformed from DP-097, "
               "issuers from DP-098, parties from DP-240, employees from DP-192, legal entities from DP-013. "
               "Descriptive columns, not joined: MNPI Escalation.Source Issuer Meeting (23) and Source "
               "Engagement (34), whose products are not upstream. "
               "The Restricted Instruments attribute stays on the fact as delivered; the bridge is its exploded form."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-228": dict(
        # WP1 re-point (CW-208, CW-163): re-cut to the specs_w1c_fop_corp.py DP-228 inputs; see notes.
        style='Star',
        entities=[
            dict(name='Fact Trade Surveillance Alert',
                 role='Fact',
                 objects=[('38', 'Trade Surveillance Alert')],
                 pk=['Trade Surveillance Alert ID', 'As-of Date Key'],
                 measures=True,
                 grain='one row = trade surveillance alert (TRSV-) x as-of date (the product grain)',
                 note='Surveillance Scenario, Surveillance Alert Status and Surveillance Disposition are degenerate dimensions. The subject references are exploded by the three bridges.'),
            dict(name='Alert Subject Order',
                 role='Bridge',
                 objects=[],
                 pk=['Fact Trade Surveillance Alert Key', 'Trade Order Key'],
                 grain='one row = alert x subject order',
                 note='Resolves the multi-valued Subject Trade Orders.'),
            dict(name='Alert Subject Execution',
                 role='Bridge',
                 objects=[],
                 pk=['Fact Trade Surveillance Alert Key', 'Execution Key'],
                 grain='one row = alert x subject execution',
                 note='Resolves the multi-valued Subject Executions.'),
            dict(name='Alert Subject Personal Transaction',
                 role='Bridge',
                 objects=[],
                 pk=['Fact Trade Surveillance Alert Key', 'Personal Transaction Key'],
                 grain='one row = alert x subject personal transaction',
                 note='Resolves the multi-valued Subject Personal Transactions; gives Personal Dealing Alert Share.'),
            dict(name='Trade Order',
                 role='Dimension',
                 objects=[('25', 'Trade Order')],
                 pk=['Trade Order ID'],
                 note='Read through DP-123 (a consumer product), so kept as an own dimension with the 25 key.'),
            dict(name='Execution',
                 role='Dimension',
                 objects=[('25', 'Execution')],
                 pk=['Execution ID'],
                 note='Read through DP-123.'),
            dict(name='Broker Placement',
                 role='Dimension',
                 objects=[('25', 'Broker Placement')],
                 pk=['Placement Block Order', 'Placement Broker', 'Placement Sequence Number'],
                 note='Read through DP-123; gives the executing broker of an execution.'),
            dict(name='Personal Transaction',
                 role='Dimension',
                 objects=[('38', 'Personal Transaction')],
                 pk=['Transaction Account', 'Broker Transaction Reference'],
                 note='Read through DP-225.'),
            dict(name='Restricted List Entry',
                 role='Dimension',
                 objects=[('38', 'Restricted List Entry')],
                 pk=['Restricted List Entry ID'],
                 note="Read through DP-227; an entry valid at the alert's time on a subject instrument gives Alerts on Restricted Names."),
            dict(name='Communications Alert',
                 role='Dimension',
                 objects=[('08', 'Surveillance Alert')],
                 pk=['Alert ID'],
                 note='Read through DP-078 (a consumer product); gives Communications Linkage Rate.'),
            dict(name='Counterparty',
                 role='Dimension',
                 conformed=('DP-115', 'Counterparty'),
                 objects=[],
                 note='Conformed Counterparty from DP-115; the placement broker.'),
            dict(name='Instrument',
                 role='Dimension',
                 conformed=('DP-097', 'Instrument'),
                 objects=[('17', 'Instrument')],
                 note='Conformed Instrument from DP-097.'),
            dict(name='Portfolio',
                 role='Dimension',
                 conformed=('DP-140', 'Portfolio'),
                 objects=[('18', 'Portfolio')],
                 note='Conformed Portfolio from DP-140; business line slicer.'),
            dict(name='Employee',
                 role='Dimension',
                 conformed=('DP-192', 'Employee'),
                 objects=[('20', 'Employee')],
                 note='The assigned trader.'),
            dict(name='Org Unit',
                 role='Dimension',
                 conformed=('DP-192', 'Org Unit'),
                 objects=[('09', 'Org Unit')],
                 note="The trader's desk or team."),
            dict(name='Legal Entity',
                 role='Dimension',
                 conformed=('DP-013', 'Internal Legal Entity'),
                 objects=[],
                 note='The trading and managing entity.'),
            dict(name='As-of Date',
                 role='Dimension',
                 conformed=('DP-013', 'Calendar Date'),
                 objects=[],
                 note='Conformed Calendar Date for the daily snapshot.'),
            dict(name='Account',
                 role='Dimension',
                 conformed=('DP-093', 'Account'),
                 objects=[('15', 'Account')]),
            dict(name='Client Order',
                 role='Dimension',
                 objects=[('48', 'Client Order')],
                 pk=['Client Order ID']),
            dict(name='Client Execution',
                 role='Dimension',
                 objects=[('48', 'Client Execution')],
                 pk=['Client Execution ID']),
            dict(name='AML Case',
                 role='Dimension',
                 objects=[('38', 'AML Case')],
                 pk=['AML Case Number']),
        ],
        relationships=[
            dict(child='Fact Trade Surveillance Alert', parent='As-of Date', fk=['As-of Date Key'], card='M:1'),
            dict(child='Fact Trade Surveillance Alert', parent='Communications Alert', fk=['Related Communications Alert'], card='M:1', optional=True),
            dict(child='Alert Subject Order', parent='Fact Trade Surveillance Alert', fk=['Fact Trade Surveillance Alert Key'], card='M:1', note='Carries the Trade Surveillance Alert ID.'),
            dict(child='Alert Subject Order', parent='Trade Order', fk=['Trade Order Key'], card='M:1', note='Carries the Trade Order ID.'),
            dict(child='Alert Subject Execution', parent='Fact Trade Surveillance Alert', fk=['Fact Trade Surveillance Alert Key'], card='M:1'),
            dict(child='Alert Subject Execution', parent='Execution', fk=['Execution Key'], card='M:1', note='Carries the Execution ID.'),
            dict(child='Alert Subject Personal Transaction', parent='Fact Trade Surveillance Alert', fk=['Fact Trade Surveillance Alert Key'], card='M:1'),
            dict(child='Alert Subject Personal Transaction', parent='Personal Transaction', fk=['Personal Transaction Key'], card='M:1', note='Carries the transaction account and broker transaction reference.'),
            dict(child='Trade Order', parent='Portfolio', fk=['Order Portfolio'], card='M:1'),
            dict(child='Trade Order', parent='Instrument', fk=['Order Instrument'], card='M:1'),
            dict(child='Trade Order', parent='Employee', fk=['Assigned Trader'], card='M:1', optional=True),
            dict(child='Trade Order', parent='Legal Entity', fk=['Trading Legal Entity'], card='M:1', optional=True),
            dict(child='Execution', parent='Broker Placement', fk=['Execution Placement'], card='M:1'),
            dict(child='Broker Placement', parent='Counterparty', fk=['Placement Broker'], card='M:1'),
            dict(child='Personal Transaction', parent='Instrument', fk=['Traded Security'], card='M:1', optional=True),
            dict(child='Restricted List Entry', parent='Instrument', fk=['Restricted Instruments'], card='M:N', optional=True),
            dict(child='Portfolio', parent='Legal Entity', fk=['Managing Entity'], card='M:1', optional=True),
            dict(child='Employee', parent='Org Unit', fk=['Home Org Unit'], card='M:1', optional=True),
            dict(child='Fact Trade Surveillance Alert', parent='Trade Order', fk=['Subject Trade Orders'], card='M:1', optional=True),
            dict(child='Fact Trade Surveillance Alert', parent='Execution', fk=['Subject Executions'], card='M:1', optional=True),
            dict(child='Fact Trade Surveillance Alert', parent='Client Order', fk=['Subject Client Orders'], card='M:1', optional=True),
            dict(child='Fact Trade Surveillance Alert', parent='Client Execution', fk=['Subject Client Executions'], card='M:1', optional=True),
            dict(child='Fact Trade Surveillance Alert', parent='Personal Transaction', fk=['Subject Personal Transactions'], card='M:1', optional=True),
            dict(child='Client Order', parent='Account', fk=['Order Account'], card='M:1', optional=True),
            dict(child='Client Order', parent='Instrument', fk=['Order Instrument'], card='M:1', optional=True),
            dict(child='AML Case', parent='Fact Trade Surveillance Alert', fk=['Source Trade Surveillance Alert'], card='M:1', optional=True),
        ],
        notes="W4 re-point (CW-938): Fact STOR is removed with 38 Suspicious Transaction and Order Report (WP0 re-scope to surveillance and AML escalation). Alert register as the snapshot fact, with three bridges for the alert's subjects (the spec's bridge rows). Orders, executions and placements (DP-123), personal transactions (DP-225), restricted list entries (DP-227) and communications alerts (DP-078) are consumer-published, so they are own dimensions. Counterparties are conformed from DP-115, instruments from DP-097, portfolios from DP-140, employees and org units from DP-192, legal entities and dates from DP-013. Descriptive columns, not joined: Broker Placement.Placement Block Order (25 Block Order), Personal Transaction.Transaction Account (38 Personal Trading Account) and Restricted List Entry.Restricted Issuer (02 Party), none of which is an input; restricted names are matched on instruments. The subject reference attributes stay on the fact as delivered; the bridges are their exploded form. WP1 re-point (CW-208, CW-163): re-cut to Trade Surveillance & Suspicious Activity Reporting. The wholesale entities keep their objects; Counterparty (DP-115) no longer holds 25 Approved Counterparty Profile (dropped from the inputs). The brokerage surveillance inputs are placed: 48 Client Order and Client Execution (the client order book, DP-301), 15 Account conformed from DP-093 and 38 AML Case.",
    ),

    # ======================================== 39 Legal & Corporate Governance =========================================
    "DP-229": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Legal Matter", role="Fact", objects=[("39", "Legal Matter")],
                 pk=["Legal Matter ID", "As-of Date Key"], measures=True,
                 grain="one row = legal matter (LMAT-) x as-of date (the product grain)",
                 note="Legal Matter Type, Forum Type, Matter Status and Matter Significance are degenerate dimensions. "
                      "Privileged matters (Privilege Indicator = Y) are excluded from wide aggregates. Measures on the "
                      "child grains are computed there and published here."),
            dict(name="Fact Matter Event", role="Fact", objects=[("39", "Matter Event")],
                 pk=["Event Matter", "Matter Event Sequence"],
                 grain="one row = legal matter x event sequence", note="Feeds Upcoming Deadlines."),
            dict(name="Fact Matter Financial Assessment", role="Fact", objects=[("39", "Matter Financial Assessment")],
                 pk=["Assessed Matter", "Assessment Reporting Entity", "Assessment Date"],
                 grain="one row = legal matter x reporting entity x assessment date",
                 note="Feeds Legal Reserve Assessed, Reasonably Possible Exposure, Reserve Booking Variance and "
                      "Unbooked Reserve Flag. The assessed reserve is Legal's view, never certified expense."),
            dict(name="Fact Outside Counsel Engagement", role="Fact", objects=[("39", "Outside Counsel Engagement")],
                 pk=["Engagement Letter", "Engaged Matter"],
                 grain="one row = engagement letter x legal matter",
                 note="Feeds Budget Consumption % (with the approved invoice amounts)."),
            dict(name="Fact Outside Counsel Invoice Review", role="Fact",
                 objects=[("39", "Outside Counsel Invoice Review")],
                 pk=["Reviewed Engagement", "Counsel Invoice Number"],
                 grain="one row = outside counsel engagement x counsel invoice",
                 note="Feeds Outside Counsel Approved Amount and Invoice Reduction Rate. Reviewed Engagement holds the "
                      "engagement letter of a matter's engagement."),
            dict(name="Fact GL Posting", role="Fact", objects=[("19", "GL Posting")],
                 pk=["Journal ID", "Journal Line Number"],
                 grain="one row = journal x journal line",
                 note="Read from DP-191 (same key). Legal expense postings sourced from counsel invoices give Counsel "
                      "Spend Reconciliation Difference; reserve journal lines give the booked reserve."),
            dict(name="Fact Legal Service Request", role="Fact", objects=[("39", "Legal Service Request")],
                 pk=["Legal Request Number"],
                 grain="one row = legal service request", note="Feeds Legal Request Cycle Time."),
            dict(name="Fact Legal Hold", role="Fact", objects=[("39", "Legal Hold")], pk=["Legal Hold ID"],
                 grain="one row = legal hold (LHOLD-)", note="Feeds Hold Issuance Lag."),
            dict(name="Fact Legal Hold Custodian", role="Fact", objects=[("39", "Legal Hold Custodian")],
                 pk=["Custodian Hold", "Custodian Employee"],
                 grain="one row = legal hold x custodian",
                 note="Feeds Custodian Acknowledgment % and Departing Custodian Flag."),
            dict(name="Fact Legal Hold Scope", role="Fact", objects=[("39", "Legal Hold Scope")],
                 pk=["Scope Hold", "Hold Scope Type", "Scoped Retention Rule", "Scoped Application", "Scoped Data Asset",
                     "Scoped Party", "Scope Date From"],
                 grain="one row = legal hold x scope (retention rule, application, data asset or party) x scope date "
                       "from",
                 note="Feeds Scope Without Disposal Suspension and Held Application Retirement Risk."),
            dict(name="Matter Party", role="Bridge", objects=[("39", "Matter Party")],
                 pk=["Party Matter", "Matter Party Role", "External Matter Party", "Internal Matter Entity"],
                 grain="one row = legal matter x party role x party (external party or internal entity)",
                 note="Model gap: the registry key adds Employee Matter Party, which is not a product input, so employee "
                      "parties to a matter are not distinguished."),
            # -- dimensions
            dict(name="Payable Invoice", role="Dimension", objects=[("19", "Payable Invoice")],
                 pk=["Payable Invoice ID"],
                 note="Read from 19 directly: no foundational product publishes payables (spec note)."),
            dim("Journal Entry", ("DP-191", "Journal Entry"), [("19", "Journal Entry")],
                note="Conformed Journal Entry from DP-191; the booked reserve journal."),
            dim("GL Account", ("DP-191", "GL Account"), note="Conformed GL Account from DP-191."),
            dim("Contract", CONTRACT, [("39", "Contract")],
                note="Conformed Contract from DP-213: engagement letters and contracts resulting from requests."),
            dim("Application", ("DP-211", "Application"), [("41", "Application")],
                note="Conformed Application from DP-211; Decommission Date gives Held Application Retirement Risk."),
            dim("Employee Lifecycle Event", ("DP-192", "Employee Lifecycle Event"),
                [("20", "Employee Lifecycle Event")],
                note="Conformed from DP-192; a leaver event for a custodian gives Departing Custodian Flag."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Plays the responsible lawyer, requester, assigned lawyer, issuing lawyer and custodian roles."),
            dim("Party", PARTY, [("02", "Party")],
                note="Conformed Party from DP-240: counsel firms, suppliers, scoped and external matter parties."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("As-of Date", CAL, note="Conformed Calendar Date for the daily snapshot."),
        ],
        relationships=[
            rel("Fact Legal Matter", "As-of Date", ["As-of Date Key"]),
            rel("Fact Legal Matter", "Employee", ["Responsible Lawyer"], optional=True),
            rel("Matter Party", "Fact Legal Matter", ["Party Matter"]),
            rel("Matter Party", "Party", ["External Matter Party"], optional=True),
            rel("Matter Party", "Legal Entity", ["Internal Matter Entity"], optional=True),
            rel("Fact Matter Event", "Fact Legal Matter", ["Event Matter"]),
            rel("Fact Matter Financial Assessment", "Fact Legal Matter", ["Assessed Matter"]),
            rel("Fact Matter Financial Assessment", "Legal Entity", ["Assessment Reporting Entity"]),
            rel("Fact Matter Financial Assessment", "Journal Entry", ["Reserve Journal Entry"], optional=True,
                note="Empty on a probable, estimable matter gives Unbooked Reserve Flag."),
            rel("Fact Outside Counsel Engagement", "Fact Legal Matter", ["Engaged Matter"]),
            rel("Fact Outside Counsel Engagement", "Party", ["Outside Counsel Firm"]),
            rel("Fact Outside Counsel Engagement", "Contract", ["Engagement Letter"]),
            rel("Fact Outside Counsel Invoice Review", "Fact Outside Counsel Engagement", ["Reviewed Engagement"]),
            rel("Fact Outside Counsel Invoice Review", "Payable Invoice", ["Payable Invoice"], optional=True),
            rel("Payable Invoice", "Party", ["Supplier"]),
            rel("Payable Invoice", "Legal Entity", ["Invoice Legal Entity"]),
            rel("Fact GL Posting", "Journal Entry", ["Journal ID"]),
            rel("Fact GL Posting", "GL Account", ["Posted Account"]),
            rel("Fact GL Posting", "Payable Invoice", ["Source Payable Invoice"], optional=True),
            rel("Journal Entry", "Legal Entity", ["Posting Legal Entity"]),
            rel("Fact Legal Service Request", "Employee", ["Requesting Employee"]),
            rel("Fact Legal Service Request", "Employee", ["Assigned Lawyer"], optional=True),
            rel("Fact Legal Service Request", "Contract", ["Resulting Contract"], optional=True),
            rel("Fact Legal Hold", "Fact Legal Matter", ["Hold Matter"], optional=True,
                note="A hold may instead be issued for an examination."),
            rel("Fact Legal Hold", "Employee", ["Issuing Lawyer"], optional=True),
            rel("Fact Legal Hold Custodian", "Fact Legal Hold", ["Custodian Hold"]),
            rel("Fact Legal Hold Custodian", "Employee", ["Custodian Employee"]),
            rel("Fact Legal Hold Scope", "Fact Legal Hold", ["Scope Hold"]),
            rel("Fact Legal Hold Scope", "Application", ["Scoped Application"], optional=True),
            rel("Fact Legal Hold Scope", "Party", ["Scoped Party"], optional=True),
            rel("Employee Lifecycle Event", "Employee", ["Event Employee"]),
        ],
        notes=("Matter register as the snapshot fact, with events, financial assessments, counsel engagements and "
               "invoice reviews under it, and legal service requests and legal holds (with custodians and scopes) as "
               "facts at their own grains. Journal entries and GL accounts are conformed from DP-191, contracts from DP-213, "
               "applications from DP-211, employees and lifecycle events from DP-192, parties from DP-240, legal "
               "entities and dates from DP-013. "
               "Descriptive columns, not joined: Legal Matter.Originating Examination and Legal Hold.Hold Examination "
               "(38 Regulatory Examination, not an input; DP-223 counts the referral), Legal Hold Scope.Scoped Retention "
               "Rule (21 Retention Rule, RET-, since W4) and Scoped Data Asset (21 Data Asset), neither an input."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-230": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Entity Governance", role="Fact", objects=[],
                 pk=["Legal Entity Key", "As-of Date Key"], measures=True,
                 grain="one row = internal legal entity x as-of date (the product grain)",
                 note="An entity-level snapshot with no input of its own: its measures are computed from the child "
                      "facts (bodies, officers, meetings, resolutions, filings, powers and signing authorities)."),
            dict(name="Fact Corporate Body Membership", role="Fact", objects=[("39", "Corporate Body Membership")],
                 pk=["Membership Body", "Member Employee", "Member External Party", "Corporate Member Role",
                     "Membership Effective From"],
                 grain="one row = governing body x member x role x effective period",
                 note="Feeds Independent Member Share % and Departed Officer or Member Flag."),
            dict(name="Fact Corporate Officer Appointment", role="Fact",
                 objects=[("39", "Corporate Officer Appointment")],
                 pk=["Officer Entity", "Corporate Officer Role", "Officer Employee", "Officer Effective From"],
                 grain="one row = entity x officer role x officer x effective period",
                 note="Feeds Vacant Officer Role Flag and Officer Change Notification Gap."),
            dict(name="Fact Corporate Board Meeting", role="Fact", objects=[("39", "Corporate Board Meeting")],
                 pk=["Meeting Body", "Corporate Meeting Date", "Corporate Meeting Sequence"],
                 grain="one row = governing body x meeting date x sequence",
                 note="Feeds Missed Meeting Flag, Inquorate Meetings and Minutes Pending."),
            dict(name="Fact Corporate Resolution", role="Fact", objects=[("39", "Corporate Resolution")],
                 pk=["Corporate Resolution ID"],
                 grain="one row = corporate resolution (CGRES-)",
                 note="Corporate Resolution Outcome is a degenerate dimension."),
            dict(name="Corporate Resolution Subject Link", role="Bridge",
                 objects=[("39", "Corporate Resolution Subject Link")],
                 pk=["Corporate Resolution Subject Link Key"],
                 grain="one row = corporate resolution x approved subject",
                 note="Surrogate key, as in the registry. Corporate Resolution Subject Type gives Resolutions Adopted by "
                      "Subject; a grant or power with no approving resolution gives Unapproved Authority Flag."),
            dict(name="Fact Entity Statutory Filing", role="Fact", objects=[("39", "Entity Statutory Filing")],
                 pk=["Filing Entity", "Statutory Filing Type", "Filing Period End"],
                 grain="one row = entity x statutory filing type x period end",
                 note="Feeds Statutory Filing Timeliness % and Overdue Statutory Filings."),
            dict(name="Fact Power of Attorney", role="Fact", objects=[("39", "Power of Attorney")],
                 pk=["Power of Attorney ID"], grain="one row = power of attorney (POWER-)"),
            dict(name="Fact Signing Authority Grant", role="Fact", objects=[("39", "Signing Authority Grant")],
                 pk=["Authorized Employee", "Authority Type", "Authority Entity", "Grant Effective From"],
                 grain="one row = employee x authority type x entity x effective period",
                 note="Feeds Active Signing Authorities and Departed Signatory Flag."),
            # -- dimensions
            dict(name="Corporate Governing Body", role="Dimension", objects=[("39", "Corporate Governing Body")],
                 pk=["Corporate Body ID"],
                 note="Boards, committees and management bodies (CGOV-); an entity with no active body gives Entities "
                      "Without Active Body."),
            dict(name="Firm Regulatory Filing", role="Dimension", objects=[("38", "Firm Regulatory Filing")],
                 pk=["Firm Filing ID"],
                 note="Read through DP-222 (a consumer product); the regulatory notification of an officer change."),
            dim("Contract", CONTRACT, [("39", "Contract")], note="Conformed Contract from DP-213; approved contracts."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", EMP, [("20", "Employee")],
                note="Members, officers, attorneys and signatories; Employment Status gives departures."),
            dim("Party", PARTY, [("02", "Party")], note="External board members and external attorneys."),
            dim("As-of Date", CAL, note="Conformed Calendar Date for the daily snapshot."),
        ],
        relationships=[
            rel("Fact Entity Governance", "Legal Entity", ["Legal Entity Key"], note="Carries the Legal Entity ID."),
            rel("Fact Entity Governance", "As-of Date", ["As-of Date Key"]),
            rel("Corporate Governing Body", "Legal Entity", ["Governed Entity"]),
            rel("Corporate Governing Body", "Corporate Governing Body", ["Parent Corporate Body"], optional=True,
                note="A committee's parent board."),
            rel("Fact Corporate Body Membership", "Corporate Governing Body", ["Membership Body"]),
            rel("Fact Corporate Body Membership", "Employee", ["Member Employee"], optional=True),
            rel("Fact Corporate Body Membership", "Party", ["Member External Party"], optional=True),
            rel("Fact Corporate Officer Appointment", "Legal Entity", ["Officer Entity"]),
            rel("Fact Corporate Officer Appointment", "Employee", ["Officer Employee"]),
            rel("Fact Corporate Officer Appointment", "Firm Regulatory Filing", ["Regulatory Notification Filing"],
                optional=True, note="Empty where a notification is required gives Officer Change Notification Gap."),
            rel("Fact Corporate Board Meeting", "Corporate Governing Body", ["Meeting Body"]),
            rel("Fact Corporate Resolution", "Fact Corporate Board Meeting", ["Adopting Corporate Meeting"]),
            rel("Fact Corporate Resolution", "Fact Corporate Resolution", ["Superseded Corporate Resolution"],
                optional=True),
            rel("Corporate Resolution Subject Link", "Fact Corporate Resolution", ["Linked Corporate Resolution"]),
            rel("Corporate Resolution Subject Link", "Contract", ["Subject Contract"], optional=True),
            rel("Corporate Resolution Subject Link", "Fact Corporate Body Membership", ["Subject Body Membership"],
                optional=True),
            rel("Corporate Resolution Subject Link", "Fact Corporate Officer Appointment",
                ["Subject Officer Appointment"], optional=True),
            rel("Corporate Resolution Subject Link", "Fact Power of Attorney", ["Subject Power of Attorney"],
                optional=True),
            rel("Corporate Resolution Subject Link", "Fact Signing Authority Grant", ["Subject Authority Grant"],
                optional=True),
            rel("Fact Entity Statutory Filing", "Legal Entity", ["Filing Entity"]),
            rel("Fact Power of Attorney", "Legal Entity", ["Grantor Entity"]),
            rel("Fact Power of Attorney", "Employee", ["Attorney Employee"], optional=True),
            rel("Fact Power of Attorney", "Party", ["Attorney Party"], optional=True),
            rel("Fact Signing Authority Grant", "Employee", ["Authorized Employee"]),
            rel("Fact Signing Authority Grant", "Legal Entity", ["Authority Entity"]),
        ],
        notes=("Entity governance snapshot as the product-grain fact, with bodies, memberships, officers, meetings, "
               "resolutions, statutory filings, powers of attorney and signing authorities at their own grains. Firm "
               "regulatory filings are read through DP-222, so they are an own dimension. Legal entities and dates are "
               "conformed from DP-013, contracts from DP-213, employees from DP-192, parties from DP-240. "
               "Descriptive columns, not joined: Corporate Resolution Subject Link.Subject Risk Appetite Statement and "
               "Subject Audit Plan (37), Subject Policy Version (38), Subject Debt Facility, Subject Capital Transaction "
               "(43) and Subject Corporate Publication (42), none of which is an input (Subject ICARA Assessment left with CW-939); "
               "Subject Description and Corporate Resolution Subject Type describe them."),
    ),
}
