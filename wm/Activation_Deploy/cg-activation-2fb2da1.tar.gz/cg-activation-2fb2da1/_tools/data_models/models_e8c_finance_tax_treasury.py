"""Logical data models: Wave E8 consumer Star models for the finance, tax and treasury products (DP-193 to DP-196 owned
by 19 Finance & Accounting; DP-202 to DP-206 owned by 43 Corporate Treasury & Capital). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here ("Legal
  Entity" is DP-013 Internal Legal Entity; "Close Task Owner" and "Signatory Employee" are DP-192 Employee). Product
  input objects of the same concept sit on the conformed entity and merge with its inherited attributes.
- Foundational facts the products read (DP-191 GL Account Balance, DP-190 Accounting Period Status, DP-007 Position,
  DP-012 Fee Revenue Record, DP-165 NAV records, DP-116 Investor Capital Account, DP-142 Portfolio Valuation Summary,
  DP-192 Employee Job Assignment) are declared conformed with role Fact, so their rows and keys match the system of
  record row for row.
- Objects that only consumer products publish (19 close, consolidation, statements, AP / AR, tax; 43 bank, cash, debt,
  hedging, seed, capital and insurance objects; 10 intercompany agreements from DP-074) are built from the product's own
  inputs with the registry's natural keys, so they still join across DP-193 to DP-206.
- Where a reference attribute's REFS target is held by the parent (directly or through its conformed source), the
  attribute itself is the foreign key. Where no input attribute carries the link, the child borrows "<Parent> Key" and
  the notes record a "Model gap".
- Date roles are conformed from DP-013 Calendar Date (firm business calendar); a date attribute on a fact is the
  foreign key. Period attributes that carry a fiscal period code join DP-013 Fiscal Period.
- Where the spec grain spans several facts at different grains, measures sit on a factless summary spine keyed by its
  dimensions (legal entity x as-of date or fiscal period); the detail facts keep their own grains.
- Multi-valued references (Lender Parties, Hedging Treasury Deals, Named Insured Entities, Covered Intercompany
  Agreements, Plan Segment Values) are drawn as M:N relationships; the build explodes them into one row per member.
- Reference attributes whose target no upstream product publishes stay degenerate on the fact and are named in the notes.
"""


def dim(name, src, objects=(), note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)


def cfact(name, src, objects, grain, role="Fact", note="", measures=False):
    """A conformed fact or bridge: rows and key of the foundational entity src, read at its own grain."""
    return dict(name=name, role=role, conformed=src, objects=list(objects), grain=grain, measures=measures, note=note)


def ent(name, role, objects, pk, grain="", note="", measures=False):
    """An entity built from the product's own inputs."""
    return dict(name=name, role=role, objects=list(objects), pk=list(pk), grain=grain, measures=measures, note=note)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources
LE = ("DP-013", "Internal Legal Entity")
FP = ("DP-013", "Fiscal Period")
CAL = ("DP-013", "Calendar Date")
CCY = ("DP-013", "Currency")
FXT = ("DP-013", "FX Rate Type")
EOR = ("DP-013", "Entity Ownership Relationship")
AUTH = ("DP-013", "Entity Authorization")
GLA = ("DP-190", "GL Account")
LDG = ("DP-190", "Ledger")
CC = ("DP-190", "Cost Center")
ORG = ("DP-190", "Org Unit")
FSL = ("DP-190", "Financial Statement Line")
FSLM = ("DP-190", "Financial Statement Line Mapping")
APS = ("DP-190", "Accounting Period Status")
GLAB = ("DP-191", "GL Account Balance")
JE = ("DP-191", "Journal Entry")
EMP = ("DP-192", "Employee")
WFP = ("DP-192", "Workforce Position")
EJA = ("DP-192", "Employee Job Assignment")
VEND = ("DP-210", "Vendor")
CONTRACT = ("DP-213", "Contract")
PARTY = ("DP-240", "Party")
CPTY = ("DP-115", "Counterparty")
CPTY_SCOPE = ("DP-115", "Counterparty Approval Scope")
TA = ("DP-147", "Trading Agreement")
FXO = ("DP-143", "FX Rate Observation")
RRF = ("DP-143", "Reference Rate Fixing")
PROD = ("DP-004", "Investment Product")
SHARE = ("DP-004", "Share Class")
PORT = ("DP-140", "Portfolio")
PVS = ("DP-142", "Portfolio Valuation Summary")
SCNAV = ("DP-165", "Share Class NAV")
FNAV = ("DP-165", "Fund NAV Calculation")
BOOK = ("DP-165", "Fund Accounting Book")
ACCT = ("DP-093", "Account")
POS = ("DP-007", "Position")
FRR = ("DP-012", "Fee Revenue Record")

GLAB_GRAIN = "one row = ledger x account combination x fiscal period x balance type x balance currency (DP-191)"
FSLM_GRAIN = "one row = GL account x financial statement line x mapping effective period (DP-190)"

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-193": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Statement Line Value", "Fact", [("19", "Financial Statement Line Value")],
                ["Line Financial Statement", "Value Statement Line"], measures=True,
                grain="one row = financial statement (reporting entity or group x framework x statement type x period) x "
                      "statement line",
                note="The statements grain of the product. Holds the measures because the close, intercompany and scope "
                     "facts all answer whether these line values can be approved; Statement-to-Ledger Difference "
                     "compares each row with the DP-191 balances mapped through the line mapping bridge."),
            ent("Fact Close Task", "Fact", [("19", "Close Task")],
                ["Close Cycle Period", "Close Task Ledger", "Close Task ID"],
                grain="one row = close cycle (fiscal period) x ledger x close task",
                note="Overdue and key-control task counts and Close Task Completion %. Due Workday is a close workday "
                     "number (workday -3 to +15), so it stays on the fact and is resolved to a date through the DP-013 "
                     "business calendar at the close cycle's period end."),
            cfact("Accounting Period Status", APS, [("19", "Accounting Period Status")],
                  "one row = ledger x fiscal period (close status)",
                  note="Conformed from DP-190, which masters period status; Days to Hard Close and Reopened Periods."),
            ent("Fact Intercompany Balance", "Fact", [("19", "Intercompany Balance")],
                ["Reporting Entity", "Counterparty Entity", "Intercompany GL Account", "Intercompany Period"],
                grain="one row = reporting entity x counterparty entity x intercompany GL account x fiscal period",
                note="Built from the input: no foundational product publishes intercompany matching. Both sides of a "
                     "pair are rows (DQ rule), so the two Legal Entity roles are separate relationships."),
            ent("Fact Consolidation Scope", "Fact", [("19", "Consolidation Scope Entity")],
                ["Consolidation Group", "Scope Legal Entity", "Consolidated Fund Product", "Seed Portfolio",
                 "Scope Fiscal Period"],
                grain="one row = consolidation group x consolidated unit (legal entity, fund product or seed portfolio) "
                      "x fiscal period",
                note="Exactly one of the three unit references is populated per row (DQ rule), so each unit "
                     "relationship is optional. Consolidation Group is a code and stays degenerate."),
            cfact("GL Account Balance", GLAB, [("19", "GL Account Balance")], GLAB_GRAIN,
                  note="Conformed from DP-191: the certified balances the statement lines must equal (CD-340) and the "
                       "population of Balance Sheet Reconciliation Completion %."),
            ent("Fact Seed Product Holding", "Fact", [("43", "Seed Product Holding")],
                ["Held Seeded Product", "Ownership Measurement Date"],
                grain="one row = seeded product x ownership measurement date",
                note="Read from DP-204 (a consumer product, so built from the input with the registry key) for the "
                     "consolidation trigger and the ownership tie-out; this product never revalues seed (CD-276)."),
            # -- bridges
            cfact("Statement Line Mapping", FSLM, [("19", "Financial Statement Line Mapping")], FSLM_GRAIN,
                  role="Bridge",
                  note="Many GL accounts map to one statement line and the mapping is effective-dated, so the ledger "
                       "balances reach the statement lines through this bridge at the Statement Period End Date."),
            cfact("Entity Ownership", EOR, [("09", "Entity Ownership Relationship")],
                  "one row = child entity x parent entity x relationship type x ownership effective period",
                  role="Bridge",
                  note="Conformed from DP-013; the legal entity tree used for Subsidiaries Missing From Scope."),
            # -- dimensions
            ent("Financial Statement", "Dimension", [("19", "Financial Statement")], ["Financial Statement ID"],
                note="Built from the input: no foundational product publishes 19 Financial Statement. Statement "
                     "Auditor stays degenerate (see notes)."),
            dim("Financial Statement Line", FSL, [("19", "Financial Statement Line")]),
            dim("GL Account", GLA, [("19", "GL Account")]),
            dim("Ledger", LDG, [("19", "Ledger")]),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")],
                note="Reporting entity, counterparty entity, ledger entity and consolidated legal entity roles."),
            dim("Fiscal Period", FP, [("09", "Fiscal Period")],
                note="Close cycle, balance, intercompany and scope periods all carry the fiscal period code."),
            dim("Close Task Owner", EMP,
                note="The only PII in the product; the wide BI view drops this dimension (spec)."),
            dim("Consolidated Fund Product", PROD),
            dim("Seed Portfolio", PORT),
            dim("Journal Entry", JE, note="The elimination journal of an intercompany pair."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Statement Line Value", "Financial Statement", ["Line Financial Statement"]),
            rel("Fact Statement Line Value", "Financial Statement Line", ["Value Statement Line"]),
            rel("Financial Statement", "Legal Entity", ["Statement Reporting Entity"],
                note="For a consolidated statement the reporting entity is the group parent."),
            rel("Financial Statement", "Calendar Date", ["Statement Period End Date"]),
            rel("Statement Line Mapping", "Financial Statement Line", ["Mapped Statement Line"]),
            rel("Statement Line Mapping", "GL Account", ["Mapped GL Account"]),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("Ledger", "Legal Entity", ["Ledger Legal Entity"]),
            rel("Accounting Period Status", "Ledger", ["Status Ledger"]),
            rel("Accounting Period Status", "Fiscal Period", ["Status Fiscal Period"]),
            rel("Accounting Period Status", "Calendar Date", ["Hard Close Date"], optional=True,
                note="Empty until the ledger is hard-closed."),
            rel("Fact Close Task", "Ledger", ["Close Task Ledger"]),
            rel("Fact Close Task", "Fiscal Period", ["Close Cycle Period"]),
            rel("Fact Close Task", "Close Task Owner", ["Close Task Owner"]),
            rel("Fact Intercompany Balance", "Legal Entity", ["Reporting Entity"]),
            rel("Fact Intercompany Balance", "Legal Entity", ["Counterparty Entity"]),
            rel("Fact Intercompany Balance", "GL Account", ["Intercompany GL Account"]),
            rel("Fact Intercompany Balance", "Fiscal Period", ["Intercompany Period"]),
            rel("Fact Intercompany Balance", "Journal Entry", ["Elimination Journal"], optional=True),
            rel("Fact Consolidation Scope", "Legal Entity", ["Scope Legal Entity"], optional=True),
            rel("Fact Consolidation Scope", "Consolidated Fund Product", ["Consolidated Fund Product"], optional=True),
            rel("Fact Consolidation Scope", "Seed Portfolio", ["Seed Portfolio"], optional=True),
            rel("Fact Consolidation Scope", "Fiscal Period", ["Scope Fiscal Period"]),
            rel("Fact Seed Product Holding", "Consolidated Fund Product", ["Held Seeded Product"],
                note="Matched to Consolidated Fund Product for the trigger and ownership checks."),
            rel("Fact Seed Product Holding", "Calendar Date", ["Ownership Measurement Date"]),
            rel("Entity Ownership", "Legal Entity", ["Child Entity"]),
            rel("Entity Ownership", "Legal Entity", ["Parent Entity"]),
            rel("Fiscal Period", "Calendar Date", ["Period End Date"],
                note="Business days from period end drive Days to Hard Close."),
        ],
        notes=("Controller's close and statements view as a constellation: statement line values (the product grain, "
               "holding the measures), close tasks, period status, intercompany balances and consolidation scope, each at "
               "its own grain, sharing the conformed Ledger, GL Account, Legal Entity and Fiscal Period dimensions. Ledger "
               "balances (DP-191) reach statement lines through the DP-190 mapping bridge, which is how "
               "Statement-to-Ledger Difference is formed; no statement number is owned here (CD-340). Seed ownership is "
               "read from DP-204's Seed Product Holding, built from the input because DP-204 is a consumer product. "
               "Model gap: Statement Auditor references 02 Party, but no product in the spec's upstream publishes Party "
               "(DP-240 is not listed), so the auditor stays degenerate on Financial Statement. "
               "Consolidation Group, Consolidation Method, Control Assessment Basis, Statement Reporting Framework and "
               "Financial Statement Type are codes and stay degenerate."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-194": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Financial Plan Line", "Fact", [("19", "Financial Plan Line")],
                ["Line Plan Version", "Plan Legal Entity", "Plan GL Account", "Plan Segment Values", "Plan Line Period"],
                measures=True,
                grain="one row = plan version x legal entity x account combination (GL account x segment values) x "
                      "fiscal period",
                note="The plan side of the product grain (budget, forecasts, long-range plan, planned FTE). Holds the "
                     "measures because every variance is stated against a plan version; actuals come from the "
                     "conformed GL Account Balance at the same legal entity x GL account x fiscal period grain."),
            cfact("GL Account Balance", GLAB, [("19", "GL Account Balance")], GLAB_GRAIN,
                  note="Conformed from DP-191: the actual side of the grain. Revenue, operating expense and operating "
                       "income stay DP-191's certified numbers."),
            cfact("Accounting Period Status", APS, [("19", "Accounting Period Status")],
                  "one row = ledger x fiscal period (close status)",
                  note="Actuals are read only for hard-closed periods; later periods take the forecast."),
            ent("Fact Distribution Plan Line", "Fact", [("10", "Plan Line")],
                ["Distribution Plan Version Key", "Plan P&L Line", "Plan Cost Center", "Plan Period"],
                grain="one row = distribution plan version x plan P&L line x cost center x plan period",
                note="The distribution plan rolled into the enterprise plan (Distribution Plan Roll-In Difference). "
                     "Model gap: 10 Plan Line carries no plan version attribute in the inputs, so Distribution Plan "
                     "Version Key is borrowed; Plan Dimension Members (part of the registry key) is not an input, so "
                     "rows are read summed over dimension members."),
            cfact("Fact Job Assignment", EJA, [("20", "Employee Job Assignment")],
                  "one row = employee x workforce position (or job profile) x assignment type x effective period "
                  "(DP-192)",
                  note="Conformed from DP-192 so Certified FTE matches the employee master; FTE at legal entity x cost "
                       "center x fiscal period end is reached through Workforce Position."),
            # -- bridges
            cfact("Statement Line Mapping", FSLM, [("19", "Financial Statement Line Mapping")], FSLM_GRAIN,
                  role="Bridge",
                  note="Maps GL accounts to the statement lines the P&L is reported by; Unmapped Plan Amount counts plan "
                       "lines whose account has no effective mapping."),
            # -- dimensions
            ent("Financial Plan Version", "Dimension", [("19", "Financial Plan Version")], ["Financial Plan Version ID"],
                note="Built from the input: no foundational product publishes plan versions."),
            ent("Distribution Plan Version", "Dimension", [("10", "Plan Version")], ["Plan Version ID"],
                note="Built from the input; Enterprise Financial Plan Version links it to the 19 plan it rolls into."),
            dim("GL Account", GLA, [("19", "GL Account")]),
            dim("Financial Statement Line", FSL,
                note="Not an input object; conformed from DP-190 so the P&L line of the grain has its labels."),
            dim("Ledger", LDG, [("19", "Ledger")]),
            dim("Cost Center", CC, [("19", "Chart Segment Value")],
                note="Chart Segment Value from DP-190; Plan Segment Values and Position Cost Center resolve here."),
            dim("Org Unit", ORG,
                note="The distribution plan states its cost center as an org unit (REFS), conformed from DP-190."),
            dim("Workforce Position", WFP, [("20", "Workforce Position")],
                note="Authorized FTE by legal entity and cost center."),
            dim("Legal Entity", LE),
            dim("Fiscal Period", FP, [("09", "Fiscal Period")]),
        ],
        relationships=[
            rel("Fact Financial Plan Line", "Financial Plan Version", ["Line Plan Version"]),
            rel("Fact Financial Plan Line", "Legal Entity", ["Plan Legal Entity"]),
            rel("Fact Financial Plan Line", "GL Account", ["Plan GL Account"]),
            rel("Fact Financial Plan Line", "Cost Center", ["Plan Segment Values"], card="M:N",
                note="Multi-valued: one row per segment value; the cost center segment is the one the grain uses."),
            rel("Fact Financial Plan Line", "Fiscal Period", ["Plan Line Period"]),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("Ledger", "Legal Entity", ["Ledger Legal Entity"]),
            rel("Accounting Period Status", "Ledger", ["Status Ledger"]),
            rel("Accounting Period Status", "Fiscal Period", ["Status Fiscal Period"]),
            rel("Statement Line Mapping", "GL Account", ["Mapped GL Account"]),
            rel("Statement Line Mapping", "Financial Statement Line", ["Mapped Statement Line"]),
            rel("Cost Center", "Org Unit", ["Represented Org Unit"], optional=True),
            rel("Cost Center", "Legal Entity", ["Represented Legal Entity"], optional=True),
            rel("Distribution Plan Version", "Financial Plan Version", ["Enterprise Financial Plan Version"],
                optional=True),
            rel("Fact Distribution Plan Line", "Distribution Plan Version", ["Distribution Plan Version Key"]),
            rel("Fact Distribution Plan Line", "Org Unit", ["Plan Cost Center"]),
            rel("Fact Distribution Plan Line", "Fiscal Period", ["Plan Period"], optional=True,
                note="Plan Period carries the fiscal period code of a monthly plan."),
            rel("Workforce Position", "Legal Entity", ["Position Legal Entity"]),
            rel("Workforce Position", "Cost Center", ["Position Cost Center"]),
            rel("Workforce Position", "Fact Financial Plan Line", ["Budget Plan Line"], optional=True,
                note="Budget Plan Line names the plan line that funds the position; the line's composite key is "
                     "resolved from the reference."),
            rel("Fact Job Assignment", "Workforce Position", ["Assigned Workforce Position"], optional=True),
        ],
        notes=("FP&A star: plan lines (19 Financial Plan Line, holding the measures) and DP-191 actual balances meet at "
               "legal entity x GL account x cost center x fiscal period, with the statement line reached through the "
               "DP-190 mapping bridge. FTE sits at legal entity x cost center x period end through Workforce Position and "
               "the DP-192 job assignments. The distribution plan (10) is a separate fact rolled into the enterprise plan "
               "through Enterprise Financial Plan Version. "
               "Model gap: 10 Plan Line has no plan version reference among the inputs (borrowed Distribution Plan "
               "Version Key) and Plan Dimension Members is not an input. "
               "Financial Plan Type, Plan Scenario and Balance Type are codes and stay degenerate."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-195": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Working Capital Daily", "Fact", [], ["Legal Entity Key", "Calendar Date Key"], measures=True,
                grain="one row = legal entity x as-of date (summary of the open payable and receivable items)",
                note="Factless spine that holds the measures; open payables and receivables are summarized onto it "
                     "from the open-item facts, which keep the open item x as-of date grain in daily snapshots."),
            ent("Fact Payable Invoice", "Fact", [("19", "Payable Invoice")], ["Payable Invoice ID"],
                grain="one row = supplier invoice, credit note or prepayment request (AP voucher), snapshotted daily",
                note="Built from the input: AP is not mastered in a foundational product."),
            ent("Fact Payable Invoice Line", "Fact", [("19", "Payable Invoice Line")],
                ["Line Payable Invoice", "Invoice Line Number"],
                grain="one row = payable invoice x invoice line"),
            ent("Fact Invoice Indirect Tax", "Fact", [("19", "Indirect Tax Detail")],
                ["Fact Payable Invoice Line Key", "Indirect Tax Type"],
                grain="one row = payable invoice line x indirect tax type",
                note="Indirect Tax Detail is a repeating group of the invoice line (fold=False) with no attribute of its "
                     "own that names the line, so it borrows the line's key."),
            ent("Fact Supplier Payment", "Fact", [("19", "Supplier Payment")], ["Supplier Payment Document Number"],
                grain="one row = outgoing supplier payment (payment run item)"),
            ent("Supplier Payment Application", "Bridge", [("19", "Supplier Payment Application")],
                ["Applied Supplier Payment", "Settled Payable Invoice"],
                grain="one row = supplier payment x payable invoice settled",
                note="One payment settles many invoices and an invoice can be paid in parts."),
            ent("Fact Receivable Item", "Fact", [("19", "Receivable Item")], ["Receivable Document Number"],
                grain="one row = receivable item (debtor x source document), snapshotted daily"),
            ent("Fact Cash Receipt Application", "Fact", [("19", "Cash Receipt Application")],
                ["Cash Receipt Reference", "Applied Receivable Item"],
                grain="one row = cash receipt x receivable item"),
            cfact("GL Account Balance", GLAB, [("19", "GL Account Balance")], GLAB_GRAIN,
                  note="Subledger to GL Control Difference compares open items with control-account balances."),
            cfact("Fact Fee Revenue", FRR, [("10", "Fee Revenue Record")],
                  "one row = share class or mandate x revenue accounting period (DP-012)",
                  note="Conformed from DP-012 for Fee Receivable to Revenue Difference."),
            ent("Fact Bank Statement Entry", "Fact", [("43", "Bank Statement Entry")],
                ["Entry Statement", "Entry Sequence Number"],
                grain="one row = bank statement x entry sequence",
                note="Read from DP-202 (consumer) and built from the input; Unapplied Receipts are credit entries with "
                     "no cash receipt application."),
            # -- dimensions
            ent("Corporate Bank Account", "Dimension", [("43", "Corporate Bank Account")],
                ["Corporate Bank Account ID"],
                note="Built from the input (DP-202 is a consumer product); Payments From Inactive Bank Accounts."),
            dim("Vendor", VEND, [("40", "Supplier Profile")],
                note="Conformed from DP-210; Supplier Status drives Payments to Suppliers Not Approved."),
            dim("Customer", PARTY, note="The receivable debtor party, conformed from DP-240."),
            dim("Debtor Fund Product", PROD),
            dim("Share Class", SHARE),
            dim("GL Account", GLA, [("19", "GL Account")]),
            dim("Ledger", LDG),
            dim("Cost Center", CC),
            dim("Legal Entity", LE),
            dim("Fiscal Period", FP, [("09", "Fiscal Period")]),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Working Capital Daily", "Legal Entity", ["Legal Entity Key"]),
            rel("Fact Working Capital Daily", "Calendar Date", ["Calendar Date Key"]),
            rel("Fact Payable Invoice", "Vendor", ["Supplier"]),
            rel("Fact Payable Invoice", "Legal Entity", ["Invoice Legal Entity"]),
            rel("Fact Payable Invoice", "Calendar Date", ["Payment Due Date"]),
            rel("Fact Payable Invoice Line", "Fact Payable Invoice", ["Line Payable Invoice"]),
            rel("Fact Payable Invoice Line", "GL Account", ["Line Expense Account"]),
            rel("Fact Payable Invoice Line", "Cost Center", ["Line Cost Center"], optional=True),
            rel("Fact Invoice Indirect Tax", "Fact Payable Invoice Line", ["Fact Payable Invoice Line Key"]),
            rel("Fact Supplier Payment", "Vendor", ["Payee Supplier"]),
            rel("Fact Supplier Payment", "Legal Entity", ["Paying Legal Entity"]),
            rel("Fact Supplier Payment", "Corporate Bank Account", ["Paying Bank Account"], optional=True),
            rel("Fact Supplier Payment", "Calendar Date", ["Payment Value Date"]),
            rel("Supplier Payment Application", "Fact Supplier Payment", ["Applied Supplier Payment"]),
            rel("Supplier Payment Application", "Fact Payable Invoice", ["Settled Payable Invoice"]),
            rel("Fact Receivable Item", "Customer", ["Customer Party"]),
            rel("Fact Receivable Item", "Debtor Fund Product", ["Debtor Fund Product"], optional=True,
                note="Fund-paid receivables (expense reimbursements, fees billed to the fund)."),
            rel("Fact Receivable Item", "Legal Entity", ["Receivable Legal Entity"]),
            rel("Fact Receivable Item", "Fact Fee Revenue", ["Source Fee Revenue Record"], optional=True),
            rel("Fact Receivable Item", "Calendar Date", ["Receivable Due Date"]),
            rel("Fact Cash Receipt Application", "Fact Receivable Item", ["Applied Receivable Item"]),
            rel("Fact Cash Receipt Application", "Fact Bank Statement Entry", ["Bank Statement Entry Reference"],
                optional=True, note="The reference names the entry; its composite key is resolved from it."),
            rel("Fact Cash Receipt Application", "Calendar Date", ["Receipt Value Date"]),
            rel("Fact Bank Statement Entry", "Calendar Date", ["Entry Value Date"]),
            rel("Corporate Bank Account", "Legal Entity", ["Account Holder Entity"]),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("Ledger", "Legal Entity", ["Ledger Legal Entity"]),
            rel("Fact Fee Revenue", "Share Class", ["Revenue Share Class / Mandate"], optional=True,
                note="Optional because mandate revenue has no share class."),
            rel("Fact Fee Revenue", "Fiscal Period", ["Revenue Accounting Period"]),
            rel("Fiscal Period", "Calendar Date", ["Period End Date"]),
            rel("Share Class", "Debtor Fund Product", ["Parent Product"]),
        ],
        notes=("Payables and receivables star: payable invoices, lines, indirect tax, supplier payments and their "
               "applications on the AP side; receivable items, cash receipt applications and bank statement entries on "
               "the AR side; DP-191 control-account balances and DP-012 fee revenue for the tie-outs. Measures sit on a "
               "legal entity x as-of date spine because the spec grain (open item x as-of date) spans two open-item "
               "facts. Vendor is conformed from DP-210 and holds 40 Supplier Profile. "
               "Model gap: Bank Statement Entry's Entry Statement references 43 Bank Statement, which is not a DP-195 "
               "input, so the entry reaches the corporate bank account only through DP-202. "
               "Degenerate references (no upstream publishes the target): Source Partner Invoice (05), Purchase Order "
               "Reference (40), Settled Partner Payment (05), Source Fee Invoice (47 Fee Invoice, BIL-, moved from 12 at W2, CW-912) and Source Intercompany Charge (10). "
               "Ledger and Cost Center are conformed with no input objects so control balances and invoice lines carry "
               "their labels."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-196": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Entity Tax Position", "Fact", [], ["Legal Entity Key", "Fiscal Period Key"], measures=True,
                grain="one row = legal entity x fiscal period (summary of returns, provision and transfer pricing)",
                note="Factless spine that holds the measures; returns and provision keep their legal entity x tax "
                     "jurisdiction x tax type x tax period grain on the detail facts, and the effective tax rate is "
                     "stated per legal entity and period."),
            ent("Fact Tax Return", "Fact", [("19", "Tax Return")], ["Tax Return ID"],
                grain="one row = tax return (legal entity x tax jurisdiction x tax type x tax period x form)",
                note="Return Tax Period is the tax authority's period and need not match a fiscal period, so it stays "
                     "degenerate; the return is placed in a fiscal period by its filing due date."),
            ent("Fact Tax Provision", "Fact", [("19", "Tax Provision")],
                ["Provision Legal Entity", "Provision Fiscal Period", "Provision Tax Jurisdiction",
                 "Provision Component"],
                grain="one row = legal entity x fiscal period x tax jurisdiction x provision component"),
            ent("Fact Tax Registration", "Fact", [("19", "Entity Tax Registration")],
                ["Registered Legal Entity", "Registration Tax Jurisdiction", "Registration Tax Type",
                 "Registration Effective From"],
                grain="one row = legal entity x tax jurisdiction x tax type x registration effective period",
                note="Factless; Entities Without Income Tax Registration."),
            ent("Fact TP Documentation", "Fact", [("19", "Transfer Pricing Documentation")], ["TP Documentation ID"],
                grain="one row = transfer pricing documentation (legal entity x documentation type x fiscal year)"),
            ent("Fact Indirect Tax", "Fact", [("19", "Indirect Tax Detail")],
                ["Payable Invoice Line Key", "Indirect Tax Type"],
                grain="one row = payable invoice line x indirect tax type",
                note="Indirect Tax Detail is a repeating group of 19 Payable Invoice Line, which is not a DP-196 input; "
                     "the line's key is borrowed from a thin Payable Invoice Line entity (see Model gap)."),
            ent("Fact Intercompany Charge", "Fact", [("10", "Intercompany Charge")], ["Intercompany Charge ID"],
                grain="one row = intercompany charge (agreement x charge period)",
                note="Read from DP-074 (consumer) and built from the input; Charges Outside Arm's Length Range."),
            ent("Fact Intercompany Loan", "Fact", [("43", "Intercompany Loan")], ["Intercompany Loan ID"],
                grain="one row = intercompany loan",
                note="Read from DP-203 (consumer); Intercompany Loans Without TP Documentation."),
            cfact("GL Account Balance", GLAB, [("19", "GL Account Balance")], GLAB_GRAIN,
                  note="Tax expense and pre-tax income accounts for the effective tax rate and the provision tie-out."),
            # -- dimensions
            ent("Payable Invoice Line", "Dimension", [], ["Payable Invoice Line Key"],
                note="Thin placeholder for the parent of Indirect Tax Detail. Model gap: 19 Payable Invoice Line and "
                     "19 Payable Invoice are not DP-196 inputs, so the legal entity the measure groups by is borrowed."),
            ent("Intercompany Agreement", "Dimension", [("10", "Intercompany Agreement"), ("10", "TP Policy")],
                ["Intercompany Agreement ID"],
                note="Built from the input (published by DP-074, a consumer product). TP Policy folds here (one policy "
                     "per agreement) and carries the arm's length range."),
            dim("Journal Entry", JE, [("19", "Journal Entry")]),
            dim("GL Account", GLA, [("19", "GL Account")]),
            dim("Ledger", LDG, [("19", "Ledger")]),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Fiscal Period", FP, [("09", "Fiscal Period")]),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Entity Tax Position", "Legal Entity", ["Legal Entity Key"]),
            rel("Fact Entity Tax Position", "Fiscal Period", ["Fiscal Period Key"]),
            rel("Fact Tax Return", "Legal Entity", ["Return Legal Entity"]),
            rel("Fact Tax Return", "Calendar Date", ["Return Filing Due Date"]),
            rel("Fact Tax Provision", "Legal Entity", ["Provision Legal Entity"]),
            rel("Fact Tax Provision", "Fiscal Period", ["Provision Fiscal Period"]),
            rel("Fact Tax Provision", "Journal Entry", ["Provision Journal"], optional=True),
            rel("Fact Tax Registration", "Legal Entity", ["Registered Legal Entity"]),
            rel("Fact TP Documentation", "Legal Entity", ["Documented Legal Entity"]),
            rel("Fact TP Documentation", "Intercompany Agreement", ["Covered Intercompany Agreements"], card="M:N",
                note="Multi-valued: one row per covered agreement; TP Documentation Coverage % counts agreements "
                     "covered in the fiscal year."),
            rel("Fact Indirect Tax", "Payable Invoice Line", ["Payable Invoice Line Key"]),
            rel("Payable Invoice Line", "Legal Entity", ["Legal Entity Key"],
                note="Borrowed: the invoice legal entity is not an input (Model gap)."),
            rel("Intercompany Agreement", "Legal Entity", ["Service Provider Entity"]),
            rel("Intercompany Agreement", "Legal Entity", ["Service Recipient Entity"]),
            rel("Intercompany Agreement", "Legal Entity", ["Tested Party"], optional=True),
            rel("Fact Intercompany Charge", "Intercompany Agreement", ["Charging Agreement"]),
            rel("Fact Intercompany Charge", "Fiscal Period", ["Charge Period"],
                note="Charge Period carries the fiscal period code."),
            rel("Fact Intercompany Loan", "Legal Entity", ["Lending Entity"]),
            rel("Fact Intercompany Loan", "Legal Entity", ["Intercompany Borrowing Entity"]),
            rel("Fact Intercompany Loan", "Fact TP Documentation", ["Pricing Documentation"], optional=True),
            rel("Fact Intercompany Loan", "Intercompany Agreement", ["Loan Intercompany Agreement"], optional=True),
            rel("Fact Intercompany Loan", "Calendar Date", ["Loan Maturity Date"]),
            rel("Journal Entry", "Fiscal Period", ["Posting Accounting Period"],
                note="Provision journals must be posted in the provision period."),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("Ledger", "Legal Entity", ["Ledger Legal Entity"]),
            rel("Fiscal Period", "Calendar Date", ["Period End Date"]),
        ],
        notes=("Tax star: returns, provision, registrations, transfer pricing documentation, intercompany charges and "
               "loans and indirect tax, summarized onto a legal entity x fiscal period spine that holds the measures. "
               "Ledger balances (DP-191) give pre-tax income and booked tax for the effective tax rate and the "
               "provision-to-ledger difference. Intercompany agreements, charges (DP-074) and loans (DP-203) are built "
               "from the inputs because their publishers are consumer products. "
               "Model gap: 19 Indirect Tax Detail is read without its parent Payable Invoice Line or Payable Invoice, so "
               "nothing in the inputs carries the legal entity Irrecoverable Indirect Tax is grouped by; a thin Payable "
               "Invoice Line entity borrows its key and the legal entity key. Recommend adding 19 Payable Invoice Line "
               "(Line Payable Invoice) and 19 Payable Invoice (Invoice Legal Entity, Invoice Date) to the inputs. "
               "Tax jurisdiction and tax type are codes and stay degenerate."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-202": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Cash Position", "Fact", [("43", "Cash Position")],
                ["Position Bank Account", "Position Value Date", "Position Version", "Position Data Basis"],
                measures=True,
                grain="one row = corporate bank account x value date x position version x data basis",
                note="The product grain; holds the measures because every cash, liquidity and control measure is "
                     "stated against the account's position."),
            ent("Fact Bank Statement", "Fact", [("43", "Bank Statement")],
                ["Statement Account", "Bank Statement Type", "Statement Date", "Statement Sequence Number"],
                grain="one row = corporate bank account x statement type x statement date x sequence",
                note="Statement Continuity Breaks compare each opening booked balance with the prior closing one."),
            ent("Fact Bank Statement Entry", "Fact", [("43", "Bank Statement Entry")],
                ["Entry Statement", "Entry Sequence Number"],
                grain="one row = bank statement x entry sequence"),
            ent("Fact Cash Forecast Line", "Fact", [("43", "Cash Forecast Line")],
                ["Line Cash Forecast", "Line Legal Entity", "Line Currency", "Cash Flow Category", "Bucket Start Date"],
                grain="one row = cash forecast x legal entity x currency x cash flow category x value date bucket"),
            ent("Fact Short-Term Investment", "Fact", [("43", "Short-Term Investment")],
                ["Short-Term Investment Reference"],
                grain="one row = short-term investment placement"),
            ent("Fact Bank Fee Statement", "Fact", [("43", "Bank Fee Statement")],
                ["Fee Statement Account", "Fee Billing Period End"],
                grain="one row = corporate bank account x fee billing period"),
            ent("Fact Bank Account Signatory", "Fact", [("43", "Bank Account Signatory")],
                ["Signatory Account", "Signatory Employee", "Signatory Party", "Signatory Authority Level",
                 "Signatory Effective From"],
                grain="one row = bank account x signatory (employee or party) x authority level x effective period",
                note="Factless; Signatories No Longer Employed and Accounts Without Dual Control."),
            cfact("GL Account Balance", GLAB, [("19", "GL Account Balance")], GLAB_GRAIN,
                  note="Cash GL balances for Bank-to-Book Difference."),
            # -- bridges
            ent("Cash Pool Membership", "Bridge", [("43", "Cash Pool Membership")],
                ["Pool Participant Account", "Pool Header Account", "Membership Effective From"],
                grain="one row = participant account x header account x membership effective period",
                note="Links participant accounts to their pool header; Pool Intercompany Loan stays degenerate."),
            # -- dimensions
            ent("Corporate Bank Account", "Dimension", [("43", "Corporate Bank Account")],
                ["Corporate Bank Account ID"],
                note="Built from the input; this product publishes the corporate bank account to DP-195 and DP-203."),
            ent("Cash Forecast", "Dimension", [("43", "Cash Forecast")], ["Cash Forecast ID"],
                note="Aligned Financial Plan Version stays degenerate (see notes)."),
            ent("Bank Relationship Profile", "Dimension", [("43", "Bank Relationship Profile")],
                ["Relationship Bank", "Profile Effective From"],
                note="Effective-dated bank tier and counterparty limit for Bank Counterparty Limit Utilization %."),
            dim("Party", PARTY, note="Servicing banks, relationship banks, deposit counterparties and party signatories."),
            dim("Signatory Employee", EMP, [("20", "Employee")]),
            cfact("FX Rate Observation", FXO, [("22", "FX Rate Observation")],
                  "one row = FX rate observation (rate type x base x quote currency x rate date)", role="Dimension",
                  note="Conformed from DP-143; converts account balances to the group reporting currency."),
            dim("FX Rate Type", FXT, [("09", "FX Rate Type")]),
            dim("Currency", CCY, [("09", "Currency")]),
            dim("Money Market Fund Share Class", SHARE),
            dim("GL Account", GLA),
            dim("Ledger", LDG),
            dim("Journal Entry", JE, note="The journal a bank entry is matched to."),
            dim("Legal Entity", LE),
            dim("Fiscal Period", FP, [("09", "Fiscal Period")]),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Cash Position", "Corporate Bank Account", ["Position Bank Account"]),
            rel("Fact Cash Position", "Calendar Date", ["Position Value Date"]),
            rel("Corporate Bank Account", "Legal Entity", ["Account Holder Entity"]),
            rel("Corporate Bank Account", "Party", ["Account Servicing Bank"]),
            rel("Corporate Bank Account", "GL Account", ["Cash GL Account"]),
            rel("Corporate Bank Account", "Currency", ["Account Currency"]),
            rel("Fact Bank Statement", "Corporate Bank Account", ["Statement Account"]),
            rel("Fact Bank Statement", "Calendar Date", ["Statement Date"]),
            rel("Fact Bank Statement Entry", "Fact Bank Statement", ["Entry Statement"],
                note="Entry Statement names the statement; its composite key is resolved from the reference."),
            rel("Fact Bank Statement Entry", "Journal Entry", ["Matched Journal Entry"], optional=True),
            rel("Fact Bank Statement Entry", "Calendar Date", ["Entry Value Date"]),
            rel("Fact Cash Forecast Line", "Cash Forecast", ["Line Cash Forecast"]),
            rel("Fact Cash Forecast Line", "Legal Entity", ["Line Legal Entity"]),
            rel("Fact Cash Forecast Line", "Currency", ["Line Currency"]),
            rel("Fact Cash Forecast Line", "Calendar Date", ["Bucket Start Date"]),
            rel("Cash Forecast", "Calendar Date", ["Forecast As-Of Date"]),
            rel("Fact Short-Term Investment", "Legal Entity", ["Placing Entity"]),
            rel("Fact Short-Term Investment", "Party", ["Deposit Counterparty"], optional=True,
                note="Deposits name a bank; money market fund placements name a share class instead."),
            rel("Fact Short-Term Investment", "Money Market Fund Share Class", ["Money Market Fund Share Class"],
                optional=True),
            rel("Fact Short-Term Investment", "Calendar Date", ["Investment Maturity Date"]),
            rel("Fact Bank Fee Statement", "Corporate Bank Account", ["Fee Statement Account"]),
            rel("Fact Bank Fee Statement", "Calendar Date", ["Fee Billing Period End"]),
            rel("Fact Bank Account Signatory", "Corporate Bank Account", ["Signatory Account"]),
            rel("Fact Bank Account Signatory", "Signatory Employee", ["Signatory Employee"], optional=True),
            rel("Fact Bank Account Signatory", "Party", ["Signatory Party"], optional=True,
                note="Exactly one of employee or party names the signatory."),
            rel("Cash Pool Membership", "Corporate Bank Account", ["Pool Participant Account"]),
            rel("Cash Pool Membership", "Corporate Bank Account", ["Pool Header Account"]),
            rel("Bank Relationship Profile", "Party", ["Relationship Bank"]),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("GL Account Balance", "Currency", ["Balance Currency"]),
            rel("Ledger", "Legal Entity", ["Ledger Legal Entity"]),
            rel("FX Rate Observation", "FX Rate Type", ["Observed FX Rate Type"]),
            rel("FX Rate Observation", "Currency", ["Base Currency"]),
            rel("FX Rate Observation", "Currency", ["Quote Currency"]),
            rel("FX Rate Observation", "Calendar Date", ["FX Rate Date"]),
            rel("Fiscal Period", "Calendar Date", ["Period End Date"]),
        ],
        notes=("Cash and banking star centered on the daily cash position by corporate bank account (the product grain, "
               "holding the measures), with bank statements and entries, cash forecast lines, short-term investments, "
               "bank fees and signatories as companion facts, all sharing Corporate Bank Account, Legal Entity, Currency "
               "and Calendar Date. Cash GL balances come from DP-191 and FX rates from DP-143. This product is the "
               "publisher of the 43 bank objects that DP-195 and DP-203 read, so it keeps their registry keys. "
               "Degenerate references: Aligned Financial Plan Version (19 Financial Plan Version is published by DP-194, "
               "a consumer product not in upstream) and Pool Intercompany Loan (43 Intercompany Loan is not a DP-202 "
               "input). Bank Account Purpose, Cash Flow Category and Position Data Basis are codes."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-203": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Funding & Hedging Daily", "Fact", [], ["Legal Entity Key", "Calendar Date Key"], measures=True,
                grain="one row = legal entity x as-of date (summary of the funding and hedging records)",
                note="Factless spine that holds the measures; each funding or hedging record keeps its own grain on "
                     "the detail facts and is summarized onto the entity's as-of date."),
            ent("Fact Debt Facility", "Fact", [("43", "Debt Facility")], ["Debt Facility ID"],
                grain="one row = debt facility"),
            ent("Fact Debt Drawdown", "Fact", [("43", "Debt Facility Drawdown")],
                ["Drawn Debt Facility", "Drawdown Reference"],
                grain="one row = debt facility x drawdown"),
            ent("Fact Covenant Test", "Fact", [("43", "Corporate Covenant Test")],
                ["Tested Debt Facility", "Covenant Metric", "Covenant Test Date"],
                grain="one row = debt facility x covenant metric x test date"),
            ent("Fact Intercompany Loan", "Fact", [("43", "Intercompany Loan")], ["Intercompany Loan ID"],
                grain="one row = intercompany loan"),
            ent("Fact Intra-Group Capital Transaction", "Fact", [("43", "Intra-Group Capital Transaction")],
                ["Capital Transaction Reference"],
                grain="one row = intra-group capital transaction"),
            ent("Fact Corporate Exposure", "Fact", [("43", "Corporate Exposure")],
                ["Exposure Legal Entity", "Corporate Exposure Type", "Exposure Currency", "Exposure Rate Index",
                 "Exposure Seed Commitment", "Exposure Debt Facility", "Exposure Period Start"],
                grain="one row = legal entity x exposure type x currency x rate index x seed commitment x debt facility "
                      "x exposure period",
                note="Exposure Seed Commitment stays degenerate: 43 Seed Capital Commitment is published by DP-204 and "
                     "is not a DP-203 input; it joins DP-204's commitment by its ID."),
            ent("Fact Treasury Deal", "Fact", [("43", "Treasury Deal")], ["Treasury Deal ID"],
                grain="one row = treasury deal (FX forward, swap, deposit or loan)"),
            ent("Fact Deal Valuation", "Fact", [("43", "Treasury Deal Valuation")],
                ["Valued Treasury Deal", "Deal Valuation Date"],
                grain="one row = treasury deal x valuation date"),
            ent("Fact Hedge Relationship", "Fact", [("43", "Hedge Relationship")], ["Hedge Relationship ID"],
                grain="one row = hedge relationship designation",
                note="Hedging OTC Derivative Trades (26) and Hedged Seed Commitment stay degenerate (see notes)."),
            ent("Fact Hedge Effectiveness Test", "Fact", [("43", "Hedge Effectiveness Test")],
                ["Tested Hedge Relationship", "Effectiveness Test Date"],
                grain="one row = hedge relationship x effectiveness test date"),
            ent("Fact Intercompany Balance", "Fact", [("19", "Intercompany Balance")],
                ["Reporting Entity", "Counterparty Entity", "Intercompany GL Account", "Intercompany Period"],
                grain="one row = reporting entity x counterparty entity x intercompany GL account x fiscal period",
                note="Read from DP-193's intercompany matching for Intercompany Loan to Ledger Difference."),
            # -- bridges
            cfact("Counterparty Approval Scope", CPTY_SCOPE, [("25", "Counterparty Approval Scope")],
                  "one row = counterparty x approved activity x trading entity x fund x scope effective period",
                  role="Bridge",
                  note="Conformed from DP-115; Deals With Unapproved Counterparty checks the deal's counterparty and "
                       "dealing entity against an active treasury scope."),
            # -- dimensions
            cfact("Reference Rate Fixing", RRF, [("22", "Reference Rate Fixing")],
                  "one row = reference rate x tenor x fixing value type x fixing date", role="Dimension",
                  note="Conformed from DP-143."),
            cfact("FX Rate Observation", FXO, [("22", "FX Rate Observation")],
                  "one row = FX rate observation (rate type x base x quote currency x rate date)", role="Dimension",
                  note="Conformed from DP-143; converts notional and exposure to the reporting currency."),
            dim("Trading Agreement", TA, [("26", "Trading Agreement")]),
            dim("Counterparty", CPTY, note="Deal counterparty banks, conformed from DP-115."),
            dim("Lender", PARTY, note="Facility lenders, conformed from DP-240."),
            dim("Journal Entry", JE, [("19", "Journal Entry")]),
            dim("GL Account", GLA),
            dim("FX Rate Type", FXT),
            dim("Currency", CCY),
            dim("Legal Entity", LE),
            dim("Fiscal Period", FP),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Funding & Hedging Daily", "Legal Entity", ["Legal Entity Key"]),
            rel("Fact Funding & Hedging Daily", "Calendar Date", ["Calendar Date Key"]),
            rel("Fact Debt Facility", "Legal Entity", ["Borrowing Entity"]),
            rel("Fact Debt Facility", "Lender", ["Lender Parties"], card="M:N",
                note="Multi-valued: one row per lender of a syndicated facility."),
            rel("Fact Debt Facility", "Calendar Date", ["Facility Maturity Date"]),
            rel("Fact Debt Drawdown", "Fact Debt Facility", ["Drawn Debt Facility"]),
            rel("Fact Debt Drawdown", "Reference Rate Fixing", ["Rate Fixing Used"], optional=True,
                note="The fixing reference resolves to the fixing's composite key."),
            rel("Fact Debt Drawdown", "Calendar Date", ["Drawdown Date"]),
            rel("Fact Covenant Test", "Fact Debt Facility", ["Tested Debt Facility"]),
            rel("Fact Covenant Test", "Calendar Date", ["Covenant Test Date"]),
            rel("Fact Intercompany Loan", "Legal Entity", ["Lending Entity"]),
            rel("Fact Intercompany Loan", "Legal Entity", ["Intercompany Borrowing Entity"]),
            rel("Fact Intercompany Loan", "Calendar Date", ["Loan Maturity Date"]),
            rel("Fact Intra-Group Capital Transaction", "Legal Entity", ["Paying Entity"]),
            rel("Fact Intra-Group Capital Transaction", "Legal Entity", ["Receiving Entity"]),
            rel("Fact Intra-Group Capital Transaction", "Calendar Date", ["Capital Transaction Effective Date"]),
            rel("Fact Corporate Exposure", "Legal Entity", ["Exposure Legal Entity"]),
            rel("Fact Corporate Exposure", "Currency", ["Exposure Currency"]),
            rel("Fact Corporate Exposure", "Fact Debt Facility", ["Exposure Debt Facility"], optional=True),
            rel("Fact Corporate Exposure", "Calendar Date", ["Exposure Period Start"]),
            rel("Fact Treasury Deal", "Legal Entity", ["Dealing Entity"]),
            rel("Fact Treasury Deal", "Counterparty", ["Deal Counterparty Bank"]),
            rel("Fact Treasury Deal", "Trading Agreement", ["Governing Trading Agreement"], optional=True),
            rel("Fact Treasury Deal", "Currency", ["Counter Currency"], optional=True),
            rel("Fact Treasury Deal", "Calendar Date", ["Deal Trade Date"]),
            rel("Fact Deal Valuation", "Fact Treasury Deal", ["Valued Treasury Deal"]),
            rel("Fact Deal Valuation", "Calendar Date", ["Deal Valuation Date"]),
            rel("Fact Hedge Relationship", "Fact Corporate Exposure", ["Hedged Exposure"], optional=True,
                note="Hedged Exposure names the exposure; its composite key is resolved from the reference."),
            rel("Fact Hedge Relationship", "Fact Debt Facility", ["Hedged Debt Facility"], optional=True),
            rel("Fact Hedge Relationship", "Legal Entity", ["Hedged Net Investment Entity"], optional=True),
            rel("Fact Hedge Relationship", "Fact Treasury Deal", ["Hedging Treasury Deals"], card="M:N",
                optional=True, note="Multi-valued: one row per hedging deal."),
            rel("Fact Hedge Effectiveness Test", "Fact Hedge Relationship", ["Tested Hedge Relationship"]),
            rel("Fact Hedge Effectiveness Test", "Journal Entry", ["Ineffectiveness Journal"], optional=True),
            rel("Fact Hedge Effectiveness Test", "Calendar Date", ["Effectiveness Test Date"]),
            rel("Fact Intercompany Balance", "Legal Entity", ["Reporting Entity"]),
            rel("Fact Intercompany Balance", "Legal Entity", ["Counterparty Entity"]),
            rel("Fact Intercompany Balance", "GL Account", ["Intercompany GL Account"]),
            rel("Fact Intercompany Balance", "Fiscal Period", ["Intercompany Period"]),
            rel("Counterparty Approval Scope", "Counterparty", ["Scope Counterparty"]),
            rel("Counterparty Approval Scope", "Legal Entity", ["Scope Trading Entity"], optional=True),
            rel("Trading Agreement", "Counterparty", ["Agreement Counterparty"]),
            rel("Trading Agreement", "Legal Entity", ["Firm Contracting Entity"]),
            rel("FX Rate Observation", "FX Rate Type", ["Observed FX Rate Type"]),
            rel("FX Rate Observation", "Currency", ["Base Currency"]),
            rel("FX Rate Observation", "Currency", ["Quote Currency"]),
            rel("FX Rate Observation", "Calendar Date", ["FX Rate Date"]),
            rel("Reference Rate Fixing", "Calendar Date", ["Fixing Date"]),
        ],
        notes=("Funding and hedging star: debt facilities with drawdowns and covenant tests, intercompany loans, "
               "intra-group capital transactions, corporate exposures, treasury deals with valuations, and hedge "
               "relationships with effectiveness tests, summarized onto a legal entity x as-of date spine that holds the "
               "measures. Market data (DP-143), counterparties and approval scope (DP-115) and trading agreements "
               "(DP-147) are conformed; DP-193's intercompany balances are built from the input. Lenders are conformed "
               "from DP-240 Party (REFS points Lender Parties to 02 Party) and deal counterparties from DP-115. "
               "Degenerate references: Hedging OTC Derivative Trades (26 OTC Derivative Trade, no upstream publishes it), "
               "Exposure Seed Commitment and Hedged Seed Commitment (43 Seed Capital Commitment, published by DP-204 but "
               "not a DP-203 input), Pricing Documentation (19 Transfer Pricing Documentation, DP-196 is not upstream) "
               "and Loan Intercompany Agreement (10, from DP-074, not upstream)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-204": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Seed Position Valuation", "Fact", [("43", "Seed Position Valuation")],
                ["Valued Seed Commitment", "Seed Valuation Date"], measures=True,
                grain="one row = seed capital commitment x valuation date (daily)",
                note="The product grain; holds the measures. Seed Valuation Tie-Out compares the value with the "
                     "conformed shareholder position and share class NAV it was sourced from."),
            ent("Fact Seed Capital Movement", "Fact", [("43", "Seed Capital Movement")],
                ["Movement Seed Commitment", "Movement Reference"],
                grain="one row = seed capital commitment x movement"),
            ent("Fact Seed Product Holding", "Fact", [("43", "Seed Product Holding")],
                ["Held Seeded Product", "Ownership Measurement Date"],
                grain="one row = seeded product x ownership measurement date",
                note="Firm Ownership % and the consolidation review trigger DP-193 reads."),
            ent("Fact Seed Exposure", "Fact", [("43", "Corporate Exposure")], ["Fact Seed Exposure Key"],
                grain="one row = corporate exposure of a seed commitment (exposure type x period)",
                note="Model gap: the registry key of 43 Corporate Exposure (legal entity, currency, rate index, debt "
                     "facility, period start) is mostly not in the DP-204 inputs, so the fact uses a surrogate key."),
            ent("Fact Seed Hedge", "Fact", [("43", "Hedge Relationship")], ["Hedge Relationship ID"],
                grain="one row = hedge relationship designated on a seed commitment",
                note="Unhedged Seed Market Exposure nets the hedge ratio against the seed exposure."),
            cfact("Shareholder Position", POS, [("06", "Fund Shareholder Position")],
                  "one row = account x share class x valuation date position (DP-007)",
                  note="Conformed from DP-007 so seed units match the shareholder record; 06 Position is re-typed by "
                       "name to Fund Shareholder Position (W4, CW-151)."),
            cfact("Share Class NAV", SCNAV, [("27", "Share Class NAV")],
                  "one row = share class NAV per valuation (DP-165)"),
            cfact("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")],
                  "one row = fund accounting book x valuation date x calculation source x version (DP-165)",
                  note="Fund Net Assets for Firm Ownership % where the product holding is not stated."),
            cfact("Portfolio Valuation Summary", PVS, [("18", "Portfolio Valuation Summary")],
                  "one row = portfolio x valuation as-of date x valuation view (DP-142)",
                  note="Incubation books (seed book portfolios) are valued here; Incubation Value Outside Firm AUM."),
            # -- dimensions
            ent("Seed Capital Commitment", "Dimension", [("43", "Seed Capital Commitment")],
                ["Seed Capital Commitment ID"],
                note="Built from the input; this product publishes seed commitments to DP-193 and DP-203. Launch Change "
                     "Initiative stays degenerate (see notes)."),
            dim("Investment Product", PROD, [("01", "Investment Product")]),
            dim("Share Class", SHARE),
            dim("Account", ACCT, [("15", "Account")], note="The account holding the seed units."),
            dim("Seed Book", PORT, [("18", "Portfolio")], note="Seed book portfolios (Proprietary Capital Indicator)."),
            dim("Fund Accounting Book", BOOK),
            dim("Legal Entity", LE),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Seed Position Valuation", "Seed Capital Commitment", ["Valued Seed Commitment"]),
            rel("Fact Seed Position Valuation", "Calendar Date", ["Seed Valuation Date"]),
            rel("Fact Seed Position Valuation", "Shareholder Position", ["Source Shareholder Position"], optional=True),
            rel("Fact Seed Position Valuation", "Share Class NAV", ["Source NAV Record"], optional=True),
            rel("Seed Capital Commitment", "Investment Product", ["Seeded Product"]),
            rel("Seed Capital Commitment", "Share Class", ["Seeded Share Class"], optional=True),
            rel("Seed Capital Commitment", "Legal Entity", ["Investing Entity"]),
            rel("Seed Capital Commitment", "Account", ["Seed Holding Account"], optional=True),
            rel("Seed Capital Commitment", "Seed Book", ["Seed Book"], optional=True),
            rel("Seed Capital Commitment", "Calendar Date", ["Commitment Approval Date"]),
            rel("Fact Seed Capital Movement", "Seed Capital Commitment", ["Movement Seed Commitment"]),
            rel("Fact Seed Capital Movement", "Legal Entity", ["Transfer Counterparty Entity"], optional=True),
            rel("Fact Seed Capital Movement", "Calendar Date", ["Movement Trade Date"]),
            rel("Fact Seed Product Holding", "Investment Product", ["Held Seeded Product"]),
            rel("Fact Seed Product Holding", "Calendar Date", ["Ownership Measurement Date"]),
            rel("Fact Seed Exposure", "Seed Capital Commitment", ["Exposure Seed Commitment"]),
            rel("Fact Seed Exposure", "Calendar Date", ["Exposure Period End"]),
            rel("Fact Seed Hedge", "Seed Capital Commitment", ["Hedged Seed Commitment"]),
            rel("Shareholder Position", "Account", ["Account"]),
            rel("Shareholder Position", "Share Class", ["Share Class"]),
            rel("Shareholder Position", "Calendar Date", ["Valuation Date"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"],
                note="The reference names the calculation; its composite key is resolved from it."),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("Fund NAV Calculation", "Calendar Date", ["Valuation Date"]),
            rel("Portfolio Valuation Summary", "Seed Book", ["Valued Portfolio"]),
            rel("Portfolio Valuation Summary", "Calendar Date", ["Valuation As-Of Date"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Seed capital star centered on the daily seed position valuation per commitment (the product grain, "
               "holding the measures), with movements, product ownership, seed exposure and seed hedges as companion "
               "facts. The sources the value is tied out to are conformed facts: DP-007 shareholder positions, DP-165 "
               "share class and fund NAVs and DP-142 portfolio valuations (W4, CW-930: the DP-116 capital account, the GP "
               "commitment and the capital call and private fund distribution dimensions are removed with 30). Seed commitment, "
               "movement, holding, exposure and hedge are built from the inputs because this product and DP-203 publish "
               "them. "
               "Model gap: 43 Corporate Exposure is read without most of its registry key (surrogate Fact Seed Exposure "
               "Key). "
               "Degenerate references: Launch Change Initiative (36 Product Change Initiative, no upstream), Resulting "
               "Fund Order and Resulting AP Order (29, no upstream)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-205": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Capital Requirement Calculation", "Fact", [("43", "Capital Requirement Calculation")],
                ["Capital Calculation ID"], measures=True,
                grain="one row = regulated entity x capital regime x calculation as-of date x calculation version",
                note="The product grain; holds the measures (requirement, resources, surplus, coverage, early-warning headroom, aggregate indebtedness)."),
            ent("Fact Capital Requirement Component", "Fact", [("43", "Capital Requirement Component")],
                ["Component Calculation", "Component Sequence"],
                grain="one row = capital calculation x component (permanent minimum, aggregate indebtedness or alternative standard requirement, haircut, deduction)"),
            ent("Fact Capital Adequacy Notification", "Fact", [("43", "Capital Adequacy Notification")],
                ["Notifying Entity", "Capital Notification Trigger", "Notification Sent Timestamp"],
                grain="one row = regulated entity x notification trigger x notification sent"),
            ent("Fact Intra-Group Capital Transaction", "Fact", [("43", "Intra-Group Capital Transaction")],
                ["Capital Transaction Reference"],
                grain="one row = intra-group capital transaction",
                note="Read from DP-203 (consumer); Capital Withdrawals Without Prior Notice."),
            ent("Fact Regulatory Financial Return", "Fact", [("19", "Regulatory Financial Return")],
                ["Return Filing Entity", "Return Regulator", "Regulatory Return Type", "Return Reporting Period End"],
                grain="one row = filing entity x regulator x return type x reporting period end",
                note="Return Copy Difference compares the filed requirement and resources with the calculation."),
            ent("Fact Statement Line Value", "Fact", [("19", "Financial Statement Line Value")],
                ["Line Financial Statement", "Value Statement Line"],
                grain="one row = financial statement x statement line",
                note="Read from DP-193 (consumer) for the Own Funds to Equity Bridge."),
            cfact("GL Account Balance", GLAB, [("19", "GL Account Balance")], GLAB_GRAIN,
                  note="Equity balances for the own funds to equity bridge."),
            # -- bridges
            cfact("Statement Line Mapping", FSLM, [("19", "Financial Statement Line Mapping")], FSLM_GRAIN,
                  role="Bridge"),
            # -- dimensions
            ent("Capital Profile", "Dimension", [("43", "Regulated Entity Capital Profile")],
                ["Capital Regulated Entity", "Capital Regime", "Capital Profile Effective From"],
                note="Effective-dated regime parameters (net capital method, permanent minimum); Regulated "
                     "Entities Without Capital Profile."),
            ent("Financial Statement", "Dimension", [("19", "Financial Statement")], ["Financial Statement ID"],
                note="Built from the input (published by DP-193, a consumer product)."),
            dim("Financial Statement Line", FSL),
            dim("Entity Authorization", AUTH, [("38", "Entity Authorization")],
                note="Conformed from DP-013; the authorization that puts an entity under a capital regime."),
            dim("GL Account", GLA, [("19", "GL Account")]),
            dim("Ledger", LDG, note="Conformed without spec input since CW-943 (the fixed overheads check left); the GL balance key still names it."),
            dim("Legal Entity", LE),
            dim("Fiscal Period", FP, note="Conformed without spec input since CW-943; the GL balance key still names it."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Capital Requirement Calculation", "Legal Entity", ["Calculation Entity"]),
            rel("Fact Capital Requirement Calculation", "Calendar Date", ["Calculation As-Of Date"]),
            rel("Fact Capital Requirement Component", "Fact Capital Requirement Calculation", ["Component Calculation"]),
            rel("Capital Profile", "Legal Entity", ["Capital Regulated Entity"]),
            rel("Capital Profile", "Entity Authorization", ["Governing Authorization"], optional=True),
            rel("Entity Authorization", "Legal Entity", ["Authorized Entity"]),
            rel("Fact Capital Adequacy Notification", "Legal Entity", ["Notifying Entity"]),
            rel("Fact Capital Adequacy Notification", "Fact Capital Requirement Calculation", ["Triggering Calculation"],
                optional=True),
            rel("Fact Capital Adequacy Notification", "Fact Intra-Group Capital Transaction",
                ["Related Capital Transaction"], optional=True),
            rel("Fact Capital Adequacy Notification", "Calendar Date", ["Trigger Event Date"]),
            rel("Fact Intra-Group Capital Transaction", "Legal Entity", ["Paying Entity"]),
            rel("Fact Intra-Group Capital Transaction", "Calendar Date", ["Capital Transaction Effective Date"]),
            rel("Fact Regulatory Financial Return", "Legal Entity", ["Return Filing Entity"]),
            rel("Fact Regulatory Financial Return", "Calendar Date", ["Return Reporting Period End"]),
            rel("Fact Statement Line Value", "Financial Statement", ["Line Financial Statement"]),
            rel("Fact Statement Line Value", "Financial Statement Line", ["Value Statement Line"]),
            rel("Financial Statement", "Legal Entity", ["Statement Reporting Entity"]),
            rel("Financial Statement", "Calendar Date", ["Statement Period End Date"]),
            rel("Statement Line Mapping", "GL Account", ["Mapped GL Account"]),
            rel("Statement Line Mapping", "Financial Statement Line", ["Mapped Statement Line"]),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("Ledger", "Legal Entity", ["Ledger Legal Entity"]),
            rel("Fiscal Period", "Calendar Date", ["Period End Date"]),
        ],
        notes=("W1b re-point (CW-943): Fact ICARA Assessment and its three relationships are removed with the 43 object; Ledger and Fiscal Period stay as conformed dimensions without spec input because the conformed GL Account Balance key names them; component and profile notes read the US net capital regime. "
               "Regulatory capital star centered on the capital requirement calculation (the product grain, holding the "
               "measures), with components, notifications, intra-group capital transactions and "
               "regulatory returns as companion facts, all sharing Legal Entity and Calendar Date. The own funds to "
               "equity bridge reads DP-193's statement line values (built from the input) and DP-191 balances through "
               "the DP-190 mapping. Entity Authorization is conformed from DP-013. "
               "Capital Regime, Net Capital Method and Capital Notification Trigger are codes and stay degenerate; Notified "
               "Regulator and Return Regulator are regulator codes with no party reference."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-206": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Coverage Layer", "Fact", [("43", "Insurance Coverage Layer")],
                ["Layer Policy", "Layer Number", "Layer Carrier"], measures=True,
                grain="one row = corporate insurance policy (policy period) x layer number x carrier",
                note="The program grain; holds the measures (limit, tower integrity, placement gap, carrier "
                     "concentration)."),
            ent("Fact Insurance Policy", "Fact", [("43", "Corporate Insurance Policy")], ["Insurance Policy ID"],
                grain="one row = corporate insurance policy x policy period",
                note="Premium, retention and program aggregate limit; parent of the layers and claims. Joint Fund "
                     "Fidelity Bond stays degenerate (see notes)."),
            ent("Fact Insurance Claim", "Fact", [("43", "Insurance Claim")], ["Insurance Claim Reference"],
                grain="one row = insurance claim (daily snapshots give claim x as-of date)"),
            ent("Fact Loss Event Amount", "Fact", [("37", "Loss Event Amount")],
                ["Amount Loss Event", "Loss Amount Sequence"],
                grain="one row = operational loss event x loss amount entry",
                note="Recovery Tie-Out to Loss Data compares Amount Recovered with the recovery entries booked here."),
            # -- dimensions
            ent("Operational Loss Event", "Dimension", [("37", "Operational Loss Event")], ["Loss Event ID"],
                note="Built from the input: no product in the upstream publishes 37 loss events."),
            ent("Legal Matter", "Dimension", [("39", "Legal Matter")], ["Legal Matter ID"],
                note="Built from the input: no product in the upstream publishes 39 legal matters. Privileged matters "
                     "are masked (Privilege Indicator)."),
            dim("Contract", CONTRACT, [("39", "Contract"), ("39", "Typed Contract Link")],
                note="Conformed from DP-213; Typed Contract Link folds here and names the insurance policy the contract "
                     "papers (Policies Without Active Contract)."),
            dim("Party", PARTY, [("02", "Party"), ("02", "Organization")],
                note="Lead insurers, brokers and layer carriers; Organization folds into Party."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Coverage Layer", "Fact Insurance Policy", ["Layer Policy"]),
            rel("Fact Coverage Layer", "Party", ["Layer Carrier"]),
            rel("Fact Insurance Policy", "Party", ["Lead Insurer"]),
            rel("Fact Insurance Policy", "Party", ["Insurance Broker"], optional=True),
            rel("Fact Insurance Policy", "Legal Entity", ["Named Insured Entities"], card="M:N",
                note="Multi-valued: one row per named insured entity."),
            rel("Fact Insurance Policy", "Calendar Date", ["Policy Period End"],
                note="Policies Renewing in 90 Days."),
            rel("Fact Insurance Claim", "Fact Insurance Policy", ["Claimed Policy"]),
            rel("Fact Insurance Claim", "Operational Loss Event", ["Related Operational Loss Event"], optional=True),
            rel("Fact Insurance Claim", "Legal Matter", ["Related Legal Matter"], optional=True),
            rel("Fact Insurance Claim", "Calendar Date", ["Claim Notice Date"]),
            rel("Operational Loss Event", "Legal Entity", ["Loss Legal Entity"]),
            rel("Fact Loss Event Amount", "Operational Loss Event", ["Amount Loss Event"]),
            rel("Fact Loss Event Amount", "Calendar Date", ["Loss Booking Date"]),
            rel("Contract", "Fact Insurance Policy", ["Linked Insurance Policy"], optional=True,
                note="Only insurance-typed contracts carry the link."),
        ],
        notes=("Corporate insurance star: the coverage layer (policy x layer x carrier, holding the measures) under each "
               "policy, with claims and the operational loss amounts they recover as companion facts. Carriers, insurers "
               "and brokers are conformed from DP-240 Party; contracts from DP-213; legal entities from DP-013. Loss "
               "events and legal matters are built from the inputs because no upstream product publishes them. "
               "Degenerate references: Related IT Incident (41 IT Incident) and Joint Fund Fidelity Bond (35 Fund "
               "Fidelity Bond); no upstream product publishes them."),
    ),
}
