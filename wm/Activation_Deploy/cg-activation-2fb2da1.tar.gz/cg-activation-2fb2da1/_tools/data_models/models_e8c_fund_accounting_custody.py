"""Logical data models, Wave E8 consumer group "fund_accounting_custody": Star models for the Fund Accounting & Valuation
(27) and Custody & Asset Servicing (28) consumer products DP-168 to DP-176 (NAV oversight and release, swing pricing and
NAV errors, fund expenses, distributions and fund tax, custody reconciliation breaks, corporate action servicing,
securities lending, safekeeping reconciliation coverage (DP-175, formerly CASS client assets, CW-928) and fund service provider oversight). See CONTRACT.md.

Conventions used in these models:
- Facts are named "Fact ..." and sit at the spec's grain (the main fact) or at a companion grain the spec names.
- Objects a foundational model publishes are conformed, never rebuilt: the NAV masters from DP-165 (Fund NAV
  Calculation, Share Class NAV, NAV Dissemination, Fund Accounting Book, Fund Book Operating Period, Fund Expense
  Accrual, Expense Cap & Waiver Accrual), the ledger and ABOR from DP-166, the custody network from DP-167, holdings and
  cash from DP-142, Portfolio from DP-140, prices from DP-143, corporate actions from DP-099, Instrument from DP-097,
  counterparties from DP-115, vendors and supplier engagements from DP-210, Party from DP-240 (or from an upstream
  foundational product that republishes it where DP-240 is not upstream), Employee from DP-192, Share Class and
  Investment Product from DP-004, Account from DP-093, and Calendar Date, Internal Legal Entity and Entity Authorization
  from DP-013. A conformed NAV or accrual object the product measures keeps the Fact role.
- Objects that only consumer products publish (DP-181 TA control checks, DP-177 fund orders, DP-043 servicing errors,
  DP-219 third-party oversight, and this group's own DP-169 NAV error cases and DP-172 reconciliation runs and breaks
  read again by DP-175 and DP-176) are modeled here as this product's own entities with their registry keys.
- Calendar Date (DP-013) is keyed by calendar and date; a date attribute on the fact is drawn as the foreign key, and
  the calendar is the product's business-day calendar.
- A reference whose target is not a product input and not published by an upstream foundational product stays an
  attribute (a key carried, not linked) and is listed under "External references" in the model notes.
"""


def fact(name, objects, pk, grain, note="", measures=False):
    return dict(name=name, role="Fact", objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def dim(name, objects, pk, note=""):
    return dict(name=name, role="Dimension", objects=list(objects), pk=list(pk), note=note)


def conf(name, src, objects=(), role="Dimension", pk=None, grain="", note="", measures=False):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    if grain:
        d["grain"] = grain
    if measures:
        d["measures"] = True
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources
SCNAV = ("DP-165", "Share Class NAV")
FNAV = ("DP-165", "Fund NAV Calculation")
DISS = ("DP-165", "NAV Dissemination")
BOOK165 = ("DP-165", "Fund Accounting Book")
BOOKOP165 = ("DP-165", "Fund Book Operating Period")
BOOK166 = ("DP-166", "Fund Accounting Book")
EXPACC = ("DP-165", "Fund Expense Accrual")
WAIVACC = ("DP-165", "Expense Cap & Waiver Accrual")
ABOR = ("DP-166", "ABOR Valuation Record")
BPLINK = ("DP-166", "Fund Book Portfolio Link")
FJE = ("DP-166", "Fund Journal Entry")
INCACC = ("DP-166", "Income Accrual")
SKA = ("DP-167", "Safekeeping Account")
CUSTODIAN = ("DP-167", "Custodian")
SUBCUST = ("DP-167", "Sub-Custodian Network Arrangement")
PPROLE = ("DP-167", "Product Party Role")
PARTY167 = ("DP-167", "Party")
HOLD = ("DP-142", "Portfolio Holding")
CASH = ("DP-142", "Cash Balance")
PORT = ("DP-140", "Portfolio")
PRICE = ("DP-143", "Approved Price")
CAE = ("DP-099", "Corporate Action Event")
CAO = ("DP-099", "Corporate Action Option")
CANOTE = ("DP-099", "Custodian Notification")
INSTR = ("DP-097", "Instrument")
CPTY = ("DP-115", "Counterparty")
CPTYSCOPE = ("DP-115", "Counterparty Approval Scope")
VENDOR = ("DP-210", "Vendor")
SUPENG = ("DP-210", "Supplier Engagement")
SUPTIER = ("DP-210", "Supplier Risk Tiering")
SPENG = ("DP-210", "Servicing Provider Engagement")
CONTRACT = ("DP-210", "Contract")
PARTY = ("DP-240", "Party")
EMP = ("DP-192", "Employee")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
COSTDISC = ("DP-004", "Cost Disclosure")
ACCOUNT = ("DP-093", "Account")
CAL = ("DP-013", "Calendar Date")
LE = ("DP-013", "Internal Legal Entity")
ENTAUTH = ("DP-013", "Entity Authorization")


MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-168": dict(
        style="Star",
        entities=[
            # -- facts
            conf("Fact Share Class NAV", SCNAV, [("27", "Share Class NAV")], role="Fact", measures=True,
                 grain="one row = fund NAV calculation (book x valuation date x NAV calculation source x NAV version) x "
                       "share class",
                 note="Conformed from DP-165, which publishes the NAV of record and every NAV value (CD-330); this "
                      "product adds control facts only. Holds the measures, which read the check, release and "
                      "transmission facts through the shared NAV keys."),
            conf("Fact Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")], role="Fact",
                 grain="one row = fund accounting book x valuation date x NAV calculation source x NAV version",
                 note="Conformed from DP-165. Official and Firm Shadow calculations are rows of the same entity told "
                      "apart by NAV Calculation Source; Shadow NAV Variance compares the two rows of one book and "
                      "valuation date, and the Firm Shadow rows are control data here, never a NAV. NAV Version Type "
                      "and Number give the re-strike count."),
            fact("Fact NAV Control Check", [("27", "NAV Control Check")],
                 ["Checked Fund NAV", "Checked Class NAV", "NAV Control Check Type", "Check Run Sequence"],
                 grain="one row = NAV (fund calculation, or class NAV) x check type x check run sequence",
                 note="Every run of a check is kept so a check failed then re-run and passed still shows the failure. "
                      "Oversight Check Indicator separates the adviser's own oversight checks from the administrator's."),
            conf("Fact NAV Dissemination", DISS, [("27", "NAV Dissemination")], role="Fact",
                 grain="one row = share class NAV x release sequence",
                 note="Conformed from DP-165; a corrected release names the release it replaces."),
            fact("Fact NAV Transmission", [("29", "Price & Rate Transmission")], ["Price Transmission Key"],
                 grain="one row = NAV release x transmission channel x attempt",
                 note="Per-channel delivery of each release (Profile, Nasdaq, platforms, insurers); the source of "
                      "Channel Delivery On Time %, Release-to-Delivery Lag and the re-dissemination check for corrected "
                      "releases."),
            fact("Fact TA Control Check", [("29", "TA Control Check")], ["TA Control Check ID"],
                 grain="one row = transfer agent control check (control type x share class x business date)",
                 note="Published by DP-181 (consumer), so modeled here with its registry key; the capital stock proof "
                      "a NAV check relies on for Capital Stock Proof Reliance %."),
            # -- dimensions
            conf("Fund Accounting Book", BOOK165, [("27", "Fund Accounting Book")],
                 note="Conformed from DP-165 (mastered in DP-166)."),
            conf("Fund Book Operating Period", BOOKOP165, [("27", "Fund Book Operating Period")],
                 note="Conformed from DP-165; the operating model and administrator of record by period decide which "
                      "calculation source is official and whether a firm shadow NAV is expected."),
            conf("Fund", PROD, [("01", "Valuation Terms")],
                 note="Conformed from DP-004 Investment Product; Valuation Terms folds here (valuation point and "
                      "publication channels set the release deadline and the channels a release must reach)."),
            conf("Share Class", SHARE, note="Conformed from DP-004."),
            conf("Fund Administrator", ("DP-143", "Party"),
                 note="Conformed from DP-143's Party, which republishes the DP-240 Party; DP-240 is not upstream here."),
            conf("Employee", EMP, note="Conformed from DP-192: check performers and NAV approvers."),
            conf("Calendar Date", CAL, note="The valuation date and the control business date."),
        ],
        relationships=[
            rel("Fact Share Class NAV", "Fact Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Fact Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Fact Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("Fact Fund NAV Calculation", "Calendar Date", ["Valuation Date"]),
            rel("Fact Fund NAV Calculation", "Employee", ["NAV Approved By"], optional=True),
            rel("Fact NAV Control Check", "Fact Fund NAV Calculation", ["Checked Fund NAV"]),
            rel("Fact NAV Control Check", "Fact Share Class NAV", ["Checked Class NAV"], optional=True,
                note="Blank for checks run on the fund calculation as a whole."),
            rel("Fact NAV Control Check", "Fact TA Control Check", ["Relied-On TA Control Check"], optional=True,
                note="Filled for the capital stock proof reliance check."),
            rel("Fact NAV Control Check", "Employee", ["Check Performed By"], optional=True),
            rel("Fact NAV Dissemination", "Fact Share Class NAV", ["Released NAV"]),
            rel("Fact NAV Dissemination", "Fact NAV Dissemination", ["Corrected Release"], card="1:1", optional=True,
                note="The earlier release a corrected release replaces."),
            rel("Fact NAV Transmission", "Fact NAV Dissemination", ["Transmitted Dissemination"]),
            rel("Fact TA Control Check", "Share Class", ["Control Share Class"]),
            rel("Fact TA Control Check", "Calendar Date", ["Control Business Date"]),
            rel("Fund Book Operating Period", "Fund Accounting Book", ["Operated Book"]),
            rel("Fund Book Operating Period", "Fund Administrator", ["Fund Administrator of Record"], optional=True,
                note="Blank for books kept in house."),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
            rel("Share Class", "Fund", ["Parent Product"]),
        ],
        notes=("Star for NAV oversight and release control. The NAV values are conformed from DP-165 and only the control "
               "facts (checks, releases' transmissions, relied-on TA checks) are added, so the NAV of record is never "
               "restated here. The TA control check is a DP-181 (consumer) object and is modeled as this product's own "
               "fact. DP-148 is upstream for price-challenge context but contributes no input object, so no entity. "
               "External references: none beyond the conformed entities; the Fund Administrator dimension is conformed "
               "from DP-143's Party because DP-240 is not upstream."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-169": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Swing Pricing Decision", [("27", "Swing Pricing Decision")], ["Swing Pricing Decision ID"],
                 measures=True,
                 grain="one row = swing pricing decision (fund x valuation date, SWG-)",
                 note="The daily decision with the net activity estimate and the parameter in force; holds the "
                      "measures, which read the NAV error, as-of order and remediation facts through the shared fund, "
                      "share class and date dimensions."),
            fact("Fact NAV Error Case", [("27", "NAV Error Case")], ["NAV Error Case ID"],
                 grain="one row = NAV error case (NEC-)",
                 note="Materiality, fund loss and reimbursement at case level; Correction Methods and Regulators "
                      "Notified are held as listed values."),
            fact("Fact NAV Error Impact", [("27", "NAV Error Impact")],
                 ["Impact Case", "Impacted Share Class", "Impacted Valuation Date"],
                 grain="one row = NAV error case x impacted share class x impacted valuation date",
                 note="Published against corrected NAV per class and date; the source of NAV Error Impact Tie-Out and "
                      "Materiality Consistency Exceptions."),
            conf("Fact Share Class NAV", SCNAV, [("27", "Share Class NAV")], role="Fact",
                 grain="one row = fund NAV calculation x share class",
                 note="Conformed from DP-165; Swung NAV per Share and Applied Swing Decision give Swung NAV Tie-Out."),
            fact("Fact Fund Order", [("29", "Fund Order"), ("29", "As-Of Order Detail")], ["Fund Order ID"],
                 grain="one row = fund order (as-of orders only are in scope)",
                 note="Published by DP-177 (consumer), so modeled here with its registry key. As-Of Order Detail folds "
                      "in (one row per order) and links the dilution to a NAV error case or a servicing error for "
                      "Unlinked As-Of Dilution."),
            fact("Fact Servicing Error", [("13", "Servicing Error")], ["Servicing Error ID"],
                 grain="one row = servicing error event",
                 note="Published by DP-043 (consumer), so modeled here with its registry key; the shareholder side of a "
                      "NAV error."),
            fact("Fact Shareholder Remediation", [("13", "Shareholder Remediation")], ["Remediation ID"],
                 grain="one row = servicing error x remediated account",
                 note="Published by DP-043 (consumer); compensation for Shareholder Remediation Outstanding."),
            # -- dimensions
            dim("Swing Pricing Parameter", [("27", "Swing Pricing Parameter")],
                ["Parameter Fund", "Parameter Effective From"],
                note="Type 2 by effective period, so a decision is checked against the parameter in force on its date."),
            conf("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")],
                 note="Conformed from DP-165; Fund Net Assets Amount is the denominator of Net Activity Ratio."),
            conf("Fund Accounting Book", BOOK165, [("27", "Fund Accounting Book")], note="Conformed from DP-165."),
            conf("Fund", PROD, note="Conformed from DP-004 Investment Product."),
            conf("Share Class", SHARE, [("01", "Investor Transaction Charge")],
                 note="Conformed from DP-004; Investor Transaction Charge folds here (anti-dilution mechanism and the "
                      "maximum swing factor the prospectus allows, for Swing Factor Exceptions)."),
            conf("Reimbursing Entity", LE, note="Conformed from DP-013 Internal Legal Entity: the adviser or affiliate "
                                                "that reimburses the fund."),
            conf("Employee", EMP, note="Conformed from DP-192: decision approvers and case owners."),
            conf("Calendar Date", CAL, note="Valuation dates of decisions and impacts."),
        ],
        relationships=[
            rel("Fact Swing Pricing Decision", "Fund", ["Decision Fund"]),
            rel("Fact Swing Pricing Decision", "Swing Pricing Parameter", ["Applied Swing Parameter"]),
            rel("Fact Swing Pricing Decision", "Calendar Date", ["Decision Valuation Date"]),
            rel("Fact Swing Pricing Decision", "Employee", ["Decision Approved By"], optional=True),
            rel("Swing Pricing Parameter", "Fund", ["Parameter Fund"]),
            rel("Fact Share Class NAV", "Fact Swing Pricing Decision", ["Applied Swing Decision"], optional=True,
                note="Blank on days the fund did not swing."),
            rel("Fact Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Fact Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
            rel("Share Class", "Fund", ["Parent Product"]),
            rel("Fact NAV Error Case", "Fund", ["Error Fund"]),
            rel("Fact NAV Error Case", "Reimbursing Entity", ["Reimbursing Entity"], optional=True),
            rel("Fact NAV Error Case", "Employee", ["Case Owner"], optional=True),
            rel("Fact NAV Error Impact", "Fact NAV Error Case", ["Impact Case"]),
            rel("Fact NAV Error Impact", "Share Class", ["Impacted Share Class"]),
            rel("Fact NAV Error Impact", "Calendar Date", ["Impacted Valuation Date"]),
            rel("Fact NAV Error Impact", "Fact Share Class NAV", ["Published NAV"], optional=True,
                note="The NAV version originally published."),
            rel("Fact NAV Error Impact", "Fact Share Class NAV", ["Corrected NAV"], optional=True,
                note="The re-struck NAV version."),
            rel("Fact Fund Order", "Share Class", ["Order Share Class"]),
            rel("Fact Fund Order", "Fact Fund Order", ["Original Fund Order"], optional=True,
                note="The order an as-of order replaces or reprocesses."),
            rel("Fact Fund Order", "Fact NAV Error Case", ["Related NAV Error Case"], optional=True),
            rel("Fact Fund Order", "Fact Servicing Error", ["Related Servicing Error"], optional=True),
            rel("Fact Servicing Error", "Fact NAV Error Case", ["Related NAV Error Case"], optional=True,
                note="Model gap: the registry has no REFS entry for 13 Servicing Error.Related NAV Error Case (target "
                     "27 NAV Error Case); drawn here from the attribute's declared type."),
            rel("Fact Shareholder Remediation", "Fact Servicing Error", ["Fact Servicing Error Key"],
                note="Carries the Servicing Error ID. Model gap: Shareholder Remediation has no input attribute for its "
                     "servicing error, although its grain is servicing error x remediated account."),
        ],
        notes=("Star with two spines, the daily swing pricing decision and the NAV error case with its per-class, "
               "per-date impacts, plus the as-of order and servicing error companions that carry the shareholder side. "
               "Fund orders (DP-177) and servicing errors and remediation (DP-043) are consumer objects and are modeled "
               "as this product's own facts. The swing decision joins the fund NAV calculation through fund and "
               "valuation date (Fund Accounting Book.Book Fund and Valuation Date), since the decision carries no NAV "
               "reference. External references (keys carried, not linked): NAV Error Case.Reimbursing Third Party to 02 "
               "Party (Model gap: no upstream foundational product of this spec publishes Party; DP-240 is not "
               "upstream); Shareholder Remediation's remediated account (not an input)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-170": dict(
        style="Star",
        entities=[
            # -- facts
            conf("Fact Fund Expense Accrual", EXPACC, [("27", "Fund Expense Accrual")], role="Fact", measures=True,
                 grain="one row = fund (or share class) x expense type x accrual date",
                 note="Conformed from DP-165. The product grain; holds the measures, which read the budget, waiver, "
                      "payment and share class fee terms through the shared fund, share class and date dimensions."),
            fact("Fact Fund Expense Budget", [("27", "Fund Expense Budget")],
                 ["Budget Fund", "Budget Expense Type", "Budget Fiscal Year End"],
                 grain="one row = fund x expense type x fiscal year",
                 note="The comparison base for Accrued vs Budget YTD and Projected Year-End Variance."),
            conf("Fact Expense Cap & Waiver Accrual", WAIVACC, [("27", "Expense Cap & Waiver Accrual")], role="Fact",
                 grain="one row = share class x waiver type x accrual date",
                 note="Conformed from DP-165; the fund side of the waiver, tied to the adviser's receivable and payable."),
            fact("Fact Fund Expense Payment", [("27", "Fund Expense Payment")],
                 ["Paying Fund", "Expense Payee", "Fund Payment Reference"],
                 grain="one row = fund x payee x payment",
                 note="Paying Safekeeping Account lets Payments from Ineligible Accounts test the account type."),
            fact("Fact Waiver Record", [("10", "Waiver Record")], ["Waiver Record ID"],
                 grain="one row = supported share class x waiver type x accounting period (WVR-)",
                 note="The adviser's own waiver record in 10, for Waiver Record Tie-Out and Adviser Side Unbooked."),
            conf("Fact Share Class NAV", SCNAV, [("27", "Share Class NAV")], role="Fact",
                 grain="one row = fund NAV calculation x share class",
                 note="Conformed from DP-165; Class Net Assets Amount is the base for Expense Cap Headroom."),
            # -- dimensions
            conf("Share Class", SHARE, [("01", "Share Class"), ("01", "Management Fee"), ("01", "Other Ongoing Fees")],
                 note="Conformed from DP-004; Management Fee and Other Ongoing Fees fold here (the contractual rates "
                      "Fee Rate Exceptions compares with the rate applied)."),
            conf("Cost Disclosure", COSTDISC, [("01", "Cost Disclosure")], pk=["Share Class Key", "Cost Reference Date"],
                 note="Conformed from DP-004; the expense cap and waiver expiry in force for Expense Cap Headroom and "
                      "Waiver Agreements Expiring."),
            conf("Fund", PROD, note="Conformed from DP-004 Investment Product."),
            conf("Expense Payee", VENDOR, note="Conformed from DP-210 Vendor (keyed by Party ID): the service provider "
                                               "or vendor the fund pays."),
            conf("Safekeeping Account", SKA, [("28", "Safekeeping Account")], note="Conformed from DP-167."),
            dim("Payable Invoice", [("19", "Payable Invoice")], ["Payable Invoice ID"],
                note="The adviser's AP voucher for a reimbursement; no foundational model publishes 19 Payable Invoice "
                     "(DP-191 publishes journals and balances only)."),
            dim("Receivable Item", [("19", "Receivable Item")], ["Receivable Document Number"],
                note="The adviser's receivable from the fund for a recoupment; not published by a foundational model."),
            conf("Calendar Date", CAL, note="Accrual and payment dates."),
        ],
        relationships=[
            rel("Fact Fund Expense Accrual", "Fund", ["Accrual Fund"]),
            rel("Fact Fund Expense Accrual", "Share Class", ["Accrual Share Class"], optional=True,
                note="Blank for fund-level expenses."),
            rel("Fact Fund Expense Accrual", "Calendar Date", ["Expense Accrual Date"]),
            rel("Fact Fund Expense Budget", "Fund", ["Budget Fund"]),
            rel("Fact Expense Cap & Waiver Accrual", "Share Class", ["Waiver Share Class"]),
            rel("Fact Expense Cap & Waiver Accrual", "Calendar Date", ["Waiver Accrual Date"]),
            rel("Fact Expense Cap & Waiver Accrual", "Receivable Item", ["Adviser Recoupment Receivable"], optional=True),
            rel("Fact Expense Cap & Waiver Accrual", "Payable Invoice", ["Adviser Reimbursement Payable"], optional=True),
            rel("Fact Fund Expense Payment", "Fund", ["Paying Fund"]),
            rel("Fact Fund Expense Payment", "Expense Payee", ["Expense Payee"]),
            rel("Fact Fund Expense Payment", "Safekeeping Account", ["Paying Safekeeping Account"], optional=True),
            rel("Fact Fund Expense Payment", "Calendar Date", ["Payment Date"]),
            rel("Fact Waiver Record", "Share Class", ["Supported Share Class"]),
            rel("Fact Waiver Record", "Cost Disclosure", ["Expense Cap Terms Reference"], optional=True,
                note="The cap terms the waiver supports; the reference carries the share class and cost reference date."),
            rel("Fact Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Cost Disclosure", "Share Class", ["Share Class Key"],
                note="Borrowed key: Cost Disclosure has no share class attribute of its own (as in DP-004)."),
            rel("Share Class", "Fund", ["Parent Product"]),
            rel("Receivable Item", "Fund", ["Debtor Fund Product"], optional=True),
        ],
        notes=("Star for fund expense control: accruals against budget and contractual rates, cap and waiver accruals "
               "tied to the adviser's own waiver records, receivables and payables, and fund expense payments. The "
               "accruals and class NAV are conformed from DP-165 so the expense ratio inputs equal the NAV of record. "
               "DP-166 and DP-191 are upstream for ledger context but contribute no input object. External references "
               "(keys carried, not linked): Share Class NAV.Parent NAV Calculation (Fund NAV Calculation is not an input "
               "here); Fund Expense Accrual.Applied Fee Schedule (Reference (Management Fee, 01): the fund fee terms, "
               "FSCH-, CW-051, not the 47 client Fee Schedule) and Management Fee.Fee Breakpoint Schedule."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-171": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Distribution Declaration", [("27", "Distribution Declaration")], ["Distribution Declaration ID"],
                 grain="one row = distribution declaration (share class x distribution type x ex-date, FDIV-)",
                 note="Rate, dates, equalization and the reinvest NAV of each declaration."),
            fact("Fact Distribution Character", [("27", "Distribution Character")],
                 ["Fact Distribution Declaration Key", "Distribution Character Type", "Character Data Basis"],
                 measures=True,
                 grain="one row = distribution declaration x tax character x character data basis (estimated or final)",
                 note="The product grain (child group, fold=False). Holds the measures; Character Tie-Out and "
                      "Estimated-to-Final Character Shift compare the bases of one declaration, and the fund tax "
                      "measures read the companion facts through Fund."),
            fact("Fact Distributable Income Estimate", [("27", "Distributable Income Estimate")],
                 ["Estimate Fund", "Distribution Requirement Period", "Estimate Date"],
                 grain="one row = fund x distribution requirement period x estimate date"),
            fact("Fact Fund Tax Year Record", [("27", "Fund Tax Year Record")], ["Fund Tax Year Record ID"],
                 grain="one row = fund x tax year x tax jurisdiction",
                 note="Taxable income, excise requirement and loss carryforwards per tax year."),
            fact("Fact Book-Tax Difference", [("27", "Book-Tax Difference")],
                 ["Difference Tax Year", "Book-Tax Difference Type", "Difference Instrument"],
                 grain="one row = fund tax year record x difference type x instrument (where instrument-specific)"),
            fact("Fact RIC Test Result", [("27", "RIC Test Result")], ["Tested Fund", "RIC Test Type", "RIC Test Date"],
                 grain="one row = fund x RIC test type x test date",
                 note="Quarterly diversification and annual income tests with headroom (Measured Ratio vs Required "
                      "Threshold)."),
            fact("Fact RIC Qualification Determination", [("35", "RIC Qualification Determination")],
                 ["Determined Fund", "Determination Tax Year"],
                 grain="one row = fund x tax year",
                 note="The board-level determination that relies on the year's test results."),
            dict(name="Determination Test Bridge", role="Bridge", objects=[],
                 pk=["Fact RIC Qualification Determination Key", "Fact RIC Test Result Key"],
                 grain="one row = RIC qualification determination x relied-on RIC test result",
                 note="Resolves the multi-valued Relied RIC Test Results for RIC Determination Coverage %."),
            # -- dimensions
            conf("Share Class NAV", SCNAV, [("27", "Share Class NAV")],
                 note="Conformed from DP-165; the reinvest NAV and shares outstanding for Reinvest NAV Exceptions and "
                      "Undistributed Income per Share."),
            conf("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")], note="Conformed from DP-165."),
            conf("Fund Accounting Book", BOOK165, note="Conformed from DP-165; carries the book's fund."),
            conf("Share Class", SHARE, [("01", "Share Class"), ("01", "Income Distribution")],
                 note="Conformed from DP-004; Income Distribution folds here (policy and frequency set the expected "
                      "declarations)."),
            conf("Fund", PROD, [("01", "Investment Product")],
                 note="Conformed from DP-004 Investment Product; Fiscal Year End sets the excise and RIC calendars."),
            conf("Instrument", INSTR, [("17", "Instrument")], note="Conformed from DP-097."),
            conf("Calendar Date", CAL, note="Ex-dates and test dates."),
        ],
        relationships=[
            rel("Fact Distribution Character", "Fact Distribution Declaration", ["Fact Distribution Declaration Key"],
                note="Borrowed key: carries the Distribution Declaration ID (the group has no attribute for its "
                     "declaration)."),
            rel("Fact Distribution Declaration", "Share Class", ["Declaring Share Class"]),
            rel("Fact Distribution Declaration", "Share Class NAV", ["Reinvest NAV"], optional=True),
            rel("Fact Distribution Declaration", "Calendar Date", ["Ex-Date"]),
            rel("Fact Distributable Income Estimate", "Fund", ["Estimate Fund"]),
            rel("Fact Fund Tax Year Record", "Fund", ["Tax Year Fund"]),
            rel("Fact Book-Tax Difference", "Fact Fund Tax Year Record", ["Difference Tax Year"]),
            rel("Fact Book-Tax Difference", "Instrument", ["Difference Instrument"], optional=True,
                note="Blank for fund-level differences."),
            rel("Fact RIC Test Result", "Fund", ["Tested Fund"]),
            rel("Fact RIC Test Result", "Calendar Date", ["RIC Test Date"]),
            rel("Fact RIC Qualification Determination", "Fund", ["Determined Fund"]),
            rel("Fact RIC Qualification Determination", "Fact Fund Tax Year Record", ["Determination Tax Year"]),
            rel("Determination Test Bridge", "Fact RIC Qualification Determination",
                ["Fact RIC Qualification Determination Key"],
                note="Carries Determined Fund + Determination Tax Year."),
            rel("Determination Test Bridge", "Fact RIC Test Result", ["Fact RIC Test Result Key"],
                note="Carries Tested Fund + RIC Test Type + RIC Test Date, one row per value of Relied RIC Test "
                     "Results."),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
            rel("Share Class", "Fund", ["Parent Product"]),
        ],
        notes=("Star for distributions and fund tax: the declaration by tax character is the spine, with the "
               "distributable income estimate, fund tax year record, book-tax differences, RIC tests and the RIC "
               "qualification determination as companion facts on Fund. DP-166 is upstream for ledger context but "
               "contributes no input object. External reference (key carried, not linked): RIC Qualification "
               "Determination.Audit Committee Review Meeting to 35 Board Meeting (not an input). W5 (CW-165): the 817(h) "
               "link to 33 Compliance Rule Result was dropped with its attribute."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-172": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Custody Reconciliation Break", [("28", "Custody Reconciliation Break")], ["Break ID"],
                 measures=True,
                 grain="one row = custody reconciliation run x break number (CUREC-n-Bnn)",
                 note="The product grain; holds the measures. A break points to whichever book side it compares (book "
                      "holding, book cash balance or ABOR valuation record) and to the custodian statement line."),
            fact("Fact Custody Reconciliation Run", [("28", "Custody Reconciliation Run")],
                 ["Custody Reconciliation Run ID"],
                 grain="one row = reconciliation scope (portfolio or safekeeping account) x reconciliation type x "
                       "business date",
                 note="Denominator of Break Rate and Reconciliation Completion %."),
            fact("Fact Custodian Statement", [("28", "Custodian Statement")],
                 ["Statement Safekeeping Account", "Custodian Statement Type", "Statement Date", "Statement Number"],
                 grain="one row = safekeeping account x statement type x statement date x statement number",
                 note="Statement Receipt % counts statements received against accounts expected to report."),
            fact("Fact Custodian Holding Line", [("28", "Custodian Holding Statement Line")],
                 ["Holding Line Statement", "Custodian Security Identifier", "Place of Safekeeping",
                  "Custodian Balance Type"],
                 grain="one row = custodian statement x security x place of safekeeping x balance type"),
            fact("Fact Custodian Cash Entry", [("28", "Custodian Cash Statement Entry")],
                 ["Cash Entry Statement", "Custodian Entry Reference"],
                 grain="one row = custodian statement x entry reference"),
            fact("Fact ABOR to IBOR Reconciliation", [("27", "ABOR to IBOR Reconciliation")],
                 ["Reconciled Book", "Reconciled Portfolio", "Reconciled Instrument", "Reconciliation Date"],
                 grain="one row = fund accounting book x portfolio x instrument x reconciliation date",
                 note="The book-to-book companion: ABOR attributed quantity against IBOR quantity."),
            # -- conformed book side
            conf("ABOR Valuation Record", ABOR, [("27", "ABOR Valuation Record")],
                 note="Conformed from DP-166; the accounting book side of a valuation break."),
            conf("Portfolio Holding", HOLD, [("18", "Portfolio Holding")],
                 note="Conformed from DP-142; the IBOR side of a position break and of the ABOR to IBOR check."),
            conf("Cash Balance", CASH, [("18", "Cash Balance")], note="Conformed from DP-142; the book side of a cash "
                                                                      "break."),
            conf("Fund Book Portfolio Link", BPLINK, [("27", "Fund Book Portfolio Link")], role="Bridge",
                 grain="one row = fund accounting book x portfolio x link effective period",
                 note="Conformed from DP-166; maps the IBOR portfolios a fund book accounts for, so portfolio-scoped "
                      "runs roll up to funds."),
            # -- dimensions
            conf("Fund Accounting Book", BOOK166, note="Conformed from DP-166, which masters the book."),
            conf("Portfolio", PORT, [("18", "Portfolio")], note="Conformed from DP-140."),
            conf("Safekeeping Account", SKA, [("28", "Safekeeping Account")], note="Conformed from DP-167."),
            conf("Account Provider", PARTY167,
                 note="Conformed from DP-167's Party (DP-240 is not upstream): the custodian that provides the "
                      "safekeeping account, for breaks by custodian."),
            conf("Place of Safekeeping", PARTY167,
                 note="Conformed from DP-167's Party: the depository or sub-custodian named on a statement line."),
            conf("Instrument", INSTR, [("17", "Instrument")], note="Conformed from DP-097."),
            conf("Approved Price", PRICE, [("22", "Approved Price")],
                 note="Conformed from DP-143; the price that values a quantity break for Break Value."),
            conf("Employee", EMP, note="Conformed from DP-192: break owners and run sign-off."),
            conf("Calendar Date", CAL, [("09", "Calendar Date")],
                 note="Day Type separates business days for Break Age and Aged Breaks Over Five Days."),
        ],
        relationships=[
            rel("Fact Custody Reconciliation Break", "Fact Custody Reconciliation Run", ["Break Run"]),
            rel("Fact Custody Reconciliation Break", "Instrument", ["Break Instrument"], optional=True,
                note="Blank for cash breaks."),
            rel("Fact Custody Reconciliation Break", "Portfolio Holding", ["Book Holding"], optional=True),
            rel("Fact Custody Reconciliation Break", "Cash Balance", ["Book Cash Balance"], optional=True),
            rel("Fact Custody Reconciliation Break", "ABOR Valuation Record", ["ABOR Valuation Record"], optional=True),
            rel("Fact Custody Reconciliation Break", "Fact Custodian Holding Line", ["Custodian Statement Line"],
                optional=True, note="Blank when the custodian reports nothing for a book position."),
            rel("Fact Custody Reconciliation Break", "Approved Price", ["Difference Valuation Price"], optional=True),
            rel("Fact Custody Reconciliation Break", "Employee", ["Break Owner"], optional=True),
            rel("Fact Custody Reconciliation Run", "Portfolio", ["Reconciled Portfolio"], optional=True),
            rel("Fact Custody Reconciliation Run", "Safekeeping Account", ["Reconciled Safekeeping Account"],
                optional=True),
            rel("Fact Custody Reconciliation Run", "Fact Custodian Statement", ["Compared Custodian Statement"],
                optional=True, note="Blank when no statement was received, which is itself an exception."),
            rel("Fact Custody Reconciliation Run", "Employee", ["Signed Off By"], optional=True),
            rel("Fact Custody Reconciliation Run", "Calendar Date", ["Reconciliation Business Date"]),
            rel("Fact Custodian Statement", "Safekeeping Account", ["Statement Safekeeping Account"]),
            rel("Fact Custodian Statement", "Calendar Date", ["Statement Date"]),
            rel("Fact Custodian Holding Line", "Fact Custodian Statement", ["Holding Line Statement"]),
            rel("Fact Custodian Holding Line", "Instrument", ["Statement Line Instrument"], optional=True,
                note="Blank until the custodian's security identifier is matched to the security master."),
            rel("Fact Custodian Holding Line", "Place of Safekeeping", ["Place of Safekeeping"]),
            rel("Fact Custodian Cash Entry", "Fact Custodian Statement", ["Cash Entry Statement"]),
            rel("Fact ABOR to IBOR Reconciliation", "Fund Accounting Book", ["Reconciled Book"]),
            rel("Fact ABOR to IBOR Reconciliation", "Portfolio", ["Reconciled Portfolio"]),
            rel("Fact ABOR to IBOR Reconciliation", "Instrument", ["Reconciled Instrument"]),
            rel("Fact ABOR to IBOR Reconciliation", "Portfolio Holding", ["Compared Holding"], optional=True),
            rel("Fact ABOR to IBOR Reconciliation", "Calendar Date", ["Reconciliation Date"]),
            rel("ABOR Valuation Record", "Fund Accounting Book", ["Valuation Book"]),
            rel("ABOR Valuation Record", "Instrument", ["Valued Instrument"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Cash Balance", "Portfolio", ["Cash Balance Portfolio"]),
            rel("Cash Balance", "Safekeeping Account", ["Cash Safekeeping Account"], optional=True),
            rel("Fund Book Portfolio Link", "Fund Accounting Book", ["Linked Book"]),
            rel("Fund Book Portfolio Link", "Portfolio", ["Accounted Portfolio"]),
            rel("Safekeeping Account", "Account Provider", ["Account Provider"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
        ],
        notes=("Star for custody reconciliation: the break is the spine, with the run, the custodian statement and its "
               "holding and cash lines, and the ABOR to IBOR reconciliation as companion facts. The book side is "
               "conformed (holdings and cash from DP-142, ABOR valuation from DP-166), so a break always points to the "
               "published book record. External references (keys carried, not linked): Custody Reconciliation "
               "Break.Related Settlement Instruction to 26 Settlement Instruction and Related AP Order to 29 AP Creation "
               "/ Redemption Order (not inputs); Portfolio.Middle Office Provider to 02 Party (held on the conformed "
               "Portfolio)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-173": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Corporate Action Entitlement", [("28", "Corporate Action Entitlement")],
                 ["Corporate Action Entitlement ID"], measures=True,
                 grain="one row = corporate action event x safekeeping account x entitled portfolio (CAEN-)",
                 note="The product grain; holds the measures, which read elections, payments and income collection "
                      "through the entitlement and the tax and class action facts through Fund."),
            conf("Fact Custodian Notification", CANOTE, [("28", "Corporate Action Notification Receipt")], role="Fact",
                 grain="one row = custodian notification message received for an event and safekeeping account",
                 note="Conformed from DP-099, which publishes the receipts it scrubs into the golden copy; Golden Copy "
                      "Discrepancy Indicator feeds Golden Copy Discrepancies. The key is DP-099's surrogate."),
            fact("Fact Corporate Action Election", [("28", "Corporate Action Election")],
                 ["Corporate Action Election ID"],
                 grain="one row = election instruction on an entitlement",
                 note="Decision maker and the linked investment decision evidence each voluntary election."),
            fact("Fact Corporate Action Payment", [("28", "Corporate Action Payment")],
                 ["Paid Entitlement", "Payment Confirmation Reference"],
                 grain="one row = entitlement x custodian payment confirmation",
                 note="Reversals are rows (Reversal Indicator) so a reversed payment is not counted as paid."),
            fact("Fact Income Collection", [("28", "Income Collection")], ["Income Entitlement"],
                 grain="one row = income entitlement",
                 note="Expected against received income for Outstanding Income Claims and Expected Income Not Accrued."),
            conf("Fact Income Accrual", INCACC, [("27", "Income Accrual")], role="Fact",
                 grain="one row = fund accounting book x instrument x income type x accrual date",
                 note="Conformed from DP-166; the accounting accrual the collection is expected to match."),
            fact("Fact Withholding Tax Reclaim", [("28", "Withholding Tax Reclaim")], ["Withholding Tax Reclaim ID"],
                 grain="one row = withholding tax reclaim (WHTR-)"),
            fact("Fact Tax Relief Documentation", [("28", "Tax Relief Documentation")],
                 ["Beneficial Owner Fund", "Relief Market", "Tax Relief Method", "Relief Effective From"],
                 grain="one row = fund x market x relief method x effective period",
                 note="Treaty rate in force at pay date, for Excess Withholding and Relief Documentation Expiring."),
            fact("Fact Class Action Claim", [("28", "Class Action Claim")], ["Class Action Claim ID"],
                 grain="one row = class action claim (SCAC-)"),
            # -- dimensions
            conf("Corporate Action Event", CAE, [("17", "Corporate Action Event")], note="Conformed from DP-099."),
            conf("Corporate Action Option", CAO, [("17", "Corporate Action Option")], note="Conformed from DP-099."),
            conf("Safekeeping Account", SKA, [("28", "Safekeeping Account")], note="Conformed from DP-167."),
            conf("Portfolio", PORT, [("18", "Portfolio")], note="Conformed from DP-140."),
            conf("Client Account", ACCOUNT, [("15", "Account")],
                 note="Conformed from DP-093 Account: the separately managed account a class action claim is filed for."),
            conf("Fund", PROD, note="Conformed from DP-004 Investment Product."),
            conf("Fund Accounting Book", BOOK166, note="Conformed from DP-166; the book an income accrual sits in."),
            conf("Instrument", INSTR, note="Conformed from DP-097."),
            conf("Party", PARTY167,
                 note="Conformed from DP-167's Party (DP-240 is not upstream): custodians (account providers) and "
                      "reclaim and claim filing agents."),
            conf("Employee", EMP, note="Conformed from DP-192: election decision makers."),
            conf("Calendar Date", CAL, [("09", "Calendar Date")],
                 note="Pay dates and deadlines; Day Type for business-day timeliness."),
        ],
        relationships=[
            rel("Fact Corporate Action Entitlement", "Corporate Action Event", ["Entitlement Event"]),
            rel("Fact Corporate Action Entitlement", "Safekeeping Account", ["Entitled Safekeeping Account"]),
            rel("Fact Corporate Action Entitlement", "Portfolio", ["Entitled Portfolio"], optional=True),
            rel("Fact Custodian Notification", "Corporate Action Event", ["Notified Event"], optional=True,
                note="Blank until the custodian's event reference is matched to the golden copy."),
            rel("Fact Custodian Notification", "Safekeeping Account", ["Notified Safekeeping Account"]),
            rel("Fact Corporate Action Election", "Fact Corporate Action Entitlement", ["Elected Entitlement"]),
            rel("Fact Corporate Action Election", "Corporate Action Option", ["Elected Option"]),
            rel("Fact Corporate Action Election", "Employee", ["Election Decision Maker"], optional=True),
            rel("Fact Corporate Action Election", "Calendar Date", ["Internal Election Deadline"], optional=True),
            rel("Fact Corporate Action Payment", "Fact Corporate Action Entitlement", ["Paid Entitlement"]),
            rel("Fact Corporate Action Payment", "Calendar Date", ["Payment Posting Date"]),
            rel("Fact Income Collection", "Fact Corporate Action Entitlement", ["Income Entitlement"], card="1:1"),
            rel("Fact Income Collection", "Fact Income Accrual", ["Expected Income Accrual"], optional=True),
            rel("Fact Income Collection", "Fact Corporate Action Payment", ["Received Payment"], optional=True),
            rel("Fact Income Accrual", "Fund Accounting Book", ["Accrual Book"]),
            rel("Fact Income Accrual", "Instrument", ["Accrual Instrument"]),
            rel("Fact Income Accrual", "Corporate Action Event", ["Related Corporate Action Event"], optional=True),
            rel("Fact Income Accrual", "Fact Income Collection", ["Related Income Collection"], optional=True,
                note="The accrual side of the same pairing; either side may be filled first."),
            rel("Fact Withholding Tax Reclaim", "Fund", ["Reclaiming Fund"]),
            rel("Fact Withholding Tax Reclaim", "Fact Corporate Action Payment", ["Source Payment"], optional=True),
            rel("Fact Withholding Tax Reclaim", "Party", ["Filing Agent"], optional=True),
            rel("Fact Tax Relief Documentation", "Fund", ["Beneficial Owner Fund"]),
            rel("Fact Class Action Claim", "Corporate Action Event", ["Class Action Event"]),
            rel("Fact Class Action Claim", "Fund", ["Claiming Fund"], optional=True,
                note="One of Claiming Fund and Claiming Client Account is filled."),
            rel("Fact Class Action Claim", "Client Account", ["Claiming Client Account"], optional=True),
            rel("Fact Class Action Claim", "Party", ["Claim Filing Agent"], optional=True),
            rel("Corporate Action Event", "Instrument", ["Event Instrument"]),
            rel("Corporate Action Event", "Calendar Date", ["Corporate Action Payment Date"]),
            rel("Corporate Action Option", "Corporate Action Event", ["Option Event"]),
            rel("Safekeeping Account", "Party", ["Account Provider"]),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
        ],
        notes=("Star for corporate action and asset servicing: the entitlement is the spine, with elections, payments "
               "and income collection on it, the custodian notification and the accounting income accrual as conformed "
               "companions, and withholding tax reclaims, relief documentation and class action claims on Fund. "
               "External references (keys carried, not linked): Corporate Action Election.Election Investment Decision "
               "to 24 Investment Decision and Corporate Action Payment.Booked Portfolio Transaction to 18 Portfolio "
               "Transaction (neither is an input)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-174": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Securities Loan", [("28", "Securities Loan")], ["Securities Loan ID", "Loan Mark Date"],
                 measures=True,
                 grain="one row = securities loan (SBL-) x mark date",
                 note="The product grain; holds the measures. The registry key is the loan; Loan Mark Date is added "
                      "because the product keeps every daily mark of an open loan."),
            fact("Fact Lending Collateral Received", [("28", "Lending Collateral Received")],
                 ["Collateralized Loan", "Collateral Pool Borrower", "Lending Collateral Type", "Collateral Instrument",
                  "Collateral Mark Date"],
                 grain="one row = loan (or borrower pool) x collateral item x mark date",
                 note="Pooled collateral names the borrower instead of the loan; Collateral Coverage % allocates it "
                      "across the borrower's loans."),
            fact("Fact Loan Regulatory Report", [("28", "Loan Regulatory Report")],
                 ["Reported Loan", "Loan Reporting Regime"],
                 grain="one row = securities loan x reporting regime (SEC Rule 10c-1a; the SFTR values left with CW-928)"),
            fact("Fact Lending Revenue Allocation", [("28", "Lending Revenue Allocation")],
                 ["Revenue Program", "Revenue Period Start"],
                 grain="one row = lending program x revenue period",
                 note="Gross revenue, agent fee and fund net revenue, with the fund journal entry that books it."),
            # -- dimensions
            dim("Securities Lending Program", [("28", "Securities Lending Program")],
                ["Lending Fund", "Lending Portfolio", "Agent Lender", "Program Effective From"],
                note="The fund or portfolio's program with its agent: on-loan cap and revenue split."),
            dim("Securities Lending Agreement", [("28", "Securities Lending Agreement")],
                ["Agreement Program", "Agreement Agent", "Agreement Counterparty"],
                note="Agency agreement or borrower agreement; eligible collateral and minimum margin."),
            conf("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")],
                 note="Conformed from DP-165; total and net assets for On-Loan to Net Assets % (memo) and Program "
                      "Utilization %."),
            conf("Fund Accounting Book", BOOK165, [("27", "Fund Accounting Book")], note="Conformed from DP-165."),
            conf("ABOR Valuation Record", ABOR, [("27", "ABOR Valuation Record")],
                 note="Conformed from DP-166; lendable positions for Lendable Utilization %."),
            conf("Fund Journal Entry", FJE, [("27", "Fund Journal Entry")],
                 note="Conformed from DP-166; the entry that books lending revenue, for Revenue Not Booked."),
            conf("Counterparty", CPTY, [("25", "Approved Counterparty Profile")],
                 note="Conformed from DP-115: borrowers, with approval status for Unapproved Borrower Loans."),
            conf("Counterparty Approval Scope", CPTYSCOPE, [("25", "Counterparty Approval Scope")],
                 note="Conformed from DP-115; approval for the securities lending activity, optionally per fund."),
            conf("Lending Agent", PARTY167,
                 note="Conformed from DP-167's Party (DP-240 is not upstream): agent lenders, tri-party agents and "
                      "reporting parties."),
            conf("Instrument", INSTR, [("17", "Instrument")], note="Conformed from DP-097."),
            conf("Fund", PROD, note="Conformed from DP-004 Investment Product."),
            # WP1 re-point (CW-206): DP-165's Portfolio entity left its model with the Firm AUM slices (moved to DP-241);
            # the portfolio is conformed from DP-166's Portfolio (itself conformed from DP-140), DP-166 being upstream.
            conf("Portfolio", ("DP-166", "Portfolio"),
                 note="Conformed from DP-166's Portfolio (DP-140 is not upstream): lending and cash collateral "
                      "reinvestment portfolios."),
            conf("Safekeeping Account", SKA, note="Conformed from DP-167: the account the securities are lent from."),
            conf("Calendar Date", CAL, note="Mark dates."),
        ],
        relationships=[
            rel("Fact Securities Loan", "Securities Lending Program", ["Loan Program"]),
            rel("Fact Securities Loan", "Securities Lending Agreement", ["Governing Agreement"], optional=True),
            rel("Fact Securities Loan", "Counterparty", ["Borrower"]),
            rel("Fact Securities Loan", "Instrument", ["Loaned Instrument"]),
            rel("Fact Securities Loan", "Safekeeping Account", ["Lent From Account"], optional=True),
            rel("Fact Securities Loan", "Calendar Date", ["Loan Mark Date"]),
            rel("Fact Lending Collateral Received", "Fact Securities Loan", ["Collateralized Loan", "Collateral Mark Date"],
                optional=True, note="Blank loan for collateral pooled at borrower level."),
            rel("Fact Lending Collateral Received", "Counterparty", ["Collateral Pool Borrower"], optional=True),
            rel("Fact Lending Collateral Received", "Instrument", ["Collateral Instrument"], optional=True,
                note="Blank for cash collateral."),
            rel("Fact Lending Collateral Received", "Lending Agent", ["Tri-Party Agent"], optional=True),
            rel("Fact Loan Regulatory Report", "Fact Securities Loan", ["Reported Loan"],
                note="Joins to the loan's mark rows by loan ID; a report is per loan, not per mark."),
            rel("Fact Loan Regulatory Report", "Lending Agent", ["Reporting Party"], optional=True),
            rel("Fact Lending Revenue Allocation", "Securities Lending Program", ["Revenue Program"]),
            rel("Fact Lending Revenue Allocation", "Fund Journal Entry", ["Booked Fund Journal Entry"], optional=True,
                note="Blank until the fund's share is booked."),
            rel("Securities Lending Program", "Fund", ["Lending Fund"], optional=True),
            rel("Securities Lending Program", "Portfolio", ["Lending Portfolio"], optional=True),
            rel("Securities Lending Program", "Portfolio", ["Cash Collateral Reinvestment Portfolio"], optional=True),
            rel("Securities Lending Program", "Lending Agent", ["Agent Lender"]),
            rel("Securities Lending Agreement", "Securities Lending Program", ["Agreement Program"]),
            rel("Securities Lending Agreement", "Lending Agent", ["Agreement Agent"]),
            rel("Securities Lending Agreement", "Counterparty", ["Agreement Counterparty"], optional=True,
                note="Blank for the agency agreement with the agent lender."),
            rel("Counterparty Approval Scope", "Counterparty", ["Scope Counterparty"]),
            rel("Counterparty Approval Scope", "Fund", ["Scope Fund"], optional=True),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("ABOR Valuation Record", "Fund Accounting Book", ["Valuation Book"]),
            rel("ABOR Valuation Record", "Instrument", ["Valued Instrument"]),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
        ],
        notes=("Star for securities lending: the daily-marked loan is the spine, with collateral, regulatory reports "
               "and revenue allocation as companion facts, and the program and agreement as this product's own "
               "dimensions. Net assets come from DP-165 and lendable positions from DP-166, so utilization is measured "
               "against the NAV of record. Fund Journal Entry is conformed from DP-166 without a link to its book, since "
               "only its ID, status and date are inputs."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-175 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ------------------------------------------------------------------------------------------------------------------
    "DP-176": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Provider Oversight", role="Fact", objects=[], pk=["Fact Provider Oversight Key"],
                 measures=True,
                 grain="one row = fund service provider (02 party) x provider role x reporting month",
                 note="The product grain, assembled from the provider role entities (custodian profile, servicing "
                      "provider engagement, product party role, supplier engagement) and the monthly facts; holds the "
                      "measures. Provider role is a degenerate attribute. Model gap: no input object sits at this "
                      "grain, so the fact has a surrogate key."),
            fact("Fact Foreign Custody Assessment", [("28", "Foreign Custody Assessment")],
                 ["Assessed Arrangement", "Assessed Depository", "Foreign Custody Assessment Type", "Assessment Date"],
                 grain="one row = sub-custodian arrangement or depository x assessment type x assessment date",
                 note="Rule 17f-5 and 17f-7 assessments with the board report date."),
            fact("Fact Custodian Service Review", [("28", "Custodian Service Review")],
                 ["Reviewed Provider", "Reviewed Provider Role", "Review Period Start"],
                 grain="one row = provider x provider role x review period"),
            fact("Fact Custody Reconciliation Run", [("28", "Custody Reconciliation Run")],
                 ["Custody Reconciliation Run ID"],
                 grain="one row = reconciliation scope x reconciliation type x business date",
                 note="Published by DP-172 (consumer), so modeled here with its registry key."),
            fact("Fact Custody Reconciliation Break", [("28", "Custody Reconciliation Break")], ["Break ID"],
                 grain="one row = custody reconciliation run x break number",
                 note="Published by DP-172 (consumer); Custodian Aged Breaks by the account's provider."),
            conf("Fact NAV Dissemination", DISS, [("27", "NAV Dissemination")], role="Fact",
                 grain="one row = share class NAV x release sequence",
                 note="Conformed from DP-165; Administrator Late NAV Releases by the book's administrator of record."),
            fact("Fact NAV Error Case", [("27", "NAV Error Case")], ["NAV Error Case ID"],
                 grain="one row = NAV error case",
                 note="Published by DP-169 (consumer), so modeled here with its registry key; Administrator NAV "
                      "Errors."),
            fact("Fact TA Control Check", [("29", "TA Control Check")], ["TA Control Check ID"],
                 grain="one row = transfer agent control check",
                 note="Published by DP-181 (consumer); the denominator of TA Control Exception Rate."),
            fact("Fact TA Control Exception", [("29", "TA Control Exception")], ["Fact TA Control Exception Key"],
                 grain="one row = TA control check x exception number",
                 note="Published by DP-181 (consumer). Model gap: the registry key is Exception Control Check + Control "
                      "Exception Number, and Control Exception Number is not a spec input, so a surrogate key is used."),
            fact("Fact Service Level Result", [("40", "Service Level Measurement Result")],
                 ["Fact Service Level Result Key"],
                 grain="one row = contracted service level x measurement period",
                 note="Published by DP-219 (consumer). Model gap: the registry key includes Measured Service Level "
                      "Effective From, which is not a spec input, so a surrogate key is used; the result joins its "
                      "contracted level by Measured Contract + Measured Metric Name."),
            fact("Fact Supplier Performance Review", [("40", "Supplier Performance Review")],
                 ["Reviewed Engagement", "Review Period End"],
                 grain="one row = supplier engagement x review period",
                 note="Published by DP-219 (consumer)."),
            fact("Fact Third-Party Risk Assessment", [("37", "Third-Party Risk Assessment")],
                 ["Third-Party Risk Assessment Reference"],
                 grain="one row = third-party risk assessment",
                 note="Published by DP-219 (consumer); residual risk for Critical Providers at Risk."),
            # -- dimensions
            conf("Custodian", CUSTODIAN, [("28", "Custody Provider Profile")],
                 note="Conformed from DP-167: the custody provider profile by role and period."),
            conf("Sub-Custodian Network Arrangement", SUBCUST, [("28", "Sub-Custodian Network Arrangement")],
                 note="Conformed from DP-167."),
            conf("Servicing Provider Engagement", SPENG, [("29", "Servicing Provider Engagement")],
                 note="Conformed from DP-210; transfer agent and other servicing providers with their oversight rating "
                      "(the object moved from 13 to 29 at W3, CW-088)."),
            conf("Product Party Role", PPROLE, [("01", "Product Party Role")],
                 note="Conformed from DP-167; the administrator, custodian, transfer agent and auditor roles a party "
                      "holds for a fund."),
            conf("Supplier Engagement", SUPENG, [("40", "Supplier Engagement")], note="Conformed from DP-210."),
            conf("Supplier Risk Tiering", SUPTIER, [("40", "Supplier Risk Tiering")],
                 note="Conformed from DP-210; criticality tier by period."),
            dim("Outsourcing Arrangement", [("40", "Outsourcing Arrangement")], ["Outsourcing Arrangement ID"],
                note="Published by DP-219 (consumer), so modeled here with its registry key."),
            dim("Contracted Service Level", [("40", "Contracted Service Level")],
                ["Service Level Contract", "Service Level Metric Name", "Service Level Effective From"],
                note="Published by DP-219 (consumer); the target a measurement result is met against."),
            conf("Safekeeping Account", SKA, [("28", "Safekeeping Account")], note="Conformed from DP-167."),
            conf("Fund Accounting Book", BOOK165, [("27", "Fund Accounting Book")], note="Conformed from DP-165."),
            conf("Fund Book Operating Period", BOOKOP165, [("27", "Fund Book Operating Period")],
                 note="Conformed from DP-165; the administrator of record a NAV release or error is attributed to."),
            conf("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")], note="Conformed from DP-165."),
            conf("Share Class NAV", SCNAV, [("27", "Share Class NAV")], note="Conformed from DP-165."),
            conf("Fund", ("DP-165", "Investment Product"),
                 note="Conformed from DP-165's Investment Product (DP-004 is not upstream)."),
            conf("Service Provider", PARTY,
                 note="Conformed from DP-240 Party: every fund service provider, depository and assessing party."),
            conf("Provider Legal Entity", LE, note="Conformed from DP-013 Internal Legal Entity: the firm entity "
                                                   "that holds the provider relationship."),
            conf("Contract", CONTRACT, note="Conformed from DP-210 (DP-213 is not upstream): the service agreement."),
            conf("Calendar Date", CAL, note="Reporting months and business dates."),
        ],
        relationships=[
            rel("Fact Provider Oversight", "Service Provider", ["Service Provider Key"],
                note="Carries the provider's Party ID."),
            rel("Fact Provider Oversight", "Calendar Date", ["Calendar Date Key"],
                note="The month-end date of the reporting month."),
            rel("Custodian", "Service Provider", ["Provider Party"]),
            rel("Custodian", "Provider Legal Entity", ["Provider Legal Entity"]),
            rel("Custodian", "Contract", ["Service Agreement Reference"], optional=True),
            rel("Sub-Custodian Network Arrangement", "Service Provider", ["Arrangement Global Custodian"]),
            rel("Sub-Custodian Network Arrangement", "Service Provider", ["Sub-Custodian"]),
            rel("Sub-Custodian Network Arrangement", "Service Provider", ["Securities Depository"], optional=True),
            rel("Fact Foreign Custody Assessment", "Sub-Custodian Network Arrangement", ["Assessed Arrangement"],
                optional=True, note="One of Assessed Arrangement and Assessed Depository is filled."),
            rel("Fact Foreign Custody Assessment", "Service Provider", ["Assessed Depository"], optional=True),
            rel("Fact Foreign Custody Assessment", "Service Provider", ["Assessing Party"], optional=True),
            rel("Fact Custodian Service Review", "Service Provider", ["Reviewed Provider"]),
            rel("Fact Custody Reconciliation Run", "Safekeeping Account", ["Reconciled Safekeeping Account"],
                optional=True),
            rel("Fact Custody Reconciliation Run", "Calendar Date", ["Reconciliation Business Date"]),
            rel("Fact Custody Reconciliation Break", "Fact Custody Reconciliation Run", ["Break Run"]),
            rel("Safekeeping Account", "Service Provider", ["Account Provider"]),
            rel("Fact NAV Dissemination", "Share Class NAV", ["Released NAV"]),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("Fund Book Operating Period", "Fund Accounting Book", ["Operated Book"]),
            rel("Fund Book Operating Period", "Service Provider", ["Fund Administrator of Record"], optional=True),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
            rel("Fact NAV Error Case", "Fund", ["Error Fund"]),
            rel("Fact NAV Error Case", "Service Provider", ["Reimbursing Third Party"], optional=True),
            rel("Fact TA Control Check", "Service Provider", ["Control Processing Provider"], optional=True),
            rel("Fact TA Control Check", "Calendar Date", ["Control Business Date"]),
            rel("Fact TA Control Exception", "Fact TA Control Check", ["Exception Control Check"]),
            rel("Servicing Provider Engagement", "Service Provider", ["Servicing Provider"]),
            rel("Product Party Role", "Service Provider", ["Party"]),
            rel("Supplier Engagement", "Servicing Provider Engagement", ["Specialized Servicing Provider Engagement"],
                optional=True),
            rel("Supplier Engagement", "Custodian", ["Specialized Custody Provider Profile"], optional=True),
            rel("Supplier Engagement", "Product Party Role", ["Fund Service Provider Role"], optional=True),
            rel("Supplier Risk Tiering", "Supplier Engagement", ["Tiered Engagement"]),
            rel("Outsourcing Arrangement", "Supplier Engagement", ["Outsourcing Engagement"]),
            rel("Contracted Service Level", "Contract", ["Service Level Contract"]),
            rel("Fact Service Level Result", "Contract", ["Measured Contract"],
                note="Drawn to the contract the registry names; the contracted level is matched on contract and "
                     "metric name."),
            rel("Fact Supplier Performance Review", "Supplier Engagement", ["Reviewed Engagement"]),
            rel("Fact Third-Party Risk Assessment", "Supplier Engagement", ["Assessed Supplier Engagement"]),
        ],
        notes=("Star for fund service provider oversight: the provider x role x month fact rolls up the custody, "
               "administration and transfer agency evidence (service reviews, foreign custody assessments, late NAV "
               "releases, NAV errors, aged custody breaks, TA control exceptions) and the third-party oversight "
               "evidence (service level results, performance reviews, risk assessments, tiering) on the conformed "
               "Service Provider. Objects published only by consumer products (DP-168, DP-169, DP-172, DP-181, DP-043, "
               "DP-219) are modeled as this product's own entities; DP-168 and DP-043 contribute no input object "
               "beyond those already conformed from DP-165 and DP-210. External references: none beyond the model gaps "
               "recorded on Fact Provider Oversight, Fact TA Control Exception and Fact Service Level Result."),
    ),
}
