"""Logical data models, Wave E8 consumer group "invops_a": Star models for the Investment Operations consumer products
DP-148 to DP-156 (price validation, fair value governance, IBOR controls, settlement, OTC derivative lifecycle, margin and
collateral, risk limits and stress tests, fund risk programs, share class risk ratings). See CONTRACT.md.

Conventions used in these stars:
- Facts, companion facts and bridges are built from the product's own inputs and keep the registry keys of their objects,
  so they still join to the foundational entities that master the same records.
- Every object a foundational model publishes is a conformed dimension under its plain conformed name: Approved Price,
  Pricing Point, Pricing Policy, Reference Rate Fixing, Fair Value Determination and ETF Market Statistic (DP-143);
  Portfolio, Portfolio Implementation Link, Portfolio Hierarchy Link, Party and Internal Legal Entity (DP-140); Portfolio
  Transaction (DP-141); Portfolio Holding, Cash Balance and Portfolio Valuation Summary (DP-142); Trading Agreement,
  Credit Support Terms, Eligible Collateral Schedule, Termination Event Trigger, Standing Settlement Instruction and
  Settlement Cycle Rule (DP-147); Portfolio Risk Measure, Risk Calculation Run, Portfolio Exposure, Risk Factor, Curve
  Definition and Benchmark (DP-146); Performance Return (DP-145); Fund Accounting Book and Fund NAV Calculation (DP-165);
  Safekeeping Account (DP-167); Instrument, Dataset and Benchmark (DP-097); Counterparty, Counterparty Trading Limit and
  Employee (DP-115); Employee (DP-192); Model (DP-212); Application (DP-211); Share Class and Investment Product (DP-004);
  Calendar Date, Calendar and Internal Legal Entity (DP-013). The product's own input objects of the same concept sit
  on the conformed dimension and merge with its inherited attributes.
- The fund is the 01 Investment Product, named "Fund" in every star, and is reached from a portfolio through the
  Portfolio Implementation Link bridge (the DP-140 link from book to product).
- Objects mastered by another consumer product are built here from the product's own inputs, keeping the registry key:
  the 25 Trade Allocation published by DP-123 (DP-151), and the 31 risk and 22 valuation-control objects no foundational
  model publishes (tolerance rules, valuation committees, risk limits, stress scenarios). Within this group, where a
  product lists an earlier product of the group upstream and reads a record only by reference, it conforms that
  product's entity: Settlement Instruction (DP-151 into DP-152 and on to DP-153), Repo Trade (DP-152 into DP-153),
  Counterparty Exposure (DP-153 into DP-154) and Stress Scenario (DP-154 into DP-155).
- A single reference attribute that points to an entity with a composite key (a code x effective period, a committee x
  meeting date, a model code x version) is drawn as the foreign key; the rest of the key comes from the context named in
  the relationship note (usually the effective period in force on the fact's date).
- Date roles are conformed from DP-013 Calendar Date only where DP-013 is upstream (DP-148, DP-151, DP-152); elsewhere
  the dates stay degenerate attributes of the facts and the notes record it.
- References to objects whose mastering product is not upstream stay attributes and are listed under "External
  references" in the model notes.
"""


def fact(name, objects, pk, grain, note="", measures=False):
    return dict(name=name, role="Fact", objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def dim(name, src, objects=(), note="", role="Dimension", grain=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note)
    if grain:
        d["grain"] = grain
    return d


def own(name, objects, pk, note="", role="Dimension", grain=""):
    d = dict(name=name, role=role, objects=list(objects), pk=list(pk), note=note)
    if grain:
        d["grain"] = grain
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources
APPROVED = ("DP-143", "Approved Price")
PPOINT = ("DP-143", "Pricing Point")
PPOLICY = ("DP-143", "Pricing Policy")
FVD = ("DP-143", "Fair Value Determination")
FIXING = ("DP-143", "Reference Rate Fixing")
ETFSTAT = ("DP-143", "ETF Market Statistic")
PORT = ("DP-140", "Portfolio")
PIL = ("DP-140", "Portfolio Implementation Link")
PHL = ("DP-140", "Portfolio Hierarchy Link")
FUND140 = ("DP-140", "Investment Product")
PARTY140 = ("DP-140", "Party")
LE140 = ("DP-140", "Internal Legal Entity")
CAL140 = ("DP-140", "Calendar")
PTX141 = ("DP-141", "Portfolio Transaction")
PTX142 = ("DP-142", "Portfolio Transaction")
HOLD = ("DP-142", "Portfolio Holding")
CASH = ("DP-142", "Cash Balance")
PVS = ("DP-142", "Portfolio Valuation Summary")
TA = ("DP-147", "Trading Agreement")
CST = ("DP-147", "Credit Support Terms")
ECS = ("DP-147", "Eligible Collateral Schedule")
TET = ("DP-147", "Termination Event Trigger")
SSI = ("DP-147", "Standing Settlement Instruction")
SCR = ("DP-147", "Settlement Cycle Rule")
PRM = ("DP-146", "Portfolio Risk Measure")
RCR = ("DP-146", "Risk Calculation Run")
PEXP = ("DP-146", "Portfolio Exposure")
RFACTOR = ("DP-146", "Risk Factor")
CURVE = ("DP-146", "Curve Definition")
BMK146 = ("DP-146", "Benchmark")
PERF = ("DP-145", "Performance Return")
FAB = ("DP-165", "Fund Accounting Book")
NAV = ("DP-165", "Fund NAV Calculation")
SAFE = ("DP-167", "Safekeeping Account")
INSTR = ("DP-097", "Instrument")
DATASET = ("DP-097", "Dataset")
BMK097 = ("DP-097", "Benchmark")
CPTY = ("DP-115", "Counterparty")
CTL = ("DP-115", "Counterparty Trading Limit")
EMP115 = ("DP-115", "Employee")
EMP = ("DP-192", "Employee")
MODEL = ("DP-212", "Model")
APP = ("DP-211", "Application")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
STRAT = ("DP-004", "Investment Strategy")
PARTY = ("DP-240", "Party")
CAL = ("DP-013", "Calendar Date")
CALENDAR = ("DP-013", "Calendar")
LE = ("DP-013", "Internal Legal Entity")

PIL_NOTE = ("Bridge from portfolio to the fund it implements (DP-140). A portfolio can implement several products over "
            "time and a fund can be run through several books, so the link is many-to-many; the primary implementation "
            "in force on the fact's date gives the fund roll-up.")
PIL_GRAIN = "one row = portfolio x implemented product / mandate / account / model x link type x effective period"
NO_CAL = ("Calendar Date is not conformed: DP-013 is not in the spec's upstream, so the dates stay degenerate "
          "attributes of the facts (Model gap: add DP-013 upstream to conform the date roles).")

MODELS = {
    # ================================================= 22 Market Data & Pricing =================================================
    "DP-148": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Price Validation Exception", [("22", "Price Validation Exception")],
                 ["Exception Approved Price", "Breached Tolerance Rule", "Exception Raised Timestamp"],
                 "one row = price validation exception (approved price version x tolerance rule x raised timestamp)",
                 note="The spine of the daily exception workbook: open exceptions by age and severity, and approved "
                      "prices still carrying one at the NAV strike, are read from here. Holds the measures; the daily "
                      "summary at pricing point x price date x asset class x source dataset is an aggregate of these "
                      "rows through Approved Price, Instrument and Dataset.",
                 measures=True),
            fact("Fact Price Override", [("22", "Price Override")], ["Overridden Approved Price", "Override Sequence"],
                 "one row = override applied to an approved price (approved price x override sequence)",
                 note="Companion fact for override reasons and the four-eyes test (requester against approver), both "
                      "drawn to Employee."),
            fact("Fact Price Challenge", [("22", "Price Challenge")], ["Price Challenge ID"],
                 "one row = price challenge sent to a vendor (PCHL-)",
                 note="Companion fact for challenges raised, open and outcome; the vendor revision rate compares "
                      "challenges with a changed approved price to all challenges."),
            fact("Fact Price Observation", [("22", "Price Observation"), ("22", "Evaluated Price Detail"),
                                            ("22", "Broker Quote Detail")],
                 ["Price Observation Key"],
                 "one row = price observation (instrument x price type x price origin x source dataset or quoting "
                 "broker x as-of timestamp)",
                 note="Every price received, the evidence the approved price was chosen from. Built here because DP-143 "
                      "publishes the approved price only, not the observations. Evaluated Price Detail and Broker Quote "
                      "Detail fold in (one row per observation). Feeds Primary Source Usage % against the source "
                      "hierarchy."),
            # -- dimensions
            dim("Approved Price", APPROVED, [("22", "Approved Price")],
                note="The certified price the exceptions, overrides and back-tests are raised against, conformed from "
                     "DP-143; this product adds the control facts only and owns no certified number."),
            dim("Pricing Point", PPOINT, [("22", "Pricing Point")]),
            dim("Pricing Policy", PPOLICY, [("22", "Pricing Policy")],
                note="Policy version and pricing operating model in force; the tolerance and source hierarchy rules hang "
                     "from it."),
            own("Price Tolerance Rule", [("22", "Price Tolerance Rule")],
                ["Tolerance Rule Code", "Tolerance Rule Effective From"],
                note="Built from the input: no foundational model publishes tolerance rules. Effective-dated, so an "
                     "exception joins to the version in force at its raised timestamp."),
            own("Pricing Source Hierarchy Rule", [("22", "Pricing Source Hierarchy Rule")],
                ["Hierarchy Rule Code", "Source Rank", "Hierarchy Rule Effective From"],
                note="Built from the input: no foundational model publishes the source hierarchy. Rank 1 rows define "
                     "the primary source for Primary Source Usage %."),
            dim("Instrument", INSTR, [("17", "Instrument")],
                note="Instrument type and asset class for the asset class slice of the daily summary."),
            dim("Dataset", DATASET, [("14", "Dataset")],
                note="Source dataset and data vendor dimension, conformed from DP-097 (upstream) which publishes the "
                     "licensed dataset."),
            dim("Party", PARTY,
                note="Outsourced pricing provider, quoting broker and challenged vendor; one conformed party "
                     "dimension in several roles."),
            dim("Employee", EMP, note="Override requester and approver, exception resolver, challenger, price approver."),
            dim("Calendar Date", CAL, note="Price date, observation date and challenge raised date."),
            dim("Pricing Calendar", CALENDAR, note="The calendar a pricing point follows (DP-013)."),
        ],
        relationships=[
            rel("Fact Price Validation Exception", "Approved Price", ["Exception Approved Price"]),
            rel("Fact Price Validation Exception", "Price Tolerance Rule", ["Breached Tolerance Rule"],
                note="Tolerance Rule Code; the effective period is the one in force at Exception Raised Timestamp."),
            rel("Fact Price Validation Exception", "Fact Price Challenge", ["Resulting Price Challenge"], optional=True,
                note="Set when the exception was resolved by challenging the vendor."),
            rel("Fact Price Validation Exception", "Employee", ["Exception Resolved By"], optional=True),
            rel("Fact Price Override", "Approved Price", ["Overridden Approved Price"]),
            rel("Fact Price Override", "Employee", ["Override Requested By"]),
            rel("Fact Price Override", "Employee", ["Override Approved By"], optional=True,
                note="Four-eyes test: must differ from Override Requested By."),
            rel("Fact Price Challenge", "Fact Price Observation", ["Challenged Observation"]),
            rel("Fact Price Challenge", "Party", ["Challenged Vendor"]),
            rel("Fact Price Challenge", "Employee", ["Challenge Raised By"]),
            rel("Fact Price Challenge", "Calendar Date", ["Challenge Raised Date"]),
            rel("Fact Price Observation", "Instrument", ["Observed Instrument"]),
            rel("Fact Price Observation", "Dataset", ["Source Dataset"], optional=True,
                note="Blank for broker quotes, which carry Quoting Broker instead."),
            rel("Fact Price Observation", "Party", ["Quoting Broker"], optional=True),
            rel("Fact Price Observation", "Calendar Date", ["Observation Date"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
            rel("Approved Price", "Pricing Point", ["Approved Pricing Point"]),
            rel("Approved Price", "Fact Price Observation", ["Selected Observation"], optional=True),
            rel("Approved Price", "Fact Price Override", ["Applied Price Override"], optional=True),
            rel("Approved Price", "Employee", ["Price Approved By"], optional=True),
            rel("Approved Price", "Calendar Date", ["Price Date"]),
            rel("Price Tolerance Rule", "Pricing Policy", ["Tolerance Policy Code"],
                note="Policy code; the version is the one in force over the rule's effective period."),
            rel("Pricing Source Hierarchy Rule", "Pricing Policy", ["Hierarchy Policy Code"],
                note="Policy code; the version is the one in force over the rule's effective period."),
            rel("Pricing Source Hierarchy Rule", "Pricing Point", ["Hierarchy Pricing Point"], optional=True),
            rel("Pricing Source Hierarchy Rule", "Dataset", ["Ranked Source Dataset"]),
            rel("Pricing Policy", "Party", ["Outsourced Pricing Provider"], optional=True),
            rel("Pricing Point", "Pricing Calendar", ["Pricing Calendar"], optional=True),
        ],
        notes="Four facts share the approved price: validation exceptions (the main fact), overrides, vendor challenges "
              "and the raw observations. The approved price, pricing point and pricing policy are conformed from DP-143 "
              "so this product republishes no certified number; only tolerance and source hierarchy rules are built "
              "here, because DP-143 deliberately does not publish them. Instruments Without Tolerance Rule is an "
              "anti-join of Approved Price -> Instrument against the tolerance rule scope (asset class and instrument "
              "type), so there is no fk between them. "
              "External references (not upstream, resolved by joining to the named product): Cataloged Data Quality "
              "Rule (21 Data Quality Rule, DP-210 data quality catalog); Related Vendor Data Issue (14 Vendor Data "
              "Issue); Dataset Vendor (14 Data Vendor, DP-210). DP-044 is upstream but consumer-aligned and publishes "
              "no conformed entity used here."),

    "DP-149": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Fair Value Determination", [("22", "Fair Value Determination")],
                 ["Fair Value Determination ID"],
                 "one row = fair value determination (FVD-: instrument x valuation date x pricing point x portfolio)",
                 note="The main fact: method, hierarchy level, approval and the approving meeting of every "
                      "determination. Built from the input (not conformed from DP-143) because it carries the governance "
                      "columns DP-143 does not publish; it keeps DP-143's key so the two "
                      "join. 22 Private Asset Valuation Detail left with 30 (W4, CW-930). Holds the measures; the fund x valuation date "
                      "summary of fair-valued holdings is an aggregate through Portfolio Holding and the implementation "
                      "link.",
                 measures=True),
            fact("Fact Valuation Input", [("22", "Valuation Input")], ["Input Determination", "Valuation Input Type"],
                 "one row = fair value determination x valuation input type",
                 note="Unobservable inputs and their ranges; Unobservable Inputs Out of Range compares Input Value with "
                      "the range."),
            fact("Fact Valuation Back-Test", [("22", "Valuation Back-Test")],
                 ["Back-Tested Approved Price", "Back-Test Comparison Type", "Comparison Date"],
                 "one row = approved price version x comparison type x comparison date",
                 note="Back-Test Pass Rate. The determination is optional because evaluated vendor prices are "
                      "back-tested too."),
            fact("Fact Fair Value Factor", [("22", "Fair Value Factor")], ["Fair Value Factor Key"],
                 "one row = fair value factor (instrument x pricing date x pricing point x factor source dataset)",
                 note="Vendor fair value factors applied to closing prices; Factors Applied Without Trigger tests the "
                      "trigger event link. Built here because DP-143 does not publish the factors."),
            fact("Fact Valuation Committee Meeting", [("22", "Valuation Committee Meeting")],
                 ["Meeting Committee", "Meeting Date"],
                 "one row = valuation committee x meeting date",
                 note="Companion fact for quorum; Approvals Without Quorate Meeting joins determinations to it."),
            fact("Fact Valuation Committee Membership", [("22", "Valuation Committee Member")],
                 ["Membership Committee", "Committee Member", "Membership Effective From"],
                 "one row = valuation committee x employee x effective period",
                 note="Companion fact for committee independence (members with a portfolio management function)."),
            # -- dimensions
            own("Valuation Committee", [("22", "Valuation Committee")], ["Valuation Committee Code"],
                note="Built from the input: no foundational model publishes the valuation committee."),
            own("Fair Value Trigger Event", [("22", "Fair Value Trigger Event")], ["Trigger Event Key"],
                note="Built from the input: the market events that trigger fair valuation are not published by a "
                     "foundational model."),
            dim("Approved Price", APPROVED, [("22", "Approved Price")],
                note="Links the approved price to the determination or factor it applied."),
            dim("Pricing Policy", PPOLICY, [("22", "Pricing Policy")],
                note="Valuation regulatory frameworks and operating model; the governing policy of each committee."),
            dim("Pricing Point", PPOINT),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Portfolio", PORT,
                note="Conformed from DP-140 (not itself an input); 18 Private Fund Portfolio Detail is no longer read (W4, "
                     "CW-930: the stale private asset valuation measure was dropped)."),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")], role="Bridge",
                grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Fund", FUND140, note="The 01 Investment Product the portfolio implements."),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")],
                note="Fair-valued holdings and their market value for the share-of-portfolio measures (DP-142)."),
            dim("Portfolio Valuation Summary", PVS, [("18", "Portfolio Valuation Summary")],
                note="Total IBOR market value, the denominator of the fair-valued and Level 3 shares (DP-142)."),
            dim("Portfolio Transaction", PTX142, note="The transaction a back-test compares the price with."),
            dim("Model", MODEL, [("37", "Model Inventory Entry")], note="Valuation model (DP-212)."),
            dim("Model Validation", ("DP-212", "Model Validation"), [("37", "Model Validation")],
                note="Determinations on Unvalidated Models reads the latest validation outcome of the model."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Preparers, reviewers and committee members; Employment Status tests current membership."),
            dim("Party", PARTY, note="External valuation agent."),
            dim("Dataset", DATASET, note="Source dataset of a fair value factor."),
            dim("Benchmark", BMK097, note="Reference benchmark of a market-move trigger."),
            dim("Internal Legal Entity", LE140, note="The firm entity that owns a valuation committee."),
        ],
        relationships=[
            rel("Fact Fair Value Determination", "Instrument", ["Fair Valued Instrument"]),
            rel("Fact Fair Value Determination", "Pricing Point", ["Determination Pricing Point"]),
            rel("Fact Fair Value Determination", "Portfolio", ["Valued Portfolio"]),
            rel("Fact Fair Value Determination", "Fair Value Trigger Event", ["Triggering Event"], optional=True),
            rel("Fact Fair Value Determination", "Model", ["Valuation Model Name"], optional=True,
                note="Model ID; the version is the one in use on the valuation date."),
            rel("Fact Fair Value Determination", "Employee", ["Valuation Prepared By"]),
            rel("Fact Fair Value Determination", "Party", ["External Valuation Agent"], optional=True),
            rel("Fact Fair Value Determination", "Fact Valuation Committee Meeting", ["Approving Meeting"],
                optional=True, note="The meeting reference; committee and meeting date resolve it."),
            rel("Fact Valuation Input", "Fact Fair Value Determination", ["Input Determination"]),
            rel("Fact Valuation Back-Test", "Approved Price", ["Back-Tested Approved Price"]),
            rel("Fact Valuation Back-Test", "Fact Fair Value Determination", ["Back-Tested Determination"],
                optional=True),
            rel("Fact Valuation Back-Test", "Portfolio Transaction", ["Comparison Transaction"], optional=True),
            rel("Fact Valuation Back-Test", "Employee", ["Back-Test Reviewed By"], optional=True),
            rel("Fact Fair Value Factor", "Instrument", ["Factor Instrument"]),
            rel("Fact Fair Value Factor", "Pricing Point", ["Factor Pricing Point"], optional=True),
            rel("Fact Fair Value Factor", "Dataset", ["Factor Source Dataset"], optional=True),
            rel("Fact Fair Value Factor", "Fair Value Trigger Event", ["Factor Triggering Event"], optional=True),
            rel("Fact Valuation Committee Meeting", "Valuation Committee", ["Meeting Committee"]),
            rel("Fact Valuation Committee Membership", "Valuation Committee", ["Membership Committee"]),
            rel("Fact Valuation Committee Membership", "Employee", ["Committee Member"]),
            rel("Valuation Committee", "Pricing Policy", ["Governing Pricing Policy"], optional=True,
                note="Policy code; the version in force."),
            rel("Valuation Committee", "Internal Legal Entity", ["Committee Owner Entity"], optional=True),
            rel("Fair Value Trigger Event", "Instrument", ["Affected Instrument"], optional=True),
            rel("Fair Value Trigger Event", "Benchmark", ["Move Reference Benchmark"], optional=True),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
            rel("Approved Price", "Pricing Point", ["Approved Pricing Point"]),
            rel("Approved Price", "Fact Fair Value Determination", ["Applied Fair Value Determination"], optional=True),
            rel("Approved Price", "Fact Fair Value Factor", ["Applied Fair Value Factor"], optional=True),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Valuation Summary", "Portfolio", ["Valued Portfolio"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
            rel("Model Validation", "Model", ["Validated Model"], note="Model ID and version."),
        ],
        notes="The determination is the main fact, with its valuation inputs, back-tests, vendor fair value factors and "
              "committee meetings and memberships as companion facts. Holdings and valuation summaries are conformed "
              "from DP-142 so the fair-valued share of a portfolio is stated against the IBOR market value, and the "
              "fund roll-up runs through the DP-140 implementation link. Fair Value Determination is published by "
              "DP-143 but is the fact here, built from the input with the same key. " + NO_CAL),

    # ================================================ 18 Portfolio & IBOR =================================================
    "DP-150": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Portfolio Position Snapshot", [("18", "Portfolio Position Snapshot")],
                 ["Snapshot Portfolio", "Snapshot Type", "Snapshot As-Of Timestamp"],
                 "one row = portfolio x snapshot type x as-of timestamp; the start-of-day snapshot of each business "
                 "date is the portfolio x business date control row",
                 note="Holds the measures: snapshot timeliness and open breaks are read from the snapshot, and the "
                      "roll, cash and IBOR to fund book tie-outs are computed for the same portfolio x business date "
                      "from Portfolio Holding, Cash Balance, Portfolio Valuation Summary and Fund NAV Calculation. Built "
                      "from the input with DP-142's key.",
                 measures=True),
            fact("Fact Position Adjustment", [("18", "Position Adjustment")],
                 ["Adjusted Portfolio", "Adjusted Instrument", "Adjustment Date", "Adjusting Transaction"],
                 "one row = portfolio x instrument x adjustment date x adjusting portfolio transaction",
                 note="Manual adjustments, their approval and the four-eyes test against the booker of the adjusting "
                      "transaction."),
            fact("Fact Portfolio Transaction Event", [("18", "Portfolio Transaction Event")],
                 ["Event Transaction", "Portfolio Transaction Event Type", "Event Timestamp"],
                 "one row = portfolio transaction x event type x event timestamp",
                 note="Back-dated and amended events; Back-Dated Events Without Restatement tests them against the "
                      "snapshot's restated indicator."),
            # -- dimensions
            dim("Portfolio", PORT, [("18", "Portfolio"), ("18", "Portfolio Accounting Basis")],
                note="IBOR operating model, middle office provider and start-of-day cutoff (DP-140)."),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")], role="Bridge",
                grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Portfolio Hierarchy Link", PHL, [("18", "Portfolio Hierarchy Link")], role="Bridge",
                grain="one row = parent portfolio x child portfolio x link type x effective period",
                note="Rolls sleeves up to their parent book (portfolio to portfolio is many-to-many over time)."),
            dim("Fund", FUND140),
            dim("Portfolio Transaction", PTX141, [("18", "Portfolio Transaction")], note="Conformed from DP-141."),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")],
                note="Start-of-day roll: prior close holdings rolled with the day's transactions against today's "
                     "start-of-day holdings (DP-142)."),
            dim("Cash Balance", CASH, [("18", "Cash Balance")], note="Cash tie-out (DP-142)."),
            dim("Portfolio Valuation Summary", PVS, [("18", "Portfolio Valuation Summary")],
                note="The IBOR side of the IBOR to fund book difference (DP-142)."),
            dim("Fund Accounting Book", FAB, [("27", "Fund Accounting Book")]),
            dim("Fund NAV Calculation", NAV, [("27", "Fund NAV Calculation")],
                note="The fund book side of the IBOR to fund book difference (DP-165)."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Employee", EMP, note="Adjustment approver and event performer."),
            dim("Application", APP, note="Book of record system and event source system (DP-211)."),
            dim("Party", PARTY140, note="Middle office provider (DP-140; DP-240 is not upstream)."),
            dim("Calendar", CAL140, note="Valuation calendar of the portfolio, which sets the business dates."),
        ],
        relationships=[
            rel("Fact Portfolio Position Snapshot", "Portfolio", ["Snapshot Portfolio"]),
            rel("Fact Position Adjustment", "Portfolio", ["Adjusted Portfolio"]),
            rel("Fact Position Adjustment", "Instrument", ["Adjusted Instrument"]),
            rel("Fact Position Adjustment", "Portfolio Holding", ["Adjusted Holding"], optional=True),
            rel("Fact Position Adjustment", "Portfolio Transaction", ["Adjusting Transaction"]),
            rel("Fact Position Adjustment", "Employee", ["Adjustment Approved By"], optional=True),
            rel("Fact Portfolio Transaction Event", "Portfolio Transaction", ["Event Transaction"]),
            rel("Fact Portfolio Transaction Event", "Portfolio Transaction", ["Rebooked As Transaction"], optional=True),
            rel("Fact Portfolio Transaction Event", "Application", ["Event Source System"], optional=True),
            rel("Fact Portfolio Transaction Event", "Employee", ["Event Performed By"], optional=True),
            rel("Portfolio Valuation Summary", "Portfolio", ["Valued Portfolio"]),
            rel("Portfolio Valuation Summary", "Fact Portfolio Position Snapshot", ["Summary Snapshot"], optional=True,
                note="Snapshot reference; portfolio and as-of timestamp resolve it."),
            rel("Portfolio Transaction", "Portfolio", ["Transaction Portfolio"]),
            rel("Portfolio Transaction", "Instrument", ["Transaction Instrument"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Cash Balance", "Portfolio", ["Cash Balance Portfolio"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
            rel("Portfolio Hierarchy Link", "Portfolio", ["Parent Portfolio"]),
            rel("Portfolio Hierarchy Link", "Portfolio", ["Child Portfolio"]),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"],
                note="Book fund; the accounting basis is the fund book's primary basis."),
            rel("Portfolio", "Application", ["Book of Record System"], optional=True),
            rel("Portfolio", "Party", ["Middle Office Provider"], optional=True),
            rel("Portfolio", "Calendar", ["Valuation Calendar"], optional=True),
        ],
        notes="The control row of the spec (portfolio x business date) is the start-of-day Portfolio Position Snapshot, "
              "so the snapshot is the main fact and carries the measures; the tie-outs compare it on the same portfolio "
              "x business date with the conformed IBOR records of DP-142 and the fund NAV of DP-165, reached through "
              "the implementation link and the fund accounting book. Position adjustments and transaction events are "
              "companion facts. " + NO_CAL),

    # ============================================ 26 Trade Operations & Settlement ============================================
    "DP-151": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Settlement Instruction", [("26", "Settlement Instruction"), ("26", "Cash Payment Detail"),
                                                 ("26", "Loan Settlement Detail")],
                 ["Settlement Instruction ID"],
                 "one row = settlement instruction (SETL-), with its latest status, fail, buy-in and penalties read "
                 "from the companion facts; summarized daily at intended settlement date x market x counterparty x "
                 "portfolio x settlement type",
                 note="Holds the measures. Cash Payment Detail and Loan Settlement Detail fold in (one row per "
                      "instruction). The market is the country of Instructed Place of Settlement.",
                 measures=True),
            fact("Fact Settlement Status Event", [("26", "Settlement Status Event")],
                 ["Status Instruction", "Status Timestamp"],
                 "one row = settlement instruction x status advice timestamp",
                 note="The latest status per instruction gives Settled on Intended Date % and Unmatched Before "
                      "Settlement Date."),
            fact("Fact Settlement Fail", [("26", "Settlement Fail"), ("26", "Buy-In Notice")],
                 ["Failed Instruction", "Fail Start Date"],
                 "one row = settlement instruction x fail start date",
                 note="Buy-In Notice folds in (at most one buy-in per fail)."),
            fact("Fact Settlement Penalty", [("26", "Settlement Penalty")], ["Settlement Penalty ID"],
                 "one row = settlement penalty (settlement instruction x penalty type x penalty date)"),
            fact("Fact Trade Confirmation", [("26", "Trade Confirmation")], ["Trade Confirmation ID"],
                 "one row = trade confirmation (trade allocation x confirmation channel x confirmation version)",
                 note="Same-Day Affirmation Rate compares Affirmation Timestamp with the allocation trade date and the "
                      "affirmation cut-off of the settlement cycle rule."),
            fact("Fact Confirmation Match Exception", [("26", "Confirmation Match Exception")],
                 ["Exception Confirmation", "Mismatched Field", "Exception Raised Timestamp"],
                 "one row = trade confirmation x mismatched field x exception raised timestamp"),
            # -- dimensions
            own("Trade Allocation", [("25", "Trade Allocation")], ["Trade Allocation ID"],
                note="Built from the input: DP-123 (upstream) masters trade allocations but is a consumer product, so "
                     "no conformed entity is published; the registry key is kept so it joins to DP-123."),
            dim("Settlement Cycle Rule", SCR, [("26", "Settlement Cycle Rule")],
                note="Standard cycle and cut-offs by market x instrument type x settlement type (DP-147); Off-Cycle "
                     "Instructions compares the instruction's settlement date with it."),
            dim("Standing Settlement Instruction", SSI, [("26", "Standing Settlement Instruction")],
                note="Own and counterparty SSIs applied; verification status for Instructions With Unverified SSI."),
            dim("Portfolio Transaction", PTX141, [("18", "Portfolio Transaction")],
                note="Settlement Confirmed Indicator ties the IBOR transaction to settlement (DP-141)."),
            dim("Portfolio", PORT, [("18", "Portfolio")], note="Portfolio and business line (DP-140)."),
            dim("Portfolio Implementation Link", PIL, role="Bridge", grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Fund", FUND140),
            dim("Instrument", INSTR, [("17", "Instrument")], note="Instrument type and asset class (DP-097)."),
            dim("Counterparty", CPTY,
                note="Settlement counterparty, executing broker and confirming party (DP-115 approved counterparty)."),
            dim("Party", PARTY, note="Operations provider and the CSD that calculates a penalty."),
            dim("Employee", EMP115, note="Affirming employee (DP-115 publishes Employee; DP-192 is not upstream)."),
            dim("Calendar Date", CAL, note="Intended and effective settlement dates, trade date, penalty date."),
            dim("Settlement Calendar", CALENDAR),
        ],
        relationships=[
            rel("Fact Settlement Instruction", "Trade Allocation", ["Settled Allocation"]),
            rel("Fact Settlement Instruction", "Portfolio Transaction", ["Settled Portfolio Transaction"],
                optional=True),
            rel("Fact Settlement Instruction", "Portfolio", ["Settlement Portfolio"]),
            rel("Fact Settlement Instruction", "Instrument", ["Settlement Instrument"]),
            rel("Fact Settlement Instruction", "Standing Settlement Instruction", ["Applied Own SSI"], optional=True),
            rel("Fact Settlement Instruction", "Standing Settlement Instruction", ["Applied Counterparty SSI"],
                optional=True),
            rel("Fact Settlement Instruction", "Counterparty", ["Settlement Counterparty"]),
            rel("Fact Settlement Instruction", "Party", ["Operations Provider"], optional=True),
            rel("Fact Settlement Instruction", "Settlement Cycle Rule", ["Settlement Type"],
                note="Lookup, not a registry reference: the rule is matched on settlement type with the market of the "
                     "place of settlement and the instrument type, effective on the trade date."),
            rel("Fact Settlement Instruction", "Calendar Date", ["Intended Settlement Date"]),
            rel("Fact Settlement Status Event", "Fact Settlement Instruction", ["Status Instruction"]),
            rel("Fact Settlement Status Event", "Calendar Date", ["Effective Settlement Date"], optional=True),
            rel("Fact Settlement Fail", "Fact Settlement Instruction", ["Failed Instruction"]),
            rel("Fact Settlement Penalty", "Fact Settlement Instruction", ["Penalized Instruction"]),
            rel("Fact Settlement Penalty", "Party", ["Penalty Calculating CSD"], optional=True),
            rel("Fact Settlement Penalty", "Portfolio", ["Penalty Allocated Portfolio"], optional=True),
            rel("Fact Settlement Penalty", "Calendar Date", ["Penalty Date"]),
            rel("Fact Trade Confirmation", "Trade Allocation", ["Confirmed Allocation"]),
            rel("Fact Trade Confirmation", "Counterparty", ["Confirming Party"], optional=True),
            rel("Fact Trade Confirmation", "Employee", ["Affirmed By"], optional=True),
            rel("Fact Confirmation Match Exception", "Fact Trade Confirmation", ["Exception Confirmation"]),
            rel("Trade Allocation", "Portfolio", ["Allocated Portfolio"]),
            rel("Trade Allocation", "Counterparty", ["Executing Broker"]),
            rel("Trade Allocation", "Calendar Date", ["Allocation Trade Date"]),
            rel("Settlement Cycle Rule", "Settlement Calendar", ["Settlement Calendar"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
        ],
        notes="The settlement instruction is the main fact, with status advices, fails (with buy-ins), penalties, "
              "confirmations and confirmation match exceptions as companion facts. The trade allocation is built here "
              "from the input because DP-123 is consumer-aligned; SSIs and settlement cycle rules are conformed from "
              "DP-147, and the fund roll-up runs through the DP-140 implementation link. "
              "External references (not upstream): Related AP Order (29 AP Creation / Redemption Order). The market "
              "is derived from Instructed Place of Settlement, an identifier rather than a reference."),

    "DP-152": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact OTC Derivative Trade", [("26", "OTC Derivative Trade"), ("26", "Clearing Detail")],
                 ["OTC Trade ID"],
                 "one row = OTC derivative trade (by UTI), current state as of the as-of date",
                 note="Holds the measures (live trades and notional, cleared share, unconfirmed or uncleared, trades "
                      "under inactive agreements). Clearing Detail folds in. The as-of date is the publication "
                      "snapshot, not part of the record key.",
                 measures=True),
            fact("Fact OTC Trade Leg", [("26", "OTC Trade Leg")], ["Leg OTC Trade", "Leg Number"],
                 "one row = OTC derivative trade x leg number",
                 note="Leg notional drives Live OTC Trades and Notional."),
            fact("Fact OTC Lifecycle Event", [("26", "OTC Lifecycle Event")],
                 ["Event OTC Trade", "OTC Event Date", "Event Sequence"],
                 "one row = OTC derivative trade x event date x event sequence",
                 note="Resulting UTI feeds UTI Continuity Breaks (novations and compressions)."),
            fact("Fact OTC Cash Flow", [("26", "OTC Cash Flow")],
                 ["Cash Flow OTC Trade", "Cash Flow Leg Number", "Cash Flow Payment Date", "OTC Cash Flow Type"],
                 "one row = OTC derivative trade x leg number x payment date x cash flow type",
                 note="Payments Due, Unsettled Past Payments (through the payment's settlement instruction) and "
                      "Floating Coupons Without Final Fixing."),
            fact("Fact Repo Trade", [("26", "Repo Trade")], ["Repo Trade Reference"],
                 "one row = repo or reverse repo (firm repo trade reference), opening to closing leg",
                 note="Live Repo Book. A sibling fact of the OTC trade, governed by a trading agreement; repos are "
                      "not trade-reported in the US model (W1b re-point, CW-926: Repo UTI removed)."),
            fact("Fact Derivative Trade Report", [("26", "Derivative Trade Report")],
                 ["Reported UTI", "Trade Report Regime", "Report Submission Timestamp"],
                 "one row = reported OTC derivative trade x trade report regime x report submission timestamp",
                 note="Trades Not Reported, Late Reports and Open Report Rejections (CFTC Part 45 and SEC Regulation "
                      "SBSR)."),
            fact("Fact Settlement Status Event", [("26", "Settlement Status Event")],
                 ["Status Instruction", "Status Timestamp"],
                 "one row = settlement instruction x status advice timestamp",
                 note="Settlement status of cash flow payments and repo legs."),
            # -- dimensions
            dim("Settlement Instruction", ("DP-151", "Fact Settlement Instruction"),
                note="Conformed from DP-151 (upstream), which publishes the settlement instruction; it is read here "
                     "only by reference from cash flows, repo legs and status advices, so no settlement input is "
                     "rebuilt."),
            dim("Trading Agreement", TA, [("26", "Trading Agreement")],
                note="Governing ISDA / GMRA and clearing agreement; Agreement Status for trades under inactive "
                     "agreements (DP-147)."),
            dim("Reference Rate Fixing", FIXING, [("22", "Reference Rate Fixing")], note="Conformed from DP-143."),
            dim("Instrument", INSTR, [("17", "Instrument"), ("17", "OTC Derivative Product Terms")],
                note="The OTC product at UPI level; OTC Derivative Product Terms (asset class, base product, notional "
                     "currency) folds with its parent."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Portfolio Implementation Link", PIL, role="Bridge", grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Fund", FUND140),
            dim("Counterparty", CPTY, note="Trade and repo counterparty and reporting counterparty (DP-115)."),
            dim("Party", PARTY,
                note="CCP, clearing member, tri-party agent, step-in party, submitting entity and trade repository."),
            dim("Calendar Date", CAL, note="Trade date and payment date; the as-of date of the snapshot."),
        ],
        relationships=[
            rel("Fact OTC Derivative Trade", "Instrument", ["OTC Product Instrument"]),
            rel("Fact OTC Derivative Trade", "Portfolio", ["OTC Portfolio"]),
            rel("Fact OTC Derivative Trade", "Counterparty", ["OTC Counterparty"]),
            rel("Fact OTC Derivative Trade", "Trading Agreement", ["Governing Trading Agreement"]),
            rel("Fact OTC Derivative Trade", "Trading Agreement", ["Clearing Agreement"], optional=True),
            rel("Fact OTC Derivative Trade", "Party", ["Central Counterparty"], optional=True),
            rel("Fact OTC Derivative Trade", "Party", ["Clearing Member"], optional=True),
            rel("Fact OTC Derivative Trade", "Calendar Date", ["OTC Trade Date"]),
            rel("Fact OTC Trade Leg", "Fact OTC Derivative Trade", ["Leg OTC Trade"]),
            rel("Fact OTC Lifecycle Event", "Fact OTC Derivative Trade", ["Event OTC Trade"]),
            rel("Fact OTC Lifecycle Event", "Party", ["Step-In Party"], optional=True),
            rel("Fact OTC Cash Flow", "Fact OTC Derivative Trade", ["Cash Flow OTC Trade"]),
            rel("Fact OTC Cash Flow", "Fact OTC Trade Leg", ["Cash Flow Leg Number"], optional=True,
                note="The leg number, with the trade from Cash Flow OTC Trade; blank for trade-level flows such as "
                     "upfront fees."),
            rel("Fact OTC Cash Flow", "Reference Rate Fixing", ["Rate Fixing Used"], optional=True,
                note="The fixed rate; tenor, value type and fixing date come from the leg and calculation period."),
            rel("Fact OTC Cash Flow", "Settlement Instruction", ["Payment Settlement Instruction"], optional=True),
            rel("Fact OTC Cash Flow", "Calendar Date", ["Cash Flow Payment Date"]),
            rel("Fact Repo Trade", "Portfolio", ["Repo Portfolio"]),
            rel("Fact Repo Trade", "Counterparty", ["Repo Counterparty"]),
            rel("Fact Repo Trade", "Trading Agreement", ["Governing Repo Agreement"]),
            rel("Fact Repo Trade", "Party", ["Tri-Party Agent"], optional=True),
            rel("Fact Repo Trade", "Settlement Instruction", ["Opening Leg Settlement"], optional=True),
            rel("Fact Repo Trade", "Settlement Instruction", ["Closing Leg Settlement"], optional=True),
            rel("Fact Derivative Trade Report", "Fact OTC Derivative Trade", ["Reported OTC Trade"]),
            rel("Fact Derivative Trade Report", "Counterparty", ["Reporting Counterparty"]),
            rel("Fact Derivative Trade Report", "Party", ["Report Submitting Entity"], optional=True),
            rel("Fact Derivative Trade Report", "Party", ["Trade Repository"], optional=True),
            rel("Fact Settlement Status Event", "Settlement Instruction", ["Status Instruction"]),
            rel("Fact Settlement Status Event", "Calendar Date", ["Effective Settlement Date"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
        ],
        notes="Two trade facts (OTC derivative, repo) share the trading agreement, counterparty, portfolio and "
              "settlement instruction dimensions; legs, lifecycle events, cash flows, trade reports and settlement "
              "status advices are companion facts. The settlement instruction is conformed from DP-151 within this "
              "group rather than rebuilt, because DP-152 reads it only by reference. "
              "External references (not resolved here): Source Allocation (25 Trade Allocation, DP-123, which "
              "publishes no conformed entity and is not read as an input); CDS Reference Entity is not an input. "
              "W1b re-point (CW-926): Derivative Trade Report.Reported Repo Trade and Entity Responsible for Reporting "
              "and Repo Trade.Repo UTI left the taxonomy; the report-to-repo and report-to-legal-entity relationships and "
              "the Internal Legal Entity dimension (used only by the latter) are removed, and every trade report now "
              "names its OTC trade (mandatory relationship)."),

    "DP-153": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Margin Call", [("26", "Margin Call"), ("26", "Margin Call Dispute")], ["Margin Call ID"],
                 "one row = margin call (trading agreement x call valuation date x margin type x collateral direction)",
                 note="The main fact and holder of the measures: calls by status, past settlement date, disputes "
                      "(Margin Call Dispute folds in) and the recalculation difference against Credit Support Terms.",
                 measures=True),
            fact("Fact Collateral Balance", [("26", "Collateral Balance")],
                 ["Balance Agreement", "Collateral Source Portfolio", "Balance Date", "Balance Margin Type",
                  "Balance Direction", "Balance Instrument", "Balance Currency"],
                 "one row = trading agreement x source portfolio x balance date x margin type x collateral direction x "
                 "collateral asset",
                 note="Collateral posted and received, eligibility and haircut tests against the Eligible Collateral "
                      "Schedule, and the tie-out to encumbered holdings."),
            fact("Fact Initial Margin Calculation", [("26", "Initial Margin Calculation")],
                 ["IM Calculation Agreement", "IM Calculation Date", "IM Direction"],
                 "one row = trading agreement x calculation date x collateral direction",
                 note="Initial Margin Shortfall against the IM collateral balance."),
            fact("Fact Collateral Movement", [("26", "Collateral Movement")],
                 ["Movement Agreement", "Collateral Movement Reference", "Collateral Value Date"],
                 "one row = collateral movement (trading agreement x movement reference x value date)"),
            fact("Fact Counterparty Exposure", [("31", "Counterparty Exposure")],
                 ["Exposure Counterparty", "Counterparty Exposure Date", "Counterparty Exposure Measure",
                  "Counterparty Exposure Portfolio", "Exposure Trading Entity", "Netting Set Agreement"],
                 "one row = counterparty x exposure date x exposure measure x portfolio x trading entity x netting set",
                 note="Net Exposure After Collateral and Counterparty Collateral Breaks."),
            # -- dimensions
            dim("Trading Agreement", TA, [("26", "Trading Agreement")],
                note="The netting set: every margin and collateral fact keys on it (DP-147)."),
            dim("Credit Support Terms", CST, [("26", "Credit Support Terms")]),
            dim("Eligible Collateral Schedule", ECS, [("26", "Eligible Collateral Schedule")]),
            dim("Termination Event Trigger", TET, [("26", "Termination Event Trigger")],
                note="NAV Decline Trigger Headroom compares the fund's NAV decline with the trigger thresholds."),
            dim("Fund Accounting Book", FAB, [("27", "Fund Accounting Book")]),
            dim("Fund NAV Calculation", NAV, [("27", "Fund NAV Calculation")],
                note="Fund net assets for the NAV decline triggers and percent-of-net-assets exposure (DP-165)."),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding")],
                note="Encumbered Quantity for the Collateral Held Tie-Out (DP-142)."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Portfolio", PORT),
            dim("Portfolio Implementation Link", PIL, role="Bridge", grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Fund", FUND140, note="Fund party of the trading agreement and the fund of the source portfolio."),
            dim("Counterparty", CPTY),
            dim("Counterparty Trading Limit", CTL, note="Applicable trading limit of an exposure (DP-115)."),
            dim("Internal Legal Entity", LE140, note="Trading entity of an exposure."),
            dim("Approved Price", APPROVED, note="Price record a collateral balance is valued with (DP-143)."),
            dim("Safekeeping Account", SAFE, note="Account holding the collateral (DP-167)."),
            dim("Party", PARTY, note="Segregation custodian."),
            dim("Repo Trade", ("DP-152", "Fact Repo Trade"),
                note="Conformed from DP-152 (upstream) for collateral tied to a repo."),
            dim("Settlement Instruction", ("DP-152", "Settlement Instruction"),
                note="Conformed through DP-152 (upstream), which conforms it from DP-151; the instruction that moves "
                     "collateral."),
        ],
        relationships=[
            rel("Fact Margin Call", "Trading Agreement", ["Call Agreement"]),
            rel("Fact Margin Call", "Fact Initial Margin Calculation", ["Supporting IM Calculation"], optional=True,
                note="Agreement, call valuation date and direction resolve the calculation."),
            rel("Fact Collateral Balance", "Trading Agreement", ["Balance Agreement"]),
            rel("Fact Collateral Balance", "Portfolio", ["Collateral Source Portfolio"]),
            rel("Fact Collateral Balance", "Instrument", ["Balance Instrument"], optional=True,
                note="Blank for cash collateral, which is keyed by currency."),
            rel("Fact Collateral Balance", "Repo Trade", ["Related Repo Trade"], optional=True),
            rel("Fact Collateral Balance", "Approved Price", ["Valuation Price Record"], optional=True),
            rel("Fact Collateral Balance", "Safekeeping Account", ["Collateral Holding Account"], optional=True),
            rel("Fact Initial Margin Calculation", "Trading Agreement", ["IM Calculation Agreement"]),
            rel("Fact Collateral Movement", "Trading Agreement", ["Movement Agreement"]),
            rel("Fact Collateral Movement", "Fact Margin Call", ["Satisfied Margin Call"], optional=True),
            rel("Fact Collateral Movement", "Repo Trade", ["Related Repo Trade"], optional=True),
            rel("Fact Collateral Movement", "Instrument", ["Moved Instrument"], optional=True),
            rel("Fact Collateral Movement", "Settlement Instruction", ["Movement Settlement Instruction"]),
            rel("Fact Counterparty Exposure", "Counterparty", ["Exposure Counterparty"]),
            rel("Fact Counterparty Exposure", "Portfolio", ["Counterparty Exposure Portfolio"], optional=True,
                note="Blank for trading-entity or firm-level exposure."),
            rel("Fact Counterparty Exposure", "Internal Legal Entity", ["Exposure Trading Entity"], optional=True),
            rel("Fact Counterparty Exposure", "Trading Agreement", ["Netting Set Agreement"], optional=True),
            rel("Fact Counterparty Exposure", "Counterparty Trading Limit", ["Applicable Trading Limit"],
                optional=True, note="Counterparty, limit type, trading entity, fund and effective period resolve it."),
            rel("Trading Agreement", "Counterparty", ["Agreement Counterparty"]),
            rel("Trading Agreement", "Fund", ["Fund Party"]),
            rel("Trading Agreement", "Trading Agreement", ["Parent Agreement"], optional=True,
                note="CSA or annex to its master agreement."),
            rel("Credit Support Terms", "Trading Agreement", ["Terms Agreement"]),
            rel("Credit Support Terms", "Party", ["Segregation Custodian"], optional=True),
            rel("Eligible Collateral Schedule", "Trading Agreement", ["Schedule Agreement"]),
            rel("Termination Event Trigger", "Trading Agreement", ["Trigger Agreement"]),
            rel("Fund Accounting Book", "Fund", ["Book Fund"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"],
                note="Book fund; the accounting basis is the fund book's primary basis."),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Counterparty Trading Limit", "Counterparty", ["Limit Counterparty"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
        ],
        notes="The trading agreement (netting set) is the hub: margin calls, collateral balances, initial margin "
              "calculations and collateral movements all key on it, and counterparty exposure joins through the "
              "netting set. Agreement terms, eligibility schedules and termination triggers are conformed from DP-147; "
              "the repo trade and settlement instruction are conformed from this group's DP-152 (upstream) rather "
              "than rebuilt. " + NO_CAL + " "
              "External references: Counterparty Credit View is not an input."),

    # ================================================= 31 Investment Risk =================================================
    "DP-154": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Limit Utilization", [("31", "Risk Limit Utilization")],
                 ["Utilized Risk Limit", "Utilized Counterparty Trading Limit", "Utilization Date",
                  "Utilized Portfolio"],
                 "one row = risk limit (RLMT-) or counterparty trading limit x utilization date x portfolio",
                 note="The main fact and holder of the measures. Exactly one of the two limit references is set; the "
                      "Utilization Tie-Out recomputes the measured value from the source measure record (portfolio "
                      "risk measure, portfolio exposure or counterparty exposure).",
                 measures=True),
            fact("Fact Risk Limit Exceedance", [("31", "Risk Limit Exceedance")], ["Risk Limit Exceedance ID"],
                 "one row = risk limit exceedance (RLEX-)",
                 note="Open, not escalated, undetected and board-reportable exceedances."),
            fact("Fact Stress Test Result", [("31", "Stress Test Result")],
                 ["Result Scenario", "Stressed Portfolio", "Stress Test Date"],
                 "one row = stress scenario version x portfolio x stress test date",
                 note="Stress Loss by Scenario, Stress Coverage % and the climate metric check."),
            dict(name="Fact Counterparty Exposure", role="Fact", conformed=("DP-153", "Fact Counterparty Exposure"),
                 objects=[("31", "Counterparty Exposure")],
                 grain="one row = counterparty x exposure date x exposure measure x portfolio x trading entity x "
                       "netting set",
                 note="Conformed from DP-153 (upstream), which publishes the exposure with its full registry key; "
                      "this product's input lacks the trading entity and netting set attributes of the key. The "
                      "source measure of counterparty limit utilizations."),
            # -- dimensions
            own("Risk Limit", [("31", "Risk Limit")], ["Risk Limit ID"],
                note="Built from the input: no foundational model publishes the risk limit register."),
            own("Stress Scenario", [("31", "Stress Scenario")], ["Stress Scenario ID", "Stress Scenario Version"],
                note="Built from the input: DP-146 does not publish stress scenarios."),
            own("Stress Scenario Shock", [("31", "Stress Scenario Shock")],
                ["Shock Scenario", "Shocked Risk Factor", "Shocked Curve", "Shock Tenor", "Shocked Index"],
                note="The shocks that define a scenario version; one scenario has many shocks."),
            own("Portfolio Sustainability Metric", [("34", "Portfolio Sustainability Metric")],
                ["Metric Portfolio", "Metric Indicator", "Metric Period End Date"],
                note="Built from the input: DP-135 (upstream) is consumer-aligned and publishes no conformed entity. "
                     "Model gap: the input lacks Emission Scopes Included and Metric Measurement Basis (and the "
                     "product and legal entity parts) of the registry key, so the key is portfolio x indicator x "
                     "period end; climate stress results read the climate metric input by that partial key."),
            dim("Portfolio Risk Measure", PRM, [("31", "Portfolio Risk Measure")],
                note="Source measure of VaR and tracking error limits (DP-146)."),
            dim("Risk Calculation Run", RCR, [("31", "Risk Calculation Run")],
                note="Run status and approval for utilizations and stress results (DP-146)."),
            dim("Portfolio Exposure", PEXP, [("31", "Portfolio Exposure")],
                note="Source measure of exposure and concentration limits (DP-146)."),
            dim("Counterparty Trading Limit", CTL, [("25", "Counterparty Trading Limit")],
                note="Conformed from DP-115 (upstream), which publishes the counterparty trading limit."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")], role="Bridge",
                grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Fund", PROD, note="Conformed from DP-004 (upstream), the product master."),
            dim("Investment Strategy", STRAT, note="Strategy a limit applies to (DP-004)."),
            dim("Counterparty", CPTY),
            dim("Benchmark", BMK146, note="Benchmark of a relative limit or risk measure (DP-146)."),
            dim("Risk Factor", RFACTOR, note="Shocked risk factor (DP-146)."),
            dim("Curve Definition", CURVE, note="Shocked curve (DP-146)."),
            dim("Internal Legal Entity", LE140, note="Entity that sets the limit."),
            dim("Employee", EMP, note="Exceedance owner and limit approver."),
        ],
        relationships=[
            rel("Fact Limit Utilization", "Risk Limit", ["Utilized Risk Limit"], optional=True),
            rel("Fact Limit Utilization", "Counterparty Trading Limit", ["Utilized Counterparty Trading Limit"],
                optional=True, note="Counterparty, limit type, trading entity, fund and effective period resolve it."),
            rel("Fact Limit Utilization", "Portfolio", ["Utilized Portfolio"], optional=True,
                note="Blank only for fund-, entity- or firm-level measurements."),
            rel("Fact Risk Limit Exceedance", "Risk Limit", ["Exceeded Risk Limit"], optional=True),
            rel("Fact Risk Limit Exceedance", "Counterparty Trading Limit", ["Exceeded Counterparty Trading Limit"],
                optional=True),
            rel("Fact Risk Limit Exceedance", "Portfolio", ["Exceedance Portfolio"], optional=True),
            rel("Fact Risk Limit Exceedance", "Fact Limit Utilization", ["Triggering Utilization"], optional=True,
                note="Limit, date and portfolio resolve the utilization row; blank marks an undetected exceedance."),
            rel("Fact Risk Limit Exceedance", "Employee", ["Exceedance Owner"], optional=True),
            rel("Fact Stress Test Result", "Stress Scenario", ["Result Scenario"],
                note="Scenario ID and version."),
            rel("Fact Stress Test Result", "Portfolio", ["Stressed Portfolio"]),
            rel("Fact Stress Test Result", "Risk Calculation Run", ["Stress Calculation Run"], optional=True),
            rel("Fact Stress Test Result", "Portfolio Sustainability Metric", ["Climate Metric Input"], optional=True),
            rel("Fact Counterparty Exposure", "Counterparty", ["Exposure Counterparty"]),
            rel("Fact Counterparty Exposure", "Portfolio", ["Counterparty Exposure Portfolio"], optional=True),
            rel("Fact Counterparty Exposure", "Counterparty Trading Limit", ["Applicable Trading Limit"],
                optional=True),
            rel("Stress Scenario Shock", "Stress Scenario", ["Shock Scenario"]),
            rel("Stress Scenario Shock", "Risk Factor", ["Shocked Risk Factor"], optional=True),
            rel("Stress Scenario Shock", "Curve Definition", ["Shocked Curve"], optional=True),
            rel("Stress Scenario Shock", "Benchmark", ["Shocked Index"], optional=True),
            rel("Portfolio Sustainability Metric", "Portfolio", ["Metric Portfolio"]),
            rel("Portfolio Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            rel("Portfolio Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Portfolio Risk Measure", "Benchmark", ["Measure Benchmark"], optional=True),
            rel("Portfolio Exposure", "Portfolio", ["Exposure Portfolio"]),
            rel("Portfolio Exposure", "Risk Calculation Run", ["Exposure Calculation Run"], optional=True),
            rel("Risk Limit", "Benchmark", ["Limit Benchmark"], optional=True),
            rel("Risk Limit", "Stress Scenario", ["Limit Stress Scenario"], optional=True),
            rel("Risk Limit", "Fund", ["Limited Fund"], optional=True),
            rel("Risk Limit", "Portfolio", ["Limited Portfolio"], optional=True),
            rel("Risk Limit", "Investment Strategy", ["Limited Strategy"], optional=True),
            rel("Risk Limit", "Internal Legal Entity", ["Limit Setting Entity"], optional=True),
            rel("Risk Limit", "Employee", ["Limit Approved By"], optional=True),
            rel("Counterparty Trading Limit", "Counterparty", ["Limit Counterparty"]),
            rel("Counterparty Trading Limit", "Fund", ["Limit Fund"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
        ],
        notes="Limit utilization is the main fact, at limit x utilization date x portfolio, for both the 31 risk "
              "limits and the 25 counterparty trading limits; exceedances, stress test results and counterparty "
              "exposures are companion facts. The source measures (portfolio risk measure, portfolio exposure, risk "
              "calculation run) are conformed from DP-146 and the counterparty trading limit from DP-115; Source "
              "Measure Record on a utilization names one of them generically, so it is not drawn as a foreign key. "
              "Calendar Date is not conformed: DP-013 is not upstream (Model gap). "
              "External references: Escalated To is a body, not a reference."),

    "DP-155": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Fund Liquidity Profile", [("31", "Fund Liquidity Profile")],
                 ["Profile Fund", "Profile Measurement Date"],
                 "one row = fund x measurement date (liquidity profile)",
                 note="The main program-result fact and holder of the measures: liquidity category percents, HLIM "
                      "shortfall and the illiquid limit flag. The other fund x measurement date results (horizon "
                      "buckets, VaR tests, leverage) are sibling facts on the same Fund dimension.",
                 measures=True),
            fact("Fact Liquidity Horizon Bucket", [("31", "Liquidity Horizon Bucket")],
                 ["Bucket Fund", "Bucket Measurement Date", "Liquidity Horizon Bucket"],
                 "one row = fund x measurement date x liquidity horizon bucket"),
            fact("Fact VaR Test Result", [("31", "VaR Test Result")], ["VaR Test Fund", "VaR Test Date", "VaR Test Regime"],
                 "one row = fund x test date x VaR test regime",
                 note="VaR Test Failures and the tie-out to the fund's portfolio VaR measure."),
            fact("Fact Leverage & Exposure Measurement", [("31", "Leverage & Exposure Measurement")],
                 ["Measured Fund", "Leverage Measurement Date", "Exposure Method"],
                 "one row = fund x measurement date x exposure method"),
            fact("Fact Liquidity Classification", [("31", "Liquidity Classification")],
                 ["Classified Fund", "Classified Instrument", "Classification Date", "Classification Portion Number"],
                 "one row = fund x instrument x classification date x classification portion",
                 note="Classification Coverage % compares classified instruments with the fund's holdings."),
            fact("Fact Stress Test Result", [("31", "Stress Test Result"), ("31", "Liquidity Stress Detail")],
                 ["Result Scenario", "Stressed Portfolio", "Stress Test Date"],
                 "one row = stress scenario version x portfolio x stress test date (liquidity stress)",
                 note="Liquidity Stress Detail folds in; Liquidity Stress Coverage."),
            fact("Fact Risk Limit Exceedance", [("31", "Risk Limit Exceedance")], ["Risk Limit Exceedance ID"],
                 "one row = risk limit exceedance (RLEX-) on a program limit",
                 note="Program Exceedances and the Form N-RN trigger."),
            fact("Fact Risk Program Designation", [("31", "Risk Program Designation")],
                 ["Program Fund", "Risk Program Type", "Program Effective From"],
                 "one row = fund x risk program type x effective period",
                 note="Companion fact for Program Designation Gaps (funds without a program they need)."),
            fact("Fact Highly Liquid Investment Minimum", [("31", "Highly Liquid Investment Minimum")],
                 ["HLIM Fund", "HLIM Effective From"],
                 "one row = fund x effective period (HLIM)",
                 note="Companion fact; the liquidity profile applies the HLIM in force."),
            fact("Fact Designated Reference Portfolio", [("31", "Designated Reference Portfolio")],
                 ["DRP Fund", "DRP Effective From"],
                 "one row = fund x effective period (designated reference portfolio)",
                 note="Companion fact; relative VaR tests apply the reference portfolio in force."),
            # -- dimensions
            dim("Fund", PROD, [("01", "Investment Product"), ("01", "Fund Legal Structure"),
                               ("01", "Investment Objective & Policy")],
                note="Vehicle type, regulatory regime, openness, derivatives usage and leverage method decide which "
                     "programs a fund needs (DP-004). The two folded groups sit with their parent."),
            own("Risk Limit", [("31", "Risk Limit")], ["Risk Limit ID"],
                note="Built from the input, keeping DP-154's key: program limits (illiquid investment limit, VaR "
                     "limit)."),
            dim("Stress Scenario", ("DP-154", "Stress Scenario"),
                note="Conformed from DP-154 (upstream), which builds the stress scenario; not an input here."),
            dim("Portfolio Risk Measure", PRM, [("31", "Portfolio Risk Measure")], note="Fund VaR measure (DP-146)."),
            dim("Risk Calculation Run", RCR, [("31", "Risk Calculation Run")]),
            dim("Fund NAV Calculation", NAV, [("27", "Fund NAV Calculation")],
                note="Net assets behind leverage and liquidity percents (DP-165)."),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")],
                note="Holdings the classifications must cover (DP-142)."),
            dim("Portfolio", PORT),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")], role="Bridge",
                grain=PIL_GRAIN, note=PIL_NOTE),
            dim("Portfolio Hierarchy Link", PHL, [("18", "Portfolio Hierarchy Link")], role="Bridge",
                grain="one row = parent portfolio x child portfolio x link type x effective period",
                note="Look-through roll-up of sleeves into the fund's whole book."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Fair Value Determination", FVD, note="Supporting fair value determination of a classification."),
            dim("ETF Market Statistic", ETFSTAT, note="Own ETF market statistics behind an in-kind ETF profile."),
            dim("Dataset", DATASET, note="Liquidity data source."),
            dim("Benchmark", BMK097, note="Designated reference index."),
            dim("Model", MODEL, note="Liquidity classification and stress models (DP-212)."),
            dim("Employee", EMP, note="Program risk lead."),
        ],
        relationships=[
            rel("Fact Fund Liquidity Profile", "Fund", ["Profile Fund"]),
            rel("Fact Fund Liquidity Profile", "Fact Highly Liquid Investment Minimum", ["Applied HLIM"],
                optional=True, note="Fund and the effective period in force on the measurement date."),
            rel("Fact Fund Liquidity Profile", "ETF Market Statistic", ["Own ETF Market Statistic"], optional=True),
            rel("Fact Liquidity Horizon Bucket", "Fund", ["Bucket Fund"]),
            rel("Fact VaR Test Result", "Fund", ["VaR Test Fund"]),
            rel("Fact VaR Test Result", "Portfolio Risk Measure", ["Fund VaR Measure"], optional=True),
            rel("Fact VaR Test Result", "Fact Designated Reference Portfolio", ["Applied Reference Portfolio"],
                optional=True, note="Fund and the effective period in force on the test date."),
            rel("Fact VaR Test Result", "Risk Limit", ["Applied VaR Limit"], optional=True),
            rel("Fact Leverage & Exposure Measurement", "Fund", ["Measured Fund"]),
            rel("Fact Leverage & Exposure Measurement", "Fund NAV Calculation", ["Net Assets Source NAV"],
                optional=True),
            rel("Fact Leverage & Exposure Measurement", "Risk Calculation Run", ["Measurement Calculation Run"],
                optional=True),
            rel("Fact Liquidity Classification", "Fund", ["Classified Fund"]),
            rel("Fact Liquidity Classification", "Instrument", ["Classified Instrument"]),
            rel("Fact Liquidity Classification", "Dataset", ["Liquidity Data Source Dataset"], optional=True),
            rel("Fact Liquidity Classification", "Fair Value Determination", ["Supporting Fair Value Determination"],
                optional=True),
            rel("Fact Liquidity Classification", "Model", ["Model Inventory Entry"], optional=True,
                note="Model ID; the version in use on the classification date."),
            rel("Fact Stress Test Result", "Stress Scenario", ["Result Scenario"]),
            rel("Fact Stress Test Result", "Portfolio", ["Stressed Portfolio"]),
            rel("Fact Stress Test Result", "Model", ["Model Inventory Entry"], optional=True),
            rel("Fact Risk Limit Exceedance", "Risk Limit", ["Exceeded Risk Limit"]),
            rel("Fact Risk Program Designation", "Fund", ["Program Fund"]),
            rel("Fact Risk Program Designation", "Employee", ["Program Risk Lead"], optional=True),
            rel("Fact Highly Liquid Investment Minimum", "Fund", ["HLIM Fund"]),
            rel("Fact Designated Reference Portfolio", "Fund", ["DRP Fund"]),
            rel("Fact Designated Reference Portfolio", "Benchmark", ["Designated Reference Index"]),
            rel("Fact Designated Reference Portfolio", "Portfolio", ["Reference Securities Portfolio"], optional=True),
            rel("Risk Limit", "Fund", ["Limited Fund"], optional=True),
            rel("Portfolio Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            rel("Portfolio Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"]),
            rel("Portfolio Hierarchy Link", "Portfolio", ["Parent Portfolio"]),
            rel("Portfolio Hierarchy Link", "Portfolio", ["Child Portfolio"]),
        ],
        notes="Fund-keyed program results (liquidity profile, horizon buckets, VaR tests, leverage and exposure) are "
              "sibling facts at fund x measurement date sharing the Fund dimension; classifications, liquidity stress "
              "results, program exceedances, program designations, HLIMs and designated reference portfolios are "
              "companion facts. Portfolio-keyed inputs (holdings, VaR measures, stress results) reach the fund through "
              "the implementation and hierarchy link bridges. " + NO_CAL + " "
              "External references (not upstream): Administrator Appointment (35 Fund Officer Appointment), Bucket "
              "Feeder Access Terms (01 feeder access terms, renamed from Bucket Private Fund Profile at W4, CW-930). "
              "Fund Borrowing Facility was dropped with 30."),

    # DP-156 retired (model deleted by the WP1 lineage pass with its retired spec)
}
