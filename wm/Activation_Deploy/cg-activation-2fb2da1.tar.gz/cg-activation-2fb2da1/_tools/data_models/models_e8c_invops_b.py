"""Logical data models, Wave E8 consumer models (group "invops_b"): Star models for DP-157 to DP-160 (32 Performance &
Attribution), DP-161 to DP-163 (33 Investment Compliance), DP-102 (17 Instrument & Issuer Reference) and DP-103
(21 Data Governance & Analytics). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed`; product input objects of the same concept sit
  on the conformed entity and merge with its inherited attributes. Where a foundational record is itself the measured
  event (an official return, an ex-ante risk measure, a capital account), it is conformed with role Fact so the product
  inherits the registry key it could not state from its own partial attribute list.
- A product builds its own entity from its inputs when those inputs carry the registry key (attribution, contribution,
  composite, compliance and breach records). Where a product reads only keys, or an attribute subset without the full
  registry key, of a record modeled by a consumer product in this group that is upstream of it (DP-157 ex-post statistics
  and DP-158 composite statistics in DP-159; DP-161 restrictions and rule libraries in DP-162 and DP-163), the entity is
  conformed from that upstream model, so the two products join on one key.
- 01 GIPS Composite, 01 Investment Restriction, 02 Client Restriction, 25 Trade Order, 25 Trade Error and 14 Vendor Data
  Issue are published by no foundational model, so each product that reads them builds its own Dimension on the registry
  key.
- Date roles are conformed from DP-013 Calendar Date (firm business calendar), so a date attribute on a fact is the
  foreign key.
- Reference attributes whose target is not a product input and not published by an upstream model stay degenerate on the
  fact; the model notes name them.
- Multi-valued references are drawn as M:N relationships; the build explodes them into one row per referenced member.
"""


def dim(name, src, objects=(), note="", role="Dimension", **kw):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role=role, conformed=src, objects=list(objects), note=note, **kw)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


CAL = ("DP-013", "Calendar Date")
LE = ("DP-013", "Internal Legal Entity")
PORT = ("DP-140", "Portfolio")
EMP = ("DP-192", "Employee")
INSTR = ("DP-097", "Instrument")
ISSUER = ("DP-098", "Issuer")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
BMK = ("DP-145", "Benchmark")
PRET = ("DP-145", "Performance Return")
BRET = ("DP-145", "Benchmark Return")
PRM = ("DP-146", "Portfolio Risk Measure")
RRUN = ("DP-146", "Risk Calculation Run")

MODELS = {
    # ================================================ 32 Performance & Attribution ==================================
    "DP-157": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Attribution Effect", role="Fact", objects=[("32", "Attribution Effect")],
                 pk=["Effect Attribution Result", "Effect Segment Code", "Attribution Effect Type"], measures=True,
                 grain="one row = attribution result (portfolio return version x benchmark return version x model "
                       "version x result version) x segment x effect type",
                 note="The product grain: allocation, selection, interaction and currency effects. Holds the measures "
                      "because every tie-out (effects sum to active return, residual share) is stated at this grain. "
                      "A blank Effect Segment Code is the total-level effect."),
            dict(name="Fact Attribution Segment", role="Fact", objects=[("32", "Attribution Segment Result")],
                 pk=["Segment Attribution Result", "Attribution Segment Code"],
                 grain="one row = attribution result x segment",
                 note="Segment weights and returns behind the effects. An effect row joins its segment row on result "
                      "and segment code; both are drawn to the result rather than to each other because the registry "
                      "points the result reference at Attribution Result."),
            dict(name="Fact Attribution Result", role="Fact", objects=[("32", "Attribution Result")],
                 pk=["Attribution Result ID", "Attribution Version"],
                 grain="one row = attribution result version (PAAN-)",
                 note="Carries Active Return and the residual. It has no period dates or currency of its own (spec "
                      "taxonomy gap); they come from the referenced Performance Return."),
            dict(name="Fact Contribution to Return", role="Fact", objects=[("32", "Contribution to Return")],
                 pk=["Contribution Portfolio Return Record", "Contribution Instrument", "Contribution Classification Scheme",
                     "Contribution Segment Code", "Contribution Calculation Basis"],
                 grain="one row = portfolio return version x instrument or segment x calculation basis",
                 note="Companion fact for top contributors and detractors; instrument rows and segment rows share the "
                      "fact, so Contribution Instrument and the segment pair are each optional."),
            dict(name="Fact Ex-Post Risk Statistic", role="Fact", objects=[("32", "Ex-Post Risk Statistic")],
                 pk=["Statistic Subject Type", "Statistic Portfolio", "Statistic Share Class", "Statistic Composite",
                     "Statistic Benchmark", "Ex-Post Statistic Type", "Statistic Period Start Date",
                     "Statistic Period End Date", "Observation Frequency", "Statistic Fee Basis", "Statistic Price Basis",
                     "Statistic Currency", "Comparison Benchmark", "Statistic Version"],
                 grain="one row = subject x ex-post statistic type x period start x period end x observation frequency "
                       "x fee basis x price basis x currency x comparison benchmark x version",
                 note="Published, not certified. Statistic Composite stays degenerate: 01 GIPS Composite is not an "
                      "input of this product (DP-158 owns the composite view)."),
            dim("Fact Ex-Ante Risk Measure", PRM, [("31", "Portfolio Risk Measure")], role="Fact",
                grain="one row = DP-146 risk calculation run x portfolio x risk measure x horizon x confidence level x "
                      "benchmark",
                note="Certified ex-ante tracking error set beside realized tracking error; conformed so the full "
                     "DP-146 key (horizon and confidence level are not inputs) is kept."),
            # -- dimensions
            dict(name="Attribution Model", role="Dimension", objects=[("32", "Attribution Model")],
                 pk=["Attribution Model Code", "Attribution Model Version"],
                 note="Built from the input: no foundational model publishes attribution models. Its approval is read "
                      "from 37 Model Validation through DP-212 (CD-246). Reference Target Allocation (24) on the result "
                      "is a key only; DP-128 is not upstream."),
            dim("Model", ("DP-212", "Model"), [("37", "Model Inventory Entry")],
                note="The 37 model inventory entry behind each attribution model."),
            dim("Model Validation", ("DP-212", "Model Validation"), [("37", "Model Validation")],
                note="Outrigger of Model; feeds Results on Unvalidated Models."),
            dim("Risk Calculation Run", RRUN, [("31", "Risk Calculation Run")],
                note="Only approved runs supply the ex-ante comparison (Run Approval Status)."),
            dim("Risk Model", ("DP-146", "Risk Model"),
                note="Shared by risk calculation runs and factor-based attribution models."),
            dim("Performance Return", PRET, [("32", "Performance Return")],
                note="The official portfolio return version explained by attribution; read from DP-145, never restated."),
            dim("Benchmark Return", BRET, [("32", "Benchmark Return")]),
            dim("Benchmark", BMK),
            dim("Portfolio", PORT, [("18", "Portfolio")], note="Business Line on the portfolio is the business line roll-up."),
            dim("Share Class", SHARE),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Classification Scheme", ("DP-097", "Classification Scheme"), [("09", "Classification Scheme")],
                note="Segment schemes of attribution models and contribution rows."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Attribution Effect", "Fact Attribution Result", ["Effect Attribution Result"]),
            rel("Fact Attribution Segment", "Fact Attribution Result", ["Segment Attribution Result"]),
            rel("Fact Attribution Result", "Performance Return", ["Portfolio Return Record"]),
            rel("Fact Attribution Result", "Benchmark Return", ["Benchmark Return Record"]),
            rel("Fact Attribution Result", "Attribution Model", ["Applied Attribution Model"]),
            rel("Attribution Model", "Classification Scheme", ["Segment Classification Scheme"], optional=True),
            rel("Attribution Model", "Risk Model", ["Factor Risk Model"], optional=True,
                note="Only factor-based attribution models name a risk model."),
            rel("Attribution Model", "Model", ["Model Inventory Reference"]),
            rel("Model Validation", "Model", ["Validated Model"]),
            rel("Fact Contribution to Return", "Performance Return", ["Contribution Portfolio Return Record"]),
            rel("Fact Contribution to Return", "Instrument", ["Contribution Instrument"], optional=True),
            rel("Fact Contribution to Return", "Classification Scheme", ["Contribution Classification Scheme"],
                optional=True),
            rel("Fact Ex-Post Risk Statistic", "Portfolio", ["Statistic Portfolio"], optional=True),
            rel("Fact Ex-Post Risk Statistic", "Share Class", ["Statistic Share Class"], optional=True),
            rel("Fact Ex-Post Risk Statistic", "Benchmark", ["Statistic Benchmark"], optional=True,
                note="Set when the subject is a benchmark."),
            rel("Fact Ex-Post Risk Statistic", "Benchmark", ["Comparison Benchmark"], optional=True,
                note="Tracking error, information ratio and beta are stated against this benchmark."),
            rel("Fact Ex-Post Risk Statistic", "Benchmark", ["Risk-Free Rate Benchmark"], optional=True,
                note="Sharpe ratio only."),
            rel("Fact Ex-Post Risk Statistic", "Calendar Date", ["Statistic Period End Date"]),
            rel("Performance Return", "Portfolio", ["Return Portfolio"], optional=True),
            rel("Performance Return", "Calendar Date", ["Return Period End Date"]),
            rel("Benchmark Return", "Benchmark", ["Return Benchmark"]),
            rel("Fact Ex-Ante Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            rel("Fact Ex-Ante Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Fact Ex-Ante Risk Measure", "Benchmark", ["Measure Benchmark"], optional=True,
                note="Blank for absolute measures; tracking error rows carry the benchmark."),
            rel("Risk Calculation Run", "Risk Model", ["Run Risk Model"]),
            rel("Risk Calculation Run", "Calendar Date", ["Run As-Of Date"]),
        ],
        notes=("Constellation of attribution facts (result, segment, effect), contribution to return and ex-post risk "
               "statistics, all reading the certified DP-145 Performance Return and Benchmark Return as conformed "
               "dimensions so no return is restated; the certified ex-ante measure from DP-146 sits beside the ex-post "
               "statistics as a conformed fact for the Ex-Ante vs Ex-Post Tracking Error Ratio, joined through "
               "Portfolio and Benchmark. Model approval comes from DP-212 (Model and Model Validation). "
               "Degenerate references: Reference Target Allocation (24 Target Allocation Set, DP-128 not upstream) and "
               "Statistic Composite (01 GIPS Composite not an input). DP-142 and DP-144 are upstream for holdings and "
               "licensed constituent weights but contribute no input object, so no entity is drawn for them."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-158": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Composite Period Statistic", role="Fact", objects=[("32", "Composite Period Statistic")],
                 pk=["Statistic Composite", "Composite Period End Date", "Composite Period Type"], measures=True,
                 grain="one row = GIPS composite x period end x period type",
                 note="The product grain: composite assets, portfolio count, dispersion and 3-year ex-post standard "
                      "deviations. No version or status (spec taxonomy gap), so restatements are not traced."),
            dict(name="Fact Composite Membership", role="Fact", objects=[("32", "Composite Membership")],
                 pk=["Membership Composite", "Member Portfolio", "Membership Start Date"],
                 grain="one row = composite x portfolio x membership start date",
                 note="Membership is effective-dated, so it is a fact rather than a bridge: Composite Members, "
                      "Pending Membership Approvals and Unassigned Discretionary Portfolios count its rows."),
            dict(name="Fact Significant Cash Flow", role="Fact", objects=[("32", "Significant Cash Flow Event")],
                 pk=["Flow Portfolio", "Flow Composite", "Significant Flow Date"],
                 grain="one row = portfolio x composite x significant flow date",
                 note="Joined to the membership whose dates contain the flow date; Significant Flow Amount and the "
                      "threshold are the values the GIPS record used (spec rule 2 exception)."),
            dict(name="Fact Carve-Out Allocation", role="Fact", objects=[("32", "Carve-Out Allocation")],
                 pk=["Carve-Out Portfolio", "Carve-Out Period Start Date"],
                 grain="one row = carve-out portfolio x carve-out period"),
            dict(name="Fact GIPS Firm Assets", role="Fact", objects=[("32", "GIPS Firm Assets")],
                 pk=["GIPS Firm Key", "Firm Assets Period End Date"],
                 grain="one row = GIPS firm definition x period end",
                 note="Child group of GIPS Firm (fold=False). Its attributes do not carry the firm, so it borrows GIPS "
                      "Firm Key. Total Firm Assets is a GIPS figure and is never summed as AUM (CD-292)."),
            dict(name="Fact GIPS Verification", role="Fact", objects=[("32", "GIPS Verification")],
                 pk=["GIPS Verification ID"], grain="one row = GIPS verification engagement (GVER-)",
                 note="Feeds Verification Lag Months. Performance Examination Composites is multi-valued (M:N)."),
            dim("Fact Composite Return", PRET, [("32", "Performance Return"), ("32", "Return Component Detail")],
                role="Fact",
                grain="one row = DP-145 performance return version (composite or member portfolio subject)",
                note="Certified composite and portfolio returns read from DP-145 (CD-320); Return Component Detail "
                     "folds in and gives the beginning and ending values used for flow percentages."),
            dim("Fact Portfolio Capital Activity", ("DP-141", "Portfolio Capital Activity"),
                [("18", "Portfolio Capital Activity")], role="Fact",
                grain="one row = portfolio x share class or account x trade date x capital activity type",
                note="Conformed from DP-141 to keep its full key (share class and account are not inputs); tests "
                     "Unrecorded Significant Flows against the significant cash flow events."),
            # -- dimensions
            dict(name="GIPS Firm", role="Dimension", objects=[("32", "GIPS Firm")],
                 pk=["GIPS Firm Code", "Firm Definition Effective From"],
                 note="Built from the input: no foundational model publishes the GIPS firm definition."),
            dict(name="GIPS Composite", role="Dimension", objects=[("01", "GIPS Composite")], pk=["Composite ID"],
                 note="01 composite definition read directly until DP-004's extension publishes it (CD-322); keyed "
                      "on Composite ID so the DP-004 entity will conform with no key change."),
            dim("Benchmark Return", BRET, [("32", "Benchmark Return")],
                note="Composite benchmark returns for Composite Excess Return."),
            dim("Benchmark", BMK),
            dim("Portfolio", PORT, [("18", "Portfolio"), ("18", "SMA Portfolio Detail")],
                note="SMA Portfolio Detail folds here; its Full Discretion Indicator drives Unassigned Discretionary "
                     "Portfolios."),
            dim("Managing Entity", LE, note="Firm legal entities: portfolio managing entities and the GIPS firm's "
                                            "member entities (DP-013)."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Membership approvers and the GIPS compliance officer."),
            dim("Verifier", ("DP-240", "Party"), note="The verification firm, an 02 party."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Composite Period Statistic", "GIPS Composite", ["Statistic Composite"]),
            rel("Fact Composite Period Statistic", "Calendar Date", ["Composite Period End Date"]),
            rel("Fact Composite Membership", "GIPS Composite", ["Membership Composite"]),
            rel("Fact Composite Membership", "Portfolio", ["Member Portfolio"]),
            rel("Fact Composite Membership", "Employee", ["Membership Approver"], optional=True),
            rel("Fact Composite Membership", "Fact Significant Cash Flow", ["Significant Cash Flow Removals"],
                card="M:N", optional=True, note="Multi-valued: the significant flows that removed the portfolio."),
            rel("Fact Significant Cash Flow", "Portfolio", ["Flow Portfolio"]),
            rel("Fact Significant Cash Flow", "GIPS Composite", ["Flow Composite"]),
            rel("Fact Significant Cash Flow", "Fact Portfolio Capital Activity", ["Source Capital Activity"],
                optional=True, note="The 18 capital activity that triggered the flow."),
            rel("Fact Carve-Out Allocation", "Portfolio", ["Carve-Out Portfolio"]),
            rel("Fact Carve-Out Allocation", "Portfolio", ["Parent Portfolio"], optional=True,
                note="The portfolio the carve-out is taken from."),
            rel("Fact GIPS Firm Assets", "GIPS Firm", ["GIPS Firm Key"]),
            rel("Fact GIPS Firm Assets", "Calendar Date", ["Firm Assets Period End Date"]),
            rel("GIPS Firm", "Employee", ["GIPS Compliance Officer"], optional=True),
            rel("GIPS Firm", "Managing Entity", ["Firm Legal Entities"], card="M:N",
                note="Multi-valued: the legal entities the GIPS firm definition covers."),
            rel("Fact GIPS Verification", "GIPS Firm", ["Verified GIPS Firm"]),
            rel("Fact GIPS Verification", "Verifier", ["Verifier"]),
            rel("Fact GIPS Verification", "GIPS Composite", ["Performance Examination Composites"], card="M:N",
                optional=True, note="Multi-valued: composites covered by a performance examination."),
            rel("Fact Composite Return", "GIPS Composite", ["Return Composite"], optional=True),
            rel("Fact Composite Return", "Portfolio", ["Return Portfolio"], optional=True),
            rel("Fact Composite Return", "Calendar Date", ["Return Period End Date"]),
            rel("Benchmark Return", "Benchmark", ["Return Benchmark"]),
            rel("GIPS Composite", "Benchmark", ["Composite Benchmark"], optional=True),
            rel("Portfolio", "Managing Entity", ["Managing Entity"], optional=True),
            rel("Fact Portfolio Capital Activity", "Portfolio", ["Activity Portfolio"]),
        ],
        notes=("GIPS star around the composite period statistic, with membership, significant flows, carve-outs, firm "
               "assets and verification as companion facts sharing GIPS Composite, Portfolio, GIPS Firm and Calendar "
               "Date. Returns are the conformed DP-145 Performance Return and Benchmark Return, never restated. "
               "GIPS Composite and GIPS Firm are built from the inputs because no foundational model publishes them. "
               "Model gap: 32 GIPS Firm Assets carries no attribute naming its firm, so the child borrows GIPS Firm "
               "Key (its registry key is the parent key plus Firm Assets Period End Date)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-159": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Fact Official Return", PRET, [("32", "Performance Return")], role="Fact", measures=True,
                grain="one row = DP-145 performance return version (share class or composite subject x period x fee "
                      "basis x currency); the scorecard row (subject x standard period x month-end x fee basis x "
                      "currency) selects the final return of each subject",
                note="Holds the measures: every scorecard number is stated against the official return. Conformed "
                     "from DP-145 so the full return key is kept (CD-320)."),
            dim("Fact Ex-Post Risk Statistic", ("DP-157", "Fact Ex-Post Risk Statistic"),
                [("32", "Ex-Post Risk Statistic")], role="Fact",
                grain="one row = DP-157 ex-post statistic (subject x statistic type x period x frequency x basis x "
                      "version)",
                note="Conformed from the upstream DP-157 fact: the inputs carry only part of the registry key."),
            dim("Fact Composite Period Statistic", ("DP-158", "Fact Composite Period Statistic"),
                [("32", "Composite Period Statistic")], role="Fact",
                grain="one row = composite x period end x period type (DP-158)",
                note="Conformed from the upstream DP-158 fact for the Composite Risk Ratio; Composite Period Type is "
                     "not an input."),
            dim("Fact Ex-Ante Risk Measure", PRM, [("31", "Portfolio Risk Measure")], role="Fact",
                grain="one row = DP-146 risk calculation run x portfolio x risk measure x horizon x confidence level x "
                      "benchmark",
                note="Certified ex-ante tracking error of the fund's implementing portfolio."),
            dim("Fact Peer Metric Snapshot", ("DP-014", "Peer Metric Snapshot"), [("11", "Peer Metric Snapshot")],
                role="Fact", pk=["Peer Fund Key", "Snapshot Date", "Return Period", "Peer Universe"],
                grain="one row = peer fund x snapshot date x return period x peer universe",
                note="Licensed peer returns and ranks (Confidential - Licensed); never mixed into own returns."),
            dim("Fact Share Class NAV", ("DP-165", "Share Class NAV"), [("27", "Share Class NAV")], role="Fact",
                grain="one row = share class x fund NAV calculation",
                note="Certified Class Net Assets weight the asset-weighted shares (CD-292, CD-330)."),
            # -- bridges
            dim("Product Benchmark Assignment", ("DP-145", "Product Benchmark Assignment"),
                [("01", "Product Benchmark Assignment")], role="Bridge",
                grain="one row = product or share class x benchmark x benchmark role x effective period",
                note="Selects the primary benchmark of each share class."),
            dim("Portfolio Implementation Link", ("DP-140", "Portfolio Implementation Link"),
                [("18", "Portfolio Implementation Link")], role="Bridge",
                grain="one row = portfolio x implemented product, mandate, account or model x link type x effective "
                      "period",
                note="The only path from a fund to its portfolio's ex-ante risk (CD-324)."),
            dim("Peer Universe Member", ("DP-014", "Peer Universe Member"), [("11", "Peer Universe Member")],
                role="Bridge", pk=["Peer Universe Key", "Member Fund"],
                grain="one row = peer universe x member fund",
                note="The peer median is taken across members' returns (spec taxonomy gap)."),
            # -- dimensions
            dim("Benchmark Return", BRET, [("32", "Benchmark Return")]),
            dim("Performance Measurement Profile", ("DP-145", "Performance Measurement Profile"),
                [("32", "Performance Measurement Profile")], note="Return methodology shown on the scorecard."),
            dim("Risk Calculation Run", RRUN, [("31", "Risk Calculation Run")]),
            dim("Portfolio", PORT),
            dim("Investment Strategy", ("DP-004", "Investment Strategy"), [("01", "Investment Strategy")]),
            dim("Investment Product", PROD, [("01", "Investment Product")]),
            dim("Share Class", SHARE, [("01", "Share Class"), ("01", "Security Identifier")],
                note="Security Identifier folds here; ISIN matches the share class to its 11 Peer Fund."),
            dict(name="GIPS Composite", role="Dimension", objects=[("01", "GIPS Composite")], pk=["Composite ID"],
                 note="01 composite read directly (no foundational model publishes it); same key as DP-158."),
            dim("Benchmark", BMK),
            dim("Peer Universe", ("DP-014", "Peer Universe"), [("11", "Peer Universe")]),
            dim("Peer Fund", ("DP-014", "Peer Fund"), [("11", "Peer Fund")]),
            dim("Fund NAV Calculation", ("DP-165", "Fund NAV Calculation"), [("27", "Fund NAV Calculation")],
                note="Only approved NAV versions weight the scorecard (NAV Approval Status)."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Official Return", "Share Class", ["Return Share Class"], optional=True),
            rel("Fact Official Return", "GIPS Composite", ["Return Composite"], optional=True),
            rel("Fact Official Return", "Calendar Date", ["Return Period End Date"]),
            rel("Benchmark Return", "Benchmark", ["Return Benchmark"]),
            rel("Fact Ex-Post Risk Statistic", "Share Class", ["Statistic Share Class"], optional=True),
            rel("Fact Ex-Post Risk Statistic", "GIPS Composite", ["Statistic Composite"], optional=True),
            rel("Fact Ex-Post Risk Statistic", "Calendar Date", ["Statistic Period End Date"]),
            rel("Fact Composite Period Statistic", "GIPS Composite", ["Statistic Composite"]),
            rel("Fact Composite Period Statistic", "Calendar Date", ["Composite Period End Date"]),
            rel("Performance Measurement Profile", "Share Class", ["Profiled Share Class"], optional=True),
            rel("Performance Measurement Profile", "GIPS Composite", ["Profiled Composite"], optional=True),
            rel("Fact Ex-Ante Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            rel("Fact Ex-Ante Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Fact Ex-Ante Risk Measure", "Benchmark", ["Measure Benchmark"], optional=True),
            rel("Risk Calculation Run", "Calendar Date", ["Run As-Of Date"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Investment Product", "Investment Strategy", ["Implemented Strategy"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
            rel("GIPS Composite", "Benchmark", ["Composite Benchmark"], optional=True),
            rel("Product Benchmark Assignment", "Share Class", ["Assigned Product / Share Class"]),
            rel("Product Benchmark Assignment", "Benchmark", ["Assigned Benchmark"]),
            rel("Peer Universe", "Investment Strategy", ["Own Strategy Compared"], optional=True),
            rel("Peer Universe Member", "Peer Universe", ["Peer Universe Key"]),
            rel("Peer Universe Member", "Peer Fund", ["Member Fund"]),
            rel("Fact Peer Metric Snapshot", "Peer Fund", ["Peer Fund Key"]),
            rel("Fact Peer Metric Snapshot", "Peer Universe", ["Peer Universe"]),
            rel("Fact Peer Metric Snapshot", "Calendar Date", ["Snapshot Date"]),
            rel("Peer Fund", "Share Class", ["ISIN"], optional=True,
                note="Own share class match by ISIN (spec taxonomy gap: no attribute links them)."),
            rel("Fact Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Fact Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Fund NAV Calculation", "Calendar Date", ["Valuation Date"]),
        ],
        notes=("Scorecard constellation keyed on Share Class, GIPS Composite, Investment Strategy and Calendar Date: "
               "official returns (DP-145), benchmark returns through the primary Product Benchmark Assignment, "
               "ex-post statistics (DP-157), composite statistics (DP-158), ex-ante risk (DP-146) reached from the "
               "fund through Portfolio Implementation Link (DP-140), licensed peer metrics (DP-014) and Class Net "
               "Assets (DP-165). The scorecard grain (subject x standard period x month-end x fee basis x currency) is "
               "a selection over these facts, not a stored table. The strategy row resolves through the composite "
               "whose benchmark and implemented strategy match (spec taxonomy gap). "
               "Model gap: DP-014 Peer Metric Snapshot and Peer Universe Member key on their parent's key, which the "
               "conformed entities do not inherit as attributes, so they borrow Peer Fund Key and Peer Universe Key; "
               "Peer Fund ID and Peer Universe ID are the values."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    # DP-160 retired (model deleted by the WP1 lineage pass with its retired spec)

    # ================================================ 33 Investment Compliance ======================================
    "DP-161": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Compliance Rule", role="Fact", objects=[("33", "Compliance Rule")],
                 pk=["Compliance Rule ID", "Rule Version"], measures=True,
                 grain="one row = compliance rule (CRULE-) x rule version, effective-dated",
                 note="The product grain; holds the measures (coverage, looser-than-source, unapproved versions, "
                      "hard-block share). DP-162 and DP-163 key their rule dimension on the same two attributes."),
            dict(name="Fact Restriction Coding Status", role="Fact", objects=[("33", "Restriction Coding Status")],
                 pk=["Status Investment Restriction", "Status Client Restriction", "Coding Status Effective From"],
                 grain="one row = source restriction (investment or client) x coding status effective period",
                 note="Restriction Coding Coverage % is measured over restrictions, so this fact carries the status."),
            dict(name="Fact Rule Coding Request", role="Fact", objects=[("33", "Rule Coding Request")],
                 pk=["Coding Request Reference"], grain="one row = rule coding request",
                 note="No received date (spec taxonomy gap); lateness is against Required Effective Date. Triggering "
                      "Product Change (36) stays degenerate."),
            dict(name="Fact Periodic Rule Review", role="Fact", objects=[("33", "Periodic Rule Review")],
                 pk=["Reviewed Rule", "Reviewed Rule Library", "Rule Review Date"],
                 grain="one row = rule or rule library x review date"),
            # -- bridges
            dict(name="Rule Source Link", role="Bridge", objects=[("33", "Rule Source Link")],
                 pk=["Linked Rule", "Linked Rule Version", "Rule Source Type", "Source Investment Restriction",
                     "Source Client Restriction", "Source Regulatory Provision"],
                 grain="one row = rule version x source (investment restriction, client restriction or regulatory "
                       "provision)",
                 note="Many-to-many between rules and the restrictions they code; Buffer Versus Source feeds Rules "
                      "Looser Than Source."),
            dict(name="Rule Library Membership", role="Bridge", objects=[("33", "Rule Library Membership")],
                 pk=["Membership Library", "Membership Library Version", "Member Rule", "Member Rule Version"],
                 grain="one row = library version x rule version"),
            dict(name="Rule Assignment", role="Bridge", objects=[("33", "Rule Assignment")],
                 pk=["Assigned Rule", "Assigned Rule Version", "Assigned Rule Library", "Assigned Library Version",
                     "Assigned Portfolio", "Assignment Effective From"],
                 grain="one row = rule version or library version x portfolio x effective period",
                 note="Many-to-many between rules (or libraries) and portfolios; Portfolios Without Rule Assignment "
                      "reads it."),
            dict(name="Rule Instrument List Member", role="Bridge", objects=[("33", "Rule Instrument List Member")],
                 pk=["Member List", "Member Instrument", "Member Issuer", "Member Effective From"],
                 grain="one row = list x instrument or issuer x effective period",
                 note="Only lists held here have members; sourced 34 and 38 lists are read at source (CD-224)."),
            # -- dimensions
            dict(name="Rule Instrument List", role="Dimension", objects=[("33", "Rule Instrument List")],
                 pk=["Rule Instrument List Code", "Rule Instrument List Version"],
                 note="Source Sustainability Exclusion List (34) and Restricted List Source (38) stay degenerate."),
            dict(name="Rule Library", role="Dimension", objects=[("33", "Rule Library")],
                 pk=["Rule Library Code", "Rule Library Version"]),
            dict(name="Regulatory Limit Provision", role="Dimension", objects=[("33", "Regulatory Limit Provision")],
                 pk=["Provision Code", "Provision Effective From"]),
            dict(name="Investment Restriction", role="Dimension", objects=[("01", "Investment Restriction")],
                 pk=["Restriction ID"],
                 note="Read directly from 01: no foundational product publishes it (spec note, CD-221)."),
            dict(name="Client Restriction", role="Dimension", objects=[("02", "Client Restriction")],
                 pk=["Client Restriction ID"],
                 note="Built from the input: DP-077 (upstream for lineage) is consumer-aligned and models it as a "
                      "fact, so it is not conformed."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Restricted Party", ("DP-140", "Party"), note="The client party a client restriction applies to."),
            dim("Restricted Account", ("DP-140", "Account"), note="The client account a client restriction applies to."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")]),
            dim("List Source Dataset", ("DP-097", "Dataset"), note="The 14 dataset a sourced list is loaded from."),
            dim("Employee", EMP, [("20", "Employee")], note="Coders, approvers, library owners and reviewers."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Compliance Rule", "Rule Instrument List", ["Rule Instrument Lists Read"], card="M:N",
                optional=True, note="Multi-valued: the lists a rule tests."),
            rel("Fact Compliance Rule", "Fact Rule Coding Request", ["Originating Coding Request"], optional=True),
            rel("Fact Compliance Rule", "Employee", ["Version Approved By"], optional=True),
            rel("Fact Compliance Rule", "Calendar Date", ["Version Effective From"]),
            rel("Rule Source Link", "Fact Compliance Rule", ["Linked Rule", "Linked Rule Version"]),
            rel("Rule Source Link", "Investment Restriction", ["Source Investment Restriction"], optional=True),
            rel("Rule Source Link", "Client Restriction", ["Source Client Restriction"], optional=True),
            rel("Rule Source Link", "Regulatory Limit Provision", ["Source Regulatory Provision"], optional=True),
            rel("Rule Library Membership", "Rule Library", ["Membership Library", "Membership Library Version"]),
            rel("Rule Library Membership", "Fact Compliance Rule", ["Member Rule", "Member Rule Version"]),
            rel("Rule Assignment", "Fact Compliance Rule", ["Assigned Rule", "Assigned Rule Version"], optional=True,
                note="Set when a single rule is assigned."),
            rel("Rule Assignment", "Rule Library", ["Assigned Rule Library", "Assigned Library Version"], optional=True,
                note="Set when a whole library is assigned."),
            rel("Rule Assignment", "Portfolio", ["Assigned Portfolio"]),
            rel("Fact Restriction Coding Status", "Investment Restriction", ["Status Investment Restriction"],
                optional=True),
            rel("Fact Restriction Coding Status", "Client Restriction", ["Status Client Restriction"], optional=True),
            rel("Fact Restriction Coding Status", "Calendar Date", ["Coding Status Effective From"]),
            rel("Fact Rule Coding Request", "Investment Restriction", ["Triggering Investment Restriction"],
                optional=True),
            rel("Fact Rule Coding Request", "Client Restriction", ["Triggering Client Restriction"], optional=True),
            rel("Fact Rule Coding Request", "Employee", ["Coded By"], optional=True),
            rel("Fact Rule Coding Request", "Employee", ["Coding Approved By"], optional=True),
            rel("Fact Rule Coding Request", "Calendar Date", ["Required Effective Date"]),
            rel("Rule Instrument List", "Client Restriction", ["Source Client Restriction"], optional=True),
            rel("Rule Instrument List", "List Source Dataset", ["List Source Dataset"], optional=True),
            rel("Rule Instrument List Member", "Rule Instrument List", ["Member List"]),
            rel("Rule Instrument List Member", "Instrument", ["Member Instrument"], optional=True),
            rel("Rule Instrument List Member", "Issuer", ["Member Issuer"], optional=True),
            rel("Fact Periodic Rule Review", "Fact Compliance Rule", ["Reviewed Rule"], optional=True),
            rel("Fact Periodic Rule Review", "Rule Library", ["Reviewed Rule Library"], optional=True),
            rel("Fact Periodic Rule Review", "Employee", ["Rule Reviewer"]),
            rel("Fact Periodic Rule Review", "Fact Rule Coding Request", ["Resulting Coding Request"], optional=True),
            rel("Fact Periodic Rule Review", "Calendar Date", ["Rule Review Date"]),
            rel("Rule Library", "Employee", ["Library Owner"], optional=True),
            rel("Client Restriction", "Restricted Party", ["Restricted Party"], optional=True),
            rel("Client Restriction", "Restricted Account", ["Restricted Accounts"], card="M:N", optional=True,
                note="W1 re-point (CW-902): Restricted Accounts is multi-valued (blank = every account of the party)."),
        ],
        notes=("Rule library star: the compliance rule version is the main fact, with coding status, coding requests "
               "and periodic reviews as companion facts and four bridges for the many-to-many links (rule to source "
               "restriction, library to rule, rule or library to portfolio, list to instrument or issuer). Restriction "
               "text stays in 01 Investment Restriction and 02 Client Restriction, built here from the inputs (CD-221). "
               "Version references (Reviewed Rule, Originating Coding Request) carry only the rule or request key, so "
               "a review joins the rule's versions. Degenerate references: Triggering Product Change (36), Source "
               "Sustainability Exclusion List (34) and Restricted List Source (38)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-162": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Compliance Rule Result", role="Fact", objects=[("33", "Compliance Rule Result")],
                 pk=["Result Check Run", "Result Portfolio", "Evaluated Rule", "Evaluated Rule Version",
                     "Evaluated Issuer", "Evaluated Instrument", "Evaluated Group Key"], measures=True,
                 grain="one row = compliance check run x portfolio x rule version x evaluated issuer, instrument or group",
                 note="The product grain; Headroom is derived here from Measured Value and Limit Applied (spec "
                      "taxonomy gap)."),
            dict(name="Fact Compliance Check Run", role="Fact",
                 objects=[("33", "Compliance Check Run"), ("33", "Pre-Trade Check Subject")],
                 pk=["Compliance Check Run ID"], grain="one row = compliance check run (CCHK-)",
                 note="Pre-Trade Check Subject folds here (one subject per pre-trade run). Tested Proposed Trade (24), "
                      "Tested Block Order (25) stay degenerate (Tested Deal left with 30, CW-930)."),
            dict(name="Fact Check Subject Member", role="Fact", objects=[("33", "Check Subject Member")],
                 pk=["Member Check Run", "Checked Trade Order"], grain="one row = check run x tested order",
                 note="Per-order pre-trade outcome; Orders Released by Override reads Releasing Override."),
            dict(name="Fact Compliance Alert", role="Fact", objects=[("33", "Compliance Alert")],
                 pk=["Compliance Alert ID"], grain="one row = compliance alert (CALERT-)",
                 note="No closed timestamp (spec taxonomy gap); resolution time is taken from the last disposition."),
            dict(name="Fact Alert Disposition", role="Fact", objects=[("33", "Alert Disposition")],
                 pk=["Disposed Alert", "Disposition Sequence"], grain="one row = alert x disposition sequence",
                 note="Related Data Quality Issue (21) stays degenerate."),
            dict(name="Fact Override Approval", role="Fact", objects=[("33", "Pre-Trade Override Approval")],
                 pk=["Override Alert", "Override Approval Sequence"], grain="one row = alert x override approval sequence",
                 note="Self-Approved Overrides compares Override Requested By with Override Approver."),
            dict(name="Fact Guideline Waiver", role="Fact", objects=[("33", "Guideline Waiver")],
                 pk=["Guideline Waiver Reference"], grain="one row = guideline waiver"),
            dict(name="Fact Manual Compliance Check", role="Fact", objects=[("33", "Manual Compliance Check")],
                 pk=["Checked Investment Restriction", "Checked Client Restriction", "Checked Portfolio",
                     "Check Period Start Date"],
                 grain="one row = source restriction x portfolio x check period"),
            dict(name="Fact Restriction Coding Status", role="Fact", objects=[("33", "Restriction Coding Status")],
                 pk=["Status Investment Restriction", "Status Client Restriction", "Coding Status Effective From"],
                 grain="one row = source restriction x coding status effective period",
                 note="Restrictions under manual monitoring set the expected manual checks (Manual Checks Missing)."),
            dim("Fact Ex-Ante Risk Measure", PRM, [("31", "Portfolio Risk Measure")], role="Fact",
                grain="one row = DP-146 risk calculation run x portfolio x risk measure x horizon x confidence level x "
                      "benchmark",
                note="The 31 value a risk-based rule tested (CD-223); Risk Results on Unapproved Runs reads the run."),
            # -- bridges
            dict(name="Rule Assignment", role="Bridge", objects=[("33", "Rule Assignment")],
                 pk=["Rule Assignment Key"],
                 grain="one row = rule or library x portfolio x effective period",
                 note="Surrogate key: the inputs leave out Assigned Rule Version and Assigned Library Version of the "
                      "registry key. Used for Post-Trade Run Coverage %."),
            # -- dimensions
            dict(name="Compliance Rule", role="Dimension", objects=[("33", "Compliance Rule")],
                 pk=["Compliance Rule ID", "Rule Version"],
                 note="Built from the input subset DP-162 reads; same key as the DP-161 rule fact."),
            dim("Rule Library", ("DP-161", "Rule Library"),
                note="Conformed from upstream DP-161: Assigned Rule Library is read here but 33 Rule Library is not "
                     "an input."),
            dim("Investment Restriction", ("DP-161", "Investment Restriction"),
                note="Conformed from upstream DP-161, which reads 01 directly; not an input here."),
            dim("Client Restriction", ("DP-161", "Client Restriction"),
                note="Conformed from upstream DP-161; not an input here."),
            dict(name="Trade Order", role="Dimension", objects=[("25", "Trade Order")], pk=["Trade Order ID"],
                 note="Built from the input: DP-123 (upstream) is consumer-aligned and no foundational model "
                      "publishes 25 orders."),
            dim("Risk Calculation Run", RRUN, [("31", "Risk Calculation Run")]),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Instrument", INSTR),
            dim("Issuer", ISSUER),
            dim("Client Approver", ("DP-140", "Party"), note="The client contact who approved a waiver (02 Party)."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Analysts, approvers, attesters and alert owners."),
        ],
        relationships=[
            rel("Fact Compliance Rule Result", "Fact Compliance Check Run", ["Result Check Run"]),
            rel("Fact Compliance Rule Result", "Portfolio", ["Result Portfolio"]),
            rel("Fact Compliance Rule Result", "Compliance Rule", ["Evaluated Rule", "Evaluated Rule Version"]),
            rel("Fact Compliance Rule Result", "Issuer", ["Evaluated Issuer"], optional=True),
            rel("Fact Compliance Rule Result", "Instrument", ["Evaluated Instrument"], optional=True),
            rel("Fact Compliance Rule Result", "Fact Guideline Waiver", ["Applied Guideline Waiver"], optional=True),
            rel("Fact Compliance Rule Result", "Fact Ex-Ante Risk Measure", ["Source Risk Measurement"], optional=True,
                note="The registry types this reference as one of three 31 objects; only Portfolio Risk Measure is an "
                     "input, so leverage and counterparty exposure rows (DP-153) stay unjoined."),
            rel("Fact Compliance Check Run", "Trade Order", ["Tested Trade Order"], optional=True),
            rel("Fact Check Subject Member", "Fact Compliance Check Run", ["Member Check Run"]),
            rel("Fact Check Subject Member", "Trade Order", ["Checked Trade Order"]),
            rel("Fact Check Subject Member", "Fact Override Approval", ["Releasing Override"], optional=True),
            rel("Fact Compliance Alert", "Fact Compliance Rule Result", ["Source Rule Result"]),
            rel("Fact Compliance Alert", "Employee", ["Alert Assigned To"], optional=True),
            rel("Fact Alert Disposition", "Fact Compliance Alert", ["Disposed Alert"]),
            rel("Fact Alert Disposition", "Employee", ["Disposed By"]),
            rel("Fact Alert Disposition", "Employee", ["Disposition Reviewed By"], optional=True),
            rel("Fact Override Approval", "Fact Compliance Alert", ["Override Alert"]),
            rel("Fact Override Approval", "Employee", ["Override Requested By"]),
            rel("Fact Override Approval", "Employee", ["Override Approver"], optional=True),
            rel("Fact Guideline Waiver", "Compliance Rule", ["Waived Rule"]),
            rel("Fact Guideline Waiver", "Portfolio", ["Waived Portfolio"]),
            rel("Fact Guideline Waiver", "Issuer", ["Waiver Scope Issuer"], optional=True),
            rel("Fact Guideline Waiver", "Client Approver", ["Client Approver"], optional=True),
            rel("Fact Guideline Waiver", "Employee", ["Internal Approver"], optional=True),
            rel("Fact Manual Compliance Check", "Investment Restriction", ["Checked Investment Restriction"],
                optional=True),
            rel("Fact Manual Compliance Check", "Client Restriction", ["Checked Client Restriction"], optional=True),
            rel("Fact Manual Compliance Check", "Portfolio", ["Checked Portfolio"]),
            rel("Fact Manual Compliance Check", "Employee", ["Attested By"], optional=True),
            rel("Fact Restriction Coding Status", "Investment Restriction", ["Status Investment Restriction"],
                optional=True),
            rel("Fact Restriction Coding Status", "Client Restriction", ["Status Client Restriction"], optional=True),
            rel("Rule Assignment", "Compliance Rule", ["Assigned Rule"], optional=True),
            rel("Rule Assignment", "Rule Library", ["Assigned Rule Library"], optional=True),
            rel("Rule Assignment", "Portfolio", ["Assigned Portfolio"]),
            rel("Trade Order", "Portfolio", ["Order Portfolio"]),
            rel("Trade Order", "Instrument", ["Order Instrument"]),
            rel("Fact Ex-Ante Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            rel("Fact Ex-Ante Risk Measure", "Portfolio", ["Measured Portfolio"]),
        ],
        notes=("Monitoring constellation around the compliance rule result, with check runs, per-order pre-trade "
               "members, alerts, dispositions, override approvals, waivers and manual checks as companion facts "
               "sharing Compliance Rule, Portfolio and Employee. The rule is built from DP-162's input subset on the "
               "DP-161 key; restrictions and rule libraries, which DP-162 reads only as keys, are conformed from "
               "upstream DP-161. Trade orders are this product's own dimension (DP-123 is consumer-aligned). "
               "Model gap: the 33 Rule Assignment inputs leave out Assigned Rule Version and Assigned Library Version, "
               "so the bridge carries a surrogate key and joins rules and libraries on their codes. DP-013 is not "
               "upstream, so run and alert timestamps stay on the facts with no Calendar Date dimension. "
               "Degenerate references: Tested Proposed Trade (24), Tested Block Order (25), Related "
               "Data Quality Issue (21)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-163": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Investment Breach", role="Fact", objects=[("33", "Investment Breach")],
                 pk=["Investment Breach ID"], measures=True,
                 grain="one row = investment breach (BREACH-: portfolio x rule x issuer, instrument or group x breach "
                       "start date), daily status snapshot",
                 note="The product grain. The breached rule version is the one effective at Breach Start Date (spec "
                      "taxonomy gap). Originating Manual Check, Related NAV Error Case (27) stay degenerate."),
            dict(name="Fact Breach Remediation Action", role="Fact", objects=[("33", "Breach Remediation Action")],
                 pk=["Remediated Breach", "Remediation Action Sequence"], grain="one row = breach x action sequence",
                 note="Implementing Trade Order (25) stays degenerate; 25 Trade Order is not an input."),
            dict(name="Fact Breach Loss Calculation", role="Fact", objects=[("33", "Breach Loss Calculation")],
                 pk=["Calculated Breach", "Loss Calculation Version"], grain="one row = breach x loss calculation version",
                 note="Used only where the breach has no trade error (one loss, one home, CD-244)."),
            dict(name="Fact Breach Review", role="Fact", objects=[("33", "Breach Review")],
                 pk=["Reviewed Breach", "Breach Review Sequence"], grain="one row = breach x review sequence",
                 note="CCO sign-off; Resulting Reportable Fund Event (35) stays degenerate."),
            dict(name="Fact Breach Notification", role="Fact", objects=[("12", "Breach Notification")],
                 pk=["Breach Notification ID"], grain="one row = client breach notification (12)",
                 note="Read only for Client Notice Gaps; the link lives in 12 (spec rule 2 exception)."),
            # -- bridges
            dict(name="Breached Source Restriction", role="Bridge", objects=[("33", "Breached Source Restriction")],
                 pk=["Source Breach", "Additional Breached Restriction", "Additional Breached Client Restriction"],
                 grain="one row = breach x additional breached restriction",
                 note="A breach can breach several restrictions; the first sits on the breach itself."),
            dim("Portfolio Implementation Link", ("DP-140", "Portfolio Implementation Link"),
                [("18", "Portfolio Implementation Link")], role="Bridge",
                grain="one row = portfolio x implemented product, mandate, account or model x link type x effective "
                      "period",
                note="Resolves a breached portfolio to its fund, mandate or managed account (CD-324)."),
            # -- dimensions
            dict(name="Compliance Rule", role="Dimension", objects=[("33", "Compliance Rule")],
                 pk=["Compliance Rule ID", "Rule Version"], note="Same key as the DP-161 rule fact."),
            dict(name="Guideline Waiver", role="Dimension", objects=[("33", "Guideline Waiver")],
                 pk=["Guideline Waiver Reference"],
                 note="Approved waivers in force explain passive breaches that are not escalated."),
            dict(name="Compliance Alert", role="Dimension", objects=[("33", "Compliance Alert")],
                 pk=["Compliance Alert ID"], note="Alert Raised Timestamp gives Detection Lag Days."),
            dict(name="Trade Error", role="Dimension", objects=[("25", "Trade Error")], pk=["Trade Error Reference"],
                 note="Built from the input: DP-125 (upstream) is consumer-aligned. Its gain or loss is the breach "
                      "loss where the breach came from a trade error."),
            dim("Investment Restriction", ("DP-161", "Investment Restriction"),
                note="Conformed from upstream DP-161; 01 Investment Restriction is not an input here."),
            dim("Client Restriction", ("DP-161", "Client Restriction"),
                note="Conformed from upstream DP-161; 02 Client Restriction is not an input here."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Investment Product", ("DP-140", "Investment Product")),
            dim("Investment Mandate", ("DP-140", "Investment Mandate")),
            dim("Managed Account", ("DP-140", "Account")),
            dim("Instrument", INSTR),
            dim("Issuer", ISSUER),
            dim("Compensating Entity", LE, note="The firm legal entity that pays compensation."),
            dim("Employee", EMP, [("20", "Employee")]),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Investment Breach", "Portfolio", ["Breached Portfolio"]),
            rel("Fact Investment Breach", "Compliance Rule", ["Breached Rule"], optional=True,
                note="Joins the rule versions; the version effective at Breach Start Date applies."),
            rel("Fact Investment Breach", "Issuer", ["Breached Issuer"], optional=True),
            rel("Fact Investment Breach", "Instrument", ["Breached Instrument"], optional=True),
            rel("Fact Investment Breach", "Investment Restriction", ["Breached Restriction"], optional=True),
            rel("Fact Investment Breach", "Client Restriction", ["Breached Client Restriction"], optional=True),
            rel("Fact Investment Breach", "Compliance Alert", ["Originating Alert"], optional=True),
            rel("Fact Investment Breach", "Trade Error", ["Related Trade Error"], optional=True),
            rel("Fact Investment Breach", "Calendar Date", ["Breach Start Date"]),
            rel("Breached Source Restriction", "Fact Investment Breach", ["Source Breach"]),
            rel("Breached Source Restriction", "Investment Restriction", ["Additional Breached Restriction"],
                optional=True),
            rel("Breached Source Restriction", "Client Restriction", ["Additional Breached Client Restriction"],
                optional=True),
            rel("Fact Breach Remediation Action", "Fact Investment Breach", ["Remediated Breach"]),
            rel("Fact Breach Remediation Action", "Employee", ["Remediation Action Owner"], optional=True),
            rel("Fact Breach Loss Calculation", "Fact Investment Breach", ["Calculated Breach"]),
            rel("Fact Breach Loss Calculation", "Compensating Entity", ["Compensating Entity"], optional=True),
            rel("Fact Breach Loss Calculation", "Employee", ["Loss Calculation Approved By"], optional=True),
            rel("Fact Breach Review", "Fact Investment Breach", ["Reviewed Breach"]),
            rel("Fact Breach Review", "Employee", ["CCO Sign-Off By"], optional=True),
            rel("Fact Breach Notification", "Fact Investment Breach", ["Related Investment Breach"]),
            rel("Guideline Waiver", "Compliance Rule", ["Waived Rule"]),
            rel("Guideline Waiver", "Portfolio", ["Waived Portfolio"]),
            rel("Trade Error", "Portfolio", ["Affected Portfolio"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Portfolio Implementation Link", "Investment Mandate", ["Implemented Mandate"], optional=True),
            rel("Portfolio Implementation Link", "Managed Account", ["Managed Account"], optional=True),
        ],
        notes=("Breach star: the investment breach fact with remediation, loss, review and client notification as "
               "child facts and a bridge for additional breached restrictions. Portfolio reaches its fund, mandate or "
               "account through the conformed DP-140 Portfolio Implementation Link. Restrictions are conformed from "
               "upstream DP-161 because DP-163 reads them only as keys; the rule, waiver, alert and trade error are "
               "built from DP-163's own inputs, which carry their keys. 12 Breach Notification's reference to the "
               "breach has no registry target (the reference is owned by 12), so its link is drawn without a REFS "
               "check. DP-162 is upstream for alerts but its model is not conformed: the alert input here carries the "
               "alert key itself."),
    ),

    # ================================================ 17 / 21 reference and governance ===============================
    "DP-102": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Instrument Setup Request", role="Fact", objects=[("17", "Instrument Setup Request")],
                 pk=["Setup Request ID"], measures=True,
                 grain="one row = instrument setup request, current state, daily snapshot",
                 note="The product grain; Setups Completed After First Trade compares Completion Timestamp with the "
                      "first portfolio transaction in the resulting instrument."),
            dict(name="Fact DQ Result", role="Fact", objects=[("21", "Data Quality Result")], pk=["DQ Result ID"],
                 grain="one row = DQ rule x execution timestamp x tested data asset (rules targeting 17 elements)",
                 note="Same key as DP-103's result fact, filtered to 17 targets (CD-301)."),
            dict(name="Fact Vendor Data Issue", role="Fact", objects=[("14", "Vendor Data Issue")],
                 pk=["Vendor Data Issue ID"], grain="one row = vendor data issue on a security master dataset",
                 note="Read directly: no foundational 14 product exists (CD-164)."),
            dim("Fact Corporate Action Scrub", ("DP-099", "Corporate Action Event"), [("17", "Corporate Action Event")],
                role="Fact", grain="one row = corporate action event x scrubber",
                note="Conformed from DP-099; Scrubbed By, which DP-099 leaves out as personal data, merges in from "
                     "this product's input for the audit."),
            dim("Fact Issuer Relationship Approval", ("DP-098", "Issuer Relationship"), [("17", "Issuer Relationship")],
                role="Fact", grain="one row = issuer relationship x approver (effective-dated)",
                note="Conformed from DP-098; Relationship Approved By merges in from the input for Issuer Overrides "
                     "Without Approver."),
            dim("Fact Portfolio Transaction", ("DP-141", "Portfolio Transaction"), [("18", "Portfolio Transaction")],
                role="Fact", grain="one row = portfolio transaction",
                note="First trade date per instrument for the setup timeliness measures."),
            # -- dimensions
            dict(name="Data Quality Rule", role="Dimension", objects=[("21", "Data Quality Rule")], pk=["DQ Rule ID"],
                 note="Built from the input: DP-103, which owns the rules, is consumer-aligned; same key."),
            dim("Critical Data Element", ("DP-100", "Critical Data Element"), [("21", "Critical Data Element")]),
            dim("Taxonomy Element", ("DP-100", "Taxonomy Element"), [("21", "Taxonomy Element")],
                note="Element Data Domain = 17 filters the rules and CDEs to the security master."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Issuer", ISSUER, note="Subject issuers and related parties of issuer relationships (02 Party)."),
            dim("Dataset", ("DP-097", "Dataset"), [("14", "Dataset")]),
            dim("Employee", EMP, [("20", "Employee")], note="Requesters, approvers and scrubbers."),
            dim("Org Unit", ("DP-192", "Org Unit"), note="Home org unit of the requester."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Instrument Setup Request", "Instrument", ["Resulting Instrument"], optional=True,
                note="Set once the request is completed."),
            rel("Fact Instrument Setup Request", "Employee", ["Requested By"]),
            rel("Fact Instrument Setup Request", "Employee", ["Approved By"], optional=True),
            rel("Fact Corporate Action Scrub", "Instrument", ["Event Instrument"]),
            rel("Fact Corporate Action Scrub", "Employee", ["Scrubbed By"], optional=True),
            rel("Fact Corporate Action Scrub", "Calendar Date", ["Ex-Date"], optional=True),
            rel("Fact Issuer Relationship Approval", "Issuer", ["Subject Issuer"]),
            rel("Fact Issuer Relationship Approval", "Issuer", ["Related Party"]),
            rel("Fact Issuer Relationship Approval", "Employee", ["Relationship Approved By"], optional=True),
            rel("Fact Portfolio Transaction", "Instrument", ["Transaction Instrument"]),
            rel("Fact Portfolio Transaction", "Calendar Date", ["Trade Date"]),
            rel("Fact DQ Result", "Data Quality Rule", ["Tested DQ Rule"]),
            rel("Fact DQ Result", "Calendar Date", ["Data As-Of Date"]),
            rel("Data Quality Rule", "Taxonomy Element", ["DQ Rule Target Element"], optional=True),
            rel("Critical Data Element", "Taxonomy Element", ["CDE Taxonomy Attribute"]),
            rel("Fact Vendor Data Issue", "Dataset", ["Issue Dataset"]),
            rel("Fact Vendor Data Issue", "Calendar Date", ["Detected Date"]),
            rel("Instrument", "Dataset", ["Source Dataset"], optional=True),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
        ],
        notes=("Security master operations star around the setup request, with DQ results, vendor data issues and "
               "the two audit facts (corporate action scrubbing from DP-099, issuer relationship approval from DP-098) "
               "as companions sharing Instrument, Employee and Calendar Date. CDEs and taxonomy elements are conformed "
               "from DP-100; a rule targets a 17 element when its Taxonomy Element has Element Data Domain 17. "
               "Model gap: DQ Rule Target Data Asset and Tested Data Asset point to 21 Data Asset, but 21 Data Asset is "
               "not an input and DP-101, which publishes it, is not upstream, so both stay degenerate. Dataset Vendor "
               "(14 Data Vendor) also stays degenerate."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-103": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact DQ Result", role="Fact", objects=[("21", "Data Quality Result")], pk=["DQ Result ID"],
                 measures=True,
                 grain="one row = DQ rule x execution timestamp x tested scope (data asset or feed load)",
                 note="The product grain; holds the measures. Tested Load (06 Load) stays degenerate: it is not an "
                      "input and no upstream model publishes loads."),
            dict(name="Fact DQ Issue", role="Fact", objects=[("21", "Data Quality Issue")], pk=["DQ Issue ID"],
                 grain="one row = data quality issue",
                 note="No resolved date (spec taxonomy gap); age and lateness against target are used."),
            dict(name="Fact Record Governance", role="Fact", objects=[("21", "Record Governance Metadata")],
                 pk=["Fact Record Governance Key"],
                 grain="one row = governed object x data quality status x information classification x system of "
                       "record x as-of date (aggregate)",
                 note="Read as an aggregate only (spec note): Governed Record Key, part of the registry key, is not "
                      "read, so the fact carries a surrogate key."),
            # -- bridges
            dim("Data Product Input", ("DP-101", "Data Product Input"), [("21", "Data Product Input")], role="Bridge",
                grain="one row = data product x input taxonomy element",
                note="Links products to the elements their DQ coverage is measured on."),
            dim("Data Ownership Assignment", ("DP-100", "Data Ownership Assignment"),
                [("21", "Data Ownership Assignment")], role="Bridge",
                grain="one row = ownership assignment (role x employee x governed rule, product or asset x effective "
                      "period)",
                note="Issues Without Active Owner reads the assignments in force."),
            # -- dimensions
            dict(name="Data Quality Rule", role="Dimension", objects=[("21", "Data Quality Rule")], pk=["DQ Rule ID"],
                 note="Built from the input: no foundational model publishes DQ rules; this product owns them "
                      "(CD-301)."),
            dict(name="Vendor Data Issue", role="Dimension", objects=[("14", "Vendor Data Issue")],
                 pk=["Vendor Data Issue ID"], note="Linked, not restated (CD-164); only the status is read."),
            dim("Critical Data Element", ("DP-100", "Critical Data Element"), [("21", "Critical Data Element")]),
            dim("Taxonomy Element", ("DP-100", "Taxonomy Element"), [("21", "Taxonomy Element")]),
            dim("Taxonomy Release", ("DP-100", "Taxonomy Release")),
            dim("Data Contract", ("DP-101", "Data Contract"), [("21", "Data Contract")]),
            dim("Data Asset", ("DP-101", "Data Asset"),
                [("21", "Data Asset"), ("21", "Analytics Report & Dashboard Detail")],
                note="Reports and dashboards are data assets; their certification detail folds here."),
            dim("Data Product", ("DP-101", "Data Product"), [("21", "Data Product")]),
            dim("Metric Definition", ("DP-101", "Metric Definition"), [("21", "Metric Definition")]),
            dim("Employee", EMP, [("20", "Employee")], note="Issue owners, CDE owners and assigned owners."),
            dim("Application", ("DP-211", "Application"), [("41", "Application")],
                note="Systems of record, source systems and hosting systems."),
            dim("Org Unit", ("DP-013", "Org Unit")),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact DQ Result", "Data Quality Rule", ["Tested DQ Rule"]),
            rel("Fact DQ Result", "Data Asset", ["Tested Data Asset"], optional=True),
            rel("Fact DQ Result", "Calendar Date", ["Data As-Of Date"]),
            rel("Data Quality Rule", "Taxonomy Element", ["DQ Rule Target Element"], optional=True),
            rel("Data Quality Rule", "Taxonomy Release", ["DQ Rule Target Registered In Release"], optional=True),
            rel("Data Quality Rule", "Data Asset", ["DQ Rule Target Data Asset"], optional=True),
            rel("Fact DQ Issue", "Fact DQ Result", ["Raising DQ Result"], optional=True),
            rel("Fact DQ Issue", "Data Quality Rule", ["Related DQ Rule"], optional=True),
            rel("Fact DQ Issue", "Data Asset", ["Affected Data Asset"], optional=True),
            rel("Fact DQ Issue", "Critical Data Element", ["Affected CDE"], optional=True),
            rel("Fact DQ Issue", "Employee", ["DQ Issue Owner"], optional=True),
            rel("Fact DQ Issue", "Vendor Data Issue", ["Linked Vendor Data Issue"], optional=True),
            rel("Fact DQ Issue", "Calendar Date", ["DQ Issue Detected Date"]),
            rel("Fact Record Governance", "Taxonomy Element", ["Governed Record Object"]),
            rel("Fact Record Governance", "Taxonomy Release", ["Governed Record Object Release"], optional=True),
            rel("Fact Record Governance", "Application", ["System of Record"], optional=True),
            rel("Fact Record Governance", "Application", ["Source System"], optional=True),
            rel("Critical Data Element", "Taxonomy Element", ["CDE Taxonomy Attribute"]),
            rel("Critical Data Element", "Taxonomy Release", ["CDE Registered In Release"], optional=True),
            rel("Critical Data Element", "Data Product", ["CDE Scoped Data Product"], optional=True),
            rel("Critical Data Element", "Employee", ["CDE Owner"], optional=True),
            rel("Data Contract", "Data Product", ["Contracted Data Product"]),
            rel("Data Contract", "Org Unit", ["Consumer Org Unit"], optional=True),
            rel("Data Contract", "Data Quality Rule", ["Contracted DQ Rules"], card="M:N", optional=True,
                note="Held as text (spec taxonomy gap); the build parses the rule IDs."),
            rel("Data Asset", "Application", ["Hosting System"], optional=True),
            rel("Data Asset", "Data Product", ["Report Primary Data Product"], optional=True,
                note="Certified Reports on Uncertified Products follows this link."),
            rel("Data Product Input", "Data Product", ["Input Data Product"]),
            rel("Data Product Input", "Taxonomy Element", ["Input Taxonomy Element"]),
            rel("Metric Definition", "Data Product", ["Metric Source Data Product"], optional=True),
            rel("Data Ownership Assignment", "Employee", ["Assigned Employee"]),
            rel("Data Ownership Assignment", "Data Quality Rule", ["Governed Data Quality Rule"], optional=True),
            rel("Data Ownership Assignment", "Data Product", ["Governed Data Product"], optional=True),
            rel("Data Ownership Assignment", "Data Asset", ["Governed Data Asset"], optional=True),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
        ],
        notes=("Enterprise DQ star: the DQ result fact with issues and the record governance aggregate as companions, "
               "sharing Data Quality Rule, Taxonomy Element, Data Asset and Calendar Date. Catalog objects (assets, "
               "products, contracts, metrics, product inputs) are conformed from DP-101 and governance objects "
               "(elements, releases, CDEs, ownership) from DP-100, so certification checks run over the published "
               "catalog. Model gap: Record Governance Metadata is read without Governed Record Key, so its fact uses a "
               "surrogate key at the aggregate grain. Degenerate references: Tested Load (06 Load) and Consumer "
               "External Party (02 Party), whose targets no upstream model publishes."),
    ),
}
