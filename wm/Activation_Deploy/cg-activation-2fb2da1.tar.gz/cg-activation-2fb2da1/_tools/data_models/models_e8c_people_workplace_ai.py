"""Logical data models, Wave E8 consumer group "people_workplace_ai": Star models for DP-197 to DP-201 (20 Human
Capital), DP-207 to DP-209 (44 Workplace & Corporate Services) and DP-104 (21 AI use case governance). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here (e.g.
  "Employing Legal Entity" and "Identifying Legal Entity" are both DP-013 Internal Legal Entity; "Site" is DP-013 Office
  Location, which keeps the SITE- key). Product input objects of the same concept sit on the conformed entity and merge
  with its inherited attributes.
- DP-192 publishes the workforce records as well as the Employee dimension, so Employee Job Assignment, Employee
  Reporting Line and Employee Lifecycle Event are conformed from it even where they act as a bridge or an event fact
  here; the same applies to Journal Entry, GL Posting and GL Account Balance from DP-191.
- Objects mastered in another consumer product (DP-033 compensation statements, DP-038 gifts and entertainment, DP-039
  registrations and CE) are built here from the inputs with the registry key, so they still join to that product.
  Within this group, DP-199 and DP-201 conform the pay records DP-198 publishes (DP-198 is in their upstream).
- Date roles are conformed from DP-013 Calendar Date, whose key is the calendar date itself, so a date attribute on a
  fact is the foreign key.
- Aggregate facts at a grain that no input carries (org unit x legal entity x ... x period; site x month; site x day)
  borrow the keys of the dimensions that make the grain ("<Dimension> Key"); the codes that are not entities (job level,
  employment type) are derived by the build, not read.
- Party references (02) are linked only where DP-240, DP-210 or DP-213 is upstream; elsewhere they are carried as keys,
  as the specs say.
"""


def dim(name, src, objects=(), note="", role="Dimension", **kw):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role=role, conformed=src, objects=list(objects), note=note, **kw)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


EMP = ("DP-192", "Employee")
POS = ("DP-192", "Workforce Position")
JOB = ("DP-192", "Job Profile")
EJA = ("DP-192", "Employee Job Assignment")
ERL = ("DP-192", "Employee Reporting Line")
ELE = ("DP-192", "Employee Lifecycle Event")
ORG = ("DP-013", "Org Unit")
ILE = ("DP-013", "Internal Legal Entity")
OFFICE = ("DP-013", "Office Location")
FPER = ("DP-013", "Fiscal Period")
CAL = ("DP-013", "Calendar Date")
CCY = ("DP-013", "Currency")
CTRY = ("DP-013", "Country")
UOM = ("DP-013", "Unit of Measure")
GLA = ("DP-190", "GL Account")
CC = ("DP-190", "Cost Center")
LEDGER = ("DP-190", "Ledger")
JE = ("DP-191", "Journal Entry")
GLP = ("DP-191", "GL Posting")
PROD = ("DP-004", "Investment Product")

EJA_NOTE = ("Conformed from DP-192: effective-dated worker x position or job profile assignments that place each worker "
            "in a job profile (and level) at a date.")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-197": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Workforce Movement", role="Fact", objects=[], pk=["Fact Workforce Movement Key"],
                 measures=True,
                 grain="one row = org unit x employing legal entity x job level x work location x employment type x "
                       "fiscal period (month, quarter, year, rolling 12 months)",
                 note="The movement and rate aggregate that holds the measures. Surrogate key over the grain because job "
                      "level (from Job Profile) and employment type (from Employee) are codes, not entities; the build "
                      "derives them. Average Headcount is read from DP-192's certified headcount for the same breakdown, "
                      "never recomputed."),
            dim("Employee Lifecycle Event", ELE, [("20", "Employee Lifecycle Event")], role="Fact",
                grain="one row = lifecycle event (ELE-): hire, rehire, conversion, transfer, promotion, termination",
                note="Conformed from DP-192, which publishes the event records: hires, leavers, internal moves and the "
                     "regulatory notification flag are counted from them. Related Reorganization (09 Reorganization "
                     "Event, mastered in DP-009) is carried as a key."),
            dict(name="Fact Leave of Absence", role="Fact", objects=[("20", "Leave of Absence")],
                 pk=["Leave Employee", "Leave Type", "Leave Start Date"],
                 grain="one row = employee x leave type x leave period",
                 note="Leave Type values for medical and long-term disability leave are health data and appear only in "
                      "the Restricted - Personal Data view (CD-344)."),
            dict(name="Fact Job Requisition", role="Fact", objects=[("20", "Job Requisition")],
                 pk=["Job Requisition ID"], grain="one row = job requisition (JRQ-)",
                 note="Time to Fill runs from Requisition Opened Date to Requisition Filled Date (no offer or start "
                      "date exists, spec taxonomy gap)."),
            dict(name="Fact Candidate Application", role="Fact", objects=[("20", "Candidate Application")],
                 pk=["Candidate Application ID"], grain="one row = candidate x job requisition",
                 note="Source of hire, internal fill and candidate retention. Candidate Name is not read."),
            dict(name="Fact Background Screening", role="Fact", objects=[("20", "Background Screening")],
                 pk=["Screened Employee", "Screened Candidate Application", "Screening Type", "Screening Completed Date"],
                 grain="one row = employee or candidate application x screening type x screening completed date",
                 note="One of Screened Employee or Screened Candidate Application is populated; both sit in the "
                      "registry key with that meaning. Results and severity are Restricted - Personal Data (criminal "
                      "record data). Screening Vendor (02 Party) and Related Individual Registration (08) are carried "
                      "as keys (spec)."),
            # -- bridges
            dim("Employee Job Assignment", EJA, [("20", "Employee Job Assignment")], role="Bridge",
                grain="one row = worker x position or job profile x assignment type x effective period",
                note=EJA_NOTE + " Internal moves are assignment changes between positions."),
            # -- dimensions
            dim("Employee", EMP, [("20", "Employee"), ("20", "Contingent Worker Detail")],
                note="Conformed from DP-192. Contingent Worker Detail folds here; workers with a Contingent Worker Type "
                     "are excluded from the rates."),
            dim("Workforce Position", POS, [("20", "Workforce Position")],
                note="Conformed from DP-192: budgeted positions for vacancy and key-person checks."),
            dim("Job Profile", JOB, [("20", "Job Profile")],
                note="Conformed from DP-192: job family, job level and regulated role category."),
            dim("Org Unit", ORG),
            dim("Employing Legal Entity", ILE, note="Employing and position legal entity."),
            dim("Work Location", OFFICE, note="Employee work location and position location."),
            dim("Cost Center", CC, [("19", "Chart Segment Value")],
                note="Conformed from DP-190; supplies the cost center labels of Position Cost Center."),
            dim("Fiscal Period", FPER, [("09", "Fiscal Period")]),
            dim("Calendar Date", CAL, note="Event, leave, requisition and screening dates."),
        ],
        relationships=[
            rel("Fact Workforce Movement", "Org Unit", ["Org Unit Key"], note="Carries the Org Unit ID."),
            rel("Fact Workforce Movement", "Employing Legal Entity", ["Employing Legal Entity Key"],
                note="Carries the Legal Entity ID."),
            rel("Fact Workforce Movement", "Work Location", ["Work Location Key"], note="Carries the Office ID."),
            rel("Fact Workforce Movement", "Fiscal Period", ["Fiscal Period Key"], note="Carries the Fiscal Period ID."),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee", "Employing Legal Entity", ["Employing Legal Entity"]),
            rel("Employee", "Work Location", ["Work Location"], optional=True),
            rel("Employee Job Assignment", "Employee", ["Assigned Worker"]),
            rel("Employee Job Assignment", "Workforce Position", ["Assigned Workforce Position"], optional=True),
            rel("Employee Job Assignment", "Job Profile", ["Assigned Job Profile"], optional=True),
            rel("Workforce Position", "Job Profile", ["Position Job Profile"]),
            rel("Workforce Position", "Org Unit", ["Position Org Unit"]),
            rel("Workforce Position", "Employing Legal Entity", ["Position Legal Entity"]),
            rel("Workforce Position", "Work Location", ["Position Location"], optional=True),
            rel("Workforce Position", "Cost Center", ["Position Cost Center"], optional=True,
                note="Carries the bare cost center code; joins within the cost center segment."),
            rel("Employee Lifecycle Event", "Employee", ["Event Employee"]),
            rel("Employee Lifecycle Event", "Calendar Date", ["Event Effective Date"]),
            rel("Fact Leave of Absence", "Employee", ["Leave Employee"]),
            rel("Fact Leave of Absence", "Calendar Date", ["Leave Start Date"]),
            rel("Fact Job Requisition", "Workforce Position", ["Requisition Position"], optional=True),
            rel("Fact Job Requisition", "Employee", ["Hiring Manager"], optional=True),
            rel("Fact Job Requisition", "Calendar Date", ["Requisition Opened Date"]),
            rel("Fact Candidate Application", "Fact Job Requisition", ["Applied Requisition"]),
            rel("Fact Candidate Application", "Employee", ["Internal Candidate Employee"], optional=True,
                note="Internal candidates only."),
            rel("Fact Candidate Application", "Employee", ["Hired As Employee"], optional=True,
                note="Set when the application ends in a hire."),
            rel("Fact Background Screening", "Employee", ["Screened Employee"], optional=True),
            rel("Fact Background Screening", "Fact Candidate Application", ["Screened Candidate Application"],
                optional=True),
            rel("Fact Background Screening", "Calendar Date", ["Screening Completed Date"], optional=True),
        ],
        notes=("Workforce movement star: one aggregate fact at org unit x legal entity x job level x work location x "
               "employment type x fiscal period holds the rates, with lifecycle events, leaves, requisitions, candidate "
               "applications and screenings as event-level facts. Employee, Workforce Position, Job Profile, Employee "
               "Job Assignment and Employee Lifecycle Event are conformed from DP-192 (headcount and joiners and "
               "leavers stay DP-192's); org unit, legal entity, work location, fiscal period and calendar date from "
               "DP-013; the cost center from DP-190. "
               "External references carried as keys, not linked: Background Screening.Screening Vendor (02 Party; no "
               "party master is upstream) and Related Individual Registration (08, DP-039), and Employee Lifecycle "
               "Event.Related Reorganization (09, DP-009). "
               "Model gap: no input carries the aggregate grain, so Fact Workforce Movement has a surrogate key and "
               "borrows Org Unit, Employing Legal Entity, Work Location and Fiscal Period Key; job level and "
               "employment type are derived from Job Profile and Employee."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-198": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Payroll Result", role="Fact", objects=[("20", "Payroll Result")],
                 pk=["Payroll Employee", "Payroll Run"], measures=True,
                 grain="one row = employee x payroll run",
                 note="The product grain and the certified Gross Pay Paid (CD-347). No pay component breakdown exists, "
                      "so incentive paid through payroll is tested at instruction level."),
            dict(name="Fact Payroll Run", role="Fact", objects=[("20", "Payroll Run")], pk=["Payroll Run Identifier"],
                 grain="one row = payroll run (legal entity x pay period x run sequence)",
                 note="The run is reconciled to the journals it posted (Payroll Journal Entries, multi-valued) and to the "
                      "GL postings that name it (Source Payroll Run). Payroll Provider (02 Party) is carried as a key."),
            dict(name="Fact Base Pay Record", role="Fact", objects=[("20", "Base Pay Record")],
                 pk=["Paid Employee", "Pay Component", "Pay Effective From"],
                 grain="one row = employee x pay component x effective period",
                 note="Annualized base pay and pay review increases; DP-199 and DP-201 conform this entity."),
            dict(name="Fact Variable Compensation Award", role="Fact", objects=[("20", "Variable Compensation Award")],
                 pk=["Variable Compensation Award ID"], grain="one row = variable compensation award (VPA-)",
                 note="Awards granted and the committee approval test; DP-199 and DP-201 conform this entity."),
            dict(name="Fact Benefit Enrollment", role="Fact", objects=[("20", "Benefit Enrollment")],
                 pk=["Enrolled Employee", "Enrolled Benefit Plan", "Coverage Start Date"],
                 grain="one row = employee x benefit plan x coverage period",
                 note="Own Plan Membership resolves to DP-094 by key (spec); DP-094 is not upstream, so it is not "
                      "linked."),
            dict(name="Fact Compensation Statement", role="Fact", objects=[("03", "Compensation Statement")],
                 pk=["Statement ID"], grain="one row = advisor x statement period (CPS-)",
                 note="W4 (CW-907, CW-062): the 03 Compensation Statement (absorbed from 07). Incentive earned (Total "
                      "Earned, Net Payable Amount) stays DP-033's; built from the input with the registry key because "
                      "DP-033 is a consumer product, not a conformed source. Payroll Result Reference is the payroll "
                      "result that paid it."),
            dim("GL Posting", GLP, [("19", "GL Posting")], role="Fact",
                grain="one row = journal entry x journal line",
                note="Conformed from DP-191: payroll posts in summary per run, so Run-to-Journal Difference compares "
                     "run totals with the lines whose Source Payroll Run names the run."),
            # -- dimensions
            dict(name="Benefit Plan", role="Dimension", objects=[("20", "Benefit Plan")], pk=["Benefit Plan ID"],
                 note="Built from the input: no foundational model masters benefit plans. Benefit Provider (02 Party) "
                      "is carried as a key."),
            dim("Journal Entry", JE, [("19", "Journal Entry")], note="Conformed from DP-191."),
            dim("Employee", EMP, [("20", "Employee"), ("20", "Contingent Worker Detail")],
                note="Conformed from DP-192; identity comes from DP-192 by key (spec)."),
            dim("Employee Job Assignment", EJA, [("20", "Employee Job Assignment")], role="Bridge",
                grain="one row = worker x position or job profile x assignment type x effective period",
                note=EJA_NOTE + " Assignment FTE feeds Active Employees Not Paid and annualization."),
            dim("Job Profile", JOB),
            dim("Org Unit", ORG),
            dim("Employing Legal Entity", ILE,
                note="Employing entity, payroll run entity, benefit offering entity and journal posting entity."),
            dim("GL Account", GLA),
            dim("Cost Center", CC),
            dim("Ledger", LEDGER),
            dim("Fiscal Period", FPER, note="Accounting period of the payroll journals."),
            dim("Currency", CCY),
            dim("Calendar Date", CAL, note="Pay date, pay effective dates and coverage dates."),
        ],
        relationships=[
            rel("Fact Payroll Result", "Employee", ["Payroll Employee"]),
            rel("Fact Payroll Result", "Fact Payroll Run", ["Payroll Run"]),
            rel("Fact Payroll Result", "Fact Compensation Statement", ["Incentive Payout Statements"], card="M:N",
                optional=True, note="Multi-valued: the incentive statements paid in this result."),
            rel("Fact Payroll Result", "Currency", ["Payroll Currency"]),
            rel("Fact Payroll Run", "Employing Legal Entity", ["Payroll Run Legal Entity"]),
            rel("Fact Payroll Run", "Journal Entry", ["Payroll Journal Entries"], card="M:N",
                note="Multi-valued: the journals the run posted; they meet GL Posting.Source Payroll Run at the run "
                     "identifier."),
            rel("Fact Payroll Run", "Calendar Date", ["Pay Date"]),
            rel("GL Posting", "Journal Entry", ["Journal ID"]),
            rel("GL Posting", "GL Account", ["Posted Account"]),
            rel("GL Posting", "Cost Center", ["Cost Center Segment Value"], optional=True),
            rel("GL Posting", "Fact Payroll Run", ["Source Payroll Run"], optional=True,
                note="Set on payroll postings only."),
            rel("Journal Entry", "Ledger", ["Journal Ledger"]),
            rel("Journal Entry", "Employing Legal Entity", ["Posting Legal Entity"], optional=True),
            rel("Journal Entry", "Fiscal Period", ["Posting Accounting Period"],
                note="Posting Accounting Period carries the fiscal period code."),
            rel("Fact Base Pay Record", "Employee", ["Paid Employee"]),
            rel("Fact Base Pay Record", "Currency", ["Pay Currency"]),
            rel("Fact Variable Compensation Award", "Employee", ["Award Recipient"]),
            rel("Fact Variable Compensation Award", "Currency", ["Award Currency"]),
            rel("Fact Variable Compensation Award", "Calendar Date", ["Award Grant Date"], optional=True),
            rel("Fact Benefit Enrollment", "Employee", ["Enrolled Employee"]),
            rel("Fact Benefit Enrollment", "Benefit Plan", ["Enrolled Benefit Plan"]),
            rel("Benefit Plan", "Employing Legal Entity", ["Offering Legal Entity"]),
            rel("Fact Compensation Statement", "Employee", ["Employee Key"],
                note="Model gap: derived link. Statement Participant names the 03 Advisor, the advisor role profile "
                     "keyed by its EMP- employee; no 03 Advisor object is an input and DP-009, whose Employee holds it, "
                     "is not upstream, so Statement Participant stays an attribute and Employee Key carries the same "
                     "EMP- value to the DP-192 Employee."),
            rel("Employee", "Employing Legal Entity", ["Employing Legal Entity"]),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee Job Assignment", "Employee", ["Assigned Worker"]),
            rel("Employee Job Assignment", "Job Profile", ["Assigned Job Profile"], optional=True),
        ],
        notes=("Payroll and reward star at employee x payroll run, with the run, base pay, variable awards, benefit "
               "enrollments, DP-033's incentive statements (03), and the DP-191 payroll postings as "
               "facts at their own grains. Employee, Employee Job Assignment and Job Profile are conformed from DP-192; "
               "Journal Entry and GL Posting from DP-191; GL Account, Cost Center and Ledger from DP-190; legal entity, "
               "org unit, fiscal period, currency and calendar date from DP-013. Compensation Statement (03) is DP-033's "
               "object, built here with its registry key. "
               "External references carried as keys, not linked: Payroll Run.Payroll Provider and Benefit Plan.Benefit "
               "Provider (02 Party; no party master is upstream) and Benefit Enrollment.Own Plan Membership (16, "
               "DP-094). "
               "W4 (CW-907): 07 Payroll Payment Instruction is removed (no successor) with its fact and relationships."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-199": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Variable Compensation Award", ("DP-198", "Fact Variable Compensation Award"),
                [("20", "Variable Compensation Award")], role="Fact", measures=True,
                grain="one row = variable compensation award (VPA-): employee x performance year x award",
                note="The product grain since CW-920: conformed within the group from DP-198, which publishes the "
                     "awards; Linked Fund is read here in addition (Carried Interest Points left with 30, CW-930). Holds the measures."),
            dict(name="Fact Deferred Award Tranche", role="Fact", objects=[("20", "Deferred Award Tranche")],
                 pk=["Tranche Award", "Tranche Number"], grain="one row = variable compensation award x vesting tranche",
                 note="Vesting and malus or clawback status; vesting is tested against the conduct flag of the "
                      "performance review."),
            dim("Base Pay Record", ("DP-198", "Fact Base Pay Record"), [("20", "Base Pay Record")], role="Fact",
                grain="one row = employee x pay component x effective period",
                note="Conformed within the group from DP-198: fixed remuneration for the variable-to-fixed ratio."),
            dict(name="Fact Performance Review", role="Fact", objects=[("20", "Performance Review")],
                 pk=["Reviewed Employee", "Review Cycle", "Review Type"],
                 grain="one row = employee x review cycle x review type",
                 note="Read for the Conduct Adjustment Indicator. Built from the input because DP-200, which publishes "
                      "reviews, is not upstream of this product."),
            # -- dimensions
            dim("Employee", EMP, [("20", "Employee")]),
            dim("Employing Legal Entity", ILE, note="Employing entity of the award recipient."),
            dim("Linked Fund", PROD, note="Conformed from DP-004: the fund whose units an award is paid in."),
            dim("Calendar Date", CAL, note="Vesting, clawback and approval dates."),
        ],
        relationships=[
            rel("Variable Compensation Award", "Employee", ["Award Recipient"]),
            rel("Variable Compensation Award", "Linked Fund", ["Linked Fund"], optional=True,
                note="Fund-unit awards and carried interest only."),
            rel("Fact Deferred Award Tranche", "Variable Compensation Award", ["Tranche Award"]),
            rel("Fact Deferred Award Tranche", "Calendar Date", ["Vesting Date"]),
            rel("Base Pay Record", "Employee", ["Paid Employee"]),
            rel("Fact Performance Review", "Employee", ["Reviewed Employee"]),
            rel("Employee", "Employing Legal Entity", ["Employing Legal Entity"]),
        ],
        notes=("W1b re-point (CW-920): Fact MRT Identification, the 07 Plan Participant Assignment bridge and Remuneration "
               "Conflict Assessment, and the conformed Employee Job Assignment and Job Profile are removed with the 20 "
               "Material Risk Taker Identification object and the spec inputs only the MRT measures read; the award becomes "
               "the main fact (grain employee x performance year x award) and the legal entity dimension is renamed "
               "Employing Legal Entity. WP0 re-scope candidate (CW-041). "
               "Deferred remuneration star with awards, deferred tranches, base pay and performance reviews as facts. "
               "Awards and base pay are conformed within the group from DP-198 (upstream); Employee from DP-192; the "
               "linked fund from DP-004; legal entity and dates from DP-013."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-200": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Talent Aggregate", role="Fact", objects=[], pk=["Fact Talent Aggregate Key"],
                 measures=True,
                 grain="one row = org unit x employing legal entity x training requirement or review cycle x period",
                 note="The published aggregate that holds the measures; the named rows below go only to HR, line "
                      "managers and Compliance. Surrogate key because the requirement-or-cycle member differs by "
                      "measure family."),
            dict(name="Fact Learning Completion", role="Fact", objects=[("20", "Learning Completion")],
                 pk=["Learner Employee", "Completed Learning Item", "Completion Due Date", "Completion Date"],
                 grain="one row = employee x learning item x assignment due date (or completion)",
                 note="Mandatory training completion and on-time measures; DP-208 reads these records by key for "
                      "emergency role certification."),
            dict(name="Fact Performance Review", role="Fact", objects=[("20", "Performance Review")],
                 pk=["Reviewed Employee", "Review Cycle", "Review Type"],
                 grain="one row = employee x review cycle x review type",
                 note="Rating distribution, calibration change and conduct adjustments (which feed DP-199)."),
            dict(name="Fact Performance Objective", role="Fact", objects=[("20", "Performance Objective")],
                 pk=["Objective Employee", "Objective Review Cycle", "Objective Title"],
                 grain="one row = employee x review cycle x objective",
                 note="Objective weighting breaks. Linked Metric Definition (21 KPI-) is carried as a key: it resolves "
                      "through DP-101, which is not upstream (spec)."),
            dict(name="Fact Succession Plan Entry", role="Fact", objects=[("20", "Succession Plan Entry")],
                 pk=["Succession Position", "Successor Employee"],
                 grain="one row = workforce position x successor employee",
                 note="Key-person succession cover, emergency successors and stale plans."),
            dict(name="Fact CE Requirement", role="Fact", objects=[("08", "CE Requirement")],
                 pk=["Individual Registration Key", "CE Element", "CE Due Date"],
                 grain="one row = registration x CE element x due date",
                 note="Child group of the registration (fold=False). Read only to show Firm Element completions that "
                      "have not reached the registration; CE status is never published here (DP-039 boundary)."),
            # -- bridges
            dim("Employee Job Assignment", EJA, [("20", "Employee Job Assignment")], role="Bridge",
                grain="one row = worker x position or job profile x assignment type x effective period",
                note=EJA_NOTE + " Places workers in positions and in the training population."),
            # -- dimensions
            dict(name="Learning Item", role="Dimension", objects=[("20", "Learning Item")], pk=["Learning Item ID"],
                 note="Built from the input: no foundational model masters learning items. Learning Provider (02 "
                      "Party) is carried as a key."),
            dict(name="Mandatory Training Requirement", role="Dimension",
                 objects=[("20", "Mandatory Training Requirement")], pk=["Training Requirement ID"],
                 note="Built from the input. Applicable Population Rule is free text evaluated outside the taxonomy "
                      "(spec taxonomy gap)."),
            dict(name="Individual Registration", role="Dimension", objects=[("08", "Individual Registration")],
                 pk=["License ID"],
                 note="DP-039 record built from the input with its registry key; only the license and person are read."),
            dim("Employee", EMP, [("20", "Employee")]),
            dim("Workforce Position", POS, [("20", "Workforce Position")],
                note="Conformed from DP-192: Key-Person Risk Indicator drives the succession measures."),
            dim("Job Profile", JOB, [("20", "Job Profile")]),
            dim("Org Unit", ORG),
            dim("Employing Legal Entity", ILE),
            dim("Fiscal Period", FPER, note="The reporting period of the aggregates."),
            dim("Calendar Date", CAL, note="Due, completion and succession review dates."),
        ],
        relationships=[
            rel("Fact Talent Aggregate", "Org Unit", ["Org Unit Key"], note="Carries the Org Unit ID."),
            rel("Fact Talent Aggregate", "Employing Legal Entity", ["Employing Legal Entity Key"],
                note="Carries the Legal Entity ID."),
            rel("Fact Talent Aggregate", "Fiscal Period", ["Fiscal Period Key"], note="Carries the Fiscal Period ID."),
            rel("Fact Talent Aggregate", "Mandatory Training Requirement", ["Mandatory Training Requirement Key"],
                optional=True, note="Training rows only; review rows are keyed by review cycle in the surrogate."),
            rel("Fact Learning Completion", "Employee", ["Learner Employee"]),
            rel("Fact Learning Completion", "Learning Item", ["Completed Learning Item"], optional=True),
            rel("Fact Learning Completion", "Mandatory Training Requirement", ["Satisfied Training Requirement"],
                optional=True),
            rel("Fact Learning Completion", "Calendar Date", ["Completion Due Date"], optional=True),
            rel("Mandatory Training Requirement", "Learning Item", ["Required Learning Item"], optional=True),
            rel("Fact Performance Review", "Employee", ["Reviewed Employee"]),
            rel("Fact Performance Review", "Employee", ["Reviewer"], optional=True),
            rel("Fact Performance Objective", "Employee", ["Objective Employee"]),
            rel("Fact Succession Plan Entry", "Workforce Position", ["Succession Position"]),
            rel("Fact Succession Plan Entry", "Employee", ["Successor Employee"]),
            rel("Fact Succession Plan Entry", "Calendar Date", ["Succession Review Date"], optional=True),
            rel("Fact CE Requirement", "Individual Registration", ["Individual Registration Key"],
                note="Carries the License ID."),
            rel("Fact CE Requirement", "Calendar Date", ["CE Due Date"]),
            rel("Individual Registration", "Employee", ["Registered Person"]),
            rel("Employee Job Assignment", "Employee", ["Assigned Worker"]),
            rel("Employee Job Assignment", "Workforce Position", ["Assigned Workforce Position"], optional=True),
            rel("Employee Job Assignment", "Job Profile", ["Assigned Job Profile"], optional=True),
            rel("Workforce Position", "Job Profile", ["Position Job Profile"]),
            rel("Workforce Position", "Org Unit", ["Position Org Unit"]),
            rel("Workforce Position", "Employing Legal Entity", ["Position Legal Entity"]),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee", "Employing Legal Entity", ["Employing Legal Entity"]),
        ],
        notes=("Talent star: an org unit x legal entity x requirement-or-cycle x period aggregate holds the published "
               "measures; training completions, performance reviews and objectives, succession entries and the 08 CE "
               "requirements are the named facts behind it. Employee, Workforce Position, Job Profile and Employee Job "
               "Assignment are conformed from DP-192; org unit, legal entity, fiscal period and dates from DP-013. "
               "Learning items and training requirements have no foundational master and are built from the inputs; "
               "the 08 registration and CE requirement are DP-039's records, built with their registry keys. "
               "External references carried as keys, not linked: Learning Item.Learning Provider (02 Party) and "
               "Performance Objective.Linked Metric Definition (21, DP-101 not upstream). "
               "Model gap: the aggregate grain is carried by no input, so Fact Talent Aggregate has a surrogate key and "
               "borrows Org Unit, Employing Legal Entity, Fiscal Period and Mandatory Training Requirement Key. "
               "Model gap: 08 CE Requirement holds no registration attribute, so it borrows Individual Registration "
               "Key."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-201": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Human Capital Metric Value", role="Fact", objects=[("20", "Human Capital Metric Value")],
                 pk=["Metric Definition", "Metric Org Unit", "Metric Legal Entity", "Metric Country",
                     "Metric Breakdown", "Metric Period Type", "Metric Period End Date"],
                 measures=True,
                 grain="one row = metric definition x legal entity, org unit or country x breakdown x period end "
                       "(snapshot)",
                 note="The only rows that leave the product: aggregates with a minimum cell size of 10, published "
                      "under the row's Disclosure Classification. Headcount rows are tested against DP-192."),
            dim("Employee Lifecycle Event", ELE, [("20", "Employee Lifecycle Event")], role="Fact",
                grain="one row = lifecycle event (ELE-)",
                note="Conformed from DP-192: leavers for Turnover by Gender % under DP-197's turnover definition."),
            dim("Payroll Result", ("DP-198", "Fact Payroll Result"), [("20", "Payroll Result")], role="Fact",
                grain="one row = employee x payroll run",
                note="Conformed within the group from DP-198 (compensation tier); Hours Worked is read for hourly pay "
                     "once populated (CD-364)."),
            dim("Base Pay Record", ("DP-198", "Fact Base Pay Record"), [("20", "Base Pay Record")], role="Fact",
                grain="one row = employee x pay component x effective period",
                note="Conformed within the group from DP-198: FTE-adjusted fixed pay for the pay gap measures."),
            dim("Variable Compensation Award", ("DP-198", "Fact Variable Compensation Award"),
                [("20", "Variable Compensation Award")], role="Fact",
                grain="one row = variable compensation award (VPA-)",
                note="Conformed within the group from DP-198: bonus gap and bonus receipt, dated by Award Grant Date."),
            # -- bridges
            dim("Employee Job Assignment", EJA, [("20", "Employee Job Assignment")], role="Bridge",
                grain="one row = worker x position or job profile x assignment type x effective period",
                note=EJA_NOTE + " Working Pattern, Assignment FTE and Standard Weekly Hours are read here."),
            # -- dimensions
            dim("Employee", EMP, [("20", "Employee"), ("20", "Employee Personal Detail"),
                                  ("20", "Employee Diversity Profile")],
                note="Conformed from DP-192. Employee Personal Detail and Employee Diversity Profile fold here; this "
                     "product is the only reader of the diversity profile (special category data), so the "
                     "employee-level working set is Restricted - Personal Data and never published."),
            dim("Job Profile", JOB, [("20", "Job Profile")], note="Job level and EEO-1 job category."),
            dim("Payroll Run", ("DP-198", "Fact Payroll Run"), role="Fact",
                grain="one row = payroll run",
                note="Conformed within the group from DP-198 so pay results carry their pay period."),
            dim("Metric Definition", ("DP-101", "Metric Definition"), [("21", "Metric Definition")],
                note="Conformed from DP-101: KPI- definitions and their disclosure frameworks."),
            dim("Data Product", ("DP-101", "Data Product"), note="Source data product of a metric definition."),
            dim("Legal Entity", ILE, [("09", "Internal Legal Entity")],
                note="Metric legal entity, employing entity and payroll run entity; Jurisdiction of Formation sets "
                     "the statutory regime."),
            dim("Org Unit", ORG),
            dim("Country", CTRY, note="Metric country and country of residence."),
            dim("Calendar Date", CAL, note="Snapshot dates and event dates."),
        ],
        relationships=[
            rel("Fact Human Capital Metric Value", "Metric Definition", ["Metric Definition"]),
            rel("Fact Human Capital Metric Value", "Org Unit", ["Metric Org Unit"], optional=True),
            rel("Fact Human Capital Metric Value", "Legal Entity", ["Metric Legal Entity"], optional=True),
            rel("Fact Human Capital Metric Value", "Country", ["Metric Country"], optional=True),
            rel("Fact Human Capital Metric Value", "Calendar Date", ["Metric Period End Date"]),
            rel("Metric Definition", "Data Product", ["Metric Source Data Product"], optional=True),
            rel("Employee", "Legal Entity", ["Employing Legal Entity"]),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee", "Country", ["Country of Residence"], optional=True),
            rel("Employee Job Assignment", "Employee", ["Assigned Worker"]),
            rel("Employee Job Assignment", "Job Profile", ["Assigned Job Profile"], optional=True),
            rel("Employee Lifecycle Event", "Employee", ["Event Employee"]),
            rel("Employee Lifecycle Event", "Calendar Date", ["Event Effective Date"]),
            rel("Payroll Result", "Employee", ["Payroll Employee"]),
            rel("Payroll Result", "Payroll Run", ["Payroll Run"]),
            rel("Payroll Run", "Legal Entity", ["Payroll Run Legal Entity"]),
            rel("Base Pay Record", "Employee", ["Paid Employee"]),
            rel("Variable Compensation Award", "Employee", ["Award Recipient"]),
        ],
        notes=("Diversity and pay equity star: the Human Capital Metric Value fact at metric x scope x breakdown x "
               "period is the published grain; the employee-level working set (Employee with its personal detail and "
               "diversity profile, job assignments, lifecycle events and pay records) is the restricted input it is "
               "computed from. Employee, Employee Job Assignment, Job Profile and Employee Lifecycle Event are "
               "conformed from DP-192; Payroll Result, Payroll Run, Base Pay Record and Variable Compensation Award "
               "within the group from DP-198 (upstream); Metric Definition and Data Product from DP-101; legal entity, "
               "org unit, country and dates from DP-013. DP-197 is upstream for its turnover definition only; no "
               "DP-197 entity is needed."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-207": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Site Month", role="Fact", objects=[], pk=["Site Key", "Calendar Date Key"], measures=True,
                 grain="one row = site (SITE-) x month",
                 note="Holds the measures; space, occupancy, lease, energy and emission facts are summarized onto it. "
                      "Calendar Date Key carries the month-end date. Site Headcount is DP-192's certified headcount by "
                      "work location."),
            dict(name="Fact Occupancy Measurement", role="Fact", objects=[("44", "Site Occupancy Measurement")],
                 pk=["Measured Site", "Measured Space", "Occupancy Measurement Date"],
                 grain="one row = site or space x measurement date",
                 note="Measured Space is empty for a site-level measurement; it stays in the key with that meaning."),
            dict(name="Fact Space Reservation", role="Fact", objects=[("44", "Space Reservation")],
                 pk=["Fact Space Reservation Key"], grain="one row = reserved space x reservation start x booker",
                 note="Booking no-show rate. The registry key includes Booker, which is deliberately not read (no names "
                      "in the occupancy view), so the key is a surrogate."),
            dict(name="Fact Lease Payment Schedule Line", role="Fact", objects=[("44", "Lease Payment Schedule Line")],
                 pk=["Schedule Lease", "Payment Period Start", "Lease Charge Type"],
                 grain="one row = lease x payment period x charge type",
                 note="Contracted rent commitment and base rent per area."),
            dict(name="Fact Lease Critical Date", role="Fact", objects=[("44", "Lease Option & Critical Date")],
                 pk=["Option Lease", "Lease Option Type", "Option Effective Date"],
                 grain="one row = lease x option type x option effective date",
                 note="Critical dates due within 180 days and missed notice deadlines."),
            dict(name="Fact Lease Accounting Measurement", role="Fact", objects=[("44", "Lease Accounting Measurement")],
                 pk=["Measured Lease", "Measurement Ledger", "Lease Measurement Date"],
                 grain="one row = lease x ledger x measurement date",
                 note="Child group of the lease (fold=False); produced by the 19 Controller (CD-279). Lease liability "
                      "and right-of-use asset are compared with DP-191 balances."),
            dict(name="Fact Utility Consumption", role="Fact", objects=[("44", "Utility Consumption Record")],
                 pk=["Consumption Site", "Meter Identifier", "Utility Resource", "Consumption Period Start"],
                 grain="one row = site x meter x utility resource x consumption period",
                 note="Source Utility Invoice (19 Payable Invoice) is carried as a key: no upstream publishes payable "
                      "invoices."),
            dict(name="Fact Operational Emission", role="Fact", objects=[("44", "Operational Emission Record")],
                 pk=["Emission Reporting Entity", "Emission Record Level", "Emission Site", "Reporting Year",
                     "GHG Scope Category", "Calculation Method"],
                 grain="one row = reporting entity x record level (site or entity total) x site x reporting year x GHG "
                       "scope category x calculation method",
                 note="Entity Total rows are compared with the sum of site rows (Site-to-Entity Emission Difference). "
                      "Reported Indicator (34) is carried as a key."),
            dim("GL Account Balance", ("DP-191", "GL Account Balance"), [("19", "GL Account Balance")], role="Fact",
                grain="one row = ledger x GL account x segment combination x fiscal period x balance type x currency",
                note="Conformed from DP-191: closing balances of the lease liability and right-of-use accounts the "
                     "Controller lists (spec taxonomy gap)."),
            # -- bridges
            dict(name="Space Assignment", role="Bridge", objects=[("44", "Space Assignment")],
                 pk=["Assigned Space", "Assigned Org Unit", "Assignment Effective From"],
                 grain="one row = building space x org unit x effective period",
                 note="Assigned area by cost center and unassigned space."),
            dict(name="Leased Space", role="Bridge", objects=[("44", "Leased Space")],
                 pk=["Space Lease", "Leased Site", "Leased Building Space", "Leased Space Effective From"],
                 grain="one row = lease x site x building space x effective period",
                 note="Ties leases to the sites and spaces they cover; Leased Building Space is empty for a whole-site "
                      "lease."),
            # -- dimensions
            dim("Site", OFFICE, [("09", "Office Location")],
                note="Conformed from DP-013, which keeps the SITE- key (CD-279); country and legal entity come from "
                     "here, never from the site profile."),
            dict(name="Site Profile", role="Dimension", objects=[("44", "Site Profile")],
                 pk=["Profiled Site", "Profile Effective From"],
                 note="Built from the input: site type, tenure, gross area and workstation capacity, effective-dated."),
            dict(name="Building Space", role="Dimension", objects=[("44", "Building Space")], pk=["Space ID"],
                 note="Built from the input: no foundational model masters building space. Parent Space gives the "
                      "building, floor and room hierarchy."),
            dict(name="Lease", role="Dimension", objects=[("44", "Lease")], pk=["Lease ID"],
                 note="Built from the input; Head Lease links a sublease to its head lease."),
            dim("Landlord", ("DP-240", "Party"), note="Conformed from DP-240: the lease counterparty."),
            dim("Lease Contract", ("DP-213", "Contract"), note="Conformed from DP-213: the lease document."),
            dim("Employee", EMP, [("20", "Employee")], note="Conformed from DP-192: headcount by work location."),
            dim("Legal Entity", ILE, note="Firm lease entity, emission reporting entity and site entity."),
            dim("Org Unit", ORG),
            dim("Chargeback Cost Center", CC, note="Conformed from DP-190."),
            dim("Ledger", LEDGER, note="Lease measurement ledger and balance ledger."),
            dim("GL Account", GLA),
            dim("Fiscal Period", FPER),
            dim("Unit of Measure", UOM, note="Area, consumption and activity units."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Site Month", "Site", ["Site Key"], note="Carries the Office ID (SITE-)."),
            rel("Fact Site Month", "Calendar Date", ["Calendar Date Key"], note="Carries the month-end date."),
            rel("Site", "Legal Entity", ["Office Legal Entity"], optional=True),
            rel("Site Profile", "Site", ["Profiled Site"]),
            rel("Site Profile", "Unit of Measure", ["Site Area Unit"], optional=True),
            rel("Building Space", "Site", ["Space Site"]),
            rel("Building Space", "Building Space", ["Parent Space"], optional=True),
            rel("Space Assignment", "Building Space", ["Assigned Space"]),
            rel("Space Assignment", "Org Unit", ["Assigned Org Unit"]),
            rel("Space Assignment", "Chargeback Cost Center", ["Chargeback Cost Center"], optional=True),
            rel("Fact Occupancy Measurement", "Site", ["Measured Site"]),
            rel("Fact Occupancy Measurement", "Building Space", ["Measured Space"], optional=True),
            rel("Fact Occupancy Measurement", "Calendar Date", ["Occupancy Measurement Date"]),
            rel("Fact Space Reservation", "Building Space", ["Reserved Space"]),
            rel("Lease", "Landlord", ["Lease Counterparty"]),
            rel("Lease", "Legal Entity", ["Firm Legal Entity"]),
            rel("Lease", "Lease", ["Head Lease"], optional=True, note="Subleases only."),
            rel("Lease", "Lease Contract", ["Lease Contract"], optional=True),
            rel("Leased Space", "Lease", ["Space Lease"]),
            rel("Leased Space", "Site", ["Leased Site"]),
            rel("Leased Space", "Building Space", ["Leased Building Space"], optional=True),
            rel("Fact Lease Payment Schedule Line", "Lease", ["Schedule Lease"]),
            rel("Fact Lease Critical Date", "Lease", ["Option Lease"]),
            rel("Fact Lease Critical Date", "Calendar Date", ["Notice Deadline Date"], optional=True),
            rel("Fact Lease Accounting Measurement", "Lease", ["Measured Lease"]),
            rel("Fact Lease Accounting Measurement", "Ledger", ["Measurement Ledger"]),
            rel("Fact Utility Consumption", "Site", ["Consumption Site"]),
            rel("Fact Utility Consumption", "Unit of Measure", ["Consumption Unit"]),
            rel("Fact Operational Emission", "Legal Entity", ["Emission Reporting Entity"]),
            rel("Fact Operational Emission", "Site", ["Emission Site"], optional=True,
                note="Empty on Entity Total rows."),
            rel("Fact Operational Emission", "Unit of Measure", ["Activity Unit"], optional=True),
            rel("GL Account Balance", "Ledger", ["Balance Ledger"]),
            rel("GL Account Balance", "GL Account", ["Balance GL Account"]),
            rel("GL Account Balance", "Fiscal Period", ["Balance Fiscal Period"]),
            rel("Employee", "Site", ["Work Location"], optional=True),
        ],
        notes=("Real estate and environmental star at site x month: occupancy, reservations, lease schedules, critical "
               "dates, lease accounting measurements, utility consumption and operational emissions are facts at their "
               "own grains, with building space, space assignment and leased space as the site's structure. The site "
               "is DP-013 Office Location (SITE-); legal entity, org unit, unit of measure, fiscal period and dates "
               "are conformed from DP-013; the landlord from DP-240; the lease document from DP-213; ledger, GL account "
               "and chargeback cost center from DP-190; GL Account Balance from DP-191; Employee from DP-192. 44 "
               "Building Space, Lease and Site Profile have no foundational master and are built from the inputs. "
               "External references carried as keys, not linked: Utility Consumption Record.Source Utility Invoice (19 "
               "Payable Invoice) and Operational Emission Record.Reported Indicator (34). "
               "Model gap: the site x month grain is carried by no input, so Fact Site Month borrows Site Key and "
               "Calendar Date Key. "
               "Model gap: Space Reservation's registry key includes Booker, which the spec deliberately does not read, "
               "so the reservation fact has a surrogate key."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-208": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Site Day", role="Fact", objects=[], pk=["Site Key", "Calendar Date Key"], measures=True,
                 grain="one row = site (SITE-) x day",
                 note="Holds the control measures; maintenance, access, visitor, incident, risk assessment and emergency "
                      "role facts are summarized onto it at day grain (badge deactivation has no timestamp)."),
            dict(name="Fact Planned Maintenance", role="Fact", objects=[("44", "Planned Maintenance Schedule")],
                 pk=["Maintained Asset", "Maintenance Task Type"], grain="one row = facility asset x maintenance task type",
                 note="Overdue statutory maintenance from Next Due Date."),
            dict(name="Fact Facility Work Order", role="Fact", objects=[("44", "Facility Work Order")],
                 pk=["Work Order ID"], grain="one row = facility work order",
                 note="SLA measures. Vendor Invoice (19 Payable Invoice) and Work Order Purchase Order (40) are carried "
                      "as keys."),
            dict(name="Fact Access Badge", role="Fact", objects=[("44", "Access Badge")], pk=["Badge ID"],
                 grain="one row = access badge",
                 note="Leavers with an active badge and badges deactivated by the leaver event."),
            dict(name="Fact Zone Grant", role="Fact", objects=[("44", "Physical Access Zone Grant")],
                 pk=["Granted Badge", "Zone Site", "Access Zone", "Zone Space", "Grant Effective From"],
                 grain="one row = badge x site x access zone x space x effective period",
                 note="Restricted zone grants without an approver."),
            dict(name="Fact Visitor Registration", role="Fact", objects=[("44", "Visitor Registration")],
                 pk=["Visit Reference"], grain="one row = visit",
                 note="Visits without departure. Visitor Party (02) is carried as a key; Visitor Name is not read."),
            dict(name="Fact Physical Security Incident", role="Fact", objects=[("44", "Physical Security Incident")],
                 pk=["Security Incident Reference"], grain="one row = physical security incident"),
            dict(name="Fact Health & Safety Incident", role="Fact", objects=[("44", "Health & Safety Incident")],
                 pk=["H&S Incident ID"], grain="one row = health and safety incident",
                 note="Special category health data: rows with Affected Employee are published only in the Restricted "
                      "- Personal Data view; the wide view carries site counts."),
            dict(name="Fact Workplace Risk Assessment", role="Fact", objects=[("44", "Workplace Risk Assessment")],
                 pk=["Risk Assessment Reference"], grain="one row = workplace risk assessment"),
            dict(name="Fact Emergency Role Assignment", role="Fact", objects=[("44", "Emergency Role Assignment")],
                 pk=["Role Holder", "Emergency Role Site", "Emergency Role", "Emergency Role Effective From"],
                 grain="one row = role holder x site x emergency role x effective period",
                 note="Emergency role gaps per floor and role holders who have left."),
            # -- bridges
            dim("Employee Job Assignment", EJA, [("20", "Employee Job Assignment")], role="Bridge",
                grain="one row = worker x position or job profile x assignment type x effective period",
                note="Conformed from DP-192: Assignment FTE for the recordable incident rate denominator."),
            # -- dimensions
            dim("Site", OFFICE, note="Conformed from DP-013 Office Location (SITE-)."),
            dict(name="Facility Asset", role="Dimension", objects=[("44", "Facility Asset")], pk=["Facility Asset Tag"],
                 note="Built from the input; IT assets are never facility assets (CD-279). Asset Lease (44 Lease) and "
                      "Fixed Asset Number are carried as keys."),
            dim("Vendor", ("DP-210", "Vendor"),
                note="Conformed from DP-210: maintenance vendor and assigned work order vendor."),
            dim("Employee", EMP, [("20", "Employee"), ("20", "Contingent Worker Detail")],
                note="Conformed from DP-192: badge holders, hosts, approvers, affected employees and role holders; "
                     "Contingent Worker Detail folds here (Engagement End Date for contractor leavers)."),
            dim("Employee Lifecycle Event", ELE, [("20", "Employee Lifecycle Event")],
                note="Conformed from DP-192: the leaver event that should deactivate a badge."),
            dict(name="Learning Completion", role="Dimension", objects=[("20", "Learning Completion")],
                 pk=["Learning Completion Key"],
                 note="The DP-200 record that certifies an emergency role holder, built from the input. Surrogate key "
                      "because Completion Due Date, part of the registry key, is not read."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Site Day", "Site", ["Site Key"], note="Carries the Office ID (SITE-)."),
            rel("Fact Site Day", "Calendar Date", ["Calendar Date Key"]),
            rel("Facility Asset", "Site", ["Asset Site"]),
            rel("Fact Planned Maintenance", "Facility Asset", ["Maintained Asset"]),
            rel("Fact Planned Maintenance", "Vendor", ["Maintenance Vendor"], optional=True),
            rel("Fact Planned Maintenance", "Calendar Date", ["Next Due Date"], optional=True),
            rel("Fact Facility Work Order", "Site", ["Work Order Site"]),
            rel("Fact Facility Work Order", "Facility Asset", ["Work Order Asset"], optional=True),
            rel("Fact Facility Work Order", "Vendor", ["Assigned Vendor"], optional=True),
            rel("Fact Access Badge", "Employee", ["Badge Holder"], optional=True, note="Empty on visitor badges."),
            rel("Fact Access Badge", "Fact Visitor Registration", ["Badge Visit"], optional=True,
                note="Visitor badges only."),
            rel("Fact Access Badge", "Employee Lifecycle Event", ["Deactivating Lifecycle Event"], optional=True),
            rel("Fact Zone Grant", "Fact Access Badge", ["Granted Badge"]),
            rel("Fact Zone Grant", "Site", ["Zone Site"]),
            rel("Fact Zone Grant", "Employee", ["Grant Approver"], optional=True),
            rel("Fact Visitor Registration", "Site", ["Visited Site"]),
            rel("Fact Visitor Registration", "Employee", ["Host Employee"], optional=True),
            rel("Fact Physical Security Incident", "Site", ["Security Incident Site"]),
            rel("Fact Physical Security Incident", "Fact Access Badge", ["Involved Badge"], optional=True),
            rel("Fact Health & Safety Incident", "Site", ["H&S Incident Site"]),
            rel("Fact Health & Safety Incident", "Employee", ["Affected Employee"], optional=True),
            rel("Fact Health & Safety Incident", "Calendar Date", ["Regulatory Report Date"], optional=True),
            rel("Fact Workplace Risk Assessment", "Site", ["Assessed Site"]),
            rel("Fact Workplace Risk Assessment", "Calendar Date", ["Next Review Date"], optional=True),
            rel("Fact Emergency Role Assignment", "Employee", ["Role Holder"]),
            rel("Fact Emergency Role Assignment", "Site", ["Emergency Role Site"]),
            rel("Fact Emergency Role Assignment", "Learning Completion", ["Certifying Learning Completion"],
                optional=True),
            rel("Learning Completion", "Employee", ["Learner Employee"]),
            rel("Employee Lifecycle Event", "Employee", ["Event Employee"]),
            rel("Employee Job Assignment", "Employee", ["Assigned Worker"]),
            rel("Employee", "Site", ["Work Location"], optional=True),
        ],
        notes=("Facilities control star at site x day, with planned maintenance, work orders, badges, zone grants, "
               "visits, physical security and health and safety incidents, risk assessments and emergency role "
               "assignments as event-level facts. Site and dates are conformed from DP-013; Employee, Employee Job "
               "Assignment and Employee Lifecycle Event from DP-192; Vendor from DP-210. Facility assets have no "
               "foundational master and are built from the input. "
               "External references carried as keys, not linked: Visitor Registration.Visitor Party (02; no party "
               "master other than DP-210 is upstream), Work Order Vendor Invoice (19) and Purchase Order (40), "
               "Facility Asset.Asset Lease (44 Lease, DP-207). "
               "Model gap: 44 Building Space is not an input of this product (DP-207 publishes it and is not "
               "upstream), so Asset Location Space, Work Order Space, Zone Space, Assessed Workstation and Emergency "
               "Role Floor are degenerate keys; Emergency Role Gaps works on the floor key as delivered. "
               "Model gap: the site x day grain is carried by no input, so Fact Site Day borrows Site Key and Calendar "
               "Date Key. "
               "Model gap: Learning Completion is read without Completion Due Date, part of its registry key, so it has "
               "a surrogate key; DP-200, which publishes it, is not in the upstream (the spec notes say the record is "
               "DP-200's)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-209": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Expense Line", role="Fact", objects=[("44", "Expense Line")],
                 pk=["Line Expense Report", "Expense Line Number"], measures=True,
                 grain="one row = expense report x line number (aggregated by claimant x cost owner org unit x expense "
                       "type x month)",
                 note="The product grain and T&E Spend. External Attendees (02 Party) are carried as keys; no party "
                      "master is upstream."),
            dict(name="Fact Expense Report", role="Fact", objects=[("44", "Expense Report")], pk=["Expense Report ID"],
                 grain="one row = expense report",
                 note="Approval chain, reimbursement route and status. Reimbursement Payroll Result (20) is carried as "
                      "a key only so the compensation tier stays in DP-198 (CD-344)."),
            dict(name="Fact Card Transaction", role="Fact", objects=[("44", "Card Transaction")],
                 pk=["Transaction Card", "Issuer Transaction Reference"], grain="one row = card x issuer transaction",
                 note="Unmatched card transactions and personal spend on corporate cards."),
            dict(name="Fact Travel Booking", role="Fact", objects=[("44", "Travel Booking")], pk=["Trip ID"],
                 grain="one row = trip",
                 note="Premium travel share; Air Distance feeds DP-207's Scope 3 Category 6 rows. Booking Agency (02) is "
                      "carried as a key."),
            dim("GL Posting", GLP, [("19", "GL Posting")], role="Fact",
                grain="one row = journal entry x journal line",
                note="Conformed from DP-191: T&E Subledger to GL Difference compares lines with the postings of the "
                     "report's journal."),
            # -- dimensions
            dict(name="Corporate Card", role="Dimension", objects=[("44", "Corporate Card")], pk=["Card Account ID"],
                 note="Built from the input. Card Issuer (02) is carried as a key."),
            dict(name="Expense Policy Limit", role="Dimension", objects=[("44", "Expense Policy Limit")],
                 pk=["Limited Expense Type", "Location Band", "Applicable Job Level", "Limit Effective From"],
                 note="Built from the input. Governing Policy (38 Policy) is carried as a key."),
            dict(name="Gift & Entertainment Item", role="Dimension", objects=[("08", "Gift / Entertainment Item")],
                 pk=["GNE ID"],
                 note="DP-038 record built from the input with its registry key; this product only tests that each "
                      "entertainment line references one. Recipient Individual (02) is carried as a key."),
            dict(name="Supplier Payment", role="Dimension", objects=[("19", "Supplier Payment")],
                 pk=["Supplier Payment Document Number"],
                 note="Built from the input: no foundational model publishes 19 supplier payments as an entity. "
                      "AP-route reimbursement status is read from it."),
            dim("Journal Entry", JE, [("19", "Journal Entry")], note="Conformed from DP-191."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: claimant, approver, cardholder, traveler and giver."),
            dim("Employee Reporting Line", ERL, [("20", "Employee Reporting Line")], role="Bridge",
                grain="one row = reporting employee x line manager x reporting line type x effective period",
                note="Conformed from DP-192: tests self-approved and off-chain reports against the claimant's line "
                     "manager on the latest Expense Date (spec taxonomy gap)."),
            dim("Employee Job Assignment", EJA, [("20", "Employee Job Assignment")], role="Bridge",
                grain="one row = worker x position or job profile x assignment type x effective period",
                note=EJA_NOTE + " Job level selects the policy limit."),
            dim("Job Profile", JOB, [("20", "Job Profile")]),
            dim("Recharge Fund", PROD, note="Conformed from DP-004: the fund a line is recharged to."),
            dim("Cost Owner Org Unit", ORG),
            dim("Legal Entity", ILE, note="Employing entity, card billing entity and journal posting entity."),
            dim("Work Location", OFFICE, note="Claimant work location: sets the policy Location Band (spec gap)."),
            dim("GL Account", GLA),
            dim("Cost Center", CC),
            dim("Fiscal Period", FPER),
            dim("Country", CTRY, note="Trip destination countries."),
            dim("Calendar Date", CAL, note="Expense, card posting and trip dates."),
        ],
        relationships=[
            rel("Fact Expense Line", "Fact Expense Report", ["Line Expense Report"]),
            rel("Fact Expense Line", "Fact Card Transaction", ["Matched Card Transaction"], optional=True,
                note="Card-paid lines only."),
            rel("Fact Expense Line", "Gift & Entertainment Item", ["Related Gift / Entertainment Items"], card="M:N",
                optional=True, note="Multi-valued: entertainment lines only."),
            rel("Fact Expense Line", "Recharge Fund", ["Recharge Fund"], optional=True),
            rel("Fact Expense Line", "Expense Policy Limit", ["Expense Type"], card="M:N",
                note="Matched on expense type, the claimant's location band and job level, effective on the Expense "
                     "Date."),
            rel("Fact Expense Line", "Calendar Date", ["Expense Date"]),
            rel("Fact Expense Report", "Employee", ["Claimant"]),
            rel("Fact Expense Report", "Employee", ["Expense Approver"], optional=True),
            rel("Fact Expense Report", "Cost Owner Org Unit", ["Cost Owner Org Unit"]),
            rel("Fact Expense Report", "Supplier Payment", ["Reimbursement Supplier Payment"], optional=True,
                note="AP route only."),
            rel("Fact Expense Report", "Journal Entry", ["Posting Journal Entry"], optional=True),
            rel("Fact Card Transaction", "Corporate Card", ["Transaction Card"]),
            rel("Fact Card Transaction", "Calendar Date", ["Card Posting Date"]),
            rel("Corporate Card", "Employee", ["Cardholder"]),
            rel("Corporate Card", "Legal Entity", ["Card Billing Entity"]),
            rel("Fact Travel Booking", "Employee", ["Traveler"]),
            rel("Fact Travel Booking", "Country", ["Destination Countries"], card="M:N",
                note="Multi-valued: one row per destination country after the build explodes the list."),
            rel("Fact Travel Booking", "Calendar Date", ["Trip Start Date"]),
            rel("Gift & Entertainment Item", "Employee", ["Giver"], optional=True),
            rel("GL Posting", "Journal Entry", ["Journal ID"]),
            rel("GL Posting", "GL Account", ["Posted Account"]),
            rel("GL Posting", "Cost Center", ["Cost Center Segment Value"], optional=True),
            rel("Journal Entry", "Legal Entity", ["Posting Legal Entity"], optional=True),
            rel("Journal Entry", "Fiscal Period", ["Posting Accounting Period"],
                note="Posting Accounting Period carries the fiscal period code."),
            rel("Employee", "Legal Entity", ["Employing Legal Entity"]),
            rel("Employee", "Cost Owner Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee", "Work Location", ["Work Location"], optional=True),
            rel("Employee Reporting Line", "Employee", ["Reporting Employee"]),
            rel("Employee Reporting Line", "Employee", ["Line Manager"]),
            rel("Employee Job Assignment", "Employee", ["Assigned Worker"]),
            rel("Employee Job Assignment", "Job Profile", ["Assigned Job Profile"], optional=True),
        ],
        notes=("Travel and expense star at expense line, with the expense report, card transactions, trips and the "
               "DP-191 postings as facts and the policy limits, cards, gift and entertainment records and supplier "
               "payments as dimensions. Employee, Employee Reporting Line, Employee Job Assignment and Job Profile are "
               "conformed from DP-192; Journal Entry and GL Posting from DP-191; GL Account and Cost Center from "
               "DP-190; the recharge fund from DP-004; org unit, legal entity, work location, fiscal period, country "
               "and dates from DP-013. The 08 Gift / Entertainment Item is DP-038's record, built with its registry "
               "key. "
               "External references carried as keys, not linked: Expense Line.External Attendees, Corporate Card.Card "
               "Issuer, Travel Booking.Booking Agency and Gift / Entertainment Item.Recipient Individual (02 Party; no "
               "party master is upstream), Expense Report.Reimbursement Payroll Result (20, DP-198 by key only, "
               "CD-344) and Expense Policy Limit.Governing Policy (38). "
               "Expense Policy Limit joins by matching (expense type, band, job level and date), not by a key the line "
               "carries, so the relationship is M:N on Expense Type."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-104": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact AI Use Case", role="Fact", objects=[("21", "AI Use Case"), ("21", "AI Risk Classification")],
                 pk=["AI Use Case ID"], measures=True,
                 grain="one row = AI use case (AIU-) x effective period",
                 note="The product grain. AI Risk Classification is one row per use case and folds here (internal "
                      "AI risk tier, NIST AI RMF profile, general-purpose model flag; the EU AI Act fields left with CW-921). Model Provider (02) is carried as a key."),
            dict(name="Fact AI Data Usage Approval", role="Fact", objects=[("21", "AI Data Usage Approval")],
                 pk=["Approved AI Use Case", "Approved Data Asset", "AI Data Usage Approved Date"],
                 grain="one row = AI use case x data asset x approval",
                 note="Approvals expiring, approvals beyond license and personal data category exceptions."),
            # -- bridges
            dim("AI System Use Case Link", ("DP-211", "AI System Use Case Link"), [("41", "AI System Use Case Link")],
                role="Bridge", grain="one row = AI system (application) x AI use case x effective period",
                note="Conformed from DP-211: which deployed systems serve a use case."),
            dim("AI System Model Deployment", ("DP-212", "AI System Model Deployment"),
                [("41", "AI System Model Deployment")], role="Bridge",
                grain="one row = AI system x deployed model x effective period",
                note="Conformed from DP-212: reaches the models of a use case served by several models."),
            dim("Data Classification Assignment", ("DP-100", "Data Classification Assignment"),
                [("21", "Data Classification Assignment")], role="Bridge",
                grain="one row = classification scheme x data asset x effective period",
                note="Conformed from DP-100: information classification and personal data categories of each data "
                     "asset."),
            # -- dimensions
            dim("Data Asset", ("DP-101", "Data Asset"), [("21", "Data Asset")],
                note="Conformed from DP-101: the catalog entry and owning Data Domain."),
            dim("Dataset", ("DP-101", "Dataset"), note="Conformed from DP-101: the licensed dataset behind a data asset."),
            dict(name="Permitted Use Grant", role="Dimension", objects=[("14", "Permitted Use Grant")],
                 pk=["Grant Agreement", "Grant Dataset", "Permitted Use Category", "Grant Effective From"],
                 note="Read from 14, its master, by the grant key the approval holds (spec). Built from the input "
                      "because DP-014, which publishes it, is not upstream. Grant Agreement (14 Data License "
                      "Agreement) is carried as a key."),
            dim("Model", ("DP-212", "Model"), [("37", "Model Inventory Entry")],
                note="Conformed from DP-212: model, version and owner."),
            dim("Model Tier Assignment", ("DP-212", "Model Tier Assignment"), [("37", "Model Tier Assignment")],
                note="Conformed from DP-212: effective-dated model tier."),
            dim("Model Validation", ("DP-212", "Model Validation"), [("37", "Model Validation")],
                note="Conformed from DP-212: live use cases on unvalidated models."),
            dim("AI System", ("DP-211", "Application"), [("41", "Application"), ("41", "AI System Profile")],
                note="Conformed from DP-211 Application; AI System Profile folds here."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: business owner, model owner and human oversight assignee; Employment "
                     "Status finds use cases with a departed owner."),
        ],
        relationships=[
            rel("Fact AI Use Case", "Employee", ["AI Use Case Business Owner"]),
            rel("Fact AI Use Case", "Model", ["Model Name"], optional=True,
                note="Model Name references the 37 model (CD-294); resolves to the version in use by effective date."),
            rel("Fact AI Data Usage Approval", "Fact AI Use Case", ["Approved AI Use Case"]),
            rel("Fact AI Data Usage Approval", "Data Asset", ["Approved Data Asset"]),
            rel("Fact AI Data Usage Approval", "Permitted Use Grant", ["Covering Permitted Use Grant"], optional=True,
                note="Licensed data only."),
            rel("Permitted Use Grant", "Dataset", ["Grant Dataset"]),
            rel("Data Asset", "AI System", ["Hosting System"], optional=True),
            rel("Data Asset", "Dataset", ["Cataloged Licensed Dataset"], optional=True),
            rel("Data Classification Assignment", "Data Asset", ["Classified Data Asset"]),
            rel("AI System Use Case Link", "AI System", ["Linked AI System"]),
            rel("AI System Use Case Link", "Fact AI Use Case", ["Served AI Use Case"]),
            rel("AI System Model Deployment", "AI System", ["Model Deploying AI System"]),
            rel("AI System Model Deployment", "Model", ["Deployed Model"]),
            rel("Model Tier Assignment", "Model", ["Tiered Model"]),
            rel("Model Validation", "Model", ["Validated Model"]),
            rel("Model", "Employee", ["Model Owner"], optional=True),
            rel("AI System", "Employee", ["Human Oversight Assignee"], optional=True),
        ],
        notes=("AI use case governance star at use case, with data usage approvals as a second fact and the system and "
               "model links as bridges. The use case is mastered in 21, the model in 37 and the deployed system in 41 "
               "(CD-246, CD-269): Model, Model Tier Assignment, Model Validation and AI System Model Deployment are "
               "conformed from DP-212; the AI system (Application with its AI System Profile) and AI System Use Case "
               "Link from DP-211; Data Asset and Dataset from DP-101; Data Classification Assignment from DP-100; "
               "Employee from DP-192. This product adds no model or system attributes. "
               "External references carried as keys, not linked: AI Use Case.Model Provider (02 Party; no party master "
               "is upstream) and Permitted Use Grant.Grant Agreement (14 Data License Agreement). "
               "Model gap: 14 Permitted Use Grant is published by DP-014, which is not upstream, so it is built here "
               "from the input with its registry key."),
    ),
}
