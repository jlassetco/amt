"""Logical data models, Wave E8 consumer group "portfolio_stewardship": Star models for the consumer products of 24 Portfolio
Management & Construction (DP-126 to DP-131) and 34 Stewardship & Sustainable Investing (DP-132 to DP-135). See CONTRACT.md.

Conventions used in these stars:
- Facts, bridges and the product's own dimensions are built from the product's inputs and keep the registry keys, so they
  join to the same objects elsewhere. Objects a foundational model publishes are conformed dimensions named with the plain
  conformed name (Portfolio, Instrument, Issuer, Party, Employee, Model, Share Class, ...); where the product reads that
  object as an input, the input sits on the conformed dimension.
- Objects that only another consumer product publishes (24 Investment Committee Decision and Investment Decision from
  DP-126, 24 Target Allocation Set from DP-128, 25 Trade Order from DP-123, 23 Issuer Meeting from DP-121, 34 Sustainability
  Indicator Definition from DP-134, 34 Vote Rationale from DP-132, 02 Client Restriction from DP-077) are modeled here as
  the product's own entities with the same registry key, not conformed: conformed dimensions come from foundational models.
- Date roles are conformed from DP-013 Calendar Date; a date attribute on a fact is the foreign key (the firm business
  calendar supplies the rest of the key).
- Snapshot facts whose grain adds an as-of date or a portfolio that the input object does not carry (allocation drift,
  tax budget, engagement and ESG standing snapshots) borrow "<Dimension> Key" from the conformed dimension; each is noted.
- A single reference attribute that points to an entity with a composite key is drawn as the foreign key; the rest of the
  key comes from the context named in the relationship note.
- A reference whose target product is not upstream (or is downstream) stays an attribute and is listed under "External
  references" in the model notes.
"""


def dim(name, src, objects=(), pk=None, note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    return d


def own(name, objects, pk, role="Dimension", grain="", note="", measures=False):
    return dict(name=name, role=role, objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def fact(name, objects, pk, grain, note="", measures=False):
    return own(name, objects, pk, role="Fact", grain=grain, note=note, measures=measures)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


PORT = ("DP-140", "Portfolio")
PIL = ("DP-140", "Portfolio Implementation Link")
DISTAGR140 = ("DP-140", "Distribution Agreement")
HOLD = ("DP-142", "Portfolio Holding")
PVS = ("DP-142", "Portfolio Valuation Summary")
CASHBAL = ("DP-142", "Cash Balance")
PCM = ("DP-142", "Projected Cash Movement")
TAXLOT = ("DP-142", "Tax Lot")
PTXN = ("DP-141", "Portfolio Transaction")
APRICE = ("DP-143", "Approved Price")
PAO = ("DP-143", "Pricing Analytics Observation")
BMK144 = ("DP-144", "Benchmark")
IDXCON = ("DP-144", "Index Constituent")
IDXCHG = ("DP-144", "Index Change Announcement")
PRET = ("DP-145", "Performance Return")
BRET = ("DP-145", "Benchmark Return")
INST = ("DP-097", "Instrument")
BMK097 = ("DP-097", "Benchmark")
DATASET = ("DP-097", "Dataset")
ISSUER = ("DP-098", "Issuer")
INST098 = ("DP-098", "Instrument")
CAE = ("DP-099", "Corporate Action Event")
PARTY = ("DP-240", "Party")
PARTY093 = ("DP-093", "Party")
SKA = ("DP-167", "Safekeeping Account")
SKAA = ("DP-167", "Safekeeping Account Assignment")
SCNAV = ("DP-165", "Share Class NAV")
FNAV = ("DP-165", "Fund NAV Calculation")
EMP = ("DP-192", "Employee")
MODEL = ("DP-212", "Model")
MVAL = ("DP-212", "Model Validation")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
STRAT = ("DP-004", "Investment Strategy")
MODPORT = ("DP-004", "Model Portfolio")
PMA01 = ("DP-004", "Portfolio Manager Assignment")
PPROG = ("DP-005", "Partner Program")
MPP = ("DP-005", "Model Program Placement")
ACCT = ("DP-093", "Account")
CAL = ("DP-013", "Calendar Date")
LE = ("DP-013", "Internal Legal Entity")
ORG = ("DP-013", "Org Unit")
CCY = ("DP-013", "Currency")
CLS = ("DP-013", "Classification Scheme")
UOM = ("DP-013", "Unit of Measure")
GEO = ("DP-013", "Geographic Unit")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-126": dict(
        style="Star",
        entities=[
            # -- facts
            fact("Fact Investment Decision Scope", [("24", "Investment Decision Scope")],
                 ["Scoped Decision", "Scope Portfolio", "Scope Model Portfolio"],
                 grain="one row = investment decision x scoped portfolio or model portfolio",
                 measures=True,
                 note="The spec's main grain. Holds the measures because the decision and authority checks are "
                      "stated per scoped portfolio. Decisions with no scope row are read from the Investment "
                      "Decision dimension for Decisions Without Scope."),
            fact("Fact Committee Decision", [("24", "Investment Committee Decision")],
                 ["Decision Committee", "Decision Meeting Date", "Decision Item Number"],
                 grain="one row = investment committee x meeting date x decision item number"),
            fact("Fact Committee Membership", [("24", "Investment Committee Member")],
                 ["Member Committee", "Committee Member", "Committee Member Role", "Member Effective From"],
                 grain="one row = investment committee x employee x member role x effective period"),
            fact("Fact Portfolio Management Assignment", [("24", "Portfolio Management Assignment")],
                 ["Assigned Portfolio", "Assigned Manager", "Assigned Investment Team", "Portfolio Management Role",
                  "Assignment Effective From"],
                 grain="one row = portfolio x manager or investment team x portfolio management role x effective "
                       "period (SCD type 2)",
                 note="The operational manager of record, reconciled against the disclosed 01 Portfolio Manager "
                      "Assignment under CD-311."),
            # -- own dimensions (24 governance objects, published only by this product)
            own("Investment Decision", [("24", "Investment Decision"), ("24", "Decision Rationale")],
                ["Investment Decision ID"],
                note="Decision Rationale folds into the decision (one rationale per decision). Decision Algorithm is a "
                     "reference to 37 Model Inventory Entry (DP-212; W3, CW-128), kept as a degenerate key because DP-212 "
                     "is a consumer model."),
            own("Investment Committee", [("24", "Investment Committee")], ["Investment Committee Code"],
                note="Parent Committee gives the committee hierarchy (sub-committees report to a parent)."),
            own("Investment Committee Meeting", [("24", "Investment Committee Meeting")],
                ["Meeting Committee", "Meeting Date"],
                note="A dimension, not a fact, because the quorum measures read one row per meeting and the decisions "
                     "hang off it."),
            # -- conformed dimensions
            dim("Portfolio Manager Assignment", PMA01, [("01", "Portfolio Manager Assignment")],
                pk=["Investment Product Key", "Portfolio Manager", "PM Start Date"],
                note="The disclosed manager of the product (DP-004), the other side of the CD-311 reconciliation. The "
                     "01 object carries no product attribute, so the product key is borrowed as in DP-004."),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")],
                note="Bridges operational portfolios to the products they implement for the reconciliation."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Investment Product", PROD, [("01", "Investment Product")]),
            dim("Investment Strategy", STRAT),
            dim("Model Portfolio", MODPORT),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Employee", EMP, [("20", "Employee")],
                note="One dimension in several roles: decision maker, committee member, assigned manager, approver and "
                     "disclosed portfolio manager."),
            dim("Org Unit", ORG, note="The investment team."),
            dim("Internal Legal Entity", LE, note="Managing entity, committee owner and employing entity."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Investment Decision Scope", "Investment Decision", ["Scoped Decision"]),
            rel("Fact Investment Decision Scope", "Portfolio", ["Scope Portfolio"]),
            rel("Fact Investment Decision Scope", "Model Portfolio", ["Scope Model Portfolio"], optional=True),
            rel("Investment Decision", "Employee", ["Decision Maker"], optional=True,
                note="Optional because an algorithm may take the decision (Decision Algorithm)."),
            rel("Investment Decision", "Investment Strategy", ["Decision Strategy"], optional=True),
            rel("Investment Decision", "Instrument", ["Decision Instrument"], optional=True),
            rel("Investment Decision", "Instrument", ["Switch To Instrument"], optional=True),
            rel("Investment Decision", "Org Unit", ["Decision Investment Team"], optional=True),
            rel("Investment Decision", "Fact Committee Decision", ["Linked Committee Decision"], optional=True,
                note="Single reference to the committee x meeting date x item key."),
            rel("Fact Committee Decision", "Investment Committee", ["Decision Committee"]),
            rel("Fact Committee Decision", "Investment Committee Meeting", ["Decision Meeting Date"],
                note="With Decision Committee, the meeting's key."),
            rel("Fact Committee Decision", "Investment Strategy", ["Decision Scope Strategy"], optional=True),
            rel("Fact Committee Decision", "Calendar Date", ["Decision Effective Date"], optional=True),
            rel("Investment Committee Meeting", "Investment Committee", ["Meeting Committee"]),
            rel("Investment Committee Meeting", "Calendar Date", ["Meeting Date"]),
            rel("Investment Committee", "Investment Committee", ["Parent Committee"], optional=True),
            rel("Investment Committee", "Internal Legal Entity", ["Committee Owning Entity"], optional=True),
            rel("Fact Committee Membership", "Investment Committee", ["Member Committee"]),
            rel("Fact Committee Membership", "Employee", ["Committee Member"]),
            rel("Fact Portfolio Management Assignment", "Portfolio", ["Assigned Portfolio"]),
            rel("Fact Portfolio Management Assignment", "Employee", ["Assigned Manager"], optional=True,
                note="Optional because the assignment may name an investment team instead."),
            rel("Fact Portfolio Management Assignment", "Org Unit", ["Assigned Investment Team"], optional=True),
            rel("Fact Portfolio Management Assignment", "Employee", ["Assignment Approved By"], optional=True),
            rel("Fact Portfolio Management Assignment", "Calendar Date", ["Assignment Effective From"]),
            rel("Portfolio Manager Assignment", "Investment Product", ["Investment Product Key"]),
            rel("Portfolio Manager Assignment", "Employee", ["Portfolio Manager"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Portfolio Implementation Link", "Model Portfolio", ["Followed Model Portfolio"], optional=True),
            rel("Investment Product", "Investment Strategy", ["Implemented Strategy"]),
            rel("Portfolio", "Internal Legal Entity", ["Managing Entity"], optional=True),
            rel("Employee", "Internal Legal Entity", ["Employing Legal Entity"]),
        ],
        notes=("Governance star with four facts at the spec's grains (decision x scope, committee decision, membership, "
               "operational assignment) around the committee, meeting and decision dimensions this product owns. The "
               "CD-311 manager reconciliation is drawn as two paths to Employee: the operational assignment (24) and the "
               "disclosed Portfolio Manager Assignment (01, conformed from DP-004), joined to the product through the "
               "Portfolio Implementation Link (DP-140). "
               "Model gap: 01 Portfolio Manager Assignment has no product attribute among the inputs, so the dimension "
               "borrows Investment Product Key, as DP-004 does. "
               "External references (target product not upstream): Primary Research Recommendation (23 Research "
               "Recommendation, research products) stays an "
               "attribute; Decision Scope Deal left with 30 (W4, CW-930). "
               "W1b re-point (CW-937, CW-925): 37 Model Inventory Entry.Trading Algorithm Code left the taxonomy and the "
               "MiFIR decision-maker measure retired, so the Model dimension (DP-212) and the Decision Algorithm Code "
               "link to it are removed with the spec input. W3 (CW-128): Decision Algorithm Code is replaced by Decision Algorithm "
               "(Reference (Model Inventory Entry, 37)) and Decision Supervising Branch Country is dropped; the W1b model gap "
               "is closed.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-127": dict(
        style="Star",
        entities=[
            fact("Fact Policy Allocation", [("24", "Asset Allocation Policy Line")],
                 ["Line Allocation Policy", "Policy Asset Class", "Policy Sub-Class", "Portfolio Key", "As-of Date Key"],
                 grain="one row = implementing portfolio x allocation policy version x policy line (asset class x "
                       "sub-class) x as-of date",
                 measures=True,
                 note="Daily snapshot of actual vs neutral weight per policy line for each portfolio implementing the "
                      "policy's strategy, product or model portfolio. Portfolio Key and As-of Date Key are borrowed: the "
                      "policy line carries neither; the portfolio comes from the Portfolio Implementation Link and the "
                      "actual weights from Portfolio Holding."),
            fact("Fact Glide Path Point", [("24", "Glide Path Point")],
                 ["Glide Path Policy", "Years to Target Date", "Glide Path Asset Class", "Glide Path Sub-Class"],
                 grain="one row = glide path policy version x years to target date x asset class x sub-class"),
            fact("Fact Tactical View", [("24", "Tactical Allocation View")],
                 ["View Strategy", "View Asset Class", "View Segment", "View Date"],
                 grain="one row = view scope (house or strategy) x asset class x segment x view date",
                 note="A house view has no View Strategy, so that key part is null for house views."),
            own("Asset Allocation Policy", [("24", "Asset Allocation Policy")],
                ["Policy Strategy", "Policy Product", "Policy Model Portfolio", "Policy Version Number"],
                note="Strategic and glide path policies; Allocation Policy Type tells them apart."),
            own("Investment Committee Decision", [("24", "Investment Committee Decision")],
                ["Decision Committee", "Decision Meeting Date", "Decision Item Number"],
                note="DP-126 publishes the full committee record, but it is a consumer product; the decision is modeled "
                     "here with the same registry key so it joins to DP-126."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")]),
            dim("Investment Product", PROD, [("01", "Investment Product")]),
            dim("Investment Strategy", STRAT),
            dim("Model Portfolio", MODPORT),
            dim("Share Class", SHARE),
            dim("Benchmark", BMK144, [("01", "Benchmark")]),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")],
                note="Actual weights by asset class (through Instrument)."),
            dim("Portfolio Valuation Summary", PVS, [("18", "Portfolio Valuation Summary")],
                note="The denominator of the actual weights."),
            dim("Performance Return", PRET, [("32", "Performance Return")]),
            dim("Benchmark Return", BRET, [("32", "Benchmark Return")]),
            dim("As-of Date", CAL),
        ],
        relationships=[
            rel("Fact Policy Allocation", "Asset Allocation Policy", ["Line Allocation Policy"],
                note="Single reference to the policy's composite key."),
            rel("Fact Policy Allocation", "Portfolio", ["Portfolio Key"],
                note="Borrowed: the implementing portfolio of the snapshot row."),
            rel("Fact Policy Allocation", "As-of Date", ["As-of Date Key"], note="Borrowed: the snapshot date."),
            rel("Fact Policy Allocation", "Benchmark", ["Line Proxy Benchmark"], optional=True),
            rel("Fact Glide Path Point", "Asset Allocation Policy", ["Glide Path Policy"]),
            rel("Fact Tactical View", "Investment Strategy", ["View Strategy"], optional=True,
                note="Null for house views."),
            rel("Fact Tactical View", "Investment Committee Decision", ["View Committee Decision"], optional=True),
            rel("Fact Tactical View", "As-of Date", ["View Date"]),
            rel("Asset Allocation Policy", "Investment Strategy", ["Policy Strategy"], optional=True),
            rel("Asset Allocation Policy", "Investment Product", ["Policy Product"], optional=True),
            rel("Asset Allocation Policy", "Model Portfolio", ["Policy Model Portfolio"], optional=True),
            rel("Asset Allocation Policy", "Benchmark", ["Policy Benchmark"], optional=True),
            rel("Asset Allocation Policy", "Investment Committee Decision", ["Approving Committee Decision"],
                optional=True),
            rel("Investment Committee Decision", "As-of Date", ["Decision Effective Date"], optional=True),
            rel("Investment Product", "Investment Strategy", ["Implemented Strategy"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
            rel("Benchmark", "Benchmark", ["Blend Components"], card="M:N", optional=True,
                note="Multi-valued: one row per blend component after the build explodes the list."),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Portfolio Implementation Link", "Model Portfolio", ["Followed Model Portfolio"], optional=True),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Holding", "As-of Date", ["Holding Date"]),
            rel("Portfolio Valuation Summary", "Portfolio", ["Valued Portfolio"]),
            rel("Portfolio Valuation Summary", "As-of Date", ["Valuation As-Of Date"]),
            rel("Performance Return", "Portfolio", ["Return Portfolio"], optional=True),
            rel("Performance Return", "Share Class", ["Return Share Class"], optional=True),
            rel("Benchmark Return", "Benchmark", ["Return Benchmark"]),
        ],
        notes=("Asset allocation star: the policy line snapshot per implementing portfolio is the main fact, with "
               "glide path points and tactical views as companion facts (the Commitment Pacing Plan fact, the Portfolio "
               "Transaction dimension and the fund interest detail left with 30 at W4, CW-930). Holdings, valuation summaries "
               "and returns are conformed from DP-142 and DP-145 and read through Portfolio and "
               "Instrument for actual weights and allocation-effect returns. "
               "Model gap: the policy line carries no portfolio or as-of date, so the main fact borrows Portfolio Key "
               "and As-of Date Key (the snapshot's portfolio and date). "
               "Investment Committee Decision is the product's own dimension because DP-126 is a consumer product; it "
               "keeps the DP-126 key so the two join. Decision Committee stays an attribute (24 Investment Committee is "
               "not an input).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-128": dict(
        style="Star",
        entities=[
            fact("Fact Allocation Drift", [("24", "Target Allocation Line")],
                 ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class",
                  "Target Classification Scheme", "Target Classification Value", "Target Sleeve Portfolio",
                  "Portfolio Key", "As-of Date Key"],
                 grain="one row = portfolio x target allocation line x as-of date (intraday, end-of-day snapshot kept)",
                 measures=True,
                 note="Actual vs target weight and tolerance breach per target line. A model portfolio target applies to "
                      "every portfolio following the model (Portfolio Implementation Link), so Portfolio Key is "
                      "borrowed along with the snapshot's As-of Date Key. Target Country and Target Currency, part of "
                      "the registry key, are not inputs (see notes)."),
            fact("Fact Investable Cash Forecast", [("24", "Investable Cash Forecast")],
                 ["Forecast Portfolio", "Forecast Date", "Forecast Value Date", "Forecast Currency"],
                 grain="one row = portfolio x forecast date x value date x currency"),
            fact("Fact Cash Forecast Adjustment", [("24", "Cash Forecast Adjustment")],
                 ["Adjusted Cash Forecast", "Cash Forecast Adjustment Source", "Adjustment Sequence"],
                 grain="one row = investable cash forecast x adjustment source x adjustment sequence",
                 note="Manager adjustments behind Manager Adjustments Net."),
            fact("Fact Rebalance Portfolio Result", [("24", "Rebalance Portfolio Result")],
                 ["Result Rebalance Run", "Result Portfolio"],
                 grain="one row = rebalance run x portfolio"),
            fact("Fact Proposed Trade", [("24", "Proposed Trade")], ["Proposed Trade ID"],
                 grain="one row = proposed trade (portfolio x instrument x side within a run, or manual)"),
            own("Target Allocation Set", [("24", "Target Allocation Set")], ["Target Set ID"],
                note="Target subject (portfolio or model portfolio) and version; the active weight benchmark when the "
                     "targets are stated relative to an index."),
            own("Portfolio Construction Constraint", [("24", "Portfolio Construction Constraint")],
                ["Constrained Portfolio", "Constraint Type", "Constraint Scope", "Constraint Effective From"],
                note="Registry key also has Constrained Model Portfolio, which is not an input (see notes)."),
            own("Rebalance Run", [("24", "Rebalance Run")], ["Rebalance Run ID"]),
            own("Rebalance Index Change Trigger", [("24", "Rebalance Index Change Trigger")],
                ["Index Change Rebalance Run", "Triggering Index Change Announcement"], role="Bridge",
                grain="one row = rebalance run x index change announcement",
                note="Many-to-many: a run may answer several index changes, and one change drives many runs."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Model Portfolio", MODPORT),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Benchmark", BMK144, note="Active weight benchmark and the benchmark of index changes."),
            dim("Index Constituent", IDXCON, [("22", "Index Constituent")],
                note="Benchmark weights for active weight targets."),
            dim("Index Change Announcement", IDXCHG, [("22", "Index Change Announcement")]),
            dim("Approved Price", APRICE, [("22", "Approved Price")]),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")]),
            dim("Portfolio Valuation Summary", PVS, [("18", "Portfolio Valuation Summary")]),
            dim("Cash Balance", CASHBAL, [("18", "Cash Balance")]),
            dim("Projected Cash Movement", PCM, [("18", "Projected Cash Movement")]),
            dim("Model", MODEL, [("37", "Model Inventory Entry")], note="Optimizer and risk model of the run."),
            dim("Classification Scheme", CLS),
            dim("Currency", CCY),
            dim("As-of Date", CAL),
        ],
        relationships=[
            rel("Fact Allocation Drift", "Target Allocation Set", ["Line Target Set"]),
            rel("Fact Allocation Drift", "Portfolio", ["Portfolio Key"],
                note="Borrowed: the portfolio measured against the line (the target portfolio or a follower of the "
                     "target model portfolio)."),
            rel("Fact Allocation Drift", "As-of Date", ["As-of Date Key"], note="Borrowed: the snapshot date."),
            rel("Fact Allocation Drift", "Instrument", ["Target Instrument"], optional=True),
            rel("Fact Allocation Drift", "Classification Scheme", ["Target Classification Scheme"], optional=True),
            rel("Fact Allocation Drift", "Portfolio", ["Target Sleeve Portfolio"], optional=True),
            rel("Target Allocation Set", "Portfolio", ["Target Portfolio"], optional=True),
            rel("Target Allocation Set", "Model Portfolio", ["Target Model Portfolio"], optional=True),
            rel("Target Allocation Set", "Benchmark", ["Active Weight Benchmark"], optional=True),
            rel("Portfolio Construction Constraint", "Portfolio", ["Constrained Portfolio"]),
            rel("Rebalance Run", "Target Allocation Set", ["Driving Target Set"], optional=True),
            rel("Rebalance Run", "Model", ["Model Inventory Entry"], optional=True,
                note="Single reference to the model x version key."),
            rel("Rebalance Index Change Trigger", "Rebalance Run", ["Index Change Rebalance Run"]),
            rel("Rebalance Index Change Trigger", "Index Change Announcement", ["Triggering Index Change Announcement"],
                note="Single reference to the announcement's composite key."),
            rel("Index Change Announcement", "Benchmark", ["Changed Benchmark"]),
            rel("Index Change Announcement", "Instrument", ["Affected Index Instrument"]),
            rel("Index Constituent", "Benchmark", ["Constituent Benchmark"]),
            rel("Index Constituent", "Instrument", ["Constituent Instrument"]),
            rel("Fact Rebalance Portfolio Result", "Rebalance Run", ["Result Rebalance Run"]),
            rel("Fact Rebalance Portfolio Result", "Portfolio", ["Result Portfolio"]),
            rel("Fact Rebalance Portfolio Result", "Target Allocation Set", ["Applied Target Set"], optional=True),
            rel("Fact Proposed Trade", "Rebalance Run", ["Proposing Rebalance Run"], optional=True,
                note="Null for manual proposals."),
            rel("Fact Proposed Trade", "Portfolio", ["Proposed Trade Portfolio"]),
            rel("Fact Proposed Trade", "Instrument", ["Proposed Trade Instrument"]),
            rel("Fact Investable Cash Forecast", "Portfolio", ["Forecast Portfolio"]),
            rel("Fact Investable Cash Forecast", "Currency", ["Forecast Currency"]),
            rel("Fact Investable Cash Forecast", "As-of Date", ["Forecast Value Date"]),
            rel("Fact Cash Forecast Adjustment", "Fact Investable Cash Forecast", ["Adjusted Cash Forecast"],
                note="Single reference to the forecast's composite key."),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Valuation Summary", "Portfolio", ["Valued Portfolio"]),
            rel("Cash Balance", "Portfolio", ["Cash Balance Portfolio"]),
            rel("Cash Balance", "Currency", ["Balance Currency"]),
            rel("Projected Cash Movement", "Portfolio", ["Projection Portfolio"]),
            rel("Projected Cash Movement", "Currency", ["Projected Currency"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
        ],
        notes=("Target and rebalancing star: the allocation drift snapshot (portfolio x target line x as-of date) holds "
               "the measures; investable cash forecasts with their adjustments, rebalance results and proposed trades "
               "are companion facts. Holdings, valuation, cash and projected cash are conformed from DP-142, prices from "
               "DP-143 and index data from DP-144. "
               "Model gap: 24 Target Allocation Line's registry key includes Target Country and Target Currency, which "
               "are not inputs of DP-128, so country and currency target lines of the same set and component type are "
               "not told apart; the spec should add both attributes. "
               "Model gap: 24 Portfolio Construction Constraint's key includes Constrained Model Portfolio, which is not "
               "an input; model portfolio constraints cannot be read (the spec should add it or state that only "
               "portfolio constraints are in scope). "
               "Model gap: the target line carries no measured portfolio or as-of date, so the drift fact borrows "
               "Portfolio Key and As-of Date Key. "
               "External references (consumer or non-upstream products): Originating Investment Decision, Triggering "
               "Investment Decision and Planned Investment Decision (24 Investment Decision, DP-126; 24 Investment "
               "Decision is not an input here), Governing Allocation Policy (24 Asset Allocation Policy, DP-127), "
               "Triggering Transition Event (12 Transition Event) and Buffered Investment Restriction (01 Investment "
               "Restriction) stay attributes.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-129": dict(
        style="Star",
        entities=[
            fact("Fact Model Change", [("24", "Target Allocation Set"), ("24", "Model Change Summary")],
                 ["Target Set ID"],
                 grain="one row = model portfolio x target set version (one Target Set ID per version)",
                 measures=True,
                 note="Model Change Summary folds into the target set. Only target sets with Target Subject Type = model "
                      "portfolio are in scope. Copied From Target Set gives the prior version for the change."),
            fact("Fact Model Target Line", [("24", "Target Allocation Line")],
                 ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class"],
                 grain="one row = target set version x target line",
                 note="Registry key also has classification, country, currency and sleeve parts that are not inputs "
                      "(see notes); model portfolios are held at instrument or asset class level, so the inputs keep "
                      "the lines unique in practice."),
            own("Trade Order", [("25", "Trade Order")], ["Trade Order ID"],
                note="Read from DP-123 (a consumer product), so modeled here with the 25 registry key; only the order "
                     "time and originating decision are used, for the trade rotation lag."),
            dim("Model Program Placement", MPP, [("05", "Model Program Placement")],
                pk=["Partner Program Key", "Placed Model Portfolio", "Model Placement Effective From"],
                note="Placement of the model on a sponsor program; with Partner Program it gives the active sponsor "
                     "placements at release. The placement carries no program attribute, so the key borrows Partner "
                     "Program Key, as DP-005 does."),
            dim("Partner Program", PPROG, [("05", "Partner Program")]),
            dim("Model Portfolio", MODPORT, [("01", "Model Portfolio")]),
            dim("Investment Strategy", STRAT),
            dim("Instrument", INST, [("17", "Instrument")]),
        ],
        relationships=[
            rel("Fact Model Change", "Model Portfolio", ["Target Model Portfolio"]),
            rel("Fact Model Change", "Fact Model Change", ["Copied From Target Set"], optional=True,
                note="The prior version the change was made from."),
            rel("Fact Model Target Line", "Fact Model Change", ["Line Target Set"]),
            rel("Fact Model Target Line", "Instrument", ["Target Instrument"], optional=True),
            rel("Trade Order", "Fact Model Change", ["Fact Model Change Key"], optional=True,
                note="Model gap: derived link. Fact Model Change Key is set to the model change (target set) whose "
                     "Originating Investment Decision equals the order's; both reference the DP-126 decision, which is "
                     "not an input here, so the decision stays an attribute on both: orders of the firm's own trading "
                     "on the same decision as the model change."),
            rel("Model Program Placement", "Model Portfolio", ["Placed Model Portfolio"]),
            rel("Model Program Placement", "Partner Program", ["Partner Program Key"]),
            rel("Model Portfolio", "Investment Strategy", ["Implemented Strategy"]),
        ],
        notes=("Model delivery star: one fact row per model change (target set version) with its lines, the sponsor "
               "programs the model is placed on (DP-005) and the firm's own trade orders on the same decision (DP-123) "
               "for the rotation lag. Target Allocation Set is modeled from the 24 inputs, not conformed, because "
               "DP-128 is a consumer product. "
               "Model gap: Trade Order reaches Fact Model Change on a derived Fact Model Change Key, matched on the "
               "shared Originating Investment Decision; the registry points that attribute to 24 Investment Decision, "
               "which is not an input of DP-129 (DP-126 is not upstream), so it stays an attribute (external reference). "
               "Model gap: 24 Target Allocation Line's registry key parts Target Classification Scheme, Target "
               "Classification Value, Target Country, Target Currency and Target Sleeve Portfolio are not inputs; the "
               "fact keys on the parts the spec reads. "
               "Model gap: Model Program Placement carries no program attribute; the key borrows Partner Program Key. "
               "Release and effective times are timestamps (Sponsor Release Timestamp, Target Effective Timestamp), so "
               "no Calendar Date dimension is drawn; the release date is the date part of the timestamp. "
               "External references: Model Sponsor / Platform (05 Distributor Firm, W5; row rule: blank for own-program "
               "models) and Program Sponsor (05 Program, a Party reference) stay attributes "
               "because no party product (DP-001, DP-240) is upstream; the sponsor is named by Program Name.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-130": dict(
        # WP1 re-point (C-6): re-cut to the specs_w1c_inv_iop_fdn.py DP-130 inputs; see notes.
        style='Star',
        entities=[
            dict(name='Fact Tax Budget',
                 role='Fact',
                 objects=[('24', 'Tax Budget')],
                 pk=['Budget Portfolio', 'Tax Year', 'As-of Date Key'],
                 measures=True,
                 grain='one row = portfolio x tax year x as-of date (daily snapshot); W3 (CW-048) re-keyed to the 18 portfolio, account-level budgets are 46',
                 note='Budget vs realized gains to date. As-of Date Key is borrowed because the budget carries no snapshot date.'),
            dict(name='Fact Proposed Lot Selection',
                 role='Fact',
                 objects=[('24', 'Proposed Lot Selection')],
                 pk=['Lot Selection Trade', 'Selected Tax Lot'],
                 grain='one row = proposed trade x tax lot (lot selection detail)'),
            dict(name='Fact Rebalance Portfolio Result',
                 role='Fact',
                 objects=[('24', 'Rebalance Portfolio Result')],
                 pk=['Result Rebalance Run', 'Result Portfolio'],
                 grain='one row = rebalance run x portfolio',
                 note='Estimated realized gain of the run against the budget.'),
            dict(name='Fact Lot Relief',
                 role='Fact',
                 objects=[('18', 'Lot Relief')],
                 pk=['Relieved Tax Lot', 'Closing Transaction'],
                 grain='one row = tax lot x closing transaction',
                 note="Realized gains and wash-sale disallowances booked; built from the product's inputs with the DP-142 key so it joins to DP-142."),
            dict(name='Proposed Trade',
                 role='Dimension',
                 objects=[('24', 'Proposed Trade')],
                 pk=['Proposed Trade ID'],
                 note='DP-128 publishes proposed trades, but it is a consumer product; same registry key.'),
            dict(name='Portfolio Construction Constraint',
                 role='Dimension',
                 objects=[('24', 'Portfolio Construction Constraint')],
                 pk=['Constrained Portfolio', 'Constraint Type', 'Constraint Effective From'],
                 note='Read from DP-077 (a consumer product); same registry key.'),
            dict(name='Account',
                 role='Dimension',
                 conformed=('DP-093', 'Account'),
                 objects=[('15', 'Account')],
                 note='The SMA account.'),
            dict(name='Portfolio',
                 role='Dimension',
                 conformed=('DP-140', 'Portfolio'),
                 objects=[('18', 'Portfolio'), ('18', 'SMA Portfolio Detail')],
                 note='SMA Portfolio Detail folds in: tax-aware and loss harvesting flags.'),
            dict(name='Portfolio Implementation Link',
                 role='Dimension',
                 conformed=('DP-140', 'Portfolio Implementation Link'),
                 objects=[('18', 'Portfolio Implementation Link')],
                 note='Links the sleeve portfolio to its SMA account (Managed Account).'),
            dict(name='Distribution Agreement',
                 role='Dimension',
                 conformed=('DP-140', 'Distribution Agreement'),
                 objects=[],
                 note='The sponsor program agreement of the SMA.'),
            dict(name='Tax Lot',
                 role='Dimension',
                 conformed=('DP-142', 'Tax Lot'),
                 objects=[('18', 'Tax Lot')]),
            dict(name='Portfolio Transaction',
                 role='Dimension',
                 conformed=('DP-141', 'Portfolio Transaction'),
                 objects=[('18', 'Portfolio Transaction')]),
            dict(name='Portfolio Holding',
                 role='Dimension',
                 conformed=('DP-142', 'Portfolio Holding'),
                 objects=[('18', 'Portfolio Holding'), ('18', 'Holding Valuation')]),
            dict(name='Instrument',
                 role='Dimension',
                 conformed=('DP-097', 'Instrument'),
                 objects=[('17', 'Instrument')]),
            dict(name='Party',
                 role='Dimension',
                 conformed=('DP-093', 'Party'),
                 objects=[],
                 note='The client who instructed the budget or holds the restriction.'),
            dict(name='As-of Date',
                 role='Dimension',
                 conformed=('DP-013', 'Calendar Date'),
                 objects=[]),
            dict(name='Investment Restriction',
                 role='Dimension',
                 objects=[('01', 'Investment Restriction')],
                 pk=['Restriction ID']),
        ],
        relationships=[
            dict(child='Fact Tax Budget', parent='Portfolio', fk=['Budget Portfolio'], card='M:1'),
            dict(child='Fact Tax Budget', parent='Party', fk=['Budget Instructed By'], card='M:1', optional=True),
            dict(child='Fact Tax Budget', parent='As-of Date', fk=['As-of Date Key'], card='M:1', note='Borrowed: the snapshot date.'),
            dict(child='Fact Proposed Lot Selection', parent='Proposed Trade', fk=['Lot Selection Trade'], card='M:1'),
            dict(child='Fact Proposed Lot Selection', parent='Tax Lot', fk=['Selected Tax Lot'], card='M:1'),
            dict(child='Proposed Trade', parent='Portfolio', fk=['Proposed Trade Portfolio'], card='M:1'),
            dict(child='Proposed Trade', parent='Instrument', fk=['Proposed Trade Instrument'], card='M:1'),
            dict(child='Fact Rebalance Portfolio Result', parent='Portfolio', fk=['Result Portfolio'], card='M:1'),
            dict(child='Fact Lot Relief', parent='Tax Lot', fk=['Relieved Tax Lot'], card='M:1'),
            dict(child='Fact Lot Relief', parent='Portfolio Transaction', fk=['Closing Transaction'], card='M:1'),
            dict(child='Fact Lot Relief', parent='Tax Lot', fk=['Wash-Sale Replacement Lot'], card='M:1', optional=True),
            dict(child='Tax Lot', parent='Portfolio', fk=['Lot Portfolio'], card='M:1'),
            dict(child='Tax Lot', parent='Instrument', fk=['Lot Instrument'], card='M:1'),
            dict(child='Portfolio Transaction', parent='Portfolio', fk=['Transaction Portfolio'], card='M:1'),
            dict(child='Portfolio Transaction', parent='As-of Date', fk=['Trade Date'], card='M:1'),
            dict(child='Portfolio Holding', parent='Portfolio', fk=['Holding Portfolio'], card='M:1'),
            dict(child='Portfolio Holding', parent='Instrument', fk=['Held Instrument'], card='M:1'),
            dict(child='Portfolio Implementation Link', parent='Portfolio', fk=['Implementing Portfolio'], card='M:1'),
            dict(child='Portfolio Implementation Link', parent='Account', fk=['Managed Account'], card='M:1', optional=True),
            dict(child='Portfolio', parent='Distribution Agreement', fk=['Sponsor Program Agreement'], card='M:1', optional=True),
            dict(child='Portfolio Construction Constraint', parent='Portfolio', fk=['Constrained Portfolio'], card='M:1', optional=True),
            dict(child='Portfolio Construction Constraint', parent='Investment Restriction', fk=['Buffered Investment Restriction'], card='M:1', optional=True),
        ],
        notes="Tax-aware SMA star: the tax budget snapshot (account or sleeve x tax year x as-of date) holds the measures; lot selections of proposed trades, rebalance results and booked lot reliefs are companion facts. Lots, transactions, holdings, portfolios and accounts are conformed from DP-142, DP-141, DP-140 and DP-093; the sponsor program agreement from DP-140. Party is conformed from DP-093, the foundational account product upstream (DP-240 is not upstream). Model gap: the tax budget carries no as-of date; the fact borrows As-of Date Key. Proposed Trade and Client Restriction are the product's own dimensions because DP-128 and DP-077 are consumer products; Proposing Rebalance Run (24 Rebalance Run, DP-128) and Result Rebalance Run stay attributes, and the proposals reach the rebalance results through Portfolio. WP1 re-point (C-6, specs_w1c_inv_iop_fdn.py): renamed Institutional Separate Account Tax Management. The Client Restriction entity (02, read through the pending DP-077) is replaced by 24 Portfolio Construction Constraint, and 01 Investment Restriction is placed; the other entities keep their objects.",
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-131": dict(
        style="Star",
        entities=[
            fact("Fact ETF Basket", [("24", "ETF Basket"), ("24", "Custom Basket Approval")], ["Basket ID"],
                 grain="one row = ETF basket (share class x basket date x basket purpose x basket type)",
                 measures=True,
                 note="The basket header; Custom Basket Approval folds in (one approval per custom basket). The 29 AP "
                      "order references this Basket ID."),
            fact("Fact ETF Basket Constituent", [("24", "ETF Basket Constituent")],
                 ["Constituent Basket", "Constituent Instrument"],
                 grain="one row = basket x constituent instrument",
                 note="Quantity per Creation Unit and Cash in Lieu Indicator, the fields basket settlement lines "
                      "reference."),
            dim("Share Class", SHARE, [("01", "Share Class")], note="The ETF share class."),
            dim("Investment Product", PROD, [("01", "ETF Characteristics")],
                note="ETF Characteristics folds into the product: replication method, creation unit size and index "
                     "tracked."),
            dim("Benchmark", BMK097, note="The index tracked; DP-097 publishes Benchmark and is upstream (DP-144 is "
                                          "not)."),
            dim("Share Class NAV", SCNAV, [("27", "Share Class NAV")]),
            dim("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")]),
            dim("Portfolio", PORT),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")]),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Approved Price", APRICE, [("22", "Approved Price")]),
            dim("Basket Date", CAL),
        ],
        relationships=[
            rel("Fact ETF Basket", "Share Class", ["Basket Share Class"]),
            rel("Fact ETF Basket", "Portfolio", ["Basket Portfolio"], optional=True),
            rel("Fact ETF Basket", "Basket Date", ["Basket Date"]),
            rel("Fact ETF Basket Constituent", "Fact ETF Basket", ["Constituent Basket"]),
            rel("Fact ETF Basket Constituent", "Instrument", ["Constituent Instrument"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
            rel("Investment Product", "Benchmark", ["Index Tracked"], optional=True),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"],
                note="Single reference to the NAV calculation's composite key."),
            rel("Fund NAV Calculation", "Basket Date", ["Valuation Date"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Holding", "Basket Date", ["Holding Date"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
            rel("Approved Price", "Basket Date", ["Price Date"]),
        ],
        notes=("ETF basket star: header and constituent facts, compared with the fund's holdings (DP-142), approved "
               "prices (DP-143) and the NAV per creation unit (DP-165). "
               "External references: Basket Constructed By and Custom Basket Approver (20 Employee) stay attributes "
               "because DP-192 is not upstream; NAV Book (27 Fund Accounting Book) is not drawn because the book is "
               "not read beyond the NAV calculation key.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-132": dict(
        style="Star",
        entities=[
            fact("Fact Vote Instruction", [("34", "Vote Instruction")], ["Vote Instruction ID"],
                 grain="one row = vote instruction: ballot (meeting x safekeeping account) x agenda item",
                 measures=True),
            fact("Fact Ballot", [("34", "Ballot")],
                 ["Ballot Meeting", "Own Fund Proxy Campaign", "Ballot Safekeeping Account"],
                 grain="one row = ballot: investee meeting (or own fund proxy campaign) x safekeeping account",
                 note="Entitlement, shares on loan not recalled and ballot status, for coverage and unvoted ballots."),
            fact("Fact Vote Rationale", [("34", "Vote Rationale")], ["Rationale Agenda Item", "Rationale Voting Policy"],
                 grain="one row = agenda item x voting policy (vote rationale)",
                 note="Registry key also has Rationale Fund Proxy Proposal, which is not an input (see notes)."),
            fact("Fact Proxy Advisor Recommendation", [("34", "Proxy Advisor Recommendation")],
                 ["Recommended Agenda Item", "Proxy Advisor", "Advisor Policy"],
                 grain="one row = agenda item x proxy advisor x advisor policy",
                 note="For votes against the advisor recommendation and advisor reliance."),
            fact("Fact Lending Recall Decision", [("34", "Lending Recall Decision")],
                 ["Recall Meeting", "Recall Securities Loan"],
                 grain="one row = investee meeting x securities loan (recall decision)"),
            fact("Fact Proxy Voting Report", [("34", "Proxy Voting Report")], ["Proxy Voting Report ID"],
                 grain="one row = proxy voting report (Form N-PX or other report) per fund series, manager or client "
                       "account and period"),
            own("Investee Meeting Agenda Item", [("34", "Investee Meeting Agenda Item")],
                ["Agenda Meeting", "Agenda Item Number"]),
            own("Voting Policy", [("34", "Voting Policy")], ["Voting Policy ID"]),
            own("Voting Guideline", [("34", "Voting Guideline")], ["Guideline Policy", "Guideline Code"]),
            own("Voting Authority Arrangement", [("34", "Voting Authority Arrangement")],
                ["Authority Portfolio", "Authority Account", "Authority Effective From"],
                note="Who holds voting authority for a portfolio or client account and which policy applies."),
            dim("Investee Meeting", CAE, [("17", "Corporate Action Event")],
                note="Shareholder meetings are corporate action events (DP-099)."),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Issuer", ISSUER),
            dim("Safekeeping Account", SKA),
            dim("Safekeeping Account Assignment", SKAA, [("28", "Safekeeping Account Assignment")],
                note="Resolves the ballot's safekeeping account to the fund, portfolio or client account that owns "
                     "it."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding")], note="Record date positions for coverage."),
            dim("Investment Product", PROD, note="The fund series of the voting report."),
            dim("Account", ACCT, [("15", "Account")]),
            dim("Party", PARTY, [("02", "Party")],
                note="Proxy advisors, voting platform providers and policy clients."),
            dim("Employee", EMP, [("20", "Employee")]),
            dim("Internal Legal Entity", LE),
            dim("Geographic Unit", GEO, note="The market a voting guideline applies to."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Vote Instruction", "Fact Ballot", ["Voted Ballot"],
                note="Single reference to the ballot's composite key."),
            rel("Fact Vote Instruction", "Investee Meeting Agenda Item", ["Voted Agenda Item"],
                note="Single reference to the meeting x item number key."),
            rel("Fact Vote Instruction", "Fact Vote Rationale", ["Applied Vote Rationale"], optional=True),
            rel("Fact Vote Instruction", "Employee", ["Vote Decision Maker"], optional=True),
            rel("Fact Ballot", "Investee Meeting", ["Ballot Meeting"], optional=True,
                note="Null for own fund proxy campaign ballots."),
            rel("Fact Ballot", "Safekeeping Account", ["Ballot Safekeeping Account"]),
            rel("Fact Ballot", "Voting Authority Arrangement", ["Governing Voting Authority"], optional=True),
            rel("Fact Vote Rationale", "Investee Meeting Agenda Item", ["Rationale Agenda Item"]),
            rel("Fact Vote Rationale", "Voting Policy", ["Rationale Voting Policy"]),
            rel("Fact Vote Rationale", "Employee", ["Override Approved By"], optional=True),
            rel("Fact Proxy Advisor Recommendation", "Investee Meeting Agenda Item", ["Recommended Agenda Item"]),
            rel("Fact Proxy Advisor Recommendation", "Party", ["Proxy Advisor"]),
            rel("Fact Lending Recall Decision", "Investee Meeting", ["Recall Meeting"]),
            rel("Fact Lending Recall Decision", "Employee", ["Recall Decision Maker"], optional=True),
            rel("Fact Proxy Voting Report", "Investment Product", ["Reporting Fund Series"], optional=True),
            rel("Fact Proxy Voting Report", "Internal Legal Entity", ["Reporting Manager Entity"], optional=True),
            rel("Fact Proxy Voting Report", "Account", ["Reporting Client Account"], optional=True),
            rel("Investee Meeting Agenda Item", "Investee Meeting", ["Agenda Meeting"]),
            rel("Voting Guideline", "Voting Policy", ["Guideline Policy"]),
            rel("Voting Guideline", "Geographic Unit", ["Guideline Market"], optional=True),
            rel("Voting Policy", "Party", ["Benchmark Proxy Advisor"], optional=True),
            rel("Voting Policy", "Party", ["Policy Client"], optional=True),
            rel("Voting Authority Arrangement", "Portfolio", ["Authority Portfolio"], optional=True),
            rel("Voting Authority Arrangement", "Account", ["Authority Account"], optional=True),
            rel("Voting Authority Arrangement", "Voting Policy", ["Applied Voting Policy"], optional=True),
            rel("Voting Authority Arrangement", "Party", ["Voting Platform Provider"], optional=True),
            rel("Investee Meeting", "Instrument", ["Event Instrument"]),
            rel("Investee Meeting", "Calendar Date", ["Meeting Date"], optional=True),
            rel("Instrument", "Issuer", ["Issuer"]),
            rel("Safekeeping Account Assignment", "Safekeeping Account", ["Assigned Safekeeping Account"]),
            rel("Safekeeping Account Assignment", "Investment Product", ["Owning Fund"], optional=True),
            rel("Safekeeping Account Assignment", "Portfolio", ["Owning Portfolio"], optional=True),
            rel("Safekeeping Account Assignment", "Account", ["Owning Client Account"], optional=True),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
        ],
        notes=("Proxy voting star: the vote instruction holds the measures, with ballots, vote rationales, advisor "
               "recommendations, lending recall decisions and voting reports as companion facts. Meetings are "
               "conformed from DP-099 Corporate Action Event, issuers from DP-098, safekeeping accounts and their "
               "owners from DP-167, parties from DP-240. "
               "Model gap: 34 Vote Rationale's registry key includes Rationale Fund Proxy Proposal, which is not an "
               "input of DP-132, so rationales for own fund proxy proposals are not told apart from the agenda item "
               "rationale; the spec should add the attribute. "
               "External references (target product not upstream or downstream): Own Fund Proxy Campaign (13 Proxy "
               "Campaign), Ballot Entitlement (28 Corporate Action Entitlement), Recall Securities Loan (28 Securities "
               "Loan) and Linked Engagement (34 Engagement, DP-133 reads this product) stay attributes.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-133": dict(
        style="Star",
        entities=[
            fact("Fact Engagement", [("34", "Engagement")], ["Engagement ID", "As-of Date Key"],
                 grain="one row = engagement case x as-of date (weekly snapshot)",
                 measures=True,
                 note="Status and outcome per week; As-of Date Key is borrowed because the case carries no snapshot "
                      "date."),
            fact("Fact Engagement Objective", [("34", "Engagement Objective")],
                 ["Objective Engagement", "Objective Sequence"],
                 grain="one row = engagement x objective sequence"),
            fact("Fact Engagement Interaction", [("34", "Engagement Interaction")], ["Interaction ID"],
                 grain="one row = engagement interaction"),
            fact("Fact Escalation Action", [("34", "Escalation Action")],
                 ["Escalated Engagement", "Escalation Sequence"],
                 grain="one row = engagement x escalation sequence"),
            fact("Fact Reported Engagement", [("34", "Reported Engagement")],
                 ["Stewardship Report Key", "Reported Engagement Case"],
                 grain="one row = stewardship report x engagement reported",
                 note="Child group of the report (fold=False); its key is the report's key plus the engagement."),
            fact("Fact Initiative Membership", [("34", "Collaborative Initiative Membership")],
                 ["Membership Initiative", "Member Legal Entity", "Membership Effective From"],
                 grain="one row = collaborative initiative x legal entity x membership period"),
            fact("Fact Vote Instruction", [("34", "Vote Instruction")], ["Vote Instruction ID"],
                 grain="one row = vote instruction",
                 note="Votes against management linked to an engagement (escalation by voting); read from DP-132 with "
                      "its registry key."),
            own("Vote Rationale", [("34", "Vote Rationale")], ["Vote Rationale Key"], role="Bridge",
                grain="one row = vote rationale (agenda item x fund proxy proposal x voting policy)",
                note="Links votes to the engagement they escalate. Surrogate key: the registry key parts Rationale Fund "
                     "Proxy Proposal and Rationale Voting Policy are not inputs (see notes)."),
            own("Stewardship Report", [("34", "Stewardship Report")], ["Stewardship Report ID"]),
            own("Issuer Meeting", [("23", "Issuer Meeting")], ["Issuer Meeting ID"],
                note="Read from DP-121 (a consumer product) with its registry key."),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")]),
            dim("Party", PARTY, [("02", "Party")],
                note="Engaged parties that are not issuers and collaborative initiatives."),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")],
                note="Portfolios holding the engaged issuer."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Employee", EMP, note="Engagement lead, interaction employee and escalation approver."),
            dim("Internal Legal Entity", LE),
            dim("Investment Product", PROD, note="The product a stewardship report covers."),
            dim("As-of Date", CAL),
        ],
        relationships=[
            rel("Fact Engagement", "Party", ["Engaged Party"]),
            rel("Fact Engagement", "Employee", ["Engagement Lead"], optional=True),
            rel("Fact Engagement", "Party", ["Collaborative Initiative"], optional=True),
            rel("Fact Engagement", "As-of Date", ["As-of Date Key"], note="Borrowed: the weekly snapshot date."),
            rel("Fact Engagement Objective", "Fact Engagement", ["Objective Engagement"]),
            rel("Fact Engagement Interaction", "Fact Engagement", ["Interaction Engagement"]),
            rel("Fact Engagement Interaction", "Issuer Meeting", ["Interaction Issuer Meeting"], optional=True),
            rel("Fact Engagement Interaction", "Employee", ["Interaction Employee"], optional=True),
            rel("Fact Engagement Interaction", "Fact Engagement Objective", ["Discussed Objective"], optional=True,
                note="Single reference to the engagement x objective sequence key."),
            rel("Fact Engagement Interaction", "As-of Date", ["Interaction Date"]),
            rel("Fact Escalation Action", "Fact Engagement", ["Escalated Engagement"]),
            rel("Fact Escalation Action", "Employee", ["Escalation Approver"], optional=True),
            rel("Fact Reported Engagement", "Stewardship Report", ["Stewardship Report Key"]),
            rel("Fact Reported Engagement", "Fact Engagement", ["Reported Engagement Case"]),
            rel("Fact Initiative Membership", "Party", ["Membership Initiative"]),
            rel("Fact Initiative Membership", "Internal Legal Entity", ["Member Legal Entity"]),
            rel("Stewardship Report", "Internal Legal Entity", ["Stewardship Reporting Entity"]),
            rel("Stewardship Report", "Investment Product", ["Stewardship Report Product"], optional=True),
            rel("Fact Vote Instruction", "Vote Rationale", ["Applied Vote Rationale"], optional=True),
            rel("Vote Rationale", "Fact Engagement", ["Linked Engagement"], optional=True),
            rel("Issuer Meeting", "Issuer", ["Meeting Issuer"]),
            rel("Issuer", "Party", ["Issuer Party"], card="1:1",
                note="An engaged party that is an issuer resolves to its issuer profile."),
            rel("Instrument", "Issuer", ["Issuer"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
        ],
        notes=("Engagement star: the weekly engagement snapshot holds the measures, with objectives, interactions, "
               "escalations, reported engagements and initiative memberships as companion facts. "
               "Engaged parties are conformed from DP-240 Party and resolve to DP-098 Issuer, whose instruments and "
               "DP-142 holdings give the exposure behind each engagement. "
               "Model gap: the engagement carries no snapshot date; the fact borrows As-of Date Key. "
               "Model gap: 34 Vote Rationale's registry key parts Rationale Fund Proxy Proposal and Rationale Voting "
               "Policy are not inputs of DP-133, so the rationale gets a surrogate Vote Rationale Key; Applied Vote "
               "Rationale on the vote resolves to it. Vote Instruction and Vote Rationale are the product's own "
               "entities because DP-132 is a consumer product; Issuer Meeting likewise for DP-121. "
               "External references: Escalation Agenda Item and Rationale Agenda Item (34 Investee Meeting Agenda Item, "
               "DP-132) and Resulting Investment Decision (24 Investment Decision, DP-126, not upstream) stay "
               "attributes. "
               "W1b re-point (CW-934): Fact Signatory Status removed with the 34 Signatory Status object (no successor) "
               "and its three relationships; Stewardship Report keeps its links to the legal entity and product.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-134": dict(
        style="Star",
        entities=[
            fact("Fact Issuer ESG Standing", [], ["Issuer Key", "As-of Date Key"],
                 grain="one row = issuer x as-of date (daily): latest approved firm assessment, latest vendor rating per "
                       "source and type, current exclusion memberships",
                 measures=True,
                 note="The conformed ESG standing is derived from the companion facts, so it holds no input object; "
                      "its key is borrowed from Issuer and As-of Date."),
            fact("Fact Firm ESG Assessment", [("34", "Firm ESG Assessment")], ["ESG Assessment ID"],
                 grain="one row = firm ESG assessment of an issuer"),
            fact("Fact ESG Rating Observation", [("34", "ESG Rating Observation")],
                 ["Rated Issuer", "Rating Source Dataset", "ESG Rating Type", "Rating As-Of Date"],
                 grain="one row = issuer x source dataset x ESG rating type x as-of date"),
            fact("Fact Sustainability Observation", [("34", "Issuer Sustainability Observation")], ["Observation Key"],
                 grain="one row = issuer or instrument x indicator x period end x source dataset x as-of date",
                 note="Observation Key is the registry's surrogate."),
            fact("Fact Exclusion List Member", [("34", "Exclusion List Member")],
                 ["Member List", "Excluded Issuer", "Excluded Instrument", "Member Effective From"],
                 grain="one row = exclusion list version x member (issuer or instrument) x effective period"),
            own("Sustainability Indicator Definition", [("34", "Sustainability Indicator Definition")],
                ["Indicator Code", "Indicator Version"]),
            own("Sustainability Exclusion List", [("34", "Sustainability Exclusion List")],
                ["Exclusion List Code", "Exclusion List Version"]),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")]),
            dim("Instrument", INST, [("17", "Instrument")]),
            dim("Dataset", DATASET, [("14", "Dataset")], note="Source dataset and vendor of observations and ratings."),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")],
                note="Holding coverage: share of held market value with a standing."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Model", MODEL, [("37", "Model Inventory Entry")], note="The assessment methodology."),
            dim("Model Validation", MVAL, [("37", "Model Validation")]),
            dim("Investment Strategy", STRAT, note="Strategy scope of a firm assessment."),
            dim("Unit of Measure", UOM),
            dim("As-of Date", CAL),
        ],
        relationships=[
            rel("Fact Issuer ESG Standing", "Issuer", ["Issuer Key"], note="Borrowed: the issuer of the standing."),
            rel("Fact Issuer ESG Standing", "As-of Date", ["As-of Date Key"], note="Borrowed: the standing date."),
            rel("Fact Firm ESG Assessment", "Issuer", ["Assessed Issuer"]),
            rel("Fact Firm ESG Assessment", "Investment Strategy", ["Assessment Strategy"], optional=True),
            rel("Fact Firm ESG Assessment", "Model", ["Assessment Methodology Name"], optional=True,
                note="Single reference to the model x version key."),
            rel("Fact Firm ESG Assessment", "As-of Date", ["Assessment Date"]),
            rel("Fact ESG Rating Observation", "Issuer", ["Rated Issuer"]),
            rel("Fact ESG Rating Observation", "Dataset", ["Rating Source Dataset"]),
            rel("Fact ESG Rating Observation", "As-of Date", ["Rating As-Of Date"]),
            rel("Fact Sustainability Observation", "Issuer", ["Observed Issuer"], optional=True),
            rel("Fact Sustainability Observation", "Instrument", ["Observed Instrument"], optional=True),
            rel("Fact Sustainability Observation", "Sustainability Indicator Definition", ["Observed Indicator"],
                note="Single reference to the indicator code x version key."),
            rel("Fact Sustainability Observation", "Dataset", ["Observation Source Dataset"]),
            rel("Fact Exclusion List Member", "Sustainability Exclusion List", ["Member List"]),
            rel("Fact Exclusion List Member", "Issuer", ["Excluded Issuer"], optional=True),
            rel("Fact Exclusion List Member", "Instrument", ["Excluded Instrument"], optional=True),
            rel("Fact Exclusion List Member", "Fact Sustainability Observation", ["Supporting Observation"],
                optional=True),
            rel("Sustainability Indicator Definition", "Unit of Measure", ["Indicator Unit"], optional=True),
            rel("Instrument", "Issuer", ["Issuer"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Model Validation", "Model", ["Validated Model"]),
        ],
        notes=("ESG data star: the derived issuer standing per day holds the measures; firm assessments, vendor ratings, "
               "indicator observations and exclusion list members are companion "
               "facts at their own grains. Issuers come from DP-098, instruments and datasets from DP-097, holdings "
               "from DP-142, assessment models and validations from DP-212. "
               "Model gap: the standing has no input object (it is the product's derivation); its key borrows Issuer "
               "Key and As-of Date Key. "
               "External references: Dataset Vendor (14 Data Vendor) stays an attribute; DP-044 is a consumer product "
               "and publishes no conformed vendor dimension. "
               "W1b re-point (CW-934): Fact Sustainable Investment Determination removed with its 34 object (no "
               "successor) and its two relationships; Sustainability Indicator Definition loses the SFDR PAI Table and "
               "SFDR PAI Indicator Number columns.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-135": dict(
        style="Star",
        entities=[
            fact("Fact Portfolio Sustainability Metric", [("34", "Portfolio Sustainability Metric")],
                 ["Metric Portfolio", "Metric Product", "Metric Legal Entity", "Metric Period End Date",
                  "Metric Indicator", "Emission Scopes Included", "Metric Measurement Basis"],
                 grain="one row = portfolio, product or legal entity x period end x indicator x emission scopes x "
                       "measurement basis",
                 measures=True),
            fact("Fact Financed Emissions Holding", [("34", "Financed Emissions Holding Detail")],
                 ["Fact Portfolio Sustainability Metric Key", "Detail Holding"],
                 grain="one row = financed emissions metric x portfolio holding",
                 note="Child group of the metric (fold=False); its key is the metric's key plus the holding."),
            fact("Fact Climate Target", [("34", "Climate Target")], ["Climate Target Code"],
                 grain="one row = climate target"),
            own("Sustainability Indicator Definition", [("34", "Sustainability Indicator Definition")],
                ["Indicator Code", "Indicator Version"],
                note="DP-134 publishes indicator definitions but is a consumer product; same registry key. Input "
                     "Indicator links a derived indicator to its input."),
            dim("Investment Product", PROD, [("01", "Investment Product"), ("01", "ESG Classification")],
                note="ESG Classification folds into the product: ESG investment approach and the Rule 35d-1 name "
                     "flag, for ESG Products Without Metrics."),
            dim("Portfolio Implementation Link", PIL, [("18", "Portfolio Implementation Link")]),
            dim("Portfolio", PORT),
            dim("Portfolio Holding", HOLD, [("18", "Portfolio Holding"), ("18", "Holding Valuation")]),
            dim("Pricing Analytics Observation", PAO, [("22", "Pricing Analytics Observation")],
                note="EVIC and other attribution denominators."),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")]),
            dim("Instrument", INST098, note="Conformed through DP-098, which is upstream (DP-097 is not)."),
            dim("Model", MODEL, [("37", "Model Inventory Entry")], note="The calculation model."),
            dim("Internal Legal Entity", LE),
            dim("Unit of Measure", UOM),
            dim("Period End Date", CAL),
        ],
        relationships=[
            rel("Fact Portfolio Sustainability Metric", "Portfolio", ["Metric Portfolio"], optional=True),
            rel("Fact Portfolio Sustainability Metric", "Investment Product", ["Metric Product"], optional=True),
            rel("Fact Portfolio Sustainability Metric", "Internal Legal Entity", ["Metric Legal Entity"],
                optional=True),
            rel("Fact Portfolio Sustainability Metric", "Sustainability Indicator Definition", ["Metric Indicator"],
                note="Single reference to the indicator code x version key."),
            rel("Fact Portfolio Sustainability Metric", "Unit of Measure", ["Metric Unit"], optional=True),
            rel("Fact Portfolio Sustainability Metric", "Model", ["Metric Model Name"], optional=True),
            rel("Fact Portfolio Sustainability Metric", "Period End Date", ["Metric Period End Date"]),
            rel("Fact Financed Emissions Holding", "Fact Portfolio Sustainability Metric",
                ["Fact Portfolio Sustainability Metric Key"]),
            rel("Fact Financed Emissions Holding", "Portfolio Holding", ["Detail Holding"]),
            rel("Fact Financed Emissions Holding", "Issuer", ["Detail Issuer"], optional=True),
            rel("Fact Climate Target", "Internal Legal Entity", ["Target Legal Entity"], optional=True),
            rel("Fact Climate Target", "Portfolio", ["Target Portfolio"], optional=True),
            rel("Fact Climate Target", "Sustainability Indicator Definition", ["Target Indicator"], optional=True),
            rel("Fact Climate Target", "Fact Portfolio Sustainability Metric", ["Latest Progress Metric"],
                optional=True, note="Single reference to the metric's composite key."),
            rel("Sustainability Indicator Definition", "Sustainability Indicator Definition", ["Input Indicator"],
                optional=True),
            rel("Sustainability Indicator Definition", "Unit of Measure", ["Indicator Unit"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Pricing Analytics Observation", "Instrument", ["Analytics Instrument"]),
            rel("Issuer", "Instrument", ["Primary Equity Instrument"], optional=True),
        ],
        notes=("Sustainability metrics star: the portfolio, product or entity metric holds the measures, with its "
               "financed emissions holding detail and climate targets as companion "
               "facts. Holdings come from DP-142, analytics (EVIC) from DP-143, issuers and instruments from DP-098, "
               "products from DP-004 and calculation models from DP-212. "
               "Sustainability Indicator Definition is the product's own dimension because DP-134 is a consumer "
               "product. "
               "Model gap: the financed emissions detail is a child group with no attribute naming its metric; its key "
               "borrows Fact Portfolio Sustainability Metric Key. "
               "External references: Source Observation (34 Issuer Sustainability Observation, DP-134 consumer) stays "
               "an attribute. "
               "W1b re-point (CW-934): Fact PAI Calculation and Fact Product Sustainability Outcome removed with their "
               "34 objects (no successor) and their six relationships; the metric's link to the PAI statement goes with "
               "Reporting PAI Calculation. WP0 re-scope candidate (CW-041).")),
}
