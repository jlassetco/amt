"""Logical data models, Wave E8 (consumer): Star models for private markets (30; DP-136 to DP-139) and the product range
(36; DP-105 to DP-109). See CONTRACT.md. W4: 30 is retired (CW-930); DP-136 to DP-139 are thin residual stars until WP0
retires them, and the DP-116 and DP-117 conformed private fund entities are gone.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here (e.g.
  "Limited Partner", "Lender" and "Buyer" are all DP-240 Party). Product input objects of the same concept sit on the
  conformed entity and merge with its inherited attributes.
- Records a foundational product already publishes at the grain this product reads (DP-116 capital accounts and
  commitment changes, DP-117 calls and distributions, DP-145 returns and private markets measures, DP-143 fair values,
  DP-165 fund NAV, DP-007 positions and DP-008 measure values) are conformed Facts, so the numbers are the publisher's
  rows, never restated here.
- Objects another consumer product publishes (DP-160 investor measures, DP-126 committee decisions, DP-182 and DP-184
  board resolutions and filings, DP-069 shareholder communications, DP-181 TA control checks, DP-204 seed commitments,
  DP-234 projects, DP-030 fee studies, DP-035 profitability, DP-040 target market evidence) are this product's own
  entities: consumer models are not a conformed source.
- Date roles are conformed from DP-013 Calendar Date; a date attribute on a fact is its foreign key. Where the grain
  carries an as-of date no input attribute holds (daily or quarter-end snapshots), the fact borrows "Calendar Date Key".
- A reference whose target object is not an input of the product (and that no conformed dimension publishes) stays a
  degenerate attribute; the entity note names it.
"""


def F(name, objects, grain, pk=None, conformed=None, measures=False, note="", role="Fact"):
    d = dict(name=name, role=role, objects=list(objects), grain=grain, measures=measures, note=note)
    if pk:
        d["pk"] = list(pk)
    if conformed:
        d["conformed"] = conformed
    return d


def B(name, objects, grain, pk=None, conformed=None, note=""):
    return F(name, objects, grain, pk=pk, conformed=conformed, note=note, role="Bridge")


def E(name, objects, pk, note=""):
    """A dimension built from the product's own inputs (no foundational model publishes it)."""
    return dict(name=name, role="Dimension", objects=list(objects), pk=list(pk), note=note)


def D(name, src, objects=(), pk=None, note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    return d


def R(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources
PERFRET = ("DP-145", "Performance Return")
BMRET = ("DP-145", "Benchmark Return")
BENCH = ("DP-145", "Benchmark")
NAVCALC = ("DP-165", "Fund NAV Calculation")
BOOK = ("DP-165", "Fund Accounting Book")
PORT = ("DP-140", "Portfolio")
PIL = ("DP-140", "Portfolio Implementation Link")
FVD = ("DP-143", "Fair Value Determination")
INSTR = ("DP-097", "Instrument")
PARTY = ("DP-240", "Party")
DISTPARTY = ("DP-001", "Party")
INSTCLIENT = ("DP-003", "Institutional Client")
SAFEKEEP = ("DP-167", "Safekeeping Account")
EMP = ("DP-192", "Employee")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
STRAT = ("DP-004", "Investment Strategy")
MODEL = ("DP-004", "Model Portfolio")
CREG = ("DP-004", "Country Registration")
AGREE = ("DP-005", "Distribution Agreement")
SHELF = ("DP-005", "Shelf Placement")
PROGRAM = ("DP-005", "Partner Program")
MODELPLACE = ("DP-005", "Model Program Placement")
ACCT93 = ("DP-093", "Account")
APR = ("DP-093", "Account Party Role")
POSITION = ("DP-007", "Position")
MVAL = ("DP-008", "Measure Value")
RPER = ("DP-008", "Reporting Period")
FEEREV = ("DP-012", "Fee Revenue Record")
PEERU = ("DP-014", "Peer Universe")
METRIC = ("DP-101", "Metric Definition")
CAL = ("DP-013", "Calendar Date")
FISCAL = ("DP-013", "Fiscal Period")
COUNTRY = ("DP-013", "Country")
ILE = ("DP-013", "Internal Legal Entity")

MODELS = {
    # ==================================================================================================================
    # 30 Private Markets
    # ==================================================================================================================
    # DP-136 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-137 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-138 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-139 retired (model deleted by the WP1 lineage pass with its retired spec)
    # ==================================================================================================================
    # 36 Product Range
    # ==================================================================================================================
    "DP-105": dict(
        style="Star",
        entities=[
            # -- facts
            F("Fact Proposal As-Of", [], pk=["Product Proposal Key", "Calendar Date Key"], measures=True,
              grain="one row = product proposal x as-of date (current stage = the stage history row with no Stage "
                    "Exited Date)",
              note="Factless snapshot spine for the pipeline measures; both keys are borrowed because the grain is a "
                   "daily snapshot, not a source record."),
            F("Fact Proposal Stage History", [("36", "Proposal Stage History")],
              pk=["Stage Proposal", "Proposal Stage", "Stage Entered Date"],
              grain="one row = proposal x proposal stage x stage entered date"),
            F("Fact Business Case", [("36", "Product Business Case")],
              pk=["Business Case Proposal", "Business Case Version"],
              grain="one row = proposal x business case version",
              note="Projections only (CD-303)."),
            F("Fact Business Case Evidence", [("36", "Business Case Market Evidence")],
              pk=["Evidence Business Case", "Evidence Sequence"],
              grain="one row = business case version x evidence sequence",
              note="Evidence Fee Benchmark Study and Evidence Market Sizing Record (11) and Evidence Flow and Revenue "
                   "Forecast (10) are not inputs and stay degenerate keys; only the peer universe is a dimension "
                   "(DP-014). Evidence values are never copied (spec)."),
            F("Fact Product Approval Decision", [("36", "Product Approval Decision")],
              pk=["Product Approval Decision ID"],
              grain="one row = product approval decision (committee meeting x agenda item)"),
            # WP1 re-point (CW-203): realized assets read DP-008's certified Ending Client Assets (06 Client Asset Measures).
            F("Fact Realized AUM", [("06", "Measure Value"), ("06", "Client Asset Measures")], conformed=MVAL,
              grain="one row = DP-008 measure value (ending AUM) for a share class linked to a launch",
              note="Conformed from DP-008: realized attributed AUM for Realized vs Projected AUM %."),
            F("Fact Realized Fee Revenue", [("10", "Fee Revenue Record")], conformed=FEEREV,
              grain="one row = fee revenue record (share class x accounting period)",
              note="Conformed from DP-012: realized net fee revenue for Realized vs Projected Net Revenue %."),
            # -- bridges
            B("Changed Product Scope", [("36", "Changed Product Scope")],
              pk=["Scope Change Initiative", "Scope Product", "Scope Share Class", "Change Scope Role"],
              grain="one row = change initiative x product or share class in scope x scope role",
              note="Links a launch to the share classes whose realized AUM and revenue are compared with the "
                   "business case. Model gap: the registry key also holds Scope Model Portfolio, which is not an "
                   "input of this product."),
            B("Product Committee Membership", [("36", "Product Committee Membership")],
              pk=["Membership Committee", "Product Committee Member", "Product Committee Member Role",
                  "Membership Effective From"],
              grain="one row = committee x member x member role x effective period"),
            # -- dimensions
            E("Product Proposal", [("36", "Product Proposal")], ["Product Proposal ID"]),
            E("Product Governance Committee", [("36", "Product Governance Committee")], ["Product Committee Code"],
              note="A management committee, never a fund board (CD-237)."),
            E("Product Committee Meeting", [("36", "Product Committee Meeting")],
              ["Meeting Product Committee", "Product Committee Meeting Date", "Product Committee Meeting Sequence"]),
            E("Product Change Initiative", [("36", "Product Change Initiative")], ["Product Change Initiative ID"],
              note="The launch that a proposal became."),
            D("Share Class", SHARE),
            D("Investment Product", PROD),
            D("Proposed Strategy", STRAT),
            D("Peer Universe", PEERU, [("11", "Peer Universe")]),
            D("Proposal Sponsor", EMP, [("20", "Employee")]),
            D("Committee Member", EMP),
            D("Reporting Period", RPER),
            D("Fiscal Period", FISCAL),
            D("Calendar Date", CAL),
        ],
        relationships=[
            R("Fact Proposal As-Of", "Product Proposal", ["Product Proposal Key"]),
            R("Fact Proposal As-Of", "Calendar Date", ["Calendar Date Key"]),
            R("Product Proposal", "Proposal Sponsor", ["Proposal Sponsor"]),
            R("Product Proposal", "Proposed Strategy", ["Proposed Strategy"], optional=True),
            R("Fact Proposal Stage History", "Product Proposal", ["Stage Proposal"]),
            R("Fact Proposal Stage History", "Calendar Date", ["Stage Entered Date"]),
            R("Fact Business Case", "Product Proposal", ["Business Case Proposal"]),
            R("Fact Business Case Evidence", "Fact Business Case", ["Evidence Business Case"],
              note="Evidence Business Case carries the business case's proposal and version key."),
            R("Fact Business Case Evidence", "Peer Universe", ["Evidence Peer Universe"], optional=True),
            R("Product Governance Committee", "Product Governance Committee", ["Parent Product Committee"],
              optional=True, note="Committee hierarchy."),
            R("Product Committee Membership", "Product Governance Committee", ["Membership Committee"]),
            R("Product Committee Membership", "Committee Member", ["Product Committee Member"]),
            R("Product Committee Meeting", "Product Governance Committee", ["Meeting Product Committee"]),
            R("Product Committee Meeting", "Calendar Date", ["Product Committee Meeting Date"]),
            R("Fact Product Approval Decision", "Product Committee Meeting", ["Decision Meeting"]),
            R("Fact Product Approval Decision", "Product Proposal", ["Decision Subject Proposal"], optional=True),
            R("Product Change Initiative", "Product Proposal", ["Originating Proposal"], optional=True),
            R("Changed Product Scope", "Product Change Initiative", ["Scope Change Initiative"]),
            R("Changed Product Scope", "Investment Product", ["Scope Product"], optional=True),
            R("Changed Product Scope", "Share Class", ["Scope Share Class"], optional=True),
            R("Share Class", "Investment Product", ["Parent Product"]),
            R("Fact Realized AUM", "Share Class", ["Dimension Key"],
              note="Share class rows of the measure value (Dimension Type = Share Class; CW-906 replaced the Share Class column)."),
            R("Fact Realized AUM", "Reporting Period", ["Reporting Period"]),
            R("Fact Realized Fee Revenue", "Share Class", ["Revenue Share Class / Mandate"], optional=True),
            R("Fact Realized Fee Revenue", "Fiscal Period", ["Revenue Accounting Period"],
              note="Revenue Accounting Period carries the fiscal period code."),
        ],
        notes=("Product proposal pipeline star: a proposal snapshot spine with stage history, business cases and their "
               "market evidence, and the committee's approval decisions. Realized results reach a proposal only "
               "through its launch: proposal -> Product Change Initiative -> Changed Product Scope -> Share Class, "
               "where the conformed DP-008 measure values and DP-012 fee revenue records join. The 36 committee, "
               "meeting, membership and proposal objects have no foundational publisher and are own entities. Model "
               "gap: Changed Product Scope's registry key includes Scope Model Portfolio, not an input here. "
               "Degenerate evidence references (not inputs): Evidence Fee Benchmark Study, Evidence Market Sizing "
               "Record, Evidence Flow and Revenue Forecast."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-106": dict(
        style="Star",
        entities=[
            # -- facts
            F("Fact Change Requirement", [("36", "Change Regulatory Requirement")],
              pk=["Requirement Change Initiative", "Regulatory Requirement Type", "Requirement Product",
                  "Requirement Country"], measures=True,
              grain="one row = product change initiative x regulatory requirement (requirement type x requirement "
                    "product x requirement country)",
              note="The product grain; each requirement carries the evidence keys that satisfy it. Satisfying "
                   "Exemptive Relief (35 Exemptive Relief Reliance) is not an input and stays a degenerate key."),
            F("Fact Proposed Term Change", [("36", "Proposed Term Change")],
              pk=["Term Change Initiative", "Product Term Name", "Term Product", "Term Share Class"],
              grain="one row = change initiative x product term x product or share class",
              note="Model gap: the registry key also holds Term Model Portfolio, which is not an input. Proposed "
                   "Benchmark (01 Benchmark) has no conformed publisher upstream of DP-106 and stays degenerate."),
            F("Fact Share Class Specification", [("36", "Share Class Specification")],
              pk=["Specification Change Initiative", "Specification Product", "Proposed Class Designation"],
              grain="one row = change initiative x product x proposed class designation"),
            F("Fact Communication Distribution", [("13", "Communication Distribution")],
              pk=["Fact Communication Distribution Key"],
              grain="one row = distribution job of a shareholder communication",
              note="Read through DP-069 (consumer). Model gap: Distribution Job ID is not an input of this product, "
                   "so the fact takes a surrogate key."),
            # -- bridges
            B("Changed Product Scope", [("36", "Changed Product Scope")],
              pk=["Scope Change Initiative", "Scope Product", "Scope Share Class", "Scope Model Portfolio",
                  "Change Scope Role"],
              grain="one row = change initiative x product, share class or model portfolio x scope role"),
            B("Resolution Subject Link", [("35", "Resolution Subject Link")], pk=["Resolution Subject Link Key"],
              grain="one row = board resolution x subject (product or change initiative)",
              note="Surrogate key, as in the registry. Read through DP-182 (consumer)."),
            B("Project Scope Link", [("41", "Project Scope Link")],
              pk=["Scoping Project", "Delivered Change Initiative", "Scope Link Effective From"],
              grain="one row = project x delivered change initiative x effective period",
              note="Read through DP-234 (consumer). Model gap: the registry key also holds Delivered Object Type and "
                   "the other delivered-object references, which are not inputs; only change initiative links are "
                   "read here."),
            # -- dimensions
            E("Product Change Initiative", [("36", "Product Change Initiative")], ["Product Change Initiative ID"],
              note="Originating Proposal (36 Product Proposal) is not an input here and stays degenerate."),
            E("Regulatory Filing", [("35", "Fund Regulatory Filing")], ["Regulatory Filing ID"],
              note="Read through DP-184 (consumer)."),
            E("Board Resolution", [("35", "Board Resolution")], ["Board Resolution ID"],
              note="Read through DP-182 (consumer)."),
            E("Shareholder Communication", [("13", "Shareholder Communication"), ("13", "Shareholder Notice")],
              ["Communication ID"], note="Read through DP-069 (consumer); the notice group folds in."),
            E("Proxy Proposal", [("13", "Proxy Proposal")], ["Proposal ID"], note="Read through DP-069 (consumer)."),
            E("Project", [("41", "Project")], ["Project ID"], note="Read through DP-234 (consumer)."),
            D("Share Class", SHARE, [("01", "Share Class")]),
            D("Successor Share Class", SHARE),
            D("Investment Product", PROD),
            D("Model Portfolio", MODEL),
            D("Change Sponsor", EMP),
            D("Project Manager", EMP),
            D("Requirement Country", COUNTRY),
            D("Calendar Date", CAL),
        ],
        relationships=[
            R("Fact Change Requirement", "Product Change Initiative", ["Requirement Change Initiative"]),
            R("Fact Change Requirement", "Investment Product", ["Requirement Product"], optional=True),
            R("Fact Change Requirement", "Requirement Country", ["Requirement Country"], optional=True,
              note="ISO alpha-2 code."),
            R("Fact Change Requirement", "Regulatory Filing", ["Satisfying Filing"], optional=True),
            R("Fact Change Requirement", "Shareholder Communication", ["Satisfying Shareholder Communication"],
              optional=True),
            R("Fact Change Requirement", "Proxy Proposal", ["Satisfying Proxy Proposal"], optional=True),
            R("Fact Change Requirement", "Calendar Date", ["Requirement Due Date"]),
            R("Product Change Initiative", "Change Sponsor", ["Change Sponsor"], optional=True),
            R("Product Change Initiative", "Calendar Date", ["Planned Effective Date"], optional=True),
            R("Changed Product Scope", "Product Change Initiative", ["Scope Change Initiative"]),
            R("Changed Product Scope", "Investment Product", ["Scope Product"], optional=True),
            R("Changed Product Scope", "Share Class", ["Scope Share Class"], optional=True),
            R("Changed Product Scope", "Model Portfolio", ["Scope Model Portfolio"], optional=True),
            R("Changed Product Scope", "Successor Share Class", ["Mapped Successor Share Class"], optional=True),
            R("Fact Proposed Term Change", "Product Change Initiative", ["Term Change Initiative"]),
            R("Fact Proposed Term Change", "Investment Product", ["Term Product"], optional=True),
            R("Fact Proposed Term Change", "Share Class", ["Term Share Class"], optional=True),
            R("Fact Share Class Specification", "Product Change Initiative", ["Specification Change Initiative"]),
            R("Fact Share Class Specification", "Investment Product", ["Specification Product"]),
            R("Fact Share Class Specification", "Share Class", ["Created Share Class"], optional=True,
              note="Filled once the class is set up in 01; New Classes Not Set Up reads the empty rows."),
            R("Regulatory Filing", "Investment Product", ["Filer Product"]),
            R("Resolution Subject Link", "Board Resolution", ["Linked Resolution"]),
            R("Resolution Subject Link", "Product Change Initiative", ["Subject Change Initiative"], optional=True),
            R("Resolution Subject Link", "Investment Product", ["Subject Product"], optional=True),
            R("Fact Communication Distribution", "Shareholder Communication", ["Distributed Communication"]),
            R("Fact Communication Distribution", "Calendar Date", ["Mail Date"]),
            R("Shareholder Communication", "Share Class", ["Covered Share Classes"], card="M:N",
              note="Multi-valued: one row per covered share class after the build explodes the list."),
            R("Project Scope Link", "Project", ["Scoping Project"]),
            R("Project Scope Link", "Product Change Initiative", ["Delivered Change Initiative"]),
            R("Project", "Project Manager", ["Project Manager"], optional=True),
            R("Share Class", "Investment Product", ["Parent Product"]),
            R("Successor Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Change calendar star at change initiative x regulatory requirement. The five evidence groups hang off "
               "the requirement fact: filings (DP-184), board resolutions through Resolution Subject Link (DP-182), "
               "shareholder communications and proxies (DP-069), and regulator approval held on the row. Those, and "
               "the DP-234 project objects, come from consumer products and are this model's own entities. Products, "
               "share classes and model portfolios are conformed from DP-004 and employees from DP-192. Model gaps: "
               "Communication Distribution has no Distribution Job ID input (surrogate key); Proposed Term Change and "
               "Project Scope Link registry keys include attributes that are not inputs. Degenerate references (not "
               "inputs): Satisfying Exemptive Relief, Proposed Benchmark, Originating Proposal."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-107": dict(
        style="Star",
        entities=[
            # -- facts
            F("Fact Readiness Check", [("36", "Readiness Check")],
              pk=["Check Readiness Plan", "Readiness Workstream", "Readiness Check Name", "Calendar Date Key"],
              measures=True,
              grain="one row = readiness plan version x readiness workstream x readiness check x as-of date (daily)",
              note="The product grain, snapshotted daily, so the as-of date is a borrowed key. Evidence references "
                   "point to the set-up records conformed below. Evidence Pricing Policy, Evidence Index Use and "
                   "Evidence Rule Coding Request are checked for presence only (spec) and stay degenerate; Evidence "
                   "Listing (01 Listing) and Evidence Product Document (01 Product Document) have no publisher "
                   "upstream of DP-107 and stay degenerate."),
            F("Fact Product Approval Decision", [("36", "Product Approval Decision")],
              pk=["Product Approval Decision ID"],
              grain="one row = product approval decision (the go / no-go on a change initiative)"),
            F("Fact Seed Capital Commitment", [("43", "Seed Capital Commitment")], pk=["Seed Capital Commitment ID"],
              grain="one row = seed capital commitment",
              note="Read through DP-204 (consumer; 43 is the only seed master, CD-276)."),
            F("Fact TA Control Check", [("29", "TA Control Check")], pk=["TA Control Check ID"],
              grain="one row = TA control check (control type x share class x business date)",
              note="Read through DP-181 (consumer)."),
            F("Fact Fund NAV", [("27", "Fund NAV Calculation")], conformed=NAVCALC,
              grain="one row = accounting book x valuation date x calculation source x version",
              note="Conformed from DP-165: the first NAV of record against the planned first NAV date."),
            # -- bridges
            B("Changed Product Scope", [("36", "Changed Product Scope")],
              pk=["Scope Change Initiative", "Scope Product", "Scope Share Class", "Change Scope Role"],
              grain="one row = change initiative x product or share class in scope x scope role",
              note="Model gap: the registry key also holds Scope Model Portfolio, which is not an input here."),
            # -- dimensions
            E("Readiness Plan", [("36", "Product Readiness Plan")],
              ["Readiness Change Initiative", "Readiness Plan Version"]),
            E("Product Change Initiative", [("36", "Product Change Initiative")], ["Product Change Initiative ID"]),
            E("Product Committee Meeting", [("36", "Product Committee Meeting")],
              ["Meeting Product Committee", "Product Committee Meeting Date"],
              note="Model gap: Product Committee Meeting Sequence (part of the registry key) is not an input, so two "
                   "meetings of one committee on one day are not told apart."),
            D("Fund Accounting Book", BOOK, [("27", "Fund Accounting Book")]),
            D("Safekeeping Account", SAFEKEEP, [("28", "Safekeeping Account")]),
            D("Seed Portfolio", PORT, [("18", "Portfolio")]),
            D("Share Class", SHARE),
            D("Investment Product", PROD),
            D("Distribution Agreement", AGREE),
            D("Shelf Placement", SHELF),
            D("Partner Program", PROGRAM),
            D("Model Program Placement", MODELPLACE,
              pk=["Partner Program Key", "Placed Model Portfolio", "Model Placement Effective From"]),
            D("Plan Owner", EMP, [("20", "Employee")]),
            D("Check Owner", EMP),
            D("Calendar Date", CAL),
        ],
        relationships=[
            R("Fact Readiness Check", "Readiness Plan", ["Check Readiness Plan"],
              note="Check Readiness Plan carries the plan's change initiative and version key."),
            R("Fact Readiness Check", "Calendar Date", ["Calendar Date Key"], note="The as-of date."),
            R("Fact Readiness Check", "Check Owner", ["Readiness Check Owner"], optional=True),
            R("Fact Readiness Check", "Fund Accounting Book", ["Evidence Fund Accounting Book"], optional=True),
            R("Fact Readiness Check", "Safekeeping Account", ["Evidence Safekeeping Account"], optional=True),
            R("Fact Readiness Check", "Fact TA Control Check", ["Evidence TA Control Check"], optional=True),
            R("Fact Readiness Check", "Distribution Agreement", ["Evidence Distribution Agreement"], optional=True),
            R("Fact Readiness Check", "Shelf Placement", ["Evidence Shelf Placement"], optional=True),
            R("Fact Readiness Check", "Model Program Placement", ["Evidence Model Program Placement"], optional=True),
            R("Readiness Plan", "Product Change Initiative", ["Readiness Change Initiative"]),
            R("Readiness Plan", "Seed Portfolio", ["Seed Portfolio"], optional=True),
            R("Readiness Plan", "Plan Owner", ["Readiness Plan Owner"], optional=True),
            R("Changed Product Scope", "Product Change Initiative", ["Scope Change Initiative"]),
            R("Changed Product Scope", "Investment Product", ["Scope Product"], optional=True),
            R("Changed Product Scope", "Share Class", ["Scope Share Class"], optional=True),
            R("Fact Product Approval Decision", "Product Change Initiative", ["Decision Subject Change Initiative"],
              optional=True, note="The go / no-go is a decision on the change; the plan holds no link to it (spec)."),
            R("Fact Product Approval Decision", "Product Committee Meeting", ["Decision Meeting"]),
            R("Product Committee Meeting", "Calendar Date", ["Product Committee Meeting Date"]),
            R("Fact Seed Capital Commitment", "Product Change Initiative", ["Launch Change Initiative"], optional=True,
              note="Seed readiness is measured from 43 by the change key (spec)."),
            R("Fact Seed Capital Commitment", "Investment Product", ["Seeded Product"]),
            R("Fact Seed Capital Commitment", "Share Class", ["Seeded Share Class"], optional=True),
            R("Fact Seed Capital Commitment", "Seed Portfolio", ["Seed Book"], optional=True),
            R("Fact TA Control Check", "Share Class", ["Control Share Class"]),
            R("Fact TA Control Check", "Calendar Date", ["Control Business Date"]),
            R("Fact Fund NAV", "Fund Accounting Book", ["NAV Book"]),
            R("Fact Fund NAV", "Calendar Date", ["Valuation Date"]),
            R("Fund Accounting Book", "Investment Product", ["Book Fund"]),
            R("Share Class", "Investment Product", ["Parent Product"]),
            R("Model Program Placement", "Partner Program", ["Partner Program Key"]),
        ],
        notes=("Launch readiness star at plan version x workstream x check x as-of date. Each check references the "
               "set-up record that evidences it; those records are conformed from their foundational publishers "
               "(fund accounting book and NAV from DP-165, safekeeping accounts from DP-167, seed portfolio from "
               "DP-140, agreements, shelf and model placements from DP-005), and the "
               "consumer-published TA control checks (DP-181) and seed commitments (DP-204) are own facts. The go / "
               "no-go joins the change initiative, not the plan. Model gaps: Changed Product Scope and Product "
               "Committee Meeting registry keys include attributes that are not inputs. Degenerate references (not "
               "inputs or no upstream publisher): Evidence Pricing Policy, Evidence Index Use, Evidence Rule Coding "
               "Request, Evidence Listing, Evidence Product Document. "
               "W1 (CW-901): 01 Country Registration is removed from the wealth 01, so the conformed Country "
               "Registration dimension (DP-004) and its link go. W4 (CW-936): Evidence Country Registration is dropped from "
               "36 and the spec; state notice filing evidence is a 35 Fund Regulatory Filing."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-108": dict(
        style="Star",
        entities=[
            # -- facts
            F("Fact Change Scope", [("36", "Changed Product Scope")],
              pk=["Scope Change Initiative", "Scope Product", "Scope Share Class", "Change Scope Role",
                  "Calendar Date Key"], measures=True,
              grain="one row = change initiative x scope item (product or share class x scope role, with its mapped "
                    "successor) x as-of date",
              note="The product grain, snapshotted by as-of date (borrowed key). Model gap: the registry key also "
                   "holds Scope Model Portfolio, which is not an input here."),
            F("Fact Change Impact Assessment", [("36", "Change Impact Assessment")],
              pk=["Impact Change Initiative", "Impact Area"],
              grain="one row = change initiative x impact area",
              note="Liquidity Evidence Profile (31 Fund Liquidity Profile) is checked for presence only and stays "
                   "degenerate. Model gap: Impact Assessed By references 20 Employee, but 20 Employee is not an input "
                   "and DP-192 is not upstream of DP-108."),
            # WP1 re-point (CW-203): DP-008 publishes Ending Client Assets by share class and channel; the 06 Distributor
            # Hierarchy (distributor firm split) left DP-008, so the firm relationship is dropped.
            F("Fact Attributed AUM", [("06", "Measure Value"), ("06", "Client Asset Measures"), ("06", "Market & Client Dimensions")],
              conformed=MVAL,
              grain="one row = DP-008 measure value (Ending Client Assets) by share class and distribution channel",
              note="Conformed from DP-008: attributed AUM by intermediary, never computed here (CD-292, CD-303)."),
            F("Fact Position", [("06", "Fund Shareholder Position")], conformed=POSITION,
              grain="one row = position of an account in a share class on a valuation date",
              note="Conformed from DP-007; 06 Position is re-typed by name to Fund Shareholder Position (CW-151). Accounts "
                   "affected are counted, never published by holder."),
            F("Fact Fund NAV", [("27", "Fund NAV Calculation")], conformed=NAVCALC,
              grain="one row = accounting book x valuation date x calculation source x version",
              note="Conformed from DP-165: affected fund net assets."),
            # -- dimensions
            E("Product Change Initiative",
              [("36", "Product Change Initiative"), ("36", "Fund Reorganization Detail"),
               ("36", "ETF Conversion Detail"), ("36", "Liquidation Detail")],
              ["Product Change Initiative ID"],
              note="The reorganization, ETF conversion and liquidation details fold in (one row per change)."),
            D("Share Class", SHARE, [("01", "Share Class")]),
            D("Successor Share Class", SHARE),
            D("Investment Product", PROD),
            D("Account", ACCT93, [("15", "Account")]),
            D("Fund Accounting Book", BOOK, [("27", "Fund Accounting Book")]),
            D("Shelf Placement", SHELF, [("05", "Shelf Placement")]),
            # WP1 re-point (CW-202): DP-001 now models the 05 Distributor Firm profile the shelf partner references.
            D("Distributor Firm", ("DP-001", "Distributor Firm"),
              note="Conformed from DP-001 Distributor Firm (05); the shelf partner."),
            D("Reporting Period", RPER),
            D("Calendar Date", CAL),
        ],
        relationships=[
            R("Fact Change Scope", "Product Change Initiative", ["Scope Change Initiative"]),
            R("Fact Change Scope", "Investment Product", ["Scope Product"], optional=True),
            R("Fact Change Scope", "Share Class", ["Scope Share Class"], optional=True),
            R("Fact Change Scope", "Successor Share Class", ["Mapped Successor Share Class"], optional=True),
            R("Fact Change Scope", "Calendar Date", ["Calendar Date Key"], note="The as-of date."),
            R("Fact Change Impact Assessment", "Product Change Initiative", ["Impact Change Initiative"]),
            R("Fact Attributed AUM", "Share Class", ["Dimension Key"],
              note="Share class rows of the measure value (Dimension Type = Share Class; CW-906)."),
            R("Fact Attributed AUM", "Reporting Period", ["Reporting Period"]),
            R("Fact Position", "Account", ["Account"]),
            R("Fact Position", "Share Class", ["Share Class"]),
            R("Fact Position", "Calendar Date", ["Valuation Date"]),
            R("Fact Fund NAV", "Fund Accounting Book", ["NAV Book"]),
            R("Fact Fund NAV", "Calendar Date", ["Valuation Date"]),
            R("Fund Accounting Book", "Investment Product", ["Book Fund"]),
            R("Shelf Placement", "Share Class", ["Placed Share Class"]),
            R("Shelf Placement", "Distributor Firm", ["Shelf Partner"]),
            R("Share Class", "Investment Product", ["Parent Product"]),
            R("Successor Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Reorganization and liquidation impact star at change x scope item x as-of date, with the impact "
               "assessment as a sibling fact on the change. Scope items reach the affected AUM (DP-008, by "
               "distributor firm), positions and accounts (DP-007, DP-093), fund net assets (DP-165) and partner "
               "platforms (DP-005 shelf placements) through the conformed Share Class and Investment Product, so no "
               "figure is recomputed. The type-specific details fold into the change initiative. Model gaps: Scope "
               "Model Portfolio is not an input (Changed Product Scope key); Impact Assessed By has no Employee input "
               "and DP-192 is not upstream. Degenerate reference: Liquidity Evidence Profile."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-109": dict(
        # WP1 re-point (CW-220): re-cut to the specs_w1c_cla_b.py DP-109 inputs; see notes.
        style='Star',
        entities=[
            dict(name='Fact Criterion Result',
                 role='Fact',
                 objects=[('36', 'Product Review Criterion Result')],
                 pk=['Criterion Review', 'Product Review Criterion', 'Criterion Share Class'],
                 measures=True,
                 grain='one row = product review x product review criterion x share class (or the reviewed subject)',
                 note='The product grain; each result references the certified evidence it rests on.'),
            dict(name='Fact Review Action',
                 role='Fact',
                 objects=[('36', 'Review Action')],
                 pk=['Action Review', 'Review Action Sequence'],
                 grain='one row = product review x action sequence'),
            dict(name='Fact Performance Return',
                 role='Fact',
                 conformed=('DP-145', 'Performance Return'),
                 objects=[('32', 'Performance Return')],
                 grain='one row = performance return x version',
                 note='Conformed from DP-145 (CD-217, CD-320).'),
            dict(name='Fact Benchmark Return',
                 role='Fact',
                 conformed=('DP-145', 'Benchmark Return'),
                 objects=[('32', 'Benchmark Return')],
                 grain='one row = benchmark x period x return type x currency x hedged basis x version',
                 note='Conformed from DP-145.'),
            dict(name='Fact Fee Benchmark Study',
                 role='Fact',
                 objects=[('11', 'Fee Benchmark Study'), ('11', 'Fee Benchmark Result')],
                 pk=['Fee Study ID'],
                 grain='one row = fee benchmark study of a share class',
                 note='Read through DP-030 (consumer); the result folds into its study.'),
            dict(name='Fact Profitability',
                 role='Fact',
                 objects=[('10', 'Profitability Record'), ('10', 'Profitability Measure')],
                 pk=['Profitability Record ID'],
                 grain='one row = profitability record (product or share class x period x data version)',
                 note='Read through DP-035 (consumer); the measures fold into the record.'),
            dict(name='Fact Net Flows',
                 role='Fact',
                 conformed=('DP-008', 'Measure Value'),
                 objects=[('06', 'Measure Value'), ('06', 'Flow Measures')],
                 grain='one row = DP-008 measure value (net flows) by share class and reporting period',
                 note='Conformed from DP-008.'),
            dict(name='Product Review',
                 role='Dimension',
                 objects=[('36', 'Product Review')],
                 pk=['Product Review ID'],
                 note='Review Report Document (01 Product Document) and Review Service Offering (01) are not modeled dimensions and stay degenerate.'),
            dict(name='Product Change Initiative',
                 role='Dimension',
                 objects=[('36', 'Product Change Initiative')],
                 pk=['Product Change Initiative ID']),
            dict(name='Share Class',
                 role='Dimension',
                 conformed=('DP-004', 'Share Class'),
                 objects=[('01', 'Share Class')]),
            dict(name='Investment Product',
                 role='Dimension',
                 conformed=('DP-004', 'Investment Product'),
                 objects=[]),
            dict(name='Model Portfolio',
                 role='Dimension',
                 conformed=('DP-004', 'Model Portfolio'),
                 objects=[]),
            dict(name='Benchmark',
                 role='Dimension',
                 conformed=('DP-145', 'Benchmark'),
                 objects=[],
                 note='Conformed from DP-145, which publishes Benchmark (upstream).'),
            dict(name='Metric Definition',
                 role='Dimension',
                 conformed=('DP-101', 'Metric Definition'),
                 objects=[('21', 'Metric Definition')]),
            dict(name='Review Approver',
                 role='Dimension',
                 conformed=('DP-192', 'Employee'),
                 objects=[]),
            dict(name='Action Owner',
                 role='Dimension',
                 conformed=('DP-192', 'Employee'),
                 objects=[]),
            dict(name='Reporting Period',
                 role='Dimension',
                 conformed=('DP-008', 'Reporting Period'),
                 objects=[]),
            dict(name='Calendar Date',
                 role='Dimension',
                 conformed=('DP-013', 'Calendar Date'),
                 objects=[]),
            dict(name='Product Governance',
                 role='Dimension',
                 objects=[('01', 'Product Governance')],
                 pk=['Product Governance Key']),
            dict(name='Service Offering',
                 role='Dimension',
                 conformed=('DP-004', 'Service Offering'),
                 objects=[]),
            dict(name='Internal Legal Entity',
                 role='Dimension',
                 conformed=('DP-013', 'Internal Legal Entity'),
                 objects=[]),
        ],
        relationships=[
            dict(child='Fact Criterion Result', parent='Product Review', fk=['Criterion Review'], card='M:1'),
            dict(child='Fact Criterion Result', parent='Share Class', fk=['Criterion Share Class'], card='M:1'),
            dict(child='Fact Criterion Result', parent='Fact Performance Return', fk=['Performance Evidence Return'], card='M:1', optional=True),
            dict(child='Fact Criterion Result', parent='Fact Benchmark Return', fk=['Benchmark Evidence Return'], card='M:1', optional=True),
            dict(child='Fact Criterion Result', parent='Fact Fee Benchmark Study', fk=['Fee Evidence Study'], card='M:1', optional=True),
            dict(child='Fact Criterion Result', parent='Fact Profitability', fk=['Cost Evidence Profitability Record'], card='M:1', optional=True),
            dict(child='Fact Criterion Result', parent='Metric Definition', fk=['Evidence Metric Definition'], card='M:1', optional=True),
            dict(child='Fact Review Action', parent='Product Review', fk=['Action Review'], card='M:1'),
            dict(child='Fact Review Action', parent='Share Class', fk=['Action Share Class'], card='M:1', optional=True),
            dict(child='Fact Review Action', parent='Action Owner', fk=['Review Action Owner'], card='M:1', optional=True),
            dict(child='Fact Review Action', parent='Product Change Initiative', fk=['Resulting Change Initiative'], card='M:1', optional=True, note='Actions Converted to Change % reads the filled rows.'),
            dict(child='Fact Review Action', parent='Calendar Date', fk=['Review Action Due Date'], card='M:1'),
            dict(child='Product Review', parent='Investment Product', fk=['Review Product'], card='M:1', optional=True),
            dict(child='Product Review', parent='Share Class', fk=['Review Share Class'], card='M:1', optional=True),
            dict(child='Product Review', parent='Model Portfolio', fk=['Review Model Portfolio'], card='M:1', optional=True),
            dict(child='Product Review', parent='Review Approver', fk=['Review Approver'], card='M:1', optional=True),
            dict(child='Product Review', parent='Calendar Date', fk=['Next Review Due Date'], card='M:1', optional=True),
            dict(child='Fact Performance Return', parent='Share Class', fk=['Return Share Class'], card='M:1'),
            dict(child='Fact Performance Return', parent='Calendar Date', fk=['Return Period End Date'], card='M:1'),
            dict(child='Fact Benchmark Return', parent='Benchmark', fk=['Return Benchmark'], card='M:1'),
            dict(child='Fact Fee Benchmark Study', parent='Share Class', fk=['Subject Share Class'], card='M:1'),
            dict(child='Fact Profitability', parent='Share Class', fk=['Product / Share Class'], card='M:1'),
            dict(child='Fact Net Flows', parent='Share Class', fk=['Dimension Key'], card='M:1', note='Share class rows of the measure value (Dimension Type = Share Class; CW-906).'),
            dict(child='Fact Net Flows', parent='Reporting Period', fk=['Reporting Period'], card='M:1'),
            dict(child='Share Class', parent='Investment Product', fk=['Parent Product'], card='M:1'),
            dict(child='Fact Criterion Result', parent='Fact Net Flows', fk=['Flow Evidence Measure Value'], card='M:1', optional=True),
            dict(child='Fact Fee Benchmark Study', parent='Service Offering', fk=['Subject Service Offering'], card='M:1', optional=True),
            dict(child='Product Review', parent='Service Offering', fk=['Review Service Offering'], card='M:1', optional=True),
            dict(child='Product Governance', parent='Internal Legal Entity', fk=['Governing Body'], card='M:1', optional=True),
            dict(child='Internal Legal Entity', parent='Fact Criterion Result', fk=['Fact Criterion Result Key'], card='M:1', optional=True, note='Model gap: no input attribute of Internal Legal Entity carries its link to Fact Criterion Result; the placeholder key stands for the lineage join.'),
        ],
        notes="W4 re-point (CW-161, CW-170, CW-936): Fact Criterion Result reads 36 Product Review Criterion Result (key Criterion Review x Product Review Criterion x Criterion Share Class); Fact Sales Against Target Market, Fact Outcome Metric (08, CW-067), the Comparable Share Class role and the folded Target Market Review Result are removed with their relationships; Peer Evidence Universe (11), Flow Evidence Measure Value (06) and Complaint Evidence Count are degenerate evidence columns. WP0 re-scope candidate ('Product Reviews & Criterion Results'). Product review star at review x criterion x share class. Each criterion result points to the evidence it rests on: returns and benchmark returns conformed from DP-145, net flows from DP-008, metric definitions from DP-101, and the consumer-published fee studies (DP-030) and profitability (DP-035) as own facts; none is recalculated. Review actions join the change initiatives they lead to. Degenerate references (not inputs): Review Report Document, Review Service Offering. WP1 re-point (CW-220): re-cut to the WP1 re-spec in specs_w1c_cla_b.py. Entities whose objects left the inputs are dropped, the objects added by the re-spec are placed as facts and dimensions keyed by the registry, and references to accounts, parties, share classes, products, portfolios and legal entities conform the upstream masters (DP-093, DP-240, DP-004, DP-140, DP-013) where the spec lists them. Where no input attribute carries a link, a placeholder key joins the entity to the main fact (Model gap).",
    ),
}
