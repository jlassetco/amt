"""Logical data models (Wave E8, consumer): Star models for DP-118 to DP-121 (23 Investment Research) and DP-122 to
DP-125 (25 Trading & Execution). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here. Product
  input objects of the same concept sit on the conformed dimension and merge with its inherited attributes.
- Facts and bridges are built from the product's own inputs, not conformed, and keep the registry's natural keys, so
  they still join to the foundational entities (DP-142 holdings, DP-098 agency ratings, DP-115 counterparty reviews).
  The one exception is a foundational entity whose registry key holds attributes the product does not read (DP-140
  Portfolio Implementation Link, DP-212 Model Validation, DP-141 Portfolio Transaction): conforming it carries the full
  key.
- Trading products downstream of DP-123 (DP-122, DP-124, DP-125) rebuild the order, block, placement, execution and
  allocation entities from their own inputs rather than conforming DP-123, which is consumer-aligned (CD-314); the keys
  are the same, so the rows join. Investment Decision and Proposed Trade (24) are read through DP-126 and DP-128, which
  are consumer-aligned, so they are dimensions built from the input.
- Date roles are conformed from DP-013 Calendar Date on the firm business calendar, so a date attribute on a fact is
  the foreign key (a timestamp joins on its date part).
- A reference attribute that carries the parent's identifier is the foreign key even where the parent's registry key
  is composite (for example Execution Placement to Broker Placement), as in the foundational models.
"""


def dim(name, src, objects=(), note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


INSTR = ("DP-097", "Instrument")
ISSUER = ("DP-098", "Issuer")
SCHEME = ("DP-098", "Classification Scheme")
CPTY = ("DP-115", "Counterparty")
PORT = ("DP-140", "Portfolio")
PIL = ("DP-140", "Portfolio Implementation Link")
PRICE = ("DP-143", "Approved Price")
EMP = ("DP-192", "Employee")
ORG = ("DP-192", "Org Unit")
PROD = ("DP-004", "Investment Product")
STRAT = ("DP-004", "Investment Strategy")
ACCT = ("DP-093", "Account")
LE = ("DP-013", "Internal Legal Entity")
GEO = ("DP-013", "Geographic Unit")
CAL = ("DP-013", "Calendar Date")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-118": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Research Recommendation", role="Fact",
                 objects=[("23", "Research Recommendation"), ("23", "Recommendation Valuation Basis")],
                 pk=["Research Recommendation ID"], measures=True,
                 grain="one row = research recommendation (subject x recommending analyst x rating scale x "
                       "recommendation timestamp)",
                 note="Holds the measures: the product's current recommendation view (subject x analyst x rating "
                      "scale x as-of date) is the latest approved row per subject, scale and analyst at each daily "
                      "snapshot, so it is derived from this fact rather than stored as a second one. Recommendation "
                      "Valuation Basis folds here (one per recommendation). Valuation Model points to 23 Research "
                      "Model, which is not an input here, so it stays a descriptive column."),
            dict(name="Fact Coverage Assignment", role="Fact", objects=[("23", "Research Coverage Assignment")],
                 pk=["Research Coverage Assignment ID"],
                 grain="one row = coverage assignment (analyst x coverage subject x coverage role x effective period)",
                 note="Effective-dated; held-issuer coverage and orphaned coverage read the rows effective on the "
                      "as-of date."),
            dict(name="Fact Research Publication", role="Fact",
                 objects=[("23", "Research Publication"), ("23", "Publication Review")],
                 pk=["Research Publication ID", "Publication Version"],
                 grain="one row = research publication x version",
                 note="Publication Review folds here (one review per version). Released As Commentary and Released "
                      "As Content Asset are hand-off keys to 01 and 04 that no upstream product publishes, so they "
                      "are descriptive columns."),
            dict(name="Fact Universe Membership", role="Fact", objects=[("23", "Research Universe Member")],
                 pk=["Member Universe", "Member Subject Type", "Member Issuer", "Member Instrument",
                     "Member Sector Scheme", "Member Sector Code", "Member Geography", "Membership Effective From"],
                 grain="one row = research universe x member subject x membership effective period",
                 note="Model gap: the registry key also has Member Market Segment, which is not an input, so two "
                      "rates-market members of the same universe and period would collide."),
            dict(name="Fact Holding", role="Fact",
                 objects=[("18", "Portfolio Holding"), ("18", "Holding Valuation")], pk=["Holding ID"],
                 grain="one row = portfolio x instrument x holding date x holding view (DP-142 holding)",
                 note="Built from the input with the DP-142 key; only the official Holding View feeds the coverage "
                      "measures. Holding Valuation folds here. IBOR market value, not AUM."),
            # -- bridges
            dict(name="Publication Subject", role="Bridge", objects=[("23", "Publication Subject")],
                 pk=["Subject Publication", "Publication Subject Type", "Subject Issuer", "Subject Instrument",
                     "Subject Sector Code"],
                 grain="one row = research publication x subject",
                 note="A publication covers many issuers and an issuer appears in many publications. Model gap: the "
                      "registry key also has Subject Sector Scheme, Subject Geography and Subject Theme, which are "
                      "not inputs, so geography and theme subjects of one publication collapse; Subject Publication "
                      "carries the publication ID only, so the subject list applies to every version."),
            dict(name="Issuer Sector", role="Bridge", conformed=("DP-098", "Issuer Classification Assignment"),
                 objects=[("17", "Issuer Classification Assignment")],
                 grain="one row = issuer x classification scheme x sector code x effective period",
                 note="Sector rollup of issuers for sector coverage views; the primary scheme is flagged by Primary "
                      "Sector Scheme Indicator."),
            # -- dimensions
            dim("Research Subject Issuer", ISSUER, [("17", "Issuer Profile")],
                note="Covered, recommended, member and publication-subject issuer; also the issuer of each held "
                     "instrument."),
            dim("Instrument", INSTR, [("17", "Instrument")],
                note="Covered, recommended and held instrument; Issuer rolls holdings up to issuers."),
            dim("Approved Price", PRICE, [("22", "Approved Price")],
                note="Reference price of each recommendation, and the price at the primary pricing point for "
                     "Price Target Upside % and Recommendation Return Since Issue."),
            dim("Sector Scheme", SCHEME, note="Scheme of covered, recommended and member sector codes."),
            dim("Geography", GEO, [("09", "Geographic Unit")]),
            dim("Analyst", EMP, [("20", "Employee")],
                note="Covering analyst, recommending analyst, lead author and universe owner (one role-playing "
                     "dimension); Employment Status drives Orphaned Coverage Count."),
            dim("Supervisory Reviewer", EMP, note="The reviewer of an externally released publication; kept apart "
                                                  "from Analyst so the reviewer-is-not-author rule reads two roles."),
            dim("Research Team", ORG, note="Covering research team and the analysts' home org unit."),
            dim("Served Investment Strategy", STRAT, [("01", "Investment Strategy")]),
            dict(name="Research Universe", role="Dimension", objects=[("23", "Research Universe")],
                 pk=["Research Universe Code"],
                 note="Built from the input: no foundational model publishes research universes."),
            dim("Portfolio", PORT, [("18", "Portfolio")],
                note="Holding portfolio; Business Line and Portfolio Status (active) scope the coverage ratios."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Research Recommendation", "Analyst", ["Recommending Analyst"]),
            rel("Fact Research Recommendation", "Research Subject Issuer", ["Recommended Issuer"]),
            rel("Fact Research Recommendation", "Instrument", ["Recommended Instrument"], optional=True),
            rel("Fact Research Recommendation", "Sector Scheme", ["Recommended Sector Scheme"], optional=True),
            rel("Fact Research Recommendation", "Geography", ["Recommended Geography"], optional=True),
            rel("Fact Research Recommendation", "Fact Coverage Assignment", ["Source Coverage Assignment"],
                optional=True, note="The team view takes the recommendation whose source assignment is Primary "
                                    "Analyst."),
            rel("Fact Research Recommendation", "Fact Research Recommendation", ["Previous Recommendation"],
                optional=True, note="Chain of recommendation changes for the same subject, analyst and scale."),
            rel("Fact Research Recommendation", "Fact Research Publication", ["Announcing Publication"], optional=True,
                note="Carries the publication ID; the version is the one published at the recommendation timestamp."),
            rel("Fact Research Recommendation", "Approved Price", ["Reference Approved Price"], optional=True),
            rel("Fact Research Recommendation", "Calendar Date", ["Recommendation Timestamp"]),
            rel("Fact Coverage Assignment", "Analyst", ["Covering Analyst"]),
            rel("Fact Coverage Assignment", "Research Subject Issuer", ["Covered Issuer"]),
            rel("Fact Coverage Assignment", "Instrument", ["Covered Instrument"], optional=True),
            rel("Fact Coverage Assignment", "Sector Scheme", ["Covered Sector Scheme"], optional=True),
            rel("Fact Coverage Assignment", "Geography", ["Covered Geography"], optional=True),
            rel("Fact Coverage Assignment", "Research Team", ["Covering Research Team"], optional=True),
            rel("Fact Coverage Assignment", "Served Investment Strategy", ["Served Investment Strategy"],
                optional=True),
            rel("Fact Coverage Assignment", "Calendar Date", ["Coverage Effective From"]),
            rel("Fact Research Publication", "Analyst", ["Lead Author"]),
            rel("Fact Research Publication", "Supervisory Reviewer", ["Supervisory Reviewer"], optional=True),
            rel("Fact Research Publication", "Calendar Date", ["Publication Timestamp"]),
            rel("Publication Subject", "Fact Research Publication", ["Subject Publication"]),
            rel("Publication Subject", "Research Subject Issuer", ["Subject Issuer"]),
            rel("Publication Subject", "Instrument", ["Subject Instrument"], optional=True),
            rel("Fact Universe Membership", "Research Universe", ["Member Universe"]),
            rel("Fact Universe Membership", "Research Subject Issuer", ["Member Issuer"]),
            rel("Fact Universe Membership", "Instrument", ["Member Instrument"], optional=True),
            rel("Fact Universe Membership", "Sector Scheme", ["Member Sector Scheme"], optional=True),
            rel("Fact Universe Membership", "Geography", ["Member Geography"], optional=True),
            rel("Research Universe", "Analyst", ["Universe Owner"], optional=True),
            rel("Fact Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Fact Holding", "Instrument", ["Held Instrument"]),
            rel("Fact Holding", "Calendar Date", ["Holding Date"]),
            rel("Instrument", "Research Subject Issuer", ["Issuer"],
                note="The path from holdings to issuers for held-issuer coverage."),
            rel("Issuer Sector", "Research Subject Issuer", ["Classified Issuer"]),
            rel("Issuer Sector", "Sector Scheme", ["Issuer Classification Scheme"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
            rel("Approved Price", "Calendar Date", ["Price Date"]),
            rel("Analyst", "Research Team", ["Home Org Unit"], optional=True),
        ],
        notes="Research view around the recommendation fact, with coverage, publications, universe membership and "
              "DP-142 holdings as linked facts that meet at Research Subject Issuer and Instrument. Held-issuer "
              "coverage goes Holding -> Instrument -> Issuer, then to coverage effective on the holding date. "
              "Return and upside measures are product measures from DP-143 approved prices (CD-217). The approved "
              "pricing point is a descriptive column (22 Pricing Point is not an input). "
              "Model gap: Research Universe Member's key needs Member Market Segment and Publication Subject's key "
              "needs Subject Sector Scheme, Subject Geography and Subject Theme, none of them inputs. "
              "Conformed: Research Subject Issuer, Issuer Sector, Sector Scheme (DP-098); Instrument (DP-097); "
              "Approved Price (DP-143); Analyst, Supervisory Reviewer, Research Team (DP-192); Served Investment "
              "Strategy (DP-004); Portfolio (DP-140); Geography, Calendar Date (DP-013).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-119": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Internal Credit Assessment", role="Fact", objects=[("23", "Internal Credit Assessment")],
                 pk=["Assessed Party", "Assessed Instrument", "Credit Analyst", "Internal Credit Rating Scale",
                     "Assessment Effective From"], measures=True,
                 grain="one row = assessed party or instrument x credit analyst x internal credit rating scale x "
                       "effective period",
                 note="The product grain; holds the measures. The current determination on each date is the "
                      "approved row whose effective period spans it. Keyed by its grain because 23 gives the "
                      "assessment no identifier (spec taxonomy gap)."),
            dict(name="Fact Agency Rating", role="Fact", objects=[("17", "Credit Rating Assignment")],
                 pk=["Rated Instrument", "Rated Issuer", "Credit Rating Agency", "Credit Rating Type",
                     "Credit Rating Action Date"],
                 grain="one row = rated instrument or issuer x agency x rating type x action date",
                 note="Agency ratings stay 17 and are read as DP-098 publishes them (CD-173), with the DP-098 key, "
                      "for divergence and downgrades since the last assessment."),
            dict(name="Fact Holding", role="Fact",
                 objects=[("18", "Portfolio Holding"), ("18", "Holding Valuation")], pk=["Holding ID"],
                 grain="one row = portfolio x instrument x holding date x holding view (DP-142 holding)",
                 note="Dependent holdings: money market fund holdings with or without a current determination. "
                      "Holding Valuation folds here."),
            dict(name="Fact Counterparty Review", role="Fact", objects=[("25", "Counterparty Review")],
                 pk=["Reviewed Counterparty", "Counterparty Review Date"],
                 grain="one row = counterparty x review date",
                 note="Credit View holds the assessment key (CD-315); read for Approved Counterparties Without "
                      "Current Credit View."),
            # -- bridges
            dict(name="Portfolio Implementation Link", role="Bridge", conformed=PIL,
                 objects=[("18", "Portfolio Implementation Link")],
                 grain="one row = portfolio x implemented product / mandate / account / model x link type x "
                       "effective period",
                 note="Conformed so the DP-140 key (link type, mandate, account and model columns) is carried; "
                      "finds the money market fund portfolios through the implemented product."),
            # -- dimensions
            dim("Assessed Issuer", ISSUER, [("17", "Issuer Profile")],
                note="Issuer side of an assessment, and the rated issuer of agency ratings."),
            dim("Assessed Counterparty", CPTY, [("25", "Approved Counterparty Profile")],
                note="Trading counterparty side of an assessment; Counterparty Approval Status scopes the "
                     "credit-view measure."),
            dim("Instrument", INSTR, [("17", "Instrument"), ("17", "Debt Terms")],
                note="Debt Terms folds here; Maturity Date only drops matured instruments."),
            dim("Regulatory Instrument Classification", ("DP-097", "Regulatory Instrument Classification"),
                [("17", "Regulatory Instrument Classification")],
                note="Effective-dated Rule 2a-7 eligibility per instrument."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Investment Product", PROD, [("01", "Investment Product"), ("01", "Regulatory Classification")],
                note="Regulatory Classification folds here and adds Money Market Fund Type, which DP-004 does not "
                     "yet publish (read from 01 per the spec)."),
            dim("Internal Rating Code", ("DP-013", "Code Value"), [("09", "Code Value")],
                note="Internal credit rating code values; the agency-equivalent notch for the divergence measure "
                     "sits on these code values (spec taxonomy gap)."),
            dim("Credit Analyst", EMP, [("20", "Employee")]),
            dim("Assessment Approver", EMP, note="Approver role, kept apart from the analyst."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Internal Credit Assessment", "Assessed Issuer", ["Assessed Party"], optional=True,
                note="Assessed Party is an issuer or a trading counterparty; it resolves to one of the two "
                     "dimensions (both keyed by Party ID)."),
            rel("Fact Internal Credit Assessment", "Assessed Counterparty", ["Assessed Party"], optional=True),
            rel("Fact Internal Credit Assessment", "Instrument", ["Assessed Instrument"], optional=True),
            rel("Fact Internal Credit Assessment", "Credit Analyst", ["Credit Analyst"]),
            rel("Fact Internal Credit Assessment", "Assessment Approver", ["Assessment Approved By"], optional=True),
            rel("Fact Internal Credit Assessment", "Internal Rating Code",
                ["Internal Credit Rating Scale", "Internal Credit Rating"],
                note="The rating scale names the code list and the rating is the code."),
            rel("Fact Internal Credit Assessment", "Calendar Date", ["Assessment Effective From"]),
            rel("Fact Agency Rating", "Instrument", ["Rated Instrument"], optional=True),
            rel("Fact Agency Rating", "Assessed Issuer", ["Rated Issuer"], optional=True),
            rel("Fact Agency Rating", "Calendar Date", ["Credit Rating Action Date"]),
            rel("Fact Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Fact Holding", "Instrument", ["Held Instrument"]),
            rel("Fact Holding", "Calendar Date", ["Holding Date"]),
            rel("Fact Counterparty Review", "Assessed Counterparty", ["Reviewed Counterparty"]),
            rel("Fact Counterparty Review", "Fact Internal Credit Assessment", ["Credit View"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Regulatory Instrument Classification", "Instrument", ["Regulatory Classified Instrument"]),
            rel("Instrument", "Assessed Issuer", ["Issuer"]),
        ],
        notes="Credit determination star: the assessment fact meets agency ratings at Instrument and Assessed "
              "Issuer, and dependent money market fund holdings through Instrument (Holding -> Instrument <- "
              "Assessment) and Portfolio -> Portfolio Implementation Link -> Investment Product (Money Market Fund "
              "Type). The 2a-7 tests and breaches are 33 (CD-221, CD-222); this product supplies the determination. "
              "Conformed: Assessed Issuer (DP-098); Assessed Counterparty (DP-115); Instrument, Regulatory "
              "Instrument Classification (DP-097); Portfolio, Portfolio Implementation Link (DP-140); Investment "
              "Product (DP-004); Credit Analyst, Assessment Approver (DP-192); Internal Rating Code, Calendar Date "
              "(DP-013).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-120": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Analyst Estimate", role="Fact", objects=[("23", "Analyst Estimate")],
                 pk=["Estimated Issuer", "Estimating Analyst", "Estimate Metric", "Fiscal Period Type",
                     "Fiscal Period End Date", "Adjusted Basis Indicator", "Estimate Date"], measures=True,
                 grain="one row = issuer x analyst x estimate metric x fiscal period x basis x estimate date",
                 note="Holds the measures; revisions compare an estimate with the previous estimate date for the "
                      "same issuer, analyst, metric, period and basis."),
            dict(name="Fact Economic Forecast", role="Fact", objects=[("23", "Economic Forecast")],
                 pk=["Forecast Geography", "Economic Indicator", "Forecast Period Type", "Forecast Period End Date",
                     "Forecast Date"],
                 grain="one row = geography x economic indicator x forecast period x forecast date"),
            dict(name="Fact Signal Score", role="Fact", objects=[("23", "Research Signal Score")],
                 pk=["Scored Signal", "Scored Instrument", "Score As-Of Date"],
                 grain="one row = research signal version x instrument x as-of date",
                 note="Scored Signal carries the signal code; the version is the one effective on the score date."),
            dict(name="Fact Coverage Assignment", role="Fact", objects=[("23", "Research Coverage Assignment")],
                 pk=["Research Coverage Assignment ID"],
                 grain="one row = coverage assignment (analyst x subject x coverage role x effective period)",
                 note="Read only for Covered Issuers Without Current Estimate."),
            # -- dimensions
            dict(name="Research Model", role="Dimension", objects=[("23", "Research Model")],
                 pk=["Research Model Key", "Research Model Version"],
                 note="Built from the input: no foundational model publishes research models; the 37 inventory "
                      "entry it points to is the conformed Model."),
            dict(name="Research Signal", role="Dimension", objects=[("23", "Research Signal Definition")],
                 pk=["Research Signal Code", "Research Signal Version"],
                 note="Built from the input. Signal Universe and Related AI Use Case point to objects that are not "
                      "inputs (spec taxonomy gap: Signal Universe is free text), so they are descriptive columns."),
            dim("Model", ("DP-212", "Model"), [("37", "Model Inventory Entry")],
                note="The 37 model inventory entry of a research model or signal (CD-246, CD-294)."),
            dim("Model Tier Assignment", ("DP-212", "Model Tier Assignment"), [("37", "Model Tier Assignment")],
                note="Effective-dated tier outrigger of Model."),
            dim("Model Validation", ("DP-212", "Model Validation"), [("37", "Model Validation")],
                note="Validation outrigger of Model, conformed so it carries Model Validation Sequence, the second "
                     "part of the DP-212 key, which is not an input."),
            dim("Dataset", ("DP-097", "Dataset"), [("14", "Dataset")],
                note="Primary input dataset of a signal. Conformed from DP-097 (upstream and foundational) rather "
                     "than DP-044, which is consumer-aligned; the license terms stay with DP-044."),
            dict(name="Permitted Use Grant", role="Dimension", objects=[("14", "Permitted Use Grant")],
                 pk=["Grant Dataset", "Permitted Use Category", "Grant Effective From"],
                 note="Outrigger of Dataset for Signals on Unlicensed Data. Model gap: the registry key also has "
                      "Grant Agreement, which is not an input, so grants of the same use under two agreements "
                      "collide."),
            dim("Issuer", ISSUER, [("17", "Issuer Profile")]),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Forecast Geography", GEO, [("09", "Geographic Unit")]),
            dim("Employee", EMP, [("20", "Employee")],
                note="Estimating analyst, economist, model author, signal owner, covering analyst and model owner "
                     "(one role-playing dimension)."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Analyst Estimate", "Issuer", ["Estimated Issuer"]),
            rel("Fact Analyst Estimate", "Employee", ["Estimating Analyst"], optional=True),
            rel("Fact Analyst Estimate", "Research Model", ["Source Research Model"], optional=True,
                note="Carries the model key; the version is the one current on the estimate date."),
            rel("Fact Analyst Estimate", "Calendar Date", ["Estimate Date"]),
            rel("Fact Economic Forecast", "Forecast Geography", ["Forecast Geography"]),
            rel("Fact Economic Forecast", "Employee", ["Forecasting Economist"], optional=True),
            rel("Fact Economic Forecast", "Calendar Date", ["Forecast Date"]),
            rel("Fact Signal Score", "Research Signal", ["Scored Signal"]),
            rel("Fact Signal Score", "Instrument", ["Scored Instrument"]),
            rel("Fact Signal Score", "Calendar Date", ["Score As-Of Date"]),
            rel("Fact Coverage Assignment", "Issuer", ["Covered Issuer"]),
            rel("Fact Coverage Assignment", "Employee", ["Covering Analyst"]),
            rel("Research Model", "Issuer", ["Modeled Issuer"], optional=True),
            rel("Research Model", "Employee", ["Model Author"], optional=True),
            rel("Research Model", "Model", ["Model Inventory Entry"], optional=True,
                note="Empty for a candidate not yet inventoried (Research Models Missing From Model Inventory)."),
            rel("Research Signal", "Model", ["Model Inventory Entry"], optional=True),
            rel("Research Signal", "Dataset", ["Primary Input Dataset"], optional=True),
            rel("Research Signal", "Employee", ["Signal Owner"], optional=True),
            rel("Model", "Employee", ["Model Owner"]),
            rel("Model Tier Assignment", "Model", ["Tiered Model"]),
            rel("Model Validation", "Model", ["Validated Model"]),
            rel("Permitted Use Grant", "Dataset", ["Grant Dataset"]),
            rel("Instrument", "Issuer", ["Issuer"]),
        ],
        notes="Estimates, forecasts and signal scores as separate facts sharing Issuer, Instrument, Employee and "
              "Calendar Date; research models and signals reach the 37 inventory through the conformed Model. "
              "Model gap: Permitted Use Grant has no Grant Agreement input (part of its key). "
              "Conformed: Issuer (DP-098); Instrument, Dataset (DP-097); Model, Model Tier Assignment, Model "
              "Validation (DP-212); Employee (DP-192); Forecast Geography, Calendar Date (DP-013).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-121": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Meeting Participant", role="Fact", objects=[("23", "Issuer Meeting Participant")],
                 pk=["Participant Meeting", "Internal Participant", "External Participant",
                     "Meeting Participant Role"],
                 grain="one row = issuer meeting x participant x participant role (the product grain)",
                 note="Wall-crossing consent and timestamp are matched to insider list entries."),
            dict(name="Fact Issuer Meeting", role="Fact",
                 objects=[("23", "Issuer Meeting"), ("23", "Meeting MNPI Assessment")],
                 pk=["Issuer Meeting ID"], measures=True,
                 grain="one row = issuer meeting",
                 note="Holds the measures, which count meetings and lags per meeting rather than participants. "
                      "Meeting MNPI Assessment folds here (one per meeting)."),
            dict(name="Fact Meeting Topic", role="Fact", objects=[("23", "Issuer Meeting Topic")],
                 pk=["Topic Meeting", "Topic Sequence"], grain="one row = issuer meeting x topic sequence"),
            dict(name="Fact MNPI Escalation", role="Fact", objects=[("38", "MNPI Escalation")],
                 pk=["MNPI Escalation ID"], grain="one row = MNPI escalation",
                 note="Read from 38 as the master because no foundational product publishes it (spec)."),
            dict(name="Fact Insider List Entry", role="Fact", objects=[("38", "Insider List Entry")],
                 pk=["Insider List", "Insider Escalation", "Internal Insider", "External Insider",
                     "Access Obtained Timestamp"],
                 grain="one row = insider list x escalation section x person x access obtained timestamp"),
            dict(name="Fact Restricted List Entry", role="Fact", objects=[("38", "Restricted List Entry")],
                 pk=["Restricted List Entry ID"], grain="one row = restricted list entry (list x issuer x added "
                                                         "timestamp)",
                 note="Restricted Instruments is multi-valued and stays a column: no instrument dimension is "
                      "upstream here (DP-097 is not read), and the restriction is issuer-level."),
            # -- dimensions
            dict(name="Restricted List", role="Dimension", objects=[("38", "Firm Restricted List")],
                 pk=["Restricted List Code"],
                 note="Built from the input: no foundational model publishes 38 lists."),
            dim("Meeting Issuer", ISSUER, [("17", "Issuer Profile")],
                note="Meeting issuer, MNPI issuer and restricted issuer."),
            dim("External Party", ("DP-240", "Party"), [("02", "Party")],
                note="External participant, external insider and arranging (corporate access) provider."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Internal participant, internal insider and MNPI decision maker."),
            dim("Org Unit", ORG, note="Home org unit of internal participants."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Meeting Participant", "Fact Issuer Meeting", ["Participant Meeting"]),
            rel("Fact Meeting Participant", "Employee", ["Internal Participant"]),
            rel("Fact Meeting Participant", "External Party", ["External Participant"], optional=True),
            rel("Fact Issuer Meeting", "Meeting Issuer", ["Meeting Issuer"]),
            rel("Fact Issuer Meeting", "External Party", ["Arranging Provider"], optional=True),
            rel("Fact Issuer Meeting", "Fact MNPI Escalation", ["MNPI Escalation Reference"], optional=True,
                note="Empty where MNPI was received but not escalated (MNPI Meetings Not Escalated)."),
            rel("Fact Issuer Meeting", "Calendar Date", ["Meeting Start Timestamp"]),
            rel("Fact Meeting Topic", "Fact Issuer Meeting", ["Topic Meeting"]),
            rel("Fact MNPI Escalation", "Fact Issuer Meeting", ["Source Issuer Meeting"], optional=True,
                note="The 38 side of the meeting link; escalations from deals or engagements have no meeting."),
            rel("Fact MNPI Escalation", "Meeting Issuer", ["MNPI Issuer"], optional=True),
            rel("Fact MNPI Escalation", "Employee", ["MNPI Decided By"], optional=True),
            rel("Fact Insider List Entry", "Restricted List", ["Insider List"]),
            rel("Fact Insider List Entry", "Fact MNPI Escalation", ["Insider Escalation"], optional=True),
            rel("Fact Insider List Entry", "Employee", ["Internal Insider"], optional=True),
            rel("Fact Insider List Entry", "External Party", ["External Insider"], optional=True),
            rel("Fact Restricted List Entry", "Restricted List", ["Entry List"]),
            rel("Fact Restricted List Entry", "Meeting Issuer", ["Restricted Issuer"]),
            rel("Fact Restricted List Entry", "Fact MNPI Escalation", ["Source MNPI Escalation"], optional=True),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
        ],
        notes="Meeting-to-restriction chain: meeting and participants (23) -> MNPI escalation -> insider list and "
              "restricted list entries (38), each a fact at its own grain joined by the escalation key. Restricted "
              "- MNPI. Conformed: Meeting Issuer (DP-098); External Party (DP-240); Employee, Org Unit (DP-192); "
              "Calendar Date (DP-013).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-122": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Commission Allocation", role="Fact",
                 objects=[("25", "Trade Allocation"), ("25", "Allocation Cost Detail")],
                 pk=["Trade Allocation ID"], measures=True,
                 grain="one row = trade allocation (DP-123 allocation with its cost detail)",
                 note="Holds the measures: the product's spend summary (broker x portfolio x strategy x legal "
                      "entity x period) is an aggregate of this fact through Portfolio, the implementation link and "
                      "the product's strategy (CD-312: summed from 25 cost detail, never from 18). Allocation Cost "
                      "Detail folds here."),
            dict(name="Fact Research Payment", role="Fact", objects=[("25", "Research Payment")],
                 pk=["Paid Research Provider", "Payment Period Type", "Payment Period End Date",
                     "Research Payment Source"],
                 grain="one row = research provider x payment period x payment source"),
            dict(name="Fact Commission Sharing Balance", role="Fact", objects=[("25", "Commission Sharing Balance")],
                 pk=["Balance Arrangement", "Balance Statement Date"],
                 grain="one row = commission sharing arrangement x statement date"),
            dict(name="Fact Research Budget", role="Fact", objects=[("25", "Research Budget")],
                 pk=["Budget Year", "Budget Legal Entity", "Budget Strategy"],
                 grain="one row = budget year x legal entity x strategy"),
            dict(name="Fact Evaluation Round", role="Fact", objects=[("23", "Research Evaluation Round")],
                 pk=["Evaluated Provider", "Evaluation Period Type", "Evaluation Period End Date", "Evaluator"],
                 grain="one row = research provider x evaluation period x evaluator"),
            dict(name="Fact Evaluation Criterion Score", role="Fact", objects=[("23", "Evaluation Criterion Score")],
                 pk=["Scored Evaluation Round", "Evaluation Criterion"],
                 grain="one row = evaluation round x criterion",
                 note="Scored Evaluation Round carries the round's reference, not its four key columns."),
            dict(name="Fact Research Consumption", role="Fact", objects=[("23", "Research Consumption Record")],
                 pk=["Consuming Employee", "Consumed Provider", "Research Interaction Type", "Interaction Timestamp"],
                 grain="one row = employee x provider x interaction type x interaction timestamp",
                 note="Matched to subscriptions on provider and date only (spec taxonomy gap: no service type)."),
            dict(name="Fact Research Subscription", role="Fact", objects=[("23", "Research Service Subscription")],
                 pk=["Subscribed Provider", "Subscribed Service Type", "Subscribing Research Team",
                     "Subscription Start Date"],
                 grain="one row = provider x service type x subscribing research team x subscription start"),
            dict(name="Fact Research Invoice", role="Fact", objects=[("19", "Payable Invoice")],
                 pk=["Payable Invoice ID"], grain="one row = payable invoice",
                 note="Read from 19 directly because no foundational product publishes invoices (spec)."),
            dict(name="Fact GL Posting", role="Fact", objects=[("19", "GL Posting")],
                 pk=["Journal ID", "Journal Line Number"], grain="one row = journal line (DP-191 posting)",
                 note="Reconciles invoiced research payments to the ledger (CD-361); expense is not restated."),
            # -- bridges
            dict(name="Portfolio Implementation Link", role="Bridge", conformed=PIL,
                 objects=[("18", "Portfolio Implementation Link")],
                 grain="one row = portfolio x implemented product / mandate / account / model x link type x "
                       "effective period",
                 note="Takes commission spend from portfolio to fund and strategy; conformed for the DP-140 key."),
            # -- dimensions
            dim("Broker", CPTY, [("25", "Approved Counterparty Profile")],
                note="Executing broker, commission schedule broker and commission sharing broker."),
            dim("Research Provider", ("DP-240", "Party"), [("02", "Party"), ("23", "Research Provider Profile")],
                note="Research Provider Profile is keyed by the provider's Party ID, so it merges here; also the "
                     "supplier of research invoices."),
            dim("Related Issuer", ("DP-240", "Party"),
                note="Issuer discussed in a consumption record (expert calls); DP-098 is not upstream, so the "
                     "party master is used."),
            dict(name="Commission Schedule", role="Dimension", objects=[("25", "Commission Schedule")],
                 pk=["Schedule Broker", "Schedule Asset Class", "Schedule Market", "Schedule Effective From"],
                 note="Built from the input: no foundational model publishes commission schedules."),
            dict(name="Commission Sharing Arrangement", role="Dimension",
                 objects=[("25", "Commission Sharing Arrangement")],
                 pk=["Arrangement Executing Broker", "Arrangement Reference", "Arrangement Effective From"],
                 note="Built from the input; Section 28(e) Safe Harbor Indicator drives soft-dollar spend."),
            dict(name="Dataset", role="Dimension", objects=[("14", "Dataset")], pk=["Dataset ID"],
                 note="Built from the input with the 14 key: DP-097 publishes Dataset but is not upstream, and "
                      "DP-044 is consumer-aligned."),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("Investment Product", PROD, [("01", "Investment Product")]),
            dim("Investment Strategy", STRAT, [("01", "Investment Strategy")]),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", EMP, [("20", "Employee")], note="Consuming employee and evaluator."),
            dim("Research Team", ORG, note="Subscribing research team and employees' home org unit."),
            dim("Journal Entry", ("DP-191", "Journal Entry"), [("19", "Journal Entry")]),
            dim("GL Account", ("DP-191", "GL Account")),
            dim("Cost Center", ("DP-191", "Cost Center")),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Commission Allocation", "Portfolio", ["Allocated Portfolio"]),
            rel("Fact Commission Allocation", "Broker", ["Executing Broker"]),
            rel("Fact Commission Allocation", "Commission Schedule", ["Applied Commission Schedule"], optional=True,
                note="Empty or mismatched rate = Off-Schedule Commission Allocations."),
            rel("Fact Commission Allocation", "Commission Sharing Arrangement",
                ["Applied Commission Sharing Arrangement"], optional=True),
            rel("Fact Commission Allocation", "Calendar Date", ["Allocation Trade Date"]),
            rel("Fact Research Payment", "Research Provider", ["Paid Research Provider"]),
            rel("Fact Research Payment", "Fact Research Budget", ["Funding Research Budget"], optional=True),
            rel("Fact Research Payment", "Commission Sharing Arrangement", ["Funding Commission Sharing Arrangement"],
                optional=True),
            rel("Fact Research Payment", "Fact Evaluation Round", ["Research Evaluation Round"], optional=True),
            rel("Fact Research Payment", "Fact Research Invoice", ["Research Invoice"], optional=True,
                note="Payments through commission sharing have no invoice."),
            rel("Fact Research Payment", "Calendar Date", ["Payment Period End Date"]),
            rel("Fact Commission Sharing Balance", "Commission Sharing Arrangement", ["Balance Arrangement"]),
            rel("Fact Commission Sharing Balance", "Calendar Date", ["Balance Statement Date"]),
            rel("Fact Research Budget", "Legal Entity", ["Budget Legal Entity"]),
            rel("Fact Research Budget", "Investment Strategy", ["Budget Strategy"]),
            rel("Fact Evaluation Round", "Research Provider", ["Evaluated Provider"]),
            rel("Fact Evaluation Round", "Employee", ["Evaluator"]),
            rel("Fact Evaluation Round", "Calendar Date", ["Evaluation Period End Date"]),
            rel("Fact Evaluation Criterion Score", "Fact Evaluation Round", ["Scored Evaluation Round"]),
            rel("Fact Research Consumption", "Employee", ["Consuming Employee"]),
            rel("Fact Research Consumption", "Research Provider", ["Consumed Provider"]),
            rel("Fact Research Consumption", "Related Issuer", ["Related Issuer"], optional=True),
            rel("Fact Research Subscription", "Research Provider", ["Subscribed Provider"]),
            rel("Fact Research Subscription", "Research Team", ["Subscribing Research Team"]),
            rel("Fact Research Subscription", "Dataset", ["Licensed Dataset"], optional=True),
            rel("Fact Research Invoice", "Research Provider", ["Supplier"],
                note="For a research invoice the supplier party is the research provider."),
            rel("Fact Research Invoice", "Legal Entity", ["Invoice Legal Entity"]),
            rel("Fact GL Posting", "Journal Entry", ["Journal ID"]),
            rel("Fact GL Posting", "GL Account", ["Posted Account"]),
            rel("Fact GL Posting", "Cost Center", ["Cost Center Segment Value"], optional=True),
            rel("Fact GL Posting", "Fact Research Invoice", ["Source Payable Invoice"], optional=True),
            rel("Journal Entry", "Legal Entity", ["Posting Legal Entity"]),
            rel("Commission Schedule", "Broker", ["Schedule Broker"]),
            rel("Commission Sharing Arrangement", "Broker", ["Arrangement Executing Broker"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"], optional=True),
            rel("Investment Product", "Investment Strategy", ["Implemented Strategy"]),
            rel("Portfolio", "Legal Entity", ["Legal Owner Entity"], optional=True),
            rel("Employee", "Research Team", ["Home Org Unit"], optional=True),
        ],
        notes="Commission and research spend star: allocation commissions (DP-123 grain) and research payments are "
              "the spend facts; commission sharing balances, budgets, broker votes, consumption, subscriptions, "
              "invoices and DP-191 postings are linked facts. Commission sharing reconciles through Commission "
              "Sharing Arrangement (allocations, payments, balances); payments reach the ledger through Research "
              "Invoice and GL Posting. Dataset Vendor (14 Data Vendor) and Posting Accounting Period are "
              "descriptive columns. Restricted - Commercial Terms. Conformed: Broker (DP-115); Research Provider, "
              "Related Issuer (DP-240); Portfolio, Portfolio Implementation Link (DP-140); Investment Product, "
              "Investment Strategy (DP-004); Legal Entity, Calendar Date (DP-013); Employee, Research Team (DP-192); "
              "Journal Entry, GL Account, Cost Center (DP-191).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-123": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Trade Allocation", role="Fact",
                 objects=[("25", "Trade Allocation"), ("25", "Allocation Cost Detail")],
                 pk=["Trade Allocation ID"], measures=True,
                 grain="one row = trade allocation (block or cross x executing broker x trade order x portfolio or "
                       "SMA account)",
                 note="The main fact; holds the measures. Allocation Cost Detail folds here and is published at "
                      "allocation grain only (CD-312); Applied Commission Schedule and Applied Commission Sharing "
                      "Arrangement are descriptive columns here and resolved in DP-122."),
            dict(name="Fact Trade Order", role="Fact",
                 objects=[("25", "Trade Order"), ("25", "Order Handling Instruction")],
                 pk=["Trade Order ID"], grain="one row = trade order",
                 note="Order Handling Instruction folds here. Related Transition Event, Related AP Order, Hedged "
                      "Share Class and Trade Rotation Program are descriptive columns: their objects are not "
                      "inputs. FX orders carry no Order Instrument (spec taxonomy gap)."),
            dict(name="Fact Trade Order Event", role="Fact", objects=[("25", "Trade Order Event")],
                 pk=["Event Trade Order", "Trade Order Event Type", "Event Timestamp"],
                 grain="one row = trade order x event type x event timestamp"),
            dict(name="Fact Block Order", role="Fact", objects=[("25", "Block Order")], pk=["Block Order ID"],
                 grain="one row = block order"),
            dict(name="Fact Broker Placement", role="Fact", objects=[("25", "Broker Placement")],
                 pk=["Placement Block Order", "Placement Broker", "Placement Sequence Number"],
                 grain="one row = block order x broker x placement sequence"),
            dict(name="Fact Execution", role="Fact", objects=[("25", "Execution")], pk=["Execution ID"],
                 grain="one row = execution (fill, correction or cancellation)"),
            # -- bridges
            dict(name="Block Order Membership", role="Bridge", objects=[("25", "Block Order Membership")],
                 pk=["Member Block Order", "Member Trade Order"], grain="one row = block order x trade order",
                 note="Orders and blocks are many-to-many (one order can be worked in several blocks)."),
            dict(name="Portfolio Implementation Link", role="Bridge", conformed=PIL,
                 objects=[("18", "Portfolio Implementation Link")],
                 grain="one row = portfolio x implemented product / mandate / account / model x link type x "
                       "effective period",
                 note="Ties SMA portfolios to their managed accounts; conformed for the DP-140 key."),
            # -- dimensions
            dict(name="Investment Decision", role="Dimension", objects=[("24", "Investment Decision")],
                 pk=["Investment Decision ID"],
                 note="Built from the input: read through DP-126, which is consumer-aligned."),
            dict(name="Proposed Trade", role="Dimension", objects=[("24", "Proposed Trade")],
                 pk=["Proposed Trade ID"],
                 note="Built from the input: read through DP-128 (consumer-aligned). Proposing Rebalance Run is a "
                      "descriptive column (24 Rebalance Run is not an input)."),
            dim("Booked Portfolio Transaction", ("DP-141", "Portfolio Transaction"), [("18", "Portfolio Transaction")],
                note="The IBOR booking of an allocation, read one way from DP-141 (CD-314) for Allocations Booked "
                     "to IBOR %."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Portfolio", PORT, [("18", "Portfolio")]),
            dim("SMA Account", ACCT, [("15", "Account")]),
            dim("Broker", CPTY, [("25", "Approved Counterparty Profile")],
                note="Executing, placement, directed and step-out broker."),
            dim("Counterparty Approval Scope", ("DP-115", "Counterparty Approval Scope"),
                [("25", "Counterparty Approval Scope")],
                note="Outrigger of Broker: the activities, trading entities and funds a broker is approved for "
                     "(Placements With Unapproved Brokers)."),
            dim("Scope Fund", ("DP-140", "Investment Product"), note="Fund named in an approval scope."),
            dim("Trading Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", EMP, [("20", "Employee")],
                note="Order originator, event performer and decision maker."),
            dim("Trader", EMP, note="Assigned trader and block trader."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Trade Allocation", "Fact Block Order", ["Allocated Block Order"], optional=True),
            rel("Fact Trade Allocation", "Fact Trade Order", ["Allocated Trade Order"], optional=True),
            rel("Fact Trade Allocation", "Portfolio", ["Allocated Portfolio"]),
            rel("Fact Trade Allocation", "SMA Account", ["Allocated Account"], optional=True),
            rel("Fact Trade Allocation", "Broker", ["Executing Broker"]),
            rel("Fact Trade Allocation", "Calendar Date", ["Allocation Trade Date"]),
            rel("Fact Trade Order", "Portfolio", ["Order Portfolio"]),
            rel("Fact Trade Order", "Instrument", ["Order Instrument"], optional=True),
            rel("Fact Trade Order", "Investment Decision", ["Originating Investment Decision"], optional=True),
            rel("Fact Trade Order", "Proposed Trade", ["Originating Proposed Trade"], optional=True),
            rel("Fact Trade Order", "Employee", ["Order Originator"]),
            rel("Fact Trade Order", "Trader", ["Assigned Trader"], optional=True),
            rel("Fact Trade Order", "Trading Legal Entity", ["Trading Legal Entity"]),
            rel("Fact Trade Order", "Broker", ["Directed Broker"], optional=True),
            rel("Fact Trade Order", "Broker", ["Step-Out Broker"], optional=True),
            rel("Fact Trade Order Event", "Fact Trade Order", ["Event Trade Order"]),
            rel("Fact Trade Order Event", "Employee", ["Event Performed By"], optional=True),
            rel("Fact Block Order", "Instrument", ["Block Instrument"]),
            rel("Fact Block Order", "Trader", ["Block Trader"]),
            rel("Block Order Membership", "Fact Block Order", ["Member Block Order"]),
            rel("Block Order Membership", "Fact Trade Order", ["Member Trade Order"]),
            rel("Fact Broker Placement", "Fact Block Order", ["Placement Block Order"]),
            rel("Fact Broker Placement", "Broker", ["Placement Broker"]),
            rel("Fact Execution", "Fact Broker Placement", ["Execution Placement"]),
            rel("Fact Execution", "Fact Execution", ["Corrected Execution"], optional=True,
                note="A correction or cancellation points to the execution it corrects."),
            rel("Booked Portfolio Transaction", "Fact Trade Allocation", ["Source Allocation ID"],
                note="Allocations with no booked transaction are the gap in Allocations Booked to IBOR %."),
            rel("Investment Decision", "Instrument", ["Decision Instrument"], optional=True),
            rel("Investment Decision", "Employee", ["Decision Maker"]),
            rel("Proposed Trade", "Investment Decision", ["Originating Investment Decision"], optional=True),
            rel("Proposed Trade", "Portfolio", ["Proposed Trade Portfolio"]),
            rel("Proposed Trade", "Instrument", ["Proposed Trade Instrument"]),
            rel("Counterparty Approval Scope", "Broker", ["Scope Counterparty"]),
            rel("Counterparty Approval Scope", "Trading Legal Entity", ["Scope Trading Entity"], optional=True),
            rel("Counterparty Approval Scope", "Scope Fund", ["Scope Fund"], optional=True),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "SMA Account", ["Managed Account"], optional=True),
        ],
        notes="The order-to-allocation chain as linked facts: trade order -> (membership) -> block order -> broker "
              "placement -> execution, with allocations tying back to block and order and forward to the DP-141 "
              "booking. Decisions and proposals are read by key (DP-126 and DP-128 must not list DP-123 upstream). "
              "No allocation timestamp exists (spec taxonomy gap), so late allocation uses the T+1 snapshot. "
              "Conformed: Instrument (DP-097); Portfolio, Portfolio Implementation Link, Scope Fund (DP-140); SMA "
              "Account (DP-093); Broker, Counterparty Approval Scope (DP-115); Booked Portfolio Transaction "
              "(DP-141); Employee, Trader (DP-192); Trading Legal Entity, Calendar Date (DP-013).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-124": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact TCA Result", role="Fact", objects=[("25", "TCA Result")], pk=["TCA Result ID"],
                 measures=True,
                 grain="one row = TCA result (trade order, block order or execution x TCA provider x measurement "
                       "date)",
                 note="Holds the measures: shortfall, explicit cost and outliers are held once here (25) and used "
                      "as given; the benchmark rows below complete the product grain."),
            dict(name="Fact TCA Benchmark Result", role="Fact", objects=[("25", "TCA Benchmark Result")],
                 pk=["Benchmark TCA Result", "TCA Benchmark"],
                 grain="one row = TCA result x TCA benchmark (the product grain)"),
            dict(name="Fact Broker Execution Review", role="Fact", objects=[("25", "Broker Execution Review")],
                 pk=["Reviewed Broker", "Broker Review Period Type", "Broker Review Period End Date",
                     "Broker Review Asset Class"],
                 grain="one row = broker x review period x asset class"),
            dict(name="Fact Best Execution Review", role="Fact", objects=[("25", "Best Execution Review")],
                 pk=["Review Meeting Date", "Review Period End Date", "Review Asset Class", "Review Legal Entity"],
                 grain="one row = committee review x period x asset class x legal entity"),
            dict(name="Fact Execution", role="Fact", objects=[("25", "Execution")], pk=["Execution ID"],
                 grain="one row = execution (DP-123 grain)",
                 note="Venue, liquidity and capacity for venue mix and TCA coverage."),
            dict(name="Fact Broker Placement", role="Fact", objects=[("25", "Broker Placement")],
                 pk=["Placement Block Order", "Placement Broker", "Placement Timestamp"],
                 grain="one row = block order x broker x placement",
                 note="Model gap: Placement Sequence Number (part of the registry key) is not an input, so "
                      "Placement Timestamp stands in as the discriminator."),
            dict(name="Fact Block Order", role="Fact", objects=[("25", "Block Order")], pk=["Block Order ID"],
                 grain="one row = block order (DP-123 grain)"),
            dict(name="Fact Trade Order", role="Fact", objects=[("25", "Trade Order")], pk=["Trade Order ID"],
                 grain="one row = trade order (DP-123 grain)",
                 note="Block Order Membership is not an input, so orders reach blocks only through TCA results "
                      "measured at both levels."),
            # -- dimensions
            dict(name="Best Execution Policy", role="Dimension", objects=[("25", "Best Execution Policy")],
                 pk=["Policy Name", "Policy Asset Class", "Policy Legal Entity", "Policy Version"],
                 note="Built from the input: no foundational model publishes it. Approved Execution Venues is "
                      "multi-valued text parsed for the unapproved venue test (spec taxonomy gap)."),
            dim("Broker", CPTY, [("25", "Approved Counterparty Profile")]),
            dim("Service Provider", ("DP-143", "Party"),
                note="TCA provider and outsourced trading provider. Model gap: DP-240 masters parties but is not "
                     "in DP-124's upstream, so the Party republished by DP-143 (upstream) is used."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Approved Price", PRICE, [("22", "Approved Price")],
                note="For the arrival price DQ check only."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Committee Chair", EMP, [("20", "Employee")]),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact TCA Result", "Fact Trade Order", ["Measured Trade Order"], optional=True),
            rel("Fact TCA Result", "Fact Block Order", ["Measured Block Order"], optional=True),
            rel("Fact TCA Result", "Fact Execution", ["Measured Execution"], optional=True,
                note="One of the three measured levels is set, per the TCA provider's level."),
            rel("Fact TCA Result", "Service Provider", ["TCA Provider"]),
            rel("Fact TCA Result", "Calendar Date", ["Measurement Date"]),
            rel("Fact TCA Benchmark Result", "Fact TCA Result", ["Benchmark TCA Result"]),
            rel("Fact Execution", "Fact Broker Placement", ["Execution Placement"]),
            rel("Fact Broker Placement", "Fact Block Order", ["Placement Block Order"]),
            rel("Fact Broker Placement", "Broker", ["Placement Broker"]),
            rel("Fact Block Order", "Instrument", ["Block Instrument"]),
            rel("Fact Trade Order", "Instrument", ["Order Instrument"], optional=True),
            rel("Fact Trade Order", "Legal Entity", ["Trading Legal Entity"]),
            rel("Fact Broker Execution Review", "Broker", ["Reviewed Broker"]),
            rel("Fact Broker Execution Review", "Calendar Date", ["Broker Review Period End Date"]),
            rel("Fact Best Execution Review", "Legal Entity", ["Review Legal Entity"]),
            rel("Fact Best Execution Review", "Best Execution Policy", ["Reviewed Policy"], optional=True,
                note="Carries the policy name; the version is the one effective in the review period."),
            rel("Fact Best Execution Review", "Committee Chair", ["Committee Chair"], optional=True),
            rel("Fact Best Execution Review", "Calendar Date", ["Review Period End Date"]),
            rel("Best Execution Policy", "Legal Entity", ["Policy Legal Entity"]),
            rel("Best Execution Policy", "Service Provider", ["Outsourced Trading Provider"], optional=True),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
        ],
        notes="Execution quality star: TCA results and their benchmarks joined to the DP-123 execution chain (rebuilt "
              "from inputs with the DP-123 keys), with broker and committee reviews as linked facts. Commission "
              "spend stays DP-122's (CD-312). Model gap: Placement Sequence Number is not an input. Model gap: "
              "DP-240 is not upstream, so TCA and outsourced trading providers use DP-143's Party. Conformed: "
              "Broker (DP-115); Service Provider, Approved Price (DP-143); Instrument (DP-097); Legal Entity, "
              "Calendar Date (DP-013); Committee Chair (DP-192).",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-125": dict(
        style="Star",
        entities=[
            # -- facts
            dict(name="Fact Trade Allocation", role="Fact", objects=[("25", "Trade Allocation")],
                 pk=["Trade Allocation ID"], measures=True,
                 grain="one row = trade allocation (DP-123 grain)",
                 note="Holds the measures: every control fact (new issue, Rule 10f-3, cross, error) points "
                      "to the allocation it concerns, so the allocation is the shared spine for pre-allocation, "
                      "reallocation and the control counts."),
            dict(name="Fact New Issue Allocation", role="Fact", objects=[("25", "New Issue Allocation")],
                 pk=["Allocation Offering", "Receiving Portfolio", "Receiving Account"],
                 grain="one row = offering x receiving portfolio or account"),
            dict(name="Fact New Issue Indication", role="Fact", objects=[("25", "New Issue Indication")],
                 pk=["Indication Offering", "Indicating Portfolio", "Indicating Account", "Indication Timestamp"],
                 grain="one row = offering x portfolio or account x indication timestamp"),
            dict(name="Fact Eligibility Certification", role="Fact",
                 objects=[("25", "New Issue Eligibility Certification")],
                 pk=["Certified Portfolio", "Certified Account", "Certification Date"],
                 grain="one row = portfolio or account x certification date (FINRA Rule 5130 / 5131)"),
            dict(name="Fact Rule 10f-3 Purchase", role="Fact", objects=[("25", "Rule 10f-3 Purchase")],
                 pk=["Rule 10f-3 Offering", "Purchasing Fund", "Purchase Trade Allocation"],
                 grain="one row = offering x fund x allocation"),
            dict(name="Fact Cross Trade", role="Fact", objects=[("25", "Cross Trade")], pk=["Cross Trade Reference"],
                 grain="one row = cross trade"),
            dict(name="Fact Trade Error", role="Fact", objects=[("25", "Trade Error")], pk=["Trade Error Reference"],
                 grain="one row = trade error",
                 note="Related Incident Reference is text, not a 37 reference (spec taxonomy gap), so it is a "
                      "column, not a link."),
            dict(name="Fact Block Order", role="Fact", objects=[("25", "Block Order")], pk=["Block Order ID"],
                 grain="one row = block order (DP-123 grain)"),
            dict(name="Fact Trade Order", role="Fact", objects=[("25", "Trade Order")], pk=["Trade Order ID"],
                 grain="one row = trade order (DP-123 grain)"),
            # -- bridges
            dict(name="Block Order Membership", role="Bridge", objects=[("25", "Block Order Membership")],
                 pk=["Member Block Order", "Member Trade Order"], grain="one row = block order x trade order",
                 note="Pre-allocation quantities and late additions per order in a block."),
            dict(name="Portfolio Implementation Link", role="Bridge", conformed=PIL,
                 objects=[("18", "Portfolio Implementation Link")],
                 grain="one row = portfolio x implemented product / mandate / account / model x link type x "
                       "effective period",
                 note="Fund and SMA account of a portfolio (Rule 10f-3 funds, new issue accounts); conformed for "
                      "the DP-140 key."),
            # -- dimensions
            dict(name="New Issue Offering", role="Dimension", objects=[("25", "New Issue Offering")],
                 pk=["New Issue Offering Reference"],
                 note="Built from the input: no foundational model publishes offerings. Offering Setup Request "
                      "(17 Instrument Setup Request) is a descriptive column."),
            dict(name="Price Observation", role="Dimension", objects=[("22", "Price Observation")],
                 pk=["Price Observation Key"],
                 note="Built from the input: DP-143 publishes approved prices, not the observations a cross cites "
                      "(spec)."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Portfolio", PORT, [("18", "Portfolio")],
                note="Allocated, indicating, receiving, certified, buying, selling and affected portfolio."),
            dim("SMA Account", ACCT, [("15", "Account")]),
            dim("Fund", PROD, [("01", "Investment Product"), ("01", "Fund Legal Structure")],
                note="Rule 10f-3 purchasing fund; Fund Legal Structure folds here (Regulatory Regime)."),
            dim("Broker", CPTY, [("25", "Approved Counterparty Profile")],
                note="Lead bookrunner and the seller of a Rule 10f-3 purchase."),
            dim("Party", ("DP-143", "Party"),
                note="The party cross-reference of internal legal entities (affiliate test). Model gap: DP-240 is not in DP-125's upstream, so the Party republished by "
                     "DP-143 (upstream) is used."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")],
                note="Trading legal entity of the order; Party Master Cross-Reference identifies affiliates."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Trade Allocation", "Fact Block Order", ["Allocated Block Order"], optional=True),
            rel("Fact Trade Allocation", "Fact Trade Order", ["Allocated Trade Order"], optional=True),
            rel("Fact Trade Allocation", "Portfolio", ["Allocated Portfolio"]),
            rel("Fact Trade Allocation", "SMA Account", ["Allocated Account"], optional=True),
            rel("Fact Trade Allocation", "Calendar Date", ["Allocation Trade Date"]),
            rel("Fact New Issue Allocation", "New Issue Offering", ["Allocation Offering"]),
            rel("Fact New Issue Allocation", "Portfolio", ["Receiving Portfolio"], optional=True),
            rel("Fact New Issue Allocation", "SMA Account", ["Receiving Account"], optional=True),
            rel("Fact New Issue Allocation", "Fact Trade Allocation", ["Booked Trade Allocation"], optional=True),
            rel("Fact New Issue Allocation", "Fact Eligibility Certification", ["Supporting Eligibility Certification"],
                optional=True, note="Required for equity new issues (Rule 5130 / 5131)."),
            rel("Fact New Issue Indication", "New Issue Offering", ["Indication Offering"]),
            rel("Fact New Issue Indication", "Portfolio", ["Indicating Portfolio"], optional=True),
            rel("Fact New Issue Indication", "SMA Account", ["Indicating Account"], optional=True),
            rel("Fact Eligibility Certification", "Portfolio", ["Certified Portfolio"], optional=True),
            rel("Fact Eligibility Certification", "SMA Account", ["Certified Account"], optional=True),
            rel("Fact Rule 10f-3 Purchase", "New Issue Offering", ["Rule 10f-3 Offering"]),
            rel("Fact Rule 10f-3 Purchase", "Fund", ["Purchasing Fund"]),
            rel("Fact Rule 10f-3 Purchase", "Fact Trade Allocation", ["Purchase Trade Allocation"]),
            rel("Fact Rule 10f-3 Purchase", "Broker", ["Purchased From"]),
            rel("Fact Cross Trade", "Portfolio", ["Buying Portfolio"]),
            rel("Fact Cross Trade", "Portfolio", ["Selling Portfolio"]),
            rel("Fact Cross Trade", "Instrument", ["Cross Instrument"]),
            rel("Fact Cross Trade", "Price Observation", ["Independent Price Observation"], optional=True),
            rel("Fact Cross Trade", "Fact Trade Allocation", ["Buying Trade Allocation"], optional=True),
            rel("Fact Cross Trade", "Fact Trade Allocation", ["Selling Trade Allocation"], optional=True),
            rel("Fact Trade Error", "Fact Trade Order", ["Affected Trade Order"], optional=True),
            rel("Fact Trade Error", "Fact Trade Allocation", ["Affected Trade Allocation"], optional=True),
            rel("Fact Trade Error", "Portfolio", ["Affected Portfolio"], optional=True),
            rel("Fact Trade Error", "Calendar Date", ["Error Discovery Date"]),
            rel("Fact Block Order", "Instrument", ["Block Instrument"]),
            rel("Block Order Membership", "Fact Block Order", ["Member Block Order"]),
            rel("Block Order Membership", "Fact Trade Order", ["Member Trade Order"]),
            rel("Fact Trade Order", "Portfolio", ["Order Portfolio"]),
            rel("Fact Trade Order", "Legal Entity", ["Trading Legal Entity"]),
            rel("New Issue Offering", "Instrument", ["Offering Instrument"]),
            rel("New Issue Offering", "Broker", ["Lead Bookrunner"], optional=True),
            rel("New Issue Offering", "Calendar Date", ["Pricing Date"]),
            rel("Price Observation", "Instrument", ["Observed Instrument"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Fund", ["Implemented Product"], optional=True),
            rel("Portfolio Implementation Link", "SMA Account", ["Managed Account"], optional=True),
            rel("Legal Entity", "Party", ["Party Master Cross-Reference"], optional=True),
        ],
        notes="Trading controls star: one fact per control at its own grain, each tied to the DP-123 allocation "
              "chain (rebuilt from inputs with the DP-123 keys, CD-314). "
              "Model gap: Block Trader points to 20 Employee, which is not an input and DP-192 is not upstream, so "
              "it is a descriptive column. "
              "Model gap: DP-240 is not upstream, so the legal entity cross-reference uses DP-143's Party. W1 (CW-917): the EU or UK Trading Venue Indicator is gone, so Regulatory Instrument "
              "Classification is no longer read. Conformed: Instrument (DP-097); Portfolio, "
              "Portfolio Implementation Link (DP-140); SMA Account (DP-093); Fund (DP-004); Broker (DP-115); Party "
              "(DP-143); Legal Entity, Calendar Date (DP-013). "
              "W1b re-point (CW-925): Fact MiFIR Transaction Report removed with its 25 object (no successor) and its "
              "four relationships; the Investment Decision dimension (24, read only for the MiFIR decision-maker "
              "comparison) and its link from the trade order are removed with the spec input. Originating Investment "
              "Decision stays a column of the trade order (the 24 key, not resolved here).",
    ),
}
