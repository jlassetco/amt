"""Logical data models: Star models for DP-214 to DP-221 (enterprise risk, internal audit and third-party products, Data
Domains 37 Enterprise & Operational Risk and 40 Procurement & Vendor Management). Wave E8 consumer models. See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here. Product input
  objects of the same concept sit on the conformed dimension and merge with its inherited attributes.
- Inside this group the spec's upstream graph is DP-214 <- DP-216 <- DP-215, DP-217, DP-218; DP-217 <- DP-220 <- DP-219;
  DP-216 <- DP-219. Where a downstream product reads an entity its upstream group product publishes, it conforms that
  entity: Enterprise Risk and Risk Taxonomy Category from DP-214, Risk Issue from DP-216 (the single remediation status,
  CD-356), Critical or Important Function from DP-217, and Outsourcing Arrangement from DP-220 (the ICT register
  entities left with CW-940). Remediation Status itself is a DP-216 measure on
  Fact Remediation Status (risk issue x as-of date); readers join to it by Risk Issue ID and compute no status of their own.
- Facts and source-record entities are built from the product's own inputs, except where the lead asked for the in-group
  reuse above. They keep the natural keys of the key registry, so they still join to the masters.
- Effective-dated masters (Critical or Important Function, Risk Taxonomy Category, Business
  Continuity Plan, Audit Plan, Control, RCSA Campaign, Risk Appetite Statement) are referenced by a single code attribute;
  the row in force on the child's date is chosen at query time. Relationships to them name that one attribute.
- Date roles are conformed from DP-013 Calendar Date (firm business calendar), so a date attribute on a fact is its key.
  Snapshot facts that carry no as-of date attribute borrow "As-of Date Key" (Model gap, as in DP-017 and DP-081).
- Multi-valued references are drawn as M:N relationships; the build explodes them into one row per referenced member.
- References to objects that are not inputs of the product (for example 33 Investment Breach, 39 Legal Matter, 14
  Assurance Report) stay degenerate attributes on their entity.
"""


def dim(name, src, objects=(), note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


CAL = ("DP-013", "Calendar Date")
LE = ("DP-013", "Internal Legal Entity")
ORG = ("DP-013", "Org Unit")
OFFICE = ("DP-013", "Office Location")
FISCAL = ("DP-013", "Fiscal Period")
EMP = ("DP-192", "Employee")
WFP = ("DP-192", "Workforce Position")
METRIC = ("DP-101", "Metric Definition")
VENDOR = ("DP-210", "Vendor")
SENG = ("DP-210", "Supplier Engagement")
STIER = ("DP-210", "Supplier Risk Tiering")
SCAT = ("DP-210", "Supplier Category Assignment")
SCP = ("DP-210", "Supplier Contract Profile")
DVEND = ("DP-210", "Data Vendor")
APP = ("DP-211", "Application")
ITSVC = ("DP-211", "IT Service")
MODEL = ("DP-212", "Model")
MVAL = ("DP-212", "Model Validation")
CONTRACT = ("DP-213", "Contract")
KEYDATE = ("DP-213", "Contract Key Date")
PARTY = ("DP-240", "Party")
PARTY_ID = ("DP-240", "Party Identifier")
GLACCT = ("DP-190", "GL Account")
COSTC = ("DP-190", "Cost Center")
JOURNAL = ("DP-191", "Journal Entry")
POSTING = ("DP-191", "GL Posting")
PRODUCT = ("DP-004", "Investment Product")
# in-group sources
RISK = ("DP-214", "Enterprise Risk")
RISKCAT = ("DP-214", "Risk Taxonomy Category")
ISSUE = ("DP-216", "Risk Issue")
CIF = ("DP-217", "Critical or Important Function")
OUTS = ("DP-220", "Outsourcing Arrangement")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-214": dict(
        style="Star",
        entities=[
            dict(name="Fact Risk Assessment", role="Fact", objects=[("37", "Risk Assessment")],
                 pk=["Assessed Risk", "Risk Assessment Date"], measures=True,
                 grain="one row = enterprise risk x risk assessment date (month-end snapshots for the risk committee)",
                 note="The product's primary grain. Holds the measures because the profile, appetite and migration "
                      "measures are stated per assessed risk; the control and KRI measures roll up to the risk through "
                      "Risk Control Link and Key Risk Indicator."),
            dict(name="Fact Control Test", role="Fact", objects=[("37", "Control Test")],
                 pk=["Tested Control", "Control Test Date", "Control Test Sequence"],
                 grain="one row = control version x test date x test sequence",
                 note="Key Control Test Failure Rate and Key Controls Not Tested; the sampled execution records stay "
                      "evidence keys (spec note)."),
            dict(name="Fact KRI Observation", role="Fact", objects=[("37", "KRI Observation")],
                 pk=["Observed KRI", "KRI Observation Date"],
                 grain="one row = KRI version x observation date"),
            dict(name="Risk Control Link", role="Bridge", objects=[("37", "Risk Control Link")],
                 pk=["Linked Risk", "Linked Control", "Link Effective From"],
                 grain="one row = enterprise risk x control x effective period",
                 note="Many controls mitigate one risk and one control mitigates many risks."),
            dict(name="Enterprise Risk", role="Dimension", objects=[("37", "Enterprise Risk")], pk=["Risk ID"],
                 note="Published here as the Risk dimension that DP-215, DP-216, DP-218 and the Wave E5 view conform."),
            dict(name="Risk Taxonomy Category", role="Dimension", objects=[("37", "Risk Taxonomy Category")],
                 pk=["Risk Category Code", "Risk Taxonomy Version"],
                 note="Level 1 and level 2 through Parent Risk Category; conformed by DP-215 and DP-216."),
            dict(name="Risk Appetite Statement", role="Dimension", objects=[("37", "Risk Appetite Statement")],
                 pk=["Appetite Statement Code", "Appetite Scope Entity", "Appetite Effective From"],
                 note="Reached from the KRI threshold. Risk Assessment has no link to the statement it was judged "
                      "against; the spec matches it by category and scope entity (taxonomy gap)."),
            dict(name="RCSA Campaign", role="Dimension", objects=[("37", "RCSA Campaign")],
                 pk=["RCSA Campaign Code", "Assessed Org Unit"],
                 note="Campaign x assessed org unit; RCSA Completion % counts its status."),
            dict(name="Control", role="Dimension", objects=[("37", "Control")], pk=["Control ID", "Control Version"]),
            dict(name="Key Risk Indicator", role="Dimension",
                 objects=[("37", "Key Risk Indicator"), ("37", "KRI Threshold")], pk=["KRI Code", "KRI Version"],
                 note="KRI Threshold is one row per KRI version, so it folds into the KRI."),
            dim("Metric Definition", METRIC, [("21", "Metric Definition")],
                note="KRIs built on a certified metric (KRIs on Uncertified Metrics)."),
            dim("Org Unit", ORG, [("09", "Org Unit")]),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", EMP, [("20", "Employee")],
                note="Role-playing: risk owner, assessor, control owner, tester and RCSA sign-off (Controls With "
                     "Departed Owner reads Employment Status)."),
            dim("Assessment Date", CAL),
        ],
        relationships=[
            rel("Fact Risk Assessment", "Enterprise Risk", ["Assessed Risk"]),
            rel("Fact Risk Assessment", "Assessment Date", ["Risk Assessment Date"]),
            rel("Fact Risk Assessment", "RCSA Campaign", ["Source RCSA Campaign"], optional=True,
                note="Carries the campaign code; the campaign row is the one for the risk's owning org unit."),
            rel("Fact Risk Assessment", "Employee", ["Risk Assessor"], optional=True),
            rel("Enterprise Risk", "Risk Taxonomy Category", ["Risk Category"],
                note="Carries the category code; the taxonomy version in force is chosen by date."),
            rel("Risk Taxonomy Category", "Risk Taxonomy Category", ["Parent Risk Category"], optional=True,
                note="Level 2 to level 1."),
            rel("Enterprise Risk", "Org Unit", ["Risk Owning Org Unit"], optional=True),
            rel("Enterprise Risk", "Legal Entity", ["Risk Legal Entities"], card="M:N", optional=True),
            rel("Enterprise Risk", "Employee", ["Risk Owner"], optional=True),
            rel("Risk Control Link", "Enterprise Risk", ["Linked Risk"]),
            rel("Risk Control Link", "Control", ["Linked Control"]),
            rel("Control", "Legal Entity", ["Control Owning Legal Entity"], optional=True),
            rel("Control", "Employee", ["Control Owner"], optional=True),
            rel("Fact Control Test", "Control", ["Tested Control"],
                note="Tested Control identifies the control version tested."),
            rel("Fact Control Test", "Employee", ["Control Tester"], optional=True),
            rel("Key Risk Indicator", "Enterprise Risk", ["Measured Risk"]),
            rel("Key Risk Indicator", "Metric Definition", ["Source Metric Definition"], optional=True),
            rel("Key Risk Indicator", "Risk Appetite Statement", ["Linked Appetite Statement"], optional=True,
                note="Carries the statement code; scope entity and period are chosen by the KRI's context."),
            rel("Risk Appetite Statement", "Legal Entity", ["Appetite Scope Entity"], optional=True,
                note="Blank for firm-wide statements."),
            rel("Fact KRI Observation", "Key Risk Indicator", ["Observed KRI"]),
            rel("RCSA Campaign", "Org Unit", ["Assessed Org Unit"]),
            rel("RCSA Campaign", "Employee", ["RCSA Sign-Off By"], optional=True),
        ],
        notes=("Risk and control profile as a constellation of assessment, control test and KRI observation facts around "
               "the Enterprise Risk dimension, with Risk Control Link as the many-to-many bridge to Control. Enterprise "
               "Risk and Risk Taxonomy Category are named so the group's downstream products (DP-215, DP-216, DP-218) "
               "conform them. Org Unit, Legal Entity and Assessment Date conform to DP-013, Employee to DP-192 and "
               "Metric Definition to DP-101. Metric Source Data Product stays a degenerate reference (21 Data Product "
               "is not an input). No issue status is modeled here; remediation is DP-216's (CD-356)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-216": dict(
        style="Star",
        entities=[
            dict(name="Fact Remediation Status", role="Fact", objects=[],
                 pk=["Risk Issue Key", "As-of Date Key"], measures=True,
                 grain="one row = risk issue x as-of date (daily status snapshot from the SCD type 2 history)",
                 note="The one place Remediation Status is computed (CD-356). Issue age, extensions and closure timing "
                      "come from the issue's history, so the snapshot is a fact over the Risk Issue dimension."),
            dict(name="Fact Issue Action", role="Fact", objects=[("37", "Issue Action")],
                 pk=["Action Issue", "Issue Action Sequence"],
                 grain="one row = risk issue x action sequence (SCD type 2 history)",
                 note="Overdue Actions and the risk acceptance actions behind Risk-Accepted Issues."),
            dict(name="Risk Issue", role="Dimension", objects=[("37", "Risk Issue")], pk=["Risk Issue ID"],
                 note="Published for the group: DP-215, DP-217, DP-218 and DP-219 conform this entity and read "
                      "Remediation Status from Fact Remediation Status by Risk Issue ID. The issue holds the only link "
                      "to its source (CD-247)."),
            dict(name="Audit Finding", role="Dimension", objects=[("37", "Audit Finding")], pk=["Audit Finding ID"],
                 note="Read from the 37 master, not DP-218, to avoid a cycle (spec note)."),
            dict(name="Examination Finding", role="Dimension", objects=[("38", "Examination Finding")],
                 pk=["Finding Examination", "Finding Sequence"]),
            dict(name="Compliance Program Review", role="Dimension", objects=[("38", "Compliance Program Review")],
                 pk=["Compliance Program Review Key"],
                 note="Model gap: the registry key includes Review Period End, which is not an input of this product, "
                      "so the entity takes a surrogate key."),
            dict(name="Operational Incident", role="Dimension", objects=[("37", "Operational Incident")],
                 pk=["Operational Incident ID"],
                 note="Own entity: DP-215 reads this product, so it cannot be conformed from DP-215."),
            dict(name="Control Test", role="Dimension", objects=[("37", "Control Test")],
                 pk=["Tested Control", "Control Test Date", "Control Test Sequence"],
                 note="Source record for keys, result and date only; the test fact is DP-214's."),
            dim("Model Validation", MVAL, [("37", "Model Validation")],
                note="Model validations are the DP-212 registry's (CD-294)."),
            dim("Model", MODEL),
            dict(name="Third-Party Risk Assessment", role="Dimension", objects=[("37", "Third-Party Risk Assessment")],
                 pk=["Third-Party Risk Assessment Reference"],
                 note="Assessed Supplier Engagement stays degenerate: 40 Supplier Engagement is not an input and DP-210 "
                      "is not upstream of this product."),
            dict(name="Resilience Test", role="Dimension", objects=[("37", "Resilience Test")],
                 pk=["Resilience Test Reference", "Resilience Test Date"]),
            dict(name="Vulnerability Finding", role="Dimension", objects=[("41", "Vulnerability Finding")],
                 pk=["Vulnerability Finding ID"],
                 note="Source-specific remediation status stays with DP-232 (spec note)."),
            dim("Enterprise Risk", RISK, [("37", "Enterprise Risk")]),
            dim("Risk Taxonomy Category", RISKCAT, note="Related risk category for the issue."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Role-playing: issue owner, action owner and risk acceptance approver."),
            dim("Org Unit", ORG, [("09", "Org Unit")]),
            dim("As-of Date", CAL),
        ],
        relationships=[
            rel("Fact Remediation Status", "Risk Issue", ["Risk Issue Key"],
                note="Carries the Risk Issue ID. Model gap: no input carries the snapshot's issue as its own attribute."),
            rel("Fact Remediation Status", "As-of Date", ["As-of Date Key"],
                note="Model gap: no input carries the as-of date; it is the snapshot date of the history."),
            rel("Fact Issue Action", "Risk Issue", ["Action Issue"]),
            rel("Fact Issue Action", "Employee", ["Issue Action Owner"], optional=True),
            rel("Fact Issue Action", "Employee", ["Risk Acceptance Approver"], optional=True),
            rel("Risk Issue", "Employee", ["Issue Owner"], optional=True),
            rel("Risk Issue", "Enterprise Risk", ["Issue Related Risk"], optional=True),
            rel("Risk Issue", "Audit Finding", ["Source Audit Finding"], optional=True,
                note="Exactly one source reference is filled, as Issue Source Type says."),
            rel("Risk Issue", "Examination Finding", ["Source Examination Finding"], optional=True),
            rel("Risk Issue", "Compliance Program Review", ["Source Compliance Program Review"], optional=True),
            rel("Risk Issue", "Operational Incident", ["Source Operational Incident"], optional=True),
            rel("Risk Issue", "Control Test", ["Source Control Test"], optional=True),
            rel("Risk Issue", "Model Validation", ["Source Model Validation"], optional=True),
            rel("Risk Issue", "Third-Party Risk Assessment", ["Source Third-Party Risk Assessment"], optional=True),
            rel("Risk Issue", "Resilience Test", ["Source Resilience Test"], optional=True,
                note="Carries the test reference; the test date is chosen as the latest run."),
            rel("Risk Issue", "Vulnerability Finding", ["Source Vulnerability Finding"], optional=True),
            rel("Model Validation", "Model", ["Validated Model"]),
            rel("Enterprise Risk", "Risk Taxonomy Category", ["Risk Category"]),
            rel("Enterprise Risk", "Org Unit", ["Risk Owning Org Unit"], optional=True,
                note="Gives the issue's owning org unit through its related risk."),
        ],
        notes=("Remediation status snapshot fact over the Risk Issue dimension, with the issue action fact and one "
               "dimension per issue source. Risk Issue is the entity the group's readers conform. Enterprise Risk and "
               "Risk Taxonomy Category conform to DP-214, Model Validation and Model to DP-212, Employee to DP-192, Org "
               "Unit and As-of Date to DP-013. Source records of products that read this one (DP-218 audit findings, "
               "DP-219 third-party assessments, DP-215 incidents) are own entities read from their 37, 38 and 41 "
               "masters, to keep the graph acyclic. "
               "Model gap: the snapshot fact borrows Risk Issue Key and As-of Date Key (no input carries the as-of "
               "date). Model gap: Compliance Program Review takes a surrogate key because Review Period End is not an "
               "input. Finding Examination (38 Regulatory Examination) and Tested Control (37 Control) stay degenerate "
               "because their targets are not inputs."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-215": dict(
        style="Star",
        entities=[
            dict(name="Fact Operational Incident", role="Fact",
                 objects=[("37", "Operational Incident"), ("37", "Incident Classification")],
                 pk=["Operational Incident ID"], measures=True,
                 grain="one row = operational incident (OPINC-)",
                 note="Incident Classification is one row per incident, so it folds in. Holds the measures; loss and "
                      "notification measures roll up to the incident through their child facts."),
            dict(name="Incident Source Record", role="Bridge", objects=[("37", "Incident Source Record")],
                 pk=["Incident Source Record Key"],
                 grain="one row = operational incident x source record (one typed source per row)",
                 note="Links one incident to many source events (trade error, NAV error, servicing error, IT incident); "
                      "the registry gives it a surrogate key."),
            dict(name="Fact Regulatory Notification", role="Fact", objects=[("37", "Incident Regulatory Notification")],
                 pk=["Notified Incident", "Notification Authority", "Incident Notification Regime",
                     "Incident Notification Stage"],
                 grain="one row = operational incident x authority x notification regime x notification stage",
                 note="W1b re-point (CW-937): the regime (Regulation S-P, state breach law, FINRA Rule 4530) is split "
                      "from the stage and joins the key, as the 37 grain states."),
            dict(name="Fact Operational Loss Event", role="Fact", objects=[("37", "Operational Loss Event")],
                 pk=["Loss Event ID"], grain="one row = operational loss event (LOSS-)"),
            dict(name="Fact Loss Event Amount", role="Fact", objects=[("37", "Loss Event Amount")],
                 pk=["Amount Loss Event", "Loss Amount Sequence"],
                 grain="one row = operational loss event x amount sequence",
                 note="Gross, recovery and client impact components; each reconciles to its GL evidence journal."),
            dict(name="Fact Insurance Claim", role="Fact", objects=[("43", "Insurance Claim")],
                 pk=["Insurance Claim Reference"], grain="one row = insurance claim (policy x claim sequence)",
                 note="Insurance Recoveries; the claim holds the only link to the loss event."),
            dict(name="IT Incident", role="Dimension", objects=[("41", "IT Incident")], pk=["IT Incident ID"],
                 note="Read only as the cause and for detection and downtime (CD-266). Affected Applications stays "
                      "degenerate: 41 Application is not an input."),
            dict(name="Trade Error", role="Dimension", objects=[("25", "Trade Error")], pk=["Trade Error Reference"]),
            dict(name="NAV Error Case", role="Dimension", objects=[("27", "NAV Error Case")], pk=["NAV Error Case ID"]),
            dict(name="Breach Loss Calculation", role="Dimension", objects=[("33", "Breach Loss Calculation")],
                 pk=["Calculated Breach", "Loss Calculation Version"]),
            dict(name="Settlement Penalty", role="Dimension", objects=[("26", "Settlement Penalty")],
                 pk=["Settlement Penalty ID"]),
            dict(name="Servicing Error", role="Dimension", objects=[("13", "Servicing Error")],
                 pk=["Servicing Error ID"]),
            dim("Risk Taxonomy Category", RISKCAT, [("37", "Risk Taxonomy Category")]),
            dim("Risk Issue", ISSUE, [("37", "Risk Issue")],
                note="Conformed from DP-216; Incidents With Overdue Remediation reads DP-216's Remediation Status by "
                     "Risk Issue ID (CD-356)."),
            dim("Journal Entry", JOURNAL, [("19", "Journal Entry")]),
            dim("GL Posting", POSTING, [("19", "GL Posting")],
                note="Loss Reconciled to GL %: the evidence journal's postings."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", EMP, [("20", "Employee")]),
            dim("Investment Product", PRODUCT, note="Impacted product dimension (DP-004)."),
            dim("Discovery Date", CAL),
        ],
        relationships=[
            rel("Fact Operational Incident", "Discovery Date", ["Incident Discovery Date"]),
            rel("Fact Operational Incident", "Legal Entity", ["Incident Legal Entity"], optional=True),
            rel("Fact Operational Incident", "Employee", ["Incident Owner"], optional=True),
            rel("Fact Operational Incident", "Investment Product", ["Impacted Products"], card="M:N", optional=True),
            rel("Fact Operational Incident", "Risk Taxonomy Category", ["Incident Risk Category"], optional=True,
                note="Carries the category code; the taxonomy version in force is chosen by date."),
            rel("Incident Source Record", "Fact Operational Incident", ["Source Incident"]),
            rel("Incident Source Record", "Trade Error", ["Source Trade Error"], optional=True),
            rel("Incident Source Record", "NAV Error Case", ["Source NAV Error Case"], optional=True),
            rel("Incident Source Record", "Servicing Error", ["Source Servicing Error"], optional=True),
            rel("Incident Source Record", "IT Incident", ["Source IT Incident"], optional=True),
            rel("Fact Regulatory Notification", "Fact Operational Incident", ["Notified Incident"]),
            rel("Fact Regulatory Notification", "Legal Entity", ["Notifying Legal Entity"], optional=True),
            rel("Fact Operational Loss Event", "Fact Operational Incident", ["Originating Incident"]),
            rel("Fact Operational Loss Event", "Legal Entity", ["Loss Legal Entity"], optional=True),
            rel("Fact Operational Loss Event", "Servicing Error", ["Impact Source Servicing Error"], optional=True),
            rel("Fact Loss Event Amount", "Fact Operational Loss Event", ["Amount Loss Event"]),
            rel("Fact Loss Event Amount", "Journal Entry", ["GL Evidence Journal"], optional=True),
            rel("Fact Loss Event Amount", "Trade Error", ["Amount Source Trade Error"], optional=True),
            rel("Fact Loss Event Amount", "NAV Error Case", ["Amount Source NAV Error Case"], optional=True),
            rel("Fact Loss Event Amount", "Breach Loss Calculation", ["Amount Source Breach Loss Calculation"],
                optional=True, note="Identifies the breach's loss calculation version."),
            rel("Fact Loss Event Amount", "Settlement Penalty", ["Amount Source Settlement Penalty"], optional=True),
            rel("Fact Insurance Claim", "Fact Operational Loss Event", ["Related Operational Loss Event"], optional=True),
            rel("NAV Error Case", "Legal Entity", ["Reimbursing Entity"], optional=True),
            rel("GL Posting", "Journal Entry", ["Journal ID"]),
            rel("Risk Issue", "Fact Operational Incident", ["Source Operational Incident"], optional=True,
                note="Issues raised from an incident."),
        ],
        notes=("W1b re-point (CW-937): Impacted Business Services and the DORA classification fields leave with the 37 attributes; the notification fact is keyed by regime and stage. "
               "Incident and loss star: the incident fact with its source bridge, regulatory notification, loss event, "
               "loss amount and insurance claim facts, and one dimension per source event type. Risk Taxonomy Category "
               "conforms to DP-214 and Risk Issue to DP-216 (remediation status is DP-216's, CD-356); Journal Entry and "
               "GL Posting conform to DP-191 (the loss reconciles to the GL evidence journal and is never labeled "
               "expense, CD-353, CD-361), Legal Entity and Discovery Date to DP-013, Employee to DP-192 and Investment "
               "Product to DP-004. Impacted Portfolios, Related Legal Matter, Source "
               "Investment Breach, Source Risk Limit Exceedance, Source Physical Security Incident, Source Plan "
               "Correction, Calculated Breach and Posted Account stay degenerate because their targets are not inputs "
               "(Impacted Portfolios is not published, spec note). DP-211 is upstream for the IT incident's "
               "applications but no Application input is read, so no Application dimension is drawn."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-217": dict(
        style="Star",
        entities=[
            dict(name="Resilience Resource Mapping", role="Fact", objects=[("37", "Resilience Resource Mapping")],
                 pk=["Resilience Resource Mapping Key"], measures=True,
                 grain="one row = critical or important function x mapped resource x effective period",
                 note="The hub of the product: RTO and RPO gaps, failing DR, mapping gaps, supplier and key-person "
                      "dependencies are all computed across a function's mapped resources. The registry gives it a "
                      "surrogate key."),
            dict(name="Fact Business Impact Analysis", role="Fact", objects=[("37", "Business Impact Analysis")],
                 pk=["Analyzed Business Process", "BIA Date"], grain="one row = business process x BIA date",
                 note="Holds the business RTO and RPO requirement that the application recovery profile is set against."),
            dict(name="Fact Resilience Test", role="Fact", objects=[("37", "Resilience Test")],
                 pk=["Resilience Test Reference", "Resilience Test Date"],
                 grain="one row = resilience test x test date"),
            dict(name="Fact Technical Resilience Test", role="Fact", objects=[("41", "Security & Resilience Test")],
                 pk=["Test Code"], grain="one row = 41 security or resilience test (DR failover, penetration, red team)",
                 note="Achieved recovery time for Mapped Applications Failing DR (CD-270)."),
            dict(name="Critical or Important Function", role="Dimension",
                 objects=[("37", "Critical or Important Function")],
                 pk=["Critical Function Code", "Designating Entity", "Function Effective From"],
                 note="Published for the group: DP-220 conforms it."),
            dict(name="Business Continuity Plan", role="Dimension", objects=[("37", "Business Continuity Plan")],
                 pk=["Business Continuity Plan Code", "Business Continuity Plan Version"]),
            dict(name="Outsourcing Arrangement", role="Dimension", objects=[("40", "Outsourcing Arrangement")],
                 pk=["Outsourcing Arrangement ID"],
                 note="Read only for the functions it supports (CD-261). Own entity: DP-220, which "
                      "publishes the outsourcing register, reads this product."),
            dim("Application", APP, [("41", "Application"), ("41", "Application Recovery Profile")],
                note="Recovery tier, RTO and RPO are 41's, read through DP-211 (CD-270)."),
            dim("IT Service", ITSVC, [("41", "IT Service")]),
            dim("Supplier Engagement", SENG, [("40", "Supplier Engagement")]),
            dim("Supplier Risk Tiering", STIER, [("40", "Supplier Risk Tiering")],
                note="Outrigger of Supplier Engagement: the inherent tier for Critical Supplier Dependencies."),
            dim("Vendor", VENDOR, note="Supplier identity from DP-210 (CD-248)."),
            dim("Workforce Position", WFP, [("20", "Workforce Position")],
                note="Key-person flag read, never copied (CD-249)."),
            dim("Employee", EMP, [("20", "Employee")], note="Plan owner."),
            dim("Office Location", OFFICE, [("09", "Office Location")], note="Mapped site."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Risk Issue", ISSUE, [("37", "Risk Issue")],
                note="Conformed from DP-216; Open Resilience Issues reads DP-216's Remediation Status (CD-356)."),
        ],
        relationships=[
            rel("Resilience Resource Mapping", "Critical or Important Function", ["Mapped Function"]),
            rel("Resilience Resource Mapping", "Application", ["Mapped Application"], optional=True,
                note="One resource reference is filled, as Resilience Resource Type says."),
            rel("Resilience Resource Mapping", "IT Service", ["Mapped IT Service"], optional=True),
            rel("Resilience Resource Mapping", "Supplier Engagement", ["Mapped Supplier Engagement"], optional=True),
            rel("Resilience Resource Mapping", "Workforce Position", ["Mapped Workforce Position"], optional=True),
            rel("Resilience Resource Mapping", "Office Location", ["Mapped Site"], optional=True),
            rel("Fact Business Impact Analysis", "Resilience Resource Mapping", ["Analyzed Business Process"],
                card="M:N", note="Matched to Mapped Business Process: the BIA is keyed by business process text, not "
                                 "by function, so the RTO gap reaches functions only through the mapping (taxonomy gap)."),
            rel("Fact Resilience Test", "Business Continuity Plan", ["Tested Continuity Plan"], optional=True,
                note="Carries the plan code; the version in force on the test date applies."),
            rel("Fact Resilience Test", "Fact Technical Resilience Test", ["Source Security and Resilience Test"],
                optional=True),
            rel("Fact Technical Resilience Test", "Application", ["Tested Applications"], card="M:N", optional=True),
            rel("Fact Technical Resilience Test", "IT Service", ["Tested IT Services"], card="M:N", optional=True),
            rel("Critical or Important Function", "Legal Entity", ["Designating Entity"]),
            rel("Business Continuity Plan", "Employee", ["Plan Owner"], optional=True),
            rel("Outsourcing Arrangement", "Supplier Engagement", ["Outsourcing Engagement"], optional=True),
            rel("Outsourcing Arrangement", "Critical or Important Function", ["Supported Critical or Important Functions"],
                card="M:N"),
            rel("IT Service", "Application", ["Supporting Applications"], card="M:N", optional=True),
            rel("IT Service", "Vendor", ["Third-Party Service Provider"], optional=True),
            rel("Supplier Engagement", "Vendor", ["Engaged Supplier"]),
            rel("Supplier Risk Tiering", "Supplier Engagement", ["Tiered Engagement"]),
            rel("Risk Issue", "Fact Resilience Test", ["Source Resilience Test"], optional=True,
                note="Carries the test reference; the latest run applies."),
        ],
        notes=("W1b re-point (CW-937): Important Business Service, Fact Impact Tolerance and their relationships are "
               "removed with the 37 objects (with Mapped Business Service, Tested Business Service, Related Important "
               "Business Service and 40 Supported Important Business Services); the mapping is keyed on the critical or "
               "important function only, so Mapped Function is now mandatory. WP0 re-scope candidate (CW-041). "
               "Business continuity star centered on the function-to-resource mapping, with BIA, resilience test and 41 "
               "technical test facts. Critical or Important Function is published here as the group's conformed "
               "dimension (DP-220 reads it). Application and IT "
               "Service conform to DP-211, Supplier Engagement, Supplier Risk Tiering and Vendor to DP-210, Workforce "
               "Position and Employee to DP-192, Office Location and Legal Entity to DP-013, and Risk Issue to DP-216. "
               "Mapped Data Asset is not read in Wave E4 (spec note). The BIA joins the mapping on business process text "
               "only (M:N), as the spec's taxonomy gap records."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-218": dict(
        style="Star",
        entities=[
            dict(name="Fact Audit Finding", role="Fact", objects=[("37", "Audit Finding")], pk=["Audit Finding ID"],
                 measures=True, grain="one row = audit finding (AUDF-)",
                 note="Holds the measures; coverage and plan measures are stated over the Auditable Entity and Audit "
                      "Plan dimensions through the engagement."),
            dict(name="Fact Finding Closure Validation", role="Fact", objects=[("37", "Finding Closure Validation")],
                 pk=["Validated Finding", "Validation Attempt Sequence"],
                 grain="one row = audit finding x validation attempt sequence",
                 note="Only a closure validation closes a finding (CD-247); this source-specific status stays here."),
            dict(name="Fact Audit Engagement", role="Fact", objects=[("37", "Audit Engagement")],
                 pk=["Audit Engagement ID"], grain="one row = audit engagement (AUDIT-)",
                 note="Engagement rating distribution and report cycle days."),
            dict(name="Fact Risk Assessment", role="Fact", objects=[("37", "Risk Assessment")],
                 pk=["Assessed Risk", "Risk Assessment Date"], grain="one row = enterprise risk x assessment date",
                 note="Residual risk by org unit for High-Risk Units Not Audited in Cycle; DP-214's assessment read "
                      "for the rating only."),
            dict(name="Auditable Entity", role="Dimension", objects=[("37", "Auditable Entity")],
                 pk=["Auditable Entity Code", "Auditable Entity Effective From"],
                 note="The audit universe at auditable entity x effective period, the coverage grain."),
            dict(name="Audit Plan", role="Dimension", objects=[("37", "Audit Plan")],
                 pk=["Audit Plan Year", "Audit Plan Version"]),
            dict(name="Corporate Resolution Subject Link", role="Bridge",
                 objects=[("39", "Corporate Resolution Subject Link")],
                 pk=["Corporate Resolution Subject Link Key"],
                 grain="one row = corporate resolution x subject record",
                 note="Audit committee approval of the plan is read from its 39 master through Subject Audit Plan; the "
                      "registry gives the link a surrogate key."),
            dict(name="Corporate Resolution", role="Dimension", objects=[("39", "Corporate Resolution")],
                 pk=["Corporate Resolution ID"]),
            dim("Risk Issue", ISSUE, [("37", "Risk Issue")],
                note="Conformed from DP-216: management remediation of a finding; Findings With Overdue Remediation "
                     "reads DP-216's Remediation Status (CD-356)."),
            dim("Enterprise Risk", RISK, [("37", "Enterprise Risk")]),
            dim("Org Unit", ORG, [("09", "Org Unit")]),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Party", PARTY, [("02", "Party")],
                note="Role-playing: covered third party and co-sourced provider (DP-240)."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Role-playing: engagement lead and closure validator."),
            dim("Report Issued Date", CAL),
        ],
        relationships=[
            rel("Fact Audit Finding", "Fact Audit Engagement", ["Finding Engagement"]),
            rel("Fact Finding Closure Validation", "Fact Audit Finding", ["Validated Finding"]),
            rel("Fact Finding Closure Validation", "Employee", ["Closure Validated By"], optional=True),
            rel("Fact Audit Engagement", "Audit Plan", ["Engagement Audit Plan"],
                note="Identifies the plan version the engagement belongs to."),
            rel("Fact Audit Engagement", "Auditable Entity", ["Covered Auditable Entities"], card="M:N",
                note="Carries the auditable entity code; the row in force at fieldwork start applies."),
            rel("Fact Audit Engagement", "Employee", ["Engagement Lead"], optional=True),
            rel("Fact Audit Engagement", "Report Issued Date", ["Audit Report Issued Date"], optional=True),
            rel("Auditable Entity", "Org Unit", ["Covered Org Unit"], optional=True),
            rel("Auditable Entity", "Legal Entity", ["Covered Legal Entity"], optional=True),
            rel("Auditable Entity", "Party", ["Covered Third Party"], optional=True),
            rel("Audit Plan", "Party", ["Co-Sourced Provider"], optional=True),
            rel("Corporate Resolution Subject Link", "Corporate Resolution", ["Linked Corporate Resolution"]),
            rel("Corporate Resolution Subject Link", "Audit Plan", ["Subject Audit Plan"], optional=True,
                note="Identifies the plan version approved."),
            rel("Risk Issue", "Fact Audit Finding", ["Source Audit Finding"], optional=True),
            rel("Enterprise Risk", "Org Unit", ["Risk Owning Org Unit"], optional=True),
            rel("Fact Risk Assessment", "Enterprise Risk", ["Assessed Risk"]),
        ],
        notes=("Internal audit star: finding, closure validation and engagement facts over the audit universe "
               "(Auditable Entity) and Audit Plan, with the plan's audit committee approval through the 39 resolution "
               "subject bridge. Risk Issue conforms to DP-216 and Enterprise Risk to DP-214; the assessment is an own "
               "fact because DP-214 publishes it as a fact, not a dimension. Org Unit, Legal Entity and Report Issued "
               "Date conform to DP-013, Party to DP-240 and Employee to DP-192. Restricted and published outside the "
               "firm-wide semantic model (spec note)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-220": dict(
        style="Star",
        entities=[
            dict(name="Outsourcing Arrangement", role="Fact",
                 objects=[("40", "Outsourcing Arrangement"), ("40", "Exit Plan")], pk=["Outsourcing Arrangement ID"],
                 measures=True,
                 grain="one row = outsourcing arrangement (OUTS-) x effective period (month-end snapshots)",
                 note="The product grain since CW-940 and the register DP-219 conforms for its exit plan. Exit Plan is "
                      "one row per arrangement, so it folds in. Holds the measures."),
            dim("Contract", CONTRACT, [("39", "Contract")], note="The governing contract, from DP-213."),
            dim("Supplier Engagement", SENG, [("40", "Supplier Engagement")]),
            dim("Critical or Important Function", CIF, [("37", "Critical or Important Function")],
                note="Conformed from DP-217, where critical functions and their resilience mapping are published."),
            dim("Party", PARTY, [("02", "Party")],
                note="Role-playing: the engaged supplier (provider) and the alternative providers of the exit plan "
                     "(DP-240)."),
            dim("Party Identifier", PARTY_ID, [("02", "LEI Record")],
                note="Provider LEI (Providers Without LEI), from DP-240."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")],
                note="Role-playing: outsourcing entity, designating entity and contracting entity."),
        ],
        relationships=[
            rel("Outsourcing Arrangement", "Supplier Engagement", ["Outsourcing Engagement"]),
            rel("Outsourcing Arrangement", "Legal Entity", ["Outsourcing Entity"]),
            rel("Outsourcing Arrangement", "Contract", ["Outsourcing Contract"]),
            rel("Outsourcing Arrangement", "Critical or Important Function", ["Supported Critical or Important Functions"],
                card="M:N", optional=True),
            rel("Outsourcing Arrangement", "Party", ["Alternative Providers"], card="M:N", optional=True,
                note="From the folded exit plan."),
            rel("Supplier Engagement", "Party", ["Engaged Supplier"]),
            rel("Critical or Important Function", "Legal Entity", ["Designating Entity"]),
            rel("Contract", "Contract", ["Parent Contract"], optional=True),
            rel("Contract", "Legal Entity", ["Contracting Entity"], optional=True),
            rel("Party Identifier", "Party", ["Party Key"],
                note="Carries the party key as in DP-240 (the LEI Record parent, Party Identifier, is not an input)."),
            rel("Legal Entity", "Party", ["Party Master Cross-Reference"], optional=True,
                note="Intragroup providers are internal legal entities mastered as parties."),
        ],
        notes=("W1b re-point (CW-940, CW-937, CW-914): the DORA register of information leaves the model with its 40 "
               "objects: Fact ICT Register Entry, ICT Register Arrangement Header, Fact Supply Chain Subcontractor, Fact "
               "Outsourcing Notification, the 14 Fact Data Vendor Register Entry, Supplier Contract Profile (its only "
               "inputs were the removed ICT fields), Important Business Service, IT Service, Application and the "
               "Register Reference Date dimension, with their relationships. The outsourcing arrangement becomes the "
               "fact. WP0 re-scope candidate (CW-041). "
               "US outsourcing register: outsourcing arrangements with their exit plan, the critical or important "
               "functions they support (conformed from DP-217), the governing contract (DP-213), the supplier "
               "engagement (DP-210) and the provider party and LEI (DP-240); Legal Entity from DP-013. Outsourcing "
               "Arrangement is published for DP-219. Related Plan Service Arrangement (16) is not an input and is not "
               "modeled."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-219": dict(
        style="Star",
        entities=[
            dict(name="Fact Supplier Oversight", role="Fact", objects=[],
                 pk=["Supplier Engagement Key", "As-of Date Key"], measures=True,
                 grain="one row = supplier engagement (VENG-) x as-of date (current oversight view; month-end snapshots)",
                 note="Oversight spine over the Supplier Engagement dimension; tier, residual rating, contract, exit "
                      "and performance measures are stated per engagement through their child facts."),
            dict(name="Fact Third-Party Risk Assessment", role="Fact", objects=[("37", "Third-Party Risk Assessment")],
                 pk=["Third-Party Risk Assessment Reference"],
                 grain="one row = third party x supplier engagement x assessment cycle",
                 note="The 37 residual rating, shown beside the 40 tier and never copied into it (CD-248)."),
            dict(name="Fact Third-Party Risk Domain Result", role="Fact",
                 objects=[("37", "Third-Party Risk Domain Result")],
                 pk=["Result Assessment", "Third-Party Risk Domain"],
                 grain="one row = third-party risk assessment x risk domain",
                 note="Risk Domain Hotspots. Domain Evidence Assurance Report stays degenerate (14 Assurance Report is "
                      "not an input)."),
            dict(name="Fact Supplier Performance Review", role="Fact", objects=[("40", "Supplier Performance Review")],
                 pk=["Reviewed Engagement", "Review Period End"], grain="one row = supplier engagement x review period"),
            dict(name="Fact Service Level Measurement", role="Fact", objects=[("40", "Service Level Measurement Result")],
                 pk=["Measured Contract", "Measured Metric Name", "Measured Service Level Effective From",
                     "Measurement Period End"],
                 grain="one row = contract x service level metric x measurement period"),
            dict(name="Fact Software License Position", role="Fact", objects=[("41", "Software License Position")],
                 pk=["Licensed Application", "Licensing Metric", "License Measurement Date"],
                 grain="one row = application x licensing metric x measurement date",
                 note="License True-Up Exposure is a quantity (no unit price, taxonomy gap)."),
            dict(name="Fact Vendor Risk Assessment", role="Fact", objects=[("14", "Vendor Risk Assessment")],
                 pk=["Risk Assessment ID"], grain="one row = 14 data vendor risk assessment",
                 note="The 14 inherent rating, shown beside the 40 tier and 37 residual rating (Data Vendor Rating "
                      "Divergence)."),
            dict(name="Fact Payable Invoice", role="Fact", objects=[("19", "Payable Invoice")],
                 pk=["Payable Invoice ID"], grain="one row = payable invoice or credit note",
                 note="Service credits received are credit notes, matched to service level results by supplier and "
                      "date window (taxonomy gap). Read from 19 because no foundational product publishes payables."),
            dict(name="Contracted Service Level", role="Dimension", objects=[("40", "Contracted Service Level")],
                 pk=["Service Level Contract", "Service Level Metric Name", "Service Level Effective From"]),
            dict(name="Data License Agreement", role="Dimension", objects=[("14", "Data License Agreement")],
                 pk=["Data License Agreement ID"]),
            dim("Supplier Engagement", SENG, [("40", "Supplier Engagement")]),
            dim("Supplier Risk Tiering", STIER, [("40", "Supplier Risk Tiering")]),
            dim("Supplier Category Assignment", SCAT, [("40", "Supplier Category Assignment")],
                note="Procurement category by effective period."),
            dim("Supplier Contract Profile", SCP, [("40", "Supplier Contract Profile")],
                note="The only link from an engagement to its governing contract (taxonomy gap)."),
            dim("Vendor", VENDOR, [("02", "Party")],
                note="Supplier identity from DP-210 (Party ID is the DP-240 party key); role-playing for the assessed "
                     "third party and the invoice supplier."),
            dim("Data Vendor", DVEND, [("14", "Data Vendor")],
                note="Data-vendor rows feed the DP-073 view (CD-298, CD-350)."),
            dim("Contract", CONTRACT, [("39", "Contract"), ("39", "Typed Contract Link")],
                note="Typed Contract Link is one row per contract, so it folds in."),
            dim("Contract Key Date", KEYDATE, [("39", "Contract Key Date")],
                note="Outrigger of Contract: notice and expiry dates for Days to Notice Deadline and Renewal "
                     "Attention."),
            dim("Outsourcing Arrangement", OUTS, [("40", "Outsourcing Arrangement"), ("40", "Exit Plan")],
                note="Conformed from DP-220, which masters the register view (CD-261, CD-268)."),
            dim("Risk Issue", ISSUE, [("37", "Risk Issue")],
                note="Conformed from DP-216; Open and Overdue Third-Party Issues read DP-216's Remediation Status "
                     "(CD-356)."),
            dim("Application", APP, note="Licensed application (DP-211)."),
            dim("Legal Entity", LE, [("09", "Internal Legal Entity")]),
            dim("Employee", ("DP-210", "Employee"), [("20", "Employee")],
                note="Conformed from DP-210, which publishes the engagement owner; DP-192 is not upstream of this "
                     "product. Role-playing: business owner and assessor."),
            dim("As-of Date", CAL),
        ],
        relationships=[
            rel("Fact Supplier Oversight", "Supplier Engagement", ["Supplier Engagement Key"],
                note="Carries the Supplier Engagement ID. Model gap: no input carries the snapshot's engagement as its "
                     "own attribute."),
            rel("Fact Supplier Oversight", "As-of Date", ["As-of Date Key"],
                note="Model gap: no input carries the as-of date."),
            rel("Supplier Engagement", "Vendor", ["Engaged Supplier"]),
            rel("Supplier Engagement", "Employee", ["Engagement Business Owner"]),
            rel("Supplier Engagement", "Legal Entity", ["Engagement Buying Entity"]),
            rel("Supplier Engagement", "Data Vendor", ["Specialized Data Vendor"], optional=True),
            rel("Supplier Risk Tiering", "Supplier Engagement", ["Tiered Engagement"]),
            rel("Supplier Category Assignment", "Supplier Engagement", ["Categorized Engagement"]),
            rel("Supplier Contract Profile", "Contract", ["Profiled Contract"], card="1:1"),
            rel("Supplier Contract Profile", "Supplier Engagement", ["Contracted Engagements"], card="M:N"),
            rel("Fact Third-Party Risk Assessment", "Supplier Engagement", ["Assessed Supplier Engagement"]),
            rel("Fact Third-Party Risk Assessment", "Vendor", ["Assessed Third Party"], optional=True),
            rel("Fact Third-Party Risk Assessment", "Employee", ["Third-Party Assessor"], optional=True),
            rel("Fact Third-Party Risk Domain Result", "Fact Third-Party Risk Assessment", ["Result Assessment"]),
            rel("Risk Issue", "Fact Third-Party Risk Assessment", ["Source Third-Party Risk Assessment"], optional=True),
            rel("Fact Supplier Performance Review", "Supplier Engagement", ["Reviewed Engagement"]),
            rel("Contracted Service Level", "Contract", ["Service Level Contract"]),
            rel("Fact Service Level Measurement", "Contract", ["Measured Contract"]),
            rel("Fact Service Level Measurement", "Contracted Service Level",
                ["Measured Metric Name", "Measured Service Level Effective From"],
                note="Joined together with Measured Contract = Service Level Contract; the contract half is drawn to "
                     "Contract."),
            rel("Contract Key Date", "Contract", ["Key Date Contract"]),
            rel("Contract", "Legal Entity", ["Contracting Entity"], optional=True),
            rel("Contract", "Data License Agreement", ["Linked Data License Agreement"], optional=True,
                note="Data-vendor contracts reach their license agreement through the typed contract link."),
            rel("Data License Agreement", "Data Vendor", ["Licensor"]),
            rel("Data Vendor", "Vendor", ["Vendor Party"], card="1:1"),
            rel("Fact Vendor Risk Assessment", "Data Vendor", ["Assessed Vendor"]),
            rel("Outsourcing Arrangement", "Supplier Engagement", ["Outsourcing Engagement"], optional=True),
            rel("Fact Software License Position", "Application", ["Licensed Application"]),
            rel("Fact Software License Position", "Contract", ["Governing Software Contract"], optional=True),
            rel("Fact Payable Invoice", "Vendor", ["Supplier"]),
        ],
        notes=("W1b re-point (CW-940): the conformed ICT Register Arrangement Header and ICT Register Entry and their relationships are removed with the 40 register objects; Exit Readiness Gap reads the Exit Plan folded into the conformed Outsourcing Arrangement. "
               "Third-party oversight spine per supplier engagement and as-of date, with assessment, domain result, "
               "performance review, service level, license position, 14 vendor risk and payable invoice facts. "
               "Supplier Engagement, Supplier Risk Tiering, Supplier Category Assignment, Supplier Contract Profile, "
               "Vendor, Data Vendor and Employee conform to DP-210; Contract and Contract Key Date to DP-213; "
               "Application to DP-211; Outsourcing Arrangement (with its Exit Plan) to DP-220; Risk Issue to DP-216; Legal Entity and As-of Date to DP-013. The supplier party is held on "
               "DP-210 Vendor, whose key is the DP-240 Party ID, so DP-240 adds no separate dimension. "
               "Model gap: the oversight spine borrows Supplier Engagement Key and As-of Date Key. Model gap: Employee "
               "would conform to DP-192, which is not in this product's upstream; it is taken from DP-210. Specialized "
               "Servicing Provider Engagement (13), Specialized Custody Provider Profile (28) and Fund Service Provider "
               "Role (01) stay degenerate because they are not inputs."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-221": dict(
        style="Star",
        entities=[
            dict(name="Fact Invoice Match", role="Fact", objects=[("40", "Invoice Match Result")],
                 pk=["Matched Payable Invoice", "Matched Invoice Line Number", "Matched Purchase Order",
                     "Matched PO Line Number"], measures=True,
                 grain="one row = payable invoice line x purchase order line (latest match run)",
                 note="The product's primary grain; holds the measures. First-pass match needs the product's own "
                      "status history (taxonomy gap)."),
            dict(name="Fact Supplier Spend", role="Fact", objects=[("40", "Supplier Spend Summary")],
                 pk=["Spend Supplier", "Spend Legal Entity", "Spend Fiscal Period"],
                 grain="one row = supplier x buying legal entity x fiscal period",
                 note="Committed, received, invoiced and paid amounts; invoiced and paid reconcile to 19."),
            dict(name="Fact Purchase Order Line", role="Fact", objects=[("40", "Purchase Order Line")],
                 pk=["Line Purchase Order", "PO Line Number"], grain="one row = purchase order x line"),
            dict(name="Fact Goods and Service Receipt", role="Fact", objects=[("40", "Goods and Service Receipt")],
                 pk=["Receipt Purchase Order", "Receipt PO Line Number", "Receipt Sequence"],
                 grain="one row = purchase order line x receipt sequence"),
            dict(name="Fact Sourcing Invitation", role="Fact", objects=[("40", "Sourcing Invitation")],
                 pk=["Invitation Sourcing Event", "Invited Supplier"], grain="one row = sourcing event x invited supplier"),
            dict(name="Fact Sourcing Award", role="Fact", objects=[("40", "Sourcing Award")],
                 pk=["Award Sourcing Event", "Awarded Supplier"], grain="one row = sourcing event x awarded supplier"),
            dict(name="Fact Payable Invoice", role="Fact", objects=[("19", "Payable Invoice")],
                 pk=["Payable Invoice ID"], grain="one row = payable invoice",
                 note="Read from 19 directly: no foundational product publishes payables (spec note)."),
            dict(name="Fact Payable Invoice Line", role="Fact", objects=[("19", "Payable Invoice Line")],
                 pk=["Line Payable Invoice", "Invoice Line Number"], grain="one row = payable invoice x line"),
            dict(name="Fact Supplier Payment", role="Fact", objects=[("19", "Supplier Payment")],
                 pk=["Supplier Payment Document Number"], grain="one row = supplier payment"),
            dict(name="Supplier Payment Application", role="Bridge", objects=[("19", "Supplier Payment Application")],
                 pk=["Applied Supplier Payment", "Settled Payable Invoice"],
                 grain="one row = supplier payment x settled payable invoice",
                 note="One payment settles many invoices and one invoice can be paid in parts."),
            dict(name="Purchase Order", role="Dimension", objects=[("40", "Purchase Order")], pk=["Purchase Order ID"]),
            dict(name="Purchase Requisition", role="Dimension", objects=[("40", "Purchase Requisition")],
                 pk=["Purchase Requisition ID"]),
            dict(name="Sourcing Event", role="Dimension", objects=[("40", "Sourcing Event")], pk=["Sourcing Event ID"]),
            dict(name="Supplier Remittance Detail", role="Dimension", objects=[("40", "Supplier Remittance Detail")],
                 pk=["Remittance Supplier", "Remittance Sequence", "Remittance Effective From"],
                 note="Child of the supplier profile (fold=False); published only here, never on the shared Vendor "
                      "dimension (DP-210 notes)."),
            dim("Vendor", VENDOR, [("40", "Supplier Profile")],
                note="Role-playing: invoice, payment, order, spend, sourcing and remittance supplier (DP-210)."),
            dim("Supplier Engagement", SENG, [("40", "Supplier Engagement")]),
            dim("Supplier Contract Profile", SCP, [("40", "Supplier Contract Profile")],
                note="Total Contract Value for Contract Value Consumption %."),
            dim("Contract", CONTRACT, note="Governing contract (DP-213)."),
            dim("Journal Entry", JOURNAL, [("19", "Journal Entry")]),
            dim("GL Posting", POSTING, [("19", "GL Posting")], note="Invoices Posted to GL % (DP-191, CD-361)."),
            dim("GL Account", GLACCT),
            dim("Cost Center", COSTC),
            dim("Fiscal Period", FISCAL, [("09", "Fiscal Period")]),
            dim("Legal Entity", LE, note="Buying, ordering, invoice and paying legal entity (DP-013)."),
            dim("Employee", EMP, [("20", "Employee")], note="Role-playing: requester, receiver and sourcing owner."),
            dim("Invoice Date", CAL),
        ],
        relationships=[
            rel("Fact Invoice Match", "Fact Payable Invoice", ["Matched Payable Invoice"]),
            rel("Fact Invoice Match", "Fact Payable Invoice Line", ["Matched Invoice Line Number"],
                note="Joined together with Matched Payable Invoice = Line Payable Invoice; the invoice half is drawn "
                     "to Fact Payable Invoice."),
            rel("Fact Invoice Match", "Purchase Order", ["Matched Purchase Order"]),
            rel("Fact Invoice Match", "Fact Purchase Order Line", ["Matched PO Line Number"],
                note="Joined together with Matched Purchase Order = Line Purchase Order."),
            rel("Fact Payable Invoice Line", "Fact Payable Invoice", ["Line Payable Invoice"]),
            rel("Fact Payable Invoice Line", "GL Account", ["Line Expense Account"], optional=True),
            rel("Fact Payable Invoice Line", "Cost Center", ["Line Cost Center"], optional=True,
                note="Carries the cost center segment value code; chart, segment and period in force are implied."),
            rel("Fact Payable Invoice", "Vendor", ["Supplier"]),
            rel("Fact Payable Invoice", "Legal Entity", ["Invoice Legal Entity"]),
            rel("Fact Payable Invoice", "Purchase Order", ["Purchase Order Reference"], optional=True,
                note="Blank on no-PO invoices (No-PO Invoice Spend %)."),
            rel("Fact Payable Invoice", "Invoice Date", ["Invoice Date"]),
            rel("Fact Supplier Payment", "Vendor", ["Payee Supplier"]),
            rel("Fact Supplier Payment", "Legal Entity", ["Paying Legal Entity"]),
            rel("Supplier Payment Application", "Fact Supplier Payment", ["Applied Supplier Payment"]),
            rel("Supplier Payment Application", "Fact Payable Invoice", ["Settled Payable Invoice"]),
            rel("GL Posting", "Journal Entry", ["Journal ID"]),
            rel("GL Posting", "Fact Payable Invoice", ["Source Payable Invoice"], optional=True),
            rel("Purchase Order", "Vendor", ["Ordered Supplier"]),
            rel("Purchase Order", "Legal Entity", ["Ordering Legal Entity"]),
            rel("Purchase Order", "Supplier Engagement", ["Ordered Engagement"], optional=True),
            rel("Purchase Order", "Contract", ["Governing Contract"], optional=True),
            rel("Fact Purchase Order Line", "Purchase Order", ["Line Purchase Order"]),
            rel("Fact Purchase Order Line", "GL Account", ["Line GL Account"], optional=True),
            rel("Fact Purchase Order Line", "Cost Center", ["Line Cost Center"], optional=True),
            rel("Fact Purchase Order Line", "Purchase Requisition", ["Source Requisition"], optional=True),
            rel("Fact Goods and Service Receipt", "Purchase Order", ["Receipt Purchase Order"]),
            rel("Fact Goods and Service Receipt", "Fact Purchase Order Line", ["Receipt PO Line Number"],
                note="Joined together with Receipt Purchase Order = Line Purchase Order."),
            rel("Fact Goods and Service Receipt", "Employee", ["Receiver"], optional=True),
            rel("Purchase Requisition", "Employee", ["Requester"]),
            rel("Purchase Requisition", "Cost Center", ["Requisition Cost Center"], optional=True),
            rel("Sourcing Event", "Employee", ["Sourcing Owner"], optional=True),
            rel("Sourcing Event", "Purchase Requisition", ["Originating Requisition"], optional=True),
            rel("Fact Sourcing Invitation", "Sourcing Event", ["Invitation Sourcing Event"]),
            rel("Fact Sourcing Invitation", "Vendor", ["Invited Supplier"]),
            rel("Fact Sourcing Award", "Sourcing Event", ["Award Sourcing Event"]),
            rel("Fact Sourcing Award", "Vendor", ["Awarded Supplier"]),
            rel("Fact Sourcing Award", "Supplier Engagement", ["Resulting Supplier Engagement"], optional=True),
            rel("Fact Sourcing Award", "Contract", ["Resulting Contract"], optional=True),
            rel("Fact Supplier Spend", "Vendor", ["Spend Supplier"]),
            rel("Fact Supplier Spend", "Legal Entity", ["Spend Legal Entity"]),
            rel("Fact Supplier Spend", "Fiscal Period", ["Spend Fiscal Period"]),
            rel("Supplier Remittance Detail", "Vendor", ["Remittance Supplier"]),
            rel("Supplier Engagement", "Vendor", ["Engaged Supplier"]),
            rel("Supplier Contract Profile", "Contract", ["Profiled Contract"], card="1:1"),
        ],
        notes=("Procure-to-pay star: the invoice match fact at invoice line x PO line, with PO line, receipt, sourcing "
               "invitation and award, payable invoice and line, supplier payment and spend facts, and the payment "
               "application bridge. Vendor, Supplier Engagement and Supplier Contract Profile conform to DP-210, "
               "Contract to DP-213, Journal Entry and GL Posting to DP-191, GL Account and Cost Center to DP-190, "
               "Fiscal Period, Legal Entity and Invoice Date to DP-013, Employee to DP-192. "
               "Model gap: the spec lists a 'Procurement category' dimension but 40 Supplier Category Assignment is not "
               "an input, so no category dimension is drawn. Payable Invoice's Source Data Invoice (14), Source "
               "Intermediary Communication Fee Invoice (05, IFI-, moved from 13 with CW-088) and Source Partner Invoice (05) stay degenerate; they mark "
               "invoices excluded from the no-PO measure."),
    ),
}
