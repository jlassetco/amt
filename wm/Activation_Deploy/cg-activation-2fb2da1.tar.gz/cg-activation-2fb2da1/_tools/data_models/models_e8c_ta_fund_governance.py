"""Logical data models: consumer Star models for Transfer Agency Operations (29) and Fund Governance & Regulatory
Reporting (35), DP-177 to DP-186 (Phase 2, Wave E8). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here. Product
  input objects of the same concept sit on the conformed dimension and merge with its inherited attributes (for example
  27 Share Class NAV's NAV per Share, which DP-165's entity does not carry).
- The source records a product reads from a foundational product (share class NAV, fund NAV, holdings, returns, risk
  exposures, capital accounts) are conformed from that product rather than rebuilt, so they keep one key across the
  taxonomy. Objects another consumer product publishes (29 fund orders read from DP-177, 35 resolutions and meetings
  from DP-182, 31 liquidity and leverage records from DP-155, 30 credit facilities from DP-139, 28 securities loans from
  DP-174, 10 profitability from DP-035, 11 fee studies from DP-030) are built from this product's own inputs and keep
  the registry's natural keys, so they still join to the publishing product.
- Date roles are conformed from DP-013 Calendar Date, whose key is the calendar date itself (the firm business
  calendar), so a date attribute on a fact is the foreign key.
- A reference whose target is outside every model this product can conform from (13 servicing errors and service
  requests, 16 payroll batches, 24 ETF baskets, 26 settlement instructions, 31 and 33 breach records, 36 product
  governance records) stays on the fact as a degenerate key; the notes name each one.
- Where the registry key names two mutually exclusive references (one populated), the key is completed by coalescing the
  populated one, as the registry notes say.
- Multi-valued references (Covered Series, Reported Products, Insured Funds) are drawn as M:N relationships; the build
  explodes them into one row per referenced fund.
"""


def dim(name, src, objects=(), note="", pk=None, role="Dimension", grain=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note)
    if grain:
        d["grain"] = grain
    if pk:
        d["pk"] = list(pk)
    return d


def ent(name, role, objects, pk, grain="", note="", measures=False):
    d = dict(name=name, role=role, objects=list(objects), pk=list(pk), note=note)
    if grain:
        d["grain"] = grain
    if measures:
        d["measures"] = True
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
CAL = ("DP-013", "Calendar Date")
CALENDAR = ("DP-013", "Calendar")
CURRENCY = ("DP-013", "Currency")
ILE = ("DP-013", "Internal Legal Entity")
PARTY = ("DP-240", "Party")
EMP = ("DP-192", "Employee")
ACCT = ("DP-093", "Account")
RESTR = ("DP-093", "Account Restriction")
CNAV = ("DP-165", "Share Class NAV")
FNAV = ("DP-165", "Fund NAV Calculation")
BOOK = ("DP-165", "Fund Accounting Book")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    # 29 Transfer Agency Operations
    # ------------------------------------------------------------------------------------------------------------------
    "DP-177": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Fund Order", "Fact",
                [("29", "Fund Order"), ("29", "Order Routing Detail"), ("29", "As-Of Order Detail")],
                ["Fund Order ID"], measures=True,
                grain="one row = fund order as received and processed by the transfer agent (FNDO-), current version",
                note="The order before execution: receipt and TA timestamps, cut-off result and assigned trade date, "
                     "with the routing codes as delivered and, for as-of and correction orders, the dilution detail "
                     "folded in (both groups are one row per order). Holds the measures because every cut-off, "
                     "forward pricing and as-of test is stated per order. Estimated Order Value is an operational "
                     "estimate and never a flow (CD-199). Model gap: the spec grain names an order version, but no "
                     "input carries a version number, so the fact keeps the current version of each order."),
            ent("Fact Order Event", "Fact", [("29", "Order Event")],
                ["Event Fund Order", "Order Event Type", "Event Timestamp"],
                grain="one row = fund order x order event type x event timestamp",
                note="Order lifecycle events; Straight-Through Processing % reads whether any manual event touched "
                     "the order."),
            ent("Fact Order Exception", "Fact", [("29", "Order Exception")],
                ["Exception Fund Order", "Order Exception Type", "Exception Raised Timestamp"],
                grain="one row = fund order x order exception type x exception raised timestamp",
                note="Open exceptions, resolution time and the blocking account restriction that caused them."),
            ent("Fact Order Interface Session", "Fact", [("29", "Order Interface Session")],
                ["Interface Session Key"],
                grain="one row = order interface session (dealing route x business date x interface cycle)",
                note="The fallback grain for routes that deliver batch totals only; Interface Session Imbalance "
                     "compares Orders Received Count and Session Control Total with the orders linked to the session. "
                     "Session Dealing Route and Interface Cycle stay degenerate."),
            ent("Fact TA Processing Calendar Event", "Fact", [("29", "TA Processing Calendar Event")],
                ["Governing Dealing Calendar", "Event Share Class", "Event Business Date",
                 "Processing Calendar Event Type"],
                grain="one row = dealing calendar (optionally one share class) x business date x processing calendar "
                      "event type",
                note="Early closes and revised cut-offs; Forward Pricing Breaks applies the Revised Cut-Off Time in "
                     "place of the fund cut-off on these dates. Event Share Class is blank for calendar-wide events."),
            # -- bridges
            ent("Exchange Link", "Bridge", [("29", "Exchange Link")], ["Exchange Out Order", "Exchange In Order"],
                grain="one row = outgoing-leg fund order x incoming-leg fund order",
                note="Pairs the two legs of an exchange, conversion or transfer; Unmatched Exchange Legs counts "
                     "exchange orders with no row here."),
            # -- dimensions
            dim("Share Class", SHARE, [("01", "Share Class")]),
            dim("Investment Product", PROD, [("01", "Dealing Terms")],
                note="Dealing Terms fold into the product (one per product) and supply the fund cut-off time, time "
                     "zone and dealing calendar for the forward pricing test."),
            dim("Share Class NAV", CNAV, [("27", "Share Class NAV")],
                note="NAV of record (CD-330); Class Net Assets Amount is the base of As-Of Dilution % of Class Net "
                     "Assets, read on the as-of trade date."),
            dim("Order Account", ACCT, note="Shareholder account of the order (PII)."),
            dim("Blocking Account Restriction", RESTR),
            dim("Receiving Party", PARTY,
                note="The party that first received the order (the fund's designated agent or an intermediary)."),
            dim("Processing Provider", PARTY, note="The transfer agent that processed the order (outsourced TA)."),
            dim("Session Counterparty", PARTY, note="The intermediary or network on the other side of the session."),
            dim("Resolved Dealer", ("DP-001", "Party"),
                note="Distributor firm resolved by 06 identity resolution; Resolved Dealer carries its party ID as a "
                     "key only (spec note)."),
            dim("Employee", EMP, note="Performer of manual order events and approver of as-of orders."),
            dim("Calendar Date", CAL, [("09", "Calendar Date")]),
            dim("Dealing Calendar", CALENDAR),
        ],
        relationships=[
            rel("Fact Fund Order", "Share Class", ["Order Share Class"]),
            rel("Fact Fund Order", "Order Account", ["Order Account"]),
            rel("Fact Fund Order", "Receiving Party", ["Receiving Party"], optional=True),
            rel("Fact Fund Order", "Processing Provider", ["Processing Provider"], optional=True),
            rel("Fact Fund Order", "Resolved Dealer", ["Resolved Dealer"], optional=True,
                note="Blank for direct-at-fund orders."),
            rel("Fact Fund Order", "Calendar Date", ["Trade Date Assigned"]),
            rel("Fact Fund Order", "Calendar Date", ["As-Of Trade Date"], optional=True,
                note="Only as-of and correction orders."),
            rel("Fact Fund Order", "Fact Order Interface Session", ["Receiving Interface Session"], optional=True,
                note="Orders that arrived through a batch interface session."),
            rel("Fact Fund Order", "Fact Fund Order", ["Original Fund Order"], optional=True,
                note="A correction order points to the order it corrects."),
            rel("Fact Fund Order", "Employee", ["As-Of Approver"], optional=True),
            rel("Fact Order Event", "Fact Fund Order", ["Event Fund Order"]),
            rel("Fact Order Event", "Employee", ["Event Performed By"], optional=True,
                note="Blank for system events."),
            rel("Fact Order Exception", "Fact Fund Order", ["Exception Fund Order"]),
            rel("Fact Order Exception", "Blocking Account Restriction", ["Blocking Account Restriction"],
                optional=True),
            rel("Blocking Account Restriction", "Order Account", ["Restricted Account"]),
            rel("Exchange Link", "Fact Fund Order", ["Exchange Out Order"]),
            rel("Exchange Link", "Fact Fund Order", ["Exchange In Order"]),
            rel("Fact Order Interface Session", "Session Counterparty", ["Session Counterparty"], optional=True),
            rel("Fact Order Interface Session", "Calendar Date", ["Session Business Date"]),
            rel("Fact TA Processing Calendar Event", "Dealing Calendar", ["Governing Dealing Calendar"]),
            rel("Fact TA Processing Calendar Event", "Share Class", ["Event Share Class"], optional=True),
            rel("Fact TA Processing Calendar Event", "Calendar Date", ["Event Business Date"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
            rel("Investment Product", "Dealing Calendar", ["Dealing Calendar"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"],
                note="Selected for the order's share class on the as-of trade date."),
        ],
        notes=("Order processing star: the fund order is the spine, with its events, exceptions and exchange legs, the "
               "interface session as the fallback batch grain, and the TA processing calendar for revised cut-offs. "
               "Share class, product and dealing terms are conformed from DP-004, the NAV of record from DP-165, "
               "accounts and restrictions from DP-093, parties from DP-240 (resolved dealer from DP-001), employees "
               "from DP-192 and calendars from DP-013. Resulting Transaction is a degenerate key into DP-006: the "
               "executed transaction is a fact of DP-006, not a dimension, so Processed Orders Without Transaction "
               "is tested by key lookup rather than a join (CD-199). Degenerate references outside this product's "
               "models: Originating Service Request and Related Servicing Error (13, DP-079 and DP-043), Source Plan "
               "Contribution Batch (16, DP-095) and Related NAV Error Case (27; DP-165's model publishes no NAV error "
               "case). Model gap: no order version attribute (see the order fact). Parent NAV Calculation stays an "
               "attribute of Share Class NAV; the fund NAV is not needed for any measure here."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-178": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Settlement Obligation", "Fact", [("29", "Settlement Obligation")], ["Settlement Obligation ID"],
                measures=True,
                grain="one row = settlement obligation (fund order or AP order x obligation sequence)",
                note="Due and actual settlement per obligation for On-Time Settlement %, Late Settlement Days and "
                     "Contractual Date Breaks. Obligation Amount is mastered in 29 (W3, CW-122: no longer a "
                     "derived copy of 06) and never a flow (CD-199)."),
            ent("Fact Settlement Batch", "Fact", [("29", "Intermediary Settlement Batch")], ["Settlement Batch ID"],
                grain="one row = intermediary settlement batch (settling party x settlement date x currency x data "
                      "basis)",
                note="The NSCC or intermediary net settlement; the only grain where obligations are not received. "
                     "Batch Tie-Out compares the batch net amount with its obligations and cash."),
            ent("Fact Cash Movement", "Fact", [("29", "Cash Movement")], ["Cash Movement ID"],
                grain="one row = cash movement",
                note="Payments and receipts that settle a batch or an obligation; Unmatched Cash counts movements "
                     "linked to neither, and Payments Held by Screening reads Payment Screening Result."),
            ent("Fact Settlement Exception", "Fact", [("29", "Settlement Exception")],
                ["Exception Settlement Obligation", "Exception Settlement Batch", "Settlement Exception Type",
                 "Exception Detected Date"],
                grain="one row = settlement obligation or settlement batch x settlement exception type x exception "
                      "detected date",
                note="Exactly one of the obligation and batch references is populated; the key coalesces them "
                     "(registry note)."),
            # -- dimensions
            ent("Fund Order", "Dimension", [("29", "Fund Order")], ["Fund Order ID"],
                note="Read from DP-177, which publishes the fund order; built from this product's inputs and keyed "
                     "by the same Fund Order ID so it joins back to DP-177."),
            dim("Share Class", SHARE),
            dim("Investment Product", PROD, [("01", "Dealing Terms")],
                note="Subscription and Redemption Settlement Periods set the contractual date tested by Contractual "
                     "Date Breaks."),
            dim("Fund Cash Account", ("DP-167", "Safekeeping Account"), [("28", "Safekeeping Account")],
                note="Fund cash accounts are 28 safekeeping accounts; corporate bank accounts are 43 (CD-274)."),
            dim("Custodian", PARTY, note="Account Provider of the fund cash account."),
            dim("Settling Party", PARTY,
                note="The intermediary or clearing party that pays or receives, for obligations and batches."),
            dim("Processing Provider", PARTY, note="The transfer agent named on the fund order."),
            dim("Currency", CURRENCY),
            dim("Calendar Date", CAL, [("09", "Calendar Date")]),
        ],
        relationships=[
            rel("Fact Settlement Obligation", "Fund Order", ["Obligation Fund Order"], optional=True,
                note="Blank on AP cash-leg obligations, which carry Obligation AP Order instead."),
            rel("Fact Settlement Obligation", "Fact Settlement Batch", ["Obligation Settlement Batch"], optional=True,
                note="Only obligations settled net through a batch."),
            rel("Fact Settlement Obligation", "Settling Party", ["Settling Party"], optional=True),
            rel("Fact Settlement Obligation", "Calendar Date", ["Contractual Settlement Date"]),
            rel("Fact Settlement Obligation", "Calendar Date", ["Actual Settlement Date"], optional=True),
            rel("Fact Settlement Batch", "Settling Party", ["Batch Settling Party"]),
            rel("Fact Settlement Batch", "Calendar Date", ["Batch Settlement Date"]),
            rel("Fact Settlement Batch", "Currency", ["Batch Currency"]),
            rel("Fact Cash Movement", "Fact Settlement Batch", ["Settled Batch"], optional=True),
            rel("Fact Cash Movement", "Fact Settlement Obligation", ["Settled Obligation"], optional=True),
            rel("Fact Cash Movement", "Fund Cash Account", ["Fund Cash Account"], optional=True,
                note="Cash Through Non-Fund Accounts counts movements whose account is not a fund cash account."),
            rel("Fact Cash Movement", "Currency", ["Payment Currency"]),
            rel("Fact Cash Movement", "Calendar Date", ["Payment Value Date"]),
            rel("Fact Settlement Exception", "Fact Settlement Obligation", ["Exception Settlement Obligation"],
                optional=True),
            rel("Fact Settlement Exception", "Fact Settlement Batch", ["Exception Settlement Batch"], optional=True),
            rel("Fact Settlement Exception", "Calendar Date", ["Exception Detected Date"]),
            rel("Fund Order", "Share Class", ["Order Share Class"]),
            rel("Fund Order", "Processing Provider", ["Processing Provider"], optional=True),
            rel("Fund Order", "Calendar Date", ["Trade Date Assigned"]),
            rel("Fund Cash Account", "Custodian", ["Account Provider"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Settlement star with four facts at their own grains (obligation, intermediary batch, cash movement, "
               "exception) that share the fund order, share class, party, cash account, currency and date "
               "dimensions. The obligation level and the batch level are both kept because NSCC net settlement may "
               "deliver only the batch (spec note). Fund Order is built from the inputs because DP-177, which "
               "publishes it, is a consumer product. Obligation AP Order stays a degenerate key: AP orders are "
               "published by DP-179, which reads the AP cash-leg obligations from this product. Share class and "
               "dealing terms are conformed from DP-004, the fund cash account from DP-167, the bank instruction "
               "from DP-093, parties from DP-240 and currency and dates from DP-013. DP-001 is upstream for the "
               "settling intermediary's distributor hierarchy; the settling party is conformed from DP-240, which "
               "masters every party, so the hierarchy is reached through the shared Party ID."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-179": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact AP Order", "Fact", [("29", "AP Creation / Redemption Order"), ("29", "AP Order Fee")],
                ["AP Order ID"], measures=True,
                grain="one row = authorized participant creation or redemption order (ECR-)",
                note="AP Order Fee folds in (one fee and collateral set per order). Order Value at NAV multiplies "
                     "creation units and unit size by the NAV of record on the trade date. Not a flow source (CD-200)."),
            ent("Fact Basket Settlement Line", "Fact", [("29", "Basket Settlement Line")],
                ["Line AP Order", "Basket Constituent"],
                grain="one row = AP order x basket constituent",
                note="In-kind delivery per constituent for Basket Delivery Completion %, Failed Basket Deliveries and "
                     "Cash in Lieu Share."),
            ent("Fact AP Cash Leg Obligation", "Fact", [("29", "Settlement Obligation")], ["Settlement Obligation ID"],
                grain="one row = settlement obligation of an AP order's cash leg (AP order x obligation sequence)",
                note="Read from DP-178 for AP Cash Leg On-Time %; only rows with Obligation AP Order filled are in "
                     "scope (spec note)."),
            ent("Fact AP Settlement Exception", "Fact", [("29", "Settlement Exception")],
                ["Fact AP Settlement Exception Key"],
                grain="one row = AP cash-leg settlement obligation x settlement exception type x exception detected "
                      "date",
                note="Feeds Collateral Coverage of Shortfall. Model gap: the registry key also needs Exception "
                     "Detected Date (and the batch reference, blank for AP obligations), which are not inputs, so a "
                     "surrogate key stands in; adding Exception Detected Date to the spec restores the natural key."),
            # -- dimensions
            dim("ETF Share Class", SHARE),
            dim("Investment Product", PROD, [("01", "ETF Characteristics")],
                note="ETF Characteristics fold into the product and supply Creation Unit Size."),
            dim("Share Class NAV", CNAV, [("27", "Share Class NAV")],
                note="NAV per Share of record (CD-330) for Order Value at NAV and Cash Component Variance."),
            dim("Authorized Participant", ("DP-115", "Counterparty"),
                note="Authorized participants are 02 parties joined to DP-115 where also approved counterparties "
                     "(spec note); AP Concentration ranks them."),
            dim("AP Agreement", ("DP-005", "Distribution Agreement"),
                note="The AP agreement is a 05 agreement (DP-005)."),
            dim("Processing Provider", PARTY,
                note="The TA, custodian or distributor portal that processed the AP order."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact AP Order", "ETF Share Class", ["ETF Share Class"]),
            rel("Fact AP Order", "Authorized Participant", ["Authorized Participant"]),
            rel("Fact AP Order", "AP Agreement", ["AP Agreement"], optional=True),
            rel("Fact AP Order", "Processing Provider", ["AP Order Processing Provider"], optional=True),
            rel("Fact AP Order", "Calendar Date", ["AP Order Trade Date"]),
            rel("Fact AP Order", "Calendar Date", ["AP Order Settlement Date"], optional=True),
            rel("Fact Basket Settlement Line", "Fact AP Order", ["Line AP Order"]),
            rel("Fact AP Cash Leg Obligation", "Fact AP Order", ["Obligation AP Order"]),
            rel("Fact AP Cash Leg Obligation", "Calendar Date", ["Contractual Settlement Date"]),
            rel("Fact AP Cash Leg Obligation", "Calendar Date", ["Actual Settlement Date"], optional=True),
            rel("Fact AP Settlement Exception", "Fact AP Cash Leg Obligation", ["Exception Settlement Obligation"]),
            rel("ETF Share Class", "Investment Product", ["Parent Product"]),
            rel("Share Class NAV", "ETF Share Class", ["NAV Share Class"],
                note="Selected for the order's share class on the AP order trade date."),
        ],
        notes=("AP order star: the AP order with its basket settlement lines, cash-leg obligations and their "
               "exceptions, sharing the ETF share class, product, NAV of record, authorized participant, AP agreement "
               "and date dimensions. Conformed from DP-004 (share class, product, ETF characteristics), DP-165 (NAV), "
               "DP-115 (authorized participant as counterparty), DP-005 (AP agreement), DP-240 (processor) and DP-013 "
               "(dates). The cash-leg obligations and exceptions are 29 records published by DP-178, built here from "
               "the inputs. AP Resulting Transaction is a degenerate key into DP-006 (the executed transaction is "
               "DP-006's fact), used by Settled Orders Without Transaction. "
               "Model gap: Applied ETF Basket and Basket Constituent reference 24 ETF Basket and ETF Basket "
               "Constituent, published by DP-131, but the spec reads no 24 attributes, so they stay degenerate keys "
               "and the basket constituent's instrument (the spec's DP-097 dimension) cannot be reached; adding the "
               "DP-131 basket constituent (with its instrument) to the inputs would let Basket Constituent join to an "
               "own basket dimension and on to DP-097 Instrument. Line Delivery Settlement references 26 Settlement "
               "Instruction, which no model this product reads publishes (DP-147 holds standing instructions only); "
               "it stays degenerate. DP-147 and DP-178 are upstream through those records."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-180": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Account Monitoring Alert", "Fact",
                [("29", "Account Monitoring Alert"), ("29", "Alert Disposition")], ["Account Monitoring Alert ID"],
                measures=True,
                grain="one row = account monitoring alert (AMA-) with its disposition",
                note="The alert of record (CD-332). Alert Disposition folds in (one review and decision per alert, "
                     "two review levels). Restricted - Legal fields (disposition value, rationale, status and "
                     "Escalation Case Reference) are withheld from the de-identified backlog view."),
            ent("Fact Identity Verification", "Fact", [("02", "Identity Verification")], ["Identity Verification ID"],
                grain="one row = party x CIP program x verification (KYCV-)",
                note="W3 re-point (CW-124): the 02 identity verification replaces the removed 29 CIP Verification; pass "
                     "rate, turnaround, government list coverage and accounts opened without verification. Read from 02 "
                     "(DP-077 was pending when this model was cut), so built from the input."),
            # -- dimensions
            ent("Fund Order", "Dimension", [("29", "Fund Order")], ["Fund Order ID"],
                note="Order that triggered the alert, read from DP-177 and keyed by its Fund Order ID."),
            ent("Cash Movement", "Dimension", [("29", "Cash Movement")], ["Cash Movement ID"],
                note="Payment that triggered the alert, read from DP-178; Released Before Disposition compares its "
                     "settlement with the disposition date."),
            dim("Account", ACCT, [("15", "Account"), ("15", "Account Opening")],
                note="Account Opening (1:1 group of the account) folds here with its Opening Identity Verification."),
            dim("Account Restriction", RESTR, [("15", "Account Restriction")],
                note="Restrictions placed after an unverified opening or an alert; Unverified Accounts Not Restricted looks for none."),
            dim("Party", PARTY, [("02", "KYC Profile")],
                note="Alert subject and verified party. KYC Profile folds into the party (current profile) and is "
                     "read from DP-077 for the AML risk rating only; it is never republished (spec note)."),
            dim("Employee", EMP, note="Alert reviewer and second reviewer."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Account Monitoring Alert", "Account", ["Alert Account"]),
            rel("Fact Account Monitoring Alert", "Party", ["Alert Subject Party"], optional=True),
            rel("Fact Account Monitoring Alert", "Fund Order", ["Triggering Fund Order"], optional=True),
            rel("Fact Account Monitoring Alert", "Cash Movement", ["Triggering Cash Movement"], optional=True),
            rel("Fact Account Monitoring Alert", "Employee", ["Alert Reviewer"], optional=True,
                note="Blank where the outsourced TA's analyst made the first review (SME question 5)."),
            rel("Fact Account Monitoring Alert", "Employee", ["Second Reviewer"], optional=True),
            rel("Fact Account Monitoring Alert", "Account Restriction", ["Alert Resulting Account Restriction"],
                optional=True),
            rel("Fact Account Monitoring Alert", "Calendar Date", ["Disposition Date"], optional=True,
                note="Blank while the alert is open."),
            rel("Fact Identity Verification", "Party", ["Verified Party"]),
            rel("Fact Identity Verification", "Calendar Date", ["Verification Date"], optional=True),
            rel("Account", "Fact Identity Verification", ["Opening Identity Verification"], optional=True,
                note="The verification relied on at account opening (15 Account Opening)."),
            rel("Account Restriction", "Account", ["Restricted Account"]),
            rel("Fund Order", "Calendar Date", ["Trade Date Assigned"]),
            rel("Cash Movement", "Calendar Date", ["Payment Value Date"]),
        ],
        notes=("Account monitoring star: the alert with its disposition and the 02 identity verification (W3, CW-124) as a companion fact, "
               "sharing the account, party, restriction, employee and date dimensions. Account and restriction are "
               "conformed from DP-093, party from DP-240 (with the DP-077 KYC profile merged), employees from DP-192 "
               "and dates from DP-013. Fund orders and cash movements are 29 records published by DP-177 and DP-178, "
               "built here from the inputs. Escalation Case Reference is a degenerate key into 38 AML Case and is "
               "never published outside the AML unit. DP-085 is upstream as a signal source only; no attribute links "
               "an alert to its pattern flag (spec taxonomy gap), so it is not joined."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-181": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact TA Control Check", "Fact", [("29", "TA Control Check")], ["TA Control Check ID"],
                measures=True,
                grain="one row = TA control check (TACK-): TA control type x share class (or fund) x business date",
                note="Daily control results and the firm's sign-off. Fund-level checks leave Control Share Class "
                     "blank and fill Control Fund."),
            ent("Fact TA Control Exception", "Fact", [("29", "TA Control Exception")],
                ["Exception Control Check", "Control Exception Number"],
                grain="one row = TA control check x control exception number",
                note="Explains a control difference; Exception Explanation Tie-Out sums Exception Difference Value "
                     "against the check's Control Difference."),
            # -- dimensions
            dim("Share Class NAV", CNAV, [("27", "Share Class NAV")],
                note="The NAV record a capital stock proof is compared against (CD-330); Shares Outstanding is the "
                     "comparison value."),
            dim("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")],
                note="Proofs Not Against NAV of Record reads its calculation source, version and approval status."),
            dim("Share Class", SHARE, [("01", "Share Class")]),
            dim("Investment Product", PROD),
            dim("Processing Provider", PARTY, note="The TA whose daily control report is the source."),
            dim("Employee", EMP, note="Sign-off and exception owner."),
            dim("Calendar Date", CAL, [("09", "Calendar Date")]),
        ],
        relationships=[
            rel("Fact TA Control Check", "Share Class", ["Control Share Class"], optional=True),
            rel("Fact TA Control Check", "Investment Product", ["Control Fund"], optional=True,
                note="Fund-level checks."),
            rel("Fact TA Control Check", "Share Class NAV", ["Compared NAV Record"], optional=True,
                note="Only checks compared with a NAV record (capital stock proof)."),
            rel("Fact TA Control Check", "Processing Provider", ["Control Processing Provider"], optional=True),
            rel("Fact TA Control Check", "Employee", ["Control Signed Off By"], optional=True),
            rel("Fact TA Control Check", "Calendar Date", ["Control Business Date"]),
            rel("Fact TA Control Exception", "Fact TA Control Check", ["Exception Control Check"]),
            rel("Fact TA Control Exception", "Employee", ["Control Exception Owner"], optional=True),
            rel("Fact TA Control Exception", "Calendar Date", ["Control Exception Resolved Date"], optional=True),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("TA controls star: the daily control check with its exceptions, against the NAV of record conformed "
               "from DP-165 (share class NAV and its fund NAV calculation), share class and fund from DP-004, the "
               "provider from DP-240, employees from DP-192 and the business calendar from DP-013. Exception Related "
               "Fund Order is a degenerate key into DP-177's fund orders (no 29 Fund Order attribute is an input) and "
               "Exception Servicing Error into 13 (DP-043). DP-178 is upstream for the cash proof through the "
               "control values; no 29 settlement object is an input."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    # 35 Fund Governance & Regulatory Reporting
    # ------------------------------------------------------------------------------------------------------------------
    "DP-182": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Resolution Subject", "Fact", [("35", "Resolution Subject Link")],
                ["Fact Resolution Subject Key"], measures=True,
                grain="one row = board resolution x approved subject",
                note="The approval of record per subject, the source of the derived Board Approval Status that 31, "
                     "33, 34 and 36 products read (CD-237). Surrogate key as in the registry (the subject is one of "
                     "sixteen typed references). Holds the measures; the companion facts feed the body, meeting, "
                     "report, bond and relief measures."),
            ent("Fact Fund Coverage", "Fact", [("35", "Governed Fund Coverage")],
                ["Coverage Governing Body", "Governed Product", "Coverage Effective From"],
                grain="one row = governing body x governed fund x coverage effective period",
                note="Effective-dated coverage; Funds Without Governing Body looks for funds with no current row."),
            ent("Fact Membership", "Fact", [("35", "Governing Body Membership")],
                ["Membership Governing Body", "External Member Party", "Interested Member Employee", "Member Role",
                 "Membership Effective From"],
                grain="one row = governing body x member (external party or interested employee) x member role x "
                      "effective period",
                note="Independent Member % and Departed Interested Members. The member is one of the two references "
                     "(coalesced in the key)."),
            ent("Fact Officer Appointment", "Fact", [("35", "Fund Officer Appointment")],
                ["Officer Registrant", "Officer Entity", "Fund Officer Role", "Appointed Officer",
                 "External Officer Party", "Officer Effective From"],
                grain="one row = registrant or entity x fund officer role x officer (employee or external party) x "
                      "effective period",
                note="Officers DP-184 reads to check certifier authority."),
            ent("Fact Governance Standards", "Fact", [("35", "Governance Standards Profile")],
                ["Governing Body Key", "Standards Assessment Date"],
                grain="one row = governing body x standards assessment date",
                note="Child group of the governing body; carries the body's key with the assessment date."),
            ent("Fact Agenda Item", "Fact", [("35", "Board Agenda Item")], ["Agenda Meeting", "Agenda Item Number"],
                grain="one row = board meeting x agenda item number"),
            ent("Fact Board Report Received", "Fact", [("35", "Board Report Received")],
                ["Fact Board Report Received Key"],
                grain="one row = board meeting x board report type x report period x reported funds or risk program",
                note="Surrogate key as in the registry (reported funds are multi-valued). Required Reports Received % "
                     "and Material Matters Reported."),
            ent("Fact Board Report Source Item", "Fact", [("35", "Board Report Source Item")],
                ["Fact Board Report Received Key", "Related Investment Breach", "Related Risk Limit Exceedance",
                 "Related Fair Value Determination", "Source Record Description"],
                grain="one row = board report received x source record (breach, exceedance or fair value "
                      "determination)",
                note="Child group of the report; references to 33, 31 and 22 records stay degenerate keys and their "
                     "measures are never copied (CD-234)."),
            ent("Fact Self-Assessment", "Fact", [("35", "Board Self-Assessment")],
                ["Assessed Governing Body", "Assessment Year"],
                grain="one row = governing body x assessment year", note="Self-Assessments Overdue."),
            ent("Fact Fidelity Bond", "Fact", [("35", "Fund Fidelity Bond")],
                ["Fidelity Bond Policy Number", "Coverage Period Start"],
                grain="one row = fidelity bond policy x coverage period",
                note="Fidelity Bond Shortfall compares Bond Coverage Amount with the Rule 17g-1 minimum. Bond Filing "
                     "is a degenerate key into DP-184's filings."),
            ent("Fact Exemptive Relief Reliance", "Fact", [("35", "Exemptive Relief Reliance")],
                ["Relying Fund", "Exemptive Relief Type", "Order or Rule Citation", "Reliance Effective From"],
                grain="one row = relying fund x exemptive relief type x order or rule citation x effective period",
                note="Relief Without Board Finding looks for reliance with no finding resolution."),
            # -- dimensions
            ent("Governing Body", "Dimension", [("35", "Fund Governing Body")], ["Governing Body ID"],
                note="Published here (consumer-published under the brief, spec note); the dimension other "
                     "governance consumers conform to if it is promoted."),
            ent("Board Meeting", "Dimension", [("35", "Board Meeting")], ["Board Meeting ID"],
                note="Meetings and Quorum and Minutes Pending Approval read its indicators."),
            ent("Board Resolution", "Dimension",
                [("35", "Board Resolution"), ("35", "Resolution Vote Count")],
                ["Board Resolution ID"],
                note="Vote Count folds in (one per resolution) for Independent Majority Failures. Board Consent Record "
                     "(LPAC consents) left with 30 (W4, CW-930)."),
            dim("Investment Product", PROD),
            dim("Share Class", SHARE, [("01", "Share Class")]),
            dim("Internal Legal Entity", ILE,
                note="Governed entity (series trust or corporation, CIT trustee) and officer entity."),
            dim("Party", PARTY,
                note="External members, external officers, trustee parties and the bond insurer."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Interested members and appointed officers; Employment Status flags departed interested "
                     "members."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Resolution Subject", "Board Resolution", ["Linked Resolution"]),
            rel("Fact Resolution Subject", "Investment Product", ["Subject Product"], optional=True),
            rel("Fact Resolution Subject", "Share Class", ["Subject Share Class"], optional=True),
            rel("Board Resolution", "Board Meeting", ["Adopting Meeting"]),
            rel("Board Resolution", "Board Resolution", ["Superseded Resolution"], optional=True),
            rel("Board Resolution", "Calendar Date", ["Resolution Effective Date"]),
            rel("Board Meeting", "Governing Body", ["Meeting Governing Body"]),
            rel("Board Meeting", "Calendar Date", ["Meeting Date"]),
            rel("Governing Body", "Governing Body", ["Parent Governing Body"], optional=True,
                note="Committees roll up to their board."),
            rel("Governing Body", "Investment Product", ["Governed Registrant"], optional=True),
            rel("Governing Body", "Internal Legal Entity", ["Governed Entity"], optional=True),
            rel("Governing Body", "Party", ["Governed Trustee Party"], optional=True,
                note="A third-party trustee governing a fund (spec operating model)."),
            rel("Fact Fund Coverage", "Governing Body", ["Coverage Governing Body"]),
            rel("Fact Fund Coverage", "Investment Product", ["Governed Product"]),
            rel("Fact Membership", "Governing Body", ["Membership Governing Body"]),
            rel("Fact Membership", "Party", ["External Member Party"], optional=True),
            rel("Fact Membership", "Employee", ["Interested Member Employee"], optional=True),
            rel("Fact Officer Appointment", "Investment Product", ["Officer Registrant"], optional=True),
            rel("Fact Officer Appointment", "Internal Legal Entity", ["Officer Entity"], optional=True),
            rel("Fact Officer Appointment", "Employee", ["Appointed Officer"], optional=True),
            rel("Fact Officer Appointment", "Party", ["External Officer Party"], optional=True),
            rel("Fact Officer Appointment", "Board Resolution", ["Appointing Resolution"], optional=True),
            rel("Fact Governance Standards", "Governing Body", ["Governing Body Key"]),
            rel("Fact Agenda Item", "Board Meeting", ["Agenda Meeting"]),
            rel("Fact Board Report Received", "Board Meeting", ["Receiving Meeting"]),
            rel("Fact Board Report Received", "Investment Product", ["Reported Products"], card="M:N", optional=True,
                note="Multi-valued: one row per reported fund after the build explodes the list."),
            rel("Fact Board Report Source Item", "Fact Board Report Received", ["Fact Board Report Received Key"]),
            rel("Fact Self-Assessment", "Governing Body", ["Assessed Governing Body"]),
            rel("Fact Fidelity Bond", "Investment Product", ["Insured Funds"], card="M:N",
                note="Multi-valued: a joint insured bond covers several funds."),
            rel("Fact Fidelity Bond", "Party", ["Bond Insurer"]),
            rel("Fact Fidelity Bond", "Board Resolution", ["Bond Approving Resolution"], optional=True),
            rel("Fact Exemptive Relief Reliance", "Investment Product", ["Relying Fund"]),
            rel("Fact Exemptive Relief Reliance", "Board Resolution", ["Board Finding Resolution"], optional=True),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Board governance star around the resolution x subject fact, with the governing body, meeting and "
               "resolution as this product's own dimensions (35 is published here, not in a foundational product) "
               "and effective-dated companion facts for coverage, membership, officers, standards, agenda, reports "
               "received, self-assessments, fidelity bonds and exemptive relief. Funds and share classes are "
               "conformed from DP-004, legal entities from DP-013, parties from DP-240 and employees from DP-192. "
               "Resolution subjects other than a fund or share class (advisory agreement, service provider role, "
               "product proposal, change initiative, product review, voting policy, HLIM, risk program designation, "
               "guideline waiver, proxy voting report, shareholder communication, financial statement, RIC tax year) "
               "stay degenerate typed keys into the products that publish them, as do Reported Risk Program and the "
               "board report source items. Two keys are surrogates because the registry keys them so: Resolution "
               "Subject Link and Board Report Received (their natural grains include multi-valued or typed "
               "references)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-183": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Agreement Fund Schedule", "Fact", [("35", "Agreement Fund Schedule")],
                ["Schedule Agreement", "Covered Fund", "Schedule Renewal"], measures=True,
                grain="one row = advisory agreement (ADVA-) x covered fund x approval cycle (initial approval or "
                      "RENEW- renewal)",
                note="Approval outcome and continuation end date per fund per cycle; initial approvals leave Schedule "
                     "Renewal blank. Holds the measures (continuations due and lapsed, shareholder approval, cited "
                     "figures read through the renewal's material items)."),
            ent("Fact Advisory Contract Renewal", "Fact", [("35", "Advisory Contract Renewal")], ["Renewal ID"],
                grain="one row = advisory agreement x renewal year (RENEW-)",
                note="Materials lead time (15(c) request to delivery) and the approving resolution."),
            ent("Fact Renewal Material Item", "Fact", [("35", "Renewal Material Item")],
                ["Material Renewal", "Renewal Material Type", "Source Fee Benchmark Study", "Source Peer Universe",
                 "Source Profitability Record", "Source Performance Return", "Source Benchmark Return"],
                grain="one row = renewal x material type x cited source record",
                note="Links each renewal to the figures the board saw; the cited values are snapshotted at Materials "
                     "Delivered Date and never recalculated (CD-330, CD-334)."),
            ent("Fact 15(c) Finding", "Fact", [("35", "Board 15(c) Finding")], ["Finding Renewal", "15(c) Factor"],
                grain="one row = renewal x 15(c) factor",
                note="Counted, not scored (spec taxonomy gap)."),
            ent("Fact Exemptive Relief Reliance", "Fact", [("35", "Exemptive Relief Reliance")],
                ["Relying Fund", "Exemptive Relief Type", "Reliance Effective From"],
                grain="one row = relying fund x exemptive relief type x effective period",
                note="Manager-of-managers relief that lets a sub-advisory agreement be approved without a "
                     "shareholder vote (Missing Shareholder Approval). Model gap: the registry key also has Order or "
                     "Rule Citation, which is not an input; two citations of the same relief type for one fund in "
                     "the same period would collide."),
            # -- dimensions
            ent("Advisory Agreement", "Dimension", [("35", "Fund Advisory Agreement")], ["Advisory Agreement ID"],
                note="Adviser and sub-advisory agreements; a sub-advisory agreement points to its parent agreement. "
                     "DP-213 indexes it as a contract type without re-mastering it; no input links it to a DP-213 "
                     "contract, so DP-213 Contract is not joined."),
            ent("Board Resolution", "Dimension", [("35", "Board Resolution"), ("35", "Resolution Vote Count")],
                ["Board Resolution ID"],
                note="Approving resolution read from DP-182; Vote Count folds in and supplies Independent Approval."),
            ent("Board Meeting", "Dimension", [("35", "Board Meeting")], ["Board Meeting ID"],
                note="Approving meeting read from DP-182 (in-person requirement through Meeting Format)."),
            ent("Fee Benchmark Study", "Dimension", [("11", "Fee Benchmark Study"), ("11", "Fee Benchmark Result")],
                ["Fee Study ID"],
                note="Peer fee study read from DP-030; Fee Benchmark Result folds in and supplies Peer Median Fee "
                     "for Net Expense Ratio vs Peer Median."),
            ent("Profitability Record", "Dimension",
                [("10", "Profitability Record"), ("10", "Profitability Measure")], ["Profitability Record ID"],
                note="Adviser profitability read from DP-035 at share class grain only; Profitability Measure folds "
                     "in (Adviser Margin (Cited))."),
            dim("Performance Return", ("DP-145", "Performance Return"), [("32", "Performance Return")],
                note="Official share class return cited in the materials (CD-320)."),
            dim("Benchmark Return", ("DP-145", "Benchmark Return"), [("32", "Benchmark Return")]),
            dim("Benchmark", ("DP-145", "Benchmark")),
            dim("Fund Financial Statement", ("DP-165", "Fund Financial Statement"),
                note="The audited statement set that holds the financial highlights."),
            dim("Financial Highlights", ("DP-165", "Financial Highlights"), [("27", "Financial Highlights")],
                pk=["Fund Financial Statement Key", "Highlights Share Class"],
                note="Audited gross and net expense ratios per share class (CD-330)."),
            dim("Expense Cap & Waiver Accrual", ("DP-165", "Expense Cap & Waiver Accrual"),
                [("27", "Expense Cap & Waiver Accrual")],
                note="Waivers in Renewal Year sums the accruals dated in the renewal year. DP-170 owns the fund side "
                     "of waivers (CD-188); the accrual record itself is published by DP-165, so it is conformed "
                     "from there."),
            dim("Share Class NAV", CNAV, [("27", "Share Class NAV")],
                note="Class net assets at renewal (Fund Net Assets at Renewal)."),
            dim("Share Class", SHARE, [("01", "Share Class")]),
            dim("Investment Product", PROD),
            dim("Adviser Entity", ILE, note="The firm's advisory entity party to the agreement."),
            dim("Party", PARTY, note="External sub-adviser and materials preparer."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Agreement Fund Schedule", "Advisory Agreement", ["Schedule Agreement"]),
            rel("Fact Agreement Fund Schedule", "Investment Product", ["Covered Fund"]),
            rel("Fact Agreement Fund Schedule", "Fact Advisory Contract Renewal", ["Schedule Renewal"], optional=True,
                note="Blank for the initial approval cycle."),
            rel("Fact Agreement Fund Schedule", "Calendar Date", ["Fund Continuation End Date"], optional=True),
            rel("Advisory Agreement", "Advisory Agreement", ["Parent Advisory Agreement"], optional=True),
            rel("Advisory Agreement", "Adviser Entity", ["Adviser Entity"]),
            rel("Advisory Agreement", "Party", ["External Sub-Adviser"], optional=True),
            rel("Fact Advisory Contract Renewal", "Advisory Agreement", ["Renewed Agreement"]),
            rel("Fact Advisory Contract Renewal", "Party", ["Materials Preparer"], optional=True,
                note="A vendor that prepares the 15(c) materials (SME question 2)."),
            rel("Fact Advisory Contract Renewal", "Board Resolution", ["Renewal Approving Resolution"],
                optional=True),
            rel("Fact Advisory Contract Renewal", "Calendar Date", ["Materials Delivered Date"], optional=True),
            rel("Fact Renewal Material Item", "Fact Advisory Contract Renewal", ["Material Renewal"]),
            rel("Fact Renewal Material Item", "Fee Benchmark Study", ["Source Fee Benchmark Study"], optional=True),
            rel("Fact Renewal Material Item", "Profitability Record", ["Source Profitability Record"], optional=True),
            rel("Fact Renewal Material Item", "Performance Return", ["Source Performance Return"], optional=True),
            rel("Fact Renewal Material Item", "Benchmark Return", ["Source Benchmark Return"], optional=True),
            rel("Fact 15(c) Finding", "Fact Advisory Contract Renewal", ["Finding Renewal"]),
            rel("Fact Exemptive Relief Reliance", "Investment Product", ["Relying Fund"]),
            rel("Board Resolution", "Board Meeting", ["Adopting Meeting"]),
            rel("Fee Benchmark Study", "Share Class", ["Subject Share Class"]),
            rel("Profitability Record", "Share Class", ["Product / Share Class"]),
            rel("Performance Return", "Share Class", ["Return Share Class"]),
            rel("Benchmark Return", "Benchmark", ["Return Benchmark"]),
            rel("Financial Highlights", "Fund Financial Statement", ["Fund Financial Statement Key"],
                note="Model gap: the spec reads no statement attribute, so the highlights borrow the statement's key "
                     "as DP-165 does."),
            rel("Financial Highlights", "Share Class", ["Highlights Share Class"]),
            rel("Expense Cap & Waiver Accrual", "Share Class", ["Waiver Share Class"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("15(c) star: the agreement fund schedule per approval cycle, with the renewal, its material items and "
               "board findings, and the exemptive relief that removes the shareholder vote. Every cited number is "
               "conformed from its owner and never recalculated: NAV, financial highlights and waiver accruals from "
               "DP-165, returns and benchmark returns from DP-145, share class and fund from DP-004, the adviser "
               "entity from DP-013 and parties from DP-240. Fee studies (DP-030) and profitability (DP-035) are "
               "consumer-published, so they are built from the inputs and keep their natural keys. Resolutions and "
               "meetings are read from DP-182 and built from the inputs. Degenerate keys: Source Peer Universe and the "
               "fee study's Peer Universe (11 Peer Universe; DP-014, which publishes it, is not upstream), Shareholder "
               "Approval Proxy Proposal (13, DP-071) and Fund Fee Schedule (01 fee rates, Reference (Management Fee, 01), CD-232, CW-051). DP-059 and DP-170 "
               "are upstream for the pricing view and the fund side of waivers; their records reach this product only "
               "through the DP-165 accruals and the cited material items. Model gaps: Exemptive Relief Reliance lacks "
               "Order or Rule Citation; Financial Highlights borrows the statement key."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-184": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Regulatory Filing", "Fact", [("35", "Fund Regulatory Filing")], ["Regulatory Filing ID"],
                measures=True,
                grain="one row = fund regulatory filing (REGF-): filer x form type x reporting period end or event / "
                      "as-of date x event reference x submission sequence",
                note="The register of submissions; amendments are new rows pointing to the filing they amend. Holds "
                     "the timeliness, amendment and certification measures."),
            ent("Fact Filing Document", "Fact", [("35", "Filing Document")],
                ["Fact Regulatory Filing Key", "Filed Shareholder Communication", "Filed Product Document",
                 "Filed Proxy Voting Report"],
                grain="one row = regulatory filing x filed document",
                note="Child group of the filing; the filed document is one of three typed references (degenerate "
                     "keys into 13, 01 and 34)."),
            ent("Fact Filing Certification", "Fact", [("35", "Filing Certification")],
                ["Fact Regulatory Filing Key", "Certification Type", "Certifying Officer", "Certifying External Party"],
                grain="one row = regulatory filing x certification type x certifier",
                note="Child group of the filing; Certifier Authority Breaks matches the certifier with a current "
                     "officer appointment."),
            ent("Fact Filing Data Source", "Fact", [("35", "Filing Data Source")],
                ["Source Filing", "Filing Data Source Type", "Source Record Key"],
                grain="one row = regulatory filing x filing data source type x source record",
                note="Data Sources Reconciled % and Data Sources Failing Quality."),
            ent("Fact Reportable Fund Event", "Fact", [("35", "Reportable Fund Event")],
                ["Event Fund", "Reportable Event Type", "Event Date"],
                grain="one row = fund x reportable event type x event date",
                note="Event Filing Timeliness; the source 31 and 33 records are degenerate keys and their measures "
                     "are not copied (CD-234)."),
            ent("Fact Public Disclosure", "Fact", [("35", "Fund Public Disclosure")],
                ["Disclosing Product", "Disclosing Share Class", "Public Disclosure Type", "Disclosure As-Of Date"],
                grain="one row = fund (or share class) x public disclosure type x disclosure as-of date",
                note="Disclosures Published On Time %. Fund-level disclosures leave the share class blank."),
            # -- dimensions
            ent("Filing Obligation", "Dimension", [("35", "Filing Obligation")],
                ["Obligated Product", "Obligated Entity", "Obligation Form Type", "Obligation Effective From"],
                note="The expected filings behind Filings Due and Missing Periodic Filings; the obligated product or "
                     "entity is coalesced in the key."),
            ent("Fund Officer Appointment", "Dimension", [("35", "Fund Officer Appointment")],
                ["Officer Registrant", "Fund Officer Role", "Appointed Officer", "Officer Effective From"],
                note="Read from DP-182 (same domain) to check certifier authority. Model gap: the registry key also "
                     "has Officer Entity and External Officer Party, which are not inputs; this product reads "
                     "employee officers of registrants only, for which the remaining attributes identify the row."),
            ent("DQ Result", "Dimension", [("21", "Data Quality Result")], ["DQ Result ID"],
                note="Data quality result of a filing data source. Model gap: DP-101, the upstream the spec names, "
                     "does not publish 21 Data Quality Result in its model (DP-075 does), so the dimension is built "
                     "from the inputs; adding DP-075 to the upstream would let it conform to DP-075 DQ Result."),
            dim("Investment Product", PROD),
            dim("Share Class", SHARE),
            dim("Internal Legal Entity", ILE, note="Filer entity (adviser, AIFM, depositor) and obligated entity."),
            dim("Filing Calendar", CALENDAR),
            dim("Party", PARTY, note="Filing agent and external certifier."),
            dim("Employee", EMP, note="Certifying officers and source sign-off employees."),
            dim("Calendar Date", CAL, [("09", "Calendar Date")]),
        ],
        relationships=[
            rel("Fact Regulatory Filing", "Filing Obligation", ["Met Obligation"], optional=True,
                note="Event filings may meet no periodic obligation."),
            rel("Fact Regulatory Filing", "Investment Product", ["Filer Product"], optional=True),
            rel("Fact Regulatory Filing", "Investment Product", ["Covered Series"], card="M:N", optional=True,
                note="Multi-valued: one row per covered series after the build explodes the list."),
            rel("Fact Regulatory Filing", "Internal Legal Entity", ["Filer Entity"], optional=True),
            rel("Fact Regulatory Filing", "Fact Regulatory Filing", ["Amended Filing"], optional=True),
            rel("Fact Regulatory Filing", "Party", ["Filing Agent Party"], optional=True),
            rel("Fact Regulatory Filing", "Calendar Date", ["Filing Due Date"]),
            rel("Fact Regulatory Filing", "Calendar Date", ["Reporting Period End Date"], optional=True,
                note="Blank for event filings, which carry Event or As-Of Date."),
            rel("Filing Obligation", "Investment Product", ["Obligated Product"], optional=True),
            rel("Filing Obligation", "Internal Legal Entity", ["Obligated Entity"], optional=True),
            rel("Filing Obligation", "Filing Calendar", ["Filing Calendar"]),
            rel("Fact Filing Document", "Fact Regulatory Filing", ["Fact Regulatory Filing Key"]),
            rel("Fact Filing Document", "Share Class", ["Filed Document Share Class"], optional=True),
            rel("Fact Filing Certification", "Fact Regulatory Filing", ["Fact Regulatory Filing Key"]),
            rel("Fact Filing Certification", "Employee", ["Certifying Officer"], optional=True),
            rel("Fact Filing Certification", "Party", ["Certifying External Party"], optional=True),
            rel("Fact Filing Data Source", "Fact Regulatory Filing", ["Source Filing"]),
            rel("Fact Filing Data Source", "Employee", ["Source Sign-Off Employee"], optional=True),
            rel("Fact Filing Data Source", "DQ Result", ["Related Data Quality Result"], optional=True),
            rel("Fact Reportable Fund Event", "Investment Product", ["Event Fund"]),
            rel("Fact Reportable Fund Event", "Fact Regulatory Filing", ["Resulting Filing"], optional=True),
            rel("Fact Reportable Fund Event", "Calendar Date", ["Event Date"]),
            rel("Fact Public Disclosure", "Investment Product", ["Disclosing Product"]),
            rel("Fact Public Disclosure", "Share Class", ["Disclosing Share Class"], optional=True),
            rel("Fact Public Disclosure", "Calendar Date", ["Disclosure As-Of Date"]),
            rel("Fund Officer Appointment", "Investment Product", ["Officer Registrant"]),
            rel("Fund Officer Appointment", "Employee", ["Appointed Officer"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Filing register star: the regulatory filing with its documents, certifications and data sources as "
               "child facts, the reportable events and public disclosures as companion facts, and the filing "
               "obligation as the expected-filing dimension. Funds and share classes are conformed from DP-004, "
               "filer entities and calendars from DP-013, parties from DP-240 and employees from DP-192. Officer "
               "appointments are read from DP-182 and built from the inputs. The filing document and certification "
               "are child groups of the filing and carry its key (Fact Regulatory Filing Key). Degenerate keys: the "
               "filed documents (13, 01, 34), the event sources (33 Investment Breach, 31 Risk Limit Exceedance, Fund "
               "Liquidity Profile and VaR Test Result, all from DP-155 and the 33 products) and the disclosure "
               "sources (24 ETF Basket from DP-131, 22 ETF Market Statistic, which DP-143 and DP-145 publish but "
               "neither is upstream). Model gaps: DQ Result is built because DP-101's model does not publish it; "
               "Fund Officer Appointment's key lacks Officer Entity and External Officer Party. DP-101 is otherwise "
               "not joined: no input references a DP-101 data asset."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-185": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Filing Data Source", "Fact", [("35", "Filing Data Source")],
                ["Source Filing", "Filing Data Source Type", "Source Record Key"], measures=True,
                grain="one row = regulatory filing (REGF-) x filing data source type x source record x source as-of "
                      "date and version, held as filed",
                note="The as-filed evidence spine: each row names the source records a periodic form (N-PORT, N-CEN, "
                     "N-MFP) was assembled from. Source Record Key holds the source's key, so the source entity it "
                     "points to depends on Filing Data Source Type. Holds the measures, which read the source "
                     "records as of the filing (Source Drift Since Filing compares them with the current value)."),
            ent("Fact Flow Measure Value", "Fact", [("06", "Measure Value"), ("06", "Flow Measures")],
                ["Measure", "Period End Date", "Data Basis", "Snapshot", "Dimension Type", "Dimension Key"],
                grain="one row = DP-008 certified flow measure value x share class x month (period end) x data basis "
                      "x snapshot",
                note="Fund-level sales, reinvestments and redemptions for Reported Flows (CD-292). Flow Measures fold "
                     "into the measure value. Model gap: the registry key has Reporting Period and Dimension Grain, "
                     "which are not inputs; Period End Date stands for the reporting period and the share class "
                     "grain is fixed by the product rule."),
            ent("Liquidity Classification", "Fact", [("31", "Liquidity Classification")],
                ["Classified Fund", "Classified Instrument", "Classification Date", "Classification Portion Number"],
                grain="one row = fund x instrument x classification date x classification portion",
                note="Rule 22e-4 classification read from DP-155 (Liquidity Classification Coverage %)."),
            ent("Fund Liquidity Profile", "Fact", [("31", "Fund Liquidity Profile")],
                ["Profile Fund", "Profile Measurement Date"],
                grain="one row = fund x profile measurement date", note="Reported Liquidity Profile (DP-155)."),
            ent("Highly Liquid Investment Minimum", "Dimension", [("31", "Highly Liquid Investment Minimum")],
                ["HLIM Fund", "HLIM Effective From"],
                note="The fund's HLIM in force on the reporting date (DP-155)."),
            ent("Leverage & Exposure Measurement", "Fact", [("31", "Leverage & Exposure Measurement")],
                ["Measured Fund", "Leverage Measurement Date", "Exposure Method"],
                grain="one row = fund x measurement date x exposure method",
                note="Rule 18f-4 derivatives exposure (Reported Derivatives Exposure and VaR), from DP-155."),
            ent("VaR Test Result", "Fact", [("31", "VaR Test Result")], ["VaR Test Fund", "VaR Test Date",
                                                                          "VaR Test Regime"],
                grain="one row = fund x VaR test date x VaR test regime", note="From DP-155."),
            ent("Securities Loan", "Fact", [("28", "Securities Loan")], ["Securities Loan ID"],
                grain="one row = securities loan (current state at the latest mark)",
                note="Securities on Loan Reported; read from DP-174, which publishes the loan."),
            # -- bridges
            dim("Portfolio Implementation Link", ("DP-140", "Portfolio Implementation Link"),
                [("18", "Portfolio Implementation Link")], role="Bridge",
                grain="one row = portfolio x implementation link type x implemented fund x effective period",
                note="Maps the fund to the portfolio whose holdings and exposures are reported (Primary "
                     "Implementation Indicator)."),
            # -- dimensions
            ent("Regulatory Filing", "Dimension", [("35", "Fund Regulatory Filing")], ["Regulatory Filing ID"],
                note="The filing registered by DP-184, built from the inputs and keyed by its REGF- ID."),
            ent("Product Party Role", "Dimension", [("01", "Product Party Role")],
                ["Investment Product Key", "Party", "Party Role Type", "Role Effective From"],
                note="N-CEN service providers. Built from the inputs because DP-167, whose model publishes it, is "
                     "not upstream. Model gap: the object has no product attribute, so the role borrows the fund's "
                     "key (Investment Product Key), as DP-167 does."),
            dim("Fund Accounting Book", BOOK, [("27", "Fund Accounting Book")]),
            dim("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")],
                note="As-Filed Net Assets: total assets, liabilities and net assets of the NAV of record."),
            dim("Share Class NAV", CNAV, [("27", "Share Class NAV")],
                note="Class NAV and Market-Based NAV (N-MFP) and shares outstanding."),
            dim("Fund Trial Balance", ("DP-166", "Fund Trial Balance"), [("27", "Fund Trial Balance")],
                note="Ledger balances behind Reported Liability Detail (mapped by a product rule table)."),
            dim("Fund Ledger Account", ("DP-166", "Fund Ledger Account")),
            dim("Portfolio Holding", ("DP-142", "Portfolio Holding"),
                [("18", "Portfolio Holding"), ("18", "Holding Valuation"), ("18", "Derivative Holding Detail")],
                note="Holdings Reported and Holding % of Net Assets; the valuation and derivative detail fold in."),
            dim("Instrument", ("DP-097", "Instrument"), [("17", "Instrument")]),
            dim("Instrument Identifier", ("DP-097", "Instrument Identifier"), [("17", "Instrument Identifier")],
                note="Holdings Without Identifier looks for holdings with no identifier in force."),
            dim("Approved Price", ("DP-143", "Approved Price"), [("22", "Approved Price")],
                note="Fair value level per instrument and date (Fair Value Level Coverage %)."),
            dim("Portfolio Exposure", ("DP-146", "Portfolio Exposure"), [("31", "Portfolio Exposure")],
                note="Interest rate and credit spread sensitivities (Reported Risk Metrics)."),
            dim("Risk Calculation Run", ("DP-146", "Risk Calculation Run")),
            dim("Performance Return", ("DP-145", "Performance Return"), [("32", "Performance Return")],
                note="Monthly share class returns (Reported Monthly Returns, CD-320)."),
            dim("Measure Definition", ("DP-008", "Measure Definition")),
            dim("Snapshot", ("DP-008", "Snapshot")),
            dim("Investment Product", PROD, [("01", "Fund Legal Structure")],
                note="Fund Legal Structure folds into the product (regulatory regime, fund LEI, registration "
                     "number)."),
            dim("Share Class", SHARE),
            dim("Portfolio", ("DP-140", "Portfolio")),
            dim("Party", ("DP-140", "Party"),
                note="Issuers, OTC counterparties, securities borrowers and service providers. Conformed from DP-140 "
                     "because DP-240 is not upstream; both carry the same Party ID."),
            dim("Employee", EMP),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            # the as-filed spine
            rel("Fact Filing Data Source", "Regulatory Filing", ["Source Filing"]),
            rel("Fact Filing Data Source", "Employee", ["Source Sign-Off Employee"], optional=True),
            rel("Fact Filing Data Source", "Calendar Date", ["Source As-Of Date"]),
            rel("Fact Filing Data Source", "Fund NAV Calculation", ["Source Record Key"], optional=True,
                note="Source Record Key is polymorphic: it holds the key of the source record named by Filing Data "
                     "Source Type, so each of these links applies only to rows of that type."),
            rel("Fact Filing Data Source", "Share Class NAV", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Fund Trial Balance", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Portfolio Holding", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Liquidity Classification", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Fund Liquidity Profile", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Leverage & Exposure Measurement", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "VaR Test Result", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Portfolio Exposure", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Performance Return", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Fact Flow Measure Value", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Securities Loan", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Product Party Role", ["Source Record Key"], optional=True),
            rel("Regulatory Filing", "Investment Product", ["Filer Product"], optional=True),
            rel("Regulatory Filing", "Investment Product", ["Covered Series"], card="M:N", optional=True,
                note="Multi-valued: one row per covered series."),
            rel("Regulatory Filing", "Regulatory Filing", ["Amended Filing"], optional=True),
            rel("Regulatory Filing", "Calendar Date", ["Reporting Period End Date"]),
            # fund accounting
            rel("Fund Accounting Book", "Investment Product", ["Book Fund"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Fund Trial Balance", "Fund Accounting Book", ["Balance Book"]),
            rel("Fund Trial Balance", "Fund Ledger Account", ["Balance Fund Ledger Account"]),
            # holdings, instruments and prices
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"]),
            rel("Portfolio Holding", "Portfolio", ["Holding Portfolio"]),
            rel("Portfolio Holding", "Instrument", ["Held Instrument"]),
            rel("Portfolio Holding", "Party", ["OTC Counterparty"], optional=True),
            rel("Instrument", "Party", ["Issuer"], optional=True),
            rel("Instrument Identifier", "Instrument", ["Identified Instrument"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
            # liquidity, derivatives and risk
            rel("Liquidity Classification", "Investment Product", ["Classified Fund"]),
            rel("Liquidity Classification", "Instrument", ["Classified Instrument"]),
            rel("Fund Liquidity Profile", "Investment Product", ["Profile Fund"]),
            rel("Highly Liquid Investment Minimum", "Investment Product", ["HLIM Fund"]),
            rel("Leverage & Exposure Measurement", "Investment Product", ["Measured Fund"]),
            rel("VaR Test Result", "Investment Product", ["VaR Test Fund"]),
            rel("Portfolio Exposure", "Portfolio", ["Exposure Portfolio"]),
            rel("Portfolio Exposure", "Risk Calculation Run", ["Exposure Calculation Run"]),
            # returns, flows, lending, providers
            rel("Performance Return", "Share Class", ["Return Share Class"]),
            rel("Fact Flow Measure Value", "Share Class", ["Dimension Key"],
                note="Share class rows (Dimension Type = Share Class; W4, CW-906 replaced the Share Class column)."),
            rel("Fact Flow Measure Value", "Measure Definition", ["Measure"]),
            rel("Fact Flow Measure Value", "Snapshot", ["Snapshot"]),
            rel("Fact Flow Measure Value", "Calendar Date", ["Period End Date"]),
            rel("Securities Loan", "Instrument", ["Loaned Instrument"]),
            rel("Securities Loan", "Party", ["Borrower"]),
            rel("Product Party Role", "Investment Product", ["Investment Product Key"]),
            rel("Product Party Role", "Party", ["Party"]),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("As-filed star for the registered fund forms (N-PORT, N-CEN, N-MFP): the filing data source is the fact "
               "and each source record it names is conformed from the product that certifies it, never remastered "
               "(CD-234, CD-334): fund accounting book, fund NAV and share class NAV from DP-165, trial balances and "
               "ledger accounts from DP-166, holdings from DP-142, instruments and identifiers from DP-097, approved "
               "prices from DP-143, exposures and risk runs from DP-146, returns from DP-145, flows' measure "
               "definition and snapshot from DP-008, funds and share classes from DP-004, portfolio and its "
               "implementation link from DP-140, employees from DP-192 and dates from DP-013. Records published by "
               "consumer products (31 liquidity, HLIM, leverage and VaR from DP-155; 28 securities loans from DP-174; "
               "35 filings from DP-184) are built from the inputs with their natural keys. Source Record Key is a "
               "polymorphic reference typed by Filing Data Source Type, drawn as one optional link per source "
               "entity. Model gaps: Product Party Role borrows the fund key; the flow measure value's registry key "
               "attributes Reporting Period and Dimension Grain are not inputs. DP-171, DP-176 and DP-177 are "
               "upstream for N-CEN items but no attribute of theirs is an input (spec note); DP-155 objects are "
               "modeled as this product's own entities."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-186": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Filing Data Source", "Fact", [("35", "Filing Data Source")],
                ["Source Filing", "Filing Data Source Type", "Source Record Key"], measures=True,
                grain="one row = regulatory filing (REGF-; Form PF per adviser filer entity) x reported fund x filing data source type x source record x source as-of date and "
                      "version, held as filed",
                note="As-filed evidence spine for Form PF. Source Record Key holds the key of the "
                     "source record named by Filing Data Source Type. The reported fund is reached through the "
                     "source record (each source carries its fund); Model gap: the filing data source has no reported "
                     "fund attribute, so a Form PF filed by an adviser for several funds is split by fund through the "
                     "source records, not by a key on this fact."),
            ent("Leverage & Exposure Measurement", "Fact", [("31", "Leverage & Exposure Measurement")],
                ["Measured Fund", "Leverage Measurement Date", "Exposure Method"],
                grain="one row = fund x measurement date x exposure method",
                note="Rule 18f-4 and Section 18 leverage (Reported Leverage), from DP-155."),
            ent("Liquidity Horizon Bucket", "Fact", [("31", "Liquidity Horizon Bucket")],
                ["Bucket Fund", "Bucket Measurement Date", "Liquidity Horizon Bucket"],
                grain="one row = fund x measurement date x liquidity horizon bucket",
                note="Portfolio and Investor Liquidity, from DP-155."),
            # -- bridges
            dim("Portfolio Implementation Link", ("DP-140", "Portfolio Implementation Link"),
                [("18", "Portfolio Implementation Link")], role="Bridge",
                grain="one row = portfolio x implementation link type x implemented fund x effective period",
                note="Maps each fund to the portfolio behind its exposures, risk measures and returns."),
            # -- dimensions
            ent("Regulatory Filing", "Dimension", [("35", "Fund Regulatory Filing")], ["Regulatory Filing ID"],
                note="The filing registered by DP-184, built from the inputs and keyed by its REGF- ID."),
            dim("Fund Accounting Book", BOOK, [("27", "Fund Accounting Book")]),
            dim("Fund NAV Calculation", FNAV, [("27", "Fund NAV Calculation")],
                note="Registered and pooled fund net and gross assets (Reported Net Assets, Reported Gross Assets)."),
            dim("Portfolio Exposure", ("DP-146", "Portfolio Exposure"), [("31", "Portfolio Exposure")],
                note="Reported Exposures."),
            dim("Portfolio Risk Measure", ("DP-146", "Portfolio Risk Measure"), [("31", "Portfolio Risk Measure")],
                note="VaR and sensitivities reported on Form PF."),
            dim("Risk Calculation Run", ("DP-146", "Risk Calculation Run")),
            dim("Performance Return", ("DP-145", "Performance Return"), [("32", "Performance Return")],
                note="Reported Returns at fund (portfolio) or share class level."),
            dim("Investment Product", PROD, [("01", "Fund Legal Structure"), ("01", "Feeder Access Terms")],
                note="Fund Legal Structure and Feeder Access Terms (the private fund dimension since W4, CW-166) fold "
                     "into the product."),
            dim("Share Class", SHARE),
            dim("Portfolio", ("DP-140", "Portfolio")),
            dim("Filer Entity", ILE, [("09", "Internal Legal Entity")],
                note="Adviser (Form PF) or AIFM (Annex IV) filer."),
            dim("Employee", EMP),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            # the as-filed spine
            rel("Fact Filing Data Source", "Regulatory Filing", ["Source Filing"]),
            rel("Fact Filing Data Source", "Employee", ["Source Sign-Off Employee"], optional=True),
            rel("Fact Filing Data Source", "Calendar Date", ["Source As-Of Date"]),
            rel("Fact Filing Data Source", "Fund NAV Calculation", ["Source Record Key"], optional=True,
                note="Source Record Key is polymorphic: it holds the key of the source record named by Filing Data "
                     "Source Type, so each of these links applies only to rows of that type."),
            rel("Fact Filing Data Source", "Leverage & Exposure Measurement", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Liquidity Horizon Bucket", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Portfolio Exposure", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Portfolio Risk Measure", ["Source Record Key"], optional=True),
            rel("Fact Filing Data Source", "Performance Return", ["Source Record Key"], optional=True),
            rel("Regulatory Filing", "Investment Product", ["Filer Product"], optional=True,
                note="Annex IV per fund; Form PF is filed by the adviser entity."),
            rel("Regulatory Filing", "Investment Product", ["Covered Series"], card="M:N", optional=True,
                note="Multi-valued: one row per reported fund."),
            rel("Regulatory Filing", "Filer Entity", ["Filer Entity"], optional=True),
            rel("Regulatory Filing", "Regulatory Filing", ["Amended Filing"], optional=True),
            rel("Regulatory Filing", "Calendar Date", ["Reporting Period End Date"]),
            # fund accounting and private fund records
            rel("Fund Accounting Book", "Investment Product", ["Book Fund"]),
            rel("Fund NAV Calculation", "Fund Accounting Book", ["NAV Book"]),
            # leverage, liquidity and risk
            rel("Leverage & Exposure Measurement", "Investment Product", ["Measured Fund"]),
            rel("Liquidity Horizon Bucket", "Investment Product", ["Bucket Fund"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Product", ["Implemented Product"]),
            rel("Portfolio Exposure", "Portfolio", ["Exposure Portfolio"]),
            rel("Portfolio Exposure", "Risk Calculation Run", ["Exposure Calculation Run"]),
            rel("Portfolio Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Portfolio Risk Measure", "Risk Calculation Run", ["Measure Calculation Run"]),
            # returns
            rel("Performance Return", "Portfolio", ["Return Portfolio"], optional=True),
            rel("Performance Return", "Share Class", ["Return Share Class"], optional=True),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("W4 re-scope to Form PF (CW-930, CW-166): Private Fund Profile, Investor Commitment, Investor Capital Account, "
               "Investor Account, Fund Credit Facility, Facility Drawdown, Lender and Private Markets Performance Measure are "
               "removed with their relationships; feeder access terms fold into the product, and the leverage measurement "
               "loses its facility link (Fund Borrowing Facility dropped). Annex IV left with the US-only pass. "
               "As-filed star for Form PF, built like DP-185: the filing data "
               "source is the fact and each source record is conformed from its certifying product, never "
               "recomputed (CD-334): fund NAV and book from DP-165, exposures, risk measures and risk runs from DP-146, "
               "returns from DP-145, funds and share classes from DP-004, portfolios "
               "and the implementation link from DP-140, the filer entity from DP-013 and employees from DP-192. "
               "Records published by consumer products (31 leverage and liquidity horizon buckets from DP-155; 35 filings "
               "from DP-184) are built from the inputs with their natural keys. Model gap: no reported-fund attribute on "
               "the filing data source (reached through the source record). DP-142 is upstream "
               "for the fund's portfolio key behind exposures; it is reached through DP-140's implementation link."),
    ),
}
