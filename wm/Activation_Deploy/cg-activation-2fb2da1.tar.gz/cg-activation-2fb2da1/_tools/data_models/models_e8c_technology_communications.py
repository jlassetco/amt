"""Logical data models, Wave E8 consumer group "technology_communications": Star models for DP-231 IT Service
Management, DP-232 Security Incidents, Testing & Vulnerabilities, DP-233 Identity, Access & Device Lifecycle and DP-234
Change & Project Portfolio (41 Technology & Information Security), and DP-235 Brand Register, Usage Rights & Trademark
Protection, DP-236 Media, Coverage & Reputation, DP-237 Issues, Crisis & Internal Communications and DP-238 Corporate
Disclosures, Public Policy & Lobbying (42 Corporate Communications & Public Affairs). See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed`: Application, IT Service and Configuration
  Item from DP-211; Vendor from DP-210 (third-party service providers and external testers are 02 parties with a
  supplier profile); Contract from DP-213; Employee, Employee Lifecycle Event and Job Profile from DP-192; GL Account and
  Cost Center from DP-190; Journal Entry from DP-191; Data Product from DP-101; Party from DP-240; Investment Product and
  Share Class from DP-004; Org Unit, Internal Legal Entity, Office Location, Country, Calendar, Calendar Date and Fiscal
  Period from DP-013. Product input objects of the same concept sit on the conformed dimension and merge with its
  inherited attributes.
- Objects another consumer product publishes (37 Risk Issue from DP-216, 14 Entitlement from DP-044, 21 Data Quality
  Issue from DP-103, 08 Compliance Review from DP-036, 11 Award from DP-030, 37 Operational Incident from DP-215, 37
  Business Continuity Plan from DP-217, 39 Legal Matter from DP-229, 41 IT Incident from DP-231, 39 Corporate Resolution
  from DP-230, 38 Political Contribution from DP-225, 20 Human Capital Metric Value from DP-201, 43 Capital Requirement
  Calculation from DP-205, and 42 Brand from DP-235) are modeled here as the product's own entities from its inputs,
  with the registry keys, so they still join to the publishing product.
- Facts are built from the product's own inputs, never conformed, so they carry only the attributes the spec reads.
- Daily or weekly snapshots whose as-of date is not an input attribute borrow "As-of Date Key" (or "Calendar Date Key")
  from the conformed DP-013 Calendar Date, as the earlier consumer waves do; each is recorded as a Model gap.
- Multi-valued references (e.g. Affected Applications) are drawn as M:N relationships; the build explodes them into one
  row per referenced member.
- References to objects that are neither product inputs nor published by an upstream foundational model stay
  degenerate attributes on their entity (named in each model's notes).
"""


def dim(name, src, objects=(), note=""):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    return dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=note)


def ent(name, role, objects, pk, grain="", note="", measures=False):
    d = dict(name=name, role=role, objects=list(objects), pk=list(pk), note=note, measures=measures)
    if grain:
        d["grain"] = grain
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


APP = ("DP-211", "Application")
ITSVC = ("DP-211", "IT Service")
CI = ("DP-211", "Configuration Item")
VENDOR = ("DP-210", "Vendor")
CONTRACT = ("DP-213", "Contract")
EMP = ("DP-192", "Employee")
ELE = ("DP-192", "Employee Lifecycle Event")
JOBP = ("DP-192", "Job Profile")
GLACCT = ("DP-190", "GL Account")
CC = ("DP-190", "Cost Center")
JE = ("DP-191", "Journal Entry")
DPROD = ("DP-101", "Data Product")
PARTY = ("DP-240", "Party")
PROD = ("DP-004", "Investment Product")
SHARE = ("DP-004", "Share Class")
ORG = ("DP-013", "Org Unit")
ILE = ("DP-013", "Internal Legal Entity")
OFFICE = ("DP-013", "Office Location")
COUNTRY = ("DP-013", "Country")
CALENDAR = ("DP-013", "Calendar")
CAL = ("DP-013", "Calendar Date")
FPER = ("DP-013", "Fiscal Period")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-231": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact IT Incident", "Fact", [("41", "IT Incident")], ["IT Incident ID", "Calendar Date Key"],
                grain="one row = IT incident (ITINC-) x status snapshot date; affected IT services, applications, "
                      "configuration items and legal entities explode through their M:N links",
                measures=True,
                note="The spine of the product: availability, restoration and downtime measures are all stated per "
                     "incident and attributed to each affected IT service and application. The daily status snapshot "
                     "borrows Calendar Date Key (see notes)."),
            ent("Fact Problem", "Fact", [("41", "Problem Record")], ["Problem Code"],
                grain="one row = problem record (known error when flagged)",
                note="Companion fact for recurring incidents; Linked IT Incidents is multi-valued, so the link to the "
                     "incident fact is M:N."),
            ent("Fact Change Request", "Fact", [("41", "Change Request")], ["Change Request ID"],
                grain="one row = change request (CHRQ-)",
                note="Change success and change-caused incidents. Kept as a fact, not a dimension, because the change "
                     "outcome and timings are measured; incidents and problems point to it as Causing or Resolving "
                     "Change."),
            ent("Fact Change Approval", "Fact", [("41", "Change Approval")], ["Approved Change", "Change Approval Step"],
                grain="one row = change request x approval step",
                note="Repeating grain under the change request; approval before implementation is tested on Change "
                     "Advisory Board Date (spec taxonomy gap: no approval timestamp)."),
            ent("Fact Release Deployment", "Fact", [("41", "Release Deployment")],
                ["Deployed Release", "Deployment Environment", "Deployment Timestamp"],
                grain="one row = release x deployment environment x deployment timestamp",
                note="Deployment results by environment for release success."),
            # -- dimensions
            ent("Release", "Dimension", [("41", "Release")], ["Release ID"],
                note="DP-211 does not publish releases, so the dimension is built from 41 here; the change request "
                     "names the release it implemented."),
            dim("IT Service", ITSVC, [("41", "IT Service")],
                note="Conformed from DP-211; Service Hours drives scheduled minutes for Service Availability %."),
            dim("Application", APP, [("41", "Application")],
                note="Conformed from DP-211 (criticality tier for Tier 1 incidents, hosting model for provider-hosted "
                     "platforms)."),
            dim("Configuration Item", CI, [("41", "Configuration Item")], note="Conformed from DP-211."),
            dim("Third-Party Service Provider", VENDOR,
                note="Conformed DP-210 Vendor: the supplier behind a provider-run IT service (third-party-caused "
                     "incidents for procurement)."),
            ent("Incident Source Record", "Bridge", [("37", "Incident Source Record")], ["Incident Source Record Key"],
                grain="one row = operational incident x source IT incident",
                note="The one link between the 37 operational incident and the 41 technical record (CD-266), read "
                     "directly so DP-215 need not be upstream. Surrogate key as in the registry (no attribute "
                     "identifies the row). Source Incident stays a degenerate key: 37 Operational Incident is not an "
                     "input."),
            dim("Employee", EMP, note="Conformed from DP-192: incident manager, problem owner, change requester and "
                                      "approver, deployer, IT service owner."),
            dim("Org Unit", ORG, note="Conformed from DP-013: the application's owning org unit."),
            dim("Internal Legal Entity", ILE, [("09", "Internal Legal Entity")],
                note="Conformed from DP-013: affected legal entities of an incident."),
            dim("Calendar", CALENDAR, [("09", "Calendar")],
                note="Conformed from DP-013: the firm office calendar for scheduled minutes and the change freeze "
                     "calendar."),
            dim("Calendar Date", CAL, [("09", "Calendar Date")],
                note="Conformed from DP-013: snapshot date and change advisory board date; Day Type marks business "
                     "days for Service Availability %."),
        ],
        relationships=[
            rel("Fact IT Incident", "IT Service", ["Affected IT Services"], card="M:N",
                note="Multi-valued: one row per affected IT service after the build explodes the list."),
            rel("Fact IT Incident", "Application", ["Affected Applications"], card="M:N", optional=True),
            rel("Fact IT Incident", "Configuration Item", ["Affected Configuration Items"], card="M:N", optional=True),
            rel("Fact IT Incident", "Internal Legal Entity", ["Affected Legal Entities"], card="M:N", optional=True),
            rel("Fact IT Incident", "Fact Change Request", ["Causing Change"], optional=True,
                note="Change-caused incidents."),
            rel("Fact IT Incident", "Employee", ["Incident Manager"], optional=True),
            rel("Fact IT Incident", "Calendar Date", ["Calendar Date Key"], note="The daily status snapshot date."),
            rel("Fact Problem", "Fact IT Incident", ["Linked IT Incidents"], card="M:N",
                note="Matches the incident on IT Incident ID across its snapshot rows."),
            rel("Fact Problem", "Fact Change Request", ["Resolving Change"], optional=True),
            rel("Fact Problem", "Employee", ["Problem Owner"], optional=True),
            rel("Fact Change Request", "Application", ["Changed Applications"], card="M:N", optional=True),
            rel("Fact Change Request", "Configuration Item", ["Changed Configuration Items"], card="M:N",
                optional=True),
            rel("Fact Change Request", "Calendar", ["Change Freeze Calendar"], optional=True),
            rel("Fact Change Request", "Release", ["Implemented Release"], optional=True),
            rel("Fact Change Request", "Employee", ["Change Requester"], optional=True),
            rel("Fact Change Approval", "Fact Change Request", ["Approved Change"]),
            rel("Fact Change Approval", "Employee", ["Change Approver"], optional=True),
            rel("Fact Change Approval", "Calendar Date", ["Change Advisory Board Date"], optional=True),
            rel("Release", "Application", ["Released Application"]),
            rel("Fact Release Deployment", "Release", ["Deployed Release"]),
            rel("Fact Release Deployment", "Employee", ["Deployed By"], optional=True),
            rel("IT Service", "Application", ["Supporting Applications"], card="M:N", optional=True),
            rel("IT Service", "Employee", ["IT Service Owner"]),
            rel("IT Service", "Third-Party Service Provider", ["Third-Party Service Provider"], optional=True),
            rel("Application", "Org Unit", ["Owning Org Unit"]),
            rel("Configuration Item", "Application", ["Instantiated Application"], optional=True),
            rel("Incident Source Record", "Fact IT Incident", ["Source IT Incident"],
                note="Only rows of Incident Source Type IT Incident; matches the incident on IT Incident ID."),
            rel("Calendar Date", "Calendar", ["Calendar Key"],
                note="A calendar date belongs to one calendar (DP-013 key)."),
        ],
        notes=("ITSM constellation: incidents, problems, change requests with their approval steps, and release "
               "deployments are facts at their own grains sharing the conformed DP-211 Application, IT Service and "
               "Configuration Item dimensions, so incidents and changes meet on the same service and application keys. "
               "Third-party service providers are DP-210 Vendors (the 02 party with a supplier profile). The 37 "
               "Incident Source Record bridge carries the link to operational incidents; DP-215 is deliberately not "
               "upstream (spec boundary). "
               "Model gap: no input attribute carries the daily status snapshot date, so Fact IT Incident borrows "
               "Calendar Date Key from the conformed Calendar Date. "
               "Degenerate: Source Incident (37 Operational Incident is not an input)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-232": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Vulnerability Finding", "Fact", [("41", "Vulnerability Finding")],
                ["Vulnerability Finding ID", "As-of Date Key"],
                grain="one row = vulnerability finding (VULN-) x as-of date (daily snapshot)",
                measures=True,
                note="The product grain. Open, overdue and remediated counts are taken from the snapshot on the as-of "
                     "date; Governing Vulnerability Policy stays a degenerate key (38 Policy is not an input)."),
            ent("Fact Security Event", "Fact", [("41", "IT Incident"), ("41", "Security Incident Detail")],
                ["IT Incident ID"],
                grain="one row = IT incident of Incident Class Security Event, with its security detail",
                note="Security Incident Detail folds into the incident (registry: one detail per incident), so the "
                     "Reg S-P determination, notice dates and containment dates sit on the event row."),
            ent("Fact Security & Resilience Test", "Fact", [("41", "Security & Resilience Test")], ["Test Code"],
                grain="one row = security or resilience test; tested applications, IT services and configuration "
                      "items explode through their M:N links",
                note="Penetration, red team and DR failover tests (TLPT left with CW-941); findings point back to their Source Test."),
            ent("Fact Risk Issue", "Fact", [("37", "Risk Issue")], ["Risk Issue ID"],
                grain="one row = risk issue (ISSUE-) raised from a vulnerability finding",
                note="Read for Risk Acceptances Without Open Issue only; DP-216 owns issue counts (CD-356). Built "
                     "from 37 here because DP-216 is a consumer product."),
            # -- dimensions
            dim("Application", APP, [("41", "Application"), ("41", "Application Recovery Profile")],
                note="Conformed from DP-211; the recovery profile folds into the application (RTO for DR tests)."),
            dim("Configuration Item", CI, [("41", "Configuration Item")], note="Conformed from DP-211."),
            dim("IT Service", ITSVC, note="Conformed from DP-211: tested IT services."),
            dim("Service Provider", VENDOR,
                note="Conformed DP-210 Vendor: external testers and notifying service providers."),
            dim("Internal Legal Entity", ILE, [("09", "Internal Legal Entity")],
                note="Conformed from DP-013: tested entity and affected legal entities."),
            dim("As-of Date", CAL, note="Conformed DP-013 Calendar Date: the snapshot date."),
        ],
        relationships=[
            rel("Fact Vulnerability Finding", "Configuration Item", ["Vulnerable Configuration Item"], optional=True),
            rel("Fact Vulnerability Finding", "Application", ["Vulnerable Application"], optional=True),
            rel("Fact Vulnerability Finding", "Fact Security & Resilience Test", ["Source Test"], optional=True),
            rel("Fact Vulnerability Finding", "As-of Date", ["As-of Date Key"], note="Carries the snapshot date."),
            rel("Fact Security Event", "Application", ["Affected Applications"], card="M:N", optional=True),
            rel("Fact Security Event", "Internal Legal Entity", ["Affected Legal Entities"], card="M:N",
                optional=True),
            rel("Fact Security Event", "Service Provider", ["Notifying Service Provider"], optional=True,
                note="Service provider breach notices (Reg S-P 72-hour notice)."),
            rel("Fact Security & Resilience Test", "Application", ["Tested Applications"], card="M:N",
                optional=True),
            rel("Fact Security & Resilience Test", "IT Service", ["Tested IT Services"], card="M:N", optional=True),
            rel("Fact Security & Resilience Test", "Configuration Item", ["Tested Configuration Items"], card="M:N",
                optional=True),
            rel("Fact Security & Resilience Test", "Internal Legal Entity", ["Tested Financial Entity"],
                optional=True),
            rel("Fact Security & Resilience Test", "Service Provider", ["External Tester"], optional=True),
            rel("Fact Risk Issue", "Fact Vulnerability Finding", ["Source Vulnerability Finding"], optional=True,
                note="Matches the finding on Vulnerability Finding ID across its snapshot rows."),
            rel("Configuration Item", "Application", ["Instantiated Application"], optional=True),
        ],
        notes=("Security constellation: the daily vulnerability snapshot is the main fact, with security events, "
               "security and resilience tests and the risk issues that accept vulnerabilities as companion facts, all "
               "on the conformed DP-211 Application, IT Service and Configuration Item dimensions. External testers "
               "and notifying service providers are DP-210 Vendors; legal entities are DP-013. Security events are the "
               "41 IT Incident rows of class Security Event; the general ITSM incident fact is DP-231's. "
               "Model gap: no input attribute carries the snapshot as-of date, so Fact Vulnerability Finding borrows "
               "As-of Date Key from the conformed Calendar Date. "
               "Degenerate: Governing Vulnerability Policy (38 Policy is not an input)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-233": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact System Access Grant", "Fact", [("41", "System Access Grant")],
                ["System Access Grant ID", "As-of Date Key"],
                grain="one row = system access grant (ACSG-) x as-of date (daily snapshot)",
                measures=True,
                note="The product grain: leaver, mover, approval, privileged and licensed-data checks all start from "
                     "the grant."),
            ent("Fact Access Review Decision", "Fact", [("41", "Access Review Decision")],
                ["Decision Campaign", "Reviewed Grant"],
                grain="one row = access review campaign x reviewed grant",
                note="Certification and remediation evidence."),
            ent("Fact IT Asset Assignment", "Fact", [("41", "IT Asset Assignment")],
                ["Assigned Configuration Item", "Device Assignee", "Assigned Date"],
                grain="one row = end-user device x assignee x assignment period",
                note="Leaver device return and wipe checks."),
            # -- dimensions
            ent("Digital Identity", "Dimension", [("41", "Digital Identity")], ["Digital Identity ID"],
                note="The identity companion snapshot (identity x as-of date) is this dimension's daily history; "
                     "kept as a dimension because grants point to it and identity counts are its rows. Identity Owner "
                     "Party stays degenerate (see notes)."),
            ent("Application Access Role", "Dimension", [("41", "Application Access Role")],
                ["Role Application", "Access Role Code"],
                note="DP-211 does not publish access roles, so the dimension is built from 41 here; privileged and "
                     "segregation of duties flags sit on the role."),
            ent("Access Review Campaign", "Dimension", [("41", "Access Review Campaign")],
                ["Access Review Campaign Code"],
                note="Governing Access Policy stays a degenerate key (38 Policy is not an input)."),
            ent("Entitlement", "Dimension", [("14", "Entitlement")], ["Entitlement ID"],
                note="Licensed-data entitlement, built from 14 here because DP-044 is a consumer product. Entitled "
                     "Application, Entitled Dataset and Governing License stay degenerate keys (not inputs)."),
            dim("Application", APP, [("41", "Application")], note="Conformed from DP-211."),
            dim("Configuration Item", CI, [("41", "Configuration Item")],
                note="Conformed from DP-211: the end-user device."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: identity owner, sponsor, approver, reviewer and device assignee."),
            dim("Employee Lifecycle Event", ELE, [("20", "Employee Lifecycle Event")],
                note="Conformed from DP-192: joiner, mover and leaver events that grant or revoke access."),
            dim("Org Unit", ORG, [("09", "Org Unit")], note="Conformed from DP-013."),
            dim("Internal Legal Entity", ILE, note="Conformed from DP-013: the employing legal entity."),
            dim("As-of Date", CAL, note="Conformed DP-013 Calendar Date: the snapshot date."),
        ],
        relationships=[
            rel("Fact System Access Grant", "Digital Identity", ["Grantee Identity"]),
            rel("Fact System Access Grant", "Application Access Role", ["Granted Access Role"],
                note="Granted Access Role carries the role's application and role code."),
            rel("Fact System Access Grant", "Employee", ["Access Approver"], optional=True),
            rel("Fact System Access Grant", "Employee Lifecycle Event", ["Granting Lifecycle Event"], optional=True),
            rel("Fact System Access Grant", "Employee Lifecycle Event", ["Revoking Lifecycle Event"], optional=True),
            rel("Fact System Access Grant", "Entitlement", ["Provisioned Data Entitlement"], optional=True),
            rel("Fact System Access Grant", "As-of Date", ["As-of Date Key"], note="Carries the snapshot date."),
            rel("Fact Access Review Decision", "Access Review Campaign", ["Decision Campaign"]),
            rel("Fact Access Review Decision", "Fact System Access Grant", ["Reviewed Grant"],
                note="Matches the grant on System Access Grant ID across its snapshot rows."),
            rel("Fact Access Review Decision", "Employee", ["Access Reviewer"], optional=True),
            rel("Fact IT Asset Assignment", "Configuration Item", ["Assigned Configuration Item"]),
            rel("Fact IT Asset Assignment", "Employee", ["Device Assignee"]),
            rel("Digital Identity", "Employee", ["Identity Owner Employee"], optional=True),
            rel("Digital Identity", "Employee", ["Service Account Sponsor"], optional=True),
            rel("Application Access Role", "Application", ["Role Application"]),
            rel("Access Review Campaign", "Application", ["Reviewed Application"], optional=True),
            rel("Entitlement", "Employee", ["Entitled User"], optional=True),
            rel("Employee Lifecycle Event", "Employee", ["Event Employee"]),
            rel("Employee", "Org Unit", ["Home Org Unit"], optional=True),
            rel("Employee", "Internal Legal Entity", ["Employing Legal Entity"]),
            rel("Application", "Org Unit", ["Owning Org Unit"]),
        ],
        notes=("Identity and access star: the daily grant snapshot is the main fact, with access review decisions and "
               "device assignments as companion facts. Identities and access roles are 41 dimensions built here "
               "(no foundational model publishes them); the person, lifecycle events, org units and legal entities "
               "are conformed from DP-192 and DP-013, applications and devices from DP-211. The 14 Entitlement is "
               "read for the provisioning match only; DP-044 counts licenses. "
               "Model gap: no input attribute carries the snapshot as-of date, so Fact System Access Grant borrows "
               "As-of Date Key from the conformed Calendar Date. "
               "Model gap: Identity Owner Party (02 Party, for external users) has no dimension because DP-240 is not "
               "in the spec's upstream; it stays a degenerate key. "
               "Degenerate: Governing Access Policy; Entitled Application, Entitled Dataset and Governing License (14 "
               "objects not read)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-234": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Project Status Report", "Fact", [("41", "Project Status Report")],
                ["Reported Project", "Status Reporting Date"],
                grain="one row = project (PRJT-) x status reporting date (weekly snapshot)",
                measures=True,
                note="The product grain: RAG, actual cost to date and forecast cost at completion as the PMO reports "
                     "them; the latest report on or before the as-of date drives the portfolio view."),
            ent("Fact Project Milestone", "Fact", [("41", "Project Milestone")], ["Milestone Project", "Milestone Name"],
                grain="one row = project x milestone",
                note="Baseline, forecast and actual dates for slippage and go-live."),
            ent("Fact GL Posting", "Fact", [("19", "GL Posting")], ["Journal ID", "Journal Line Number"],
                grain="one row = journal entry x journal line",
                note="Read only for the project cost reconciliation (CD-353); certified expense stays DP-191's. "
                     "Built from the product's inputs (same key as DP-191 GL Posting) so it carries only the "
                     "attributes the reconciliation needs."),
            ent("Project Scope Link", "Bridge", [("41", "Project Scope Link")],
                ["Scoping Project", "Delivered Object Type", "Delivered Change Initiative", "Delivered Data Product",
                 "Delivered Data Quality Issue", "Delivered Application", "Delivered Regulatory Change Item",
                 "Scope Link Effective From"],
                grain="one row = project x delivered object x effective period",
                note="The only project link (CD-239): one typed delivered object per row, so each target link is "
                     "optional."),
            # -- dimensions
            ent("Project", "Dimension", [("41", "Project")], ["Project ID"],
                note="No foundational model publishes 41 projects; approved budget and the capitalization flag sit "
                     "here."),
            ent("Change Program", "Dimension", [("41", "Change Program")], ["Change Program Code"],
                note="Parent of projects; strategic objective and business lines for the portfolio roll-up."),
            ent("Financial Plan Version", "Dimension", [("19", "Financial Plan Version")],
                ["Financial Plan Version ID"],
                note="Read from 19 directly (DP-194 is a consumer product and is not upstream, spec boundary)."),
            ent("Product Change Initiative", "Dimension", [("36", "Product Change Initiative")],
                ["Product Change Initiative ID"],
                note="Read from 36 directly so DP-105 to DP-107 may depend on this product."),
            ent("Regulatory Change Item", "Dimension", [("38", "Regulatory Change Item")], ["Regulatory Change ID"],
                note="Read from 38 directly; DP-223 must never be upstream (no cycle)."),
            ent("Data Quality Issue", "Dimension", [("21", "Data Quality Issue")], ["DQ Issue ID"],
                note="Built from 21 here because DP-103 is a consumer product."),
            dim("Data Product", DPROD, [("21", "Data Product")], note="Conformed from the DP-101 catalog."),
            dim("Application", APP, [("41", "Application")],
                note="Conformed from DP-211: delivered applications and their go-live dates."),
            dim("Journal Entry", JE, [("19", "Journal Entry")],
                note="Conformed from DP-191: Journal Status = Posted and the posting period."),
            dim("GL Account", GLACCT, note="Conformed from DP-190: account type of the posting."),
            dim("Cost Center", CC, note="Conformed DP-190 Cost Center (19 Chart Segment Value)."),
            dim("Fiscal Period", FPER, [("09", "Fiscal Period")], note="Conformed from DP-013."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: sponsors and project managers (departed leadership)."),
            dim("Calendar Date", CAL, note="Conformed from DP-013: the status reporting date."),
        ],
        relationships=[
            rel("Fact Project Status Report", "Project", ["Reported Project"]),
            rel("Fact Project Status Report", "Calendar Date", ["Status Reporting Date"]),
            rel("Fact Project Milestone", "Project", ["Milestone Project"]),
            rel("Project Scope Link", "Project", ["Scoping Project"]),
            rel("Project Scope Link", "Product Change Initiative", ["Delivered Change Initiative"], optional=True),
            rel("Project Scope Link", "Data Product", ["Delivered Data Product"], optional=True),
            rel("Project Scope Link", "Data Quality Issue", ["Delivered Data Quality Issue"], optional=True),
            rel("Project Scope Link", "Application", ["Delivered Application"], optional=True),
            rel("Project Scope Link", "Regulatory Change Item", ["Delivered Regulatory Change Item"], optional=True),
            rel("Project", "Change Program", ["Parent Change Program"], optional=True),
            rel("Project", "Employee", ["Project Sponsor"], optional=True),
            rel("Project", "Employee", ["Project Manager"]),
            rel("Project", "Financial Plan Version", ["Budget Plan Version"], optional=True),
            rel("Change Program", "Employee", ["Program Sponsor"]),
            rel("Fact GL Posting", "Journal Entry", ["Journal ID"]),
            rel("Fact GL Posting", "GL Account", ["Posted Account"]),
            rel("Fact GL Posting", "Cost Center", ["Cost Center Segment Value"], optional=True),
            rel("Fact GL Posting", "Project", ["Project Key"], optional=True,
                note="Model gap: derived link. Project Key is set from the project segment value inside Other Segment "
                     "Values, whose code is the Project ID (spec taxonomy gap: GL Posting has no project reference)."),
            rel("Journal Entry", "Fiscal Period", ["Posting Accounting Period"]),
        ],
        notes=("Project portfolio star: the weekly project status report is the main fact, with milestones and GL "
               "postings as companion facts and Project Scope Link as the bridge to delivered objects. Projects, "
               "programs, plan versions, product change initiatives, regulatory change items and data quality issues "
               "are built here from their inputs (no foundational model publishes them); applications, data products, "
               "journals, GL accounts, cost centers, fiscal periods and employees are conformed. "
               "Model gap: 19 GL Posting has no project reference, so the posting reaches the project on a derived "
               "Project Key taken from the project segment value in Other Segment Values (its code is the Project ID). "
               "Other Segment Values itself references 19 Chart Segment Value (multi-valued) and stays an attribute; "
               "Cost Center Segment Value keeps the chart segment link. "
               "Degenerate: Journal Ledger (19 Ledger is not an input)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-235": dict(
        style="Star",
        entities=[
            ent("Brand", "Dimension", [("42", "Brand")], ["Brand ID"],
                measures=True,
                note="The brand dimension this product publishes for DP-236 and others, kept as SCD type 2 by the "
                     "build. Holds the measures because every measure counts brands or is stated per brand (active "
                     "brands, unprotected jurisdictions, retired brands still authorized)."),
            ent("Fact Brand Standard Version", "Fact", [("42", "Brand Standard Version")],
                ["Standard Brand", "Standard Version Number"],
                grain="one row = brand x standard version",
                note="Brands Without Current Standard tests the effective window."),
            ent("Fact Brand Use Authorization", "Fact", [("42", "Brand Use Authorization")],
                ["Authorized Brand", "Licensee Entity", "Licensee Party", "Brand Use Effective From"],
                grain="one row = brand x licensee (entity or party) x effective period",
                note="Usage rights, tested against license grants and contracts."),
            ent("Fact Trademark Registration", "Fact", [("39", "Trademark Registration")],
                ["Trademark Registration ID"],
                grain="one row = trademark registration (TMARK-)",
                note="Protection of each brand by IP office and Nice class; read from 39 (CD-259)."),
            ent("Fact Trademark Docket Deadline", "Fact", [("39", "Trademark Docket Deadline")],
                ["Docket Registration", "Docket Deadline Type", "Docket Due Date"],
                grain="one row = trademark registration x docket deadline type x due date",
                note="Renewal and use-declaration deadlines."),
            ent("Fact Trademark License Grant", "Fact", [("39", "Trademark License Grant")],
                ["Licensed Registration", "Licensee Entity", "Licensee Party", "License Effective From"],
                grain="one row = trademark registration x licensee (entity or party) x effective period",
                note="The licensed right that a brand use authorization must sit within."),
            dim("Contract", CONTRACT, [("39", "Contract")],
                note="Conformed from DP-213; status and dates are read as DP-213 publishes them (CD-257)."),
            dim("Party", PARTY, [("02", "Party")], note="Conformed from DP-240: third-party licensees."),
            dim("Internal Legal Entity", ILE, [("09", "Internal Legal Entity")],
                note="Conformed from DP-013: owning, licensee and contracting entities."),
            dim("Country", COUNTRY, [("09", "Country")],
                note="Conformed from DP-013: permitted jurisdictions of a brand."),
            dim("Employee", EMP, note="Conformed from DP-192: the standard's approver."),
            dim("Effective Date", CAL, note="Conformed DP-013 Calendar Date: the authorization effective date."),
        ],
        relationships=[
            rel("Brand", "Brand", ["Parent Brand"], optional=True, note="Brand hierarchy (sub-brand to parent)."),
            rel("Brand", "Internal Legal Entity", ["Brand Owning Entity"]),
            rel("Brand", "Country", ["Brand Permitted Jurisdictions"], card="M:N", optional=True,
                note="A text list of country codes (spec taxonomy gap); one row per jurisdiction after the build "
                     "explodes it."),
            rel("Fact Brand Standard Version", "Brand", ["Standard Brand"]),
            rel("Fact Brand Standard Version", "Employee", ["Standard Approved By"], optional=True),
            rel("Fact Brand Use Authorization", "Brand", ["Authorized Brand"]),
            rel("Fact Brand Use Authorization", "Internal Legal Entity", ["Licensee Entity"], optional=True),
            rel("Fact Brand Use Authorization", "Party", ["Licensee Party"], optional=True),
            rel("Fact Brand Use Authorization", "Contract", ["Brand Use Contract"], optional=True),
            rel("Fact Brand Use Authorization", "Effective Date", ["Brand Use Effective From"]),
            rel("Fact Trademark Registration", "Brand", ["Protected Brand"], optional=True),
            rel("Fact Trademark Registration", "Internal Legal Entity", ["Trademark Owner Entity"]),
            rel("Fact Trademark Docket Deadline", "Fact Trademark Registration", ["Docket Registration"]),
            rel("Fact Trademark License Grant", "Fact Trademark Registration", ["Licensed Registration"]),
            rel("Fact Trademark License Grant", "Internal Legal Entity", ["Licensee Entity"], optional=True),
            rel("Fact Trademark License Grant", "Party", ["Licensee Party"], optional=True),
            rel("Fact Trademark License Grant", "Contract", ["Licensing Contract"], optional=True),
            rel("Contract", "Internal Legal Entity", ["Contracting Entity"], optional=True),
        ],
        notes=("Brand register star: the Brand dimension (SCD type 2) is the product's spine and holds the measures, "
               "because this consumer-aligned master publishes the brand dimension itself; standards, usage "
               "authorizations, trademark registrations, docket deadlines and license grants are facts that hang off "
               "it. Contracts are DP-213, licensee parties DP-240, entities and countries DP-013. "
               "Model gap: 42 Brand carries no effective-from attribute, so the SCD type 2 version is kept by the "
               "build and the key stays Brand ID. "
               "IP Office stays a degenerate code on the registration (no office-to-country mapping in the taxonomy, "
               "spec taxonomy gap)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-236": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Media Coverage", "Fact", [("42", "Media Coverage Item")], ["Coverage Item ID"],
                grain="one row = media coverage item (MCOV-) x mentioned brand; the brands explode through the M:N "
                      "link",
                measures=True,
                note="The product grain: volume, reach, sentiment, coverage per release, embargo breaches and "
                     "spokesperson checks."),
            ent("Fact Media Inquiry", "Fact", [("42", "Media Inquiry")], ["Media Inquiry ID"],
                grain="one row = media inquiry (MEDQ-)",
                note="Inquiry Communications Issue stays a degenerate key (the issue is DP-237's)."),
            ent("Fact Press Release", "Fact", [("42", "Press Release")], ["Press Release ID"],
                grain="one row = press release (NEWS-)",
                note="Release Change Initiative, Release Publication Property and Coordinated Shareholder "
                     "Communication stay degenerate keys (36, 04 and 13 objects are not inputs)."),
            ent("Fact Reputation Measurement", "Fact", [("42", "Reputation Measurement")],
                ["Measured Brand", "Reputation Measure", "Measurement Provider", "Measurement Stakeholder Group",
                 "Measurement Period Start", "Measurement Period End"],
                grain="one row = brand x reputation measure x provider x stakeholder group x measurement period",
                note="Provider-sourced reputation and share-of-voice values."),
            ent("Fact Award Entry", "Fact", [("42", "Corporate Award Entry")],
                ["Award Program Name", "Entry Category", "Award Year", "Entrant Entity", "Entrant Product",
                 "Entrant Employee"],
                grain="one row = award program x entry category x award year x entrant",
                note="Firm and individual results here; fund and manager results through the 11 Award record."),
            # -- dimensions
            ent("Brand", "Dimension", [("42", "Brand")], ["Brand ID"],
                note="Built from 42 here with the DP-235 key because DP-235 is a consumer product; joins to DP-235's "
                     "Brand on Brand ID."),
            ent("Media Contact Profile", "Dimension", [("42", "Media Contact Profile")],
                ["Media Party", "Media Profile Effective From"],
                note="Journalist profile by effective period (outlet, outlet type, beats, relationship owner)."),
            ent("Spokesperson Authorization", "Dimension", [("42", "Spokesperson Authorization")],
                ["Spokesperson", "Spokesperson Effective From"],
                note="Authorization periods tested against quoted spokespeople."),
            ent("Corporate Event", "Dimension", [("42", "Corporate Event")], ["Corporate Event ID"],
                note="Events announced by a press release."),
            ent("Compliance Review", "Dimension", [("08", "Compliance Review")], ["Review ID"],
                note="Read from 08 (DP-036 is a consumer product, so no conformed source); never re-reviewed here."),
            ent("Compliance Approval", "Dimension", [("08", "Compliance Approval")],
                ["Compliance Review Key", "Approval Decision Date"],
                note="Child of Compliance Review (fold=False): one row per approval decision, for Fund Releases "
                     "Without Prior Approval."),
            ent("Award", "Dimension", [("11", "Award")], ["Award ID"],
                note="Fund and manager award results and the paid-to-participate fact, built from 11 because DP-030 "
                     "is a consumer product."),
            dim("Investment Product", PROD, [("01", "Investment Product")],
                note="Conformed from DP-004: release subject products and award entrant products."),
            dim("Share Class", SHARE, note="Conformed from DP-004: products featured in a compliance review."),
            dim("Party", PARTY, [("02", "Party")],
                note="Conformed from DP-240: journalists, coverage authors, measurement providers, award organizers."),
            dim("Media Outlet", PARTY, note="Conformed DP-240 Party in its media outlet role."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: spokespeople, handlers, approvers, entrants, relationship owners."),
            dim("Internal Legal Entity", ILE, note="Conformed from DP-013: issuing and entrant entities."),
            dim("Calendar Date", CAL, note="Conformed from DP-013: publication date."),
        ],
        relationships=[
            rel("Fact Media Coverage", "Brand", ["Coverage Mentioned Brands"], card="M:N",
                note="Multi-valued: one row per mentioned brand after the build explodes the list."),
            rel("Fact Media Coverage", "Media Outlet", ["Coverage Outlet"]),
            rel("Fact Media Coverage", "Party", ["Coverage Author"], optional=True),
            rel("Fact Media Coverage", "Employee", ["Quoted Spokesperson"], optional=True),
            rel("Fact Media Coverage", "Fact Press Release", ["Originating Press Release"], optional=True),
            rel("Fact Media Coverage", "Fact Media Inquiry", ["Originating Media Inquiry"], optional=True),
            rel("Fact Media Coverage", "Calendar Date", ["Coverage Publication Date"]),
            rel("Fact Media Inquiry", "Party", ["Inquiring Journalist"], optional=True),
            rel("Fact Media Inquiry", "Media Outlet", ["Inquiring Outlet"], optional=True),
            rel("Fact Media Inquiry", "Employee", ["Inquiry Handled By"], optional=True),
            rel("Fact Press Release", "Internal Legal Entity", ["Issuing Entity"]),
            rel("Fact Press Release", "Investment Product", ["Release Subject Products"], card="M:N", optional=True),
            rel("Fact Press Release", "Compliance Review", ["Release Compliance Review"], optional=True),
            rel("Fact Press Release", "Employee", ["Release Approved By"], optional=True),
            rel("Fact Reputation Measurement", "Brand", ["Measured Brand"]),
            rel("Fact Reputation Measurement", "Party", ["Measurement Provider"]),
            rel("Fact Reputation Measurement", "Calendar Date", ["Measurement Period End"]),
            rel("Fact Award Entry", "Party", ["Award Organizer"], optional=True),
            rel("Fact Award Entry", "Internal Legal Entity", ["Entrant Entity"], optional=True),
            rel("Fact Award Entry", "Investment Product", ["Entrant Product"], optional=True),
            rel("Fact Award Entry", "Employee", ["Entrant Employee"], optional=True),
            rel("Fact Award Entry", "Award", ["Fund or Manager Award Record"], optional=True),
            rel("Media Contact Profile", "Party", ["Media Party"]),
            rel("Media Contact Profile", "Media Outlet", ["Media Outlet"], optional=True),
            rel("Media Contact Profile", "Employee", ["Media Relationship Owner"], optional=True),
            rel("Spokesperson Authorization", "Employee", ["Spokesperson"]),
            rel("Corporate Event", "Fact Press Release", ["Event Press Release"], optional=True),
            rel("Compliance Approval", "Compliance Review", ["Compliance Review Key"]),
            rel("Compliance Review", "Share Class", ["Products Featured"], card="M:N", optional=True),
            rel("Award", "Compliance Review", ["Citation Approval"], optional=True),
            rel("Share Class", "Investment Product", ["Parent Product"]),
        ],
        notes=("Media and reputation constellation: coverage by mentioned brand is the main fact, with inquiries, "
               "press releases, reputation measurements and award entries as companion facts. Journalists, outlets, "
               "providers and organizers are DP-240 parties (Media Outlet is the outlet role of the same Party); "
               "products and share classes are DP-004, spokespeople DP-192, entities and dates DP-013. Brand, "
               "compliance review and award are built from their inputs because DP-235, DP-036 and DP-030 are "
               "consumer products. "
               "Model gap: 08 Compliance Approval carries no review attribute, so it borrows Compliance Review Key "
               "(the registry's parent key). "
               "Degenerate: Inquiry Communications Issue, Release Change Initiative, Release Publication Property, "
               "Coordinated Shareholder Communication (their objects are not inputs)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-237": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Communications Issue", "Fact", [("42", "Communications Issue")], ["Communications Issue ID"],
                grain="one row = communications issue (CRIS-)",
                measures=True,
                note="Holds the measures because open issues, time to first statement, trigger-to-statement time and "
                     "crises without a plan are all stated per issue; statements are its child fact."),
            ent("Fact Issue Statement", "Fact", [("42", "Issue Statement")],
                ["Statement Issue", "Statement Type", "Statement Audience", "Statement Version"],
                grain="one row = communications issue x statement type x audience x version",
                note="The product grain under the issue: release and approval of each statement."),
            ent("Fact Internal Communication", "Fact", [("42", "Internal Communication")],
                ["Internal Communication ID"],
                grain="one row = internal communication",
                note="Announced Policy stays a degenerate key (38 Policy is not an input)."),
            ent("Fact Internal Communication Audience", "Fact", [("42", "Internal Communication Audience")],
                ["Audience Communication", "Audience Segment Type", "Audience Org Unit", "Audience Office",
                 "Audience Legal Entity", "Audience Job Profile"],
                grain="one row = internal communication x audience segment",
                note="Recipient counts for the reach denominator."),
            ent("Fact Internal Communication Engagement", "Fact", [("42", "Internal Communication Engagement")],
                ["Engagement Communication", "Engagement Channel", "Engagement Measurement Date"],
                grain="one row = internal communication x channel x measurement date",
                note="Aggregate engagement only (42 SME Q7)."),
            # -- dimensions
            ent("Crisis Communication Plan", "Dimension", [("42", "Crisis Communication Plan")],
                ["Crisis Plan Code", "Crisis Plan Version"],
                note="Plan versions; scenario types are tested against issue trigger types."),
            ent("Business Continuity Plan", "Dimension", [("37", "Business Continuity Plan")],
                ["Business Continuity Plan Code", "Business Continuity Plan Version"],
                note="Built from 37 because DP-217 is a consumer product."),
            ent("Operational Incident", "Dimension", [("37", "Operational Incident")], ["Operational Incident ID"],
                note="Trigger detection date; built from 37 because DP-215 is a consumer product."),
            ent("IT Incident", "Dimension", [("41", "IT Incident")], ["IT Incident ID"],
                note="Trigger detection timestamp; built from 41 because DP-231 is a consumer product."),
            ent("Legal Matter", "Dimension", [("39", "Legal Matter")], ["Legal Matter ID"],
                note="Only ID, type and opened date (never privileged content); built from 39 because DP-229 is a "
                     "consumer product."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: issue lead, statement approver, plan owner, sender."),
            dim("Org Unit", ORG, [("09", "Org Unit")], note="Conformed from DP-013: audience org unit."),
            dim("Office Location", OFFICE, note="Conformed from DP-013: audience office."),
            dim("Internal Legal Entity", ILE, note="Conformed from DP-013: audience legal entity."),
            dim("Job Profile", JOBP, note="Conformed from DP-192: audience job profile."),
            dim("Calendar Date", CAL, note="Conformed from DP-013: engagement measurement date."),
        ],
        relationships=[
            rel("Fact Communications Issue", "Operational Incident", ["Trigger Operational Incident"], optional=True),
            rel("Fact Communications Issue", "IT Incident", ["Trigger IT Incident"], optional=True),
            rel("Fact Communications Issue", "Legal Matter", ["Trigger Legal Matter"], optional=True),
            rel("Fact Communications Issue", "Employee", ["Issue Lead"], optional=True),
            rel("Fact Communications Issue", "Crisis Communication Plan", ["Activated Crisis Plan"], optional=True,
                note="Activated Crisis Plan carries the plan code; the version in force at Issue Opened Timestamp is "
                     "taken."),
            rel("Fact Issue Statement", "Fact Communications Issue", ["Statement Issue"]),
            rel("Fact Issue Statement", "Employee", ["Statement Approved By"], optional=True),
            rel("Crisis Communication Plan", "Employee", ["Crisis Plan Owner"], optional=True),
            rel("Crisis Communication Plan", "Business Continuity Plan", ["Linked Business Continuity Plan"],
                optional=True, note="Carries the plan code; the current approved version is taken."),
            rel("Fact Internal Communication", "Employee", ["Internal Communication Sender"], optional=True),
            rel("Fact Internal Communication", "Fact Communications Issue", ["Internal Communication Issue"],
                optional=True),
            rel("Fact Internal Communication Audience", "Fact Internal Communication", ["Audience Communication"]),
            rel("Fact Internal Communication Audience", "Org Unit", ["Audience Org Unit"], optional=True),
            rel("Fact Internal Communication Audience", "Office Location", ["Audience Office"], optional=True),
            rel("Fact Internal Communication Audience", "Internal Legal Entity", ["Audience Legal Entity"],
                optional=True),
            rel("Fact Internal Communication Audience", "Job Profile", ["Audience Job Profile"], optional=True),
            rel("Fact Internal Communication Engagement", "Fact Internal Communication", ["Engagement Communication"]),
            rel("Fact Internal Communication Engagement", "Calendar Date", ["Engagement Measurement Date"]),
        ],
        notes=("Issues and internal communications constellation: the communications issue and its statements, and "
               "internal communications with audience segments and engagement, are facts sharing the conformed "
               "DP-192 Employee and DP-013 organization dimensions. Trigger records (operational incident, IT "
               "incident, legal matter) and continuity plans are built from their inputs because DP-215, DP-231, "
               "DP-229 and DP-217 are consumer products. "
               "Model gap: Activated Crisis Plan and Linked Business Continuity Plan carry the plan code only, while "
               "both plans are keyed by code and version; the version is resolved by date in the build. "
               "Degenerate: Trigger Health and Safety Incident and Trigger Physical Security Incident (counted by "
               "trigger type only, spec boundary), Related Social Mentions (04, referenced not read), Announced "
               "Policy. Certified headcount for All-Staff Audience Coverage % is read from DP-192 at build time and "
               "has no input object here."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-238": dict(
        style="Star",
        entities=[
            # -- facts
            ent("Fact Corporate Publication", "Fact", [("42", "Corporate Publication")],
                ["Corporate Publication ID"],
                grain="one row = corporate publication version (type x publishing entity x period end x version)",
                note="First main fact: deadlines, publication dates and board approval."),
            ent("Fact Lobbying Disclosure Report", "Fact", [("42", "Lobbying Disclosure Report")],
                ["Lobbying Report ID"],
                grain="one row = lobbying disclosure report (LOBR-: registration x filer x report type x period x "
                      "amendment)",
                measures=True,
                note="Second main fact. Holds the measures because most of them (reports, expense, contacts, "
                     "contributions, dues, positions, lobbyists) are lobbying and policy measures; publication "
                     "measures reach Fact Corporate Publication through the shared entity and calendar dimensions."),
            ent("Fact Lobbying Report Issue Line", "Fact", [("42", "Lobbying Report Issue Line")],
                ["Issue Line Report", "General Issue Area Code"],
                grain="one row = lobbying report x general issue area",
                note="Entities Contacted stays text."),
            ent("Fact Government Official Contact", "Fact", [("42", "Government Official Contact")],
                ["Official Contact ID"],
                grain="one row = government official contact",
                note="Related Hospitality Item stays a degenerate key (08 Gift / Entertainment Item is not an "
                     "input)."),
            ent("Fact Consultation Response", "Fact", [("42", "Consultation Response")],
                ["Consultation Reference", "Responding Entity"],
                grain="one row = consultation x responding entity",
                note="Consulting Regulator is a code; consulting bodies other than regulators are parties."),
            ent("Fact Trade Association Membership", "Fact", [("42", "Trade Association Membership")],
                ["Trade Association", "Member Entity", "Membership Effective From"],
                grain="one row = trade association x member entity x effective period",
                note="Dues and their lobbying portion."),
            # -- bridges
            ent("Publication Source Link", "Bridge", [("42", "Publication Source Link")],
                ["Linked Publication", "Source Human Capital Metric Value",
                 "Source Capital Requirement Calculation", "Source Operational Emission Record",
                 "Other Source Record Key"],
                grain="one row = corporate publication x source record",
                note="Traces published figures to their certified owners (CD-293); one typed source per row."),
            ent("Corporate Resolution Subject Link", "Bridge", [("39", "Corporate Resolution Subject Link")],
                ["Corporate Resolution Subject Link Key"],
                grain="one row = corporate resolution x subject corporate publication",
                note="Board approval held once in 39 (DP-230); surrogate key as in the registry."),
            ent("Registered Lobbyist", "Bridge", [("42", "Registered Lobbyist")],
                ["Lobbyist", "Lobbyist Registration", "Lobbyist Effective From"],
                grain="one row = employee x lobbying registration x effective period",
                note="Many-to-many between employees and registrations over time."),
            # -- dimensions
            ent("Lobbying Registration", "Dimension", [("42", "Lobbying Registration")], ["Lobbying Registration ID"],
                note="Regime, registrant and outside lobbying firm."),
            ent("Public Policy Position", "Dimension", [("42", "Public Policy Position")],
                ["Policy Position ID", "Policy Position Version"],
                note="Policy Position Jurisdictions stays a text list (09 Country is not an input)."),
            ent("Political Contribution", "Dimension", [("38", "Political Contribution")],
                ["Political Contribution ID"],
                note="Built from 38 because DP-225 is a consumer product; no amount is read."),
            ent("Corporate Resolution", "Dimension", [("39", "Corporate Resolution")], ["Corporate Resolution ID"],
                note="Built from 39 because DP-230 is a consumer product."),
            ent("Human Capital Metric Value", "Dimension", [("20", "Human Capital Metric Value")],
                ["Metric Definition", "Metric Legal Entity", "Metric Breakdown", "Metric Period End Date"],
                note="Certified values from DP-201 (a consumer product), read not recomputed. Key narrowed to the "
                     "inputs (see notes)."),
            ent("Capital Requirement Calculation", "Dimension", [("43", "Capital Requirement Calculation")],
                ["Capital Calculation ID"],
                note="Built from 43 because DP-205 is a consumer product."),
            dim("Employee", EMP, [("20", "Employee")],
                note="Conformed from DP-192: signatories, lobbyists, filers, attendees, contributors."),
            dim("Internal Legal Entity", ILE, [("09", "Internal Legal Entity")],
                note="Conformed from DP-013: publishing, registrant, responding, member and metric entities."),
            dim("Party", PARTY,
                note="Conformed from DP-240: officials, agencies, trade associations, consulting bodies and outside "
                     "lobbying firms."),
            dim("Calendar Date", CAL, note="Conformed from DP-013: publication period end."),
        ],
        relationships=[
            rel("Fact Corporate Publication", "Internal Legal Entity", ["Publishing Entity"]),
            rel("Fact Corporate Publication", "Employee", ["Publication Signatory"], optional=True),
            rel("Fact Corporate Publication", "Calendar Date", ["Publication Period End"]),
            rel("Publication Source Link", "Fact Corporate Publication", ["Linked Publication"]),
            rel("Publication Source Link", "Human Capital Metric Value", ["Source Human Capital Metric Value"],
                optional=True, note="Carries the metric value reference; resolves on the metric value's key."),
            rel("Publication Source Link", "Capital Requirement Calculation", ["Source Capital Requirement Calculation"],
                optional=True),
            rel("Corporate Resolution Subject Link", "Corporate Resolution", ["Linked Corporate Resolution"]),
            rel("Corporate Resolution Subject Link", "Fact Corporate Publication", ["Subject Corporate Publication"],
                optional=True),
            rel("Fact Lobbying Disclosure Report", "Lobbying Registration", ["Report Registration"]),
            rel("Fact Lobbying Disclosure Report", "Employee", ["Filing Lobbyist"], optional=True),
            rel("Fact Lobbying Disclosure Report", "Fact Lobbying Disclosure Report", ["Amended Report"],
                optional=True, note="An amendment points to the report it amends."),
            rel("Fact Lobbying Disclosure Report", "Political Contribution", ["Reported Political Contributions"],
                card="M:N", optional=True, note="LD-203 rows reference the contributions they report."),
            rel("Fact Lobbying Report Issue Line", "Fact Lobbying Disclosure Report", ["Issue Line Report"]),
            rel("Fact Lobbying Report Issue Line", "Employee", ["Issue Line Lobbyists"], card="M:N", optional=True),
            rel("Registered Lobbyist", "Employee", ["Lobbyist"]),
            rel("Registered Lobbyist", "Lobbying Registration", ["Lobbyist Registration"]),
            rel("Lobbying Registration", "Internal Legal Entity", ["Registrant Entity"]),
            rel("Lobbying Registration", "Party", ["Outside Lobbying Firm"], optional=True),
            rel("Fact Government Official Contact", "Party", ["Contacted Official"]),
            rel("Fact Government Official Contact", "Party", ["Official Agency"], optional=True),
            rel("Fact Government Official Contact", "Employee", ["Firm Attendees"], card="M:N"),
            rel("Fact Government Official Contact", "Public Policy Position", ["Discussed Position"], optional=True),
            rel("Fact Consultation Response", "Party", ["Consulting Body"], optional=True),
            rel("Fact Consultation Response", "Internal Legal Entity", ["Responding Entity"]),
            rel("Fact Consultation Response", "Public Policy Position", ["Response Position"], optional=True),
            rel("Fact Consultation Response", "Party", ["Joint Response Association"], optional=True),
            rel("Fact Trade Association Membership", "Party", ["Trade Association"]),
            rel("Fact Trade Association Membership", "Internal Legal Entity", ["Member Entity"]),
            rel("Political Contribution", "Employee", ["Contributor Employee"]),
            rel("Human Capital Metric Value", "Internal Legal Entity", ["Metric Legal Entity"], optional=True),
            rel("Capital Requirement Calculation", "Internal Legal Entity", ["Calculation Entity"]),
        ],
        notes=("Disclosures and lobbying constellation with two main facts, corporate publication versions and "
               "lobbying disclosure reports, plus official contacts, consultation responses and trade association "
               "memberships as companion facts. Registered Lobbyist bridges employees and registrations; the "
               "publication source link and the 39 resolution subject link bridge publications to their certified "
               "sources and board approvals. Source records of other consumer products (DP-201, DP-205, DP-225, "
               "DP-230) are built from their inputs. Parties are DP-240, people DP-192, entities and dates DP-013. "
               "Model gap: the registry key of 20 Human Capital Metric Value also names Metric Org Unit, Metric Country "
               "and Metric Period Type, which are not product inputs, so the key is narrowed to the four input key "
               "attributes; add those three attributes to the spec input to carry the full key. "
               "W1b re-point (CW-934, CW-942): Source PAI Calculation left the bridge key with the 34 object. "
               "Degenerate: Source Operational Emission Record (traced only by the link, "
               "spec boundary), Metric Definition (DP-101 is not upstream), Publication Property, Related Hospitality "
               "Item, Consulting Regulator."),
    ),
}
