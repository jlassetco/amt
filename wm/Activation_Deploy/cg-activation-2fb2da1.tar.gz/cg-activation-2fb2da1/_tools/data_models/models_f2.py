"""Logical data models: foundational ER models for DP-006, DP-007, DP-009 and DP-010. See CONTRACT.md.

Conventions (same as models_pilot_er.py):
- One entity per business object; folded Attribute Groups sit in their parent's entity; child groups (fold=False) are
  child entities M:1 to their parent and borrow "<Parent> Key" (which carries the parent's natural key) where they have
  no attribute naming the parent.
- Entities that consumer models reuse as conformed dimensions carry the shared names: Transaction, Attribution Record
  (DP-006); Position, Account (DP-007); Employee, Coverage Team, Coverage Assignment (DP-009); Advisor Activity (DP-010).
- References to objects outside the product are external references, resolved by joining to the upstream product
  named in the model notes; they are not linked inside the model.
- Where no attribute can carry a link the product needs, the model adds "<Parent> Key" as a placeholder foreign key and
  records a "Model gap:".
"""

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-006": dict(
        # WP1 re-point (CW-203): re-cut to the specs_w1f_certified.py DP-006 inputs; see notes.
        style='ER',
        entities=[
            dict(name='Transaction',
                 role='Entity',
                 objects=[('06', 'Transaction'), ('06', 'Transaction Dates'), ('06', 'Transaction Amounts'), ('06', 'Order Source'), ('06', 'Intermediary As Delivered'), ('06', 'ETF Creation / Redemption'), ('06', 'SMA Flow'), ('06', 'Transaction Status')],
                 pk=['Transaction ID'],
                 grain='one row = one source-delivered transaction leg (purchase, redemption, exchange, transfer, conversion, ETF creation / redemption or SMA flow) per cancel / correct version',
                 note='Conformed transaction entity. Dates, amounts, order source, intermediary codes as delivered and status all fold here (one per transaction version). ETF Creation / Redemption and SMA Flow columns are populated only for those transaction types. A cancel or correction is a new row that names the version it replaces in Original Transaction ID. The Resolved Distributor Firm / Office / Advisor columns are the first-pass resolution of the delivered dealer, branch and rep numbers; the published attribution is on Attribution Record.'),
            dict(name='Linked Transaction',
                 role='Entity',
                 objects=[('06', 'Linked Transaction')],
                 pk=['Transaction Key', 'Linked Transaction ID'],
                 grain='one row = transaction x linked contra transaction (exchange, transfer or conversion pair)',
                 note='Child of Transaction (fold=False in the registry). Key is the owning Transaction Key (carries the Transaction ID) + Linked Transaction ID. Same-Owner Indicator here drives the Same-Owner Movement Flag.'),
            dict(name='Attribution Record',
                 role='Entity',
                 objects=[('06', 'Attribution Record'), ('06', 'Market & Client Dimensions'), ('06', 'Attribution Method'), ('06', 'Unattributed Item')],
                 pk=['Attribution Record ID'],
                 measures=True,
                 grain='one row = transaction version x attributed distributor hierarchy node x attribution effective date (the product grain)',
                 note="Core entity and conformed name. Distributor Hierarchy (firm > office > team > advisor), Market & Client Dimensions (channel, plan, client, consultant), Attribution Method and Unattributed Item all fold here: one of each per attribution record. A record resolved only to a higher level carries its suspense amount and reason in the Unattributed Item columns, so attributed + unattributed reconciles to the transaction's Reporting Currency Amount. Prior attributions are kept as separate rows (new Attribution Effective Date), never overwritten. Holds the product measures."),
            dict(name='Identifier Crosswalk',
                 role='Entity',
                 objects=[('06', 'Identifier Crosswalk')],
                 pk=['Source Feed', 'Source Identifier Type', 'Source Identifier Value', 'Crosswalk Effective From'],
                 grain='one row = source feed x source identifier type x source identifier value x effective period',
                 note='Resolves the dealer, branch and representative numbers delivered on each feed to a Party (Resolved Party) and CRD number, effective-dated so re-attribution can replay history.'),
            dict(name='Data Feed',
                 role='Entity',
                 objects=[('06', 'Data Feed')],
                 pk=['Feed ID'],
                 grain='one row = data feed (provider x content x layout)',
                 note='Source Precedence Rank decides which feed wins when the same transaction arrives on more than one feed (de-duplication).'),
            dict(name='Reporting Period',
                 role='Entity',
                 objects=[('06', 'Reporting Period')],
                 pk=['Reporting Period ID'],
                 grain='one row = reporting period (period type x period)',
                 note="Same key as the DP-008 Reporting Period. Taken as an input for its Final Close Date, which the Late Correction Flag compares with each transaction version's As-Of Date."),
            dict(name='Account Channel Assignment',
                 role='Entity',
                 objects=[('06', 'Account Channel Assignment')],
                 pk=['Channel Assignment ID']),
            dict(name='Account Asset Summary',
                 role='Entity',
                 objects=[('06', 'Account Asset Summary')],
                 pk=['Account Asset Summary Key']),
            dict(name='Client Account Activity',
                 role='Entity',
                 objects=[('49', 'Client Account Activity')],
                 pk=['Client Account Activity ID']),
            dict(name='Register Transaction',
                 role='Entity',
                 objects=[('29', 'Register Transaction')],
                 pk=['Register Transaction ID']),
            dict(name='Participant Ledger Posting',
                 role='Entity',
                 objects=[('16', 'Participant Ledger Posting')],
                 pk=['Ledger Posting ID']),
            dict(name='Portfolio Capital Activity',
                 role='Entity',
                 objects=[('18', 'Portfolio Capital Activity')],
                 pk=['Portfolio Capital Activity Key']),
            dict(name='Account',
                 role='Entity',
                 objects=[('15', 'Account')],
                 pk=['Account ID']),
        ],
        relationships=[
            dict(child='Attribution Record', parent='Transaction', fk=['Source Transaction'], card='M:1', note="Every attribution record in this product is sourced from a transaction version (Source Record Type = transaction); Attribution Share % across one version's records sums to 100%."),
            dict(child='Linked Transaction', parent='Transaction', fk=['Transaction Key'], card='M:1', note='The transaction that owns the link. Transaction Key carries the Transaction ID.'),
            dict(child='Linked Transaction', parent='Transaction', fk=['Linked Transaction ID'], card='M:1', note='The contra leg of the exchange, transfer or conversion.'),
            dict(child='Transaction', parent='Transaction', fk=['Original Transaction ID'], card='M:1', optional=True, note='Cancel / correct chain: the version this row cancels or corrects.'),
            dict(child='Transaction', parent='Data Feed', fk=['Source Feed'], card='M:1'),
            dict(child='Attribution Record', parent='Data Feed', fk=['Attribution Source'], card='M:1', optional=True, note='Feed that supplied the attribution evidence (e.g. a look-through or rep-code file).'),
            dict(child='Identifier Crosswalk', parent='Data Feed', fk=['Source Feed'], card='M:1'),
            dict(child='Transaction', parent='Identifier Crosswalk', fk=['Intermediary Identifier Scheme', 'Representative Number'], card='M:N', optional=True, note="Value lookup, not a key: the delivered representative number (and in the same way Dealer / Firm Number and Branch Number) is matched to Source Identifier Type + Source Identifier Value for the transaction's Source Feed, effective on the Trade Date."),
            dict(child='Transaction', parent='Reporting Period', fk=['As-Of Date'], card='M:N', optional=True, note="Date-range lookup, not a key: the reporting period(s) whose span contains the As-Of Date. A version with an As-Of Date after that period's Final Close Date is a late correction. Reporting Period has no start / end date attribute, so the span is taken from the DP-013 calendar (see Model gap)."),
            dict(child='Transaction', parent='Account', fk=['Account'], card='M:1', optional=True),
            dict(child='Transaction', parent='Client Account Activity', fk=['Source Client Account Activity'], card='M:1', optional=True),
            dict(child='Transaction', parent='Register Transaction', fk=['Source Register Transaction'], card='M:1', optional=True),
            dict(child='Transaction', parent='Participant Ledger Posting', fk=['Source Participant Ledger Posting'], card='M:1', optional=True),
            dict(child='Transaction', parent='Portfolio Capital Activity', fk=['Source Portfolio Capital Activity'], card='M:1', optional=True),
            dict(child='Transaction', parent='Account Channel Assignment', fk=['Source Channel Assignment'], card='M:1', optional=True),
            dict(child='Identifier Crosswalk', parent='Account', fk=['Resolved Account'], card='M:1', optional=True),
            dict(child='Account Channel Assignment', parent='Account', fk=['Assigned Account'], card='M:1', optional=True),
            dict(child='Account Asset Summary', parent='Account', fk=['Summary Account'], card='M:1', optional=True),
            dict(child='Client Account Activity', parent='Account', fk=['Activity Account'], card='M:1', optional=True),
            dict(child='Register Transaction', parent='Account', fk=['Posting Account'], card='M:1', optional=True),
            dict(child='Portfolio Capital Activity', parent='Account', fk=['Activity Account'], card='M:1', optional=True),
        ],
        notes="Foundational transaction-level fact, modeled ER with Transaction (one row per source version) and Attribution Record (one row per attributed hierarchy node) at the center. Salesperson Credit and Linked Transaction are child entities because they repeat within their parent. The product measures sit on Attribution Record; Unattributed Amount shares its name with the Unattributed Item column and is published once. Same-Owner Movement Flag is derived through Linked Transaction, Late Correction Flag from Transaction Status and As-Of Date. External references (resolved by joining to the upstream product, not linked here): Share Class, Product and Linked Transaction.Contra Share Class to DP-004; Account to DP-003 (15 Account); Resolved Distributor Firm, Resolved Office / Branch, Distributor Firm, Distributor Office / Branch and Advisor Team to the 05 Distributor Firm, Branch / Office and Advisor Team (CW-132; DP-001 until WP0); Contra Firm, Authorized Participant, Resolved Party and Data Provider to Party (DP-001); Resolved Advisor / Rep and Advisor / Rep to 05 Financial Professional (DP-002 until WP0); Retirement Plan and Consultant to DP-003 and Institutional Client to 12 Institutional Client (CW-133); Credited Salesperson to Employee (DP-009); Salesperson Credit.Source Partner Coverage Assignment to 05 Partner Coverage Assignment; Sponsor Program to Distribution Agreement (DP-005); SMA Flow.Model Portfolio to Model Portfolio (DP-004). W4 (CW-141, CW-143): Transaction Sales Charge, Territory, Platform / Fund Distributor (EU/UK), Crediting Rule Applied and Suspense Territory / Bucket left the inputs (spec notes); Suspense Channel replaces the suspense territory. Model gap: 06 Reporting Period has no period start / end date attribute in the taxonomy, so the period containing a transaction's As-Of Date (and so the Final Close Date the Late Correction Flag tests) is found through the DP-013 calendar; add Period Start Date and Period End Date to 06 Reporting Period. Model gap: no attribute on Transaction names the FX rate type applied (see the FX Rate Type relationship). Model gap: the Identifier Crosswalk link is a value match; neither Transaction nor Attribution Record records which crosswalk row resolved it, so lineage of a resolution is not enforceable. WP1 re-point (CW-203): re-cut to Client Flow Transactions. Transaction (14 conformers), Attribution Record, Data Feed, Linked Transaction and Identifier Crosswalk keep their objects and keys; 06 Distributor Hierarchy, Salesperson Credit and 09 FX Rate Type leave with the spec inputs. The source flow books (49 Client Account Activity, 29 Register Transaction, 16 Participant Ledger Posting, 18 Portfolio Capital Activity), 06 Account Channel Assignment and Account Asset Summary and 15 Account are placed as entities keyed by the registry and linked by the Order Source references; where the spec reads no key attribute the entity has a surrogate key.",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-007": dict(
        # WP1 re-point (CW-203): re-cut to the specs_w1f_certified.py DP-007 inputs; see notes.
        style='ER',
        entities=[
            dict(name='Position',
                 role='Entity',
                 objects=[('06', 'Fund Shareholder Position'), ('06', 'Omnibus Look-Through'), ('06', 'ETF Holding'), ('06', 'Plan Position'), ('06', 'Sponsor-Reported Assets')],
                 pk=['Position ID'],
                 grain='one row = account or sub-account x share class x valuation date x position source',
                 note="Conformed position entity (06 Fund Shareholder Position, renamed from Position at W4, CW-007; the entity keeps the conformed name). Omnibus Look-Through, ETF Holding, Plan Position and Sponsor-Reported Assets fold here: each source type is loaded as a position of its own account (sub-account, DTC participant, plan account or sponsor program), so each group's columns are populated only for positions of that source. Several sources can hold the same account x share class x date; only the one with the best Source Precedence Rank is attributed, the others are kept for reconciliation."),
            dict(name='Attribution Record',
                 role='Entity',
                 objects=[('06', 'Attribution Record'), ('06', 'Market & Client Dimensions'), ('06', 'Attribution Method'), ('06', 'Unattributed Item')],
                 pk=['Attribution Record ID'],
                 measures=True,
                 grain='one row = position x attributed distributor hierarchy node x attribution effective date (the product grain)',
                 note='Core entity; same shape and name as in DP-006 but sourced from positions (Source Position) instead of transactions. Distributor Hierarchy, Market & Client Dimensions, Attribution Method and Unattributed Item fold here. Holds the product measures. The Look-Through Coverage % measure is the partner x valuation date rollup of the position-level column of the same name on Position.'),
            dict(name='Account',
                 role='Entity',
                 objects=[('15', 'Account')],
                 pk=['Account ID'],
                 grain='one row = account',
                 note='Conformed account entity (account, omnibus parent or sub-account). Intermediary Account Servicing folds here: networking level and the dealer, branch and rep of record that feed account-of-record attribution.'),
            dict(name='Account Hierarchy Link',
                 role='Entity',
                 objects=[('15', 'Account Hierarchy Link')],
                 pk=['Parent Account', 'Child Account', 'Account Link Type', 'Link Effective From'],
                 grain='one row = parent account x child account x link type x effective period',
                 note='Account master view of the omnibus structure (Account Link Type = Omnibus to Sub-Account), which replaces the wholesale Omnibus Parent Account on Intermediary Account Servicing.'),
            dict(name='Program Enrollment',
                 role='Entity',
                 objects=[('15', 'Program Enrollment')],
                 pk=['Program Enrollment ID'],
                 grain='one row = account x service offering x enrollment period (ENRL-)',
                 note='An active enrollment on the valuation date drives Advisory Program AUM; it replaces the wholesale Advisory Program Indicator.'),
            dict(name='Data Feed',
                 role='Entity',
                 objects=[('06', 'Data Feed')],
                 pk=['Feed ID'],
                 grain='one row = data feed (provider x content x layout)',
                 note='Position sources (TA, intermediary look-through, DTC, recordkeeper, sponsor) and their precedence.'),
            dict(name='Load',
                 role='Entity',
                 objects=[('06', 'Load')],
                 pk=['Load ID'],
                 grain='one row = feed file load (feed x business date x file)',
                 note='Load Status per feed and business date (Completeness Status merged into it at W4) decides whether positions are final or estimated.'),
            dict(name='Reconciliation',
                 role='Entity',
                 objects=[('06', 'Reconciliation')],
                 pk=['Reconciliation ID'],
                 grain='one row = reconciliation definition (left source x right source x comparison grain x measure)',
                 note='Defines the TA / fund accounting comparison and its tolerances for Source Reconciliation Variance.'),
            dict(name='Reconciliation Run',
                 role='Entity',
                 objects=[('06', 'Reconciliation Run')],
                 pk=['Reconciliation Key', 'Run Business Date'],
                 grain='one row = reconciliation x run business date',
                 note='Child of Reconciliation (fold=False). Key is Reconciliation Key (carries the Reconciliation ID) + Run Business Date.'),
            dict(name='Account Asset Summary',
                 role='Entity',
                 objects=[('06', 'Account Asset Summary')],
                 pk=['Summary Account', 'Summary As-Of Date', 'Summary Holding Type']),
            dict(name='Account Channel Assignment',
                 role='Entity',
                 objects=[('06', 'Account Channel Assignment')],
                 pk=['Channel Assignment ID']),
            dict(name='Break',
                 role='Entity',
                 objects=[('06', 'Break')],
                 pk=['Break ID']),
            dict(name='Client Holding',
                 role='Entity',
                 objects=[('49', 'Client Holding'), ('49', 'Client Holding Valuation')],
                 pk=['Client Holding ID']),
            dict(name='Account Cash Balance',
                 role='Entity',
                 objects=[('49', 'Account Cash Balance')],
                 pk=['Account Cash Balance Key']),
            dict(name='Margin Balance Snapshot',
                 role='Entity',
                 objects=[('49', 'Margin Balance Snapshot')],
                 pk=['Margin Snapshot Account', 'Margin Snapshot Business Date', 'Margin Snapshot Type', 'Margin Snapshot As-Of Timestamp']),
            dict(name='Share Register Balance',
                 role='Entity',
                 objects=[('29', 'Share Register Balance')],
                 pk=['Register Account', 'Register Share Class', 'Register Business Date']),
            dict(name='Share Class NAV',
                 role='Entity',
                 objects=[('27', 'Share Class NAV')],
                 pk=['Share Class NAV ID']),
            dict(name='Participant Balance',
                 role='Entity',
                 objects=[('16', 'Participant Balance')],
                 pk=['Participant Balance Key']),
            dict(name='Participant Plan Membership',
                 role='Entity',
                 objects=[('16', 'Participant Plan Membership')],
                 pk=['Membership ID']),
            dict(name='Portfolio Valuation Summary',
                 role='Entity',
                 objects=[('18', 'Portfolio Valuation Summary')],
                 pk=['Valued Portfolio', 'Valuation As-Of Date', 'Valuation View']),
            dict(name='Portfolio Implementation Link',
                 role='Entity',
                 objects=[('18', 'Portfolio Implementation Link')],
                 pk=['Portfolio Implementation Link Key']),
        ],
        relationships=[
            dict(child='Attribution Record', parent='Position', fk=['Source Position'], card='M:1', note="Every attribution record in this product is sourced from a position (Source Record Type = position); Attribution Share % across one position's records sums to 100%."),
            dict(child='Position', parent='Account', fk=['Account'], card='M:1', note='The account (or sub-account, DTC participant, plan or sponsor account) the position is held in.'),
            dict(child='Position', parent='Account', fk=['Omnibus Parent Account'], card='M:1', optional=True, note='Look-through positions only: the omnibus account the sub-account was looked through from.'),
            dict(child='Account Hierarchy Link', parent='Account', fk=['Parent Account'], card='M:1', note='The omnibus parent.'),
            dict(child='Account Hierarchy Link', parent='Account', fk=['Child Account'], card='M:1', note='The sub-account.'),
            dict(child='Program Enrollment', parent='Account', fk=['Enrolled Account'], card='M:1'),
            dict(child='Position', parent='Data Feed', fk=['Position Source'], card='M:1'),
            dict(child='Load', parent='Data Feed', fk=['Feed'], card='M:1'),
            dict(child='Reconciliation', parent='Data Feed', fk=['Left Source'], card='M:1'),
            dict(child='Reconciliation', parent='Data Feed', fk=['Right Source'], card='M:1'),
            dict(child='Reconciliation Run', parent='Reconciliation', fk=['Reconciliation Key'], card='M:1', note='Reconciliation Key carries the Reconciliation ID; Reconciliation Run has no attribute for it.'),
            dict(child='Position', parent='Client Holding', fk=['Source Client Holding'], card='M:1', optional=True),
            dict(child='Position', parent='Share Register Balance', fk=['Source Share Register Balance'], card='M:1', optional=True),
            dict(child='Position', parent='Share Class NAV', fk=['Valuation NAV'], card='M:1', optional=True),
            dict(child='Attribution Record', parent='Account Asset Summary', fk=['Source Account Asset Summary'], card='M:1', optional=True),
            dict(child='Account Asset Summary', parent='Account', fk=['Summary Account'], card='M:1'),
            dict(child='Account Channel Assignment', parent='Account', fk=['Assigned Account'], card='M:1', optional=True),
            dict(child='Account Channel Assignment', parent='Program Enrollment', fk=['Basis Program Enrollment'], card='M:1', optional=True),
            dict(child='Client Holding', parent='Account', fk=['Holding Account'], card='M:1', optional=True),
            dict(child='Account Cash Balance', parent='Account', fk=['Cash Balance Account'], card='M:1', optional=True),
            dict(child='Margin Balance Snapshot', parent='Account', fk=['Margin Snapshot Account'], card='M:1'),
            dict(child='Share Register Balance', parent='Account', fk=['Register Account'], card='M:1'),
            dict(child='Participant Balance', parent='Participant Plan Membership', fk=['Balance Membership'], card='M:1', optional=True),
            dict(child='Participant Plan Membership', parent='Account', fk=['Participant Account'], card='M:1', optional=True),
            dict(child='Portfolio Implementation Link', parent='Account', fk=['Managed Account'], card='M:1', optional=True),
            dict(child='Break', parent='Reconciliation', fk=['Reconciliation Key'], card='M:1', optional=True, note='Model gap: no input attribute of Break carries its link to Reconciliation; the placeholder key stands for the lineage join.'),
            dict(child='Portfolio Valuation Summary', parent='Account Asset Summary', fk=['Account Asset Summary Key'], card='M:1', optional=True, note='Model gap: no input attribute of Portfolio Valuation Summary carries its link to Account Asset Summary; the placeholder key stands for the lineage join.'),
        ],
        notes='Foundational asset-base fact, modeled ER with Position (one row per account x share class x date x source) and Attribution Record (one row per attributed hierarchy node) at the center, Account as the conformed account entity, and Data Feed / Load / Reconciliation for source precedence, completeness and reconciliation to TA and fund accounting. Product measures sit on Attribution Record; Unattributed AUM is computed from the folded Unattributed Item columns. External references (resolved by joining to the upstream product, not linked here): Share Class to DP-004; Distributor Firm, Distributor Office / Branch, Advisor Team and Sponsor to the 05 Distributor Firm, Branch / Office and Advisor Team (CW-132; DP-001 until WP0); Holding Custodian / Broker, Dealer of Record, Branch of Record and Data Provider to Party (DP-001); Recordkeeper to 16 Recordkeeper Profile; Advisor / Rep, Plan Advisor and Rep of Record to 05 Financial Professional (DP-002 until WP0); Retirement Plan (both on Position and Attribution Record) and Consultant to DP-003, Institutional Client to 12 Institutional Client (CW-133). W4 (CW-141, CW-143): Territory, Platform / Fund Distributor (EU/UK), Investor Country, Suspense Territory / Bucket, Nominee / Platform Account Indicator, Office-Level Detail Indicator, Market Value (Reporting Currency) and Completeness Status left the inputs (spec notes). Model gap: Position carries no Load ID, so which load supplied a position (and so whether it is estimated) is found only by Position Source = Load.Feed and Valuation Date = Business Date. Model gap: Reconciliation Run has no share class or result columns at position grain, and no attribute records which position source won under precedence (noted in the spec as a taxonomy gap); Source Reconciliation Variance is derived from Position by Valuation Date = Run Business Date. Model gap: no attribute names the FX rate type applied (see the FX Rate Type relationship). 15 Account is also an input of DP-003; data owners should confirm which product publishes the conformed Account entity (this model assumes DP-007 for account-of-record servicing and DP-003 for institutional and plan relationships, with the same Account ID key). W1 re-point (CW-021; the 15 re-point map): Account Hierarchy Link (Omnibus to Sub-Account) replaces the Account self-link on Omnibus Parent Account, and Program Enrollment replaces Advisory Program Indicator. Program Enrollment.Enrolled Service Offering resolves to 01 Service Offering, not modeled here. WP1 re-point (CW-203): re-cut to Client Asset Positions. Position (12 conformers) stays the 06 Fund Shareholder Position (with Omnibus Look-Through, ETF Holding, Plan Position and Sponsor-Reported Assets) and never a Client Holding; Account (15 Account, 18 conformers), Data Feed, Attribution Record and Reconciliation keep their objects; 06 Distributor Hierarchy, 15 Intermediary Account Servicing and 09 FX Rate Type leave. The 06 Account Asset Summary, Account Channel Assignment and Break and the 49, 29, 27, 16 and 18 book objects are placed as entities. Model gap: no input attribute links a Break to its reconciliation run or an 18 Portfolio Valuation Summary to the Account Asset Summary built from it; placeholder keys stand for those joins.',
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-009": dict(
        style="ER",
        entities=[
            # -- people and advisor organization (20 HR, 03 Advisor, 08 registration)
            dict(name="Employee", role="Entity", objects=[("20", "Employee"), ("03", "Advisor")],
                 pk=["Employee ID"],
                 grain="one row = employee in an advisor role (EMP-), with their advisor profile",
                 note="Conformed advisor and salesperson entity (the conformed name is kept). 03 Advisor is a 1:1 role "
                      "profile of the 20 Employee keyed by the EMP- reference (registry), so it is held here rather than "
                      "as a separate entity: its Employee column repeats Employee ID. Only staff in an advisor role are "
                      "published (spec boundary). Names, email and hire / termination dates are personal data."),
            dict(name="Advisor Role Assignment", role="Entity", objects=[("03", "Advisor Role Assignment")],
                 pk=["Role Advisor", "Advisor Role", "Role Effective From"],
                 grain="one row = advisor x advisor role x role effective period",
                 note="Producing Indicator drives Active Producing Advisors."),
            dict(name="Employee Reporting Line", role="Entity", objects=[("20", "Employee Reporting Line")],
                 pk=["Reporting Employee", "Line Manager", "Reporting Line Type", "Reporting Effective From"],
                 grain="one row = reporting employee x line manager x reporting line type x effective period"),
            dict(name="Coverage Team", role="Entity", objects=[("03", "Coverage Team")],
                 pk=["Coverage Team ID"],
                 grain="one row = coverage team (SLT-)"),
            dict(name="Coverage Team Membership", role="Entity", objects=[("03", "Coverage Team Membership")],
                 pk=["Member Coverage Team", "Member Advisor", "Membership Role", "Membership Effective From"],
                 grain="one row = coverage team x advisor x membership role x membership effective period",
                 note="A pairing is two membership rows of one team (the pairing type is the Membership Role). Capacity "
                      "Allocation Percentage drives the Allocation Check."),
            dict(name="Individual Registration", role="Entity", objects=[("08", "Individual Registration")],
                 pk=["License ID"],
                 grain="one row = registered person x registration category x jurisdiction",
                 note="Read from 08, the registration master, for the Registration Gap Flag."),
            dict(name="Org Unit Assignment", role="Entity", objects=[("20", "Org Unit Assignment")],
                 pk=["Assigned Employee", "Assigned Org Unit", "Assignment Effective From / To"],
                 grain="one row = advisor x org unit x effective period",
                 note="The effective period is a single text attribute; the key uses it as delivered. Published only "
                      "for staff in an advisor role."),
            dict(name="Reorganization Event", role="Entity", objects=[("09", "Reorganization Event")],
                 pk=["Reorganization ID"],
                 grain="one row = reorganization event"),
            # -- coverage design (03)
            dict(name="Coverage Model", role="Entity", objects=[("03", "Coverage Model")],
                 pk=["Coverage Model Code"],
                 grain="one row = coverage model (code value)",
                 note="Coverage Roles Included lists the roles a team following the model should have filled; Service "
                      "Tiers Covered the tiers it serves."),
            dict(name="Coverage Assignment Rule", role="Entity", objects=[("03", "Coverage Assignment Rule")],
                 pk=["Assignment Rule ID"],
                 grain="one row = coverage assignment rule (ASRL-), including exception rules",
                 note="In-force rule set; an exception is a rule of an exception Assignment Rule Type with its own "
                      "effective period (replaces 07 Alignment Exception)."),
            dict(name="Coverage Assignment Rule Criterion", role="Entity",
                 objects=[("03", "Coverage Assignment Rule Criterion")],
                 pk=["Coverage Assignment Rule Key", "Criterion Sequence"],
                 grain="one row = coverage assignment rule x criterion sequence",
                 note="Child of Coverage Assignment Rule (fold=False). Key is Coverage Assignment Rule Key (carries the "
                      "Assignment Rule ID) + Criterion Sequence."),
            # -- coverage (03, 02)
            dict(name="Coverage Assignment", role="Entity", objects=[("03", "Party Coverage Assignment")],
                 pk=["Coverage Assignment ID"], measures=True,
                 grain="one row = covered party, household or account x advisor or coverage team x party coverage "
                       "role x coverage period (CVA-; the product grain)",
                 note="Core entity and conformed party-coverage name (03 Party Coverage Assignment, CW-063). "
                      "Relationship Start Date carries tenure across reassignments. Holds the product measures; those "
                      "about teams, rules, tiers and reorganizations are counted from the related entities as of the "
                      "same date."),
            dict(name="Coverage Reassignment", role="Entity", objects=[("03", "Coverage Reassignment")],
                 pk=["Reassignment ID"],
                 grain="one row = coverage reassignment event (REAS-)"),
            dict(name="Service Tier Assignment", role="Entity", objects=[("02", "Service Tier Assignment")],
                 pk=["Tier Party", "Assigned Service Tier", "Tier Effective From"],
                 grain="one row = household or party x service tier x tier effective period",
                 note="Replaces 07 Coverage Tier Assignment: the tier belongs to the client, not to the coverage row."),
        ],
        relationships=[
            dict(child="Advisor Role Assignment", parent="Employee", fk=["Role Advisor"], card="M:1"),
            dict(child="Employee Reporting Line", parent="Employee", fk=["Reporting Employee"], card="M:1"),
            dict(child="Employee Reporting Line", parent="Employee", fk=["Line Manager"], card="M:1"),
            dict(child="Coverage Team", parent="Coverage Team", fk=["Parent Coverage Team"], card="M:1", optional=True,
                 note="Coverage team tree; empty for top-level teams."),
            dict(child="Coverage Team", parent="Employee", fk=["Lead Advisor"], card="M:1", optional=True),
            dict(child="Coverage Team Membership", parent="Employee", fk=["Member Advisor"], card="M:1"),
            dict(child="Coverage Team Membership", parent="Coverage Team", fk=["Member Coverage Team"], card="M:1"),
            dict(child="Individual Registration", parent="Employee", fk=["Registered Person"], card="M:1"),
            dict(child="Org Unit Assignment", parent="Employee", fk=["Assigned Employee"], card="M:1"),
            dict(child="Org Unit Assignment", parent="Reorganization Event", fk=["Reorganization Event Key"],
                 card="M:1", optional=True,
                 note="Model gap: no attribute records the reorganization that produced an org unit assignment. "
                      "Reorganization Event Key is a placeholder carrying the Reorganization ID; today it can only be "
                      "inferred where Assigned Org Unit is among the Target Org Units and the assignment starts on the "
                      "Reorganization Effective Date."),
            dict(child="Coverage Assignment Rule", parent="Coverage Team", fk=["Target Coverage Team"], card="M:1",
                 optional=True),
            dict(child="Coverage Assignment Rule", parent="Employee", fk=["Target Advisor"], card="M:1", optional=True),
            dict(child="Coverage Assignment Rule Criterion", parent="Coverage Assignment Rule",
                 fk=["Coverage Assignment Rule Key"], card="M:1",
                 note="Coverage Assignment Rule Key carries the Assignment Rule ID."),
            dict(child="Coverage Assignment", parent="Employee", fk=["Covering Advisor"], card="M:1", optional=True),
            dict(child="Coverage Assignment", parent="Coverage Team", fk=["Covering Coverage Team"], card="M:1",
                 optional=True, note="Exactly one of Covering Advisor and Covering Coverage Team is populated."),
            dict(child="Coverage Assignment", parent="Coverage Assignment Rule", fk=["Source Assignment Rule"],
                 card="M:1", optional=True,
                 note="Empty for referral and manual assignments (drives Rule-Based Assignment Share)."),
            dict(child="Coverage Reassignment", parent="Employee", fk=["From Advisor"], card="M:1", optional=True),
            dict(child="Coverage Reassignment", parent="Employee", fk=["To Advisor"], card="M:1", optional=True),
            dict(child="Coverage Assignment", parent="Service Tier Assignment", fk=["Service Tier Assignment Key"],
                 card="M:1", optional=True,
                 note="Model gap: Coverage Assignment carries no service tier; Service Tier Assignment Key is a "
                      "placeholder for the covered party's tier row on the as-of date (Tier Party = Covered Party, both "
                      "02 Party)."),
            dict(child="Coverage Team", parent="Coverage Model", fk=["Coverage Model Key"], card="M:1", optional=True,
                 note="Model gap: Coverage Team names no coverage model; Coverage Model Key is a placeholder carrying "
                      "the Coverage Model Code the team follows."),
        ],
        notes=("Foundational coverage master, modeled ER in two areas joined through Employee: the advisor organization "
               "(Employee with its folded 03 Advisor profile, Advisor Role Assignment, reporting lines, coverage teams "
               "and memberships, registrations, org unit assignments and reorganizations) and coverage (coverage models, "
               "assignment rules and criteria, party coverage assignments, reassignments and the 02 service tier). "
               "Measures sit on Coverage Assignment, the product grain. "
               "No Org Unit entity: 09 Org Unit is not an input; Home Org Unit, Assigned Org Unit and Source / Target "
               "Org Units resolve to DP-013. "
               "External references (resolved by joining to the upstream product, not linked here): Employing Legal "
               "Entity, Home Org Unit, Work Location, Assigned Org Unit, Source / Target Org Units, Team Office and "
               "Criterion Geographic Group to DP-013; Covered Party, Excepted Party and Tier Party to 02 Party (the WP1 "
               "client master); Covered Account to Account (DP-093); Assigned Service Tier and Service Tiers Covered to "
               "01 Service Tier (DP-004). "
               "W2 re-point (CW-062, PK_CHANGES in proposals_w2_03.py): Sales Person folds into Employee as 03 Advisor; "
               "Sales Role becomes Advisor Role Assignment (key Role Advisor + Advisor Role + Role Effective From); "
               "Sales Team becomes Coverage Team (Sales Team ID -> Coverage Team ID); Sales Team Membership and Sales "
               "Pairing become Coverage Team Membership (Paired Employee, Partner Employee, Sales Pairing Type, Pairing "
               "Effective From -> Member Coverage Team, Member Advisor, Membership Role, Membership Effective From); 07 "
               "Coverage Model keeps Coverage Model Code; 07 Alignment Rule, Criterion and Exception become Coverage "
               "Assignment Rule and Criterion; 07 Coverage Tier Assignment becomes 02 Service Tier Assignment. W2: the "
               "territory design (Territory Model, Territory, Territory Hierarchy Node, Territory Geographic Unit, "
               "Territory Type Definition, Sales Cluster), Party Territory Alignment, Realignment Event, Crediting Rule "
               "and Territory Salesperson Assignment left with the 07 retirement (CW-907); the measures move from "
               "Territory Salesperson Assignment to Coverage Assignment. "
               "Model gap: Coverage Assignment does not carry the covered party's service tier, so Coverage Span and "
               "Uncovered Tiered Households join 02 Service Tier Assignment by party as of the date. "
               "Model gap: Org Unit Assignment holds its effective period as one text attribute; split it into from / "
               "to dates so as-of joins and SCD type 2 history work."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-010": dict(
        style="ER",
        entities=[
            dict(name="Advisor Activity", role="Entity",
                 objects=[("03", "Advisor Activity"), ("03", "Discussion Content"), ("03", "Outcome & Follow-Up"),
                          ("03", "Activity Capture")],
                 pk=["Activity ID"], measures=True,
                 grain="one row = advisor activity (ACT-): meeting, call, video call, email or client review",
                 note="Core entity (03 Advisor Activity, renamed from Sales Activity, CW-062). Discussion Content, "
                      "Outcome & Follow-Up and Activity Capture fold here (one per activity). Products Discussed and "
                      "Content Assets Shared are multi-valued references held as lists; Product Mentions and Content "
                      "Shares explode them. Meeting Notes are excluded from the BI semantic model. Holds the product "
                      "measures."),
            dict(name="Internal Participant", role="Entity", objects=[("03", "Internal Participant")],
                 pk=["Advisor Activity Key", "Internal Participant"],
                 grain="one row = advisor activity x internal participant employee",
                 note="Child of Advisor Activity (fold=False). Key is Advisor Activity Key (carries the Activity ID) + "
                      "Internal Participant."),
            dict(name="External Participant", role="Entity", objects=[("03", "External Participant")],
                 pk=["Advisor Activity Key", "External Participant", "Unmatched Participant Email"],
                 grain="one row = advisor activity x external participant (matched party or unmatched attendee)",
                 note="Child of Advisor Activity (fold=False). Exactly one of External Participant (matched party) and "
                      "Unmatched Participant Email is populated, so the empty one needs a default member (e.g. "
                      "'none') rather than a null in the key."),
            dict(name="Call Frequency Standard", role="Entity", objects=[("03", "Call Frequency Standard")],
                 pk=["Standard Coverage Model", "Standard Service Tier", "Contact Type", "Standard Effective From"],
                 grain="one row = coverage model x service tier x contact type x standard effective period",
                 note="Read only to flag Qualifying Interactions; coverage-frequency compliance is calculated in "
                      "DP-016."),
        ],
        relationships=[
            dict(child="Internal Participant", parent="Advisor Activity", fk=["Advisor Activity Key"], card="M:1",
                 note="Advisor Activity Key carries the Activity ID; the participant group has no attribute for it."),
            dict(child="External Participant", parent="Advisor Activity", fk=["Advisor Activity Key"], card="M:1",
                 note="Advisor Activity Key carries the Activity ID."),
            dict(child="Advisor Activity", parent="Advisor Activity", fk=["Follow-Up Task"], card="M:1", optional=True,
                 note="The task activity created to track the agreed next step."),
            dict(child="Advisor Activity", parent="Call Frequency Standard", fk=["Activity Type"], card="M:N",
                 optional=True,
                 note="Value lookup, not a key: Activity Type is matched to the multi-valued Qualifying Activity Type. "
                      "Picking the right standard also needs the covered party's service tier and the team's coverage "
                      "model, which come from DP-009 (see notes)."),
        ],
        notes=("Foundational activity fact, modeled ER around Advisor Activity (one row per Activity ID) with Internal "
               "and External Participant as child entities (the participant half of the grain). Product measures sit "
               "on Advisor Activity; Unique Parties Reached and Unmatched Participant Rate are counted from External "
               "Participant. "
               "External references (resolved by joining to the upstream product, not linked here): Activity Owner and "
               "Internal Participant to Employee (DP-009); Activity Party and External Participant to 02 Party (the "
               "WP1 client master); Related Accounts to Account (DP-093); Products Discussed to DP-004; Content Assets "
               "Shared and Related Campaign to DP-011. "
               "W2 re-point (CW-062): Sales Activity is renamed Advisor Activity and the entity follows; 07 Call "
               "Frequency Standard moves to 03 (key Standard Coverage Model + Standard Service Tier + Contact Type + "
               "Standard Effective From); Consultant Research Review and Content Usage Event left the inputs (spec "
               "notes). "
               "Model gap: Gifts & Entertainment Reference and Communication Archive Reference point to 08 objects that "
               "no foundational product publishes; they stay unresolved identifiers here. "
               "Model gap: Qualifying Interactions needs the covered party's service tier on the activity date; it is "
               "not on Advisor Activity, so the Call Frequency Standard is chosen by joining Activity Party to DP-009 "
               "Service Tier Assignment as of the Activity Start Timestamp. "
               "Model gap: Products Discussed is a multi-valued reference to strategy, product or share class while "
               "the registry points it to Share Class only; a typed product-discussed child would remove the "
               "ambiguity."),
    ),
}
