"""Logical data models: foundational ER models for DP-011, DP-012, DP-013, DP-014 and DP-075. See CONTRACT.md.

Conventions (as in models_pilot_er.py):
- One entity per Business Object; folded Attribute Groups sit in their parent's entity; child groups are child entities.
- A child whose own attributes don't identify its parent borrows "<Parent> Key" (which carries the parent's natural ID).
- References to objects mastered in another product are listed in the notes as external references, resolved by
  joining to that product, not linked here.
- Entities named as conformed dimensions (Campaign, Content Asset, Calendar, Country, Currency, Peer Fund ...) keep the
  taxonomy name so consumer models can reuse them.
"""

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-011": dict(
        style="ER",
        entities=[
            dict(name="Campaign", role="Entity", objects=[("04", "Campaign")],
                 pk=["Campaign ID"],
                 grain="one row = campaign node (program, campaign or wave)",
                 note="Conformed campaign dimension. Program, campaign and wave are one entity, with Campaign Level and "
                      "Parent Campaign forming the hierarchy, so engagement can roll up at any level."),
            dict(name="Campaign Member", role="Entity", objects=[("04", "Campaign Member")],
                 pk=["Campaign Key", "Member Party", "Member Lead"],
                 grain="one row = campaign x member party or lead",
                 note="Key is Campaign Key + Member Party + Member Lead. The object has no attribute for its campaign "
                      "(the registry scopes it within Campaign), so Campaign Key, carrying the Campaign ID, completes "
                      "the key. Exactly one of Member Party and Member Lead is populated; the empty one needs a default "
                      "member (e.g. 'Not matched') rather than a null in the key."),
            dict(name="Content Asset", role="Entity", objects=[("04", "Content Asset")],
                 pk=["Asset ID"],
                 grain="one row = content asset",
                 note="Conformed content dimension. Email templates, web content and media are all content assets; "
                      "Parent / Source Asset links derived or localized versions to their source."),
            dict(name="Web Page", role="Entity", objects=[("04", "Web Page")],
                 pk=["Page URL"],
                 grain="one row = web page URL",
                 note="The URL is the identifier. Page Product / Share Class gives the product a page is about, for "
                      "'engagement by product' questions."),
            dict(name="Web Visitor", role="Entity", objects=[("04", "Web Visitor / Known User")],
                 pk=["Visitor ID", "Identity Namespace"],
                 grain="one row = visitor identifier x identity namespace",
                 note="Holds 04 Web Visitor / Known User. Resolves anonymous and known visitors to the party master "
                      "through Matched Party, only where Applied Tracking Consent permits; this is what Identified "
                      "Engagement Share measures."),
            dict(name="Session", role="Entity", objects=[("04", "Session")],
                 pk=["Session ID"],
                 grain="one row = web or app session",
                 note="Carries the traffic source and campaign of a visit."),
            dict(name="Engagement Event", role="Entity",
                 objects=[("04", "Engagement Event"), ("04", "Media Engagement")],
                 pk=["Event Visitor / Party", "Engagement Event Type", "Event Timestamp"], measures=True,
                 grain="one row = visitor or party x engagement event type x event timestamp (the product grain)",
                 note="Conformed engagement fact and the core of the product. Media Engagement folds here (one media "
                      "view is one engagement event), so its columns are populated only for media-view events. Holds "
                      "the product measures: Identified Engagement Share and Media Completion Rate are measured on these "
                      "rows; the email rates are measured on Email Interaction rows and Event Attendance Rate on Event "
                      "Registration rows, joined through Email Send and Marketing Event."),
            dict(name="Email Send", role="Entity", objects=[("04", "Email Send")],
                 pk=["Email Send Key"],
                 grain="one row = email deployment (one send of a template)",
                 note="Surrogate key: the object has no deployment identifier (registry)."),
            dict(name="Email Interaction", role="Entity", objects=[("04", "Email Interaction")],
                 pk=["Email Send Key", "Recipient Party"],
                 grain="one row = email recipient x deployment",
                 note="Key is Email Send Key + Recipient Party. The registry keys this object on Recipient Email "
                      "Address (recipients may be unmatched), but that attribute is not a product input, so Recipient "
                      "Party stands in and unmatched recipients need a default member. Email Send Key is borrowed "
                      "because no attribute carries the deployment."),
            dict(name="Marketing Event", role="Entity", objects=[("04", "Marketing Event")],
                 pk=["Event ID"],
                 grain="one row = marketing event (webinar, conference, roadshow ...)",
                 note="Conformed marketing event dimension."),
            dict(name="Event Registration", role="Entity", objects=[("04", "Event Registration")],
                 pk=["Marketing Event Key", "Registrant Party"],
                 grain="one row = marketing event x registrant",
                 note="Key is Marketing Event Key + Registrant Party; Marketing Event Key carries the Event ID because "
                      "no attribute of the registration names the event (registry)."),
            dict(name="Marketing Touchpoint", role="Entity", objects=[("04", "Marketing Touchpoint")],
                 pk=["Touchpoint Party", "Touchpoint Type", "Touchpoint Timestamp"],
                 grain="one row = party x touchpoint type x touchpoint timestamp",
                 note="The attribution-ready touchpoint stream: identified parties only, each tied to a campaign and, "
                      "where it came from digital engagement, to its source engagement event."),
            dict(name="Consent Record", role="Entity", objects=[("02", "Consent Record")],
                 pk=["Consent Record ID"],
                 grain="one row = consent record (party x consent purpose x capture event)",
                 note="Read from the 02 master (DP-002) to check identified engagement against current consent and "
                      "withdrawal."),
            dict(name="Advisor", role="Entity", conformed=("DP-009", "Employee"), objects=[],
                 note="Conformed from DP-009 Employee (the firm's own advisor, 03 Advisor), named for its role, so event "
                      "invitations roll up the advisor organization."),
        ],
        relationships=[
            dict(child="Campaign", parent="Campaign", fk=["Parent Campaign"], card="M:1", optional=True,
                 note="Program > campaign > wave hierarchy; empty for programs."),
            dict(child="Campaign Member", parent="Campaign", fk=["Campaign Key"], card="M:1",
                 note="Campaign Key carries the Campaign ID; no attribute of Campaign Member holds it (registry model "
                      "gap)."),
            dict(child="Content Asset", parent="Content Asset", fk=["Parent / Source Asset"], card="M:1",
                 optional=True, note="Derived, localized or excerpted versions of a source asset."),
            dict(child="Session", parent="Campaign", fk=["Session Campaign"], card="M:1", optional=True,
                 note="Campaign attributed to the session from its tracking parameters; DQ requires it to resolve."),
            dict(child="Engagement Event", parent="Web Visitor", fk=["Event Visitor / Party"], card="M:1",
                 note="Event Visitor / Party carries the Visitor ID; the Identity Namespace half of the Web Visitor key "
                      "is implied by the capturing system (see model gap)."),
            dict(child="Engagement Event", parent="Content Asset", fk=["Event Content Asset"], card="M:1",
                 optional=True, note="The asset viewed, downloaded or played; empty for page views of non-asset pages."),
            dict(child="Engagement Event", parent="Web Page", fk=["Web Page Key"], card="M:1", optional=True,
                 note="Model gap: Engagement Event has no page attribute, although the grain names the page as a "
                      "source object. Web Page Key would carry the Page URL for page-view events."),
            dict(child="Email Send", parent="Content Asset", fk=["Email Template Asset"], card="M:1", optional=True,
                 note="The email template sent."),
            dict(child="Email Send", parent="Campaign", fk=["Email Campaign"], card="M:1",
                 note="DQ requires every send to resolve to a Campaign ID."),
            dict(child="Email Interaction", parent="Email Send", fk=["Email Send Key"], card="M:1",
                 note="Email Send Key is borrowed: no attribute of Email Interaction names its deployment (registry "
                      "model gap). The denominator of every email rate is the interaction rows of one send."),
            dict(child="Marketing Event", parent="Campaign", fk=["Owning Campaign"], card="M:1", optional=True),
            dict(child="Event Registration", parent="Marketing Event", fk=["Marketing Event Key"], card="M:1",
                 note="Marketing Event Key carries the Event ID (registry model gap: no attribute holds it)."),
            dict(child="Marketing Touchpoint", parent="Campaign", fk=["Touchpoint Campaign"], card="M:1"),
            dict(child="Marketing Touchpoint", parent="Engagement Event", fk=["Source Event"], card="M:1",
                 optional=True,
                 note="Source Event carries one value against the three-part Engagement Event key, and may instead "
                      "point to a 03 sales activity (Reference (Engagement Event / Activity)); see model gap."),
            dict(child="Event Registration", parent="Advisor", fk=["Invited By Advisor"], card="M:1",
                 optional=True, note="The advisor who invited the registrant; empty for self-registrations."),
            dict(child="Web Visitor", parent="Consent Record", fk=["Applied Tracking Consent"], card="M:N",
                 optional=True,
                 note="Value lookup, not a key: Applied Tracking Consent holds the consent purposes applied at capture, "
                      "matched to Consent Purpose. Model gap: Consent Record has no party attribute in the taxonomy, so "
                      "the consent of the matched party is found through DP-002, not through this link."),
        ],
        notes=("Foundational engagement product, modeled ER around Engagement Event, with email (Email Send > Email "
               "Interaction), event (Marketing Event > Event Registration) and attribution (Marketing "
               "Touchpoint) branches that share Campaign and Content Asset. Campaign, Content Asset, Marketing Event and "
               "Engagement Event are the conformed entities for DP-025 to DP-028. "
               "External references (resolved by joining to the upstream product, not linked here): Campaign Member."
               "Member Party, Web Visitor.Matched Party, Email Interaction.Recipient Party, Event Registration.Registrant "
               "Party and Marketing Touchpoint.Touchpoint Party to Party (DP-002); Web Page.Page Product / Share Class to "
               "Share Class (DP-004); Marketing Event.Event Country to Country (DP-013). Event "
               "Registration.Invited By Advisor joins to Advisor, conformed from DP-009 Employee. "
               "W2 (CW-904): CE Credit Issued and Campaign Member.Added By Salesperson left the inputs; Invited By "
               "Salesperson is renamed Invited By Advisor. Campaign.Marketing Theme, Email Send.Email Subscription Topic and "
               "Campaign Member.Member Lead point to 04 objects that are inputs of DP-026, DP-028 and DP-027, which are "
               "downstream of this product, so they are carried as IDs only to avoid a cycle. "
               "Model gap: Engagement Event carries only visitor, type, timestamp and content asset; the grain also names "
               "page, email, event and campaign as source objects, and there is no session reference. Add Event Page, "
               "Event Session and Event Campaign references to 04 Engagement Event so web engagement joins to Web Page, "
               "Session and Campaign directly. "
               "Model gap: Session has no visitor attribute, so sessions cannot be tied to visitors or parties. "
               "Model gap: Event Visitor / Party is one reference against a two-part Web Visitor key (Visitor ID + "
               "Identity Namespace), and Marketing Touchpoint.Source Event one value against a three-part Engagement "
               "Event key; an engagement event identifier would make both joins exact. "
               "Model gap: Email Interaction, Event Registration and Campaign Member have no attribute for their parent "
               "(registry), and Recipient Email Address, the registry key of Email Interaction, is not a product input. "
               "Model gap: Consent Record has no party attribute, so the withdrawal DQ rule needs DP-002's party-level "
               "consent; the M:N link to Web Visitor is a value lookup only."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-012": dict(
        style='ER',
        entities=[
            dict(name='Revenue Record',
                 role='Entity',
                 objects=[('10', 'Distribution Revenue Record')],
                 pk=['Paying Share Class', 'Receiving Entity', 'Distribution Revenue Type', 'Fiscal Period Key'],
                 grain='one row = paying share class x receiving legal entity x distribution revenue type x accounting period',
                 note="Conformed distribution revenue record (12b-1, sales charges, CDSC, platform and servicing fees with the amount passed through to intermediaries). Holds 10 Distribution Revenue Record. Key is the registry's three attributes plus Fiscal Period Key, because the grain names the accounting period but no attribute carries it (registry model gap). Revenue Data Basis is also missing, so estimated and final versions of a row cannot coexist in this key."),
            dict(name='Fee Revenue Record',
                 role='Entity',
                 objects=[('10', 'Fee Revenue Record')],
                 pk=['Fee Revenue Record ID'],
                 measures=True,
                 grain='one row = share class or mandate x revenue accounting period (one FRR- record)',
                 note='Management fee revenue before and after waivers. Holds the product measures: Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate are its own columns (published once), Waiver Cost and Fee Basis Variance join by share class and period, Net Distribution Revenue Retained is summed from Revenue Record and Reconciliation Control Completion % from Control, both through Fiscal Period.'),
            dict(name='Performance Fee Record',
                 role='Entity',
                 objects=[('10', 'Performance Fee Record')],
                 pk=['Performance Fee Record ID'],
                 grain='one row = share class or mandate x crystallization date (one PFR- record)',
                 note='Recognized performance fees and their constraint assessment.'),
            dict(name='Waiver Record',
                 role='Entity',
                 objects=[('10', 'Waiver Record')],
                 pk=['Waiver Record ID'],
                 grain='one row = supported share class x waiver type x accounting period (one WVR- record)',
                 note='Fee waivers and expense reimbursements, the detail behind Waiver and Reimbursement Offset on Fee Revenue Record (same share class and period).'),
            dict(name='Revenue Contract',
                 role='Entity',
                 objects=[('10', 'Revenue Contract'), ('10', 'Performance Obligation')],
                 pk=['Revenue Contract ID'],
                 grain='one row = revenue contract (one RVC- contract with an identified customer)',
                 note='Performance Obligation folds here (one obligation and satisfaction pattern per contract) and gives the Revenue Stream used to classify revenue.'),
            dict(name='Account Mapping',
                 role='Entity',
                 objects=[('10', 'Account Mapping')],
                 pk=['Account Mapping ID'],
                 grain='one row = management P&L line x GL natural account x ledger x mapping effective period',
                 note='Maps GL natural accounts (19 GL accounts since CD-152) to management P&L lines for the GL reconciliation.'),
            dict(name='Statement Line Mapping',
                 role='Entity',
                 objects=[('19', 'Financial Statement Line Mapping')],
                 pk=['Mapped GL Account', 'Mapped Statement Line', 'Line Mapping Effective From'],
                 grain='one row = GL account x statement line x effective period',
                 note='19 Financial Statement Line Mapping, which took over the revenue disaggregation category from 10 Account Mapping under CD-152.'),
            dict(name='Journal Entry',
                 role='Entity',
                 objects=[('19', 'Journal Entry')],
                 pk=['Journal ID'],
                 grain='one row = journal entry (header)',
                 note='19 Journal Entry (CD-152): the posting period and legal entity moved to the header.'),
            dict(name='GL Posting',
                 role='Entity',
                 objects=[('19', 'GL Posting')],
                 pk=['Journal ID', 'Journal Line Number'],
                 grain='one row = journal entry x journal line',
                 note='The general ledger side of the revenue-to-GL reconciliation (19 GL Posting, CD-152).'),
            dict(name='Accounting Period Status',
                 role='Entity',
                 objects=[('19', 'Accounting Period Status')],
                 pk=['Status Ledger', 'Status Fiscal Period'],
                 grain='one row = ledger x fiscal period',
                 note='19 Accounting Period Status (CD-152). Period Close Status = closed is what moves revenue from estimated to final.'),
            dict(name='Fiscal Period',
                 role='Entity',
                 objects=[('09', 'Fiscal Period')],
                 pk=['Fiscal Period ID'],
                 grain='one row = fiscal calendar x fiscal period',
                 note='Conformed accounting period; the same object as DP-013 Fiscal Period, read here as an input. It is the hub that ties revenue, GL, close status and controls to one period.'),
            dict(name='Control',
                 role='Entity',
                 objects=[('10', 'Control')],
                 pk=['Control Reference', 'Reconciliation Type', 'Fiscal Period Key'],
                 grain='one row = control x reconciliation type x accounting period (control execution)',
                 note="Key is the registry's Control Reference + Reconciliation Type plus Fiscal Period Key, because the grain names the accounting period but no attribute carries it (registry model gap)."),
            dict(name='Identified Customer',
                 role='Entity',
                 conformed=('DP-001', 'Party'),
                 objects=[],
                 note='Conformed from DP-001 Party (now upstream), named for its role: the customer of a revenue contract (fund, distributor or platform). Replaces the customer ID carried unlinked.'),
            dict(name='GL Account',
                 role='Entity',
                 conformed=('DP-190', 'GL Account'),
                 objects=[],
                 note='Conformed from DP-190 (19 GL Account, upstream): the GL natural account that Account Mapping, Statement Line Mapping and GL Posting all name, so the management P&L line, the revenue disaggregation category and the posted amount meet on it.'),
            dict(name='Client Revenue Record',
                 role='Entity',
                 objects=[('10', 'Client Revenue Record')],
                 pk=['Client Revenue Record ID']),
            dict(name='Cash Program Economics',
                 role='Entity',
                 objects=[('10', 'Cash Program Economics')],
                 pk=['Economics Sweep Program', 'Economics Program Bank', 'Economics Period']),
            dict(name='Account Fee Calculation',
                 role='Entity',
                 objects=[('47', 'Account Fee Calculation')],
                 pk=['Account Fee Calculation Key']),
            dict(name='Fee Calculation Run',
                 role='Entity',
                 objects=[('47', 'Fee Calculation Run')],
                 pk=['Fee Calculation Run ID']),
            dict(name='Fee Debit',
                 role='Entity',
                 objects=[('47', 'Fee Debit')],
                 pk=['Fee Debit ID']),
            dict(name='Fee Invoice',
                 role='Entity',
                 objects=[('47', 'Fee Invoice')],
                 pk=['Invoice ID']),
            dict(name='Fee Adjustment',
                 role='Entity',
                 objects=[('47', 'Fee Adjustment')],
                 pk=['Fee Adjustment ID']),
            dict(name='Fee Household',
                 role='Entity',
                 objects=[('47', 'Fee Household')],
                 pk=['Fee Household ID']),
            dict(name='Share Class NAV',
                 role='Entity',
                 objects=[('27', 'Share Class NAV')],
                 pk=['Share Class NAV ID']),
            dict(name='Fund NAV Calculation',
                 role='Entity',
                 objects=[('27', 'Fund NAV Calculation')],
                 pk=['Fund NAV Calculation Key']),
            dict(name='Account Party Role',
                 role='Entity',
                 objects=[('15', 'Account Party Role')],
                 pk=['Role Account', 'Role Party', 'Account Role Type', 'Account Role Effective From']),
            dict(name='Household Membership',
                 role='Entity',
                 objects=[('02', 'Household Membership')],
                 pk=['Household', 'Household Member', 'Membership Effective From']),
            dict(name='Account',
                 role='Entity',
                 conformed=('DP-093', 'Account'),
                 objects=[]),
            dict(name='Service Offering',
                 role='Entity',
                 conformed=('DP-004', 'Service Offering'),
                 objects=[]),
            dict(name='Internal Legal Entity',
                 role='Entity',
                 conformed=('DP-013', 'Internal Legal Entity'),
                 objects=[]),
            dict(name='Share Class',
                 role='Entity',
                 conformed=('DP-004', 'Share Class'),
                 objects=[]),
            dict(name='Party',
                 role='Entity',
                 conformed=('DP-240', 'Party'),
                 objects=[]),
        ],
        relationships=[
            dict(child='Revenue Record', parent='Fiscal Period', fk=['Fiscal Period Key'], card='M:1', note='Fiscal Period Key carries the Fiscal Period ID; Distribution Revenue Record has no period attribute (model gap).'),
            dict(child='Revenue Record', parent='Revenue Contract', fk=['Revenue Contract Key'], card='M:1', optional=True, note='Model gap: no attribute ties a revenue record to its contract; Revenue Contract Key would carry the Revenue Contract ID.'),
            dict(child='Fee Revenue Record', parent='Fiscal Period', fk=['Revenue Accounting Period'], card='M:1', note='Assumes Revenue Accounting Period holds the Fiscal Period ID of a monthly period.'),
            dict(child='Fee Revenue Record', parent='Revenue Contract', fk=['Revenue Contract Key'], card='M:1', optional=True, note="Model gap: no attribute ties a fee revenue record to its contract (the product dimension 'revenue contract and identified customer' needs it)."),
            dict(child='Performance Fee Record', parent='Revenue Contract', fk=['Revenue Contract Key'], card='M:1', optional=True, note='Model gap, as for Fee Revenue Record.'),
            dict(child='Performance Fee Record', parent='Fiscal Period', fk=['Crystallization Date'], card='M:N', optional=True, note='Date-range lookup, not a key: Crystallization Date falls between Period Start Date and Period End Date of one period per Fiscal Period Type.'),
            dict(child='Waiver Record', parent='Fiscal Period', fk=['Fiscal Period Key'], card='M:1', note='Fiscal Period Key carries the Fiscal Period ID; the grain names the accounting period but no attribute carries it (model gap).'),
            dict(child='GL Posting', parent='Journal Entry', fk=['Journal ID'], card='M:1'),
            dict(child='Journal Entry', parent='Fiscal Period', fk=['Posting Accounting Period'], card='M:1'),
            dict(child='Account Mapping', parent='GL Account', fk=['GL Natural Account'], card='M:1', note='The GL account mapped to a management P&L line (one mapping per ledger and effective period).'),
            dict(child='Statement Line Mapping', parent='GL Account', fk=['Mapped GL Account'], card='M:1', note='Meets Account Mapping on the same GL account, which gives the revenue disaggregation category of a management P&L line.'),
            dict(child='GL Posting', parent='Fee Revenue Record', fk=['Source Finance Record'], card='M:1', optional=True, note='Source Finance Record is polymorphic: it points to a Fee Revenue Record when it has the FRR- prefix. DCO-, ACR-, ARN- and ICC- records are outside this product.'),
            dict(child='GL Posting', parent='GL Account', fk=['Posted Account'], card='M:1', note='The Account Mapping effective at the posting date for the same GL account gives the Management P&L Line for the reconciliation.'),
            dict(child='Revenue Contract', parent='Identified Customer', fk=['Identified Customer'], card='M:1', note='Identified Customer carries the Party ID, so the contract joins the distributor hierarchy.'),
            dict(child='Accounting Period Status', parent='Fiscal Period', fk=['Status Fiscal Period'], card='M:1'),
            dict(child='Control', parent='Fiscal Period', fk=['Fiscal Period Key'], card='M:1', note='Fiscal Period Key carries the Fiscal Period ID (registry model gap).'),
            dict(child='Revenue Record', parent='Internal Legal Entity', fk=['Receiving Entity'], card='M:1'),
            dict(child='Revenue Record', parent='Share Class', fk=['Paying Share Class'], card='M:1'),
            dict(child='Fee Revenue Record', parent='Share Class', fk=['Revenue Share Class / Mandate'], card='M:1', optional=True),
            dict(child='Performance Fee Record', parent='Share Class', fk=['Performance Fee Share Class / Mandate'], card='M:1', optional=True),
            dict(child='Waiver Record', parent='Share Class', fk=['Supported Share Class'], card='M:1', optional=True),
            dict(child='Revenue Contract', parent='Internal Legal Entity', fk=['Contracting Legal Entity'], card='M:1', optional=True),
            dict(child='Journal Entry', parent='Internal Legal Entity', fk=['Posting Legal Entity'], card='M:1', optional=True),
            dict(child='Client Revenue Record', parent='Account', fk=['Revenue Account / Household'], card='M:1', optional=True),
            dict(child='Client Revenue Record', parent='Service Offering', fk=['Revenue Service Offering'], card='M:1', optional=True),
            dict(child='Client Revenue Record', parent='Internal Legal Entity', fk=['Recognizing Legal Entity'], card='M:1', optional=True),
            dict(child='Cash Program Economics', parent='Fee Revenue Record', fk=['Money Market Sweep Fund Revenue'], card='M:1', optional=True),
            dict(child='Account Fee Calculation', parent='Fee Calculation Run', fk=['Calculation Run'], card='M:1', optional=True),
            dict(child='Fee Debit', parent='Account', fk=['Debited Account'], card='M:1', optional=True),
            dict(child='Fee Invoice', parent='Party', fk=['Invoice Bill-To Party'], card='M:1', optional=True),
            dict(child='Fee Household', parent='Party', fk=['Anchor Client Household'], card='M:1', optional=True),
            dict(child='Share Class NAV', parent='Share Class', fk=['NAV Share Class'], card='M:1', optional=True),
            dict(child='Share Class NAV', parent='Fund NAV Calculation', fk=['Parent NAV Calculation'], card='M:1', optional=True),
            dict(child='Account Party Role', parent='Party', fk=['Role Party'], card='M:1'),
            dict(child='Account Party Role', parent='Account', fk=['Role Account'], card='M:1'),
            dict(child='Household Membership', parent='Party', fk=['Household'], card='M:1'),
            dict(child='Household Membership', parent='Party', fk=['Household Member'], card='M:1'),
            dict(child='Account Fee Calculation', parent='Client Revenue Record', fk=['Client Revenue Record Key'], card='M:1', optional=True, note='Model gap: no input attribute of Account Fee Calculation carries its link to Client Revenue Record; the placeholder key stands for the lineage join.'),
            dict(child='Fee Adjustment', parent='Account Fee Calculation', fk=['Account Fee Calculation Key'], card='M:1', optional=True, note='Model gap: no input attribute of Fee Adjustment carries its link to Account Fee Calculation; the placeholder key stands for the lineage join.'),
        ],
        notes="Foundational revenue product, modeled ER with Fiscal Period as the hub: fee, performance fee, waiver and distribution revenue records, GL postings, period close status and reconciliation controls all resolve to one accounting period. Revenue Record (the distribution revenue record) and Fee Revenue Record are the conformed revenue facts for DP-015, DP-034 and DP-035; Fee Revenue Record holds the measures because three of them are its own columns. External references (resolved by joining to the upstream product, not linked here): Fee Revenue Record.Revenue Share Class / Mandate, Performance Fee Record.Performance Fee Share Class / Mandate, Waiver Record.Supported Share Class and Revenue Record.Paying Share Class to Share Class or mandate (DP-004); Revenue Contract.Contracting Legal Entity, Revenue Record.Receiving Entity and Journal Entry.Posting Legal Entity to Internal Legal Entity (DP-013); Measure Value.Share Class to Share Class (DP-004) and Measure Value.Reporting Period, Snapshot and Measure to Reporting Period, Snapshot and Measure Definition (DP-008). Revenue Contract.Identified Customer joins to Identified Customer, conformed from DP-001 Party. Model gap: Distribution Revenue Record, Waiver Record and Control carry no accounting period, although their grains name it; Fiscal Period Key is borrowed to complete them. Add a period reference to each. GL postings, journal headers and accounting period status are read from 19 Finance & Accounting since CD-152; Accounting Period Status now carries its ledger and fiscal period. Model gap: no revenue record references its Revenue Contract, so contract and identified customer cannot be attributed to revenue; the links are shown as optional borrowed keys. Model gap: Revenue Data Basis (estimated / final) is on Fee Revenue Record only; Distribution Revenue Record has none, although the product grain includes data basis. Model gap: Control has no attribute for the legal entity or the revenue figures it reconciles; the DQ rule 'final only when every revenue-to-GL Control is reconciled' is evaluated per period only. WP1 re-point (CW-204): re-cut to Client Fee Revenue. Fee Revenue Record (5 conformers), Waiver Record, Accounting Period Status and Revenue Contract keep their objects and keys; the Measure Value entity is dropped with the 06 Measure Value and Asset Measures inputs (DP-008 is no longer upstream; Fee Basis Variance is re-based on DP-165 Class Net Assets). The 10 Client Revenue Record and Cash Program Economics, the 47 billed objects (Account Fee Calculation, Fee Calculation Run, Fee Debit, Fee Invoice, Fee Adjustment, Fee Household), 27 Share Class NAV and Fund NAV Calculation, 15 Account Party Role and 02 Household Membership are entities keyed by the registry; accounts, parties, offerings and legal entities are conformed from DP-093, DP-240, DP-004 and DP-013. Model gap: no input attribute links Account Fee Calculation to the Client Revenue Record recognized from it (Source Calculation Record is not a typed reference) or a Fee Adjustment to the calculation it adjusts; placeholder keys stand for those joins. WP1 lineage addition (CW-265, C-4): the new measure Client Fee Revenue (client fee slice of Gross Fee Revenue) is published with the product measures.",
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-013": dict(
        style="ER",
        entities=[
            # -- geography
            dict(name="Country", role="Entity", objects=[("09", "Country")],
                 pk=["Country Code (Alpha-2)"],
                 grain="one row = country (ISO 3166-1)",
                 note="Conformed country dimension, with default currency and primary time zone."),
            dict(name="Country Subdivision", role="Entity", objects=[("09", "Country Subdivision")],
                 pk=["Subdivision Code"],
                 grain="one row = country subdivision (ISO 3166-2)",
                 note="States, provinces and other subdivisions; US State FIPS Code bridges to the US county and ZIP schemes."),
            dict(name="Geographic Unit", role="Entity",
                 objects=[("09", "Geographic Unit"), ("09", "US County"), ("09", "Core Based Statistical Area"),
                          ("09", "ZIP Code & ZCTA")],
                 pk=["Geographic Unit ID"],
                 grain="one row = geographic unit (geographic scheme x scheme code x scheme vintage)",
                 note="Conformed geography dimension. The scheme-specific groups (US County, CBSA, ZIP Code & ZCTA) "
                      "fold here, as the spec's extension tables keyed on Geographic "
                      "Unit ID: each is populated only for units of its Geographic Unit Type. Vintage is part of the "
                      "grain, so each delineation vintage is a separate unit linked by Successor Geographic Unit."),
            dict(name="Geographic Hierarchy", role="Entity", objects=[("09", "Geographic Hierarchy")],
                 pk=["Geographic Hierarchy Type", "Parent Geographic Unit", "Child Geographic Unit",
                     "Hierarchy Effective From"],
                 grain="one row = hierarchy type x parent unit x child unit x effective period",
                 note="Roll-ups (ZIP to county to state to country, county to CBSA) as "
                      "effective-dated parent-child links, one parent per child per hierarchy type on any date."),
            dict(name="Geographic Group", role="Entity", objects=[("09", "Geographic Group")],
                 pk=["Geographic Group ID"],
                 grain="one row = geographic group (sales region, market cluster ...)"),
            dict(name="Geographic Group Membership", role="Entity", objects=[("09", "Geographic Group Membership")],
                 pk=["Geographic Group Key", "Member Geographic Unit", "Membership Effective From"],
                 grain="one row = geographic group x member unit x effective period",
                 note="Key is Geographic Group Key + Member Geographic Unit + Membership Effective From; the group is "
                      "not an attribute (the registry scopes membership within Geographic Group)."),
            dict(name="Time Zone", role="Entity", objects=[("09", "Time Zone")],
                 pk=["IANA Time Zone ID"],
                 grain="one row = IANA time zone"),
            # -- calendars and periods
            dict(name="Calendar", role="Entity", objects=[("09", "Calendar"), ("09", "Fiscal Calendar")],
                 pk=["Calendar ID"],
                 grain="one row = calendar (business, exchange, dealing, fiscal or composite)",
                 note="Conformed calendar dimension. Fiscal Calendar folds here and is populated only for calendars of "
                      "type fiscal (Fiscal Calendar ID, Fiscal Year Start, Period Structure)."),
            dict(name="Calendar Date", role="Entity", objects=[("09", "Calendar Date")],
                 pk=["Calendar Key", "Calendar Date"], measures=True,
                 grain="one row = calendar x date",
                 note="Conformed date dimension; Calendar Key carries the Calendar ID (Calendar Date is scoped within "
                      "Calendar). Holds the product measures because Business Day Indicator and Business Days in Period "
                      "are measured here and this is the most widely joined entity; the other measures are counts over "
                      "the entity they name (Code Mapping, Internal Legal Entity, Geographic Unit, Entity Authorization, "
                      "Classification Concordance, Code List Change Request, Locale)."),
            dict(name="Composite Calendar", role="Entity", objects=[("09", "Composite Calendar")],
                 pk=["Calendar Key", "Component Calendar"],
                 grain="one row = composite calendar x component calendar",
                 note="Calendar Key is the composite calendar; Component Calendar one of the calendars it combines "
                      "under Combination Rule (e.g. business day only if all components are open)."),
            dict(name="Fiscal Period", role="Entity", objects=[("09", "Fiscal Period")],
                 pk=["Fiscal Period ID"],
                 grain="one row = fiscal calendar x fiscal period",
                 note="Conformed accounting period, with Fiscal Period Status for close."),
            dict(name="Reporting Period Definition", role="Entity", objects=[("09", "Reporting Period Definition")],
                 pk=["Reporting Period Definition Code"],
                 grain="one row = reporting period definition (MTD, QTD, YTD ...)"),
            # -- currency and FX
            dict(name="Currency", role="Entity", objects=[("09", "Currency")],
                 pk=["Currency Code"],
                 grain="one row = currency (ISO 4217)",
                 note="Conformed currency dimension; Group Reporting Currency Indicator marks the reporting currency."),
            dict(name="Currency Pair Convention", role="Entity", objects=[("09", "Currency Pair Convention")],
                 pk=["Currency Pair"],
                 grain="one row = currency pair"),
            dict(name="FX Rate Type", role="Entity", objects=[("09", "FX Rate Type"), ("09", "FX Rate Source")],
                 pk=["FX Rate Type Code"],
                 grain="one row = FX rate type (e.g. WM/Reuters 4pm London close)",
                 note="FX Rate Source folds here: one source per rate type."),
            # -- language and conventions
            dict(name="Language", role="Entity", objects=[("09", "Language")],
                 pk=["Language Code (ISO 639-1)"],
                 grain="one row = language (ISO 639)"),
            dict(name="Locale", role="Entity", objects=[("09", "Locale"), ("09", "Number & Date Convention")],
                 pk=["Locale Tag"],
                 grain="one row = locale (BCP 47 tag)",
                 note="Number & Date Convention folds here (one set of separators, date pattern and rounding per "
                      "locale)."),
            dict(name="Unit of Measure", role="Entity", objects=[("09", "Unit of Measure")],
                 pk=["Unit Code"],
                 grain="one row = unit of measure"),
            # -- the firm's own legal entities and organization
            dict(name="Internal Legal Entity", role="Entity",
                 objects=[("09", "Internal Legal Entity"), ("09", "Legal Entity Identifier")],
                 pk=["Legal Entity ID"],
                 grain="one row = internal legal entity (or branch)",
                 note="Conformed legal entity dimension for employing, contracting, booking and receiving entities. "
                      "Legal Entity Identifier folds here (one current LEI, CIK, CRD and FRN per entity)."),
            dict(name="Entity Ownership Relationship", role="Entity", objects=[("09", "Entity Ownership Relationship")],
                 pk=["Child Entity", "Parent Entity", "Relationship Type", "Ownership Effective From"],
                 grain="one row = child entity x parent entity x relationship type x effective period"),
            dict(name="Entity Authorization", role="Entity", objects=[("38", "Entity Authorization")],
                 pk=["Authorization ID"],
                 grain="one row = legal entity x regulator x authorization type"),
            dict(name="Office Location", role="Entity", objects=[("09", "Office Location")],
                 pk=["Office ID"],
                 grain="one row = office location of the firm"),
            dict(name="Org Unit", role="Entity", objects=[("09", "Org Unit")],
                 pk=["Org Unit ID"],
                 grain="one row = org unit",
                 note="Conformed internal organization dimension. Unit Head is excluded from the spec (personal data)."),
            dict(name="Org Hierarchy Link", role="Entity", objects=[("09", "Org Hierarchy Link")],
                 pk=["Org Hierarchy Type", "Parent Org Unit", "Child Org Unit", "Link Effective From"],
                 grain="one row = hierarchy type x parent org unit x child org unit x effective period"),
            # -- code lists and classifications
            dict(name="Code List", role="Entity", objects=[("09", "Code List")],
                 pk=["Code List ID"],
                 grain="one row = registered code list",
                 note="Conformed code list registry entry; every Code attribute in the taxonomy draws its values from "
                      "one registered code list."),
            dict(name="Code Value", role="Entity", objects=[("09", "Code Value")],
                 pk=["Code List Key", "Code"],
                 grain="one row = code list (current version) x code value",
                 note="Key is Code List Key + Code. The registry scopes Code Value within Code List Version, which is "
                      "not an input, so values are keyed to their code list and versioned by SCD type 2 (see model "
                      "gap)."),
            dict(name="Code Mapping", role="Entity", objects=[("09", "Code Mapping")],
                 pk=["Code Mapping ID"],
                 grain="one row = source system x source value x target code list",
                 note="Conforms source-system values to registered codes; Mapping Status = approved is what counts a "
                      "value as mapped."),
            dict(name="Code List Change Request", role="Entity", objects=[("09", "Code List Change Request")],
                 pk=["Change Request Reference"],
                 grain="one row = code list change request"),
            dict(name="Code List Consumer", role="Entity", objects=[("09", "Code List Consumer")],
                 pk=["Code List Key", "Consuming Domain", "Consuming Attribute"],
                 grain="one row = code list x consuming domain x consuming attribute",
                 note="Binds each Code attribute in the taxonomy to the code list its values come from, so a Code Value "
                      "lookup can be published for every bound attribute. Key is Code List Key + Consuming Domain + "
                      "Consuming Attribute (registry scopes it within Code List), matching the DP-075 entity; Code "
                      "List Key is borrowed because the object has no code list attribute (see model gap)."),
            dict(name="Classification Scheme", role="Entity", objects=[("09", "Classification Scheme")],
                 pk=["Classification Scheme ID"],
                 grain="one row = classification scheme version (e.g. NAICS 2022, NACE Rev. 2.1)",
                 note="License Required Indicator = Y restricts publication to consumers covered by the Data Domain 14 "
                      "license."),
            dict(name="Classification Code", role="Entity", objects=[("09", "Classification Code")],
                 pk=["Classification Scheme Key", "Classification Code"],
                 grain="one row = classification scheme version x classification code",
                 note="Key is Classification Scheme Key + Classification Code: the same code can appear in several "
                      "schemes and versions (registry scopes it within Classification Scheme)."),
            dict(name="Classification Concordance", role="Entity", objects=[("09", "Classification Concordance")],
                 pk=["Source Classification Code", "Target Classification Code"],
                 grain="one row = source classification code x target classification code"),
        ],
        relationships=[
            # geography
            dict(child="Country", parent="Currency", fk=["Default Currency"], card="M:1", optional=True),
            dict(child="Country", parent="Time Zone", fk=["Primary Time Zone"], card="M:1", optional=True),
            dict(child="Country Subdivision", parent="Country", fk=["Parent Country"], card="M:1"),
            dict(child="Geographic Unit", parent="Country", fk=["Country"], card="M:1", optional=True,
                 note="Empty only for supranational units."),
            dict(child="Geographic Unit", parent="Geographic Unit", fk=["Successor Geographic Unit"], card="M:1",
                 optional=True, note="The unit that replaces this one in a later vintage."),
            dict(child="Geographic Unit", parent="Geographic Unit", fk=["Preferred County"], card="M:1", optional=True,
                 note="ZIP codes only. Value lookup: Preferred County holds a County FIPS Code, matched to the US "
                      "county unit of the same vintage, not the Geographic Unit ID."),
            dict(child="Geographic Unit", parent="Geographic Unit", fk=["County CBSA Code"], card="M:1",
                 optional=True,
                 note="US counties only. Value lookup on CBSA Code of the CBSA unit of the same delineation vintage; "
                      "gives the metro roll-up."),
            dict(child="Geographic Unit", parent="Code Value", fk=["Geographic Unit Type"], card="M:1",
                 note="Value lookup: Geographic Unit Type, like every Code attribute here, takes its values from a "
                      "registered code list. Shown once to tie the code list registry to the reference members it "
                      "governs (see model gap)."),
            dict(child="Geographic Hierarchy", parent="Geographic Unit", fk=["Parent Geographic Unit"], card="M:1"),
            dict(child="Geographic Hierarchy", parent="Geographic Unit", fk=["Child Geographic Unit"], card="M:1"),
            dict(child="Geographic Group Membership", parent="Geographic Group", fk=["Geographic Group Key"],
                 card="M:1", note="Geographic Group Key carries the Geographic Group ID (registry scoping)."),
            dict(child="Geographic Group Membership", parent="Geographic Unit", fk=["Member Geographic Unit"],
                 card="M:1"),
            # calendars
            dict(child="Calendar", parent="Country", fk=["Calendar Country"], card="M:1", optional=True,
                 note="Empty for exchange and composite calendars that are not country-based."),
            dict(child="Calendar", parent="Time Zone", fk=["Calendar Time Zone"], card="M:1", optional=True),
            dict(child="Calendar Date", parent="Calendar", fk=["Calendar Key"], card="M:1",
                 note="Calendar Key carries the Calendar ID (Calendar Date is scoped within Calendar)."),
            dict(child="Composite Calendar", parent="Calendar", fk=["Calendar Key"], card="M:1",
                 note="The composite calendar."),
            dict(child="Composite Calendar", parent="Calendar", fk=["Component Calendar"], card="M:1",
                 note="One of the calendars it combines."),
            dict(child="Fiscal Period", parent="Calendar", fk=["Calendar Key"], card="M:1",
                 note="Model gap: Fiscal Period has no attribute for its fiscal calendar, although its grain is fiscal "
                      "calendar x fiscal period; Calendar Key would carry the Calendar ID of the fiscal calendar."),
            dict(child="Reporting Period Definition", parent="Calendar", fk=["Period Basis Calendar"], card="M:1",
                 optional=True),
            # currency and FX
            dict(child="Currency", parent="Currency", fk=["Replacement Currency"], card="M:1", optional=True,
                 note="Withdrawn currencies only."),
            dict(child="Currency Pair Convention", parent="Currency", fk=["Currency Pair"], card="M:N",
                 note="Value lookup, not a key: the pair code embeds the base and quote ISO 4217 codes (see model "
                      "gap)."),
            dict(child="FX Rate Type", parent="Calendar", fk=["Publication Calendar"], card="M:1", optional=True,
                 note="Business-day calendar on which the rate type is published; resolves to a published Calendar "
                      "ID."),
            # language and conventions
            dict(child="Locale", parent="Locale", fk=["Fallback Locale"], card="M:1", optional=True),
            dict(child="Locale", parent="Language", fk=["Language Key"], card="M:1",
                 note="Model gap: Locale has no language attribute. Language Key would carry the language subtag of the "
                      "BCP 47 Locale Tag (ISO 639-1); today it can only be parsed from the tag."),
            dict(child="Locale", parent="Country", fk=["Country Key"], card="M:1", optional=True,
                 note="Model gap: Locale has no country attribute. Country Key would carry the region subtag of the "
                      "Locale Tag (ISO 3166-1 alpha-2); empty for language-only locales."),
            dict(child="Unit of Measure", parent="Code Value", fk=["Unit Category"], card="M:1", optional=True,
                 note="Value lookup on the registered unit category code list."),
            # legal entities and organization
            dict(child="Internal Legal Entity", parent="Internal Legal Entity", fk=["Head Office Entity"], card="M:1",
                 optional=True, note="Branches only (Branch Indicator = Y)."),
            dict(child="Internal Legal Entity", parent="Country", fk=["Jurisdiction of Formation"], card="M:1",
                 optional=True,
                 note="US entities may record a state of formation (ISO 3166-2), which resolves to Country "
                      "Subdivision instead; see decisions in the notes."),
            dict(child="Entity Ownership Relationship", parent="Internal Legal Entity", fk=["Child Entity"],
                 card="M:1"),
            dict(child="Entity Ownership Relationship", parent="Internal Legal Entity", fk=["Parent Entity"],
                 card="M:1"),
            dict(child="Entity Authorization", parent="Internal Legal Entity", fk=["Authorized Entity"], card="M:1"),
            dict(child="Office Location", parent="Internal Legal Entity", fk=["Office Legal Entity"], card="M:1"),
            dict(child="Office Location", parent="Country Subdivision", fk=["Office Country / Subdivision"],
                 card="M:1", optional=True,
                 note="Holds a subdivision code where one applies; offices recorded at country level resolve to Country "
                      "through the code's country prefix."),
            dict(child="Office Location", parent="Time Zone", fk=["Office Time Zone"], card="M:1", optional=True),
            dict(child="Org Unit", parent="Internal Legal Entity", fk=["Employing / Booking Entity"], card="M:1"),
            dict(child="Org Hierarchy Link", parent="Org Unit", fk=["Parent Org Unit"], card="M:1"),
            dict(child="Org Hierarchy Link", parent="Org Unit", fk=["Child Org Unit"], card="M:1"),
            # code lists and classifications
            dict(child="Code Value", parent="Code List", fk=["Code List Key"], card="M:1",
                 note="Code List Key carries the Code List ID; Code Value has no attribute for its list or version "
                      "(model gap)."),
            dict(child="Code Value", parent="Code Value", fk=["Parent Code"], card="M:1", optional=True,
                 note="Hierarchical code lists; the parent is in the same code list."),
            dict(child="Code Value", parent="Code Value", fk=["Replaced By Code"], card="M:1", optional=True,
                 note="Retired codes; the replacement is in the same code list."),
            dict(child="Code Mapping", parent="Code List", fk=["Target Code List"], card="M:1"),
            dict(child="Code Mapping", parent="Code Value", fk=["Target Code"], card="M:1", optional=True,
                 note="With Target Code List, Target Code completes the Code Value key; DQ requires approved mappings "
                      "to point to an active value."),
            dict(child="Code List Consumer", parent="Code List", fk=["Code List Key"], card="M:1",
                 note="Model gap: borrowed key; Code List Consumer has no attribute naming its code list (taxonomy "
                      "follow-up), so Code List Key carries the Code List ID."),
            dict(child="Code List Change Request", parent="Code List", fk=["Code List Key"], card="M:1",
                 note="Model gap: the change request has no attribute for the code list it changes; Code List Key "
                      "would carry the Code List ID."),
            dict(child="Classification Scheme", parent="Country", fk=["Scheme Jurisdiction"], card="M:1",
                 optional=True,
                 note="National schemes only; EU and international schemes (NACE, ISIC) hold a region code that is not "
                      "a country."),
            dict(child="Classification Code", parent="Classification Scheme", fk=["Classification Scheme Key"],
                 card="M:1", note="Classification Scheme Key carries the Classification Scheme ID (registry scoping)."),
            dict(child="Classification Code", parent="Classification Code", fk=["Parent Classification Code"],
                 card="M:1", optional=True, note="Within the same scheme version."),
            dict(child="Classification Concordance", parent="Classification Code",
                 fk=["Source Classification Code"], card="M:1"),
            dict(child="Classification Concordance", parent="Classification Code",
                 fk=["Target Classification Code"], card="M:1"),
        ],
        notes=("Root foundational reference product, modeled ER as a package of small reference sets: one entity per "
               "Business Object (32 entities for 42 inputs, because the scheme-specific geography groups, Fiscal "
               "Calendar, FX Rate Source, Legal Entity Identifier and Number & Date Convention fold into their parents). "
               "It is connected through five hubs: Country (geography, calendars, legal entities, classification), "
               "Calendar (dates, fiscal and reporting periods, FX rate types), Internal Legal Entity (ownership, "
               "authorizations, offices, org units), Code List (values, mappings, change requests, consumers) and "
               "Geographic Unit. "
               "Conformed entities: Calendar, Calendar Date, Fiscal Period, Country, Currency, Geographic Unit, Internal "
               "Legal Entity, Org Unit, Code List, Code Value. "
               "Many Code attributes (Country.Default Currency, Primary Time Zone, Calendar Country, Office Time Zone ...) "
               "are linked as foreign keys because they hold the natural key of another entity in this product. "
               "External references (cross-references only; this product has no upstream, so they are resolved by the "
               "downstream products that depend on DP-013, not joined here): Code List.Data Owner to Employee (20, "
               "published through DP-009); Internal Legal Entity.Party Master Cross-Reference to Party (DP-001); FX Rate "
               "Source.Licensed Dataset to Dataset (14, cataloged in DP-075). "
               "Model gap: Code List Version is not an input, so Code List.Current Version has nothing to join to and "
               "Code Value, which the registry scopes within Code List Version, is keyed to its code list instead. Code "
               "Value, Code List Change Request and Code List Consumer carry no attribute for their code list; Code List "
               "Key is borrowed. Code List Consumer is the binding of each Code attribute to its code list; only "
               "Geographic Unit Type and Unit Category are drawn as value lookups to Code Value, and every other bound "
               "Code attribute follows the same pattern through its Code List Consumer row. "
               "Model gap: Fiscal Period has no fiscal calendar attribute, so it is linked to Calendar through a "
               "borrowed Calendar Key. "
               "Model gap: Currency Pair Convention has only the pair code (no base and quote currency attributes), and "
               "Locale has no language or country attribute (parsed from the tag; shown as borrowed Language Key and "
               "Country Key). "
               "Model gap: Country Subdivision is not linked to Geographic Unit (states also exist as geographic units in "
               "the ISO 3166-2 scheme), and Classification Concordance carries codes without their scheme versions, so a "
               "code that exists in two schemes is ambiguous. "
               "Taxonomy gap (from the spec): no FX rate observation object. "
               "W1 re-point (CW-909): UK Postcode, ITL Region and NUTS Region leave Geographic Unit, and EU Member State "
               "Indicator, EEA Member Indicator, FCA Firm Reference Number and Benchmark Regulatory Status leave Country, "
               "Internal Legal Entity and FX Rate Type, with the spec inputs (removed, US only)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-014": dict(
        style="ER",
        entities=[
            dict(name="Industry Flow Observation", role="Entity", objects=[("11", "Industry Flow Observation")],
                 pk=["Data Release", "Industry Category", "Distribution Channel", "Vehicle Type", "Region / Market",
                     "Distributor Firm", "Fund Manager Firm", "Fund / Share Class"], measures=True,
                 grain="one row = data release x category x channel x vehicle type x region x distributor firm x fund "
                       "manager x fund or share class (the product grain)",
                 note="Conformed industry flow fact and the core of the product. Dimension members the release does not "
                      "provide need an 'all / not applicable' member rather than a null in the key (registry). Holds the "
                      "product measures; Peer Median Expense Ratio and Peer Flow Rank are measured on Peer Metric "
                      "Snapshot rows, joined through Peer Fund."),
            dict(name="Industry Data Release", role="Entity", objects=[("11", "Industry Data Release")],
                 pk=["Data Release ID"],
                 grain="one row = industry dataset x release (as-of date, publication version)",
                 note="Every vendor release is kept, including superseded ones; Supersedes Release gives the revision "
                      "chain behind Release Revision."),
            dict(name="Industry Dataset Profile", role="Entity", objects=[("11", "Industry Dataset Profile")],
                 pk=["Licensed Dataset"],
                 grain="one row = licensed industry flow or AUM dataset",
                 note="The industry extension of 14 Dataset (1:1): Licensed Dataset carries the Dataset ID of the "
                      "conformed Dataset entity."),
            dict(name="Category Mapping", role="Entity", objects=[("11", "Category Mapping")],
                 pk=["Category Scheme", "External Category Value", "Mapped Share Class", "Mapping Effective From"],
                 grain="one row = category scheme x external category value x own share class x effective period",
                 note="Maps vendor categories to own share classes and internal market segments; drives Mapped "
                      "Coverage %."),
            dict(name="Competitor", role="Entity", objects=[("11", "Competitor Profile")],
                 pk=["Competitor Profile ID"],
                 grain="one row = competitor firm (fund manager)",
                 note="Conformed competitor dimension; holds 11 Competitor Profile. Vendor Manager Identifiers resolve "
                      "vendor fund manager codes to the competitor, and identify the firm's own rows."),
            dict(name="Peer Fund", role="Entity", objects=[("11", "Peer Fund")],
                 pk=["Peer Fund ID"],
                 grain="one row = peer fund or share class (competitor product)",
                 note="Conformed peer fund dimension, identified externally by ISIN or Morningstar SecId."),
            dict(name="Peer Metric Snapshot", role="Entity", objects=[("11", "Peer Metric Snapshot")],
                 pk=["Peer Fund Key", "Snapshot Date", "Return Period", "Peer Universe"],
                 grain="one row = peer fund x snapshot date x return period x peer universe",
                 note="Child of Peer Fund (registry fold=False). Key is Peer Fund Key + the registry discriminator; "
                      "Peer Fund Key carries the Peer Fund ID because the group has no attribute for its fund."),
            dict(name="Peer Universe", role="Entity", objects=[("11", "Peer Universe")],
                 pk=["Peer Universe ID"],
                 grain="one row = peer universe (versioned by effective period)",
                 note="Conformed peer universe dimension. The registry keys it on Peer Universe ID; with SCD history, "
                      "Universe Effective From joins the key (see decisions)."),
            dict(name="Peer Universe Member", role="Entity", objects=[("11", "Peer Universe Member")],
                 pk=["Peer Universe Key", "Member Fund"],
                 grain="one row = peer universe x member fund",
                 note="Child of Peer Universe (registry fold=False); Peer Universe Key carries the Peer Universe ID."),
            dict(name="Market Share Definition", role="Entity", objects=[("11", "Market Share Definition")],
                 pk=["Share Definition Code"],
                 grain="one row = market share definition"),
            dict(name="Market Share Record", role="Entity", objects=[("11", "Market Share Record")],
                 pk=["Market Share Record ID"],
                 grain="one row = share definition x period end date x period type x category or segment x channel x "
                       "distributor firm x market x vehicle type",
                 note="Conformed market share fact, mastered in 11 and published here for DP-015 and DP-031."),
            dict(name="Permitted Use Grant", role="Entity", objects=[("14", "Permitted Use Grant")],
                 pk=["Grant Dataset", "Permitted Use Category", "Grant Effective From"],
                 grain="one row = data license agreement x dataset x permitted use category x grant effective period",
                 note="Grant Agreement is now an input and completes the registry key (Grant Agreement + Grant "
                      "Dataset + Permitted Use Category + Grant Effective From), which the spec names as the key. The "
                      "published key stays at three attributes for now because consumer models conform to this entity; "
                      "consumers needing uniqueness across agreements (DP-048) declare the full registry key "
                      "themselves. Until the key is widened, two agreements granting the same use of a dataset from "
                      "the same date collide (model gap)."),
            dict(name="Dataset", role="Entity", conformed=("DP-075", "Dataset"), objects=[],
                 note="Conformed from DP-075 Dataset (now upstream), which catalogs 14 Dataset. Holding it here lets "
                      "Licensed Dataset, Denominator Dataset and Grant Dataset join to the dataset they reference, "
                      "including non-industry datasets in grants (GAP-11-003)."),
            dict(name="Load", role="Entity", conformed=("DP-075", "Load"), objects=[],
                 note="Conformed from DP-075 Load (now upstream), so a release traces to the load that ingested it. "
                      "Replaces the Source Load ID carried unlinked."),
            dict(name="Attribution Requirement", role="Entity", objects=[("14", "Attribution Requirement")],
                 pk=["Attribution Requirement Key"],
                 grain="one row = data license agreement x attribution and disclaimer requirement (per output type set)",
                 note="Surrogate key kept so consumer models that conform to this entity are not re-keyed. Attribution "
                      "Agreement is now an input, so the registry key (Attribution Agreement + Applies To Output Types) "
                      "is available as the natural key and is what consumers should match on."),
        ],
        relationships=[
            dict(child="Industry Flow Observation", parent="Industry Data Release", fk=["Data Release"], card="M:1"),
            dict(child="Industry Flow Observation", parent="Competitor", fk=["Fund Manager Firm"], card="M:1",
                 optional=True, note="Empty or 'all' where the release is not at manager grain."),
            dict(child="Industry Flow Observation", parent="Peer Fund", fk=["Fund / Share Class"], card="M:1",
                 optional=True,
                 note="Fund-level releases only. The reference may also name an own share class (Reference (Peer Fund / "
                      "Share Class)); own share classes are reached through Category Mapping, not this link."),
            dict(child="Industry Flow Observation", parent="Category Mapping", fk=["Industry Category"], card="M:N",
                 optional=True,
                 note="Value lookup, not a key: Industry Category matches External Category Value within the dataset's "
                      "Category Scheme, on the mapping effective at the release's As-of Date."),
            dict(child="Industry Data Release", parent="Industry Data Release", fk=["Supersedes Release"], card="1:1",
                 optional=True, note="Revision chain: each release replaces at most one earlier release."),
            dict(child="Industry Data Release", parent="Industry Dataset Profile", fk=["Industry Dataset Profile Key"],
                 card="M:1",
                 note="Model gap: the release has no attribute for its dataset, although its grain is dataset x "
                      "release; Industry Dataset Profile Key would carry the Licensed Dataset (Dataset ID)."),
            dict(child="Peer Fund", parent="Competitor", fk=["Managing Firm"], card="M:1"),
            dict(child="Peer Metric Snapshot", parent="Peer Fund", fk=["Peer Fund Key"], card="M:1",
                 note="Peer Fund Key carries the Peer Fund ID (child group of Peer Fund)."),
            dict(child="Peer Metric Snapshot", parent="Peer Universe", fk=["Peer Universe"], card="M:1",
                 note="Ranks and percentiles are relative to this universe."),
            dict(child="Peer Universe Member", parent="Peer Universe", fk=["Peer Universe Key"], card="M:1",
                 note="Peer Universe Key carries the Peer Universe ID (child group of Peer Universe)."),
            dict(child="Peer Universe Member", parent="Peer Fund", fk=["Member Fund"], card="M:1"),
            dict(child="Market Share Record", parent="Market Share Definition", fk=["Share Definition"], card="M:1"),
            dict(child="Industry Dataset Profile", parent="Dataset", fk=["Licensed Dataset"], card="1:1",
                 note="Industry Dataset Profile is the 1:1 industry extension of the cataloged dataset."),
            dict(child="Market Share Definition", parent="Dataset", fk=["Denominator Dataset"], card="M:1",
                 note="Joins to the conformed Dataset, the registry target; industry attributes of the denominator are "
                      "reached through Industry Dataset Profile on the same Dataset ID."),
            dict(child="Permitted Use Grant", parent="Dataset", fk=["Grant Dataset"], card="M:1",
                 note="Joins to the conformed Dataset, the registry target, so grants on non-industry datasets are "
                      "covered too."),
            dict(child="Industry Data Release", parent="Load", fk=["Source Load"], card="M:1", optional=True,
                 note="The load that ingested the vendor release."),
            dict(child="Attribution Requirement", parent="Permitted Use Grant", fk=["Permitted Use Grant Key"],
                 card="M:N",
                 note="Join on Attribution Agreement = Grant Agreement: a requirement applies to every grant under the "
                      "same data license agreement, which the DQ rule enforces. Both attributes point to 14 Data "
                      "License Agreement, which is not an input, so the shared parent is drawn as this M:N link with "
                      "the borrowed Permitted Use Grant Key rather than as a foreign key to the agreement."),
        ],
        notes=("Foundational industry baseline, modeled ER around Industry Flow Observation, with a release and dataset "
               "chain (Industry Data Release > Industry Dataset Profile > Dataset > Permitted Use Grant > Attribution "
               "Requirement), a peer chain (Competitor > Peer Fund > Peer Metric Snapshot; Peer Universe > Peer Universe "
               "Member) and market share (Market Share Definition > Market Share Record). Conformed entities: Peer Fund, "
               "Peer Universe, Competitor and Industry Flow Observation, plus Market Share Record. "
               "External references (resolved by joining to the upstream product, not linked here): Industry Flow "
               "Observation.Distributor Firm and Market Share Record.Distributor Firm to Distributor Firm / Party "
               "(DP-001); Competitor.Competitor Party to Party (DP-001); Category Mapping.Mapped Share Class to Share "
               "Class (DP-004); Peer Universe.Own Strategy Compared to Investment Strategy (DP-004); Observation "
               "Currency to Currency and Region / Market to Geographic Unit or Country (DP-013). Industry Dataset "
               "Profile.Licensed Dataset, Market Share Definition.Denominator Dataset and Permitted Use Grant.Grant "
               "Dataset join to Dataset, and Industry Data Release.Source Load to Load, both conformed from DP-075. "
               "Model gap: Industry Data Release has no dataset attribute; add Release Dataset to the inputs. "
               "Model gap: Industry Flow Observation has no own-firm flag (spec taxonomy gap); own rows are found by "
               "matching Fund Manager Firm to the firm's own Competitor row through Vendor Manager Identifiers. "
               "Model gap: Market Share Record has no link to the industry release or observations it was computed "
               "from, so Release Revision cannot be traced into market share. "
               "GAP-11-003 resolved: with DP-075 upstream, Denominator Dataset and Grant Dataset join to the conformed "
               "Dataset rather than to Industry Dataset Profile. "
               "Decision for data owners: widen the Permitted Use Grant key to the full registry key (adding Grant "
               "Agreement) and replace the Attribution Requirement surrogate with Attribution Agreement + Applies To "
               "Output Types, coordinated with the consumer models that conform to them."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-075": dict(
        style="ER",
        entities=[
            dict(name="Lineage Edge", role="Entity", objects=[],
                 pk=["Lineage Edge Key"], measures=True,
                 grain="one row = source catalog entry x target catalog entry x effective period",
                 note="Model gap: no taxonomy object holds lineage edges, data products or data product inputs (spec "
                      "taxonomy gap); they come from the program's own register. The entity is kept with a surrogate "
                      "key and no attributes of its own, and joins to each catalog entry type through an optional "
                      "'<Entry> Key' (one is filled for each end of the edge; data product ends point to the register). "
                      "It is the hub of the catalog and holds the product measures, because Lineage Completeness %, "
                      "Downstream Impact Count and DQ Rule Pass Rate roll up along edges; the other measures are counts "
                      "over the entry they name."),
            dict(name="Code List", role="Entity", objects=[("09", "Code List")],
                 pk=["Code List ID"],
                 grain="one row = registered code list x version (SCD type 2)"),
            dict(name="Code List Version", role="Entity", objects=[("09", "Code List Version")],
                 pk=["Code List Version ID"],
                 grain="one row = code list version"),
            dict(name="Code List Consumer", role="Entity", objects=[("09", "Code List Consumer")],
                 pk=["Code List Key", "Consuming Domain", "Consuming Attribute"],
                 grain="one row = code list x consuming domain x consuming attribute",
                 note="Key is Code List Key + the registry's Consuming Domain + Consuming Attribute; the consumer has "
                      "no attribute for its code list (registry scopes it within Code List)."),
            dict(name="Code Mapping", role="Entity", objects=[("09", "Code Mapping")],
                 pk=["Code Mapping ID"],
                 grain="one row = source system x source value x target code list"),
            dict(name="Reference Data Subscription", role="Entity", objects=[("09", "Reference Data Subscription")],
                 pk=["Reference Data Set", "Subscribing System"],
                 grain="one row = reference data set x subscribing system"),
            dict(name="Dataset", role="Entity", objects=[("14", "Dataset"), ("14", "Dataset Delivery")],
                 pk=["Dataset ID"],
                 grain="one row = licensed dataset x version (SCD type 2)",
                 note="Catalog entry for a licensed vendor dataset. Dataset Delivery folds here (one delivery method "
                      "and technical feed per dataset)."),
            dict(name="Dataset Key Field", role="Entity", objects=[("14", "Dataset Key Field")],
                 pk=["Dataset Key", "Field Name"],
                 grain="one row = dataset x key field",
                 note="Key is Dataset Key + Field Name; Dataset Key carries the Dataset ID because no attribute holds "
                      "it (registry model gap)."),
            dict(name="Dataset Consumption", role="Entity", objects=[("14", "Dataset Consumption")],
                 pk=["Consumed Dataset", "Consuming Application", "Use Case", "Consumption Effective From"],
                 grain="one row = dataset x consuming application x use case x consumption effective period",
                 note="Drives Orphan Dataset Count and Uncovered Consumption Count."),
            dict(name="Consuming Application", role="Entity", objects=[("14", "Consuming Application")],
                 pk=["Consuming Application ID"],
                 grain="one row = consuming application"),
            dict(name="Application", role="Entity", conformed=("DP-101", "Application"), objects=[],
                 note="Conformed from DP-101 (41 Application, upstream): the source system of a code mapping, the "
                      "subscribing system of a reference data subscription and the application behind a consuming "
                      "application (keyed by APPL-, CD-264)."),
            dict(name="Data Feed", role="Entity", objects=[("06", "Data Feed")],
                 pk=["Feed ID"],
                 grain="one row = data feed (provider x content x layout) x version"),
            dict(name="Load", role="Entity", objects=[("06", "Load")],
                 pk=["Load ID"],
                 grain="one row = feed file load (feed x business date x file)",
                 note="Load history behind Feed Freshness Flag."),
            dict(name="Measure Definition", role="Entity", objects=[("06", "Measure Definition")],
                 pk=["Measure ID"],
                 grain="one row = measure definition version"),
            dict(name="DQ Rule", role="Entity", objects=[("21", "Data Quality Rule")],
                 pk=["DQ Rule ID"],
                 grain="one row = data quality rule",
                 note="21 Data Quality Rule (moved from 06 under CD-156)."),
            dict(name="DQ Result", role="Entity", objects=[("21", "Data Quality Result")],
                 pk=["DQ Result ID"],
                 grain="one row = data quality rule x execution",
                 note="21 Data Quality Result; only the latest result per rule is cataloged (summary for discovery; "
                      "monitoring belongs to DP-045)."),
            dict(name="Marketing System", role="Entity", objects=[("04", "Marketing System")],
                 pk=["System Name"],
                 grain="one row = marketing system (application instance)",
                 note="The system name is the catalog key (no identifier attribute)."),
        ],
        relationships=[
            # lineage edge to each catalog entry type
            dict(child="Lineage Edge", parent="Dataset", fk=["Dataset Key"], card="M:1", optional=True,
                 note="Licensed dataset as a lineage source."),
            dict(child="Lineage Edge", parent="Data Feed", fk=["Data Feed Key"], card="M:1", optional=True),
            dict(child="Lineage Edge", parent="Code List", fk=["Code List Key"], card="M:1", optional=True),
            dict(child="Lineage Edge", parent="Marketing System", fk=["Marketing System Key"], card="M:1",
                 optional=True, note="Marketing System Key carries the System Name."),
            dict(child="Lineage Edge", parent="Measure Definition", fk=["Measure Definition Key"], card="M:1",
                 optional=True, note="Measure used by a data product (for Certified Measure Share %)."),
            dict(child="DQ Result", parent="DQ Rule", fk=["Tested DQ Rule"], card="M:1"),
            dict(child="Lineage Edge", parent="DQ Rule", fk=["DQ Rule Key"], card="M:1", optional=True,
                 note="Rule applied to a feed, dataset or product (for DQ Rule Pass Rate by dependent product)."),
            dict(child="Lineage Edge", parent="Consuming Application", fk=["Consuming Application Key"], card="M:1",
                 optional=True, note="Application as a lineage target (for Downstream Impact Count)."),
            # code lists
            dict(child="Code List", parent="Code List Version", fk=["Current Version"], card="1:1", optional=True,
                 note="DQ requires every registered list's Current Version to exist."),
            dict(child="Code List Version", parent="Code List", fk=["Code List Key"], card="M:1",
                 note="Model gap: Code List Version has no attribute for its code list; Code List Key would carry the "
                      "Code List ID."),
            dict(child="Code List Consumer", parent="Code List", fk=["Code List Key"], card="M:1",
                 note="Code List Key carries the Code List ID (registry scoping)."),
            dict(child="Code Mapping", parent="Code List", fk=["Target Code List"], card="M:1"),
            dict(child="Code Mapping", parent="Application", fk=["Source System"], card="M:1",
                 note="The source system whose values are mapped. Uncataloged Marketing Source Count still matches the "
                      "source system to Marketing System.System Name by value (no input names the marketing system's "
                      "application)."),
            dict(child="Reference Data Subscription", parent="Code List", fk=["Reference Data Set"], card="M:1"),
            dict(child="Reference Data Subscription", parent="Application", fk=["Subscribing System"], card="M:1",
                 note="The subscribing system; it meets Consuming Application through the same application."),
            dict(child="Consuming Application", parent="Application", fk=["Consuming Application ID"], card="1:1",
                 note="The consuming application is keyed by the APPL- application ID (CD-264)."),
            # datasets and feeds
            dict(child="Dataset", parent="Data Feed", fk=["Technical Feed"], card="M:1", optional=True,
                 note="From the folded Dataset Delivery; links the licensed dataset to the feed that lands it."),
            dict(child="Dataset Key Field", parent="Dataset", fk=["Dataset Key"], card="M:1",
                 note="Dataset Key carries the Dataset ID (registry model gap)."),
            dict(child="Dataset Consumption", parent="Dataset", fk=["Consumed Dataset"], card="M:1"),
            dict(child="Dataset Consumption", parent="Consuming Application", fk=["Consuming Application"],
                 card="M:1"),
            dict(child="Load", parent="Data Feed", fk=["Feed"], card="M:1"),
        ],
        notes=("Foundational catalog product, modeled ER with the taxonomy's catalog entry types (Dataset, Data Feed, "
               "Code List, Marketing System, Measure Definition, DQ Rule, Consuming Application) as entities, joined "
               "through Lineage Edge. Code lists carry their versions, consumers, mappings and subscriptions; datasets "
               "their key fields, delivery and consumption; feeds their loads. "
               "External references (identifiers only; their masters are not upstream of this product, so they are not joined): "
               "Code List.Data Owner and Data Steward and Dataset.Dataset Business Owner to Employee (20; hold roles, "
               "not named individuals); Dataset.Dataset Vendor to Data Vendor / Party and Data Feed.Data Provider to "
               "Party (DP-001). "
               "Model gap: the data product register, data product inputs, certification, non-marketing source systems "
               "and lineage edges have no taxonomy objects (spec taxonomy gap). Lineage Edge is therefore an entity "
               "with no taxonomy attributes; its source and target ends, edge type and effective period come from the "
               "program's own register until a metadata family is added to Data Domain 09. Measure Definition and DQ "
               "Rule join the model only through Lineage Edge. "
               "Model gap: Code List Version, Code List Consumer and Dataset Key Field carry no attribute for their "
               "parent; Code List Key and Dataset Key are borrowed. "
               "DQ Rule and DQ Result are read from 21 Data Governance & Analytics since CD-156; the rule's target "
               "element or asset and the result's execution timestamp are now in the taxonomy. "
               "Code Mapping.Source System, Reference Data Subscription.Subscribing System and Consuming Application "
               "resolve to the conformed 41 Application (DP-101). Model gap: Marketing System carries no application "
               "input, so marketing sources are still matched to Marketing System.System Name by value."),
    ),
}
