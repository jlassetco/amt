"""Logical data models, Wave WP2 foundational group A2 "advice": ER models for the foundational advice, managed account,
fee, manager, trust and model construction products of specs_w1f_advice.py (wealth-manager reference model). See
CONTRACT.md and 00_Program/Rework/Agent_Instructions/models_common.md.

DP-303 Advice Plans & Recommendations (45); DP-304 Managed Account Model Assignments (46); DP-305 Fee Schedules & Billing
Runs (47); DP-306 Manager & Sub-Adviser Master (52); DP-307 Trust Fiduciary Record (51, optional); DP-530 Capital Market
Assumptions, Model Lineups & Model Weights (24).

Conventions used in these models:
- Each product's own master objects are entities keyed as the registry says; Attribute Groups with fold=True sit on their
  parent's entity (45 Recommendation Rationale, 45 PTE 2020-02 Documentation, 46 Tax Management Setting, 47 Performance
  Fee Terms, 52 Manager-of-Managers Hire Condition, 02 Organization, 15 Account Registration Detail) and the one fold=False
  group (51 Trust Instrument Document) is a child entity keyed by its parent reference plus the discriminator.
- Objects another foundational product publishes are conformed entities (role "Entity") with the plain conformed name of
  the WP2 set: Party, Household and Household Membership and Investor Profile (DP-240), Client Account, Program
  Enrollment and Account Agreement (DP-093), Advisor (DP-009, 20 Employee with 03 Advisor), Employee (DP-192), Offering
  or Program, Model Portfolio, Share Class and Investment Product (DP-004), Instrument and Benchmark (DP-097), Model
  (DP-212), Contract (DP-213), Internal Legal Entity (DP-013), Portfolio and Investment Mandate (DP-140). Where the product
  reads that object as an input, the input sits on the conformed entity. Household is a 02 Party (PTY-HH-) and is conformed
  from the DP-240 Party entity under the role name Household; it is never a column on the account.
- Within this group the spec dependency order is kept: DP-530 publishes Capital Market Assumption Set and Target Allocation
  Set (read by DP-303 and DP-304), DP-306 publishes Sub-Adviser Engagement (read by DP-304) and DP-303 publishes Advice
  Engagement (read by DP-305).
- A reference whose target product is not upstream (or is downstream, which would make a cycle) stays an attribute and is
  listed under "External references" in the model notes; it is resolved by joining to the named product.
- A single reference attribute that points to an entity with a composite key (e.g. CMA set ID x version) is drawn as the
  foreign key; the rest of the key comes from the context named in the relationship note.
- Three books of record (CW-007): no model here joins a 49 Client Holding, an 18 Portfolio Holding or an 06 Fund
  Shareholder Position. The only holding-side keys read are 46 Tax-Loss Harvest Decision.Harvest Client Tax Lots (49, a key
  into DP-300) and 52 Sub-Adviser Engagement.Sleeve Portfolio (18 Portfolio, the book, not its holdings).
- PII tiers are those the content modules state on each object ("Object PII tier"); every entity that carries PII names
  its tier in the note. Special-category values (CD-344) occur only in DP-307 and are handled there.
"""


def ent(name, objects, pk, grain="", note="", measures=False):
    return dict(name=name, role="Entity", objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def conf(name, src, objects=(), pk=None, note=""):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role="Entity", conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources outside this group
PARTY = ("DP-240", "Party")
HHMEM = ("DP-240", "Household Membership")
INVPROF = ("DP-240", "Investor Profile")
CLIREST = ("DP-240", "Client Restriction")
DEATH = ("DP-240", "Death Notification")
ACCT = ("DP-093", "Account")
ENROLL = ("DP-093", "Program Enrollment")
ACCTAGMT = ("DP-093", "Account Agreement")
ADVISOR = ("DP-009", "Employee")
EMP = ("DP-192", "Employee")
OFFER = ("DP-004", "Service Offering")
MODELPF = ("DP-004", "Model Portfolio")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
OFSL = ("DP-004", "Offering Fee Schedule Link")
INSTR = ("DP-097", "Instrument")
BMK = ("DP-097", "Benchmark")
MODEL = ("DP-212", "Model")
CONTRACT = ("DP-213", "Contract")
LE = ("DP-013", "Internal Legal Entity")
PORT = ("DP-140", "Portfolio")
MANDATE = ("DP-140", "Investment Mandate")
# conformed sources inside this group
CMA = ("DP-530", "Capital Market Assumption Set")
TAS = ("DP-530", "Target Allocation Set")
SADV = ("DP-306", "Sub-Adviser Engagement")
ADENG = ("DP-303", "Advice Engagement")

GAP6 = ("Model gap (taxonomy, GAP6 of the spec): the one-to-one sub-object folded here carries no key or parent reference "
        "of its own, so it sits on its parent's row by the registry's fold rule and its join is implicit.")


MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-303": dict(
        style="ER",
        entities=[
            ent("Advice Engagement", [("45", "Advice Engagement")], ["Advice Engagement ID"],
                grain="one row = advice engagement (ADENG-) x SCD type 2 status period",
                note="The conformed Advice Engagement of the WP2 set: the advice relationship the funnel, supervision, fee "
                     "billing (DP-305 Billed Advice Engagement) and the advice star count once. Delivery channel (digital or "
                     "human) is an attribute, not a separate record (CW-044). PII tier: financial."),
            ent("Engagement Participant", [("45", "Engagement Participant")],
                ["Participant Engagement", "Participant Party", "Engagement Participant Role", "Participant Effective From"],
                grain="one row = engagement x participant party x participant role x effective period",
                note="Associative entity between an engagement and the 02 parties it serves (primary client, joint client, "
                     "decision maker); effective dated so the primary-client test is as of a date. PII tier: identity."),
            ent("Advice Review", [("45", "Advice Review")], ["Advice Review ID"],
                grain="one row = advice review (AVREV-), including the Rule 3a-4 annual contact",
                note="A review confirms or creates a 02 investor profile version (45 SME 4); Reviewed Program Enrollments is a "
                     "multi reference drawn as M:N. PII tier: financial."),
            ent("Financial Goal", [("45", "Financial Goal")], ["Financial Goal ID"],
                grain="one row = financial goal (FGOAL-) x SCD type 2 status period",
                note="Goal Owner is a 02 party or a Client Household (PTY-HH-); a household goal counts once at household "
                     "grain and never also at member grain. PII tier: financial."),
            ent("Financial Plan", [("45", "Client Financial Plan")], ["Client Financial Plan ID"],
                grain="one row = client financial plan (FPLAN-) x SCD type 2 status period",
                note="The conformed Financial Plan of the WP2 set (45 Client Financial Plan); versions are a child entity "
                     "because a plan is re-presented and each version is locked once accepted. PII tier: financial."),
            ent("Financial Plan Version", [("45", "Client Financial Plan Version")], ["Client Financial Plan Version ID"],
                grain="one row = client financial plan version",
                note="Carries the profile version, planning engine and assumption set the version relied on, so plan "
                     "currency and inactive-assumption tests read one row. PII tier: financial."),
            ent("Planning Assumption Set", [("45", "Planning Assumption Set")], ["Assumption Set Code"],
                grain="one row = planning assumption set (house assumptions) x effective period",
                note="Firm house assumptions; links the plan to the DP-530 capital market assumption set it uses. No PII."),
            ent("Planning Scenario", [("45", "Planning Scenario")], ["Planning Scenario ID"],
                grain="one row = planning scenario run on a plan version",
                note="Scenarios are run on a version, not on the plan, so a version's accepted scenario is a row here. "
                     "PII tier: financial."),
            ent("Recommendation", [("45", "Recommendation"), ("45", "Recommendation Rationale")], ["Recommendation ID"],
                measures=True,
                grain="one row = recommendation (RECOM-) x client x presented timestamp",
                note="The conformed Recommendation of the WP2 set and the product's grain, so it holds the measures. "
                     "The rationale group has one row per recommendation and folds here; a recommendation is locked once "
                     "Client Decision is not Pending. Recommendation Accounts is a multi reference drawn as M:N to Client "
                     "Account. PII tier: financial. " + GAP6),
            ent("Recommendation Alternative", [("45", "Recommendation Alternative")],
                ["Alternative Recommendation", "Alternative Number"],
                grain="one row = recommendation x alternative considered",
                note="Repeating detail of the care obligation (alternatives and their cost). PII tier: financial."),
            ent("Best Interest Evidence", [("45", "Best Interest Evidence")],
                ["Evidence Recommendation", "Best Interest Component"],
                grain="one row = recommendation x best interest component",
                note="Component-level best-interest (Reg BI, Rule 15l-1) evidence; the evidence gap flag is DP-334's, "
                     "computed from these rows. PII tier: financial."),
            ent("Recommendation Implementation Link", [("45", "Recommendation Implementation Link")],
                ["Implemented Recommendation", "Implementing Record Type", "Implementing Enrollment", "Implementing Account",
                 "Implementing Model Assignment", "Implementing Client Order"],
                grain="one row = recommendation x implementing record (enrollment, account, model assignment or client order)",
                note="Polymorphic link: one implementing key is set per Implementing Record Type and the rest are blank. "
                     "Model gap: the registry key also names Implementing Distribution, which the spec does not read, so "
                     "the key here omits it and a distribution-implemented recommendation cannot be told apart by key; "
                     "add the attribute to the spec inputs or confirm the narrower key. No PII (keys only)."),
            ent("Rollover Analysis", [("45", "Rollover Analysis"), ("45", "PTE 2020-02 Documentation")],
                ["Rollover Analysis ID"],
                grain="one row = rollover analysis (ROLV-) with its PTE 2020-02 documentation",
                note="The PTE 2020-02 documentation group has one row per analysis and folds here, so DP-335 reads the "
                     "analysis and its delivery evidence on one row. Source Retirement Plan stays an external key (DP-094 "
                     "is not upstream). PII tier: financial. " + GAP6),
            conf("Capital Market Assumption Set", CMA, [("24", "Capital Market Assumption Set")],
                 note="Conformed from DP-530; read for Plan Versions on Inactive Assumptions. No PII."),
            conf("Party", PARTY, [("02", "Party")],
                 note="Conformed from DP-240: the client, joint participant, goal owner or plan subject, an individual or a "
                      "Client Household party (Party Type = Household, CW-005). PII tier: identity."),
            conf("Household Membership", HHMEM,
                 note="Conformed from DP-240 and used only for the rollup rule: an individual's rows roll up to the "
                      "household through the membership effective on the as-of date (many-to-many, effective dated). "
                      "PII tier: identity."),
            conf("Investor Profile", INVPROF, [("02", "Investor Profile")],
                 note="Conformed from DP-240; the profile version a recommendation, plan version or review relied on. "
                      "PII tier: financial."),
            conf("Advisor", ADVISOR, [("03", "Advisor")],
                 note="Conformed from DP-009 (20 Employee with 03 Advisor), which the spec names as the Advisor source; "
                      "the engagement and recommending advisor. PII tier: identity (employee)."),
            conf("Employee", EMP,
                 note="Conformed from DP-192: preparers, reviewers and attesters, who need not be advisors. PII tier: "
                      "identity (employee)."),
            conf("Client Account", ACCT,
                 note="Conformed from DP-093; recommended and implementing accounts. PII tier: financial."),
            conf("Program Enrollment", ENROLL,
                 note="Conformed from DP-093; reviewed and implementing enrollments. PII tier: financial."),
            conf("Account Agreement", ACCTAGMT,
                 note="Conformed from DP-093; the advisory agreement an engagement operates under."),
            conf("Offering", OFFER,
                 note="Conformed from DP-004 (01 Service Offering): the engaged and recommended service offering."),
            conf("Model Portfolio", MODELPF, note="Conformed from DP-004; the recommended model."),
            conf("Share Class", SHARE, note="Conformed from DP-004; the recommended share class."),
            conf("Instrument", INSTR, note="Conformed from DP-097; the recommended security."),
            conf("Model", MODEL,
                 note="Conformed from DP-212 (37 Model Inventory Entry): the planning, projection and recommendation "
                      "engines."),
        ],
        relationships=[
            rel("Advice Engagement", "Party", ["Engagement Client"]),
            rel("Advice Engagement", "Advisor", ["Engagement Advisor"], optional=True,
                note="Blank for a digital-only engagement."),
            rel("Advice Engagement", "Offering", ["Engagement Service Offering"]),
            rel("Advice Engagement", "Account Agreement", ["Engagement Advisory Agreement"], optional=True),
            rel("Engagement Participant", "Advice Engagement", ["Participant Engagement"]),
            rel("Engagement Participant", "Party", ["Participant Party"]),
            rel("Advice Review", "Advice Engagement", ["Reviewed Engagement"]),
            rel("Advice Review", "Program Enrollment", ["Reviewed Program Enrollments"], card="M:N", optional=True,
                note="Multi reference: one review can cover several enrollments."),
            rel("Advice Review", "Employee", ["Review Conducted By"], optional=True),
            rel("Advice Review", "Investor Profile", ["Profile Version Confirmed"], optional=True),
            rel("Financial Goal", "Party", ["Goal Owner"]),
            rel("Financial Goal", "Advice Engagement", ["Goal Source Engagement"], optional=True),
            rel("Financial Plan", "Party", ["Plan Subject"]),
            rel("Financial Plan", "Advice Engagement", ["Plan Engagement"], optional=True),
            rel("Financial Plan Version", "Financial Plan", ["Versioned Plan"]),
            rel("Financial Plan Version", "Employee", ["Plan Preparer"], optional=True),
            rel("Financial Plan Version", "Investor Profile", ["Plan Profile Version Relied On"]),
            rel("Financial Plan Version", "Model", ["Planning Engine"], optional=True,
                note="Single reference to the composite Model key (Model ID x Model Version); the version is the one "
                     "in production on Plan Data As-Of Date."),
            rel("Financial Plan Version", "Planning Assumption Set", ["Version Assumption Set"]),
            rel("Planning Assumption Set", "Capital Market Assumption Set", ["Capital Market Assumption Set"],
                optional=True,
                note="Single reference to the composite CMA key (ID x CMA Set Version); the version effective on the "
                     "assumption set's effective date."),
            rel("Planning Scenario", "Financial Plan Version", ["Scenario Plan Version"]),
            rel("Planning Scenario", "Planning Assumption Set", ["Scenario Assumption Set"], optional=True),
            rel("Planning Scenario", "Model", ["Projection Engine"], optional=True),
            rel("Recommendation", "Advisor", ["Recommending Advisor"], optional=True,
                note="Blank for a digital recommendation, which names the Recommendation Engine instead."),
            rel("Recommendation", "Model", ["Recommendation Engine"], optional=True),
            rel("Recommendation", "Party", ["Recommended Client"]),
            rel("Recommendation", "Client Account", ["Recommendation Accounts"], card="M:N", optional=True,
                note="Multi reference: a recommendation can cover several accounts."),
            rel("Recommendation", "Advice Engagement", ["Recommendation Engagement"], optional=True),
            rel("Recommendation", "Investor Profile", ["Recommendation Profile Version"]),
            rel("Recommendation", "Financial Plan Version", ["Supporting Plan Version"], optional=True),
            rel("Recommendation", "Rollover Analysis", ["Supporting Rollover Analysis"], optional=True,
                note="Both directions are recorded (Rollover Analysis.Rollover Recommendation), by design; Rollover "
                     "Recommendations Without Analysis tests both."),
            rel("Recommendation", "Offering", ["Recommended Service Offering"], optional=True),
            rel("Recommendation", "Model Portfolio", ["Recommended Model Portfolio"], optional=True),
            rel("Recommendation", "Share Class", ["Recommended Share Class"], optional=True),
            rel("Recommendation", "Instrument", ["Recommended Instrument"], optional=True),
            rel("Recommendation Alternative", "Recommendation", ["Alternative Recommendation"]),
            rel("Best Interest Evidence", "Recommendation", ["Evidence Recommendation"]),
            rel("Best Interest Evidence", "Employee", ["Evidence Attester"], optional=True),
            rel("Recommendation Implementation Link", "Recommendation", ["Implemented Recommendation"]),
            rel("Recommendation Implementation Link", "Program Enrollment", ["Implementing Enrollment"], optional=True),
            rel("Recommendation Implementation Link", "Client Account", ["Implementing Account"], optional=True),
            rel("Rollover Analysis", "Recommendation", ["Rollover Recommendation"]),
            rel("Rollover Analysis", "Employee", ["Attesting Employee"], optional=True),
            rel("Investor Profile", "Party", ["Profile Client"]),
            rel("Household Membership", "Party", ["Household"], note="The household party (PTY-HH-)."),
            rel("Household Membership", "Party", ["Household Member"], note="The member party."),
            rel("Advisor", "Employee", ["Employee"], card="1:1", note="03 Advisor is a role profile of the 20 employee."),
        ],
        notes=("Foundational ER model of the advice record (45). Published for conforming: Advice Engagement, Financial Plan "
               "(45 Client Financial Plan) and Recommendation; Financial Plan Version, Financial Goal, Advice Review and "
               "Rollover Analysis are also available. The Recommendation entity holds the measures because the grain line "
               "is the recommendation. Rollup rule: rows owned by a Client Household party are counted at household grain "
               "only; individual rows roll up through the conformed DP-240 Household Membership. PII tier: financial "
               "(identity for participants and parties); special-category planning data (45 Client Planning Assumptions, "
               "Healthcare Expense cash flows) is not read (CD-344), and Protection Flag Present is not carried because "
               "DP-322 is consumer-aligned. "
               "External references (resolved by joining to the named product): Implementing Model Assignment (46, DP-304) "
               "and Implementing Client Order (48, DP-430) on Recommendation Implementation Link, which are downstream of "
               "this product (they list DP-303 or would form a cycle); Source Retirement Plan (02 Retirement Plan, DP-094, "
               "not upstream). "
               "Model gap: Recommendation Implementation Link key without Implementing Distribution (see the entity note).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-304": dict(
        style="ER",
        entities=[
            ent("Model Assignment", [("46", "Model Assignment"), ("46", "Tax Management Setting")], ["Model Assignment ID"],
                measures=True,
                grain="one row = managed account x model assignment x assignment period (SCD type 2)",
                note="The conformed Model Assignment of the WP2 set and the product's grain, so it holds the measures. "
                     "The tax management settings have one row per assignment and fold here. Previous Model Assignment "
                     "chains model changes. PII tier: financial. " + GAP6),
            ent("Sleeve Assignment", [("46", "Sleeve Assignment")],
                ["Sleeve Model Assignment", "Sleeve Sequence", "Sleeve Effective From"],
                grain="one row = model assignment x sleeve x effective period",
                note="Multi-manager and multi-model accounts; a sleeve may be run by a DP-306 sub-adviser engagement. "
                     "PII tier: financial."),
            ent("Household Managed Group", [("46", "Household Managed Group")],
                ["Managed Group Household", "Group Member Account", "Group Effective From"],
                grain="one row = household x member account x effective period",
                note="The managed-together association of a household's accounts (household-level asset location and wash "
                     "sale control); many-to-many and effective dated, so it is an associative entity, never a column on "
                     "the account. PII tier: financial."),
            ent("Managed Account Target", [("46", "Managed Account Target")],
                ["Target Model Assignment", "Account Target Version"],
                grain="one row = model assignment x account target version",
                note="The account's applied target, either the DP-530 model target set or a custom target. PII tier: "
                     "financial."),
            ent("Account Target Override Line", [("46", "Account Target Override Line")],
                ["Override Account Target", "Override Asset Class", "Override Instrument"],
                grain="one row = account target version x overridden asset class or instrument",
                note="Repeating override lines of a custom target. PII tier: financial."),
            ent("Account Investment Constraint", [("46", "Account Investment Constraint")],
                ["Constrained Account", "Source Client Restriction", "Source Trust Term Provision", "Constraint Type",
                 "Constraint Effective From"],
                grain="one row = account x constraint source x constraint type x effective period",
                note="Implements a 02 client restriction or a 51 trust term provision; exactly one source key is set and "
                     "the other is blank. PII tier: financial."),
            ent("Drift Assessment", [("46", "Drift Assessment")], ["Drift Assessment ID"],
                grain="one row = account x assessment timestamp",
                note="Drift is assessed against the account target, not against a holding fact: Holdings As-Of Timestamp "
                     "records which 49 snapshot was used without joining it (CW-007). PII tier: financial."),
            ent("Rebalance Run", [("46", "Trade Proposal Batch")], ["Batch ID"],
                grain="one row = trade proposal batch (rebalance run) x program x cycle date",
                note="The conformed Rebalance Run of the WP2 set is the 46 Trade Proposal Batch: one rebalancing cycle of "
                     "a program whose proposals are released together. No PII."),
            ent("Trade Proposal", [("46", "Trade Proposal")], ["Trade Proposal ID"],
                grain="one row = batch x account x instrument x side",
                note="Released proposals become 48 client orders or 16 participant investment transfers (external keys). "
                     "PII tier: financial."),
            ent("Tax-Loss Harvest Decision", [("46", "Tax-Loss Harvest Decision")], ["Harvest Decision ID"],
                grain="one row = account x harvest scan x security sold",
                note="Harvest Client Tax Lots is a key into DP-300 (49 Client Tax Lot), never joined to an 18 tax lot. "
                     "PII tier: financial."),
            ent("Wash Sale Control Window", [("46", "Wash Sale Control Window")],
                ["Window Household", "Window Account", "Window Security Group", "Window Start Date"],
                grain="one row = household or account x substantially identical security group x window start",
                note="Controlled and monitored accounts are multi references drawn as M:N. Model gap: Window Security Group "
                     "points to 46 Substantially Identical Security Group, which the spec does not read, so it stays an "
                     "attribute in the key. PII tier: financial."),
            ent("Managed Account Composite", [("46", "Managed Account Composite")], ["Managed Account Composite ID"],
                grain="one row = managed account composite",
                note="Program-level composite for performance; Linked GIPS Composite (01) is an external key. No PII."),
            ent("Managed Account Composite Membership", [("46", "Managed Account Composite Membership")],
                ["Membership Composite", "Member Account", "Membership Start Date"],
                grain="one row = composite x member account x membership period",
                note="Associative entity between composites and accounts, tied to the assignment that qualified the "
                     "account. PII tier: financial."),
            conf("Program Enrollment", ENROLL, [("15", "Program Enrollment")],
                 note="Conformed from DP-093; the advisory program enrollment the assignment serves. PII tier: financial."),
            conf("Program", OFFER, [("01", "Service Offering")],
                 note="The conformed Program of the WP2 set: the advisory program (01 Service Offering, conformed from "
                      "DP-004) read here as an input for discretion type, wrap fee and model use; this product publishes "
                      "it because it is where the program object is read."),
            conf("Model Portfolio", MODELPF, [("01", "Model Portfolio")],
                 note="Conformed from DP-004; the assigned, sleeve and composite model."),
            conf("Target Allocation Set", TAS, [("24", "Target Allocation Set")],
                 note="Conformed from DP-530; the model target set an account target applies."),
            conf("Client Account", ACCT,
                 note="Conformed from DP-093; the managed account. PII tier: financial."),
            conf("Household", PARTY,
                 note="Conformed from DP-240 Party under the role name Household (PTY-HH-): the managed group and wash sale "
                      "window household. PII tier: identity."),
            conf("Client Restriction", CLIREST,
                 note="Conformed from DP-240; the restriction a constraint implements. PII tier: financial."),
            conf("Instrument", INSTR, note="Conformed from DP-097; proposal, override and harvest securities."),
            conf("Sub-Adviser Engagement", SADV,
                 note="Conformed from DP-306; the sub-adviser running a sleeve."),
        ],
        relationships=[
            rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
            rel("Program Enrollment", "Program", ["Enrolled Service Offering"]),
            rel("Model Assignment", "Client Account", ["Assigned Account"]),
            rel("Model Assignment", "Program Enrollment", ["Assignment Program Enrollment"]),
            rel("Model Assignment", "Model Portfolio", ["Assigned Model Portfolio"]),
            rel("Model Assignment", "Model Assignment", ["Previous Model Assignment"], optional=True,
                note="Model change chain."),
            rel("Sleeve Assignment", "Model Assignment", ["Sleeve Model Assignment"]),
            rel("Sleeve Assignment", "Model Portfolio", ["Sleeve Model Portfolio"], optional=True),
            rel("Sleeve Assignment", "Sub-Adviser Engagement", ["Sleeve Sub-Adviser Engagement"], optional=True),
            rel("Household Managed Group", "Household", ["Managed Group Household"]),
            rel("Household Managed Group", "Client Account", ["Group Member Account"]),
            rel("Managed Account Target", "Model Assignment", ["Target Model Assignment"]),
            rel("Managed Account Target", "Target Allocation Set", ["Applied Model Target Set"], optional=True,
                note="Blank for a fully custom target."),
            rel("Account Target Override Line", "Managed Account Target", ["Override Account Target"],
                note="Single reference to the composite target key (assignment x version)."),
            rel("Account Target Override Line", "Instrument", ["Override Instrument"], optional=True),
            rel("Account Investment Constraint", "Client Account", ["Constrained Account"]),
            rel("Account Investment Constraint", "Client Restriction", ["Source Client Restriction"], optional=True),
            rel("Drift Assessment", "Client Account", ["Assessed Account"]),
            rel("Drift Assessment", "Managed Account Target", ["Assessed Account Target"],
                note="Single reference to the composite target key."),
            rel("Rebalance Run", "Program", ["Batch Program"]),
            rel("Trade Proposal", "Rebalance Run", ["Proposal Batch"]),
            rel("Trade Proposal", "Client Account", ["Proposal Account"]),
            rel("Trade Proposal", "Instrument", ["Proposal Instrument"]),
            rel("Tax-Loss Harvest Decision", "Client Account", ["Harvest Account"]),
            rel("Tax-Loss Harvest Decision", "Instrument", ["Security Sold"]),
            rel("Tax-Loss Harvest Decision", "Instrument", ["Replacement Security"], optional=True),
            rel("Tax-Loss Harvest Decision", "Wash Sale Control Window", ["Resulting Wash Sale Window"], optional=True,
                note="Single reference to the composite window key."),
            rel("Wash Sale Control Window", "Household", ["Window Household"], optional=True,
                note="Set when the window is controlled at household grain; Window Account otherwise."),
            rel("Wash Sale Control Window", "Client Account", ["Window Account"], optional=True),
            rel("Wash Sale Control Window", "Tax-Loss Harvest Decision", ["Triggering Harvest Decision"], optional=True),
            rel("Wash Sale Control Window", "Client Account", ["Controlled Accounts in Scope"], card="M:N",
                note="Multi reference."),
            rel("Wash Sale Control Window", "Client Account", ["Monitored Accounts in Scope"], card="M:N", optional=True,
                note="Multi reference."),
            rel("Managed Account Composite", "Program", ["Composite Program"]),
            rel("Managed Account Composite", "Model Portfolio", ["Composite Model Portfolio"], optional=True),
            rel("Managed Account Composite Membership", "Managed Account Composite", ["Membership Composite"]),
            rel("Managed Account Composite Membership", "Client Account", ["Member Account"]),
            rel("Managed Account Composite Membership", "Model Assignment", ["Membership Model Assignment"],
                optional=True),
            rel("Target Allocation Set", "Model Portfolio", ["Target Model Portfolio"]),
            rel("Program", "Model Portfolio", ["Model Portfolios Used"], card="M:N", optional=True,
                note="Multi reference: the models a program uses."),
        ],
        notes=("Foundational ER model of managed accounts (46). Published for conforming: Model Assignment, Model Portfolio "
               "(as conformed from DP-004), Rebalance Run (46 Trade Proposal Batch) and Program (01 Service Offering as "
               "the advisory program; this is the product that reads the program object, DP-305 conforms Program "
               "from DP-004 without reading it). Model Assignment holds the measures because the grain line is the "
               "assignment. PII tier: financial (Rebalance Run and Managed Account Composite: no PII). Three books "
               "(CW-007): no holding entity is modeled; drift and harvest rows carry keys into DP-300 only. "
               "External references (resolved by joining to the named product): Source Recommendation (45, DP-303), "
               "Source Trust Term Provision (51, DP-307), Released Client Order (48, DP-430), Released Participant "
               "Investment Transfer (16), Harvest Client Tax Lots (49, DP-300), Linked GIPS Composite (01), Assignment "
               "Approved By (20 Employee; neither DP-192 nor DP-009 is upstream). "
               "Model gap (missing upstream): Model Assignment.Source Recommendation keys into DP-303, which is not in "
               "this product's upstream; DP-303 does not list DP-304, so adding it would not make a cycle. "
               "Model gap: Window Security Group (46 Substantially Identical Security Group) is not a spec input.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-305": dict(
        style="ER",
        entities=[
            ent("Fee Schedule", [("47", "Fee Schedule"), ("47", "Performance Fee Terms")], ["Fee Schedule ID"],
                grain="one row = fee schedule version",
                note="The conformed Fee Schedule of the WP2 set. Each version is its own row (Superseded Schedule Version "
                     "chains them); performance fee terms have one row per version and fold here. No PII. " + GAP6),
            ent("Fee Schedule Tier", [("47", "Fee Schedule Tier")], ["Tier Fee Schedule", "Tier Sequence"],
                grain="one row = fee schedule version x tier", note="Breakpoint tiers of a schedule version. No PII."),
            ent("Fee Schedule Assignment", [("47", "Fee Schedule Assignment")], ["Fee Schedule Assignment ID"],
                grain="one row = fee schedule assignment x effective period (SCD type 2)",
                note="The conformed Fee Schedule Assignment of the WP2 set: which schedule bills an enrollment, account or "
                     "advice engagement and which account pays. PII tier: financial."),
            ent("Fee Rate Override", [("47", "Fee Rate Override")], ["Overridden Assignment", "Override Effective From"],
                grain="one row = assignment x override effective period",
                note="Negotiated rate of one assignment. PII tier: financial."),
            ent("Billing Arrangement", [("47", "Billing Arrangement")], ["Billing Arrangement ID"],
                grain="one row = institutional or separately managed billing arrangement x effective period",
                note="The mandate billing path, beside the account assignment path. Billed Mandate stays an external key "
                     "(01 Investment Mandate is not yet on DP-004, CD-322, and DP-140 is not upstream). PII tier: "
                     "financial where the client is an individual."),
            ent("Fee Household", [("47", "Fee Household")], ["Fee Household ID"],
                grain="one row = fee household x effective period",
                note="The billing household used for breakpoint aggregation; anchored on a 02 Client Household but kept "
                     "separate because its membership follows billing rules. PII tier: financial."),
            ent("Fee Household Membership", [("47", "Fee Household Membership")],
                ["Membership Fee Household", "Member Account", "Fee Household Membership Effective From"],
                grain="one row = fee household x member account x effective period",
                note="Household-to-account association, many-to-many and effective dated, never a column on the account. "
                     "PII tier: financial."),
            ent("Fee Waiver", [("47", "Fee Waiver")], ["Fee Waiver ID"],
                grain="one row = fee waiver", note="PII tier: financial."),
            ent("Fee Run", [("47", "Fee Calculation Run")], ["Fee Calculation Run ID"],
                grain="one row = fee calculation run",
                note="The conformed Fee Run of the WP2 set (47 Fee Calculation Run), with its reconciliation status "
                     "(acceptance question 8). No PII (run control totals only)."),
            ent("Account Fee Calculation", [("47", "Account Fee Calculation")],
                ["Calculation Run", "Calculated Assignment", "Calculated Billing Arrangement"], measures=True,
                grain="one row = fee calculation run x billed subject (fee schedule assignment or billing arrangement)",
                note="The product's grain, so it holds the measures. Exactly one of Calculated Assignment and Calculated "
                     "Billing Arrangement is set; the other key part is blank. Billed fees are operational; client fee "
                     "revenue is DP-012's (CW-214). PII tier: financial."),
            ent("Fee Debit", [("47", "Fee Debit")], ["Fee Debit ID"],
                grain="one row = fee debit against an account",
                note="Debit Posting is a key into DP-300 (49 Client Account Activity). PII tier: financial."),
            ent("Fee Invoice", [("47", "Fee Invoice")], ["Invoice ID"],
                grain="one row = fee invoice",
                note="The conformed Fee Invoice of the WP2 set: the invoice path for billing arrangements and invoiced "
                     "assignments. PII tier: financial."),
            ent("Fee Adjustment", [("47", "Fee Adjustment")], ["Fee Adjustment ID"],
                grain="one row = fee adjustment",
                note="Credit Posting is a key into DP-300. PII tier: financial where the client is an individual."),
            ent("Billing Dispute", [("47", "Billing Dispute")], ["Billing Dispute ID"],
                grain="one row = billing dispute",
                note="Related Complaint (08) is an external key. PII tier: financial."),
            ent("Fee Deduction Authorization", [("47", "Fee Deduction Authorization")],
                ["Authorized Account", "Authorizing Agreement"],
                grain="one row = account x authorizing agreement",
                note="Custody rule evidence for direct fee deduction. PII tier: financial."),
            ent("Fee Disclosure Delivery", [("47", "Fee Disclosure Delivery")],
                ["Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type", "Disclosed Fee Schedule",
                 "Fee Disclosure Delivered Date"],
                grain="one row = recipient x account x disclosure type x fee schedule x delivered date",
                note="PII tier: identity."),
            conf("Offering Fee Schedule Link", OFSL, [("01", "Offering Fee Schedule Link")],
                 note="Conformed from DP-004; the schedule a program prescribes, used for Assignments Off Offering "
                      "Schedule."),
            conf("Program Enrollment", ENROLL, [("15", "Program Enrollment")],
                 note="Conformed from DP-093; the billed enrollment. PII tier: financial."),
            conf("Program", OFFER,
                 note="Conformed from DP-004 (01 Service Offering) as the advisory program; not read as an input here, "
                      "so the Program dimension consumers conform is DP-304's."),
            conf("Client Account", ACCT, note="Conformed from DP-093. PII tier: financial."),
            conf("Household", PARTY,
                 note="Conformed from DP-240 Party under the role name Household (PTY-HH-): the fee household's anchor. "
                      "PII tier: identity."),
            conf("Party", PARTY,
                 note="Conformed from DP-240: bill-to parties and disclosure recipients. PII tier: identity."),
            conf("Advice Engagement", ADENG,
                 note="Conformed from DP-303; an engagement billed under a planning fee."),
            conf("Account Agreement", ACCTAGMT, note="Conformed from DP-093; the agreement authorizing fee deduction."),
            conf("Employee", EMP, note="Conformed from DP-192; approvers. PII tier: identity (employee)."),
            conf("Internal Legal Entity", LE, note="Conformed from DP-013; the qualified custodian."),
        ],
        relationships=[
            rel("Fee Schedule", "Fee Schedule", ["Superseded Schedule Version"], optional=True, note="Version chain."),
            rel("Fee Schedule Tier", "Fee Schedule", ["Tier Fee Schedule"]),
            rel("Fee Schedule Assignment", "Fee Schedule", ["Assigned Fee Schedule"]),
            rel("Fee Schedule Assignment", "Program Enrollment", ["Billed Enrollment"], optional=True),
            rel("Fee Schedule Assignment", "Client Account", ["Billed Account"], optional=True),
            rel("Fee Schedule Assignment", "Advice Engagement", ["Billed Advice Engagement"], optional=True,
                note="One billed subject is set per assignment."),
            rel("Fee Schedule Assignment", "Client Account", ["Fee-Paying Account"], optional=True),
            rel("Fee Schedule Assignment", "Fee Household", ["Assigned Fee Household"], optional=True),
            rel("Fee Rate Override", "Fee Schedule Assignment", ["Overridden Assignment"]),
            rel("Fee Rate Override", "Employee", ["Override Approved By"], optional=True),
            rel("Billing Arrangement", "Party", ["Bill-To Party"]),
            rel("Billing Arrangement", "Fee Schedule", ["Applied Fee Schedule"]),
            rel("Fee Household", "Household", ["Anchor Client Household"], optional=True),
            rel("Fee Household Membership", "Fee Household", ["Membership Fee Household"]),
            rel("Fee Household Membership", "Client Account", ["Member Account"]),
            rel("Fee Waiver", "Fee Schedule Assignment", ["Waived Assignment"], optional=True),
            rel("Fee Waiver", "Billing Arrangement", ["Waived Billing Arrangement"], optional=True),
            rel("Fee Waiver", "Employee", ["Waiver Approved By"], optional=True),
            rel("Fee Run", "Employee", ["Run Approved By"], optional=True),
            rel("Account Fee Calculation", "Fee Run", ["Calculation Run"]),
            rel("Account Fee Calculation", "Fee Schedule Assignment", ["Calculated Assignment"], optional=True),
            rel("Account Fee Calculation", "Billing Arrangement", ["Calculated Billing Arrangement"], optional=True),
            rel("Account Fee Calculation", "Fee Schedule", ["Schedule Version Applied"]),
            rel("Fee Debit", "Account Fee Calculation", ["Debited Calculation"],
                note="Single reference to the composite calculation key (run x billed subject)."),
            rel("Fee Debit", "Client Account", ["Debited Account"]),
            rel("Fee Invoice", "Billing Arrangement", ["Invoice Billing Arrangement"], optional=True),
            rel("Fee Invoice", "Fee Schedule Assignment", ["Invoice Fee Schedule Assignment"], optional=True),
            rel("Fee Invoice", "Party", ["Invoice Bill-To Party"]),
            rel("Fee Adjustment", "Fee Invoice", ["Adjusted Invoice"], optional=True),
            rel("Fee Adjustment", "Account Fee Calculation", ["Adjusted Fee Calculation"], optional=True),
            rel("Fee Adjustment", "Fee Waiver", ["Applied Fee Waiver"], optional=True),
            rel("Fee Adjustment", "Billing Dispute", ["Related Billing Dispute"], optional=True),
            rel("Fee Adjustment", "Employee", ["Adjustment Approved By"], optional=True),
            rel("Billing Dispute", "Fee Invoice", ["Disputed Invoice"], optional=True),
            rel("Billing Dispute", "Account Fee Calculation", ["Disputed Fee Calculation"], optional=True),
            rel("Fee Deduction Authorization", "Client Account", ["Authorized Account"]),
            rel("Fee Deduction Authorization", "Account Agreement", ["Authorizing Agreement"]),
            rel("Fee Deduction Authorization", "Client Account", ["Authorized Fee-Paying Account"], optional=True),
            rel("Fee Deduction Authorization", "Internal Legal Entity", ["Qualified Custodian"], optional=True),
            rel("Fee Disclosure Delivery", "Party", ["Fee Disclosure Recipient"]),
            rel("Fee Disclosure Delivery", "Client Account", ["Fee Disclosure Account"], optional=True),
            rel("Fee Disclosure Delivery", "Fee Schedule", ["Disclosed Fee Schedule"]),
            rel("Fee Disclosure Delivery", "Program Enrollment", ["Related Program Enrollment"], optional=True),
            rel("Offering Fee Schedule Link", "Program", ["Linked Offering"]),
            rel("Offering Fee Schedule Link", "Fee Schedule", ["Linked Fee Schedule"]),
            rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
            rel("Program Enrollment", "Program", ["Enrolled Service Offering"]),
        ],
        notes=("Foundational ER model of advisory fees and billing (47). Published for conforming: Fee Schedule, Fee Schedule "
               "Assignment, Fee Run (47 Fee Calculation Run) and Fee Invoice; Account Fee Calculation and Fee Debit are also "
               "available. Account Fee Calculation holds the measures because the grain line is the account fee "
               "calculation. Two billing paths are modeled side by side (assignment for accounts, enrollments and "
               "engagements; billing arrangement for mandates) and meet at the calculation. Fee Household is the billing "
               "household, distinct from but anchored on the 02 Client Household. PII tier: financial (schedules, tiers "
               "and runs: no PII; disclosure deliveries: identity). "
               "External references (resolved by joining to the named product): Debit Posting and Credit Posting (49 Client "
               "Account Activity, DP-300; kept as keys because DP-300's model is being written by a sibling group and its "
               "entity name is not yet published), Billed Mandate (01 Investment Mandate; DP-140 not upstream, CD-322), "
               "Related Complaint (08).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-306": dict(
        style="ER",
        entities=[
            ent("Manager", [("52", "External Manager Profile")], ["Profiled Manager"],
                grain="one row = external manager (02 party) x profile period",
                note="The conformed Manager of the WP2 set: the external manager or sub-adviser, keyed by its 02 party "
                     "(PTY-) because the profile is a role profile of the party (CW-116). No PII (organization data)."),
            ent("Manager Key Person", [("52", "Manager Key Person")],
                ["Key Person Manager", "Key Person", "Key Person Role", "Role Start Date"],
                grain="one row = manager x key person x role x role period",
                note="PII tier: identity (professional data about an individual); published only in the Confidential - "
                     "Personal Data view."),
            ent("External Manager Strategy", [("52", "External Manager Strategy")], ["External Manager Strategy ID"],
                grain="one row = external manager strategy (EMSTR-)", note="No PII."),
            ent("Sub-Adviser Engagement", [("52", "Sub-Adviser Engagement"), ("52", "Manager-of-Managers Hire Condition")],
                ["Sub-Adviser Engagement ID"], measures=True,
                grain="one row = sub-adviser x fund or mandate x sleeve x engagement period (SADV-)",
                note="The product's grain, so it holds the measures. The manager-of-managers hire condition has one row per "
                     "engagement and folds here. Exactly one of Engaged Fund and Delegated Mandate is set. No PII. "
                     + GAP6),
            ent("Sub-Adviser Guideline Set", [("52", "Sub-Adviser Guideline Set")], ["Guideline Set ID"],
                grain="one row = guideline set version of an engagement", note="No PII."),
            ent("Sub-Adviser Watch Status", [("52", "Sub-Adviser Watch Status")],
                ["Watched Engagement", "Watch Effective From"],
                grain="one row = engagement x watch status period", note="No PII."),
            ent("Manager Termination", [("52", "Manager Termination")],
                ["Terminated Engagement", "Termination Effective Date"],
                grain="one row = terminated engagement x termination effective date", note="No PII."),
            ent("Product Due Diligence", [("52", "Product Due Diligence")], ["Product Due Diligence ID"],
                grain="one row = third-party product due diligence review (TPDUE-)", note="No PII."),
            ent("Product List Status", [("52", "Product List Status")],
                ["Listed Instrument", "List Scope", "List Status Effective From"],
                grain="one row = instrument x list scope x status period",
                note="Published here by ruling CW-254; DP-530 holds a derived copy on Model Building Block. No PII."),
            ent("Fund Advisory Agreement", [("35", "Fund Advisory Agreement")], ["Advisory Agreement ID"],
                grain="one row = fund sub-advisory agreement",
                note="Own entity because no foundational product publishes 35 Fund Advisory Agreement (spec note); read for "
                     "agreement status only. No PII."),
            conf("Party", PARTY, [("02", "Party"), ("02", "Organization")],
                 note="Conformed from DP-240: the manager's party, key persons and the agreement's sub-adviser. PII tier: "
                      "identity for individual key persons; organizations are not personal data."),
            conf("Contract", CONTRACT, [("39", "Contract")], note="Conformed from DP-213; key and status check only."),
            conf("Instrument", INSTR, [("17", "Instrument")],
                 note="Conformed from DP-097; the listed or reviewed third-party product, key and status check only."),
            conf("Share Class", SHARE, note="Conformed from DP-004; an instrument that is the firm's own share class."),
            conf("Investment Product", PROD, note="Conformed from DP-004; the sub-advised fund."),
            conf("Investment Mandate", MANDATE, note="Conformed from DP-140; the delegated mandate."),
            conf("Portfolio", PORT, note="Conformed from DP-140; the sleeve book (the portfolio, not its holdings)."),
            conf("Internal Legal Entity", LE, note="Conformed from DP-013; the overseeing adviser entity."),
            conf("Employee", EMP, note="Conformed from DP-192; the coverage analyst. PII tier: identity (employee)."),
        ],
        relationships=[
            rel("Manager", "Party", ["Profiled Manager"], card="1:1",
                note="The profile is a role profile of the 02 party; party identity is never copied (CW-116)."),
            rel("Manager", "Employee", ["Coverage Analyst"], optional=True),
            rel("Manager Key Person", "Manager", ["Key Person Manager"]),
            rel("Manager Key Person", "Party", ["Key Person"]),
            rel("Manager Key Person", "External Manager Strategy", ["Key Person Strategies"], card="M:N", optional=True,
                note="Multi reference."),
            rel("External Manager Strategy", "Manager", ["Strategy Manager"]),
            rel("Sub-Adviser Engagement", "Manager", ["Engaged Sub-Adviser"]),
            rel("Sub-Adviser Engagement", "External Manager Strategy", ["Engaged Strategy"], optional=True),
            rel("Sub-Adviser Engagement", "Fund Advisory Agreement", ["Governing Fund Agreement"], optional=True),
            rel("Sub-Adviser Engagement", "Contract", ["Governing Contract"], optional=True),
            rel("Sub-Adviser Engagement", "Internal Legal Entity", ["Overseeing Adviser Entity"]),
            rel("Sub-Adviser Engagement", "Investment Product", ["Engaged Fund"], optional=True),
            rel("Sub-Adviser Engagement", "Investment Mandate", ["Delegated Mandate"], optional=True),
            rel("Sub-Adviser Engagement", "Portfolio", ["Sleeve Portfolio"], optional=True),
            rel("Sub-Adviser Guideline Set", "Sub-Adviser Engagement", ["Guideline Engagement"]),
            rel("Sub-Adviser Watch Status", "Sub-Adviser Engagement", ["Watched Engagement"]),
            rel("Manager Termination", "Sub-Adviser Engagement", ["Terminated Engagement"]),
            rel("Manager Termination", "Sub-Adviser Engagement", ["Replacement Engagement"], optional=True),
            rel("Product Due Diligence", "Instrument", ["Reviewed Instrument"]),
            rel("Product List Status", "Instrument", ["Listed Instrument"]),
            rel("Product List Status", "Product Due Diligence", ["Deciding Product Review"], optional=True),
            rel("Fund Advisory Agreement", "Party", ["External Sub-Adviser"]),
            rel("Instrument", "Share Class", ["Own Share Class"], optional=True,
                note="Set when the instrument is one of the firm's own share classes (Own Products on Third-Party List)."),
            rel("Share Class", "Investment Product", ["Parent Product"],
                note="Inherited from DP-004; joins the own-product check to the fund side of the model."),
        ],
        notes=("Foundational ER model of external manager and sub-adviser oversight (52). Published for conforming: Manager "
               "(52 External Manager Profile, keyed by the manager's 02 party); Sub-Adviser Engagement, External Manager "
               "Strategy and Product List Status are also available. Sub-Adviser Engagement holds the measures because the "
               "grain line is the engagement. The spec reads 35 Fund Advisory Agreement, 39 Contract and 17 Instrument as "
               "its oversight inputs (no 32 object is read). PII tier: identity (key persons only; everything else is "
               "organization data). The third-party product list (Product Due Diligence, Product List Status, Instrument) "
               "has no reference to a manager in 52, so it joins the manager side only through Instrument.Own Share Class "
               "and the share class's DP-004 parent product. "
               "External references (resolved by joining to the named product): Deciding Committee Decision (24 Investment "
               "Committee Decision, DP-530 not upstream), Relied-On Exemptive Relief (35 Exemptive Relief Reliance). "
               "Model gap: Product List Status.Deciding Oversight Review points to 52 Oversight Review, which the spec does "
               "not read (oversight reviews are DP-536's), so it stays an attribute.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-307": dict(
        style="ER",
        entities=[
            ent("Trust", [("51", "Trust")], ["Trust ID"], measures=True,
                grain="one row = trust (TRUST-) x SCD type 2 status period",
                note="The conformed Trust of the WP2 set. The trust is neither a party nor an account (CW-075): it names "
                     "its 02 party and the accounts point to it. Holds the measures because they are counted per trust "
                     "(the grain line's trust role rows are the main companion). PII tier: identity; Trust Instrument Type "
                     "is special category (CD-344) for the value Special Needs / Supplemental Needs Trust, which is "
                     "blanked in every published row. Model gap: the registry places the whole 51 Trust object in one "
                     "entity, so that one value cannot sit in a restricted child entity; it stays restricted in 51 for "
                     "DP-352's view."),
            ent("Trust Instrument Document", [("51", "Trust Instrument Document")],
                ["Instrument Trust", "Instrument Version Number"],
                grain="one row = trust x instrument document version",
                note="Repeating group of the trust (fold=False): the trust agreement, amendments and certification of "
                     "trust. PII tier: identity."),
            ent("Trust Term Provision", [("51", "Trust Term Provision")],
                ["Provision Trust", "Provision Type", "Provision Sequence", "Provision Instrument Version"],
                grain="one row = trust x provision type x sequence x instrument version",
                note="Restricted entity. PII tier: identity, special category (CD-344) where Provision Type = Special Needs "
                     "Purpose or Distribution Standard = Supplemental Needs Only; those values are blanked, never "
                     "relabeled, outside DP-352's restricted view. A 46 Account Investment Constraint reads Source Trust "
                     "Term Provision as a key."),
            ent("Trust Role", [("51", "Trust Role")],
                ["Role Trust", "Role Holder Party", "Role Holder Entity", "Trust Role Type", "Role Effective From"],
                grain="one row = trust x role holder x trust role type x role period",
                note="Trustee, co-trustee, grantor and other roles; the role holder is a 02 party or the firm's own "
                     "internal legal entity (the trust company), so one of the two holder keys is blank. PII tier: "
                     "identity."),
            ent("Beneficial Interest", [("51", "Beneficial Interest")],
                ["Interest Trust", "Beneficiary Party", "Beneficial Interest Type", "Interest Effective From"],
                grain="one row = trust x beneficiary x interest type x effective period",
                note="PII tier: financial (a beneficiary's entitlement) and identity."),
            ent("Trust Distribution Request", [("51", "Trust Distribution Request")], ["Distribution Request ID"],
                grain="one row = trust distribution request (TDRQ-)",
                note="Restricted entity. PII tier: special category (CD-344) where the purpose is medical, disability or "
                     "hardship, otherwise financial. Requests with a special-category Distribution Purpose are absent from "
                     "every published row and aggregate, and Distribution Purpose itself is never published (DQ rule); "
                     "DP-352 is the only restricted view of purposes and decisions (CW-213)."),
            ent("Fiduciary Account Review", [("51", "Fiduciary Account Review")], ["Fiduciary Review ID"],
                grain="one row = fiduciary account review (FIRV-, 12 CFR 9.6)",
                note="Accounts Reviewed is a multi reference drawn as M:N. PII tier: financial."),
            ent("Principal and Income Allocation", [("51", "Principal and Income Allocation")],
                ["Allocation Trust", "Source Account Activity", "Source Money Movement", "Allocation Sequence"],
                grain="one row = trust x source event (49 account activity or 50 money movement) x allocation sequence",
                note="Trust accounting is a principal and income ledger, not a book of record (CW-076); the source event "
                     "keys stay keys into DP-300 and the 50 owner. PII tier: financial."),
            ent("Fiduciary Accounting Statement", [("51", "Fiduciary Accounting Statement")],
                ["Statement Trust", "Accounting Period End"],
                grain="one row = trust x accounting period end",
                note="Read only for the allocation lock (DQ rule). PII tier: financial."),
            ent("Fiduciary Tax Return", [("51", "Fiduciary Tax Return")], ["Fiduciary Tax Return ID"],
                grain="one row = trust or estate x tax year (TXRT-)",
                note="Filer EIN is published masked to its last four digits. PII tier: financial."),
            ent("Estate Settlement Case", [("51", "Estate Settlement Case")], ["Estate Settlement Case ID"],
                grain="one row = estate settlement case (ESTATE-)",
                note="PII tier: identity (decedent, heirs and representative) and financial."),
            conf("Party", PARTY, [("02", "Party")],
                 note="Conformed from DP-240: trust party, role holders, beneficiaries, filers, decedents and personal "
                      "representatives. PII tier: identity."),
            conf("Client Account", ACCT, [("15", "Account"), ("15", "Account Registration Detail")],
                 note="Conformed from DP-093. The trust-account link is held once, on 15 Account Registration Detail."
                      "Governing Trust (CW-075), which folds onto the account. PII tier: financial. " + GAP6),
            conf("Advisor", ADVISOR, note="Conformed from DP-009; the administering trust officer. PII tier: identity "
                                          "(employee)."),
            conf("Employee", EMP, note="Conformed from DP-192; the fiduciary reviewer. PII tier: identity (employee)."),
            conf("Internal Legal Entity", LE,
                 note="Conformed from DP-013; the trust company acting as trustee or estate fiduciary."),
            conf("Death Notification", DEATH, note="Conformed from DP-240. PII tier: identity."),
        ],
        relationships=[
            rel("Trust", "Party", ["Trust Party"], card="1:1"),
            rel("Trust", "Advisor", ["Administering Trust Officer"], optional=True),
            rel("Trust Instrument Document", "Trust", ["Instrument Trust"]),
            rel("Trust Term Provision", "Trust", ["Provision Trust"]),
            rel("Trust Role", "Trust", ["Role Trust"]),
            rel("Trust Role", "Party", ["Role Holder Party"], optional=True),
            rel("Trust Role", "Internal Legal Entity", ["Role Holder Entity"], optional=True),
            rel("Beneficial Interest", "Trust", ["Interest Trust"]),
            rel("Beneficial Interest", "Party", ["Beneficiary Party"]),
            rel("Trust Distribution Request", "Trust", ["Request Trust"]),
            rel("Trust Distribution Request", "Party", ["Request Beneficiary"]),
            rel("Fiduciary Account Review", "Trust", ["Review Trust"]),
            rel("Fiduciary Account Review", "Client Account", ["Accounts Reviewed"], card="M:N", note="Multi reference."),
            rel("Fiduciary Account Review", "Employee", ["Reviewer"], optional=True),
            rel("Principal and Income Allocation", "Trust", ["Allocation Trust"]),
            rel("Fiduciary Accounting Statement", "Trust", ["Statement Trust"]),
            rel("Fiduciary Tax Return", "Trust", ["Return Trust"], optional=True),
            rel("Fiduciary Tax Return", "Estate Settlement Case", ["Return Estate Case"], optional=True,
                note="A return is filed for a trust or for an estate; one of the two keys is set."),
            rel("Fiduciary Tax Return", "Party", ["Filing Entity Party"]),
            rel("Estate Settlement Case", "Party", ["Decedent"]),
            rel("Estate Settlement Case", "Death Notification", ["Case Death Notification"], optional=True),
            rel("Estate Settlement Case", "Internal Legal Entity", ["Fiduciary Entity"], optional=True),
            rel("Estate Settlement Case", "Party", ["Personal Representative"], optional=True),
            rel("Estate Settlement Case", "Trust", ["Testamentary Trust"], optional=True),
            rel("Client Account", "Trust", ["Governing Trust"], optional=True,
                note="The account points to the trust that owns it (CW-075)."),
        ],
        notes=("Foundational ER model of the trust company's fiduciary record (51, optional TR line). The spec of DP-307 is "
               "the Trust Fiduciary Record, not a client-protection view: it reads no 02 vulnerability concern, 15 account "
               "restriction or 08 senior investor case, so no Protection Flag entity can be published here (the protection "
               "flag is DP-322's, consumer-aligned). Published for conforming: Trust; Trust Role, Beneficial Interest and "
               "Estate Settlement Case are also available. Trust holds the measures because they are counted per trust. "
               "Special category (CD-344): Trust Term Provision and Trust Distribution Request are restricted entities with "
               "the tier in their notes; the special-needs value of Trust Instrument Type stays on Trust (Model gap above). "
               "Trust assets are Client Holdings of the trust's accounts (DP-300) and are never summed here. "
               "External references (resolved by joining to the named product): Source Account Activity (49, DP-300) and "
               "Source Money Movement (50) on Principal and Income Allocation. "
               "Spec observation: Distribution Purpose is a spec input although the DQ rules say it is never published; "
               "the model keeps it on the restricted Trust Distribution Request entity.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-530": dict(
        style="ER",
        entities=[
            ent("Capital Market Assumption Set", [("24", "Capital Market Assumption Set")],
                ["Capital Market Assumption Set ID", "CMA Set Version"],
                grain="one row = capital market assumption set x version",
                note="The conformed Capital Market Assumption Set of the WP2 set, read by planning (DP-303) and model "
                     "lineups. Every version is kept. No PII."),
            ent("Asset Class Return Assumption", [("24", "Asset Class Return Assumption")],
                ["Return Assumption CMA Set", "Assumption Asset Class", "Assumption Sub-Class"],
                grain="one row = CMA set version x asset class x sub-class", note="No PII."),
            ent("Asset Class Correlation Assumption", [("24", "Asset Class Correlation Assumption")],
                ["Correlation CMA Set", "First Assumption Line", "Second Assumption Line"],
                grain="one row = CMA set version x pair of return assumption lines",
                note="Associative entity between two return assumption lines of one set. No PII."),
            ent("Model Lineup", [("24", "Model Lineup")], ["Model Lineup ID", "Model Lineup Version"],
                grain="one row = model lineup x version",
                note="The conformed Model Lineup of the WP2 set: the glide path or risk-band family of models an advice "
                     "program offers, tied to one CMA set. No PII."),
            ent("Model Lineup Position", [("24", "Model Lineup Position")],
                ["Position Model Lineup", "Position Model Portfolio"],
                grain="one row = lineup version x model portfolio position", note="No PII."),
            ent("Model Building Block", [("24", "Model Building Block")],
                ["Building Block Model Portfolio", "Building Block Share Class", "Building Block Instrument",
                 "Building Block Role", "Building Block Effective From"],
                grain="one row = model portfolio x vehicle (share class or instrument) x role x effective period",
                note="Building Block Product List Status is a derived copy of DP-306's list status (CW-254), tied out by "
                     "DP-531. Exactly one of the share class and instrument keys is set. No PII."),
            ent("Target Allocation Set", [("24", "Target Allocation Set")], ["Target Set ID"], measures=True,
                grain="one row = model portfolio x target set version",
                note="The model's target weights, read by DP-304 for account targets. Holds the measures because the grain "
                     "line is the model target set and its lines. No PII."),
            ent("Target Allocation Line", [("24", "Target Allocation Line")],
                ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class"],
                grain="one row = target set x component (instrument or asset class)",
                note="Model gap: the registry key also names Target Classification Scheme, Target Classification Value, "
                     "Target Country, Target Currency and Target Sleeve Portfolio, which the spec does not read; the key "
                     "here is the instrument and asset class part only, which suffices for model portfolios (classification, "
                     "country, currency and sleeve components are not read). No PII."),
            ent("Investment Committee Decision", [("24", "Investment Committee Decision")],
                ["Decision Committee", "Decision Meeting Date", "Decision Item Number"],
                grain="one row = committee x meeting date x decision item",
                note="Approval evidence for CMA sets and lineups. Decision Committee (24 Investment Committee) is not a "
                     "spec input and stays an attribute in the key. No PII."),
            conf("Model Portfolio", MODELPF, [("01", "Model Portfolio")], note="Conformed from DP-004."),
            conf("Offering", OFFER, [("01", "Service Offering")],
                 note="Conformed from DP-004 (01 Service Offering): the advice programs a lineup serves."),
            conf("Benchmark", BMK, [("01", "Benchmark")], note="Conformed from DP-097; proxy benchmark of an assumption."),
            conf("Share Class", SHARE, [("01", "Share Class")], note="Conformed from DP-004; building block vehicle."),
            conf("Instrument", INSTR, [("17", "Instrument")], note="Conformed from DP-097; building block and target "
                                                                   "line vehicle."),
            conf("Model", MODEL, [("37", "Model Inventory Entry")],
                 note="Conformed from DP-212; the model that generated a CMA set."),
        ],
        relationships=[
            rel("Capital Market Assumption Set", "Model", ["CMA Generating Model"], optional=True,
                note="Single reference to the composite Model key (ID x version)."),
            rel("Capital Market Assumption Set", "Investment Committee Decision", ["CMA Approving Committee Decision"],
                optional=True, note="Single reference to the composite decision key."),
            rel("Asset Class Return Assumption", "Capital Market Assumption Set", ["Return Assumption CMA Set"],
                note="Single reference to the composite CMA key; the version is the set's version."),
            rel("Asset Class Return Assumption", "Benchmark", ["Assumption Proxy Benchmark"], optional=True),
            rel("Asset Class Correlation Assumption", "Capital Market Assumption Set", ["Correlation CMA Set"]),
            rel("Asset Class Correlation Assumption", "Asset Class Return Assumption", ["First Assumption Line"],
                note="Single reference to the composite line key, within the same CMA set."),
            rel("Asset Class Correlation Assumption", "Asset Class Return Assumption", ["Second Assumption Line"]),
            rel("Model Lineup", "Offering", ["Lineup Service Offering"], card="M:N", optional=True,
                note="Multi reference."),
            rel("Model Lineup", "Capital Market Assumption Set", ["Lineup CMA Set"]),
            rel("Model Lineup", "Investment Committee Decision", ["Lineup Approving Committee Decision"], optional=True),
            rel("Model Lineup Position", "Model Lineup", ["Position Model Lineup"],
                note="Single reference to the composite lineup key (ID x version)."),
            rel("Model Lineup Position", "Model Portfolio", ["Position Model Portfolio"]),
            rel("Model Building Block", "Model Portfolio", ["Building Block Model Portfolio"]),
            rel("Model Building Block", "Model Building Block", ["Alternate For Building Block"], optional=True),
            rel("Model Building Block", "Share Class", ["Building Block Share Class"], optional=True),
            rel("Model Building Block", "Instrument", ["Building Block Instrument"], optional=True),
            rel("Target Allocation Set", "Model Portfolio", ["Target Model Portfolio"]),
            rel("Target Allocation Set", "Target Allocation Set", ["Copied From Target Set"], optional=True),
            rel("Target Allocation Line", "Target Allocation Set", ["Line Target Set"]),
            rel("Target Allocation Line", "Instrument", ["Target Instrument"], optional=True),
        ],
        notes=("Foundational ER model of capital market assumptions, model lineups and model weights (24, the model-subject "
               "rows taken out of DP-128 by CW-250). Published for conforming: Capital Market Assumption Set and Model "
               "Lineup; Target Allocation Set (read by DP-304), Model Lineup Position and Model Building Block are also "
               "available. Model Portfolio is conformed from DP-004 here, as everywhere. The spec reads 24 objects only "
               "(no 46 object). No PII in this product. "
               "External references: Lineup Allocation Policy and Governing Allocation Policy (24 Asset Allocation Policy) "
               "and Decision Committee (24 Investment Committee) are not spec inputs and stay attributes (Model gap: no "
               "parent entity for them); Implemented Strategy on Model Portfolio resolves through DP-004.")),
}
