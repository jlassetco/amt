"""Logical data models, wealth WP2 foundational wave, group A1 "books": ER models for the seven foundational products of
specs_w1f_books.py: DP-432 Execution Venues & Routing Rules, DP-580 Fund Share Register & Postings, DP-301 Client Orders &
Executions, DP-431 Sweep Programs & Program Banks, DP-302 Money Movement Transactions, DP-300 Client Holdings, Lots &
Cost Basis and DP-430 Participant Balances & Ledger. See CONTRACT.md and Wealth_Manager_Rework_Plan.md section 8.4.

Conventions used in these models:
- Each product's own master and fact objects are entities keyed as the registry says (keys_w_48_50, keys_e7_27_29,
  keys_g6_15_16); Attribute Groups with fold=True sit on their parent's entity (Order Instruction Detail, Brokerage
  Omnibus Order Detail, Client Holding Valuation and the five 50 rail detail groups). None of these products reads a
  fold=False group.
- Objects another foundational product publishes are conformed entities (role "Entity") under the plain conformed names
  of plan section 8.4: Client Account (DP-093 Account), Party (DP-240), Advisor (DP-009 Employee, which holds 03 Advisor),
  Instrument (DP-097), Share Class (DP-004), Internal Legal Entity (DP-013), Employee (DP-192), Contract (DP-213), Model
  (DP-212), Recordkept Plan (DP-094 Retirement Plan). Where the product reads that object as an input, the input sits on
  the conformed entity.
- Within this group the dependency order of the specs is kept: DP-432 publishes Execution Venue and Routing Rule; DP-580
  publishes Shareholder Account, Register Position, Register Transaction and Fund Order; DP-301 publishes Client Order and
  its companions; DP-431 publishes Sweep Program and Program Bank; DP-302 publishes Money Movement, Money Movement Hold and
  Sweep Allocation; DP-300 publishes Client Holding, Cash Balance and the lot and activity facts; DP-430 publishes
  Participant Balance and republishes Recordkept Plan.
- Three books of record (CW-007): Client Holding (49, DP-300) is the only client holdings book here. No model in this file
  holds 18 Portfolio Holding (DP-142) or 06 Fund Shareholder Position (DP-007, a view over DP-300 and DP-580), and
  Register Position (29) and Participant Balance (16) are separate books that are never joined to Client Holding as one
  fact; the omnibus look-through reconciliation is DP-446's and the 06 view is DP-007's.
- Special-category data (CD-344): none of these specs reads a special-category attribute. The Rule 2165 and Financial
  Exploitation hold rows and hardship reasons are filtered out at ingestion by the specs' DQ5 rules and reach consumers
  only through DP-322, DP-456 and DP-403 (CW-213, CW-231), so no restricted child entity is needed; each entity that
  carries personal data names its PII tier in its note.
- A reference whose target product is not upstream (or is downstream, which would make a cycle) stays an attribute and is
  listed under "External references" in the model notes.
- A single reference attribute that points to an entity with a composite key is drawn as the foreign key; the rest of the
  key comes from the context named in the relationship note.
"""


def ent(name, objects, pk, grain="", note="", measures=False):
    return dict(name=name, role="Entity", objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def conf(name, src, objects=(), pk=None, note=""):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role="Entity", conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources outside this group
PARTY = ("DP-240", "Party")
CONSENT = ("DP-240", "Consent Record")
ACCT = ("DP-093", "Account")
BANKINST = ("DP-093", "Bank Instruction")
STANDING = ("DP-093", "Account Standing Instruction")
CBELECT = ("DP-093", "Cost Basis Election")
ACCTAGMT = ("DP-093", "Account Agreement")
PLAN = ("DP-094", "Retirement Plan")
MEMBER = ("DP-094", "Participant")
OPTION = ("DP-094", "Plan Investment Option")
INSTR = ("DP-097", "Instrument")
CAE = ("DP-099", "Corporate Action Event")
PRICE = ("DP-143", "Approved Price")
SHARE = ("DP-004", "Share Class")
LE = ("DP-013", "Internal Legal Entity")
EMP = ("DP-192", "Employee")
ADVISOR = ("DP-009", "Employee")
MODEL = ("DP-212", "Model")
CONTRACT = ("DP-213", "Contract")
CLASSNAV = ("DP-165", "Share Class NAV")
NAVCALC = ("DP-165", "Fund NAV Calculation")
# conformed sources inside this group
VENUE = ("DP-432", "Execution Venue")
RULE = ("DP-432", "Routing Rule")
VENUEPTY = ("DP-432", "Party")
REGPOS = ("DP-580", "Register Position")
REGTXN = ("DP-580", "Register Transaction")
FNDO = ("DP-580", "Fund Order")
ALLOC = ("DP-301", "Client Allocation")
SWEEP = ("DP-431", "Sweep Program")
PGBNK = ("DP-431", "Program Bank")
MMVMT = ("DP-302", "Money Movement")
# conformed sources from the sibling advice group (models_w_advice.py)
PROPOSAL = ("DP-304", "Trade Proposal")
REBAL = ("DP-304", "Rebalance Run")
RECO = ("DP-303", "Recommendation")
ADENG = ("DP-303", "Advice Engagement")


MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-432": dict(
        style="ER",
        entities=[
            ent("Execution Venue", [("48", "Execution Venue Profile")], ["Venue Party", "Venue Profile Effective From"],
                measures=True,
                grain="one row = venue party (02 PTY-) x profile effective period",
                note="The conformed Venue dimension (CW-234): the broker-dealer's profile of a venue it routes to, on the "
                     "02 venue party, SCD type 2. Party identity, LEI and CRD stay on Party and are never copied. Holds the "
                     "measures; the routing rule and Rule 605 measures are read through the relationships. PII tier: none "
                     "(DQ5 keeps individual parties out)."),
            ent("Routing Rule", [("48", "Routing Rule")], ["Routing Rule Code", "Routing Rule Effective From"],
                grain="one row = routing rule code x effective period (rule version)",
                note="The conformed Routing Rule dimension: the versioned rule that sends an order class to a primary and "
                     "fallback venues. An active rule is one whose effective period covers the date (no rule status; "
                     "taxonomy gap in the spec)."),
            ent("Rule 605 Report Line", [("48", "Rule 605 Report Line")],
                ["Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Security", "Rule 605 Order Type",
                 "Rule 605 Order Size Bucket"],
                grain="one row = reporting broker-dealer x report month x security x Rule 605 order type x size bucket",
                note="Companion fact published as reported; the execution-quality ratios and venue comparison are "
                     "DP-436's, which reads these lines from here."),
            conf("Party", PARTY, [("02", "Party")],
                 note="Conformed from DP-240; the venue party (exchange, ATS, market maker). Firm-level parties only."),
            conf("Internal Legal Entity", LE, [("09", "Internal Legal Entity")],
                 note="Conformed from DP-013; the Rule 605 reporting broker-dealer."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; the Rule 605 security."),
        ],
        relationships=[
            rel("Execution Venue", "Party", ["Venue Party"]),
            rel("Routing Rule", "Party", ["Primary Venue"],
                note="The registry points the venue to the 02 party; the venue profile used is the Execution Venue row of "
                     "that party whose effective period covers the routing date (the profile key is party x effective "
                     "from)."),
            rel("Routing Rule", "Party", ["Fallback Venues"], card="M:N", optional=True,
                note="A rule lists several fallback venue parties; each resolves to its Execution Venue profile by date "
                     "as for Primary Venue."),
            rel("Rule 605 Report Line", "Internal Legal Entity", ["Rule 605 Reporting Entity"]),
            rel("Rule 605 Report Line", "Instrument", ["Rule 605 Security"]),
            rel("Internal Legal Entity", "Party", ["Party Master Cross-Reference"], optional=True,
                note="The broker-dealer's own 02 party record; it ties the reporting entity to the party master the "
                     "venues sit in."),
            rel("Instrument", "Party", ["Issuer"], optional=True),
        ],
        notes=("Foundational ER master of the two conformed brokerage dimensions Execution Venue (48 Execution Venue "
               "Profile on the 02 venue party) and Routing Rule (48), with Rule 605 Report Line as a companion fact. "
               "Entity names other products conform: Execution Venue, Routing Rule, Rule 605 Report Line (and Party, "
               "republished from DP-240 for DP-301, whose upstream does not list DP-240). "
               "The registry points every venue reference (Venue Party, Primary Venue, Fallback Venues and, in DP-301, "
               "Route Venue) to 02 Party, so the venue references are drawn to Party and the effective profile is chosen "
               "by date; this keeps the profile versions and the party identity in one place. "
               "External references (keys carried, not linked): Routing Rule.Approving Review to the 08 Supervisory "
               "Review of the best-execution committee (no 08 product upstream; CW-100). "
               "Assignment note: the WP2 brief listed DP-432 as '49 clearing, settlement and reserve inputs' with a "
               "'Reserve Computation' entity; the spec is the 48 venue and routing master, and the 49 Reserve Computation "
               "is BWO DP-445's (CW-103) and is read by no product of this group, so no Reserve Computation entity is "
               "published here."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-580": dict(
        style="ER",
        entities=[
            ent("Register Position", [("29", "Share Register Balance")],
                ["Register Account", "Register Share Class", "Register Business Date"], measures=True,
                grain="one row = registered account (15) x share class (01) x business date (daily snapshot)",
                note="The transfer agent's share register (29 Share Register Balance, CW-122, CW-261), published once. It "
                     "is not one of the three books of client holdings (CW-007) and is never a 06 Fund Shareholder "
                     "Position: DP-007 builds that view from the Fund-Only and Institutional Direct rows. Omnibus, nominee "
                     "and plan rows look through to other books (Client Holding in DP-300, Participant Balance in DP-430) "
                     "and are never added to them here. Shares only, never market value. Holds the measures. PII tier: "
                     "financial (account-level rows of individuals' fund-only accounts)."),
            ent("Register Transaction", [("29", "Register Transaction")], ["Register Transaction ID"],
                grain="one row = posted share movement on the TA register (RGTX-)",
                note="The flow book of TA-registered accounts, append-only with reversals as new rows; DP-006 copies it "
                     "as a declared-source flow (CW-141). PII tier: financial."),
            ent("Fund Order", [("29", "Fund Order"), ("29", "Brokerage Omnibus Order Detail")], ["Fund Order ID"],
                grain="one row = fund order as received by the transfer agent (FNDO-)",
                note="The order that produces a posting; the broker-dealer omnibus aggregation detail has one row per "
                     "omnibus fund order and folds here (populated for Order Origin = brokerage omnibus only). The "
                     "aggregates are copies of 48 and are reconciled to DP-301 by the consumer. PII tier: financial."),
            ent("Settlement Obligation", [("29", "Settlement Obligation")], ["Settlement Obligation ID"],
                grain="one row = fund order or AP order x settlement obligation sequence",
                note="Keyed to the fund or AP order by design; obligation-to-posting is matched through Obligation Fund "
                     "Order and Originating Fund Order. Past-due and batch analytics are DP-178's."),
            conf("Shareholder Account", ACCT, [("15", "Account")],
                 note="Conformed from DP-093 Account in its registered-account role: the account the TA register keeps "
                      "(fund-only, institutional direct, broker-dealer omnibus, plan omnibus, nominee). Published under "
                      "this name so register readers conform it; it is the same Account key as Client Account."),
            conf("Share Class", SHARE, [("01", "Share Class")], note="Conformed from DP-004; the registered share class."),
            conf("Share Class NAV", CLASSNAV, [("27", "Share Class NAV")],
                 note="Conformed from DP-165; read only to test the price applied. Shares outstanding stay DP-165's."),
            conf("Party", PARTY, note="Conformed from DP-240; the register keeper (the in-house TA or an outsourced "
                                      "provider)."),
        ],
        relationships=[
            rel("Register Position", "Shareholder Account", ["Register Account"]),
            rel("Register Position", "Share Class", ["Register Share Class"]),
            rel("Register Position", "Register Transaction", ["Last Register Transaction"], optional=True),
            rel("Register Position", "Party", ["Register Keeper"], optional=True),
            rel("Register Transaction", "Shareholder Account", ["Posting Account"]),
            rel("Register Transaction", "Share Class", ["Posting Share Class"]),
            rel("Register Transaction", "Share Class NAV", ["Applied NAV Record"], optional=True),
            rel("Register Transaction", "Fund Order", ["Originating Fund Order"], optional=True,
                note="Blank for AP order and distribution postings, which carry their own originating keys."),
            rel("Register Transaction", "Register Transaction", ["Reversed Register Transaction"], optional=True,
                note="Reversal and correction rows name the posting they reverse."),
            rel("Fund Order", "Share Class", ["Order Share Class"]),
            rel("Fund Order", "Shareholder Account", ["Order Account"]),
            rel("Fund Order", "Register Transaction", ["Resulting Transaction"], card="1:1", optional=True,
                note="Set once the order is priced and posted."),
            rel("Settlement Obligation", "Fund Order", ["Obligation Fund Order"], optional=True,
                note="Blank for AP order obligations (Obligation AP Order is then set)."),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
        ],
        notes=("Foundational ER: the share register (Register Position, the 29 Share Register Balance) and the posted "
               "Register Transactions on the conformed Shareholder Account and Share Class, with Fund Order and "
               "Settlement Obligation as companion facts (CW-261). Entity names other products conform: Shareholder "
               "Account, Register Position, Register Transaction, Fund Order, Settlement Obligation. "
               "Restricted data: Governing Account Restriction is carried as the 15 Account Restriction key only and is "
               "not joined (DQ5); its type is not read, and Rule 2165 restrictions are DP-583's over DP-322, so no "
               "restricted child entity is needed. "
               "External references (keys carried, not linked): Register Transaction.Originating AP Order and Settlement "
               "Obligation.Obligation AP Order to the 29 AP Creation / Redemption Order (DP-170's, not upstream); "
               "Register Transaction.Originating Distribution Declaration to the 27 Distribution Declaration (DP-171's, "
               "not upstream); Register Position.Governing Account Restriction to DP-093 Account Restriction (key only by "
               "rule)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-301": dict(
        style="ER",
        entities=[
            ent("Client Order", [("48", "Client Order"), ("48", "Order Instruction Detail")], ["Client Order ID"],
                measures=True,
                grain="one row = client order (CLORD-; one 15 account's order in one instrument)",
                note="The conformed Client Order (CW-096); the pricing, time-in-force and session instructions have one "
                     "row per order and fold here. Distinct from the 25 fund desk Trade Order (DP-121). Holds the "
                     "measures; route, execution, allocation, confirmation and correction measures are read through the "
                     "relationships. PII tier: financial (account-level orders)."),
            ent("Option Order Leg", [("48", "Option Order Leg")], ["Leg Client Order", "Leg Sequence Number"],
                grain="one row = client order x leg sequence",
                note="The legs of a multi-leg option order."),
            ent("Client Order Event", [("48", "Client Order Event")], ["Event Client Order", "Event Sequence Number"],
                grain="one row = client order x event sequence",
                note="The order lifecycle trail (new, replace, cancel, fill, expire), append-only."),
            ent("Order Route", [("48", "Order Route")], ["Order Route ID"],
                grain="one row = client order or client block order x route sequence (ROUTE-)",
                note="Either Routed Client Order or Routed Client Block Order is set. Venue and rule come from DP-432 "
                     "and are never copied."),
            ent("Client Block Order", [("48", "Client Block Order")], ["Client Block Order ID"],
                grain="one row = client block order (CLBLK-)",
                note="The aggregate of managed-account or advisor orders routed as one; no personal data."),
            ent("Client Execution", [("48", "Client Execution")], ["Client Execution ID"],
                grain="one row = client execution (one fill on one order route; CLEXE-)",
                note="Client Execution has no venue party reference (taxonomy gap); the venue is reached through "
                     "Execution Order Route to Route Venue, or matched on Execution Venue MIC to the Execution Venue "
                     "profile."),
            ent("Client Allocation", [("48", "Client Allocation")],
                ["Allocation Client Block Order", "Allocated Client Order", "Allocated Account"],
                grain="one row = client block order or client order x allocated account",
                note="The registry key is composite because the object has no identifier (taxonomy gap); exactly one of "
                     "the block or client order is populated. The 49 postings of the allocation are DP-300's, which "
                     "holds the link. PII tier: financial."),
            ent("Client Trade Confirmation", [("48", "Client Trade Confirmation")], ["Client Trade Confirmation ID"],
                grain="one row = client allocation x confirmation version (CCONF-)",
                note="Rule 10b-10 confirmations, versioned; the current version is the one no later version names in "
                     "Superseded Confirmation. Commission Charged is an operational billed amount, never fee revenue "
                     "(DP-012). PII tier: financial."),
            ent("Trade Correction", [("48", "Trade Correction")], ["Trade Correction ID"],
                grain="one row = trade correction (TCORR-)",
                note="Corrections and as-of trades; the error cases are DP-437's."),
            ent("CAT Reportable Event", [("48", "CAT Reportable Event")], ["CAT Record ID"],
                grain="one row = CAT reportable event record (one per order, route, execution or allocation event)",
                note="Carries no customer identifying information (CW-115). PII tier: financial (restricted) on Firm "
                     "Designated ID only, visible to CAT reporting and compliance roles and masked elsewhere. The "
                     "completeness counts are DP-435's."),
            ent("Pre-Trade Risk Limit", [("48", "Pre-Trade Risk Limit")],
                ["Pre-Trade Limit Scope", "Limit Scope Value", "Limit Scope Account", "Limit Instrument Class",
                 "Pre-Trade Limit Type", "Limit Effective From"],
                grain="one row = limit scope x scope account, segment or channel x instrument class x limit type x "
                      "effective period",
                note="Reference companion, SCD type 2 (Rule 15c3-5); the key parts that do not apply to the scope are "
                     "blank. Personal data only when a scope account is set (financial)."),
            conf("Client Account", ACCT, [("15", "Account")],
                 note="Conformed from DP-093; the ordering, allocated and confirmed account. Carried as the DP-093 key "
                      "only in published views (DQ5)."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; the ordered, blocked, confirmed and option-leg instrument."),
            conf("Execution Venue", VENUE, note="Conformed from DP-432; the venue profile of a route venue."),
            conf("Routing Rule", RULE, note="Conformed from DP-432; the rule version applied to a route."),
            conf("Party", VENUEPTY,
                 note="Conformed from DP-432, which republishes the DP-240 party (DP-240 is not in this product's "
                      "upstream); the route venue party."),
            conf("Fund Order", FNDO, note="Conformed from DP-580; the 29 fund order an own-fund route results in."),
            conf("Employee", EMP,
                 note="Conformed from DP-192; the entering employee, the block's advisor and the correction approver."),
            conf("Internal Legal Entity", LE, note="Conformed from DP-013; the executing broker-dealer."),
            conf("Trade Proposal", PROPOSAL,
                 note="Conformed from DP-304; the managed-account trade proposal an order implements (never re-scored)."),
            conf("Rebalance Run", REBAL,
                 note="Conformed from DP-304 (the 46 Trade Proposal Batch); the rebalance run a block order aggregates."),
            conf("Recommendation", RECO,
                 note="Conformed from DP-303; the advice recommendation a solicited order implements (never re-scored)."),
        ],
        relationships=[
            rel("Client Order", "Client Account", ["Order Account"]),
            rel("Client Order", "Instrument", ["Order Instrument"]),
            rel("Client Order", "Employee", ["Entering Employee"], optional=True,
                note="Set for orders entered by an associate; self-directed digital orders leave it blank."),
            rel("Client Order", "Client Order", ["Original Client Order"], optional=True,
                note="Cancel-replace: the order this one replaces."),
            rel("Client Order", "Client Block Order", ["Parent Client Block Order"], optional=True),
            rel("Client Order", "Internal Legal Entity", ["Executing Broker-Dealer"], optional=True),
            rel("Client Order", "Trade Proposal", ["Source Trade Proposal"], optional=True,
                note="Managed-account orders only (Order Source = managed account rebalance)."),
            rel("Client Order", "Recommendation", ["Source Recommendation"], optional=True,
                note="Orders that implement an advice recommendation."),
            rel("Option Order Leg", "Client Order", ["Leg Client Order"]),
            rel("Option Order Leg", "Instrument", ["Leg Option Series"]),
            rel("Client Order Event", "Client Order", ["Event Client Order"]),
            rel("Client Order Event", "Order Route", ["Event Order Route"], optional=True),
            rel("Order Route", "Client Order", ["Routed Client Order"], optional=True),
            rel("Order Route", "Client Block Order", ["Routed Client Block Order"], optional=True),
            rel("Order Route", "Party", ["Route Venue"],
                note="The registry points the venue to the 02 party; the venue profile is the Execution Venue row of "
                     "that party effective at Routed Timestamp."),
            rel("Order Route", "Routing Rule", ["Applied Routing Rule"], optional=True,
                note="The routing rule key is code x effective from; the version effective at Routed Timestamp supplies "
                     "the rest of it."),
            rel("Order Route", "Fund Order", ["Resulting Fund Order"], optional=True,
                note="Own-fund orders routed to the in-house TA through the omnibus account."),
            rel("Execution Venue", "Party", ["Venue Party"]),
            rel("Routing Rule", "Party", ["Primary Venue"]),
            rel("Client Block Order", "Instrument", ["Block Instrument"]),
            rel("Client Block Order", "Employee", ["Block Advisor"], optional=True),
            rel("Client Block Order", "Rebalance Run", ["Source Trade Proposal Batch"], optional=True,
                note="Blocks built from a managed-account rebalance run."),
            rel("Client Execution", "Order Route", ["Execution Order Route"]),
            rel("Client Allocation", "Client Block Order", ["Allocation Client Block Order"], optional=True),
            rel("Client Allocation", "Client Order", ["Allocated Client Order"]),
            rel("Client Allocation", "Client Account", ["Allocated Account"]),
            rel("Client Trade Confirmation", "Client Allocation", ["Confirmed Client Allocation"],
                note="The allocation key is composite; the confirmation's account and the allocation's order or block "
                     "supply the rest of it."),
            rel("Client Trade Confirmation", "Client Account", ["Confirmation Account"]),
            rel("Client Trade Confirmation", "Instrument", ["Confirmed Instrument"]),
            rel("Client Trade Confirmation", "Client Trade Confirmation", ["Superseded Confirmation"], optional=True),
            rel("Client Trade Confirmation", "Trade Correction", ["Originating Trade Correction"], optional=True),
            rel("Trade Correction", "Client Execution", ["Corrected Client Execution"], optional=True),
            rel("Trade Correction", "Client Allocation", ["Corrected Client Allocation"],
                note="Composite allocation key, resolved as for the confirmation."),
            rel("Trade Correction", "Employee", ["Correction Approved By"], optional=True),
            rel("Trade Correction", "Client Trade Confirmation", ["Resulting Confirmation"], optional=True),
            rel("CAT Reportable Event", "Client Order", ["CAT Source Client Order"]),
            rel("CAT Reportable Event", "Order Route", ["CAT Source Order Route"], optional=True),
            rel("CAT Reportable Event", "Client Execution", ["CAT Source Client Execution"], optional=True),
            rel("CAT Reportable Event", "Client Allocation", ["CAT Source Client Allocation"], optional=True),
            rel("Pre-Trade Risk Limit", "Client Account", ["Limit Scope Account"], optional=True,
                note="Account-scoped limits only."),
        ],
        notes=("Foundational ER around the conformed Client Order (48, CLORD-) with its legs, events, routes, block "
               "orders, executions, allocations, confirmation versions, corrections and CAT records, and Pre-Trade Risk "
               "Limit as a reference companion (CW-096, CW-098, CW-176). Entity names other products conform: Client "
               "Order, Option Order Leg, Client Order Event, Order Route, Client Block Order, Client Execution, Client "
               "Allocation, Client Trade Confirmation, Trade Correction, CAT Reportable Event, Pre-Trade Risk Limit. "
               "Trade Proposal and Rebalance Run (DP-304) and Recommendation (DP-303) are conformed so orders and "
               "blocks link to the advice and managed-account records they implement. "
               "External references (keys carried, not linked): Instrument.Own "
               "Share Class to DP-004 Share Class (Model gap: DP-004 is not in this product's upstream). The 48 "
               "Specified Client Tax Lots attribute is not read, so DP-301 stays upstream of DP-300."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-431": dict(
        style="ER",
        entities=[
            ent("Sweep Program", [("50", "Sweep Program")], ["Sweep Program ID"], measures=True,
                grain="one row = sweep program (SWEEP-), SCD type 2",
                note="The conformed Sweep Program dimension (CW-108): the bank deposit and money market fund sweeps "
                     "with their eligibility. Holds the measures; the bank, participation, tier, daily total and FDIC "
                     "measures are read through the relationships. No personal data."),
            ent("Program Bank", [("50", "Program Bank")], ["Program Bank ID"],
                grain="one row = bank party (02 PTY-) in the program bank role x role period (PGBNK-)",
                note="The conformed Program Bank dimension (CW-108, CW-234): a role profile of the 02 bank party. FDIC "
                     "Certificate Number and Bank Charter Type are held here until 02 carries them (taxonomy gap). No "
                     "personal data; Bank Approved By is published as the employee key only."),
            ent("Program Bank Participation", [("50", "Program Bank Participation")],
                ["Participation Sweep Program", "Participating Program Bank", "Participation Effective From"],
                grain="one row = sweep program x program bank x effective period",
                note="Associative entity between program and bank: priority, capacity, agreement and the primary-purpose "
                     "exception basis. Omnibus Deposit Account Number is not read."),
            ent("Sweep Rate Tier", [("50", "Sweep Rate Tier")],
                ["Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Effective From"],
                grain="one row = sweep program x rate tier basis x balance band x effective period"),
            ent("Program Bank Daily Total", [("50", "Program Bank Daily Total")],
                ["Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date"],
                grain="one row = sweep program x program bank x business date",
                note="Companion fact: aggregate customer deposits placed at the bank; no personal data. Program revenue "
                     "is 10's (CW-156)."),
            ent("FDIC Coverage Assessment", [("50", "FDIC Coverage Assessment")],
                ["Assessed Party", "FDIC Ownership Category", "Assessed Program Bank", "Assessment Date"],
                grain="one row = party x FDIC ownership category x program bank x assessment date",
                note="Companion fact. PII tier: financial (party-level deposit and insured amounts); visible at party "
                     "grain to cash program and compliance roles only, otherwise aggregated to program bank x ownership "
                     "category (DQ5)."),
            conf("Party", PARTY, [("02", "Party")],
                 note="Conformed from DP-240; the bank party of a program bank and the assessed depositor party."),
            conf("Internal Legal Entity", LE, [("09", "Internal Legal Entity")],
                 note="Conformed from DP-013; the sponsoring broker-dealer."),
            conf("Share Class", SHARE, [("01", "Share Class")],
                 note="Conformed from DP-004; the eligible sweep money market fund classes."),
            conf("Contract", CONTRACT, [("39", "Contract")],
                 note="Conformed from DP-213; the program bank agreement."),
            conf("Employee", EMP, note="Conformed from DP-192; the approver of a program bank."),
            conf("Client Account", ACCT, note="Conformed from DP-093; the accounts an FDIC assessment covers."),
        ],
        relationships=[
            rel("Sweep Program", "Internal Legal Entity", ["Sponsoring Broker-Dealer"]),
            rel("Sweep Program", "Share Class", ["Eligible Sweep Funds"], card="M:N", optional=True,
                note="Money market fund sweeps list one or more eligible fund classes."),
            rel("Program Bank", "Party", ["Bank Party"]),
            rel("Program Bank", "Employee", ["Bank Approved By"], optional=True),
            rel("Program Bank Participation", "Sweep Program", ["Participation Sweep Program"]),
            rel("Program Bank Participation", "Program Bank", ["Participating Program Bank"]),
            rel("Program Bank Participation", "Contract", ["Program Bank Agreement"], optional=True),
            rel("Sweep Rate Tier", "Sweep Program", ["Tier Sweep Program"]),
            rel("Program Bank Daily Total", "Sweep Program", ["Daily Total Sweep Program"]),
            rel("Program Bank Daily Total", "Program Bank", ["Daily Total Program Bank"]),
            rel("FDIC Coverage Assessment", "Party", ["Assessed Party"]),
            rel("FDIC Coverage Assessment", "Program Bank", ["Assessed Program Bank"]),
            rel("FDIC Coverage Assessment", "Client Account", ["Accounts Assessed"], card="M:N", optional=True,
                note="An assessment aggregates the depositor's accounts in one ownership category."),
        ],
        notes=("Foundational ER master of the conformed Sweep Program and Program Bank dimensions (CW-108, CW-234), "
               "joined by Program Bank Participation and Sweep Rate Tier, with Program Bank Daily Total and FDIC Coverage "
               "Assessment as companion facts. Entity names other products conform: Sweep Program, Program Bank, Program "
               "Bank Participation, Sweep Rate Tier, Program Bank Daily Total, FDIC Coverage Assessment. "
               "Account-level Sweep Allocation rows are DP-302's and the 49 Cash Balance (the account total) is DP-300's; the "
               "allocation-to-balance tie is DP-446's (CW-102)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-302": dict(
        style="ER",
        entities=[
            ent("Money Movement",
                [("50", "Money Movement"), ("50", "ACH Entry Detail"), ("50", "Wire Transfer Detail"),
                 ("50", "Check Detail"), ("50", "Internal Transfer Detail"), ("50", "Card Transaction Detail")],
                ["Money Movement ID"], measures=True,
                grain="one row = money movement (MMVMT-)",
                note="The payment record (CW-107), not a flow book: DP-006 takes brokerage flows from 49 Client Account "
                     "Activity (DP-300), which holds Source Money Movement. The ACH, wire, check, internal journal and card "
                     "rail detail groups have one row per movement and fold here; only the group of the movement's rail "
                     "is populated. For a movement held only under a suppressed special-category or AML hold, the "
                     "published status is the status before the hold (DQ5). Holds the measures. PII tier: financial "
                     "(bank, card, check and wire beneficiary numbers masked or not published)."),
            ent("Money Movement Event", [("50", "Money Movement Event")], ["Event Movement", "Event Sequence"],
                grain="one row = money movement x event sequence",
                note="Held and Released events of suppressed holds are omitted (DQ5)."),
            ent("Money Movement Return", [("50", "Money Movement Return")], ["Returned Movement", "Return Sequence"],
                grain="one row = money movement x return sequence"),
            ent("Money Movement Exception", [("50", "Money Movement Exception")],
                ["Exception Movement", "Exception Sequence"],
                grain="one row = money movement x exception sequence"),
            ent("Money Movement Hold", [("50", "Money Movement Hold")], ["Money Movement Hold ID"],
                grain="one row = money movement hold (MMHLD-), non-special rows only",
                note="The conformed Money Movement Hold (CW-109) for the published holds: funds availability, fraud, "
                     "verification, legal process and sanctions. FINRA Rule 2165 and 2166 holds, the Financial "
                     "Exploitation, diminished capacity, undue influence and scam reasons and AML holds are not loaded "
                     "(DQ5, CW-213, CW-231); they reach consumers only through DP-322 and the restricted views DP-456 and "
                     "DP-403 (special category, CD-344), and the AML holds through DP-226 and DP-460. The special-category "
                     "detail (narrative, vulnerability concern, senior investor case, trusted contact, paired "
                     "restriction) is not read, so no restricted child entity is needed. PII tier: financial."),
            ent("Fraud Risk Assessment", [("50", "Fraud Risk Assessment")], ["Assessed Movement", "Assessment Timestamp"],
                grain="one row = money movement x assessment timestamp",
                note="Score from the 37 fraud model (CD-294). Resulting Hold is blank where the hold is suppressed."),
            ent("Money Movement Monitoring Alert", [("50", "Money Movement Monitoring Alert")],
                ["Money Movement Monitoring Alert ID"],
                grain="one row = money movement monitoring alert (MMALT-)",
                note="Published alerts only: the Elder Exploitation Pattern scenario is not loaded (DQ5); Alert "
                     "Disposition is published only as escalated or closed. PII tier: financial; rows visible to AML and "
                     "money movement roles only."),
            ent("Sweep Allocation", [("50", "Sweep Allocation")],
                ["Allocation Account", "Allocation Program Bank", "Allocation Business Date"],
                grain="one row = account x program bank x business date (daily snapshot)",
                note="The 50 Sweep Allocation (CW-102): the account's bank "
                     "deposit sweep balance placed at each program bank. It is the program-bank split of the 49 "
                     "Cash Balance of the sweep balance type (DP-300); DP-446 ties the two, and the two are never added. "
                     "PII tier: financial."),
            conf("Client Account", ACCT, [("15", "Account")],
                 note="Conformed from DP-093; the movement, destination, alert and sweep account (key only in views)."),
            conf("Bank Instruction", BANKINST, [("15", "Bank Instruction")],
                 note="Conformed from DP-093; the bank account on file a movement used. Account numbers masked."),
            conf("Account Standing Instruction", STANDING, [("15", "Account Standing Instruction")],
                 note="Conformed from DP-093; the recurring instruction that generated a movement."),
            conf("Program Bank", PGBNK, note="Conformed from DP-431; the sweep bank and the check drawee bank."),
            conf("Fund Order", FNDO, note="Conformed from DP-580; the money market fund redemption behind a check."),
            conf("Model", MODEL,
                 note="Conformed from DP-212; the fraud model. The model key is model x version; the version in use at "
                      "Assessment Timestamp supplies the rest of it."),
            conf("Party", PARTY, note="Conformed from DP-240; the initiating party (owner, agent or third party)."),
        ],
        relationships=[
            rel("Money Movement", "Client Account", ["Movement Account"]),
            rel("Money Movement", "Party", ["Initiating Party"], optional=True),
            rel("Money Movement", "Account Standing Instruction", ["Source Standing Instruction"], optional=True),
            rel("Money Movement", "Bank Instruction", ["Bank Instruction Used"], optional=True,
                note="Blank for internal journals and card transactions."),
            rel("Money Movement", "Client Account", ["Destination Account"], optional=True,
                note="Internal journals only (Internal Transfer Detail)."),
            rel("Money Movement", "Program Bank", ["Drawn-On Program Bank"], optional=True,
                note="Checks only (Check Detail)."),
            rel("Money Movement", "Fund Order", ["Redeeming Fund Order"], optional=True,
                note="Checkwriting on the firm's own money market funds."),
            rel("Money Movement Event", "Money Movement", ["Event Movement"]),
            rel("Money Movement Return", "Money Movement", ["Returned Movement"]),
            rel("Money Movement Exception", "Money Movement", ["Exception Movement"]),
            rel("Money Movement Hold", "Money Movement", ["Held Movement"]),
            rel("Fraud Risk Assessment", "Money Movement", ["Assessed Movement"]),
            rel("Fraud Risk Assessment", "Model", ["Fraud Model"], optional=True),
            rel("Fraud Risk Assessment", "Money Movement Hold", ["Resulting Hold"], optional=True),
            rel("Money Movement Monitoring Alert", "Money Movement", ["Movements in Scope"], card="M:N",
                note="An alert names the movements of its scenario window, and a movement may sit in several alerts."),
            rel("Money Movement Monitoring Alert", "Client Account", ["Alert Accounts"], card="M:N", optional=True),
            rel("Sweep Allocation", "Client Account", ["Allocation Account"]),
            rel("Sweep Allocation", "Program Bank", ["Allocation Program Bank"]),
            rel("Bank Instruction", "Client Account", ["Bank Instruction Account"]),
            rel("Account Standing Instruction", "Client Account", ["Instruction Account"]),
            rel("Account Standing Instruction", "Bank Instruction", ["Linked Bank Instruction"], optional=True),
        ],
        notes=("Foundational ER around the conformed Money Movement (50, MMVMT-) with its rail detail folded, the event, "
               "return and exception trails, the published Money Movement Hold rows, Fraud Risk Assessment and Money "
               "Movement Monitoring Alert, and Sweep Allocation (50) as a daily companion snapshot. Entity "
               "names other products conform: Money Movement, Money Movement Event, Money Movement Return, Money Movement "
               "Exception, Money Movement Hold, Fraud Risk Assessment, Money Movement Monitoring Alert, Sweep Allocation. "
               "Special category: no special-category attribute is read; the suppressed hold and alert rows never enter "
               "this model (see Money Movement Hold). "
               "External references (keys carried, not linked): Card Transaction Detail.Transaction Debit Card to the 50 "
               "Debit Card (DP-459's, downstream); the 49 posting of a movement is held by DP-300 (Source Money "
               "Movement), and Sweep Allocation.Reconciled Sweep Balance is not read, so DP-300 stays downstream."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-300": dict(
        style="ER",
        entities=[
            ent("Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")], ["Client Holding ID"],
                measures=True,
                grain="one row = client account (15) x instrument (17) x holding date x Client Holding View (CLHLD-)",
                note="The brokerage book of record of client holdings (CW-007, CW-101), with its valuation folded (one "
                     "row per holding). Never a Portfolio Holding (18, DP-142) or a Fund Shareholder Position (06, a view "
                     "DP-007 builds from this entity and the DP-580 register), and never joined to either as one fact; "
                     "the 49-to-29 omnibus proof is DP-446's. Market Value is the book value DP-007 and DP-008 copy; "
                     "Client Assets are DP-008's and Firm AUM DP-241's, never added here (CW-011). Holds the measures. "
                     "PII tier: financial."),
            ent("Client Tax Lot", [("49", "Client Tax Lot")], ["Client Tax Lot ID"],
                grain="one row = account x instrument x acquisition lot (CTLOT-), current state",
                note="Fund-only account lots are opened by 29 Register Transactions (CW-034, CW-122). Lot state on a "
                     "past date is rebuilt from Acquisition Date and Client Lot Relief (no snapshot; taxonomy gap). PII "
                     "tier: financial."),
            ent("Client Lot Relief", [("49", "Client Lot Relief")],
                ["Relieved Client Tax Lot", "Closing Activity", "Closing Register Transaction"],
                grain="one row = client tax lot x closing activity (CLACT-) or closing register transaction (RGTX-)",
                note="Associative entity between the lot and the closing record; exactly one closing key is set. "
                     "Carries realized gain, wash-sale and Form 1099-B category. PII tier: financial."),
            ent("Cost Basis Adjustment", [("49", "Cost Basis Adjustment")],
                ["Adjusted Client Tax Lot", "Adjustment Sequence"],
                grain="one row = client tax lot x adjustment sequence"),
            ent("Cost Basis Transfer Statement", [("49", "Cost Basis Transfer Statement")],
                ["Statement Account Transfer", "Transfer Statement Direction", "Statement Version"],
                grain="one row = account transfer x statement direction x statement version (IRC section 6045A)"),
            ent("Client Account Activity", [("49", "Client Account Activity")], ["Client Account Activity ID"],
                grain="one row = account x posting (CLACT-)",
                note="The flow book of brokerage and managed accounts (CW-141): DP-006 copies it with declared sources "
                     "and nothing is recomputed here. Each posting names its source record (allocation, movement, fee "
                     "debit, entitlement, transfer or fund order). PII tier: financial."),
            ent("Cash Balance", [("49", "Account Cash Balance")],
                ["Cash Balance Account", "Cash Balance Currency", "Cash Balance Type", "Balance Basis",
                 "Cash Balance Business Date"],
                grain="one row = account x currency x cash balance type x balance basis x business date",
                note="The 49 Account Cash Balance under its conformed name: free credit, sweep, margin and other balance "
                     "types on trade-date and settlement-date bases. The sweep balance type is the account total whose "
                     "program-bank split is DP-302's Sweep Allocation; Cash Balance stays the account total. Free credit balances feed the DP-445 reserve "
                     "computation, which this product never reads (CW-103). Distinct from the portfolio Cash Balance of "
                     "DP-142 (18). PII tier: financial."),
            ent("Account Transfer", [("49", "Account Transfer")], ["Account Transfer ID"],
                grain="one row = account transfer (ACXF-), ACATS or non-ACATS",
                note="Contra Firm Account Number is not read (DQ5). The work queues and asset lines are DP-448's."),
            ent("Margin Balance Snapshot", [("49", "Margin Balance Snapshot")],
                ["Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Snapshot Type",
                 "Margin Snapshot As-Of Timestamp"],
                grain="one row = margin account x business date x snapshot type x as-of timestamp",
                note="Margin debit balances feed DP-445; margin calls are DP-600's. PII tier: financial."),
            ent("Client Corporate Action Entitlement", [("49", "Client Corporate Action Entitlement")],
                ["Client Corporate Action Entitlement ID"],
                grain="one row = corporate action event x account (CLCAE-)",
                note="Elections and DRIP are DP-452's. PII tier: financial."),
            ent("Fully Paid Securities Loan", [("49", "Fully Paid Securities Loan")], ["Fully Paid Securities Loan ID"],
                grain="one row = account x borrowing entity x instrument x loan (CSLN-)",
                note="Matched to the daily Client Holding by Lending Account and Loaned Instrument, because a daily "
                     "snapshot row is not a reference target (spec design note). PII tier: financial."),
            conf("Client Account", ACCT, [("15", "Account")],
                 note="Conformed from DP-093; the brokerage, managed, IRA and fund-only account (key only in views)."),
            conf("Cost Basis Election", CBELECT, [("15", "Cost Basis Election")],
                 note="Conformed from DP-093; the account's lot relief method by scope (15 holds the election, never "
                      "lots)."),
            conf("Instrument", INSTR, [("17", "Instrument")], pk=["Instrument ID"],
                 note="Conformed from DP-097; the held, lotted, transacted and loaned instrument."),
            conf("Approved Price", PRICE, [("22", "Approved Price")],
                 note="Conformed from DP-143; the price record a holding is valued at."),
            conf("Register Transaction", REGTXN, [("29", "Register Transaction")],
                 note="Conformed from DP-580; the TA posting that opens or relieves a fund-only account lot."),
            conf("Client Allocation", ALLOC, note="Conformed from DP-301; the allocation a trade posting settles."),
            conf("Money Movement", MMVMT, note="Conformed from DP-302; the payment a cash posting records."),
            conf("Fund Order", FNDO, note="Conformed from DP-580; the fund order behind an own-fund posting."),
            conf("Sweep Program", SWEEP, note="Conformed from DP-431; the program of a sweep cash balance."),
            conf("Corporate Action Event", CAE,
                 note="Conformed from DP-099; the event of an entitlement and of a basis adjustment."),
            conf("Account Agreement", ACCTAGMT,
                 note="Conformed from DP-093; the fully paid lending agreement the account signed."),
            conf("Party", PARTY, note="Conformed from DP-240; the contra firm of a transfer and of a basis statement."),
            conf("Internal Legal Entity", LE,
                 note="Conformed from DP-013; the carrying broker-dealer and the borrowing entity of a loan."),
        ],
        relationships=[
            rel("Client Holding", "Client Account", ["Holding Account"]),
            rel("Client Holding", "Instrument", ["Held Instrument"]),
            rel("Client Holding", "Approved Price", ["Valuation Price Record"], optional=True,
                note="Blank where no approved price exists for the valuation date (the holding is then carried at the "
                     "last price and flagged by the valuation test)."),
            rel("Client Tax Lot", "Client Account", ["Lot Account"]),
            rel("Client Tax Lot", "Instrument", ["Lot Instrument"]),
            rel("Client Tax Lot", "Client Account Activity", ["Acquisition Activity"], optional=True,
                note="Brokerage lots; blank for lots taken on by transfer without the opening posting."),
            rel("Client Tax Lot", "Register Transaction", ["Acquisition Register Transaction"], optional=True,
                note="Fund-only account lots."),
            rel("Client Lot Relief", "Client Tax Lot", ["Relieved Client Tax Lot"]),
            rel("Client Lot Relief", "Client Account Activity", ["Closing Activity"], optional=True),
            rel("Client Lot Relief", "Register Transaction", ["Closing Register Transaction"], optional=True),
            rel("Cost Basis Adjustment", "Client Tax Lot", ["Adjusted Client Tax Lot"]),
            rel("Cost Basis Adjustment", "Corporate Action Event", ["Source Corporate Action Event"], optional=True),
            rel("Cost Basis Transfer Statement", "Account Transfer", ["Statement Account Transfer"]),
            rel("Cost Basis Transfer Statement", "Party", ["Statement Counterparty Firm"], optional=True),
            rel("Client Account Activity", "Client Account", ["Activity Account"]),
            rel("Client Account Activity", "Instrument", ["Activity Instrument"], optional=True,
                note="Blank for pure cash postings."),
            rel("Client Account Activity", "Client Allocation", ["Source Client Allocation"], optional=True,
                note="The allocation key is composite; the posting's account and the allocation's order or block supply "
                     "the rest of it."),
            rel("Client Account Activity", "Money Movement", ["Source Money Movement"], optional=True),
            rel("Client Account Activity", "Client Corporate Action Entitlement", ["Source Entitlement"], optional=True),
            rel("Client Account Activity", "Account Transfer", ["Source Account Transfer"], optional=True),
            rel("Client Account Activity", "Fund Order", ["Source Fund Order"], optional=True),
            rel("Client Account Activity", "Client Account Activity", ["Reversed Activity"], optional=True),
            rel("Cash Balance", "Client Account", ["Cash Balance Account"]),
            rel("Cash Balance", "Sweep Program", ["Balance Sweep Program"], optional=True,
                note="Sweep balance types only."),
            rel("Account Transfer", "Client Account", ["Transfer Account"]),
            rel("Account Transfer", "Party", ["Contra Firm"], optional=True),
            rel("Margin Balance Snapshot", "Client Account", ["Margin Snapshot Account"]),
            rel("Client Corporate Action Entitlement", "Corporate Action Event", ["Entitlement Event"]),
            rel("Client Corporate Action Entitlement", "Client Account", ["Entitled Account"]),
            rel("Client Corporate Action Entitlement", "Client Account Activity", ["Payment Activity"], optional=True),
            rel("Fully Paid Securities Loan", "Client Account", ["Lending Account"]),
            rel("Fully Paid Securities Loan", "Account Agreement", ["Lending Agreement"], optional=True),
            rel("Fully Paid Securities Loan", "Internal Legal Entity", ["Borrowing Entity"], optional=True),
            rel("Fully Paid Securities Loan", "Instrument", ["Loaned Instrument"], optional=True),
            rel("Client Account", "Internal Legal Entity", ["Carrying Entity"]),
            rel("Cost Basis Election", "Client Account", ["Election Account"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
        ],
        notes=("Foundational ER around the conformed Client Holding (49, CLHLD-), the brokerage book of record, with the "
               "lot, relief and cost basis facts, the Client Account Activity flow book and the cash, transfer, margin, "
               "entitlement and fully paid lending companions, all on the conformed Client Account. Entity names other "
               "products conform: Client Holding, Client Tax Lot, Client Lot Relief, Cost Basis Adjustment, Cost Basis "
               "Transfer Statement, Client Account Activity, Cash Balance, Account Transfer, Margin Balance Snapshot, "
               "Client Corporate Action Entitlement, Fully Paid Securities Loan. "
               "Books of record (CW-007): this model holds no 18 or 06 object; Portfolio Holding stays DP-142's and Fund "
               "Shareholder Position DP-007's. A consumer that needs both reads them as separate facts and reconciles "
               "through the 18 Portfolio Implementation Link (managed account to book) and DP-446 (omnibus look-through). "
               "Boundaries: the Rule 15c3-3 Reserve Computation, possession or control and Control Location are DP-445's "
               "(CW-103); this product publishes their inputs only. "
               "External references (keys carried, not linked): Client Holding.Principal Control Location to the 49 "
               "Control Location (DP-445's, downstream); Client Account Activity.Source Fee Debit to the 47 Fee Debit "
               "(DP-305 lists this product upstream, so the edge would close a cycle)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-430": dict(
        style="ER",
        entities=[
            ent("Participant Balance", [("16", "Participant Balance")],
                ["Balance Membership", "Balance Contribution Source", "Balance Investment Option", "Valuation Date"],
                measures=True,
                grain="one row = participant plan membership x money source x plan investment option x valuation date "
                      "(daily snapshot)",
                note="The recordkeeping book of record of participant accounts (CW-125): not one of the three books of "
                     "CW-007 and never mixed with Client Holding (49) or Portfolio Holding (18); brokerage windows and "
                     "IRAs are Client Holdings (DP-300). A re-valued day overwrites (no valuation version; taxonomy gap). "
                     "Holds the measures. PII tier: financial (identity only through the 02 participant key)."),
            ent("Participant Ledger Posting", [("16", "Participant Ledger Posting")], ["Ledger Posting ID"],
                grain="one row = participant ledger posting (PLPST-)",
                note="The flow book of participant accounts (CW-141): DP-006 copies it with declared sources. PII tier: "
                     "financial."),
            ent("Participant Investment Transfer", [("16", "Participant Investment Transfer")], ["Investment Transfer ID"],
                grain="one row = participant investment transfer (PEXC-)"),
            ent("Participant Retail Hand-Off", [("16", "Participant Retail Hand-Off")], ["Hand-Off ID"],
                grain="one row = participant plan membership x trigger event (PRTHO-)",
                note="The separation or rollover hand-off to the direct business; the funnel and capture rate are "
                     "DP-467's. PII tier: financial."),
            conf("Participant", MEMBER, [("16", "Participant Plan Membership")],
                 note="Conformed from DP-094 (the membership master); read for its participant account link and status. "
                      "The Highly Compensated Employee Indicator inherited from DP-094 is not read or published by this "
                      "product (DQ5)."),
            conf("Plan Investment Option", OPTION, [("16", "Plan Investment Option")],
                 note="Conformed from DP-094; the plan menu entry a balance and a posting sit in."),
            conf("Recordkept Plan", PLAN,
                 note="Conformed from DP-094 Retirement Plan (the 02 plan party); republished here under the plain name "
                      "so participant-balance consumers conform the plan with the balance."),
            conf("Client Account", ACCT, [("15", "Account")],
                 note="Conformed from DP-093; the 15 Plan Participant Account of the membership."),
            conf("Share Class NAV", CLASSNAV, [("27", "Share Class NAV")],
                 note="Conformed from DP-165; the NAV the unit value applied is tested against."),
            conf("Fund NAV Calculation", NAVCALC, [("27", "Fund NAV Calculation")],
                 note="Conformed from DP-165; read for the valuation date, version type and status of the NAV used."),
            conf("Register Position", REGPOS, [("29", "Share Register Balance")],
                 note="Conformed from DP-580; read only for the Register Keeper of the share class (transfer-agent "
                      "test). The plan omnibus register rows are a separate book and are never added to Participant "
                      "Balance; there is no key from a plan or option to its plan omnibus register account (taxonomy "
                      "gap)."),
            conf("Share Class", SHARE, note="Conformed from DP-004; the offered and NAV share class."),
            conf("Fund Order", FNDO, note="Conformed from DP-580; the plan fund order a posting results in."),
            conf("Party", PARTY, note="Conformed from DP-240; the participant party and the register keeper."),
            conf("Consent Record", CONSENT, note="Conformed from DP-240; the consent to contact for a hand-off."),
            conf("Advisor", ADVISOR,
                 note="Conformed from DP-009 Employee, which holds 03 Advisor; the advisor a hand-off is referred to. "
                      "DP-001 (intermediary financial professionals) is not upstream and does not hold 03 Advisor."),
            conf("Advice Engagement", ADENG,
                 note="Conformed from DP-303; the advice engagement a hand-off referral opens."),
        ],
        relationships=[
            rel("Participant Balance", "Participant", ["Balance Membership"]),
            rel("Participant Balance", "Plan Investment Option", ["Balance Investment Option"]),
            rel("Participant Ledger Posting", "Participant", ["Posting Membership"]),
            rel("Participant Ledger Posting", "Plan Investment Option", ["Posting Investment Option"], optional=True),
            rel("Participant Ledger Posting", "Fund Order", ["Resulting Plan Fund Order"], optional=True),
            rel("Participant Investment Transfer", "Participant", ["Transfer Membership"]),
            rel("Participant Investment Transfer", "Plan Investment Option", ["Transfer From Option"], optional=True),
            rel("Participant Investment Transfer", "Plan Investment Option", ["Transfer To Option"], optional=True),
            rel("Participant Retail Hand-Off", "Participant", ["Hand-Off Membership"]),
            rel("Participant Retail Hand-Off", "Consent Record", ["Contact Consent"], optional=True),
            rel("Participant Retail Hand-Off", "Advisor", ["Referred Advisor"], optional=True),
            rel("Participant Retail Hand-Off", "Advice Engagement", ["Referral Advice Engagement"], optional=True,
                note="Set when the hand-off is referred to advice."),
            rel("Participant", "Party", ["Participant"]),
            rel("Participant", "Recordkept Plan", ["Membership Plan"]),
            rel("Participant", "Client Account", ["Participant Account"]),
            rel("Plan Investment Option", "Recordkept Plan", ["Menu Plan"]),
            rel("Plan Investment Option", "Share Class", ["Offered Share Class"]),
            rel("Share Class NAV", "Share Class", ["NAV Share Class"]),
            rel("Share Class NAV", "Fund NAV Calculation", ["Parent NAV Calculation"], optional=True,
                note="The calculation key is book x valuation date x source x version; the class NAV's calculation "
                     "supplies it."),
            rel("Register Position", "Share Class", ["Register Share Class"]),
            rel("Register Position", "Party", ["Register Keeper"], optional=True),
            rel("Fund Order", "Share Class", ["Order Share Class"]),
        ],
        notes=("Foundational ER around the conformed Participant Balance (16), the recordkeeping book of record, with "
               "Participant Ledger Posting as the participant flow book, Participant Investment Transfer and Participant "
               "Retail Hand-Off, on the DP-094 membership, plan and menu masters. Entity names other products conform: "
               "Participant Balance, Participant Ledger Posting, Participant Investment Transfer, Participant Retail "
               "Hand-Off, and Recordkept Plan (republished from DP-094). "
               "Special category: hardship reasons (CD-344) and the HCE indicator are not read, so no restricted child "
               "entity is needed. "
               "External references (keys carried, not linked): Participant Retail Hand-Off.Linked Distribution Request to the 16 Distribution Request (no "
               "upstream product models it); Participant Ledger Posting.Posting Source Record (polymorphic reference "
               "with no registry target)."),
    ),
}
