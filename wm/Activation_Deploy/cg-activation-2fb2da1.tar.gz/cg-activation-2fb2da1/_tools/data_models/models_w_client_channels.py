"""Logical data models, wealth-manager WP2 foundational wave, group A3 'client and channels' (ER): DP-381 Client Service
Interactions & Requests and DP-382 Client Document & Delivery Record (Data Domain 13; specs_w1f_client.py), DP-480 Cost
Allocation & Management Hierarchy (Data Domain 10) and DP-481 Competitor Offerings & Price Observations (Data Domain 11;
specs_w1f_channels.py). See CONTRACT.md and Wealth_Manager_Rework_Plan.md section 8.4.

Conformed entities published here for the consumer stars:
- DP-381: Service Request, Interaction, Interaction Authentication, Account Maintenance Change, QA Review;
- DP-382: Communication, Communication Distribution, Investor Document, Investor Document Definition, Document Delivery,
  Delivery Election, Mailing Household, Tax Form, Production Run;
- DP-480: Cost Pool, Allocation Method, Allocation Driver, Allocation Rule, Allocation Run, Allocation Result,
  Management Hierarchy, Management Hierarchy Node, Hierarchy Restatement, Account Mapping;
- DP-481: Competitor, Competitor Offering, Price Observation, Fee Benchmark Study.

Conventions:
- Client Account is conformed from DP-093 Account; Party and Household from DP-240 Party (a household is a Party,
  PTY-HH-); the household-to-member link is the DP-240 Household Membership bridge, never a column on the account.
- Advisor is conformed from DP-009 Employee (03 Advisor folds there; DP-009 is the spec upstream, not DP-001, whose
  Financial Professional is the intermediary rep); the contact center agent from DP-192 Employee.
- Offering and Share Class are conformed from DP-004 (Service Offering, Share Class).
- No foundational model publishes a "Channel" entity today: Account Channel Assignment (06) is published by DP-006,
  DP-007 and DP-008, none of which is upstream here. Intake Channel and Interaction Channel are code values (DP-013
  code lists), so no Channel entity is conformed in these models.
- A child Attribute Group that does not carry its parent's identifier borrows "<Parent> Key".
"""

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-381": dict(
        style="ER",
        entities=[
            dict(name="Service Request", role="Entity",
                 objects=[("13", "Service Request"), ("13", "Request Controls")],
                 pk=["Service Request ID"], measures=True,
                 grain="one row = service request (account x request type x received timestamp) x status version (SCD "
                       "type 2)",
                 note="The conformed Service Request (SRQ-, CW-222). Request Controls has one row per request and folds "
                      "here, so the call-back and signature guarantee evidence sits on the request it controls. It holds "
                      "the product measures because the request is the main fact; Assisted Interactions and Service "
                      "Events per Account count Interaction rows through the same product. Request Status uses the "
                      "shared Case Status values, so the request is also the service case: 13 has no separate case "
                      "object. PII tier: identity (party and account keys, requester role; requester names are never "
                      "read). External keys carried, not linked (their masters are not upstream and resolve downstream): "
                      "Resulting Order (29, DP-580), Resulting Client Account Activity (49, DP-300), Resulting Money "
                      "Movement (50, DP-302) and Escalated Complaint (08, DP-414; referenced, never copied, CW-070)."),
            dict(name="Service Request Estate Detail", role="Entity",
                 objects=[("13", "Transfer of Ownership & Estate")],
                 pk=["Service Request Key"],
                 grain="one row = service request of an ownership transfer, estate or beneficiary claim type",
                 note="Restricted child of Service Request, kept apart although the registry folds the group: death, "
                      "estate and ownership-transfer facts are served only to the estate and servicing views, and the "
                      "Ownership Transfer Reason value Incapacity / Guardianship (special category, CD-344) is excluded "
                      "at read, so the only column that could carry a special-category fact sits behind its own access "
                      "rule (CW-213). The validator warning that the folded group sits apart from its parent is accepted "
                      "for this reason. PII tier: identity (death notification, beneficiary and restriction keys). "
                      "Estate Settlement Case (51) is carried as a key: its master product is not upstream. Model gap: "
                      "the group carries no Service Request ID, so the key is the borrowed Service Request Key."),
            dict(name="Account Maintenance Change", role="Entity",
                 objects=[("13", "Account Maintenance Change")],
                 pk=["Service Request Key", "Maintained Data Element"],
                 grain="one row = account maintenance service request x maintained data element",
                 note="Repeating detail of a maintenance request (fold=False): one row per changed element, so the "
                      "high-risk changes (mailing address, email, phone, bank instruction) can be tested against the "
                      "request's call-back evidence. PII tier: identity (keys only; the changed values are 15 and 02's). "
                      "Change Notification Document points to a DP-382 Investor Document, carried as a key because "
                      "DP-382 is not upstream of this product. Model gap: the group carries no Service Request ID, so "
                      "its key borrows the Service Request Key."),
            dict(name="Interaction", role="Entity",
                 objects=[("13", "Contact Center Interaction")],
                 pk=["Interaction ID"],
                 grain="one row = assisted-service interaction (phone, chat, secure message, video, email or branch)",
                 note="The conformed assisted-service Interaction; the companion fact of the request. Recording Reference "
                      "is not read. PII tier: identity (party, account and agent keys)."),
            dict(name="Interaction Authentication", role="Entity",
                 objects=[("13", "Interaction Authentication")],
                 pk=["Authenticated Interaction", "Authentication Attempt Number"],
                 grain="one row = interaction x authentication attempt",
                 note="Kept as its own entity because an interaction can need several attempts and a step-up, and the "
                      "Regulation S-ID red flag count is per attempt. Authentication evidence and Linked Identity "
                      "Verification are not read. PII tier: identity."),
            dict(name="QA Review", role="Entity",
                 objects=[("13", "QA Review")],
                 pk=["Reviewed Item"],
                 grain="one row = quality assurance review x reviewed service request or interaction",
                 note="The QA sample. PII tier: identity (keys only). Model gap: Reviewed Item is polymorphic (Service "
                      "Request / Interaction); the registry maps it to the service request, so interaction reviews have "
                      "no modeled link, and 13 QA Review has no review ID, date or reviewer (the key assumes one review "
                      "per reviewed item; spec taxonomy gap)."),
            dict(name="Client Account", role="Entity", conformed=("DP-093", "Account"), objects=[],
                 note="Conformed from DP-093: the account of every request, interaction and maintenance change."),
            dict(name="Party", role="Entity", conformed=("DP-240", "Party"), objects=[],
                 note="Conformed from DP-240: requesting, interaction and authenticated parties and the servicing "
                      "provider (an outsourced contact center or transfer agent, CD-297)."),
            dict(name="Household", role="Entity", conformed=("DP-240", "Party"), objects=[],
                 note="Conformed from DP-240 Party restricted to Party Type = Household (PTY-HH-): the client household "
                      "that Service Events per Account rolls up to as of the period end."),
            dict(name="Household Membership", role="Bridge", conformed=("DP-240", "Household Membership"), objects=[],
                 grain="one row = household x member party x membership effective period",
                 note="Conformed from DP-240: the effective-dated many-to-many link of household to member party. The "
                      "request and interaction reach the household through their party, never through a household "
                      "column."),
            dict(name="Death Notification", role="Entity", conformed=("DP-240", "Death Notification"), objects=[],
                 note="Conformed from DP-240 so estate requests resolve to the notification that opened them."),
            dict(name="Beneficiary Designation", role="Entity", conformed=("DP-093", "Beneficiary Designation"),
                 objects=[], note="Conformed from DP-093: the designation a beneficiary claim relies on."),
            dict(name="Account Restriction", role="Entity", conformed=("DP-093", "Account Restriction"), objects=[],
                 note="Conformed from DP-093, which excludes the FINRA Rule 2165 rows at read; only the deceased-account "
                      "restriction key is published here, never its detail."),
            dict(name="Advisor", role="Entity", conformed=("DP-009", "Employee"), objects=[],
                 note="Conformed from DP-009 (20 Employee with 03 Advisor): the assisting advisor of the request."),
            dict(name="Contact Center Agent", role="Entity", conformed=("DP-192", "Employee"), objects=[],
                 note="Conformed from DP-192: the agent who handled the interaction."),
        ],
        relationships=[
            dict(child="Service Request", parent="Client Account", fk=["Account"], card="M:1"),
            dict(child="Service Request", parent="Party", fk=["Requesting Party"], card="M:1", optional=True),
            dict(child="Service Request", parent="Party", fk=["Servicing Provider"], card="M:1", optional=True,
                 note="Populated when the request is serviced by a provider (outsourced operating model)."),
            dict(child="Service Request", parent="Advisor", fk=["Assisting Advisor"], card="M:1", optional=True),
            dict(child="Service Request Estate Detail", parent="Service Request", fk=["Service Request Key"],
                 card="1:1", note="Only requests of an ownership transfer, estate or beneficiary claim type."),
            dict(child="Service Request Estate Detail", parent="Death Notification", fk=["Related Death Notification"],
                 card="M:1", optional=True),
            dict(child="Service Request Estate Detail", parent="Beneficiary Designation",
                 fk=["Claimed Beneficiary Designation"], card="M:1", optional=True),
            dict(child="Service Request Estate Detail", parent="Account Restriction",
                 fk=["Deceased-Account Restriction"], card="M:1", optional=True),
            dict(child="Account Maintenance Change", parent="Service Request", fk=["Service Request Key"], card="M:1"),
            dict(child="Account Maintenance Change", parent="Client Account", fk=["Updated Master Record"], card="M:1",
                 optional=True, note="Updated Master Record is Party / Account; the registry maps it to the account, "
                                     "and party-level changes carry the party key without a modeled link."),
            dict(child="Interaction", parent="Client Account", fk=["Interaction Account"], card="M:1", optional=True),
            dict(child="Interaction", parent="Party", fk=["Interaction Party"], card="M:1", optional=True),
            dict(child="Interaction", parent="Contact Center Agent", fk=["Interaction Agent"], card="M:1",
                 optional=True, note="Blank for interactions handled by a provider's agent (Servicing Provider)."),
            dict(child="Interaction", parent="Service Request", fk=["Linked Service Request"], card="M:1",
                 optional=True, note="The request the interaction opened or progressed; same account by DQ3."),
            dict(child="Interaction Authentication", parent="Interaction", fk=["Authenticated Interaction"],
                 card="M:1"),
            dict(child="Interaction Authentication", parent="Party", fk=["Authenticated Party"], card="M:1",
                 optional=True),
            dict(child="QA Review", parent="Service Request", fk=["Reviewed Item"], card="1:1", optional=True,
                 note="Service request reviews only; see the QA Review model gap for interaction reviews."),
            dict(child="Household Membership", parent="Household", fk=["Household"], card="M:1"),
            dict(child="Household Membership", parent="Party", fk=["Household Member"], card="M:1"),
        ],
        notes=("Foundational, modeled ER around the conformed Service Request and Interaction (CW-222, CW-229): requests "
               "with their folded controls, the maintenance and estate detail as children, and the interaction with its "
               "authentication attempts. Every 13 entity names its PII tier (identity); the analytics view carries keys, "
               "types, channels, timestamps and durations only. No special-category fact is held: the Incapacity / "
               "Guardianship reason is excluded at read and the estate detail is a restricted child (CD-344, CW-213); "
               "vulnerability, hardship and exploitation facts reach consumers only through DP-322. "
               "Accepted warning: the folded group Transfer of Ownership & Estate is placed apart from Service Request on "
               "purpose (restricted child). "
               "Model gap: no 13 object is a 'Service Case'; the request is the case record (its Request Status takes the "
               "Case Status values), and complaint cases are 08's (DP-414). "
               "Channel: Intake Channel and Interaction Channel are code values; no foundational model publishes a "
               "Channel entity yet (06 Account Channel Assignment is DP-006/DP-007/DP-008's, not upstream)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-382": dict(
        style="ER",
        entities=[
            dict(name="Investor Document Definition", role="Entity",
                 objects=[("13", "Investor Document Definition")],
                 pk=["Document Definition Code"],
                 grain="one row = client document definition (catalog entry)",
                 note="The catalog of statement, confirmation, tax and notice types with the regulatory basis and furnish "
                      "deadline rule the late-delivery measure applies. PII tier: none."),
            dict(name="Investor Document", role="Entity",
                 objects=[("13", "Investor Document")],
                 pk=["Investor Document ID"], measures=True,
                 grain="one row = investor document (definition x account x recipient x period end x version)",
                 note="The conformed Investor Document (STMT-, CW-223). It holds the product measures because Documents "
                      "Issued is the main count and the other measures are its companions. Document Repository "
                      "Reference is not read; content (statement lines) is DP-300's. PII tier: financial (client "
                      "documents; account and recipient keys are identity)."),
            dict(name="Confirmation Delivery", role="Entity",
                 objects=[("13", "Confirmation Delivery")],
                 pk=["Investor Document Key", "Client Trade Confirmation", "Confirmed Fund Order"],
                 grain="one row = confirmation document x confirmed client trade confirmation or fund order",
                 note="Repeating detail of a confirmation document (fold=False): a periodic confirmation covers several "
                      "trades. Exactly one of Client Trade Confirmation and Confirmed Fund Order is populated; the fund "
                      "order (29) is a key resolved by DP-580 downstream. PII tier: financial. Model gap: the group "
                      "carries no Investor Document ID, so its key borrows the Investor Document Key."),
            dict(name="Client Trade Confirmation", role="Entity", conformed=("DP-301", "Client Trade Confirmation"),
                 objects=[("48", "Client Trade Confirmation")],
                 note="Conformed from DP-301, the foundational publisher of the 48 confirmation (CW-081), which the "
                      "Rule 10b-10 timing test compares against. PII tier: financial."),
            dict(name="Tax Form", role="Entity",
                 objects=[("13", "Tax Form Record")],
                 pk=["Tax Form Account", "Payer Entity", "Tax Document Type", "Tax Year", "Tax Form Version"],
                 grain="one row = tax form (account x payer entity x tax document type x tax year x form version)",
                 note="Published at form grain: Form Box Code, Reported Amount and Recipient TIN (Masked) are not read, so "
                      "the box rows of the 13 object collapse to one form row; amounts are DP-355's and DP-417's. PII "
                      "tier: financial. Model gap: the registry key (Payer Fund, Tax Year, Tax Document Type, Tax Form "
                      "Version, Form Box Code) names two attributes the spec does not read and predates Tax Form "
                      "Account; the key here follows the spec grain (lead: re-cut the registry key)."),
            dict(name="Production Run", role="Entity",
                 objects=[("13", "Production Run")],
                 pk=["Production Run ID"],
                 grain="one row = document production run (vendor x run date x batch)",
                 note="The print or delivery vendor's run with its reconciliation status. PII tier: none (vendor and "
                      "control counts). Model gap: 13 Investor Document has no link to its Production Run (spec taxonomy "
                      "gap), so runs join to the rest of the model only through the vendor party."),
            dict(name="Communication", role="Entity",
                 objects=[("13", "Shareholder Communication")],
                 pk=["Communication ID"],
                 grain="one row = client communication (communication type x audience x period or event)",
                 note="The conformed Communication (COMM-): shareholder reports, prospectus and proxy materials, notices "
                      "and privacy notices with the delivery deadline. PII tier: none (a communication is not personal "
                      "data; its distribution to accounts is)."),
            dict(name="Communication Distribution", role="Entity",
                 objects=[("13", "Communication Distribution")],
                 pk=["Distribution Job ID"],
                 grain="one row = communication distribution job (communication x audience x mail date)",
                 note="One mailing or posting of a communication, with the deadline test. PII tier: none."),
            dict(name="Document Delivery", role="Entity",
                 objects=[("13", "Recipient Delivery Record")],
                 pk=["Document Delivery Key"],
                 grain="one row = delivery to one recipient: distribution job x recipient account, or investor document x "
                       "recipient account",
                 note="The conformed recipient-level Document Delivery, master of returned mail (CW-089). PII tier: "
                      "identity (recipient account key, return reason). Model gap: the registry key (Recipient Account "
                      "alone) is not unique, and the grain's two parents are alternatives (exactly one of Distribution "
                      "Job and Delivered Investor Document is populated), so no composite of input attributes is a key; "
                      "a surrogate Document Delivery Key is used (lead: registry key Distribution Job + Delivered Investor "
                      "Document + Recipient Account, with the empty side defaulted)."),
            dict(name="Delivery Election", role="Entity",
                 objects=[("13", "E-Delivery Election"), ("13", "Mail Hold")],
                 pk=["Delivery Election ID"],
                 grain="one row = delivery election (account x document scope x effective period, SCD type 2)",
                 note="The conformed Delivery Election: e-delivery preference and consent per document scope, with the "
                      "account's mail hold folded in (one row per election). Consent Evidence Reference and Delivery "
                      "Email Contact Point are not read. PII tier: identity."),
            dict(name="Mailing Household", role="Entity",
                 objects=[("13", "Householding Group")],
                 pk=["Householding Group ID"],
                 grain="one row = mailing household (shared address x member accounts) x status version (SCD type 2)",
                 note="The 13 mailing household of Rule 30e-1 and Rule 154 householding (MHG-). It is not the 02 client "
                      "household (DP-240) or the 47 fee household (DP-305), so it is named apart and never joined to "
                      "them (CW-027). PII tier: identity (Householding Address is served only in the servicing view)."),
            dict(name="Client Account", role="Entity", conformed=("DP-093", "Account"), objects=[],
                 note="Conformed from DP-093: document, recipient, election, tax form, mailing household member and "
                      "confirmation accounts."),
            dict(name="Party", role="Entity", conformed=("DP-240", "Party"), objects=[],
                 note="Conformed from DP-240: document recipients and the print or delivery vendor."),
            dict(name="Household", role="Entity", conformed=("DP-240", "Party"), objects=[],
                 note="Conformed from DP-240 Party restricted to Party Type = Household: the client household a "
                      "recipient belongs to, for household statement rollups (13 SME 5). Distinct from Mailing Household."),
            dict(name="Household Membership", role="Bridge", conformed=("DP-240", "Household Membership"), objects=[],
                 grain="one row = household x member party x membership effective period",
                 note="Conformed from DP-240: the effective-dated household-to-member bridge."),
            dict(name="Contact Point", role="Entity", conformed=("DP-240", "Contact Point"), objects=[],
                 note="Conformed from DP-240 (02 Contact Point with Postal Address): the shared address of a mailing "
                      "household."),
            dict(name="Consent Record", role="Entity", conformed=("DP-240", "Consent Record"), objects=[],
                 note="Conformed from DP-240: the E-SIGN consent an electronic delivery election links to."),
            dict(name="Legal Entity", role="Entity", conformed=("DP-013", "Internal Legal Entity"), objects=[],
                 note="Conformed from DP-013: the issuing, payer and communicating entities."),
            dict(name="Share Class", role="Entity", conformed=("DP-004", "Share Class"), objects=[],
                 note="Conformed from DP-004: the share classes a communication covers."),
        ],
        relationships=[
            dict(child="Investor Document", parent="Investor Document Definition", fk=["Document Definition"],
                 card="M:1"),
            dict(child="Investor Document", parent="Client Account", fk=["Document Account"], card="M:1"),
            dict(child="Investor Document", parent="Party", fk=["Document Recipient"], card="M:1", optional=True),
            dict(child="Investor Document", parent="Legal Entity", fk=["Issuing Entity"], card="M:1", optional=True),
            dict(child="Investor Document", parent="Investor Document", fk=["Original Document"], card="M:1",
                 optional=True, note="A corrected or reissued document points to the one it replaces."),
            dict(child="Confirmation Delivery", parent="Investor Document", fk=["Investor Document Key"], card="M:1"),
            dict(child="Confirmation Delivery", parent="Client Trade Confirmation", fk=["Client Trade Confirmation"],
                 card="M:1", optional=True, note="Blank on fund order confirmations."),
            dict(child="Client Trade Confirmation", parent="Client Account", fk=["Confirmation Account"], card="M:1"),
            dict(child="Tax Form", parent="Client Account", fk=["Tax Form Account"], card="M:1"),
            dict(child="Tax Form", parent="Legal Entity", fk=["Payer Entity"], card="M:1"),
            dict(child="Production Run", parent="Party", fk=["Print / Delivery Vendor"], card="M:1", optional=True),
            dict(child="Communication", parent="Legal Entity", fk=["Communicating Entity"], card="M:1", optional=True),
            dict(child="Communication", parent="Share Class", fk=["Covered Share Classes"], card="M:N", optional=True,
                 note="Multi-valued; one communication covers many share classes and a class receives many "
                      "communications, split into a bridge at publication."),
            dict(child="Communication Distribution", parent="Communication", fk=["Distributed Communication"],
                 card="M:1"),
            dict(child="Document Delivery", parent="Communication Distribution", fk=["Distribution Job"], card="M:1",
                 optional=True, note="Populated for communication mailings."),
            dict(child="Document Delivery", parent="Investor Document", fk=["Delivered Investor Document"], card="M:1",
                 optional=True, note="Populated for account documents; same account by DQ3."),
            dict(child="Document Delivery", parent="Client Account", fk=["Recipient Account"], card="M:1"),
            dict(child="Delivery Election", parent="Client Account", fk=["Election Account"], card="M:1"),
            dict(child="Delivery Election", parent="Consent Record", fk=["Linked Consent Record"], card="M:1",
                 optional=True),
            dict(child="Mailing Household", parent="Client Account", fk=["Member Accounts"], card="M:N",
                 note="Multi-valued; an account belongs to at most one active mailing household per document scope "
                      "(DQ2), split into a bridge at publication."),
            dict(child="Mailing Household", parent="Contact Point", fk=["Householding Address"], card="M:1"),
            dict(child="Household Membership", parent="Household", fk=["Household"], card="M:1"),
            dict(child="Household Membership", parent="Party", fk=["Household Member"], card="M:1"),
        ],
        notes=("Foundational, modeled ER around the conformed Investor Document, Communication, Document Delivery and "
               "Delivery Election (CW-223): documents with their confirmation detail, tax forms at form grain, "
               "communications with their distributions, the recipient delivery record that masters returned mail, "
               "elections with the mail hold, and the mailing household. Every 13 entity names its PII tier; no "
               "special-category attribute is read. The mailing household is never joined to the client or fee "
               "household (CW-027). 15 opening disclosure and 47 fee disclosure deliveries stay with their masters "
               "(CW-087). "
               "Model gaps: Document Delivery surrogate key; Tax Form key re-cut to the spec grain; Production Run has no "
               "link to the documents it produced."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-480": dict(
        style="ER",
        entities=[
            dict(name="Cost Pool", role="Entity",
                 objects=[("10", "Cost Pool")],
                 pk=["Cost Pool ID"],
                 grain="one row = cost pool x effective period",
                 note="The conformed Cost Pool dimension (DIS+FDN brief section 5). Pool Source Cost is derived from "
                      "DP-191 through the contributing cost centers; the pool itself has no amount (spec taxonomy gap)."),
            dict(name="Allocation Method", role="Entity",
                 objects=[("10", "Allocation Method")],
                 pk=["Allocation Method ID"],
                 grain="one row = allocation method"),
            dict(name="Allocation Driver", role="Entity",
                 objects=[("10", "Allocation Driver")],
                 pk=["Allocation Driver ID"],
                 grain="one row = allocation driver",
                 note="Driver volumes are applied by the allocation engine; only the driver definition and its TDABC "
                      "rate and time estimate are held."),
            dict(name="Allocation Rule", role="Entity",
                 objects=[("10", "Allocation Rule")],
                 pk=["Allocation Rule ID"],
                 grain="one row = source cost pool x method x driver x target dimension x rule effective period"),
            dict(name="Allocation Run", role="Entity",
                 objects=[("10", "Allocation Run")],
                 pk=["Allocation Run ID"],
                 grain="one row = allocation run (run period x run data version)",
                 note="Versioned by Run Data Version; a Final run is never changed."),
            dict(name="Allocation Result", role="Entity",
                 objects=[("10", "Allocation Result")],
                 pk=["Allocation Run Key", "Allocated Rule", "Target Dimension Member"], measures=True,
                 grain="one row = allocation run x allocation rule x target dimension member (members summed to the "
                       "target dimension for Household, Account, Client and Advisor targets)",
                 note="Holds the product measures: allocated cost, completeness and the reconciliation to certified "
                      "operating expense all sum result rows. Rows whose target is a household, account or client are "
                      "PII - financial and advisor targets carry compensation cost (CD-344 tier); they are summed to the "
                      "target dimension before publication and released at member grain only through the restricted "
                      "views of DP-498 and DP-499 (CW-243). Target Dimension Member is polymorphic (offering, share "
                      "class, partner, plan, segment, legal entity, region, channel code or a cost pool for pool-to-pool "
                      "steps) and has no registry reference, so it is carried as a key. Model gap: the group carries no "
                      "Allocation Run ID, so its key borrows the Allocation Run Key."),
            dict(name="Management Hierarchy", role="Entity",
                 objects=[("10", "Management Hierarchy")],
                 pk=["Management Hierarchy ID"],
                 grain="one row = management hierarchy version (hierarchy type x version)",
                 note="The conformed Management Hierarchy dimension (DIS+FDN brief section 5); one active version per "
                      "hierarchy type on any date."),
            dict(name="Management Hierarchy Node", role="Entity",
                 objects=[("10", "Management Hierarchy Node")],
                 pk=["Management Hierarchy Key", "Node ID"],
                 grain="one row = hierarchy version x node",
                 note="Repeating detail of a hierarchy version (fold=False). Leaf Member is polymorphic (a dimension "
                      "member of the hierarchy type); only cost center leaves are linked here. Model gap: the group "
                      "carries no Management Hierarchy ID, so its key borrows the Management Hierarchy Key."),
            dict(name="Hierarchy Restatement", role="Entity",
                 objects=[("10", "Hierarchy Restatement")],
                 pk=["Restatement ID"],
                 grain="one row = hierarchy restatement event"),
            dict(name="Account Mapping", role="Entity",
                 objects=[("10", "Account Mapping")],
                 pk=["Account Mapping ID"],
                 grain="one row = management P&L line x GL natural account x ledger x mapping effective period",
                 note="The management P&L line to GL account mapping (ACM-)."),
            dict(name="GL Account Balance", role="Entity", conformed=("DP-191", "GL Account Balance"),
                 objects=[("19", "GL Account Balance")],
                 note="Conformed from DP-191: the certified operating expense by cost center that every Final run "
                      "reconciles to (CW-011); allocated cost is never presented as a ledger figure."),
            dict(name="Accounting Period Status", role="Entity", conformed=("DP-191", "Accounting Period Status"),
                 objects=[("19", "Accounting Period Status")],
                 note="Conformed from DP-191: only hard-closed periods feed a Final run."),
            dict(name="GL Account", role="Entity", conformed=("DP-190", "GL Account"), objects=[("19", "GL Account")],
                 note="Conformed from DP-190, the chart master."),
            dict(name="Ledger", role="Entity", conformed=("DP-190", "Ledger"), objects=[("19", "Ledger")],
                 note="Conformed from DP-190; the primary ledger is the one reconciled to."),
            dict(name="Cost Center", role="Entity", conformed=("DP-190", "Cost Center"), objects=[],
                 note="Conformed from DP-190 (19 Chart Segment Value, CD-152): the contributing cost centers of a pool."),
            dict(name="Fiscal Period", role="Entity", conformed=("DP-013", "Fiscal Period"), objects=[],
                 note="Conformed from DP-013: run, balance and close-status periods."),
        ],
        relationships=[
            dict(child="Cost Pool", parent="Cost Center", fk=["Contributing Cost Centers"], card="M:N",
                 note="Multi-valued; one cost center contributes to one pool per run (DQ2), split into a bridge at "
                      "publication."),
            dict(child="Allocation Rule", parent="Cost Pool", fk=["Source Cost Pool"], card="M:1"),
            dict(child="Allocation Rule", parent="Allocation Method", fk=["Applied Allocation Method"], card="M:1"),
            dict(child="Allocation Rule", parent="Allocation Driver", fk=["Applied Driver"], card="M:1",
                 optional=True, note="Blank for methods that need no driver (Rules Without Driver tests it)."),
            dict(child="Allocation Result", parent="Allocation Run", fk=["Allocation Run Key"], card="M:1"),
            dict(child="Allocation Result", parent="Allocation Rule", fk=["Allocated Rule"], card="M:1"),
            dict(child="Allocation Run", parent="Fiscal Period", fk=["Run Period"], card="M:1",
                 note="A code carrying the Fiscal Period ID (no registry reference)."),
            dict(child="Management Hierarchy Node", parent="Management Hierarchy", fk=["Management Hierarchy Key"],
                 card="M:1"),
            dict(child="Management Hierarchy Node", parent="Management Hierarchy Node", fk=["Parent Node"],
                 card="M:1", optional=True, note="Blank on the root node."),
            dict(child="Management Hierarchy Node", parent="Cost Center", fk=["Leaf Member"], card="M:1",
                 optional=True, note="Cost center leaves only; other leaf types resolve to the master of the hierarchy "
                                     "type (DP-004, DP-001, DP-003, DP-240, DP-013) and are carried as keys."),
            dict(child="Hierarchy Restatement", parent="Management Hierarchy", fk=["Prior Hierarchy Version"],
                 card="M:1"),
            dict(child="Account Mapping", parent="GL Account", fk=["GL Natural Account"], card="M:1"),
            dict(child="Account Mapping", parent="Ledger", fk=["Applicable Ledger"], card="M:1", optional=True),
            dict(child="GL Account Balance", parent="GL Account", fk=["Balance GL Account"], card="M:1"),
            dict(child="GL Account Balance", parent="Ledger", fk=["Balance Ledger"], card="M:1"),
            dict(child="GL Account Balance", parent="Fiscal Period", fk=["Balance Fiscal Period"], card="M:1"),
            dict(child="GL Account Balance", parent="Cost Center", fk=["Balance Segment Combination"], card="M:1",
                 note="Through the cost center segment of the account combination: the join that gives certified "
                      "operating expense by cost center."),
            dict(child="Accounting Period Status", parent="Ledger", fk=["Status Ledger"], card="M:1"),
            dict(child="Accounting Period Status", parent="Fiscal Period", fk=["Status Fiscal Period"], card="M:1"),
        ],
        notes=("Foundational, modeled ER: the allocation chain (pool, method, driver, rule, run, result), the management "
               "hierarchy (version, node, restatement) and the account mapping, with the GL masters conformed from "
               "DP-190 and the certified balances and close status from DP-191, so every run ties back to certified "
               "operating expense (CW-011). Publishes the WP2 shared dimensions Cost Pool and Management Hierarchy. "
               "PII tier: none in the published output; household, account, client and advisor targets are summed "
               "before publication (CW-243). "
               "Scope note: the A3 assignment described DP-480 as industry and market reference (industry flows, peer "
               "sets); the spec (specs_w1f_channels.py, CW-240) defines DP-480 as Cost Allocation & Management "
               "Hierarchy, so this model follows the spec. Industry flows and peer universes are DP-014's (11 Industry "
               "Flow Observation, Peer Universe) and are not modeled here. "
               "Contributing Cost Centers links to the DP-190 Cost Center (19 Chart Segment Value, CD-152). "
               "Model gap: Allocation Result and Management Hierarchy Node borrow their parent keys (spec "
               "taxonomy gaps)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-481": dict(
        style="ER",
        entities=[
            dict(name="Competitor", role="Entity",
                 objects=[("11", "Competitor Profile")],
                 pk=["Competitor Profile ID"],
                 grain="one row = competitor firm or group x effective period (SCD type 2)",
                 note="The conformed Competitor dimension (CPF-, CD-012) on a DP-240 organization party. Competitor "
                      "Display Name and Regulatory Identifiers are Derived copies of 02 and are not read. PII tier: none "
                      "(organizations only, DQ1)."),
            dict(name="Competitor Offering", role="Entity",
                 objects=[("11", "Competitor Offering")],
                 pk=["Competitor Offering ID"],
                 grain="one row = competitor x offering x effective period (SCD type 2)",
                 note="The conformed Competitor Offering (COFF-, CW-160), mapped to the comparable own offering. PII "
                      "tier: none."),
            dict(name="Price Observation", role="Entity",
                 objects=[("11", "Competitor Pricing Observation")],
                 pk=["Priced Offering", "Price Component", "Observation As-of Date", "Balance Tier Lower Bound"],
                 measures=True,
                 grain="one row = competitor offering x price component x observation as-of date x balance tier lower "
                       "bound (empty when untiered); append-only",
                 note="The conformed Price Observation. Holds the product measures because every price, currency and "
                      "coverage measure is over observations. PII tier: none."),
            dict(name="Fee Benchmark Study", role="Entity",
                 objects=[("11", "Fee Benchmark Study"), ("11", "Pricing Input")],
                 pk=["Fee Study ID"],
                 grain="one row = fee benchmark study (subject x fee measure x study date)",
                 note="Read only for its key, subject and measure, with the folded Pricing Input (one recommendation per "
                      "study): this product is the one publisher of the recommended fee range; the benchmark statistics "
                      "are DP-506's. PII tier: none."),
            dict(name="Party", role="Entity", conformed=("DP-240", "Party"), objects=[("02", "Party")],
                 note="Conformed from DP-240: the competitor's organization party (Party Type other than Individual or "
                      "Household, DQ1), source of the name."),
            dict(name="Offering", role="Entity", conformed=("DP-004", "Service Offering"), objects=[],
                 note="Conformed from DP-004: the own offering a competitor offering or fee study is compared with."),
            dict(name="Share Class", role="Entity", conformed=("DP-004", "Share Class"), objects=[],
                 note="Conformed from DP-004: the own share class a fee study benchmarks."),
            dict(name="Investment Strategy", role="Entity", conformed=("DP-004", "Investment Strategy"), objects=[],
                 note="Conformed from DP-004: the own strategies a competitor competes against."),
        ],
        relationships=[
            dict(child="Competitor", parent="Party", fk=["Competitor Party"], card="1:1"),
            dict(child="Competitor", parent="Investment Strategy", fk=["Competing Strategies"], card="M:N",
                 optional=True, note="Multi-valued, split into a bridge at publication."),
            dict(child="Competitor Offering", parent="Competitor", fk=["Offering Competitor"], card="M:1"),
            dict(child="Competitor Offering", parent="Offering", fk=["Comparable Own Offering"], card="M:1",
                 optional=True, note="Mapped to Own Offering % tests the coverage."),
            dict(child="Price Observation", parent="Competitor Offering", fk=["Priced Offering"], card="M:1"),
            dict(child="Fee Benchmark Study", parent="Share Class", fk=["Subject Share Class"], card="M:1",
                 optional=True, note="Exactly one study subject is populated: share class or service offering."),
            dict(child="Fee Benchmark Study", parent="Offering", fk=["Subject Service Offering"], card="M:1",
                 optional=True),
        ],
        notes=("Foundational, modeled ER: competitor, offering and the append-only price observations, with the fee-study "
               "recommendation, on DP-240 parties and DP-004 offerings. Publishes the WP2 shared dimensions Competitor "
               "and Competitor Offering and the Price Observation fact for DP-505, DP-506 and DP-497. PII tier: none. "
               "Competitor Metric Snapshot is DP-505's and is never compared with certified Client Assets here. "
               "Model gap: 11 Pricing Input names no Fee Benchmark Study; it folds into its parent study (spec taxonomy "
               "gap). No Competitor party role exists in 02 (spec taxonomy gap), so the competitor is identified by its "
               "profile."),
    ),
}
