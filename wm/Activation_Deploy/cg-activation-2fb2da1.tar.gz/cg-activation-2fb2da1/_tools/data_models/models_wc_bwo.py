"""Logical data models, wealth WP2 consumer wave, group B3 "BWO" (Brokerage, Cash & Workplace): Star models for the 15
consumer products of specs_w1c_bwo.py that had no model: DP-445, DP-456, DP-435, DP-436, DP-437, DP-438, DP-446, DP-447,
DP-448, DP-452, DP-457, DP-459, DP-460, DP-466 and DP-467. DP-095 and DP-096 keep their models in
models_f4_accounts_plans.py. See CONTRACT.md and Wealth_Manager_Rework_Plan.md section 8.4.

Conventions used in these stars:
- Facts and their companion facts are built from the product's own inputs at the registry key of the foundational
  entity that publishes them (DP-300 Client Holding, DP-301 Client Order, DP-302 Money Movement and so on), not conformed,
  so a fact carries only the columns the product reads and still joins to the foundation on the same natural key. The
  exceptions are facts whose registry key holds attributes the product does not read (06 Measure Value's Data Basis, 16
  Participant Balance's source and option, 13 Confirmation Delivery's fund order, 49 Account Cash Balance's currency in
  DP-446 and DP-457, 50 Money Movement Event's sequence in DP-460) and 10 Cash Program Economics: those are conformed from
  the foundation so the full key is inherited.
- Dimensions are conformed under the plain names of plan section 8.4: Client Account (DP-093 Account), Party roles (DP-240
  Party, named for their role here: Client Party, Venue, Contra Firm, Control Location Party, External Institution),
  Advisor (DP-009 Employee, which holds 03 Advisor), Employee (DP-192), Instrument (DP-097), Share Class and Offering
  (DP-004, or the upstream foundation that republishes 01 Share Class where DP-004 is not upstream), Program Bank and Sweep
  Program (DP-431), Internal Legal Entity roles (DP-013), Calendar Date (DP-013). No foundational model publishes a
  Channel entity; the account channel is the DP-008 06 Account Channel Assignment bridge where a product reads it.
- Objects no foundational model publishes (49 Control Location, 43 Corporate Bank Account, 08 Supervisory Review, 08
  Senior Investor Case, 37 Operational Loss Event, 38 AML Case, 50 Client Cash Forecast, 50 Debit Card) are the
  product's own Dimension or Fact entities.
- Three books of record (CW-007): 49 Client Holding (DP-300) is never joined to an 18 Portfolio Holding or a 06 entity,
  and the 29 Share Register Balance (DP-580) and 16 Participant Balance (DP-430) are separate facts; where a product
  proves one book against another (DP-446 omnibus tie, DP-447 own-fund settlement) the facts meet only through shared
  dimensions at an aggregate grain.
- Client Assets (06, DP-008) are read as their own conformed fact and only compared with operational values (transfers,
  sweep balances, rollovers); no fact adds them to anything (CW-011, CW-230).
- Special category (CD-344): DP-456 and DP-466 hold the special-category rows (Rule 2165 and Rule 2166 holds, hardship and
  Disability distribution types) only in entities named "Restricted ...", which are not published row-level outside the
  restricted roles; their published aggregate facts suppress cells under 10 and apply complementary suppression. Every
  entity that carries personal data names its PII tier in its note.
- A single reference attribute that points to an entity with a composite key is drawn as the foreign key; the rest of
  the key comes from the context named in the relationship note. Multi-valued references are M:N.
- A date attribute on a fact is the foreign key to the conformed DP-013 Calendar Date (keyed by the calendar date in the
  firm business calendar).
"""


def fact(name, objects, pk, grain, note="", measures=False):
    return dict(name=name, role="Fact", objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def own(name, objects, pk, note="", role="Dimension", grain=""):
    d = dict(name=name, role=role, objects=list(objects), pk=list(pk), note=note)
    if grain:
        d["grain"] = grain
    return d


def dim(name, src, objects=(), note="", role="Dimension", grain="", measures=False):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note)
    if grain:
        d["grain"] = grain
    if measures:
        d["measures"] = True
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources
ACCT = ("DP-093", "Account")
ACCTFEAT = ("DP-093", "Account Feature")
ACCTRESTR = ("DP-093", "Account Restriction")
ACCTROLE = ("DP-093", "Account Party Role")
BANKINST = ("DP-093", "Bank Instruction")
SWEEPELECT = ("DP-093", "Cash Sweep Election")
PARTY = ("DP-240", "Party")
TCD = ("DP-240", "Trusted Contact Designation")
CONSENT = ("DP-240", "Consent Record")
ADVISOR = ("DP-009", "Employee")
EMP = ("DP-192", "Employee")
INSTR = ("DP-097", "Instrument")
SHARE = ("DP-004", "Share Class")
OFFER = ("DP-004", "Service Offering")
ILE = ("DP-013", "Internal Legal Entity")
CAL = ("DP-013", "Calendar Date")
MODEL = ("DP-212", "Model")
SWEEP = ("DP-431", "Sweep Program")
PGBANK = ("DP-431", "Program Bank")
MV = ("DP-008", "Measure Value")
SNAP = ("DP-008", "Snapshot")
MDEF = ("DP-008", "Measure Definition")
PLAN = ("DP-094", "Retirement Plan")
PARTICIPANT = ("DP-094", "Participant")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-445": dict(
        style="Star",
        entities=[
            fact("Fact Reserve Computation", [("49", "Reserve Computation")], ["Reserve Computation ID"],
                 grain="one row = computing broker-dealer x computation date x Reserve Computation Type (Customer, PAB); "
                       "daily append-only snapshot of each approved computation",
                 measures=True,
                 note="The certified customer and PAB reserve of SEC Rule 15c3-3(e): its own fact, because it is the one "
                      "published source of the reserve requirement, deposit on hand and deposit or withdrawal due, and "
                      "DP-600 and DP-205 read it by reference and never recompute it (CW-262). The 49 key holds one row "
                      "per broker-dealer, date and type; the product's daily snapshot is the only version history "
                      "(taxonomy gap). PII tier: none (Reserve Computation ID is flagged by the registry tier line only)."),
            fact("Fact Reserve Computation Line", [("49", "Reserve Computation Line")],
                 ["Line Reserve Computation", "Exhibit A Formula Item"],
                 grain="one row = reserve computation x Exhibit A formula item (CREDIT-01 to CREDIT-09, DEBIT-10 to DEBIT-15)",
                 note="Companion rows that prove the computation totals and tie items 1 and 10 to the client cash book. "
                      "PII tier: none."),
            fact("Fact Possession or Control Determination", [("49", "Possession or Control Determination")],
                 ["Determination Instrument", "Determination Business Date", "Deficit Source"],
                 grain="one row = instrument x business date x deficit source",
                 note="SEC Rule 15c3-3(d) and (h) deficits. Carries no price, so the deficit is valued from the client "
                      "holdings fact through Instrument (taxonomy gap). PII tier: none."),
            fact("Fact Client Cash Balance", [("49", "Account Cash Balance")],
                 ["Cash Balance Account", "Cash Balance Currency", "Cash Balance Type", "Balance Basis",
                  "Cash Balance Business Date"],
                 grain="one row = account x currency x cash balance type x balance basis x business date (read from "
                       "DP-300; aggregated to type and date before publication)",
                 note="Free credit and margin debit balances on the settlement-date book, read at the DP-300 Cash Balance "
                      "key and summed to compare with Exhibit A items 1 and 10. Cash Balance Account is never published "
                      "(DQ5). PII tier: financial, input only."),
            fact("Fact Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
                 ["Client Holding ID"],
                 grain="one row = account x instrument x holding date x Holding View (DP-300 Client Holding; End of Day "
                       "rows, aggregated to instrument and date before publication)",
                 note="The 49 client book (CW-007), read for segregated quantity and the unit value that prices a "
                      "deficit; joined only to Instrument and Calendar Date, never to an 18 or 06 entity. Client Holding "
                      "Valuation folds here. Holding Account is never published (DQ5). PII tier: financial, input only."),
            fact("Fact Capital Requirement Calculation", [("43", "Capital Requirement Calculation")],
                 ["Capital Calculation ID"],
                 grain="one row = legal entity x capital regime x as-of date x version (43 net capital calculation)",
                 note="Read directly because no foundational product publishes it; carries the Derived copy of aggregate "
                      "debit items (CW-103) that must equal the approved customer computation. PII tier: none."),
            own("Control Location", [("49", "Control Location")], ["Control Location Party", "Location Effective From"],
                note="Own dimension: no foundational model publishes 49 Control Location. Effective dated (SCD type 2); "
                     "only approved locations in their effective period are good control. PII tier: none (the party is "
                     "a depository, bank or clearing agency)."),
            own("Reserve Bank Account", [("43", "Corporate Bank Account")], ["Corporate Bank Account ID"],
                note="Own dimension: 43 Corporate Bank Account has no foundational model. A bank account is a reserve "
                     "bank account only by being named in Reserve Bank Accounts (taxonomy gap: Bank Account Purpose has "
                     "no special reserve value). The account number is not read. PII tier: none."),
            dim("Computing Broker-Dealer", ILE, [("09", "Internal Legal Entity")],
                note="The firm broker-dealer that computes the reserve, books net capital and holds the reserve accounts."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Control Location Party", PARTY, [("02", "Party")],
                note="Conformed from DP-240 Party: the depository, bank or clearing agency that holds the securities."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Reserve Computation", "Computing Broker-Dealer", ["Computing Broker-Dealer"]),
            rel("Fact Reserve Computation", "Calendar Date", ["Computation Date"]),
            rel("Fact Reserve Computation", "Reserve Bank Account", ["Reserve Bank Accounts"], card="M:N",
                note="Multi-valued: the special reserve bank accounts the deposit on hand is held in."),
            rel("Reserve Bank Account", "Computing Broker-Dealer", ["Account Holder Entity"]),
            rel("Fact Reserve Computation Line", "Fact Reserve Computation", ["Line Reserve Computation"]),
            rel("Fact Reserve Computation Line", "Fact Client Cash Balance", ["Supporting Cash Balance Type"], card="M:N",
                optional=True,
                note="Supporting Cash Balance Type matches Cash Balance Type (Free Credit Balance for item 1, Margin "
                     "Debit Balance for item 10) on the computation date; the tie-out is made on aggregates."),
            rel("Fact Capital Requirement Calculation", "Fact Reserve Computation", ["Reserve Computation"],
                optional=True, note="The approved customer computation that net capital uses (CW-103)."),
            rel("Fact Capital Requirement Calculation", "Computing Broker-Dealer", ["Calculation Entity"]),
            rel("Fact Possession or Control Determination", "Instrument", ["Determination Instrument"]),
            rel("Fact Possession or Control Determination", "Calendar Date", ["Determination Business Date"]),
            rel("Fact Possession or Control Determination", "Control Location", ["Control Locations Counted"],
                card="M:N", note="Multi-valued: the locations whose quantity counted as good control."),
            rel("Control Location", "Control Location Party", ["Control Location Party"]),
            rel("Fact Client Holding", "Instrument", ["Held Instrument"]),
            rel("Fact Client Holding", "Calendar Date", ["Client Holding Date"]),
            rel("Fact Client Cash Balance", "Calendar Date", ["Cash Balance Business Date"]),
        ],
        notes=("Daily SEC Rule 15c3-3 control pack as a constellation: the certified Reserve Computation is its own fact "
               "with its Exhibit A lines, and the possession-or-control determinations sit at instrument x date x "
               "deficit source. The DP-300 client books (cash balances, End of Day client holdings) are inputs to "
               "aggregate proofs only and are never published by account (DQ5). Client Holding joins only Instrument "
               "and Calendar Date (CW-007). The 43 net capital calculation and corporate bank accounts are read "
               "directly because no foundation publishes them; DP-205 and DP-600 read this product, so they are not "
               "upstream. Computing Broker-Dealer is conformed from DP-013 Internal Legal Entity, Instrument from DP-097, "
               "Control Location Party from DP-240. Own dimensions: Control Location and Reserve Bank Account (no "
               "foundational model). No special-category data; pii = N per the spec, the account-level inputs being "
               "aggregated before publication."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-456": dict(
        style="Star",
        entities=[
            fact("Restricted Money Movement Hold", [("50", "Money Movement Hold")], ["Money Movement Hold ID"],
                 grain="one row = money movement hold (MMHLD-) x as-of business date (daily snapshot of open and recently "
                       "closed holds)",
                 measures=True,
                 note="The restricted row-level view (Restricted - Personal Data) for the money movement, senior investor "
                      "and compliance roles: it holds the special-category rows (FINRA Rule 2165 Disbursement Hold, Rule "
                      "2166 Temporary Delay, special-category Hold Reason) that DP-302 suppresses (CW-213, CW-231, "
                      "CD-344). Kept as its own entity, not conformed from DP-322 Money Movement Hold: the spec reads "
                      "the 50 hold rows directly (F3 ruling) and takes only Protection Flag Present from DP-322. The "
                      "measures sit here because the Rule 2165 clock measures exist only in this view; the "
                      "non-special counts are republished through Fact Non-Special Hold Aggregate. Hold Reason is "
                      "restricted to this entity. PII tier: special category."),
            fact("Fact Non-Special Hold Aggregate", [], ["Fact Non-Special Hold Aggregate Key"],
                 grain="one row = Hold Type x hold age bucket x outcome x as-of date, over holds that are not special "
                       "category (minimum cell 10 holds)",
                 note="The aggregate view for every other role: only Active Money Movement Holds (from DP-302) and their "
                      "amounts, with no total, Protection category or difference from which the special-category count "
                      "could be derived; cells under 10 holds are suppressed and a suppressed cell is protected by "
                      "suppressing a further cell (complementary suppression, DQ5, lead ruling 2). Built from the "
                      "restricted hold rows, so it has no input object of its own. PII tier: none published."),
            fact("Fact Money Movement", [("50", "Money Movement")], ["Money Movement ID"],
                 grain="one row = held money movement (MMVMT-), read from DP-302",
                 note="Amount on Hold is the full Movement Amount (taxonomy gap: no held amount). The Bank Instruction "
                      "Used key is masked outside the restricted view. PII tier: financial."),
            fact("Fact Fraud Risk Assessment", [("50", "Fraud Risk Assessment")],
                 ["Assessed Movement", "Assessment Timestamp"],
                 grain="one row = money movement x assessment timestamp",
                 note="Fraud Risk Score is produced by the DP-212 model named in Fraud Model (CD-294); read, never "
                      "re-scored. PII tier: financial."),
            fact("Fact Bank Account Verification", [("50", "Bank Account Verification Event")],
                 ["Verified Bank Instruction", "Verification Attempt Number"],
                 grain="one row = bank instruction x verification attempt",
                 note="Moved read from backlog DP-455. Account Owner Name Matched is a result flag; no name is read. "
                      "PII tier: financial."),
            dim("Restricted Senior Investor Case", ("DP-403", "Senior Investor Case"), [("08", "Senior Investor Case")],
                note="Conformed from DP-403's restricted view (keyed on the 08 case ID); read for its key, status and "
                     "closed date only, never re-scored. Restricted: the existence of a case reveals suspected "
                     "exploitation. PII tier: special category."),
            dim("Restricted External Protection Report", ("DP-403", "External Protection Report"),
                [("08", "External Protection Report")], role="Fact",
                grain="one row = senior investor case x recipient type x agency x report date",
                note="Conformed from DP-403 so the full registry key (Reported Case, Report Recipient Type, Recipient "
                     "Agency, Report Date) is inherited; feeds the Rule 2165 extension that DP-403 owns. PII tier: "
                     "special category."),
            dim("Client Account", ACCT, [("15", "Account")], note="PII tier: financial."),
            dim("Paired Account Restriction", ACCTRESTR, [("15", "Account Restriction")],
                note="Conformed from DP-093: the securities or whole-account restriction paired with a hold (shown only "
                     "when paired). PII tier: financial."),
            dim("Account Party Role", ACCTROLE, [("15", "Account Party Role")], role="Bridge",
                grain="one row = account x party x account role type x role effective period",
                note="Conformed from DP-093: account-to-client many-to-many, effective dated; the join DP-322's "
                     "Protection Flag Present is traced on. PII tier: identity."),
            dim("Client Party", PARTY, [("02", "Party")],
                note="Conformed from DP-240. 02 Specified Adult Status and Vulnerability Concern are never read; the "
                     "protection cause reaches this product only through DP-322 measures. PII tier: identity."),
            dim("Trusted Contact Designation", TCD, [("02", "Trusted Contact Designation")],
                note="Conformed from DP-240 (FINRA Rule 4512). PII tier: identity."),
            dim("Bank Instruction", BANKINST,
                note="Conformed from DP-093 for the verification and movement link; bank routing and account number "
                     "columns are DP-093 restricted columns and are not read here. PII tier: financial."),
            dim("Fraud Model", MODEL, note="Conformed from DP-212 model inventory (CD-294)."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Restricted Money Movement Hold", "Fact Money Movement", ["Held Movement"]),
            rel("Restricted Money Movement Hold", "Fact Non-Special Hold Aggregate", ["Fact Non-Special Hold Aggregate Key"],
                optional=True,
                note="Only non-special holds roll up to an aggregate cell; special-category holds carry no aggregate key."),
            rel("Restricted Money Movement Hold", "Trusted Contact Designation", ["Trusted Contact Notified"], optional=True),
            rel("Restricted Money Movement Hold", "Paired Account Restriction", ["Paired Account Restriction"],
                optional=True),
            rel("Restricted Money Movement Hold", "Restricted Senior Investor Case", ["Senior Investor Case"],
                optional=True, note="Populated on every Rule 2165 hold older than two business days (DQ4)."),
            rel("Restricted Money Movement Hold", "Calendar Date", ["Hold Placed Date"]),
            rel("Restricted External Protection Report", "Restricted Senior Investor Case", ["Reported Case"]),
            rel("Fact Fraud Risk Assessment", "Fact Money Movement", ["Assessed Movement"]),
            rel("Fact Fraud Risk Assessment", "Restricted Money Movement Hold", ["Resulting Hold"], optional=True),
            rel("Fact Fraud Risk Assessment", "Fraud Model", ["Fraud Model"],
                note="Fraud Model carries the model ID; the version in force at the assessment timestamp completes the "
                     "DP-212 key."),
            rel("Fact Money Movement", "Client Account", ["Movement Account"]),
            rel("Fact Money Movement", "Bank Instruction", ["Bank Instruction Used"], optional=True),
            rel("Fact Bank Account Verification", "Bank Instruction", ["Verified Bank Instruction"]),
            rel("Paired Account Restriction", "Client Account", ["Restricted Account"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Client Party", ["Role Party"]),
            rel("Trusted Contact Designation", "Client Party", ["Designating Client"]),
        ],
        notes=("Cash-movement fraud and elder-exploitation holds (CW-264). Two outputs: the restricted row-level view, "
               "whose hold, senior investor case and protection report entities are named Restricted and carry the "
               "special-category rows (CD-344, CW-213, CW-231); and the aggregate view (Fact Non-Special Hold Aggregate) "
               "that carries only non-special counts and amounts with minimum cell 10 and complementary suppression. "
               "The Rule 2165 clock and Protection Flag Present are read from DP-403 and DP-322 as measures; the senior "
               "investor case is conformed from DP-403, while the hold rows stay this product's own (read from 50 "
               "directly per the F3 ruling, not through DP-322's view). AML holds are excluded at ingestion (DP-460, "
               "DP-226). Conformed: Client Account, Paired Account Restriction, Account Party Role and Bank Instruction "
               "from DP-093; Client Party and Trusted Contact Designation from DP-240; Fraud Model from DP-212; Calendar "
               "Date from DP-013. Restricted External Protection Report is conformed from DP-403 with its full key."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-435": dict(
        style="Star",
        entities=[
            fact("Fact Client Order", [("48", "Client Order"), ("48", "Order Instruction Detail")], ["Client Order ID"],
                 grain="one row = client order (CLORD-) x trade date; daily snapshot of open exceptions",
                 measures=True,
                 note="The lifecycle row, read at the DP-301 key; Order Instruction Detail folds here. Holds the CAT "
                      "completeness and market-access measures this product owns. PII tier: financial."),
            fact("Fact Option Order Leg", [("48", "Option Order Leg")], ["Leg Client Order", "Leg Sequence Number"],
                 grain="one row = client order x leg sequence", note="PII tier: financial."),
            fact("Fact Client Order Event", [("48", "Client Order Event")], ["Event Client Order", "Event Sequence Number"],
                 grain="one row = client order x event sequence",
                 note="Event sequence breaks and terminal status. PII tier: financial."),
            fact("Fact Order Route", [("48", "Order Route")], ["Order Route ID"],
                 grain="one row = client order or client block order x route sequence (ROUTE-)",
                 note="PII tier: financial."),
            fact("Fact Client Execution", [("48", "Client Execution")], ["Client Execution ID"],
                 grain="one row = client execution (one fill on one order route)", note="PII tier: financial."),
            fact("Fact Client Allocation", [("48", "Client Allocation")],
                 ["Allocation Client Block Order", "Allocated Client Order", "Allocated Account"],
                 grain="one row = client block order or client order x allocated account", note="PII tier: financial."),
            fact("Fact CAT Reportable Event", [("48", "CAT Reportable Event")], ["CAT Record ID"],
                 grain="one row = CAT reportable event record (one per order, route, execution or allocation event)",
                 note="Carries the Firm Designated ID only, no customer identifying information (CW-115). PII tier: "
                      "financial."),
            fact("Fact Order Eligibility Check", [("48", "Order Eligibility Check")],
                 ["Checked Client Order", "Eligibility Check Type"],
                 grain="one row = client order x eligibility check type",
                 note="Read directly (no foundation publishes it; moved from backlog DP-439). The 02 Client Restriction "
                      "and 38 Restricted List Entry it checks are carried as keys (CW-099); their products are not "
                      "upstream. PII tier: financial."),
            dim("Pre-Trade Risk Limit", ("DP-301", "Pre-Trade Risk Limit"), [("48", "Pre-Trade Risk Limit")],
                note="Conformed from DP-301; effective dated (SCD type 2) reference companion for SEC Rule 15c3-5."),
            dim("Client Block Order", ("DP-301", "Client Block Order"), [("48", "Client Block Order")]),
            dim("Client Account", ACCT, [("15", "Account")], note="PII tier: financial."),
            dim("Instrument", INSTR, [("17", "Instrument")],
                note="Order instrument and, through the leg relationship, the option series."),
            dim("Venue", ("DP-432", "Party"),
                note="Conformed from DP-432 Party: the venue party a route goes to (DP-240 is not upstream)."),
            dim("Routing Rule", ("DP-432", "Routing Rule")),
            dim("Account Feature", ACCTFEAT, note="The options or margin approval checked at order time."),
            dim("Account Restriction", ACCTRESTR, note="The account restriction checked at order time."),
            dim("Employee", EMP,
                note="Conformed from DP-192: entering employee, override approver and limit approver. National "
                     "identifier columns are DP-192 restricted columns. PII tier: identity."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Client Order", "Client Account", ["Order Account"]),
            rel("Fact Client Order", "Instrument", ["Order Instrument"]),
            rel("Fact Client Order", "Employee", ["Entering Employee"], optional=True),
            rel("Fact Option Order Leg", "Fact Client Order", ["Leg Client Order"]),
            rel("Fact Option Order Leg", "Instrument", ["Leg Option Series"]),
            rel("Fact Client Order Event", "Fact Client Order", ["Event Client Order"]),
            rel("Fact Order Route", "Fact Client Order", ["Routed Client Order"], optional=True),
            rel("Fact Order Route", "Client Block Order", ["Routed Client Block Order"], optional=True),
            rel("Fact Order Route", "Venue", ["Route Venue"]),
            rel("Fact Order Route", "Routing Rule", ["Applied Routing Rule"], optional=True,
                note="The rule version in force at Routed Timestamp completes the key."),
            rel("Fact Client Execution", "Fact Order Route", ["Execution Order Route"]),
            rel("Fact Client Execution", "Calendar Date", ["Execution Trade Date"]),
            rel("Fact Client Allocation", "Client Block Order", ["Allocation Client Block Order"], optional=True),
            rel("Fact Client Allocation", "Fact Client Order", ["Allocated Client Order"], optional=True),
            rel("Fact Client Allocation", "Client Account", ["Allocated Account"]),
            rel("Fact CAT Reportable Event", "Fact Client Order", ["CAT Source Client Order"], optional=True),
            rel("Fact CAT Reportable Event", "Fact Order Route", ["CAT Source Order Route"], optional=True),
            rel("Fact CAT Reportable Event", "Fact Client Execution", ["CAT Source Client Execution"], optional=True),
            rel("Fact CAT Reportable Event", "Fact Client Allocation", ["CAT Source Client Allocation"], optional=True,
                note="Single reference to the composite allocation key; the source order and account complete it."),
            rel("Fact CAT Reportable Event", "Calendar Date", ["CAT Submission Date"]),
            rel("Fact Order Eligibility Check", "Fact Client Order", ["Checked Client Order"]),
            rel("Fact Order Eligibility Check", "Account Feature", ["Checked Account Feature"], optional=True),
            rel("Fact Order Eligibility Check", "Account Restriction", ["Checked Account Restriction"], optional=True),
            rel("Fact Order Eligibility Check", "Pre-Trade Risk Limit", ["Applied Pre-Trade Risk Limit"], optional=True,
                note="Single reference to the composite limit key; the limit version in force at Check Timestamp."),
            rel("Fact Order Eligibility Check", "Employee", ["Override Approver"], optional=True),
            rel("Pre-Trade Risk Limit", "Client Account", ["Limit Scope Account"], optional=True),
            rel("Pre-Trade Risk Limit", "Employee", ["Limit Approved By"], optional=True),
        ],
        notes=("Order lifecycle and CAT completeness: the order, its events, legs, routes, executions, allocations and CAT "
               "records are facts at their own grain read from DP-301 at its keys; the order eligibility checks are read "
               "directly. Conformed: Pre-Trade Risk Limit and Client Block Order from DP-301, Venue (Party) and Routing "
               "Rule from DP-432, Client Account, Account Feature and Account Restriction from DP-093, Instrument from "
               "DP-097, Employee from DP-192, Calendar Date from DP-013. External references kept as attributes: Checked "
               "Client Restriction (02, DP-240 not upstream) and Checked Restricted List Entry (38). No special-category "
               "data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-436": dict(
        style="Star",
        entities=[
            fact("Fact Execution Quality Measure", [("48", "Execution Quality Measure")],
                 ["Measure Period Start", "Measure Period End", "Measure Order Class", "Measure Client Order Type",
                  "Measured Venue"],
                 grain="one row = measurement period x order class x client order type x venue",
                 measures=True,
                 note="The 48 statistics are computed in 48 (CW-100) and published and compared here, never recomputed. "
                      "PII tier: none."),
            fact("Fact Rule 605 Report Line", [("48", "Rule 605 Report Line")],
                 ["Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Security", "Rule 605 Order Type",
                  "Rule 605 Order Size Bucket"],
                 grain="one row = reporting broker-dealer x month x security x Rule 605 order type x size bucket",
                 note="Read from DP-432 at its key. PII tier: none."),
            fact("Fact Rule 606 Report Line", [("48", "Rule 606 Report Line")],
                 ["Rule 606 Reporting Entity", "Rule 606 Report Quarter", "Rule 606 Report Month", "Rule 606 Order Class",
                  "Rule 606 Venue"],
                 grain="one row = reporting broker-dealer x quarter x month x Rule 606 order class x venue",
                 note="Read directly (no foundation publishes it). PII tier: none."),
            fact("Fact Routing Disclosure Request", [("48", "Order Routing Disclosure Request")],
                 ["Requesting Party", "Request Account", "Request Received Date"],
                 grain="one row = customer request under Rule 606(b)(1) or (b)(3)",
                 note="Restricted view (DQ5). PII tier: identity."),
            fact("Fact Order Route", [("48", "Order Route")], ["Order Route ID"],
                 grain="one row = order route (ROUTE-), with the NBBO at route", note="PII tier: financial."),
            fact("Fact Client Execution", [("48", "Client Execution")], ["Client Execution ID"],
                 grain="one row = client execution (one fill on one order route)", note="PII tier: financial."),
            fact("Fact Client Order", [("48", "Client Order"), ("48", "Order Instruction Detail")], ["Client Order ID"],
                 grain="one row = client order (CLORD-), for the NBBO midpoint at receipt and order type",
                 note="Order Instruction Detail folds here. PII tier: financial."),
            fact("Fact Quote Observation", [("22", "Price Observation")], ["Price Observation Key"],
                 grain="one row = instrument x price type (Bid, Ask) x price origin x source x as-of timestamp",
                 note="The quote snapshot approximated by 22 Price Observation Bid and Ask rows (taxonomy gap: no NBBO "
                      "snapshot object); read directly because DP-143 publishes approved prices, not observations. "
                      "PII tier: none."),
            own("Committee Review", [("08", "Supervisory Review")], ["Supervisory Review ID"],
                note="Own dimension: no foundational model publishes 08 Supervisory Review; read for key, type, outcome "
                     "and date only, never re-scored. PII tier: none published (reviewer not read)."),
            dim("Execution Venue", ("DP-432", "Execution Venue"), [("48", "Execution Venue Profile")],
                note="Conformed from DP-432; effective dated venue profile (affiliation, payment for order flow)."),
            dim("Routing Rule", ("DP-432", "Routing Rule"), [("48", "Routing Rule")]),
            dim("Venue", PARTY, note="Conformed from DP-240 Party in the venue role."),
            dim("Requesting Client", PARTY, note="Conformed from DP-240 Party: the Rule 606(b) requester. PII tier: identity."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Instrument", INSTR),
            dim("Reporting Broker-Dealer", ILE),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Execution Quality Measure", "Venue", ["Measured Venue"]),
            rel("Fact Execution Quality Measure", "Committee Review", ["Reviewing Committee Review"], optional=True),
            rel("Fact Rule 605 Report Line", "Reporting Broker-Dealer", ["Rule 605 Reporting Entity"]),
            rel("Fact Rule 605 Report Line", "Instrument", ["Rule 605 Security"]),
            rel("Fact Rule 606 Report Line", "Reporting Broker-Dealer", ["Rule 606 Reporting Entity"]),
            rel("Fact Rule 606 Report Line", "Venue", ["Rule 606 Venue"]),
            rel("Fact Routing Disclosure Request", "Requesting Client", ["Requesting Party"]),
            rel("Fact Routing Disclosure Request", "Client Account", ["Request Account"]),
            rel("Fact Routing Disclosure Request", "Calendar Date", ["Request Received Date"]),
            rel("Execution Venue", "Venue", ["Venue Party"]),
            rel("Routing Rule", "Venue", ["Primary Venue"], optional=True),
            rel("Routing Rule", "Committee Review", ["Approving Review"], optional=True),
            rel("Committee Review", "Routing Rule", ["Reviewed Routing Rule"], optional=True,
                note="The rule version in force at Review Completed Date completes the key."),
            rel("Committee Review", "Execution Venue", ["Reviewed Execution Venue"], optional=True,
                note="The venue profile in force at Review Completed Date completes the key."),
            rel("Fact Order Route", "Fact Client Order", ["Routed Client Order"], optional=True),
            rel("Fact Order Route", "Venue", ["Route Venue"]),
            rel("Fact Order Route", "Routing Rule", ["Applied Routing Rule"], optional=True),
            rel("Fact Client Execution", "Fact Order Route", ["Execution Order Route"]),
            rel("Fact Client Execution", "Calendar Date", ["Execution Trade Date"]),
            rel("Fact Client Order", "Instrument", ["Order Instrument"]),
            rel("Fact Quote Observation", "Instrument", ["Observed Instrument"],
                note="Matched to a route on instrument and the nearest Observation As-Of Timestamp to Routed Timestamp."),
        ],
        notes=("Execution quality and routing (Rules 605 and 606): the 48 Execution Quality Measure, Rule 605 and 606 "
               "lines and disclosure requests are facts at their own grain, with the routes, executions and orders from "
               "DP-301 and the 22 quote observations as companions. Conformed: Execution Venue and Routing Rule from "
               "DP-432, Venue and Requesting Client from DP-240 Party, Client Account from DP-093, Instrument from DP-097, "
               "Reporting Broker-Dealer and Calendar Date from DP-013. Own dimension: Committee Review (08). The Rule "
               "606(b) requester rows are the only personal data and sit in a restricted view. No special-category "
               "data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-437": dict(
        style="Star",
        entities=[
            fact("Fact Trade Correction", [("48", "Trade Correction")], ["Trade Correction ID"],
                 grain="one row = trade correction (TCORR-); append-only",
                 measures=True,
                 note="Read from DP-301 at its key; holds the correction and error measures. The correction month is "
                      "taken from the resulting confirmation's trade date (taxonomy gap: no correction date). PII tier: "
                      "financial."),
            fact("Fact Trade Error Case", [("48", "Trade Error Case")], ["Trade Error Case Number"],
                 grain="one row = trade error case (case number); monthly snapshot of open cases",
                 note="Read directly (no foundation publishes it). The loss is booked in 37 and published by DP-215; it "
                      "is linked, never booked here. PII tier: financial."),
            fact("Fact Client Trade Confirmation", [("48", "Client Trade Confirmation")], ["Client Trade Confirmation ID"],
                 grain="one row = client allocation x confirmation version (CCONF-)",
                 note="The superseded and resulting confirmation versions of a correction. PII tier: financial."),
            fact("Fact Client Allocation", [("48", "Client Allocation")],
                 ["Allocation Client Block Order", "Allocated Client Order", "Allocated Account"],
                 grain="one row = client block order or client order x allocated account", note="PII tier: financial."),
            fact("Fact Client Execution", [("48", "Client Execution")], ["Client Execution ID"],
                 grain="one row = client execution", note="Venue busts by venue. PII tier: financial."),
            fact("Fact Client Order", [("48", "Client Order"), ("48", "Order Instruction Detail")], ["Client Order ID"],
                 grain="one row = client order (CLORD-)",
                 note="Order source and client order type for the correction cuts; Order Instruction Detail folds here. "
                      "PII tier: financial."),
            own("Operational Loss Event", [("37", "Operational Loss Event")], ["Loss Event ID"],
                note="Own dimension: DP-215, which publishes loss events, is a consumer product with no foundational "
                     "model to conform from. PII tier: none."),
            dim("Order Route", ("DP-301", "Order Route"),
                note="Conformed from DP-301 to reach the venue of an execution."),
            dim("Client Block Order", ("DP-301", "Client Block Order")),
            dim("Venue", ("DP-432", "Party"), note="Conformed from DP-432 Party in the venue role."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Approver", EMP, note="Conformed from DP-192 Employee: the correction approver. PII tier: identity."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Trade Correction", "Fact Client Execution", ["Corrected Client Execution"], optional=True),
            rel("Fact Trade Correction", "Fact Client Allocation", ["Corrected Client Allocation"], optional=True,
                note="Single reference to the composite allocation key."),
            rel("Fact Trade Correction", "Approver", ["Correction Approved By"], optional=True),
            rel("Fact Trade Correction", "Fact Client Trade Confirmation", ["Resulting Confirmation"], optional=True),
            rel("Fact Trade Correction", "Fact Trade Error Case", ["Related Trade Error Case"], optional=True),
            rel("Fact Trade Error Case", "Fact Client Order", ["Error Client Order"], optional=True),
            rel("Fact Trade Error Case", "Client Block Order", ["Error Client Block Order"], optional=True),
            rel("Fact Trade Error Case", "Client Account", ["Error Account"], optional=True,
                note="The firm error account the position was booked to."),
            rel("Fact Trade Error Case", "Operational Loss Event", ["Related Loss Event"], optional=True),
            rel("Fact Trade Error Case", "Calendar Date", ["Error Detected Date"]),
            rel("Fact Client Trade Confirmation", "Fact Client Allocation", ["Confirmed Client Allocation"]),
            rel("Fact Client Trade Confirmation", "Fact Client Trade Confirmation", ["Superseded Confirmation"],
                optional=True, note="The prior version this confirmation supersedes."),
            rel("Fact Client Trade Confirmation", "Fact Trade Correction", ["Originating Trade Correction"], optional=True),
            rel("Fact Client Allocation", "Client Block Order", ["Allocation Client Block Order"], optional=True),
            rel("Fact Client Allocation", "Fact Client Order", ["Allocated Client Order"], optional=True),
            rel("Fact Client Allocation", "Client Account", ["Allocated Account"]),
            rel("Fact Client Execution", "Order Route", ["Execution Order Route"]),
            rel("Fact Client Execution", "Calendar Date", ["Execution Trade Date"]),
            rel("Order Route", "Venue", ["Route Venue"]),
            rel("Order Route", "Fact Client Order", ["Routed Client Order"], optional=True),
            rel("Fact Client Order", "Client Account", ["Order Account"]),
        ],
        notes=("Trade corrections and trade error cases as the two main facts, each joined to the order, execution and "
               "allocation it concerns and to the superseded and resulting confirmations. Conformed: Order Route and "
               "Client Block Order from DP-301, Venue from DP-432 Party, Client Account from DP-093, Approver from DP-192 "
               "Employee, Calendar Date from DP-013. Own dimension: Operational Loss Event (37; DP-215 is a consumer). "
               "No special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-438": dict(
        style="Star",
        entities=[
            fact("Fact Client Trade Confirmation",
                 [("48", "Client Trade Confirmation"), ("48", "Confirmation Remuneration Disclosure")],
                 ["Client Trade Confirmation ID"],
                 grain="one row = client allocation x confirmation version (CCONF-); daily, append-only",
                 measures=True,
                 note="Read from DP-301 at its key; Confirmation Remuneration Disclosure (markup, prevailing market "
                      "price) folds here and is read directly because no foundation publishes it. PII tier: financial."),
            fact("Fact Regulatory Trade Report", [("48", "Regulatory Trade Report")],
                 ["Reported Client Execution", "Trade Reporting Facility", "Report Submission Timestamp"],
                 grain="one row = client execution x trade reporting facility x submission",
                 note="Read directly (no foundation publishes it). PII tier: none."),
            fact("Fact Client Execution", [("48", "Client Execution")], ["Client Execution ID"],
                 grain="one row = client execution", note="PII tier: financial."),
            dim("Fact Confirmation Delivery", ("DP-382", "Confirmation Delivery"), [("13", "Confirmation Delivery")],
                role="Fact", grain="one row = investor document x confirmed client trade confirmation or fund order",
                note="Conformed from DP-382 so its full key (with Confirmed Fund Order, not an input here) is inherited; "
                     "the delivery is 13's (CW-081, CW-098). PII tier: financial."),
            dim("Client Order", ("DP-301", "Client Order"),
                [("48", "Fixed Income Order Detail"), ("48", "Fund Order Detail")],
                note="Conformed from DP-301: the folded Fixed Income Order Detail and Fund Order Detail groups are read "
                     "without their parent object, so they sit on the conformed order that holds the key. PII tier: "
                     "financial."),
            dim("Client Allocation", ("DP-301", "Client Allocation"),
                note="Conformed from DP-301 to reach the order from a confirmation."),
            dim("Order Route", ("DP-301", "Order Route"),
                note="Conformed from DP-301 to reach the order from an execution."),
            dim("Approved Price", ("DP-143", "Approved Price"), [("22", "Approved Price")],
                note="The 22 approved price the prevailing market price is checked against."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Fund Share Class", SHARE, [("01", "Share Class")],
                note="Conformed from DP-004: the share class of a fund order in a brokerage account."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Client Trade Confirmation", "Client Allocation", ["Confirmed Client Allocation"]),
            rel("Fact Client Trade Confirmation", "Client Account", ["Confirmation Account"]),
            rel("Fact Client Trade Confirmation", "Instrument", ["Confirmed Instrument"]),
            rel("Fact Client Trade Confirmation", "Calendar Date", ["Confirmed Trade Date"]),
            rel("Fact Client Trade Confirmation", "Fact Client Trade Confirmation", ["Superseded Confirmation"],
                optional=True),
            rel("Fact Client Trade Confirmation", "Approved Price", ["Reference Approved Price"], optional=True),
            rel("Fact Confirmation Delivery", "Fact Client Trade Confirmation", ["Client Trade Confirmation"],
                optional=True, note="Null for a fund order confirmation."),
            rel("Fact Regulatory Trade Report", "Fact Client Execution", ["Reported Client Execution"]),
            rel("Fact Client Execution", "Order Route", ["Execution Order Route"]),
            rel("Order Route", "Client Order", ["Routed Client Order"], optional=True),
            rel("Client Allocation", "Client Order", ["Allocated Client Order"], optional=True),
            rel("Client Order", "Fund Share Class", ["Fund Order Share Class"], optional=True),
            rel("Client Order", "Instrument", ["Order Instrument"]),
            rel("Client Order", "Client Account", ["Order Account"]),
            rel("Approved Price", "Instrument", ["Priced Instrument"]),
        ],
        notes=("Confirmations (SEC Rule 10b-10, FINRA Rule 2232) and regulatory trade reports (TRACE, TRF, RTRS) as the "
               "two main facts, with the 13 delivery as a conformed DP-382 fact. Conformed: Client Order, Client "
               "Allocation and Order Route from DP-301, Fact Confirmation Delivery from DP-382, Approved Price from "
               "DP-143, Instrument from DP-097, Fund Share Class from DP-004, Client Account from DP-093, Calendar Date "
               "from DP-013. Originating Trade Correction stays an attribute (corrections are DP-437's). No "
               "special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-446": dict(
        style="Star",
        entities=[
            fact("Fact Stock Record Reconciliation", [("49", "Stock Record Reconciliation")],
                 ["Reconciliation Broker-Dealer", "Stock Record Reconciliation Type", "Reconciliation Business Date",
                  "Reconciled Control Location", "Reconciled Sweep Program"],
                 grain="one row = reconciliation type x business date x control location or sweep program; daily",
                 measures=True,
                 note="Read directly (no foundation publishes it). PII tier: none."),
            fact("Fact Stock Record Break", [("49", "Stock Record Break")], ["Break Reconciliation", "Break Sequence"],
                 grain="one row = stock record reconciliation x break sequence",
                 note="Break Account is restricted (DQ5). PII tier: financial."),
            fact("Fact Security Count", [("49", "Security Count")],
                 ["Count Broker-Dealer", "Count Quarter", "Counted Control Location", "Count Date"],
                 grain="one row = broker-dealer x quarter x control location x count date (SEC Rule 17a-13)",
                 note="PII tier: none."),
            dim("Fact Client Cash Balance", ("DP-300", "Cash Balance"), [("49", "Account Cash Balance")], role="Fact",
                grain="one row = account x currency x cash balance type x balance basis x business date (from DP-300)",
                note="Conformed from DP-300 so its full key is inherited (Cash Balance Currency is not an input). The "
                     "sweep balance side of the sweep tie. PII tier: financial (restricted, DQ5)."),
            fact("Fact Client Holding", [("49", "Client Holding")], ["Client Holding ID"],
                 grain="one row = account x instrument x holding date x Holding View (from DP-300)",
                 note="The 49 client book of own-fund shares for the omnibus tie (CW-007). It is never joined row to row "
                      "with the register fact: the tie compares settled quantity summed by share class with registered "
                      "shares summed by share class on the same date. PII tier: financial."),
            fact("Fact Sweep Allocation", [("50", "Sweep Allocation")],
                 ["Allocation Account", "Allocation Program Bank", "Allocation Business Date"],
                 grain="one row = account x program bank x business date (from DP-302)",
                 note="PII tier: financial (restricted, DQ5)."),
            fact("Fact Program Bank Daily Total", [("50", "Program Bank Daily Total")],
                 ["Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date"],
                 grain="one row = sweep program x program bank x business date (from DP-431)", note="PII tier: none."),
            fact("Fact Register Position", [("29", "Share Register Balance")],
                 ["Register Account", "Register Share Class", "Register Business Date"],
                 grain="one row = registered account x share class x business date (from DP-580)",
                 note="The 29 share register, a separate book (CW-007, CW-102); the brokerage omnibus account's "
                      "registered shares are compared with the 49 client book by share class. PII tier: financial."),
            own("Control Location", [("49", "Control Location")], ["Control Location Party", "Location Effective From"],
                note="Own dimension: no foundational model publishes 49 Control Location. PII tier: none."),
            dim("Control Location Party", PARTY, note="Conformed from DP-240 Party."),
            dim("Broker-Dealer", ILE),
            dim("Sweep Program", SWEEP),
            dim("Program Bank", PGBANK),
            dim("Share Class", ("DP-097", "Share Class"),
                note="Conformed from DP-097, which republishes 01 Share Class. Model gap: the spec names DP-004 for the "
                     "share class dimension but DP-004 is not in its upstream."),
            dim("Instrument", INSTR, [("17", "Instrument")]),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Employee", EMP, note="Conformed from DP-192: break owner, sign-off and count performer."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Stock Record Reconciliation", "Broker-Dealer", ["Reconciliation Broker-Dealer"]),
            rel("Fact Stock Record Reconciliation", "Control Location", ["Reconciled Control Location"], optional=True,
                note="The location version in force on the business date completes the key."),
            rel("Fact Stock Record Reconciliation", "Sweep Program", ["Reconciled Sweep Program"], optional=True),
            rel("Fact Stock Record Reconciliation", "Fact Register Position", ["Reconciled Register Balances"],
                card="M:N", optional=True, note="Multi-valued reference to the register balances of the omnibus tie."),
            rel("Fact Stock Record Reconciliation", "Employee", ["Reconciliation Signed Off By"], optional=True),
            rel("Fact Stock Record Reconciliation", "Calendar Date", ["Reconciliation Business Date"]),
            rel("Fact Stock Record Break", "Fact Stock Record Reconciliation", ["Break Reconciliation"],
                note="Single reference to the composite reconciliation key."),
            rel("Fact Stock Record Break", "Instrument", ["Break Instrument"], optional=True),
            rel("Fact Stock Record Break", "Client Account", ["Break Account"], optional=True),
            rel("Fact Stock Record Break", "Employee", ["Break Owner"], optional=True),
            rel("Fact Security Count", "Broker-Dealer", ["Count Broker-Dealer"]),
            rel("Fact Security Count", "Control Location", ["Counted Control Location"]),
            rel("Fact Security Count", "Employee", ["Count Performed By"], optional=True),
            rel("Control Location", "Control Location Party", ["Control Location Party"]),
            rel("Fact Client Cash Balance", "Client Account", ["Cash Balance Account"]),
            rel("Fact Client Cash Balance", "Sweep Program", ["Balance Sweep Program"], optional=True),
            rel("Fact Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Client Holding", "Instrument", ["Held Instrument"]),
            rel("Fact Sweep Allocation", "Client Account", ["Allocation Account"]),
            rel("Fact Sweep Allocation", "Program Bank", ["Allocation Program Bank"]),
            rel("Fact Program Bank Daily Total", "Sweep Program", ["Daily Total Sweep Program"]),
            rel("Fact Program Bank Daily Total", "Program Bank", ["Daily Total Program Bank"]),
            rel("Fact Register Position", "Client Account", ["Register Account"]),
            rel("Fact Register Position", "Share Class", ["Register Share Class"]),
            rel("Instrument", "Share Class", ["Own Share Class"], optional=True,
                note="Maps an own-fund instrument in the client book to its share class on the register."),
        ],
        notes=("Stock record reconciliation and security counts, with the sweep tie (DP-300 cash balance to DP-302 "
               "allocation to DP-431 daily total) and the own-fund omnibus tie (DP-300 client holdings to DP-580 "
               "register). The three books stay separate facts (CW-007): 49 Client Holding and 29 Register Position "
               "meet only through Instrument -> Share Class at share class x date. Conformed: Control Location Party "
               "from DP-240, Broker-Dealer and Calendar Date from DP-013, Sweep Program and Program Bank from DP-431, "
               "Share Class and Instrument from DP-097, Client Account from DP-093, Employee from DP-192. Own dimension: "
               "Control Location. Model gap: Share Class conformed from DP-097 because DP-004 is not upstream. No "
               "special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-447": dict(
        style="Star",
        entities=[
            fact("Fact Street Settlement Obligation", [("49", "Street Settlement Obligation")],
                 ["Settling Broker-Dealer", "Clearing Channel", "Obligation Instrument", "Contractual Settlement Date"],
                 grain="one row = settling broker-dealer x clearing channel x instrument x contractual settlement date; "
                       "daily snapshot of open obligations",
                 measures=True, note="Read directly (DP-300 does not publish it). PII tier: none."),
            fact("Fact Client Settlement Fail", [("49", "Client Settlement Fail")], ["Failed Client Activity", "Fail Type"],
                 grain="one row = client account activity x fail type", note="PII tier: financial (restricted, DQ5)."),
            fact("Fact Client Account Activity", [("49", "Client Account Activity")], ["Client Account Activity ID"],
                 grain="one row = account x posting (CLACT-), from DP-300", note="PII tier: financial."),
            fact("Fact Fund Settlement Obligation", [("29", "Settlement Obligation")], ["Settlement Obligation ID"],
                 grain="one row = fund order x settlement obligation sequence (from DP-580)",
                 note="The own-fund settlement cash stays 29's (CW-102); compared with the street obligation, never "
                      "merged with it. Obligation Fund Order stays an attribute. PII tier: financial."),
            dim("Close-Out Order", ("DP-301", "Client Order"), [("48", "Client Order")],
                note="Conformed from DP-301: the order that closed out a fail (Regulation SHO Rule 204)."),
            dim("Freeriding Restriction", ACCTRESTR, [("15", "Account Restriction")],
                note="Conformed from DP-093: the Regulation T 90-day freeze. PII tier: financial."),
            dim("Settling Broker-Dealer", ILE),
            dim("Clearing Counterparty", PARTY, note="Conformed from DP-240 Party (clearing agency or contra broker)."),
            dim("Instrument", INSTR),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Street Settlement Obligation", "Settling Broker-Dealer", ["Settling Broker-Dealer"]),
            rel("Fact Street Settlement Obligation", "Clearing Counterparty", ["Clearing Counterparty"], optional=True),
            rel("Fact Street Settlement Obligation", "Instrument", ["Obligation Instrument"]),
            rel("Fact Street Settlement Obligation", "Calendar Date", ["Contractual Settlement Date"]),
            rel("Fact Street Settlement Obligation", "Fact Fund Settlement Obligation", ["Own-Fund Settlement Obligation"],
                optional=True, note="The TA-side obligation of an own-fund street settlement."),
            rel("Fact Client Settlement Fail", "Fact Client Account Activity", ["Failed Client Activity"]),
            rel("Fact Client Settlement Fail", "Close-Out Order", ["Close-Out Client Order"], optional=True),
            rel("Fact Client Settlement Fail", "Freeriding Restriction", ["Freeriding Restriction"], optional=True),
            rel("Fact Client Account Activity", "Client Account", ["Activity Account"]),
            rel("Fact Client Account Activity", "Instrument", ["Activity Instrument"], optional=True),
            rel("Fact Client Account Activity", "Calendar Date", ["Settlement Date"]),
            rel("Freeriding Restriction", "Client Account", ["Restricted Account"]),
        ],
        notes=("Street settlement and client fails as the two main facts. Conformed: Close-Out Order from DP-301, "
               "Freeriding Restriction and Client Account from DP-093, Settling Broker-Dealer and Calendar Date from "
               "DP-013, Clearing Counterparty from DP-240, Instrument from DP-097. The 29 own-fund settlement obligation "
               "is a separate fact from DP-580 (CW-102). External reference kept as attribute: Obligation Fund Order "
               "(29). No special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-448": dict(
        style="Star",
        entities=[
            fact("Fact Account Transfer", [("49", "Account Transfer")], ["Account Transfer ID"],
                 grain="one row = account transfer (ACXF-); daily snapshot of open transfers",
                 measures=True,
                 note="Read from DP-300 at its key. Transfer values are operational and never labeled Net New Assets "
                      "(CW-230). PII tier: financial (contra account numbers not read)."),
            fact("Fact Account Transfer Asset Line", [("49", "Account Transfer Asset Line")],
                 ["Line Account Transfer", "Asset Line Sequence"],
                 grain="one row = account transfer x asset line sequence",
                 note="Read directly (no foundation publishes it); valued at the 22 approved price of the settlement "
                      "date (taxonomy gap: no transferred value). PII tier: financial."),
            fact("Fact Cost Basis Transfer Statement", [("49", "Cost Basis Transfer Statement")],
                 ["Statement Account Transfer", "Transfer Statement Direction", "Statement Version"],
                 grain="one row = account transfer x statement direction x statement version (IRC section 6045A)",
                 note="PII tier: financial."),
            dim("Fact Certified Net New Assets", MV, [("06", "Measure Value"), ("06", "Client Asset Measures")],
                role="Fact",
                grain="one row = DP-008 measure value (measure x period end x dimension type x dimension key x data basis "
                      "x snapshot)",
                note="Conformed from DP-008 so its full key (Data Basis is not an input) is inherited. The certified Net "
                     "New Assets is compared with Net Transfer Value as a share, never added to it (CW-011, CW-142, "
                     "CW-230)."),
            dim("Snapshot", SNAP, [("06", "Snapshot")]),
            dim("Measure Definition", MDEF),
            dim("Service Request", ("DP-381", "Service Request"), [("13", "Service Request")],
                note="Conformed from DP-381: the originating request whose Received Timestamp times a transfer in."),
            dim("Approved Price", ("DP-143", "Approved Price"), [("22", "Approved Price")]),
            dim("Client Account Activity", ("DP-300", "Client Account Activity"),
                note="Conformed from DP-300: the posting that resulted from an asset line."),
            dim("Client Account", ACCT, [("15", "Account")], note="PII tier: financial."),
            dim("Contra Firm", PARTY, note="Conformed from DP-240 Party: the contra broker-dealer or custodian."),
            dim("Instrument", INSTR),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Account Transfer", "Client Account", ["Transfer Account"]),
            rel("Fact Account Transfer", "Contra Firm", ["Contra Firm"]),
            rel("Fact Account Transfer", "Service Request", ["Originating Service Request"], optional=True),
            rel("Fact Account Transfer", "Calendar Date", ["Transfer Settlement Date"], optional=True),
            rel("Fact Account Transfer Asset Line", "Fact Account Transfer", ["Line Account Transfer"]),
            rel("Fact Account Transfer Asset Line", "Instrument", ["Transfer Asset Instrument"], optional=True),
            rel("Fact Account Transfer Asset Line", "Fact Cost Basis Transfer Statement",
                ["Line Cost Basis Transfer Statement"], optional=True,
                note="Single reference to the composite statement key; the latest version completes it."),
            rel("Fact Account Transfer Asset Line", "Client Account Activity", ["Resulting Activity"], optional=True),
            rel("Fact Cost Basis Transfer Statement", "Fact Account Transfer", ["Statement Account Transfer"]),
            rel("Fact Cost Basis Transfer Statement", "Contra Firm", ["Statement Counterparty Firm"], optional=True),
            rel("Approved Price", "Instrument", ["Priced Instrument"],
                note="Values an asset line on its instrument and the transfer settlement date."),
            rel("Fact Certified Net New Assets", "Snapshot", ["Snapshot"]),
            rel("Fact Certified Net New Assets", "Measure Definition", ["Measure"]),
            rel("Fact Certified Net New Assets", "Calendar Date", ["Period End Date"]),
        ],
        notes=("ACATS in and out: the transfer, its asset lines and cost basis statements as facts, and the certified Net "
               "New Assets as a separate conformed DP-008 fact that is compared, never summed (CW-011, CW-230). "
               "Conformed: Snapshot, Measure Definition and Measure Value from DP-008, Service Request from DP-381, "
               "Approved Price from DP-143, Client Account Activity from DP-300, Client Account from DP-093, Contra Firm "
               "from DP-240, Instrument from DP-097, Calendar Date from DP-013. Distribution channel is the DP-008 "
               "Dimension Key of the measure value (no Channel entity is published). No special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-452": dict(
        style="Star",
        entities=[
            fact("Fact Client Corporate Action Entitlement",
                 [("49", "Client Corporate Action Entitlement"), ("49", "Dividend Reinvestment Allocation")],
                 ["Client Corporate Action Entitlement ID"],
                 grain="one row = corporate action event x account (CLCAE-); daily snapshots",
                 measures=True,
                 note="Read from DP-300 at its key; Dividend Reinvestment Allocation folds here and is read directly. "
                      "PII tier: financial."),
            fact("Fact Client Voluntary Election", [("49", "Client Voluntary Election")],
                 ["Elected Entitlement", "Elected Option", "Election Received Timestamp"],
                 grain="one row = client corporate action entitlement x corporate action option x election",
                 note="PII tier: financial."),
            fact("Fact Record Date Client Holding", [("49", "Client Holding")], ["Client Holding ID"],
                 grain="one row = account x instrument x holding date x Holding View (from DP-300; record date rows)",
                 note="The 49 client book on the record date, compared with the entitlement's record date quantity "
                      "(CW-007). PII tier: financial."),
            fact("Fact Option Exercise Instruction", [("48", "Option Exercise Instruction")],
                 ["Exercise Account", "Exercised Option Series", "Exercise Date"],
                 grain="one row = account x option series x exercise date",
                 note="Read directly (moved from backlog DP-441). PII tier: financial."),
            fact("Fact Option Assignment Allocation", [("48", "Option Assignment Allocation")],
                 ["OCC Assignment Notice Reference", "Assigned Account"],
                 grain="one row = OCC assignment notice x account", note="PII tier: financial."),
            dim("Corporate Action Event", ("DP-099", "Corporate Action Event"), [("17", "Corporate Action Event")]),
            dim("Corporate Action Option", ("DP-099", "Corporate Action Option"), [("17", "Corporate Action Option")]),
            dim("DRIP Feature", ACCTFEAT, [("15", "Account Feature")],
                note="Conformed from DP-093 Account Feature: the dividend reinvestment feature applied."),
            dim("Client Account Activity", ("DP-300", "Client Account Activity"),
                note="Conformed from DP-300: the payment, exercise and assignment postings."),
            dim("Client Tax Lot", ("DP-300", "Client Tax Lot"), note="Conformed from DP-300: the lot a reinvestment created."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Instrument", INSTR, note="Event instrument and option series."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Client Corporate Action Entitlement", "Corporate Action Event", ["Entitlement Event"]),
            rel("Fact Client Corporate Action Entitlement", "Client Account", ["Entitled Account"]),
            rel("Fact Client Corporate Action Entitlement", "Client Account Activity", ["Payment Activity"], optional=True),
            rel("Fact Client Corporate Action Entitlement", "Client Tax Lot", ["Resulting Client Tax Lot"], optional=True),
            rel("Fact Client Corporate Action Entitlement", "DRIP Feature", ["DRIP Feature Applied"], optional=True),
            rel("Fact Client Corporate Action Entitlement", "Calendar Date", ["Entitlement Payment Date"], optional=True),
            rel("Fact Client Voluntary Election", "Fact Client Corporate Action Entitlement", ["Elected Entitlement"]),
            rel("Fact Client Voluntary Election", "Corporate Action Option", ["Elected Option"],
                note="Single reference to the composite option key; the entitlement's event completes it."),
            rel("Fact Record Date Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Record Date Client Holding", "Instrument", ["Held Instrument"]),
            rel("Fact Record Date Client Holding", "Calendar Date", ["Client Holding Date"]),
            rel("Fact Option Exercise Instruction", "Client Account", ["Exercise Account"]),
            rel("Fact Option Exercise Instruction", "Instrument", ["Exercised Option Series"]),
            rel("Fact Option Exercise Instruction", "Client Account Activity", ["Resulting Exercise Activity"],
                optional=True),
            rel("Fact Option Assignment Allocation", "Client Account", ["Assigned Account"]),
            rel("Fact Option Assignment Allocation", "Instrument", ["Assigned Option Series"]),
            rel("Fact Option Assignment Allocation", "Client Account Activity", ["Resulting Assignment Activity"],
                optional=True),
            rel("Corporate Action Option", "Corporate Action Event", ["Option Event"]),
            rel("Corporate Action Event", "Instrument", ["Event Instrument"]),
            rel("Corporate Action Event", "Calendar Date", ["Record Date"]),
            rel("DRIP Feature", "Client Account", ["Feature Account"]),
        ],
        notes=("Client corporate action entitlements and elections with option exercises and assignments as companion "
               "facts. Conformed: Corporate Action Event and Option from DP-099, DRIP Feature and Client Account from "
               "DP-093, Client Account Activity and Client Tax Lot from DP-300, Instrument from DP-097, Calendar Date "
               "from DP-013. The record date client holdings are the 49 book only (CW-007). No special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-457": dict(
        style="Star",
        entities=[
            fact("Fact Program Bank Daily Total", [("50", "Program Bank Daily Total")],
                 ["Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date"],
                 grain="one row = sweep program x program bank x business date (program view, from DP-431)",
                 measures=True,
                 note="The program view; holds the measures. Settlement Wire IMAD is an operational reference. PII "
                      "tier: none."),
            fact("Fact Sweep Run", [("50", "Sweep Run")], ["Run Sweep Program", "Run Business Date", "Run Cycle Number"],
                 grain="one row = sweep program x business date x run cycle",
                 note="Read directly (no foundation publishes it). PII tier: none."),
            fact("Fact Sweep Allocation", [("50", "Sweep Allocation")],
                 ["Allocation Account", "Allocation Program Bank", "Allocation Business Date"],
                 grain="one row = account x program bank x business date (from DP-302)",
                 note="Operational balance (CW-230). PII tier: financial (restricted, DQ5)."),
            fact("Fact FDIC Coverage Assessment", [("50", "FDIC Coverage Assessment")],
                 ["Assessed Party", "FDIC Ownership Category", "Assessed Program Bank", "Assessment Date"],
                 grain="one row = party x FDIC ownership category x program bank x assessment date (from DP-431)",
                 note="PII tier: financial (party rows restricted, DQ5)."),
            fact("Fact Client Cash Forecast Line", [("50", "Client Cash Forecast Line")],
                 ["Line Client Cash Forecast", "Line Value Date", "Line Cash Flow Category", "Line Sweep Program"],
                 grain="one row = client cash forecast x value date x client cash flow category x sweep program",
                 note="Read directly (moved from backlog DP-461). PII tier: none."),
            dim("Fact Client Cash Balance", ("DP-300", "Cash Balance"), [("49", "Account Cash Balance")], role="Fact",
                grain="one row = account x currency x cash balance type x balance basis x business date (from DP-300)",
                note="Conformed from DP-300 so its full key is inherited (Cash Balance Currency is not an input). Sweep "
                     "Balances (from DP-300), operational (CW-230). PII tier: financial."),
            dim("Fact Cash Program Economics", ("DP-012", "Cash Program Economics"), [("10", "Cash Program Economics")],
                role="Fact", grain="one row = sweep program x program bank x period (from DP-012)",
                note="Conformed from DP-012: Net Spread is 10's (CW-156, CW-244), read, never recomputed."),
            dim("Fact Certified Client Assets", MV, [("06", "Measure Value"), ("06", "Client Asset Measures")],
                role="Fact",
                grain="one row = DP-008 measure value (measure x period end x dimension type x dimension key x data basis "
                      "x snapshot); Holding Type Cash and Sweep",
                note="Conformed from DP-008. Ending Client Assets is compared with the bank sweep share, never added "
                     "to an operational balance (CW-011, CW-230)."),
            dim("Snapshot", SNAP, [("06", "Snapshot")]),
            dim("Measure Definition", MDEF),
            own("Client Cash Forecast", [("50", "Client Cash Forecast")], ["Client Cash Forecast ID"],
                note="Own dimension: the forecast version (no foundational model publishes it)."),
            dim("Sweep Program", SWEEP, [("50", "Sweep Program")]),
            dim("Program Bank", PGBANK, [("50", "Program Bank")]),
            dim("Program Bank Participation", ("DP-431", "Program Bank Participation"),
                [("50", "Program Bank Participation")], role="Bridge",
                grain="one row = sweep program x program bank x effective period",
                note="Conformed from DP-431: program-to-bank many-to-many with allocation priority and capacity."),
            dim("Sweep Rate Tier", ("DP-431", "Sweep Rate Tier"), [("50", "Sweep Rate Tier")]),
            dim("Cash Sweep Election", SWEEPELECT, [("15", "Cash Sweep Election")],
                note="Conformed from DP-093: account sweep vehicle election with excluded banks. PII tier: financial."),
            dim("Sweep Fund Share Class", ("DP-431", "Share Class"),
                note="Conformed from DP-431's Share Class (DP-004 is not upstream): the money market fund swept to."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Client Party", PARTY, note="Conformed from DP-240: the FDIC-assessed party. PII tier: identity."),
            dim("Bank Party", PARTY, note="Conformed from DP-240 Party: the bank in the program bank role."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Program Bank Daily Total", "Sweep Program", ["Daily Total Sweep Program"]),
            rel("Fact Program Bank Daily Total", "Program Bank", ["Daily Total Program Bank"]),
            rel("Fact Program Bank Daily Total", "Calendar Date", ["Daily Total Business Date"]),
            rel("Fact Sweep Run", "Sweep Program", ["Run Sweep Program"]),
            rel("Fact Sweep Run", "Calendar Date", ["Run Business Date"]),
            rel("Fact Sweep Allocation", "Client Account", ["Allocation Account"]),
            rel("Fact Sweep Allocation", "Program Bank", ["Allocation Program Bank"]),
            rel("Fact Sweep Allocation", "Calendar Date", ["Allocation Business Date"]),
            rel("Fact FDIC Coverage Assessment", "Client Party", ["Assessed Party"]),
            rel("Fact FDIC Coverage Assessment", "Program Bank", ["Assessed Program Bank"]),
            rel("Fact Client Cash Forecast Line", "Client Cash Forecast", ["Line Client Cash Forecast"]),
            rel("Fact Client Cash Forecast Line", "Sweep Program", ["Line Sweep Program"]),
            rel("Fact Client Cash Forecast Line", "Calendar Date", ["Line Value Date"]),
            rel("Fact Client Cash Balance", "Client Account", ["Cash Balance Account"]),
            rel("Fact Client Cash Balance", "Sweep Program", ["Balance Sweep Program"], optional=True),
            rel("Fact Cash Program Economics", "Sweep Program", ["Economics Sweep Program"]),
            rel("Fact Cash Program Economics", "Program Bank", ["Economics Program Bank"]),
            rel("Fact Certified Client Assets", "Snapshot", ["Snapshot"]),
            rel("Fact Certified Client Assets", "Measure Definition", ["Measure"]),
            rel("Fact Certified Client Assets", "Calendar Date", ["Period End Date"]),
            rel("Program Bank Participation", "Sweep Program", ["Participation Sweep Program"]),
            rel("Program Bank Participation", "Program Bank", ["Participating Program Bank"]),
            rel("Sweep Rate Tier", "Sweep Program", ["Tier Sweep Program"]),
            rel("Program Bank", "Bank Party", ["Bank Party"]),
            rel("Cash Sweep Election", "Client Account", ["Sweep Election Account"]),
            rel("Cash Sweep Election", "Sweep Program", ["Elected Sweep Program"], optional=True),
            rel("Cash Sweep Election", "Sweep Fund Share Class", ["Elected Sweep Fund"], optional=True),
            rel("Cash Sweep Election", "Program Bank", ["Excluded Program Banks"], card="M:N", optional=True,
                note="Multi-valued: the banks a client excluded."),
        ],
        notes=("Cash sweep and program bank allocation as a constellation at the program, allocation, run, FDIC and "
               "forecast grains. Certified Client Assets (DP-008) and Net Spread (DP-012) are separate conformed facts, "
               "compared with the operational sweep balances, never added (CW-011, CW-230). Conformed: Sweep Program, "
               "Program Bank, Program Bank Participation, Sweep Rate Tier and Sweep Fund Share Class from DP-431, Cash "
               "Sweep Election and Client Account from DP-093, Client Party and Bank Party from DP-240, Snapshot, "
               "Measure Definition and Measure Value from DP-008, Cash Program Economics from DP-012, Calendar Date from "
               "DP-013. Own dimension: Client Cash Forecast. The allocation-to-balance reconciliation is DP-446's. No "
               "special-category data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-459": dict(
        style="Star",
        entities=[
            fact("Fact Debit Card", [("50", "Debit Card")], ["Debit Card ID"],
                 grain="one row = debit card (DCARD-) x business date (daily snapshot of the card view)",
                 note="Read directly (no foundation publishes it); no status history (taxonomy gap). Masked card "
                      "number not read. PII tier: financial."),
            fact("Fact Money Movement",
                 [("50", "Money Movement"), ("50", "Card Transaction Detail"), ("50", "Check Detail")],
                 ["Money Movement ID"],
                 grain="one row = card or check money movement (MMVMT-), from DP-302",
                 measures=True,
                 note="Card Transaction Detail and Check Detail fold here. Merchant name and check image are not read "
                      "(DQ5). PII tier: financial."),
            fact("Fact Card Dispute", [("50", "Card Dispute")], ["Disputed Movement", "Error Notice Date"],
                 grain="one row = card money movement x dispute (Regulation E error notice)",
                 note="Read directly (no foundation publishes it). PII tier: financial."),
            dim("Card Feature", ACCTFEAT, [("15", "Account Feature")],
                note="Conformed from DP-093 Account Feature (CW-111). PII tier: financial."),
            dim("Redeeming Fund Order", ("DP-580", "Fund Order"), [("29", "Fund Order")],
                note="Conformed from DP-580: the 29 redemption behind a checkwriting draft."),
            dim("Share Class", ("DP-580", "Share Class"),
                note="Conformed from DP-580 (DP-004 is not upstream): the money market share class drawn on."),
            dim("Program Bank", PGBANK, note="Issuing and drawn-on program bank."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Cardholder", PARTY, note="Conformed from DP-240 Party. PII tier: identity."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Debit Card", "Client Account", ["Card Account"]),
            rel("Fact Debit Card", "Card Feature", ["Card Feature"]),
            rel("Fact Debit Card", "Cardholder", ["Cardholder"]),
            rel("Fact Debit Card", "Program Bank", ["Issuing Program Bank"]),
            rel("Fact Money Movement", "Client Account", ["Movement Account"]),
            rel("Fact Money Movement", "Fact Debit Card", ["Transaction Debit Card"], optional=True),
            rel("Fact Money Movement", "Program Bank", ["Drawn-On Program Bank"], optional=True),
            rel("Fact Money Movement", "Redeeming Fund Order", ["Redeeming Fund Order"], optional=True),
            rel("Fact Money Movement", "Calendar Date", ["Value Date"]),
            rel("Fact Card Dispute", "Fact Money Movement", ["Disputed Movement"]),
            rel("Fact Card Dispute", "Fact Money Movement", ["Provisional Credit Movement"], optional=True,
                note="The credit movement that provisionally credited the client."),
            rel("Fact Card Dispute", "Calendar Date", ["Error Notice Date"]),
            rel("Redeeming Fund Order", "Share Class", ["Order Share Class"]),
            rel("Card Feature", "Client Account", ["Feature Account"]),
        ],
        notes=("Debit card, checkwriting and Regulation E disputes. Conformed: Card Feature and Client Account from "
               "DP-093, Redeeming Fund Order and Share Class from DP-580, Program Bank from DP-431, Cardholder from "
               "DP-240, Calendar Date from DP-013. Fraud holds on card movements are DP-456's. No special-category "
               "data."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-460": dict(
        style="Star",
        entities=[
            fact("Fact Money Movement Monitoring Alert", [("50", "Money Movement Monitoring Alert")],
                 ["Money Movement Monitoring Alert ID"],
                 grain="one row = money movement monitoring alert (MMALT-); daily snapshot of open alerts",
                 measures=True,
                 note="Elder Exploitation Pattern alerts (special category, CD-344) are dropped at ingestion with "
                      "Monitoring Scenario used only as the filter, so no restricted entity is needed here; they are "
                      "DP-226's and the holds DP-456's. Restricted classification for AML confidentiality (31 CFR "
                      "1023.320(e)). PII tier: identity and financial."),
            fact("Fact Payment Sanctions Screening", [("50", "Payment Sanctions Screening")],
                 ["Screened Movement", "Screening Timestamp"],
                 grain="one row = money movement x screening run", note="PII tier: identity."),
            fact("Fact Money Movement", [("50", "Money Movement")], ["Money Movement ID"],
                 grain="one row = money movement (MMVMT-), from DP-302", note="PII tier: financial."),
            dim("Fact Money Movement Event", ("DP-302", "Money Movement Event"), [("50", "Money Movement Event")],
                role="Fact", grain="one row = money movement x event",
                note="Conformed from DP-302 so its full key is inherited (Event Sequence is not an input); release "
                     "before screening. PII tier: financial."),
            own("Restricted AML Case", [("38", "AML Case")], ["AML Case Number"],
                note="Own dimension: DP-226 is a consumer with no foundational model; read for its number and opening "
                     "date only, never SAR Decision. Restricted (AML confidentiality). PII tier: identity."),
            dim("Subject Party", PARTY, note="Conformed from DP-240: alert subjects and screened parties. PII tier: identity."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Alert Reviewer", EMP, note="Conformed from DP-192 Employee."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Money Movement Monitoring Alert", "Fact Money Movement", ["Movements in Scope"], card="M:N"),
            rel("Fact Money Movement Monitoring Alert", "Subject Party", ["Alert Subject Party"], optional=True),
            rel("Fact Money Movement Monitoring Alert", "Client Account", ["Alert Accounts"], card="M:N", optional=True),
            rel("Fact Money Movement Monitoring Alert", "Alert Reviewer", ["Alert Reviewer"], optional=True),
            rel("Fact Money Movement Monitoring Alert", "Restricted AML Case", ["Escalated AML Case"], optional=True),
            rel("Fact Payment Sanctions Screening", "Fact Money Movement", ["Screened Movement"]),
            rel("Fact Payment Sanctions Screening", "Subject Party", ["Screened Parties"], card="M:N", optional=True),
            rel("Fact Money Movement", "Client Account", ["Movement Account"]),
            rel("Fact Money Movement", "Calendar Date", ["Requested Date"]),
            rel("Fact Money Movement Event", "Fact Money Movement", ["Event Movement"]),
            rel("Restricted AML Case", "Calendar Date", ["Case Opened Date"]),
        ],
        notes=("Money movement AML monitoring and payment sanctions screening as the two main facts. Conformed: Subject "
               "Party from DP-240, Client Account from DP-093, Alert Reviewer from DP-192, Calendar Date from DP-013. Own "
               "dimension: Restricted AML Case (38). External reference kept as attribute: Blocked or Rejected Report "
               "(38 AML and Sanctions Report). Special category: Elder Exploitation Pattern rows are excluded at "
               "ingestion (CD-344)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-466": dict(
        style="Star",
        entities=[
            fact("Fact Plan Cohort Outcome", [], ["Fact Plan Cohort Outcome Key"],
                 grain="one row = plan x participant cohort (plan entry year x membership status) x as-of month; "
                       "minimum cell 10 participants",
                 measures=True,
                 note="The only published fact. Cells under 10 memberships are suppressed and each suppressed cell is "
                      "protected by suppressing another cell of the plan (complementary suppression); Pre-Retirement "
                      "Withdrawals is published at plan level only (DQ5). Model gap: no input attribute carries the "
                      "cohort or the month, so the fact has a surrogate key and borrows the plan and date keys. PII "
                      "tier: none published."),
            fact("Fact Participant Balance", [("16", "Participant Balance")],
                 ["Balance Membership", "Balance Contribution Source", "Balance Investment Option", "Valuation Date"],
                 grain="one row = membership x money source x plan investment option x valuation date (from DP-430)",
                 note="The 16 recordkeeping book, never Client Assets (CW-007, CW-011). Input only. PII tier: financial."),
            fact("Fact Participant Loan", [("16", "Participant Loan")], ["Loan ID"],
                 grain="one row = participant loan", note="Read directly. Input only. PII tier: financial."),
            fact("Restricted Distribution Request", [("16", "Distribution Request")], ["Distribution ID"],
                 grain="one row = distribution request",
                 note="Restricted: Distribution Type values Hardship and Disability are special category (CD-344, "
                      "CW-231); the rows feed only the plan-level Pre-Retirement Withdrawals and Cash-Out at "
                      "Separation counts, with complementary suppression, and are never published row-level. Hardship "
                      "Reason is not read. PII tier: special category."),
            fact("Fact Annual Limit Tracking", [("16", "Annual Limit Tracking")],
                 ["Limit Membership", "Limit Type", "Limit Plan Year"],
                 grain="one row = membership x limit type x plan year", note="Input only. PII tier: financial."),
            fact("Fact Personal Rate of Return", [("32", "Personal Rate of Return")], ["Personal Rate of Return ID"],
                 grain="one row = personal rate of return (subject x period x method x fee basis x version), from DP-145",
                 note="Certified (CW-129): only final values are read for the median, never recomputed. Input only. PII "
                      "tier: financial."),
            dim("Vested Balance by Source", ("DP-094", "Vested Balance by Source"), [("16", "Vested Balance by Source")],
                role="Fact", grain="one row = membership x employer money source x as-of date",
                note="Conformed from DP-094. Input only. PII tier: financial."),
            dim("Participant", PARTICIPANT, [("16", "Participant Plan Membership")],
                note="Conformed from DP-094. Never published: the Highly Compensated Employee indicator it inherits is "
                     "not read, and participant identifiers stay out of every output (DQ5). PII tier: financial, input "
                     "only."),
            dim("Deferral Election", ("DP-094", "Deferral Election"), [("16", "Deferral Election")],
                note="Conformed from DP-094; effective dated."),
            dim("Investment Election", ("DP-094", "Investment Election"), [("16", "Investment Election")], role="Bridge",
                grain="one row = membership x plan investment option x election effective period",
                note="Conformed from DP-094: membership-to-option many-to-many with allocation percentages."),
            dim("Plan Investment Option", ("DP-094", "Plan Investment Option"), [("16", "Plan Investment Option")]),
            dim("Plan Document", ("DP-094", "Plan Document"), [("16", "Deferral & Automatic Features")],
                note="Conformed from DP-094: the folded Deferral & Automatic Features group is read without its parent, "
                     "so it sits on the conformed plan document; the plan-level design companion."),
            own("Plan Managed Account Service", [("16", "Plan Managed Account Service")],
                ["Managed Account Service Plan", "Managed Account Service Offering", "Service Effective From"],
                role="Bridge", grain="one row = retirement plan x service offering x effective period",
                note="Read directly (moved from backlog DP-468); no foundational model publishes it."),
            own("Participant Service Election", [("16", "Participant Service Election")],
                ["Service Election Membership", "Service Election Type", "Service Election Effective From"],
                note="Read directly (moved from backlog DP-468). Input only. PII tier: financial."),
            dim("Model Assignment", ("DP-304", "Model Assignment"), [("46", "Model Assignment")],
                note="Conformed from DP-304: a model assignment on the participant account infers managed account "
                     "enrollment (taxonomy gap). PII tier: financial."),
            dim("Recordkept Plan", PLAN, note="Conformed from DP-094 Retirement Plan."),
            dim("Share Class", SHARE),
            dim("Offering", OFFER, note="Conformed from DP-004 Service Offering: the managed account service."),
            dim("Client Account", ACCT, note="PII tier: financial."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Plan Cohort Outcome", "Recordkept Plan", ["Recordkept Plan Key"]),
            rel("Fact Plan Cohort Outcome", "Calendar Date", ["Calendar Date Key"], note="The as-of month end."),
            rel("Participant", "Recordkept Plan", ["Membership Plan"]),
            rel("Participant", "Client Account", ["Participant Account"], optional=True),
            rel("Deferral Election", "Participant", ["Election Membership"]),
            rel("Investment Election", "Participant", ["Investment Election Membership"]),
            rel("Investment Election", "Plan Investment Option", ["Elected Investment Option"]),
            rel("Plan Investment Option", "Recordkept Plan", ["Menu Plan"]),
            rel("Plan Investment Option", "Share Class", ["Offered Share Class"]),
            rel("Plan Document", "Recordkept Plan", ["Administered Plan"]),
            rel("Fact Participant Balance", "Participant", ["Balance Membership"]),
            rel("Fact Participant Balance", "Plan Investment Option", ["Balance Investment Option"]),
            rel("Fact Participant Balance", "Calendar Date", ["Valuation Date"]),
            rel("Vested Balance by Source", "Participant", ["Vested Balance Membership"]),
            rel("Fact Participant Loan", "Participant", ["Loan Membership"]),
            rel("Restricted Distribution Request", "Participant", ["Distribution Membership"]),
            rel("Fact Annual Limit Tracking", "Participant", ["Limit Membership"]),
            rel("Plan Managed Account Service", "Recordkept Plan", ["Managed Account Service Plan"]),
            rel("Plan Managed Account Service", "Offering", ["Managed Account Service Offering"]),
            rel("Participant Service Election", "Participant", ["Service Election Membership"]),
            rel("Model Assignment", "Client Account", ["Assigned Account"]),
            rel("Fact Personal Rate of Return", "Client Account", ["Personal Return Account"], optional=True),
        ],
        notes=("Participant outcomes as one published aggregate fact (plan x cohort x month, minimum cell 10 with "
               "complementary suppression) over row-level participant inputs that are never published. Special "
               "category: the Hardship and Disability distribution rows sit only in Restricted Distribution Request "
               "(CD-344, CW-231). Books: Participant Balance (16, DP-430) is the only balance read, never Client Assets. "
               "Conformed: Participant, Deferral Election, Investment Election, Plan Investment Option, Plan Document, "
               "Vested Balance by Source and Recordkept Plan from DP-094, Share Class and Offering from DP-004, Model "
               "Assignment from DP-304, Client Account from DP-093, Calendar Date from DP-013. DP-430 and DP-145 facts "
               "are read at their keys. Model gap: no input carries the cohort or month (surrogate key on the cohort "
               "fact)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-467": dict(
        style="Star",
        entities=[
            fact("Fact Participant Retail Hand-Off", [("16", "Participant Retail Hand-Off")], ["Hand-Off ID"],
                 grain="one row = participant retail hand-off (PRTHO-; membership x trigger); monthly and quarterly "
                       "snapshots",
                 measures=True,
                 note="Read from DP-430 at its key. Capture rates are operational funnel values, never Net New Assets "
                      "(CW-230). Participant rows are visible only to workplace and advice roles (DQ5). PII tier: "
                      "financial."),
            fact("Fact Separation Event", [("16", "Employment Event")],
                 ["Event Membership", "Employment Event Type", "Employment Event Date"],
                 grain="one row = membership x employment event type x event date (Termination and Retirement)",
                 note="Matched to a hand-off on membership and date (taxonomy gap: no separation key on the hand-off). "
                      "PII tier: financial."),
            fact("Fact Distribution Request", [("16", "Distribution Request")], ["Distribution ID"],
                 grain="one row = distribution request (rollover and cash-out rows)",
                 note="Read directly. Model gap: the spec reads Distribution Type at participant row level without a "
                      "DQ rule excluding the Hardship and Disability values, which are special category (CD-344); the "
                      "rollover measures need only rollover rows, so the lead should add an ingestion filter or make "
                      "this a restricted entity. PII tier: financial."),
            fact("Fact Rollover Contribution", [("16", "Contribution Record"), ("16", "Rollover Contribution Detail")],
                 ["Contribution ID"],
                 grain="one row = contribution record with incoming rollover detail",
                 note="Rollover Contribution Detail folds here. PII tier: financial."),
            dim("Fact Participant Balance", ("DP-430", "Participant Balance"), [("16", "Participant Balance")],
                role="Fact", grain="one row = membership x money source x plan investment option x valuation date",
                note="Conformed from DP-430 so the full key (source and option are not inputs) is inherited; the 16 "
                     "book (CW-007). PII tier: financial."),
            fact("Fact Rollover Recommendation", [("45", "Recommendation")], ["Recommendation ID"],
                 grain="one row = recommendation (RECOM-) of type Rollover, from DP-303",
                 note="Read, never re-scored. PII tier: financial."),
            fact("Fact Rollover Analysis", [("45", "Rollover Analysis"), ("45", "PTE 2020-02 Documentation")],
                 ["Rollover Analysis ID"],
                 grain="one row = rollover recommendation x analysis (ROLV-), from DP-303",
                 note="PTE 2020-02 Documentation folds here; the documentation gap flag is DP-335's. PII tier: financial."),
            fact("Fact Best Interest Evidence", [("45", "Best Interest Evidence")],
                 ["Evidence Recommendation", "Best Interest Component"],
                 grain="one row = recommendation x obligation component", note="PII tier: financial."),
            dim("Fact Certified Inter-Channel Transfers", MV, [("06", "Measure Value"), ("06", "Client Asset Measures")],
                role="Fact",
                grain="one row = DP-008 measure value (measure x period end x dimension type x dimension key x data basis "
                      "x snapshot)",
                note="Conformed from DP-008: Net Inter-Channel Transfers, compared with rollover capture, never added "
                     "(CW-011, CW-142, CW-230)."),
            dim("Snapshot", SNAP, [("06", "Snapshot")]),
            dim("Measure Definition", MDEF),
            dim("Account Channel Assignment", ("DP-008", "Account Channel Assignment"),
                [("06", "Account Channel Assignment")], role="Bridge",
                grain="one row = account x distribution channel x effective period",
                note="Conformed from DP-008: the channel of the receiving account, read and never derived here. Joined "
                     "only to Client Account (no 49 Client Holding in this model)."),
            dim("Participant", PARTICIPANT, [("16", "Participant Plan Membership")],
                note="Conformed from DP-094. PII tier: financial."),
            dim("Participant Party", PARTY, note="Conformed from DP-240 Party. PII tier: identity."),
            dim("External Institution", PARTY,
                note="Conformed from DP-240 Party: receiving and distributing institutions and the auto-rollover IRA "
                     "provider."),
            dim("Recordkept Plan", PLAN, note="Conformed from DP-094 Retirement Plan."),
            dim("Contact Consent", CONSENT, note="Conformed from DP-240 Consent Record."),
            dim("Advice Engagement", ("DP-303", "Advice Engagement"),
                note="Conformed from DP-303 (sibling WP2 file models_w_advice.py)."),
            dim("Advisor", ADVISOR, note="Conformed from DP-009 Employee, which holds 03 Advisor."),
            dim("Client Account", ACCT, [("15", "Account")],
                note="Participant, distribution, receiving and contribution accounts. PII tier: financial."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Participant Retail Hand-Off", "Participant", ["Hand-Off Membership"]),
            rel("Fact Participant Retail Hand-Off", "Contact Consent", ["Contact Consent"], optional=True),
            rel("Fact Participant Retail Hand-Off", "Advice Engagement", ["Referral Advice Engagement"], optional=True),
            rel("Fact Participant Retail Hand-Off", "Advisor", ["Referred Advisor"], optional=True),
            rel("Fact Participant Retail Hand-Off", "Fact Distribution Request", ["Linked Distribution Request"],
                optional=True),
            rel("Fact Participant Retail Hand-Off", "Calendar Date", ["Trigger Date"]),
            rel("Fact Separation Event", "Participant", ["Event Membership"]),
            rel("Fact Distribution Request", "Participant", ["Distribution Membership"]),
            rel("Fact Distribution Request", "Client Account", ["Distribution Account"], optional=True),
            rel("Fact Distribution Request", "Client Account", ["Receiving Account"], optional=True,
                note="The direct-business account a rollover lands in; its channel comes from the bridge."),
            rel("Fact Distribution Request", "External Institution", ["Receiving Institution"], optional=True),
            rel("Fact Distribution Request", "External Institution", ["Auto-Rollover IRA Provider"], optional=True),
            rel("Fact Distribution Request", "Fact Participant Retail Hand-Off", ["Originating Hand-Off"], optional=True),
            rel("Fact Distribution Request", "Calendar Date", ["Payment Date"], optional=True),
            rel("Fact Rollover Contribution", "Participant", ["Contribution Membership"]),
            rel("Fact Rollover Contribution", "Client Account", ["Contribution Account"], optional=True),
            rel("Fact Rollover Contribution", "External Institution", ["Distributing Institution"], optional=True),
            rel("Fact Participant Balance", "Participant", ["Balance Membership"]),
            rel("Fact Rollover Recommendation", "Advice Engagement", ["Recommendation Engagement"]),
            rel("Fact Rollover Recommendation", "Fact Rollover Analysis", ["Supporting Rollover Analysis"],
                optional=True),
            rel("Fact Rollover Analysis", "Fact Rollover Recommendation", ["Rollover Recommendation"]),
            rel("Fact Rollover Analysis", "Recordkept Plan", ["Source Retirement Plan"], optional=True),
            rel("Fact Best Interest Evidence", "Fact Rollover Recommendation", ["Evidence Recommendation"]),
            rel("Account Channel Assignment", "Client Account", ["Assigned Account"]),
            rel("Participant", "Participant Party", ["Participant"]),
            rel("Participant", "Recordkept Plan", ["Membership Plan"]),
            rel("Participant", "Client Account", ["Participant Account"], optional=True),
            rel("Fact Certified Inter-Channel Transfers", "Snapshot", ["Snapshot"]),
            rel("Fact Certified Inter-Channel Transfers", "Measure Definition", ["Measure"]),
            rel("Fact Certified Inter-Channel Transfers", "Calendar Date", ["Period End Date"]),
        ],
        notes=("Rollover capture: the hand-off is the main fact with separation events, distributions, incoming rollover "
               "contributions, balances and the 45 rollover advice as companion facts, and the certified Net "
               "Inter-Channel Transfers (DP-008) compared, never added (CW-230). Conformed: Participant and Recordkept "
               "Plan from DP-094, Participant Balance from DP-430, Advice Engagement from DP-303, Advisor from DP-009, "
               "Participant Party, External Institution and Contact Consent from DP-240, Measure Value, Snapshot, "
               "Measure Definition and Account Channel Assignment from DP-008, Client Account from DP-093, Calendar Date "
               "from DP-013. The 06 bridge joins only Client Account. Model gap: Distribution Type is read at row level "
               "without a special-category filter (see Fact Distribution Request)."),
    ),
}
