"""Logical data models, Wave WP2 consumer group B1 "CLA-A": Star models for the client, account, advice, managed account,
billing and trust consumer products of specs_w1c_cla_a.py (wealth-manager reference model). See CONTRACT.md and
00_Program/Rework/Agent_Instructions/models_common.md.

DP-320 Household 360; DP-321 Authorized Persons, Trusted Contacts & Beneficiaries; DP-322 Client Protection Flags & Senior
Investor Register (restricted); DP-324 Client Contactability, Preferences & Consent; DP-329 Retirement Account RMD &
Distribution Tracker; DP-332 Advisory Program Enrollment & Rule 3a-4 Compliance; DP-333 Advice Funnel & Conversion; DP-334
Plan Quality & Recommendation Evidence (Reg BI File); DP-335 Rollover Recommendations & PTE 2020-02 Evidence; DP-337 Goal
Progress & Funded Status; DP-341 Drift & Rebalance Monitor; DP-342 Rebalance & Tax-Loss Harvest Effectiveness; DP-345
Managed Account Assets, Models & Composites; DP-346 Fee Billing Accuracy & Custody-Rule Evidence; DP-349 Brokerage
Commissions & Account Service Charges; DP-350 Fee Invoicing, Mandate Billing & Performance Fees; DP-351 Fiduciary Account
Review Compliance; DP-352 Discretionary Distribution Decisions (restricted); DP-353 Trust Principal & Income Accounting;
DP-354 Estate Settlement Case Tracker; DP-355 Fiduciary Tax Filing & K-1 Status (restricted). DP-077 and DP-080 keep their
existing models.

Conventions used in these stars:
- Dimensions are conformed from the foundational WP2 models under the plain conformed names: Party, Household (a DP-240
  Party with Party Type = Household, PTY-HH-), Household Membership (DP-240 bridge), Client Account, Account Party Role,
  Program Enrollment, Account Agreement (DP-093), Advisor (DP-009 Employee, 20 Employee with 03 Advisor), Employee
  (DP-192), Program or Service Offering, Service Tier, Model Portfolio, Share Class (DP-004), Instrument (DP-097), Model
  (DP-212), Internal Legal Entity and Calendar Date (DP-013). Where the product reads that object as an input, the input
  sits on the conformed entity.
- The account-to-household path is always Client Account -> Account Party Role -> Party -> Household Membership ->
  Household (DP-240 bridge, effective dated); no household column is put on an account.
- Facts are built from the product's own inputs at their registry keys. Where the registry key holds an attribute the
  product does not read (for example Cash Balance Currency, Margin Snapshot Type, Data Basis), the fact is conformed from
  the foundational entity so the key stays whole.
- A Fact at a grain no input object holds (party, account or household x as-of date) borrows the keys of its dimensions
  ("<Dimension> Key"); the note says which business key it carries.
- Date roles are conformed from DP-013 Calendar Date; a date attribute on a fact is the foreign key to it.
- Multi-valued references (e.g. Recommendation Accounts, Accounts Reviewed) are drawn M:N; the build explodes them.
- A reference whose target product is not upstream stays an attribute and is listed under "External references".
- Three books of record (CW-007): client values come only from 49 Client Holding, Account Cash Balance and Margin Balance
  Snapshot (through DP-300) or the 06 Account Asset Summary (through DP-007); 06 Fund Shareholder Position is read only as a
  view (DP-320 omnibus residual) and 18 Portfolio data only for institutional mandates (DP-350). No fact joins 49 to 18 or
  06 as if they were one fact.
- Client Assets (DP-008) and Firm AUM (DP-241) are never added; DP-345 publishes the managed account slice DP-241
  certifies from, and DP-320's household client assets are a decomposition tied to DP-008.
- Special category (CD-344, CW-213): only DP-322 (02 Specified Adult Status, Vulnerability Concern, Rule 2165 rows of 15
  Account Restriction, 50 Money Movement Hold, 08 Senior Investor Case) and DP-352 (51 trust distribution purposes) hold
  special-category rows, in restricted Fact entities. Every other product carries only Protection Flag Present (from
  DP-322) as a measure joined on Party ID or Account ID; no model conforms an entity from DP-322.
- 08 Supervisory Review is DP-398's object (CLA-B). DP-334 and DP-335 conform DP-398 Supervisory Review Outcome (keyed on
  Supervisory Review ID) with their 08 inputs merged onto it, and the evidence facts carry its key.
"""


def dim(name, src, objects=(), note="", pk=None):
    """A conformed dimension: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role="Dimension", conformed=src, objects=list(objects), note=_tier(src, note))
    if pk:
        d["pk"] = list(pk)
    return d


def own(name, objects, pk, note=""):
    return dict(name=name, role="Dimension", objects=list(objects), pk=list(pk), note=note)


def fact(name, objects, pk, grain, note="", measures=False, src=None):
    d = dict(name=name, role="Fact", objects=list(objects), grain=grain, note=note, measures=measures)
    if src:
        d["conformed"] = src
        d["note"] = _tier(src, note)
    if pk:
        d["pk"] = list(pk)
    return d


def bridge(name, objects, pk, grain, note="", src=None):
    d = dict(name=name, role="Bridge", objects=list(objects), grain=grain, note=note)
    if src:
        d["conformed"] = src
        d["note"] = _tier(src, note)
    if pk:
        d["pk"] = list(pk)
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


# conformed sources
PARTY = ("DP-240", "Party")
HHMEM = ("DP-240", "Household Membership")
INVPROF = ("DP-240", "Investor Profile")
INVQ = ("DP-240", "Investor Qualification")
DEATH = ("DP-240", "Death Notification")
CONSENT = ("DP-240", "Consent Record")
AUTH = ("DP-240", "Authority Grant")
TCD = ("DP-240", "Trusted Contact Designation")
PREL = ("DP-240", "Party Relationship")
STA = ("DP-240", "Service Tier Assignment")
CLIREST = ("DP-240", "Client Restriction")
CPT = ("DP-240", "Contact Point")
ACCT = ("DP-093", "Account")
APR = ("DP-093", "Account Party Role")
ENROLL = ("DP-093", "Program Enrollment")
AGMT = ("DP-093", "Account Agreement")
BENE = ("DP-093", "Beneficiary Designation")
AREST = ("DP-093", "Account Restriction")
AHL = ("DP-093", "Account Hierarchy Link")
ASI = ("DP-093", "Account Standing Instruction")
ADVISOR = ("DP-009", "Employee")
COVER = ("DP-009", "Coverage Assignment")
EMP = ("DP-192", "Employee")
OFFER = ("DP-004", "Service Offering")
TIER = ("DP-004", "Service Tier")
MODELPF = ("DP-004", "Model Portfolio")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
INSTR = ("DP-097", "Instrument")
MODEL = ("DP-212", "Model")
CAL = ("DP-013", "Calendar Date")
ILE = ("DP-013", "Internal Legal Entity")
MV = ("DP-008", "Measure Value")
SNAP = ("DP-008", "Snapshot")
CAMPAIGN = ("DP-008", "Campaign")
AAS = ("DP-007", "Account Asset Summary")
HPG = ("DP-145", "Household Performance Group")
PERFRET = ("DP-145", "Performance Return")
BMKRET = ("DP-145", "Benchmark Return")
BMK145 = ("DP-145", "Benchmark")
ADENG = ("DP-303", "Advice Engagement")
GOAL = ("DP-303", "Financial Goal")
PLAN = ("DP-303", "Financial Plan")
PLANV = ("DP-303", "Financial Plan Version")
RECOM = ("DP-303", "Recommendation")
ADREV = ("DP-303", "Advice Review")
RIL = ("DP-303", "Recommendation Implementation Link")
SCEN = ("DP-303", "Planning Scenario")
PAS = ("DP-303", "Planning Assumption Set")
MASSIGN = ("DP-304", "Model Assignment")
HMG = ("DP-304", "Household Managed Group")
MAT = ("DP-304", "Managed Account Target")
ATOL = ("DP-304", "Account Target Override Line")
AIC = ("DP-304", "Account Investment Constraint")
DRIFT = ("DP-304", "Drift Assessment")
RUN = ("DP-304", "Rebalance Run")
SLEEVE = ("DP-304", "Sleeve Assignment")
COMPOSITE = ("DP-304", "Managed Account Composite")
FSCHED = ("DP-305", "Fee Schedule")
FTIER = ("DP-305", "Fee Schedule Tier")
FSA = ("DP-305", "Fee Schedule Assignment")
FRO = ("DP-305", "Fee Rate Override")
FWAIVE = ("DP-305", "Fee Waiver")
AFC = ("DP-305", "Account Fee Calculation")
FHH = ("DP-305", "Fee Household")
FHHM = ("DP-305", "Fee Household Membership")
BARR = ("DP-305", "Billing Arrangement")
SADV = ("DP-306", "Sub-Adviser Engagement")
TRUST = ("DP-307", "Trust")
TROLE = ("DP-307", "Trust Role")
BENINT = ("DP-307", "Beneficial Interest")
TTP = ("DP-307", "Trust Term Provision")
ESTATE = ("DP-307", "Estate Settlement Case")
PIA = ("DP-307", "Principal and Income Allocation")
PARTY307 = ("DP-307", "Party")
CASHBAL = ("DP-300", "Cash Balance")
MARGIN = ("DP-300", "Margin Balance Snapshot")
TAXLOT = ("DP-300", "Client Tax Lot")
LOTREL = ("DP-300", "Client Lot Relief")
CBADJ = ("DP-300", "Cost Basis Adjustment")
ACCTXFER = ("DP-300", "Account Transfer")
MM302 = ("DP-302", "Money Movement")
ACCT302 = ("DP-302", "Client Account")
CALLOC = ("DP-301", "Client Allocation")
CORDER = ("DP-301", "Client Order")
DELIV = ("DP-382", "Delivery Election")
DOCDEF = ("DP-382", "Investor Document Definition")
SREQ = ("DP-381", "Service Request")
CMA = ("DP-530", "Capital Market Assumption Set")
TAS = ("DP-530", "Target Allocation Set")
PART430 = ("DP-430", "Participant")
PART094 = ("DP-094", "Participant")
RPLAN = ("DP-094", "Retirement Plan")
INSTCLI = ("DP-003", "Institutional Client")
MANDATE = ("DP-140", "Investment Mandate")
PORT = ("DP-140", "Portfolio")
PIL = ("DP-140", "Portfolio Implementation Link")
PVS = ("DP-142", "Portfolio Valuation Summary")
SROUT = ("DP-398", "Supervisory Review Outcome")

_TIERS = {
    PARTY: "identity (individual and household parties; organizations hold no personal data)", HHMEM: "identity",
    INVPROF: "financial", INVQ: "financial", DEATH: "identity", CONSENT: "identity", AUTH: "identity", TCD: "identity",
    PREL: "identity", STA: "financial", CLIREST: "financial", CPT: "identity (contact values are not published)",
    ACCT: "financial", APR: "identity", ENROLL: "financial", AGMT: "financial", BENE: "identity",
    AREST: "identity (the Rule 2165 rows, special category, are excluded at read; only DP-322 holds them)",
    AHL: "none", ASI: "financial", ADVISOR: "identity (employee)", COVER: "identity", EMP: "identity (employee)",
    MV: "none (aggregates)", SNAP: "none", CAMPAIGN: "none", AAS: "financial", HPG: "financial", PERFRET: "none",
    BMKRET: "none", BMK145: "none", ADENG: "financial", GOAL: "financial", PLAN: "financial", PLANV: "financial",
    RECOM: "financial", ADREV: "financial", RIL: "none (keys only)", SCEN: "financial", PAS: "none",
    MASSIGN: "financial", HMG: "financial", MAT: "financial", ATOL: "financial", AIC: "financial", DRIFT: "financial",
    RUN: "none", SLEEVE: "financial", COMPOSITE: "none", FSCHED: "none", FTIER: "none", FSA: "financial",
    FRO: "financial", FWAIVE: "financial", AFC: "financial", FHH: "financial", FHHM: "financial",
    BARR: "financial where the client is an individual", SADV: "none", TRUST: "identity (a trust's name and terms reveal a family)",
    TROLE: "identity", BENINT: "financial and identity", ESTATE: "identity and financial", PIA: "financial",
    PARTY307: "identity", CASHBAL: "financial", MARGIN: "financial", TAXLOT: "financial", LOTREL: "financial",
    CBADJ: "financial", ACCTXFER: "financial", MM302: "financial", ACCT302: "financial", CALLOC: "financial",
    CORDER: "financial", DELIV: "identity", DOCDEF: "none", SREQ: "identity", CMA: "none", TAS: "none",
    PART430: "identity", PART094: "identity", RPLAN: "none", INSTCLI: "none (institutional organizations)",
    MANDATE: "none (client-confidential)", PORT: "none", PIL: "none", PVS: "none",
    TTP: "identity; special category (CD-344) where a provision names a beneficiary's disability (restricted entity)",
}


def _tier(src, note):
    if "PII tier" in note or src not in _TIERS:
        return note
    return (note + " " if note else "") + f"PII tier: {_TIERS[src]}."


FLAG = ("Protection Flag Present (from DP-322) is a measure here, read as published (Y or N per party and account) and "
        "joined on Party ID or Account ID; no special-category attribute is read (CW-213, CD-344). ")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-320": dict(
        style="Star",
        entities=[
            fact("Fact Household 360", [], ["Household Key", "As-Of Date Key"], measures=True,
                 grain="one row = Client Household (02 PTY-HH-) x as-of date (daily snapshot)",
                 note="The household tile row. No input object sits at household x date, so the fact borrows the "
                      "Household key (the household's Party ID) and the as-of date. It owns no certified number "
                      "(CW-211): Households, Ending Client Assets and Advised Assets are read from DP-008 and the "
                      "household return from DP-145. " + FLAG + "PII tier: financial."),
            fact("Fact Household Client Assets", [("06", "Account Asset Summary")],
                 ["Summary Account", "Summary As-Of Date", "Summary Holding Type"],
                 grain="one row = member account x as-of date x holding type (DP-007 account asset summary)",
                 note="The decomposition fact of Household Client Assets and Household Advised Assets: DP-008's scope "
                      "rules (Summary Source Book, Advised Assets Indicator) are applied by reference to these rows and "
                      "rolled to the household through the DP-240 bridge. It ties to the certified DP-008 Measure "
                      "Value with Non-Household Client Assets as the reconciling item; it is never summed with DP-008, "
                      "DP-241 Firm AUM or held-away assets. PII tier: financial."),
            fact("Fact Certified Client Assets", [("06", "Measure Value"), ("06", "Client Asset Measures")], None,
                 src=MV, grain="one row = DP-008 certified measure value (Households, Ending Client Assets, Advised "
                               "Assets) x period end x dimension x snapshot",
                 note="Conformed from DP-008 Measure Value because the registry key holds Data Basis, which the product "
                      "does not read. The certified side of the household tie-out; read, never recomputed (CW-011)."),
            fact("Fact Fund Position View", [("06", "Fund Shareholder Position"), ("06", "Omnibus Look-Through")],
                 ["Position ID"],
                 grain="one row = 06 fund shareholder position (a view)",
                 note="Read only for Omnibus Residual Amount, part of Non-Household Client Assets. 06 is a view, never "
                      "a second source of client holdings (CW-007); it is not added to the account asset summary rows. "
                      "PII tier: financial."),
            fact("Fact Goal Progress", [("45", "Goal Progress Snapshot")], ["Snapshot Goal", "Snapshot As-Of Date"],
                 grain="one row = financial goal x snapshot as-of date",
                 note="Shown, not scored (goal progress is DP-337's). PII tier: financial."),
            fact("Fact Held-Away Balance", [("45", "Aggregated Account Balance")],
                 ["Balance Aggregated Account", "Balance As-Of Date"],
                 grain="one row = aggregated (held-away) account x balance as-of date",
                 note="Held-Away Assets; never added to Client Assets. PII tier: financial."),
            fact("Fact Household Return", [("32", "Personal Rate of Return")], ["Personal Rate of Return ID"],
                 grain="one row = personal rate of return (household performance group x period x method)",
                 note="Household Personal Rate of Return, read from DP-145 with its method. PII tier: financial."),
            fact("Fact Service Contact", [("13", "Contact Center Interaction")], ["Interaction ID"],
                 grain="one row = contact center interaction",
                 note="Recent Service Contacts (trailing 90 days). PII tier: identity (party key)."),
            dim("Party", PARTY, [("02", "Party"), ("02", "Individual"), ("02", "Household")],
                note="Members and households are both 02 parties; Individual and Household fold onto the party."),
            dim("Household", PARTY, note="Role of DP-240 Party restricted to Party Type = Household (PTY-HH-); the "
                                         "02 Client Household, never the 13 mailing or 47 fee household."),
            bridge("Household Membership", [("02", "Household Membership")], None, src=HHMEM,
                   grain="one row = household x member party x membership effective period",
                   note="The DP-240 bridge every account reaches its household through."),
            bridge("Service Tier Assignment", [("02", "Service Tier Assignment")], None, src=STA,
                   grain="one row = party x service tier x effective period",
                   note="Service Tier Qualification Mismatch (DP-325 folds in)."),
            dim("Service Tier", TIER, [("01", "Service Tier")]),
            dim("Investor Profile", INVPROF, [("02", "Investor Profile")]),
            dim("Consent Record", CONSENT, [("02", "Consent Record")]),
            dim("Client Account", ACCT, [("15", "Account")]),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x account role type x effective period",
                   note="Owner roles take the account to its member parties."),
            dim("Program Enrollment", ENROLL, [("15", "Program Enrollment")]),
            dim("Service Offering", OFFER),
            dim("Model Assignment", MASSIGN, [("46", "Model Assignment")]),
            dim("Model Portfolio", MODELPF),
            bridge("Household Managed Group", [("46", "Household Managed Group")], None, src=HMG,
                   grain="one row = household x member account x group effective period"),
            dim("Fee Household", FHH, [("47", "Fee Household")],
                note="The 47 fee household, aligned to (never the same as) the 02 household."),
            bridge("Fee Household Membership", [("47", "Fee Household Membership")], None, src=FHHM,
                   grain="one row = fee household x member account x effective period",
                   note="Fee Household Alignment Breaks compare it with the 02 path."),
            dim("Advice Engagement", ADENG, [("45", "Advice Engagement")]),
            dim("Advisor", ADVISOR),
            bridge("Party Coverage Assignment", [("03", "Party Coverage Assignment")], None, src=COVER,
                   grain="one row = coverage assignment (party x covering advisor x role x period)",
                   note="Households Without Primary Advisor: 02 Household has no advisor of record, so coverage is "
                        "read from 03."),
            dim("Financial Goal", GOAL, [("45", "Financial Goal")]),
            dim("Financial Plan", PLAN, [("45", "Client Financial Plan")]),
            dim("Financial Plan Version", PLANV, [("45", "Client Financial Plan Version")]),
            own("Held-Away Account", [("45", "Aggregated Account")], ["Aggregated Account ID"],
                note="No foundational model publishes 45 Aggregated Account. PII tier: financial (restricted: masked "
                     "account number)."),
            dim("Trust", TRUST, [("51", "Trust")], note="Trust panel; optional with DP-307."),
            dim("Household Performance Group", HPG, [("32", "Household Performance Group")]),
            dim("Share Class", SHARE),
            dim("Snapshot", SNAP),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Household 360", "Household", ["Household Key"], note="Carries the household's Party ID."),
            rel("Fact Household 360", "As-Of Date", ["As-Of Date Key"]),
            rel("Household Membership", "Household", ["Household"]),
            rel("Household Membership", "Party", ["Household Member"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Fact Household Client Assets", "Client Account", ["Summary Account"]),
            rel("Fact Household Client Assets", "As-Of Date", ["Summary As-Of Date"]),
            rel("Fact Household Client Assets", "Fact Certified Client Assets", ["Summary As-Of Date"], card="M:N",
                note="Tie-out on period end: decomposed household client assets plus Non-Household Client Assets "
                     "equal DP-008 Ending Client Assets; reconciled, never added."),
            rel("Fact Certified Client Assets", "Snapshot", ["Snapshot"]),
            rel("Fact Certified Client Assets", "As-Of Date", ["Period End Date"]),
            rel("Fact Fund Position View", "Client Account", ["Account"]),
            rel("Fact Fund Position View", "Client Account", ["Omnibus Parent Account"], optional=True),
            rel("Fact Fund Position View", "Share Class", ["Share Class"]),
            rel("Service Tier Assignment", "Party", ["Tier Party"]),
            rel("Service Tier Assignment", "Service Tier", ["Assigned Service Tier"]),
            rel("Service Tier Assignment", "Advisor", ["Override Approver"], optional=True),
            rel("Investor Profile", "Party", ["Profile Client"]),
            rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
            rel("Program Enrollment", "Service Offering", ["Enrolled Service Offering"]),
            rel("Model Assignment", "Client Account", ["Assigned Account"]),
            rel("Model Assignment", "Model Portfolio", ["Assigned Model Portfolio"]),
            rel("Household Managed Group", "Household", ["Managed Group Household"]),
            rel("Household Managed Group", "Client Account", ["Group Member Account"]),
            rel("Fee Household", "Household", ["Anchor Client Household"]),
            rel("Fee Household Membership", "Fee Household", ["Membership Fee Household"]),
            rel("Fee Household Membership", "Client Account", ["Member Account"]),
            rel("Advice Engagement", "Party", ["Engagement Client"]),
            rel("Advice Engagement", "Advisor", ["Engagement Advisor"]),
            rel("Party Coverage Assignment", "Party", ["Covered Party"]),
            rel("Party Coverage Assignment", "Advisor", ["Covering Advisor"]),
            rel("Financial Goal", "Party", ["Goal Owner"]),
            rel("Fact Goal Progress", "Financial Goal", ["Snapshot Goal"]),
            rel("Fact Goal Progress", "As-Of Date", ["Snapshot As-Of Date"]),
            rel("Financial Plan", "Party", ["Plan Subject"]),
            rel("Financial Plan Version", "Financial Plan", ["Versioned Plan"]),
            rel("Held-Away Account", "Party", ["Aggregated Account Owner"]),
            rel("Held-Away Account", "Consent Record", ["Aggregation Consent"]),
            rel("Fact Held-Away Balance", "Held-Away Account", ["Balance Aggregated Account"]),
            rel("Fact Held-Away Balance", "As-Of Date", ["Balance As-Of Date"]),
            rel("Trust", "Party", ["Trust Party"]),
            rel("Household Performance Group", "Household", ["Group Household"]),
            rel("Fact Household Return", "Household Performance Group", ["Personal Return Group"]),
            rel("Fact Service Contact", "Party", ["Interaction Party"]),
        ],
        notes=("Household 360 owns no certified number (CW-211). Household Client Assets is a decomposition fact over "
               "DP-007 account asset summary rows tied to the DP-008 certified measure value, with Non-Household "
               "Client Assets (omnibus residual from the 06 view and accounts with no household owner) as the named "
               "reconciling item; it is never a sum of DP-008 and DP-241, and held-away balances stay a separate fact. "
               "Accounts reach the household only through Account Party Role -> Party -> Household Membership (DP-240). "
               "Conformed: DP-240 (Party, Household, Household Membership, Service Tier Assignment, Investor Profile, "
               "Consent Record), DP-093 (Client Account, Account Party Role, Program Enrollment), DP-004 (Service Tier, "
               "Service Offering, Model Portfolio, Share Class), DP-008 (Measure Value, Snapshot), DP-145 (Household "
               "Performance Group), DP-303 (Advice Engagement, Financial Goal, Financial Plan, Financial Plan Version), "
               "DP-304 (Model Assignment, Household Managed Group), DP-305 (Fee Household, Fee Household Membership), "
               "DP-307 (Trust), DP-009 (Advisor, Party Coverage Assignment), DP-013 (Calendar Date). Model gap: no input "
               "object sits at household x as-of date, so Fact Household 360 borrows the Household and As-Of Date keys. "
               "DP-322 and DP-381 are upstream for measures only (Protection Flag Present; the interaction is read from "
               "its 13 object).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-321": dict(
        style="Star",
        entities=[
            fact("Fact Account Authority Test", [], ["Client Account Key", "As-Of Date Key"], measures=True,
                 grain="one row = account (15) x as-of date (Rule 4512 trusted contact and beneficiary tests)",
                 note="Carries Account ID (Client Account Key) and the as-of date; no input object sits at this grain. "
                      + FLAG + "PII tier: identity."),
            fact("Fact Authority Grant", [("02", "Authority Grant")], ["Authority Grant ID"],
                 grain="one row = authority grant (AGNT-) version, SCD type 2",
                 note="PII tier: identity (agents named by clients)."),
            fact("Fact Trusted Contact Designation", [("02", "Trusted Contact Designation")],
                 ["Trusted Contact Designation ID"], grain="one row = trusted contact designation (TCNT-) version",
                 note="Account Scope blank means all accounts of the client. PII tier: identity."),
            fact("Fact Beneficiary Designation", [("15", "Beneficiary Designation")], ["Beneficiary Designation ID"],
                 grain="one row = beneficiary designation version",
                 note="Spousal Consent Missing and Deceased Beneficiaries; the allocation check stays DP-093's. "
                      "PII tier: identity."),
            fact("Fact Death Notification", [("02", "Death Notification")], ["Death Notification ID"],
                 grain="one row = death notification (DTHN-)", note="PII tier: identity."),
            fact("Fact Account Restriction", [("15", "Account Restriction")], ["Account Restriction ID"],
                 grain="one row = account restriction (deceased-account restrictions)",
                 note="Deaths Notified Not Restricted and Notification to Restriction Days. Rule 2165 hold rows are "
                      "special category and excluded at read; they are DP-322's. PII tier: identity."),
            dim("Party", PARTY, [("02", "Party"), ("02", "Individual")]),
            dim("Client Account", ACCT, [("15", "Account")]),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period"),
            bridge("Party Relationship", [("02", "Party Relationship")], None, src=PREL,
                   grain="one row = from party x to party x relationship type x effective period",
                   note="Spouse on record for the IRA spousal consent test."),
            dim("Service Request", SREQ, note="Intake request of a grant; resolved through DP-381."),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Account Authority Test", "Client Account", ["Client Account Key"]),
            rel("Fact Account Authority Test", "As-Of Date", ["As-Of Date Key"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Fact Authority Grant", "Party", ["Grantor Party"]),
            rel("Fact Authority Grant", "Party", ["Authority Holder"]),
            rel("Fact Authority Grant", "Client Account", ["Accounts Covered"], card="M:N"),
            rel("Fact Authority Grant", "Service Request", ["Intake Service Request"], optional=True),
            rel("Fact Trusted Contact Designation", "Party", ["Designating Client"]),
            rel("Fact Trusted Contact Designation", "Party", ["Trusted Contact Person"]),
            rel("Fact Trusted Contact Designation", "Client Account", ["Account Scope"], optional=True),
            rel("Fact Beneficiary Designation", "Client Account", ["Designated Account"]),
            rel("Fact Beneficiary Designation", "Party", ["Beneficiary"]),
            rel("Fact Death Notification", "Party", ["Deceased Party"]),
            rel("Fact Death Notification", "Party", ["Estate Representative"], optional=True),
            rel("Fact Death Notification", "Fact Authority Grant", ["Representative Authority Grant"], optional=True),
            rel("Fact Account Restriction", "Client Account", ["Restricted Account"]),
            rel("Party Relationship", "Party", ["From Party"]),
            rel("Party Relationship", "Party", ["To Party"]),
        ],
        notes=("Registers of the third parties a client names, each a fact at its own SCD type 2 grain, around an "
               "account x as-of date test fact. Conformed: DP-240 (Party, Party Relationship), DP-093 (Client Account, "
               "Account Party Role), DP-381 (Service Request), DP-013 (Calendar Date). The register objects are facts "
               "built from the product's inputs (their DP-240 and DP-093 entities share the same natural keys). Model "
               "gap: the test fact borrows the Client Account and As-Of Date keys. DP-322 is upstream for Protection "
               "Flag Present only.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-322": dict(
        style="Star",
        entities=[
            fact("Fact Party Protection Flag", [("02", "Party")], ["Party ID", "As-Of Date Key"], measures=True,
                 grain="one row = protected client (02 party) x as-of date, SCD type 2 on the flag",
                 note="Restricted fact keyed on Party ID. Only Party ID and Protection Flag Present leave the "
                      "restricted view; aggregates outside it keep a minimum cell size of 10 (DQ5). PII tier: special "
                      "category (CD-344) inside the view; identity for the published flag."),
            fact("Fact Account Protection Flag", [("15", "Account")], ["Account ID", "As-Of Date Key"],
                 grain="one row = 15 account x as-of date",
                 note="Restricted fact keyed on Account ID; the account flag other products join on. PII tier: "
                      "special category (CD-344) inside the view; financial for the published flag."),
            fact("Fact Specified Adult Status", [("02", "Specified Adult Status")],
                 ["Party Key", "Specified Adult Basis", "Specified Adult Status Effective From"],
                 grain="one row = party x specified adult basis x effective period",
                 note="Restricted fact. PII tier: special category (CD-344). Model gap: the attribute group carries no "
                      "party key of its own, so it borrows Party Key (the Party ID)."),
            fact("Fact Vulnerability Concern", [("02", "Vulnerability Concern")], ["Vulnerability Concern ID"],
                 grain="one row = vulnerability concern",
                 note="Restricted fact keyed to the party by Concern Party. PII tier: special category (CD-344)."),
            fact("Fact Rule 2165 Restriction", [("15", "Account Restriction")], ["Account Restriction ID"],
                 grain="one row = account restriction (the Rule 2165 rows)",
                 note="Restricted fact keyed to the account by Restricted Account; DP-403 reads its key rows. PII tier: "
                      "special category (CD-344) on Rule 2165 rows, otherwise identity."),
            fact("Fact Money Movement Hold", [("50", "Money Movement Hold")], ["Money Movement Hold ID"],
                 grain="one row = money movement hold (Rule 2165 and 2166 rows)",
                 note="Restricted fact; DP-302 suppresses these hold values and leaves them here (F3 ruling). Keyed to "
                      "the account through the held movement. PII tier: special category (CD-344)."),
            fact("Fact Senior Investor Case", [("08", "Senior Investor Case")], ["Senior Investor Case ID"],
                 grain="one row = senior investor case",
                 note="Restricted fact keyed to the party by Case Client; case ageing is DP-403's. PII tier: special "
                      "category (CD-344)."),
            dim("Party", PARTY),
            dim("Client Account", ACCT),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period",
                   note="Carries the party flag to the accounts the party owns."),
            dim("Trusted Contact Designation", TCD, [("02", "Trusted Contact Designation")]),
            dim("Authority Grant", AUTH, [("02", "Authority Grant")]),
            dim("Money Movement", MM302, [("50", "Money Movement")]),
            dim("Employee", EMP),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Party Protection Flag", "Party", ["Party ID"]),
            rel("Fact Party Protection Flag", "As-Of Date", ["As-Of Date Key"]),
            rel("Fact Account Protection Flag", "Client Account", ["Account ID"]),
            rel("Fact Account Protection Flag", "As-Of Date", ["As-Of Date Key"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Fact Specified Adult Status", "Party", ["Party Key"]),
            rel("Fact Specified Adult Status", "Employee", ["Determined By"], optional=True),
            rel("Fact Vulnerability Concern", "Party", ["Concern Party"]),
            rel("Fact Vulnerability Concern", "Trusted Contact Designation", ["Trusted Contact Designation Used"],
                optional=True),
            rel("Fact Vulnerability Concern", "Fact Senior Investor Case", ["Escalation Case Reference"], optional=True),
            rel("Trusted Contact Designation", "Party", ["Designating Client"]),
            rel("Trusted Contact Designation", "Party", ["Trusted Contact Person"]),
            rel("Authority Grant", "Party", ["Grantor Party"]),
            rel("Authority Grant", "Party", ["Authority Holder"]),
            rel("Fact Rule 2165 Restriction", "Client Account", ["Restricted Account"]),
            rel("Fact Rule 2165 Restriction", "Fact Vulnerability Concern", ["Source Vulnerability Concern"],
                optional=True),
            rel("Fact Senior Investor Case", "Party", ["Case Client"]),
            rel("Fact Senior Investor Case", "Fact Vulnerability Concern", ["Source Vulnerability Concern"],
                optional=True),
            rel("Fact Money Movement Hold", "Money Movement", ["Held Movement"]),
            rel("Fact Money Movement Hold", "Trusted Contact Designation", ["Trusted Contact Notified"], optional=True),
            rel("Fact Money Movement Hold", "Fact Vulnerability Concern", ["Source Vulnerability Concern"],
                optional=True),
            rel("Fact Money Movement Hold", "Fact Rule 2165 Restriction", ["Paired Account Restriction"], optional=True),
            rel("Fact Money Movement Hold", "Fact Senior Investor Case", ["Senior Investor Case"], optional=True),
            rel("Money Movement", "Client Account", ["Movement Account"]),
        ],
        notes=("The CW-213 restricted view. The Protection Flag (per party and per account) and the specified adult, "
               "vulnerability concern, Rule 2165 restriction, money movement hold and senior investor case rows are "
               "restricted Fact entities keyed on Party ID and Account ID, each with its tier in the note; the 02 Party "
               "and 15 Account input objects sit on the flag facts so the published keys are the business keys. The "
               "conformed Party and Client Account dimensions carry no special-category attribute. Conformed: DP-240 "
               "(Party, Trusted Contact Designation, Authority Grant), DP-093 (Client Account, Account Party Role), "
               "DP-302 (Money Movement), DP-192 (Employee), DP-013 (Calendar Date). Model gap: 02 Specified Adult Status "
               "has no party key (Party Key borrowed). 08 Senior Investor Case is mastered by no foundational model and "
               "is a fact here. The hold clock and case ageing measures are DP-403's (publication ruling).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-324": dict(
        style="Star",
        entities=[
            fact("Fact Contact Permission", [("02", "Contact Preference")], ["Preference Holder", "Preference Effective From"],
                 measures=True,
                 grain="one row = party x contact preference version (SCD type 2), exploded to party x contact channel "
                       "x as-of date by Do Not Contact Channels and the party's contact points",
                 note="Contactable Clients by Channel and the contact rule set. The daily view date is borrowed (As-Of "
                      "Date Key). PII tier: identity."),
            fact("Fact Marketing Permission", [("02", "Communication Preference")],
                 ["Preference Party", "Preference Topic", "Preference Channel"],
                 grain="one row = party x subscription topic x channel",
                 note="Marketing Permission (read by DP-412). Preference Topic is a 04 Subscription Topic key (external "
                      "reference). PII tier: identity."),
            fact("Fact Statement Contact Mode", [("13", "E-Delivery Election"), ("13", "Mail Hold")],
                 ["Delivery Election ID"], grain="one row = account x delivery election",
                 note="Read only to set the contact mode; DP-382 owns the election measures. PII tier: identity."),
            fact("Fact Suppression Entry", [("04", "Suppression Entry")], ["Suppressed Identifier", "Suppression Scope"],
                 grain="one row = suppressed identifier x suppression scope",
                 note="Suppressed Identifier is a hashed contact value with no party key, so the entry joins to the "
                      "party only through the revoked consent record. PII tier: identity."),
            dim("Party", PARTY, [("02", "Party"), ("02", "Individual"), ("02", "Privacy Profile")],
                note="Privacy Profile folds onto the party (affiliate marketing opt-out, do not contact)."),
            dim("Contact Point", CPT, [("02", "Contact Point"), ("02", "Postal Address")],
                note="Contact values are not published; consumers resolve Contact Point ID through DP-240 (DQ5). Mail "
                     "Returned Date is the Derived copy of 13 read on the 02 contact point."),
            dim("Consent Record", CONSENT, [("02", "Consent Record")]),
            dim("Client Account", ACCT),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period",
                   note="Takes the account's contact mode to its owners."),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Contact Permission", "Party", ["Preference Holder"]),
            rel("Fact Contact Permission", "Contact Point", ["Preferred Contact Point"], optional=True),
            rel("Fact Contact Permission", "As-Of Date", ["As-Of Date Key"]),
            rel("Contact Point", "Party", ["Contact Point Party"]),
            rel("Fact Marketing Permission", "Party", ["Preference Party"]),
            rel("Fact Marketing Permission", "Consent Record", ["Consent Record Reference"], optional=True),
            rel("Consent Record", "Party", ["Consenting Party"]),
            rel("Fact Statement Contact Mode", "Client Account", ["Election Account"]),
            rel("Fact Statement Contact Mode", "Consent Record", ["Linked Consent Record"], optional=True),
            rel("Fact Suppression Entry", "Consent Record", ["Revoked Consent Record"], optional=True),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
        ],
        notes=("Permissions are per party; the household is not used. Conformed: DP-240 (Party, Contact Point, Consent "
               "Record), DP-093 (Client Account, Account Party Role), DP-013 (Calendar Date). The 13 election is a fact "
               "built from its inputs (DP-382's Delivery Election shares the key). External references: Communication "
               "Preference.Preference Topic -> 04 Subscription Topic (no upstream product publishes it). Model gap: "
               "the contact permission fact borrows the As-Of Date key for the daily view of SCD type 2 rows.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-329": dict(
        style="Star",
        entities=[
            fact("Fact RMD", [("15", "RMD Record")], ["RMD Account", "RMD Distribution Year"], measures=True,
                 grain="one row = IRA account x distribution year (RMD Record), daily through the year",
                 note="RMD Prior Year-End Value and RMD Satisfied Amount (Derived copies of 49 and 50) are not read; "
                      "the masters are compared. PII tier: financial."),
            fact("Fact Retirement Distribution", [("50", "Money Movement")], ["Money Movement ID"],
                 grain="one row = money movement (settled retirement distributions)",
                 note="Every settled retirement distribution in the year counts toward the RMD (no reason code). "
                      "PII tier: financial."),
            fact("Fact Withholding Election", [("15", "Retirement Distribution Election")],
                 ["Withholding Election Account", "Withholding Election Type", "Withholding Election Effective From"],
                 grain="one row = account x withholding election type x effective period", note="PII tier: financial."),
            fact("Fact Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
                 ["Client Holding ID"], grain="one row = client holding (End of Day view at prior year-end)",
                 note="Prior Year-End Fair Market Value from the client book of record (CW-007). PII tier: financial."),
            fact("Fact Cash Balance", [("49", "Account Cash Balance")], None, src=CASHBAL,
                 grain="one row = account x currency x cash balance type x basis x business date",
                 note="Conformed from DP-300 because Cash Balance Currency is in the key and not read."),
            fact("Fact Margin Balance", [("49", "Margin Balance Snapshot")], None, src=MARGIN,
                 grain="one row = margin balance snapshot of an account",
                 note="Conformed from DP-300 because Margin Snapshot Type and As-Of Timestamp are in the key."),
            fact("Fact Managed Account Cash Raise", [("46", "Managed Account Cash Instruction")], ["Cash Instruction ID"],
                 grain="one row = managed account cash instruction",
                 note="Managed Account RMD Raises Late. PII tier: financial."),
            fact("Fact Participant Distribution Election", [("16", "Participant Distribution Election")],
                 ["Distribution Election Membership", "Distribution Election Type", "Distribution Election Effective From"],
                 grain="one row = plan membership x distribution election type x effective period",
                 note="Participant Distribution Elections (DP-470 folds in). PII tier: financial."),
            dim("Client Account", ACCT, [("15", "Account"), ("15", "Retirement Account Detail")],
                note="Retirement Account Detail folds onto the account."),
            dim("Party", PARTY, [("02", "Individual")], note="Date of birth (masked) and death for the RMD age test."),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period"),
            dim("Beneficiary Designation", BENE, [("15", "Beneficiary Designation")]),
            dim("Account Standing Instruction", ASI, [("15", "Account Standing Instruction")]),
            dim("Participant", PART094),
            dim("Value Date", CAL),
        ],
        relationships=[
            rel("Fact RMD", "Client Account", ["RMD Account"]),
            rel("Client Account", "Party", ["Inherited IRA Decedent"], optional=True),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Beneficiary Designation", "Client Account", ["Designated Account"]),
            rel("Beneficiary Designation", "Party", ["Beneficiary"]),
            rel("Account Standing Instruction", "Client Account", ["Instruction Account"]),
            rel("Fact Withholding Election", "Client Account", ["Withholding Election Account"]),
            rel("Fact Retirement Distribution", "Client Account", ["Movement Account"]),
            rel("Fact Retirement Distribution", "Value Date", ["Value Date"]),
            rel("Fact Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Client Holding", "Value Date", ["Client Holding Date"]),
            rel("Fact Cash Balance", "Client Account", ["Cash Balance Account"]),
            rel("Fact Margin Balance", "Client Account", ["Margin Snapshot Account"]),
            rel("Fact Managed Account Cash Raise", "Client Account", ["Instruction Account"]),
            rel("Fact Managed Account Cash Raise", "Fact RMD", ["Source RMD Record"], optional=True,
                note="Single reference to the RMD record; the distribution year comes from Required By Date."),
            rel("Fact Participant Distribution Election", "Participant", ["Distribution Election Membership"]),
            rel("Participant", "Client Account", ["Participant Account"], optional=True),
        ],
        notes=("Book of record: Client Holding, Account Cash Balance and Margin Balance Snapshot (49) through DP-300 "
               "(CW-007); distributions from 50 Money Movement. Conformed: DP-093 (Client Account, Account Party Role, "
               "Beneficiary Designation, Account Standing Instruction), DP-240 (Party), DP-300 (Cash Balance, Margin "
               "Balance Snapshot), DP-094 (Participant), DP-013 (Calendar Date). DP-302 and DP-304 are read through "
               "their 50 and 46 objects (facts built from inputs). Participant Distribution Election joins the retail "
               "account only through the membership's Participant Account.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-332": dict(
        style="Star",
        entities=[
            fact("Fact Rule 3a-4 Enrollment", [("15", "Program Enrollment")], ["Program Enrollment ID", "As-Of Date Key"],
                 measures=True,
                 grain="one row = program enrollment (Rule 3a-4 Program Indicator = Y) x as-of date; quarterly "
                       "snapshots locked",
                 note="Reasonable Restrictions explode to the accepted-restriction companion rows (enrollment x 02 "
                      "client restriction). PII tier: financial."),
            fact("Fact Account Investment Constraint", [("46", "Account Investment Constraint")], None, src=AIC,
                 grain="one row = account x source restriction or provision x constraint type x effective period",
                 note="Conformed from DP-304 because Source Trust Term Provision is in the key and not read. Restrictions "
                      "Not Implemented and Constraints Without Accepted Restriction."),
            fact("Fact Quarterly Statement", [("13", "Investor Document")], ["Investor Document ID"],
                 grain="one row = investor document (quarterly statements)", note="PII tier: financial."),
            dim("Program", OFFER, [("01", "Service Offering")], note="Rule 3a-4 and wrap fee program indicators."),
            dim("Client Account", ACCT, [("15", "Account")]),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period"),
            bridge("Account Hierarchy Link", [("15", "Account Hierarchy Link")], None, src=AHL,
                   grain="one row = parent account x child account x link type x effective period",
                   note="Linked-Account Enrollments."),
            dim("Account Agreement", AGMT, [("15", "Account Agreement")]),
            dim("Client Restriction", CLIREST, [("02", "Client Restriction")]),
            dim("Investor Profile", INVPROF, [("02", "Investor Profile")]),
            dim("Party", PARTY),
            dim("Advice Review", ADREV, [("45", "Advice Review")], note="Annual contact evidence."),
            dim("Recommendation", RECOM, [("45", "Recommendation")]),
            dim("Model Assignment", MASSIGN, [("46", "Model Assignment")]),
            dim("Investor Document Definition", DOCDEF, [("13", "Investor Document Definition")]),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Rule 3a-4 Enrollment", "As-Of Date", ["As-Of Date Key"]),
            rel("Fact Rule 3a-4 Enrollment", "Client Account", ["Enrolled Account"]),
            rel("Fact Rule 3a-4 Enrollment", "Program", ["Enrolled Service Offering"]),
            rel("Fact Rule 3a-4 Enrollment", "Recommendation", ["Source Recommendation"], optional=True),
            rel("Fact Rule 3a-4 Enrollment", "Account Agreement", ["Advisory Agreement"]),
            rel("Fact Rule 3a-4 Enrollment", "Client Restriction", ["Reasonable Restrictions"], card="M:N",
                note="The accepted reasonable restrictions (companion rows)."),
            rel("Account Agreement", "Client Account", ["Agreement Account"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Account Hierarchy Link", "Client Account", ["Parent Account"]),
            rel("Account Hierarchy Link", "Client Account", ["Child Account"]),
            rel("Client Restriction", "Party", ["Restricted Party"]),
            rel("Client Restriction", "Client Account", ["Restricted Accounts"], card="M:N"),
            rel("Investor Profile", "Party", ["Profile Client"]),
            rel("Advice Review", "Fact Rule 3a-4 Enrollment", ["Reviewed Program Enrollments"], card="M:N"),
            rel("Advice Review", "Investor Profile", ["Profile Version Confirmed"], optional=True),
            rel("Model Assignment", "Client Account", ["Assigned Account"]),
            rel("Model Assignment", "Fact Rule 3a-4 Enrollment", ["Assignment Program Enrollment"]),
            rel("Fact Account Investment Constraint", "Client Account", ["Constrained Account"]),
            rel("Fact Account Investment Constraint", "Client Restriction", ["Source Client Restriction"], optional=True),
            rel("Fact Quarterly Statement", "Client Account", ["Document Account"]),
            rel("Fact Quarterly Statement", "Investor Document Definition", ["Document Definition"]),
        ],
        notes=("Conformed: DP-004 (Program), DP-093 (Client Account, Account Party Role, Account Hierarchy Link, Account "
               "Agreement), DP-240 (Client Restriction, Investor Profile, Party), DP-303 (Advice Review, "
               "Recommendation), DP-304 (Model Assignment, Account Investment Constraint), DP-382 (Investor Document "
               "Definition), DP-013 (Calendar Date). The enrollment is the product's grain, so it is a fact built "
               "from its input (same natural key as DP-093's Program Enrollment) that borrows the As-Of Date key.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-333": dict(
        style="Star",
        entities=[
            fact("Fact Advice Referral", [("03", "Channel Referral")], ["Referral ID"], measures=True,
                 grain="one row = funnel entry: 03 channel referral to an advice channel, carried to the stage reached; "
                       "cohorts by entry month",
                 note="The funnel spine; a lead entering without a referral is a Fact Lead Hand-Off row matched to its "
                      "engagement by party and date (taxonomy gap). PII tier: identity (referred party)."),
            fact("Fact Lead Hand-Off", [("04", "Marketing Lead"), ("04", "Lead Conversion")], ["Lead ID"],
                 grain="one row = marketing lead whose converted party opened an engagement",
                 note="Lead Conversion folds onto the lead. PII tier: identity."),
            fact("Fact Advice Engagement", [("45", "Advice Engagement")], ["Advice Engagement ID"],
                 grain="one row = advice engagement (stage: engagement opened)", note="PII tier: financial."),
            fact("Fact Plan Presented", [("45", "Client Financial Plan Version")], ["Client Financial Plan Version ID"],
                 grain="one row = financial plan version (stage: plan presented and accepted)",
                 note="PII tier: financial."),
            fact("Fact Program Recommendation", [("45", "Recommendation")], ["Recommendation ID"],
                 grain="one row = program recommendation (stage: recommended and decided)", note="PII tier: financial."),
            fact("Fact Enrollment", [("15", "Program Enrollment")], ["Program Enrollment ID"],
                 grain="one row = program enrollment (stage: enrolled)", note="PII tier: financial."),
            fact("Fact Assets Enrolled", [("06", "Account Asset Summary")], None, src=AAS,
                 grain="one row = enrolled account x as-of date x holding type",
                 note="Conformed from DP-007 because Summary Holding Type is in the key and not read. Assets Enrolled "
                      "is operational; the certified Advised Assets and NNA are read from DP-008."),
            fact("Fact Certified Advised Assets", [("06", "Measure Value"), ("06", "Client Asset Measures")], None,
                 src=MV, grain="one row = DP-008 measure value (Advised Assets, Net New Assets) x period end x dimension "
                               "x snapshot",
                 note="Conformed from DP-008 (Data Basis is in the key); read, never recomputed (CW-011, CW-142)."),
            bridge("Recommendation Implementation Link", [("45", "Recommendation Implementation Link")], None, src=RIL,
                   grain="one row = recommendation x implementing record (enrollment)"),
            dim("Financial Plan", PLAN, [("45", "Client Financial Plan")]),
            dim("Advisor", ADVISOR, [("03", "Advisor")], note="Advisors Accepting New Clients."),
            dim("Party", PARTY),
            dim("Client Account", ACCT),
            dim("Service Offering", OFFER),
            dim("Campaign", CAMPAIGN),
            dim("Snapshot", SNAP),
            dim("Stage Date", CAL),
        ],
        relationships=[
            rel("Fact Advice Referral", "Party", ["Referred Party"]),
            rel("Fact Advice Referral", "Advisor", ["Target Advisor"], optional=True),
            rel("Fact Advice Referral", "Fact Advice Engagement", ["Resulting Advice Engagement"], optional=True),
            rel("Fact Advice Referral", "Fact Enrollment", ["Resulting Program Enrollment"], optional=True),
            rel("Fact Advice Referral", "Fact Lead Hand-Off", ["Resulting Marketing Lead"], optional=True),
            rel("Fact Advice Referral", "Stage Date", ["Referral Date"]),
            rel("Fact Lead Hand-Off", "Party", ["Lead Party"]),
            rel("Fact Lead Hand-Off", "Party", ["Converted Party"], optional=True),
            rel("Fact Lead Hand-Off", "Campaign", ["Original Campaign"], optional=True),
            rel("Fact Advice Engagement", "Party", ["Engagement Client"]),
            rel("Fact Advice Engagement", "Advisor", ["Engagement Advisor"]),
            rel("Fact Advice Engagement", "Service Offering", ["Engagement Service Offering"], optional=True),
            rel("Financial Plan", "Fact Advice Engagement", ["Plan Engagement"]),
            rel("Fact Plan Presented", "Financial Plan", ["Versioned Plan"]),
            rel("Fact Program Recommendation", "Fact Advice Engagement", ["Recommendation Engagement"]),
            rel("Fact Program Recommendation", "Party", ["Recommended Client"]),
            rel("Fact Program Recommendation", "Service Offering", ["Recommended Service Offering"]),
            rel("Recommendation Implementation Link", "Fact Program Recommendation", ["Implemented Recommendation"]),
            rel("Recommendation Implementation Link", "Fact Enrollment", ["Implementing Enrollment"]),
            rel("Fact Enrollment", "Client Account", ["Enrolled Account"]),
            rel("Fact Enrollment", "Service Offering", ["Enrolled Service Offering"]),
            rel("Fact Enrollment", "Fact Program Recommendation", ["Source Recommendation"], optional=True),
            rel("Fact Assets Enrolled", "Client Account", ["Summary Account"]),
            rel("Fact Certified Advised Assets", "Snapshot", ["Snapshot"]),
            rel("Fact Certified Advised Assets", "Stage Date", ["Period End Date"]),
        ],
        notes=("The funnel is a chain of stage facts (referral or lead -> engagement -> plan -> recommendation -> "
               "enrollment), each at its own object's grain and joined by the stage references. Conformed: DP-009 "
               "(Advisor), DP-240 (Party), DP-093 (Client Account), DP-004 (Service Offering), DP-303 (Financial Plan, "
               "Recommendation Implementation Link), DP-007 (Account Asset Summary), DP-008 (Measure Value, Snapshot, "
               "Campaign), DP-013 (Calendar Date). The stage objects are facts built from inputs with the DP-303 and "
               "DP-093 natural keys. Model gap: 04 Lead Conversion has no link to an advice engagement (spec taxonomy "
               "gap); the hand-off is matched by party and date.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-334": dict(
        style="Star",
        entities=[
            fact("Fact Recommendation Evidence", [("45", "Recommendation"), ("45", "Recommendation Rationale")],
                 ["Recommendation ID"], measures=True,
                 grain="one row = recommendation (45, RECOM-) x presented timestamp, with its evidence flags; locked "
                       "once Client Decision is not Pending",
                 note="The Reg BI file row. Carries the DP-398 review as a key (Supervisory Review Key = Supervisory "
                      "Review ID of the review of this recommendation) so the review outcome reads with the evidence "
                      "without re-scoring (CW-215). Recommendation Rationale folds onto it (one-to-one, implicit join). "
                      "PII tier: financial."),
            fact("Fact Best Interest Evidence", [("45", "Best Interest Evidence")],
                 ["Evidence Recommendation", "Best Interest Component"],
                 grain="one row = recommendation x best interest component", note="PII tier: financial."),
            fact("Fact Recommendation Alternative", [("45", "Recommendation Alternative")],
                 ["Alternative Recommendation", "Alternative Number"],
                 grain="one row = recommendation x alternative considered", note="PII tier: financial."),
            fact("Fact Plan Input Completeness", [("45", "Client Financial Plan Version"),
                                                  ("45", "Client Planning Assumptions")],
                 ["Client Financial Plan Version ID"], grain="one row = client financial plan version",
                 note="Plan Input Completeness Score. Of Client Planning Assumptions only Planning Federal Marginal Tax "
                      "Rate is read; the longevity and healthcare-cost bases (special category) are not. PII tier: "
                      "financial."),
            fact("Fact Planning Cash Flow Input", [("45", "Planning Cash Flow Input")],
                 ["Cash Flow Plan Version", "Cash Flow Item Number"],
                 grain="one row = plan version x cash flow item", note="PII tier: financial."),
            fact("Fact Planning Balance Sheet Item", [("45", "Planning Balance Sheet Item")],
                 ["Balance Sheet Plan Version", "Balance Sheet Item Number"],
                 grain="one row = plan version x balance sheet item", note="PII tier: financial."),
            fact("Fact Disclosure Delivery", [("15", "Account Disclosure Delivery")],
                 ["Disclosure Account", "Disclosure Type", "Disclosure Version", "Disclosure Delivered Date"],
                 grain="one row = account x disclosure type x version x delivered date",
                 note="Disclosure Not Delivered Before Recommendation. PII tier: none (account key only)."),
            fact("Fact Alternative Investment Subscription", [("15", "Alternative Investment Subscription")],
                 ["Subscription ID"], grain="one row = alternative investment subscription",
                 note="Unqualified Alternative Investment Subscriptions; the subscribing party is matched through the "
                      "account's owner role (spec taxonomy gap). PII tier: financial."),
            dim("Supervisory Review (DP-398)", SROUT, [("08", "Supervisory Review"), ("08", "Best Interest Review Detail")],
                note="Conformed from DP-398 Supervisory Review Outcome (keyed on Supervisory Review ID); this product's "
                     "08 inputs merge onto it. Review Outcome is carried with the evidence. PII tier: financial."),
            dim("Financial Plan", PLAN, [("45", "Client Financial Plan")]),
            dim("Investor Profile", INVPROF, [("02", "Investor Profile")]),
            dim("Investor Qualification", INVQ, [("02", "Investor Qualification")]),
            dim("Party", PARTY),
            dim("Client Account", ACCT),
            dim("Advisor", ADVISOR),
            dim("Employee", EMP),
            dim("Service Offering", OFFER),
            dim("Share Class", SHARE),
            dim("Investment Product", PROD),
            dim("Review Date", CAL),
        ],
        relationships=[
            rel("Fact Recommendation Evidence", "Supervisory Review (DP-398)", ["Supervisory Review (DP-398) Key"],
                optional=True, note="The review whose Reviewed Recommendation is this recommendation."),
            rel("Fact Recommendation Evidence", "Advisor", ["Recommending Advisor"]),
            rel("Fact Recommendation Evidence", "Party", ["Recommended Client"]),
            rel("Fact Recommendation Evidence", "Client Account", ["Recommendation Accounts"], card="M:N"),
            rel("Fact Recommendation Evidence", "Investor Profile", ["Recommendation Profile Version"]),
            rel("Fact Recommendation Evidence", "Fact Plan Input Completeness", ["Supporting Plan Version"],
                optional=True),
            rel("Fact Recommendation Evidence", "Service Offering", ["Recommended Service Offering"], optional=True),
            rel("Fact Recommendation Evidence", "Share Class", ["Recommended Share Class"], optional=True),
            rel("Fact Best Interest Evidence", "Fact Recommendation Evidence", ["Evidence Recommendation"]),
            rel("Fact Best Interest Evidence", "Fact Disclosure Delivery", ["Evidence Disclosure Delivery"],
                optional=True, note="Single reference to the delivery; the rest of its key from the recommendation."),
            rel("Fact Best Interest Evidence", "Employee", ["Evidence Attester"], optional=True),
            rel("Fact Recommendation Alternative", "Fact Recommendation Evidence", ["Alternative Recommendation"]),
            rel("Fact Plan Input Completeness", "Financial Plan", ["Versioned Plan"]),
            rel("Fact Plan Input Completeness", "Investor Profile", ["Plan Profile Version Relied On"], optional=True),
            rel("Fact Planning Cash Flow Input", "Fact Plan Input Completeness", ["Cash Flow Plan Version"]),
            rel("Fact Planning Balance Sheet Item", "Fact Plan Input Completeness", ["Balance Sheet Plan Version"]),
            rel("Financial Plan", "Party", ["Plan Subject"]),
            rel("Investor Profile", "Party", ["Profile Client"]),
            rel("Investor Qualification", "Party", ["Qualified Party"]),
            rel("Fact Disclosure Delivery", "Client Account", ["Disclosure Account"]),
            rel("Fact Alternative Investment Subscription", "Client Account", ["Subscribing Account"]),
            rel("Fact Alternative Investment Subscription", "Investment Product", ["Feeder Product"]),
            rel("Fact Alternative Investment Subscription", "Investor Qualification", ["Investor Qualification Relied On"],
                optional=True, note="Single reference; the qualification standard comes from the referenced row."),
            rel("Supervisory Review (DP-398)", "Investor Profile", ["Investor Profile Version Checked"], optional=True),
            rel("Supervisory Review (DP-398)", "Review Date", ["Review Completed Date"], optional=True),
        ],
        notes=("Evidence assembled, never re-scored (CW-215). The evidence fact carries the DP-398 review key; the "
               "review dimension is conformed from DP-398 Supervisory Review Outcome. Model gap: 45 Recommendation holds no review "
               "reference, so the evidence fact borrows Supervisory Review (DP-398) Key, resolved from 08 Supervisory "
               "Review.Reviewed Recommendation. Conformed: DP-398 (Supervisory Review Outcome), DP-303 (Financial Plan), DP-240 (Investor Profile, Investor "
               "Qualification, Party), DP-093 (Client Account), DP-009 (Advisor), DP-192 (Employee), DP-004 (Service "
               "Offering, Share Class, Investment Product), DP-013 (Calendar Date). The 45 recommendation, evidence and "
               "plan objects are facts built from inputs on the DP-303 natural keys.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-335": dict(
        style="Star",
        entities=[
            fact("Fact Rollover Evidence", [("45", "Rollover Analysis"), ("45", "PTE 2020-02 Documentation")],
                 ["Rollover Analysis ID"], measures=True,
                 grain="one row = rollover analysis (45, ROLV-) x rollover recommendation; locked at the client "
                       "decision",
                 note="PTE 2020-02 Documentation folds onto the analysis (one-to-one, implicit join). Carries the DP-398 "
                      "review as a key (Supervisory Review Key = the review whose Rollover Analysis Reviewed is this "
                      "analysis). PII tier: financial."),
            fact("Fact Rollover Option Comparison", [("45", "Rollover Option Comparison")],
                 ["Comparison Analysis", "Rollover Option"], grain="one row = rollover analysis x rollover option",
                 note="Option Fee Schedule is a 47 key (external reference). PII tier: financial."),
            fact("Fact Rollover Recommendation", [("45", "Recommendation")], ["Recommendation ID"],
                 grain="one row = rollover recommendation", note="PII tier: financial."),
            fact("Fact Best Interest Evidence", [("45", "Best Interest Evidence")],
                 ["Evidence Recommendation", "Best Interest Component"],
                 grain="one row = recommendation x best interest component", note="PII tier: financial."),
            fact("Fact Plan Distribution", [("16", "Distribution Request")], ["Distribution ID"],
                 grain="one row = 16 plan distribution request (the implementing rollover)",
                 note="Supplies the receiving firm account (45 Rollover Analysis has none). PII tier: financial."),
            fact("Fact Retail Hand-Off", [("16", "Participant Retail Hand-Off")], ["Hand-Off ID"],
                 grain="one row = participant retail hand-off", note="PII tier: identity."),
            bridge("Recommendation Implementation Link", [("45", "Recommendation Implementation Link")], None, src=RIL,
                   grain="one row = recommendation x implementing distribution",
                   note="Conformed from DP-303 because the registry key holds implementing keys not read."),
            dim("Supervisory Review (DP-398)", SROUT, [("08", "Supervisory Review"), ("08", "Best Interest Review Detail")],
                note="Conformed from DP-398 Supervisory Review Outcome (keyed on Supervisory Review ID); this product's "
                     "08 retrospective-review inputs merge onto it. PII tier: financial."),
            dim("Client Account", ACCT, [("15", "Account")]),
            dim("Participant", PART430),
            dim("Retirement Plan", RPLAN),
            dim("Party", PARTY),
            dim("Advisor", ADVISOR),
            dim("Employee", EMP),
            dim("Advice Engagement", ADENG),
            dim("Review Date", CAL),
        ],
        relationships=[
            rel("Fact Rollover Evidence", "Supervisory Review (DP-398)", ["Supervisory Review (DP-398) Key"],
                optional=True),
            rel("Fact Rollover Evidence", "Fact Rollover Recommendation", ["Rollover Recommendation"]),
            rel("Fact Rollover Evidence", "Retirement Plan", ["Source Retirement Plan"]),
            rel("Fact Rollover Evidence", "Participant", ["Source Plan Membership"], optional=True),
            rel("Fact Rollover Evidence", "Employee", ["Attesting Employee"], optional=True),
            rel("Fact Rollover Option Comparison", "Fact Rollover Evidence", ["Comparison Analysis"]),
            rel("Fact Rollover Recommendation", "Advisor", ["Recommending Advisor"]),
            rel("Fact Rollover Recommendation", "Party", ["Recommended Client"]),
            rel("Fact Rollover Recommendation", "Client Account", ["Recommendation Accounts"], card="M:N"),
            rel("Fact Best Interest Evidence", "Fact Rollover Recommendation", ["Evidence Recommendation"]),
            rel("Fact Best Interest Evidence", "Employee", ["Evidence Attester"], optional=True),
            rel("Recommendation Implementation Link", "Fact Rollover Recommendation", ["Implemented Recommendation"]),
            rel("Recommendation Implementation Link", "Fact Plan Distribution", ["Implementing Distribution"]),
            rel("Fact Plan Distribution", "Participant", ["Distribution Membership"]),
            rel("Fact Plan Distribution", "Client Account", ["Receiving Account"], optional=True),
            rel("Fact Retail Hand-Off", "Participant", ["Hand-Off Membership"]),
            rel("Fact Retail Hand-Off", "Advice Engagement", ["Referral Advice Engagement"], optional=True),
            rel("Fact Retail Hand-Off", "Advisor", ["Referred Advisor"], optional=True),
            rel("Fact Retail Hand-Off", "Fact Plan Distribution", ["Linked Distribution Request"], optional=True),
            rel("Supervisory Review (DP-398)", "Review Date", ["Review Completed Date"], optional=True),
        ],
        notes=("Evidence assembled, never re-scored (CW-215); the evidence fact carries the DP-398 review key. Model "
               "gap: 45 Rollover Analysis holds no review reference, so it borrows Supervisory Review (DP-398) Key, "
               "resolved from 08 Best Interest Review Detail.Rollover Analysis Reviewed. Conformed: DP-398 "
               "(Supervisory Review Outcome), DP-093 (Client Account), DP-430 "
               "(Participant), DP-094 (Retirement Plan), DP-240 (Party), DP-009 (Advisor), DP-192 (Employee), DP-303 "
               "(Advice Engagement, Recommendation Implementation Link), DP-013 (Calendar Date). 16 Distribution "
               "Request is published by no foundational model and is a fact here. External references: PTE 2020-02 "
               "Documentation.Documentation Delivery Record -> 13 Recipient Delivery Record (DP-382, not upstream); "
               "Rollover Option Comparison.Option Fee Schedule -> 47 Fee Schedule (DP-305, not upstream).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-337": dict(
        style="Star",
        entities=[
            fact("Fact Goal Progress", [("45", "Goal Progress Snapshot")], ["Snapshot Goal", "Snapshot As-Of Date"],
                 measures=True, grain="one row = financial goal (FGOAL-) x snapshot as-of date; month-end kept",
                 note="PII tier: financial."),
            fact("Fact Goal Projection", [("45", "Goal Projection Result")], ["Result Scenario", "Result Goal"],
                 grain="one row = planning scenario x goal", note="PII tier: financial."),
            fact("Fact Projection Year", [("45", "Projection Year Result")], ["Year Result Scenario", "Projection Year"],
                 grain="one row = planning scenario x projection year", note="PII tier: financial."),
            fact("Fact Held-Away Balance", [("45", "Aggregated Account Balance")],
                 ["Balance Aggregated Account", "Balance As-Of Date"],
                 grain="one row = aggregated account x balance date",
                 note="Outside Assets Funding Goals; never added to firm client assets. PII tier: financial."),
            fact("Fact Funding Account Assets", [("06", "Account Asset Summary")], None, src=AAS,
                 grain="one row = funding account x as-of date x holding type",
                 note="Conformed from DP-007 (Summary Holding Type is in the key). Firm Assets Funding Goals."),
            fact("Fact Funding Account Return", [("32", "Personal Rate of Return")], ["Personal Rate of Return ID"],
                 grain="one row = personal rate of return of a funding account x period x method",
                 note="Funding Account Personal Return (from DP-145). PII tier: financial."),
            bridge("Goal Funding Link", [("45", "Goal Funding Link")],
                   ["Funded Goal", "Funding Account", "Funding Aggregated Account", "Funding Effective From"],
                   grain="one row = goal x funding account or aggregated account x effective period",
                   note="Many accounts fund many goals. PII tier: financial."),
            bridge("Plan Goal Inclusion", [("45", "Plan Goal Inclusion")], ["Inclusion Plan Version", "Included Goal"],
                   grain="one row = plan version x included goal", note="PII tier: financial."),
            dim("Financial Goal", GOAL, [("45", "Financial Goal"), ("45", "Retirement Income Goal Detail"),
                                         ("45", "Education Goal Detail")],
                note="The goal detail groups fold onto the goal. PII tier: financial; identity for the education goal "
                     "(student)."),
            dim("Planning Scenario", SCEN, [("45", "Planning Scenario")]),
            dim("Financial Plan Version", PLANV, [("45", "Client Financial Plan Version")]),
            dim("Planning Assumption Set", PAS, [("45", "Planning Assumption Set")]),
            dim("Capital Market Assumption Set", CMA),
            dim("Model", MODEL, [("37", "Model Inventory Entry")], note="The projection engine."),
            dim("Advice Review", ADREV, [("45", "Advice Review")]),
            dim("Advice Engagement", ADENG),
            dim("Party", PARTY),
            dim("Client Account", ACCT),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Goal Progress", "Financial Goal", ["Snapshot Goal"]),
            rel("Fact Goal Progress", "Planning Scenario", ["Snapshot Scenario"], optional=True),
            rel("Fact Goal Progress", "As-Of Date", ["Snapshot As-Of Date"]),
            rel("Financial Goal", "Party", ["Goal Owner"]),
            rel("Financial Goal", "Party", ["Retiring Party"], optional=True),
            rel("Financial Goal", "Party", ["Student"], optional=True),
            rel("Financial Goal", "Advice Engagement", ["Goal Source Engagement"], optional=True),
            rel("Fact Goal Projection", "Planning Scenario", ["Result Scenario"]),
            rel("Fact Goal Projection", "Financial Goal", ["Result Goal"]),
            rel("Fact Projection Year", "Planning Scenario", ["Year Result Scenario"]),
            rel("Planning Scenario", "Financial Plan Version", ["Scenario Plan Version"]),
            rel("Planning Scenario", "Planning Assumption Set", ["Scenario Assumption Set"]),
            rel("Planning Scenario", "Model", ["Projection Engine"], optional=True),
            rel("Financial Plan Version", "Planning Assumption Set", ["Version Assumption Set"], optional=True),
            rel("Planning Assumption Set", "Capital Market Assumption Set", ["Capital Market Assumption Set"],
                note="Single reference; the CMA set version comes from the assumption set's effective period."),
            rel("Plan Goal Inclusion", "Financial Plan Version", ["Inclusion Plan Version"]),
            rel("Plan Goal Inclusion", "Financial Goal", ["Included Goal"]),
            rel("Goal Funding Link", "Financial Goal", ["Funded Goal"]),
            rel("Goal Funding Link", "Client Account", ["Funding Account"], optional=True),
            rel("Advice Review", "Advice Engagement", ["Reviewed Engagement"]),
            rel("Fact Held-Away Balance", "As-Of Date", ["Balance As-Of Date"]),
            rel("Fact Funding Account Assets", "Client Account", ["Summary Account"]),
            rel("Fact Funding Account Return", "Client Account", ["Personal Return Account"]),
        ],
        notes=("Conformed: DP-303 (Financial Goal, Planning Scenario, Financial Plan Version, Planning Assumption Set, "
               "Advice Review, Advice Engagement), DP-530 (Capital Market Assumption Set), DP-212 (Model), DP-240 "
               "(Party), DP-093 (Client Account), DP-007 (Account Asset Summary), DP-013 (Calendar Date). Model gap: no "
               "45 Aggregated Account object is read, so Goal Funding Link.Funding Aggregated Account and Fact Held-Away "
               "Balance.Balance Aggregated Account carry the same key without a dimension between them.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-341": dict(
        style="Star",
        entities=[
            fact("Fact Drift Assessment", [("46", "Drift Assessment")], ["Drift Assessment ID"], measures=True,
                 grain="one row = managed account x drift assessment (latest per day)",
                 note="Market Value Outside Tolerance is valued from 49 Client Holding; the 46 Account Market Value copy "
                      "is not read. PII tier: financial."),
            fact("Fact Drift Assessment Line", [("46", "Drift Assessment Line")],
                 ["Line Drift Assessment", "Line Asset Class", "Line Instrument"],
                 grain="one row = drift assessment x asset class x instrument", note="PII tier: financial."),
            fact("Fact Rebalance Event", [("46", "Account Rebalance Event")], ["Rebalance Event ID"],
                 grain="one row = account rebalance event (ARBE-)",
                 note="Decision Reviewed By is a 20 Employee key (external reference). PII tier: financial."),
            fact("Fact Trade Proposal", [("46", "Trade Proposal")], ["Trade Proposal ID"],
                 grain="one row = trade proposal (TRPR-)", note="PII tier: financial."),
            fact("Fact Proposed Lot Selection", [("46", "Proposed Client Lot Selection")],
                 ["Lot Selection Proposal", "Selected Client Tax Lot"],
                 grain="one row = trade proposal x selected client tax lot", note="PII tier: financial."),
            fact("Fact Trade Proposal Exception", [("46", "Trade Proposal Exception")],
                 ["Exception Trade Proposal", "Pre-Trade Check Type", "Exception Raised Timestamp"],
                 grain="one row = trade proposal x pre-trade check x raised timestamp", note="PII tier: financial."),
            fact("Fact Cash Instruction", [("46", "Managed Account Cash Instruction")], ["Cash Instruction ID"],
                 grain="one row = managed account cash instruction (CSHI-)", note="PII tier: financial."),
            fact("Fact Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
                 ["Client Holding ID"], grain="one row = client holding (End of Day or intraday view)",
                 note="The book of record for the assessed value (CW-007). PII tier: financial."),
            dim("Model Assignment", MASSIGN, [("46", "Model Assignment")]),
            dim("Managed Account Target", MAT, [("46", "Managed Account Target")]),
            dim("Account Target Override Line", ATOL, [("46", "Account Target Override Line")],
                note="Outrigger of the account target."),
            own("Rebalance Trigger Rule", [("46", "Rebalance Trigger Rule")],
                ["Rule Program", "Rule Model Portfolio", "Trigger Type", "Rule Effective From"],
                note="Not published by a foundational model. PII tier: none."),
            dim("Rebalance Run", RUN, [("46", "Trade Proposal Batch")]),
            dim("Program Enrollment", ENROLL, [("15", "Program Enrollment")]),
            dim("Program", OFFER),
            dim("Model Portfolio", MODELPF),
            dim("Target Allocation Set", TAS),
            dim("Instrument", INSTR),
            dim("Client Tax Lot", TAXLOT),
            dim("Client Account", ACCT),
            dim("Business Date", CAL),
        ],
        relationships=[
            rel("Fact Drift Assessment", "Client Account", ["Assessed Account"]),
            rel("Fact Drift Assessment", "Managed Account Target", ["Assessed Account Target"],
                note="Single reference; the target version is the one in force at the assessment."),
            rel("Fact Drift Assessment Line", "Fact Drift Assessment", ["Line Drift Assessment"]),
            rel("Fact Drift Assessment Line", "Instrument", ["Line Instrument"], optional=True),
            rel("Model Assignment", "Client Account", ["Assigned Account"]),
            rel("Model Assignment", "Program Enrollment", ["Assignment Program Enrollment"]),
            rel("Model Assignment", "Model Portfolio", ["Assigned Model Portfolio"]),
            rel("Program Enrollment", "Program", ["Enrolled Service Offering"]),
            rel("Managed Account Target", "Model Assignment", ["Target Model Assignment"]),
            rel("Managed Account Target", "Target Allocation Set", ["Applied Model Target Set"], optional=True),
            rel("Account Target Override Line", "Managed Account Target", ["Override Account Target"]),
            rel("Account Target Override Line", "Instrument", ["Override Instrument"], optional=True),
            rel("Rebalance Trigger Rule", "Program", ["Rule Program"]),
            rel("Rebalance Trigger Rule", "Model Portfolio", ["Rule Model Portfolio"], optional=True),
            rel("Fact Rebalance Event", "Client Account", ["Rebalanced Account"]),
            rel("Fact Rebalance Event", "Rebalance Trigger Rule", ["Triggering Rule"], optional=True,
                note="Single reference to the composite rule key."),
            rel("Fact Rebalance Event", "Fact Drift Assessment", ["Triggering Drift Assessment"], optional=True),
            rel("Fact Rebalance Event", "Managed Account Target", ["Applied Account Target"], optional=True),
            rel("Fact Rebalance Event", "Rebalance Run", ["Event Proposal Batch"], optional=True),
            rel("Rebalance Run", "Program", ["Batch Program"]),
            rel("Fact Trade Proposal", "Rebalance Run", ["Proposal Batch"]),
            rel("Fact Trade Proposal", "Client Account", ["Proposal Account"]),
            rel("Fact Trade Proposal", "Instrument", ["Proposal Instrument"]),
            rel("Fact Trade Proposal", "Fact Rebalance Event", ["Source Rebalance Event"], optional=True),
            rel("Fact Trade Proposal", "Fact Cash Instruction", ["Source Cash Instruction"], optional=True),
            rel("Fact Proposed Lot Selection", "Fact Trade Proposal", ["Lot Selection Proposal"]),
            rel("Fact Proposed Lot Selection", "Client Tax Lot", ["Selected Client Tax Lot"]),
            rel("Fact Trade Proposal Exception", "Fact Trade Proposal", ["Exception Trade Proposal"]),
            rel("Fact Cash Instruction", "Client Account", ["Instruction Account"]),
            rel("Fact Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Client Holding", "Business Date", ["Client Holding Date"]),
        ],
        notes=("Book of record: 49 Client Holding through DP-300 (CW-007); the 46 drift copies of 49 are not read. "
               "Conformed: DP-304 (Model Assignment, Managed Account Target, Account Target Override Line, Rebalance "
               "Run), DP-093 (Program Enrollment, Client Account), DP-004 (Program, Model Portfolio), DP-530 (Target "
               "Allocation Set), DP-097 (Instrument), DP-300 (Client Tax Lot), DP-013 (Calendar Date). External "
               "references: Account Rebalance Event.Decision Reviewed By and Trade Proposal Exception.Override Approver "
               "-> 20 Employee (DP-192, not upstream).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-342": dict(
        style="Star",
        entities=[
            fact("Fact Tax-Loss Harvest", [("46", "Tax-Loss Harvest Decision")], ["Harvest Decision ID"], measures=True,
                 grain="one row = tax-loss harvest decision (TLH-), matched to the 49 client lot reliefs it produced",
                 note="Realized losses are matched by lot and a 3-business-day window (no link to the closing "
                      "activity). Estimated Tax Saving is read from DP-304. PII tier: financial."),
            fact("Fact Client Lot Relief", [("49", "Client Lot Relief")], None, src=LOTREL,
                 grain="one row = relieved client tax lot x closing activity",
                 note="Conformed from DP-300 because Closing Register Transaction is in the key and not read. The "
                      "client book of record, never 18 (CW-007)."),
            fact("Fact Closing Activity", [("49", "Client Account Activity")], ["Client Account Activity ID"],
                 grain="one row = client account activity", note="PII tier: financial."),
            fact("Fact Cost Basis Adjustment", [("49", "Cost Basis Adjustment")], None, src=CBADJ,
                 grain="one row = client tax lot x adjustment sequence",
                 note="Conformed from DP-300 (Adjustment Sequence is in the key). Wash Sale Basis Adjustments."),
            fact("Fact Wash Sale Window", [("46", "Wash Sale Control Window")],
                 ["Window Household", "Window Account", "Window Security Group", "Window Start Date"],
                 grain="one row = household x account x security group x window start", note="PII tier: financial."),
            fact("Fact Account Tax Budget", [("46", "Account Tax Budget")], ["Budget Account", "Budget Tax Year"],
                 grain="one row = account x tax year",
                 note="The 46 realized-to-date copies of 49 are not read; realized gains come from the lot reliefs. "
                      "PII tier: financial."),
            fact("Fact Asset Location", [("46", "Asset Location Decision")],
                 ["Location Household", "Location Asset Class", "Location Account", "Location Effective From"],
                 grain="one row = household x asset class x account x effective period", note="PII tier: financial."),
            fact("Fact Rebalance Event", [("46", "Account Rebalance Event")], ["Rebalance Event ID"],
                 grain="one row = account rebalance event", note="Drift Reduction After Rebalance. PII tier: financial."),
            fact("Fact Model Change Implementation", [("46", "Model Change Implementation")],
                 ["Changed Model Portfolio", "From Target Set", "To Target Set"],
                 grain="one row = model portfolio x from target set x to target set",
                 note="Tax-Aware Transition Deferral %. PII tier: none."),
            fact("Fact Tax-Managed Return", [("32", "Personal Rate of Return")], ["Personal Rate of Return ID"],
                 grain="one row = personal rate of return of a tax-managed account x period x method",
                 note="Read from DP-145. PII tier: financial."),
            bridge("Substantially Identical Security Group", [("46", "Substantially Identical Security Group")],
                   ["Security Group Code", "Group Member Instrument", "Member Effective From"],
                   grain="one row = security group x member instrument x effective period",
                   note="Instruments belong to many groups over time. PII tier: none."),
            bridge("Household Managed Group", [("46", "Household Managed Group")], None, src=HMG,
                   grain="one row = household x member account x group effective period"),
            dim("Model Assignment", MASSIGN, [("46", "Model Assignment"), ("46", "Tax Management Setting")],
                note="Tax Management Setting folds onto the assignment (one-to-one, implicit join)."),
            dim("Drift Assessment", DRIFT, [("46", "Drift Assessment")]),
            dim("Client Tax Lot", TAXLOT, [("49", "Client Tax Lot")]),
            dim("Household", PARTY, note="DP-240 Party restricted to Party Type = Household."),
            dim("Client Account", ACCT),
            dim("Instrument", INSTR),
            dim("Model Portfolio", MODELPF),
            dim("Target Allocation Set", TAS),
            dim("Trade Date", CAL),
        ],
        relationships=[
            rel("Fact Tax-Loss Harvest", "Client Account", ["Harvest Account"]),
            rel("Fact Tax-Loss Harvest", "Instrument", ["Security Sold"]),
            rel("Fact Tax-Loss Harvest", "Instrument", ["Replacement Security"], optional=True),
            rel("Fact Tax-Loss Harvest", "Client Tax Lot", ["Harvest Client Tax Lots"], card="M:N",
                note="The lots harvested; their reliefs are the realized losses."),
            rel("Fact Tax-Loss Harvest", "Fact Wash Sale Window", ["Resulting Wash Sale Window"], optional=True,
                note="Single reference to the composite window key."),
            rel("Fact Client Lot Relief", "Client Tax Lot", ["Relieved Client Tax Lot"]),
            rel("Fact Client Lot Relief", "Fact Closing Activity", ["Closing Activity"]),
            rel("Fact Client Lot Relief", "Client Tax Lot", ["Wash Sale Replacement Lot"], optional=True),
            rel("Fact Closing Activity", "Client Account", ["Activity Account"]),
            rel("Fact Closing Activity", "Instrument", ["Activity Instrument"], optional=True),
            rel("Fact Closing Activity", "Trade Date", ["Trade Date"]),
            rel("Fact Cost Basis Adjustment", "Client Tax Lot", ["Adjusted Client Tax Lot"]),
            rel("Client Tax Lot", "Client Account", ["Lot Account"]),
            rel("Client Tax Lot", "Instrument", ["Lot Instrument"]),
            rel("Fact Wash Sale Window", "Household", ["Window Household"]),
            rel("Fact Wash Sale Window", "Client Account", ["Window Account"]),
            rel("Fact Wash Sale Window", "Substantially Identical Security Group", ["Window Security Group"],
                note="Single reference to the group code."),
            rel("Fact Wash Sale Window", "Fact Tax-Loss Harvest", ["Triggering Harvest Decision"], optional=True),
            rel("Fact Wash Sale Window", "Client Account", ["Controlled Accounts in Scope"], card="M:N"),
            rel("Fact Wash Sale Window", "Client Account", ["Monitored Accounts in Scope"], card="M:N"),
            rel("Substantially Identical Security Group", "Instrument", ["Group Member Instrument"]),
            rel("Fact Account Tax Budget", "Client Account", ["Budget Account"]),
            rel("Fact Asset Location", "Household", ["Location Household"]),
            rel("Fact Asset Location", "Client Account", ["Location Account"]),
            rel("Fact Rebalance Event", "Client Account", ["Rebalanced Account"]),
            rel("Fact Rebalance Event", "Drift Assessment", ["Triggering Drift Assessment"], optional=True),
            rel("Drift Assessment", "Client Account", ["Assessed Account"]),
            rel("Household Managed Group", "Household", ["Managed Group Household"]),
            rel("Household Managed Group", "Client Account", ["Group Member Account"]),
            rel("Model Assignment", "Client Account", ["Assigned Account"]),
            rel("Model Assignment", "Model Portfolio", ["Assigned Model Portfolio"]),
            rel("Fact Model Change Implementation", "Model Portfolio", ["Changed Model Portfolio"]),
            rel("Fact Model Change Implementation", "Target Allocation Set", ["From Target Set"]),
            rel("Fact Model Change Implementation", "Target Allocation Set", ["To Target Set"]),
            rel("Fact Tax-Managed Return", "Client Account", ["Personal Return Account"]),
        ],
        notes=("Book of record: Client Tax Lot, Client Lot Relief and Client Account Activity (49) through DP-300, never "
               "18 (CW-007). Conformed: DP-304 (Model Assignment, Drift Assessment, Household Managed Group), DP-300 "
               "(Client Tax Lot, Client Lot Relief, Cost Basis Adjustment), DP-240 (Household), DP-093 (Client "
               "Account), DP-097 (Instrument), DP-004 (Model Portfolio), DP-530 (Target Allocation Set), DP-013 "
               "(Calendar Date). Model gap: Tax-Loss Harvest Decision has no link to its closing activity; the decision "
               "reaches its reliefs through Harvest Client Tax Lots = Relieved Client Tax Lot within the 3-day window.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-345": dict(
        style="Star",
        entities=[
            fact("Fact Managed Account Assets", [("46", "Model Assignment")], ["Model Assignment ID", "Business Date Key"],
                 measures=True,
                 grain="one row = managed account (15) x active model assignment (46) x business date, valued from End "
                       "of Day 49 Client Holdings; published aggregate at program x model x regulatory AUM "
                       "classification x month-end, month-ends locked",
                 note="Publishes Managed Account Assets (Discretionary and Non-Discretionary): the operational source "
                      "DP-241 certifies the Firm AUM Managed Account Slice from and reconciles to Client Assets "
                      "(CW-011, CW-212). It is never added to Client Assets. A retail managed account is a 15 account "
                      "managed in 46, never an 18 portfolio. The month's version is held by this snapshot (46 has no "
                      "month-end lock). PII tier: financial."),
            fact("Fact Sleeve", [("46", "Sleeve Assignment")], None, src=SLEEVE,
                 grain="one row = model assignment x sleeve sequence x effective period",
                 note="Sub-Advised Sleeve Accounts."),
            fact("Fact Composite Membership", [("46", "Managed Account Composite Membership")],
                 ["Membership Composite", "Member Account", "Membership Start Date"],
                 grain="one row = composite x account x membership period",
                 note="Eligible Accounts Outside Composite by Composite Exclusion Reason. PII tier: financial."),
            fact("Fact Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
                 ["Client Holding ID"], grain="one row = client holding (End of Day view)",
                 note="Managed Account Market Value and Own-Fund Holdings from the client book of record (CW-007). "
                      "PII tier: financial."),
            fact("Fact Cash Balance", [("49", "Account Cash Balance")], None, src=CASHBAL,
                 grain="one row = account x currency x cash balance type x basis x business date",
                 note="Conformed from DP-300 (Cash Balance Currency is in the key). The DP-007 client cash rule."),
            fact("Fact Margin Balance", [("49", "Margin Balance Snapshot")], None, src=MARGIN,
                 grain="one row = margin balance snapshot of an account",
                 note="Conformed from DP-300 (Margin Snapshot Type and As-Of Timestamp are in the key)."),
            fact("Fact Composite Return", [("32", "Performance Return")], None, src=PERFRET,
                 grain="one row = managed account composite return x period x version",
                 note="Conformed from DP-145 (Return Version is in the key); read, not recomputed."),
            fact("Fact Benchmark Return", [("32", "Benchmark Return")], None, src=BMKRET,
                 grain="one row = benchmark x period x return type x currency x version",
                 note="Conformed from DP-145; Composite Excess Return."),
            fact("Fact Account Personal Return", [("32", "Personal Rate of Return")], ["Personal Rate of Return ID"],
                 grain="one row = member account personal return x period x method",
                 note="Composite Return Dispersion. PII tier: financial."),
            dim("Managed Account Composite", COMPOSITE, [("46", "Managed Account Composite")]),
            dim("Model Portfolio", MODELPF, [("01", "Model Portfolio")]),
            dim("Client Account", ACCT, [("15", "Account")]),
            dim("Program Enrollment", ENROLL, [("15", "Program Enrollment")]),
            dim("Program", OFFER),
            dim("Sub-Adviser Engagement", SADV),
            dim("Benchmark", BMK145),
            dim("Business Date", CAL),
        ],
        relationships=[
            rel("Fact Managed Account Assets", "Business Date", ["Business Date Key"]),
            rel("Fact Managed Account Assets", "Client Account", ["Assigned Account"]),
            rel("Fact Managed Account Assets", "Program Enrollment", ["Assignment Program Enrollment"]),
            rel("Fact Managed Account Assets", "Model Portfolio", ["Assigned Model Portfolio"]),
            rel("Fact Managed Account Assets", "Fact Managed Account Assets", ["Previous Model Assignment"],
                optional=True, note="Assets Moved by Model Change: the prior assignment of the same account."),
            rel("Program Enrollment", "Program", ["Enrolled Service Offering"]),
            rel("Fact Sleeve", "Fact Managed Account Assets", ["Sleeve Model Assignment"]),
            rel("Fact Sleeve", "Model Portfolio", ["Sleeve Model Portfolio"], optional=True),
            rel("Fact Sleeve", "Sub-Adviser Engagement", ["Sleeve Sub-Adviser Engagement"], optional=True),
            rel("Managed Account Composite", "Program", ["Composite Program"]),
            rel("Managed Account Composite", "Model Portfolio", ["Composite Model Portfolio"], optional=True),
            rel("Fact Composite Membership", "Managed Account Composite", ["Membership Composite"]),
            rel("Fact Composite Membership", "Client Account", ["Member Account"]),
            rel("Fact Composite Membership", "Fact Managed Account Assets", ["Membership Model Assignment"],
                optional=True),
            rel("Fact Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Client Holding", "Business Date", ["Client Holding Date"]),
            rel("Fact Cash Balance", "Client Account", ["Cash Balance Account"]),
            rel("Fact Margin Balance", "Client Account", ["Margin Snapshot Account"]),
            rel("Fact Composite Return", "Managed Account Composite", ["Return Managed Account Composite"]),
            rel("Fact Benchmark Return", "Benchmark", ["Return Benchmark"]),
            rel("Fact Benchmark Return", "Business Date", ["Benchmark Period End Date"]),
            rel("Fact Account Personal Return", "Client Account", ["Personal Return Account"]),
        ],
        notes=("This product's managed-account assets fact is the source DP-241 certifies from (CW-212); it owns no "
               "certified family and is never summed with Client Assets. Values come from 49 through DP-300 (CW-007); "
               "no 18 portfolio is joined. Conformed: DP-304 (Managed Account Composite, Sleeve Assignment), DP-004 "
               "(Model Portfolio, Program), DP-093 (Client Account, Program Enrollment), DP-300 (Cash Balance, Margin "
               "Balance Snapshot), DP-145 (Performance Return, Benchmark Return, Benchmark), DP-306 (Sub-Adviser "
               "Engagement), DP-013 (Calendar Date). The model assignment is the grain, so it is a fact on the DP-304 "
               "key with the business date borrowed. The household dimension of the spec is reached through DP-240 by "
               "the account (no 02 object is read here).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-346": dict(
        style="Star",
        entities=[
            fact("Fact Fee Billing Test", [("47", "Account Fee Calculation")], None, src=AFC, measures=True,
                 grain="one row = account fee calculation (fee calculation run x billed subject) with its re-performed "
                       "fee and flags; re-tested on each recalculation run",
                 note="Conformed from DP-305 because Calculated Billing Arrangement is in the key and not read. "
                      "Billed fees are operational; client fee revenue is DP-012's (CW-214)."),
            fact("Fact Fee Run Reconciliation", [("47", "Fee Calculation Run")], ["Fee Calculation Run ID"],
                 grain="one row = fee calculation run", note="Run control totals only. PII tier: none."),
            fact("Fact Billable Asset Exclusion", [("47", "Billable Asset Exclusion")],
                 ["Excluded From Calculation", "Exclusion Category", "Excluded Client Holding"],
                 grain="one row = fee calculation x exclusion category x excluded client holding",
                 note="Excluded Amount is a Derived copy; the holding is matched by Excluded Client Holding. PII tier: "
                      "financial."),
            fact("Fact Fee Calculation Exception", [("47", "Fee Calculation Exception")],
                 ["Exception Calculation", "Fee Exception Type", "Exception Raised Date"],
                 grain="one row = fee calculation x exception type x raised date",
                 note="Exception Supervisory Review is an 08 key (external reference). PII tier: financial."),
            fact("Fact Fee Adjustment", [("47", "Fee Adjustment")], ["Fee Adjustment ID"],
                 grain="one row = fee adjustment", note="Billing Error Refunds. PII tier: financial."),
            fact("Fact Billing Dispute", [("47", "Billing Dispute")], ["Billing Dispute ID"],
                 grain="one row = billing dispute",
                 note="Related Complaint is an 08 key (external reference). PII tier: financial."),
            fact("Fact Fee Debit", [("47", "Fee Debit")], ["Fee Debit ID"], grain="one row = fee debit",
                 note="Debit to Calculation Breaks. PII tier: financial."),
            fact("Fact Fee Deduction Authorization", [("47", "Fee Deduction Authorization")],
                 ["Authorized Account", "Authorizing Agreement"],
                 grain="one row = debited account x authorizing agreement, tested per quarter (custody-rule evidence)",
                 note="PII tier: financial."),
            fact("Fact Fee Disclosure Delivery", [("47", "Fee Disclosure Delivery")],
                 ["Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type", "Disclosed Fee Schedule",
                  "Fee Disclosure Delivered Date"],
                 grain="one row = recipient x account x disclosure type x schedule x delivered date",
                 note="Fee Changes Without Advance Notice. PII tier: identity."),
            fact("Fact Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
                 ["Client Holding ID"], grain="one row = client holding at the valuation as-of date",
                 note="Billable assets re-performed from the client book of record (CW-007). PII tier: financial."),
            fact("Fact Client Account Activity", [("49", "Client Account Activity")], ["Client Account Activity ID"],
                 grain="one row = client account activity (fee postings and credits)", note="PII tier: financial."),
            fact("Fact Custodian Statement", [("13", "Investor Document")], ["Investor Document ID"],
                 grain="one row = investor document (qualified custodian statements)", note="PII tier: financial."),
            fact("Fact Client Revenue", [("10", "Client Revenue Record")], ["Client Revenue Record ID"],
                 grain="one row = DP-012 client revenue record",
                 note="Billed to Client Fee Revenue Variance; read from DP-012, not recomputed. PII tier: financial."),
            fact("Fact Surprise Examination", [("38", "Custody Surprise Examination")],
                 ["Surprise Examined Adviser", "Surprise Examination Date"],
                 grain="one row = adviser entity x surprise examination date",
                 note="Form ADV-E Filing is a 38 key (external reference). PII tier: none."),
            own("Adviser Custody Profile", [("38", "Adviser Custody Profile")],
                ["Custody Adviser Entity", "Custody Profile Effective From"],
                note="Not published by a foundational model. PII tier: none."),
            dim("Fee Schedule Assignment", FSA, [("47", "Fee Schedule Assignment")]),
            dim("Fee Schedule", FSCHED, [("47", "Fee Schedule")]),
            dim("Fee Schedule Tier", FTIER, [("47", "Fee Schedule Tier")]),
            dim("Fee Rate Override", FRO, [("47", "Fee Rate Override")]),
            dim("Fee Waiver", FWAIVE, [("47", "Fee Waiver")]),
            dim("Fee Household", FHH, [("47", "Fee Household")]),
            bridge("Fee Household Membership", [("47", "Fee Household Membership")], None, src=FHHM,
                   grain="one row = fee household x member account x effective period",
                   note="Household Breakpoint Not Applied."),
            dim("Program Enrollment", ENROLL, [("15", "Program Enrollment")]),
            dim("Client Account", ACCT, [("15", "Account")]),
            dim("Account Agreement", AGMT, [("15", "Account Agreement")]),
            dim("Household", PARTY, note="DP-240 Party restricted to Party Type = Household."),
            dim("Party", PARTY),
            dim("Internal Legal Entity", ILE, note="Adviser entities and qualified custodians."),
            dim("Billing Period End", CAL),
        ],
        relationships=[
            rel("Fact Fee Billing Test", "Fact Fee Run Reconciliation", ["Calculation Run"]),
            rel("Fact Fee Billing Test", "Fee Schedule Assignment", ["Calculated Assignment"]),
            rel("Fact Fee Billing Test", "Fee Schedule", ["Schedule Version Applied"]),
            rel("Fact Fee Billing Test", "Fee Waiver", ["Waivers Applied"], card="M:N", optional=True),
            rel("Fact Fee Run Reconciliation", "Billing Period End", ["Run Billing Period End"]),
            rel("Fact Billable Asset Exclusion", "Fact Fee Billing Test", ["Excluded From Calculation"],
                note="Single reference to the composite calculation key."),
            rel("Fact Billable Asset Exclusion", "Fact Client Holding", ["Excluded Client Holding"]),
            rel("Fact Fee Calculation Exception", "Fact Fee Billing Test", ["Exception Calculation"]),
            rel("Fact Fee Adjustment", "Fact Fee Billing Test", ["Adjusted Fee Calculation"]),
            rel("Fact Fee Adjustment", "Fee Waiver", ["Applied Fee Waiver"], optional=True),
            rel("Fact Fee Adjustment", "Fact Billing Dispute", ["Related Billing Dispute"], optional=True),
            rel("Fact Fee Adjustment", "Fact Client Account Activity", ["Credit Posting"], optional=True),
            rel("Fact Billing Dispute", "Fact Fee Billing Test", ["Disputed Fee Calculation"]),
            rel("Fact Fee Debit", "Fact Fee Billing Test", ["Debited Calculation"]),
            rel("Fact Fee Debit", "Client Account", ["Debited Account"]),
            rel("Fact Fee Debit", "Fact Client Account Activity", ["Debit Posting"], optional=True),
            rel("Fact Client Account Activity", "Client Account", ["Activity Account"]),
            rel("Fact Client Account Activity", "Fact Fee Debit", ["Source Fee Debit"], optional=True),
            rel("Fee Schedule Assignment", "Program Enrollment", ["Billed Enrollment"], optional=True),
            rel("Fee Schedule Assignment", "Client Account", ["Billed Account"]),
            rel("Fee Schedule Assignment", "Fee Schedule", ["Assigned Fee Schedule"]),
            rel("Fee Schedule Assignment", "Client Account", ["Fee-Paying Account"], optional=True),
            rel("Fee Schedule Assignment", "Fee Household", ["Assigned Fee Household"], optional=True),
            rel("Fee Schedule Tier", "Fee Schedule", ["Tier Fee Schedule"]),
            rel("Fee Rate Override", "Fee Schedule Assignment", ["Overridden Assignment"]),
            rel("Fee Waiver", "Fee Schedule Assignment", ["Waived Assignment"]),
            rel("Fee Household", "Household", ["Anchor Client Household"]),
            rel("Fee Household Membership", "Fee Household", ["Membership Fee Household"]),
            rel("Fee Household Membership", "Client Account", ["Member Account"]),
            rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
            rel("Program Enrollment", "Account Agreement", ["Advisory Agreement"], optional=True),
            rel("Account Agreement", "Client Account", ["Agreement Account"]),
            rel("Fact Fee Deduction Authorization", "Client Account", ["Authorized Account"]),
            rel("Fact Fee Deduction Authorization", "Account Agreement", ["Authorizing Agreement"]),
            rel("Fact Fee Deduction Authorization", "Client Account", ["Authorized Fee-Paying Account"], optional=True),
            rel("Fact Fee Deduction Authorization", "Internal Legal Entity", ["Qualified Custodian"]),
            rel("Fact Fee Deduction Authorization", "Fact Custodian Statement", ["Last Custodian Statement"],
                optional=True),
            rel("Fact Fee Disclosure Delivery", "Party", ["Fee Disclosure Recipient"]),
            rel("Fact Fee Disclosure Delivery", "Client Account", ["Fee Disclosure Account"]),
            rel("Fact Fee Disclosure Delivery", "Fee Schedule", ["Disclosed Fee Schedule"]),
            rel("Fact Fee Disclosure Delivery", "Program Enrollment", ["Related Program Enrollment"], optional=True),
            rel("Fact Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Custodian Statement", "Client Account", ["Document Account"]),
            rel("Fact Client Revenue", "Fact Fee Billing Test", ["Source Calculation Record"], optional=True,
                note="The revenue record names its source calculation record; matched for the advisory fee stream."),
            rel("Adviser Custody Profile", "Internal Legal Entity", ["Custody Adviser Entity"]),
            rel("Fact Surprise Examination", "Internal Legal Entity", ["Surprise Examined Adviser"]),
        ],
        notes=("Re-performance of billed advisory fees against schedules, household breakpoints and the 49 billable "
               "assets, with the custody-rule evidence. Billed fees are operational; revenue is read from DP-012 "
               "(CW-214). Conformed: DP-305 (Account Fee Calculation, Fee Schedule Assignment, Fee Schedule, Fee "
               "Schedule Tier, Fee Rate Override, Fee Waiver, Fee Household, Fee Household Membership), DP-093 (Program "
               "Enrollment, Client Account, Account Agreement), DP-240 (Household, Party), DP-013 (Internal Legal "
               "Entity, Calendar Date). External references: Fee Calculation Run.Run Approved By -> 20 Employee "
               "(DP-192, not upstream); Fee Calculation Exception.Exception Supervisory Review -> 08 Supervisory Review "
               "and Billing Dispute.Related Complaint -> 08 Complaint (no upstream product); Custody Surprise "
               "Examination.Form ADV-E Filing -> 38 Firm Regulatory Filing (no upstream product).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-349": dict(
        style="Star",
        entities=[
            fact("Fact Commission Re-Performance", [("48", "Client Trade Confirmation"),
                                                    ("48", "Confirmation Remuneration Disclosure")],
                 ["Client Trade Confirmation ID"], measures=True,
                 grain="one row = client trade confirmation (CCONF-, latest version) with its re-performed charge; "
                       "daily on T+1",
                 note="Remuneration Disclosure folds onto the confirmation. PII tier: financial."),
            fact("Fact Account Service Charge", [("47", "Fee Debit")], ["Fee Debit ID"],
                 grain="one row = fee debit of Charged Fee Type = Account Service with its triggering money movement or "
                       "account transfer",
                 note="Charged Service Type with Charged Service Fee Schedule names the Account Service Fee Item. PII "
                      "tier: financial."),
            own("Commission & Transaction Charge Rate", [("47", "Commission & Transaction Charge Rate")],
                ["Charge Fee Schedule", "Instrument Charge Category", "Charge Channel"],
                note="Not published by a foundational model. Order Entry Channel maps to Charge Channel by a drafting "
                     "assumption (taxonomy gap). PII tier: none."),
            own("Account Service Fee Item", [("47", "Account Service Fee Item")],
                ["Service Fee Schedule", "Account Service Type"], note="PII tier: none."),
            own("Fee Discount Rule", [("47", "Fee Discount Rule")], ["Discounted Fee Schedule", "Discount Rule Code"],
                note="PII tier: none."),
            dim("Fee Schedule", FSCHED, [("47", "Fee Schedule")]),
            dim("Fee Schedule Assignment", FSA, [("47", "Fee Schedule Assignment")]),
            dim("Fee Waiver", FWAIVE, [("47", "Fee Waiver")]),
            dim("Client Allocation", CALLOC, [("48", "Client Allocation")],
                note="Conformed from DP-301 (Allocation Client Block Order is in the key)."),
            dim("Client Order", CORDER, [("48", "Client Order")], note="Order Entry Channel for the charge channel."),
            dim("Money Movement", MM302, [("50", "Money Movement")]),
            dim("Account Transfer", ACCTXFER, [("49", "Account Transfer")]),
            bridge("Service Tier Assignment", [("02", "Service Tier Assignment")], None, src=STA,
                   grain="one row = party x service tier x effective period", note="Tier-based waivers and discounts."),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period"),
            dim("Delivery Election", DELIV, [("13", "E-Delivery Election")],
                note="Conformed from DP-382 (Delivery Election ID is the key and not read). Paper Fees on E-Delivery "
                     "Accounts."),
            dim("Service Tier", TIER),
            dim("Party", PARTY),
            dim("Client Account", ACCT),
            dim("Instrument", INSTR),
            dim("Trade Date", CAL),
        ],
        relationships=[
            rel("Fact Commission Re-Performance", "Client Allocation", ["Confirmed Client Allocation"],
                note="Single reference to the composite allocation key."),
            rel("Fact Commission Re-Performance", "Client Account", ["Confirmation Account"]),
            rel("Fact Commission Re-Performance", "Instrument", ["Confirmed Instrument"]),
            rel("Fact Commission Re-Performance", "Fee Schedule", ["Commission Fee Schedule"], optional=True),
            rel("Fact Commission Re-Performance", "Fact Commission Re-Performance", ["Superseded Confirmation"],
                optional=True, note="Only the latest version is published."),
            rel("Fact Commission Re-Performance", "Trade Date", ["Confirmed Trade Date"]),
            rel("Client Allocation", "Client Order", ["Allocated Client Order"]),
            rel("Client Allocation", "Client Account", ["Allocated Account"]),
            rel("Client Order", "Client Account", ["Order Account"]),
            rel("Commission & Transaction Charge Rate", "Fee Schedule", ["Charge Fee Schedule"]),
            rel("Account Service Fee Item", "Fee Schedule", ["Service Fee Schedule"]),
            rel("Account Service Fee Item", "Service Tier", ["Waiver Service Tier"], optional=True),
            rel("Fee Discount Rule", "Fee Schedule", ["Discounted Fee Schedule"]),
            rel("Fee Discount Rule", "Service Tier", ["Qualifying Service Tier"], optional=True),
            rel("Fee Schedule Assignment", "Client Account", ["Billed Account"]),
            rel("Fee Schedule Assignment", "Fee Schedule", ["Assigned Fee Schedule"]),
            rel("Fee Waiver", "Fee Schedule Assignment", ["Waived Assignment"]),
            rel("Fact Account Service Charge", "Fee Schedule", ["Charged Service Fee Schedule"], optional=True),
            rel("Fact Account Service Charge", "Money Movement", ["Triggering Money Movement"], optional=True),
            rel("Fact Account Service Charge", "Account Transfer", ["Triggering Account Transfer"], optional=True),
            rel("Fact Account Service Charge", "Client Account", ["Debited Account"]),
            rel("Fact Account Service Charge", "Trade Date", ["Debit Date"]),
            rel("Money Movement", "Client Account", ["Movement Account"]),
            rel("Account Transfer", "Client Account", ["Transfer Account"]),
            rel("Service Tier Assignment", "Party", ["Tier Party"]),
            rel("Service Tier Assignment", "Service Tier", ["Assigned Service Tier"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Delivery Election", "Client Account", ["Election Account"]),
        ],
        notes=("Two fact sets: confirmations with their re-performed commission, and account service fee debits with "
               "their triggering event. Conformed: DP-305 (Fee Schedule, Fee Schedule Assignment, Fee Waiver), DP-301 "
               "(Client Allocation, Client Order), DP-302 (Money Movement), DP-300 (Account Transfer), DP-240 (Service "
               "Tier Assignment, Party), DP-093 (Account Party Role, Client Account), DP-382 (Delivery Election), "
               "DP-004 (Service Tier), DP-097 (Instrument), DP-013 (Calendar Date). The 47 rate, service item and "
               "discount objects are published by no foundational model and are dimensions here.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-350": dict(
        style="Star",
        entities=[
            fact("Fact Fee Invoice", [("47", "Fee Invoice")], ["Invoice ID"], measures=True,
                 grain="one row = fee invoice (47, BIL-) x billing period, for billing arrangements and planning-"
                       "engagement fee schedule assignments; closed periods final",
                 note="Billing currency is the arrangement's (taxonomy gap). PII tier: identity (bill-to parties of "
                      "planning engagements); mandate rows are client-confidential."),
            fact("Fact Performance Fee Calculation", [("47", "Performance Fee Calculation")],
                 ["Performance Fee Billing Arrangement", "Calculation Period End"],
                 grain="one row = billing arrangement x calculation period end",
                 note="Calculation Approved By is a 20 Employee key (external reference). PII tier: financial where the "
                      "client is an individual."),
            fact("Fact Billing Dispute", [("47", "Billing Dispute")], ["Billing Dispute ID"],
                 grain="one row = billing dispute of an invoice", note="PII tier: financial."),
            fact("Fact Fee Adjustment", [("47", "Fee Adjustment")], ["Fee Adjustment ID"],
                 grain="one row = fee adjustment of an invoice (MFN true-ups)", note="PII tier: financial."),
            fact("Fact Fee Receivable", [("19", "Receivable Item")], ["Receivable Document Number"],
                 grain="one row = 19 receivable item", note="PII tier: identity (customer party)."),
            fact("Fact Portfolio Valuation", [("18", "Portfolio Valuation Summary")], None, src=PVS,
                 grain="one row = mandate portfolio x valuation date x view",
                 note="Conformed from DP-142 (Valuation View is in the key). Institutional mandate billable assets "
                      "come from the 18 investment book; no 49 client holding is read or joined (CW-007)."),
            fact("Fact Portfolio Return", [("32", "Performance Return")], None, src=PERFRET,
                 grain="one row = portfolio return x period x version",
                 note="Conformed from DP-145 (Return Version is in the key); Performance Fee Re-Performance Variance."),
            fact("Fact Benchmark Return", [("32", "Benchmark Return")], None, src=BMKRET,
                 grain="one row = benchmark x period x return type x currency x version", note="The hurdle return."),
            dim("Billing Arrangement", BARR, [("47", "Billing Arrangement")]),
            dim("Fee Schedule", FSCHED, [("47", "Fee Schedule"), ("47", "Performance Fee Terms")],
                note="Performance Fee Terms fold onto the schedule (one-to-one, implicit join)."),
            dim("Fee Schedule Assignment", FSA, [("47", "Fee Schedule Assignment")]),
            dim("Advice Engagement", ADENG, [("45", "Advice Engagement")]),
            dim("Institutional Client", INSTCLI, [("12", "Institutional Client")]),
            dim("Investment Mandate", MANDATE, [("01", "Investment Mandate")]),
            bridge("Portfolio Implementation Link", [("18", "Portfolio Implementation Link")], None, src=PIL,
                   grain="one row = portfolio x implemented mandate x effective period",
                   note="A mandate may be implemented by more than one portfolio over time."),
            dim("Portfolio", PORT),
            dim("Investor Qualification", INVQ),
            dim("Bill-To Party", PARTY),
            dim("Benchmark", BMK145),
            dim("Billing Period End", CAL),
        ],
        relationships=[
            rel("Fact Fee Invoice", "Billing Arrangement", ["Invoice Billing Arrangement"], optional=True),
            rel("Fact Fee Invoice", "Fee Schedule Assignment", ["Invoice Fee Schedule Assignment"], optional=True),
            rel("Fact Fee Invoice", "Bill-To Party", ["Invoice Bill-To Party"]),
            rel("Fact Fee Invoice", "Billing Period End", ["Billing Period End"]),
            rel("Billing Arrangement", "Investment Mandate", ["Billed Mandate"], optional=True),
            rel("Billing Arrangement", "Bill-To Party", ["Bill-To Party"]),
            rel("Billing Arrangement", "Fee Schedule", ["Applied Fee Schedule"]),
            rel("Billing Arrangement", "Investor Qualification", ["Qualified Client Determination"], optional=True,
                note="Single reference; the qualification standard comes from the referenced row."),
            rel("Fact Performance Fee Calculation", "Billing Arrangement", ["Performance Fee Billing Arrangement"]),
            rel("Fact Performance Fee Calculation", "Benchmark", ["Hurdle Benchmark"], optional=True),
            rel("Fee Schedule Assignment", "Advice Engagement", ["Billed Advice Engagement"], optional=True),
            rel("Fee Schedule Assignment", "Fee Schedule", ["Assigned Fee Schedule"]),
            rel("Fact Billing Dispute", "Fact Fee Invoice", ["Disputed Invoice"]),
            rel("Fact Fee Adjustment", "Fact Fee Invoice", ["Adjusted Invoice"]),
            rel("Fact Fee Adjustment", "Fact Billing Dispute", ["Related Billing Dispute"], optional=True),
            rel("Fact Fee Receivable", "Bill-To Party", ["Customer Party"]),
            rel("Fact Fee Receivable", "Fact Fee Invoice", ["Source Fee Invoice"]),
            rel("Institutional Client", "Bill-To Party", ["Institutional Client Party"]),
            rel("Investment Mandate", "Institutional Client", ["Client"]),
            rel("Portfolio Implementation Link", "Portfolio", ["Implementing Portfolio"]),
            rel("Portfolio Implementation Link", "Investment Mandate", ["Implemented Mandate"]),
            rel("Fact Portfolio Valuation", "Portfolio", ["Valued Portfolio"]),
            rel("Fact Portfolio Return", "Portfolio", ["Return Portfolio"]),
            rel("Fact Benchmark Return", "Benchmark", ["Return Benchmark"]),
        ],
        notes=("Succeeds DP-067 (CW-216). Billed fees are operational; recognized revenue is DP-012's (CW-214). "
               "Institutional mandates are valued from the 18 book (DP-142) and planning engagements carry no assets; "
               "no client holding (49) is read, so no book-of-record join arises. Conformed: DP-305 (Billing "
               "Arrangement, Fee Schedule, Fee Schedule Assignment), DP-303 (Advice Engagement), DP-003 (Institutional "
               "Client), DP-140 (Investment Mandate, Portfolio Implementation Link, Portfolio), DP-142 (Portfolio "
               "Valuation Summary), DP-145 (Performance Return, Benchmark Return, Benchmark), DP-240 (Bill-To Party, "
               "Investor Qualification), DP-013 (Calendar Date). External references: Performance Fee "
               "Calculation.Calculation Approved By -> 20 Employee (DP-192, not upstream). 19 Receivable Item is "
               "published by no foundational model upstream and is a fact here.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-351": dict(
        style="Star",
        entities=[
            fact("Fact Fiduciary Review", [("51", "Fiduciary Account Review")], ["Fiduciary Review ID"], measures=True,
                 grain="one row = fiduciary account review (FIRV-; trust x review type x due date); calendar-year "
                       "snapshot locked in January",
                 note="Reviewing Committee is a 39 Corporate Governing Body key (external reference). PII tier: "
                      "financial."),
            fact("Fact Review Exception", [("51", "Fiduciary Review Exception")], ["Exception Review", "Exception Sequence"],
                 grain="one row = fiduciary review x exception sequence",
                 note="Related Conflict is a 38 key (external reference). PII tier: financial."),
            fact("Fact Trust Account Constraint", [("46", "Account Investment Constraint")], None, src=AIC,
                 grain="one row = account x source provision x constraint type x effective period",
                 note="Conformed from DP-304 (Source Client Restriction is in the key and not read). Constraint "
                      "Provisions Not Implemented."),
            dim("Trust", TRUST, [("51", "Trust")]),
            bridge("Trust Role", [("51", "Trust Role")], None, src=TROLE,
                   grain="one row = trust x role type x role holder x effective period"),
            dim("Trust Term Provision", TTP, [("51", "Trust Term Provision")],
                note="Restricted entity. Only Investment Constraint Indicator and dates are read; the special-needs "
                     "content stays in DP-307 and DP-352."),
            dim("Client Account", ACCT, [("15", "Account"), ("15", "Account Registration Detail")],
                note="Account Registration Detail folds onto the account (Governing Trust; one-to-one, implicit join)."),
            dim("Party", PARTY307),
            dim("Trust Officer", ADVISOR),
            dim("Employee", EMP),
            dim("Internal Legal Entity", ILE),
            dim("Review Due Date", CAL),
        ],
        relationships=[
            rel("Fact Fiduciary Review", "Trust", ["Review Trust"]),
            rel("Fact Fiduciary Review", "Client Account", ["Accounts Reviewed"], card="M:N"),
            rel("Fact Fiduciary Review", "Employee", ["Reviewer"], optional=True),
            rel("Fact Fiduciary Review", "Review Due Date", ["Review Due Date"]),
            rel("Fact Review Exception", "Fact Fiduciary Review", ["Exception Review"]),
            rel("Trust", "Party", ["Trust Party"]),
            rel("Trust", "Trust Officer", ["Administering Trust Officer"]),
            rel("Trust Role", "Trust", ["Role Trust"]),
            rel("Trust Role", "Party", ["Role Holder Party"], optional=True),
            rel("Trust Role", "Internal Legal Entity", ["Role Holder Entity"], optional=True),
            rel("Trust Term Provision", "Trust", ["Provision Trust"]),
            rel("Fact Trust Account Constraint", "Client Account", ["Constrained Account"]),
            rel("Fact Trust Account Constraint", "Trust Term Provision", ["Source Trust Term Provision"], optional=True,
                note="Single reference to the composite provision key."),
            rel("Client Account", "Trust", ["Governing Trust"], optional=True),
        ],
        notes=("Trust line (tailoring lever, optional TR). Conformed: DP-307 (Trust, Trust Role, Trust Term Provision, "
               "Party), DP-304 (Account Investment Constraint), DP-093 (Client Account), DP-009 (Trust Officer), DP-192 "
               "(Employee), DP-013 (Internal Legal Entity, Calendar Date). Party is conformed from DP-307 because "
               "DP-240 is not upstream. External references: Fiduciary Account Review.Reviewing Committee -> 39 "
               "Corporate Governing Body; Fiduciary Review Exception.Related Conflict -> 38 Conflict of Interest.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-352": dict(
        style="Star",
        entities=[
            fact("Fact Distribution Decision", [("51", "Trust Distribution Request"), ("51", "Distribution Decision")],
                 ["Distribution Request ID"], measures=True,
                 grain="one row = trust distribution request (TDRQ-) with its latest decision; locked when paid or "
                       "declined",
                 note="Restricted entity, the named CW-213 view of trust distribution purposes and decisions. "
                      "Distribution Decision folds onto the request. PII tier: special category (CD-344) where the "
                      "purpose is medical, disability or hardship, in the restricted view; financial in the default "
                      "view, where those requests are absent."),
            fact("Fact Distribution Payment", [("50", "Money Movement")], ["Money Movement ID"],
                 grain="one row = money movement paying a distribution request",
                 note="Approved Not Paid; matched by Source Trust Distribution Request (no paid date on the decision). "
                      "PII tier: financial."),
            bridge("Beneficial Interest", [("51", "Beneficial Interest")], None, src=BENINT,
                   grain="one row = trust x beneficiary x interest type x effective period",
                   note="Requests From Non-Beneficiaries."),
            dim("Trust Term Provision", TTP, [("51", "Trust Term Provision")],
                note="Restricted entity; Distribution Standard for the standard cited."),
            bridge("Trust Role", [("51", "Trust Role")], None, src=TROLE,
                   grain="one row = trust x role type x role holder x effective period",
                   note="Interested Trustee Decisions."),
            dim("Trust", TRUST, [("51", "Trust")]),
            dim("Party", PARTY),
            dim("Client Account", ACCT302),
            dim("Trust Officer", ADVISOR),
            dim("Employee", EMP),
            dim("Internal Legal Entity", ILE),
            dim("Request Date", CAL),
        ],
        relationships=[
            rel("Fact Distribution Decision", "Trust", ["Request Trust"]),
            rel("Fact Distribution Decision", "Party", ["Request Beneficiary"]),
            rel("Fact Distribution Decision", "Trust Term Provision", ["Provision Applied"], optional=True,
                note="Single reference to the composite provision key."),
            rel("Fact Distribution Decision", "Employee", ["Decided By"], optional=True),
            rel("Fact Distribution Decision", "Request Date", ["Request Received Date"]),
            rel("Fact Distribution Payment", "Fact Distribution Decision", ["Source Trust Distribution Request"]),
            rel("Fact Distribution Payment", "Client Account", ["Movement Account"]),
            rel("Beneficial Interest", "Trust", ["Interest Trust"]),
            rel("Beneficial Interest", "Party", ["Beneficiary Party"]),
            rel("Trust Term Provision", "Trust", ["Provision Trust"]),
            rel("Trust Role", "Trust", ["Role Trust"]),
            rel("Trust Role", "Party", ["Role Holder Party"], optional=True),
            rel("Trust Role", "Internal Legal Entity", ["Role Holder Entity"], optional=True),
            rel("Trust", "Trust Officer", ["Administering Trust Officer"]),
        ],
        notes=("Restricted product (CW-213, CD-344): the one consumer, besides DP-322, that holds special-category trust "
               "purposes; the decision fact is restricted and the tier is in its note. Conformed: DP-307 (Trust, "
               "Trust Term Provision, Trust Role, Beneficial Interest), DP-240 (Party), DP-302 (Client Account), "
               "DP-009 (Trust Officer), DP-192 (Employee), DP-013 (Internal Legal Entity, Calendar Date). External "
               "references: Trust Distribution Request.Intake Service Request -> 13 Service Request (DP-381, not "
               "upstream).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-353": dict(
        style="Star",
        entities=[
            fact("Fact Fiduciary Accounting Statement", [("51", "Fiduciary Accounting Statement")],
                 ["Statement Trust", "Accounting Period End"], measures=True,
                 grain="one row = trust x accounting period end",
                 note="The 51 Closing Market Value and Trustee Report Delivered Date copies are not read (CW-007, "
                      "CW-076). PII tier: financial."),
            fact("Fact Principal and Income Allocation", [("51", "Principal and Income Allocation")],
                 ["Allocation Trust", "Source Account Activity", "Source Money Movement", "Allocation Sequence"],
                 grain="one row = trust x source event x allocation sequence", note="PII tier: financial."),
            fact("Fact Trust Account Activity", [("49", "Client Account Activity")], ["Client Account Activity ID"],
                 grain="one row = client account activity of a trust account", note="PII tier: financial."),
            fact("Fact Trust Money Movement", [("50", "Money Movement")], ["Money Movement ID"],
                 grain="one row = money movement of a trust account", note="PII tier: financial."),
            fact("Fact Trustee Fee Debit", [("47", "Fee Debit")], ["Fee Debit ID"],
                 grain="one row = fee debit of a trust account", note="PII tier: financial."),
            fact("Fact Client Holding", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
                 ["Client Holding ID"], grain="one row = client holding of a trust account",
                 note="Statement Closing Market Value from the client book of record (CW-007). PII tier: financial."),
            fact("Fact Cash Balance", [("49", "Account Cash Balance")], None, src=CASHBAL,
                 grain="one row = account x currency x cash balance type x basis x business date",
                 note="Conformed from DP-300 (Cash Balance Currency is in the key). Principal and Income Cash Break."),
            fact("Fact Trustee Report", [("13", "Investor Document")], ["Investor Document ID"],
                 grain="one row = investor document of a trust account",
                 note="Any delivered statement for the period end counts (no trustee report type). PII tier: financial."),
            dim("Trust", TRUST, [("51", "Trust")]),
            dim("Trust Term Provision", TTP, [("51", "Trust Term Provision")],
                note="Restricted entity; Distribution Standard for mandatory-income trusts. Conformed because the key "
                     "attributes are not read."),
            dim("Client Account", ACCT, [("15", "Account"), ("15", "Account Registration Detail")],
                note="Account Registration Detail folds onto the account (Governing Trust)."),
            dim("Period End", CAL),
        ],
        relationships=[
            rel("Fact Fiduciary Accounting Statement", "Trust", ["Statement Trust"]),
            rel("Fact Fiduciary Accounting Statement", "Period End", ["Accounting Period End"]),
            rel("Fact Principal and Income Allocation", "Trust", ["Allocation Trust"]),
            rel("Fact Principal and Income Allocation", "Fact Trust Account Activity", ["Source Account Activity"],
                optional=True),
            rel("Fact Principal and Income Allocation", "Fact Trust Money Movement", ["Source Money Movement"],
                optional=True),
            rel("Trust Term Provision", "Trust", ["Provision Trust"]),
            rel("Client Account", "Trust", ["Governing Trust"]),
            rel("Fact Trust Account Activity", "Client Account", ["Activity Account"]),
            rel("Fact Trust Account Activity", "Fact Trustee Fee Debit", ["Source Fee Debit"], optional=True),
            rel("Fact Trust Money Movement", "Client Account", ["Movement Account"]),
            rel("Fact Trustee Fee Debit", "Client Account", ["Debited Account"]),
            rel("Fact Client Holding", "Client Account", ["Holding Account"]),
            rel("Fact Cash Balance", "Client Account", ["Cash Balance Account"]),
            rel("Fact Trustee Report", "Client Account", ["Document Account"]),
        ],
        notes=("Book of record: Client Holding, Client Account Activity and Account Cash Balance (49) through DP-300 "
               "(CW-007). Trust accounts reach their trust through Account Registration Detail.Governing Trust. "
               "Conformed: DP-307 (Trust, Trust Term Provision), DP-093 (Client Account), DP-300 (Cash Balance), DP-013 "
               "(Calendar Date). The 49, 50, 47 and 13 objects are facts built from inputs on the DP-300, DP-302, "
               "DP-305 and DP-382 natural keys.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-354": dict(
        style="Star",
        entities=[
            fact("Fact Estate Case", [("51", "Estate Settlement Case")], ["Estate Settlement Case ID", "As-Of Date Key"],
                 measures=True, grain="one row = estate settlement case (ESTATE-) x as-of date (daily)",
                 note="Age is measured from the death notification (no case opened date). PII tier: identity "
                      "(decedent, heirs and representative) and financial."),
            fact("Fact Estate Task", [("51", "Estate Settlement Task")], ["Task Case", "Estate Milestone", "Task Sequence"],
                 grain="one row = estate case x milestone x task sequence", note="PII tier: identity."),
            fact("Fact Estate Service Request", [("13", "Service Request"), ("13", "Transfer of Ownership & Estate")],
                 ["Service Request ID"], grain="one row = service request related to the estate",
                 note="Transfer of Ownership & Estate folds onto the request. The Incapacity / Guardianship value of "
                      "Ownership Transfer Reason (special category) is excluded at read. PII tier: identity."),
            fact("Fact Estate Payment", [("50", "Money Movement")], ["Money Movement ID"],
                 grain="one row = money movement from a decedent account", note="Beneficiary Distributions Paid. PII "
                                                                               "tier: financial."),
            fact("Fact Decedent Account Value", [("06", "Account Asset Summary")], None, src=AAS,
                 grain="one row = decedent account x as-of date x holding type",
                 note="Conformed from DP-007 (Summary Holding Type is in the key). Decedent Account Value."),
            dim("Death Notification", DEATH, [("02", "Death Notification")]),
            dim("Authority Grant", AUTH, [("02", "Authority Grant")]),
            dim("Client Account", ACCT, [("15", "Account")]),
            bridge("Account Party Role", [("15", "Account Party Role")], None, src=APR,
                   grain="one row = account x party x role type x effective period",
                   note="The decedent's accounts."),
            dim("Account Restriction", AREST, [("15", "Account Restriction")]),
            dim("Beneficiary Designation", BENE, [("15", "Beneficiary Designation")]),
            dim("Party", PARTY),
            dim("Trust", TRUST),
            dim("Internal Legal Entity", ILE),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Estate Case", "As-Of Date", ["As-Of Date Key"]),
            rel("Fact Estate Case", "Party", ["Decedent"]),
            rel("Fact Estate Case", "Death Notification", ["Case Death Notification"]),
            rel("Fact Estate Case", "Internal Legal Entity", ["Fiduciary Entity"], optional=True),
            rel("Fact Estate Case", "Party", ["Personal Representative"], optional=True),
            rel("Fact Estate Case", "Authority Grant", ["Representative Authority Grant"], optional=True),
            rel("Fact Estate Case", "Trust", ["Testamentary Trust"], optional=True),
            rel("Fact Estate Task", "Fact Estate Case", ["Task Case"]),
            rel("Death Notification", "Party", ["Deceased Party"]),
            rel("Fact Estate Service Request", "Client Account", ["Account"]),
            rel("Fact Estate Service Request", "Death Notification", ["Related Death Notification"], optional=True),
            rel("Fact Estate Service Request", "Beneficiary Designation", ["Claimed Beneficiary Designation"],
                optional=True),
            rel("Fact Estate Service Request", "Fact Estate Case", ["Estate Settlement Case"], optional=True),
            rel("Fact Estate Service Request", "Account Restriction", ["Deceased-Account Restriction"], optional=True),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Party", ["Role Party"]),
            rel("Account Restriction", "Client Account", ["Restricted Account"]),
            rel("Beneficiary Designation", "Client Account", ["Designated Account"]),
            rel("Beneficiary Designation", "Party", ["Beneficiary"]),
            rel("Fact Estate Payment", "Client Account", ["Movement Account"]),
            rel("Fact Estate Payment", "Death Notification", ["Source Death Notification"], optional=True),
            rel("Fact Decedent Account Value", "Client Account", ["Summary Account"]),
            rel("Fact Decedent Account Value", "As-Of Date", ["Summary As-Of Date"]),
        ],
        notes=("Conformed: DP-240 (Death Notification, Authority Grant, Party), DP-093 (Client Account, Account Party "
               "Role, Account Restriction, Beneficiary Designation), DP-307 (Trust), DP-007 (Account Asset Summary), "
               "DP-013 (Internal Legal Entity, Calendar Date). The 13 service request and 50 money movement are facts "
               "built from inputs on the DP-381 and DP-302 keys. Account restrictions are death restrictions; Rule "
               "2165 rows are DP-322's and excluded at read. The estate case fact borrows the As-Of Date key for the "
               "daily snapshot.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-355": dict(
        style="Star",
        entities=[
            fact("Fact Fiduciary Tax Return", [("51", "Fiduciary Tax Return")], ["Fiduciary Tax Return ID"],
                 measures=True,
                 grain="one row = fiduciary tax return (TXRT-; trust or estate x tax year end x return)",
                 note="Restricted - Personal Data (DQ5). PII tier: financial (tax data of beneficiaries)."),
            fact("Fact K-1 Allocation", [("51", "Beneficiary Tax Allocation")], ["Allocation Return", "K-1 Beneficiary"],
                 grain="one row = fiduciary tax return x K-1 beneficiary",
                 note="Restricted - Personal Data (DQ5). PII tier: financial (a beneficiary's tax data)."),
            fact("Fact Income Allocation", [("51", "Principal and Income Allocation")], None, src=PIA,
                 grain="one row = trust x source event x allocation sequence",
                 note="Conformed from DP-307 (the source event keys are not read). K-1 Allocation to Distribution "
                      "Variance."),
            fact("Fact K-1 Delivery", [("13", "Investor Document")], ["Investor Document ID"],
                 grain="one row = investor document delivered to a K-1 recipient",
                 note="No K-1 document type: delivery is matched by recipient and period end. PII tier: financial."),
            dim("Trust", TRUST, [("51", "Trust")]),
            dim("Estate Settlement Case", ESTATE, [("51", "Estate Settlement Case")]),
            bridge("Beneficial Interest", [("51", "Beneficial Interest")], None, src=BENINT,
                   grain="one row = trust x beneficiary x interest type x effective period",
                   note="K-1 Recipients Without Interest."),
            dim("Party", PARTY),
            dim("Tax Year End", CAL),
        ],
        relationships=[
            rel("Fact Fiduciary Tax Return", "Trust", ["Return Trust"], optional=True),
            rel("Fact Fiduciary Tax Return", "Estate Settlement Case", ["Return Estate Case"], optional=True),
            rel("Fact Fiduciary Tax Return", "Party", ["Filing Entity Party"]),
            rel("Fact Fiduciary Tax Return", "Tax Year End", ["Tax Year End Date"]),
            rel("Fact K-1 Allocation", "Fact Fiduciary Tax Return", ["Allocation Return"]),
            rel("Fact K-1 Allocation", "Party", ["K-1 Beneficiary"]),
            rel("Fact Income Allocation", "Trust", ["Allocation Trust"]),
            rel("Beneficial Interest", "Trust", ["Interest Trust"]),
            rel("Beneficial Interest", "Party", ["Beneficiary Party"]),
            rel("Fact K-1 Delivery", "Party", ["Document Recipient"]),
            rel("Fact K-1 Delivery", "Tax Year End", ["Period End Date"]),
        ],
        notes=("Restricted product: beneficiary tax data, Restricted - Personal Data (DQ5); the return and K-1 facts "
               "carry the tier in their notes. Conformed: DP-307 (Trust, Estate Settlement Case, Beneficial Interest, "
               "Principal and Income Allocation), DP-240 (Party), DP-013 (Calendar Date). The 13 investor document is a "
               "fact built from its input on the DP-382 key.")),
}
