"""Logical data models, wealth-manager WP2 consumer wave, group B2 (CLA-B): Star models for the new consumer products of
specs_w1c_cla_b.py (offering, conduct and engagement; Data Domains 01, 36, 03, 04, 13, 08): DP-383, DP-384, DP-385,
DP-387, DP-390, DP-391, DP-392, DP-393, DP-394, DP-398, DP-399, DP-400, DP-402, DP-403, DP-404, DP-405, DP-408, DP-409,
DP-410, DP-412, DP-414 and DP-418. The re-scoped DP-036, DP-038, DP-039, DP-069, DP-078, DP-079, DP-085 and DP-109 keep
their models in their old modules. See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here (Household,
  Client, Client Account, Advisor, Offering, Program, Principal, Employee, Calendar Date). Household is a DP-240 Party
  (Party Type Household); the account-to-household path is Client Account -> Account Party Role -> Client -> Household
  Membership -> Household, both links being effective-dated bridges, never a column on the account.
- Facts, bridges and child entities are built from the product's own inputs with the registry's natural keys, so they
  join to the foundational entities of the same key without pulling columns this product must not publish.
- Date roles are conformed from DP-013 Calendar Date; a date attribute on a fact is the foreign key (a timestamp joins on
  its day).
- Where no input attribute carries a link, the child borrows "<Parent> Key" and the entity note records a "Model gap".
- References whose target product is not upstream (or is a sibling consumer product still being modeled) are carried
  as keys on the fact and named in the notes; they are not drawn as entities.
- Certified numbers (DP-008 Client Assets, Net New Assets, Advised Assets, Households; DP-012 fee revenue; DP-145
  Personal Return Value) are read as published measure values and never recomputed (CW-011, CW-226). Client Holding
  (49, DP-300) and the share register (29, DP-580) are always separate facts, never joined as one, and 06 positions are
  not read (CW-007).
- Each entity carrying personal data names its PII tier in its note; special-category facts (CD-344) appear only in
  DP-403's restricted view or as DP-322 counts.
"""


def dim(name, src, objects=(), note="", role="Dimension", grain=None, pk=None):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note)
    if grain:
        d["grain"] = grain
    if pk:
        d["pk"] = list(pk)
    return d


def ent(name, role, objects, pk, grain="", note="", measures=False):
    d = dict(name=name, role=role, objects=list(objects), pk=list(pk), note=note, measures=measures)
    if grain:
        d["grain"] = grain
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


CAL = ("DP-013", "Calendar Date")
OFFICE = ("DP-013", "Office Location")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
STRAT = ("DP-004", "Investment Strategy")
MODEL_PF = ("DP-004", "Model Portfolio")
OFFER = ("DP-004", "Service Offering")
TIER = ("DP-004", "Service Tier")
UNIVERSE = ("DP-004", "Tradable Universe Policy Rule")
FEATURE = ("DP-004", "Platform Feature")
EMP9 = ("DP-009", "Employee")            # 20 Employee + 03 Advisor: the Advisor dimension
EMP = ("DP-192", "Employee")
TEAM = ("DP-009", "Coverage Team")
PARTY = ("DP-240", "Party")
HHM = ("DP-240", "Household Membership")
ACCT = ("DP-093", "Account")
ENROLL = ("DP-093", "Program Enrollment")
MV = ("DP-008", "Measure Value")
SNAP = ("DP-008", "Snapshot")
MDEF = ("DP-008", "Measure Definition")
REC = ("DP-303", "Recommendation")
CMP = ("DP-011", "Campaign")
VISITOR = ("DP-011", "Web Visitor")

_MVOBJ = [("06", "Measure Value"), ("06", "Client Asset Measures")]
_MVPK = ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Data Basis", "Snapshot"]


def certified(name="Certified Client Assets", extra_note=""):
    return ent(name, "Fact", _MVOBJ, _MVPK,
               grain="one row = DP-008 measure value (measure x period end x dimension type x dimension key x data basis x snapshot)",
               note="Certified numbers read as DP-008 publishes them (CW-011, CW-226); never recomputed or added to Firm AUM. "
                    + extra_note)


def certified_rels(name="Certified Client Assets", slice_parent=None, slice_note=""):
    r = [rel(name, "Snapshot", ["Snapshot"]), rel(name, "Measure Definition", ["Measure"]),
         rel(name, "Calendar Date", ["Period End Date"])]
    if slice_parent:
        r.append(rel(name, slice_parent, ["Dimension Key"], optional=True, note=slice_note))
    return r


MODELS = {}

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-383"] = dict(
    style="Star",
    entities=[
        ent("Platform Availability", "Fact", [("01", "Platform Product Availability")], ["Platform Availability ID"],
            measures=True,
            grain="one row = platform availability version (own share class or third-party instrument x availability effective date); SCD type 2",
            note="Built from the input with DP-004's natural key rather than conformed: this product joins availability to the "
                 "due diligence lifecycle and reports gaps, it never re-decides eligibility. Exactly one of Available Share Class "
                 "and Available Third-Party Instrument is set, so both links are optional."),
        ent("Due Diligence Criterion Result", "Fact", [("52", "Product Due Diligence Criterion Result")],
            ["Criterion Product Review", "Product Due Diligence Criterion"],
            grain="one row = product due diligence x criterion",
            note="Companion fact for Failed Criteria on Available Products; no foundational model publishes criterion results."),
        ent("Platform Feature Version", "Fact", [("01", "Platform Feature")], ["Platform Feature Type", "Feature Effective From"],
            grain="one row = platform feature type x feature effective date",
            note="Companion fact; keeps DP-004 Platform Feature's key. Eligible Offerings is multi-valued, so the offering link is M:N."),
        ent("Product Document Version", "Fact", [("01", "Product Document")],
            ["Document Type", "Document Language", "Document Version Date"],
            grain="one row = product document version (document type x language x version date) for a document subject",
            note="Model gap: the registry key also carries Document Jurisdiction, which is not a product input (US-only firm, one "
                 "jurisdiction). Taxonomy gap: no attribute names the product documented, so the version joins the star only "
                 "through its version date."),
        ent("Investment Commentary", "Fact", [("01", "Investment Commentary"), ("01", "Commentary Approval")], ["Commentary ID"],
            grain="one row = investment commentary with its approval state",
            note="Commentary Approval folds into the commentary (one approval state per commentary). Author and sign-off names "
                 "are not read, so the entity carries no personal data."),
        dim("Tradable Universe Policy Rule", UNIVERSE, [("01", "Tradable Universe Policy Rule")],
            note="Conformed from DP-004; SCD type 2 on rule status and effective dates."),
        dim("Product Due Diligence", ("DP-306", "Product Due Diligence"), [("52", "Product Due Diligence")],
            note="Conformed from DP-306, which publishes the 52 approved, watch and restricted outcome (CW-120)."),
        dim("Share Class", SHARE, note="Own share classes on the shelf (DP-004)."),
        dim("Third-Party Instrument", ("DP-097", "Instrument"), note="Third-party instruments on the shelf (DP-097)."),
        dim("Offering", OFFER, note="Offerings a platform feature is eligible for (DP-004)."),
        dim("Investment Product", PROD, note="Subject of a commentary."),
        dim("Investment Strategy", STRAT, note="Strategy a commentary covers."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Platform Availability", "Share Class", ["Available Share Class"], optional=True),
        rel("Platform Availability", "Third-Party Instrument", ["Available Third-Party Instrument"], optional=True),
        rel("Platform Availability", "Product Due Diligence", ["Due Diligence Approval"], optional=True,
            note="Empty on own products and on third-party products offered without an approval (the gap measured)."),
        rel("Platform Availability", "Calendar Date", ["Availability Effective From"]),
        rel("Product Due Diligence", "Third-Party Instrument", ["Reviewed Instrument"]),
        rel("Due Diligence Criterion Result", "Product Due Diligence", ["Criterion Product Review"]),
        rel("Platform Feature Version", "Tradable Universe Policy Rule", ["Feature Governing Policy Rule"], optional=True),
        rel("Platform Feature Version", "Offering", ["Eligible Offerings"], card="M:N"),
        rel("Platform Feature Version", "Calendar Date", ["Feature Effective From"]),
        rel("Product Document Version", "Calendar Date", ["Document Version Date"]),
        rel("Investment Commentary", "Investment Product", ["Subject Product / Mandate"], optional=True),
        rel("Investment Commentary", "Investment Strategy", ["Subject Strategy"], optional=True),
        rel("Investment Commentary", "Calendar Date", ["Commentary Period End Date"]),
    ],
    notes=("The shelf star: availability is the fact and due diligence the governing dimension, so a product offered without a "
           "current approval shows as an availability row with no or a lapsed approval. Taxonomy gap: availability carries no "
           "reference to the universe rule that admits it, so rules reach the star only through platform features. No personal "
           "data."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-384"] = dict(
    style="Star",
    entities=[
        ent("Product Change Initiative", "Fact", [("36", "Product Change Initiative")], ["Product Change Initiative ID"],
            measures=True,
            grain="one row = product change initiative version (LCHG-); SCD type 2 on status and planned dates",
            note="PII tier: identity (Change Sponsor employee key only). Originating Proposal (36 Product Proposal) and Launch "
                 "Project Code are carried as keys: no upstream product publishes proposals or 41 projects."),
        ent("Service Offering Specification", "Fact", [("36", "Service Offering Specification")],
            ["Offering Specification Change Initiative", "Offering Specification Sequence"],
            grain="one row = change initiative x offering specification sequence",
            note="Proposed values stay 36 until the effective date, then DP-004 masters them (CD-236). Proposed Offering Fee "
                 "Schedule (47) is carried as a key: DP-305 is not upstream."),
        ent("Platform Feature Specification", "Fact", [("36", "Platform Feature Specification")],
            ["Feature Specification Change Initiative", "Specified Feature Type"],
            grain="one row = change initiative x specified platform feature type"),
        ent("Changed Product Scope", "Bridge", [("36", "Changed Product Scope")],
            ["Scope Change Initiative", "Scope Product", "Scope Share Class", "Scope Model Portfolio", "Scope Service Offering",
             "Scope Service Tier", "Change Scope Role"],
            grain="one row = change initiative x scoped product, share class, model portfolio, offering or service tier x scope role",
            note="Many-to-many between initiatives and the catalog items they change; Mapped Successor Share Class gives the "
                 "share class mapping check."),
        ent("Change Impact Assessment", "Fact", [("36", "Change Impact Assessment")], ["Impact Change Initiative", "Impact Area"],
            grain="one row = change initiative x impact area",
            note="Affected Shareholder Accounts Count and Estimated Impact Cost are 36 planning estimates, not certified numbers."),
        ent("Change Regulatory Requirement", "Fact", [("36", "Change Regulatory Requirement")],
            ["Requirement Change Initiative", "Regulatory Requirement Type", "Requirement Product"],
            grain="one row = change initiative x regulatory requirement type x product",
            note="Model gap: the registry key also carries Requirement Country, which is not a product input (US only). "
                 "Satisfying Firm Filing (38) and Satisfying Shareholder Communication (13) are carried as keys: neither DP-382 "
                 "nor a 38 filings product is upstream."),
        dim("Offering", OFFER, [("01", "Service Offering")], note="Conformed from DP-004; the catalog check for launched offerings."),
        dim("Platform Feature", FEATURE, note="Feature created by a specification (DP-004)."),
        dim("Tradable Universe Policy Rule", UNIVERSE),
        dim("Investment Product", PROD),
        dim("Share Class", SHARE),
        dim("Model Portfolio", MODEL_PF),
        dim("Service Tier", TIER),
        dim("Change Sponsor", EMP, note="Conformed from DP-192. PII tier: identity."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Product Change Initiative", "Change Sponsor", ["Change Sponsor"]),
        rel("Product Change Initiative", "Calendar Date", ["Planned Effective Date"]),
        rel("Service Offering Specification", "Product Change Initiative", ["Offering Specification Change Initiative"]),
        rel("Service Offering Specification", "Offering", ["Created Service Offering"], optional=True),
        rel("Platform Feature Specification", "Product Change Initiative", ["Feature Specification Change Initiative"]),
        rel("Platform Feature Specification", "Tradable Universe Policy Rule", ["Governing Policy Rule"], optional=True),
        rel("Platform Feature Specification", "Platform Feature", ["Created Platform Feature"], optional=True),
        rel("Platform Feature Specification", "Offering", ["Eligible Offerings"], card="M:N"),
        rel("Changed Product Scope", "Product Change Initiative", ["Scope Change Initiative"]),
        rel("Changed Product Scope", "Investment Product", ["Scope Product"], optional=True),
        rel("Changed Product Scope", "Share Class", ["Scope Share Class"], optional=True),
        rel("Changed Product Scope", "Share Class", ["Mapped Successor Share Class"], optional=True,
            note="Second role of Share Class: the successor of a merged or closed class."),
        rel("Changed Product Scope", "Offering", ["Scope Service Offering"], optional=True),
        rel("Changed Product Scope", "Service Tier", ["Scope Service Tier"], optional=True),
        rel("Changed Product Scope", "Model Portfolio", ["Scope Model Portfolio"], optional=True),
        rel("Change Impact Assessment", "Product Change Initiative", ["Impact Change Initiative"]),
        rel("Change Regulatory Requirement", "Product Change Initiative", ["Requirement Change Initiative"]),
        rel("Change Regulatory Requirement", "Investment Product", ["Requirement Product"], optional=True),
        rel("Change Regulatory Requirement", "Calendar Date", ["Requirement Due Date"]),
    ],
    notes=("The advice and platform side of the change calendar; the fund side stays DP-106, which reads this product. The "
           "initiative is the fact and its specifications, impacts and requirements are companion facts at their own grain so "
           "a requirement can be overdue without the initiative changing status."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-385"] = dict(
    style="Star",
    entities=[
        ent("Program Review Criterion", "Fact", [("36", "Product Review Criterion Result")],
            ["Criterion Review", "Product Review Criterion"], measures=True,
            grain="one row = advice program review x product review criterion; immutable per review version",
            note="Model gap: the registry key also carries Criterion Share Class, which is not a product input (program "
                 "reviews are not per share class). Evidence Metric Definition (21) is carried as a key: DP-101 is not upstream."),
        ent("Program Review", "Dimension", [("36", "Product Review")], ["Product Review ID"],
            note="Built from the input: no foundational model publishes 36 reviews (DP-109 is the review register and reads "
                 "this product, so it is not upstream)."),
        ent("Review Action", "Fact", [("36", "Review Action")], ["Action Review", "Review Action Sequence"],
            grain="one row = program review x action sequence",
            note="Resulting Change Initiative is carried as a DP-384 key (sibling consumer, not upstream)."),
        ent("Program Enrollment Evidence", "Fact", [("15", "Program Enrollment")], ["Program Enrollment ID"],
            grain="one row = program enrollment (account x offering x effective period)",
            note="Enrolled Accounts and Program Termination Rate %; keeps DP-093's key. PII tier: financial (account keys; "
                 "restricted drill, published at program and cohort grain)."),
        ent("Drift Assessment", "Fact", [("46", "Drift Assessment")], ["Drift Assessment ID"],
            grain="one row = drift assessment of an account",
            note="DP-304's assessment read as published; drift is never re-assessed here. PII tier: financial."),
        ent("Personal Return", "Fact", [("32", "Personal Rate of Return")], ["Personal Rate of Return ID"],
            grain="one row = personal rate of return (account or group x period x method x fee basis)",
            note="Personal Return Value is DP-145's certified number, read and medianed by program, never recomputed. PII tier: "
                 "financial."),
        certified(extra_note="Advised Assets at the advice channel; DP-008 publishes no offering slice (taxonomy gap)."),
        ent("Offering NNA Attribution", "Fact", [("06", "Attribution Record"), ("06", "Market & Client Dimensions")],
            ["Attribution Record ID"],
            grain="one row = DP-008 attribution record carrying the service offering",
            note="The offering slice of Net New Assets, read through DP-491's operational decomposition of DP-008 (DP-491 is a "
                 "sibling consumer product, so its keys are carried here on the DP-008 attribution record rather than conformed). "
                 "Market & Client Dimensions folds into its Attribution Record parent."),
        ent("Program Fee Revenue", "Fact", [("10", "Client Revenue Record")], ["Client Revenue Record ID"],
            grain="one row = client revenue record (offering x revenue period x stream)",
            note="DP-012 client fee revenue read at program grain (certified, not recomputed)."),
        ent("Program Complaint", "Fact", [("08", "Complaint")], ["Complaint ID"],
            grain="one row = complaint on an enrolled account",
            note="Counted as DP-414 counts them (same key); only the account link is read. PII tier: identity."),
        dim("Program", ("DP-304", "Program"), note="The advice program is a DP-304 Program (01 Service Offering)."),
        dim("Model Portfolio", MODEL_PF),
        dim("Investment Product", PROD),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: financial."),
        dim("Performance Return", ("DP-145", "Performance Return"), note="Return evidence cited by a criterion."),
        dim("Snapshot", SNAP, [("06", "Snapshot")]),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Program Review Criterion", "Program Review", ["Criterion Review"]),
        rel("Program Review Criterion", "Performance Return", ["Performance Evidence Return"], optional=True),
        rel("Program Review Criterion", "Certified Client Assets", ["Flow Evidence Measure Value"], optional=True),
        rel("Program Review", "Program", ["Review Service Offering"], optional=True),
        rel("Program Review", "Model Portfolio", ["Review Model Portfolio"], optional=True),
        rel("Program Review", "Investment Product", ["Review Product"], optional=True),
        rel("Program Review", "Calendar Date", ["Review Period End"]),
        rel("Review Action", "Program Review", ["Action Review"]),
        rel("Program Enrollment Evidence", "Client Account", ["Enrolled Account"]),
        rel("Program Enrollment Evidence", "Program", ["Enrolled Service Offering"]),
        rel("Drift Assessment", "Client Account", ["Assessed Account"]),
        rel("Personal Return", "Client Account", ["Personal Return Account"]),
        rel("Offering NNA Attribution", "Program", ["Service Offering"]),
        rel("Program Fee Revenue", "Program", ["Revenue Service Offering"]),
        rel("Program Complaint", "Client Account", ["Account"]),
    ] + certified_rels(),
    notes=("Program evidence is joined to each review through the program and the account's enrollment; certified values "
           "(DP-008, DP-012, DP-145) are read at program grain and never summed with each other. Published at program and cohort "
           "grain with a minimum cell of 10; account keys stay in the restricted drill."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-387"] = dict(
    style="Star",
    entities=[
        ent("Advisor Capacity", "Fact", [("03", "Advisor Capacity Snapshot")],
            ["Capacity Subject Advisor", "Capacity Subject Team", "Capacity As-Of Date"], measures=True,
            grain="one row = advisor or coverage team x capacity as-of date (monthly snapshot)",
            note="PII tier: identity (advisor key). Book Client Assets is the 03 operational copy and is never published as a "
                 "value; book assets come from DP-008. Model gap: no input links an advisor or team to its Coverage Model, so "
                 "the model capacity is borrowed as Coverage Model Key, matched through Delivery Mode and Advice Channels Offered."),
        ent("Book Coverage Assignment", "Bridge", [("03", "Party Coverage Assignment")], ["Coverage Assignment ID"],
            grain="one row = coverage assignment of a household to an advisor or team for an effective period",
            note="Many-to-many and effective dated: a household can have a primary and secondary advisor, and a pooled team. "
                 "Keeps DP-009's key. PII tier: identity."),
        ent("Household Reassignment", "Fact", [("03", "Coverage Reassignment"), ("03", "Coverage Reassignment Item")],
            ["Reassignment ID", "Reassigned Household"],
            grain="one row = household reassigned in a coverage reassignment",
            note="The reassignment and its items are one fact at item grain because every measure (households reassigned in, "
                 "notice timeliness) counts items. PII tier: identity."),
        ent("Advisor Credential", "Fact", [("03", "Advisor Credential")], ["Credential Holder", "Credential Type"],
            grain="one row = advisor x credential type (current credential)",
            note="Model gap: the registry key also carries Credential Earned Date, which is not a product input; the current "
                 "credential per type is kept. PII tier: identity."),
        ent("Advice Review", "Fact", [("45", "Advice Review")], ["Advice Review ID"],
            grain="one row = scheduled or held advice review",
            note="Keeps DP-303's key; linked to the advisor who conducted it (no household reference is read)."),
        ent("Household Service Request", "Fact", [("13", "Service Request")], ["Service Request ID"],
            grain="one row = service request on a client account",
            note="DP-381's request, counted per household through the account bridge. PII tier: identity."),
        certified(extra_note="Ending Client Assets, Net New Assets and Advised Assets by advisor of record (Dimension Type Advisor)."),
        dim("Advisor", EMP9, [("03", "Advisor")], note="Conformed from DP-009 (20 Employee with 03 Advisor). PII tier: identity."),
        dim("Coverage Team", TEAM),
        dim("Coverage Model", ("DP-009", "Coverage Model"), [("03", "Coverage Model")]),
        dim("Household", PARTY, note="DP-240 Party of Party Type Household. PII tier: identity. Protected households are counted "
                                     "only as the DP-322 flag on this key (CD-344, CW-225)."),
        dim("Client", PARTY, note="DP-240 Party: the household member and account party. PII tier: identity."),
        dim("Household Membership", HHM, [("02", "Household Membership")], role="Bridge",
            grain="one row = household x member x membership effective period"),
        dim("Account Party Role", ("DP-008", "Account Party Role"), [("15", "Account Party Role")], role="Bridge",
            grain="one row = account x party x role type x effective period",
            note="Conformed from DP-008, the link DP-008 uses to put accounts in households for the certified values."),
        dim("Client Account", ("DP-381", "Client Account"), note="Conformed from DP-381 (DP-093 is not upstream). PII tier: financial."),
        dim("Service Tier Assignment", ("DP-240", "Service Tier Assignment"), [("02", "Service Tier Assignment")], role="Bridge",
            grain="one row = household x service tier x tier effective period"),
        dim("Service Tier", TIER),
        dim("Snapshot", SNAP, [("06", "Snapshot")]),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Advisor Capacity", "Advisor", ["Capacity Subject Advisor"], optional=True),
        rel("Advisor Capacity", "Coverage Team", ["Capacity Subject Team"], optional=True,
            note="Pooled digital-advice books are measured at the team."),
        rel("Advisor Capacity", "Coverage Model", ["Coverage Model Key"], optional=True, note="Model gap (see entity)."),
        rel("Advisor Capacity", "Calendar Date", ["Capacity As-Of Date"]),
        rel("Book Coverage Assignment", "Household", ["Covered Party"]),
        rel("Book Coverage Assignment", "Advisor", ["Covering Advisor"], optional=True),
        rel("Book Coverage Assignment", "Coverage Team", ["Covering Coverage Team"], optional=True),
        rel("Household Reassignment", "Advisor", ["From Advisor"]),
        rel("Household Reassignment", "Advisor", ["To Advisor"]),
        rel("Household Reassignment", "Household", ["Reassigned Household"]),
        rel("Household Reassignment", "Calendar Date", ["Reassignment Effective Date"]),
        rel("Advisor Credential", "Advisor", ["Credential Holder"]),
        rel("Advice Review", "Advisor", ["Review Conducted By"]),
        rel("Advice Review", "Calendar Date", ["Review Due Date"]),
        rel("Household Service Request", "Client Account", ["Account"]),
        rel("Household Membership", "Household", ["Household"]),
        rel("Household Membership", "Client", ["Household Member"]),
        rel("Account Party Role", "Client Account", ["Role Account"]),
        rel("Account Party Role", "Client", ["Role Party"]),
        rel("Service Tier Assignment", "Household", ["Tier Party"]),
        rel("Service Tier Assignment", "Service Tier", ["Assigned Service Tier"]),
    ] + certified_rels(slice_parent="Advisor", slice_note="Only where Dimension Type = Advisor (the advisor of record)."),
    notes=("Plan section 8.3 example. The advisor capacity snapshot is the fact; the book is the household coverage bridge, "
           "and the account-to-household path runs through the DP-008/DP-240 bridges, never an account column. Book assets and "
           "NNA are DP-008's certified values by advisor of record; no edge to DP-491. Protected Households in Book is the "
           "DP-322 count read by Household key (DP-322 is a sibling consumer product; no 02 protection object is read here)."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-390"] = dict(
    style="Star",
    entities=[
        ent("Incentive Earnings", "Fact", [("03", "Compensation Statement"), ("03", "Incentive Earnings Line")],
            ["Statement ID", "Earning Component"], measures=True,
            grain="one row = compensation statement (advisor x statement period) x plan component earnings line; immutable once issued",
            note="Statement and earnings lines are one fact at line grain: every incentive measure is per component. PII tier: "
                 "financial (employee compensation; Confidential - Compensation). Payroll Result Reference (20) is carried as a "
                 "key: certified pay stays DP-198."),
        ent("Incentive Plan", "Dimension", [("03", "Incentive Compensation Plan")], ["Incentive Plan ID"],
            note="SCD type 2; no foundational model publishes 03 incentive plans."),
        ent("Incentive Plan Component", "Dimension", [("03", "Incentive Plan Component")], ["Component ID"],
            note="SCD type 2. Incentive Conflict Review Reference points at the latest 08 review; the review fact carries the "
                 "full history, so it is not drawn twice."),
        ent("Plan Participation", "Bridge", [("03", "Incentive Plan Participation")],
            ["Plan Participant", "Assigned Plan", "Participation Effective From"],
            grain="one row = advisor x incentive plan x participation effective period",
            note="PII tier: financial (target incentive amounts)."),
        ent("Recognition Award", "Fact", [("03", "Recognition Award")], ["Recognition Award ID"],
            grain="one row = recognition award to an advisor",
            note="PII tier: financial. Award Conduct Review Reference is the latest review pointer, as on the component."),
        ent("Variable Compensation Award", "Fact", [("20", "Variable Compensation Award")], ["Variable Compensation Award ID"],
            grain="one row = variable compensation award (employee x award type x performance year)",
            note="Read as DP-198 publishes it for the certified pay tie-out; built with DP-198's key (DP-198 is a consumer model "
                 "and is not conformed). PII tier: financial."),
        ent("Incentive Conflict Review", "Fact", [("08", "Incentive Conflict Review")],
            ["Reviewed Incentive Plan Component", "Reviewed Recognition Award", "Conflict Review Date"],
            grain="one row = 08 conflict review of a plan component or recognition award on a review date",
            note="The Reg BI incentive review is 08's (CW-064, CW-168). Mitigation Applied (38) is carried as a key."),
        certified(extra_note="Net New Assets and Ending Client Assets by advisor for the asset-based tie-out."),
        dim("Advisor", EMP9, note="Conformed from DP-009. PII tier: identity."),
        dim("Snapshot", SNAP),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Incentive Earnings", "Advisor", ["Statement Participant"]),
        rel("Incentive Earnings", "Incentive Plan Component", ["Earning Component"]),
        rel("Incentive Earnings", "Calendar Date", ["Statement Period End"]),
        rel("Incentive Plan Component", "Incentive Plan", ["Parent Incentive Plan"]),
        rel("Plan Participation", "Advisor", ["Plan Participant"]),
        rel("Plan Participation", "Incentive Plan", ["Assigned Plan"]),
        rel("Recognition Award", "Advisor", ["Award Recipient"]),
        rel("Recognition Award", "Calendar Date", ["Award Date"]),
        rel("Variable Compensation Award", "Advisor", ["Award Recipient"]),
        rel("Incentive Conflict Review", "Incentive Plan Component", ["Reviewed Incentive Plan Component"], optional=True),
        rel("Incentive Conflict Review", "Recognition Award", ["Reviewed Recognition Award"], optional=True),
    ] + certified_rels(slice_parent="Advisor", slice_note="Only where Dimension Type = Advisor."),
    notes=("Successor of the 07 compensation products (DP-032, DP-033, DP-082). Incentives in reduced form are 03, pay 20 "
           "(DP-198), the incentive conflict review 08. Asset-based component results are compared with DP-008's certified "
           "values by advisor, never substituted for them."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-391"] = dict(
    style="Star",
    entities=[
        ent("Supervisory Assignment", "Fact", [("03", "Supervisory Assignment")],
            ["Supervised Person", "Assigned Supervisor", "Supervisory Assignment Type", "Assignment Effective From"],
            measures=True,
            grain="one row = supervised person x assigned supervisor x assignment type x effective period; SCD type 2",
            note="Published under this name so that DP-398 (and other readers) conform the supervisor of record from here. "
                 "PII tier: identity (employees). Heightened Supervision Plan Reference is carried as an 08 key (DP-400 and "
                 "DP-402 publish the plans; neither is upstream)."),
        ent("Firm Branch Office", "Dimension", [("03", "Firm Branch Office")], ["Office", "Branch Designation Effective From"],
            note="Published under this name for DP-402, DP-404 and DP-414 to conform. SCD type 2 on designation. Branch "
                 "Registration Reference is the current Form BR pointer; the registration fact carries the history."),
        ent("Supervisory Hierarchy Link", "Bridge", [("03", "Supervisory Hierarchy Link")],
            ["Child Supervisory Unit", "Parent Supervisory Unit", "Link Effective From"],
            grain="one row = child supervisory unit x parent unit x link effective period",
            note="Units are offices or org units (registry has no single target); they are joined to Office Location, the unit "
                 "type used by assignments and designations (taxonomy gap)."),
        ent("Principal Designation", "Fact", [("03", "Principal Designation")],
            ["Designated Principal", "Principal Designation Type", "Designation Office", "Designation Effective From"],
            grain="one row = principal x designation type x office x effective period",
            note="PII tier: identity."),
        ent("Branch Registration", "Fact", [("08", "Branch Registration")],
            ["Registered Office", "Form BR Filing Type", "Form BR Filed Date"],
            grain="one row = Form BR filing for a branch office",
            note="08 registrations read directly, as DP-009 does; DP-039 is not upstream."),
        dim("Individual Registration", ("DP-009", "Individual Registration"), [("08", "Individual Registration")],
            note="Conformed from DP-009. PII tier: identity."),
        dim("Office Location", OFFICE, [("09", "Office Location")], note="Conformed from DP-013; gives the office state."),
        dim("Employee", EMP, note="Conformed from DP-192: supervised persons, supervisors and principals. PII tier: identity."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Supervisory Assignment", "Employee", ["Supervised Person"]),
        rel("Supervisory Assignment", "Employee", ["Assigned Supervisor"]),
        rel("Supervisory Assignment", "Office Location", ["Supervising Office"], optional=True),
        rel("Supervisory Assignment", "Calendar Date", ["Assignment Effective From"]),
        rel("Firm Branch Office", "Office Location", ["Office"]),
        rel("Supervisory Hierarchy Link", "Office Location", ["Child Supervisory Unit"]),
        rel("Supervisory Hierarchy Link", "Office Location", ["Parent Supervisory Unit"]),
        rel("Principal Designation", "Employee", ["Designated Principal"]),
        rel("Principal Designation", "Office Location", ["Designation Office"]),
        rel("Principal Designation", "Individual Registration", ["Qualifying Registration"], optional=True),
        rel("Branch Registration", "Firm Branch Office", ["Registered Office"]),
        rel("Individual Registration", "Employee", ["Registered Person"]),
    ],
    notes=("Rule 3110 supervisory structure. Assignments are the fact; offices, designations and registrations are matched by "
           "office and person so that span of supervision and unregistered branches can be counted. Taxonomy gap: assignments "
           "and designations do not reference the supervisory hierarchy unit; units are matched through the office."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-392"] = dict(
    style="Star",
    entities=[
        ent("Acquisition Milestone", "Fact", [("04", "Acquisition Milestone")],
            ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"], measures=True,
            grain="one row = party x milestone type x milestone date (x account where applicable); immutable events",
            note="The funnel fact runs from lead to account opening and funding and stops there: the opening of the advice "
                 "engagement is where DP-333 (CLA-A) starts, so a prospect who later engages advice is never counted twice as "
                 "a conversion. PII tier: identity (party and account keys)."),
        ent("Marketing Lead", "Fact", [("04", "Marketing Lead"), ("04", "Lead Conversion")], ["Lead ID"],
            grain="one row = marketing lead with its conversion",
            note="Lead Conversion folds into the lead. Captured contact data is not read (CW-083). PII tier: identity."),
        ent("Lead Status History", "Fact", [("04", "Lead Qualification")], ["Marketing Lead Key", "Lead Status Effective Timestamp"],
            grain="one row = lead x status effective timestamp",
            note="Model gap: the group carries no Lead ID, so the parent key is borrowed."),
        ent("Lead Assignment", "Fact", [("04", "Lead Assignment")], ["Marketing Lead Key", "Assigned Advisor"],
            grain="one row = lead x assigned advisor or team",
            note="Model gap: the group carries no Lead ID, so the parent key is borrowed. First Sales Activity (03 Advisor "
                 "Activity) is carried as a key."),
        ent("Application Journey", "Fact", [("04", "Application Journey")], ["Journey ID"],
            grain="one row = application journey", note="PII tier: identity."),
        ent("Onboarding Case", "Dimension", [("02", "Onboarding Case")], ["Onboarding Case ID"],
            note="Read directly: DP-240 does not publish the 02 onboarding case. PII tier: identity."),
        ent("Promotion Offer", "Dimension", [("04", "Promotion Offer")], ["Promotion ID"],
            note="Promotion Compliance Review (08) is carried as a key; the review is DP-036's."),
        ent("Promotion Enrollment", "Fact", [("04", "Promotion Enrollment")], ["Enrolled Promotion", "Enrolled Party", "Enrolled Account"],
            grain="one row = promotion x enrolled party x enrolled account", note="PII tier: identity."),
        ent("Client Referral", "Fact", [("04", "Client Referral")], ["Referral ID"],
            grain="one row = client-to-friend referral",
            note="Referee Party may be a party or a lead (no single registry target); it joins Party when it is a party. "
                 "PII tier: identity."),
        ent("Funding Money Movement", "Fact", [("50", "Money Movement")], ["Money Movement ID"],
            grain="one row = money movement that funds an account or pays a promotion award",
            note="Built from the input with DP-302's key so that bank details are not pulled in. PII tier: financial."),
        certified(extra_note="Net New Assets by campaign (Dimension Type Campaign), the 04 attribution weights applied once in DP-008."),
        dim("Client Account", ACCT, [("15", "Account"), ("15", "Account Opening")],
            note="Conformed from DP-093; Account Opening folds into the account (good order and approval dates). PII tier: financial."),
        dim("Party", PARTY, note="DP-240 Party: lead, applicant and enrolled party. PII tier: identity."),
        dim("Household", PARTY, note="DP-240 Party of Party Type Household, for Funded Households Acquired."),
        dim("Household Membership", HHM, [("02", "Household Membership")], role="Bridge",
            grain="one row = household x member x membership effective period"),
        dim("Campaign", CMP),
        dim("Advisor", EMP9, note="Advisor or coverage team assigned a lead. PII tier: identity."),
        dim("Fee Waiver", ("DP-305", "Fee Waiver"), note="Promotion awards paid as 47 fee waivers."),
        dim("Snapshot", SNAP, [("06", "Snapshot")]),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Acquisition Milestone", "Party", ["Milestone Party"]),
        rel("Acquisition Milestone", "Client Account", ["Milestone Account"], optional=True),
        rel("Acquisition Milestone", "Calendar Date", ["Milestone Date"]),
        rel("Marketing Lead", "Party", ["Lead Party"], optional=True),
        rel("Marketing Lead", "Party", ["Converted Party"], optional=True),
        rel("Marketing Lead", "Campaign", ["Original Campaign"], optional=True),
        rel("Marketing Lead", "Application Journey", ["Resulting Application Journey"], optional=True),
        rel("Lead Status History", "Marketing Lead", ["Marketing Lead Key"]),
        rel("Lead Assignment", "Marketing Lead", ["Marketing Lead Key"]),
        rel("Lead Assignment", "Advisor", ["Assigned Advisor"], optional=True),
        rel("Application Journey", "Party", ["Journey Applicant Party"]),
        rel("Application Journey", "Onboarding Case", ["Resulting Onboarding Case"], optional=True),
        rel("Application Journey", "Client Account", ["Resulting Account"], optional=True),
        rel("Onboarding Case", "Party", ["Case Party"]),
        rel("Client Account", "Funding Money Movement", ["Initial Funding Transaction"], optional=True),
        rel("Household Membership", "Household", ["Household"]),
        rel("Household Membership", "Party", ["Household Member"]),
        rel("Promotion Offer", "Campaign", ["Promotion Campaign"], optional=True),
        rel("Promotion Enrollment", "Promotion Offer", ["Enrolled Promotion"]),
        rel("Promotion Enrollment", "Party", ["Enrolled Party"]),
        rel("Promotion Enrollment", "Client Account", ["Enrolled Account"], optional=True),
        rel("Promotion Enrollment", "Fee Waiver", ["Award Fee Waiver"], optional=True),
        rel("Client Referral", "Party", ["Referrer Party"]),
        rel("Client Referral", "Party", ["Referee Party"], optional=True),
        rel("Client Referral", "Promotion Enrollment", ["Referral Reward Enrollment"], optional=True),
        rel("Funding Money Movement", "Promotion Enrollment", ["Source Promotion Enrollment"], optional=True),
    ] + certified_rels(slice_parent="Campaign", slice_note="Only where Dimension Type = Campaign."),
    notes=("Acquisition milestones are the funnel spine; leads, journeys, openings and funding are companion facts joined by "
           "party and account. Funded households come through the DP-240 membership bridge. Campaign NNA is DP-008's certified "
           "value; spend and attribution views are DP-410's."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-393"] = dict(
    style="Star",
    entities=[
        ent("Channel Referral", "Fact", [("03", "Channel Referral")], ["Referral ID"], measures=True,
            grain="one row = channel referral (RFRL-)",
            note="PII tier: identity (client keys). Source Service Request (13), Resulting Marketing Lead (04) and Resulting "
                 "Trust (51) are carried as keys: DP-381, DP-392 and DP-307 are not upstream."),
        ent("Referral Status History", "Fact", [("03", "Referral Status History")],
            ["Channel Referral Key", "History Referral Status", "Status Change Timestamp"],
            grain="one row = channel referral x status x status change timestamp",
            note="Model gap: the group carries no Referral ID, so the parent key is borrowed."),
        ent("Participant Retail Hand-Off", "Fact", [("16", "Participant Retail Hand-Off")], ["Hand-Off ID"],
            grain="one row = participant plan membership x hand-off trigger event (PRTHO-)",
            note="DP-430's hand-off fact, built with its key; Hand-Off Rollover Amount is DP-430's published value, not a "
                 "certified number. PII tier: identity (participant keys)."),
        certified(extra_note="Net Inter-Channel Transfers by target channel."),
        dim("Advice Engagement", ("DP-303", "Advice Engagement"), [("45", "Advice Engagement")]),
        dim("Program Enrollment", ENROLL, [("15", "Program Enrollment")]),
        dim("Client Account", ACCT, note="PII tier: financial."),
        dim("Offering", OFFER),
        dim("Client", PARTY, note="DP-240 Party referred. PII tier: identity."),
        dim("Referring Employee", EMP, note="PII tier: identity."),
        dim("Advisor", EMP9, note="Target or referred advisor. PII tier: identity."),
        dim("Coverage Team", TEAM),
        dim("Participant", ("DP-094", "Participant"), note="Plan membership handed off. PII tier: identity."),
        dim("Consent Record", ("DP-240", "Consent Record"), note="Contact consent for the hand-off."),
        dim("Snapshot", SNAP, [("06", "Snapshot")]),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Channel Referral", "Client", ["Referred Party"]),
        rel("Channel Referral", "Referring Employee", ["Referring Employee"]),
        rel("Channel Referral", "Advisor", ["Target Advisor"], optional=True),
        rel("Channel Referral", "Coverage Team", ["Target Coverage Team"], optional=True),
        rel("Channel Referral", "Advice Engagement", ["Resulting Advice Engagement"], optional=True),
        rel("Channel Referral", "Program Enrollment", ["Resulting Program Enrollment"], optional=True),
        rel("Channel Referral", "Calendar Date", ["Referral Date"]),
        rel("Referral Status History", "Channel Referral", ["Channel Referral Key"]),
        rel("Participant Retail Hand-Off", "Participant", ["Hand-Off Membership"]),
        rel("Participant Retail Hand-Off", "Consent Record", ["Contact Consent"], optional=True),
        rel("Participant Retail Hand-Off", "Advice Engagement", ["Referral Advice Engagement"], optional=True),
        rel("Participant Retail Hand-Off", "Advisor", ["Referred Advisor"], optional=True),
        rel("Participant Retail Hand-Off", "Calendar Date", ["Trigger Date"]),
        rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
        rel("Program Enrollment", "Offering", ["Enrolled Service Offering"]),
    ] + certified_rels(),
    notes=("Referrals and participant hand-offs are two facts that meet at the advice engagement and program enrollment they "
           "produce, which gives the conversion and leakage rates. DP-467 reads Hand-Off to Advice Engagement Rate % as "
           "defined here; the PTE 2020-02 evidence of a rollover is DP-335's."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-394"] = dict(
    style="Star",
    entities=[
        ent("Engagement Event", "Fact", [("04", "Engagement Event")], ["Event Visitor / Party", "Engagement Event Type", "Event Timestamp"],
            measures=True,
            grain="one row = visitor or party x engagement event type x event timestamp, under the applied tracking consent; immutable",
            note="PII tier: identity (pseudonymous visitor keys). Event Application Journey is carried as a 04 key (DP-392's). "
                 "Model gap: no input carries the page of an event (the taxonomy has none either), so Web Page Key is borrowed "
                 "for Journey Events by Page Type."),
        ent("Session", "Fact", [("04", "Session")], ["Session ID"], grain="one row = web or app session",
            note="Keeps DP-011's key. PII tier: identity."),
        ent("Digital Profile", "Fact", [("04", "Digital Profile")], ["Digital Profile ID"],
            grain="one row = client digital profile (current state)", note="PII tier: identity."),
        ent("Experiment", "Dimension", [("04", "Experiment")], ["Experiment ID"],
            note="Results are computed here, not stored in 04 (CW-091)."),
        ent("Experiment Assignment", "Fact", [("04", "Experiment Assignment")], ["Assigned Experiment", "Assigned Visitor / Party"],
            grain="one row = experiment x visitor or party", note="PII tier: identity."),
        ent("Digital Property", "Dimension", [("04", "Digital Property")], ["Property ID"],
            note="Model gap: no input links a page to its property, so Digital Property Key is borrowed on Web Page."),
        ent("Nudge Definition", "Dimension", [("04", "Nudge Definition")], ["Nudge ID"]),
        ent("Nudge Delivery", "Fact", [("04", "Nudge Delivery")], ["Delivered Nudge", "Delivery Party", "Delivered Timestamp"],
            grain="one row = nudge x party x delivered timestamp",
            note="The 45 recommendation a delivery carried is linked, never classified here (CW-228). PII tier: identity."),
        ent("Nudge Compliance Review", "Dimension", [("08", "Compliance Review")], ["Review ID"],
            note="Read directly: no foundational product publishes 08 reviews (DP-036 is the review product)."),
        ent("Nudge Determination", "Fact", [("08", "Compliance Approval")], ["Nudge Compliance Review Key", "Approval Decision Date"],
            grain="one row = compliance review x approval decision date",
            note="The recorded 08 determination of whether a nudge is a recommendation, reported as recorded (CW-228). Model gap: "
                 "the group carries no Review ID, so the parent key is borrowed."),
        dim("Web Visitor", VISITOR, [("04", "Web Visitor / Known User")],
            note="Conformed from DP-011; carries the applied tracking consent. PII tier: identity."),
        dim("Web Page", ("DP-011", "Web Page"), [("04", "Web Page")]),
        dim("Metric Definition", ("DP-101", "Metric Definition"), [("21", "Metric Definition")],
            note="The primary metric's definition is 21's (DP-101)."),
        dim("Recommendation", REC, [("45", "Recommendation")]),
        dim("Party", PARTY, note="PII tier: identity."),
        dim("Share Class", SHARE),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Engagement Event", "Web Visitor", ["Event Visitor / Party"]),
        rel("Engagement Event", "Session", ["Event Session"], optional=True),
        rel("Engagement Event", "Experiment", ["Exposed Experiment"], optional=True),
        rel("Engagement Event", "Web Page", ["Web Page Key"], optional=True, note="Model gap (see entity)."),
        rel("Engagement Event", "Calendar Date", ["Event Timestamp"]),
        rel("Session", "Web Visitor", ["Session Visitor"]),
        rel("Web Visitor", "Party", ["Matched Party"], optional=True),
        rel("Web Page", "Share Class", ["Page Product / Share Class"], optional=True),
        rel("Web Page", "Digital Property", ["Digital Property Key"], optional=True, note="Model gap (see Digital Property)."),
        rel("Digital Profile", "Party", ["Digital Profile Party"]),
        rel("Experiment", "Metric Definition", ["Primary Metric"]),
        rel("Experiment Assignment", "Experiment", ["Assigned Experiment"]),
        rel("Experiment Assignment", "Web Visitor", ["Assigned Visitor / Party"]),
        rel("Nudge Definition", "Nudge Compliance Review", ["Nudge Compliance Review"], optional=True),
        rel("Nudge Determination", "Nudge Compliance Review", ["Nudge Compliance Review Key"]),
        rel("Nudge Delivery", "Nudge Definition", ["Delivered Nudge"]),
        rel("Nudge Delivery", "Party", ["Delivery Party"]),
        rel("Nudge Delivery", "Recommendation", ["Linked Recommendation"], optional=True),
    ],
    notes=("Plan section 8.3 example. Events are the fact under the visitor's applied tracking consent; experiments and nudges "
           "are dimensions with their own assignment and delivery facts. Recommendation evidence is DP-334's and its review "
           "DP-398's; this product only shows the link and the recorded determination."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-398"] = dict(
    style="Star",
    entities=[
        ent("Supervisory Review Outcome", "Fact", [("08", "Supervisory Review"), ("08", "Best Interest Review Detail")],
            ["Supervisory Review ID"], measures=True,
            grain="one row = one principal review of one subject (PRNR-); immutable once completed, open reviews snapshot daily",
            note="Published under this name: DP-334 and DP-335 read Review Outcome, Review Completed Date and the evidence "
                 "indicators from here as recorded; this product owns the workflow and never re-scores evidence (CW-215, "
                 "CW-224). Best Interest Review Detail folds into the review. PII tier: identity (client and representative "
                 "keys; restricted to supervision). Reviewed Correspondence (08 Captured Communication Record), Applied "
                 "Supervisory Control (DP-402), Source Sales Practice Alert (DP-400) and Disclosure Delivery Checked (DP-399) are "
                 "carried as keys: those products are not upstream."),
        dim("Supervisor of Record", ("DP-391", "Supervisory Assignment"), [("03", "Supervisory Assignment")], role="Bridge",
            grain="one row = supervised person x assigned supervisor x assignment type x effective period",
            note="Conformed from DP-391, which owns the supervisory structure; gives Reviews by Unassigned Principal and Self-Reviews."),
        dim("Recommendation", REC, [("45", "Recommendation")]),
        dim("Client Account", ACCT, [("15", "Account Opening")],
            note="Conformed from DP-093; Account Opening (approval) folds into the account. PII tier: financial."),
        dim("Account Feature", ("DP-093", "Account Feature"), [("15", "Account Feature"), ("15", "Options Approval Detail")],
            note="Options Approval Detail folds into the feature."),
        dim("Client Order", ("DP-301", "Client Order"), [("48", "Client Order")]),
        dim("Routing Rule", ("DP-432", "Routing Rule"), note="Best-execution review subject."),
        dim("Execution Venue", ("DP-432", "Execution Venue"), note="Best-execution review subject."),
        dim("Investor Profile", ("DP-240", "Investor Profile"), note="Profile version checked. PII tier: financial."),
        dim("Best Interest Evidence", ("DP-303", "Best Interest Evidence")),
        dim("Rollover Analysis", ("DP-303", "Rollover Analysis")),
        dim("Advisor", EMP9, note="Supervised representative. PII tier: identity."),
        dim("Principal", EMP, note="Reviewing principal and approvers (DP-192). PII tier: identity."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Supervisory Review Outcome", "Recommendation", ["Reviewed Recommendation"], optional=True),
        rel("Supervisory Review Outcome", "Client Account", ["Reviewed Account"], optional=True),
        rel("Supervisory Review Outcome", "Account Feature", ["Reviewed Account Feature"], optional=True),
        rel("Supervisory Review Outcome", "Client Order", ["Reviewed Client Order"], optional=True),
        rel("Supervisory Review Outcome", "Routing Rule", ["Reviewed Routing Rule"], optional=True),
        rel("Supervisory Review Outcome", "Execution Venue", ["Reviewed Execution Venue"], optional=True),
        rel("Supervisory Review Outcome", "Advisor", ["Supervised Representative"], optional=True),
        rel("Supervisory Review Outcome", "Principal", ["Reviewing Principal"]),
        rel("Supervisory Review Outcome", "Investor Profile", ["Investor Profile Version Checked"], optional=True),
        rel("Supervisory Review Outcome", "Best Interest Evidence", ["Best Interest Evidence Reviewed"], optional=True),
        rel("Supervisory Review Outcome", "Rollover Analysis", ["Rollover Analysis Reviewed"], optional=True),
        rel("Supervisory Review Outcome", "Calendar Date", ["Review Completed Date"], optional=True),
        rel("Recommendation", "Advisor", ["Recommending Advisor"]),
        rel("Client Account", "Principal", ["Account Approved By"], optional=True),
        rel("Account Feature", "Client Account", ["Feature Account"]),
        rel("Account Feature", "Principal", ["Feature Approved By"], optional=True),
        rel("Client Order", "Client Account", ["Order Account"]),
        rel("Supervisor of Record", "Advisor", ["Supervised Person"]),
        rel("Supervisor of Record", "Principal", ["Assigned Supervisor"]),
    ],
    notes=("The principal review queue. One review fact for every review type, with exactly one subject link set per row; the "
           "subjects are conformed from their owners (DP-303, DP-093, DP-301, DP-432). Taxonomy gap: no queued or assigned "
           "timestamp, so aging starts at the subject's own timestamp."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-399"] = dict(
    style="Star",
    entities=[
        ent("Disclosure Delivery Check", "Fact", [("08", "Disclosure Delivery Check")],
            ["Checked Account", "Checked Retail Investor", "Disclosure Trigger", "Trigger Date"], measures=True,
            grain="one row = account or retail investor x disclosure trigger x trigger date; immutable per check",
            note="08 owns the check. Client-Level Delivery Evidence (45 Best Interest Evidence) is carried as a key: it is "
                 "DP-334's evidence and DP-303 is not upstream. PII tier: identity."),
        ent("Account Disclosure Delivery", "Fact", [("15", "Account Disclosure Delivery")],
            ["Disclosure Account", "Disclosure Type", "Disclosure Version", "Disclosure Delivered Date"],
            grain="one row = account x disclosure type x version x delivered date",
            note="Read directly: DP-093 does not publish it. PII tier: identity."),
        ent("Recipient Delivery", "Fact", [("13", "Recipient Delivery Record")],
            ["Distribution Job", "Delivered Investor Document", "Recipient Account"],
            grain="one row = distribution job x investor document x recipient account",
            note="Built with the registry's composite key, which is the natural key behind DP-382 Document Delivery, so it joins "
                 "there without pulling DP-382's delivery columns. PII tier: identity."),
        ent("Fee Disclosure Delivery", "Fact", [("47", "Fee Disclosure Delivery")],
            ["Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type", "Disclosed Fee Schedule",
             "Fee Disclosure Delivered Date"],
            grain="one row = recipient x account x fee disclosure type x fee schedule x delivered date",
            note="Keeps DP-305's key. PII tier: identity."),
        ent("Form CRS Filing", "Dimension", [("38", "Firm Regulatory Filing"), ("38", "Form CRS Filing Detail")], ["Firm Filing ID"],
            note="Read directly: no foundational product publishes 38 filings. Form CRS Filing Detail folds into the filing."),
        dim("Client Account", ACCT, [("15", "Account")], note="Conformed from DP-093; the opening population. PII tier: financial."),
        dim("Retail Investor", PARTY, note="PII tier: identity."),
        dim("Program Enrollment", ENROLL),
        dim("Communication", ("DP-382", "Communication")),
        dim("Communication Distribution", ("DP-382", "Communication Distribution")),
        dim("Investor Document", ("DP-382", "Investor Document")),
        dim("Fee Schedule", ("DP-305", "Fee Schedule")),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Disclosure Delivery Check", "Client Account", ["Checked Account"], optional=True),
        rel("Disclosure Delivery Check", "Retail Investor", ["Checked Retail Investor"], optional=True),
        rel("Disclosure Delivery Check", "Form CRS Filing", ["Form CRS Version Required"], optional=True),
        rel("Disclosure Delivery Check", "Account Disclosure Delivery", ["Account Delivery Evidence"], optional=True),
        rel("Disclosure Delivery Check", "Communication", ["Communication Delivery Evidence"], optional=True),
        rel("Disclosure Delivery Check", "Fee Disclosure Delivery", ["Fee Disclosure Evidence"], optional=True),
        rel("Disclosure Delivery Check", "Calendar Date", ["Check Date"]),
        rel("Account Disclosure Delivery", "Client Account", ["Disclosure Account"]),
        rel("Account Disclosure Delivery", "Program Enrollment", ["Related Program Enrollment"], optional=True),
        rel("Recipient Delivery", "Communication Distribution", ["Distribution Job"]),
        rel("Recipient Delivery", "Investor Document", ["Delivered Investor Document"]),
        rel("Recipient Delivery", "Client Account", ["Recipient Account"]),
        rel("Fee Disclosure Delivery", "Retail Investor", ["Fee Disclosure Recipient"]),
        rel("Fee Disclosure Delivery", "Client Account", ["Fee Disclosure Account"]),
        rel("Fee Disclosure Delivery", "Fee Schedule", ["Disclosed Fee Schedule"]),
    ],
    notes=("The check is the fact and each delivery source (15 account opening, 13 communications, 47 fee disclosures) is its "
           "own evidence fact, because each has its own owner (CW-087, CW-162, CW-223); the Form CRS filing in force is the "
           "version dimension."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-400"] = dict(
    style="Star",
    entities=[
        ent("Sales Practice Alert", "Fact", [("08", "Sales Practice Alert")], ["Sales Practice Alert ID"], measures=True,
            grain="one row = sales practice alert (SPA-) with its disposition",
            note="PII tier: identity (client and representative keys; restricted to supervision)."),
        ent("Surveillance Scenario", "Dimension", [("08", "Surveillance Scenario")], ["Scenario ID"],
            note="SCD type 2 on thresholds; no foundational product publishes 08 scenarios."),
        ent("Conduct Corrective Action", "Fact", [("08", "Conduct Corrective Action")], ["Corrective Action ID"],
            grain="one row = corrective action",
            note="Source Supervisory Review (DP-398) and Client Remediation (13, DP-409) are carried as keys: neither is "
                 "upstream. PII tier: identity."),
        ent("Heightened Supervision Plan", "Fact", [("08", "Heightened Supervision Plan")], ["Heightened Supervision Plan ID"],
            grain="one row = heightened supervision plan for a representative",
            note="Read without its basis, which can be special category (CD-344). PII tier: identity."),
        ent("Client Holding", "Fact", [("49", "Client Holding"), ("49", "Client Holding Valuation")], ["Client Holding ID"],
            grain="one row = client holding (account x instrument x holding date x view) with its valuation",
            note="Book of record 49 through DP-300 (CW-007), never 06 or 18; used for the concentration coverage test. PII "
                 "tier: financial."),
        dim("Recommendation", REC, [("45", "Recommendation")]),
        dim("Share Class", SHARE, [("01", "Product Risk Indicator")],
            note="Conformed from DP-004; the firm risk rating folds into the share class and sets the complex-product scenarios."),
        dim("Instrument", ("DP-300", "Instrument")),
        dim("Client Account", ACCT, [("15", "Account")], note="PII tier: financial."),
        dim("Client Order", ("DP-301", "Client Order"), note="The triggering transaction."),
        dim("Advisor", EMP9, note="PII tier: identity."),
        dim("Model", ("DP-212", "Model"), note="Scenario model in the 37 inventory."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Sales Practice Alert", "Surveillance Scenario", ["Alert Scenario"]),
        rel("Sales Practice Alert", "Client Account", ["Alert Account"], optional=True),
        rel("Sales Practice Alert", "Advisor", ["Alerted Representative"], optional=True),
        rel("Sales Practice Alert", "Client Order", ["Triggering Transaction"], optional=True),
        rel("Sales Practice Alert", "Recommendation", ["Triggering Recommendation"], optional=True),
        rel("Sales Practice Alert", "Calendar Date", ["Alert Generated Date"]),
        rel("Surveillance Scenario", "Model", ["Scenario Model"], optional=True),
        rel("Conduct Corrective Action", "Sales Practice Alert", ["Source Sales Practice Alert"], optional=True),
        rel("Conduct Corrective Action", "Advisor", ["Action Subject Representative"], optional=True),
        rel("Heightened Supervision Plan", "Advisor", ["Supervised Representative"]),
        rel("Recommendation", "Share Class", ["Recommended Share Class"], optional=True),
        rel("Recommendation", "Instrument", ["Recommended Instrument"], optional=True),
        rel("Client Holding", "Client Account", ["Holding Account"]),
        rel("Client Holding", "Instrument", ["Held Instrument"]),
    ],
    notes=("Alerts are the fact with scenario, representative, account and triggering recommendation or order as dimensions; "
           "corrective actions and heightened supervision plans are companion facts. Holdings are read only from Client "
           "Holding (49); market-abuse surveillance is 38 (DP-228)."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-402"] = dict(
    style="Star",
    entities=[
        ent("Supervisory Control Test", "Fact", [("08", "Supervisory Control Test")], ["Tested Control", "Test Period End Date"],
            measures=True, grain="one row = supervisory control x test period; immutable once completed",
            note="Rule 3120 testing. PII tier: identity (tester employee key)."),
        ent("Supervisory Control", "Dimension", [("08", "Supervisory Control")], ["Supervisory Control Number"]),
        ent("WSP Policy", "Dimension", [("38", "Policy")], ["Policy ID"],
            note="Written supervisory procedures are 38 Policies, read directly: no foundational product publishes them."),
        ent("Branch Inspection", "Fact", [("08", "Branch Inspection")], ["Branch Inspection ID"],
            grain="one row = inspection of a branch office",
            note="Published under this name for DP-404 to conform (office slice of findings). PII tier: identity (inspector)."),
        ent("Supervisory Finding", "Fact", [("08", "Supervisory Finding")], ["Supervisory Finding ID"],
            grain="one row = supervisory finding from an inspection or control test",
            note="Taxonomy gap: no owner, due or closed date; those come from the corrective action raised from the finding."),
        ent("Finding Corrective Action", "Fact", [("08", "Conduct Corrective Action")], ["Corrective Action ID"],
            grain="one row = corrective action raised from a finding", note="PII tier: identity (action owner)."),
        ent("Heightened Supervision Plan", "Fact", [("08", "Heightened Supervision Plan")], ["Heightened Supervision Plan ID"],
            grain="one row = heightened supervision plan",
            note="Read without its basis, which can be special category (CD-344). PII tier: identity."),
        ent("Supervisory Attestation", "Fact", [("38", "Attestation")], ["Attester", "Attestation Type"],
            grain="one row = attester x attestation type (Rule 3130 certification)",
            note="38 Attestation, read directly. PII tier: identity."),
        dim("Firm Branch Office", ("DP-391", "Firm Branch Office"), [("03", "Firm Branch Office")],
            note="Conformed from DP-391, which owns the branch structure."),
        dim("Office Location", OFFICE),
        dim("Employee", EMP, note="Testers, inspectors, action owners, heightened supervisors and attesters. PII tier: identity."),
        dim("Advisor", EMP9, note="Representative under heightened supervision. PII tier: identity."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Supervisory Control Test", "Supervisory Control", ["Tested Control"]),
        rel("Supervisory Control Test", "Employee", ["Control Tester"], optional=True),
        rel("Supervisory Control Test", "Calendar Date", ["Test Period End Date"]),
        rel("Supervisory Control", "WSP Policy", ["Governing WSP Policy"], optional=True),
        rel("Branch Inspection", "Firm Branch Office", ["Inspected Office"]),
        rel("Branch Inspection", "Employee", ["Inspector"], optional=True),
        rel("Branch Inspection", "Calendar Date", ["Inspection Date"]),
        rel("Supervisory Finding", "Branch Inspection", ["Source Branch Inspection"], optional=True),
        rel("Supervisory Finding", "Supervisory Control Test", ["Source Control Test"], optional=True),
        rel("Finding Corrective Action", "Supervisory Finding", ["Source Supervisory Finding"]),
        rel("Finding Corrective Action", "Employee", ["Action Owner"], optional=True),
        rel("Heightened Supervision Plan", "Advisor", ["Supervised Representative"]),
        rel("Heightened Supervision Plan", "Employee", ["Heightened Supervisor"], optional=True,
            note="Heightened Supervisor is an employee identifier without a registry link."),
        rel("Supervisory Attestation", "Employee", ["Attester"]),
        rel("Firm Branch Office", "Office Location", ["Office"]),
    ],
    notes=("Controls x test period is the main fact; inspections, findings and their actions are a chain of companion facts so "
           "a finding is traced to its source and its remediation. Corrective actions from alerts are DP-400's."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-403"] = dict(
    style="Star",
    entities=[
        ent("Senior Investor Case", "Fact", [("08", "Senior Investor Case")], ["Senior Investor Case ID"], measures=True,
            grain="one row = senior investor case (SNRC-) with status history; restricted view",
            note="PII tier: special category (CD-344); restricted view, aggregates elsewhere with a minimum cell of 10 (CW-225). "
                 "This product owns the Rule 2165 hold clock and the case counts; DP-456 reads them. Source Vulnerability Concern "
                 "(02, special category) is carried as a DP-322 key and Related AML Case as a 38 key (DP-226): neither is "
                 "conformed."),
        ent("Senior Investor Case Action", "Fact", [("08", "Senior Investor Case Action")],
            ["Senior Investor Case Key", "Protection Action Type", "Action Date"],
            grain="one row = case x protective action type x action date",
            note="Model gap: the group carries no case ID, so the parent key is borrowed. PII tier: special category."),
        ent("External Protection Report", "Fact", [("08", "External Protection Report")],
            ["Reported Case", "Report Recipient Type", "Recipient Agency", "Report Date"],
            grain="one row = case x recipient type x agency x report date", note="PII tier: special category."),
        dim("Rule 2165 Disbursement Hold", ("DP-322", "Fact Money Movement Hold"), [("50", "Money Movement Hold")], role="Fact",
            grain="one row = money movement hold linked to a senior investor case",
            note="Conformed from DP-322's restricted view: the Rule 2165 hold rows that DP-302 suppresses (CW-213). This "
                 "product's Senior Investor Case stays the owner of the case and the hold clock. PII tier: special category."),
        dim("Rule 2165 Account Restriction", ("DP-322", "Fact Rule 2165 Restriction"), [("15", "Account Restriction")], role="Fact",
            grain="one row = Rule 2165 (financial exploitation) account restriction",
            note="Conformed from DP-322's restricted view: the Rule 2165 restriction rows that DP-093 suppresses. PII tier: "
                 "special category."),
        ent("Held Money Movement", "Fact", [("50", "Money Movement")], ["Money Movement ID"],
            grain="one row = money movement placed on hold",
            note="Built with DP-302's key for the amount held; bank details are not pulled in. PII tier: financial."),
        dim("Trusted Contact Designation", ("DP-240", "Trusted Contact Designation"), [("02", "Trusted Contact Designation")],
            note="Conformed from DP-240. PII tier: identity."),
        dim("Client", PARTY, note="Case client and designating client. PII tier: identity (the case facts carry the special category)."),
        dim("Protection Agency", PARTY, note="Adult protective services or regulator receiving a report."),
        dim("Client Account", ACCT, note="PII tier: financial."),
        dim("Case Owner", EMP, note="PII tier: identity."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Senior Investor Case", "Client", ["Case Client"]),
        rel("Senior Investor Case", "Case Owner", ["Case Owner"], optional=True),
        rel("Senior Investor Case", "Calendar Date", ["Case Opened Date"]),
        rel("Senior Investor Case Action", "Senior Investor Case", ["Senior Investor Case Key"]),
        rel("Senior Investor Case Action", "Trusted Contact Designation", ["Trusted Contact Designation Used"], optional=True),
        rel("Senior Investor Case Action", "Rule 2165 Account Restriction", ["Account Hold"], optional=True),
        rel("Senior Investor Case Action", "Rule 2165 Disbursement Hold", ["Disbursement Hold"], optional=True),
        rel("External Protection Report", "Senior Investor Case", ["Reported Case"]),
        rel("External Protection Report", "Protection Agency", ["Recipient Agency"]),
        rel("Rule 2165 Disbursement Hold", "Senior Investor Case", ["Senior Investor Case"], optional=True),
        rel("Rule 2165 Disbursement Hold", "Held Money Movement", ["Held Movement"]),
        rel("Rule 2165 Disbursement Hold", "Trusted Contact Designation", ["Trusted Contact Notified"], optional=True),
        rel("Rule 2165 Disbursement Hold", "Calendar Date", ["Hold Placed Date"]),
        rel("Rule 2165 Account Restriction", "Client Account", ["Restricted Account"]),
        rel("Held Money Movement", "Client Account", ["Movement Account"]),
        rel("Trusted Contact Designation", "Client", ["Designating Client"]),
    ],
    notes=("The named restricted view for the 08 Rule 2165 case (CW-213): the case is the fact, holds and restrictions are "
           "companion facts linked through the case actions and the hold's own case key, which gives the hold clock (placed, "
           "notice, expiry, released). DP-322 is the protection register and must not list this product upstream."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-404"] = dict(
    style="Star",
    entities=[
        ent("Conduct Indicator", "Fact", [], ["Conduct Indicator Key"], measures=True,
            grain="one row = indicator x business line x offering x office x advisor x month; monthly snapshot",
            note="Each indicator is a count or rate read from its owning product under the owner's measure name and normalized "
                 "by DP-008 only at the advisor and business line slices; nothing is re-derived (CW-224). The evidence gap "
                 "counts are DP-334's Evidence Gap Flag and DP-335's PTE Documentation Gap Flag, read by the Recommendation "
                 "and Rollover Analysis keys below (DP-334 and DP-335 are sibling consumer products, so their keys are carried, "
                 "not conformed). Business line is a degenerate column. Model gap: no input carries the indicator grain, so the "
                 "fact has a surrogate key and borrows its dimension keys. PII tier: identity (advisor-level employee "
                 "performance data; no client-level rows)."),
        ent("Review Outcome Count", "Fact", [("08", "Supervisory Review")], ["Supervisory Review ID"],
            grain="one row = supervisory review outcome as recorded by DP-398",
            note="Only the representative, outcome and completion date are read (no client keys), with DP-398's key."),
        ent("Alert Count", "Fact", [("08", "Sales Practice Alert")], ["Sales Practice Alert ID"],
            grain="one row = sales practice alert as published by DP-400"),
        ent("Corrective Action Count", "Fact", [("08", "Conduct Corrective Action")], ["Corrective Action ID"],
            grain="one row = corrective action as published by DP-400"),
        ent("Finding Count", "Fact", [("08", "Supervisory Finding")], ["Supervisory Finding ID"],
            grain="one row = supervisory finding as published by DP-402"),
        ent("Complaint Count", "Fact", [("08", "Complaint")], ["Complaint ID"],
            grain="one row = complaint as published by DP-414 (advisor and office only)"),
        ent("CE Requirement", "Fact", [("08", "CE Requirement")], ["CE Person", "CE Due Date"],
            grain="one row = person x CE due date, as published by DP-039 (restricted licensing view)",
            note="Model gap: the registry key also carries CE Registration and CE Element, which are not product inputs."),
        ent("FINRA Filing Count", "Fact", [("08", "FINRA Advertising Filing")], ["FINRA Filing Count Key"],
            grain="one row = FINRA advertising filing as published by DP-036",
            note="Model gap: neither the parent Compliance Review key nor FINRA Filing Reference is a product input, so the "
                 "row has a surrogate key; it joins the star only by its due date."),
        dim("Advisor Coverage", ("DP-009", "Coverage Assignment"), [("03", "Party Coverage Assignment")], role="Bridge",
            grain="one row = household x advisor coverage assignment",
            note="Conformed from DP-009 (the key is not a product input). Gives households per advisor for the DP-322 flag "
                 "counts; primary coverage only."),
        certified(extra_note="Households and Ending Client Assets as denominators (Dimension Type Advisor and Business Line)."),
        dim("Recommendation", REC, [("45", "Recommendation")], note="The DP-334 join key."),
        dim("Rollover Analysis", ("DP-303", "Rollover Analysis"), [("45", "Rollover Analysis")], note="The DP-335 join key."),
        dim("Individual Registration", ("DP-009", "Individual Registration"), [("08", "Individual Registration")],
            note="Registration status as DP-039 reads it."),
        dim("Branch Inspection", ("DP-402", "Branch Inspection"), note="Gives the office of a finding."),
        dim("Household", ("DP-303", "Party"), [("02", "Party")],
            note="DP-303 Party (DP-240 is not upstream); only the key is read. PII tier: identity."),
        dim("Advisor", EMP9, note="PII tier: identity."),
        dim("Offering", OFFER),
        dim("Firm Branch Office", ("DP-391", "Firm Branch Office")),
        dim("Snapshot", SNAP, [("06", "Snapshot")]),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Conduct Indicator", "Advisor", ["Advisor Key"], optional=True, note="Model gap (see entity)."),
        rel("Conduct Indicator", "Offering", ["Offering Key"], optional=True),
        rel("Conduct Indicator", "Firm Branch Office", ["Firm Branch Office Key"], optional=True),
        rel("Conduct Indicator", "Calendar Date", ["Calendar Date Key"], note="The month-end."),
        rel("Recommendation", "Advisor", ["Recommending Advisor"]),
        rel("Recommendation", "Offering", ["Recommended Service Offering"], optional=True),
        rel("Rollover Analysis", "Recommendation", ["Rollover Recommendation"]),
        rel("Review Outcome Count", "Advisor", ["Supervised Representative"], optional=True),
        rel("Alert Count", "Advisor", ["Alerted Representative"], optional=True),
        rel("Corrective Action Count", "Advisor", ["Action Subject Representative"], optional=True),
        rel("Finding Count", "Branch Inspection", ["Source Branch Inspection"], optional=True),
        rel("Branch Inspection", "Firm Branch Office", ["Inspected Office"]),
        rel("Complaint Count", "Advisor", ["Associated Person Named"], optional=True),
        rel("Complaint Count", "Firm Branch Office", ["Complaint Office"], optional=True),
        rel("Individual Registration", "Advisor", ["Registered Person"]),
        rel("CE Requirement", "Advisor", ["CE Person"]),
        rel("FINRA Filing Count", "Calendar Date", ["Filing Due Date"]),
        rel("Advisor Coverage", "Household", ["Covered Party"]),
        rel("Advisor Coverage", "Advisor", ["Covering Advisor"]),
    ] + certified_rels(slice_parent="Advisor", slice_note="Only where Dimension Type = Advisor."),
    notes=("Retail conduct risk indicators (SM-29). The indicator fact sits over thin count facts that keep the owning "
           "products' keys and only the advisor, office and offering links, so every count can be traced to its owner. Senior "
           "investor cases are not counted here (special category, DP-403); protection appears only as the DP-322 count."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-414"] = dict(
    style="Star",
    entities=[
        ent("Complaint", "Fact",
            [("08", "Complaint"), ("08", "Complaint Classification"), ("08", "Complaint Handling"), ("08", "Complaint Regulatory Report")],
            ["Complaint ID"], measures=True,
            grain="one row = complaint (CPL-) with classification, handling and Rule 4530 reporting; handling SCD type 2",
            note="The three groups fold into the complaint (one row each per complaint). PII tier: identity (complainant and "
                 "account keys; restricted drill); a complaint revealing a vulnerability counts only through the DP-322 flag on "
                 "the complainant key. Related Recommendation (45), Client Remediation (13, DP-409), Arbitration Matter (39) and "
                 "Related Disclosure Event (08) are carried as keys: their owners are not upstream."),
        ent("Contact Center Interaction", "Fact", [("13", "Contact Center Interaction")], ["Interaction ID"],
            grain="one row = assisted-service interaction",
            note="Unlogged dissatisfaction; keeps DP-381's key. PII tier: identity."),
        ent("Survey Response", "Fact", [("04", "Survey Response")], ["Response ID"],
            grain="one row = survey response", note="Read directly (DP-011 does not publish it); verbatims are not read."),
        dim("Advisor of Record", ("DP-009", "Coverage Assignment"), [("03", "Party Coverage Assignment")], role="Bridge",
            grain="one row = account x covering advisor x coverage effective period",
            note="Conformed from DP-009, which carries the Coverage Assignment ID this product does not read. Effective dated; "
                 "the primary coverage at the received date is the advisor of record."),
        dim("Program Enrollment", ENROLL, [("15", "Program Enrollment")], role="Bridge",
            grain="one row = account x offering x enrollment effective period",
            note="Conformed from DP-093; gives Complaints per 1,000 Accounts by Offering."),
        dim("Service Request", ("DP-381", "Service Request"), [("13", "Service Request")]),
        dim("Complainant", PARTY, note="PII tier: identity."),
        dim("Client Account", ACCT, note="PII tier: financial."),
        dim("Share Class", SHARE),
        dim("Offering", OFFER),
        dim("Advisor", EMP9, note="PII tier: identity."),
        dim("Firm Branch Office", ("DP-391", "Firm Branch Office")),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Complaint", "Complainant", ["Complainant"]),
        rel("Complaint", "Service Request", ["Intake Service Request"], optional=True),
        rel("Complaint", "Client Account", ["Account"], optional=True),
        rel("Complaint", "Share Class", ["Product / Share Class"], optional=True),
        rel("Complaint", "Advisor", ["Associated Person Named"], optional=True),
        rel("Complaint", "Firm Branch Office", ["Complaint Office"], optional=True),
        rel("Complaint", "Calendar Date", ["Received Date"]),
        rel("Service Request", "Complaint", ["Escalated Complaint"], optional=True),
        rel("Contact Center Interaction", "Client Account", ["Interaction Account"], optional=True),
        rel("Contact Center Interaction", "Service Request", ["Linked Service Request"], optional=True),
        rel("Survey Response", "Complaint", ["Complaint Referral"], optional=True),
        rel("Advisor of Record", "Client Account", ["Covered Account"]),
        rel("Advisor of Record", "Advisor", ["Covering Advisor"]),
        rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
        rel("Program Enrollment", "Offering", ["Enrolled Service Offering"]),
    ],
    notes=("Complaints are 08 and service requests 13 (CW-070); the Rule 4530 definition decides. Unlogged dissatisfaction "
           "(interactions, survey referrals) are companion facts tested against the complaint key. DP-385 and DP-404 read the "
           "counts."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-405"] = dict(
    style="Star",
    entities=[
        ent("Contact Center Interaction", "Fact", [("13", "Contact Center Interaction")], ["Interaction ID"], measures=True,
            grain="one row = assisted-service interaction (DP-381), aggregated by queue x day",
            note="DP-381's service fact read with its key; its contact measures are read under DP-381's names (CW-222). "
                 "PII tier: identity (client keys and agent ids; leadership views are aggregates)."),
        ent("Interaction Authentication", "Fact", [("13", "Interaction Authentication")],
            ["Authenticated Interaction", "Authentication Attempt Number"],
            grain="one row = interaction x authentication attempt"),
        ent("QA Review", "Fact", [("13", "QA Review")], ["Reviewed Item"], grain="one row = QA review of a service request",
            note="Keeps DP-381's key."),
        ent("Service Level Definition", "Dimension", [("13", "Service Level Definition")], ["SLA ID"]),
        ent("Service Level Measurement", "Fact", [("13", "Service Level Measurement")],
            ["Service Level Definition Key", "Measurement Period"],
            grain="one row = service level definition x measurement period",
            note="Model gap: the group carries no SLA ID, so the parent key is borrowed; Measurement Period is text, so the "
                 "period end date is borrowed as Calendar Date Key. Abandonment comes from here (taxonomy gap on the interaction)."),
        ent("Client Survey", "Dimension", [("04", "Client Survey")], ["Survey ID"]),
        ent("Survey Response", "Fact", [("04", "Survey Response")], ["Response ID"],
            grain="one row = transactional survey response",
            note="Verbatims, which can be special category, are not read (CW-225)."),
        ent("Digital Self-Service Event", "Fact", [("04", "Engagement Event")], ["Digital Self-Service Event Key"],
            grain="one row = digital self-service engagement event",
            note="Model gap: Event Visitor / Party, part of the registry key, is not a product input (no visitor is needed for "
                 "the deflection count), so the row has a surrogate key."),
        dim("Service Request", ("DP-381", "Service Request")),
        dim("Contact Center Agent", EMP, note="PII tier: identity."),
        dim("Client Account", ACCT, [("15", "Account")], note="Denominator for Contacts per 1,000 Accounts. PII tier: financial."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Contact Center Interaction", "Client Account", ["Interaction Account"], optional=True),
        rel("Contact Center Interaction", "Contact Center Agent", ["Interaction Agent"], optional=True),
        rel("Contact Center Interaction", "Service Request", ["Linked Service Request"], optional=True),
        rel("Contact Center Interaction", "Calendar Date", ["Interaction Start Timestamp"]),
        rel("Interaction Authentication", "Contact Center Interaction", ["Authenticated Interaction"]),
        rel("QA Review", "Service Request", ["Reviewed Item"]),
        rel("Service Level Measurement", "Service Level Definition", ["Service Level Definition Key"]),
        rel("Service Level Measurement", "Calendar Date", ["Calendar Date Key"], note="Model gap (see entity)."),
        rel("Survey Response", "Client Survey", ["Response Survey"]),
        rel("Survey Response", "Contact Center Interaction", ["Triggering Interaction"], optional=True),
        rel("Digital Self-Service Event", "Calendar Date", ["Event Timestamp"]),
    ],
    notes=("Plan section 8.3 example. Interactions are the fact at queue x day; service levels, QA, surveys and digital "
           "self-service are companion facts. Complaints are DP-414's and cost per contact DP-498's."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-408"] = dict(
    style="Star",
    entities=[
        ent("Vote Tally", "Fact", [("13", "Vote Tally")], ["Proxy Proposal Key", "Tally As-Of Date"], measures=True,
            grain="one row = own-fund proxy proposal x tally as-of date; immutable",
            note="Model gap: the tally carries no proposal key (only the grain names it), so the proposal key is borrowed."),
        ent("Proxy Proposal", "Dimension", [("13", "Proxy Proposal")], ["Proposal ID"],
            note="Model gap: no input links a proposal to its campaign, so the campaign key is borrowed."),
        ent("Proxy Campaign", "Dimension", [("13", "Proxy Campaign")], ["Proxy Campaign ID"]),
        ent("Intermediary Vote Instruction", "Fact", [("13", "Intermediary Vote Instruction")],
            ["Proxy Proposal Key", "Voting Intermediary"],
            grain="one row = proposal x voting intermediary",
            note="Model gap: the proposal key is borrowed, as on the tally."),
        ent("Issuer Proxy Pass-Through", "Fact", [("13", "Issuer Proxy Pass-Through")], ["Issuer Meeting", "Pass-Through Account"],
            grain="one row = issuer meeting x brokerage account", note="PII tier: financial (account entitlements)."),
        ent("Beneficial Owner Disclosure Election", "Fact", [("13", "Beneficial Owner Disclosure Election")],
            ["Disclosure Election Account", "Disclosure Election Effective From"],
            grain="one row = account x OBO / NOBO election effective period", note="PII tier: identity."),
        ent("Voting Choice Election", "Fact", [("13", "Voting Choice Election")], ["Voting Choice Election ID"],
            grain="one row = account x fund x voting choice effective period",
            note="Chosen Voting Policy (34) is carried as a key. PII tier: identity."),
        ent("Client Holding", "Fact", [("49", "Client Holding")], ["Client Holding ID"],
            grain="one row = brokerage client holding (49, DP-300) at the record date",
            note="Pass-through entitlement source for brokerage accounts (CW-007). Never joined to the register fact: the two "
                 "are compared, not added. PII tier: financial."),
        ent("Register Position", "Fact", [("29", "Share Register Balance")],
            ["Register Account", "Register Share Class", "Register Business Date"],
            grain="one row = register account x share class x business date (29, DP-580)",
            note="Record-date shares of own funds for TA-registered accounts; keeps DP-580 Register Position's key and is "
                 "reconciled to the tally's Shares Outstanding at Record Date, never summed with Client Holding (CW-007). "
                 "PII tier: financial."),
        dim("Corporate Action Event", ("DP-099", "Corporate Action Event"), [("17", "Corporate Action Event")],
            note="The issuer meeting (DP-099)."),
        dim("Instrument", ("DP-099", "Instrument")),
        dim("Client Account", ACCT, note="PII tier: financial."),
        dim("Investment Product", PROD, note="Registrant fund of a campaign and fund of a voting choice."),
        dim("Share Class", SHARE),
        dim("Party", ("DP-093", "Party"), note="Solicitation agent and voting intermediary."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Vote Tally", "Proxy Proposal", ["Proxy Proposal Key"]),
        rel("Vote Tally", "Calendar Date", ["Tally As-Of Date"]),
        rel("Proxy Proposal", "Proxy Campaign", ["Proxy Campaign Key"]),
        rel("Proxy Campaign", "Investment Product", ["Registrant / Fund"]),
        rel("Proxy Campaign", "Party", ["Solicitation Agent"], optional=True),
        rel("Proxy Campaign", "Calendar Date", ["Record Date"]),
        rel("Intermediary Vote Instruction", "Proxy Proposal", ["Proxy Proposal Key"]),
        rel("Intermediary Vote Instruction", "Party", ["Voting Intermediary"]),
        rel("Issuer Proxy Pass-Through", "Corporate Action Event", ["Issuer Meeting"]),
        rel("Issuer Proxy Pass-Through", "Client Account", ["Pass-Through Account"]),
        rel("Corporate Action Event", "Instrument", ["Event Instrument"]),
        rel("Beneficial Owner Disclosure Election", "Client Account", ["Disclosure Election Account"]),
        rel("Voting Choice Election", "Client Account", ["Voting Choice Account"]),
        rel("Voting Choice Election", "Investment Product", ["Voting Choice Fund"]),
        rel("Client Holding", "Client Account", ["Holding Account"]),
        rel("Client Holding", "Instrument", ["Held Instrument"]),
        rel("Register Position", "Client Account", ["Register Account"]),
        rel("Register Position", "Share Class", ["Register Share Class"]),
    ],
    notes=("Three shapes in one star: own-fund solicitation (campaign, proposal, tally), issuer pass-through (meeting x account) "
           "and elections (account x period). The record-date position is read from the two books of record, Client Holding "
           "(49) for brokerage and the register (29) for TA accounts, as separate facts; 06 is never read (CW-007)."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-409"] = dict(
    style="Star",
    entities=[
        ent("Shareholder Remediation", "Fact", [("13", "Shareholder Remediation")], ["Remediation ID"], measures=True,
            grain="one row = servicing error x remediated account (13 Shareholder Remediation); payment status kept",
            note="Model gap: the remediation carries no reference to its servicing error (the taxonomy has none), so the error "
                 "key is borrowed. PII tier: financial (account keys with remediation amounts)."),
        ent("Servicing Error", "Dimension", [("13", "Servicing Error")], ["Servicing Error ID"],
            note="Related NAV Error Case (27, DP-169) and Correction Transactions (29) are carried as keys."),
        ent("Remediation Money Movement", "Fact", [("50", "Money Movement")], ["Money Movement ID"],
            grain="one row = remediation payment (50 money movement)",
            note="Built with DP-302's key (CW-107); bank details are not pulled in. PII tier: financial."),
        ent("Incident Source Record", "Bridge", [("37", "Incident Source Record")], ["Incident Source Record Key"],
            grain="one row = operational incident x source record (here a servicing error)",
            note="The only link between a servicing error and its 37 incident; surrogate key per the registry."),
        ent("Operational Incident", "Dimension", [("37", "Operational Incident")], ["Operational Incident ID"],
            note="Built from the input: DP-215 is a consumer product, so it is not conformed (same key)."),
        dim("Client Account", ACCT, note="PII tier: financial."),
        dim("Responsible Party", ("DP-093", "Party"), note="Party responsible for the error (provider, intermediary)."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Shareholder Remediation", "Servicing Error", ["Servicing Error Key"], note="Model gap (see entity)."),
        rel("Shareholder Remediation", "Client Account", ["Remediated Account"]),
        rel("Shareholder Remediation", "Remediation Money Movement", ["Remediation Money Movement"], optional=True),
        rel("Servicing Error", "Responsible Party", ["Responsible Party"], optional=True),
        rel("Servicing Error", "Calendar Date", ["Error Occurrence Date"]),
        rel("Incident Source Record", "Operational Incident", ["Source Incident"]),
        rel("Incident Source Record", "Servicing Error", ["Source Servicing Error"], optional=True),
        rel("Remediation Money Movement", "Calendar Date", ["Value Date"], optional=True),
    ],
    notes=("Error and remediation part of retired DP-043. Remediation rows are the fact, each tied to its error, its payment and "
           "(through the incident source record) the operational incident. NAV-error remediation stays DP-169."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-410"] = dict(
    style="Star",
    entities=[
        ent("Campaign Performance", "Fact", [], ["Campaign Performance Key"], measures=True,
            grain="one row = campaign node x attribution model x month; monthly snapshot",
            note="The reporting grain over the companion facts (spend, delivery, outcomes, touchpoints, events). Model gap: no "
                 "input carries this grain, so the fact has a surrogate key and borrows its campaign, model and month keys."),
        dim("Campaign", CMP, [("04", "Campaign"), ("04", "Campaign Targeting")],
            note="Conformed from DP-011; Campaign Targeting folds into the node. Hierarchy through Parent Campaign (SCD type 2). "
                 "Target Segments (DP-412's 04 Marketing Segment) and Marketing Theme are carried as keys."),
        ent("Campaign Product", "Bridge", [("04", "Campaign Product")], ["Campaign Key", "Campaign Product / Share Class"],
            grain="one row = campaign x featured share class",
            note="Model gap: the group carries no Campaign ID, so the parent key is borrowed."),
        ent("Campaign Budget", "Fact", [("04", "Campaign Budget")], ["Campaign Key", "Budget Currency"],
            grain="one row = campaign x budget currency", note="Model gap: parent key borrowed, as on Campaign Product."),
        ent("Spend Line", "Fact", [("04", "Spend Line")], ["Spend Line Key"],
            grain="one row = campaign spend line",
            note="Surrogate key per the registry; parent key borrowed. Taxonomy gap: no spend date, so spend falls in the month "
                 "of the node's Planned Start Date."),
        ent("Campaign Tracking Code", "Dimension", [("04", "Campaign Tracking Code")], ["Campaign Key", "Tracked URL"],
            note="Model gap: parent key borrowed."),
        ent("Campaign Member", "Fact", [("04", "Campaign Member")], ["Campaign Key", "Member Party", "Member Lead"],
            grain="one row = campaign x member party or lead",
            note="Model gap: no Campaign ID among the inputs, so it is borrowed (DP-011 keys the member the same way). Member "
                 "Lead is carried as a DP-392 key. PII tier: identity."),
        ent("Media Placement", "Dimension", [("04", "Media Placement")], ["Placement ID"]),
        ent("Paid Media Delivery", "Fact", [("04", "Paid Media Delivery")], ["Paid Media Delivery Key"],
            grain="one row = paid media delivery of a placement",
            note="Surrogate key per the registry; the placement key is borrowed (the group carries no Placement ID)."),
        ent("Attribution Model", "Dimension", [("04", "Attribution Model")], ["Attribution Model Key"],
            note="Surrogate key per the registry."),
        ent("Attributed Outcome", "Fact", [("04", "Attributed Outcome")],
            ["Attributed Milestone", "Attributed Campaign", "Applied Attribution Model"],
            grain="one row = acquisition milestone x campaign x attribution model",
            note="Attributed Outcomes (Primary Model) for DP-492. Attributed Amount is the 04 weight view, never added to the "
                 "certified campaign NNA."),
        ent("Acquisition Milestone", "Fact", [("04", "Acquisition Milestone")],
            ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"],
            grain="one row = party x milestone type x milestone date (x account)",
            note="Same key as DP-392's funnel fact. PII tier: identity."),
        ent("Marketing Touchpoint", "Fact", [("04", "Marketing Touchpoint")], ["Touchpoint Party", "Touchpoint Type", "Touchpoint Timestamp"],
            grain="one row = party x touchpoint type x timestamp", note="PII tier: identity."),
        dim("Marketing Event", ("DP-011", "Marketing Event"), [("04", "Marketing Event")]),
        ent("Event Registration", "Fact", [("04", "Event Registration")], ["Marketing Event Key", "Registrant Party"],
            grain="one row = marketing event x registrant",
            note="Model gap: the event key is borrowed (DP-011 keys registrations the same way). PII tier: identity."),
        dim("Content Asset", ("DP-011", "Content Asset"),
            [("04", "Content Asset"), ("04", "Audience Restriction"), ("04", "Asset Classification")],
            note="Audience Restriction and Asset Classification fold into the asset. Taxonomy gap: no link to the campaign that "
                 "uses the content; featured products are matched through Campaign Product."),
        ent("Social Media Account", "Dimension", [("04", "Social Media Account")], ["Social Account ID"]),
        ent("Social Post", "Fact", [("04", "Social Post")], ["Platform Post ID"],
            grain="one row = social post",
            note="Model gap: no input links a post to its account, so the account key is borrowed. Post Compliance Review (08) "
                 "is carried as a key; the review is DP-036's."),
        certified(extra_note="Net New Assets by campaign (Dimension Type Campaign)."),
        dim("Party", PARTY, note="PII tier: identity."),
        dim("Client Account", ("DP-008", "Account"), note="DP-008 Account (DP-093 is not upstream). PII tier: financial."),
        dim("Share Class", SHARE),
        dim("Snapshot", SNAP, [("06", "Snapshot")]),
        dim("Measure Definition", MDEF),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Campaign Performance", "Campaign", ["Campaign Key"], note="Model gap (see entity)."),
        rel("Campaign Performance", "Attribution Model", ["Attribution Model Key"]),
        rel("Campaign Performance", "Calendar Date", ["Calendar Date Key"], note="The month-end."),
        rel("Campaign", "Campaign", ["Parent Campaign"], optional=True, note="Program, campaign, wave, tactic hierarchy."),
        rel("Campaign Product", "Campaign", ["Campaign Key"]),
        rel("Campaign Product", "Share Class", ["Campaign Product / Share Class"]),
        rel("Campaign Budget", "Campaign", ["Campaign Key"]),
        rel("Spend Line", "Campaign", ["Campaign Key"]),
        rel("Campaign Tracking Code", "Campaign", ["Campaign Key"]),
        rel("Campaign Member", "Campaign", ["Campaign Key"]),
        rel("Campaign Member", "Party", ["Member Party"], optional=True),
        rel("Media Placement", "Campaign", ["Placement Campaign"]),
        rel("Paid Media Delivery", "Media Placement", ["Media Placement Key"]),
        rel("Attributed Outcome", "Acquisition Milestone", ["Attributed Milestone"]),
        rel("Attributed Outcome", "Campaign", ["Attributed Campaign"]),
        rel("Attributed Outcome", "Attribution Model", ["Applied Attribution Model"]),
        rel("Acquisition Milestone", "Party", ["Milestone Party"]),
        rel("Acquisition Milestone", "Client Account", ["Milestone Account"], optional=True),
        rel("Acquisition Milestone", "Calendar Date", ["Milestone Date"]),
        rel("Marketing Touchpoint", "Party", ["Touchpoint Party"]),
        rel("Marketing Touchpoint", "Campaign", ["Touchpoint Campaign"], optional=True),
        rel("Marketing Event", "Campaign", ["Owning Campaign"], optional=True),
        rel("Event Registration", "Marketing Event", ["Marketing Event Key"]),
        rel("Event Registration", "Party", ["Registrant Party"]),
        rel("Content Asset", "Share Class", ["Featured Products / Share Classes"], card="M:N"),
        rel("Social Post", "Campaign", ["Post Campaign"], optional=True),
        rel("Social Post", "Social Media Account", ["Social Media Account Key"]),
    ] + certified_rels(slice_parent="Campaign", slice_note="Only where Dimension Type = Campaign."),
    notes=("Campaign node x attribution model x month over companion facts. Campaign NNA is DP-008's certified value, the same "
           "value DP-492 reads; the 04 attributed outcomes are shown beside it, never added to it. Acquisition cost and "
           "lifetime value are DP-498's."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-412"] = dict(
    style="Star",
    entities=[
        ent("Segment Membership", "Fact", [("04", "Segment Membership")], ["Marketing Segment Key", "Member Party", "Membership Effective From"],
            measures=True, grain="one row = party x marketing segment x membership effective period; SCD type 2",
            note="Model gap: the membership carries no segment reference, so the segment key is borrowed. PII tier: identity."),
        ent("Marketing Segment", "Dimension", [("04", "Marketing Segment")], ["Segment ID"],
            note="Marketing audiences are 04; 02 client segments are not audiences (CW-094)."),
        ent("Subscription Topic", "Dimension", [("04", "Subscription Topic")], ["Subscription Topic ID"]),
        ent("Suppression Entry", "Fact", [("04", "Suppression Entry")], ["Suppressed Identifier", "Suppression Scope"],
            grain="one row = suppressed identifier x scope", note="PII tier: identity (hashed identifiers)."),
        ent("Tracking Consent Choice", "Fact", [("04", "Tracking Consent Choice")], ["Choice Visitor", "Choice Timestamp"],
            grain="one row = visitor x tracking choice timestamp", note="PII tier: identity (pseudonymous)."),
        ent("Email Interaction", "Fact", [("04", "Email Interaction")], ["Email Send Key", "Recipient Party"],
            grain="one row = email send x recipient party",
            note="Model gap: the registry key (Recipient Email Address) is not a product input and is not read (personal "
                 "data); the row is keyed as DP-011 keys it, by the send and the recipient party. PII tier: identity."),
        ent("Communication Preference", "Fact", [("02", "Communication Preference")],
            ["Preference Party", "Preference Topic", "Preference Channel"],
            grain="one row = party x subscription topic x channel (opt-in state)",
            note="Read as DP-324 publishes it; DP-324 is a sibling consumer product (models_wc_cla_a.py) still being modeled, "
                 "so the rows are built here with the registry key rather than conformed. PII tier: identity."),
        ent("Contact Preference", "Fact", [("02", "Contact Preference")], ["Preference Holder", "Preference Effective From"],
            grain="one row = party x do-not-contact preference effective period",
            note="Read as DP-324 publishes it (see Communication Preference). PII tier: identity."),
        dim("Email Send", ("DP-011", "Email Send"), [("04", "Email Send")]),
        dim("Campaign", CMP, [("04", "Campaign")]),
        dim("Content Asset", ("DP-011", "Content Asset"), note="Email template."),
        dim("Web Visitor", VISITOR, [("04", "Web Visitor / Known User")], note="PII tier: identity."),
        dim("Consent Record", ("DP-240", "Consent Record"), note="Revoked consent behind a suppression."),
        dim("Party", PARTY, note="PII tier: identity."),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Segment Membership", "Marketing Segment", ["Marketing Segment Key"], note="Model gap (see entity)."),
        rel("Segment Membership", "Party", ["Member Party"]),
        rel("Segment Membership", "Calendar Date", ["Membership Effective From"]),
        rel("Suppression Entry", "Consent Record", ["Revoked Consent Record"], optional=True),
        rel("Suppression Entry", "Calendar Date", ["Suppression Effective From"]),
        rel("Tracking Consent Choice", "Web Visitor", ["Choice Visitor"]),
        rel("Web Visitor", "Party", ["Matched Party"], optional=True),
        rel("Email Send", "Campaign", ["Email Campaign"], optional=True),
        rel("Email Send", "Content Asset", ["Email Template Asset"], optional=True),
        rel("Email Send", "Subscription Topic", ["Email Subscription Topic"], optional=True),
        rel("Email Interaction", "Email Send", ["Email Send Key"]),
        rel("Email Interaction", "Party", ["Recipient Party"]),
        rel("Communication Preference", "Party", ["Preference Party"]),
        rel("Communication Preference", "Subscription Topic", ["Preference Topic"]),
        rel("Contact Preference", "Party", ["Preference Holder"]),
    ],
    notes=("Audiences, subscriptions and tracking consent. Opt-in state and consent are 02 as DP-324 publishes them; topics, "
           "suppression and tracking choices are 04 (CW-084, CW-094). The opted-out and late write-back tests join the email "
           "interaction to the party's preference."),
)

# ----------------------------------------------------------------------------------------------------------------------
MODELS["DP-418"] = dict(
    style="Star",
    entities=[
        ent("Dormancy Assessment", "Fact", [("13", "Dormancy Assessment")], ["Dormancy Assessment Key"], measures=True,
            grain="one row = account x reporting state x dormancy assessment cycle; status SCD type 2",
            note="Surrogate key per the registry. Taxonomy gap: no link to the report that escheated it; matched on Reporting "
                 "State and report year. PII tier: financial (account keys with owner state)."),
        ent("Lost Securityholder Status", "Fact", [("13", "Lost Shareholder Status")], ["Status Account", "First Returned Mail Date"],
            grain="one row = account x lost securityholder episode (first returned mail date)", note="PII tier: financial."),
        ent("Escheatment Report", "Fact", [("13", "Escheatment Report & Remittance")], ["Escheatment Report ID"],
            grain="one row = state escheatment report and remittance"),
        ent("Unclaimed Property Reclaim", "Fact", [("13", "Unclaimed Property Reclaim")], ["Reclaim ID"],
            grain="one row = reclaim of escheated property", note="PII tier: identity."),
        ent("Owner Service Request", "Fact", [("13", "Service Request")], ["Service Request ID"],
            grain="one row = service request (owner-generated contact)", note="DP-381's key. PII tier: identity."),
        ent("Owner Interaction", "Fact", [("13", "Contact Center Interaction")], ["Owner Interaction Key"],
            grain="one row = assisted-service interaction on an account",
            note="Model gap: Interaction ID is not a product input, so the row has a surrogate key."),
        ent("Register Position", "Fact", [("29", "Share Register Balance")],
            ["Register Account", "Register Share Class", "Register Business Date"],
            grain="one row = register account x share class x business date (29, DP-580)",
            note="Registered shares at risk for TA-registered accounts; separate from Client Holding and never summed with it "
                 "(CW-007). PII tier: financial."),
        ent("Client Holding", "Fact", [("49", "Client Holding"), ("49", "Client Holding Valuation")], ["Client Holding ID"],
            grain="one row = brokerage client holding with its valuation (49, DP-300)",
            note="Brokerage value at risk (CW-007); never 06. PII tier: financial."),
        ent("Remittance Money Movement", "Fact", [("50", "Money Movement")], ["Money Movement ID"],
            grain="one row = remittance money movement (50, DP-302)", note="Built with DP-302's key."),
        dim("Client Account", ACCT, note="PII tier: financial."),
        dim("Claimant", PARTY, note="PII tier: identity."),
        dim("Legal Entity", ("DP-300", "Internal Legal Entity"), note="Entity running the Rule 17Ad-17 search."),
        dim("Share Class", ("DP-580", "Share Class")),
        dim("Calendar Date", CAL),
    ],
    relationships=[
        rel("Dormancy Assessment", "Client Account", ["Dormancy Account"]),
        rel("Dormancy Assessment", "Calendar Date", ["Presumed Abandoned Date"], optional=True),
        rel("Lost Securityholder Status", "Client Account", ["Status Account"]),
        rel("Lost Securityholder Status", "Legal Entity", ["Searching Entity"], optional=True),
        rel("Escheatment Report", "Remittance Money Movement", ["Remittance Money Movement"], optional=True),
        rel("Escheatment Report", "Calendar Date", ["Report Due Date"]),
        rel("Unclaimed Property Reclaim", "Claimant", ["Claimant"]),
        rel("Owner Service Request", "Client Account", ["Account"]),
        rel("Owner Interaction", "Client Account", ["Interaction Account"]),
        rel("Register Position", "Client Account", ["Register Account"]),
        rel("Register Position", "Share Class", ["Register Share Class"]),
        rel("Client Holding", "Client Account", ["Holding Account"]),
        rel("Remittance Money Movement", "Calendar Date", ["Value Date"], optional=True),
        rel("Unclaimed Property Reclaim", "Calendar Date", ["Calendar Date Key"], optional=True,
            note="Model gap: the reclaim has no date among the inputs; the load date is borrowed."),
    ],
    notes=("Dormancy assessment is the fact; lost securityholder episodes, reports, reclaims, owner contact and the two books "
           "of record are companion facts joined by account (CW-007: register for TA accounts, Client Holding for brokerage)."),
)
