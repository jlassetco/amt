"""Logical data models, wealth-manager WP2 consumer wave, group B4 'DIS' (Star): the consumer products of
specs_w1c_dis.py (Distribution, Channels & Client Economics) that had no model: DP-486, DP-487, DP-488, DP-490, DP-491,
DP-492, DP-493, DP-495, DP-496, DP-497, DP-498, DP-499, DP-503, DP-505, DP-506, DP-510, DP-511 and DP-514. DP-243 keeps
its model in models_e8c_cross_area.py. See CONTRACT.md and Wealth_Manager_Rework_Plan.md section 8.4.

Conventions used in these stars:
- Certified numbers are read from their one owner and never re-derived (CW-011, CW-241): Client Assets, Net New Assets,
  Advised Assets and the counts are 06 Measure Value rows of the locked DP-008 snapshot; Firm AUM and its slices are
  DP-241's; client fee revenue is DP-012's. A certified read is a Fact built from the product's own 06 Measure Value
  input, keyed exactly as the DP-008 Measure Value (Measure, Period End Date, Dimension Type, Dimension Key, Data Basis,
  Snapshot), so it joins to the certified row without pulling DP-008 columns the product does not publish. Snapshot,
  Measure Definition and Reporting Period are conformed from DP-008.
- Client Assets and Firm AUM are different certified families that overlap (CW-011): where a product reads both (DP-490,
  DP-496) the Firm AUM slices are separate Fact entities joined only through the calendar, and no Fact adds them.
- Books of record (CW-007): Client Holding (49) is a Fact of its own, never joined to a Portfolio Holding (18); the 06
  Fund Shareholder Position is modeled as a view of the register for look-through and tie-out, never as a second source
  of client holdings; the 18 Portfolio Valuation Summary is read only as a Firm AUM slice.
- Facts, bridges and child entities are built from the product's own inputs, keeping the foundational natural keys so
  they still join. A Fact is conformed from its foundational owner only where the product reads the owner's row but not
  every attribute of its key (the conformed entity then supplies the key); each such case says so in its note.
- Client Account is conformed from DP-093 Account (DP-007 Account where DP-093 is not upstream); Party and Household from
  DP-240 Party (a household is a Party of Party Type Household, PTY-HH-); the account-to-household path is the DP-093
  Account Party Role bridge to the party and the DP-240 Household Membership bridge to the household, never a column.
- Advisor is conformed from DP-009 Employee (03 Advisor folds there); service and sign-off employees from DP-192
  Employee where DP-009 is not upstream. Offering, Service Tier, Share Class, Investment Product and Model Portfolio
  are conformed from DP-004; partner firms from DP-001 Distributor Firm; institutional, plan sponsor, consultant and
  recordkeeper profiles, mandates and the 02 Retirement Plan party from DP-003 (DP-094 for the recordkept plan).
- No foundational model publishes a Channel entity: distribution channel is a code value (DP-013 code list) and stays
  degenerate on the facts; 06 Account Channel Assignment is not an input of any of these products.
- Date roles are conformed from DP-013 Calendar Date (firm business calendar, Calendar Key fixed), so a date attribute on
  a fact is the foreign key.
- A child Attribute Group, or an object whose own attributes do not identify its parent, borrows "<Parent> Key"; the
  model notes record each such case as a "Model gap".
- Household and advisor economics (DP-498, DP-499) and the member-level allocation read (DP-503) are restricted views
  registered in DP-518 (CW-243, CD-344): each is a Fact entity of its own whose note names the view and the PII tier; the
  published facts carry aggregates only.
- Every entity names its PII tier in its note ("PII tier: identity | financial | none"); where the product publishes
  aggregates only, the tier of the row-level read is stated with the publication rule.
"""

SNAP = ("DP-008", "Snapshot")
MDEF = ("DP-008", "Measure Definition")
RPER = ("DP-008", "Reporting Period")
CAL = ("DP-013", "Calendar Date")
LE13 = ("DP-013", "Internal Legal Entity")
ACCT = ("DP-093", "Account")
PTY240 = ("DP-240", "Party")
HHM = ("DP-240", "Household Membership")
APR = ("DP-093", "Account Party Role")
SEG = ("DP-240", "Segment Assignment")
PTY1 = ("DP-001", "Party")
DFIRM = ("DP-001", "Distributor Firm")
EMP9 = ("DP-009", "Employee")
EMP192 = ("DP-192", "Employee")
OFFER = ("DP-004", "Service Offering")
STIER = ("DP-004", "Service Tier")
SHARE = ("DP-004", "Share Class")
PROD = ("DP-004", "Investment Product")
MODELP = ("DP-004", "Model Portfolio")
AGREE = ("DP-005", "Distribution Agreement")
PAYARR = ("DP-005", "Payment Arrangement")
COMP = ("DP-481", "Competitor")
CAMP = ("DP-011", "Campaign")

MV = ("06", "Measure Value")
CAM = ("06", "Client Asset Measures")
MVPK = ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Data Basis", "Snapshot"]


def dim(name, src, objects=(), pk=None, note="", role="Dimension", grain=""):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note)
    if pk:
        d["pk"] = list(pk)
    if grain:
        d["grain"] = grain
    return d


def ent(name, role, objects, pk, grain="", note="", measures=False):
    return dict(name=name, role=role, objects=list(objects), pk=list(pk), grain=grain, note=note, measures=measures)


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


def cert(name, objects, grain, note, measures=False, period=False):
    """The certified DP-008 read: a Fact at the DP-008 Measure Value key with its snapshot, definition and dates."""
    rels = [rel(name, "Snapshot", ["Snapshot"]), rel(name, "Measure Definition", ["Measure"]),
            rel(name, "Calendar Date", ["Period End Date"], note="The period end.")]
    if period:
        rels.append(rel(name, "Reporting Period", ["Reporting Period"]))
    return ent(name, "Fact", objects, MVPK, grain, note, measures), rels


SNAP_NOTE = ("Conformed from DP-008: only a Final or Restated snapshot is read, so every certified number names the "
             "locked version it came from. PII tier: none.")
MDEF_NOTE = "Conformed from DP-008: the certified definition each read measure resolves to. PII tier: none."
CAL_NOTE = "Conformed from DP-013 (firm business calendar); date attributes on the facts are the foreign key. PII tier: none."


def _tiers(models, tiers):
    """Append the product's default PII tier to any entity note that does not state one."""
    for pid, m in models.items():
        for e in m["entities"]:
            if "PII tier" not in e.get("note", ""):
                e["note"] = (e.get("note", "") + " " if e.get("note") else "") + f"PII tier: {tiers[pid]}."
    return models


# ======================================================================================================================
# DP-505 Industry Flows, Market Share & Sizing
# ======================================================================================================================
_c505, _r505 = cert("Fact Firm Client Assets", [MV, CAM],
                    "one row = DP-008 Ending Client Assets or Net New Assets at Dimension Type Channel or Segment x period "
                    "end x locked snapshot",
                    "The certified numerators of channel and segment share, read as published (CW-011); Firm Value of a "
                    "Market Share Record must equal this row for the same period end and channel (DQ3). Client Assets "
                    "only: competitor and industry figures are never compared to Firm AUM.")

DP505 = dict(
    style="Star",
    entities=[
        ent("Fact Market Share", "Fact", [("11", "Market Share Record")], ["Market Share Record ID"], measures=True,
            grain="one row = market share record: share definition x period end x period type x category or segment x "
                  "channel x region x vehicle type, one version per industry data release (superseded kept)",
            note="The main output. Firm Value is the DP-008 certified number and Industry Value the licensed dataset "
                 "total, so the share is never recomputed from a firm-defined numerator. Holds the measures because "
                 "every tile is a share, a sizing or a count beside it. Category / Segment, Channel, Region / Market "
                 "and Vehicle Type are degenerate code values. PII tier: none (firm and industry aggregates)."),
        ent("Fact Industry Ranking", "Fact", [("11", "Industry Ranking")], ["Fact Market Share Key", "Ranked Firm"],
            grain="one row = market share record x ranked firm",
            note="Child of the market share record (registry fold=False). Model gap: the group carries no Market Share "
                 "Record ID, so it borrows the Fact Market Share Key. PII tier: none (firms only)."),
        dim("Fact Industry Flow Observation", ("DP-014", "Industry Flow Observation"),
            [("11", "Industry Flow Observation")], role="Fact",
            grain="one row = industry data release x category x channel x vehicle x region x distributor firm x fund "
                  "manager firm x fund or share class",
            note="Conformed from DP-014, the owner of the licensed observations: Industry Net Flow and Organic Growth "
                 "Rate are read as DP-014 publishes them, never recomputed, and the conformed entity supplies the full "
                 "observation key (Distributor Firm and Fund / Share Class are not product inputs). Industry Ending "
                 "Assets and Fund Category Market Share sum these rows, numerator and denominator from the same dataset. "
                 "PII tier: none."),
        dim("Industry Data Release", ("DP-014", "Industry Data Release"), [("11", "Industry Data Release")],
            pk=["Data Release ID"],
            note="Only the current release (Release Status) feeds the shares; Supersedes Release keeps the chain. Model "
                 "gap: the release carries no dataset reference in the inputs, so it borrows the Industry Dataset "
                 "Profile Key as DP-014 does. PII tier: none."),
        dim("Industry Dataset Profile", ("DP-014", "Industry Dataset Profile"),
            [("11", "Industry Dataset Profile"), ("11", "Redistribution Restriction")],
            note="Redistribution Restriction folds here (registry fold): whether a dataset's figures may be shown "
                 "outside the firm is a property of the licensed dataset. PII tier: none."),
        dim("Dataset", ("DP-014", "Dataset"),
            note="14 Dataset, the licensed dataset behind profiles, share denominators, sizing records and research "
                 "reports. PII tier: none."),
        dim("Market Share Definition", ("DP-014", "Market Share Definition"), [("11", "Market Share Definition")],
            note="Conformed from DP-014: Share Measure Basis, Numerator Source and Negative Flow Treatment decide how "
                 "each share row is read. PII tier: none."),
        dim("Category Mapping", ("DP-014", "Category Mapping"), [("11", "Category Mapping")],
            note="Resolves an external category value to the firm's share class at the As-of Date (Mapping Effective "
                 "From / To), so own funds are found in the category tables. PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("Peer Fund", ("DP-014", "Peer Fund"),
            note="The fund or share class named on an industry observation (REFS 11 Peer Fund). PII tier: none."),
        dim("Intermediary Firm", DFIRM,
            note="Conformed from DP-001: the distributor firm of an industry observation; firm level only, never "
                 "advisor level (CW-160, CW-245). PII tier: none."),
        dim("Competitor", COMP, [("11", "Competitor Profile")],
            note="Conformed from DP-481 (the competitor master the spec names); also the Fund Manager Firm and Ranked "
                 "Firm of the industry tables. PII tier: none."),
        dim("Party", PTY1,
            note="Conformed from DP-001: competitor parties and the partner firms of Opportunity Potential. PII tier: "
                 "identity (a partner firm can be a sole-practitioner RIA); only firm-level rows are published."),
        ent("Fact Competitor Metric Snapshot", "Fact", [("11", "Competitor Metric Snapshot")],
            ["Competitor Key", "As-of Date"], grain="one row = competitor x as-of date",
            note="Reported Client Assets, Net New Assets, Total AUM and account counts as each competitor reports them; "
                 "shown beside the DP-008 figures, never compared to Firm AUM. Model gap: the group carries no "
                 "Competitor Profile ID, so it borrows the Competitor Key. PII tier: none."),
        ent("Fact Competitor Footprint", "Fact", [("11", "Competitor Distribution Footprint")],
            ["Competitor Key", "Channel"], grain="one row = competitor x channel",
            note="Model gap: the group carries no Competitor Profile ID, so it borrows the Competitor Key. PII tier: none."),
        ent("Fact Competitor Event", "Fact", [("11", "Competitor Event")], ["Competitor Event ID"],
            grain="one row = competitor event", note="PII tier: none."),
        ent("Fact Competitor Personnel Move", "Fact", [("11", "Competitor Personnel Move")], ["Individual", "Move Date"],
            grain="one row = individual x move date",
            note="Counted by Move Type and competitor only: Individual is part of the key so moves are counted once, "
                 "and is never published (DQ5). PII tier: identity at row level; none at publication."),
        ent("Fact Market Sizing", "Fact", [("11", "Market Sizing Record")], ["Market Sizing Record ID"],
            grain="one row = market sizing record (subject type x metric x channel x wealth band x age band x mapped "
                  "segment x as-of date)",
            note="Addressable Market Size and the penetration denominator. PII tier: none (market aggregates)."),
        ent("Fact Opportunity Potential", "Fact", [("11", "Opportunity Potential")],
            ["Target Party", "Potential As-of Date"], grain="one row = partner firm x potential as-of date",
            note="Intermediary Firm White Space, firm level only (CW-160, CW-245). PII tier: identity (a partner firm "
                 "can be an individual); published at firm level only."),
        ent("Fact Market Research Report", "Fact", [("11", "Market Research Report")], ["Research Report ID"],
            grain="one row = market research report", note="Counted in Market Signals in Period. PII tier: none."),
        ent("Fact Market Trend", "Fact", [("11", "Market Trend")], ["Market Trend ID"],
            grain="one row = market trend indicator reading", note="PII tier: none."),
        ent("Fact Intelligence Item", "Fact", [("11", "Intelligence Item")], ["Intelligence Item ID"],
            grain="one row = intelligence item",
            note="Linked Competitors is multi-valued, drawn M:N to Competitor. PII tier: none."),
        _c505,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=[
        rel("Fact Market Share", "Market Share Definition", ["Share Definition"]),
        rel("Fact Market Share", "Calendar Date", ["Period End Date"]),
        rel("Fact Industry Ranking", "Fact Market Share", ["Fact Market Share Key"]),
        rel("Fact Industry Ranking", "Competitor", ["Ranked Firm"]),
        rel("Fact Industry Flow Observation", "Industry Data Release", ["Data Release"]),
        rel("Fact Industry Flow Observation", "Competitor", ["Fund Manager Firm"]),
        rel("Fact Industry Flow Observation", "Intermediary Firm", ["Distributor Firm"], optional=True),
        rel("Fact Industry Flow Observation", "Peer Fund", ["Fund / Share Class"], optional=True),
        rel("Fact Industry Flow Observation", "Category Mapping", ["Industry Category"], card="M:N", optional=True,
            note="Industry Category matched to External Category Value within the dataset's Category Scheme at the "
                 "release As-of Date; a code match, not a key."),
        rel("Industry Data Release", "Industry Dataset Profile", ["Industry Dataset Profile Key"]),
        rel("Industry Data Release", "Calendar Date", ["As-of Date"]),
        rel("Industry Dataset Profile", "Dataset", ["Licensed Dataset"]),
        rel("Market Share Definition", "Dataset", ["Denominator Dataset"], optional=True),
        rel("Category Mapping", "Share Class", ["Mapped Share Class"]),
        rel("Competitor", "Party", ["Competitor Party"], optional=True),
        rel("Fact Competitor Metric Snapshot", "Competitor", ["Competitor Key"]),
        rel("Fact Competitor Footprint", "Competitor", ["Competitor Key"]),
        rel("Fact Competitor Event", "Competitor", ["Competitor"]),
        rel("Fact Competitor Event", "Calendar Date", ["Event Date"]),
        rel("Fact Competitor Personnel Move", "Competitor", ["From Competitor"], optional=True),
        rel("Fact Competitor Personnel Move", "Competitor", ["To Competitor"], optional=True),
        rel("Fact Competitor Personnel Move", "Calendar Date", ["Move Date"]),
        rel("Fact Market Sizing", "Dataset", ["Source Dataset"]),
        rel("Fact Market Sizing", "Calendar Date", ["Sizing As-of Date"]),
        rel("Fact Opportunity Potential", "Party", ["Target Party"]),
        rel("Fact Opportunity Potential", "Calendar Date", ["Potential As-of Date"]),
        rel("Fact Market Research Report", "Dataset", ["Licensed Dataset"]),
        rel("Fact Market Trend", "Calendar Date", ["Indicator As-of Date"]),
        rel("Fact Intelligence Item", "Competitor", ["Linked Competitors"], card="M:N"),
        rel("Fact Intelligence Item", "Calendar Date", ["Publication Date"]),
    ] + _r505,
    notes="Market share star at the market share record, with the DP-014 industry observations, sizing records, "
          "competitor snapshots and signal counts as companion facts. Industry objects are conformed from DP-014 (the "
          "licensed-data owner) and competitors from DP-481; the firm numerators are the certified DP-008 Client Assets "
          "and NNA (CW-011), so the product owns no certified metric. Fact Industry Flow Observation is conformed from "
          "DP-014 because the product reads the row but not Distributor Firm and Fund / Share Class of its key. Model "
          "gaps (borrowed keys): Industry Ranking (Fact Market Share Key), Competitor Metric Snapshot and Competitor "
          "Distribution Footprint (Competitor Key), Industry Data Release (Industry Dataset Profile Key, as in DP-014)."
)

# ======================================================================================================================
# DP-487 Intermediary Payments, Sub-Accounting & Platform Fees
# ======================================================================================================================
DP487 = dict(
    style="Star",
    entities=[
        ent("Fact Payment Calculation", "Fact", [("05", "Payment Calculation")], ["Calculation ID"], measures=True,
            grain="one row = payment arrangement x calculation period (closed accrual periods locked, true-ups appended)",
            note="The main output: the calculated payment against the arrangement's terms, rate schedule and basis. "
                 "Basis Snapshot names the DP-008 snapshot the basis came from; DP-008 is not upstream, so it stays a "
                 "degenerate key. PII tier: none."),
        dim("Payment Arrangement", PAYARR, [("05", "Payment Arrangement"), ("05", "Sub-Accounting Fee Terms")],
            note="Conformed from DP-005 (the agreement master); Sub-Accounting Fee Terms folds here (registry fold), so "
                 "the per-account fee and the fund-paid sub-TA cap sit on the arrangement they govern. PII tier: none."),
        dim("Rate Schedule", ("DP-005", "Rate Schedule"), [("05", "Rate Schedule")],
            pk=["Payment Arrangement Key", "Rate Schedule Effective From"],
            note="Conformed from DP-005, keyed as there by the arrangement and the effective date. Model gap: no input "
                 "attribute names the arrangement, so it borrows the Payment Arrangement Key. PII tier: none."),
        ent("Rate Tier", "Dimension", [("05", "Rate Tier")], ["Rate Schedule Key", "Tier Sequence"],
            note="No foundational model publishes 05 Rate Tier. Model gap: the tier carries no rate schedule "
                 "reference, so it borrows the Rate Schedule Key. PII tier: none."),
        dim("Distribution Agreement", AGREE, note="Conformed from DP-005. PII tier: none."),
        ent("Fact Partner Invoice", "Fact", [("05", "Partner Invoice")], ["Partner Invoice Number"],
            grain="one row = partner invoice", note="PII tier: none (firm-to-firm invoices)."),
        ent("Fact Partner Payment", "Fact", [("05", "Partner Payment")], ["Partner Payment ID"],
            grain="one row = partner payment",
            note="Invoices Settled is multi-valued, drawn M:N to the invoices it settles. PII tier: none."),
        ent("Fact Communication Fee Invoice", "Fact", [("05", "Intermediary Communication Fee Invoice")],
            ["Fee Invoice ID"], grain="one row = intermediary communication fee invoice", note="PII tier: none."),
        dim("Partner Data Feed Arrangement", ("DP-005", "Partner Data Feed Arrangement"),
            [("05", "Partner Data Feed Arrangement")], role="Bridge",
            grain="one row = data feed x governing data agreement",
            note="Data Fees by Governed Feed: which agreement governs each partner feed. PII tier: none."),
        dim("Data Feed", ("DP-007", "Data Feed"), [("06", "Data Feed")], note="Conformed from DP-007. PII tier: none."),
        dim("Agreement Account Link", ("DP-005", "Agreement Account Link"), [("05", "Agreement Account Link")],
            pk=["Distribution Agreement Key", "Linked Account", "Account Link Role", "Account Link Effective From"],
            role="Bridge", grain="one row = agreement x linked account x link role x effective period",
            note="Conformed from DP-005: the omnibus and networked accounts an agreement bills (Sub-Accounts Billed vs "
                 "Look-Through). PII tier: identity (account keys)."),
        dim("Client Account", ACCT, [("15", "Intermediary Account Servicing")],
            note="Conformed from DP-093; Intermediary Account Servicing folds here (registry fold). PII tier: identity "
                 "(account keys); aggregated to partner firm at publication."),
        dim("Dealer of Record", DFIRM, note="Conformed from DP-001: the partner firm servicing the account. PII tier: none."),
        ent("Fact Distribution Cost Item", "Fact", [("10", "Distribution Cost Item")], ["Distribution Cost Item ID"],
            grain="one row = distribution cost item (cost counterparty x expense category x service period)",
            note="Fund-Borne and Firm-Borne Intermediary Cost. Source Record is a multi-type reference with no REFS "
                 "target, so it stays degenerate. PII tier: none."),
        ent("Fact Accrual", "Fact", [("10", "Accrual")], ["Accrual ID"], grain="one row = accrual of a cost item x period",
            note="Accrued Intermediary Cost and Accrual True-Up. PII tier: none."),
        ent("Fact Adviser-Borne Cost", "Fact", [("10", "Adviser-Borne Cost")],
            ["Related Payment Arrangement", "Adviser-Borne Cost Type"],
            grain="one row = payment arrangement x adviser-borne cost type",
            note="The sub-accounting excess above the fund-paid cap that the adviser bears. PII tier: none."),
        dim("Fact Distribution Revenue", ("DP-012", "Revenue Record"), [("10", "Distribution Revenue Record")],
            pk=["Fiscal Period Key", "Distribution Revenue Type", "Receiving Entity", "Paying Share Class"], role="Fact",
            grain="one row = paying share class x distribution revenue type x receiving entity x fiscal period",
            note="Conformed from DP-012, which certifies distribution revenue: the product reads Gross Distribution "
                 "Revenue and Amount Passed Through but not Receiving Entity, which the conformed entity supplies for "
                 "the key (Pass-Through Distribution Revenue %). Borrows the Fiscal Period Key as DP-012 does. PII "
                 "tier: none."),
        dim("Fiscal Period", ("DP-190", "Fiscal Period"), note="Conformed from DP-190. PII tier: none."),
        ent("Fact Fund Shareholder Position", "Fact", [("06", "Fund Shareholder Position"), ("06", "Omnibus Look-Through")],
            ["Position ID"], grain="one row = fund shareholder position x valuation date",
            note="Payment Basis Variance to Client Asset Positions and Sub-Accounts Billed vs Look-Through. The 06 "
                 "position is a view of the register for the payment basis, never a second source of client holdings "
                 "(CW-007); Omnibus Look-Through folds here. PII tier: financial at row level (account market value); "
                 "none at publication (partner-firm aggregates)."),
        dim("Party", PTY1, note="Conformed from DP-001: payers, payees, invoicing partners and cost counterparties. PII "
                                "tier: identity (a partner can be an individual); published at firm level."),
        dim("Legal Entity", LE13, note="Conformed from DP-013: the bearing legal entity. PII tier: none."),
        dim("Org Unit", ("DP-190", "Org Unit"),
            note="Conformed from DP-190 (09 Org Unit with Cost & Profit Center): the cost center a cost item is "
                 "booked to (REFS 09 Org Unit). PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=[
        rel("Fact Payment Calculation", "Payment Arrangement", ["Calculated Arrangement"]),
        rel("Fact Payment Calculation", "Calendar Date", ["Calculation Period End"]),
        rel("Payment Arrangement", "Distribution Agreement", ["Governing Agreement"]),
        rel("Payment Arrangement", "Party", ["Payer Entity"], optional=True),
        rel("Payment Arrangement", "Party", ["Payee Entity"], optional=True),
        rel("Rate Schedule", "Payment Arrangement", ["Payment Arrangement Key"]),
        rel("Rate Tier", "Rate Schedule", ["Rate Schedule Key"]),
        rel("Fact Partner Invoice", "Party", ["Invoicing Partner"]),
        rel("Fact Partner Payment", "Party", ["Charged Entity"]),
        rel("Fact Partner Payment", "Fact Partner Invoice", ["Invoices Settled"], card="M:N", optional=True),
        rel("Fact Partner Payment", "Calendar Date", ["Payment Date"]),
        rel("Fact Communication Fee Invoice", "Party", ["Invoicing Party"]),
        rel("Fact Communication Fee Invoice", "Distribution Agreement", ["Governing Agreement"], optional=True),
        rel("Partner Data Feed Arrangement", "Data Feed", ["Data Feed"]),
        rel("Partner Data Feed Arrangement", "Distribution Agreement", ["Governing Data Agreement"]),
        rel("Agreement Account Link", "Distribution Agreement", ["Distribution Agreement Key"]),
        rel("Agreement Account Link", "Client Account", ["Linked Account"]),
        rel("Client Account", "Dealer of Record", ["Dealer of Record"], optional=True),
        rel("Fact Distribution Cost Item", "Party", ["Cost Counterparty"], optional=True),
        rel("Fact Distribution Cost Item", "Legal Entity", ["Bearing Legal Entity"]),
        rel("Fact Distribution Cost Item", "Org Unit", ["Cost Center"], optional=True),
        rel("Fact Distribution Cost Item", "Share Class", ["Direct Product / Share Class"], optional=True),
        rel("Fact Distribution Cost Item", "Calendar Date", ["Service Period End"]),
        rel("Fact Accrual", "Fact Distribution Cost Item", ["Accrued Cost Item"]),
        rel("Fact Adviser-Borne Cost", "Payment Arrangement", ["Related Payment Arrangement"]),
        rel("Fact Distribution Revenue", "Fiscal Period", ["Fiscal Period Key"]),
        rel("Fact Distribution Revenue", "Share Class", ["Paying Share Class"]),
        rel("Fact Fund Shareholder Position", "Client Account", ["Account"]),
        rel("Fact Fund Shareholder Position", "Client Account", ["Omnibus Parent Account"], optional=True),
        rel("Fact Fund Shareholder Position", "Share Class", ["Share Class"]),
        rel("Fact Fund Shareholder Position", "Calendar Date", ["Valuation Date"]),
    ],
    notes="Payment star at the payment calculation, with partner invoices and payments, communication fee invoices, "
          "distribution cost items, accruals, adviser-borne costs and distribution revenue as companion facts. "
          "Arrangements, rate schedules, agreements, account links and data feed arrangements are conformed from DP-005 "
          "(master); the payment basis is checked against the 06 position view (CW-007), and distribution revenue is "
          "DP-012's certified row. Model gaps (borrowed keys): Rate Schedule (Payment Arrangement Key, as in DP-005), "
          "Rate Tier (Rate Schedule Key; 05 Rate Tier has no foundational model), Fact Distribution Revenue (Fiscal "
          "Period Key, as in DP-012). Basis Snapshot and Source Record stay degenerate (DP-008 is not upstream; Source "
          "Record has no single target)."
)

# ======================================================================================================================
# DP-486 Intermediary Oversight
# ======================================================================================================================
DP486 = dict(
    style="Star",
    entities=[
        ent("Fact Agreement Oversight", "Fact", [], ["Fact Agreement Oversight Key"], measures=True,
            grain="one row = partner firm x distribution agreement x as-of date (monthly snapshot)",
            note="The oversight row: due diligence currency, findings, obligations, amendments, contract and 22c-2 "
                 "coverage and payment disclosure for one agreement of one partner, each counted from its companion "
                 "fact. Model gap: no input object holds the partner x agreement x as-of row, so it takes a surrogate "
                 "key and borrows the agreement, partner firm and calendar keys. PII tier: identity (professional data, "
                 "CW-150): the partner firm can be a sole-practitioner RIA."),
        dim("Distribution Agreement", AGREE, [("05", "Distribution Agreement"), ("05", "Agreement Term")],
            note="Conformed from DP-005 (master); Agreement Term folds here (registry fold). Status history is SCD type 2 "
                 "in the source. PII tier: none."),
        dim("Contract", ("DP-213", "Contract"), [("39", "Contract")],
            note="Conformed from DP-213: Agreements Without Executed Contract. PII tier: none."),
        dim("Partner Firm", DFIRM,
            note="Conformed from DP-001. PII tier: identity (professional data, CW-150); no employee, advisor or "
                 "client attribute is published (DQ5)."),
        ent("Fact Due Diligence Review", "Fact", [("05", "Distributor Due Diligence")], ["Due Diligence ID"],
            grain="one row = due diligence review of a partner firm",
            note="Reviews by outcome, residual risk and evidence; Next Review Due Date drives Partners Overdue. PII tier: "
                 "identity (professional data, CW-150)."),
        ent("Fact Due Diligence Finding", "Fact", [("05", "Due Diligence Finding")], ["Due Diligence Finding Key"],
            grain="one row = due diligence finding (SCD type 2 on remediation status)",
            note="Model gap: the finding carries no review reference in the inputs, so it borrows the Fact Due "
                 "Diligence Review Key; findings age from the review completion date (spec taxonomy gap). PII tier: none."),
        ent("Fact Agreement Obligation", "Fact", [("05", "Agreement Obligation")], ["Obligation ID"],
            grain="one row = agreement obligation (SCD type 2 on compliance status)",
            note="Model gap: the obligation carries no agreement reference in the inputs, so it borrows the "
                 "Distribution Agreement Key. PII tier: none."),
        ent("Fact Agreement Amendment", "Fact", [("05", "Agreement Amendment")], ["Amendment ID"],
            grain="one row = agreement amendment",
            note="Model gap: the amendment carries no agreement reference in the inputs, so it borrows the "
                 "Distribution Agreement Key (DP-005 does the same). PII tier: none."),
        dim("Partner Dealer Setup", ("DP-005", "Partner Dealer Setup"),
            [("05", "Partner Dealer Setup"), ("05", "Networking Setup")],
            note="Conformed from DP-005; Networking Setup folds here (registry fold), so Rule 22c-2 coverage reads one "
                 "row per dealer set-up. PII tier: none."),
        ent("Fact Payment Disclosure", "Fact", [("05", "Payment Disclosure")],
            ["Disclosing Party", "Disclosure Type", "Disclosure Publication Date"],
            grain="one row = disclosing party x disclosure type x publication date",
            note="Disclosed Arrangements is multi-valued, drawn M:N to Payment Arrangement (matched by reference value, "
                 "spec taxonomy gap). PII tier: identity (professional data, CW-150)."),
        dim("Payment Arrangement", PAYARR, [("05", "Payment Arrangement")],
            note="Conformed from DP-005: Prospectus Disclosure Indicator drives Undisclosed Payments. PII tier: none."),
        dim("Agreement Account Link", ("DP-005", "Agreement Account Link"), [("05", "Agreement Account Link")],
            pk=["Distribution Agreement Key", "Linked Account", "Account Link Role", "Account Link Effective From"],
            role="Bridge", grain="one row = agreement x linked account x link role x effective period",
            note="Conformed from DP-005: Linked Accounts Without Active Agreement. PII tier: identity (account keys); "
                 "counts only at publication."),
        dim("Client Account", ACCT, [("15", "Account")],
            note="Conformed from DP-093. PII tier: identity (account keys); never published at row level."),
        ent("Fact Partner Payment", "Fact", [("05", "Partner Payment")], ["Partner Payment ID"],
            grain="one row = partner payment",
            note="Payments Made, read as DP-487 publishes them. PII tier: none."),
        dim("Party", PTY1, note="Conformed from DP-001: charged entities and covered service providers. PII tier: "
                                "identity (professional data, CW-150)."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=[
        rel("Fact Agreement Oversight", "Distribution Agreement", ["Distribution Agreement Key"]),
        rel("Fact Agreement Oversight", "Partner Firm", ["Partner Firm Key"]),
        rel("Fact Agreement Oversight", "Calendar Date", ["Calendar Date Key"], note="The month-end as-of date."),
        rel("Distribution Agreement", "Fact Due Diligence Review", ["Distributor Due Diligence Reference"], optional=True),
        rel("Distribution Agreement", "Contract", ["Executed Contract"], optional=True),
        rel("Fact Due Diligence Review", "Partner Firm", ["Distributor Firm"]),
        rel("Fact Due Diligence Review", "Calendar Date", ["Due Diligence Completed Date"], optional=True),
        rel("Fact Due Diligence Finding", "Fact Due Diligence Review", ["Fact Due Diligence Review Key"]),
        rel("Fact Agreement Obligation", "Distribution Agreement", ["Distribution Agreement Key"]),
        rel("Fact Agreement Amendment", "Distribution Agreement", ["Distribution Agreement Key"]),
        rel("Fact Agreement Amendment", "Calendar Date", ["Amendment Effective Date"]),
        rel("Partner Dealer Setup", "Partner Firm", ["Dealer Setup Partner"]),
        rel("Fact Payment Disclosure", "Partner Firm", ["Disclosing Party"]),
        rel("Fact Payment Disclosure", "Payment Arrangement", ["Disclosed Arrangements"], card="M:N", optional=True),
        rel("Fact Payment Disclosure", "Party", ["Covered Service Provider"], optional=True),
        rel("Fact Payment Disclosure", "Calendar Date", ["Disclosure Publication Date"]),
        rel("Payment Arrangement", "Distribution Agreement", ["Governing Agreement"]),
        rel("Agreement Account Link", "Distribution Agreement", ["Distribution Agreement Key"]),
        rel("Agreement Account Link", "Client Account", ["Linked Account"]),
        rel("Fact Partner Payment", "Party", ["Charged Entity"]),
        rel("Fact Partner Payment", "Calendar Date", ["Payment Date"]),
    ],
    notes="Oversight star at partner x agreement x as-of date, with due diligence reviews and findings, obligations, "
          "amendments, dealer set-ups, disclosures and payments as companion facts. Agreements, arrangements, dealer "
          "set-ups and account links are conformed from DP-005 (master), partners from DP-001, contracts from DP-213 "
          "and accounts from DP-093; payments are read as DP-487 publishes them. Model gaps: Fact Agreement Oversight "
          "has no backing object (surrogate key, borrowed agreement, partner and calendar keys); Due Diligence Finding "
          "(Fact Due Diligence Review Key), Agreement Obligation and Agreement Amendment (Distribution Agreement Key) "
          "borrow their parent's key because the inputs carry no reference to it."
)

# ======================================================================================================================
# DP-488 Institutional & Plan Sponsor Pipeline
# ======================================================================================================================
DP488 = dict(
    style="Star",
    entities=[
        ent("Fact Sales Opportunity", "Fact",
            [("05", "Sales Opportunity"), ("05", "Pipeline Status"), ("05", "Opportunity Value"),
             ("05", "Placement & Plan Detail"), ("05", "Win / Loss")],
            ["Opportunity ID"], measures=True,
            grain="one row = sales opportunity (OPP-) x weekly as-of snapshot (stage history SCD type 2)",
            note="The main output; Pipeline Status, Opportunity Value, Placement & Plan Detail and Win / Loss fold here "
                 "(registry fold). The weekly as-of date is the snapshot load, not an attribute. Proposed Offering or "
                 "Strategy and Originating Campaign stay degenerate (no single REFS target; the campaign master is not "
                 "upstream). PII tier: identity (opportunity owners are employees; some prospects and plan fiduciaries "
                 "are individuals)."),
        ent("Fact RFP", "Fact", [("05", "RFP Request"), ("05", "RFP Submission")], ["RFP ID"],
            grain="one row = RFP request with its submission",
            note="RFP Submission folds here (registry fold). Final Compliance Approval (08) stays a degenerate key. PII "
                 "tier: none."),
        ent("Fact Consultant Rating", "Fact", [("05", "Consultant Rating")],
            ["Rating Provider", "Rated Strategy / Product", "Rating Type", "Rating Date"],
            grain="one row = consultant x rated strategy or product x rating type x rating date",
            note="Consultant Ratings Downgraded compares consecutive ratings. PII tier: none."),
        ent("Database Profile", "Dimension", [("05", "Database Profile")], ["Database Profile ID"],
            note="No foundational model publishes the manager database profile. PII tier: none."),
        ent("Fact Database Submission", "Fact", [("05", "Database Submission")],
            ["Database Profile Key", "Submission Period End"],
            grain="one row = database profile x submission period end",
            note="Model gap: the group carries no Database Profile ID, so it borrows the Database Profile Key. PII tier: none."),
        ent("Fact Plan Market Record", "Fact", [("11", "Plan Market Record")], ["Plan Party", "Form 5500 Plan Year"],
            grain="one row = retirement plan x Form 5500 plan year",
            note="Plan Recordkeeping White Space. PII tier: none (plan-level public filings)."),
        ent("Fact Win/Loss Analysis", "Fact", [("11", "Win/Loss Analysis")], ["Analysis Segment", "Analysis Period End"],
            grain="one row = analysis segment x analysis period end", note="PII tier: none."),
        ent("Fact Mandate Search Event", "Fact", [("11", "Mandate Search Event")], ["Search Event ID"],
            grain="one row = mandate search event", note="Searches in Market. PII tier: none."),
        ent("Fact Mandate Onboarding", "Fact", [("12", "Mandate Onboarding")], ["Fact Mandate Onboarding Key"],
            grain="one row = mandate onboarding of a won opportunity",
            note="Won Opportunities Funded %. Model gap: the registry key (Onboarded Mandate, Onboarding Start Date) is "
                 "not in the inputs, so the row takes a surrogate key. PII tier: none."),
        dim("Client Party", PTY240,
            note="Conformed from DP-240: prospects and clients stay 02 parties (PTY-), as do RFP issuers, asset owners "
                 "and plan market recordkeepers. PII tier: identity (some prospects are individuals); aggregated at "
                 "publication."),
        dim("Employee", EMP192,
            note="Conformed from DP-192 (DP-009 is not upstream): the opportunity owner. PII tier: identity (employee); "
                 "personal-detail columns of the master are not served by this product."),
        dim("Consultant Profile", ("DP-003", "Consultant Profile"), note="Conformed from DP-003. PII tier: none."),
        dim("Platform / Sponsor Firm", DFIRM, note="Conformed from DP-001: the target platform of a placement. PII tier: none."),
        dim("Retirement Plan", ("DP-094", "Retirement Plan"),
            note="Conformed from DP-094: the 02 Retirement Plan party (a plan is a PTY- party, CW-021). PII tier: none."),
        dim("Recordkeeper Profile", ("DP-003", "Recordkeeper Profile"), [("16", "Recordkeeper Profile")],
            note="Conformed from DP-003. PII tier: none."),
        dim("Competitor", COMP, note="Conformed from DP-481: winning competitors and hired managers. PII tier: none."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=[
        rel("Fact Sales Opportunity", "Client Party", ["Prospect / Client"]),
        rel("Fact Sales Opportunity", "Employee", ["Opportunity Owner"]),
        rel("Fact Sales Opportunity", "Consultant Profile", ["Search Consultant"], optional=True),
        rel("Fact Sales Opportunity", "Platform / Sponsor Firm", ["Target Platform / Sponsor"], optional=True),
        rel("Fact Sales Opportunity", "Retirement Plan", ["Retirement Plan"], optional=True),
        rel("Fact Sales Opportunity", "Recordkeeper Profile", ["Plan Recordkeeper"], optional=True),
        rel("Fact Sales Opportunity", "Competitor", ["Winning Competitor"], optional=True),
        rel("Fact Sales Opportunity", "Calendar Date", ["Expected Close Date"]),
        rel("Fact RFP", "Fact Sales Opportunity", ["Related Opportunity"], optional=True),
        rel("Fact RFP", "Client Party", ["Issuing Party"]),
        rel("Fact Consultant Rating", "Consultant Profile", ["Rating Provider"]),
        rel("Fact Consultant Rating", "Calendar Date", ["Rating Date"]),
        rel("Fact Database Submission", "Database Profile", ["Database Profile Key"]),
        rel("Fact Database Submission", "Calendar Date", ["Submission Period End"]),
        rel("Fact Plan Market Record", "Retirement Plan", ["Plan Party"]),
        rel("Fact Plan Market Record", "Client Party", ["Recordkeeper"], optional=True),
        rel("Fact Win/Loss Analysis", "Competitor", ["Most Frequent Winning Competitor"], optional=True),
        rel("Fact Win/Loss Analysis", "Calendar Date", ["Analysis Period End"]),
        rel("Fact Mandate Search Event", "Client Party", ["Asset Owner"]),
        rel("Fact Mandate Search Event", "Consultant Profile", ["Consultant"], optional=True),
        rel("Fact Mandate Search Event", "Competitor", ["Winning / Hired Manager"], optional=True),
        rel("Fact Mandate Search Event", "Fact Sales Opportunity", ["Linked Opportunity"], optional=True),
        rel("Fact Mandate Search Event", "Calendar Date", ["Event Date"]),
        rel("Fact Mandate Onboarding", "Fact Sales Opportunity", ["Won Opportunity"]),
    ],
    notes="Pipeline star at the sales opportunity, with RFPs, consultant ratings, database submissions, plan market "
          "records, win/loss analyses, search events and onboardings as companion facts. Prospects and clients are "
          "DP-240 parties, owners DP-192 employees, consultants and recordkeepers DP-003 profiles, plans the DP-094 "
          "Retirement Plan, platforms DP-001 firms and competitors DP-481. Model gaps: Database Submission borrows the "
          "Database Profile Key; Mandate Onboarding takes a surrogate key (its registry key is not in the inputs)."
)

# ======================================================================================================================
# DP-491 Net New Assets by Channel, Offering & Advisor
# ======================================================================================================================
_c491, _r491 = cert("Fact Net New Assets", [MV, CAM],
                    "one row = DP-008 measure value: measure x period end x dimension type x dimension key x data basis x "
                    "locked snapshot",
                    "The certified NNA at every DP-008 dimension (channel, business line, advisor of record, holding "
                    "type, share class, segment) read as published (CW-142, CW-242); attribution slices it and adds no "
                    "flow treatment or weight. Holds the measures because every tile reconciles to these rows.",
                    measures=True, period=True)

DP491 = dict(
    style="Star",
    entities=[
        _c491,
        ent("Fact Flow Transaction", "Fact",
            [("06", "Transaction"), ("06", "Transaction Dates"), ("06", "Transaction Amounts"),
             ("06", "Transaction Status"), ("06", "Order Source")],
            ["Transaction ID"],
            grain="one row = client flow transaction",
            note="The offering and flow-type cross-tab (period x channel x service offering x transaction type) sums "
                 "these rows through their attribution; dates, amounts, status and order source fold here (registry "
                 "fold). Flow Source Book and Source Client Account Activity trace the flow to the 49 book of record "
                 "(CW-007). PII tier: financial at row level (account flows); aggregated at publication."),
        ent("Fact Linked Transaction", "Fact", [("06", "Linked Transaction")],
            ["Fact Flow Transaction Key", "Fact Linked Transaction Key"],
            grain="one row = transaction x linked transaction",
            note="Same-Owner Transfers Excluded and Net Inter-Channel Transfers by Channel. Model gap: neither the "
                 "transaction key nor Linked Transaction ID is in the inputs, so the row borrows the Fact Flow "
                 "Transaction Key and takes a surrogate discriminator. PII tier: none."),
        ent("Fact Attribution Record", "Fact",
            [("06", "Attribution Record"), ("06", "Market & Client Dimensions"), ("06", "Attribution Method")],
            ["Attribution Record ID"],
            grain="one row = attribution record (transaction x attributed channel, offering, advisor and household)",
            note="Market & Client Dimensions and Attribution Method fold here (registry fold). Client Household is the "
                 "attributed household of the record, used only to roll up client segments; household rows are never "
                 "published (DQ5). PII tier: identity (advisor and household keys); aggregated at publication."),
        ent("Salesperson Credit", "Bridge", [("06", "Salesperson Credit")],
            ["Fact Attribution Record Key", "Credited Salesperson", "Credit Role"],
            grain="one row = attribution record x credited salesperson x credit role",
            note="Salesperson-Credited NNA: credit splits are many-to-many between attribution rows and salespeople. "
                 "Model gap: the group carries no Attribution Record ID, so it borrows the Fact Attribution Record Key. "
                 "PII tier: identity (employee salesperson keys with their credited flows)."),
        dim("Coverage Assignment", ("DP-009", "Coverage Assignment"), [("03", "Party Coverage Assignment")],
            note="Conformed from DP-009: NNA Moved by Coverage Changes compares effective-dated assignments. PII tier: "
                 "identity (advisor and covered party keys)."),
        dim("Advisor", EMP9, [("03", "Advisor")],
            note="Conformed from DP-009 Employee (03 Advisor folds there): advisor of record and credited salesperson. "
                 "PII tier: identity (employee advisor keys with their performance)."),
        dim("Partner Coverage Assignment", ("DP-001", "Partner Coverage Assignment"),
            [("05", "Partner Coverage Assignment")], note="Conformed from DP-001. PII tier: identity (professional data)."),
        dim("Client Account Activity", ("DP-300", "Client Account Activity"), [("49", "Client Account Activity")],
            note="Conformed from DP-300, the 49 book of record a flow is sourced from (CW-007). PII tier: financial."),
        dim("Money Movement", ("DP-302", "Money Movement"), [("50", "Money Movement")],
            note="Conformed from DP-302: Rollover Flows by Source reads the money movement type and rail. PII tier: "
                 "financial."),
        dim("Program Enrollment", ("DP-093", "Program Enrollment"), [("15", "Program Enrollment")], role="Bridge",
            grain="one row = account x enrolled service offering x enrollment period",
            note="Conformed from DP-093: NNA by Offering and Program places an account's flows in the program it was "
                 "enrolled in on the trade date. PII tier: identity (account keys)."),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: identity (account keys)."),
        dim("Client Party", PTY240,
            note="Conformed from DP-240: covered parties and attributed households (a household is a Party of Party "
                 "Type Household). PII tier: identity; never published at row level."),
        dim("Service Offering", OFFER, note="Conformed from DP-004. PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, [("06", "Flow Treatment Rule")],
            note="Conformed from DP-008; Flow Treatment Rule folds into the definition (registry fold): transfer, "
                 "inter-channel and rollover treatment are read, never re-decided here. PII tier: none."),
        dim("Reporting Period", RPER, note="Conformed from DP-008. PII tier: none."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r491 + [
        rel("Fact Flow Transaction", "Client Account", ["Account"]),
        rel("Fact Flow Transaction", "Share Class", ["Share Class"], optional=True),
        rel("Fact Flow Transaction", "Client Account Activity", ["Source Client Account Activity"], optional=True),
        rel("Fact Flow Transaction", "Calendar Date", ["Trade Date"]),
        rel("Fact Linked Transaction", "Fact Flow Transaction", ["Fact Flow Transaction Key"]),
        rel("Fact Attribution Record", "Fact Flow Transaction", ["Source Transaction"], optional=True),
        rel("Fact Attribution Record", "Service Offering", ["Service Offering"], optional=True),
        rel("Fact Attribution Record", "Advisor", ["Covering Advisor"], optional=True),
        rel("Fact Attribution Record", "Coverage Assignment", ["Advisor Coverage Assignment"], optional=True),
        rel("Fact Attribution Record", "Client Party", ["Client Household"], optional=True),
        rel("Fact Attribution Record", "Calendar Date", ["Attribution Effective Date"]),
        rel("Salesperson Credit", "Fact Attribution Record", ["Fact Attribution Record Key"]),
        rel("Salesperson Credit", "Advisor", ["Credited Salesperson"]),
        rel("Salesperson Credit", "Partner Coverage Assignment", ["Source Partner Coverage Assignment"], optional=True),
        rel("Coverage Assignment", "Advisor", ["Covering Advisor"]),
        rel("Coverage Assignment", "Client Party", ["Covered Party"]),
        rel("Client Account Activity", "Money Movement", ["Source Money Movement"], optional=True),
        rel("Program Enrollment", "Client Account", ["Enrolled Account"]),
        rel("Program Enrollment", "Service Offering", ["Enrolled Service Offering"]),
    ],
    notes="NNA attribution star: the certified DP-008 NNA rows are the main fact; the offering and flow-type cross-tab "
          "and the advisor rows are built from the DP-006 transactions and attribution records they slice, which add "
          "no flow treatment or weight (CW-142, CW-242). Advisors and coverage are DP-009's, accounts and program "
          "enrollments DP-093's, households DP-240 parties, the 49 activity DP-300's and money movements DP-302's. "
          "Model gaps: Linked Transaction (borrowed Fact Flow Transaction Key plus a surrogate discriminator) and "
          "Salesperson Credit (borrowed Fact Attribution Record Key)."
)

# ======================================================================================================================
# DP-492 Net New Assets by Campaign & Acquisition Cohort
# ======================================================================================================================
_c492, _r492 = cert("Fact Campaign Net New Assets", [MV, CAM],
                    "one row = DP-008 NNA at Dimension Type Campaign (or the firm total) x period end x locked snapshot",
                    "NNA by Campaign read as published (CW-242): the campaign slice is DP-008's, weighted by the 04 "
                    "attribution copied onto the attribution record, never re-weighted here.", measures=True)

DP492 = dict(
    style="Star",
    entities=[
        _c492,
        ent("Fact Attribution Record", "Fact", [("06", "Attribution Record"), ("06", "Market & Client Dimensions")],
            ["Attribution Record ID"], grain="one row = attribution record with its attributed campaign and weight",
            note="Campaign Weight Copy Breaks compares Campaign Attribution Weight with the 04 Attribution Weight of the "
                 "Source Attributed Outcome. PII tier: none at publication."),
        ent("Fact Flow Transaction", "Fact", [("06", "Transaction"), ("06", "Transaction Dates")], ["Transaction ID"],
            grain="one row = client flow transaction",
            note="Cohort NNA Since Funding sums flows of cohort accounts by trade date. PII tier: financial at row level; "
                 "aggregated over households at publication."),
        dim("Fact Account Asset Summary", ("DP-008", "Account Asset Summary"), [("06", "Account Asset Summary")],
            role="Fact", grain="one row = account x as-of date x holding type",
            note="Conformed from DP-008 because the product reads the account's market value but not Summary Holding "
                 "Type of the key. Cohort asset retention reads it for cohort accounts; Cohort Client Assets are the "
                 "DP-320 published numbers. PII tier: financial at row level; aggregated at publication."),
        ent("Fact Attributed Outcome", "Fact", [("04", "Attributed Outcome")],
            ["Attributed Milestone", "Attributed Campaign", "Applied Attribution Model"],
            grain="one row = acquisition milestone x campaign x attribution model",
            note="Attribution Model Sensitivity compares the primary model with the others. PII tier: none."),
        ent("Attribution Model", "Dimension", [("04", "Attribution Model")], ["Attribution Model Key"],
            note="No foundational model publishes 04 Attribution Model; the registry key is a surrogate. PII tier: none."),
        ent("Fact Acquisition Milestone", "Fact", [("04", "Acquisition Milestone")],
            ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"],
            grain="one row = party x milestone type x milestone date x account",
            note="The funding milestone sets a household's acquisition cohort month. PII tier: identity at row level; "
                 "aggregated over households (cohort and campaign) at publication."),
        dim("Campaign", CAMP, [("04", "Campaign")],
            note="Conformed from DP-011 (marketing master); Parent Campaign rolls programs up. PII tier: none."),
        ent("Fact Marketing Touchpoint", "Fact", [("04", "Marketing Touchpoint")],
            ["Touchpoint Party", "Touchpoint Timestamp", "Touchpoint Type"],
            grain="one row = party x touchpoint timestamp x touchpoint type",
            note="Touchpoints per Funded Household. PII tier: identity at row level; aggregated at publication."),
        dim("Household Membership", HHM, [("02", "Household Membership")], role="Bridge",
            grain="one row = household x member party x effective period",
            note="Conformed from DP-240: the member-to-household path (effective dated), so households are counted once "
                 "however many members fund. PII tier: identity."),
        dim("Account Party Role", APR, [("15", "Account Party Role")], role="Bridge",
            grain="one row = account x party x account role type x effective period",
            note="Conformed from DP-093: the account-to-party path; with Household Membership it is the only "
                 "account-to-household path (never a column on the account). PII tier: identity."),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: identity (account keys)."),
        dim("Client Party", PTY240, note="Conformed from DP-240: milestone, touchpoint and member parties. PII tier: identity."),
        dim("Household", PTY240,
            note="Conformed from DP-240: the household is a Party of Party Type Household (PTY-HH-). PII tier: identity; "
                 "aggregated at publication."),
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r492 + [
        rel("Fact Attribution Record", "Campaign", ["Attributed Campaign"], optional=True),
        rel("Fact Attribution Record", "Fact Attributed Outcome", ["Source Attributed Outcome"], optional=True),
        rel("Fact Attribution Record", "Fact Flow Transaction", ["Source Transaction"], optional=True),
        rel("Fact Flow Transaction", "Client Account", ["Account"]),
        rel("Fact Flow Transaction", "Calendar Date", ["Trade Date"]),
        rel("Fact Account Asset Summary", "Client Account", ["Summary Account"]),
        rel("Fact Account Asset Summary", "Calendar Date", ["Summary As-Of Date"]),
        rel("Fact Attributed Outcome", "Fact Acquisition Milestone", ["Attributed Milestone"]),
        rel("Fact Attributed Outcome", "Campaign", ["Attributed Campaign"]),
        rel("Fact Attributed Outcome", "Attribution Model", ["Applied Attribution Model"]),
        rel("Fact Acquisition Milestone", "Client Party", ["Milestone Party"]),
        rel("Fact Acquisition Milestone", "Client Account", ["Milestone Account"], optional=True),
        rel("Fact Acquisition Milestone", "Calendar Date", ["Milestone Date"]),
        rel("Fact Marketing Touchpoint", "Client Party", ["Touchpoint Party"]),
        rel("Fact Marketing Touchpoint", "Campaign", ["Touchpoint Campaign"], optional=True),
        rel("Household Membership", "Household", ["Household"]),
        rel("Household Membership", "Client Party", ["Household Member"]),
        rel("Account Party Role", "Client Account", ["Role Account"]),
        rel("Account Party Role", "Client Party", ["Role Party"]),
    ],
    notes="Campaign and cohort star: the certified DP-008 NNA by campaign is the main fact; the cohort facts (milestones, "
          "touchpoints, flows and account summaries) are aggregated over households, reached from the account only "
          "through the DP-093 Account Party Role and DP-240 Household Membership bridges. Campaigns are DP-011's. "
          "Fact Account Asset Summary is conformed from DP-008 for its key. No surrogate keys beyond the registry's "
          "(04 Attribution Model)."
)

# ======================================================================================================================
# DP-493 Intermediary Channel Flows
# ======================================================================================================================
_c493, _r493 = cert("Fact Intermediary Certified Value", [MV, CAM, ("06", "Flow Measures"), ("06", "Asset Measures")],
                    "one row = DP-008 measure value at Dimension Type Channel (intermediary sub-channels) x period end x "
                    "locked snapshot",
                    "Intermediary Client Assets, NNA, organic growth, own-fund sales, redemptions and own-fund assets by "
                    "channel, read as published (CW-011); Flow Measures and Asset Measures fold here (registry fold). "
                    "Asset Measures are DP-008's own-fund asset reads, kept in their own columns and never added to "
                    "Ending Client Assets.")

DP493 = dict(
    style="Star",
    entities=[
        ent("Fact Intermediary Flow", "Fact",
            [("06", "Transaction"), ("06", "Transaction Dates"), ("06", "Transaction Amounts"),
             ("06", "Transaction Status"), ("06", "Intermediary As Delivered"), ("06", "ETF Creation / Redemption"),
             ("06", "SMA Flow")],
            ["Transaction ID"], measures=True,
            grain="one row = intermediary flow transaction, aggregated to partner firm x vehicle type x period (daily "
                  "flows, monthly output)",
            note="The main output sums these rows by Resolved Distributor Firm and the product's Vehicle Type; the "
                 "as-delivered intermediary, ETF creation and SMA flow groups fold here (registry fold). Unresolved "
                 "Intermediary Flows are rows with no resolved firm. PII tier: none at publication (firm-level flows)."),
        ent("Fact Intermediary Position", "Fact",
            [("06", "Fund Shareholder Position"), ("06", "Omnibus Look-Through"), ("06", "ETF Holding"),
             ("06", "Plan Position"), ("06", "Sponsor-Reported Assets")],
            ["Position ID"], grain="one row = intermediary-held fund shareholder position x valuation date",
            note="Intermediary-held own-fund assets, ETF holdings by broker, third-party recordkept plan positions and "
                 "sponsor program assets; the groups fold here (registry fold). The 06 position is a view of the "
                 "register, never a second source of client holdings (CW-007), and no 49 or 18 holding is joined to it. "
                 "Plan Position and Sponsor-Reported Assets take the parent's Market Value (spec taxonomy gap). PII "
                 "tier: none at publication (omnibus and firm-level positions)."),
        ent("Fact Attribution Record", "Fact",
            [("06", "Attribution Record"), ("06", "Distributor Hierarchy"), ("06", "Market & Client Dimensions")],
            ["Attribution Record ID"], grain="one row = attribution record of an intermediary flow or position",
            note="Distributor Hierarchy and Market & Client Dimensions fold here (registry fold): the partner firm and "
                 "branch a flow or position is attributed to. PII tier: none."),
        ent("Fact Model Delivery Event", "Fact", [("05", "Model Delivery Event")], ["Model Delivery Event ID"],
            grain="one row = model delivery event", note="Model Deliveries Acknowledged On Time %. PII tier: none."),
        dim("Model Program Placement", ("DP-005", "Model Program Placement"), [("05", "Model Program Placement")],
            pk=["Sponsor Program Agreement", "Placed Model Portfolio", "Model Placement Effective From"], role="Bridge",
            grain="one row = sponsor program agreement x model portfolio x placement effective period",
            note="Conformed from DP-005, keyed by the registry key (the sponsor program agreement, not DP-005's Partner "
                 "Program placeholder). Model Placements Producing Assets %. PII tier: none."),
        dim("Investment Product", PROD, [("01", "Investment Product")],
            note="Conformed from DP-004: Vehicle Type of the main grain. PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("Model Portfolio", MODELP, note="Conformed from DP-004. PII tier: none."),
        dim("Partner Firm", DFIRM, note="Conformed from DP-001: resolved distributor firms and sponsors. PII tier: none."),
        dim("Branch / Office", ("DP-001", "Branch / Office"), note="Conformed from DP-001. PII tier: none."),
        dim("Party", PTY1, note="Conformed from DP-001: authorized participants and holding custodians or brokers. PII "
                                "tier: none (firms)."),
        dim("Distribution Agreement", AGREE, note="Conformed from DP-005: sponsor program agreements. PII tier: none."),
        dim("Retirement Plan", ("DP-003", "Party"),
            note="Conformed from DP-003 Party, which holds the 02 Retirement Plan (a plan is a PTY- party). PII tier: none."),
        dim("Recordkeeper Profile", ("DP-003", "Recordkeeper Profile"), note="Conformed from DP-003. PII tier: none."),
        dim("Client Account", ("DP-007", "Account"),
            note="Conformed from DP-007 (DP-093 is not upstream): omnibus and networked accounts. PII tier: identity "
                 "(account keys); omnibus accounts only at publication."),
        _c493,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r493 + [
        rel("Fact Intermediary Flow", "Share Class", ["Share Class"], optional=True),
        rel("Fact Intermediary Flow", "Investment Product", ["Product"]),
        rel("Fact Intermediary Flow", "Partner Firm", ["Resolved Distributor Firm"], optional=True),
        rel("Fact Intermediary Flow", "Branch / Office", ["Resolved Office / Branch"], optional=True),
        rel("Fact Intermediary Flow", "Party", ["Authorized Participant"], optional=True),
        rel("Fact Intermediary Flow", "Distribution Agreement", ["Sponsor Program"], optional=True),
        rel("Fact Intermediary Flow", "Model Portfolio", ["Model Portfolio"], optional=True),
        rel("Fact Intermediary Flow", "Calendar Date", ["Trade Date"]),
        rel("Fact Intermediary Position", "Client Account", ["Account"]),
        rel("Fact Intermediary Position", "Client Account", ["Omnibus Parent Account"], optional=True),
        rel("Fact Intermediary Position", "Share Class", ["Share Class"]),
        rel("Fact Intermediary Position", "Party", ["Holding Custodian / Broker"], optional=True),
        rel("Fact Intermediary Position", "Retirement Plan", ["Retirement Plan"], optional=True),
        rel("Fact Intermediary Position", "Recordkeeper Profile", ["Recordkeeper"], optional=True),
        rel("Fact Intermediary Position", "Partner Firm", ["Sponsor"], optional=True),
        rel("Fact Intermediary Position", "Calendar Date", ["Valuation Date"]),
        rel("Fact Attribution Record", "Fact Intermediary Flow", ["Source Transaction"], optional=True),
        rel("Fact Attribution Record", "Fact Intermediary Position", ["Source Position"], optional=True),
        rel("Fact Attribution Record", "Partner Firm", ["Distributor Firm"], optional=True),
        rel("Fact Attribution Record", "Branch / Office", ["Distributor Office / Branch"], optional=True),
        rel("Fact Model Delivery Event", "Model Portfolio", ["Delivered Model Portfolio"]),
        rel("Fact Model Delivery Event", "Distribution Agreement", ["Delivery Program Agreement"]),
        rel("Model Program Placement", "Distribution Agreement", ["Sponsor Program Agreement"]),
        rel("Model Program Placement", "Model Portfolio", ["Placed Model Portfolio"]),
        rel("Share Class", "Investment Product", ["Parent Product"]),
    ],
    notes="Intermediary flow star at partner firm x vehicle x period over the DP-006 transactions, with the certified "
          "DP-008 sub-channel values, the DP-007 intermediary positions (06 view, CW-007), attribution, model "
          "deliveries and placements as companion facts. The thin intermediary channel (CW-245) is read at firm and "
          "branch level only. Partners are DP-001's, agreements and placements DP-005's, plans and recordkeepers "
          "DP-003's, products DP-004's. No model gaps."
)

# ======================================================================================================================
# DP-495 Client Asset Data Supply Chain, Reconciliation & Suspense
# ======================================================================================================================
_c495, _r495 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Ending Client Assets x period end x locked snapshot",
                    "The denominator of Suspense Share of Client Assets, read as published (CW-011).")

DP495 = dict(
    style="Star",
    entities=[
        ent("Fact Load", "Fact", [("06", "Load")], ["Load ID"], measures=True,
            grain="one row = data feed x business date load",
            note="Load health is the first main output; holds the measures because every supply-chain tile starts at a "
                 "load (on time judged against Delivery Frequency, spec taxonomy gap). PII tier: none."),
        dim("Data Feed", ("DP-007", "Data Feed"), [("06", "Data Feed")],
            note="Conformed from DP-007. PII tier: none."),
        dim("Reconciliation", ("DP-007", "Reconciliation"), [("06", "Reconciliation")],
            note="Conformed from DP-007: the left and right sources, compared measure and tolerances. PII tier: none."),
        ent("Fact Reconciliation Run", "Fact", [("06", "Reconciliation Run")], ["Reconciliation Key", "Run Business Date"],
            grain="one row = reconciliation x run business date",
            note="Reconciliation health, the second main output. Model gap: the group carries no Reconciliation ID, so "
                 "it borrows the Reconciliation Key. PII tier: none."),
        ent("Fact Break", "Fact", [("06", "Break")], ["Break ID"], grain="one row = reconciliation break",
            note="Age is read from Break Age (Days) (spec taxonomy gap). Model gap: the break carries no run reference "
                 "in the inputs, so it borrows the Fact Reconciliation Run Key. PII tier: none."),
        ent("Fact Unattributed Item", "Fact", [("06", "Unattributed Item")], ["Unattributed Item ID"],
            grain="one row = unattributed (suspense) item",
            note="Unattributed Suspense Amount, aging and write-offs to house. PII tier: identity in the steward "
                 "drill-down (lowest resolved level can name an external advisor or account); none in the summary."),
        ent("Fact Attribution Override", "Fact", [("06", "Attribution Override")], ["Override ID"],
            grain="one row = attribution override",
            note="Active Attribution Overrides. Approved By (20 Employee) stays a degenerate key: no employee master is "
                 "upstream. PII tier: none at publication."),
        dim("Identifier Crosswalk", ("DP-006", "Identifier Crosswalk"), [("06", "Identifier Crosswalk")],
            note="Conformed from DP-006: intermediary source identifiers resolved to parties and accounts. PII tier: "
                 "identity in the steward drill-down (rep codes resolve to external advisors and accounts)."),
        ent("Fact Match Result", "Fact", [("06", "Match Result")], ["Identifier Crosswalk Key", "Match Date"],
            grain="one row = crosswalk entry x match date",
            note="Intermediary Identity Match Rate % and Suggested Matches Awaiting Review. Model gap: the group "
                 "carries none of the crosswalk key attributes, so it borrows the Identifier Crosswalk Key. PII tier: "
                 "identity in the steward drill-down."),
        ent("Match Rule", "Dimension", [("06", "Match Rule")], ["Match Rule ID"],
            note="No foundational model publishes 06 Match Rule. PII tier: none."),
        ent("Fact Restatement", "Fact", [("06", "Restatement")], ["Restatement ID"],
            grain="one row = restatement of a locked period",
            note="Restatements and Net Impact. Affected Periods is multi-valued text, drawn M:N to Reporting Period. "
                 "Model gap: the inputs carry no reference to the restated snapshot, so it borrows the Snapshot Key; "
                 "Restatement Approved By stays degenerate. PII tier: none."),
        ent("Fact DQ Result", "Fact", [("21", "Data Quality Result")], ["DQ Result ID"],
            grain="one row = data quality rule execution on a load",
            note="DQ Rule Pass Rate %. Tested DQ Rule (21) stays a degenerate key: no upstream model publishes the "
                 "rule. PII tier: none."),
        ent("Fact Vendor Data Issue", "Fact", [("14", "Vendor Data Issue")], ["Vendor Data Issue ID"],
            grain="one row = vendor data issue", note="PII tier: none."),
        dim("Dataset", ("DP-101", "Dataset"), note="Conformed from DP-101. PII tier: none."),
        dim("Party", PTY240, note="Conformed from DP-240: data providers and resolved parties. PII tier: identity in "
                                  "the steward drill-down."),
        dim("Client Account", ACCT, note="Conformed from DP-093: resolved accounts. PII tier: identity in the steward "
                                         "drill-down."),
        dim("Distribution Agreement", AGREE, note="Conformed from DP-005: the agreement governing a partner feed. PII "
                                                  "tier: none."),
        _c495,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE + " Supersedes Snapshot chains restated versions."),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Reporting Period", RPER, note="Conformed from DP-008: the periods a restatement affects. PII tier: none."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r495 + [
        rel("Fact Load", "Data Feed", ["Feed"]),
        rel("Fact Load", "Calendar Date", ["Business Date"]),
        rel("Data Feed", "Party", ["Data Provider"], optional=True),
        rel("Data Feed", "Distribution Agreement", ["Governing Agreement"], optional=True),
        rel("Reconciliation", "Data Feed", ["Left Source"]),
        rel("Reconciliation", "Data Feed", ["Right Source"]),
        rel("Fact Reconciliation Run", "Reconciliation", ["Reconciliation Key"]),
        rel("Fact Reconciliation Run", "Calendar Date", ["Run Business Date"]),
        rel("Fact Break", "Fact Reconciliation Run", ["Fact Reconciliation Run Key"]),
        rel("Fact Break", "Calendar Date", ["Resolution Date"], optional=True),
        rel("Fact Unattributed Item", "Calendar Date", ["First Seen Date"]),
        rel("Fact Attribution Override", "Calendar Date", ["Override Effective From"]),
        rel("Identifier Crosswalk", "Data Feed", ["Source Feed"]),
        rel("Identifier Crosswalk", "Party", ["Resolved Party"], optional=True),
        rel("Identifier Crosswalk", "Client Account", ["Resolved Account"], optional=True),
        rel("Fact Match Result", "Identifier Crosswalk", ["Identifier Crosswalk Key"]),
        rel("Fact Match Result", "Match Rule", ["Match Rule Applied"], optional=True),
        rel("Match Rule", "Data Feed", ["Applicable Feeds"], card="M:N"),
        rel("Fact Restatement", "Reporting Period", ["Affected Periods"], card="M:N"),
        rel("Fact Restatement", "Snapshot", ["Snapshot Key"]),
        rel("Fact DQ Result", "Fact Load", ["Tested Load"]),
        rel("Fact Vendor Data Issue", "Dataset", ["Issue Dataset"]),
        rel("Fact Vendor Data Issue", "Calendar Date", ["Detected Date"]),
    ],
    notes="Supply-chain star with two main facts, loads (data feed x business date) and reconciliation runs "
          "(reconciliation x run date), and breaks, suspense items, overrides, match results, restatements, DQ results "
          "and vendor issues as companion facts. Feeds, loads and reconciliations follow DP-007, the crosswalk DP-006, "
          "the certified denominator and restatements DP-008. Model gaps (borrowed keys): Reconciliation Run "
          "(Reconciliation Key), Break (Fact Reconciliation Run Key), Match Result (Identifier Crosswalk Key), "
          "Restatement (Snapshot Key). Degenerate keys: Approved By, Restatement Approved By (no employee master "
          "upstream), Tested DQ Rule."
)

# ======================================================================================================================
# DP-496 Client Asset Mix & Own-Fund Penetration
# ======================================================================================================================
_c496, _r496 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Ending Client Assets, Advised Assets or Own-Fund Overlap Amount x dimension type "
                    "(channel, holding type, segment) x period end x locked snapshot",
                    "The certified margins the cross-tab decomposes, read as published (CW-011).")

DP496 = dict(
    style="Star",
    entities=[
        ent("Fact Channel Holding Type Mix", "Fact", [("06", "Account Asset Summary")],
            ["Summary Account", "Summary As-Of Date", "Summary Holding Type"], measures=True,
            grain="one row = account x as-of date x holding type (DP-007 account summary), aggregated to period end x "
                  "distribution channel x holding type",
            note="The decomposition fact: the channel-by-holding-type cells are sums of these account summaries and are "
                 "tied to the DP-008 margins of the same snapshot (Fact Certified Client Assets at Dimension Type "
                 "Channel and Holding Type), so the cells add to the certified totals and never redefine them. Client "
                 "Assets only: no Firm AUM slice is added to these rows (CW-011). Own-Product Indicator gives the "
                 "own-fund share. PII tier: financial at row level (account market values); none at publication."),
        _c496,
        ent("Fact Firm AUM Fund Slice", "Fact", [("27", "Fund NAV Calculation")], ["Fact Firm AUM Fund Slice Key"],
            grain="one row = approved NAV of record of a fund x valuation date",
            note="Firm AUM (from DP-241) and Own Funds Outside Client Assets read the fund slice as DP-241 certifies it; "
                 "a separate family from Client Assets, joined only through the calendar and never added to it "
                 "(CW-011). Model gap: the NAV of record key (NAV Book, NAV Calculation Source, NAV Version Number) is "
                 "not in the inputs and no upstream foundational model publishes 27 Fund NAV Calculation, so the row "
                 "takes a surrogate key. PII tier: none."),
        ent("Fact Firm AUM Managed Account Slice", "Fact", [("46", "Model Assignment")], ["Model Assignment ID"],
            grain="one row = model assignment of a managed account",
            note="The managed account slice of Firm AUM (Regulatory AUM Classification), DP-241's; never added to "
                 "Client Assets (CW-011). PII tier: financial at row level (account key); none at publication."),
        dim("Fact Firm AUM Portfolio Slice", ("DP-007", "Portfolio Valuation Summary"),
            [("18", "Portfolio Valuation Summary")], role="Fact",
            grain="one row = portfolio x valuation as-of date x valuation view",
            note="The portfolio slice of Firm AUM; conformed from DP-007 because the product reads the total but not "
                 "Valuation View of the key. Read as a slice total only: no 18 Portfolio Holding is joined to a client "
                 "holding (CW-007). PII tier: none."),
        ent("Fact Fund Shareholder Position", "Fact", [("06", "Fund Shareholder Position"), ("06", "Omnibus Look-Through")],
            ["Position ID"], grain="one row = fund shareholder position x valuation date",
            note="Source-book tie-out only: the 06 position is a view of the register, never a second source of client "
                 "holdings (CW-007); Omnibus Look-Through folds here. PII tier: financial at row level; none at "
                 "publication."),
        ent("Fact Attribution Record", "Fact", [("06", "Attribution Record"), ("06", "Market & Client Dimensions")],
            ["Attribution Record ID"], grain="one row = attribution record of an account summary or position",
            note="Gives the channel and service offering of the offering cut. PII tier: none at publication."),
        ent("Fact Client Holding", "Fact", [("49", "Client Holding"), ("49", "Client Holding Valuation")],
            ["Client Holding ID"], grain="one row = client holding x holding date x holding view",
            note="Own-Fund Client Holdings Market Value (from DP-300) and the third-party and securities wallet share: "
                 "the 49 book of record, never joined to an 18 Portfolio Holding (CW-007); Client Holding Valuation folds "
                 "here. PII tier: financial at row level; none at publication."),
        dim("Instrument", ("DP-097", "Instrument"), [("17", "Instrument")],
            note="Conformed from DP-097 (security master): instrument type and asset class of the wallet share. PII "
                 "tier: none."),
        dim("Share Class", SHARE, [("01", "Share Class")], note="Conformed from DP-004. PII tier: none."),
        dim("Investment Product", PROD, [("01", "Investment Product")],
            note="Conformed from DP-004: Vehicle Type of Own-Fund Share by Share Class Vehicle. PII tier: none."),
        dim("Service Offering", OFFER, note="Conformed from DP-004. PII tier: none."),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: identity (account keys)."),
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r496 + [
        rel("Fact Channel Holding Type Mix", "Client Account", ["Summary Account"]),
        rel("Fact Channel Holding Type Mix", "Calendar Date", ["Summary As-Of Date"]),
        rel("Fact Firm AUM Fund Slice", "Calendar Date", ["Valuation Date"]),
        rel("Fact Firm AUM Managed Account Slice", "Client Account", ["Assigned Account"]),
        rel("Fact Firm AUM Portfolio Slice", "Calendar Date", ["Valuation As-Of Date"]),
        rel("Fact Fund Shareholder Position", "Share Class", ["Share Class"]),
        rel("Fact Fund Shareholder Position", "Client Account", ["Omnibus Parent Account"], optional=True),
        rel("Fact Fund Shareholder Position", "Calendar Date", ["Valuation Date"]),
        rel("Fact Attribution Record", "Fact Fund Shareholder Position", ["Source Position"], optional=True),
        rel("Fact Attribution Record", "Fact Channel Holding Type Mix", ["Source Account Asset Summary"], optional=True),
        rel("Fact Attribution Record", "Service Offering", ["Service Offering"], optional=True),
        rel("Fact Client Holding", "Client Account", ["Holding Account"]),
        rel("Fact Client Holding", "Instrument", ["Held Instrument"]),
        rel("Fact Client Holding", "Calendar Date", ["Client Holding Date"]),
        rel("Share Class", "Investment Product", ["Parent Product"]),
    ],
    notes="Asset mix star: the channel-by-holding-type decomposition of the DP-007 account summaries is the main fact, "
          "tied to the certified DP-008 margins of the same snapshot. Firm AUM and its slices (DP-241) are three "
          "separate facts joined only through the calendar; no fact adds Client Assets and Firm AUM (CW-011). Books of "
          "record kept apart (CW-007): 49 Client Holding (DP-300), the 06 position view and the 18 valuation total "
          "never join as one fact; they reconcile only as totals on the calendar. Model gap: Fact Firm AUM Fund Slice "
          "takes a surrogate key (NAV of record key not in the inputs; no upstream foundational model publishes 27). "
          "Fact Firm AUM Portfolio Slice is conformed from DP-007 for its key."
)

# ======================================================================================================================
# DP-497 Client Revenue Yield by Stream, Offering & Segment
# ======================================================================================================================
_c497, _r497 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Average Client Assets x dimension (offering, channel, segment) x period end x locked "
                    "snapshot",
                    "The yield denominator, read as published (CW-011).")

DP497 = dict(
    style="Star",
    entities=[
        ent("Fact Client Revenue", "Fact", [("10", "Client Revenue Record")], ["Client Revenue Record ID"], measures=True,
            grain="one row = client revenue record, aggregated to fiscal period x revenue stream x service offering x "
                  "channel x client segment (closed periods final)",
            note="Client revenue as DP-012 certifies it, never re-derived; yield divides by the DP-008 average. Revenue "
                 "Account / Household names the account (REFS 15 Account); a household is reached only through the "
                 "account-party and household-membership bridges. PII tier: financial at row level; none at "
                 "publication (aggregates)."),
        ent("Fact Fee Revenue", "Fact", [("10", "Fee Revenue Record")], ["Fee Revenue Record ID"],
            grain="one row = fee revenue record (share class or mandate x accounting period)",
            note="Own-fund fee revenue and Effective Net Fee Rate from DP-012. PII tier: none."),
        ent("Fact Waiver", "Fact", [("10", "Waiver Record")], ["Waiver Record ID"],
            grain="one row = waiver or reimbursement record", note="PII tier: none."),
        ent("Fact Cash Program Economics", "Fact", [("10", "Cash Program Economics")],
            ["Economics Sweep Program", "Economics Program Bank", "Economics Period"],
            grain="one row = sweep program x program bank x period",
            note="Cash Program Net Spread from DP-012. PII tier: none (program-level aggregates)."),
        ent("Pricing Scenario", "Dimension", [("10", "Pricing Scenario")], ["Pricing Scenario ID"],
            note="Priced Subject and Proposed Schedule Version are multi-type references with no REFS target, so they "
                 "stay degenerate. PII tier: none."),
        ent("Fact Pricing Scenario Result", "Fact", [("10", "Pricing Scenario Result")],
            ["Pricing Scenario Key", "Projection Year"], grain="one row = pricing scenario x projection year",
            note="Model gap: the group carries no Pricing Scenario ID, so it borrows the Pricing Scenario Key. PII "
                 "tier: none."),
        dim("Fact Account Fee Calculation", ("DP-305", "Account Fee Calculation"), [("47", "Account Fee Calculation")],
            role="Fact", grain="one row = fee calculation run x fee schedule assignment x billing arrangement",
            note="Billing realization from DP-305; conformed because the product does not read Calculated Billing "
                 "Arrangement of the key. Institutional billing is 47 (CW-246). PII tier: financial at row level; "
                 "aggregated to offering x billing period at publication."),
        dim("Fact Fee Waiver", ("DP-305", "Fee Waiver"), [("47", "Fee Waiver")], role="Fact",
            grain="one row = fee waiver",
            note="Fee Reductions by Type; conformed from DP-305 so the waiver keeps its assignment link, which the "
                 "inputs do not read. PII tier: financial at row level; aggregated at publication."),
        dim("Fee Schedule Assignment", ("DP-305", "Fee Schedule Assignment"), note="Conformed from DP-305. PII tier: "
                                                                                     "identity (account keys)."),
        dim("Fee Run", ("DP-305", "Fee Run"), note="Conformed from DP-305: the fee calculation run. PII tier: none."),
        ent("Fact Client Trade Confirmation", "Fact", [("48", "Client Trade Confirmation")],
            ["Client Trade Confirmation ID"], grain="one row = client trade confirmation",
            note="Commission Revenue per Confirmation, from the DP-301 book. PII tier: financial at row level; "
                 "aggregated at publication."),
        dim("Fact Fully Paid Lending", ("DP-300", "Fully Paid Securities Loan"), [("49", "Fully Paid Securities Loan")],
            role="Fact", grain="one row = fully paid securities loan",
            note="Fully Paid Lending Revenue Check; conformed from DP-300 so the loan keeps its lending account, which "
                 "the inputs do not read. PII tier: financial at row level; aggregated at publication."),
        dim("Segment Assignment", SEG, [("02", "Segment Assignment")], role="Bridge",
            grain="one row = party x segmentation scheme x segment effective period",
            note="Conformed from DP-240: Revenue by Client Segment Scheme re-cuts revenue by any scheme in force. PII "
                 "tier: identity."),
        dim("Account Party Role", APR, [("15", "Account Party Role")], role="Bridge",
            grain="one row = account x party x account role type x effective period",
            note="Conformed from DP-093: account-to-party path. PII tier: identity."),
        dim("Household Membership", HHM, [("02", "Household Membership")], role="Bridge",
            grain="one row = household x member party x effective period",
            note="Conformed from DP-240: party-to-household path; with Account Party Role the only account-to-household "
                 "path. PII tier: identity."),
        dim("Fee Household", ("DP-305", "Fee Household"), [("47", "Fee Household")],
            note="Conformed from DP-305: the billing household anchored on a client household. PII tier: identity."),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: identity (account keys)."),
        dim("Client Party", PTY240, note="Conformed from DP-240. PII tier: identity."),
        dim("Household", PTY240, note="Conformed from DP-240 (Party Type Household). PII tier: identity."),
        dim("Service Offering", OFFER, note="Conformed from DP-004. PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("Legal Entity", LE13, note="Conformed from DP-013: the recognizing legal entity. PII tier: none."),
        dim("Sweep Program", ("DP-431", "Sweep Program"), note="Conformed from DP-431. PII tier: none."),
        dim("Program Bank", ("DP-431", "Program Bank"), note="Conformed from DP-431. PII tier: none."),
        _c497,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r497 + [
        rel("Fact Client Revenue", "Client Account", ["Revenue Account / Household"], optional=True),
        rel("Fact Client Revenue", "Service Offering", ["Revenue Service Offering"], optional=True),
        rel("Fact Client Revenue", "Legal Entity", ["Recognizing Legal Entity"]),
        rel("Fact Fee Revenue", "Share Class", ["Revenue Share Class / Mandate"], optional=True),
        rel("Fact Waiver", "Share Class", ["Supported Share Class"]),
        rel("Fact Cash Program Economics", "Sweep Program", ["Economics Sweep Program"]),
        rel("Fact Cash Program Economics", "Program Bank", ["Economics Program Bank"]),
        rel("Fact Cash Program Economics", "Fact Fee Revenue", ["Money Market Sweep Fund Revenue"], optional=True),
        rel("Pricing Scenario", "Calendar Date", ["Scenario Base Date"]),
        rel("Fact Pricing Scenario Result", "Pricing Scenario", ["Pricing Scenario Key"]),
        rel("Fact Account Fee Calculation", "Fee Run", ["Calculation Run"]),
        rel("Fact Account Fee Calculation", "Fee Schedule Assignment", ["Calculated Assignment"]),
        rel("Fact Fee Waiver", "Fee Schedule Assignment", ["Waived Assignment"], optional=True),
        rel("Fee Schedule Assignment", "Client Account", ["Billed Account"], optional=True),
        rel("Fact Client Trade Confirmation", "Calendar Date", ["Confirmed Trade Date"]),
        rel("Fact Fully Paid Lending", "Client Account", ["Lending Account"]),
        rel("Fact Fully Paid Lending", "Calendar Date", ["Loan Start Date"]),
        rel("Sweep Program", "Legal Entity", ["Sponsoring Broker-Dealer"]),
        rel("Fee Schedule Assignment", "Fee Household", ["Assigned Fee Household"], optional=True),
        rel("Segment Assignment", "Client Party", ["Segmented Party"]),
        rel("Account Party Role", "Client Account", ["Role Account"]),
        rel("Account Party Role", "Client Party", ["Role Party"]),
        rel("Household Membership", "Household", ["Household"]),
        rel("Household Membership", "Client Party", ["Household Member"]),
        rel("Fee Household", "Household", ["Anchor Client Household"]),
    ],
    notes="Revenue yield star at the DP-012 client revenue record, with own-fund fee revenue, waivers, cash program "
          "economics, DP-305 billing realization, DP-301 commissions, DP-300 fully paid lending and pricing scenarios "
          "as companion facts; the denominator is the certified DP-008 Average Client Assets. Revenue is never "
          "re-derived (CW-241). Segments cut through the DP-240 Segment Assignment bridge and households through the "
          "Account Party Role and Household Membership bridges, never a column. Facts conformed for their keys or "
          "links: Account Fee Calculation, Fee Waiver (DP-305), Fully Paid Securities Loan (DP-300). Model gap: Pricing "
          "Scenario Result borrows the Pricing Scenario Key."
)

# ======================================================================================================================
# DP-498 Cost to Serve & Client Lifetime Value (restricted household rows)
# ======================================================================================================================
_c498, _r498 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Average Client Assets or household count x dimension x period end x locked snapshot",
                    "The cost-to-serve rate and per-household denominators, read as published (CW-011).")

DP498 = dict(
    style="Star",
    entities=[
        ent("Fact Cost to Serve", "Fact", [("10", "Profitability Record"), ("10", "Cost-to-Serve Profile")],
            ["Profitability Record ID"], measures=True,
            grain="one row = profitability record (profitability period x served dimension: client segment, service "
                  "tier, service offering, channel) x data version, one version per DP-480 allocation run",
            note="The published fact: segment, tier, offering and channel aggregates with a 10-household minimum cell; "
                 "Cost-to-Serve Profile folds here (registry fold) and the components tie out to the DP-480 allocation "
                 "and the DP-191 certified expense. Rows at household grain (Served Party, Client / Account) are "
                 "released only through the restricted Fact Household Cost to Serve. PII tier: financial (cost to "
                 "serve is a PII - financial inference, CW-157); aggregates only at publication."),
        ent("Fact Household Cost to Serve (restricted)", "Fact", [], ["Fact Cost to Serve Key"],
            grain="one row = profitability record at household grain (Dimension Grain Household)",
            note="Restricted view 'DP-498 Household Economics' registered in DP-518 (CW-243, CD-344), entitled client "
                 "economics and advice leadership roles only: the household rows of Fact Cost to Serve. PII tier: "
                 "financial (restricted)."),
        ent("Fact Household Lifetime Value (restricted)", "Fact", [("10", "Client Lifetime Value Estimate")],
            ["Valued Household", "Valuation Model Version", "Estimate As-Of Date"],
            grain="one row = household x lifetime value model version x estimate as-of date",
            note="Restricted view 'DP-498 Household Economics' registered in DP-518 (CW-243): household lifetime value "
                 "is never published at row level. PII tier: financial (restricted)."),
        ent("Fact Lifetime Value Aggregate", "Fact", [], ["Fact Lifetime Value Aggregate Key"],
            grain="one row = lifetime value model version x acquisition channel x cohort x segment",
            note="The published lifetime value: aggregates of the restricted household estimates with the 10-household "
                 "minimum cell. Model gap: no input object holds the aggregate, so it takes a surrogate key and borrows "
                 "the Lifetime Value Model Key. PII tier: none at publication."),
        ent("Lifetime Value Model", "Dimension", [("10", "Lifetime Value Model")],
            ["Lifetime Value Model ID", "Lifetime Value Model Version"],
            note="Estimates on Unapproved Model Version checks the version's use status in the model inventory. Model "
                 "gap: the inputs carry no model inventory reference, so it borrows the Model Inventory Entry Key. PII "
                 "tier: none."),
        dim("Model Inventory Entry", ("DP-212", "Model"), [("37", "Model Inventory Entry")],
            note="Conformed from DP-212. PII tier: none."),
        ent("Fact Acquisition Cost", "Fact", [("10", "Client Acquisition Cost Record")],
            ["Acquisition Channel", "Acquisition Campaign", "Cohort Month"],
            grain="one row = acquisition channel x campaign x cohort month",
            note="Acquisition Cost per Funded Household. PII tier: none (aggregates)."),
        dim("Allocation Run", ("DP-480", "Allocation Run"), [("10", "Allocation Run")],
            note="Conformed from DP-480: the run whose results the profile ties out to. PII tier: none."),
        dim("Allocation Rule", ("DP-480", "Allocation Rule"), [("10", "Allocation Rule")],
            note="Conformed from DP-480. PII tier: none."),
        ent("Fact Allocation Result", "Fact", [("10", "Allocation Result")],
            ["Allocation Run Key", "Allocated Rule", "Target Dimension Member"],
            grain="one row = allocation run x allocation rule x target dimension member",
            note="Allocated Cost Tie-Out (from DP-480), summed to the served dimension. Target Dimension Member can name "
                 "a household; such rows are read only for the restricted view. Model gap: the group carries no "
                 "Allocation Run ID, so it borrows the Allocation Run Key (as DP-480 does). PII tier: financial at "
                 "member level; aggregates only at publication."),
        dim("Cost Pool", ("DP-480", "Cost Pool"), [("10", "Cost Pool")],
            note="Conformed from DP-480: Cost-to-Serve Component of Cost to Serve by Component. PII tier: none."),
        dim("Management Hierarchy", ("DP-480", "Management Hierarchy"), note="Conformed from DP-480. PII tier: none."),
        ent("Fact Client Revenue", "Fact", [("10", "Client Revenue Record")], ["Client Revenue Record ID"],
            grain="one row = client revenue record",
            note="Revenue to Cost to Serve Ratio, from DP-012. Model gap: the inputs carry no offering, account or "
                 "entity reference, so the row borrows the Fact Cost to Serve Key of the profitability record it is "
                 "summed into. PII tier: financial at row level; aggregates only at publication."),
        dim("Campaign", CAMP, [("04", "Campaign")], note="Conformed from DP-011. PII tier: none."),
        ent("Fact Campaign Budget", "Fact", [("04", "Campaign Budget")], ["Fact Campaign Budget Key"],
            grain="one row = campaign x budget currency",
            note="Acquisition Cost Tie-Out to Campaign Spend. Model gap: neither the campaign key nor the Budget "
                 "Currency discriminator is in the inputs, so the row takes a surrogate key and borrows the Campaign "
                 "Key. PII tier: none."),
        ent("Spend Line", "Fact", [("04", "Spend Line")], ["Spend Line Key"], grain="one row = campaign spend line",
            note="Campaign Spend (from DP-410). Model gap: the line carries no campaign reference in the inputs, so it "
                 "borrows the Campaign Key; the registry key is a surrogate. PII tier: none."),
        ent("Fact Acquisition Milestone", "Fact", [("04", "Acquisition Milestone")],
            ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"],
            grain="one row = party x milestone type x milestone date x account",
            note="Funded households by cohort. PII tier: identity at row level; aggregates only at publication."),
        ent("Fact Attributed Outcome", "Fact", [("04", "Attributed Outcome")], ["Fact Attributed Outcome Key"],
            grain="one row = acquisition milestone x campaign x attribution model",
            note="Model gap: the registry key (Attributed Milestone, Applied Attribution Model) is not in the inputs, so "
                 "the row takes a surrogate key. PII tier: none."),
        ent("Fact Marketing Lead", "Fact", [("04", "Marketing Lead")], ["Lead ID"], grain="one row = marketing lead",
            note="Funded Accounts by Original Campaign (from DP-392). PII tier: identity at row level; aggregates only "
                 "at publication."),
        ent("Fact Service Request", "Fact", [("13", "Service Request")], ["Service Request ID"],
            grain="one row = service request",
            note="Service Requests per Household (from DP-381), counted through the account-to-household bridges. PII "
                 "tier: identity at row level; aggregates only at publication."),
        dim("Fact GL Balance", ("DP-191", "GL Account Balance"), [("19", "GL Account Balance")], role="Fact",
            grain="one row = ledger x GL account x segment combination x fiscal period x balance type x currency",
            note="Certified Operating Expense (from DP-191); conformed because the product does not read the ledger, "
                 "segment combination and currency of the key. Model gap: Balance Fiscal Period and the allocation Run Period are codes, so the balance borrows the Allocation Run Key of the run it ties out to. PII tier: none."),
        dim("GL Account", ("DP-191", "GL Account"), [("19", "GL Account")], note="Conformed from DP-191. PII tier: none."),
        dim("Fact Attribution Record", ("DP-008", "Attribution Record"), [("06", "Attribution Record")], role="Fact",
            grain="one row = attribution record",
            note="Twelve-month NNA of acquired households; conformed from DP-008 because the product reads Attributed "
                 "Amount but not the record key. Model gap: the attributed campaign (06 Market & Client Dimensions) is "
                 "not in the inputs, so the row borrows the Campaign Key. PII tier: none at publication."),
        dim("Segment Assignment", SEG, [("02", "Segment Assignment")], role="Bridge",
            grain="one row = party x segmentation scheme x segment effective period",
            note="Conformed from DP-240. PII tier: identity."),
        dim("Household Membership", HHM, [("02", "Household Membership")], role="Bridge",
            grain="one row = household x member party x effective period",
            note="Conformed from DP-240: household counts and the household grain of the restricted view. PII tier: "
                 "identity."),
        dim("Account Party Role", APR, [("15", "Account Party Role")], role="Bridge",
            grain="one row = account x party x account role type x effective period",
            note="Conformed from DP-093: with Household Membership the only account-to-household path. PII tier: identity."),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: identity (account keys)."),
        dim("Client Party", PTY240, note="Conformed from DP-240. PII tier: identity."),
        dim("Household", PTY240, note="Conformed from DP-240 (Party Type Household). PII tier: identity; rows only in "
                                      "the restricted view."),
        dim("Service Offering", OFFER, note="Conformed from DP-004. PII tier: none."),
        dim("Service Tier", STIER, note="Conformed from DP-004. PII tier: none."),
        _c498,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r498 + [
        rel("Fact Cost to Serve", "Service Offering", ["Service Offering"], optional=True),
        rel("Fact Cost to Serve", "Service Tier", ["Service Tier"], optional=True),
        rel("Fact Cost to Serve", "Management Hierarchy", ["Hierarchy Version"]),
        rel("Fact Cost to Serve", "Allocation Run", ["Source Allocation Run"]),
        rel("Fact Cost to Serve", "Household", ["Served Party"], optional=True,
            note="Joined only in the restricted 'DP-498 Household Economics' view."),
        rel("Fact Cost to Serve", "Client Party", ["Client / Account"], optional=True,
            note="Joined only in the restricted 'DP-498 Household Economics' view."),
        rel("Fact Household Cost to Serve (restricted)", "Fact Cost to Serve", ["Fact Cost to Serve Key"], card="1:1"),
        rel("Fact Household Lifetime Value (restricted)", "Household", ["Valued Household"]),
        rel("Fact Household Lifetime Value (restricted)", "Lifetime Value Model", ["Valuation Model Version"]),
        rel("Fact Household Lifetime Value (restricted)", "Calendar Date", ["Estimate As-Of Date"]),
        rel("Fact Lifetime Value Aggregate", "Lifetime Value Model", ["Lifetime Value Model Key"]),
        rel("Lifetime Value Model", "Model Inventory Entry", ["Model Inventory Entry Key"], optional=True),
        rel("Fact Acquisition Cost", "Campaign", ["Acquisition Campaign"]),
        rel("Fact Acquisition Cost", "Calendar Date", ["Cohort Month"]),
        rel("Fact Allocation Result", "Allocation Run", ["Allocation Run Key"]),
        rel("Fact Allocation Result", "Allocation Rule", ["Allocated Rule"]),
        rel("Allocation Rule", "Cost Pool", ["Source Cost Pool"]),
        rel("Fact Client Revenue", "Fact Cost to Serve", ["Fact Cost to Serve Key"]),
        rel("Fact Campaign Budget", "Campaign", ["Campaign Key"]),
        rel("Spend Line", "Campaign", ["Campaign Key"]),
        rel("Fact Acquisition Milestone", "Client Party", ["Milestone Party"]),
        rel("Fact Acquisition Milestone", "Client Account", ["Milestone Account"], optional=True),
        rel("Fact Acquisition Milestone", "Calendar Date", ["Milestone Date"]),
        rel("Fact Attributed Outcome", "Campaign", ["Attributed Campaign"]),
        rel("Fact Marketing Lead", "Client Party", ["Lead Party"]),
        rel("Fact Marketing Lead", "Campaign", ["Original Campaign"], optional=True),
        rel("Fact Service Request", "Client Account", ["Account"]),
        rel("Fact GL Balance", "GL Account", ["Balance GL Account"]),
        rel("Fact GL Balance", "Allocation Run", ["Allocation Run Key"],
            note="The GL balances of the run period the tie-out compares (Balance Fiscal Period and Run Period are both codes)."),
        rel("Fact Attribution Record", "Campaign", ["Campaign Key"]),
        rel("Segment Assignment", "Client Party", ["Segmented Party"]),
        rel("Household Membership", "Household", ["Household"]),
        rel("Household Membership", "Client Party", ["Household Member"]),
        rel("Account Party Role", "Client Account", ["Role Account"]),
        rel("Account Party Role", "Client Party", ["Role Party"]),
    ],
    notes="Cost-to-serve and lifetime value star. Published facts carry aggregates only (Fact Cost to Serve at segment, "
          "tier, offering and channel; Fact Lifetime Value Aggregate; acquisition cost, campaign spend and tie-outs); "
          "household rows sit in the restricted Fact Household Cost to Serve and Fact Household Lifetime Value, the "
          "'DP-498 Household Economics' view registered in DP-518 (CW-243, CD-344; PII tier financial). Allocation "
          "objects are DP-480's, revenue DP-012's, expense DP-191's, campaigns DP-011's, the model inventory DP-212's, "
          "segments and households DP-240's (households only through the bridges). Facts conformed for their keys: GL "
          "Account Balance (DP-191), Attribution Record (DP-008). Model gaps: Fact Household Cost to Serve and Fact "
          "Lifetime Value Aggregate have no backing object; borrowed keys on Lifetime Value Model (Model Inventory "
          "Entry Key), Fact Allocation Result (Allocation Run Key), Fact Client Revenue (Fact Cost to Serve Key), Fact "
          "Campaign Budget, Spend Line and Fact Attribution Record (Campaign Key); surrogate keys on Fact Campaign Budget "
          "and Fact Attributed Outcome (registry keys not in the inputs)."
)

# ======================================================================================================================
# DP-499 Client, Offering & Advisor Profitability (restricted advisor and household rows)
# ======================================================================================================================
_c499, _r499 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Average Client Assets x dimension x period end x locked snapshot",
                    "The yield denominator (Net Revenue Yield on Client Assets), read as published (CW-011).")

DP499 = dict(
    style="Star",
    entities=[
        ent("Fact Profitability", "Fact",
            [("10", "Profitability Record"), ("10", "Profitability Measure"), ("10", "Cost-to-Serve Profile")],
            ["Profitability Record ID"], measures=True,
            grain="one row = profitability record (dimension combination x profitability period x data version x "
                  "hierarchy version), one version per allocation run",
            note="The published fact at segment, offering, channel, business line, product and partner firm grains; "
                 "Profitability Measure and Cost-to-Serve Profile fold here (registry fold). Advisor and household "
                 "grain rows are released only through the restricted facts below. PII tier: financial and "
                 "compensation for the advisor and household rows (restricted); none at publication."),
        ent("Fact Advisor Book Profitability (restricted)", "Fact", [], ["Fact Profitability Key"],
            grain="one row = profitability record at advisor grain (Dimension Grain Advisor)",
            note="Restricted view 'DP-499 Advisor Book' registered in DP-518 (CW-243): advisor book rows carry "
                 "allocated employee compensation cost. PII tier: financial and compensation (CD-344 tier, restricted)."),
        ent("Fact Household Profitability (restricted)", "Fact", [], ["Fact Profitability Key"],
            grain="one row = profitability record at household grain (Dimension Grain Household)",
            note="Restricted view 'DP-499 Household Profitability' registered in DP-518 (CW-243; household "
                 "profitability is restricted by ruling). PII tier: financial (restricted)."),
        ent("Profitability Measure Definition", "Dimension", [("10", "Profitability Measure Definition")],
            ["Profitability Measure Code"],
            note="Measure Formula Conformance compares each measure's formula with the definition (year-start extract, "
                 "spec taxonomy gap). PII tier: none."),
        ent("Fact Distribution Cost Item", "Fact", [("10", "Distribution Cost Item")], ["Distribution Cost Item ID"],
            grain="one row = distribution cost item",
            note="Direct Sales & Marketing Cost (directly attributable items). PII tier: none."),
        dim("Allocation Run", ("DP-480", "Allocation Run"), [("10", "Allocation Run")],
            note="Conformed from DP-480. PII tier: none."),
        dim("Management Hierarchy", ("DP-480", "Management Hierarchy"), [("10", "Management Hierarchy")],
            note="Conformed from DP-480. PII tier: none."),
        dim("Management Hierarchy Node", ("DP-480", "Management Hierarchy Node"), [("10", "Management Hierarchy Node")],
            pk=["Management Hierarchy Key", "Node ID"],
            note="Conformed from DP-480, keyed as there by the hierarchy and the node; Parent Node rolls the leaves up. "
                 "Model gap: the node carries no hierarchy reference, so it borrows the Management Hierarchy Key (as "
                 "DP-480 does). PII tier: none."),
        dim("Fact Client Revenue", ("DP-012", "Client Revenue Record"), [("10", "Client Revenue Record")], role="Fact",
            grain="one row = client revenue record",
            note="Revenue Tie-Out to DP-012; conformed from DP-012 so the record keeps its offering and legal entity, "
                 "which the inputs do not read. PII tier: financial at row level; aggregates only at publication."),
        dim("Fact Fee Revenue", ("DP-012", "Fee Revenue Record"), [("10", "Fee Revenue Record")], role="Fact",
            grain="one row = fee revenue record (share class or mandate x accounting period)",
            note="Conformed from DP-012 so the record keeps its share class, which the inputs do not read. PII tier: none."),
        dim("Advisor", EMP9, [("03", "Advisor")],
            note="Conformed from DP-009 Employee (03 Advisor folds there). PII tier: identity (employee); joined only in "
                 "the restricted 'DP-499 Advisor Book' view."),
        dim("Fact GL Balance", ("DP-191", "GL Account Balance"), [("19", "GL Account Balance")], role="Fact",
            grain="one row = ledger x GL account x segment combination x fiscal period x balance type x currency",
            note="Operating Profit Tie-Out to Certified Operating Income (from DP-191); conformed for its key. Model gap: Balance Fiscal Period and the "
                 "allocation Run Period are codes, so the balance borrows the Allocation Run Key. PII tier: none."),
        dim("GL Account", ("DP-191", "GL Account"), [("19", "GL Account")], note="Conformed from DP-191. PII tier: none."),
        dim("Household", PTY240, note="Conformed from DP-240 (Party Type Household). PII tier: financial; joined only "
                                      "in the restricted 'DP-499 Household Profitability' view."),
        dim("Partner Firm", DFIRM, note="Conformed from DP-001. PII tier: none."),
        dim("Service Offering", OFFER, note="Conformed from DP-004. PII tier: none."),
        dim("Service Tier", STIER, note="Conformed from DP-004. PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("Legal Entity", LE13, note="Conformed from DP-013. PII tier: none."),
        _c499,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r499 + [
        rel("Fact Profitability", "Service Offering", ["Service Offering"], optional=True),
        rel("Fact Profitability", "Service Tier", ["Service Tier"], optional=True),
        rel("Fact Profitability", "Partner Firm", ["Partner Firm"], optional=True),
        rel("Fact Profitability", "Share Class", ["Product / Share Class"], optional=True),
        rel("Fact Profitability", "Legal Entity", ["Reporting Legal Entity"]),
        rel("Fact Profitability", "Management Hierarchy", ["Hierarchy Version"]),
        rel("Fact Profitability", "Allocation Run", ["Source Allocation Run"]),
        rel("Fact Profitability", "Advisor", ["Advisor"], optional=True,
            note="Joined only in the restricted 'DP-499 Advisor Book' view."),
        rel("Fact Profitability", "Household", ["Client / Account"], optional=True,
            note="Joined only in the restricted 'DP-499 Household Profitability' view."),
        rel("Fact Profitability", "Profitability Measure Definition", ["Profitability Measure Definition Key"],
            card="M:N", note="Each measure column of the record is defined by one code."),
        rel("Fact Advisor Book Profitability (restricted)", "Fact Profitability", ["Fact Profitability Key"], card="1:1"),
        rel("Fact Household Profitability (restricted)", "Fact Profitability", ["Fact Profitability Key"], card="1:1"),
        rel("Fact Distribution Cost Item", "Share Class", ["Direct Product / Share Class"], optional=True),
        rel("Fact Distribution Cost Item", "Calendar Date", ["Service Period End"]),
        rel("Management Hierarchy Node", "Management Hierarchy", ["Management Hierarchy Key"]),
        rel("Fact Client Revenue", "Service Offering", ["Revenue Service Offering"], optional=True),
        rel("Fact Client Revenue", "Legal Entity", ["Recognizing Legal Entity"]),
        rel("Fact Fee Revenue", "Share Class", ["Revenue Share Class / Mandate"], optional=True),
        rel("Fact GL Balance", "GL Account", ["Balance GL Account"]),
        rel("Fact GL Balance", "Allocation Run", ["Allocation Run Key"],
            note="The GL balances of the run period the tie-out compares (Balance Fiscal Period and Run Period are both codes)."),
    ],
    notes="Profitability star at the profitability record, published at segment, offering, channel, business line, "
          "product and partner firm grains; advisor and household rows are the restricted facts 'DP-499 Advisor Book' "
          "and 'DP-499 Household Profitability' registered in DP-518 (CW-243, CD-344), 1:1 row filters of the record. "
          "Revenue is DP-012's, distribution payments DP-487's, cost to serve DP-498's, allocations and hierarchy "
          "DP-480's, operating income DP-191's and the yield denominator DP-008's. Facts conformed for their keys or "
          "links: Client Revenue Record and Fee Revenue Record (DP-012), GL Account Balance (DP-191). Model gaps: the "
          "restricted facts have no backing object of their own (they borrow the Fact Profitability Key); Management "
          "Hierarchy Node borrows the Management Hierarchy Key; the measure-to-definition link borrows the Profitability "
          "Measure Definition Key (no attribute names the measure code)."
)

# ======================================================================================================================
# DP-490 Client Assets & Flows Executive Scorecard
# ======================================================================================================================
_c490, _r490 = cert("Fact Scorecard", [MV, CAM, ("06", "Flow Measures")],
                    "one row = DP-008 measure value: reporting period (month, quarter, year to date) x channel or "
                    "business line x scorecard measure x locked snapshot",
                    "The main output: every client assets, NNA, organic growth, advised assets, count and own-fund flow "
                    "tile is a DP-008 row read as published (CW-011); Flow Measures folds here (registry fold). Holds "
                    "the measures because the scorecard is stated against these certified rows.",
                    measures=True, period=True)

DP490 = dict(
    style="Star",
    entities=[
        _c490,
        ent("Fact Restatement", "Fact", [("06", "Restatement")], ["Restatement ID"],
            grain="one row = restatement of a locked period",
            note="Restatement Impact (from DP-008); Affected Periods is multi-valued text, drawn M:N to Reporting "
                 "Period. PII tier: none."),
        dim("Fact Firm AUM Fund Slice", ("DP-012", "Fund NAV Calculation"), [("27", "Fund NAV Calculation")],
            role="Fact", grain="one row = NAV calculation of a fund x valuation date",
            note="Firm AUM and Slices (from DP-241): the fund slice, conformed from DP-012 for its key. A separate "
                 "family from Client Assets, joined only through the calendar and never added to it (CW-011). PII "
                 "tier: none."),
        ent("Fact Firm AUM Managed Account Slice", "Fact", [("46", "Model Assignment")], ["Model Assignment ID"],
            grain="one row = model assignment of a managed account",
            note="The managed account slice of Firm AUM; never added to Client Assets (CW-011). Model gap: the inputs "
                 "carry no account or date, so the row borrows the Reporting Period Key of the scorecard period. PII "
                 "tier: financial at row level; firm-level totals only at publication."),
        dim("Fact Firm AUM Portfolio Slice", ("DP-008", "Portfolio Valuation Summary"),
            [("18", "Portfolio Valuation Summary")], role="Fact",
            grain="one row = portfolio x valuation as-of date",
            note="The portfolio slice of Firm AUM, conformed from DP-008 for its key; read as a total, no 18 Portfolio "
                 "Holding is joined (CW-007). PII tier: none."),
        ent("Fact Client Revenue", "Fact", [("10", "Client Revenue Record")], ["Client Revenue Record ID"],
            grain="one row = client revenue record, aggregated to period x stream x channel x business line",
            note="Revenue vs Plan and the yield tile read as DP-012 and DP-497 publish them. Model gap: Client Revenue "
                 "Period is a code, not a period reference, so the row borrows the Reporting Period Key. PII tier: "
                 "financial at row level; none at publication."),
        ent("Fact Fee Revenue", "Fact", [("10", "Fee Revenue Record")], ["Fee Revenue Record ID"],
            grain="one row = fee revenue record (share class or mandate x accounting period)",
            note="Net Fee Revenue (from DP-012). Model gap: Revenue Accounting Period is a code, so the row borrows the "
                 "Reporting Period Key. PII tier: none."),
        ent("Fact Profitability", "Fact", [("10", "Profitability Record"), ("10", "Profitability Measure")],
            ["Profitability Record ID"], grain="one row = profitability record at business line grain",
            note="Operating Margin by Business Line (from DP-499), business line rows only; Profitability Measure folds "
                 "here. Model gap: Profitability Period is a code, so the row borrows the Reporting Period Key. PII "
                 "tier: none (business line aggregates)."),
        ent("Plan Version", "Dimension", [("10", "Plan Version")], ["Plan Version ID"],
            note="No foundational model publishes 10 Plan Version. PII tier: none."),
        ent("Fact Plan Line", "Fact", [("10", "Plan Line")],
            ["Plan Version Key", "Plan P&L Line", "Plan Dimension Members", "Plan Period"],
            grain="one row = plan version x P&L line x dimension members x plan period",
            note="Revenue vs Plan. Model gap: the group carries no Plan Version ID and the Plan Cost Center "
                 "discriminator is not in the inputs, so it borrows the Plan Version Key and keys on the other "
                 "discriminators; Plan Period is a code, so it also borrows the Reporting Period Key. PII tier: none."),
        ent("Fact Flow & Revenue Forecast", "Fact", [("10", "Flow & Revenue Forecast")],
            ["Plan Version Key", "Fact Flow & Revenue Forecast Key"],
            grain="one row = plan version x forecast share class or product x forecast channel",
            note="NNA Forecast vs Plan. Model gap: Forecast Share Class / Product of the registry key is not in the "
                 "inputs, so the row borrows the Plan Version Key and takes a surrogate discriminator. PII tier: none."),
        ent("Fact Plan Variance", "Fact", [("10", "Variance")], ["Plan Version Key", "Compared Plan Version"],
            grain="one row = plan version x compared plan version",
            note="Plan Variance by Driver. Model gap: the group carries no Plan Version ID, so it borrows the Plan "
                 "Version Key. PII tier: none."),
        ent("Fact Market Share", "Fact", [("11", "Market Share Record")], ["Market Share Record ID"],
            grain="one row = market share record",
            note="Channel Market Share (from DP-505), read as published. Share Definition stays degenerate (DP-014 is "
                 "not upstream). PII tier: none."),
        dim("Reporting Period", RPER, [("06", "Reporting Period")], note="Conformed from DP-008. PII tier: none."),
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r490 + [
        rel("Fact Restatement", "Reporting Period", ["Affected Periods"], card="M:N"),
        rel("Fact Firm AUM Fund Slice", "Calendar Date", ["Valuation Date"]),
        rel("Fact Firm AUM Managed Account Slice", "Reporting Period", ["Reporting Period Key"]),
        rel("Fact Firm AUM Portfolio Slice", "Calendar Date", ["Valuation As-Of Date"]),
        rel("Fact Client Revenue", "Reporting Period", ["Reporting Period Key"]),
        rel("Fact Fee Revenue", "Reporting Period", ["Reporting Period Key"]),
        rel("Fact Profitability", "Reporting Period", ["Reporting Period Key"]),
        rel("Fact Plan Line", "Plan Version", ["Plan Version Key"]),
        rel("Fact Plan Line", "Reporting Period", ["Reporting Period Key"]),
        rel("Fact Flow & Revenue Forecast", "Plan Version", ["Plan Version Key"]),
        rel("Fact Plan Variance", "Plan Version", ["Plan Version Key"]),
        rel("Fact Plan Variance", "Plan Version", ["Compared Plan Version"]),
        rel("Fact Market Share", "Calendar Date", ["Period End Date"]),
    ],
    notes="Executive scorecard star: the certified DP-008 rows are the main fact; the Firm AUM slices (DP-241) are three "
          "separate facts, never added to Client Assets (CW-011); revenue (DP-012, DP-497), margin (DP-499), market share "
          "(DP-505), plan and forecast are companion facts read as published. Facts conformed for their keys: Fund NAV "
          "Calculation (DP-012), Portfolio Valuation Summary (DP-008). Model gaps (borrowed keys): the managed account "
          "slice, client and fee revenue, profitability and plan lines borrow the Reporting Period Key (their periods "
          "are codes); Plan Line, Forecast and Variance borrow the Plan Version Key; Forecast takes a surrogate "
          "discriminator and Plan Line drops Plan Cost Center from its key (not in the inputs)."
)

# ======================================================================================================================
# DP-503 Intercompany Charges & Transfer Pricing (restricted member-level allocation read)
# ======================================================================================================================
DP503 = dict(
    style="Star",
    entities=[
        ent("Fact Intercompany Charge", "Fact", [("10", "Intercompany Charge")], ["Intercompany Charge ID"],
            measures=True,
            grain="one row = intercompany agreement x charge period (closed periods final)",
            note="The main output: booked charge against the expected charge and the arm's length range of the policy. "
                 "The charge has no link to the allocation run or revenue records its basis came from (spec taxonomy "
                 "gap). PII tier: none."),
        ent("Intercompany Agreement", "Dimension", [("10", "Intercompany Agreement"), ("10", "TP Policy")],
            ["Intercompany Agreement ID"],
            note="No foundational model publishes 10 Intercompany Agreement; TP Policy folds here (registry fold), SCD "
                 "type 2 on agreement and policy history. PII tier: none."),
        ent("Fact TP Documentation", "Fact", [("19", "Transfer Pricing Documentation")], ["TP Documentation ID"],
            grain="one row = documented entity x fiscal year x documentation type",
            note="Covered Intercompany Agreements is multi-valued text, drawn M:N to the agreement. PII tier: none."),
        ent("Fact Allocation Result (restricted)", "Fact", [("10", "Allocation Result")],
            ["Allocation Run Key", "Allocated Rule", "Target Dimension Member"],
            grain="one row = allocation run x allocation rule x target dimension member (Target Dimension Legal Entity)",
            note="Restricted view 'DP-503 Member-Level Allocation Read' registered in DP-518, limited to rows whose "
                 "Target Dimension is Legal Entity; no household, account or employee row is read. Model gap: the group "
                 "carries no Allocation Run ID, so it borrows the Allocation Run Key (as DP-480 does). PII tier: none "
                 "within the view (legal entity members only); the unfiltered result is financial."),
        dim("Allocation Run", ("DP-480", "Allocation Run"), [("10", "Allocation Run")],
            note="Conformed from DP-480. PII tier: none."),
        dim("Allocation Rule", ("DP-480", "Allocation Rule"), [("10", "Allocation Rule")],
            note="Conformed from DP-480. PII tier: none."),
        ent("Fact Client Revenue", "Fact", [("10", "Client Revenue Record")], ["Client Revenue Record ID"],
            grain="one row = client revenue record, summed by recognizing legal entity",
            note="Charge Basis for distribution services; no household, account or employee row is published (DQ5). "
                 "PII tier: financial at row level; legal entity totals only at publication."),
        ent("Fact Fee Revenue", "Fact", [("10", "Fee Revenue Record")], ["Fee Revenue Record ID"],
            grain="one row = fee revenue record (share class or mandate x accounting period)", note="PII tier: none."),
        ent("Entity Distribution Role", "Dimension", [("09", "Entity Distribution Role")],
            ["Role Entity", "Distribution Role", "Role Effective From"],
            note="Distribution Services Charges: which entity is the default contracting distributor. Model gap: Role "
                 "Market Scope of the registry key is not in the inputs, so the key omits it. PII tier: none."),
        ent("Fact GL Posting", "Fact", [("19", "GL Posting")], ["Journal ID", "Journal Line Number"],
            grain="one row = journal line",
            note="Ledger Booking Tie-Out (from DP-191) and elimination checks; Source Finance Record is a multi-type "
                 "reference and stays degenerate. PII tier: none."),
        dim("Legal Entity", ("DP-190", "Internal Legal Entity"), [("09", "Internal Legal Entity")],
            note="Conformed from DP-190 (09 Internal Legal Entity). PII tier: none."),
        dim("Investment Product", PROD, note="Conformed from DP-004. PII tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        dim("GL Account", ("DP-191", "GL Account"), note="Conformed from DP-191. PII tier: none."),
    ],
    relationships=[
        rel("Fact Intercompany Charge", "Intercompany Agreement", ["Charging Agreement"]),
        rel("Intercompany Agreement", "Legal Entity", ["Service Provider Entity"]),
        rel("Intercompany Agreement", "Legal Entity", ["Service Recipient Entity"]),
        rel("Intercompany Agreement", "Legal Entity", ["Tested Party"], optional=True),
        rel("Intercompany Agreement", "Investment Product", ["Covered Products"], card="M:N", optional=True),
        rel("Intercompany Agreement", "Fact TP Documentation", ["TP Documentation Reference"], optional=True),
        rel("Fact TP Documentation", "Legal Entity", ["Documented Legal Entity"]),
        rel("Fact TP Documentation", "Intercompany Agreement", ["Covered Intercompany Agreements"], card="M:N",
            optional=True),
        rel("Fact Allocation Result (restricted)", "Allocation Run", ["Allocation Run Key"]),
        rel("Fact Allocation Result (restricted)", "Allocation Rule", ["Allocated Rule"]),
        rel("Fact Allocation Result (restricted)", "Legal Entity", ["Target Dimension Member"], optional=True,
            note="Rows whose Target Dimension is Legal Entity only."),
        rel("Fact Client Revenue", "Legal Entity", ["Recognizing Legal Entity"]),
        rel("Fact Fee Revenue", "Share Class", ["Revenue Share Class / Mandate"], optional=True),
        rel("Share Class", "Investment Product", ["Parent Product"]),
        rel("Entity Distribution Role", "Legal Entity", ["Role Entity"]),
        rel("Fact GL Posting", "GL Account", ["Posted Account"]),
        rel("Fact GL Posting", "Legal Entity", ["Intercompany Partner Entity"], optional=True),
    ],
    notes="Transfer pricing star at intercompany agreement x charge period, with TP documentation, the restricted "
          "member-level allocation read, revenue bases and ledger postings as companion facts. The allocation read is "
          "the 'DP-503 Member-Level Allocation Read' restricted view registered in DP-518, legal-entity members only. "
          "Allocations are DP-480's, revenue DP-012's, postings and accounts DP-191's, legal entities DP-190's. Model "
          "gaps: Fact Allocation Result borrows the Allocation Run Key; Entity Distribution Role keys without Role Market "
          "Scope (not in the inputs)."
)

# ======================================================================================================================
# DP-506 Competitive Pricing & Fee Benchmarks
# ======================================================================================================================
DP506 = dict(
    style="Star",
    entities=[
        ent("Fact Fee Benchmark", "Fact",
            [("11", "Fee Benchmark Study"), ("11", "Fee Benchmark Result"), ("11", "Pricing Input")],
            ["Fee Study ID"], measures=True,
            grain="one row = fee benchmark study (subject x comparison set x fee measure x study date), history by study "
                  "date",
            note="The main output; Fee Benchmark Result and Pricing Input fold here (registry fold). Built from the "
                 "product's own inputs at the DP-481 key, so it joins to the DP-481 study. Own Fee Rate's source (47 or "
                 "01) is inferred from the subject (spec taxonomy gap). PII tier: none."),
        ent("Fact Price Observation", "Fact", [("11", "Competitor Pricing Observation")],
            ["Priced Offering", "Price Component", "Observation As-of Date", "Balance Tier Lower Bound"],
            grain="one row = competitor offering x price component x balance tier x as-of date",
            note="Own rate x competitor observation comparisons (advisory fee, commission, account fee, cash sweep "
                 "yield). PII tier: none."),
        dim("Competitor Offering", ("DP-481", "Competitor Offering"), [("11", "Competitor Offering")],
            note="Conformed from DP-481; Comparable Own Offering pairs it with the firm's offering. PII tier: none."),
        dim("Competitor", COMP, note="Conformed from DP-481. PII tier: none."),
        ent("Fact Peer Metric Snapshot", "Fact", [("11", "Peer Metric Snapshot")],
            ["Snapshot Subject", "Snapshot Date", "Peer Universe"],
            grain="one row = peer fund x snapshot date x peer universe",
            note="Peer Median Expense Ratio (from DP-014). Model gap: Return Period of the registry key is not in the "
                 "inputs (the expense ratio does not vary by return period), so the key omits it. PII tier: none."),
        dim("Peer Fund", ("DP-014", "Peer Fund"), note="Conformed from DP-014. PII tier: none."),
        dim("Peer Universe", ("DP-014", "Peer Universe"), note="Conformed from DP-014. PII tier: none."),
        ent("Rating Scheme", "Dimension", [("11", "Rating Scheme")], ["Rating Scheme Code"],
            note="No foundational model publishes 11 Rating Scheme. PII tier: none."),
        ent("Fact Rating Observation", "Fact", [("11", "Rating Observation")], ["Rating Observation ID"],
            grain="one row = rating observation of an own share class",
            note="Own Share Class Rating Distribution and Rating Changes in Period. PII tier: none."),
        dim("Fee Schedule", ("DP-305", "Fee Schedule"), [("47", "Fee Schedule")],
            note="Conformed from DP-305: Own Advisory Fee Rate at Balance reads the schedule in force. PII tier: none."),
        dim("Fee Schedule Tier", ("DP-305", "Fee Schedule Tier"), [("47", "Fee Schedule Tier")],
            note="Conformed from DP-305. PII tier: none."),
        dim("Sweep Rate Tier", ("DP-431", "Sweep Rate Tier"), [("50", "Sweep Rate Tier")],
            note="Conformed from DP-431: Cash Sweep Rate Comparison. PII tier: none."),
        dim("Sweep Program", ("DP-431", "Sweep Program"), note="Conformed from DP-431. PII tier: none."),
        dim("Fund Financial Statement", ("DP-165", "Fund Financial Statement"),
            note="Conformed from DP-165. PII tier: none."),
        dim("Financial Highlights", ("DP-165", "Financial Highlights"), [("27", "Financial Highlights")],
            pk=["Fund Financial Statement Key", "Highlights Share Class"],
            note="Conformed from DP-165: Own Net Expense Ratio (from DP-165). Model gap: the group carries no statement "
                 "reference, so it borrows the Fund Financial Statement Key (as DP-165 does). PII tier: none."),
        dim("Share Class", SHARE, [("01", "Share Class"), ("01", "Management Fee"), ("01", "Other Ongoing Fees")],
            note="Conformed from DP-004; Management Fee and Other Ongoing Fees fold here (registry fold). PII tier: none."),
        dim("Service Offering", OFFER, [("01", "Service Offering")], note="Conformed from DP-004. PII tier: none."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=[
        rel("Fact Fee Benchmark", "Share Class", ["Subject Share Class"], optional=True),
        rel("Fact Fee Benchmark", "Service Offering", ["Subject Service Offering"], optional=True),
        rel("Fact Fee Benchmark", "Fee Schedule", ["Subject Fee Schedule"], optional=True),
        rel("Fact Fee Benchmark", "Peer Universe", ["Peer Universe"], optional=True),
        rel("Fact Fee Benchmark", "Competitor Offering", ["Comparison Offerings"], card="M:N", optional=True),
        rel("Fact Fee Benchmark", "Calendar Date", ["Study Date"]),
        rel("Fact Price Observation", "Competitor Offering", ["Priced Offering"]),
        rel("Fact Price Observation", "Calendar Date", ["Observation As-of Date"]),
        rel("Competitor Offering", "Competitor", ["Offering Competitor"]),
        rel("Competitor Offering", "Service Offering", ["Comparable Own Offering"], optional=True),
        rel("Fact Peer Metric Snapshot", "Peer Fund", ["Snapshot Subject"]),
        rel("Fact Peer Metric Snapshot", "Peer Universe", ["Peer Universe"]),
        rel("Fact Rating Observation", "Rating Scheme", ["Rating Scheme"]),
        rel("Fact Rating Observation", "Share Class", ["Rated Share Class / Fund"]),
        rel("Fact Rating Observation", "Calendar Date", ["Rating Date"]),
        rel("Fee Schedule Tier", "Fee Schedule", ["Tier Fee Schedule"]),
        rel("Sweep Rate Tier", "Sweep Program", ["Tier Sweep Program"]),
        rel("Sweep Rate Tier", "Calendar Date", ["Tier Effective From"]),
        rel("Financial Highlights", "Fund Financial Statement", ["Fund Financial Statement Key"]),
        rel("Financial Highlights", "Share Class", ["Highlights Share Class"]),
    ],
    notes="Fee benchmark star at the fee benchmark study, with competitor price observations, peer expense ratios and "
          "own-fund rating observations as companion facts. Competitors and observations are DP-481's, peers DP-014's, "
          "own fee schedules DP-305's, sweep tiers DP-431's, expense ratios DP-165's and share classes and offerings "
          "DP-004's. Model gaps: Peer Metric Snapshot keys without Return Period; Financial Highlights borrows the Fund "
          "Financial Statement Key."
)

# ======================================================================================================================
# DP-510 Institutional Relationship Health & Service
# ======================================================================================================================
_c510, _r510 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Ending Client Assets at Dimension Type Institutional Client x period end x locked "
                    "snapshot",
                    "Institutional Client Assets (from DP-008), read as published (CW-011).")

DP510 = dict(
    style="Star",
    entities=[
        ent("Fact Relationship Health", "Fact", [], ["Fact Relationship Health Key"], measures=True,
            grain="one row = service relationship x month-end (monthly snapshot)",
            note="The relationship health row assembled from the companion facts (requests, reviews, scores, breaches, "
                 "certificates, terminations, onboardings, cash flow notices, surveys and disputes), each kept at its "
                 "own grain. Model gap: no input object holds the relationship x month-end row, so it takes a "
                 "surrogate key and borrows the relationship and calendar keys. PII tier: none at publication."),
        dim("Service Relationship", ("DP-003", "Service Relationship"),
            [("12", "Service Relationship"), ("12", "OCIO Service Detail")],
            note="Conformed from DP-003; OCIO Service Detail folds here (registry fold): OCIO Relationships by "
                 "Delegation. PII tier: none."),
        dim("Institutional Client", ("DP-003", "Institutional Client"), [("12", "Institutional Client")],
            note="Conformed from DP-003. PII tier: none."),
        ent("Institutional Service Tier", "Dimension", [("12", "Institutional Service Tier")], ["Service Tier Code"],
            note="No foundational model publishes 12 Institutional Service Tier: review and reporting cadence by tier. "
                 "PII tier: none."),
        ent("Service Standard", "Dimension", [("12", "Service Standard")], ["Service Standard ID"],
            note="Applies To Tier / Relationship is polymorphic; the REFS target is the tier. PII tier: none."),
        ent("Service Team", "Dimension", [("12", "Service Team")], ["Service Team ID"],
            note="PII tier: identity (the team lead is an employee)."),
        ent("Service Coverage Assignment", "Bridge", [("12", "Service Coverage Assignment")], ["Service Assignment ID"],
            grain="one row = service employee x service relationship x service role x effective period",
            note="Relationships Without Primary Contact. PII tier: identity (service employees)."),
        ent("Fact Service Request", "Fact", [("12", "Client Service Request")], ["Service Request ID"],
            grain="one row = institutional client service request",
            note="Related Complaint (08) stays a degenerate key: the complaint master is not upstream. PII tier: none."),
        ent("Fact Client Review", "Fact", [("12", "Client Review")], ["Client Review ID"],
            grain="one row = client review", note="Reviews Held to Cadence %. PII tier: none."),
        ent("Fact Health Score", "Fact", [("12", "Relationship Health Score")], ["Scored Relationship", "Health Score Date"],
            grain="one row = service relationship x health score date", note="PII tier: none."),
        ent("Guideline Monitoring Arrangement", "Dimension", [("12", "Guideline Monitoring Arrangement")],
            ["Monitored Mandate"], note="The breach notification and certificate terms of a mandate. PII tier: none."),
        ent("Fact Breach Notification", "Fact", [("12", "Breach Notification")], ["Breach Notification ID"],
            grain="one row = guideline breach notification", note="Breach Notifications Late. PII tier: none."),
        ent("Fact Compliance Certificate", "Fact", [("12", "Compliance Certificate")],
            ["Certified Mandate", "Certificate Period End"], grain="one row = mandate x certificate period end",
            note="Compliance Certificates Overdue. Keyed by mandate and period end: the registry key names only the "
                 "period end, which cannot tell two mandates apart. PII tier: none."),
        ent("Fact Mandate Termination", "Fact", [("12", "Mandate Termination")], ["Termination ID"],
            grain="one row = mandate termination notice", note="PII tier: none."),
        ent("Fact Mandate Onboarding", "Fact", [("12", "Mandate Onboarding")], ["Onboarded Mandate", "Onboarding Start Date"],
            grain="one row = mandate x onboarding start date", note="Mandates Funded On Target %. PII tier: none."),
        ent("Fact Cash Flow Notification", "Fact", [("12", "Cash Flow Notification")], ["Cash Flow Notification ID"],
            grain="one row = client cash flow notification",
            note="Cash Flow Notices Outside Controls (notice period and call-back). PII tier: none."),
        ent("Cash Flow Arrangement", "Dimension", [("12", "Cash Flow Arrangement")], ["Arrangement Mandate"],
            note="The notice period and cut-off of a mandate. PII tier: none."),
        ent("Fact Client Custodian Account Set-Up", "Fact", [("12", "Client Custodian Account")],
            ["Client Custodian Account Set-Up ID"], grain="one row = client custodian account set-up",
            note="Custodian Set-Ups Without Standing Instructions; Created Standing Settlement Instructions (26) stays "
                 "degenerate (its master is not upstream). PII tier: none."),
        ent("Fact Client Data Feed", "Fact", [("12", "Client Data Feed")], ["Client Data Feed ID"],
            grain="one row = client data feed", note="Client Data Feeds Without Data-Sharing Agreement. PII tier: none."),
        ent("Fact Survey Response", "Fact", [("04", "Survey Response")], ["Response ID"], grain="one row = survey response",
            note="Institutional Net Promoter Score; individual respondents are read only to aggregate (DQ5). PII tier: "
                 "identity at row level; aggregates only at publication."),
        ent("Fact Billing Dispute", "Fact", [("47", "Billing Dispute")], ["Billing Dispute ID"],
            grain="one row = billing dispute",
            note="Open Billing Disputes (from DP-305); institutional billing is 47 (CW-246). PII tier: financial at row "
                 "level; counts only at publication."),
        dim("Fee Invoice", ("DP-305", "Fee Invoice"), note="Conformed from DP-305. PII tier: financial (invoice amounts)."),
        dim("Fact Attributed Client Assets", ("DP-007", "Attribution Record"),
            [("06", "Attribution Record"), ("06", "Market & Client Dimensions")], role="Fact",
            grain="one row = attribution record of an account summary to an institutional client",
            note="Relationship Client Assets; conformed from DP-007 because the product reads the attributed amount but "
                 "not the record key. Market & Client Dimensions folds here. Institutional Client is the only client key "
                 "on attributed assets (spec taxonomy gap). PII tier: none."),
        dim("Fact Account Asset Summary", ("DP-007", "Account Asset Summary"), [("06", "Account Asset Summary")],
            role="Fact", grain="one row = account x as-of date x holding type",
            note="Conformed from DP-007 for its key: the summary an attribution reads, dated by Summary As-Of Date. PII "
                 "tier: financial at row level; none at publication."),
        dim("Investment Mandate", ("DP-003", "Investment Mandate"), note="Conformed from DP-003. PII tier: none."),
        dim("Investment Policy Statement", ("DP-003", "Investment Policy Statement"),
            note="Conformed from DP-003. PII tier: none."),
        dim("Consultant Advisory Relationship", ("DP-003", "Consultant Advisory Relationship"),
            note="Conformed from DP-003: the advising consultant engagement of a relationship. PII tier: none."),
        dim("Sub-Adviser Engagement", ("DP-306", "Sub-Adviser Engagement"), note="Conformed from DP-306. PII tier: none."),
        dim("Service Offering", OFFER, note="Conformed from DP-004. PII tier: none."),
        dim("Employee", EMP192, note="Conformed from DP-192: service employees and team leads. PII tier: identity "
                                     "(employee); personal-detail columns of the master are not served."),
        dim("Party", ("DP-003", "Party"),
            note="Conformed from DP-003: client, custodian, feed recipient and survey respondent parties. PII tier: "
                 "identity (individual respondents and signatories)."),
        dim("Client Account", ACCT, note="Conformed from DP-093. PII tier: identity (account keys)."),
        dim("Distribution Agreement", AGREE, note="Conformed from DP-005: data-sharing agreements. PII tier: none."),
        _c510,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r510 + [
        rel("Fact Relationship Health", "Service Relationship", ["Service Relationship Key"]),
        rel("Fact Relationship Health", "Calendar Date", ["Calendar Date Key"], note="The month-end."),
        rel("Service Relationship", "Institutional Client", ["Client"]),
        rel("Service Relationship", "Institutional Service Tier", ["Service Tier"], optional=True,
            note="Service Tier is a code matched to the tier code."),
        rel("Service Relationship", "Consultant Advisory Relationship", ["Advising Consultant"], optional=True),
        rel("Service Relationship", "Investment Mandate", ["Serviced Mandates"], card="M:N", optional=True),
        rel("Service Relationship", "Service Offering", ["OCIO Service Offering"], optional=True),
        rel("Service Relationship", "Sub-Adviser Engagement", ["Managers in Scope"], card="M:N", optional=True),
        rel("Service Relationship", "Investment Policy Statement", ["Governing IPS"], optional=True),
        rel("Institutional Client", "Party", ["Institutional Client Party"]),
        rel("Service Standard", "Institutional Service Tier", ["Applies To Tier / Relationship"], optional=True),
        rel("Service Team", "Employee", ["Service Team Lead"]),
        rel("Service Coverage Assignment", "Employee", ["Assigned Service Employee"]),
        rel("Service Coverage Assignment", "Service Relationship", ["Covered Service Relationship"]),
        rel("Service Coverage Assignment", "Service Team", ["Service Team"], optional=True),
        rel("Fact Service Request", "Service Relationship", ["Request Service Relationship"]),
        rel("Fact Client Review", "Service Relationship", ["Reviewed Relationship"]),
        rel("Fact Client Review", "Calendar Date", ["Review Held Date"]),
        rel("Fact Health Score", "Service Relationship", ["Scored Relationship"]),
        rel("Fact Health Score", "Calendar Date", ["Health Score Date"]),
        rel("Guideline Monitoring Arrangement", "Investment Mandate", ["Monitored Mandate"], card="1:1"),
        rel("Fact Breach Notification", "Investment Mandate", ["Breached Mandate"]),
        rel("Fact Breach Notification", "Calendar Date", ["Breach Detected Date"]),
        rel("Fact Compliance Certificate", "Investment Mandate", ["Certified Mandate"]),
        rel("Fact Mandate Termination", "Investment Mandate", ["Terminated Mandate"]),
        rel("Fact Mandate Onboarding", "Investment Mandate", ["Onboarded Mandate"]),
        rel("Fact Mandate Onboarding", "Service Relationship", ["Onboarding Service Relationship"], optional=True),
        rel("Fact Cash Flow Notification", "Investment Mandate", ["Notified Mandate"]),
        rel("Cash Flow Arrangement", "Investment Mandate", ["Arrangement Mandate"], card="1:1"),
        rel("Fact Client Custodian Account Set-Up", "Client Account", ["Client Account"], optional=True),
        rel("Fact Client Custodian Account Set-Up", "Investment Mandate", ["Client Custodian Mandate"], optional=True),
        rel("Fact Client Custodian Account Set-Up", "Party", ["Custodian"]),
        rel("Fact Client Data Feed", "Party", ["Feed Recipient"]),
        rel("Fact Client Data Feed", "Distribution Agreement", ["Data-Sharing Agreement"], optional=True),
        rel("Fact Survey Response", "Party", ["Respondent Party"]),
        rel("Fact Billing Dispute", "Fee Invoice", ["Disputed Invoice"]),
        rel("Fee Invoice", "Party", ["Invoice Bill-To Party"], optional=True),
        rel("Fact Attributed Client Assets", "Institutional Client", ["Institutional Client"]),
        rel("Fact Attributed Client Assets", "Fact Account Asset Summary", ["Source Account Asset Summary"]),
        rel("Fact Account Asset Summary", "Calendar Date", ["Summary As-Of Date"]),
    ],
    notes="Relationship health star at service relationship x month-end, with requests, reviews, health scores, "
          "breaches, certificates, terminations, onboardings, cash flow notices, custodian set-ups, data feeds, surveys "
          "and billing disputes as companion facts at their own grain. Relationships, clients, mandates, consultants and "
          "parties are DP-003's, employees DP-192's, billing DP-305's, attributed assets DP-007's and the certified "
          "institutional client assets DP-008's. Facts conformed for their keys: Attribution Record and Account Asset "
          "Summary (DP-007). Model gap: Fact Relationship Health has no backing object (surrogate key, borrowed "
          "relationship and calendar keys)."
)

# ======================================================================================================================
# DP-511 Institutional & OCIO Client Reporting Delivery
# ======================================================================================================================
DP511 = dict(
    style="Star",
    entities=[
        ent("Fact Report Run", "Fact", [("12", "Report Run")], ["Report Run ID"], measures=True,
            grain="one row = report run (report package or definition x reporting period end x version), every version "
                  "kept",
            note="The main output. Compliance Review (08) and Commentary Used (01) stay degenerate keys (their masters "
                 "are not upstream); no link to the Performance Return versions shown (spec taxonomy gap), so the close "
                 "group of the package's mandates is used. PII tier: identity (sign-off employee)."),
        ent("Report Definition", "Dimension", [("12", "Report Definition")], ["Report Definition ID"],
            note="No foundational model publishes 12 reporting objects. PII tier: none."),
        ent("Report Component", "Dimension", [("12", "Report Component")], ["Component ID"],
            note="Commentary Missing on Delivered Runs reads the mandatory and commentary-required components. Model gap: "
                 "the component carries no definition reference in the inputs, so it borrows the Report Definition Key. "
                 "PII tier: none."),
        ent("Report Template", "Dimension", [("12", "Report Template")], ["Template ID"], note="PII tier: none."),
        ent("Report Package", "Dimension", [("12", "Report Package"), ("12", "Report Schedule")], ["Report Package ID"],
            note="Report Schedule folds here (registry fold): cut-off and due offsets under the business calendar. "
                 "Covered Mandates / Vehicles is polymorphic; the REFS target is the mandate. PII tier: none."),
        ent("Presentation Profile", "Dimension", [("12", "Presentation Profile"), ("12", "Portfolio Holdings Presentation")],
            ["Presentation Profile ID"],
            note="Incomplete Presentation Profiles and Holdings Disclosure Settings Outside Policy; Portfolio Holdings "
                 "Presentation folds here (registry fold). PII tier: none."),
        ent("Fact GIPS Report Provision", "Fact", [("12", "GIPS Report Provision")],
            ["Report Definition Key", "Related GIPS Composite"], grain="one row = report definition x GIPS composite",
            note="GIPS Reports Not Current. Model gap: the group carries no Report Definition ID, so it borrows the "
                 "Report Definition Key; Related GIPS Composite (01) stays degenerate (no upstream model publishes it). "
                 "PII tier: none."),
        ent("Distribution List", "Bridge", [("12", "Distribution List")], ["Distribution List ID"],
            grain="one row = report package x recipient x delivery channel",
            note="Packages Without Recipients. PII tier: identity (recipients at institutional clients)."),
        ent("Fact Report Delivery", "Fact", [("12", "Report Delivery")], ["Delivered Run", "Delivery Recipient"],
            grain="one row = report run x recipient",
            note="Delivery completeness, failed and recalled deliveries. PII tier: identity (recipients)."),
        ent("Fact Transition Event", "Fact", [("12", "Transition Event")], ["Transition ID"],
            grain="one row = mandate transition event", note="Post-Transition Reports Outstanding. PII tier: none."),
        dim("Performance Period Close", ("DP-145", "Performance Period Close"), [("32", "Performance Period Close")],
            note="Conformed from DP-145: Reports Produced Before Performance Close. PII tier: none."),
        dim("Fact Performance Return", ("DP-145", "Performance Return"), [("32", "Performance Return")], role="Fact",
            grain="one row = performance return x return version",
            note="Conformed from DP-145 because the product reads the return's status but not Return Version of the key. "
                 "PII tier: none."),
        dim("Service Relationship", ("DP-003", "Service Relationship"), note="Conformed from DP-003. PII tier: none."),
        dim("Investment Mandate", ("DP-003", "Investment Mandate"), note="Conformed from DP-003. PII tier: none."),
        dim("Party", ("DP-003", "Party"),
            note="Conformed from DP-003, which holds the 02 Retirement Plan: recipients and covered plans. PII tier: "
                 "identity (report recipients)."),
        dim("Benchmark", ("DP-145", "Benchmark"), note="Conformed from DP-145. PII tier: none."),
        dim("Employee", EMP192, note="Conformed from DP-192: sign-off employees. PII tier: identity (employee)."),
        dim("Business Calendar", ("DP-013", "Calendar"), note="Conformed from DP-013 (09 Calendar). PII tier: none."),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=[
        rel("Fact Report Run", "Report Package", ["Run Package / Report"]),
        rel("Fact Report Run", "Employee", ["Signed Off By"], optional=True),
        rel("Fact Report Run", "Calendar Date", ["Reporting Period End"]),
        rel("Report Definition", "Report Template", ["Report Template"], optional=True),
        rel("Report Component", "Report Definition", ["Report Definition Key"]),
        rel("Report Package", "Service Relationship", ["Package Client"]),
        rel("Report Package", "Report Definition", ["Included Report Definitions"], card="M:N"),
        rel("Report Package", "Investment Mandate", ["Covered Mandates / Vehicles"], card="M:N", optional=True),
        rel("Report Package", "Party", ["Covered Retirement Plans"], card="M:N", optional=True),
        rel("Report Package", "Business Calendar", ["Business Calendar"], optional=True),
        rel("Presentation Profile", "Report Package", ["Applies To Package / Mandate"]),
        rel("Presentation Profile", "Benchmark", ["Primary Benchmark Shown"], optional=True),
        rel("Fact GIPS Report Provision", "Report Definition", ["Report Definition Key"]),
        rel("Distribution List", "Report Package", ["Distribution Package"]),
        rel("Distribution List", "Party", ["Recipient"]),
        rel("Fact Report Delivery", "Fact Report Run", ["Delivered Run"]),
        rel("Fact Report Delivery", "Party", ["Delivery Recipient"]),
        rel("Fact Transition Event", "Investment Mandate", ["Transition Mandate"]),
        rel("Fact Transition Event", "Calendar Date", ["Actual Completion Date"], optional=True),
        rel("Performance Period Close", "Calendar Date", ["Close Period End Date"]),
        rel("Fact Performance Return", "Calendar Date", ["Return Period End Date"]),
    ],
    notes="Reporting delivery star at the report run, with deliveries, presentation profiles, GIPS provisions, "
          "transitions and performance closes as companion facts. Relationships, mandates and recipients are DP-003's, "
          "official returns and closes DP-145's, employees DP-192's. Fact Performance Return is conformed from DP-145 "
          "for its key. Model gaps: Report Component and GIPS Report Provision borrow the Report Definition Key."
)

# ======================================================================================================================
# DP-514 Plan Sponsor Servicing & Plan Reviews
# ======================================================================================================================
_c514, _r514 = cert("Fact Certified Client Assets", [MV, CAM],
                    "one row = DP-008 Ending Client Assets at the workplace dimension x period end x locked snapshot",
                    "Workplace Client Assets (from DP-008), read as published (CW-011).")

DP514 = dict(
    style="Star",
    entities=[
        ent("Fact Plan Servicing", "Fact", [("12", "Plan Sponsor Servicing Detail")],
            ["Sponsor Service Relationship", "Serviced Retirement Plan"], measures=True,
            grain="one row = recordkept plan x plan sponsor service relationship x quarter-end (monthly refresh)",
            note="The main output: the servicing terms of each recordkept plan under its sponsor relationship. PII "
                 "tier: none."),
        dim("Service Relationship", ("DP-003", "Service Relationship"), [("12", "Service Relationship")],
            note="Conformed from DP-003. PII tier: none."),
        dim("Institutional Client", ("DP-003", "Institutional Client"), note="Conformed from DP-003. PII tier: none."),
        ent("Fact Plan Review", "Fact", [("12", "Client Review")], ["Client Review ID"], grain="one row = plan review",
            note="Plan Reviews Held to Cadence %; tied to the plan through the sponsor relationship (spec taxonomy gap). "
                 "PII tier: none."),
        ent("Fact Sponsor Request", "Fact", [("12", "Client Service Request")], ["Service Request ID"],
            grain="one row = sponsor service request", note="Open Sponsor Requests Past Standard. PII tier: none."),
        ent("Service Coverage Assignment", "Bridge", [("12", "Service Coverage Assignment")],
            ["Assigned Service Employee", "Covered Service Relationship", "Assignment Effective From"],
            grain="one row = service employee x service relationship x effective period",
            note="Plans Without Primary Relationship Manager. Model gap: the registry key Service Assignment ID is not in "
                 "the inputs, so the bridge keys on employee, relationship and effective date; Assigned Service Employee "
                 "stays a degenerate key (no employee master is upstream). PII tier: identity (service employees)."),
        dim("Plan Sponsor Profile", ("DP-003", "Plan Sponsor Profile"), [("16", "Plan Sponsor Profile")],
            note="Conformed from DP-003. PII tier: none."),
        dim("Service Arrangement", ("DP-094", "Service Arrangement"), [("16", "Service Arrangement")],
            note="Conformed from DP-094: the recordkeeping arrangement of the plan. PII tier: none."),
        dim("Plan Investment Option", ("DP-094", "Plan Investment Option"), [("16", "Plan Investment Option")],
            note="Conformed from DP-094: Active Menu Options and Line-Up Changes. PII tier: none."),
        ent("Fact Fund Change Event", "Fact", [("16", "Fund Change Event")], ["Fund Change ID"],
            grain="one row = plan fund change event", note="PII tier: none."),
        dim("Participant", ("DP-094", "Participant"), [("16", "Participant Plan Membership")],
            note="Conformed from DP-094: Active Participants and New Participants by Enrollment Method, counted only. "
                 "PII tier: identity at row level; aggregates only at publication."),
        dim("Fact Participant Balance", ("DP-430", "Participant Balance"), [("16", "Participant Balance")], role="Fact",
            grain="one row = participant membership x contribution source x investment option x valuation date",
            note="Plan Assets Recordkept (from DP-430); conformed because the product reads the market value but not "
                 "Balance Contribution Source and Balance Investment Option of the key. The 16 participant ledger is its "
                 "own book, never joined to a 49 client holding. PII tier: financial at row level; plan totals only at "
                 "publication."),
        ent("Fact Plan Conversion", "Fact", [("16", "Plan Conversion")], ["Conversion ID"], grain="one row = plan conversion",
            note="Plan Conversions In Progress and Blackout Notices Sent Late. PII tier: none."),
        dim("Retirement Plan", ("DP-094", "Retirement Plan"), note="Conformed from DP-094. PII tier: none."),
        dim("Plan Role Assignment", ("DP-094", "Plan Role Assignment"),
            note="Conformed from DP-094: the plan fiduciary committee. PII tier: identity (plan fiduciaries can be "
                 "individuals); not published at row level."),
        dim("Party", ("DP-003", "Party"), note="Conformed from DP-003: sponsor and institutional client parties. PII "
                                               "tier: none."),
        dim("Share Class", SHARE, note="Conformed from DP-004. PII tier: none."),
        _c514,
        dim("Snapshot", SNAP, [("06", "Snapshot")], note=SNAP_NOTE),
        dim("Measure Definition", MDEF, note=MDEF_NOTE),
        dim("Calendar Date", CAL, note=CAL_NOTE),
    ],
    relationships=_r514 + [
        rel("Fact Plan Servicing", "Service Relationship", ["Sponsor Service Relationship"]),
        rel("Fact Plan Servicing", "Retirement Plan", ["Serviced Retirement Plan"]),
        rel("Fact Plan Servicing", "Service Arrangement", ["Recordkeeping Service Arrangement"], optional=True),
        rel("Fact Plan Servicing", "Plan Role Assignment", ["Plan Fiduciary Committee"], optional=True),
        rel("Service Relationship", "Institutional Client", ["Client"]),
        rel("Institutional Client", "Party", ["Institutional Client Party"]),
        rel("Plan Sponsor Profile", "Party", ["Sponsor Party"]),
        rel("Fact Plan Review", "Service Relationship", ["Reviewed Relationship"]),
        rel("Fact Plan Review", "Calendar Date", ["Review Held Date"]),
        rel("Fact Sponsor Request", "Service Relationship", ["Request Service Relationship"]),
        rel("Service Coverage Assignment", "Service Relationship", ["Covered Service Relationship"]),
        rel("Service Arrangement", "Retirement Plan", ["Arrangement Plan"]),
        rel("Plan Investment Option", "Retirement Plan", ["Menu Plan"]),
        rel("Plan Investment Option", "Share Class", ["Offered Share Class"], optional=True),
        rel("Fact Fund Change Event", "Retirement Plan", ["Change Plan"]),
        rel("Fact Fund Change Event", "Calendar Date", ["Mapping Effective Date"]),
        rel("Participant", "Retirement Plan", ["Membership Plan"]),
        rel("Fact Participant Balance", "Participant", ["Balance Membership"]),
        rel("Fact Participant Balance", "Plan Investment Option", ["Balance Investment Option"], optional=True),
        rel("Fact Participant Balance", "Calendar Date", ["Valuation Date"]),
        rel("Fact Plan Conversion", "Retirement Plan", ["Converted Plan"]),
    ],
    notes="Plan sponsor servicing star at recordkept plan x sponsor relationship x quarter-end, with plan reviews, "
          "sponsor requests, fund changes, conversions and participation aggregates as companion facts. Plans, "
          "arrangements, menus, participants and conversions are DP-094's, balances DP-430's, sponsor relationships and "
          "profiles DP-003's and the certified workplace client assets DP-008's. Fact Participant Balance is conformed "
          "from DP-430 for its key. Model gap: Service Coverage Assignment keys without its registry ID (not in the "
          "inputs)."
)


MODELS = _tiers({
    "DP-505": DP505, "DP-487": DP487, "DP-486": DP486, "DP-488": DP488, "DP-491": DP491, "DP-492": DP492,
    "DP-493": DP493, "DP-495": DP495, "DP-496": DP496, "DP-497": DP497, "DP-498": DP498, "DP-499": DP499,
    "DP-490": DP490, "DP-503": DP503, "DP-506": DP506, "DP-510": DP510, "DP-511": DP511, "DP-514": DP514,
}, {
    "DP-505": "none", "DP-487": "none", "DP-486": "identity", "DP-488": "identity", "DP-491": "identity",
    "DP-492": "none", "DP-493": "none", "DP-495": "none", "DP-496": "none", "DP-497": "none", "DP-498": "financial",
    "DP-499": "financial", "DP-490": "none", "DP-503": "none", "DP-506": "none", "DP-510": "none", "DP-511": "none",
    "DP-514": "none",
})
