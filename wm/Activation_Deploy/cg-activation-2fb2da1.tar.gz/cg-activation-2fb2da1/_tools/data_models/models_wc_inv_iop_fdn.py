"""Logical data models, WP2 consumer wave, group B5 'INV, IOP and FDN': Star models for DP-531, DP-532, DP-533, DP-535,
DP-536, DP-538, DP-544, DP-515, DP-516 and DP-518 (specs in data_products/specs_w1c_inv_iop_fdn.py). DP-044 and DP-130
keep their existing models. See CONTRACT.md.

Conventions used in these stars:
- Conformed dimensions reuse the foundational entity named in `conformed` and are named for their role here. Where a
  foundational model publishes the very object a fact is built on (DP-145 Personal Rate of Return, DP-306 Sub-Adviser
  Engagement, DP-530 Model Lineup Position), the fact is conformed too, so the consumer reads the published row and
  never re-derives it; elsewhere facts are built from the product's own inputs so they do not pull in columns (for
  example account or quantity columns) the product must not publish.
- Where a reference attribute's REFS target is held by the parent (directly or through its conformed source), the
  attribute itself is the foreign key. Where no input attribute carries the link, the child borrows "<Parent> Key" and
  the note records a "Model gap".
- Date roles are conformed from DP-013 Calendar Date (firm business calendar); a date attribute on a fact is the
  foreign key. Snapshot dates that no input carries are borrowed as "As-Of Date Key" / "Publication Date Key".
- Investment Committee Decision is published by DP-530, but only DP-531 lists DP-530 upstream; DP-535, DP-536 and
  DP-538 read decisions through DP-126 (consumer), so they hold their own decision dimension on the registry key.
- Multi-valued references (e.g. Included Oversight Reviews, Linked Investment Breaches) are drawn as M:N relationships;
  the build explodes them into one row per referenced member.
"""


def dim(name, src, objects=(), note="", role="Dimension", grain="", measures=False):
    """A conformed entity: inherits the attributes and key of entity src = (pid, entity)."""
    d = dict(name=name, role=role, conformed=src, objects=list(objects), note=note, measures=measures)
    if grain:
        d["grain"] = grain
    return d


def own(name, objects, pk, role="Dimension", grain="", note="", measures=False):
    d = dict(name=name, role=role, objects=list(objects), pk=list(pk), note=note, measures=measures)
    if grain:
        d["grain"] = grain
    return d


def rel(child, parent, fk, card="M:1", optional=False, note=""):
    return dict(child=child, parent=parent, fk=list(fk), card=card, optional=optional, note=note)


CAL = ("DP-013", "Calendar Date")
INSTR = ("DP-097", "Instrument")
PROD = ("DP-004", "Investment Product")
SHARE = ("DP-004", "Share Class")
EMP192 = ("DP-192", "Employee")
MANAGER = ("DP-306", "Manager")
EMSTR = ("DP-306", "External Manager Strategy")
SAE = ("DP-306", "Sub-Adviser Engagement")
MANDATE = ("DP-306", "Investment Mandate")
ACCT = ("DP-093", "Account")
PARTY240 = ("DP-240", "Party")

ICD_NOTE = ("Own dimension on the registry key: DP-530 publishes Investment Committee Decision but is not in this "
            "product's upstream (decisions are read through DP-126, a consumer product). No PII.")

MODELS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-531": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Fact Lineup Position", ("DP-530", "Model Lineup Position"), [("24", "Model Lineup Position")],
                role="Fact", measures=True,
                grain="one row = model lineup version x lineup position (01 model portfolio) x as-of date (daily "
                      "snapshot, every lineup version kept)",
                note="Conformed from DP-530 so the position is read as published, never remastered. Holds the measures "
                     "because every lineup, drift and band test is stated per position; the model's equity weight comes "
                     "from Fact Target Allocation Line through the position's model portfolio. No PII."),
            dim("Fact Target Allocation Line", ("DP-530", "Target Allocation Line"), [("24", "Target Allocation Line")],
                role="Fact", grain="one row = target allocation set x component (instrument or asset class line)",
                note="The model's effective weights (Model Equity Weight); conformed from DP-530 and read, never "
                     "recomputed. Asset class of an instrument line resolves through Instrument. No PII."),
            dim("Fact Model Building Block", ("DP-530", "Model Building Block"), [("24", "Model Building Block")],
                role="Fact",
                grain="one row = model portfolio x vehicle (share class or instrument) x building block role x "
                      "effective period",
                note="Building Block Product List Status is DP-530's derived copy of DP-306's list status (CW-250, "
                     "CW-254); it is tied out here against Product List Status, never treated as the master. No PII."),
            own("Fact Allocation Policy Line", [("24", "Asset Allocation Policy Line")],
                ["Line Allocation Policy", "Policy Asset Class"], role="Fact",
                grain="one row = asset allocation policy version x asset class (sub-class not read)",
                note="Neutral, minimum and maximum weights for the Policy Band Breaches test. Model gap: Policy Sub-Class "
                     "(part of the registry key) is not a spec input; the lineup policies are set at asset class "
                     "level. No PII."),
            own("Fact Glide Path Point", [("24", "Glide Path Point")],
                ["Glide Path Policy", "Years to Target Date", "Glide Path Asset Class"], role="Fact",
                grain="one row = glide path policy version x years to target date x asset class (sub-class not read)",
                note="Glide Path Drift compares a position's Years to Retirement Position with the nearest point. "
                     "Model gap: Glide Path Sub-Class (registry key) is not a spec input. No PII."),
            # -- dimensions
            dim("Model Lineup", ("DP-530", "Model Lineup"), [("24", "Model Lineup")],
                note="Conformed lineup and version, carrying Model Lineup Purpose. Model Lineup ID is flagged PII only "
                     "because its note reads 'Object PII tier: No PII'; PII tier: none."),
            dim("Capital Market Assumption Set", ("DP-530", "Capital Market Assumption Set"),
                [("24", "Capital Market Assumption Set")],
                note="Conformed CMA set and version; CMA Sets Stale or Unapproved is read as DP-530 publishes it. "
                     "Capital Market Assumption Set ID is flagged PII only by its 'No PII' note; PII tier: none."),
            own("Asset Allocation Policy", [("24", "Asset Allocation Policy")],
                ["Policy Model Portfolio", "Policy Version Number"],
                note="Own dimension: asset allocation policies and glide paths are DP-127's (consumer), so no "
                     "foundational model publishes them. Model gap: the registry key also names Policy Strategy and "
                     "Policy Product, which are not spec inputs; lineup policies are model-portfolio policies, so the "
                     "model portfolio and version identify the row (taxonomy gap: no single policy key). No PII."),
            dim("Target Allocation Set", ("DP-530", "Target Allocation Set"), [("24", "Target Allocation Set")],
                note="The model's effective target set version (Target Set Status Effective). No PII."),
            dim("Investment Committee Decision", ("DP-530", "Investment Committee Decision"),
                [("24", "Investment Committee Decision")],
                note="Conformed from DP-530: one dimension serves the CMA, lineup and policy approvals by Committee "
                     "Decision Type. No PII."),
            dim("Model Portfolio", ("DP-530", "Model Portfolio"), [("01", "Model Portfolio")]),
            dim("Offering", ("DP-004", "Service Offering"), note="The lineup's service offering (advice program)."),
            dim("Instrument", INSTR, [("17", "Instrument")], note="Asset Class of instrument lines and building blocks."),
            dim("Share Class", SHARE, note="Own share class building blocks; read for the key only."),
            dim("Product List Status", ("DP-306", "Product List Status"), [("52", "Product List Status")],
                note="DP-306's list status master (CW-254), effective dated; the source of truth for the building "
                     "block list status tie-out. Listed Instrument is flagged PII only by its 'No PII' note."),
            dim("Generating Model", ("DP-212", "Model"), [("37", "Model Inventory Entry")],
                note="The 37 model that generated the CMA set (CMA Sets With Inactive Generating Model)."),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Lineup Position", "Model Lineup", ["Position Model Lineup"]),
            rel("Fact Lineup Position", "Model Portfolio", ["Position Model Portfolio"]),
            rel("Fact Lineup Position", "As-Of Date", ["As-Of Date Key"],
                note="Daily snapshot date. Model gap: the position carries no as-of date."),
            rel("Model Lineup", "Offering", ["Lineup Service Offering"]),
            rel("Model Lineup", "Asset Allocation Policy", ["Lineup Allocation Policy"], optional=True,
                note="Resolves by model portfolio and Policy Version Number (taxonomy gap: no single policy key)."),
            rel("Model Lineup", "Capital Market Assumption Set", ["Lineup CMA Set"]),
            rel("Model Lineup", "Investment Committee Decision", ["Lineup Approving Committee Decision"], optional=True),
            rel("Capital Market Assumption Set", "Generating Model", ["CMA Generating Model"], optional=True,
                note="Blank for a licensed vendor set (tailoring lever)."),
            rel("Capital Market Assumption Set", "Investment Committee Decision", ["CMA Approving Committee Decision"],
                optional=True),
            rel("Asset Allocation Policy", "Model Portfolio", ["Policy Model Portfolio"]),
            rel("Asset Allocation Policy", "Capital Market Assumption Set", ["Policy CMA Set"], optional=True),
            rel("Asset Allocation Policy", "Investment Committee Decision", ["Approving Committee Decision"],
                optional=True),
            rel("Fact Allocation Policy Line", "Asset Allocation Policy", ["Line Allocation Policy"]),
            rel("Fact Glide Path Point", "Asset Allocation Policy", ["Glide Path Policy"]),
            rel("Target Allocation Set", "Model Portfolio", ["Target Model Portfolio"]),
            rel("Target Allocation Set", "Asset Allocation Policy", ["Governing Allocation Policy"], optional=True),
            rel("Fact Target Allocation Line", "Target Allocation Set", ["Line Target Set"]),
            rel("Fact Target Allocation Line", "Instrument", ["Target Instrument"], optional=True),
            rel("Fact Model Building Block", "Model Portfolio", ["Building Block Model Portfolio"]),
            rel("Fact Model Building Block", "Share Class", ["Building Block Share Class"], optional=True),
            rel("Fact Model Building Block", "Instrument", ["Building Block Instrument"], optional=True),
            rel("Product List Status", "Instrument", ["Listed Instrument"]),
        ],
        notes=("Lineup governance star over DP-530's masters: the lineup, CMA set, target set, building block and "
               "decision entities are conformed from DP-530 and the list status from DP-306, so this product decides "
               "with them and remasters nothing. Asset allocation policies and glide paths are DP-127's (consumer) and "
               "held as own entities on the keys the spec reads (Model gaps above). Account drift (46) is not modeled "
               "here; lineup drift is the model's own weights against the lineup design. No personal data in any "
               "entity; the three PII flags are the 'No PII' note false positives the spec records.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-532": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Fact Personal Return", ("DP-145", "Personal Rate of Return"), [("32", "Personal Rate of Return")],
                role="Fact", measures=True,
                grain="one row = personal return subject (15 account or 32 household performance group) x period start "
                      "x period end x method x fee basis x version, as displayed on the snapshot (publication) date; "
                      "monthly snapshots, every displayed version kept",
                note="Conformed from DP-145 so Personal Return Value and its inputs (beginning and ending values, flows, "
                     "fees) are read exactly as published; the return methodology is pinned and nothing is recomputed "
                     "(CW-251). Ending Market Value is DP-145's derived copy of the 49 book; no 49 entity is joined. "
                     "Holds the measures. PII tier: financial (account and household returns, values, flows and fees)."),
            dim("Fact Comparison Benchmark Return", ("DP-145", "Benchmark Return"), [("32", "Benchmark Return")],
                role="Fact",
                grain="one row = 01 benchmark x period start x period end x return type x currency x hedged basis x "
                      "version",
                note="Companion fact. Matches a personal return through the profile's Client Comparison Benchmark and "
                     "the period dates; Personal Return Less Comparison Benchmark is a presentation difference of two "
                     "certified DP-145 numbers. No PII."),
            dim("Fact Client Return Exception", ("DP-145", "Client Return Exception"), [("32", "Client Return Exception")],
                role="Fact", grain="one row = 15 account x exception date x exception type",
                note="Read for the suppression label and Preliminary Returns Withheld; the workflow is DP-533's. PII "
                     "tier: financial."),
            # -- dimensions and bridges
            dim("Client Performance Profile", ("DP-145", "Client Performance Profile"),
                [("32", "Client Performance Profile")],
                note="SCD on Client Profile Effective From (taxonomy gap: no end date, so the profile in force is the "
                     "latest on or before the period end). Carries Return Suppression Reason and the comparison "
                     "benchmark. PII tier: financial."),
            dim("Household Performance Group", ("DP-145", "Household Performance Group"),
                [("32", "Household Performance Group")],
                note="DP-145's performance grouping of a Client Household; not the 13 mailing, 46 managed or 47 fee "
                     "household. PII tier: financial (household grouping)."),
            dim("Household Performance Group Member", ("DP-145", "Household Performance Group Member"),
                [("32", "Household Performance Group Member")], role="Bridge",
                grain="one row = household performance group x 15 account x inclusion period",
                note="Many-to-many, effective dated, so Household Group Members Shown counts the accounts in a group on "
                     "the period end. PII tier: financial."),
            dim("Performance Calculation Policy", ("DP-145", "Performance Calculation Policy"),
                [("32", "Performance Calculation Policy")],
                note="The 'how computed' disclosure (cash flow timing, large flow threshold). No PII."),
            dim("Benchmark", ("DP-145", "Benchmark"), [("01", "Benchmark")]),
            dim("Client Account", ACCT, [("15", "Account")],
                note="Account type, status and business line. PII tier: identity (Account ID)."),
            dim("Account Party Role", ("DP-093", "Account Party Role"), [("15", "Account Party Role")], role="Bridge",
                grain="one row = account x party x account role type x role effective period",
                note="Account-to-owner bridge (Primary Owner, Joint Owner), the first leg of the account-to-household "
                     "path; never a household column on the account. PII tier: identity."),
            dim("Account Holder", PARTY240, note="The owner party of an account and the member party of a household. "
                                                 "PII tier: identity."),
            dim("Household", PARTY240,
                note="The 02 Client Household (Party Type Household, PTY-HH-), conformed from DP-240. PII tier: "
                     "identity."),
            dim("Household Membership", ("DP-240", "Household Membership"), [("02", "Household Membership")],
                role="Bridge", grain="one row = client household x member party x membership effective period",
                note="Household-to-member bridge, effective dated. PII tier: identity."),
            dim("Advisor Coverage", ("DP-009", "Coverage Assignment"), [("03", "Party Coverage Assignment")],
                role="Bridge",
                grain="one row = covered party or account x covering advisor x coverage role x coverage period",
                note="Advisor of record and row-level entitlement, applied with the account, client, household "
                     "precedence. PII tier: identity."),
            dim("Advisor", ("DP-009", "Employee"), note="The 03 Advisor of record. PII tier: identity (employee)."),
            dim("Period End Date", CAL),
            dim("Publication Date", CAL),
        ],
        relationships=[
            rel("Fact Personal Return", "Client Account", ["Personal Return Account"], optional=True,
                note="Set when Personal Return Subject Type is Account."),
            rel("Fact Personal Return", "Household Performance Group", ["Personal Return Group"], optional=True,
                note="Set when the subject is a household performance group."),
            rel("Fact Personal Return", "Fact Personal Return", ["Supersedes Personal Return"], optional=True,
                note="Restated Returns Displayed: the version a displayed return replaced."),
            rel("Fact Personal Return", "Period End Date", ["Personal Return Period End Date"]),
            rel("Fact Personal Return", "Publication Date", ["Publication Date Key"],
                note="Model gap (taxonomy gap in the spec): 32 Personal Rate of Return has no publication date, so the "
                     "displayed version is recorded by this product's snapshot date."),
            rel("Fact Comparison Benchmark Return", "Benchmark", ["Return Benchmark"]),
            rel("Fact Client Return Exception", "Client Account", ["Exception Account"]),
            rel("Client Performance Profile", "Client Account", ["Client Profile Account"], optional=True),
            rel("Client Performance Profile", "Household Performance Group", ["Client Profile Group"], optional=True),
            rel("Client Performance Profile", "Benchmark", ["Client Comparison Benchmark"], optional=True),
            rel("Client Performance Profile", "Performance Calculation Policy", ["Client Applied Calculation Policy"]),
            rel("Household Performance Group", "Household", ["Group Household"]),
            rel("Household Performance Group Member", "Household Performance Group", ["Member Performance Group"]),
            rel("Household Performance Group Member", "Client Account", ["Member Account"]),
            rel("Account Party Role", "Client Account", ["Role Account"]),
            rel("Account Party Role", "Account Holder", ["Role Party"]),
            rel("Household Membership", "Household", ["Household"]),
            rel("Household Membership", "Account Holder", ["Household Member"]),
            rel("Advisor Coverage", "Client Account", ["Covered Account"], optional=True),
            rel("Advisor Coverage", "Account Holder", ["Covered Party"], optional=True,
                note="A household-level assignment carries the household's Party ID, which resolves in Household on "
                     "the same key."),
            rel("Advisor Coverage", "Advisor", ["Covering Advisor"]),
        ],
        notes=("Presentation star over DP-145's certified personal returns: the return, benchmark return, profile, "
               "group, policy and exception entities are all conformed from DP-145, so the Personal Return Value and "
               "DP-145's controls (Suppressed Personal Returns, Personal Return Inputs Shown) are read, never "
               "recomputed. The household is a Party (DP-240); account-to-owner, household-to-member and group-to-"
               "account links are effective-dated bridges, never columns on the account. No 49 Client Holding or 18 "
               "Portfolio Holding entity is joined (the statement value is DP-145's copy). Personal data: financial "
               "tier on the return entities, identity tier on account, party and coverage entities; no special-category "
               "data, so no restricted child entity is needed.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-533": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Fact Client Return Exception", ("DP-145", "Client Return Exception"), [("32", "Client Return Exception")],
                role="Fact", measures=True,
                grain="one row = 15 account x exception date x exception type, per daily as-of snapshot",
                note="The exception worklist. Holds the measures (open age, household groups affected, suppressed "
                     "values published). Taxonomy gap: no resolved date or owner, so only open age is measured. PII "
                     "tier: financial."),
            dim("Fact Personal Return Version", ("DP-145", "Personal Rate of Return"), [("32", "Personal Rate of Return")],
                role="Fact",
                grain="one row = personal rate of return version (PRROR-); a restating version carries Supersedes "
                      "Personal Return",
                note="Conformed from DP-145: restatement size is measured from DP-145's values and Restated Personal "
                     "Returns Requiring Notification is DP-145's flag, read as published. PII tier: financial."),
            dim("Fact Performance Restatement", ("DP-145", "Performance Restatement"), [("32", "Performance Restatement")],
                role="Fact", grain="one row = performance return x restatement sequence",
                note="Institutional account restatements (Material Restatements (from DP-145), Institutional "
                     "Accounts). No PII at this grain; the account is reached through Performance Return."),
            # -- dimensions and bridges
            dim("Performance Return", ("DP-145", "Performance Return"), [("32", "Performance Return")],
                note="The subject of an institutional restatement (Return Subject Type Account). PII tier: financial "
                     "where the subject is a client account."),
            dim("Client Performance Profile", ("DP-145", "Client Performance Profile"),
                [("32", "Client Performance Profile")],
                note="Profile control rows (Profiles Missing Start Date or Policy, Open Accounts Without Performance "
                     "Profile by anti-join to Client Account). PII tier: financial."),
            dim("Performance Calculation Policy", ("DP-145", "Performance Calculation Policy"),
                [("32", "Performance Calculation Policy")],
                note="Large Cash Flow Threshold and version; Profiles on Superseded Policy Version. No PII."),
            dim("Household Performance Group", ("DP-145", "Household Performance Group"),
                [("32", "Household Performance Group")], note="PII tier: financial (household grouping)."),
            dim("Household Performance Group Member", ("DP-145", "Household Performance Group Member"),
                [("32", "Household Performance Group Member")], role="Bridge",
                grain="one row = household performance group x 15 account x inclusion period",
                note="Carries an open account exception to every group that contains the account on the exception "
                     "date. PII tier: financial."),
            dim("Household", PARTY240, note="The 02 Client Household (PTY-HH-). PII tier: identity."),
            dim("Client Account", ACCT, [("15", "Account")],
                note="Account type, status, open and close dates (Exceptions on Closed Accounts). PII tier: identity."),
            dim("Exception Date", CAL),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Client Return Exception", "Client Account", ["Exception Account"]),
            rel("Fact Client Return Exception", "Exception Date", ["Exception Date"]),
            rel("Fact Client Return Exception", "As-Of Date", ["As-Of Date Key"],
                note="Daily snapshot date. Model gap: the exception carries no as-of date."),
            rel("Fact Personal Return Version", "Client Account", ["Personal Return Account"], optional=True),
            rel("Fact Personal Return Version", "Household Performance Group", ["Personal Return Group"], optional=True),
            rel("Fact Personal Return Version", "Fact Personal Return Version", ["Supersedes Personal Return"],
                optional=True, note="The restated (prior) version."),
            rel("Fact Performance Restatement", "Performance Return", ["Restated Return"]),
            rel("Performance Return", "Client Account", ["Return Account"], optional=True),
            rel("Client Performance Profile", "Client Account", ["Client Profile Account"], optional=True),
            rel("Client Performance Profile", "Household Performance Group", ["Client Profile Group"], optional=True),
            rel("Client Performance Profile", "Performance Calculation Policy", ["Client Applied Calculation Policy"],
                optional=True),
            rel("Household Performance Group", "Household", ["Group Household"]),
            rel("Household Performance Group Member", "Household Performance Group", ["Member Performance Group"]),
            rel("Household Performance Group Member", "Client Account", ["Member Account"]),
        ],
        notes=("Exception and restatement control star over DP-145: every 32 entity is conformed from DP-145, so "
               "Suppressed Personal Returns and the notification and materiality flags are read as published and no "
               "return is recalculated (CW-251). Large Flow Exceptions Below Policy Threshold compares DP-145's own "
               "flow and value copies with the policy threshold, a trigger check only. The household is a Party "
               "(DP-240) and group-to-account is an effective-dated bridge. No 49 or 18 holding entity is read. "
               "Taxonomy gaps the spec records (no notification link from 13, no restatement date on 32 Personal Rate "
               "of Return) leave no join to model. Personal data: financial tier on the 32 entities, identity on "
               "account and household; no special-category data.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-535": dict(
        style="Star",
        entities=[
            # -- facts
            own("Fact Search Candidate", [("52", "Search Candidate")], ["Candidate Search", "Candidate Strategy"],
                role="Fact", measures=True, grain="one row = manager search x candidate external manager strategy",
                note="First main fact: candidates by stage and elimination reason. Holds the measures because the "
                     "search, recommendation and hire tests resolve per search and candidate. Candidate Search is "
                     "flagged PII only by its 'No PII' note; PII tier: none."),
            own("Fact Manager Due Diligence Review", [("52", "Manager Due Diligence Review")],
                ["Manager Due Diligence Review ID"], role="Fact", grain="one row = manager due diligence review (MDILG-)",
                note="Review dates, rating and outcome (overdue, turnaround, superseded template). Taxonomy gap: no "
                     "completion status; completed means Review Completed Date is set. PII tier: identity (Lead "
                     "Reviewer is an employee reference)."),
            own("Fact Due Diligence Score", [("52", "Due Diligence Score")], ["Scored Review", "Scoring Factor"],
                role="Fact", grain="one row = manager due diligence review x scoring factor",
                note="Second main fact: Weighted Due Diligence Score = sum of Factor Score x Factor Weight per review. "
                     "No PII."),
            own("Fact Onsite Visit", [("52", "Onsite Visit")], ["Visited Review", "Visit Date"], role="Fact",
                grain="one row = manager due diligence review x visit date", note="No PII."),
            own("Fact Background Check Result", [("52", "Background Check Result")],
                ["Checked Key Person", "Background Check Type", "Check Date"], role="Fact",
                grain="one row = manager key person x background check type x check date",
                note="Restricted entity: an FCRA consumer report about an individual, published as outcome and "
                     "authorization only in a restricted view (DQ5); kept apart from the key person so the restriction "
                     "applies to this entity alone. PII tier: identity (with regulatory disclosure indicator); no "
                     "CD-344 special-category attribute is read."),
            dim("Fact Product Due Diligence", ("DP-306", "Product Due Diligence"), [("52", "Product Due Diligence")],
                role="Fact", grain="one row = third-party product (17 instrument) x review (TPDUE-)",
                note="Conformed from DP-306 (the backlog DP-539 reads fold in here); the list status itself stays "
                     "DP-306's. No PII."),
            own("Fact Product Criterion Result", [("52", "Product Due Diligence Criterion Result")],
                ["Criterion Product Review", "Product Due Diligence Criterion"], role="Fact",
                grain="one row = product due diligence x criterion",
                note="Products Approved Despite Failed Criteria. No PII."),
            own("Fact Fund of Funds Use", [("52", "Fund of Funds Use Detail")],
                ["Fund of Funds Product Review", "Acquiring Fund"], role="Fact",
                grain="one row = product due diligence x acquiring fund of funds",
                note="Section 12(d)(1) use and its investment agreement. No PII."),
            # -- dimensions
            own("Manager Search", [("52", "Manager Search"), ("52", "Search Outcome")], ["Manager Search ID"],
                note="Own dimension (no foundational model publishes 52 Manager Search); Search Outcome folds in. "
                     "Taxonomy gap: Search Outcome has no key of its own, so its join to the search is implicit. PII "
                     "tier: identity (Search Owner is an employee reference)."),
            own("Questionnaire Template", [("52", "Due Diligence Questionnaire Template")],
                ["Questionnaire Template Code", "Questionnaire Template Version"],
                note="Own dimension; Reviews on Superseded Templates. No PII."),
            dim("Manager", MANAGER, [("52", "External Manager Profile")],
                note="Conformed external manager (02 party in its research role), read never remastered. PII tier: "
                     "none (managers are organizations)."),
            dim("External Manager Strategy", EMSTR, [("52", "External Manager Strategy")], note="No PII."),
            dim("Manager Key Person", ("DP-306", "Manager Key Person"), [("52", "Manager Key Person")],
                note="Key persons are individuals: PII tier identity. Key Persons Without Current Background Check."),
            dim("Key Person Individual", PARTY240, note="The individual behind a key person. PII tier: identity."),
            dim("Sub-Adviser Engagement", SAE, [("52", "Sub-Adviser Engagement")],
                note="The hire a search resulted in (Approved Hires Without Engagement). No PII."),
            own("Investment Committee Decision", [("24", "Investment Committee Decision")],
                ["Decision Committee", "Decision Meeting Date", "Decision Item Number"], note=ICD_NOTE),
            dim("Target Fund", PROD, note="The fund a search is for."),
            dim("Acquiring Fund", PROD, note="The fund of funds acquiring the reviewed product."),
            dim("Target Mandate", MANDATE),
            dim("Instrument", INSTR, note="The third-party product reviewed."),
            dim("Investment Agreement", ("DP-213", "Contract"), note="The 39 fund-of-funds investment agreement."),
            dim("Employee", EMP192, note="Search owners and lead reviewers. PII tier: identity (employee)."),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Search Candidate", "Manager Search", ["Candidate Search"]),
            rel("Fact Search Candidate", "External Manager Strategy", ["Candidate Strategy"]),
            rel("Fact Search Candidate", "Fact Manager Due Diligence Review", ["Candidate Due Diligence Reviews"],
                card="M:N", optional=True),
            rel("Manager Search", "Target Fund", ["Target Product"], optional=True),
            rel("Manager Search", "Target Mandate", ["Target Mandate"], optional=True),
            rel("Manager Search", "Employee", ["Search Owner"]),
            rel("Manager Search", "External Manager Strategy", ["Selected Strategy"], optional=True),
            rel("Manager Search", "Investment Committee Decision", ["Approving Committee Decision"], optional=True),
            rel("Manager Search", "Sub-Adviser Engagement", ["Resulting Engagement"], optional=True),
            rel("Manager Search", "Calendar Date", ["Search Opened Date"]),
            rel("Fact Manager Due Diligence Review", "Manager", ["Reviewed Manager"]),
            rel("Fact Manager Due Diligence Review", "External Manager Strategy", ["Reviewed Strategy"], optional=True),
            rel("Fact Manager Due Diligence Review", "Questionnaire Template", ["Questionnaire Template Used"],
                optional=True),
            rel("Fact Manager Due Diligence Review", "Employee", ["Lead Reviewer"]),
            rel("Fact Due Diligence Score", "Fact Manager Due Diligence Review", ["Scored Review"]),
            rel("Fact Onsite Visit", "Fact Manager Due Diligence Review", ["Visited Review"]),
            rel("Fact Background Check Result", "Manager Key Person", ["Checked Key Person"]),
            rel("Manager Key Person", "Manager", ["Key Person Manager"]),
            rel("Manager Key Person", "Key Person Individual", ["Key Person"]),
            rel("External Manager Strategy", "Manager", ["Strategy Manager"]),
            rel("Fact Product Due Diligence", "Instrument", ["Reviewed Instrument"]),
            rel("Fact Product Due Diligence", "Investment Committee Decision", ["Product Approving Decision"],
                optional=True),
            rel("Fact Product Criterion Result", "Fact Product Due Diligence", ["Criterion Product Review"]),
            rel("Fact Fund of Funds Use", "Fact Product Due Diligence", ["Fund of Funds Product Review"]),
            rel("Fact Fund of Funds Use", "Acquiring Fund", ["Acquiring Fund"]),
            rel("Fact Fund of Funds Use", "Investment Agreement", ["Fund of Funds Investment Agreement"], optional=True),
        ],
        notes=("Manager search and due diligence star. The manager, strategy, key person, engagement and product "
               "due diligence masters are conformed from DP-306 and read, never remastered (CW-116, CW-254); searches, "
               "reviews, scores, visits and background checks are 52 records no foundational model publishes, so they "
               "are built from the product's inputs. Personal data: identity tier on Manager Key Person, Key Person "
               "Individual, Employee and the employee references on Manager Search and the review; the FCRA background "
               "check is its own restricted entity. Taxonomy gap: Search Outcome is an attribute group with no key, "
               "folded into Manager Search.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-536": dict(
        style="Star",
        entities=[
            # -- facts
            own("Fact Oversight Metric Reading", [("52", "Oversight Metric Reading")],
                ["Reading Review", "Oversight Metric"], role="Fact", measures=True,
                grain="one row = sub-adviser engagement x oversight review (review period) x oversight metric, with "
                      "the threshold in force and the pinned source record of the reading",
                note="Main fact; holds the measures. Each reading pins its source row (32, 31, 11, 27, 33), and the "
                     "tie-out measures compare the reading with that row as its owner publishes it. Taxonomy gap: no "
                     "source version for the 31, 11 and 27 sources, so those tie to the current row. Reading Review is "
                     "flagged PII only by its 'No PII' note."),
            own("Fact Oversight Review", [("52", "Oversight Review")], ["Oversight Review ID"], role="Fact",
                grain="one row = oversight review (OVRVW-) of an engagement",
                note="Own entity (no foundational model publishes 52 Oversight Review). Review period, conclusion and "
                     "completion (On Time %). PII tier: identity (Oversight Reviewer is an employee reference)."),
            own("Fact Compliance Certification", [("52", "Sub-Adviser Compliance Certification")],
                ["Certifying Manager", "Certifying Engagement", "Certification Type", "Certification Period End"],
                role="Fact", grain="one row = certification subject (manager or engagement) x certification type x "
                                   "certification period",
                note="Taxonomy gap: no certification status, so overdue is computed from due and received dates. No "
                     "PII (Certifying Manager flag is the 'No PII' note)."),
            own("Fact Guideline Rule Inclusion", [("52", "Guideline Rule Inclusion")],
                ["Inclusion Guideline Set", "Included Compliance Rule", "Included Investment Restriction"], role="Fact",
                grain="one row = guideline set version x 33 compliance rule version or 01 investment restriction",
                note="Guideline Inclusions on Superseded Rule Versions compares Included Rule Version with Compliance "
                     "Rule. No PII."),
            own("Fact Oversight Finding", [("52", "Oversight Finding")], ["Oversight Finding ID"], role="Fact",
                grain="one row = oversight finding (OVFND-)", note="No PII."),
            own("Fact Remediation Action", [("52", "Remediation Action")], ["Remediated Finding", "Action Sequence"],
                role="Fact", grain="one row = oversight finding x action sequence", note="No PII."),
            # -- dimensions from DP-306
            dim("Sub-Adviser Engagement", SAE, [("52", "Sub-Adviser Engagement")],
                note="Conformed engagement master (DP-306), read never remastered. No PII."),
            dim("Sub-Adviser Watch Status", ("DP-306", "Sub-Adviser Watch Status"), [("52", "Sub-Adviser Watch Status")],
                note="Effective-dated watch periods (SCD); the status on the review end and as of today are both "
                     "resolved from Watch Effective From and To. No PII."),
            dim("Manager", MANAGER, note="External manager / sub-adviser. No PII."),
            dim("External Manager Strategy", EMSTR),
            dim("Manager Key Person", ("DP-306", "Manager Key Person"), [("52", "Manager Key Person")],
                note="Key Person Departures at Engaged Managers. PII tier: identity (individuals)."),
            dim("Sub-Adviser Guideline Set", ("DP-306", "Sub-Adviser Guideline Set"), [("52", "Sub-Adviser Guideline Set")]),
            own("Oversight Metric Threshold", [("52", "Oversight Metric Threshold")],
                ["Threshold Engagement", "Threshold Metric", "Threshold Effective From"],
                note="Own dimension, effective dated per engagement and metric (threshold and warning band). A reading "
                     "takes the threshold of its engagement and metric in force on the review end. No PII."),
            # -- source dimensions (pinned readings)
            dim("Source Performance Return", ("DP-145", "Performance Return"), [("32", "Performance Return")],
                note="Official return (DP-145) the return reading pins, with its version."),
            dim("Source Benchmark Return", ("DP-145", "Benchmark Return"), [("32", "Benchmark Return")]),
            own("Source Ex-Post Risk Statistic", [("32", "Ex-Post Risk Statistic")], ["Source Ex-Post Risk Statistic Key"],
                note="Own dimension: 32 Ex-Post Risk Statistic is read through DP-157 (consumer). Model gap: the "
                     "registry key (subject, type, period, frequency, fee and price basis, currency, benchmark, "
                     "version) is mostly not a spec input, so a surrogate key carries the reading's pinned row."),
            dim("Source Risk Measure", ("DP-146", "Portfolio Risk Measure"), [("31", "Portfolio Risk Measure")],
                note="Ex-ante risk certified by DP-146. Measured Portfolio is flagged PII only by its 'No PII' note."),
            dim("Source Peer Metric Snapshot", ("DP-014", "Peer Metric Snapshot"), [("11", "Peer Metric Snapshot")],
                note="Peer ranking (DP-014)."),
            own("Source Fee Benchmark Result", [("11", "Fee Benchmark Result")], ["Source Fee Benchmark Result Key"],
                note="Own dimension: DP-506 (consumer) is the source and its parent 11 Fee Benchmark Study is not read. "
                     "Model gap: the folded result group has no key of its own, so a surrogate carries the pinned row."),
            dim("Source Financial Highlights", ("DP-165", "Financial Highlights"), [("27", "Financial Highlights")],
                note="Audited fund turnover (DP-165), fund level (sleeve turnover is a tailoring lever)."),
            own("Investment Breach", [("33", "Investment Breach")], ["Investment Breach ID"],
                note="Own dimension: breaches are DP-163's (consumer). Breach Count Tie-Out and certified exceptions. "
                     "Breached Portfolio is flagged PII only by its 'No PII' note."),
            own("Compliance Rule", [("33", "Compliance Rule")], ["Compliance Rule ID", "Rule Version"],
                note="Own dimension: coded rules are DP-161's (consumer). No PII."),
            own("Investment Committee Decision", [("24", "Investment Committee Decision")],
                ["Decision Committee", "Decision Meeting Date", "Decision Item Number"], note=ICD_NOTE),
            # -- conformed reference
            dim("Fund", PROD, note="The engaged fund."),
            dim("Delegated Mandate", MANDATE),
            dim("Portfolio", ("DP-140", "Portfolio"),
                note="18 portfolio book: the sleeve, the measured portfolio and the breached portfolio. No client book "
                     "(49) entity is read."),
            dim("Employee", EMP192, note="Oversight reviewers. PII tier: identity (employee)."),
            dim("Review Period End", CAL),
        ],
        relationships=[
            rel("Fact Oversight Metric Reading", "Fact Oversight Review", ["Reading Review"]),
            rel("Fact Oversight Metric Reading", "Source Performance Return", ["Source Performance Return"],
                optional=True),
            rel("Fact Oversight Metric Reading", "Source Benchmark Return", ["Source Benchmark Return"], optional=True),
            rel("Fact Oversight Metric Reading", "Source Ex-Post Risk Statistic", ["Source Ex-Post Risk Statistic"],
                optional=True),
            rel("Fact Oversight Metric Reading", "Source Risk Measure", ["Source Risk Measure"], optional=True),
            rel("Fact Oversight Metric Reading", "Source Peer Metric Snapshot", ["Source Peer Metric Snapshot"],
                optional=True),
            rel("Fact Oversight Metric Reading", "Source Fee Benchmark Result", ["Source Fee Benchmark Result"],
                optional=True),
            rel("Fact Oversight Metric Reading", "Source Financial Highlights", ["Source Financial Highlights"],
                optional=True),
            rel("Fact Oversight Metric Reading", "Sub-Adviser Guideline Set", ["Breach Count Guideline Set"],
                optional=True),
            rel("Fact Oversight Metric Reading", "Investment Breach", ["Source Investment Breaches"], card="M:N",
                optional=True),
            rel("Fact Oversight Review", "Sub-Adviser Engagement", ["Reviewed Engagement"]),
            rel("Fact Oversight Review", "Employee", ["Oversight Reviewer"]),
            rel("Fact Oversight Review", "Review Period End", ["Review Period End"]),
            rel("Sub-Adviser Watch Status", "Sub-Adviser Engagement", ["Watched Engagement"]),
            rel("Sub-Adviser Watch Status", "Fact Oversight Review", ["Deciding Oversight Review"], optional=True,
                note="Watch Status Without Deciding Review."),
            rel("Oversight Metric Threshold", "Sub-Adviser Engagement", ["Threshold Engagement"]),
            rel("Oversight Metric Threshold", "Investment Committee Decision", ["Threshold Approving Decision"],
                optional=True),
            rel("Sub-Adviser Engagement", "Manager", ["Engaged Sub-Adviser"]),
            rel("Sub-Adviser Engagement", "External Manager Strategy", ["Engaged Strategy"], optional=True),
            rel("Sub-Adviser Engagement", "Fund", ["Engaged Fund"], optional=True),
            rel("Sub-Adviser Engagement", "Delegated Mandate", ["Delegated Mandate"], optional=True),
            rel("Sub-Adviser Engagement", "Portfolio", ["Sleeve Portfolio"], optional=True),
            rel("Manager Key Person", "Manager", ["Key Person Manager"]),
            rel("Sub-Adviser Guideline Set", "Sub-Adviser Engagement", ["Guideline Engagement"]),
            rel("Fact Guideline Rule Inclusion", "Sub-Adviser Guideline Set", ["Inclusion Guideline Set"]),
            rel("Fact Guideline Rule Inclusion", "Compliance Rule", ["Included Compliance Rule"], optional=True),
            rel("Fact Compliance Certification", "Manager", ["Certifying Manager"]),
            rel("Fact Compliance Certification", "Sub-Adviser Engagement", ["Certifying Engagement"], optional=True),
            rel("Fact Compliance Certification", "Investment Breach", ["Linked Investment Breaches"], card="M:N",
                optional=True, note="Certified Exceptions Without Linked Breach."),
            rel("Fact Oversight Finding", "Fact Oversight Review", ["Source Oversight Review"], optional=True),
            rel("Fact Oversight Finding", "Fact Compliance Certification", ["Source Certification"], optional=True),
            rel("Fact Oversight Finding", "Manager", ["Finding Manager"]),
            rel("Fact Remediation Action", "Fact Oversight Finding", ["Remediated Finding"]),
            rel("Source Risk Measure", "Portfolio", ["Measured Portfolio"]),
            rel("Investment Breach", "Portfolio", ["Breached Portfolio"]),
        ],
        notes=("Sub-adviser oversight scorecard. Engagement, watch status, key person and guideline set are conformed "
               "from DP-306; the certified sources a reading pins are conformed from their owners where a foundational "
               "model publishes them (DP-145 returns, DP-146 risk measures, DP-014 peer snapshots, DP-165 financial "
               "highlights) and held as own dimensions where the owner is a consumer product (DP-157 ex-post "
               "statistics, DP-506 fee results, DP-163 breaches, DP-161 rules). Each reading ties out to its pinned "
               "source; nothing certified is recomputed here (CW-252). Only the 18 portfolio book is read. Personal "
               "data: identity tier on Manager Key Person, Employee and the reviewer reference on Fact Oversight "
               "Review; no special-category data. Surrogate keys: Source Ex-Post Risk Statistic Key and Source Fee "
               "Benchmark Result Key (Model gaps above).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-538": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Fact Sub-Adviser Hire", SAE, [("52", "Sub-Adviser Engagement"), ("52", "Manager-of-Managers Hire Condition")],
                role="Fact", measures=True,
                grain="one row = sub-adviser engagement (hire event at Engagement Start Date, with its manager-of-"
                      "managers hire condition)",
                note="Conformed from DP-306 so the engagement and its hire condition are read as mastered. Holds the "
                     "measures: hire, renewal and termination tests all resolve to the engagement. Taxonomy gap: the "
                     "hire condition group has no key, so it folds into the engagement. Sub-Adviser Engagement ID is "
                     "flagged PII only by its 'No PII' note; PII tier: none."),
            own("Fact Section 15(c) Renewal Submission", [("52", "Section 15(c) Renewal Submission")],
                ["Submission Engagement", "Submission Renewal"], role="Fact",
                grain="one row = sub-adviser engagement x 35 advisory contract renewal (renewal year)",
                note="Taxonomy gap: no version or status, so a resubmission overwrites the row. No PII."),
            dim("Fact Manager Termination", ("DP-306", "Manager Termination"), [("52", "Manager Termination")],
                role="Fact", grain="one row = sub-adviser engagement x termination",
                note="Conformed from DP-306. Originating Search is kept as a degenerate reference: 52 Manager Search is "
                     "not a spec input (searches are DP-535's). No PII."),
            own("Fact Transition Event", [("12", "Transition Event")], ["Transition ID"], role="Fact",
                grain="one row = transition event (TRN-)",
                note="Own entity: no live foundational model publishes 12 Transition Event (DP-068 is retired). "
                     "Transition Completion Days and Cost. No PII."),
            # -- dimensions
            dim("Sub-Adviser Watch Status", ("DP-306", "Sub-Adviser Watch Status"), [("52", "Sub-Adviser Watch Status")],
                note="Continue Recommendations on Engagements Under Review. No PII."),
            own("Oversight Review", [("52", "Oversight Review")], ["Oversight Review ID"],
                note="Own dimension: oversight reviews are DP-536's (consumer). Submissions Without Current Oversight "
                     "Review. No PII."),
            own("Advisory Contract Renewal", [("35", "Advisory Contract Renewal")], ["Renewal ID"],
                note="Own dimension: the renewal is 35's (DP-183, consumer, not read to avoid a cycle, CW-253). No PII."),
            dim("Fund Advisory Agreement", ("DP-306", "Fund Advisory Agreement"), [("35", "Fund Advisory Agreement")],
                note="The governing sub-advisory agreement (35), conformed from DP-306."),
            own("Exemptive Relief Reliance", [("35", "Exemptive Relief Reliance")],
                ["Relying Fund", "Exemptive Relief Type", "Reliance Effective From"],
                note="Own dimension (manager-of-managers order). Model gap: Order or Rule Citation (registry key) is "
                     "not a spec input; one reliance per fund, relief type and effective date is assumed. No PII."),
            own("Board Resolution", [("35", "Board Resolution")], ["Board Resolution ID"],
                note="Own dimension: board resolutions are read from DP-182 (consumer). No PII."),
            dim("Information Statement", ("DP-382", "Communication"), [("13", "Shareholder Communication")],
                note="The 13 shareholder communication that carries the information statement. Communication ID is "
                     "flagged PII only by its 'No PII' note."),
            own("Investment Committee Decision", [("24", "Investment Committee Decision")],
                ["Decision Committee", "Decision Meeting Date", "Decision Item Number"], note=ICD_NOTE),
            dim("Sub-Adviser", MANAGER, note="The engaged sub-adviser (52 profile). No PII (organizations)."),
            dim("Sub-Adviser Party", ("DP-306", "Party"),
                note="The 02 party named on the 35 agreement; same key as Sub-Adviser."),
            dim("Governing Contract", ("DP-213", "Contract"), note="OCIO and trust engagements governed by a 39 contract."),
            dim("Fund", PROD),
            dim("Delegated Mandate", MANDATE),
            dim("Event Date", CAL),
        ],
        relationships=[
            rel("Fact Sub-Adviser Hire", "Sub-Adviser", ["Engaged Sub-Adviser"]),
            rel("Fact Sub-Adviser Hire", "Fund Advisory Agreement", ["Governing Fund Agreement"], optional=True),
            rel("Fact Sub-Adviser Hire", "Governing Contract", ["Governing Contract"], optional=True),
            rel("Fact Sub-Adviser Hire", "Fund", ["Engaged Fund"], optional=True),
            rel("Fact Sub-Adviser Hire", "Delegated Mandate", ["Delegated Mandate"], optional=True),
            rel("Fact Sub-Adviser Hire", "Exemptive Relief Reliance", ["Relied-On Exemptive Relief"], optional=True),
            rel("Fact Sub-Adviser Hire", "Information Statement", ["Information Statement Communication"],
                optional=True),
            rel("Fact Sub-Adviser Hire", "Event Date", ["Engagement Start Date"]),
            rel("Fact Section 15(c) Renewal Submission", "Fact Sub-Adviser Hire", ["Submission Engagement"]),
            rel("Fact Section 15(c) Renewal Submission", "Advisory Contract Renewal", ["Submission Renewal"]),
            rel("Fact Section 15(c) Renewal Submission", "Oversight Review", ["Included Oversight Reviews"], card="M:N",
                optional=True),
            rel("Fact Manager Termination", "Fact Sub-Adviser Hire", ["Terminated Engagement"]),
            rel("Fact Manager Termination", "Fact Sub-Adviser Hire", ["Replacement Engagement"], optional=True,
                note="Role: the replacement engagement."),
            rel("Fact Manager Termination", "Investment Committee Decision", ["Deciding Committee Decision"],
                optional=True),
            rel("Fact Manager Termination", "Fact Transition Event", ["Transition Event"], optional=True),
            rel("Fact Manager Termination", "Event Date", ["Termination Effective Date"]),
            rel("Sub-Adviser Watch Status", "Fact Sub-Adviser Hire", ["Watched Engagement"]),
            rel("Oversight Review", "Fact Sub-Adviser Hire", ["Reviewed Engagement"]),
            rel("Advisory Contract Renewal", "Fund Advisory Agreement", ["Renewed Agreement"]),
            rel("Advisory Contract Renewal", "Board Resolution", ["Renewal Approving Resolution"], optional=True),
            rel("Fund Advisory Agreement", "Sub-Adviser Party", ["External Sub-Adviser"], optional=True),
            rel("Exemptive Relief Reliance", "Fund", ["Relying Fund"]),
        ],
        notes=("Sub-adviser lifecycle star: three event facts (hire, Section 15(c) submission per renewal year, "
               "termination) at the engagement, with the 12 transition as a companion fact. The engagement, hire "
               "condition, termination, watch status and fund advisory agreement are conformed from DP-306; the 35 "
               "renewal, exemptive relief and board resolution are read directly because their owners (DP-183, "
               "DP-182) are consumer products and DP-183 is not read, keeping the CW-253 edge one-way. Model gap: "
               "Originating Search on Manager Termination points to 52 Manager Search, which is not a spec input. No "
               "personal data: every PII flag is the 'No PII' note false positive; sub-advisers are organizations.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-544": dict(
        style="Star",
        entities=[
            # -- facts
            own("Fact Investment Decision", [("24", "Investment Decision")], ["Investment Decision ID"], role="Fact",
                measures=True,
                grain="one row = investment decision (its instrument and action); the comparison point at which the "
                      "25 desk book and the 46/48 managed account book are reconciled",
                note="Holds the measures: rotation lag, first-execution lead, cross-book price difference and "
                     "completion are stated per decision by comparing the two book facts, which stay separate. Own "
                     "entity: decisions are DP-126's (consumer). No PII."),
            own("Fact Desk Trade Order", [("25", "Trade Order"), ("25", "Order Handling Instruction")], ["Trade Order ID"],
                role="Fact", grain="one row = trade order (one 18 portfolio x one instrument x side)",
                note="Desk book (fund and institutional portfolios, 18). Handling instructions fold in (trade rotation "
                     "program). PII tier: identity where an institutional separate account belongs to a natural "
                     "person (Order Portfolio); published only as book-level aggregates (DQ5)."),
            own("Fact Desk Execution", [("25", "Execution")], ["Execution ID"], role="Fact",
                grain="one row = broker placement x execution (fill, correction or cancellation)",
                note="Desk book executions (DP-123's), joined by key only and not republished. Volume-weighted price "
                     "and first execution per book are derived from this fact for the desk book. No PII."),
            own("Fact Client Execution", [("48", "Client Execution")], ["Client Execution ID"], role="Fact",
                grain="one row = client execution (one fill on one order route; CLEXE-) of a managed account client "
                      "block order",
                note="Managed account book executions (48, DP-301's), the client book of record side; kept as a fact "
                     "separate from the desk book (CW-007) and reconciled to it only at Fact Investment Decision. PII "
                     "tier: financial where a block's proposals name 15 accounts; no account is read here and only "
                     "book-level aggregates are published (DQ5)."),
            # -- desk book dimensions
            own("Block Order", [("25", "Block Order")], ["Block Order ID"], note="Desk block (25). No PII."),
            own("Block Order Membership", [("25", "Block Order Membership")], ["Member Block Order", "Member Trade Order"],
                role="Bridge", grain="one row = block order x trade order",
                note="Many-to-many between desk orders and blocks. No PII."),
            own("Broker Placement", [("25", "Broker Placement")], ["Broker Placement Key"],
                note="Model gap: the registry key (block order, broker, placement sequence) is only partly read "
                     "(Placement Broker and Placement Sequence Number are not spec inputs), so a surrogate key carries "
                     "the execution's placement. No PII."),
            dim("Portfolio", ("DP-140", "Portfolio"), [("18", "Portfolio")],
                note="The 18 portfolio book: portfolio type and business line of the desk book."),
            dim("Trade Rotation Program", ("DP-140", "Distribution Agreement"),
                note="Taxonomy gap (spec): Trade Rotation Program references a 05 agreement while rotation is a 25 "
                     "policy; conformed from DP-140's Distribution Agreement to follow the registry."),
            # -- managed account book dimensions
            dim("Rebalance Run", ("DP-304", "Rebalance Run"), [("46", "Trade Proposal Batch")],
                note="The 46 trade proposal batch and its release timestamp. Batch ID is flagged PII only by its 'No "
                     "PII' note."),
            own("Fact Trade Proposal", [("46", "Trade Proposal")], ["Trade Proposal ID"], role="Fact",
                grain="one row = proposal line (account x instrument x side) within a trade proposal batch",
                note="Fact built from the product's inputs rather than conformed from DP-304's, so the proposal's "
                     "account is not pulled in; read only for the batch's instrument and side. "
                     "PII tier: financial (a proposal line belongs to a 15 account)."),
            dim("Client Block Order", ("DP-301", "Client Block Order"), [("48", "Client Block Order")],
                note="Managed account client block (Block Origin Managed Account Trade Proposal Batch); Client Blocks "
                     "Without Source Batch."),
            own("Fact Order Route", [("48", "Order Route")], ["Order Route ID"], role="Fact",
                grain="one row = client block order x route sequence (ROUTE-)",
                note="Fact built from the product's inputs rather than conformed from DP-301's, so client-order "
                     "route columns are not pulled in; the execution-to-block link. "
                     "PII tier: financial (flagged route identifiers)."),
            dim("Program", ("DP-304", "Program"), note="The managed account program (01 service offering)."),
            # -- shared
            dim("Instrument", INSTR),
            dim("Investment Strategy", ("DP-004", "Investment Strategy")),
            dim("Trade Date", CAL),
        ],
        relationships=[
            rel("Fact Investment Decision", "Instrument", ["Decision Instrument"]),
            rel("Fact Investment Decision", "Investment Strategy", ["Decision Strategy"], optional=True),
            rel("Fact Desk Trade Order", "Fact Investment Decision", ["Originating Investment Decision"], optional=True,
                note="Desk Rebalance Orders Without Originating Decision."),
            rel("Fact Desk Trade Order", "Portfolio", ["Order Portfolio"]),
            rel("Fact Desk Trade Order", "Instrument", ["Order Instrument"]),
            rel("Fact Desk Trade Order", "Trade Rotation Program", ["Trade Rotation Program"], optional=True),
            rel("Block Order Membership", "Block Order", ["Member Block Order"]),
            rel("Block Order Membership", "Fact Desk Trade Order", ["Member Trade Order"]),
            rel("Block Order", "Instrument", ["Block Instrument"]),
            rel("Broker Placement", "Block Order", ["Placement Block Order"]),
            rel("Fact Desk Execution", "Broker Placement", ["Execution Placement"]),
            rel("Rebalance Run", "Program", ["Batch Program"]),
            rel("Fact Trade Proposal", "Rebalance Run", ["Proposal Batch"]),
            rel("Fact Trade Proposal", "Instrument", ["Proposal Instrument"]),
            rel("Client Block Order", "Rebalance Run", ["Source Trade Proposal Batch"], optional=True),
            rel("Client Block Order", "Instrument", ["Block Instrument"]),
            rel("Fact Order Route", "Client Block Order", ["Routed Client Block Order"]),
            rel("Fact Client Execution", "Fact Order Route", ["Execution Order Route"]),
            rel("Fact Client Execution", "Trade Date", ["Execution Trade Date"]),
        ],
        notes=("Trade rotation star with the two books kept apart (CW-007): the desk book (25 orders, blocks and "
               "executions over 18 portfolios) and the managed account book (46 batches, 48 client blocks and client "
               "executions over 49 client accounts) are separate facts that reconcile at Fact Investment Decision; "
               "no entity holds rows of both books. The desk side joins the decision by Originating Investment "
               "Decision; the managed account side has no decision reference (taxonomy gap), so it is matched by "
               "instrument, side and a two-business-day window, which the model draws only through the shared "
               "Instrument dimension. Trade orders, executions and client executions are joined by key and not "
               "republished (CW-255, CD-314). Personal data: the flagged 25, 46 and 48 attributes are read only to "
               "join books and publish book-level aggregates; no account entity is modeled. Surrogate key: Broker "
               "Placement Key (Model gap above).")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-515": dict(
        style="Star",
        entities=[
            # -- facts
            own("Fact Code List Version", [("09", "Code List Version")], ["Code List Version ID", "As-Of Date Key"],
                role="Fact", measures=True,
                grain="one row = code list x code list version x as-of date (daily snapshot, SCD type 2 on lists and "
                      "versions)",
                note="Own entity: DP-075 publishes Code List Version but is deliberately not upstream (its retirement "
                     "needs no change here). Holds the measures, since registry coverage is stated per list and "
                     "version. No PII."),
            dim("Fact Code Value", ("DP-013", "Code Value"), [("09", "Code Value")], role="Fact",
                grain="one row = code list x code value (version not referenced; taxonomy gap)",
                note="Retired Codes Without Replacement. No PII."),
            dim("Fact Code List Consumer", ("DP-013", "Code List Consumer"), [("09", "Code List Consumer")], role="Fact",
                grain="one row = code list x consuming domain x consuming attribute", note="No PII."),
            dim("Fact Code Mapping", ("DP-013", "Code Mapping"), [("09", "Code Mapping")], role="Fact",
                grain="one row = source system x source value x target code list", note="No PII."),
            dim("Fact Code List Change Request", ("DP-013", "Code List Change Request"),
                [("09", "Code List Change Request")], role="Fact", grain="one row = code list change request",
                note="Taxonomy gap: no reference to the list it changes or a request date, so requests cannot be aged "
                     "or attributed (see the borrowed key below). No PII."),
            own("Fact Reference Data Subscription", [("09", "Reference Data Subscription")],
                ["Reference Data Set", "Subscribing System"], role="Fact",
                grain="one row = reference data set (code list) x subscribing system",
                note="Own entity (DP-075 not upstream, as for versions). Subscriptions to Decommissioned Systems. No "
                     "PII."),
            dim("Fact Calendar Date", ("DP-013", "Calendar Date"), [("09", "Calendar Date")], role="Fact",
                grain="one row = calendar x date (rolled up to calendar x year for completeness)",
                note="Calendars Without Next-Year Dates. Taxonomy gap: 09 Calendar Date has no Calendar reference; the "
                     "calendar is the row's parent (Calendar Key, as DP-013 models it). No PII."),
            dim("Fact Taxonomy Element Registration", ("DP-100", "Taxonomy Element Registration"),
                [("21", "Taxonomy Element Registration")], role="Fact",
                grain="one row = taxonomy element x taxonomy release",
                note="Taxonomy Attributes on Unregistered Code Lists (Element Code List not in the registry). No PII."),
            # -- dimensions
            dim("Code List", ("DP-013", "Code List"), [("09", "Code List")],
                note="Conformed code list registry entry (DP-013), read never remastered. Data Owner and Data Steward "
                     "are kept as employee IDs; no Employee dimension is joined (DP-192 is not upstream and the "
                     "product carries no personal data). No PII."),
            dim("Calendar", ("DP-013", "Calendar"), [("09", "Calendar"), ("09", "Dealing Calendar Rule")],
                note="Dealing Calendar Rule folds into its parent calendar. No PII."),
            dim("Taxonomy Element", ("DP-100", "Taxonomy Element")),
            dim("Taxonomy Release", ("DP-100", "Taxonomy Release"), [("21", "Taxonomy Release")]),
            dim("Application", ("DP-211", "Application"), [("41", "Application")],
                note="Source and subscribing systems, with status and decommission date."),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Code List Version", "Code List", ["Code List Key"],
                note="Model gap (taxonomy gap): 09 Code List Version carries no reference to its Code List."),
            rel("Fact Code List Version", "As-Of Date", ["As-Of Date Key"], note="Daily snapshot date."),
            rel("Code List", "Fact Code List Version", ["Current Version"], optional=True,
                note="Code Lists Without Current Version."),
            rel("Fact Code Value", "Code List", ["Code List Key"],
                note="Model gap (taxonomy gap): 09 Code Value carries no reference to its list or version; the key is "
                     "borrowed as DP-013 models it."),
            rel("Fact Code List Consumer", "Code List", ["Code List Key"],
                note="Model gap (taxonomy gap): no list reference on the consumer row."),
            rel("Fact Code Mapping", "Code List", ["Target Code List"]),
            rel("Fact Code Mapping", "Application", ["Source System"]),
            rel("Fact Code List Change Request", "Code List", ["Code List Key"], optional=True,
                note="Model gap: the change request has no list reference; the borrowed key is blank until the "
                     "taxonomy adds one."),
            rel("Fact Reference Data Subscription", "Code List", ["Reference Data Set"]),
            rel("Fact Reference Data Subscription", "Application", ["Subscribing System"]),
            rel("Fact Calendar Date", "Calendar", ["Calendar Key"]),
            rel("Fact Calendar Date", "As-Of Date", ["As-Of Date Key"],
                note="Daily snapshot of calendar completeness, shared with the code list facts."),
            rel("Calendar", "Calendar", ["Base Business Calendar"], optional=True,
                note="A dealing calendar's base business calendar."),
            rel("Calendar", "Calendar", ["Market Closure Calendars"], card="M:N", optional=True,
                note="Dealing Calendars Without Closure Calendars."),
            rel("Fact Taxonomy Element Registration", "Taxonomy Element", ["Registered Taxonomy Element"]),
            rel("Fact Taxonomy Element Registration", "Taxonomy Release", ["Registering Release"]),
            rel("Fact Taxonomy Element Registration", "Code List", ["Element Code List"], optional=True),
        ],
        notes=("Reference data governance over the 09 objects: code lists, values, consumers, mappings, change "
               "requests and calendars are conformed from DP-013 and the taxonomy registry from DP-100, so the product "
               "tests them and remasters nothing (CD-300). Code List Version and Reference Data Subscription are own "
               "entities because their only foundational publisher, DP-075, is deliberately not upstream. The 09 "
               "catalog lacks list references on versions, values, consumers and change requests, so those rows borrow "
               "Code List Key (Model gaps above). No personal data in any entity.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-516": dict(
        style="Star",
        entities=[
            # -- facts
            own("Fact Instrument Coverage",
                [("17", "Instrument"), ("17", "Municipal Security Terms"), ("17", "Municipal Fund Security Terms"),
                 ("17", "Listed Derivative Contract Terms"), ("17", "Debt Terms")],
                ["Instrument ID", "As-Of Date Key"], role="Fact", measures=True,
                grain="one row = instrument x as-of date for platform-available and client-held instruments (daily "
                      "snapshot), with type-specific term completeness and eligibility rule checks",
                note="Built from the product's own instrument inputs so only the terms the completeness tests read are "
                     "carried; the type-specific attribute groups fold in (taxonomy gap: they have no key of their "
                     "own). Holds the measures. The golden record stays DP-097's; nothing is remastered (CD-300). No "
                     "PII."),
            dim("Fact Instrument Identifier", ("DP-097", "Instrument Identifier"), [("17", "Instrument Identifier")],
                role="Fact", grain="one row = instrument x identifier scheme x identifier value x effective period",
                note="CUSIP and OCC symbol coverage (Available Instruments Without Active CUSIP). No PII."),
            own("Fact Instrument Setup Request", [("17", "Instrument Setup Request")], ["Setup Request ID"],
                role="Fact", grain="one row = instrument setup request",
                note="Turnaround, past-required and rejected requests. Requested By and Approved By are not read. "
                     "Taxonomy gap: no link to the blocked client order. No PII."),
            own("Fact Client-Held Instrument", [("49", "Client Holding")], ["Client Holding ID"], role="Fact",
                grain="one row = client holding (account x instrument x holding date x holding view), read only to "
                      "list distinct client-held instruments",
                note="49 client book of record, read for Held Instrument, date and view only; no account, quantity or "
                     "value is read or published (DQ5), and no 18 portfolio holding is joined. PII tier: financial at "
                     "source (Client Holding attributes are account holdings)."),
            dim("Fact Approved Price", ("DP-143", "Approved Price"), [("22", "Approved Price")], role="Fact",
                grain="one row = instrument x pricing point x price date x version",
                note="Client-Held Instruments Without Approved Price (client reporting pricing point)."),
            # -- dimensions
            dim("Instrument", INSTR,
                note="Conformed DP-097 instrument: the join point for identifiers, set-up requests, client holdings, "
                     "prices and platform availability."),
            dim("Platform Product Availability", ("DP-004", "Platform Product Availability"),
                [("01", "Platform Product Availability")],
                note="Availability status and transaction fee category. Platform Availability ID is flagged PII only by "
                     "its 'No PII' note."),
            dim("Tradable Universe Policy Rule", ("DP-004", "Tradable Universe Policy Rule"),
                [("01", "Tradable Universe Policy Rule")],
                note="Fractional and extended-hours eligibility rules."),
            dim("Share Class", SHARE, note="Own fund and ETF share classes."),
            dim("Pricing Point", ("DP-143", "Pricing Point"), [("22", "Pricing Point")]),
            dim("As-Of Date", CAL),
        ],
        relationships=[
            rel("Fact Instrument Coverage", "Instrument", ["Instrument ID"]),
            rel("Fact Instrument Coverage", "As-Of Date", ["As-Of Date Key"],
                note="Daily snapshot date. Model gap: the instrument carries no as-of date."),
            rel("Fact Instrument Coverage", "Share Class", ["Own Share Class"], optional=True),
            rel("Fact Instrument Coverage", "Tradable Universe Policy Rule", ["Fractional Trading Eligibility Rule"],
                optional=True, note="Fractional Eligibility Without Rule."),
            rel("Fact Instrument Coverage", "Tradable Universe Policy Rule", ["Extended-Hours Eligibility Rule"],
                optional=True, note="Extended-Hours Eligibility Without Rule."),
            rel("Fact Instrument Identifier", "Instrument", ["Identified Instrument"]),
            rel("Fact Instrument Setup Request", "Instrument", ["Resulting Instrument"], optional=True),
            rel("Fact Client-Held Instrument", "Instrument", ["Held Instrument"]),
            rel("Fact Approved Price", "Instrument", ["Priced Instrument"]),
            rel("Fact Approved Price", "Pricing Point", ["Approved Pricing Point"]),
            rel("Platform Product Availability", "Instrument", ["Available Third-Party Instrument"], optional=True),
            rel("Platform Product Availability", "Share Class", ["Available Share Class"], optional=True),
        ],
        notes=("Instrument coverage star: one snapshot row per platform-available or client-held instrument, with "
               "identifiers, set-up requests, client holdings and approved prices as companion facts joined through "
               "the conformed DP-097 Instrument. The 49 Client Holding is read only to find client-held instruments; "
               "it is never joined to an 18 portfolio holding or a 06 position. Program Manager (17 Municipal Fund "
               "Security Terms, a 02 party) is kept as an attribute without a Party dimension, which no listed "
               "upstream publishes without personal attributes. Personal data: none published; the financial-tier "
               "flags on the 49 attributes stay inside Fact Client-Held Instrument.")),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-518": dict(
        style="Star",
        entities=[
            # -- facts
            dim("Fact Data Product Reader", ("DP-101", "Data Product Input"), [("21", "Data Product Input")],
                role="Fact", measures=True,
                grain="one row = data product x input taxonomy element x as-of date (daily snapshot), with the "
                      "element's effective classification and the product's active data contracts",
                note="The fact of readers: which product reads which element and in which Input Role (Filter / Rule "
                     "reads are excluded from the detail tests). Holds the measures. Metadata only; no PII."),
            # -- dimensions
            dim("Named Restricted View", ("DP-101", "Data Contract"), [("21", "Data Contract")],
                note="The register of named restricted views. Model gap (taxonomy gap): 21 has no restricted-view "
                     "object and Data Contract no view name, so a named view (DP-498 Household Economics, DP-499 "
                     "Advisor Book, DP-499 Household Profitability, DP-503 Member-Level Allocation Read) is evidenced "
                     "by an Active contract of its product naming a Consumer Org Unit; row-level entitlement rules "
                     "are not recorded. Consumer External Party is kept as an ID with no Party dimension, so the "
                     "register carries no personal data."),
            dim("Data Product", ("DP-101", "Data Product"), [("21", "Data Product")],
                note="Tier, owning domain, classification and Contains Personal Data. No PII."),
            dim("Taxonomy Element", ("DP-100", "Taxonomy Element"), [("21", "Taxonomy Element")],
                note="Element names and data domain (member-level economics test on 10 elements). No PII."),
            dim("Data Classification Assignment", ("DP-100", "Data Classification Assignment"),
                [("21", "Data Classification Assignment")],
                note="Effective-dated classification (information class, personal data categories, special-category "
                     "and CPRA indicators); the CD-344 tier is derived from these (taxonomy gap). Metadata about "
                     "elements, not personal data."),
            dim("Critical Data Element", ("DP-100", "Critical Data Element"), [("21", "Critical Data Element")],
                note="Personal-Data CDEs. No PII."),
            dim("Allocation Rule", ("DP-480", "Allocation Rule"), [("10", "Allocation Rule")],
                note="Member-level economics rules (Target Dimension Household, Account, Client or Advisor). The rule "
                     "has no key link to a taxonomy element; readers of member-level economics are found by element "
                     "name and data domain 10. No PII."),
            dim("Cost Pool", ("DP-480", "Cost Pool")),
            dim("Consumer Org Unit", ("DP-013", "Org Unit")),
            dim("Calendar Date", CAL),
        ],
        relationships=[
            rel("Fact Data Product Reader", "Data Product", ["Input Data Product"]),
            rel("Fact Data Product Reader", "Taxonomy Element", ["Input Taxonomy Element"]),
            rel("Fact Data Product Reader", "Calendar Date", ["Calendar Date Key"],
                note="As-of date of the daily snapshot. Model gap: Data Product Input carries no as-of date."),
            rel("Data Product", "Data Product", ["Upstream Data Products"], card="M:N", optional=True),
            rel("Named Restricted View", "Data Product", ["Contracted Data Product"]),
            rel("Named Restricted View", "Consumer Org Unit", ["Consumer Org Unit"], optional=True),
            rel("Data Classification Assignment", "Taxonomy Element", ["Classified Taxonomy Element"], optional=True),
            rel("Critical Data Element", "Taxonomy Element", ["CDE Taxonomy Attribute"]),
            rel("Allocation Rule", "Cost Pool", ["Source Cost Pool"]),
            rel("Allocation Rule", "Calendar Date", ["Rule Effective From"],
                note="Effective dating only; see the Allocation Rule note for how member-level readers are found."),
        ],
        notes=("Restricted-view register: a Dimension of named views (Named Restricted View, evidenced by active data "
               "contracts) and a Fact of readers (Fact Data Product Reader), with each element's classification and "
               "CDE status as dimensions. The catalog, contracts and lineage are conformed from DP-101, the taxonomy, "
               "classification and CDE registry from DP-100 and the allocation rules from DP-480; nothing is "
               "remastered. The special-category register itself is DP-322's. No entity carries personal data: the "
               "register is metadata, and consumer parties and employees are not joined.")),
}

# Explicit primary keys on conformed entities that borrow a parent key or add a snapshot key.
_PK = {
    ("DP-531", "Fact Lineup Position"): ["Position Model Lineup", "Position Model Portfolio", "As-Of Date Key"],
    ("DP-532", "Fact Personal Return"): ["Personal Rate of Return ID", "Publication Date Key"],
    ("DP-533", "Fact Client Return Exception"): ["Exception Account", "Exception Date", "Client Return Exception Type",
                                                 "As-Of Date Key"],
    ("DP-515", "Fact Code Value"): ["Code List Key", "Code"],
    ("DP-515", "Fact Code List Consumer"): ["Code List Key", "Consuming Domain", "Consuming Attribute"],
    ("DP-515", "Fact Calendar Date"): ["Calendar Key", "Calendar Date"],
    ("DP-516", "Fact Instrument Coverage"): ["Instrument ID", "As-Of Date Key"],
    ("DP-518", "Fact Data Product Reader"): ["Input Data Product", "Input Taxonomy Element", "Calendar Date Key"],
}
for _pid, _m in MODELS.items():
    for _e in _m["entities"]:
        if (_pid, _e["name"]) in _PK:
            _e["pk"] = _PK[(_pid, _e["name"])]
        if _e.get("measures") is False:
            del _e["measures"]
