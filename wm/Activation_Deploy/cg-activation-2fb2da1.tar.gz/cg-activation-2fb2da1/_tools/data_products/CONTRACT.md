# Data product specification contract

A **data product** is a governed, reusable data asset built from the taxonomy's L3 Data Business Objects and L4 Data Business Attributes. It has a named owner, a stated grain, service levels and quality rules, and it exists to serve one or more business functions of the wholesale distributor.

- **Register:** `framework.py` holds the functions (`FUNCTIONS`), the specified product register (`PRODUCTS`: ID, name, tier, type, owning Data Domain, product owner, primary and supporting functions) and the identified backlog (`BACKLOG`).
- **Specifications:** the attribute-level specs live in `specs_*.py`, each defining `SPECS = {product_id: dict(...)}`.
- **Example:** DP-008 Client Assets & Net New Assets in `specs_w1f_certified.py` is the worked example and quality bar (lead ruling 2026-10-16; the wholesale DP-008 in `specs_00_reference.py` is superseded and that module now holds no spec).

## Fields (all required except `notes`)

| Field | Type | Content |
|---|---|---|
| `definition` | str | 2–4 sentences: what the product is, what it combines, and why it exists. |
| `business_questions` | list[str] | 3–6 concrete questions the primary function answers with it. |
| `grain` | str | What one row of the main output represents, written as `x`-joined dimensions. |
| `dimensions` | list[str] | The conformed dimensions consumers slice by. |
| `measures` | list[(name, definition, uses)] | Derived measures, scores or flags with an explicit formula or rule. Master-data products may list counts or completeness measures. `uses` lists what the formula reads: `("NN", "Object Name", "Attribute")` tuples, each of which must appear in `inputs`, and the names of other measures of the same product it builds on. It must not be empty. |
| `inputs` | list[("NN", "Object Name", [attribute names])] | **Exact** L3 object and L4 attribute names from the consolidated taxonomy (see `_catalog.txt`). List only the attributes the product actually needs, always including the object's identifying attribute(s) and the CDEs that drive its measures. |
| `upstream` | list[DP ids] | Specified products this one is built from. Consumer-aligned products should build on foundational products; foundational products may only depend on other foundational products. No cycles. |
| `refresh` | str | One of `framework.REFRESH`. |
| `timeliness` | str | When data is available, e.g. "By 7am ET on T+1", "Business day 8 after month-end". |
| `history` | str | Retention and history approach (snapshots, SCD type 2, years kept). |
| `classification` | str | One of `framework.CLASSIFICATIONS` (the enterprise Information Classification list). |
| `pii` | "Y" / "N" | "Y" if any output contains personal data (e.g. advisor names or IDs, end-investor data, employee compensation). |
| `delivery` | list[str] | From `framework.DELIVERY`. |
| `dq_rules` | list[str] | 3–6 testable data-quality rules, each one sentence. |
| `notes` | str | Optional: open questions, boundary decisions, links to decision-log items (CD-nnn). |

### Enterprise products (Waves E1 to E5, CD-299)

A product of the data products expansion also states, in `definition` or `notes`:

| Element | What it captures |
|---|---|
| Master concept | For a foundational product: the concept it conforms once and the matching row of `CONCEPT_OWNERSHIP` in `consolidation/decisions.py` (for example "Portfolio (managed book)", 18). The product never remasters it; it publishes it. |
| Operating model | For a product of a function that may be outsourced (fund accounting, custody, middle office, transfer agency, private fund administration; CD-297): whether the grain is the operational record or oversight data received from the provider, and how the product changes under the other model. |
| Certified numbers | Which certified metric families the product is the source of (CD-293, CD-320, CD-330, CD-340, CD-341), or which product it takes them from. A certified number is defined in one product only. |
| Capability | The function the product serves must run a capability of the business capability map; `framework.FUNCTIONS` carries the link and the validator checks it (CD-291). |

## Rules

1. **Reference by exact name.** Use `("NN", "Object Name", [...])` exactly as printed in `_catalog.txt`. The validator rejects anything it cannot resolve.
2. **Take inputs from the mastering domain.** Draw a concept from the Data Domain that masters it, not from a reference or copy elsewhere. In the catalog, `->NN` marks a reference.
   - Exception: when the relationship itself lives in the referencing object, use that object. For example, attributed flows by territory come from `06 Market & Client Dimensions`.
3. **Trace every measure.** A measure's `uses` list is how a dashboard metric is traced back to the owning Data Domain: metric (semantic model) -> measure (product) -> `uses` -> `inputs` -> taxonomy attribute. The validator rejects a use that is not in `inputs`. If a formula needs an attribute the product does not read, add it to `inputs`; if the taxonomy lacks it, record the gap (rule 4) and trace the measure to the nearest attributes it does read.
4. **Don't invent attributes.** If a product needs data the taxonomy doesn't have, describe it as a derived measure. Otherwise record the gap in `notes`, starting with "Taxonomy gap:".
5. **Write for a business reader.**
   - Use US spelling and plain sentences.
   - No marketing language.
   - Keep the taxonomy's terms: Data Domain, Data Business Object, advisor (not adviser, except in official UK names).
6. **Validate before finishing:** run `python data_products/dp_model.py specs_<yours>` from `_tools/` with the session's Python, and fix every ERROR. Fix a WARNING too, or justify it in `notes`.
7. **Register first.** A product is specified only after it is in `framework.PRODUCTS`. For the expansion waves the program lead registers each wave's products from the accepted brief (`WAVE_E1` and later lists) before the specs are written; a spec author never edits `framework.py`.

**Products pending WP0 re-scope (wealth-manager branch, CW-041).** `framework.RESCOPE_PENDING` lists every Consumer-aligned product of the wholesale Waves 1 to 4; WP0 re-scopes or retires each one and empties the register. A pending product keeps its register row and its spec, but `dp_model.py` does not validate the spec and the catalog, coverage counts and explorer leave it out (the catalog keeps a "Pending re-scope (WP0)" row; the explorer lists it in a collapsed group). Do not re-point a pending spec. A live product that lists a pending product in `upstream` is a warning until WP0 ("live product X depends on pending product Y; re-point at WP0; CW-041"), counted on every run: re-point it to a live product or drop the dependency.
