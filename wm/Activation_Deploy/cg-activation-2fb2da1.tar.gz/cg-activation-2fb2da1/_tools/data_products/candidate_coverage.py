"""Checks the candidate products of a product brief against the taxonomy, the function register and the coverage rule:
the wholesale Wave E0 briefs (consolidation/proposals_dp_<group>.py) and the wealth-manager WP0 briefs
(consolidation/proposals_wdp_<group>.py and proposals_wp0_<name>.py). Usage, from _tools:
  python data_products/candidate_coverage.py <module> [more modules]   one or more proposals modules
  python data_products/candidate_coverage.py --all                     every consolidation/proposals_dp_*.py (wholesale E0)
  python data_products/candidate_coverage.py --wealth                  every proposals_wdp_*.py and proposals_wp0_*.py (WP0)
  python data_products/candidate_coverage.py --wealth --wp1            the same, counting only WP1-scope candidates as readers
Errors: unknown object, tier, type, domain or function; a retired function as primary; duplicate id; a new id outside the
wealth id blocks (framework.ID_BLOCKS); an existing id that is not declared a re-scope; a foundational candidate with a
consumer upstream; a dependency cycle. Wave codes come from framework (CANDIDATE_WAVES for the wealth briefs, the E1 to E5
codes for the wholesale modules; the W0-instruction codes W1 to W4 are accepted with a warning).
A re-scope of an existing product keeps its id: a candidate with disposition "re-scope" (or an entry of the module's
RESCOPED list) is checked like a candidate, and its objects replace the existing spec's reads in the coverage count.
Coverage: every object with CDEs in the candidates' owning domains must be read by at least one candidate (across every
module loaded) or by a live product (not pending WP0 re-scope, not retired, not re-scoped by a loaded candidate); every
function the candidates serve as primary is listed.
--wp1 (WP1_Scope.md): backlog candidates (framework.WP1_BACKLOG) are still checked but do not count as readers, so every
object with CDEs must be read by a live product or a WP1-scope candidate. In every mode a candidate's backlog flag must
agree with framework.WP1_BACKLOG, and a WP1-scope candidate may not name a backlog candidate as upstream.
"""
import glob, importlib, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(HERE)
for p in (TOOLS, HERE, os.path.join(TOOLS, "consolidation"), os.path.join(TOOLS, "capability_map")):
    sys.path.insert(0, p)
sys.dont_write_bytecode = True
import dp_model  # noqa: E402
import framework as fw  # noqa: E402
from taxonomy_builder import DD_NAMES  # noqa: E402

FIELDS = {"id": str, "name": str, "tier": str, "type": str, "domain": str, "owner_role": str, "primary": str,
          "supporting": list, "wave": str, "definition": str, "objects": list, "upstream": list, "notes": str}
WAVES = set(getattr(fw, "CANDIDATE_WAVES", set())) | set(getattr(fw, "HISTORICAL_CANDIDATE_WAVES", {"E1", "E2", "E3", "E4", "E5"}))
FOUNDATIONAL_WAVES = set(getattr(fw, "FOUNDATIONAL_WAVES", set())) | {"E1"}
LEGACY = dict(getattr(fw, "LEGACY_WAVE_ALIASES", {}))
RETIRED_FN = dict(getattr(fw, "RETIRED_FUNCTIONS", {}))
RETIRED_DP = dict(getattr(fw, "RETIRED_PRODUCTS", {}))
PENDING_DP = dict(getattr(fw, "RESCOPE_PENDING", {}))
RESCOPE = {"re-scope", "re-scope in place", "rescope", "extend", "re-scope (extend)"}
try:
    import areas as _ar
    DOMAIN_AREA = dict(_ar.DOMAIN_AREA)
except Exception:          # capability map mid-edit: the area check is skipped
    DOMAIN_AREA = {}


def rescoped_in_place(m):
    """Existing ids a module's DISPOSITIONS declares re-scoped in place (tuple (id, disposition, ...) or dict form)."""
    out = set()
    for d in getattr(m, "DISPOSITIONS", []) or []:
        if isinstance(d, dict):
            pid, disp = d.get("id", ""), str(d.get("disposition", ""))
        elif isinstance(d, (tuple, list)) and len(d) >= 2:
            pid, disp = str(d[0]), str(d[1])
        else:
            continue
        if pid.startswith("DP-") and "re-scope" in disp.lower() and "retire" not in disp.lower():
            out.add(pid)
    return out


RESCOPED_IN_PLACE = set()       # filled by load(): pending products a loaded module re-scopes in place keep their reads


def load(names):
    cands, decisions = [], []
    for n in names:
        m = importlib.import_module(n)
        RESCOPED_IN_PLACE.update(rescoped_in_place(m))
        for c in getattr(m, "CANDIDATES", []):
            cands.append((n, c))
        for c in getattr(m, "RESCOPED", []):           # re-scopes of existing products listed apart from CANDIDATES
            c = dict(c); c.setdefault("disposition", "re-scope")
            cands.append((n, c))
        decisions += getattr(m, "DECISIONS", [])
    return cands, decisions


def main(argv):
    names = list(argv or [])
    wp1 = "--wp1" in names
    names = [n for n in names if n != "--wp1"]
    if names == ["--all"]:
        names = sorted(os.path.basename(f)[:-3] for f in glob.glob(os.path.join(TOOLS, "consolidation", "proposals_dp_*.py")))
    elif names == ["--wealth"]:
        names = sorted(os.path.basename(f)[:-3] for pat in ("proposals_wdp_*.py", "proposals_wp0_*.py")
                       for f in glob.glob(os.path.join(TOOLS, "consolidation", pat)))
    if not names:
        print(__doc__); return 2
    objs = dp_model.load_taxonomy()
    cands, decisions = load(names)
    fns = {f[0]: f for f in fw.FUNCTIONS}
    # A candidate registered at the WP0 integration (framework.WAVE_WP1F / WAVE_WP1C, in progress until its WP1 spec) is
    # still checked as its brief's candidate, not as an existing product.
    registered = {p[0] for p in getattr(fw, "WAVE_WP1F", [])} | {p[0] for ps in getattr(fw, "WAVE_WP1C", {}).values() for p in ps} \
        | {p[0] for ps in getattr(fw, "WAVE_BACKLOG", {}).values() for p in ps}
    backlog = set(getattr(fw, "WP1_BACKLOG", set()))
    existing = {p[0] for p in fw.PRODUCTS} - registered
    errs, warns = [], []
    ids, by_id = {}, {}
    for mod, c in cands:
        cid = c.get("id", "?")
        for k, t in FIELDS.items():
            if k not in c or not isinstance(c[k], t):
                errs.append(f"{cid}: missing or wrong-typed field '{k}' ({t.__name__})")
        if cid in ids:
            errs.append(f"{cid}: duplicate id (also in {ids[cid]})")
        ids[cid] = mod; by_id[cid] = c
        rescope = str(c.get("disposition", "")).strip().lower() in RESCOPE
        if cid in existing and not rescope:
            errs.append(f"{cid}: collides with an existing product (declare disposition='re-scope' to re-scope it in place)")
        elif rescope and cid not in existing:
            errs.append(f"{cid}: declared a re-scope but is not an existing product")
        elif rescope and cid in RETIRED_DP:
            errs.append(f"{cid}: re-scoped but listed in framework.RETIRED_PRODUCTS ({RETIRED_DP[cid]})")
        wealth = c.get("wave") in getattr(fw, "CANDIDATE_WAVES", set()) or c.get("wave") in LEGACY
        if wealth and cid not in existing and cid.startswith("DP-") and hasattr(fw, "id_block_of") and not fw.id_block_of(cid):
            errs.append(f"{cid}: a new wealth-manager id must fall in a block of framework.ID_BLOCKS (DP-300 onward)")
        if c.get("tier") not in fw.TIERS: errs.append(f"{cid}: unknown tier {c.get('tier')!r}")
        if c.get("type") not in fw.TYPES: errs.append(f"{cid}: unknown type {c.get('type')!r}")
        if c.get("domain") not in DD_NAMES: errs.append(f"{cid}: unknown owning domain {c.get('domain')!r}")
        wave = c.get("wave")
        if wave in LEGACY:
            warns.append(f"{cid}: wave {wave!r} is a W0-instruction code; use {LEGACY[wave]} (framework.WAVE_CODES)")
            wave = LEGACY[wave]
        elif wave not in WAVES:
            errs.append(f"{cid}: wave must be one of {sorted(WAVES)}")
        for fn in [c.get("primary")] + list(c.get("supporting", [])):
            if fn not in fns: errs.append(f"{cid}: unknown function {fn}")
        if c.get("primary") in RETIRED_FN:
            errs.append(f"{cid}: primary function {c['primary']} is retired ({RETIRED_FN[c['primary']]}); use its successor "
                        f"{getattr(fw, 'FUNCTION_SUCCESSOR', {}).get(c['primary'])}")
        for fn in c.get("supporting", []):
            if fn in RETIRED_FN:
                warns.append(f"{cid}: supporting function {fn} is retired ({RETIRED_FN[fn]})")
        if c.get("tier") == "Foundational" and wave not in FOUNDATIONAL_WAVES:
            warns.append(f"{cid}: a foundational candidate is normally in wave {sorted(FOUNDATIONAL_WAVES)}")
        if c.get("tier") == "Consumer-aligned" and wave in FOUNDATIONAL_WAVES:
            warns.append(f"{cid}: a consumer-aligned candidate in a foundational wave")
        if isinstance(wave, str) and wave.startswith("WP1C_") and DOMAIN_AREA.get(c.get("domain")) not in (None, wave[5:]):
            warns.append(f"{cid}: wave {wave} but owning domain {c.get('domain')} is in area {DOMAIN_AREA.get(c.get('domain'))}")
        for o in c.get("objects", []):
            if not (isinstance(o, tuple) and len(o) == 2):
                errs.append(f"{cid}: object must be (\"NN\", \"Object Name\"): {o!r}")
            elif o not in objs:
                errs.append(f"{cid}: unknown object {o!r} (check _catalog.txt)")
        if not c.get("objects"):
            errs.append(f"{cid}: no objects covered")
        if c.get("domain") and c.get("objects") and not any(o[0] == c["domain"] for o in c["objects"] if isinstance(o, tuple)):
            warns.append(f"{cid}: reads nothing from its owning domain {c.get('domain')}")
    by_name = {c["name"]: c["id"] for _, c in cands}
    for mod, c in cands:
        for u in c.get("upstream", []):
            if not u.startswith("DP-") and u in by_name:
                warns.append(f"{c['id']}: upstream '{u}' should be written as its id {by_name[u]}")
                u = by_name[u]
            if u.startswith("DP-"):
                if u not in existing and u not in by_id:
                    errs.append(f"{c['id']}: upstream {u} is neither an existing product nor a candidate loaded")
                elif u in RETIRED_DP and u not in by_id:
                    warns.append(f"{c['id']}: upstream {u} is retired ({RETIRED_DP[u]}); name its successor")
                elif u in PENDING_DP and u not in by_id:
                    warns.append(f"{c['id']}: upstream {u} is pending WP0 re-scope ({PENDING_DP[u]}) and not re-scoped by a loaded module")
                elif u in by_id and c.get("tier") == "Foundational" and by_id[u].get("tier") != "Foundational":
                    errs.append(f"{c['id']}: foundational candidate depends on consumer candidate {u}")
            else:
                warns.append(f"{c['id']}: upstream '{u}' named, not an id (a Wave E1 candidate from another brief)")

    # WP1 scope (WP1_Scope.md): the flag agrees with the register, and a WP1-scope candidate never waits on a backlog one
    for mod, c in cands:
        if "backlog" in c and bool(c["backlog"]) != (c["id"] in backlog):
            errs.append(f"{c['id']}: backlog flag {c['backlog']} disagrees with framework.WP1_BACKLOG")
        if c["id"] in backlog and c.get("tier") != "Consumer-aligned":
            errs.append(f"{c['id']}: only consumer-aligned candidates go to the backlog")
        if c["id"] not in backlog:
            for u in c.get("upstream", []):
                if u in backlog:
                    errs.append(f"{c['id']}: WP1-scope candidate depends on backlog candidate {u}")
    for pid, sp in dp_model.load_specs()[0].items():
        if pid not in RETIRED_DP and pid not in PENDING_DP:
            for u in sp.get("upstream", []):
                if u in backlog:
                    errs.append(f"{pid}: live product depends on backlog candidate {u}")

    # Dependency cycles among the candidates (upstream edges; existing products have no candidate upstream)
    graph = {c["id"]: [by_name.get(u, u) for u in c.get("upstream", []) if by_name.get(u, u) in by_id] for _, c in cands}
    state, cycles = {}, []
    def visit(n, path):
        state[n] = 1; path.append(n)
        for m in graph.get(n, []):
            if state.get(m) == 1:
                cycles.append(" -> ".join(path[path.index(m):] + [m]))
            elif state.get(m) is None:
                visit(m, path)
        path.pop(); state[n] = 2
    for n in graph:
        if state.get(n) is None:
            visit(n, [])
    for cyc in cycles:
        errs.append(f"dependency cycle: {cyc}")

    # Coverage: objects with CDEs in the owning domains of the loaded candidates
    doms = sorted({c["domain"] for _, c in cands if c.get("domain") in DD_NAMES})
    readers = [c for _, c in cands if not (wp1 and c.get("id") in backlog)]
    read = {o for c in readers for o in c.get("objects", []) if isinstance(o, tuple)}
    # Objects the live existing products already read count as covered. Not counted: products pending WP0 re-scope
    # (CW-041), retired products, and products re-scoped by a loaded candidate (their candidate objects count instead).
    specs, _, _ = dp_model.load_specs()
    # A pending product that a loaded module's DISPOSITIONS re-scopes in place keeps its reads until its spec is rewritten.
    skip = (set(PENDING_DP) - RESCOPED_IN_PLACE) | set(RETIRED_DP) | {c["id"] for _, c in cands
                                                if str(c.get("disposition", "")).strip().lower() in RESCOPE}
    read |= {(n, on) for pid, sp in specs.items() if pid not in skip for n, on, _ in sp["inputs"]}
    print(f"Candidates: {len(cands)} in {', '.join(names)}; owning Data Domains {', '.join(doms)}")
    for t in fw.TIERS:
        n = sum(1 for _, c in cands if c.get("tier") == t)
        if n: print(f"  {t}: {n}")
    for w in sorted(WAVES | set(LEGACY)):
        n = sum(1 for _, c in cands if c.get("wave") == w)
        if n: print(f"  Wave {w}: {n}")
    nb = sum(1 for _, c in cands if c.get("id") in backlog)
    if nb: print(f"  Backlog candidates (framework.WP1_BACKLOG): {nb}" + ("; not counted as readers (--wp1)" if wp1 else ""))
    n = sum(1 for _, c in cands if str(c.get("disposition", "")).strip().lower() in RESCOPE)
    if n: print(f"  Re-scopes of existing products (id kept): {n}")
    print(f"  Existing products not counted as readers: {len(skip)} (pending WP0 re-scope, retired, or re-scoped here)"
          + (f"; pending products re-scoped in place by DISPOSITIONS, counted: {', '.join(sorted(RESCOPED_IN_PLACE & set(PENDING_DP)))}"
             if RESCOPED_IN_PLACE & set(PENDING_DP) else ""))
    print("\nCoverage of objects with CDEs, by owning Data Domain:")
    uncovered = []
    for n in doms:
        cde_objs = [k for k, o in objs.items() if k[0] == n and any(x["cde"] for x in o["attrs"].values())]
        miss = [k for k in cde_objs if k not in read]
        print(f"  {n} {DD_NAMES[n]}: {len(cde_objs) - len(miss)}/{len(cde_objs)} objects with CDEs read (by a {'WP1-scope ' if wp1 else ''}candidate or an existing product)"
              + (f"; not read: {'; '.join(k[1] for k in miss)}" if miss else ""))
        uncovered += miss
    served = {c["primary"] for _, c in cands if c.get("primary") in fns}
    area_fns = sorted({fn for _, c in cands for fn in [c.get("primary")] + list(c.get("supporting", [])) if fn in fns})
    print("\nFunctions served as primary: " + ", ".join(sorted(served)))
    not_primary = [fn for fn in area_fns if fn not in served]
    if not_primary:
        print("Functions only supporting (no primary candidate): " + ", ".join(not_primary))
    print(f"\nDecisions proposed: {len(decisions)}" + (": " + ", ".join(d.get('id', '?') for d in decisions) if decisions else ""))
    for w in warns: print("WARN", w)
    for e in errs: print("ERROR", e)
    print(f"\n{len(errs)} error(s), {len(warns)} warning(s), {len(uncovered)} object(s) with CDEs not read by any candidate")
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
