"""Loads the data product framework and specs, resolves every input against the consolidated taxonomy, and validates them.

Usage (from _tools/):
  python data_products/dp_model.py                 validate every specs_*.py
  python data_products/dp_model.py specs_sales     validate one specs file (ignores products specified elsewhere)
  python data_products/dp_model.py --catalog FILE  write a flat object / attribute catalog for authoring
"""
import importlib, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(HERE)
sys.path.insert(0, TOOLS)
sys.path.insert(0, HERE)
sys.dont_write_bytecode = True

sys.path.insert(0, os.path.join(TOOLS, "capability_map"))
from taxonomy_builder import CONTENT, Consolidated, load_consolidation, model, DD_NAMES  # noqa: E402
import framework as fw  # noqa: E402

# Products pending WP0 re-scope (framework.RESCOPE_PENDING, CW-041): {id: decision}. Their specs are loaded but not
# validated, built or counted; a live product that lists one as upstream is a warning until WP0, counted on every run so
# the re-pointing stays visible.
PENDING = dict(getattr(fw, "RESCOPE_PENDING", {}))
PENDING_DEP = "live product {pid} depends on pending product {up}; re-point at WP0; {dec}"


# Retired products (framework.RETIRED_PRODUCTS, WP0; CW-207 and the decisions it names): {id: decision}. Their specs are
# still validated until the WP1 integration removes them (they read surviving objects; framework.py), but they are not
# live: live() leaves them out, the builders list them only as "Retired (CW-nnn)" and check_baseline.py reports them as
# retired. A live product that lists one as upstream is a warning until WP1 re-points it. A product both pending and
# retired is listed as retired; is_pending() stays true for it, so the model layers keep holding it back. Retired functions (framework.RETIRED_FUNCTIONS): a live product whose primary function is
# retired is an error; a retired supporting function is a warning; capability coverage counts live functions only.
RETIRED = dict(getattr(fw, "RETIRED_PRODUCTS", {}))
RETIRED_FNS = dict(getattr(fw, "RETIRED_FUNCTIONS", {}))
RETIRED_DEP = "live product {pid} depends on retired product {up}; re-point at WP1; {dec}"


def is_pending(pid):
    """In RESCOPE_PENDING (also when retired: the logical and semantic models keep treating it as pending)."""
    return pid in PENDING


def is_retired(pid):
    return pid in RETIRED


def live(specs):
    """The specs of live products (every product neither pending WP0 re-scope nor retired)."""
    return {pid: s for pid, s in specs.items() if pid not in PENDING and pid not in RETIRED}


def live_functions():
    """framework.FUNCTIONS without the retired functions."""
    return [f for f in fw.FUNCTIONS if f[0] not in RETIRED_FNS]

REQUIRED = {"definition": str, "business_questions": list, "grain": str, "dimensions": list, "measures": list,
            "inputs": list, "upstream": list, "refresh": str, "timeliness": str, "history": str,
            "classification": str, "pii": str, "delivery": list, "dq_rules": list}


def load_taxonomy():
    """{(NN, object name): object dict} over the consolidated taxonomy, with attributes keyed by name."""
    scl = load_consolidation()
    objs = {}
    for f in sorted(os.listdir(CONTENT)):
        if not (f.startswith("content_") and f.endswith(".py")):
            continue
        m = Consolidated(importlib.import_module(f[:-3]), scl)
        n = m.__name__.split("_")[1]
        for fam in model(m):
            for o in fam["objects"]:
                attrs = {}
                for x in o["attrs"]:
                    a = x["a"]
                    note = a[9] if len(a) > 9 else ""
                    attrs[a[0]] = {"id": x["id"], "def": a[1], "type": a[3], "code_list": a[4], "cde": a[8] == "Y",
                                   "pii": bool(re.search(r"\bPII\b", note)), "flag": x["flag"], "owner": x["owner"]}
                objs[(n, o["name"])] = {"domain": n, "family": fam["name"], "family_code": fam["code"], "code": o["code"],
                                        "name": o["name"], "grain": o["grain"], "kind": o["kind"], "attrs": attrs}
    return objs


def load_specs(only=None):
    """Merge SPECS from every specs_*.py (or just `only`). Returns ({id: spec}, {id: source file}, [errors])."""
    specs, where, errs = {}, {}, []
    files = [only] if only else sorted(f[:-3] for f in os.listdir(HERE) if f.startswith("specs_") and f.endswith(".py"))
    for name in files:
        mod = importlib.import_module(name)
        for pid, s in mod.SPECS.items():
            if pid in specs:
                errs.append(f"{pid}: specified in both {where[pid]} and {name}")
            specs[pid], where[pid] = s, name
    return specs, where, errs


def validate(specs, objs, partial=False):
    errs, warns = [], []
    reg = {p[0]: p for p in fw.PRODUCTS}
    backlog = {b[0] for b in fw.BACKLOG}
    fns = {f[0] for f in fw.FUNCTIONS}
    # Functions: home area and the L2 capabilities each runs (capability_map); every capability needs a function (CD-291)
    import areas as ar, content_capabilities as cc
    l2 = {c["id"] for l1 in cc.CAPABILITIES for c in l1["l2"]}
    for f in fw.FUNCTIONS:
        if len(f) != 7: errs.append(f"{f[0]}: function must be (code, name, area, capabilities, description, roles, decisions)"); continue
        if f[2] not in ar.AREA_IDS: errs.append(f"{f[0]}: unknown area {f[2]!r}")
        for c in f[3]:
            if c not in l2: errs.append(f"{f[0]}: unknown capability {c}")
    topics = {t[0] for t in fw.TOPICS}
    for n in DD_NAMES:
        if n not in fw.TOPIC_OF_DOMAIN: errs.append(f"Data Domain {n}: no topic in framework.TOPIC_OF_DOMAIN")
    for n, t in fw.TOPIC_OF_DOMAIN.items():
        if t not in topics: errs.append(f"TOPIC_OF_DOMAIN {n}: unknown topic {t}")
    for pid, t in fw.PRODUCT_TOPIC.items():
        if pid not in reg: errs.append(f"PRODUCT_TOPIC {pid}: not a registered product")
        if t not in topics: errs.append(f"PRODUCT_TOPIC {pid}: unknown topic {t}")
    served_caps = {c for f in live_functions() if len(f) == 7 for c in f[3]}
    for c in sorted(l2 - served_caps):
        errs.append(f"{c}: no live function runs this capability")
    for f in fw.FUNCTIONS:
        if f[0] in RETIRED_FNS and len(f) == 7 and f[3]:
            warns.append(f"{f[0]}: retired ({RETIRED_FNS[f[0]]}) but still lists capabilities {', '.join(f[3])}")
    for k in RETIRED_FNS:
        if k not in fns: errs.append(f"RETIRED_FUNCTIONS {k}: not in FUNCTIONS")
    for pid in RETIRED:
        if pid not in reg: errs.append(f"RETIRED_PRODUCTS {pid}: not a registered product")
    for p in fw.PRODUCTS:
        if p[2] not in fw.TIERS: errs.append(f"{p[0]}: unknown tier {p[2]}")
        if p[3] not in fw.TYPES: errs.append(f"{p[0]}: unknown type {p[3]}")
        if p[4] not in DD_NAMES: errs.append(f"{p[0]}: unknown owning domain {p[4]}")
        for fn in [p[6]] + p[7]:
            if fn not in fns: errs.append(f"{p[0]}: unknown function {fn}")
        if p[0] not in PENDING and p[0] not in RETIRED:      # live products: no retired primary function
            if p[6] in RETIRED_FNS:
                errs.append(f"{p[0]}: primary function {p[6]} is retired ({RETIRED_FNS[p[6]]}); successor "
                            f"{fw.FUNCTION_SUCCESSOR.get(p[6]) or 'none'}")
            for fn in p[7]:
                if fn in RETIRED_FNS:
                    warns.append(f"{p[0]}: supporting function {fn} is retired ({RETIRED_FNS[fn]})")
        if not partial and p[0] not in specs and fw.WAVE.get(p[0]) not in getattr(fw, "IN_PROGRESS", set()) \
                and p[0] not in PENDING and p[0] not in RETIRED:     # a retired product's spec is deleted at WP1 (CW-207)
            errs.append(f"{p[0]}: no specification")
    # The pending register (CW-041) holds only Consumer-aligned products of the wholesale Waves 1 to 4
    for pid, d in PENDING.items():
        if pid not in reg:
            errs.append(f"RESCOPE_PENDING {pid}: not a registered product")
        elif reg[pid][2] != "Consumer-aligned" or fw.WAVE.get(pid, "Wave 1") not in ("Wave 1", "Wave 2", "Wave 3", "Wave 4"):
            errs.append(f"RESCOPE_PENDING {pid}: only Consumer-aligned products of Waves 1 to 4 can be pending ({reg[pid][2]}, "
                        f"{fw.WAVE.get(pid, 'Wave 1')})")
    for b in fw.BACKLOG:
        if b[0] in reg: errs.append(f"{b[0]}: in both PRODUCTS and BACKLOG")
        for fn in [b[5]] + b[6]:
            if fn not in fns: errs.append(f"{b[0]}: unknown function {fn}")
        for d in b[8]:
            if d not in DD_NAMES: errs.append(f"{b[0]}: unknown input domain {d}")
    if not partial:
        lv = live(specs)
        served = {p[6] for p in fw.PRODUCTS if p[0] in lv} | {f for p in fw.PRODUCTS if p[0] in lv for f in p[7]}
        for fn in sorted(fns - served - set(RETIRED_FNS)):     # an error again once Phase 1 of the products expansion closes (plan §9 item 1)
            warns.append(f"{fn}: no specified product serves this function")

    for pid, s in specs.items():
        if pid not in reg:
            errs.append(f"{pid}: specified but not in framework.PRODUCTS"); continue
        if pid in PENDING and pid not in RETIRED:   # pending WP0 re-scope (CW-041): the spec is kept, not validated
            continue
        if pid in PENDING:                  # retired while pending: nothing to validate either
            continue
        for k, t in REQUIRED.items():
            if not isinstance(s.get(k), t) or (not s.get(k) and k != "upstream"):   # a root product has no upstream
                errs.append(f"{pid}: missing or empty '{k}' ({t.__name__})")
        for k in s:
            if k not in REQUIRED and k != "notes":
                errs.append(f"{pid}: unexpected field '{k}'")
        for k in ("business_questions", "dq_rules"):
            if isinstance(s.get(k), list) and not 3 <= len(s[k]) <= 6:
                errs.append(f"{pid}: '{k}' has {len(s[k])} items; the contract allows 3-6")
        if s.get("refresh") not in fw.REFRESH: errs.append(f"{pid}: refresh '{s.get('refresh')}' not in REFRESH")
        if s.get("classification") not in fw.CLASSIFICATIONS: errs.append(f"{pid}: classification '{s.get('classification')}' not in CLASSIFICATIONS")
        if s.get("pii") not in ("Y", "N"): errs.append(f"{pid}: pii must be 'Y' or 'N'")
        for d in s.get("delivery", []):
            if d not in fw.DELIVERY: errs.append(f"{pid}: delivery '{d}' not in DELIVERY")
        mnames = [mz[0] for mz in s.get("measures", []) if isinstance(mz, tuple) and mz]
        declared = {(n, on, a) for inp in s.get("inputs", []) if isinstance(inp, tuple) and len(inp) == 3
                    for n, on, al in [inp] if isinstance(al, list) for a in al}
        for mz in s.get("measures", []):
            if not (isinstance(mz, tuple) and len(mz) == 3 and all(isinstance(x, str) and x for x in mz[:2])
                    and isinstance(mz[2], list)):
                errs.append(f"{pid}: measure must be (name, definition, uses): {mz!r}"); continue
            name, _, uses = mz
            if not uses:
                errs.append(f"{pid}: measure '{name}' has an empty uses list")
            if len(set(map(repr, uses))) != len(uses):
                errs.append(f"{pid}: measure '{name}' repeats a use")
            for u in uses:
                if isinstance(u, str):
                    if u == name: errs.append(f"{pid}: measure '{name}' uses itself")
                    elif u not in mnames: errs.append(f"{pid}: measure '{name}' uses unknown measure '{u}'")
                elif isinstance(u, tuple) and len(u) == 3 and all(isinstance(x, str) for x in u):
                    if u not in declared:
                        errs.append(f"{pid}: measure '{name}' uses {u[0]}:{u[1]}.{u[2]}, which is not in its inputs")
                else:
                    errs.append(f"{pid}: measure '{name}' use must be (NN, object, attribute) or a measure name: {u!r}")
        seen, pii_used, domains = set(), [], set()
        for inp in s.get("inputs", []):
            if not (isinstance(inp, tuple) and len(inp) == 3 and isinstance(inp[2], list)):
                errs.append(f"{pid}: input must be (NN, object, [attributes]): {inp!r}"); continue
            n, on, an = inp
            o = objs.get((n, on))
            if not o:
                near = [k[1] for k in objs if k[0] == n and on.lower().split()[0] in k[1].lower()][:5]
                errs.append(f"{pid}: object '{on}' not found in domain {n}" + (f" (similar: {near})" if near else "")); continue
            if (n, on) in seen: errs.append(f"{pid}: object {n}:{on} listed twice")
            seen.add((n, on)); domains.add(n)
            if not an: errs.append(f"{pid}: {n}:{on} lists no attributes")
            if len(set(an)) != len(an): errs.append(f"{pid}: {n}:{on} repeats an attribute")
            for a in an:
                if a not in o["attrs"]:
                    errs.append(f"{pid}: attribute '{a}' not in {n}:{on} (has: {', '.join(o['attrs'])})")
                elif o["attrs"][a]["pii"]:
                    pii_used.append(a)
        if pii_used and s.get("pii") == "N":
            warns.append(f"{pid}: pii='N' but consumes attributes noted as PII: {', '.join(pii_used[:5])}")
        own = reg[pid][4]
        if domains and own not in domains:
            warns.append(f"{pid}: owning domain {own} is not among its input domains {sorted(domains)}")
        for u in s.get("upstream", []):
            if u == pid: errs.append(f"{pid}: lists itself as upstream")
            elif u in backlog: errs.append(f"{pid}: upstream {u} is a backlog product")
            elif u not in reg: errs.append(f"{pid}: unknown upstream {u}")
            elif u in RETIRED:
                if pid not in RETIRED: warns.append(f"{pid}: " + RETIRED_DEP.format(pid=pid, up=u, dec=RETIRED[u]))
            elif u in PENDING: warns.append(f"{pid}: " + PENDING_DEP.format(pid=pid, up=u, dec=PENDING[u]))
            elif reg[pid][2] == "Foundational" and reg[u][2] != "Foundational":
                errs.append(f"{pid}: foundational product depends on consumer-aligned {u}")
        if s.get("upstream") == [] and reg[pid][2] != "Foundational":
            errs.append(f"{pid}: consumer-aligned products must build on at least one upstream product")
    # cycles
    graph = {pid: [u for u in s.get("upstream", []) if u in reg] for pid, s in live(specs).items()}
    state = {}

    def visit(v, path):
        if state.get(v) == 1:
            errs.append("upstream cycle: " + " -> ".join(path + [v])); return
        if state.get(v) == 2: return
        state[v] = 1
        for u in graph.get(v, []): visit(u, path + [v])
        state[v] = 2
    for v in graph: visit(v, [])
    return errs, warns


def write_catalog(objs, path):
    lines, last = [], None
    for (n, on), o in objs.items():
        if (n, o["family"]) != last:
            lines.append(f"\n## [{n} {DD_NAMES[n]}] {o['family_code']} {o['family']}")
            last = (n, o["family"])
        lines.append(f'("{n}", "{on}")  grain: {o["grain"]} | {o["kind"]}')
        lines.append("    " + "; ".join(a + ("*" if v["cde"] else "") + (" [PII]" if v["pii"] else "")
                                       + ("" if v["flag"] == "Mastered here" else f" ->{v['owner']}") for a, v in o["attrs"].items()))
    with open(path, "w", encoding="utf-8") as f:
        f.write("Legend: * = CDE; [PII] = personal data; ->NN = reference to / copy of a concept mastered in Data Domain NN\n")
        f.write("\n".join(lines))


if __name__ == "__main__":
    args = sys.argv[1:]
    objs = load_taxonomy()
    if args[:1] == ["--catalog"]:
        write_catalog(objs, args[1]); print("wrote", args[1], len(objs), "objects"); sys.exit(0)
    only = args[0].removesuffix(".py") if args else None
    specs, _, errs = load_specs(only)
    e, w = validate(specs, objs, partial=bool(only))
    errs += e
    for x in w: print("WARN ", x)
    for x in errs: print("ERROR", x)
    dep = [x for x in w if "depends on pending product" in x]
    rdep = [x for x in w if "depends on retired product" in x]
    held = sorted(p for p in specs if is_pending(p) and not is_retired(p))
    gone = sorted(p for p in specs if is_retired(p))
    if gone:
        print(f"{len(gone)} retired product spec(s), not live (validated until WP1 removes them unless pending): "
              + ", ".join(f"{p} ({RETIRED[p]})" for p in gone))
    if rdep:
        print(f"{len(rdep)} warning(s) are live products that depend on a retired product "
              f"({len({x.split(':')[0] for x in rdep})} live products to re-point at WP1)")
    if held:
        print(f"{len(held)} product spec(s) pending WP0 re-scope, not validated (CW-041): {', '.join(held)}")
    if dep:
        print(f"{len(dep)} warning(s) are live products that depend on a pending product "
              f"({len({x.split(':')[0] for x in dep})} live products to re-point)")
    print(f"{len(specs) - len(held) - len([p for p in gone if p in PENDING])} product spec(s) checked "
          f"({len(live(specs))} live): {len(errs)} error(s), {len(w)} warning(s)")
    sys.exit(1 if errs else 0)
