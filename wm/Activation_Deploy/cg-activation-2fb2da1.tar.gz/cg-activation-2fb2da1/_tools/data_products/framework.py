"""Data product framework: the business functions of the firm (the wholesale functions FN-01 to FN-51, retained until WP0 of
the wealth-manager rework, and the wealth-manager functions FN-60 onward; CW-002, CW-013), the specified data product register and the
identified backlog. Attribute-level specifications live in specs_*.py (see CONTRACT.md); build_data_products.py merges and
validates them against the consolidated taxonomy.
"""

VERSION = "Draft v0.2"
AS_OF = "2026-10-08"

# (code, function, area, capabilities run, description, typical roles, key decisions the function makes)
# area: the home area of the function (capability_map/areas.py); capabilities: the L2 capabilities of the business
# capability map (capability_map/content_capabilities.py) the function runs. A leadership function that only consumes
# capabilities may list none. FN-01 to FN-19 were the wholesale distribution and plan recordkeeping functions (Draft
# v0.1); FN-20 to FN-51 are the enterprise functions added for the data products expansion (CD-291), cut from the
# capability map by owner role; FN-60 onward are the wealth-manager functions (CW-002, W0).
#
# W0 re-pointing (2026-10-14; Wealth_Manager_Rework_Plan.md section 8.1; CW-013, CW-016, CW-018): every function was
# re-pointed to the re-cut capability map; old codes were kept because products and specs name them.
# WP0 re-cut (2026-10-15; CW-200; FUNCTION_DISPOSITIONS below): sixteen wholesale functions are retired (FN-01 to FN-11,
# FN-13, FN-14, FN-18; FN-25 and FN-26 keep their codes with no products), five are re-cut and keep their codes
# (FN-12, FN-15, FN-16, FN-17, FN-19), FN-20 to FN-24 and FN-27 to FN-51 are kept, FN-60 to FN-78 (W0) are confirmed
# against the capability map, and FN-79 Business Line Leadership & Strategy is added as the successor of FN-01. A retired
# function stays in this list (codes are never reused and the pending wholesale products still name them) with an
# empty capability list; RETIRED_FUNCTIONS flags it, and validators and builders skip it (live_functions()). Live
# products name live functions only: their primary and supporting functions were re-pointed to the successor at WP0.
FUNCTIONS = [
    # --- Wholesale distribution functions: retired or re-cut at WP0 (CW-200; FUNCTION_DISPOSITIONS) ------------------
    ("FN-01", "Distribution Leadership & Strategy", "DIS", [],
     "Set distribution strategy, channel priorities, resourcing and targets across the intermediary, institutional and "
     "retirement channels. Retired at WP0 (CW-200): the firm's leadership consumer is FN-79 Business Line Leadership & "
     "Strategy; the channels are run by FN-74 and FN-75.",
     "Head of Distribution; channel heads; Chief Operating Officer (Distribution)",
     "Where to invest sales capacity; channel and product priorities; target setting; performance management of "
     "channel leaders."),
    ("FN-02", "External Wholesaling", "DIS", [],
     "Field sales force covering advisors, teams, branches and offices in an assigned territory. Retired at WP0 "
     "(CW-200): coverage of third-party advisors is run by FN-74 at reduced depth; territories have no successor (CW-907).",
     "External wholesaler; regional sales director; divisional sales manager",
     "Which advisors to see; what to discuss; where to spend time and expense; which products to position."),
    ("FN-03", "Internal / Inside Sales", "DIS", [],
     "Phone and digital sales coverage of advisors, paired with external wholesalers. Retired at WP0 (CW-200): "
     "intermediary coverage is run by FN-74.",
     "Internal wholesaler; hybrid / virtual wholesaler; inside sales manager",
     "Call priorities; follow-up on leads and engagement signals; meeting set-up for externals."),
    ("FN-04", "National Accounts & Strategic Partnerships", "DIS", [],
     "Managed home-office relationships with broker-dealers, platforms and banks: access, shelf, models and partner "
     "economics. Retired at WP0 (CW-200): partner agreements, payments, placement and model delivery are run by FN-74, "
     "ETF capital markets by FN-23.",
     "National account manager; head of strategic partnerships; platform relationship manager",
     "Which partners to invest in; agreement and rev-share terms; shelf and model placement priorities; partner "
     "business plans."),
    ("FN-05", "Institutional Sales & Consultant Relations", "DIS", [],
     "Won and retained institutional mandates, directly and through investment consultants. Retired at WP0 (CW-200): "
     "institutional advisory, OCIO sales and consultant relations are run by FN-75.",
     "Institutional relationship manager; consultant relations manager; head of institutional",
     "Which searches and prospects to pursue; consultant coverage priorities; pipeline management."),
    ("FN-06", "RFP, DDQ & Proposal Management", "DIS", [],
     "Produced RFP, RFI and DDQ responses and consultant database submissions. Retired at WP0 (CW-200): RFPs, DDQs and "
     "consultant databases are run by FN-75 (C-11.05).",
     "RFP manager; proposal writer; content librarian",
     "Bid / no-bid; content currency and approval; resourcing of responses."),
    ("FN-07", "Retirement / DCIO", "DIS", [],
     "Sold investment-only products into defined contribution plans through recordkeepers, plan advisors and "
     "consultants. Retired at WP0 (CW-200): the firm recordkeeps its own plans (FN-19) and serves sponsors and "
     "participants through FN-71; investment-only selling through other recordkeepers is an FN-74 coverage segment.",
     "DCIO wholesaler; retirement national accounts; DCIO strategy lead",
     "Recordkeeper and advisor priorities; plan lineup opportunities; CIT vs mutual fund positioning."),
    ("FN-08", "Sales Operations, Strategy & Analytics", "DIS", [],
     "Ran the CRM, sales reporting, segmentation and sales-force effectiveness. Retired at WP0 (CW-200): client assets, "
     "flows and attribution are run by FN-77, the client and household master by FN-62, advisor coverage and capacity by "
     "FN-73 and intermediary firm and advisor profiles by FN-74.",
     "Sales operations lead; distribution analytics; CRM product owner",
     "Segmentation and targeting models; reporting definitions; sales-force sizing and deployment."),
    ("FN-09", "Marketing & Digital", "CLA", [],
     "Created demand through campaigns, content, events and digital properties aimed at intermediaries. Retired at WP0 "
     "(CW-200): client acquisition, campaigns and consent are run by FN-76, the digital client experience by FN-61.",
     "CMO; campaign manager; content strategist; digital / marketing operations",
     "Campaign investment and targeting; content priorities; channel mix; lead hand-off rules."),
    ("FN-10", "Product Management & Product Strategy", "CLA", [],
     "Owned the product line-up from a distribution perspective. Retired at WP0 (CW-200): offering management is run by "
     "FN-78, product strategy, launches and governance reviews by FN-37.",
     "Product manager; product strategy; product specialist",
     "Launch, close, merge or reprice products; share class and vehicle strategy; distribution priorities per "
     "product."),
    ("FN-11", "Sales Compensation & Territory Management", "CLA", [],
     "Designed territories, set goals, applied crediting rules and calculated incentive compensation for the wholesale "
     "sales force. Retired at WP0 (CW-200): 07 retired (CW-907); the incentive compensation half (03 Incentive "
     "Compensation Plan to Compensation Statement, CW-064) is run by FN-73 for the firm's own advisors; territories and "
     "wholesale crediting have no successor.",
     "Sales compensation manager; territory planning; HR compensation",
     "Territory alignment; goal setting; crediting disputes; payout approval."),
    ("FN-12", "Client Revenue & Profitability Finance", "DIS", ["C-26.02"],
     "Accounts for client revenue (advisory and account fees, commissions, fund management fees, cash program revenue and "
     "the thin intermediary channel's payments), allocates expense, and measures profitability and cost to serve by "
     "offering, channel and client segment. Re-cut at WP0 (CW-200) from Distribution Finance & FP&A with 10 Client "
     "Revenue, Pricing Economics & Profitability; fee calculation and billing are FN-72's.",
     "Head of Client Revenue Finance; FP&A (business lines); pricing economics analysts; intermediary payments team",
     "Revenue recognition and accruals; allocation drivers; offering, segment and channel profitability; cost-to-serve "
     "and lifetime value models; pricing economics of fee changes."),
    ("FN-13", "Distribution Compliance & Product Governance", "CLA", [],
     "Oversaw marketing review, distributor oversight, gifts and non-cash compensation, licensing, complaints and product "
     "governance for the wholesale business. Retired at WP0 (CW-200; CW-015): retail conduct, communications review, "
     "licensing and records retention are run by FN-68, product governance reviews by FN-37, firm-level programs by FN-44.",
     "Distribution compliance; marketing review; registrations / licensing; product governance",
     "Approval of communications; distributor risk ratings; exceptions and escalations; target-market adjustments."),
    ("FN-14", "Institutional Client Service & Reporting", "DIS", [],
     "Serviced institutional clients after funding. Retired at WP0 (CW-200): institutional and OCIO servicing and "
     "reporting are run by FN-75, institutional fee billing by FN-72.",
     "Client service manager; client reporting; institutional operations",
     "Service levels; escalation of at-risk relationships; reporting changes; fee billing accuracy."),
    ("FN-15", "Fund Shareholder Servicing & TA Oversight", "FOP", ["C-07.08"],
     "Oversees the transfer agent (in house by default, a provider under the outsourcing lever) and the fund-level "
     "shareholder obligations: TA service levels and controls, fund shareholder reports and prospectus delivery, fund "
     "proxy solicitation and the omnibus and intermediary operations of the fund complex. Re-cut at WP0 (CW-200) from "
     "Investor Servicing & Fund Operations; client service for every account is FN-67's.",
     "TA oversight; fund shareholder communications; intermediary and omnibus operations",
     "TA performance actions; service exceptions; fund shareholder communication and proxy solicitation choices."),
    ("FN-16", "Market & Competitive Intelligence", "DIS", ["C-26.03", "C-10.09"],
     "Tracks the retail and wealth market: competitor firms and offerings, industry flows and share for the direct, advice "
     "and workplace businesses, fee and pricing comparisons, peer universes and ratings, and the advisor-channel market at "
     "reduced depth. Re-cut at WP0 (CW-200) with 11.",
     "Market intelligence analyst; competitive intelligence; strategy",
     "Where the market is growing; competitive threats; peer positioning, pricing and white space."),
    ("FN-17", "Third-Party Data Licensing & Entitlements", "FDN", ["C-14.09"],
     "Licenses and administers the firm's third-party data: vendor datasets and agreements, permitted use, user and "
     "application entitlements (real-time quotes, account aggregation, planning and research data), usage reporting and "
     "data spend. Re-cut at WP0 (CW-200) from Data Office & Distribution Data Management as the enterprise function of "
     "14; mastering, data quality and the catalog are FN-49's and FN-50's, attribution operations FN-77's.",
     "Head of Market Data & Licensing; data licensing managers; entitlements administration",
     "Data sourcing and vendor spend; permitted-use rulings; entitlement grants and audits; renewal and exit decisions."),
    ("FN-18", "EU / UK Cross-Border Distribution", "DIS", [],
     "Distributed UCITS, AIFs and UK funds across European and UK markets. Retired at WP0 (CW-200; CW-003): EU and UK "
     "distribution is out of scope; no successor.",
     "Head of international distribution; country heads; cross-border registration",
     "Which markets and share classes to register; distributor network; inducement and product governance "
     "arrangements."),
    ("FN-19", "Retirement Plan Services (Recordkeeping)", "BWO", ["C-08.01", "C-08.02", "C-08.03", "C-08.04", "C-08.05", "C-08.06"],
     "Administers the plans the firm recordkeeps: plan documents, participant records, contributions, loans, "
     "distributions, compliance testing, government filings and CIT plan participation. Re-cut (adapted) at WP0 "
     "(CW-200): sponsor relationships, in-plan advice and rollover capture are FN-71's.",
     "Plan services operations; plan compliance; conversions",
     "Good-order and posting decisions on payroll batches; loan and distribution approvals; test corrections and "
     "correction programs; filing and notice deadlines; conversion blackout timing."),
    # --- Enterprise functions (CD-291) ---------------------------------------------------------------------------
    ("FN-20", "Investment Research", "INV", ["C-01.01", "C-01.02", "C-01.03"],
     "Forms the firm's investment views on issuers, securities, factors and markets, and records the meetings and "
     "models behind them.",
     "Director of Research; equity and credit analysts; quantitative and macro research",
     "Coverage priorities; ratings and recommendations; model and note publication; issuer meeting follow-up and "
     "wall crossings."),
    ("FN-21", "Portfolio Management", "INV", ["C-02.01", "C-02.02", "C-02.03", "C-02.07"],
     "Decides what each portfolio holds: investment policy and asset allocation, portfolio construction and "
     "rebalancing, model portfolios and portfolio manager assignment.",
     "Chief Investment Officer; heads of portfolio management; portfolio managers; investment committee",
     "Target weights and rebalances; cash deployment; model portfolio changes; manager assignments; investment "
     "committee approvals."),
    ("FN-22", "Managed Accounts & ETF Portfolio Management", "INV", ["C-02.04", "C-02.06"],
     "Runs the portfolio side of the model and ETF programs: model delivery to intermediary platforms and sponsors, the "
     "tax management of the institutional and sponsor separate accounts the firm manages on its portfolio book (18, 24), "
     "and ETF basket construction. Kept at WP0 (CW-200): the managed accounts of the firm's own clients are FN-63's (46).",
     "Head of Managed Accounts; Head of ETF Portfolio Management; SMA portfolio implementation; basket desk",
     "Model updates sent to sponsors; customization and tax-loss harvesting rules for separate accounts; daily creation "
     "and redemption baskets."),
    ("FN-23", "Trading & ETF Capital Markets", "INV", ["C-03.01", "C-03.02", "C-03.03", "C-03.04", "C-01.04", "C-03.05"],
     "Executes investment decisions: order management, execution and allocation, broker and counterparty approval, "
     "best execution and transaction cost analysis, research payments, and the authorized participant "
     "relationships of the ETF business.",
     "Head of Trading; traders by asset class; Head of ETF Capital Markets; trading compliance liaison",
     "Venue and broker selection; allocation across accounts and sleeves; broker approvals and limits; commission "
     "and research budgets; AP engagement."),
    ("FN-24", "Stewardship & Sustainable Investing", "INV", ["C-01.05", "C-01.06"],
     "Acts as a shareholder in investee companies (proxy voting, including the investor-choice voting options, and "
     "engagement) and sources ESG data and produces the firm's voluntary climate and sustainability reporting and the "
     "metrics behind ESG-named funds (SEC Names Rule).",
     "Head of Stewardship; Head of Sustainable Investing; ESG analysts; proxy operations",
     "Voting decisions against policy; investor-choice voting programs; engagement targets and escalation; ESG data "
     "sources and scoring; climate targets and disclosures."),
    ("FN-25", "Private Markets Investing", "INV", [],
     "Sourced, diligenced and monitored private investments and formed private funds. Retired at WP0 (CW-200; CW-016, "
     "CW-930): the code is kept with no products; DP-137 and DP-138 retire (CW-207) and the due diligence of third-party "
     "private funds offered through feeders is FN-70's (52).",
     "Head of Private Markets; deal teams; portfolio company monitoring; fund formation counsel liaison",
     "Pipeline pursuit and investment committee decisions; portfolio company actions; fund terms and closes; "
     "placement agent mandates."),
    ("FN-26", "Private Markets Operations & Investor Relations", "INV", [],
     "Administered private fund investors and capital. Retired at WP0 (CW-200; CW-016, CW-930): the code is kept with no "
     "products; DP-116, DP-117, DP-136, DP-139 and DP-160 retire (CW-207) and feeder subscriptions are 15 Alternative "
     "Investment Subscription in the re-scoped DP-093.",
     "Head of Private Markets Operations; investor relations; fund administration oversight; fund finance",
     "Call and distribution notices; capital account allocations; credit facility draws; waterfall calculations; "
     "ILPA reporting content."),
    ("FN-27", "Investment Operations & Book of Record", "IOP", ["C-04.02", "C-04.03"],
     "Keeps the investment book of record: portfolio set-up and maintenance, start-of-day positions, holdings, tax "
     "lots, cash and portfolio transactions.",
     "Head of Investment Operations; IBOR operations; portfolio data management",
     "Portfolio and sleeve set-up; position and cash exceptions; IBOR versus accounting book differences; data "
     "corrections."),
    ("FN-28", "Pricing, Valuation & Market Data", "IOP", ["C-04.04", "C-04.05", "C-04.06"],
     "Prices the instruments the firm holds, runs price challenges and fair value decisions, and manages market "
     "and index data.",
     "Head of Pricing and Valuation; valuation committee; Head of Market Data; pricing analysts",
     "Pricing source hierarchy; stale and challenged prices; fair value marks for hard-to-value assets; index and "
     "market data sourcing."),
    ("FN-29", "Trade Operations, Settlement & Collateral", "IOP", ["C-04.07", "C-04.08", "C-04.09", "C-04.10"],
     "Confirms, matches and settles trades, manages settlement fails and CSDR penalties, runs the OTC derivative "
     "lifecycle, margin and collateral, and maintains standing settlement instructions.",
     "Head of Trade Operations; settlements; derivatives operations; collateral management",
     "Fail resolution and penalty disputes; collateral calls and eligibility; SSI changes; counterparty exposure "
     "escalation."),
    ("FN-30", "Investment Risk", "IOP", ["C-05.01", "C-05.02"],
     "Measures portfolio risk: exposures, VaR and tracking error, stress tests, liquidity classification (Rule "
     "22e-4), derivatives risk (Rule 18f-4) and product risk indicators.",
     "Head of Investment Risk; Liquidity Risk Management Program Administrator; risk analysts",
     "Risk limit breaches and escalation; liquidity bucket assignments; derivatives risk program compliance; "
     "product risk indicator disclosures."),
    ("FN-31", "Performance Measurement", "IOP", ["C-05.03", "C-05.04", "C-05.10"],
     "Calculates and certifies official returns at portfolio, share class and composite level, attribution and "
     "risk-adjusted statistics, GIPS composites, and private market IRRs and multiples.",
     "Head of Performance Measurement; performance analysts; GIPS compliance",
     "Official return sign-off; composite membership; attribution methodology; return restatements."),
    ("FN-32", "Investment Compliance", "IOP", ["C-05.06", "C-05.07", "C-05.08"],
     "Codes investment guidelines and regulatory limits, monitors pre- and post-trade compliance, and manages "
     "breaches and remediation.",
     "Head of Investment Compliance; guideline coding; compliance monitoring analysts",
     "Rule interpretation and coding; alert disposition; breach classification and client notification; "
     "remediation deadlines."),
    ("FN-33", "Fund Accounting & Administration", "FOP", ["C-06.01", "C-06.02", "C-06.03", "C-06.10", "C-06.12"],
     "Produces fund ledgers and NAVs, accrues expenses, calculates income and distributions, applies swing "
     "pricing, corrects NAV errors, and oversees fund service providers.",
     "Head of Fund Accounting; Fund Treasurer; Head of Fund Administration; fund administrator oversight",
     "NAV release and tolerance exceptions; expense accrual changes; distribution rates; NAV error materiality; "
     "service provider SLAs."),
    ("FN-34", "Custody & Asset Servicing", "FOP", ["C-06.04", "C-06.05", "C-06.06", "C-06.07"],
     "Runs the custodian network and safekeeping accounts, cash and position reconciliations, corporate action "
     "processing and income collection, tax reclaims, securities lending, and client money and client assets.",
     "Head of Asset Servicing; custody operations; reconciliations; corporate actions; securities lending",
     "Custodian selection and monitoring; reconciliation break resolution; corporate action elections; lending "
     "program parameters; CASS compliance."),
    ("FN-35", "Transfer Agency Operations", "FOP", ["C-07.02", "C-07.03", "C-07.04", "C-07.08"],
     "Processes fund orders and their settlement with intermediaries, ETF primary-market orders with authorized "
     "participants, shareholder identity verification and AML monitoring, and oversees an outsourced transfer "
     "agent.",
     "Head of Transfer Agency; Head of ETF Operations; BSA / AML Officer (shareholder accounts); TA oversight",
     "Order acceptance and as-of processing; settlement exceptions; AML alert disposition; TA control report "
     "follow-up."),
    ("FN-36", "Fund Legal, Board & Regulatory Reporting", "FOP", ["C-06.08", "C-06.09", "C-06.11"],
     "Supports fund boards and trustees, manages advisory agreements and Section 15(c) renewals, and files fund "
     "regulatory reports (N-PORT, N-CEN, Form PF, AIFMD Annex IV).",
     "Head of Fund Legal; Head of Fund Regulatory Reporting; fund board secretariat",
     "Board agenda and approvals; 15(c) materials; filing accuracy and deadlines; RIC qualification tests."),
    ("FN-37", "Product Development & Lifecycle", "CLA", ["C-10.01", "C-10.02", "C-10.03", "C-10.04"],
     "Plans the product range and runs the events that change it: new product approval and launch, share class and "
     "fee changes, mergers, conversions and liquidations, and periodic product governance reviews.",
     "Head of Product Development; Head of Product Governance; product approval committee; launch project managers",
     "Business case approval; launch readiness; change and closure decisions; value assessment outcomes."),
    ("FN-38", "Finance, Controllership & FP&A", "CORP", ["C-13.01", "C-13.02", "C-13.03", "C-13.04", "C-13.17"],
     "Keeps the general ledger and closes the books, accounts for revenue, payables and receivables, plans and "
     "forecasts, and administers travel and expense.",
     "Finance Controller; Head of FP&A; accounting operations; expense administration",
     "Close calendar and adjustments; revenue recognition; budget and forecast versions; expense policy "
     "exceptions."),
    ("FN-39", "Tax", "CORP", ["C-13.05"],
     "Manages corporate tax positions, provisions and filings, and coordinates fund and investor tax matters "
     "produced elsewhere.",
     "Head of Tax; tax accounting; tax compliance",
     "Provision and filing positions; transfer pricing; tax treatment of new products and entities."),
    ("FN-40", "Treasury & Regulatory Capital", "CORP", ["C-13.06", "C-13.07", "C-13.14", "C-13.15"],
     "Manages corporate cash, funding and hedging, seed and co-investment capital, regulatory capital (net "
     "capital, ICARA) and corporate insurance.",
     "Group Treasurer; Head of Regulatory Capital; treasury operations",
     "Liquidity and funding; seed capital deployment and recycling; capital adequacy buffers; insurance cover."),
    ("FN-41", "Human Resources", "CORP", ["C-13.08", "C-13.09"],
     "Manages the workforce: hiring, jobs and positions, employment events, performance, talent and learning, "
     "compensation and benefits.",
     "Chief Human Resources Officer; HR business partners; compensation and benefits; talent and learning",
     "Headcount plan; compensation cycles; performance and talent reviews; benefits design; regulatory training "
     "completion."),
    ("FN-42", "Enterprise Risk, Resilience & Model Risk", "CORP", ["C-12.01", "C-12.02", "C-12.03", "C-12.04", "C-12.13"],
     "Runs the firm's risk framework: risk and control assessments, incidents and loss events, key risk "
     "indicators, operational resilience, model risk management and third-party risk assessment.",
     "Head of Operational Risk; Head of Operational Resilience; Head of Model Risk; Head of Third-Party Risk",
     "Risk appetite and ratings; incident escalation; control testing; model validation and tiering; resilience "
     "tolerances; third-party risk tiers."),
    ("FN-43", "Internal Audit", "CORP", ["C-12.05"],
     "Independently assesses controls across the firm: the audit universe, plans, engagements, findings and "
     "remediation tracking.",
     "Chief Audit Executive; audit managers; audit committee liaison",
     "Audit plan and coverage; finding ratings; remediation acceptance and closure."),
    ("FN-44", "Corporate Compliance", "CORP", ["C-12.06", "C-12.07", "C-12.08", "C-12.09", "C-12.14", "C-12.15", "C-12.17"],
     "Maintains firm registrations and manages regulatory exams and change, the policy library and attestations, "
     "code of ethics and conflicts, AML and sanctions program, restricted lists and trade surveillance.",
     "Chief Compliance Officer; BSA / AML Officer; compliance testing; regulatory affairs",
     "Exam responses; policy approvals; personal trading pre-clearance; sanctions screening disposition; "
     "surveillance case outcomes; regulatory change impact."),
    ("FN-45", "Legal & Company Secretariat", "CORP", ["C-12.10", "C-12.11", "C-12.12"],
     "Manages the enterprise contract repository, legal matters, litigation and legal holds, and the governance of "
     "the firm's legal entities.",
     "General Counsel; Company Secretary; legal operations",
     "Contract approval and renewal; matter strategy and reserves; hold scope; board resolutions and officer "
     "appointments."),
    ("FN-46", "Procurement & Third-Party Management", "CORP", ["C-13.10", "C-13.13", "C-06.10"],
     "Sources and manages suppliers: sourcing events, purchase orders and invoices, supplier performance, the "
     "outsourcing and ICT third-party register, and oversight of fund service providers.",
     "Head of Procurement; vendor management office; outsourcing oversight",
     "Supplier selection and terms; renewal and exit; performance scorecards; critical and ICT third-party "
     "designations."),
    ("FN-47", "Corporate Communications & Public Affairs", "CORP", ["C-13.11", "C-13.16"],
     "Manages the corporate brand, media relations and press, internal communications, government relations and "
     "lobbying disclosure.",
     "Head of Corporate Communications; Head of Government Relations; media relations",
     "Press responses and crisis communications; brand standards; policy positions; lobbying disclosures."),
    ("FN-48", "Workplace & Corporate Services", "CORP", ["C-13.12", "C-13.18", "C-13.19"],
     "Manages real estate and facilities, physical security, and health and safety.",
     "Head of Corporate Real Estate; Head of Workplace Services; facilities management",
     "Site strategy and leases; space allocation; physical access; incident response."),
    ("FN-49", "Enterprise Data Management", "FDN", ["C-04.01", "C-14.08"],
     "Masters the security and issuer master and the firm's shared reference data (calendars, geography, "
     "currencies, legal entities, organization units).",
     "Head of Enterprise Data Management; security master operations; reference data stewards",
     "Instrument set-up and golden record rules; identifier sources; reference list changes; vendor source "
     "hierarchy."),
    ("FN-50", "Data Governance & Analytics", "FDN", ["C-14.04", "C-14.05", "C-14.06", "C-14.07"],
     "Governs data across the firm: ownership and stewardship, critical data elements, data quality, the catalog, "
     "glossary and lineage, business intelligence and data products, and AI and analytics model governance. The "
     "enterprise successor of FN-17.",
     "Chief Data Officer; Head of Data Governance; data stewards; BI and analytics platform owners",
     "CDE designation; DQ thresholds and issue priorities; catalog and taxonomy releases; product certification; "
     "AI use case approval."),
    ("FN-51", "Technology, Information Security & Change Portfolio", "CORP", ["C-14.01", "C-14.02", "C-14.03", "C-14.10"],
     "Runs the application and IT asset inventory, identity and access, information security, IT service and "
     "incident management, and the change and project portfolio.",
     "Chief Information Officer; Chief Information Security Officer; Head of Enterprise PMO; IT service management",
     "System of record designations; access certifications; security incident response; change approvals; "
     "portfolio prioritization."),
    # --- Wealth-manager functions (CW-002, CW-013 to CW-018; W0 2026-10-14) ----------------------------------------
    ("FN-60", "Financial Planning & Advice", "CLA", ["C-16.01", "C-16.02", "C-16.03", "C-16.04"],
     "Gives advice to clients and households: gathers goals and circumstances, builds and updates financial plans, "
     "makes recommendations with the best-interest and fiduciary evidence behind them, documents rollover "
     "recommendations, and runs the periodic reviews of each advice engagement.",
     "Head of Advice; Head of Financial Planning; financial advisors and planners; advice methodology and quality",
     "Planning assumptions and methodology; recommendations and the reasonably available alternatives considered; "
     "rollover recommendations under PTE 2020-02; review cadence and triggers; plan updates after life events."),
    ("FN-61", "Digital Advice & Client Experience", "CLA", ["C-21.02", "C-16.01", "C-16.02", "C-15.03"],
     "Runs the digital advice service and the client's digital experience: online profiling and risk questionnaires, "
     "algorithmic goals-based plans and recommendations at scale, and the web and mobile journeys, alerts and "
     "engagement that serve every line.",
     "Head of Digital; Head of Digital Advice; digital product owners; advice algorithm team; client experience "
     "research",
     "Questionnaire design and risk-scoring rules; algorithm and portfolio eligibility rules; journey and feature "
     "priorities; alerts and engagement targets; hand-off from digital to human advice."),
    ("FN-62", "Client Onboarding & Account Services", "CLA",
     ["C-15.01", "C-15.02", "C-15.03", "C-15.04", "C-15.05", "C-15.06", "C-15.07"],
     "Brings clients and their accounts onto the firm and keeps them current: the client and household master, "
     "onboarding with customer identification and KYC, the investor profile, consent and contact preferences, account "
     "opening and maintenance, beneficiaries, elections and RMD status, and enrollment in advisory programs.",
     "Head of Client Onboarding; Head of Account Services; Head of Client Data; new accounts and account maintenance "
     "teams; Privacy Officer",
     "Identity verification outcomes and exceptions; household and relationship linking rules; account approval in "
     "good order; beneficiary and election changes; program enrollment eligibility; trusted contact and authorized "
     "agent set-up."),
    ("FN-63", "Managed Account Operations", "CLA", ["C-17.01", "C-17.02", "C-17.03", "C-17.04"],
     "Manages client accounts to their assigned models at scale: model assignment, account-level targets and "
     "restrictions, drift monitoring and rebalancing, tax-loss harvesting and asset location, and the composites of "
     "the managed account programs.",
     "Head of Managed Account Operations; portfolio implementation analysts; tax management specialists; program "
     "composite owner",
     "Model assignment and restriction approval; drift thresholds and rebalance timing; harvesting and wash-sale "
     "rules; release of trade proposals; composite membership and exclusions."),
    ("FN-64", "Brokerage Trading & Execution", "BWO", ["C-23.01", "C-23.02", "C-23.03"],
     "Handles client orders in every product the platform offers: order capture and routing, executions, allocations "
     "and confirmations under Rule 10b-10, execution quality review and Rule 605 and 606 disclosure, and CAT "
     "reporting.",
     "Head of Brokerage Trading; trading desks by product (equities, options, fixed income, funds); order routing; "
     "best execution committee",
     "Routing venues and arrangements; order handling exceptions and trade corrections; regular and rigorous execution "
     "quality reviews; CAT error correction."),
    ("FN-65", "Clearing, Settlement & Client Asset Custody", "BWO",
     ["C-23.04", "C-23.05", "C-23.06", "C-23.07", "C-23.08", "C-23.09"],
     "Keeps the brokerage book of record and clears and settles client trades: client holdings, tax lots and cash at "
     "account grain, settlement through DTC and NSCC, the customer reserve and possession or control (Rule 15c3-3), "
     "ACATS transfers, margin and fully paid lending, corporate actions on client holdings and cost-basis reporting.",
     "Head of Brokerage Operations; Financial and Operations Principal; Head of Margin & Credit; cage and settlement; "
     "client asset servicing; cost basis",
     "Settlement fail and buy-in actions; reserve deposits and possession-or-control deficits; transfer rejections; "
     "margin calls and house requirements; voluntary corporate action elections; cost-basis corrections."),
    ("FN-66", "Money Movement & Cash Programs", "BWO", ["C-24.01", "C-24.02", "C-24.03", "C-24.04"],
     "Moves cash into and out of client accounts and manages the cash they hold: ACH, wire, check and debit-card "
     "activity, bank sweep programs and program banks, money market sweep and FDIC pass-through allocation, holds, "
     "returns and fraud prevention, and AML monitoring of cash movement.",
     "Head of Money Movement; Head of Cash Programs; fraud operations; BSA / AML Officer (cash movement); program bank "
     "relationship managers",
     "Hold placement and release; fraud and elder-exploitation holds; program bank allocation and capacity; sweep "
     "rates and eligibility; AML alert disposition and SAR referral."),
    ("FN-67", "Client Service & Contact Center", "CLA", ["C-21.03", "C-21.04"],
     "Services clients by phone, chat and secure message: service requests and cases, the contact center, and the "
     "statements, trade confirmations and tax documents every client receives.",
     "Head of Client Service; Head of Client Communications; contact center managers; service quality; statement and "
     "tax document production",
     "Service levels and staffing; case escalation and resolution; complaint referral; statement and tax document "
     "content, delivery preferences and corrections."),
    ("FN-68", "Retail Supervision & Conduct", "CLA",
     ["C-19.01", "C-19.02", "C-19.03", "C-19.04", "C-19.05", "C-19.06", "C-12.16"],
     "Supervises how the firm and its representatives deal with retail clients: Reg BI and Form CRS compliance, "
     "supervisory review and surveillance of recommendations and accounts, complaints and senior investor protection, "
     "communications review, representative licensing and registration, options and margin approval oversight, and the "
     "records retention schedule.",
     "Head of Retail Conduct; Head of Retail Supervision; Head of Advertising Review; Head of Registration & "
     "Licensing; Head of Records Management; registered principals",
     "Surveillance alert disposition; supervisory approvals of accounts and recommendations; complaint classification "
     "and Rule 4530 reporting; temporary holds for vulnerable investors; communication approvals; heightened "
     "supervision; retention periods."),
    ("FN-69", "Trust & Estate Services", "CLA", ["C-22.01", "C-22.02", "C-22.03"],
     "Acts as trustee and agent through the trust company: trust administration and discretionary distributions, trust "
     "accounting and fiduciary tax returns, and estate settlement.",
     "Head of Trust Services; trust officers; trust accounting; fiduciary tax; estate settlement specialists; trust "
     "committee",
     "Discretionary distribution approvals; trust account reviews; fiduciary appointment acceptance and termination; "
     "estate asset transfers; fiduciary tax elections."),
    ("FN-70", "Manager Research & Oversight", "INV", ["C-25.01", "C-25.02", "C-25.03", "C-25.04"],
     "Selects and oversees the external managers the firm hires and the third-party products it offers or recommends: "
     "manager research and selection, sub-advisory agreements and mandate guidelines, sub-adviser oversight reviews, "
     "and due diligence of third-party funds used in advice and on the platform.",
     "Head of Manager Research; manager research analysts; operational due diligence; fund board liaison",
     "Manager hire, watch and termination recommendations; sub-advisory fee and guideline terms; Section 15(c) "
     "materials on sub-advisers; the approved list of third-party products."),
    ("FN-71", "Workplace Participant Services & Rollovers", "BWO", ["C-08.07", "C-08.08", "C-08.09", "C-16.03"],
     "Runs the workplace business beyond recordkeeping: plan sponsor relationships, in-plan managed accounts and "
     "advice for participants, and the capture of rollovers when participants leave a plan, with the rollover "
     "documentation behind them.",
     "Head of Workplace Solutions; plan sponsor relationship managers; participant education and advice; rollover "
     "specialists",
     "Sponsor service and retention plans; in-plan managed account and advice enrollment; rollover outreach and "
     "eligibility; transition of separating participants into direct accounts."),
    ("FN-72", "Client Pricing & Billing", "CLA", ["C-18.01", "C-18.02", "C-18.03", "C-18.04"],
     "Prices the firm's services and bills clients: fee schedules, tiers, householding and breakpoints, advisory fee "
     "calculation and debiting under the custody rule conditions, institutional fee billing and invoicing, and fee "
     "waivers, credits and disclosures.",
     "Head of Pricing & Billing; billing operations; fee disclosure; pricing analysts",
     "Fee schedule and tier changes; householding rules; billing exceptions and adjustments; waivers and credits; fee "
     "disclosure content."),
    ("FN-73", "Advisor Workforce & Practice Management", "CLA", ["C-20.01", "C-20.02", "C-20.03"],
     "Organizes the firm's own advisors and their books: teams, branches and supervisory structure, client assignment "
     "and advisor capacity, and advisor goals and incentive compensation.",
     "Head of Advisor Workforce; Head of Sales Compensation; advisor practice managers; branch and team leaders",
     "Team and supervisory alignment; client assignment and reassignment; advisor capacity and hiring; goals and "
     "incentive plan design; crediting and payout approval."),
    ("FN-74", "Intermediary Distribution", "DIS", ["C-11.04", "C-11.08", "C-11.09", "C-11.19", "C-02.04"],
     "Sells the firm's funds, ETFs and models through third-party advisors and platforms, a secondary channel kept at "
     "reduced depth: intermediary firm and advisor profiles, coverage and pipeline, selling and platform agreements "
     "and placement, intermediary payments, and model delivery to platforms.",
     "Head of Intermediary Distribution; national account managers; intermediary sales; platform relationship managers",
     "Partner and platform priorities; agreement and payment terms; shelf and model placement; coverage of advisor "
     "firms."),
    ("FN-75", "Institutional Advisory & OCIO", "DIS", ["C-11.04", "C-11.05", "C-11.15", "C-11.16"],
     "Wins and serves institutional advisory and OCIO clients: prospects and consultant relations, RFPs and DDQs, "
     "relationship and mandate servicing after funding, and client reporting.",
     "Head of Institutional Sales; Head of Institutional Client Service; Head of Client Reporting; OCIO relationship "
     "managers; consultant relations",
     "Which searches and prospects to pursue; bid / no-bid and content approval; mandate and guideline changes; "
     "reporting packages and service levels; escalation of at-risk relationships."),
    ("FN-76", "Marketing & Acquisition", "CLA", ["C-21.01", "C-15.04"],
     "Acquires clients and assets: brand and campaign marketing, prospects and leads, offers and referral programs, "
     "and the consent and contact preferences that govern every outreach.",
     "Head of Marketing; acquisition and campaign managers; marketing operations; Privacy Officer (consent)",
     "Acquisition spend and channel mix; targeting and offers; lead routing to digital or human advice; contact "
     "frequency and suppression rules."),
    ("FN-77", "Client & Channel Analytics", "DIS", ["C-26.01", "C-07.05"],
     "Measures client assets and flows across every channel: client assets and net new assets by channel, offering and "
     "segment, and the sub-accounting and intermediary reconciliation that attributes own-fund assets held through "
     "intermediaries.",
     "Head of Client & Channel Analytics; flows and attribution analysts; intermediary data operations",
     "Channel and segment attribution rules; net new asset definitions; certification of client asset figures; "
     "resolution of reconciliation breaks with intermediaries."),
    ("FN-78", "Product & Offering Management", "CLA", ["C-10.05", "C-10.06", "C-10.07", "C-10.10", "C-10.11"],
     "Owns the offerings the firm sells: fund and ETF reference data and registration, product documents and "
     "commentary, benchmark assignment, the advice programs and service tiers, and the brokerage platform's product "
     "shelf.",
     "Head of Product; Head of Advice Products; Head of Brokerage Products; product managers",
     "Offering features and eligibility; service tier design; platform shelf additions and removals; benchmark and "
     "document changes; release of product data."),
    # --- WP0 addition (CW-200) ------------------------------------------------------------------------------------
    ("FN-79", "Business Line Leadership & Strategy", "DIS", [],
     "Leads the firm's client businesses (direct brokerage, digital and human advice, workplace, institutional advisory, "
     "the intermediary channel and trust): line strategy, targets and resourcing, read from the certified numbers (client "
     "assets, net new assets, advised assets, Firm AUM, client revenue, cost to serve) rather than mastering any. Added "
     "at WP0 (CW-200) as the successor of FN-01; it runs no capability.",
     "Chief Executive Officer; heads of business lines; Chief Client Officer; Chief Operating Officer; strategy office",
     "Line strategy and targets; capacity and investment across lines; pricing posture; offering and channel "
     "priorities; performance management of line leaders."),
]

# --- WP0 function dispositions (2026-10-15; CW-200; Wealth_Manager_Rework_Plan.md section 8.1) ---------------------
# (code, disposition, successor, decision, note). Disposition: "retire" (code kept in FUNCTIONS with no capabilities,
# flagged in RETIRED_FUNCTIONS and skipped by validators and builders; never reused), "re-cut" (code kept, renamed or
# re-described for the wealth manager), "keep" (carried unchanged or with a wording fix), "add" (new at WP0). The
# successor is the function that live products were re-pointed to (primary and supporting); the note names the other
# functions that take part of the scope. FN-60 to FN-78 were added at W0 and are confirmed here against the capability
# map (every L2 capability has at least one live function; dp_model.py and build_capability_map.py check it).
FUNCTION_DISPOSITIONS = [
    ("FN-01", "retire", "FN-79", "CW-200", "Leadership consumer of the certified numbers; channels run by FN-74 and FN-75."),
    ("FN-02", "retire", "FN-74", "CW-200", "Third-party advisor coverage at reduced depth; territories have no successor (CW-907)."),
    ("FN-03", "retire", "FN-74", "CW-200", "Inside coverage folds into intermediary coverage."),
    ("FN-04", "retire", "FN-74", "CW-200", "Partner agreements, payments, placement and model delivery; ETF capital markets to FN-23."),
    ("FN-05", "retire", "FN-75", "CW-200", "Institutional advisory, OCIO and consultant relations."),
    ("FN-06", "retire", "FN-75", "CW-200", "RFPs, DDQs and consultant databases (C-11.05)."),
    ("FN-07", "retire", "FN-74", "CW-200", "Investment-only selling through other recordkeepers; own plans FN-19, sponsors and participants FN-71."),
    ("FN-08", "retire", "FN-77", "CW-200", "Client assets and attribution FN-77; client master FN-62; advisor coverage FN-73; intermediary profiles FN-74."),
    ("FN-09", "retire", "FN-76", "CW-200", "Client acquisition and consent FN-76; digital experience FN-61."),
    ("FN-10", "retire", "FN-78", "CW-200", "Offering management FN-78; product strategy, launch and governance reviews FN-37."),
    ("FN-11", "retire", "FN-73", "CW-200", "Incentive compensation half to 03 (CW-064) under FN-73; territories and wholesale crediting have no successor (CW-907)."),
    ("FN-12", "re-cut", "FN-12", "CW-200", "Renamed Client Revenue & Profitability Finance with 10 (CW-910); runs C-26.02."),
    ("FN-13", "retire", "FN-68", "CW-200", "Retail conduct FN-68 (CW-015); product governance FN-37; firm programs FN-44."),
    ("FN-14", "retire", "FN-75", "CW-200", "Institutional servicing and reporting FN-75; institutional fee billing FN-72."),
    ("FN-15", "re-cut", "FN-15", "CW-200", "Renamed Fund Shareholder Servicing & TA Oversight; client service for every account is FN-67."),
    ("FN-16", "re-cut", "FN-16", "CW-200", "Name kept; re-described for the retail and wealth market with 11."),
    ("FN-17", "re-cut", "FN-17", "CW-200", "Renamed Third-Party Data Licensing & Entitlements, the enterprise function of 14 (C-14.09); mastering FN-49, catalog FN-50, attribution FN-77."),
    ("FN-18", "retire", None, "CW-200", "EU / UK distribution out of scope (CW-003); supporting references are dropped."),
    ("FN-19", "re-cut", "FN-19", "CW-200", "Adapted: plan recordkeeping and CIT plan participation; sponsors, in-plan advice and rollovers FN-71."),
    ("FN-20", "keep", "FN-20", "CW-200", ""),
    ("FN-21", "keep", "FN-21", "CW-200", "Fund and institutional portfolios; capital-market assumptions and models consumed by FN-63."),
    ("FN-22", "keep", "FN-22", "CW-200", "Wording: client managed accounts are FN-63's (46)."),
    ("FN-23", "keep", "FN-23", "CW-200", "Fund desk trading (25); client orders are FN-64's (48)."),
    ("FN-24", "keep", "FN-24", "CW-200", "Wording: SFDR and PAI removed (CW-934)."),
    ("FN-25", "retire", None, "CW-200", "Private markets (CW-016, CW-930); code kept with no products."),
    ("FN-26", "retire", None, "CW-200", "Private markets (CW-016, CW-930); code kept with no products."),
] + [(f"FN-{i}", "keep", f"FN-{i}", "CW-200", "") for i in range(27, 52)] \
  + [(f"FN-{i}", "keep", f"FN-{i}", "CW-200", "Added at W0 (CW-002); confirmed at WP0.") for i in range(60, 79)] \
  + [("FN-79", "add", "FN-79", "CW-200", "Successor of FN-01; runs no capability.")]
RETIRED_FUNCTIONS = {d[0]: d[3] for d in FUNCTION_DISPOSITIONS if d[1] == "retire"}      # {code: decision}
FUNCTION_SUCCESSOR = {d[0]: d[2] for d in FUNCTION_DISPOSITIONS}                         # retired -> successor (or None)


def is_retired_function(code):
    return code in RETIRED_FUNCTIONS


def live_functions():
    """FUNCTIONS without the retired ones: what validators, coverage tests and builders iterate."""
    return [f for f in FUNCTIONS if f[0] not in RETIRED_FUNCTIONS]


TIERS = {
    "Foundational": "Source-aligned, conformed data products that master or conform a core business entity or fact once, for reuse by every consumer-aligned product.",
    "Consumer-aligned": "Products shaped for a specific function's decisions and workflows, built from foundational products.",
}
TYPES = {
    "Master & Reference": "Golden records and hierarchies for a core entity, with history.",
    "Conformed Facts": "Reconciled, attributed transactional or time-series facts at a defined grain.",
    "Analytical": "Aggregated measures, scores and comparisons that support management decisions.",
    "Operational": "Data delivered into a workflow or system to drive day-to-day actions (lists, alerts, calculations).",
    "Regulatory & Control": "Evidence, registers and monitoring that demonstrate compliance or control.",
}

# Topics: how the catalog is grouped for a reader (explorer products page, catalog Topic column). A product's topic is
# its owning Data Domain's topic unless PRODUCT_TOPIC overrides it (party-role masters owned by other domains, the
# firm-wide cross-area views). Topics are presentation, like areas: they never master data.
TOPICS = [
    # Re-cut for the wealth manager's eight areas (W5 tooling, 2026-10-16): codes are kept so PRODUCT_TOPIC and the catalog
    # stay stable; T10 (private markets, retired with 30 under CW-930) now holds brokerage, clearing and money movement;
    # T19 is new. Listed in reading order, client-facing topics first.
    ("T01", "Clients, households & accounts", "Who the firm serves and deals with: clients and households, accounts, intermediaries, institutions, counterparties, vendors and the party identity behind them."),
    ("T02", "Products, offerings & instruments", "What the firm offers and holds: funds, share classes, advice programs and the platform offering, the product lifecycle, and the security and issuer master."),
    ("T19", "Advice, managed accounts & trust", "Financial plans and recommendations, accounts managed to models, rebalancing and tax management, and trust and estate services."),
    ("T03", "Advisors, marketing & channel partners", "The firm's advisors and coverage, acquisition and engagement, intermediary and institutional partners, and market intelligence."),
    ("T06", "Client service, workplace plans & institutional reporting", "Serving clients: service interactions and communications, plan recordkeeping and participants, institutional servicing and reporting."),
    ("T10", "Brokerage, clearing & money movement", "The client back office: client orders and executions, the brokerage book of record, clearing and customer protection, money movement and cash sweep."),
    ("T04", "Client assets, flows & attribution", "The certified client numbers: client assets, net new assets and fund flows, attributed to channel, advisor, campaign and plan."),
    ("T05", "Client pricing, revenue & profitability", "What clients pay and what the firm earns: fee schedules and billing, client revenue, cost to serve and profitability."),
    ("T07", "Portfolios, trading & research", "Running the money: research, portfolio decisions, manager oversight, the investment book of record, portfolio orders, settlement and collateral."),
    ("T08", "Pricing, performance & investment risk", "Measuring the money: prices and market data, official and client returns, risk measures, investment compliance."),
    ("T09", "Stewardship & sustainability", "Acting as an owner: proxy voting, engagement, ESG data and sustainability reporting."),
    ("T11", "Fund accounting, custody & transfer agency", "Operating the funds: NAV and fund financials, fund custody and asset servicing, the share register and fund orders."),
    ("T12", "Fund governance & regulatory reporting", "Fund boards, advisory agreements and the fund regulatory filings."),
    ("T13", "Compliance, conduct, legal & corporate affairs", "Retail conduct and supervision, firm compliance programs and surveillance, contracts, legal matters, entity governance, corporate communications."),
    ("T14", "Finance, treasury & tax", "The firm's books: ledger, close, planning, payables, tax, cash, net capital and funding."),
    ("T15", "People & workplace", "The workforce and where it works: employees, pay, talent, real estate and workplace services."),
    ("T16", "Enterprise risk, audit & third parties", "Risk and control across the firm: risk profile, incidents, resilience, model risk, internal audit, third-party oversight."),
    ("T17", "Reference data, governance & technology", "The foundations every product uses: shared reference data, data governance and the catalog, applications and security."),
    ("T18", "Firm-wide views", "Cross-area products that read certified numbers from their owners: reconciliations, 360 views, registries and packs."),
]
TOPIC_OF_DOMAIN = {
    "02": "T01", "15": "T01",
    "01": "T02", "36": "T02", "17": "T02",
    "45": "T19", "46": "T19", "51": "T19",
    "03": "T03", "04": "T03", "05": "T03", "11": "T03",
    "12": "T06", "13": "T06", "16": "T06",
    "48": "T10", "49": "T10", "50": "T10",
    "06": "T04",
    "10": "T05", "47": "T05",
    "07": "T05",   # retired at W4 (CW-907): kept for the products it owned (pending or retired)
    "18": "T07", "23": "T07", "24": "T07", "25": "T07", "26": "T07", "52": "T07",
    "22": "T08", "31": "T08", "32": "T08", "33": "T08",
    "34": "T09",
    "27": "T11", "28": "T11", "29": "T11",
    "30": "T11",   # retired at W4 (CW-930): its products are retired (RETIRED_PRODUCTS); kept so they still resolve a topic
    "35": "T12",
    "08": "T13", "38": "T13", "39": "T13", "42": "T13",
    "19": "T14", "43": "T14",
    "20": "T15", "44": "T15",
    "37": "T16", "40": "T16", "14": "T16",
    "09": "T17", "21": "T17", "41": "T17",
}
PRODUCT_TOPIC = {
    "DP-115": "T01", "DP-210": "T01",                    # party-role masters owned by 25 and 40
    "DP-241": "T18", "DP-242": "T18", "DP-243": "T18", "DP-244": "T18",
    "DP-245": "T18", "DP-246": "T18", "DP-247": "T18", "DP-248": "T18",
}


def topic_of(product):
    """Topic code of a PRODUCTS tuple: the override, else the owning Data Domain's topic."""
    return PRODUCT_TOPIC.get(product[0]) or TOPIC_OF_DOMAIN[product[4]]


# Specified products. (id, name, tier, type, owning Data Domain, accountable product owner (role),
#                      primary function, supporting functions)
PRODUCTS = [
    # --- Foundational -----------------------------------------------------------------------------------------------
    ("DP-001", "Distributor Hierarchy", "Foundational", "Master & Reference", "02", "Head of Distribution Data Management",
     "FN-74", ["FN-73", "FN-12", "FN-17"]),
    ("DP-002", "Financial Professional Profile", "Foundational", "Master & Reference", "02", "CRM Product Owner",
     "FN-74", ["FN-76", "FN-68"]),
    ("DP-003", "Institutional, Consultant & Plan Relationships", "Foundational", "Master & Reference", "02", "Head of Institutional Client Data",
     "FN-75", ["FN-74"]),
    ("DP-004", "Product & Share Class Distribution Reference", "Foundational", "Master & Reference", "01", "Head of Product Data",
     "FN-78", ["FN-74", "FN-75", "FN-68"]),
    ("DP-005", "Distribution Agreements & Shelf Status", "Foundational", "Master & Reference", "05", "Head of Strategic Partnerships Operations",
     "FN-74", ["FN-12", "FN-68", "FN-78"]),
    ("DP-006", "Attributed Transactions", "Foundational", "Conformed Facts", "06", "Head of Distribution Data Management",
     "FN-77", ["FN-73", "FN-12", "FN-17"]),
    ("DP-007", "Attributed Positions & AUM", "Foundational", "Conformed Facts", "06", "Head of Distribution Data Management",
     "FN-77", ["FN-74", "FN-12", "FN-75"]),
    ("DP-008", "Certified Flows & AUM", "Foundational", "Conformed Facts", "06", "Head of Distribution Analytics",   # W4: successor at WP0 is Client Assets & Net New Assets (CW-142)
     "FN-77", ["FN-78", "FN-12", "FN-16"]),
    ("DP-009", "Sales Organization & Coverage", "Foundational", "Master & Reference", "03", "Head of Sales Operations",   # W4: owner 07 -> 03 (CW-080; 07 retired, CW-907)
     "FN-73", ["FN-77", "FN-74", "FN-75"]),
    ("DP-010", "Sales Activities & Interactions", "Foundational", "Conformed Facts", "03", "CRM Product Owner",
     "FN-73", ["FN-74", "FN-75", "FN-68"]),
    ("DP-011", "Marketing Engagement", "Foundational", "Conformed Facts", "04", "Head of Marketing Operations",
     "FN-76", ["FN-74", "FN-77"]),
    ("DP-012", "Distribution Revenue", "Foundational", "Conformed Facts", "10", "Head of Distribution Finance",
     "FN-12", ["FN-79", "FN-78", "FN-74"]),
    ("DP-013", "Enterprise Reference & Calendars", "Foundational", "Master & Reference", "09", "Enterprise Reference Data Lead",
     "FN-49", ["FN-17", "FN-77", "FN-12"]),   # primary function FN-17 -> FN-49 Enterprise Data Management (CD-304)
    ("DP-014", "Industry Flows & Peer Universe", "Foundational", "Conformed Facts", "11", "Head of Market Intelligence",
     "FN-16", ["FN-78", "FN-79"]),
    # --- Consumer-aligned -------------------------------------------------------------------------------------------
    ("DP-015", "Distribution Executive Dashboard", "Consumer-aligned", "Analytical", "06", "Head of Distribution Strategy & Analytics",
     "FN-01", ["FN-12", "FN-10"]),
    ("DP-016", "Wholesaler Territory Scorecard", "Consumer-aligned", "Analytical", "07", "Head of Sales Operations",
     "FN-02", ["FN-01", "FN-08", "FN-11", "FN-03"]),
    ("DP-017", "Advisor 360", "Consumer-aligned", "Operational", "03", "CRM Product Owner",
     "FN-02", ["FN-03", "FN-04", "FN-09"]),
    ("DP-092", "Institutional Client 360", "Consumer-aligned", "Operational", "03", "CRM Product Owner",
     "FN-05", ["FN-14", "FN-06", "FN-13"]),
    ("DP-018", "Advisor Segmentation & Prioritization", "Consumer-aligned", "Analytical", "03", "Head of Distribution Analytics",
     "FN-08", ["FN-02", "FN-03", "FN-09"]),
    ("DP-019", "Sales Pipeline & Win/Loss", "Consumer-aligned", "Analytical", "03", "Head of Sales Operations",
     "FN-05", ["FN-01", "FN-04", "FN-08", "FN-07"]),
    ("DP-020", "National Account Partner Scorecard", "Consumer-aligned", "Analytical", "05", "Head of Strategic Partnerships",
     "FN-04", ["FN-12", "FN-01"]),
    ("DP-021", "Platform Shelf & Placement Coverage", "Consumer-aligned", "Analytical", "05", "Head of Strategic Partnerships",
     "FN-04", ["FN-10", "FN-02"]),
    ("DP-022", "Consultant Relations & Manager Search", "Consumer-aligned", "Operational", "03", "Head of Consultant Relations",
     "FN-05", ["FN-06", "FN-16"]),
    ("DP-023", "RFP & DDQ Performance", "Consumer-aligned", "Analytical", "03", "Head of RFP & Proposals",
     "FN-06", ["FN-05", "FN-13"]),
    ("DP-024", "DCIO Plan & Recordkeeper Insight", "Consumer-aligned", "Analytical", "06", "Head of DCIO",
     "FN-07", ["FN-04", "FN-08"]),
    ("DP-025", "Campaign Performance & Attribution", "Consumer-aligned", "Analytical", "04", "Head of Marketing Operations",
     "FN-09", ["FN-01", "FN-08"]),
    ("DP-026", "Content Performance", "Consumer-aligned", "Analytical", "04", "Head of Content Strategy",
     "FN-09", ["FN-10", "FN-06"]),
    ("DP-027", "Lead Funnel & Sales Hand-off", "Consumer-aligned", "Operational", "04", "Head of Marketing Operations",
     "FN-09", ["FN-03", "FN-02"]),
    ("DP-028", "Marketing Audience & Consent", "Consumer-aligned", "Operational", "04", "Head of Marketing Operations",
     "FN-09", ["FN-13", "FN-18"]),
    ("DP-029", "Product Sales Performance & Distribution Footprint", "Consumer-aligned", "Analytical", "06", "Head of Product Strategy",
     "FN-10", ["FN-01", "FN-04"]),
    ("DP-030", "Competitive Positioning & Peer Benchmarks", "Consumer-aligned", "Analytical", "11", "Head of Market Intelligence",
     "FN-10", ["FN-16", "FN-05", "FN-06"]),
    ("DP-031", "Market Sizing & Share", "Consumer-aligned", "Analytical", "11", "Head of Market Intelligence",
     "FN-16", ["FN-01", "FN-10", "FN-18"]),
    ("DP-032", "Sales Crediting & Goal Attainment", "Consumer-aligned", "Operational", "07", "Head of Sales Compensation",
     "FN-11", ["FN-02", "FN-03", "FN-08"]),
    ("DP-033", "Incentive Compensation Payouts", "Consumer-aligned", "Operational", "07", "Head of Sales Compensation",
     "FN-11", ["FN-12"]),
    ("DP-034", "Intermediary Payments & Revenue-Sharing Accruals", "Consumer-aligned", "Operational", "10", "Head of Distribution Finance",
     "FN-12", ["FN-04", "FN-13", "FN-18"]),
    ("DP-035", "Channel, Partner & Product Profitability", "Consumer-aligned", "Analytical", "10", "Head of Distribution Finance",
     "FN-12", ["FN-01", "FN-04", "FN-10"]),
    ("DP-036", "Marketing Communications Review & Filing", "Consumer-aligned", "Regulatory & Control", "08", "Head of Marketing Compliance",
     "FN-13", ["FN-09"]),
    ("DP-037", "Know-Your-Distributor Oversight", "Consumer-aligned", "Regulatory & Control", "08", "Head of Distribution Compliance",
     "FN-13", ["FN-04", "FN-18"]),
    ("DP-038", "Gifts, Entertainment & Non-Cash Compensation", "Consumer-aligned", "Regulatory & Control", "08", "Head of Distribution Compliance",
     "FN-13", ["FN-02", "FN-12"]),
    ("DP-039", "Sales Personnel Registration & Licensing", "Consumer-aligned", "Regulatory & Control", "08", "Head of Registrations & Licensing",
     "FN-13", ["FN-11", "FN-08"]),
    ("DP-040", "Product Governance & Target Market Feedback", "Consumer-aligned", "Regulatory & Control", "08", "Head of Product Governance",
     "FN-13", ["FN-10", "FN-18"]),
    ("DP-041", "Cross-Border Distribution Eligibility", "Consumer-aligned", "Regulatory & Control", "08", "Head of Cross-Border Registration",
     "FN-18", ["FN-13", "FN-02", "FN-09"]),
    ("DP-042", "Institutional Client Health & Service", "Consumer-aligned", "Analytical", "12", "Head of Institutional Client Service",
     "FN-14", ["FN-05", "FN-01"]),
    ("DP-043", "Shareholder Servicing & TA Oversight", "Consumer-aligned", "Regulatory & Control", "13", "Head of TA Oversight",
     "FN-15", ["FN-13"]),
    # WP1 re-point (CW-240, lead WP0 ruling): DP-044 is re-scoped in place with DP-519's row (DP-519 merged here).
    ("DP-044", "Third-Party Data Entitlements, Usage & Cost", "Consumer-aligned", "Regulatory & Control", "14", "Head of Market Data & Licensing",
     "FN-17", ["FN-50", "FN-38", "FN-46"]),
    ("DP-045", "Distribution Data Quality & Attribution Health", "Consumer-aligned", "Regulatory & Control", "06", "Head of Distribution Data Management",
     "FN-17", ["FN-08", "FN-11"]),
]

# Wave 2: identified as backlog in v0.1 and since specified at attribute level. Kept here for the original rationale,
# priority and dependency; each becomes a PRODUCTS entry below with its accountable product owner.
# (id, name, tier, type, owning Data Domain, primary function, supporting functions, definition,
#  main input Data Domains, value / rationale, priority, taxonomy gap or dependency)
WAVE_2 = [
    ("DP-046", "Next-Best-Action Recommendations", "Consumer-aligned", "Operational", "03", "FN-03", ["FN-02", "FN-09"],
     "Ranked, explainable recommendations of the next advisor, topic and channel for each salesperson, combining flows, holdings, engagement signals and coverage.",
     ["02", "03", "04", "06", "07"], "Raises sales productivity by turning signals into prioritized actions inside the CRM.", "High",
     "Needs DP-017 and DP-018 in production; model features and outcomes need a home (model registry not in taxonomy)."),
    ("DP-047", "Advisor Redemption Risk", "Consumer-aligned", "Analytical", "06", "FN-02", ["FN-03", "FN-08"],
     "Early-warning score for advisors and teams at risk of large redemptions, based on flow trends, performance, platform changes and engagement decline.",
     ["02", "06", "03", "11"], "Protects AUM by prompting retention calls before assets leave.", "High",
     "Scores and model outputs are not yet modeled in the taxonomy."),
    ("DP-048", "Advisor Movement & Breakaway Alerts", "Consumer-aligned", "Operational", "02", "FN-02", ["FN-04", "FN-08"],
     "Alerts when advisors or teams change firm, channel or affiliation (e.g. wirehouse to RIA), with assets at risk and new-firm shelf status.",
     ["02", "05", "06", "14"], "Retains assets through transitions and opens new-firm opportunities.", "Medium",
     "Depends on licensed advisor data feeds (14) and CRD / FCA register history in 02."),
    ("DP-049", "Wallet Share Estimates", "Consumer-aligned", "Analytical", "11", "FN-08", ["FN-02", "FN-04"],
     "Estimated share of an advisor's, office's or firm's product-category assets held in the firm's products, using licensed industry holdings data.",
     ["02", "06", "11", "14"], "Sizes white space and sets realistic goals.", "Medium",
     "Requires permitted-use clearance for vendor holdings data."),
    ("DP-050", "Model Portfolio & SMA Placement and Flows", "Consumer-aligned", "Analytical", "05", "FN-04", ["FN-10", "FN-02"],
     "Model and SMA/UMA sponsor placements of the firm's strategies, with model-driven flows and assets by sponsor and model.",
     ["01", "05", "06"], "Model delivery is a fast-growing channel with different economics and data.", "High",
     "Model-driven flow identification depends on sponsor-reported data."),
    ("DP-051", "Event & Webinar ROI", "Consumer-aligned", "Analytical", "04", "FN-09", ["FN-12", "FN-13"],
     "Cost, attendance, CE credit, engagement and subsequent flows for each event, conference and webinar, including partner-sponsored conferences.",
     ["04", "06", "10", "08"], "Justifies event and conference sponsorship spend.", "Medium", ""),
    ("DP-052", "Digital Intent Signals", "Consumer-aligned", "Operational", "04", "FN-03", ["FN-09"],
     "Identity-resolved web, portal and content behavior aggregated into topic and product intent signals for known advisors.",
     ["04", "02"], "Feeds inside sales and next-best-action with timely buying signals.", "Medium",
     "Consent and identity resolution rules must be confirmed per jurisdiction."),
    ("DP-053", "Unified Engagement Timeline", "Consumer-aligned", "Operational", "03", "FN-02", ["FN-03", "FN-09", "FN-14"],
     "One chronological view of every sales, marketing, service and event touchpoint with a party, across CRM, marketing automation and servicing systems.",
     ["03", "04", "12", "13"], "Gives every client-facing role the same context.", "Medium", ""),
    ("DP-054", "Territory Alignment Scenarios", "Consumer-aligned", "Analytical", "07", "FN-11", ["FN-08", "FN-01"],
     "What-if modeling of territory realignments: opportunity, workload, travel and compensation impact of alternative alignments.",
     ["07", "02", "06", "09"], "Makes realignments data-driven and fair.", "Medium",
     "Scenario versions of territory alignments are not modeled."),
    ("DP-055", "Sales Flow Forecast", "Consumer-aligned", "Analytical", "06", "FN-01", ["FN-12", "FN-10"],
     "Forward estimate of gross sales, redemptions and net flows by channel and product, combining pipeline, run-rates and seasonality.",
     ["06", "03", "11"], "Supports planning, capacity and revenue forecasting.", "Medium",
     "Forecast versions and assumptions are not modeled."),
    ("DP-056", "Distribution Budget vs Actual", "Consumer-aligned", "Analytical", "10", "FN-12", ["FN-01"],
     "Distribution expense (headcount, T&E, events, sponsorships, partner payments) against budget by cost center, channel and team.",
     ["10", "09", "05"], "Controls distribution cost.", "Medium", ""),
    ("DP-057", "Wholesaler Productivity & Expense", "Consumer-aligned", "Analytical", "07", "FN-01", ["FN-11", "FN-12"],
     "Activity, T&E spend and results per wholesaler, normalized for territory opportunity.",
     ["03", "07", "10", "06"], "Identifies coaching needs and sales capacity gaps.", "Low", ""),
    ("DP-058", "Product Launch Readiness & Tracking", "Consumer-aligned", "Operational", "01", "FN-10", ["FN-04", "FN-09", "FN-13"],
     "Status of each new product or share class across identifiers, registrations, platform onboarding, shelf approvals, materials and first flows.",
     ["01", "05", "08", "04", "06"], "Shortens time from launch to first sale.", "High", ""),
    ("DP-059", "Pricing & Fee Waiver Analytics", "Consumer-aligned", "Analytical", "01", "FN-10", ["FN-12", "FN-16"],
     "Share class fees, waivers and expense caps against peers and against flows, with revenue impact of pricing changes.",
     ["01", "10", "11"], "Supports pricing decisions and board 15(c) materials.", "Medium", ""),
    ("DP-060", "Share Class Eligibility & Breakpoint Monitoring", "Consumer-aligned", "Regulatory & Control", "08", "FN-13", ["FN-15"],
     "Surveillance of share class suitability signals: missed breakpoints, rights of accumulation, conversion eligibility and C-share aging.",
     ["06", "01", "02", "15", "08"], "Reduces sales-practice risk in intermediated channels.", "Medium", ""),
    ("DP-061", "Complaints & Conduct Analytics", "Consumer-aligned", "Regulatory & Control", "08", "FN-13", ["FN-15", "FN-14"],
     "Complaints, root causes, outcomes and conduct indicators by product, channel and distributor, including Consumer Duty outcome monitoring.",
     ["08", "13", "12", "01"], "Evidences good outcomes and finds systemic issues.", "Medium", ""),
    ("DP-062", "Marketing Rule Performance Substantiation", "Consumer-aligned", "Regulatory & Control", "08", "FN-13", ["FN-09"],
     "Evidence pack for each performance presentation in marketing: source, calculation, net-of-fee and time-period compliance, hypothetical performance controls.",
     ["08", "04", "01"], "Meets SEC Marketing Rule substantiation and record-keeping requirements.", "Medium", ""),
    ("DP-063", "Revenue Sharing & Inducement Disclosure", "Consumer-aligned", "Regulatory & Control", "05", "FN-13", ["FN-04", "FN-18"],
     "Payments to each intermediary, in the form needed for Reg BI / prospectus revenue-sharing disclosures and MiFID II / COBS inducement and quality-enhancement evidence.",
     ["05", "10", "08"], "Ensures disclosures match actual payments.", "High", ""),
    ("DP-064", "FinDatEx EMT / EPT / EET Distributor Feed", "Consumer-aligned", "Operational", "01", "FN-18", ["FN-13", "FN-04"],
     "Validated European MiFID, PRIIPs and ESG template data per share class for distribution to EU/UK distributors and data platforms.",
     ["01", "08", "14"], "Required for EU/UK distributors to sell and report costs and sustainability preferences.", "High",
     "EET sustainability fields are only partly modeled in 01."),
    ("DP-065", "Inducement & Retrocession Monitoring (EU/UK)", "Consumer-aligned", "Regulatory & Control", "08", "FN-18", ["FN-12"],
     "Retrocessions and trail commissions paid to EU/UK distributors, by permitted basis (quality enhancement, non-independent advice) and client category.",
     ["05", "10", "08", "02"], "Controls inducement risk under MiFID II and UK COBS 6.1A.", "Medium", ""),
    ("DP-066", "Retirement Plan Prospecting", "Consumer-aligned", "Analytical", "02", "FN-07", ["FN-08"],
     "DC plans with their assets, recordkeeper, advisor and current fund lineup from Form 5500 and vendor data, scored for DCIO opportunity.",
     ["02", "11", "14"], "Targets DCIO effort at plans and advisors likely to add funds.", "Medium", ""),
    ("DP-067", "Institutional Fee Billing & Revenue Leakage", "Consumer-aligned", "Regulatory & Control", "12", "FN-14", ["FN-12"],
     "Billed versus contracted institutional fees, with exceptions for missing breakpoints, late billing and unbilled mandates.",
     ["12", "10", "01"], "Recovers lost revenue and avoids overbilling.", "Medium", ""),
    ("DP-068", "Client Reporting Delivery & SLA", "Consumer-aligned", "Regulatory & Control", "12", "FN-14", ["FN-05"],
     "Timeliness, accuracy and exceptions of institutional client reports against each client's requirements and SLAs.",
     ["12"], "Keeps institutional service commitments visible.", "Low", ""),
    ("DP-069", "Shareholder Communications Delivery & Cost", "Consumer-aligned", "Analytical", "13", "FN-15", ["FN-12"],
     "Regulatory shareholder mailings by type, delivery method (print, e-delivery, householding), suppression and cost.",
     ["13", "10", "15"], "Reduces print and postage cost and evidences delivery.", "Low", ""),
    ("DP-070", "Escheatment & Lost Shareholder Monitoring", "Consumer-aligned", "Regulatory & Control", "13", "FN-15", ["FN-13"],
     "Accounts at risk of escheatment, outreach attempts and state filings, with lost-shareholder search results.",
     ["13", "15", "02"], "Meets unclaimed-property and SEC lost-securityholder obligations.", "Low", ""),
    ("DP-071", "Fund Proxy Solicitation Tracking", "Consumer-aligned", "Operational", "13", "FN-15", ["FN-02", "FN-04"],
     "Vote status of fund shareholder meetings by intermediary and advisor, to direct solicitation effort to meet quorum.",
     ["13", "06", "15"], "Reduces cost and risk of adjourned shareholder meetings.", "Low", ""),
    ("DP-072", "Index Licensing Fees", "Consumer-aligned", "Regulatory & Control", "14", "FN-17", ["FN-10", "FN-12"],
     "Index licenses used by products and in marketing, with fee basis, AUM-linked fees and permitted uses.",
     ["14", "01", "10"], "Controls index fees and avoids unlicensed use.", "Low", ""),
    ("DP-073", "Data Vendor Risk & Renewals", "Consumer-aligned", "Regulatory & Control", "14", "FN-17", ["FN-12"],
     "Data vendor contracts, renewal dates, risk assessments and usage, to support renewal decisions.",
     ["14", "10"], "Prevents surprise renewals and concentration risk.", "Low", ""),
    ("DP-074", "Intercompany Distribution Cost Allocation", "Consumer-aligned", "Analytical", "10", "FN-12", ["FN-18"],
     "Distribution cost and revenue allocated between the firm's legal entities and affiliates under transfer-pricing arrangements.",
     ["10", "09"], "Supports transfer pricing and entity-level profitability.", "Low", ""),
    ("DP-075", "Distribution Metadata & Lineage Catalog", "Foundational", "Master & Reference", "09", "FN-50", ["FN-77"],
     "Catalog of every data product, its inputs, owners, certifications and lineage to source systems, kept in step with this taxonomy.",
     ["09", "14"], "Makes data products discoverable and trusted.", "Medium",
     "Source-system mapping is still a Phase D task."),
    ("DP-076", "End-Investor Look-Through Insights", "Consumer-aligned", "Analytical", "06", "FN-10", ["FN-13", "FN-18"],
     "Aggregated, privacy-safe profile of end investors behind intermediary accounts (investor type, region, holding period) where look-through data is available.",
     ["06", "02", "15", "13"], "Informs target-market reviews and product design.", "Low",
     "Look-through availability varies widely by channel; privacy review needed."),
]

WAVE_2_OWNERS = {
    "DP-046": "Head of Distribution Analytics", "DP-047": "Head of Distribution Analytics", "DP-048": "CRM Product Owner",
    "DP-049": "Head of Market Intelligence", "DP-050": "Head of Strategic Partnerships", "DP-051": "Head of Marketing Operations",
    "DP-052": "Head of Digital Marketing", "DP-053": "CRM Product Owner", "DP-054": "Head of Sales Operations",
    "DP-055": "Head of Distribution Analytics", "DP-056": "Head of Distribution Finance", "DP-057": "Head of Sales Operations",
    "DP-058": "Head of Product Management", "DP-059": "Head of Product Strategy", "DP-060": "Head of Distribution Compliance",
    "DP-061": "Head of Complaints & Conduct", "DP-062": "Head of Marketing Compliance", "DP-063": "Head of Distribution Compliance",
    "DP-064": "Head of Product Data", "DP-065": "Head of EU/UK Distribution Compliance", "DP-066": "Head of DCIO",
    "DP-067": "Head of Institutional Operations", "DP-068": "Head of Client Reporting", "DP-069": "Head of Shareholder Services",
    "DP-070": "Head of Shareholder Services", "DP-071": "Head of TA Oversight", "DP-072": "Head of Market Data & Licensing",
    "DP-073": "Head of Market Data & Licensing", "DP-074": "Head of Distribution Finance",
    "DP-075": "Chief Data Officer (Distribution)", "DP-076": "Head of Distribution Analytics",
}
PRODUCTS += [(w[0], w[1], w[2], w[3], w[4], WAVE_2_OWNERS[w[0]], w[5], w[6]) for w in WAVE_2]

# Wave 3: products identified from taxonomy objects that no Wave 1 or 2 product used (coverage review, 2026-10-01).
# Same tuple shape as WAVE_2.
WAVE_3 = [
    ("DP-077", "Client Restrictions & KYC Status", "Consumer-aligned", "Regulatory & Control", "02", "FN-13", ["FN-05", "FN-09", "FN-03", "FN-14"],
     "Current KYC / AML status, beneficial ownership, tax classification and every active client, account and restricted-client restriction, as one eligibility list of parties and accounts the firm must not market or sell to, or may serve only under conditions.",
     ["02", "15", "08"], "Gives marketing, sales and next-best-action products one exclusion list, and evidences KYC currency for institutional clients.", "High",
     "Should feed the eligibility checks in DP-027, DP-028 and DP-046."),
    ("DP-078", "Communications Surveillance & Recordkeeping", "Consumer-aligned", "Regulatory & Control", "08", "FN-13", ["FN-02", "FN-09"],
     "Capture coverage of business communications by approved channel and employee, surveillance alerts and their clearance, and registered employee social media accounts, as evidence of books-and-records and supervision obligations.",
     ["08", "09", "03"], "Off-channel communications are a leading SEC and FINRA enforcement theme; this shows capture gaps and alert backlogs.", "High", ""),
    ("DP-079", "Fund Dealing & Operational Reference for Intermediaries", "Consumer-aligned", "Operational", "01", "FN-15", ["FN-04", "FN-18"],
     "The operational terms intermediaries need to trade and service each share class: dealing and settlement terms, cut-offs and dealing calendars, valuation, exchange listings, income distribution, currency hedging and tax status, with partner trading set-up.",
     ["01", "09", "05"], "Platforms and dealers ask for this data for every launch and change; one feed avoids conflicting copies.", "High", ""),
    ("DP-080", "Data Subject Rights & Retention", "Consumer-aligned", "Regulatory & Control", "02", "FN-17", ["FN-13", "FN-09"],
     "Data subject requests (access, erasure, rectification, objection) with deadlines and outcomes, and retention and erasure schedules for parties, as evidence that privacy rights are honored across the products that hold personal data.",
     ["02", "04"], "Demonstrates GDPR, UK GDPR and CCPA compliance for advisor and investor data.", "High", ""),
    ("DP-081", "Partner Contract Obligations & SLAs", "Consumer-aligned", "Regulatory & Control", "05", "FN-04", ["FN-15", "FN-13"],
     "Obligations each distribution agreement places on the firm and the partner, their service levels and measured performance, partner attestations, amendments and executed documents.",
     ["05"], "Shows whether partners and the firm meet contractual commitments, and which attestations are overdue.", "Medium", ""),
    ("DP-082", "Sales Compensation Governance & Controls", "Consumer-aligned", "Regulatory & Control", "07", "FN-11", ["FN-13", "FN-12"],
     "Approvals of compensation plans, crediting rules and territory models, remuneration conflict-of-interest assessments, compensation controls and the change audit trail for compensation data.",
     ["07", "09"], "Evidences control over incentive pay (MiFID II remuneration, FCA SYSC 19F) and closes the approval gap noted in DP-033.", "Medium", ""),
    # WP1 re-point (CW-260): functions re-pointed to the CW-260 proposal (FN-13 and FN-18 retired at WP0, CW-200).
    ("DP-083", "Regulatory Obligations, Attestations & Horizon", "Consumer-aligned", "Regulatory & Control", "38", "FN-44", ["FN-68", "FN-36", "FN-43"],
     "Register of regulatory obligations by legal entity, periodic attestations against them, and upcoming regulatory initiatives mapped to the obligations and products they affect.",
     ["08", "09", "11"], "Connects rule changes to owners and evidence of compliance.", "Medium", ""),
    ("DP-084", "Frequent Trading & Market Timing Surveillance", "Consumer-aligned", "Regulatory & Control", "08", "FN-13", ["FN-15"],
     "Accounts and omnibus positions showing round-trip or excessive trading against fund policy, with cases, intermediary information requests and restrictions applied.",
     ["08", "06", "15"], "Supports Rule 22c-2 and fund excessive-trading policies.", "Medium", ""),
    ("DP-085", "Shareholder Account Maintenance & Fraud Monitoring", "Consumer-aligned", "Regulatory & Control", "13", "FN-15", ["FN-13"],
     "Account maintenance changes, ownership transfers, standing instructions and their control evidence, with fraud-pattern flags such as an address or bank change followed by a redemption.",
     ["13", "15", "06"], "Reduces account-takeover losses and evidences servicing controls.", "Medium", ""),
    ("DP-086", "Mandate Onboarding & Cash Flow Readiness", "Consumer-aligned", "Operational", "12", "FN-14", ["FN-05"],
     "Set-up status of each new or changing institutional mandate (onboarding case, custody accounts, settlement instructions, investment restrictions, client data feeds) and the timeliness of client cash flow notifications.",
     ["12", "02", "01"], "Shortens time from win to funding and avoids missed cash flows.", "Medium", ""),
    ("DP-087", "Digital Access Gating & Self-Certification Evidence", "Consumer-aligned", "Regulatory & Control", "04", "FN-09", ["FN-13", "FN-18"],
     "Digital properties, their audience and jurisdiction access gates, web forms and visitor self-certification records, as evidence that restricted content was shown only to eligible audiences.",
     ["04", "08"], "Evidences professional-investor and jurisdiction gating required for EU/UK marketing.", "Medium", ""),
    ("DP-088", "Competitor & Market Watch", "Consumer-aligned", "Analytical", "11", "FN-16", ["FN-05", "FN-10", "FN-01"],
     "Competitor strategic events, personnel moves and distribution footprint, market trends, research reports, news and win/loss analysis, as one intelligence feed.",
     ["11"], "Keeps sales and product teams current on competitor moves beyond performance and peer data.", "Medium", ""),
    ("DP-089", "Capitalized Contract Costs", "Consumer-aligned", "Regulatory & Control", "10", "FN-12", ["FN-11"],
     "Capitalization assessments and capitalized contract cost assets (deferred sales commissions and similar incremental costs) with amortization and impairment, under ASC 340-40 / IFRS 15.",
     ["10", "07", "05"], "Supports the accounting for capitalized distribution costs.", "Medium", ""),
    ("DP-090", "Social Media & Brand Performance", "Consumer-aligned", "Analytical", "04", "FN-09", ["FN-13"],
     "Reach, engagement and sentiment of corporate social media accounts and posts, and third-party mentions, by brand, marketing theme and messaging pillar.",
     ["04"], "Shows which themes and messages resonate.", "Low", ""),
    ("DP-091", "Shareholder Tax & Cost Basis Reporting", "Consumer-aligned", "Regulatory & Control", "13", "FN-15", ["FN-18"],
     "Cost basis method elections, trade confirmations and tax documents for US and UK/EU shareholders, with share class tax reporting status and delivery timeliness.",
     ["13", "15", "01", "06"], "Evidences timely, accurate tax reporting to shareholders.", "Low", ""),
]
WAVE_3_OWNERS = {
    "DP-077": "Head of Client Onboarding & KYC", "DP-078": "Head of Compliance Surveillance", "DP-079": "Head of Product Data",
    "DP-080": "Data Protection Officer", "DP-081": "Head of Strategic Partnerships Operations",
    "DP-082": "Head of Sales Compensation", "DP-083": "Head of Compliance Risk & Controls",
    "DP-084": "Head of Distribution Compliance", "DP-085": "Head of Shareholder Services",
    "DP-086": "Head of Institutional Operations", "DP-087": "Head of Digital Marketing", "DP-088": "Head of Market Intelligence",
    "DP-089": "Head of Distribution Finance", "DP-090": "Head of Digital Marketing", "DP-091": "Head of Shareholder Services",
}
PRODUCTS += [(w[0], w[1], w[2], w[3], w[4], WAVE_3_OWNERS[w[0]], w[5], w[6]) for w in WAVE_3]

# Wave 4 (2026-10-05): Account and Retirement Plan Administration. Products for the two Data Domains added in October 2026:
# 15 Account (the conformed account record) and 16 Retirement Plan Administration (plans the firm recordkeeps).
# Same tuple shape as WAVE_2.
WAVE_4 = [
    ("DP-093", "Account Master", "Foundational", "Master & Reference", "15", "FN-15", ["FN-71", "FN-75", "FN-19"],
     "The conformed account record: every account with its identifiers, registration, hierarchy (omnibus / sub-account, plan / participant), party roles, standing and bank instructions, tax status, restrictions and lifecycle, conformed once so that positions, transactions, servicing and plan administration refer to the same account.",
     ["15", "02", "01", "05"], "Replaces the account copies carried by DP-003 and DP-007 with one governed master (resolves GAP-02-010) and gives every servicing, compliance and plan product the same Account ID, registration and status.", "High",
     "DP-003 and DP-007 take the Account record from this product; the retirement plan reference on participant accounts resolves in DP-003 and DP-094."),
    ("DP-094", "Recordkept Plan & Participant Core", "Foundational", "Master & Reference", "16", "FN-19", ["FN-71", "FN-15"],
     "Plan documents and provisions, fiduciary and service roles, the investment menu, participant membership, deferral and investment elections and vesting status for every plan the firm recordkeeps, conformed per plan and participant.",
     ["16", "02", "15", "01"], "One plan and participant master for recordkeeping operations, compliance and DCIO insight, keyed to the conformed Retirement Plan (DP-003) and Account (DP-093).", "High",
     "Participant data is personal; depends on DP-093 for participant accounts and on DP-003 for the plan identity (Sponsor EIN + Plan Number)."),
    # WP1 re-point (CW-233): supporting functions per the BWO re-scope (CW-233).
    ("DP-095", "Plan Contribution, Loan & Distribution Operations", "Consumer-aligned", "Operational", "16", "FN-19", ["FN-71", "FN-66"],
     "Daily operational view of payroll batches and contribution records, annual limit tracking, late deposits, participant loans and repayments, distribution requests and required minimum distributions, with good-order and aging flags for plan services operations.",
     ["16", "15", "06"], "Puts the day's exceptions (batches not in good order, late deposits, loans near default, aging distributions, unsatisfied RMDs) in front of the operations team with the posting transaction behind each record.", "High",
     "Posting, disbursement and settlement transactions must resolve to DP-006; limit amounts depend on the plan year end held in DP-094."),
    # WP1 re-point (CW-233): supporting functions per the BWO re-scope (FN-13 retired at WP0, CW-200).
    ("DP-096", "Plan Compliance Testing & Filing Status", "Consumer-aligned", "Regulatory & Control", "16", "FN-19", ["FN-44", "FN-71"],
     "Nondiscrimination test results and corrections, plan correction cases, Form 5500 and Form 8955-SSA filing status, plan audits, required participant notices and plan terminations, with deadlines and overdue flags per plan and plan year.",
     ["16", "02"], "Evidences that each recordkept plan is tested, corrected, filed, audited and noticed on time, and shows the compliance team what is overdue.", "High",
     "Filing and notice due dates depend on Plan Year End in the plan document (DP-094); correction deadlines are entered by the compliance team."),
]
WAVE_4_OWNERS = {
    "DP-093": "Head of Account Data", "DP-094": "Head of Retirement Plan Services",   # WP1: DP-093 owner as in WP0_ROWS
    "DP-095": "Head of Retirement Plan Services", "DP-096": "Head of Retirement Plan Compliance",
}
PRODUCTS += [(w[0], w[1], w[2], w[3], w[4], WAVE_4_OWNERS[w[0]], w[5], w[6]) for w in WAVE_4]

# --- Wave E1 (2026-10-08): the 27 enterprise foundational products of the data products expansion, registered from the
# accepted Wave E0 briefs (consolidation/proposals_dp_*.py, CD-362). Same tuple shape as PRODUCTS. A product stays
# "in progress" (register entry, no specification yet) until its specs_e1_*.py module validates; IN_PROGRESS lists the
# waves whose products may lack a specification without failing the build.
WAVE_E1 = [
    ("DP-097", "Security Master & Identifiers", "Foundational", "Master & Reference", "17", "Head of Enterprise Data Management",
     "FN-49", ["FN-27", "FN-28", "FN-23", "FN-29", "FN-30", "FN-32", "FN-33", "FN-34", "FN-21", "FN-36"]),
    ("DP-098", "Issuer Hierarchy, Classifications & Ratings", "Foundational", "Master & Reference", "17", "Head of Enterprise Data Management",
     "FN-49", ["FN-20", "FN-21", "FN-30", "FN-32", "FN-36", "FN-24", "FN-34"]),
    ("DP-099", "Corporate Action Event Golden Copy", "Foundational", "Conformed Facts", "17", "Head of Enterprise Data Management",
     "FN-49", ["FN-34", "FN-27", "FN-24", "FN-21", "FN-33", "FN-28"]),
    ("DP-100", "Taxonomy, Glossary & Data Ownership Register", "Foundational", "Master & Reference", "21", "Head of Data Governance",
     "FN-50", ["FN-17", "FN-49", "FN-51", "FN-42", "FN-44"]),
    ("DP-101", "Governance Metadata & Enterprise Catalog", "Foundational", "Master & Reference", "21", "Chief Data Officer",
     "FN-50", ["FN-17", "FN-49", "FN-51", "FN-38", "FN-36", "FN-44"]),
    ("DP-115", "Approved Broker & Counterparty Master", "Foundational", "Master & Reference", "25", "Head of Trading",
     "FN-23", ["FN-21", "FN-22", "FN-29", "FN-30", "FN-32", "FN-42", "FN-44"]),
    ("DP-116", "Investor Capital Accounts", "Foundational", "Conformed Facts", "30", "Head of Private Markets Operations",   # W4: 30 retired (CW-930); retire at WP0
     "FN-26", ["FN-25", "FN-05", "FN-14", "FN-31", "FN-33", "FN-36", "FN-40"]),
    ("DP-117", "Private Fund Capital Calls & Distributions", "Foundational", "Conformed Facts", "30", "Head of Private Markets Operations",   # W4: 30 retired (CW-930); retire at WP0
     "FN-26", ["FN-25", "FN-31", "FN-33", "FN-34", "FN-40", "FN-14"]),
    ("DP-140", "Portfolio Master & Mandate Link", "Foundational", "Master & Reference", "18", "Head of Investment Operations",
     "FN-27", ["FN-21", "FN-22", "FN-30", "FN-31", "FN-32", "FN-33", "FN-75"]),
    ("DP-141", "Portfolio Transactions", "Foundational", "Conformed Facts", "18", "Head of Investment Operations",
     "FN-27", ["FN-29", "FN-31", "FN-33", "FN-23", "FN-39"]),
    ("DP-142", "Holdings, Tax Lots & Cash", "Foundational", "Conformed Facts", "18", "Head of Investment Operations",
     "FN-27", ["FN-21", "FN-22", "FN-30", "FN-31", "FN-32", "FN-33", "FN-34", "FN-36"]),
    ("DP-143", "Prices, FX & Curves", "Foundational", "Conformed Facts", "22", "Head of Pricing and Valuation",
     "FN-28", ["FN-27", "FN-29", "FN-30", "FN-31", "FN-33", "FN-38", "FN-23"]),
    ("DP-144", "Index Levels & Constituents", "Foundational", "Conformed Facts", "22", "Head of Market Data",
     "FN-28", ["FN-31", "FN-21", "FN-22", "FN-30", "FN-32", "FN-75"]),
    ("DP-145", "Official Returns", "Foundational", "Conformed Facts", "32", "Head of Performance Measurement",
     "FN-31", ["FN-75", "FN-79", "FN-16", "FN-78", "FN-68", "FN-36", "FN-21", "FN-37"]),
    ("DP-146", "Risk Measures", "Foundational", "Conformed Facts", "31", "Head of Investment Risk",
     "FN-30", ["FN-21", "FN-32", "FN-36", "FN-75", "FN-78", "FN-42"]),
    ("DP-147", "Trading Agreements & Settlement Instructions", "Foundational", "Master & Reference", "26", "Head of Trade Operations",
     "FN-29", ["FN-23", "FN-34", "FN-35", "FN-75", "FN-30", "FN-45"]),
    # WP1 re-point (CW-206, FOP+CORP RESPEC): supporting FN-15 and FN-12 re-pointed to FN-77 and FN-72.
    ("DP-165", "NAV & Fund Financials", "Foundational", "Conformed Facts", "27", "Head of Fund Accounting",
     "FN-33", ["FN-77", "FN-78", "FN-72", "FN-75", "FN-36", "FN-38", "FN-28", "FN-31", "FN-79", "FN-19"]),
    ("DP-166", "Fund Ledger & ABOR Positions", "Foundational", "Conformed Facts", "27", "Head of Fund Accounting",
     "FN-33", ["FN-34", "FN-27", "FN-36", "FN-38", "FN-39"]),
    ("DP-167", "Custody Network & Safekeeping Accounts", "Foundational", "Master & Reference", "28", "Head of Asset Servicing",
     "FN-34", ["FN-29", "FN-27", "FN-33", "FN-35", "FN-75", "FN-46"]),
    ("DP-190", "Chart of Accounts & Ledger", "Foundational", "Master & Reference", "19", "Finance Controller",
     "FN-38", ["FN-12", "FN-39", "FN-40", "FN-33", "FN-49", "FN-46", "FN-43"]),
    ("DP-191", "General Ledger Journals & Balances", "Foundational", "Conformed Facts", "19", "Finance Controller",
     "FN-38", ["FN-12", "FN-39", "FN-40", "FN-41", "FN-43", "FN-79"]),
    ("DP-192", "Employee & Position Master", "Foundational", "Master & Reference", "20", "Head of HR Data & People Analytics",
     "FN-41", ["FN-77", "FN-73", "FN-38", "FN-51", "FN-44", "FN-21", "FN-50", "FN-68"]),
    ("DP-210", "Vendor Master", "Foundational", "Master & Reference", "40", "Head of Procurement",
     "FN-46", ["FN-42", "FN-33", "FN-17", "FN-50", "FN-38", "FN-51", "FN-34", "FN-15"]),
    ("DP-211", "Application & System Inventory", "Foundational", "Master & Reference", "41", "Chief Information Officer",
     "FN-51", ["FN-50", "FN-49", "FN-42", "FN-46", "FN-17", "FN-45", "FN-48"]),
    ("DP-212", "Model Inventory & Validation", "Foundational", "Master & Reference", "37", "Head of Model Risk",
     "FN-42", ["FN-50", "FN-30", "FN-31", "FN-28", "FN-21", "FN-23", "FN-24", "FN-77", "FN-43"]),
    ("DP-213", "Enterprise Contract Register", "Foundational", "Master & Reference", "39", "General Counsel",
     "FN-45", ["FN-46", "FN-74", "FN-17", "FN-36", "FN-40", "FN-48", "FN-38"]),
    ("DP-240", "Enterprise Party & Role Master", "Foundational", "Master & Reference", "02", "Head of Enterprise Data Management",
     "FN-49", ["FN-77", "FN-23", "FN-29", "FN-34", "FN-44", "FN-45", "FN-46", "FN-47"]),
]
PRODUCTS += WAVE_E1
# --- Wave E2 (2026-10-08): 35 consumer-aligned products of the accepted Wave E0 briefs (CD-362).
WAVE_E2 = [
    ("DP-102", "Instrument Setup & Security Master Quality", "Consumer-aligned", "Operational", "17", "Head of Enterprise Data Management",
     "FN-49", ["FN-23", "FN-27", "FN-28", "FN-50"]),
    ("DP-103", "Enterprise Data Quality, Issues & Certification", "Consumer-aligned", "Regulatory & Control", "21", "Head of Data Governance",
     "FN-50", ["FN-17", "FN-49", "FN-42", "FN-51", "FN-43"]),
    ("DP-118", "Research Coverage, Recommendations & Publications", "Consumer-aligned", "Analytical", "23", "Director of Research",
     "FN-20", ["FN-21", "FN-22", "FN-24", "FN-32", "FN-44"]),
    ("DP-119", "Internal Credit Views & Money Market Eligibility", "Consumer-aligned", "Regulatory & Control", "23", "Director of Research",
     "FN-20", ["FN-21", "FN-23", "FN-32", "FN-36", "FN-30"]),
    ("DP-120", "Research Estimates, Models & Signals", "Consumer-aligned", "Analytical", "23", "Director of Research",
     "FN-20", ["FN-21", "FN-42", "FN-50"]),
    ("DP-121", "Issuer Meetings & MNPI Control", "Consumer-aligned", "Regulatory & Control", "23", "Director of Research",
     "FN-20", ["FN-44", "FN-24", "FN-21"]),
    ("DP-122", "Research Valuation, Commissions & Research Payments", "Consumer-aligned", "Regulatory & Control", "25", "Head of Trading",
     "FN-23", ["FN-20", "FN-38", "FN-36", "FN-44"]),
    ("DP-123", "Trade Order, Execution & Allocation Record", "Consumer-aligned", "Operational", "25", "Head of Trading",
     "FN-23", ["FN-21", "FN-22", "FN-27", "FN-29", "FN-32", "FN-44"]),
    ("DP-124", "Best Execution & Transaction Cost Analysis", "Consumer-aligned", "Regulatory & Control", "25", "Head of Trading",
     "FN-23", ["FN-21", "FN-36", "FN-44"]),
    ("DP-125", "Trade Allocation Fairness & Trading Regulatory Controls", "Consumer-aligned", "Regulatory & Control", "25", "Head of Trading",
     "FN-23", ["FN-22", "FN-32", "FN-36", "FN-44"]),
    ("DP-126", "Investment Governance, Decisions & Manager Assignment", "Consumer-aligned", "Regulatory & Control", "24", "Chief Investment Officer",
     "FN-21", ["FN-23", "FN-31", "FN-32", "FN-44", "FN-36"]),
    ("DP-127", "Asset Allocation Policy & Glide Paths", "Consumer-aligned", "Analytical", "24", "Chief Investment Officer",
     "FN-21", ["FN-37", "FN-71", "FN-30", "FN-31"]),
    ("DP-128", "Portfolio Targets, Investable Cash & Rebalancing", "Consumer-aligned", "Operational", "24", "Head of Portfolio Management",
     "FN-21", ["FN-22", "FN-23", "FN-27", "FN-30", "FN-32"]),
    ("DP-129", "Model Portfolio Delivery to Sponsors", "Consumer-aligned", "Operational", "24", "Head of Managed Accounts",
     "FN-22", ["FN-74", "FN-23", "FN-78"]),
    # WP1 re-point (C-6, specs_w1c_inv_iop_fdn.py): renamed at its WP1 re-scope.
    ("DP-130", "Institutional Separate Account Tax Management", "Consumer-aligned", "Operational", "24", "Head of Managed Accounts",
     "FN-22", ["FN-75", "FN-74", "FN-21"]),
    ("DP-131", "ETF Baskets & Custom Basket Evidence", "Consumer-aligned", "Operational", "24", "Head of ETF Portfolio Management",
     "FN-22", ["FN-23", "FN-35", "FN-36", "FN-33"]),
    ("DP-132", "Proxy Voting Record & Disclosure", "Consumer-aligned", "Regulatory & Control", "34", "Head of Stewardship",
     "FN-24", ["FN-36", "FN-75", "FN-34", "FN-21", "FN-44"]),
    ("DP-133", "Engagement & Stewardship Reporting", "Consumer-aligned", "Analytical", "34", "Head of Stewardship",
     "FN-24", ["FN-20", "FN-75"]),
    ("DP-134", "ESG Data, Firm Assessments & Exclusion Lists", "Consumer-aligned", "Analytical", "34", "Head of Sustainable Investing",
     "FN-24", ["FN-20", "FN-21", "FN-32", "FN-30", "FN-78"]),
    ("DP-135", "Sustainability Metrics, PAI & Product Outcomes", "Consumer-aligned", "Regulatory & Control", "34", "Head of Sustainable Investing",
     "FN-24", ["FN-36", "FN-30", "FN-75", "FN-78", "FN-68"]),
    ("DP-148", "Pricing Control & Price Challenges", "Consumer-aligned", "Regulatory & Control", "22", "Head of Pricing and Valuation",
     "FN-28", ["FN-33", "FN-49", "FN-36", "FN-42"]),
    ("DP-149", "Fair Value & Valuation Committee Oversight", "Consumer-aligned", "Regulatory & Control", "22", "Head of Pricing and Valuation",
     "FN-28", ["FN-36", "FN-33", "FN-42", "FN-30"]),
    ("DP-150", "IBOR Control, Adjustments & Book Differences", "Consumer-aligned", "Regulatory & Control", "18", "Head of Investment Operations",
     "FN-27", ["FN-33", "FN-34", "FN-21", "FN-42"]),
    ("DP-151", "Trade Confirmation, Settlement & Fails", "Consumer-aligned", "Operational", "26", "Head of Trade Operations",
     "FN-29", ["FN-23", "FN-27", "FN-33", "FN-34", "FN-35"]),
    ("DP-152", "OTC Derivative Lifecycle & Trade Reporting", "Consumer-aligned", "Regulatory & Control", "26", "Head of Trade Operations",
     "FN-29", ["FN-30", "FN-33", "FN-44", "FN-36", "FN-23"]),
    ("DP-153", "Margin, Collateral & Counterparty Exposure", "Consumer-aligned", "Operational", "26", "Head of Trade Operations",
     "FN-29", ["FN-30", "FN-23", "FN-33", "FN-40", "FN-32"]),
    ("DP-154", "Risk Limits, Stress Tests & Exceedances", "Consumer-aligned", "Regulatory & Control", "31", "Head of Investment Risk",
     "FN-30", ["FN-21", "FN-23", "FN-36", "FN-42", "FN-24"]),
    ("DP-155", "Fund Liquidity & Derivatives Risk Programs", "Consumer-aligned", "Regulatory & Control", "31", "Liquidity Risk Management Program Administrator",
     "FN-30", ["FN-36", "FN-21", "FN-33", "FN-37", "FN-32"]),
    ("DP-156", "Product Risk Indicators",   # W1b: PRIIPs scenarios removed (CW-931); WP0 re-scope candidate
      "Consumer-aligned", "Regulatory & Control", "31", "Head of Investment Risk",
     "FN-30", ["FN-78", "FN-37", "FN-36"]),
    ("DP-157", "Performance Attribution & Ex-Post Analytics", "Consumer-aligned", "Analytical", "32", "Head of Performance Measurement",
     "FN-31", ["FN-21", "FN-20", "FN-75", "FN-30"]),
    ("DP-158", "GIPS Composites & Verification", "Consumer-aligned", "Regulatory & Control", "32", "Head of Performance Measurement",
     "FN-31", ["FN-75", "FN-68", "FN-79"]),
    ("DP-159", "Investment Performance Scorecard", "Consumer-aligned", "Analytical", "32", "Head of Performance Measurement",
     "FN-31", ["FN-79", "FN-16", "FN-78", "FN-21", "FN-37", "FN-75"]),
    ("DP-161", "Guideline Coding & Rule Library", "Consumer-aligned", "Regulatory & Control", "33", "Head of Investment Compliance",
     "FN-32", ["FN-75", "FN-37", "FN-36", "FN-44", "FN-24"]),
    ("DP-162", "Compliance Monitoring, Alerts & Overrides", "Consumer-aligned", "Operational", "33", "Head of Investment Compliance",
     "FN-32", ["FN-23", "FN-21", "FN-22", "FN-44"]),
    ("DP-163", "Investment Breaches & Remediation", "Consumer-aligned", "Regulatory & Control", "33", "Head of Investment Compliance",
     "FN-32", ["FN-75", "FN-36", "FN-42", "FN-44", "FN-21", "FN-33"]),
]
PRODUCTS += WAVE_E2

# --- Wave E3 (2026-10-08): 29 consumer-aligned products of the accepted Wave E0 briefs (CD-362).
WAVE_E3 = [
    ("DP-105", "Product Proposal Pipeline & Approval Decisions", "Consumer-aligned", "Analytical", "36", "Head of Product Development",
     "FN-37", ["FN-78", "FN-79", "FN-16", "FN-40", "FN-12"]),
    ("DP-106", "Product Change Calendar & Regulatory Clock", "Consumer-aligned", "Operational", "36", "Head of Product Development",
     "FN-37", ["FN-36", "FN-15", "FN-35", "FN-33", "FN-78", "FN-68", "FN-74", "FN-12", "FN-19"]),
    ("DP-107", "Product Launch Readiness & Go / No-Go", "Consumer-aligned", "Operational", "36", "Head of Product Development",
     "FN-37", ["FN-78", "FN-33", "FN-34", "FN-35", "FN-28", "FN-32", "FN-40", "FN-74"]),
    ("DP-108", "Fund Mergers, Conversions & Liquidations", "Consumer-aligned", "Operational", "36", "Head of Product Development",
     "FN-37", ["FN-35", "FN-33", "FN-36", "FN-15", "FN-39", "FN-74", "FN-19", "FN-30"]),
    ("DP-109", "Product Reviews & Criterion Results", "Consumer-aligned", "Regulatory & Control", "36", "Head of Product Governance",   # W4: re-scope to "Product Reviews & Criterion Results" at WP0 (CW-161, CW-936; value assessments removed)
     "FN-37", ["FN-68", "FN-36", "FN-78", "FN-12"]),
    ("DP-136", "Private Fund Investor Onboarding, Side Letters & ILPA Reporting", "Consumer-aligned", "Operational", "30", "Head of Private Markets Operations",   # W4: 30 retired (CW-930); retire at WP0
     "FN-26", ["FN-25", "FN-05", "FN-14", "FN-39", "FN-44", "FN-15"]),
    ("DP-137", "Private Deal Pipeline & Allocation", "Consumer-aligned", "Analytical", "30", "Head of Private Markets",   # W4: 30 retired (CW-930); retire at WP0
     "FN-25", ["FN-21", "FN-32", "FN-44", "FN-40"]),
    ("DP-138", "Portfolio Company Monitoring & Realizations", "Consumer-aligned", "Analytical", "30", "Head of Private Markets",   # W4: 30 retired (CW-930); retire at WP0
     "FN-25", ["FN-26", "FN-28", "FN-24", "FN-30", "FN-31"]),
    ("DP-139", "Fund Financing, Waterfall & Carried Interest", "Consumer-aligned", "Regulatory & Control", "30", "Head of Private Markets Operations",   # W4: 30 retired (CW-930); retire at WP0
     "FN-26", ["FN-25", "FN-38", "FN-41", "FN-33", "FN-40"]),
    ("DP-160", "Private Markets Investor Performance & PME", "Consumer-aligned", "Analytical", "32", "Head of Performance Measurement",   # W4: private markets retired (CW-930); retire at WP0
     "FN-31", ["FN-26", "FN-25", "FN-14", "FN-36"]),
    ("DP-168", "NAV Oversight & Release Control", "Consumer-aligned", "Regulatory & Control", "27", "Head of Fund Accounting",
     "FN-33", ["FN-15", "FN-36", "FN-28", "FN-42"]),
    ("DP-169", "Swing Pricing & NAV Error Correction", "Consumer-aligned", "Regulatory & Control", "27", "Head of Fund Accounting",
     "FN-33", ["FN-15", "FN-36", "FN-35", "FN-42", "FN-68"]),
    ("DP-170", "Fund Expense, Cap & Waiver Management", "Consumer-aligned", "Operational", "27", "Fund Treasurer",
     "FN-33", ["FN-12", "FN-78", "FN-38", "FN-36", "FN-46"]),
    ("DP-171", "Fund Distributions, Excise & RIC Compliance", "Consumer-aligned", "Regulatory & Control", "27", "Fund Treasurer",
     "FN-33", ["FN-39", "FN-36", "FN-15", "FN-21"]),
    ("DP-172", "Custody & Book Reconciliation Breaks", "Consumer-aligned", "Regulatory & Control", "28", "Head of Asset Servicing",
     "FN-34", ["FN-27", "FN-33", "FN-29", "FN-42", "FN-43"]),
    ("DP-173", "Corporate Actions, Income & Tax Recovery", "Consumer-aligned", "Operational", "28", "Head of Asset Servicing",
     "FN-34", ["FN-21", "FN-27", "FN-33", "FN-39", "FN-75", "FN-24"]),
    ("DP-174", "Securities Lending Program & Revenue", "Consumer-aligned", "Analytical", "28", "Head of Asset Servicing",
     "FN-34", ["FN-36", "FN-30", "FN-24", "FN-21", "FN-12", "FN-29"]),
    ("DP-175", "Safekeeping Account Reconciliation",   # W1b: CASS removed (CW-928); WP0 re-scope candidate
      "Consumer-aligned", "Regulatory & Control", "28", "CASS Operational Oversight Officer",
     "FN-34", ["FN-44", "FN-40", "FN-75", "FN-43"]),
    ("DP-176", "Fund Service Provider Oversight", "Consumer-aligned", "Regulatory & Control", "28", "Head of Fund Administration",
     "FN-33", ["FN-34", "FN-35", "FN-15", "FN-36", "FN-46", "FN-42"]),
    ("DP-177", "Fund Order Processing & Cut-Off Control", "Consumer-aligned", "Operational", "29", "Head of Transfer Agency",
     "FN-35", ["FN-15", "FN-68", "FN-19", "FN-33", "FN-77"]),
    ("DP-178", "Shareholder Settlement with Intermediaries", "Consumer-aligned", "Operational", "29", "Head of Transfer Agency",
     "FN-35", ["FN-40", "FN-33", "FN-34", "FN-15", "FN-44"]),
    ("DP-179", "ETF Creation & Redemption Operations", "Consumer-aligned", "Operational", "29", "Head of ETF Operations",
     "FN-35", ["FN-23", "FN-22", "FN-33", "FN-29", "FN-74"]),
    ("DP-180", "Shareholder CIP, AML & Fraud Alerts", "Consumer-aligned", "Regulatory & Control", "29", "BSA / AML Officer",
     "FN-35", ["FN-44", "FN-15", "FN-68", "FN-42"]),
    ("DP-181", "TA Daily Controls & Capital Stock Proof", "Consumer-aligned", "Regulatory & Control", "29", "Head of Transfer Agency",
     "FN-35", ["FN-33", "FN-15", "FN-36", "FN-43"]),
    ("DP-182", "Fund Board Governance, Reporting & Approvals", "Consumer-aligned", "Regulatory & Control", "35", "Head of Fund Legal",
     "FN-36", ["FN-33", "FN-32", "FN-30", "FN-28", "FN-37", "FN-44", "FN-45"]),
    ("DP-183", "Advisory Agreements & 15(c) Renewal", "Consumer-aligned", "Regulatory & Control", "35", "Head of Fund Legal",
     "FN-36", ["FN-78", "FN-12", "FN-38", "FN-31", "FN-33", "FN-45"]),
    ("DP-184", "Fund Regulatory Filing Calendar & Evidence", "Consumer-aligned", "Regulatory & Control", "35", "Head of Fund Regulatory Reporting",
     "FN-36", ["FN-33", "FN-32", "FN-30", "FN-44", "FN-50", "FN-22"]),
    ("DP-185", "Registered Fund Report Data (N-PORT, N-CEN, N-MFP)", "Consumer-aligned", "Regulatory & Control", "35", "Head of Fund Regulatory Reporting",
     "FN-36", ["FN-33", "FN-30", "FN-31", "FN-34", "FN-35", "FN-32"]),
    ("DP-186", "Private Fund Report Data (Form PF)", "Consumer-aligned", "Regulatory & Control", "35", "Head of Fund Regulatory Reporting",
     "FN-36", ["FN-30", "FN-33", "FN-44"]),
]
PRODUCTS += WAVE_E3

# --- Wave E4 (2026-10-08): 43 consumer-aligned products of the accepted Wave E0 briefs (CD-362).
WAVE_E4 = [
    ("DP-104", "AI Use Case Register & Data Usage Approvals", "Consumer-aligned", "Regulatory & Control", "21", "Chief Data Officer",
     "FN-50", ["FN-42", "FN-44", "FN-51", "FN-45"]),
    ("DP-193", "Financial Close, Consolidation & Statements", "Consumer-aligned", "Regulatory & Control", "19", "Head of Financial Reporting",
     "FN-38", ["FN-43", "FN-12", "FN-33", "FN-40", "FN-45", "FN-42"]),
    ("DP-194", "Enterprise Budget, Forecast & Operating Expense", "Consumer-aligned", "Analytical", "19", "Head of FP&A",
     "FN-38", ["FN-79", "FN-12", "FN-41", "FN-40", "FN-37"]),
    ("DP-195", "Payables, Receivables & Working Capital", "Consumer-aligned", "Operational", "19", "Head of Accounting Operations",
     "FN-38", ["FN-46", "FN-40", "FN-12", "FN-75", "FN-33", "FN-17", "FN-39"]),
    ("DP-196", "Corporate Tax Provision, Filings & Transfer Pricing", "Consumer-aligned", "Regulatory & Control", "19", "Head of Tax",
     "FN-39", ["FN-38", "FN-12", "FN-45", "FN-40"]),
    ("DP-197", "Workforce Movement, Hiring & Screening", "Consumer-aligned", "Analytical", "20", "Head of HR Data & People Analytics",
     "FN-41", ["FN-38", "FN-79", "FN-44", "FN-68", "FN-51"]),
    ("DP-198", "Pay, Payroll & Benefits", "Consumer-aligned", "Operational", "20", "Head of Reward",
     "FN-41", ["FN-38", "FN-73", "FN-12", "FN-19"]),
    ("DP-199", "Deferred Awards & Clawback",   # W1b: MRT removed (CW-920); WP0 re-scope candidate
      "Consumer-aligned", "Regulatory & Control", "20", "Head of Reward",
     "FN-41", ["FN-44", "FN-73", "FN-38", "FN-45"]),
    ("DP-200", "Talent, Succession & Mandatory Training", "Consumer-aligned", "Regulatory & Control", "20", "Head of Talent & Learning",
     "FN-41", ["FN-44", "FN-68", "FN-42", "FN-79"]),
    ("DP-201", "Workforce Diversity, Pay Equity & Human Capital Disclosure", "Consumer-aligned", "Regulatory & Control", "20", "Head of HR Data & People Analytics",
     "FN-41", ["FN-47", "FN-38", "FN-24", "FN-50"]),
    ("DP-202", "Corporate Cash, Bank Accounts & Liquidity", "Consumer-aligned", "Operational", "43", "Group Treasurer",
     "FN-40", ["FN-38", "FN-45", "FN-42"]),
    ("DP-203", "Corporate Funding, Intercompany Loans & Hedging", "Consumer-aligned", "Analytical", "43", "Group Treasurer",
     "FN-40", ["FN-38", "FN-39", "FN-29", "FN-45"]),
    ("DP-204", "Seed & Co-Investment Capital", "Consumer-aligned", "Analytical", "43", "Group Treasurer",
     "FN-40", ["FN-37", "FN-38", "FN-21", "FN-33", "FN-78"]),
    ("DP-205", "Regulatory Capital & ICARA", "Consumer-aligned", "Regulatory & Control", "43", "Head of Regulatory Capital",
     "FN-40", ["FN-38", "FN-42", "FN-44", "FN-45"]),
    ("DP-206", "Corporate Insurance Program & Claims", "Consumer-aligned", "Analytical", "43", "Group Treasurer",
     "FN-40", ["FN-42", "FN-45", "FN-36", "FN-51", "FN-48"]),
    ("DP-207", "Real Estate, Occupancy & Operational Footprint", "Consumer-aligned", "Analytical", "44", "Head of Corporate Real Estate",
     "FN-48", ["FN-38", "FN-47", "FN-24", "FN-41"]),
    ("DP-208", "Workplace Services, Physical Security & Safety", "Consumer-aligned", "Regulatory & Control", "44", "Head of Workplace Services",
     "FN-48", ["FN-42", "FN-41", "FN-51", "FN-46"]),
    ("DP-209", "Travel & Expense Spend and Policy Compliance", "Consumer-aligned", "Regulatory & Control", "44", "Finance Controller",
     "FN-38", ["FN-48", "FN-68", "FN-12", "FN-44", "FN-79"]),
    ("DP-214", "Enterprise Risk Profile, Controls & KRIs", "Consumer-aligned", "Analytical", "37", "Head of Operational Risk",
     "FN-42", ["FN-43", "FN-44", "FN-38", "FN-40", "FN-68", "FN-51"]),
    ("DP-215", "Operational Incidents, Losses & Regulatory Notifications", "Consumer-aligned", "Regulatory & Control", "37", "Head of Operational Risk",
     "FN-42", ["FN-51", "FN-38", "FN-40", "FN-33", "FN-23", "FN-32", "FN-45", "FN-35", "FN-19"]),
    ("DP-216", "Risk Issues & Remediation Tracker", "Consumer-aligned", "Operational", "37", "Head of Operational Risk",
     "FN-42", ["FN-43", "FN-44", "FN-51", "FN-46", "FN-45", "FN-36"]),
    ("DP-217", "Critical Functions & Business Continuity",   # W1b: UK resilience regime removed (CW-937); WP0 re-scope candidate
      "Consumer-aligned", "Regulatory & Control", "37", "Head of Operational Resilience",
     "FN-42", ["FN-51", "FN-46", "FN-47", "FN-48", "FN-33", "FN-35"]),
    ("DP-218", "Internal Audit Universe, Plan & Findings", "Consumer-aligned", "Analytical", "37", "Chief Audit Executive",
     "FN-43", ["FN-42", "FN-45", "FN-36", "FN-44"]),
    ("DP-219", "Third-Party Oversight: Risk, Performance & Renewals", "Consumer-aligned", "Regulatory & Control", "40", "Head of Vendor Management",
     "FN-46", ["FN-42", "FN-17", "FN-50", "FN-33", "FN-34", "FN-35", "FN-15", "FN-51", "FN-38"]),
    ("DP-220", "Outsourcing Register",   # W1b: DORA register removed (CW-940); WP0 re-scope candidate
      "Consumer-aligned", "Regulatory & Control", "40", "Head of Procurement",
     "FN-46", ["FN-42", "FN-51", "FN-44", "FN-17", "FN-33", "FN-36"]),
    ("DP-221", "Source-to-Pay Controls & Supplier Spend", "Consumer-aligned", "Operational", "40", "Head of Procurement",
     "FN-46", ["FN-38", "FN-12", "FN-48", "FN-51"]),
    ("DP-222", "Firm Authorizations, Filings & Ownership Disclosures", "Consumer-aligned", "Regulatory & Control", "38", "Head of Regulatory Affairs",
     "FN-44", ["FN-36", "FN-45", "FN-23", "FN-21", "FN-68"]),
    ("DP-223", "Regulatory Examinations & Change Management", "Consumer-aligned", "Operational", "38", "Head of Regulatory Affairs",
     "FN-44", ["FN-45", "FN-42", "FN-51", "FN-68", "FN-36", "FN-50", "FN-37"]),
    ("DP-224", "Compliance Program, Policies & Attestations", "Consumer-aligned", "Regulatory & Control", "38", "Chief Compliance Officer",
     "FN-44", ["FN-68", "FN-36", "FN-41", "FN-43", "FN-51"]),
    ("DP-225", "Code of Ethics: Personal Trading, Conflicts & Political Contributions", "Consumer-aligned", "Regulatory & Control", "38", "Chief Compliance Officer",
     "FN-44", ["FN-41", "FN-47", "FN-75", "FN-68"]),
    ("DP-226", "AML & Sanctions Program Cases", "Consumer-aligned", "Regulatory & Control", "38", "BSA / AML Officer",
     "FN-44", ["FN-35", "FN-46", "FN-68", "FN-19"]),
    ("DP-227", "Restricted, Watch & Insider Lists", "Consumer-aligned", "Operational", "38", "Head of Compliance Control Room",
     "FN-44", ["FN-32", "FN-20", "FN-23", "FN-24", "FN-21"]),
    ("DP-228", "Trade Surveillance & Suspicious Activity Reporting", "Consumer-aligned", "Regulatory & Control", "38", "Head of Compliance Surveillance",   # W4: STOR (UK MAR) removed (CW-163, CW-938); re-scope at WP0
     "FN-44", ["FN-23", "FN-32", "FN-68", "FN-22"]),
    ("DP-229", "Legal Matters, Holds & Outside Counsel", "Consumer-aligned", "Analytical", "39", "General Counsel",
     "FN-45", ["FN-38", "FN-42", "FN-68", "FN-51", "FN-41", "FN-44", "FN-47"]),
    ("DP-230", "Entity Governance, Officers & Signing Authority", "Consumer-aligned", "Regulatory & Control", "39", "Company Secretary",
     "FN-45", ["FN-44", "FN-40", "FN-38", "FN-36", "FN-43"]),
    ("DP-231", "IT Service Management: Incidents, Problems & Changes", "Consumer-aligned", "Operational", "41", "Head of IT Service Management",
     "FN-51", ["FN-42", "FN-46", "FN-49", "FN-27"]),
    ("DP-232", "Security Incidents, Testing & Vulnerabilities", "Consumer-aligned", "Regulatory & Control", "41", "Chief Information Security Officer",
     "FN-51", ["FN-42", "FN-44", "FN-45", "FN-15", "FN-43"]),
    ("DP-233", "Identity, Access & Device Lifecycle", "Consumer-aligned", "Regulatory & Control", "41", "Chief Information Security Officer",
     "FN-51", ["FN-43", "FN-44", "FN-41", "FN-17", "FN-50", "FN-38"]),
    ("DP-234", "Change & Project Portfolio", "Consumer-aligned", "Analytical", "41", "Head of Enterprise PMO",
     "FN-51", ["FN-37", "FN-44", "FN-38", "FN-50", "FN-79"]),
    ("DP-235", "Brand Register, Usage Rights & Trademark Protection", "Consumer-aligned", "Master & Reference", "42", "Head of Corporate Communications",
     "FN-47", ["FN-45", "FN-76", "FN-37", "FN-74"]),
    ("DP-236", "Media, Coverage & Reputation", "Consumer-aligned", "Analytical", "42", "Head of Media Relations",
     "FN-47", ["FN-76", "FN-68", "FN-37", "FN-16"]),
    ("DP-237", "Issues, Crisis & Internal Communications", "Consumer-aligned", "Operational", "42", "Head of Corporate Communications",
     "FN-47", ["FN-42", "FN-51", "FN-45", "FN-41", "FN-44"]),
    ("DP-238", "Corporate Disclosures, Public Policy & Lobbying", "Consumer-aligned", "Regulatory & Control", "42", "Head of Government Relations",
     "FN-47", ["FN-44", "FN-41", "FN-40", "FN-39", "FN-45"]),
]
PRODUCTS += WAVE_E4

# --- Wave E5 (2026-10-08): the cross-area products of the program lead (plan §7, E5; CD-362 reserves DP-241 to DP-249).
WAVE_E5 = [
    ("DP-241", "Firm AUM Reconciliation", "Consumer-aligned", "Analytical", "27", "Head of Fund Accounting",
     "FN-33", ["FN-79", "FN-77", "FN-12", "FN-27", "FN-50"]),
    ("DP-242", "Fund 360 & Product P&L", "Consumer-aligned", "Analytical", "01", "Head of Product",
     "FN-78", ["FN-37", "FN-12", "FN-33", "FN-36", "FN-79"]),
    ("DP-243", "Total Client Relationship", "Consumer-aligned", "Analytical", "02", "Head of Institutional Client Data",   # W4: Consultant Coverage returns on the restored 05 objects (CW-132)
     "FN-75", ["FN-74", "FN-71", "FN-79"]),
    ("DP-244", "Cost to Serve by Channel & Vehicle", "Consumer-aligned", "Analytical", "10", "Head of Distribution Finance",
     "FN-12", ["FN-38", "FN-33", "FN-35", "FN-79"]),
    ("DP-245", "Enterprise KPI & Metrics Registry", "Consumer-aligned", "Analytical", "21", "Chief Data Officer",
     "FN-50", ["FN-79", "FN-38", "FN-31", "FN-42"]),
    ("DP-246", "Regulatory Filing Data Hub", "Consumer-aligned", "Regulatory & Control", "35", "Head of Fund Regulatory Reporting",
     "FN-36", ["FN-44", "FN-68", "FN-32", "FN-30", "FN-40"]),
    ("DP-247", "Board & Management Reporting Pack", "Consumer-aligned", "Analytical", "19", "Head of FP&A",
     "FN-38", ["FN-79", "FN-36", "FN-42", "FN-50"]),
    ("DP-248", "Enterprise Risk & Control View", "Consumer-aligned", "Regulatory & Control", "37", "Head of Operational Risk",
     "FN-42", ["FN-43", "FN-44", "FN-32", "FN-68", "FN-51"]),
]
PRODUCTS += WAVE_E5
IN_PROGRESS = set()            # Waves E1 to E5 specified 2026-10-08; every registered product has a specification

WAVE = {**{w[0]: "Wave 2" for w in WAVE_2}, **{w[0]: "Wave 3" for w in WAVE_3},
        **{w[0]: "Wave 4" for w in WAVE_4}}   # products not listed are Wave 1
RATIONALE = {w[0]: (w[10], w[9], w[11]) for w in WAVE_2 + WAVE_3 + WAVE_4}   # (priority, value / rationale, dependency or gap)
WAVE.update({p[0]: "Wave E1" for p in WAVE_E1})
WAVE.update({**{p[0]: "Wave E2" for p in WAVE_E2}, **{p[0]: "Wave E3" for p in WAVE_E3}, **{p[0]: "Wave E4" for p in WAVE_E4}})
WAVE.update({p[0]: "Wave E5" for p in WAVE_E5})

# --- Pending WP0 re-scope (W1 merge, CW-041) ----------------------------------------------------------------------------
# Rule: every Consumer-aligned product of the wholesale distribution waves (the base PRODUCTS list of Wave 1, WAVE_2,
# WAVE_3 and WAVE_4) is pending. Stage W1 replaces Data Domains 02 and 15, and these products read them by object and
# attribute name; WP0 re-scopes or retires each one by table (Wealth_Manager_Rework_Plan.md section 8; CW-013), so they
# are not re-pointed at the W1 merge. The Foundational products of those waves (DP-001 to DP-014, DP-075, DP-093,
# DP-094) and every product of Waves E1 to E5 stay live and are re-pointed at the merge.
# A pending product keeps its register row and its spec file, but the validators, catalog, logical models, semantic
# models and explorer treat it like an in-progress product: its spec and model are not validated or built, and it is
# listed only as "Pending re-scope (WP0)" (catalog Products tab; a collapsed group on the explorer's products page).
# A live product or logical model that depends on a pending one is a warning until WP0 ("live product X depends on
# pending product Y; re-point at WP0; CW-041"), counted on every run so every dependency to re-point stays visible. The register is emptied at WP0 as each product is re-scoped or retired.
# This is the W1 register as it stood (copied to RESCOPE_PENDING_W1 below); it is reset after WP0_DISPOSITIONS and is empty
# since the WP2 retirement sweep.
RESCOPE_PENDING = {
    # Wave 1 (32)
    "DP-015": "CW-041", "DP-016": "CW-041", "DP-017": "CW-041", "DP-092": "CW-041", "DP-018": "CW-041",
    "DP-019": "CW-041", "DP-020": "CW-041", "DP-021": "CW-041", "DP-022": "CW-041", "DP-023": "CW-041",
    "DP-024": "CW-041", "DP-025": "CW-041", "DP-026": "CW-041", "DP-027": "CW-041", "DP-028": "CW-041",
    "DP-029": "CW-041", "DP-030": "CW-041", "DP-031": "CW-041", "DP-032": "CW-041", "DP-033": "CW-041",
    "DP-034": "CW-041", "DP-035": "CW-041", "DP-036": "CW-041", "DP-037": "CW-041", "DP-038": "CW-041",
    "DP-039": "CW-041", "DP-040": "CW-041", "DP-041": "CW-041", "DP-042": "CW-041", "DP-043": "CW-041",
    "DP-044": "CW-041", "DP-045": "CW-041",
    # Wave 2 (30)
    "DP-046": "CW-041", "DP-047": "CW-041", "DP-048": "CW-041", "DP-049": "CW-041", "DP-050": "CW-041",
    "DP-051": "CW-041", "DP-052": "CW-041", "DP-053": "CW-041", "DP-054": "CW-041", "DP-055": "CW-041",
    "DP-056": "CW-041", "DP-057": "CW-041", "DP-058": "CW-041", "DP-059": "CW-041", "DP-060": "CW-041",
    "DP-061": "CW-041", "DP-062": "CW-041", "DP-063": "CW-041", "DP-064": "CW-041", "DP-065": "CW-041",
    "DP-066": "CW-041", "DP-067": "CW-041", "DP-068": "CW-041", "DP-069": "CW-041", "DP-070": "CW-041",
    "DP-071": "CW-041", "DP-072": "CW-041", "DP-073": "CW-041", "DP-074": "CW-041", "DP-076": "CW-041",
    # Wave 3 (15)
    "DP-077": "CW-041", "DP-078": "CW-041", "DP-079": "CW-041", "DP-080": "CW-041", "DP-081": "CW-041",
    "DP-082": "CW-041", "DP-083": "CW-041", "DP-084": "CW-041", "DP-085": "CW-041", "DP-086": "CW-041",
    "DP-087": "CW-041", "DP-088": "CW-041", "DP-089": "CW-041", "DP-090": "CW-041", "DP-091": "CW-041",
    # Wave 4 (2)
    "DP-095": "CW-041", "DP-096": "CW-041",
}

# --- Wealth-manager product waves (WP0 framing, 2026-10-15; CW-201; Wealth_Manager_Rework_Plan.md sections 8 and 10) ----
# WP0 drafts candidates in area briefs (consolidation/proposals_wp0_*.py, checked by candidate_coverage.py); WP1 registers
# the accepted candidates and the re-scoped products wave by wave and writes their specs; WP2 writes the key registry,
# logical models and semantic models. Wave codes are what a candidate's "wave" field names; each register list below is
# filled at WP1 with PRODUCTS-shaped tuples, and a registered product may lack its spec while its wave is in IN_PROGRESS.
#   WP1F         the foundational wave: re-scoped foundations (DP-001 to DP-014, DP-093, DP-240 ...) and DP-300 onward
#   WP1C         the consumer-aligned waves; a candidate may name WP1C (its area is its owning domain's area,
#                capability_map/areas.py DOMAIN_AREA) or WP1C_<area> explicitly; WP1 runs one consumer wave per area
#   WP2          logical and semantic models (no product is registered in it)
WEALTH_AREAS = ["CLA", "INV", "IOP", "FOP", "BWO", "DIS", "CORP", "FDN"]
WAVE_CODES = {"WP1F": "Wave WP1F: foundational products (re-scoped and new)",
              **{f"WP1C_{a}": f"Wave WP1C {a}: consumer-aligned products of the {a} area" for a in WEALTH_AREAS},
              "WP2": "Wave WP2: key registry, logical models and semantic models"}
FOUNDATIONAL_WAVES = {"WP1F"}
CONSUMER_WAVES = {"WP1C"} | {f"WP1C_{a}" for a in WEALTH_AREAS}
CANDIDATE_WAVES = FOUNDATIONAL_WAVES | CONSUMER_WAVES                    # what candidate_coverage.py accepts for the wealth briefs
HISTORICAL_CANDIDATE_WAVES = {"E1", "E2", "E3", "E4", "E5"}                # the wholesale E0 proposals_dp_*.py modules
LEGACY_WAVE_ALIASES = {"W1": "WP1F", "W2": "WP1C", "W3": "WP1C", "W4": "WP1C"}   # accepted with a warning (W0 brief instructions)
# Registered at the WP0 integration (2026-10-15) from the accepted candidates of the seven WP0 modules, in progress until
# their WP1 specs validate (IN_PROGRESS). New ids only; the re-scoped existing products are in WP1_RESCOPED below.
WAVE_WP1F = [
    ('DP-300', 'Client Holdings, Lots & Cost Basis', 'Foundational', 'Conformed Facts', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-63', 'FN-60', 'FN-72', 'FN-77', 'FN-67', 'FN-69', 'FN-31', 'FN-39']),
    ('DP-301', 'Client Orders & Executions', 'Foundational', 'Conformed Facts', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-65', 'FN-63', 'FN-68', 'FN-72', 'FN-67', 'FN-44']),
    ('DP-302', 'Money Movement Transactions', 'Foundational', 'Conformed Facts', '50', 'Head of Money Movement', 'FN-66', ['FN-65', 'FN-62', 'FN-68', 'FN-44', 'FN-77', 'FN-71', 'FN-69']),
    ('DP-303', 'Advice Plans & Recommendations', 'Foundational', 'Master & Reference', '45', 'Head of Advice', 'FN-60', ['FN-61', 'FN-68', 'FN-71', 'FN-63', 'FN-73', 'FN-62']),
    ('DP-304', 'Managed Account Model Assignments', 'Foundational', 'Master & Reference', '46', 'Head of Managed Account Operations', 'FN-63', ['FN-60', 'FN-61', 'FN-72', 'FN-31', 'FN-33', 'FN-71', 'FN-69']),
    ('DP-305', 'Fee Schedules & Billing Runs', 'Foundational', 'Conformed Facts', '47', 'Head of Pricing & Billing', 'FN-72', ['FN-12', 'FN-63', 'FN-75', 'FN-69', 'FN-68', 'FN-38']),
    ('DP-306', 'Manager & Sub-Adviser Master', 'Foundational', 'Master & Reference', '52', 'Head of Manager Research', 'FN-70', ['FN-21', 'FN-36', 'FN-32', 'FN-31', 'FN-60', 'FN-75', 'FN-78']),
    ('DP-307', 'Trust Fiduciary Record', 'Foundational', 'Master & Reference', '51', 'Head of Trust Services', 'FN-69', ['FN-62', 'FN-63', 'FN-39', 'FN-72']),
    ('DP-381', 'Client Service Interactions & Requests', 'Foundational', 'Conformed Facts', '13', 'Head of Client Service', 'FN-67', ['FN-62', 'FN-68', 'FN-61', 'FN-65', 'FN-66', 'FN-77', 'FN-38', 'FN-71']),
    ('DP-382', 'Client Document & Delivery Record', 'Foundational', 'Conformed Facts', '13', 'Head of Client Communications', 'FN-67', ['FN-68', 'FN-62', 'FN-64', 'FN-72', 'FN-35', 'FN-37', 'FN-76']),
    ('DP-430', 'Participant Balances & Ledger', 'Foundational', 'Conformed Facts', '16', 'Head of Retirement Plan Services', 'FN-19', ['FN-71', 'FN-63', 'FN-77', 'FN-31']),
    ('DP-431', 'Sweep Programs & Program Banks', 'Foundational', 'Master & Reference', '50', 'Head of Cash Programs', 'FN-66', ['FN-65', 'FN-72', 'FN-38', 'FN-62']),
    ('DP-432', 'Execution Venues & Routing Rules', 'Foundational', 'Master & Reference', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-68', 'FN-44']),
    ('DP-480', 'Cost Allocation & Management Hierarchy', 'Foundational', 'Conformed Facts', '10', 'Head of Client Economics & Profitability', 'FN-12', ['FN-38', 'FN-72', 'FN-77', 'FN-78']),
    ('DP-481', 'Competitor Offerings & Price Observations', 'Foundational', 'Master & Reference', '11', 'Head of Market Intelligence', 'FN-16', ['FN-72', 'FN-78', 'FN-37', 'FN-12']),
    ('DP-530', 'Capital Market Assumptions, Model Lineups & Model Weights', 'Foundational', 'Master & Reference', '24', 'Chief Investment Officer', 'FN-21', ['FN-60', 'FN-61', 'FN-63', 'FN-71', 'FN-74', 'FN-30', 'FN-70']),
    ('DP-580', 'Fund Share Register & Postings', 'Foundational', 'Conformed Facts', '29', 'Head of Transfer Agency', 'FN-35', ['FN-33', 'FN-65', 'FN-77', 'FN-67', 'FN-39', 'FN-36']),
]
WAVE_WP1C = {a: [] for a in WEALTH_AREAS}             # one list per area; plain WP1C takes the owning domain's area
WAVE_WP1C['CLA'] = [
    ('DP-320', 'Household 360', 'Consumer-aligned', 'Analytical', '02', 'Head of Client Data', 'FN-60', ['FN-61', 'FN-62', 'FN-63', 'FN-67', 'FN-72', 'FN-73', 'FN-69']),
    ('DP-321', 'Authorized Persons, Trusted Contacts & Beneficiaries', 'Consumer-aligned', 'Operational', '02', 'Head of Account Services', 'FN-62', ['FN-67', 'FN-68', 'FN-69', 'FN-60']),
    ('DP-322', 'Client Protection Flags & Senior Investor Register', 'Consumer-aligned', 'Regulatory & Control', '02', 'Head of Retail Conduct', 'FN-68', ['FN-66', 'FN-67', 'FN-60', 'FN-69', 'FN-62']),
    ('DP-323', 'Investor Profile Currency & Suitability Inputs', 'Consumer-aligned', 'Regulatory & Control', '02', 'Head of Advice', 'FN-60', ['FN-61', 'FN-68', 'FN-62', 'FN-63']),
    ('DP-324', 'Client Contactability, Preferences & Consent', 'Consumer-aligned', 'Operational', '02', 'Head of Client Service', 'FN-67', ['FN-76', 'FN-62', 'FN-61']),
    ('DP-325', 'Service Tier Qualification & Client Segments', 'Consumer-aligned', 'Analytical', '02', 'Head of Advice Products', 'FN-78', ['FN-73', 'FN-67', 'FN-76', 'FN-60']),
    ('DP-326', 'Client Base Movement & Attrition', 'Consumer-aligned', 'Analytical', '02', 'Head of Client & Channel Analytics', 'FN-77', ['FN-76', 'FN-67', 'FN-60', 'FN-78']),
    ('DP-327', 'Account Opening & Good Order Pipeline', 'Consumer-aligned', 'Operational', '15', 'Head of Client Onboarding', 'FN-62', ['FN-61', 'FN-76', 'FN-67', 'FN-66']),
    ('DP-328', 'Account Features, Agreements & Disclosure Evidence', 'Consumer-aligned', 'Regulatory & Control', '15', 'Head of Account Services', 'FN-62', ['FN-68', 'FN-65', 'FN-66', 'FN-64']),
    ('DP-329', 'Retirement Account RMD & Distribution Tracker', 'Consumer-aligned', 'Operational', '15', 'Head of Account Services', 'FN-62', ['FN-60', 'FN-67', 'FN-65', 'FN-66']),
    ('DP-330', 'Account Tax Certification & Cost Basis Election Status', 'Consumer-aligned', 'Regulatory & Control', '15', 'Head of Account Services', 'FN-62', ['FN-65', 'FN-67', 'FN-39']),
    ('DP-331', 'Systematic Investment & Withdrawal Plans', 'Consumer-aligned', 'Analytical', '15', 'Head of Account Services', 'FN-66', ['FN-62', 'FN-60', 'FN-77']),
    ('DP-332', 'Advisory Program Enrollment & Rule 3a-4 Compliance', 'Consumer-aligned', 'Regulatory & Control', '15', 'Head of Managed Account Operations', 'FN-63', ['FN-61', 'FN-68', 'FN-60', 'FN-78']),
    ('DP-333', 'Advice Funnel & Conversion', 'Consumer-aligned', 'Analytical', '45', 'Head of Advice', 'FN-60', ['FN-61', 'FN-76', 'FN-73', 'FN-78']),
    ('DP-334', 'Plan Quality & Recommendation Evidence (Reg BI File)', 'Consumer-aligned', 'Regulatory & Control', '45', 'Head of Advice', 'FN-60', ['FN-68', 'FN-61', 'FN-71']),
    ('DP-335', 'Rollover Recommendations & PTE 2020-02 Evidence', 'Consumer-aligned', 'Regulatory & Control', '45', 'Head of Workplace Solutions', 'FN-71', ['FN-60', 'FN-68', 'FN-19']),
    ('DP-336', 'Advice Review Cadence & Plan Currency', 'Consumer-aligned', 'Operational', '45', 'Head of Financial Planning', 'FN-60', ['FN-61', 'FN-73', 'FN-68']),
    ('DP-337', 'Goal Progress & Funded Status', 'Consumer-aligned', 'Analytical', '45', 'Head of Digital Advice', 'FN-61', ['FN-60', 'FN-67', 'FN-71']),
    ('DP-338', 'Held-Away Assets & Consolidation Opportunity', 'Consumer-aligned', 'Analytical', '45', 'Head of Financial Planning', 'FN-60', ['FN-76', 'FN-61', 'FN-71', 'FN-73']),
    ('DP-339', 'Digital Advice Engine Outcomes & Oversight', 'Consumer-aligned', 'Regulatory & Control', '45', 'Head of Digital Advice', 'FN-61', ['FN-60', 'FN-68', 'FN-42', 'FN-63']),
    ('DP-340', 'Advisor Client Action Worklist', 'Consumer-aligned', 'Operational', '45', 'Head of Advice', 'FN-60', ['FN-73', 'FN-67', 'FN-63', 'FN-62']),
    ('DP-341', 'Drift & Rebalance Monitor', 'Consumer-aligned', 'Operational', '46', 'Head of Managed Account Operations', 'FN-63', ['FN-61', 'FN-60', 'FN-64']),
    ('DP-342', 'Rebalance & Tax-Loss Harvest Effectiveness', 'Consumer-aligned', 'Analytical', '46', 'Head of Managed Account Operations', 'FN-63', ['FN-61', 'FN-60', 'FN-31', 'FN-72']),
    ('DP-343', 'Wash-Sale Control & Household Tax Coordination', 'Consumer-aligned', 'Regulatory & Control', '46', 'Head of Managed Account Operations', 'FN-63', ['FN-65', 'FN-64', 'FN-68']),
    ('DP-344', 'Trade Proposals, Cash Raises & Pre-Trade Exceptions', 'Consumer-aligned', 'Operational', '46', 'Head of Managed Account Operations', 'FN-63', ['FN-64', 'FN-71', 'FN-66']),
    ('DP-345', 'Managed Account Assets, Models & Composites', 'Consumer-aligned', 'Analytical', '46', 'Head of Managed Account Operations', 'FN-63', ['FN-31', 'FN-78', 'FN-77']),
    ('DP-346', 'Fee Billing Accuracy & Custody-Rule Evidence', 'Consumer-aligned', 'Regulatory & Control', '47', 'Head of Pricing & Billing', 'FN-72', ['FN-68', 'FN-44', 'FN-38', 'FN-63']),
    ('DP-347', 'Fee Waivers, Adjustments & Billing Disputes', 'Consumer-aligned', 'Operational', '47', 'Head of Pricing & Billing', 'FN-72', ['FN-67', 'FN-68', 'FN-38']),
    ('DP-348', 'Client Pricing Realization & Breakpoints', 'Consumer-aligned', 'Analytical', '47', 'Head of Pricing & Billing', 'FN-72', ['FN-78', 'FN-38', 'FN-73']),
    ('DP-349', 'Brokerage Commissions & Account Service Charges', 'Consumer-aligned', 'Regulatory & Control', '47', 'Head of Pricing & Billing', 'FN-72', ['FN-64', 'FN-66', 'FN-65', 'FN-68']),
    ('DP-350', 'Fee Invoicing, Mandate Billing & Performance Fees', 'Consumer-aligned', 'Operational', '47', 'Head of Pricing & Billing', 'FN-72', ['FN-75', 'FN-38', 'FN-60']),
    ('DP-351', 'Fiduciary Account Review Compliance', 'Consumer-aligned', 'Regulatory & Control', '51', 'Head of Trust Services', 'FN-69', ['FN-68', 'FN-63', 'FN-44']),
    ('DP-352', 'Discretionary Distribution Decisions', 'Consumer-aligned', 'Regulatory & Control', '51', 'Head of Trust Services', 'FN-69', ['FN-66', 'FN-68']),
    ('DP-353', 'Trust Principal & Income Accounting', 'Consumer-aligned', 'Operational', '51', 'Head of Trust Services', 'FN-69', ['FN-65', 'FN-72']),
    ('DP-354', 'Estate Settlement Case Tracker', 'Consumer-aligned', 'Operational', '51', 'Head of Trust Services', 'FN-69', ['FN-67', 'FN-62']),
    ('DP-355', 'Fiduciary Tax Filing & K-1 Status', 'Consumer-aligned', 'Regulatory & Control', '51', 'Head of Trust Services', 'FN-69', ['FN-39', 'FN-67']),
    ('DP-383', 'Platform Shelf, Availability & Due Diligence Status', 'Consumer-aligned', 'Regulatory & Control', '01', 'Head of Brokerage Products', 'FN-78', ['FN-70', 'FN-64', 'FN-68', 'FN-60', 'FN-63']),
    ('DP-384', 'Advice Service & Platform Feature Development Pipeline', 'Consumer-aligned', 'Operational', '36', 'Head of Product Development', 'FN-37', ['FN-78', 'FN-61', 'FN-51', 'FN-72', 'FN-68', 'FN-63']),
    ('DP-385', 'Advice Program Outcomes Evidence', 'Consumer-aligned', 'Regulatory & Control', '36', 'Head of Product Governance', 'FN-37', ['FN-78', 'FN-63', 'FN-68', 'FN-60', 'FN-31']),
    ('DP-386', 'Product Documents & Commentary Currency', 'Consumer-aligned', 'Regulatory & Control', '01', 'Head of Product', 'FN-78', ['FN-68', 'FN-31', 'FN-37', 'FN-76']),
    ('DP-387', 'Advisor Capacity & Book Health', 'Consumer-aligned', 'Analytical', '03', 'Head of Advisor Workforce', 'FN-73', ['FN-60', 'FN-77', 'FN-68', 'FN-67', 'FN-41']),
    ('DP-388', 'Client Reassignment & Retention', 'Consumer-aligned', 'Operational', '03', 'Head of Advisor Workforce', 'FN-73', ['FN-77', 'FN-67', 'FN-60']),
    ('DP-389', 'Advisor Contact Cadence & Coverage Standards', 'Consumer-aligned', 'Operational', '03', 'Head of Advisor Workforce', 'FN-73', ['FN-60', 'FN-61', 'FN-67']),
    ('DP-390', 'Incentive Plan Governance & Advisor Payouts', 'Consumer-aligned', 'Regulatory & Control', '03', 'Head of Sales Compensation', 'FN-73', ['FN-68', 'FN-41', 'FN-38', 'FN-44']),
    ('DP-391', 'Supervisory Structure & Principal Coverage', 'Consumer-aligned', 'Regulatory & Control', '03', 'Head of Retail Supervision', 'FN-68', ['FN-73', 'FN-44', 'FN-41']),
    ('DP-393', 'Channel Referrals & Advice Hand-Offs', 'Consumer-aligned', 'Analytical', '03', 'Head of Advisor Workforce', 'FN-73', ['FN-71', 'FN-60', 'FN-61', 'FN-76', 'FN-77']),
    ('DP-392', 'Acquisition Funnel & Account Opening Conversion', 'Consumer-aligned', 'Analytical', '04', 'Head of Marketing', 'FN-76', ['FN-61', 'FN-62', 'FN-77', 'FN-38']),
    ('DP-394', 'Digital Engagement & Experiments', 'Consumer-aligned', 'Analytical', '04', 'Head of Digital', 'FN-61', ['FN-76', 'FN-50', 'FN-67', 'FN-51']),
    ('DP-395', 'Nudges & Recommendation Determinations', 'Consumer-aligned', 'Regulatory & Control', '04', 'Head of Digital Advice', 'FN-61', ['FN-68', 'FN-60', 'FN-76']),
    ('DP-396', 'Promotions & Client Referral Rewards', 'Consumer-aligned', 'Operational', '04', 'Head of Marketing', 'FN-76', ['FN-66', 'FN-72', 'FN-67', 'FN-68']),
    ('DP-397', 'Voice of Client: Surveys & NPS', 'Consumer-aligned', 'Analytical', '04', 'Head of Digital', 'FN-61', ['FN-67', 'FN-68', 'FN-73', 'FN-76', 'FN-37']),
    ('DP-410', 'Campaign Performance & Spend', 'Consumer-aligned', 'Analytical', '04', 'Head of Marketing Operations', 'FN-76', ['FN-38', 'FN-77']),
    ('DP-411', 'Content Performance', 'Consumer-aligned', 'Analytical', '04', 'Head of Content Strategy', 'FN-76', ['FN-61', 'FN-68', 'FN-78']),
    ('DP-412', 'Marketing Audiences, Subscriptions & Tracking Consent', 'Consumer-aligned', 'Operational', '04', 'Head of Marketing Operations', 'FN-76', ['FN-62', 'FN-61']),
    ('DP-413', 'Social Media & Brand Performance', 'Consumer-aligned', 'Analytical', '04', 'Head of Digital Marketing', 'FN-76', ['FN-47', 'FN-68']),
    ('DP-398', 'Principal Review Queue & Supervisory Approvals', 'Consumer-aligned', 'Operational', '08', 'Head of Retail Supervision', 'FN-68', ['FN-60', 'FN-61', 'FN-62', 'FN-71']),
    ('DP-399', 'Form CRS & Reg BI Disclosure Delivery Control', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Conduct', 'FN-68', ['FN-62', 'FN-67', 'FN-44', 'FN-72']),
    ('DP-400', 'Sales Practice Surveillance & Corrective Action', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Supervision', 'FN-68', ['FN-60', 'FN-64', 'FN-63', 'FN-73', 'FN-44']),
    ('DP-401', 'Options & Margin Approval Oversight', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Supervision', 'FN-68', ['FN-62', 'FN-65', 'FN-64']),
    ('DP-402', 'Supervisory Controls, Branch Inspections & Findings', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Supervision', 'FN-68', ['FN-44', 'FN-43', 'FN-42', 'FN-73']),
    ('DP-403', 'Senior Investor Case Management & Rule 2165 Holds', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Conduct', 'FN-68', ['FN-66', 'FN-67', 'FN-62', 'FN-60']),
    ('DP-404', 'Retail Conduct Risk Indicators', 'Consumer-aligned', 'Analytical', '08', 'Head of Retail Conduct', 'FN-68', ['FN-42', 'FN-44', 'FN-73', 'FN-37']),
    ('DP-414', 'Complaints & Rule 4530 Reporting', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Complaints & Conduct', 'FN-68', ['FN-67', 'FN-37', 'FN-73', 'FN-44']),
    ('DP-415', 'Marketing Rule Performance Substantiation', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Advertising Review', 'FN-68', ['FN-31', 'FN-76', 'FN-78']),
    ('DP-416', 'Frequent Trading & Market Timing Surveillance', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Supervision', 'FN-68', ['FN-35', 'FN-36', 'FN-74']),
    ('DP-405', 'Contact Center Operations', 'Consumer-aligned', 'Operational', '13', 'Head of Client Service', 'FN-67', ['FN-61', 'FN-41', 'FN-38', 'FN-68']),
    ('DP-406', 'Service Request Fulfillment & Good-Order Quality', 'Consumer-aligned', 'Operational', '13', 'Head of Client Service', 'FN-67', ['FN-62', 'FN-65', 'FN-66', 'FN-71']),
    ('DP-407', 'Statements & Trade Confirmation Delivery', 'Consumer-aligned', 'Regulatory & Control', '13', 'Head of Client Communications', 'FN-67', ['FN-64', 'FN-65', 'FN-68', 'FN-63']),
    ('DP-408', 'Proxy Solicitation, Pass-Through & Voting Choice', 'Consumer-aligned', 'Operational', '13', 'Head of Client Communications', 'FN-67', ['FN-24', 'FN-35', 'FN-36', 'FN-65']),
    ('DP-409', 'Servicing Errors & Client Remediation', 'Consumer-aligned', 'Regulatory & Control', '13', 'Head of Client Service', 'FN-67', ['FN-42', 'FN-68', 'FN-33', 'FN-72']),
    ('DP-417', 'Client Tax Forms & Cost Basis Reporting', 'Consumer-aligned', 'Regulatory & Control', '13', 'Head of Client Communications', 'FN-67', ['FN-65', 'FN-39', 'FN-62', 'FN-76']),
    ('DP-418', 'Escheatment, Dormancy & Lost Client Monitoring', 'Consumer-aligned', 'Regulatory & Control', '13', 'Head of Client Service', 'FN-67', ['FN-35', 'FN-65', 'FN-66', 'FN-38', 'FN-44']),
]
WAVE_WP1C['INV'] = [
    ('DP-531', 'CMA & Model Lineup Governance and Lineup Drift', 'Consumer-aligned', 'Regulatory & Control', '24', 'Chief Investment Officer', 'FN-21', ['FN-70', 'FN-63', 'FN-60', 'FN-68', 'FN-42']),
    ('DP-535', 'Manager Search, Selection & Due Diligence', 'Consumer-aligned', 'Operational', '52', 'Head of Manager Research', 'FN-70', ['FN-21', 'FN-75', 'FN-69', 'FN-44']),
    ('DP-536', 'Sub-Adviser Oversight Scorecard', 'Consumer-aligned', 'Regulatory & Control', '52', 'Head of Manager Research', 'FN-70', ['FN-31', 'FN-30', 'FN-32', 'FN-36', 'FN-21', 'FN-75']),
    ('DP-537', 'Sub-Adviser Guidelines, Certifications & Findings', 'Consumer-aligned', 'Regulatory & Control', '52', 'Head of Manager Research', 'FN-70', ['FN-32', 'FN-36', 'FN-44', 'FN-24']),
    ('DP-538', 'Sub-Adviser Hires, Terminations & Section 15(c) Renewal Evidence', 'Consumer-aligned', 'Regulatory & Control', '52', 'Head of Manager Research', 'FN-70', ['FN-36', 'FN-35', 'FN-45', 'FN-21']),
    ('DP-539', 'Third-Party Product Due Diligence & Approved Lists', 'Consumer-aligned', 'Regulatory & Control', '52', 'Head of Manager Research', 'FN-70', ['FN-78', 'FN-60', 'FN-61', 'FN-68', 'FN-71', 'FN-74', 'FN-21']),
    ('DP-540', 'OCIO & Trust Delegated Manager Oversight', 'Consumer-aligned', 'Analytical', '52', 'Head of Manager Research', 'FN-70', ['FN-75', 'FN-69', 'FN-31']),
    ('DP-541', 'Investor Choice Proxy Voting Program', 'Consumer-aligned', 'Regulatory & Control', '34', 'Head of Stewardship', 'FN-24', ['FN-35', 'FN-36', 'FN-67', 'FN-61']),
    ('DP-544', 'Trade Rotation & Cross-Book Allocation Fairness', 'Consumer-aligned', 'Regulatory & Control', '25', 'Head of Trading', 'FN-23', ['FN-63', 'FN-64', 'FN-32', 'FN-44', 'FN-74']),
]
WAVE_WP1C['IOP'] = [
    ('DP-532', 'Household & Account Performance View', 'Consumer-aligned', 'Analytical', '32', 'Head of Performance Measurement', 'FN-31', ['FN-61', 'FN-60', 'FN-67', 'FN-73', 'FN-69', 'FN-71']),
    ('DP-533', 'Personal Return Exceptions, Suppression & Restatements', 'Consumer-aligned', 'Regulatory & Control', '32', 'Head of Performance Measurement', 'FN-31', ['FN-65', 'FN-28', 'FN-67', 'FN-72']),
    ('DP-534', 'Managed Account Program Performance & Dispersion', 'Consumer-aligned', 'Analytical', '32', 'Head of Performance Measurement', 'FN-31', ['FN-63', 'FN-61', 'FN-21', 'FN-68']),
    ('DP-542', 'Institutional Mandate Guidelines & IPS Compliance', 'Consumer-aligned', 'Regulatory & Control', '33', 'Head of Investment Compliance', 'FN-32', ['FN-75', 'FN-21', 'FN-31']),
    ('DP-543', 'Client-Held Instrument Pricing Coverage', 'Consumer-aligned', 'Regulatory & Control', '22', 'Head of Pricing and Valuation', 'FN-28', ['FN-65', 'FN-67', 'FN-31']),
]
WAVE_WP1C['FOP'] = [
    ('DP-582', 'Omnibus Aggregation, Forward-Pricing & Settlement Evidence', 'Consumer-aligned', 'Regulatory & Control', '29', 'Head of Transfer Agency', 'FN-35', ['FN-64', 'FN-68', 'FN-33', 'FN-44']),
    ('DP-583', 'Shareholder Account Holds & Rule 2165 Restrictions', 'Consumer-aligned', 'Regulatory & Control', '29', 'Head of Transfer Agency', 'FN-35', ['FN-68', 'FN-66', 'FN-44', 'FN-62']),
    ('DP-585', 'Intermediary Shareholder Requests: Rule 22c-2 and Beneficial Owner Distribution', 'Consumer-aligned', 'Operational', '29', 'Head of Transfer Agency', 'FN-35', ['FN-74', 'FN-68', 'FN-67', 'FN-36']),
    ('DP-586', 'Fund Fee Accrual Assurance', 'Consumer-aligned', 'Regulatory & Control', '27', 'Fund Treasurer', 'FN-33', ['FN-36', 'FN-78', 'FN-38', 'FN-35']),
    ('DP-587', 'Fund Share State Notice Filings & Sales by State', 'Consumer-aligned', 'Regulatory & Control', '35', 'Head of Fund Regulatory Reporting', 'FN-36', ['FN-78', 'FN-35', 'FN-38']),
    ('DP-588', 'Fund Distribution Payment & Reinvestment Posting Control', 'Consumer-aligned', 'Regulatory & Control', '29', 'Head of Transfer Agency', 'FN-35', ['FN-33', 'FN-65', 'FN-67']),
]
WAVE_WP1C['BWO'] = [
    ('DP-435', 'Order Lifecycle & CAT Completeness', 'Consumer-aligned', 'Regulatory & Control', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-68', 'FN-44', 'FN-65']),
    ('DP-436', 'Execution Quality & Routing (605/606)', 'Consumer-aligned', 'Regulatory & Control', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-68', 'FN-44', 'FN-67']),
    ('DP-437', 'Trade Corrections & Errors', 'Consumer-aligned', 'Regulatory & Control', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-65', 'FN-68', 'FN-42']),
    ('DP-438', 'Trade Confirmations & Regulatory Trade Reporting', 'Consumer-aligned', 'Regulatory & Control', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-67', 'FN-68', 'FN-72']),
    ('DP-439', 'Order-Time Eligibility & Market Access Controls', 'Consumer-aligned', 'Regulatory & Control', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-68', 'FN-65', 'FN-62']),
    ('DP-440', 'Brokerage Activity by Product & Session', 'Consumer-aligned', 'Analytical', '48', 'Head of Brokerage Trading', 'FN-64', ['FN-78', 'FN-61', 'FN-77']),
    ('DP-441', 'Option Exercise & Assignment Operations', 'Consumer-aligned', 'Operational', '48', 'Head of Brokerage Operations', 'FN-65', ['FN-64', 'FN-67']),
    ('DP-445', 'Customer Reserve & Possession-and-Control Control Pack', 'Consumer-aligned', 'Regulatory & Control', '49', 'Financial and Operations Principal', 'FN-65', ['FN-40', 'FN-44', 'FN-38']),
    ('DP-446', 'Stock Record Reconciliation & Security Counts', 'Consumer-aligned', 'Regulatory & Control', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-35', 'FN-66', 'FN-38']),
    ('DP-447', 'Client Settlement & Fails', 'Consumer-aligned', 'Operational', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-64', 'FN-35', 'FN-40']),
    ('DP-448', 'ACATS In and Out', 'Consumer-aligned', 'Operational', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-77', 'FN-62', 'FN-67', 'FN-60']),
    ('DP-449', 'Cost Basis & Form 1099-B Readiness', 'Consumer-aligned', 'Regulatory & Control', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-67', 'FN-63', 'FN-39']),
    ('DP-450', 'Margin Calls & Margin Exposure', 'Consumer-aligned', 'Operational', '49', 'Head of Margin & Credit', 'FN-65', ['FN-40', 'FN-42', 'FN-68']),
    ('DP-451', 'Fully Paid Securities Lending Program', 'Consumer-aligned', 'Regulatory & Control', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-40', 'FN-44', 'FN-72']),
    ('DP-452', 'Client Corporate Action Entitlements & Elections', 'Consumer-aligned', 'Operational', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-67', 'FN-63']),
    ('DP-453', 'Brokerage Operations Daily Control Dashboard', 'Consumer-aligned', 'Analytical', '49', 'Head of Brokerage Operations', 'FN-65', ['FN-64', 'FN-66', 'FN-42']),
    ('DP-455', 'ACH, Wire & Check Operations and Returns', 'Consumer-aligned', 'Operational', '50', 'Head of Money Movement', 'FN-66', ['FN-67', 'FN-65', 'FN-62']),
    ('DP-456', 'Fraud & Elder-Exploitation Holds', 'Consumer-aligned', 'Regulatory & Control', '50', 'Head of Money Movement', 'FN-66', ['FN-68', 'FN-44', 'FN-67']),
    ('DP-457', 'Cash Sweep & Program Bank Allocation', 'Consumer-aligned', 'Analytical', '50', 'Head of Cash Programs', 'FN-66', ['FN-40', 'FN-72', 'FN-78', 'FN-38']),
    ('DP-458', 'FDIC Pass-Through Coverage', 'Consumer-aligned', 'Regulatory & Control', '50', 'Head of Cash Programs', 'FN-66', ['FN-67', 'FN-44', 'FN-62']),
    ('DP-459', 'Debit Card, Checkwriting & Regulation E Disputes', 'Consumer-aligned', 'Operational', '50', 'Head of Money Movement', 'FN-66', ['FN-67', 'FN-68']),
    ('DP-460', 'Money Movement AML Monitoring & Payment Sanctions Screening', 'Consumer-aligned', 'Regulatory & Control', '50', 'Head of Money Movement', 'FN-66', ['FN-44']),
    ('DP-461', 'Client Cash Forecast', 'Consumer-aligned', 'Analytical', '50', 'Head of Cash Programs', 'FN-66', ['FN-40']),
    ('DP-462', 'Account Funding & Money-In Journey', 'Consumer-aligned', 'Analytical', '50', 'Head of Money Movement', 'FN-66', ['FN-62', 'FN-76', 'FN-61']),
    ('DP-465', 'Plan Sponsor Reporting Data', 'Consumer-aligned', 'Analytical', '16', 'Head of Workplace Plan Sponsor Services', 'FN-71', ['FN-19', 'FN-75', 'FN-72']),
    ('DP-466', 'Participant Outcomes', 'Consumer-aligned', 'Analytical', '16', 'Head of Workplace Participant Services', 'FN-71', ['FN-19', 'FN-60', 'FN-61']),
    ('DP-467', 'Rollover Capture', 'Consumer-aligned', 'Analytical', '16', 'Head of Workplace Participant Services', 'FN-71', ['FN-60', 'FN-77', 'FN-68']),
    ('DP-468', 'Participant Managed Account Program', 'Consumer-aligned', 'Analytical', '16', 'Head of Workplace Participant Services', 'FN-71', ['FN-63', 'FN-19', 'FN-72']),
    ('DP-469', 'Plan Conversion & Fund Change Tracker', 'Consumer-aligned', 'Operational', '16', 'Head of Retirement Plan Services', 'FN-19', ['FN-71', 'FN-35']),
    ('DP-470', 'Required Minimum Distribution Readiness', 'Consumer-aligned', 'Operational', '16', 'Head of Workplace Participant Services', 'FN-71', ['FN-62', 'FN-67', 'FN-19']),
]
WAVE_WP1C['DIS'] = [
    ('DP-482', 'Intermediary Partner Scorecard', 'Consumer-aligned', 'Analytical', '05', 'Head of Intermediary Distribution', 'FN-74', ['FN-77', 'FN-12', 'FN-78']),
    ('DP-483', 'Intermediary Advisor Coverage & Engagement', 'Consumer-aligned', 'Operational', '05', 'Head of Intermediary Distribution', 'FN-74', ['FN-77', 'FN-76']),
    ('DP-484', 'Platform Shelf & Share Class Placement', 'Consumer-aligned', 'Analytical', '05', 'Head of Intermediary Distribution', 'FN-74', ['FN-78', 'FN-77']),
    ('DP-485', 'Model Delivery & Sponsor Program Assets', 'Consumer-aligned', 'Operational', '05', 'Head of Intermediary Distribution', 'FN-74', ['FN-22', 'FN-78', 'FN-12']),
    ('DP-486', 'Intermediary Oversight: Due Diligence, Obligations & Payment Disclosure', 'Consumer-aligned', 'Regulatory & Control', '05', 'Head of Intermediary Distribution Operations', 'FN-74', ['FN-44', 'FN-45', 'FN-12']),
    ('DP-487', 'Intermediary Payments, Sub-Accounting & Platform Fees', 'Consumer-aligned', 'Operational', '10', 'Head of Client Economics & Profitability', 'FN-12', ['FN-74', 'FN-38', 'FN-35']),
    ('DP-488', 'Institutional & Plan Sponsor Pipeline', 'Consumer-aligned', 'Analytical', '05', 'Head of Institutional Advisory Sales', 'FN-75', ['FN-71', 'FN-74', 'FN-16']),
    ('DP-489', 'Consultant Relations, Databases & RFP Performance', 'Consumer-aligned', 'Operational', '05', 'Head of Institutional Advisory Sales', 'FN-75', ['FN-16', 'FN-78']),
    ('DP-490', 'Client Assets & Flows Executive Scorecard', 'Consumer-aligned', 'Analytical', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-79', 'FN-12', 'FN-16', 'FN-38', 'FN-78']),
    ('DP-491', 'Net New Assets by Channel, Offering & Advisor', 'Consumer-aligned', 'Analytical', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-73', 'FN-74', 'FN-75', 'FN-71', 'FN-78']),
    ('DP-492', 'Net New Assets by Campaign & Acquisition Cohort', 'Consumer-aligned', 'Analytical', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-76', 'FN-12']),
    ('DP-493', 'Intermediary Channel Flows', 'Consumer-aligned', 'Analytical', '06', 'Head of Client & Channel Analytics', 'FN-74', ['FN-77', 'FN-78', 'FN-16']),
    ('DP-494', 'Intermediary Look-Through & Sub-Accounting Reconciliation', 'Consumer-aligned', 'Regulatory & Control', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-35', 'FN-74', 'FN-68']),
    ('DP-495', 'Client Asset Data Supply Chain, Reconciliation & Suspense', 'Consumer-aligned', 'Regulatory & Control', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-50', 'FN-74', 'FN-65']),
    ('DP-496', 'Client Asset Mix & Own-Fund Penetration', 'Consumer-aligned', 'Analytical', '06', 'Head of Client & Channel Analytics', 'FN-78', ['FN-77', 'FN-70', 'FN-37']),
    ('DP-497', 'Client Revenue Yield by Stream, Offering & Segment', 'Consumer-aligned', 'Analytical', '10', 'Head of Client Economics & Profitability', 'FN-12', ['FN-72', 'FN-78', 'FN-38', 'FN-77']),
    ('DP-498', 'Cost to Serve & Client Lifetime Value', 'Consumer-aligned', 'Analytical', '10', 'Head of Client Economics & Profitability', 'FN-12', ['FN-76', 'FN-77', 'FN-78', 'FN-38', 'FN-73']),
    ('DP-499', 'Client, Offering & Advisor Profitability', 'Consumer-aligned', 'Analytical', '10', 'Head of Client Economics & Profitability', 'FN-12', ['FN-73', 'FN-78', 'FN-38', 'FN-74']),
    ('DP-500', 'Pricing Scenarios & Repricing Impact', 'Consumer-aligned', 'Analytical', '10', 'Head of Client Pricing', 'FN-72', ['FN-78', 'FN-12', 'FN-37', 'FN-16']),
    ('DP-501', 'Cash Sweep & Program Bank Economics', 'Consumer-aligned', 'Analytical', '10', 'Head of Client Economics & Profitability', 'FN-12', ['FN-66', 'FN-72', 'FN-40', 'FN-44']),
    ('DP-502', 'Net New Assets & Revenue Forecast vs Plan', 'Consumer-aligned', 'Analytical', '10', 'Head of FP&A', 'FN-38', ['FN-12', 'FN-77', 'FN-74', 'FN-75']),
    ('DP-503', 'Intercompany Charges & Transfer Pricing', 'Consumer-aligned', 'Regulatory & Control', '10', 'Head of Client Economics & Profitability', 'FN-38', ['FN-39', 'FN-12']),
    ('DP-504', 'Capitalized Contract Costs', 'Consumer-aligned', 'Regulatory & Control', '10', 'Finance Controller', 'FN-38', ['FN-12', 'FN-73']),
    ('DP-505', 'Industry Flows, Market Share & Sizing', 'Consumer-aligned', 'Analytical', '11', 'Head of Market Intelligence', 'FN-16', ['FN-77', 'FN-78', 'FN-38']),
    ('DP-506', 'Competitive Pricing & Fee Benchmarks', 'Consumer-aligned', 'Analytical', '11', 'Head of Market Intelligence', 'FN-16', ['FN-72', 'FN-78', 'FN-37']),
    ('DP-507', 'Own-Fund Peer Rankings & Ratings', 'Consumer-aligned', 'Analytical', '11', 'Head of Market Intelligence', 'FN-16', ['FN-78', 'FN-70', 'FN-37']),
    ('DP-508', 'Competitor & Market Watch', 'Consumer-aligned', 'Analytical', '11', 'Head of Market Intelligence', 'FN-16', ['FN-78', 'FN-75', 'FN-37']),
    ('DP-509', 'Regulatory Horizon & Change Watch', 'Consumer-aligned', 'Regulatory & Control', '11', 'Head of Market Intelligence', 'FN-16', ['FN-44', 'FN-68', 'FN-37', 'FN-72']),
    ('DP-510', 'Institutional Relationship Health & Service', 'Consumer-aligned', 'Analytical', '12', 'Head of Institutional Client Service', 'FN-75', ['FN-71', 'FN-72', 'FN-12']),
    ('DP-511', 'Institutional & OCIO Client Reporting Delivery', 'Consumer-aligned', 'Regulatory & Control', '12', 'Head of Client Reporting', 'FN-75', ['FN-31', 'FN-71']),
    ('DP-512', 'OCIO Policy, Allocation & Manager Line-Up', 'Consumer-aligned', 'Analytical', '12', 'Head of Institutional Advisory', 'FN-75', ['FN-21', 'FN-70', 'FN-31']),
    ('DP-513', 'Mandate Onboarding & Cash Flow Readiness', 'Consumer-aligned', 'Operational', '12', 'Head of Institutional Operations', 'FN-75', ['FN-62', 'FN-29', 'FN-32']),
    ('DP-514', 'Plan Sponsor Servicing & Plan Reviews', 'Consumer-aligned', 'Operational', '12', 'Head of Institutional Client Service', 'FN-71', ['FN-75', 'FN-19']),
]
WAVE_WP1C['CORP'] = [
    ('DP-592', 'Employee Brokerage Accounts & Personal Trading Coverage', 'Consumer-aligned', 'Regulatory & Control', '38', 'Chief Compliance Officer', 'FN-44', ['FN-41', 'FN-65', 'FN-64']),
    ('DP-593', 'Government Client Pay-to-Play Exposure', 'Consumer-aligned', 'Regulatory & Control', '38', 'Chief Compliance Officer', 'FN-44', ['FN-75', 'FN-71', 'FN-73']),
    ('DP-595', 'Client Data Safeguards: Reg S-P, Reg S-ID & Customer Notification', 'Consumer-aligned', 'Regulatory & Control', '41', 'Chief Information Security Officer', 'FN-51', ['FN-44', 'FN-62', 'FN-46', 'FN-42']),
    ('DP-598', 'Client Revenue Recognition & Ledger Tie-Out', 'Consumer-aligned', 'Regulatory & Control', '19', 'Finance Controller', 'FN-38', ['FN-72', 'FN-39', 'FN-66']),
    ('DP-600', 'Customer Reserve Funding & Program Bank Exposure', 'Consumer-aligned', 'Operational', '43', 'Group Treasurer', 'FN-40', ['FN-65', 'FN-66', 'FN-42', 'FN-38']),
    ('DP-602', 'Client-Impacting Incidents & Remediation', 'Consumer-aligned', 'Regulatory & Control', '37', 'Head of Operational Risk', 'FN-42', ['FN-67', 'FN-65', 'FN-64', 'FN-35', 'FN-33']),
    ('DP-603', 'Customer Financing Funding: Margin Debits, Stock Loan & Bank Lines', 'Consumer-aligned', 'Analytical', '43', 'Group Treasurer', 'FN-40', ['FN-65', 'FN-42', 'FN-38']),
    ('DP-604', 'Fidelity Bond & Excess SIPC Coverage Adequacy', 'Consumer-aligned', 'Regulatory & Control', '43', 'Group Treasurer', 'FN-40', ['FN-36', 'FN-65', 'FN-42']),
]
WAVE_WP1C['FDN'] = [
    ('DP-515', 'Reference Data & Code List Governance', 'Consumer-aligned', 'Regulatory & Control', '09', 'Enterprise Reference Data Lead', 'FN-49', ['FN-50', 'FN-51']),
    ('DP-516', 'Retail Tradable Instrument Coverage & Eligibility', 'Consumer-aligned', 'Regulatory & Control', '17', 'Head of Enterprise Data Management', 'FN-49', ['FN-64', 'FN-78', 'FN-65']),
    ('DP-517', 'Records Retention Schedule Coverage', 'Consumer-aligned', 'Regulatory & Control', '21', 'Head of Data Governance', 'FN-50', ['FN-44', 'FN-45', 'FN-68', 'FN-51']),
    ('DP-518', 'Personal Data Tiers & Restricted-View Register', 'Consumer-aligned', 'Regulatory & Control', '21', 'Chief Data Officer', 'FN-50', ['FN-44', 'FN-62', 'FN-68']),
    ('DP-519', 'Third-Party Data Entitlements, Usage & Cost', 'Consumer-aligned', 'Regulatory & Control', '14', 'Head of Market Data & Licensing', 'FN-17', ['FN-50', 'FN-38', 'FN-46']),
    ('DP-520', 'Client Market Data Entitlements & Exchange Reporting', 'Consumer-aligned', 'Regulatory & Control', '14', 'Head of Market Data & Licensing', 'FN-17', ['FN-61', 'FN-64', 'FN-38']),
    ('DP-521', 'Index Licensing Fees', 'Consumer-aligned', 'Regulatory & Control', '14', 'Head of Market Data & Licensing', 'FN-17', ['FN-78', 'FN-38', 'FN-33']),
    ('DP-522', 'Data Vendor Risk & Renewals', 'Consumer-aligned', 'Regulatory & Control', '14', 'Head of Market Data & Licensing', 'FN-17', ['FN-46', 'FN-42', 'FN-38']),
]
# WP1 scope (WP0 rationalization, 2026-10-15; program-lead ruling; Product_Briefs/WP1_Scope.md). WP1 specifies the 17
# foundational products, the re-scoped existing products (WP1_RESCOPED) and the consumer candidates left in WAVE_WP1C;
# the other consumer candidates move to the registered Backlog wave: they keep their id and register row in PRODUCTS,
# carry the status "backlog" (is_backlog), are not specified at WP1, and no WP1 product may depend on them. Selection,
# in order: the plan section 8.5 acceptance questions and their direct inputs, the section 8.3 named examples, the
# certified-metric chains (CW-011), the regulatory controls with a rule by number, one product per operation, and the
# re-point targets of live products; tailoring levers last or to backlog. WAVE_BACKLOG_MERGES names the product each
# backlog candidate overlaps (its scope folds in there if it is picked up; None = stands alone). Objects with CDEs read
# only by a backlog candidate are read by a WP1 product instead (the proposals modules' WP1_MOVED_READS). Lead ruling
# 2026-10-15: DP-321 (Rule 4512 trusted contact) and DP-332 (Rule 3a-4) pulled back into WP1.
WAVE_BACKLOG_MERGES = {
    "DP-323": "DP-334", "DP-325": "DP-320", "DP-326": "DP-490", "DP-327": "DP-392",
    "DP-328": "DP-399", "DP-330": "DP-417", "DP-331": None, "DP-336": "DP-337", "DP-338": "DP-320",
    "DP-339": "DP-385", "DP-340": "DP-387", "DP-343": "DP-342", "DP-344": "DP-341", "DP-347": "DP-346",
    "DP-348": "DP-349", "DP-386": "DP-383", "DP-388": "DP-387", "DP-389": "DP-387", "DP-395": "DP-394",
    "DP-396": "DP-392", "DP-397": "DP-405", "DP-401": "DP-398", "DP-406": "DP-405", "DP-407": "DP-382",
    "DP-411": "DP-410", "DP-413": "DP-410", "DP-415": "DP-036", "DP-416": "DP-585", "DP-417": None,
    "DP-439": "DP-435", "DP-440": None, "DP-441": "DP-452", "DP-449": "DP-417", "DP-450": None, "DP-451": None,
    "DP-453": "DP-445", "DP-455": None, "DP-458": "DP-457", "DP-461": "DP-457", "DP-462": "DP-392",
    "DP-465": "DP-514", "DP-468": "DP-466", "DP-469": "DP-514", "DP-470": "DP-329", "DP-482": "DP-505",
    "DP-483": "DP-491", "DP-484": "DP-005", "DP-485": "DP-493", "DP-489": "DP-488", "DP-494": "DP-487",
    "DP-500": "DP-497", "DP-501": "DP-497", "DP-502": "DP-490", "DP-504": "DP-598", "DP-507": "DP-506",
    "DP-508": "DP-505", "DP-509": None, "DP-512": None, "DP-513": "DP-510", "DP-517": None, "DP-520": "DP-044",
    "DP-521": "DP-044", "DP-522": "DP-044",
    "DP-519": "DP-044",   # WP1 lineage (lead ruling): DP-519 merged into the re-scoped DP-044; backlog, not specified
    "DP-534": "DP-345", "DP-537": "DP-536", "DP-539": "DP-535",
    "DP-540": "DP-536", "DP-541": "DP-408", "DP-542": None, "DP-543": "DP-516", "DP-582": None, "DP-587": None,
    "DP-592": "DP-225", "DP-593": None, "DP-602": "DP-215", "DP-603": "DP-600", "DP-604": None,
}
WP1_BACKLOG = set(WAVE_BACKLOG_MERGES)
WAVE_BACKLOG = {a: [p for p in WAVE_WP1C[a] if p[0] in WP1_BACKLOG] for a in WEALTH_AREAS}   # by area, register rows
for _a in WEALTH_AREAS:
    WAVE_WP1C[_a] = [p for p in WAVE_WP1C[_a] if p[0] not in WP1_BACKLOG]
assert sum(len(v) for v in WAVE_BACKLOG.values()) == len(WP1_BACKLOG), "a backlog id is not a registered WP1C candidate"
BACKLOG_WAVE = "Wave Backlog"
PRODUCTS += WAVE_WP1F + [p for a in WEALTH_AREAS for p in WAVE_WP1C[a]] + [p for a in WEALTH_AREAS for p in WAVE_BACKLOG[a]]
# Topics of the WP0 candidates: each resolves to its owning domain's topic in the W5 re-cut (checked at the WP0 integration:
# brokerage T10, advice, managed accounts and trust T19, conduct T13, and so on); three are read where a reader looks for them.
PRODUCT_TOPIC.update({"DP-509": "T13",                   # regulatory horizon (11) sits with compliance and regulatory affairs
                      "DP-503": "T14", "DP-504": "T14"})  # intercompany charges and capitalized contract costs (10) are the firm's books
IN_PROGRESS |= {"Wave WP1F"} | {f"Wave WP1C {a}" for a in WEALTH_AREAS}
for _p in WAVE_WP1F:
    WAVE[_p[0]] = "Wave WP1F"
for _a, _ps in WAVE_WP1C.items():
    for _p in _ps:
        WAVE[_p[0]] = f"Wave WP1C {_a}"
IN_PROGRESS |= {BACKLOG_WAVE}             # registered, not specified (dp_model accepts a missing spec)
for _ps in WAVE_BACKLOG.values():
    for _p in _ps:
        WAVE[_p[0]] = BACKLOG_WAVE


def is_backlog(pid):
    """True for a consumer candidate moved to the Backlog wave (WP1_Scope.md): registered, not specified at WP1."""
    return pid in WP1_BACKLOG

# New product id blocks (CW-002, CW-201). Retired ids are never reused. Each brief draws its new ids from its block only;
# re-scoped products keep their ids. The framing block holds the new foundational products of section 8.2.
ID_BLOCKS = {
    "FRAMING": {"range": ("DP-300", "DP-319"), "domains": [], "brief": "WP0_Framing.md (proposals_wp0_framing.py)",
                "decisions": ("CW-200", "CW-209")},
    "CLA-A": {"range": ("DP-320", "DP-379"), "domains": ["02", "15", "45", "46", "47", "51"], "brief": "Client & Advice A"},
    "CLA-B": {"range": ("DP-380", "DP-429"), "domains": ["01", "36", "03", "04", "13", "08"], "brief": "Client & Advice B"},
    "BWO": {"range": ("DP-430", "DP-479"), "domains": ["48", "49", "50", "16"], "brief": "Brokerage & Workplace Operations"},
    "DIS+FDN": {"range": ("DP-480", "DP-529"), "domains": ["05", "06", "10", "11", "12", "09", "17", "21", "14"],
                "brief": "Distribution, Channels & Client Economics; Foundations"},
    "INV+IOP": {"range": ("DP-530", "DP-579"), "domains": ["23", "24", "25", "34", "52", "18", "22", "26", "31", "32", "33"],
                "brief": "Investment; Investment Operations"},
    "FOP+CORP": {"range": ("DP-580", "DP-639"),
                 "domains": ["27", "28", "29", "35", "19", "20", "37", "38", "39", "40", "41", "42", "43", "44"],
                 "brief": "Fund Operations; Corporate Functions"},
}
DECISION_BLOCKS = {"FRAMING": ("CW-200", "CW-209"), "BRIEFS": ("CW-210", "CW-269"), "WP2": ("CW-270", "CW-279")}   # the briefs take blocks of ten; WP2 close CW-270 onward


def id_block_of(pid):
    """The ID_BLOCKS key whose range holds a DP- id, or None (an id below DP-300 is an existing or retired product)."""
    n = int(pid[3:])
    for k, b in ID_BLOCKS.items():
        if int(b["range"][0][3:]) <= n <= int(b["range"][1][3:]):
            return k
    return None


# Retired products (WP0; CW-207 executes CW-930 and the framing rulings): {id: retiring decision}. The ids are never
# reused. The register row stays; the specs and logical models were deleted at the WP1 integration (DP-002, DP-244,
# DP-156, DP-175 and the private-markets seven) and in the WP2 retirement sweep (the 66 WP0 dispositions, DP-040, DP-064
# and DP-065 among them); dp_model.py would still validate a retired spec left in a specs module,
# build_review_pack.py leaves them out, and the builders and check_baseline.py skip them. The WP0 integration adds the superseded and retired pending products below
# (WP0_DISPOSITIONS) and takes them out of RESCOPE_PENDING.
RETIRED_PRODUCTS = {
    # Private markets left with 30 (CW-930); the residual inputs pass to DP-093 (15 Alternative Investment Subscription),
    # 52 product due diligence (INV+IOP brief), 31 leverage (DP-146), 22 fair value (DP-149) and 18 fund interests (DP-142).
    "DP-116": "CW-930", "DP-117": "CW-930", "DP-136": "CW-930", "DP-137": "CW-930", "DP-138": "CW-930",
    "DP-139": "CW-930", "DP-160": "CW-930",
    # Framing rulings (CW-207): EU / UK products with no US successor, and two products absorbed by their neighbors.
    "DP-040": "CW-207", "DP-064": "CW-207", "DP-065": "CW-207", "DP-175": "CW-207", "DP-156": "CW-207",
    # Merged into a re-scoped neighbor; live dependents re-point at the WP1 integration before the row goes:
    "DP-002": "CW-202",     # into DP-001 Intermediary Partner Master (re-scoped in place)
    "DP-244": "CW-206",     # into DIS+FDN DP-498 Cost to Serve & Client Lifetime Value (lead ruling 2026-10-15)
}


def is_retired(pid):
    return pid in RETIRED_PRODUCTS


# --- WP0 integration (2026-10-15; WP0_Integration_Notes.md): the dispositions of the 79 products pending re-scope -----
# One row per product of the W1 pending register (CW-041), reconciled across the seven WP0 modules (consolidation/
# proposals_wp0_framing.py and proposals_wdp_*.py). (id, disposition, successor ids or None, decision, ruling brief).
# Disposition: "re-scope in place" (the id stays in RESCOPE_PENDING until WP1 rewrites its spec), "superseded" (retired;
# the named new id takes the purpose), "retired" (no successor, or only residual homes named). One rule (lead,
# 2026-10-15): re-scope in place only when a live product depends on the id; DP-080, DP-095 and DP-096 are re-scoped in
# place by explicit lead ruling. Superseded and retired products join RETIRED_PRODUCTS; their rows stay so history and
# ids resolve (their specs and models were deleted in the WP2 retirement sweep), and the live products that listed them
# were re-pointed at WP1.
RESCOPE_PENDING_W1 = dict(RESCOPE_PENDING)          # the W1 register as it stood (79 products), kept for history
WP0_DISPOSITIONS = [
    ('DP-015', 'superseded', 'DP-490', 'CW-240', 'DIS+FDN'),
    ('DP-016', 'retired', None, 'CW-207', 'Framing'),
    ('DP-017', 'superseded', 'DP-483', 'CW-220', 'CLA-B'),
    ('DP-018', 'superseded', 'DP-483', 'CW-220', 'CLA-B'),
    ('DP-019', 'superseded', 'DP-488', 'CW-220', 'CLA-B'),
    ('DP-020', 'superseded', 'DP-482', 'CW-240', 'DIS+FDN'),
    ('DP-021', 'superseded', 'DP-484', 'CW-240', 'DIS+FDN'),
    ('DP-022', 'superseded', 'DP-489', 'CW-220', 'CLA-B'),
    ('DP-023', 'superseded', 'DP-489', 'CW-220', 'CLA-B'),
    ('DP-024', 'retired', 'DP-493, DP-488', 'CW-139, CW-240', 'DIS+FDN'),
    ('DP-025', 'superseded', 'DP-410, DP-492', 'CW-220', 'CLA-B'),
    ('DP-026', 'superseded', 'DP-411', 'CW-220', 'CLA-B'),
    ('DP-027', 'superseded', 'DP-392', 'CW-220', 'CLA-B'),
    ('DP-028', 'superseded', 'DP-412, DP-324', 'CW-220', 'CLA-B'),
    ('DP-029', 'superseded', 'DP-496, DP-493', 'CW-240', 'DIS+FDN'),
    ('DP-030', 'superseded', 'DP-506, DP-507', 'CW-160, CW-240', 'DIS+FDN'),
    ('DP-031', 'superseded', 'DP-505', 'CW-160, CW-240', 'DIS+FDN'),
    ('DP-032', 'superseded', 'DP-390', 'CW-207', 'Framing'),
    ('DP-033', 'superseded', 'DP-390', 'CW-207', 'Framing'),
    ('DP-034', 'superseded', 'DP-487', 'CW-136, CW-240', 'DIS+FDN'),
    ('DP-035', 'superseded', 'DP-499', 'CW-159, CW-243, CW-240', 'DIS+FDN'),
    ('DP-036', 're-scope in place', 'DP-036', 'CW-220', 'CLA-B'),
    ('DP-037', 'superseded', 'DP-486', 'CW-220', 'CLA-B'),
    ('DP-038', 're-scope in place', 'DP-038', 'CW-220', 'CLA-B'),
    ('DP-039', 're-scope in place', 'DP-039', 'CW-220', 'CLA-B'),
    ('DP-040', 'retired', 'DP-109, DP-385', 'CW-207', 'Framing'),
    ('DP-041', 'retired', None, 'CW-220', 'CLA-B'),
    ('DP-042', 'superseded', 'DP-510', 'CW-145, CW-240', 'DIS+FDN'),
    ('DP-043', 'superseded', 'DP-405, DP-409', 'CW-220', 'CLA-B'),
    ('DP-044', 're-scope in place', 'DP-044', 'CW-914, CW-240', 'DIS+FDN'),   # WP1: lead WP0 ruling; DP-519 merged into it
    ('DP-045', 'superseded', 'DP-495', 'CW-144, CW-240', 'DIS+FDN'),
    ('DP-046', 'superseded', 'DP-340', 'CW-220', 'CLA-B'),
    ('DP-047', 'retired', 'DP-483', 'CW-245', 'DIS+FDN'),
    ('DP-048', 'retired', None, 'CW-210', 'CLA-A'),
    ('DP-049', 'retired', 'DP-482', 'CW-160, CW-245', 'DIS+FDN'),
    ('DP-050', 'superseded', 'DP-485', 'CW-137, CW-240', 'DIS+FDN'),
    ('DP-051', 'superseded', 'DP-410', 'CW-220', 'CLA-B'),
    ('DP-052', 'superseded', 'DP-394', 'CW-220', 'CLA-B'),
    ('DP-053', 'retired', None, 'CW-220', 'CLA-B'),
    ('DP-054', 'retired', None, 'CW-207', 'Framing'),
    ('DP-055', 'superseded', 'DP-502', 'CW-240', 'DIS+FDN'),
    ('DP-056', 'retired', 'DP-502, DP-194', 'CW-240', 'DIS+FDN'),
    ('DP-057', 'retired', None, 'CW-207', 'Framing'),
    ('DP-058', 'superseded', 'DP-383, DP-107', 'CW-220', 'CLA-B'),
    ('DP-059', 'superseded', 'DP-500, DP-506, DP-183', 'CW-220', 'CLA-B'),
    ('DP-060', 'superseded', 'DP-400', 'CW-220', 'CLA-B'),
    ('DP-061', 'superseded', 'DP-414', 'CW-220', 'CLA-B'),
    ('DP-062', 'superseded', 'DP-415', 'CW-220', 'CLA-B'),
    ('DP-063', 'superseded', 'DP-486', 'CW-136, CW-240', 'DIS+FDN'),
    ('DP-064', 'retired', None, 'CW-207', 'Framing'),
    ('DP-065', 'retired', None, 'CW-207', 'Framing'),
    ('DP-066', 'retired', None, 'CW-210', 'CLA-A'),
    ('DP-067', 'retired', 'DP-350', 'CW-054, CW-246', 'DIS+FDN'),
    ('DP-068', 'superseded', 'DP-511', 'CW-912, CW-240', 'DIS+FDN'),
    ('DP-069', 're-scope in place', 'DP-069', 'CW-220', 'CLA-B'),
    ('DP-070', 'superseded', 'DP-418', 'CW-220', 'CLA-B'),
    ('DP-071', 'superseded', 'DP-408', 'CW-220', 'CLA-B'),
    ('DP-072', 'superseded', 'DP-521', 'CW-914, CW-240', 'DIS+FDN'),
    ('DP-073', 'superseded', 'DP-522', 'CW-914, CW-240', 'DIS+FDN'),
    ('DP-074', 'superseded', 'DP-503', 'CW-910, CW-240', 'DIS+FDN'),
    ('DP-076', 'superseded', 'DP-494', 'CW-240, CW-906', 'DIS+FDN'),
    ('DP-077', 're-scope in place', 'DP-077', 'CW-210', 'CLA-A'),
    ('DP-078', 're-scope in place', 'DP-078', 'CW-220', 'CLA-B'),
    ('DP-079', 're-scope in place', 'DP-079', 'CW-220', 'CLA-B'),
    ('DP-080', 're-scope in place', 'DP-080', 'CW-210', 'CLA-A'),
    ('DP-081', 'superseded', 'DP-486', 'CW-131, CW-135, CW-240', 'DIS+FDN'),
    ('DP-082', 'superseded', 'DP-390', 'CW-207', 'Framing'),
    ('DP-083', 're-scope in place', 'DP-083', 'CW-260', 'FOP+CORP'),
    ('DP-084', 'superseded', 'DP-416', 'CW-220', 'CLA-B'),
    ('DP-085', 're-scope in place', 'DP-085', 'CW-220', 'CLA-B'),
    ('DP-086', 'superseded', 'DP-513', 'CW-145, CW-240', 'DIS+FDN'),
    ('DP-087', 'retired', None, 'CW-220', 'CLA-B'),
    ('DP-088', 'superseded', 'DP-508', 'CW-160, CW-240', 'DIS+FDN'),
    ('DP-089', 'superseded', 'DP-504', 'CW-240', 'DIS+FDN'),
    ('DP-090', 'superseded', 'DP-413', 'CW-220', 'CLA-B'),
    ('DP-091', 'superseded', 'DP-417', 'CW-220', 'CLA-B'),
    ('DP-092', 'retired', 'DP-243, DP-510', 'CW-220', 'CLA-B'),
    ('DP-095', 're-scope in place', 'DP-095', 'CW-233', 'BWO'),
    ('DP-096', 're-scope in place', 'DP-096', 'CW-233', 'BWO'),
]
RESCOPE_OPEN = {d[0]: d[3] for d in WP0_DISPOSITIONS if d[1] == "re-scope in place"}   # the 12 still to re-scope at WP1
# WP1 lineage pass: re-scoped products whose WP1 specs have landed (old wholesale entries deleted) leave the hold-back.
WP1_RESCOPE_SPECIFIED = {"DP-083",            # specs_w1c_fop_corp.py (C-4)
                         "DP-095", "DP-096",   # specs_w1c_bwo.py (C-3)
                         "DP-044", "DP-130",   # specs_w1c_inv_iop_fdn.py (C-6)
                         "DP-036", "DP-038", "DP-039", "DP-069", "DP-078", "DP-079", "DP-085",   # specs_w1c_cla_b.py (C-2)
                         "DP-077", "DP-080"}   # specs_w1c_cla_a.py (C-1)
RESCOPE_OPEN = {k: v for k, v in RESCOPE_OPEN.items() if k not in WP1_RESCOPE_SPECIFIED}
RETIRED_PRODUCTS.update({d[0]: d[3] for d in WP0_DISPOSITIONS if d[1] in ("superseded", "retired")})
# RESCOPE_PENDING is RESCOPE_OPEN, now empty: every re-scope in place has its WP1 spec (WP1_RESCOPE_SPECIFIED). Until WP2
# the 66 superseded and retired wholesale consumer products were also held here, so that dm_model.py and sm_model.py held
# back their wholesale specs and models (which read removed objects). The WP2 retirement sweep deleted those specs and
# logical models (and the semantic models SM-01 to SM-07 and SM-13), so the hold-back was emptied: the 66 ids stay in
# RETIRED_PRODUCTS with their retiring decisions (WP0_DISPOSITIONS) and RETIRED_SUCCESSOR, and RESCOPE_PENDING_W1 keeps
# the W1 register for history. The readers (dp_model, dm_model, sm_model, candidate_coverage and the builders) take an
# empty register.
RESCOPE_PENDING = dict(RESCOPE_OPEN)
RETIRED_SUCCESSOR = {d[0]: d[2] for d in WP0_DISPOSITIONS if d[1] in ("superseded", "retired")}
RETIRED_SUCCESSOR.update({"DP-116": "DP-093", "DP-117": "DP-142", "DP-136": "DP-093", "DP-137": "DP-539",
                          "DP-138": "DP-149", "DP-139": "DP-146", "DP-160": "DP-145", "DP-175": "DP-172",
                          "DP-156": "DP-004, DP-146", "DP-002": "DP-001", "DP-244": "DP-498"})

# Existing products re-scoped in place at WP1 (id kept): {id: (WP1 wave code, ruling brief)}. Their register rows carry
# the WP0 name, owning domain, owner and functions (WP0_ROWS below); their specs are rewritten in that wave. WAVE keeps
# the product's original wave label (a pending product must stay a Waves 1 to 4 product until WP1 re-specifies it).
WP1_RESCOPED = {
    'DP-001': ('WP1F', 'Framing'),
    'DP-003': ('WP1F', 'Framing'),
    'DP-004': ('WP1F', 'Framing'),
    'DP-005': ('WP1F', 'Framing'),
    'DP-006': ('WP1F', 'Framing'),
    'DP-007': ('WP1F', 'Framing'),
    'DP-008': ('WP1F', 'Framing'),
    'DP-012': ('WP1F', 'Framing'),
    'DP-036': ('WP1C_CLA', 'CLA-B'),
    'DP-038': ('WP1C_CLA', 'CLA-B'),
    'DP-039': ('WP1C_CLA', 'CLA-B'),
    'DP-069': ('WP1C_CLA', 'CLA-B'),
    'DP-077': ('WP1C_CLA', 'CLA-A'),
    'DP-078': ('WP1C_CLA', 'CLA-B'),
    'DP-079': ('WP1C_CLA', 'CLA-B'),
    'DP-080': ('WP1C_CLA', 'CLA-A'),
    'DP-083': ('WP1C_CORP', 'FOP+CORP'),
    'DP-085': ('WP1C_CLA', 'CLA-B'),
    'DP-093': ('WP1F', 'Framing'),
    'DP-095': ('WP1C_BWO', 'BWO'),
    'DP-096': ('WP1C_BWO', 'BWO'),
    'DP-109': ('WP1C_CLA', 'Framing'),
    'DP-130': ('WP1C_INV', 'Framing'),
    'DP-044': ('WP1C_FDN', 'DIS+FDN'),   # WP1: re-scoped in place (lead WP0 ruling; DP-519 merged)
    'DP-199': ('WP1C_CORP', 'Framing'),
    'DP-217': ('WP1C_CORP', 'Framing'),
    'DP-228': ('WP1C_CORP', 'Framing'),
    'DP-240': ('WP1F', 'Framing'),
    'DP-241': ('WP1C_FOP', 'Framing'),
    'DP-243': ('WP1C_DIS', 'Framing'),
}
# Re-scopes deferred to the backlog (WP1_Scope.md, lever): the product stays live on its current spec; its WP0 re-scope
# is not specified at WP1. DP-135 (voluntary climate reporting, plan lever) keeps its Wave E2 specification.
RESCOPE_BACKLOG = {'DP-135': ('WP1C_INV', 'Framing')}
# Register rows of the re-scoped candidates as the WP0 briefs drew them (name, tier, type, owning domain, owner role,
# primary and supporting functions); applied to PRODUCTS here, specs follow at WP1 (WP0_Framing.md section 9 step 5).
WP0_ROWS = {
    'DP-001': ('DP-001', 'Intermediary Partner Master', 'Foundational', 'Master & Reference', '05', 'Head of Intermediary Distribution', 'FN-74', ['FN-75', 'FN-73', 'FN-12', 'FN-77', 'FN-68']),
    'DP-003': ('DP-003', 'Institutional, Consultant & Plan Relationships', 'Foundational', 'Master & Reference', '12', 'Head of Institutional Client Service', 'FN-75', ['FN-71', 'FN-19', 'FN-74', 'FN-72']),
    'DP-004': ('DP-004', 'Product, Offering & Share Class Reference', 'Foundational', 'Master & Reference', '01', 'Head of Product Data', 'FN-78', ['FN-37', 'FN-60', 'FN-61', 'FN-63', 'FN-64', 'FN-72', 'FN-74', 'FN-68']),
    'DP-005': ('DP-005', 'Intermediary Agreements & Platform Placement', 'Foundational', 'Master & Reference', '05', 'Head of Intermediary Distribution', 'FN-74', ['FN-12', 'FN-68', 'FN-78', 'FN-22']),
    'DP-006': ('DP-006', 'Client Flow Transactions', 'Foundational', 'Conformed Facts', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-12', 'FN-74', 'FN-73', 'FN-76', 'FN-71']),
    'DP-007': ('DP-007', 'Client Asset Positions', 'Foundational', 'Conformed Facts', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-12', 'FN-74', 'FN-75', 'FN-33', 'FN-71']),
    'DP-008': ('DP-008', 'Client Assets & Net New Assets', 'Foundational', 'Conformed Facts', '06', 'Head of Client & Channel Analytics', 'FN-77', ['FN-79', 'FN-12', 'FN-73', 'FN-74', 'FN-75', 'FN-76', 'FN-78', 'FN-16']),
    'DP-012': ('DP-012', 'Client Fee Revenue', 'Foundational', 'Conformed Facts', '10', 'Head of Client Revenue Finance', 'FN-12', ['FN-79', 'FN-72', 'FN-78', 'FN-38', 'FN-74', 'FN-33']),
    'DP-036': ('DP-036', 'Communications Review & FINRA Filing', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Advertising Review', 'FN-68', ['FN-76', 'FN-78', 'FN-47']),
    'DP-038': ('DP-038', 'Gifts & Non-Cash Compensation', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Retail Conduct', 'FN-68', ['FN-44', 'FN-74', 'FN-38']),
    'DP-039': ('DP-039', 'Representative Registrations, Licensing & CE', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Registration & Licensing', 'FN-68', ['FN-41', 'FN-73', 'FN-44']),
    'DP-069': ('DP-069', 'Client Communications Delivery, Householding & Cost', 'Consumer-aligned', 'Analytical', '13', 'Head of Client Communications', 'FN-67', ['FN-35', 'FN-38', 'FN-76']),
    'DP-077': ('DP-077', 'Client Eligibility, KYC & Restrictions Status', 'Consumer-aligned', 'Regulatory & Control', '02', 'Head of Client Onboarding', 'FN-62', ['FN-68', 'FN-44', 'FN-76', 'FN-61', 'FN-63', 'FN-66']),
    'DP-078': ('DP-078', 'Communications Capture & Surveillance', 'Consumer-aligned', 'Regulatory & Control', '08', 'Head of Compliance Surveillance', 'FN-68', ['FN-44', 'FN-73', 'FN-51']),
    'DP-079': ('DP-079', 'Fund Dealing & Operational Reference', 'Consumer-aligned', 'Operational', '01', 'Head of Product Data', 'FN-78', ['FN-35', 'FN-74', 'FN-64']),
    'DP-080': ('DP-080', 'Consumer Privacy Rights & Opt-Out Evidence', 'Consumer-aligned', 'Regulatory & Control', '02', 'Privacy Officer', 'FN-44', ['FN-76', 'FN-50', 'FN-62']),
    'DP-085': ('DP-085', 'Account Maintenance, Authentication & Takeover Monitoring', 'Consumer-aligned', 'Regulatory & Control', '13', 'Head of Client Service', 'FN-67', ['FN-66', 'FN-68', 'FN-51', 'FN-44']),
    'DP-093': ('DP-093', 'Account Master', 'Foundational', 'Master & Reference', '15', 'Head of Account Data', 'FN-62', ['FN-60', 'FN-63', 'FN-64', 'FN-65', 'FN-66', 'FN-67', 'FN-72', 'FN-71', 'FN-19', 'FN-15']),
    'DP-240': ('DP-240', 'Client, Household & Party Master', 'Foundational', 'Master & Reference', '02', 'Head of Client Data', 'FN-62', ['FN-49', 'FN-60', 'FN-61', 'FN-67', 'FN-68', 'FN-73', 'FN-77', 'FN-23', 'FN-44', 'FN-46']),
    'DP-241': ('DP-241', 'Firm AUM & Client Assets Reconciliation', 'Consumer-aligned', 'Analytical', '27', 'Head of Fund Accounting', 'FN-33', ['FN-63', 'FN-77', 'FN-79', 'FN-12', 'FN-27', 'FN-50']),
    'DP-243': ('DP-243', 'Total Client Relationship', 'Consumer-aligned', 'Analytical', '12', 'Head of Institutional Client Service', 'FN-75', ['FN-71', 'FN-74', 'FN-79', 'FN-72']),
}
PRODUCTS[:] = [WP0_ROWS.get(p[0], p) for p in PRODUCTS]


def wp1_wave(pid):
    """The WP1 wave code of a registered candidate or a re-scoped product (WP1F or WP1C_<area>), else None (also for
    a backlog candidate or a re-scope deferred to the backlog)."""
    if pid in WP1_RESCOPED:
        return WP1_RESCOPED[pid][0]
    if pid in WP1_BACKLOG or pid in RESCOPE_BACKLOG:
        return None                                   # backlog: not specified at WP1
    w = WAVE.get(pid, "")
    return "WP1F" if w == "Wave WP1F" else ("WP1C_" + w.split()[-1] if w.startswith("Wave WP1C") else None)

# Identified backlog: named and defined, not yet specified at attribute level. Same tuple shape as WAVE_2.
BACKLOG = []

DELIVERY = ["Warehouse table", "BI semantic model", "Dashboard", "CRM embed", "API", "File extract", "Event stream",
            "Reverse ETL to CRM", "Regulatory report"]
CLASSIFICATIONS = ['Public', 'Internal', 'Confidential', 'Confidential - Personal Data', 'Confidential - Client',
                   'Confidential - Financial', 'Confidential - Compensation', 'Confidential - Licensed', 'Restricted',
                   'Restricted - Personal Data', 'Restricted - MNPI', 'Restricted - Commercial Terms', 'Restricted - Legal']
REFRESH = ['Real-Time', 'Intraday', 'Daily', 'Weekly', 'Fortnightly', 'Monthly', 'Quarterly', 'Semi-Annual', 'Annual',
           'On Event', 'Ad Hoc']
