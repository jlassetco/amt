"""Data product specifications: formerly the wholesale reference example (DP-008). DP-008 is re-specified at WP1 in
specs_w1f_certified.py, which CONTRACT.md now names as the worked example; this module holds no spec. See CONTRACT.md."""

SPECS = {
    # DP-008 re-specified at WP1 in specs_w1f_certified.py (the CONTRACT.md worked example now points there, lead ruling 2026-10-16)
}
