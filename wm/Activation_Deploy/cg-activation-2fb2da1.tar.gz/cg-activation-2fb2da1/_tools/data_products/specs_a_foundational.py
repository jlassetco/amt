"""Data product specifications: foundational masters and conformed facts (DP-001 to DP-007). DP-001, DP-003, DP-004,
DP-005, DP-006 and DP-007 are re-specified at WP1 (specs_w1f_channels.py, specs_w1f_client.py, specs_w1f_certified.py);
DP-002 is retired into DP-001 (CW-202). See CONTRACT.md."""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    # DP-001 re-specified at WP1 in specs_w1f_channels.py
    # ------------------------------------------------------------------------------------------------------------------
    # DP-002 retired into DP-001 (CW-202); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-003 re-specified at WP1 in specs_w1f_channels.py
    # ------------------------------------------------------------------------------------------------------------------
    # DP-004 re-specified at WP1 in specs_w1f_client.py
    # ------------------------------------------------------------------------------------------------------------------
    # DP-005 re-specified at WP1 in specs_w1f_channels.py
    # ------------------------------------------------------------------------------------------------------------------
    # DP-006 re-specified at WP1 in specs_w1f_certified.py
    # ------------------------------------------------------------------------------------------------------------------
    # DP-007 re-specified at WP1 in specs_w1f_certified.py
}
