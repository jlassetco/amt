"""Data product specifications: foundational products DP-009 to DP-011, DP-013 and DP-014.
DP-012 is re-specified at WP1 in specs_w1f_certified.py. See CONTRACT.md."""

# DP-015 retired at WP0 (CW-240, successor DP-490; framework.RETIRED_PRODUCTS); its spec was deleted in the WP2 retirement sweep.
SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-009": dict(
        definition=("The conformed advisor organization and coverage master: every advisor with their advisor roles, coverage "
                    "teams and memberships, the coverage models the teams follow, the assignment rules, criteria and exception "
                    "rules that place households and clients with an advisor or team, who covers which party and account, and "
                    "the coverage reassignments between advisors, with full effective-dated history including org unit "
                    "assignments and reorganizations. It joins the HR employee record (20), the advisor profile and coverage "
                    "design (03), the client service tier (02) and registration (08) once, so that activity reporting, "
                    "scorecards, supervision and incentive compensation all resolve 'who covers whom' the same way."),
        business_questions=[
            "Who is the primary and secondary coverage (advisor and coverage team) for each household, client and account today, and who was it on any past date?",
            "Which households in a service tier have no active primary advisor, and which advisors are allocated above 100% across coverage teams?",
            "Which coverage teams exist and who is on each in which membership role, and which coverage model and roles does each team follow?",
            "Which households moved in each coverage reassignment and when did the change take effect, and which org units were merged, split or moved in each reorganization and how is history restated across it?",
            "Is every advisor who covers a client registered in the categories and states the coverage requires?",
            "Which assignment rule placed each household with its advisor or team, and which households are held by an exception rule, and until when?",
        ],
        grain="Advisor or coverage team x covered party or account x coverage role x effective period (with the advisor profile and coverage team as conformed dimensions)",
        dimensions=["Advisor (employee)", "Advisor role and producing indicator", "Coverage team and membership role",
                    "Coverage model", "Service tier", "Coverage role", "Covered party / household / account",
                    "Assignment rule and exception", "Coverage reassignment", "Org unit", "Reorganization event",
                    "Effective date"],
        measures=[
            ("Active Producing Advisors", "Count of distinct employees with Advisor Status = active, Employment Status = active and an open Advisor Role Assignment with Producing Indicator = Y on the as-of date.",
             [("03", "Advisor", "Advisor Status"), ("03", "Advisor Role Assignment", "Producing Indicator"),
              ("20", "Employee", "Employment Status")]),
            ("Allocation Check", "Sum of Capacity Allocation Percentage over an advisor's Coverage Team Memberships open on the as-of date; flagged when above 100%.",
             [("03", "Coverage Team Membership", "Capacity Allocation Percentage"),
              ("03", "Coverage Team Membership", "Member Advisor"),
              ("03", "Coverage Team Membership", "Membership Effective To")]),
            ("Uncovered Tiered Households", "Count of parties with a Service Tier Assignment open on the as-of date and no open Party Coverage Assignment with Primary Coverage Indicator = Y.",
             [("02", "Service Tier Assignment", "Tier Party"), ("02", "Service Tier Assignment", "Tier Effective From"),
              ("02", "Service Tier Assignment", "Tier Effective To"),
              ("03", "Party Coverage Assignment", "Covered Party"),
              ("03", "Party Coverage Assignment", "Primary Coverage Indicator"),
              ("03", "Party Coverage Assignment", "Coverage Effective From"),
              ("03", "Party Coverage Assignment", "Coverage Effective To")]),
            ("Coverage Span", "Count of covered parties with Primary Coverage Indicator = Y per covering advisor, by the party's assigned service tier.",
             [("03", "Party Coverage Assignment", "Primary Coverage Indicator"),
              ("03", "Party Coverage Assignment", "Covering Advisor"),
              ("02", "Service Tier Assignment", "Assigned Service Tier")]),
            ("Registration Gap Flag", "Y when the covering advisor of an open Party Coverage Assignment has no Individual Registration with Registration Status = active in a required registration category on the as-of date (and, where the assignment rule has Registered-State Check Indicator = Y, in the client's state).",
             [("03", "Party Coverage Assignment", "Covering Advisor"),
              ("03", "Coverage Assignment Rule", "Registered-State Check Indicator"),
              ("08", "Individual Registration", "Registered Person"),
              ("08", "Individual Registration", "Registration Category"),
              ("08", "Individual Registration", "Registration Jurisdiction"),
              ("08", "Individual Registration", "Registration Status")]),
            ("Rule-Based Assignment Share", "Primary Party Coverage Assignments on the as-of date with a Source Assignment Rule / all primary assignments; the remainder are exceptions, referrals or manual assignments.",
             [("03", "Party Coverage Assignment", "Source Assignment Rule"),
              ("03", "Party Coverage Assignment", "Primary Coverage Indicator")]),
            ("Active Assignment Exceptions", "Count of Coverage Assignment Rule rows of an exception Assignment Rule Type that are open on the as-of date (Rule Effective To null or later), by Assignment Rule Type and Target Coverage Team.",
             [("03", "Coverage Assignment Rule", "Rule Effective To"),
              ("03", "Coverage Assignment Rule", "Target Coverage Team"),
              ("03", "Coverage Assignment Rule", "Assignment Rule Type")]),
            ("Expiring Exceptions (30 Days)", "Count of exception Coverage Assignment Rule rows with Rule Effective To within the next 30 days.",
             [("03", "Coverage Assignment Rule", "Rule Effective To"),
              ("03", "Coverage Assignment Rule", "Assignment Rule Type")]),
            ("Coverage Team Size", "Count of distinct Member Advisor per Member Coverage Team with a membership open on the as-of date.",
             [("03", "Coverage Team Membership", "Member Coverage Team"),
              ("03", "Coverage Team Membership", "Member Advisor")]),
            ("Reorganization-Affected Advisors", "Count of advisors whose Org Unit Assignment changes on a Reorganization Effective Date, per Reorganization ID.",
             [("09", "Reorganization Event", "Reorganization Effective Date"),
              ("09", "Reorganization Event", "Reorganization ID")]),
        ],
        inputs=[
            ("20", "Employee", ["Employee ID", "Preferred Name", "Legal Last Name", "Business Email Address", "Job Title",
                                "Employing Legal Entity", "Home Org Unit", "Work Location", "Employment Status", "Hire Date",
                                "Termination Date"]),
            ("20", "Employee Reporting Line", ["Reporting Employee", "Line Manager", "Reporting Line Type",
                                               "Reporting Effective From", "Reporting Effective To"]),
            ("03", "Advisor", ["Employee", "Advisor Status", "Client-Facing Title", "Advice Channels Offered",
                               "Advisor Business Lines", "Entities Represented"]),
            ("03", "Advisor Role Assignment", ["Role Advisor", "Advisor Role", "Primary Role Indicator", "Producing Indicator",
                                               "Role Effective From", "Role Effective To"]),
            ("03", "Coverage Team", ["Coverage Team ID", "Coverage Team Name", "Coverage Team Type", "Lead Advisor",
                                     "Team Office", "Parent Coverage Team", "Team Status", "Team Effective From",
                                     "Team Effective To"]),
            ("03", "Coverage Team Membership", ["Member Coverage Team", "Member Advisor", "Membership Role",
                                                "Capacity Allocation Percentage", "Membership Effective From",
                                                "Membership Effective To"]),
            ("03", "Coverage Model", ["Coverage Model Code", "Delivery Mode", "Coverage Roles Included",
                                      "Service Tiers Covered", "Coverage Model Status"]),
            ("03", "Coverage Assignment Rule", ["Assignment Rule ID", "Assignment Rule Type", "Target Coverage Team",
                                                "Target Advisor", "Excepted Party", "Rule Precedence", "Boolean Filter",
                                                "Registered-State Check Indicator", "Rule Status", "Rule Effective From",
                                                "Rule Effective To"]),
            ("03", "Coverage Assignment Rule Criterion", ["Criterion Sequence", "Criterion Field", "Criterion Operator",
                                                          "Criterion Value", "Criterion Geographic Group"]),
            ("03", "Party Coverage Assignment", ["Coverage Assignment ID", "Covered Party", "Covered Account",
                                                 "Covering Advisor", "Covering Coverage Team", "Party Coverage Role",
                                                 "Primary Coverage Indicator", "Assignment Basis", "Source Assignment Rule",
                                                 "Coverage Effective From", "Coverage Effective To",
                                                 "Relationship Start Date"]),
            ("03", "Coverage Reassignment", ["Reassignment ID", "Reassignment Reason", "From Advisor", "To Advisor",
                                             "Reassignment Effective Date", "Reassignment Status"]),
            ("02", "Service Tier Assignment", ["Tier Party", "Assigned Service Tier", "Tier Effective From",
                                               "Tier Effective To"]),
            ("08", "Individual Registration", ["License ID", "Registered Person", "Registration Category", "Registration Jurisdiction",
                                               "Registration Status", "Registration Effective Date"]),
            ("20", "Org Unit Assignment", ["Assigned Employee", "Assigned Org Unit", "Assignment Effective From / To"]),
            ("09", "Reorganization Event", ["Reorganization ID", "Reorganization Type", "Reorganization Effective Date",
                                            "Source Org Units", "Target Org Units", "History Restatement Rule"]),
        ],
        upstream=["DP-013", "DP-192"],   # DP-192 Employee & Position Master, Wave E1 (CD-342)
        refresh="Daily",
        timeliness="By 7am ET on T+1; HR changes reflected within one business day of the HR effective date",
        history="SCD type 2 on every assignment, rule, role and membership since 2015; coverage models and assignment rules kept by version indefinitely",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Reverse ETL to CRM"],
        dq_rules=[
            "Every Advisor resolves to exactly one Employee with an Employee ID, and an advisor with Employment Status = terminated has no Party Coverage Assignment or Coverage Team Membership effective after the Termination Date.",
            "Capacity Allocation Percentage over an advisor's open Coverage Team Memberships sums to no more than 100% on any date.",
            "No covered scope (account, client or household) has more than one Primary Coverage Indicator = Y per Party Coverage Role on any date, and the account row takes precedence over the client row and the client row over the household row; effective periods for the same advisor, role, membership or assignment do not overlap, and Effective To is on or after Effective From.",
            "Every Source Assignment Rule on a Party Coverage Assignment resolves to an Assignment Rule ID effective on the assignment date, and every Coverage Assignment Rule has at least one Coverage Assignment Rule Criterion or a Boolean Filter; every open exception rule names an Excepted Party and an active Target Coverage Team or Target Advisor.",
            "Every Criterion Geographic Group resolves to an active Geographic Unit in DP-013, and every Assigned Service Tier and Service Tiers Covered value to an active 01 service tier.",
            "Every Coverage Reassignment with Reassignment Status = completed has a From Advisor or From Coverage Team and a To Advisor or To Coverage Team, and its Reassignment Effective Date is on or after the date it was approved.",
        ],
        notes=("Employee names, email and hire / termination dates are personal data (PII = Y); publish a pseudonymized view keyed on "
               "Employee ID for wide analytics use. Boundary: the HR employee record is mastered in 20 (CD-151) and published by DP-192 Employee & Position Master, from which this product takes it (CD-342); it is published here only "
               "for staff in an advisor role; DP-013 does not carry employees. Registration status is read from 08 Individual "
               "Registration (the master) rather than the 03 License & Registration Reference copy. Assignment rules, criteria "
               "and exception rules are published here as the in-force set. Org Unit Assignment and Reorganization Event are "
               "published only for staff in an advisor role. Intermediary partner coverage is 05 Partner Coverage Assignment "
               "(CW-132), not this product. "
               "W2 re-point (CW-062, CW-063; 03 re-point map and PK_CHANGES in proposals_w2_03.py): Sales Person is read as 03 "
               "Advisor (Sales Profile Status as Advisor Status), Sales Role as Advisor Role Assignment (Primary Sales Role, "
               "Secondary Sales Roles and Sales Function as Advisor Role; Client-Facing Title on Advisor), Sales Team and 07 "
               "Coverage Team as 03 Coverage Team (Team Leader as Lead Advisor, Parent Team as Parent Coverage Team), Team "
               "Membership & Channel Assignment and Sales Pairing & Alignment as Coverage Team Membership (a pairing is two "
               "membership rows of one team, the pairing type a Membership Role), 07 Coverage Model and Party Coverage "
               "Assignment as their 03 successors (Covering Salesperson as Covering Advisor), 07 Coverage Tier Assignment as "
               "02 Service Tier Assignment, 07 Alignment Rule, Alignment Rule Criterion and Alignment Exception as Coverage "
               "Assignment Rule and Coverage Assignment Rule Criterion (an exception is a rule of an exception type with its "
               "own effective period), and 07 Realignment Event as Coverage Reassignment. "
               "W2: Sales Person CRM User ID and Home Market, Sales Team Primary Channel and Sales Market, and Team Membership "
               "Assigned Channel dropped (system key; EU/UK markets; the intermediary channel moves to 05) (CW-062, CW-903). "
               "W2: Territory Model, Territory, Territory Hierarchy Node, Territory Geographic Unit, Territory Scope, Territory "
               "Type Definition, Party Territory Alignment, Territory Salesperson Assignment, Sales Cluster, Crediting Rule, "
               "Realignment Event Transition Credit Rule and Alignment Rule Aligned Party Level and Inherit to Child Parties "
               "Indicator dropped, no successor in the wealth 03 (no territories, distributor hierarchy or sales crediting in "
               "the wealth model; CW-013, CW-062, CW-064; 07 retired, CW-907); with them the measures Territory Coverage "
               "Completeness % and the territory forms of Allocation Check and Uncovered Aligned Parties (rewritten to coverage "
               "team allocation and tiered households), and the upstream DP-001 to DP-003 (intermediary parties are no longer "
               "covered here). W4: owner domain 03 (CW-080). "
               "WP0: 03 Advisor Capacity Snapshot now holds the advisor's household capacity, which closes the former capacity "
               "gap (Coverage Span is still derived); 03 Firm Branch Office, Principal Designation and Supervisory Assignment "
               "are candidates for the supervision view."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-010": dict(
        definition=("Every logged advisor interaction - meetings, calls, video calls, emails and client reviews - with its "
                    "internal and external participants, products and services discussed, content shared, outcome and capture "
                    "source. It conforms CRM, calendar-capture and conversation-capture records into one activity fact keyed to "
                    "the advisor and resolved party, so that coverage, productivity and compliance reporting count the same "
                    "interactions."),
        business_questions=[
            "How many qualifying meetings and calls did each advisor hold this month, and with which clients and households?",
            "Which products and topics were discussed most, by activity purpose, and what content was shared?",
            "Which activities have an external participant who could not be matched to a known party?",
            "Which recorded or archived interactions link to a gifts and entertainment record?",
        ],
        grain="Advisor activity x participant (internal or external) - the activity header is one row per Activity ID, with participant and product bridge tables",
        dimensions=["Activity date", "Activity type and interaction medium", "Activity purpose", "Advisor (activity owner and participants)",
                    "External party / household", "Product discussed", "Activity outcome", "Source system"],
        measures=[
            ("Completed Activities", "Count of distinct Activity ID with Activity Status = completed in the period.",
             [("03", "Advisor Activity", "Activity Status"), ("03", "Advisor Activity", "Activity ID")]),
            ("Qualifying Interactions", "Completed activities whose Activity Type is a Qualifying Activity Type in the Call Frequency Standard for the covered party's service tier.",
             [("03", "Call Frequency Standard", "Qualifying Activity Type"), ("03", "Advisor Activity", "Activity Type"),
              "Completed Activities"]),
            ("Unique Parties Reached", "Count of distinct matched External Participant with External Attendance Status = attended on completed activities.",
             [("03", "External Participant", "External Attendance Status"),
              ("03", "External Participant", "External Participant"),
              ("03", "Internal Participant", "Attendance Status"), "Completed Activities"]),
            ("Unmatched Participant Rate", "External participant rows with no External Participant party / all external participant rows.",
             [("03", "External Participant", "External Participant")]),
            ("Product Mentions", "Count of completed activities x Products Discussed, by product.",
             [("03", "Discussion Content", "Products Discussed"), "Completed Activities"]),
            ("Content Shares", "Count of completed activities x Content Assets Shared, by content asset.",
             [("03", "Discussion Content", "Content Assets Shared"), "Completed Activities"]),
        ],
        inputs=[
            ("03", "Advisor Activity", ["Activity ID", "Activity Type", "Interaction Medium", "Activity Purpose",
                                        "Activity Start Timestamp", "Activity End Timestamp", "Activity Status",
                                        "Activity Owner", "Activity Party", "Related Accounts", "Related Campaign",
                                        "Activity Classification"]),
            ("03", "Internal Participant", ["Internal Participant", "Internal Participant Role", "Attendance Status"]),
            ("03", "External Participant", ["External Participant", "External Participant Role",
                                            "External Attendance Status", "Unmatched Participant Email"]),
            ("03", "Discussion Content", ["Products Discussed", "Discussion Topics", "Meeting Notes", "Summary Generation Method",
                                          "Content Assets Shared", "Client Sentiment"]),
            ("03", "Outcome & Follow-Up", ["Activity Outcome", "Next Step", "Follow-Up Task"]),
            ("03", "Activity Capture", ["Activity Source System", "Capture Method", "Source Record ID", "Communication Archive Reference",
                                        "Recorded Communication Indicator", "Gifts & Entertainment Reference"]),
            ("03", "Call Frequency Standard", ["Standard Coverage Model", "Standard Service Tier", "Contact Type",
                                               "Qualifying Activity Type", "Required Interactions per Period",
                                               "Standard Period", "Standard Effective From"]),
        ],
        upstream=["DP-009", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for activities logged by end of the prior business day",
        history="All activities since 2015, with insert / update history retained for seven years to support books-and-records review",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every activity has an Activity ID, Activity Type, Activity Start Timestamp, Activity Status, Activity Owner and Activity Source System.",
            "Activity Owner resolves to an active advisor in DP-009 on the activity date, and Activity Party resolves to an active party.",
            "Activity End Timestamp is on or after Activity Start Timestamp, and completed activities are not dated in the future.",
            "Each source record (Activity Source System x Source Record ID) loads to exactly one Activity ID.",
            "At least 95% of external participants on completed meetings resolve to a party; the rest carry an Unmatched Participant Email.",
            "Recorded Communication Indicator = Y implies a Communication Archive Reference.",
        ],
        notes=("Meeting notes, participant identities, unmatched emails and research analyst names are personal data (PII = Y); "
               "Meeting Notes are excluded from the BI semantic model and available only through the warehouse table under "
               "CRM role-based access. Activity Classification must be honored on every delivery. Call Frequency Standard is read "
               "here only to flag qualifying interactions; coverage-frequency compliance is calculated in DP-016. "
               "W2 re-point (CW-062): Sales Activity is renamed Advisor Activity (Confidentiality Type read as Activity "
               "Classification) and 07 Call Frequency Standard moves to 03 (Standard Coverage Tier read as Standard Service "
               "Tier); Content Shares now counts Discussion Content Content Assets Shared. "
               "W2: Activity Subject, Activity Location Type, Activity Sales Channel, Activity Territory, Related Opportunity, "
               "Related Marketing Event and Related Sales Play, External Participant Participant Firm and External Attendee "
               "Count, Call Frequency Standard Standard Coverage Role, Consultant Research Review and Content Usage Event "
               "dropped, no successor in the wealth 03 (no territories, sales plays or intermediary channel; opportunities are "
               "05; seminar head counts are 04 registrations; consultant reviews are institutional, 05) (CW-062, CW-903); with "
               "them the consultant review question and the Territory and Sales channel dimensions, and the upstream DP-001 to "
               "DP-003."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-011": dict(
        definition=("The conformed record of how known and anonymous audiences engage with marketing: email deliveries and "
                    "interactions, web and portal engagement, media views, event registrations and attendance, "
                    "campaign membership and the touchpoints used for attribution. It resolves visitors and recipients to the "
                    "party master where consent allows, and ties each event to its campaign and content asset, so that campaign, "
                    "content, lead and sales hand-off products share one engagement history."),
        business_questions=[
            "Which clients and prospects engaged with our email, web, webinar and event content in the last 30 days, and on which products and topics?",
            "What are delivery, open, click and unsubscribe rates by campaign, email type and audience?",
            "How many registrants attended each event, and which advisor invited them?",
            "What share of digital engagement is identified to a known party, and under which tracking consent?",
            "Which touchpoints does each party have before an opportunity or flow, for attribution?",
        ],
        grain="Engagement event: party or visitor x engagement type x source object (email, page, asset, event, campaign) x event timestamp",
        dimensions=["Event date", "Engagement event type", "Marketing channel", "Campaign (program, campaign, wave)", "Content asset",
                    "Web page / product", "Marketing event", "Party (known) or visitor (anonymous)", "Identification status",
                    "Applied tracking consent"],
        measures=[
            ("Delivery Rate", "Email Interaction rows with Delivery Status = delivered / rows sent, by Email Send.",
             [("04", "Email Interaction", "Delivery Status")]),
            ("Unique Open Rate", "Delivered rows with a First Open Timestamp / delivered rows.",
             [("04", "Email Interaction", "First Open Timestamp")]),
            ("Click-Through Rate", "Delivered rows with a First Click Timestamp / delivered rows.",
             [("04", "Email Interaction", "First Click Timestamp")]),
            ("Unsubscribe Rate", "Delivered rows with an Unsubscribe Timestamp / delivered rows.",
             [("04", "Email Interaction", "Unsubscribe Timestamp")]),
            ("Event Attendance Rate", "Event Registration rows with Attended Indicator = Y / rows with Registration Status = registered.",
             [("04", "Event Registration", "Registration Status"), ("04", "Event Registration", "Attended Indicator")]),
            ("Identified Engagement Share", "Engagement events whose visitor has Identification Status = identified and a Matched Party / all engagement events.",
             [("04", "Web Visitor / Known User", "Identification Status"),
              ("04", "Web Visitor / Known User", "Matched Party")]),
            ("Media Completion Rate", "Media Engagement rows with Completion Indicator = Y / all media view rows.",
             [("04", "Media Engagement", "Completion Indicator")]),
        ],
        inputs=[
            ("04", "Campaign", ["Campaign ID", "Campaign Name", "Campaign Level", "Parent Campaign", "Campaign Type", "Campaign Status",
                                "Planned Start Date", "Planned End Date", "Marketing Theme"]),
            ("04", "Campaign Member", ["Member Party", "Member Lead", "Member Status", "Responded Indicator"]),
            ("04", "Content Asset", ["Asset ID", "Asset Title", "Content Type", "Parent / Source Asset"]),
            ("04", "Web Page", ["Page URL", "Page Type", "Page Product / Share Class", "Page Audience Restriction"]),
            ("04", "Web Visitor / Known User", ["Visitor ID", "Identity Namespace", "Identification Status", "Matched Party",
                                                "Match Method", "Applied Tracking Consent"]),
            ("04", "Session", ["Session ID", "Session Source / Medium", "Session Campaign"]),
            ("04", "Engagement Event", ["Event Timestamp", "Engagement Event Type", "Event Visitor / Party", "Event Content Asset"]),
            ("04", "Email Send", ["Email Template Asset", "Email Campaign", "Subject Line", "Email Send Type", "Email Subscription Topic"]),
            ("04", "Email Interaction", ["Recipient Party", "Delivery Status", "First Open Timestamp", "First Click Timestamp",
                                         "Unsubscribe Timestamp"]),
            ("04", "Media Engagement", ["Viewing Mode", "Percent Viewed", "Completion Indicator"]),
            ("04", "Marketing Event", ["Event ID", "Event Name", "Event Type", "Attendance Mode", "Event Status", "Event Start",
                                       "Event Country", "Owning Campaign", "Event Audience Restriction"]),
            ("04", "Event Registration", ["Registrant Party", "Registration Status", "Invited By Advisor", "Attended Indicator"]),
            ("04", "Marketing Touchpoint", ["Touchpoint Party", "Touchpoint Timestamp", "Touchpoint Type", "Touchpoint Campaign",
                                            "Source Event"]),
            ("02", "Consent Record", ["Consent Record ID", "Consent Purpose", "Consent Status", "Consent Captured Timestamp",
                                      "Consent Withdrawn Timestamp"]),
        ],
        upstream=["DP-240", "DP-004", "DP-013", "DP-009"],
        refresh="Daily",
        timeliness="By 8am ET on T+1; email and web events from the prior calendar day",
        history="Event-level detail kept 3 years (24 months for anonymous visitor events), aggregates kept since 2018; no restatement of past events",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Event stream", "Reverse ETL to CRM"],
        dq_rules=[
            "Every engagement event has an Event Timestamp, Engagement Event Type and a visitor or party; events with neither are rejected.",
            "A visitor is linked to a Matched Party only when Applied Tracking Consent permits identification for the visitor's jurisdiction.",
            "First Click Timestamp, when present, is on or after the send date of its Email Send; First Open Timestamp precedes or equals any later interaction.",
            "Attended Indicator = Y only for registrations with Registration Status = registered or walk-in.",
            "Parties with Consent Status = withdrawn have no identified engagement events after the Consent Withdrawn Timestamp.",
            "Every Email Send, Session Campaign and Touchpoint Campaign resolves to a Campaign ID.",
        ],
        notes=("Visitor, session and recipient identifiers are personal data (PII = Y). Consent is read from the 02 "
               "Consent Record master; 04 Applied Tracking Consent is the consent state applied at capture. Identified "
               "engagement must follow the CCPA / CPRA and state privacy opt-outs; the CRM feed excludes parties with Do Not Contact set in DP-240 (02 Privacy Profile). "
               "Social post metrics are post-level, not party-level, and are left to DP-025. Lead records stay in DP-027. "
               "Taxonomy gap: Email Interaction records only first open / first click; total opens and clicks are not modeled, so "
               "rates are unique-recipient rates. "
               "W2 re-point (CW-904): Event Registration Invited By Salesperson is renamed Invited By Advisor (the firm's own "
               "advisor, 03). W2: Campaign Member Added By Salesperson and CE Credit Issued dropped, no successor in the wealth "
               "04 (no wholesaler CE program) (CW-904); with them the CE credit question and quality rule clause."
               "WP1 re-point (CW-202): upstream DP-002 (retired into DP-001) replaced by DP-240, which masters the 02 Consent Record, Privacy Profile and the client parties that Matched Party, Recipient Party, Registrant Party and Touchpoint Party resolve to; no input or measure changes."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-012 re-specified at WP1 in specs_w1f_certified.py
    # ------------------------------------------------------------------------------------------------------------------
    "DP-013": dict(
        definition=("The enterprise reference data every distribution product joins to: countries and the geographic units and "
                    "hierarchies used for territories and reporting, business, dealing and fiscal calendars, reporting period "
                    "conventions, currencies, currency pair conventions and FX rate types and sources, languages, locales and "
                    "number and date conventions, units of measure, the firm's own legal entities with their LEIs, ownership "
                    "structure, regulatory authorizations and office locations, the internal organization, sub-national "
                    "geography (subdivisions, US counties, CBSAs and ZIP codes), industry "
                    "classification schemes with their concordances, and the registered code lists with source-system "
                    "mappings and change requests. It publishes one governed, "
                    "versioned copy so that every product uses the same codes and dates."),
        business_questions=[
            "Which geographic units (ZIP, county, CBSA) roll up to each state, country, sales region and US metro area, and which vintage applies?",
            "Is a given date a business day for a calendar, which fiscal period does it fall in, and is that period closed?",
            "Which internal legal entity is the employing, contracting or booking entity, what is its LEI and renewal status, which regulator authorizes it for which activities, who owns it, and when is its next annual filing due?",
            "How does each org unit roll up in the management hierarchy as of a given date?",
            "What is the approved code and label for a source-system value, is the mapping approved, and how does an industry code in one scheme (e.g. NAICS 2022) map to another (e.g. ISIC Rev. 4)?",
            "Which locale, language, date pattern and decimal separator should a client-facing output use for a given country?",
        ],
        grain="One row per reference member (country, geographic unit, calendar date, fiscal period, currency, legal entity, org unit, code value or code mapping) x effective period; published as a set of conformed reference tables",
        dimensions=["Reference entity type", "Effective date / version", "Country", "Country subdivision", "Geographic scheme and vintage",
                    "Geographic group", "Time zone", "Calendar", "Fiscal period", "Currency", "Currency pair", "Language", "Locale",
                    "Unit of measure", "Legal entity", "Regulator and authorization type", "Office location", "Org unit",
                    "Classification scheme and version", "Code list"],
        measures=[
            ("Business Day Indicator", "Y when Day Type = business day for the calendar on that Calendar Date; composite calendars follow their Combination Rule.",
             [("09", "Composite Calendar", "Combination Rule"), ("09", "Calendar Date", "Calendar Date"),
              ("09", "Calendar Date", "Day Type")]),
            ("Business Days in Period", "Count of Calendar Dates with Day Type = business day between the period start and end dates.",
             [("09", "Calendar Date", "Day Type")]),
            ("Unmapped Source Values", "Count of distinct source values seen in feeds with no Code Mapping in Mapping Status = approved.",
             [("09", "Code Mapping", "Mapping Status")]),
            ("LEI Renewal Due", "Count of internal legal entities with LEI Next Renewal Date within 60 days or LEI Registration Status not issued.",
             [("09", "Legal Entity Identifier", "LEI Registration Status"),
              ("09", "Legal Entity Identifier", "LEI Next Renewal Date"), ("09", "Code List", "Registration Status"),
              ("09", "Legal Entity Identifier", "LEI")]),
            ("Geographic Coverage Completeness %", "Active geographic units of a scheme with a parent in each required hierarchy type / all active units of that scheme.",
             [("09", "Geographic Unit", "Geographic Unit ID"), ("09", "Geographic Unit", "Geographic Scheme"),
              ("09", "Geographic Unit", "Geographic Unit Status"),
              ("09", "Geographic Hierarchy", "Geographic Hierarchy Type"),
              ("09", "Geographic Hierarchy", "Parent Geographic Unit"),
              ("09", "Geographic Hierarchy", "Child Geographic Unit")]),
            ("ZIP-to-County Coverage %", "Active ZIP codes with a Preferred County that resolves to an active US County / all active ZIP codes; counties with a County CBSA Code give the metro roll-up.",
             [("09", "US County", "County CBSA Code"), ("09", "ZIP Code & ZCTA", "Preferred County"),
              ("09", "Core Based Statistical Area", "CBSA Code")]),
            ("Authorizations Due for Filing", "Count of Entity Authorization rows with Authorization Status = active and Annual Filing Due Date within 60 days, by Regulator.",
             [("38", "Entity Authorization", "Annual Filing Due Date"),
              ("38", "Entity Authorization", "Authorization Status"), ("38", "Entity Authorization", "Regulator")]),
            ("Concordance Coverage %", "Active Classification Codes of a source scheme version with at least one Classification Concordance row to the target scheme / all active codes of the source scheme version.",
             [("09", "Classification Scheme", "Scheme Version")]),
            ("Open Code List Change Requests", "Count of Code List Change Request rows with no Change Decision, by Change Type.",
             [("09", "Code List Change Request", "Change Decision"), ("09", "Code List Change Request", "Change Type")]),
            ("Supported Locale Count", "Count of Locale Tag values whose language has Firm-Supported Language Indicator = Y.",
             [("09", "Language", "Firm-Supported Language Indicator"), ("09", "Locale", "Locale Tag")]),
        ],
        inputs=[
            ("09", "Country", ["Country Code (Alpha-2)", "Country Short Name", "Default Currency", "Primary Time Zone"]),
            ("09", "Geographic Unit", ["Geographic Unit ID", "Geographic Unit Type", "Geographic Scheme", "Scheme Code",
                                       "Geographic Unit Name", "Scheme Vintage", "Country", "Successor Geographic Unit",
                                       "Geographic Unit Status", "Effective From", "Effective To"]),
            ("09", "Geographic Hierarchy", ["Geographic Hierarchy Type", "Parent Geographic Unit", "Child Geographic Unit",
                                            "Hierarchy Effective From"]),
            ("09", "Geographic Group", ["Geographic Group ID", "Geographic Group Name", "Geographic Group Type"]),
            ("09", "Calendar", ["Calendar ID", "Calendar Name", "Calendar Type", "Calendar Country", "Exchange MIC",
                                "Calendar Time Zone", "Weekend Days"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type", "Holiday Name"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Fiscal Period Type", "Period Start Date", "Period End Date",
                                     "Fiscal Period Status"]),
            ("09", "Reporting Period Definition", ["Reporting Period Definition Code", "Period Basis Calendar", "As-Of Date Convention",
                                                   "Business Day Convention"]),
            ("09", "Currency", ["Currency Code", "Currency Name", "Minor Unit", "Currency Status", "Replacement Currency",
                                "Group Reporting Currency Indicator"]),
            ("09", "FX Rate Type", ["FX Rate Type Code", "FX Rate Type Name", "Fixing Time", "Publication Calendar",
                                    "Quote Convention", "Approved Usage"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category", "Jurisdiction of Formation",
                                             "Entity Status", "Branch Indicator", "Head Office Entity", "Accounting Company Code",
                                             "Party Master Cross-Reference"]),
            ("09", "Legal Entity Identifier", ["LEI", "LEI Registration Status", "LEI Next Renewal Date", "SEC CIK", "Firm CRD Number"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name", "Org Unit Type", "Business Function", "Employing / Booking Entity",
                                "Org Unit Effective From"]),
            ("09", "Org Hierarchy Link", ["Org Hierarchy Type", "Parent Org Unit", "Child Org Unit", "Link Effective From"]),
            ("09", "Code List", ["Code List ID", "Code List Name", "Owning Business Domain", "Data Owner", "Registration Status",
                                 "Current Version"]),
            ("09", "Code Value", ["Code", "Code Label", "Parent Code", "Code Value Status", "Replaced By Code"]),
            ("09", "Code Mapping", ["Code Mapping ID", "Source System", "Source Value", "Target Code List", "Target Code",
                                    "Mapping Type", "Mapping Status"]),
            ("09", "Code List Consumer", ["Consuming Domain", "Consuming Attribute", "Usage Type"]),
            ("09", "Country Subdivision", ["Subdivision Code", "Subdivision Name", "Subdivision Category", "Parent Country",
                                           "US State FIPS Code"]),
            ("09", "US County", ["County FIPS Code", "County CBSA Code"]),
            ("09", "Core Based Statistical Area", ["CBSA Code", "CBSA Title", "CBSA Type", "Delineation Bulletin"]),
            ("09", "ZIP Code & ZCTA", ["ZIP Code", "ZCTA Code", "Preferred County"]),
            ("09", "Geographic Group Membership", ["Member Geographic Unit", "Membership Type", "Membership Effective From"]),
            ("09", "Time Zone", ["IANA Time Zone ID", "Daylight Saving Indicator", "tzdata Release"]),
            ("09", "Composite Calendar", ["Component Calendar", "Combination Rule"]),
            ("09", "Fiscal Calendar", ["Fiscal Calendar ID", "Fiscal Year Start", "Period Structure"]),
            ("09", "Currency Pair Convention", ["Currency Pair"]),
            ("09", "FX Rate Source", ["FX Rate Source Code", "Licensed Dataset"]),
            ("09", "Language", ["Language Code (ISO 639-1)", "Language Code (ISO 639-3)", "Language Name (English)",
                                "Firm-Supported Language Indicator"]),
            ("09", "Locale", ["Locale Tag", "Fallback Locale", "Locale Usage"]),
            ("09", "Unit of Measure", ["Unit Code", "Unit Name", "Unit Category", "Conversion Factor to Base"]),
            ("09", "Number & Date Convention", ["Decimal Separator", "Display Date Pattern", "Rounding Rule",
                                                "Percentage Storage Convention"]),
            ("09", "Entity Ownership Relationship", ["Child Entity", "Parent Entity", "Relationship Type", "Ownership Percentage",
                                                     "Level 2 Reporting Exception", "Ownership Effective From"]),
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Regulator", "Authorization Type",
                                            "Regulator Reference Number", "Authorization Status", "Authorization Effective Date",
                                            "Permitted Activities", "Requirements / Limitations", "Annual Filing Due Date"]),
            ("09", "Office Location", ["Office ID", "Office Country / Subdivision", "Office Time Zone", "Office Legal Entity"]),
            ("09", "Classification Scheme", ["Classification Scheme ID", "Scheme Name", "Scheme Version", "Scheme Jurisdiction",
                                             "Number of Levels", "Scheme Effective From", "License Required Indicator"]),
            ("09", "Classification Code", ["Classification Code", "Classification Label", "Classification Level",
                                           "Parent Classification Code"]),
            ("09", "Classification Concordance", ["Source Classification Code", "Target Classification Code",
                                                  "Correspondence Type", "Concordance Source"]),
            ("09", "Code List Change Request", ["Change Request Reference", "Change Type", "Impact Assessment", "Change Decision"]),
        ],
        upstream=[],
        refresh="Daily",
        timeliness="By 6am ET each business day; calendar years published at least 12 months ahead",
        history="SCD type 2 on every reference member with effective dates; geographic schemes kept by vintage; code list versions kept indefinitely",
        classification="Internal",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract"],
        dq_rules=[
            "Every Country, Currency and Code Value used by another product exists here with an active status on the date of use; every Code Mapping with Mapping Status = approved points to a Code Value with Code Value Status = active.",
            "Each calendar has exactly one Calendar Date row per date for the published horizon, with a Day Type; fiscal periods of a fiscal year are contiguous and do not overlap, with each Period Start Date the day after the prior Period End Date.",
            "Every active Internal Legal Entity with Entity Category requiring one has an LEI with LEI Registration Status = issued; every active Entity Authorization has a Regulator Reference Number and Permitted Activities, and its Authorized Entity is an active Internal Legal Entity.",
            "Every child in a geographic or org hierarchy has exactly one parent per hierarchy type on any date; every ZIP Code Preferred County, US County CBSA Code and Country Subdivision Parent Country resolves to an active member of the referenced scheme for the same vintage.",
            "Every Locale Tag is a valid BCP 47 tag with a Number & Date Convention row, and every Fallback Locale resolves to another published locale.",
            "Ownership Percentage of all open Entity Ownership Relationship rows for a Child Entity and Relationship Type sums to no more than 100%.",
        ],
        notes=("Root foundational product: it depends on no other data product, so upstream is empty by design. Unit Head on Org Unit is personal data and is excluded, "
               "so PII = N. Employees are mastered in 09 but are published through DP-009 (sales staff only), not here. "
               "Granular geographic units are Geographic Unit rows by scheme; the scheme-specific attributes (US County, CBSA, "
               "ZIP Code & ZCTA) are published as extension tables keyed on Geographic Unit "
               "ID. Licensed classification schemes (License Required Indicator = Y) and FX Rate Source Licensed Dataset are "
               "published only to consumers covered by the Data Domain 14 license. Code List Consumer binds each Code attribute to "
               "its code list, so a Code Value lookup is published for every bound attribute; FX Rate Type Publication Calendar "
               "resolves to a published Calendar ID. 39 input objects is far above the usual range "
               "because this is the enterprise reference product: it publishes every small Data Domain 09 reference set as one "
               "governed, versioned package so no other product sources reference data on its own. "
               "Taxonomy gap: there is no FX rate observation object (rate type x currency pair x date x rate); FX rates exist "
               "only as FX Rate Applied on 06 transactions. A daily FX rate table should be added to 09 SR-CCY before reporting-"
               "currency conversion can be governed here. "
               "W1 re-point (CW-909): UK Postcode, ITL Region and NUTS Region dropped, no successor in the wealth 09 (UK and EU "
               "statistical geography removed, US only) (CW-909); Country EU Member State Indicator and EEA Member Indicator, "
               "Legal Entity Identifier FCA Firm Reference Number (no UK-authorized entity; SEC file numbers are held per "
               "registration in 38 Entity Authorization) and FX Rate Source Benchmark Regulatory Status (EU / UK BMR) dropped, "
               "no successor in the wealth 09 (CW-909). No measure read them."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-014": dict(
        definition=("Licensed industry flow and asset data conformed to the firm's categories, channels and distributor firms, "
                    "together with the maintained peer universes, peer funds and their periodic performance, fee and flow metrics, "
                    "and the definitions and records of market share. It loads each vendor release once, maps external "
                    "categories to the firm's share classes and segments, and carries the vendor's permitted-use terms, so that "
                    "market sizing, share and competitive benchmarking products use the same industry baseline."),
        business_questions=[
            "What were industry gross sales, redemptions and net flows last month by category, channel, vehicle and region?",
            "Which categories and channels are growing fastest, and which fund managers are gaining assets?",
            "Who is in the peer universe for each of our strategies, and where do our share classes rank on return, fees and flows?",
            "What is our market share by category and channel under each share definition, and how did it change?",
            "Which datasets and uses are permitted for each industry release, and what attribution is required?",
        ],
        grain="Industry flow observation: data release x category x channel x vehicle type x region x distributor firm x fund manager x fund or share class (with peer metric snapshots at peer fund x snapshot date x return period x peer universe)",
        dimensions=["Data release / as-of date", "Industry category (external and mapped internal segment)", "Distribution channel",
                    "Vehicle type", "Region / market", "Distributor firm", "Fund manager / competitor", "Peer universe", "Peer fund",
                    "Return period"],
        measures=[
            ("Industry Net Flow", "Sum of Net Flow for the release and dimension combination; Gross Sales - Redemptions where the provider supplies both.",
             [("11", "Industry Flow Observation", "Gross Sales"), ("11", "Industry Flow Observation", "Redemptions"),
              ("11", "Industry Flow Observation", "Net Flow")]),
            ("Industry Organic Growth Rate", "Annualized Industry Net Flow / prior-period Ending Assets for the same dimension combination.",
             [("11", "Industry Flow Observation", "Ending Assets"), ("11", "Industry Flow Observation", "Net Flow"),
              "Industry Net Flow"]),
            ("Mapped Coverage %", "Own-firm Ending Assets in observations mapped to an own share class through Category Mapping / own-firm Ending Assets reported by the provider.",
             [("11", "Industry Flow Observation", "Ending Assets")]),
            ("Peer Median Expense Ratio", "Median Expense Ratio of peer universe members at the snapshot date.",
             [("11", "Peer Metric Snapshot", "Snapshot Date"), ("11", "Peer Metric Snapshot", "Expense Ratio"),
              ("11", "Peer Metric Snapshot", "Peer Universe")]),
            ("Peer Flow Rank", "Rank of each member's Estimated Net Flow within its peer universe for the snapshot.",
             [("11", "Peer Metric Snapshot", "Estimated Net Flow"), ("11", "Peer Metric Snapshot", "Peer Universe"),
              ("11", "Industry Flow Observation", "Net Flow")]),
            ("Release Revision", "Net Flow in the current release - Net Flow in the superseded release for the same dimension combination.",
             [("11", "Industry Flow Observation", "Net Flow")]),
        ],
        inputs=[
            ("11", "Industry Dataset Profile", ["Licensed Dataset", "Dataset Family", "Industry Data Provider", "Flow Estimation Method",
                                                "Reinvested Distribution Treatment", "Category Scheme", "Lowest Grain Available",
                                                "Vehicles Covered", "Coverage Basis", "Revision Policy"]),
            ("11", "Industry Data Release", ["Data Release ID", "As-of Date", "Publication Date", "Release Status", "Supersedes Release",
                                             "Source Load"]),
            ("11", "Industry Flow Observation", ["Data Release", "Industry Category", "Distribution Channel", "Vehicle Type",
                                                 "Region / Market", "Distributor Firm", "Fund Manager Firm", "Fund / Share Class",
                                                 "Gross Sales", "Redemptions", "Net Flow", "Ending Assets", "Observation Currency",
                                                 "Value Basis"]),
            ("11", "Category Mapping", ["Category Scheme", "External Category Value", "Mapped Share Class", "Internal Market Segment",
                                        "Mapping Effective From", "Mapping Effective To"]),
            ("11", "Competitor Profile", ["Competitor Profile ID", "Competitor Party", "Competitor Display Name", "Competitor Tier",
                                          "Competitor Type", "Vendor Manager Identifiers"]),
            ("11", "Peer Universe", ["Peer Universe ID", "Peer Universe Name", "Universe Type", "Base Category Scheme",
                                     "Base Category Value", "Inclusion Rules", "Representative Share Class Rule",
                                     "Own Strategy Compared", "Universe Effective From", "Universe Effective To"]),
            ("11", "Peer Universe Member", ["Member Fund", "Manual Override Indicator"]),
            ("11", "Peer Fund", ["Peer Fund ID", "Peer Fund Name", "ISIN", "Ticker", "Morningstar SecId", "Managing Firm",
                                 "Vehicle Type", "Domicile", "Peer Morningstar Category"]),
            ("11", "Peer Metric Snapshot", ["Snapshot Date", "Return Period", "Total Return", "Category Percentile Rank", "Quartile Rank",
                                            "Expense Ratio", "Estimated Net Flow", "Peer Universe"]),
            ("11", "Market Share Definition", ["Share Definition Code", "Share Definition Name", "Share Measure Basis", "Share Dimension",
                                               "Numerator Source", "Denominator Dataset", "Calculation Formula", "Negative Flow Treatment"]),
            ("11", "Market Share Record", ["Market Share Record ID", "Share Definition", "Period End Date", "Period Type",
                                           "Category / Segment", "Channel", "Distributor Firm", "Region / Market", "Vehicle Type",
                                           "Firm Value", "Industry Value", "Market Share"]),
            ("14", "Permitted Use Grant", ["Grant Agreement", "Grant Dataset", "Permitted Use Category", "Permission Status",
                                           "Redistribution Recipient Types", "Derived Data Ownership", "Grant Effective From",
                                           "Grant Effective To"]),
            ("14", "Attribution Requirement", ["Attribution Agreement", "Required Attribution Text", "Required Disclaimer Text",
                                               "Applies To Output Types"]),
        ],
        upstream=["DP-001", "DP-004", "DP-013", "DP-075", "DP-481"],
        refresh="Monthly",
        timeliness="Within 2 business days of each vendor release (typically mid-month for prior-month industry flows); peer metrics by business day 5 after month-end",
        history="Every vendor release kept as published, including superseded releases, since 2010 or the licensed history depth, whichever is shorter",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model"],
        dq_rules=[
            "Every observation belongs to a release with Release Status = published, and only the latest non-superseded release per as-of date is flagged current.",
            "Where Gross Sales and Redemptions are both supplied, Net Flow equals Gross Sales - Redemptions within the provider's rounding.",
            "At least 98% of the firm's own Ending Assets in each release map to an own share class through an effective Category Mapping.",
            "Every Peer Universe has at least 10 members on each snapshot date, and every member resolves to a Peer Fund with an ISIN or Morningstar SecId.",
            "Market Share = Firm Value / Industry Value for every Market Share Record, and Industry Value is greater than zero.",
            "No dataset is delivered to a consumer use without a Permitted Use Grant in Permission Status = permitted for that use, and the Attribution Requirement applied to its output has Attribution Agreement equal to the grant's Grant Agreement.",
        ],
        notes=("Classified Confidential - Licensed: redistribution outside the firm, or in client-facing material, needs the "
               "Permitted Use Grant and the Required Attribution Text. Permitted Use Grant is keyed on its registry key (Grant "
               "Agreement, Grant Dataset, Permitted Use Category, Grant Effective From) and linked to its attribution terms "
               "through the same license agreement. Industry data is organization and fund level (PII = N). "
               "Market Share Record is mastered in 11 and published here as a conformed fact; share analysis and sizing are "
               "built on it in DP-031. Ratings (Rating Observation) are left to DP-030. Fund Manager Firm is resolved to a "
               "competitor through Competitor Profile Vendor Manager Identifiers. "
               "Taxonomy gap: Industry Flow Observation has no flag for the firm's own observations; own-firm rows are identified "
               "by matching Fund Manager Firm to the firm's own vendor manager identifier."
               "WP1 re-point (CW-240): the competitor join (Fund Manager Firm to 11 Competitor Profile through Vendor Manager Identifiers) resolves through DP-481 Competitor Offerings & Price Observations, the WP1F publisher of 11 Competitor Profile, added upstream; the 11 Competitor Profile input is unchanged (Competitor Display Name is still read here as the vendor's label, while DP-481 takes the name from the DP-240 party)."),
    ),
}
