"""Data product specifications, Wave E1 group "book_of_record": the investment book of record, prices and index data,
official returns (DP-145 re-specified at WP1 in specs_w1f_certified.py), risk measures, trading agreements and SSIs (DP-140 to DP-147), and the fund NAV (DP-165 re-specified at WP1 in specs_w1f_certified.py), fund ledger and
custody network (DP-165 to DP-167). See CONTRACT.md (Enterprise products) and the Wave E0 briefs Investment_Operations.md
and Fund_Operations.md."""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-140": dict(
        definition=("The conformed portfolio master: every portfolio (managed book) the firm runs, with its identifiers, IBOR "
                    "accounting conventions, lifecycle events and business-line detail, and the effective-dated links that join "
                    "it to the funds, mandates, SMA accounts and model portfolios it implements and to its parent, sleeve, "
                    "carve-out and successor books. It publishes the concept 'Portfolio (managed book)', 18, PORT- of "
                    "CONCEPT_OWNERSHIP (CD-145) without remastering it, and it is the only place any product resolves a "
                    "portfolio to a fund, mandate or account (CD-324), so risk, performance, compliance, fund accounting and "
                    "the Wave E5 Firm AUM Reconciliation slice by the same book. It owns no certified number."),
        business_questions=[
            "Which portfolios are active today, by business line, portfolio type, book of record system and IBOR operating model?",
            "Which fund, mandate, SMA account or model portfolio does each portfolio implement, and which portfolio implemented a given fund or mandate on any past date?",
            "Which active books have no implementation link, and which live funds or open mandates have no implementing portfolio?",
            "Which sleeves, carve-outs and aggregates roll up to each parent book, and which of them roll up on a look-through basis?",
            "Which portfolios were set up, funded, transitioned, merged or terminated this month, and which lifecycle events are still awaiting approval?",
            "Which books are run by an outsourced middle office or shadow a client custodian record, and by which provider?",
        ],
        grain="Portfolio x effective period (SCD type 2), with bridge tables portfolio x implemented object x link type x effective period and parent portfolio x child portfolio x link type x effective period",
        dimensions=["Portfolio", "Portfolio type", "Business line", "Portfolio status", "Base currency", "IBOR operating model and middle office provider",
                    "Book of record system", "Implementation link type", "Implemented fund / product", "Implemented mandate",
                    "Managed account", "Followed model portfolio", "Portfolio hierarchy link type", "Lifecycle event type", "Effective date"],
        measures=[
            ("Active Portfolios", "Count of distinct Portfolio ID with Portfolio Status in (Active, Closed to New Money, Liquidating) on the as-of date, by Business Line, Portfolio Type and IBOR Operating Model.",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("18", "Portfolio", "Business Line"),
              ("18", "Portfolio", "Portfolio Type"), ("18", "Portfolio", "IBOR Operating Model")]),
            ("Unlinked Active Books", "Count of Active Portfolios with Portfolio Type in (Standalone Book, Aggregate) that have no Portfolio Implementation Link effective on the as-of date (Implementation Effective From on or before it and Implementation Effective To null or after it). Sleeves are excluded because they reach their product through the parent's link.",
             [("18", "Portfolio Implementation Link", "Implementing Portfolio"), ("18", "Portfolio Implementation Link", "Implementation Effective From"),
              ("18", "Portfolio Implementation Link", "Implementation Effective To"), ("18", "Portfolio", "Portfolio Type"), "Active Portfolios"]),
            ("Implementation Link Completeness %", "1 - Unlinked Active Books / Active Portfolios with Portfolio Type in (Standalone Book, Aggregate).",
             [("18", "Portfolio", "Portfolio Type"), "Unlinked Active Books", "Active Portfolios"]),
            ("Live Products Without Portfolio", "Count of Investment Product IDs with Vehicle Type other than Model Portfolio, Separately Managed Account and Segregated Mandate (which are reached through Manages Account and Implements Mandate links), with at least one Share Class of Share Class Status Active (Parent Product) and no Portfolio Implementation Link of Implementation Link Type Implements Product whose Implemented Product is the product on the as-of date.",
             [("01", "Investment Product", "Product ID"), ("01", "Investment Product", "Vehicle Type"),
              ("01", "Share Class", "Parent Product"), ("01", "Share Class", "Share Class Status"),
              ("18", "Portfolio Implementation Link", "Implementation Link Type"), ("18", "Portfolio Implementation Link", "Implemented Product")]),
            ("Open Mandates Without Portfolio", "Count of Investment Mandate IDs with no Mandate Termination whose Effective Termination Date is on or before the as-of date, and no effective Portfolio Implementation Link of Implementation Link Type Implements Mandate naming the mandate as Implemented Mandate.",
             [("01", "Investment Mandate", "Mandate ID"), ("12", "Mandate Termination", "Terminated Mandate"),
              ("12", "Mandate Termination", "Effective Termination Date"),
              ("18", "Portfolio Implementation Link", "Implementation Link Type"), ("18", "Portfolio Implementation Link", "Implemented Mandate")]),
            ("Multiple Primary Implementation Flag", "Y for an implemented product, mandate or account that has more than one effective Portfolio Implementation Link with Primary Implementation Indicator = Y on the as-of date.",
             [("18", "Portfolio Implementation Link", "Primary Implementation Indicator"), ("18", "Portfolio Implementation Link", "Implemented Product"),
              ("18", "Portfolio Implementation Link", "Implemented Mandate"), ("18", "Portfolio Implementation Link", "Managed Account")]),
            ("Sleeves Without Parent", "Count of Active Portfolios with Portfolio Type = Sleeve and no effective Portfolio Hierarchy Link of type Sleeve Of naming them as Child Portfolio.",
             [("18", "Portfolio Hierarchy Link", "Child Portfolio"), ("18", "Portfolio Hierarchy Link", "Portfolio Hierarchy Link Type"),
              ("18", "Portfolio Hierarchy Link", "Hierarchy Effective From"), ("18", "Portfolio Hierarchy Link", "Hierarchy Effective To"),
              ("18", "Portfolio", "Portfolio Type"), "Active Portfolios"]),
            ("Outsourced Book Share", "Active Portfolios with IBOR Operating Model in (Outsourced Middle Office, Hybrid, Shadow of Client Custodian Record) / Active Portfolios, by Middle Office Provider and Business Line.",
             [("18", "Portfolio", "IBOR Operating Model"), ("18", "Portfolio", "Middle Office Provider"), "Active Portfolios"]),
            ("Pending Lifecycle Events", "Count of Portfolio Lifecycle Events with Event Approval Status = Pending, by Portfolio Lifecycle Event Type and days since Event Effective Date.",
             [("18", "Portfolio Lifecycle Event", "Event Approval Status"), ("18", "Portfolio Lifecycle Event", "Portfolio Lifecycle Event Type"),
              ("18", "Portfolio Lifecycle Event", "Event Effective Date")]),
            ("Books Without Custody Account", "Count of Active Portfolios with Portfolio Type = Standalone Book and Safekeeping Custody Account null.",
             [("18", "Portfolio", "Safekeeping Custody Account"), ("18", "Portfolio", "Portfolio Type"), "Active Portfolios"]),
        ],
        inputs=[
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Name", "Portfolio Type", "Business Line", "Portfolio Status", "Base Currency",
                                 "Legal Owner Entity", "Managing Entity", "Proprietary Capital Indicator", "Inception Date", "Termination Date",
                                 "Book of Record System", "IBOR Operating Model", "Middle Office Provider", "Safekeeping Custody Account"]),
            ("18", "Portfolio Identifier", ["Identified Portfolio", "Portfolio Identifier Scheme", "Portfolio Identifier Value", "Identifier Issuer",
                                            "Portfolio Identifier Status", "Identifier Effective From", "Identifier Effective To"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product", "Implemented Mandate",
                                                     "Managed Account", "Followed Model Portfolio", "Primary Implementation Indicator",
                                                     "Implementation Effective From", "Implementation Effective To"]),
            ("18", "Portfolio Hierarchy Link", ["Parent Portfolio", "Child Portfolio", "Portfolio Hierarchy Link Type", "Look-Through Roll-Up Indicator",
                                                "Hierarchy Effective From", "Hierarchy Effective To"]),
            ("18", "Portfolio Accounting Basis", ["Default Lot Relief Method", "Wash-Sale Tracking Indicator",
                                                  "Daily Income Accrual Indicator", "Valuation Calendar", "FX Rate Type Used",
                                                  "Start-of-Day Cutoff Time", "Accounting Basis Effective From"]),
            ("18", "Portfolio Lifecycle Event", ["Event Portfolio", "Portfolio Lifecycle Event Type", "Event Effective Date", "Resulting Portfolio Status",
                                                 "Event Approval Status", "Counterpart Portfolio", "Related Transition Event"]),
            ("18", "Fund Portfolio Detail", ["Cash Sweep Vehicle", "Daily Holdings Publication Indicator"]),
            ("18", "SMA Portfolio Detail", ["Sponsor Program Agreement", "Full Discretion Indicator", "Tax-Aware Management Indicator",
                                            "Tax Loss Harvesting Indicator"]),
            ("18", "Private Fund Portfolio Detail", ["Valuation Lag Days", "Fund Interest Holdings Indicator"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type", "Implemented Strategy", "Base Currency"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("01", "Investment Mandate", ["Mandate ID", "Mandate Name", "Mandate Type", "Client", "Implemented Strategy"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name"]),
            ("12", "Mandate Termination", ["Termination ID", "Terminated Mandate", "Effective Termination Date"]),
        ],
        upstream=["DP-004", "DP-093", "DP-005", "DP-013", "DP-211", "DP-240"],
        refresh="Daily",
        timeliness="By 6am ET each business day, before the start-of-day holdings view; a portfolio set up or relinked during the day is published within one hour of approval",
        history="SCD type 2 on the portfolio, identifiers, implementation and hierarchy links and accounting basis since each book's inception; lifecycle events kept indefinitely; terminated books kept for 10 years after Termination Date",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Portfolio has exactly one Portfolio ID, a Portfolio Type, a Business Line and a Base Currency, and Termination Date is null unless Portfolio Status is Terminated or Merged.",
            "Each Portfolio Implementation Link fills exactly the one reference its Implementation Link Type names (Implemented Product, Implemented Mandate, Managed Account or Followed Model Portfolio) and that reference resolves in DP-004, 01 Investment Mandate or DP-093 on the link's effective dates.",
            "No implemented product, mandate or account has more than one effective link with Primary Implementation Indicator = Y on any date, and effective periods of the same link never overlap.",
            "The Portfolio Hierarchy Link graph has no cycles, a child has at most one Sleeve Of parent on any date, and every Portfolio of type Sleeve has an effective Sleeve Of parent.",
            "An Active Portfolio with IBOR Operating Model other than In House names a Middle Office Provider that resolves to an active party in DP-240.",
            "A Portfolio Identifier Value is unique within its Portfolio Identifier Scheme on any date.",
        ],
        notes=("W4 re-point (CW-930, CW-166): 18 Private Fund Portfolio Detail.Vintage Year and Subscription Credit Facility Indicator dropped, no successor (they served the firm's own private fund books, which leave with 30); 18 keeps the feeder book and Fund Interest Holding Detail, and no measure read either attribute. "
               "W1b: Portfolio Accounting Basis.Lot Rule Jurisdiction dropped, no successor (CW-918); the US book applies one lot rule set (wash-sale tracking stays), so no measure read it. "
               "Master concept: 'Portfolio (managed book)', 18, PORT- (CD-145); Portfolio Implementation Link and Portfolio Hierarchy Link "
               "are the one portfolio-to-fund, mandate, account and model mapping in the catalog (CD-324): every product that rolls "
               "portfolio values to a fund, share class, mandate or account lists DP-140 upstream and uses these links as of the date "
               "measured. Certified numbers: none. "
               "Operating model (CD-297, CD-147): drafted in house. If the middle office is outsourced the grain is unchanged, because "
               "portfolio set-up remains the firm's decision; set-up and lifecycle events arrive from the provider for approval, "
               "IBOR Operating Model and Middle Office Provider record the model per book, and DP-150 carries the oversight measures. "
               "Dimensions: fund and share class come from DP-004. DP-004 does not yet carry 01 Investment Mandate (CD-322 extends it in "
               "Wave E1), so this product reads 01 Investment Mandate directly until that extension is built, and then takes it through "
               "DP-004 with no change to the inputs. SMA and institutional accounts come from DP-093, sponsor program agreements from "
               "DP-005, middle office providers from DP-240, book of record systems from DP-211, calendars, legal entities and FX rate "
               "types from DP-013. 12 Mandate Termination is read directly because the mandate's end date lives only there "
               "(rule 2 exception); no 12 product is upstream. Safekeeping Custody Account is published as the SKA- key only; the "
               "account itself is published by DP-167, which depends on this product and so is not listed upstream. "
               "Daily Holdings Publication Indicator is a Derived copy (01) on 18 Fund Portfolio Detail with no 01 master attribute yet "
               "(proposals_18 asks 01 to add one), so it is read as held. "
               "PII = Y: Portfolio Name and Portfolio Identifier Value are personal data for individuals' SMA books; publish a "
               "pseudonymized view keyed on Portfolio ID for wide use. "
               "Open SME questions (18 Source_Notes): SMA granularity (one portfolio per account or per sleeve, question 3); whether "
               "seed and proprietary books are in this book or in 43 (question 8); whether the firm keeps the book for insurer separate "
               "accounts it sub-advises (question 9); which platform is the IBOR (question 1). "
               "Rests on CD-145, CD-147, CD-297, CD-322, CD-324."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-141": dict(
        definition=("Every transaction booked to a portfolio in the IBOR - trades, income, corporate action bookings, FX, fees, "
                    "transfers, in-kind movements, capital calls paid, distributions received and adjustments - with its explicit "
                    "costs and its booking and amendment trail, plus the Portfolio Capital Activity that moves cash and assets into "
                    "and out of each book. It publishes the concept 'Portfolio Transaction', 18, PTXN- of CONCEPT_OWNERSHIP "
                    "without remastering it. Performance takes its external cash flows from it, trade operations the booked "
                    "trades it settles, and fund accounting and tax one record of what each portfolio did. It owns no certified "
                    "number: Portfolio Capital Activity is a book's cash flow, never a sales flow, and is never re-labeled as net "
                    "flows, which stay certified in DP-008 (CD-320)."),
        business_questions=[
            "What did each portfolio buy, sell, receive and pay on a trade date, and at what explicit cost?",
            "Which bookings were amended, canceled, rebooked or back-dated after the start-of-day cut-off, by whom and why?",
            "Which trades are past their contractual settlement date without settlement confirmed?",
            "What capital came into and went out of each portfolio by share class, client account and capital activity type, and how much of it was in kind?",
            "Which trades were booked without an allocation reference, and which corporate action bookings do not trace to a corporate action event?",
        ],
        grain="Portfolio transaction (PTXN-) as booked, with its event trail (transaction x event type x event timestamp); Portfolio Capital Activity is a second fact at portfolio x share class or client account x trade date x capital activity type",
        dimensions=["Portfolio", "Business line", "Instrument", "Portfolio transaction type", "Trade date", "Contractual settlement date",
                    "Transaction currency", "Executing broker", "Transaction counterparty", "Transaction event type", "Capital activity type",
                    "Share class", "Client account", "Data basis"],
        measures=[
            ("Booked Transactions", "Count of distinct Portfolio Transaction ID whose latest Portfolio Transaction Event Type is Booked or Amended (Canceled and Rebooked transactions excluded; a rebooking is counted once, as its Rebooked As Transaction), by Portfolio Transaction Type and Trade Date.",
             [("18", "Portfolio Transaction", "Portfolio Transaction ID"), ("18", "Portfolio Transaction", "Portfolio Transaction Type"),
              ("18", "Portfolio Transaction", "Trade Date"), ("18", "Portfolio Transaction Event", "Event Transaction"),
              ("18", "Portfolio Transaction Event", "Portfolio Transaction Event Type"), ("18", "Portfolio Transaction Event", "Event Timestamp"),
              ("18", "Portfolio Transaction Event", "Rebooked As Transaction")]),
            ("Explicit Transaction Cost Base", "Sum of Total Explicit Cost over Booked Transactions, translated to the portfolio Base Currency at Trade FX Rate where Transaction Currency differs.",
             [("18", "Transaction Cost & Charge", "Total Explicit Cost"), ("18", "Portfolio Transaction", "Trade FX Rate"),
              ("18", "Portfolio Transaction", "Transaction Currency"), ("18", "Portfolio", "Base Currency"), "Booked Transactions"]),
            ("Explicit Cost Tie-Out Flag", "Y when Total Explicit Cost differs from Commission Amount + Exchange and Clearing Fee Amount + Transaction Tax Amount by more than 0.01 in transaction currency (Research Payment Component is part of Commission Amount and is not added again).",
             [("18", "Transaction Cost & Charge", "Total Explicit Cost"), ("18", "Transaction Cost & Charge", "Commission Amount"),
              ("18", "Transaction Cost & Charge", "Exchange and Clearing Fee Amount"), ("18", "Transaction Cost & Charge", "Transaction Tax Amount")]),
            ("Amendment Rate", "Booked Transactions with at least one Portfolio Transaction Event of type Amended, Canceled or Rebooked / all transactions booked in the period, by Amendment Reason.",
             [("18", "Portfolio Transaction Event", "Portfolio Transaction Event Type"), ("18", "Portfolio Transaction Event", "Amendment Reason"),
              "Booked Transactions"]),
            ("Back-Dated Bookings", "Count of Portfolio Transaction Events with Back-Dated Indicator = Y, by Event Source System and portfolio.",
             [("18", "Portfolio Transaction Event", "Back-Dated Indicator"), ("18", "Portfolio Transaction Event", "Event Source System")]),
            ("Unsettled Past Contractual Date", "Count and Net Amount Base of Booked Transactions with Contractual Settlement Date before the as-of date and Settlement Confirmed Indicator = N.",
             [("18", "Portfolio Transaction", "Contractual Settlement Date"), ("18", "Portfolio Transaction", "Settlement Confirmed Indicator"),
              ("18", "Portfolio Transaction", "Net Amount Base"), "Booked Transactions"]),
            ("Trades Without Allocation Reference", "Count of Booked Transactions with Portfolio Transaction Type in (Buy, Sell, Short Sale, Buy to Cover, Open Derivative, Close Derivative, FX Spot, FX Forward) and Source Allocation ID null.",
             [("18", "Portfolio Transaction", "Source Allocation ID"), ("18", "Portfolio Transaction", "Portfolio Transaction Type"), "Booked Transactions"]),
            ("Portfolio Net Capital Activity", "Sum of Activity Amount Base with Capital Activity Type in (Subscription, ETF Creation, Client Contribution, Capital Call Proceeds, Seed Investment) minus Activity Amount Base with type in (Redemption, ETF Redemption, Client Withdrawal, Distribution to Investors, Seed Redemption), by portfolio, Activity Share Class or Activity Account and Activity Trade Date. A book cash flow, not net flows.",
             [("18", "Portfolio Capital Activity", "Activity Amount Base"), ("18", "Portfolio Capital Activity", "Capital Activity Type"),
              ("18", "Portfolio Capital Activity", "Activity Portfolio"), ("18", "Portfolio Capital Activity", "Activity Share Class"),
              ("18", "Portfolio Capital Activity", "Activity Account"), ("18", "Portfolio Capital Activity", "Activity Trade Date")]),
            ("In-Kind Capital Activity Share", "Activity Amount Base with In-Kind Activity Indicator = Y / all Activity Amount Base, by Capital Activity Type.",
             [("18", "Portfolio Capital Activity", "In-Kind Activity Indicator"), ("18", "Portfolio Capital Activity", "Activity Amount Base"),
              ("18", "Portfolio Capital Activity", "Capital Activity Type")]),
            ("Estimated Capital Activity Share", "Activity Amount Base with Activity Data Basis = Estimated / all Activity Amount Base for the trade date, the part of the day's capital activity the book has not yet confirmed.",
             [("18", "Portfolio Capital Activity", "Activity Data Basis"), ("18", "Portfolio Capital Activity", "Activity Amount Base")]),
        ],
        inputs=[
            ("18", "Portfolio Transaction", ["Portfolio Transaction ID", "Transaction Portfolio", "Portfolio Transaction Type", "Transaction Instrument",
                                             "Trade Date", "Contractual Settlement Date", "Transaction Quantity", "Transaction Price",
                                             "Transaction Currency", "Principal Amount", "Accrued Interest Amount", "Net Settlement Amount",
                                             "Trade FX Rate", "Net Amount Base", "Executing Broker", "Transaction Counterparty",
                                             "Source Allocation ID", "Source Corporate Action Event", "Related Transition Event",
                                             "Related Capital Activity", "Settlement Confirmed Indicator"]),
            ("18", "Transaction Cost & Charge", ["Commission Amount", "Research Payment Component", "Exchange and Clearing Fee Amount",
                                                 "Transaction Tax Amount", "Total Explicit Cost",
                                                 "Costs Capitalized Indicator"]),
            ("18", "Portfolio Transaction Event", ["Event Transaction", "Portfolio Transaction Event Type", "Event Timestamp", "Amendment Reason",
                                                   "Rebooked As Transaction", "Event Source System", "Back-Dated Indicator"]),
            ("18", "Portfolio Capital Activity", ["Activity Portfolio", "Activity Share Class", "Activity Account", "Capital Activity Type",
                                                  "Activity Trade Date", "Activity Settlement Date", "Activity Amount Base", "Activity Data Basis",
                                                  "Capital Activity Source", "Source Cash Flow Notification", "In-Kind Activity Indicator"]),
            ("18", "Portfolio", ["Portfolio ID", "Base Currency", "Business Line"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-140", "DP-143", "DP-004", "DP-093", "DP-097", "DP-099", "DP-240", "DP-115"],   # DP-115 restored at E1 merge: the candidate listed it (broker and counterparty roles)
        refresh="Intraday",
        timeliness="Each booking and amendment within 15 minutes of entry in the IBOR; the day's set complete by 8pm ET on trade date and final by the 6am ET start-of-day cut-off on T+1",
        history="Every transaction and every event in its trail kept for 10 years after the portfolio terminates (books and records); canceled and superseded bookings kept, never deleted",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Event stream", "API", "BI semantic model"],
        dq_rules=[
            "Every Portfolio Transaction resolves to a Portfolio in DP-140 and, unless it is a cash-only type (Fee / Expense, Cash Transfer In, Cash Transfer Out), to an Instrument in DP-097.",
            "Contractual Settlement Date is on or after Trade Date, and Net Amount Base = Net Settlement Amount x Trade FX Rate within 0.01 base currency where Transaction Currency differs from the portfolio Base Currency.",
            "Every Portfolio Transaction has a Booked event, and a transaction with a Canceled event has no later Booked event (a correction is a Rebooked As Transaction).",
            "Every booking of type Corporate Action - Securities or Corporate Action - Cash names a Source Corporate Action Event that resolves in DP-099.",
            "Every Portfolio Capital Activity names an Activity Share Class for a pooled fund book or an Activity Account for a mandate or SMA book, and an In-Kind Transfer In or Out transaction names the Related Capital Activity it settles.",
        ],
        notes=("W1b: Transaction Cost & Charge.Cost Categories Applied dropped, no successor (CW-918); it held the MiFID II cost reporting categories, and no measure read it. "
               "Master concept: 'Portfolio Transaction', 18, PTXN- of CONCEPT_OWNERSHIP; 'Transaction' bare stays 06 (shareholder "
               "transaction). Certified numbers: none. Portfolio Capital Activity is never published as flows: net flows stay certified "
               "in DP-008 and are never re-derived from it (CD-292, CD-320). "
               "Operating model (CD-297, CD-147): drafted in house. If the middle office is outsourced the grain is unchanged and the "
               "bookings arrive from the provider's IBOR file; DP-150 carries the provider breaks and SLA results. "
               "Copies read as held in 18 (brief §6 item 7): Commission Amount and Research Payment Component are Derived copies (25, "
               "CD-174), Trade FX Rate a Derived copy (22 or 25 by the CD-168 row rule) and Settlement Confirmed Indicator a Derived "
               "copy (26, CD-181). Each is the value applied to this booking, so the relationship lives in 18 (rule 2 exception); "
               "settlement detail itself is read from DP-151, a consumer product, and is therefore not upstream. Trade allocations "
               "arrive from the Investment brief's order and execution product (25); only Source Allocation ID is carried here. "
               "Upstream: the candidate listed DP-115 Approved Broker & Counterparty Master for Executing Broker and Transaction "
               "Counterparty; this spec takes them as the 02 party key from DP-240 instead, as the assignment's upstream list "
               "directs. DP-141 -> DP-115 would be acyclic (DP-115 reads DP-147, which reads DP-140), so the program lead may add it. "
               "PII = Y: transactions and capital activity of individuals' SMA books are personal financial data (18 overview); "
               "Event Performed By is not published. "
               "Taxonomy gap: Transaction Cost & Charge carries no currency attribute; costs are taken to be in Transaction Currency. "
               "Open SME questions (18 Source_Notes): whether capitalized transaction costs apply to funds as well as SMAs and whether "
               "research payments are still bundled in commissions for any book (question 11). "
               "Rests on CD-146, CD-168, CD-174, CD-181, CD-292, CD-297, CD-320."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-142": dict(
        definition=("What each portfolio holds by holding view and date, valued from approved prices and FX rates, with "
                    "derivative and fund-interest detail, open tax lots and lot relief, cash balances and projected cash, the "
                    "locked position snapshots and the IBOR valuation summary. It publishes the concepts 'Portfolio Holding', "
                    "18, HLD- and 'Tax Lot', 18, LOT- of CONCEPT_OWNERSHIP (CD-146) without remastering them, and is the "
                    "conformed holdings set that risk, performance, compliance, fund filings and portfolio management read. It "
                    "publishes 'Portfolio Market Value (IBOR)', which is not certified and is never labeled or published as AUM "
                    "(CD-292, CD-320): Firm AUM is DP-241's and client assets DP-008's."),
        business_questions=[
            "What does each portfolio hold at start and end of day, at what market value, cost and weight, and in which tax lots?",
            "What is each book's Portfolio Market Value (IBOR), and does it tie to the sum of its holdings, cash and accrued income?",
            "Which holdings were valued at a price that is not the approved price for the date, or at a stale price?",
            "What realized and unrealized gains does each portfolio carry, short- and long-term, and where were wash-sale losses disallowed?",
            "What cash does each portfolio have by currency and account, which accounts are overdrawn, and what cash is projected over the next five days?",
            "Which portfolios have no locked end-of-day or month-end snapshot, or a snapshot with an open control break?",
        ],
        grain="Portfolio x instrument x holding date x holding view (HLD-); with tax lot (portfolio x instrument x acquisition lot, current state, history through lot relief), cash balance (portfolio x currency x cash account x balance date x balance type), projected cash movement and portfolio valuation summary (portfolio x valuation as-of date x valuation view) as companion facts; daily snapshots",
        dimensions=["Portfolio", "Business line", "Instrument", "Asset class", "Holding date", "Holding view", "Long / short",
                    "Tax lot", "Holding period term", "Currency", "Cash safekeeping account", "Cash balance type", "Snapshot type", "Data basis"],
        measures=[
            ("Holdings Market Value Base", "Sum of Market Value Base over Portfolio Holdings for the portfolio, holding date and Holding View, short positions negative (Long / Short Indicator).",
             [("18", "Holding Valuation", "Market Value Base"), ("18", "Portfolio Holding", "Long / Short Indicator"),
              ("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Holding Date"), ("18", "Portfolio Holding", "Holding View")]),
            ("Portfolio Market Value (IBOR)", "Total IBOR Market Value of the Portfolio Valuation Summary for the portfolio, Valuation As-Of Date and Valuation View End of Day, from the summary of the locked snapshot (Summary Snapshot). Not certified, never labeled AUM; an input to the DP-241 Firm AUM Institutional Slice only.",
             [("18", "Portfolio Valuation Summary", "Total IBOR Market Value"), ("18", "Portfolio Valuation Summary", "Valuation As-Of Date"),
              ("18", "Portfolio Valuation Summary", "Valuation View"), ("18", "Portfolio Valuation Summary", "Summary Snapshot"),
              ("18", "Portfolio Valuation Summary", "Valued Portfolio")]),
            ("Valuation Summary Tie-Out", "Total IBOR Market Value - (Total Holdings Market Value + Total Cash Balance + Total Accrued Income), and Total Holdings Market Value - Holdings Market Value Base, for the same portfolio, date and view; each flagged when not zero within 0.01 base currency.",
             [("18", "Portfolio Valuation Summary", "Total IBOR Market Value"), ("18", "Portfolio Valuation Summary", "Total Holdings Market Value"),
              ("18", "Portfolio Valuation Summary", "Total Cash Balance"), ("18", "Portfolio Valuation Summary", "Total Accrued Income"),
              "Holdings Market Value Base", "Portfolio Market Value (IBOR)"]),
            ("Holdings at Approved Price %", "Portfolio Holdings whose Price Used equals the Approved Price Value of the Approved Price with Price Approval Status = Approved for the Held Instrument and Price Date at the portfolio's pricing point / all priced holdings, for the end-of-day view.",
             [("18", "Holding Valuation", "Price Used"), ("18", "Holding Valuation", "Price Date"), ("18", "Portfolio Holding", "Held Instrument"),
              ("22", "Approved Price", "Priced Instrument"), ("22", "Approved Price", "Price Date"), ("22", "Approved Price", "Approved Price Value"),
              ("22", "Approved Price", "Approved Pricing Point"), ("22", "Approved Price", "Price Approval Status")]),
            ("Stale Priced Holdings", "Count and Market Value Base of end-of-day holdings whose Price Date is earlier than the Holding Date, or whose Price Source is Prior Price Carried Forward.",
             [("18", "Holding Valuation", "Price Date"), ("18", "Holding Valuation", "Price Source"), ("18", "Holding Valuation", "Market Value Base"),
              ("18", "Portfolio Holding", "Holding Date")]),
            ("Unrealized Gain / Loss Base", "Market Value Base - Holding Cost Base per holding, summed by portfolio and asset class.",
             [("18", "Holding Valuation", "Market Value Base"), ("18", "Holding Valuation", "Holding Cost Base")]),
            ("Realized Gain / Loss Base", "Sum of Realized Gain / Loss Base over Lot Relief rows whose Closing Transaction trades in the period, by Holding Period Term; Wash-Sale Loss Disallowed reported beside it.",
             [("18", "Lot Relief", "Realized Gain / Loss Base"), ("18", "Lot Relief", "Holding Period Term"), ("18", "Lot Relief", "Closing Transaction"),
              ("18", "Lot Relief", "Wash-Sale Loss Disallowed")]),
            ("Lot to Holding Quantity Break", "Absolute difference between the sum of Remaining Quantity over Tax Lots with Lot Closed Indicator = N for the Lot Portfolio and Lot Instrument and the end-of-day Holding Quantity of the same portfolio and instrument; counted where not zero.",
             [("18", "Tax Lot", "Remaining Quantity"), ("18", "Tax Lot", "Lot Closed Indicator"), ("18", "Tax Lot", "Lot Portfolio"),
              ("18", "Tax Lot", "Lot Instrument"), ("18", "Portfolio Holding", "Holding Quantity")]),
            ("Delta-Adjusted Exposure Base", "Sum of Delta-Adjusted Exposure Base and of Notional Amount Base over derivative holdings, by portfolio and instrument type.",
             [("18", "Derivative Holding Detail", "Delta-Adjusted Exposure Base"), ("18", "Derivative Holding Detail", "Notional Amount Base")]),
            ("Unfunded Commitments", "Sum of Unfunded Commitment over fund-interest holdings at the holding date, by portfolio.",
             [("18", "Fund Interest Holding Detail", "Unfunded Commitment")]),
            ("Overdrawn Cash Accounts", "Count and Balance Amount Base of Cash Balance rows with Cash Balance Type = Settled and Balance Amount Local below zero on the balance date.",
             [("18", "Cash Balance", "Cash Balance Type"), ("18", "Cash Balance", "Balance Amount Local"), ("18", "Cash Balance", "Balance Amount Base")]),
            ("Projected Net Cash", "Sum of Projected Amount with Projected Flow Direction = Inflow minus Projected Amount with Outflow, by portfolio, Projected Currency and Projected Value Date for the next five business days.",
             [("18", "Projected Cash Movement", "Projected Amount"), ("18", "Projected Cash Movement", "Projected Flow Direction"),
              ("18", "Projected Cash Movement", "Projected Currency"), ("18", "Projected Cash Movement", "Projected Value Date")]),
            ("Locked Snapshot Coverage %", "Portfolios with a Portfolio Position Snapshot of Snapshot Type End of Day, Snapshot Locked Indicator = Y and Snapshot Control Status in (Reconciled, Reconciled within Tolerance) for the business date / portfolios with holdings on that date.",
             [("18", "Portfolio Position Snapshot", "Snapshot Type"), ("18", "Portfolio Position Snapshot", "Snapshot Locked Indicator"),
              ("18", "Portfolio Position Snapshot", "Snapshot Control Status"), ("18", "Portfolio Position Snapshot", "Snapshot Business Date"),
              ("18", "Portfolio Position Snapshot", "Snapshot Portfolio")]),
        ],
        inputs=[
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View", "Holding As-Of Timestamp",
                                         "Holding Quantity", "Quantity Unit", "Long / Short Indicator", "Settled Quantity", "Unsettled Quantity",
                                         "Encumbered Quantity", "Corresponding Shareholder Position"]),
            ("18", "Holding Valuation", ["Price Used", "Price Date", "Price Source", "Market Value Local", "Holding FX Rate", "Market Value Base",
                                         "Accrued Income Base", "Holding Cost Base", "Holding Weight"]),
            ("18", "Derivative Holding Detail", ["Number of Contracts", "Notional Amount Base", "Delta Used", "Delta-Adjusted Exposure Base",
                                                 "Initial Margin Posted", "OTC Counterparty", "Clearing Broker"]),
            ("18", "Fund Interest Holding Detail", ["Commitment Amount", "Called Capital to Date", "Recallable Distributions", "Unfunded Commitment",
                                                    "Distributions Received to Date", "GP Reported NAV", "GP Statement Date", "Adjusted NAV"]),
            ("18", "Tax Lot", ["Tax Lot ID", "Lot Portfolio", "Lot Instrument", "Opening Transaction", "Lot Open Date", "Original Quantity",
                               "Remaining Quantity", "Original Cost Local", "Original Cost Base", "Wash-Sale Basis Adjustment",
                               "Adjusted Cost Basis Base", "Holding Period Start Date", "Lot Closed Indicator"]),
            ("18", "Lot Relief", ["Relieved Tax Lot", "Closing Transaction", "Relief Method Applied", "Relieved Quantity",
                                  "Relieved Cost Base", "Relief Proceeds Base", "Realized Gain / Loss Base", "Holding Period Term",
                                  "Wash-Sale Loss Disallowed", "Wash-Sale Replacement Lot"]),
            ("18", "Cash Balance", ["Cash Balance Portfolio", "Balance Currency", "Cash Safekeeping Account", "Cash Account Purpose", "Cash Custodian",
                                    "Balance Date", "Cash Balance Type", "Balance Amount Local", "Cash FX Rate", "Balance Amount Base"]),
            ("18", "Projected Cash Movement", ["Projection Portfolio", "Projected Currency", "Projected Value Date", "Projected Cash Source",
                                               "Projected Amount", "Projected Flow Direction", "Projection Data Basis", "Source Portfolio Transaction",
                                               "Source Corporate Action Event"]),
            ("18", "Portfolio Position Snapshot", ["Snapshot Portfolio", "Snapshot Type", "Snapshot Holding View", "Snapshot Business Date",
                                                   "Snapshot As-Of Timestamp", "Snapshot Locked Indicator", "Snapshot Control Status",
                                                   "Snapshot Restated Indicator"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Valuation Period Type",
                                                   "Total Holdings Market Value", "Total Cash Balance", "Total Accrued Income",
                                                   "Total IBOR Market Value", "Summary Data Basis", "Summary Snapshot"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date", "Approved Price Value",
                                      "Price Approval Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-140", "DP-141", "DP-143", "DP-097", "DP-099", "DP-167"],
        refresh="Daily",
        timeliness="Start-of-day view by 6:30am ET each business day; end-of-day view by 9pm ET on the business date; locked end-of-day snapshot and valuation summary by 7am ET on T+1; month-end lock by business day 2",
        history="Daily end-of-day and start-of-day holdings and cash kept for 10 years; month-end and quarter-end locked snapshots kept indefinitely with every restated version; tax lots kept in current state with full Lot Relief history",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract"],
        dq_rules=[
            "Each portfolio x instrument x holding date x Holding View has exactly one Portfolio Holding, and Settled Quantity + Unsettled Quantity = Holding Quantity.",
            "Market Value Base = Market Value Local x Holding FX Rate within 0.01 base currency, and Holding Weight sums to 100% within 0.01% per portfolio, holding date and view.",
            "Total IBOR Market Value = Total Holdings Market Value + Total Cash Balance + Total Accrued Income for every Portfolio Valuation Summary.",
            "For every end-of-day holding the sum of Remaining Quantity of open Tax Lots equals Holding Quantity, and Remaining Quantity of a lot never exceeds its Original Quantity.",
            "Every Cash Safekeeping Account resolves to an open Safekeeping Account in DP-167, and every holding's Holding Portfolio and Held Instrument resolve in DP-140 and DP-097.",
            "A Portfolio Position Snapshot with Snapshot Locked Indicator = Y changes only through a new snapshot with Snapshot Restated Indicator = Y.",
        ],
        notes=("W1b: Tax Lot.Pooled Lot Indicator and Lot Relief.UK Matching Rule Applied dropped, no successor (CW-918); the UK section 104 pooling and same-day and 30-day matching rules have no US book, and no measure read them. "
               "Master concepts: 'Portfolio Holding', 18, HLD- and 'Tax Lot', 18, LOT- (CD-146); the holding is never called "
               "'Position' bare. Certified numbers: none. Portfolio Market Value (IBOR) is published under that name only, is not "
               "certified and is never labeled AUM (CD-292, CD-320; brief hardest call 1); its portfolio valuation summaries feed "
               "the Firm AUM Institutional Slice of DP-241, which reconciles Firm AUM to Client Assets (DP-008). No AUM measure may be added here. "
               "Operating model (CD-297, CD-147): drafted in house. If the middle office is outsourced the grain stays portfolio x "
               "instrument x date x view, sourced from the provider's IBOR file, and DP-150 carries the oversight measures "
               "(provider breaks, SLA results, differences against the firm's snapshot). "
               "Copies read as held in 18, because the value applied to the holding lives on the holding (rule 2 exception, brief §6 "
               "item 7): Price Used, Price Date, Price Source, Holding FX Rate, Cash FX Rate (22, CD-167, CD-168), Delta Used (22), "
               "Encumbered Quantity and Initial Margin Posted (26, CD-181), Adjusted NAV (22, CD-170). Holdings at Approved Price % "
               "compares Price Used with the 22 master, read through DP-143. Fund Interest Holding Detail values for own private "
               "funds are proposed as Derived copies (30) by a deferred row rule; until it is applied they are read as held. "
               "Holding views published: Start of Day and End of Day only (18 SME question 6, brief question 6); intraday views stay "
               "in the IBOR. Projected Cash Movement feeds the 24 investable cash forecast (CD-178). Position Adjustment is not "
               "published here; DP-150 reads it as IBOR control evidence. "
               "PII = Y: holdings, lots and cash of individuals' SMA books are personal financial data (18 overview); publish a view "
               "without them for wide use. "
               "Taxonomy gap: Portfolio Holding carries no pricing point, so Holdings at Approved Price % takes the pricing point "
               "from the portfolio's business line convention (Fund NAV Valuation Point for pooled funds, SMA Month-End Valuation for "
               "SMAs) until 18 records it. "
               "Open SME questions (18 Source_Notes): whether fund-of-funds and master-feeder look-through holdings are stored or "
               "derived (question 4); lot relief methods by line and jurisdiction (question 5); whether the valuation summary is used "
               "officially anywhere (question 10). "
               "Rests on CD-146, CD-167, CD-168, CD-170, CD-178, CD-181, CD-292, CD-297, CD-320, CD-321."
               "WP1 re-point (CW-206): Firm AUM moved from DP-165 to DP-241 and DP-008 publishes Client Assets instead of attributed AUM; the texts naming them are re-pointed. DP-241 no longer reads 'Portfolio Market Value (from DP-142)' as a cause; it reads the 18 Portfolio Valuation Summary for its institutional slice. No input or measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-143": dict(
        definition=("The approved price of every instrument at every pricing point and date, with its fair value level, basis, "
                    "overrides and the approved fair value determinations behind Level 3 marks; FX rate observations; reference "
                    "rate fixings; curves and volatility surfaces; approved pricing analytics and instrument factors; and the "
                    "Rule 6c-11 market statistics of own ETFs. It publishes the 22 concepts Approved Price (PRICE-), Fair Value "
                    "Determination (FVD-), FX Rate Observation (FXR-), Reference Rate Fixing, Curve Definition (CURVE-) and ETF "
                    "Market Statistic of CONCEPT_OWNERSHIP (CD-167, CD-168, CD-170, CD-206) without remastering them, so that "
                    "every valuation in the firm (IBOR, NAV, risk, collateral, performance and the general ledger) applies these "
                    "values by reference instead of sourcing its own. It owns no certified number."),
        business_questions=[
            "What is the approved price of each instrument at each pricing point today, on what basis and fair value level, and which version is current?",
            "Which approved prices are stale, overridden, carried forward or Level 3 without an approved fair value determination?",
            "Which prices were restated after first approval, and which own-fund rows carry a NAV record and swung price?",
            "Which FX rates, fixings and curve points are missing or fell back for a rate type and date?",
            "What were each own ETF's market price, premium or discount and 30-day median bid-ask spread, and has it traded beyond a 2% premium or discount for seven consecutive days?",
        ],
        grain="Instrument x pricing point x price date x approved price version (one current version per instrument x pricing point x price date); with FX rate observation (rate type x currency pair x rate basis x tenor x as-of timestamp), reference rate fixing, curve point, volatility surface point, pricing analytics, instrument factor and ETF market statistic as companion facts",
        dimensions=["Instrument", "Asset class", "Pricing point", "Price date", "Approved price basis", "Fair value hierarchy level",
                    "Price approval status", "Currency", "FX rate type and currency pair", "Reference rate and tenor", "Curve",
                    "Pricing analytic measure", "Pricing operating model"],
        measures=[
            ("Approved Prices Published", "Count of current Approved Price rows (highest Approved Price Version per Priced Instrument x Approved Pricing Point x Price Date) with Price Approval Status = Approved, by pricing point and Approved Price Basis.",
             [("22", "Approved Price", "Approved Price ID"), ("22", "Approved Price", "Approved Price Version"), ("22", "Approved Price", "Priced Instrument"),
              ("22", "Approved Price", "Approved Pricing Point"), ("22", "Approved Price", "Price Date"), ("22", "Approved Price", "Price Approval Status"),
              ("22", "Approved Price", "Approved Price Basis")]),
            ("Price Approval Completeness %", "Approved Prices Published / all current Approved Price rows for the pricing point and date, measured at the pricing point's Snap Time plus the approval window.",
             [("22", "Pricing Point", "Snap Time"), ("22", "Approved Price", "Price Approval Timestamp"), "Approved Prices Published"]),
            ("Fair Value Level Mix", "Share of Approved Prices Published by Approved Price Fair Value Level (Level 1, Level 2, Level 3, NAV Practical Expedient), by asset class.",
             [("22", "Approved Price", "Approved Price Fair Value Level"), ("17", "Instrument", "Asset Class"), "Approved Prices Published"]),
            ("Level 3 Without Approved Determination", "Count of Approved Prices Published with Approved Price Fair Value Level = Level 3 whose Applied Fair Value Determination is null or resolves to a Fair Value Determination with Determination Approval Status other than Approved.",
             [("22", "Approved Price", "Approved Price Fair Value Level"), ("22", "Approved Price", "Applied Fair Value Determination"),
              ("22", "Fair Value Determination", "Fair Value Determination ID"), ("22", "Fair Value Determination", "Determination Approval Status"),
              "Approved Prices Published"]),
            ("Overridden and Carried-Forward Share", "Approved Prices Published with Approved Price Basis in (Price Override, Prior Price Carried Forward) / Approved Prices Published, by pricing point.",
             [("22", "Approved Price", "Approved Price Basis"), ("22", "Approved Price", "Applied Price Override"), "Approved Prices Published"]),
            ("Stale Prices", "Count of Approved Prices Published whose Underlying Market Date is more than one business day (Pricing Calendar) before the Price Date.",
             [("22", "Approved Price", "Underlying Market Date"), ("22", "Approved Price", "Price Date"), ("22", "Pricing Point", "Pricing Calendar"),
              "Approved Prices Published"]),
            ("Restated Prices", "Count of Approved Price rows with Approved Price Version above 1 (Supersedes Approved Price filled), by Version Effective Timestamp date and pricing point.",
             [("22", "Approved Price", "Approved Price Version"), ("22", "Approved Price", "Supersedes Approved Price"),
              ("22", "Approved Price", "Version Effective Timestamp")]),
            ("FX Fallback Rate", "FX Rate Observation rows with Fallback Applied Indicator = Y / all rows with FX Observation Status = Final, by Observed FX Rate Type and FX Rate Date.",
             [("22", "FX Rate Observation", "Fallback Applied Indicator"), ("22", "FX Rate Observation", "FX Observation Status"),
              ("22", "FX Rate Observation", "Observed FX Rate Type"), ("22", "FX Rate Observation", "FX Rate Date")]),
            ("Missing Fixings", "Count of Fixed Reference Rate x Fixing Tenor combinations fixed on the prior business day with no Reference Rate Fixing of Fixing Observation Status = Final for the Fixing Date.",
             [("22", "Reference Rate Fixing", "Fixed Reference Rate"), ("22", "Reference Rate Fixing", "Fixing Tenor"),
              ("22", "Reference Rate Fixing", "Fixing Date"), ("22", "Reference Rate Fixing", "Fixing Observation Status")]),
            ("ETF Premium / Discount Run", "Per own ETF instrument, the count of consecutive Statistic Dates up to the as-of date with absolute Premium / Discount above 2%; flagged at 7 or more (Rule 6c-11 website disclosure trigger).",
             [("22", "ETF Market Statistic", "ETF Instrument"), ("22", "ETF Market Statistic", "Statistic Date"),
              ("22", "ETF Market Statistic", "Premium / Discount")]),
        ],
        inputs=[
            ("22", "Pricing Policy", ["Pricing Policy Code", "Pricing Policy Version", "Pricing Operating Model", "Outsourced Pricing Provider",
                                      "Policy Approval Status", "Policy Effective From", "Policy Effective To"]),
            ("22", "Pricing Point", ["Pricing Point Code", "Pricing Point Purpose", "Snap Time", "Pricing Calendar", "Pricing Point Frequency",
                                     "Pricing Point Status"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date", "Approved Price Version",
                                      "Version Effective Timestamp", "Supersedes Approved Price", "Approved Price Value", "Own Fund Swung Price",
                                      "Own Fund Swing Decision", "Approved Price Currency", "Approved Price Quote Basis", "Approved Price Basis",
                                      "Approved Price Fair Value Level", "Selected Observation", "Underlying Market Date", "Applied Price Override",
                                      "Applied Fair Value Determination", "Applied Fair Value Factor", "Own Fund NAV Record",
                                      "Price Approval Status", "Price Approval Timestamp"]),
            ("22", "Fair Value Determination", ["Fair Value Determination ID", "Fair Valued Instrument", "Valuation Date", "Determination Pricing Point",
                                                "Valued Portfolio", "Fair Value Method", "Fair Value Hierarchy Level", "Fair Value per Unit",
                                                "Fair Value Amount", "Fair Value Currency", "Valuation Model Name", "Determination Approval Status",
                                                "Approving Meeting"]),
            ("22", "FX Rate Observation", ["FX Rate Observation ID", "Observed FX Rate Type", "FX Rate Basis", "Base Currency", "Quote Currency",
                                           "FX Rate Tenor", "FX As-Of Timestamp", "FX Rate Date", "Rate Period Start", "Rate Period End",
                                           "Spot Rate", "Forward Points", "Forward Outright Rate", "Period Rate", "Fallback Applied Indicator",
                                           "FX Observation Status"]),
            ("22", "Reference Rate Fixing", ["Fixed Reference Rate", "Fixing Tenor", "Fixing Value Type", "Fixing Date", "Fixing Value",
                                             "Rate Administrator", "Fixing Source Dataset", "Fixing Observation Status"]),
            ("22", "Curve Definition", ["Curve ID", "Curve Type", "Curve Currency", "Curve Reference Rate", "Surface Underlying Instrument",
                                        "Surface Underlying Benchmark", "Interpolation Method", "Curve Source Dataset", "Curve Status"]),
            ("22", "Curve Point Observation", ["Observed Curve", "Curve As-Of Date", "Curve Point Tenor", "Curve Point Value Type", "Curve Point Value"]),
            ("22", "Volatility Surface Point", ["Observed Surface", "Surface As-Of Date", "Expiry Tenor", "Strike Coordinate", "Strike Unit",
                                                "Implied Volatility"]),
            ("22", "Pricing Analytics Observation", ["Analytics Instrument", "Analytics As-Of Date", "Pricing Analytic Measure", "Analytic Measure Value",
                                                     "Analytics Source Dataset", "Analytics Source Rank", "Approved Analytics Value Indicator"]),
            ("22", "Instrument Factor Observation", ["Factor Observation Instrument", "Instrument Factor Type", "Factor Effective Date",
                                                     "Instrument Factor Value", "Factor Source Party"]),
            ("22", "ETF Market Statistic", ["ETF Instrument", "Statistic Date", "Primary Listing Exchange", "ETF Closing Price", "NBBO Midpoint at NAV Time",
                                            "ETF Market Price", "ETF Market Price Type", "Premium / Discount NAV", "Premium / Discount",
                                            "30-Day Median Bid-Ask Spread", "Intraday Quote Source Dataset"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Instrument Status", "Own Share Class"]),
        ],
        upstream=["DP-097", "DP-013", "DP-140", "DP-240"],
        refresh="Intraday",
        timeliness="Approved prices for each pricing point within 90 minutes of its Snap Time (the 4pm ET Fund NAV Valuation Point by 5:30pm ET); FX rates and fixings within 30 minutes of the fixing time; curves, analytics and ETF statistics by 7am ET on T+1",
        history="Every approved price version, FX observation, fixing, curve point and ETF statistic kept for 10 years (Rule 2a-5 and Rule 31a-2 record keeping); fair value determinations kept indefinitely",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "API", "Event stream", "BI semantic model"],
        dq_rules=[
            "Exactly one Approved Price version with Price Approval Status = Approved is current per Priced Instrument x Approved Pricing Point x Price Date, and each later version names the version it supersedes.",
            "Every Approved Price with Approved Price Fair Value Level = Level 3 names an Applied Fair Value Determination whose Determination Approval Status is Approved for the same instrument, valuation date and pricing point.",
            "Every Approved Price of an instrument with Own Share Class filled has Approved Price Basis = Own Fund NAV and an Own Fund NAV Record; no other instrument has an Own Fund NAV Record.",
            "Approved Price Value, Spot Rate, Fixing Value and Curve Point Value are never null or negative except where the instrument type, rate or curve allows negative values (rates, spreads, swaps).",
            "FX rates are published only for the currency pair as quoted (Base Currency x Quote Currency); no row holds a computed inverse or cross (CD-168).",
            "Every Priced Instrument, Fair Valued Instrument and ETF Instrument resolves to an Instrument in DP-097, and every Pricing Calendar and Observed FX Rate Type to DP-013.",
        ],
        notes=("Master concepts: Approved Price (PRICE-), Fair Value Determination (FVD-), FX Rate Observation (FXR-), Reference "
               "Rate Fixing, Curve Definition (CURVE-) and ETF Market Statistic, 22 (CD-167, CD-168, CD-170, CD-206). Certified "
               "numbers: none. "
               "Dependency direction (CD-321, brief hardest call 2): own fund share class rows carry the 27 NAV as the 22 record holds "
               "it (Approved Price Value, Approved Price Currency, Own Fund Swung Price, Own Fund Swing Decision and Own Fund NAV Record "
               "are Derived copies (27) on those rows; Premium / Discount NAV likewise), so DP-165 NAV & Fund Financials is downstream "
               "of this product and is never listed upstream. "
               "Operating model (CD-297): drafted in house. Pricing Policy 'Pricing Operating Model' records the model; if pricing is "
               "outsourced to a fund administrator, the grain is unchanged, the approved price is received from the provider and "
               "approved by the firm, and DP-148 holds the provider's exceptions and challenges. "
               "Valued Portfolio on a Fair Value Determination resolves through DP-140 (mandatory for private fund interests); rate "
               "administrators, pricing providers and factor sources through DP-240. Price observations, tolerance rules, validation "
               "exceptions, overrides in workflow and challenges are not published here; DP-148 reads them. Vendor dataset "
               "entitlements are DP-044's and are not upstream (consumer product). "
               "Classification Confidential - Licensed: vendor prices, FX rates and curves may be redistributed only under the 14 "
               "permitted uses (DP-044); Price Approved By and other approver names are not published, so PII = N. "
               "Coverage of held instruments (every holding has a price) is measured in DP-142 and DP-148, not here, because this "
               "product may not depend on holdings. "
               "Open SME questions (22 Source_Notes): whether pricing is outsourced for any line (question 1); whether an own share "
               "class held by an own portfolio is always priced at the NAV or at the exchange price for own ETFs, and whether any "
               "policy values own fund holdings at the swung price (question 9); whether intraday prices are persisted (question 11); "
               "the rule that sets the fair value level where no determination exists (question 14). "
               "Rests on CD-167, CD-168, CD-170, CD-206, CD-297, CD-321."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-144": dict(
        definition=("Daily levels of every benchmark and index the firm references, by index level variant (price, net total or "
                    "gross total return) and currency, with constituents, weights and announced index changes, all keyed by the "
                    "01 Benchmark. It publishes the concept 'Index Level Observation / Index Constituent / Index Change "
                    "Announcement', 22 of CONCEPT_OWNERSHIP (CD-169 option A) without remastering it, as the single index data set "
                    "for benchmark returns, attribution, index-relative risk and compliance rules, and ETF and index-fund "
                    "rebalancing. It owns no certified number: benchmark returns are computed and certified in DP-145 (CD-217, "
                    "CD-320)."),
        business_questions=[
            "Do we have a final level for every benchmark assigned to a product, in each return variant and currency, for every business day?",
            "What are the constituents and weights of each index on a date, and do the weights sum to 100%?",
            "Which constituents do not resolve to an active instrument in the security master?",
            "Which additions, deletions and rebalances are announced for the indices our index funds and ETFs track, and when are they effective?",
            "Which index levels moved by an unusual amount from the prior day and need checking before benchmark returns are calculated?",
        ],
        grain="01 benchmark x level date x index level variant x level currency (index level); with index constituent (benchmark x instrument x effective date) and index change announcement (benchmark x instrument x change type x effective date x announcement date) as companion facts",
        dimensions=["Benchmark", "Benchmark administrator", "Index level variant", "Level currency", "Level date", "Constituent instrument",
                    "Index change type", "Change effective date", "Benchmark role", "Source dataset"],
        measures=[
            ("Assigned Benchmark Level Coverage %", "Benchmarks with Blended Benchmark Indicator = N and a Product Benchmark Assignment effective on the level date that have an Index Level Observation with Index Level Status = Final for every Index Level Variant and Level Currency required, / all such benchmarks.",
             [("01", "Benchmark", "Benchmark ID"), ("01", "Benchmark", "Blended Benchmark Indicator"),
              ("01", "Product Benchmark Assignment", "Assigned Benchmark"), ("01", "Product Benchmark Assignment", "Assignment Effective From"),
              ("01", "Product Benchmark Assignment", "Assignment Effective To"), ("22", "Index Level Observation", "Index Benchmark"),
              ("22", "Index Level Observation", "Level Date"), ("22", "Index Level Observation", "Index Level Variant"),
              ("22", "Index Level Observation", "Level Currency"), ("22", "Index Level Observation", "Index Level Status")]),
            ("Missing Level Days", "Count of benchmark x variant x currency x business day combinations in the period with no Final Index Level Observation, by Benchmark Administrator.",
             [("22", "Index Level Observation", "Index Level Status"), ("22", "Index Level Observation", "Level Date"),
              ("01", "Benchmark", "Benchmark Administrator")]),
            ("Level Jump Flag", "Y when |Index Level Value / prior business day's Index Level Value - 1| exceeds 10% for the same benchmark, variant and currency; a data check only, never published as a benchmark return.",
             [("22", "Index Level Observation", "Index Level Value"), ("22", "Index Level Observation", "Index Benchmark"),
              ("22", "Index Level Observation", "Index Level Variant"), ("22", "Index Level Observation", "Level Currency")]),
            ("Constituent Weight Sum", "Sum of Constituent Weight per Constituent Benchmark x Constituent Effective Date; flagged when not 100% within 0.01%.",
             [("22", "Index Constituent", "Constituent Weight"), ("22", "Index Constituent", "Constituent Benchmark"),
              ("22", "Index Constituent", "Constituent Effective Date")]),
            ("Constituent Count", "Count of distinct Constituent Instrument per benchmark and effective date.",
             [("22", "Index Constituent", "Constituent Instrument"), ("22", "Index Constituent", "Constituent Benchmark")]),
            ("Unresolved Constituent Rate", "Index Constituent rows whose Constituent Instrument does not resolve to an Instrument with Instrument Status active in DP-097 (only a Vendor Constituent Identifier is held) / all constituent rows, by benchmark.",
             [("22", "Index Constituent", "Constituent Instrument"), ("22", "Index Constituent", "Vendor Constituent Identifier"),
              ("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Instrument Status")]),
            ("Upcoming Index Changes", "Count of Index Change Announcements with Change Effective Date in the next 10 business days and Change Announcement Status not Withdrawn, by Index Change Type and benchmark.",
             [("22", "Index Change Announcement", "Change Effective Date"), ("22", "Index Change Announcement", "Change Announcement Status"),
              ("22", "Index Change Announcement", "Index Change Type"), ("22", "Index Change Announcement", "Changed Benchmark")]),
        ],
        inputs=[
            ("22", "Index Level Observation", ["Index Benchmark", "Level Date", "Index Level Variant", "Level Currency", "Index Level Value",
                                               "Index Level Status", "Index Level Source Dataset"]),
            ("22", "Index Constituent", ["Constituent Benchmark", "Constituent Instrument", "Vendor Constituent Identifier", "Constituent Effective Date",
                                         "Constituent Weight", "Constituent Source Dataset"]),
            ("22", "Index Change Announcement", ["Changed Benchmark", "Index Change Type", "Affected Index Instrument", "Announcement Date",
                                                 "Change Effective Date", "Change Announcement Status", "Related Corporate Action Event",
                                                 "Change Source Dataset"]),
            ("01", "Benchmark", ["Benchmark ID", "Benchmark Name", "Benchmark Administrator", "Benchmark Currency", "Return Type",
                                 "Benchmark Hedged Indicator", "Blended Benchmark Indicator", "Blend Components",
                                 "Benchmark Vendor Code"]),
            ("01", "Product Benchmark Assignment", ["Assigned Product / Share Class", "Assigned Benchmark", "Benchmark Role",
                                                    "Assignment Effective From", "Assignment Effective To"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Status"]),
        ],
        upstream=["DP-004", "DP-013", "DP-097", "DP-099"],
        refresh="Daily",
        timeliness="Final levels by 8am ET on T+1 for US and European indices and by 10am ET for Asia-Pacific; constituents and announced changes by 7am ET on the effective date and on the announcement date",
        history="All index levels since each benchmark's first assignment, and constituents and change announcements for 10 years, with corrected levels kept as superseded rows",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "API", "File extract"],
        dq_rules=[
            "Each Index Benchmark x Level Date x Index Level Variant x Level Currency has at most one Index Level Observation with Index Level Status = Final.",
            "Every Index Benchmark, Constituent Benchmark and Changed Benchmark resolves to a Benchmark ID in 01 (through DP-004 once extended), and no level is held for a benchmark with Blended Benchmark Indicator = Y.",
            "Constituent Weight sums to 100% within 0.01% per benchmark and Constituent Effective Date.",
            "Every Constituent Instrument and Affected Index Instrument resolves to an Instrument in DP-097, and Change Effective Date is on or after Announcement Date.",
            "Every benchmark with a Product Benchmark Assignment effective on a business day has a Final level for its Return Type and Benchmark Currency by the timeliness deadline.",
        ],
        notes=("Master concept: 'Index Level Observation / Index Constituent / Index Change Announcement', 22 (CD-169 option A, "
               "keyed by the 01 Benchmark BMK-). Certified numbers: none; Level Jump Flag is a data check, and benchmark returns are "
               "certified only in DP-145 (CD-217, CD-320). "
               "The benchmark dimension needs DP-004 to carry 01 Benchmark and Product Benchmark Assignment (CD-322). Until that "
               "extension is built this product reads 01 Benchmark and Product Benchmark Assignment directly and lists DP-004 "
               "upstream; the inputs do not change when the extension lands. Blended benchmarks have no levels: their returns are "
               "built from the components in DP-145. "
               "Boundary with DP-072 Index Licensing Fees: DP-072 keeps the 14 license and fee record and stays separate; this product "
               "holds the data. Index licenses (14) set the permitted uses; constituent weights are usually restricted to internal "
               "use, so classification is Confidential - Licensed and client-report use needs the license check (brief question 8). "
               "Related Corporate Action Event resolves through DP-099. "
               "Operating model: in house (market data); a vendor feed changes the source dataset, not the grain. "
               "Taxonomy gap: 01 Benchmark has no status or end date, so a retired benchmark is recognized only by having no "
               "effective Product Benchmark Assignment. Taxonomy gap: no attribute states which variants and currencies each "
               "benchmark must be published in; coverage uses the benchmark's Return Type and Benchmark Currency. "
               "Open SME questions (22 Source_Notes): which indices are in scope and whether every constituent must be a 17 "
               "instrument (question 6). "
               "Rests on CD-169, CD-217, CD-320, CD-322. "
               "W1: BMR Register Status (01 Benchmark) dropped, no successor in the wealth 01 (CW-901); no measure read it."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-145 re-specified at WP1 in specs_w1f_certified.py
    # ------------------------------------------------------------------------------------------------------------------
    "DP-146": dict(
        definition=("Independent ex-ante risk of every portfolio: the risk models and versions used, their factors, factor "
                    "returns and instrument loadings, each risk calculation run and its approval, portfolio risk measures "
                    "(ex-ante tracking error, volatility, VaR, expected shortfall, beta), their decomposition, model-based "
                    "exposures by dimension, and VaR back-tests. It publishes the 31 concepts Risk Model, Risk Factor, Instrument "
                    "Factor Loading, Risk Calculation Run, Portfolio Risk Measure and Portfolio Exposure of CONCEPT_OWNERSHIP "
                    "(CD-211) without remastering them. It is the only source of the certified ex-ante VaR and tracking error "
                    "(CD-293, CD-320), taken from approved runs only, which limit monitoring, fund risk programs, compliance rules "
                    "and client reports read."),
        business_questions=[
            "What are the ex-ante VaR, expected shortfall, volatility, tracking error and beta of each portfolio today, from an approved run?",
            "Which factors, sectors, countries and currencies drive each portfolio's active risk?",
            "What are each portfolio's gross, net, beta-adjusted and duration exposures as a share of net assets?",
            "Which portfolios were not covered by an approved run today, or were measured on stale holdings?",
            "How many VaR back-test exceptions has each portfolio had in the window, and which are in the yellow or red zone?",
        ],
        grain="Risk calculation run x portfolio x risk measure x horizon days x confidence level x benchmark (blank for absolute); with risk decomposition (measure x risk dimension x bucket), portfolio exposure (portfolio x as-of date x run x dimension x bucket x exposure measure x benchmark) and VaR back-test (portfolio x model version x back-test date x P&L basis) as companion facts",
        dimensions=["Portfolio", "Business line", "Risk model and version", "Risk calculation run and as-of date", "Risk measure",
                    "Horizon days", "Confidence level", "Benchmark", "Risk dimension and bucket", "Risk factor", "Exposure measure",
                    "Back-test P&L basis", "Back-test zone"],
        measures=[
            ("Ex-Ante VaR", "Risk Measure Value (and Risk Measure Amount) of the Portfolio Risk Measure with Risk Measure = Value at Risk, from the Risk Calculation Run for the as-of date with Run Approval Status = Approved and Risk Run Status Completed or Completed with Warnings, by Risk Horizon Days, Confidence Level and VaR Method; certified (CD-320).",
             [("31", "Portfolio Risk Measure", "Risk Measure Value"), ("31", "Portfolio Risk Measure", "Risk Measure Amount"),
              ("31", "Portfolio Risk Measure", "Risk Measure"), ("31", "Portfolio Risk Measure", "Risk Horizon Days"),
              ("31", "Portfolio Risk Measure", "Confidence Level"), ("31", "Portfolio Risk Measure", "VaR Method"),
              ("31", "Portfolio Risk Measure", "Measure Calculation Run"), ("31", "Risk Calculation Run", "Run Approval Status"),
              ("31", "Risk Calculation Run", "Risk Run Status"), ("31", "Risk Calculation Run", "Run As-Of Date")]),
            ("Ex-Ante Tracking Error", "Risk Measure Value of the Portfolio Risk Measure with Risk Measure = Ex-Ante Tracking Error and Measure Benchmark filled, from the approved run for the as-of date; certified (CD-320).",
             [("31", "Portfolio Risk Measure", "Risk Measure Value"), ("31", "Portfolio Risk Measure", "Risk Measure"),
              ("31", "Portfolio Risk Measure", "Measure Benchmark"), ("31", "Risk Calculation Run", "Run Approval Status")]),
            ("Other Ex-Ante Measures", "Risk Measure Value for Risk Measure in (Ex-Ante Volatility, Expected Shortfall, Ex-Ante Beta) from the approved run; published, not certified.",
             [("31", "Portfolio Risk Measure", "Risk Measure Value"), ("31", "Portfolio Risk Measure", "Risk Measure"),
              ("31", "Risk Calculation Run", "Run Approval Status")]),
            ("Approved Risk Coverage %", "Portfolios with Portfolio Status Active that have at least one Portfolio Risk Measure from an approved run for the as-of date / all Portfolios with Portfolio Status Active, by Business Line; books outside the risk program are listed as exclusions by the risk function, not dropped.",
             [("31", "Portfolio Risk Measure", "Measured Portfolio"), ("31", "Risk Calculation Run", "Run Approval Status"),
              ("31", "Risk Calculation Run", "Run As-Of Date"), ("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"),
              ("18", "Portfolio", "Business Line")]),
            ("Stale Holdings Runs", "Count of approved Risk Calculation Runs whose Holdings As-Of Date is earlier than the business day before Run As-Of Date, or whose Holding View Used is not Start of Day or End of Day.",
             [("31", "Risk Calculation Run", "Holdings As-Of Date"), ("31", "Risk Calculation Run", "Run As-Of Date"),
              ("31", "Risk Calculation Run", "Holding View Used"), ("31", "Risk Calculation Run", "Run Approval Status")]),
            ("Decomposition Tie-Out", "Risk Measure Value - sum of Contribution to Risk over the Risk Decomposition rows of one Risk Dimension for the same measure; flagged beyond 0.5% of the measure value.",
             [("31", "Risk Decomposition", "Contribution to Risk"), ("31", "Risk Decomposition", "Risk Dimension"),
              ("31", "Risk Decomposition", "Decomposed Measure"), ("31", "Portfolio Risk Measure", "Risk Measure Value")]),
            ("Exposure % of Net Assets", "Exposure Percent of Net Assets by Exposure Measure, Exposure Dimension and Exposure Bucket for the portfolio and as-of date, as held on the 31 record.",
             [("31", "Portfolio Exposure", "Exposure Percent of Net Assets"), ("31", "Portfolio Exposure", "Exposure Measure"),
              ("31", "Portfolio Exposure", "Exposure Dimension"), ("31", "Portfolio Exposure", "Exposure Bucket"),
              ("31", "Portfolio Exposure", "Exposure Portfolio"), ("31", "Portfolio Exposure", "Exposure As-Of Date")]),
            ("VaR Back-Test Exceptions", "Exceptions in Window and Back-Test Zone of the latest VaR Back-Test per portfolio, risk model and Back-Test P&L Basis; count of portfolios in the Yellow and Red zones.",
             [("31", "VaR Back-Test", "Exceptions in Window"), ("31", "VaR Back-Test", "Back-Test Zone"), ("31", "VaR Back-Test", "Back-Test Date"),
              ("31", "VaR Back-Test", "Back-Tested Portfolio"), ("31", "VaR Back-Test", "Back-Test P&L Basis"),
              ("31", "VaR Back-Test", "Back-Test Exception Indicator")]),
            ("Proxied Loading Share", "Instrument Factor Loading rows with Proxy Instrument filled / all loading rows for the risk model version and Factor Loading Date.",
             [("31", "Instrument Factor Loading", "Proxy Instrument"), ("31", "Instrument Factor Loading", "Loading Risk Model"),
              ("31", "Instrument Factor Loading", "Factor Loading Date")]),
        ],
        inputs=[
            ("31", "Risk Model", ["Risk Model Code", "Risk Model Version", "Risk Model Type", "Model Forecast Horizon", "Model Vendor",
                                  "Vendor Model Dataset", "Model Inventory Reference", "Risk Model Status", "Model Effective From",
                                  "Model Effective To"]),
            ("31", "Risk Factor", ["Factor Risk Model", "Risk Factor Code", "Risk Factor Type", "Mapped Curve", "Factor Classification Scheme",
                                   "Factor Classification Code"]),
            ("31", "Risk Factor Return", ["Return Risk Factor", "Factor Return Date", "Factor Return", "Factor Volatility Forecast",
                                          "Covariance Matrix Dataset", "Factor Return Data Basis"]),
            ("31", "Instrument Factor Loading", ["Loading Risk Model", "Loaded Instrument", "Loading Risk Factor", "Factor Loading Date",
                                                 "Factor Loading", "Proxy Instrument", "Factor Loading Data Basis"]),
            ("31", "Risk Calculation Run", ["Run Risk Model", "Run As-Of Date", "Run Scope", "Holdings As-Of Date", "Holding View Used",
                                            "Market Data Cut-Off Timestamp", "Risk Run Status", "Run Approval Status"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Horizon Days", "Confidence Level",
                                              "Measure Benchmark", "VaR Method", "Lookback Period Days", "Risk Measure Value", "Risk Measure Unit",
                                              "Risk Measure Amount"]),
            ("31", "Risk Decomposition", ["Decomposed Measure", "Risk Dimension", "Risk Bucket", "Contribution to Risk",
                                          "Marginal Contribution to Risk"]),
            ("31", "VaR Back-Test", ["Back-Tested Portfolio", "Back-Test Risk Model", "Back-Test Date", "Back-Test P&L Basis",
                                     "Back-Tested VaR Measure", "Realized Daily P&L", "Back-Test Exception Indicator", "Exceptions in Window",
                                     "Back-Test Window Days", "Back-Test Zone"]),
            ("31", "Portfolio Exposure", ["Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run", "Exposure Dimension",
                                          "Exposure Bucket", "Exposure Measure", "Exposure Value", "Exposure Value Unit",
                                          "Exposure Percent of Net Assets", "Exposure Benchmark"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Status", "Business Line"]),
        ],
        upstream=["DP-140", "DP-142", "DP-143", "DP-144", "DP-004", "DP-097", "DP-165", "DP-013", "DP-240", "DP-212"],   # DP-212 added at E1 merge: risk models are registered in the model inventory (CD-294)
        refresh="Daily",
        timeliness="Approved run for the prior business day published by 8am ET; factor returns and loadings by 6am ET; back-tests by 10am ET once the realized P&L of the day is final",
        history="Every approved run, measure, decomposition and exposure kept for 7 years, and back-tests for the full regulatory window history; superseded runs kept with Risk Run Status Superseded",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Ex-Ante VaR and Ex-Ante Tracking Error are published only from Risk Calculation Runs with Run Approval Status = Approved, and at most one approved run per risk model version, as-of date and run scope.",
            "Every Portfolio Risk Measure with Risk Measure = Ex-Ante Tracking Error names a Measure Benchmark, and every Value at Risk or Expected Shortfall row has Risk Horizon Days, Confidence Level and VaR Method.",
            "Contribution to Risk summed over the buckets of one Risk Dimension equals the Risk Measure Value of the decomposed measure within 0.5%.",
            "Every Measured Portfolio, Exposure Portfolio and Back-Tested Portfolio resolves to a Portfolio in DP-140, and every run's Run Risk Model resolves to a Risk Model version effective on Run As-Of Date.",
            "Exceptions in Window equals the count of Back-Test Exception Indicator = Y rows for the portfolio, model and P&L basis over Back-Test Window Days.",
        ],
        notes=("Master concepts: Risk Model, Risk Factor, Instrument Factor Loading, Risk Calculation Run, Portfolio Risk Measure, "
               "Portfolio Exposure, 31 (CD-211). Certified numbers (CD-293, CD-320): ex-ante VaR and ex-ante tracking error, from "
               "approved runs only; volatility, expected shortfall and beta are published but not certified. The Rule 22e-4 "
               "liquidity classification family is certified in DP-155, not here (brief hardest call 3). Ex-post statistics are 32 "
               "(DP-157) and optimizer estimates 24 (CD-211); per-instrument vendor analytics are 22 values in DP-143. "
               "Fund-keyed results are measured on the fund's whole 18 book reached through DP-140 (CD-324). "
               "Copies read as held: Realized Daily P&L on VaR Back-Test is a Derived copy (27), the P&L the back-test used, hence "
               "DP-165 upstream; Exposure Percent of Net Assets is computed on 27 net assets and read as held. "
               "Model inventory: Model Inventory Reference points to 37 MODEL- (CD-246, CD-294); DP-212 Model Inventory & Validation "
               "is a Wave E1 product of another group and is not in this group's permitted upstream list, so it is not listed; the "
               "program lead may add DP-212 upstream (DP-212 reads DP-211 and DP-192 only, so no cycle). Factor classification "
               "schemes resolve through DP-013 and model vendors through DP-240. "
               "Operating model: in house, possibly on a vendor engine; a vendor engine changes the run's source dataset (Vendor "
               "Model Dataset, Covariance Matrix Dataset), not the grain. "
               "PII = Y: Measured Portfolio, Decomposed Measure and Back-Tested Portfolio are personal data for individuals' SMA books; "
               "publish a view without those books for wide use. Risk Model Owner is not published. "
               "Taxonomy gap: Risk Calculation Run has no run identifier attribute; a run is keyed by Run Risk Model x Run As-Of Date x "
               "Run Scope. "
               "Open SME questions (31 Source_Notes): which platforms and vendors are used and which values are stored rather than "
               "recomputed (question 1). "
               "Rests on CD-211, CD-246, CD-293, CD-294, CD-320, CD-324."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-147": dict(
        definition=("The counterparty-facing reference terms of trade operations: ISDA, CSA, GMRA, MRA, MSFTA, clearing, give-up "
                    "and related trading agreements with their credit support terms, eligible collateral and haircuts and "
                    "termination triggers, and the verified standing settlement instructions of client mandates, funds, portfolios "
                    "and counterparties, with the settlement cycle rules by market. It publishes the concepts 'Trading Agreement', "
                    "26, TAGR- (CD-182) and 'Standing Settlement Instruction', 26, SSI- (CD-155 option A) of CONCEPT_OWNERSHIP "
                    "without remastering them, so settlement, collateral, counterparty exposure, broker approval and custody "
                    "set-up read these terms from one governed record. It owns no certified number."),
        business_questions=[
            "Which trading agreements are in force for each fund and counterparty, of which type, and which derivatives relationships lack an executed CSA?",
            "What thresholds, minimum transfer amounts, eligible collateral and haircuts apply under each agreement and margin type?",
            "Which agreements carry NAV decline, key person or rating triggers, at what thresholds?",
            "Which SSIs are active, verified with a call-back and approved under four eyes, and which changes are pending approval?",
            "Which active portfolios or funds have no active own SSI for a market they trade, and what settlement cycle and affirmation cut-off applies in each market?",
        ],
        grain="Trading agreement (TAGR-) with credit support terms, eligible collateral schedule and termination triggers as effective-dated child rows; standing settlement instruction (owner x market or settlement currency x asset class x effective period) with its verification; settlement cycle rule (market x instrument type x settlement type x effective period)",
        dimensions=["Trading agreement and type", "Fund party", "Agreement counterparty", "Firm contracting entity", "Margin type and direction",
                    "Collateral type", "Termination trigger type", "SSI owner type", "SSI fund / portfolio / mandate / counterparty",
                    "Market", "Asset class", "Settlement currency", "Verification and approval status", "Effective date"],
        measures=[
            ("Active Trading Agreements", "Count of Trading Agreement ID with Agreement Status = Active on the as-of date, by Trading Agreement Type, Fund Party and Agreement Counterparty.",
             [("26", "Trading Agreement", "Trading Agreement ID"), ("26", "Trading Agreement", "Agreement Status"),
              ("26", "Trading Agreement", "Trading Agreement Type"), ("26", "Trading Agreement", "Fund Party"),
              ("26", "Trading Agreement", "Agreement Counterparty")]),
            ("ISDA Without Margin Terms", "Count of Active Trading Agreements of type ISDA Master Agreement with no Credit Support Terms of Terms Margin Type Variation Margin effective on the as-of date, on the agreement or on a child agreement (Parent Agreement).",
             [("26", "Credit Support Terms", "Terms Agreement"), ("26", "Credit Support Terms", "Terms Margin Type"),
              ("26", "Credit Support Terms", "Terms Effective From"), ("26", "Credit Support Terms", "Terms Effective To"),
              ("26", "Trading Agreement", "Parent Agreement"), ("26", "Trading Agreement", "Trading Agreement Type"), "Active Trading Agreements"]),
            ("Agreements With Termination Triggers", "Count of Active Trading Agreements with at least one effective Termination Event Trigger, by Termination Trigger Type, and the lowest Trigger Threshold Percentage of NAV Decline triggers by Measurement Period Months.",
             [("26", "Termination Event Trigger", "Trigger Agreement"), ("26", "Termination Event Trigger", "Termination Trigger Type"),
              ("26", "Termination Event Trigger", "Trigger Threshold Percentage"), ("26", "Termination Event Trigger", "Measurement Period Months"),
              "Active Trading Agreements"]),
            ("Active SSIs", "Count of SSI ID with SSI Status = Active and the as-of date between SSI Effective From and SSI Effective To, by SSI Owner Type, SSI Market and SSI Asset Class.",
             [("26", "Standing Settlement Instruction", "SSI ID"), ("26", "Standing Settlement Instruction", "SSI Status"),
              ("26", "Standing Settlement Instruction", "SSI Effective From"), ("26", "Standing Settlement Instruction", "SSI Effective To"),
              ("26", "Standing Settlement Instruction", "SSI Owner Type"), ("26", "Standing Settlement Instruction", "SSI Market"),
              ("26", "Standing Settlement Instruction", "SSI Asset Class")]),
            ("SSI Verification Rate", "Active SSIs with SSI Verification Status = Verified, Call-Back Performed Indicator = Y and SSI Change Approval Status = Approved / Active SSIs.",
             [("26", "Standing Settlement Instruction", "SSI Verification Status"), ("26", "SSI Verification", "Call-Back Performed Indicator"),
              ("26", "SSI Verification", "SSI Change Approval Status"), "Active SSIs"]),
            ("Pending SSI Changes", "Count of SSIs with SSI Change Approval Status = Pending, by SSI Source and days pending since SSI Effective From.",
             [("26", "SSI Verification", "SSI Change Approval Status"), ("26", "SSI Verification", "SSI Source"),
              ("26", "Standing Settlement Instruction", "SSI Effective From")]),
            ("Four-Eyes Exceptions", "Count of SSIs whose Verified By equals SSI Approved By.",
             [("26", "SSI Verification", "Verified By"), ("26", "SSI Verification", "SSI Approved By")]),
            ("Active Portfolios Without Own SSI", "Count of Portfolios with Portfolio Status Active and no Active SSI with SSI Owner Type = Portfolio naming them as SSI Portfolio, nor an Active SSI of SSI Owner Type Fund or Client Mandate for the fund or mandate the portfolio implements through an effective Portfolio Implementation Link (DP-140, CD-324).",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("26", "Standing Settlement Instruction", "SSI Portfolio"),
              ("26", "Standing Settlement Instruction", "SSI Fund"), ("26", "Standing Settlement Instruction", "SSI Mandate"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"), ("18", "Portfolio Implementation Link", "Implementation Link Type"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("18", "Portfolio Implementation Link", "Implemented Mandate"),
              "Active SSIs"]),
            ("Markets by Settlement Cycle", "Count of Cycle Market x Cycle Instrument Type rows effective on the as-of date by Standard Settlement Cycle, with the earliest Affirmation Cut-Off Time.",
             [("26", "Settlement Cycle Rule", "Cycle Market"), ("26", "Settlement Cycle Rule", "Cycle Instrument Type"),
              ("26", "Settlement Cycle Rule", "Standard Settlement Cycle"), ("26", "Settlement Cycle Rule", "Affirmation Cut-Off Time"),
              ("26", "Settlement Cycle Rule", "Cycle Effective From"), ("26", "Settlement Cycle Rule", "Cycle Effective To")]),
        ],
        inputs=[
            ("26", "Trading Agreement", ["Trading Agreement ID", "Trading Agreement Type", "Agreement Form", "Parent Agreement", "Fund Party",
                                         "Principal Account", "Firm Contracting Entity", "Agreement Counterparty", "Give-Up Executing Broker",
                                         "Governing Law", "Agreement Date", "Agreement Effective From", "Last Amendment Date", "Agreement Status",
                                         "Agreement Termination Date", "Agreement Operations Provider"]),
            ("26", "Credit Support Terms", ["Terms Agreement", "Terms Margin Type", "Terms Direction", "Threshold Amount", "Minimum Transfer Amount",
                                            "Independent Amount", "Rounding Amount", "Cash Collateral Interest Rate", "Credit Support Base Currency",
                                            "Valuation Agent", "Call Frequency", "Notification Time", "Margin Rule Regulators",
                                            "Segregation Required Indicator", "Segregation Custodian", "Terms Effective From", "Terms Effective To"]),
            ("26", "Eligible Collateral Schedule", ["Schedule Agreement", "Schedule Margin Type", "Schedule Direction", "Eligible Collateral Type",
                                                    "Eligibility Criteria", "Valuation Haircut", "FX Haircut", "Concentration Limit",
                                                    "Eligibility Effective From", "Eligibility Effective To"]),
            ("26", "Termination Event Trigger", ["Trigger Agreement", "Termination Trigger Type", "Trigger Applies To", "Measurement Period Months",
                                                 "Trigger Threshold Percentage", "Rating Threshold", "Trigger Effective From", "Trigger Effective To"]),
            ("26", "Standing Settlement Instruction", ["SSI ID", "SSI Mandate", "SSI Asset Class", "SSI Market", "Place of Settlement",
                                                       "Settlement Agent BIC", "Settlement Message Standard", "SSI Verification Status",
                                                       "SSI Effective From", "SSI Owner Type", "SSI Portfolio", "SSI Fund", "SSI Counterparty",
                                                       "Own Safekeeping Account", "Counterparty Safekeeping Account Number",
                                                       "SSI Settlement Currency", "Cash Correspondent BIC", "Cash Account Number", "SSI Status",
                                                       "SSI Effective To"]),
            ("26", "SSI Verification", ["SSI Source", "Call-Back Performed Indicator", "Verified By", "SSI Change Approval Status", "SSI Approved By"]),
            ("26", "Settlement Cycle Rule", ["Cycle Market", "Cycle Instrument Type", "Cycle Settlement Type", "Standard Settlement Cycle",
                                             "Allocation Cut-Off Time", "Affirmation Cut-Off Time", "Settlement Calendar", "Cycle Effective From",
                                             "Cycle Effective To"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Status"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product", "Implemented Mandate",
                                                     "Implementation Effective From", "Implementation Effective To"]),
        ],
        upstream=["DP-140", "DP-004", "DP-013", "DP-240", "DP-167", "DP-093", "DP-192"],
        refresh="On Event",
        timeliness="Each approved SSI or agreement change within 15 minutes of approval; a full daily snapshot by 6am ET for settlement and collateral processing",
        history="SCD type 2 on every agreement, credit support term, collateral schedule, trigger, SSI and cycle rule; terminated agreements and inactive SSIs kept for 10 years after their end date",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "API", "Event stream"],
        dq_rules=[
            "Every Standing Settlement Instruction fills exactly the owner reference its SSI Owner Type names (SSI Mandate, SSI Fund, SSI Portfolio or SSI Counterparty), and that reference resolves in DP-004, DP-140 or DP-240.",
            "No two Active SSIs share the same owner, SSI Market (or SSI Settlement Currency for Cash / FX), SSI Asset Class and overlapping effective period.",
            "An SSI is published as usable only when SSI Verification Status = Verified, Call-Back Performed Indicator = Y, SSI Change Approval Status = Approved and Verified By differs from SSI Approved By.",
            "Every Own Safekeeping Account resolves to an open Safekeeping Account in DP-167 assigned to the SSI's owner on SSI Effective From.",
            "Every Active Trading Agreement names a Fund Party or Principal Account and an Agreement Counterparty that resolves in DP-240, and every Credit Support Terms, Eligible Collateral Schedule and Termination Event Trigger row references an existing Trading Agreement ID.",
            "Valuation Haircut and FX Haircut are between 0% and 100%, and Terms, Eligibility and Trigger effective periods fall within the agreement's effective period.",
        ],
        notes=("Master concepts: 'Trading Agreement', 26, TAGR- (CD-182) and 'Standing Settlement Instruction', 26, SSI- "
               "(CD-155 option A). Certified numbers: none. "
               "Dependency direction (CD-321): DP-115 Approved Broker & Counterparty Master reads agreement status from this product, so "
               "this product takes counterparty identity as the 02 party key from DP-240 and never lists DP-115 upstream. The "
               "enterprise contract record is 39 (CD-257, DP-213); this product holds the typed trading terms and does not list "
               "DP-213. DP-086 Mandate Onboarding re-points its SSI read here (CD-323). "
               "Operating model (CD-297): drafted in house. If trade support or collateral management is outsourced (Agreement "
               "Operations Provider), SSIs and agreements remain the firm's record because SSIs authorize payments; the provider's SSI "
               "changes arrive for verification and approval (SSI Source), and DP-151 to DP-153 carry the provider's daily results. "
               "Safekeeping accounts: Own Safekeeping Account (SKA-) is read and resolved through DP-167. The SSI attribute "
               "'Safekeeping Account' is a Derived copy (12) of the 12 Custody Account number; it is not read here (rule 2), and its "
               "re-typing to SKA- is deferred under CD-194 (26 SME question 12). DP-086 still joins to 12 Custody Account through it "
               "until that is decided. Fund Party, SSI Fund and SSI Mandate resolve through DP-004 (01 Investment Mandate directly "
               "until CD-322 is built); Principal Account through DP-093; verifiers and approvers through DP-192. "
               "PII = Y and classification Restricted - Personal Data: Cash Account Number and Principal Account identify individual "
               "mandate clients, and Verified By and SSI Approved By are employees; SSIs authorize payments, so delivery is limited "
               "to operations systems and a key-only view is published for analytics. "
               "Taxonomy gap: 26 has no trading agreement amendment object; amendments are visible only as Last Amendment Date, "
               "and the amended terms as new effective-dated child rows. "
               "Open SME questions (26 Source_Notes): whether DTCC ALERT is the golden source for counterparty SSIs (question 1); "
               "whether ISDAs are held for funds as counterparties or for the adviser as agent, and how fund termination triggers are "
               "monitored (question 10); whether collateral management is outsourced (question 7). "
               "Rests on CD-155, CD-182, CD-194, CD-257, CD-297, CD-321, CD-323."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-165 re-specified at WP1 in specs_w1f_certified.py
    # ------------------------------------------------------------------------------------------------------------------
    "DP-166": dict(
        definition=("The fund accounting book of record (ABOR): each fund's books by accounting basis and the 18 portfolios they "
                    "account for, the fund chart of accounts, journal entries and lines with their typed source records, daily "
                    "trial balances, ABOR valuation records with the book's own quantity, applied price, cost and unrealized gain, "
                    "and daily income accruals. It publishes the 27 concepts Fund Accounting Book, Fund Ledger Account, Fund "
                    "Journal Entry (FJNL-), ABOR Valuation Record and Income Accrual of CONCEPT_OWNERSHIP (CD-186) without "
                    "remastering them, as the one conformed fund ledger and fund position set that NAV, reconciliations, "
                    "expenses, distributions, tax and fund filings read. It owns no certified number: what is struck from the "
                    "book is certified in DP-165."),
        business_questions=[
            "Is each fund's trial balance in balance today, and which journals were manual, reversed or posted after the accounting date?",
            "What does the ABOR hold for each fund by instrument - quantity, applied price, market value, identified cost and unrealized gain - and was every price the approved one?",
            "Which portfolios does each fund book account for, and which active books have no linked portfolio?",
            "How much income did each fund accrue today by income type, and which instruments that pay income had no accrual?",
            "Which journal lines cannot be traced to a typed source record?",
        ],
        grain="Fund journal line (fund journal entry x line number), with fund trial balance (book x fund ledger account x share class or fund level x balance date), ABOR valuation record (book x instrument x valuation date) and income accrual (book x instrument x income type x accrual date) as companion facts; fallback grain for administrator-kept books: trial balance and ABOR valuation",
        dimensions=["Fund (investment product)", "Fund accounting book and accounting basis", "Fund accounting operating model and administrator",
                    "Linked portfolio", "Fund ledger account and account class", "Share class", "Journal source type", "Accounting date",
                    "Posting date", "Instrument", "Income type", "Valuation date", "Business line"],
        measures=[
            ("Trial Balance Check", "Sum of Closing Balance Amount over all Fund Ledger Accounts of a Balance Book and Balance Date (fund level and every Balance Share Class); flagged when not zero.",
             [("27", "Fund Trial Balance", "Closing Balance Amount"), ("27", "Fund Trial Balance", "Balance Book"),
              ("27", "Fund Trial Balance", "Balance Date"), ("27", "Fund Trial Balance", "Balance Share Class")]),
            ("Unbalanced Journals", "Count of Fund Journal Entries with Fund Journal Status = Posted whose Line Base Amount does not sum to zero over their Fund Journal Lines.",
             [("27", "Fund Journal Line", "Line Base Amount"), ("27", "Fund Journal Line", "Line Journal"),
              ("27", "Fund Journal Entry", "Fund Journal Entry ID"), ("27", "Fund Journal Entry", "Fund Journal Status")]),
            ("Manual Journal Share", "Posted Fund Journal Entries with Manual Entry Indicator = Y / all posted entries, by book and Fund Journal Source Type.",
             [("27", "Fund Journal Entry", "Manual Entry Indicator"), ("27", "Fund Journal Entry", "Fund Journal Status"),
              ("27", "Fund Journal Entry", "Fund Journal Source Type"), ("27", "Fund Journal Entry", "Journal Book")]),
            ("Late Postings", "Count of posted Fund Journal Entries with Posting Date after Accounting Date, by days late and Fund Journal Source Type.",
             [("27", "Fund Journal Entry", "Posting Date"), ("27", "Fund Journal Entry", "Accounting Date"),
              ("27", "Fund Journal Entry", "Fund Journal Source Type")]),
            ("Untraced Journal Lines", "Count of Fund Journal Lines of entries whose Fund Journal Source Type is Trade, Capital Stock, ETF Creation / Redemption or Distribution and whose matching source reference (Source Portfolio Transaction, Source Fund Order, Source AP Order, Source Distribution Declaration) is null.",
             [("27", "Fund Journal Entry", "Fund Journal Source Type"), ("27", "Fund Journal Line", "Source Portfolio Transaction"),
              ("27", "Fund Journal Line", "Source Fund Order"), ("27", "Fund Journal Line", "Source AP Order"),
              ("27", "Fund Journal Line", "Source Distribution Declaration")]),
            ("ABOR Market Value", "Sum of Base Market Value over ABOR Valuation Records per Valuation Book and ABOR Valuation Date. Not NAV and not AUM; NAV is DP-165's.",
             [("27", "ABOR Valuation Record", "Base Market Value"), ("27", "ABOR Valuation Record", "Valuation Book"),
              ("27", "ABOR Valuation Record", "ABOR Valuation Date")]),
            ("Unrealized Gain Tie-Out", "Base Market Value - Identified Cost Amount - Unrealized Gain Loss Amount per ABOR Valuation Record; flagged beyond 0.01 base currency.",
             [("27", "ABOR Valuation Record", "Base Market Value"), ("27", "ABOR Valuation Record", "Identified Cost Amount"),
              ("27", "ABOR Valuation Record", "Unrealized Gain Loss Amount")]),
            ("ABOR at Approved Price %", "ABOR Valuation Records whose Applied Price resolves to an Approved Price with Price Approval Status = Approved and the same Price Date as the ABOR Valuation Date / all records valued at a price (ABOR Valuation Method not amortized cost).",
             [("27", "ABOR Valuation Record", "Applied Price"), ("27", "ABOR Valuation Record", "ABOR Valuation Method"),
              ("27", "ABOR Valuation Record", "ABOR Valuation Date"), ("22", "Approved Price", "Approved Price ID"),
              ("22", "Approved Price", "Price Approval Status"), ("22", "Approved Price", "Price Date")]),
            ("Daily Income Accrued", "Sum of Daily Accrual Amount by Accrual Book, Income Type and Income Accrual Date.",
             [("27", "Income Accrual", "Daily Accrual Amount"), ("27", "Income Accrual", "Accrual Book"), ("27", "Income Accrual", "Income Type"),
              ("27", "Income Accrual", "Income Accrual Date")]),
            ("Unlinked Active Books", "Count of Fund Accounting Books with Book Status = Active and no Fund Book Portfolio Link effective on the as-of date.",
             [("27", "Fund Accounting Book", "Book Status"), ("27", "Fund Book Portfolio Link", "Linked Book"),
              ("27", "Fund Book Portfolio Link", "Portfolio Link Effective From"), ("27", "Fund Book Portfolio Link", "Portfolio Link Effective To")]),
        ],
        inputs=[
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis", "Book Code", "Book Fund Chart of Accounts", "Business Line",
                                            "Book Reporting Currency", "Book Owner Entity", "Book Status"]),
            ("27", "Fund Book Operating Period", ["Operated Book", "Fund Accounting Operating Model", "Fund Administrator of Record",
                                                  "Operating Period Effective From", "Operating Period Effective To"]),
            ("27", "Fund Book Portfolio Link", ["Linked Book", "Accounted Portfolio", "Book Portfolio Role", "Portfolio Link Effective From",
                                                "Portfolio Link Effective To"]),
            ("27", "Fund Ledger Account", ["Fund Chart of Accounts", "Fund Ledger Account Number", "Fund Ledger Account Name",
                                           "Fund Ledger Account Class", "Class-Specific Account Indicator", "Statement Caption"]),
            ("27", "Fund Journal Entry", ["Fund Journal Entry ID", "Journal Book", "Fund Journal Source Type", "Accounting Date", "Posting Date",
                                          "Fund Journal Status", "Reversed Journal", "Related NAV Error Case", "Manual Entry Indicator"]),
            ("27", "Fund Journal Line", ["Line Journal", "Journal Line Number", "Line Fund Ledger Account", "Line Amount", "Line Base Amount",
                                         "Line FX Rate", "Line Share Class", "Line Instrument", "Source Portfolio Transaction",
                                         "Source Settlement Instruction", "Source Fund Order", "Source AP Order", "Source Distribution Declaration"]),
            ("27", "Fund Trial Balance", ["Balance Book", "Balance Fund Ledger Account", "Balance Date", "Balance Share Class", "Closing Balance Amount"]),
            ("27", "ABOR Valuation Record", ["Valuation Book", "Valued Instrument", "ABOR Valuation Date", "ABOR Quantity", "Applied Price",
                                             "Applied Fair Value Determination", "Applied FX Rate", "ABOR Valuation Method", "Local Market Value",
                                             "Base Market Value", "Identified Cost Amount", "Unrealized Gain Loss Amount"]),
            ("27", "Income Accrual", ["Accrual Book", "Accrual Instrument", "Income Accrual Date", "Income Type", "Accrual Coupon Period",
                                      "Applied Rate Fixing", "Coupon Rate Applied", "Related Corporate Action Event", "Daily Accrual Amount",
                                      "Accrued Income Balance", "Related Income Collection"]),
            ("22", "Approved Price", ["Approved Price ID", "Price Date", "Approved Price Value", "Price Approval Status"]),
        ],
        upstream=["DP-004", "DP-013", "DP-097", "DP-099", "DP-140", "DP-141", "DP-142", "DP-143"],
        refresh="Daily",
        timeliness="ABOR valuation, accruals and trial balance for the valuation date by 6pm ET (before the NAV strike); journal entries and lines by 7am ET on T+1; administrator files by the time agreed in the administration agreement",
        history="Journal entries and lines, trial balances and ABOR valuation records kept for 10 years (Rule 31a-2 books and records); the chart of accounts and book links kept with effective dates indefinitely",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Closing Balance Amount sums to zero over all Fund Ledger Accounts of each Balance Book and Balance Date, and Line Base Amount sums to zero over the lines of every posted Fund Journal Entry.",
            "Every Fund Journal Line posts to a Fund Ledger Account of the book's Book Fund Chart of Accounts, and a Class-Specific Account Indicator = Y account always carries a Line Share Class.",
            "Every ABOR Valuation Record names an Applied Price and Applied FX Rate that resolve in DP-143, and Base Market Value = Local Market Value x the Spot Rate of the Applied FX Rate within 0.01.",
            "Every Accounted Portfolio resolves to a Portfolio in DP-140, and no portfolio is linked to two books of the same Accounting Basis with overlapping effective periods.",
            "Every Fund Accounting Book has exactly one Fund Book Operating Period effective on every date, and books whose model is not In House are certified at trial balance and ABOR valuation grain only.",
        ],
        notes=("W4 re-point (CW-930, CW-166): 27 Fund Journal Line.Source Capital Call, Source Private Fund Distribution, Source "
               "Credit Facility and Source Waterfall Calculation dropped, no successor (30 retires); Untraced Journal Lines no "
               "longer tests the capital call, private fund distribution and credit facility source types. Fee accruals that "
               "reach this ledger reference the 01 fund fee terms (Reference (Management Fee, 01), CW-051), not the 47 client "
               "Fee Schedule. "
               "Master concepts: Fund Accounting Book, Fund Ledger Account, Fund Journal Entry (FJNL-), ABOR Valuation Record and "
               "Income Accrual, 27 (CD-186). Certified numbers: none; ABOR Market Value is a book value, never NAV or AUM (CD-330). "
               "A fund's transactions never post to a 19 ledger; the adviser side of waivers and fees is 19 and reaches this product "
               "only by reference (CD-186, CD-188). ABOR quantity is mastered in 27 and compared with the 18 IBOR quantity in DP-172, "
               "not here (CD-196, CD-335); 27 ABOR to IBOR Reconciliation is not published here. "
               "Journal line sources (18 PTXN-, 26 SETL-, 29 FNDO- and ECR-, 27 FDIV-) are published as "
               "keys only; this product does not list the 26 or 29 products upstream because it reads none of their values. "
               "Operating model (CD-297, CD-331): in house the grain is the platform's full journal. If an administrator keeps the "
               "book (Fund Book Operating Period), the firm usually receives the trial balance, valuation and accrual files but not "
               "journal lines, so for those books Fund Journal Entry and Fund Journal Line are optional, the product is certified at "
               "trial balance and ABOR valuation grain, and Unbalanced Journals, Manual Journal Share, Late Postings and Untraced "
               "Journal Lines are marked not available. "
               "Inputs: Applied Price, Applied Fair Value Determination, Applied FX Rate and Applied Rate Fixing are references to the "
               "22 masters, resolved through DP-143 (CD-187). Related Corporate Action Event resolves through DP-099; Line Instrument "
               "and Valued Instrument through DP-097. The candidate's DP-142 upstream is kept because DP-172 compares this product's "
               "quantities with DP-142 at the same grain; this product itself reads no 18 holding values. "
               "PII = N: Journal Approved By is not published. "
               "Taxonomy gap: Fund Journal Line has no debit / credit indicator, so balancing assumes signed Line Base Amount. "
               "Taxonomy gap: 27 Income Accrual has no expected-income flag, so instruments that should have accrued but did not "
               "cannot be found without the 17 coupon schedule; DP-172 or DP-174 checks it. "
               "Open SME questions (27 Source_Notes): which funds are accounted at an administrator (question 1); whether the "
               "accounting platform keeps its own lots or uses 18 LOT- (question 2); whether private funds are on the same ledger "
               "(question 8). "
               "Fund Accounting Book Business Line (Derived copy, 18) and Book Reporting Currency (Derived copy, 01) are read as held on the "
               "book, because they are the book's own slicing and reporting attributes; they must agree with DP-140 and DP-004. "
               "Rests on CD-186, CD-187, CD-188, CD-196, CD-297, CD-330, CD-331, CD-335."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-167": dict(
        definition=("The custodian and safekeeping account dimension: each custody provider by role, the global custodians' "
                    "sub-custodian and depository network by market, and every safekeeping, cash, bank deposit and collateral "
                    "account (SKA-) with its effective-dated assignment to a fund, portfolio or client account. It publishes the concepts Safekeeping Account (SKA-, CD-194 option A) and Custody Provider "
                    "Profile, 28 of CONCEPT_OWNERSHIP without remastering them, and the Custodian dimension CD-296 names for "
                    "SM-00. Settlement, reconciliation, corporate action, lending, fund order settlement and client money products "
                    "key on its Safekeeping Account ID and custodian, so no product keeps its own list of custody accounts. It owns "
                    "no certified number."),
        business_questions=[
            "Which safekeeping and cash accounts does each fund, portfolio and client account hold, at which custodian and for what purpose?",
            "Which open accounts are not assigned to any owner, and which active portfolios have no main safekeeping account?",
            "Does the custodian appointed for each fund hold the fund's main safekeeping account?",
            "Which sub-custodians and depositories does each global custodian use in each market, and which arrangements are inactive?",
        ],
        grain="Safekeeping account (SKA-) x effective period, with bridge table safekeeping account x owner (fund, portfolio or client account) x assignment purpose x effective period; custody provider profile (provider x role x effective period) and sub-custodian network arrangement (global custodian x market x sub-custodian x effective period) as dimensions",
        dimensions=["Safekeeping account", "Account provider (custodian)", "Custody provider role", "Safekeeping account type", "Account status",
                    "Account currency", "Owning fund", "Owning portfolio", "Owning client account", "Assignment purpose",
                    "Market", "Sub-custodian and depository", "Effective date"],
        measures=[
            ("Open Safekeeping Accounts", "Count of Safekeeping Account ID with Safekeeping Account Status = Open on the as-of date, by Account Provider, Safekeeping Account Type and Account Currency.",
             [("28", "Safekeeping Account", "Safekeeping Account ID"), ("28", "Safekeeping Account", "Safekeeping Account Status"),
              ("28", "Safekeeping Account", "Account Provider"), ("28", "Safekeeping Account", "Safekeeping Account Type"),
              ("28", "Safekeeping Account", "Account Currency")]),
            ("Unassigned Open Accounts", "Count of Open Safekeeping Accounts with no Safekeeping Account Assignment effective on the as-of date.",
             [("28", "Safekeeping Account Assignment", "Assigned Safekeeping Account"), ("28", "Safekeeping Account Assignment", "Assignment Effective From"),
              ("28", "Safekeeping Account Assignment", "Assignment Effective To"), "Open Safekeeping Accounts"]),
            ("Portfolios Without Main Safekeeping Account", "Count of Portfolios with Portfolio Status Active and Portfolio Type = Standalone Book that have no effective Safekeeping Account Assignment with Owning Portfolio = the portfolio and Account Assignment Purpose = Main Safekeeping, directly or through the fund it implements by an effective Portfolio Implementation Link of type Implements Product (DP-140, CD-324).",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("18", "Portfolio", "Portfolio Type"),
              ("28", "Safekeeping Account Assignment", "Owning Portfolio"), ("28", "Safekeeping Account Assignment", "Owning Fund"),
              ("28", "Safekeeping Account Assignment", "Account Assignment Purpose"), ("18", "Portfolio Implementation Link", "Implementing Portfolio"),
              ("18", "Portfolio Implementation Link", "Implementation Link Type"), ("18", "Portfolio Implementation Link", "Implemented Product")]),
            ("Portfolio Custody Account Mismatch", "Count of Active Portfolios whose Safekeeping Custody Account is not among the accounts assigned to the portfolio (or its fund) with Account Assignment Purpose = Main Safekeeping on the as-of date.",
             [("18", "Portfolio", "Safekeeping Custody Account"), ("28", "Safekeeping Account Assignment", "Assigned Safekeeping Account"),
              ("28", "Safekeeping Account Assignment", "Owning Portfolio"), ("28", "Safekeeping Account Assignment", "Account Assignment Purpose")]),
            ("Custodian Appointment Mismatch", "Count of funds whose effective 01 Product Party Role of Party Role Type Custodian or Depositary / Trustee names a Party that is not the Account Provider of the fund's Main Safekeeping account on the as-of date.",
             [("01", "Product Party Role", "Party"), ("01", "Product Party Role", "Party Role Type"), ("01", "Product Party Role", "Role Effective From"),
              ("01", "Product Party Role", "Role Effective To"), ("28", "Safekeeping Account", "Account Provider"),
              ("28", "Safekeeping Account Assignment", "Owning Fund"), ("28", "Safekeeping Account Assignment", "Account Assignment Purpose")]),
            ("Active Sub-Custody Markets", "Count of distinct Arrangement Market with an Arrangement Status = Active arrangement per Arrangement Global Custodian on the as-of date, and the count of markets with more than one active Sub-Custodian.",
             [("28", "Sub-Custodian Network Arrangement", "Arrangement Market"), ("28", "Sub-Custodian Network Arrangement", "Arrangement Status"),
              ("28", "Sub-Custodian Network Arrangement", "Arrangement Global Custodian"), ("28", "Sub-Custodian Network Arrangement", "Sub-Custodian")]),
        ],
        inputs=[
            ("28", "Custody Provider Profile", ["Provider Party", "Provider Legal Entity", "Custody Provider Role", "Services Provided",
                                                "Supported Message Standards", "Service Agreement Reference", "Provider Profile Status",
                                                "Profile Effective From", "Profile Effective To"]),
            ("28", "Sub-Custodian Network Arrangement", ["Arrangement Global Custodian", "Arrangement Market", "Sub-Custodian", "Securities Depository",
                                                         "Market Holding Model", "Arrangement Status", "Arrangement Effective From",
                                                         "Arrangement Effective To"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Account Provider", "Internal Account Provider", "Safekeeping Account Number",
                                           "Safekeeping Account Name", "Safekeeping Account Type", "Account Holding Model", "Account Currency",
                                           "Cash Account IBAN", "Registered Nominee", "Safekeeping Account Status", "Account Opened Date",
                                           "Account Closed Date"]),
            ("28", "Safekeeping Account Assignment", ["Assigned Safekeeping Account", "Owning Fund", "Owning Portfolio", "Owning Client Account",
                                                      "Account Assignment Purpose", "Assignment Effective From", "Assignment Effective To"]),
            ("01", "Product Party Role", ["Party", "Party Role Type", "Role Effective From", "Role Effective To"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Status", "Portfolio Type", "Safekeeping Custody Account"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Implementation Effective From", "Implementation Effective To"]),
        ],
        upstream=["DP-004", "DP-013", "DP-093", "DP-140", "DP-210", "DP-240", "DP-213"],   # DP-213 added at E1 merge: the custodian service agreement is a contract register record
        refresh="Daily",
        timeliness="By 6am ET each business day; a newly opened or reassigned account within one hour of the change being confirmed by the custodian",
        history="SCD type 2 on accounts, assignments, provider profiles and network arrangements; closed accounts kept for 10 years after Account Closed Date (books and records under Investment Company Act Rule 31a-1 and Section 17(f))",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "API", "BI semantic model"],
        dq_rules=[
            "Every Safekeeping Account has exactly one Account Provider (or an Internal Account Provider for a self-custodying CIT trustee) that resolves to an active Custody Provider Profile on Account Opened Date.",
            "Each Safekeeping Account Assignment fills exactly one of Owning Fund, Owning Portfolio and Owning Client Account, and that owner resolves in DP-004, DP-140 or DP-093 on the assignment's effective dates.",
            "No owner has more than one effective assignment with Account Assignment Purpose = Main Safekeeping per Account Provider on any date, and assignments fall within the account's open period.",
            "A Safekeeping Account with Safekeeping Account Status = Closed has an Account Closed Date and no assignment effective after it.",
            "Every Provider Party, Account Provider, Sub-Custodian and Securities Depository resolves to an active party in DP-240, and every global custodian with an active profile has at least one active Sub-Custodian Network Arrangement.",
        ],
        notes=("W1b: Client Asset Designation (Designated Safekeeping Account, CASS Account Designation, Designating CASS Firm, Statutory Trust Indicator, designation dates) dropped, no successor (CW-928); with it the measure Client Accounts Without CASS Designation, the CASS business question, the CASS designation dimension and the CASS taxonomy gap are removed. 28 is now Fund Custody & Asset Servicing; the US customer-protection record of client assets (Rule 15c3-3) is 49's (CW-007), so client-owned safekeeping assignments stay only where an institutional separate account holds its own custody account. "
               "Master concepts: Safekeeping Account (SKA-, CD-194 option A) and Custody Provider Profile, 28. Publishes the "
               "Custodian dimension CD-296 names for SM-00. Certified numbers: none. "
               "Operating model (CD-297): custody is outsourced (28 Source_Notes). The grain is the accounts as opened at the "
               "custodians plus the firm's assignments, which the firm keeps whoever the custodian is; the product "
               "does not change if a CIT trustee self-custodies (Internal Account Provider filled instead of Account Provider). "
               "Inputs: provider identity comes from DP-240 (02 party key) and the supplier record from DP-210 Vendor Master (40). "
               "The 01 Product Party Role custodian appointment is read directly, because DP-004 does not publish Product Party Role; "
               "the program lead may add it to DP-004 under CD-322's lineage extension, after which the input stays and DP-004 is "
               "its source. Service Agreement Reference points to the 39 contract record; DP-213 is not in this group's permitted "
               "upstream list, so the key is carried without a DP-213 lineage. 18 Portfolio Safekeeping Custody Account is read to "
               "check it against the assignments (the reference lives in 18). "
               "Dependency direction: this product depends on DP-140 and is upstream of DP-142 and DP-147; DP-140 publishes the "
               "SKA- key only and never lists this product. 12 Custody Account (CUA-) stays the mandate set-up workflow (DP-086, "
               "CD-336 adds this product upstream of DP-086). "
               "PII = Y: Safekeeping Account Number, Safekeeping Account Name and Cash Account IBAN are personal data on individual "
               "SMA client rows, and Owning Client Account identifies the client; an account-key-only view is published widely. "
               "Open SME questions (28 Source_Notes): which custodians serve which funds and whether any custody is insourced "
               "(question 1); whether the firm or the sponsor custodian reconciles SMA accounts (question 3); questions 5 and 12 (UK CASS "
               "firms, EU safeguarding) are withdrawn with CW-928. "
               "Rests on CD-194, CD-197, CD-296, CD-297, CD-331, CD-336."),
    ),
}
