"""Data product specifications, Wave E1 foundations: the security master products (DP-097 to DP-099, Data Domain 17),
the governance register and enterprise catalog (DP-100, DP-101, Data Domain 21) and the enterprise party master
(DP-240, Data Domain 02; re-specified at WP1 in specs_w1f_client.py). See CONTRACT.md ("Enterprise products") and the brief
00_Program/Expansion/Product_Briefs/Foundations_and_Product_Range.md.

Dependency order (no cycles): DP-240 <- DP-013; DP-097 <- DP-004, DP-013; DP-098 <- DP-097, DP-013, DP-240;
DP-099 <- DP-097, DP-013; DP-100 <- DP-013, DP-192; DP-101 <- DP-100, DP-013, DP-211.
"""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-097": dict(
        definition=("The golden record of every instrument the firm holds, trades, prices or references as an underlying: "
                    "equities, bonds, securitized products, third-party funds, own share classes held by own portfolios, "
                    "listed and OTC derivatives at product level, private assets and limited partner fund interests. It "
                    "conforms the master concept 'Instrument (security master)' (CONCEPT_OWNERSHIP row 17, INS-) together "
                    "with 'Instrument Identifier' (17, IID-) and 'Instrument Listing' (17, LST-), and combines them with the "
                    "asset-class terms, coupon and redemption schedules, the firm and vendor classifications and the "
                    "US regulatory eligibility flags (Rule 2a-7, Rule 144A, Regulation S, restricted security, NAIC), each versioned by "
                    "effective period. It is the firm's one Instrument dimension (CD-296, CD-300): holdings, prices, orders, "
                    "settlements, corporate actions, risk and compliance products key on its Instrument ID and never build "
                    "their own. It is the source of no certified metric family; it publishes the dimension those metrics "
                    "are sliced by."),
        business_questions=[
            "Which instrument does an identifier (ISIN, CUSIP, SEDOL, FIGI, UPI, ticker on a venue) resolve to on a given date, and which identifiers does an instrument carry?",
            "Which active instruments are missing an ISIN, a primary identifier or a firm asset-class classification, so cannot be traded, priced or limit-tested cleanly?",
            "Is an instrument Rule 2a-7 eligible, a Rule 144A, Regulation S or restricted security, and what is its NAIC designation category?",
            "What are the coupon, maturity, seniority, call and put terms and the next coupon and redemption dates of a bond, and which instruments have matured or expired but are still active?",
            "Which own share classes held by own portfolios appear as instruments, and do their identifiers still match the 01 share class identifiers?",
            "What is the underlying instrument or index of a derivative, depositary receipt or convertible, and which instruments reference a given underlying?",
        ],
        grain=("Instrument x effective period (SCD type 2), with child tables at instrument x identifier scheme x identifier "
               "value x effective period, instrument x venue MIC x effective period, instrument x classification scheme x "
               "classification code x effective period, instrument x regulatory classification effective period, "
               "instrument x coupon period, instrument x redemption event type x redemption start date and subject "
               "instrument x related instrument or index x relationship type x effective period"),
        dimensions=["Instrument", "Instrument type and asset class", "Identifier scheme", "Listing venue (MIC) and ticker",
                    "Classification scheme and code (firm asset class, CFI, vendor sector)", "Regulatory eligibility flags",
                    "Denomination currency", "Country of issue", "Issuer (party key; issuer attributes from DP-098)",
                    "Own share class (DP-004)", "Underlying instrument or benchmark", "Debt seniority and coupon type",
                    "Primary data provider and source dataset", "Effective date / version"],
        measures=[
            ("Active Instruments", "Count of distinct Instrument ID with Instrument Status = active on the as-of date, by Instrument Type and Asset Class.",
             [("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Instrument Status"),
              ("17", "Instrument", "Instrument Type"), ("17", "Instrument", "Asset Class")]),
            ("Instruments Without ISIN", "Count of active instruments, excluding Instrument Type values for which no ISIN is allocated (OTC derivative product, private asset, fund interest) and Private Instrument Indicator = Y, with no Instrument Identifier row of Instrument Identifier Scheme = ISIN, Instrument Identifier Status = active and Identifier Effective From <= as-of date < Identifier Effective To (or open).",
             [("17", "Instrument", "Instrument Status"), ("17", "Instrument", "Instrument Type"),
              ("17", "Instrument", "Private Instrument Indicator"), ("17", "Instrument Identifier", "Identified Instrument"),
              ("17", "Instrument Identifier", "Instrument Identifier Scheme"),
              ("17", "Instrument Identifier", "Instrument Identifier Status"),
              ("17", "Instrument Identifier", "Identifier Effective From"),
              ("17", "Instrument Identifier", "Identifier Effective To")]),
            ("Primary Identifier Coverage %", "Active instruments with exactly one active Instrument Identifier row with Primary Identifier Indicator = Y on the as-of date / Active Instruments.",
             [("17", "Instrument Identifier", "Identified Instrument"),
              ("17", "Instrument Identifier", "Primary Identifier Indicator"),
              ("17", "Instrument Identifier", "Instrument Identifier Status"), "Active Instruments"]),
            ("Duplicate Identifier Count", "Count of (Instrument Identifier Scheme, Instrument Identifier Value) pairs that are active on the as-of date on more than one distinct Identified Instrument.",
             [("17", "Instrument Identifier", "Instrument Identifier Scheme"),
              ("17", "Instrument Identifier", "Instrument Identifier Value"),
              ("17", "Instrument Identifier", "Identified Instrument"),
              ("17", "Instrument Identifier", "Instrument Identifier Status")]),
            ("Own Share Class Identifier Mismatches", "Count of active Instrument Identifier rows with Derived from Own Share Class Indicator = Y whose Instrument Identifier Value differs from the 01 Security Identifier of the same scheme (ISIN, CUSIP or FIGI) for the instrument's Own Share Class; target 0.",
             [("17", "Instrument Identifier", "Derived from Own Share Class Indicator"),
              ("17", "Instrument Identifier", "Instrument Identifier Value"),
              ("17", "Instrument Identifier", "Instrument Identifier Scheme"),
              ("17", "Instrument", "Own Share Class"), ("01", "Share Class", "Share Class ID"),
              ("01", "Security Identifier", "ISIN"), ("01", "Security Identifier", "CUSIP"),
              ("01", "Security Identifier", "FIGI")]),
            ("Own Share Class Status Breaks", "Count of instruments with Instrument Type = Own Fund Share Class and Instrument Status = active whose Own Share Class has a 01 Share Class Status other than active.",
             [("17", "Instrument", "Instrument Type"), ("17", "Instrument", "Instrument Status"),
              ("17", "Instrument", "Own Share Class"), ("01", "Share Class", "Share Class Status")]),
            ("Asset Class Classification Coverage %", "Active instruments with an Instrument Classification Assignment in the firm asset-class scheme open on the as-of date / Active Instruments.",
             [("17", "Instrument Classification Assignment", "Classified Instrument"),
              ("17", "Instrument Classification Assignment", "Instrument Classification Scheme"),
              ("17", "Instrument Classification Assignment", "Instrument Classification Effective From"),
              ("17", "Instrument Classification Assignment", "Instrument Classification Effective To"),
              "Active Instruments"]),
            ("Classification Overrides Open", "Count of Instrument Classification Assignment rows open on the as-of date with Instrument Classification Override Indicator = Y, by Instrument Classification Scheme.",
             [("17", "Instrument Classification Assignment", "Instrument Classification Override Indicator"),
              ("17", "Instrument Classification Assignment", "Instrument Classification Scheme"),
              ("17", "Instrument Classification Assignment", "Instrument Classification Effective To")]),
            ("Debt Terms Completeness %", "Active instruments with Asset Class = fixed income whose Coupon Type, Coupon Frequency, Day Count Convention, Debt Seniority and Amount Issued are populated, Coupon Rate is populated unless Coupon Type = zero coupon, and Maturity Date is populated unless Perpetual Indicator = Y / active fixed income instruments.",
             [("17", "Instrument", "Asset Class"), ("17", "Debt Terms", "Coupon Type"),
              ("17", "Debt Terms", "Coupon Rate"), ("17", "Debt Terms", "Coupon Frequency"),
              ("17", "Debt Terms", "Day Count Convention"), ("17", "Debt Terms", "Debt Seniority"),
              ("17", "Debt Terms", "Amount Issued"), ("17", "Debt Terms", "Maturity Date"),
              ("17", "Debt Terms", "Perpetual Indicator")]),
            ("Coupon Schedule Gaps", "Count of active fixed income instruments with Coupon Type other than zero coupon and Maturity Date after the as-of date that have no Coupon Schedule row with Coupon Payment Date on or after the as-of date.",
             [("17", "Coupon Schedule", "Coupon Instrument"), ("17", "Coupon Schedule", "Coupon Payment Date"),
              ("17", "Debt Terms", "Coupon Type"), ("17", "Debt Terms", "Maturity Date")]),
            ("Matured or Expired Still Active", "Count of instruments with Instrument Status = active whose Maturity Date (Debt Terms) or Expiry Date (Listed Derivative Contract Terms) is before the as-of date and that have no Redemption Schedule row extending past it.",
             [("17", "Instrument", "Instrument Status"), ("17", "Debt Terms", "Maturity Date"),
              ("17", "Listed Derivative Contract Terms", "Expiry Date"),
              ("17", "Redemption Schedule", "Redemption Instrument"), ("17", "Redemption Schedule", "Redemption End Date")]),
            ("Primary Listing Breaks", "Count of active instruments with at least one Instrument Listing in Listing Status = active that do not have exactly one active listing with Primary Listing Indicator = Y.",
             [("17", "Instrument Listing", "Listed Instrument"), ("17", "Instrument Listing", "Listing Status"),
              ("17", "Instrument Listing", "Primary Listing Indicator")]),
        ],
        inputs=[
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "FISN", "Instrument Type", "Asset Class", "CFI Code",
                                  "Issuer", "Denomination Currency", "Country of Issue", "Instrument Status", "Issue Date",
                                  "Form of Security", "Own Share Class", "Private Instrument Indicator",
                                  "Primary Data Provider", "Source Dataset"]),
            ("17", "Instrument Identifier", ["Instrument Identifier ID", "Identified Instrument", "Instrument Identifier Scheme",
                                             "Instrument Identifier Value", "Identifier Listing", "Issuing Agency",
                                             "Primary Identifier Indicator", "Derived from Own Share Class Indicator",
                                             "Instrument Identifier Status", "Identifier Effective From",
                                             "Identifier Effective To"]),
            ("17", "Instrument Relationship", ["Subject Instrument", "Related Instrument", "Related Index",
                                               "Instrument Relationship Type", "Relationship Ratio", "Basket Weight",
                                               "Relationship Effective From", "Relationship Effective To"]),
            ("17", "Instrument Listing", ["Listing ID", "Listed Instrument", "Listing Venue MIC", "Operating MIC",
                                          "Listing Ticker", "Listing Trading Currency", "Primary Listing Indicator",
                                          "Round Lot Size", "Trading Calendar", "Listing Status", "Listing Date",
                                          "Delisting Date", "Delisting Reason"]),
            ("17", "Instrument Classification Assignment", ["Classified Instrument", "Instrument Classification Scheme",
                                                            "Instrument Classification Code",
                                                            "Instrument Classification Source",
                                                            "Instrument Classification Override Indicator",
                                                            "Instrument Classification Override Reason",
                                                            "Instrument Classification Effective From",
                                                            "Instrument Classification Effective To"]),
            ("17", "Regulatory Instrument Classification", ["Regulatory Classified Instrument",
                                                            "Rule 2a-7 Eligible Security Indicator", "Rule 144A Indicator",
                                                            "Regulation S Indicator", "Restricted Security Indicator",
                                                            "NAIC Designation Category", "NAIC SVO Filing Status",
                                                            "Regulatory Classification Effective From",
                                                            "Regulatory Classification Effective To"]),
            ("17", "Equity Terms", ["Equity Share Type", "Voting Rights Per Share", "Par Value", "Shares Outstanding",
                                    "Shares Outstanding As-Of Date", "Dividend Frequency", "Depositary Receipt Type",
                                    "Depositary Bank", "Cumulative Dividend Indicator", "Preferred Dividend Rate"]),
            ("17", "Fund Instrument Terms", ["Fund Vehicle Type", "Fund Regulatory Regime", "Fund Domicile",
                                             "Fund Manager or General Partner", "Own Investment Product", "Peer Fund",
                                             "Fund Dealing Frequency", "Fund Distribution Policy", "Money Market Fund Type"]),
            ("17", "Debt Terms", ["Coupon Type", "Coupon Rate", "Coupon Frequency", "Day Count Convention",
                                  "Business Day Convention", "Payment Calendar", "Reference Rate", "Reference Rate Term",
                                  "Floating Rate Spread", "Coupon Floor Rate", "Coupon Cap Rate", "Maturity Date",
                                  "Perpetual Indicator", "Dated Date", "First Coupon Date", "Issue Price", "Amount Issued",
                                  "Amount Outstanding", "Amount Outstanding As-Of Date", "Minimum Denomination",
                                  "Debt Seniority", "Debt Guarantor", "Callable Indicator", "Puttable Indicator",
                                  "Tax-Exempt Indicator", "Inflation-Linked Indicator", "In Default Indicator",
                                  "Sustainable Bond Label"]),
            ("17", "Coupon Schedule", ["Coupon Instrument", "Coupon Period Number", "Accrual Start Date", "Accrual End Date",
                                       "Coupon Payment Date", "Coupon Record Date", "Scheduled Coupon Rate",
                                       "Rate Fixing Date", "Irregular Period Indicator"]),
            ("17", "Redemption Schedule", ["Redemption Instrument", "Redemption Event Type", "Redemption Start Date",
                                           "Redemption End Date", "Redemption Price", "Scheduled Redemption Amount",
                                           "Notice Period Days", "Make-Whole Spread", "Partial Redemption Allowed Indicator"]),
            ("17", "Securitized Product Terms", ["Securitized Collateral Type", "Pool Number", "Deal Name", "Tranche Class",
                                                 "Tranche Seniority Rank", "Original Face Amount",
                                                 "Original Weighted Average Maturity", "Payment Delay Days",
                                                 "Collateral Manager or Servicer", "Reinvestment Period End Date"]),
            ("17", "Listed Derivative Contract Terms", ["Contract Multiplier", "Contract Unit", "Tick Size", "Tick Value",
                                                        "Expiry Date", "Last Trading Date", "First Notice Date",
                                                        "Option Right", "Strike Price", "Option Style",
                                                        "Settlement Method", "Clearing House"]),
            ("17", "OTC Derivative Product Terms", ["OTC Asset Class", "OTC Base Product", "OTC Sub-Product",
                                                    "Notional Currency", "Other Notional Currency", "OTC Reference Rate",
                                                    "OTC Delivery Type", "OTC Option Style", "Governing Definitions",
                                                    "Clearing Mandate Indicator"]),
            ("17", "Private Asset Terms", ["Private Asset Type", "Security Class Description", "Loan Facility Type",
                                           "Administrative Agent", "Real Asset Country", "Transfer Restriction Indicator"]),
            ("17", "Fund Interest Terms", ["Vintage Year", "Private Fund Strategy", "Commitment Currency",
                                           "Private Fund Legal Form", "Final Close Date", "Investment Period End Date",
                                           "Fund Term Years", "Fund Term Extension Years"]),
            ("01", "Benchmark", ["Benchmark ID", "Benchmark Name", "Benchmark Vendor Code"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Legal Name", "Share Class Currency",
                                   "Share Class Status"]),
            ("01", "Security Identifier", ["ISIN", "CUSIP", "FIGI", "FISN"]),
            ("01", "Listing", ["Listing Exchange", "Exchange Ticker", "Primary Listing Indicator"]),
            ("09", "Classification Scheme", ["Classification Scheme ID", "Scheme Name", "Scheme Version",
                                             "License Required Indicator"]),
            ("09", "Classification Code", ["Classification Code", "Classification Label", "Classification Level",
                                           "Parent Classification Code"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Status"]),
        ],
        upstream=["DP-004", "DP-013"],
        refresh="Intraday",
        timeliness=("A new or changed instrument is published within 15 minutes of golden-copy approval, so an order can be "
                    "placed on it the same day; the end-of-day snapshot of every table is complete by 6am ET on T+1"),
        history=("SCD type 2 on the instrument and every child table (identifiers, listings, classifications, regulatory "
                 "classification, terms, schedules, relationships) from first set-up; inactive, matured and delisted "
                 "instruments are kept indefinitely so that historical holdings and trades always resolve; end-of-day "
                 "snapshots kept 10 years"),
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "File extract"],
        dq_rules=[
            "Every active instrument has an Instrument Type, an Instrument Status and a Denomination Currency that resolves to an active currency in DP-013, and its Asset Class equals level 1 of its open firm asset-class Instrument Classification Assignment.",
            "An (Instrument Identifier Scheme, Instrument Identifier Value) pair is active on at most one instrument on any date, and every ISIN passes the ISO 6166 check digit and every CUSIP the CUSIP check digit.",
            "Every instrument with Instrument Type = Own Fund Share Class has an Own Share Class that resolves to an active DP-004 Share Class ID, a blank Issuer, no Instrument Listing rows, and only identifier rows with Derived from Own Share Class Indicator = Y whose values equal the 01 Security Identifier.",
            "For one instrument and identifier scheme, listing venue, classification scheme or regulatory classification, effective periods do not overlap and every Effective To is on or after its Effective From.",
            "For every fixed income instrument, Maturity Date is on or after Issue Date unless Perpetual Indicator = Y, consecutive Coupon Schedule periods are contiguous (Accrual Start Date of period n+1 = Accrual End Date of period n), and Callable Indicator = Y exactly when a Redemption Schedule row of a call event type exists.",
            "Every Instrument Classification Code resolves to an active 09 Classification Code of the referenced Classification Scheme version, and fields from a scheme with License Required Indicator = Y or from a licensed Source Dataset are served only to consumers entitled in 14.",
        ],
        notes=("Master concept: 'Instrument (security master)' (17, INS-), 'Instrument Identifier' (17, IID-) and 'Instrument "
               "Listing' (17, LST-) in CONCEPT_OWNERSHIP; the product publishes them and never remasters them (CD-154, "
               "CD-300). SM-00 Instrument dimension, tagged Foundations (CD-296). "
               "Certified numbers: none. DP-097 owns no CD-293, CD-320, CD-330, CD-340 or CD-341 family; every certified "
               "investment number is sliced by its Instrument ID. "
               "Own share classes (CD-143, CD-154, CD-300): an own share class held by an own portfolio is a row of type "
               "'Own Fund Share Class' carrying the DP-004 Share Class ID. Its identifiers are read from 01 Security "
               "Identifier and 01 Share Class through DP-004 and its venue from 01 Listing (17 creates no listing for it); "
               "DP-097 republishes only the instrument key, type and the derived identifiers and checks them against 01 "
               "(Own Share Class Identifier Mismatches). DP-004 does not read 01 Listing today, so that object is read "
               "directly from its master. "
               "Copies read on purpose: Instrument Name, FISN, CFI Code, Denomination Currency, Country of Issue and Issue "
               "Date (Instrument) and the six fund term attributes on Fund Instrument Terms are flagged Derived copy (01) "
               "at attribute level, but 17 masters them for every third-party and other instrument (17 Source_Notes §2); "
               "they are read from 17, and for Own Fund Share Class rows the 01 values win. Classification Level and Label "
               "are read from the 09 Classification Code master, not the 17 copies. The underlying index (Related Index) "
               "resolves to 01 Benchmark, which DP-004 conforms (CD-322); 17 has no Index object (17 SME question 4). "
               "Issuer: the instrument row carries the issuer party key only; issuer name, parents, sector and ratings "
               "come from DP-098, which also measures instruments whose issuer has no issuer profile. "
               "Out of scope (CD-300): prices, evaluated analytics and pool factors (22, CD-167), internal credit "
               "assessments (23, CD-173), ESG data (34), risk measures (31), holdings (18) and set-up requests (DP-102). "
               "Shares Outstanding and Amount Outstanding are slowly changing reference values with their own as-of dates "
               "(17 SME question 12). "
               "Operating model (CD-297): drafted for an in-house EDM or IBOR platform with vendor feeds (17 SME question 1). "
               "If security master operations are outsourced (vendor golden copy or IBOR provider), the grain is unchanged "
               "because the firm still owns the record its holdings key on; the provider's daily golden-copy delivery and "
               "exception feed become the source, and Primary Data Provider records it. "
               "Licensed data (CD-164): vendor identifiers (FIGI excepted), CFI and GICS-type codes and vendor terms are "
               "licensed; classification Confidential - Licensed, with entitlement filtering through 14. "
               "Taxonomy gap: no attribute records which vendor source won per field family (golden-copy survivorship, "
               "brief §8 question 1); only the instrument-level Primary Data Provider and Source Dataset exist. "
               "Taxonomy gap: Instrument carries no effective dates or golden-copy approval timestamp; versions of the "
               "instrument row are kept by the product as SCD type 2, and set-up timeliness is measured in DP-102 from 17 "
               "Instrument Setup Request. "
               "Open SME questions (17 Source_Notes §4): 1 security master of record and survivorship; 2 OTC derivatives at "
               "UPI level or per trade; 5 every own share class or only those held or listed (recommended: only held or "
               "listed); 7 private asset set-up and identifier scheme; 8 licensed sector schemes; 11 CFI on the instrument; "
               "12 outstanding amounts as reference or 22 time series. "
               "Rests on CD-143, CD-154, CD-164, CD-167, CD-173, CD-296, CD-297, CD-300, CD-322. "
               "W1: UCITS Eligible Asset Indicator, UCITS Eligible Asset Category, MiFID II Complex Instrument Indicator, "
               "EU or UK Trading Venue Indicator and Solvency II CIC Code (Regulatory Instrument Classification) dropped, no "
               "successor in the wealth 17 (CW-917); the measure Regulatory Classification Coverage % that read them goes. "
               "W1: STS Securitization Indicator (Securitized Product Terms) dropped, no successor in the wealth 17 (CW-917). "
               "W1 re-point: SEDOL is no longer an attribute of 01 Security Identifier (CW-901); a SEDOL is read as an 17 "
               "Instrument Identifier row with Instrument Identifier Scheme = SEDOL, and Own Share Class Identifier "
               "Mismatches compares ISIN, CUSIP and FIGI only."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-098": dict(
        definition=("The issuer dimension: every party that issues, guarantees or stands behind an instrument the firm "
                    "holds or references, with its security-master issuer profile, its legal direct and ultimate parent "
                    "from the party master, the credit parent overrides research maintains, sector classifications by "
                    "scheme and agency credit ratings of issuers and issues with history. It conforms the master concepts "
                    "'Issuer Profile' and 'Credit Rating Assignment' (CONCEPT_OWNERSHIP rows 17) and takes the party "
                    "identity, organization profile, legal hierarchy and identifiers from DP-240 (CD-360), so a bank that is "
                    "both issuer and counterparty is one party. It gives concentration limits, exposure reporting, "
                    "regulatory filings and research one answer to who the issuer is, who stands behind it, what sector it "
                    "is in and how it is rated. It is the source of no certified metric family."),
        business_questions=[
            "Who is the issuer of an instrument, who are its legal direct and ultimate parents and, where research overrides them, its credit parent?",
            "What is the total set of issuers that roll up to one ultimate or credit parent, for concentration limit and exposure aggregation?",
            "What is the current agency rating of each issue and issuer by agency, the composite rating and investment-grade status, and which ratings changed or went on watch this period?",
            "Which sector does an issuer belong to in each licensed and firm scheme, and which scheme is primary?",
            "Which held or referenced instruments have an issuer with no issuer profile, no LEI, no ultimate parent or no primary sector, and so fail limit testing or regulatory reporting?",
        ],
        grain=("Issuer party x effective period (SCD type 2), with child tables at issuer party x related party x issuer "
               "relationship type x effective period, issuer party x classification scheme x sector code x effective period, "
               "and rated instrument or rated issuer x credit rating agency x credit rating type x action date"),
        dimensions=["Issuer (party)", "Issuer type", "Country of risk", "Legal direct and ultimate parent", "Credit parent",
                    "Guarantor", "Sector classification scheme and code", "Credit rating agency and rating type",
                    "Normalized rating notch and investment-grade flag", "Instrument (DP-097)", "Effective date / version"],
        measures=[
            ("Active Issuers", "Count of distinct Issuer Party with Issuer Profile Status = active on the as-of date, by Issuer Type and Country of Risk.",
             [("17", "Issuer Profile", "Issuer Party"), ("17", "Issuer Profile", "Issuer Profile Status"),
              ("17", "Issuer Profile", "Issuer Type"), ("17", "Issuer Profile", "Country of Risk")]),
            ("Instruments Without Issuer Profile", "Count of active instruments (DP-097) other than Own Fund Share Class and derivative contract types whose Issuer is blank or has no active Issuer Profile.",
             [("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Issuer"), ("17", "Instrument", "Instrument Type"),
              ("17", "Instrument", "Instrument Status"), ("17", "Issuer Profile", "Issuer Party"),
              ("17", "Issuer Profile", "Issuer Profile Status")]),
            ("Issuers Without LEI %", "Active Issuers whose party has no LEI Record with LEI Registration Status = issued / Active Issuers.",
             [("02", "LEI Record", "LEI"), ("02", "LEI Record", "LEI Registration Status"), "Active Issuers"]),
            ("Ultimate Parent Coverage %", "Active Issuers whose party has an Ultimate Parent in 02 Legal Entity Hierarchy / Active Issuers.",
             [("02", "Legal Entity Hierarchy", "Ultimate Parent"), "Active Issuers"]),
            ("Credit Parent Overrides Open", "Count of Issuer Relationship rows open on the as-of date with Issuer Relationship Type = credit parent whose Related Party differs from the issuer's 02 Ultimate Parent.",
             [("17", "Issuer Relationship", "Subject Issuer"), ("17", "Issuer Relationship", "Related Party"),
              ("17", "Issuer Relationship", "Issuer Relationship Type"),
              ("17", "Issuer Relationship", "Issuer Relationship Effective To"),
              ("02", "Legal Entity Hierarchy", "Ultimate Parent")]),
            ("Primary Sector Coverage %", "Active Issuers with exactly one Issuer Classification Assignment open on the as-of date with Primary Sector Scheme Indicator = Y / Active Issuers.",
             [("17", "Issuer Classification Assignment", "Classified Issuer"),
              ("17", "Issuer Classification Assignment", "Primary Sector Scheme Indicator"),
              ("17", "Issuer Classification Assignment", "Issuer Classification Effective To"), "Active Issuers"]),
            ("Composite Agency Rating Notch", "Per rated instrument (or issuer where no issue rating exists): of the current Normalized Credit Rating Notch values (Credit Rating Effective To open) across agencies for the long-term rating type, the middle value where three agencies rate, the lower (worse) where two, the single value where one.",
             [("17", "Credit Rating Assignment", "Rated Instrument"), ("17", "Credit Rating Assignment", "Rated Issuer"),
              ("17", "Credit Rating Assignment", "Credit Rating Agency"),
              ("17", "Credit Rating Assignment", "Credit Rating Type"),
              ("17", "Credit Rating Assignment", "Normalized Credit Rating Notch"),
              ("17", "Credit Rating Assignment", "Credit Rating Effective To")]),
            ("Investment Grade Flag", "Y when Composite Agency Rating Notch is at or better than the notch equivalent to BBB- / Baa3; N otherwise; blank when unrated.",
             ["Composite Agency Rating Notch"]),
            ("Rated Issuer Coverage %", "Active Issuers with an active debt instrument in DP-097 that have at least one current issuer rating (Rated Issuer populated, Credit Rating Effective To open) / Active Issuers with an active debt instrument.",
             [("17", "Credit Rating Assignment", "Rated Issuer"), ("17", "Credit Rating Assignment", "Credit Rating Effective To"),
              ("17", "Instrument", "Asset Class"), ("17", "Instrument", "Issuer"), "Active Issuers"]),
            ("Rating Actions in Period", "Count of Credit Rating Assignment rows with Credit Rating Action Date in the period, by Credit Rating Action (upgrade, downgrade, affirmation, new, withdrawn) and Credit Rating Agency.",
             [("17", "Credit Rating Assignment", "Credit Rating Action Date"),
              ("17", "Credit Rating Assignment", "Credit Rating Action"),
              ("17", "Credit Rating Assignment", "Credit Rating Agency")]),
            ("Ratings on Watch", "Count of current ratings (Credit Rating Effective To open) with Credit Rating Watch Status other than none, or Credit Rating Outlook = negative, by agency.",
             [("17", "Credit Rating Assignment", "Credit Rating Watch Status"),
              ("17", "Credit Rating Assignment", "Credit Rating Outlook"),
              ("17", "Credit Rating Assignment", "Credit Rating Effective To"),
              ("17", "Credit Rating Assignment", "Credit Rating Agency")]),
        ],
        inputs=[
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk", "Country of Risk Basis",
                                      "CUSIP Issuer Number", "Bloomberg Company ID", "Primary Equity Instrument",
                                      "Issuer Profile Status", "Issuer Profile Effective From"]),
            ("17", "Issuer Relationship", ["Subject Issuer", "Related Party", "Issuer Relationship Type", "Guarantee Coverage",
                                           "Override Reason", "Issuer Relationship Effective From",
                                           "Issuer Relationship Effective To"]),
            ("17", "Issuer Classification Assignment", ["Classified Issuer", "Issuer Classification Scheme", "Issuer Sector Code",
                                                        "Issuer Classification Source", "Primary Sector Scheme Indicator",
                                                        "Issuer Classification Effective From",
                                                        "Issuer Classification Effective To"]),
            ("17", "Credit Rating Assignment", ["Rated Instrument", "Rated Issuer", "Credit Rating Agency", "Credit Rating Type",
                                                "Credit Rating Value", "Credit Rating Outlook", "Credit Rating Watch Status",
                                                "Credit Rating Action", "Credit Rating Action Date",
                                                "Normalized Credit Rating Notch", "Credit Rating Effective To",
                                                "Credit Rating Source Dataset"]),
            ("17", "Instrument", ["Instrument ID", "Issuer", "Instrument Type", "Asset Class", "Instrument Status"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party"]),
            ("02", "Organization", ["Legal Name", "Legal Form", "Legal Jurisdiction", "Industry Classification",
                                    "Primary Regulator"]),
            ("02", "Legal Entity Hierarchy", ["Subsidiary Party", "Direct Parent", "Ultimate Parent",
                                              "Parent Relationship Basis", "Hierarchy Effective From",
                                              "Hierarchy Effective To"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status", "Role Effective From", "Role Effective To"]),
            ("02", "Party Identifier", ["Identified Party", "Identifier Value", "Identifier Scheme", "Identifier Status",
                                        "Identifier Effective From"]),
            ("02", "LEI Record", ["LEI", "LEI Registration Status"]),
            ("09", "Classification Scheme", ["Classification Scheme ID", "Scheme Name", "Scheme Version",
                                             "License Required Indicator"]),
            ("09", "Classification Code", ["Classification Code", "Classification Label", "Classification Level",
                                           "Parent Classification Code"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor"]),
        ],
        upstream=["DP-097", "DP-013", "DP-240"],
        refresh="Daily",
        timeliness="By 6am ET each business day for the prior day's profile, parent, classification and rating changes",
        history=("SCD type 2 on the issuer profile, issuer relationships and classification assignments since first set-up; "
                 "every rating action kept as its own row indefinitely, so the rating of any issue or issuer on any past date "
                 "can be reproduced"),
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract"],
        dq_rules=[
            "Every Issuer Party resolves to an active DP-240 party with Party Type = organization and an open Party Role of type Issuer, and a party with Merged Into Party populated has no active Issuer Profile.",
            "Each active issuer has exactly one Issuer Classification Assignment with Primary Sector Scheme Indicator = Y open on any date, and every Issuer Sector Code resolves to an active 09 Classification Code of the referenced scheme version.",
            "An issue rating has Rated Instrument populated and Rated Issuer blank, an issuer rating has Rated Issuer populated and Rated Instrument blank, and every Credit Rating Value maps to a Normalized Credit Rating Notch.",
            "For one rated instrument or issuer x Credit Rating Agency x Credit Rating Type, at most one rating row has Credit Rating Effective To open, and Credit Rating Effective To is on or after Credit Rating Action Date.",
            "Every credit parent Issuer Relationship has an Override Reason and a Related Party that differs from the Subject Issuer, and neither the legal nor the credit parent rollup contains a cycle.",
            "Fields from a sector scheme with License Required Indicator = Y and agency ratings from a licensed Credit Rating Source Dataset are served only to consumers entitled in 14.",
        ],
        notes=("Master concept: 'Issuer Profile' and 'Credit Rating Assignment' (17, CONCEPT_OWNERSHIP, CD-154); the party "
               "core stays 02 PTY- (CD-143) and is taken from DP-240, never copied (CD-360). SM-00 Issuer dimension, tagged "
               "Foundations (CD-296, CD-300). "
               "Certified numbers: none. The composite rating and investment-grade flag are reference derivations offered "
               "for convenience; Investment Compliance (33) rule coding may apply its own rating rule per limit and reads "
               "the agency rows directly. "
               "Parents (CD-300, 17 SME question 6): both the legal rollup (02 Legal Entity Hierarchy) and the credit "
               "rollup (17 Issuer Relationship override) are published; the product does not choose one, and the default "
               "for limits is set in 33 rule coding. "
               "Agency ratings only; internal credit assessments and 2a-7 minimal credit risk determinations are 23 "
               "(CD-173). If 17 SME question 3 moves credit ratings to 22, Credit Rating Assignment leaves this product for "
               "the 22 prices product (DP-143). "
               "Relationship Approved By on Issuer Relationship is not published (it is personal data), so PII = N; DP-102 "
               "carries the security master audit. "
               "Boundary with DP-115: a party that is both issuer and counterparty is one DP-240 party with two role "
               "profiles. The DP-115 candidate note (take the party core from DP-098 for issuers) predates CD-360; DP-115 "
               "takes the party identity from DP-240. "
               "Operating model: as DP-097 (security master operations may be outsourced; grain unchanged). "
               "Licensed data (CD-164): GICS, BICS, ICB and agency ratings are licensed; served to entitled consumers only. "
               "Taxonomy gap: CUSIP Issuer Number and Bloomberg Company ID sit on 17 Issuer Profile; moving them into 02 "
               "Party Identifier schemes is proposed in proposals_17.py and still open with 02. "
               "Taxonomy gap: no attribute records which parent rollup is the firm default for concentration limits (17 SME "
               "question 6); until answered the product flags the legal rollup as default. "
               "Open SME questions: 17 questions 3, 6 and 8. "
               "Rests on CD-143, CD-154, CD-164, CD-173, CD-296, CD-300, CD-360. "
               "W1 re-point (CW-902): Organization Type is read from 02 Party Type, and Regulated Entity Indicator from 02 "
               "Organization Primary Regulator (populated = regulated); the hierarchy and identifier rows now carry their "
               "own party keys (Subsidiary Party, Identified Party, Role Party) and Hierarchy effective dates. "
               "W1: Ownership Percentage (Legal Entity Hierarchy) dropped, no successor in the wealth 02 (CW-902); no "
               "measure read it. PII stays N although the wealth 02 flags every Party attribute as personal data (a party "
               "may be an individual): issuers are organizations, and an individual issuer is out of scope (CW-902)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-099": dict(
        definition=("The scrubbed golden copy of every announced corporate action event on an instrument the firm holds or "
                    "follows, with its options, key dates, rates and ratios and announcement status, including investee "
                    "shareholder and bondholder meetings. It conforms the master concept 'Corporate Action Event' "
                    "(CONCEPT_OWNERSHIP row 17, CAE-) and its options, and records against each event how custodian "
                    "notifications compared with the golden copy. Asset servicing, the book of record, fund accounting and "
                    "proxy voting work from the same event and option keys instead of reconciling custodian and vendor "
                    "versions. It is the source of no certified metric family."),
        business_questions=[
            "Which corporate action events are announced on held or followed instruments, with which ex, record, payment and meeting dates, and which are mandatory, mandatory with options or voluntary?",
            "Which events are not yet scrubbed to golden copy although their ex-date or an option's market deadline is near or past?",
            "What options does each event offer, which is the default, and what cash rate, securities ratio, resulting instrument and market deadline apply?",
            "Where did custodian notifications disagree with the golden copy, by event type and custodian, and how often?",
            "Which investee meetings fall in the coming weeks, for proxy voting and lending recall decisions?",
        ],
        grain=("Corporate action event x option number, with the event attributes on every option row (events without "
               "options carry one row); each announcement update (preliminary, confirmed, canceled, withdrawn) is kept as a "
               "version"),
        dimensions=["Corporate action event", "Event type and mandatory / voluntary type", "Announcement status",
                    "Golden copy status", "Option type and default option", "Instrument (DP-097)", "Resulting instrument",
                    "Key dates (announcement, ex, record, payment, meeting, market deadline)", "Announcement source",
                    "Custodian notification (28)", "Effective date / version"],
        measures=[
            ("Announced Events", "Count of distinct Corporate Action Event ID with Announcement Date in the period, by Corporate Action Event Type, Mandatory Voluntary Type and Corporate Action Announcement Status.",
             [("17", "Corporate Action Event", "Corporate Action Event ID"),
              ("17", "Corporate Action Event", "Announcement Date"),
              ("17", "Corporate Action Event", "Corporate Action Event Type"),
              ("17", "Corporate Action Event", "Mandatory Voluntary Type"),
              ("17", "Corporate Action Event", "Corporate Action Announcement Status")]),
            ("Unscrubbed Events at Ex-Date", "Count of events with Corporate Action Announcement Status not canceled or withdrawn, Ex-Date on or before the as-of date and Golden Copy Status other than golden copy.",
             [("17", "Corporate Action Event", "Ex-Date"), ("17", "Corporate Action Event", "Golden Copy Status"),
              ("17", "Corporate Action Event", "Corporate Action Announcement Status")]),
            ("Voluntary Deadlines Due (5 Business Days)", "Count of active options (Option Status = active) of events with Mandatory Voluntary Type in (voluntary, mandatory with options) whose Market Deadline falls within the next five business days of the DP-013 calendar.",
             [("17", "Corporate Action Option", "Option Event"), ("17", "Corporate Action Option", "Market Deadline"),
              ("17", "Corporate Action Option", "Option Status"), ("17", "Corporate Action Event", "Mandatory Voluntary Type")]),
            ("Events Missing Default Option", "Count of events with Mandatory Voluntary Type in (voluntary, mandatory with options) and at least one option that do not have exactly one option with Default Option Indicator = Y.",
             [("17", "Corporate Action Option", "Option Event"), ("17", "Corporate Action Option", "Default Option Indicator"),
              ("17", "Corporate Action Event", "Mandatory Voluntary Type")]),
            ("Custodian Discrepancy Rate %", "Corporate Action Notification Receipts with Golden Copy Discrepancy Indicator = Y / all receipts in the period, by Corporate Action Event Type.",
             [("28", "Corporate Action Notification Receipt", "Notified Event"),
              ("28", "Corporate Action Notification Receipt", "Golden Copy Discrepancy Indicator"),
              ("17", "Corporate Action Event", "Corporate Action Event Type")]),
            ("Orphan Custodian Notifications", "Count of Corporate Action Notification Receipts whose Notified Event does not resolve to a Corporate Action Event ID; target 0.",
             [("28", "Corporate Action Notification Receipt", "Notified Event"),
              ("28", "Corporate Action Notification Receipt", "Custodian Message Reference"),
              ("17", "Corporate Action Event", "Corporate Action Event ID")]),
            ("Upcoming Investee Meetings", "Count of events of a meeting Corporate Action Event Type (annual, extraordinary, ordinary, bondholder, court) with Meeting Date in the next 30 days and Corporate Action Announcement Status = confirmed.",
             [("17", "Corporate Action Event", "Corporate Action Event Type"), ("17", "Corporate Action Event", "Meeting Date"),
              ("17", "Corporate Action Event", "Corporate Action Announcement Status")]),
            ("Events on Inactive Instruments", "Count of events with Corporate Action Payment Date on or after the as-of date whose Event Instrument has Instrument Status other than active in DP-097.",
             [("17", "Corporate Action Event", "Event Instrument"), ("17", "Corporate Action Event", "Corporate Action Payment Date"),
              ("17", "Instrument", "Instrument Status")]),
        ],
        inputs=[
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Official Corporate Action Event Reference",
                                              "Event Instrument", "Corporate Action Event Type", "Mandatory Voluntary Type",
                                              "Corporate Action Announcement Status", "Golden Copy Status", "Offeror",
                                              "Announcement Date", "Ex-Date", "Record Date", "Meeting Date",
                                              "Corporate Action Payment Date", "Effective Date",
                                              "Announcement Message Standard", "Announcement Source", "Linked Event"]),
            ("17", "Corporate Action Option", ["Option Event", "Option Number", "Corporate Action Option Type",
                                               "Default Option Indicator", "Option Currency", "Cash Rate Per Share",
                                               "Resulting Instrument", "New Securities Quantity", "Old Securities Quantity",
                                               "Option Price", "Market Deadline", "Fraction Disposition", "Option Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Instrument Status", "Own Share Class"]),
            ("17", "Instrument Identifier", ["Identified Instrument", "Instrument Identifier Scheme",
                                             "Instrument Identifier Value"]),
            ("28", "Corporate Action Notification Receipt", ["Notified Event", "Custodian Event Reference",
                                                             "Custodian Message Reference", "Notification Function",
                                                             "Custodian Response Deadline",
                                                             "Golden Copy Discrepancy Indicator"]),
        ],
        upstream=["DP-097", "DP-013"],
        refresh="Intraday",
        timeliness=("A golden-copy status change or announcement update is published within 30 minutes; the complete "
                    "end-of-day event and option set is available by 7pm ET, and the prior day's set is final by 6am ET on T+1"),
        history=("Every announcement version of every event and option kept as SCD type 2 for 10 years after the payment "
                 "date, to support tax reclaims, class action claims and proxy voting evidence"),
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "API", "Event stream", "File extract"],
        dq_rules=[
            "Every event has an Event Instrument that resolves to a DP-097 Instrument ID, and an Official Corporate Action Event Reference, where the market allocates one, that is unique across events.",
            "For every event Record Date is on or before Corporate Action Payment Date, mandatory cash and stock distributions carry an Ex-Date, and Meeting Date is populated exactly when Corporate Action Event Type is a meeting type.",
            "Option Number is unique within an event, and every voluntary or mandatory-with-options event with options has exactly one option with Default Option Indicator = Y.",
            "A cash option carries Option Currency and Cash Rate Per Share, and a securities option carries New Securities Quantity, Old Securities Quantity and a Resulting Instrument that resolves to a DP-097 instrument.",
            "An event whose Corporate Action Announcement Status is canceled or withdrawn has no option with Option Status = active.",
            "Every 28 Corporate Action Notification Receipt resolves to an existing Corporate Action Event ID.",
        ],
        notes=("Master concept: 'Corporate Action Event' (17, CAE-) in CONCEPT_OWNERSHIP, with its options; the product "
               "publishes the event reference and never remasters it (CD-154, CD-300). SM-00 Corporate Action Event "
               "dimension for 28, 18 and 34. "
               "Certified numbers: none. "
               "Event reference only (CD-195): entitlements, elections and payments are 28 and are not in this product; the "
               "position effect is an 18 Portfolio Transaction; investee agenda items, ballots and votes are 34 (CD-226), "
               "which keys them to the event published here. 28 Corporate Action Notification Receipt is read only for the "
               "golden-copy comparison (Golden Copy Discrepancy Indicator), where the relationship lives in 28; no 28 product "
               "is upstream, so the dependency order holds. "
               "Scrubbed By is not published (it is personal data), so PII = N; DP-102 Instrument Setup & Security Master "
               "Quality carries the scrubbing audit. Offeror is published as the party key only. "
               "Who scrubs events, the security master team or 28 asset servicing, is 17 SME question 9; the product owner "
               "role follows the answer and the product stays 17-owned (brief §8 question 4). "
               "Operating model (CD-297): drafted for in-house scrubbing with vendor and DTCC GCA feeds. If asset servicing is "
               "outsourced to the custodian, the custodian notification becomes the main source, the grain is unchanged and "
               "Announcement Source records which source the golden copy took per event. "
               "Licensed data (CD-164): vendor event feeds are licensed; served to entitled consumers only. "
               "Taxonomy gap: Corporate Action Event has no timestamp for golden-copy approval, so scrubbing timeliness is "
               "measured against ex-date (Unscrubbed Events at Ex-Date) instead of as elapsed time from announcement. "
               "Taxonomy gap: no attribute records which source won per event field when vendor and custodian versions "
               "differ; only the event-level Announcement Source exists. "
               "Rests on CD-154, CD-164, CD-195, CD-226, CD-297, CD-300."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-100": dict(
        definition=("The governed register of what the firm's data means and who is accountable for it: every taxonomy "
                    "element with its release-by-release registrations, the taxonomy releases, the business glossary and "
                    "its links to elements, the decision log, the data governance bodies, effective-dated ownership and "
                    "stewardship assignments, critical data elements and data classification assignments. It conforms the "
                    "master concepts 'Taxonomy Element', 'Business Term' and 'Governance Decision' (CONCEPT_OWNERSHIP rows "
                    "21, CD-160, CD-162). Every other product resolves an attribute's meaning, owner, CDE status and "
                    "classification here. It is generated by the build from the consolidated taxonomy, its baseline and "
                    "decisions.py (CD-295) and is the source of no certified metric family."),
        business_questions=[
            "What does a taxonomy element mean in a given release, which Data Domain masters it, is it a CDE, and what changed since the previous release?",
            "Who is the data owner and the data steward of each Data Domain, object, attribute, code list, term, data product or metric today, and which scopes have no owner or an owner who has left?",
            "Which attributes are critical data elements, for which data product or regulatory driver, and is the published CDE flag consistent with the CDE register?",
            "How is each element and data asset classified (information classification, personal data categories, special category data), and which elements are not yet classified?",
            "Which governance decisions are open, by status, priority and Data Domain, and which were applied in each release?",
        ],
        grain=("Taxonomy element x taxonomy release (registration), with governance child tables at governed scope x "
               "governance role x employee x effective period (ownership), CDE x scope x effective period, element or data "
               "asset x classification scheme x effective period, business term and term relationship, and governance "
               "decision"),
        dimensions=["Taxonomy element (Data Domain, family, object, attribute)", "Taxonomy release", "Taxonomy level",
                    "Business term", "Governance decision and status", "Governance body", "Governance role",
                    "Owner / steward (employee, org unit)", "CDE scope and regulatory driver", "Information classification",
                    "Personal data category", "Code list", "Effective date / version"],
        measures=[
            ("Registered Elements by Release", "Count of Taxonomy Element Registration rows per Registering Release, by Published Object Kind, Mastered In Data Domain and Element Change Type.",
             [("21", "Taxonomy Element Registration", "Registered Taxonomy Element"),
              ("21", "Taxonomy Element Registration", "Registering Release"),
              ("21", "Taxonomy Element Registration", "Published Object Kind"),
              ("21", "Taxonomy Element Registration", "Mastered In Data Domain"),
              ("21", "Taxonomy Element Registration", "Element Change Type")]),
            ("Element Changes in Release", "Count of registrations in a release with Element Change Type other than unchanged, by change type (added, changed, renamed, moved, retired) and Element Data Domain.",
             [("21", "Taxonomy Element Registration", "Element Change Type"),
              ("21", "Taxonomy Element Registration", "Registering Release"),
              ("21", "Taxonomy Element", "Element Data Domain")]),
            ("Data Owner Coverage %", "Active L3 Taxonomy Elements in the current release with a Data Ownership Assignment of Governance Role = data owner open on the as-of date / active L3 Taxonomy Elements, by Element Data Domain.",
             [("21", "Taxonomy Element", "Taxonomy Element Key"), ("21", "Taxonomy Element", "Taxonomy Level"),
              ("21", "Taxonomy Element", "Taxonomy Element Status"), ("21", "Taxonomy Element", "Element Data Domain"),
              ("21", "Data Ownership Assignment", "Governed Taxonomy Element"),
              ("21", "Data Ownership Assignment", "Governance Role"),
              ("21", "Data Ownership Assignment", "Assignment Effective From"),
              ("21", "Data Ownership Assignment", "Assignment Effective To")]),
            ("Data Steward Coverage %", "As Data Owner Coverage %, for Governance Role = data steward.",
             [("21", "Data Ownership Assignment", "Governance Role"),
              ("21", "Data Ownership Assignment", "Governed Taxonomy Element"),
              ("21", "Data Ownership Assignment", "Assignment Effective To"), ("21", "Taxonomy Element", "Taxonomy Level")]),
            ("Assignments Held by Leavers", "Count of Data Ownership Assignments and Critical Data Elements open on the as-of date whose Assigned Employee or CDE Owner has Employment Status other than active in 20.",
             [("21", "Data Ownership Assignment", "Assigned Employee"),
              ("21", "Data Ownership Assignment", "Assignment Effective To"), ("21", "Critical Data Element", "CDE Owner"),
              ("21", "Critical Data Element", "CDE Effective To"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status")]),
            ("Active CDEs", "Count of distinct CDE Taxonomy Attribute with a Critical Data Element row open on the as-of date, by CDE Scope, CDE Regulatory Driver and Data Domain.",
             [("21", "Critical Data Element", "CDE ID"), ("21", "Critical Data Element", "CDE Taxonomy Attribute"),
              ("21", "Critical Data Element", "CDE Scope"), ("21", "Critical Data Element", "CDE Regulatory Driver"),
              ("21", "Critical Data Element", "CDE Effective To")]),
            ("CDE Flag Mismatches", "Count of current-release L4 registrations where Published CDE Flag = Y and no Critical Data Element is open for the element, plus open Critical Data Elements whose current-release registration has Published CDE Flag = N; target 0.",
             [("21", "Taxonomy Element Registration", "Published CDE Flag"),
              ("21", "Taxonomy Element Registration", "Registered Taxonomy Element"),
              ("21", "Critical Data Element", "CDE Taxonomy Attribute"), ("21", "Critical Data Element", "CDE Effective To")]),
            ("Classification Coverage %", "Active L4 Taxonomy Elements in the current release with a Data Classification Assignment open on the as-of date / active L4 Taxonomy Elements, by Element Data Domain.",
             [("21", "Data Classification Assignment", "Classified Taxonomy Element"),
              ("21", "Data Classification Assignment", "Classification Effective To"),
              ("21", "Taxonomy Element", "Taxonomy Level"), ("21", "Taxonomy Element", "Taxonomy Element Status")]),
            ("Personal Data Elements", "Count of elements with an open Data Classification Assignment whose Assigned Personal Data Categories is not none, with the subsets flagged Special Category Data Indicator = Y and CPRA Sensitive Personal Information Indicator = Y.",
             [("21", "Data Classification Assignment", "Assigned Personal Data Categories"),
              ("21", "Data Classification Assignment", "Special Category Data Indicator"),
              ("21", "Data Classification Assignment", "CPRA Sensitive Personal Information Indicator")]),
            ("Glossary Linkage %", "Business Terms with Business Term Status = approved that have at least one Business Term Relationship to a Related Taxonomy Element / approved Business Terms.",
             [("21", "Business Term", "Business Term ID"), ("21", "Business Term", "Business Term Status"),
              ("21", "Business Term Relationship", "Source Business Term"),
              ("21", "Business Term Relationship", "Related Taxonomy Element")]),
            ("Open Governance Decisions", "Count of Governance Decisions with Decision Status not in (applied, rejected, withdrawn), by Decision Status, Decision Priority, Decision Theme and Affected Data Domains.",
             [("21", "Governance Decision", "Governance Decision ID"), ("21", "Governance Decision", "Decision Status"),
              ("21", "Governance Decision", "Decision Priority"), ("21", "Governance Decision", "Decision Theme"),
              ("21", "Governance Decision", "Affected Data Domains")]),
            ("Decisions Applied in Release", "Count of Governance Decisions per Applied In Release.",
             [("21", "Governance Decision", "Applied In Release"), ("21", "Taxonomy Release", "Taxonomy Release ID")]),
        ],
        inputs=[
            ("21", "Taxonomy Element", ["Taxonomy Element Key", "Taxonomy Level", "Element Data Domain", "Element Family Name",
                                        "Element Object Name", "Element Attribute Name", "First Registered Release",
                                        "Successor Taxonomy Element", "Taxonomy Element Status"]),
            ("21", "Taxonomy Release", ["Taxonomy Release ID", "Taxonomy Release Status", "Release Scope Domains",
                                        "Release Date", "Predecessor Release"]),
            ("21", "Taxonomy Element Registration", ["Registered Taxonomy Element", "Registering Release",
                                                     "Published Element Code", "Published Element Name",
                                                     "Published Element Definition", "Published Object Kind",
                                                     "Published Grain", "Parent Business Object", "Published Data Type",
                                                     "Published Code List or Format", "Element Code List",
                                                     "Published CDE Flag", "Element Ownership Flag",
                                                     "Mastered In Data Domain", "Element Change Type"]),
            ("21", "Business Term", ["Business Term ID", "Business Term Name", "Business Term Definition",
                                     "Term Owning Data Domain", "Business Term Status", "Governing Code List",
                                     "Defining Metric"]),
            ("21", "Business Term Relationship", ["Source Business Term", "Term Relationship Type", "Related Business Term",
                                                  "Related Taxonomy Element", "Related Element Registered In Release",
                                                  "Term Relationship Effective From"]),
            ("21", "Governance Decision", ["Governance Decision ID", "Decision Title", "Decision Theme", "Decision Issue",
                                           "Decision Resolution", "Decision Rationale", "Decision Action",
                                           "Decision Status", "Decision Priority", "Decision Owner Role",
                                           "Affected Data Domains", "Applied In Release"]),
            ("21", "Data Governance Body", ["Governance Body ID", "Governance Body Name", "Governance Body Type",
                                            "Governance Body Chair", "Parent Governance Body", "Governed Data Domains"]),
            ("21", "Data Ownership Assignment", ["Ownership Assignment ID", "Governance Role", "Assigned Employee",
                                                 "Governed Scope Type", "Governed Data Domain", "Governed Taxonomy Element",
                                                 "Governed Element Registered In Release", "Governed Business Capability",
                                                 "Governed Code List", "Governed Business Term", "Governed Data Product",
                                                 "Governed Data Asset", "Governed Data Quality Rule", "Governed Metric",
                                                 "Appointing Governance Body", "Assignment Effective From",
                                                 "Assignment Effective To"]),
            ("21", "Critical Data Element", ["CDE ID", "CDE Taxonomy Attribute", "CDE Registered In Release", "CDE Scope",
                                             "CDE Scoped Data Product", "CDE Regulatory Driver", "CDE Rationale",
                                             "CDE Owner", "CDE Effective From", "CDE Effective To"]),
            ("21", "Data Classification Assignment", ["Classification Scheme", "Classified Taxonomy Element",
                                                      "Classified Element Registered In Release", "Classified Data Asset",
                                                      "Assigned Information Classification",
                                                      "Assigned Personal Data Categories",
                                                      "Other Scheme Classification Value",
                                                      "Special Category Data Indicator",
                                                      "CPRA Sensitive Personal Information Indicator",
                                                      "Classification Effective From", "Classification Effective To"]),
            ("09", "Code List", ["Code List ID", "Code List Name", "Code List Definition", "Owning Business Domain",
                                 "Registration Status", "Current Version"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Job Title", "Home Org Unit", "Employment Status"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name", "Org Unit Type"]),
        ],
        upstream=["DP-013", "DP-192"],
        refresh="Daily",
        timeliness=("Taxonomy element, registration, glossary and decision rows are regenerated by the build within one "
                    "business day of a release or decision log change; ownership, CDE and classification assignments by "
                    "7am ET on T+1"),
        history=("Every taxonomy release and its registrations kept indefinitely (the register is the record of what each "
                 "release published); ownership, CDE and classification assignments kept as SCD type 2 indefinitely; the "
                 "decision log keeps every status change"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Dashboard"],
        dq_rules=[
            "Every Taxonomy Element Key is unique and equals 'NN | Family | Object | Attribute' built from Element Data Domain, Element Family Name, Element Object Name and Element Attribute Name, and every retired element that was renamed or moved has a Successor Taxonomy Element that is active.",
            "The count of Taxonomy Element Registration rows of the current release equals the object and attribute count of the consolidated taxonomy build for that release, and each active element has exactly one registration per release from its First Registered Release onward.",
            "A governed scope has at most one Data Ownership Assignment per Governance Role open on any date, and exactly the Governed field that matches Governed Scope Type is populated.",
            "Published CDE Flag = Y on a current-release registration exactly when a Critical Data Element is open for that element (CDE Flag Mismatches = 0).",
            "Every Governance Decision has a Decision Status and a Decision Resolution, and every Applied In Release resolves to a Taxonomy Release ID.",
            "Every Data Classification Assignment names exactly one of Classified Taxonomy Element or Classified Data Asset, uses an Assigned Information Classification from the enterprise Information Classification list, and is not held for a data asset that catalogs a 14 licensed dataset (CD-164).",
        ],
        notes=("W1b re-point (CW-921): Data Classification Assignment.GDPR Special Category Data Indicator re-pointed to the renamed Special Category Data Indicator (CD-344 tier, US basis) in the Personal Data Elements measure and the input list. "
               "Master concept: 'Taxonomy Element', 'Business Term' and 'Governance Decision' (21, CONCEPT_OWNERSHIP, CD-160, "
               "CD-162); the product also publishes ownership, CDE and classification assignments, which 21 masters "
               "(CD-301). SM-00 governance dimensions Taxonomy Element and Governance Decision, tagged Foundations. "
               "Certified numbers: none. "
               "Generated, not keyed (CD-295): taxonomy elements, registrations and releases come from the consolidated "
               "taxonomy build and baseline JSON; governance decisions from consolidation/decisions.py; business terms from "
               "the glossary. Ownership, CDE and classification assignments are maintained by the Data Office. "
               "Owners, stewards, CDE owners and governance body chairs are 20 employees read through DP-192, so PII = Y; a "
               "view showing governance role and org unit only, without employee identity, is published Internal for wide "
               "use, and employee identity is restricted to governance users. "
               "Code lists stay 09 (CD-157) and are read through DP-013; the register links to them by Element Code List, "
               "Governing Code List and Governed Code List. Licensed dataset ownership and classification are 14's (CD-164) "
               "and are not restated. Object-level governance profiles (default classification, retention) are DP-101's "
               "(CD-301). "
               "Boundary: DP-101 holds the catalog of assets, lineage and the data product export and reads elements from "
               "this product; DP-103 holds data quality rules, results and issues. "
               "Taxonomy gap: Governance Decision has no raised or decided date, so decision age and time to decision cannot "
               "be measured; Open Governance Decisions is a count only. "
               "Taxonomy gap: Data Governance Body has no membership object; only the chair is recorded. "
               "Open SME questions (21 Source_Notes §4): 2 owners by business capability, Data Domain or both; 3 CDE "
               "designation level; 4 whether the code list registry moves to 21; 11 who stewards Information "
               "Classification. "
               "Rests on CD-157, CD-160, CD-162, CD-164, CD-165, CD-295, CD-301."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-101": dict(
        definition=("The enterprise catalog of the firm's data estate: cataloged data assets including reports and "
                    "dashboards, physical-to-taxonomy element mappings, lineage links, system of record designations and "
                    "object governance profiles, together with the data product catalog itself (data products, their "
                    "inputs, data contracts, semantic model bindings and registered metric definitions with their "
                    "certification status) exported from the build (CD-295). It conforms the master concepts 'Data Asset "
                    "(catalog entry)', 'Data Product' and 'Metric Definition' (CONCEPT_OWNERSHIP rows 21, CD-160, CD-163) "
                    "and is the enterprise successor of DP-075, used for discovery, trust level and change impact for every "
                    "product and asset in every area. It holds the definitions and certification of every certified metric "
                    "family (CD-293, CD-320, CD-330, CD-340, CD-341) but no metric value: values stay with the owning product."),
        business_questions=[
            "Which data products, data assets, reports and metrics exist, who owns them (through DP-100), what grain, classification and certification do they have, and in which semantic model is each published?",
            "Which data assets, feeds, licensed datasets and taxonomy elements feed a given data product or report, and what is affected downstream if one of them changes?",
            "Which system is the system of record or authoritative source for each object and attribute, by business line, and does every designated system exist in the application inventory?",
            "Which metrics are certified, in which semantic model and source data product, and where does the 06 copy of a certification disagree with the register?",
            "Which data products have no active data contract, which certified metrics are not bound in any semantic model, and which reports run on uncertified products?",
        ],
        grain=("Catalog entry (data asset, data product, metric definition or data contract) x version, with child tables at "
               "data product x taxonomy element (input), data asset x physical element x taxonomy element (mapping), lineage "
               "link, taxonomy element x system x designation type x business line x effective period (system of record) "
               "and L3 object x effective period (governance profile)"),
        dimensions=["Catalog entry type", "Data asset type", "Data product (tier, type, owning Data Domain, wave, status)",
                    "Metric definition and certification status", "Semantic model", "Taxonomy element (DP-100)",
                    "Hosting or designated system (Application, DP-211)", "Designation type and business line",
                    "Licensed dataset (14)", "Data feed (06)", "Data contract and consumer", "Report and BI tool",
                    "Effective date / version"],
        measures=[
            ("Cataloged Data Assets", "Count of Data Asset ID with Data Asset Status = active, by Data Asset Type, Asset Owning Data Domain and Hosting System.",
             [("21", "Data Asset", "Data Asset ID"), ("21", "Data Asset", "Data Asset Status"),
              ("21", "Data Asset", "Data Asset Type"), ("21", "Data Asset", "Asset Owning Data Domain"),
              ("21", "Data Asset", "Hosting System")]),
            ("Element Mapping Coverage %", "Active Data Assets of a table, view, file or feed type with at least one Data Element Mapping in Element Mapping Status = approved / those assets.",
             [("21", "Data Element Mapping", "Mapped Data Asset"), ("21", "Data Element Mapping", "Element Mapping Status"),
              ("21", "Data Asset", "Data Asset Type"), "Cataloged Data Assets"]),
            ("Product Lineage Coverage %", "Data products with Data Product Status = specified or published whose every Data Product Input taxonomy element appears as a Mapped Taxonomy Attribute of an approved Data Element Mapping on a Data Asset that is the target of at least one Lineage Link / those data products.",
             [("21", "Data Product", "Data Product ID"), ("21", "Data Product", "Data Product Status"),
              ("21", "Data Product Input", "Input Data Product"), ("21", "Data Product Input", "Input Taxonomy Element"),
              ("21", "Data Element Mapping", "Mapped Taxonomy Attribute"), ("21", "Data Element Mapping", "Mapped Data Asset"),
              ("21", "Lineage Link", "Lineage Target Data Asset"), ("21", "Lineage Link", "Lineage Source Data Asset")]),
            ("System of Record Coverage %", "L3 objects with an Object Governance Profile open on the as-of date that have an open System of Record Designation of Designation Type = system of record / L3 objects with an open profile.",
             [("21", "Object Governance Profile", "Governed Business Object"),
              ("21", "Object Governance Profile", "Profile Effective To"),
              ("21", "System of Record Designation", "Designated Taxonomy Element"),
              ("21", "System of Record Designation", "Designation Type"),
              ("21", "System of Record Designation", "Designation Effective To")]),
            ("Unresolved System References", "Count of open System of Record Designations and active Data Assets whose Designated System or Hosting System does not resolve to a 41 Application with Application Status = active; target 0.",
             [("21", "System of Record Designation", "Designated System"), ("21", "Data Asset", "Hosting System"),
              ("41", "Application", "Application ID"), ("41", "Application", "Application Status")]),
            ("Certified Metric Count", "Count of Metric Definitions with Metric Certification Status = certified, by Metric Owning Data Domain and Owning Semantic Model.",
             [("21", "Metric Definition", "Metric ID"), ("21", "Metric Definition", "Metric Certification Status"),
              ("21", "Metric Definition", "Metric Owning Data Domain"), ("21", "Metric Definition", "Owning Semantic Model")]),
            ("Certification Copy Mismatches", "Count of 06 Measure Definitions whose Certified Indicator differs from the Metric Certification Status of the Metric Definition that registers it (Registered Measure Definition = Measure ID); target 0.",
             [("06", "Measure Definition", "Measure ID"), ("06", "Measure Definition", "Certified Indicator"),
              ("21", "Metric Definition", "Registered Measure Definition"),
              ("21", "Metric Definition", "Metric Certification Status")]),
            ("Unbound Certified Metrics", "Count of certified Metric Definitions whose Metric ID appears in no Semantic Model Binding's Bound Certified Metrics.",
             [("21", "Semantic Model Binding", "Bound Certified Metrics"), ("21", "Semantic Model Binding", "Semantic Model"),
              "Certified Metric Count"]),
            ("Products Without Active Contract", "Count of data products with Data Product Status = published that have no Data Contract with Data Contract Status = active on the as-of date.",
             [("21", "Data Product", "Data Product Status"), ("21", "Data Contract", "Contracted Data Product"),
              ("21", "Data Contract", "Data Contract Status"), ("21", "Data Contract", "Data Contract Effective To")]),
            ("Certified Report Share %", "Active analytics reports and dashboards with Report Certification Status = certified / active analytics reports and dashboards, by BI Tool and Report Primary Data Product.",
             [("21", "Analytics Report & Dashboard Detail", "Report Certification Status"),
              ("21", "Analytics Report & Dashboard Detail", "BI Tool"),
              ("21", "Analytics Report & Dashboard Detail", "Report Primary Data Product")]),
            ("Foundational Dependency Breaches", "Count of Data Products with Data Product Tier = Foundational whose Upstream Data Products include a product of another tier; target 0.",
             [("21", "Data Product", "Data Product Tier"), ("21", "Data Product", "Upstream Data Products")]),
            ("Downstream Impact Count", "For a catalog entry: count of distinct data assets, data products and client feeds or reports reachable from it through Lineage Link edges and Upstream Data Products.",
             [("21", "Lineage Link", "Lineage Source Data Asset"), ("21", "Lineage Link", "Lineage Target Data Asset"),
              ("21", "Lineage Link", "Lineage Target Client Data Feed"), ("21", "Lineage Link", "Lineage Target Client Report"),
              ("21", "Data Product", "Upstream Data Products")]),
        ],
        inputs=[
            ("21", "Data Asset", ["Data Asset ID", "Data Asset Name", "Data Asset Type", "Hosting System", "Physical Location",
                                  "Asset Owning Data Domain", "Cataloged Licensed Dataset", "Cataloged Technical Feed",
                                  "Providing Party", "Data Asset Status"]),
            ("21", "Analytics Report & Dashboard Detail", ["BI Tool", "Report Primary Data Product", "Report Semantic Model",
                                                           "Report Certification Status", "Report Certified Date"]),
            ("21", "Data Element Mapping", ["Mapped Data Asset", "Physical Element Name", "Mapped Taxonomy Attribute",
                                            "Mapped Attribute Registered In Release", "Element Mapping Type",
                                            "Mapping Transformation Rule", "Element Mapping Status"]),
            ("21", "Lineage Link", ["Lineage Link ID", "Lineage Source Data Asset", "Lineage Target Data Asset",
                                    "Lineage Target Client Data Feed", "Lineage Target Client Report",
                                    "Lineage Source Element", "Lineage Target Element", "Lineage Transformation Type",
                                    "Lineage Verified Date"]),
            ("21", "System of Record Designation", ["SoR Designation ID", "Designated Taxonomy Element",
                                                    "Designated Element Registered In Release", "Designated System",
                                                    "Designated Data Asset", "Designation Type", "Designation Business Lines",
                                                    "Designating Decision", "Designation Effective From",
                                                    "Designation Effective To"]),
            ("21", "Object Governance Profile", ["Governed Business Object", "Profile Registered In Release",
                                                 "Object Records Retention Rule", "Default Information Classification",
                                                 "Default Personal Data Categories", "Object Certification Status",
                                                 "Profile Effective From", "Profile Effective To"]),
            ("21", "Data Product", ["Data Product ID", "Data Product Name", "Data Product Definition", "Data Product Tier",
                                    "Data Product Type", "Data Product Owning Data Domain", "Data Product Owner Role",
                                    "Primary Business Function", "Supporting Business Functions", "Data Product Wave",
                                    "Data Product Priority", "Data Product Value Rationale", "Data Product Dependency Note",
                                    "Upstream Data Products", "Data Product Grain", "Data Product Dimensions",
                                    "Data Product Measure Count", "Business Question Count", "Data Product DQ Rule Count",
                                    "Data Product Refresh", "Data Product Timeliness", "Data Product History Approach",
                                    "Data Product Classification", "Data Product Contains Personal Data",
                                    "Data Product Delivery Modes", "Data Product Specification Reference",
                                    "Data Product Status"]),
            ("21", "Data Product Input", ["Input Data Product", "Input Taxonomy Element", "Input Registered In Release",
                                          "Input Role"]),
            ("21", "Data Contract", ["Data Contract ID", "Contracted Data Product", "Consumer Org Unit",
                                     "Consumer External Party", "Data Contract Version", "Data Contract Standard",
                                     "Data Contract Status", "Contracted DQ Rules", "Freshness Commitment",
                                     "Availability Target %", "Data Contract Effective From", "Data Contract Effective To"]),
            ("21", "Semantic Model Binding", ["Semantic Model", "Published Entities", "Bound Certified Metrics",
                                              "Conformed Dimensions"]),
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Owning Data Domain", "Metric Nature",
                                         "Registered Measure Definition", "Registered Market Share Definition",
                                         "Registered Profitability Measure", "Metric Business Definition",
                                         "Metric Formula", "Metric Unit of Measure", "Metric Currency Basis",
                                         "Metric Aggregation Rule", "Metric Direction", "Metric Grain",
                                         "Metric Dimensions", "Metric Disclosure Frameworks", "Owning Semantic Model",
                                         "Semantic Model Metric Name", "Metric Source Data Product",
                                         "Metric Certification Status"]),
            ("21", "Taxonomy Element", ["Taxonomy Element Key", "Taxonomy Level", "Element Data Domain",
                                        "Taxonomy Element Status"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Subject Area",
                               "Contains Personal Data Indicator", "Information Sensitivity", "Dataset Status"]),
            ("06", "Data Feed", ["Feed ID", "Feed Name", "Data Provider", "Feed Type", "Delivery Frequency", "Feed Status"]),
            ("06", "Measure Definition", ["Measure ID", "Measure Name", "Business Definition", "Calculation Formula",
                                          "Certified Indicator"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Type", "Owning Org Unit",
                                   "Application Status", "Criticality Tier"]),
        ],
        upstream=["DP-100", "DP-013", "DP-211"],
        refresh="Daily",
        timeliness=("By 7am ET each business day; the CD-295 export rows (data products, inputs, metric definitions, "
                    "semantic model bindings, contracts) are refreshed by each build of the data product register and "
                    "semantic register"),
        history=("Every catalog entry, lineage link, designation, governance profile and exported data product version kept "
                 "as SCD type 2 indefinitely, so the lineage and certification of any product or metric on any past date can "
                 "be shown"),
        classification="Internal",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Dashboard"],
        dq_rules=[
            "Every Data Product row matches exactly one entry of framework.PRODUCTS by Data Product ID, and every Data Product Input resolves to a Taxonomy Element registered in its Input Registered In Release.",
            "The graph of Upstream Data Products has no cycle and Foundational Dependency Breaches = 0.",
            "Every Metric Definition with Metric Certification Status = certified has a Metric Source Data Product that resolves to a Data Product, a Metric Unit of Measure, a Metric Aggregation Rule and an Owning Semantic Model, and is named in that model's Semantic Model Binding.",
            "Every open System of Record Designation and every active Data Asset names a Designated System or Hosting System that resolves to an active DP-211 Application ID, and at most one designation of type system of record is open per taxonomy element and business line on any date.",
            "Every Lineage Link has a Lineage Source Data Asset and exactly one of Lineage Target Data Asset, Lineage Target Client Data Feed or Lineage Target Client Report.",
            "Every Data Asset of type licensed dataset has a Cataloged Licensed Dataset that resolves to an active 14 Dataset ID, and every Data Asset of type feed has a Cataloged Technical Feed that resolves to a 06 Feed ID.",
        ],
        notes=("Master concept: 'Data Asset (catalog entry)', 'Data Product' and 'Metric Definition' (21, CONCEPT_OWNERSHIP, "
               "CD-160, CD-163); also System of Record Designation (CD-161), lineage and object governance profiles (CD-301). "
               "SM-00 governance dimensions Data Product and Metric, tagged Foundations. "
               "Certified numbers: none as values. DP-101 masters the definition and certification of every certified metric "
               "(CD-163) and never a value; values stay with the owning product (DP-008 flows and AUM, DP-012 revenue, "
               "DP-165 NAV and firm AUM (CD-330), DP-145 returns and DP-146 risk (CD-320), DP-191 P&L and operating expense "
               "(CD-340), DP-192 headcount and FTE (CD-341)). The Wave E5 Enterprise KPI & Metrics Registry builds on this "
               "product for definitions and takes values from the owners (CD-301). "
               "CD-295 export: Data Product, Data Product Input, Metric Definition, Semantic Model Binding and Data Contract "
               "rows are written by the build from framework.py, the specs_*.py modules and semantic_model/register.py, so "
               "the catalog holds its own records, this product included. "
               "Copy read on purpose: 06 Measure Definition Certified Indicator is a derived copy of 21 certification "
               "(CD-163); it is read only to reconcile the copy to the master (Certification Copy Mismatches). "
               "Dependency order (CD-361 item 5): DP-101 depends on DP-211 Application & System Inventory for systems "
               "(CD-263), never the reverse, and on DP-100 for taxonomy elements and ownership. "
               "DP-075 (CD-298, CD-301): DP-075 keeps its ID, owner and FN-17 consumer and becomes the distribution view of "
               "this product (filter: assets, products and metrics owned by Data Domains 01-16). DP-075's spec must add "
               "DP-101 upstream and move its lineage inputs here; its 'Taxonomy gap' notes on data product, input and "
               "lineage objects close. That change is DP-075's owner's, not made here. "
               "Boundary: data quality rules, results, issues and product certification against contracts are DP-103 "
               "(CD-301); distribution supply-chain health stays DP-045. Licensed dataset ownership, classification and "
               "permitted use are 14's (CD-164); the Data Asset references 14 Dataset. Ownership of every catalog entry is "
               "read from DP-100 Data Ownership Assignment (Governed Data Product, Governed Data Asset, Governed Metric). "
               "Operating model: in house (Chief Data Office); a catalog tool changes the source, not the grain (brief §2). "
               "Taxonomy gap: 21 has no object for a data product's measures (name, formula, uses) or for its business "
               "questions and DQ rule texts; the export holds only Data Product Measure Count, Business Question Count and "
               "Data Product DQ Rule Count, and Data Product Input cannot record which measure uses an element, so the "
               "metric -> measure -> uses trace of CONTRACT.md rule 3 is not yet held in 21. "
               "Taxonomy gap: there is no Semantic Model object (21 SME question 13); semantic models are a code list and "
               "Semantic Model Binding rows. "
               "Taxonomy gap: the spec 'notes' field (decision references, taxonomy gaps, SME questions) has no 21 attribute. "
               "Open SME questions (21 Source_Notes §4): 1 catalog tool; 8 interim system list before 41; 9 BI report "
               "certification; 10 data contract standard. "
               "Rests on CD-160, CD-161, CD-163, CD-164, CD-263, CD-295, CD-298, CD-301, CD-361."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    # DP-240 re-specified at WP1 in specs_w1f_client.py
}
