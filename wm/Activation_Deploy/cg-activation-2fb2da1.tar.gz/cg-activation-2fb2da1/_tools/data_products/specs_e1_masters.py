"""Data product specifications, Wave E1 group "masters": the masters of the investment and corporate functions.

DP-115 Approved Broker & Counterparty Master (25), DP-116 Investor Capital Accounts (30), DP-117 Private Fund Capital
Calls & Distributions (30), DP-190 Chart of Accounts & Ledger (19), DP-191 General Ledger Journals & Balances (19),
DP-192 Employee & Position Master (20), DP-210 Vendor Master (40), DP-211 Application & System Inventory (41),
DP-212 Model Inventory & Validation (37), DP-213 Enterprise Contract Register (39). See CONTRACT.md.

WP1 lineage pass: the specs of the retired DP-116 and DP-117 are deleted (framework.RETIRED_PRODUCTS; register rows kept).
"""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-115": dict(
        definition=("The conformed master of every broker, dealer and trading counterparty the firm may trade with. It "
                    "publishes the concept ownership rows Approved Counterparty Profile, Counterparty Approval Scope and "
                    "Counterparty Trading Limit (25, CD-179) on the 02 party: the approval status and tier, the activities, "
                    "trading entities and funds each approval covers, the agreement each scope requires, the limits set, "
                    "and the periodic reviews with the status each one set. Party identity, LEI and legal parents are "
                    "taken from DP-240 and never copied; agreement status comes from DP-147. It is the one source of the "
                    "Counterparty and Broker dimension of SM-00 (CD-315), so order routing, settlement, exposure, "
                    "compliance and surveillance mean the same counterparty and the same approval. It owns no certified "
                    "metric family."),
        business_questions=[
            "Which brokers and counterparties are approved today, for which activities, trading entities and funds, and in which tier?",
            "Which approved scopes require an executed trading agreement that is missing, not active or signed with a different party?",
            "Which counterparties are past their review due date, and which reviews in the period suspended, restricted or terminated an approval?",
            "What limits are set for each counterparty and for its ultimate parent group, by limit type and trading entity?",
            "Which approved counterparties lack a current LEI, and which issuer counterparties have no current agency issuer rating?",
        ],
        grain="Counterparty party x approved activity x trading entity x fund (optional) x effective period (scope), with the counterparty profile, limits and latest review as conformed attributes; SCD type 2",
        dimensions=["Counterparty (02 party) and ultimate parent", "Counterparty tier", "Approval status", "Approved activity",
                    "Trading entity (internal legal entity)", "Fund (product)", "Limit type", "Governing trading agreement",
                    "Review outcome", "Effective date"],
        measures=[
            ("Approved Counterparties", "Count of distinct Counterparty Party with Counterparty Approval Status in (Approved, Approved - Restricted, Closing Only) on the as-of date, by Counterparty Tier.",
             [("25", "Approved Counterparty Profile", "Counterparty Party"),
              ("25", "Approved Counterparty Profile", "Counterparty Approval Status"),
              ("25", "Approved Counterparty Profile", "Approval Status Effective From"),
              ("25", "Approved Counterparty Profile", "Counterparty Tier")]),
            ("Active Approval Scopes", "Count of Counterparty Approval Scope rows with Scope Status in (Approved, Approved - Restricted) and Scope Effective From <= as-of date < Scope Effective To (or open), by Approved Activity and Scope Trading Entity.",
             [("25", "Counterparty Approval Scope", "Scope Status"), ("25", "Counterparty Approval Scope", "Scope Effective From"),
              ("25", "Counterparty Approval Scope", "Scope Effective To"), ("25", "Counterparty Approval Scope", "Approved Activity"),
              ("25", "Counterparty Approval Scope", "Scope Trading Entity")]),
            ("Scopes Missing Required Agreement", "Active Approval Scopes with Trading Agreement Required Indicator = Y where Governing Trading Agreement is blank, or the 26 Trading Agreement has Agreement Status other than Active, or its Agreement Counterparty differs from Scope Counterparty.",
             [("25", "Counterparty Approval Scope", "Trading Agreement Required Indicator"),
              ("25", "Counterparty Approval Scope", "Governing Trading Agreement"),
              ("25", "Counterparty Approval Scope", "Scope Counterparty"),
              ("26", "Trading Agreement", "Trading Agreement ID"), ("26", "Trading Agreement", "Agreement Status"),
              ("26", "Trading Agreement", "Agreement Counterparty"), "Active Approval Scopes"]),
            ("Overdue Counterparty Reviews", "Count of Approved Counterparties whose Next Review Due Date is before the as-of date, by Counterparty Tier and Review Frequency.",
             [("25", "Approved Counterparty Profile", "Next Review Due Date"),
              ("25", "Approved Counterparty Profile", "Review Frequency"), "Approved Counterparties"]),
            ("Adverse Review Outcomes", "Count of Counterparty Review rows with Counterparty Review Date in the period and Status After Review in (Approved - Restricted, Suspended, Closing Only, Terminated) or Counterparty Review Outcome in (Reduce Scope or Limits, Watch List, Suspend, Terminate).",
             [("25", "Counterparty Review", "Reviewed Counterparty"), ("25", "Counterparty Review", "Counterparty Review Date"),
              ("25", "Counterparty Review", "Status After Review"), ("25", "Counterparty Review", "Counterparty Review Outcome")]),
            ("Approved Counterparties Without LEI %", "Approved Counterparties whose party has no LEI Record with LEI Registration Status = Issued / Approved Counterparties.",
             [("02", "LEI Record", "LEI"), ("02", "LEI Record", "LEI Registration Status"), "Approved Counterparties"]),
            ("Approved Limit by Parent Group", "Sum of Limit Amount of Counterparty Trading Limit rows effective on the as-of date, grouped by the counterparty's Ultimate Parent (from 02 Legal Entity Hierarchy), Limit Type and Limit Trading Entity; amounts are summed only within one currency.",
             [("25", "Counterparty Trading Limit", "Limit Counterparty"), ("25", "Counterparty Trading Limit", "Limit Amount"),
              ("25", "Counterparty Trading Limit", "Limit Type"), ("25", "Counterparty Trading Limit", "Limit Trading Entity"),
              ("25", "Counterparty Trading Limit", "Limit Effective From"), ("25", "Counterparty Trading Limit", "Limit Effective To"),
              ("02", "Legal Entity Hierarchy", "Ultimate Parent")]),
            ("Approved Scopes Without Limit", "Count of Active Approval Scopes whose Approved Activity is OTC Derivative Counterparty, FX Counterparty or Repo Counterparty and for which no Counterparty Trading Limit for the same counterparty (and trading entity, where the limit names one) is effective on the as-of date.",
             [("25", "Counterparty Approval Scope", "Approved Activity"), ("25", "Counterparty Trading Limit", "Limit Counterparty"),
              ("25", "Counterparty Trading Limit", "Limit Trading Entity"), "Active Approval Scopes"]),
            ("Issuer Counterparties Without Agency Rating", "Count of Approved Counterparties that have a 17 Issuer Profile and no Credit Rating Assignment of Credit Rating Type issuer rating that is open (Credit Rating Effective To blank) on the as-of date.",
             [("17", "Issuer Profile", "Issuer Party"), ("17", "Credit Rating Assignment", "Rated Issuer"),
              ("17", "Credit Rating Assignment", "Credit Rating Type"), ("17", "Credit Rating Assignment", "Credit Rating Effective To"),
              "Approved Counterparties"]),
        ],
        inputs=[
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status", "Approval Status Effective From",
                                                     "Counterparty Tier", "Next Review Due Date", "Review Frequency"]),
            ("25", "Counterparty Approval Scope", ["Scope Counterparty", "Approved Activity", "Scope Trading Entity", "Scope Fund",
                                                   "Scope Countries", "Scope Status", "Trading Agreement Required Indicator",
                                                   "Governing Trading Agreement", "Scope Effective From", "Scope Effective To"]),
            ("25", "Counterparty Trading Limit", ["Limit Counterparty", "Limit Type", "Limit Trading Entity", "Limit Fund", "Limit Amount",
                                                  "Maximum Tenor Months", "Limit Effective From", "Limit Effective To"]),
            ("25", "Counterparty Review", ["Reviewed Counterparty", "Counterparty Review Date", "Credit View", "Counterparty Review Outcome",
                                           "Status After Review", "Counterparty Reviewer"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party", "Primary Country"]),
            ("02", "Organization", ["Legal Name", "Legal Jurisdiction", "Primary Regulator"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status", "Role Effective From", "Role Effective To"]),
            ("02", "LEI Record", ["LEI", "LEI Registration Status"]),
            ("02", "Legal Entity Hierarchy", ["Direct Parent", "Ultimate Parent", "Parent Relationship Basis"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk"]),
            ("17", "Credit Rating Assignment", ["Rated Issuer", "Credit Rating Agency", "Credit Rating Type", "Credit Rating Value",
                                                "Credit Rating Action Date", "Credit Rating Effective To"]),
            ("26", "Trading Agreement", ["Trading Agreement ID", "Trading Agreement Type", "Agreement Counterparty", "Fund Party",
                                         "Firm Contracting Entity", "Agreement Status", "Agreement Effective From",
                                         "Agreement Termination Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-240", "DP-147", "DP-098", "DP-192", "DP-013", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; an approval status change or suspension is published intraday through the event stream",
        history="SCD type 2 on profile status, scopes, limits and tier since the start of the OMS record; every review kept; no deletion",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Counterparty Party, Scope Counterparty, Limit Counterparty and Reviewed Counterparty resolves to a DP-240 party with Party Status active and no Merged Into Party, and holds an active 02 Party Role of a trading role type (Executing Broker, Clearing Broker / FCM, Prime Broker, OTC Derivative Counterparty, FX Counterparty or Repo Counterparty).",
            "No counterparty has a scope with Scope Status Approved or Approved - Restricted while its profile Counterparty Approval Status is Suspended, Terminated or Rejected.",
            "Scopes for the same counterparty, Approved Activity, Scope Trading Entity and Scope Fund do not overlap in effective period, and Scope Effective To is on or after Scope Effective From; the same holds for limits by counterparty, Limit Type, Limit Trading Entity and Limit Fund.",
            "Every Governing Trading Agreement resolves to a DP-147 Trading Agreement whose Agreement Counterparty is the Scope Counterparty.",
            "The latest Counterparty Review's Status After Review equals the profile's Counterparty Approval Status unless a later Approval Status Effective From records a change.",
            "Every Scope Trading Entity and Limit Trading Entity resolves to an active internal legal entity in DP-013, and every Scope Fund and Limit Fund to a product in DP-004.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Approved Counterparty Profile, Counterparty Approval Scope and Counterparty "
               "Trading Limit (25, CD-179); source of the SM-00 Counterparty and Broker dimension, tagged Investment area (CD-315). "
               "Party identity (name, LEI, parents) is read from 02 through DP-240 (CD-360, CD-143) and never copied; DP-098 is "
               "listed only for the issuer profile and agency ratings of counterparties that also issue (Country of Risk, issuer "
               "rating); the party core is DP-240's for every counterparty. Dependency direction (CD-321): this product depends on "
               "DP-147 for agreement status; DP-147 takes the counterparty as the 02 party key and must never list this product. "
               "Portfolio Transactions (DP-141) lists this product upstream, so it never depends on an 18 product. The 23 credit "
               "view is carried as the Credit View key on the review only, so the product stays foundational. Limit utilization "
               "and exceedance are 31 (CD-215) and are not computed here. Limit Amount is an Amount that carries its currency; no "
               "FX conversion is done, so the parent-group sum is per currency. PII = Y only because Counterparty Reviewer is an "
               "employee reference and 02 Primary Country is flagged for individual parties; the SM-00 Counterparty and Broker "
               "dimension view omits the reviewer. Operating model (CD-147, CD-297): with an outsourced trading desk the approval "
               "record stays the firm's and the grain is unchanged; the provider's approved list is added as scope rows received "
               "from the provider, with the provider as source. Open SME question (25 Q3): which committee approves "
               "counterparties, and whether limits are set by trading or by risk (31), per entity, fund or activity. "
               "Taxonomy gap: Counterparty Trading Limit has no limit approver or approval date (dropped to the attribute "
               "target), so limit approval cannot be evidenced here. Taxonomy gap: 02 Party Role holds no link to the 25 profile, "
               "so the trading role is matched by party and role type. Decisions: CD-179, CD-143, CD-215, CD-297, CD-315, CD-321, CD-360. "
               "W1 re-point (CW-902): Organization Type is read from 02 Party Type and Regulated Entity Indicator from 02 "
               "Organization Primary Regulator (populated = regulated); Party Role is read with its own key, Role Party."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-116 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-117 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    "DP-190": dict(
        definition=("The conformed chart of accounts of every group legal entity. It publishes the concept ownership rows GL "
                    "Account (GLA-), Chart Segment Value / Cost & Profit Center Code, Ledger (LDG-) and Accounting Period "
                    "Status (19, CD-152): charts and their segment structure, GL accounts with type and statement class, "
                    "chart segment values (company codes, cost and profit centers, product, channel and intercompany "
                    "segments) with the org unit, legal entity or product each represents, ledgers by entity, accounting "
                    "basis, currency and role, financial statement lines with their GL mapping, and the close state of each "
                    "ledger's fiscal periods, all effective-dated. It is the source of the SM-00 GL Account, Cost Center and "
                    "Ledger dimensions (CD-296), and of the statement line mapping through which DP-191's certified P&L is "
                    "presented; it owns no certified metric family itself."),
        business_questions=[
            "Which GL accounts, cost centers and ledgers are active for each legal entity, and how do they roll up to financial statement lines?",
            "Which active GL accounts have no effective financial statement line mapping, and which cost centers represent no org unit?",
            "Does every legal entity have exactly one primary ledger, and does its company code match the 09 entity record?",
            "Which ledger periods are still open or reopened after the period they belong to has ended?",
            "What changed in the chart (new, closed or re-parented accounts and segment values) since the last period?",
        ],
        grain="Chart of accounts x GL account or chart segment value x effective period, with ledger and ledger x fiscal period status as conformed tables; SCD type 2",
        dimensions=["Chart of accounts", "GL account (natural account) and parent summary account", "GL account type and financial statement class",
                    "Chart segment and segment value (company, cost center, profit center, product, channel, intercompany)",
                    "Represented org unit / legal entity / product", "Ledger (entity, basis, currency, role)",
                    "Financial statement line and reporting framework", "Fiscal period and close status", "Effective date"],
        measures=[
            ("Active GL Accounts", "Count of GL Accounts with GL Account Status active and GL Account Effective From <= as-of date < GL Account Effective To (or open), by GL Account Chart and GL Account Type.",
             [("19", "GL Account", "GL Account ID"), ("19", "GL Account", "GL Account Status"), ("19", "GL Account", "GL Account Effective From"),
              ("19", "GL Account", "GL Account Effective To"), ("19", "GL Account", "GL Account Chart"), ("19", "GL Account", "GL Account Type")]),
            ("Unmapped Active GL Accounts", "Active GL Accounts of type Asset, Liability, Equity, Revenue or Expense with no Financial Statement Line Mapping effective on the as-of date for each reporting framework in use.",
             [("19", "Financial Statement Line Mapping", "Mapped GL Account"), ("19", "Financial Statement Line Mapping", "Mapped Statement Line"),
              ("19", "Financial Statement Line Mapping", "Line Mapping Effective From"), ("19", "Financial Statement Line Mapping", "Line Mapping Effective To"),
              ("19", "Financial Statement Line", "Line Reporting Framework"), "Active GL Accounts"]),
            ("Active Cost Centers", "Count of Chart Segment Values with Chart Segment = Cost Center, Segment Value Status active and effective on the as-of date, by Represented Legal Entity.",
             [("19", "Chart Segment Value", "Chart Segment"), ("19", "Chart Segment Value", "Segment Value Code"),
              ("19", "Chart Segment Value", "Segment Value Status"), ("19", "Chart Segment Value", "Segment Value Effective From"),
              ("19", "Chart Segment Value", "Segment Value Effective To"), ("19", "Chart Segment Value", "Represented Legal Entity")]),
            ("Cost Centers Without Org Unit", "Active Cost Centers with no Represented Org Unit, or whose Represented Org Unit is not an active 09 Org Unit on the as-of date.",
             [("19", "Chart Segment Value", "Represented Org Unit"), ("09", "Org Unit", "Org Unit ID"), "Active Cost Centers"]),
            ("Company Code Mismatches", "Count of active internal legal entities whose 09 Accounting Company Code differs from the Segment Value Code of the active Chart Segment Value with Chart Segment = Company and Represented Legal Entity = that entity.",
             [("09", "Internal Legal Entity", "Legal Entity ID"), ("09", "Internal Legal Entity", "Accounting Company Code"),
              ("19", "Chart Segment Value", "Chart Segment"), ("19", "Chart Segment Value", "Segment Value Code"),
              ("19", "Chart Segment Value", "Represented Legal Entity")]),
            ("Entities Without One Primary Ledger", "Count of active internal legal entities with zero or more than one Ledger with Ledger Role = Primary for the same Accounting Basis.",
             [("19", "Ledger", "Ledger ID"), ("19", "Ledger", "Ledger Legal Entity"), ("19", "Ledger", "Ledger Role"),
              ("19", "Ledger", "Accounting Basis"), ("09", "Internal Legal Entity", "Entity Status")]),
            ("Overdue Open Periods", "Count of ledger x fiscal period rows with Period Close Status in (Open, Soft Close, Reopened) whose 09 Period End Date is more than one calendar month before the as-of date, by ledger.",
             [("19", "Accounting Period Status", "Status Ledger"), ("19", "Accounting Period Status", "Status Fiscal Period"),
              ("19", "Accounting Period Status", "Period Close Status"), ("09", "Fiscal Period", "Fiscal Period ID"),
              ("09", "Fiscal Period", "Period End Date")]),
            ("Chart Changes in Period", "Count of GL Accounts and Chart Segment Values whose effective-from or effective-to date falls in the period, by change type (new, closed) and chart.",
             [("19", "GL Account", "GL Account Effective From"), ("19", "GL Account", "GL Account Effective To"),
              ("19", "Chart Segment Value", "Segment Value Effective From"), ("19", "Chart Segment Value", "Segment Value Effective To"),
              ("19", "Chart Segment Value", "Segment Value Chart")]),
        ],
        inputs=[
            ("19", "Chart of Accounts", ["Chart of Accounts Code", "Chart of Accounts Name", "Chart Segment Structure", "Chart Status"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Chart", "Natural Account Number", "GL Account Name", "GL Account Type",
                                  "Normal Balance", "Financial Statement Class", "Parent Summary Account",
                                  "Subledger Control Account Indicator", "Account Reconciliation Frequency", "GL Account Status",
                                  "GL Account Effective From", "GL Account Effective To"]),
            ("19", "Chart Segment Value", ["Segment Value Chart", "Chart Segment", "Segment Value Code", "Segment Value Name",
                                           "Parent Segment Value", "Represented Org Unit", "Represented Legal Entity",
                                           "Represented Product", "Segment Value Status", "Segment Value Effective From",
                                           "Segment Value Effective To"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Legal Entity", "Accounting Basis", "Ledger Role", "Ledger Currency",
                              "Ledger Chart of Accounts", "Ledger Fiscal Calendar", "Source Ledger"]),
            ("19", "Financial Statement Line", ["Statement Line Code", "Line Reporting Framework", "Line Statement Type",
                                                "External Reporting Line", "XBRL Element"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Mapped Statement Line", "Revenue Disaggregation Category",
                                                        "Line Mapping Effective From", "Line Mapping Effective To"]),
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status", "Translation Rate Type",
                                                "Balance Sheet Translation Rate Type", "Hard Close Date", "Period Reopen Reason"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status", "Accounting Company Code"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Fiscal Period Type", "Period Start Date", "Period End Date"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name", "Org Unit Type", "Org Unit Effective From"]),
            ("09", "Cost & Profit Center", ["Cost Center Code", "Profit Center Code"]),
        ],
        upstream=["DP-013", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a new account, segment value or period status change is available the business day after it is made in the ERP",
        history="SCD type 2 on every account, segment value, mapping and ledger since the ERP go-live; period status history kept for every ledger x fiscal period indefinitely",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every GL Account is unique by GL Account Chart x Natural Account Number, and its Parent Summary Account resolves to a GL Account of the same chart.",
            "Every active GL Account of type Revenue or Expense maps to exactly one Financial Statement Line per reporting framework on any date, and mapping periods for the same account and framework do not overlap.",
            "Every active Chart Segment Value with Chart Segment = Cost Center names a Represented Org Unit that is active in DP-013, and every 09 Cost & Profit Center Cost Center Code resolves to an active Cost Center segment value.",
            "Each active internal legal entity has exactly one Ledger with Ledger Role = Primary per Accounting Basis, and every Ledger with a role other than Primary names a Source Ledger.",
            "Every Status Fiscal Period resolves to a DP-013 Fiscal Period of the ledger's Ledger Fiscal Calendar, and a period with Period Close Status Hard Close or Permanently Closed has a Hard Close Date.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows GL Account (19, GLA-), Chart Segment Value / Cost & Profit Center Code (19), "
               "Ledger (19, LDG-) and Accounting Period Status (19) (CD-152). Publishes the SM-00 GL Account, Cost Center and "
               "Ledger dimensions, area CORP (CD-296). DP-013 keeps legal entity, org unit and fiscal calendar; this product joins "
               "them to the segment values that represent them and never repeats them. The 09 Accounting Company Code and the 09 "
               "Cost & Profit Center codes are derived copies of 19 segment values; they are read only to test that the copies "
               "match the master (Company Code Mismatches and the cost center rule), which is the exception in CONTRACT.md rule 2. "
               "Represented Product resolves through DP-004. Fund ledgers are 27 (CD-186) and out of scope. Certified P&L and "
               "operating expense are DP-191's (CD-340); this product supplies their statement line mapping. Period Closed By is "
               "deliberately not read, so the product carries no personal data. Operating model: in house; if a shared-service "
               "provider runs the close, the grain is unchanged (CD-297). Open SME questions (19 Q1, Q2, Q11): the ERP and number "
               "of ledgers and bases per entity; the chart segments in use and whether product or channel sit in the GL; whether "
               "09 Fiscal Period Status stays a copy. Taxonomy gap: Chart Segment Structure is free text, so segment order for "
               "parsing Balance Segment Combination in DP-191 is read from it rather than from a structured segment list. "
               "Decisions: CD-084, CD-152, CD-186, CD-296, CD-340, CD-343."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-191": dict(
        definition=("Every journal entry and GL posting of the group ledgers with its subledger source, and the period "
                    "balances by ledger, account combination, fiscal period, balance type and currency (concept ownership "
                    "row Journal Entry / GL Posting, 19, JNL-, CD-152). It is the certified source of the P&L and operating "
                    "expense family (CD-293, CD-340): booked revenue, operating expense, compensation expense (CD-347) and "
                    "operating income at ledger x account combination x fiscal period, presented on statement lines through "
                    "DP-190. FP&A, distribution finance, tax, treasury and the statements read one booked actual; DP-012 "
                    "reconciles its management revenue to the revenue lines here, and corporate cost measures in other "
                    "products reconcile to it (CD-353)."),
        business_questions=[
            "What are certified revenue, operating expense, compensation expense and operating income by legal entity, cost center and statement line for each closed period?",
            "Do period balances agree with the posted journals for every ledger, account and period?",
            "Which journals are unbalanced, manual, self-approved or posted after the period's hard close?",
            "Which balance sheet balances were not reconciled at period end?",
            "How much activity sits on accounts with no statement line mapping, and so is missing from the reported P&L?",
        ],
        grain="Ledger x account combination x fiscal period x balance type x balance currency (balances), with journal entry x journal line (postings) as the detail fact",
        dimensions=["Ledger and legal entity", "GL account, GL account type and financial statement class", "Cost center and other segment values",
                    "Financial statement line", "Fiscal period and close status", "Balance type", "Currency",
                    "Journal type and journal source", "Manual indicator", "Intercompany partner entity"],
        measures=[
            ("Period Net Activity", "Closing Balance - Opening Balance for each GL Account Balance row (balances held debit-positive).",
             [("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Opening Balance"),
              ("19", "GL Account Balance", "Balance Ledger"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Segment Combination"), ("19", "GL Account Balance", "Balance Fiscal Period"),
              ("19", "GL Account Balance", "Balance Type"), ("19", "GL Account Balance", "Balance Currency")]),
            ("Certified Revenue", "Sum of Period Net Activity x -1 (revenue shown positive) for GL accounts with GL Account Type = Revenue, Balance Type = Actual, on ledgers with Ledger Role = Primary, for periods with Period Close Status in (Hard Close, Permanently Closed); by legal entity, statement line and period. Before hard close the same figure is published as preliminary.",
             [("19", "GL Account", "GL Account Type"), ("19", "Ledger", "Ledger Role"), ("19", "Ledger", "Ledger Legal Entity"),
              ("19", "Accounting Period Status", "Period Close Status"), ("19", "Financial Statement Line Mapping", "Mapped Statement Line"),
              "Period Net Activity"]),
            ("Certified Operating Expense", "Sum of Period Net Activity for GL accounts with GL Account Type = Expense and Financial Statement Class in (Operating Expense - Compensation, Operating Expense - Distribution, Operating Expense - General and Administrative), on the same ledger, balance type and close conditions as Certified Revenue; by legal entity, cost center (parsed from Balance Segment Combination), statement line and period.",
             [("19", "GL Account", "GL Account Type"), ("19", "GL Account", "Financial Statement Class"),
              ("19", "Chart of Accounts", "Chart Segment Structure"), "Period Net Activity"]),
            ("Certified Compensation Expense", "Part of Certified Operating Expense on GL accounts with Financial Statement Class = Operating Expense - Compensation, by cost center and period (CD-347: compensation expense; incentive earned is DP-033 and compensation paid is DP-198).",
             [("19", "GL Account", "Financial Statement Class"), "Certified Operating Expense"]),
            ("Certified Operating Income", "Certified Revenue - Certified Operating Expense, by legal entity and period.",
             ["Certified Revenue", "Certified Operating Expense"]),
            ("Balance-to-Journal Difference", "Period Net Activity (Balance Type = Actual, at GL account level) - (sum of Posted Amount with Debit Credit Indicator = Debit - sum with Credit) of GL Postings on journals with Journal Status = Posted for the same Journal Ledger, Posted Account and Posting Accounting Period; expected 0.",
             [("19", "GL Posting", "Journal ID"), ("19", "GL Posting", "Posted Account"), ("19", "GL Posting", "Posted Amount"),
              ("19", "GL Posting", "Debit Credit Indicator"), ("19", "Journal Entry", "Journal ID"), ("19", "Journal Entry", "Journal Ledger"),
              ("19", "Journal Entry", "Posting Accounting Period"), ("19", "Journal Entry", "Journal Status"), "Period Net Activity"]),
            ("Unbalanced Journals", "Count of posted journals where the sum of debit Posted Amount differs from the sum of credit Posted Amount.",
             [("19", "GL Posting", "Journal ID"), ("19", "GL Posting", "Posted Amount"), ("19", "GL Posting", "Debit Credit Indicator"),
              ("19", "Journal Entry", "Journal Status")]),
            ("Manual Journal Share %", "Posted journals with Manual Journal Indicator = Y / all posted journals, by ledger and period, also by summed debit amount.",
             [("19", "Journal Entry", "Manual Journal Indicator"), ("19", "Journal Entry", "Journal Ledger"),
              ("19", "Journal Entry", "Posting Accounting Period"), ("19", "Journal Entry", "Journal Status")]),
            ("Self-Approved Manual Journals", "Count of posted journals with Manual Journal Indicator = Y where Journal Approved By is blank or equals Journal Prepared By.",
             [("19", "Journal Entry", "Manual Journal Indicator"), ("19", "Journal Entry", "Journal Prepared By"),
              ("19", "Journal Entry", "Journal Approved By")]),
            ("Postings After Hard Close", "Count of posted journals whose Posting Date is after the Hard Close Date of their Journal Ledger x Posting Accounting Period.",
             [("19", "Journal Entry", "Posting Date"), ("19", "Accounting Period Status", "Hard Close Date"),
              ("19", "Accounting Period Status", "Status Ledger"), ("19", "Accounting Period Status", "Status Fiscal Period")]),
            ("Unreconciled Balance Sheet Balances", "Count and absolute Closing Balance of Actual balances on Asset, Liability or Equity accounts for closed periods with Account Reconciliation Status not Reconciled.",
             [("19", "GL Account Balance", "Account Reconciliation Status"), ("19", "GL Account Balance", "Closing Balance"),
              ("19", "GL Account", "GL Account Type")]),
            ("Unmapped Activity", "Sum of absolute Period Net Activity on GL accounts with no Financial Statement Line Mapping effective at the period end.",
             [("19", "Financial Statement Line Mapping", "Mapped GL Account"), ("19", "Financial Statement Line Mapping", "Line Mapping Effective From"),
              ("19", "Financial Statement Line Mapping", "Line Mapping Effective To"), "Period Net Activity"]),
        ],
        inputs=[
            ("19", "Journal Entry", ["Journal ID", "Journal Ledger", "Journal Type", "Journal Source", "Posting Date",
                                     "Posting Accounting Period", "Posting Legal Entity", "Journal Status", "Manual Journal Indicator",
                                     "Journal Prepared By", "Journal Approved By", "Reversed Journal"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount",
                                  "Transaction Currency Amount", "Applied Exchange Rate", "Cost Center Segment Value",
                                  "Other Segment Values", "Source Finance Record", "Source Payable Invoice", "Source Supplier Payment",
                                  "Source Receivable Item", "Source Payroll Run", "Intercompany Partner Entity"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period",
                                          "Balance Type", "Balance Currency", "Opening Balance", "Closing Balance",
                                          "Applied Exchange Rate", "Account Reconciliation Status"]),
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status", "Hard Close Date"]),
            ("19", "GL Account", ["GL Account ID", "Natural Account Number", "GL Account Type", "Normal Balance", "Financial Statement Class"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Mapped Statement Line", "Line Mapping Effective From",
                                                        "Line Mapping Effective To"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Legal Entity", "Accounting Basis", "Ledger Role", "Ledger Currency"]),
            ("19", "Chart of Accounts", ["Chart of Accounts Code", "Chart Segment Structure"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Period End Date"]),
        ],
        upstream=["DP-190", "DP-013", "DP-192"],
        refresh="Daily",
        timeliness="Postings and balances by 7am ET on T+1; certified figures for a period when its Period Close Status is Hard Close, typically business day 8 after month-end",
        history="All journals and balances since the ERP go-live, kept for at least the statutory record period (seven years); hard-closed periods are immutable and corrections are posted in an open period",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every posted journal balances: the sum of debit Posted Amount equals the sum of credit Posted Amount.",
            "For every ledger, GL account and fiscal period, Period Net Activity on the Actual balance equals the net of posted GL Postings to the cent.",
            "Opening Balance of a period equals the Closing Balance of the prior period for the same ledger, account combination, balance type and currency, except at the fiscal year start for Revenue and Expense accounts, where it is 0.",
            "No journal is posted to a ledger x fiscal period whose Period Close Status is Hard Close or Permanently Closed after its Hard Close Date.",
            "Every Posted Account and Balance GL Account resolves to an active GL Account in DP-190 and every Cost Center Segment Value to an active Cost Center segment value, on the posting date.",
            "Certified Revenue on DP-012's mapped revenue accounts equals DP-012 revenue for the same legal entity and closed period plus the reconciling items DP-012 records; a difference is a reconciling item, never a second revenue number.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP row Journal Entry / GL Posting (19, JNL-), with GL Account Balance (CD-152). "
               "Certified numbers: the P&L and operating expense family (CD-293, CD-340), under the definitions above: certified "
               "revenue, operating expense, compensation expense and operating income on primary ledgers, Actual balances, "
               "hard-closed periods. DP-012 stays the certified management revenue by share class and reconciles to the revenue "
               "lines here (CD-340); DP-056, DP-035, DP-057 and DP-194 take actual expense by cost center from here and never "
               "re-aggregate GL postings (CD-340, CD-343); DP-193 statement line values must equal mapped balances here. CD-347: "
               "compensation expense is this product's; incentive earned stays DP-033 and compensation paid DP-198. CD-353: "
               "supplier spend, project cost, counsel spend, reserves and operational losses in 37 to 42 products are operational "
               "measures that reconcile to the postings here and are never certified expense. Payroll posts in summary per run "
               "(Source Payroll Run), so there is no employee-level cost. Journal Prepared By and Journal Approved By are employee "
               "keys resolved through DP-192 for the segregation-of-duties checks only; PII = Y for that reason, and the wide "
               "BI view drops both columns. If the parent is listed, unreleased quarterly figures are handled as Restricted - "
               "MNPI until the earnings release. Operating model: in house; a shared-service AP or close provider leaves the grain "
               "unchanged (CD-297). Taxonomy gap: GL Account Balance holds the cost center only inside Balance Segment "
               "Combination (text); the cost center is parsed in the segment order of DP-190 Chart Segment Structure. Taxonomy "
               "gap: GL Account Balance does not state its sign convention; the product assumes debit-positive balances and "
               "checks the sign against Normal Balance. Taxonomy gap: no period debit and credit activity on GL Account Balance, so "
               "activity is derived as Closing - Opening. Open SME questions (19 Q1, Q5, Q12; Corporate A brief Q3): ERP and "
               "ledgers per entity; the subledger of record for fee revenue; payroll journal grain; DP-191 certified for all P&L "
               "(recommended) or expense only. Decisions: CD-152, CD-293, CD-340, CD-343, CD-347, CD-353."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-192": dict(
        definition=("The conformed record of every worker of the firm: employees, contractors, consultants and secondees, with "
                    "job profile, budgeted workforce position, job and org unit assignments, reporting lines, employing legal "
                    "entity, work location, position cost center and the lifecycle events that change them, all "
                    "effective-dated. It publishes the concept ownership rows Employee (20, EMP-, CD-151), Job Profile (JOB-), "
                    "Workforce Position (WFP-) and Employee Lifecycle Event (ELE-) as the SM-00 Employee dimension (CD-342), "
                    "holds only the employee master personal data tier (CD-344), feeds joiner, mover and leaver events to "
                    "access and badge products, and is the certified source of headcount and FTE (CD-293, CD-341)."),
        business_questions=[
            "What is certified headcount and FTE at each period end by legal entity, org unit, cost center, job level and employment type, and how many contingent workers are there?",
            "How does actual FTE compare with authorized FTE by position, cost center and org unit, and which positions are vacant?",
            "Who joined, moved and left in the period, and which leavers still need regulatory notification?",
            "Which active workers have no solid-line manager, no primary assignment or a position whose cost center is not valid?",
            "Which contingent engagements have passed their end date while the worker is still active?",
        ],
        grain="Worker (EMP-) x effective period, with job assignment (worker x position or job profile x assignment type x effective period), reporting line, org unit assignment and lifecycle event as conformed child tables; SCD type 2",
        dimensions=["Employee (worker)", "Employment type and status", "Contingent worker type", "Job profile, family and level",
                    "Regulated role category", "Workforce position", "Org unit", "Employing legal entity", "Work location",
                    "Cost center", "Line manager", "Lifecycle event type", "Effective date"],
        measures=[
            ("Certified Headcount", "Count of distinct Employee ID with Employment Status in (Active, Leave of Absence, Notice Period, Garden Leave) on the period end date and no Contingent Worker Detail (Contingent Worker Type blank), by Employment Type, Employing Legal Entity, Home Org Unit and Work Location.",
             [("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Employment Type"),
              ("20", "Employee", "Employing Legal Entity"), ("20", "Employee", "Home Org Unit"), ("20", "Employee", "Work Location"),
              ("20", "Contingent Worker Detail", "Contingent Worker Type"), ("09", "Fiscal Period", "Period End Date")]),
            ("Contingent Worker Count", "Count of distinct Employee ID with an employed Employment Status on the period end date and Contingent Worker Type populated, by Contingent Worker Type; reported separately and excluded from Certified Headcount.",
             [("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"),
              ("20", "Contingent Worker Detail", "Contingent Worker Type")]),
            ("Certified FTE", "Sum of Assignment FTE of Employee Job Assignments with Assignment Type = Primary effective on the period end date (Assignment Effective From <= date < Assignment Effective To or open) for workers counted in Certified Headcount, by Position Cost Center, org unit and legal entity.",
             [("20", "Employee Job Assignment", "Assignment FTE"), ("20", "Employee Job Assignment", "Assignment Type"),
              ("20", "Employee Job Assignment", "Assigned Worker"), ("20", "Employee Job Assignment", "Assignment Effective From"),
              ("20", "Employee Job Assignment", "Assignment Effective To"), ("20", "Employee Job Assignment", "Assigned Workforce Position"),
              ("20", "Workforce Position", "Position Cost Center"), "Certified Headcount"]),
            ("Authorized FTE", "Sum of Authorized FTE of Workforce Positions effective on the period end date with Position Status not Closed, by Position Cost Center, Position Org Unit and Position Legal Entity (an authorization measure compared with Certified FTE, not a headcount).",
             [("20", "Workforce Position", "Authorized FTE"), ("20", "Workforce Position", "Position Status"),
              ("20", "Workforce Position", "Position Effective From"), ("20", "Workforce Position", "Position Effective To"),
              ("20", "Workforce Position", "Position Org Unit"), ("20", "Workforce Position", "Position Legal Entity")]),
            ("FTE Variance to Authorized", "Certified FTE - Authorized FTE by position cost center and org unit at the period end.",
             ["Certified FTE", "Authorized FTE"]),
            ("Vacant Positions", "Count of Workforce Positions effective on the as-of date with Position Status Open, or with no primary Employee Job Assignment effective on that date, split by Key-Person Risk Indicator.",
             [("20", "Workforce Position", "Workforce Position ID"), ("20", "Workforce Position", "Position Status"),
              ("20", "Workforce Position", "Key-Person Risk Indicator"), ("20", "Employee Job Assignment", "Assigned Workforce Position")]),
            ("Joiners, Movers and Leavers", "Count of Employee Lifecycle Events with Event Effective Date in the period, grouped as joiners (Hire, Rehire, Conversion), movers (Transfer, Promotion, Demotion, Job Change) and leavers (Termination, split by Voluntary Termination Indicator).",
             [("20", "Employee Lifecycle Event", "Lifecycle Event ID"), ("20", "Employee Lifecycle Event", "Lifecycle Event Type"),
              ("20", "Employee Lifecycle Event", "Event Effective Date"), ("20", "Employee Lifecycle Event", "Voluntary Termination Indicator")]),
            ("Leavers Requiring Regulatory Notification", "Count of Termination events in the period with Regulatory Notification Required Indicator = Y, by Termination Reason.",
             [("20", "Employee Lifecycle Event", "Regulatory Notification Required Indicator"),
              ("20", "Employee Lifecycle Event", "Termination Reason"), "Joiners, Movers and Leavers"]),
            ("Workers Without Solid-Line Manager", "Count of workers in Certified Headcount or Contingent Worker Count with no Employee Reporting Line of Reporting Line Type = Solid-Line Manager effective on the as-of date.",
             [("20", "Employee Reporting Line", "Reporting Employee"), ("20", "Employee Reporting Line", "Reporting Line Type"),
              ("20", "Employee Reporting Line", "Reporting Effective From"), ("20", "Employee Reporting Line", "Reporting Effective To"),
              "Certified Headcount", "Contingent Worker Count"]),
            ("Contingent Engagements Past End Date", "Count of contingent workers with an employed Employment Status whose Engagement End Date is before the as-of date.",
             [("20", "Contingent Worker Detail", "Engagement End Date"), "Contingent Worker Count"]),
            ("Work Authorizations Expiring (90 Days)", "Count of workers with an employed Employment Status whose Work Authorization Expiry Date falls within the next 90 days, by Work Authorization Type (restricted extension view only).",
             [("20", "Employee Personal Detail", "Work Authorization Expiry Date"), ("20", "Employee Personal Detail", "Work Authorization Type"),
              ("20", "Employee", "Employment Status")]),
        ],
        inputs=[
            ("20", "Employee", ["Employee ID", "HR Employee Number", "Legal First Name", "Legal Last Name", "Preferred Name",
                                "Business Email Address", "Business Phone Number", "Job Title", "Job Family", "Employing Legal Entity",
                                "Home Org Unit", "Work Location", "Employment Type", "Employment Status", "Hire Date", "Termination Date"]),
            ("20", "Employee Reporting Line", ["Reporting Employee", "Line Manager", "Reporting Line Type", "Reporting Effective From",
                                               "Reporting Effective To"]),
            ("20", "Employee Personal Detail", ["Country of Residence", "National Identifier Type", "National Identifier",
                                                "Work Authorization Type", "Work Authorization Expiry Date"]),
            ("20", "Contingent Worker Detail", ["Contingent Worker Type", "Supplier Agency", "Supplier Contract Reference",
                                                "Engagement Start Date", "Engagement End Date",
                                                "Secondment Home Entity"]),
            ("20", "Job Profile", ["Job Profile ID", "Job Profile Name", "Job Profile Family", "Job Level", "US SOC Code",
                                   "FLSA Status", "EEO-1 Job Category", "Regulated Role Category"]),
            ("20", "Workforce Position", ["Workforce Position ID", "Position Job Profile", "Position Org Unit", "Position Legal Entity",
                                          "Position Location", "Position Cost Center", "Authorized FTE", "Budget Plan Line",
                                          "Position Status", "Key-Person Risk Indicator", "Position Effective From",
                                          "Position Effective To"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assigned Workforce Position", "Assigned Job Profile", "Assignment Type",
                                               "Assignment FTE", "Working Pattern", "Assignment Effective From", "Assignment Effective To"]),
            ("20", "Org Unit Assignment", ["Assigned Employee", "Assigned Org Unit", "Assignment Effective From / To"]),
            ("20", "Employee Lifecycle Event", ["Lifecycle Event ID", "Event Employee", "Lifecycle Event Type", "Event Effective Date",
                                                "Termination Reason", "Voluntary Termination Indicator", "Notice Period End Date",
                                                "Regulatory Notification Required Indicator", "Related Reorganization"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name", "Org Unit Type", "Employing / Booking Entity"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("09", "Office Location", ["Office ID", "Office Country / Subdivision", "Office Legal Entity"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Period End Date"]),
            ("19", "Chart Segment Value", ["Chart Segment", "Segment Value Code", "Segment Value Status", "Represented Org Unit"]),
        ],
        upstream=["DP-013", "DP-190"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; joiner and leaver events published on the event stream within one hour of approval in the HRIS; certified headcount and FTE for a period by business day 3 after period end",
        history="SCD type 2 on every worker, assignment, reporting line, position and org placement since the HRIS go-live; lifecycle events kept for the employment record retention period; certified period-end snapshots kept indefinitely",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every worker has exactly one Employee Job Assignment with Assignment Type = Primary effective on each date between Hire Date and Termination Date, and none after Termination Date.",
            "A worker with Employment Status = Terminated has Termination Date populated and a Termination lifecycle event with the same Event Effective Date; a worker with any other status has no Termination Date in the past.",
            "Employing Legal Entity, Home Org Unit, Work Location, Position Org Unit and Position Legal Entity resolve to active DP-013 records, and every Position Cost Center resolves to an active Cost Center segment value in DP-190 on the as-of date.",
            "Contingent Worker Type is populated only for Employment Type Contractor, Secondee or Intern / Graduate, and every contingent worker has an Engagement End Date.",
            "No worker has more than one Solid-Line Manager reporting line on any date, and no worker is their own Line Manager.",
            "Certified Headcount and Certified FTE for a locked period equal every 20 Human Capital Metric Value row for headcount and FTE of the same period and breakdown.",
        ],
        notes=("W1b: Contingent Worker Detail.Off-Payroll Working Determination (UK IR35) and Job Profile.ISCO-08 Code dropped, no successor (CW-920); US SOC Code stays as the occupation code and no measure read either attribute. "
               "Master concept: CONCEPT_OWNERSHIP rows Employee (20, EMP-, CD-151), Job Profile (JOB-), Workforce Position (WFP-) "
               "and Employee Lifecycle Event (ELE-); source of the SM-00 Employee dimension, area CORP (CD-342). Certified numbers "
               "(CD-341, CD-293): Certified Headcount and Certified FTE as defined above; Authorized FTE (20) and Planned FTE (19 "
               "plan lines) are compared with them, never alternatives; DP-056, DP-194, DP-197 and DP-201 take both from here. "
               "DP-009 keeps Active Producing Salespeople, a sales measure. CD-341 says 'Employment Status active'; it is applied "
               "here as every employed status (Active, Leave of Absence, Notice Period, Garden Leave), because a worker on leave or "
               "notice is still employed - confirm with HR (Corporate A brief Q4). Contingent workers are identified by Contingent "
               "Worker Detail rather than Employment Type, so paid interns count as employees and third-party interns as "
               "contingent. CD-342: this product publishes every attribute DP-009's Employee dimension reads today (20 Employee: "
               "Employee ID, Preferred Name, Legal Last Name, Business Email Address, Job Title, Employing Legal Entity, Home Org "
               "Unit, Work Location, Employment Status, Hire Date, Termination Date; all of Employee Reporting Line; all of Org Unit "
               "Assignment); DP-009 must add DP-192 upstream and keep its 20 inputs as lineage through it. Personal data tiers "
               "(CD-344): master tier only, Confidential - Personal Data. Employee Personal Detail is read only for country of "
               "residence, national identifier and work authorization, published as a Restricted - Personal Data extension for "
               "payroll and regulatory registration; Date of Birth, Legal Gender, Nationality and Home Postal Address are not "
               "read. No diversity data (DP-201), no pay or awards (DP-198, DP-199), no leave of absence detail (DP-197). A "
               "pseudonymized view keyed on Employee ID is the wide analytics view. Supplier Agency (02) and Supplier Contract "
               "Reference (39) are carried as keys only: this product must not depend on DP-210 or DP-213, which list it "
               "upstream. Related Reorganization is a key to 09 Reorganization Event, read by DP-009. Operating model: HRIS in "
               "house; outsourced payroll affects DP-198, not this product. Open SME questions (20 Q1, Q2, Q10): whether the HRIS "
               "holds contractors and secondees; whether non-executive directors are workers here; whether position management "
               "is used (without it Authorized FTE and Vacant Positions are empty and authorized FTE comes from 19 plan lines). "
               "Taxonomy gap: no attribute holds a worker's standard weekly hours, so FTE is taken as recorded in Assignment FTE "
               "and cannot be recomputed. Decisions: CD-151, CD-293, CD-296, CD-341, CD-342, CD-344, CD-347."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-210": dict(
        definition=("The conformed record of every supplier of every group entity. It publishes the concept ownership rows "
                    "Supplier Profile (40, keyed by the 02 party) and Supplier Engagement (40, VENG-), with Supplier Risk "
                    "Tiering, Supplier Category Assignment and Supplier Contract Profile as dated attributes of the "
                    "engagement: the party in the supplier role with its ERP supplier number, dated supplier status and "
                    "onboarding outcome, and each engagement with its buying entity, business owner, procurement category, "
                    "inherent criticality tier and the 39 contract that governs it, plus the link to the specialized data "
                    "vendor (14), servicing provider (13), custody provider (28) or fund service provider role (01). Party "
                    "identity comes from DP-240 and the contract from DP-213. It is the SM-00 Vendor dimension (CD-296), so "
                    "procurement, third-party risk, finance, the outsourcing register and service provider oversight count the same "
                    "supplier once. It owns no certified metric family."),
        business_questions=[
            "Which suppliers may be used today, under which engagements, by which group entities, and in which procurement categories?",
            "Which engagements are Tier 1 - Critical or Tier 2 - High, and which of them lack a current tier, an active governing contract or an exit assistance period?",
            "Which approved suppliers have not completed onboarding or have an unresolved sanctions screening result?",
            "Which engagements have a business owner who has left the firm?",
            "Are data vendors, servicing providers, custody providers and fund service providers each linked to one supplier engagement?",
        ],
        grain="Supplier engagement (VENG-) x effective period, with the supplier profile (02 party in the supplier role) as parent and tier, category and contract as dated attributes; SCD type 2",
        dimensions=["Supplier (02 party) and LEI", "Supplier status", "Supplier engagement", "Buying legal entity", "Requesting org unit",
                    "Business owner (employee)", "Procurement category", "Third-party criticality tier", "Governing contract",
                    "Specialized provider type (data vendor, servicing, custody, fund service provider)", "Effective date"],
        measures=[
            ("Approved Suppliers", "Count of distinct Supplier Party with Supplier Status in (Approved, Restricted) effective on the as-of date.",
             [("40", "Supplier Profile", "Supplier Party"), ("40", "Supplier Profile", "Supplier Status"),
              ("40", "Supplier Profile", "Supplier Status Effective From"), ("40", "Supplier Profile", "Supplier Status Effective To")]),
            ("Active Engagements by Tier", "Count of Supplier Engagements with Engagement Status = Active on the as-of date, by the Third-Party Criticality Tier effective on that date and by Engagement Buying Entity.",
             [("40", "Supplier Engagement", "Supplier Engagement ID"), ("40", "Supplier Engagement", "Engagement Status"),
              ("40", "Supplier Engagement", "Engagement Buying Entity"), ("40", "Supplier Risk Tiering", "Tiered Engagement"),
              ("40", "Supplier Risk Tiering", "Third-Party Criticality Tier"), ("40", "Supplier Risk Tiering", "Tier Effective From"),
              ("40", "Supplier Risk Tiering", "Tier Effective To")]),
            ("Untiered Active Engagements", "Active engagements with no Supplier Risk Tiering effective on the as-of date.",
             [("40", "Supplier Risk Tiering", "Tiered Engagement"), "Active Engagements by Tier"]),
            ("Critical Engagements Without Active Contract", "Active engagements in Tier 1 - Critical or Tier 2 - High not listed in the Contracted Engagements of a Supplier Contract Profile whose 39 Contract has Contract Status = Active, or whose contract has no Exit Assistance Period.",
             [("40", "Supplier Contract Profile", "Profiled Contract"), ("40", "Supplier Contract Profile", "Contracted Engagements"),
              ("40", "Supplier Contract Profile", "Exit Assistance Period"), ("39", "Contract", "Contract ID"),
              ("39", "Contract", "Contract Status"), "Active Engagements by Tier"]),
            ("Suppliers Without Completed Onboarding", "Approved Suppliers with no Supplier Onboarding Case having Onboarding Case Status = Resolved / Completed, Onboarding Approval Status = Approved and Sanctions Screening Result = No Match.",
             [("40", "Supplier Onboarding Case", "Onboarding Supplier"), ("40", "Supplier Onboarding Case", "Onboarding Case Status"),
              ("40", "Supplier Onboarding Case", "Onboarding Approval Status"), ("40", "Supplier Onboarding Case", "Sanctions Screening Result"),
              "Approved Suppliers"]),
            ("Engagements With Departed Owner", "Active engagements whose Engagement Business Owner has Employment Status = Terminated in DP-192 on the as-of date.",
             [("40", "Supplier Engagement", "Engagement Business Owner"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status"), "Active Engagements by Tier"]),
            ("Uncategorized Active Engagements", "Active engagements with no Supplier Category Assignment effective on the as-of date.",
             [("40", "Supplier Category Assignment", "Categorized Engagement"), ("40", "Supplier Category Assignment", "Category Effective From"),
              ("40", "Supplier Category Assignment", "Category Effective To"), "Active Engagements by Tier"]),
            ("Critical Suppliers Without LEI", "Count of distinct Engaged Supplier of an active engagement in Tier 1 - Critical or Tier 2 - High (Supplier Risk Tiering effective on the as-of date) whose party has no 02 LEI Record.",
             [("40", "Supplier Engagement", "Engaged Supplier"), ("40", "Supplier Risk Tiering", "Third-Party Criticality Tier"),
              ("02", "LEI Record", "LEI"), "Active Engagements by Tier"]),
            ("Unlinked Specialized Providers", "Count of 14 Data Vendors, 29 Servicing Provider Engagements and 28 Custody Provider Profiles with an active status that no active Supplier Engagement references (Specialized Data Vendor, Specialized Servicing Provider Engagement, Specialized Custody Provider Profile), plus Data Vendors whose Procurement Supplier ID differs from the party's ERP Supplier Number.",
             [("40", "Supplier Engagement", "Specialized Data Vendor"), ("40", "Supplier Engagement", "Specialized Servicing Provider Engagement"),
              ("40", "Supplier Engagement", "Specialized Custody Provider Profile"), ("14", "Data Vendor", "Vendor Party"),
              ("14", "Data Vendor", "Vendor Relationship Status"), ("14", "Data Vendor", "Procurement Supplier ID"),
              ("29", "Servicing Provider Engagement", "Servicing Provider"), ("28", "Custody Provider Profile", "Provider Party"),
              ("28", "Custody Provider Profile", "Provider Profile Status"), ("40", "Supplier Profile", "ERP Supplier Number")]),
        ],
        inputs=[
            ("40", "Supplier Profile", ["Supplier Party", "ERP Supplier Number", "Supplier Status", "Supplier Status Effective From",
                                        "Supplier Status Effective To", "Default Payment Terms", "Diversity Certifications",
                                        "Supplier Relationship Manager"]),
            ("40", "Supplier Onboarding Case", ["Onboarding Supplier", "Onboarding Sequence", "Sanctions Screening Result",
                                                "Onboarding Case Status", "Onboarding Approval Status", "Onboarding Completed Date"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engaged Supplier", "Service Description", "Engagement Business Owner",
                                           "Requesting Org Unit", "Engagement Buying Entity", "Engagement Business Lines",
                                           "Fund-Paid Indicator", "Specialized Data Vendor", "Specialized Servicing Provider Engagement",
                                           "Specialized Custody Provider Profile", "Fund Service Provider Role", "Engagement Start Date",
                                           "Engagement End Date", "Engagement Status"]),
            ("40", "Supplier Category Assignment", ["Categorized Engagement", "Procurement Category", "UNSPSC Code",
                                                    "Category Effective From", "Category Effective To"]),
            ("40", "Supplier Risk Tiering", ["Tiered Engagement", "Third-Party Criticality Tier", "Criticality Drivers", "Due-Diligence Depth",
                                             "Tier Effective From", "Tier Effective To"]),
            ("40", "Supplier Contract Profile", ["Profiled Contract", "Contracted Engagements", "Exit Assistance Period"]),
            ("39", "Contract", ["Contract ID", "Contract Family", "Contract Status", "Contract Effective Date", "Contract Expiry Date",
                                "Contracting Entity"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party", "Primary Country"]),
            ("02", "Organization", ["Legal Name", "Legal Jurisdiction"]),
            ("02", "Party Role", ["Role Type", "Role Status", "Role Effective From", "Role Effective To"]),
            ("02", "LEI Record", ["LEI", "LEI Registration Status"]),
            ("14", "Data Vendor", ["Vendor Party", "Vendor Type", "Vendor Relationship Status", "Strategic Tier", "Procurement Supplier ID"]),
            ("29", "Servicing Provider Engagement", ["Servicing Provider", "Servicing Role", "Engagement Start Date"]),
            ("28", "Custody Provider Profile", ["Provider Party", "Custody Provider Role", "Provider Profile Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-240", "DP-213", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a supplier status change to Blocked is published on the event stream within one hour",
        history="SCD type 2 on supplier status, engagement, tier, category and contract link since the procurement suite go-live; onboarding cases kept for the record retention period",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Supplier Party and Engaged Supplier resolves to a DP-240 party with Party Status active, no Merged Into Party and an active 02 Party Role of Role Type Supplier.",
            "ERP Supplier Number is unique per supplier party, and every 14 Data Vendor Procurement Supplier ID equals the ERP Supplier Number of the same party.",
            "Every active engagement has exactly one Supplier Risk Tiering and at least one Supplier Category Assignment effective on each date, with no overlapping tier periods.",
            "Every Profiled Contract resolves to a DP-213 contract with Contract Family = Supplier and Technology Agreement or Fund Service Provider Agreement, and every engagement in Contracted Engagements exists.",
            "No engagement has Engagement Status = Active while its supplier has Supplier Status = Blocked or Inactive.",
            "Engagement Buying Entity resolves to an active internal legal entity in DP-013 and Engagement Business Owner to an employee in DP-192.",
        ],
        notes=("W3 re-point (CW-088, CW-124): Servicing Provider Engagement moved from 13 to 29 with its attributes unchanged; the input and the Unlinked Specialized Providers measure read ('29', 'Servicing Provider Engagement'). "
               "W1b re-point (CW-940): Supplier Contract Profile.ICT Contractual Arrangement Type dropped, no successor (the DORA register of information leaves); the measure ICT Suppliers Without LEI is rewritten as Critical Suppliers Without LEI on the 40 inherent tier (Tier 1 - Critical or Tier 2 - High), the population the 2023 interagency third-party guidance expects to identify. DORA register wording in the definition reads the outsourcing register. "
               "Master concept: CONCEPT_OWNERSHIP rows Supplier Profile (40) and Supplier Engagement (40, VENG-), with Supplier "
               "Risk Tiering, Supplier Category Assignment and Supplier Contract Profile (40); source of the SM-00 Vendor dimension, "
               "area CORP (CD-296). Party name, LEI and address are read from 02 through DP-240 and never copied (CD-143, CD-260, "
               "CD-360). The contract status and dates are read from 39 Contract through DP-213 (CD-354); the 40 Contract Status "
               "copy is not read. Tier is the 40 inherent tier only; the residual risk rating is 37's and is shown beside it only "
               "in DP-219 (CD-248). Remittance bank details (Supplier Remittance Detail) are deliberately left out of the shared "
               "dimension and published only in DP-221; Total Contract Value and pricing terms are left out so the dimension stays "
               "Confidential rather than Restricted - Commercial Terms. Boundary: DP-073 Data Vendor Risk & Renewals becomes the "
               "data-vendor view of DP-219, the 40 oversight product (CD-298, CD-350), not of this product; this product supplies "
               "only the data vendor to supplier link. Spend is DP-221 and reconciles to 19 (CD-353). Fund-appointed providers "
               "link through Fund Service Provider Role (01, read through DP-004 by key). PII = Y: Supplier Profile and Engagement "
               "attributes are flagged PII because a supplier can be a sole trader, and Engagement Business Owner and Supplier "
               "Relationship Manager are employee keys. Operating model: in house; with an outsourced procure-to-pay provider "
               "the source is the provider's procurement suite extract and the grain is unchanged (CD-297). Open SME questions "
               "(40 Q1, Q3, Q5): the supplier system of record; who sets the criticality tier; whether fund service providers are "
               "procured through 40 or appointed by fund boards. Taxonomy gap: Supplier Engagement holds no reference to the 41 "
               "IT services or applications it supplies (GAP-40-001; the removed register header held the only link); DP-211 resolves the Software Vendor party "
               "instead. Decisions: CD-143, CD-248, CD-257, CD-260, CD-296, CD-297, CD-298, CD-350, CD-353, CD-354, CD-360."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-211": dict(
        definition=("The enterprise inventory of applications (APPL-), including the provider-hosted platforms of outsourced "
                    "functions, with ownership, criticality and security categorization, business capability mappings, "
                    "lifecycle (TIME) assessments, interfaces, recovery profiles, AI system facts, the IT services they "
                    "deliver and the configuration items that run them. It publishes the concept ownership rows Application "
                    "(41, APPL-), IT Service (41) and Configuration Item (41, CFGI-) as the SM-00 Application dimension "
                    "(CD-296), and it is the system of record inventory the enterprise catalog points at (CD-160, CD-263, "
                    "CD-295): lineage, resilience mapping, access, incidents, the outsourcing register and legal holds resolve to one "
                    "application key. It owns no certified metric family."),
        business_questions=[
            "Which applications are in production, how critical are they, who owns them and which business capabilities and business lines do they support?",
            "Which Tier 1 - Mission Critical applications lack a recovery profile, an accountable business owner or a current lifecycle assessment?",
            "Which applications rated Eliminate or Sunsetting are past their target retirement date, and which interfaces still depend on them?",
            "Which production configuration items are past end of vendor support, and which applications do they run?",
            "Which vendor-supplied applications have no approved supplier in the Vendor Master?",
        ],
        grain="Application (APPL-) x effective period, with ownership, capability mapping, lifecycle assessment, interface, IT service and configuration item as conformed child tables; SCD type 2",
        dimensions=["Application", "Application type and hosting model", "Application status", "Criticality tier and security categorization",
                    "Owning org unit and legal entity", "Ownership role and role holder", "Business capability", "TIME rating",
                    "Recovery tier", "IT service and ICT service type", "Configuration item class and environment",
                    "Software vendor (supplier)", "Effective date"],
        measures=[
            ("Applications in Production", "Count of Applications with Application Status = In Production on the as-of date, by Application Type, Hosting Model and Criticality Tier.",
             [("41", "Application", "Application ID"), ("41", "Application", "Application Status"), ("41", "Application", "Application Type"),
              ("41", "Application", "Hosting Model"), ("41", "Application", "Criticality Tier")]),
            ("Applications Without Business Owner", "Applications in Production with no Application Ownership Assignment of Application Ownership Role = Business Owner effective on the as-of date, or whose Business Owner holder has Employment Status = Terminated.",
             [("41", "Application Ownership Assignment", "Owned Application"), ("41", "Application Ownership Assignment", "Application Ownership Role"),
              ("41", "Application Ownership Assignment", "Application Role Holder"), ("41", "Application Ownership Assignment", "Ownership Effective From"),
              ("41", "Application Ownership Assignment", "Ownership Effective To"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status"), "Applications in Production"]),
            ("Critical Applications Without Recovery Profile", "Applications in Production with Criticality Tier = Tier 1 - Mission Critical or Tier 2 - Business Critical and no Recovery Tier or Recovery Time Objective Hours.",
             [("41", "Application Recovery Profile", "Recovery Tier"), ("41", "Application Recovery Profile", "Recovery Time Objective Hours"),
              ("41", "Application", "Criticality Tier"), "Applications in Production"]),
            ("Applications Without Capability Mapping", "Applications in Production of Application Type Business Application or AI System with no Application Capability Mapping effective on the as-of date.",
             [("41", "Application Capability Mapping", "Mapped Application"), ("41", "Application Capability Mapping", "Supported Business Capability"),
              ("41", "Application Capability Mapping", "Capability Mapping Effective From"), ("41", "Application Capability Mapping", "Capability Mapping Effective To"),
              "Applications in Production"]),
            ("Stale Lifecycle Assessments", "Applications in Production whose latest Lifecycle Assessment Date is more than 12 months before the as-of date, or that have none.",
             [("41", "Application Lifecycle Assessment", "Assessed Application"), ("41", "Application Lifecycle Assessment", "Lifecycle Assessment Date"),
              "Applications in Production"]),
            ("Overdue Retirements", "Applications with Application Status in (In Production, Sunsetting) whose latest TIME Rating is Eliminate or Migrate and whose Target Retirement Date is before the as-of date.",
             [("41", "Application Lifecycle Assessment", "TIME Rating"), ("41", "Application Lifecycle Assessment", "Target Retirement Date"),
              ("41", "Application", "Application Status")]),
            ("Interfaces to Retiring Applications", "Count of Application Interfaces with Interface Status = Active whose Source Application or Target Application has Application Status Sunsetting or Decommissioned.",
             [("41", "Application Interface", "Interface Code"), ("41", "Application Interface", "Source Application"),
              ("41", "Application Interface", "Target Application"), ("41", "Application Interface", "Interface Status"),
              ("41", "Application", "Application Status")]),
            ("Configuration Items Past Vendor Support", "Count of Configuration Items with Environment = Production, Configuration Item Status = Active and End of Vendor Support Date before the as-of date, by Instantiated Application's Criticality Tier.",
             [("41", "Configuration Item", "Configuration Item ID"), ("41", "Configuration Item", "Environment"),
              ("41", "Configuration Item", "Configuration Item Status"), ("41", "Configuration Item", "End of Vendor Support Date"),
              ("41", "Configuration Item", "Instantiated Application"), ("41", "Application", "Criticality Tier")]),
            ("Vendor Applications Without Approved Supplier", "Applications in Production with a Software Vendor or AI System Provider party that has no 40 Supplier Profile with Supplier Status in (Approved, Restricted).",
             [("41", "Application", "Software Vendor"), ("41", "AI System Profile", "AI System Provider"),
              ("40", "Supplier Profile", "Supplier Party"), ("40", "Supplier Profile", "Supplier Status"), "Applications in Production"]),
        ],
        inputs=[
            ("41", "Application", ["Application ID", "Application Name", "Application Type", "Hosting Model", "Software Vendor",
                                   "Software Product Name", "Owning Org Unit", "Owning Legal Entity", "Application Status",
                                   "Confidentiality Impact Level", "Integrity Impact Level", "Availability Impact Level",
                                   "Criticality Tier", "Internet-Facing Indicator", "Production Go-Live Date", "Decommission Date"]),
            ("41", "Application Ownership Assignment", ["Owned Application", "Application Ownership Role", "Application Role Holder",
                                                        "Ownership Effective From", "Ownership Effective To"]),
            ("41", "Application Capability Mapping", ["Mapped Application", "Supported Business Capability", "Capability Support Role",
                                                      "Business Lines Served", "Capability Mapping Effective From",
                                                      "Capability Mapping Effective To"]),
            ("41", "Application Lifecycle Assessment", ["Assessed Application", "Lifecycle Assessment Date", "TIME Rating",
                                                        "Technical Fitness Score", "Business Fitness Score", "Target Retirement Date",
                                                        "Successor Application"]),
            ("41", "Application Interface", ["Interface Code", "Source Application", "Target Application", "External Endpoint Party",
                                             "Interface Mechanism", "Interface Message Standard", "Interface Schedule",
                                             "Carried Data Feed", "Interface Status"]),
            ("41", "Application Recovery Profile", ["Recovery Tier", "Recovery Time Objective Hours", "Recovery Point Objective Minutes",
                                                    "Disaster Recovery Strategy", "Recovery Location"]),
            ("41", "AI System Profile", ["AI System Provider", "Log Retention Months", "Human Oversight Assignee"]),
            ("41", "AI System Use Case Link", ["Linked AI System", "Served AI Use Case", "Use Case Link Effective From",
                                               "Use Case Link Effective To"]),
            ("41", "IT Service", ["IT Service Code", "IT Service Name", "IT Service Category", "ICT Service Type", "Supporting Applications",
                                  "IT Service Owner", "Third-Party Service Provider", "Service Hours", "IT Service Status"]),
            ("41", "Configuration Item", ["Configuration Item ID", "Configuration Item Name", "Configuration Item Class", "Environment",
                                          "Instantiated Application", "Hosting Site", "Configuration Item Status",
                                          "End of Vendor Support Date"]),
            ("41", "Configuration Item Relationship", ["Parent Configuration Item", "Child Configuration Item", "CI Relationship Type",
                                                       "CI Relationship Effective From", "CI Relationship Effective To"]),
            ("40", "Supplier Profile", ["Supplier Party", "ERP Supplier Number", "Supplier Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
        ],
        upstream=["DP-210", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a new production application or a status change is available the business day after it is recorded in the inventory tool",
        history="SCD type 2 on every application attribute, ownership, mapping, interface and configuration item since the inventory go-live; decommissioned applications kept indefinitely for lineage and legal holds",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Application in Production has exactly one Business Owner and one IT Owner Application Ownership Assignment effective on each date, and each role holder resolves to an employee in DP-192.",
            "Every Application with Criticality Tier Tier 1 - Mission Critical has an Application Recovery Profile whose Recovery Tier is consistent with Recovery Time Objective Hours (Tier 1 - Recover within 4 hours means at most 4 hours).",
            "An Application with Application Status = Decommissioned has a Decommission Date, no Active Application Interface and no Active Production Configuration Item instantiating it.",
            "Every Source Application and Target Application of an interface, every Instantiated Application of a configuration item and every Supporting Application of an IT service resolves to an Application ID.",
            "Every Software Vendor, AI System Provider and Third-Party Service Provider party of an application in production resolves to a DP-210 supplier.",
            "Every Supported Business Capability value is a capability code of the business capability map.",
        ],
        notes=("W1b: AI System Profile.Input Data Controlled Indicator dropped, no successor (CW-941; it was an EU AI Act deployer duty); no measure read it. IT Service.ICT Service Type keeps its name; its DORA S-code values are removed, and no measure filters on them. "
               "Master concept: CONCEPT_OWNERSHIP rows Application (41, APPL-), IT Service (41) and Configuration Item (41, CFGI-); "
               "source of the SM-00 Application dimension, area CORP (CD-296). System of record (CD-160, CD-263, CD-295): which "
               "application is authoritative for a taxonomy element is 21 System of Record Designation, published by DP-101, which "
               "lists this product upstream; this product must never list DP-101 or DP-100 (no cycle, CD-361). Provider platforms "
               "of outsourced functions are inventoried with Hosting Model = Provider-Hosted and the grain does not change "
               "(CD-147, CD-297). Whether an application supports a critical or important function is 37 Resilience Resource "
               "Mapping, not read here. Model deployments (41 AI System Model Deployment) are published by DP-212, which lists "
               "this product upstream. Identity, access, incidents, changes and projects are consumer products of 41 (DP-231 to "
               "DP-234). PII = Y: Application Role Holder, IT Service Owner and Human Oversight Assignee are employee keys; the "
               "wide view shows role coverage, not names. Classified Confidential; the Internet-Facing Indicator and security "
               "categorization are released to the security team's view only. Open SME questions (41 Q1, Q2, Q10, Q12): which "
               "tool is the inventory and whether it holds the CMDB; whether provider platforms are applications or IT services "
               "only; whether 14 Consuming Application is re-keyed to APPL-; CMDB state mapping. Taxonomy gap: Supported Business "
               "Capability is text, not a reference, until the capability map is registered as data (37 SME Q13). Taxonomy gap: "
               "Application has no attribute linking it to the 40 Supplier Engagement that supplies it; the supplier is matched by "
               "the Software Vendor party. Decisions: CD-147, CD-160, CD-263, CD-295, CD-296, CD-297, CD-361."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-212": dict(
        definition=("The registry of every quantitative, AI and trading-algorithm model the firm uses, by model and version "
                    "(MODEL- x version): purpose, type, owner, vendor, use status, dated tier with materiality, complexity and "
                    "uncertainty, validation history with outcomes and conditions, ongoing performance monitoring results "
                    "and breaches, and the applications that deploy each version. It publishes the concept ownership row "
                    "Model Inventory Entry (37, MODEL-) with Model Tier Assignment, Model Validation and Model Performance "
                    "Monitoring (CD-246) as the SM-00 Model dimension (CD-354). Under CD-294 it is the registry that every "
                    "data product publishing a score, forecast or recommendation cites by model ID, version and run date, so "
                    "model risk can see which products rest on an unvalidated or breached model. It owns no certified metric "
                    "family; scores and forecasts stay measures of the products that compute them."),
        business_questions=[
            "Which model versions are in use, by type and tier, and which have never been validated or were rejected?",
            "Which Tier 1 models are overdue for annual validation, and which are approved only with conditions?",
            "Which models breached a monitoring threshold in the last period, and which production applications deploy them?",
            "Which deployed model versions are not the validated version of that model?",
        ],
        grain="Model (MODEL-) x model version, with tier (model x effective period), validation (version x sequence), monitoring (version x test x period end) and deployment (application x model x effective period) as conformed child tables; SCD type 2",
        dimensions=["Model and version", "Model type and purpose", "Model owner (employee)", "Model vendor", "Model use status",
                    "Model tier, materiality, complexity and uncertainty", "Validation type and outcome", "Monitoring test",
                    "Deploying application (AI system)", "Effective date"],
        measures=[
            ("Models in Use", "Count of Model Inventory Entry rows (Model ID x Model Version) with Model Use Status = Active, by Model Type and the Model Tier effective on the as-of date.",
             [("37", "Model Inventory Entry", "Model ID"), ("37", "Model Inventory Entry", "Model Version"),
              ("37", "Model Inventory Entry", "Model Use Status"), ("37", "Model Inventory Entry", "Model Type"),
              ("37", "Model Tier Assignment", "Tiered Model"), ("37", "Model Tier Assignment", "Model Tier"),
              ("37", "Model Tier Assignment", "Tier Effective From"), ("37", "Model Tier Assignment", "Tier Effective To")]),
            ("Models in Use Without Approving Validation", "Models in Use with no Model Validation having Model Validation Outcome in (Approved, Approved with Conditions).",
             [("37", "Model Validation", "Validated Model"), ("37", "Model Validation", "Model Validation Outcome"), "Models in Use"]),
            ("Models in Use After Rejection", "Models in Use whose latest Model Validation (highest Model Validation Sequence) has Model Validation Outcome = Rejected.",
             [("37", "Model Validation", "Model Validation Sequence"), ("37", "Model Validation", "Model Validation Outcome"), "Models in Use"]),
            ("Tier 1 Validations Overdue", "Models in Use with Model Tier = Tier 1 whose latest Model Validation Completed Date is more than 12 months before the as-of date.",
             [("37", "Model Validation", "Model Validation Completed Date"), ("37", "Model Tier Assignment", "Model Tier"), "Models in Use"]),
            ("Conditional Approval Share %", "Models in Use whose latest validation outcome is Approved with Conditions / Models in Use, by Model Tier.",
             [("37", "Model Validation", "Model Validation Outcome"), ("37", "Model Validation", "Model Validation Conditions"), "Models in Use"]),
            ("Untiered Models in Use", "Models in Use with no Model Tier Assignment effective on the as-of date.",
             [("37", "Model Tier Assignment", "Tiered Model"), "Models in Use"]),
            ("Monitoring Breaches", "Count of Model Performance Monitoring rows with Monitoring Threshold Breached Indicator = Y, by Monitoring Period End Date, Monitoring Test and Model Tier.",
             [("37", "Model Performance Monitoring", "Monitored Model"), ("37", "Model Performance Monitoring", "Monitoring Period End Date"),
              ("37", "Model Performance Monitoring", "Monitoring Test"), ("37", "Model Performance Monitoring", "Monitoring Threshold Breached Indicator")]),
            ("Breached Models in Production Deployment", "Count of model versions with a Monitoring Breach in the latest monitoring period that an AI System Model Deployment effective on the as-of date links to an Application with Application Status = In Production.",
             [("41", "AI System Model Deployment", "Model Deploying AI System"), ("41", "AI System Model Deployment", "Deployed Model"),
              ("41", "AI System Model Deployment", "Model Deployment Effective From"), ("41", "AI System Model Deployment", "Model Deployment Effective To"),
              ("41", "Application", "Application ID"), ("41", "Application", "Application Status"), "Monitoring Breaches"]),
            ("Deployments of Unvalidated Versions", "Count of AI System Model Deployments effective on the as-of date whose Deployed Model version has no approving Model Validation.",
             [("41", "AI System Model Deployment", "Deployed Model"), ("37", "Model Validation", "Validated Model"),
              ("37", "Model Validation", "Model Validation Outcome")]),
        ],
        inputs=[
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Type", "Model Purpose", "Model Owner",
                                             "Model Vendor", "Model Use Status"]),
            ("37", "Model Tier Assignment", ["Tiered Model", "Model Tier", "Model Materiality", "Model Complexity", "Model Uncertainty",
                                             "Tier Effective From", "Tier Effective To"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Sequence", "Model Validation Type", "Internal Validator",
                                        "External Validator", "Model Validation Completed Date", "Model Validation Outcome",
                                        "Model Validation Conditions"]),
            ("37", "Model Performance Monitoring", ["Monitored Model", "Monitoring Period End Date", "Monitoring Test",
                                                    "Monitoring Threshold Breached Indicator", "Back-Test Evidence"]),
            ("41", "AI System Model Deployment", ["Model Deploying AI System", "Deployed Model", "Model Deployment Effective From",
                                                  "Model Deployment Effective To"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Type", "Application Status", "Criticality Tier"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-211", "DP-192"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a validation outcome or monitoring breach is available the business day after it is recorded",
        history="Every model version, tier period, validation and monitoring result kept since the inventory go-live and for at least the retention period after the model is retired",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Model Inventory Entry is unique by Model ID x Model Version and has Model Type, Model Owner and Model Use Status populated.",
            "Every model version with Model Use Status = Active has exactly one Model Tier Assignment effective on each date, with no overlapping tier periods.",
            "Every Model Validation has a Model Validation Completed Date and Model Validation Outcome, and Model Validation Sequence increases with the completed date for each model version.",
            "Every Deployed Model resolves to a Model Inventory Entry version and every Model Deploying AI System to a DP-211 Application with Application Type = AI System.",
            "Every Model Owner and Internal Validator resolves to an employee in DP-192, and the Internal Validator of a validation is not the Model Owner of that model.",
        ],
        notes=("W1b: Model Inventory Entry.Trading Algorithm Code dropped, no successor (CW-937; MiFIR RTS 22 algorithm codes); the measure Trading Algorithms Without Code, its business question and its DQ rule are removed. Trading algorithms stay registered by Model Type. "
               "Master concept: CONCEPT_OWNERSHIP row Model Inventory Entry (37, MODEL-) with Model Tier Assignment, Model Validation "
               "and Model Performance Monitoring (CD-246); source of the SM-00 Model dimension (CD-296, CD-354). CD-294: every "
               "scoring, forecasting or recommendation model behind a data product is registered here; the scores stay derived "
               "measures of the product that computes them, carrying the model ID, version and run date. The registry holds no "
               "list of uses (37 holds none): product-to-model usage is built from the consuming specs and the 21 catalog export "
               "(CD-295). CD-352 re-points DP-018, DP-046, DP-047, DP-049, DP-052 and DP-055 to this product by lineage; 31 risk, "
               "32 attribution, 22 valuation and 34 ESG models cite it in their specs. 31 Risk Model is the risk function's use "
               "of a model version and references this registry (CD-211). Model Vendor and External Validator are 02 party keys "
               "carried as keys. PII = Y: Model Owner and Internal Validator are employee keys. Open SME questions (37 Q7, Q8; "
               "Corporate B brief Q2): which models are in the inventory today, including vendor and distribution analytics "
               "models (recommended: all, with tier setting validation depth); which standard model risk follows (SR 26-2 by "
               "analogy, CW-937). Taxonomy gap: no validation frequency or next validation due date per tier; Tier 1 is taken "
               "as annual from the Model Tier list, and Tier 2 and Tier 3 frequencies are firm policy outside the taxonomy, so "
               "only Tier 1 overdue validation is measured. Taxonomy gap: Model Inventory Entry has no deployment link for "
               "non-AI applications (only 41 AI System Model Deployment), so models run inside other applications are not "
               "traced to them. Taxonomy gap: Model Performance Monitoring holds no observed value or threshold, only the breach "
               "indicator. Decisions: CD-211, CD-246, CD-294, CD-295, CD-296, CD-352, CD-354."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-213": dict(
        definition=("One record of every executed legal instrument of the group (concept ownership row Contract, 39, CTRCT-, "
                    "with Contract Party, Contract Signatory, Contract Document Version, Contract Key Date and Contract "
                    "Clause Position; CD-257): family and subtype, hierarchy and amendments, contracting entity or fund, "
                    "parties and their roles, signatories, document versions, key dates and notice deadlines, negotiated "
                    "clause positions, and the link to the typed record (distribution agreement, data license, trading "
                    "agreement, advisory agreement, supplier contract, lease and others) that keeps its "
                    "commercial terms. It gives every product one contract key and one set of dates, status and governing "
                    "law, as the SM-00 Contract dimension (CD-296, CD-354); external parties take their identity from DP-240. "
                    "It owns no certified metric family and publishes no commercial terms."),
        business_questions=[
            "Which contracts are in force for each group entity and fund, by family and counterparty, and which expire in the next 90 days?",
            "Which renewal and termination notice deadlines fall in the next 90 days and have not been actioned?",
            "Which in-force contracts have no executed document, no counterparty or no governing law recorded?",
            "Which contracts were signed by an employee without a recorded signing authority grant or power of attorney?",
            "Which typed contracts (distribution, data license, trading, advisory, supplier) are missing the link to their typed record?",
        ],
        grain="Contract (CTRCT-) x effective period, with contract party, signatory, document version, key date and clause position as conformed child tables; SCD type 2",
        dimensions=["Contract and parent contract", "Contract family, subtype and hierarchy role", "Contracting entity (internal legal entity)",
                    "Contracting product (fund)", "Contract party and party role", "Typed record type", "Contract status",
                    "Governing law", "Key date type", "Clause type and position", "Legal owner (employee)", "Effective date"],
        measures=[
            ("Contracts in Force", "Count of Contracts with Contract Status = Active and Contract Effective Date <= as-of date and (Contract Expiry Date blank or after the as-of date), by Contract Family, Contracting Entity and Typed Record Type.",
             [("39", "Contract", "Contract ID"), ("39", "Contract", "Contract Status"), ("39", "Contract", "Contract Effective Date"),
              ("39", "Contract", "Contract Expiry Date"), ("39", "Contract", "Contract Family"), ("39", "Contract", "Contracting Entity"),
              ("39", "Typed Contract Link", "Typed Record Type")]),
            ("Contracts Expiring (90 Days)", "Contracts in Force whose Contract Expiry Date falls within the next 90 days, by Contract Family.",
             [("39", "Contract", "Contract Expiry Date"), "Contracts in Force"]),
            ("Open Notice Deadlines (90 Days)", "Count of Contract Key Date rows of Key Date Type Renewal Notice Deadline, Termination Notice Deadline or Option Exercise Deadline with Key Date Value within the next 90 days and Key Date Action Status = Open, on Contracts in Force.",
             [("39", "Contract Key Date", "Key Date Contract"), ("39", "Contract Key Date", "Key Date Type"),
              ("39", "Contract Key Date", "Key Date Value"), ("39", "Contract Key Date", "Key Date Action Status"), "Contracts in Force"]),
            ("Contracts Without Executed Document", "Contracts in Force with no Contract Document Version of Document Version Type = Executed.",
             [("39", "Contract Document Version", "Document Version Contract"), ("39", "Contract Document Version", "Document Version Type"),
              "Contracts in Force"]),
            ("Contracts Without Counterparty", "Contracts in Force with no Contract Party effective on the as-of date naming an External Contract Party or an Internal Contract Party other than the Contracting Entity.",
             [("39", "Contract Party", "Party Contract"), ("39", "Contract Party", "External Contract Party"),
              ("39", "Contract Party", "Internal Contract Party"), ("39", "Contract Party", "Party Effective From"),
              ("39", "Contract Party", "Party Effective To"), "Contracts in Force"]),
            ("Missing Governing Law", "Contracts in Force with Governing Law blank.",
             [("39", "Contract", "Governing Law"), "Contracts in Force"]),
            ("Employee Signatures Without Authority", "Count of Contract Signatory rows with a Signing Employee and neither Relied-On Authority Grant nor Relied-On Power of Attorney, by Signed Date period.",
             [("39", "Contract Signatory", "Signing Employee"), ("39", "Contract Signatory", "Relied-On Authority Grant"),
              ("39", "Contract Signatory", "Relied-On Power of Attorney"), ("39", "Contract Signatory", "Signed Date")]),
            ("Typed Link Completeness %", "Contracts in Force whose Typed Record Type is not None and whose matching linked-record attribute is populated (or, for Supplier Contract Profile (40), whose contract is a 40 Profiled Contract) / Contracts in Force whose Typed Record Type is not None.",
             [("39", "Typed Contract Link", "Typed Record Type"), ("39", "Typed Contract Link", "Linked Distribution Agreement"),
              ("39", "Typed Contract Link", "Linked Data License Agreement"), ("39", "Typed Contract Link", "Linked Trading Agreement"),
              ("39", "Typed Contract Link", "Linked Fund Advisory Agreement"),
              ("39", "Typed Contract Link", "Linked Investment Mandate"), "Contracts in Force"]),
            ("Non-Standard Clause Share %", "Contracts in Force with at least one Contract Clause Position of Clause Position = Non-Standard - Approved / Contracts in Force with any clause positions recorded, by Clause Type.",
             [("39", "Contract Clause Position", "Clause Contract"), ("39", "Contract Clause Position", "Clause Type"),
              ("39", "Contract Clause Position", "Clause Position"), "Contracts in Force"]),
            ("Contracts With Departed Legal Owner", "Contracts in Force whose Legal Owner has Employment Status = Terminated in DP-192.",
             [("39", "Contract", "Legal Owner"), ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"),
              "Contracts in Force"]),
        ],
        inputs=[
            ("39", "Contract", ["Contract ID", "Contract Title", "Contract Family", "Contract Subtype", "Contract Hierarchy Role",
                                "Parent Contract", "Contracting Entity", "Contracting Product", "Contract Status",
                                "Contract Effective Date", "Contract Expiry Date", "Governing Law", "Legal Owner",
                                "Contract Business Lines"]),
            ("39", "Typed Contract Link", ["Typed Record Type", "Linked Distribution Agreement", "Linked Agreement Amendment",
                                           "Linked Data License Agreement", "Linked Trading Agreement", "Linked Fund Advisory Agreement",
                                           "Linked Securities Lending Agreement", "Linked Intercompany Agreement",
                                           "Linked Service Arrangement", "Linked Investment Mandate", "Linked Debt Facility",
                                           "Linked Insurance Policy"]),
            ("39", "Contract Party", ["Party Contract", "Contract Party Role", "External Contract Party", "Internal Contract Party",
                                      "Notice Contact Point", "Party Effective From", "Party Effective To"]),
            ("39", "Contract Signatory", ["Signed Contract", "Signing Employee", "External Signatory", "Signing Capacity",
                                          "Relied-On Power of Attorney", "Relied-On Authority Grant", "Signed Date"]),
            ("39", "Contract Document Version", ["Document Version Contract", "Document Version Number", "Document Sequence",
                                                 "Document Role", "Document Version Type", "Document Location",
                                                 "E-Signature Envelope ID", "Document Executed Date"]),
            ("39", "Contract Key Date", ["Key Date Contract", "Key Date Type", "Key Date Sequence", "Key Date Value",
                                         "Key Date Action Status"]),
            ("39", "Contract Clause Position", ["Clause Contract", "Clause Type", "Clause Position", "Clause Summary"]),
            ("40", "Supplier Contract Profile", ["Profiled Contract"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party"]),
            ("02", "Organization", ["Legal Name", "Legal Jurisdiction"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-240", "DP-192", "DP-013", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; an executed contract is available the business day after it is filed in the repository",
        history="SCD type 2 on every contract, party, key date and clause position; every document version kept; contracts kept for the record retention period after expiry or termination and indefinitely while under legal hold",
        classification="Restricted - Legal",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Contract has Contract Family, Contract Subtype, Contracting Entity and Contract Status, and a contract with Contract Hierarchy Role Amendment, Amendment and Restatement, Statement of Work / Order, Schedule / Addendum or Side Letter has a Parent Contract.",
            "Contract Expiry Date, where present, is on or after Contract Effective Date, and a contract with Contract Status = Active has an Executed Contract Document Version.",
            "Exactly one linked-record attribute is populated when Typed Record Type is not None (except Supplier Contract Profile (40) and the 44 lease, where the link is held on the other side), and none when it is None; one typed record links to at most one contract.",
            "Every External Contract Party resolves to a DP-240 party with no Merged Into Party, every Contracting Entity and Internal Contract Party to a DP-013 internal legal entity, and every Contracting Product to a DP-004 product.",
            "On typed rows, Contract Status, Contract Effective Date, Contract Expiry Date and Governing Law equal the typed record's values on the same business day (row rule, CD-257).",
            "Every Contract Key Date with Key Date Type Renewal Notice Deadline or Termination Notice Deadline falls on or before the contract's Contract Expiry Date.",
        ],
        notes=("W4 re-point (CW-930): 39 Typed Contract Link.Linked Side Letter, Linked Investor Commitment, Linked Private Fund Profile and Linked Fund Credit Facility dropped, no successor (their 30 targets retire); Typed Link Completeness % no longer tests the investor commitment link. "
               "Master concept: CONCEPT_OWNERSHIP row Contract (39, CTRCT-) and its parts Contract Party, Contract Signatory, Contract "
               "Document Version, Contract Key Date and Contract Clause Position; source of the SM-00 Contract dimension (CD-296, "
               "CD-354). Row rule (CD-257, CD-289): on typed rows the dates, status, governing law and parties are derived copies "
               "of the typed record (05, 14, 26, 28, 30, 35, 01, 10, 16, 43, 44) and are published as received; that is why "
               "Contract Status, dates and Governing Law are read from 39 although the catalog marks them as copies (CONTRACT.md "
               "rule 2 exception: the conformed contract record lives in 39). Commercial terms stay with the typed owners and are "
               "not published. This product does not list the typed-record products (DP-005, DP-147 and others) upstream, so they "
               "may list it without a cycle (DP-081 may add it by lineage). Party identity comes from DP-240 (CD-360); Notice "
               "Contact Point and External Signatory are 02 keys. 40 Supplier Contract Profile is read only for its contract key, "
               "to test the supplier typed link that 40 holds. Classified Restricted - Legal because clause positions, document "
               "locations and signatories are legal records; a Confidential Contract dimension view (ID, family, subtype, entity, "
               "status, dates, governing law) is the shared view. PII = Y: Legal Owner, Signing Employee and the signatory rows "
               "are personal data. Operating model: in house with outside counsel, no grain change. Open SME questions (39 Q1, "
               "Q2, Q3, Q9): which contract lifecycle tool is the repository and whether it is the system of record for 05 and 14 "
               "agreements; whether Legal holds executed copies of 05 agreements, IMAs, LPAs and side letters. Taxonomy gap: no "
               "contract value or currency is held on the generic record (by design, CD-257), so no value-weighted measure is "
               "possible here. Taxonomy gap: the 44 Lease link is held on the 44 side and is not read in Wave E1. Decisions: "
               "CD-257, CD-289, CD-296, CD-354, CD-360."),
    ),
}
