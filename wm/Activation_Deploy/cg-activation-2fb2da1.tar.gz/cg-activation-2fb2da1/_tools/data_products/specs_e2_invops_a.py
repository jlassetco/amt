"""Data product specifications: Wave E2, Investment Operations group "invops_pricing_settlement_risk" (DP-148 to DP-156).

Consumer-aligned products of 22 Market Data & Pricing, 18 Portfolio & Investment Book of Record, 26 Trade Operations,
Settlement & Collateral and 31 Investment Risk, built on the Wave E1 foundational products. Brief:
00_Program/Expansion/Product_Briefs/Investment_Operations.md; candidates: consolidation/proposals_dp_investment_ops.py.
See CONTRACT.md.

WP1 lineage pass: the specs of the retired DP-156 are deleted (framework.RETIRED_PRODUCTS; register rows kept).
"""

SPECS = {
    # ================================================= 22 Market Data & Pricing =================================================
    "DP-148": dict(
        definition=("Daily evidence of how each approved price was reached: the pricing policy, source hierarchy and tolerance "
                    "rules in force, every price observation received from vendors and brokers, the validation exceptions the "
                    "tolerance checks raised, the overrides applied and the challenges sent to vendors with their outcomes. "
                    "Pricing works the day's exceptions from it before the NAV strike, and the valuation designee, fund "
                    "accounting and fund boards see stale, overridden and challenged prices by vendor, dataset and asset class. "
                    "It takes the approved price itself from DP-143 Prices, FX & Curves and adds only the control facts that "
                    "DP-143 deliberately does not publish; it owns no certified number."),
        business_questions=[
            "Which approved prices for today's pricing point still carry an open validation exception before the NAV strike, by severity, asset class and tolerance check?",
            "Which overrides were applied today, for what reason, and was each approved by someone other than the requester before the price was approved?",
            "Which vendors and datasets raise the most exceptions and challenges, and how often do they revise their price when we challenge it?",
            "Is each approved price taken from the highest-ranked source in the pricing source hierarchy, and where and why do we fall back to a lower-ranked source?",
            "Which asset classes and instrument types are priced with no effective tolerance rule?",
            "For the quarterly valuation report: how many stale, overridden and challenged prices were there by vendor and asset class, and how were they resolved?",
        ],
        grain=("Price validation exception (approved price version x tolerance rule x raised timestamp), with price override "
               "(approved price x override sequence) and price challenge (PCHL-) as companion facts, summarized daily at "
               "pricing point x price date x asset class x source dataset"),
        dimensions=["Price date and pricing point (snap time, pricing calendar)", "Instrument, instrument type and asset class",
                    "Source dataset and data vendor", "Price origin and price type", "Tolerance check type and exception severity",
                    "Exception resolution and workflow status", "Override reason", "Challenge reason and outcome",
                    "Pricing policy version and pricing operating model", "Approver and exception owner (employee)"],
        measures=[
            ("Validation Exceptions Raised",
             "Count of Price Validation Exceptions by the Tolerance Check Type and Exception Severity Assigned of the Breached "
             "Tolerance Rule, by the Approved Pricing Point and Price Date of the Exception Approved Price and by the Asset Class "
             "of its Priced Instrument (from DP-097); the raised day is the date of Exception Raised Timestamp.",
             [("22", "Price Validation Exception", "Exception Approved Price"), ("22", "Price Validation Exception", "Breached Tolerance Rule"),
              ("22", "Price Validation Exception", "Exception Raised Timestamp"), ("22", "Price Tolerance Rule", "Tolerance Rule Code"),
              ("22", "Price Tolerance Rule", "Tolerance Check Type"), ("22", "Price Tolerance Rule", "Exception Severity Assigned"),
              ("22", "Approved Price", "Approved Price ID"), ("22", "Approved Price", "Priced Instrument"),
              ("22", "Approved Price", "Approved Pricing Point"), ("22", "Approved Price", "Price Date"),
              ("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Asset Class")]),
            ("Open Exceptions by Age",
             "Count of Price Validation Exceptions with Exception Workflow Status not in (Resolved / Completed, Closed, Rejected, "
             "Canceled) at the as-of timestamp, bucketed by hours since Exception Raised Timestamp (under 1, 1-4, 4-24, over 24) "
             "and by Exception Severity Assigned.",
             [("22", "Price Validation Exception", "Exception Workflow Status"), ("22", "Price Validation Exception", "Exception Raised Timestamp"),
              ("22", "Price Tolerance Rule", "Exception Severity Assigned"), "Validation Exceptions Raised"]),
            ("Approved With Open Exception",
             "Count of current Approved Price versions with Price Approval Status = Approved whose Price Approval Timestamp is "
             "earlier than the resolution of an exception raised on them: at least one Price Validation Exception on the version "
             "still open (Exception Workflow Status not Resolved / Completed or Closed) when the price was approved. A control "
             "failure that must be zero at the NAV strike.",
             [("22", "Approved Price", "Approved Price ID"), ("22", "Approved Price", "Approved Price Version"),
              ("22", "Approved Price", "Price Approval Status"), ("22", "Approved Price", "Price Approval Timestamp"),
              ("22", "Price Validation Exception", "Exception Approved Price"), ("22", "Price Validation Exception", "Exception Workflow Status")]),
            ("Exception Resolution Mix",
             "Share of resolved Price Validation Exceptions by Exception Resolution (Price Confirmed, Alternate Source Selected, "
             "Price Overridden, Referred for Fair Value, Challenged with Vendor, Corrected by Vendor, Rule Not Applicable), by "
             "Tolerance Check Type and source dataset of the Selected Observation.",
             [("22", "Price Validation Exception", "Exception Resolution"), ("22", "Price Validation Exception", "Exception Workflow Status"),
              ("22", "Price Tolerance Rule", "Tolerance Check Type"), ("22", "Approved Price", "Selected Observation"),
              ("22", "Price Observation", "Price Observation Key"), ("22", "Price Observation", "Source Dataset")]),
            ("Overrides by Reason",
             "Count of Price Override rows and the absolute difference between Override Price Value and the Observed Price Value "
             "of the overridden version's Selected Observation, as a percent of the observed value, by Price Override Reason, "
             "Override Approval Status and asset class.",
             [("22", "Price Override", "Overridden Approved Price"), ("22", "Price Override", "Override Sequence"),
              ("22", "Price Override", "Override Price Value"), ("22", "Price Override", "Price Override Reason"),
              ("22", "Price Override", "Override Approval Status"), ("22", "Approved Price", "Selected Observation"),
              ("22", "Price Observation", "Observed Price Value"), ("17", "Instrument", "Asset Class")]),
            ("Unapproved Overrides Applied",
             "Count of current Approved Price versions with Approved Price Basis = Price Override and Price Approval Status = "
             "Approved whose Applied Price Override is null or resolves to a Price Override with Override Approval Status not in "
             "(Approved, Approved with Conditions).",
             [("22", "Approved Price", "Approved Price Basis"), ("22", "Approved Price", "Applied Price Override"),
              ("22", "Approved Price", "Price Approval Status"), ("22", "Price Override", "Override Approval Status")]),
            ("Override Four-Eyes Exceptions",
             "Count of Price Override rows with Override Approval Status = Approved where Override Approved By equals Override "
             "Requested By.",
             [("22", "Price Override", "Override Approved By"), ("22", "Price Override", "Override Requested By"),
              ("22", "Price Override", "Override Approval Status")]),
            ("Challenges Raised and Open",
             "Count of Price Challenges by Challenged Vendor (party, from DP-240), Price Challenge Reason and month of Challenge "
             "Raised Date; open challenges are those with Price Challenge Status not in (Resolved / Completed, Closed, Rejected, "
             "Canceled), aged in business days since Challenge Raised Date.",
             [("22", "Price Challenge", "Price Challenge ID"), ("22", "Price Challenge", "Challenged Vendor"),
              ("22", "Price Challenge", "Price Challenge Reason"), ("22", "Price Challenge", "Challenge Raised Date"),
              ("22", "Price Challenge", "Price Challenge Status")]),
            ("Vendor Revision Rate",
             "Price Challenges with Price Challenge Outcome = Vendor Price Revised / Price Challenges with an outcome other than "
             "Challenge Withdrawn, by Challenged Vendor and the Source Dataset of the Challenged Observation; also the share with "
             "Approved Price Changed Indicator = Y.",
             [("22", "Price Challenge", "Price Challenge Outcome"), ("22", "Price Challenge", "Challenged Vendor"),
              ("22", "Price Challenge", "Challenged Observation"), ("22", "Price Challenge", "Approved Price Changed Indicator"),
              ("22", "Price Observation", "Source Dataset"), "Challenges Raised and Open"]),
            ("Primary Source Usage %",
             "Current approved prices with Approved Price Basis = Selected Observation whose Selected Observation's Source Dataset "
             "equals the Ranked Source Dataset of the effective Pricing Source Hierarchy Rule with the lowest Source Rank for the "
             "instrument's scope (Hierarchy Pricing Point, Hierarchy Scope Asset Class and Hierarchy Scope Instrument Type matched "
             "to the instrument's Asset Class and Instrument Type) / all current approved prices with Approved Price Basis = "
             "Selected Observation; the remainder is the fallback share, shown by Source Rank used.",
             [("22", "Approved Price", "Approved Price Basis"), ("22", "Approved Price", "Selected Observation"),
              ("22", "Approved Price", "Approved Pricing Point"), ("22", "Price Observation", "Source Dataset"),
              ("22", "Pricing Source Hierarchy Rule", "Hierarchy Pricing Point"), ("22", "Pricing Source Hierarchy Rule", "Hierarchy Scope Asset Class"),
              ("22", "Pricing Source Hierarchy Rule", "Hierarchy Scope Instrument Type"), ("22", "Pricing Source Hierarchy Rule", "Source Rank"),
              ("22", "Pricing Source Hierarchy Rule", "Ranked Source Dataset"), ("22", "Pricing Source Hierarchy Rule", "Hierarchy Rule Effective From"),
              ("22", "Pricing Source Hierarchy Rule", "Hierarchy Rule Effective To"), ("17", "Instrument", "Asset Class"),
              ("17", "Instrument", "Instrument Type")]),
            ("Instruments Without Tolerance Rule",
             "Count of instruments with a current approved price on the price date whose Asset Class and Instrument Type match no "
             "Price Tolerance Rule effective on that date (Tolerance Rule Effective From on or before it, Tolerance Rule Effective "
             "To null or after it) under a Pricing Policy version with Policy Approval Status = Approved, by asset class.",
             [("22", "Price Tolerance Rule", "Tolerance Scope Asset Class"), ("22", "Price Tolerance Rule", "Tolerance Scope Instrument Type"),
              ("22", "Price Tolerance Rule", "Tolerance Rule Effective From"), ("22", "Price Tolerance Rule", "Tolerance Rule Effective To"),
              ("22", "Price Tolerance Rule", "Tolerance Policy Code"), ("22", "Pricing Policy", "Pricing Policy Code"),
              ("22", "Pricing Policy", "Policy Approval Status"), ("22", "Approved Price", "Priced Instrument"),
              ("17", "Instrument", "Asset Class"), ("17", "Instrument", "Instrument Type")]),
        ],
        inputs=[
            ("22", "Pricing Policy", ["Pricing Policy Code", "Pricing Policy Version", "Valuation Regulatory Frameworks",
                                      "Pricing Operating Model", "Outsourced Pricing Provider", "Policy Approval Status",
                                      "Policy Effective From", "Policy Effective To"]),
            ("22", "Pricing Source Hierarchy Rule", ["Hierarchy Rule Code", "Hierarchy Policy Code", "Hierarchy Pricing Point",
                                                     "Hierarchy Scope Asset Class", "Hierarchy Scope Instrument Type", "Source Rank",
                                                     "Ranked Source Dataset", "Ranked Data Provider", "Ranked Price Origin",
                                                     "Ranked Price Type", "Hierarchy Rule Effective From", "Hierarchy Rule Effective To"]),
            ("22", "Price Tolerance Rule", ["Tolerance Rule Code", "Tolerance Policy Code", "Tolerance Scope Asset Class",
                                            "Tolerance Scope Instrument Type", "Tolerance Check Type", "Tolerance Threshold",
                                            "Tolerance Threshold Unit", "Exception Severity Assigned", "Cataloged Data Quality Rule",
                                            "Tolerance Rule Effective From", "Tolerance Rule Effective To"]),
            ("22", "Pricing Point", ["Pricing Point Code", "Pricing Point Purpose", "Snap Time", "Pricing Calendar", "Pricing Point Status"]),
            ("22", "Price Observation", ["Price Observation Key", "Observed Instrument", "Observed Price Type", "Observation Price Origin",
                                         "Source Dataset", "Observation As-Of Timestamp", "Observation Date", "Observed Price Value",
                                         "Observed Price Currency", "Observation Status"]),
            ("22", "Evaluated Price Detail", ["Evaluation Method", "Evaluation Lot Size Basis"]),
            ("22", "Broker Quote Detail", ["Quoting Broker", "Firm Quote Indicator", "Quote Evidence Reference"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date",
                                      "Approved Price Version", "Approved Price Value", "Approved Price Basis",
                                      "Approved Price Fair Value Level", "Selected Observation", "Underlying Market Date",
                                      "Applied Price Override", "Price Approval Status", "Price Approved By", "Price Approval Timestamp"]),
            ("22", "Price Validation Exception", ["Exception Approved Price", "Breached Tolerance Rule", "Exception Raised Timestamp",
                                                  "Measured Variance", "Exception Workflow Status", "Exception Resolution",
                                                  "Resolution Comment", "Exception Resolved By", "Resulting Price Challenge"]),
            ("22", "Price Override", ["Overridden Approved Price", "Override Sequence", "Override Price Value", "Price Override Reason",
                                      "Override Justification", "Override Requested By", "Override Approval Status", "Override Approved By"]),
            ("22", "Price Challenge", ["Price Challenge ID", "Challenged Observation", "Challenged Vendor", "Price Challenge Reason",
                                       "Proposed Price Value", "Challenge Raised By", "Challenge Raised Date", "Price Challenge Outcome",
                                       "Price Challenge Status", "Related Vendor Data Issue", "Approved Price Changed Indicator"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor"]),
        ],
        upstream=["DP-143", "DP-044", "DP-097", "DP-192", "DP-240", "DP-013"],
        refresh="Intraday",
        timeliness=("Exceptions within 15 minutes of each pricing point's Snap Time; the pre-strike exception queue refreshed every "
                    "15 minutes until the price approval window closes (assumed 5:30pm ET for the US fund NAV valuation point); "
                    "the daily control summary by 7pm ET on the price date"),
        history=("Every exception, override and challenge kept with its full status history for at least six years (Rule 2a-5 "
                 "records under Rule 31a-4); daily control summaries kept as locked snapshots; policy, hierarchy and tolerance "
                 "rules effective-dated (SCD type 2)"),
        classification="Confidential - Licensed",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Price Validation Exception references an existing Approved Price version and a Price Tolerance Rule effective on its Price Date.",
            "Every current Approved Price with Approved Price Basis = Price Override has Applied Price Override filled.",
            "Override Approved By is never equal to Override Requested By on a Price Override with Override Approval Status = Approved.",
            "Every Price Validation Exception with Exception Resolution = Challenged with Vendor has Resulting Price Challenge filled, and that challenge's Challenged Observation resolves to a Price Observation of the same instrument.",
            "Exception Resolved By and Exception Resolution are filled whenever Exception Workflow Status is Resolved / Completed or Closed.",
            "Exactly one Pricing Policy version with Policy Approval Status = Approved is effective on each price date for each Pricing Policy Code in use.",
        ],
        notes=("Consumer-aligned control product of 22 (CD-171: price challenges and validation exceptions are mastered in 22; "
               "dataset-level vendor problems stay 14 Vendor Data Issue and are carried only as Related Vendor Data Issue). "
               "Certified numbers: none. The approved price, its basis and fair value level are DP-143's (CD-167); this product "
               "reads them to tie each control fact to the price it affected and never republishes DP-143's own control counts "
               "(Stale Prices, Overridden and Carried-Forward Share, Level 3 Without Approved Determination). Vendor datasets and "
               "their entitlements come from DP-044 (14 Dataset); vendors and quoting brokers are 02 parties from DP-240; "
               "approvers, requesters and exception owners from DP-192 (PII = Y for that reason); pricing calendars from DP-013. "
               "Price Approved By is read here although DP-143 does not publish it, because it is the evidence of who approved a "
               "price with an open exception. "
               "Operating model (CD-297): drafted in house. Pricing Policy 'Pricing Operating Model' and 'Outsourced Pricing "
               "Provider' record the model. If pricing is outsourced to a fund administrator, the grain becomes the provider's "
               "daily exception, override and challenge report checked against the firm's policy, hierarchy and tolerance rules; "
               "the measures are unchanged and sliced by provider. The provider's SLA results are 28 service results published by "
               "DP-176 Fund Service Provider Oversight (CD-333), not here. "
               "Boundary: DP-168 NAV Oversight & Release Control says price exception clearance is read through DP-143, but "
               "DP-143 does not publish exceptions; DP-168 should take 'Approved With Open Exception' and open exceptions from this "
               "product (change for the Fund Operations group). DP-149 holds fair value governance; an exception resolved as "
               "Referred for Fair Value continues there. "
               "Taxonomy gap: Price Validation Exception has no resolved timestamp, so time to resolve is not measurable; open "
               "exceptions are aged from Exception Raised Timestamp only. "
               "Taxonomy gap: Price Challenge has no closed or vendor response date, so vendor turnaround cannot be measured. "
               "Taxonomy gap: Price Override has no request or approval timestamp; 'approved before the price' is inferred from "
               "the price's Price Approval Timestamp. "
               "Open SME questions (22 Source_Notes §5): which platform holds approved prices and whether pricing is outsourced for "
               "any business line (Q1); which pricing points exist (Q3); how OTC derivative marks relate to 26 margin disputes "
               "(Q12); which rules set the fair value level where no determination exists (Q14). Thresholds (15-minute refresh, "
               "5:30pm ET approval window, age buckets) are drafting assumptions. Rests on CD-167, CD-171, CD-297, CD-321."),
    ),

    "DP-149": dict(
        definition=("The valuation designee's record under SEC Rule 2a-5 (and 12 CFR 9.18 for the CITs): valuation committees, "
                    "their membership and meetings, every fair value determination (FVD-) with its method, inputs, triggers and "
                    "factors, and back-tests of approved prices and determinations against later "
                    "market prices and sales. It answers which holdings are fair valued, how, by whom, under which approved "
                    "model, and how well the marks held up, and it is the source the fund board's valuation reporting reads. "
                    "The approved fair value amount itself is published by DP-143; this product holds the governance and evidence "
                    "around it and owns no certified number."),
        business_questions=[
            "Which holdings of each fund are fair valued today, by which method and hierarchy level, and what share of the fund's portfolio market value do they represent?",
            "Which determinations were applied before the valuation committee approved them, or approved at a meeting without quorum?",
            "How well did our fair values hold up against the next market price or the realized sale, by method, valuation agent and asset class?",
            "Were fair value factors applied only on days when a trigger event breached its threshold, and were triggers missed?",
            "Which Level 3 marks rest on unobservable inputs outside their stated range or on a valuation model without an approving validation?",
            "Is each valuation committee independent of portfolio management, as Rule 2a-5 requires?",
        ],
        grain=("Fair value determination (FVD-: instrument x valuation date x pricing point x portfolio) with its valuation inputs "
               "and back-tests; fund x valuation date summary of fair-valued holdings; valuation committee meeting and membership "
               "(committee x employee x effective period) as companion facts"),
        dimensions=["Valuation date and pricing point", "Fund (through DP-140) and portfolio", "Instrument, instrument type and asset class",
                    "Fair value method and fair value hierarchy level", "Determination reason and trigger event type",
                    "Valuation committee and meeting", "External valuation agent", "Valuation model (DP-212)",
                    "Back-test comparison type"],
        measures=[
            ("Fair Valued Holdings",
             "Count and sum of Market Value Base of End of Day Portfolio Holdings whose Held Instrument has a current Approved "
             "Price with Price Approval Status = Approved for the Holding Date at the fund's valuation pricing point and Approved "
             "Price Basis in (Fair Value Determination, Fair Value Factor), rolled to the fund through the effective Portfolio "
             "Implementation Link of type Implements Product (DP-140), by Fair Value Method of the Applied Fair Value "
             "Determination and asset class.",
             [("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"),
              ("18", "Portfolio Holding", "Holding Date"), ("18", "Portfolio Holding", "Holding View"),
              ("18", "Holding Valuation", "Market Value Base"), ("22", "Approved Price", "Priced Instrument"),
              ("22", "Approved Price", "Price Date"), ("22", "Approved Price", "Approved Pricing Point"),
              ("22", "Approved Price", "Approved Price Basis"), ("22", "Approved Price", "Price Approval Status"),
              ("22", "Approved Price", "Applied Fair Value Determination"), ("22", "Fair Value Determination", "Fair Value Method"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"), ("18", "Portfolio Implementation Link", "Implementation Link Type"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("18", "Portfolio Implementation Link", "Implementation Effective From"),
              ("18", "Portfolio Implementation Link", "Implementation Effective To"), ("17", "Instrument", "Asset Class")]),
            ("Fair Valued Share of Portfolio Market Value",
             "Fair Valued Holdings market value / Total IBOR Market Value of the End of Day Portfolio Valuation Summary of the same "
             "portfolios and date (Portfolio Market Value (IBOR), from DP-142); never labeled AUM or net assets. Board reports "
             "that need a percent of net assets take the denominator from DP-165 in the board product.",
             [("18", "Portfolio Valuation Summary", "Valued Portfolio"), ("18", "Portfolio Valuation Summary", "Valuation As-Of Date"),
              ("18", "Portfolio Valuation Summary", "Valuation View"), ("18", "Portfolio Valuation Summary", "Total IBOR Market Value"),
              "Fair Valued Holdings"]),
            ("Level 3 Share of Portfolio Market Value",
             "Market Value Base of End of Day holdings whose current approved price has Approved Price Fair Value Level = Level 3 "
             "/ Total IBOR Market Value of the same portfolios and date, by fund.",
             [("22", "Approved Price", "Approved Price Fair Value Level"), ("18", "Holding Valuation", "Market Value Base"),
              ("18", "Portfolio Valuation Summary", "Total IBOR Market Value")]),
            ("Determinations Applied Before Approval",
             "Count of current approved prices with Applied Fair Value Determination filled whose determination has Determination "
             "Approval Status in (Pending, Retrospectively Approved, Rejected) on the Price Date; Retrospectively Approved rows are "
             "the ratifications the board report discloses.",
             [("22", "Approved Price", "Applied Fair Value Determination"), ("22", "Approved Price", "Price Date"),
              ("22", "Fair Value Determination", "Fair Value Determination ID"), ("22", "Fair Value Determination", "Determination Approval Status")]),
            ("Approvals Without Quorate Meeting",
             "Count of Fair Value Determinations with Determination Approval Status in (Approved, Approved with Conditions, "
             "Retrospectively Approved) whose Approving Meeting is null or resolves to a Valuation Committee Meeting with Quorum "
             "Met Indicator = N.",
             [("22", "Fair Value Determination", "Approving Meeting"), ("22", "Fair Value Determination", "Determination Approval Status"),
              ("22", "Valuation Committee Meeting", "Meeting Committee"), ("22", "Valuation Committee Meeting", "Meeting Date"),
              ("22", "Valuation Committee Meeting", "Quorum Met Indicator")]),
            ("Back-Test Pass Rate",
             "Valuation Back-Tests with Within Tolerance Indicator = Y / all Valuation Back-Tests in the period, with the mean of "
             "absolute Back-Test Variance, by Back-Test Comparison Type, the Fair Value Method and External Valuation Agent of the "
             "Back-Tested Determination (blank for prices without a determination) and asset class.",
             [("22", "Valuation Back-Test", "Back-Tested Approved Price"), ("22", "Valuation Back-Test", "Back-Tested Determination"),
              ("22", "Valuation Back-Test", "Back-Test Comparison Type"), ("22", "Valuation Back-Test", "Comparison Date"),
              ("22", "Valuation Back-Test", "Back-Test Variance"), ("22", "Valuation Back-Test", "Within Tolerance Indicator"),
              ("22", "Fair Value Determination", "Fair Value Method"), ("22", "Fair Value Determination", "External Valuation Agent")]),
            ("Factors Applied Without Trigger",
             "Count of current approved prices with Approved Price Basis = Fair Value Factor whose Applied Fair Value Factor has a "
             "Factor Triggering Event that is null or resolves to a Fair Value Trigger Event with Trigger Threshold Breached "
             "Indicator = N; and, conversely, Missed Triggers: Fair Value Trigger Events with Trigger Threshold Breached Indicator "
             "= Y on whose Trigger Event Date no Fair Value Factor names them for any instrument of the Affected Market.",
             [("22", "Approved Price", "Approved Price Basis"), ("22", "Approved Price", "Applied Fair Value Factor"),
              ("22", "Fair Value Factor", "Fair Value Factor Key"), ("22", "Fair Value Factor", "Factor Triggering Event"),
              ("22", "Fair Value Factor", "Factor Pricing Date"), ("22", "Fair Value Trigger Event", "Trigger Event Key"),
              ("22", "Fair Value Trigger Event", "Trigger Event Date"), ("22", "Fair Value Trigger Event", "Affected Market"),
              ("22", "Fair Value Trigger Event", "Trigger Threshold Breached Indicator")]),
            ("Unobservable Inputs Out of Range",
             "Count of Valuation Inputs with Unobservable Input Indicator = Y whose Input Value is below Input Range Low or above "
             "Input Range High, by Valuation Input Type; and Level 3 determinations with no Valuation Input flagged unobservable.",
             [("22", "Valuation Input", "Input Determination"), ("22", "Valuation Input", "Valuation Input Type"),
              ("22", "Valuation Input", "Unobservable Input Indicator"), ("22", "Valuation Input", "Input Value"),
              ("22", "Valuation Input", "Input Range Low"), ("22", "Valuation Input", "Input Range High"),
              ("22", "Fair Value Determination", "Fair Value Hierarchy Level")]),
            ("Determinations on Unvalidated Models",
             "Count of approved Fair Value Determinations whose Valuation Model Name resolves to a Model Inventory Entry (DP-212) "
             "with no Model Validation of Model Validation Outcome in (Approved, Approved with Conditions) completed on or before "
             "the Valuation Date, or with Model Use Status other than Active.",
             [("22", "Fair Value Determination", "Valuation Model Name"), ("22", "Fair Value Determination", "Determination Approval Status"),
              ("37", "Model Inventory Entry", "Model ID"), ("37", "Model Inventory Entry", "Model Use Status"),
              ("37", "Model Validation", "Validated Model"), ("37", "Model Validation", "Model Validation Outcome"),
              ("37", "Model Validation", "Model Validation Completed Date")]),
            ("Committee Independence Flag",
             "Y for a valuation committee where, on the as-of date, voting members (Voting Member Indicator = Y, effective "
             "membership) with Portfolio Management Function Indicator = Y are half or more of all voting members, or any voting "
             "member's Employment Status (DP-192) is not employed.",
             [("22", "Valuation Committee Member", "Membership Committee"), ("22", "Valuation Committee Member", "Committee Member"),
              ("22", "Valuation Committee Member", "Voting Member Indicator"), ("22", "Valuation Committee Member", "Portfolio Management Function Indicator"),
              ("22", "Valuation Committee Member", "Membership Effective From"), ("22", "Valuation Committee Member", "Membership Effective To"),
              ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status")]),
        ],
        inputs=[
            ("22", "Valuation Committee", ["Valuation Committee Code", "Valuation Committee Name", "Valuation Committee Type",
                                           "Governing Pricing Policy", "Committee Owner Entity", "Committee Status"]),
            ("22", "Valuation Committee Member", ["Membership Committee", "Committee Member", "Voting Member Indicator",
                                                  "Portfolio Management Function Indicator", "Membership Effective From",
                                                  "Membership Effective To"]),
            ("22", "Valuation Committee Meeting", ["Meeting Committee", "Meeting Date", "Quorum Met Indicator", "Minutes Reference"]),
            ("22", "Fair Value Determination", ["Fair Value Determination ID", "Fair Valued Instrument", "Valuation Date",
                                                "Determination Pricing Point", "Valued Portfolio", "Fair Value Determination Reason",
                                                "Triggering Event", "Fair Value Method", "Fair Value Hierarchy Level",
                                                "Fair Value per Unit", "Fair Value Amount", "Fair Value Currency",
                                                "Valuation Model Name", "Valuation Prepared By", "External Valuation Agent",
                                                "Determination Approval Status", "Approving Meeting"]),
            ("22", "Valuation Input", ["Input Determination", "Valuation Input Type", "Unobservable Input Indicator", "Input Value",
                                       "Input Unit", "Input Range Low", "Input Range High"]),
            ("22", "Fair Value Trigger Event", ["Trigger Event Key", "Fair Value Trigger Event Type", "Trigger Event Date",
                                                "Affected Market", "Affected Instrument", "Measured Market Move",
                                                "Move Reference Benchmark", "Trigger Threshold Breached Indicator"]),
            ("22", "Fair Value Factor", ["Fair Value Factor Key", "Factor Instrument", "Factor Pricing Date", "Factor Pricing Point",
                                         "Factor Source Dataset", "Fair Value Factor Value", "Factor Triggering Event"]),
            ("22", "Valuation Back-Test", ["Back-Tested Approved Price", "Back-Tested Determination", "Back-Test Comparison Type",
                                           "Comparison Date", "Comparison Value per Unit", "Comparison Transaction",
                                           "Back-Test Variance", "Within Tolerance Indicator", "Back-Test Reviewed By"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date",
                                      "Approved Price Value", "Approved Price Basis", "Approved Price Fair Value Level",
                                      "Applied Fair Value Determination", "Applied Fair Value Factor", "Price Approval Status"]),
            ("22", "Pricing Policy", ["Pricing Policy Code", "Valuation Regulatory Frameworks", "Pricing Operating Model",
                                      "Policy Approval Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View",
                                         "Holding Quantity"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Total IBOR Market Value"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Private Instrument Indicator"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Use Status"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Completed Date", "Model Validation Outcome"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-143", "DP-142", "DP-140", "DP-097", "DP-192", "DP-212", "DP-240"],
        refresh="Daily",
        timeliness=("Determinations, factors and trigger events by 7pm ET on the valuation date (after the fair value factor "
                    "decision at the 4pm ET valuation point); back-tests by business day 2 after the comparison date; the "
                    "quarterly board extract by business day 10 after quarter-end"),
        history=("Every determination, input, factor, trigger event and back-test kept with its approval status history for at "
                 "least six years (Rule 31a-4 records of Rule 2a-5 determinations); committee membership effective-dated (SCD type 2); "
                 "quarter-end board extracts kept as locked snapshots"),
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every current Approved Price with Approved Price Basis = Fair Value Determination has Applied Fair Value Determination filled, and that determination has the same instrument, Valuation Date equal to the Price Date and the same pricing point.",
            "At most one Fair Value Determination with Determination Approval Status = Approved exists per Fair Valued Instrument x Valuation Date x Determination Pricing Point x Valued Portfolio, and Valued Portfolio is filled for every LP Fund Interest instrument.",
            "Every Fair Value Determination with Fair Value Hierarchy Level = Level 3 has at least one Valuation Input.",
            "Input Range Low is less than or equal to Input Range High on every Valuation Input that has both.",
            "Every Valuation Back-Test with Back-Test Comparison Type = Realized Sale Price has Comparison Transaction filled.",
            "Fair Value Amount equals Fair Value per Unit multiplied by the portfolio's End of Day Holding Quantity of the instrument on the Valuation Date, within one currency unit.",
        ],
        notes=("W4 re-point (CW-930, CW-166): 22 Private Asset Valuation Detail dropped, no successor (it served the 30 private "
               "fund books), with the measure Stale Private Asset Valuations and the 18 Private Fund Portfolio Detail input only "
               "it read; fund interest statements of feeder books are 18 Fund Interest Holding Detail (DP-117 residual). "
               "Consumer-aligned governance product of 22 (CD-170: fair value determinations and the valuation committee are "
               "mastered in 22). Certified numbers: none; the approved fair value amount is published by DP-143 and applied in "
               "the NAV by DP-165 (CD-187). Fair Valued Share and Level 3 Share use Portfolio Market Value (IBOR) from DP-142 as "
               "the denominator; it is not certified and never labeled AUM (CD-320). Fund roll-up only through DP-140's "
               "implementation link (CD-324). Private fund interest values reach 18 through DP-143, not from here. "
               "Board reporting (CD-225, CD-234, CD-237): the Rule 2a-5 board report is a 35 Board Report Received in DP-182 Fund "
               "Board Governance, Reporting & Approvals, which reads this product; board approvals are linked only on 35 "
               "Resolution Subject Link, so this product holds none. "
               "Models (CD-246, CD-294): Valuation Model Name references the 37 model inventory, read through DP-212 Model "
               "Inventory & Validation. External valuation agents and fair value factor vendors resolve through DP-240; committee "
               "members, preparers and reviewers through DP-192 (PII = Y). 20 Employee Employment Status is read only to test "
               "that voting members are still employed. "
               "Operating model (CD-297): Rule 2a-5 keeps the valuation designee (the adviser) responsible even when a fund "
               "administrator calculates prices, so the grain is unchanged under every pricing operating model; an outsourced or "
               "third-party valuation is recorded as External Valuation Agent and the committee's approval is the firm's "
               "oversight evidence. "
               "Boundary: price validation exceptions, overrides and vendor challenges are DP-148; an exception resolved as "
               "'Referred for Fair Value' continues here as a determination. "
               "Taxonomy gap: Fair Value Determination has no approval timestamp, so the time from valuation to committee approval "
               "is not measurable; 'applied before approval' uses the approval status on the price date. "
               "Taxonomy gap: Valuation Committee Meeting records quorum but not attendance by member, so independence is tested "
               "on membership, not on who voted. "
               "Taxonomy gap: Valuation Back-Test holds Within Tolerance Indicator but not the tolerance applied; it is assumed "
               "to be the Price Tolerance Rule of Tolerance Check Type 'Back-Test Variance'. "
               "Open SME questions (22 Source_Notes §5): the valuation designee per fund family and who values the CITs "
               "(Q2); the fair value factor vendor and trigger (Q4); who prepares private asset valuations (Q5). The 92-day "
               "staleness allowance is a drafting assumption. Rests on CD-170, CD-187, CD-225, CD-234, CD-237, CD-246, CD-294, "
               "CD-297, CD-320, CD-324. "
               "W1b re-point (CW-922): the AIFMD valuation function and the UCITS and AIF valuers left the definition and the SME "
               "question (Valuation Committee Type values AIFM Valuation Function and ManCo Valuation Committee removed); no input "
               "changed."),
    ),

    # ========================================== 18 Portfolio & Investment Book of Record ==========================================
    "DP-150": dict(
        definition=("The control view of the investment book of record: whether each portfolio's start-of-day snapshot was "
                    "locked on time and reconciled, the manual position and cost adjustments with their approvals, back-dated "
                    "and amended bookings into locked periods, the start-of-day roll and cash tie-outs, and the daily difference "
                    "between IBOR portfolio market value and the fund accounting book. It drives investment operations' exception "
                    "queue and evidences that portfolio managers trade on a controlled start-of-day position. It reads 18 Position "
                    "Adjustment, which DP-142 deliberately does not publish, and takes portfolios, transactions and holdings from "
                    "DP-140 to DP-142; it owns no certified number."),
        business_questions=[
            "Which portfolios did not have a locked, reconciled start-of-day snapshot by their cutoff time this morning, and why?",
            "Which manual position and cost adjustments were made, for what reason, and which are unapproved or were approved by the person who booked them?",
            "Which back-dated bookings changed a period whose snapshot was already locked, and was the snapshot restated?",
            "Where does today's start-of-day position not roll from yesterday's end-of-day, and where does the cash on the valuation summary not tie to the cash balances?",
            "How far is each fund's IBOR portfolio market value from the fund accounting book, and for how many days has it been outside tolerance?",
            "For books run by a middle office provider: how do their snapshot timeliness, adjustments and book differences compare with in-house books?",
        ],
        grain=("Portfolio x business date control row (start-of-day snapshot status, roll and cash tie-outs, IBOR to fund book "
               "difference), with position adjustment (portfolio x instrument x adjustment date x adjusting transaction) and "
               "back-dated or amended transaction event (transaction x event type x event timestamp) as companion facts"),
        dimensions=["Business date", "Portfolio, portfolio type and business line (DP-140)", "Fund (through DP-140's implementation link)",
                    "IBOR operating model and middle office provider", "Snapshot type and control status",
                    "Position adjustment reason and approval status", "Event source system", "Instrument and asset class (DP-097)",
                    "Booker and approver (employee)"],
        measures=[
            ("Start-of-Day Snapshot On Time %",
             "Active portfolios (Portfolio Status Active, Closed to New Money or Liquidating; Portfolio Type Standalone Book or "
             "Sleeve) with a Portfolio Position Snapshot of Snapshot Type = Start of Day Official for the business date with "
             "Snapshot Locked Indicator = Y, Snapshot Control Status in (Reconciled, Reconciled within Tolerance) and Snapshot "
             "As-Of Timestamp at or before the portfolio's Start-of-Day Cutoff Time / those active portfolios, by Business Line, "
             "IBOR Operating Model and Middle Office Provider.",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("18", "Portfolio", "Portfolio Type"),
              ("18", "Portfolio", "Business Line"), ("18", "Portfolio", "IBOR Operating Model"), ("18", "Portfolio", "Middle Office Provider"),
              ("18", "Portfolio Position Snapshot", "Snapshot Portfolio"), ("18", "Portfolio Position Snapshot", "Snapshot Type"),
              ("18", "Portfolio Position Snapshot", "Snapshot Business Date"), ("18", "Portfolio Position Snapshot", "Snapshot As-Of Timestamp"),
              ("18", "Portfolio Position Snapshot", "Snapshot Locked Indicator"), ("18", "Portfolio Position Snapshot", "Snapshot Control Status"),
              ("18", "Portfolio Accounting Basis", "Start-of-Day Cutoff Time")]),
            ("Snapshots With Open Breaks",
             "Count of Portfolio Position Snapshots with Snapshot Control Status in (Break Open, Not Reconciled), by Snapshot Type "
             "and business date; and Restated Snapshots: count with Snapshot Restated Indicator = Y.",
             [("18", "Portfolio Position Snapshot", "Snapshot Control Status"), ("18", "Portfolio Position Snapshot", "Snapshot Type"),
              ("18", "Portfolio Position Snapshot", "Snapshot Business Date"), ("18", "Portfolio Position Snapshot", "Snapshot Restated Indicator")]),
            ("Manual Position Adjustments",
             "Count of Position Adjustments, sum of absolute Quantity Adjustment and sum of absolute Cost Adjustment Base, by "
             "Position Adjustment Reason, Adjustment Date, portfolio and asset class of the Adjusted Instrument; the market value "
             "affected is absolute Quantity Adjustment x (Market Value Base / Holding Quantity) of the Adjusted Holding.",
             [("18", "Position Adjustment", "Adjusted Portfolio"), ("18", "Position Adjustment", "Adjusted Instrument"),
              ("18", "Position Adjustment", "Adjusted Holding"), ("18", "Position Adjustment", "Adjustment Date"),
              ("18", "Position Adjustment", "Position Adjustment Reason"), ("18", "Position Adjustment", "Quantity Adjustment"),
              ("18", "Position Adjustment", "Cost Adjustment Base"), ("18", "Portfolio Holding", "Holding ID"),
              ("18", "Portfolio Holding", "Holding Quantity"), ("18", "Holding Valuation", "Market Value Base"),
              ("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Asset Class")]),
            ("Unapproved Adjustments",
             "Count of Position Adjustments with Adjustment Approval Status not in (Approved, Approved with Conditions, "
             "Retrospectively Approved, Not Required) and Adjustment Date on or before the as-of date, by age in business days; "
             "Retrospectively Approved adjustments are reported beside them as a share of all approved adjustments.",
             [("18", "Position Adjustment", "Adjustment Approval Status"), ("18", "Position Adjustment", "Adjustment Date"),
              "Manual Position Adjustments"]),
            ("Adjustment Four-Eyes Exceptions",
             "Count of approved Position Adjustments whose Adjustment Approved By equals the Event Performed By of the Booked "
             "Portfolio Transaction Event of the Adjusting Transaction; and Adjustments Without Booking: Position Adjustments "
             "with Adjusting Transaction null.",
             [("18", "Position Adjustment", "Adjustment Approved By"), ("18", "Position Adjustment", "Adjusting Transaction"),
              ("18", "Position Adjustment", "Adjustment Approval Status"), ("18", "Portfolio Transaction Event", "Event Transaction"),
              ("18", "Portfolio Transaction Event", "Portfolio Transaction Event Type"), ("18", "Portfolio Transaction Event", "Event Performed By")]),
            ("Back-Dated Events Without Restatement",
             "Count of Portfolio Transaction Events with Back-Dated Indicator = Y whose transaction's Trade Date falls on a business "
             "date with a locked End of Day snapshot (Snapshot Locked Indicator = Y) and no snapshot of that portfolio and business "
             "date with Snapshot Restated Indicator = Y and Snapshot As-Of Timestamp after the Event Timestamp, by Event Source "
             "System and Portfolio Transaction Event Type.",
             [("18", "Portfolio Transaction Event", "Back-Dated Indicator"), ("18", "Portfolio Transaction Event", "Event Timestamp"),
              ("18", "Portfolio Transaction Event", "Event Source System"), ("18", "Portfolio Transaction Event", "Event Transaction"),
              ("18", "Portfolio Transaction Event", "Portfolio Transaction Event Type"), ("18", "Portfolio Transaction", "Portfolio Transaction ID"),
              ("18", "Portfolio Transaction", "Transaction Portfolio"), ("18", "Portfolio Transaction", "Trade Date"),
              ("18", "Portfolio Position Snapshot", "Snapshot Locked Indicator"), ("18", "Portfolio Position Snapshot", "Snapshot Restated Indicator"),
              ("18", "Portfolio Position Snapshot", "Snapshot As-Of Timestamp")]),
            ("Start-of-Day Roll Breaks",
             "Count of portfolio x instrument pairs where the Holding Quantity with Holding View = Start of Day on the business "
             "date differs from the Holding Quantity with Holding View = End of Day on the prior business day of the portfolio's "
             "Valuation Calendar, after adding the Quantity Adjustment of Position Adjustments dated the business date and the "
             "Transaction Quantity of transactions booked overnight with that Trade Date.",
             [("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"),
              ("18", "Portfolio Holding", "Holding Date"), ("18", "Portfolio Holding", "Holding View"),
              ("18", "Portfolio Holding", "Holding Quantity"), ("18", "Portfolio Accounting Basis", "Valuation Calendar"),
              ("18", "Position Adjustment", "Quantity Adjustment"), ("18", "Portfolio Transaction", "Transaction Quantity"),
              ("18", "Portfolio Transaction", "Trade Date")]),
            ("Cash Tie-Out Break",
             "Total Cash Balance of the Portfolio Valuation Summary - sum of Balance Amount Base over Cash Balance rows of the "
             "portfolio with Balance Date = Valuation As-Of Date and Cash Balance Type = Trade Date, per portfolio, date and "
             "Valuation View; flagged when the absolute difference exceeds one unit of Base Currency.",
             [("18", "Portfolio Valuation Summary", "Total Cash Balance"), ("18", "Portfolio Valuation Summary", "Valued Portfolio"),
              ("18", "Portfolio Valuation Summary", "Valuation As-Of Date"), ("18", "Portfolio Valuation Summary", "Valuation View"),
              ("18", "Cash Balance", "Cash Balance Portfolio"), ("18", "Cash Balance", "Balance Date"),
              ("18", "Cash Balance", "Cash Balance Type"), ("18", "Cash Balance", "Balance Amount Base"),
              ("18", "Portfolio", "Base Currency")]),
            ("IBOR to Fund Book Difference",
             "For each fund and valuation date: sum of Total IBOR Market Value (Valuation View End of Day, Portfolio Market Value "
             "(IBOR) from DP-142) over the portfolios whose effective Portfolio Implementation Link of type Implements Product "
             "with Primary Implementation Indicator = Y names the fund, excluding sleeves whose parent (Portfolio Hierarchy Link "
             "of type Sleeve Of) is already included, minus the Total Assets Amount of the NAV of record (NAV of Record Flag, from "
             "DP-165) of the fund's Fund Accounting Book for the same Valuation Date; also shown as a percent of Total Assets "
             "Amount. An operational exception measure, not AUM and not a reconciliation of record.",
             [("18", "Portfolio Valuation Summary", "Total IBOR Market Value"), ("18", "Portfolio Valuation Summary", "Valued Portfolio"),
              ("18", "Portfolio Valuation Summary", "Valuation As-Of Date"), ("18", "Portfolio Valuation Summary", "Valuation View"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"), ("18", "Portfolio Implementation Link", "Implementation Link Type"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("18", "Portfolio Implementation Link", "Primary Implementation Indicator"),
              ("18", "Portfolio Implementation Link", "Implementation Effective From"), ("18", "Portfolio Implementation Link", "Implementation Effective To"),
              ("18", "Portfolio Hierarchy Link", "Parent Portfolio"), ("18", "Portfolio Hierarchy Link", "Child Portfolio"),
              ("18", "Portfolio Hierarchy Link", "Portfolio Hierarchy Link Type"), ("27", "Fund Accounting Book", "Book Fund"),
              ("27", "Fund NAV Calculation", "NAV Book"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "NAV Calculation Source"), ("27", "Fund NAV Calculation", "NAV Version Number"),
              ("27", "Fund NAV Calculation", "NAV Approval Status"), ("27", "Fund NAV Calculation", "Total Assets Amount")]),
            ("Book Difference Outside Tolerance",
             "Y when the absolute IBOR to Fund Book Difference exceeds 0.05% of Total Assets Amount; Consecutive Days Outside "
             "Tolerance counts the fund's consecutive valuation dates flagged Y up to the as-of date.",
             [("27", "Fund NAV Calculation", "Total Assets Amount"), "IBOR to Fund Book Difference"]),
        ],
        inputs=[
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status", "Base Currency",
                                 "Book of Record System", "IBOR Operating Model", "Middle Office Provider"]),
            ("18", "Portfolio Accounting Basis", ["Valuation Calendar", "Start-of-Day Cutoff Time"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("18", "Portfolio Hierarchy Link", ["Parent Portfolio", "Child Portfolio", "Portfolio Hierarchy Link Type",
                                                "Hierarchy Effective From", "Hierarchy Effective To"]),
            ("18", "Portfolio Position Snapshot", ["Snapshot Portfolio", "Snapshot Type", "Snapshot Holding View",
                                                   "Snapshot Business Date", "Snapshot As-Of Timestamp", "Snapshot Locked Indicator",
                                                   "Snapshot Control Status", "Snapshot Restated Indicator"]),
            ("18", "Position Adjustment", ["Adjusted Portfolio", "Adjusted Instrument", "Adjusted Holding", "Adjustment Date",
                                           "Position Adjustment Reason", "Quantity Adjustment", "Cost Adjustment Base",
                                           "Adjustment Approval Status", "Adjustment Approved By", "Adjustment Comment",
                                           "Adjusting Transaction"]),
            ("18", "Portfolio Transaction", ["Portfolio Transaction ID", "Transaction Portfolio", "Portfolio Transaction Type",
                                             "Transaction Instrument", "Trade Date", "Transaction Quantity", "Net Amount Base"]),
            ("18", "Portfolio Transaction Event", ["Event Transaction", "Portfolio Transaction Event Type", "Event Timestamp",
                                                   "Amendment Reason", "Rebooked As Transaction", "Event Source System",
                                                   "Event Performed By", "Back-Dated Indicator"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View",
                                         "Holding Quantity"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("18", "Cash Balance", ["Cash Balance Portfolio", "Balance Currency", "Balance Date", "Cash Balance Type",
                                    "Balance Amount Local", "Balance Amount Base"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View",
                                                   "Total Holdings Market Value", "Total Cash Balance", "Total Accrued Income",
                                                   "Total IBOR Market Value", "Summary Data Basis", "Summary Snapshot"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis", "Book Code", "Book Status"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "NAV Status", "Total Assets Amount", "Fund Net Assets Amount", "NAV Approval Status"]),
            ("17", "Instrument", ["Instrument ID", "Asset Class"]),
        ],
        upstream=["DP-140", "DP-141", "DP-142", "DP-165", "DP-192", "DP-097", "DP-211"],
        refresh="Daily",
        timeliness=("Start-of-day control rows by each portfolio's Start-of-Day Cutoff Time (assumed 7am local) on the business "
                    "date; adjustment and back-dated booking facts by 9am ET; the IBOR to fund book difference by 9am ET on T+1, "
                    "once the NAV of record is approved in DP-165"),
        history=("Daily control rows and every adjustment and booking event kept at least seven years (Rule 204-2 books and "
                 "records with margin); snapshot status history kept as it changes; no restatement of a past control row except "
                 "through a restated snapshot"),
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model"],
        dq_rules=[
            "Every Position Adjustment with Adjustment Approval Status in (Approved, Approved with Conditions, Retrospectively Approved) has Adjustment Approved By filled.",
            "Every Position Adjustment has an Adjusting Transaction that resolves to a Portfolio Transaction of the same portfolio and instrument.",
            "Each active portfolio has at most one locked Portfolio Position Snapshot per Snapshot Type and Snapshot Business Date that is not restated.",
            "Total IBOR Market Value equals Total Holdings Market Value + Total Cash Balance + Total Accrued Income on every Portfolio Valuation Summary used in the book difference, within one unit of base currency.",
            "The fund book difference is computed only against a Fund NAV Calculation flagged as NAV of record by DP-165, never a Firm Shadow row.",
            "Every portfolio counted in a fund's book difference has exactly one effective primary Implements Product link on the valuation date.",
        ],
        notes=("Consumer-aligned control product of 18; primary function FN-27. Certified numbers: none. Total IBOR Market Value is "
               "DP-142's 'Portfolio Market Value (IBOR)', uncertified and never labeled AUM (CD-292, CD-320; brief hardest call "
               "1); no AUM measure is added here. The IBOR to fund book difference is an operational exception measure by fund and "
               "date: it is not the Wave E5 Firm AUM Reconciliation (CD-292), not a 27 NAV Control Check (DP-168) and not a "
               "position-level reconciliation: 27 ABOR to IBOR Reconciliation and custody breaks are published by DP-172 (CD-196, "
               "CD-335). The NAV of record and its Total Assets Amount come from DP-165 (CD-330); the fund is reached only through "
               "DP-140's primary implementation link as of the valuation date (CD-324), not through 27 Fund Book Portfolio Link. "
               "Total Assets Amount is used because the IBOR summary carries no liabilities; it is read as held, not certified. "
               "Position Adjustment is read directly from 18 because DP-142 deliberately does not publish it (assignment). "
               "Portfolio Transaction and its events are DP-141's; snapshots, holdings, cash and valuation summaries DP-142's; "
               "Event Source System resolves through DP-211; bookers and approvers through DP-192 (PII = Y). "
               "Operating model (CD-297, CD-147): drafted in house. IBOR Operating Model and Middle Office Provider on the "
               "portfolio are dimensions, so a mixed model is rows, not products (CD-331 logic). If the middle office is "
               "outsourced, DP-140 to DP-142 keep their grain from the provider's IBOR file and this product becomes the oversight "
               "product: the same measures computed on the provider's snapshot, adjustments and bookings, compared with the "
               "firm's own start-of-day expectations; provider SLA results are 28 service results in DP-176 (CD-333). "
               "Taxonomy gap: 18 has no provider break or SLA object for an outsourced middle office (CD-147 expects oversight "
               "data); until one exists provider breaks are measured from the provider's records as above. "
               "Taxonomy gap: Position Adjustment has no requester or created timestamp, so approval latency is not measurable "
               "and four-eyes is tested against the booking event's Event Performed By. "
               "Taxonomy gap: Portfolio Valuation Summary has no receivables, payables or liabilities total, so the fund book "
               "difference compares against Total Assets Amount and unsettled trade receivables and payables appear as "
               "difference. "
               "Open SME questions (18 Source_Notes §4): which platform is the IBOR and whether it also holds the ABOR (Q1); which "
               "functions are outsourced (Q2); whether the valuation summary is used officially (Q10). The 0.05% tolerance and "
               "7am cutoff are drafting assumptions. Rests on CD-145, CD-147, CD-196, CD-292, CD-297, CD-320, CD-324, CD-330, "
               "CD-335."),
    ),

    # ===================================== 26 Trade Operations, Settlement & Collateral =====================================
    "DP-151": dict(
        definition=("Every allocated trade from confirmation and affirmation through settlement instruction, status advices and "
                    "settlement, with confirmation match exceptions, settlement fails, buy-ins and CSDR penalties, measured against "
                    "the settlement cycle and affirmation cut-off of each market. Trade operations works fails and penalty disputes "
                    "from it, and trading, investment operations, fund accounting and custody see which trades will not settle on "
                    "time and why. It keeps trade-level settlement only; custody statements and reconciliations are 28 and ledger "
                    "entries 27. It owns no certified number."),
        business_questions=[
            "Which of yesterday's US allocations were not affirmed by the T+1 affirmation cut-off, by broker, portfolio and confirmation channel?",
            "Which instructions are unmatched or failing today, how much value is at risk, how old are the fails and who is responsible?",
            "What did settlement fails cost us in CSDR penalties and buy-ins this month, how much did the firm absorb, and which appeals are open?",
            "Which counterparties and markets have the worst settlement rate on the intended settlement date?",
            "Which instructions used an SSI that is not active and verified, or were instructed off the market's standard settlement cycle?",
        ],
        grain=("Settlement instruction (SETL-) with its trade confirmation, latest status, fail, buy-in and penalties; status "
               "advice (instruction x status timestamp) and confirmation match exception as companion facts; daily summary at "
               "intended settlement date x market x counterparty x portfolio x settlement type"),
        dimensions=["Trade date and intended settlement date", "Market (country of place of settlement) and settlement cycle",
                    "Settlement counterparty and executing broker (DP-115)", "Portfolio, business line and fund (DP-140)",
                    "Instrument type and asset class (DP-097)", "Settlement type", "Confirmation channel",
                    "Fail reason and responsible party", "Penalty type and calculating CSD", "Operations provider"],
        measures=[
            ("Same-Day Affirmation Rate",
             "Trade Allocations whose Trade Confirmation reached Confirmation Status = Affirmed with Affirmation Timestamp at or "
             "before the Affirmation Cut-Off Time of the effective Settlement Cycle Rule for the market, instrument type and "
             "Settlement Type on the Allocation Trade Date / all Trade Allocations with Allocation Status not canceled for that "
             "trade date, by Executing Broker, Confirmation Channel and market.",
             [("25", "Trade Allocation", "Trade Allocation ID"), ("25", "Trade Allocation", "Allocation Trade Date"),
              ("25", "Trade Allocation", "Allocation Status"), ("25", "Trade Allocation", "Executing Broker"),
              ("26", "Trade Confirmation", "Confirmed Allocation"), ("26", "Trade Confirmation", "Confirmation Status"),
              ("26", "Trade Confirmation", "Affirmation Timestamp"), ("26", "Trade Confirmation", "Confirmation Channel"),
              ("26", "Settlement Cycle Rule", "Cycle Market"), ("26", "Settlement Cycle Rule", "Cycle Instrument Type"),
              ("26", "Settlement Cycle Rule", "Cycle Settlement Type"), ("26", "Settlement Cycle Rule", "Affirmation Cut-Off Time"),
              ("26", "Settlement Cycle Rule", "Cycle Effective From"), ("26", "Settlement Cycle Rule", "Cycle Effective To"),
              ("17", "Instrument", "Instrument Type")]),
            ("Confirmation Match Exceptions",
             "Count of Confirmation Match Exceptions by Mismatched Field and Exception Responsible Party, raised and still open "
             "(Exception Status not in (Resolved / Completed, Closed, Rejected, Canceled)), by Confirmation Channel.",
             [("26", "Confirmation Match Exception", "Exception Confirmation"), ("26", "Confirmation Match Exception", "Mismatched Field"),
              ("26", "Confirmation Match Exception", "Exception Responsible Party"), ("26", "Confirmation Match Exception", "Exception Status"),
              ("26", "Confirmation Match Exception", "Exception Raised Timestamp"), ("26", "Trade Confirmation", "Trade Confirmation ID"),
              ("26", "Trade Confirmation", "Confirmation Channel")]),
            ("Settled on Intended Date %",
             "Settlement Instructions with Intended Settlement Date in the period whose latest Settlement Status Event has Trade "
             "Settlement Status = Settled and Effective Settlement Date on or before Intended Settlement Date / all such "
             "instructions excluding those whose latest status is Canceled; by count and by Settlement Amount, by market, "
             "Settlement Counterparty and Settlement Type.",
             [("26", "Settlement Instruction", "Settlement Instruction ID"), ("26", "Settlement Instruction", "Intended Settlement Date"),
              ("26", "Settlement Instruction", "Settlement Amount"), ("26", "Settlement Instruction", "Settlement Counterparty"),
              ("26", "Settlement Instruction", "Settlement Type"), ("26", "Settlement Instruction", "Instructed Place of Settlement"),
              ("26", "Settlement Status Event", "Status Instruction"), ("26", "Settlement Status Event", "Status Timestamp"),
              ("26", "Settlement Status Event", "Trade Settlement Status"), ("26", "Settlement Status Event", "Effective Settlement Date")]),
            ("Unmatched Before Settlement Date",
             "Count of Settlement Instructions whose latest Settlement Status Event before the start of the Intended Settlement "
             "Date has Matched Indicator = N, by Status Reason and counterparty.",
             [("26", "Settlement Status Event", "Matched Indicator"), ("26", "Settlement Status Event", "Status Reason"),
              ("26", "Settlement Status Event", "Status Timestamp"), ("26", "Settlement Instruction", "Intended Settlement Date")]),
            ("Open Fails and Value at Risk",
             "Count of Settlement Fails with Fail Case Status not in (Resolved / Completed, Closed, Rejected, Canceled), and their "
             "value = Failing Quantity / Settlement Quantity x Settlement Amount of the Failed Instruction, by Fail Reason, Fail "
             "Responsible Party and age in business days since Fail Start Date (settlement calendar of the cycle rule).",
             [("26", "Settlement Fail", "Failed Instruction"), ("26", "Settlement Fail", "Fail Start Date"),
              ("26", "Settlement Fail", "Fail Reason"), ("26", "Settlement Fail", "Fail Responsible Party"),
              ("26", "Settlement Fail", "Failing Quantity"), ("26", "Settlement Fail", "Fail Case Status"),
              ("26", "Settlement Instruction", "Settlement Quantity"), ("26", "Settlement Instruction", "Settlement Amount"),
              ("26", "Settlement Cycle Rule", "Settlement Calendar")]),
            ("Fail Rate",
             "Settlement Instructions with at least one Settlement Fail whose Fail Start Date is in the period / Settlement "
             "Instructions with Intended Settlement Date in the period, by counterparty, market and Fail Responsible Party (own "
             "side versus counterparty).",
             [("26", "Settlement Fail", "Failed Instruction"), ("26", "Settlement Fail", "Fail Start Date"),
              ("26", "Settlement Fail", "Fail Responsible Party"), ("26", "Settlement Instruction", "Intended Settlement Date")]),
            ("Buy-In Cost",
             "Count of Buy-In Notices and sum of Price Differential Amount by Buy-In Basis and month of Buy-In Execution Date.",
             [("26", "Buy-In Notice", "Buy-In Basis"), ("26", "Buy-In Notice", "Buy-In Execution Date"),
              ("26", "Buy-In Notice", "Price Differential Amount")]),
            ("Net Settlement Penalties",
             "Sum of Penalty Amount with Penalty Direction = Outflow minus Penalty Amount with Penalty Direction = Inflow, by "
             "Penalty Type, Penalty Calculating CSD and month of Penalty Date; Penalties Absorbed by Firm is the outflow amount with "
             "Penalty Absorbed by Firm Indicator = Y (the source of the 37 Loss Event Amount copies, CD-244); open appeals are rows "
             "with Penalty Appeal Status open.",
             [("26", "Settlement Penalty", "Settlement Penalty ID"), ("26", "Settlement Penalty", "Penalty Amount"),
              ("26", "Settlement Penalty", "Penalty Direction"), ("26", "Settlement Penalty", "Penalty Type"),
              ("26", "Settlement Penalty", "Penalty Calculating CSD"), ("26", "Settlement Penalty", "Penalty Date"),
              ("26", "Settlement Penalty", "Penalty Absorbed by Firm Indicator"), ("26", "Settlement Penalty", "Penalty Appeal Status")]),
            ("Off-Cycle Instructions",
             "Count of Settlement Instructions of Settlement Type = Trade whose Intended Settlement Date differs from the Allocation "
             "Trade Date plus the Standard Settlement Cycle of the effective Settlement Cycle Rule, counted in business days of its "
             "Settlement Calendar, by market and counterparty.",
             [("26", "Settlement Instruction", "Settlement Type"), ("26", "Settlement Instruction", "Intended Settlement Date"),
              ("26", "Settlement Instruction", "Settled Allocation"), ("25", "Trade Allocation", "Allocation Trade Date"),
              ("26", "Settlement Cycle Rule", "Standard Settlement Cycle"), ("26", "Settlement Cycle Rule", "Settlement Calendar")]),
            ("Instructions With Unverified SSI",
             "Count of Settlement Instructions whose Applied Own SSI or Applied Counterparty SSI resolves to a Standing Settlement "
             "Instruction (DP-147) with SSI Status not Active or SSI Verification Status not Verified on the instruction's Intended "
             "Settlement Date.",
             [("26", "Settlement Instruction", "Applied Own SSI"), ("26", "Settlement Instruction", "Applied Counterparty SSI"),
              ("26", "Standing Settlement Instruction", "SSI ID"), ("26", "Standing Settlement Instruction", "SSI Status"),
              ("26", "Standing Settlement Instruction", "SSI Verification Status")]),
        ],
        inputs=[
            ("26", "Trade Confirmation", ["Trade Confirmation ID", "Confirmed Allocation", "Confirming Party", "Confirmation Channel",
                                          "Confirmation Version", "Confirmation Status", "Confirmed Trade Date",
                                          "Confirmed Settlement Date", "Confirmed Quantity", "Confirmed Net Amount",
                                          "Affirmation Timestamp", "Affirmed By"]),
            ("26", "Confirmation Match Exception", ["Exception Confirmation", "Mismatched Field", "Our Value", "Their Value",
                                                    "Exception Raised Timestamp", "Exception Responsible Party", "Exception Status"]),
            ("26", "Settlement Instruction", ["Settlement Instruction ID", "Settled Allocation", "Settled Portfolio Transaction",
                                              "Settlement Portfolio", "Related AP Order", "Settlement Type", "Against Payment Indicator",
                                              "Settlement Instrument", "Settlement Quantity", "Settlement Amount",
                                              "Intended Settlement Date", "Instructed Place of Settlement", "Applied Own SSI",
                                              "Applied Counterparty SSI", "Settlement Counterparty", "Instruction Message Standard",
                                              "Partial Settlement Allowed Indicator", "Operations Provider"]),
            ("26", "Cash Payment Detail", ["Payment Direction", "Payment Currency", "Payment Amount", "CLS Settlement Indicator"]),
            ("26", "Loan Settlement Detail", ["Loan Trade Date", "Loan Closing Date", "Consents Received Date", "Delayed Compensation Amount"]),
            ("26", "Settlement Status Event", ["Status Instruction", "Status Timestamp", "Instruction Processing Status",
                                               "Matched Indicator", "Trade Settlement Status", "Status Reason",
                                               "Effective Settlement Date", "Confirmed Settled Quantity"]),
            ("26", "Settlement Fail", ["Failed Instruction", "Fail Start Date", "Fail Reason", "Fail Responsible Party",
                                       "Failing Quantity", "Fail Case Status", "Fail Resolution Date"]),
            ("26", "Buy-In Notice", ["Buy-In Basis", "Buy-In Execution Date", "Buy-In Quantity", "Buy-In Price",
                                     "Price Differential Amount"]),
            ("26", "Settlement Penalty", ["Settlement Penalty ID", "Penalized Instruction", "Penalty Type", "Penalty Date",
                                          "Penalty Direction", "Penalty Amount", "Penalty Calculating CSD", "Penalty Appeal Status",
                                          "Penalty Absorbed by Firm Indicator", "Penalty Allocated Portfolio"]),
            ("26", "Settlement Cycle Rule", ["Cycle Market", "Cycle Instrument Type", "Cycle Settlement Type",
                                             "Standard Settlement Cycle", "Allocation Cut-Off Time", "Affirmation Cut-Off Time",
                                             "Settlement Calendar", "Cycle Effective From", "Cycle Effective To"]),
            ("26", "Standing Settlement Instruction", ["SSI ID", "SSI Status", "SSI Verification Status"]),
            ("25", "Trade Allocation", ["Trade Allocation ID", "Allocated Portfolio", "Executing Broker", "Allocated Quantity",
                                        "Allocation Trade Date", "Contractual Settlement Date", "Net Trade Amount", "Allocation Status"]),
            ("18", "Portfolio Transaction", ["Portfolio Transaction ID", "Contractual Settlement Date", "Settlement Confirmed Indicator"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-147", "DP-141", "DP-140", "DP-013", "DP-097", "DP-115", "DP-123", "DP-240"],
        refresh="Intraday",
        timeliness=("Status advices and confirmations within 15 minutes of receipt; the affirmation queue before each market's "
                    "Affirmation Cut-Off Time (9pm ET on trade date for US T+1); fails and penalties by 8am ET on each business "
                    "day; CSDR penalties after each CSD's daily and monthly penalty reports"),
        history=("Every instruction, status advice, confirmation version, fail, buy-in and penalty kept at least seven years "
                 "(Rule 204-2 with margin; CSDR records); daily summary snapshots kept for trend; no overwrite of status history"),
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Settlement Instruction of Settlement Type = Trade has Settled Allocation filled and it resolves to a Trade Allocation in DP-123.",
            "Every Trade Confirmation with Confirmation Status = Affirmed has Affirmation Timestamp filled.",
            "A Settlement Status Event with Trade Settlement Status = Settled has Effective Settlement Date filled and Confirmed Settled Quantity equal to Settlement Quantity unless Partial Settlement Allowed Indicator = Y.",
            "18 Settlement Confirmed Indicator of the Settled Portfolio Transaction is Y exactly when the instruction's latest Trade Settlement Status is Settled (CD-181 row rule a).",
            "Every Settlement Penalty has Penalty Amount greater than zero and a Penalized Instruction that resolves to a Settlement Instruction.",
            "Every Settlement Fail has Fail Start Date on or after the Intended Settlement Date of its Failed Instruction.",
        ],
        notes=("Consumer-aligned operational product of 26 (CD-183: trade-level settlement only; custody statements and "
               "reconciliations are 28 in DP-172, ledger entries 27 in DP-166; sese.024 / MT 548 status advices are 26, semt.002 "
               "/ MT 535 are 28). Certified numbers: none. Trade allocations come from DP-123 Trade Order, Execution & Allocation "
               "Record (25), named upstream here as the candidate asked; Allocated Portfolio is PII for individuals' SMAs. SSIs and "
               "settlement cycle rules are DP-147's; settlement counterparties and brokers are slices of DP-115 (CD-315), CSDs and "
               "confirming parties resolve through DP-240; portfolios through DP-140; calendars through DP-013. 18 Settlement "
               "Confirmed Indicator is a Derived copy of this product's status (CD-181) and is read only to test it; DP-141 takes "
               "its settlement detail from here. ETF in-kind deliveries are instructions of type In-Kind Creation or Redemption "
               "that reference the 29 AP order (CD-200); the AP order itself is DP-179. Penalties the firm absorbs reach 37 as Loss "
               "Event Amount copies (CD-244). Shareholder settlement with intermediaries is DP-178, not here. "
               "Operating model (CD-297): drafted in house. If trade support is outsourced (Settlement Instruction 'Operations "
               "Provider'), the grain becomes the provider's daily confirmation, status, fail and penalty report at the same "
               "instruction grain, sliced by Operations Provider; the provider's SLA results are DP-176's. "
               "Taxonomy gap: Settlement Instruction has no settlement market attribute; the market is taken as the country of "
               "the Instructed Place of Settlement (CSD BIC country code) to join the Settlement Cycle Rule. "
               "Taxonomy gap: Settlement Fail has no failing amount, only Failing Quantity; value at risk is prorated from the "
               "instruction's Settlement Amount. "
               "Taxonomy gap: Trade Confirmation has no received timestamp, so time from trade to confirmation receipt is not "
               "measurable; only affirmation timing is. "
               "Open SME questions (26 Source_Notes §4): matching platforms and outsourced trade support (Q2); whether penalties "
               "are allocated to portfolios or absorbed and whether US fails charges are tracked (Q3); SMA sponsor-custodian "
               "instructions (Q8); flows to outsourced fund accounting and custody (Q11); FX and loan settlement ownership (Q14). "
               "The 15-minute and 8am ET timings are drafting assumptions. Rests on CD-181, CD-183, CD-155, CD-200, CD-244, "
               "CD-297, CD-315."),
    ),

    "DP-152": dict(
        definition=("OTC derivative and repo trades after execution: UTIs, legs, clearing, lifecycle events and scheduled cash "
                    "flows, with every CFTC Part 45 and SEC Regulation SBSR report submitted for the OTC derivatives. It shows "
                    "derivatives operations the live book, the trades awaiting confirmation or clearing and the payments due, and "
                    "shows compliance whether every reportable trade and event was reported on time and accepted by the trade "
                    "repository. It owns no certified number."),
        business_questions=[
            "Which OTC trades are still unconfirmed or pending clearing beyond the regulatory deadline, by counterparty and CCP?",
            "What payments are due on our OTC trades in the next ten business days, and which past payments did not settle?",
            "Which reportable OTC trades and lifecycle events were not reported, reported late or rejected, by regime, trade repository and submitting entity?",
            "Are UTIs carried through clearing and novation, and is every resulting UTI reported?",
            "What is our live repo book by counterparty and agreement, and which repo and OTC trades sit under an agreement that is not active?",
        ],
        grain=("OTC derivative trade (by UTI) or repo trade (by repo trade reference) x as-of date, with legs (trade x leg), lifecycle events (trade x event "
               "date x sequence) and cash flows (trade x leg x payment date x type); derivative trade report (reported trade x "
               "regime x submission timestamp) as a companion fact"),
        dimensions=["Trade date, as-of date and payment date", "Portfolio and fund (DP-140)", "Counterparty (DP-115) and CCP (DP-240)",
                    "Governing trading agreement (DP-147)", "OTC product, asset class and notional currency (DP-097)",
                    "Clearing status", "Lifecycle event type", "Trade report regime, action type and processing status",
                    "Trade repository, reporting counterparty and submitting entity (DP-240)"],
        measures=[
            ("Live OTC Trades and Notional",
             "Count of OTC Derivative Trades with OTC Trade Status = Live and sum of Leg Notional Amount of leg 1 (Leg Number = 1), "
             "by OTC Asset Class and Notional Currency (17 OTC Derivative Product Terms), counterparty and Clearing Status.",
             [("26", "OTC Derivative Trade", "OTC Trade ID"), ("26", "OTC Derivative Trade", "OTC Trade Status"),
              ("26", "OTC Derivative Trade", "OTC Counterparty"), ("26", "OTC Derivative Trade", "OTC Product Instrument"),
              ("26", "OTC Trade Leg", "Leg OTC Trade"), ("26", "OTC Trade Leg", "Leg Number"), ("26", "OTC Trade Leg", "Leg Notional Amount"),
              ("26", "Clearing Detail", "Clearing Status"), ("17", "OTC Derivative Product Terms", "OTC Asset Class"),
              ("17", "OTC Derivative Product Terms", "Notional Currency")]),
            ("Cleared Share",
             "Live OTC trades with Clearing Status = Cleared / Live OTC trades, by OTC Asset Class.",
             [("26", "Clearing Detail", "Clearing Status"), "Live OTC Trades and Notional"]),
            ("Unconfirmed or Uncleared Trades",
             "Count of OTC Derivative Trades with OTC Trade Status = Pending Confirmation, and of trades with Clearing Status in "
             "(Pending Clearing, Rejected by CCP), by business days since OTC Trade Date; flagged beyond one business day (CFTC "
             "23.501 timely confirmation, assumed T+1).",
             [("26", "OTC Derivative Trade", "OTC Trade Status"), ("26", "OTC Derivative Trade", "OTC Trade Date"),
              ("26", "Clearing Detail", "Clearing Status"), ("26", "Clearing Detail", "Central Counterparty")]),
            ("Payments Due",
             "Sum of Cash Flow Amount of OTC Cash Flows with Cash Flow Payment Date in the next ten business days, by Cash Flow "
             "Direction, OTC Cash Flow Type, Notional Currency and portfolio.",
             [("26", "OTC Cash Flow", "Cash Flow OTC Trade"), ("26", "OTC Cash Flow", "Cash Flow Payment Date"),
              ("26", "OTC Cash Flow", "Cash Flow Amount"), ("26", "OTC Cash Flow", "Cash Flow Direction"),
              ("26", "OTC Cash Flow", "OTC Cash Flow Type"), ("17", "OTC Derivative Product Terms", "Notional Currency"),
              ("26", "OTC Derivative Trade", "OTC Portfolio")]),
            ("Unsettled Past Payments",
             "Count and Cash Flow Amount of OTC Cash Flows with Cash Flow Payment Date before the as-of date whose Payment "
             "Settlement Instruction is null or whose latest Settlement Status Event (from DP-151) has Trade Settlement Status other "
             "than Settled.",
             [("26", "OTC Cash Flow", "Cash Flow Payment Date"), ("26", "OTC Cash Flow", "Payment Settlement Instruction"),
              ("26", "OTC Cash Flow", "Cash Flow Amount"), ("26", "Settlement Status Event", "Status Instruction"),
              ("26", "Settlement Status Event", "Status Timestamp"), ("26", "Settlement Status Event", "Trade Settlement Status")]),
            ("Floating Coupons Without Final Fixing",
             "Count of OTC Cash Flows with OTC Cash Flow Type = Floating Leg Coupon and Calculation Period End before the as-of date "
             "whose Rate Fixing Used is null or resolves to a Reference Rate Fixing (DP-143) with Fixing Observation Status other "
             "than Final.",
             [("26", "OTC Cash Flow", "OTC Cash Flow Type"), ("26", "OTC Cash Flow", "Calculation Period End"),
              ("26", "OTC Cash Flow", "Rate Fixing Used"), ("22", "Reference Rate Fixing", "Fixed Reference Rate"),
              ("22", "Reference Rate Fixing", "Fixing Date"), ("22", "Reference Rate Fixing", "Fixing Observation Status")]),
            ("Trades Not Reported",
             "Count of OTC Derivative Trades with OTC Trade Status in (Live, Pending Confirmation) and OTC Trade Date before the "
             "as-of date that have no Derivative Trade Report with Report Action Type = New (NEWT) and Report Processing Status "
             "= Accepted under any Trade Report Regime (CFTC Part 45 or SEC Regulation SBSR). Repo trades are not trade-reported "
             "in the US model (W1b re-point, CW-926).",
             [("26", "OTC Derivative Trade", "OTC Trade Status"), ("26", "OTC Derivative Trade", "OTC Trade Date"),
              ("26", "OTC Derivative Trade", "Unique Transaction Identifier"),
              ("26", "Derivative Trade Report", "Reported OTC Trade"),
              ("26", "Derivative Trade Report", "Report Action Type"), ("26", "Derivative Trade Report", "Report Processing Status"),
              ("26", "Derivative Trade Report", "Trade Report Regime")]),
            ("Late Reports",
             "Derivative Trade Reports whose Report Submission Timestamp date is more than one business day after the reported "
             "event (OTC Trade Date for New, the OTC Event Date of the matching OTC Lifecycle Event for Modification and "
             "Termination actions) / all reports submitted, by Trade Report Regime and Report Submitting Entity; the one-day "
             "deadline is applied to both regimes as a drafting assumption.",
             [("26", "Derivative Trade Report", "Report Submission Timestamp"), ("26", "Derivative Trade Report", "Report Action Type"),
              ("26", "Derivative Trade Report", "Trade Report Regime"), ("26", "Derivative Trade Report", "Report Submitting Entity"),
              ("26", "Derivative Trade Report", "Reported OTC Trade"),
              ("26", "OTC Derivative Trade", "OTC Trade Date"), ("26", "OTC Lifecycle Event", "Event OTC Trade"),
              ("26", "OTC Lifecycle Event", "OTC Event Date")]),
            ("Open Report Rejections",
             "Count of Derivative Trade Reports with Report Processing Status = Rejected for which no later report of the same "
             "Reported UTI and Trade Report Regime has Report Processing Status = Accepted, by Trade Repository and age in business "
             "days; also the Rejection Rate = rejected / submitted reports in the period.",
             [("26", "Derivative Trade Report", "Reported UTI"), ("26", "Derivative Trade Report", "Trade Report Regime"),
              ("26", "Derivative Trade Report", "Report Processing Status"), ("26", "Derivative Trade Report", "Report Submission Timestamp"),
              ("26", "Derivative Trade Report", "Trade Repository")]),
            ("UTI Continuity Breaks",
             "Count of OTC Lifecycle Events of OTC Event Type in (Clearing, Novation) with Resulting UTI filled that have no "
             "accepted Derivative Trade Report with Reported UTI = Resulting UTI; and cleared trades (Clearing Status = Cleared) "
             "with Cleared UTI null.",
             [("26", "OTC Lifecycle Event", "OTC Event Type"), ("26", "OTC Lifecycle Event", "Resulting UTI"),
              ("26", "Derivative Trade Report", "Reported UTI"), ("26", "Derivative Trade Report", "Report Processing Status"),
              ("26", "Clearing Detail", "Clearing Status"), ("26", "Clearing Detail", "Cleared UTI")]),
            ("Live Repo Book",
             "Count of Repo Trades with Repo Status = Live, sum of Repo Purchase Price and Repo Purchase Price-weighted average Repo "
             "Rate, by Reverse Repo Indicator, Repo Counterparty, Tri-Party Agent and Governing Repo Agreement.",
             [("26", "Repo Trade", "Repo Status"), ("26", "Repo Trade", "Repo Purchase Price"), ("26", "Repo Trade", "Repo Rate"),
              ("26", "Repo Trade", "Reverse Repo Indicator"), ("26", "Repo Trade", "Repo Counterparty"),
              ("26", "Repo Trade", "Tri-Party Agent"), ("26", "Repo Trade", "Governing Repo Agreement")]),
            ("Trades Under Inactive Agreements",
             "Count of Live OTC Derivative Trades and Live Repo Trades whose Governing Trading Agreement (Governing Repo Agreement) "
             "resolves to a Trading Agreement (DP-147) with Agreement Status not in (Active, Under Notice of Termination).",
             [("26", "OTC Derivative Trade", "Governing Trading Agreement"), ("26", "Repo Trade", "Governing Repo Agreement"),
              ("26", "Trading Agreement", "Trading Agreement ID"), ("26", "Trading Agreement", "Agreement Status"),
              "Live OTC Trades and Notional", "Live Repo Book"]),
        ],
        inputs=[
            ("26", "OTC Derivative Trade", ["OTC Trade ID", "Unique Transaction Identifier", "OTC Product Instrument", "OTC Portfolio",
                                            "OTC Counterparty", "Governing Trading Agreement", "Source Allocation", "OTC Trade Date",
                                            "OTC Effective Date", "Scheduled Termination Date", "Trade Side", "OTC Trade Status"]),
            ("26", "Clearing Detail", ["Clearing Status", "Central Counterparty", "Clearing Member", "Clearing Agreement", "Cleared UTI"]),
            ("26", "OTC Trade Leg", ["Leg OTC Trade", "Leg Number", "Leg Payer", "Leg Notional Amount", "Leg Fixed Rate",
                                     "Leg Floating Rate Index", "Leg Spread", "Leg Payment Frequency"]),
            ("26", "OTC Lifecycle Event", ["Event OTC Trade", "OTC Event Type", "OTC Event Date", "Event Sequence",
                                           "Notional Change Amount", "Step-In Party", "Resulting UTI"]),
            ("26", "OTC Cash Flow", ["Cash Flow OTC Trade", "Cash Flow Leg Number", "Cash Flow Payment Date", "OTC Cash Flow Type",
                                     "Cash Flow Direction", "Calculation Period Start", "Calculation Period End", "Rate Fixing Used",
                                     "Calculated Floating Rate", "Cash Flow Amount", "Payment Settlement Instruction"]),
            ("26", "Repo Trade", ["Repo Trade Reference", "Repo Portfolio", "Repo Counterparty", "Governing Repo Agreement",
                                  "Reverse Repo Indicator", "Tri-Party Agent", "Repo Purchase Date", "Repo Repurchase Date", "Repo Rate",
                                  "Repo Purchase Price", "Repo Haircut", "Opening Leg Settlement", "Closing Leg Settlement",
                                  "Repo Status"]),
            ("26", "Derivative Trade Report", ["Reported OTC Trade", "Reported UTI", "Trade Report Regime",
                                               "Report Action Type", "Report Event Type", "Reporting Counterparty",
                                               "Report Submitting Entity", "Trade Repository",
                                               "Report Submission Timestamp", "Report Processing Status"]),
            ("26", "Trading Agreement", ["Trading Agreement ID", "Trading Agreement Type", "Agreement Status"]),
            ("26", "Settlement Status Event", ["Status Instruction", "Status Timestamp", "Trade Settlement Status", "Effective Settlement Date"]),
            ("22", "Reference Rate Fixing", ["Fixed Reference Rate", "Fixing Tenor", "Fixing Date", "Fixing Value", "Fixing Observation Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("17", "OTC Derivative Product Terms", ["OTC Asset Class", "OTC Base Product", "Notional Currency"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line"]),
        ],
        upstream=["DP-147", "DP-140", "DP-143", "DP-097", "DP-115", "DP-240", "DP-013", "DP-123", "DP-151"],
        refresh="Daily",
        timeliness=("By 8am ET on T+1, after the prior day's trade repository acknowledgment and rejection files and the CCP "
                    "clearing reports; payment projections for the next ten business days refreshed with it"),
        history=("Trades, legs, lifecycle events and cash flows kept for the life of the trade plus at least five years after "
                 "termination (CFTC 45.2; Regulation SBSR record retention); every report submission and its processing status kept unchanged"),
        classification="Confidential - Financial",
        pii="N",
        delivery=["Dashboard", "Warehouse table", "BI semantic model"],
        dq_rules=[
            "Every OTC Derivative Trade has a Unique Transaction Identifier, and no UTI is shared by two live trades.",
            "Every OTC Derivative Trade and Repo Trade names a Governing Trading Agreement (Governing Repo Agreement) that resolves to a Trading Agreement in DP-147.",
            "Every Derivative Trade Report names a Reported OTC Trade, and its Reported UTI equals that trade's UTI, Cleared UTI or a Resulting UTI of its lifecycle events.",
            "Every OTC Derivative Trade with Clearing Status = Cleared has Central Counterparty and Cleared UTI filled.",
            "Every OTC Cash Flow names a Cash Flow Leg Number that exists as an OTC Trade Leg of the same trade.",
        ],
        notes=("Consumer-aligned regulatory and control product of 26 (CD-184: derivatives and repo trade reports are 26; SEC "
               "Rule 10c-1a securities lending reports are 28; fund filings are 35). Certified numbers: "
               "none. Trading agreements are DP-147's (CD-182); OTC product terms and the UPI are 17, read through DP-097; "
               "counterparties are DP-115 slices (CD-315), CCPs, clearing members, tri-party agents and trade repositories resolve "
               "through DP-240, as do the reporting counterparty and submitting entity; calendars and the firm's legal entities through DP-013; source allocations through DP-123; fixings "
               "through DP-143. DP-151 (consumer) is upstream only for the settlement status of OTC payments; DP-151 does not "
               "depend on this product. DP-153 reads this product for the trades behind each netting set. "
               "PII = N: OTC Portfolio and Repo Portfolio are not personal data in the taxonomy and no employee is read. "
               "Operating model (CD-297): drafted in house. If derivatives operations or regulatory reporting is delegated (Report "
               "Submitting Entity differs from Reporting Counterparty, or the agreement names an Agreement Operations "
               "Provider), the grain becomes the delegate's submission and rejection report at the same report grain; the firm "
               "remains responsible and the measures are unchanged. "
               "Taxonomy gap: which regimes apply to each trade (reporting obligation and counterparty classification) is mastered "
               "in 38 (Corporate B brief) and not keyed to the 26 trade, so 'Trades Not Reported' tests for at least one accepted "
               "report rather than one per required regime; when the 38 obligation record exists it should be joined here "
               "(change for the Corporate B group, likely DP-224). "
               "Taxonomy gap: OTC Cash Flow has no currency; payments are grouped by the 17 Notional Currency, which is wrong for "
               "cross-currency legs. "
               "Taxonomy gap: Derivative Trade Report has no reporting deadline attribute; the one-business-day deadline is a "
               "drafting assumption per regime. "
               "Open SME questions (26 Source_Notes §4): one 26 trade per contract with terms in 17 (Q4); which entities report "
               "under which regimes and whether submission is delegated (Q5); repo and MSFTA usage (Q9). Rests on CD-182, CD-184, "
               "CD-297, CD-315. "
               "W1b re-point (CW-926): Repo Trade.Repo UTI, Derivative Trade Report.Reported Repo Trade and Entity Responsible "
               "for Reporting dropped, no successor (the SFTR and EMIR fields left the US model); 'Trades Not Reported' and "
               "'Late Reports' now cover OTC derivatives only, the repo book stays as an operations view; the regimes read are "
               "CFTC Part 45 and SEC Regulation SBSR; the dimension 'Entity responsible for reporting' and the exactly-one "
               "DQ rule are replaced."),
    ),

    "DP-153": dict(
        definition=("Daily margin calls and disputes, collateral movements and balances, initial margin calculations and "
                    "counterparty exposure after collateral, by trading agreement (netting set), portfolio and counterparty, "
                    "with the termination triggers that could let a counterparty close out a fund. Collateral management decides "
                    "calls, disputes and eligible collateral from it, and risk, trading and investment compliance see net exposure "
                    "to each counterparty. It publishes the 31 Counterparty Exposure master (CD-215) with the 26 collateral it "
                    "copies; utilization and exceedance of counterparty trading limits are DP-154's. It owns no certified number."),
        business_questions=[
            "Which margin calls are open, disputed or past their settlement date today, by counterparty, agreement and margin type?",
            "Are our calls correctly sized under each agreement's threshold, minimum transfer amount, independent amount and rounding?",
            "Is the collateral we hold and post eligible, correctly haircut and within concentration limits, and is uncleared initial margin fully covered?",
            "What is our net exposure to each counterparty after collateral, by portfolio and netting set, as a percent of net assets?",
            "How close is each fund to a NAV decline termination trigger in its ISDA agreements?",
            "Which collateral balances disagree with the counterparty, and do the 18 encumbered quantities tie to the posted collateral?",
        ],
        grain=("Trading agreement (netting set) x source portfolio x valuation date x margin type x collateral direction (margin "
               "call, collateral balance, initial margin calculation); counterparty exposure (counterparty x date x measure x "
               "portfolio x netting set) and collateral movement (agreement x movement reference x value date) as companion facts"),
        dimensions=["Valuation date", "Trading agreement, type and netting set (DP-147)", "Counterparty (DP-115)",
                    "Portfolio and fund (DP-140)", "Margin type and collateral direction", "Collateral type and instrument (DP-097)",
                    "Margin call status and dispute reason", "Counterparty exposure measure and method", "Termination trigger type"],
        measures=[
            ("Margin Calls by Status",
             "Count and sum of Call Amount of Margin Calls by Call Margin Type, Call Collateral Direction and Margin Call Status "
             "for the Call Valuation Date, by agreement counterparty.",
             [("26", "Margin Call", "Margin Call ID"), ("26", "Margin Call", "Call Agreement"), ("26", "Margin Call", "Call Valuation Date"),
              ("26", "Margin Call", "Call Margin Type"), ("26", "Margin Call", "Call Collateral Direction"),
              ("26", "Margin Call", "Call Amount"), ("26", "Margin Call", "Margin Call Status"),
              ("26", "Trading Agreement", "Agreement Counterparty")]),
            ("Calls Past Settlement Date",
             "Count and Agreed Amount (Call Amount where Agreed Amount is null) of Margin Calls with Margin Call Status not in "
             "(Settled, Canceled) and Call Settlement Date before the as-of date.",
             [("26", "Margin Call", "Margin Call Status"), ("26", "Margin Call", "Call Settlement Date"),
              ("26", "Margin Call", "Agreed Amount"), ("26", "Margin Call", "Call Amount")]),
            ("Open Disputes",
             "Count of Margin Calls with Margin Call Status = Disputed or Dispute Status not in (Resolved / Completed, Closed, "
             "Rejected, Canceled), sum of Disputed Amount, and age in business days since Call Valuation Date, by Collateral "
             "Dispute Reason; disputes older than 15 business days are flagged for escalation under firm policy (the threshold mirrors the CFTC swap dealer dispute notice, 17 CFR 23.502, confirm).",
             [("26", "Margin Call", "Margin Call Status"), ("26", "Margin Call", "Call Valuation Date"),
              ("26", "Margin Call Dispute", "Disputed Amount"), ("26", "Margin Call Dispute", "Collateral Dispute Reason"),
              ("26", "Margin Call Dispute", "Dispute Status")]),
            ("Call Recalculation Difference",
             "For variation margin calls: Call Amount - expected call, where expected call = Exposure Amount - Collateral Held "
             "Amount - Threshold Amount (+ Independent Amount where the firm receives it), rounded by Rounding Amount and set to "
             "zero when below Minimum Transfer Amount, using the Credit Support Terms of the Call Agreement, margin type and "
             "direction effective on the Call Valuation Date; flagged when not zero.",
             [("26", "Margin Call", "Call Amount"), ("26", "Margin Call", "Exposure Amount"), ("26", "Margin Call", "Collateral Held Amount"),
              ("26", "Credit Support Terms", "Terms Agreement"), ("26", "Credit Support Terms", "Terms Margin Type"),
              ("26", "Credit Support Terms", "Terms Direction"), ("26", "Credit Support Terms", "Threshold Amount"),
              ("26", "Credit Support Terms", "Minimum Transfer Amount"), ("26", "Credit Support Terms", "Independent Amount"),
              ("26", "Credit Support Terms", "Rounding Amount"), ("26", "Credit Support Terms", "Terms Effective From"),
              ("26", "Credit Support Terms", "Terms Effective To")]),
            ("Collateral Posted and Received",
             "Sum of Collateral Value of Collateral Balances by Balance Direction, Balance Margin Type, Balance Collateral Type, "
             "agreement and Collateral Source Portfolio for the Balance Date.",
             [("26", "Collateral Balance", "Balance Agreement"), ("26", "Collateral Balance", "Collateral Source Portfolio"),
              ("26", "Collateral Balance", "Balance Date"), ("26", "Collateral Balance", "Balance Direction"),
              ("26", "Collateral Balance", "Balance Margin Type"), ("26", "Collateral Balance", "Balance Collateral Type"),
              ("26", "Collateral Balance", "Collateral Value")]),
            ("Ineligible or Mis-Haircut Collateral",
             "Count and Collateral Value of Collateral Balances whose Balance Collateral Type has no Eligible Collateral Schedule "
             "row effective on the Balance Date for the agreement, margin type and direction; and of balances where Collateral "
             "Value differs from Collateral Market Value x (1 - Valuation Haircut - FX Haircut, the FX haircut only where Balance "
             "Currency differs from Credit Support Base Currency) by more than one currency unit.",
             [("26", "Collateral Balance", "Balance Collateral Type"), ("26", "Collateral Balance", "Collateral Market Value"),
              ("26", "Collateral Balance", "Collateral Value"), ("26", "Collateral Balance", "Balance Currency"),
              ("26", "Eligible Collateral Schedule", "Schedule Agreement"), ("26", "Eligible Collateral Schedule", "Schedule Margin Type"),
              ("26", "Eligible Collateral Schedule", "Schedule Direction"), ("26", "Eligible Collateral Schedule", "Eligible Collateral Type"),
              ("26", "Eligible Collateral Schedule", "Valuation Haircut"), ("26", "Eligible Collateral Schedule", "FX Haircut"),
              ("26", "Eligible Collateral Schedule", "Eligibility Effective From"), ("26", "Eligible Collateral Schedule", "Eligibility Effective To"),
              ("26", "Credit Support Terms", "Credit Support Base Currency")]),
            ("Concentration Limit Exceedances",
             "Count of agreement x margin type x direction x collateral type combinations where Collateral Value of that type / "
             "total Collateral Value of the agreement, margin type and direction exceeds the Concentration Limit of the effective "
             "Eligible Collateral Schedule row.",
             [("26", "Eligible Collateral Schedule", "Concentration Limit"), ("26", "Collateral Balance", "Collateral Value"),
              ("26", "Collateral Balance", "Balance Collateral Type"), "Collateral Posted and Received"]),
            ("Initial Margin Shortfall",
             "Per agreement, date and IM Direction: IM Requirement Amount of the Initial Margin Calculation - sum of Collateral "
             "Value of Collateral Balances with Balance Margin Type = Initial Margin in the same direction, floored at zero; "
             "flagged when above zero.",
             [("26", "Initial Margin Calculation", "IM Calculation Agreement"), ("26", "Initial Margin Calculation", "IM Calculation Date"),
              ("26", "Initial Margin Calculation", "IM Direction"), ("26", "Initial Margin Calculation", "IM Requirement Amount"),
              ("26", "Collateral Balance", "Balance Margin Type"), ("26", "Collateral Balance", "Balance Direction"),
              ("26", "Collateral Balance", "Collateral Value")]),
            ("Net Exposure After Collateral",
             "Counterparty Exposure Amount and Counterparty Exposure Percent of Net Assets of Counterparty Exposure rows with "
             "Counterparty Exposure Measure = Net Exposure After Collateral, by Exposure Counterparty, Counterparty Exposure "
             "Portfolio, Netting Set Agreement and Counterparty Exposure Method, as held on the 31 record.",
             [("31", "Counterparty Exposure", "Exposure Counterparty"), ("31", "Counterparty Exposure", "Counterparty Exposure Date"),
              ("31", "Counterparty Exposure", "Counterparty Exposure Measure"), ("31", "Counterparty Exposure", "Counterparty Exposure Portfolio"),
              ("31", "Counterparty Exposure", "Netting Set Agreement"), ("31", "Counterparty Exposure", "Counterparty Exposure Method"),
              ("31", "Counterparty Exposure", "Counterparty Exposure Amount"), ("31", "Counterparty Exposure", "Counterparty Exposure Percent of Net Assets")]),
            ("Collateral Held Tie-Out",
             "Counterparty Exposure Amount of the row with Counterparty Exposure Measure = Collateral Held - sum of Collateral Value "
             "of Collateral Balances with Balance Direction = Received for the same Netting Set Agreement, portfolio and date; "
             "flagged when not zero (CD-215 Derived copy check).",
             [("31", "Counterparty Exposure", "Counterparty Exposure Measure"), ("31", "Counterparty Exposure", "Counterparty Exposure Amount"),
              ("31", "Counterparty Exposure", "Netting Set Agreement"), ("26", "Collateral Balance", "Balance Agreement"),
              ("26", "Collateral Balance", "Balance Direction"), ("26", "Collateral Balance", "Collateral Value")]),
            ("NAV Decline Trigger Headroom",
             "For each effective Termination Event Trigger with Termination Trigger Type = NAV Decline and Trigger Applies To = Our "
             "Side: Trigger Threshold Percentage - (1 - Fund Total Net Assets at the as-of date / Fund Total Net Assets at the as-of "
             "date less Measurement Period Months), both from the NAV of record (from DP-165) of the agreement's Fund Party; "
             "flagged when headroom is below 5 percentage points.",
             [("26", "Termination Event Trigger", "Trigger Agreement"), ("26", "Termination Event Trigger", "Termination Trigger Type"),
              ("26", "Termination Event Trigger", "Trigger Applies To"), ("26", "Termination Event Trigger", "Measurement Period Months"),
              ("26", "Termination Event Trigger", "Trigger Threshold Percentage"), ("26", "Termination Event Trigger", "Trigger Effective From"),
              ("26", "Termination Event Trigger", "Trigger Effective To"), ("26", "Trading Agreement", "Fund Party"),
              ("27", "Fund Accounting Book", "Book Fund"), ("27", "Fund NAV Calculation", "NAV Book"),
              ("27", "Fund NAV Calculation", "Valuation Date"), ("27", "Fund NAV Calculation", "Fund Net Assets Amount"),
              ("27", "Fund NAV Calculation", "NAV Approval Status"), ("27", "Fund NAV Calculation", "NAV Version Number")]),
            ("Counterparty Collateral Breaks",
             "Count and Collateral Value of Collateral Balances with Counterparty Agreement Status in (Break Open, Not Reconciled), "
             "by agreement; and Encumbrance Tie-Out: 18 Encumbered Quantity of each End of Day holding - sum of Balance Quantity of "
             "Collateral Balances with Balance Direction = Posted for the same portfolio, instrument and date (securities lending "
             "on-loan quantity from 28 excluded, CD-181 row rule c), flagged when not zero.",
             [("26", "Collateral Balance", "Counterparty Agreement Status"), ("26", "Collateral Balance", "Collateral Value"),
              ("26", "Collateral Balance", "Balance Quantity"), ("26", "Collateral Balance", "Balance Instrument"),
              ("26", "Collateral Balance", "Collateral Source Portfolio"), ("26", "Collateral Balance", "Balance Date"),
              ("26", "Collateral Balance", "Balance Direction"), ("18", "Portfolio Holding", "Holding Portfolio"),
              ("18", "Portfolio Holding", "Held Instrument"), ("18", "Portfolio Holding", "Holding Date"),
              ("18", "Portfolio Holding", "Holding View"), ("18", "Portfolio Holding", "Encumbered Quantity")]),
        ],
        inputs=[
            ("26", "Margin Call", ["Margin Call ID", "Call Agreement", "Call Valuation Date", "Call Margin Type",
                                   "Call Collateral Direction", "Exposure Amount", "Collateral Held Amount", "Call Amount",
                                   "Agreed Amount", "Margin Call Status", "Call Notification Timestamp", "Call Settlement Date",
                                   "Supporting IM Calculation"]),
            ("26", "Margin Call Dispute", ["Disputed Amount", "Collateral Dispute Reason", "Dispute Status",
                                           "Dispute Resolution Approval Status", "Dispute Resolution Date"]),
            ("26", "Collateral Movement", ["Collateral Movement Reference", "Movement Agreement", "Satisfied Margin Call",
                                           "Related Repo Trade", "Movement Margin Type", "Movement Collateral Direction",
                                           "Movement Direction", "Moved Collateral Type", "Moved Instrument", "Movement Quantity",
                                           "Movement Amount", "Collateral Value Date", "Movement Settlement Instruction"]),
            ("26", "Collateral Balance", ["Balance Agreement", "Collateral Source Portfolio", "Balance Date", "Balance Margin Type",
                                          "Balance Direction", "Balance Collateral Type", "Balance Instrument", "Balance Currency",
                                          "Related Repo Trade", "Balance Quantity", "Valuation Price Record",
                                          "Collateral Market Value", "Collateral Value", "Collateral Holding Account",
                                          "Counterparty Agreement Status"]),
            ("26", "Initial Margin Calculation", ["IM Calculation Agreement", "IM Calculation Date", "IM Direction",
                                                  "IM Calculation Method", "Gross IM Amount", "IM Threshold Used",
                                                  "IM Requirement Amount", "Counterparty IM Amount"]),
            ("31", "Counterparty Exposure", ["Exposure Counterparty", "Counterparty Exposure Date", "Counterparty Exposure Measure",
                                             "Counterparty Exposure Portfolio", "Exposure Trading Entity", "Netting Set Agreement",
                                             "Counterparty Exposure Method", "Counterparty Exposure Amount",
                                             "Counterparty Exposure Percent of Net Assets", "Applicable Trading Limit"]),
            ("26", "Trading Agreement", ["Trading Agreement ID", "Trading Agreement Type", "Parent Agreement", "Fund Party",
                                         "Agreement Counterparty", "Agreement Status"]),
            ("26", "Credit Support Terms", ["Terms Agreement", "Terms Margin Type", "Terms Direction", "Threshold Amount",
                                            "Minimum Transfer Amount", "Independent Amount", "Rounding Amount",
                                            "Credit Support Base Currency", "Valuation Agent", "Call Frequency", "Notification Time",
                                            "Segregation Required Indicator", "Segregation Custodian", "Terms Effective From",
                                            "Terms Effective To"]),
            ("26", "Eligible Collateral Schedule", ["Schedule Agreement", "Schedule Margin Type", "Schedule Direction",
                                                    "Eligible Collateral Type", "Valuation Haircut", "FX Haircut",
                                                    "Concentration Limit", "Eligibility Effective From", "Eligibility Effective To"]),
            ("26", "Termination Event Trigger", ["Trigger Agreement", "Termination Trigger Type", "Trigger Applies To",
                                                 "Measurement Period Months", "Trigger Threshold Percentage", "Rating Threshold",
                                                 "Trigger Effective From", "Trigger Effective To"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Book Status"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "Fund Net Assets Amount", "NAV Approval Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View",
                                         "Encumbered Quantity"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-147", "DP-152", "DP-143", "DP-142", "DP-140", "DP-165", "DP-115", "DP-097", "DP-167", "DP-240"],
        refresh="Daily",
        timeliness=("Calls and balances by each agreement's Notification Time on the valuation date (assumed 10am ET for US "
                    "counterparties); counterparty exposure after collateral and trigger headroom by 9am ET on T+1, once the NAV of "
                    "record is approved"),
        history=("Every call, dispute, movement, balance and IM calculation kept at least seven years and for the life of the "
                 "agreement plus five years; counterparty exposure daily rows kept seven years; no overwrite of call status history"),
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Margin Call, Collateral Balance and Initial Margin Calculation names an agreement that resolves to a Trading Agreement in DP-147 with Agreement Status Active or Under Notice of Termination on the date.",
            "Every Margin Call with Margin Call Status = Disputed has a Margin Call Dispute with Disputed Amount greater than zero.",
            "Every Collateral Balance of a security has Balance Instrument and Valuation Price Record filled, and the price record resolves to an Approved Price in DP-143 for the Balance Date.",
            "Collateral Value is never greater than Collateral Market Value on a Collateral Balance.",
            "Every Counterparty Exposure row with Netting Set Agreement filled has an Exposure Counterparty equal to that agreement's Agreement Counterparty.",
            "Every Collateral Movement that satisfies a call has a Satisfied Margin Call of the same agreement and a Movement Settlement Instruction.",
        ],
        notes=("Consumer-aligned operational product of 26 (primary function FN-29). Certified numbers: none; fund net assets for "
               "the NAV decline trigger are certified in DP-165 (CD-330) and read from it. CD-215: Counterparty Exposure is "
               "mastered in 31 and published here with the 26 collateral it copies (brief hardest call 5); utilization of 25 "
               "Counterparty Trading Limits and their exceedances (RLEX-) are published by DP-154 only, and the prospectus "
               "counterparty concentration limit is a 33 rule (DP-161 to DP-163) that reads Counterparty Exposure from here. "
               "Applicable Trading Limit is carried as a key only. CD-181: 18 Encumbered Quantity and Initial Margin Posted are "
               "derived from these balances; the tie-out checks the first. CD-198: securities lending collateral is 28 (DP-174), "
               "not here. Agreements, credit support terms, eligible collateral and triggers are DP-147's (CD-182); OTC and repo "
               "trades DP-152's; counterparties DP-115's (CD-315); collateral prices DP-143's; holdings DP-142's; collateral "
               "holding accounts DP-167's; segregation custodians and tri-party agents DP-240's. The fund is reached through the "
               "agreement's Fund Party and the 27 book of that fund. PII = Y because Counterparty Exposure Portfolio is personal "
               "data for individuals' SMAs. "
               "Operating model (CD-297): drafted in house. If collateral management is outsourced (tri-party agent, collateral "
               "manager; Agreement Operations Provider in DP-147), the grain becomes the agent's call, dispute and balance report "
               "at the same agreement grain, with the firm's exposure and trigger measures unchanged; agent SLAs are DP-176's. "
               "Taxonomy gap: Margin Call has no currency; call amounts are assumed to be in the Credit Support Base Currency. "
               "Taxonomy gap: Collateral Movement has no settlement status; failing collateral deliveries are seen in DP-151 "
               "through Movement Settlement Instruction. "
               "Taxonomy gap: Termination Event Trigger does not say whether NAV decline is measured on total net assets or NAV "
               "per share, nor whether redemptions are excluded; the measure uses total net assets. "
               "Open SME questions (26 Source_Notes §4): uncleared IM scope and segregation custodians (Q6); in-house or outsourced "
               "collateral management (Q7); how fund-level termination triggers are monitored (Q10); IM allocation basis to 18 (Q13); "
               "31 Source_Notes Q5: whether risk or the collateral team measures counterparty exposure and whether PFE is "
               "computed. The 15-business-day dispute flag and 5-point trigger headroom are drafting assumptions. Rests on CD-181, "
               "CD-182, CD-198, CD-215, CD-297, CD-315, CD-330. "
               "W1b re-point (CW-926, CW-931): the 'Open Disputes' 15-day flag no longer feeds an EMIR dispute report (no EMIR "
               "basis in the US model) and is re-sourced to firm policy mirroring 17 CFR 23.502 (confirm); the UCITS Article 52 "
               "counterparty rule in the notes reads the prospectus counterparty concentration limit (33). No input changed."),
    ),

    # ===================================================== 31 Investment Risk =====================================================
    "DP-154": dict(
        definition=("Every risk limit (RLMT-) and counterparty trading limit with its daily utilization by portfolio, the "
                    "exceedances (RLEX-) raised and their escalation, and the stress scenarios, shocks and results run against "
                    "each portfolio, including climate scenarios. Risk escalates exceedances of appetite from it, portfolio "
                    "managers and trading see headroom, and fund boards receive the exceedance record. It reads ex-ante VaR, "
                    "tracking error and exposures from DP-146 and counterparty exposure from DP-153 and never recalculates them; "
                    "it owns no certified number. An exceedance is never called a breach (CD-223)."),
        business_questions=[
            "Which limits are in warning or exceeded today, by program, portfolio and limit type, and how much headroom is left?",
            "Which exceedances are open, how long have they lasted, who owns them and were hard-limit exceedances escalated?",
            "Did every utilization above its limit raise an exceedance, and does every utilization rest on an approved risk run?",
            "What is each portfolio's loss under each approved stress scenario, and which portfolios missed a required stress run?",
            "How much of each counterparty trading limit is used, and which counterparty limit exceedances need trading's action?",
            "Which exceedances must be reported to the fund board this quarter?",
        ],
        grain=("Risk limit (RLMT-) or 25 counterparty trading limit x portfolio x utilization date, with risk limit exceedance "
               "(RLEX-) and stress test result (scenario version x portfolio x stress test date) as companion facts"),
        dimensions=["Utilization date and stress test date", "Risk limit, limit type and risk program", "Portfolio, fund and business line (DP-140)",
                    "Risk measure, horizon, confidence level and benchmark (DP-146)", "Counterparty (DP-115)",
                    "Stress scenario, type and source", "Exceedance severity, workflow status and escalation body",
                    "Exceedance owner and limit approver (employee)"],
        measures=[
            ("Limit Utilization",
             "Utilization Percent of each Risk Limit Utilization row as held, with Headroom = Limit Threshold (Limit Amount for a "
             "Utilized Counterparty Trading Limit) - Utilization Measured Value; the measured value of a VaR, tracking error or "
             "exposure limit is the certified value from DP-146 and of a counterparty limit the Net Exposure After Collateral from "
             "DP-153.",
             [("31", "Risk Limit Utilization", "Utilized Risk Limit"), ("31", "Risk Limit Utilization", "Utilized Counterparty Trading Limit"),
              ("31", "Risk Limit Utilization", "Utilization Date"), ("31", "Risk Limit Utilization", "Utilized Portfolio"),
              ("31", "Risk Limit Utilization", "Utilization Measured Value"), ("31", "Risk Limit Utilization", "Utilization Percent"),
              ("31", "Risk Limit", "Risk Limit ID"), ("31", "Risk Limit", "Limit Threshold"),
              ("25", "Counterparty Trading Limit", "Limit Amount")]),
            ("Utilization Tie-Out",
             "Utilization Percent - Utilization Measured Value / Limit Threshold (or / Limit Amount), flagged beyond 0.1 percentage "
             "point; and, for limits on a Limited Risk Measure, Utilization Measured Value - Risk Measure Value of the Portfolio "
             "Risk Measure of the same portfolio, measure, horizon, confidence level and benchmark from the approved run for the "
             "Utilization Date (Ex-Ante VaR or Ex-Ante Tracking Error, from DP-146), flagged when not zero.",
             [("31", "Risk Limit Utilization", "Utilization Percent"), ("31", "Risk Limit Utilization", "Utilization Measured Value"),
              ("31", "Risk Limit", "Limit Threshold"), ("25", "Counterparty Trading Limit", "Limit Amount"),
              ("31", "Risk Limit", "Limited Risk Measure"), ("31", "Risk Limit", "Limit Horizon Days"),
              ("31", "Risk Limit", "Limit Confidence Level"), ("31", "Risk Limit", "Limit Benchmark"),
              ("31", "Portfolio Risk Measure", "Measure Calculation Run"), ("31", "Portfolio Risk Measure", "Measured Portfolio"),
              ("31", "Portfolio Risk Measure", "Risk Measure"), ("31", "Portfolio Risk Measure", "Risk Horizon Days"),
              ("31", "Portfolio Risk Measure", "Confidence Level"), ("31", "Portfolio Risk Measure", "Measure Benchmark"),
              ("31", "Portfolio Risk Measure", "Risk Measure Value"), ("31", "Risk Calculation Run", "Run As-Of Date"),
              ("31", "Risk Calculation Run", "Run Approval Status")]),
            ("Limits in Warning",
             "Count of Risk Limit Utilization rows with Utilization Measured Value at or above Warning Threshold and below Limit "
             "Threshold (Utilization RAG Status = Amber), by Limit Risk Program, Risk Limit Type and Business Line.",
             [("31", "Risk Limit Utilization", "Utilization RAG Status"), ("31", "Risk Limit Utilization", "Utilization Measured Value"),
              ("31", "Risk Limit", "Warning Threshold"), ("31", "Risk Limit", "Limit Threshold"), ("31", "Risk Limit", "Limit Risk Program"),
              ("31", "Risk Limit", "Risk Limit Type"), ("18", "Portfolio", "Business Line")]),
            ("Open Exceedances",
             "Count of Risk Limit Exceedances with Exceedance Workflow Status not in (Resolved / Completed, Closed, Rejected, "
             "Canceled), by Exceedance Severity, Risk Limit Type and Limit Risk Program of the Exceeded Risk Limit (or "
             "'Counterparty Trading Limit' where Exceeded Counterparty Trading Limit is filled), with Exceedance Duration = business "
             "days from Exceedance Start Date to Exceedance End Date, or to the as-of date while open.",
             [("31", "Risk Limit Exceedance", "Risk Limit Exceedance ID"), ("31", "Risk Limit Exceedance", "Exceeded Risk Limit"),
              ("31", "Risk Limit Exceedance", "Exceeded Counterparty Trading Limit"), ("31", "Risk Limit Exceedance", "Exceedance Start Date"),
              ("31", "Risk Limit Exceedance", "Exceedance End Date"), ("31", "Risk Limit Exceedance", "Exceedance Severity"),
              ("31", "Risk Limit Exceedance", "Exceedance Workflow Status"), ("31", "Risk Limit", "Risk Limit Type"),
              ("31", "Risk Limit", "Limit Risk Program")]),
            ("Hard Limit Exceedances Not Escalated",
             "Count of Risk Limit Exceedances on limits with Risk Limit Type = Hard whose Escalated To is null, or whose Exceedance "
             "Owner is null, at the end of the Exceedance Start Date.",
             [("31", "Risk Limit Exceedance", "Escalated To"), ("31", "Risk Limit Exceedance", "Exceedance Owner"),
              ("31", "Risk Limit Exceedance", "Exceeded Risk Limit"), ("31", "Risk Limit", "Risk Limit Type")]),
            ("Undetected Exceedances",
             "Count of Risk Limit Utilization rows on Hard or Soft limits with Utilization Measured Value above Limit Threshold (or "
             "Limit Amount) for which no Risk Limit Exceedance has Triggering Utilization = the row, or covers the Utilization "
             "Date for the same limit and portfolio (Exceedance Start Date on or before it, Exceedance End Date null or on or after "
             "it).",
             [("31", "Risk Limit Utilization", "Utilization Measured Value"), ("31", "Risk Limit Utilization", "Utilization Date"),
              ("31", "Risk Limit", "Limit Threshold"), ("31", "Risk Limit", "Risk Limit Type"), ("25", "Counterparty Trading Limit", "Limit Amount"),
              ("31", "Risk Limit Exceedance", "Triggering Utilization"), ("31", "Risk Limit Exceedance", "Exceedance Portfolio"),
              ("31", "Risk Limit Exceedance", "Exceedance Start Date"), ("31", "Risk Limit Exceedance", "Exceedance End Date")]),
            ("Board-Reportable Exceedances",
             "Count of Risk Limit Exceedances with Board Reporting Required Indicator = Y whose Exceedance Start Date or open period "
             "falls in the quarter, by fund (Limited Fund, or the fund of the Exceedance Portfolio through DP-140), with the count "
             "flagged Form N-RN Trigger Indicator = Y.",
             [("31", "Risk Limit Exceedance", "Board Reporting Required Indicator"), ("31", "Risk Limit Exceedance", "Form N-RN Trigger Indicator"),
              ("31", "Risk Limit Exceedance", "Exceedance Start Date"), ("31", "Risk Limit Exceedance", "Exceedance Portfolio"),
              ("31", "Risk Limit", "Limited Fund"), ("18", "Portfolio Implementation Link", "Implementing Portfolio"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("18", "Portfolio Implementation Link", "Implementation Link Type"),
              ("18", "Portfolio Implementation Link", "Implementation Effective From"), ("18", "Portfolio Implementation Link", "Implementation Effective To")]),
            ("Stress Loss by Scenario",
             "Stress P&L Impact and Stress Impact Percent of Net Assets per Stress Test Result, by scenario, Stress Scenario Type "
             "and portfolio; Worst Stress Loss is the most negative Stress Impact Percent of Net Assets per portfolio and stress "
             "test date across approved scenarios.",
             [("31", "Stress Test Result", "Result Scenario"), ("31", "Stress Test Result", "Stressed Portfolio"),
              ("31", "Stress Test Result", "Stress Test Date"), ("31", "Stress Test Result", "Stress P&L Impact"),
              ("31", "Stress Test Result", "Stress Impact Percent of Net Assets"), ("31", "Stress Scenario", "Stress Scenario ID"),
              ("31", "Stress Scenario", "Stress Scenario Type"), ("31", "Stress Scenario", "Scenario Approval Status")]),
            ("Stress Coverage %",
             "Active portfolios that have a Stress Test Result for every Stress Scenario version with Scenario Status = Active and "
             "Scenario Approval Status = Approved within the period set by its Stress Test Frequency / active portfolios in scope; "
             "results on scenarios not approved are counted separately as Unapproved Scenario Runs.",
             [("31", "Stress Scenario", "Stress Scenario Version"), ("31", "Stress Scenario", "Scenario Status"),
              ("31", "Stress Scenario", "Scenario Approval Status"), ("31", "Stress Scenario", "Stress Test Frequency"),
              ("31", "Stress Test Result", "Result Scenario"), ("31", "Stress Test Result", "Stressed Portfolio"),
              ("31", "Stress Test Result", "Stress Test Date"), ("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status")]),
            ("Climate Results Without Current Metric",
             "Count of Stress Test Results on scenarios with Stress Scenario Type in (Climate Transition, Climate Physical) whose "
             "Climate Metric Input is null or resolves to a Portfolio Sustainability Metric (DP-135) with Metric Period End Date "
             "more than 15 months before the Stress Test Date.",
             [("31", "Stress Scenario", "Stress Scenario Type"), ("31", "Stress Test Result", "Climate Metric Input"),
              ("31", "Stress Test Result", "Stress Test Date"), ("34", "Portfolio Sustainability Metric", "Metric Portfolio"),
              ("34", "Portfolio Sustainability Metric", "Metric Indicator"), ("34", "Portfolio Sustainability Metric", "Metric Period End Date")]),
        ],
        inputs=[
            ("31", "Risk Limit", ["Risk Limit ID", "Risk Limit Name", "Limit Risk Program", "Limited Program Test Measure",
                                  "Limited Risk Measure", "Limited Exposure Measure", "Limit Horizon Days", "Limit Confidence Level",
                                  "Limit Benchmark", "Limit Stress Scenario", "Limit Exposure Dimension", "Limit Exposure Bucket",
                                  "Limited Fund", "Limited Portfolio", "Limited Strategy", "Limit Business Lines", "Limit Threshold",
                                  "Warning Threshold", "Limit Threshold Unit", "Risk Limit Type", "Limit Setting Entity",
                                  "Limit Approved By", "Risk Limit Status", "Limit Effective From", "Limit Effective To"]),
            ("31", "Risk Limit Utilization", ["Utilized Risk Limit", "Utilized Counterparty Trading Limit", "Utilization Date",
                                              "Utilized Portfolio", "Utilization Measured Value", "Source Measure Record",
                                              "Utilization Percent", "Utilization RAG Status"]),
            ("31", "Risk Limit Exceedance", ["Risk Limit Exceedance ID", "Exceeded Risk Limit", "Exceeded Counterparty Trading Limit",
                                             "Exceedance Portfolio", "Triggering Utilization", "Exceedance Start Date",
                                             "Exceedance End Date", "Exceedance Severity", "Exceedance Cause",
                                             "Exceedance Workflow Status", "Escalated To", "Board Reporting Required Indicator",
                                             "Form N-RN Trigger Indicator", "Exceedance Resolution", "Exceedance Owner"]),
            ("31", "Stress Scenario", ["Stress Scenario ID", "Stress Scenario Version", "Stress Scenario Name", "Stress Scenario Type",
                                       "Stress Scenario Source", "Stress Test Frequency", "Climate Scenario Pathway",
                                       "Scenario Approval Status", "Scenario Status", "Scenario Effective From", "Scenario Effective To"]),
            ("31", "Stress Scenario Shock", ["Shock Scenario", "Shocked Risk Factor", "Shocked Curve", "Shocked Index", "Shock Tenor",
                                             "Shock Size", "Shock Unit"]),
            ("31", "Stress Test Result", ["Result Scenario", "Stressed Portfolio", "Stress Test Date", "Stress Test Program",
                                          "Stress Calculation Run", "Stress P&L Impact", "Stress Impact Percent of Net Assets",
                                          "Climate Metric Input"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Horizon Days",
                                              "Confidence Level", "Measure Benchmark", "Risk Measure Value"]),
            ("31", "Risk Calculation Run", ["Run As-Of Date", "Risk Run Status", "Run Approval Status"]),
            ("31", "Portfolio Exposure", ["Exposure Portfolio", "Exposure As-Of Date", "Exposure Dimension", "Exposure Bucket",
                                          "Exposure Measure", "Exposure Value", "Exposure Percent of Net Assets"]),
            ("31", "Counterparty Exposure", ["Exposure Counterparty", "Counterparty Exposure Date", "Counterparty Exposure Measure",
                                             "Counterparty Exposure Portfolio", "Counterparty Exposure Amount", "Applicable Trading Limit"]),
            ("25", "Counterparty Trading Limit", ["Limit Counterparty", "Limit Type", "Limit Trading Entity", "Limit Fund",
                                                  "Limit Amount", "Limit Effective From", "Limit Effective To"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Status", "Business Line"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("34", "Portfolio Sustainability Metric", ["Metric Portfolio", "Metric Indicator", "Metric Period End Date", "Metric Value"]),
        ],
        upstream=["DP-146", "DP-153", "DP-140", "DP-192", "DP-115", "DP-004", "DP-135"],
        refresh="Daily",
        timeliness=("By 9am ET on T+1, after DP-146's approved risk run and DP-153's counterparty exposure; exceedances raised the "
                    "same morning; stress results by the business day after each scheduled stress run; the quarterly board extract "
                    "by business day 10 after quarter-end"),
        history=("Limits and scenarios effective-dated (SCD type 2); daily utilization and stress results kept at least seven "
                 "years; every exceedance kept with its workflow history for at least seven years and never deleted"),
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Risk Limit Utilization row names exactly one of Utilized Risk Limit and Utilized Counterparty Trading Limit, and the limit is effective on the Utilization Date.",
            "Every Risk Limit Exceedance names exactly one of Exceeded Risk Limit and Exceeded Counterparty Trading Limit, and Exceedance End Date is null or on or after Exceedance Start Date.",
            "Utilization rows of limits on a Limited Risk Measure rest only on Portfolio Risk Measures of a Risk Calculation Run with Run Approval Status = Approved.",
            "Every Risk Limit with Risk Limit Status = Active has Limit Threshold, Limit Threshold Unit and Limit Approved By filled, and Warning Threshold, when filled, is below Limit Threshold for upper limits.",
            "Every Stress Test Result references a Stress Scenario version effective on the Stress Test Date.",
            "No Risk Limit Exceedance is labeled or exported as a 'breach'; the term is reserved for 33 Investment Breach (DP-163).",
        ],
        notes=("Consumer-aligned regulatory and control product of 31 (primary function FN-30). Certified numbers: none. Ex-ante "
               "VaR and tracking error are certified only in DP-146 and are read from it (CD-320); the utilization tie-out checks "
               "that each limit used the certified value from an approved run. CD-223: risk-program limits and their exceedances "
               "(RLMT-, RLEX-) are 31 and published here; coded investment restrictions and their breaches are 33 (DP-161, "
               "DP-163); 'breach' is never used for an RLEX-. CD-215: utilization and exceedance of 25 counterparty trading limits "
               "are 31 rows published here; the limit itself is DP-115's and counterparty exposure DP-153's. CD-214: statutory VaR "
               "test limits are Risk Limits held here; the fund VaR test results are DP-155's, which reads these exceedance rows "
               "for program context (brief §6 item 4). CD-244: an exceedance is not an operational incident unless it causes a "
               "loss. CD-216: climate scenarios read 34 Portfolio Sustainability Metric from DP-135 and never copy it. CD-225, "
               "CD-234, CD-237: 35 reports RLEX- to the board through DP-182 and holds the approvals; this product holds none. "
               "Funds, strategies and benchmarks resolve through DP-004; portfolios and fund roll-up through DP-140 (CD-324); "
               "limit approvers and exceedance owners through DP-192 (PII = Y, also for Utilized Portfolio and Stressed Portfolio "
               "of individuals' SMAs). Stress runs reference Risk Calculation Runs whose models are inventoried in DP-212 through "
               "DP-146 (CD-294); no score is produced here. "
               "Operating model: in house, possibly on a vendor engine; a vendor engine changes the run's source dataset, not the "
               "grain. "
               "Taxonomy gap: Risk Limit Exceedance has no escalation date or board-reported date, so escalation timeliness is "
               "tested only on the start date. "
               "Taxonomy gap: Risk Limit Utilization 'Source Measure Record' is free text, not a reference, so the tie-out to the "
               "approved Portfolio Risk Measure joins on portfolio, measure, horizon, confidence level, benchmark and date. "
               "Taxonomy gap: Stress Test Result has no approval or review status. "
               "Open SME questions (31 Source_Notes §4): which body approves limits and which are hard (Q4); who owns climate "
               "scenarios (Q7); whether risk or trading escalates counterparty limit exceedances (Q9); whether utilization should "
               "keep the measured value (Q10). The 0.1-point tie-out and 15-month metric age are drafting assumptions. Rests on "
               "CD-214, CD-215, CD-216, CD-223, CD-225, CD-234, CD-237, CD-244, CD-294, CD-320, CD-324."),
    ),

    "DP-155": dict(
        definition=("The fund-level results of the liquidity and derivatives risk programs: Rule 22e-4 liquidity classifications, "
                    "highly liquid investment minimums (HLIM) and fund liquidity profiles, liquidity stress tests and horizon "
                    "buckets, Rule 18f-4 designated reference portfolios and VaR tests, derivatives exposure and Section 18 asset coverage, "
                    "with the program designations and the program exceedances. Program administrators and the derivatives risk "
                    "manager act on it, and N-PORT, N-RN, N-CEN and Form PF take their values from it. It is the "
                    "only publisher of the certified Rule 22e-4 liquidity classification family (percent of net assets by "
                    "liquidity category, illiquid percent and HLIM shortfall, CD-320); fund VaR and tracking error remain DP-146's."),
        business_questions=[
            "What percent of each fund's net assets is highly liquid, moderately liquid, less liquid and illiquid today, and is any fund above the 15% illiquid limit?",
            "Which funds are below their HLIM, for how many consecutive days, and which shortfalls must go to the board?",
            "Is every holding of each fund's whole book classified, how many classifications were overridden, and on what basis?",
            "Which funds failed their Rule 18f-4 VaR test, for how many business days, and is each fund's VaR the certified value from the approved risk run?",
            "What is each fund's derivatives exposure or Section 18 asset coverage as a percent of net assets, and does the net asset figure tie to the NAV of record?",
            "Which in-scope funds lack a program designation, an approved HLIM or an approved designated reference portfolio?",
        ],
        grain=("Fund x measurement date x program result (fund liquidity profile; liquidity horizon bucket; VaR test regime; "
               "exposure method), with liquidity classification (fund x instrument x classification date x portion) and program "
               "designation, HLIM and designated reference portfolio (fund x effective period) as companion facts"),
        dimensions=["Measurement date and month-end filing date", "Fund, vehicle type and regulatory regime (DP-004)",
                    "Risk program type and regulator", "Liquidity category and classification basis", "Liquidity horizon bucket",
                    "VaR test regime and designated reference index", "Exposure method", "Instrument and asset class (DP-097)",
                    "Program administrator and risk lead (employee)"],
        measures=[
            ("Liquidity Category Percent of Net Assets",
             "Certified (CD-320): Highly Liquid Percent, Moderately Liquid Percent, Less Liquid Percent and Illiquid Percent of "
             "the Fund Liquidity Profile for the fund and Profile Measurement Date, as held on the 31 record; the denominator "
             "Profile Net Assets is the fund's net assets of the NAV of record (from DP-165). Published only by this product.",
             [("31", "Fund Liquidity Profile", "Profile Fund"), ("31", "Fund Liquidity Profile", "Profile Measurement Date"),
              ("31", "Fund Liquidity Profile", "Highly Liquid Percent"), ("31", "Fund Liquidity Profile", "Moderately Liquid Percent"),
              ("31", "Fund Liquidity Profile", "Less Liquid Percent"), ("31", "Fund Liquidity Profile", "Illiquid Percent"),
              ("31", "Fund Liquidity Profile", "Profile Net Assets")]),
            ("Liquidity Profile Tie-Out",
             "Per fund, date and Liquidity Category: the category percent of the profile - sum over Liquidity Classification rows "
             "of the fund and Classification Date in that category of Portion Percent of Position x Market Value Base of the "
             "End of Day holdings of the Classified Instrument in every portfolio implementing the fund (DP-140 Implements Product "
             "links effective on the date, sleeves rolled to their parent) / Profile Net Assets; flagged beyond 0.1 percentage "
             "point. Also flags profiles whose four category percents do not sum to 100% within 0.1 point.",
             [("31", "Liquidity Classification", "Classified Fund"), ("31", "Liquidity Classification", "Classified Instrument"),
              ("31", "Liquidity Classification", "Classification Date"), ("31", "Liquidity Classification", "Classification Portion Number"),
              ("31", "Liquidity Classification", "Liquidity Category"), ("31", "Liquidity Classification", "Portion Percent of Position"),
              ("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"),
              ("18", "Portfolio Holding", "Holding Date"), ("18", "Portfolio Holding", "Holding View"),
              ("18", "Holding Valuation", "Market Value Base"), ("18", "Portfolio Implementation Link", "Implementing Portfolio"),
              ("18", "Portfolio Implementation Link", "Implementation Link Type"), ("18", "Portfolio Implementation Link", "Implemented Product"),
              ("18", "Portfolio Implementation Link", "Implementation Effective From"), ("18", "Portfolio Implementation Link", "Implementation Effective To"),
              ("18", "Portfolio Hierarchy Link", "Parent Portfolio"), ("18", "Portfolio Hierarchy Link", "Child Portfolio"),
              ("31", "Fund Liquidity Profile", "Profile Net Assets"), "Liquidity Category Percent of Net Assets"]),
            ("Illiquid Limit Exceedance Flag",
             "Y when Illiquid Percent exceeds the Limit Threshold of the fund's active Risk Limit with Limit Risk Program = Liquidity "
             "Risk Management Program (Rule 22e-4) and Limited Program Test Measure = Illiquid Investments Percent (15% for "
             "registered open-end funds); the exceedance record itself is DP-154's RLEX- with Form N-RN Trigger Indicator.",
             [("31", "Fund Liquidity Profile", "Illiquid Percent"), ("31", "Risk Limit", "Risk Limit ID"),
              ("31", "Risk Limit", "Limit Risk Program"), ("31", "Risk Limit", "Limited Program Test Measure"),
              ("31", "Risk Limit", "Limited Fund"), ("31", "Risk Limit", "Limit Threshold"), "Liquidity Category Percent of Net Assets"]),
            ("HLIM Shortfall",
             "Certified (CD-320): Y when the fund's Highly Liquid Percent, after deducting Highly Liquid Margin Adjustment / Profile "
             "Net Assets, is below the HLIM Percent of the Applied HLIM effective on the date (HLIM Shortfall Indicator, checked "
             "against this formula), with Consecutive HLIM Shortfall Days; Board Notification Due is Y when the shortfall has "
             "lasted more than 7 consecutive calendar days.",
             [("31", "Fund Liquidity Profile", "Highly Liquid Percent"), ("31", "Fund Liquidity Profile", "Highly Liquid Margin Adjustment"),
              ("31", "Fund Liquidity Profile", "Profile Net Assets"), ("31", "Fund Liquidity Profile", "Applied HLIM"),
              ("31", "Fund Liquidity Profile", "HLIM Shortfall Indicator"), ("31", "Fund Liquidity Profile", "Consecutive HLIM Shortfall Days"),
              ("31", "Highly Liquid Investment Minimum", "HLIM Fund"), ("31", "Highly Liquid Investment Minimum", "HLIM Percent"),
              ("31", "Highly Liquid Investment Minimum", "HLIM Effective From"), ("31", "Highly Liquid Investment Minimum", "HLIM Effective To")]),
            ("Classification Coverage %",
             "End of Day holdings (Market Value Base not zero) of the fund's whole book whose instrument has Liquidity "
             "Classification rows for the fund and latest Classification Date whose Portion Percent of Position sums to 100% / all "
             "such holdings, by fund; Classification Overrides is the count of rows with Classification Override Reason filled, by "
             "Liquidity Classification Basis.",
             [("31", "Liquidity Classification", "Portion Percent of Position"), ("31", "Liquidity Classification", "Classification Override Reason"),
              ("31", "Liquidity Classification", "Liquidity Classification Basis"), ("31", "Liquidity Classification", "Classified Instrument"),
              ("18", "Portfolio Holding", "Held Instrument"), ("18", "Holding Valuation", "Market Value Base")]),
            ("Liquidity Stress Coverage",
             "Liquidity Coverage Ratio and Days to Meet Redemptions of the latest Stress Test Result with Stress Test Program = "
             "Liquidity Risk Management Program (Rule 22e-4) for each fund's portfolios; flagged "
             "when Liquidity Coverage Ratio is below 1 or Days to Meet Redemptions exceeds the fund's redemption settlement period "
             "(assumed 7 days).",
             [("31", "Stress Test Result", "Stressed Portfolio"), ("31", "Stress Test Result", "Stress Test Date"),
              ("31", "Stress Test Result", "Stress Test Program"), ("31", "Liquidity Stress Detail", "Liquidity Coverage Ratio"),
              ("31", "Liquidity Stress Detail", "Days to Meet Redemptions"), ("31", "Liquidity Stress Detail", "Redemption Shock Percent")]),
            ("VaR Test Failures",
             "Count of funds with VaR Test Pass Indicator = N on the test date, by VaR Test Regime, with Consecutive Business Days Out "
             "of Compliance; Board and N-RN Reporting Due is Y when the fund has been out of compliance for more than 5 business "
             "days under a Rule 18f-4 regime.",
             [("31", "VaR Test Result", "VaR Test Fund"), ("31", "VaR Test Result", "VaR Test Date"), ("31", "VaR Test Result", "VaR Test Regime"),
              ("31", "VaR Test Result", "VaR Test Pass Indicator"), ("31", "VaR Test Result", "Consecutive Business Days Out of Compliance")]),
            ("VaR Test Tie-Out",
             "For relative regimes: VaR Test Value - Risk Measure Value of the Fund VaR Measure / Reference Portfolio VaR; for "
             "absolute regimes: VaR Test Value - Risk Measure Value of the Fund VaR Measure; and the Fund VaR Measure must be a "
             "Portfolio Risk Measure of a Risk Calculation Run with Run Approval Status = Approved and Run As-Of Date = VaR Test "
             "Date (certified Ex-Ante VaR, from DP-146). Flagged when the difference exceeds 0.01 percentage point or the run is "
             "not approved.",
             [("31", "VaR Test Result", "VaR Test Value"), ("31", "VaR Test Result", "Fund VaR Measure"),
              ("31", "VaR Test Result", "Reference Portfolio VaR"), ("31", "VaR Test Result", "VaR Test Regime"),
              ("31", "VaR Test Result", "VaR Test Date"), ("31", "Portfolio Risk Measure", "Measure Calculation Run"),
              ("31", "Portfolio Risk Measure", "Risk Measure Value"), ("31", "Risk Calculation Run", "Run As-Of Date"),
              ("31", "Risk Calculation Run", "Run Approval Status")]),
            ("Leverage and Exposure Percent of Net Assets",
             "Leverage Percent of Net Assets of each Leverage & Exposure Measurement by Exposure Method, with Net Assets Tie-Out = "
             "Net Assets Used - Fund Total Net Assets of the NAV of record (from DP-165) referenced by Net Assets Source NAV, "
             "flagged when not zero, and Leverage Tie-Out = Leverage Percent of Net Assets - Measured Exposure Amount / Net Assets "
             "Used, flagged beyond 0.01 percentage point.",
             [("31", "Leverage & Exposure Measurement", "Measured Fund"), ("31", "Leverage & Exposure Measurement", "Leverage Measurement Date"),
              ("31", "Leverage & Exposure Measurement", "Exposure Method"), ("31", "Leverage & Exposure Measurement", "Measured Exposure Amount"),
              ("31", "Leverage & Exposure Measurement", "Net Assets Used"), ("31", "Leverage & Exposure Measurement", "Net Assets Source NAV"),
              ("31", "Leverage & Exposure Measurement", "Leverage Percent of Net Assets"), ("27", "Fund NAV Calculation", "Fund Net Assets Amount"),
              ("27", "Fund NAV Calculation", "NAV Approval Status")]),
            ("Program Designation Gaps",
             "Count of funds with Vehicle Type in (Open-Ended Fund, Exchange-Traded Fund, Closed-End Fund, Interval Fund) and "
             "Regulatory Regime = US 1940 Act Registered with no Risk Program Designation of type Liquidity Risk Management Program "
             "(Rule 22e-4) effective on the as-of date (In-Kind ETF Exemption Indicator noted); funds whose Derivatives Usage is "
             "filled with neither a Derivatives Risk Management Program nor Limited Derivatives User Policies designation; funds "
             "under a relative VaR regime with no Designated Reference Portfolio of DRP Approval Status = Approved; and funds with "
             "no approved HLIM or HLIM Last Review Date older than 12 months.",
             [("31", "Risk Program Designation", "Program Fund"), ("31", "Risk Program Designation", "Risk Program Type"),
              ("31", "Risk Program Designation", "Program Effective From"), ("31", "Risk Program Designation", "Program Effective To"),
              ("31", "Risk Program Designation", "In-Kind ETF Exemption Indicator"), ("01", "Investment Product", "Product ID"),
              ("01", "Investment Product", "Vehicle Type"), ("01", "Fund Legal Structure", "Regulatory Regime"),
              ("01", "Investment Objective & Policy", "Derivatives Usage"), ("31", "Designated Reference Portfolio", "DRP Fund"),
              ("31", "Designated Reference Portfolio", "Applicable VaR Test Regime"), ("31", "Designated Reference Portfolio", "DRP Approval Status"),
              ("31", "Highly Liquid Investment Minimum", "HLIM Approval Status"), ("31", "Highly Liquid Investment Minimum", "HLIM Last Review Date")]),
            ("Program Exceedances",
             "Count of Risk Limit Exceedances (from DP-154) on limits of a fund program (Limit Risk Program in the 22e-4, 18f-4 "
             "and Rule 2a-7 program types) open or started in the period, by fund and program, with the count flagged Form N-RN "
             "Trigger Indicator = Y.",
             [("31", "Risk Limit Exceedance", "Risk Limit Exceedance ID"), ("31", "Risk Limit Exceedance", "Exceeded Risk Limit"),
              ("31", "Risk Limit Exceedance", "Exceedance Start Date"), ("31", "Risk Limit Exceedance", "Exceedance End Date"),
              ("31", "Risk Limit Exceedance", "Form N-RN Trigger Indicator"), ("31", "Risk Limit", "Limit Risk Program"),
              ("31", "Risk Limit", "Limited Fund")]),
        ],
        inputs=[
            ("31", "Risk Program Designation", ["Program Fund", "Risk Program Type", "Program Regulator", "Program Effective From",
                                                "Program Effective To", "In-Kind ETF Exemption Indicator",
                                                "Administrator Appointment", "Program Risk Lead"]),
            ("31", "Liquidity Classification", ["Classified Fund", "Classified Instrument", "Classification Date",
                                                "Classification Portion Number", "Liquidity Category", "Portion Percent of Position",
                                                "Days to Cash", "Reasonably Anticipated Trade Size", "Liquidity Classification Basis",
                                                "Classification Data Basis", "Liquidity Data Source Dataset",
                                                "Supporting Fair Value Determination", "Classification Override Reason",
                                                "Model Inventory Entry"]),
            ("31", "Highly Liquid Investment Minimum", ["HLIM Fund", "HLIM Percent", "Primarily Highly Liquid Indicator",
                                                        "HLIM Effective From", "HLIM Effective To", "HLIM Approval Status",
                                                        "HLIM Last Review Date"]),
            ("31", "Fund Liquidity Profile", ["Profile Fund", "Profile Measurement Date", "Profile Net Assets", "Highly Liquid Percent",
                                              "Highly Liquid Margin Adjustment", "Moderately Liquid Percent", "Less Liquid Percent",
                                              "Illiquid Percent", "Applied HLIM", "HLIM Shortfall Indicator",
                                              "Consecutive HLIM Shortfall Days", "Own ETF Market Statistic"]),
            ("31", "Liquidity Horizon Bucket", ["Bucket Fund", "Bucket Measurement Date", "Liquidity Horizon Bucket",
                                                "Portfolio Percent Liquidatable", "Investor Liquidity Percent",
                                                "Bucket Feeder Access Terms", "Bucket Data Basis"]),
            ("31", "Stress Test Result", ["Result Scenario", "Stressed Portfolio", "Stress Test Date", "Stress Test Program",
                                          "Stress Impact Percent of Net Assets"]),
            ("31", "Liquidity Stress Detail", ["Redemption Shock Percent", "Stressed Liquidity Horizon Days", "Liquid Assets Available",
                                               "Liquidity Coverage Ratio", "Days to Meet Redemptions", "Model Inventory Entry"]),
            ("31", "Designated Reference Portfolio", ["DRP Fund", "Applicable VaR Test Regime", "Designated Reference Index",
                                                      "Reference Securities Portfolio", "DRP Effective From", "DRP Effective To",
                                                      "DRP Approval Status"]),
            ("31", "VaR Test Result", ["VaR Test Fund", "VaR Test Date", "VaR Test Regime", "Fund VaR Measure",
                                       "Applied Reference Portfolio", "Reference Portfolio VaR", "VaR Test Value", "Applied VaR Limit",
                                       "VaR Test Pass Indicator", "Consecutive Business Days Out of Compliance"]),
            ("31", "Leverage & Exposure Measurement", ["Measured Fund", "Leverage Measurement Date", "Exposure Method",
                                                       "Measured Exposure Amount", "Net Assets Used", "Net Assets Source NAV",
                                                       "Leverage Percent of Net Assets", "Excluded Hedging Exposure Amount",
                                                       "Measurement Calculation Run"]),
            ("31", "Risk Limit", ["Risk Limit ID", "Limit Risk Program", "Limited Program Test Measure", "Limited Fund",
                                  "Limit Threshold"]),
            ("31", "Risk Limit Exceedance", ["Risk Limit Exceedance ID", "Exceeded Risk Limit", "Exceedance Start Date",
                                             "Exceedance End Date", "Exceedance Severity", "Exceedance Workflow Status",
                                             "Board Reporting Required Indicator", "Form N-RN Trigger Indicator"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Horizon Days",
                                              "Confidence Level", "Risk Measure Value"]),
            ("31", "Risk Calculation Run", ["Run As-Of Date", "Risk Run Status", "Run Approval Status"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Version Number", "Fund Net Assets Amount",
                                            "NAV Approval Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("18", "Portfolio Hierarchy Link", ["Parent Portfolio", "Child Portfolio", "Portfolio Hierarchy Link Type",
                                                "Look-Through Roll-Up Indicator"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("01", "Fund Legal Structure", ["Regulatory Regime", "Fund Openness"]),
            ("01", "Investment Objective & Policy", ["Derivatives Usage", "Leverage Calculation Method"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-146", "DP-154", "DP-142", "DP-140", "DP-143", "DP-004", "DP-165", "DP-097", "DP-192", "DP-212"],
        refresh="Daily",
        timeliness=("Daily HLIM, VaR test and exposure results by 10am ET on T+1, after DP-146's approved run and DP-165's NAV of "
                    "record; liquidity classifications at least monthly and on reclassification events; month-end results locked "
                    "for N-PORT by business day 10 after month-end"),
        history=("Daily program results and every classification kept at least six years (Rule 22e-4(c) and Rule 18f-4(c)(6) "
                 "require five); month-end values locked as filed, with any later correction kept as a new version; designations, "
                 "HLIMs and reference portfolios effective-dated (SCD type 2)"),
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "For every fund and Classification Date, Portion Percent of Position sums to 100% per Classified Instrument across its classification portions.",
            "Highly Liquid Percent + Moderately Liquid Percent + Less Liquid Percent + Illiquid Percent equals 100% within 0.1 percentage point on every Fund Liquidity Profile.",
            "Profile Net Assets and Net Assets Used equal the Fund Total Net Assets of the fund's NAV of record (DP-165) for the measurement date.",
            "Every VaR Test Result under a relative regime has Applied Reference Portfolio filled and resolving to a Designated Reference Portfolio with DRP Approval Status = Approved effective on the VaR Test Date.",
            "Every Fund Liquidity Profile names an Applied HLIM effective on the Profile Measurement Date unless the fund's HLIM has Primarily Highly Liquid Indicator = Y.",
            "Days to Cash is filled on every Liquidity Classification with Liquidity Classification Basis = Position Level, and Classification Override Reason is filled whenever the basis is Asset Class with Position Exception.",
        ],
        notes=("W4 re-point (CW-930, CW-166): 31 Liquidity Horizon Bucket.Bucket Private Fund Profile re-pointed to its renamed "
               "successor Bucket Feeder Access Terms (01 feeder, tender-offer and interval funds); Leverage & Exposure "
               "Measurement.Fund Borrowing Facility dropped, no successor (the 30 credit facility retires), and no measure read it. "
               "Consumer-aligned regulatory and control product of 31 (CD-213, CD-214). Certified numbers (CD-293, CD-320): the "
               "Rule 22e-4 liquidity classification family (Liquidity Category Percent of Net Assets, Illiquid Percent and HLIM "
               "Shortfall) is published only here; every other product, including DP-185 and DP-186 for N-PORT, N-RN and Form PF, "
               "reads it from here (brief hardest call 3). Ex-ante VaR is certified in DP-146 and read here; the VaR "
               "tie-out proves the fund test used it. Fund net assets are certified in DP-165 (CD-330) and read here. Fund-keyed "
               "results are measured on the fund's whole 18 book reached through DP-140 (CD-324). Program limits and their "
               "exceedances (RLMT-, RLEX-) are DP-154's (CD-223), read here for program context. Rule 2a-7 liquid asset minimums are "
               "33 rules, not here. CD-225, CD-234, CD-237: 35 files from this product and holds filing status and board "
               "approvals; HLIM Approval Status and DRP Approval Status are read as the 31 status only. "
               "Models (CD-294): liquidity classifications and liquidity stress results come from a liquidity model (usually a "
               "vendor model behind Liquidity Data Source Dataset) and VaR from the DP-146 risk model; both belong in the 37 model "
               "inventory, hence DP-212 upstream, and the Classification Date and run date are dimensions. "
               "Funds, vehicle types, regimes and derivatives usage come from DP-004; instruments from DP-097; fair value "
               "determinations behind classifications from DP-143; program risk leads and administrators through DP-192 (PII = "
               "Y, also for Stressed Portfolio of SMAs). "
               "Operating model: in house, possibly on a vendor engine; a vendor engine changes the source dataset, not the grain. "
               "If the program administrator role is outsourced, the grain is unchanged and the program results are received and "
               "approved by the firm. "
               "Model Inventory Entry reference added 2026-10-14 (CD-246, GAP-37-001): Liquidity Classification and Liquidity "
               "Stress Detail now name the liquidity model's 37 entry, read through DP-212. "
               "Taxonomy gap: Fund Liquidity Profile holds no publication or lock indicator for the N-PORT month-end value; the "
               "month-end lock is a product rule. "
               "Taxonomy gap: there is no fund redemption settlement period attribute for the liquidity stress flag; 7 days is "
               "assumed (Section 22(e)). "
               "Open SME questions (31 Source_Notes §4): program administrator and derivatives risk manager per fund family and "
               "limited derivatives users (Q2); classification by asset class or position, trade size used and whether 22 should "
               "own per-instrument liquidity inputs (Q3). Tolerances (0.1 and 0.01 percentage point) are drafting assumptions. "
               "Brief question 2: the client should confirm that the liquidity classification family is certified rather than "
               "regulatory evidence only. Rests on CD-213, CD-214, CD-223, CD-225, CD-234, CD-237, CD-294, CD-320, CD-324, CD-330. "
               "W1b re-point (CW-931, CW-935): 'Liquidity Stress Coverage' no longer filters on the removed Risk Program Type "
               "value UCITS Risk Management Process; 'Program Exceedances' counts the 22e-4, 18f-4 and Rule 2a-7 program types "
               "(the UCITS and AIFMD program values are removed); UCITS global exposure, AIFMD leverage, the UCITS VaR test and "
               "AIFMD Annex IV left the definition, questions and notes (Exposure Method now holds Rule 18f-4 Derivatives "
               "Exposure and Section 18 Asset Coverage). No input changed."),
    ),

    # DP-156 retired (CW-207); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
}
