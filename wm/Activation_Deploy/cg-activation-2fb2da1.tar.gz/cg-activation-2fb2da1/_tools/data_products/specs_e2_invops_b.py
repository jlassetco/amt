"""Data product specifications, Waves E2 and E3: performance, investment compliance and data quality (group
"invops_performance_compliance_data"). DP-157 to DP-163 (32 Performance & Attribution, 33 Investment Compliance; brief
Investment_Operations.md) and DP-102, DP-103 (17 Instrument & Issuer Reference, 21 Data Governance & Analytics; brief
Foundations_and_Product_Range.md). Consumer-aligned products built on the Wave E1 foundational products. See CONTRACT.md.

WP1 lineage pass: the specs of the retired DP-160 are deleted (framework.RETIRED_PRODUCTS; register rows kept).
"""

SPECS = {
    # =========================================== 32 Performance & Attribution ===========================================
    "DP-157": dict(
        definition=("Why each portfolio beat or trailed its benchmark: attribution results and their allocation, selection, "
                    "interaction and currency effects by segment under the approved attribution model, contribution to "
                    "return by instrument and segment, and ex-post risk statistics (realized tracking error, information "
                    "ratio, Sharpe ratio, beta, maximum drawdown) computed from realized returns. It combines the 32 "
                    "attribution and ex-post objects with the official and benchmark returns they explain, which it reads "
                    "from DP-145 and never restates, and sets the ex-post statistics beside the certified ex-ante tracking "
                    "error from DP-146. Portfolio managers, the CIO, risk and client reporting explain results with one "
                    "methodology. It owns no certified number."),
        business_questions=[
            "How much of each portfolio's active return last month and year to date came from allocation, selection, interaction and currency?",
            "Which instruments and segments contributed most to, and detracted most from, each portfolio's return?",
            "What were the realized tracking error, information ratio and Sharpe ratio over 1, 3 and 5 years, and how do they compare with the ex-ante tracking error the risk model forecast?",
            "Does every attribution result tie back to the official portfolio and benchmark returns, and how large is the unexplained residual?",
            "Which portfolios have a final official return but no final attribution, or an attribution run on a model that is not validated?",
        ],
        grain=("Attribution result (PAAN-: portfolio return version x benchmark return version x attribution model version x "
               "result version) x segment x effect type; with contribution to return (portfolio return version x segment or "
               "instrument x calculation basis) and ex-post risk statistic (subject x statistic type x period start x period "
               "end x observation frequency x fee basis x price basis x currency x comparison benchmark x version) as "
               "companion facts"),
        dimensions=["Portfolio", "Business line", "Benchmark", "Attribution model and version", "Attribution method",
                    "Segment classification scheme and segment", "Attribution effect type", "Instrument",
                    "Return period start and end", "Fee basis", "Currency", "Ex-post statistic type",
                    "Observation frequency", "Result status and version"],
        measures=[
            ("Active Return",
             "Active Return of the Attribution Result with the highest Attribution Version per Portfolio Return Record, Benchmark "
             "Return Record and Applied Attribution Model, and Attribution Status = Final.",
             [("32", "Attribution Result", "Active Return"), ("32", "Attribution Result", "Attribution Version"),
              ("32", "Attribution Result", "Attribution Status"), ("32", "Attribution Result", "Portfolio Return Record"),
              ("32", "Attribution Result", "Benchmark Return Record"), ("32", "Attribution Result", "Applied Attribution Model")]),
            ("Attribution Effect by Type",
             "Sum of Attribution Effect Value over the segments of the final result, by Attribution Effect Type (allocation, "
             "selection, interaction, currency and any factor effects the model defines).",
             [("32", "Attribution Effect", "Effect Attribution Result"), ("32", "Attribution Effect", "Effect Segment Code"),
              ("32", "Attribution Effect", "Attribution Effect Type"), ("32", "Attribution Effect", "Attribution Effect Value"),
              "Active Return"]),
            ("Effects Sum Tie-Out",
             "Active Return - (sum of Attribution Effect Value over all segments and effect types + Attribution Residual) for "
             "the result; flagged beyond 0.0001.",
             [("32", "Attribution Effect", "Attribution Effect Value"), ("32", "Attribution Result", "Attribution Residual"),
              "Active Return"]),
            ("Return Tie-Out",
             "Active Return - (Official Return of the Portfolio Return Record - Benchmark Return of the Benchmark Return "
             "Record), both read from DP-145 for the same period and currency (arithmetic; geometric models compare to "
             "(1 + portfolio) / (1 + benchmark) - 1); flagged beyond 0.0001. The returns are read, never recalculated (CD-320).",
             [("32", "Performance Return", "Performance Return ID"), ("32", "Performance Return", "Return Version"),
              ("32", "Performance Return", "Return Value"), ("32", "Performance Return", "Return Status"),
              ("32", "Benchmark Return", "Benchmark Return Value"), ("32", "Benchmark Return", "Benchmark Return Status"),
              ("32", "Attribution Model", "Attribution Method"), "Active Return"]),
            ("Residual Share %",
             "|Attribution Residual| / |Active Return| for the final result; results above 10% are listed for review.",
             [("32", "Attribution Result", "Attribution Residual"), "Active Return"]),
            ("Segment Weight Sum Check",
             "Sum of Portfolio Segment Weight and sum of Benchmark Segment Weight per Segment Attribution Result; each flagged "
             "when not 100% within 0.01%.",
             [("32", "Attribution Segment Result", "Segment Attribution Result"),
              ("32", "Attribution Segment Result", "Portfolio Segment Weight"),
              ("32", "Attribution Segment Result", "Benchmark Segment Weight")]),
            ("Top Contributors and Detractors",
             "The ten highest and ten lowest Contribution to Return Value per Contribution Portfolio Return Record at "
             "instrument level (Contribution Instrument filled), with Contribution Average Weight.",
             [("32", "Contribution to Return", "Contribution Portfolio Return Record"),
              ("32", "Contribution to Return", "Contribution Instrument"),
              ("32", "Contribution to Return", "Contribution to Return Value"),
              ("32", "Contribution to Return", "Contribution Average Weight")]),
            ("Contribution Tie-Out",
             "Sum of Contribution to Return Value over the rows of one Contribution Portfolio Return Record, Contribution "
             "Classification Scheme and Contribution Calculation Basis - Return Value of that return (from DP-145); flagged "
             "beyond 0.0005 for single-period arithmetic contributions.",
             [("32", "Contribution to Return", "Contribution Portfolio Return Record"),
              ("32", "Contribution to Return", "Contribution Classification Scheme"),
              ("32", "Contribution to Return", "Contribution Calculation Basis"),
              ("32", "Contribution to Return", "Contribution to Return Value"), ("32", "Performance Return", "Return Value")]),
            ("Ex-Post Risk Statistics",
             "Statistic Value of the Ex-Post Risk Statistic with the highest Statistic Version per subject, Ex-Post Statistic "
             "Type, period, Observation Frequency, Statistic Fee Basis, Statistic Price Basis, Statistic Currency and "
             "Comparison Benchmark, and Statistic Status = Final, by type (Ex-Post Tracking Error, Information Ratio, Sharpe "
             "Ratio, Ex-Post Beta, Maximum Drawdown). Published, not certified.",
             [("32", "Ex-Post Risk Statistic", "Statistic Subject Type"), ("32", "Ex-Post Risk Statistic", "Statistic Portfolio"),
              ("32", "Ex-Post Risk Statistic", "Ex-Post Statistic Type"),
              ("32", "Ex-Post Risk Statistic", "Statistic Period Start Date"),
              ("32", "Ex-Post Risk Statistic", "Statistic Period End Date"),
              ("32", "Ex-Post Risk Statistic", "Observation Frequency"), ("32", "Ex-Post Risk Statistic", "Comparison Benchmark"),
              ("32", "Ex-Post Risk Statistic", "Statistic Fee Basis"), ("32", "Ex-Post Risk Statistic", "Statistic Price Basis"),
              ("32", "Ex-Post Risk Statistic", "Statistic Currency"), ("32", "Ex-Post Risk Statistic", "Statistic Version"),
              ("32", "Ex-Post Risk Statistic", "Statistic Value"), ("32", "Ex-Post Risk Statistic", "Statistic Status")]),
            ("Ex-Ante vs Ex-Post Tracking Error Ratio",
             "Ex-post tracking error (Ex-Post Statistic Type = Ex-Post Tracking Error, trailing 12 months, monthly) / Ex-Ante "
             "Tracking Error from DP-146 (Risk Measure = Ex-Ante Tracking Error from the approved Risk Calculation Run at the "
             "start of the window) for the same portfolio and benchmark; flagged outside 0.5 to 2.0. The ex-ante value is "
             "certified in DP-146 and only read here.",
             [("31", "Portfolio Risk Measure", "Measured Portfolio"), ("31", "Portfolio Risk Measure", "Risk Measure"),
              ("31", "Portfolio Risk Measure", "Measure Benchmark"), ("31", "Portfolio Risk Measure", "Risk Measure Value"),
              ("31", "Portfolio Risk Measure", "Measure Calculation Run"), ("31", "Risk Calculation Run", "Run As-Of Date"),
              ("31", "Risk Calculation Run", "Run Approval Status"), "Ex-Post Risk Statistics"]),
            ("Attribution Coverage %",
             "Portfolios with a Final or Restated monthly Official Return (DP-145) and a primary benchmark that have a final "
             "Attribution Result for the month / all such portfolios, by Business Line.",
             [("32", "Performance Return", "Return Subject Type"), ("32", "Performance Return", "Return Portfolio"),
              ("32", "Performance Return", "Return Period End Date"), ("32", "Performance Return", "Return Status"),
              ("18", "Portfolio", "Business Line"), ("32", "Attribution Result", "Portfolio Return Record"),
              ("32", "Attribution Result", "Attribution Status")]),
            ("Results on Unvalidated Models",
             "Count of final Attribution Results whose Applied Attribution Model version names, through Model Inventory "
             "Reference, a 37 model version (DP-212) with Model Use Status not in use or with no Model Validation whose Model "
             "Validation Outcome is Approved or Approved with Conditions.",
             [("32", "Attribution Model", "Attribution Model Code"), ("32", "Attribution Model", "Attribution Model Version"),
              ("32", "Attribution Model", "Model Inventory Reference"), ("37", "Model Inventory Entry", "Model ID"),
              ("37", "Model Inventory Entry", "Model Version"), ("37", "Model Inventory Entry", "Model Use Status"),
              ("37", "Model Validation", "Validated Model"), ("37", "Model Validation", "Model Validation Outcome"),
              ("32", "Attribution Result", "Applied Attribution Model")]),
        ],
        inputs=[
            ("32", "Attribution Model", ["Attribution Model Code", "Attribution Model Version", "Attribution Method",
                                         "Attribution Linking Method", "Attribution Calculation Basis",
                                         "Segment Classification Scheme", "Currency Attribution Method", "Factor Risk Model",
                                         "Model Inventory Reference", "Attribution Model Effective From"]),
            ("32", "Attribution Result", ["Attribution Result ID", "Portfolio Return Record", "Benchmark Return Record",
                                          "Applied Attribution Model", "Active Return", "Attribution Residual",
                                          "Reference Target Allocation", "Attribution Version", "Attribution Status"]),
            ("32", "Attribution Segment Result", ["Segment Attribution Result", "Attribution Segment Code",
                                                  "Portfolio Segment Weight", "Benchmark Segment Weight",
                                                  "Portfolio Segment Return", "Benchmark Segment Return"]),
            ("32", "Attribution Effect", ["Effect Attribution Result", "Effect Segment Code", "Attribution Effect Type",
                                          "Attribution Effect Value"]),
            ("32", "Contribution to Return", ["Contribution Portfolio Return Record", "Contribution Instrument",
                                              "Contribution Classification Scheme", "Contribution Segment Code",
                                              "Contribution Average Weight", "Contribution to Return Value",
                                              "Contribution Calculation Basis"]),
            ("32", "Ex-Post Risk Statistic", ["Statistic Subject Type", "Statistic Portfolio", "Statistic Share Class",
                                              "Statistic Composite", "Statistic Benchmark", "Ex-Post Statistic Type",
                                              "Statistic Period Start Date", "Statistic Period End Date",
                                              "Observation Frequency", "Comparison Benchmark", "Risk-Free Rate Benchmark",
                                              "Statistic Fee Basis", "Statistic Price Basis", "Statistic Currency",
                                              "Statistic Version", "Statistic Value", "Statistic Status"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Subject Type",
                                          "Return Portfolio", "Return Period Start Date", "Return Period End Date",
                                          "Return Fee Basis", "Return Currency", "Return Value", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Type", "Benchmark Return Currency",
                                        "Benchmark Hedged Basis Indicator", "Benchmark Return Version",
                                        "Benchmark Return Value", "Benchmark Return Status"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure",
                                              "Measure Benchmark", "Risk Measure Value"]),
            ("31", "Risk Calculation Run", ["Run Risk Model", "Run As-Of Date", "Run Approval Status"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Use Status"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Outcome", "Model Validation Completed Date"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("09", "Classification Scheme", ["Classification Scheme ID", "Scheme Name"]),
        ],
        upstream=["DP-145", "DP-146", "DP-142", "DP-144", "DP-140", "DP-097", "DP-004", "DP-013", "DP-212"],
        refresh="Monthly",
        timeliness=("Monthly results by business day 10 after month-end, three business days after the official returns are "
                    "Final in DP-145 (business day 7); daily ex-post statistics and contribution for internal use by T+2"),
        history=("Every attribution result version and ex-post statistic version since the attribution model's effective date; "
                 "monthly results kept 10 years; superseded versions retained with their status"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every final Attribution Result references a Portfolio Return Record and Benchmark Return Record whose Return Status and Benchmark Return Status are Final or Restated in DP-145.",
            "For every final result, Active Return equals the sum of Attribution Effect Value over all segments and effect types plus Attribution Residual within 0.0001.",
            "Portfolio Segment Weight and Benchmark Segment Weight each sum to 100% within 0.01% per result.",
            "No Ex-Post Risk Statistic with Statistic Status Final has a Statistic Period End Date after the latest Final official return of its subject.",
            "Every Attribution Model version used by a final result has a Model Inventory Reference that resolves to a 37 model version in DP-212.",
        ],
        notes=("Master concepts read, not remastered: Attribution Result (PAAN-), Contribution to Return and Ex-Post Risk "
               "Statistic (32). Certified numbers: none. Official and benchmark returns are certified in DP-145 and ex-ante "
               "VaR and tracking error in DP-146 (CD-293, CD-320); this product reads both and never recalculates them. "
               "Ex-post statistics are published but not certified; names say 'Ex-Post' wherever DP-146 has an ex-ante "
               "counterpart (CD-211). Attribution and contribution reference return versions in DP-145 and never restate "
               "the return (32 Source_Notes: the return value lives only on Performance Return). Model inventory (CD-246, "
               "CD-294): attribution models reference the 37 model inventory through Model Inventory Reference; DP-212 is "
               "upstream and supplies the validation state. Reference Target Allocation (24) is carried as a key only; the "
               "portfolio targets product of the Investment brief (DP-128) publishes the targets and is not upstream. "
               "Segments resolve to 09 classification schemes through DP-013; instruments through DP-097; portfolios and "
               "business lines through DP-140; benchmarks through DP-004 (read as 01 keys on the 32 records until the "
               "CD-322 extension is built). Benchmark Segment Weight is derived from licensed index constituents (DP-144): "
               "client-report use needs the index license check (Investment_Operations brief question 8). PII = Y: "
               "Statistic Portfolio, Return Portfolio and the result values of portfolios of individuals (SMA books) are "
               "personal data, as in DP-145; publish a view without SMA books for wide use. Operating model: in house "
               "(brief §2); if a vendor attribution engine is used the grain is unchanged and the Attribution Model records "
               "the vendor model. Taxonomy gap: Attribution Result carries no period dates or currency of its own; they are "
               "read from the referenced Performance Return. Model Inventory Entry reference added 2026-10-14 (CD-246, "
               "GAP-37-001): Attribution Model holds it as Model Inventory Reference (re-typed at the Stage 4 consolidation), "
               "so approval is read from 37 Model Validation through DP-212 by design and 32 carries no approval status. Taxonomy gap: Ex-Post Risk Statistic has no account or "
               "model portfolio subject (32 Source_Notes review response), so SMA statistics are computed on the 18 "
               "portfolio. Taxonomy gap: no attribute records the residual tolerance per model; 10% is a drafting assumption. "
               "Open SME questions (32 Source_Notes §4): 5 attribution models per asset class and linking method; 1 the "
               "performance platform. Rests on CD-211, CD-217, CD-246, CD-293, CD-294, CD-320, CD-322, CD-324."),
    ),

    "DP-158": dict(
        definition=("The firm's GIPS compliance record: the GIPS firm definition and its total firm assets, composite "
                    "membership by portfolio with inclusion and exclusion dates and reasons, significant cash flow removals, "
                    "carve-outs, the composite statistics GIPS reports require (number of portfolios, composite assets, "
                    "internal dispersion, 3-year ex-post standard deviation) and verification engagements. It combines the "
                    "32 GIPS objects with the portfolio master (DP-140), portfolio capital activity (DP-141) and the official "
                    "composite and benchmark returns (DP-145), so the performance team can prove every fee-paying "
                    "discretionary portfolio is in the right composite and RFPs, marketing and GIPS reports show the same "
                    "statistics. GIPS Total Firm Assets and Composite Assets are GIPS-defined figures, never AUM (CD-320)."),
        business_questions=[
            "Is every active fee-paying discretionary portfolio of the GIPS firm in a composite, or excluded with a documented reason?",
            "What are each composite's number of portfolios, composite assets, share of firm assets, internal dispersion and 3-year standard deviation for the year, and do they tie to the members' values?",
            "Which significant cash flows removed a portfolio from its composite, and which removals are still open?",
            "What is the composite's official return against its benchmark for each annual period shown in the GIPS report?",
            "When was the GIPS firm last verified, for which period, and which composites had a performance examination?",
        ],
        grain=("Composite x period end x period type (composite period statistic); with composite membership (composite x "
               "portfolio x membership start date), significant cash flow event (portfolio x composite x flow date), "
               "carve-out allocation (carve-out portfolio x period), GIPS firm x period end (firm assets) and GIPS "
               "verification engagement (GVER-) as companion facts"),
        dimensions=["GIPS firm", "GIPS composite", "Composite benchmark", "Portfolio", "Business line", "Managing entity",
                    "Period end and period type", "Membership start and end date", "Composite exclusion reason",
                    "Fee-paying indicator", "Verification engagement and verifier"],
        measures=[
            ("Composite Members",
             "Count of Composite Membership rows per Membership Composite with Membership Start Date on or before the date, "
             "Membership End Date null or after it, and Membership Approval Status = Approved, excluding portfolios in an open "
             "significant cash flow removal (Removal Start Date on or before the date and Return to Composite Date null or "
             "after it).",
             [("32", "Composite Membership", "Membership Composite"), ("32", "Composite Membership", "Member Portfolio"),
              ("32", "Composite Membership", "Membership Start Date"), ("32", "Composite Membership", "Membership End Date"),
              ("32", "Composite Membership", "Membership Approval Status"),
              ("32", "Significant Cash Flow Event", "Removal Start Date"),
              ("32", "Significant Cash Flow Event", "Return to Composite Date")]),
            ("Unassigned Discretionary Portfolios",
             "Count of Portfolios with Portfolio Status = Active, Portfolio Type = Standalone Book, Managing Entity among the "
             "GIPS Firm's Firm Legal Entities and Full Discretion Indicator not N, that have no Composite Membership effective "
             "on the date and no membership row closed with a Composite Exclusion Reason.",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("18", "Portfolio", "Portfolio Type"),
              ("18", "Portfolio", "Managing Entity"), ("18", "SMA Portfolio Detail", "Full Discretion Indicator"),
              ("32", "GIPS Firm", "Firm Legal Entities"), ("32", "Composite Membership", "Member Portfolio"),
              ("32", "Composite Membership", "Composite Exclusion Reason")]),
            ("Pending Membership Approvals",
             "Count of Composite Membership rows with Membership Approval Status = Pending, by composite and days since "
             "Membership Start Date.",
             [("32", "Composite Membership", "Membership Approval Status"), ("32", "Composite Membership", "Membership Start Date")]),
            ("Composite Assets",
             "Composite Assets and Number of Portfolios of the Composite Period Statistic for the composite and period end, as "
             "GIPS figures; never labeled or summed as AUM (CD-320).",
             [("32", "Composite Period Statistic", "Statistic Composite"),
              ("32", "Composite Period Statistic", "Composite Period End Date"),
              ("32", "Composite Period Statistic", "Composite Period Type"),
              ("32", "Composite Period Statistic", "Composite Assets"),
              ("32", "Composite Period Statistic", "Number of Portfolios")]),
            ("Composite Statistic Tie-Out",
             "Number of Portfolios - Composite Members at Composite Period End Date, and Composite Assets - sum of Ending "
             "Portfolio Value of the members' Final monthly Performance Return ending on that date (DP-145); each flagged when "
             "not zero (assets within 0.5%).",
             [("32", "Composite Period Statistic", "Number of Portfolios"),
              ("32", "Composite Period Statistic", "Composite Assets"),
              ("32", "Return Component Detail", "Ending Portfolio Value"), ("32", "Performance Return", "Return Portfolio"),
              ("32", "Performance Return", "Return Period End Date"), ("32", "Performance Return", "Return Status"),
              "Composite Members"]),
            ("Composite Share of Firm Assets %",
             "Composite Assets / Total Firm Assets of the GIPS Firm Assets with Firm Assets Period End Date equal to the "
             "Composite Period End Date, both GIPS figures in Firm Assets Currency.",
             [("32", "GIPS Firm Assets", "Total Firm Assets"), ("32", "GIPS Firm Assets", "Firm Assets Period End Date"),
              ("32", "GIPS Firm Assets", "Firm Assets Currency"), "Composite Assets"]),
            ("Composite Excess Return",
             "Official Return of the composite (Return Subject Type = GIPS Composite, Return Composite) minus the Benchmark "
             "Return of the Composite Benchmark for the same annual period, Return Fee Basis and currency, both read from "
             "DP-145 (arithmetic).",
             [("32", "Performance Return", "Return Subject Type"), ("32", "Performance Return", "Return Composite"),
              ("32", "Performance Return", "Return Period Start Date"), ("32", "Performance Return", "Return Fee Basis"),
              ("32", "Performance Return", "Return Currency"), ("32", "Performance Return", "Return Value"),
              ("01", "GIPS Composite", "Composite Benchmark"), ("32", "Benchmark Return", "Return Benchmark"),
              ("32", "Benchmark Return", "Benchmark Return Value")]),
            ("Missing Required Statistics",
             "Count of composite annual periods with Number of Portfolios of 6 or more and Internal Dispersion null, plus "
             "periods with 36 or more monthly composite returns and Composite 3-Year Ex-Post Standard Deviation or "
             "Benchmark 3-Year Ex-Post Standard Deviation null.",
             [("32", "Composite Period Statistic", "Number of Portfolios"),
              ("32", "Composite Period Statistic", "Internal Dispersion"),
              ("32", "Composite Period Statistic", "Composite 3-Year Ex-Post Standard Deviation"),
              ("32", "Composite Period Statistic", "Benchmark 3-Year Ex-Post Standard Deviation"),
              ("32", "Performance Return", "Return Composite")]),
            ("Significant Flow Removals Open",
             "Count of Significant Cash Flow Events with Removal Start Date filled and Return to Composite Date null, by "
             "composite, with Significant Flow Amount and Flow Percentage of Portfolio Value.",
             [("32", "Significant Cash Flow Event", "Flow Portfolio"), ("32", "Significant Cash Flow Event", "Flow Composite"),
              ("32", "Significant Cash Flow Event", "Removal Start Date"),
              ("32", "Significant Cash Flow Event", "Return to Composite Date"),
              ("32", "Significant Cash Flow Event", "Significant Flow Amount"),
              ("32", "Significant Cash Flow Event", "Flow Percentage of Portfolio Value")]),
            ("Unrecorded Significant Flows",
             "Count of Portfolio Capital Activity rows (DP-141) of member portfolios whose |Activity Amount Base| / Beginning "
             "Portfolio Value of the month's return is at or above the Applied Significant Flow Threshold of the composite's "
             "policy and that have no Significant Cash Flow Event on the Activity Trade Date.",
             [("18", "Portfolio Capital Activity", "Activity Portfolio"),
              ("18", "Portfolio Capital Activity", "Activity Trade Date"),
              ("18", "Portfolio Capital Activity", "Activity Amount Base"),
              ("18", "Portfolio Capital Activity", "Capital Activity Type"),
              ("32", "Return Component Detail", "Beginning Portfolio Value"),
              ("32", "Significant Cash Flow Event", "Applied Significant Flow Threshold"),
              ("32", "Significant Cash Flow Event", "Significant Flow Date"),
              ("01", "GIPS Composite", "Significant Cash Flow Policy")]),
            ("Carve-Outs Without Own Cash",
             "Count of Carve-Out Allocations with Own Cash Balance Indicator = N whose Carve-Out Period End Date is on or "
             "after 2010-01-01 (GIPS requires carve-outs from that date to carry their own cash) and whose Carve-Out "
             "Portfolio is a composite member.",
             [("32", "Carve-Out Allocation", "Carve-Out Portfolio"), ("32", "Carve-Out Allocation", "Own Cash Balance Indicator"),
              ("32", "Carve-Out Allocation", "Carve-Out Period End Date"), ("32", "Composite Membership", "Member Portfolio")]),
            ("Verification Lag Months",
             "Months between the latest Verification Period End Date of the GIPS Firm (Verified GIPS Firm) and the latest "
             "Firm Assets Period End Date; flagged above 15.",
             [("32", "GIPS Verification", "Verified GIPS Firm"), ("32", "GIPS Verification", "Verification Period End Date"),
              ("32", "GIPS Verification", "Verification Report Date"), ("32", "GIPS Firm Assets", "Firm Assets Period End Date")]),
        ],
        inputs=[
            ("32", "GIPS Firm", ["GIPS Firm Code", "GIPS Firm Name", "GIPS Firm Definition", "Firm Legal Entities",
                                 "Compliance Claim Date", "Firm Definition Effective From", "GIPS Compliance Officer"]),
            ("32", "GIPS Firm Assets", ["Firm Assets Period End Date", "Total Firm Assets", "Firm Assets Currency"]),
            ("32", "Composite Membership", ["Membership Composite", "Member Portfolio", "Membership Start Date",
                                            "Membership End Date", "Composite Exclusion Reason",
                                            "Significant Cash Flow Removals", "Fee-Paying Indicator",
                                            "Membership Approval Status", "Membership Approver"]),
            ("32", "Composite Period Statistic", ["Statistic Composite", "Composite Period End Date", "Composite Period Type",
                                                  "Number of Portfolios", "Composite Assets", "Internal Dispersion",
                                                  "Internal Dispersion Method",
                                                  "Composite 3-Year Ex-Post Standard Deviation",
                                                  "Benchmark 3-Year Ex-Post Standard Deviation",
                                                  "Standard Deviation Fee Basis", "Non-Fee-Paying Assets Percentage"]),
            ("32", "Significant Cash Flow Event", ["Flow Portfolio", "Flow Composite", "Significant Flow Date",
                                                   "Source Capital Activity", "Significant Flow Amount",
                                                   "Flow Percentage of Portfolio Value",
                                                   "Applied Significant Flow Threshold", "Removal Start Date",
                                                   "Return to Composite Date"]),
            ("32", "Carve-Out Allocation", ["Carve-Out Portfolio", "Parent Portfolio", "Carve-Out Period Start Date",
                                            "Carve-Out Period End Date", "Own Cash Balance Indicator"]),
            ("32", "GIPS Verification", ["GIPS Verification ID", "Verified GIPS Firm", "Verifier",
                                         "Verification Period Start Date", "Verification Period End Date",
                                         "Verification Report Date", "Performance Examination Composites"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Subject Type",
                                          "Return Portfolio", "Return Composite", "Return Period Start Date",
                                          "Return Period End Date", "Return Fee Basis", "Return Currency", "Return Value",
                                          "Return Status"]),
            ("32", "Return Component Detail", ["Beginning Portfolio Value", "Ending Portfolio Value"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Currency", "Benchmark Return Value", "Benchmark Return Status"]),
            ("01", "GIPS Composite", ["Composite ID", "Composite Name", "Composite Definition", "Composite Creation Date",
                                      "Composite Inception Date", "Composite Benchmark", "Minimum Portfolio Size",
                                      "Significant Cash Flow Policy"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status", "Managing Entity",
                                 "Inception Date", "Termination Date"]),
            ("18", "SMA Portfolio Detail", ["Full Discretion Indicator"]),
            ("18", "Portfolio Capital Activity", ["Activity Portfolio", "Capital Activity Type", "Activity Trade Date",
                                                  "Activity Amount Base"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-145", "DP-140", "DP-141", "DP-004", "DP-192", "DP-013", "DP-240"],
        refresh="Monthly",
        timeliness=("Membership and significant flow checks by business day 10 after month-end; annual composite statistics "
                    "by business day 30 after the calendar year-end, before GIPS reports are refreshed"),
        history=("Full history since the GIPS firm's Compliance Claim Date: membership kept as effective-dated rows and never "
                 "deleted (GIPS requires the composite's full membership history), annual statistics and firm assets for "
                 "every year shown, all verification engagements"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Composite Membership references a Membership Composite that exists as an 01 GIPS Composite and a Member Portfolio active in DP-140 on the Membership Start Date.",
            "No portfolio has two overlapping Composite Memberships in the same composite.",
            "Number of Portfolios on each Composite Period Statistic equals the count of members at Composite Period End Date, excluding open significant cash flow removals.",
            "Every Significant Cash Flow Event with a Removal Start Date falls within a Composite Membership of the same portfolio and composite.",
            "Composite Assets never exceeds Total Firm Assets of the same GIPS firm and period end.",
            "Every composite return shown for a GIPS period has Return Status Final or Restated in DP-145.",
        ],
        notes=("Master concepts read, not remastered: Composite Membership, Composite Period Statistic, Significant Cash "
               "Flow Event, Carve-Out Allocation, GIPS Firm and GIPS Verification (32, CD-218). Certified numbers: none. "
               "Composite and benchmark returns are certified in DP-145 and only read (CD-320). GIPS Total Firm Assets and "
               "Composite Assets are GIPS-defined figures, never published or summed as AUM (CD-292, CD-320; brief hardest "
               "call 1); they are not reconciled to Firm AUM (DP-241 dropped the GIPS Firm Assets comparison memo at WP1). The composite "
               "definition stays in 01 and reaches this product through DP-004 (CD-218, CD-322); until DP-004's extension is "
               "built, 01 GIPS Composite is read directly and DP-004 is listed upstream, with no change to the inputs when "
               "it lands. Portfolios, managing entities and SMA discretion come from DP-140 (CD-324); capital activity from "
               "DP-141; approvers and the GIPS compliance officer from DP-192; the verifier party from DP-240; legal entities "
               "from DP-013. Copies read as held: Significant Flow Amount (18) and Applied Significant Flow Threshold (01) "
               "on Significant Cash Flow Event, and Beginning and Ending Portfolio Value (18) on Return Component Detail, are "
               "the values the GIPS record used (rule 2 exception). Re-points (CD-323): DP-062 and DP-068 add DP-145 and "
               "this product upstream for composite statistics, and DP-023 reads composite statistics from here; their "
               "owners make those changes. PII = Y: Member Portfolio, Membership Approver and the GIPS Compliance Officer "
               "identify individuals' SMA books and employees; a composite-level view without member portfolios is the "
               "wide view for marketing and RFPs. Operating model: in house (brief §2). Taxonomy gap: 18 Portfolio has no "
               "discretion or fee-paying indicator outside SMA Portfolio Detail, so pooled funds and institutional books are "
               "treated as discretionary unless excluded. Taxonomy gap: 01 GIPS Composite has no composite termination date "
               "and no new-portfolio inclusion period, so late inclusion cannot be tested. Taxonomy gap: Composite "
               "Membership has no approval date, and GIPS Verification has no opinion or engagement type (32 Source_Notes "
               "§2); Composite Period Statistic has no version or status, so restated statistics are not traced. Thresholds "
               "(0.5% assets tie-out, 15-month verification lag, 6 portfolios and 36 months for required statistics) follow "
               "the GIPS 2020 requirements as understood and are to be confirmed. Open SME questions (32 Source_Notes §4): 4 "
               "who approves membership changes; 10 GIPS claim scope and pooled fund reports. Rests on CD-218, CD-292, "
               "CD-297, CD-320, CD-322, CD-323, CD-324."
               "WP1 re-point (CW-206): Firm AUM is DP-241's (moved from DP-165), and DP-241 no longer reads GIPS firm assets (its 'GIPS Firm Assets Comparison (memo)' is dropped); the boundary sentence is re-pointed. No input or measure changed."),
    ),

    "DP-159": dict(
        definition=("One firm view of investment results by strategy, fund, share class and composite: official returns "
                    "against the primary benchmark and the peer median over standard periods, peer percentile rank, ex-post "
                    "and ex-ante risk, and the share of share classes and of fund assets ahead of benchmark. It combines the "
                    "certified returns of DP-145, ex-post statistics of DP-157, ex-ante tracking error of DP-146, GIPS "
                    "composite statistics of DP-158, peer returns and ranks of DP-014 ('Published Peer Return', CD-217) and "
                    "certified class net assets of DP-165, so investment, distribution and product leadership read the same "
                    "numbers instead of rebuilding them from vendor data. It recalculates none of them."),
        business_questions=[
            "Which funds, share classes and composites are ahead of their primary benchmark over 1, 3, 5 and 10 years, and by how much?",
            "Where does each own share class rank against its peer universe, and how far is it from the peer median?",
            "What share of share classes, and of fund assets, is ahead of benchmark over 3 and 5 years, and how is that trending?",
            "Which strategies combine underperformance with high realized or forecast tracking error?",
            "Which active share classes lack a final official return or a peer rank for the period?",
        ],
        grain=("Scorecard subject (share class, fund, GIPS composite or strategy) x standard period (1 month, 3 months, year to "
               "date, 1, 3, 5 and 10 years, since inception) x month-end as-of date x fee basis x currency"),
        dimensions=["Strategy", "Investment product (fund)", "Share class", "GIPS composite", "Primary benchmark",
                    "Peer universe", "Standard period", "As-of month-end", "Fee basis", "Currency", "Vehicle type",
                    "Business line"],
        measures=[
            ("Official Return",
             "Return Value of the Final or Restated Performance Return (highest Return Version) for the subject, period and "
             "fee basis, from DP-145; annualized for periods over one year as published (Annualized Indicator).",
             [("32", "Performance Return", "Return Subject Type"), ("32", "Performance Return", "Return Share Class"),
              ("32", "Performance Return", "Return Composite"), ("32", "Performance Return", "Return Period Start Date"),
              ("32", "Performance Return", "Return Period End Date"), ("32", "Performance Return", "Return Period Basis"),
              ("32", "Performance Return", "Return Fee Basis"), ("32", "Performance Return", "Return Currency"),
              ("32", "Performance Return", "Return Version"), ("32", "Performance Return", "Return Value"),
              ("32", "Performance Return", "Annualized Indicator"), ("32", "Performance Return", "Return Status")]),
            ("Benchmark Return",
             "Benchmark Return Value of the Final or Restated Benchmark Return (DP-145) of the subject's primary benchmark: the "
             "Product Benchmark Assignment with Benchmark Role = Primary effective at the period end for share classes and "
             "funds, the Composite Benchmark for composites; same period and currency.",
             [("32", "Benchmark Return", "Return Benchmark"), ("32", "Benchmark Return", "Benchmark Period Start Date"),
              ("32", "Benchmark Return", "Benchmark Period End Date"), ("32", "Benchmark Return", "Benchmark Return Currency"),
              ("32", "Benchmark Return", "Benchmark Return Value"), ("32", "Benchmark Return", "Benchmark Return Status"),
              ("01", "Product Benchmark Assignment", "Assigned Product / Share Class"),
              ("01", "Product Benchmark Assignment", "Assigned Benchmark"),
              ("01", "Product Benchmark Assignment", "Benchmark Role"),
              ("01", "Product Benchmark Assignment", "Assignment Effective From"),
              ("01", "Product Benchmark Assignment", "Assignment Effective To"),
              ("01", "GIPS Composite", "Composite Benchmark")]),
            ("Excess Return",
             "For share classes, the Excess Return published by DP-145; for composites and strategies the same arithmetic "
             "difference Official Return - Benchmark Return of the two DP-145 values.",
             ["Official Return", "Benchmark Return"]),
            ("Peer Median Return",
             "Median of Total Return (Published Peer Return, DP-014) over the Peer Universe Member funds of the subject's peer "
             "universe for the same Snapshot Date and Return Period; vendor returns, never mixed into own returns (CD-217).",
             [("11", "Peer Universe", "Peer Universe ID"), ("11", "Peer Universe", "Own Strategy Compared"),
              ("11", "Peer Universe Member", "Member Fund"), ("11", "Peer Metric Snapshot", "Snapshot Date"),
              ("11", "Peer Metric Snapshot", "Return Period"), ("11", "Peer Metric Snapshot", "Total Return"),
              ("11", "Peer Metric Snapshot", "Peer Universe")]),
            ("Excess vs Peer Median",
             "Official Return - Peer Median Return for the same period; shown with the basis note that own returns are "
             "official and peer returns vendor-published.",
             ["Official Return", "Peer Median Return"]),
            ("Peer Percentile Rank and Quartile",
             "Category Percentile Rank and Quartile Rank of the 11 Peer Fund whose ISIN equals the own share class ISIN, for the "
             "Snapshot Date and Return Period, as published by the vendor (not recomputed).",
             [("11", "Peer Fund", "Peer Fund ID"), ("11", "Peer Fund", "ISIN"), ("01", "Security Identifier", "ISIN"),
              ("11", "Peer Metric Snapshot", "Category Percentile Rank"), ("11", "Peer Metric Snapshot", "Quartile Rank")]),
            ("Ex-Post Risk",
             "Final ex-post Information Ratio, Sharpe Ratio and Ex-Post Tracking Error of the subject for the period, read from "
             "DP-157.",
             [("32", "Ex-Post Risk Statistic", "Statistic Subject Type"), ("32", "Ex-Post Risk Statistic", "Statistic Share Class"),
              ("32", "Ex-Post Risk Statistic", "Statistic Composite"), ("32", "Ex-Post Risk Statistic", "Ex-Post Statistic Type"),
              ("32", "Ex-Post Risk Statistic", "Statistic Period End Date"), ("32", "Ex-Post Risk Statistic", "Statistic Value"),
              ("32", "Ex-Post Risk Statistic", "Statistic Status")]),
            ("Ex-Ante Tracking Error",
             "Risk Measure Value with Risk Measure = Ex-Ante Tracking Error from the approved Risk Calculation Run at the "
             "as-of date (DP-146, certified), for the portfolio whose Portfolio Implementation Link to the fund has Primary "
             "Implementation Indicator = Y (DP-140, CD-324).",
             [("31", "Portfolio Risk Measure", "Measured Portfolio"), ("31", "Portfolio Risk Measure", "Risk Measure"),
              ("31", "Portfolio Risk Measure", "Risk Measure Value"), ("31", "Portfolio Risk Measure", "Measure Calculation Run"),
              ("31", "Risk Calculation Run", "Run As-Of Date"), ("31", "Risk Calculation Run", "Run Approval Status"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"),
              ("18", "Portfolio Implementation Link", "Implemented Product"),
              ("18", "Portfolio Implementation Link", "Primary Implementation Indicator"),
              ("18", "Portfolio Implementation Link", "Implementation Effective From"),
              ("18", "Portfolio Implementation Link", "Implementation Effective To")]),
            ("Composite Risk Ratio",
             "Composite 3-Year Ex-Post Standard Deviation / Benchmark 3-Year Ex-Post Standard Deviation of the composite's "
             "latest annual Composite Period Statistic (DP-158).",
             [("32", "Composite Period Statistic", "Statistic Composite"),
              ("32", "Composite Period Statistic", "Composite Period End Date"),
              ("32", "Composite Period Statistic", "Composite 3-Year Ex-Post Standard Deviation"),
              ("32", "Composite Period Statistic", "Benchmark 3-Year Ex-Post Standard Deviation")]),
            ("Share Classes Ahead of Benchmark %",
             "Count of share classes with Excess Return > 0 / count of share classes with an Official Return for the period, "
             "by standard period and vehicle type.",
             [("01", "Share Class", "Share Class ID"), ("01", "Investment Product", "Vehicle Type"), "Excess Return"]),
            ("Fund Assets Ahead of Benchmark %",
             "Sum of Class Net Assets (DP-165, certified, Share Class NAV of the NAV of record at the as-of month-end) of share "
             "classes with Excess Return > 0 / sum of Class Net Assets of all share classes measured, by standard period. "
             "Weights are certified class net assets, never DP-008 client assets or DP-142 portfolio market value.",
             [("27", "Share Class NAV", "NAV Share Class"), ("27", "Share Class NAV", "Parent NAV Calculation"),
              ("27", "Share Class NAV", "Class Net Assets Amount"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "NAV Approval Status"), ("27", "Fund NAV Calculation", "NAV Version Number"),
              "Excess Return"]),
            ("Share Classes in Top Half of Peers %",
             "Count of share classes with Category Percentile Rank of 50 or better / count with a peer rank, by Return Period.",
             ["Peer Percentile Rank and Quartile"]),
            ("Scorecard Coverage %",
             "Share classes with Share Class Status = Active and Share Class Launch Date before the period start that have a "
             "Final or Restated Official Return for the period / all such share classes.",
             [("01", "Share Class", "Share Class Status"), ("01", "Share Class", "Share Class Launch Date"), "Official Return"]),
        ],
        inputs=[
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Subject Type",
                                          "Return Share Class", "Return Composite", "Return Period Start Date",
                                          "Return Period End Date", "Return Period Basis", "Return Fee Basis",
                                          "Return Currency", "Return Value", "Annualized Indicator", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Type", "Benchmark Return Currency", "Benchmark Return Version",
                                        "Benchmark Return Value", "Benchmark Return Status"]),
            ("32", "Ex-Post Risk Statistic", ["Statistic Subject Type", "Statistic Share Class", "Statistic Composite",
                                              "Ex-Post Statistic Type", "Statistic Period Start Date",
                                              "Statistic Period End Date", "Statistic Value", "Statistic Status"]),
            ("32", "Composite Period Statistic", ["Statistic Composite", "Composite Period End Date",
                                                  "Composite 3-Year Ex-Post Standard Deviation",
                                                  "Benchmark 3-Year Ex-Post Standard Deviation"]),
            ("32", "Performance Measurement Profile", ["Profiled Subject Type", "Profiled Share Class",
                                                       "Profiled Composite", "Return Methodology",
                                                       "Profile Effective From", "Profile Effective To"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure",
                                              "Measure Benchmark", "Risk Measure Value"]),
            ("31", "Risk Calculation Run", ["Run As-Of Date", "Run Approval Status"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("01", "Investment Strategy", ["Strategy ID", "Strategy Name"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type", "Implemented Strategy"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status", "Share Class Launch Date"]),
            ("01", "Security Identifier", ["ISIN"]),
            ("01", "GIPS Composite", ["Composite ID", "Composite Name", "Composite Benchmark"]),
            ("01", "Product Benchmark Assignment", ["Assigned Product / Share Class", "Assigned Benchmark", "Benchmark Role",
                                                    "Assignment Effective From", "Assignment Effective To"]),
            ("11", "Peer Universe", ["Peer Universe ID", "Universe Type", "Own Strategy Compared"]),
            ("11", "Peer Universe Member", ["Member Fund"]),
            ("11", "Peer Fund", ["Peer Fund ID", "ISIN", "Peer Morningstar Category"]),
            ("11", "Peer Metric Snapshot", ["Snapshot Date", "Return Period", "Total Return", "Category Percentile Rank",
                                            "Quartile Rank", "Peer Universe"]),
            ("27", "Share Class NAV", ["NAV Share Class", "Parent NAV Calculation", "Class Net Assets Amount"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Version Number", "NAV Approval Status"]),
        ],
        upstream=["DP-145", "DP-157", "DP-146", "DP-158", "DP-014", "DP-004", "DP-165", "DP-140", "DP-013"],
        refresh="Monthly",
        timeliness=("By business day 10 after month-end, after the official returns are Final (DP-145, business day 7) and "
                    "the peer vendor's month-end release is loaded in DP-014; peer columns stay blank until the release"),
        history="Month-end scorecards kept 10 years as published, plus the restated version where a DP-145 restatement changes a value",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["BI semantic model", "Dashboard", "Warehouse table", "File extract"],
        dq_rules=[
            "Every Official Return shown has Return Status Final or Restated in DP-145 and equals the DP-145 value to full precision.",
            "Every share class row has exactly one primary Product Benchmark Assignment effective at the period end, or is flagged 'no benchmark'.",
            "Peer ranks are shown only when the Peer Fund ISIN matches the own share class ISIN and the Snapshot Date equals the scorecard as-of month-end.",
            "Fund Assets Ahead of Benchmark % uses Class Net Assets of the NAV of record at the as-of month-end; the sum of weights equals the measured classes' total in DP-165.",
            "Ex-ante tracking error is taken only from a Risk Calculation Run with Run Approval Status = Approved.",
        ],
        notes=("Consumer-aligned scorecard; owns no certified number. Own returns only from DP-145 (CD-217, CD-320); peer returns "
               "stay 11 'Published Peer Return' read through DP-014 and are never mixed into own returns. Ex-ante tracking "
               "error is DP-146's certified value; ex-post statistics are DP-157's; composite statistics DP-158's. Asset "
               "weights use certified Class Net Assets from DP-165 (CD-292, CD-330), not DP-008 client assets and not "
               "DP-142 portfolio market value (Investment_Operations brief §6, hardest call 1). Mandates and SMAs are shown "
               "through their GIPS composite rows and are not asset-weighted here; whether the asset-weighted share should "
               "extend to the institutional slice of Firm AUM (DP-241) is an open question for the client. Portfolio-to-fund resolution "
               "only through DP-140 (CD-324). DP-030 boundary (CD-323): DP-030 keeps competitive positioning on vendor "
               "data and takes own share class returns from DP-145; this product is the firm's performance scorecard and "
               "DP-030 does not become a view of it. Serves FN-37 product reviews and value assessments (36, DP-109) as an "
               "input; it holds no review outcome. Classification Confidential - Licensed because peer returns and ranks "
               "are licensed vendor data (CD-164); a view without peer columns is Internal once returns are released. PII = "
               "N: the validator warns because Return Value, Statistic Value and Measured Portfolio carry conditional PII "
               "flags (individuals' account and SMA rows); this product reads only share class, composite and fund "
               "portfolio rows, so no personal data is published. Taxonomy gap: no attribute links an own share class to "
               "its 11 Peer Fund; the match is by ISIN. Taxonomy gap: 11 holds no universe-level published median, so the "
               "peer median is taken across the universe's member returns and may differ from the vendor's published "
               "median. Taxonomy gap: Performance Return has no strategy subject and no attribute names a strategy's "
               "representative composite or share class; the strategy row uses the composite whose Composite Benchmark and "
               "Implemented Strategy match, to be confirmed by performance. Open SME questions: which periods and fee basis "
               "the firm scorecard shows (net of fees assumed); whether the scorecard should show sales-charge-adjusted "
               "returns (32 Source_Notes question 12). Rests on CD-211, CD-217, CD-292, CD-293, CD-320, CD-323, CD-324, "
               "CD-330."
               "WP1 re-point (CW-203, CW-206): DP-008 publishes Client Assets instead of attributed AUM and Firm AUM's slices are DP-241's; the boundary texts are re-pointed. No input or measure changed."),
    ),

    # DP-160 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)

    "DP-161": dict(
        definition=("The coded rule base and its coverage: statutory limit provisions, rule libraries and their versioned "
                    "membership, compliance rules with their versions, sources and approvals, rule assignments to "
                    "portfolios, rule instrument lists, coding requests, the coding status of every prospectus and client "
                    "restriction, and periodic rule reviews. It combines the 33 rule objects with the restrictions they "
                    "code (01 Investment Restriction, 02 Client Restriction), the portfolio master (DP-140) and the "
                    "instrument and issuer dimensions (DP-097, DP-098), so investment compliance can show that every "
                    "restriction is coded or monitored manually and answer which rule version applied to a portfolio on a "
                    "date. The restriction stays in 01 or 02; the coded rule is 33 (CD-221)."),
        business_questions=[
            "Is every prospectus, regulatory and client restriction in force coded, monitored manually, or documented as not testable?",
            "Which rule version, at which limit and warning level, applied to a given portfolio on a given date, and who approved it?",
            "Where is a coded limit looser than the restriction or statutory provision it implements?",
            "Which active portfolios have no rule assignment, and which coding requests missed their required effective date?",
            "Which rules and libraries are overdue for their annual review under Rule 38a-1?",
        ],
        grain=("Compliance rule (CRULE-) x rule version; with rule source link (rule version x source), rule library "
               "membership (library version x rule version), rule assignment (library or rule version x portfolio x effective "
               "period), restriction coding status (source restriction x effective period), coding request, rule instrument "
               "list and member, and periodic rule review as child tables; effective-dated"),
        dimensions=["Compliance rule and version", "Rule type", "Rule library and version", "Regulatory regime",
                    "Rule source type", "Investment restriction", "Client restriction", "Regulatory limit provision",
                    "Portfolio", "Business line", "Rule instrument list", "Restriction coding status", "Effective date"],
        measures=[
            ("Restriction Coding Coverage %",
             "Restrictions in force (01 Investment Restriction with Restriction Effective From on or before the date; 02 Client "
             "Restriction with Restriction Status = Active and the date within its effective dates) whose Restriction Coding "
             "Status effective on the date is Coded / all restrictions in force; the remainder split by status (Manual "
             "Monitoring, Not Testable with Not Testable Reason, Pending Coding).",
             [("01", "Investment Restriction", "Restriction ID"), ("01", "Investment Restriction", "Restriction Effective From"),
              ("02", "Client Restriction", "Client Restriction ID"), ("02", "Client Restriction", "Restriction Status"),
              ("02", "Client Restriction", "Restriction Effective From"), ("02", "Client Restriction", "Restriction Effective To"),
              ("33", "Restriction Coding Status", "Status Investment Restriction"),
              ("33", "Restriction Coding Status", "Status Client Restriction"),
              ("33", "Restriction Coding Status", "Restriction Coding Status"),
              ("33", "Restriction Coding Status", "Not Testable Reason"),
              ("33", "Restriction Coding Status", "Coding Status Effective From"),
              ("33", "Restriction Coding Status", "Coding Status Effective To")]),
            ("Restrictions Without Coding Status",
             "Count of restrictions in force with no Restriction Coding Status row effective on the date, by Restriction "
             "Source and Restriction Category.",
             [("01", "Investment Restriction", "Restriction Source"), ("01", "Investment Restriction", "Restriction Category"),
              ("02", "Client Restriction", "Restriction Source"), ("02", "Client Restriction", "Restriction Category"),
              "Restriction Coding Coverage %"]),
            ("Coded Restrictions Without Active Rule",
             "Count of restrictions with Restriction Coding Status = Coded that have no Rule Source Link (Source Investment "
             "Restriction or Source Client Restriction) to a Compliance Rule version effective on the date (Version Effective "
             "From / To) with Rule Status = Active.",
             [("33", "Rule Source Link", "Linked Rule"), ("33", "Rule Source Link", "Linked Rule Version"),
              ("33", "Rule Source Link", "Source Investment Restriction"), ("33", "Rule Source Link", "Source Client Restriction"),
              ("33", "Compliance Rule", "Compliance Rule ID"), ("33", "Compliance Rule", "Rule Version"),
              ("33", "Compliance Rule", "Version Effective From"), ("33", "Compliance Rule", "Version Effective To"),
              ("33", "Compliance Rule", "Rule Status"), ("33", "Restriction Coding Status", "Restriction Coding Status")]),
            ("Rules Looser Than Source",
             "Count of effective rule versions whose Rule Limit Value is less strict than the linked source: for Rule Limit "
             "Type = Maximum, Rule Limit Value above the 01 Limit Value or the Statutory Limit Value of the Source Regulatory "
             "Provision; for Minimum, below it; equivalently Buffer Versus Source below zero.",
             [("33", "Compliance Rule", "Rule Limit Type"), ("33", "Compliance Rule", "Rule Limit Value"),
              ("33", "Compliance Rule", "Rule Measurement Basis"), ("01", "Investment Restriction", "Limit Value"),
              ("01", "Investment Restriction", "Measurement Basis"),
              ("33", "Regulatory Limit Provision", "Statutory Limit Value"),
              ("33", "Rule Source Link", "Source Regulatory Provision"), ("33", "Rule Source Link", "Buffer Versus Source")]),
            ("Unapproved Rule Versions in Force",
             "Count of rule versions effective on the date whose Version Approval Status is not Approved or Approved with "
             "Conditions, or whose Version Approved By equals the Coded By of the Originating Coding Request (no four-eyes).",
             [("33", "Compliance Rule", "Version Approval Status"), ("33", "Compliance Rule", "Version Approved By"),
              ("33", "Compliance Rule", "Originating Coding Request"), ("33", "Rule Coding Request", "Coding Request Reference"),
              ("33", "Rule Coding Request", "Coded By"), ("33", "Compliance Rule", "Version Effective From")]),
            ("Portfolios Without Rule Assignment",
             "Count of Portfolios with Portfolio Status = Active and Portfolio Type = Standalone Book (DP-140) with no Rule "
             "Assignment effective on the date (Assignment Effective From / To) for the portfolio, by Business Line.",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("18", "Portfolio", "Portfolio Type"),
              ("18", "Portfolio", "Business Line"), ("33", "Rule Assignment", "Assigned Portfolio"),
              ("33", "Rule Assignment", "Assignment Effective From"), ("33", "Rule Assignment", "Assignment Effective To")]),
            ("Late Coding Requests",
             "Count of Rule Coding Requests with Implementation Date after Required Effective Date, plus open requests (no "
             "Implementation Date) past Required Effective Date, by Coding Request Trigger.",
             [("33", "Rule Coding Request", "Coding Request Trigger"), ("33", "Rule Coding Request", "Required Effective Date"),
              ("33", "Rule Coding Request", "Implementation Date"), ("33", "Rule Coding Request", "Coding Approval Status")]),
            ("Rule Reviews Overdue",
             "Count of active rules and rule libraries with no Periodic Rule Review (Reviewed Rule or Reviewed Rule Library) "
             "with Rule Review Date in the last 12 months, and of reviews with Changes Requested whose Resulting Coding "
             "Request is not implemented.",
             [("33", "Periodic Rule Review", "Reviewed Rule"), ("33", "Periodic Rule Review", "Reviewed Rule Library"),
              ("33", "Periodic Rule Review", "Rule Review Date"), ("33", "Periodic Rule Review", "Annual Program Review Indicator"),
              ("33", "Periodic Rule Review", "Changes Requested"), ("33", "Periodic Rule Review", "Resulting Coding Request"),
              ("33", "Rule Library", "Rule Library Code"), ("33", "Rule Library", "Library Status")]),
            ("Unresolved List Members",
             "Count of Rule Instrument List Members effective on the date of firm-maintained lists (Members Held Here "
             "Indicator = Y) whose Member Instrument is not an active Instrument in DP-097 or whose Member Issuer has no Issuer "
             "Profile in DP-098.",
             [("33", "Rule Instrument List", "Rule Instrument List Code"),
              ("33", "Rule Instrument List", "Members Held Here Indicator"),
              ("33", "Rule Instrument List Member", "Member List"), ("33", "Rule Instrument List Member", "Member Instrument"),
              ("33", "Rule Instrument List Member", "Member Issuer"),
              ("33", "Rule Instrument List Member", "Member Effective From"),
              ("33", "Rule Instrument List Member", "Member Effective To"), ("17", "Instrument", "Instrument ID"),
              ("17", "Instrument", "Instrument Status"), ("17", "Issuer Profile", "Issuer Party")]),
            ("Hard-Block Rule Share %",
             "Active rule versions with Hard Block Indicator = Y / all active rule versions, by Rule Type.",
             [("33", "Compliance Rule", "Hard Block Indicator"), ("33", "Compliance Rule", "Rule Type"),
              ("33", "Compliance Rule", "Rule Status")]),
        ],
        inputs=[
            ("33", "Regulatory Limit Provision", ["Provision Code", "Provision Citation", "Limit Component Description",
                                                  "Provision Regulator", "Applicable Regulatory Regimes",
                                                  "Statutory Limit Value", "Provision Limit Type",
                                                  "Provision Measurement Basis", "Provision Effective From",
                                                  "Provision Effective To"]),
            ("33", "Rule Library", ["Rule Library Code", "Rule Library Version", "Library Regulatory Regimes",
                                    "Library Business Lines", "Library Owner", "Library Status",
                                    "Library Version Effective From", "Library Version Effective To"]),
            ("33", "Rule Library Membership", ["Membership Library", "Membership Library Version", "Member Rule",
                                               "Member Rule Version"]),
            ("33", "Compliance Rule", ["Compliance Rule ID", "Rule Version", "Rule Name", "Rule Type",
                                       "Rule Logic Expression", "Rule Limit Type", "Rule Limit Value",
                                       "Rule Upper Limit Value", "Warning Value", "Rule Measurement Basis",
                                       "Rule Applicability", "Hard Block Indicator", "Look-Through Indicator",
                                       "Rule Instrument Lists Read", "Risk Measure Read", "Exposure Method Read",
                                       "Originating Coding Request", "Version Approval Status", "Version Approved By",
                                       "Version Approved Date", "Version Effective From", "Version Effective To",
                                       "Rule Status", "Rule Status Effective From", "Rule Status Effective To"]),
            ("33", "Rule Source Link", ["Linked Rule", "Linked Rule Version", "Rule Source Type",
                                        "Source Investment Restriction", "Source Client Restriction",
                                        "Source Regulatory Provision", "Interpretation Note", "Buffer Versus Source"]),
            ("33", "Rule Assignment", ["Assigned Rule", "Assigned Rule Version", "Assigned Rule Library",
                                       "Assigned Library Version", "Assigned Portfolio", "Assignment Inclusion Type",
                                       "Assignment Basis", "Assignment Effective From", "Assignment Effective To"]),
            ("33", "Rule Instrument List", ["Rule Instrument List Code", "Rule Instrument List Version",
                                            "Rule Instrument List Type", "Members Held Here Indicator",
                                            "Source Sustainability Exclusion List", "Restricted List Source",
                                            "Source Client Restriction", "List Source Dataset", "List Refresh Frequency",
                                            "List Status"]),
            ("33", "Rule Instrument List Member", ["Member List", "Member Instrument", "Member Issuer",
                                                   "Member Inclusion Type", "Membership Reason", "Member Effective From",
                                                   "Member Effective To"]),
            ("33", "Rule Coding Request", ["Coding Request Reference", "Coding Request Trigger",
                                           "Triggering Investment Restriction", "Triggering Client Restriction",
                                           "Triggering Product Change", "Required Effective Date", "Coded By",
                                           "Coding Approved By", "Coding Approval Status", "Implementation Date"]),
            ("33", "Restriction Coding Status", ["Status Investment Restriction", "Status Client Restriction",
                                                 "Restriction Coding Status", "Not Testable Reason",
                                                 "Coding Status Effective From", "Coding Status Effective To"]),
            ("33", "Periodic Rule Review", ["Reviewed Rule", "Reviewed Rule Library", "Rule Review Date",
                                            "Annual Program Review Indicator", "Rule Reviewer", "Rule Review Outcome",
                                            "Changes Requested", "Resulting Coding Request"]),
            ("01", "Investment Restriction", ["Restriction ID", "Restriction Source", "Restriction Category",
                                              "Restriction Description", "Limit Type", "Limit Value", "Measurement Basis",
                                              "Restriction Effective From"]),
            ("02", "Client Restriction", ["Client Restriction ID", "Restricted Party", "Restricted Accounts",
                                          "Restriction Category", "Restriction Source", "Restriction Status",
                                          "Restriction Effective From", "Restriction Effective To"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Status"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Profile Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-140", "DP-004", "DP-077", "DP-097", "DP-098", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day for rules, assignments and coding status effective that day; changes during the day appear the next morning",
        history=("Every rule version, library version, assignment and coding status row kept effective-dated and never "
                 "overwritten, for at least 6 years after the version ends (Rule 31a-2 and Rule 204-2 retention)"),
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Compliance Rule version with a Version Effective From has Version Approval Status Approved or Approved with Conditions and a Version Approved By.",
            "Every Rule Source Link fills exactly the one source reference its Rule Source Type names.",
            "Every Rule Assignment pins a rule version or a library version, never a bare rule or library, and names a portfolio that exists in DP-140.",
            "Effective periods of the Restriction Coding Status rows of one restriction do not overlap.",
            "Firm-maintained list members (Members Held Here Indicator = Y) exist only for lists with no Source Sustainability Exclusion List and no Restricted List Source.",
        ],
        notes=("Master concepts read, not remastered: Compliance Rule (CRULE-), Rule Library, Rule Assignment and Restriction "
               "Coding Status (33, CD-221). Certified numbers: none. Restriction versus rule (CD-221): restriction text, "
               "limit, source and category stay in 01 Investment Restriction and 02 Client Restriction; 01 Investment "
               "Restriction is read directly because no foundational product publishes it (DP-004 does not carry it), and "
               "02 Client Restriction is read with DP-077 Client Restrictions & KYC Status upstream for lineage. Sourced "
               "lists (CD-224): lists taken from 34 exclusion lists and the 38 restricted list are read at source; their "
               "members are not stored or published here. A rule that reads a 31 measure names it (Risk Measure Read, "
               "Exposure Method Read); the value comes from DP-146 or DP-153 in DP-162 (CD-223). Portfolios through DP-140 "
               "(CD-324); instruments and issuers through DP-097 and DP-098 (CD-300); coders, approvers, library owners and "
               "reviewers through DP-192. Tier: consumer for now; candidate for promotion to foundational at review if 25 or "
               "35 products need the rule master directly (brief question 5); DP-162 and DP-163 depend on it. PII = Y: "
               "Assigned Portfolio identifies individuals' SMA books and coders and approvers are employees; client "
               "restrictions are client confidential. Operating model: in house (brief §2). Taxonomy gap: 01 Investment "
               "Restriction has no reference to the product or mandate it restricts and no end date or status, so "
               "'in force' is taken as effective from on or before the date with no superseding row, and restrictions are "
               "joined to portfolios only through the rule assignments that code them. Taxonomy gap: Rule Coding Request has "
               "no received date (33 Source_Notes size trims), so coding cycle time cannot be measured; lateness is against "
               "Required Effective Date. Taxonomy gap: the Restriction Coding Status values (Coded, Manual Monitoring, Not "
               "Testable, Pending Coding) are assumed from the 33 list and to confirm. Open SME questions (33 Source_Notes "
               "§4): 1 compliance engines; 2 internal buffers and their approval; 3 restrictions not codable today; 9 rule "
               "version retention; 10 ERISA party-in-interest lists. Rests on CD-221, CD-223, CD-224, CD-296, CD-300, "
               "CD-324. W1 re-point (CW-902): Client Restriction Restricted Account is read from Restricted Accounts (one "
               "restriction may name several 15 accounts)."),
    ),

    "DP-162": dict(
        definition=("Every pre-trade, intraday and post-trade compliance run with its rule results, the alerts raised, their "
                    "dispositions and pre-trade overrides, guideline waivers in force and manual checks of restrictions the "
                    "engine cannot test. It combines the 33 monitoring objects with the coded rules of DP-161, orders from "
                    "DP-123, portfolios from DP-140 and the risk measures rules read from DP-146, so compliance analysts work "
                    "the alert queue from it, and trading and portfolio management see why an order was blocked or "
                    "released and on whose approval."),
        business_questions=[
            "Which alerts are open, by severity and age, and who is working them?",
            "Was every order checked before release, which orders failed and which were released by an override of a hard rule?",
            "Did every portfolio with assigned rules get a post-trade run for the business date, and how close is each result to its limit?",
            "Which guideline waivers are in force or expiring, and were any results evaluated against an unapproved waiver?",
            "Which manually monitored restrictions have no completed manual check for the period, or an exception reported?",
        ],
        grain=("Compliance rule result (compliance check run x portfolio x rule version x evaluated issuer, instrument or "
               "group); with compliance check run (CCHK-), pre-trade check subject and member (run x tested order), "
               "compliance alert (CALERT-) with its dispositions and override approvals, guideline waiver and manual "
               "compliance check (source restriction x portfolio x check period) as companion facts"),
        dimensions=["Compliance check run type and trigger", "Run timestamp and business date", "Portfolio", "Business line",
                    "Compliance rule and version", "Rule type", "Hard block indicator", "Evaluated issuer and instrument",
                    "Rule result status", "Alert severity and status", "Disposition outcome", "Trade order",
                    "Guideline waiver", "Restriction"],
        measures=[
            ("Check Runs",
             "Count of Compliance Check Runs by Compliance Check Run Type, Check Run Trigger and business date of Run "
             "Timestamp; evidential period-end runs (Evidential Period-End Run Indicator = Y) counted separately.",
             [("33", "Compliance Check Run", "Compliance Check Run ID"),
              ("33", "Compliance Check Run", "Compliance Check Run Type"), ("33", "Compliance Check Run", "Check Run Trigger"),
              ("33", "Compliance Check Run", "Run Timestamp"),
              ("33", "Compliance Check Run", "Evidential Period-End Run Indicator")]),
            ("Pre-Trade Check Coverage %",
             "Trade Orders created in the period (DP-123, Order Created Timestamp) that appear as a Checked Trade Order of a "
             "Check Subject Member or as the Tested Trade Order of a Pre-Trade Check Subject / all trade orders created.",
             [("25", "Trade Order", "Trade Order ID"), ("25", "Trade Order", "Order Created Timestamp"),
              ("33", "Check Subject Member", "Checked Trade Order"), ("33", "Pre-Trade Check Subject", "Tested Trade Order")]),
            ("Pre-Trade Fail Rate %",
             "Check Subject Members with Initial Check Outcome = Fail / all Check Subject Members, by rule type of the failing "
             "results and portfolio business line.",
             [("33", "Check Subject Member", "Member Check Run"), ("33", "Check Subject Member", "Initial Check Outcome"),
              ("33", "Compliance Rule", "Rule Type")]),
            ("Orders Released by Override",
             "Count of Check Subject Members with Releasing Override filled whose Pre-Trade Override Approval has Override "
             "Approval Status = Approved, and the subset where the overridden result's rule has Hard Block Indicator = Y.",
             [("33", "Check Subject Member", "Releasing Override"), ("33", "Check Subject Member", "Compliance Check Outcome"),
              ("33", "Pre-Trade Override Approval", "Override Alert"),
              ("33", "Pre-Trade Override Approval", "Override Approval Status"), ("33", "Compliance Rule", "Hard Block Indicator")]),
            ("Self-Approved Overrides",
             "Count of Pre-Trade Override Approvals with Override Approval Status = Approved and Override Approver equal to "
             "Override Requested By.",
             [("33", "Pre-Trade Override Approval", "Override Requested By"),
              ("33", "Pre-Trade Override Approval", "Override Approver"),
              ("33", "Pre-Trade Override Approval", "Override Approval Status")]),
            ("Post-Trade Run Coverage %",
             "Portfolios with a Rule Assignment effective on the business date that have a Compliance Rule Result from a run "
             "with Compliance Check Run Type = Post-Trade and Run Timestamp on that business date / all such portfolios.",
             [("33", "Rule Assignment", "Assigned Portfolio"), ("33", "Rule Assignment", "Assignment Effective From"),
              ("33", "Rule Assignment", "Assignment Effective To"), ("33", "Compliance Rule Result", "Result Check Run"),
              ("33", "Compliance Rule Result", "Result Portfolio"), ("33", "Compliance Check Run", "Compliance Check Run Type"),
              ("33", "Compliance Check Run", "Run Timestamp")]),
            ("Results by Status and Headroom",
             "Count of Compliance Rule Results by Compliance Rule Result Status, and Headroom = Limit Applied - Measured Value "
             "for a maximum rule (Measured Value - Limit Applied for a minimum rule), with results inside the Warning Value "
             "listed.",
             [("33", "Compliance Rule Result", "Compliance Rule Result Status"),
              ("33", "Compliance Rule Result", "Measured Value"), ("33", "Compliance Rule Result", "Limit Applied"),
              ("33", "Compliance Rule Result", "Evaluated Rule"), ("33", "Compliance Rule Result", "Evaluated Rule Version"),
              ("33", "Compliance Rule", "Rule Limit Type"), ("33", "Compliance Rule", "Warning Value")]),
            ("Open Alerts and Age",
             "Count of Compliance Alerts with Alert Status not closed, by Alert Severity and Alert Assigned To, with age = "
             "as-of timestamp - Alert Raised Timestamp in buckets (under 1 day, 1 to 5, over 5 business days).",
             [("33", "Compliance Alert", "Compliance Alert ID"), ("33", "Compliance Alert", "Alert Status"),
              ("33", "Compliance Alert", "Alert Severity"), ("33", "Compliance Alert", "Alert Raised Timestamp"),
              ("33", "Compliance Alert", "Alert Assigned To")]),
            ("Time to First Disposition",
             "Median of Disposition Timestamp of the alert's first Alert Disposition (lowest Disposition Sequence) - Alert "
             "Raised Timestamp, by Alert Severity.",
             [("33", "Alert Disposition", "Disposed Alert"), ("33", "Alert Disposition", "Disposition Sequence"),
              ("33", "Alert Disposition", "Disposition Timestamp"), ("33", "Compliance Alert", "Alert Raised Timestamp"),
              ("33", "Compliance Alert", "Alert Severity")]),
            ("Unreviewed Dispositions",
             "Count of Alert Dispositions with Disposition Reviewed By null or equal to Disposed By, by Alert Disposition "
             "Outcome.",
             [("33", "Alert Disposition", "Disposed By"), ("33", "Alert Disposition", "Disposition Reviewed By"),
              ("33", "Alert Disposition", "Alert Disposition Outcome")]),
            ("Waivers Expiring in 30 Days",
             "Count of Guideline Waivers with Waiver Approval Status = Approved and Waiver Effective To within the next 30 "
             "days, by Waived Rule and Waived Portfolio; and Compliance Rule Results whose Applied Guideline Waiver is not "
             "Approved or not effective on the run date.",
             [("33", "Guideline Waiver", "Guideline Waiver Reference"), ("33", "Guideline Waiver", "Waived Rule"),
              ("33", "Guideline Waiver", "Waived Portfolio"), ("33", "Guideline Waiver", "Waiver Approval Status"),
              ("33", "Guideline Waiver", "Waiver Effective From"), ("33", "Guideline Waiver", "Waiver Effective To"),
              ("33", "Compliance Rule Result", "Applied Guideline Waiver")]),
            ("Manual Checks Missing",
             "Count of restriction x portfolio pairs whose Restriction Coding Status effective in the period is Manual "
             "Monitoring and that have no Manual Compliance Check with Check Period Start Date / End Date covering the "
             "period; plus checks with Manual Check Result = Exception.",
             [("33", "Restriction Coding Status", "Status Investment Restriction"),
              ("33", "Restriction Coding Status", "Status Client Restriction"),
              ("33", "Restriction Coding Status", "Restriction Coding Status"),
              ("33", "Manual Compliance Check", "Checked Investment Restriction"),
              ("33", "Manual Compliance Check", "Checked Client Restriction"),
              ("33", "Manual Compliance Check", "Checked Portfolio"),
              ("33", "Manual Compliance Check", "Check Period Start Date"),
              ("33", "Manual Compliance Check", "Check Period End Date"),
              ("33", "Manual Compliance Check", "Manual Check Result")]),
            ("Risk Results on Unapproved Runs",
             "Count of Compliance Rule Results whose Source Risk Measurement is a Portfolio Risk Measure from a Risk "
             "Calculation Run with Run Approval Status other than Approved (DP-146).",
             [("33", "Compliance Rule Result", "Source Risk Measurement"),
              ("31", "Portfolio Risk Measure", "Measure Calculation Run"), ("31", "Risk Calculation Run", "Run Approval Status")]),
        ],
        inputs=[
            ("33", "Compliance Check Run", ["Compliance Check Run ID", "Compliance Check Run Type", "Check Run Trigger",
                                            "Run Timestamp", "Holdings As-Of Timestamp", "Run Batch Reference",
                                            "Evidential Period-End Run Indicator"]),
            ("33", "Pre-Trade Check Subject", ["Tested Proposed Trade", "Tested Trade Order", "Tested Block Order",
                                               "Subject Check Outcome"]),
            ("33", "Check Subject Member", ["Member Check Run", "Checked Trade Order", "Tested Quantity",
                                            "Initial Check Outcome", "Compliance Check Outcome", "Releasing Override",
                                            "Outcome Timestamp"]),
            ("33", "Compliance Rule Result", ["Result Check Run", "Result Portfolio", "Evaluated Rule",
                                              "Evaluated Rule Version", "Evaluated Issuer", "Evaluated Instrument",
                                              "Evaluated Group Key", "Compliance Rule Result Status", "Measured Value",
                                              "Limit Applied", "Applied Guideline Waiver", "Numerator Value",
                                              "Denominator Value", "Source Risk Measurement"]),
            ("33", "Compliance Alert", ["Compliance Alert ID", "Source Rule Result", "Alert Severity", "Alert Status",
                                        "Alert Raised Timestamp", "Alert Assigned To"]),
            ("33", "Alert Disposition", ["Disposed Alert", "Disposition Sequence", "Alert Disposition Outcome",
                                         "Disposition Rationale", "Disposed By", "Disposition Reviewed By",
                                         "Disposition Timestamp", "Related Data Quality Issue"]),
            ("33", "Pre-Trade Override Approval", ["Override Alert", "Override Approval Sequence", "Override Reason",
                                                   "Override Requested By", "Override Approver",
                                                   "Override Approval Status", "Override Decision Timestamp",
                                                   "Override Conditions"]),
            ("33", "Guideline Waiver", ["Guideline Waiver Reference", "Waived Rule", "Waived Portfolio",
                                        "Waived Limit Value", "Waived Measurement Basis", "Waiver Scope Issuer",
                                        "Waiver Basis", "Client Approver", "Internal Approver", "Board Approval Date",
                                        "Waiver Approval Status", "Waiver Effective From", "Waiver Effective To"]),
            ("33", "Manual Compliance Check", ["Checked Investment Restriction", "Checked Client Restriction",
                                               "Checked Portfolio", "Check Period Start Date", "Check Period End Date",
                                               "Manual Check Result", "Exception Description", "Attested By",
                                               "Attestation Timestamp"]),
            ("33", "Compliance Rule", ["Compliance Rule ID", "Rule Version", "Rule Name", "Rule Type", "Rule Limit Type",
                                       "Rule Limit Value", "Warning Value", "Hard Block Indicator", "Risk Measure Read",
                                       "Rule Status"]),
            ("33", "Rule Assignment", ["Assigned Rule", "Assigned Rule Library", "Assigned Portfolio",
                                       "Assignment Effective From", "Assignment Effective To"]),
            ("33", "Restriction Coding Status", ["Status Investment Restriction", "Status Client Restriction",
                                                 "Restriction Coding Status", "Coding Status Effective From",
                                                 "Coding Status Effective To"]),
            ("25", "Trade Order", ["Trade Order ID", "Order Portfolio", "Order Instrument", "Order Created Timestamp",
                                   "Trade Order Status"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure",
                                              "Risk Measure Value"]),
            ("31", "Risk Calculation Run", ["Run As-Of Date", "Run Approval Status"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line", "Portfolio Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-161", "DP-123", "DP-140", "DP-142", "DP-146", "DP-153", "DP-097", "DP-098", "DP-192"],
        refresh="Intraday",
        timeliness=("Pre-trade runs, alerts and overrides within 5 minutes of the engine event during trading hours; "
                    "post-trade results for the business date by 8am ET on T+1"),
        history=("Every run, result, alert, disposition, override and waiver kept as recorded for at least 6 years (Rule "
                 "38a-1, 31a-2 and 204-2 evidence); evidential period-end runs kept for the life of the fund plus 6 years"),
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "Event stream", "API", "BI semantic model"],
        dq_rules=[
            "Every Compliance Rule Result references a rule version that is in a Rule Assignment of the result's portfolio effective on the run date.",
            "Every Check Subject Member with Releasing Override filled has a Pre-Trade Override Approval with Override Approval Status = Approved and an Override Approver different from the Override Requested By.",
            "Every Compliance Alert references one Source Rule Result whose Compliance Rule Result Status is Warning or Fail.",
            "Limit Applied equals the rule version's Rule Limit Value unless Applied Guideline Waiver is filled, in which case it equals the Waived Limit Value of an approved waiver effective on the run date.",
            "Each post-trade run's Holdings As-Of Timestamp is no earlier than the end of the prior business day.",
        ],
        notes=("W4 re-point (CW-930): 33 Pre-Trade Check Subject.Tested Deal dropped, no successor (the 30 Deal retires); no measure read it. "
               "Master concepts read, not remastered: Compliance Check Run (CCHK-), Compliance Rule Result, Compliance Alert "
               "(CALERT-), Pre-Trade Override Approval and Guideline Waiver (33, CD-221). Certified numbers: none. "
               "Orders (CD-180, CD-221, CD-314): trade orders come from DP-123 Trade Order, Execution & Allocation Record "
               "(25), which compliance products read upstream; 25 copies the per-order outcome from Check Subject Member "
               "and DP-123 must never list this product upstream. Rules that read 31 measures name them; values come from "
               "DP-146 (ex-ante VaR, tracking error and exposures, certified from approved runs) and DP-153 (counterparty "
               "exposure), never copied into 33 (CD-223). Rule definitions come from DP-161; portfolios from DP-140 "
               "(CD-324); holdings context from DP-142; instruments and issuers from DP-097 and DP-098; analysts and "
               "approvers from DP-192. Breaches raised from alerts are DP-163's (CD-222); this product reports the "
               "disposition outcome only, so it does not depend on DP-163. Evidential period-end runs support the RIC "
               "diversification tests, which 27 and 35 determine (CD-224). PII = Y: Result Portfolio, Waived Portfolio and Checked "
               "Portfolio identify individuals' SMA books; analysts, approvers and attesters are employees; Client Approver "
               "is a client contact. Operating model: in house (brief §2); a vendor engine changes the source, not the "
               "grain. Taxonomy gap: Compliance Alert has no closed timestamp (33 Source_Notes size trims), so alert "
               "resolution time is taken from the last disposition. Taxonomy gap: 33 holds no order release timestamp, so "
               "'checked before release' is tested against the 25 Trade Order Event in DP-123. Taxonomy gap: Headroom was "
               "removed from 33 and is derived here. Taxonomy gap: the Initial Check Outcome, Alert Status and Manual Check "
               "Result values (Fail, closed, Exception) are assumed from the 33 lists, to confirm. Thresholds (5-minute "
               "latency, alert age buckets, 30-day waiver horizon) are drafting assumptions. Open SME questions (33 "
               "Source_Notes §4): 4 who approves overrides of hard rules; 7 who monitors 18f-4 and 22e-4 limits; 12 block "
               "evaluation per member order; 13 which run is evidential. Rests on CD-180, CD-221, CD-222, CD-223, CD-224, "
               "CD-314, CD-324."),
    ),

    "DP-163": dict(
        definition=("Every breach of a coded investment rule from detection to cure: the breached rule and source "
                    "restrictions, cause, type, severity and materiality, remediation actions, loss calculations, and the "
                    "CCO's review with board (or CIT trustee) and regulator escalation decisions. It combines the 33 breach "
                    "objects with the rule library (DP-161), the alerts that raised them (DP-162), the portfolio master "
                    "(DP-140) and the trade error loss where a trade error caused the breach (DP-125), so compliance manages "
                    "cure deadlines, client service sees which mandates need notice, and boards and risk see breach trends "
                    "by cause. It is the one product that publishes the investment breach (CD-222)."),
        business_questions=[
            "Which breaches are open, which are past their cure deadline, and what remediation is outstanding?",
            "How many active and passive breaches did we have this quarter, by cause, rule type, business line and fund or mandate?",
            "What did breaches cost, net of compensation, and is every loss recorded in exactly one place?",
            "Which material breaches still need CCO sign-off, board or CIT trustee escalation, or a regulator notification?",
            "Which breaches on client mandates require client notice, and has it been given?",
        ],
        grain=("Investment breach (BREACH-: portfolio x compliance rule x issuer, instrument or group x breach start date); "
               "with remediation action (breach x sequence), loss calculation (breach x version), breach review (breach x "
               "sequence) and additional source restriction as child tables; daily status snapshot"),
        dimensions=["Portfolio", "Business line", "Implemented fund, mandate or account", "Compliance rule and rule type",
                    "Breached restriction", "Breached issuer and instrument", "Breach type (active or passive)",
                    "Breach cause", "Breach severity", "Material breach indicator", "Breach status",
                    "Detection, cure and closure dates", "Remediation action type"],
        measures=[
            ("Open Breaches",
             "Count of Investment Breaches with Breach Closure Date null (or Breach Status not closed) on the as-of date, by "
             "Breach Type, Breach Cause, Breach Severity and Material Breach Indicator.",
             [("33", "Investment Breach", "Investment Breach ID"), ("33", "Investment Breach", "Breach Status"),
              ("33", "Investment Breach", "Breach Closure Date"), ("33", "Investment Breach", "Breach Type"),
              ("33", "Investment Breach", "Breach Cause"), ("33", "Investment Breach", "Breach Severity"),
              ("33", "Investment Breach", "Material Breach Indicator")]),
            ("New Breaches",
             "Count of Investment Breaches with Breach Detected Date in the period, by Breach Type, Breach Cause and the Rule "
             "Type of the Breached Rule.",
             [("33", "Investment Breach", "Breach Detected Date"), ("33", "Investment Breach", "Breached Rule"),
              ("33", "Compliance Rule", "Rule Type"), ("33", "Investment Breach", "Breach Type"),
              ("33", "Investment Breach", "Breach Cause")]),
            ("Detection Lag Days",
             "Breach Detected Date - Breach Start Date per breach; median and count above 1 business day, by Breach Type and "
             "origin (Originating Alert or Originating Manual Check).",
             [("33", "Investment Breach", "Breach Start Date"), ("33", "Investment Breach", "Breach Detected Date"),
              ("33", "Investment Breach", "Originating Alert"), ("33", "Investment Breach", "Originating Manual Check")]),
            ("Breaches Past Cure Deadline",
             "Count of breaches with Cure Date null and Cure Deadline Date before the as-of date, and of cured breaches with "
             "Cure Date after Cure Deadline Date, by Breach Type.",
             [("33", "Investment Breach", "Cure Deadline Date"), ("33", "Investment Breach", "Cure Date"),
              ("33", "Investment Breach", "Cure Action"), ("33", "Investment Breach", "Breach Type")]),
            ("Days to Cure",
             "Median of Cure Date - Breach Detected Date over breaches cured in the period, by Breach Type and Cure Action.",
             [("33", "Investment Breach", "Cure Date"), ("33", "Investment Breach", "Breach Detected Date"),
              ("33", "Investment Breach", "Cure Action")]),
            ("Breach Loss Amount",
             "One loss, one home (CD-244): where Related Trade Error is filled, Error Gain or Loss Amount of that 25 Trade "
             "Error (DP-125); otherwise Breach Loss Amount of the latest Loss Calculation Version with Loss Calculation "
             "Approval Status = Approved; summed by period of Breach Detected Date. NAV impact (Related NAV Error Case, 27) is "
             "excluded and counted separately.",
             [("33", "Investment Breach", "Related Trade Error"), ("25", "Trade Error", "Trade Error Reference"),
              ("25", "Trade Error", "Error Gain or Loss Amount"), ("33", "Breach Loss Calculation", "Calculated Breach"),
              ("33", "Breach Loss Calculation", "Loss Calculation Version"),
              ("33", "Breach Loss Calculation", "Breach Loss Amount"),
              ("33", "Breach Loss Calculation", "Loss Calculation Approval Status"),
              ("33", "Investment Breach", "Related NAV Error Case")]),
            ("Compensation Paid",
             "Compensation Amount of the latest approved Loss Calculation, or Reimbursement Amount of the related Trade Error, "
             "by Compensating Entity.",
             [("33", "Breach Loss Calculation", "Compensation Amount"),
              ("33", "Breach Loss Calculation", "Compensating Entity"), ("25", "Trade Error", "Reimbursement Amount"),
              "Breach Loss Amount"]),
            ("Remediation Actions Overdue",
             "Count of Breach Remediation Actions with Remediation Completed Date null and Remediation Due Date before the "
             "as-of date, by Remediation Action Type and Remediation Action Owner.",
             [("33", "Breach Remediation Action", "Remediated Breach"),
              ("33", "Breach Remediation Action", "Remediation Action Type"),
              ("33", "Breach Remediation Action", "Remediation Action Owner"),
              ("33", "Breach Remediation Action", "Remediation Due Date"),
              ("33", "Breach Remediation Action", "Remediation Completed Date")]),
            ("Material Breaches Without CCO Sign-Off",
             "Count of breaches with Material Breach Indicator = Y that are cured or older than 30 days and have no Breach "
             "Review with CCO Sign-Off Date filled.",
             [("33", "Investment Breach", "Material Breach Indicator"), ("33", "Breach Review", "Reviewed Breach"),
              ("33", "Breach Review", "CCO Sign-Off Date"), ("33", "Breach Review", "CCO Sign-Off By"),
              ("33", "Investment Breach", "Breach Detected Date")]),
            ("Escalations Pending",
             "Count of Breach Reviews with Regulatory Notification Required Indicator = Y and Resulting Reportable Fund Event "
             "null (regulator notification not yet raised in 35), and with Board Reportable Indicator = Y, by fund.",
             [("33", "Breach Review", "Regulatory Notification Required Indicator"),
              ("33", "Breach Review", "Resulting Reportable Fund Event"), ("33", "Breach Review", "Board Reportable Indicator"),
              ("18", "Portfolio Implementation Link", "Implemented Product")]),
            ("Client Notice Gaps",
             "Count of breaches on portfolios whose primary Portfolio Implementation Link (DP-140) is to a mandate or managed "
             "account that have no 12 Breach Notification naming them as Related Investment Breach, or whose notification has "
             "Client Notification Required Indicator = Y and Client Notified Timestamp null.",
             [("18", "Portfolio Implementation Link", "Implementing Portfolio"),
              ("18", "Portfolio Implementation Link", "Implemented Mandate"),
              ("18", "Portfolio Implementation Link", "Managed Account"),
              ("18", "Portfolio Implementation Link", "Primary Implementation Indicator"),
              ("33", "Investment Breach", "Breached Portfolio"), ("12", "Breach Notification", "Related Investment Breach"),
              ("12", "Breach Notification", "Client Notification Required Indicator"),
              ("12", "Breach Notification", "Client Notified Timestamp")]),
            ("Repeat Breaches",
             "Count of portfolio x rule pairs with two or more breaches whose Breach Start Date falls in the trailing 12 "
             "months.",
             [("33", "Investment Breach", "Breached Portfolio"), ("33", "Investment Breach", "Breached Rule"),
              ("33", "Investment Breach", "Breach Start Date")]),
        ],
        inputs=[
            ("33", "Investment Breach", ["Investment Breach ID", "Breached Portfolio", "Breached Rule", "Breached Issuer",
                                         "Breached Instrument", "Breached Group Key", "Breached Restriction",
                                         "Breached Client Restriction", "Originating Alert", "Originating Manual Check",
                                         "Breach Type", "Breach Cause", "Breach Start Date", "Breach Detected Date",
                                         "Breach Severity", "Material Breach Indicator", "Cure Deadline Date",
                                         "Cure Action", "Cure Date", "Related Trade Error", "Related NAV Error Case",
                                         "Breach Status", "Breach Closure Date"]),
            ("33", "Breached Source Restriction", ["Source Breach", "Additional Breached Restriction",
                                                   "Additional Breached Client Restriction"]),
            ("33", "Breach Remediation Action", ["Remediated Breach", "Remediation Action Sequence",
                                                 "Remediation Action Type", "Remediation Action Description",
                                                 "Remediation Action Owner", "Remediation Due Date",
                                                 "Remediation Completed Date", "Implementing Trade Order"]),
            ("33", "Breach Loss Calculation", ["Calculated Breach", "Loss Calculation Version", "Loss Calculation Method",
                                               "Breach Loss Amount", "Compensation Amount", "Compensating Entity",
                                               "Loss Calculation Approval Status", "Loss Calculation Approved By"]),
            ("33", "Breach Review", ["Reviewed Breach", "Breach Review Sequence", "Root Cause Description",
                                     "Control Improvement Actions", "Regulatory Notification Required Indicator",
                                     "Resulting Reportable Fund Event", "Board Reportable Indicator",
                                     "CCO Sign-Off By", "CCO Sign-Off Date"]),
            ("33", "Compliance Rule", ["Compliance Rule ID", "Rule Version", "Rule Name", "Rule Type",
                                       "Hard Block Indicator", "Version Effective From", "Version Effective To"]),
            ("33", "Guideline Waiver", ["Guideline Waiver Reference", "Waived Rule", "Waived Portfolio",
                                        "Waiver Approval Status", "Waiver Effective From", "Waiver Effective To"]),
            ("33", "Compliance Alert", ["Compliance Alert ID", "Alert Raised Timestamp"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line", "Portfolio Status"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type",
                                                     "Implemented Product", "Implemented Mandate", "Managed Account",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("25", "Trade Error", ["Trade Error Reference", "Affected Portfolio", "Error Gain or Loss Amount",
                                   "Reimbursement Amount", "Trade Error Status"]),
            ("12", "Breach Notification", ["Breach Notification ID", "Related Investment Breach",
                                           "Client Notification Required Indicator", "Client Notified Timestamp"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-161", "DP-162", "DP-140", "DP-192", "DP-097", "DP-098", "DP-125", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET each business day for breaches detected through the prior day's post-trade run; status changes during the day appear the next morning",
        history=("Every breach with its full remediation, loss and review history kept for at least 6 years after closure "
                 "(Rule 38a-1, 31a-2 and 204-2), daily status snapshots kept 3 years"),
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Investment Breach references a Breached Rule that is a 33 Compliance Rule and a Breached Portfolio that exists in DP-140.",
            "Every breach fills at most one of Breached Restriction and Breached Client Restriction, and has exactly one of Originating Alert or Originating Manual Check filled.",
            "A breach with Related Trade Error filled has no approved Breach Loss Calculation (one loss, one home).",
            "Cure Date and Breach Closure Date, when filled, are on or after Breach Detected Date, which is on or after Breach Start Date.",
            "Every breach with Material Breach Indicator = Y and Breach Closure Date filled has a Breach Review with CCO Sign-Off Date.",
            "No breach is raised on a portfolio and rule covered by an approved Guideline Waiver effective on the Breach Start Date.",
        ],
        notes=("Master concepts read, not remastered: Investment Breach (BREACH-), Breach Remediation Action, Breach Loss "
               "Calculation and Breach Review (33, CD-222). Certified numbers: none. Boundaries: client notification is 12's "
               "(Breach Notification references the breach and copies five of its facts) and regulator notification is "
               "35's (Reportable Fund Event); this product reads 12 Breach Notification only to show notice gaps, where the "
               "relationship lives in 12 (rule 2 exception), and lists no 12 product upstream. CD-323: DP-042 Institutional "
               "Client Health & Service adds this product upstream for breach facts; DP-042's owner makes that change, and "
               "this product must never list DP-042 upstream. One loss, one home (CD-244): a breach caused by a trade "
               "error takes its loss from the 25 Trade Error (read through DP-125); Breach Loss Calculation is used only "
               "otherwise; NAV impact is a 27 NAV Error Case referenced by key; 37 reads the loss for operational loss "
               "events. Risk limit exceedances (RLEX-) are DP-154 and are never called breaches (CD-223). Rules come from "
               "DP-161, alerts from DP-162, portfolios and their fund, mandate and account links from DP-140 (CD-324), "
               "issuers and instruments from DP-097 and DP-098, owners and signers from DP-192, compensating legal entities "
               "from DP-013. PII = Y: Breached Portfolio identifies individuals' SMA books; owners, approvers and the CCO "
               "are employees. Operating model: in house (brief §2). Taxonomy gap: the breached rule version is not held "
               "(33 Source_Notes size trims); it is the version effective at Breach Start Date. Taxonomy gap: 33 has no "
               "client notification deadline (12's) and no compensation paid date. Taxonomy gap: the Breach Type values "
               "(active, passive) and Breach Status values are assumed from the shared lists, to confirm. The 30-day CCO "
               "sign-off window is a drafting assumption. Open SME questions (33 Source_Notes §4): 5 breach materiality "
               "policy and escalation; 6 loss calculation and who pays. Rests on CD-215, CD-222, CD-223, CD-224, CD-244, "
               "CD-323, CD-324. "
               "W1b re-point (CW-933): Breach Review.Depositary Notification Date dropped, no successor (CW-933; US funds have "
               "no depositary, the board or CIT trustee escalation is Board Reportable Indicator); 'Escalations Pending' keeps "
               "its regulator and board tests and no longer reads it; definition and question re-worded."),
    ),

    # ===================================== 17 and 21: security master and data quality =====================================
    "DP-102": dict(
        definition=("The security master team's work queue and service record: instrument setup requests from trading, "
                    "operations and private markets with their due times, approvals and outcomes, together with "
                    "golden-copy rule results on instrument data, vendor disagreements, open vendor data issues on "
                    "security master datasets, and the audit of who scrubbed corporate action events and who approved "
                    "issuer relationship overrides. It combines 17 Instrument Setup Request with the instrument, issuer and "
                    "corporate action golden copies (DP-097 to DP-099), the enterprise DQ rule results (DP-103) and 14 "
                    "vendor data issues. It shows which setups block a trade, which instruments fail their CDE rules, and "
                    "how fast the team turns requests around. It owns no certified number."),
        business_questions=[
            "Which setup requests are open, which are past their required-by time, and which are blocking a trade?",
            "How long do setups take by request type and instrument type, and what share is completed on time?",
            "Which instruments were traded before their setup was completed, and which setups were approved by their own requester?",
            "What is the pass rate of the CDE rules on instrument, issuer and corporate action data, and where do vendors disagree?",
            "Which vendor data issues on security master datasets are open, how old are they, and which were scrubbed or approved by whom?",
        ],
        grain=("Instrument setup request (one row per request, current state, daily snapshot); with DQ result (rule x "
               "execution timestamp x tested data asset) for rules targeting 17 elements, vendor data issue on security "
               "master datasets, and audit rows (corporate action event x scrubber; issuer relationship x approver) as "
               "companion facts"),
        dimensions=["Setup request type", "Requested instrument type", "Requesting function", "Request status",
                    "Approval status", "Requested by and approved by", "Instrument", "Asset class", "DQ rule and dimension",
                    "Critical data element", "Dataset and vendor", "Vendor issue type and severity", "Business date"],
        measures=[
            ("Open Setup Requests",
             "Count of Instrument Setup Requests with Setup Request Status not in (Completed, Rejected, Canceled), by Setup "
             "Request Type, Requested Instrument Type and Requesting Function.",
             [("17", "Instrument Setup Request", "Setup Request ID"), ("17", "Instrument Setup Request", "Setup Request Status"),
              ("17", "Instrument Setup Request", "Setup Request Type"),
              ("17", "Instrument Setup Request", "Requested Instrument Type"),
              ("17", "Instrument Setup Request", "Requesting Function")]),
            ("Overdue Setups",
             "Open Setup Requests with Required By Timestamp before the as-of timestamp, by Requesting Function; those from "
             "trading are reported as blocking a trade.",
             [("17", "Instrument Setup Request", "Required By Timestamp"),
              ("17", "Instrument Setup Request", "Requesting Function"), "Open Setup Requests"]),
            ("Setup Cycle Time",
             "Median and 90th percentile of Completion Timestamp - Request Timestamp over requests completed in the period, by "
             "Setup Request Type and Requested Instrument Type.",
             [("17", "Instrument Setup Request", "Request Timestamp"),
              ("17", "Instrument Setup Request", "Completion Timestamp"),
              ("17", "Instrument Setup Request", "Setup Request Type"),
              ("17", "Instrument Setup Request", "Requested Instrument Type")]),
            ("Setups On Time %",
             "Requests completed in the period with Completion Timestamp on or before Required By Timestamp / all requests "
             "completed in the period.",
             [("17", "Instrument Setup Request", "Completion Timestamp"),
              ("17", "Instrument Setup Request", "Required By Timestamp")]),
            ("Setups Completed After First Trade",
             "Count of completed requests whose Resulting Instrument has a Portfolio Transaction (DP-141) with Trade Date "
             "earlier than the date of Completion Timestamp.",
             [("17", "Instrument Setup Request", "Resulting Instrument"),
              ("17", "Instrument Setup Request", "Completion Timestamp"),
              ("18", "Portfolio Transaction", "Transaction Instrument"), ("18", "Portfolio Transaction", "Trade Date")]),
            ("Rejection Rate %",
             "Requests with Setup Request Status = Rejected / all requests closed in the period, by Rejection Reason.",
             [("17", "Instrument Setup Request", "Setup Request Status"),
              ("17", "Instrument Setup Request", "Rejection Reason")]),
            ("Setup Approval Exceptions",
             "Count of completed requests with Setup Approval Status not Approved, with Approved By equal to Requested By "
             "(no four-eyes), or with Resulting Instrument null.",
             [("17", "Instrument Setup Request", "Setup Approval Status"),
              ("17", "Instrument Setup Request", "Approved By"), ("17", "Instrument Setup Request", "Requested By"),
              ("17", "Instrument Setup Request", "Resulting Instrument"),
              ("17", "Instrument Setup Request", "Setup Request Status")]),
            ("Security Master CDE Pass Rate %",
             "Sum of (Records Tested - Records Failed) / sum of Records Tested over the latest Data Quality Result per rule "
             "and Tested Data Asset for rules whose DQ Rule Target Element is the CDE Taxonomy Attribute of an effective "
             "Critical Data Element with Element Data Domain = 17 (rules and results from DP-103), by DQ Dimension.",
             [("21", "Data Quality Rule", "DQ Rule ID"), ("21", "Data Quality Rule", "DQ Rule Target Element"),
              ("21", "Data Quality Rule", "DQ Dimension"), ("21", "Data Quality Result", "Tested DQ Rule"),
              ("21", "Data Quality Result", "DQ Execution Timestamp"), ("21", "Data Quality Result", "Tested Data Asset"),
              ("21", "Data Quality Result", "Records Tested"), ("21", "Data Quality Result", "Records Failed"),
              ("21", "Critical Data Element", "CDE Taxonomy Attribute"),
              ("21", "Critical Data Element", "CDE Effective From"), ("21", "Critical Data Element", "CDE Effective To"),
              ("21", "Taxonomy Element", "Taxonomy Element Key"), ("21", "Taxonomy Element", "Element Data Domain")]),
            ("Golden-Copy Completeness %",
             "Security Master CDE Pass Rate % restricted to rules with DQ Dimension = Completeness, by Taxonomy Element object "
             "(Element Object Name).",
             [("21", "Taxonomy Element", "Element Object Name"), ("21", "Data Quality Rule", "DQ Dimension"),
              "Security Master CDE Pass Rate %"]),
            ("Vendor Disagreement Rate %",
             "Records Failed / Records Tested over the latest results of 17-target rules with DQ Rule Type = Cross-Source "
             "Comparison (vendor versus vendor or vendor versus golden copy), by Tested Data Asset.",
             [("21", "Data Quality Rule", "DQ Rule Type"), ("21", "Data Quality Result", "Records Failed"),
              ("21", "Data Quality Result", "Records Tested"), ("21", "Data Quality Result", "Tested Data Asset")]),
            ("Rules Below Threshold",
             "Count of latest 17-target results with Threshold Met Indicator = N, by DQ Rule Severity, with DQ Result % against "
             "DQ Threshold %.",
             [("21", "Data Quality Result", "Threshold Met Indicator"), ("21", "Data Quality Result", "DQ Result %"),
              ("21", "Data Quality Rule", "DQ Threshold %"), ("21", "Data Quality Rule", "DQ Rule Severity")]),
            ("Open Vendor Data Issues",
             "Count of 14 Vendor Data Issues with Issue Status open whose Issue Dataset is a Source Dataset of an Instrument "
             "(DP-097) or Dataset Subject Area is reference data, by Issue Type and Issue Severity, with age = as-of date - "
             "Detected Date; median Resolved Date - Detected Date for issues resolved in the period.",
             [("14", "Vendor Data Issue", "Vendor Data Issue ID"), ("14", "Vendor Data Issue", "Issue Dataset"),
              ("14", "Vendor Data Issue", "Issue Type"), ("14", "Vendor Data Issue", "Issue Severity"),
              ("14", "Vendor Data Issue", "Detected Date"), ("14", "Vendor Data Issue", "Resolved Date"),
              ("14", "Vendor Data Issue", "Issue Status"), ("17", "Instrument", "Source Dataset"),
              ("14", "Dataset", "Dataset Subject Area")]),
            ("Corporate Action Scrubbing Audit",
             "Count of Corporate Action Events with Golden Copy Status in a scrubbed or approved state and Scrubbed By null, "
             "and count of scrubbed events by Scrubbed By and Announcement Source in the period.",
             [("17", "Corporate Action Event", "Corporate Action Event ID"),
              ("17", "Corporate Action Event", "Golden Copy Status"), ("17", "Corporate Action Event", "Scrubbed By"),
              ("17", "Corporate Action Event", "Announcement Source"), ("17", "Corporate Action Event", "Ex-Date")]),
            ("Issuer Overrides Without Approver",
             "Count of Issuer Relationships effective on the date with Override Reason filled and Relationship Approved By "
             "null, or with a Relationship Approved By who is no longer employed (DP-192).",
             [("17", "Issuer Relationship", "Subject Issuer"), ("17", "Issuer Relationship", "Override Reason"),
              ("17", "Issuer Relationship", "Relationship Approved By"),
              ("17", "Issuer Relationship", "Issuer Relationship Effective From"),
              ("17", "Issuer Relationship", "Issuer Relationship Effective To"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status")]),
        ],
        inputs=[
            ("17", "Instrument Setup Request", ["Setup Request ID", "Setup Request Type", "Requested Identifier Scheme",
                                                "Requested Identifier Value", "Requested Instrument Type",
                                                "Requesting Function", "Requested By", "Request Timestamp",
                                                "Required By Timestamp", "Setup Request Status", "Setup Approval Status",
                                                "Approved By", "Resulting Instrument", "Completion Timestamp",
                                                "Rejection Reason"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Instrument Status",
                                  "Private Instrument Indicator", "Primary Data Provider", "Source Dataset"]),
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Event Instrument", "Corporate Action Event Type",
                                              "Golden Copy Status", "Ex-Date", "Announcement Source", "Scrubbed By"]),
            ("17", "Issuer Relationship", ["Subject Issuer", "Related Party", "Issuer Relationship Type", "Override Reason",
                                           "Relationship Approved By", "Issuer Relationship Effective From",
                                           "Issuer Relationship Effective To"]),
            ("18", "Portfolio Transaction", ["Portfolio Transaction ID", "Transaction Instrument", "Trade Date"]),
            ("21", "Data Quality Rule", ["DQ Rule ID", "DQ Rule Description", "DQ Dimension", "DQ Threshold %",
                                         "DQ Rule Type", "DQ Rule Target Element", "DQ Rule Target Data Asset",
                                         "DQ Rule Severity"]),
            ("21", "Data Quality Result", ["DQ Result ID", "Tested DQ Rule", "DQ Execution Timestamp", "Data As-Of Date",
                                           "Tested Data Asset", "Records Tested", "Records Failed", "DQ Result %",
                                           "Threshold Met Indicator"]),
            ("21", "Critical Data Element", ["CDE ID", "CDE Taxonomy Attribute", "CDE Effective From", "CDE Effective To"]),
            ("21", "Taxonomy Element", ["Taxonomy Element Key", "Element Data Domain", "Element Object Name",
                                        "Element Attribute Name"]),
            ("14", "Vendor Data Issue", ["Vendor Data Issue ID", "Issue Dataset", "Issue Type", "Issue Severity",
                                         "Issue Description", "Detected Date", "Detected By Domain",
                                         "Own Data Challenge Indicator", "Vendor Ticket Reference", "Root Cause Category",
                                         "Resolution Outcome", "Resolved Date", "Issue Status"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Subject Area"]),
            ("20", "Employee", ["Employee ID", "Home Org Unit", "Employment Status"]),
        ],
        upstream=["DP-097", "DP-098", "DP-099", "DP-100", "DP-103", "DP-141", "DP-192", "DP-013"],
        refresh="Intraday",
        timeliness=("Setup queue within 15 minutes of a request status change during the business day; DQ results as each "
                    "rule run completes in DP-103; vendor issues and audit rows by 7am ET daily"),
        history="Every setup request with its daily status snapshot kept 7 years; DQ results and vendor issues for 3 years; audit rows for the life of the record",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Instrument Setup Request with Setup Request Status = Completed has a Resulting Instrument that exists in DP-097 and a Completion Timestamp on or after its Request Timestamp.",
            "Every completed request has Setup Approval Status = Approved and an Approved By different from Requested By.",
            "Every DQ result counted references a rule whose DQ Rule Target Element resolves to a 17 Taxonomy Element registered in DP-100.",
            "Every Corporate Action Event with a scrubbed or approved Golden Copy Status has Scrubbed By filled with an employee in DP-192.",
            "Every Issuer Relationship with Override Reason filled has Relationship Approved By filled.",
        ],
        notes=("Consumer-aligned operational product of 17. Master concept read, not remastered: Instrument Setup Request "
               "(17); instruments, issuers and corporate action events are published by DP-097, DP-098 and DP-099 and only "
               "read here for keys and audit (CD-300). Certified numbers: none. Security master audit: DP-098 and DP-099 "
               "leave out Relationship Approved By (17 Issuer Relationship) and Scrubbed By (17 Corporate Action Event) "
               "because they are personal data; this product carries them, restricted to the security master and audit "
               "teams. Data quality (CD-301): rules, results and CDE designations are enterprise DQ, owned by DP-103, which "
               "is upstream (a consumer product; DP-103 must never list this product upstream); this product filters them "
               "to 17 targets. CDEs and taxonomy elements come from DP-100. Vendor data issues stay 14's (CD-164) and are "
               "read directly because no foundational 14 product exists (brief §5: DP-044 is consumer); the 21 Data Quality "
               "Issue links to them. First trade dates come from DP-141 (portfolio transactions). Requesters, approvers and "
               "scrubbers resolve through DP-192, so PII = Y and classification Confidential - Personal Data; a view "
               "without employee identity is the wide view. Operating model (CD-297, 17 SME question 1): drafted for an "
               "in-house security master team. If security master operations are outsourced, the request queue is the "
               "provider's ticket feed and the product becomes SLA oversight with the same grain (Required By Timestamp "
               "as the SLA due time, approvals as the firm's acceptance). Taxonomy gap: Instrument Setup Request has no "
               "link to the order or trade that triggered it, so 'blocking a trade' is inferred from Requesting Function = "
               "Trading and the first trade date. Taxonomy gap: no service-level target per request type; Required By "
               "Timestamp is set by the requester. Taxonomy gap: Corporate Action Event has no golden-copy approval "
               "timestamp (as DP-099 notes), so scrubbing timeliness is not measured here. Taxonomy gap: the DQ Rule Type "
               "value 'Cross-Source Comparison' and the Setup Request Status values are assumed, to confirm. Open SME "
               "questions (17 Source_Notes §4): 1 platform and survivorship; 7 who sets up private asset instruments; 9 who "
               "scrubs corporate action events. Rests on CD-154, CD-164, CD-297, CD-300, CD-301."),
    ),

    "DP-103": dict(
        definition=("Data quality across the firm: rule results against thresholds by critical data element, data product, "
                    "data asset and Data Domain, open data quality issues by severity, age and owner, record-level quality "
                    "status in aggregate, and the certification state of data products, reports and metrics checked against "
                    "their data contracts. It combines the 21 data quality objects with the governance register (DP-100: "
                    "taxonomy elements, CDEs, ownership) and the catalog (DP-101: data assets, products, contracts, reports, "
                    "metric definitions and their certification). The Chief Data Officer uses it to set DQ priorities, "
                    "certify products and report data risk to enterprise risk and audit. It is the enterprise successor of "
                    "the distribution data quality view DP-075 held, for all 44 Data Domains, and owns no certified number."),
        business_questions=[
            "What is the DQ pass rate of each critical data element, data product and Data Domain, and which are below threshold?",
            "Which CDEs have no active DQ rule, or no rule result in the last cycle?",
            "Which data quality issues are open, by severity and age, which are past their target resolution date, and who owns them?",
            "Which certified data products, reports and metrics have failing contracted DQ rules, and should their certification be withdrawn?",
            "How many governed records are in each data quality status, by object and system of record?",
        ],
        grain=("DQ result (DQ rule x execution timestamp x tested scope: data asset or feed load); with DQ issue, critical data "
               "element x effective period, record governance aggregate (object x data quality status x information "
               "classification x system of record x as-of date) and certification check (data product, report or metric x "
               "data contract version x as-of date) as companion facts"),
        dimensions=["Data Domain", "Taxonomy element (object and attribute)", "Critical data element", "DQ rule",
                    "DQ dimension", "DQ rule severity", "Data asset", "Data product", "Data contract", "Report",
                    "Metric", "Issue severity and status", "Issue owner", "System of record", "Information classification",
                    "As-of date"],
        measures=[
            ("DQ Pass Rate %",
             "Sum of (Records Tested - Records Failed) / sum of Records Tested over the latest Data Quality Result per DQ rule "
             "and tested scope (Tested Data Asset or Tested Load) with DQ Execution Timestamp in the cycle, by CDE, Data Domain "
             "(Element Data Domain of the DQ Rule Target Element), data product (Data Product Input naming the target element) "
             "and data asset.",
             [("21", "Data Quality Result", "Tested DQ Rule"), ("21", "Data Quality Result", "DQ Execution Timestamp"),
              ("21", "Data Quality Result", "Tested Data Asset"), ("21", "Data Quality Result", "Tested Load"),
              ("21", "Data Quality Result", "Records Tested"), ("21", "Data Quality Result", "Records Failed"),
              ("21", "Data Quality Rule", "DQ Rule ID"), ("21", "Data Quality Rule", "DQ Rule Target Element"),
              ("21", "Taxonomy Element", "Taxonomy Element Key"), ("21", "Taxonomy Element", "Element Data Domain"),
              ("21", "Data Product Input", "Input Data Product"), ("21", "Data Product Input", "Input Taxonomy Element")]),
            ("Rules Meeting Threshold %",
             "Latest results with Threshold Met Indicator = Y / all latest results, by DQ Dimension and DQ Rule Severity; a "
             "result whose DQ Result % is below DQ Threshold % but flagged Met is reported as an inconsistency.",
             [("21", "Data Quality Result", "Threshold Met Indicator"), ("21", "Data Quality Result", "DQ Result %"),
              ("21", "Data Quality Rule", "DQ Threshold %"), ("21", "Data Quality Rule", "DQ Dimension"),
              ("21", "Data Quality Rule", "DQ Rule Severity")]),
            ("CDE Rule Coverage %",
             "Critical Data Elements effective on the date (CDE Effective From / To) with at least one DQ Rule whose DQ Rule "
             "Target Element is the CDE Taxonomy Attribute / all effective CDEs, by Element Data Domain and CDE Scope.",
             [("21", "Critical Data Element", "CDE ID"), ("21", "Critical Data Element", "CDE Taxonomy Attribute"),
              ("21", "Critical Data Element", "CDE Scope"), ("21", "Critical Data Element", "CDE Effective From"),
              ("21", "Critical Data Element", "CDE Effective To"), ("21", "Data Quality Rule", "DQ Rule Target Element"),
              ("21", "Taxonomy Element", "Element Data Domain")]),
            ("CDEs Without Recent Result",
             "Count of covered CDEs none of whose rules has a Data Quality Result with DQ Execution Timestamp in the last 7 "
             "days (35 days for monthly data).",
             [("21", "Critical Data Element", "CDE Taxonomy Attribute"), ("21", "Data Quality Result", "DQ Execution Timestamp"),
              ("21", "Data Quality Result", "Data As-Of Date"), "CDE Rule Coverage %"]),
            ("Open DQ Issues",
             "Count of Data Quality Issues with DQ Issue Status not closed, by DQ Issue Severity, Affected CDE, Affected Data "
             "Asset and age bucket (as-of date - DQ Issue Detected Date: under 30, 30 to 90, over 90 days).",
             [("21", "Data Quality Issue", "DQ Issue ID"), ("21", "Data Quality Issue", "DQ Issue Status"),
              ("21", "Data Quality Issue", "DQ Issue Severity"), ("21", "Data Quality Issue", "Affected CDE"),
              ("21", "Data Quality Issue", "Affected Data Asset"), ("21", "Data Quality Issue", "DQ Issue Detected Date")]),
            ("Issues Past Target Resolution",
             "Count of open issues with DQ Issue Target Resolution Date before the as-of date, and of open issues with no "
             "target date, by DQ Issue Severity.",
             [("21", "Data Quality Issue", "DQ Issue Target Resolution Date"), ("21", "Data Quality Issue", "DQ Issue Severity"),
              "Open DQ Issues"]),
            ("Issues Without Active Owner",
             "Count of open issues whose DQ Issue Owner is null or is an employee whose Employment Status is not employed "
             "(DP-192).",
             [("21", "Data Quality Issue", "DQ Issue Owner"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status"), "Open DQ Issues"]),
            ("Failed Results Without Issue",
             "Count of latest results with Threshold Met Indicator = N on rules with DQ Rule Severity High or Critical that "
             "have no open Data Quality Issue naming them as Raising DQ Result or naming their rule as Related DQ Rule.",
             [("21", "Data Quality Result", "DQ Result ID"), ("21", "Data Quality Result", "Threshold Met Indicator"),
              ("21", "Data Quality Rule", "DQ Rule Severity"), ("21", "Data Quality Issue", "Raising DQ Result"),
              ("21", "Data Quality Issue", "Related DQ Rule"), ("21", "Data Quality Issue", "DQ Issue Status")]),
            ("Record Quality Status Distribution",
             "Count of current Record Governance Metadata rows (Record Effective To null) by Governed Record Object, Data "
             "Quality Status, Information Classification and System of Record, and the share in a failed or suspect status; "
             "record keys are never published.",
             [("21", "Record Governance Metadata", "Governed Record Object"),
              ("21", "Record Governance Metadata", "Record Effective To"),
              ("21", "Record Governance Metadata", "Data Quality Status"),
              ("21", "Record Governance Metadata", "Information Classification"),
              ("21", "Record Governance Metadata", "System of Record"),
              ("21", "Record Governance Metadata", "Source System")]),
            ("Contract DQ Breaches",
             "Count of active Data Contracts (Data Contract Status active, date within Data Contract Effective From / To) whose "
             "Contracted DQ Rules include a rule with a latest result of Threshold Met Indicator = N, by Contracted Data "
             "Product and consumer.",
             [("21", "Data Contract", "Data Contract ID"), ("21", "Data Contract", "Contracted Data Product"),
              ("21", "Data Contract", "Consumer Org Unit"), ("21", "Data Contract", "Data Contract Status"),
              ("21", "Data Contract", "Contracted DQ Rules"), ("21", "Data Contract", "Data Contract Effective From"),
              ("21", "Data Contract", "Data Contract Effective To"), ("21", "Data Quality Result", "Threshold Met Indicator")]),
            ("Certified Products at Risk",
             "Count of Data Products with Data Product Status = Certified that have a Contract DQ Breach or no active Data "
             "Contract, and of Metric Definitions with Metric Certification Status = Certified whose Metric Source Data "
             "Product is one of them; candidates for certification review.",
             [("21", "Data Product", "Data Product ID"), ("21", "Data Product", "Data Product Status"),
              ("21", "Metric Definition", "Metric ID"), ("21", "Metric Definition", "Metric Certification Status"),
              ("21", "Metric Definition", "Metric Source Data Product"), "Contract DQ Breaches"]),
            ("Certified Reports on Uncertified Products",
             "Count of reports and dashboards (Analytics Report & Dashboard Detail) with Report Certification Status = "
             "Certified whose Report Primary Data Product does not have Data Product Status = Certified, and Certified Report "
             "Share % = certified reports / all active reports.",
             [("21", "Analytics Report & Dashboard Detail", "Report Certification Status"),
              ("21", "Analytics Report & Dashboard Detail", "Report Primary Data Product"),
              ("21", "Analytics Report & Dashboard Detail", "Report Certified Date"),
              ("21", "Data Asset", "Data Asset ID"), ("21", "Data Asset", "Data Asset Status"),
              ("21", "Data Product", "Data Product Status")]),
        ],
        inputs=[
            ("21", "Data Quality Rule", ["DQ Rule ID", "DQ Rule Description", "DQ Dimension", "DQ Threshold %",
                                         "DQ Rule Type", "DQ Rule Expression", "DQ Rule Target Element",
                                         "DQ Rule Target Registered In Release", "DQ Rule Target Data Asset",
                                         "DQ Rule Severity"]),
            ("21", "Data Quality Result", ["DQ Result ID", "Tested DQ Rule", "DQ Execution Timestamp", "Data As-Of Date",
                                           "Tested Data Asset", "Tested Load", "Records Tested", "Records Failed",
                                           "DQ Result %", "Threshold Met Indicator"]),
            ("21", "Data Quality Issue", ["DQ Issue ID", "DQ Issue Description", "DQ Issue Severity", "DQ Issue Status",
                                          "DQ Issue Root Cause", "Raising DQ Result", "Related DQ Rule",
                                          "Affected Data Asset", "Affected CDE", "DQ Issue Owner",
                                          "DQ Issue Detected Date", "DQ Issue Target Resolution Date",
                                          "Linked Vendor Data Issue"]),
            ("21", "Record Governance Metadata", ["Governed Record Object", "Governed Record Object Release",
                                                  "Record Version Number", "System of Record", "Source System",
                                                  "Record Effective From", "Record Effective To",
                                                  "Last Updated Timestamp", "Data Quality Status",
                                                  "Information Classification", "Personal Data Sensitivity"]),
            ("21", "Critical Data Element", ["CDE ID", "CDE Taxonomy Attribute", "CDE Registered In Release", "CDE Scope",
                                             "CDE Scoped Data Product", "CDE Regulatory Driver", "CDE Owner",
                                             "CDE Effective From", "CDE Effective To"]),
            ("21", "Taxonomy Element", ["Taxonomy Element Key", "Taxonomy Level", "Element Data Domain",
                                        "Element Object Name", "Element Attribute Name"]),
            ("21", "Data Contract", ["Data Contract ID", "Contracted Data Product", "Consumer Org Unit",
                                     "Consumer External Party", "Data Contract Version", "Data Contract Standard",
                                     "Data Contract Status", "Contracted DQ Rules", "Freshness Commitment",
                                     "Availability Target %", "Data Contract Effective From", "Data Contract Effective To"]),
            ("21", "Data Asset", ["Data Asset ID", "Data Asset Name", "Data Asset Type", "Hosting System",
                                  "Asset Owning Data Domain", "Data Asset Status"]),
            ("21", "Analytics Report & Dashboard Detail", ["BI Tool", "Report Primary Data Product", "Report Semantic Model",
                                                           "Report Certification Status", "Report Certified Date"]),
            ("21", "Data Product", ["Data Product ID", "Data Product Name", "Data Product Tier",
                                    "Data Product Owning Data Domain", "Data Product Status"]),
            ("21", "Data Product Input", ["Input Data Product", "Input Taxonomy Element"]),
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Owning Data Domain", "Metric Source Data Product",
                                         "Metric Certification Status"]),
            ("21", "Data Ownership Assignment", ["Governance Role", "Assigned Employee", "Governed Scope Type",
                                                 "Governed Data Quality Rule", "Governed Data Product",
                                                 "Governed Data Asset", "Assignment Effective From",
                                                 "Assignment Effective To"]),
            ("14", "Vendor Data Issue", ["Vendor Data Issue ID", "Issue Status"]),
            ("20", "Employee", ["Employee ID", "Home Org Unit", "Employment Status"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Status"]),
        ],
        upstream=["DP-100", "DP-101", "DP-192", "DP-211", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET each business day for rule results executed through the prior day; issue and certification status as of the prior evening",
        history="Every DQ result kept 3 years and monthly aggregates 7 years; issues and certification checks kept for their life plus 7 years; record governance aggregates as monthly snapshots",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Data Quality Result references a Tested DQ Rule that exists and exactly one tested scope (Tested Data Asset or Tested Load).",
            "Records Failed is between zero and Records Tested, and DQ Result % equals (Records Tested - Records Failed) / Records Tested within 0.01%.",
            "Threshold Met Indicator = Y exactly when DQ Result % is at or above the rule's DQ Threshold %.",
            "Every DQ Rule Target Element and CDE Taxonomy Attribute resolves to a Taxonomy Element registered in DP-100.",
            "Every open Data Quality Issue with DQ Issue Severity High or Critical has a DQ Issue Owner and a DQ Issue Target Resolution Date.",
            "No record key (Governed Record Key, Source System Record ID) appears in any published output.",
        ],
        notes=("Consumer-aligned control product of 21. Master concepts read, not remastered: Data Quality Rule, Data Quality "
               "Result and Data Quality Issue (21, CD-156, CD-301). Certified numbers: none; DP-101 holds the definition and "
               "certification status of every certified metric and DP-103 never holds a metric value (CD-163, CD-301). "
               "Certification: product, report and metric certification statuses are 21 attributes published by DP-101; "
               "this product checks them against contracted DQ rules and flags candidates for withdrawal, and the CDO "
               "records the decision in 21. Boundaries (CD-301): DP-045 stays separate and keeps distribution supply-chain "
               "health (06 feeds, loads, reconciliations, matching, attribution), reading its DQ rows filtered to "
               "distribution assets; DP-075 becomes the distribution view of DP-101, and this product is the enterprise "
               "successor of the data quality summary DP-075 carried. DP-075 is foundational and cannot list this "
               "consumer product upstream, so its 21 Data Quality Rule and Result inputs should either stay as a discovery "
               "summary or be dropped in Phase 2 (a change for DP-075's owner, not made here). DP-102 reads this product's "
               "rule results for 17 targets; this product must never list DP-102 upstream. Taxonomy elements, CDEs and "
               "ownership come from DP-100; data assets, products, contracts, reports and metric definitions from DP-101; "
               "issue and CDE owners from DP-192; source systems from DP-211; org units from DP-013. Vendor data issues "
               "stay 14's and are linked, not restated (CD-164). Record Governance Metadata is read as an aggregate only: "
               "Governed Record Key and Source System Record ID are not read, so PII comes only from issue owners, CDE "
               "owners and ownership assignments (PII = Y; a view without employee identity is published Internal). "
               "Operating model: in house (Chief Data Office); a governance tool changes the source, not the grain. "
               "Taxonomy gap: Data Quality Issue has no resolved or closed date, so time to resolve cannot be measured; "
               "issue age and lateness against target are used. Taxonomy gap: Data Contract Contracted DQ Rules and "
               "Freshness Commitment are held as text, so contract checks parse rule IDs and freshness is not tested. "
               "Taxonomy gap: the Data Product Status value 'Certified' is assumed to carry product certification (21 has "
               "no separate product certification status), to confirm. Taxonomy gap: Data Quality Rule has no run "
               "frequency, so the 7- and 35-day recency windows are drafting assumptions. Open SME questions (21 "
               "Source_Notes §4): 5 who owns the DQ rule framework and whether 06 checks become instances of it; 6 whether "
               "record governance metadata is physically carried; 9 report certification today; 10 data contract standard. "
               "Rests on CD-156, CD-160, CD-163, CD-164, CD-295, CD-298, CD-301."),
    ),
}
