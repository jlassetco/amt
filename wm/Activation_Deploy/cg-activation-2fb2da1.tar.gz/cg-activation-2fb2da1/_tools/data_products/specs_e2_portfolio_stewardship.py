"""Data product specifications, Wave E2 group "portfolio_stewardship": the consumer-aligned products of 24 Portfolio
Management & Construction (DP-126 to DP-131) and 34 Stewardship & Sustainable Investing (DP-132 to DP-135). See
CONTRACT.md (Enterprise products), Agent_Instructions/spec_common.md and the Wave E0 brief Investment.md."""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-126": dict(
        definition=("The record of who decides and what was decided in portfolio management: investment committees with their "
                    "members, meetings, quorum and decisions; each investment decision with its action, scope, maker and "
                    "rationale; and the operational assignment of portfolio managers and investment teams to portfolios. It "
                    "evidences the reasonable basis of decisions (Advisers Act Rule 204-2) and is the one place where the operational manager of record (24 Portfolio Management Assignment) is "
                    "reconciled to the manager disclosed for the product (01 Portfolio Manager Assignment) under CD-311. "
                    "Investment, risk, performance attribution and trading products take the portfolio manager from here; "
                    "distribution products keep the 01 disclosed manager through DP-004. It owns no certified number."),
        business_questions=[
            "Who is the operational portfolio manager and decision authority of each active portfolio today, and which portfolios have none?",
            "Which disclosed product managers have no operational assignment on an implementing portfolio, and which operational lead managers are not disclosed?",
            "Did each investment committee meet at its stated frequency with quorum, and what did it decide, by decision type and outcome?",
            "Which investment decisions lack a recorded rationale, a scope or a decision maker?",
            "Which assignments and committee memberships name employees who have left or are not yet approved?",
        ],
        grain=("Investment decision (IDEC-) x scoped portfolio or model portfolio, with companion facts at investment committee x "
               "meeting date x decision item number (committee decision), committee x employee x member role x effective period "
               "(membership) and portfolio x manager or team x portfolio management role x effective period (assignment, SCD type 2)"),
        dimensions=["Investment committee and committee type", "Meeting date", "Committee decision type and outcome",
                    "Investment decision action and cause", "Portfolio (DP-140)", "Model portfolio and strategy (DP-004)",
                    "Instrument (DP-097)", "Employee: decision maker, member, assigned manager (DP-192)",
                    "Investment team and legal entity (DP-013)", "Decision algorithm (DP-212)", "Portfolio management role",
                    "Effective date"],
        measures=[
            ("Portfolios Without Decision Authority", "Count of active portfolios (Portfolio Status in Active, Closed to New Money, Liquidating; Portfolio Type other than Sleeve) with no Portfolio Management Assignment effective on the as-of date (Assignment Effective From on or before it, Assignment Effective To null or after it) with Decision Authority Indicator = Y and Assignment Approval Status = Approved.",
             [("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status"), ("18", "Portfolio", "Portfolio Type"),
              ("24", "Portfolio Management Assignment", "Assigned Portfolio"), ("24", "Portfolio Management Assignment", "Decision Authority Indicator"),
              ("24", "Portfolio Management Assignment", "Assignment Approval Status"), ("24", "Portfolio Management Assignment", "Assignment Effective From"),
              ("24", "Portfolio Management Assignment", "Assignment Effective To")]),
            ("Disclosed Managers Without Operational Assignment", "CD-311 reconciliation, first direction: count of 01 Portfolio Manager Assignment rows effective on the as-of date (PM Start Date on or before it, PM End Date null or after it) whose Portfolio Manager has no effective Portfolio Management Assignment (Assigned Manager = Portfolio Manager) on any portfolio whose Portfolio Implementation Link of Implementation Link Type Implements Product names the row's product (Product ID) on that date.",
             [("01", "Portfolio Manager Assignment", "Portfolio Manager"), ("01", "Portfolio Manager Assignment", "PM Start Date"),
              ("01", "Portfolio Manager Assignment", "PM End Date"), ("01", "Investment Product", "Product ID"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"), ("18", "Portfolio Implementation Link", "Implementation Link Type"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("18", "Portfolio Implementation Link", "Implementation Effective From"),
              ("18", "Portfolio Implementation Link", "Implementation Effective To"),
              ("24", "Portfolio Management Assignment", "Assigned Manager"), ("24", "Portfolio Management Assignment", "Assigned Portfolio")]),
            ("Operational Lead Managers Not Disclosed", "CD-311 reconciliation, reverse direction: count of effective Portfolio Management Assignments with Decision Authority Indicator = Y on a portfolio whose primary Portfolio Implementation Link (Primary Implementation Indicator = Y) implements a product, where the Assigned Manager is not a Portfolio Manager of an effective 01 Portfolio Manager Assignment of that product. Sleeve and backup roles (Portfolio Management Role) are reported separately because they may legitimately be undisclosed.",
             [("24", "Portfolio Management Assignment", "Assigned Manager"), ("24", "Portfolio Management Assignment", "Decision Authority Indicator"),
              ("24", "Portfolio Management Assignment", "Portfolio Management Role"),
              ("18", "Portfolio Implementation Link", "Primary Implementation Indicator"), ("18", "Portfolio Implementation Link", "Implemented Product"),
              ("01", "Portfolio Manager Assignment", "Portfolio Manager"), ("01", "Portfolio Manager Assignment", "PM End Date")]),
            ("Manager Reconciliation Rate %", "1 - (Disclosed Managers Without Operational Assignment + Operational Lead Managers Not Disclosed) / (effective 01 Portfolio Manager Assignment rows + effective decision-authority Portfolio Management Assignments on product-implementing portfolios).",
             [("01", "Portfolio Manager Assignment", "Portfolio Manager"), ("24", "Portfolio Management Assignment", "Decision Authority Indicator"),
              "Disclosed Managers Without Operational Assignment", "Operational Lead Managers Not Disclosed"]),
            ("Assignments to Departed Employees", "Count of effective Portfolio Management Assignments and Investment Committee Member rows whose Assigned Manager or Committee Member has Employment Status other than active, or a Termination Date on or before the as-of date, in DP-192.",
             [("24", "Portfolio Management Assignment", "Assigned Manager"), ("24", "Investment Committee Member", "Committee Member"),
              ("24", "Investment Committee Member", "Member Effective To"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status"), ("20", "Employee", "Termination Date")]),
            ("Unapproved Effective Assignments", "Count of Portfolio Management Assignments effective on the as-of date with Assignment Approval Status other than Approved, by days since Assignment Effective From.",
             [("24", "Portfolio Management Assignment", "Assignment Approval Status"), ("24", "Portfolio Management Assignment", "Assignment Effective From")]),
            ("Meetings With Quorum %", "Investment Committee Meetings in the period with Quorum Met Indicator = Y (and, for meetings that are not written resolutions, Voting Members Present at least the committee's Quorum Requirement) / all meetings in the period, by committee.",
             [("24", "Investment Committee Meeting", "Meeting Committee"), ("24", "Investment Committee Meeting", "Meeting Date"),
              ("24", "Investment Committee Meeting", "Quorum Met Indicator"), ("24", "Investment Committee Meeting", "Voting Members Present"),
              ("24", "Investment Committee Meeting", "Written Resolution Indicator"), ("24", "Investment Committee", "Quorum Requirement")]),
            ("Committees Behind Meeting Frequency", "Active committees (Committee Status active) whose latest Meeting Date is older than the interval of their Meeting Frequency on the as-of date.",
             [("24", "Investment Committee", "Investment Committee Code"), ("24", "Investment Committee", "Committee Status"),
              ("24", "Investment Committee", "Meeting Frequency"), ("24", "Investment Committee Meeting", "Meeting Date")]),
            ("Committee Decisions", "Count of Investment Committee Decisions by Committee Decision Type and Committee Decision Outcome, with Decision Effective Date in the period.",
             [("24", "Investment Committee Decision", "Decision Committee"), ("24", "Investment Committee Decision", "Committee Decision Type"),
              ("24", "Investment Committee Decision", "Committee Decision Outcome"), ("24", "Investment Committee Decision", "Decision Effective Date")]),
            ("Decisions Without Rationale", "Count of Investment Decisions in the period with no Decision Rationale, or with Investment Thesis null, or with Rationale Recorded Timestamp more than one business day after Decision Timestamp.",
             [("24", "Investment Decision", "Investment Decision ID"), ("24", "Investment Decision", "Decision Timestamp"),
              ("24", "Decision Rationale", "Investment Thesis"), ("24", "Decision Rationale", "Rationale Recorded Timestamp")]),
            ("Decisions Without Scope", "Count of Investment Decisions with Decision Strategy null and no Investment Decision Scope row naming a Scope Portfolio or Scope Model Portfolio.",
             [("24", "Investment Decision", "Decision Strategy"), ("24", "Investment Decision Scope", "Scoped Decision"),
              ("24", "Investment Decision Scope", "Scope Portfolio"), ("24", "Investment Decision Scope", "Scope Model Portfolio")]),
        ],
        inputs=[
            ("24", "Investment Committee", ["Investment Committee Code", "Investment Committee Name", "Investment Committee Type", "Committee Remit",
                                            "Committee Business Lines", "Committee Owning Entity", "Parent Committee", "Meeting Frequency",
                                            "Quorum Requirement", "Committee Status", "Committee Effective From", "Committee Effective To"]),
            ("24", "Investment Committee Member", ["Member Committee", "Committee Member", "Committee Member Role", "Member Effective From",
                                                   "Member Effective To"]),
            ("24", "Investment Committee Meeting", ["Meeting Committee", "Meeting Date", "Written Resolution Indicator", "Voting Members Present",
                                                    "Quorum Met Indicator", "Minutes Location"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number", "Committee Decision Type",
                                                     "Committee Decision Outcome", "Decision Summary", "Decision Effective Date",
                                                     "Decision Scope Strategy", "Decision Instrument Type"]),
            ("24", "Investment Decision", ["Investment Decision ID", "Decision Action", "Decision Strategy", "Decision Instrument",
                                           "Switch To Instrument", "Decision Maker", "Decision Algorithm", "Decision Investment Team",
                                           "Decision Timestamp"]),
            ("24", "Decision Rationale", ["Decision Cause", "Investment Thesis", "Primary Research Recommendation", "Linked Committee Decision",
                                          "Rationale Recorded Timestamp"]),
            ("24", "Investment Decision Scope", ["Scoped Decision", "Scope Portfolio", "Scope Model Portfolio"]),
            ("24", "Portfolio Management Assignment", ["Assigned Portfolio", "Assigned Manager", "Assigned Investment Team",
                                                       "Portfolio Management Role", "Decision Authority Indicator",
                                                       "Independent Release Authority Indicator", "Assignment Approval Status",
                                                       "Assignment Approved By", "Assignment Effective From", "Assignment Effective To"]),
            ("01", "Portfolio Manager Assignment", ["Portfolio Manager", "Portfolio Manager Role", "PM Start Date", "PM End Date"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type", "Implemented Strategy"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status", "Managing Entity"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Followed Model Portfolio", "Primary Implementation Indicator",
                                                     "Implementation Effective From", "Implementation Effective To"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Termination Date", "Employing Legal Entity"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-140", "DP-192", "DP-097", "DP-004", "DP-013", "DP-212"],
        refresh="Daily",
        timeliness="By 7am ET each business day for assignments and the prior day's decisions; committee decisions within one business day of the meeting minutes being recorded",
        history="SCD type 2 on assignments, committees and memberships; decisions, rationales and committee decisions kept for at least 7 years (Advisers Act Rule 204-2 books and records, five years, and SEC Rule 31a-2, six years, rounded up)",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Portfolio Management Assignment names exactly one of Assigned Manager or Assigned Investment Team and its Assigned Portfolio resolves to a portfolio in DP-140 on the assignment's effective dates.",
            "Effective periods of assignments for the same portfolio, manager and Portfolio Management Role never overlap.",
            "Every Investment Committee Decision references an Investment Committee Meeting of the same Decision Committee and Decision Meeting Date.",
            "Every Investment Decision has a Decision Timestamp and either a Decision Maker that resolves to an employee in DP-192 or a Decision Algorithm that resolves to a 37 Model Inventory Entry in DP-212.",
            "Every Decision Rationale with a Linked Committee Decision references a committee decision whose Committee Decision Outcome is an approval and whose Decision Effective Date is on or before the Decision Timestamp.",
        ],
        notes=("W3 re-point (CW-128, CW-924, CW-930): 24 Investment Decision.Decision Algorithm Code replaced by Decision "
               "Algorithm, typed Reference (Model Inventory Entry, 37), so algorithmic decisions resolve to DP-212 (added "
               "upstream; this closes the W1b taxonomy gap); Decision Supervising Branch Country dropped, no successor (US-only "
               "pass); Investment Committee Decision.Decision Scope Deal dropped, no successor (the 30 Deal retires, and DP-137 no "
               "longer reads deal decisions). The DQ rule reads 'either a Decision Maker or a Decision Algorithm'. No measure read "
               "the dropped attributes. Manager hire, termination and third-party product approval decisions are new Committee "
               "Decision Type values (CW-121); the engagements are 52. "
               "Consumer-aligned product of FN-21; owning domain 24. Certified numbers: none. "
               "Portfolio manager of record (CD-175 drafted as option B; CD-311): this product is the source of the operational "
               "manager for investment, risk, performance attribution and trading products; DP-004 keeps the 01 disclosed manager for "
               "distribution and is not changed. The 01 Portfolio Manager Assignment rows are the ones DP-004 publishes; they are read "
               "here only for the reconciliation measures. If the client chooses option A, DP-004 is re-pointed to this product by "
               "decision and the reconciliation measures fall away. "
               "Portfolio-to-product resolution only through DP-140's Portfolio Implementation Link as of the date measured (CD-324). "
               "House views are 24 committee decisions, not 23 "
               "research rows (CD-172); Primary Research Recommendation is published as the 23 key only, so DP-118 is not upstream. "
               "Product governance committees (36) and fund boards (35) are separate bodies and are not in this product (CD-237). "
               "DP-123 Trade Order, Execution & Allocation Record lists this product upstream for the decision behind each order, so "
               "this product never reads 25. "
               "Operating model: 24 is in house (brief, CD-297 not applicable). "
               "Taxonomy gap: 01 Portfolio Manager Assignment has no product or mandate reference attribute (the product is implied by "
               "its grain); the reconciliation joins on the product of the row as DP-004 publishes it. "
               "Taxonomy gap: Investment Decision has no decision-approval or supervisory-review attribute, so review of decisions taken "
               "outside a committee is not evidenced. "
               "PII = Y: decision makers, committee members, assigned managers and approvers are employees. "
               "Open SME questions (24 Source_Notes): option A or B and per-portfolio or per-product assignment (question 2); which "
               "committees exist and whether house views are recorded by committee (question 4); whether decisions are taken across a "
               "strategy or per portfolio (question 14); how orders are linked to decisions today (question 11). "
               
               "Rests on CD-172, CD-175, CD-208, CD-237, CD-246, CD-294, CD-311, CD-324. "
               "W1b re-point (CW-937, CW-925): 37 Model Inventory Entry.Trading Algorithm Code dropped, no successor (CW-937); "
               "the measure MiFIR Decision Maker Completeness % retires with MiFIR reporting (CW-925); the 37 Model Inventory "
               "Entry input (read only by that measure), DP-212 upstream and the 'Decision algorithm (DP-212)' dimension go "
               "with it; the DQ rule no longer resolves Decision Algorithm Code to DP-212; MiFIR RTS 22 left the definition, "
               "questions, history and SME questions. Decision Supervising Branch Country stays as an input (24 not yet re-cut)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-127": dict(
        definition=("Strategic asset allocation policies with neutral weights and ranges, glide path points for target-date "
                    "series and house and strategy tactical views, set against the "
                    "actual allocation of the portfolios that implement them and their policy benchmarks. It shows the investment committee and the multi-asset teams where "
                    "each portfolio and target-date series sits against policy and tilt. Actual weights are read from "
                    "DP-142 holdings, and portfolio and policy benchmark returns from DP-145; the policy-relative result is a "
                    "labeled product measure, not an official return (CD-217). It owns no certified number."),
        business_questions=[
            "Which portfolios sit outside the minimum or maximum weight of their allocation policy, by asset class, today?",
            "How far is each portfolio from its policy neutral weights, and how much of that gap is the approved tactical tilt?",
            "How did each portfolio perform against its policy benchmark over the period?",
            "Which policies are in effect without an approving committee decision, or are past their review date?",
        ],
        grain=("Implementing portfolio x allocation policy version x policy line (asset class x sub-class) x as-of date, with "
               "companion facts at glide path policy version x years to target date x asset class x sub-class, and tactical view "
               "(scope x asset class x segment x view date); daily, "
               "month-end snapshots kept"),
        dimensions=["Allocation policy and version", "Policy type (strategic, glide path)", "Strategy, product and model portfolio (DP-004)",
                    "Portfolio (DP-140)", "Asset class and sub-class", "Policy benchmark (DP-144)", "Tactical stance",
                    "Committee decision (DP-126)", "As-of date"],
        measures=[
            ("Actual Asset Class Weight", "Sum of Market Value Base of the portfolio's end-of-day holdings whose instrument's Asset Class maps to the Policy Asset Class (and Policy Sub-Class where set) / Total IBOR Market Value of the Portfolio Valuation Summary for the same date and view (from DP-142). Portfolios are resolved to the policy subject through DP-140: Policy Product through Implemented Product, Policy Model Portfolio through Followed Model Portfolio, Policy Strategy through the Implemented Strategy of the implemented product.",
             [("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"), ("18", "Portfolio Holding", "Holding Date"),
              ("18", "Holding Valuation", "Market Value Base"), ("17", "Instrument", "Asset Class"),
              ("18", "Portfolio Valuation Summary", "Total IBOR Market Value"), ("24", "Asset Allocation Policy Line", "Policy Asset Class"),
              ("24", "Asset Allocation Policy Line", "Policy Sub-Class"), ("24", "Asset Allocation Policy", "Policy Product"),
              ("24", "Asset Allocation Policy", "Policy Model Portfolio"), ("24", "Asset Allocation Policy", "Policy Strategy"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("18", "Portfolio Implementation Link", "Followed Model Portfolio"),
              ("01", "Investment Product", "Implemented Strategy")]),
            ("Active Weight vs Policy", "Actual Asset Class Weight - Neutral Weight of the effective policy line.",
             [("24", "Asset Allocation Policy Line", "Neutral Weight"), "Actual Asset Class Weight"]),
            ("Lines Outside Policy Range", "Count of policy lines (and portfolios) where Actual Asset Class Weight < Minimum Weight or > Maximum Weight of the effective policy version (Policy Status effective, Policy Effective From on or before the as-of date, Policy Effective To null or after it).",
             [("24", "Asset Allocation Policy Line", "Minimum Weight"), ("24", "Asset Allocation Policy Line", "Maximum Weight"),
              ("24", "Asset Allocation Policy", "Policy Status"), ("24", "Asset Allocation Policy", "Policy Effective From"),
              ("24", "Asset Allocation Policy", "Policy Effective To"), "Actual Asset Class Weight"]),
            ("Tilt Implementation Gap", "For each effective Tactical Allocation View (View Date on or before the as-of date, View Effective To null or after it) on a View Asset Class: Active Weight vs Policy - signed Tilt Magnitude (positive for an overweight Tactical Stance, negative for underweight, zero for neutral), for the portfolios of the View Strategy, or all policy portfolios for a house view.",
             [("24", "Tactical Allocation View", "View Asset Class"), ("24", "Tactical Allocation View", "Tactical Stance"),
              ("24", "Tactical Allocation View", "Tilt Magnitude"), ("24", "Tactical Allocation View", "View Date"),
              ("24", "Tactical Allocation View", "View Effective To"), ("24", "Tactical Allocation View", "View Strategy"),
              "Active Weight vs Policy"]),
            ("Glide Path Deviation", "For a target-date portfolio, Actual Asset Class Weight - Glide Path Weight of the Glide Path Point of its glide path policy at the portfolio's Years to Target Date (interpolated between points), and a flag where it is outside Glide Path Minimum Weight and Glide Path Maximum Weight.",
             [("24", "Glide Path Point", "Glide Path Policy"), ("24", "Glide Path Point", "Years to Target Date"),
              ("24", "Glide Path Point", "Glide Path Asset Class"), ("24", "Glide Path Point", "Glide Path Weight"),
              ("24", "Glide Path Point", "Glide Path Minimum Weight"), ("24", "Glide Path Point", "Glide Path Maximum Weight"),
              "Actual Asset Class Weight"]),
            ("Policy-Relative Return", "Labeled product measure (CD-217), not an official return: Official Return of the portfolio (or of the share class for a fund policy) for the period, from DP-145 (Return Status Final or Restated, highest Return Version), minus the Benchmark Return of the policy's Policy Benchmark for the same period, currency and return type, from DP-145.",
             [("32", "Performance Return", "Return Portfolio"), ("32", "Performance Return", "Return Share Class"),
              ("32", "Performance Return", "Return Period Start Date"), ("32", "Performance Return", "Return Period End Date"),
              ("32", "Performance Return", "Return Value"), ("32", "Performance Return", "Return Status"),
              ("32", "Performance Return", "Return Version"), ("32", "Benchmark Return", "Return Benchmark"),
              ("32", "Benchmark Return", "Benchmark Return Value"), ("24", "Asset Allocation Policy", "Policy Benchmark")]),
            ("Neutral Weight Tie-Out to Benchmark Blend", "For policies whose Policy Benchmark has Blended Benchmark Indicator = Y: sum over lines of |Neutral Weight - weight of the matching Blend Components entry (Line Proxy Benchmark)|; zero expected, because Neutral Weight is a derived copy of the blend (01) except where no blend exists.",
             [("24", "Asset Allocation Policy Line", "Neutral Weight"), ("24", "Asset Allocation Policy Line", "Line Proxy Benchmark"),
              ("01", "Benchmark", "Blended Benchmark Indicator"), ("01", "Benchmark", "Blend Components")]),
            ("Policies Without Committee Approval", "Count of effective Asset Allocation Policy versions with Approving Committee Decision null, or whose committee decision (from DP-126) has a Committee Decision Outcome that is not an approval.",
             [("24", "Asset Allocation Policy", "Approving Committee Decision"), ("24", "Asset Allocation Policy", "Policy Status"),
              ("24", "Investment Committee Decision", "Committee Decision Outcome")]),
        ],
        inputs=[
            ("24", "Asset Allocation Policy", ["Policy Strategy", "Policy Product", "Policy Model Portfolio", "Policy Version Number",
                                               "Allocation Policy Name", "Allocation Policy Type", "Policy Benchmark",
                                               "Approving Committee Decision", "Policy Rebalance Frequency", "Policy Status",
                                               "Policy Effective From", "Policy Effective To"]),
            ("24", "Asset Allocation Policy Line", ["Line Allocation Policy", "Policy Asset Class", "Policy Sub-Class", "Neutral Weight",
                                                    "Minimum Weight", "Maximum Weight", "Line Proxy Benchmark"]),
            ("24", "Glide Path Point", ["Glide Path Policy", "Years to Target Date", "Glide Path Asset Class", "Glide Path Sub-Class",
                                        "Glide Path Weight", "Glide Path Minimum Weight", "Glide Path Maximum Weight", "Landing Point Indicator"]),
            ("24", "Tactical Allocation View", ["View Committee Decision", "View Strategy", "View Asset Class", "View Segment", "Tactical Stance",
                                                "Tilt Magnitude", "View Date", "View Horizon Months", "View Effective To"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number",
                                                     "Committee Decision Outcome", "Decision Effective Date"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type", "Implemented Strategy"]),
            ("01", "Benchmark", ["Benchmark ID", "Benchmark Name", "Blended Benchmark Indicator", "Blend Components"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Followed Model Portfolio", "Primary Implementation Indicator",
                                                     "Implementation Effective From", "Implementation Effective To"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base", "Holding Weight"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Total IBOR Market Value"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Subject Type", "Return Portfolio",
                                          "Return Share Class", "Return Period Start Date", "Return Period End Date", "Return Fee Basis",
                                          "Return Currency", "Return Value", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Type", "Benchmark Return Currency", "Benchmark Return Version",
                                        "Benchmark Return Value", "Benchmark Return Status"]),
        ],
        upstream=["DP-126", "DP-140", "DP-142", "DP-144", "DP-145", "DP-097", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET each business day on the prior day's end-of-day holdings; month-end view locked when DP-142's month-end snapshot is locked and DP-145 publishes Final returns",
        history="Policy, glide path and tactical view versions kept indefinitely (SCD type 2 by version); daily positions against policy for 13 months; month-end snapshots for 10 years",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "For every effective policy version, Neutral Weight sums to 100% across its lines and Minimum Weight <= Neutral Weight <= Maximum Weight on every line.",
            "For every glide path policy, Glide Path Weight sums to 100% at each Years to Target Date and exactly one point set is flagged Landing Point Indicator = Y.",
            "Every effective policy resolves to at least one portfolio through DP-140 on the as-of date, or is reported as unimplemented.",
            "Actual Asset Class Weight sums to 100% (including cash) for each portfolio and date within 0.01 percentage points.",
            "Policy-Relative Return is published only where both the portfolio return and the policy benchmark return are Final or Restated in DP-145 for the same period and currency.",
        ],
        notes=("W4 re-point (CW-930, CW-924): 24 Commitment Pacing Plan dropped, no successor (private markets pacing leaves "
               "with 30); the measures Commitments vs Pacing Plan %, Calls and Distributions vs Projection and Private Markets "
               "Exposure vs Target, the pacing business question, the plan period dimension and the 18 Fund Interest Holding Detail "
               "and Portfolio Transaction inputs and DP-141 upstream they alone needed are removed. The register name keeps "
               "'Commitment Pacing' until WP0 renames the product (framework.py is the lead's). "
               "Consumer-aligned product of FN-21; owning domain 24. Certified numbers: none; it reads official and benchmark "
               "returns from DP-145 (CD-320) and labels the difference a product measure (CD-217); Portfolio Market Value (IBOR) from "
               "DP-142 is the weight denominator and is never labeled AUM (CD-320). "
               "Portfolio-to-product, model and strategy resolution only through DP-140 (CD-324). Benchmarks come through DP-144 until "
               "DP-004 carries 01 Benchmark (CD-322). Neutral Weight is a derived copy of the policy benchmark blend (01) except where "
               "no blend exists (row rule), which the tie-out measure tests. Approving committee decisions are read from DP-126. "
               
               "Taxonomy gap: 01 carries no target date (vintage year) for a target-date product, so a portfolio's Years to Target "
               "Date for the glide path comparison is derived from the product name or the 01 Product Range until an attribute exists. "
               "Taxonomy gap: Asset Allocation Policy has no review-due date, so policy review timeliness is not measured. "
               
               "Validator warning justified: pii = N although 32 Return Portfolio and Return Value are noted as PII; they are personal data only for "
               "individual SMA and account subjects, and this product reads returns only for fund, institutional and model policy "
               "portfolios; an SMA-level policy view would need pii = Y. "
               "Operating model: 24 is in house (brief); if the middle office is outsourced (CD-297), the DP-142 and DP-141 inputs "
               "become provider-delivered IBOR and this product is unchanged. "
               "Open SME questions (24 Source_Notes): who owns glide path design, 24 or 36 (question 5; recommendation 24 with FN-37 "
               "supporting, brief §8 item 10); whether tactical views are set per house, strategy or portfolio manager (question 12). "
               "Rests on CD-217, CD-320, CD-322, CD-324."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-128": dict(
        definition=("Each portfolio's effective target set and construction constraints, its drift against end-of-day holdings, "
                    "the day's investable cash after the portfolio manager's adjustments, and every rebalance run with its "
                    "per-portfolio result, the index changes that triggered it and the proposed trades it produced, through to "
                    "release. It drives the daily rebalance and cash deployment decision and shows which proposals were released "
                    "to trading. Opening and projected cash are read from DP-142 and never restated (CD-178); tracking error and "
                    "cost figures are optimizer estimates for a proposal, not DP-146 risk measures (CD-211). It owns no certified "
                    "number."),
        business_questions=[
            "Which portfolios are outside the tolerance bands of their effective target set this morning, and by how much?",
            "How much cash can each portfolio invest today, by currency and value date, and which manager adjustments drive it?",
            "Which announced index changes affect our benchmarked portfolios, and has a rebalance been run for each?",
            "Which rebalance results were accepted, and which proposed trades are still waiting for release?",
            "What turnover, cost, realized gain and tracking error change did the optimizer estimate for each accepted result?",
        ],
        grain=("Portfolio x target allocation line x as-of date (drift), with companion facts at investable cash forecast (portfolio "
               "x forecast date x value date x currency), rebalance run x portfolio (result) and proposed trade; intraday during "
               "the trading day, end-of-day snapshot kept"),
        dimensions=["Portfolio and business line (DP-140)", "Target subject (portfolio or model portfolio, DP-004)", "Target set version",
                    "Target component (instrument DP-097, asset class, classification node)", "Active weight benchmark (DP-144)",
                    "Constraint type", "Rebalance trigger", "Optimizer and risk model (DP-212)", "Proposed trade status and side",
                    "Investment decision (DP-126)", "Currency and value date (DP-013)", "As-of date"],
        measures=[
            ("Line Drift", "Actual weight - Target Weight for each line of the portfolio's effective Target Allocation Set (Target Set Status = Effective, latest Target Effective Timestamp on or before the as-of time). Actual weight = Market Value Base of the portfolio's holdings in the component (Held Instrument = Target Instrument for instrument lines; instrument Asset Class = Target Asset Class for asset class lines) / Total IBOR Market Value (from DP-142). For sets with Active Weight Indicator = Y, the benchmark's Constituent Weight in DP-144 is subtracted from the actual weight first.",
             [("24", "Target Allocation Set", "Target Portfolio"), ("24", "Target Allocation Set", "Target Set Status"),
              ("24", "Target Allocation Set", "Target Effective Timestamp"), ("24", "Target Allocation Set", "Active Weight Indicator"),
              ("24", "Target Allocation Set", "Active Weight Benchmark"), ("24", "Target Allocation Line", "Target Component Type"),
              ("24", "Target Allocation Line", "Target Instrument"), ("24", "Target Allocation Line", "Target Asset Class"),
              ("24", "Target Allocation Line", "Target Weight"), ("18", "Portfolio Holding", "Held Instrument"),
              ("18", "Holding Valuation", "Market Value Base"), ("18", "Portfolio Valuation Summary", "Total IBOR Market Value"),
              ("17", "Instrument", "Asset Class"), ("22", "Index Constituent", "Constituent Benchmark"),
              ("22", "Index Constituent", "Constituent Instrument"), ("22", "Index Constituent", "Constituent Weight")]),
            ("Lines Outside Tolerance", "Count of target lines where Line Drift < -Lower Tolerance Band or > Upper Tolerance Band, and the absolute excess beyond the band, by portfolio.",
             [("24", "Target Allocation Line", "Lower Tolerance Band"), ("24", "Target Allocation Line", "Upper Tolerance Band"), "Line Drift"]),
            ("Portfolios Requiring Rebalance", "Distinct active portfolios with at least one line outside tolerance, or with a hard Portfolio Construction Constraint (Hard Constraint Indicator = Y, Constraint Status active) whose current value is outside Constraint Lower Value and Constraint Upper Value.",
             [("24", "Portfolio Construction Constraint", "Constrained Portfolio"), ("24", "Portfolio Construction Constraint", "Constraint Type"),
              ("24", "Portfolio Construction Constraint", "Constraint Lower Value"), ("24", "Portfolio Construction Constraint", "Constraint Upper Value"),
              ("24", "Portfolio Construction Constraint", "Hard Constraint Indicator"), ("24", "Portfolio Construction Constraint", "Constraint Status"),
              "Lines Outside Tolerance"]),
            ("Investable Cash", "Investable Cash Amount of the latest Investable Cash Forecast per portfolio, currency and Forecast Value Date for today's Forecast Date: Opening Cash + Projected Cash Net + Manager Adjustments Net - Cash Target Amount.",
             [("24", "Investable Cash Forecast", "Forecast Portfolio"), ("24", "Investable Cash Forecast", "Forecast Date"),
              ("24", "Investable Cash Forecast", "Forecast Value Date"), ("24", "Investable Cash Forecast", "Forecast Currency"),
              ("24", "Investable Cash Forecast", "Opening Cash"), ("24", "Investable Cash Forecast", "Projected Cash Net"),
              ("24", "Investable Cash Forecast", "Manager Adjustments Net"), ("24", "Investable Cash Forecast", "Cash Target Amount"),
              ("24", "Investable Cash Forecast", "Investable Cash Amount")]),
            ("Manager Adjustment Tie-Out", "Manager Adjustments Net - sum of Adjustment Amount of the forecast's Cash Forecast Adjustments (inflows positive, outflows negative by Adjustment Flow Direction); zero expected.",
             [("24", "Investable Cash Forecast", "Manager Adjustments Net"), ("24", "Cash Forecast Adjustment", "Adjusted Cash Forecast"),
              ("24", "Cash Forecast Adjustment", "Adjustment Amount"), ("24", "Cash Forecast Adjustment", "Adjustment Flow Direction")]),
            ("Opening and Projected Cash Tie-Out", "Opening Cash - sum of Balance Amount Local of the portfolio's 18 Cash Balances in the Forecast Currency with Cash Balance Type = Settled on the Forecast Date; and Projected Cash Net - (Projected Amount inflows - outflows of 18 Projected Cash Movements for the portfolio, currency and Forecast Value Date), both from DP-142; non-zero values show a stale copy (CD-178).",
             [("24", "Investable Cash Forecast", "Opening Cash"), ("24", "Investable Cash Forecast", "Projected Cash Net"),
              ("18", "Cash Balance", "Cash Balance Portfolio"), ("18", "Cash Balance", "Balance Currency"), ("18", "Cash Balance", "Balance Date"),
              ("18", "Cash Balance", "Cash Balance Type"), ("18", "Cash Balance", "Balance Amount Local"),
              ("18", "Projected Cash Movement", "Projection Portfolio"), ("18", "Projected Cash Movement", "Projected Currency"),
              ("18", "Projected Cash Movement", "Projected Value Date"), ("18", "Projected Cash Movement", "Projected Amount"),
              ("18", "Projected Cash Movement", "Projected Flow Direction")]),
            ("Index Changes Without Rebalance", "Count of 22 Index Change Announcements (from DP-144) with Change Announcement Status confirmed and Change Effective Date within the next five business days whose Changed Benchmark is the Active Weight Benchmark of an effective target set, and which no Rebalance Index Change Trigger references.",
             [("22", "Index Change Announcement", "Changed Benchmark"), ("22", "Index Change Announcement", "Index Change Type"),
              ("22", "Index Change Announcement", "Change Effective Date"), ("22", "Index Change Announcement", "Change Announcement Status"),
              ("24", "Rebalance Index Change Trigger", "Triggering Index Change Announcement"), ("24", "Target Allocation Set", "Active Weight Benchmark")]),
            ("Rebalance Results Accepted %", "Rebalance Portfolio Results with Result Accepted Indicator = Y / all results of runs with Run Timestamp in the period, by Rebalance Trigger and Optimizer Used.",
             [("24", "Rebalance Run", "Rebalance Trigger"), ("24", "Rebalance Run", "Run Timestamp"), ("24", "Rebalance Run", "Optimizer Used"),
              ("24", "Rebalance Portfolio Result", "Result Rebalance Run"), ("24", "Rebalance Portfolio Result", "Result Accepted Indicator")]),
            ("Proposals Released %", "Proposed Trades with Proposed Trade Status = Released / Proposed Trades of accepted results, by portfolio and day; the order created from each release is published by DP-123, which reads this product.",
             [("24", "Proposed Trade", "Proposed Trade ID"), ("24", "Proposed Trade", "Proposing Rebalance Run"),
              ("24", "Proposed Trade", "Proposed Trade Status"), ("24", "Rebalance Portfolio Result", "Result Accepted Indicator")]),
            ("Open Proposals Past Run Day", "Count of Proposed Trades with Proposed Trade Status in (Proposed, Accepted) whose run's Run Timestamp is before the current business day.",
             [("24", "Proposed Trade", "Proposed Trade Status"), ("24", "Rebalance Run", "Run Timestamp")]),
            ("Optimizer Estimates of Accepted Results", "For accepted results: Estimated Turnover, Estimated Transaction Cost, Post-Trade Cash Weight and the estimated tracking error change Post-Trade Tracking Error - Pre-Trade Tracking Error, labeled optimizer estimates with the Optimizer Used and Risk Model Used of the run (CD-211), and with the Model Use Status of the optimizer's Model Inventory Entry joined to DP-212 on Model ID and Model Version (CD-246, CD-294).",
             [("24", "Rebalance Portfolio Result", "Estimated Turnover"), ("24", "Rebalance Portfolio Result", "Estimated Transaction Cost"),
              ("24", "Rebalance Portfolio Result", "Post-Trade Cash Weight"), ("24", "Rebalance Portfolio Result", "Pre-Trade Tracking Error"),
              ("24", "Rebalance Portfolio Result", "Post-Trade Tracking Error"), ("24", "Rebalance Run", "Optimizer Used"),
              ("24", "Rebalance Run", "Risk Model Used"), ("24", "Rebalance Run", "Model Inventory Entry"),
              ("37", "Model Inventory Entry", "Model ID"), ("37", "Model Inventory Entry", "Model Version"),
              ("37", "Model Inventory Entry", "Model Use Status")]),
            ("Stale Holdings in Results", "Rebalance Portfolio Results whose Holdings As-Of Timestamp is earlier than the latest DP-142 Holding As-Of Timestamp for the portfolio at Run Timestamp.",
             [("24", "Rebalance Portfolio Result", "Holdings As-Of Timestamp"), ("24", "Rebalance Run", "Run Timestamp"),
              ("18", "Portfolio Holding", "Holding As-Of Timestamp")]),
            ("Proposed Trade Value", "Proposed Amount where filled, else Proposed Quantity x Approved Price Value of the instrument at the latest approved price date (from DP-143), by portfolio, side and day.",
             [("24", "Proposed Trade", "Proposed Amount"), ("24", "Proposed Trade", "Proposed Quantity"), ("24", "Proposed Trade", "Proposed Trade Side"),
              ("22", "Approved Price", "Priced Instrument"), ("22", "Approved Price", "Price Date"), ("22", "Approved Price", "Approved Price Value"),
              ("22", "Approved Price", "Price Approval Status")]),
        ],
        inputs=[
            ("24", "Target Allocation Set", ["Target Set ID", "Target Subject Type", "Target Portfolio", "Target Model Portfolio", "Target Set Version",
                                             "Target Set Status", "Target Set Approval Status", "Target Effective Timestamp", "Active Weight Indicator",
                                             "Active Weight Benchmark", "Governing Allocation Policy", "Originating Investment Decision"]),
            ("24", "Target Allocation Line", ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class",
                                              "Target Classification Scheme", "Target Classification Value", "Target Sleeve Portfolio",
                                              "Target Weight", "Lower Tolerance Band", "Upper Tolerance Band"]),
            ("24", "Portfolio Construction Constraint", ["Constrained Portfolio", "Constraint Type", "Constraint Scope", "Constraint Lower Value",
                                                         "Constraint Upper Value", "Constraint Unit", "Hard Constraint Indicator",
                                                         "Buffered Investment Restriction", "Constraint Status", "Constraint Effective From",
                                                         "Constraint Effective To"]),
            ("24", "Rebalance Run", ["Rebalance Run ID", "Rebalance Trigger", "Run Timestamp", "Driving Target Set", "Triggering Investment Decision",
                                     "Triggering Transition Event", "Optimizer Used", "Risk Model Used", "Model Inventory Entry"]),
            ("24", "Rebalance Index Change Trigger", ["Index Change Rebalance Run", "Triggering Index Change Announcement"]),
            ("24", "Rebalance Portfolio Result", ["Result Rebalance Run", "Result Portfolio", "Applied Target Set", "Holdings As-Of Timestamp",
                                                  "Pre-Trade Tracking Error", "Post-Trade Tracking Error", "Estimated Turnover",
                                                  "Post-Trade Cash Weight", "Estimated Transaction Cost", "Estimated Realized Gain",
                                                  "Result Accepted Indicator"]),
            ("24", "Proposed Trade", ["Proposed Trade ID", "Proposing Rebalance Run", "Originating Investment Decision", "Proposed Trade Portfolio",
                                      "Proposed Trade Instrument", "Proposed Trade Side", "Proposed Quantity", "Proposed Amount",
                                      "Proposed Trade Status"]),
            ("24", "Investable Cash Forecast", ["Forecast Portfolio", "Forecast Date", "Forecast Value Date", "Forecast Currency", "Opening Cash",
                                                "Projected Cash Net", "Manager Adjustments Net", "Cash Target Amount", "Investable Cash Amount"]),
            ("24", "Cash Forecast Adjustment", ["Adjusted Cash Forecast", "Cash Forecast Adjustment Source", "Adjustment Sequence",
                                                "Adjustment Amount", "Adjustment Flow Direction", "Adjustment Data Basis",
                                                "Planned Investment Decision"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View",
                                         "Holding As-Of Timestamp", "Holding Quantity"]),
            ("18", "Holding Valuation", ["Market Value Base", "Holding Weight"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Total IBOR Market Value"]),
            ("18", "Cash Balance", ["Cash Balance Portfolio", "Balance Currency", "Balance Date", "Cash Balance Type", "Balance Amount Local"]),
            ("18", "Projected Cash Movement", ["Projection Portfolio", "Projected Currency", "Projected Value Date", "Projected Cash Source",
                                               "Projected Amount", "Projected Flow Direction"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Instrument Status"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Price Date", "Approved Price Value", "Price Approval Status"]),
            ("22", "Index Constituent", ["Constituent Benchmark", "Constituent Instrument", "Constituent Effective Date", "Constituent Weight"]),
            ("22", "Index Change Announcement", ["Changed Benchmark", "Index Change Type", "Affected Index Instrument", "Announcement Date",
                                                 "Change Effective Date", "Change Announcement Status"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Type", "Model Use Status"]),
        ],
        upstream=["DP-126", "DP-140", "DP-142", "DP-097", "DP-143", "DP-144", "DP-004", "DP-013", "DP-212"],
        refresh="Intraday",
        timeliness="Drift and investable cash by 7:30am ET on the start-of-day holdings view; rebalance runs, results and proposals within 5 minutes of the run; end-of-day snapshot by 8pm ET",
        history="Target set versions and constraints SCD type 2, kept indefinitely; rebalance runs, results and proposed trades kept 7 years as decision evidence; daily drift and cash forecast snapshots kept 3 years",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API", "Event stream"],
        dq_rules=[
            "Each target subject has at most one Target Allocation Set with Target Set Status = Effective at any time, and it has Target Set Approval Status = Approved.",
            "Target Weight sums to 100% over the instrument and asset class lines of every absolute set (Active Weight Indicator = N), and Lower Tolerance Band and Upper Tolerance Band are non-negative.",
            "Investable Cash Amount = Opening Cash + Projected Cash Net + Manager Adjustments Net - Cash Target Amount for every forecast row.",
            "Every Proposed Trade has an Originating Investment Decision, and every Proposed Trade with Proposed Trade Status = Released belongs to an accepted Rebalance Portfolio Result or is a manual proposal without a run.",
            "Every Rebalance Index Change Trigger references an Index Change Announcement that exists in DP-144.",
        ],
        notes=("Consumer-aligned product of FN-21; owning domain 24. Certified numbers: none. Tracking error here is an optimizer "
               "estimate for a proposal (CD-211); the certified ex-ante tracking error of the held book is DP-146's (CD-320). Total "
               "IBOR Market Value is Portfolio Market Value (IBOR) from DP-142, never AUM. "
               "Cash (CD-178): Opening Cash and Projected Cash Net are derived copies of 18 and are tied out to DP-142; this product "
               "adds only the 24 adjustments, cash target and investable result. "
               "Client and account restrictions apply at proposal and are 33-coded rules (CD-221), not 24 constraints; the "
               "restriction applied to a result is a relationship on Rebalance Portfolio Result with no attribute (see gap). "
               "Order link (CD-180, CD-314): the 25 Trade Order references the Proposed Trade; DP-123 lists this product upstream and "
               "publishes the proposal-to-order link, so this product reads Proposed Trade Status only and never reads 25 (no cycle). "
               "Models (CD-294): the optimizer and risk model behind proposals are registered in 37 and read through DP-212. "
               "Model Inventory Entry reference added 2026-10-14 (CD-246, GAP-37-001). "
               "Taxonomy gap: Rebalance Portfolio Result has no attribute for the client or account restrictions applied (held as a "
               "relationship only). "
               "Taxonomy gap: Proposed Trade has no creation timestamp; age is measured from the run's Run Timestamp, so manual "
               "proposals have no age. "
               "PII = Y: Proposed Quantity, Proposed Amount and Estimated Realized Gain of individual SMA portfolios are personal "
               "financial data (24 personal data rule); publish a view without SMA portfolios for wide use. "
               "Operating model: 24 is in house. If the middle office is outsourced (CD-297), the 18 inputs become "
               "provider-delivered IBOR through DP-142 and this product is unchanged. "
               "Open SME questions (24 Source_Notes): platforms for targets and rebalances (question 1); whether proposals are "
               "persisted after release (question 6; brief §8 item 7 recommends persisting); whether the cash forecast is stored and "
               "which flow estimates feed it (question 7). "
               "Rests on CD-178, CD-180, CD-211, CD-221, CD-246, CD-294, CD-314, CD-320, CD-324."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-129": dict(
        definition=("Every model portfolio version delivered to sponsor platforms: the target lines, the model change description "
                    "and turnover, sponsor publication and release time, by model, sponsor program and delivery method, set "
                    "against the time the firm's own accounts traded the same investment decision. It lets the managed accounts "
                    "team prove that each model change reached every active placement on time and in the rotation the firm's "
                    "trade rotation policy requires. The delivered content is the 24 target set of a model subject (CD-176); "
                    "01 keeps the model and 05 the placement. It owns no certified number."),
        business_questions=[
            "Which model changes were approved this period, and when was each released to sponsors relative to approval?",
            "Which approved model changes have not yet been released, and to how many active sponsor placements?",
            "Did the release of each model change follow the trade rotation policy relative to the firm's own discretionary trading on the same decision?",
            "How much turnover did each model change carry, and how often does each model change?",
            "Which model target lines name instruments that are no longer active?",
        ],
        grain="Model portfolio x target set version (model change), with child rows at target set version x target line and model change x active sponsor placement at release",
        dimensions=["Model portfolio and strategy (DP-004)", "Sponsor program and sponsor (DP-005)", "Model delivery method",
                    "Target set version", "Instrument (DP-097)", "Investment decision (DP-126 key)", "Release date (DP-013)"],
        measures=[
            ("Model Changes Released", "Count of Target Allocation Sets with Target Subject Type = Model Portfolio, Sponsor Publication Indicator = Y and Sponsor Release Timestamp in the period, by model and delivery method.",
             [("24", "Target Allocation Set", "Target Subject Type"), ("24", "Target Allocation Set", "Target Model Portfolio"),
              ("24", "Model Change Summary", "Sponsor Publication Indicator"), ("24", "Model Change Summary", "Sponsor Release Timestamp"),
              ("01", "Model Portfolio", "Model Delivery Method")]),
            ("Release Lag Hours", "Sponsor Release Timestamp - Target Set Approval Timestamp, in hours, for each released model change.",
             [("24", "Model Change Summary", "Sponsor Release Timestamp"), ("24", "Target Allocation Set", "Target Set Approval Timestamp")]),
            ("On-Time Release %", "Released model changes whose Sponsor Release Timestamp is on or before the Target Effective Timestamp of the version (or within the same business day as approval where effective immediately) / all released model changes.",
             [("24", "Model Change Summary", "Sponsor Release Timestamp"), ("24", "Target Allocation Set", "Target Effective Timestamp"),
              ("24", "Target Allocation Set", "Target Set Approval Timestamp"), "Model Changes Released"]),
            ("Approved Changes Not Released", "Count of model target set versions with Target Set Approval Status = Approved, Sponsor Publication Indicator = Y and Sponsor Release Timestamp null after their Target Effective Timestamp, and the number of active placements of the model waiting on each.",
             [("24", "Target Allocation Set", "Target Set Approval Status"), ("24", "Target Allocation Set", "Target Effective Timestamp"),
              ("24", "Model Change Summary", "Sponsor Publication Indicator"), ("24", "Model Change Summary", "Sponsor Release Timestamp"),
              "Active Placements Reached"]),
            ("Active Placements Reached", "Count of 05 Model Program Placements of the model (Placed Model Portfolio) with Model Placement Status = Approved - Available and Model Placement Effective From on or before the Sponsor Release Timestamp (from DP-005); every such placement is deemed to receive the release (see the delivery-event gap).",
             [("05", "Model Program Placement", "Placed Model Portfolio"), ("05", "Model Program Placement", "Model Placement Status"),
              ("05", "Model Program Placement", "Model Placement Effective From"), ("24", "Model Change Summary", "Sponsor Release Timestamp")]),
            ("Rotation Lag vs Firm Trading", "Sponsor Release Timestamp - earliest Order Created Timestamp of the 25 Trade Orders (from DP-123) whose Originating Investment Decision equals the target set's Originating Investment Decision, in minutes; negative when sponsors were released first. Flagged where the sequence breaks the trade rotation policy.",
             [("24", "Model Change Summary", "Sponsor Release Timestamp"), ("24", "Target Allocation Set", "Originating Investment Decision"),
              ("25", "Trade Order", "Originating Investment Decision"), ("25", "Trade Order", "Order Created Timestamp")]),
            ("Model Turnover", "Model Turnover of the model change as recorded in Model Change Summary, and the sum over the trailing 12 months by model.",
             [("24", "Model Change Summary", "Model Turnover")]),
            ("Target Lines on Inactive Instruments", "Count of target lines of the effective or latest released model version whose Target Instrument has Instrument Status other than active in DP-097.",
             [("24", "Target Allocation Line", "Target Instrument"), ("17", "Instrument", "Instrument Status")]),
        ],
        inputs=[
            ("24", "Target Allocation Set", ["Target Set ID", "Target Subject Type", "Target Model Portfolio", "Target Set Version", "Target Set Status",
                                             "Target Set Approval Status", "Target Set Approval Timestamp", "Target Effective Timestamp",
                                             "Originating Investment Decision", "Copied From Target Set"]),
            ("24", "Target Allocation Line", ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class", "Target Weight"]),
            ("24", "Model Change Summary", ["Model Change Description", "Model Turnover", "Sponsor Publication Indicator", "Sponsor Release Timestamp"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name", "Implemented Strategy", "Model Sponsor / Platform",
                                       "Rebalance Frequency", "Model Delivery Method"]),
            ("05", "Model Program Placement", ["Placed Model Portfolio", "Sponsor Program Type", "Firm Role in Program", "Model Placement Status",
                                               "Model Placement Effective From"]),
            ("05", "Partner Program", ["Program ID", "Program Name", "Program Type", "Program Sponsor", "Program Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "Instrument Status"]),
            ("25", "Trade Order", ["Trade Order ID", "Order Created Timestamp", "Originating Investment Decision"]),
        ],
        upstream=["DP-128", "DP-004", "DP-005", "DP-097", "DP-013", "DP-123"],
        refresh="On Event",
        timeliness="Each model change within 15 minutes of its approval or release; rotation lag after the first order on the decision is created",
        history="Every model target set version and its lines kept indefinitely; placement status at each release kept with the release",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "File extract", "API"],
        dq_rules=[
            "Every Target Allocation Set with Target Subject Type = Model Portfolio names a Target Model Portfolio that resolves in DP-004 and no Target Portfolio.",
            "Sponsor Release Timestamp is null unless Sponsor Publication Indicator = Y and Target Set Approval Status = Approved, and it is never earlier than Target Set Approval Timestamp.",
            "Target Weight sums to 100% across the instrument lines of every released model version.",
            "Model Turnover is between 0% and 200% and is filled for every released version that has a predecessor version.",
        ],
        notes=("Consumer-aligned product of FN-22; owning domain 24. Certified numbers: none. "
               "Boundary with DP-050 Model Portfolio & SMA Placement and Flows: DP-050 stays the distribution view of placements, "
               "assets and flows; this product is the model content and its delivery timeliness, and does not change DP-050. "
               "CD-176 and C-02.04: the delivered content is the 24 target set of a model subject; 01 keeps the model record and "
               "delivery terms, 05 the placement (read through DP-005). "
               "Upstream addition to the candidate: DP-123, for the order times of the firm's own trading on the same investment "
               "decision (trade rotation evidence); DP-123 lists DP-128 but not this product, so there is no cycle. "
               "Taxonomy gap (CD-176): no delivery-event record per sponsor; delivery is evidenced only by the Sponsor Release "
               "Timestamp of the version, so per-sponsor receipt and acknowledgement cannot be measured. "
               "Taxonomy gap: no trade rotation policy object (rotation group, sequence or randomization), so the rotation flag "
               "compares release time with the firm's first order and cannot test a randomized rotation. "
               "Taxonomy gap: 05 Model Program Placement carries no partner program key attribute (the program is implied by its "
               "grain); placements are joined to 05 Partner Program as DP-005 publishes them. "
               "Operating model: 24 is in house (brief). "
               "Open SME question (24 Source_Notes question 3): whether each model's target set is shared with a lead portfolio or "
               "maintained separately. "
               "Rests on CD-176, CD-180, CD-314."
               "WP1 re-point (CW-202): Active Placements Reached filtered Model Placement Status = Active, which is not a value of the 05 Placement Status list read by DP-005; the filter now names 'Approved - Available', the value DP-005's Active Model Placements counts."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-130 re-specified at WP1 in specs_w1c_inv_iop_fdn.py
    # ------------------------------------------------------------------------------------------------------------------
    "DP-131": dict(
        definition=("Each ETF's daily creation and redemption baskets with their constituents, quantities per creation unit, "
                    "weights and cash in lieu, the Rule 6c-11 cash balancing amount and NAV per creation unit, and the custom "
                    "baskets with their reason, policy basis and approval, and whether each was disseminated. It drives basket "
                    "publication and is the Rule 6c-11(d) record of baskets and custom basket compliance. It publishes the basket "
                    "at the keys the AP order record uses (Basket ID, BSKT-, and Basket ID x constituent instrument), so DP-179 "
                    "ETF Creation & Redemption Operations takes the basket from here rather than reading 24 again (CD-361). NAV "
                    "per share is read from DP-165; the product owns no certified number."),
        business_questions=[
            "Which creation and redemption baskets did each ETF publish today, standard and custom, and were they all disseminated?",
            "Was every custom basket approved under the custom basket policies before it was used, and for which reason?",
            "How much of each basket is cash in lieu, and why?",
            "Does each basket's value tie to NAV per creation unit within tolerance after the balancing amount?",
            "How representative is each standard basket of the fund's portfolio holdings?",
        ],
        grain=("ETF basket (Basket ID, BSKT-: share class x basket date x basket purpose x basket type) as the header, with "
               "constituent lines at Basket ID x constituent instrument; the line carries Quantity per Creation Unit and Cash in "
               "Lieu Indicator, the fields 29 AP Creation / Redemption Order (Applied ETF Basket) and Basket Settlement Line "
               "(Basket Constituent, Basket Quantity) reference; daily"),
        dimensions=["ETF share class and product (DP-004)", "Basket date (DP-013)", "Basket purpose (creation, redemption)",
                    "Basket type (standard, custom)", "Instrument (DP-097)", "Portfolio (DP-140)", "Custom basket reason and policy basis",
                    "Approval status"],
        measures=[
            ("Baskets Published", "Count of ETF Baskets by Basket Share Class, Basket Date, Basket Purpose and Basket Type, with Basket Disseminated Indicator = Y shown separately.",
             [("24", "ETF Basket", "Basket ID"), ("24", "ETF Basket", "Basket Share Class"), ("24", "ETF Basket", "Basket Date"),
              ("24", "ETF Basket", "Basket Purpose"), ("24", "ETF Basket", "Basket Type"), ("24", "ETF Basket", "Basket Disseminated Indicator")]),
            ("Custom Basket Share %", "Custom baskets (Basket Type custom) / all baskets per ETF over the period.",
             [("24", "ETF Basket", "Basket Type"), "Baskets Published"]),
            ("Custom Baskets Without Approval", "Count of baskets with Basket Type custom that have no Custom Basket Approval, or Custom Basket Approval Status other than Approved, or Custom Basket Approval Timestamp after the start of the Basket Date's dealing day, or Custom Basket Policy Basis null.",
             [("24", "ETF Basket", "Basket Type"), ("24", "ETF Basket", "Basket Date"), ("24", "Custom Basket Approval", "Custom Basket Approval Status"),
              ("24", "Custom Basket Approval", "Custom Basket Approval Timestamp"), ("24", "Custom Basket Approval", "Custom Basket Policy Basis"),
              ("24", "Custom Basket Approval", "Custom Basket Approver")]),
            ("Cash in Lieu Share %", "Sum of Constituent Weight of constituents with Cash in Lieu Indicator = Y / sum of Constituent Weight of the basket, with Total Cash in Lieu Amount and counts by Cash in Lieu Reason.",
             [("24", "ETF Basket Constituent", "Constituent Basket"), ("24", "ETF Basket Constituent", "Constituent Weight"),
              ("24", "ETF Basket Constituent", "Cash in Lieu Indicator"), ("24", "ETF Basket Constituent", "Cash in Lieu Reason"),
              ("24", "ETF Basket", "Total Cash in Lieu Amount")]),
            ("Basket Value", "Sum over in-kind constituents of Quantity per Creation Unit x Approved Price Value (approved price of the prior valuation date, from DP-143) + Total Cash in Lieu Amount + Basket Balancing Amount.",
             [("24", "ETF Basket Constituent", "Constituent Instrument"), ("24", "ETF Basket Constituent", "Quantity per Creation Unit"),
              ("22", "Approved Price", "Priced Instrument"), ("22", "Approved Price", "Price Date"), ("22", "Approved Price", "Approved Price Value"),
              ("22", "Approved Price", "Price Approval Status"), ("24", "ETF Basket", "Total Cash in Lieu Amount"),
              ("24", "ETF Basket", "Basket Balancing Amount")]),
            ("NAV per Creation Unit Tie-Out", "NAV per Creation Unit - NAV per Share of the share class's NAV of record for the prior valuation date (from DP-165) x Creation Unit Size of 01 ETF Characteristics; zero expected, because NAV per Creation Unit is a derived copy (27).",
             [("24", "ETF Basket", "NAV per Creation Unit"), ("27", "Share Class NAV", "NAV Share Class"), ("27", "Share Class NAV", "NAV per Share"),
              ("27", "Share Class NAV", "Parent NAV Calculation"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "NAV Approval Status"), ("01", "ETF Characteristics", "Creation Unit Size")]),
            ("Basket Value Tie-Out", "Basket Value - NAV per Creation Unit, as an amount and in basis points of NAV per Creation Unit; flagged beyond the tolerance of the basket policy.",
             [("24", "ETF Basket", "NAV per Creation Unit"), "Basket Value"]),
            ("Creation Unit Size Mismatch", "Count of baskets whose Creation Unit Size differs from the Creation Unit Size of the product's 01 ETF Characteristics on the Basket Date.",
             [("24", "ETF Basket", "Creation Unit Size"), ("01", "ETF Characteristics", "Creation Unit Size"), ("01", "Share Class", "Parent Product")]),
            ("Portfolio Representation %", "For standard baskets: sum over the Basket Portfolio's end-of-day holdings of min(Holding Weight, Constituent Weight of the same instrument) (from DP-142), so 100% means the basket is a pro rata slice of the portfolio.",
             [("24", "ETF Basket", "Basket Portfolio"), ("24", "ETF Basket Constituent", "Constituent Weight"),
              ("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"),
              ("18", "Holding Valuation", "Holding Weight")]),
            ("Constituent Weight Total", "Sum of Constituent Weight over the basket's constituents; 100% expected within rounding.",
             [("24", "ETF Basket Constituent", "Constituent Weight")]),
        ],
        inputs=[
            ("24", "ETF Basket", ["Basket ID", "Basket Share Class", "Basket Date", "Basket Purpose", "Basket Type", "Basket Portfolio",
                                  "Creation Unit Size", "Basket Balancing Amount", "Total Cash in Lieu Amount", "NAV per Creation Unit",
                                  "Basket Disseminated Indicator", "Basket Constructed By"]),
            ("24", "ETF Basket Constituent", ["Constituent Basket", "Constituent Instrument", "Quantity per Creation Unit", "Constituent Weight",
                                              "Cash in Lieu Indicator", "Cash in Lieu Reason"]),
            ("24", "Custom Basket Approval", ["Custom Basket Reason", "Custom Basket Policy Basis", "Custom Basket Approver",
                                              "Custom Basket Approval Timestamp", "Custom Basket Approval Status"]),
            ("01", "ETF Characteristics", ["Replication Method", "Creation Unit Size", "Index Tracked"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Version Number", "NAV Approval Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View", "Holding Quantity"]),
            ("18", "Holding Valuation", ["Market Value Base", "Holding Weight"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Price Date", "Approved Price Value", "Price Approval Status"]),
        ],
        upstream=["DP-165", "DP-142", "DP-143", "DP-097", "DP-140", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="Each day's baskets by 6pm ET on the business day before the basket date (before dissemination to authorized participants and publication); tie-outs after the NAV of record is approved",
        history="Every basket, constituent line and custom basket approval kept for at least 5 years, the first 2 readily accessible (Rule 6c-11(d) record keeping)",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "API", "File extract", "Dashboard"],
        dq_rules=[
            "Basket ID is unique and follows BSKT-YYYYMMDD-nnnnn, and every basket has at least one ETF Basket Constituent or a Basket Balancing Amount for an all-cash basket.",
            "Every basket with Basket Type custom has a Custom Basket Approval with Custom Basket Reason and Custom Basket Policy Basis filled; no standard basket has one.",
            "Every constituent with Cash in Lieu Indicator = Y has a Cash in Lieu Reason, and Constituent Instrument resolves in DP-097.",
            "Basket Share Class resolves to an active ETF share class in DP-004 and Basket Portfolio resolves to the portfolio DP-140 links to its product on the Basket Date.",
            "Basket Disseminated Indicator = Y is set only on baskets whose custom approval, where required, is Approved.",
        ],
        notes=("Consumer-aligned product of FN-22; owning domain 24. Certified numbers: none; NAV per share comes from DP-165 "
               "(CD-330) and NAV per Creation Unit is a derived copy (27) tied out to it. "
               "Boundaries (CD-177, CD-200): basket construction in 24, AP order processing in 29, the creation and redemption "
               "transaction in 06, the AP agreement in 05. The daily website disclosure is 35 (CD-235). ETF capital markets "
               "(C-03.05, FN-23) reads this product for AP engagement. "
               "For DP-179 (Fund Operations, CD-361): the basket header is published at Basket ID and the lines at Basket ID x "
               "Constituent Instrument with Quantity per Creation Unit, matching 29 Applied ETF Basket, Basket Settlement Line "
               "Basket Constituent and Basket Quantity; DP-179 lists this product upstream; this product does not read 29, so there "
               "is no cycle. "
               "Upstream changes from the candidate: DP-143 added for the approved prices that value the basket; DP-005 dropped "
               "because no measure reads the AP agreement (05), which DP-179 reads. "
               "Taxonomy gap: ETF Basket has no dissemination timestamp, so the 6c-11 requirement to publish before the opening of "
               "regular trading is evidenced by the indicator only. "
               "Taxonomy gap: no object records the custom basket policies themselves (the conditions, tested by the board); "
               "Custom Basket Policy Basis is text. "
               "PII = Y: Custom Basket Approver and Basket Constructed By are employees; publish a view without them for authorized "
               "participant and capital markets use. "
               "Operating model: basket construction is in house (24); if the fund accounting agent builds the basket file, the rows "
               "arrive from it and the grain is unchanged (CD-297). "
               "Open SME question (24 Source_Notes question 8): who approves custom baskets, and are rejected baskets kept (drafted "
               "as kept). "
               "Rests on CD-177, CD-200, CD-235, CD-330, CD-361."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-132": dict(
        definition=("Every investee meeting the firm's portfolios could vote: agenda items, proxy advisor and management "
                    "recommendations, ballots by safekeeping account with record date shares and shares on loan, the firm's "
                    "vote decision and rationale per agenda item, each vote instruction with its against-management and "
                    "against-policy flags, lending recall decisions and the proxy voting reports built from them. It is the "
                    "Form N-PX and client account voting report content and the evidence that votes followed policy and "
                    "authority. The meeting event comes from DP-099 (17 Corporate Action Event), safekeeping accounts from "
                    "DP-167; the N-PX submission is 35's. It owns no certified number."),
        business_questions=[
            "Which meetings and ballots under the firm's voting authority were voted, and which were missed or late?",
            "How often did we vote against management and against our own policy, and was every override approved?",
            "How many record date shares were not voted because they were on loan, and when did we decide to recall?",
            "How closely did our votes follow the benchmark proxy advisor's recommendations, by proposal category?",
            "Which fund series and client accounts are due a proxy voting report for the period, and which are approved?",
        ],
        grain=("Vote instruction (VOTE-): ballot (meeting x safekeeping account) x agenda item, with companion facts at ballot, "
               "agenda item x voting policy (vote rationale), meeting x securities loan (recall decision) and proxy voting report"),
        dimensions=["Investee meeting and meeting type (DP-099)", "Issuer (DP-098)", "Instrument (DP-097)", "Safekeeping account (DP-167)",
                    "Portfolio (DP-140)", "Fund series (DP-004)", "Client account (DP-093)", "Voting policy and guideline",
                    "Voting authority holder", "Proposal category and proponent", "Proxy advisor (DP-240)", "Vote cast",
                    "Vote decision source", "Meeting date and record date"],
        measures=[
            ("Ballots Voted %", "Ballots whose Governing Voting Authority has Voting Authority Holder = firm and which have a Vote Instruction with Vote Confirmation Status confirmed for every agenda item of the meeting / all such ballots with Vote Deadline Timestamp in the period.",
             [("34", "Ballot", "Ballot Meeting"), ("34", "Ballot", "Governing Voting Authority"), ("34", "Ballot", "Vote Deadline Timestamp"),
              ("34", "Voting Authority Arrangement", "Voting Authority Holder"), ("34", "Vote Instruction", "Voted Ballot"),
              ("34", "Vote Instruction", "Voted Agenda Item"), ("34", "Vote Instruction", "Vote Confirmation Status"),
              ("34", "Investee Meeting Agenda Item", "Agenda Meeting")]),
            ("Missed Votes", "Count of firm-authority ballots with no confirmed Vote Instruction by Vote Deadline Timestamp, or with Instructed Timestamp after it, by reason (Share Blocking Indicator, Ballot Status).",
             [("34", "Ballot", "Vote Deadline Timestamp"), ("34", "Ballot", "Share Blocking Indicator"), ("34", "Ballot", "Ballot Status"),
              ("34", "Vote Instruction", "Instructed Timestamp"), ("34", "Vote Instruction", "Vote Confirmation Status")]),
            ("Against Management %", "Vote Instructions with Against Management Indicator = Y / all Vote Instructions in the period, by Proposal Category and Agenda Item Proponent.",
             [("34", "Vote Instruction", "Against Management Indicator"), ("34", "Investee Meeting Agenda Item", "Proposal Category"),
              ("34", "Investee Meeting Agenda Item", "Agenda Item Proponent")]),
            ("Against Policy Votes", "Count and share of Vote Instructions with Against Policy Indicator = Y, by Vote Decision Source.",
             [("34", "Vote Instruction", "Against Policy Indicator"), ("34", "Vote Instruction", "Vote Decision Source")]),
            ("Unapproved Overrides", "Count of Vote Instructions with Against Policy Indicator = Y whose Applied Vote Rationale has Override Approved By null.",
             [("34", "Vote Instruction", "Against Policy Indicator"), ("34", "Vote Instruction", "Applied Vote Rationale"),
              ("34", "Vote Rationale", "Override Approved By")]),
            ("Shares Voted %", "Shares Voted / Record Date Shares per ballot and agenda item, summed by portfolio and meeting; Record Date Shares and Shares on Loan Not Recalled are derived copies (28) read as given.",
             [("34", "Vote Instruction", "Shares Voted"), ("34", "Ballot", "Record Date Shares")]),
            ("Shares on Loan Not Voted", "Sum of Shares on Loan Not Recalled over ballots of the meeting, and its share of Record Date Shares.",
             [("34", "Ballot", "Shares on Loan Not Recalled"), ("34", "Ballot", "Record Date Shares")]),
            ("Recall Decisions", "Count of Lending Recall Decisions with Recall Decided Indicator = Y, and of meetings with shares on loan and no recall decision, by Materiality Assessment.",
             [("34", "Lending Recall Decision", "Recall Meeting"), ("34", "Lending Recall Decision", "Recall Decided Indicator"),
              ("34", "Lending Recall Decision", "Materiality Assessment"), ("34", "Ballot", "Shares on Loan Not Recalled")]),
            ("Proxy Advisor Alignment %", "Vote Instructions whose Vote Cast equals the Advisor Recommended Vote of the applied voting policy's Benchmark Proxy Advisor for the same agenda item / all instructions with such a recommendation.",
             [("34", "Vote Instruction", "Vote Cast"), ("34", "Proxy Advisor Recommendation", "Recommended Agenda Item"),
              ("34", "Proxy Advisor Recommendation", "Proxy Advisor"), ("34", "Proxy Advisor Recommendation", "Advisor Recommended Vote"),
              ("34", "Voting Policy", "Benchmark Proxy Advisor")]),
            ("Ballot Coverage of Holdings", "Count of portfolio holdings of the meeting's Event Instrument at the Record Date (from DP-142) under firm voting authority that have no Ballot on a safekeeping account assigned to that portfolio (28 Safekeeping Account Assignment, from DP-167).",
             [("17", "Corporate Action Event", "Event Instrument"), ("17", "Corporate Action Event", "Record Date"),
              ("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"), ("18", "Portfolio Holding", "Holding Date"),
              ("28", "Safekeeping Account Assignment", "Assigned Safekeeping Account"), ("28", "Safekeeping Account Assignment", "Owning Portfolio"),
              ("34", "Ballot", "Ballot Safekeeping Account"), ("34", "Voting Authority Arrangement", "Authority Portfolio")]),
            ("Voting Reports Pending", "Count of fund series (and client accounts with the Client Account Voting Report type) with Vote Instructions in the reporting period and no Proxy Voting Report of the period with Voting Report Approval Status = Approved, by Proxy Voting Report Type and days to the filing or delivery deadline.",
             [("34", "Proxy Voting Report", "Reporting Fund Series"), ("34", "Proxy Voting Report", "Reporting Client Account"),
              ("34", "Proxy Voting Report", "Proxy Voting Report Type"), ("34", "Proxy Voting Report", "Voting Report Period End"),
              ("34", "Proxy Voting Report", "Voting Report Approval Status"), ("28", "Safekeeping Account Assignment", "Owning Fund")]),
        ],
        inputs=[
            ("34", "Voting Policy", ["Voting Policy ID", "Voting Policy Name", "Voting Policy Type", "Benchmark Proxy Advisor",
                                     "Adopted Benchmark Policy Name", "Policy Client", "Policy Approval Status", "Policy Effective From",
                                     "Policy Effective To"]),
            ("34", "Voting Guideline", ["Guideline Policy", "Guideline Code", "Guideline Proposal Category", "Guideline Market",
                                        "Default Voting Position"]),
            ("34", "Voting Authority Arrangement", ["Authority Portfolio", "Authority Account", "Voting Authority Holder", "Applied Voting Policy",
                                                    "Voting Platform Provider", "Authority Effective From", "Authority Effective To"]),
            ("34", "Investee Meeting Agenda Item", ["Agenda Meeting", "Agenda Item Number", "Proposal Text", "Proposal Category",
                                                    "Agenda Item Proponent", "Management Recommendation"]),
            ("34", "Proxy Advisor Recommendation", ["Recommended Agenda Item", "Proxy Advisor", "Advisor Policy", "Advisor Recommended Vote",
                                                    "Recommendation Revised Indicator"]),
            ("34", "Ballot", ["Ballot Meeting", "Own Fund Proxy Campaign", "Ballot Safekeeping Account", "Governing Voting Authority",
                              "Ballot Control Number", "Ballot Entitlement", "Record Date Shares", "Shares on Loan Not Recalled",
                              "Vote Deadline Timestamp", "Share Blocking Indicator", "Ballot Status"]),
            ("34", "Vote Rationale", ["Rationale Agenda Item", "Rationale Voting Policy", "Vote Rationale Text", "Pre-Declared Vote Indicator",
                                      "Linked Engagement", "Override Approved By"]),
            ("34", "Vote Instruction", ["Vote Instruction ID", "Voted Ballot", "Voted Agenda Item", "Applied Vote Rationale", "Vote Cast",
                                        "Shares Voted", "Against Management Indicator", "Against Policy Indicator", "Vote Decision Source",
                                        "Vote Decision Maker", "Instructed Timestamp", "Vote Confirmation Status"]),
            ("34", "Lending Recall Decision", ["Recall Meeting", "Recall Securities Loan", "Recall Decided Indicator", "Materiality Assessment",
                                               "Recall Decision Maker", "Recall Requested Date"]),
            ("34", "Proxy Voting Report", ["Proxy Voting Report ID", "Reporting Fund Series", "Reporting Manager Entity", "Reporting Client Account",
                                           "Proxy Voting Report Type", "Voting Report Period Start", "Voting Report Period End",
                                           "No Votes Indicator", "Joint Report Indicator", "Voting Report Approval Status"]),
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Event Instrument", "Corporate Action Event Type",
                                              "Corporate Action Announcement Status", "Record Date", "Meeting Date"]),
            ("17", "Instrument", ["Instrument ID", "Issuer", "Instrument Type"]),
            ("28", "Safekeeping Account Assignment", ["Assigned Safekeeping Account", "Owning Fund", "Owning Portfolio", "Owning Client Account",
                                                      "Account Assignment Purpose", "Assignment Effective From", "Assignment Effective To"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View", "Holding Quantity"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-099", "DP-097", "DP-098", "DP-167", "DP-140", "DP-142", "DP-093", "DP-004", "DP-192", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day for ballots, recommendations and instructions received the prior day; vote confirmations within one business day of the voting platform's confirmation",
        history="All ballots, rationales, instructions, recall decisions and reports kept for at least 7 years (Advisers Act Rule 204-2 five years, extended for N-PX and client requests); policy versions kept indefinitely",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Regulatory report", "File extract"],
        dq_rules=[
            "Every Ballot references a Corporate Action Event of a meeting type in DP-099 (or an Own Fund Proxy Campaign) and a Ballot Safekeeping Account that resolves in DP-167.",
            "Shares Voted on each Vote Instruction is not greater than Record Date Shares - Shares on Loan Not Recalled of its ballot.",
            "Every Vote Instruction references an agenda item of the same meeting as its ballot, and Vote Cast is one of the votes the agenda item allows.",
            "Against Management Indicator = Y exactly when Vote Cast differs from the agenda item's Management Recommendation (where one is given).",
            "Every Vote Instruction with Against Policy Indicator = Y has an Applied Vote Rationale with Vote Rationale Text filled.",
        ],
        notes=("Consumer-aligned product of FN-24; owning domain 34. Certified numbers: none. "
               "Boundaries (CD-226, CD-230): investee votes in 34; own-fund shareholder proxy in 13 stays DP-071 Fund Proxy "
               "Solicitation Tracking, which this product does not change (a ballot on an own fund held by a firm portfolio references "
               "the 13 campaign by key only); the meeting event is the 17 corporate action read through DP-099; the Form N-PX "
               "submission is 35's, and board proxy voting reporting reaches the boards through 35, which reads this product "
               "(CD-234). Client presentation of votes is 12's. "
               "Record Date Shares and Shares on Loan Not Recalled are derived copies (28) and are read as given; the 28 entitlement "
               "(Ballot Entitlement) and the securities loan (Recall Securities Loan) are published as keys only. Safekeeping accounts "
               "and their owning portfolios come from DP-167; portfolios from DP-140. Proxy advisors are parties in DP-240. "
               "Vote Rationale Linked Engagement is published as the 34 engagement key; DP-133 lists this product upstream and reads "
               "votes linked to engagements, never the reverse. "
               "Operating model: in house, with a proxy voting agent and platform (Voting Platform Provider); an outsourced voting "
               "agent changes the source of the ballot and instruction rows, not the grain (brief, CD-297). "
               "Taxonomy gap: 28 has no dated on-loan quantity (deferred at Stage 3), so Shares on Loan Not Recalled cannot be tied "
               "out to the loan book. "
               "Taxonomy gap: Ballot has no voted or confirmation timestamp of its own; vote timeliness uses the Instructed "
               "Timestamp of the instructions. "
               "PII = Y: client accounts (Authority Account, Reporting Client Account, Ballot Safekeeping Account of an "
               "individual), Policy Client, and employee decision makers and override approvers. "
               "Open SME questions (34 Source_Notes): voting platform and proxy advisors (question 1); who approves policies and "
               "overrides (question 2); split votes and override frequency (question 3); recall materiality rule (question 4); "
               "client-retained or pass-through voting (question 5); joint manager N-PX filing (question 9). "
               "Rests on CD-226, CD-230, CD-234. "
               "W1b re-point (CW-934): SRD II left the definition (Proxy Voting Report Type value SRD II Voting Disclosure "
               "removed); 'Voting Reports Pending' reads the relabeled value Client Account Voting Report (was SMA Client Voting "
               "Report) and the client account wording of the REPOINTS (Authority Account, Reporting Client Account, Ballot "
               "Safekeeping Account). No input changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-133": dict(
        definition=("Engagement cases with investee companies, private portfolio companies and market bodies: objectives and "
                    "milestones, interactions, escalations and outcomes, collaborative initiative memberships, and the "
                    "stewardship reports and case studies built from them, set against the firm's holdings "
                    "of each engaged issuer. It tracks engagement progress for the stewardship team and supplies the firm's "
                    "stewardship report, PRI and NZAM reporting and client stewardship reporting. Engagement is 34's; issuer meetings are 23's and are read by "
                    "key through DP-121; votes linked to engagements come from DP-132 (CD-227). It owns no certified number."),
        business_questions=[
            "How many engagements are active by theme and milestone stage, and which have had no interaction for six months?",
            "What share of engagement objectives due this year were achieved, and which outcomes did closed engagements reach?",
            "Which engagements were escalated, and did the escalation lead to a vote against management or an investment decision?",
            "How much of our holdings by market value is in issuers we are actively engaging?",
            "Which engagements and case studies does each stewardship report cover, and is each framework's latest report approved?",
        ],
        grain=("Engagement case (ENGM-) x as-of date, with companion facts at engagement x objective sequence, engagement "
               "interaction, engagement x escalation sequence, stewardship report x engagement (reported engagement) and initiative x "
               "legal entity x membership period; weekly snapshots"),
        dimensions=["Engagement theme and status", "Engaged party: issuer (DP-098) or other party (DP-240)", "Engagement lead (DP-192)",
                    "Milestone stage", "Contact medium", "Escalation action type", "Collaborative initiative (DP-240)",
                    "Stewardship framework and report", "Legal entity (DP-013)", "Portfolio holding the issuer (DP-142)", "As-of date"],
        measures=[
            ("Active Engagements", "Count of Engagements with Engagement Status open on the as-of date, by Engagement Theme, Engagement Lead and the latest Engagement Milestone Stage reached by any of their objectives.",
             [("34", "Engagement", "Engagement ID"), ("34", "Engagement", "Engagement Status"), ("34", "Engagement", "Engagement Theme"),
              ("34", "Engagement", "Engagement Lead"), ("34", "Engagement Objective", "Objective Engagement"),
              ("34", "Engagement Objective", "Engagement Milestone Stage")]),
            ("Objectives Achieved %", "Engagement Objectives with Objective Achieved Date on or before Objective Target Date / objectives whose Objective Target Date is in the period.",
             [("34", "Engagement Objective", "Objective Target Date"), ("34", "Engagement Objective", "Objective Achieved Date")]),
            ("Dormant Engagements", "Active Engagements with no Engagement Interaction whose Interaction Date is in the last 180 days.",
             [("34", "Engagement Interaction", "Interaction Engagement"), ("34", "Engagement Interaction", "Interaction Date"), "Active Engagements"]),
            ("Interactions", "Count of Engagement Interactions with Interaction Date in the period, by Contact Medium, and those recorded as a 23 issuer meeting (Interaction Issuer Meeting filled).",
             [("34", "Engagement Interaction", "Interaction ID"), ("34", "Engagement Interaction", "Interaction Date"),
              ("34", "Engagement Interaction", "Contact Medium"), ("34", "Engagement Interaction", "Interaction Issuer Meeting")]),
            ("Escalated Engagements", "Count of Engagements with at least one Escalation Action, by Escalation Action Type, with those leading to a vote (Escalation Agenda Item filled) and to an investment decision (Resulting Investment Decision filled).",
             [("34", "Escalation Action", "Escalated Engagement"), ("34", "Escalation Action", "Escalation Action Type"),
              ("34", "Escalation Action", "Escalation Agenda Item"), ("34", "Escalation Action", "Resulting Investment Decision")]),
            ("Votes Linked to Engagements", "Count of vote decisions (34 Vote Rationale, from DP-132) with Linked Engagement filled in the period, and those whose vote instructions were against management.",
             [("34", "Vote Rationale", "Linked Engagement"), ("34", "Vote Rationale", "Rationale Agenda Item"),
              ("34", "Vote Instruction", "Applied Vote Rationale"), ("34", "Vote Instruction", "Against Management Indicator")]),
            ("Engagement Outcomes", "Count of engagements closed in the period by Engagement Outcome, and the share with a successful outcome.",
             [("34", "Engagement", "Engagement Outcome"), ("34", "Engagement", "Engagement Status")]),
            ("Holdings in Engaged Issuers %", "Market Value Base of end-of-day holdings whose instrument's Issuer is the Engaged Party of an Active Engagement / total Market Value Base of holdings, by portfolio and business line (from DP-142).",
             [("18", "Portfolio Holding", "Held Instrument"), ("18", "Holding Valuation", "Market Value Base"), ("17", "Instrument", "Issuer"),
              ("34", "Engagement", "Engaged Party"), "Active Engagements"]),
            ("Reported Engagements and Case Studies", "Count of Reported Engagement rows per Stewardship Report, and those with Case Study Indicator = Y and Issuer Named Indicator = Y.",
             [("34", "Reported Engagement", "Reported Engagement Case"), ("34", "Reported Engagement", "Case Study Indicator"),
              ("34", "Reported Engagement", "Issuer Named Indicator"), ("34", "Stewardship Report", "Stewardship Report ID")]),
            ("Stewardship Reports Not Approved", "Count of Stewardship Frameworks whose Stewardship Report for the latest Stewardship Report Period End has Stewardship Report Approval Status other than Approved, by Stewardship Reporting Entity.",
             [("34", "Stewardship Report", "Stewardship Framework"), ("34", "Stewardship Report", "Stewardship Reporting Entity"),
              ("34", "Stewardship Report", "Stewardship Report Period End"), ("34", "Stewardship Report", "Stewardship Report Approval Status")]),
            ("Active Initiative Memberships", "Count of Collaborative Initiative Memberships with Membership Status active and effective on the as-of date, and engagements run through each initiative (Collaborative Initiative).",
             [("34", "Collaborative Initiative Membership", "Membership Initiative"), ("34", "Collaborative Initiative Membership", "Membership Status"),
              ("34", "Collaborative Initiative Membership", "Membership Effective From"), ("34", "Collaborative Initiative Membership", "Membership Effective To"),
              ("34", "Engagement", "Collaborative Initiative")]),
        ],
        inputs=[
            ("34", "Engagement", ["Engagement ID", "Engaged Party", "Engagement Theme", "Engagement Headline", "Engagement Lead",
                                  "Engagement Start Date", "Engagement Status", "Engagement Outcome", "Collaborative Initiative",
                                  "Passive Status Review Indicator", "Engagement Information Classification"]),
            ("34", "Engagement Objective", ["Objective Engagement", "Objective Sequence", "Objective Description", "Engagement Milestone Stage",
                                            "Objective Target Date", "Objective Achieved Date"]),
            ("34", "Engagement Interaction", ["Interaction ID", "Interaction Engagement", "Contact Medium", "Interaction Issuer Meeting",
                                              "Interaction Date", "Interaction Employee", "Discussed Objective"]),
            ("34", "Escalation Action", ["Escalated Engagement", "Escalation Sequence", "Escalation Action Type", "Escalation Date",
                                         "Escalation Approver", "Escalation Agenda Item", "Resulting Investment Decision"]),
            ("34", "Collaborative Initiative Membership", ["Membership Initiative", "Member Legal Entity", "Membership Effective From",
                                                           "Membership Effective To", "Membership Status"]),
            ("34", "Stewardship Report", ["Stewardship Report ID", "Stewardship Framework", "Stewardship Reporting Entity",
                                          "Stewardship Report Product", "Stewardship Report Period Start", "Stewardship Report Period End",
                                          "Stewardship Report Approval Status", "Report Publication Location", "Framework Assessment Result"]),
            ("34", "Reported Engagement", ["Reported Engagement Case", "Case Study Indicator", "Issuer Named Indicator", "Report Section Reference"]),
            ("34", "Vote Rationale", ["Rationale Agenda Item", "Linked Engagement"]),
            ("34", "Vote Instruction", ["Vote Instruction ID", "Applied Vote Rationale", "Against Management Indicator"]),
            ("23", "Issuer Meeting", ["Issuer Meeting ID", "Meeting Issuer", "Meeting Start Timestamp"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk"]),
            ("17", "Instrument", ["Instrument ID", "Issuer"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line"]),
        ],
        upstream=["DP-121", "DP-132", "DP-098", "DP-097", "DP-240", "DP-142", "DP-140", "DP-192", "DP-004", "DP-013"],
        refresh="Weekly",
        timeliness="Weekly snapshot by Monday 9am ET of the prior week's engagement activity; stewardship report views by business day 10 after each reporting period end",
        history="Every engagement, objective, interaction and escalation kept for the life of the case plus 7 years; weekly snapshots for 3 years; stewardship reports kept indefinitely",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Engagement has an Engaged Party that resolves to an active party in DP-240 (or an issuer in DP-098), an Engagement Lead that resolves in DP-192, and an Engagement Status.",
            "Every Engagement Interaction with Interaction Issuer Meeting filled references a 23 Issuer Meeting whose Meeting Issuer is the engagement's Engaged Party.",
            "Objective Achieved Date, where filled, is on or after the Engagement Start Date of its engagement.",
            "Every Reported Engagement references an engagement that was open at some time during the stewardship report's period.",
            "No Engagement with Engagement Status closed lacks an Engagement Outcome.",
        ],
        notes=("Consumer-aligned product of FN-24; owning domain 34. Certified numbers: none. "
               "Boundaries (CD-227, CD-172): engagement is 34; issuer meetings are 23 and are read through DP-121 by key (no date, "
               "participant or topic repeated); 03 Sales Activity is never used. Escalations that lead to a vote or an investment "
               "decision link to DP-132 (agenda item) and DP-126 (Resulting Investment Decision, published as a key; DP-126 is not "
               "listed because no DP-126 attribute is read). Private company engagement reads the 30 portfolio company through its "
               "02 party (DP-240). Client stewardship presentation is 12's. "
               "Upstream additions to the candidate: DP-097 (instrument to issuer for holdings), DP-240 (non-issuer engaged parties "
               "and initiatives), DP-140 (portfolio and business line). "
               "Engagement Information Classification governs row-level access: engagements that may carry MNPI follow the DP-121 "
               "control and are restricted in every view. "
               "Taxonomy gap: Engagement Objective has no objective status other than the achieved date, so abandoned objectives "
               "cannot be told apart from those still open after the target date. "
               "PII = Y: issuer contacts, interaction summaries (not published by default), engagement leads and approvers. "
               "Operating model: in house; an engagement service provider changes the source of rows, not the grain (brief). "
               "Open SME questions (34 Source_Notes): the four-milestone engagement scale is common practice, not a standard, so the "
               "firm's milestone stages and outcome values need confirming (section 3). "
               "Rests on CD-172, CD-227. "
               "W1b re-point (CW-934): Signatory Status dropped, no successor (CW-934; the FRC UK Stewardship Code status left "
               "the US model); the measure Current Signatory Statuses is removed and its report-approval half kept as "
               "Stewardship Reports Not Approved over the re-cut Stewardship Framework values (Firm Stewardship Report, "
               "Voluntary Climate Report, PRI, NZAM, Other); the signatory grain fact, question, history and the FRC SME "
               "question are re-worded or dropped."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-134": dict(
        definition=("The issuer-level sustainability view: indicator definitions, vendor and company-reported observations, "
                    "vendor ESG ratings, the firm's own ESG assessments "
                    "and the exclusion lists with their members, joined to holdings for coverage. It is the one source "
                    "that portfolio construction, coded compliance rules and product disclosures read for an issuer's ESG standing "
                    "(CD-228); DP-135 builds portfolio and product metrics on it. Vendor datasets and licenses come from DP-044; "
                    "the assessment methodology is a 37 model read through DP-212. It owns no certified number."),
        business_questions=[
            "What share of each portfolio's holdings by market value has a current, approved firm ESG assessment and a vendor rating?",
            "Which issuers' firm assessments are stale or diverge most from vendor ratings?",
            "Which holdings are in issuers or instruments on an effective exclusion list, and which list changes took effect this period?",
            "Which observations come from datasets that are no longer active, and how current is each indicator's data?",
            "Which assessments rely on a methodology that is not validated in the model inventory?",
        ],
        grain=("Issuer (02 party) x as-of date for the conformed ESG standing (latest approved firm assessment, latest vendor rating per "
               "source and type, current exclusion memberships), with observation (issuer or "
               "instrument x indicator x period end x source dataset x as-of date), exclusion list version x member and holding x "
               "as-of date coverage as companion facts; daily"),
        dimensions=["Issuer and issuer sector (DP-098)", "Instrument (DP-097)", "Sustainability indicator and level", "Source dataset and vendor (DP-044)",
                    "ESG rating type", "Strategy scope of assessment (DP-004)", "Exclusion list and policy basis",
                    "Portfolio and business line (DP-140)", "Assessment methodology model (DP-212)", "As-of date"],
        measures=[
            ("Firm Assessment Coverage %", "Market Value Base of end-of-day holdings whose instrument's Issuer has a Firm ESG Assessment with Assessment Approval Status = Approved and Assessment Effective To null or after the as-of date / Market Value Base of all corporate-issuer holdings, by portfolio (from DP-142).",
             [("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Portfolio Holding", "Held Instrument"), ("18", "Holding Valuation", "Market Value Base"),
              ("17", "Instrument", "Issuer"), ("17", "Issuer Profile", "Issuer Type"), ("34", "Firm ESG Assessment", "Assessed Issuer"),
              ("34", "Firm ESG Assessment", "Assessment Approval Status"), ("34", "Firm ESG Assessment", "Assessment Effective To")]),
            ("Vendor Rating Coverage %", "Market Value Base of holdings whose Issuer has an ESG Rating Observation with Rating As-Of Date in the last 12 months / Market Value Base of corporate-issuer holdings, by Rating Source Dataset and ESG Rating Type.",
             [("34", "ESG Rating Observation", "Rated Issuer"), ("34", "ESG Rating Observation", "Rating Source Dataset"),
              ("34", "ESG Rating Observation", "ESG Rating Type"), ("34", "ESG Rating Observation", "Rating As-Of Date"),
              ("18", "Holding Valuation", "Market Value Base"), ("17", "Instrument", "Issuer")]),
            ("Stale Firm Assessments", "Count of issuers held whose latest approved Firm ESG Assessment has an Assessment Date more than 12 months before the as-of date.",
             [("34", "Firm ESG Assessment", "Assessed Issuer"), ("34", "Firm ESG Assessment", "Assessment Date"),
              ("34", "Firm ESG Assessment", "Assessment Approval Status")]),
            ("Assessment Divergence", "Absolute difference between the percentile rank of Firm ESG Score among assessed issuers and the percentile rank of ESG Rating Numeric Score of the primary vendor rating type among rated issuers; issuers above 40 percentile points are listed for review.",
             [("34", "Firm ESG Assessment", "Firm ESG Score"), ("34", "ESG Rating Observation", "ESG Rating Numeric Score"),
              ("34", "ESG Rating Observation", "ESG Rating Type")]),
            ("Excluded Holdings", "Count and Market Value Base of end-of-day holdings whose Held Instrument is an Excluded Instrument, or whose instrument's Issuer is an Excluded Issuer (with Excluded Instrument null), of an effective Exclusion List Member (Member Effective From on or before the as-of date, Member Effective To null or after it) of a list version with List Approval Status = Approved, by list and portfolio. A monitoring view: the coded rule and any breach are 33's.",
             [("34", "Exclusion List Member", "Member List"), ("34", "Exclusion List Member", "Excluded Issuer"),
              ("34", "Exclusion List Member", "Excluded Instrument"), ("34", "Exclusion List Member", "Member Effective From"),
              ("34", "Exclusion List Member", "Member Effective To"), ("34", "Sustainability Exclusion List", "List Approval Status"),
              ("18", "Portfolio Holding", "Held Instrument"), ("18", "Holding Valuation", "Market Value Base"), ("17", "Instrument", "Issuer")]),
            ("Exclusion List Changes", "Count of Exclusion List Members whose Member Effective From or Member Effective To falls in the period, by list and Member Inclusion Type.",
             [("34", "Exclusion List Member", "Member Effective From"), ("34", "Exclusion List Member", "Member Effective To"),
              ("34", "Exclusion List Member", "Member Inclusion Type")]),
            ("Members Below Revenue Threshold", "Count of revenue-based members whose Measured Revenue Percentage is below the list's Revenue Threshold Percentage (candidates for removal or evidence of an override).",
             [("34", "Exclusion List Member", "Measured Revenue Percentage"), ("34", "Sustainability Exclusion List", "Revenue Threshold Percentage")]),
            ("Observation Freshness", "For each indicator, the share of observed issuers whose latest Issuer Sustainability Observation has Reporting Period End Date within the last 18 months, and the share on an estimated Observation Data Basis.",
             [("34", "Issuer Sustainability Observation", "Observed Indicator"), ("34", "Issuer Sustainability Observation", "Observed Issuer"),
              ("34", "Issuer Sustainability Observation", "Reporting Period End Date"), ("34", "Issuer Sustainability Observation", "Observation Data Basis")]),
            ("Observations From Inactive Datasets", "Count of current observations and ratings whose Observation Source Dataset or Rating Source Dataset has a Dataset Status other than active in DP-044.",
             [("34", "Issuer Sustainability Observation", "Observation Source Dataset"), ("34", "ESG Rating Observation", "Rating Source Dataset"),
              ("14", "Dataset", "Dataset ID"), ("14", "Dataset", "Dataset Status")]),
            ("Assessments on Unvalidated Methodology", "Count of approved, effective Firm ESG Assessments whose Assessment Methodology Name (a reference to the 37 Model Inventory Entry) resolves, on Model ID and Model Version, to an entry with Model Use Status not in use, or with no Model Validation whose Model Validation Outcome is approved (CD-294, CD-246).",
             [("34", "Firm ESG Assessment", "Assessment Methodology Name"), ("37", "Model Inventory Entry", "Model ID"),
              ("37", "Model Inventory Entry", "Model Version"), ("37", "Model Inventory Entry", "Model Use Status"),
              ("37", "Model Validation", "Model Validation Outcome")]),
        ],
        inputs=[
            ("34", "Sustainability Indicator Definition", ["Indicator Code", "Indicator Version", "Indicator Name", "Indicator Level", "Indicator Unit",
                                                           "Sustainability Indicator Scope"]),
            ("34", "Issuer Sustainability Observation", ["Observation Key", "Observed Issuer", "Observed Instrument", "Observed Indicator",
                                                         "Reporting Period End Date", "Observed Value", "Observation Data Basis",
                                                         "Observation Source Dataset", "Originating Provider", "Observation As-Of Date"]),
            ("34", "ESG Rating Observation", ["Rated Issuer", "Rating Source Dataset", "ESG Rating Type", "ESG Rating Value", "ESG Rating Numeric Score",
                                              "Rating As-Of Date"]),
            ("34", "Firm ESG Assessment", ["ESG Assessment ID", "Assessed Issuer", "Assessment Strategy", "Assessment Date", "Firm ESG Score",
                                           "Environmental Pillar Score", "Social Pillar Score", "Governance Pillar Score", "Firm Controversy View",
                                           "Assessment Approval Status", "Assessment Effective To", "Assessment Methodology Name"]),
            ("34", "Sustainability Exclusion List", ["Exclusion List Code", "Exclusion List Version", "Exclusion List Name", "Exclusion Policy Basis",
                                                     "Revenue Threshold Percentage", "List Approval Status", "List Effective From"]),
            ("34", "Exclusion List Member", ["Member List", "Excluded Issuer", "Excluded Instrument", "Member Inclusion Type",
                                             "Measured Revenue Percentage", "Supporting Observation", "Member Effective From", "Member Effective To"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Status"]),
            ("17", "Instrument", ["Instrument ID", "Issuer", "Instrument Type", "Asset Class"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line", "Portfolio Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Use Status"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Completed Date", "Model Validation Outcome"]),
        ],
        upstream=["DP-098", "DP-097", "DP-142", "DP-140", "DP-044", "DP-212", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day: vendor files loaded the prior evening, approved assessments and list changes of the prior day, coverage on the prior day's end-of-day holdings",
        history="Observations and ratings are never overwritten (observation pattern) and kept 10 years; assessment and exclusion list versions kept indefinitely; daily coverage snapshots kept 3 years",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Dashboard"],
        dq_rules=[
            "Every Issuer Sustainability Observation and ESG Rating Observation names a source dataset that resolves in DP-044 and an issuer that resolves in DP-098.",
            "Each issuer, Assessment Strategy and Assessment Date has at most one Firm ESG Assessment with Assessment Approval Status = Approved.",
            "Every Exclusion List Member names an Excluded Issuer, and its effective periods for the same list and issuer or instrument never overlap.",
            "Every observed value's indicator has Indicator Level = Issuer in the Sustainability Indicator Definition.",
        ],
        notes=("Consumer-aligned product of FN-24; owning domain 34. Certified numbers: none. "
               "Boundaries (CD-228): datasets and licenses in 14 (DP-044), observations, assessments and exclusion lists in 34; 33 "
               "coded rules reference the 34 list version and store no members (CD-221), so Excluded Holdings is a monitoring view and "
               "never a compliance breach count. Fund-level vendor ratings stay 11; the label claimed at issue stays 17; 23 research "
               "holds no ESG score. "
               "Consumer-aligned by design (brief §9 call 4, §8 item 8): if an E1 product (Risk Measures DP-146 or an investment "
               "compliance foundational) needs exclusion lists or ESG observations upstream, this product is promoted to "
               "foundational; its upstream products are all foundational except DP-044, which would have to be replaced by the "
               "14 dataset read directly or a foundational licensing product. "
               "Models (CD-294, CD-246): the firm ESG assessment methodology is a 37 model read through DP-212. Model Inventory Entry "
               "reference added 2026-10-14 (CD-246, GAP-37-001): Assessment Methodology Name is that reference (re-typed at the Stage 4 "
               "consolidation), so the join is on Model ID and Model Version. "
               "Taxonomy gap: Firm ESG Assessment has no source observation link, so the "
               "data behind a firm view cannot be traced row by row. "
               "PII = N: Assessing Analyst and List Approved By are not published (approval status only), so DP-192 is dropped from the "
               "candidate's upstream; DP-140 is added for the portfolio dimension. Classification "
               "Confidential - Licensed because vendor ratings and observations are licensed data whose redistribution DP-044 governs. "
               "Operating model: in house; an ESG data vendor changes the source of rows, not the grain (brief). "
               "Open SME questions (34 Source_Notes): one firm ESG score per issuer or one per strategy (question 6); which vendors "
               "feed the data and whether estimated data is permitted (question 7); whether exclusion lists are firm-wide or per "
               "product and who owns them (question 10). "
               "Rests on CD-221, CD-228, CD-246, CD-294. "
               "W1b re-point (CW-934): Sustainability Indicator Definition.SFDR PAI Table and SFDR PAI Indicator Number dropped, "
               "no successor (CW-934; no measure read them); Sustainable Investment Determination dropped, no successor "
               "(CW-934), with the measure Determination Coverage %, its DQ rule (taxonomy-aligned shares, DNSH and good "
               "governance), the 'Sustainable investment framework' dimension and the determination in the definition, "
               "question and grain. The product keeps its US purpose (firm assessments, vendor ratings, exclusion lists)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-135": dict(
        definition=("Portfolio, product and entity sustainability metrics in one indicator vocabulary, financed emissions "
                    "attributed holding by holding, and climate targets with progress. It produces the firm's voluntary climate "
                    "(TCFD / IFRS S2), PCAF and NZAM reporting and the metrics shown for the products 01 ESG Classification marks "
                    "as ESG products (ESG investment approach or an ESG term in the name under SEC Rule 35d-1). Metrics are 34's, "
                    "the ESG investment approach 01's (CD-229); issuer data comes from DP-134. It owns no certified number."),
        business_questions=[
            "What are the sustainability metric values for each portfolio, product and the entity for the period, by indicator, with their data coverage?",
            "What are each portfolio's financed emissions and carbon footprint, and how good is the underlying data (PCAF score)?",
            "Which ESG products have no sustainability metric for the latest period end?",
            "How is each climate target progressing against its baseline and target year?",
        ],
        grain=("Portfolio, product or legal entity x period end x portfolio-level indicator x emission scopes x measurement basis "
               "(sustainability metric), with companion facts at financed emissions metric x portfolio holding and climate target "
               "code; monthly"),
        dimensions=["Indicator (DP-134)", "Portfolio (DP-140)", "Product and ESG investment approach (DP-004, 01)",
                    "Legal entity (DP-013)", "Period end", "Emission scopes", "Measurement basis and framework",
                    "PCAF asset class and attribution basis", "Issuer (DP-098)", "Calculation model (DP-212)", "Climate target"],
        measures=[
            ("Sustainability Metric Value", "Metric Value of the Portfolio Sustainability Metric rows for the scope (Metric Portfolio, Metric Product or Metric Legal Entity) and Metric Period End Date, by Metric Indicator, Metric Framework and Metric Measurement Basis, with Metric Coverage Percentage and Metric Unit.",
             [("34", "Portfolio Sustainability Metric", "Metric Value"), ("34", "Portfolio Sustainability Metric", "Metric Portfolio"),
              ("34", "Portfolio Sustainability Metric", "Metric Product"), ("34", "Portfolio Sustainability Metric", "Metric Legal Entity"),
              ("34", "Portfolio Sustainability Metric", "Metric Period End Date"), ("34", "Portfolio Sustainability Metric", "Metric Indicator"),
              ("34", "Portfolio Sustainability Metric", "Metric Framework"), ("34", "Portfolio Sustainability Metric", "Metric Measurement Basis"),
              ("34", "Portfolio Sustainability Metric", "Metric Coverage Percentage"), ("34", "Portfolio Sustainability Metric", "Metric Unit")]),
            ("Low Coverage Indicators", "Count of metric rows with Metric Coverage Percentage below 50%, by Metric Indicator and scope.",
             [("34", "Portfolio Sustainability Metric", "Metric Coverage Percentage"), ("34", "Portfolio Sustainability Metric", "Metric Indicator")]),
            ("Financed Emissions", "Sum of Attributed Emissions over the Financed Emissions Holding Detail rows of a financed emissions metric (tCO2e), by Emission Scopes Included and PCAF Asset Class.",
             [("34", "Financed Emissions Holding Detail", "Attributed Emissions"), ("34", "Financed Emissions Holding Detail", "PCAF Asset Class"),
              ("34", "Portfolio Sustainability Metric", "Emission Scopes Included")]),
            ("Financed Emissions Tie-Out", "Metric Value of the financed emissions metric - Financed Emissions; zero expected.",
             [("34", "Portfolio Sustainability Metric", "Metric Value"), "Financed Emissions"]),
            ("Attribution Factor Check", "Attribution Factor - Holding Value Used / Attribution Denominator Value for each holding detail row; flagged beyond 0.0001.",
             [("34", "Financed Emissions Holding Detail", "Attribution Factor"), ("34", "Financed Emissions Holding Detail", "Holding Value Used"),
              ("34", "Financed Emissions Holding Detail", "Attribution Denominator Value")]),
            ("Holding Value Tie-Out", "Holding Value Used - Market Value Base of the Detail Holding in DP-142 (derived copy check); and for listed rows with Attribution Basis EVIC, Attribution Denominator Value - the approved EVIC Analytic Measure Value of 22 Pricing Analytics Observation for the issuer's primary instrument at the period end (from DP-143).",
             [("34", "Financed Emissions Holding Detail", "Holding Value Used"), ("34", "Financed Emissions Holding Detail", "Detail Holding"),
              ("34", "Financed Emissions Holding Detail", "Attribution Basis"), ("34", "Financed Emissions Holding Detail", "Attribution Denominator Value"),
              ("18", "Portfolio Holding", "Holding ID"), ("18", "Holding Valuation", "Market Value Base"),
              ("22", "Pricing Analytics Observation", "Analytics Instrument"), ("22", "Pricing Analytics Observation", "Pricing Analytic Measure"),
              ("22", "Pricing Analytics Observation", "Analytic Measure Value"), ("22", "Pricing Analytics Observation", "Approved Analytics Value Indicator"),
              ("17", "Issuer Profile", "Primary Equity Instrument")]),
            ("Weighted PCAF Data Quality Check", "Sum of PCAF Data Quality Score x Holding Value Used / sum of Holding Value Used over the metric's holding details - Weighted PCAF Data Quality Score; zero expected.",
             [("34", "Financed Emissions Holding Detail", "PCAF Data Quality Score"), ("34", "Financed Emissions Holding Detail", "Holding Value Used"),
              ("34", "Portfolio Sustainability Metric", "Weighted PCAF Data Quality Score")]),
            ("ESG Products Without Metrics", "Count of products whose 01 ESG Classification ESG Investment Approach holds a value other than None, or whose ESG Term in Name Indicator = Y, with no Portfolio Sustainability Metric for the latest Metric Period End Date whose Metric Product is the product or whose Metric Portfolio implements it (Portfolio Implementation Link with Primary Implementation Indicator = Y, effective at the period end).",
             [("01", "ESG Classification", "ESG Investment Approach"), ("01", "ESG Classification", "ESG Term in Name Indicator"),
              ("01", "Investment Product", "Product ID"), ("34", "Portfolio Sustainability Metric", "Metric Product"),
              ("34", "Portfolio Sustainability Metric", "Metric Portfolio"), ("34", "Portfolio Sustainability Metric", "Metric Period End Date"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"), ("18", "Portfolio Implementation Link", "Implemented Product"),
              ("18", "Portfolio Implementation Link", "Primary Implementation Indicator"),
              ("18", "Portfolio Implementation Link", "Implementation Effective From"), ("18", "Portfolio Implementation Link", "Implementation Effective To")]),
            ("Climate Target Progress %", "(Baseline Value - latest Metric Value of the target's Target Indicator for the Target Portfolio or Target Legal Entity) / Baseline Value / Target Reduction Percentage, against the straight-line path from Baseline Year to Target Year; with Target Progress Status as recorded.",
             [("34", "Climate Target", "Climate Target Code"), ("34", "Climate Target", "Target Indicator"), ("34", "Climate Target", "Baseline Year"),
              ("34", "Climate Target", "Baseline Value"), ("34", "Climate Target", "Target Year"), ("34", "Climate Target", "Target Reduction Percentage"),
              ("34", "Climate Target", "Target Portfolio"), ("34", "Climate Target", "Target Legal Entity"), ("34", "Climate Target", "Target Progress Status"),
              ("34", "Portfolio Sustainability Metric", "Metric Value"), ("34", "Portfolio Sustainability Metric", "Metric Period End Date")]),
        ],
        inputs=[
            ("34", "Portfolio Sustainability Metric", ["Metric Portfolio", "Metric Product", "Metric Legal Entity", "Metric Indicator",
                                                       "Metric Period End Date", "Emission Scopes Included", "Metric Measurement Basis",
                                                       "Metric Framework", "Metric Calculation Standard", "Metric Value", "Metric Unit",
                                                       "Normalization Currency", "Metric Coverage Percentage", "Metric Data Basis",
                                                       "Weighted PCAF Data Quality Score", "Metric Model Name"]),
            ("34", "Financed Emissions Holding Detail", ["Detail Holding", "Detail Issuer", "PCAF Asset Class", "Holding Value Used", "Attribution Basis",
                                                         "Attribution Denominator Value", "Attribution Factor", "Attributed Emissions",
                                                         "PCAF Data Quality Score", "Source Observation"]),
            ("34", "Climate Target", ["Climate Target Code", "Climate Target Type", "Target Legal Entity", "Target Portfolio", "Target Indicator",
                                      "Target Emission Scopes", "Baseline Year", "Baseline Value", "Target Year", "Target Reduction Percentage",
                                      "AUM in Scope Percentage", "Latest Progress Metric", "Target Progress Status", "Target Status"]),
            ("34", "Sustainability Indicator Definition", ["Indicator Code", "Indicator Version", "Indicator Name", "Indicator Level", "Indicator Unit",
                                                           "Input Indicator"]),
            ("01", "ESG Classification", ["ESG Investment Approach", "ESG Term in Name Indicator"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From", "Implementation Effective To"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("22", "Pricing Analytics Observation", ["Analytics Instrument", "Analytics As-Of Date", "Pricing Analytic Measure", "Analytic Measure Value",
                                                     "Approved Analytics Value Indicator"]),
            ("17", "Issuer Profile", ["Issuer Party", "Primary Equity Instrument"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Use Status"]),
        ],
        upstream=["DP-134", "DP-142", "DP-140", "DP-143", "DP-098", "DP-212", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Month-end metrics by business day 15 after month-end; annual climate and NZAM reporting views by the firm's publication date",
        history="Every metric, holding detail and climate target kept for at least 10 years; restated metric rows kept",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "File extract", "API"],
        dq_rules=[
            "Every Portfolio Sustainability Metric names exactly one of Metric Portfolio, Metric Product or Metric Legal Entity as its scope (a product scope resolves through DP-140 to its implementing portfolios), and its Metric Indicator has Indicator Level other than Issuer.",
            "For every financed emissions metric, the sum of Attributed Emissions over its holding details equals Metric Value within 0.1%.",
            "Attribution Factor is between 0 and 1 and PCAF Data Quality Score is an integer from 1 to 5 on every holding detail row.",
        ],
        notes=("Consumer-aligned product of FN-24; owning domain 34. Certified numbers: none (no certified sustainability family is "
               "defined in CD-293). "
               "WP0 re-scope candidate (CW-041): the SFDR PAI statement, the product sustainability outcomes and the EET achieved "
               "values this product was built around left the US model (CW-934); what remains is voluntary climate, PCAF and "
               "NZAM reporting and the metrics behind ESG-named funds. The program lead confirms at WP0 whether the firm reports "
               "these and whether the product stays separate from DP-134. "
               "Boundaries (CD-229, CD-216): metrics in 34, the ESG investment approach and the Rule 35d-1 name flag in 01 (read "
               "directly; DP-004 is upstream for the product dimension); climate stress results stay 31 and read the 34 metric. "
               "Attribution denominators by row rule: 22 EVIC (read through DP-143), 14 vendor EVIC, 30 fair value through 22 Fair "
               "Value Determination, 14 GDP for sovereigns; only the 22 EVIC row is tied out here. "
               "Upstream changes from the candidate: DP-116 dropped, because product and portfolio values come from 18 holdings "
               "(DP-142), private fund portfolios included, and no capital account attribute is read; DP-098 (issuer primary "
               "instrument for the EVIC tie-out) and DP-212 added. "
               "Models (CD-294): estimation and attribution models behind metrics are registered in 37 (Metric Model Name) and read "
               "through DP-212; the model is a dimension of each metric row. "
               "Model Inventory Entry reference added 2026-10-14 (CD-246, GAP-37-001): Metric Model Name is that reference (re-typed "
               "at the Stage 4 consolidation), joined to DP-212 on Model ID and Model Version, and Climate Target Latest Progress "
               "Metric references the 34 Portfolio Sustainability Metric row. "
               "Taxonomy gap: no firm reporting attribute ties Climate Target AUM in Scope Percentage to Firm AUM (DP-241); the "
               "percentage is published as recorded and is not recomputed. "
               "Taxonomy gap: Portfolio Sustainability Metric has no approval status or version, so the metric shown is the row as "
               "recorded for the period end. "
               "PII = N: approvers are not published. Classification Confidential - Licensed until disclosure, because metrics "
               "embed licensed vendor data. "
               "Operating model: in house; an ESG calculation vendor changes the source of metric rows, not the grain (brief). "
               "Open SME questions (34 Source_Notes): data vendors and estimated data (question 7); climate targets after the NZAM "
               "relaunch (question 11). "
               "Rests on CD-216, CD-229, CD-293, CD-294, CD-324. "
               "W1: SFDR Classification, Sustainability Label, Minimum Sustainable Investment %, Minimum Taxonomy-Aligned "
               "Investment % and Principal Adverse Impacts Considered (01 ESG Classification) dropped, no successor in the "
               "wealth 01 (CW-901). "
               "W1b re-point (CW-934): PAI Calculation dropped, no successor (CW-934); Product Sustainability Outcome dropped, "
               "no successor (CW-934); Portfolio Sustainability Metric.Reporting PAI Calculation and PAI Actions Taken dropped, "
               "no successor (CW-934); Sustainability Indicator Definition.SFDR PAI Table and SFDR PAI Indicator Number dropped, "
               "no successor (CW-934). Measures removed: Commitment Met and EET Achieved Values (outcome only); PAI Indicator "
               "Value re-cut as Sustainability Metric Value over the 34 metric (Metric Framework values SFDR PAI and FCA ESG "
               "Sourcebook removed, no filter read them); Low Coverage Indicators no longer reads the statement's Overall Data "
               "Coverage Percentage; Products Missing Outcome re-cut as ESG Products Without Metrics. DQ rules on the outcome "
               "removed; PAI statement and outcome companion facts, the disclosure regime dimension, the SFDR and UK SDR "
               "reporting, the PAI deadline, the regulatory report delivery, the EET lineage to DP-064 (CD-313 lapses) and the "
               "SFDR review SME question removed."
               "WP1 re-point (CW-206): Firm AUM moved from DP-165 to DP-241; the taxonomy gap line is re-pointed. No input or measure changed."),
    ),
}
