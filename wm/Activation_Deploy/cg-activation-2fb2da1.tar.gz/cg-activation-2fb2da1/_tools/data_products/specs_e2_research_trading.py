"""Data product specifications: Wave E2, Investment Research (23) and Trading & Execution (25) consumer-aligned products.

DP-118 to DP-121 (23 Investment Research) and DP-122 to DP-125 (25 Trading & Execution). See CONTRACT.md and
00_Program/Expansion/Product_Briefs/Investment.md. Built on the Wave E1 foundational products; no certified number of
another product is recalculated here.
"""

# Shared input fragments (exact catalog names). Each product lists its own copy so that `uses` trace to its inputs.
EMP = ("20", "Employee", ["Employee ID", "Employment Status", "Home Org Unit"])
LE = ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Jurisdiction of Formation", "Party Master Cross-Reference"])

SPECS = {
    # ===================================================== 23 Investment Research =====================================================
    "DP-118": dict(
        definition=("Who covers which issuer, instrument, sector and country, what each analyst currently recommends with rating, "
                    "price target and conviction, how recommendations changed and how they have done since issue, and which research "
                    "notes were published and reviewed, set against the issuers the firm actually holds. It combines the 23 coverage, "
                    "universe, recommendation and publication records with holdings from DP-142, instruments from DP-097, issuers and "
                    "sectors from DP-098 and approved prices from DP-143, so that the Director of Research can close coverage gaps on "
                    "held names and portfolio managers see one current research view per subject. It owns no certified number: "
                    "recommendation return since issue is a labeled product measure, not an official return (CD-217)."),
        business_questions=[
            "Which issuers the firm holds have no effective primary analyst, and how much market value do they represent?",
            "What is the current recommendation, price target and conviction for each covered issuer, and which changed this week?",
            "Which current recommendations are older than their horizon or than 12 months and need to be refreshed?",
            "How have each analyst's recommendations done since issue, and what share moved in the recommended direction?",
            "Which research notes were released outside the investment team, and was each reviewed before release?",
            "How is coverage spread across analysts, and which coverage sits with analysts who have left the firm?",
        ],
        grain=("Research subject (issuer, instrument, sector or country) x recommending analyst x rating scale x as-of date "
               "(current recommendation view), with coverage assignment (analyst x subject x coverage role x effective period), "
               "recommendation history (recommendation x timestamp) and publication (publication x version x subject) as linked facts; "
               "daily snapshots"),
        dimensions=["As-of date (DP-013 calendar)", "Research subject: issuer (DP-098), instrument (DP-097), sector scheme and code, geography",
                    "Covering or recommending analyst and research team (DP-192)", "Research coverage role",
                    "Research universe", "Recommendation rating scale and rating", "Recommendation change type",
                    "Served investment strategy (DP-004)", "Holding portfolio and business line (DP-140)",
                    "Publication type and classification"],
        measures=[
            ("Held Issuers Without Primary Coverage",
             "Count of distinct issuers (17 Instrument.Issuer of each Held Instrument) with Holding Market Value Base <> 0 on the as-of "
             "Holding Date in the official Holding View of an active portfolio (Portfolio Status = active), for which no Research "
             "Coverage Assignment with Research Coverage Role = Primary Analyst has Covered Issuer = the issuer and Coverage Effective "
             "From <= as-of date < Coverage Effective To (or open). Holdings from DP-142.",
             [("18", "Portfolio Holding", "Held Instrument"), ("18", "Portfolio Holding", "Holding Date"),
              ("18", "Portfolio Holding", "Holding View"), ("18", "Portfolio Holding", "Holding Portfolio"),
              ("18", "Holding Valuation", "Market Value Base"), ("18", "Portfolio", "Portfolio Status"),
              ("17", "Instrument", "Issuer"), ("23", "Research Coverage Assignment", "Covered Issuer"),
              ("23", "Research Coverage Assignment", "Research Coverage Role"),
              ("23", "Research Coverage Assignment", "Coverage Effective From"),
              ("23", "Research Coverage Assignment", "Coverage Effective To")]),
            ("Held Market Value With Primary Coverage %",
             "Sum of Holding Market Value Base (DP-142) of held instruments whose issuer has an effective Primary Analyst coverage "
             "assignment / Sum of Holding Market Value Base of all held instruments with an issuer, on the as-of Holding Date, by "
             "business line and portfolio. A coverage ratio over IBOR market value; it is not AUM.",
             [("18", "Holding Valuation", "Market Value Base"), ("18", "Portfolio", "Business Line"),
              ("17", "Instrument", "Issuer"), ("23", "Research Coverage Assignment", "Covered Issuer"),
              ("23", "Research Coverage Assignment", "Research Coverage Role"), "Held Issuers Without Primary Coverage"]),
            ("Universe Coverage %",
             "Research Universe Members effective on the as-of date (Membership Effective From <= date < Membership Effective To) "
             "whose Member Issuer has an effective Primary Analyst coverage assignment / all effective members, per Research Universe "
             "with Research Universe Status = active.",
             [("23", "Research Universe Member", "Member Universe"), ("23", "Research Universe Member", "Member Issuer"),
              ("23", "Research Universe Member", "Membership Effective From"),
              ("23", "Research Universe Member", "Membership Effective To"), ("23", "Research Universe", "Research Universe Status"),
              ("23", "Research Coverage Assignment", "Covered Issuer"),
              ("23", "Research Coverage Assignment", "Research Coverage Role")]),
            ("Orphaned Coverage Count",
             "Effective Research Coverage Assignments whose Covering Analyst has Employment Status not in the employed statuses "
             "(DP-192) on the as-of date.",
             [("23", "Research Coverage Assignment", "Covering Analyst"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status")]),
            ("Current Recommendation",
             "For each subject x Recommendation Rating Scale x Recommending Analyst, the Research Recommendation with the latest "
             "Recommendation Timestamp <= as-of and Recommendation Approval Status = approved (the 23 rule). The team view is the "
             "current recommendation of the analyst whose Source Coverage Assignment has Research Coverage Role = Primary Analyst. "
             "House views are DP-126 committee decisions, not this measure.",
             [("23", "Research Recommendation", "Research Recommendation ID"),
              ("23", "Research Recommendation", "Recommended Issuer"), ("23", "Research Recommendation", "Recommended Instrument"),
              ("23", "Research Recommendation", "Recommending Analyst"),
              ("23", "Research Recommendation", "Recommendation Rating Scale"),
              ("23", "Research Recommendation", "Recommendation Rating"),
              ("23", "Research Recommendation", "Recommendation Timestamp"),
              ("23", "Research Recommendation", "Recommendation Approval Status"),
              ("23", "Research Recommendation", "Source Coverage Assignment"),
              ("23", "Research Coverage Assignment", "Research Coverage Role")]),
            ("Recommendation Changes",
             "Count of approved Research Recommendations with Recommendation Timestamp in the period, by Recommendation Change Type "
             "(initiation, upgrade, downgrade, target change, reiteration, drop).",
             [("23", "Research Recommendation", "Recommendation Change Type"),
              ("23", "Research Recommendation", "Recommendation Timestamp")]),
            ("Stale Recommendations",
             "Current Recommendations whose age (as-of date - Recommendation Timestamp) exceeds Recommendation Horizon Months, or 12 "
             "months where no horizon is set.",
             [("23", "Research Recommendation", "Recommendation Horizon Months"),
              ("23", "Research Recommendation", "Recommendation Timestamp"), "Current Recommendation"]),
            ("Price Target Upside %",
             "Price Target / Approved Price Value of the Recommended Instrument at the firm's primary pricing point on the latest "
             "Price Date <= as-of (DP-143) - 1, for current recommendations with an instrument and Target Currency = Approved Price "
             "Currency; not published otherwise.",
             [("23", "Research Recommendation", "Price Target"), ("23", "Research Recommendation", "Target Currency"),
              ("22", "Approved Price", "Approved Price Value"), ("22", "Approved Price", "Approved Price Currency"),
              ("22", "Approved Price", "Price Date"), ("22", "Approved Price", "Approved Pricing Point"),
              "Current Recommendation"]),
            ("Recommendation Return Since Issue",
             "Approved Price Value of the Recommended Instrument at the primary pricing point on the as-of (or recommendation end) "
             "date / Price at Recommendation - 1, in the price currency, without dividends. Product measure only (CD-217): any "
             "portfolio or share class return comes from DP-145.",
             [("23", "Recommendation Valuation Basis", "Price at Recommendation"),
              ("23", "Recommendation Valuation Basis", "Reference Approved Price"),
              ("22", "Approved Price", "Approved Price ID"), ("22", "Approved Price", "Priced Instrument"),
              ("22", "Approved Price", "Approved Price Value"), ("22", "Approved Price", "Price Date"),
              ("23", "Research Recommendation", "Recommended Instrument")]),
            ("Recommendation Hit Rate %",
             "Recommendations closed (superseded or past horizon) in the period whose Recommendation Return Since Issue has the sign "
             "implied by the Recommendation Rating (positive for buy-equivalent, negative for sell-equivalent; hold excluded) / all "
             "such closed buy- and sell-equivalent recommendations, by recommending analyst and rating scale.",
             [("23", "Research Recommendation", "Recommendation Rating"),
              ("23", "Research Recommendation", "Recommending Analyst"), "Recommendation Return Since Issue"]),
            ("Externally Released Publications Reviewed %",
             "Research Publications with External Release Indicator = Y whose Publication Review Status = approved by a Supervisory "
             "Reviewer other than the Lead Author before the External Release Date / all externally released publications in the "
             "period.",
             [("23", "Publication Review", "External Release Indicator"), ("23", "Publication Review", "External Release Date"),
              ("23", "Publication Review", "Publication Review Status"), ("23", "Publication Review", "Supervisory Reviewer"),
              ("23", "Research Publication", "Lead Author"), ("23", "Research Publication", "Publication Timestamp")]),
            ("Publications Issued",
             "Count of Research Publications with Publication Record Status = published and Publication Timestamp in the period, by "
             "Publication Type, Lead Author and primary subject (Publication Subject with Primary Subject Indicator = Y).",
             [("23", "Research Publication", "Research Publication ID"), ("23", "Research Publication", "Publication Type"),
              ("23", "Research Publication", "Publication Record Status"), ("23", "Research Publication", "Publication Timestamp"),
              ("23", "Publication Subject", "Primary Subject Indicator"), ("23", "Publication Subject", "Subject Issuer")]),
        ],
        inputs=[
            ("23", "Research Coverage Assignment", ["Research Coverage Assignment ID", "Covering Analyst", "Research Subject Type",
                                                    "Covered Issuer", "Covered Instrument", "Covered Sector Scheme", "Covered Sector Code",
                                                    "Covered Geography", "Research Coverage Role", "Covering Research Team",
                                                    "Served Investment Strategy", "Coverage Effective From", "Coverage Effective To"]),
            ("23", "Research Universe", ["Research Universe Code", "Research Universe Name", "Research Universe Type",
                                         "Universe Owner", "Research Universe Status"]),
            ("23", "Research Universe Member", ["Member Universe", "Member Subject Type", "Member Issuer", "Member Instrument",
                                                "Member Sector Scheme", "Member Sector Code", "Member Geography", "Inclusion Reason",
                                                "Membership Effective From", "Membership Effective To"]),
            ("23", "Research Recommendation", ["Research Recommendation ID", "Recommending Analyst", "Recommendation Subject Type",
                                               "Recommended Issuer", "Recommended Instrument", "Recommended Sector Scheme",
                                               "Recommended Sector Code", "Recommended Geography", "Source Coverage Assignment",
                                               "Recommendation Rating Scale", "Recommendation Rating", "Recommendation Change Type",
                                               "Previous Recommendation", "Conviction Level", "Price Target", "Fair Value Estimate",
                                               "Target Currency", "Recommendation Horizon Months", "Recommendation Timestamp",
                                               "Recommendation Approval Status", "Announcing Publication"]),
            ("23", "Recommendation Valuation Basis", ["Valuation Method", "Valuation Model", "Reference Approved Price",
                                                      "Price at Recommendation"]),
            ("23", "Research Publication", ["Research Publication ID", "Publication Version", "Publication Type", "Publication Title",
                                            "Lead Author", "Publication Timestamp", "Publication Classification",
                                            "Publication Record Status"]),
            ("23", "Publication Subject", ["Subject Publication", "Publication Subject Type", "Subject Issuer", "Subject Instrument",
                                           "Subject Sector Code", "Primary Subject Indicator"]),
            ("23", "Publication Review", ["Supervisory Reviewer", "Publication Review Status", "External Release Indicator",
                                          "External Release Date", "Released As Commentary", "Released As Content Asset",
                                          "Investment Recommendation Disclosure Indicator"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "Issuer", "Instrument Type", "Asset Class", "Instrument Status"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk", "Issuer Profile Status"]),
            ("17", "Issuer Classification Assignment", ["Classified Issuer", "Issuer Classification Scheme", "Issuer Sector Code",
                                                        "Primary Sector Scheme Indicator", "Issuer Classification Effective From",
                                                        "Issuer Classification Effective To"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date",
                                      "Approved Price Value", "Approved Price Currency", "Price Approval Status"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("01", "Investment Strategy", ["Strategy ID", "Strategy Name"]),
            ("09", "Geographic Unit", ["Geographic Unit ID", "Geographic Unit Name"]),
            EMP,
        ],
        upstream=["DP-097", "DP-098", "DP-143", "DP-142", "DP-140", "DP-192", "DP-013", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for coverage, holdings overlay and return measures; recommendation changes published as events within 15 minutes of approval",
        history="Daily snapshots kept 13 months; every recommendation, coverage assignment and publication version kept for at least 7 years (Rule 204-2 and FINRA Rule 2241 record keeping), never overwritten",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Event stream"],
        dq_rules=[
            "Every Research Recommendation with a Recommended Instrument has Recommended Issuer equal to the 17 Instrument.Issuer of that instrument (23 row ownership rule).",
            "No covered issuer has more than one effective Research Coverage Assignment with Research Coverage Role = Primary Analyst for the same Covered Sector Code on any date.",
            "Price at Recommendation equals the Approved Price Value of the Reference Approved Price (DP-143) for every recommendation with an instrument.",
            "Every Covering Analyst, Recommending Analyst and Lead Author resolves to an EMP- key in DP-192.",
            "Every Research Publication with External Release Indicator = Y has Publication Review Status = approved and a Supervisory Reviewer different from the Lead Author.",
            "Coverage Effective From is on or before Coverage Effective To for every assignment, and Recommendation Timestamp is not in the future.",
        ],
        notes=("Current recommendation follows the 23 rule (latest approved row per subject x rating scale x analyst); the team view is "
               "the primary analyst's; house views are 24 committee decisions in DP-126 (CD-172, Investment brief §6 item 9). "
               "Recommendation return and hit rate are product measures computed from DP-143 approved prices, not official returns "
               "(CD-217); price return only, no income. Externally released notes hand off to 01 commentary and 04 content assets, "
               "which are read by key only (Released As Commentary, Released As Content Asset). Held-issuer coverage uses DP-142 IBOR "
               "market value (DP-142 publishes Portfolio Market Value, never AUM). Code values assumed for drafting and to be "
               "confirmed (23 SME question 2): Research Coverage Role 'Primary Analyst', Recommendation Approval Status 'approved', "
               "Publication Record Status 'published', the buy- and sell-equivalent mapping of each rating scale. PII = Y: analyst, "
               "author, reviewer and universe owner names; publish an analyst-free coverage view for wide distribution. Unpublished "
               "recommendations are investment views behind the information barrier; distribution and sales functions do not "
               "receive them. Rests on CD-172, CD-217, CD-296, CD-311 (portfolio manager is not read here). "
               "W1b re-point (CW-923): history no longer cites MiFID II record keeping (FINRA Rule 2241 in its place); no input changed."),
    ),

    "DP-119": dict(
        definition=("The current internal credit rating, outlook and Rule 2a-7 minimal credit risk and first tier determination for "
                    "every issuer, trading counterparty and instrument the firm assesses, set beside the agency ratings published by "
                    "DP-098 and joined to the money market fund and credit holdings in DP-142 that depend on them. It reads the 23 "
                    "Internal Credit Assessment (CD-173) and evidences that every held eligible security has a current, approved "
                    "determination, flags reviews that are overdue and internal-to-agency divergences, and gives DP-115 counterparty "
                    "reviews the credit view they reference. It supplies the determination; the coded 2a-7 limits and their breaches "
                    "are 33 (CD-221, CD-222). It owns no certified number."),
        business_questions=[
            "Does every security held by a money market fund have a current, approved minimal credit risk determination?",
            "Which internal credit assessments are past their next review date, and which held issuers do they affect?",
            "Where does our internal rating differ from the agency ratings by three notches or more, and why?",
            "Which issuers were downgraded by an agency after our last assessment and need a review?",
            "Which approved trading counterparties lack a current internal credit view?",
        ],
        grain=("Assessed party or instrument x internal credit rating scale x effective period (current determination as of each date), "
               "joined to holding portfolio x held instrument x holding date for dependent holdings; daily snapshots"),
        dimensions=["As-of date (DP-013 calendar)", "Assessed issuer or counterparty (DP-098, DP-115)", "Assessed instrument (DP-097)",
                    "Credit analyst and approver (DP-192)", "Internal credit rating scale, rating and outlook",
                    "Agency and agency rating (DP-098)", "Holding portfolio and implemented product (DP-140, DP-004)",
                    "Money market fund type"],
        measures=[
            ("Current Internal Rating",
             "For each Assessed Party (or Assessed Instrument) x Internal Credit Rating Scale, the Internal Credit Assessment with "
             "Assessment Approval Status = approved and Assessment Effective From <= as-of date < Assessment Effective To (or open).",
             [("23", "Internal Credit Assessment", "Assessed Party"), ("23", "Internal Credit Assessment", "Assessed Instrument"),
              ("23", "Internal Credit Assessment", "Internal Credit Rating Scale"),
              ("23", "Internal Credit Assessment", "Internal Credit Rating"),
              ("23", "Internal Credit Assessment", "Assessment Approval Status"),
              ("23", "Internal Credit Assessment", "Assessment Effective From"),
              ("23", "Internal Credit Assessment", "Assessment Effective To")]),
            ("Overdue Credit Reviews",
             "Current Internal Ratings with Next Credit Review Date < as-of date, with the count and Market Value Base (DP-142) of "
             "held instruments of the assessed party.",
             [("23", "Internal Credit Assessment", "Next Credit Review Date"), ("18", "Holding Valuation", "Market Value Base"),
              ("17", "Instrument", "Issuer"), "Current Internal Rating"]),
            ("MMF Holdings Without Current Determination",
             "Count and Market Value Base of holdings on the as-of Holding Date in portfolios implementing a product with Money Market "
             "Fund Type populated (DP-140 implementation link, 01 Regulatory Classification) whose Held Instrument has Rule 2a-7 Eligible "
             "Security Indicator = Y (DP-097) and has no Current Internal Rating with Minimal Credit Risk Indicator = Y on the "
             "instrument or, failing that, on its issuer.",
             [("18", "Portfolio Holding", "Held Instrument"), ("18", "Portfolio Holding", "Holding Date"),
              ("18", "Portfolio Holding", "Holding Portfolio"), ("18", "Holding Valuation", "Market Value Base"),
              ("18", "Portfolio Implementation Link", "Implementing Portfolio"),
              ("18", "Portfolio Implementation Link", "Implemented Product"),
              ("01", "Regulatory Classification", "Money Market Fund Type"),
              ("17", "Regulatory Instrument Classification", "Rule 2a-7 Eligible Security Indicator"),
              ("23", "Internal Credit Assessment", "Minimal Credit Risk Indicator"), "Current Internal Rating"]),
            ("MMF Holdings With Minimal Credit Risk Determination %",
             "Market Value Base of money market fund holdings with a Current Internal Rating carrying Minimal Credit Risk Indicator = Y "
             "/ Market Value Base of all money market fund holdings in 2a-7 eligible securities, per fund and as-of date.",
             [("18", "Holding Valuation", "Market Value Base"), "MMF Holdings Without Current Determination"]),
            ("First Tier Share of MMF Holdings %",
             "Market Value Base of money market fund holdings whose Current Internal Rating has First Tier Determination Indicator = Y "
             "/ Market Value Base of the fund's holdings in 2a-7 eligible securities. An input to the 33 limit test, not the test.",
             [("23", "Internal Credit Assessment", "First Tier Determination Indicator"),
              ("18", "Holding Valuation", "Market Value Base"), "Current Internal Rating"]),
            ("Internal-to-Agency Divergence",
             "Current Internal Ratings where |internal notch - median Normalized Credit Rating Notch of the current agency ratings of "
             "the same issuer (or instrument)| >= 3; the internal notch is the agency-equivalent notch held on the Internal Credit "
             "Rating code value (DP-013 Code Value).",
             [("23", "Internal Credit Assessment", "Internal Credit Rating"), ("09", "Code Value", "Code"),
              ("17", "Credit Rating Assignment", "Rated Issuer"), ("17", "Credit Rating Assignment", "Rated Instrument"),
              ("17", "Credit Rating Assignment", "Normalized Credit Rating Notch"),
              ("17", "Credit Rating Assignment", "Credit Rating Effective To"), "Current Internal Rating"]),
            ("Agency Downgrades Since Last Assessment",
             "Current Internal Ratings whose issuer or instrument has a Credit Rating Assignment with Credit Rating Action = downgrade "
             "and Credit Rating Action Date > Assessment Effective From.",
             [("17", "Credit Rating Assignment", "Credit Rating Action"),
              ("17", "Credit Rating Assignment", "Credit Rating Action Date"), ("17", "Credit Rating Assignment", "Credit Rating Agency"),
              ("23", "Internal Credit Assessment", "Assessment Effective From"), "Current Internal Rating"]),
            ("Approved Counterparties Without Current Credit View",
             "Counterparties with Counterparty Approval Status = approved (DP-115) whose latest Counterparty Review has no Credit View, "
             "or whose Credit View is not a Current Internal Rating on the as-of date.",
             [("25", "Approved Counterparty Profile", "Counterparty Party"),
              ("25", "Approved Counterparty Profile", "Counterparty Approval Status"),
              ("25", "Counterparty Review", "Reviewed Counterparty"), ("25", "Counterparty Review", "Counterparty Review Date"),
              ("25", "Counterparty Review", "Credit View"), "Current Internal Rating"]),
            ("Assessments Pending Approval",
             "Internal Credit Assessments with Assessment Approval Status = pending, and their age in days since Assessment Effective "
             "From.",
             [("23", "Internal Credit Assessment", "Assessment Approval Status"),
              ("23", "Internal Credit Assessment", "Assessment Effective From")]),
        ],
        inputs=[
            ("23", "Internal Credit Assessment", ["Assessed Party", "Assessed Instrument", "Credit Analyst", "Internal Credit Rating Scale",
                                                  "Internal Credit Rating", "Internal Credit Outlook", "Expected Recovery Rate",
                                                  "Minimal Credit Risk Indicator", "First Tier Determination Indicator",
                                                  "Assessment Approval Status", "Assessment Approved By", "Assessment Effective From",
                                                  "Assessment Effective To", "Next Credit Review Date"]),
            ("17", "Credit Rating Assignment", ["Rated Instrument", "Rated Issuer", "Credit Rating Agency", "Credit Rating Type",
                                                "Credit Rating Value", "Credit Rating Outlook", "Credit Rating Action",
                                                "Credit Rating Action Date", "Normalized Credit Rating Notch", "Credit Rating Effective To"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk", "Issuer Profile Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "Issuer", "Instrument Type", "Asset Class", "Instrument Status"]),
            ("17", "Regulatory Instrument Classification", ["Regulatory Classified Instrument", "Rule 2a-7 Eligible Security Indicator",
                                                            "Regulatory Classification Effective From",
                                                            "Regulatory Classification Effective To"]),
            ("17", "Debt Terms", ["Maturity Date"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Product", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type"]),
            ("01", "Regulatory Classification", ["Money Market Fund Type"]),
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status", "Counterparty Tier"]),
            ("25", "Counterparty Review", ["Reviewed Counterparty", "Counterparty Review Date", "Credit View"]),
            ("09", "Code Value", ["Code", "Code Label"]),
            EMP,
        ],
        upstream=["DP-097", "DP-098", "DP-142", "DP-140", "DP-192", "DP-115", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1, before the money market funds' daily portfolio review",
        history="Daily snapshots kept 13 months; every assessment version kept for at least 6 years after the security was last held (Rule 2a-7 record keeping), never overwritten",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "No assessed party or instrument has more than one approved Internal Credit Assessment per Internal Credit Rating Scale effective on the same date.",
            "Every approved assessment has an Assessment Approved By different from the Credit Analyst.",
            "Every assessment with First Tier Determination Indicator = Y also has Minimal Credit Risk Indicator = Y.",
            "Every assessment with an Assessed Instrument has Assessed Party equal to the 17 Instrument.Issuer of that instrument (23 row ownership rule).",
            "Every Internal Credit Rating value has an agency-equivalent notch on its code value; a value without one is reported, not dropped from divergence.",
            "Every DP-115 Counterparty Review Credit View resolves to an Internal Credit Assessment of the same counterparty.",
        ],
        notes=("CD-173: internal assessments are 23; agency ratings stay 17 and are read through DP-098, never copied. Holdings come "
               "from DP-142 and the money market fund portfolios through the DP-140 implementation link and the 01 product's Money "
               "Market Fund Type (read directly from 01 with DP-004 upstream, because DP-004 does not yet publish that attribute). The "
               "coded 2a-7 limits, the daily and weekly liquid asset tests and breaches are 33 (CD-221, CD-222); this product supplies "
               "the determination and its currency, not the compliance result. DP-115 counterparty reviews hold the assessment key "
               "(Credit View); this product is where the assessment content is read (CD-315). Remaining maturity against the 397-day "
               "limit is a 33 test; Maturity Date is read only to drop matured instruments. Taxonomy gap: the internal-to-agency notch "
               "mapping is held on the Internal Credit Rating code values (23 design note), not as an L4 attribute, so the divergence "
               "measure traces to 09 Code Value; an 'Agency Equivalent Notch' attribute was dropped from 23 to meet the size target. "
               "Taxonomy gap: Internal Credit Assessment has no assessment identifier; rows are keyed by its grain. Open SME questions "
               "(23 SME question 3): does credit research make the 2a-7 determinations, and are internal ratings used in 33 limits? "
               "Code values assumed: Assessment Approval Status 'approved' and 'pending', Credit Rating Action 'downgrade'. PII = Y "
               "(credit analyst and approver). Rests on CD-173, CD-221, CD-222, CD-315."),
    ),

    "DP-120": dict(
        definition=("Analyst estimates by issuer, metric and fiscal period, economic forecasts by geography and indicator, the research "
                    "models behind them, and the quantitative research signal definitions with their dated scores per instrument. It "
                    "shows estimate and forecast revisions and signal coverage for security selection and asset allocation, checks that "
                    "signal input datasets are licensed for the use (DP-044), and lists the research models and signals that should be "
                    "in the 37 model inventory (DP-212, CD-294, CD-246). Signal scores remain 23 records read as given; the product "
                    "computes revisions and coverage from them and owns no certified number."),
        business_questions=[
            "Which issuers had the largest estimate revisions this week, and is the revision breadth positive or negative?",
            "Which covered issuers have no current estimate for the next fiscal period?",
            "How have our economic forecasts for each geography and indicator changed since the last round?",
            "Which active signals failed to produce scores on the latest date, or lost coverage?",
            "Which research models and signals used in investment decisions are not in the model inventory or not validated?",
            "Does any active signal rely on a dataset that is not licensed for research use?",
        ],
        grain=("Issuer x analyst x estimate metric x fiscal period x basis x estimate date (estimates); geography x economic indicator x "
               "forecast period x forecast date (forecasts); research signal version x instrument x as-of date (signal scores); research "
               "model x version and research signal x version as conformed dimensions; daily snapshots"),
        dimensions=["Estimate or score as-of date (DP-013 calendar)", "Issuer (DP-098)", "Instrument (DP-097)", "Analyst, economist, model author and signal owner (DP-192)",
                    "Estimate metric, fiscal period type and basis", "Forecast geography and economic indicator",
                    "Research model and version", "Research signal and version", "Model inventory entry and tier (DP-212)",
                    "Licensed dataset (DP-044)"],
        measures=[
            ("Estimate Revision %",
             "For each Estimated Issuer x Estimating Analyst x Estimate Metric x Fiscal Period End Date x Adjusted Basis Indicator, "
             "(latest Estimate Value - prior Estimate Value) / |prior Estimate Value|, where prior is the latest row with Estimate Date "
             "before the window start (default 30 days).",
             [("23", "Analyst Estimate", "Estimated Issuer"), ("23", "Analyst Estimate", "Estimating Analyst"),
              ("23", "Analyst Estimate", "Estimate Metric"), ("23", "Analyst Estimate", "Fiscal Period End Date"),
              ("23", "Analyst Estimate", "Adjusted Basis Indicator"), ("23", "Analyst Estimate", "Estimate Value"),
              ("23", "Analyst Estimate", "Estimate Date")]),
            ("Revision Breadth",
             "(Count of upward revisions - count of downward revisions) / count of estimates revised, per issuer and Estimate Metric "
             "within the window.",
             ["Estimate Revision %"]),
            ("Covered Issuers Without Current Estimate",
             "Issuers with an effective Research Coverage Assignment whose latest Analyst Estimate for the next Fiscal Period End Date "
             "after the as-of date is missing or has Estimate Date more than 90 days old.",
             [("23", "Research Coverage Assignment", "Covered Issuer"), ("23", "Research Coverage Assignment", "Coverage Effective From"),
              ("23", "Research Coverage Assignment", "Coverage Effective To"), ("23", "Analyst Estimate", "Fiscal Period End Date"),
              ("23", "Analyst Estimate", "Estimate Date")]),
            ("Economic Forecast Revision",
             "Latest Forecast Value - previous Forecast Value per Forecast Geography x Economic Indicator x Forecast Period End Date, "
             "by Forecast Date.",
             [("23", "Economic Forecast", "Forecast Geography"), ("23", "Economic Forecast", "Economic Indicator"),
              ("23", "Economic Forecast", "Forecast Period End Date"), ("23", "Economic Forecast", "Forecast Value"),
              ("23", "Economic Forecast", "Forecast Date")]),
            ("Signal Scored Instruments",
             "Count of distinct Scored Instrument with a Signal Score per Scored Signal x Score As-Of Date; a coverage drop is flagged "
             "when the count falls more than 10% from the previous as-of date.",
             [("23", "Research Signal Score", "Scored Signal"), ("23", "Research Signal Score", "Scored Instrument"),
              ("23", "Research Signal Score", "Score As-Of Date"), ("23", "Research Signal Score", "Signal Score")]),
            ("Active Signals Without Latest Score",
             "Research Signal Definitions with Research Signal Status = active and Signal Effective From <= as-of < Signal Effective To "
             "(or open) that have no Research Signal Score on the latest expected Score As-Of Date.",
             [("23", "Research Signal Definition", "Research Signal Code"), ("23", "Research Signal Definition", "Research Signal Version"),
              ("23", "Research Signal Definition", "Research Signal Status"),
              ("23", "Research Signal Definition", "Signal Effective From"), ("23", "Research Signal Definition", "Signal Effective To"),
              ("23", "Research Signal Score", "Score As-Of Date"), "Signal Scored Instruments"]),
            ("Research Models Missing From Model Inventory",
             "Research Models with Model Inventory Candidate Indicator = Y and Research Model Status = active whose Model Inventory "
             "Entry is null or does not resolve to a 37 Model ID and Model Version in DP-212.",
             [("23", "Research Model", "Research Model Key"), ("23", "Research Model", "Research Model Version"),
              ("23", "Research Model", "Model Inventory Candidate Indicator"), ("23", "Research Model", "Research Model Status"),
              ("23", "Research Model", "Model Inventory Entry"),
              ("37", "Model Inventory Entry", "Model ID"), ("37", "Model Inventory Entry", "Model Version")]),
            ("Active Signals Missing From Model Inventory",
             "Active Research Signal Definitions whose Model Inventory Entry is null or does not resolve to a 37 Model ID and Model "
             "Version in DP-212; listed for the model risk team to register or record as out of scope (CD-294).",
             [("23", "Research Signal Definition", "Research Signal Code"), ("23", "Research Signal Definition", "Research Signal Version"),
              ("23", "Research Signal Definition", "Research Signal Status"), ("23", "Research Signal Definition", "Model Inventory Entry"),
              ("37", "Model Inventory Entry", "Model ID"), ("37", "Model Inventory Entry", "Model Version")]),
            ("Inventoried Research Models Without Validation",
             "Research models and signals matched to a 37 entry whose Model Use Status = in use and whose latest Model Validation has "
             "no Model Validation Completed Date or a Model Validation Outcome other than approved, by Model Tier.",
             [("37", "Model Inventory Entry", "Model Use Status"), ("37", "Model Validation", "Validated Model"),
              ("37", "Model Validation", "Model Validation Completed Date"), ("37", "Model Validation", "Model Validation Outcome"),
              ("37", "Model Tier Assignment", "Model Tier"), "Research Models Missing From Model Inventory"]),
            ("Signals on Unlicensed Data",
             "Active signals whose Primary Input Dataset has no 14 Permitted Use Grant (DP-044) with Permission Status = permitted for "
             "a research or internal-model Permitted Use Category effective on the as-of date, or whose Dataset Status is not active.",
             [("23", "Research Signal Definition", "Primary Input Dataset"), ("14", "Dataset", "Dataset ID"),
              ("14", "Dataset", "Dataset Status"), ("14", "Permitted Use Grant", "Grant Dataset"),
              ("14", "Permitted Use Grant", "Permitted Use Category"), ("14", "Permitted Use Grant", "Permission Status"),
              ("14", "Permitted Use Grant", "Grant Effective From"), ("14", "Permitted Use Grant", "Grant Effective To")]),
        ],
        inputs=[
            ("23", "Analyst Estimate", ["Estimated Issuer", "Estimating Analyst", "Estimate Metric", "Fiscal Period Type",
                                        "Fiscal Period End Date", "Estimate Value", "Estimate Currency", "Estimate Date",
                                        "Adjusted Basis Indicator", "Source Research Model"]),
            ("23", "Research Model", ["Research Model Key", "Research Model Version", "Research Model Type", "Modeled Issuer",
                                      "Model Author", "Model Version Date", "Model Inventory Candidate Indicator", "Research Model Status",
                                      "Model Inventory Entry"]),
            ("23", "Economic Forecast", ["Forecast Geography", "Economic Indicator", "Forecast Period Type", "Forecast Period End Date",
                                         "Forecast Value", "Forecast Date", "Forecasting Economist"]),
            ("23", "Research Signal Definition", ["Research Signal Code", "Research Signal Version", "Research Signal Name", "Signal Type",
                                                  "Primary Input Dataset", "Signal Universe", "Signal Owner", "Related AI Use Case",
                                                  "Research Signal Status", "Signal Effective From", "Signal Effective To",
                                                  "Model Inventory Entry"]),
            ("23", "Research Signal Score", ["Scored Signal", "Scored Instrument", "Score As-Of Date", "Signal Score"]),
            ("23", "Research Coverage Assignment", ["Research Coverage Assignment ID", "Covered Issuer", "Covering Analyst",
                                                    "Research Coverage Role", "Coverage Effective From", "Coverage Effective To"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Type", "Model Purpose", "Model Owner",
                                             "Model Use Status"]),
            ("37", "Model Tier Assignment", ["Tiered Model", "Model Tier", "Tier Effective From", "Tier Effective To"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Completed Date", "Model Validation Outcome"]),
            ("17", "Instrument", ["Instrument ID", "Issuer", "Asset Class", "Instrument Status"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk", "Issuer Profile Status"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Status"]),
            ("14", "Permitted Use Grant", ["Grant Dataset", "Permitted Use Category", "Permission Status", "Grant Effective From",
                                           "Grant Effective To"]),
            ("09", "Geographic Unit", ["Geographic Unit ID", "Geographic Unit Name"]),
            EMP,
        ],
        upstream=["DP-097", "DP-098", "DP-192", "DP-013", "DP-044", "DP-212"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; signal scores for the as-of date by 6am ET, before portfolio construction runs",
        history="Every estimate, forecast and signal score kept as dated rows for 10 years (point-in-time back-testing); model and signal versions kept indefinitely",
        classification="Confidential - Licensed",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Research Signal Score references an active Research Signal Definition version whose Signal Effective From is on or before the Score As-Of Date.",
            "No Analyst Estimate has two rows for the same issuer, analyst, metric, fiscal period, basis and Estimate Date.",
            "Every Scored Instrument and Estimated Issuer resolves to an active DP-097 instrument or DP-098 issuer on the as-of date.",
            "Every active Research Model with Model Inventory Candidate Indicator = Y has a Model Inventory Entry that resolves to a DP-212 entry within 30 days of its Model Version Date, or is reported.",
            "Every Primary Input Dataset resolves to a DP-044 Dataset ID.",
        ],
        notes=("CD-294 and CD-246: a research model or signal used in investment decisions is registered in the 37 model inventory; the "
               "product flags candidates with no entry and reads tier and validation from DP-212. Signal scores are 23 records "
               "(taxonomy objects), used as given, not product-owned scores; revisions and coverage counts are not model outputs, so "
               "no measure here needs its own model entry. Licensed input datasets are read through DP-044 by key; the license terms "
               "stay there. Model Inventory Entry reference added 2026-10-14 (CD-246, GAP-37-001). "
               "Taxonomy gap: Signal Universe is free text, so signal coverage is measured against the "
               "previous as-of date rather than against a defined universe. Open SME questions: 23 SME question 5 (are signal scores "
               "persisted per instrument and date?) and 13 (are consensus and scenario values research records?). Code values assumed: "
               "Research Model Status and Research Signal Status 'active', Model Validation Outcome 'approved', Permission Status "
               "'permitted'. PII = Y (analyst, economist, model author and signal owner). Rests on CD-172, CD-246, CD-294."),
    ),

    "DP-121": dict(
        definition=("Every meeting between investment staff and issuer management with its participants, topics, per-person wall "
                    "crossings and MNPI flag, linked to the 38 MNPI escalation, insider list entries and restricted list entry that "
                    "followed. It joins the 23 meeting record (CD-224) to the 38 control record (CD-256) so that the Director of "
                    "Research and Corporate Compliance can evidence that MNPI received in a meeting was escalated and the issuer "
                    "restricted promptly, and shows which meetings served stewardship objectives. Trade surveillance against the "
                    "restriction stays a 38 product. It owns no certified number."),
        business_questions=[
            "Which meetings recorded MNPI, and was each escalated to compliance and the issuer restricted, and how quickly?",
            "Which wall-crossed staff are missing from the insider list for the escalation?",
            "Which restrictions are still open after the cleansing date?",
            "How many issuer meetings did each team hold, with which issuers and through which corporate access providers?",
            "Which meetings addressed stewardship objectives, for the stewardship team's engagement record?",
        ],
        grain=("Issuer meeting x participant x participant role, with the meeting's MNPI assessment, topics, escalation, insider list "
               "entries and restricted list entry as linked facts; event-driven, daily snapshots"),
        dimensions=["Meeting date (DP-013 calendar)", "Meeting issuer (DP-098)", "Internal participant and org unit (DP-192)",
                    "External participant and arranging provider (DP-240)", "Meeting format and channel", "Meeting topic category",
                    "MNPI decision", "Restricted list"],
        measures=[
            ("Issuer Meetings Held",
             "Count of Issuer Meetings with Meeting Start Timestamp in the period, by Meeting Issuer, Issuer Meeting Format, Meeting "
             "Channel and Arranging Provider.",
             [("23", "Issuer Meeting", "Issuer Meeting ID"), ("23", "Issuer Meeting", "Meeting Issuer"),
              ("23", "Issuer Meeting", "Meeting Start Timestamp"), ("23", "Issuer Meeting", "Issuer Meeting Format"),
              ("23", "Issuer Meeting", "Meeting Channel"), ("23", "Issuer Meeting", "Arranging Provider")]),
            ("MNPI Meetings",
             "Issuer Meetings with MNPI Received Indicator = Y in the period.",
             [("23", "Meeting MNPI Assessment", "MNPI Received Indicator"), "Issuer Meetings Held"]),
            ("MNPI Meetings Not Escalated",
             "MNPI Meetings with no MNPI Escalation Reference, or whose reference has no 38 MNPI Escalation with Source Issuer "
             "Meeting = the meeting.",
             [("23", "Meeting MNPI Assessment", "MNPI Escalation Reference"), ("38", "MNPI Escalation", "MNPI Escalation ID"),
              ("38", "MNPI Escalation", "Source Issuer Meeting"), "MNPI Meetings"]),
            ("Escalation Lag Hours",
             "Escalation Received Timestamp - Meeting Start Timestamp, in hours, per escalated MNPI meeting; reported as median and "
             "maximum by team and period.",
             [("38", "MNPI Escalation", "Escalation Received Timestamp"), ("23", "Issuer Meeting", "Meeting Start Timestamp"),
              ("38", "MNPI Escalation", "Source Issuer Meeting")]),
            ("Restriction Lag Hours",
             "Entry Added Timestamp of the Restricted List Entry whose Source MNPI Escalation = the escalation - Escalation Received "
             "Timestamp, in hours, for escalations with MNPI Decision = MNPI confirmed.",
             [("38", "Restricted List Entry", "Entry Added Timestamp"), ("38", "Restricted List Entry", "Source MNPI Escalation"),
              ("38", "MNPI Escalation", "Escalation Received Timestamp"), ("38", "MNPI Escalation", "MNPI Decision")]),
            ("Confirmed MNPI Without Restriction",
             "Escalations from issuer meetings with MNPI Decision = MNPI confirmed and no Restricted List Entry with Source MNPI "
             "Escalation = the escalation and Restricted Issuer = MNPI Issuer.",
             [("38", "MNPI Escalation", "MNPI Decision"), ("38", "MNPI Escalation", "MNPI Issuer"),
              ("38", "Restricted List Entry", "Source MNPI Escalation"), ("38", "Restricted List Entry", "Restricted Issuer")]),
            ("Wall-Crossed Staff Not on Insider List",
             "Internal Participants of MNPI meetings with Wall-Crossing Consent Indicator = Y for whom no Insider List Entry exists with "
             "Insider Escalation = the meeting's escalation and Internal Insider = the participant.",
             [("23", "Issuer Meeting Participant", "Participant Meeting"),
              ("23", "Issuer Meeting Participant", "Internal Participant"),
              ("23", "Issuer Meeting Participant", "Wall-Crossing Consent Indicator"),
              ("23", "Issuer Meeting Participant", "Wall-Crossing Timestamp"), ("38", "Insider List Entry", "Insider Escalation"),
              ("38", "Insider List Entry", "Internal Insider"), "MNPI Meetings"]),
            ("Open Restrictions Past Cleansing",
             "Restricted List Entries sourced from an issuer meeting escalation with no Entry Removed Timestamp whose escalation "
             "Cleansing Date < as-of date.",
             [("38", "Restricted List Entry", "Entry Removed Timestamp"), ("38", "Restricted List Entry", "Source MNPI Escalation"),
              ("38", "MNPI Escalation", "Cleansing Date")]),
            ("Stewardship Meetings",
             "Issuer Meetings with at least one Issuer Meeting Topic with Stewardship Objective Indicator = Y, by issuer and Meeting "
             "Topic Category; read by the 34 engagement product by key (CD-227).",
             [("23", "Issuer Meeting Topic", "Topic Meeting"), ("23", "Issuer Meeting Topic", "Stewardship Objective Indicator"),
              ("23", "Issuer Meeting Topic", "Meeting Topic Category"), "Issuer Meetings Held"]),
            ("Meetings Without Internal Participant",
             "Issuer Meetings with no Issuer Meeting Participant row with an Internal Participant (data completeness).",
             [("23", "Issuer Meeting Participant", "Participant Meeting"), ("23", "Issuer Meeting Participant", "Internal Participant"),
              "Issuer Meetings Held"]),
        ],
        inputs=[
            ("23", "Issuer Meeting", ["Issuer Meeting ID", "Meeting Issuer", "Meeting Start Timestamp", "Issuer Meeting Format",
                                      "Meeting Channel", "Arranging Provider", "Corporate Access Charge Basis", "Meeting Notes Location",
                                      "Meeting Notes Classification"]),
            ("23", "Issuer Meeting Participant", ["Participant Meeting", "Internal Participant", "External Participant",
                                                  "Meeting Participant Role", "Wall-Crossing Consent Indicator", "Wall-Crossing Timestamp"]),
            ("23", "Issuer Meeting Topic", ["Topic Meeting", "Topic Sequence", "Meeting Topic Category", "Stewardship Objective Indicator"]),
            ("23", "Meeting MNPI Assessment", ["MNPI Received Indicator", "MNPI Escalation Reference"]),
            ("38", "MNPI Escalation", ["MNPI Escalation ID", "MNPI Source Type", "Source Issuer Meeting", "MNPI Issuer",
                                       "Escalation Received Timestamp", "MNPI Decision", "MNPI Decided By", "Cleansing Date",
                                       "MNPI Escalation Classification"]),
            ("38", "Insider List Entry", ["Insider List", "Insider Escalation", "Internal Insider", "External Insider",
                                          "Access Obtained Timestamp", "Access Ceased Timestamp"]),
            ("38", "Restricted List Entry", ["Restricted List Entry ID", "Entry List", "Restricted Issuer", "Restricted Instruments",
                                             "Restriction Reason", "Source MNPI Escalation", "Entry Added Timestamp",
                                             "Entry Removed Timestamp"]),
            ("38", "Firm Restricted List", ["Restricted List Code", "Restricted List Name", "Restricted List Type"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
            EMP,
        ],
        upstream=["DP-098", "DP-192", "DP-013", "DP-240"],
        refresh="Intraday",
        timeliness="Within 15 minutes of a meeting log, escalation or restricted list change; full daily rebuild by 7am ET",
        history="Every meeting, participant, escalation and restriction kept for at least 5 years after the restriction is lifted (Advisers Act Section 204A and Rule 204A-1 record keeping); no row is overwritten",
        classification="Restricted - MNPI",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "Event stream", "API"],
        dq_rules=[
            "Every Issuer Meeting with MNPI Received Indicator = Y has an MNPI Escalation Reference that resolves to a 38 MNPI Escalation whose Source Issuer Meeting is the same meeting.",
            "Every Issuer Meeting Participant has exactly one of Internal Participant or External Participant populated.",
            "Every Wall-Crossing Timestamp is on or before the Meeting Start Timestamp's day end, and is populated whenever Wall-Crossing Consent Indicator = Y.",
            "MNPI Issuer on an escalation from a meeting equals the Meeting Issuer of that meeting.",
            "Every Internal Participant resolves to an EMP- key in DP-192 and every External Participant and Arranging Provider to a PTY- key in DP-240.",
        ],
        notes=("CD-224 and CD-256: the MNPI flag is 23; the escalation, insider list and restricted list are 38 and are read here as "
               "masters (no E1 product publishes them). Trade surveillance against the restriction (orders placed between MNPI receipt "
               "and restriction) is a 38 product, which may read this product and DP-123; it is not measured here. Meeting notes stay "
               "in the document store; only Meeting Notes Location is carried, and it is PII. Engagement is 34 and reads 23 meetings by "
               "key (CD-227); Stewardship Meetings is the hand-off count, not an engagement record. Taxonomy gap: the compliance "
               "determination fields dropped from 23 (reviewer, compliance notified timestamp, market sounding flag) were proposed to "
               "38 and are not yet in 38 MNPI Escalation, so a market sounding cannot be told apart from an inadvertent receipt. Code "
               "values assumed: MNPI Decision 'MNPI confirmed'. Open SME questions: 23 SME question 8 (who logs meetings, and how is "
               "MNPI escalated today?) and 23 SME question 10 (expert call chaperones). Restricted - MNPI: access limited to compliance, "
               "the Director of Research and the control room. PII = Y (internal and external participants, decided-by, insiders). "
               "Rests on CD-172, CD-224, CD-227, CD-256. "
               "W1b re-point (CW-923): history cites Advisers Act Section 204A and Rule 204A-1 in place of the EU MAR insider list; no input changed."),
    ),

    # ===================================================== 25 Trading & Execution =====================================================
    "DP-122": dict(
        definition=("The research unbundling and commission record from use to payment: approved research providers and subscriptions, "
                    "research consumed, the broker vote with its criterion scores, research budgets, commission schedules, commission "
                    "sharing arrangements with their dated balances, every research payment with its source, invoice and ledger posting, "
                    "and commission and research component spend summed from the DP-123 allocations. It is the single source of "
                    "commission spend, research commission component and research spend by broker, provider, fund, strategy, legal "
                    "entity and period (CD-312): Investment Operations, Fund Operations and 35 board soft-dollar reporting take these "
                    "numbers from here, never from the 18 transaction copies. It evidences the research quality "
                    "assessment behind the broker vote, the Section 28(e) basis of soft-dollar spend and the budget-to-payment position. Research expense in "
                    "the P&L stays a DP-191 certified number and is reconciled to, not restated."),
        business_questions=[
            "How much commission did we pay each broker this quarter, and how much of it was a research component?",
            "Where does each research budget stand against payments made, by legal entity and strategy?",
            "Do research payments to each provider follow the broker vote, and was every paid provider evaluated?",
            "What is the balance of each commission sharing arrangement, and does it reconcile to accruals and payments?",
            "How much soft-dollar research did each fund pay under Section 28(e), for the board?",
            "Were all research payments invoiced and posted to the ledger, and were expert calls approved?",
        ],
        grain=("Broker or research provider x fund portfolio x strategy x legal entity x period (spend and payment summary), with "
               "trade allocation cost detail (from DP-123), commission sharing balance (arrangement x statement date), research payment "
               "(provider x payment period x source) and evaluation round (provider x period x evaluator) as linked facts; daily, with "
               "quarter-end locked snapshots"),
        dimensions=["Period: trade date, payment period, evaluation period, budget year (DP-013 calendar)",
                    "Executing broker (DP-115)", "Research provider (DP-240)", "Portfolio and fund (DP-140)",
                    "Strategy (DP-004)", "Legal entity (DP-013)", "Research payment source", "Commission sharing arrangement",
                    "Evaluator and consuming employee (DP-192)", "Licensed dataset (DP-044)"],
        measures=[
            ("Commission Spend",
             "Sum of Commission Amount (Allocation Cost Detail, from DP-123) on Trade Allocations with Allocation Status not cancelled "
             "and Allocation Source other than internal cross, by Executing Broker, Allocated Portfolio, strategy (via the portfolio's "
             "implemented product) and Allocation Trade Date period. Single source of commission spend (CD-312).",
             [("25", "Allocation Cost Detail", "Commission Amount"), ("25", "Trade Allocation", "Allocation Status"),
              ("25", "Trade Allocation", "Allocation Source"), ("25", "Trade Allocation", "Executing Broker"),
              ("25", "Trade Allocation", "Allocated Portfolio"), ("25", "Trade Allocation", "Allocation Trade Date"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), ("01", "Investment Product", "Implemented Strategy")]),
            ("Research Commission Component",
             "Sum of Research Payment Component on the same allocations and slices as Commission Spend (CD-312).",
             [("25", "Allocation Cost Detail", "Research Payment Component"), "Commission Spend"]),
            ("Execution-Only Commission",
             "Commission Spend - Research Commission Component.",
             ["Commission Spend", "Research Commission Component"]),
            ("Off-Schedule Commission Allocations",
             "Count and Commission Amount of allocations whose Commission Rate differs from the Scheduled Commission Rate of the "
             "Applied Commission Schedule effective on the Allocation Trade Date (Schedule Effective From <= date < Schedule Effective "
             "To), or with no Applied Commission Schedule.",
             [("25", "Allocation Cost Detail", "Commission Rate"), ("25", "Allocation Cost Detail", "Applied Commission Schedule"),
              ("25", "Allocation Cost Detail", "Commission Amount"), ("25", "Commission Schedule", "Scheduled Commission Rate"),
              ("25", "Commission Schedule", "Schedule Effective From"), ("25", "Commission Schedule", "Schedule Effective To"),
              ("25", "Trade Allocation", "Allocation Trade Date")]),
            ("Commission Sharing Balance Difference",
             "Research Credit Balance at Balance Statement Date - (prior statement's Research Credit Balance + Research Payment "
             "Component of allocations with Applied Commission Sharing Arrangement = the arrangement traded between the two statement "
             "dates - Research Payment Amount of payments with Funding Commission Sharing Arrangement = the arrangement paid between "
             "them); nonzero beyond tolerance is a reconciliation break.",
             [("25", "Commission Sharing Balance", "Balance Arrangement"), ("25", "Commission Sharing Balance", "Balance Statement Date"),
              ("25", "Commission Sharing Balance", "Research Credit Balance"),
              ("25", "Allocation Cost Detail", "Applied Commission Sharing Arrangement"),
              ("25", "Allocation Cost Detail", "Research Payment Component"),
              ("25", "Research Payment", "Funding Commission Sharing Arrangement"), ("25", "Research Payment", "Research Payment Amount"),
              ("25", "Research Payment", "Payment Period End Date")]),
            ("Research Spend",
             "Sum of Research Payment Amount of Research Payments with Research Payment Status = paid, by Paid Research Provider, "
             "Research Payment Source, Funding Research Budget and payment period.",
             [("25", "Research Payment", "Research Payment Amount"), ("25", "Research Payment", "Research Payment Status"),
              ("25", "Research Payment", "Paid Research Provider"), ("25", "Research Payment", "Research Payment Source"),
              ("25", "Research Payment", "Funding Research Budget"), ("25", "Research Payment", "Payment Period End Date")]),
            ("Research Budget Utilization %",
             "Research Spend funded by the budget (Funding Research Budget = budget) in the Budget Year / Research Budget Amount, per "
             "Budget Legal Entity x Budget Strategy, for budgets with Budget Approval Status = approved.",
             [("25", "Research Budget", "Budget Year"), ("25", "Research Budget", "Budget Legal Entity"),
              ("25", "Research Budget", "Budget Strategy"), ("25", "Research Budget", "Research Budget Amount"),
              ("25", "Research Budget", "Budget Approval Status"), "Research Spend"]),
            ("Weighted Evaluation Score",
             "Sum(Criterion Score x Criterion Weight) / Sum(Criterion Weight) per Research Evaluation Round; the difference from "
             "Overall Evaluation Score is reported when greater than 0.5 points.",
             [("23", "Evaluation Criterion Score", "Scored Evaluation Round"), ("23", "Evaluation Criterion Score", "Criterion Score"),
              ("23", "Evaluation Criterion Score", "Criterion Weight"), ("23", "Research Evaluation Round", "Overall Evaluation Score")]),
            ("Vote-to-Payment Deviation",
             "Provider share of Research Spend for the evaluation period - average Vote Allocation Share of the provider across "
             "approved Research Evaluation Rounds of the same Evaluation Period End Date, in percentage points; flagged above 5 points.",
             [("23", "Research Evaluation Round", "Evaluated Provider"), ("23", "Research Evaluation Round", "Evaluation Period End Date"),
              ("23", "Research Evaluation Round", "Vote Allocation Share"), ("23", "Research Evaluation Round", "Evaluation Approval Status"),
              "Research Spend"]),
            ("Paid Providers Without Approved Evaluation",
             "Research Payments whose Research Evaluation Round is empty or not approved, or whose Paid Research Provider had Research "
             "Use Approval Status other than approved on the Payment Period End Date.",
             [("25", "Research Payment", "Research Evaluation Round"), ("25", "Research Payment", "Paid Research Provider"),
              ("23", "Research Evaluation Round", "Evaluation Approval Status"),
              ("23", "Research Provider Profile", "Research Use Approval Status"),
              ("23", "Research Provider Profile", "Provider Profile Effective From"),
              ("23", "Research Provider Profile", "Provider Profile Effective To")]),
            ("Section 28(e) Soft-Dollar Spend",
             "Research Commission Component on allocations whose Applied Commission Sharing Arrangement has Section 28(e) Safe Harbor "
             "Indicator = Y, by fund (implemented product of the Allocated Portfolio) and period; the figure 35 board reporting reads "
             "(CD-234).",
             [("25", "Commission Sharing Arrangement", "Arrangement Reference"),
              ("25", "Commission Sharing Arrangement", "Section 28(e) Safe Harbor Indicator"),
              ("25", "Allocation Cost Detail", "Applied Commission Sharing Arrangement"),
              ("18", "Portfolio Implementation Link", "Implemented Product"), "Research Commission Component"]),
            ("Research Payments Posted to Ledger %",
             "Paid research payments with Research Payment Source = Own Resources whose Research Invoice has GL Postings (DP-191) "
             "with Source Payable Invoice = the invoice in a posted journal and Sum(Posted Amount) = Invoice Gross Amount within "
             "tolerance / all such paid payments, by legal entity and period.",
             [("25", "Research Payment", "Research Invoice"), ("25", "Research Payment", "Research Payment Source"),
              ("19", "Payable Invoice", "Payable Invoice ID"), ("19", "Payable Invoice", "Invoice Gross Amount"),
              ("19", "GL Posting", "Source Payable Invoice"), ("19", "GL Posting", "Posted Amount"),
              ("19", "Journal Entry", "Journal Status"), "Research Spend"]),
            ("Unapproved Expert Calls",
             "Research Consumption Records with Research Interaction Type = expert call and Expert Call Approval Status other than "
             "approved, or with a Consumed Provider whose Expert Network Due Diligence Date is empty or more than 12 months before the "
             "Interaction Timestamp.",
             [("23", "Research Consumption Record", "Research Interaction Type"),
              ("23", "Research Consumption Record", "Expert Call Approval Status"),
              ("23", "Research Consumption Record", "Consumed Provider"), ("23", "Research Consumption Record", "Interaction Timestamp"),
              ("23", "Research Provider Profile", "Expert Network Due Diligence Date")]),
            ("Research Consumed Without Subscription",
             "Research Consumption Records whose Consumed Provider has no Research Service Subscription effective on the Interaction "
             "Timestamp (Subscription Start Date <= date <= Subscription End Date or open).",
             [("23", "Research Consumption Record", "Consumed Provider"), ("23", "Research Consumption Record", "Interaction Timestamp"),
              ("23", "Research Service Subscription", "Subscribed Provider"),
              ("23", "Research Service Subscription", "Subscription Start Date"),
              ("23", "Research Service Subscription", "Subscription End Date")]),
        ],
        inputs=[
            ("23", "Research Provider Profile", ["Research Provider Party", "Research Provider Type", "Approved Research Service Types",
                                                 "Research Use Approval Status", "Expert Network Due Diligence Date",
                                                 "Research Provider Profile Status", "Provider Profile Effective From",
                                                 "Provider Profile Effective To"]),
            ("23", "Research Service Subscription", ["Subscribed Provider", "Subscribed Service Type", "Subscribing Research Team",
                                                     "Subscription Start Date", "Subscription End Date", "Licensed Dataset"]),
            ("23", "Research Consumption Record", ["Consuming Employee", "Consumed Provider", "Research Interaction Type",
                                                   "Interaction Timestamp", "Related Issuer", "Expert Call Approval Status"]),
            ("23", "Research Evaluation Round", ["Evaluated Provider", "Evaluation Period Type", "Evaluation Period End Date", "Evaluator",
                                                 "Overall Evaluation Score", "Vote Allocation Share", "Evaluation Approval Status"]),
            ("23", "Evaluation Criterion Score", ["Scored Evaluation Round", "Evaluation Criterion", "Criterion Score", "Criterion Weight"]),
            ("25", "Commission Schedule", ["Schedule Broker", "Schedule Asset Class", "Schedule Market", "Schedule Commission Basis",
                                           "Scheduled Commission Rate", "Execution Component Rate", "Research Component Rate",
                                           "Schedule Effective From", "Schedule Effective To"]),
            ("25", "Commission Sharing Arrangement", ["Arrangement Executing Broker", "Arrangement Reference",
                                                      "Section 28(e) Safe Harbor Indicator", "Arrangement Status",
                                                      "Arrangement Effective From", "Arrangement Effective To"]),
            ("25", "Commission Sharing Balance", ["Balance Arrangement", "Balance Statement Date", "Research Credit Balance"]),
            ("25", "Research Budget", ["Budget Year", "Budget Legal Entity", "Budget Strategy", "Research Budget Amount",
                                       "Budget Approval Status"]),
            ("25", "Research Payment", ["Paid Research Provider", "Payment Period Type", "Payment Period End Date",
                                        "Research Payment Amount", "Research Payment Source", "Funding Research Budget",
                                        "Funding Commission Sharing Arrangement", "Research Evaluation Round", "Research Invoice",
                                        "Research Payment Status"]),
            ("25", "Trade Allocation", ["Trade Allocation ID", "Allocation Source", "Allocated Portfolio", "Executing Broker",
                                        "Allocation Trade Date", "Gross Trade Amount", "Settlement Currency", "Allocation Status"]),
            ("25", "Allocation Cost Detail", ["Commission Basis", "Commission Rate", "Commission Amount", "Research Payment Component",
                                              "Applied Commission Schedule", "Applied Commission Sharing Arrangement"]),
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status", "Counterparty Tier"]),
            ("19", "Payable Invoice", ["Payable Invoice ID", "Supplier", "Supplier Invoice Number", "Invoice Date", "Invoice Legal Entity",
                                       "Invoice Currency", "Invoice Gross Amount", "Payable Invoice Status"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Posted Amount", "Source Payable Invoice",
                                  "Cost Center Segment Value"]),
            ("19", "Journal Entry", ["Journal ID", "Posting Accounting Period", "Posting Legal Entity", "Journal Status"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Legal Owner Entity"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Product", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Implemented Strategy"]),
            ("01", "Investment Strategy", ["Strategy ID", "Strategy Name"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            EMP,
        ],
        upstream=["DP-115", "DP-123", "DP-191", "DP-192", "DP-013", "DP-044", "DP-240", "DP-140", "DP-004"],
        refresh="Daily",
        timeliness="Commission spend and arrangement accruals by 9am ET on T+1; quarter-end spend, vote and budget positions locked by business day 10 after quarter-end",
        history="Daily accruals kept 13 months; locked quarter-end snapshots, every payment, evaluation round and balance statement kept for at least 7 years (Rule 204-2 and SEC Rule 31a-2 record keeping)",
        classification="Restricted - Commercial Terms",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract", "Regulatory report"],
        dq_rules=[
            "Commission Spend for a quarter equals the sum of Commission Amount on the DP-123 allocations of that quarter with the same filters; no 18 Transaction Cost & Charge row is added (CD-312).",
            "Research Payment Component is less than or equal to Commission Amount on every allocation.",
            "Every Research Payment with Research Payment Source = commission sharing has a Funding Commission Sharing Arrangement, and every other source has a Research Invoice.",
            "Every Commission Sharing Balance statement after the first reconciles to the prior statement plus accruals less payments within the tolerance, or is reported as a break.",
            "Every Executing Broker, Schedule Broker and Arrangement Executing Broker resolves to a DP-115 counterparty, and every Paid Research Provider to a DP-240 party.",
            "Every Research Evaluation Round's Vote Allocation Shares for one evaluator and period sum to 100% within 0.1 points.",
        ],
        notes=("CD-174: commissions and research payments are 25, the broker vote and provider record are 23, invoices are 19. CD-312: "
               "commission and research component spend are summed from 25 Allocation Cost Detail of the allocations DP-123 publishes, "
               "never from the 18 copies; 18 rows not booked from an allocation (transfers, corporate actions, external manager trades) "
               "are reported by the 18 products as a separate line, not as broker commission. This product is the source of those "
               "figures for Investment Operations, Fund Operations and 35 board soft-dollar reporting (CD-234). CD-361: ledger postings "
               "come from DP-191; research expense in the P&L stays DP-191's certified operating expense and is reconciled here, not "
               "restated. 19 Payable Invoice is read directly from 19 because no Wave E1 product publishes invoices; DP-191 publishes "
               "the postings keyed by Source Payable Invoice. Research Payment Status is a Derived copy (19) read on the payment, because payments through commission sharing have no 19 invoice to read the status from; for invoiced payments the DQ check is that it agrees with Payable Invoice Status. Owned by 25 because C-01.04 is mastered by 25 and run by FN-23; research "
               "(FN-20) is the first supporting function. Expert network approvals in Research Consumption Record are also read by "
               "Corporate Compliance (FN-44). Taxonomy gap: Research Consumption Record carries no subscription or service type, so "
               "consumption is matched to subscriptions on provider and date only. Open "
               "SME questions: 23 SME question 9 and 25 SME question 5 (which entities pay research from own resources and which "
               "through Section 28(e) commission sharing) and 23 SME question 12 (criterion weights per round or per period). "
               "Code values assumed: Allocation Source 'internal cross', Research Payment Status 'paid', Research Interaction Type "
               "'expert call'. Restricted - Commercial Terms: broker rates and payments. PII = Y (consuming employees, evaluators, "
               "supplier names on invoices of sole-trader providers). Rests on CD-174, CD-234, CD-312, CD-315, CD-361. "
               "W1b re-point (CW-925): Commission Sharing Arrangement.Joint Payment Indicator dropped, no successor (CW-925); "
               "Research Budget.Research Payment Account Indicator and Client Research Charge Rate dropped, no successor "
               "(CW-925); no measure read them. 'Research Payments Posted to Ledger %' now filters Research Payment Source = Own "
               "Resources (the Research Payment Account value is removed); the RPA taxonomy gap (GAP-25-003) lapses; MiFID II "
               "and FCA COBS 2.3B left the definition, history and SME question."),
    ),

    "DP-123": dict(
        definition=("The trading record from the portfolio manager's order to the allocated fill: orders with their handling "
                    "instructions and event trail, blocks and block membership, broker placements, executions, and allocations to "
                    "portfolios and SMA accounts with commission, fee and tax detail, each traced to the 24 investment decision (DP-126) "
                    "and proposed trade (DP-128) that caused it. It assembles the 25 order-to-allocation chain once (CD-180) so that "
                    "trading, investment operations, compliance and surveillance share one record with fill rates, working times and "
                    "decision traceability. It is consumer-aligned (CD-314): Portfolio Transactions (DP-141) joins it by the ALLOC- key "
                    "and does not depend on it, and the 26, 33 and 38 consumers list it upstream instead of reading 25 again. It owns no "
                    "certified number; allocation-level commission detail is published here and aggregated into commission spend only by "
                    "DP-122 (CD-312)."),
        business_questions=[
            "Which orders are still working, how long have they been working, and what share of each block is filled?",
            "Can every order be traced to an investment decision or proposed trade, an AP order, a transition or a share class hedge?",
            "Did any block execute with a broker not approved for the activity and trading entity?",
            "Is every executed block fully allocated, and has every final allocation been booked to the IBOR?",
            "Which orders were released after a failed or overridden pre-trade compliance check?",
            "How many executions were corrected or cancelled, by broker and asset class?",
        ],
        grain=("Trade allocation (ALLOC-: block or cross x executing broker x trade order x portfolio or SMA account) as the main fact, "
               "with trade order (TORD-), order event (order x event type x timestamp), block order (BLOCK-), block membership, broker "
               "placement (block x broker x sequence) and execution (EXEC-) as linked facts at their own grains; intraday, with a T+1 "
               "snapshot"),
        dimensions=["Trade date and event timestamp (DP-013 calendar)", "Instrument and asset class (DP-097)", "Portfolio and business line (DP-140)",
                    "SMA account (DP-093)", "Executing or placement broker (DP-115)", "Trading legal entity (DP-013)",
                    "Order originator, assigned trader and block trader (DP-192)", "Investment decision (DP-126)",
                    "Proposed trade and rebalance run (DP-128)", "Order side, type and status", "Execution venue"],
        measures=[
            ("Block Fill Rate %",
             "Sum of Executed Quantity of Executions with Execution Type = fill (net of corrections and cancellations) across the "
             "block's Broker Placements / Block Quantity.",
             [("25", "Execution", "Executed Quantity"), ("25", "Execution", "Execution Type"), ("25", "Execution", "Execution Placement"),
              ("25", "Execution", "Corrected Execution"), ("25", "Broker Placement", "Placement Block Order"),
              ("25", "Block Order", "Block Quantity")]),
            ("Order Fill Rate %",
             "Sum of Allocated Quantity of the order's Trade Allocations with Allocation Status not cancelled / Order Quantity.",
             [("25", "Trade Allocation", "Allocated Quantity"), ("25", "Trade Allocation", "Allocated Trade Order"),
              ("25", "Trade Allocation", "Allocation Status"), ("25", "Trade Order", "Order Quantity")]),
            ("Order Working Time",
             "Latest Execution Timestamp of the order's block - Order Created Timestamp, in minutes, for completed orders; for open "
             "orders, as-of timestamp - Order Created Timestamp.",
             [("25", "Execution", "Execution Timestamp"), ("25", "Trade Order", "Order Created Timestamp"),
              ("25", "Trade Order", "Trade Order Status"), ("25", "Block Order Membership", "Member Trade Order"),
              ("25", "Block Order Membership", "Member Block Order")]),
            ("Placement Delay",
             "First Placement Timestamp of the block - Block Created Timestamp, in minutes.",
             [("25", "Broker Placement", "Placement Timestamp"), ("25", "Block Order", "Block Created Timestamp")]),
            ("Decision Traceability %",
             "Trade Orders with Originating Investment Decision resolving to a DP-126 Investment Decision, or with Related AP Order, "
             "Related Transition Event or Hedged Share Class populated / all Trade Orders created in the period.",
             [("25", "Trade Order", "Originating Investment Decision"), ("25", "Trade Order", "Related AP Order"),
              ("25", "Trade Order", "Related Transition Event"), ("25", "Trade Order", "Hedged Share Class"),
              ("24", "Investment Decision", "Investment Decision ID"), ("25", "Trade Order", "Order Created Timestamp")]),
            ("Orders Differing From Proposal",
             "Trade Orders with an Originating Proposed Trade whose Order Side differs from Proposed Trade Side, Order Portfolio from "
             "Proposed Trade Portfolio, Order Instrument from Proposed Trade Instrument, or Order Quantity from Proposed Quantity by "
             "more than 1%.",
             [("25", "Trade Order", "Originating Proposed Trade"), ("25", "Trade Order", "Order Side"),
              ("25", "Trade Order", "Order Portfolio"), ("25", "Trade Order", "Order Instrument"), ("25", "Trade Order", "Order Quantity"),
              ("24", "Proposed Trade", "Proposed Trade ID"), ("24", "Proposed Trade", "Proposed Trade Side"),
              ("24", "Proposed Trade", "Proposed Trade Portfolio"), ("24", "Proposed Trade", "Proposed Trade Instrument"),
              ("24", "Proposed Trade", "Proposed Quantity")]),
            ("Unallocated Executed Quantity",
             "Per block x executing broker: net filled Executed Quantity - Sum of Allocated Quantity of Trade Allocations with "
             "Allocated Block Order = the block and Executing Broker = the placement broker; nonzero after the allocation cut-off is "
             "an exception.",
             [("25", "Trade Allocation", "Allocated Block Order"), ("25", "Trade Allocation", "Executing Broker"),
              ("25", "Trade Allocation", "Allocated Quantity"), ("25", "Broker Placement", "Placement Broker"),
              ("25", "Execution", "Executed Quantity")]),
            ("Allocations Booked to IBOR %",
             "Final Trade Allocations (Allocation Status = final) whose Trade Allocation ID appears as Source Allocation ID on a DP-141 "
             "Portfolio Transaction with the same Transaction Quantity / all final allocations, by Allocation Trade Date (CD-314 join).",
             [("25", "Trade Allocation", "Trade Allocation ID"), ("25", "Trade Allocation", "Allocation Status"),
              ("25", "Trade Allocation", "Allocation Trade Date"), ("18", "Portfolio Transaction", "Source Allocation ID"),
              ("18", "Portfolio Transaction", "Transaction Quantity"), "Order Fill Rate %"]),
            ("Placements With Unapproved Brokers",
             "Broker Placements whose Placement Broker has no Counterparty Approval Scope (DP-115) with Scope Status = approved, Scope "
             "Trading Entity = the order's Trading Legal Entity and Scope Effective From <= Placement Timestamp < Scope Effective To, "
             "or whose Counterparty Approval Status is not approved.",
             [("25", "Broker Placement", "Placement Broker"), ("25", "Broker Placement", "Placement Timestamp"),
              ("25", "Trade Order", "Trading Legal Entity"), ("25", "Counterparty Approval Scope", "Scope Counterparty"),
              ("25", "Counterparty Approval Scope", "Approved Activity"), ("25", "Counterparty Approval Scope", "Scope Trading Entity"),
              ("25", "Counterparty Approval Scope", "Scope Status"), ("25", "Counterparty Approval Scope", "Scope Effective From"),
              ("25", "Counterparty Approval Scope", "Scope Effective To"),
              ("25", "Approved Counterparty Profile", "Counterparty Approval Status")]),
            ("Orders Released After Failed Compliance Check",
             "Trade Orders with a Trade Order Event whose Compliance Check Outcome is fail or overridden and a later release or "
             "placement event, by Event Performed By.",
             [("25", "Trade Order Event", "Event Trade Order"), ("25", "Trade Order Event", "Trade Order Event Type"),
              ("25", "Trade Order Event", "Event Timestamp"), ("25", "Trade Order Event", "Compliance Check Outcome"),
              ("25", "Trade Order Event", "Event Performed By")]),
            ("Allocation Explicit Cost",
             "Commission Amount + Exchange and Clearing Fee Amount + Regulatory Transaction Fee Amount + Transaction Tax Amount per "
             "Trade Allocation, in Settlement Currency. Allocation-level detail only; summed spend is DP-122 (CD-312).",
             [("25", "Allocation Cost Detail", "Commission Amount"), ("25", "Allocation Cost Detail", "Exchange and Clearing Fee Amount"),
              ("25", "Allocation Cost Detail", "Regulatory Transaction Fee Amount"),
              ("25", "Allocation Cost Detail", "Transaction Tax Amount"), ("25", "Trade Allocation", "Settlement Currency")]),
            ("Execution Corrections and Cancellations",
             "Count of Executions with Execution Type = correction or cancellation, by Placement Broker, asset class and trade date, "
             "and as a share of fills.",
             [("25", "Execution", "Execution Type"), ("25", "Execution", "Execution Timestamp"),
              ("25", "Broker Placement", "Placement Broker"), ("17", "Instrument", "Asset Class")]),
        ],
        inputs=[
            ("25", "Trade Order", ["Trade Order ID", "Order Portfolio", "Order Instrument", "Order Side", "Order Quantity",
                                   "Order Cash Amount", "FX Instrument Type", "Currency Pair", "Dealt Currency", "FX Value Date",
                                   "Order Type", "Order Limit Price", "Time in Force", "Trade Order Status", "Order Created Timestamp",
                                   "Order Reason", "Originating Investment Decision", "Originating Proposed Trade", "Order Originator",
                                   "Assigned Trader", "Trading Legal Entity", "Related Transition Event", "Related AP Order",
                                   "Hedged Share Class"]),
            ("25", "Order Handling Instruction", ["Directed Broker", "Step-Out Broker", "Trade-Away Indicator", "Execution Instructions",
                                                  "Large Trader ID", "Trade Rotation Program"]),
            ("25", "Trade Order Event", ["Event Trade Order", "Trade Order Event Type", "Event Timestamp", "Compliance Check Outcome",
                                         "Event Performed By"]),
            ("25", "Block Order", ["Block Order ID", "Block Instrument", "Block Side", "Block Quantity", "Block Created Timestamp",
                                   "Execution Strategy", "Block Trader", "Block Order Status", "Pre-Allocation Recorded Indicator"]),
            ("25", "Block Order Membership", ["Member Block Order", "Member Trade Order", "Pre-Allocation Quantity",
                                              "Late Addition Indicator"]),
            ("25", "Broker Placement", ["Placement Block Order", "Placement Sequence Number", "Placement Broker", "Placement Timestamp",
                                        "Placed Quantity", "Broker Algorithm", "Broker Client Order ID"]),
            ("25", "Execution", ["Execution ID", "Execution Placement", "Broker Execution ID", "Execution Type", "Executed Quantity",
                                 "Execution Price", "Execution Currency", "Execution Timestamp", "Execution Venue", "Broker Capacity",
                                 "Liquidity Indicator", "Dealt Amount", "Contra Amount", "Executed FX Rate", "Corrected Execution"]),
            ("25", "Trade Allocation", ["Trade Allocation ID", "Allocation Source", "Allocated Block Order", "Allocated Trade Order",
                                        "Allocated Portfolio", "Allocated Account", "Executing Broker", "Allocated Quantity",
                                        "Allocation Average Price", "Allocation Trade Date", "Contractual Settlement Date",
                                        "Gross Trade Amount", "Accrued Interest Amount", "Net Trade Amount", "Settlement Currency",
                                        "Allocation Method", "Allocation Status", "Reallocation Indicator"]),
            ("25", "Allocation Cost Detail", ["Commission Basis", "Commission Rate", "Commission Amount", "Research Payment Component",
                                              "Applied Commission Schedule", "Applied Commission Sharing Arrangement",
                                              "Exchange and Clearing Fee Amount", "Regulatory Transaction Fee Amount",
                                              "Transaction Tax Amount"]),
            ("24", "Investment Decision", ["Investment Decision ID", "Decision Action", "Decision Instrument", "Decision Maker",
                                           "Decision Timestamp"]),
            ("24", "Proposed Trade", ["Proposed Trade ID", "Proposing Rebalance Run", "Originating Investment Decision",
                                      "Proposed Trade Portfolio", "Proposed Trade Instrument", "Proposed Trade Side", "Proposed Quantity",
                                      "Proposed Trade Status"]),
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status", "Counterparty Tier"]),
            ("25", "Counterparty Approval Scope", ["Scope Counterparty", "Approved Activity", "Scope Trading Entity", "Scope Fund",
                                                   "Scope Status", "Scope Effective From", "Scope Effective To"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "Instrument Type", "Asset Class", "Instrument Status"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status", "Base Currency"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Managed Account",
                                                     "Implementation Effective From", "Implementation Effective To"]),
            ("18", "Portfolio Transaction", ["Portfolio Transaction ID", "Source Allocation ID", "Trade Date", "Transaction Quantity"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            EMP,
        ],
        upstream=["DP-115", "DP-126", "DP-128", "DP-097", "DP-140", "DP-093", "DP-192", "DP-013", "DP-141"],
        refresh="Intraday",
        timeliness="Orders, events, placements and executions within 15 minutes of the OMS / EMS event; allocations final by 7pm ET on trade date (before the affirmation cut-off); T+1 snapshot by 6am ET",
        history="Every order, event, placement, execution and allocation kept for at least 7 years (Rule 204-2 and Rule 31a-1 record keeping); amendments recorded as events and corrections, never overwritten",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Event stream", "API", "BI semantic model"],
        dq_rules=[
            "Every Trade Allocation with Allocation Source other than internal cross references a Block Order and an Executing Broker that placed that block.",
            "For every block, the Sum of Allocated Quantity by executing broker equals that broker's net filled Executed Quantity by the allocation cut-off.",
            "Every Allocated Account on an allocation is a Managed Account of the Allocated Portfolio through a DP-140 implementation link effective on the Allocation Trade Date.",
            "Every Trade Order belongs to exactly one Block Order Membership once placed, and every Block Order has at least one member order.",
            "Every corrected or cancelled Execution references a Corrected Execution on the same Broker Placement.",
            "Order Instrument resolves to a DP-097 instrument for every order except FX orders, which carry FX Instrument Type and Currency Pair instead.",
        ],
        notes=("CD-180: order, execution and allocation are 25. CD-314: DP-123 is consumer-aligned; DP-141 Portfolio Transactions carries "
               "Source Allocation ID as a key and does not list DP-123 upstream. This product reads DP-141 (foundational) only for the "
               "booked-to-IBOR reconciliation, which keeps the dependency one way. Trade confirmation and settlement (26), post-trade "
               "compliance (33) and trade surveillance (38) products list DP-123 upstream rather than re-assembling orders; DP-122, "
               "DP-124 and DP-125 do the same. Decision and proposal links are read through DP-126 and DP-128, which must never list "
               "DP-123 upstream (cycle). Compliance Check Outcome is read from the 25 order event, a Derived copy (33, CD-221), because "
               "the link between the event and its outcome lives in the copy; check run detail belongs to the 33 products. CD-312: "
               "Allocation Cost Detail is published at allocation grain only; commission spend by broker, fund and period is DP-122's. "
               "Operating model (CD-147, CD-297): in-house desks on an OMS / EMS (25 SME questions 1 and 12); for an outsourced trading "
               "desk the grain is unchanged, the provider's fills arrive as executions with the provider as placement broker, and "
               "DP-124 reviews the provider under the policy that names it. Taxonomy gap: Trade Allocation has no allocation timestamp "
               "(dropped from 25), so late allocation against the affirmation cut-off is measured from the T+1 snapshot. Taxonomy gap: "
               "no FX instrument exists in 17 (25 Source Notes), so FX orders carry no Order Instrument. Open SME questions: 25 SME "
               "questions 1 (system of record for allocations), 2 (allocation per portfolio and per SMA account; crosses booked as "
               "allocations) and 8 (trade rotation). Code values assumed: Execution Type 'fill', 'correction', 'cancellation'; "
               "Allocation Status 'final', 'cancelled'; Compliance Check Outcome 'fail', 'overridden'. PII = Y: Order Portfolio, "
               "Allocated Portfolio and Allocated Account are flagged (SMA clients), as are originator and trader. Rests on CD-147, "
               "CD-180, CD-221, CD-312, CD-314, CD-315. "
               "W1b re-point (CW-925): history no longer cites MiFID II record keeping; no input changed."),
    ),

    "DP-124": dict(
        definition=("Execution quality by order, block, execution, broker, venue and asset class: implementation shortfall, explicit "
                    "cost and cost against each TCA benchmark, outliers, periodic broker execution reviews and the best execution "
                    "committee's reviews against the policy in force. It reads the TCA measures held once on 25 TCA Result and TCA "
                    "Benchmark Result and uses them as given, joined to the DP-123 execution chain and the DP-115 broker dimension. It is "
                    "the evidence the best execution committee, the fund boards (through 35, CD-234) and regulators see, and the input to "
                    "broker allocation decisions. It owns no certified number."),
        business_questions=[
            "What did execution cost us this quarter by asset class, broker and venue, against arrival and each TCA benchmark?",
            "Which brokers rank best and worst on value-weighted implementation shortfall, and how did their reviews conclude?",
            "Which executions were outliers, and how many came from each broker?",
            "Is every asset class and legal entity reviewed by the committee on schedule against the policy in force?",
            "What share of executed value has TCA coverage, and did any execution use a venue the policy does not approve?",
        ],
        grain=("TCA result (TCA-: trade order, block order or execution x TCA provider x measurement date) x TCA benchmark, joined to the "
               "DP-123 execution chain; broker execution review (broker x period x asset class) and best execution review (committee "
               "review x period x asset class x legal entity) as linked facts; daily, with quarter-end locked snapshots"),
        dimensions=["Measurement and review period (DP-013 calendar)", "Asset class and instrument (DP-097)", "Broker (DP-115)",
                    "Execution venue and liquidity indicator", "Trading legal entity (DP-013)", "TCA provider and TCA benchmark",
                    "Best execution policy and version", "Execution strategy and broker algorithm"],
        measures=[
            ("Implementation Shortfall bps",
             "Value-weighted average of Implementation Shortfall bps over TCA Results in the slice, weights = Executed Quantity x "
             "Execution Price for execution-level results and Block Quantity (or Order Quantity) x Arrival Price for block- and "
             "order-level results; used as given, not recomputed.",
             [("25", "TCA Result", "Implementation Shortfall bps"), ("25", "TCA Result", "Arrival Price"),
              ("25", "TCA Result", "Measured Execution"), ("25", "TCA Result", "Measured Block Order"),
              ("25", "TCA Result", "Measured Trade Order"), ("25", "Execution", "Executed Quantity"),
              ("25", "Execution", "Execution Price"), ("25", "Block Order", "Block Quantity"), ("25", "Trade Order", "Order Quantity")]),
            ("Cost vs Benchmark bps",
             "Value-weighted average of Cost vs Benchmark bps per TCA Benchmark, with the weights of Implementation Shortfall bps.",
             [("25", "TCA Benchmark Result", "Benchmark TCA Result"), ("25", "TCA Benchmark Result", "TCA Benchmark"),
              ("25", "TCA Benchmark Result", "Cost vs Benchmark bps"), "Implementation Shortfall bps"]),
            ("Explicit Cost bps",
             "Value-weighted average of Explicit Cost bps over TCA Results in the slice.",
             [("25", "TCA Result", "Explicit Cost bps"), "Implementation Shortfall bps"]),
            ("Outlier Rate %",
             "TCA Results with Outlier Indicator = Y / all TCA Results, by broker, asset class and period.",
             [("25", "TCA Result", "Outlier Indicator"), ("25", "TCA Result", "TCA Result ID"), ("25", "TCA Result", "Measurement Date")]),
            ("Broker Shortfall Rank",
             "Rank of Placement Broker by Implementation Shortfall bps (lowest cost first) within asset class and period, shown with "
             "the latest Execution Quality Score and Broker Review Outcome for the broker.",
             [("25", "Broker Placement", "Placement Broker"), ("25", "Broker Execution Review", "Reviewed Broker"),
              ("25", "Broker Execution Review", "Execution Quality Score"), ("25", "Broker Execution Review", "Broker Review Outcome"),
              "Implementation Shortfall bps"]),
            ("Venue Mix %",
             "Executed value (Executed Quantity x Execution Price) by Execution Venue and Liquidity Indicator / total executed value, by "
             "asset class and period.",
             [("25", "Execution", "Execution Venue"), ("25", "Execution", "Liquidity Indicator"), ("25", "Execution", "Executed Quantity"),
              ("25", "Execution", "Execution Price"), ("17", "Instrument", "Asset Class")]),
            ("TCA Coverage %",
             "Executed value of fills with a TCA Result at execution, block or order level / total executed value, by asset class and "
             "period.",
             [("25", "TCA Result", "Measured Execution"), ("25", "TCA Result", "Measured Block Order"),
              ("25", "TCA Result", "Measured Trade Order"), ("25", "Execution", "Execution Type"), "Venue Mix %"]),
            ("Executions on Unapproved Venues",
             "Executions whose Execution Venue is not in Approved Execution Venues of the Best Execution Policy in force (Policy "
             "Effective From <= Execution Timestamp < Policy Effective To) for the instrument's asset class and the order's Trading "
             "Legal Entity.",
             [("25", "Execution", "Execution Venue"), ("25", "Execution", "Execution Timestamp"),
              ("25", "Best Execution Policy", "Approved Execution Venues"), ("25", "Best Execution Policy", "Policy Asset Class"),
              ("25", "Best Execution Policy", "Policy Legal Entity"), ("25", "Best Execution Policy", "Policy Effective From"),
              ("25", "Best Execution Policy", "Policy Effective To"), ("25", "Trade Order", "Trading Legal Entity")]),
            ("Overdue Best Execution Reviews",
             "Policy Asset Class x Policy Legal Entity combinations of policies in force with no Best Execution Review whose Review "
             "Period End Date is within the last quarter (Review Asset Class and Review Legal Entity matched).",
             [("25", "Best Execution Review", "Review Period End Date"), ("25", "Best Execution Review", "Review Asset Class"),
              ("25", "Best Execution Review", "Review Legal Entity"), ("25", "Best Execution Review", "Reviewed Policy"),
              ("25", "Best Execution Policy", "Policy Asset Class"), ("25", "Best Execution Policy", "Policy Legal Entity")]),
            ("Brokers Used Without Periodic Review",
             "Placement Brokers with executions in the review period that have no Broker Execution Review with the same Broker Review "
             "Period End Date and Broker Review Asset Class.",
             [("25", "Broker Placement", "Placement Broker"), ("25", "Broker Execution Review", "Reviewed Broker"),
              ("25", "Broker Execution Review", "Broker Review Period End Date"),
              ("25", "Broker Execution Review", "Broker Review Asset Class")]),
        ],
        inputs=[
            ("25", "Best Execution Policy", ["Policy Name", "Policy Version", "Policy Legal Entity", "Policy Asset Class",
                                             "Execution Factor Priority", "Approved Execution Venues", "Trading Operating Model",
                                             "Outsourced Trading Provider", "Policy Effective From", "Policy Effective To"]),
            ("25", "TCA Result", ["TCA Result ID", "Measured Trade Order", "Measured Block Order", "Measured Execution", "TCA Provider",
                                  "Measurement Date", "Arrival Price", "Implementation Shortfall bps", "Explicit Cost bps",
                                  "Outlier Indicator"]),
            ("25", "TCA Benchmark Result", ["Benchmark TCA Result", "TCA Benchmark", "Benchmark Price", "Cost vs Benchmark bps"]),
            ("25", "Broker Execution Review", ["Reviewed Broker", "Broker Review Period End Date", "Broker Review Period Type",
                                               "Broker Review Asset Class", "Execution Quality Score", "Broker Review Outcome"]),
            ("25", "Best Execution Review", ["Review Meeting Date", "Review Period End Date", "Review Asset Class", "Review Legal Entity",
                                             "Reviewed Policy", "Rule 606 Reports Reviewed Count", "Best Execution Review Outcome",
                                             "Review Findings", "Committee Chair"]),
            ("25", "Execution", ["Execution ID", "Execution Placement", "Execution Type", "Executed Quantity", "Execution Price",
                                 "Execution Currency", "Execution Timestamp", "Execution Venue", "Broker Capacity", "Liquidity Indicator"]),
            ("25", "Broker Placement", ["Placement Block Order", "Placement Broker", "Placement Timestamp", "Placed Quantity",
                                        "Broker Algorithm"]),
            ("25", "Block Order", ["Block Order ID", "Block Instrument", "Block Side", "Block Quantity", "Block Created Timestamp",
                                   "Execution Strategy"]),
            ("25", "Trade Order", ["Trade Order ID", "Order Instrument", "Order Side", "Order Quantity", "Trading Legal Entity"]),
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status", "Counterparty Tier"]),
            ("22", "Approved Price", ["Priced Instrument", "Approved Pricing Point", "Price Date", "Approved Price Value"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-123", "DP-115", "DP-143", "DP-097", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="TCA results by 10am ET on T+1 (provider delivery); quarterly review pack locked by business day 15 after quarter-end",
        history="TCA results and reviews kept for at least 7 years; quarter-end snapshots locked and kept with the committee minutes",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every TCA Result references exactly one of Measured Trade Order, Measured Block Order or Measured Execution, and that key resolves in DP-123.",
            "Arrival Price on an instrument TCA Result is within 20% of the DP-143 Approved Price Value of the instrument for the Measurement Date, or the result is reported for review (DQ check only; shortfall is not recomputed).",
            "Every TCA Benchmark Result references an existing TCA Result and has at most one row per TCA Benchmark.",
            "Exactly one Best Execution Policy version is in force per Policy Asset Class x Policy Legal Entity on any date.",
            "Every Reviewed Broker resolves to a DP-115 counterparty.",
        ],
        notes=("TCA measures are held once on TCA Result and TCA Benchmark Result (25) and used as given; DP-143 prices are read only for "
               "the arrival price DQ check. Rule 606 report counts are read from Best Execution Review. Board reporting of best "
               "execution is assembled by the 35 board reporting product from this one (CD-234). Broker commission spend for "
               "commission-versus-quality comparisons is DP-122's (CD-312) and is not summed here. Operating model (CD-147): Best "
               "Execution Policy names the outsourced trading provider where trading is outsourced; the reviews then cover the "
               "provider's executions, and the grain is unchanged. Taxonomy gap: TCA Result has no outlier disposition or comment (dropped "
               "from 25), so outlier follow-up cannot be evidenced here. Taxonomy gap: Approved Execution Venues is a multi-valued "
               "attribute, so the unapproved venue test parses the list. Open SME question: 25 SME question 9 (TCA provider, and are "
               "results per execution, order or block?). The quarterly review frequency is a drafting assumption. PII = Y (committee "
               "chair). Rests on CD-147, CD-234, CD-312, CD-314, CD-315."),
    ),

    "DP-125": dict(
        definition=("The controls on how trades are shared and reported: new issue indications and allocations against FINRA Rule 5130 "
                    "and 5131 eligibility, Rule 10f-3 purchases from syndicates with an affiliated underwriter, internal cross trades "
                    "against the independent current market price (Rule 17a-7), pre-allocation adherence and reallocations, trade errors "
                    "with gains, losses and reimbursements. It reads the 25 control records with the DP-123 allocation chain, so "
                    "that compliance and the fund boards (through 35, CD-234) share one evidence set for fair allocation. It owns "
                    "no certified number."),
        business_questions=[
            "Was each new issue allocated fairly against the indications, and did any equity new issue go to an account that was not eligible?",
            "Did every Rule 10f-3 purchase meet the conditions and reach the board report?",
            "Was every internal cross executed at the independent current market price, approved and without commission?",
            "Were block allocations made as pre-allocated, and how many were reallocated after the fact?",
            "What did trade errors cost this quarter, and were losses reimbursed and logged as incidents?",
        ],
        grain=("Control event x portfolio or SMA account: new issue allocation (offering x portfolio or account), Rule 10f-3 purchase "
               "(offering x fund x allocation), cross trade, block membership (block x order) and trade error, each as its own fact; daily, with quarter-end "
               "locked snapshots for board reporting"),
        dimensions=["Trade, pricing and report date (DP-013 calendar)", "Offering and instrument (DP-097)", "Portfolio, fund and business line (DP-140, DP-004)",
                    "SMA account (DP-093)", "Broker, bookrunner and seller (DP-115)", "Trading legal entity (DP-013)",
                    "Control type and status"],
        measures=[
            ("New Issue Allocation Deviation %",
             "Per offering x receiving portfolio or account: New Issue Allocated Quantity / (Sum of New Issue Allocated Quantity for "
             "the offering x Indicated Quantity / Sum of Indicated Quantity) - 1, using the latest indication before the Pricing "
             "Date; flagged above the policy tolerance when Fairness Review Status is not approved.",
             [("25", "New Issue Allocation", "Allocation Offering"), ("25", "New Issue Allocation", "Receiving Portfolio"),
              ("25", "New Issue Allocation", "Receiving Account"), ("25", "New Issue Allocation", "New Issue Allocated Quantity"),
              ("25", "New Issue Allocation", "Fairness Review Status"), ("25", "New Issue Indication", "Indication Offering"),
              ("25", "New Issue Indication", "Indicating Portfolio"), ("25", "New Issue Indication", "Indicating Account"),
              ("25", "New Issue Indication", "Indicated Quantity"), ("25", "New Issue Indication", "Indication Timestamp"),
              ("25", "New Issue Offering", "Pricing Date")]),
            ("New Issue Allocations Without Indication",
             "New Issue Allocations whose receiving portfolio or account has no New Issue Indication for the offering with Indication "
             "Timestamp before the Pricing Date.",
             [("25", "New Issue Indication", "Indication Timestamp"), ("25", "New Issue Offering", "Pricing Date"),
              "New Issue Allocation Deviation %"]),
            ("Equity New Issue Allocations to Ineligible Accounts",
             "Allocations of offerings with Equity New Issue Indicator = Y to a portfolio or account with no New Issue Eligibility "
             "Certification valid on the Pricing Date (Certification Date <= Pricing Date <= Certification Expiry Date), or whose "
             "certification shows Restricted Person Status = restricted with no Rule 5130 Exemption and Restricted Beneficial Interest "
             "Percentage above the de minimis 10%, or Rule 5131 Covered Person Indicator = Y.",
             [("25", "New Issue Offering", "Equity New Issue Indicator"), ("25", "New Issue Offering", "Pricing Date"),
              ("25", "New Issue Allocation", "Receiving Portfolio"), ("25", "New Issue Allocation", "Receiving Account"),
              ("25", "New Issue Allocation", "Supporting Eligibility Certification"),
              ("25", "New Issue Eligibility Certification", "Certified Portfolio"),
              ("25", "New Issue Eligibility Certification", "Certified Account"),
              ("25", "New Issue Eligibility Certification", "Certification Date"),
              ("25", "New Issue Eligibility Certification", "Certification Expiry Date"),
              ("25", "New Issue Eligibility Certification", "Restricted Person Status"),
              ("25", "New Issue Eligibility Certification", "Rule 5130 Exemption"),
              ("25", "New Issue Eligibility Certification", "Restricted Beneficial Interest Percentage"),
              ("25", "New Issue Eligibility Certification", "Rule 5131 Covered Person Indicator")]),
            ("Rule 10f-3 Purchases Failing Conditions",
             "Rule 10f-3 Purchases with Rule 10f-3 Conditions Met Indicator = N, Percentage of Offering Purchased above the 25% limit, "
             "or Purchased From equal to an affiliate (a party that is the Party Master Cross-Reference of an internal legal entity).",
             [("25", "Rule 10f-3 Purchase", "Rule 10f-3 Offering"), ("25", "Rule 10f-3 Purchase", "Purchasing Fund"),
              ("25", "Rule 10f-3 Purchase", "Rule 10f-3 Conditions Met Indicator"),
              ("25", "Rule 10f-3 Purchase", "Percentage of Offering Purchased"), ("25", "Rule 10f-3 Purchase", "Purchased From"),
              ("09", "Internal Legal Entity", "Party Master Cross-Reference"),
              ("25", "New Issue Offering", "Affiliate in Syndicate Indicator")]),
            ("Rule 10f-3 Purchases Not Board Reported",
             "Rule 10f-3 Purchases with no Board Report Date by the end of the quarter after the offering's Pricing Date.",
             [("25", "Rule 10f-3 Purchase", "Board Report Date"), ("25", "New Issue Offering", "Pricing Date")]),
            ("Cross Trade Exceptions",
             "Cross Trades where |Cross Price - Independent Current Market Price| / Independent Current Market Price > 0 beyond rounding, "
             "Cross Trade Approval Status is not approved, Commission Charged Indicator = Y, or either the Buying Trade Allocation or the "
             "Selling Trade Allocation is missing; the independent price is checked against the 22 Price Observation it cites.",
             [("25", "Cross Trade", "Cross Trade Reference"), ("25", "Cross Trade", "Cross Price"),
              ("25", "Cross Trade", "Independent Current Market Price"), ("25", "Cross Trade", "Independent Price Observation"),
              ("25", "Cross Trade", "Cross Trade Approval Status"), ("25", "Cross Trade", "Commission Charged Indicator"),
              ("25", "Cross Trade", "Buying Trade Allocation"), ("25", "Cross Trade", "Selling Trade Allocation"),
              ("22", "Price Observation", "Price Observation Key"), ("22", "Price Observation", "Observed Price Value")]),
            ("Pre-Allocation Adherence %",
             "Block memberships whose final allocated share (Sum of Allocated Quantity for the member order / Sum for the block) equals "
             "the pre-allocated share (Pre-Allocation Quantity / Sum of Pre-Allocation Quantity for the block) within one round lot / "
             "all memberships of executed blocks with Pre-Allocation Recorded Indicator = Y.",
             [("25", "Block Order Membership", "Member Block Order"), ("25", "Block Order Membership", "Member Trade Order"),
              ("25", "Block Order Membership", "Pre-Allocation Quantity"), ("25", "Block Order", "Pre-Allocation Recorded Indicator"),
              ("25", "Trade Allocation", "Allocated Trade Order"), ("25", "Trade Allocation", "Allocated Quantity")]),
            ("Blocks Without Pre-Allocation or With Late Additions",
             "Executed Block Orders with Pre-Allocation Recorded Indicator = N, and block memberships with Late Addition Indicator = Y, "
             "by trader and period.",
             [("25", "Block Order", "Pre-Allocation Recorded Indicator"), ("25", "Block Order", "Block Trader"),
              ("25", "Block Order Membership", "Late Addition Indicator")]),
            ("Reallocation Rate %",
             "Trade Allocations with Reallocation Indicator = Y / all Trade Allocations, by portfolio and period.",
             [("25", "Trade Allocation", "Reallocation Indicator"), ("25", "Trade Allocation", "Trade Allocation ID"),
              ("25", "Trade Allocation", "Allocation Trade Date")]),
            ("Trade Error Net Loss",
             "Sum of Error Gain or Loss Amount of Trade Errors with Error Discovery Date in the period where the amount is a loss, by "
             "Trade Error Type, Affected Portfolio and severity; Unreimbursed Loss = |loss| - Reimbursement Amount.",
             [("25", "Trade Error", "Error Gain or Loss Amount"), ("25", "Trade Error", "Reimbursement Amount"),
              ("25", "Trade Error", "Error Discovery Date"), ("25", "Trade Error", "Trade Error Type"),
              ("25", "Trade Error", "Affected Portfolio"), ("25", "Trade Error", "Trade Error Severity")]),
            ("Loss Errors Without Incident Reference",
             "Trade Errors with a loss and no Related Incident Reference (a loss is also a 37 Operational Loss Event, CD-244).",
             [("25", "Trade Error", "Related Incident Reference"), "Trade Error Net Loss"]),
        ],
        inputs=[
            ("25", "New Issue Offering", ["New Issue Offering Reference", "Offering Instrument", "Offering Setup Request",
                                          "New Issue Offering Types", "Lead Bookrunner", "Pricing Date", "Offer Price",
                                          "Equity New Issue Indicator", "Affiliate in Syndicate Indicator"]),
            ("25", "New Issue Indication", ["Indication Offering", "Indicating Portfolio", "Indicating Account", "Indicated Quantity",
                                            "Indication Timestamp"]),
            ("25", "New Issue Allocation", ["Allocation Offering", "Receiving Portfolio", "Receiving Account",
                                            "New Issue Allocated Quantity", "New Issue Allocation Method", "Fairness Review Status",
                                            "Booked Trade Allocation", "Supporting Eligibility Certification"]),
            ("25", "Rule 10f-3 Purchase", ["Rule 10f-3 Offering", "Purchasing Fund", "Purchase Trade Allocation", "Purchased From",
                                           "Percentage of Offering Purchased", "Rule 10f-3 Conditions Met Indicator", "Board Report Date"]),
            ("25", "New Issue Eligibility Certification", ["Certified Portfolio", "Certified Account", "Certification Date",
                                                           "Restricted Person Status", "Rule 5130 Exemption",
                                                           "Restricted Beneficial Interest Percentage",
                                                           "Rule 5131 Covered Person Indicator", "Certification Expiry Date"]),
            ("25", "Cross Trade", ["Cross Trade Reference", "Buying Portfolio", "Selling Portfolio", "Cross Instrument", "Cross Timestamp",
                                   "Cross Quantity", "Cross Price", "Independent Price Observation", "Independent Current Market Price",
                                   "Cross Trade Basis", "Cross Trade Approval Status", "Buying Trade Allocation",
                                   "Selling Trade Allocation", "Commission Charged Indicator"]),
            ("25", "Trade Error", ["Trade Error Reference", "Trade Error Type", "Affected Trade Order", "Affected Trade Allocation",
                                   "Affected Portfolio", "Error Discovery Date", "Error Gain or Loss Amount", "Reimbursement Amount",
                                   "Trade Error Severity", "Trade Error Status", "Related Incident Reference"]),
            ("25", "Trade Allocation", ["Trade Allocation ID", "Allocation Source", "Allocated Block Order", "Allocated Trade Order",
                                        "Allocated Portfolio", "Allocated Account", "Allocated Quantity", "Allocation Trade Date",
                                        "Allocation Status", "Reallocation Indicator"]),
            ("25", "Block Order", ["Block Order ID", "Block Instrument", "Block Trader", "Pre-Allocation Recorded Indicator"]),
            ("25", "Block Order Membership", ["Member Block Order", "Member Trade Order", "Pre-Allocation Quantity",
                                              "Late Addition Indicator"]),
            ("25", "Trade Order", ["Trade Order ID", "Order Portfolio", "Trading Legal Entity", "Originating Investment Decision"]),
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status"]),
            ("22", "Price Observation", ["Price Observation Key", "Observed Instrument", "Observed Price Type",
                                         "Observation As-Of Timestamp", "Observed Price Value"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Product", "Managed Account",
                                                     "Implementation Effective From", "Implementation Effective To"]),
            ("15", "Account", ["Account ID", "Account Type"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type"]),
            ("01", "Fund Legal Structure", ["Regulatory Regime"]),
            LE,
        ],
        upstream=["DP-123", "DP-115", "DP-143", "DP-097", "DP-140", "DP-093", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET on T+1; quarter-end board evidence locked by business day 15 after quarter-end",
        history="Every control record kept for at least 7 years (Rule 204-2, Rule 31a-1, and FINRA 5130 / 5131 record keeping); quarter-end snapshots locked with the board materials",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every New Issue Allocation with a Booked Trade Allocation has New Issue Allocated Quantity equal to that allocation's Allocated Quantity.",
            "Every Cross Trade's Buying Trade Allocation and Selling Trade Allocation exist in DP-123 with Allocation Source = internal cross and the same Cross Quantity.",
            "Independent Current Market Price on a Cross Trade equals the Observed Price Value of its Independent Price Observation.",
            "Every New Issue Indication, Allocation and Eligibility Certification names exactly one of a portfolio or an SMA account, and an account is a Managed Account of a DP-140 portfolio.",
            "Every Rule 10f-3 Purchase has a Purchase Trade Allocation that exists in DP-123 and an offering with Affiliate in Syndicate Indicator = Y.",
        ],
        notes=("CD-184: derivative trade reports are 26; fund filings are 35 (MiFIR transaction reports left 25, CW-925). Board reporting of Rule "
               "10f-3, Rule 17a-7 and trade errors is assembled by the 35 board reporting product from this one (CD-234). A trade error "
               "that causes a loss is also a 37 Operational Loss Event (CD-244); this product carries the incident reference only and "
               "does not restate the loss event. The allocation chain is read with DP-123 upstream (CD-314). The 22 Price Observation "
               "is read directly from 22 because DP-143 publishes approved prices, not the observations a cross cites. Affiliates are "
               "identified through the 09 Internal Legal Entity party cross-reference (DP-013). Taxonomy gap: there is no affiliated "
               "underwriter attribute on New Issue Offering beyond Affiliate in Syndicate Indicator, so the 'not purchased from the "
               "affiliate' test relies on the internal legal entity party cross-reference and misses affiliates that are not internal "
               "legal entities. Taxonomy gap: Trade Error Related Incident Reference is text, not a reference to 37, so the incident "
               "link cannot be validated. Taxonomy gap: there is no fairness tolerance or allocation policy object, so the deviation "
               "threshold is a parameter. Open SME questions: 25 SME questions 6 (cross trades permitted, for which "
               "vehicles, approved by whom) and 7 (is any affiliate ever in a syndicate?). The Rule 10f-3 25% limit applies to most "
               "security categories and is to be confirmed per category. Code values assumed: Restricted Person Status 'restricted', "
               "Allocation Source 'internal cross'. PII = Y (SMA accounts, restricted "
               "person status, beneficial interest). Rests on CD-184, CD-234, CD-244, CD-311, CD-314, CD-315. "
               "W1: EU or UK Trading Venue Indicator (17 Regulatory Instrument Classification) dropped, no successor in the "
               "wealth 17 (CW-917); Unreported MiFIR Transactions now tests every final allocation of an in-scope entity, and "
               "the MiFIR measures and the 25 MiFIR Transaction Report object retire with MiFIR reporting when 25 is re-cut "
               "for the US-only firm (CW-022). "
               "W1b re-point (CW-925): MiFIR Transaction Report dropped, no successor (CW-925); the measures Unreported MiFIR "
               "Transactions, Rejected MiFIR Reports Open and MiFIR Decision Maker Mismatches retire with it, as do the MiFIR "
               "business question, grain fact, DQ rule, timeliness and the 25 SME question 4. 24 Investment Decision (read only "
               "by the decision-maker measure) and DP-126 upstream are dropped with it; the 'Reporting legal entity' dimension "
               "reads the Trading Legal Entity of the order. The product keeps its US purpose (FINRA 5130 / 5131, Rule 10f-3, "
               "Rule 17a-7, pre-allocation and trade errors), so it is not a re-scope candidate."),
    ),
}
