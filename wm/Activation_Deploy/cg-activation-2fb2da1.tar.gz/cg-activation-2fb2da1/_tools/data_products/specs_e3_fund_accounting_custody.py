"""Data product specifications: Wave E3 consumer-aligned Fund Accounting & Valuation (27) and Custody & Asset Servicing (28)
products, DP-168 to DP-176. Brief: 00_Program/Expansion/Product_Briefs/Fund_Operations.md. See CONTRACT.md.

WP1 lineage pass: the specs of the retired DP-175 are deleted (framework.RETIRED_PRODUCTS; register rows kept).
"""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-168": dict(
        definition=("The daily evidence that each NAV was checked, approved, released and delivered on time: NAV control checks "
                    "by type, run and result, the comparison of the official NAV with the firm shadow NAV, NAV versions and "
                    "re-strikes, the reliance on the transfer agent's capital stock proof, and the per-channel transmission of "
                    "each release to Profile, Nasdaq, platforms and insurers. It adds control facts only: the NAV of record and "
                    "every NAV value are taken from DP-165 (CD-330), and the Firm Shadow rows DP-165 publishes only to this "
                    "product are used here as control data, never as a NAV. Fund accounting uses it to release NAVs within "
                    "tolerance and deadline, and fund oversight uses it to evidence NAV oversight to the board."),
        business_questions=[
            "Which of today's NAVs have an open or failed control check, and which were released with one?",
            "For funds kept by an administrator, where does the official NAV differ from our shadow NAV by more than tolerance, and for how many days in a row?",
            "Did every NAV rely on a passed capital stock proof from the transfer agent for the same business date?",
            "Which releases reached each channel late or not at all, and were corrected NAVs re-sent to every channel that received the original?",
            "How often were NAVs re-struck or restated this quarter, by fund and administrator?",
        ],
        grain="Fund NAV calculation (fund accounting book x valuation date x NAV calculation source x NAV version) x share class, with NAV control check (NAV x check type x check run sequence) and NAV release x transmission channel x attempt as companion facts",
        dimensions=["Fund (investment product) and share class", "Fund accounting book", "Valuation date",
                    "NAV calculation source (official / firm shadow)", "NAV version and version type",
                    "Fund accounting operating model and administrator of record", "NAV control check type",
                    "Oversight check indicator", "Transmission channel", "Check result"],
        measures=[
            ("Shadow NAV Variance", "For each share class and valuation date with both a NAV of record (from DP-165) and a Fund NAV Calculation with NAV Calculation Source = Firm Shadow: (NAV per Share of the NAV of record - NAV per Share of the latest shadow version) / NAV per Share of the shadow version.",
             [("27", "Share Class NAV", "NAV per Share"), ("27", "Share Class NAV", "NAV Share Class"),
              ("27", "Share Class NAV", "Parent NAV Calculation"), ("27", "Fund NAV Calculation", "NAV Calculation Source"),
              ("27", "Fund NAV Calculation", "NAV Book"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "NAV Version Number"), ("27", "Fund NAV Calculation", "NAV Approval Status")]),
            ("Shadow NAV Tolerance Breaches", "Count of share class valuation dates where the absolute Shadow NAV Variance exceeds the Check Tolerance of the NAV Control Check of type Shadow NAV Comparison on the same NAV, and the count of consecutive valuation dates in breach per share class.",
             [("27", "NAV Control Check", "NAV Control Check Type"), ("27", "NAV Control Check", "Check Tolerance"),
              ("27", "NAV Control Check", "Checked Class NAV"), "Shadow NAV Variance"]),
            ("NAV Check Completion %", "NAVs of record whose latest Check Run Sequence of every required NAV Control Check Type has Check Result = Passed or Exception Cleared / all NAVs of record due on the valuation date, by book and operating model.",
             [("27", "NAV Control Check", "Checked Fund NAV"), ("27", "NAV Control Check", "Checked Class NAV"),
              ("27", "NAV Control Check", "NAV Control Check Type"), ("27", "NAV Control Check", "Check Run Sequence"),
              ("27", "NAV Control Check", "Check Result")]),
            ("Released With Failed Check", "Count of share class NAVs with a NAV Dissemination of NAV Release Status = Released whose NAV has a latest-run NAV Control Check with Check Result = Failed.",
             [("27", "NAV Dissemination", "Released NAV"), ("27", "NAV Dissemination", "NAV Release Status"),
              ("27", "NAV Control Check", "Check Result"), ("27", "NAV Control Check", "Check Run Sequence"),
              ("27", "NAV Control Check", "Checked Class NAV")]),
            ("Capital Stock Proof Reliance %", "NAVs of record whose every share class has a NAV Control Check whose Relied-On TA Control Check is a TA Control Check of TA Control Type = Capital Stock Proof for the same Control Share Class and Control Business Date = Valuation Date with Control Result = Passed (from DP-181) / all NAVs of record.",
             [("27", "NAV Control Check", "Relied-On TA Control Check"), ("29", "TA Control Check", "TA Control Check ID"),
              ("29", "TA Control Check", "TA Control Type"), ("29", "TA Control Check", "Control Share Class"),
              ("29", "TA Control Check", "Control Business Date"), ("29", "TA Control Check", "Control Result"),
              ("27", "Fund NAV Calculation", "Valuation Date")]),
            ("Oversight Check Coverage %", "NAVs of record on books whose Fund Book Operating Period effective on the Valuation Date has Fund Accounting Operating Model other than In House and that carry at least one NAV Control Check with Oversight Check Indicator = Y / all NAVs of record on those books.",
             [("27", "NAV Control Check", "Oversight Check Indicator"), ("27", "Fund Book Operating Period", "Operated Book"),
              ("27", "Fund Book Operating Period", "Fund Accounting Operating Model"),
              ("27", "Fund Book Operating Period", "Operating Period Effective From"),
              ("27", "Fund Book Operating Period", "Operating Period Effective To")]),
            ("Re-Strike Rate", "Fund NAV Calculations of the official source with NAV Version Type = Re-Strike or Restatement / NAVs of record, by book, administrator and month.",
             [("27", "Fund NAV Calculation", "NAV Version Type"), ("27", "Fund NAV Calculation", "NAV Calculation Source"),
              ("27", "Fund Book Operating Period", "Fund Administrator of Record")]),
            ("Channel Delivery On Time %", "Price & Rate Transmissions of first releases (Release Sequence = 1) with Transmission Status = Delivered or Acknowledged and Transmission Late Indicator = N / all first-release transmissions, by Transmission Channel and valuation date.",
             [("29", "Price & Rate Transmission", "Transmission Status"), ("29", "Price & Rate Transmission", "Transmission Late Indicator"),
              ("29", "Price & Rate Transmission", "Transmission Channel"), ("29", "Price & Rate Transmission", "Transmitted Dissemination"),
              ("27", "NAV Dissemination", "Release Sequence")]),
            ("Release-to-Delivery Lag", "Median and 95th percentile of Acknowledgment Timestamp (Transmission Timestamp where no acknowledgment is received) - Release Timestamp, in minutes, by Transmission Channel.",
             [("29", "Price & Rate Transmission", "Acknowledgment Timestamp"), ("29", "Price & Rate Transmission", "Transmission Timestamp"),
              ("29", "Price & Rate Transmission", "Transmission Channel"), ("27", "NAV Dissemination", "Release Timestamp")]),
            ("Undelivered Channel Releases", "Count of share class NAV releases x channel named in the fund's NAV Publication Channel with no Price & Rate Transmission of Transmission Status = Delivered or Acknowledged by the end of the valuation date.",
             [("01", "Valuation Terms", "NAV Publication Channel"), ("29", "Price & Rate Transmission", "Transmission Channel"),
              ("29", "Price & Rate Transmission", "Transmission Status"), ("27", "NAV Dissemination", "Released NAV")]),
            ("Corrected Release Re-Dissemination %", "Releases with Corrected Release Indicator = Y that were delivered to every Transmission Channel that received the Corrected Release / all corrected releases.",
             [("27", "NAV Dissemination", "Corrected Release Indicator"), ("27", "NAV Dissemination", "Corrected Release"),
              ("29", "Price & Rate Transmission", "Transmission Channel"), ("29", "Price & Rate Transmission", "Transmission Status")]),
        ],
        inputs=[
            ("27", "NAV Control Check", ["Checked Fund NAV", "Checked Class NAV", "NAV Control Check Type", "Check Run Sequence",
                                         "Check Tolerance", "Observed Variance", "Check Result", "Oversight Check Indicator",
                                         "Relied-On TA Control Check", "Check Performed By"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number", "NAV Version Type",
                                            "NAV Status", "Fund Net Assets Amount", "NAV Approval Status", "NAV Approved By"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share"]),
            ("27", "NAV Dissemination", ["Released NAV", "Release Sequence", "Release Timestamp", "NAV Release Status",
                                         "Corrected Release Indicator", "Corrected Release"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis", "Book Status"]),
            ("27", "Fund Book Operating Period", ["Operated Book", "Fund Accounting Operating Model", "Fund Administrator of Record",
                                                  "Operating Period Effective From", "Operating Period Effective To"]),
            ("29", "Price & Rate Transmission", ["Price Transmission Key", "Transmitted Dissemination", "Transmission Channel",
                                                 "Transmission Timestamp", "Transmission Status", "Acknowledgment Timestamp",
                                                 "Transmission Late Indicator"]),
            ("29", "TA Control Check", ["TA Control Check ID", "TA Control Type", "Control Share Class", "Control Business Date",
                                        "Control Result"]),
            ("01", "Valuation Terms", ["Valuation Frequency", "Valuation Point", "NAV Publication Channel"]),
        ],
        upstream=["DP-165", "DP-166", "DP-181", "DP-013", "DP-143", "DP-004", "DP-192", "DP-148"],   # price exception clearance from DP-148 Pricing Control (E2 to E4 merge)
        refresh="Intraday",
        timeliness="Control checks and the shadow comparison within 15 minutes of each NAV calculation version; release and channel status within 15 minutes of each transmission; the day's control record final by 9pm ET on the valuation date",
        history="Every check run, NAV version, release and transmission attempt kept for 10 years (Rule 31a-2 books and records), including superseded versions; daily snapshots of check status at release time",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every NAV Dissemination with NAV Release Status = Released refers to a Share Class NAV whose Parent NAV Calculation has NAV Approval Status = Approved and NAV Calculation Source other than Firm Shadow.",
            "For each NAV, the Check Performed By of every check differs from the NAV Approved By of the same Fund NAV Calculation (four-eyes).",
            "Every Relied-On TA Control Check resolves to a TA Control Check in DP-181 with the same share class and a Control Business Date equal to the Valuation Date.",
            "Every Price & Rate Transmission names a Transmitted Dissemination that exists in DP-165, and every Corrected Release points to an earlier Release Sequence of the same share class NAV.",
            "Every Fund Accounting Book has exactly one Fund Book Operating Period effective on each valuation date, so every NAV has one operating model and administrator.",
        ],
        notes=("W3 (CW-929): 29 Price & Rate Transmission.Transmission Channel values re-cut (Insurer Feed removed with the insurance-dedicated funds, Broker-Dealer Pricing Feed added); no measure filters on a value, so no input changed. "
               "Consumer-aligned control product of 27 for FN-33 (C-06.01, C-06.10 evidence). Certified numbers: none. NAV of record, "
               "NAV per Share and net assets are read from DP-165 (CD-330) and never recalculated; the NAV of record is DP-165's NAV of "
               "Record Flag. Firm Shadow rows are published by DP-165 only to this product, as control data. DP-165's NAV Release "
               "Timeliness stays the release-deadline measure; this product adds the channel delivery that follows release (CD-207: "
               "NAV Dissemination is the release, 29 Price & Rate Transmission the delivery). The capital stock proof is a 29 TA "
               "control relied on by reference and published by DP-181 (CD-196, CD-335); this product reads its result only. Price "
               "exception clearance is the NAV-level check type Price Exceptions Cleared; the price validation exceptions themselves "
               "stay in 22 and DP-143, and no price check is held here. "
               "Operating model (CD-297, CD-331): in house, the checks are fund accounting's own and the Firm Shadow comparison is "
               "absent or optional. If fund accounting is outsourced (Fund Book Operating Period names the administrator), the grain "
               "is unchanged: the administrator's NAV control report arrives as NAV Control Check rows, the firm's own oversight "
               "checks carry Oversight Check Indicator = Y, and Shadow NAV Variance and Shadow NAV Tolerance Breaches become the "
               "product's main measures. A mixed fund range is rows, not products. "
               "PII = Y: Check Performed By and NAV Approved By are employee references (DP-192), needed for the four-eyes rule; "
               "publish a board view without them. 01 Valuation Terms is read directly from 01 because DP-004 does not publish it. "
               "Taxonomy gap: NAV Control Check has no run timestamp, so whether a check passed before the Release Timestamp cannot "
               "be tested; Released With Failed Check uses the latest run. Taxonomy gap: no attribute lists the check types required "
               "per fund; NAV Check Completion % uses a required-check list held as a product parameter by the Head of Fund "
               "Accounting. Taxonomy gap: no attribute holds the per-channel delivery deadline; Transmission Late Indicator is taken "
               "as set by 29. Code values (Shadow NAV Comparison, Capital Stock Proof, Passed, Exception Cleared, Delivered, "
               "Acknowledged) are drafting assumptions to confirm against the 27 and 29 code lists. "
               "Open SME questions (27 Source_Notes): which funds are at an administrator and whether a shadow NAV is kept "
               "(question 1); which channels receive NAVs and whether corrected NAVs are re-disseminated (question 7); confirm the "
               "capital stock proof is run by the TA and only relied on (question 11). "
               "Rests on CD-196, CD-207, CD-297, CD-330, CD-331, CD-335."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-169": dict(
        definition=("Swing pricing and anti-dilution decisions per fund and valuation date tested against the effective swing "
                    "parameters, and every NAV error case with its affected share classes and dates, materiality test, fund loss, "
                    "reimbursing entity, correction methods, and the as-of orders and dilution that caused or corrected it. It "
                    "combines the 27 swing and NAV error records with the 29 fund orders and as-of details and the 13 servicing "
                    "error and shareholder remediation that follow, taking NAV per share and net assets from DP-165. Fund "
                    "accounting uses it for swing governance and NAV error materiality decisions, and for regulator and board "
                    "notification; it feeds shareholder remediation in 13."),
        business_questions=[
            "On which valuation dates did each fund swing, was the decision consistent with the threshold and factor in force, and did the swung NAV equal NAV times the factor?",
            "How accurate was the net capital activity estimate behind each swing decision, and on which days would the final order activity have changed the decision?",
            "Which NAV errors were opened this quarter, which exceeded the materiality threshold, how much did each cost the fund, and who reimbursed it?",
            "Has every shareholder affected by a material NAV error been compensated, and how much is still unpaid?",
            "Which as-of orders caused dilution above threshold without a NAV error case or servicing error?",
        ],
        grain="Swing pricing decision (fund x valuation date, SWG-); NAV error case (NEC-) x impacted share class x impacted valuation date; with as-of order detail (fund order) and servicing error / remediation as companion facts",
        dimensions=["Fund and share class", "Valuation date", "Swing parameter version", "Net activity direction",
                    "NAV error type and cause", "Materiality basis", "Reimbursing entity or third party",
                    "Correction method", "NAV error case status", "As-of reason", "Dilution cost bearer", "Case owner"],
        measures=[
            ("Net Activity Ratio", "Net Capital Activity Estimate / Fund Total Net Assets of the prior NAV of record (from DP-165), signed by Net Activity Direction.",
             [("27", "Swing Pricing Decision", "Net Capital Activity Estimate"), ("27", "Swing Pricing Decision", "Net Activity Direction"),
              ("27", "Swing Pricing Decision", "Decision Fund"), ("27", "Swing Pricing Decision", "Decision Valuation Date"),
              ("27", "Fund NAV Calculation", "Fund Net Assets Amount"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund Accounting Book", "Book Fund")]),
            ("Swing Decision Exceptions", "Count of Swing Pricing Decisions where (absolute Net Activity Ratio > Swing Threshold of the Applied Swing Parameter) differs from Threshold Breached Indicator, or the Applied Swing Parameter was not effective on the Decision Valuation Date.",
             [("27", "Swing Pricing Decision", "Threshold Breached Indicator"), ("27", "Swing Pricing Decision", "Applied Swing Parameter"),
              ("27", "Swing Pricing Parameter", "Swing Threshold"), ("27", "Swing Pricing Parameter", "Parameter Effective From"),
              ("27", "Swing Pricing Parameter", "Parameter Effective To"), "Net Activity Ratio"]),
            ("Swing Factor Exceptions", "Count of decisions with Threshold Breached Indicator = Y whose Swing Factor Applied differs from the Inflow Swing Factor (net inflow) or Outflow Swing Factor (net outflow) of the Applied Swing Parameter, or exceeds the share class's Maximum Swing Factor.",
             [("27", "Swing Pricing Decision", "Swing Factor Applied"), ("27", "Swing Pricing Decision", "Net Activity Direction"),
              ("27", "Swing Pricing Decision", "Threshold Breached Indicator"), ("27", "Swing Pricing Parameter", "Inflow Swing Factor"),
              ("27", "Swing Pricing Parameter", "Outflow Swing Factor"), ("01", "Investor Transaction Charge", "Maximum Swing Factor")]),
            ("Swung NAV Tie-Out", "Swung NAV per Share - NAV per Share x (1 + Swing Factor Applied) for net inflow or (1 - Swing Factor Applied) for net outflow, per share class NAV of record whose Applied Swing Decision is the decision; flagged beyond one unit of NAV rounding.",
             [("27", "Share Class NAV", "Swung NAV per Share"), ("27", "Share Class NAV", "NAV per Share"),
              ("27", "Share Class NAV", "Applied Swing Decision"), ("27", "Swing Pricing Decision", "Swing Factor Applied"),
              ("27", "Swing Pricing Decision", "Net Activity Direction")]),
            ("Swing Frequency", "Swing Pricing Decisions with Threshold Breached Indicator = Y / valuation dates, by fund and quarter, and the average Swing Factor Applied on swing days.",
             [("27", "Swing Pricing Decision", "Threshold Breached Indicator"), ("27", "Swing Pricing Decision", "Swing Factor Applied"),
              ("27", "Swing Pricing Decision", "Swing Pricing Decision ID")]),
            ("Swing Estimate Variance", "(Net Capital Activity Estimate - final net order value) / prior Fund Total Net Assets, where final net order value is the sum of Estimated Order Value of Fund Orders of the fund's share classes with Trade Date Assigned = Decision Valuation Date and Fund Order Status not cancelled, purchases positive and redemptions negative (read from DP-177; never counted as flows); and Mis-Swing Days, the count of decisions whose threshold result or direction would differ on the final value.",
             [("29", "Fund Order", "Estimated Order Value"), ("29", "Fund Order", "Order Share Class"),
              ("29", "Fund Order", "Trade Date Assigned"), ("29", "Fund Order", "Fund Order Type"), ("29", "Fund Order", "Fund Order Status"),
              ("27", "Swing Pricing Decision", "Net Capital Activity Estimate"), ("27", "Swing Pricing Parameter", "Swing Threshold"),
              "Net Activity Ratio"]),
            ("NAV Error Cases", "Count of NAV Error Cases by Error Discovery Date period, NAV Error Type, NAV Error Cause and Material Error Indicator; open cases by NAV Error Case Status.",
             [("27", "NAV Error Case", "NAV Error Case ID"), ("27", "NAV Error Case", "Error Discovery Date"),
              ("27", "NAV Error Case", "NAV Error Type"), ("27", "NAV Error Case", "NAV Error Cause"),
              ("27", "NAV Error Case", "Material Error Indicator"), ("27", "NAV Error Case", "NAV Error Case Status")]),
            ("Materiality Consistency Exceptions", "Count of NAV Error Cases where Material Error Indicator = N but any NAV Error Impact has absolute NAV Error Percentage >= Materiality Threshold, or Threshold Exceeded Indicator disagrees with that test for the impact row.",
             [("27", "NAV Error Case", "Material Error Indicator"), ("27", "NAV Error Case", "Materiality Threshold"),
              ("27", "NAV Error Case", "Materiality Basis"), ("27", "NAV Error Impact", "NAV Error Percentage"),
              ("27", "NAV Error Impact", "Threshold Exceeded Indicator"), ("27", "NAV Error Impact", "Impact Case")]),
            ("NAV Error Impact Tie-Out", "Published NAV - Corrected NAV - NAV Difference per Share per impact row, and NAV Difference per Share / Corrected NAV - NAV Error Percentage; flagged beyond rounding.",
             [("27", "NAV Error Impact", "Published NAV"), ("27", "NAV Error Impact", "Corrected NAV"),
              ("27", "NAV Error Impact", "NAV Difference per Share"), ("27", "NAV Error Impact", "NAV Error Percentage"),
              ("27", "NAV Error Impact", "Impacted Share Class"), ("27", "NAV Error Impact", "Impacted Valuation Date")]),
            ("Fund Loss and Reimbursement", "Sum of Fund Loss Amount of NAV Error Cases by Reimbursing Entity (internal) or Reimbursing Third Party, and by period of Error Discovery Date.",
             [("27", "NAV Error Case", "Fund Loss Amount"), ("27", "NAV Error Case", "Reimbursing Entity"),
              ("27", "NAV Error Case", "Reimbursing Third Party")]),
            ("Error Detection Lag", "Error Discovery Date - First Affected Valuation Date in business days, and Last Affected Valuation Date - First Affected Valuation Date + 1, per case.",
             [("27", "NAV Error Case", "Error Discovery Date"), ("27", "NAV Error Case", "First Affected Valuation Date"),
              ("27", "NAV Error Case", "Last Affected Valuation Date")]),
            ("Shareholder Remediation Outstanding", "Per material NAV Error Case: sum of Estimated Shareholder Impact Amount over its impacts - sum of Compensation Amount of Shareholder Remediations with a Compensation Paid Date under the 13 Servicing Errors whose Related NAV Error Case is the case (from DP-409).",
             [("27", "NAV Error Impact", "Estimated Shareholder Impact Amount"), ("13", "Servicing Error", "Related NAV Error Case"),
              ("13", "Servicing Error", "Servicing Error ID"), ("13", "Shareholder Remediation", "Compensation Amount"),
              ("13", "Shareholder Remediation", "Compensation Paid Date"), ("27", "NAV Error Case", "Material Error Indicator")]),
            ("Unlinked As-Of Dilution", "Count and sum of Dilution Amount of as-of orders with Dilution Threshold Exceeded Indicator = Y and neither a Related NAV Error Case nor a Related Servicing Error; total Dilution Amount by Dilution Cost Bearer.",
             [("29", "As-Of Order Detail", "Dilution Amount"), ("29", "As-Of Order Detail", "Dilution Threshold Exceeded Indicator"),
              ("29", "As-Of Order Detail", "Related NAV Error Case"), ("29", "As-Of Order Detail", "Related Servicing Error"),
              ("29", "As-Of Order Detail", "Dilution Cost Bearer")]),
        ],
        inputs=[
            ("27", "Swing Pricing Parameter", ["Parameter Fund", "Swing Factor Method", "Swing Threshold", "Inflow Swing Factor",
                                               "Outflow Swing Factor", "Parameter Effective From", "Parameter Effective To"]),
            ("27", "Swing Pricing Decision", ["Swing Pricing Decision ID", "Decision Fund", "Decision Valuation Date", "Applied Swing Parameter",
                                              "Net Capital Activity Estimate", "Net Activity Direction", "Threshold Breached Indicator",
                                              "Swing Factor Applied", "Decision Approved By"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "Fund Net Assets Amount"]),
            ("27", "Fund Accounting Book", ["Book Fund"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                                       "Swung NAV per Share", "Applied Swing Decision"]),
            ("27", "NAV Error Case", ["NAV Error Case ID", "Error Fund", "NAV Error Type", "NAV Error Cause", "Error Discovery Date",
                                      "First Affected Valuation Date", "Last Affected Valuation Date", "Materiality Basis",
                                      "Materiality Threshold", "Material Error Indicator", "Error Severity", "Fund Loss Amount",
                                      "Reimbursing Entity", "Reimbursing Third Party", "Correction Methods", "Regulators Notified",
                                      "NAV Error Case Status", "Case Owner"]),
            ("27", "NAV Error Impact", ["Impact Case", "Impacted Share Class", "Impacted Valuation Date", "Published NAV", "Corrected NAV",
                                        "NAV Difference per Share", "NAV Error Percentage", "Threshold Exceeded Indicator",
                                        "Estimated Shareholder Impact Amount"]),
            ("01", "Investor Transaction Charge", ["Anti-Dilution Mechanism", "Maximum Swing Factor"]),
            ("29", "Fund Order", ["Fund Order ID", "Fund Order Type", "Order Share Class", "Trade Date Assigned", "Fund Order Status",
                                  "Estimated Order Value"]),
            ("29", "As-Of Order Detail", ["Original Fund Order", "As-Of Trade Date", "As-Of Reason", "Related NAV Error Case",
                                          "Related Servicing Error", "Dilution Amount", "Dilution Threshold Exceeded Indicator",
                                          "Dilution Cost Bearer"]),
            ("13", "Servicing Error", ["Servicing Error ID", "Servicing Error Type", "Related NAV Error Case", "Accounts Impacted Count",
                                       "Total Financial Impact"]),
            ("13", "Shareholder Remediation", ["Remediation ID", "Remediation Type", "Compensation Amount", "Compensation Paid Date",
                                               "Cost Borne By"]),
        ],
        upstream=["DP-165", "DP-177", "DP-409", "DP-004", "DP-013", "DP-192"],
        refresh="Daily",
        timeliness="Swing decisions and their tests by 8pm ET on the valuation date; NAV error cases, impacts, as-of orders and remediation status by 7am ET on T+1",
        history="Every swing decision, parameter version and NAV error case with its impacts kept for 10 years (Rule 31a-2 and the Rule 22c-1(a)(3) swing pricing records); SCD type 2 on swing parameters and case status",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Swing Pricing Decision references an Applied Swing Parameter of the same fund effective on the Decision Valuation Date.",
            "Every Share Class NAV with a Swung NAV per Share different from its NAV per Share names an Applied Swing Decision with Threshold Breached Indicator = Y for the same fund and valuation date.",
            "Every NAV Error Case with Material Error Indicator = Y has at least one NAV Error Impact, a Correction Methods value and, when closed, a Fund Loss Amount (zero allowed) and a Reimbursing Entity or Reimbursing Third Party when the loss is above zero.",
            "Every NAV Error Impact's Impacted Valuation Date lies between the case's First and Last Affected Valuation Date, and its Impacted Share Class belongs to the Error Fund in DP-004.",
            "Every As-Of Order Detail with a Related NAV Error Case resolves to a NAV Error Case of the same fund, and every 13 Servicing Error naming a Related NAV Error Case resolves to an existing case.",
        ],
        notes=("W1b: Swing Pricing Parameter.Dilution Levy Rate and Swing Pricing Decision.Dilution Levy Amount dropped, no successor (CW-927); a US open-end fund uses swing pricing under Rule 22c-1(a)(3), not a dilution levy, and no measure read either attribute. The history text no longer cites CSSF Circular 24/856. "
               "Consumer-aligned control product of 27 for FN-33. Certified numbers: none; NAV per Share, Swung NAV per Share and "
               "Fund Total Net Assets of the NAV of record are read from DP-165 (CD-330). The net capital activity behind a swing "
               "is compared with 29 fund orders read through DP-177; orders are not flows and never feed DP-006 or DP-008 (CD-199). "
               "Shareholder remediation stays 13 (CD-189) and is read through DP-409 Servicing Errors & Client Remediation; 13 "
               "Servicing Error amounts that copy 27 (NAV Error Magnitude, Materiality Threshold Exceeded Indicator) are Derived "
               "copies, so the 27 case is the source and the 13 rows are read only for the remediation link. Fund losses that are "
               "operational losses are 37 Operational Loss Events (CD-244), referenced by the loss event's Impact Amount, never "
               "copied here. "
               "Operating model (CD-297, CD-331): in house, fund accounting calculates the swing and opens error cases. If fund "
               "accounting is outsourced, the administrator calculates the swing and proposes NAV error cases; the grain is "
               "unchanged, the administrator is named by DP-165's Fund Book Operating Period, and the firm's approval (Decision "
               "Approved By, case status) is the oversight fact. If the transfer agent supplies only batch totals (29 SME question "
               "2), Swing Estimate Variance falls back to interface session totals from DP-177 and is marked not available at "
               "order grain. "
               "PII = Y: Case Owner and Decision Approved By are employee references (DP-192) and 29 Estimated Order Value is "
               "flagged personal data at order level; only fund-level sums are published, and the board view carries no names. "
               "Taxonomy gap: Swing Pricing Parameter has no maximum swing factor of its own; the share class Maximum Swing Factor "
               "in 01 Investor Transaction Charge is used. Taxonomy gap: Swing Pricing Decision has no decision timestamp, so "
               "whether the decision preceded the NAV strike cannot be tested. Taxonomy gap: Shareholder Remediation has no direct "
               "reference to its Servicing Error in the catalog attributes (the link is in its grain); the join is taken as "
               "modeled in 13. "
               "Open SME questions (27 Source_Notes): NAV error materiality policy by regime and fund type (question 4); whether "
               "US funds swing at all and who sets thresholds and factors (question 5). "
               "Rests on CD-189, CD-199, CD-244, CD-297, CD-330, CD-331."
               "WP1 re-point (CW-220): retired DP-043 replaced by its successor DP-409 Servicing Errors & Client Remediation (WP1C_CLA candidate), which publishes the 13 Servicing Error and Shareholder Remediation objects Shareholder Remediation Outstanding reads; DP-405 (the other DP-043 successor, contact center) publishes nothing read here."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-170": dict(
        definition=("Each fund's expenses by type: the fiscal-year budget against the daily accrual, expense cap and waiver "
                    "accruals with recoupable balances and the adviser receivable or payable they create, and payments to each "
                    "payee with whether the adviser paid. It combines the 27 expense records with the 01 fee and cap terms, the "
                    "10 waiver record and the 19 adviser-side documents, and reads the certified expense ratios and class net "
                    "assets from DP-165 without recalculating them. The Fund Treasurer uses it to set and true up accrual rates, "
                    "manage caps and waivers before they expire, and approve fund payments."),
        business_questions=[
            "For each fund and expense type, how does the year-to-date accrual compare with budget, and what will the year-end variance be at today's accrual rate?",
            "Which share classes run a trailing net expense ratio above their contractual cap, and how much headroom does each have?",
            "How much has the adviser waived or reimbursed this year by class and waiver type, and how much is recoupable before it expires?",
            "Which cap and waiver agreements expire within the next two quarters and need board approval to renew?",
            "Which fund payments are pending, which were paid by the adviser, and which were paid from an account that is not an open fund cash account?",
        ],
        grain="Fund (or share class) x expense type x accrual date, with fund expense budget (fund x expense type x fiscal year), cap and waiver accrual (share class x waiver type x accrual date) and fund expense payment (fund x payee x payment) as companion facts",
        dimensions=["Fund and share class", "Expense type", "Fiscal year and accrual date", "Waiver type", "Payee",
                    "Paid by adviser indicator", "Payment status", "Paying safekeeping account", "Fund accounting operating model"],
        measures=[
            ("Accrued vs Budget YTD", "Sum of Accrued Expense Amount from the start of the fiscal year to the as-of date by fund and Accrual Expense Type - Budgeted Amount x elapsed days / days in the fiscal year (straight-line Budget Accrual Method; other methods use the budget's own phasing).",
             [("27", "Fund Expense Accrual", "Accrued Expense Amount"), ("27", "Fund Expense Accrual", "Accrual Fund"),
              ("27", "Fund Expense Accrual", "Accrual Expense Type"), ("27", "Fund Expense Accrual", "Expense Accrual Date"),
              ("27", "Fund Expense Budget", "Budgeted Amount"), ("27", "Fund Expense Budget", "Budget Fund"),
              ("27", "Fund Expense Budget", "Budget Expense Type"), ("27", "Fund Expense Budget", "Budget Fiscal Year End"),
              ("27", "Fund Expense Budget", "Budget Accrual Method")]),
            ("Projected Year-End Variance", "Year-to-date Accrued Expense Amount + latest daily Accrued Expense Amount x remaining days in the fiscal year - Budgeted Amount, by fund and expense type.",
             [("27", "Fund Expense Accrual", "Accrued Expense Amount"), ("27", "Fund Expense Budget", "Budgeted Amount"),
              ("27", "Fund Expense Budget", "Budget Fiscal Year End"), "Accrued vs Budget YTD"]),
            ("Accrual True-Up Exposure", "Accrued Expense Balance at the as-of date - sum of Payment Amount of Fund Expense Payments with Fund Payment Status = Approved or Pending for the same fund and expense type; positive is over-accrued, negative under-accrued.",
             [("27", "Fund Expense Accrual", "Accrued Expense Balance"), ("27", "Fund Expense Payment", "Payment Amount"),
              ("27", "Fund Expense Payment", "Fund Payment Status"), ("27", "Fund Expense Payment", "Paying Fund"),
              ("27", "Fund Expense Payment", "Payment Expense Type")]),
            ("Expense Cap Headroom", "Expense Cap Rate of the share class (01 Cost Disclosure, the contractual cap) - Net Expense Ratio (Trailing) from DP-165, in basis points; classes with negative headroom are flagged, and classes where Expense Cap Rate Applied on the latest waiver accrual differs from the 01 Expense Cap Rate are flagged separately.",
             [("01", "Cost Disclosure", "Expense Cap Rate"), ("01", "Cost Disclosure", "Cost Reference Date"),
              ("27", "Expense Cap & Waiver Accrual", "Expense Cap Rate Applied"), ("27", "Expense Cap & Waiver Accrual", "Waiver Share Class")]),
            ("Waivers and Reimbursements", "Sum of Waived Fee Amount and of Reimbursed Expense Amount by share class, Waiver Type and fiscal period, and as basis points of average Class Net Assets of the NAV of record over the same days (from DP-165).",
             [("27", "Expense Cap & Waiver Accrual", "Waived Fee Amount"), ("27", "Expense Cap & Waiver Accrual", "Reimbursed Expense Amount"),
              ("27", "Expense Cap & Waiver Accrual", "Waiver Type"), ("27", "Expense Cap & Waiver Accrual", "Waiver Accrual Date"),
              ("27", "Share Class NAV", "Class Net Assets Amount"), ("27", "Share Class NAV", "NAV Share Class")]),
            ("Recoupable Balance Expiring", "Recoupable Balance at the as-of date of share classes whose 10 Waiver Record has Recoupment Eligible Indicator = Y, bucketed by Recoupment Expiry Date (within 3, 12 and 36 months).",
             [("27", "Expense Cap & Waiver Accrual", "Recoupable Balance"), ("10", "Waiver Record", "Recoupment Eligible Indicator"),
              ("10", "Waiver Record", "Recoupment Expiry Date"), ("10", "Waiver Record", "Supported Share Class")]),
            ("Waiver Agreements Expiring", "Count of share classes whose Waiver Expiry Date (01 Cost Disclosure) falls within the next 180 days, with the trailing waived and reimbursed amount at stake.",
             [("01", "Cost Disclosure", "Waiver Expiry Date"), "Waivers and Reimbursements"]),
            ("Waiver Record Tie-Out", "For each share class, Waiver Type and accounting period: sum of 27 Waived Fee Amount (and Reimbursed Expense Amount) - the 10 Waiver Record Waived Fee Amount (and Reimbursed Expense Amount); flagged when not zero (CD-188).",
             [("27", "Expense Cap & Waiver Accrual", "Waived Fee Amount"), ("27", "Expense Cap & Waiver Accrual", "Reimbursed Expense Amount"),
              ("10", "Waiver Record", "Waived Fee Amount"), ("10", "Waiver Record", "Reimbursed Expense Amount"),
              ("10", "Waiver Record", "Waiver Type")]),
            ("Adviser Side Unbooked", "Count of share class months with Reimbursed Expense Amount > 0 and no Adviser Reimbursement Payable resolving to a 19 Payable Invoice with Payable Invoice Status not cancelled, plus months with recoupment and no Adviser Recoupment Receivable resolving to a 19 Receivable Item.",
             [("27", "Expense Cap & Waiver Accrual", "Adviser Reimbursement Payable"), ("27", "Expense Cap & Waiver Accrual", "Adviser Recoupment Receivable"),
              ("19", "Payable Invoice", "Payable Invoice ID"), ("19", "Payable Invoice", "Payable Invoice Status"),
              ("19", "Receivable Item", "Receivable Document Number"), ("19", "Receivable Item", "Receivable Status"),
              ("27", "Expense Cap & Waiver Accrual", "Reimbursed Expense Amount")]),
            ("Fund Payments by Status", "Sum and count of Payment Amount by Fund Payment Status, Payment Expense Type and Expense Payee, separating payments with Paid by Adviser Indicator = Y.",
             [("27", "Fund Expense Payment", "Payment Amount"), ("27", "Fund Expense Payment", "Fund Payment Status"),
              ("27", "Fund Expense Payment", "Payment Expense Type"), ("27", "Fund Expense Payment", "Expense Payee"),
              ("27", "Fund Expense Payment", "Paid by Adviser Indicator")]),
            ("Payments from Ineligible Accounts", "Count of Fund Expense Payments whose Paying Safekeeping Account is not a Safekeeping Account of type Cash Account or Bank Deposit Account with Safekeeping Account Status = Open on the Payment Date (from DP-167).",
             [("27", "Fund Expense Payment", "Paying Safekeeping Account"), ("27", "Fund Expense Payment", "Payment Date"),
              ("28", "Safekeeping Account", "Safekeeping Account Type"), ("28", "Safekeeping Account", "Safekeeping Account Status")]),
        ],
        inputs=[
            ("27", "Fund Expense Budget", ["Budget Fund", "Budget Expense Type", "Budget Fiscal Year End", "Budgeted Amount", "Budget Accrual Method"]),
            ("27", "Fund Expense Accrual", ["Accrual Fund", "Accrual Share Class", "Expense Accrual Date", "Accrual Expense Type",
                                            "Applied Fee Schedule", "Fee Rate Applied", "Accrual Basis Amount", "Accrued Expense Amount",
                                            "Accrued Expense Balance"]),
            ("27", "Expense Cap & Waiver Accrual", ["Waiver Share Class", "Waiver Accrual Date", "Waiver Type", "Expense Cap Rate Applied",
                                                    "Waived Fee Amount", "Reimbursed Expense Amount", "Recoupable Balance",
                                                    "Adviser Recoupment Receivable", "Adviser Reimbursement Payable"]),
            ("27", "Fund Expense Payment", ["Fund Payment Reference", "Paying Fund", "Expense Payee", "Payment Expense Type", "Payment Amount",
                                            "Payment Date", "Paying Safekeeping Account", "Fund Payment Status", "Paid by Adviser Indicator"]),
            ("27", "Share Class NAV", ["NAV Share Class", "Parent NAV Calculation", "Class Net Assets Amount"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product"]),
            ("01", "Management Fee", ["Management Fee Rate", "Maximum Management Fee Rate", "Fee Accrual Basis", "Fee Breakpoint Schedule"]),
            ("01", "Other Ongoing Fees", ["Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate", "Shareholder Servicing Fee Rate"]),
            ("01", "Cost Disclosure", ["Gross Expense Ratio", "Net Expense Ratio", "Expense Cap Rate", "Waiver Expiry Date", "Cost Reference Date"]),
            ("10", "Waiver Record", ["Waiver Record ID", "Waiver Type", "Supported Share Class", "Expense Cap Terms Reference", "Waived Fee Amount",
                                     "Reimbursed Expense Amount", "Waiver Accounting Treatment", "Recoupment Eligible Indicator",
                                     "Recoupment Expiry Date"]),
            ("19", "Payable Invoice", ["Payable Invoice ID", "Invoice Gross Amount", "Payable Invoice Status"]),
            ("19", "Receivable Item", ["Receivable Document Number", "Debtor Fund Product", "Open Receivable Amount", "Receivable Status"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Safekeeping Account Type", "Safekeeping Account Status"]),
        ],
        upstream=["DP-165", "DP-166", "DP-167", "DP-004", "DP-013", "DP-210", "DP-191"],
        refresh="Daily",
        timeliness="Accruals, waivers and payments for the valuation date by 7am ET on T+1; budgets when approved for the fiscal year; month-end tie-outs to the 10 Waiver Record by business day 5",
        history="Daily accruals and waivers kept for 10 years (Rule 31a-2); budgets and payment records kept for 10 years; SCD type 2 on cap and fee terms as read from 01",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Fund Expense Accrual and Expense Cap & Waiver Accrual row names a share class or fund that resolves in DP-004, and every class-level accrual's Accrual Fund is the share class's Parent Product.",
            "For every share class and month, the 27 Waived Fee Amount summed over Waiver Accrual Dates equals the 10 Waiver Record Waived Fee Amount for the same Waiver Type (CD-188).",
            "Recoupable Balance never increases on a day with no Waived Fee Amount or Reimbursed Expense Amount and never exceeds the cumulative waived and reimbursed amount within the recoupment window.",
            "Every Fund Expense Payment with Fund Payment Status = Paid has a Payment Date, an Expense Payee that resolves in DP-240 (and to an engagement in DP-210 where the payee is a supplier) and a Paying Safekeeping Account that resolves in DP-167, unless Paid by Adviser Indicator = Y.",
            "Every Fund Expense Budget has one row per fund, expense type and Budget Fiscal Year End, and every expense type accrued in the fiscal year has a budget row.",
        ],
        notes=("W2 re-point (CW-051): 27 Fund Expense Accrual.Applied Fee Schedule is typed Reference (Management Fee, 01), the fund fee terms (Fund Fee Schedule, FSCH-) that stay in 01, not the 47 client Fee Schedule (CLFEE-); the attribute keeps its name. 10 Waiver Record.Expense Cap Terms Reference keeps its name (definition re-cut at W4, CW-159). "
               "Consumer-aligned operational product of 27 for FN-33 (owner: Fund Treasurer). Certified numbers: none. Net and Gross "
               "Expense Ratio (Trailing) and Audited ratios are DP-165's (CD-330) and are read, never recalculated; Expense Cap "
               "Headroom compares DP-165's ratio with the 01 cap. Class Net Assets is read from DP-165's NAV of record. "
               "Boundaries: the 10 Waiver Record amounts are Derived copies of 27 (CD-188), so DP-059 (pricing and waiver strategy) "
               "and DP-012 (net revenue) keep reading 10; this product owns the fund-side accrual and payment view and the "
               "27-to-10 tie-out. Fees paid by the fund to intermediaries (12b-1, sub-transfer agency) appear here as expense types "
               "only; the arrangement and payment calculation stay in DP-034. The 01 prospectus ratios in Cost Disclosure are "
               "disclosures published by DP-004, not certified actuals; only Expense Cap Rate and Waiver Expiry Date are used as "
               "contractual terms. The adviser side of waivers is 19 (CD-186, CD-188): 19 Payable Invoice and Receivable Item are "
               "read only to confirm the adviser-side document exists; the postings they create are DP-191's, which is listed "
               "upstream instead of DP-190 because postings, not the chart, are needed (CD-361 item 1). DP-210 supplies the payee "
               "supplier record. "
               "Operating model (CD-297, CD-331): if fund accounting is outsourced, budgets and accrual rates are still set by the "
               "Fund Treasurer and the administrator delivers the accruals and pays invoices on instruction; the grain does not "
               "change and Fund Book Operating Period (DP-165) names the administrator. "
               "Taxonomy gap: Fund Expense Payment has no approval date or approver, so payment approval timeliness cannot be "
               "measured. Taxonomy gap: no attribute links a Fund Expense Payment to the accrual it settles, so Accrual True-Up "
               "Exposure is computed at fund x expense type, not per invoice. Code values (Management Fee, Paid, Pending, Cash "
               "Account, Bank Deposit Account) are drafting assumptions to confirm. "
               "Open SME questions (27 Source_Notes): whether fund expense payments are made by fund accounting or by the "
               "adviser's AP with reimbursement (question 9; 19 question 13); whether financial highlights feed 01 Cost "
               "Disclosure (question 10); Payable Invoice as the right 19 object for non-invoice adviser payables (27 §2). "
               "Rests on CD-186, CD-188, CD-297, CD-330, CD-331, CD-361."
               "WP1 re-point (CW-260): measure 'Fee Rate Exceptions' dropped: accrual-to-terms testing moved to DP-586 Fund Fee Accrual Assurance (specs_w1c_fop_corp.py, 'Fee Rate Applied Differs From Terms'), which lists this product upstream; the SM-11 metric on it is removed. Its inputs stay, read by the other measures."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-171": dict(
        definition=("Distribution declarations by share class and ex-date with rates, reinvest NAV and estimated and final tax "
                    "character, together with each fund's distributable income estimates, tax year record, book-tax differences, "
                    "excise distribution requirement, RIC diversification and income test results and the 35 RIC qualification "
                    "determination that concludes them. Shares outstanding and NAV per share at the record and reinvest dates "
                    "come from DP-165. The Fund Treasurer and fund tax use it to set distribution rates that avoid excise tax and "
                    "protect RIC status, and the board's audit committee reviews the determination. It is the source DP-091 reads "
                    "for the final distribution character (CD-336)."),
        business_questions=[
            "How much undistributed net investment income and capital gain does each fund have per share against its excise requirement, and what rate avoids excise tax?",
            "Did any RIC diversification or gross income test fail or come within one point of its threshold, and is the cure done before its deadline?",
            "Does each declaration's estimated and final character add up to the declared rate, and which classes moved most from estimated to final?",
            "Which distributions needed a Section 19 notice, and did each one get flagged?",
            "Is every fund with a RIC tax regime covered by an approved qualification determination for the tax year, reviewed by the audit committee?",
        ],
        grain="Distribution declaration (share class x distribution type x ex-date, FDIV-) x tax character x character data basis; with distributable income estimate (fund x requirement period x estimate date), fund tax year record (fund x tax year x jurisdiction), book-tax difference, RIC test result (fund x test type x test date) and RIC qualification determination (fund x tax year) as companion facts",
        dimensions=["Fund and share class", "Distribution type", "Ex-date, record date and payable date", "Tax character and data basis",
                    "Distribution requirement period", "Tax year and jurisdiction", "Fund tax regime", "Book-tax difference type",
                    "Instrument", "RIC test type", "RIC qualification status"],
        measures=[
            ("Distribution Amount", "Distribution Rate per Share x Shares Outstanding of the NAV of record of the Declaring Share Class on the Record Date (from DP-165), per declaration.",
             [("27", "Distribution Declaration", "Distribution Rate per Share"), ("27", "Distribution Declaration", "Declaring Share Class"),
              ("27", "Distribution Declaration", "Record Date"), ("27", "Share Class NAV", "Shares Outstanding"),
              ("27", "Share Class NAV", "NAV Share Class"), ("27", "Share Class NAV", "Parent NAV Calculation"),
              ("27", "Fund NAV Calculation", "Valuation Date")]),
            ("Reinvest NAV Exceptions", "Count of declarations whose Reinvest NAV differs from the NAV per Share of the class's NAV of record on the Ex-Date (from DP-165).",
             [("27", "Distribution Declaration", "Reinvest NAV"), ("27", "Distribution Declaration", "Ex-Date"),
              ("27", "Share Class NAV", "NAV per Share")]),
            ("Character Tie-Out", "Per declaration and Character Data Basis: sum of Character Rate per Share over Distribution Character Types - Distribution Rate per Share; flagged when not zero.",
             [("27", "Distribution Character", "Character Rate per Share"), ("27", "Distribution Character", "Distribution Character Type"),
              ("27", "Distribution Character", "Character Data Basis"), ("27", "Distribution Declaration", "Distribution Rate per Share")]),
            ("Estimated-to-Final Character Shift", "Per declaration and Distribution Character Type: final Character Rate per Share - estimated Character Rate per Share, and the amount shifted (x Shares Outstanding at Record Date), with return of capital shown separately.",
             [("27", "Distribution Character", "Character Rate per Share"), ("27", "Distribution Character", "Character Data Basis"),
              ("27", "Distribution Character", "Distribution Character Type"), "Distribution Amount"]),
            ("Section 19 Notice Gaps", "Count of declarations with an estimated Distribution Character Type other than net investment income (for example return of capital or capital gain) and Section 19 Notice Required Indicator not Y.",
             [("27", "Distribution Declaration", "Section 19 Notice Required Indicator"), ("27", "Distribution Character", "Distribution Character Type"),
              ("27", "Distribution Character", "Character Data Basis")]),
            ("Excise Distribution Shortfall", "Required Excise Distribution of the fund's Fund Tax Year Record for the excise year - sum of Distribution Amount of the fund's declarations with Excise Distribution Indicator = Y or Declaration Date within the excise calendar year (capital gains on the October year), floored at zero; with the recorded Excise Tax Amount beside it.",
             [("27", "Fund Tax Year Record", "Required Excise Distribution"), ("27", "Fund Tax Year Record", "Excise Tax Amount"),
              ("27", "Fund Tax Year Record", "Tax Year Fund"), ("27", "Fund Tax Year Record", "Tax Year End Date"),
              ("27", "Distribution Declaration", "Excise Distribution Indicator"), ("27", "Distribution Declaration", "Declaration Date"),
              "Distribution Amount"]),
            ("Undistributed Income per Share", "(Undistributed Net Investment Income + Undistributed Short-Term Capital Gain + Undistributed Long-Term Capital Gain) of the latest Distributable Income Estimate for the requirement period / sum of Shares Outstanding of the fund's classes on the Estimate Date (from DP-165), shown by component.",
             [("27", "Distributable Income Estimate", "Undistributed Net Investment Income"),
              ("27", "Distributable Income Estimate", "Undistributed Short-Term Capital Gain"),
              ("27", "Distributable Income Estimate", "Undistributed Long-Term Capital Gain"),
              ("27", "Distributable Income Estimate", "Estimate Date"), ("27", "Distributable Income Estimate", "Distribution Requirement Period"),
              ("27", "Distributable Income Estimate", "Estimate Fund"), ("27", "Share Class NAV", "Shares Outstanding")]),
            ("RIC Test Failures and Headroom", "Count of RIC Test Results with Test Passed Indicator = N, open past Cure Deadline Date; and headroom = Measured Ratio - Required Threshold (Required Threshold - Measured Ratio for ceiling tests), flagged under one percentage point.",
             [("27", "RIC Test Result", "Test Passed Indicator"), ("27", "RIC Test Result", "Cure Deadline Date"),
              ("27", "RIC Test Result", "Measured Ratio"), ("27", "RIC Test Result", "Required Threshold"),
              ("27", "RIC Test Result", "RIC Test Type"), ("27", "RIC Test Result", "RIC Test Date")]),
            ("RIC Determination Coverage %", "Funds with a Fund Tax Year Record of Fund Tax Regime = RIC that have a RIC Qualification Determination for the tax year with a Determination Date and an Audit Committee Review Meeting / all such funds, and the count with RIC Qualification Status other than Qualified.",
             [("35", "RIC Qualification Determination", "Determined Fund"), ("35", "RIC Qualification Determination", "Determination Tax Year"),
              ("35", "RIC Qualification Determination", "RIC Qualification Status"), ("35", "RIC Qualification Determination", "Determination Date"),
              ("35", "RIC Qualification Determination", "Audit Committee Review Meeting"), ("27", "Fund Tax Year Record", "Fund Tax Regime"),
              ("27", "Fund Tax Year Record", "Fund Tax Year Record ID")]),
            ("Book-Tax Differences", "Sum of Difference Amount by Book-Tax Difference Type and Permanent Difference Indicator per tax year, sum of Capital Reclassification Amount, and the instrument-specific part by Instrument Type (DP-097).",
             [("27", "Book-Tax Difference", "Difference Amount"), ("27", "Book-Tax Difference", "Book-Tax Difference Type"),
              ("27", "Book-Tax Difference", "Permanent Difference Indicator"), ("27", "Book-Tax Difference", "Capital Reclassification Amount"),
              ("27", "Book-Tax Difference", "Difference Tax Year"), ("27", "Book-Tax Difference", "Difference Instrument"),
              ("17", "Instrument", "Instrument Type")]),
            ("Capital Loss Carryforward", "Short-Term Capital Loss Carryforward + Long-Term Capital Loss Carryforward per fund and tax year, beside Net Capital Gain Amount.",
             [("27", "Fund Tax Year Record", "Short-Term Capital Loss Carryforward"), ("27", "Fund Tax Year Record", "Long-Term Capital Loss Carryforward"),
              ("27", "Fund Tax Year Record", "Net Capital Gain Amount")]),
        ],
        inputs=[
            ("27", "Distribution Declaration", ["Distribution Declaration ID", "Declaring Share Class", "Distribution Type", "Daily Dividend Indicator",
                                                "Spillback Indicator", "Declaration Date", "Record Date", "Ex-Date", "Payable Date",
                                                "Distribution Rate per Share",
                                                "Reinvest NAV", "Excise Distribution Indicator", "Section 19 Notice Required Indicator"]),
            ("27", "Distribution Character", ["Distribution Character Type", "Character Data Basis", "Character Rate per Share"]),
            ("27", "Distributable Income Estimate", ["Estimate Fund", "Distribution Requirement Period", "Requirement Period End Date",
                                                     "Estimate Date", "Undistributed Net Investment Income", "Undistributed Short-Term Capital Gain",
                                                     "Undistributed Long-Term Capital Gain"]),
            ("27", "Fund Tax Year Record", ["Fund Tax Year Record ID", "Tax Year Fund", "Tax Year End Date", "Tax Jurisdiction", "Fund Tax Regime",
                                            "Investment Company Taxable Income", "Net Capital Gain Amount", "Required Excise Distribution",
                                            "Excise Tax Amount", "Short-Term Capital Loss Carryforward", "Long-Term Capital Loss Carryforward",
                                            "Fund Tax Return Type"]),
            ("27", "Book-Tax Difference", ["Difference Tax Year", "Book-Tax Difference Type", "Difference Instrument", "Difference Amount",
                                           "Permanent Difference Indicator", "Capital Reclassification Amount"]),
            ("27", "RIC Test Result", ["Tested Fund", "RIC Test Type", "RIC Test Date", "Measured Ratio", "Required Threshold",
                                       "Test Passed Indicator", "Cure Deadline Date"]),
            ("35", "RIC Qualification Determination", ["Determined Fund", "Determination Tax Year", "RIC Qualification Status",
                                                       "Relied RIC Test Results",
                                                       "Cure Action Description", "Determination Date", "Audit Committee Review Meeting"]),
            ("27", "Share Class NAV", ["NAV Share Class", "Parent NAV Calculation", "NAV per Share", "Shares Outstanding"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product"]),
            ("01", "Investment Product", ["Product ID", "Fiscal Year End"]),
            ("01", "Income Distribution", ["Distribution Policy", "Distribution Frequency"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type"]),
        ],
        upstream=["DP-165", "DP-166", "DP-580", "DP-004", "DP-013", "DP-097"],
        refresh="Daily",
        timeliness="Declarations and estimated character by 7am ET on T+1 after the declaration date; distributable income estimates on each estimate date; RIC tests within 5 business days after each quarter-end test date; final character and tax year records when fund tax completes the year",
        history="All declarations, character versions (estimated and final), estimates, tax year records, tests and determinations kept for 10 years (Rule 31a-2; IRS record retention); superseded estimates kept",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "For every declaration and Character Data Basis, Character Rate per Share summed over character types equals Distribution Rate per Share.",
            "Every declaration has Ex-Date on or after Declaration Date, Record Date and Payable Date present, and a Declaring Share Class that is active in DP-004 on the Ex-Date.",
            "Every final Distribution Character row has an estimated row for the same declaration and character type, or the type is new and flagged as a reclassification.",
            "Every fund whose Fund Tax Regime is RIC has RIC Test Results for each quarter-end test date of the tax year, and its RIC Qualification Determination relies only on RIC Test Results of the same fund and tax year.",
            "Every RIC Test Result with Test Passed Indicator = N has a Cure Deadline Date, and a determination of Qualified is not recorded while such a test is uncured.",
        ],
        notes=("W1b: Distribution Declaration.Equalization per Share and Excess Reportable Income per Unit dropped, no successor (CW-927); they served UK reporting fund and equalization regimes, and no measure read them. "
               "Consumer-aligned control product of 27 for FN-33 (owner: Fund Treasurer); FN-39 and FN-36 use it for fund tax and the "
               "board. Certified numbers: none. Shares Outstanding and NAV per Share are read from DP-165's NAV of record (CD-330); "
               "Distribution Amount is a derived operational amount, not a flow, and reinvestment transactions stay 06 and DP-006. "
               "Distribution policy and frequency stay 01 and DP-004. 1099-DIV and the other US tax documents are 13 and DP-091, which CD-336 "
               "extends to read the final Distribution Character from this product. The 35 RIC Qualification Determination is read "
               "here, not in a 35 product, because it concludes the 27 tests (CD-191, CD-235). W5 (CW-165): Section 817(h) Result and "
               "Relied 817(h) Rule Results dropped with the insurance-dedicated fund scope; RIC qualification stays. "
               "Fund tax moves with a Tax domain if CD-149 creates one; the product keeps its ID. Book-tax differences that name an "
               "instrument use the Instrument dimension from DP-097. "
               "Operating model (CD-297, CD-331): in house, fund accounting and fund tax keep the records. If fund tax or fund "
               "accounting is outsourced, the provider's tax year, test and estimate files are the source and the firm's "
               "determination is the oversight fact; the grain is unchanged. "
               "PII = N: Determination Approver (an employee) is not published; the audit committee meeting reference carries the "
               "approval evidence. "
               "Taxonomy gap: Distribution Declaration has no total distribution amount or shares-at-record attribute, so "
               "Distribution Amount uses DP-165 Shares Outstanding on the Record Date, which may differ from the TA's record-date "
               "shares (27 SME question 3). Taxonomy gap: no attribute separates the ordinary-income and capital-gain parts of "
               "Required Excise Distribution, so the excise shortfall is computed on the total. Taxonomy gap: RIC Test Result has "
               "no ceiling or floor direction; headroom direction is set by RIC Test Type. Code values (RIC, Qualified, final, "
               "estimated, return of capital) are drafting assumptions. "
               "Open SME questions (27 Source_Notes): who performs fund tax and whether a Tax domain is wanted (question 6); "
               "whether shares outstanding is mastered by fund accounting or the TA register (question 3). "
               "Rests on CD-149, CD-191, CD-235, CD-297, CD-330, CD-331, CD-336."
               "WP1 re-point (CW-261): DP-580 Fund Share Register & Postings is added upstream: reinvestment postings on the 29 register are read from DP-580; posting completeness moved to DP-588 (specs_w1c_fop_corp.py), which reads this product's declarations. No measure or input changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-172": dict(
        definition=("Position and cash reconciliation of the investment book (18) and the fund book (27) against custodian "
                    "statements, and of the fund book against the investment book, with every break, its type, signed "
                    "difference, valuation, age, owner, root cause and resolution. It publishes the 28 Custody Reconciliation Run "
                    "and Break (CUREC-) and the 27 ABOR to IBOR Reconciliation together, so one product shows every position "
                    "reconciliation of a fund (CD-335); book quantities are read from DP-166 and DP-142, and safekeeping accounts "
                    "and custodians from DP-167. Asset servicing uses it to clear breaks before NAV and settlement deadlines, and "
                    "risk and audit use the break aging as control evidence."),
        business_questions=[
            "Which reconciliations for today's business date are not complete or not signed off, and which custodian statements are missing?",
            "How many breaks are open by custodian, fund, break type and severity, what are they worth, and how old are they?",
            "Which breaks have been open longer than five business days, and who owns them?",
            "What are the main root causes of breaks by custodian, and how many are settlement-related?",
            "Where does the fund book's quantity differ from the investment book's, and which differences have no explanation?",
        ],
        grain="Custody reconciliation break (custody reconciliation run x break number, CUREC-n-Bnn), with custody reconciliation run (scope x reconciliation type x business date), custodian statement and its lines, and ABOR to IBOR reconciliation (book x portfolio x instrument x reconciliation date) as companion facts",
        dimensions=["Custodian (account provider)", "Safekeeping account", "Portfolio", "Fund and fund accounting book", "Instrument and asset class",
                    "Custody reconciliation type", "Break type", "Break severity", "Break root cause", "Break status", "Break owner",
                    "Business date", "Age bucket (business days)"],
        measures=[
            ("Statement Receipt %", "Open safekeeping accounts of type Securities Account or Cash Account with a Custodian Statement of Complete Statement Indicator = Y for the business date / all such open accounts, by Account Provider and Custodian Statement Type.",
             [("28", "Custodian Statement", "Statement Safekeeping Account"), ("28", "Custodian Statement", "Statement Date"),
              ("28", "Custodian Statement", "Complete Statement Indicator"), ("28", "Custodian Statement", "Custodian Statement Type"),
              ("28", "Safekeeping Account", "Safekeeping Account ID"), ("28", "Safekeeping Account", "Safekeeping Account Type"),
              ("28", "Safekeeping Account", "Safekeeping Account Status"), ("28", "Safekeeping Account", "Account Provider")]),
            ("Reconciliation Completion %", "Expected reconciliation scopes (each open safekeeping account and each linked fund book and portfolio, by Custody Reconciliation Type) with a Custody Reconciliation Run of Reconciliation Status = Completed for the Reconciliation Business Date / all expected scopes; runs not signed off (no Signed Off By) counted separately.",
             [("28", "Custody Reconciliation Run", "Custody Reconciliation Run ID"), ("28", "Custody Reconciliation Run", "Custody Reconciliation Type"),
              ("28", "Custody Reconciliation Run", "Reconciled Portfolio"), ("28", "Custody Reconciliation Run", "Reconciled Safekeeping Account"),
              ("28", "Custody Reconciliation Run", "Reconciliation Business Date"), ("28", "Custody Reconciliation Run", "Reconciliation Status"),
              ("28", "Custody Reconciliation Run", "Signed Off By")]),
            ("Open Breaks", "Count of Custody Reconciliation Breaks with Break Case Status not Closed, by Custody Break Type, Break Severity, Account Provider of the run's safekeeping account and Custody Reconciliation Type.",
             [("28", "Custody Reconciliation Break", "Break ID"), ("28", "Custody Reconciliation Break", "Break Case Status"),
              ("28", "Custody Reconciliation Break", "Custody Break Type"), ("28", "Custody Reconciliation Break", "Break Severity"),
              ("28", "Custody Reconciliation Break", "Break Run"), ("28", "Safekeeping Account", "Account Provider")]),
            ("Break Value", "Per open break: absolute Amount Difference for cash breaks; absolute Quantity Difference x Approved Price Value of the Difference Valuation Price for position breaks (DP-143); summed by custodian, fund and break type in base currency.",
             [("28", "Custody Reconciliation Break", "Amount Difference"), ("28", "Custody Reconciliation Break", "Quantity Difference"),
              ("28", "Custody Reconciliation Break", "Difference Valuation Price"), ("22", "Approved Price", "Approved Price ID"),
              ("22", "Approved Price", "Approved Price Value"), "Open Breaks"]),
            ("Break Age", "Business days on the run's calendar (09 Calendar Date with Day Type = Business Day) from the Reconciliation Business Date of the break's run to the as-of date for open breaks, or to Break Resolution Date for closed ones; bucketed 0-1, 2-5, 6-10 and over 10.",
             [("28", "Custody Reconciliation Run", "Reconciliation Business Date"), ("28", "Custody Reconciliation Break", "Break Resolution Date"),
              ("28", "Custody Reconciliation Break", "Break Case Status"), ("09", "Calendar Date", "Calendar Date"),
              ("09", "Calendar Date", "Day Type")]),
            ("Aged Breaks Over Five Days", "Count and Break Value of open breaks with Break Age > 5 business days, by Break Owner and custodian; breaks with no Break Owner shown separately.",
             [("28", "Custody Reconciliation Break", "Break Owner"), "Break Age", "Break Value"]),
            ("Resolved Within Three Days %", "Breaks closed in the period with Break Age at Break Resolution Date <= 3 business days / all breaks closed in the period, by custodian.",
             [("28", "Custody Reconciliation Break", "Break Resolution Date"), "Break Age"]),
            ("Root Cause Mix", "Share of breaks raised in the period by Break Root Cause, and the share with a Related Settlement Instruction (settlement-related) or Related AP Order (ETF basket delivery).",
             [("28", "Custody Reconciliation Break", "Break Root Cause"), ("28", "Custody Reconciliation Break", "Related Settlement Instruction"),
              ("28", "Custody Reconciliation Break", "Related AP Order")]),
            ("Break Rate", "Breaks raised / Custodian Holding Statement Lines compared, per run, by custodian and asset class (DP-097).",
             [("28", "Custodian Holding Statement Line", "Holding Line Statement"), ("28", "Custodian Holding Statement Line", "Statement Line Instrument"),
              ("28", "Custody Reconciliation Run", "Compared Custodian Statement"), ("17", "Instrument", "Asset Class"), "Open Breaks"]),
            ("ABOR-IBOR Breaks", "Count of ABOR to IBOR Reconciliation rows with ABOR-IBOR Reconciliation Result other than Matched, and the quantity difference ABOR Attributed Quantity - IBOR Quantity per row, by book, portfolio and instrument.",
             [("27", "ABOR to IBOR Reconciliation", "ABOR-IBOR Reconciliation Result"), ("27", "ABOR to IBOR Reconciliation", "ABOR Attributed Quantity"),
              ("27", "ABOR to IBOR Reconciliation", "IBOR Quantity"), ("27", "ABOR to IBOR Reconciliation", "Reconciled Book"),
              ("27", "ABOR to IBOR Reconciliation", "Reconciled Portfolio"), ("27", "ABOR to IBOR Reconciliation", "Reconciled Instrument"),
              ("27", "ABOR to IBOR Reconciliation", "Reconciliation Date")]),
            ("Unexplained ABOR-IBOR Differences", "ABOR-IBOR Breaks with no Difference Explanation one business day after the Reconciliation Date.",
             [("27", "ABOR to IBOR Reconciliation", "Difference Explanation"), "ABOR-IBOR Breaks"]),
        ],
        inputs=[
            ("28", "Custodian Statement", ["Statement Safekeeping Account", "Custodian Statement Type", "Statement Date", "Statement Number",
                                           "Complete Statement Indicator", "Statement Message Type"]),
            ("28", "Custodian Holding Statement Line", ["Holding Line Statement", "Custodian Security Identifier", "Statement Line Instrument",
                                                        "Place of Safekeeping", "Custodian Balance Type", "Custodian Quantity", "Custodian Market Value"]),
            ("28", "Custodian Cash Statement Entry", ["Cash Entry Statement", "Custodian Entry Reference", "Entry Value Date", "Entry Amount",
                                                      "Bank Transaction Code"]),
            ("28", "Custody Reconciliation Run", ["Custody Reconciliation Run ID", "Custody Reconciliation Type", "Reconciled Portfolio",
                                                  "Reconciled Safekeeping Account", "Reconciliation Business Date", "Compared Custodian Statement",
                                                  "Reconciliation Status", "Signed Off By"]),
            ("28", "Custody Reconciliation Break", ["Break ID", "Break Run", "Custody Break Type", "Break Instrument", "Book Holding",
                                                    "Book Cash Balance", "ABOR Valuation Record", "Custodian Statement Line", "Quantity Difference",
                                                    "Amount Difference", "Difference Valuation Price", "Break Severity", "Break Owner",
                                                    "Break Root Cause", "Related Settlement Instruction", "Related AP Order", "Break Case Status",
                                                    "Break Resolution Date"]),
            ("27", "ABOR to IBOR Reconciliation", ["Reconciled Book", "Reconciled Portfolio", "Reconciled Instrument", "Reconciliation Date",
                                                   "Compared Holding", "ABOR Attributed Quantity", "IBOR Quantity",
                                                   "ABOR-IBOR Reconciliation Result", "Difference Explanation"]),
            ("27", "ABOR Valuation Record", ["Valuation Book", "Valued Instrument", "ABOR Valuation Date", "ABOR Quantity", "Base Market Value"]),
            ("27", "Fund Book Portfolio Link", ["Linked Book", "Accounted Portfolio", "Book Portfolio Role", "Portfolio Link Effective From",
                                                "Portfolio Link Effective To"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View", "Holding Quantity",
                                         "Settled Quantity"]),
            ("18", "Cash Balance", ["Cash Balance Portfolio", "Balance Currency", "Cash Safekeeping Account", "Balance Date", "Cash Balance Type",
                                    "Balance Amount Local"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Status", "IBOR Operating Model", "Middle Office Provider"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Account Provider", "Safekeeping Account Type", "Safekeeping Account Status"]),
            ("22", "Approved Price", ["Approved Price ID", "Price Date", "Approved Price Value"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
        ],
        upstream=["DP-167", "DP-166", "DP-013", "DP-097", "DP-142", "DP-140", "DP-143", "DP-192"],
        refresh="Daily",
        timeliness="Statements and runs for the business date by 9am ET (before the trading and NAV cut-offs); break status refreshed hourly until 7pm ET; ABOR-IBOR results by 10am ET on T+1",
        history="Every run, break and status change kept for 10 years (books and records, Rule 31a-2); daily snapshots of open breaks for aging trends",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Custody Reconciliation Run names a Reconciled Safekeeping Account that resolves to an open account in DP-167 on the Reconciliation Business Date, and its Compared Custodian Statement belongs to that account.",
            "Every Custody Reconciliation Break of a position type has a Break Instrument and a non-zero Quantity Difference, and every cash break has a non-zero Amount Difference.",
            "Every break with Break Case Status = Closed has a Break Resolution Date on or after its run's Reconciliation Business Date and a Break Root Cause.",
            "Every ABOR to IBOR Reconciliation row's Reconciled Portfolio is linked to the Reconciled Book by a Fund Book Portfolio Link effective on the Reconciliation Date (DP-166).",
            "No break holds a book quantity or custodian quantity of its own: the break references Book Holding, Book Cash Balance, ABOR Valuation Record or Custodian Statement Line, and its difference equals book minus custodian for that pair.",
        ],
        notes=("Consumer-aligned control product of 28 for FN-34. Certified numbers: none. Reconcile, do not remaster (CD-196, CD-335): "
               "breaks hold signed differences only; book quantities come from DP-166 (ABOR) and DP-142 (IBOR), custodian accounts "
               "and providers from DP-167, prices from DP-143, instruments from DP-097. Boundaries (CD-335): the 27 ABOR to IBOR "
               "Reconciliation is published here; the 29 capital stock and cash proofs stay DP-181; the 06 TA versus fund accounting "
               "AUM check stays DP-045; DP-241 Firm AUM & Client Assets Reconciliation compares certified "
               "totals and no longer reads this product (its IBOR to NAV difference cause was dropped at WP1). Settlement fails (26 SETL-) and AP orders (29 ECR-) are referenced by key only; "
               "DP-175 reads these runs for safekeeping account reconciliation coverage (the CASS external reconciliation types left with CW-928). "
               "Operating model (CD-297, CD-331): custody is outsourced, so custodian statements always come from the providers. "
               "In house the firm runs the reconciliation. If middle office (18 IBOR Operating Model, Middle Office Provider) or "
               "fund accounting (DP-165 Fund Book Operating Period) is also outsourced, the provider runs the reconciliation and the "
               "grain becomes the provider's break report at the same break grain, with Signed Off By as the firm's oversight "
               "sign-off; Reconciliation Completion % then measures the provider's delivery. "
               "PII = Y: Break Owner and Signed Off By are employee references (DP-192); SMA client safekeeping accounts are shown "
               "by account key only. "
               "Taxonomy gap: a break that persists across daily runs has no first-identified date or link to the prior run's break, "
               "so Break Age counts from the break's own run date; a persisting break re-raised daily appears young. Proposed to 28: "
               "a First Identified Date or Carried From Break attribute. Taxonomy gap: Custody Reconciliation Run has no completion "
               "timestamp, so completion before the NAV cut-off cannot be tested. Taxonomy gap: no attribute names the "
               "reconciliation calendar; Break Age uses the US business calendar from DP-013 unless the account's market calendar is "
               "configured. Code values (Completed, Closed, Matched, Business Day, Securities Account, Cash Account) are drafting "
               "assumptions. "
               "Open SME questions (28 Source_Notes): whether the firm or the sponsor custodian reconciles SMA accounts (question "
               "3); whether sub-custodian-level statements are received (question 11). "
               "Rests on CD-183, CD-194, CD-196, CD-297, CD-331, CD-335."
               "WP1 re-point (CW-206): DP-241 dropped DP-172 upstream and the 'IBOR to NAV Difference (Pooled Funds)' cause; the boundary sentence is re-pointed. No input or measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-173": dict(
        definition=("Per safekeeping account and portfolio: corporate action notifications received from custodians, "
                    "entitlements, elections against internal and market deadlines, payments received, the income collection "
                    "control against the 27 expected accrual, withholding tax relief documentation and reclaims, and class action "
                    "claims with recoveries. Event terms and options come from DP-099 (17, CD-195), accounts and custodians from "
                    "DP-167 and the expected income from DP-166. Asset servicing uses it to meet election deadlines, chase unpaid "
                    "income, and recover withholding tax and class action money for the funds and client accounts."),
        business_questions=[
            "Which voluntary corporate actions have elections due in the next three business days, and which entitlements have no election yet?",
            "Which custodian notifications disagree with the golden copy event, and are they resolved?",
            "Which income was not received on pay date, how much is outstanding, and for how long?",
            "How much withholding tax is reclaimable, how much has been recovered, and which reclaims approach the statute of limitation?",
            "Which class action settlements has each fund or client account claimed, and how much has been recovered?",
        ],
        grain="Corporate action entitlement (event x safekeeping account x entitled portfolio, CAEN-) with its elections, payments and income collection; withholding tax reclaim (WHTR-), tax relief documentation (fund x market x method x period) and class action claim (SCAC-) as companion facts",
        dimensions=["Corporate action event and type", "Mandatory / voluntary", "Instrument", "Safekeeping account and custodian",
                    "Portfolio and fund", "Client account (SMA)", "Election status", "Income claim status", "Relief market and method",
                    "Reclaim status", "Class action claim status", "Business date"],
        measures=[
            ("Golden Copy Discrepancies", "Count of Corporate Action Notification Receipts with Golden Copy Discrepancy Indicator = Y, by custodian and event type, and the share of notification receipts so flagged.",
             [("28", "Corporate Action Notification Receipt", "Golden Copy Discrepancy Indicator"),
              ("28", "Corporate Action Notification Receipt", "Notified Event"), ("28", "Corporate Action Notification Receipt", "Notified Safekeeping Account"),
              ("28", "Safekeeping Account", "Account Provider"), ("17", "Corporate Action Event", "Corporate Action Event Type")]),
            ("Elections Due", "Entitlements of events with Mandatory Voluntary Type = Voluntary (or mandatory with options) whose earliest Internal Election Deadline (or Custodian Response Deadline where no election exists) falls in the next three business days, and those with no Corporate Action Election in Election Instruction Status Sent or later.",
             [("28", "Corporate Action Election", "Internal Election Deadline"), ("28", "Corporate Action Election", "Election Instruction Status"),
              ("28", "Corporate Action Election", "Elected Entitlement"), ("28", "Corporate Action Notification Receipt", "Custodian Response Deadline"),
              ("17", "Corporate Action Event", "Mandatory Voluntary Type"), ("28", "Corporate Action Entitlement", "Corporate Action Entitlement ID"),
              ("09", "Calendar Date", "Calendar Date"), ("09", "Calendar Date", "Day Type")]),
            ("Election Timeliness %", "Elections whose Election Instruction Status was Sent or later in the daily snapshot taken at the Internal Election Deadline / all elections due in the period; Defaulted elections and voluntary entitlements with no election by the option's Market Deadline counted separately.",
             [("28", "Corporate Action Election", "Election Instruction Status"), ("28", "Corporate Action Election", "Internal Election Deadline"),
              ("17", "Corporate Action Option", "Market Deadline"), ("17", "Corporate Action Option", "Default Option Indicator")]),
            ("Elections Without Decision Evidence", "Count of elections for voluntary events with neither an Election Investment Decision (24) nor an Election Decision Maker.",
             [("28", "Corporate Action Election", "Election Investment Decision"), ("28", "Corporate Action Election", "Election Decision Maker"),
              ("17", "Corporate Action Event", "Mandatory Voluntary Type")]),
            ("Unpaid Entitlements", "Count and Entitled Cash Amount of entitlements with no non-reversed Corporate Action Payment one business day after the event's Corporate Action Payment Date, by custodian and market.",
             [("28", "Corporate Action Entitlement", "Entitled Cash Amount"), ("28", "Corporate Action Entitlement", "Corporate Action Entitlement Status"),
              ("28", "Corporate Action Payment", "Paid Entitlement"), ("28", "Corporate Action Payment", "Reversal Indicator"),
              ("17", "Corporate Action Event", "Corporate Action Payment Date")]),
            ("Income Paid on Pay Date %", "Income Collections whose Received Payment has Payment Posting Date <= Income Due Date / all Income Collections due in the period, by custodian.",
             [("28", "Income Collection", "Received Payment"), ("28", "Income Collection", "Income Due Date"),
              ("28", "Corporate Action Payment", "Payment Posting Date"), ("28", "Corporate Action Payment", "Payment Confirmation Reference")]),
            ("Outstanding Income Claims", "Sum of Income Difference Amount of Income Collections with Income Claim Status not Closed, aged in business days since Income Due Date; and the expected-vs-received gap: Expected Net Income Amount - Paid Net Amount per collection.",
             [("28", "Income Collection", "Income Difference Amount"), ("28", "Income Collection", "Income Claim Status"),
              ("28", "Income Collection", "Income Due Date"), ("28", "Income Collection", "Expected Net Income Amount"),
              ("28", "Corporate Action Payment", "Paid Net Amount")]),
            ("Expected Income Not Accrued", "Count of Income Collections whose Expected Income Accrual does not resolve to a 27 Income Accrual of the same Related Corporate Action Event (DP-166).",
             [("28", "Income Collection", "Expected Income Accrual"), ("27", "Income Accrual", "Related Corporate Action Event"),
              ("27", "Income Accrual", "Accrued Income Balance"), ("27", "Income Accrual", "Related Income Collection")]),
            ("Excess Withholding", "Per payment: Withholding Tax Amount - Paid Gross Amount x Treaty Rate Percentage of the fund's Tax Relief Documentation effective for the Relief Market on the Payment Posting Date (Documentation Approval Status = Approved); positive values are reclaimable or relief failures.",
             [("28", "Corporate Action Payment", "Withholding Tax Amount"), ("28", "Corporate Action Payment", "Paid Gross Amount"),
              ("28", "Tax Relief Documentation", "Treaty Rate Percentage"), ("28", "Tax Relief Documentation", "Relief Market"),
              ("28", "Tax Relief Documentation", "Beneficial Owner Fund"), ("28", "Tax Relief Documentation", "Documentation Approval Status"),
              ("28", "Tax Relief Documentation", "Relief Effective From"), ("28", "Tax Relief Documentation", "Relief Effective To")]),
            ("Reclaims Outstanding and At Risk", "Sum of Reclaimable Amount - Recovered Amount over Withholding Tax Reclaims with Tax Reclaim Status not Closed, aged from Reclaim Filed Date; reclaims with Statute of Limitation Date within 90 days and no Reclaim Filed Date flagged at risk.",
             [("28", "Withholding Tax Reclaim", "Reclaimable Amount"), ("28", "Withholding Tax Reclaim", "Recovered Amount"),
              ("28", "Withholding Tax Reclaim", "Tax Reclaim Status"), ("28", "Withholding Tax Reclaim", "Reclaim Filed Date"),
              ("28", "Withholding Tax Reclaim", "Statute of Limitation Date"), ("28", "Withholding Tax Reclaim", "Reclaim Market")]),
            ("Reclaim Recovery Rate", "Recovered Amount / Reclaimable Amount of reclaims closed in the period, by Reclaim Market and Filing Agent.",
             [("28", "Withholding Tax Reclaim", "Recovered Amount"), ("28", "Withholding Tax Reclaim", "Reclaimable Amount"),
              ("28", "Withholding Tax Reclaim", "Filing Agent")]),
            ("Relief Documentation Expiring", "Count of approved Tax Relief Documentation rows whose Documentation Expiry Date falls within the next 90 days, by fund and market.",
             [("28", "Tax Relief Documentation", "Documentation Expiry Date"), ("28", "Tax Relief Documentation", "Documentation Approval Status")]),
            ("Class Action Recoveries and Unfiled Claims", "Sum of Recovery Amount by Claiming Fund (and, in the restricted view, Claiming Client Account) and period; and the count of claims with Recognized Loss Amount > 0, Opt-Out Indicator = N and no Claim Filed Date.",
             [("28", "Class Action Claim", "Recovery Amount"), ("28", "Class Action Claim", "Claiming Fund"),
              ("28", "Class Action Claim", "Claiming Client Account"), ("28", "Class Action Claim", "Recognized Loss Amount"),
              ("28", "Class Action Claim", "Opt-Out Indicator"), ("28", "Class Action Claim", "Claim Filed Date"),
              ("28", "Class Action Claim", "Class Action Claim Status")]),
        ],
        inputs=[
            ("28", "Corporate Action Notification Receipt", ["Notified Event", "Notified Safekeeping Account", "Custodian Event Reference",
                                                             "Custodian Message Reference", "Notification Function", "Custodian Response Deadline",
                                                             "Golden Copy Discrepancy Indicator"]),
            ("28", "Corporate Action Entitlement", ["Corporate Action Entitlement ID", "Entitlement Event", "Entitled Safekeeping Account",
                                                    "Entitled Portfolio", "Eligible Balance", "Entitled Cash Amount", "Entitled Securities Quantity",
                                                    "Market Claim Indicator", "Corporate Action Entitlement Status"]),
            ("28", "Corporate Action Election", ["Corporate Action Election ID", "Elected Entitlement", "Elected Option", "Elected Quantity",
                                                 "Election Decision Maker", "Election Investment Decision", "Internal Election Deadline",
                                                 "Election Instruction Status"]),
            ("28", "Corporate Action Payment", ["Paid Entitlement", "Payment Confirmation Reference", "Corporate Action Payment Type",
                                                "Payment Posting Date", "Paid Gross Amount", "Withholding Tax Amount", "Paid Net Amount",
                                                "Paid Securities Quantity", "Reversal Indicator", "Booked Portfolio Transaction"]),
            ("28", "Income Collection", ["Income Entitlement", "Income Due Date", "Expected Income Accrual", "Expected Net Income Amount",
                                         "Received Payment", "Income Difference Amount", "Income Claim Status"]),
            ("28", "Tax Relief Documentation", ["Beneficial Owner Fund", "Relief Market", "Tax Relief Method", "Treaty Rate Percentage", "Relief Form",
                                                "Documentation Approval Status", "Documentation Expiry Date", "Relief Effective From",
                                                "Relief Effective To"]),
            ("28", "Withholding Tax Reclaim", ["Withholding Tax Reclaim ID", "Reclaiming Fund", "Reclaim Market", "Source Payment",
                                               "Reclaimable Amount", "Reclaim Filing Reference", "Reclaim Filed Date", "Filing Agent",
                                               "Statute of Limitation Date", "Tax Reclaim Status", "Recovered Amount"]),
            ("28", "Class Action Claim", ["Class Action Claim ID", "Class Action Event", "Claiming Fund", "Claiming Client Account",
                                          "Eligible Purchase Quantity", "Recognized Loss Amount", "Claim Filing Agent", "Claim Filed Date",
                                          "Opt-Out Indicator", "Class Action Claim Status", "Recovery Amount"]),
            ("27", "Income Accrual", ["Accrual Book", "Accrual Instrument", "Income Accrual Date", "Income Type", "Related Corporate Action Event",
                                      "Accrued Income Balance", "Related Income Collection"]),
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Event Instrument", "Corporate Action Event Type", "Mandatory Voluntary Type",
                                              "Golden Copy Status", "Ex-Date", "Record Date", "Corporate Action Payment Date"]),
            ("17", "Corporate Action Option", ["Option Event", "Option Number", "Corporate Action Option Type", "Default Option Indicator",
                                               "Market Deadline"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Account Provider", "Safekeeping Account Status"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line"]),
            ("15", "Account", ["Account ID", "Account Type"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
        ],
        upstream=["DP-167", "DP-166", "DP-004", "DP-093", "DP-013", "DP-099", "DP-097", "DP-140", "DP-192"],
        refresh="Daily",
        timeliness="Notifications, entitlements and election status by 7am ET each business day and refreshed hourly until the custodians' cut-off; payments and income collection by 10am ET on T+1 after pay date; reclaims and class action claims weekly from the filing agents",
        history="Every notification, entitlement, election, payment, reclaim and claim kept for 10 years (books and records; tax reclaim files until the statute of limitation passes plus 7 years); daily snapshots of election status for timeliness evidence",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Corporate Action Entitlement references an Entitlement Event that resolves to a golden-copy Corporate Action Event in DP-099 and an Entitled Safekeeping Account that resolves in DP-167.",
            "Every Corporate Action Election's Elected Option is an option of the entitlement's event, and Elected Quantity summed over an entitlement's elections does not exceed its Eligible Balance.",
            "Paid Net Amount = Paid Gross Amount - Withholding Tax Amount for every cash Corporate Action Payment that is not a reversal.",
            "Every Income Collection with a Received Payment has Income Difference Amount = Expected Net Income Amount - the payment's Paid Net Amount.",
            "Every Withholding Tax Reclaim's Source Payment resolves to a Corporate Action Payment with Withholding Tax Amount > 0, and Recovered Amount never exceeds Reclaimable Amount.",
            "Every Class Action Claim names exactly one of Claiming Fund and Claiming Client Account, and its Class Action Event is a Corporate Action Event of type Class Action in DP-099.",
        ],
        notes=("Consumer-aligned operational product of 28 for FN-34. Certified numbers: none. Event terms, options and dates come "
               "from the Corporate Action Event Golden Copy, DP-099 (17, CD-195); the booked position effect is an 18 portfolio "
               "transaction (Booked Portfolio Transaction, DP-141) referenced by key only; elections reference 24 investment "
               "decisions by key; investee proxy votes are 34 and out of scope. Expected income is DP-166's Income Accrual (27). "
               "Accounts and custodians are DP-167's; client accounts are DP-093's; portfolios DP-140's; the fund dimension DP-004's. "
               "Operating model (CD-297, CD-331): custody is outsourced, so notifications and payments are the custodians' records "
               "as received plus the firm's elections and controls. If corporate action processing is also outsourced to the "
               "custodian or a middle-office provider, elections, reclaims and claims become the provider's records; the grain is "
               "unchanged, the provider is named by the account's custodian or 18 Middle Office Provider, and Election Timeliness % "
               "and Reclaims Outstanding and At Risk become the provider's deadline and claim-aging exceptions. "
               "PII = Y: Claiming Client Account, Recognized Loss Amount and Recovery Amount are personal data for SMA client claims, "
               "and Election Decision Maker is an employee (DP-192); publish a fund-level view without client accounts or names. "
               "Taxonomy gap: Corporate Action Election has no instruction sent timestamp, so Election Timeliness % relies on daily "
               "status snapshots taken at the Internal Election Deadline. Taxonomy gap: income without a 17 event is not controlled "
               "until 17 announces it (28 SME question 13). Taxonomy gap: Withholding Tax Reclaim has no expected recovery date. "
               "Code values (Voluntary, Sent, Defaulted, Closed, Approved, Class Action, Business Day) are drafting assumptions. "
               "Open SME questions (28 Source_Notes): who makes voluntary corporate action decisions (question 4); who files class "
               "action claims and whether SMA claims are filed (question 7); whether reclaims are tracked in house (question 8). "
               "Rests on CD-195, CD-297, CD-331."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-174": dict(
        definition=("Each securities lending program's loans, utilization against the maximum on-loan percentage, collateral and "
                    "margin coverage by borrower, recalls, regulatory loan report status, and gross revenue, agent fee and fund net "
                    "revenue by period. It combines the 28 lending program, agreements, loans, collateral, reports and revenue "
                    "with fund total assets and net assets from DP-165, lendable ABOR positions and the revenue journal from "
                    "DP-166, and borrower approvals from DP-115. Asset servicing and the fund board use it to set program "
                    "parameters, monitor borrower exposure and evidence the fund's share of lending revenue."),
        business_questions=[
            "What share of each fund's total assets and lendable holdings is on loan, and is any fund above its maximum on-loan percentage?",
            "Is every borrower collateralized at or above the agreement's minimum margin, and which borrower concentrations are largest?",
            "Is every open loan with a borrower that is approved for securities lending for that fund?",
            "Which recalls are past due, and which loans are unreported or rejected under Rule 10c-1a?",
            "How much net lending revenue did each fund earn this period, did the split match the agreed revenue share, and was it booked to the fund?",
        ],
        grain="Securities loan (SBL-) x mark date, with lending program (fund or portfolio x agent x effective period), lending agreement, collateral received (loan or borrower pool x item x mark date), loan regulatory report (loan x regime) and lending revenue allocation (program x revenue period) as companion facts",
        dimensions=["Fund and lending portfolio", "Agent lender", "Borrower", "Instrument and asset class", "Collateral type",
                    "Lending agreement type", "Loan status", "Reporting regime", "Revenue period", "Mark date"],
        measures=[
            ("On-Loan Value", "Sum of Loan Value of Securities Loans with Securities Loan Status = Open at the Loan Mark Date, by program, borrower and asset class.",
             [("28", "Securities Loan", "Loan Value"), ("28", "Securities Loan", "Securities Loan Status"), ("28", "Securities Loan", "Loan Mark Date"),
              ("28", "Securities Loan", "Loan Program"), ("28", "Securities Loan", "Borrower"), ("28", "Securities Loan", "Loaned Instrument"),
              ("17", "Instrument", "Asset Class")]),
            ("Program Utilization %", "On-Loan Value / Total Assets Amount of the fund's NAV of record on the same date (from DP-165); flagged when above the program's Maximum On-Loan Percentage.",
             [("27", "Fund NAV Calculation", "Total Assets Amount"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "NAV Book"), ("27", "Fund Accounting Book", "Book Fund"),
              ("28", "Securities Lending Program", "Maximum On-Loan Percentage"), ("28", "Securities Lending Program", "Lending Fund"),
              "On-Loan Value"]),
            ("On-Loan to Net Assets % (memo)", "On-Loan Value / Fund Net Assets Amount of the fund's NAV of record on the same date (from DP-165). Memo for board reporting; Program Utilization % on total assets is the regulatory test (CD-363, ruled 2026-10-14). Not certified.",
             [("27", "Fund NAV Calculation", "Fund Net Assets Amount"), ("27", "Fund NAV Calculation", "Valuation Date"), ("27", "Fund NAV Calculation", "NAV Book"),
              ("27", "Fund Accounting Book", "Book Fund"), "On-Loan Value"]),
            ("Lendable Utilization %", "On-Loan Value / Base Market Value of the fund book's ABOR Valuation Records on the date for instruments eligible in the program (DP-166), by asset class.",
             [("27", "ABOR Valuation Record", "Base Market Value"), ("27", "ABOR Valuation Record", "Valuation Book"),
              ("27", "ABOR Valuation Record", "Valued Instrument"), ("27", "ABOR Valuation Record", "ABOR Valuation Date"), "On-Loan Value"]),
            ("Collateral Coverage %", "Sum of Collateral Value of Lending Collateral Received at the Collateral Mark Date / On-Loan Value, per loan and per borrower collateral pool; coverage below the agreement's Minimum Collateral Margin Percentage is a margin shortfall, with the shortfall amount.",
             [("28", "Lending Collateral Received", "Collateral Value"), ("28", "Lending Collateral Received", "Collateralized Loan"),
              ("28", "Lending Collateral Received", "Collateral Pool Borrower"), ("28", "Lending Collateral Received", "Collateral Mark Date"),
              ("28", "Securities Lending Agreement", "Minimum Collateral Margin Percentage"), ("28", "Securities Loan", "Governing Agreement"),
              "On-Loan Value"]),
            ("Collateral by Type", "Sum of Collateral Value by Lending Collateral Type and Tri-Party Agent; collateral types outside the agreement's Eligible Collateral Types flagged.",
             [("28", "Lending Collateral Received", "Collateral Value"), ("28", "Lending Collateral Received", "Lending Collateral Type"),
              ("28", "Lending Collateral Received", "Tri-Party Agent"), ("28", "Securities Lending Agreement", "Eligible Collateral Types")]),
            ("Borrower Concentration", "Largest single Borrower's On-Loan Value / program On-Loan Value, and the top five borrowers' share, per program.",
             [("28", "Securities Loan", "Borrower"), "On-Loan Value"]),
            ("Unapproved Borrower Loans", "Count and Loan Value of open loans whose Borrower has no Counterparty Approval Scope with Approved Activity = Securities Lending, Scope Status = Active, effective on the mark date and with Scope Fund empty or equal to the Lending Fund, or whose Approved Counterparty Profile has Counterparty Approval Status other than Approved (DP-115).",
             [("25", "Counterparty Approval Scope", "Scope Counterparty"), ("25", "Counterparty Approval Scope", "Approved Activity"),
              ("25", "Counterparty Approval Scope", "Scope Fund"), ("25", "Counterparty Approval Scope", "Scope Status"),
              ("25", "Counterparty Approval Scope", "Scope Effective From"), ("25", "Counterparty Approval Scope", "Scope Effective To"),
              ("25", "Approved Counterparty Profile", "Counterparty Party"), ("25", "Approved Counterparty Profile", "Counterparty Approval Status"),
              ("28", "Securities Loan", "Borrower"), ("28", "Securities Loan", "Loan Value")]),
            ("Recalls Past Due", "Count of loans with a Recall Date and no Loan Return Date more than the market settlement cycle after the Recall Date, by borrower.",
             [("28", "Securities Loan", "Recall Date"), ("28", "Securities Loan", "Loan Return Date"), ("28", "Securities Loan", "Borrower")]),
            ("Unreported Loans", "Count of open loans with no Loan Regulatory Report for each applicable Loan Reporting Regime, or with Loan Report Status other than Accepted and Reporting Deferred Indicator = N, by regime and Reporting Party.",
             [("28", "Loan Regulatory Report", "Reported Loan"), ("28", "Loan Regulatory Report", "Loan Reporting Regime"),
              ("28", "Loan Regulatory Report", "Loan Report Status"), ("28", "Loan Regulatory Report", "Reporting Deferred Indicator"),
              ("28", "Loan Regulatory Report", "Reporting Party")]),
            ("Fund Net Lending Revenue", "Sum of Fund Net Revenue of Lending Revenue Allocations by program and revenue period (Revenue Data Basis final where available), beside Gross Lending Revenue and Agent Fee Amount.",
             [("28", "Lending Revenue Allocation", "Fund Net Revenue"), ("28", "Lending Revenue Allocation", "Gross Lending Revenue"),
              ("28", "Lending Revenue Allocation", "Agent Fee Amount"), ("28", "Lending Revenue Allocation", "Revenue Program"),
              ("28", "Lending Revenue Allocation", "Revenue Period Start"), ("28", "Lending Revenue Allocation", "Revenue Period End"),
              ("28", "Lending Revenue Allocation", "Revenue Data Basis")]),
            ("Revenue Split Variance", "Fund Net Revenue / (Fund Net Revenue + Agent Fee Amount) - the program's Fund Revenue Share Percentage, per revenue period; and Gross Lending Revenue - Agent Fee Amount - Fund Net Revenue; each flagged beyond 0.01.",
             [("28", "Lending Revenue Allocation", "Fund Net Revenue"), ("28", "Lending Revenue Allocation", "Agent Fee Amount"),
              ("28", "Lending Revenue Allocation", "Gross Lending Revenue"), ("28", "Securities Lending Program", "Fund Revenue Share Percentage")]),
            ("Revenue Not Booked", "Lending Revenue Allocations with Fund Net Revenue > 0 whose Booked Fund Journal Entry is empty or does not resolve to a Fund Journal Entry with Fund Journal Status = Posted (DP-166), 5 business days after Revenue Period End.",
             [("28", "Lending Revenue Allocation", "Booked Fund Journal Entry"), ("27", "Fund Journal Entry", "Fund Journal Entry ID"),
              ("27", "Fund Journal Entry", "Fund Journal Status"), ("28", "Lending Revenue Allocation", "Revenue Period End")]),
            ("Lending Return (bps)", "Annualized Fund Net Lending Revenue / average Fund Total Net Assets of the NAV of record over the revenue period (from DP-165) x 10,000.",
             [("27", "Fund NAV Calculation", "Fund Net Assets Amount"), "Fund Net Lending Revenue"]),
        ],
        inputs=[
            ("28", "Securities Lending Program", ["Lending Fund", "Lending Portfolio", "Agent Lender", "Maximum On-Loan Percentage",
                                                  "Fund Revenue Share Percentage", "Cash Collateral Reinvestment Portfolio", "Program Status",
                                                  "Program Effective From", "Program Effective To"]),
            ("28", "Securities Lending Agreement", ["Agreement Program", "Agreement Agent", "Agreement Counterparty", "Lending Agreement Type",
                                                    "Eligible Collateral Types", "Minimum Collateral Margin Percentage",
                                                    "Borrower Default Indemnification Indicator", "Agreement Status", "Agreement Effective Date",
                                                    "Agreement Termination Date"]),
            ("28", "Securities Loan", ["Securities Loan ID", "Loan Program", "Governing Agreement", "Lent From Account", "Borrower",
                                       "Loaned Instrument", "Loan Quantity", "Loan Value", "Loan Mark Date", "Lending Fee Rate", "Rebate Rate",
                                       "Recall Date", "Loan Return Date", "Securities Loan Status"]),
            ("28", "Lending Collateral Received", ["Collateralized Loan", "Collateral Pool Borrower", "Collateral Mark Date", "Lending Collateral Type",
                                                   "Collateral Instrument", "Collateral Value", "Collateral Margin Percentage", "Tri-Party Agent"]),
            ("28", "Loan Regulatory Report", ["Reported Loan", "Loan Reporting Regime", "Reporting Party", "Unique Transaction Identifier",
                                              "Loan Report Status", "Reporting Deferred Indicator"]),
            ("28", "Lending Revenue Allocation", ["Revenue Program", "Revenue Period Start", "Revenue Period End", "Gross Lending Revenue",
                                                  "Agent Fee Amount", "Fund Net Revenue", "Revenue Data Basis", "Booked Fund Journal Entry"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "Total Assets Amount", "Fund Net Assets Amount"]),
            ("27", "Fund Accounting Book", ["Book Fund"]),
            ("27", "ABOR Valuation Record", ["Valuation Book", "Valued Instrument", "ABOR Valuation Date", "ABOR Quantity", "Base Market Value"]),
            ("27", "Fund Journal Entry", ["Fund Journal Entry ID", "Fund Journal Status", "Accounting Date"]),
            ("25", "Approved Counterparty Profile", ["Counterparty Party", "Counterparty Approval Status", "Approval Status Effective From"]),
            ("25", "Counterparty Approval Scope", ["Scope Counterparty", "Approved Activity", "Scope Fund", "Scope Status", "Scope Effective From",
                                                   "Scope Effective To"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
        ],
        upstream=["DP-167", "DP-165", "DP-166", "DP-004", "DP-013", "DP-097", "DP-115", "DP-143"],
        refresh="Daily",
        timeliness="Loans, marks and collateral from the agent lender by 9am ET on T+1; regulatory report status by noon ET on T+1; revenue allocations by business day 10 after month-end (estimated earlier, final when the agent closes the month)",
        history="Daily loan, collateral and report snapshots kept for 7 years; revenue allocations and program and agreement terms (SCD type 2) kept for 10 years (Rule 31a-2, N-CEN support)",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Securities Loan's Loan Program resolves to a Securities Lending Program effective on the Loan Mark Date and its Governing Agreement to a Securities Lending Agreement of that program with Agreement Status = Active.",
            "Every open loan has collateral on the Loan Mark Date, either as Lending Collateral Received for the loan or for its borrower's collateral pool.",
            "Gross Lending Revenue - Agent Fee Amount = Fund Net Revenue for every Lending Revenue Allocation within 0.01.",
            "Every Borrower, Agreement Counterparty, Agent Lender and Tri-Party Agent resolves to a party in DP-240, and every Loaned Instrument and Collateral Instrument resolves in DP-097.",
            "Every Lent From Account resolves to an open safekeeping account in DP-167 assigned to the Lending Fund or Lending Portfolio.",
        ],
        notes=("Consumer-aligned analytical product of 28 for FN-34; supports the board (FN-36) and N-CEN. Certified numbers: none. "
               "Utilization and lending return use Total Assets Amount and Fund Total Net Assets of the NAV of record from DP-165 "
               "(CD-330), never a recomputed AUM; the candidate named net assets for utilization, but the SEC staff one-third limit "
               "is measured on total assets including collateral, so Total Assets Amount is used and the SME confirms. Cash "
               "collateral reinvestment is an 18 portfolio (CD-198) read through DP-140 and DP-142, not here; OTC and margin "
               "collateral is 26. Revenue booked to the fund is the 27 journal referenced by Booked Fund Journal Entry (DP-166). "
               "Rule 10c-1a report status is shown (the EU and UK SFTR regime values left with CW-928), but the reports stay 28 records (CD-233). This product supplies the "
               "securities lending items of N-CEN to DP-185 (CD-334). Borrowers are 25 approved counterparties (DP-115); the "
               "Counterparty and Broker dimension is DP-115's. "
               "Operating model (CD-297, CD-331): lending is run by an agent lender (custodian or third party); the grain is the "
               "agent's loan, collateral and revenue files as received, which does not change if the agent changes or the fund "
               "lends through a different agent; Agent Lender names the provider. "
               "PII = N: borrowers, agents and funds are organizations. "
               "Taxonomy gap: no attribute marks which instruments are eligible for lending in a program, so Lendable Utilization % "
               "uses every ABOR holding of the lending fund less instruments excluded by a program parameter list. Taxonomy gap: "
               "Securities Loan has no settlement cycle for recalls; Recalls Past Due uses the market's standard cycle as a "
               "parameter. Taxonomy gap: Maximum On-Loan Percentage is provisional in 28 (future owner 01). Code values (Open, "
               "Securities Lending, Active, Accepted, Posted, final) are drafting assumptions. "
               "Open SME questions (28 Source_Notes): whether lending is run by the custodian or a third-party agent, which funds "
               "lend, and who is the Rule 10c-1a reporting party (question 6). "
               "Rests on CD-182, CD-198, CD-233, CD-297, CD-330, CD-331, CD-334."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-175 retired (CW-207); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    "DP-176": dict(
        definition=("One oversight scorecard per fund service provider - fund administrator, global custodian and sub-custodian "
                    "network, transfer agent and securities lending agent - with its fund-level service results: periodic service "
                    "reviews, SOC 1 receipt, Rule 17f-5 and 17f-7 foreign custody assessments, and the operational evidence each "
                    "provider generates (late NAV releases, NAV errors, custody reconciliation breaks, TA control exceptions). "
                    "Engagement, criticality tier, residual risk, contract and contracted service level results are read from "
                    "DP-219 and DP-210 (40, CD-355, CD-361) and the outsourced-TA engagement from 29 Servicing Provider Engagement, never re-mastered. Fund "
                    "administration uses it for the annual provider reviews and the board's service provider and foreign custody "
                    "reports."),
        business_questions=[
            "Has every fund service provider had its annual review and delivered its SOC 1 report, and which reviews are overdue?",
            "Is every active sub-custodian and depository assessed under Rule 17f-5 or 17f-7 within the last year, eligible, and reported to the board?",
            "How did each administrator perform this quarter on NAV timeliness and NAV errors, and what did its errors cost the funds?",
            "Which custodians have the most aged reconciliation breaks and the lowest income-on-pay-date rate?",
            "Which critical providers missed contracted service levels or carry an elevated residual risk rating?",
        ],
        grain="Fund service provider (02 party) x provider role x reporting period (month, with quarter and year rollups), with foreign custody assessment (arrangement or depository x assessment type x date) and custodian service review (provider x role x review period) as companion facts",
        dimensions=["Service provider and role", "Supplier engagement and criticality tier", "Fund (served)", "Market (custody network)",
                    "Assessment type (17f-5 / 17f-7)", "Reporting period", "Fund accounting operating model", "Residual risk rating"],
        measures=[
            ("Providers in Scope", "Count of distinct providers with an effective Product Party Role of a fund service Party Role Type (administrator, custodian, depositary, transfer agent, securities lending agent) or an active Custody Provider Profile, by role.",
             [("01", "Product Party Role", "Party"), ("01", "Product Party Role", "Party Role Type"), ("01", "Product Party Role", "Role Effective From"),
              ("01", "Product Party Role", "Role Effective To"), ("28", "Custody Provider Profile", "Provider Party"),
              ("28", "Custody Provider Profile", "Custody Provider Role"), ("28", "Custody Provider Profile", "Provider Profile Status")]),
            ("Annual Review Currency %", "Providers in scope with a review whose period ended within the last 12 months - Custodian Service Review Review Period End (custody roles), 29 Servicing Provider Engagement Last Oversight Review Date (transfer agents, read from 29 directly) or 40 Supplier Performance Review Review Period End of the linked engagement (administrators and lending agents, from DP-219) / providers in scope.",
             [("28", "Custodian Service Review", "Review Period End"), ("28", "Custodian Service Review", "Reviewed Provider"),
              ("29", "Servicing Provider Engagement", "Last Oversight Review Date"), ("29", "Servicing Provider Engagement", "Servicing Provider"),
              ("40", "Supplier Performance Review", "Review Period End"), ("40", "Supplier Performance Review", "Reviewed Engagement"),
              "Providers in Scope"]),
            ("SOC 1 Receipt %", "Custodian Service Reviews of the latest period with SOC 1 Report Received Indicator = Y / all latest reviews, by provider role.",
             [("28", "Custodian Service Review", "SOC 1 Report Received Indicator"), ("28", "Custodian Service Review", "Reviewed Provider Role"),
              ("28", "Custodian Service Review", "Review Period End")]),
            ("Foreign Custody Assessment Currency %", "Active Sub-Custodian Network Arrangements (Rule 17f-5) and their Securities Depositories (Rule 17f-7) with a Foreign Custody Assessment of the matching Foreign Custody Assessment Type dated within the last 12 months and Eligibility Decision = Eligible / all active arrangements and depositories, by global custodian and market.",
             [("28", "Foreign Custody Assessment", "Assessed Arrangement"), ("28", "Foreign Custody Assessment", "Assessed Depository"),
              ("28", "Foreign Custody Assessment", "Foreign Custody Assessment Type"), ("28", "Foreign Custody Assessment", "Assessment Date"),
              ("28", "Foreign Custody Assessment", "Eligibility Decision"), ("28", "Sub-Custodian Network Arrangement", "Arrangement Status"),
              ("28", "Sub-Custodian Network Arrangement", "Arrangement Global Custodian"), ("28", "Sub-Custodian Network Arrangement", "Arrangement Market"),
              ("28", "Sub-Custodian Network Arrangement", "Securities Depository")]),
            ("Ineligible Active Arrangements", "Count of active arrangements or depositories whose latest Foreign Custody Assessment has Eligibility Decision other than Eligible, with the Custody Risk Rating.",
             [("28", "Foreign Custody Assessment", "Eligibility Decision"), ("28", "Foreign Custody Assessment", "Custody Risk Rating"),
              ("28", "Sub-Custodian Network Arrangement", "Arrangement Status")]),
            ("Assessments Not Reported to Board", "Count of Foreign Custody Assessments older than one quarter with no Board Report Date.",
             [("28", "Foreign Custody Assessment", "Board Report Date"), ("28", "Foreign Custody Assessment", "Assessment Date")]),
            ("Custodian Income on Pay Date %", "Income Paid on Pay Date Percentage of the latest Custodian Service Review per custodian, and its change from the prior review.",
             [("28", "Custodian Service Review", "Income Paid on Pay Date Percentage"), ("28", "Custodian Service Review", "Review Period Start")]),
            ("Administrator Late NAV Releases", "Share class NAV first releases (Release Sequence = 1) of books whose Fund Book Operating Period names the administrator (Fund Administrator of Record) on the valuation date and whose Release Timestamp is after the release deadline / all such releases, per administrator and period (from DP-168 and DP-165).",
             [("27", "NAV Dissemination", "Release Sequence"), ("27", "NAV Dissemination", "Release Timestamp"), ("27", "NAV Dissemination", "Released NAV"),
              ("27", "Share Class NAV", "Share Class NAV ID"), ("27", "Share Class NAV", "Parent NAV Calculation"),
              ("27", "Fund NAV Calculation", "NAV Book"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund Book Operating Period", "Fund Administrator of Record"), ("27", "Fund Book Operating Period", "Operated Book"),
              ("27", "Fund Book Operating Period", "Operating Period Effective From"), ("27", "Fund Book Operating Period", "Operating Period Effective To")]),
            ("Administrator NAV Errors", "Count of NAV Error Cases (from DP-169) on funds whose book's Fund Book Operating Period on the First Affected Valuation Date names the administrator and has Fund Accounting Operating Model other than In House, split by Material Error Indicator, with the sum of Fund Loss Amount and the part reimbursed by the administrator (Reimbursing Third Party = the administrator).",
             [("27", "NAV Error Case", "NAV Error Case ID"), ("27", "NAV Error Case", "Error Fund"), ("27", "NAV Error Case", "First Affected Valuation Date"),
              ("27", "NAV Error Case", "Material Error Indicator"), ("27", "NAV Error Case", "Fund Loss Amount"),
              ("27", "NAV Error Case", "Reimbursing Third Party"), ("27", "Fund Accounting Book", "Book Fund"),
              ("27", "Fund Book Operating Period", "Fund Accounting Operating Model"), ("27", "Fund Book Operating Period", "Fund Administrator of Record")]),
            ("Custodian Aged Breaks", "Count of open Custody Reconciliation Breaks (from DP-172) more than 5 business days after their run's Reconciliation Business Date, by the Account Provider of the run's safekeeping account and Break Severity.",
             [("28", "Custody Reconciliation Break", "Break ID"), ("28", "Custody Reconciliation Break", "Break Run"),
              ("28", "Custody Reconciliation Break", "Break Case Status"), ("28", "Custody Reconciliation Break", "Break Severity"),
              ("28", "Custody Reconciliation Run", "Custody Reconciliation Run ID"), ("28", "Custody Reconciliation Run", "Reconciled Safekeeping Account"),
              ("28", "Custody Reconciliation Run", "Reconciliation Business Date"), ("28", "Safekeeping Account", "Account Provider")]),
            ("TA Control Exception Rate", "TA Control Checks (from DP-181) with Control Result other than Passed / all checks, by Control Processing Provider and period, with open TA Control Exceptions by Control Exception Severity.",
             [("29", "TA Control Check", "Control Result"), ("29", "TA Control Check", "Control Processing Provider"),
              ("29", "TA Control Check", "Control Business Date"), ("29", "TA Control Exception", "Exception Control Check"),
              ("29", "TA Control Exception", "Control Exception Severity"), ("29", "TA Control Exception", "Control Exception Status")]),
            ("Contracted Service Levels Met %", "Service Level Measurement Results with Service Level Met Indicator = Y / all results in the period for the provider's engagement contract, and the sum of Service Credit Due Amount, as published by DP-219 (40 rows exist only where no Fund Operations product measures the service, CD-355).",
             [("40", "Service Level Measurement Result", "Service Level Met Indicator"), ("40", "Service Level Measurement Result", "Measured Contract"),
              ("40", "Service Level Measurement Result", "Measured Metric Name"), ("40", "Service Level Measurement Result", "Measurement Period End"),
              ("40", "Service Level Measurement Result", "Service Credit Due Amount"), ("40", "Contracted Service Level", "Service Level Contract"),
              ("40", "Contracted Service Level", "Service Level Metric Name"), ("40", "Contracted Service Level", "Service Level Target")]),
            ("Critical Providers at Risk", "Count of providers whose engagement has Third-Party Criticality Tier of the two highest tiers or Critical or Important Outsourcing Indicator = Y, and whose latest Third-Party Residual Risk Rating is High or above, or whose latest Overall Performance Rating, Oversight Rating or Service Review Outcome is below satisfactory (from DP-219, and 29 Servicing Provider Engagement read directly).",
             [("40", "Supplier Risk Tiering", "Third-Party Criticality Tier"), ("40", "Supplier Risk Tiering", "Tiered Engagement"),
              ("40", "Outsourcing Arrangement", "Critical or Important Outsourcing Indicator"), ("40", "Outsourcing Arrangement", "Outsourcing Engagement"),
              ("37", "Third-Party Risk Assessment", "Third-Party Residual Risk Rating"), ("37", "Third-Party Risk Assessment", "Assessed Supplier Engagement"),
              ("40", "Supplier Performance Review", "Overall Performance Rating"), ("29", "Servicing Provider Engagement", "Oversight Rating"),
              ("28", "Custodian Service Review", "Service Review Outcome")]),
        ],
        inputs=[
            ("28", "Custody Provider Profile", ["Provider Party", "Provider Legal Entity", "Custody Provider Role", "Services Provided",
                                                "Service Agreement Reference", "Provider Profile Status", "Profile Effective From", "Profile Effective To"]),
            ("28", "Sub-Custodian Network Arrangement", ["Arrangement Global Custodian", "Arrangement Market", "Sub-Custodian", "Securities Depository",
                                                         "Arrangement Status", "Arrangement Effective From", "Arrangement Effective To"]),
            ("28", "Foreign Custody Assessment", ["Assessed Arrangement", "Assessed Depository", "Foreign Custody Assessment Type", "Assessment Date",
                                                  "Assessing Party", "Custody Risk Rating", "Eligibility Decision", "Board Report Date"]),
            ("28", "Custodian Service Review", ["Reviewed Provider", "Reviewed Provider Role", "Review Period Start", "Review Period End",
                                                "Income Paid on Pay Date Percentage", "SOC 1 Report Received Indicator", "Service Review Outcome"]),
            ("28", "Custody Reconciliation Run", ["Custody Reconciliation Run ID", "Reconciled Safekeeping Account", "Reconciliation Business Date"]),
            ("28", "Custody Reconciliation Break", ["Break ID", "Break Run", "Break Case Status", "Break Severity"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Account Provider"]),
            ("27", "Fund Accounting Book", ["Book Fund"]),
            ("27", "Fund Book Operating Period", ["Operated Book", "Fund Accounting Operating Model", "Fund Administrator of Record",
                                                  "Operating Period Effective From", "Operating Period Effective To"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "Parent NAV Calculation"]),
            ("27", "NAV Dissemination", ["Released NAV", "Release Sequence", "Release Timestamp"]),
            ("27", "NAV Error Case", ["NAV Error Case ID", "Error Fund", "First Affected Valuation Date", "Material Error Indicator", "Fund Loss Amount",
                                      "Reimbursing Third Party"]),
            ("29", "TA Control Check", ["TA Control Check ID", "Control Business Date", "Control Result", "Control Processing Provider"]),
            ("29", "TA Control Exception", ["Exception Control Check", "Control Exception Severity", "Control Exception Status"]),
            ("29", "Servicing Provider Engagement", ["Servicing Provider", "Servicing Role", "Last Oversight Review Date", "Oversight Rating"]),
            ("01", "Product Party Role", ["Party", "Party Role Type", "Role Effective From", "Role Effective To"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Specialized Servicing Provider Engagement", "Specialized Custody Provider Profile",
                                           "Fund Service Provider Role", "Fund-Paid Indicator", "Engagement Status"]),
            ("40", "Supplier Risk Tiering", ["Tiered Engagement", "Third-Party Criticality Tier", "Tier Effective From", "Tier Effective To"]),
            ("40", "Outsourcing Arrangement", ["Outsourcing Arrangement ID", "Outsourcing Engagement", "Critical or Important Outsourcing Indicator",
                                               "Outsourcing Arrangement Status"]),
            ("40", "Contracted Service Level", ["Service Level Contract", "Service Level Metric Name", "Service Level Target", "Service Level Effective From"]),
            ("40", "Service Level Measurement Result", ["Measured Contract", "Measured Metric Name", "Measurement Period End", "Actual Value",
                                                        "Service Level Met Indicator", "Service Credit Due Amount"]),
            ("40", "Supplier Performance Review", ["Reviewed Engagement", "Review Period End", "Overall Performance Rating"]),
            ("37", "Third-Party Risk Assessment", ["Third-Party Risk Assessment Reference", "Assessed Supplier Engagement", "Third-Party Residual Risk Rating",
                                                   "Third-Party Assessment Completed Date", "Third-Party Next Assessment Due Date"]),
        ],
        upstream=["DP-167", "DP-168", "DP-169", "DP-172", "DP-181", "DP-165", "DP-013", "DP-210", "DP-219", "DP-240"],
        refresh="Monthly",
        timeliness="Monthly scorecard by business day 10 after month-end; quarterly board pack (service provider and foreign custody reports) by business day 15 after quarter-end; foreign custody assessments and reviews published within one business day of approval",
        history="Monthly scorecard snapshots and every assessment and review kept for 10 years (Rule 31a-2; Rule 17f-5 board reporting records); SCD type 2 on provider roles and engagement links",
        classification="Restricted - Commercial Terms",
        pii="N",
        delivery=["Dashboard", "BI semantic model", "Warehouse table", "Regulatory report"],
        dq_rules=[
            "Every provider in scope resolves to a party in DP-240 and to exactly one active Supplier Engagement in DP-210 through Specialized Custody Provider Profile, Specialized Servicing Provider Engagement or Fund Service Provider Role.",
            "Every Foreign Custody Assessment names exactly one of Assessed Arrangement and Assessed Depository, and its Foreign Custody Assessment Type matches it (17f-5 for an arrangement, 17f-7 for a depository).",
            "Every active Sub-Custodian Network Arrangement of a custodian serving a registered fund has at least one Foreign Custody Assessment.",
            "Every Fund Administrator of Record on a Fund Book Operating Period whose model is not In House is a provider in scope with a fund administrator Product Party Role for the Book Fund effective in the same period.",
            "Counts of NAV errors, breaks and TA exceptions per provider equal the counts in DP-169, DP-172 and DP-181 for the same period and scope; this product holds no copy of their records.",
        ],
        notes=("W3 re-point (CW-088, CW-124): Servicing Provider Engagement moved from 13 to 29 (outsourced transfer agent oversight is 29) with its attributes unchanged; the input and the Annual Review Currency % and provider rating measures read ('29', 'Servicing Provider Engagement'); the validator's PII warning on Servicing Provider (a 02 party reference that 29 flags as PII for individual providers) is accepted, because the providers in scope are firms. "
               "Consumer-aligned control product owned in 28 (Head of Fund Administration) for FN-33 (C-06.10 Fund Service Provider "
               "Oversight); supports FN-34, FN-35, FN-46. Certified numbers: none. "
               "Boundaries (CD-333, CD-355, CD-361 item 2): DP-219 Third-Party Oversight (40, a Corporate B product specified in "
               "parallel) publishes every fund service provider's engagement, inherent tier, 37 residual risk, contract, exit plan, "
               "performance reviews and contracted service level results; this product reads them through DP-219 and DP-210 and "
               "keeps only the fund-level service results (17f-5 and 17f-7 assessments, custodian service reviews, and the "
               "operational evidence counted from DP-168, DP-169, DP-172 and DP-181). Neither product copies the other's measures: "
               "Contracted Service Levels Met % and Critical Providers at Risk display DP-219's published values. The 29 "
               "Servicing Provider Engagement (outsourced-TA oversight, CW-088) is read directly. Provider risk ratings stay 37 and "
               "40 (CD-248). This is the fund-provider slice of the enterprise vendor performance product, as DP-073 is the "
               "data-vendor slice (CD-298). The 40, 37 and 13 objects are listed as inputs because the measures trace to them; "
               "their source is DP-219 and DP-210, not the domains directly; 29 Servicing Provider Engagement is read from 29. "
               "Operating model (CD-297, CD-331): this is the product CD-297 means by oversight data. It exists under every model "
               "and grows in weight the more is outsourced: with in-house fund accounting the administrator rows are empty and the "
               "custody, TA and lending agent rows remain; with outsourced fund accounting or TA, the administrator and TA rows "
               "carry the main evidence. The provider of record comes from the domains' own attributes (27 Fund Administrator of "
               "Record, 29 Control Processing Provider, 28 Custody Provider Profile). "
               "PII = N: Reviewer and assessor names are not read; Supplier Engagement's Engaged Supplier is not read because "
               "service providers are joined through the specialized links. Classification Restricted - Commercial Terms because "
               "service credits and contract service levels are commercial terms. "
               "24 input objects, above the usual range, because the scorecard brings together four providers' evidence across "
               "27, 28, 29, 13, 37 and 40, each read through its owning product. "
               "Taxonomy gap: no attribute holds the NAV release deadline (as recorded by DP-165); Administrator Late NAV Releases "
               "uses DP-165's 6pm ET convention. Taxonomy gap: 27 Fund Book Operating Period names the administrator as a 02 party "
               "but not its 40 engagement; the join to DP-219 goes through 01 Product Party Role and Supplier Engagement Fund "
               "Service Provider Role. Taxonomy gap: no 28 object records a securities lending agent review; lending agents are "
               "reviewed through 40 Supplier Performance Review only. Code values (Eligible, Passed, In House, the tier and "
               "rating scales) are drafting assumptions. "
               "Open SME questions (brief §8 question 5): DP-176 owned in 28 (recommended) or in 40 as a view of DP-219; 28 SME "
               "question 14, whether Rule 17f-4 depository use is assessed alongside 17f-5 and 17f-7. "
               "Rests on CD-202, CD-248, CD-297, CD-298, CD-331, CD-333, CD-355, CD-361."
               "WP1 re-point (CW-220, CW-088): upstream DP-043 (retired; successors DP-405 and DP-409) dropped: TA oversight left 13 with Servicing Provider Engagement, now 29, and neither successor publishes it, so the 29 Servicing Provider Engagement attributes Annual Review Currency % and Critical Providers at Risk read are taken from 29 directly; outsourced-TA oversight stays in this product (FOP+CORP brief). No measure or input dropped. The earlier statements that DP-043 keeps the TA servicing view are superseded."),
    ),
}
