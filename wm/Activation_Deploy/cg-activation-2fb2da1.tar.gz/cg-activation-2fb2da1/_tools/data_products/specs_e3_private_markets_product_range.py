"""Data product specifications, Wave E3: private markets (30; DP-136 to DP-139) and the product range (36; DP-105 to DP-109).

Consumer-aligned products built on the Wave E1 foundational products. W4: Data Domain 30 is retired (CW-930); DP-136 to
DP-139 are kept valid on thin residuals until WP0 retires them, and DP-109 is a WP0 re-scope candidate. See CONTRACT.md and
00_Program/Expansion/Agent_Instructions/spec_common.md.

WP1 lineage pass: the specs of the retired DP-136 to DP-139 are deleted (framework.RETIRED_PRODUCTS; register rows kept).
"""

SPECS = {
    # ==================================================================================================================
    # 30 Private Markets
    # ==================================================================================================================
    # DP-136 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-137 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-138 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ------------------------------------------------------------------------------------------------------------------
    # DP-139 retired (CW-930); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ==================================================================================================================
    # 36 Product Development & Lifecycle
    # ==================================================================================================================
    "DP-105": dict(
        definition=("The product development pipeline from idea to decision: every product proposal (PPSL-) by stage and age, the "
                    "business case versions with projected AUM, revenue, breakeven and seed requirement, the market evidence they "
                    "cite, and every product governance committee, its members and meetings, and each approval decision (PAPR-) "
                    "with its conditions. Product leadership steers the range plan with it, and the committee sees what is coming, "
                    "what it approved and which conditions are open. Business case figures are labeled projections; realized AUM "
                    "for launched products is read from DP-008 and realized revenue from DP-012, never computed here (CD-303)."),
        business_questions=[
            "How many proposals are at each stage, how long have they been there, and how old is each?",
            "Which proposals did the committee approve, reject or defer this quarter, and which approval conditions are past their due date?",
            "What projected AUM, revenue and seed capital does the open pipeline represent, and which business cases cite no market evidence?",
            "Did each committee meeting have a quorum, and who sat on each committee?",
            "For products launched from approved proposals, how does realized AUM and revenue compare with the business case projection?",
        ],
        grain=("Product proposal x as-of date (current stage = the Proposal Stage History row with no Stage Exited Date), with "
               "child tables proposal x proposal stage x stage entered date, proposal x business case version (x evidence "
               "sequence), and product approval decision (committee meeting x agenda item)"),
        dimensions=["Product proposal", "Proposal stage", "Proposed vehicle type, asset class, domicile and business line",
                    "Proposal sponsor (employee)", "Product governance committee", "Committee meeting date",
                    "Product decision type and outcome", "Business case version", "Intended peer category", "As-of date"],
        measures=[
            ("Proposals by Stage", "Count of Product Proposals whose current Proposal Stage History row (Stage Exited Date empty) is at each Proposal Stage, by Proposed Vehicle Type and Proposed Business Line.",
             [("36", "Product Proposal", "Product Proposal ID"), ("36", "Product Proposal", "Proposed Vehicle Type"),
              ("36", "Product Proposal", "Proposed Business Line"), ("36", "Proposal Stage History", "Stage Proposal"),
              ("36", "Proposal Stage History", "Proposal Stage"), ("36", "Proposal Stage History", "Stage Exited Date")]),
            ("Days in Current Stage and Proposal Age", "As-of date - Stage Entered Date of the current stage row; as-of date - Proposal Submitted Date; median by Proposal Stage.",
             [("36", "Proposal Stage History", "Stage Entered Date"), ("36", "Product Proposal", "Proposal Submitted Date"),
              "Proposals by Stage"]),
            ("Days to Decision", "Product Committee Meeting Date of the first Product Approval Decision whose Decision Subject Proposal is the proposal - Proposal Submitted Date; median by Product Decision Type.",
             [("36", "Product Approval Decision", "Decision Subject Proposal"), ("36", "Product Approval Decision", "Decision Meeting"),
              ("36", "Product Approval Decision", "Product Decision Type"), ("36", "Product Committee Meeting", "Product Committee Meeting Date"),
              ("36", "Product Proposal", "Proposal Submitted Date")]),
            ("Decision Outcome Mix", "Count of Product Approval Decisions by Product Decision Type and Product Decision Outcome, by committee and meeting period.",
             [("36", "Product Approval Decision", "Product Decision Type"), ("36", "Product Approval Decision", "Product Decision Outcome"),
              ("36", "Product Committee Meeting", "Meeting Product Committee"), ("36", "Product Committee Meeting", "Product Committee Meeting Date")]),
            ("Conditions Past Due", "Count of Product Approval Decisions with Decision Conditions present and Conditions Due Date before the as-of date whose subject has not moved to a later stage or a later decision.",
             [("36", "Product Approval Decision", "Decision Conditions"), ("36", "Product Approval Decision", "Conditions Due Date"),
              ("36", "Product Approval Decision", "Decision Subject Proposal")]),
            ("Projected Pipeline (projection)", "Sum of Projected AUM Year 3, Projected Net Revenue Year 3 and Seed Capital Required of the highest Business Case Version per open proposal; labeled projection, never published under a certified metric name.",
             [("36", "Product Business Case", "Business Case Proposal"), ("36", "Product Business Case", "Business Case Version"),
              ("36", "Product Business Case", "Projected AUM Year 3"), ("36", "Product Business Case", "Projected Net Revenue Year 3"),
              ("36", "Product Business Case", "Seed Capital Required"), ("36", "Product Business Case", "Projection Data Basis"),
              "Proposals by Stage"]),
            ("Business Cases Without Market Evidence", "Count of current business case versions with no Business Case Market Evidence row, or whose evidence fills none of Evidence Peer Universe, Evidence Fee Benchmark Study, Evidence Market Sizing Record and Evidence Flow and Revenue Forecast.",
             [("36", "Business Case Market Evidence", "Evidence Business Case"), ("36", "Business Case Market Evidence", "Evidence Peer Universe"),
              ("36", "Business Case Market Evidence", "Evidence Fee Benchmark Study"), ("36", "Business Case Market Evidence", "Evidence Market Sizing Record"),
              ("36", "Business Case Market Evidence", "Evidence Flow and Revenue Forecast"), ("36", "Product Business Case", "Business Case Version")]),
            ("Committee Quorum Met %", "Product Committee Meetings with Quorum Met Indicator = Y / all meetings in the period, by committee; meetings held by Written Procedure Indicator = Y shown separately.",
             [("36", "Product Committee Meeting", "Quorum Met Indicator"), ("36", "Product Committee Meeting", "Written Procedure Indicator"),
              ("36", "Product Committee Meeting", "Meeting Product Committee")]),
            ("Realized vs Projected AUM %", "For proposals with a launch Product Change Initiative (Originating Proposal) whose Actual Effective Date is at least three years before the as-of date: certified Ending Client Assets (CW-011) at Dimension Type share class for the Changed Product Scope share classes at the month-end three years after launch (from DP-008) / Projected AUM Year 3 of the latest business case approved before launch.",
             [("36", "Product Change Initiative", "Originating Proposal"), ("36", "Product Change Initiative", "Actual Effective Date"),
              ("36", "Changed Product Scope", "Scope Change Initiative"), ("36", "Changed Product Scope", "Scope Share Class"),
              ("06", "Measure Value", "Dimension Type"), ("06", "Measure Value", "Dimension Key"), ("06", "Measure Value", "Period End Date"), ("06", "Client Asset Measures", "Ending Client Assets"),
              ("36", "Product Business Case", "Projected AUM Year 3")]),
            ("Realized vs Projected Net Revenue %", "Net Fee Revenue of the scope share classes over the twelve accounting periods ending three years after launch (from DP-012) / Projected Net Revenue Year 3.",
             [("10", "Fee Revenue Record", "Revenue Share Class / Mandate"), ("10", "Fee Revenue Record", "Revenue Accounting Period"),
              ("10", "Fee Revenue Record", "Net Fee Revenue"), ("36", "Product Business Case", "Projected Net Revenue Year 3"),
              ("36", "Changed Product Scope", "Scope Share Class")]),
        ],
        inputs=[
            ("36", "Product Proposal", ["Product Proposal ID", "Proposal Title", "Proposed Vehicle Type", "Proposed Business Line",
                                        "Proposed Strategy", "Proposed Asset Class", "Proposed Domicile", "Proposed Regulatory Regime",
                                        "Intended Peer Category", "Proposal Origin", "Proposal Sponsor",
                                        "Proposal Submitted Date", "Planned Launch Date"]),
            ("36", "Proposal Stage History", ["Stage Proposal", "Proposal Stage", "Stage Entered Date", "Stage Exited Date"]),
            ("36", "Product Business Case", ["Business Case Proposal", "Business Case Version", "Projected AUM Year 3",
                                             "Projected Net Revenue Year 3", "Projected Breakeven Year", "Projection Management Fee Rate",
                                             "Projected Total Annual Operating Expense", "Seed Capital Required", "Projection Data Basis", "Business Case Status"]),
            ("36", "Business Case Market Evidence", ["Evidence Business Case", "Evidence Sequence", "Evidence Peer Universe",
                                                     "Evidence Fee Benchmark Study", "Evidence Market Sizing Record",
                                                     "Evidence Flow and Revenue Forecast", "Evidence Conclusion"]),
            ("36", "Product Governance Committee", ["Product Committee Code", "Product Committee Name", "Product Committee Remit",
                                                    "Committee Business Lines", "Parent Product Committee", "Product Committee Quorum",
                                                    "Product Committee Status"]),
            ("36", "Product Committee Membership", ["Membership Committee", "Product Committee Member", "Product Committee Member Role",
                                                    "Voting Member Indicator", "Membership Effective From", "Membership Effective To"]),
            ("36", "Product Committee Meeting", ["Meeting Product Committee", "Product Committee Meeting Date",
                                                 "Product Committee Meeting Sequence", "Written Procedure Indicator", "Quorum Met Indicator"]),
            ("36", "Product Approval Decision", ["Product Approval Decision ID", "Decision Meeting", "Agenda Item Number",
                                                 "Product Decision Type", "Decision Subject Proposal", "Product Decision Outcome",
                                                 "Decision Conditions", "Conditions Due Date", "Decision Rationale"]),
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Product Change Type", "Originating Proposal",
                                                 "Actual Effective Date"]),
            ("36", "Changed Product Scope", ["Scope Change Initiative", "Scope Product", "Scope Share Class", "Change Scope Role"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period",
                                          "Net Fee Revenue", "Revenue Data Basis"]),
            ("11", "Peer Universe", ["Peer Universe ID", "Peer Universe Name", "Universe Type"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Job Title"]),
        ],
        upstream=["DP-004", "DP-014", "DP-008", "DP-012", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for proposals, stage changes and business cases; committee decisions by 7am ET on the business day after the minutes are recorded; realized AUM and revenue after the DP-008 and DP-012 month-end locks",
        history="Every stage row, business case version, meeting and decision kept since the proposal was submitted, including withdrawn and rejected proposals ('Closed - Not Pursued'), for 10 years after the decision",
        classification="Restricted - MNPI",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Each Product Proposal has exactly one Proposal Stage History row with Stage Exited Date empty, and no two stage rows of a proposal overlap in time.",
            "Every Product Approval Decision names a Decision Meeting that exists, and at least one of Decision Subject Proposal, Decision Subject Change Initiative or Decision Subject Review.",
            "Every decision with Decision Conditions has a Conditions Due Date.",
            "Projection figures are published only under names ending '(projection)' and never under the certified AUM or revenue names of DP-008 or DP-012.",
            "Realized AUM and revenue for a launched proposal equal DP-008 Ending Client Assets and DP-012 Net Fee Revenue for the same share classes and period.",
        ],
        notes=("W4 re-point (CW-936, CW-161): 36 Product Proposal.Intended Distribution Markets dropped, no successor (US-only "
               "distribution); Product Business Case.Projected Ongoing Charge re-pointed to its renamed successor Projected Total "
               "Annual Operating Expense (Form N-1A fee table basis); 06 Measure Value.Share Class re-pointed to Dimension Type and "
               "Dimension Key (share class rows, CW-906). No measure read the dropped attribute. "
               "Certified numbers: none owned. Business case figures are projections (CD-303); realized client assets (Ending Client Assets) are read "
               "from DP-008 and realized net fee revenue from DP-012, for share classes that 36 Changed Product Scope links to "
               "the launch. Market evidence references resolve to 11 through DP-014 and to 10; evidence values are not copied. "
               "Boundaries: the product governance committee is a management committee, never a fund board (CD-237); board and "
               "trustee approvals are read from 35 in DP-106. Seed capital approval is 43 (CD-276); Seed Capital Required is a "
               "projection. The go / no-go decision on a launch is a Product Approval Decision on the change initiative and is "
               "shown in DP-107. Not outsourced. "
               "Classification Restricted - MNPI: proposals not yet public are inside information where the parent is listed; a "
               "view without proposal names and projections can be published more widely. PII = Y: proposal sponsors and "
               "committee members are employees (DP-192). "
               "Taxonomy gap: Product Approval Decision has no conditions-met date or condition status, so Conditions Past Due "
               "treats a condition as met only when the subject moved on. Taxonomy gap: Product Business Case has no approval date, "
               "so 'the case approved before launch' is the highest version with Business Case Status current at the decision "
               "meeting. Open SME questions (36 Q1, Q2, Q3, Q9): one or many committees; the system holding proposals; whether "
               "rejected ideas are kept; where seed capital is approved. "
               "Rests on CD-236, CD-237, CD-276, CD-303."
               "WP1 re-point (CW-203): DP-008 no longer publishes the wholesale certified Ending AUM; realized assets of a launched share class are read as the certified Ending Client Assets (06 Client Asset Measures) at Dimension Type share class (CW-011); the 06 Asset Measures Ending AUM input is replaced. The measure name Realized vs Projected AUM % is kept (SM-06 read it; SM-06 retired at WP2, CW-209); no input changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-106": dict(
        definition=("One dated calendar of every approved and in-flight change to the product range (LCHG-): launches, share class "
                    "additions, fee, name, objective and benchmark changes, closes and substitutions, with the products and classes "
                    "in scope, the proposed terms and new class specifications, and each filing, board or trustee approval, "
                    "shareholder notice or vote and regulator approval the change needs against its due date. Fund legal, transfer "
                    "agency, fund accounting, distribution and partner teams plan from it and see which regulatory requirement is "
                    "late. It computes lateness, not filing or approval status: filings come from 35 through DP-184, board "
                    "approvals through DP-182 and shareholder communications from 13 through DP-069 (CD-233, CD-237)."),
        business_questions=[
            "Which changes take effect in the next 30 and 90 days, for which products and share classes, and what changes for each?",
            "Which filings, board approvals, notices and votes are overdue or due in the next 30 days, and which change do they put at risk?",
            "Was every shareholder notice mailed early enough for its minimum notice period, and is every filing effective before the change date?",
            "Which changes slipped from their planned effective date, by how many days and why?",
            "Which proposed fee changes are adverse to shareholders, and which new share classes are not yet set up in 01?",
        ],
        grain=("Product change initiative x regulatory requirement (requirement type x requirement product x requirement country), "
               "with child tables change x scope item (product, share class or model portfolio x scope role), change x proposed "
               "term change, and change x proposed share class specification; the calendar date is Planned Effective Date or "
               "Requirement Due Date"),
        dimensions=["Product change initiative and change type", "Change status", "Product, share class and model portfolio in scope",
                    "Regulatory requirement type", "Requirement country and regulator",
                    "Requirement status", "Product term", "Change sponsor (employee)", "Launch project", "Calendar date"],
        measures=[
            ("Changes Effective in Window", "Count of Product Change Initiatives with Change Status approved or in progress and Planned Effective Date within the next 30 and 90 days, by Product Change Type, with the count of scope products and share classes.",
             [("36", "Product Change Initiative", "Product Change Initiative ID"), ("36", "Product Change Initiative", "Change Status"),
              ("36", "Product Change Initiative", "Planned Effective Date"), ("36", "Product Change Initiative", "Product Change Type"),
              ("36", "Changed Product Scope", "Scope Change Initiative"), ("36", "Changed Product Scope", "Scope Product"),
              ("36", "Changed Product Scope", "Scope Share Class")]),
            ("Requirements Overdue", "Count of Change Regulatory Requirements with Requirement Due Date before the as-of date and Requirement Status other than Satisfied, by Regulatory Requirement Type and Requirement Country.",
             [("36", "Change Regulatory Requirement", "Requirement Due Date"), ("36", "Change Regulatory Requirement", "Requirement Status"),
              ("36", "Change Regulatory Requirement", "Regulatory Requirement Type"), ("36", "Change Regulatory Requirement", "Requirement Country")]),
            ("Requirements Due in 30 Days", "Count of Change Regulatory Requirements with Requirement Status Open or Evidence Pending and Requirement Due Date within the next 30 days.",
             [("36", "Change Regulatory Requirement", "Requirement Due Date"), ("36", "Change Regulatory Requirement", "Requirement Status")]),
            ("Notice Period Shortfall", "For shareholder notice requirements: Minimum Notice Days - (Planned Effective Date - Mail Date of the Communication Distribution of the Satisfying Shareholder Communication); a positive value is a shortfall in days.",
             [("36", "Change Regulatory Requirement", "Minimum Notice Days"), ("36", "Change Regulatory Requirement", "Satisfying Shareholder Communication"),
              ("13", "Communication Distribution", "Distributed Communication"), ("13", "Communication Distribution", "Mail Date"),
              ("36", "Product Change Initiative", "Planned Effective Date")]),
            ("Filings Not Effective Before Change", "Count of fund filing requirements whose Satisfying Filing is missing, has Filing Status other than accepted, or has an Effectiveness Date (485(a), 485(b) and N-14 forms) or Official Filing Date after the Planned Effective Date.",
             [("36", "Change Regulatory Requirement", "Satisfying Filing"), ("35", "Fund Regulatory Filing", "Regulatory Filing ID"),
              ("35", "Fund Regulatory Filing", "Filing Form Type"), ("35", "Fund Regulatory Filing", "Filing Status"),
              ("35", "Fund Regulatory Filing", "Effectiveness Date"), ("35", "Fund Regulatory Filing", "Official Filing Date"),
              ("36", "Product Change Initiative", "Planned Effective Date")]),
            ("Board Approvals Missing", "Count of board or trustee approval requirements with no 35 Resolution Subject Link whose Subject Change Initiative is the change and whose Linked Resolution has an approving Resolution Outcome with Resolution Effective Date on or before the Planned Effective Date.",
             [("36", "Change Regulatory Requirement", "Regulatory Requirement Type"), ("35", "Resolution Subject Link", "Subject Change Initiative"),
              ("35", "Resolution Subject Link", "Linked Resolution"), ("35", "Board Resolution", "Board Resolution ID"),
              ("35", "Board Resolution", "Resolution Outcome"), ("35", "Board Resolution", "Resolution Effective Date"),
              ("36", "Product Change Initiative", "Planned Effective Date")]),
            ("Shareholder Votes Not Passed", "Count of shareholder vote requirements whose Satisfying Proxy Proposal has a Proposal Outcome other than approved, by Proposal Type.",
             [("36", "Change Regulatory Requirement", "Satisfying Proxy Proposal"), ("13", "Proxy Proposal", "Proposal ID"),
              ("13", "Proxy Proposal", "Proposal Outcome"), ("13", "Proxy Proposal", "Proposal Type")]),
            ("Effective Date at Risk", "Y for an open change when any of its requirements is overdue or has a Requirement Due Date after the Planned Effective Date, or a 41 Project scoped to it (Project Scope Link) has Planned End Date after the Planned Effective Date.",
             [("36", "Change Regulatory Requirement", "Requirement Change Initiative"), ("36", "Change Regulatory Requirement", "Requirement Due Date"),
              ("41", "Project Scope Link", "Delivered Change Initiative"), ("41", "Project Scope Link", "Scoping Project"),
              ("41", "Project", "Planned End Date"), ("41", "Project", "Project Status"), "Requirements Overdue"]),
            ("Effective Date Slippage", "Actual Effective Date - Planned Effective Date in days for completed changes; on-time % = changes with slippage <= 0 / completed changes, by Product Change Type.",
             [("36", "Product Change Initiative", "Actual Effective Date"), ("36", "Product Change Initiative", "Planned Effective Date"),
              ("36", "Product Change Initiative", "Product Change Type")]),
            ("Fee Rate Changes (bps)", "(Proposed Term Rate - Current Term Rate) x 10,000 for Proposed Term Changes on fee terms not withdrawn (Term Change Withdrawn Date empty), with the count marked Shareholder Adverse Indicator = Y.",
             [("36", "Proposed Term Change", "Proposed Term Rate"), ("36", "Proposed Term Change", "Current Term Rate"),
              ("36", "Proposed Term Change", "Product Term Name"), ("36", "Proposed Term Change", "Term Change Withdrawn Date"),
              ("36", "Proposed Term Change", "Shareholder Adverse Indicator")]),
            ("New Classes Not Set Up", "Count of Share Class Specifications on changes with an Actual Effective Date whose Created Share Class is empty or resolves to a 01 Share Class with Share Class Status not active.",
             [("36", "Share Class Specification", "Created Share Class"), ("36", "Share Class Specification", "Specification Change Initiative"),
              ("01", "Share Class", "Share Class ID"), ("01", "Share Class", "Share Class Status"),
              ("36", "Product Change Initiative", "Actual Effective Date")]),
        ],
        inputs=[
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Change Title", "Product Change Type", "Change Status",
                                                 "Originating Proposal", "Change Rationale", "Change Sponsor", "Planned Effective Date",
                                                 "Actual Effective Date", "Launch Project Code"]),
            ("36", "Changed Product Scope", ["Scope Change Initiative", "Scope Product", "Scope Share Class", "Scope Model Portfolio",
                                             "Change Scope Role", "Mapped Successor Share Class",
                                             "Scope Added Date", "Scope Removed Date"]),
            ("36", "Proposed Term Change", ["Term Change Initiative", "Term Product", "Term Share Class", "Product Term Name",
                                            "Current Term Rate", "Proposed Term Rate", "Proposed Term Text", "Proposed Benchmark",
                                            "Shareholder Adverse Indicator", "Term Proposed Date", "Term Change Withdrawn Date"]),
            ("36", "Share Class Specification", ["Specification Change Initiative", "Specification Product", "Proposed Class Designation",
                                                 "Proposed Share Class Type", "Proposed Class Currency", "Proposed Class Management Fee Rate",
                                                 "Proposed Class Distribution Fee Rate", "Proposed Class Expense Cap Rate", "Created Share Class"]),
            ("36", "Change Regulatory Requirement", ["Requirement Change Initiative", "Regulatory Requirement Type", "Requirement Product",
                                                     "Requirement Country", "Requirement Regulator", "Minimum Notice Days",
                                                     "Requirement Due Date", "Requirement Status", "Requirement Satisfied Date",
                                                     "Satisfying Filing", "Satisfying Exemptive Relief", "Satisfying Shareholder Communication",
                                                     "Satisfying Proxy Proposal", "Regulator Approval Reference"]),
            ("35", "Fund Regulatory Filing", ["Regulatory Filing ID", "Filing Form Type", "Filer Product", "Filing Due Date",
                                              "Official Filing Date", "Accession Number", "Filing Status", "Effectiveness Date"]),
            ("35", "Resolution Subject Link", ["Linked Resolution", "Resolution Subject Type", "Subject Product", "Subject Change Initiative"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Resolution Type", "Resolution Outcome", "Resolution Effective Date"]),
            ("13", "Shareholder Communication", ["Communication ID", "Communication Type", "Covered Share Classes",
                                                 "Required Delivery Deadline", "Communication Status"]),
            ("13", "Shareholder Notice", ["Notice Type", "Minimum Notice Period (Days)",
                                          "Shareholder Approval Required Indicator"]),
            ("13", "Communication Distribution", ["Distributed Communication", "Mail Date", "Deadline Met Indicator"]),
            ("13", "Proxy Proposal", ["Proposal ID", "Proposal Type", "Proposal Outcome"]),
            ("41", "Project", ["Project ID", "Project Name", "Project Status", "Project Manager", "Planned End Date", "Actual End Date"]),
            ("41", "Project Scope Link", ["Scoping Project", "Delivered Change Initiative", "Scope Link Effective From", "Scope Link Effective To"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status", "Share Class Launch Date"]),
        ],
        upstream=["DP-004", "DP-182", "DP-184", "DP-069", "DP-382", "DP-384", "DP-234", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1, with requirement status re-derived from the DP-182, DP-184 and DP-069 loads of the previous business day",
        history="Every change initiative, scope row, proposed term and requirement kept with its status history (daily snapshots) for 10 years after the change's effective date; withdrawn terms and removed scope rows kept with their dates",
        classification="Restricted - MNPI",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every open change initiative has a Planned Effective Date and at least one Changed Product Scope row with Scope Removed Date empty.",
            "A Change Regulatory Requirement has Requirement Status = Satisfied only when its evidence exists in the source of its evidence group (35 filing, 35 board resolution link, 35 exemptive relief reliance, 13 communication or proxy proposal, or a Regulator Approval Reference) and Requirement Satisfied Date is filled.",
            "Every Satisfying Filing resolves to a 35 Fund Regulatory Filing whose Filer Product equals the Requirement Product.",
            "Every Changed Product Scope with a merging or converting Change Scope Role has a shareholder vote or notice requirement row whenever its Proposed Term Changes include a Shareholder Adverse Indicator = Y term or the 01 fundamental policy changes.",
            "After the Actual Effective Date, the proposed values are not shown as current: the product's current terms are read from DP-004 (CD-236).",
        ],
        notes=("W4 re-point (CW-936, CW-913): 36 Changed Product Scope.COLL Change Classification and 13 Shareholder Notice.Change "
               "Classification dropped, no successor (UK COLL change classes); the DQ rule on fundamental changes reads the "
               "adverse term changes instead, and the COLL dimension goes. Regulatory Requirement Type values re-cut to US "
               "requirements (Form ADV, Form CRS, Advance Fee Change Notice, Advisory Agreement Amendment, State Notice Filing, "
               "FINRA Continuing Membership Application; FCA and UCITS values removed); no measure filters on a literal value. "
               "Requirement Country is kept. "
               "Certified numbers: none. 36 holds proposed values only; after the effective date the 01 record is the master again "
               "and DP-004 shows it (CD-236). Requirement status follows the 36 row rule of five evidence groups: filings from 35 "
               "(CD-233) through DP-184; board and trustee approvals through 35 Resolution Subject Link (CD-237) through DP-182; "
               "exemptive relief through 35 Exemptive Relief Reliance (held as the Satisfying Exemptive Relief key); shareholder "
               "notices and proxies from 13 through DP-069; regulator prior approval mastered on the 36 row. This product computes "
               "lateness and notice-period sufficiency, never filing or approval status. The 41 Project and Project Scope Link are "
               "read through DP-234 Change & Project Portfolio (Wave E4), which replaces the candidate's DP-211: the project "
               "object, not the application inventory, is what the calendar needs; Launch Project Code stays as text until 41 is "
               "populated (CD-239). DP-182, DP-184, DP-069 and DP-234 must not list DP-106 upstream. Change Sponsor and Project "
               "Manager names come from DP-192. Not outsourced. "
               "Classification Restricted - MNPI: changes approved but not announced are inside information where the parent is "
               "listed. PII = Y: change sponsors and project managers are employees. "
               "Taxonomy gap: Change Regulatory Requirement has no requirement owner, so overdue items cannot be routed to a "
               "person. Taxonomy gap: no status history on Change Status; slippage reasons are not recorded beyond Change "
               "Rationale. Open SME questions (36 Q2, Q10, Q11): the system holding change initiatives; which regulator approvals "
               "stay mastered here; whether a waived requirement state is needed. Requirement status values (Open, Evidence "
               "Pending, Satisfied, Not Obtained) are the 36 mapping; outcome values filtered on (approved, accepted) are "
               "drafting assumptions. "
               "Rests on CD-233, CD-236, CD-237, CD-239."
               "WP1 re-point (CW-220): DP-384 (CLA-B, the advice and platform side of the change calendar, specs_w1c_cla_b.py) is added upstream: this product keeps the fund side (CW-161) and shows DP-384's advice and platform changes beside it; DP-384 does not list this product. No measure changes here; the combined calendar measures wait for this product's next re-spec."
               "WP1 re-point (CW-223, C-2 fix pass): DP-382 Client Document & Delivery Record is added upstream beside DP-069: the shareholder notice delivery facts behind Notice Period Shortfall are published by DP-382 (DP-069 reads them as '(from DP-382)' measures). No measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-107": dict(
        definition=("The enterprise readiness plan for each launch, share class addition and conversion: plan dates (seed, first "
                    "NAV, listing), every readiness check by workstream with its owner, due date, status and the set-up record that "
                    "evidences it in the owning domain, and the go / no-go decision. Launch project managers and the product "
                    "committee see which operational workstream will miss the launch date before it does. It references the set-up "
                    "records in 27, 28, 29, 22, 14, 05, 01, 33 and 43 and masters none of them (CD-239), and it is the source of "
                    "the distribution workstream status that DP-058 reads (CD-302)."),
        business_questions=[
            "For each launch, what share of readiness checks is complete in each workstream, and which are overdue?",
            "Which checks are marked complete without an evidence record, or with an evidence record that is not yet ready?",
            "Is the seed capital approved and at least the planned amount, and is the seed portfolio set up?",
            "Was the go / no-go decision taken, with what outcome, and were any checks still open when it was a Go?",
            "Was the first NAV struck on the planned date, and how far did the launch slip?",
        ],
        grain=("Readiness plan version x readiness workstream x readiness check x as-of date (daily), with the change initiative "
               "(launch, share class addition or conversion) and its go / no-go decision as parents"),
        dimensions=["Product change initiative and change type", "Readiness plan version", "Readiness workstream",
                    "Readiness check status", "Check owner (employee)", "Product and share class in scope",
                    "Evidence record type", "Go / no-go outcome", "As-of date"],
        measures=[
            ("Readiness Complete %", "Readiness Checks of the latest Readiness Plan Version with Readiness Check Status complete / all checks of that version, by Readiness Workstream and overall.",
             [("36", "Readiness Check", "Check Readiness Plan"), ("36", "Readiness Check", "Readiness Workstream"),
              ("36", "Readiness Check", "Readiness Check Status"), ("36", "Product Readiness Plan", "Readiness Plan Version")]),
            ("Overdue Checks", "Count of Readiness Checks with Check Due Date before the as-of date and Check Completed Date empty, by workstream and Readiness Check Owner.",
             [("36", "Readiness Check", "Check Due Date"), ("36", "Readiness Check", "Check Completed Date"),
              ("36", "Readiness Check", "Readiness Check Owner"), ("36", "Readiness Check", "Readiness Workstream")]),
            ("Checks Due After First NAV", "Count of open checks whose Check Due Date is after the plan's Planned First NAV Date (a plan that cannot launch on time).",
             [("36", "Readiness Check", "Check Due Date"), ("36", "Product Readiness Plan", "Planned First NAV Date"),
              ("36", "Readiness Check", "Check Completed Date")]),
            ("Complete Without Evidence", "Count of checks with Readiness Check Status complete whose workstream has an owning record but none of the evidence references is filled (Evidence Fund Accounting Book, Evidence Safekeeping Account, Evidence TA Control Check, Evidence Pricing Policy, Evidence Index Use, Evidence Distribution Agreement, Evidence Shelf Placement, Evidence Model Program Placement, Evidence Country Registration, Evidence Listing, Evidence Product Document, Evidence Rule Coding Request). NSCC profile and seed checks are exempt (no owning record).",
             [("36", "Readiness Check", "Readiness Check Status"), ("36", "Readiness Check", "Readiness Workstream"),
              ("36", "Readiness Check", "Evidence Fund Accounting Book"), ("36", "Readiness Check", "Evidence Safekeeping Account"),
              ("36", "Readiness Check", "Evidence TA Control Check"), ("36", "Readiness Check", "Evidence Pricing Policy"),
              ("36", "Readiness Check", "Evidence Index Use"), ("36", "Readiness Check", "Evidence Distribution Agreement"),
              ("36", "Readiness Check", "Evidence Shelf Placement"), ("36", "Readiness Check", "Evidence Model Program Placement"),
              ("36", "Readiness Check", "Evidence Listing"),
              ("36", "Readiness Check", "Evidence Product Document"), ("36", "Readiness Check", "Evidence Rule Coding Request")]),
            ("Evidence Not Ready", "Count of complete checks whose evidence record is not in a ready state: Fund Accounting Book with Book Status not active; Safekeeping Account with Safekeeping Account Status not open; TA Control Check with Control Result not pass.",
             [("36", "Readiness Check", "Evidence Fund Accounting Book"), ("27", "Fund Accounting Book", "Book Code"),
              ("27", "Fund Accounting Book", "Book Status"), ("36", "Readiness Check", "Evidence Safekeeping Account"),
              ("28", "Safekeeping Account", "Safekeeping Account ID"), ("28", "Safekeeping Account", "Safekeeping Account Status"),
              ("36", "Readiness Check", "Evidence TA Control Check"), ("29", "TA Control Check", "TA Control Check ID"),
              ("29", "TA Control Check", "Control Result"), ("36", "Readiness Check", "Readiness Check Status")]),
            ("Seed Funding Gap", "Planned Seed Amount - sum of Approved Commitment Amount of 43 Seed Capital Commitments whose Launch Change Initiative is the change and whose Seed Commitment Status is approved or funded; positive values are a shortfall.",
             [("36", "Product Readiness Plan", "Planned Seed Amount"), ("36", "Product Readiness Plan", "Readiness Change Initiative"),
              ("43", "Seed Capital Commitment", "Launch Change Initiative"), ("43", "Seed Capital Commitment", "Approved Commitment Amount"),
              ("43", "Seed Capital Commitment", "Seed Commitment Status")]),
            ("Seed Portfolio Not Set Up", "Y when the plan's Seed Portfolio is empty or resolves to a DP-140 Portfolio whose Portfolio Status is not active, within 10 business days of the Planned Seed Date.",
             [("36", "Product Readiness Plan", "Seed Portfolio"), ("36", "Product Readiness Plan", "Planned Seed Date"),
              ("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Portfolio Status")]),
            ("Days to Launch and At-Risk Flag", "Planned First NAV Date - as-of date; At-Risk = Y when Days to Launch <= 10 business days and any check is open, or when any check is overdue.",
             [("36", "Product Readiness Plan", "Planned First NAV Date"), "Overdue Checks", "Readiness Complete %"]),
            ("Go / No-Go Outcome", "Product Decision Outcome and Product Committee Meeting Date of the Product Approval Decision with Product Decision Type = Go / No-Go whose Decision Subject Change Initiative is the change; Go With Open Checks = count of checks not complete at that meeting date when the outcome is Go.",
             [("36", "Product Approval Decision", "Product Decision Type"), ("36", "Product Approval Decision", "Decision Subject Change Initiative"),
              ("36", "Product Approval Decision", "Product Decision Outcome"), ("36", "Product Approval Decision", "Decision Meeting"),
              ("36", "Product Committee Meeting", "Product Committee Meeting Date"), ("36", "Readiness Check", "Check Completed Date")]),
            ("First NAV vs Plan (days)", "Valuation Date of the first DP-165 NAV of record (NAV Approval Status = Approved) of the launched fund's book - Planned First NAV Date.",
             [("27", "Fund NAV Calculation", "NAV Book"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "NAV Approval Status"), ("27", "Fund Accounting Book", "Book Fund"),
              ("36", "Product Readiness Plan", "Planned First NAV Date")]),
            ("Launch Slippage (days)", "Actual Effective Date - Planned Effective Date of the change initiative.",
             [("36", "Product Change Initiative", "Actual Effective Date"), ("36", "Product Change Initiative", "Planned Effective Date")]),
            ("Distribution Workstream Complete %", "For DP-058 (CD-302): checks in the registration, shelf, listing and product document workstreams with Readiness Check Status complete / all checks in those workstreams, per change and share class.",
             [("36", "Readiness Check", "Readiness Workstream"), ("36", "Readiness Check", "Readiness Check Status"),
              ("36", "Changed Product Scope", "Scope Share Class")]),
        ],
        inputs=[
            ("36", "Product Readiness Plan", ["Readiness Change Initiative", "Readiness Plan Version", "Planned Seed Date",
                                              "Planned First NAV Date", "Planned Listing Date", "Seed Portfolio", "Planned Seed Amount",
                                              "Overall Readiness Status", "Readiness Plan Owner"]),
            ("36", "Readiness Check", ["Check Readiness Plan", "Readiness Workstream", "Readiness Check Name", "Readiness Check Owner",
                                       "Check Due Date", "Check Completed Date", "Readiness Check Status", "Evidence Fund Accounting Book",
                                       "Evidence Safekeeping Account", "Evidence TA Control Check", "Evidence Pricing Policy",
                                       "Evidence Index Use", "Evidence Distribution Agreement", "Evidence Shelf Placement",
                                       "Evidence Model Program Placement", "Evidence Listing",
                                       "Evidence Product Document", "Evidence Rule Coding Request"]),
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Change Title", "Product Change Type", "Change Status",
                                                 "Planned Effective Date", "Actual Effective Date"]),
            ("36", "Changed Product Scope", ["Scope Change Initiative", "Scope Product", "Scope Share Class", "Change Scope Role"]),
            ("36", "Product Approval Decision", ["Product Approval Decision ID", "Decision Meeting", "Product Decision Type",
                                                 "Decision Subject Change Initiative", "Product Decision Outcome", "Decision Conditions"]),
            ("36", "Product Committee Meeting", ["Meeting Product Committee", "Product Committee Meeting Date"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis", "Book Code", "Book Status"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number", "NAV Approval Status"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Account Provider", "Safekeeping Account Type",
                                           "Safekeeping Account Status", "Account Opened Date"]),
            ("29", "TA Control Check", ["TA Control Check ID", "TA Control Type", "Control Share Class", "Control Business Date", "Control Result"]),
            ("43", "Seed Capital Commitment", ["Seed Capital Commitment ID", "Seed Commitment Type", "Seeded Product", "Seeded Share Class",
                                               "Approved Commitment Amount", "Launch Change Initiative", "Seed Book", "Seed Commitment Status"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Portfolio Status", "Inception Date"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Home Org Unit"]),
        ],
        upstream=["DP-004", "DP-005", "DP-383", "DP-140", "DP-165", "DP-167", "DP-181", "DP-204", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; during the final 10 business days before a planned first NAV date, also refreshed at 1pm ET",
        history="Daily snapshots of every plan version and check kept for 7 years after the launch; superseded plan versions kept",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Product Readiness Plan belongs to a change initiative whose Product Change Type is a launch, share class addition or conversion, and each initiative has exactly one latest Readiness Plan Version.",
            "Every Readiness Check has a Readiness Workstream, a Readiness Check Owner who is an active DP-192 employee, and a Check Due Date on or before the Planned First NAV Date unless flagged by Checks Due After First NAV.",
            "A check is complete only with a Check Completed Date, and, for workstreams with an owning record, at least one evidence reference that resolves to its record in 27, 28, 29, 22, 14, 05, 01 or 33.",
            "Every change initiative with an Actual Effective Date has a Go / No-Go Product Approval Decision dated on or before it.",
            "Distribution Workstream Complete % for a share class equals the readiness score DP-058 publishes for the same share class and date.",
        ],
        notes=("W4 re-point (CW-936, CW-170): 36 Readiness Check.Evidence Country Registration dropped, no successor (01 Country "
               "Registration left with the US-only pass; state notice filings are 35 filings); Complete Without Evidence no longer "
               "reads it. Readiness Workstream values re-cut (Custody to Fund Custody, Platform Onboarding to Intermediary Platform "
               "Onboarding, Registration to State Notice Filing); no measure filters on a literal value. "
               "Certified numbers: none. The first NAV date is read from DP-165's NAV of record and never restruck. Boundary with "
               "DP-058 (CD-302): DP-107 owns readiness up to the go / no-go and the launch date across all workstreams (fund "
               "accounting, custody, TA, pricing, index, rule coding, seed, distribution); DP-058 stays the distribution "
               "go-to-market tracker (trade enablement, approved materials, first sales, days to first sale) and takes its "
               "registration, shelf, listing and document workstream status from Distribution Workstream Complete % here. DP-058 "
               "should add DP-107 upstream; DP-107 must never list DP-058. Readiness checks reference the set-up record and master "
               "none of it (CD-239): fund accounting books and NAV from DP-165, safekeeping accounts from DP-167 (added upstream "
               "beyond the candidate), TA control checks from DP-181 (added), seed commitments from DP-204 (added; 43 is the only "
               "seed master, CD-276), seed portfolio from DP-140, agreements and shelf placements from DP-005, registrations, "
               "listings and documents from DP-004. Pricing policy, index use and rule coding evidence are checked for presence "
               "only; their status is not read. The go / no-go is a Product Approval Decision of type Go / No-Go on the change "
               "initiative; the plan holds no link to it. "
               "Operating model (CD-297): where fund accounting, custody or TA are outsourced the evidence is the provider's set-up "
               "confirmation recorded against the same check, so the grain does not change. "
               "Classification Confidential; a launch that is not yet announced inherits DP-106's Restricted - MNPI handling. PII = "
               "Y: check owners and plan owners are employees. "
               "Taxonomy gap: the NSCC profile and seed capital workstreams have no evidence reference on Readiness Check (no NSCC "
               "set-up record exists in any domain; 43 Seed Capital Commitment points to the change, not the check), so seed "
               "readiness is measured from 43 by the change key. Taxonomy gap: no workstream reference list fixing which "
               "workstreams need which evidence; Complete Without Evidence uses the 36 workstream list descriptions. "
               "Workstream and status values (complete, active, open, pass, approved, funded) are drafting assumptions. "
               "Rests on CD-236, CD-239, CD-276, CD-297, CD-302."
               "WP1 re-point (CW-220): DP-383 (CLA-B, platform shelf, due diligence and product documents, specs_w1c_cla_b.py) is added upstream: it took the go-to-market part of the retired DP-058, which the distribution workstream checks of this product evidence; DP-383 does not list this product. No measure changes."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-108": dict(
        definition=("The execution record of fund reorganizations: mergers and shell reorganizations, mutual fund to ETF "
                    "conversions and liquidations, with the successor share class mapping, structure and tax status, conversion "
                    "route and treatment of ineligible accounts, liquidation dates and final distribution approach, cost bearer, "
                    "and the impact assessment by area (accounts, assets, liquidity). Transfer agency, fund "
                    "accounting, partners and plan services plan the account and position moves from it. It computes no AUM: "
                    "attributed AUM by intermediary comes from DP-008 and fund net assets from DP-165 (CD-292, CD-303)."),
        business_questions=[
            "Which mergers, conversions and liquidations are in flight, on what dates, and is every merging share class mapped to a live successor?",
            "How much attributed AUM, fund net assets and how many accounts and partner platforms does each reorganization touch?",
            "For an ETF conversion, how many accounts cannot hold the ETF and how will they be treated?",
            "Which reorganizations are taxable, who bears the cost, and what is the estimated cost?",
            "Which impact areas are unassessed, and which assessed impacts have no mitigation?",
        ],
        grain=("Product change initiative (merger, shell reorganization, ETF conversion or liquidation) x scope item (product or "
               "share class x scope role, with its mapped successor) x as-of date, with change x impact area as a child table"),
        dimensions=["Product change initiative and change type", "Merging or liquidating product and share class",
                    "Successor share class", "Change scope role", "Reorganization structure and tax status", "ETF conversion route",
                    "Impact area and severity", "Distributor firm", "Partner platform", "As-of date"],
        measures=[
            ("Reorganizations in Flight", "Count of Product Change Initiatives of merger, shell reorganization, ETF conversion or liquidation type with Change Status not complete or withdrawn, by Product Change Type and Planned Effective Date month.",
             [("36", "Product Change Initiative", "Product Change Initiative ID"), ("36", "Product Change Initiative", "Product Change Type"),
              ("36", "Product Change Initiative", "Change Status"), ("36", "Product Change Initiative", "Planned Effective Date")]),
            ("Successor Mapping Completeness %", "Changed Product Scope rows with a merging or converting Change Scope Role whose Mapped Successor Share Class is filled / all such rows (liquidations excluded).",
             [("36", "Changed Product Scope", "Change Scope Role"), ("36", "Changed Product Scope", "Mapped Successor Share Class"),
              ("36", "Changed Product Scope", "Scope Share Class")]),
            ("Successor Class Breaks", "Count of mapped successors whose 01 Share Class has Share Class Status not active, or a Share Class Launch Date after the change's Planned Effective Date, or a Share Class Currency different from the merging class.",
             [("36", "Changed Product Scope", "Mapped Successor Share Class"), ("01", "Share Class", "Share Class ID"),
              ("01", "Share Class", "Share Class Status"), ("01", "Share Class", "Share Class Launch Date"),
              ("01", "Share Class", "Share Class Currency"), ("36", "Product Change Initiative", "Planned Effective Date")]),
            ("Affected Attributed AUM", "Sum of certified Ending Client Assets (CW-011) of the scope share classes at the latest locked month-end, by Distribution Channel (from DP-008); not recomputed.",
             [("06", "Measure Value", "Dimension Type"), ("06", "Measure Value", "Dimension Key"), ("06", "Measure Value", "Period End Date"), ("06", "Measure Value", "Snapshot"),
              ("06", "Client Asset Measures", "Ending Client Assets"), ("06", "Market & Client Dimensions", "Distribution Channel"),
              ("36", "Changed Product Scope", "Scope Share Class")]),
            ("Affected Fund Net Assets", "Fund Net Assets Amount of DP-165's NAV of record for each scope product's fund accounting book on the latest valuation date; certified in DP-165, shown here.",
             [("27", "Fund Accounting Book", "Book Fund"), ("27", "Fund NAV Calculation", "NAV Book"), ("27", "Fund NAV Calculation", "Valuation Date"),
              ("27", "Fund NAV Calculation", "Fund Net Assets Amount"), ("27", "Fund NAV Calculation", "NAV Approval Status"),
              ("36", "Changed Product Scope", "Scope Product")]),
            ("Affected Accounts and Count Difference", "Count of distinct 15 Accounts with an 06 Position in a scope share class with Units Held > 0 on the latest Valuation Date (from DP-007 and DP-093); minus Affected Shareholder Accounts Count of the accounts impact area, flagged when not zero.",
             [("06", "Fund Shareholder Position", "Account"), ("06", "Fund Shareholder Position", "Share Class"), ("06", "Fund Shareholder Position", "Valuation Date"),
              ("06", "Fund Shareholder Position", "Units Held"), ("15", "Account", "Account ID"), ("15", "Account", "Account Status"),
              ("36", "Change Impact Assessment", "Affected Shareholder Accounts Count"), ("36", "Change Impact Assessment", "Impact Area")]),
            ("ETF-Ineligible Accounts", "For ETF conversions: count of affected accounts whose Account Type or Account Registration Type cannot hold an ETF (drafting assumption: direct-at-fund and certain retirement registrations), compared with Accounts Requiring Action Count, by Ineligible Account Treatment.",
             [("15", "Account", "Account Type"), ("15", "Account", "Account Registration Type"),
              ("36", "ETF Conversion Detail", "Accounts Requiring Action Count"), ("36", "ETF Conversion Detail", "Ineligible Account Treatment"),
              ("36", "ETF Conversion Detail", "ETF Conversion Route"), "Affected Accounts and Count Difference"]),
            ("Partner Platforms Affected", "Count of distinct Shelf Partners with a Shelf Placement of a scope share class whose Placement Status is approved on the as-of date (from DP-005).",
             [("05", "Shelf Placement", "Shelf Partner"), ("05", "Shelf Placement", "Placed Share Class"),
              ("05", "Shelf Placement", "Placement Status"), ("05", "Shelf Placement", "Placement Status Effective From"),
              ("05", "Shelf Placement", "Placement Status Effective To")]),
            ("Taxable Reorganizations", "Count of reorganizations with Tax-Free Reorganization Indicator = N, and their Affected Attributed AUM.",
             [("36", "Fund Reorganization Detail", "Tax-Free Reorganization Indicator"), ("36", "Fund Reorganization Detail", "Reorganization Structure"),
              "Affected Attributed AUM"]),
            ("Estimated Cost by Bearer", "Sum of Estimated Reorganization Cost by Reorganization Cost Bearer, plus Estimated Impact Cost across the change's impact areas; liquidation cost by Liquidation Cost Bearer.",
             [("36", "Fund Reorganization Detail", "Estimated Reorganization Cost"), ("36", "Fund Reorganization Detail", "Reorganization Cost Bearer"),
              ("36", "Change Impact Assessment", "Estimated Impact Cost"), ("36", "Liquidation Detail", "Liquidation Cost Bearer")]),
            ("Impact Areas Unassessed", "Count of required impact areas (accounts, assets, liquidity) with no Change Impact Assessment row for the change, plus liquidity rows with Liquidity Evidence Profile empty.",
             [("36", "Change Impact Assessment", "Impact Change Initiative"), ("36", "Change Impact Assessment", "Impact Area"),
              ("36", "Change Impact Assessment", "Liquidity Evidence Profile")]),
            ("Liquidation Timeline Breaks", "Count of liquidations where Planned Close to New Investors Date > Planned Last Purchase Date, or Planned Last Purchase Date > Planned Effective Date, or Retirement Account Default Treatment is empty while scope classes are held in retirement registrations.",
             [("36", "Liquidation Detail", "Planned Close to New Investors Date"), ("36", "Liquidation Detail", "Planned Last Purchase Date"),
              ("36", "Liquidation Detail", "Retirement Account Default Treatment"), ("36", "Product Change Initiative", "Planned Effective Date"),
              ("15", "Account", "Account Registration Type")]),
        ],
        inputs=[
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Change Title", "Product Change Type", "Change Status",
                                                 "Planned Effective Date", "Actual Effective Date"]),
            ("36", "Changed Product Scope", ["Scope Change Initiative", "Scope Product", "Scope Share Class", "Change Scope Role",
                                             "Mapped Successor Share Class", "Scope Removed Date"]),
            ("36", "Fund Reorganization Detail", ["Reorganization Structure", "Tax-Free Reorganization Indicator", "Exchange Valuation Date",
                                                  "Reorganization Cost Bearer", "Estimated Reorganization Cost"]),
            ("36", "ETF Conversion Detail", ["ETF Conversion Route", "Ineligible Account Treatment", "Accounts Requiring Action Count",
                                             "Cash in Lieu of Fractional Shares Indicator", "Proposed Listing Exchange"]),
            ("36", "Liquidation Detail", ["Planned Close to New Investors Date", "Planned Last Purchase Date", "Final Distribution Approach",
                                          "Retirement Account Default Treatment", "Liquidation Cost Bearer"]),
            ("36", "Change Impact Assessment", ["Impact Change Initiative", "Impact Area", "Impact Severity", "Affected Shareholder Accounts Count",
                                                "Affected AUM", "Liquidity Evidence Profile", "Estimated Impact Cost",
                                                "Impact Description", "Impact Mitigation",
                                                "Impact Assessed By", "Impact Assessment Date"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Currency", "Share Class Launch Date", "Share Class Status"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
            ("06", "Market & Client Dimensions", ["Distribution Channel"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Account", "Share Class", "Valuation Date", "Units Held"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Book Code", "Book Status"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "Fund Net Assets Amount", "NAV Approval Status"]),
            ("05", "Shelf Placement", ["Shelf Placement ID", "Shelf Partner", "Placed Share Class", "Placement Status",
                                       "Placement Status Effective From", "Placement Status Effective To"]),
        ],
        upstream=["DP-004", "DP-008", "DP-007", "DP-093", "DP-005", "DP-165", "DP-001", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; affected attributed AUM after each DP-008 month-end lock and fund net assets from the latest DP-165 NAV of record",
        history="Daily snapshots of every reorganization kept from approval to 7 years after the effective date; impact assessments kept by assessment date",
        classification="Restricted - MNPI",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every merger, shell reorganization and ETF conversion change has exactly one Fund Reorganization Detail or ETF Conversion Detail row, and every liquidation exactly one Liquidation Detail row.",
            "Every scope row with a merging or converting Change Scope Role has a Mapped Successor Share Class before the change's Change Status moves to approved.",
            "Affected Attributed AUM equals the DP-008 locked Ending Client Assets for the same share classes and month-end, and Affected Fund Net Assets equals the DP-165 NAV of record for the same book and valuation date.",
            "Every change has a Change Impact Assessment row for each required impact area before its Planned Effective Date minus 30 days.",
            "For ETF conversions, Accounts Requiring Action Count differs from the counted ETF-ineligible accounts by no more than 1% or is explained in Impact Description.",
        ],
        notes=("W4 re-point (CW-151, CW-906, CW-936): 06 Position re-typed by name to Fund Shareholder Position (same columns); "
               "06 Measure Value.Share Class re-pointed to Dimension Type and Dimension Key (share class rows); 36 Changed Product "
               "Scope.COLL Change Classification and Change Impact Assessment.Foreseeable Harm Identified Indicator dropped, no "
               "successor (UK COLL and Consumer Duty), with the measure Foreseeable Harm Without Mitigation. 05 Shelf Placement "
               "resolves unchanged in the restored 05 (CW-905). "
               "Certified numbers: none owned. Affected AUM on the impact assessment is a reference to 06; this product shows "
               "attributed AUM by intermediary from DP-008 and fund net assets from DP-165, and computes neither (CD-292, CD-303). "
               "Accounts affected come from DP-093 (15) and positions from DP-007 (06); Account Name and External Account Number "
               "are not read. Liquidity evidence is a reference to the 31 fund liquidity profile (DP-155); only its presence is "
               "checked. Resulting transactions are 29 and 06, and accounts 15 (CD-239); 36 holds planned dates, and the effected "
               "closes and successor status are 01's (CD-236). Plan menus the firm recordkeeps (16) need the Retirement Account "
               "Default Treatment, so FN-19 supports. Not outsourced; TA and fund accounting execute the moves under their own "
               "operating model. "
               "Classification Restricted - MNPI: reorganizations are inside information until announced where the parent is "
               "listed. PII = Y: Impact Assessed By is an employee; account rows are counted, never published by holder. "
               "Taxonomy gap: Fund Reorganization Detail holds one exchange valuation date and cost bearer per change, not per "
               "merging fund (36 SME question 12). Taxonomy gap: no attribute marks which account registrations can hold an ETF, so "
               "ETF-Ineligible Accounts uses an assumed list of Account Type and Account Registration Type values. Taxonomy gap: "
               "no actual reorganization cost (only estimates), so cost is not reconciled to 10 or 19 (36 SME question 8). Open SME "
               "questions (36 Q5, Q8, Q12): conversion route and ineligible accounts; cost bearer recording; per-fund dates. "
               "Rests on CD-236, CD-239, CD-292, CD-303."
               "WP1 re-point (CW-203): DP-008 dropped the wholesale Ending AUM by distributor firm and the 'Distributor firm / office / team / advisor' dimension; Affected Attributed AUM now reads the certified Ending Client Assets (06 Client Asset Measures, CW-011) by Distribution Channel, and the 06 Distributor Hierarchy input is replaced by 06 Market & Client Dimensions Distribution Channel. The intermediary-firm split is lost (the 06 Distributor Hierarchy is no longer published by a live 06 product); the partner platforms touched stay countable from DP-005. Measure name kept (SM-06 read it; SM-06 retired at WP2, CW-209)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-109 re-specified at WP1 in specs_w1c_cla_b.py
}
