"""Data product specifications: Wave E3 Transfer Agency Operations (29) and Fund Governance & Regulatory Reporting (35),
DP-177 to DP-186. Consumer-aligned products of the Fund Operations brief
(00_Program/Expansion/Product_Briefs/Fund_Operations.md). See CONTRACT.md."""


def _u(dd, obj, *attrs):
    """Uses helper: [(dd, obj, attr), ...] for the attributes of one input object."""
    return [(dd, obj, a) for a in attrs]


SPECS = {
    # ---------------------------------------------------------------------------------------------------------------
    # 29 Transfer Agency Operations
    # ---------------------------------------------------------------------------------------------------------------
    "DP-177": dict(
        definition=("Every fund order as the transfer agent received and processed it: receipt and TA timestamps, the "
                    "cut-off result and trade date assigned, routing and intermediary codes as delivered, order events, "
                    "exceptions and blocking account restrictions, exchange legs, and as-of corrections with their "
                    "dilution, by dealing route and interface session, against the dealing calendar and its processing "
                    "events. Transfer agency uses it to work exceptions and as-of requests, and compliance uses its "
                    "cut-off and as-of evidence for Rule 22c-1 forward pricing. It holds the order before execution; "
                    "executed amounts and flows stay in DP-006 and DP-008, and the product certifies no number."),
        business_questions=[
            "Were all orders priced at the NAV next computed after receipt, and which orders received after the cut-off got the same day's trade date?",
            "Which order exceptions are open, how old are they, which blocking account restrictions caused them, and which moved the trade date?",
            "How many as-of orders were processed this month, why, what dilution did they cause, and which exceeded the threshold or lack an approver?",
            "Does each intermediary interface session balance to the orders loaded from it, by dealing route and cycle?",
            "What share of orders flowed straight through without an exception, by dealing route, intermediary and processing provider?",
            "Which processed orders have not yet produced a 06 transaction for attribution?",
        ],
        grain=("Fund order (FNDO-) x order version as processed, with child grains fund order x order event type x event "
               "timestamp and fund order x order exception type x exception raised timestamp; fallback grain order "
               "interface session (dealing route x business date x interface cycle) where only batch totals are received"),
        dimensions=["Trade date assigned and receipt date", "Share class and fund (DP-004)", "Fund order type",
                    "Dealing route and interface cycle", "Receiving party and processing provider (DP-240)",
                    "Resolved dealer (DP-001)", "Order origin", "Cut-off result", "Order exception type",
                    "As-of reason and dilution cost bearer", "Dealing calendar and processing calendar event (DP-013)"],
        measures=[
            ("Orders Received",
             "Count of Fund Order ID and sum of Estimated Order Value by Trade Date Assigned, Fund Order Type, Dealing Route and Processing Provider.",
             _u("29", "Fund Order", "Fund Order ID", "Estimated Order Value", "Trade Date Assigned", "Fund Order Type", "Processing Provider")
             + _u("29", "Order Routing Detail", "Dealing Route")),
            ("Orders After Cut-Off",
             "Count of orders whose Cut-Off Result is after the cut-off, by Dealing Route and Receiving Party; these must carry the next dealing day as Trade Date Assigned.",
             _u("29", "Fund Order", "Fund Order ID", "Cut-Off Result", "Receiving Party") + _u("29", "Order Routing Detail", "Dealing Route")),
            ("Forward Pricing Breaks",
             "Count of orders whose Cut-Off Result is before the cut-off but whose Order Received Timestamp (TA Received Timestamp where the Receiving Party is not the fund's designated agent) is later than the Dealing Cut-off Time in Cut-off Time Zone on Trade Date Assigned, or later than the Revised Cut-Off Time where a TA Processing Calendar Event for the share class and date revises it. Each break is Rule 22c-1 evidence to investigate.",
             _u("29", "Fund Order", "Cut-Off Result", "Order Received Timestamp", "TA Received Timestamp", "Receiving Party", "Trade Date Assigned", "Order Share Class")
             + _u("01", "Dealing Terms", "Dealing Cut-off Time", "Cut-off Time Zone")
             + _u("29", "TA Processing Calendar Event", "Event Share Class", "Event Business Date", "Revised Cut-Off Time")),
            ("Trade Date Assignment Breaks",
             "Count of orders whose Trade Date Assigned is not a business day (Day Type) of the share class's Dealing Calendar, or is not the dealing day on or after receipt that the Cut-Off Result implies.",
             _u("29", "Fund Order", "Trade Date Assigned", "Cut-Off Result", "Order Received Timestamp")
             + _u("01", "Dealing Terms", "Dealing Calendar") + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
            ("Open Order Exceptions",
             "Count of Order Exceptions with Exception Status open at the as-of time, by Order Exception Type, with age in hours from Exception Raised Timestamp (buckets: under 4, 4 to 24, over 24); count of those with a Blocking Account Restriction.",
             _u("29", "Order Exception", "Exception Fund Order", "Order Exception Type", "Exception Raised Timestamp", "Exception Status", "Blocking Account Restriction")),
            ("Exception Resolution Time",
             "Median and 90th percentile of Exception Resolved Timestamp - Exception Raised Timestamp in hours for exceptions resolved in the period, by Order Exception Type; share of resolved exceptions with Trade Date Moved Indicator = Y.",
             _u("29", "Order Exception", "Order Exception Type", "Exception Raised Timestamp", "Exception Resolved Timestamp", "Trade Date Moved Indicator")),
            ("Straight-Through Processing %",
             "Orders with no Order Exception / all orders received, by Dealing Route, Resolved Dealer and Processing Provider.",
             _u("29", "Fund Order", "Fund Order ID", "Processing Provider") + _u("29", "Order Exception", "Exception Fund Order")
             + _u("29", "Order Routing Detail", "Dealing Route", "Resolved Dealer")),
            ("As-Of Orders and Dilution",
             "Count of orders with an As-Of Order Detail and sum of Dilution Amount, by As-Of Reason and Dilution Cost Bearer, for As-Of Trade Date in the period; count with Dilution Threshold Exceeded Indicator = Y.",
             _u("29", "As-Of Order Detail", "As-Of Trade Date", "As-Of Reason", "Dilution Amount", "Dilution Cost Bearer", "Dilution Threshold Exceeded Indicator")),
            ("As-Of Dilution % of Class Net Assets",
             "Sum of Dilution Amount for the share class and As-Of Trade Date / Class Net Assets of the share class at the NAV of record for that valuation date (from DP-165, Share Class NAV whose Parent NAV Calculation is the NAV of record).",
             _u("29", "As-Of Order Detail", "As-Of Trade Date", "Dilution Amount") + _u("29", "Fund Order", "Order Share Class")
             + _u("27", "Share Class NAV", "NAV Share Class", "Parent NAV Calculation", "Class Net Assets Amount")
             + ["As-Of Orders and Dilution"]),
            ("Unapproved or Unexplained As-Of Orders",
             "Count of as-of orders with no As-Of Approver, or with As-Of Reason requiring a cause record but neither Related NAV Error Case nor Related Servicing Error filled.",
             _u("29", "As-Of Order Detail", "As-Of Approver", "As-Of Reason", "Related NAV Error Case", "Related Servicing Error", "Original Fund Order")),
            ("Interface Session Imbalance",
             "For each Order Interface Session: Orders Received Count - count of Fund Orders whose Receiving Interface Session is the Interface Session Key; sessions with a non-zero difference or Session Balance Status not balanced, by Session Dealing Route and Session Counterparty.",
             _u("29", "Order Interface Session", "Interface Session Key", "Orders Received Count", "Session Balance Status", "Session Dealing Route", "Session Counterparty", "Session Business Date")
             + _u("29", "Order Routing Detail", "Receiving Interface Session")),
            ("Unmatched Exchange Legs",
             "Count of Exchange Links whose Exchange Out Order and Exchange In Order have different Trade Date Assigned, or where one leg has Fund Order Status rejected or canceled and the other does not.",
             _u("29", "Exchange Link", "Exchange Out Order", "Exchange In Order") + _u("29", "Fund Order", "Trade Date Assigned", "Fund Order Status")),
            ("Processed Orders Without Transaction",
             "Count of orders with Fund Order Status processed and no Resulting Transaction (the 29 Register Transaction posted for the order) by the end of the business day after Trade Date Assigned; the hand-off gap to the 29 register posting.",
             _u("29", "Fund Order", "Fund Order Status", "Resulting Transaction", "Trade Date Assigned")),
        ],
        inputs=[
            ("29", "Fund Order", ["Fund Order ID", "Fund Order Type", "Order Share Class", "Order Account", "Requested Amount",
                                  "Requested Units", "Full Liquidation Indicator", "Order Currency", "Order Received Timestamp",
                                  "TA Received Timestamp", "Receiving Party", "Cut-Off Result", "Trade Date Assigned",
                                  "Fund Order Status", "Order Origin", "Originating Service Request",
                                  "Source Plan Contribution Batch", "Resulting Transaction", "Estimated Order Value",
                                  "Processing Provider"]),
            ("29", "Order Routing Detail", ["Dealing Route", "Order Message Standard", "Fund/SERV Control Number",
                                            "Dealer Number As Delivered", "Representative Number As Delivered",
                                            "Resolved Dealer", "Resolved Representative", "Receiving Interface Session"]),
            ("29", "As-Of Order Detail", ["Original Fund Order", "As-Of Trade Date", "As-Of Reason", "Related NAV Error Case",
                                          "Related Servicing Error", "Dilution Amount", "Dilution Threshold Exceeded Indicator",
                                          "Dilution Cost Bearer", "As-Of Approver"]),
            ("29", "Order Event", ["Event Fund Order", "Order Event Type", "Event Timestamp", "Event Performed By"]),
            ("29", "Order Exception", ["Exception Fund Order", "Order Exception Type", "Exception Raised Timestamp",
                                       "Blocking Account Restriction", "Exception Status", "Exception Resolved Timestamp",
                                       "Trade Date Moved Indicator"]),
            ("29", "Exchange Link", ["Exchange Out Order", "Exchange In Order", "Switch Order Reference"]),
            ("29", "Order Interface Session", ["Interface Session Key", "Session Dealing Route", "Session Business Date",
                                               "Interface Cycle", "Session Counterparty", "Orders Received Count",
                                               "Session Control Total", "Session Balance Status"]),
            ("29", "TA Processing Calendar Event", ["Governing Dealing Calendar", "Event Share Class", "Event Business Date",
                                                    "Processing Calendar Event Type", "Revised Cut-Off Time",
                                                    "Orders Affected Count"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("01", "Dealing Terms", ["Dealing Frequency", "Dealing Cut-off Time", "Cut-off Time Zone", "Pricing Basis",
                                     "Dealing Calendar"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation",
                                       "Class Net Assets Amount"]),
        ],
        upstream=["DP-580", "DP-093", "DP-004", "DP-079", "DP-001", "DP-006", "DP-013", "DP-165", "DP-192", "DP-240"],
        refresh="Intraday",
        timeliness="Orders, events and exceptions within 15 minutes of TA receipt during the dealing day; cut-off and as-of evidence complete by 7am ET on T+1",
        history="Every order, event and exception kept for at least 6 years after the trade date (transfer agent and Rule 22c-1 record retention, to confirm against the client's schedule); daily snapshots of open exceptions kept 13 months",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "API"],
        dq_rules=[
            "Every fund order has Order Received Timestamp, Cut-Off Result and Trade Date Assigned before it reaches Fund Order Status processed.",
            "Trade Date Assigned is a business day of the share class's Dealing Calendar.",
            "Every as-of order has an Original Fund Order, an As-Of Reason and an As-Of Approver before it is processed.",
            "The count of fund orders loaded from an Order Interface Session equals its Orders Received Count when Session Balance Status is balanced.",
            "Every Exchange Link references two existing fund orders, one outgoing and one incoming leg.",
            "An Order Exception with Exception Status resolved has an Exception Resolved Timestamp not earlier than its Exception Raised Timestamp.",
        ],
        notes=("W3 re-point (CW-122, CW-123, CW-929): Fund Order.Resulting Transaction is re-typed to the 29 Register Transaction "
               "(the fund share register is 29; 06 reads it as a view), so the processed-without-transaction measure is the gap to "
               "the 29 posting; Order Account definition re-cut (15 account or 29 register account). Dealing Route and Session "
               "Dealing Route values re-cut to the US NSCC services (Affiliated Broker-Dealer Omnibus added; SWIFT_DIRECT removed "
               "by ruling); no measure filters on a literal value, so no input changed. "
               "Boundary with DP-006 (CD-199): the executed price, units and amounts and the attribution of the transaction "
               "stay 06 and DP-006; this product holds the order before execution and its processing facts, and flows are "
               "never counted from it (Estimated Order Value is an operational estimate, never a flow). Resolved Dealer and "
               "Resolved Representative are Derived copies of 06 identity resolution, published as keys only. Plan-level "
               "orders from firm-recordkept plans link to DP-095 batches through Source Plan Contribution Batch. DP-169 reads "
               "the as-of and order facts from this product; DP-084 keeps the 29 Shareholder Information Request (CD-336). "
               "Operating model (CD-297, CD-331): an outsourced TA is the base case. In house, the grain is the TA "
               "platform's order record. If the TA is outsourced, the grain is the same order record received from the TA "
               "(Processing Provider names it) and the product is the firm's evidence of the TA's processing; if the firm "
               "receives only batch totals for some routes (29 SME question 2), those rows fall back to the Order "
               "Interface Session grain and Orders After Cut-Off, Forward Pricing Breaks, Straight-Through Processing % and "
               "the as-of measures are marked not available for them. "
               "Account and representative fields are personal data (PII = Y); publish an account-free aggregate view by "
               "route, intermediary and share class for wide use. "
               "Taxonomy gap: 01 Dealing Terms holds one Dealing Cut-off Time per product; intermediary-specific or "
               "designated-agent cut-offs (for example Fund/SERV cycle deadlines) are not modeled, so Forward Pricing Breaks "
               "uses the fund cut-off and the TA Processing Calendar Event revision only. "
               "Taxonomy gap: no attribute marks whether the Receiving Party is a designated agent of the fund for Rule "
               "22c-1 receipt; the rule is applied from a reference list of designated intermediaries kept with DP-005 "
               "agreements until one is added. "
               "Open SME questions: 29 questions 1, 2, 12 and 14. Rests on CD-199, CD-297, CD-331."
               "WP1 re-point (CW-260, CW-007): DP-580 Fund Share Register & Postings (WP1F) is added upstream: the 29 Fund Order and Brokerage Omnibus Order Detail facts behind the cut-off, forward-pricing and order-exception measures are published by DP-580 (the register book) and read 'from DP-580'; this product keeps the cut-off control, forward-pricing tests and fund-order processing exceptions and redefines no DP-580 fact (F3 hand-off note). The 29 inputs and measures are unchanged; the FOP+CORP re-spec items (Order Origin values, DP-079 and DP-006 upstreams) are not applied here, as DP-177 is not re-specified at WP1.")),

    "DP-178": dict(
        definition=("Settlement of every fund order and AP cash leg with intermediaries: obligations by contractual "
                    "settlement date and method, net batches per settling party, settlement date and currency, the cash "
                    "movements into and out of the fund cash accounts with their screening result, and settlement "
                    "exceptions such as shortfalls, returns and cancellations for non-payment. Transfer agency and "
                    "treasury use it to fund redemptions and collect purchases on time and to chase late intermediaries. "
                    "Fund cash accounts are the 28 safekeeping accounts published by DP-167; the product certifies no "
                    "number and is never a source of flows."),
        business_questions=[
            "Which settlement obligations and net batches are due today and tomorrow, by settling party, currency and method, and how much cash moves each way?",
            "Which intermediaries settled late or short in the last 90 days, by how many days and how much?",
            "Does every net batch tie to its obligations and to the cash actually received or paid?",
            "Which payments are held by screening, and which cash moved through an account that is not an open fund cash account?",
            "How many orders were canceled for non-payment, and what loss or interest claim did that cause?",
        ],
        grain=("Settlement obligation (fund order or AP order x obligation sequence), with intermediary settlement batch "
               "(settling party x settlement date x currency x data basis), cash movement and settlement exception "
               "(obligation or batch x exception type x detected date) as companion facts; batch grain only where the "
               "obligation level is not received"),
        dimensions=["Contractual settlement date", "Settling party (DP-001, DP-240)", "Settlement method and payment method",
                    "Flow direction", "Currency", "Share class and fund (DP-004)", "Fund cash account and custodian (DP-167)",
                    "Batch data basis (estimated / final)", "Settlement exception type", "Processing provider"],
        measures=[
            ("Obligations Due",
             "Count of Settlement Obligations and sum of Obligation Amount by Contractual Settlement Date, Obligation Flow Direction, Settling Party, Order Settlement Method and Batch Currency.",
             _u("29", "Settlement Obligation", "Settlement Obligation ID", "Obligation Amount", "Contractual Settlement Date",
                "Obligation Flow Direction", "Settling Party", "Order Settlement Method", "Obligation Settlement Batch")
             + _u("29", "Intermediary Settlement Batch", "Batch Currency")),
            ("On-Time Settlement %",
             "Obligations with Actual Settlement Date on or before Contractual Settlement Date / obligations whose Contractual Settlement Date has passed, by Settling Party and Order Settlement Method.",
             _u("29", "Settlement Obligation", "Actual Settlement Date", "Contractual Settlement Date", "Settling Party", "Order Settlement Method")),
            ("Late Settlement Days",
             "Business days (Calendar Date, Day Type) from Contractual Settlement Date to Actual Settlement Date, or to the as-of date for unsettled obligations, per late obligation; mean and maximum by Settling Party.",
             _u("29", "Settlement Obligation", "Contractual Settlement Date", "Actual Settlement Date", "Obligation Settlement Status", "Settling Party")
             + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
            ("Contractual Date Breaks",
             "Count of fund-order obligations whose Contractual Settlement Date differs from Trade Date Assigned plus the share class's Subscription Settlement Period (inflows) or Redemption Settlement Period (outflows) in business days.",
             _u("29", "Settlement Obligation", "Obligation Fund Order", "Contractual Settlement Date", "Obligation Flow Direction")
             + _u("29", "Fund Order", "Trade Date Assigned", "Order Share Class")
             + _u("01", "Dealing Terms", "Subscription Settlement Period", "Redemption Settlement Period")
             + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
            ("Batch Tie-Out",
             "Per batch: Net Settlement Amount - (Gross Inflow Amount - Gross Outflow Amount) signed by Net Settlement Direction; Gross Inflow Amount and Gross Outflow Amount - the sum of Obligation Amount of the batch's obligations by direction; Batch Obligation Count - count of obligations; any non-zero difference is flagged.",
             _u("29", "Intermediary Settlement Batch", "Settlement Batch ID", "Net Settlement Amount", "Gross Inflow Amount",
                "Gross Outflow Amount", "Net Settlement Direction", "Batch Obligation Count")
             + _u("29", "Settlement Obligation", "Obligation Settlement Batch", "Obligation Amount", "Obligation Flow Direction")),
            ("Unmatched Cash",
             "Batch cash difference: Net Settlement Amount - sum of Payment Amount of Cash Movements with Settled Batch = the batch and Payment Settlement Status settled; plus count and sum of Cash Movements with neither Settled Batch nor Settled Obligation filled.",
             _u("29", "Intermediary Settlement Batch", "Settlement Batch ID", "Net Settlement Amount")
             + _u("29", "Cash Movement", "Cash Movement ID", "Settled Batch", "Settled Obligation", "Payment Amount", "Payment Settlement Status")),
            ("Open Settlement Exceptions",
             "Count of Settlement Exceptions with Settlement Exception Status open and sum of Shortfall Amount, by Settlement Exception Type and settling party, with age in days from Exception Detected Date.",
             _u("29", "Settlement Exception", "Settlement Exception Type", "Settlement Exception Status", "Shortfall Amount",
                "Exception Detected Date", "Exception Settlement Obligation", "Exception Settlement Batch")),
            ("Orders Canceled for Non-Payment",
             "Count of Settlement Exceptions with Order Canceled for Non-Payment Indicator = Y in the period, by settling party and Return Reason Code.",
             _u("29", "Settlement Exception", "Order Canceled for Non-Payment Indicator", "Return Reason Code", "Exception Settlement Obligation")),
            ("Payments Held by Screening",
             "Count and sum of Payment Amount of Cash Movements whose Payment Screening Result is not cleared and Payment Settlement Status is not settled, by Payment Flow Direction.",
             _u("29", "Cash Movement", "Payment Screening Result", "Payment Settlement Status", "Payment Amount", "Payment Flow Direction")),
            ("Cash Through Non-Fund Accounts",
             "Count of Cash Movements whose Fund Cash Account is not a Safekeeping Account with Safekeeping Account Status open on the Payment Value Date.",
             _u("29", "Cash Movement", "Fund Cash Account", "Payment Value Date")
             + _u("28", "Safekeeping Account", "Safekeeping Account ID", "Safekeeping Account Status", "Account Opened Date", "Account Closed Date")),
            ("Late Payer Ranking",
             "Rank of settling parties over the trailing 90 days by count of late obligations, then by sum of Shortfall Amount on open and closed exceptions.",
             _u("29", "Settlement Obligation", "Settling Party") + _u("29", "Settlement Exception", "Shortfall Amount")
             + ["On-Time Settlement %", "Late Settlement Days"]),
        ],
        inputs=[
            ("29", "Settlement Obligation", ["Settlement Obligation ID", "Obligation Fund Order", "Obligation AP Order",
                                             "Obligation Flow Direction", "Obligation Amount", "Contractual Settlement Date",
                                             "Order Settlement Method", "Settling Party", "Obligation Settlement Batch",
                                             "Obligation Settlement Status", "Actual Settlement Date"]),
            ("29", "Intermediary Settlement Batch", ["Settlement Batch ID", "Batch Settling Party", "Batch Settlement Date",
                                                     "Batch Currency", "Batch Data Basis", "Gross Inflow Amount",
                                                     "Gross Outflow Amount", "Net Settlement Amount", "Net Settlement Direction",
                                                     "Batch Settlement Method", "Batch Obligation Count",
                                                     "Batch Settlement Status"]),
            ("29", "Cash Movement", ["Cash Movement ID", "Payment Reference", "Settled Batch", "Settled Obligation",
                                     "Payment Flow Direction", "Payment Amount", "Payment Currency", "Payment Value Date",
                                     "Payment Method", "Fund Cash Account", "Client Money Movement",
                                     "Payment Settlement Status", "Payment Screening Result"]),
            ("29", "Settlement Exception", ["Exception Settlement Obligation", "Exception Settlement Batch",
                                            "Settlement Exception Type", "Exception Detected Date", "Shortfall Amount",
                                            "Return Reason Code", "Order Canceled for Non-Payment Indicator",
                                            "Settlement Exception Status"]),
            ("29", "Fund Order", ["Fund Order ID", "Order Share Class", "Trade Date Assigned", "Processing Provider"]),
            ("28", "Safekeeping Account", ["Safekeeping Account ID", "Account Provider", "Safekeeping Account Type",
                                           "Account Currency", "Safekeeping Account Status", "Account Opened Date",
                                           "Account Closed Date"]),
            ("01", "Dealing Terms", ["Subscription Settlement Period", "Redemption Settlement Period"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
        ],
        upstream=["DP-580", "DP-177", "DP-167", "DP-093", "DP-001", "DP-004", "DP-013", "DP-240"],
        refresh="Daily",
        timeliness="Obligations and estimated batches for the settlement date by 8am ET; final batches, cash and exceptions by 7am ET on the next business day",
        history="Every obligation, batch, cash movement and exception kept at least 6 years after settlement (to confirm against the client's retention schedule); daily snapshots of open exceptions kept 13 months",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Settlement Obligation references exactly one of Obligation Fund Order and Obligation AP Order.",
            "For each batch, Net Settlement Amount equals Gross Inflow Amount - Gross Outflow Amount in the direction stated by Net Settlement Direction.",
            "A Settlement Obligation with Obligation Settlement Status settled has an Actual Settlement Date.",
            "Every Cash Movement with Payment Settlement Status settled names a Fund Cash Account and either a Settled Batch or a Settled Obligation.",
            "A Settlement Exception references exactly one of Exception Settlement Obligation and Exception Settlement Batch.",
        ],
        notes=("W3 re-point (CW-122, CW-929): 29 Cash Movement.Investor Bank Instruction dropped (the investor's bank instruction "
               "is the 50 money movement's), and the cash movement now names its Client Money Movement (50), read in its place; "
               "Obligation Amount is no longer a Derived copy of 06 (29 masters the register and its settlement); Order "
               "Settlement Method values re-cut (NSCC Net Settlement, Affiliated Broker-Dealer Omnibus Settlement, Bank Transfer / "
               "Wire, Direct Investor Payment); no measure filters on a literal value. "
               "Obligation Amount is mastered in 29 for fund orders and AP cash legs (CD-183); flows are never counted from it. Fund cash accounts are 28 safekeeping accounts "
               "(DP-167); corporate bank accounts are 43 (CD-274). DP-179 reads the AP cash-leg obligations from this "
               "product. Operating model (CD-297, CD-331): an outsourced TA is the base case; the TA's settlement and "
               "exception reports are the source and the grain is unchanged, with Processing Provider on the fund order "
               "naming the TA. In house, the TA platform's obligations are the source. With NSCC net settlement the "
               "obligation level may not be received (29 SME question 11): those rows are certified at batch grain, and On-Time "
               "Settlement %, Late Settlement Days and Contractual Date Breaks are marked not available for them while "
               "Batch Tie-Out and Unmatched Cash still run. "
               "Payment Reference, Client Money Movement and individual payment amounts are personal data (PII = Y); "
               "publish an intermediary batch view without them. "
               "Taxonomy gap: there is no interest claim or late-payment charge attribute (Interest Claim Amount was "
               "removed in the 29 review), so the cost of non-payment is not measured. "
               "Open SME questions: 29 questions 1, 11. Rests on CD-183, CD-199, CD-274, CD-297, CD-331."
               "WP1 re-point (CW-260, CW-007): DP-580 Fund Share Register & Postings (WP1F) is added upstream: the 29 Fund Order and Settlement Obligation facts are published by DP-580 and read 'from DP-580'; this product keeps the settlement obligations past due and intermediary settlement measures (F3 hand-off note). Inputs and measures are unchanged; the 50 Money Movement upstream (DP-302) named in the FOP+CORP brief is left for a later re-spec.")),

    "DP-179": dict(
        definition=("Every authorized participant creation and redemption order: creation units ordered against the "
                    "applied basket, cut-off result, estimated and actual cash component, transaction fees and "
                    "collateral, basket line delivery and cash in lieu, and the settlement of the AP cash leg. ETF "
                    "operations and capital markets use it to manage AP activity, failed basket deliveries and "
                    "collateral, and fund accounting books the capital stock change from it. The basket comes from "
                    "DP-131 and the NAV and creation unit value from DP-165; the creation or redemption transaction "
                    "that DP-006 attributes and DP-008 certifies stays 06, so this product is never a flow source."),
        business_questions=[
            "How many creation units did each authorized participant create and redeem this month, in kind or in cash, and how concentrated is AP activity?",
            "Which AP orders have basket lines not delivered by settlement date, how much cash in lieu or collateral covers them, and how old are they?",
            "How far did the actual cash component differ from the estimate published with the basket?",
            "Were the fixed and variable transaction fees charged as agreed, and how much did they collect?",
            "Which AP orders were received after the cut-off, rejected, or have not produced a 06 creation or redemption transaction?",
        ],
        grain=("AP creation / redemption order (ECR-), with basket settlement line (AP order x basket constituent) and the AP "
               "cash-leg settlement obligation as child grains"),
        dimensions=["AP order trade date and settlement date", "ETF share class and fund (DP-004)", "Authorized participant (DP-115, DP-240)",
                    "AP agreement (DP-005)", "AP order type (creation / redemption)", "Basket settlement form (in kind / cash / custom)",
                    "Applied ETF basket (DP-131)", "Basket constituent instrument (DP-097)", "AP order channel and processing provider"],
        measures=[
            ("AP Orders and Creation Units",
             "Count of AP Order ID and sum of Creation Units Ordered by AP Order Type, ETF Share Class, Authorized Participant, Basket Settlement Form and AP Order Trade Date, for AP Order Status not rejected or canceled.",
             _u("29", "AP Creation / Redemption Order", "AP Order ID", "Creation Units Ordered", "AP Order Type", "ETF Share Class",
                "Authorized Participant", "Basket Settlement Form", "AP Order Trade Date", "AP Order Status")),
            ("Shares Created and Redeemed",
             "Creation Units Ordered x Creation Unit Size of the ETF (from DP-004), positive for creations and negative for redemptions, for settled orders by AP Order Settlement Date; the capital stock change fund accounting books, not a flow.",
             _u("29", "AP Creation / Redemption Order", "Creation Units Ordered", "AP Order Type", "AP Order Status", "AP Order Settlement Date")
             + _u("01", "ETF Characteristics", "Creation Unit Size") + ["AP Orders and Creation Units"]),
            ("Order Value at NAV",
             "Shares Created and Redeemed x NAV per Share of the ETF share class at the NAV of record for AP Order Trade Date (from DP-165).",
             _u("27", "Share Class NAV", "NAV Share Class", "Parent NAV Calculation", "NAV per Share")
             + _u("29", "AP Creation / Redemption Order", "AP Order Trade Date") + ["Shares Created and Redeemed"]),
            ("Cash Component Variance",
             "AP Cash Component Amount - Estimated Cash Component Amount, both signed by AP Cash Component Direction, per order; absolute variance as % of Order Value at NAV, flagged above the ETF operations tolerance.",
             _u("29", "AP Creation / Redemption Order", "AP Cash Component Amount", "Estimated Cash Component Amount", "AP Cash Component Direction")
             + ["Order Value at NAV"]),
            ("Late or Rejected AP Orders",
             "Count of AP orders whose AP Order Cut-Off Result is after the cut-off or whose AP Order Status is rejected, by Authorized Participant and AP Order Channel.",
             _u("29", "AP Creation / Redemption Order", "AP Order Cut-Off Result", "AP Order Status", "Authorized Participant", "AP Order Channel")),
            ("Transaction Fees Collected",
             "Sum of Fixed Transaction Fee + Variable Transaction Fee Amount by ETF share class and Authorized Participant; fee check flags orders where Variable Transaction Fee Amount differs from Variable Transaction Fee Rate x Order Value at NAV by more than one currency unit.",
             _u("29", "AP Order Fee", "Fixed Transaction Fee", "Variable Transaction Fee Rate", "Variable Transaction Fee Amount")
             + _u("29", "AP Creation / Redemption Order", "ETF Share Class", "Authorized Participant") + ["Order Value at NAV"]),
            ("Basket Delivery Completion %",
             "Basket Settlement Lines with Delivered Quantity at least Basket Quantity, or with the shortfall covered by Cash in Lieu Amount, / all lines of orders past AP Order Settlement Date.",
             _u("29", "Basket Settlement Line", "Line AP Order", "Basket Constituent", "Basket Quantity", "Delivered Quantity", "Cash in Lieu Amount")
             + _u("29", "AP Creation / Redemption Order", "AP Order Settlement Date")),
            ("Failed Basket Deliveries",
             "Count of Basket Settlement Lines with Line Settlement Status failed or pending after AP Order Settlement Date, with undelivered quantity Basket Quantity - Delivered Quantity and age in business days, by Authorized Participant and Basket Constituent.",
             _u("29", "Basket Settlement Line", "Line Settlement Status", "Basket Quantity", "Delivered Quantity", "Basket Constituent", "Line Delivery Settlement")
             + _u("29", "AP Creation / Redemption Order", "AP Order Settlement Date", "Authorized Participant")),
            ("Collateral Coverage of Shortfall",
             "Collateral Posted Amount / sum of Shortfall Amount of open Settlement Exceptions of type Failed Basket Delivery on the order's AP cash-leg obligation; orders below 100% are flagged.",
             _u("29", "AP Order Fee", "Collateral Posted Amount")
             + _u("29", "Settlement Obligation", "Obligation AP Order")
             + _u("29", "Settlement Exception", "Exception Settlement Obligation", "Settlement Exception Type", "Shortfall Amount", "Settlement Exception Status")),
            ("Cash in Lieu Share",
             "Sum of Cash in Lieu Amount / Order Value at NAV for in-kind orders, by ETF share class and month.",
             _u("29", "Basket Settlement Line", "Cash in Lieu Amount") + _u("29", "AP Creation / Redemption Order", "Basket Settlement Form")
             + ["Order Value at NAV"]),
            ("AP Cash Leg On-Time %",
             "AP cash-leg Settlement Obligations (Obligation AP Order filled) with Actual Settlement Date on or before Contractual Settlement Date / those due, by Authorized Participant.",
             _u("29", "Settlement Obligation", "Obligation AP Order", "Actual Settlement Date", "Contractual Settlement Date", "Obligation Settlement Status")),
            ("Settled Orders Without Transaction",
             "Count of AP orders with AP Order Status settled and no AP Resulting Transaction (the 29 Register Transaction) at the end of the business day after AP Order Settlement Date; the hand-off gap to the 29 register posting.",
             _u("29", "AP Creation / Redemption Order", "AP Order Status", "AP Resulting Transaction", "AP Order Settlement Date")),
            ("AP Concentration",
             "Share of Creation Units Ordered over the trailing 12 months held by the largest Authorized Participant and by the largest three, per ETF share class.",
             _u("29", "AP Creation / Redemption Order", "Authorized Participant", "ETF Share Class") + ["AP Orders and Creation Units"]),
        ],
        inputs=[
            ("29", "AP Creation / Redemption Order", ["AP Order ID", "AP Order Type", "Authorized Participant", "AP Agreement",
                                                      "ETF Share Class", "Creation Units Ordered", "Basket Settlement Form",
                                                      "Applied ETF Basket", "AP Order Received Timestamp",
                                                      "AP Order Cut-Off Result", "AP Order Trade Date", "AP Order Status",
                                                      "Estimated Cash Component Amount", "AP Cash Component Amount",
                                                      "AP Cash Component Direction", "AP Order Channel",
                                                      "AP Order Processing Provider", "AP Order Settlement Date",
                                                      "AP Resulting Transaction"]),
            ("29", "AP Order Fee", ["Fixed Transaction Fee", "Variable Transaction Fee Rate", "Variable Transaction Fee Amount",
                                    "Collateral Posted Amount"]),
            ("29", "Basket Settlement Line", ["Line AP Order", "Basket Constituent", "Basket Quantity", "Delivered Quantity",
                                              "Cash in Lieu Amount", "Line Settlement Status", "Line Delivery Settlement"]),
            ("29", "Settlement Obligation", ["Settlement Obligation ID", "Obligation AP Order", "Obligation Amount",
                                             "Contractual Settlement Date", "Obligation Settlement Status",
                                             "Actual Settlement Date"]),
            ("29", "Settlement Exception", ["Exception Settlement Obligation", "Settlement Exception Type", "Shortfall Amount",
                                            "Settlement Exception Status"]),
            ("01", "ETF Characteristics", ["Creation Unit Size", "Replication Method"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share"]),
        ],
        upstream=["DP-004", "DP-005", "DP-165", "DP-178", "DP-013", "DP-097", "DP-115", "DP-131", "DP-147", "DP-240"],
        refresh="Intraday",
        timeliness="AP orders within 15 minutes of receipt on the trade date; basket delivery and cash-leg status by 7am ET on each business day to settlement",
        history="Every AP order, fee, basket line and cash leg kept at least 6 years after settlement (Rule 6c-11 and transfer agent record retention, to confirm); daily snapshots of open failed deliveries kept 13 months",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "API"],
        dq_rules=[
            "Every AP order names an Authorized Participant with an AP Agreement in force (DP-005) on the AP Order Trade Date.",
            "Every in-kind AP order has an Applied ETF Basket and at least one Basket Settlement Line.",
            "Delivered Quantity is not greater than Basket Quantity on any Basket Settlement Line.",
            "Every AP order with AP Order Status settled has an AP Order Settlement Date and an AP cash-leg Settlement Obligation with Obligation Settlement Status settled.",
            "AP Cash Component Direction is filled whenever AP Cash Component Amount is not zero.",
        ],
        notes=("W3 re-point (CW-122, CW-929): AP Resulting Transaction re-typed to the 29 Register Transaction; AP Order Channel "
               "values re-cut to the NSCC CNS / ETF Portal and direct channels; no measure filters on a literal value. "
               "Boundary with DP-006 (CD-200): 06 ETF Creation / Redemption is the primary-market flow that DP-006 attributes "
               "and DP-008 certifies; this product is the order and settlement record and is never a flow source. The "
               "basket is taken from DP-131 ETF Baskets & Custom Basket Evidence (CD-361; Wave E2, specified in parallel) "
               "through Applied ETF Basket; 24 ETF Basket is not read directly, and Estimated Cash Component Amount and "
               "Basket Quantity are Derived copies (24) held on the 29 records, where the order-to-basket relationship lives. "
               "In-kind deliveries are 26 Settlement Instructions reached through Line Delivery Settlement (DP-147). AP "
               "agreements are 05 (DP-005), authorized participants are 02 parties joined to DP-115 where also approved "
               "counterparties. NAV per Share and the NAV of record come from DP-165 (CD-330); the cash-leg obligations "
               "and exceptions from DP-178. Operating model (CD-297, CD-331): AP orders may be processed by the TA, the "
               "custodian or a distributor portal (29 SME question 3); an outsourced processor is the base case. The grain "
               "is the AP order either way and AP Order Processing Provider names the processor; if the firm receives only "
               "the processor's order and settlement reports, basket line detail may be absent and Basket Delivery "
               "Completion % and Failed Basket Deliveries are marked not available for those rows. "
               "PII = N with justification for the validator warning: Obligation Amount and Shortfall Amount are tagged "
               "personal data because on fund-order rows they belong to an individual account; this product reads only "
               "AP cash-leg rows (Obligation AP Order filled), whose counterparty is an institutional authorized "
               "participant. "
               "Taxonomy gap: the AP order cut-off time (from the AP agreement or ETF procedures) is not an attribute, so "
               "AP Order Cut-Off Result is read as delivered and not re-tested. "
               "Open SME questions: 29 question 3. Rests on CD-177, CD-183, CD-200, CD-330, CD-331, CD-361.")),

    "DP-180": dict(
        definition=("Identity verification of direct shareholders (US CIP) by method and result, and every AML, "
                    "sanctions and fraud monitoring alert on shareholder accounts with its trigger, review, disposition, "
                    "escalation, fraud loss and the account restriction it caused. The BSA / AML officer uses it to "
                    "manage alert backlogs and evidence the CIP and monitoring controls of the AML program. It is the "
                    "only product that publishes shareholder-account alerts, dispositions, fraud loss amounts and CIP "
                    "results (CD-332); DP-085 feeds it as a pattern signal and party KYC state stays DP-077."),
        business_questions=[
            "Which accounts were opened without a completed identity verification or with a failed result, and are they restricted?",
            "How large and how old is the open alert backlog by category, scenario and priority, and is it within the review standard?",
            "How long does disposition take, how many alerts are escalated to an AML case, and how many had a second review?",
            "Which potential sanctions matches are open, and did any order or payment proceed before the alert was cleared?",
            "How much fraud loss did shareholder accounts suffer this quarter, by scenario and channel?",
        ],
        grain=("Account monitoring alert (AMA-) with its disposition; with the 02 identity verification behind each account opening (party x CIP "
               "program x verification, KYCV-) as a companion fact"),
        dimensions=["Alert generated date and disposition date", "Monitoring alert category (AML / sanctions / fraud)",
                    "Monitoring scenario", "Alert priority and status", "Account type and registration (DP-093)",
                    "CIP program and verification method", "Verification result", "Reviewer and second reviewer (DP-192)",
                    "Party AML risk rating (DP-077)"],
        measures=[
            ("Identity Verifications and Pass Rate",
             "Count of 02 Identity Verifications of direct shareholders with Verification Date in the period by CIP Program and Verification Method; share with Verification Result verified.",
             _u("02", "Identity Verification", "Identity Verification ID", "Verification Date", "CIP Program", "Verification Method", "Verification Result")),
            ("Accounts Opened Without Verification",
             "Count of Accounts with Account Open Date in the period, of an Account Registration Type in CIP scope, whose 15 Account Opening has no Opening Identity Verification or names one whose Verification Result is not verified.",
             _u("15", "Account", "Account ID", "Account Open Date", "Account Registration Type")
             + _u("15", "Account Opening", "Opening Identity Verification")
             + _u("02", "Identity Verification", "Identity Verification ID", "Verification Result")),
            ("Verification Turnaround",
             "Business days from Account Open Date to the Verification Date of the account's Opening Identity Verification; median and share over 30 days, by Verification Method.",
             _u("15", "Account", "Account Open Date") + _u("15", "Account Opening", "Opening Identity Verification")
             + _u("02", "Identity Verification", "Verification Date", "Verification Method")),
            ("Unverified Accounts Not Restricted",
             "Count of open accounts whose Opening Identity Verification is missing or not verified with no 15 Account Restriction on the account whose Account Restriction Lifted Date is empty.",
             _u("15", "Account Opening", "Opening Identity Verification") + _u("02", "Identity Verification", "Verification Result")
             + _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Lifted Date")),
            ("Government List Check Coverage %",
             "Completed Identity Verifications with Government List Check Date filled / all completed Identity Verifications of direct shareholders, by month.",
             _u("02", "Identity Verification", "Government List Check Date", "Verification Date", "CIP Program")),
            ("Alerts Generated",
             "Count of Account Monitoring Alerts by Alert Generated Timestamp date, Monitoring Alert Category and Monitoring Scenario; rate per 1,000 open accounts.",
             _u("29", "Account Monitoring Alert", "Account Monitoring Alert ID", "Alert Generated Timestamp", "Monitoring Alert Category", "Monitoring Scenario")
             + _u("15", "Account", "Account Status")),
            ("Open Alert Backlog",
             "Count of alerts with Alert Status open at the as-of date by Monitoring Alert Category and Alert Priority, aged from Alert Generated Timestamp in buckets 0 to 10, 11 to 30 and over 30 calendar days.",
             _u("29", "Account Monitoring Alert", "Alert Status", "Monitoring Alert Category", "Alert Priority", "Alert Generated Timestamp")),
            ("Disposition Time",
             "Calendar days from Alert Generated Timestamp to Disposition Date per dispositioned alert; median, 90th percentile and share within 30 days (the SAR decision clock of 31 CFR 1024.320), by category.",
             _u("29", "Account Monitoring Alert", "Alert Generated Timestamp", "Monitoring Alert Category") + _u("29", "Alert Disposition", "Disposition Date")),
            ("Escalation Rate",
             "Dispositioned alerts with Escalation Case Reference filled / all dispositioned alerts, by Monitoring Scenario; restricted audience only.",
             _u("29", "Alert Disposition", "Escalation Case Reference", "Alert Disposition") + _u("29", "Account Monitoring Alert", "Monitoring Scenario")),
            ("Second Review Coverage %",
             "Dispositioned alerts with Second Reviewer filled / dispositioned alerts of high Alert Priority, escalated, or first reviewed by an external (TA) reviewer.",
             _u("29", "Alert Disposition", "Second Reviewer", "Alert Reviewer", "Escalation Case Reference") + _u("29", "Account Monitoring Alert", "Alert Priority")),
            ("Open Sanctions Matches",
             "Count of alerts in the sanctions category with Sanctions Match Result potential or true match and Alert Status open, by Matched Sanctions List; true matches without an Alert Resulting Account Restriction are flagged.",
             _u("29", "Account Monitoring Alert", "Monitoring Alert Category", "Sanctions Match Result", "Matched Sanctions List", "Alert Status")
             + _u("29", "Alert Disposition", "Alert Resulting Account Restriction")),
            ("Released Before Disposition",
             "Count of sanctions and fraud alerts whose Triggering Fund Order reached Fund Order Status processed, or whose Triggering Cash Movement reached Payment Settlement Status settled, before the Disposition Date.",
             _u("29", "Account Monitoring Alert", "Triggering Fund Order", "Triggering Cash Movement", "Monitoring Alert Category")
             + _u("29", "Fund Order", "Fund Order ID", "Fund Order Status", "Trade Date Assigned")
             + _u("29", "Cash Movement", "Cash Movement ID", "Payment Settlement Status", "Payment Value Date")
             + _u("29", "Alert Disposition", "Disposition Date")),
            ("Fraud Loss",
             "Sum of Fraud Loss Amount of alerts dispositioned in the period, by Monitoring Scenario and Account Type; published only by this product (CD-332).",
             _u("29", "Alert Disposition", "Fraud Loss Amount", "Disposition Date") + _u("29", "Account Monitoring Alert", "Monitoring Scenario")
             + _u("15", "Account", "Account Type")),
            ("Alerts on High-Risk Parties",
             "Count of alerts whose Alert Subject Party has AML Risk Rating high or PEP Status = Y in the 02 KYC Profile at Alert Generated Timestamp (read through DP-077), by category.",
             _u("29", "Account Monitoring Alert", "Alert Subject Party", "Alert Generated Timestamp", "Monitoring Alert Category")
             + _u("02", "KYC Profile", "AML Risk Rating", "PEP Status")),
        ],
        inputs=[
            ("29", "Account Monitoring Alert", ["Account Monitoring Alert ID", "Monitoring Alert Category", "Monitoring Scenario",
                                                "Alert Account", "Alert Subject Party", "Triggering Fund Order",
                                                "Triggering Cash Movement", "Alert Generated Timestamp", "Alerted Amount",
                                                "Alert Priority", "Sanctions Match Result", "Matched Sanctions List",
                                                "Alert Status"]),
            ("29", "Alert Disposition", ["Alert Reviewer", "Alert Disposition", "Disposition Rationale", "Disposition Date",
                                         "Second Reviewer", "Escalation Case Reference",
                                         "Disposition Information Classification", "Alert Resulting Account Restriction",
                                         "Fraud Loss Amount"]),
            ("29", "Fund Order", ["Fund Order ID", "Fund Order Status", "Trade Date Assigned"]),
            ("29", "Cash Movement", ["Cash Movement ID", "Payment Settlement Status", "Payment Value Date"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status", "Account Open Date",
                               "Account Close Date"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Account Restriction Reason", "Account Restriction Effective From",
                                           "Account Restriction Lifted Date"]),
            ("15", "Account Opening", ["Opening Identity Verification", "Good Order Date", "Account Approval Date"]),
            ("02", "Identity Verification", ["Identity Verification ID", "Verified Party", "CIP Program", "Verification Method",
                                             "Verification Result", "Verification Date", "Government List Check Date"]),
            ("02", "KYC Profile", ["KYC Status", "AML Risk Rating", "PEP Status", "Sanctions Screening Result"]),
        ],
        upstream=["DP-093", "DP-077", "DP-085", "DP-177", "DP-178", "DP-013", "DP-192", "DP-240"],
        refresh="Daily",
        timeliness="Alerts, dispositions and CIP results of the prior business day by 7am ET",
        history="CIP records kept 5 years after the account is closed (31 CFR 1024.220(a)(3)); alerts and dispositions kept at least 5 years after disposition, with daily backlog snapshots kept 3 years",
        classification="Restricted - Legal",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model"],
        dq_rules=[
            "Every Opening Identity Verification of an account in CIP scope resolves to a 02 Identity Verification of an account owner with a Verification Result and a Verification Date.",
            "Every alert with Alert Status closed has an Alert Disposition, a Disposition Date and an Alert Reviewer.",
            "Disposition Date is not earlier than the date of Alert Generated Timestamp.",
            "An alert with Alert Disposition escalated has an Escalation Case Reference.",
            "Every sanctions-category alert has a Sanctions Match Result and a Matched Sanctions List.",
            "Fraud Loss Amount is filled only on alerts in the fraud category.",
        ],
        notes=("W3 re-point (CW-124, CW-025, CW-929): 29 CIP Verification dropped and CIP- retired; the five CIP measures are "
               "re-pointed to 02 Identity Verification (KYCV-) through 15 Account Opening.Opening Identity Verification (Identity "
               "Verification Regime is CIP Program, CIP Verification Method is Verification Method, CIP Result is Verification "
               "Result, Verification Completed Date is Verification Date, Government List Check Indicator is a filled Government "
               "List Check Date); CIP Exemption Reason and CIP Resulting Account Restriction have no successor (exemption is read "
               "from the registration type in scope, restrictions from 15 Account Restriction on the account). Matched Sanctions "
               "List is a secondary reference only; Account Monitoring Alert is kept. "
               "Boundary with DP-085 (CD-332): DP-085 detects account maintenance and redemption patterns on 13 servicing "
               "events and is upstream as a signal source, unchanged, with no alert or loss measure; 29 Account Monitoring "
               "Alert is the alert of record, published only here, and fraud counts and losses are defined only here. Party "
               "KYC state stays 02 (DP-077) and is read for the risk rating only; it is never republished. AML cases and SAR "
               "and OFAC reports are 38 (CD-255) and are referenced by Escalation Case Reference only. Restricted - Legal "
               "fields (the escalation disposition value, Escalation Case Reference, Alert Status and Disposition "
               "Rationale) are never published outside the AML unit (31 CFR 1024.320(e)); the whole product is classified "
               "Restricted - Legal, and a de-identified backlog view (counts and ages by category, no account, party, "
               "disposition value or case reference) is the only view for TA management. PII = Y throughout. "
               "Operating model (CD-297, CD-331): an outsourced TA is the base case; alerts may be generated and "
               "first-reviewed by the TA, the grain is unchanged, Alert Reviewer may be an external party and the firm's "
               "second review is recorded as Second Reviewer (29 SME question 5). In house, the firm's AML unit is the "
               "first reviewer. "
               "Taxonomy gap: no reference links an Account Monitoring Alert to the DP-085 pattern flag or 13 maintenance "
               "event that prompted it, so signal-to-alert conversion cannot be measured; Monitoring Scenario is the "
               "nearest attribute. "
               "Taxonomy gap: Alert Disposition holds two review levels only; more levels wait for SME question 5. "
               "Open SME questions: 29 questions 1, 4, 5. Rests on CD-201, CD-255, CD-297, CD-331, CD-332."
               "WP1 re-point (CW-264): holds on registered shares are DP-583's (Shareholder Account Holds & Rule 2165 Restrictions, specs_w1c_fop_corp.py), which lists this product upstream for the monitoring alerts that place them; this product keeps the alerts, dispositions, fraud loss and CIP results and publishes no register hold measure, so no measure is dropped.")),

    "DP-181": dict(
        definition=("Daily transfer agency control results by share class: capital stock proof against the shares "
                    "outstanding of the NAV of record, cash proof, unprocessed items and as-of dilution against "
                    "threshold, with every exception's cause, severity, owner and resolution and the daily sign-off. "
                    "Transfer agency signs off each business day from it, fund accounting relies on its capital stock "
                    "proof before releasing the NAV (DP-168), and DP-176 reads it for the TA scorecard. Comparison "
                    "values are the NAV of record published by DP-165 and are not stored twice."),
        business_questions=[
            "Did every active share class get a capital stock proof, a cash proof and an unprocessed items check today, and did each pass within tolerance?",
            "Which share classes have a capital stock difference against fund accounting shares outstanding, how large, and what caused it?",
            "Was each proof run against the NAV of record, or against a version or source that is not official?",
            "Which control exceptions are open, by severity and owner, and how long do they take to resolve?",
            "Has the TA signed off every control for the business date, and which provider's controls fail most often?",
        ],
        grain=("TA control check (TACK-): TA control type x share class (or fund) x business date, with TA control exception "
               "(control check x exception number) as a child grain"),
        dimensions=["Control business date", "TA control type", "Share class and fund (DP-004)", "Control result",
                    "Control processing provider (DP-240)", "Control exception cause and severity",
                    "Exception owner and sign-off (DP-192)", "Business calendar (DP-013)"],
        measures=[
            ("Control Coverage %",
             "Share classes with Share Class Status active that have a TA Control Check of each required TA Control Type for each business day (Day Type) / share classes x required control types x business days.",
             _u("01", "Share Class", "Share Class ID", "Share Class Status") + _u("09", "Calendar Date", "Calendar Date", "Day Type")
             + _u("29", "TA Control Check", "TA Control Check ID", "TA Control Type", "Control Share Class", "Control Business Date")),
            ("Control Pass Rate %",
             "Checks with Control Result pass / checks run, by TA Control Type, Control Processing Provider and month.",
             _u("29", "TA Control Check", "Control Result", "TA Control Type", "Control Processing Provider")),
            ("Control Difference Check",
             "Per check with a Comparison Value: TA Control Value - Comparison Value - Control Difference; any non-zero result is a calculation break. Checks where the absolute Control Difference exceeds Control Tolerance but Control Result is pass are flagged.",
             _u("29", "TA Control Check", "TA Control Value", "Comparison Value", "Control Difference", "Control Tolerance", "Control Result")),
            ("Capital Stock Proof Difference",
             "Control Difference in shares for TA Control Type capital stock proof, per share class and business date; count and sum of absolute difference beyond Control Tolerance.",
             _u("29", "TA Control Check", "TA Control Type", "Control Difference", "Control Tolerance", "Control Measure Unit")),
            ("Proofs Not Against NAV of Record",
             "Count of capital stock proofs whose Compared NAV Record is not the Share Class NAV of the NAV of record for the share class and Control Business Date (DP-165), or whose Comparison Value differs from that record's Shares Outstanding.",
             _u("29", "TA Control Check", "Compared NAV Record", "Comparison Value", "Control Share Class", "Control Business Date")
             + _u("27", "Share Class NAV", "Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "Shares Outstanding")
             + _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Approval Status", "NAV Version Number", "NAV Calculation Source")),
            ("Cash Proof Difference",
             "Control Difference in Control Currency for TA Control Type cash proof, per share class or fund and business date; sum of absolute difference beyond Control Tolerance.",
             _u("29", "TA Control Check", "TA Control Type", "Control Difference", "Control Currency", "Control Tolerance", "Control Fund")),
            ("Unprocessed Items and As-Of Dilution",
             "TA Control Value of the unprocessed items control (count) and of the as-of dilution control (amount) against Control Tolerance as threshold, per share class and day; days over threshold in the month.",
             _u("29", "TA Control Check", "TA Control Type", "TA Control Value", "Control Tolerance", "Control Business Date")),
            ("Open Control Exceptions",
             "Count of TA Control Exceptions with Control Exception Status open at the as-of date by Control Exception Severity and Control Exception Cause, aged in business days from the check's Control Business Date.",
             _u("29", "TA Control Exception", "Exception Control Check", "Control Exception Number", "Control Exception Status", "Control Exception Severity", "Control Exception Cause")
             + _u("29", "TA Control Check", "Control Business Date")),
            ("Exception Resolution Time",
             "Business days from Control Business Date to Control Exception Resolved Date for exceptions resolved in the period; median and maximum by Control Exception Cause and Control Exception Owner.",
             _u("29", "TA Control Exception", "Control Exception Resolved Date", "Control Exception Cause", "Control Exception Owner")
             + _u("29", "TA Control Check", "Control Business Date")),
            ("Exception Explanation Tie-Out",
             "Control Difference - sum of Exception Difference Value of the check's exceptions; a non-zero remainder on a failed check is unexplained difference.",
             _u("29", "TA Control Check", "Control Difference", "Control Result") + _u("29", "TA Control Exception", "Exception Difference Value")),
            ("Daily Sign-Off Completion %",
             "Checks with Control Signed Off By filled by 10am ET on the next business day / checks of the business date, by Control Processing Provider.",
             _u("29", "TA Control Check", "Control Signed Off By", "Control Business Date", "Control Processing Provider")),
        ],
        inputs=[
            ("29", "TA Control Check", ["TA Control Check ID", "TA Control Type", "Control Share Class", "Control Fund",
                                        "Control Business Date", "Control Measure Unit", "Control Currency", "TA Control Value",
                                        "Comparison Value", "Compared NAV Record", "Control Difference", "Control Tolerance",
                                        "Control Result", "Control Processing Provider", "Control Signed Off By"]),
            ("29", "TA Control Exception", ["Exception Control Check", "Control Exception Number", "Exception Difference Value",
                                            "Control Exception Cause", "Control Exception Severity", "Control Exception Owner",
                                            "Exception Related Fund Order", "Exception Servicing Error",
                                            "Control Exception Status", "Control Exception Resolved Date"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "Shares Outstanding"]),
            ("27", "Fund NAV Calculation", ["Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "NAV Approval Status"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
        ],
        upstream=["DP-165", "DP-177", "DP-178", "DP-004", "DP-013", "DP-192", "DP-240"],
        refresh="Daily",
        timeliness="Control results for the business date by 5pm ET, before NAV release; exceptions and sign-off by 10am ET on the next business day",
        history="Every control check and exception kept at least 6 years (transfer agent record retention, to confirm); no overwrite: a re-run creates a new check row",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "API"],
        dq_rules=[
            "Every active share class has one capital stock proof per business day of its dealing calendar.",
            "For every check with a Comparison Value, Control Difference equals TA Control Value - Comparison Value.",
            "Every capital stock proof's Compared NAV Record is the Share Class NAV of the NAV of record for its share class and Control Business Date.",
            "A check with Control Result fail has at least one TA Control Exception.",
            "A TA Control Exception with Control Exception Status resolved has a Control Exception Resolved Date and a Control Exception Cause.",
        ],
        notes=("Boundary with DP-043 (CD-202, CD-333): DP-043 keeps outsourced-TA service levels and servicing errors (13); "
               "this product holds the daily operational control results (29), referencing 13 Servicing Errors by "
               "Exception Servicing Error only. DP-176 reads this product for the provider scorecard and DP-168 relies on "
               "the capital stock and cash proofs (CD-335); neither copies its measures. 27 NAV Control Check references "
               "the TACK- record and does not recompute it (CD-196). A 37 Control Test samples these results by reference "
               "(CD-243). Comparison values are read from DP-165 (NAV of record, CD-330) and not stored twice; DP-045 keeps "
               "the 06 TA versus fund accounting AUM check. "
               "Operating model (CD-297, CD-331): an outsourced TA is the base case; the TA's daily control report is the "
               "source (Control Processing Provider names it), the grain is unchanged, and the firm's sign-off (Control "
               "Signed Off By) is the oversight fact. In house, the TA platform's controls are the source and the same "
               "person signs off. Either way the product exists, as CD-331 requires. "
               "PII = Y: sign-off and exception owners are named employees; publish a view without them for the "
               "provider scorecard. "
               "Taxonomy gap: there is no sign-off timestamp (Control Sign-Off Timestamp was removed in the 29 review), so "
               "Daily Sign-Off Completion % is measured from the load time of the sign-off, not the time it was given. "
               "Open SME questions: 29 questions 1, 6 (capital stock proof as a TA control, a fund accounting control or "
               "both). Rests on CD-196, CD-202, CD-243, CD-330, CD-331, CD-333, CD-335.")),

    # ---------------------------------------------------------------------------------------------------------------
    # 35 Fund Governance & Regulatory Reporting
    # ---------------------------------------------------------------------------------------------------------------
    "DP-182": dict(
        definition=("The fund governance record across registrant boards and CIT trustee "
                    "committees: the funds each body governs, members and their independence, fund officers, governance "
                    "standards and self-assessments, meetings and agenda, the reports each board received and the "
                    "material matters they cited, every resolution with its subjects and votes, fidelity bonds "
                    "and exemptive relief relied on. Fund legal and the board secretariat use it to plan agendas, "
                    "evidence required approvals and reports, and answer what the board approved and when. It publishes "
                    "the Governing Body dimension and the derived board-approval status that 31, 33, 34 and 36 products "
                    "read (CD-237); it holds the governance record, not any reported number."),
        business_questions=[
            "Which funds are governed by which board or committee today, and does any active fund lack one?",
            "Does each board meet the independence and governance standards, and are any members past their term or no longer employed?",
            "Which reports required by rule did each board receive this year, which are missing, and which cited material compliance matters?",
            "What did the board approve for a given fund, share class, risk program or waiver, when, with what conditions, and is that approval still in force?",
            "Which resolutions needed an independent majority and did not record one, and which approvals expire in the next 90 days?",
            "Is each fund covered by a fidelity bond at least equal to the required minimum, and was the bond filed?",
        ],
        grain=("Board resolution (RESO-) x approved subject, with fund governing body (BOARD-), governed fund coverage, "
               "membership, officer appointment, board meeting (BMEET-), report received, fidelity bond and exemptive relief "
               "reliance as effective-dated companion tables"),
        dimensions=["Governing body and type (published here)", "Governed fund and share class (DP-004)", "Meeting date and type",
                    "Resolution type and outcome", "Resolution subject type", "Board report type", "Member role and interested person status",
                    "Fund officer role (DP-192, DP-240)", "Legal entity (DP-013)"],
        measures=[
            ("Funds Without Governing Body",
             "Count of funds (Parent Product of a Share Class with Share Class Status active) with no Governed Fund Coverage effective at the as-of date.",
             _u("01", "Share Class", "Parent Product", "Share Class Status")
             + _u("35", "Governed Fund Coverage", "Governed Product", "Coverage Effective From", "Coverage Effective To")),
            ("Independent Member %",
             "Members with Interested Person Status independent / all members effective at the as-of date, per governing body, excluding observer and advisory roles (Member Role); compared with the latest Independent Majority Met Indicator, and differences flagged.",
             _u("35", "Governing Body Membership", "Membership Governing Body", "Interested Person Status", "Member Role",
                "Membership Effective From", "Membership Effective To")
             + _u("35", "Governance Standards Profile", "Independent Majority Met Indicator", "Standards Assessment Date")),
            ("Governance Standards Met",
             "Governing bodies whose latest Governance Standards Profile has Governance Standards Met Indicator = Y / bodies of type registrant board; bodies without an assessment in the last 12 months are counted as not met.",
             _u("35", "Governance Standards Profile", "Governance Standards Met Indicator", "Standards Assessment Date")
             + _u("35", "Fund Governing Body", "Governing Body ID", "Governing Body Type", "Governing Body Status")),
            ("Departed Interested Members",
             "Count of effective memberships whose Interested Member Employee has Employment Status not active in DP-192.",
             _u("35", "Governing Body Membership", "Interested Member Employee", "Membership Effective To")
             + _u("20", "Employee", "Employee ID", "Employment Status")),
            ("Meetings and Quorum",
             "Count of Board Meetings by Board Meeting Type and Meeting Format per body and year; meetings with Quorum Present Indicator not Y; regular meetings without Executive Session Held Indicator = Y.",
             _u("35", "Board Meeting", "Board Meeting ID", "Meeting Governing Body", "Meeting Date", "Board Meeting Type",
                "Meeting Format", "Quorum Present Indicator", "Executive Session Held Indicator")),
            ("Minutes Pending Approval",
             "Count of Board Meetings with Minutes Approval Status not approved whose body has held a later regular meeting.",
             _u("35", "Board Meeting", "Minutes Approval Status", "Meeting Governing Body", "Meeting Date", "Board Meeting Type")),
            ("Required Reports Received %",
             "Board Report Received rows by Board Report Type and Report Period End for each governed fund / the reports expected for the year from the board reporting calendar (for example the CCO annual report, the liquidity risk management program annual report, the valuation designee reports).",
             _u("35", "Board Report Received", "Receiving Meeting", "Board Report Type", "Report Period Start", "Report Period End", "Reported Products")
             + _u("35", "Governed Fund Coverage", "Governed Product")),
            ("Material Matters Reported",
             "Count of Board Report Received with Material Compliance Matter Indicator = Y per body and year, with the count of Board Report Source Items citing investment breaches, risk limit exceedances and fair value determinations.",
             _u("35", "Board Report Received", "Material Compliance Matter Indicator", "Board Report Type")
             + _u("35", "Board Report Source Item", "Related Investment Breach", "Related Risk Limit Exceedance", "Related Fair Value Determination")),
            ("Board Approval Status",
             "For each approved subject (Resolution Subject Type with its subject reference): approved when the latest Board Resolution linked through Resolution Subject Link has Resolution Outcome approved, Resolution Effective Date on or before the as-of date, no Resolution Expiry Date before it and no later resolution naming it as Superseded Resolution; otherwise not approved or expired. The derived status 31, 33, 34 and 36 read (CD-237).",
             _u("35", "Resolution Subject Link", "Linked Resolution", "Resolution Subject Type", "Subject Product", "Subject Share Class",
                "Subject Highly Liquid Investment Minimum", "Subject Risk Program Designation", "Subject Guideline Waiver",
                "Subject Voting Policy", "Subject Product Proposal", "Subject Change Initiative", "Subject Advisory Agreement")
             + _u("35", "Board Resolution", "Board Resolution ID", "Resolution Outcome", "Resolution Effective Date", "Resolution Expiry Date", "Superseded Resolution")),
            ("Independent Majority Failures",
             "Count of resolutions with Independent Majority Required Indicator = Y and Resolution Outcome approved whose Independent Majority Achieved Indicator is not Y.",
             _u("35", "Board Resolution", "Independent Majority Required Indicator", "Resolution Outcome")
             + _u("35", "Resolution Vote Count", "Independent Majority Achieved Indicator", "Independent Votes For")),
            ("Approvals Expiring",
             "Count of approved resolutions with Resolution Expiry Date in the next 90 days and no superseding resolution, by Resolution Type.",
             _u("35", "Board Resolution", "Resolution Expiry Date", "Resolution Type", "Resolution Outcome", "Superseded Resolution")),
            ("Fidelity Bond Shortfall",
             "Count of bonds effective at the as-of date with Bond Coverage Amount below Minimum Required Coverage Amount, without a Bond Approving Resolution, or without a Bond Filing; and count of governed funds not among the Insured Funds of any effective bond (Rule 17g-1).",
             _u("35", "Fund Fidelity Bond", "Fidelity Bond Policy Number", "Insured Funds", "Coverage Period Start", "Coverage Period End",
                "Bond Coverage Amount", "Minimum Required Coverage Amount", "Bond Approving Resolution", "Bond Filing")
             + _u("35", "Governed Fund Coverage", "Governed Product")),
            ("Self-Assessments Overdue",
             "Count of active governing bodies with no Board Self-Assessment whose Assessment Completion Date is within the last 12 months.",
             _u("35", "Board Self-Assessment", "Assessed Governing Body", "Assessment Completion Date")
             + _u("35", "Fund Governing Body", "Governing Body Status")),
            ("Relief Without Board Finding",
             "Count of Exemptive Relief Reliance rows effective at the as-of date with no Board Finding Resolution, by Exemptive Relief Type.",
             _u("35", "Exemptive Relief Reliance", "Relying Fund", "Exemptive Relief Type", "Board Finding Resolution", "Reliance Effective From", "Reliance Effective To")),
        ],
        inputs=[
            ("35", "Fund Governing Body", ["Governing Body ID", "Governing Body Name", "Governing Body Type", "Board Committee Function",
                                           "Parent Governing Body", "Governed Registrant", "Governed Entity",
                                           "Governed Trustee Party", "Fund Complex Name", "Governing Body Status"]),
            ("35", "Governed Fund Coverage", ["Coverage Governing Body", "Governed Product", "Coverage Basis",
                                              "Covered Business Line", "Coverage Effective From", "Coverage Effective To"]),
            ("35", "Governing Body Membership", ["Membership Governing Body", "External Member Party", "Interested Member Employee",
                                                 "Member Role", "Interested Person Status", "Interested Person Basis",
                                                 "Audit Committee Financial Expert Indicator", "Membership Effective From",
                                                 "Membership Effective To"]),
            ("35", "Fund Officer Appointment", ["Officer Registrant", "Officer Entity", "Fund Officer Role", "Appointed Officer",
                                                "External Officer Party", "Appointing Resolution", "Officer Effective From",
                                                "Officer Effective To"]),
            ("35", "Governance Standards Profile", ["Standards Assessment Date", "Independent Majority Met Indicator",
                                                    "Independent Legal Counsel Indicator", "Quarterly Executive Session Indicator",
                                                    "Governance Standards Met Indicator"]),
            ("35", "Board Meeting", ["Board Meeting ID", "Meeting Governing Body", "Meeting Date", "Board Meeting Type",
                                     "Meeting Format", "Quorum Present Indicator", "Independent Members Present Count",
                                     "Executive Session Held Indicator", "Minutes Approval Status",
                                     "Board Materials Classification"]),
            ("35", "Board Agenda Item", ["Agenda Meeting", "Agenda Item Number", "Agenda Item Type", "Agenda Item Title"]),
            ("35", "Board Report Received", ["Receiving Meeting", "Board Report Type", "Report Period Start", "Report Period End",
                                             "Reported Products", "Reported Risk Program", "Material Compliance Matter Indicator"]),
            ("35", "Board Report Source Item", ["Related Investment Breach", "Related Risk Limit Exceedance",
                                                "Related Fair Value Determination", "Source Record Description"]),
            ("35", "Board Self-Assessment", ["Assessed Governing Body", "Assessment Year", "Assessment Completion Date"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Adopting Meeting", "Resolution Type", "Resolution Summary",
                                        "Resolution Outcome", "Resolution Effective Date", "Resolution Expiry Date",
                                        "Resolution Conditions", "Independent Majority Required Indicator",
                                        "Superseded Resolution"]),
            ("35", "Resolution Subject Link", ["Linked Resolution", "Resolution Subject Type", "Subject Advisory Agreement",
                                               "Subject Product", "Subject Share Class", "Subject Service Provider Role",
                                               "Subject Product Proposal", "Subject Change Initiative", "Subject Product Review",
                                               "Subject Voting Policy", "Subject Highly Liquid Investment Minimum",
                                               "Subject Risk Program Designation", "Subject Guideline Waiver",
                                               "Subject Proxy Voting Report", "Subject Shareholder Communication",
                                               "Subject Fund Financial Statement", "Subject RIC Determination Tax Year"]),
            ("35", "Resolution Vote Count", ["Votes For", "Votes Against", "Abstentions", "Independent Votes For",
                                             "Independent Majority Achieved Indicator"]),
            ("35", "Fund Fidelity Bond", ["Fidelity Bond Policy Number", "Insured Funds", "Bond Insurer", "Coverage Period Start",
                                          "Coverage Period End", "Bond Coverage Amount", "Minimum Required Coverage Amount",
                                          "Bond Approving Resolution", "Bond Filing"]),
            ("35", "Exemptive Relief Reliance", ["Relying Fund", "Exemptive Relief Type", "Order or Rule Citation",
                                                 "Board Finding Resolution", "Reliance Effective From", "Reliance Effective To"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-004", "DP-013", "DP-192", "DP-240"],
        refresh="Daily",
        timeliness="Records entered by the board secretariat available by 7am ET on the next business day; Board Approval Status recomputed daily",
        history="Resolutions, meetings, minutes status and memberships kept permanently (Rule 31a-2 minute book retention); effective-dated tables keep every version (SCD type 2)",
        classification="Restricted - Legal",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Board Resolution has an Adopting Meeting, a Resolution Type, a Resolution Outcome and a Resolution Effective Date.",
            "Every Governing Body Membership names exactly one of External Member Party and Interested Member Employee.",
            "A membership with Interested Person Status independent never names an Interested Member Employee.",
            "Every Resolution Subject Link names exactly one subject reference matching its Resolution Subject Type.",
            "A Fund Governing Body names exactly one of Governed Registrant, Governed Entity and Governed Trustee Party for its Governing Body Type.",
            "Effective periods of Governed Fund Coverage for the same body and product do not overlap.",
        ],
        notes=("W4 re-point (CW-930, CW-166): 35 Board Consent Record (LPAC consents, Related Private Fund Deal) dropped, no "
               "successor (the firm's private funds and their LPACs leave with 30), with the measure LPAC Consents Short. "
               "W1b: Governance Standards Profile.UK AFM Independence Requirement Met Indicator dropped, no successor (CW-935); no measure read it. The ManCo and AIFM boards leave the definition with the removed Governing Body Type values. "
               "Publishes the Governing Body dimension (consumer-published under the brief §5; promote to SM-00 only if Phase "
               "2 needs it, brief §8 question 9) and the derived Board Approval Status that 31, 33, 34 and 36 products and "
               "the Foundations brief's DP-105 and DP-107 read (CD-237). Board report source items are references to 31, "
               "33 and 22 records; their measures are never copied (CD-234). DP-183 reads this product for the 15(c) "
               "approving resolutions and DP-184 for certifying officers. The Wave E5 Board and Management Reporting pack "
               "reads certified metrics; this product holds the governance record, not the pack's numbers. Shareholder "
               "approvals are 13 (DP-071). "
               "Operating model: fund legal is in house; if a third-party trustee governs a fund, its body is a 35 "
               "Fund Governing Body with a Governed Trustee Party and the grain is unchanged. "
               "Membership, officer and interested person fields are personal data (PII = Y); minutes and resolutions may "
               "be privileged, hence Restricted - Legal; publish Board Approval Status without member or officer names for "
               "the consuming domains. "
               "Taxonomy gap: there is no board reporting requirement object (report type x regime x frequency x governed "
               "fund), so the expected set behind Required Reports Received % is a reference list kept by the board "
               "secretariat until one is added. "
               "Taxonomy gap: membership has no term end or retirement age attribute, so terms past their limit cannot be "
               "measured. "
               "Open SME questions: 35 questions 1, 5, 6, 7, 12, 13. Rests on CD-231, CD-234, CD-237.")),

    "DP-183": dict(
        definition=("Every fund advisory and sub-advisory agreement with its per-fund schedule, term and continuation date, "
                    "and each annual Section 15(c) renewal: request and delivery dates, the materials assembled (fees, "
                    "peer fees, expenses, profitability and performance) by reference to their owning products, the "
                    "board's findings by factor and the approving resolution and vote. Fund legal uses it to run the "
                    "renewal calendar and evidence the board's process. Every number shown is read from its owner "
                    "(CD-330, CD-334): expense ratios and net assets from DP-165, returns from DP-145, waivers from "
                    "DP-170, peer fees from DP-506, profitability from DP-499; the fee terms stay 01 (CD-232)."),
        business_questions=[
            "Which fund agreements reach their continuation end date in the next 120 days, and is a renewal under way for each?",
            "Did any fund operate under an agreement whose continuation lapsed or that shareholders had not approved?",
            "Were the 15(c) materials requested and delivered in time, and do they cover fees, peers, expenses, profitability and performance for every fund?",
            "Did the board record a finding on every 15(c) factor, and was the renewal approved by a majority of independent members?",
            "How does each fund's net expense ratio, performance and adviser margin compare with its peers, as presented to the board?",
        ],
        grain=("Agreement fund schedule: advisory agreement (ADVA-) x covered fund x approval cycle (initial approval or "
               "RENEW- renewal), with advisory contract renewal (agreement x renewal year), renewal material item and 15(c) "
               "finding as child grains"),
        dimensions=["Advisory agreement and type (adviser / sub-adviser)", "Adviser entity (DP-013) and sub-adviser (DP-240)",
                    "Covered fund and share class (DP-004)", "Renewal year", "Continuation end date", "Renewal material type",
                    "15(c) factor", "Approving meeting and resolution (DP-182)", "Materials preparer"],
        measures=[
            ("Agreements in Force",
             "Count of Fund Advisory Agreements with Advisory Agreement Status in force at the as-of date, by Advisory Agreement Type and Adviser Entity, and count of covered funds.",
             _u("35", "Fund Advisory Agreement", "Advisory Agreement ID", "Advisory Agreement Status", "Advisory Agreement Type", "Adviser Entity")
             + _u("35", "Agreement Fund Schedule", "Covered Fund")),
            ("Continuations Due",
             "Count of covered funds whose latest Fund Continuation End Date falls in the next 120 days with no later approval cycle of Fund Approval Outcome approved, by Adviser Entity.",
             _u("35", "Agreement Fund Schedule", "Schedule Agreement", "Covered Fund", "Schedule Renewal", "Fund Approval Outcome", "Fund Continuation End Date")
             + _u("35", "Fund Advisory Agreement", "Adviser Entity")),
            ("Lapsed Continuations",
             "Count of covered funds of agreements in force whose latest approved Fund Continuation End Date is before the as-of date; each is a Section 15(a)(2) exception.",
             _u("35", "Agreement Fund Schedule", "Covered Fund", "Fund Approval Outcome", "Fund Continuation End Date")
             + _u("35", "Fund Advisory Agreement", "Advisory Agreement Status")),
            ("Missing Shareholder Approval",
             "Count of initial approval cycles (Schedule Renewal blank) with Fund Approval Outcome approved and no Shareholder Approval Date on or before Agreement Effective Date, excluding agreements the board approved under exemptive relief recorded in Exemptive Relief Reliance (manager of managers).",
             _u("35", "Agreement Fund Schedule", "Schedule Renewal", "Fund Approval Outcome", "Shareholder Approval Date", "Shareholder Approval Proxy Proposal")
             + _u("35", "Fund Advisory Agreement", "Agreement Effective Date")
             + _u("35", "Exemptive Relief Reliance", "Relying Fund", "Exemptive Relief Type", "Reliance Effective From", "Reliance Effective To")),
            ("Materials Lead Time",
             "Days from 15(c) Request Date to Materials Delivered Date, and from Materials Delivered Date to the Meeting Date of the meeting that adopted the Renewal Approving Resolution; renewals with fewer than the board's minimum review days are flagged.",
             _u("35", "Advisory Contract Renewal", "Renewal ID", "15(c) Request Date", "Materials Delivered Date", "Renewal Approving Resolution")
             + _u("35", "Board Resolution", "Board Resolution ID", "Adopting Meeting") + _u("35", "Board Meeting", "Board Meeting ID", "Meeting Date")),
            ("Materials Completeness %",
             "Renewal x covered fund pairs with at least one Renewal Material Item of each required Renewal Material Type (fee comparison, peer universe, expenses, profitability, performance) whose source reference is filled / all renewal x fund pairs.",
             _u("35", "Renewal Material Item", "Material Renewal", "Renewal Material Type", "Source Fee Benchmark Study",
                "Source Peer Universe", "Source Profitability Record", "Source Performance Return", "Source Benchmark Return")
             + _u("35", "Agreement Fund Schedule", "Schedule Renewal", "Covered Fund")),
            ("Factor Findings Completeness %",
             "Renewals with a Board 15(c) Finding with Finding Text for each required 15(c) Factor (nature, extent and quality of services; performance; costs and profitability; economies of scale; fall-out benefits; fee comparison) / renewals approved in the year.",
             _u("35", "Board 15(c) Finding", "Finding Renewal", "15(c) Factor", "Finding Text") + _u("35", "Advisory Contract Renewal", "Renewal ID", "Renewal Year")),
            ("Independent Approval",
             "Renewal approving resolutions with Independent Majority Achieved Indicator = Y adopted at a meeting whose Meeting Format meets the in-person requirement (or recorded relief) / renewals approved.",
             _u("35", "Advisory Contract Renewal", "Renewal Approving Resolution")
             + _u("35", "Resolution Vote Count", "Independent Majority Achieved Indicator", "Independent Votes For")
             + _u("35", "Board Meeting", "Meeting Format")),
            ("Net Expense Ratio vs Peer Median",
             "Audited net expense ratio of the share class (Highlights Net Expense Ratio, certified by DP-165) - Peer Median Fee of the Fee Benchmark Study cited as Source Fee Benchmark Study (DP-506), with Own Fee Percentile, as presented to the board.",
             _u("27", "Financial Highlights", "Highlights Share Class", "Highlights Net Expense Ratio")
             + _u("11", "Fee Benchmark Study", "Fee Study ID", "Subject Share Class", "Fee Measure Compared", "Study Date")
             + _u("11", "Fee Benchmark Result", "Peer Median Fee", "Own Fee Percentile")
             + _u("35", "Renewal Material Item", "Source Fee Benchmark Study")),
            ("Performance vs Benchmark (Cited)",
             "Return Value of the Source Performance Return - Benchmark Return Value of the Source Benchmark Return for the same period, both certified by DP-145 (Return Status final or restated), for each cited period.",
             _u("35", "Renewal Material Item", "Source Performance Return", "Source Benchmark Return")
             + _u("32", "Performance Return", "Performance Return ID", "Return Value", "Return Status", "Return Period Start Date", "Return Period End Date")
             + _u("32", "Benchmark Return", "Benchmark Return Value", "Benchmark Period Start Date", "Benchmark Period End Date")),
            ("Adviser Margin (Cited)",
             "Operating Margin and Operating Profit of the Source Profitability Record for the covered fund's share classes (from DP-499).",
             _u("35", "Renewal Material Item", "Source Profitability Record")
             + _u("10", "Profitability Record", "Profitability Record ID", "Product / Share Class", "Profitability Period")
             + _u("10", "Profitability Measure", "Operating Profit", "Operating Margin")),
            ("Waivers in Renewal Year",
             "Sum of Waived Fee Amount + Reimbursed Expense Amount over the covered fund's share classes for accrual dates in the 12 months before the 15(c) Request Date (from DP-170).",
             _u("27", "Expense Cap & Waiver Accrual", "Waiver Share Class", "Waiver Accrual Date", "Waived Fee Amount", "Reimbursed Expense Amount")
             + _u("35", "Advisory Contract Renewal", "15(c) Request Date")),
            ("Fund Net Assets at Renewal",
             "Sum of Class Net Assets over the covered fund's share classes at the NAV of record on the last valuation date before the 15(c) Request Date (from DP-165).",
             _u("27", "Share Class NAV", "NAV Share Class", "Parent NAV Calculation", "Class Net Assets Amount")
             + _u("35", "Advisory Contract Renewal", "15(c) Request Date")),
        ],
        inputs=[
            ("35", "Fund Advisory Agreement", ["Advisory Agreement ID", "Adviser Entity", "External Sub-Adviser",
                                               "Advisory Agreement Type", "Parent Advisory Agreement",
                                               "Advisory Agreement Status", "Agreement Effective Date",
                                               "Initial Term End Date", "Agreement Termination Date", "Termination Reason"]),
            ("35", "Agreement Fund Schedule", ["Schedule Agreement", "Covered Fund", "Schedule Renewal", "Fund Fee Schedule",
                                               "Fund Approval Outcome", "Fund Continuation End Date",
                                               "Shareholder Approval Proxy Proposal", "Shareholder Approval Date"]),
            ("35", "Advisory Contract Renewal", ["Renewal ID", "Renewed Agreement", "Renewal Year", "15(c) Request Date",
                                                 "Materials Delivered Date", "Materials Preparer",
                                                 "Renewal Approving Resolution"]),
            ("35", "Renewal Material Item", ["Material Renewal", "Renewal Material Type", "Source Fee Benchmark Study",
                                             "Source Peer Universe", "Source Profitability Record",
                                             "Source Performance Return", "Source Benchmark Return"]),
            ("35", "Board 15(c) Finding", ["Finding Renewal", "15(c) Factor", "Finding Text", "Follow-Up Action"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Adopting Meeting", "Resolution Type", "Resolution Outcome",
                                        "Resolution Effective Date"]),
            ("35", "Resolution Vote Count", ["Independent Votes For", "Independent Majority Achieved Indicator"]),
            ("35", "Board Meeting", ["Board Meeting ID", "Meeting Date", "Meeting Format"]),
            ("35", "Exemptive Relief Reliance", ["Relying Fund", "Exemptive Relief Type", "Reliance Effective From",
                                                 "Reliance Effective To"]),
            ("27", "Financial Highlights", ["Highlights Share Class", "Highlights Gross Expense Ratio",
                                            "Highlights Net Expense Ratio"]),
            ("27", "Share Class NAV", ["NAV Share Class", "Parent NAV Calculation", "Class Net Assets Amount"]),
            ("27", "Expense Cap & Waiver Accrual", ["Waiver Share Class", "Waiver Accrual Date", "Waiver Type",
                                                    "Waived Fee Amount", "Reimbursed Expense Amount"]),
            ("11", "Fee Benchmark Study", ["Fee Study ID", "Subject Share Class", "Peer Universe", "Fee Measure Compared",
                                           "Study Date"]),
            ("11", "Fee Benchmark Result", ["Peer Median Fee", "Own Fee Percentile"]),
            ("10", "Profitability Record", ["Profitability Record ID", "Profitability Period", "Data Version",
                                            "Product / Share Class"]),
            ("10", "Profitability Measure", ["Operating Profit", "Operating Margin"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Share Class",
                                          "Return Period Start Date", "Return Period End Date", "Return Fee Basis",
                                          "Return Value", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Version", "Benchmark Return Value", "Benchmark Return Status"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product"]),
        ],
        upstream=["DP-182", "DP-165", "DP-170", "DP-499", "DP-506", "DP-538", "DP-004", "DP-013", "DP-145", "DP-408",
                  "DP-213", "DP-240"],
        refresh="Daily",
        timeliness="Agreement, schedule and renewal records by 7am ET on the next business day; cited figures as of the materials date, frozen when Materials Delivered Date is set",
        history="Every agreement version, approval cycle, renewal, material item and finding kept permanently for the life of the agreement plus 6 years (Rule 31a-2 retention of 15(c) materials, to confirm with counsel); cited figures snapshotted at Materials Delivered Date",
        classification="Restricted - Legal",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Fund Advisory Agreement in force has at least one Agreement Fund Schedule with Fund Approval Outcome approved.",
            "Every Advisory Contract Renewal with an approved outcome has a Renewal Approving Resolution whose Resolution Outcome is approved.",
            "Materials Delivered Date is not earlier than 15(c) Request Date and not later than the Meeting Date of the approving meeting.",
            "Every Renewal Material Item names exactly one source reference matching its Renewal Material Type.",
            "Fund Continuation End Date of a renewal cycle is later than the Fund Continuation End Date of the previous approved cycle for the same agreement and fund.",
        ],
        notes=("W2/W4 (CW-051, CW-911): 35 Agreement Fund Schedule.Fund Fee Schedule is typed Reference (Management Fee, 01), the "
               "fund fee terms (FSCH-) that stay in 01, not the 47 client Fee Schedule; 11 Fee Benchmark Study keeps Subject Share "
               "Class (EFAMA and IA peer sources left the 11 lists; no input changed). "
               "Takes every number from its owner (CD-330, CD-334) and never recalculates one: audited expense ratios and net "
               "assets from DP-165, waivers and reimbursements from DP-170 (which owns the fund side, CD-188), peer fees "
               "from DP-506 (11), adviser profitability from DP-499 (10), returns and "
               "benchmark returns from DP-145 (32, CD-320). The cited figures are the values the board saw: they are "
               "snapshotted at Materials Delivered Date and are not a source for any other product. Fee rates and "
               "breakpoints stay 01 (Fund Fee Schedule references them, CD-232). Shareholder approval of agreements is 13 "
               "(DP-408, Shareholder Approval Proxy Proposal); approving resolutions and meetings come from DP-182; DP-213 "
               "indexes the agreement as a contract type without re-mastering it. "
               "Operating model: fund legal is in house; if 15(c) materials are prepared by a vendor (35 SME question 2), "
               "Materials Preparer names it and the grain is unchanged. "
               "PII = N, with justification for the validator warning: Return Value is tagged personal data because account-level "
               "returns belong to an individual; this product reads only share class and fund returns cited in the "
               "materials. Renewal Material Item references 10 Profitability Records at share class grain only (rows with "
               "a Salesperson are out of scope). Restricted - Legal because 15(c) "
               "materials and profitability are prepared for counsel and the independent directors. "
               "Taxonomy gap: there is no required-materials or required-factor reference list per board; the required "
               "Renewal Material Types and 15(c) Factors behind the two completeness measures are a board secretariat "
               "list until one is added. "
               "Taxonomy gap: 35 Board 15(c) Finding has no per-factor conclusion (Factor Satisfied Indicator was dropped "
               "in the 35 review), so findings are counted, not scored. "
               "Open SME questions: 35 question 2. Rests on CD-188, CD-232, CD-237, CD-320, CD-330, CD-334."
               "WP1 re-point (CW-220, CW-240): the retired upstreams are replaced by their successors: DP-030 by DP-506 Competitive Pricing & Fee Benchmarks (11 Fee Benchmark Study and Result, read by Net Expense Ratio vs Peer Median), DP-035 by DP-499 Client, Offering & Advisor Profitability (10 Profitability Record and Measure, read by Adviser Margin (Cited)) and DP-071 by DP-408 Proxy Solicitation, Pass-Through & Voting Choice (13 Proxy Proposal behind Shareholder Approval Proxy Proposal); DP-059 is dropped with no replacement, since no measure read it and its 15(c) fee-materials scope is this product's (CW-220). DP-165 (net assets, audited ratios) was already upstream; DP-012 is not added, as no measure reads fee revenue. DP-538 Sub-Adviser Hires, Terminations & Section 15(c) Renewal Evidence is added upstream for the sub-advised funds' renewal evidence (CW-253; the edge runs one way, DP-183 lists DP-538 and DP-538 does not list DP-183). No measure dropped.")),

    "DP-184": dict(
        definition=("Every fund filing obligation and submission across forms (N-PORT, N-CEN, N-CSR, N-MFP, N-RN, N-PX, "
                    "24F-2, 485 and 497, Form PF, AIFMD Annex IV, UK and EU fund returns) and every reportable fund event "
                    "and public website disclosure: due date against official filing date, amendments, certifications, "
                    "documents filed, and the sign-off and reconciliation of each data source. Regulatory reporting uses "
                    "it to run the filing calendar and evidence timely, certified and reconciled filings. It is the "
                    "register of every fund submission (CD-334); DP-185 and DP-186 hold the assembled data of the "
                    "periodic structured forms, and the Wave E5 Regulatory Filing Data Hub reads all three."),
        business_questions=[
            "Which fund filings are due in the next 30 days, by form, filer and preparer, and which obligations have no filing yet?",
            "Which filings were late, by how many days, and which were amended after acceptance?",
            "Was every filing certified by an officer holding the right appointment before submission, with sub-certifications complete?",
            "Were all data sources of each filing reconciled and signed off, and did any fail a data quality check?",
            "Was every reportable event filed within its deadline and notified to the board, and was every required website disclosure published on time?",
        ],
        grain=("Fund regulatory filing (REGF-): filer x form type x reporting period end or event / as-of date x event "
               "reference x submission sequence; with filing obligation (filer x form x effective period), filing "
               "certification, filing data source, reportable fund event and fund public disclosure as companion facts"),
        dimensions=["Form type and regulator", "Filer product or entity (DP-004, DP-013)", "Reporting period end and due date",
                    "Filing status", "Filing preparation model and filing agent (DP-240)", "Certifying officer (DP-192)",
                    "Data source type", "Reportable event type", "Public disclosure type"],
        measures=[
            ("Filings Due",
             "Count of Fund Regulatory Filings and of effective Filing Obligations with Filing Due Date in the next 30 days and Filing Status not filed, by Filing Form Type, Filing Preparation Model and filer.",
             _u("35", "Fund Regulatory Filing", "Regulatory Filing ID", "Filing Form Type", "Filing Due Date", "Filing Status", "Filer Product")
             + _u("35", "Filing Obligation", "Obligation Form Type", "Filing Preparation Model", "Obligation Effective From", "Obligation Effective To")),
            ("On-Time Filing %",
             "Filings with Official Filing Date on or before Filing Due Date / filings whose Filing Due Date has passed, excluding amendments (Amended Filing filled), by form and preparer.",
             _u("35", "Fund Regulatory Filing", "Official Filing Date", "Filing Due Date", "Amended Filing", "Filing Form Type")
             + _u("35", "Filing Obligation", "Filing Preparation Model")),
            ("Days Late",
             "Business days (Calendar Date, Day Type) from Filing Due Date to Official Filing Date for late filings; sum and maximum by form.",
             _u("35", "Fund Regulatory Filing", "Filing Due Date", "Official Filing Date", "Filing Form Type")
             + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
            ("Missing Periodic Filings",
             "Count of effective Filing Obligations x reporting periods whose due date has passed with no Fund Regulatory Filing whose Met Obligation is the obligation and Reporting Period End Date is the period, by Obligation Form Type.",
             _u("35", "Filing Obligation", "Obligated Product", "Obligation Form Type", "Filing Frequency", "Due Day Rule",
                "Obligation Effective From", "Obligation Effective To")
             + _u("35", "Fund Regulatory Filing", "Met Obligation", "Reporting Period End Date")),
            ("Due Date Breaks",
             "Count of filings whose Filing Due Date differs from the date the Met Obligation's Due Day Rule gives for the Reporting Period End Date on its Filing Calendar.",
             _u("35", "Fund Regulatory Filing", "Filing Due Date", "Met Obligation", "Reporting Period End Date")
             + _u("35", "Filing Obligation", "Due Day Rule", "Filing Calendar")),
            ("Amendment Rate",
             "Filings with Amended Filing filled / original filings accepted in the trailing 12 months, by Filing Form Type.",
             _u("35", "Fund Regulatory Filing", "Amended Filing", "Acceptance Timestamp", "Filing Form Type")),
            ("Certification Completeness",
             "Filings of form types that require certification with a Filing Certification whose Certification Signed Date is on or before the date of Submitted Timestamp and Sub-Certifications Complete Indicator = Y / such filings submitted.",
             _u("35", "Filing Certification", "Certification Type", "Certification Signed Date", "Sub-Certifications Complete Indicator")
             + _u("35", "Fund Regulatory Filing", "Submitted Timestamp", "Filing Form Type")),
            ("Certifier Authority Breaks",
             "Count of Filing Certifications whose Certifying Officer holds no Fund Officer Appointment for the filer with a Fund Officer Role matching Certifying Officer Role, effective on Certification Signed Date.",
             _u("35", "Filing Certification", "Certifying Officer", "Certifying Officer Role", "Certification Signed Date")
             + _u("35", "Fund Officer Appointment", "Officer Registrant", "Fund Officer Role", "Appointed Officer", "Officer Effective From", "Officer Effective To")),
            ("Data Sources Reconciled %",
             "Filing Data Sources with Source Reconciled Indicator = Y and Source Sign-Off Employee filled / all data sources of filings submitted in the period, by Filing Data Source Type.",
             _u("35", "Filing Data Source", "Source Filing", "Filing Data Source Type", "Source Reconciled Indicator", "Source Sign-Off Employee")),
            ("Data Sources Failing Quality",
             "Count of Filing Data Sources whose Related Data Quality Result has Threshold Met Indicator = N, with DQ Result % (from DP-101).",
             _u("35", "Filing Data Source", "Related Data Quality Result")
             + _u("21", "Data Quality Result", "DQ Result ID", "DQ Result %", "Threshold Met Indicator", "Data As-Of Date")),
            ("Event Filing Timeliness",
             "Reportable Fund Events whose Resulting Filing has an Official Filing Date within the form's deadline from Event Date (for Form N-RN, one business day) / events requiring a filing; with days from Event Date to Board Notification Date.",
             _u("35", "Reportable Fund Event", "Event Fund", "Reportable Event Type", "Event Date", "Resulting Filing", "Board Notification Date")
             + _u("35", "Fund Regulatory Filing", "Official Filing Date") + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
            ("Disclosures Published On Time %",
             "Fund Public Disclosures with Publication Timestamp on or before the deadline for the Public Disclosure Type relative to Disclosure As-Of Date (for example ETF holdings before the opening of trading) / disclosures due; count of Persistent Premium or Discount Statement Required Indicator = Y.",
             _u("35", "Fund Public Disclosure", "Disclosing Product", "Public Disclosure Type", "Disclosure As-Of Date", "Publication Timestamp",
                "Persistent Premium or Discount Statement Required Indicator")),
        ],
        inputs=[
            ("35", "Filing Obligation", ["Obligated Product", "Obligated Entity", "Obligation Form Type", "Obligation Regulator",
                                         "Filing Frequency", "Due Day Rule", "Filing Calendar", "Filing Preparation Model",
                                         "Obligation Effective From", "Obligation Effective To"]),
            ("35", "Fund Regulatory Filing", ["Regulatory Filing ID", "Filing Form Type", "Filer Product", "Filer Entity",
                                              "Met Obligation", "Covered Series", "Reporting Period End Date",
                                              "Event or As-Of Date", "Event Reference", "Filing Due Date",
                                              "Submission Sequence", "Submitted Timestamp", "Acceptance Timestamp",
                                              "Official Filing Date", "Accession Number", "Filing Status", "Amended Filing",
                                              "Effectiveness Date", "Filing Agent Party", "Confidential Treatment Indicator"]),
            ("35", "Filing Document", ["Filed Shareholder Communication", "Filed Product Document", "Filed Proxy Voting Report",
                                       "Filed Document Share Class"]),
            ("35", "Filing Certification", ["Certification Type", "Certifying Officer", "Certifying External Party",
                                             "Certifying Officer Role", "Certification Signed Date",
                                             "Sub-Certifications Complete Indicator"]),
            ("35", "Filing Data Source", ["Source Filing", "Filing Data Source Type", "Source Record Key", "Source As-Of Date",
                                          "Source Data Basis", "Source Reconciled Indicator", "Source Sign-Off Employee",
                                          "Related Data Quality Result"]),
            ("35", "Reportable Fund Event", ["Event Fund", "Reportable Event Type", "Event Date", "Event Severity",
                                             "Source Investment Breach", "Source Risk Limit Exceedance",
                                             "Source Fund Liquidity Profile", "Source VaR Test Result", "Notified Regulator",
                                             "Board Notification Date", "Resulting Filing", "Event Resolved Date"]),
            ("35", "Fund Public Disclosure", ["Disclosing Product", "Disclosing Share Class", "Public Disclosure Type",
                                              "Disclosure As-Of Date", "Publication Timestamp", "Publication Location",
                                              "Source ETF Basket", "Source ETF Market Statistic",
                                              "Persistent Premium or Discount Statement Required Indicator"]),
            ("35", "Fund Officer Appointment", ["Officer Registrant", "Fund Officer Role", "Appointed Officer",
                                                "Officer Effective From", "Officer Effective To"]),
            ("21", "Data Quality Result", ["DQ Result ID", "Data As-Of Date", "DQ Result %", "Threshold Met Indicator"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
        ],
        upstream=["DP-182", "DP-004", "DP-013", "DP-192", "DP-101", "DP-240"],
        refresh="Daily",
        timeliness="Obligations, filings and disclosures as of the prior business day by 7am ET; filing status refreshed within one hour of EDGAR or regulator acceptance",
        history="Every obligation version, submission, amendment, certification and data source record kept permanently for the life of the fund plus 6 years; daily calendar snapshots kept 2 years",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "API"],
        dq_rules=[
            "Every Fund Regulatory Filing with Filing Status filed has a Submitted Timestamp, an Official Filing Date and an Accession Number.",
            "Every periodic filing references a Met Obligation effective on its Reporting Period End Date; event-driven filings reference none.",
            "An amended filing's Amended Filing references an accepted filing with the same Filing Form Type and filer.",
            "Every filing with Filing Status filed has at least one Filing Data Source with Source Reconciled Indicator = Y.",
            "Every Reportable Fund Event whose Reportable Event Type requires a filing has a Resulting Filing once the deadline has passed.",
        ],
        notes=("The register of submissions for every fund form (CD-233, CD-334); DP-185 and DP-186 hold the assembled data "
               "of the periodic structured forms. Reportable events reference 31 and 33 records (breaches, exceedances, "
               "liquidity profiles, VaR tests) and their measures are not copied (CD-234). Filing Data Source's data "
               "quality result links to the 21 catalog through DP-101 (Governance Metadata & Enterprise Catalog). "
               "Distribution, plan, firm and transaction filings stay 08, 16, 19, 25, 26, 28 and 38 (CD-233); 36 holds the "
               "change-to-filing link (Satisfying Filing) and derives its status from this product. Certifying officers "
               "are read from 35 Fund Officer Appointment (DP-182's record, same domain). "
               "Operating model (CD-297, CD-331): filing is in house with outsourced preparation as an option; if an "
               "administrator or filing agent prepares a form (Filing Preparation Model, Filing Agent Party), the grain is "
               "unchanged and the agent's draft and sign-off are recorded as Filing Data Sources. "
               "PII = Y: certifying officers and source sign-off employees are named; publish a calendar view without them. "
               "Taxonomy gap: the form deadline after an event (for example one business day for N-RN) and the "
               "publication deadline per Public Disclosure Type are not attributes; Event Filing Timeliness and "
               "Disclosures Published On Time % use a reference table of deadlines by form and disclosure type kept with "
               "this product until they are added. "
               "Taxonomy gap: which form types require certification is not an attribute of the obligation; Certification "
               "Completeness uses the same reference table. "
               "Open SME questions: 35 questions 3, 4, 11. Rests on CD-233, CD-234, CD-297, CD-331, CD-334.")),

    "DP-185": dict(
        definition=("The as-filed data set of each US registered fund's periodic structured reports: N-PORT holdings, "
                    "fair value levels, liquidity classification, risk metrics, derivatives exposure, returns and flows, "
                    "and securities lending; N-CEN service providers, securities lending and fund operational items; "
                    "N-MFP money market data. Each value is keyed to its REGF- filing and to the certified source product "
                    "and record it came from (CD-334). Regulatory reporting uses it to assemble, review and reconcile the "
                    "reports before certification and to answer what was filed after a source restates. It assembles "
                    "and never remasters: net assets and NAV from DP-165, holdings from DP-142, prices from DP-143, "
                    "liquidity classification from DP-155, risk measures from DP-146, returns from DP-145 and flows from "
                    "DP-008; the as-filed snapshot is evidence, not a source for other consumers."),
        business_questions=[
            "What exactly did we report on N-PORT for this fund and month, item by item, and from which source record and version?",
            "Is the N-PORT data set ready to certify: do holdings, liabilities and net assets tie to the NAV of record, and is every data source reconciled and signed off?",
            "Which holdings lack an identifier, a fair value level or a complete liquidity classification before filing?",
            "Have any filed values changed at source since filing (NAV re-strike, restated return, reclassified liquidity), and does that require an amendment?",
            "Which service providers, securities lending figures and operational items will we report on N-CEN, and do they match the provider records?",
        ],
        grain=("Fund regulatory filing (REGF-) x filing data source type x source record (holding, share class NAV, "
               "liquidity classification portion, risk exposure, return, flow measure, securities loan or product party "
               "role) x source as-of date and version, held as filed; with filing x share class x month for returns and "
               "flows"),
        dimensions=["Filing and form type (DP-184)", "Reporting period end", "Fund and share class (DP-004)",
                    "Instrument and asset class (DP-097)", "Liquidity category (DP-155)", "Fair value level (DP-143)",
                    "Data source type and source product", "Source as-of date and version", "Filing status (draft / filed / amended)"],
        measures=[
            ("As-Filed Net Assets",
             "Total Assets Amount, Total Liabilities Amount and Fund Net Assets Amount of the NAV of record (from DP-165) for the fund's book at the Reporting Period End Date, captured at Source As-Of Date and held as filed.",
             _u("27", "Fund NAV Calculation", "NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                "NAV Approval Status", "Total Assets Amount", "Total Liabilities Amount", "Fund Net Assets Amount")
             + _u("27", "Fund Accounting Book", "Book Fund")
             + _u("35", "Fund Regulatory Filing", "Regulatory Filing ID", "Reporting Period End Date", "Filer Product")
             + _u("35", "Filing Data Source", "Source As-Of Date")),
            ("Class NAV and Market-Based NAV",
             "NAV per Share, Shares Outstanding and Class Net Assets of each share class at the NAV of record (from DP-165), and Market-Based NAV per Share for money market classes on N-MFP, held as filed.",
             _u("27", "Share Class NAV", "Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                "Shares Outstanding", "Class Net Assets Amount", "Market-Based NAV per Share")),
            ("Holdings Reported",
             "Count of holdings and sum of Market Value Base of end-of-day Portfolio Holdings of the fund's primary implementing portfolio at the Reporting Period End Date (from DP-142), by Asset Class and Long / Short Indicator.",
             _u("18", "Portfolio Holding", "Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View", "Long / Short Indicator")
             + _u("18", "Holding Valuation", "Market Value Base")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implemented Product", "Primary Implementation Indicator")
             + _u("17", "Instrument", "Asset Class")),
            ("Holding % of Net Assets",
             "Market Value Base of each reported holding / Fund Net Assets Amount of the NAV of record; the sum over holdings plus other assets less liabilities is checked against 100%.",
             _u("18", "Holding Valuation", "Market Value Base") + _u("27", "Fund NAV Calculation", "Fund Net Assets Amount")
             + ["Holdings Reported", "As-Filed Net Assets"]),
            ("Holdings Without Identifier",
             "Count of reported holdings whose Held Instrument has no effective Instrument Identifier of a scheme the form accepts (ISIN, CUSIP, ticker or other) (DP-097).",
             _u("18", "Portfolio Holding", "Held Instrument")
             + _u("17", "Instrument Identifier", "Identified Instrument", "Instrument Identifier Scheme", "Instrument Identifier Value",
                  "Identifier Effective From", "Identifier Effective To")),
            ("Fair Value Level Coverage %",
             "Reported holdings whose Price Used matches an Approved Price with Price Approval Status approved and Approved Price Fair Value Level filled for the Held Instrument and Holding Date (DP-143) / reported holdings.",
             _u("18", "Holding Valuation", "Price Used") + _u("18", "Portfolio Holding", "Held Instrument", "Holding Date")
             + _u("22", "Approved Price", "Priced Instrument", "Price Date", "Approved Price Value", "Approved Price Fair Value Level", "Price Approval Status")),
            ("Liquidity Classification Coverage %",
             "Reported holdings whose Liquidity Classification portions for the fund, instrument and Classification Date at period end sum to 100% of the position (Portion Percent of Position) / reported holdings (from DP-155).",
             _u("31", "Liquidity Classification", "Classified Fund", "Classified Instrument", "Classification Date",
                "Classification Portion Number", "Liquidity Category", "Portion Percent of Position")
             + _u("18", "Portfolio Holding", "Held Instrument")),
            ("Reported Liquidity Profile",
             "Highly Liquid Percent, Illiquid Percent and HLIM Shortfall Indicator of the Fund Liquidity Profile at the period end, and HLIM Percent of the effective Highly Liquid Investment Minimum (certified by DP-155), held as filed.",
             _u("31", "Fund Liquidity Profile", "Profile Fund", "Profile Measurement Date", "Highly Liquid Percent", "Illiquid Percent", "HLIM Shortfall Indicator")
             + _u("31", "Highly Liquid Investment Minimum", "HLIM Fund", "HLIM Percent", "HLIM Effective From", "HLIM Effective To")),
            ("Reported Risk Metrics",
             "Exposure Value by Exposure Measure (interest rate and credit spread sensitivities), Exposure Dimension and Exposure Bucket for the fund's portfolio at period end from the approved run (from DP-146), held as filed.",
             _u("31", "Portfolio Exposure", "Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run",
                "Exposure Measure", "Exposure Dimension", "Exposure Bucket", "Exposure Value")),
            ("Reported Derivatives Exposure and VaR",
             "Leverage Percent of Net Assets for the Rule 18f-4 derivatives exposure method and VaR Test Value and VaR Test Pass Indicator of the period's VaR Test Results (from DP-155), held as filed.",
             _u("31", "Leverage & Exposure Measurement", "Measured Fund", "Leverage Measurement Date", "Exposure Method",
                "Measured Exposure Amount", "Leverage Percent of Net Assets")
             + _u("31", "VaR Test Result", "VaR Test Fund", "VaR Test Date", "VaR Test Regime", "VaR Test Value", "VaR Test Pass Indicator")),
            ("Reported Monthly Returns",
             "Return Value of the monthly Performance Return of each share class with Return Status final or restated and the highest Return Version (Official Return, from DP-145), for each month of the reporting period, held as filed.",
             _u("32", "Performance Return", "Performance Return ID", "Return Share Class", "Return Period Start Date",
                "Return Period End Date", "Return Fee Basis", "Return Value", "Return Status", "Return Version")),
            ("Reported Flows",
             "Gross Sales, Reinvested Distributions and Redemptions of the fund for each month of the reporting period from the locked DP-008 snapshot (Measure Value with Data Basis actual), held as filed (CD-334: fund-level flows from DP-008 until CD-292 rules otherwise).",
             _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Dimension Key", "Data Basis", "Snapshot", "Measure Amount")
             + _u("06", "Flow Measures", "Gross Sales", "Reinvested Distributions", "Redemptions")),
            ("Reported Liability Detail",
             "Closing Balance Amount of the fund's ledger accounts mapped to the form's liability items (borrowings, payables for investments purchased, other liabilities) at the Reporting Period End Date (from DP-166); their sum is checked against Total Liabilities Amount.",
             _u("27", "Fund Trial Balance", "Balance Book", "Balance Fund Ledger Account", "Balance Date", "Closing Balance Amount")
             + _u("27", "Fund NAV Calculation", "Total Liabilities Amount")),
            ("Securities on Loan Reported",
             "Sum of Loan Value of Securities Loans with Securities Loan Status open at the period end, by Loaned Instrument and Borrower (from DP-174), held as filed.",
             _u("28", "Securities Loan", "Securities Loan ID", "Loaned Instrument", "Borrower", "Loan Value", "Loan Mark Date", "Securities Loan Status")),
            ("N-CEN Service Providers",
             "Count of Product Party Roles effective at the period end by Party Role Type (custodian, transfer agent, administrator, auditor, pricing service, securities lending agent), and count of reported providers without Party LEI (DP-004; provider oversight read from DP-176).",
             _u("01", "Product Party Role", "Party", "Party Legal Name", "Party LEI", "Party Role Type", "Role Effective From", "Role Effective To")),
            ("Data Sources Reconciled %",
             "Filing Data Sources of the filing with Source Reconciled Indicator = Y and Source Sign-Off Employee filled / all data sources of the filing; the filing is ready to certify at 100%.",
             _u("35", "Filing Data Source", "Source Filing", "Filing Data Source Type", "Source Record Key", "Source Reconciled Indicator", "Source Sign-Off Employee")),
            ("Source Drift Since Filing",
             "For each filed value, the current certified value from the same source minus the as-filed value, where the source has a later version than the one filed (higher NAV Version Number of the NAV of record, higher Return Version, a later Classification Date record for the period); count of filings with drift beyond the amendment threshold.",
             _u("27", "Fund NAV Calculation", "NAV Version Number", "Fund Net Assets Amount")
             + _u("32", "Performance Return", "Return Version", "Return Value")
             + _u("35", "Filing Data Source", "Source Record Key", "Source As-Of Date", "Source Data Basis")
             + _u("35", "Fund Regulatory Filing", "Filing Status", "Amended Filing")
             + ["As-Filed Net Assets", "Reported Monthly Returns"]),
        ],
        inputs=[
            ("35", "Fund Regulatory Filing", ["Regulatory Filing ID", "Filing Form Type", "Filer Product", "Covered Series",
                                              "Reporting Period End Date", "Filing Due Date", "Submission Sequence",
                                              "Official Filing Date", "Accession Number", "Filing Status", "Amended Filing",
                                              "Confidential Treatment Indicator"]),
            ("35", "Filing Data Source", ["Source Filing", "Filing Data Source Type", "Source Record Key", "Source As-Of Date",
                                          "Source Data Basis", "Source Reconciled Indicator", "Source Sign-Off Employee"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "NAV Approval Status", "Total Assets Amount", "Total Liabilities Amount",
                                            "Fund Net Assets Amount"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                                       "Class Net Assets Amount", "Shares Outstanding", "Market-Based NAV per Share"]),
            ("27", "Fund Trial Balance", ["Balance Book", "Balance Fund Ledger Account", "Balance Date",
                                          "Closing Balance Amount"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View",
                                         "Holding Quantity", "Long / Short Indicator"]),
            ("18", "Holding Valuation", ["Price Used", "Price Date", "Market Value Base"]),
            ("18", "Derivative Holding Detail", ["Notional Amount Base", "Delta-Adjusted Exposure Base", "OTC Counterparty"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Product",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Issuer"]),
            ("17", "Instrument Identifier", ["Identified Instrument", "Instrument Identifier Scheme",
                                             "Instrument Identifier Value", "Identifier Effective From",
                                             "Identifier Effective To"]),
            ("22", "Approved Price", ["Priced Instrument", "Price Date", "Approved Price Value", "Approved Price Fair Value Level",
                                      "Price Approval Status"]),
            ("31", "Liquidity Classification", ["Classified Fund", "Classified Instrument", "Classification Date",
                                                "Classification Portion Number", "Liquidity Category",
                                                "Portion Percent of Position"]),
            ("31", "Fund Liquidity Profile", ["Profile Fund", "Profile Measurement Date", "Highly Liquid Percent",
                                              "Illiquid Percent", "HLIM Shortfall Indicator"]),
            ("31", "Highly Liquid Investment Minimum", ["HLIM Fund", "HLIM Percent", "HLIM Effective From",
                                                        "HLIM Effective To"]),
            ("31", "Portfolio Exposure", ["Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run",
                                          "Exposure Dimension", "Exposure Bucket", "Exposure Measure", "Exposure Value"]),
            ("31", "Leverage & Exposure Measurement", ["Measured Fund", "Leverage Measurement Date", "Exposure Method",
                                                       "Measured Exposure Amount", "Leverage Percent of Net Assets"]),
            ("31", "VaR Test Result", ["VaR Test Fund", "VaR Test Date", "VaR Test Regime", "VaR Test Value",
                                       "VaR Test Pass Indicator"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Share Class",
                                          "Return Period Start Date", "Return Period End Date", "Return Fee Basis",
                                          "Return Value", "Return Status"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Data Basis", "Snapshot", "Measure Amount"]),
            ("06", "Flow Measures", ["Gross Sales", "Redemptions", "Reinvested Distributions"]),
            ("28", "Securities Loan", ["Securities Loan ID", "Loaned Instrument", "Borrower", "Loan Value", "Loan Mark Date",
                                       "Securities Loan Status"]),
            ("01", "Product Party Role", ["Party", "Party Legal Name", "Party LEI", "Party Role Type", "Role Effective From",
                                          "Role Effective To"]),
            ("01", "Fund Legal Structure", ["Regulatory Regime", "Fund LEI", "Legal Registration Number"]),
        ],
        upstream=["DP-184", "DP-165", "DP-166", "DP-174", "DP-176", "DP-177", "DP-171", "DP-004", "DP-008", "DP-140",
                  "DP-142", "DP-097", "DP-143", "DP-146", "DP-145", "DP-155", "DP-013", "DP-192"],
        refresh="Monthly",
        timeliness="Draft data set by business day 15 after the reporting period end; locked as filed at the filing's Acceptance Timestamp; N-CEN annually after fiscal year-end",
        history="Every draft and as-filed snapshot, each amendment and the source record versions it used, kept permanently for the life of the fund plus 6 years",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "Regulatory report", "File extract", "BI semantic model"],
        dq_rules=[
            "Total Assets Amount - Total Liabilities Amount equals Fund Net Assets Amount for the as-filed NAV of record.",
            "The as-filed NAV is the NAV of record (approved, highest NAV Version Number, official calculation source) for the Reporting Period End Date.",
            "Every reported holding has at least one effective instrument identifier and an Approved Price Fair Value Level.",
            "Liquidity Classification portions of each reported holding sum to 100% of the position.",
            "Every filed value carries a Filing Data Source with a Source Record Key and Source As-Of Date, and no filing is certified unless all its data sources have Source Reconciled Indicator = Y.",
            "An as-filed snapshot is never overwritten; a change after acceptance creates an amended filing's snapshot.",
        ],
        notes=("W4 re-point (CW-906): 06 Measure Value.Share Class dropped; Reported Flows reads the fund's share class rows by "
               "Dimension Type and Dimension Key. "
               "Assembles, never remasters (CD-234, CD-334): net assets, NAV, shares outstanding and market-based NAV from "
               "DP-165 (CD-330); holdings from DP-142 Holdings, Tax Lots & Cash, mapped to the fund through DP-140; "
               "identifiers from DP-097; prices and fair value levels from DP-143; the Rule 22e-4 liquidity classification "
               "family, HLIM, Rule 18f-4 derivatives exposure and VaR tests from DP-155 Fund Liquidity & Derivatives Risk "
               "Programs (Wave E2, specified in parallel; CD-320); interest rate and credit spread sensitivities from DP-146 "
               "Risk Measures; official returns from DP-145 (CD-320); fund-level sales, reinvestments and redemptions from "
               "DP-008 (CD-292, CD-334); liability detail from DP-166 ledger balances; securities lending from DP-174; "
               "service providers from 01 Product Party Role (DP-004) and provider oversight from DP-176. DP-171 is upstream "
               "for N-CEN distribution and RIC items and DP-177 for N-CEN transfer agent items, as the candidate names them; "
               "neither is read at attribute level yet, and they drop if the item map shows no use. DP-156 (PRIIPs and "
               "SRRI indicators, EU and UK disclosure) and DP-157 (attribution and ex-post analytics) were considered and are "
               "not upstream: no N-PORT, N-CEN or N-MFP item reads them. The as-filed snapshot is evidence keyed by REGF- "
               "and is never upstream of a product that needs a current value; the Wave E5 Regulatory Filing Data Hub reads "
               "this product and does not reassemble the forms; DP-184 is the register of the submission. "
               "Operating model (CD-297, CD-331): if an administrator prepares N-PORT (Filing Preparation Model), the "
               "administrator's file is loaded as a Filing Data Source and reconciled to the certified sources; the grain "
               "is unchanged. "
               "PII = Y because Source Sign-Off Employee is a named employee; Return Value, Exposure Portfolio and similar "
               "attributes are tagged personal data in the taxonomy for account-level rows, but this product reads only "
               "fund and share class rows. "
               "Taxonomy gap: there is no form item object (filing x item number x value); as-filed values are held as the "
               "source record values at Source As-Of Date keyed by Filing Data Source, and the item map from source "
               "attributes to form items is a product rule table. "
               "Taxonomy gap: N-MFP weighted average maturity, weighted average life and daily and weekly liquid assets "
               "are not in the taxonomy (Rule 2a-7 liquid asset minimums are 33 compliance rules, CD-213); until they are "
               "added, those items are loaded from the fund accounting or administrator file as a Filing Data Source. "
               "Taxonomy gap: there is no mapping of 27 Fund Ledger Accounts to N-PORT liability items; Reported Liability "
               "Detail uses a product rule table. "
               "Open SME questions: 35 question 3; brief §8 questions 1 and 2. Rests on CD-233, CD-234, CD-292, CD-320, "
               "CD-330, CD-331, CD-334.")),

    "DP-186": dict(
        definition=("The as-filed data set of the adviser's Form PF for the private funds it advises, chiefly the feeder "
                    "funds of the firm's alternative investment access products (01 Feeder Access Terms, CW-166): fund and "
                    "adviser gross and net assets, leverage, portfolio and investor liquidity, exposures and returns, each "
                    "value keyed to its REGF- filing and to the certified source product and record it came from (CD-334). "
                    "Regulatory reporting uses it to assemble and reconcile the filing and to answer regulator queries about "
                    "what was filed. Fund NAV comes from DP-165, returns from DP-145, leverage and liquidity from DP-155 and "
                    "exposures from DP-146; it never recalculates them."),
        business_questions=[
            "What did we report on Form PF for this period, fund by fund, and from which source records?",
            "Which funds and advisers cross the large adviser or reporting thresholds this period, on reported gross assets?",
            "Do reported net assets and leverage tie to the certified NAV and leverage measurements?",
            "Have any filed values changed at source since filing, and does that require an amendment?",
        ],
        grain=("Fund regulatory filing (REGF-; Form PF per adviser filer entity) x reported fund x "
               "filing data source type x source record x source as-of date and version, held as filed"),
        dimensions=["Filing and form type (DP-184)", "Filer entity, adviser (DP-013)", "Reported fund (DP-004)",
                    "Reporting period end", "Feeder access structure (DP-004)", "Exposure method (DP-155)",
                    "Liquidity horizon bucket", "Data source type and source product", "Filing status"],
        measures=[
            ("Reported Net Assets",
             "Fund Net Assets Amount of the NAV of record at the Reporting Period End Date (from DP-165); held as filed.",
             _u("27", "Fund NAV Calculation", "NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                "NAV Approval Status", "Fund Net Assets Amount")
             + _u("27", "Fund Accounting Book", "Book Fund")),
            ("Reported Gross Assets",
             "Total Assets Amount of the NAV of record (from DP-165), held as filed; regulatory assets add uncalled commitments to underlying funds where the form asks for them (a product rule on the feeder book, see notes).",
             _u("27", "Fund NAV Calculation", "Total Assets Amount") + ["Reported Net Assets"]),
            ("Adviser Threshold Test",
             "Sum of Reported Gross Assets over the private funds of each Filer Entity (products with Feeder Access Terms) by Feeder Access Structure at each month-end of the period, compared with the Form PF large adviser thresholds held in the form reference table; the result sets the sections the adviser files.",
             _u("35", "Fund Regulatory Filing", "Filer Entity", "Reporting Period End Date")
             + _u("01", "Feeder Access Terms", "Feeder Access Structure", "Required Investor Qualification") + ["Reported Gross Assets"]),
            ("Reported Leverage",
             "Measured Exposure Amount and Leverage Percent of Net Assets of the Leverage & Exposure Measurement at the period end for each Exposure Method, certified by DP-155; Net Assets Used is checked against Reported Net Assets.",
             _u("31", "Leverage & Exposure Measurement", "Measured Fund", "Leverage Measurement Date", "Exposure Method",
                "Measured Exposure Amount", "Leverage Percent of Net Assets", "Net Assets Used")
             + ["Reported Net Assets"]),
            ("Portfolio and Investor Liquidity",
             "Portfolio Percent Liquidatable and Investor Liquidity Percent by Liquidity Horizon Bucket at the period end (from DP-155), with the cumulative gap of investor over portfolio liquidity per bucket, held as filed.",
             _u("31", "Liquidity Horizon Bucket", "Bucket Fund", "Bucket Measurement Date", "Liquidity Horizon Bucket",
                "Portfolio Percent Liquidatable", "Investor Liquidity Percent", "Bucket Data Basis")),
            ("Reported Exposures",
             "Exposure Value and Exposure Percent of Net Assets by Exposure Dimension, Exposure Bucket and Exposure Measure for the fund's portfolio at the period end from the approved run (from DP-146); VaR from the Portfolio Risk Measure where the form asks for it.",
             _u("31", "Portfolio Exposure", "Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run",
                "Exposure Dimension", "Exposure Bucket", "Exposure Measure", "Exposure Value", "Exposure Percent of Net Assets")
             + _u("31", "Portfolio Risk Measure", "Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Measure Value")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implemented Product", "Primary Implementation Indicator")),
            ("Reported Returns",
             "Monthly gross and net Return Value of the fund's share class or portfolio with Return Status final or restated and the highest Return Version (Official Return, from DP-145), by Return Fee Basis, held as filed.",
             _u("32", "Performance Return", "Performance Return ID", "Return Version", "Return Share Class", "Return Portfolio",
                "Return Period Start Date", "Return Period End Date", "Return Fee Basis", "Return Value", "Return Status")),
            ("Data Sources Reconciled %",
             "Filing Data Sources of the filing with Source Reconciled Indicator = Y and Source Sign-Off Employee filled / all data sources of the filing.",
             _u("35", "Filing Data Source", "Source Filing", "Filing Data Source Type", "Source Record Key", "Source Reconciled Indicator", "Source Sign-Off Employee")),
            ("Source Drift Since Filing",
             "For each filed value, the current certified value minus the as-filed value where the source has a later version (higher NAV Version Number or Return Version); count of filings with drift beyond the amendment threshold.",
             _u("27", "Fund NAV Calculation", "NAV Version Number")
             + _u("32", "Performance Return", "Return Version")
             + _u("35", "Filing Data Source", "Source As-Of Date", "Source Data Basis")
             + _u("35", "Fund Regulatory Filing", "Filing Status", "Amended Filing")
             + ["Reported Net Assets", "Reported Returns"]),
        ],
        inputs=[
            ("35", "Fund Regulatory Filing", ["Regulatory Filing ID", "Filing Form Type", "Filer Product", "Filer Entity",
                                              "Covered Series", "Reporting Period End Date", "Filing Due Date",
                                              "Official Filing Date", "Accession Number", "Filing Status", "Amended Filing",
                                              "Confidential Treatment Indicator"]),
            ("35", "Filing Data Source", ["Source Filing", "Filing Data Source Type", "Source Record Key", "Source As-Of Date",
                                          "Source Data Basis", "Source Reconciled Indicator", "Source Sign-Off Employee"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "NAV Approval Status", "Total Assets Amount", "Fund Net Assets Amount"]),
            ("31", "Leverage & Exposure Measurement", ["Measured Fund", "Leverage Measurement Date", "Exposure Method",
                                                       "Measured Exposure Amount", "Net Assets Used",
                                                       "Leverage Percent of Net Assets"]),
            ("31", "Liquidity Horizon Bucket", ["Bucket Fund", "Bucket Measurement Date", "Liquidity Horizon Bucket",
                                                "Portfolio Percent Liquidatable", "Investor Liquidity Percent",
                                                "Bucket Data Basis"]),
            ("31", "Portfolio Exposure", ["Exposure Portfolio", "Exposure As-Of Date", "Exposure Calculation Run",
                                          "Exposure Dimension", "Exposure Bucket", "Exposure Measure", "Exposure Value",
                                          "Exposure Percent of Net Assets"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure",
                                              "Risk Measure Value"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Share Class", "Return Portfolio",
                                          "Return Period Start Date", "Return Period End Date", "Return Fee Basis",
                                          "Return Value", "Return Status"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Product",
                                                     "Primary Implementation Indicator"]),
            ("01", "Fund Legal Structure", ["Regulatory Regime", "Fund Domicile", "Fund LEI", "Master-Feeder Role"]),
            ("01", "Feeder Access Terms", ["Feeder Access Structure", "Underlying Fund Instrument", "Required Investor Qualification"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
        ],
        upstream=["DP-184", "DP-165", "DP-004", "DP-013", "DP-140", "DP-142", "DP-146", "DP-145",
                  "DP-155", "DP-192"],
        refresh="Quarterly",
        timeliness="Draft data set by business day 30 after the quarter end (Form PF quarterly sections), or after fiscal year-end for annual filers; locked as filed at the filing's Acceptance Timestamp",
        history="Every draft and as-filed snapshot, each amendment and the source record versions it used, kept permanently for the life of the fund plus 6 years",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "Regulatory report", "File extract", "BI semantic model"],
        dq_rules=[
            "Every reported fund has Reported Net Assets from exactly one source, the NAV of record in 27, and every private fund reported is a DP-004 product with Feeder Access Terms or a Regulatory Regime of private fund.",
            "Net Assets Used of each reported leverage measurement equals Reported Net Assets for the same fund and date within one currency unit.",
            "Portfolio Percent Liquidatable is non-decreasing across Liquidity Horizon Buckets and reaches 100% in the last bucket.",
            "Every filed value carries a Filing Data Source with a Source Record Key and Source As-Of Date, and no filing is submitted unless all its data sources have Source Reconciled Indicator = Y.",
            "An as-filed snapshot is never overwritten; a change after acceptance creates an amended filing's snapshot.",
        ],
        notes=("W4 re-scope to Form PF data (CW-930, CW-166, CW-938): 30 Private Fund Profile, Investor Commitment, Investor "
               "Capital Account, Fund Credit Facility and Facility Drawdown and 32 Private Markets Performance Measure dropped, no "
               "successor; the private fund dimension is 01 Feeder Access Terms (feeder, tender-offer and interval funds) and the "
               "feeder book's 18 portfolio (through DP-140); 31 Leverage & Exposure Measurement.Fund Borrowing Facility dropped. "
               "With them the measures Reported Borrowings, Investor Concentration, Benefit Plan Investor % and Reported Private "
               "Fund IRR and Multiples, the investor concentration business question, and DP-116 and DP-139 upstream are removed; "
               "Reported Net Assets reads the NAV of record only. AIFMD Annex IV leaves with the US-only pass (no EU AIFM); the "
               "register name keeps it until WP0 (framework.py is the lead's). Taxonomy gap: Form PF investor concentration and "
               "beneficial ownership by investor type have no source now that 30 is gone; 15 Alternative Investment "
               "Subscription could supply them at WP0. "
               "Same assembly rule as DP-185 (CD-334): it never computes a measure its source certifies and is never upstream "
               "of a product that needs a current value. Feeder and pooled fund NAV from DP-165 (CD-292, CD-330); official "
               "returns from DP-145 (32, CD-320); Rule 18f-4 and Section 18 leverage and the "
               "liquidity horizon buckets from DP-155 Fund Liquidity & Derivatives Risk Programs (31, CD-214; Wave E2, "
               "specified in parallel); exposures and VaR from DP-146. DP-156 (PRIIPs and SRRI) and DP-157 (attribution and ex-post analytics) were "
               "considered and are not upstream: no Form PF item used here reads them. DP-142 is upstream for "
               "the fund's portfolio key behind exposures (through DP-140). Form PF is an adviser filing (Filer Entity), a 35 "
               "REGF- record registered by DP-184 (CD-233). "
               "Operating model (CD-297, CD-331): if feeder fund administration is outsourced, the administrator's NAV "
               "files enter through DP-165, not here; if a filing agent prepares the form, its file is a Filing Data "
               "Source and the grain is unchanged. "
               "PII = Y: Source Sign-Off Employee is a named employee; the as-filed outputs are fund-level only. "
               "Taxonomy gap: there is no form item object (filing x item number x value); as-filed values are held as "
               "source record values keyed by Filing Data Source, as in DP-185. "
               "Taxonomy gap: Form PF thresholds and item definitions (large adviser thresholds) are not in the taxonomy; Adviser Threshold Test uses a form reference table kept with "
               "this product. "
               
               "Open SME questions: 35 question 3; brief §8 question 1. Rests on CD-214, CD-233, CD-234, CD-292, "
               "CD-320, CD-330, CD-331, CD-334.")),
}
