"""Data product specifications: Wave E4 Corporate Compliance & Regulatory Affairs (38) and Legal & Corporate Governance (39)
consumer-aligned products DP-222 to DP-230. See CONTRACT.md.

Brief: 00_Program/Expansion/Product_Briefs/Corporate_Risk_Compliance_Legal_and_Technology.md
Candidates: _tools/consolidation/proposals_dp_corporate_b.py
"""

SPECS = {
    # ================================== 38 Corporate Compliance & Regulatory Affairs ==================================
    "DP-222": dict(
        definition=("The calendar and status of every regulated entity's authorizations (SEC, FINRA, state registrations and "
                    "notice filings, broker-dealer, transfer agent and trust company registrations, the SEC Large Trader "
                    "registration), its firm-level regulatory filings (Form ADV, Form CRS, Form BD, Form 13F, Form 13H, "
                    "Schedules 13D and 13G) against due dates, and the ownership disclosure determinations "
                    "that aggregate the firm's holdings of an issuer's security class by regime and aggregation entity and "
                    "decide whether a filing is required. It tells Regulatory Affairs which filings are due or late, which "
                    "holdings crossed a threshold without a filing, and whether the aggregated percentage ties back to the "
                    "book of record. It owns no certified metric family; holdings come from DP-142 (Portfolio Market Value "
                    "is never AUM) and shares outstanding from DP-097."),
        business_questions=[
            "Which firm regulatory filings are due in the next 30 and 90 days by filer entity and form type, and which were filed late or are overdue?",
            "Which authorizations and state notice filings are active by entity, regulator and jurisdiction, and which annual filings or renewals fall due in the next 90 days?",
            "Which issuers and security classes crossed a disclosure threshold this period, under which regime, and was the resulting filing made on time?",
            "Does each aggregated ownership percentage reconcile to the holdings in the book of record and the issuer's shares outstanding?",
            "Which Schedule 13G positions are held where passive eligibility is lost or an engagement is under review?",
        ],
        grain=("Entity authorization (legal entity x regulator x authorization type x authorization jurisdiction) x as-of date, "
               "with child grains of firm filing submission (filer entity x form type x period x submission sequence) "
               "and ownership disclosure determination "
               "(security class x disclosure regime x aggregation entity x determination date)"),
        dimensions=["As-of date and filing period", "Filer / authorized legal entity and entity category", "Regulator",
                    "Authorization type and jurisdiction", "Filing form type and submission type", "Firm filing status",
                    "Disclosure regime", "Issuer and security class", "Aggregation entity"],
        measures=[
            ("Active Authorizations", "Count of Entity Authorizations with Authorization Status = active and Authorization End Date empty or after the as-of date, by Authorized Entity, Regulator, Authorization Type and Authorization Jurisdiction.",
             [("38", "Entity Authorization", "Authorization ID"), ("38", "Entity Authorization", "Authorization Status"),
              ("38", "Entity Authorization", "Authorization End Date"), ("38", "Entity Authorization", "Authorized Entity"),
              ("38", "Entity Authorization", "Regulator"), ("38", "Entity Authorization", "Authorization Type"),
              ("38", "Entity Authorization", "Authorization Jurisdiction")]),
            ("Upcoming Entity Filing", "Active Entity Authorizations with Annual Filing Due Date within 90 days of the as-of date (the enterprise version of the DP-083 measure of the same name; DP-083 keeps its distribution slice).",
             [("38", "Entity Authorization", "Annual Filing Due Date"), ("38", "Entity Authorization", "Authorization Status")]),
            ("Firm Filing Timeliness %", "Firm Regulatory Filings with Filing Submission Type = original whose Filing Submitted Timestamp (date part, ET) <= Filing Due Date / original filings with Filing Due Date in the period, by Filing Form Type and Filer Entity. Amendments are excluded from the denominator.",
             [("38", "Firm Regulatory Filing", "Filing Submission Type"), ("38", "Firm Regulatory Filing", "Filing Submitted Timestamp"),
              ("38", "Firm Regulatory Filing", "Filing Due Date"), ("38", "Firm Regulatory Filing", "Filing Form Type"),
              ("38", "Firm Regulatory Filing", "Filer Entity")]),
            ("Overdue Firm Filings", "Count of Firm Regulatory Filings with Filing Due Date before the as-of date, Filing Submitted Timestamp empty and Firm Filing Status not withdrawn, aged in calendar days past Filing Due Date.",
             [("38", "Firm Regulatory Filing", "Filing Due Date"), ("38", "Firm Regulatory Filing", "Filing Submitted Timestamp"),
              ("38", "Firm Regulatory Filing", "Firm Filing Status")]),
            ("Amendment Rate", "Filings with Amended Firm Filing populated / original filings submitted in the period, by Filing Form Type; a high rate signals data quality problems in the source of the filing.",
             [("38", "Firm Regulatory Filing", "Amended Firm Filing"), ("38", "Firm Regulatory Filing", "Filing Submission Type"),
              ("38", "Firm Regulatory Filing", "Filing Form Type")]),
            ("Threshold Crossings", "Count of Ownership Disclosure Determinations with Filing Required Indicator = Y and Determination Date in the period, by Disclosure Regime and Aggregation Entity.",
             [("38", "Ownership Disclosure Determination", "Filing Required Indicator"),
              ("38", "Ownership Disclosure Determination", "Determination Date"),
              ("38", "Ownership Disclosure Determination", "Disclosure Regime"),
              ("38", "Ownership Disclosure Determination", "Aggregation Entity")]),
            ("Unfiled Required Disclosure Flag", "Y where a determination has Filing Required Indicator = Y and either Resulting Firm Filing is empty after the regime's due date, or the resulting filing's Filing Submitted Timestamp is after its Filing Due Date.",
             [("38", "Ownership Disclosure Determination", "Filing Required Indicator"),
              ("38", "Ownership Disclosure Determination", "Resulting Firm Filing"),
              ("38", "Firm Regulatory Filing", "Firm Filing ID"), ("38", "Firm Regulatory Filing", "Filing Submitted Timestamp"),
              ("38", "Firm Regulatory Filing", "Filing Due Date")]),
            ("Recomputed Ownership %", "Sum of Holding Quantity (long minus short, by Long / Short Indicator) of the Disclosure Security Class on the Determination Date, in the Holding View the regime requires, across portfolios whose Legal Owner Entity or Managing Entity is the Aggregation Entity or one of its subsidiaries under Entity Ownership Relationship, divided by Shares Outstanding (from DP-097, latest Shares Outstanding As-Of Date on or before the Determination Date). Holdings from DP-142, portfolios from DP-140.",
             [("18", "Portfolio Holding", "Holding Quantity"), ("18", "Portfolio Holding", "Long / Short Indicator"),
              ("18", "Portfolio Holding", "Held Instrument"), ("18", "Portfolio Holding", "Holding Date"),
              ("18", "Portfolio Holding", "Holding View"), ("18", "Portfolio Holding", "Holding Portfolio"),
              ("18", "Portfolio", "Legal Owner Entity"), ("18", "Portfolio", "Managing Entity"),
              ("09", "Entity Ownership Relationship", "Child Entity"), ("09", "Entity Ownership Relationship", "Parent Entity"),
              ("17", "Equity Terms", "Shares Outstanding"), ("17", "Equity Terms", "Shares Outstanding As-Of Date"),
              ("38", "Ownership Disclosure Determination", "Disclosure Security Class"),
              ("38", "Ownership Disclosure Determination", "Determination Date"),
              ("38", "Ownership Disclosure Determination", "Aggregation Entity")]),
            ("Aggregation Variance", "Aggregated Ownership Percentage - Recomputed Ownership %, in percentage points; flagged where the absolute variance exceeds 0.05 points or the two sit on different sides of a regime threshold.",
             [("38", "Ownership Disclosure Determination", "Aggregated Ownership Percentage"), "Recomputed Ownership %"]),
            ("Passive Eligibility Review Flag", "Y where the determination's Disclosure Regime is a Schedule 13G regime and Passive Investor Eligibility Indicator = N, or Reviewed Engagement is populated (a stewardship engagement may defeat passive status).",
             [("38", "Ownership Disclosure Determination", "Disclosure Regime"),
              ("38", "Ownership Disclosure Determination", "Passive Investor Eligibility Indicator"),
              ("38", "Ownership Disclosure Determination", "Reviewed Engagement")]),
        ],
        inputs=[
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Regulator", "Authorization Type",
                                            "Regulator Reference Number", "Authorization Status", "Authorization Effective Date",
                                            "Permitted Activities", "Requirements / Limitations", "Annual Filing Due Date",
                                            "Authorization Jurisdiction", "Authorization End Date"]),
            ("38", "Firm Regulatory Filing", ["Firm Filing ID", "Filer Entity", "Filing Form Type", "Filing Submission Type",
                                              "Filing Period End Date", "Filing Due Date", "Filing Submitted Timestamp",
                                              "Filing Regulator Reference", "Firm Filing Status", "Amended Firm Filing"]),
            ("38", "Ownership Disclosure Determination", ["Disclosure Issuer", "Disclosure Security Class", "Disclosure Regime",
                                                          "Determination Date", "Aggregation Entity",
                                                          "Aggregated Ownership Percentage", "Passive Investor Eligibility Indicator",
                                                          "Reviewed Engagement", "Filing Required Indicator", "Resulting Firm Filing"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category", "Jurisdiction of Formation", "Entity Status"]),
            ("09", "Legal Entity Identifier", ["LEI", "SEC CIK", "Firm CRD Number"]),
            ("09", "Entity Ownership Relationship", ["Child Entity", "Parent Entity", "Relationship Type", "Ownership Percentage",
                                                     "Ownership Effective From"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View",
                                         "Holding Quantity", "Long / Short Indicator"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Legal Owner Entity", "Managing Entity"]),
            ("17", "Instrument", ["Instrument ID", "Issuer", "Instrument Type", "Asset Class", "Instrument Status"]),
            ("17", "Equity Terms", ["Equity Share Type", "Voting Rights Per Share", "Shares Outstanding", "Shares Outstanding As-Of Date"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Country of Risk", "CUSIP Issuer Number"]),
            ("02", "Party", ["Party ID", "Party Display Name", "Party Status"]),
        ],
        upstream=["DP-013", "DP-142", "DP-140", "DP-097", "DP-098", "DP-240"],
        refresh="Daily",
        timeliness="By 8am ET each business day for authorizations, filings and the prior day's ownership determinations; ownership determinations rerun intraday on request when a position approaches a threshold",
        history="Filings, determinations and authorization status changes kept as SCD type 2 for at least 6 years after the filing or determination (Advisers Act Rule 204-2 and SEA Rule 17a-4); daily as-of snapshots of the filing calendar kept 3 years",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Firm Regulatory Filing has a Filer Entity that resolves to an Internal Legal Entity and a Filing Due Date on or after its Filing Period End Date.",
            "Every Entity Authorization with Authorization Status = active has a Regulator Reference Number and an Authorized Entity that resolves to an Internal Legal Entity with Entity Status active.",
            "Every Ownership Disclosure Determination has an Aggregated Ownership Percentage between 0 and 100 and a Disclosure Security Class that resolves to an Instrument in DP-097.",
            "Every determination with Filing Required Indicator = Y has a Resulting Firm Filing within the regime's filing window, or appears in Unfiled Required Disclosure Flag.",
            "An amendment's Amended Firm Filing resolves to a filing with the same Filer Entity, Filing Form Type and Filing Period End Date.",
            "Aggregation Variance is within 0.05 percentage points for every determination before the resulting filing is submitted.",
        ],
        notes=("W4 re-point (CW-938, CW-162): 38 Cross-Border Passport dropped, no successor (the firm's EU and UK entities and "
               "their passports leave with the US-only pass), with the measure Passport Without Home Authorization Flag, the "
               "passport business question, the passport child grain and the host country dimension; the EU and UK major "
               "holdings, short position, CASS CMAR and DTR 5 text leaves the definition and notes. The broker-dealer, transfer "
               "agent and trust company registrations and the Form CRS filing are new Entity Authorization and Firm Regulatory "
               "Filing values (CW-162); WP0 may add 38 Form CRS Filing Detail and Adviser Custody Profile as inputs. "
               "Boundaries: DP-013 keeps publishing Entity Authorization as legal entity reference and DP-041 as cross-border "
               "sale eligibility (CD-298, DP-013 stays); this product monitors the filing obligations and status changes and "
               "owns the enterprise filing calendar (brief §3). Fund filings (N-PORT, N-CEN, Form PF) are 35 "
               "(CD-233, CD-251) and belong to the Fund Operations products; distribution filings stay 08 and financial "
               "and capital returns 19. Under CD-351 DP-083 keeps its distribution 'Upcoming Entity Filing' slice; the "
               "enterprise calendar is published here. Aggregated Ownership Percentage is mastered in 38 (CD-251); the "
               "Recomputed Ownership % is a reconciliation only and never replaces it. Holdings are read from DP-142 and "
               "portfolio ownership from DP-140; Portfolio Market Value is not used, and no AUM is shown. PII = N: no "
               "personal data is read. The Large Trader ID is held once, as the Regulator Reference Number of the SEC Large "
               "Trader authorization (38 Source Notes). Thresholds (5% for 13D / 13G and the Section 13(f) "
               "and 13(h) filing tests) and the Holding View each regime requires are "
               "maintained by Regulatory Affairs and are not hard-coded; the 0.05 point tolerance is a drafting assumption "
               "to confirm. Taxonomy gap: Ownership Disclosure Determination holds no threshold crossed, no numerator "
               "(shares held) and no shares outstanding used, so the variance is computed against DP-097's latest Shares "
               "Outstanding rather than the figure the determination used. Taxonomy gap: Firm Regulatory Filing has no "
               "acceptance timestamp or regulator outcome (Firm Filing Status carries it). Open SME questions (38 Source "
               "Notes 1, 6): is the move of 09 Entity Authorization to 38 accepted; which entities file Form 13F and 13H, "
               "and is aggregation at entity or group level. Decisions: CD-250, CD-251, CD-298, CD-293. "
               "W1: FCA Firm Reference Number (09 Legal Entity Identifier) dropped, no successor in the wealth 09 (CW-909); "
               "no measure read it. FCA, CSSF and CBI authorizations named above are a 38 US-only re-cut question (W4). "
               "PII stays N although the wealth 02 flags every Party attribute as personal data (a party may be an "
               "individual): the parties read here are issuers and filers, which are organizations (CW-902)."),
    ),

    "DP-223": dict(
        definition=("Regulatory examinations, sweeps and inquiries of every regulated entity, with each regulator request "
                    "item and its response timeliness, each examination finding with its response and the 37 Risk Issue that "
                    "remediates it, the referral to a 39 legal matter where an exam turns into enforcement, and the "
                    "regulatory change items from horizon to compliance date with their impact by entity, business line and "
                    "Data Domain and the 41 project that delivers them. It lets the CCO see which regulator requests are "
                    "late, which findings are unremediated, and which changes with a near compliance date have no impact "
                    "assessment or delivering project. Remediation open and overdue status is taken from DP-216 (CD-356); "
                    "the product owns no certified metric family."),
        business_questions=[
            "Which examinations and inquiries are open, by regulator and entity, and which request items are due this week or already late?",
            "What share of request items and finding responses were delivered on time in the last 12 months?",
            "Which examination findings have no remediating risk issue, and which remediation is overdue, by finding severity?",
            "Which examinations were referred to enforcement as a legal matter?",
            "Which regulatory changes reach their compliance date in the next 12 months, and which have no impact assessment or no delivering project?",
        ],
        grain=("Examination (EXAM-) x as-of date, with child grains of request item (examination x request sequence) and "
               "finding (examination x finding sequence); and regulatory change item (REGCH-) x impacted scope (legal entity, "
               "business line or Data Domain) x as-of date"),
        dimensions=["As-of date", "Examining regulator and examination type", "Examined legal entity", "Examination status",
                    "Finding severity", "Change regulator and instrument type", "Regulatory change stage", "Compliance date month",
                    "Impacted entity, business line and Data Domain", "Impact rating and implementation status", "Delivering project"],
        measures=[
            ("Open Examinations", "Count of Regulatory Examinations with Examination Status not closed and Examination Closed Date empty, by Examination Type and Examining Regulator.",
             [("38", "Regulatory Examination", "Examination ID"), ("38", "Regulatory Examination", "Examination Status"),
              ("38", "Regulatory Examination", "Examination Closed Date"), ("38", "Regulatory Examination", "Examination Type"),
              ("38", "Regulatory Examination", "Examining Regulator")]),
            ("Examination Duration", "Business days from Examination Notice Date to Examination Closed Date for closed examinations; days to the as-of date for open ones.",
             [("38", "Regulatory Examination", "Examination Notice Date"), ("38", "Regulatory Examination", "Examination Closed Date")]),
            ("Request Timeliness %", "Request items with Request Produced Date <= Request Due Date / request items with Request Due Date in the period, by examination and regulator.",
             [("38", "Regulator Request Item", "Request Produced Date"), ("38", "Regulator Request Item", "Request Due Date"),
              ("38", "Regulator Request Item", "Request Examination")]),
            ("Overdue Requests", "Request items with Request Due Date before the as-of date and Request Produced Date empty, with the count awaiting privilege review (Privilege Review Required Indicator = Y).",
             [("38", "Regulator Request Item", "Request Due Date"), ("38", "Regulator Request Item", "Request Produced Date"),
              ("38", "Regulator Request Item", "Privilege Review Required Indicator")]),
            ("Finding Response Timeliness %", "Findings with Response Sent Date <= Response Due Date / findings with Response Due Date in the period, by Finding Severity.",
             [("38", "Examination Finding", "Response Sent Date"), ("38", "Examination Finding", "Response Due Date"),
              ("38", "Examination Finding", "Finding Severity")]),
            ("Findings Without Remediation Issue", "Count of Examination Findings (Finding Examination x Finding Sequence) with no Risk Issue whose Issue Source Type = Regulatory Finding and Source Examination Finding references the finding.",
             [("38", "Examination Finding", "Finding Examination"), ("38", "Examination Finding", "Finding Sequence"),
              ("37", "Risk Issue", "Issue Source Type"), ("37", "Risk Issue", "Source Examination Finding")]),
            ("Overdue Finding Remediation", "Count of findings whose remediating Risk Issue is overdue, by Finding Severity. The overdue status (Issue Status open and Issue Due Date passed) is the one DP-216 publishes and is not recomputed here (CD-356).",
             [("37", "Risk Issue", "Risk Issue ID"), ("37", "Risk Issue", "Issue Status"), ("37", "Risk Issue", "Issue Due Date"),
              ("37", "Risk Issue", "Source Examination Finding"), ("38", "Examination Finding", "Finding Severity")]),
            ("Examinations Referred to Enforcement", "Count of examinations with at least one Legal Matter whose Originating Examination is the examination (CD-253), by Legal Matter Type; matter detail is not shown.",
             [("39", "Legal Matter", "Legal Matter ID"), ("39", "Legal Matter", "Originating Examination"),
              ("39", "Legal Matter", "Legal Matter Type"), ("38", "Regulatory Examination", "Examination ID")]),
            ("Change Items Due 12m", "Regulatory Change Items with Change Compliance Date within 12 months of the as-of date, by Change Regulator, Change Instrument Type and Regulatory Change Stage.",
             [("38", "Regulatory Change Item", "Regulatory Change ID"), ("38", "Regulatory Change Item", "Change Compliance Date"),
              ("38", "Regulatory Change Item", "Change Regulator"), ("38", "Regulatory Change Item", "Change Instrument Type"),
              ("38", "Regulatory Change Item", "Regulatory Change Stage")]),
            ("Unassessed Change Flag", "Y where a change item has Change Compliance Date within 180 days and no Regulatory Change Impact row with Impacted Change Item = the item and Impact Rating populated.",
             [("38", "Regulatory Change Item", "Change Compliance Date"), ("38", "Regulatory Change Impact", "Impacted Change Item"),
              ("38", "Regulatory Change Impact", "Impact Rating")]),
            ("Undelivered Change Flag", "Y where a change item has an impact with Impact Rating high or medium and Impact Implementation Status not complete, and either no Project Scope Link in effect has Delivered Regulatory Change Item = the item, or the delivering Project's Planned End Date is after Change Compliance Date, or its Project Status is canceled.",
             [("38", "Regulatory Change Impact", "Impact Rating"), ("38", "Regulatory Change Impact", "Impact Implementation Status"),
              ("41", "Project Scope Link", "Delivered Regulatory Change Item"), ("41", "Project Scope Link", "Scope Link Effective To"),
              ("41", "Project Scope Link", "Scoping Project"), ("41", "Project", "Project ID"),
              ("41", "Project", "Planned End Date"), ("41", "Project", "Project Status"),
              ("38", "Regulatory Change Item", "Change Compliance Date")]),
            ("Horizon Items Without Change Item", "11 Regulatory Horizon Items with Expected Effective Date within 12 months for which no Regulatory Change Item cites the Regulatory Initiative as its Source Horizon Item: initiatives the market intelligence team flagged that compliance has not taken on.",
             [("11", "Regulatory Horizon Item", "Regulatory Initiative"), ("11", "Regulatory Horizon Item", "Expected Effective Date"),
              ("38", "Regulatory Change Item", "Source Horizon Item")]),
        ],
        inputs=[
            ("38", "Regulatory Examination", ["Examination ID", "Examination Type", "Examining Regulator", "Examined Entities",
                                              "Examination Scope", "Examination Notice Date", "Examination Closed Date",
                                              "Examination Status"]),
            ("38", "Regulator Request Item", ["Request Examination", "Request Sequence", "Request Due Date", "Request Produced Date",
                                              "Privilege Review Required Indicator"]),
            ("38", "Examination Finding", ["Finding Examination", "Finding Sequence", "Deficiency Description", "Finding Severity",
                                           "Response Due Date", "Response Sent Date"]),
            ("38", "Regulatory Change Item", ["Regulatory Change ID", "Change Regulator", "Change Instrument Type", "Change Title",
                                              "Regulatory Change Stage", "Change Compliance Date", "Source Horizon Item"]),
            ("38", "Regulatory Change Impact", ["Impacted Change Item", "Impacted Entity", "Impacted Business Line",
                                                "Impacted Data Domain", "Impact Rating", "Impact Implementation Status",
                                                "Affected Obligations", "Policies to Update"]),
            ("11", "Regulatory Horizon Item", ["Regulator / Body", "Regulatory Initiative", "Initiative Stage", "Expected Effective Date"]),
            ("41", "Project Scope Link", ["Scoping Project", "Delivered Object Type", "Delivered Regulatory Change Item",
                                          "Scope Link Effective From", "Scope Link Effective To"]),
            ("41", "Project", ["Project ID", "Project Name", "Project Status", "Planned End Date", "Actual End Date"]),
            ("39", "Legal Matter", ["Legal Matter ID", "Legal Matter Type", "Originating Examination", "Matter Status", "Matter Opened Date"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Issue Source Type", "Source Examination Finding", "Issue Rating", "Issue Status",
                                  "Issue Due Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
        ],
        upstream=["DP-013", "DP-216", "DP-234", "DP-229"],
        refresh="Daily",
        timeliness="By 8am ET each business day, covering request items, responses and change item updates to the prior day's close",
        history="Examinations, request items, findings, change items and impacts kept as SCD type 2 for at least 6 years after the examination closes or the change item's compliance date (longest applicable books-and-records rule); daily snapshots of open items kept 3 years",
        classification="Restricted",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Regulator Request Item and Examination Finding has a Request Examination or Finding Examination that resolves to an Examination ID.",
            "Request Produced Date and Response Sent Date are on or after the examination's Examination Notice Date.",
            "An examination with Examination Closed Date populated has an Examination Status of closed, and no request item with Request Produced Date empty.",
            "Every Examination Finding with Finding Severity high has a Risk Issue with Source Examination Finding referencing it within 30 days of Response Sent Date.",
            "Every Regulatory Change Item past the proposal stage has a Change Compliance Date, and every Regulatory Change Impact has exactly one of Impacted Entity, Impacted Business Line or Impacted Data Domain populated.",
        ],
        notes=("Classified Restricted: examination correspondence and findings are confidential supervisory information, "
               "and request text is not carried (Request Text is left out; Deficiency Description is shown to Compliance "
               "and Legal only). PII = N: no employee attributes are read; examination staff and project managers are not "
               "named. Boundaries: enforcement is a 39 Legal Matter that references the exam (CD-253) and is read here only "
               "for the referral count through DP-229; remediation is a 37 Risk Issue whose open and overdue status is "
               "computed once in DP-216 and only grouped here by finding severity (CD-356); delivery is held only on 41 "
               "Project Scope Link (CD-267) and read through DP-234. The 11 Regulatory Horizon Item is read only as the "
               "change item's source; DP-083 keeps the distribution horizon view and reads 11 only (CD-351), so the "
               "enterprise regulatory change register is published here. The candidate's upstream Employee & Position "
               "Master (DP-192) is not listed: no measure needs an employee attribute. Thresholds (180-day assessment "
               "window, 30-day issue creation rule) are drafting assumptions. Taxonomy gap: Regulatory Horizon Item has "
               "no identifier, so the horizon link uses Regulatory Initiative text (the DP-083 gap stands). Taxonomy gap: "
               "Regulatory Examination has no examination owner and no response due date for the exam letter as a "
               "whole. Taxonomy gap: Regulatory Change Impact has no impact assessment date, so the time from horizon to "
               "assessment cannot be measured. Open SME question (39 Source Notes 6): who issues legal holds for "
               "regulatory exams. Decisions: CD-252, CD-253, CD-267, CD-351, CD-356."),
    ),

    "DP-224": dict(
        definition=("The firm's compliance program for every regulated entity: the regulatory obligations register with "
                    "owners and monitoring controls, the policy library with each version's approval and review cycle, "
                    "attestation campaigns and completion by population, the training each policy requires, and the annual "
                    "compliance program reviews (Advisers Act Rule 206(4)-7, Investment Company Act Rule 38a-1, the annual "
                    "AML program report, the report supporting the FINRA Rule 3130 certification) with their conclusions. It is the "
                    "evidence the CCO presents to boards and regulators. It is the enterprise product of which DP-083 "
                    "Regulatory Obligations, Attestations & Horizon is the distribution view (CD-351): it computes obligation "
                    "ownership and Attestation Completion % once, for the whole firm, and DP-083 takes them filtered to "
                    "distribution entities and populations. It owns no certified metric family."),
        business_questions=[
            "Which obligations apply to each regulated entity, who owns each one, and which have no owner, no current compliance assessment or no monitoring control?",
            "What share of required attestations were completed on time this period, by attestation type, campaign, legal entity and org unit, and who is overdue?",
            "Which policies are past their review date or in force without a recorded approval, and which required policy training is incomplete?",
            "Has every regulated entity and fund complex had its annual compliance program review, what did it conclude, and are the material compliance matters remediated?",
            "Which monitoring controls behind obligations were tested by Compliance in the last 12 months, and which failed?",
        ],
        grain=("Regulatory obligation (OBL-) x as-of date, with child grains of policy x version, attestation (attester x "
               "attestation type x attestation period), and compliance program review (reviewed entity or fund complex x "
               "program review type x review period)"),
        dimensions=["As-of date and attestation period", "Applicable legal entity and entity category", "Source regulation and rule citation",
                    "Obligation owner, org unit and line manager", "Policy domain and policy status", "Approving body",
                    "Attestation type, campaign and status", "Program review type and conclusion", "Covered products"],
        measures=[
            ("Obligations Without Monitoring Control", "Count of obligations in effect with Monitoring Control empty, or resolving to a Control whose Control Version Effective To is before the as-of date.",
             [("38", "Regulatory Obligation", "Monitoring Control"), ("37", "Control", "Control ID"),
              ("37", "Control", "Control Version Effective To")]),
            ("Compliance Testing Coverage %", "Obligations whose Monitoring Control has a Control Test with Testing Line = Compliance and Control Test Date in the last 12 months / obligations with a Monitoring Control; failed tests (Control Test Result = ineffective) are counted alongside. Test results are those DP-214 publishes.",
             [("38", "Regulatory Obligation", "Monitoring Control"), ("37", "Control Test", "Tested Control"),
              ("37", "Control Test", "Testing Line"), ("37", "Control Test", "Control Test Date"),
              ("37", "Control Test", "Control Test Result")]),
            ("Policies Overdue for Review", "Count of Policies with Policy Status active whose latest approved Policy Version has Version Effective From + Policy Review Frequency before the as-of date, by Policy Domain and Policy Owner.",
             [("38", "Policy", "Policy ID"), ("38", "Policy", "Policy Status"), ("38", "Policy", "Policy Review Frequency"),
              ("38", "Policy", "Policy Domain"), ("38", "Policy", "Policy Owner"),
              ("38", "Policy Version", "Versioned Policy"), ("38", "Policy Version", "Version Approval Status"),
              ("38", "Policy Version", "Version Effective From")]),
            ("Policy Version Without Recorded Approval", "Y where a Policy Version in force (Version Effective From <= as-of date, Version Effective To empty or later) has Version Approval Date empty, or names an entity board as Approving Body and no adopted Corporate Resolution has a Corporate Resolution Subject Link with Subject Policy Version = the version (CD-259).",
             [("38", "Policy Version", "Version Effective From"), ("38", "Policy Version", "Version Effective To"),
              ("38", "Policy Version", "Version Approval Date"), ("38", "Policy Version", "Approving Body"),
              ("39", "Corporate Resolution Subject Link", "Subject Policy Version"),
              ("39", "Corporate Resolution Subject Link", "Linked Corporate Resolution"),
              ("39", "Corporate Resolution", "Corporate Resolution ID"), ("39", "Corporate Resolution", "Corporate Resolution Outcome")]),
            ("Policy Attestation Coverage %", "Active employees of the Policy Applicable Entities with an Attestation whose Attested Policy Version is the version in force and Attestation Status = completed / active employees of those entities, by policy.",
             [("38", "Policy", "Policy Applicable Entities"), ("38", "Attestation", "Attested Policy Version"),
              ("38", "Attestation", "Attestation Status"), ("20", "Employee", "Employing Legal Entity"),
              ("20", "Employee", "Employment Status")]),
            ("Required Training Completion %", "Learning Completions whose Completed Learning Item is the Required Training of a Policy Version in force, with Completion Status = completed and Completion Date <= Completion Due Date / such completions due in the period.",
             [("38", "Policy Version", "Required Training"), ("20", "Learning Completion", "Completed Learning Item"),
              ("20", "Learning Completion", "Learner Employee"), ("20", "Learning Completion", "Completion Status"),
              ("20", "Learning Completion", "Completion Date"), ("20", "Learning Completion", "Completion Due Date")]),
            ("Program Review Currency Flag", "Y where a regulated entity (or fund complex for Rule 38a-1) has no Compliance Program Review of each required Program Review Type with Review Period End in the last 12 months and Review Report Date populated.",
             [("38", "Compliance Program Review", "Reviewed Entity"), ("38", "Compliance Program Review", "Program Review Type"),
              ("38", "Compliance Program Review", "Review Period End"), ("38", "Compliance Program Review", "Review Report Date"),
              ("38", "Entity Authorization", "Authorized Entity"), ("38", "Entity Authorization", "Authorization Status")]),
            ("Program Review Conclusions", "Count of program reviews by Program Assessment Conclusion and Program Review Type in the period, with the number that report Material Compliance Matters.",
             [("38", "Compliance Program Review", "Program Assessment Conclusion"), ("38", "Compliance Program Review", "Program Review Type"),
              ("38", "Compliance Program Review", "Material Compliance Matters")]),
            ("Open Program Review Remediation", "Count of Risk Issues with Issue Source Type = compliance program review and Source Compliance Program Review referencing a review, split open and overdue as published by DP-216 (CD-356), by Reviewed Entity.",
             [("37", "Risk Issue", "Risk Issue ID"), ("37", "Risk Issue", "Issue Source Type"),
              ("37", "Risk Issue", "Source Compliance Program Review"), ("37", "Risk Issue", "Issue Status"),
              ("37", "Risk Issue", "Issue Due Date"), ("38", "Compliance Program Review", "Reviewed Entity")]),
        ],
        inputs=[
            ("38", "Regulatory Obligation", ["Obligation ID", "Source Regulation", "Rule Citation", "Obligation Summary",
                                             "Applicable Legal Entity", "Obligation Owner", "Compliance Assessment",
                                             "Obligation Effective From", "Obligation Effective To", "Monitoring Control"]),
            ("38", "Policy", ["Policy ID", "Policy Title", "Policy Domain", "Policy Owner", "Policy Applicable Entities",
                              "Policy Regulatory Basis", "Policy Review Frequency", "Policy Status"]),
            ("38", "Policy Version", ["Versioned Policy", "Policy Version Number", "Version Approval Status", "Approving Body",
                                      "Version Approval Date", "Version Effective From", "Version Effective To", "Required Training"]),
            ("38", "Attestation", ["Attestation Type", "Attester", "Attestation Completed Date", "Attestation Status",
                                   "Attestation Period", "Attestation Campaign", "Attested Policy Version"]),
            ("38", "Compliance Program Review", ["Program Review Type", "Reviewed Entity", "Covered Products", "Review Period End",
                                                 "Review Lead", "Review Report Date", "Program Assessment Conclusion",
                                                 "Material Compliance Matters"]),
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Regulator", "Authorization Type", "Authorization Status"]),
            ("37", "Control", ["Control ID", "Control Version", "Control Objective", "Control Type", "Key Control Indicator",
                               "Control Version Effective To"]),
            ("37", "Control Test", ["Tested Control", "Control Test Date", "Testing Line", "Control Test Result"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Issue Source Type", "Source Compliance Program Review", "Issue Rating",
                                  "Issue Status", "Issue Due Date"]),
            ("39", "Corporate Resolution", ["Corporate Resolution ID", "Corporate Resolution Outcome", "Corporate Resolution Effective Date"]),
            ("39", "Corporate Resolution Subject Link", ["Linked Corporate Resolution", "Corporate Resolution Subject Type",
                                                         "Subject Policy Version"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Legal Last Name", "Job Title", "Employing Legal Entity",
                                "Home Org Unit", "Employment Status"]),
            ("20", "Employee Reporting Line", ["Reporting Employee", "Line Manager", "Reporting Line Type", "Reporting Effective From",
                                               "Reporting Effective To"]),
            ("20", "Learning Completion", ["Learner Employee", "Completed Learning Item", "Completion Due Date", "Completion Status",
                                           "Completion Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category", "Entity Status"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name", "Org Unit Type"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type"]),
        ],
        upstream=["DP-013", "DP-214", "DP-216", "DP-192", "DP-230", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET each business day; attestation status refreshed every 4 hours during an open attestation campaign",
        history="Obligations, policies and policy versions kept as SCD type 2 for 7 years after retirement; attestation records kept 7 years after the attestation period (longer where a governing rule requires); program reviews kept at least 6 years (Rule 38a-1(d), Rule 204-2); weekly snapshots of the obligation register kept 7 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Regulatory Obligation has an Obligation ID, a Rule Citation and an Applicable Legal Entity that resolves to an Internal Legal Entity, and Obligation ID is unique for each Rule Citation x Applicable Legal Entity.",
            "Every Attestation has an Attester that resolves to an Employee ID, an Attestation Period and an Attestation Campaign, and Attestation Completed Date is populated if and only if Attestation Status = completed.",
            "Every Policy Version with Version Approval Status approved has a Version Approval Date and an Approving Body, and Version Effective From is on or after Version Approval Date.",
            "At most one Policy Version per Versioned Policy is in force on any date.",
            "Every Compliance Program Review has a Review Report Date on or after its Review Period End and a Program Assessment Conclusion once the report date is populated.",
            "Every Monitoring Control on an obligation resolves to a Control ID in DP-214.",
        ],
        notes=("CD-351: this is the enterprise product; DP-083 keeps its ID, primary function FN-13 and its 11 horizon view, "
               "gains DP-224 upstream and takes Obligation Coverage, Unowned Obligation Flag, Entity Without Obligations "
               "Flag, Attestation Completion % and Overdue Attestation Count from here, filtered to distribution entities "
               "and populations; it must stop computing them (a change to DP-083's spec for the program lead, not made "
               "here). The definitions above are DP-083's, widened to every entity and to the 38 attributes added since "
               "(obligation effective dates, Monitoring Control, attestation period, campaign and attested policy version). "
               "Regulatory change items are published by DP-223 and the enterprise filing calendar by DP-222. CD-252: the "
               "policy library, obligations and attestations are 38. Compliance monitoring tests are 37 Control Test rows "
               "with Testing Line = Compliance (CD-243) read through DP-214; remediation counts come from DP-216 "
               "(CD-356). Policy approvals by entity boards are read from 39 Corporate Resolution Subject Link through "
               "DP-230 (CD-259); fund board approvals are 35 and not read. Version Approval Date is the 39 derived copy on Policy Version; the "
               "approval test also reads the resolution itself from 39. PII = Y: owners, attesters and learners are "
               "named employees; publish an entity- and org-unit-level aggregate for wide distribution. 20 Learning "
               "Completion is read directly from 20 because no foundational product publishes it (DP-192 does not); "
               "re-point if a Corporate A learning product is specified. Taxonomy gap: Attestation has no due date and "
               "Attestation Campaign is a plain attribute with no campaign object, so the due date comes from a "
               "maintained campaign calendar. Taxonomy gap: Policy has no next review date; it is derived from Version "
               "Effective From and Policy Review Frequency. Taxonomy gap: there is no list of which Program Review Types "
               "each entity category requires; the Program Review Currency Flag uses a maintained crosswalk. Open SME "
               "question (38 Source Notes 10): does the policy library include fund policies approved by the 35 board. "
               "Decisions: CD-243, CD-252, CD-259, CD-351, CD-356."
               "WP1 re-point (CW-260): the obligation and attestation measures Obligation Coverage, Unowned Obligation Flag, Entity Without Obligations Flag, Attestation Completion % and Overdue Attestation Count are dropped: the re-scoped DP-083 (specs_w1c_fop_corp.py) now owns them for the whole firm, so the CD-351 split above (computed here, filtered in DP-083) is superseded. The SM-16 metrics on them are removed until DP-083's semantic home is set at WP2. The obligation, attestation and policy inputs stay (Obligations Without Monitoring Control, Compliance Testing Coverage % and the policy measures read them)."),
    ),

    "DP-225": dict(
        definition=("Code of ethics monitoring for access persons, investment persons and covered associates: the population "
                    "designations, personal trading accounts, holdings and transaction reports against due dates, "
                    "pre-clearance decisions matched to trades, trades in restricted names, violations and sanctions, outside "
                    "business activities, political contributions with their pay-to-play outcomes, and the firm conflicts "
                    "register with its mitigations. It shows Compliance which people are late, which trades lacked "
                    "pre-clearance or hit the restricted list, which contributions triggered a time-out, and which conflicts "
                    "lack an effective mitigation, as evidence under Advisers Act Rules 204A-1 and 206(4)-5, Investment "
                    "Company Act Rule 17j-1, FINRA Rules 3270 and 3280, MiFID II Delegated Regulation Articles 29 and 33-35 "
                    "and FCA SYSC 10. It owns no certified metric family."),
        business_questions=[
            "Which access persons are late with initial, annual holdings or quarterly transaction reports, by entity and fund?",
            "Which personal trades had no matching pre-clearance, traded outside the approval window, or traded a security on the restricted list?",
            "What share of pre-clearance requests were denied, and how many were blocked by the restricted list?",
            "Which political contributions exceeded the de minimis amounts, and which triggered a two-year time-out with which government clients?",
            "Which outside business activities are active without approval, and which firm conflicts lack an effective mitigation?",
            "How many code of ethics violations were found this year, by detection source and sanction?",
        ],
        grain=("Conduct population member (employee x designation type x designating entity or fund x effective period) x "
               "reporting period, with child grains of personal securities report, personal transaction, pre-clearance "
               "request, violation, political contribution and outside business activity; and firm conflict (CONFL-) x "
               "mitigation x effective period"),
        dimensions=["Reporting period (quarter, year)", "Designating legal entity or fund", "Conduct designation type",
                    "Employee, org unit and employing entity", "Personal report type", "Pre-clearance decision and reason",
                    "Security and issuer", "Violation detection source and sanction", "Political recipient type and jurisdiction",
                    "Pay-to-play outcome", "Conflict category and register status", "Mitigation type"],
        measures=[
            ("Access Persons", "Count of distinct Designated Employees with a Conduct Population Designation in effect (Designation Effective From <= as-of date, Designation Effective To empty or later), by Conduct Designation Type and Designating Entity or Designating Fund.",
             [("38", "Conduct Population Designation", "Designated Employee"), ("38", "Conduct Population Designation", "Conduct Designation Type"),
              ("38", "Conduct Population Designation", "Designating Entity"), ("38", "Conduct Population Designation", "Designating Fund"),
              ("38", "Conduct Population Designation", "Designation Effective From"), ("38", "Conduct Population Designation", "Designation Effective To")]),
            ("Report Timeliness %", "Personal Securities Reports with Report Submitted Date <= Report Due Date / reports with Report Due Date in the period, by Personal Report Type (initial within 10 days of becoming an access person, quarterly within 30 days of quarter end, annual holdings).",
             [("38", "Personal Securities Report", "Report Submitted Date"), ("38", "Personal Securities Report", "Report Due Date"),
              ("38", "Personal Securities Report", "Personal Report Type")]),
            ("Late or Missing Reports", "Count of reports with Report Due Date before the as-of date and Report Submitted Date empty, plus access persons designated in the period with no initial report row (designation start + 10 calendar days passed).",
             [("38", "Personal Securities Report", "Reporting Access Person"), ("38", "Personal Securities Report", "Report Due Date"),
              ("38", "Personal Securities Report", "Report Submitted Date"), ("38", "Personal Securities Report", "Personal Report Type"),
              ("38", "Conduct Population Designation", "Designated Employee"),
              ("38", "Conduct Population Designation", "Designation Effective From")]),
            ("Unprecleared Trade Flag", "Y where a Personal Transaction in an account with Discretionary Managed Indicator = N has no Matched Pre-Clearance; or the matched request's Pre-Clearance Decision is not approved; or Personal Trade Date is after Approval Valid Until; or Personal Trade Side differs from Pre-Clearance Side; or Personal Trade Quantity exceeds Pre-Clearance Quantity. Exempt instrument types (see notes) are excluded using DP-097 Instrument Type.",
             [("38", "Personal Transaction", "Matched Pre-Clearance"), ("38", "Personal Transaction", "Transaction Account"),
              ("38", "Personal Trading Account", "Personal Account Key"), ("38", "Personal Trading Account", "Discretionary Managed Indicator"),
              ("38", "Pre-Clearance Request", "Pre-Clearance Decision"), ("38", "Pre-Clearance Request", "Approval Valid Until"),
              ("38", "Personal Transaction", "Personal Trade Date"), ("38", "Personal Transaction", "Personal Trade Side"),
              ("38", "Pre-Clearance Request", "Pre-Clearance Side"), ("38", "Personal Transaction", "Personal Trade Quantity"),
              ("38", "Pre-Clearance Request", "Pre-Clearance Quantity"), ("38", "Personal Transaction", "Traded Security"),
              ("17", "Instrument", "Instrument Type")]),
            ("Restricted List Trade Flag", "Y where the Traded Security, or any instrument whose Issuer is the Restricted Issuer, was on a Restricted List Entry of a list that applies to personal trading with Entry Added Timestamp <= Personal Trade Date and Entry Removed Timestamp empty or after it. Entries come from DP-227.",
             [("38", "Personal Transaction", "Traded Security"), ("38", "Personal Transaction", "Personal Trade Date"),
              ("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Issuer"),
              ("38", "Restricted List Entry", "Restricted Issuer"), ("38", "Restricted List Entry", "Restricted Instruments"),
              ("38", "Restricted List Entry", "Entry Added Timestamp"), ("38", "Restricted List Entry", "Entry Removed Timestamp"),
              ("38", "Restricted List Entry", "Entry List"), ("38", "Firm Restricted List", "Restricted List Type")]),
            ("Unreported Transaction Flag", "Y where a Personal Transaction with Personal Trade Date in a quarter whose quarterly report is due has Reported On Report empty and Personal Trading Data Source is a broker feed.",
             [("38", "Personal Transaction", "Reported On Report"), ("38", "Personal Transaction", "Personal Trading Data Source"),
              ("38", "Personal Transaction", "Personal Trade Date")]),
            ("Pre-Clearance Denial Rate", "Requests with Pre-Clearance Decision = denied / requests decided in the period, by Pre-Clearance Decision Reason; the share denied with Blocking Restricted List Entry populated is shown separately.",
             [("38", "Pre-Clearance Request", "Pre-Clearance Decision"), ("38", "Pre-Clearance Request", "Pre-Clearance Decision Reason"),
              ("38", "Pre-Clearance Request", "Blocking Restricted List Entry"), ("38", "Pre-Clearance Request", "Request Timestamp")]),
            ("Violations by Sanction", "Count of Code of Ethics Violations by Violation Detected Date period, Violation Detection Source and Violation Sanction; the count with Source Surveillance Alert populated shows violations found by trade surveillance.",
             [("38", "Code of Ethics Violation", "Violating Employee"), ("38", "Code of Ethics Violation", "Violation Detected Date"),
              ("38", "Code of Ethics Violation", "Violation Detection Source"), ("38", "Code of Ethics Violation", "Violation Sanction"),
              ("38", "Code of Ethics Violation", "Source Surveillance Alert")]),
            ("Contribution Over De Minimis Flag", "Y where the sum of Contribution Amount by Contributor Employee x Contribution Recipient x election cycle exceeds USD 350 when Eligible to Vote Indicator = Y, or USD 150 when it is N (Rule 206(4)-5(b)(1)).",
             [("38", "Political Contribution", "Contribution Amount"), ("38", "Political Contribution", "Contributor Employee"),
              ("38", "Political Contribution", "Contribution Recipient"), ("38", "Political Contribution", "Eligible to Vote Indicator"),
              ("38", "Political Contribution", "Contribution Date")]),
            ("Time-Outs Triggered", "Count of contributions whose Pay-to-Play Review has Two-Year Time-Out Triggered Indicator = Y, with the number of Affected Government Clients that are government entities (12 Institutional Client Government Entity Indicator = Y) and the time-out end (Contribution Date + 2 years).",
             [("38", "Pay-to-Play Review", "Two-Year Time-Out Triggered Indicator"), ("38", "Pay-to-Play Review", "Affected Government Clients"),
              ("12", "Institutional Client", "Institutional Client Party"), ("12", "Institutional Client", "Government Entity Indicator"),
              ("38", "Political Contribution", "Contribution Date"),
              ("38", "Pay-to-Play Review", "Pay-to-Play Outcome")]),
            ("Contributions Without Pre-Clearance", "Contributions with Contribution Pre-Clearance Status empty or not approved and Contribution Date in the period, by Political Recipient Type.",
             [("38", "Political Contribution", "Contribution Pre-Clearance Status"), ("38", "Political Contribution", "Political Recipient Type"),
              ("38", "Political Contribution", "Contribution Date")]),
            ("Unapproved Active OBA", "Outside Business Activities with OBA Effective From <= as-of date, OBA Effective To empty or later, and OBA Approval Status not approved, by OBA Type and OBA Compensated Indicator.",
             [("38", "Outside Business Activity", "OBA Approval Status"), ("38", "Outside Business Activity", "OBA Effective From"),
              ("38", "Outside Business Activity", "OBA Effective To"), ("38", "Outside Business Activity", "OBA Type"),
              ("38", "Outside Business Activity", "OBA Compensated Indicator")]),
            ("Conflicts Without Effective Mitigation", "Count of Conflicts of Interest with Conflict Register Status active and either no Conflict Mitigation in effect, or every mitigation in effect is a control whose Mitigating Control has no Control Test in the last 12 months or whose latest Control Test Result is ineffective (tests from DP-214), by Firm Conflict Category.",
             [("38", "Conflict of Interest", "Conflict ID"), ("38", "Conflict of Interest", "Conflict Register Status"),
              ("38", "Conflict of Interest", "Firm Conflict Category"), ("38", "Conflict Mitigation", "Mitigated Conflict"),
              ("38", "Conflict Mitigation", "Mitigation Type"), ("38", "Conflict Mitigation", "Mitigating Control"),
              ("38", "Conflict Mitigation", "Mitigation Effective From"), ("38", "Conflict Mitigation", "Mitigation Effective To"),
              ("37", "Control Test", "Tested Control"), ("37", "Control Test", "Control Test Date"),
              ("37", "Control Test", "Control Test Result")]),
        ],
        inputs=[
            ("38", "Conduct Population Designation", ["Designated Employee", "Conduct Designation Type", "Designating Entity",
                                                      "Designating Fund", "Designation Effective From", "Designation Effective To"]),
            ("38", "Personal Trading Account", ["Personal Account Key", "Account Holder Employee", "Personal Account Broker",
                                                "Personal Account Type", "Account Holder Relationship",
                                                "Discretionary Managed Indicator", "Personal Account Opened Date",
                                                "Personal Account Closed Date"]),
            ("38", "Personal Securities Report", ["Reporting Access Person", "Personal Report Type", "Report As-Of Date",
                                                  "Report Due Date", "Report Submitted Date", "Report Review Outcome"]),
            ("38", "Reported Personal Holding", ["Holding Report", "Holding Account", "Held Security", "Held Quantity"]),
            ("38", "Personal Transaction", ["Broker Transaction Reference", "Transaction Account", "Personal Trade Date",
                                            "Traded Security", "Personal Trade Side", "Personal Trade Quantity",
                                            "Personal Trading Data Source", "Matched Pre-Clearance", "Reported On Report"]),
            ("38", "Pre-Clearance Request", ["Requesting Employee", "Request Timestamp", "Pre-Clearance Security",
                                             "Pre-Clearance Side", "Pre-Clearance Quantity", "Pre-Clearance Decision",
                                             "Pre-Clearance Decision Reason", "Approval Valid Until",
                                             "Blocking Restricted List Entry"]),
            ("38", "Code of Ethics Violation", ["Violating Employee", "Violation Detected Date", "Violation Sequence",
                                                "Violated Policy Version", "Violation Detection Source",
                                                "Source Surveillance Alert", "Violation Sanction"]),
            ("38", "Political Contribution", ["Political Contribution ID", "Contributor Employee", "Contributing Entity",
                                              "Contribution Recipient", "Political Recipient Type",
                                              "Recipient Office and Jurisdiction", "Contribution Amount", "Contribution Date",
                                              "Eligible to Vote Indicator", "Contribution Pre-Clearance Status"]),
            ("38", "Pay-to-Play Review", ["Affected Government Clients", "De Minimis Exception Applied Indicator",
                                          "Two-Year Time-Out Triggered Indicator", "Return Exception Used Indicator",
                                          "Look-Back Review Indicator", "Pay-to-Play Outcome"]),
            ("38", "Conflict of Interest", ["Conflict ID", "Firm Conflict Category", "Firm Conflict Description",
                                            "Conflict Entities", "Disclosure Location", "Conflict Register Status"]),
            ("38", "Conflict Mitigation", ["Mitigated Conflict", "Mitigation Type", "Mitigating Control", "Mitigating Policy",
                                           "Client Consent Obtained Indicator", "Mitigation Effective From",
                                           "Mitigation Effective To"]),
            ("38", "Outside Business Activity", ["OBA Employee", "OBA Type", "OBA Organization", "OBA Compensated Indicator",
                                                 "OBA Approval Status", "OBA Related Conflict", "OBA Effective From",
                                                 "OBA Effective To"]),
            ("38", "Firm Restricted List", ["Restricted List Code", "Restricted List Type", "Restricted List Status"]),
            ("38", "Restricted List Entry", ["Restricted List Entry ID", "Entry List", "Restricted Issuer", "Restricted Instruments",
                                             "Entry Added Timestamp", "Entry Removed Timestamp"]),
            ("37", "Control Test", ["Tested Control", "Control Test Date", "Control Test Result"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "Issuer", "Instrument Type", "Asset Class"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
            ("12", "Institutional Client", ["Institutional Client Party", "Institutional Client Type", "Government Entity Indicator"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Legal Last Name", "Employing Legal Entity", "Home Org Unit",
                                "Employment Status", "Hire Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name"]),
        ],
        upstream=["DP-227", "DP-192", "DP-097", "DP-240", "DP-013", "DP-214", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET each business day, covering broker feeds and pre-clearance decisions to the prior day's close; quarterly report status final by the 35th day after quarter end",
        history="Every report, transaction, pre-clearance, violation, contribution, activity and conflict record kept as SCD type 2 for at least 5 years after the end of the fiscal year of the record (Rule 204-2(a)(12) and (13), 204-2(a)(18) for contributions) and 6 years where FINRA or FCA rules require longer; designations kept for 5 years after they end",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Personal Transaction has a Transaction Account that resolves to a Personal Trading Account and a Traded Security that resolves to an Instrument in DP-097.",
            "Every Matched Pre-Clearance resolves to a Pre-Clearance Request of the same employee as the account's Account Holder Employee, with Request Timestamp before Personal Trade Date.",
            "Every Pre-Clearance Request with Pre-Clearance Decision = approved has Approval Valid Until populated, and every denial blocked by the restricted list has Blocking Restricted List Entry populated.",
            "Every Personal Securities Report has a Report Due Date, and every access person in effect for a full quarter has one quarterly transaction report row for that quarter.",
            "Every Political Contribution has exactly one of Contributor Employee or Contributing Entity populated, and every contribution has a Pay-to-Play Review row once Contribution Pre-Clearance Status is decided.",
            "Every Conflict of Interest with Conflict Register Status active has a Disclosure Location or at least one Conflict Mitigation.",
        ],
        notes=("CD-254: code of ethics, personal trading, political contributions, outside activities and the firm conflicts "
               "register are 38; HR sanctions stay 20 (only the 38 Violation Sanction is shown); 08 keeps the distribution "
               "conflict profile and gifts and entertainment (DP-038). PII and Restricted: every individual-level output is "
               "personal data of employees and their household members (account holders, contribution recipients); "
               "individual rows go to the CCO's team only, and an aggregate by entity, fund and designation type is "
               "published for wide use. Masked account numbers are not carried. Restricted list content is read from "
               "DP-227 by entry and list type; watch list entries are not shown here (control room only). Mitigating "
               "control test results come from DP-214. Trade surveillance violations reference the alert by key only "
               "(Source Surveillance Alert); this product does not list DP-228 upstream, because DP-228 reads personal "
               "transactions from here. Exempt instruments for the pre-clearance test (open-end funds not advised by the "
               "firm, money market funds, government securities, bank instruments) are a maintained list of Instrument "
               "Types; it is not hard-coded. De minimis amounts are per election (Rule 206(4)-5); election cycles are not "
               "held in the taxonomy and are a maintained calendar. Taxonomy gap: Personal Securities Report has no "
               "identifier, so Reported On Report and Holding Report join on access person x report type x as-of date. "
               "Taxonomy gap: Pay-to-Play Review has no time-out end date (dropped as derivable); it is Contribution "
               "Date + 2 years. Open SME questions (38 Source Notes 3, 9, 13): the personal trading platform and broker "
               "feed coverage; pre-clearance of spouse and household contributions; tracking of solicitor and placement "
               "agent payments. Decisions: CD-224, CD-254, CD-256. "
               "W1 re-point (CW-902, CW-021): Institutional Client Government Entity Indicator was read from 02 Party Type = "
               "Government through DP-240 (added upstream). DP-003 left upstream at W1. "
               "W4 re-point (CW-151, CW-912): Institutional Client is restored in 12, so the government-entity test reads 12 "
               "Institutional Client.Government Entity Indicator again (Institutional Client Type is read with it); 02 Party "
               "stays for the contribution recipients. Pre-Clearance Decision is now the shared Approval Status ('denied' reads "
               "'Rejected'); Personal Trade Side and Impacted Data Domain keep names and values."),
    ),

    "DP-226": dict(
        definition=("The AML and sanctions program for every legal entity and fund it covers: program assessments with the "
                    "BSA institution type, applicability date, risk rating, designated AML officer and independent test "
                    "date; AML cases opened from shareholder account alerts (29), party KYC reviews (02), supplier "
                    "onboarding screening (40) and trade surveillance (38); the SAR decision and actions on each case; and "
                    "FinCEN SAR and OFAC blocked and rejected property reports against their deadlines. "
                    "It lets the BSA / AML Officer evidence case timeliness and filing deadlines without "
                    "exposing case detail beyond the restricted AML population. It owns no certified metric family."),
        business_questions=[
            "How many AML cases are open by source and type, how old are they, and which are close to the SAR decision deadline?",
            "Were SAR and OFAC reports filed by their due dates this period, by entity and report type?",
            "Which escalated alerts or screening hits have no AML case?",
            "Has every covered entity and fund had an independent AML test in the last 12 months, and is a designated AML officer appointed?",
            "What share of decided cases resulted in a SAR, by case source?",
        ],
        grain=("AML case x as-of date, with child grains of AML and sanctions report (AML Report Key; case x report sequence within a case) and AML program "
               "assessment (assessed entity or fund x assessment year)"),
        dimensions=["As-of date and assessment year", "Assessed entity or fund", "AML institution type", "AML case type and source",
                    "Case status and SAR decision", "AML report type and authority", "Case age bucket", "AML risk assessment rating"],
        measures=[
            ("Open AML Cases", "Count of AML Cases with AML Case Status not closed, by AML Case Type and AML Case Source, aged in calendar days since Case Opened Date (0-15, 16-30, 31-60, over 60).",
             [("38", "AML Case", "AML Case Number"), ("38", "AML Case", "AML Case Status"), ("38", "AML Case", "AML Case Type"),
              ("38", "AML Case", "AML Case Source"), ("38", "AML Case", "Case Opened Date")]),
            ("Days to SAR Decision", "Calendar days from initial detection to Case Decision Date; initial detection is the earliest Alert Generated Timestamp of the 29 or 50 alerts that escalated to the case (29 Alert Disposition Escalation Case Reference, 50 Escalated AML Case) or of the source 38 alert, else Case Opened Date. Cases still open past 30 days (60 where no suspect is identified, see notes) are flagged.",
             [("38", "AML Case", "Case Decision Date"), ("38", "AML Case", "Case Opened Date"),
              ("29", "Alert Disposition", "Escalation Case Reference"), ("29", "Account Monitoring Alert", "Alert Generated Timestamp"),
              ("50", "Money Movement Monitoring Alert", "Escalated AML Case"), ("50", "Money Movement Monitoring Alert", "Alert Generated Timestamp"),
              ("38", "AML Case", "Source Trade Surveillance Alert"), ("38", "Trade Surveillance Alert", "Alert Generated Timestamp")]),
            ("Report Filing Timeliness %", "AML and Sanctions Reports with Report Filed Date <= AML Report Due Date / reports with AML Report Due Date in the period, by AML Report Type.",
             [("38", "AML and Sanctions Report", "Report Filed Date"), ("38", "AML and Sanctions Report", "AML Report Due Date"),
              ("38", "AML and Sanctions Report", "AML Report Type")]),
            ("Overdue Reports", "Reports with AML Report Due Date before the as-of date and Report Filed Date empty, by AML Report Type.",
             [("38", "AML and Sanctions Report", "AML Report Due Date"), ("38", "AML and Sanctions Report", "Report Filed Date"),
              ("38", "AML and Sanctions Report", "AML Report Key"), ("38", "AML and Sanctions Report", "Reported Case")]),
            ("SAR Conversion Rate", "Cases with SAR Decision = file / cases with a Case Decision Date in the period, by AML Case Source.",
             [("38", "AML Case", "SAR Decision"), ("38", "AML Case", "Case Decision Date"), ("38", "AML Case", "AML Case Source")]),
            ("Unlinked Escalations", "Count of 29 Account Monitoring Alerts whose Alert Disposition is escalated and whose Escalation Case Reference is empty or does not resolve to an AML Case Number, plus 50 Money Movement Monitoring Alerts with Alert Disposition escalated and Escalated AML Case empty or unresolved, plus 38 Trade Surveillance Alerts with Surveillance Disposition escalated to AML and no AML Case with Source Trade Surveillance Alert = the alert.",
             [("29", "Account Monitoring Alert", "Account Monitoring Alert ID"), ("29", "Alert Disposition", "Alert Disposition"),
              ("29", "Alert Disposition", "Escalation Case Reference"), ("38", "AML Case", "AML Case Number"),
              ("50", "Money Movement Monitoring Alert", "Money Movement Monitoring Alert ID"), ("50", "Money Movement Monitoring Alert", "Alert Disposition"),
              ("38", "Trade Surveillance Alert", "Trade Surveillance Alert ID"), ("38", "Trade Surveillance Alert", "Surveillance Disposition"),
              ("38", "AML Case", "Source Trade Surveillance Alert")]),
            ("Unescalated Screening Hits", "Supplier Onboarding Cases with Sanctions Screening Result = potential or confirmed match and no AML Case with Source Supplier Onboarding Case = the case; and KYC Profiles with Sanctions Screening Result = confirmed match and no AML Case with Source KYC Profile = the party.",
             [("40", "Supplier Onboarding Case", "Onboarding Supplier"), ("40", "Supplier Onboarding Case", "Onboarding Sequence"),
              ("40", "Supplier Onboarding Case", "Sanctions Screening Result"), ("38", "AML Case", "Source Supplier Onboarding Case"),
              ("02", "KYC Profile", "Sanctions Screening Result"), ("02", "Party", "Party ID"),
              ("38", "AML Case", "Source KYC Profile")]),
            ("Independent Test Currency Flag", "Y where an AML Program Assessment with Program Applicability Date on or before the as-of date has Independent Test Date empty or more than 12 months before the as-of date (FINRA Rule 3310(c) annual default; see notes).",
             [("38", "AML Program Assessment", "Assessed Entity"), ("38", "AML Program Assessment", "Assessed Fund"),
              ("38", "AML Program Assessment", "Program Applicability Date"), ("38", "AML Program Assessment", "Independent Test Date"),
              ("38", "AML Program Assessment", "AML Institution Type")]),
            ("Program Without Designated Officer", "Y where an applicable AML Program Assessment for the current Assessment Year has Designated AML Officer empty, or the referenced Corporate Officer Appointment has Officer Effective To before the as-of date or an Officer Employee with Employment Status not active (from DP-230 and DP-192).",
             [("38", "AML Program Assessment", "Designated AML Officer"), ("38", "AML Program Assessment", "Assessment Year"),
              ("39", "Corporate Officer Appointment", "Officer Effective To"), ("39", "Corporate Officer Appointment", "Officer Employee"),
              ("20", "Employee", "Employment Status")]),
            ("High-Risk Subject Share %", "Open cases with at least one Case Subject Party whose KYC Profile has AML Risk Rating = high or PEP Status = PEP / open cases.",
             [("38", "AML Case", "Case Subject Parties"), ("02", "KYC Profile", "AML Risk Rating"), ("02", "KYC Profile", "PEP Status"),
              ("38", "AML Case", "AML Case Status")]),
        ],
        inputs=[
            ("38", "AML Program Assessment", ["Assessed Entity", "Assessed Fund", "Assessment Year", "AML Institution Type",
                                              "Program Applicability Date", "AML Risk Assessment Rating", "Designated AML Officer",
                                              "Independent Test Date"]),
            ("38", "AML Case", ["AML Case Number", "AML Case Type", "AML Case Source",
                                "Source KYC Profile", "Source Supplier Onboarding Case", "Source Trade Surveillance Alert",
                                "Case Subject Parties", "Case Subject Accounts", "Case Opened Date", "AML Case Status",
                                "SAR Decision", "AML Case Actions", "Case Decision Date"]),
            ("38", "AML and Sanctions Report", ["AML Report Key", "Reported Case", "Report Sequence", "AML Report Type", "AML Report Due Date",
                                                "Report Filed Date", "Authority Reference Number", "Report Classification"]),
            ("38", "Trade Surveillance Alert", ["Trade Surveillance Alert ID", "Alert Generated Timestamp", "Surveillance Disposition"]),
            ("29", "Account Monitoring Alert", ["Account Monitoring Alert ID", "Monitoring Alert Category", "Alert Account",
                                                "Alert Generated Timestamp", "Alert Status"]),
            ("29", "Alert Disposition", ["Alert Disposition", "Disposition Date", "Escalation Case Reference"]),
            ("50", "Money Movement Monitoring Alert", ["Money Movement Monitoring Alert ID", "Monitoring Scenario", "Alert Generated Timestamp",
                                                       "Alert Status", "Alert Disposition", "Escalated AML Case"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
            ("02", "KYC Profile", ["KYC Status", "AML Risk Rating", "PEP Status", "Sanctions Screening Result", "Last Screening Date"]),
            ("40", "Supplier Onboarding Case", ["Onboarding Supplier", "Onboarding Sequence", "Sanctions Screening Result",
                                                "Onboarding Case Status"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("39", "Corporate Officer Appointment", ["Officer Entity", "Corporate Officer Role", "Officer Employee",
                                                     "Officer Effective From", "Officer Effective To"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type"]),
        ],
        upstream=["DP-093", "DP-077", "DP-210", "DP-013", "DP-180", "DP-228", "DP-240", "DP-230", "DP-192", "DP-004"],
        refresh="Daily",
        timeliness="By 7am ET each business day, covering alerts, case decisions and filings to the prior day's close",
        history="Cases, reports and program assessments kept as SCD type 2 for at least 5 years from the SAR filing or case decision (31 CFR 1010.430, 1024.320(d)) and longer under legal hold; daily snapshots of open cases kept 5 years",
        classification="Restricted - Legal",
        pii="Y",
        delivery=["Warehouse table", "Dashboard"],
        dq_rules=[
            "Every AML Case has an AML Case Source; a 38, 02 or 40 source has exactly the matching source reference (Source KYC Profile, Source Supplier Onboarding Case or Source Trade Surveillance Alert) populated, and every case with a 29 or 50 source is referenced by at least one alert (29 Escalation Case Reference or 50 Escalated AML Case).",
            "Every AML Case with a Case Decision Date has a SAR Decision, and every case with SAR Decision = file has at least one AML and Sanctions Report of a SAR type.",
            "Every AML and Sanctions Report has a unique AML Report Key; a report with a Reported Case resolves to an AML Case Number and has an AML Report Due Date on or after that case's Case Opened Date (OFAC blocked and rejected property reports may have no case).",
            "Report Filed Date is populated if and only if Authority Reference Number is populated.",
            "Every AML Program Assessment has exactly one of Assessed Entity or Assessed Fund populated.",
        ],
        notes=("W4 re-point (CW-938, CW-162, ruling 2): 38 AML Case.Source Account Monitoring Alert dropped; the case is linked "
               "from the alert side, 29 Alert Disposition.Escalation Case Reference and 50 Money Movement Monitoring Alert.Escalated "
               "AML Case (50 added as an input; brokerage money movement monitoring, CW-123), in Days to SAR Decision, Unlinked "
               "Escalations and the source rule. AML and Sanctions Report is keyed by its new AML Report Key (case-less OFAC "
               "reports); Reported Case and Report Sequence are kept as columns. The UK SAR, NCA, OFSI, MLRO and POCA text leaves "
               "the definition, questions, history and notes. "
               "CD-201 and CD-255: shareholder account monitoring and CIP are 29, published only by DP-180 (Fund Operations); "
               "party KYC is 02 (DP-077); supplier screening is 40 (DP-210); the program, cases and reports are 38. DP-180 "
               "must not take DP-226 upstream (it references the case by Escalation Case Reference only); DP-228 likewise. "
               "Classified Restricted - Legal and delivered to the AML unit only: SAR confidentiality (31 CFR 1024.320(e), "
               "1023.320(e)) forbids disclosing that a SAR exists; no SAR "
               "Decision, case or report row appears in the BI semantic model or any wide aggregate. PII = Y: case "
               "subjects, accounts and parties are personal data. Operating model (CD-297): if the TA runs fund AML (38 "
               "SME question 7), the 29 alert arrives as provider data at the same grain and the case remains 38's; the "
               "Designated AML Officer is a 39 officer appointment read through DP-230. The 30-day SAR clock (60 days "
               "where no suspect is identified, 31 CFR 1024.320(b)(3)) and the 12-month independent test interval are "
               "defaults; the AML Report Due Date in 38 is the authority. The FinCEN investment adviser AML rule is "
               "modeled as an applicability date (2028-01-01), not as in force. Taxonomy gap: AML Case has no initial "
               "detection date or 'no suspect identified' indicator, so the SAR clock starts from the source alert or "
               "Case Opened Date. Taxonomy gap: AML Program Assessment has no independent test provider or test result. "
               "Open SME questions (38 Source Notes 7, 11): is fund AML in house or at the TA; is a restricted 29 "
               "reference acceptable to the AML Officer. Decisions: CD-201, CD-255, CD-297."),
    ),

    "DP-227": dict(
        definition=("The current and dated content of the firm's restricted, watch and insider lists by issuer and "
                    "instrument, with the MNPI escalation decisions that put names on them, cleansing dates, and the insider "
                    "list entries kept under the firm's Section 204A and Rule 204A-1 MNPI policies. It is the one published feed of restricted names (CD-224, "
                    "CD-256) that pre-trade investment compliance (33 reads it by Restricted List Code and stores no "
                    "members), personal trading pre-clearance (DP-225), trade surveillance (DP-228) and research consume "
                    "intraday, so that no desk keeps its own copy. It owns no certified metric family."),
        business_questions=[
            "Which issuers and instruments are on each restricted and watch list now, since when and for what reason?",
            "How long did it take from an MNPI escalation to the restriction, and were any restrict decisions not put on a list?",
            "Which entries are past their cleansing date but still open, and which have been on the list longest?",
            "Is every person who obtained inside information on the insider list, and was their access ceased when the information was cleansed or they left?",
            "Which restricted issuers have active instruments that the entry does not name?",
        ],
        grain=("Restricted list entry (RLIST-: list x issuer x added timestamp) with its valid time from Entry Added Timestamp "
               "to Entry Removed Timestamp; an intraday current-content view at list x issuer x instrument; child grains of "
               "MNPI escalation (MNPI-) and insider list entry (list x section x person x access obtained timestamp)"),
        dimensions=["List code and list type", "Restricted issuer and instrument", "Restriction reason", "Entry added and removed date",
                    "MNPI source type and decision", "Insider list section", "Insider (internal or external)", "List scope entity"],
        measures=[
            ("Current Restricted Names", "Count of Restricted List Entries with Entry Removed Timestamp empty, by Entry List, Restricted List Type and Restriction Reason; instruments are expanded to every active Instrument of the Restricted Issuer from DP-097.",
             [("38", "Restricted List Entry", "Restricted List Entry ID"), ("38", "Restricted List Entry", "Entry Removed Timestamp"),
              ("38", "Restricted List Entry", "Entry List"), ("38", "Firm Restricted List", "Restricted List Type"),
              ("38", "Restricted List Entry", "Restriction Reason"), ("38", "Restricted List Entry", "Restricted Issuer"),
              ("17", "Instrument", "Issuer"), ("17", "Instrument", "Instrument Status")]),
            ("Unexpanded Entry Flag", "Y where an open entry has Restricted Instruments populated and omits an Instrument with Instrument Status active whose Issuer is the Restricted Issuer.",
             [("38", "Restricted List Entry", "Restricted Instruments"), ("38", "Restricted List Entry", "Restricted Issuer"),
              ("17", "Instrument", "Instrument ID"), ("17", "Instrument", "Issuer"), ("17", "Instrument", "Instrument Status")]),
            ("Escalation-to-Restriction Minutes", "Minutes from Escalation Received Timestamp to Entry Added Timestamp of the entry whose Source MNPI Escalation is the escalation, for escalations with MNPI Decision = restrict; median and maximum by MNPI Source Type.",
             [("38", "MNPI Escalation", "Escalation Received Timestamp"), ("38", "Restricted List Entry", "Entry Added Timestamp"),
              ("38", "Restricted List Entry", "Source MNPI Escalation"), ("38", "MNPI Escalation", "MNPI Decision"),
              ("38", "MNPI Escalation", "MNPI Source Type")]),
            ("Restrict Decision Without Entry", "Count of MNPI Escalations with MNPI Decision = restrict and no Restricted List Entry with Source MNPI Escalation = the MNPI Escalation ID.",
             [("38", "MNPI Escalation", "MNPI Escalation ID"), ("38", "MNPI Escalation", "MNPI Decision"),
              ("38", "Restricted List Entry", "Source MNPI Escalation")]),
            ("Stale Restriction Flag", "Y where an open entry's Source MNPI Escalation has Cleansing Date on or before the as-of date (the information is public or no longer price sensitive, but the name is still restricted).",
             [("38", "Restricted List Entry", "Source MNPI Escalation"), ("38", "Restricted List Entry", "Entry Removed Timestamp"),
              ("38", "MNPI Escalation", "Cleansing Date")]),
            ("Days on List", "Calendar days from Entry Added Timestamp to Entry Removed Timestamp (or the as-of date for open entries); average and maximum by Restriction Reason.",
             [("38", "Restricted List Entry", "Entry Added Timestamp"), ("38", "Restricted List Entry", "Entry Removed Timestamp"),
              ("38", "Restricted List Entry", "Restriction Reason")]),
            ("Insider Section Gap", "Count of MNPI Escalations with an insider-list decision and no Insider List Entry with Insider Escalation = the escalation.",
             [("38", "MNPI Escalation", "MNPI Escalation ID"), ("38", "MNPI Escalation", "MNPI Decision"),
              ("38", "Insider List Entry", "Insider Escalation")]),
            ("Open Insider Access After Cleansing or Departure", "Insider List Entries with Access Ceased Timestamp empty where the Insider Escalation's Cleansing Date has passed, or the Internal Insider has Employment Status not active (from DP-192).",
             [("38", "Insider List Entry", "Access Ceased Timestamp"), ("38", "Insider List Entry", "Insider Escalation"),
              ("38", "MNPI Escalation", "Cleansing Date"), ("38", "Insider List Entry", "Internal Insider"),
              ("20", "Employee", "Employment Status")]),
            ("Entries on Retired Parties", "Open entries whose Restricted Issuer has Party Status inactive or Merged Into Party populated in DP-240, so the restriction may not reach the surviving issuer.",
             [("38", "Restricted List Entry", "Restricted Issuer"), ("02", "Party", "Party Status"), ("02", "Party", "Merged Into Party")]),
        ],
        inputs=[
            ("38", "Firm Restricted List", ["Restricted List Code", "Restricted List Name", "Restricted List Type",
                                            "List Scope Entities", "Restricted List Status"]),
            ("38", "Restricted List Entry", ["Restricted List Entry ID", "Entry List", "Restricted Issuer", "Restricted Instruments",
                                             "Restriction Reason", "Source MNPI Escalation", "Entry Added Timestamp",
                                             "Entry Removed Timestamp", "Entry Classification"]),
            ("38", "MNPI Escalation", ["MNPI Escalation ID", "MNPI Source Type", "Source Issuer Meeting",
                                       "Source Engagement", "MNPI Issuer", "Escalation Received Timestamp", "MNPI Decision",
                                       "MNPI Decided By", "Cleansing Date", "MNPI Escalation Classification"]),
            ("38", "Insider List Entry", ["Insider List", "Insider Escalation", "Internal Insider", "External Insider",
                                          "Access Obtained Timestamp", "Access Ceased Timestamp", "Insider Reason",
                                          "Insider Entry Classification"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Name", "Issuer", "Instrument Type", "Instrument Status"]),
            ("17", "Instrument Identifier", ["Identified Instrument", "Instrument Identifier Scheme", "Instrument Identifier Value",
                                             "Primary Identifier Indicator", "Instrument Identifier Status"]),
            ("17", "Issuer Profile", ["Issuer Party", "Issuer Type", "Issuer Profile Status"]),
            ("02", "Party", ["Party ID", "Party Display Name", "Party Status", "Merged Into Party"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Legal Last Name", "Home Org Unit", "Employment Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
        ],
        upstream=["DP-098", "DP-097", "DP-240", "DP-192", "DP-013"],
        refresh="Real-Time",
        timeliness="List changes published within 1 minute of Entry Added or Removed Timestamp; full current-content snapshot every 15 minutes during trading hours and at 6am ET",
        history="Every entry, escalation and insider entry kept with full valid time and transaction time (bitemporal) for at least 5 years from the end of the restriction or the insider list update (Advisers Act Rule 204-2 and SEA Rule 17a-4); intraday snapshots kept 1 year",
        classification="Restricted - MNPI",
        pii="Y",
        delivery=["API", "Event stream", "Warehouse table", "Dashboard"],
        dq_rules=[
            "Every Restricted List Entry has an Entry List that resolves to a Firm Restricted List with Restricted List Status active, and a Restricted Issuer that resolves to a Party in DP-240.",
            "Entry Removed Timestamp, when populated, is after Entry Added Timestamp, and no two open entries on the same list have the same Restricted Issuer.",
            "Every Restricted Instruments value resolves to an Instrument in DP-097 whose Issuer is the Restricted Issuer.",
            "Every Insider List Entry has exactly one of Internal Insider or External Insider populated, an Access Obtained Timestamp, and an Insider List that resolves to a Firm Restricted List of type insider list.",
            "Every MNPI Escalation with MNPI Decision populated has MNPI Decided By and an Escalation Received Timestamp before the decision.",
        ],
        notes=("W4 re-point (CW-938, CW-930): 38 MNPI Escalation.Source Deal dropped, no successor (the 30 Deal retires); no "
               "measure read it. The UK and EU insider list (MAR Article 18) text leaves the definition, history and notes. "
               "CD-224 and CD-256: 38 decides, 23 flags (23 Meeting MNPI Assessment holds the escalation reference), 33 Rule "
               "Instrument List reads the list by Restricted List Source code and stores no members; this product is the "
               "only feed of restricted names (brief §6 item 12). Classified Restricted - MNPI: watch list and insider list "
               "content is visible to the control room only; consumers outside it receive the restricted list view "
               "(list type restricted) with issuer and instrument keys but no restriction reason or source escalation. "
               "PII = Y: insider list entries name employees and external insiders, and MNPI "
               "Decided By names an employee. Instruments and identifiers come from DP-097 and issuer status from DP-098 "
               "and DP-240. This product does not list DP-121 (Issuer Meetings & MNPI Control) upstream; DP-121 reads the "
               "escalation and entry from here, so the edge must go that way only. Taxonomy gap: Restricted List Entry "
               "has no 'applies to personal trading' indicator (dropped in 38), so consumers filter by Restricted List "
               "Type. Taxonomy gap: there is no time at which the restriction became effective in the order management "
               "system, so restriction latency stops at Entry Added Timestamp. Open SME questions (38 Source Notes 4, 5, "
               "12): one restricted list across entities or one per entity; who decides MNPI escalations. Decisions: CD-224, CD-256."),
    ),

    # DP-228 re-specified at WP1 in specs_w1c_fop_corp.py

    # ======================================== 39 Legal & Corporate Governance ========================================
    "DP-229": dict(
        definition=("Legal matters (litigation, regulatory enforcement, investigations, arbitration) with their parties, events "
                    "and deadlines, the ASC 450 and IAS 37 assessments and reserves per reporting entity, outside counsel "
                    "engagements against budget with invoice reductions, legal service request workload, and legal holds "
                    "with custodian acknowledgment and the applications, data assets and record classes where disposal is "
                    "suspended. It gives the General Counsel matter exposure and counsel spend, and evidences that every "
                    "hold reached its custodians and systems. Money amounts are operational measures under their own names "
                    "(Legal Reserve Assessed, Outside Counsel Approved Amount), never expense or P&L, and each reconciles to "
                    "the journal or payable it should match in DP-191 (CD-353, CD-361); certified expense comes only from "
                    "DP-191."),
        business_questions=[
            "Which matters are open by type, forum and significance, and which deadlines fall in the next 14 days?",
            "What is the assessed reserve and the reasonably possible loss range by matter and reporting entity, and does the reserve match what was booked?",
            "How much outside counsel spend was approved against each engagement budget, how much was cut in invoice review, and does approved spend tie to payables?",
            "Did every custodian acknowledge each active hold, and are any custodians leaving the firm or scoped systems being retired while the hold is active?",
            "How many legal service requests are open by type and lawyer, and how long do they take?",
        ],
        grain=("Legal matter (LMAT-) x as-of date, with child grains of matter financial assessment (matter x reporting entity x "
               "assessment date), outside counsel engagement (engagement letter x matter) and invoice review, legal service "
               "request, legal hold (LHOLD-) x custodian and legal hold x scope"),
        dimensions=["As-of date and fiscal period", "Legal matter type, forum and significance", "Matter regulator", "Matter status",
                    "Reporting entity", "ASC 450 and IAS 37 likelihood", "Outside counsel firm", "Legal request type",
                    "Responsible or assigned lawyer", "Hold status", "Hold scope type", "Scoped application"],
        measures=[
            ("Open Matters", "Count of Legal Matters with Matter Status not closed and Matter Closed Date empty, by Legal Matter Type, Forum Type, Matter Significance and Matter Regulator; privileged matters (Privilege Indicator = Y) are counted but not itemized outside Legal.",
             [("39", "Legal Matter", "Legal Matter ID"), ("39", "Legal Matter", "Matter Status"), ("39", "Legal Matter", "Matter Closed Date"),
              ("39", "Legal Matter", "Legal Matter Type"), ("39", "Legal Matter", "Forum Type"),
              ("39", "Legal Matter", "Matter Significance"), ("39", "Legal Matter", "Matter Regulator"),
              ("39", "Legal Matter", "Privilege Indicator")]),
            ("Upcoming Deadlines", "Matter Events with Response Deadline within 14 calendar days of the as-of date, by matter and Responsible Lawyer.",
             [("39", "Matter Event", "Event Matter"), ("39", "Matter Event", "Response Deadline"), ("39", "Legal Matter", "Responsible Lawyer")]),
            ("Legal Reserve Assessed", "Sum of Reserve Amount on the latest Matter Financial Assessment (max Assessment Date on or before period end) per Assessed Matter x Assessment Reporting Entity. An operational measure of Legal's assessment; never shown as expense (CD-353).",
             [("39", "Matter Financial Assessment", "Reserve Amount"), ("39", "Matter Financial Assessment", "Assessment Date"),
              ("39", "Matter Financial Assessment", "Assessed Matter"), ("39", "Matter Financial Assessment", "Assessment Reporting Entity")]),
            ("Reasonably Possible Exposure", "Sum of Estimated Loss Range High (and Low) on the latest assessment where ASC 450 Likelihood = reasonably possible, or IAS 37 Likelihood = possible for IFRS reporting entities, with the count where Disclosure Required Indicator = Y.",
             [("39", "Matter Financial Assessment", "Estimated Loss Range High"), ("39", "Matter Financial Assessment", "Estimated Loss Range Low"),
              ("39", "Matter Financial Assessment", "ASC 450 Likelihood"), ("39", "Matter Financial Assessment", "IAS 37 Likelihood"),
              ("39", "Matter Financial Assessment", "Disclosure Required Indicator")]),
            ("Reserve Booking Variance", "Per matter x reporting entity: Legal Reserve Assessed - the cumulative signed Posted Amount (Debit Credit Indicator applied) of the GL Postings of every Journal Entry referenced as Reserve Journal Entry with Journal Status posted, from DP-191 (CD-361). Non-zero after the period's hard close is a reconciliation break.",
             [("39", "Matter Financial Assessment", "Reserve Journal Entry"), ("19", "Journal Entry", "Journal ID"),
              ("19", "Journal Entry", "Journal Status"), ("19", "GL Posting", "Journal ID"), ("19", "GL Posting", "Posted Amount"),
              ("19", "GL Posting", "Debit Credit Indicator"), "Legal Reserve Assessed"]),
            ("Unbooked Reserve Flag", "Y where the latest assessment has Reserve Amount different from the prior assessment's and Reserve Journal Entry is empty, or resolves to a Journal Entry whose Journal Status is not posted.",
             [("39", "Matter Financial Assessment", "Reserve Amount"), ("39", "Matter Financial Assessment", "Reserve Journal Entry"),
              ("19", "Journal Entry", "Journal Status")]),
            ("Outside Counsel Approved Amount", "Sum of Approved Amount of Outside Counsel Invoice Reviews by Invoice Review Date period, engagement, Engaged Matter and Outside Counsel Firm. An operational measure; never shown as legal expense (CD-353).",
             [("39", "Outside Counsel Invoice Review", "Approved Amount"), ("39", "Outside Counsel Invoice Review", "Invoice Review Date"),
              ("39", "Outside Counsel Invoice Review", "Reviewed Engagement"), ("39", "Outside Counsel Engagement", "Engaged Matter"),
              ("39", "Outside Counsel Engagement", "Outside Counsel Firm")]),
            ("Budget Consumption %", "Cumulative Outside Counsel Approved Amount since Engagement Start Date / Engagement Budget Amount; flagged above 90%.",
             [("39", "Outside Counsel Engagement", "Engagement Budget Amount"), ("39", "Outside Counsel Engagement", "Engagement Start Date"),
              "Outside Counsel Approved Amount"]),
            ("Invoice Reduction Rate", "Sum of Reduction Amount / Sum of Billed Fees Amount for invoice reviews completed in the period, by Outside Counsel Firm.",
             [("39", "Outside Counsel Invoice Review", "Reduction Amount"), ("39", "Outside Counsel Invoice Review", "Billed Fees Amount"),
              ("39", "Outside Counsel Invoice Review", "Invoice Review Status")]),
            ("Counsel Spend Reconciliation Difference", "Outside Counsel Approved Amount - Invoice Gross Amount of the referenced Payable Invoices (19), per period and entity; reviews with Invoice Review Status approved and no Payable Invoice, and payables with no posted GL Posting whose Source Payable Invoice is the invoice (DP-191), are listed as breaks.",
             [("39", "Outside Counsel Invoice Review", "Payable Invoice"), ("19", "Payable Invoice", "Payable Invoice ID"),
              ("19", "Payable Invoice", "Invoice Gross Amount"), ("19", "Payable Invoice", "Payable Invoice Status"),
              ("19", "Payable Invoice", "Invoice Legal Entity"),
              ("19", "GL Posting", "Source Payable Invoice"), ("39", "Outside Counsel Invoice Review", "Invoice Review Status"),
              "Outside Counsel Approved Amount"]),
            ("Legal Request Cycle Time", "Calendar days from Request Received Date to Request Completed Date, median by Legal Request Type; open requests counted by Assigned Lawyer and age.",
             [("39", "Legal Service Request", "Legal Request Number"), ("39", "Legal Service Request", "Request Received Date"),
              ("39", "Legal Service Request", "Request Completed Date"), ("39", "Legal Service Request", "Legal Request Type"),
              ("39", "Legal Service Request", "Assigned Lawyer"), ("39", "Legal Service Request", "Legal Request Status")]),
            ("Hold Issuance Lag", "Calendar days from Duty to Preserve Trigger Date to Hold Issued Date, by hold.",
             [("39", "Legal Hold", "Legal Hold ID"), ("39", "Legal Hold", "Duty to Preserve Trigger Date"), ("39", "Legal Hold", "Hold Issued Date")]),
            ("Custodian Acknowledgment %", "Custodians of active holds (Hold Status active, Custodian Released Date empty) with Custodian Acknowledgment Status acknowledged / custodians noticed; custodians unacknowledged more than 10 business days after Notice Sent Date are listed with Last Reminder Date.",
             [("39", "Legal Hold", "Hold Status"), ("39", "Legal Hold Custodian", "Custodian Hold"),
              ("39", "Legal Hold Custodian", "Custodian Employee"), ("39", "Legal Hold Custodian", "Custodian Acknowledgment Status"),
              ("39", "Legal Hold Custodian", "Notice Sent Date"), ("39", "Legal Hold Custodian", "Acknowledged Date"),
              ("39", "Legal Hold Custodian", "Last Reminder Date"), ("39", "Legal Hold Custodian", "Custodian Released Date")]),
            ("Departing Custodian Flag", "Y where a custodian of an active hold has an Employee Lifecycle Event of a termination type with Event Effective Date in the next 30 days or past, and Custodian Released Date empty: the leaver's data must be preserved before offboarding (from DP-192).",
             [("39", "Legal Hold Custodian", "Custodian Employee"), ("39", "Legal Hold Custodian", "Custodian Released Date"),
              ("20", "Employee Lifecycle Event", "Event Employee"), ("20", "Employee Lifecycle Event", "Lifecycle Event Type"),
              ("20", "Employee Lifecycle Event", "Event Effective Date"), ("39", "Legal Hold", "Hold Status")]),
            ("Scope Without Disposal Suspension", "Legal Hold Scope rows of active holds with Disposal Suspended Indicator = N, by Hold Scope Type.",
             [("39", "Legal Hold Scope", "Scope Hold"), ("39", "Legal Hold Scope", "Disposal Suspended Indicator"),
              ("39", "Legal Hold Scope", "Hold Scope Type"), ("39", "Legal Hold", "Hold Status")]),
            ("Held Application Retirement Risk", "Active hold scopes whose Scoped Application has a Decommission Date populated or Application Status retiring or retired in DP-211.",
             [("39", "Legal Hold Scope", "Scoped Application"), ("41", "Application", "Application ID"),
              ("41", "Application", "Decommission Date"), ("41", "Application", "Application Status"), ("39", "Legal Hold", "Hold Status")]),
        ],
        inputs=[
            ("39", "Legal Matter", ["Legal Matter ID", "Legal Matter Type", "Forum Type", "Docket Number", "Matter Regulator",
                                    "Originating Examination", "Matter Status", "Matter Significance", "Matter Opened Date",
                                    "Matter Closed Date", "Privilege Indicator", "Matter Classification", "Responsible Lawyer"]),
            ("39", "Matter Party", ["Party Matter", "Matter Party Role", "External Matter Party", "Internal Matter Entity"]),
            ("39", "Matter Event", ["Event Matter", "Matter Event Sequence", "Matter Event Type", "Matter Event Date", "Response Deadline"]),
            ("39", "Matter Financial Assessment", ["Assessed Matter", "Assessment Reporting Entity", "Assessment Date",
                                                   "ASC 450 Likelihood", "IAS 37 Likelihood", "Reserve Amount",
                                                   "Estimated Loss Range Low", "Estimated Loss Range High",
                                                   "Disclosure Required Indicator", "Reserve Journal Entry"]),
            ("39", "Outside Counsel Engagement", ["Engaged Matter", "Outside Counsel Firm", "Engagement Letter",
                                                  "Engagement Budget Amount", "Engagement Start Date"]),
            ("39", "Outside Counsel Invoice Review", ["Reviewed Engagement", "Counsel Invoice Number", "Payable Invoice",
                                                      "Billed Fees Amount", "Approved Amount", "Reduction Amount",
                                                      "UTBMS Task Codes Billed", "Invoice Review Status", "Invoice Review Date"]),
            ("39", "Legal Service Request", ["Legal Request Number", "Legal Request Type", "Requesting Employee", "Assigned Lawyer",
                                             "Legal Request Status", "Request Received Date", "Request Completed Date",
                                             "Resulting Contract"]),
            ("39", "Legal Hold", ["Legal Hold ID", "Hold Matter", "Hold Examination", "Duty to Preserve Trigger Date",
                                  "Hold Issued Date", "Hold Released Date", "Issuing Lawyer", "Hold Status"]),
            ("39", "Legal Hold Custodian", ["Custodian Hold", "Custodian Employee", "Notice Sent Date",
                                            "Custodian Acknowledgment Status", "Acknowledged Date", "Last Reminder Date",
                                            "Custodian Released Date"]),
            ("39", "Legal Hold Scope", ["Scope Hold", "Hold Scope Type", "Scope Inclusion Type", "Scoped Retention Rule",
                                        "Scoped Application", "Scoped Data Asset", "Scoped Party", "Scope Date From",
                                        "Scope Date To", "Disposal Suspended Indicator"]),
            ("39", "Contract", ["Contract ID", "Contract Subtype", "Contract Status", "Contract Effective Date", "Contract Expiry Date"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Status", "Posting Date", "Posting Accounting Period", "Posting Legal Entity"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount",
                                  "Source Payable Invoice"]),
            ("19", "Payable Invoice", ["Payable Invoice ID", "Supplier", "Supplier Invoice Number", "Invoice Legal Entity",
                                       "Invoice Currency", "Invoice Gross Amount", "Payable Invoice Status"]),
            ("20", "Employee Lifecycle Event", ["Lifecycle Event ID", "Event Employee", "Lifecycle Event Type", "Event Effective Date"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Legal Last Name", "Employment Status"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Status", "Decommission Date"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
        ],
        upstream=["DP-213", "DP-211", "DP-013", "DP-191", "DP-192", "DP-240"],
        refresh="Daily",
        timeliness="By 7am ET each business day for matters, events, holds and custodians; reserves and assessments final by business day 5 after quarter-end, before the controller's close",
        history="Matters, assessments, engagements, invoice reviews and holds kept as SCD type 2 for at least 7 years after the matter closes or the hold is released (longer where a hold or a disclosure requires); quarter-end assessment snapshots kept permanently",
        classification="Restricted - Legal",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Matter Financial Assessment has an Assessed Matter that resolves to a Legal Matter ID, an Assessment Reporting Entity that resolves to an Internal Legal Entity, and Estimated Loss Range Low <= Estimated Loss Range High where both are populated.",
            "Every Reserve Journal Entry resolves to a Journal ID in DP-191 whose Posting Legal Entity equals the Assessment Reporting Entity.",
            "Every Outside Counsel Engagement has an Engagement Letter that resolves to a Contract in DP-213 and an Outside Counsel Firm that resolves to a Party in DP-240.",
            "Approved Amount + Reduction Amount equals Billed Fees Amount on every invoice review with Invoice Review Status approved.",
            "Every Legal Hold with Hold Status active has Hold Issued Date on or after Duty to Preserve Trigger Date, at least one Legal Hold Custodian and at least one Legal Hold Scope row.",
            "Every Legal Hold Custodian has a Custodian Employee that resolves to an Employee ID in DP-192, and Acknowledged Date is populated if and only if Custodian Acknowledgment Status is acknowledged.",
        ],
        notes=("CD-253, CD-258: matters, assessments, counsel, requests and holds are 39; enforcement matters reference the "
               "38 exam (Originating Examination) and DP-223 counts the referral from here. CD-353 and CD-361: Legal Reserve "
               "Assessed is Legal's assessment, never certified expense; the booked reserve is the 19 journal read from "
               "DP-191, and Reserve Booking Variance is the reconciliation. Outside Counsel Approved Amount is an "
               "operational measure; Billed Fees Amount is the 19 copy held on the review and is read there because the "
               "reduction is a fact of the review (rule 2 exception), while the reconciliation reads the 19 Payable Invoice itself; legal expense is certified only in DP-191. Payable Invoice is read from 19 directly "
               "because no foundational product publishes payables (DP-191 publishes postings only); re-point if an "
               "accounts payable product is specified. Legal Hold Scope is the source of the 02 and 08 Legal Hold "
               "Indicators that DP-078 and DP-080 read (CD-258, lineage only). Engagement letters come from DP-213, scoped "
               "applications from DP-211, custodians and leavers from DP-192, counsel firms and external parties from "
               "DP-240. Classified Restricted - Legal: privileged matters (Privilege Indicator = Y) are excluded from wide "
               "aggregates, and matter descriptions are not carried; PII = Y because custodians, lawyers, requesters and "
               "individual matter parties are named. Settlements and fines feed the 37 Operational Loss Event (DP-215), "
               "which holds the link to the matter; this product does not count losses. Thresholds (14-day deadline "
               "window, 90% budget, 10-day acknowledgment) are drafting assumptions. Taxonomy gap: Matter Financial "
               "Assessment has no currency attribute; amounts are assumed in the reporting entity's ledger currency. "
               "Taxonomy gap: Legal Hold Custodian has no data preserved date, so 'preserved before offboarding' cannot be "
               "evidenced, only flagged. Taxonomy gap: there is no reserve GL account designation, so Reserve Booking "
               "Variance takes every line of the referenced journal. Open SME questions (39 Source Notes 5, 6, 10): matter "
               "and e-billing tools and whether counsel spend is approved in 40; who issues holds for exams; which "
               "entities report under US GAAP or IFRS. Decisions: CD-253, CD-258, CD-353, CD-361."),
    ),

    "DP-230": dict(
        definition=("The governance record of each internal legal entity other than funds, fund-management entities and "
                    "general partners: governing bodies and committees with membership and independence, officer appointments "
                    "(including the adviser CCO, the funds' CCO, the BSA / AML officer and the broker-dealer's FINRA principals), meetings with quorum and "
                    "minutes status, resolutions with every subject each approved, statutory filings against due dates, "
                    "powers of attorney and signing authority grants with monetary limits. It tells the Company Secretary "
                    "which entities lack a functioning board, are short of quorum or late on filings, and lets finance, "
                    "treasury and contract signatories check who may sign for which entity and amount. It is the only source "
                    "of corporate approval dates (Corporate Resolution Subject Link, CD-259) that other products read. It "
                    "owns no certified metric family."),
        business_questions=[
            "Which active entities have no active governing body, a vacant required officer role, or an officer who has left the firm?",
            "Did each body meet as often as its Meeting Frequency requires, were meetings quorate, and are minutes approved?",
            "Which statutory filings are due in the next 60 days or overdue, by entity and jurisdiction?",
            "Who holds signing authority or a power of attorney for each entity, up to what limit, and which grants lack board approval or are held by leavers?",
            "Which officer changes required a regulatory notification, and was it filed?",
        ],
        grain=("Internal legal entity x as-of date, with child grains of governing body (CGOV-), body membership (body x member x "
               "role x effective period), officer appointment (entity x role x officer x effective period), board meeting, "
               "resolution x approved subject, statutory filing (entity x filing type x period end), power of attorney "
               "(POWER-) and signing authority grant (employee x authority type x entity x effective period)"),
        dimensions=["As-of date", "Internal legal entity, legal form and jurisdiction", "Corporate body type", "Corporate member role",
                    "Corporate officer role", "Meeting date and type", "Resolution subject type and outcome",
                    "Statutory filing type", "Authority type and monetary limit band", "Power of attorney type"],
        measures=[
            ("Entities Without Active Body", "Count of Internal Legal Entities with Entity Status active and no Corporate Governing Body with Governed Entity = the entity and Corporate Body Status active (entities whose body is a 35 fund board are excluded, see notes).",
             [("09", "Internal Legal Entity", "Legal Entity ID"), ("09", "Internal Legal Entity", "Entity Status"),
              ("39", "Corporate Governing Body", "Governed Entity"), ("39", "Corporate Governing Body", "Corporate Body Status")]),
            ("Independent Member Share %", "Active members (Membership Effective From <= as-of date, Membership Effective To empty or later) with Independent Member Indicator = Y / active members, by body.",
             [("39", "Corporate Body Membership", "Membership Body"), ("39", "Corporate Body Membership", "Independent Member Indicator"),
              ("39", "Corporate Body Membership", "Membership Effective From"), ("39", "Corporate Body Membership", "Membership Effective To")]),
            ("Vacant Officer Role Flag", "Y where an active entity has no Corporate Officer Appointment in effect for a Corporate Officer Role required for its Entity Category (maintained crosswalk, see notes).",
             [("39", "Corporate Officer Appointment", "Officer Entity"), ("39", "Corporate Officer Appointment", "Corporate Officer Role"),
              ("39", "Corporate Officer Appointment", "Officer Effective From"), ("39", "Corporate Officer Appointment", "Officer Effective To"),
              ("09", "Internal Legal Entity", "Entity Category")]),
            ("Departed Officer or Member Flag", "Y where an appointment or membership in effect names an Officer Employee or Member Employee with Employment Status not active in DP-192.",
             [("39", "Corporate Officer Appointment", "Officer Employee"), ("39", "Corporate Body Membership", "Member Employee"),
              ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status")]),
            ("Officer Change Notification Gap", "Officer appointments starting or ending in the period for a regulated role with Regulatory Notification Filing empty, or resolving to a Firm Regulatory Filing with Filing Submitted Timestamp empty (from DP-222).",
             [("39", "Corporate Officer Appointment", "Regulatory Notification Filing"), ("39", "Corporate Officer Appointment", "Corporate Officer Role"),
              ("39", "Corporate Officer Appointment", "Officer Effective From"), ("39", "Corporate Officer Appointment", "Officer Effective To"),
              ("38", "Firm Regulatory Filing", "Firm Filing ID"), ("38", "Firm Regulatory Filing", "Filing Submitted Timestamp")]),
            ("Missed Meeting Flag", "Y where a body with Corporate Body Status active held fewer Corporate Board Meetings (excluding written consents) in the last 12 months than its Meeting Frequency requires.",
             [("39", "Corporate Board Meeting", "Meeting Body"), ("39", "Corporate Board Meeting", "Corporate Meeting Date"),
              ("39", "Corporate Board Meeting", "Corporate Meeting Type"), ("39", "Corporate Governing Body", "Meeting Frequency"),
              ("39", "Corporate Governing Body", "Corporate Body Status")]),
            ("Inquorate Meetings", "Count of meetings with Quorum Present Indicator = N in the period, by body.",
             [("39", "Corporate Board Meeting", "Quorum Present Indicator"), ("39", "Corporate Board Meeting", "Corporate Meeting Date"),
              ("39", "Corporate Board Meeting", "Meeting Body")]),
            ("Minutes Pending", "Meetings more than 60 days past Corporate Meeting Date with Minutes Approval Status not approved.",
             [("39", "Corporate Board Meeting", "Minutes Approval Status"), ("39", "Corporate Board Meeting", "Corporate Meeting Date")]),
            ("Resolutions Adopted by Subject", "Count of Corporate Resolutions with Corporate Resolution Outcome = adopted by Corporate Resolution Effective Date period and Corporate Resolution Subject Type of their subject links.",
             [("39", "Corporate Resolution", "Corporate Resolution ID"), ("39", "Corporate Resolution", "Corporate Resolution Outcome"),
              ("39", "Corporate Resolution", "Corporate Resolution Effective Date"),
              ("39", "Corporate Resolution Subject Link", "Linked Corporate Resolution"),
              ("39", "Corporate Resolution Subject Link", "Corporate Resolution Subject Type")]),
            ("Statutory Filing Timeliness %", "Entity Statutory Filings with Statutory Filed Date <= Statutory Filing Due Date / filings due in the period, excluding Filing Exemption Indicator = Y, by Statutory Filing Type and the entity's Jurisdiction of Formation.",
             [("39", "Entity Statutory Filing", "Statutory Filed Date"), ("39", "Entity Statutory Filing", "Statutory Filing Due Date"),
              ("39", "Entity Statutory Filing", "Filing Exemption Indicator"), ("39", "Entity Statutory Filing", "Statutory Filing Type"),
              ("09", "Internal Legal Entity", "Jurisdiction of Formation")]),
            ("Overdue Statutory Filings", "Filings with Statutory Filing Due Date before the as-of date, Statutory Filed Date empty and Filing Exemption Indicator not Y; and filings due in the next 60 days.",
             [("39", "Entity Statutory Filing", "Filing Entity"), ("39", "Entity Statutory Filing", "Statutory Filing Due Date"),
              ("39", "Entity Statutory Filing", "Statutory Filed Date"), ("39", "Entity Statutory Filing", "Filing Exemption Indicator")]),
            ("Active Signing Authorities", "Count of Signing Authority Grants in effect (Grant Effective From <= as-of date, Grant Effective To empty or later) and Powers of Attorney in effect (Power Effective From <= as-of date, Power Revoked Date empty or later), by entity, Authority Type and monetary limit band.",
             [("39", "Signing Authority Grant", "Authority Entity"), ("39", "Signing Authority Grant", "Authority Type"),
              ("39", "Signing Authority Grant", "Authority Monetary Limit"), ("39", "Signing Authority Grant", "Grant Effective From"),
              ("39", "Signing Authority Grant", "Grant Effective To"), ("39", "Power of Attorney", "Power of Attorney ID"),
              ("39", "Power of Attorney", "Grantor Entity"), ("39", "Power of Attorney", "Power Effective From"),
              ("39", "Power of Attorney", "Power Revoked Date"), ("39", "Power of Attorney", "Power Monetary Limit")]),
            ("Departed Signatory Flag", "Y where a grant or power of attorney in effect names an Authorized Employee or Attorney Employee with Employment Status not active in DP-192.",
             [("39", "Signing Authority Grant", "Authorized Employee"), ("39", "Power of Attorney", "Attorney Employee"),
              ("20", "Employee", "Employment Status")]),
            ("Unapproved Authority Flag", "Y where a grant or power of attorney in effect has no Corporate Resolution Subject Link (Subject Authority Grant or Subject Power of Attorney) on a resolution with Corporate Resolution Outcome = adopted and Corporate Resolution Effective Date on or before the grant's effective date.",
             [("39", "Corporate Resolution Subject Link", "Subject Authority Grant"),
              ("39", "Corporate Resolution Subject Link", "Subject Power of Attorney"),
              ("39", "Corporate Resolution Subject Link", "Linked Corporate Resolution"),
              ("39", "Corporate Resolution", "Corporate Resolution Outcome"), ("39", "Corporate Resolution", "Corporate Resolution Effective Date"),
              ("39", "Signing Authority Grant", "Grant Effective From"), ("39", "Power of Attorney", "Power Effective From")]),
        ],
        inputs=[
            ("39", "Corporate Governing Body", ["Corporate Body ID", "Corporate Body Name", "Corporate Body Type", "Governed Entity",
                                                "Parent Corporate Body", "Meeting Frequency", "Corporate Body Status"]),
            ("39", "Corporate Body Membership", ["Membership Body", "Member Employee", "Member External Party",
                                                 "Corporate Member Role", "Independent Member Indicator",
                                                 "Membership Effective From", "Membership Effective To"]),
            ("39", "Corporate Officer Appointment", ["Officer Entity", "Corporate Officer Role", "Officer Employee",
                                                     "Regulatory Notification Filing", "Officer Effective From",
                                                     "Officer Effective To"]),
            ("39", "Corporate Board Meeting", ["Meeting Body", "Corporate Meeting Date", "Corporate Meeting Sequence",
                                               "Corporate Meeting Type", "Quorum Present Indicator", "Minutes Approval Status"]),
            ("39", "Corporate Resolution", ["Corporate Resolution ID", "Adopting Corporate Meeting", "Resolution Title",
                                            "Corporate Resolution Outcome", "Corporate Resolution Effective Date",
                                            "Superseded Corporate Resolution"]),
            ("39", "Corporate Resolution Subject Link", ["Linked Corporate Resolution", "Corporate Resolution Subject Type",
                                                         "Subject Contract", "Subject Body Membership",
                                                         "Subject Officer Appointment", "Subject Power of Attorney",
                                                         "Subject Authority Grant", "Subject Risk Appetite Statement",
                                                         "Subject Audit Plan", "Subject Policy Version", "Subject Debt Facility",
                                                         "Subject Capital Transaction",
                                                         "Subject Corporate Publication"]),
            ("39", "Entity Statutory Filing", ["Filing Entity", "Statutory Filing Type", "Filing Period End",
                                               "Statutory Filing Due Date", "Statutory Filed Date", "Registry Filing Reference",
                                               "Filing Exemption Indicator"]),
            ("39", "Power of Attorney", ["Power of Attorney ID", "Grantor Entity", "Attorney Employee", "Attorney Party",
                                         "Power of Attorney Type", "Power Scope", "Power Monetary Limit", "Power Effective From",
                                         "Power Revoked Date"]),
            ("39", "Signing Authority Grant", ["Authorized Employee", "Authority Type", "Authority Entity", "Authority Monetary Limit",
                                               "Dual Signature Required Indicator", "Grant Effective From", "Grant Effective To"]),
            ("38", "Firm Regulatory Filing", ["Firm Filing ID", "Filing Form Type", "Firm Filing Status", "Filing Submitted Timestamp"]),
            ("39", "Contract", ["Contract ID", "Contract Title", "Contract Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Legal Form", "Entity Category",
                                             "Jurisdiction of Formation", "Company Registration Number", "Entity Status"]),
            ("20", "Employee", ["Employee ID", "Preferred Name", "Legal Last Name", "Job Title", "Employment Status"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
        ],
        upstream=["DP-013", "DP-213", "DP-192", "DP-240", "DP-222"],
        refresh="Daily",
        timeliness="By 7am ET each business day; signing authority changes published on event within 1 hour for treasury and payment controls",
        history="Bodies, memberships, appointments, grants and powers of attorney kept as SCD type 2 for the life of the entity plus 10 years; meetings, resolutions and statutory filings kept permanently as the corporate record",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API", "File extract"],
        dq_rules=[
            "Every Corporate Governing Body has a Governed Entity that resolves to an Internal Legal Entity in DP-013, and no body governs an entity whose board is a 35 Fund Governing Body.",
            "Every Corporate Body Membership and Corporate Officer Appointment has exactly one person (Member Employee or Member External Party; Officer Employee) and effective dates with Effective To after Effective From.",
            "Every Corporate Resolution Subject Link has exactly one subject reference populated, matching its Corporate Resolution Subject Type.",
            "Every Signing Authority Grant with an Authority Type that carries a limit has Authority Monetary Limit populated, and no employee holds two overlapping grants of the same Authority Type for the same entity.",
            "Every Entity Statutory Filing has a Statutory Filing Due Date after its Filing Period End, and Registry Filing Reference is populated once Statutory Filed Date is populated.",
        ],
        notes=("W1b: Corporate Resolution Subject Link.Subject ICARA Assessment dropped, no successor (CW-939, CW-943; the ICARA Assessment left 43); no measure read it. The MLRO and SM&CR function holders leave the definition (CW-920). "
               "CD-231 and CD-259: boards of funds, fund-management entities (the CIT trustee committee) and "
               "general partners are 35 and belong to the Fund Operations products; an affiliated CIT trustee bank's own "
               "corporate board is here. What a resolution approved is held only on Corporate Resolution Subject Link; "
               "DP-224 (policy versions), DP-218 (audit plans), DP-214 (risk appetite) and DP-238 (publications) read "
               "approval dates from here and must not hold their own. Contract signature checks stay in DP-213 "
               "(Employee Signatures Without Authority); this product publishes the grants it checks against and does "
               "not recount signatures. Officer regulatory notifications are read from DP-222 (Form ADV, Form BD, FCA "
               "notifications). Bank account mandates are 43 and not covered. PII = Y: officers, members, attorneys and "
               "authorized signatories are named; monetary limits on grants are flagged personal data. Taxonomy gap: there "
               "is no record of which officer roles each entity category or regulator requires; Vacant Officer Role Flag "
               "uses a maintained crosswalk. Taxonomy gap: Corporate Governing Body has no quorum rule and Corporate Board "
               "Meeting no attendee list, so quorum is taken as recorded. Taxonomy gap: Contract has no value attribute "
               "(no commercial terms in 39), so a signature cannot be tested against Authority Monetary Limit. Open SME "
               "questions (39 Source Notes 4, 7): which internal entities have boards distinct from fund and GP boards; "
               "who maintains the signing authority matrix. Decisions: CD-231, CD-257, CD-259."),
    ),
}
