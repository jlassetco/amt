"""Data product specifications: Wave E4 consumer-aligned finance, tax and treasury products (DP-193 to DP-196 owned by
19 Finance & Accounting; DP-202 to DP-206 owned by 43 Corporate Treasury & Capital). See CONTRACT.md and
00_Program/Expansion/Product_Briefs/Corporate_Finance_and_People.md."""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-193": dict(
        definition=("The Controller's view of the period close, consolidation and the financial statements of every group "
                    "reporting entity and framework. It combines close task progress and ledger close status, balance sheet "
                    "reconciliation status, intercompany matching and elimination, the consolidation scope with its control "
                    "conclusions (including seeded funds and GP entities, triggered from DP-204's ownership share) and the "
                    "statement line values, and ties every statement line to DP-191's mapped ledger balances. It owns no "
                    "certified number: statement line values are certified only as reported and must equal DP-191's "
                    "certified balances mapped through DP-190 (CD-340)."),
        business_questions=[
            "Which ledgers are still open for the period, how many workdays into the close are we, and which key-control close tasks are overdue or blocked?",
            "Which balance sheet accounts and intercompany balances are still unreconciled or unmatched, and by how much?",
            "Does every financial statement line equal the mapped ledger balances, and where is the difference for consolidated statements explained by eliminations?",
            "Which seeded funds crossed the consolidation review trigger this period, and has a control conclusion been recorded for each?",
            "Is every controlled subsidiary in the consolidation scope with the ownership percentage that treasury measured?",
        ],
        grain=("Reporting entity or group x reporting framework x statement type x period x statement line (statements); with ledger "
               "x fiscal period x close task (close), reporting entity x counterparty entity x intercompany GL account x fiscal "
               "period (intercompany) and consolidation group x consolidated unit x fiscal period (scope) as companion facts; "
               "one locked snapshot per period"),
        dimensions=["Fiscal period and close cycle", "Ledger (entity, basis, currency, role) from DP-190",
                    "Reporting entity and consolidation group (DP-013 legal entity)", "Reporting framework and statement type",
                    "Financial statement line and GL account (DP-190)", "Counterparty entity (intercompany)",
                    "Consolidated unit: legal entity, fund product (DP-004) or seed portfolio (DP-140)",
                    "Consolidation method and control assessment basis", "Close task owner (DP-192)", "Close task status and RAG"],
        measures=[
            ("Days to Hard Close", "Business days (DP-013 calendar) from the Period End Date of the Status Fiscal Period to the Hard Close Date, by Status Ledger; ledgers not yet hard-closed show business days elapsed to the as-of date.",
             [("19", "Accounting Period Status", "Status Ledger"), ("19", "Accounting Period Status", "Status Fiscal Period"),
              ("19", "Accounting Period Status", "Hard Close Date"), ("19", "Accounting Period Status", "Period Close Status"),
              ("09", "Fiscal Period", "Period End Date")]),
            ("Reopened Periods", "Count of ledger x fiscal period rows with Period Close Status = Reopened, or with a Period Reopen Reason recorded during the close cycle.",
             [("19", "Accounting Period Status", "Period Close Status"), ("19", "Accounting Period Status", "Period Reopen Reason")]),
            ("Overdue Close Tasks", "Count of Close Tasks of the close cycle whose Due Workday (business day after the Close Cycle Period end, DP-013 calendar) has passed and whose Close Task Status is not in (Completed, Reviewed, Not Applicable), by Close Task Ledger and Close Task Owner; tasks with Close Task Status = Blocked or Close Task RAG = Red are shown separately.",
             [("19", "Close Task", "Close Task ID"), ("19", "Close Task", "Close Cycle Period"), ("19", "Close Task", "Due Workday"),
              ("19", "Close Task", "Close Task Status"), ("19", "Close Task", "Close Task RAG"),
              ("19", "Close Task", "Close Task Ledger"), ("19", "Close Task", "Close Task Owner")]),
            ("Overdue Key Control Tasks", "Overdue Close Tasks with Key Control Reference populated; the population 37 control tests sample (CD-243).",
             [("19", "Close Task", "Key Control Reference"), "Overdue Close Tasks"]),
            ("Close Task Completion %", "Close Tasks of the cycle with Close Task Status in (Completed, Reviewed, Not Applicable) / all Close Tasks of the cycle, by ledger, as of each business day of the close.",
             [("19", "Close Task", "Close Task Status"), ("19", "Close Task", "Close Cycle Period"), ("19", "Close Task", "Close Task Ledger")]),
            ("Balance Sheet Reconciliation Completion %", "Actual balances on GL accounts with GL Account Type in (Asset, Liability, Equity) and Closing Balance not zero whose Account Reconciliation Status is in (Reconciled, Reconciled within Tolerance) / all such balances, by ledger and period, by count and by absolute Closing Balance; the complement of DP-191's Unreconciled Balance Sheet Balances, read from DP-191.",
             [("19", "GL Account Balance", "Balance Ledger"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Fiscal Period"), ("19", "GL Account Balance", "Balance Type"),
              ("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Account Reconciliation Status"),
              ("19", "GL Account", "GL Account Type")]),
            ("Unmatched Intercompany Difference", "Count and sum of absolute Intercompany Difference of Intercompany Balances with Intercompany Match Status in (Break Open, Not Reconciled), by Reporting Entity x Counterparty Entity x Intercompany Period.",
             [("19", "Intercompany Balance", "Reporting Entity"), ("19", "Intercompany Balance", "Counterparty Entity"),
              ("19", "Intercompany Balance", "Intercompany Period"), ("19", "Intercompany Balance", "Intercompany Difference"),
              ("19", "Intercompany Balance", "Intercompany Match Status")]),
            ("Matched but Not Eliminated", "Count and sum of Reporting Entity Balance of Intercompany Balances between two entities in the same consolidation group with Intercompany Match Status in (Reconciled, Reconciled within Tolerance) and Eliminated Indicator = N or no Elimination Journal, after the group consolidation ledger's Hard Close Date.",
             [("19", "Intercompany Balance", "Reporting Entity Balance"), ("19", "Intercompany Balance", "Intercompany Match Status"),
              ("19", "Intercompany Balance", "Eliminated Indicator"), ("19", "Intercompany Balance", "Elimination Journal"),
              ("19", "Consolidation Scope Entity", "Consolidation Group"), ("19", "Consolidation Scope Entity", "Scope Legal Entity"),
              ("19", "Accounting Period Status", "Hard Close Date")]),
            ("Statement-to-Ledger Difference", "For each Financial Statement Line Value: Current Period Value - the mapped DP-191 balance, where the mapped balance is the sum over Actual GL Account Balances of the Statement Reporting Entity's primary ledger (Ledger Role = Primary; for a statement with Consolidated Statement Indicator = Y, Balance Type = Consolidated on the Consolidation ledger) whose Balance GL Account maps to the Value Statement Line through a Financial Statement Line Mapping effective at the Statement Period End Date, of Closing Balance for a Balance Sheet and of Closing Balance - Opening Balance for other statement types, with credit-normal lines shown positive. Expected 0 (CD-340); a difference is a reconciling item, never a second number.",
             [("19", "Financial Statement Line Value", "Current Period Value"), ("19", "Financial Statement Line Value", "Value Statement Line"),
              ("19", "Financial Statement Line Value", "Line Financial Statement"), ("19", "Financial Statement", "Statement Reporting Entity"),
              ("19", "Financial Statement", "Consolidated Statement Indicator"), ("19", "Financial Statement", "Financial Statement Type"),
              ("19", "Financial Statement", "Statement Period End Date"), ("19", "Financial Statement Line Mapping", "Mapped GL Account"),
              ("19", "Financial Statement Line Mapping", "Mapped Statement Line"), ("19", "Financial Statement Line Mapping", "Line Mapping Effective From"),
              ("19", "Financial Statement Line Mapping", "Line Mapping Effective To"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Ledger"), ("19", "GL Account Balance", "Balance Type"),
              ("19", "GL Account Balance", "Opening Balance"), ("19", "GL Account Balance", "Closing Balance"),
              ("19", "Ledger", "Ledger Legal Entity"), ("19", "Ledger", "Ledger Role")]),
            ("Seed Consolidation Triggers Not Assessed", "Seeded products with a Seed Product Holding row in the period with Consolidation Review Trigger Indicator = Y (from DP-204) and no Consolidation Scope Entity row for the same Consolidated Fund Product and Scope Fiscal Period with Consolidation Method and Control Assessment Basis populated.",
             [("43", "Seed Product Holding", "Held Seeded Product"), ("43", "Seed Product Holding", "Ownership Measurement Date"),
              ("43", "Seed Product Holding", "Consolidation Review Trigger Indicator"), ("19", "Consolidation Scope Entity", "Consolidated Fund Product"),
              ("19", "Consolidation Scope Entity", "Scope Fiscal Period"), ("19", "Consolidation Scope Entity", "Consolidation Method"),
              ("19", "Consolidation Scope Entity", "Control Assessment Basis")]),
            ("Ownership Percentage Mismatch", "Consolidation Scope Entity rows for a fund product whose Group Ownership Percentage differs by more than 0.01 percentage points from the Firm Ownership Percentage of the Seed Product Holding at the latest Ownership Measurement Date in the Scope Fiscal Period (19 holds a derived copy, CD-276).",
             [("19", "Consolidation Scope Entity", "Group Ownership Percentage"), ("19", "Consolidation Scope Entity", "Consolidated Fund Product"),
              ("19", "Consolidation Scope Entity", "Scope Fiscal Period"), ("43", "Seed Product Holding", "Firm Ownership Percentage"),
              ("43", "Seed Product Holding", "Held Seeded Product"), ("43", "Seed Product Holding", "Ownership Measurement Date")]),
            ("Subsidiaries Missing From Scope", "Active internal legal entities that are the Child Entity of an Entity Ownership Relationship effective in the period whose Parent Entity is in the consolidation group, with Ownership Percentage > 50% or Relationship Type indicating control, and no Consolidation Scope Entity row (Scope Legal Entity) for the period.",
             [("09", "Entity Ownership Relationship", "Child Entity"), ("09", "Entity Ownership Relationship", "Parent Entity"),
              ("09", "Entity Ownership Relationship", "Relationship Type"), ("09", "Entity Ownership Relationship", "Ownership Percentage"),
              ("09", "Entity Ownership Relationship", "Ownership Effective From"), ("09", "Internal Legal Entity", "Entity Status"),
              ("19", "Consolidation Scope Entity", "Scope Legal Entity"), ("19", "Consolidation Scope Entity", "Scope Fiscal Period")]),
            ("Statements Pending Approval", "Count of Financial Statements whose Statement Approval Status is not Approved for a period whose ledgers of the Statement Reporting Entity are all hard-closed, by framework and statement type.",
             [("19", "Financial Statement", "Statement Approval Status"), ("19", "Financial Statement", "Statement Reporting Framework"),
              ("19", "Financial Statement", "Financial Statement Type"), ("19", "Accounting Period Status", "Period Close Status")]),
        ],
        inputs=[
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status", "Hard Close Date",
                                                "Period Reopen Reason"]),
            ("19", "Close Task", ["Close Task ID", "Close Cycle Period", "Close Task Ledger", "Close Task Name", "Close Task Owner",
                                  "Due Workday", "Close Task Status", "Close Task RAG", "Key Control Reference"]),
            ("19", "Consolidation Scope Entity", ["Consolidation Group", "Scope Legal Entity", "Consolidated Fund Product", "Seed Portfolio",
                                                  "Scope Fiscal Period", "Consolidation Method", "Control Assessment Basis",
                                                  "Group Ownership Percentage", "GP Entity Indicator"]),
            ("19", "Intercompany Balance", ["Reporting Entity", "Counterparty Entity", "Intercompany GL Account", "Intercompany Period",
                                            "Reporting Entity Balance", "Counterparty Reported Balance", "Intercompany Difference",
                                            "Intercompany Match Status", "Eliminated Indicator", "Elimination Journal"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period",
                                          "Balance Type", "Balance Currency", "Opening Balance", "Closing Balance",
                                          "Account Reconciliation Status"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Legal Entity", "Accounting Basis", "Ledger Role", "Ledger Currency"]),
            ("19", "Financial Statement", ["Financial Statement ID", "Statement Reporting Entity", "Consolidated Statement Indicator",
                                           "Statement Reporting Framework", "Financial Statement Type", "Statement Period Type",
                                           "Statement Period End Date", "Statement Approval Status", "Statement Auditor"]),
            ("19", "Financial Statement Line Value", ["Line Financial Statement", "Value Statement Line", "Current Period Value",
                                                      "Comparative Period Value", "Value Period Basis"]),
            ("19", "Financial Statement Line", ["Statement Line Code", "Line Reporting Framework", "Line Statement Type",
                                                "External Reporting Line", "XBRL Element"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Mapped Statement Line", "Line Mapping Effective From",
                                                        "Line Mapping Effective To"]),
            ("43", "Seed Product Holding", ["Held Seeded Product", "Ownership Measurement Date", "Firm Ownership Percentage",
                                            "Consolidation Review Trigger Indicator"]),
            ("09", "Entity Ownership Relationship", ["Child Entity", "Parent Entity", "Relationship Type", "Ownership Percentage",
                                                     "Ownership Effective From"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Period End Date"]),
        ],
        upstream=["DP-190", "DP-191", "DP-192", "DP-013", "DP-204", "DP-004", "DP-140"],
        refresh="Daily",
        timeliness="By 8am ET each business day of the close window (workday -3 to workday +15); statements published on approval; period snapshot locked at the group Hard Close Date",
        history="One locked snapshot per fiscal period kept for 10 years (statements, scope, intercompany, close tasks); daily close-status snapshots kept for 24 months",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Dashboard", "BI semantic model", "Warehouse table", "File extract"],
        dq_rules=[
            "Statement-to-Ledger Difference is zero for every line of a single-entity statement before its Statement Approval Status is set to Approved.",
            "Every Intercompany Balance row has a reverse row (Reporting Entity and Counterparty Entity swapped) for the same Intercompany Period, and Intercompany Difference = Reporting Entity Balance + Counterparty Reported Balance under the sign convention.",
            "Every Consolidation Scope Entity row names exactly one consolidated unit: Scope Legal Entity, Consolidated Fund Product or Seed Portfolio.",
            "Every seeded product with Consolidation Review Trigger Indicator = Y in the period has a Consolidation Scope Entity row with Consolidation Method and Control Assessment Basis by the group consolidation ledger's Hard Close Date.",
            "Group Ownership Percentage equals DP-204's Firm Ownership Percentage at the latest Ownership Measurement Date in the period, within 0.01 percentage points.",
            "Every Close Task has a Due Workday and a Close Task Owner who is an active worker in DP-192 on the close cycle's start date.",
        ],
        notes=("Certified numbers: none owned. Statement line values are certified only as reported and must equal DP-191's mapped "
               "balances (CD-340); revenue, operating expense and operating income stay DP-191's. Close Task executions are "
               "sampled by 37 control tests (CD-243); the control library and test results are DP-214's, not held here. Seed "
               "consolidation triggers and the ownership share come from DP-204 (43 Seed Product Holding); this product reads "
               "them for the consolidation decision, which stays 19, and never revalues seed (CD-276, CD-346). Fund ledgers are "
               "27 (CD-186) and are out of scope. Operating model (CD-297): the close runs in house; if a shared-service provider "
               "runs parts of the close, the grain is unchanged and the provider's task completion and SLA results are added as "
               "oversight measures. PII = Y only because Close Task Owner names the employee accountable for a task (resolved "
               "through DP-192); the wide BI view drops the owner and is PII-free. If the parent is listed, unreleased "
               "statements are handled as Restricted - MNPI until the earnings release. CD-345: if 44 is dropped, Lease "
               "Accounting Measurement moves to 19 and this product reads it for the lease lines; if 43 folds into 19, this "
               "product is unchanged and DP-204 keeps its ID with owning domain 19. Taxonomy gap: Close Task has no completion "
               "timestamp, so on-time completion is derived from daily snapshots of Close Task Status. Taxonomy gap: Financial "
               "Statement has no approval date or approver, so Statements Pending Approval cannot be measured against a "
               "deadline. Taxonomy gap: Consolidation Scope Entity has no assessment date or approver, so evidence of the "
               "control conclusion is the row's existence in the period. Taxonomy gap: no attribute marks an Entity Ownership "
               "Relationship type as conferring control; Subsidiaries Missing From Scope uses Ownership Percentage > 50% plus "
               "the firm's Relationship Type values that mean control. Open SME questions (19 Q1, Q6, Q11): the consolidation "
               "tool; whether seed investments, GP entities and private funds are consolidated and who runs the ASC 810 / IFRS "
               "10 assessment; whether 09 Fiscal Period Status stays a copy. Decisions: CD-152, CD-186, CD-243, CD-276, CD-297, "
               "CD-340, CD-345, CD-346."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-194": dict(
        definition=("The FP&A view of the firm: actual P&L and operating expense against the enterprise budget, rolling forecasts "
                    "and the long-range plan by legal entity, cost center, statement line and fiscal period, with planned FTE set "
                    "against certified and authorized FTE. Actuals are DP-191's certified revenue, operating expense and "
                    "operating income (CD-340) and FTE is DP-192's certified FTE (CD-341); this product compares plans with them "
                    "and recalculates neither. The distribution budgets in 10 roll into the enterprise plan here, so DP-056's "
                    "distribution view and this product agree for the same cost centers."),
        business_questions=[
            "How do actual revenue, operating expense and operating income compare with budget and the latest forecast, year-to-date and for the full year, by entity and cost center?",
            "Which cost centers and statement lines drive the variance to budget, and is the full-year outturn inside the approved plan?",
            "How does certified FTE compare with planned and authorized FTE by cost center, and what is operating expense per FTE?",
            "Do the distribution budgets in the 10 plan roll into the enterprise plan without a difference?",
            "What is the operating margin by legal entity, and how does the forecast move it?",
        ],
        grain="Plan version or actual x legal entity x cost center x GL account (mapped to statement line) x fiscal period; FTE at legal entity x cost center x fiscal period end",
        dimensions=["Fiscal period and fiscal year (DP-013)", "Legal entity (DP-013)", "Cost center and segment hierarchy (DP-190)",
                    "GL account, financial statement class and statement line (DP-190)",
                    "Plan version, plan type (budget, rolling forecast, long-range plan, scenario) and scenario",
                    "Data basis (actual, plan)", "Workforce position cost center (DP-192)"],
        measures=[
            ("Actual Operating Expense", "Certified Operating Expense from DP-191: Closing Balance - Opening Balance of Actual GL Account Balances on primary ledgers for GL accounts with GL Account Type = Expense and Financial Statement Class in (Operating Expense - Compensation, Operating Expense - Distribution, Operating Expense - General and Administrative), for hard-closed periods (preliminary before), by legal entity, cost center (parsed from Balance Segment Combination) and statement line; taken as published, never re-aggregated from postings.",
             [("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Opening Balance"),
              ("19", "GL Account Balance", "Balance Type"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Segment Combination"), ("19", "GL Account Balance", "Balance Ledger"),
              ("19", "GL Account", "GL Account Type"), ("19", "GL Account", "Financial Statement Class"),
              ("19", "Ledger", "Ledger Role"), ("19", "Accounting Period Status", "Period Close Status")]),
            ("Actual Revenue", "Certified Revenue from DP-191 (GL Account Type = Revenue, shown positive), by legal entity, statement line and period, under the same ledger, balance type and close conditions.",
             [("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Opening Balance"),
              ("19", "GL Account", "GL Account Type"), ("19", "Ledger", "Ledger Role"),
              ("19", "Accounting Period Status", "Period Close Status")]),
            ("Actual Operating Income", "Certified Operating Income from DP-191 (Certified Revenue - Certified Operating Expense), by legal entity and period; read, not recomputed.",
             ["Actual Revenue", "Actual Operating Expense"]),
            ("Budget", "Sum of Plan Line Amount of Financial Plan Lines in the Financial Plan Version with Financial Plan Type = Annual Budget, Plan Scenario = Base and Plan Version Status in (Approved, Locked) for the Plan Fiscal Year, by Plan Legal Entity, cost center (parsed from Plan Segment Values), Plan GL Account and Plan Line Period.",
             [("19", "Financial Plan Line", "Plan Line Amount"), ("19", "Financial Plan Line", "Line Plan Version"),
              ("19", "Financial Plan Line", "Plan Legal Entity"), ("19", "Financial Plan Line", "Plan Segment Values"),
              ("19", "Financial Plan Line", "Plan GL Account"), ("19", "Financial Plan Line", "Plan Line Period"),
              ("19", "Financial Plan Version", "Financial Plan Type"), ("19", "Financial Plan Version", "Plan Scenario"),
              ("19", "Financial Plan Version", "Plan Version Status"), ("19", "Financial Plan Version", "Plan Fiscal Year")]),
            ("Latest Forecast", "Sum of Plan Line Amount in the most recent Financial Plan Version with Financial Plan Type = Rolling Forecast and Plan Version Status in (Approved, Locked), for the periods after its Actuals Through Period.",
             [("19", "Financial Plan Line", "Plan Line Amount"), ("19", "Financial Plan Version", "Financial Plan Type"),
              ("19", "Financial Plan Version", "Plan Version Status"), ("19", "Financial Plan Version", "Actuals Through Period"),
              ("19", "Financial Plan Version", "Plan Cycle Name")]),
            ("Variance to Budget", "Actual - Budget for the same entity, cost center, statement line and period; Variance % = Variance to Budget / Budget. Positive is overspend for expense lines and outperformance for revenue lines.",
             ["Actual Operating Expense", "Actual Revenue", "Budget"]),
            ("Full-Year Outturn", "Year-to-date actuals through the forecast's Actuals Through Period + Latest Forecast for the remaining periods of the fiscal year; Outturn vs Budget = Full-Year Outturn - full-year Budget.",
             [("19", "Financial Plan Version", "Actuals Through Period"), "Actual Operating Expense", "Actual Revenue",
              "Latest Forecast", "Budget"]),
            ("Operating Margin %", "Actual Operating Income / Actual Revenue (both from DP-191), by legal entity, year-to-date; the same ratio on Budget and Latest Forecast lines for comparison.",
             ["Actual Operating Income", "Actual Revenue", "Budget", "Latest Forecast"]),
            ("Planned FTE", "Sum of Planned FTE on Financial Plan Lines of the approved budget or latest forecast version, by Plan Legal Entity, cost center and Plan Line Period (a top-down plan measure, CD-341).",
             [("19", "Financial Plan Line", "Planned FTE"), ("19", "Financial Plan Line", "Plan Segment Values"),
              ("19", "Financial Plan Line", "Plan Line Period")]),
            ("Certified FTE", "Certified FTE from DP-192: sum of Assignment FTE of Employee Job Assignments with Assignment Type = Primary effective on the period end date, by the Position Cost Center of the Assigned Workforce Position; read as published (CD-341).",
             [("20", "Employee Job Assignment", "Assignment FTE"), ("20", "Employee Job Assignment", "Assignment Type"),
              ("20", "Employee Job Assignment", "Assigned Workforce Position"), ("20", "Employee Job Assignment", "Assignment Effective From"),
              ("20", "Employee Job Assignment", "Assignment Effective To"), ("20", "Workforce Position", "Position Cost Center")]),
            ("Authorized FTE", "Authorized FTE from DP-192: sum of Authorized FTE of Workforce Positions effective on the period end date with Position Status not Closed, by Position Cost Center and Position Legal Entity (an authorization measure, CD-341).",
             [("20", "Workforce Position", "Authorized FTE"), ("20", "Workforce Position", "Position Status"),
              ("20", "Workforce Position", "Position Cost Center"), ("20", "Workforce Position", "Position Legal Entity"),
              ("20", "Workforce Position", "Position Effective From"), ("20", "Workforce Position", "Position Effective To")]),
            ("FTE Variance to Plan", "Certified FTE - Planned FTE and Authorized FTE - Planned FTE, by cost center at the period end.",
             ["Certified FTE", "Authorized FTE", "Planned FTE"]),
            ("Operating Expense per FTE", "Annualized year-to-date Actual Operating Expense / average Certified FTE of the period ends in the year, by cost center and legal entity.",
             ["Actual Operating Expense", "Certified FTE"]),
            ("Distribution Plan Roll-In Difference", "Sum of Planned Amount of 10 Plan Lines in the 10 Plan Version whose Enterprise Financial Plan Version is the 19 version, by Plan Cost Center and Plan Period - sum of Plan Line Amount of the 19 Financial Plan Lines of that version for the same cost centers and periods; expected 0.",
             [("10", "Plan Version", "Enterprise Financial Plan Version"), ("10", "Plan Version", "Plan Version Status"),
              ("10", "Plan Line", "Planned Amount"), ("10", "Plan Line", "Plan Cost Center"), ("10", "Plan Line", "Plan Period"),
              ("19", "Financial Plan Line", "Plan Line Amount"), ("19", "Financial Plan Line", "Plan Segment Values"),
              ("19", "Financial Plan Version", "Financial Plan Version ID")]),
            ("Unmapped Plan Amount", "Sum of absolute Plan Line Amount on Plan GL Accounts with no Financial Statement Line Mapping effective in the Plan Line Period, by plan version.",
             [("19", "Financial Plan Line", "Plan GL Account"), ("19", "Financial Plan Line", "Plan Line Amount"),
              ("19", "Financial Statement Line Mapping", "Mapped GL Account"), ("19", "Financial Statement Line Mapping", "Line Mapping Effective From"),
              ("19", "Financial Statement Line Mapping", "Line Mapping Effective To")]),
        ],
        inputs=[
            ("19", "Financial Plan Version", ["Financial Plan Version ID", "Plan Cycle Name", "Financial Plan Type", "Plan Scenario",
                                              "Plan Fiscal Year", "Actuals Through Period", "Plan Version Status"]),
            ("19", "Financial Plan Line", ["Line Plan Version", "Plan Legal Entity", "Plan GL Account", "Plan Segment Values",
                                           "Plan Line Period", "Plan Line Amount", "Planned FTE"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period",
                                          "Balance Type", "Opening Balance", "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Mapped Statement Line", "Line Mapping Effective From",
                                                        "Line Mapping Effective To"]),
            ("19", "Chart Segment Value", ["Chart Segment", "Segment Value Code", "Segment Value Name", "Parent Segment Value",
                                           "Represented Org Unit", "Represented Legal Entity"]),
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Legal Entity", "Ledger Role", "Ledger Currency"]),
            ("10", "Plan Version", ["Plan Version ID", "Plan Type", "Scenario", "Plan Fiscal Year", "Plan Version Status",
                                    "Enterprise Financial Plan Version"]),
            ("10", "Plan Line", ["Plan P&L Line", "Plan Cost Center", "Plan Period", "Planned Amount"]),
            ("20", "Workforce Position", ["Workforce Position ID", "Position Legal Entity", "Position Cost Center", "Authorized FTE",
                                          "Budget Plan Line", "Position Status", "Position Effective From", "Position Effective To"]),
            ("20", "Employee Job Assignment", ["Assigned Workforce Position", "Assignment Type", "Assignment FTE",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Period End Date"]),
        ],
        upstream=["DP-190", "DP-191", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="Actuals by 9am ET on the business day after each ledger's soft close and restated at hard close; plan versions available within one business day of approval",
        history="Every approved plan version kept for 10 years; month-end actual-versus-plan snapshots locked at hard close and kept for 10 years",
        classification="Confidential - Financial",
        pii="N",
        delivery=["BI semantic model", "Dashboard", "Warehouse table"],
        dq_rules=[
            "Actual Revenue, Actual Operating Expense and Actual Operating Income for a hard-closed period equal DP-191's certified figures for the same legal entity, cost center and statement line.",
            "Exactly one Financial Plan Version with Financial Plan Type = Annual Budget, Plan Scenario = Base and Plan Version Status in (Approved, Locked) exists per Plan Fiscal Year.",
            "Every cost center code parsed from Plan Segment Values is an active Chart Segment Value with Chart Segment = Cost Center in DP-190 for the Plan Line Period.",
            "Distribution Plan Roll-In Difference is zero for every approved 19 plan version.",
            "Certified FTE and Authorized FTE equal DP-192's published values for the same cost center and period end.",
        ],
        notes=("Certified numbers: none owned. Actuals are DP-191's certified revenue, operating expense and operating income "
               "(CD-340); headcount and FTE are DP-192's certified numbers, and Planned FTE (19) and Authorized FTE (20) are plan "
               "and authorization measures compared with them, never alternative headcounts (CD-341). Compensation expense in "
               "these actuals is DP-191's (CD-347). Boundary with DP-056 Distribution Budget vs Actual: DP-056 stays the "
               "distribution cost-center view with 10 plans and partner program commitments; its actuals must equal this "
               "product's for the same cost centers, and its plans roll in here through 10 Plan Version Enterprise Financial "
               "Plan Version. Management P&L lines, allocations and profitability stay 10 (DP-035). PII = N: the product "
               "publishes cost center and entity aggregates only. The validator warns that 20 Employee Job Assignment and "
               "Workforce Position attributes are flagged personal data; they are listed only to trace Certified FTE and "
               "Authorized FTE, which are read as DP-192 aggregates by cost center and never shown per worker. If the parent is "
               "listed, unreleased actuals and forecasts are handled as Restricted - MNPI until the earnings release. "
               "Taxonomy gap: Financial Plan Line holds cost center and other segments only in Plan Segment Values (text); the "
               "cost center is parsed in DP-190's Chart Segment Structure order, as DP-191 does for balances. Taxonomy gap: no "
               "attribute holds a plan line's currency or the FX rate type used for plan translation, so plans are assumed to "
               "be in the plan legal entity's primary ledger currency. Open SME questions (19 Q9; 20 Q10; Corporate A brief Q4, "
               "Q8): the planning tool; whether position management is used (without it Authorized FTE is empty and plan FTE "
               "comes from 19 plan lines only); the headcount definition. Decisions: CD-293, CD-340, CD-341, CD-343, CD-347."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-195": dict(
        definition=("Open and settled payable invoices, supplier payments, receivable items and cash receipt applications of the "
                    "firm's own books, with aging, due dates, payment status and the bank entries behind each receipt, by legal "
                    "entity, supplier or debtor and source document. It drives payment runs, collections and accrual cut-off, "
                    "measures days payable and days sales outstanding, and ties the AP and AR subledgers to their GL control "
                    "accounts in DP-191. It starts at the accounting record: purchase orders, receipts and invoice matching are "
                    "40's (DP-221). It owns no certified number; fee receivables reconcile to DP-012's certified fee revenue."),
        business_questions=[
            "What do we owe suppliers and what are we owed, by entity, counterparty and aging bucket, and what is overdue?",
            "What share of invoices did we pay by their due date, and how are days payable and days sales outstanding trending?",
            "Did any payment go to a supplier that is not approved in the vendor master, or from a bank account that is not active?",
            "Are there possible duplicate supplier invoices before the next payment run?",
            "Do the AP and AR subledgers tie to their GL control accounts, and do fee receivables agree with certified fee revenue?",
            "Which bank receipts are still unapplied to a receivable?",
        ],
        grain="Open item (payable invoice or receivable item) x as-of date, with supplier payment x payable invoice and cash receipt x receivable item applications as detail facts; daily snapshots",
        dimensions=["As-of date and fiscal period (DP-013)", "Legal entity (DP-013)", "Supplier (DP-210) or customer party (DP-240) or debtor fund product (DP-004)",
                    "Payable document type and receivable source type", "Aging bucket", "Payment method and paying bank account (DP-202)",
                    "GL expense account and cost center (DP-190)", "Indirect tax type and recoverability"],
        measures=[
            ("Open Payables", "Invoice Gross Amount of payable invoices with Payable Invoice Status not in (Paid, Rejected, Credited), credit notes negative by Payable Document Type, less the Applied Payment Amount of Supplier Payment Applications whose Supplier Payment has Outgoing Payment Status = Paid / Settled; by Invoice Legal Entity and Supplier, aged by days past Payment Due Date (not due, 1-30, 31-60, 61-90, over 90).",
             [("19", "Payable Invoice", "Invoice Gross Amount"), ("19", "Payable Invoice", "Payable Invoice Status"),
              ("19", "Payable Invoice", "Payable Document Type"), ("19", "Payable Invoice", "Payment Due Date"),
              ("19", "Payable Invoice", "Invoice Legal Entity"), ("19", "Payable Invoice", "Supplier"),
              ("19", "Supplier Payment Application", "Applied Payment Amount"), ("19", "Supplier Payment Application", "Settled Payable Invoice"),
              ("19", "Supplier Payment", "Outgoing Payment Status")]),
            ("On-Time Payment %", "Payable invoices settled in the period whose latest applying Supplier Payment has Payment Value Date <= Payment Due Date / all payable invoices settled in the period, by count and by Invoice Gross Amount.",
             [("19", "Supplier Payment", "Payment Value Date"), ("19", "Supplier Payment Application", "Applied Supplier Payment"),
              ("19", "Supplier Payment Application", "Settled Payable Invoice"), ("19", "Payable Invoice", "Payment Due Date"),
              ("19", "Payable Invoice", "Invoice Gross Amount")]),
            ("Days Payable Outstanding", "Open Payables at the period end / Invoice Gross Amount of invoices with Invoice Date in the trailing 90 days x 90, by legal entity.",
             [("19", "Payable Invoice", "Invoice Date"), ("19", "Payable Invoice", "Invoice Gross Amount"), "Open Payables"]),
            ("Possible Duplicate Invoices", "Count of pairs of payable invoices not Rejected or Credited with the same Supplier and Invoice Gross Amount and either the same Supplier Invoice Number (after removing spaces and punctuation) or the same Invoice Date.",
             [("19", "Payable Invoice", "Supplier"), ("19", "Payable Invoice", "Supplier Invoice Number"),
              ("19", "Payable Invoice", "Invoice Gross Amount"), ("19", "Payable Invoice", "Invoice Date"),
              ("19", "Payable Invoice", "Payable Invoice Status")]),
            ("Payments to Suppliers Not Approved", "Count and Payment Amount of Supplier Payments with Outgoing Payment Status in (Released, Paid / Settled) whose Payee Supplier has no Supplier Profile (DP-210) with Supplier Status in (Approved, Restricted) effective on the Payment Value Date.",
             [("19", "Supplier Payment", "Payee Supplier"), ("19", "Supplier Payment", "Payment Amount"),
              ("19", "Supplier Payment", "Payment Value Date"), ("19", "Supplier Payment", "Outgoing Payment Status"),
              ("40", "Supplier Profile", "Supplier Party"), ("40", "Supplier Profile", "Supplier Status"),
              ("40", "Supplier Profile", "Supplier Status Effective From"), ("40", "Supplier Profile", "Supplier Status Effective To")]),
            ("Payments From Inactive Bank Accounts", "Count and Payment Amount of Supplier Payments whose Paying Bank Account has Bank Account Status not Active on the Payment Value Date, or whose Account Holder Entity differs from the Paying Legal Entity.",
             [("19", "Supplier Payment", "Paying Bank Account"), ("19", "Supplier Payment", "Paying Legal Entity"),
              ("19", "Supplier Payment", "Payment Amount"), ("19", "Supplier Payment", "Payment Value Date"),
              ("43", "Corporate Bank Account", "Corporate Bank Account ID"), ("43", "Corporate Bank Account", "Bank Account Status"),
              ("43", "Corporate Bank Account", "Account Holder Entity")]),
            ("Irrecoverable Indirect Tax", "Sum of Indirect Tax Amount x (1 - Recoverable Percentage) on payable invoice lines, where Recoverable Percentage is taken as 100% for Fully Recoverable and Reverse Charge - Self-Accounted and 0% for Irrecoverable and Exempt Supply, by legal entity, Indirect Tax Type and Line Expense Account.",
             [("19", "Indirect Tax Detail", "Indirect Tax Amount"), ("19", "Indirect Tax Detail", "Recoverable Percentage"),
              ("19", "Indirect Tax Detail", "Indirect Tax Recoverability"), ("19", "Indirect Tax Detail", "Indirect Tax Type"),
              ("19", "Payable Invoice Line", "Line Expense Account")]),
            ("Open Receivables", "Sum of Open Receivable Amount of receivable items with Receivable Status in (Open, Partially Paid, In Dispute), by Receivable Legal Entity, Receivable Source Type and debtor (Customer Party or Debtor Fund Product), aged by days past Receivable Due Date.",
             [("19", "Receivable Item", "Open Receivable Amount"), ("19", "Receivable Item", "Receivable Status"),
              ("19", "Receivable Item", "Receivable Legal Entity"), ("19", "Receivable Item", "Receivable Source Type"),
              ("19", "Receivable Item", "Customer Party"), ("19", "Receivable Item", "Debtor Fund Product"),
              ("19", "Receivable Item", "Receivable Due Date")]),
            ("Days Sales Outstanding", "Open Receivables at the period end / Original Receivable Amount of receivable items with Receivable Due Date in the trailing 90 days x 90, by legal entity and Receivable Source Type.",
             [("19", "Receivable Item", "Original Receivable Amount"), ("19", "Receivable Item", "Receivable Due Date"), "Open Receivables"]),
            ("Receivable Write-Offs", "Sum of Write-Off Amount of Cash Receipt Applications with Receipt Value Date in the period, by legal entity and Receivable Source Type.",
             [("19", "Cash Receipt Application", "Write-Off Amount"), ("19", "Cash Receipt Application", "Receipt Value Date"),
              ("19", "Cash Receipt Application", "Applied Receivable Item")]),
            ("Fee Receivable to Revenue Difference", "For receivable items with Source Fee Revenue Record: Original Receivable Amount - Net Fee Revenue of that Fee Revenue Record (from DP-012), by share class or mandate and Revenue Accounting Period; a reconciling item, never a second revenue number (CD-340).",
             [("19", "Receivable Item", "Source Fee Revenue Record"), ("19", "Receivable Item", "Original Receivable Amount"),
              ("10", "Fee Revenue Record", "Fee Revenue Record ID"), ("10", "Fee Revenue Record", "Net Fee Revenue"),
              ("10", "Fee Revenue Record", "Revenue Share Class / Mandate"), ("10", "Fee Revenue Record", "Revenue Accounting Period")]),
            ("Unapplied Receipts", "Count and Entry Amount of end-of-day Bank Statement Entries with Credit Debit Indicator = Credit on the entity's accounts, Entry Value Date more than 5 business days before the as-of date, Entry Reconciliation Status not in (Reconciled, Reconciled within Tolerance) and no Cash Receipt Application whose Bank Statement Entry Reference is the entry.",
             [("43", "Bank Statement Entry", "Credit Debit Indicator"), ("43", "Bank Statement Entry", "Entry Amount"),
              ("43", "Bank Statement Entry", "Entry Value Date"), ("43", "Bank Statement Entry", "Entry Reconciliation Status"),
              ("43", "Bank Statement Entry", "Entry Statement"), ("43", "Bank Statement Entry", "Entry Sequence Number"),
              ("19", "Cash Receipt Application", "Bank Statement Entry Reference")]),
            ("Subledger to GL Control Difference", "AP: Open Payables at the period end + Closing Balance (credit, so negative) of Actual GL Account Balances on accounts with Subledger Control Account Indicator = Y and Financial Statement Class = Payables and Accrued Liabilities (from DP-191); AR: Open Receivables - Closing Balance of control accounts with Financial Statement Class = Receivables; by ledger and period; expected 0.",
             [("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Balance Type"),
              ("19", "GL Account Balance", "Balance GL Account"), ("19", "GL Account Balance", "Balance Fiscal Period"),
              ("19", "GL Account", "Subledger Control Account Indicator"), ("19", "GL Account", "Financial Statement Class"),
              "Open Payables", "Open Receivables"]),
            ("Trade Working Capital", "Open Receivables - Open Payables at the period end, by legal entity.",
             ["Open Receivables", "Open Payables"]),
        ],
        inputs=[
            ("19", "Payable Invoice", ["Payable Invoice ID", "Payable Document Type", "Supplier", "Supplier Invoice Number", "Invoice Date",
                                       "Invoice Legal Entity", "Invoice Currency", "Invoice Gross Amount", "Payment Due Date",
                                       "Payable Invoice Status", "Source Partner Invoice", "Purchase Order Reference"]),
            ("19", "Payable Invoice Line", ["Line Payable Invoice", "Invoice Line Number", "Line Net Amount", "Line Expense Account",
                                            "Line Cost Center"]),
            ("19", "Indirect Tax Detail", ["Indirect Tax Type", "Indirect Tax Amount", "Indirect Tax Recoverability", "Recoverable Percentage"]),
            ("19", "Supplier Payment", ["Supplier Payment Document Number", "Payment Run Reference", "Payee Supplier", "Paying Legal Entity",
                                        "Payment Method", "Payment Amount", "Payment Value Date", "Paying Bank Account",
                                        "Outgoing Payment Status", "Settled Partner Payment"]),
            ("19", "Supplier Payment Application", ["Applied Supplier Payment", "Settled Payable Invoice", "Applied Payment Amount"]),
            ("19", "Receivable Item", ["Receivable Document Number", "Customer Party", "Debtor Fund Product", "Receivable Legal Entity",
                                       "Receivable Source Type", "Source Fee Invoice", "Source Fee Revenue Record",
                                       "Source Intercompany Charge", "Receivable Due Date", "Original Receivable Amount",
                                       "Open Receivable Amount", "Receivable Status"]),
            ("19", "Cash Receipt Application", ["Cash Receipt Reference", "Applied Receivable Item", "Receipt Value Date", "Applied Amount",
                                                "Write-Off Amount", "Bank Statement Entry Reference"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class", "Subledger Control Account Indicator"]),
            ("43", "Bank Statement Entry", ["Entry Statement", "Entry Sequence Number", "Credit Debit Indicator", "Entry Amount",
                                            "Entry Value Date", "Entry Reconciliation Status"]),
            ("43", "Corporate Bank Account", ["Corporate Bank Account ID", "Account Holder Entity", "Bank Account Status"]),
            ("40", "Supplier Profile", ["Supplier Party", "Supplier Status", "Supplier Status Effective From", "Supplier Status Effective To",
                                        "Default Payment Terms"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period",
                                          "Net Fee Revenue"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Period Start Date", "Period End Date"]),
        ],
        upstream=["DP-190", "DP-191", "DP-210", "DP-240", "DP-012", "DP-004", "DP-013", "DP-202"],
        refresh="Daily",
        timeliness="By 7am ET on T+1, before the day's payment run; month-end aging and subledger-to-GL tie-out by business day 3 after month-end",
        history="Daily open-item snapshots kept for 24 months; month-end snapshots and all settled items kept for 10 years (record retention for books and records)",
        classification="Confidential - Financial",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Open Payables and Open Receivables at each period end equal their GL control account balances in DP-191 (Subledger to GL Control Difference = 0) before the ledger is hard-closed.",
            "Sum of Applied Payment Amount over a Supplier Payment's applications equals its Payment Amount.",
            "Every Supplier and Payee Supplier resolves to a Supplier Profile in DP-210, and every Customer Party to a party in DP-240.",
            "Every Supplier Payment's Paying Bank Account resolves to a Corporate Bank Account in 43 whose Account Holder Entity is the Paying Legal Entity.",
            "Open Receivable Amount is between zero and Original Receivable Amount, and equals Original Receivable Amount less applied and written-off amounts.",
            "Every Receivable Item with Receivable Source Type = Fund Fee Receivable has a Debtor Fund Product or a Source Fee Revenue Record.",
        ],
        notes=("W2 re-point (CW-051, CW-912): 19 Receivable Item.Source Fee Invoice now resolves to the 47 Fee Invoice (BIL-, "
               "moved from 12 to 47 with Billing Arrangement and Billing Dispute); the attribute keeps its name. "
               "Certified numbers: none owned. Fee revenue comes from DP-012 and is not recalculated; Fee Receivable to Revenue "
               "Difference is a reconciling item (CD-340). Purchase orders, receipts, matching and supplier spend are 40 (DP-221); "
               "this product starts at the accounting record (CD-158, CD-260), and DP-221's Supplier Spend reconciles to the "
               "payable invoices here (CD-353). Partner payments settle DP-034 accruals through Settled Partner Payment and "
               "Source Partner Invoice; the accrual stays DP-034's. Bank accounts and statement entries are 43's (CD-274), read "
               "through DP-202; the receipt-to-entry link is held only on 19 Cash Receipt Application. Operating model (CD-297): "
               "in house; if a shared-service provider runs AP or collections, the grain is unchanged and the provider's SLA "
               "results are added as oversight measures through DP-219. PII = Y: Supplier, Payee Supplier, Customer Party and "
               "Remitting Party can be sole traders or individuals; the wide view replaces them with the DP-210 or DP-240 key "
               "and masks individuals' names. Taxonomy gap: Receivable Item has no document or invoice date, so Days Sales "
               "Outstanding uses Receivable Due Date as the period anchor. Taxonomy gap: Payable Invoice has no received or "
               "approved-for-payment date, so invoice processing cycle time cannot be measured. Taxonomy gap: Supplier Payment "
               "Application has no application date; on-time payment uses the applying payment's value date. Open SME "
               "questions (19 Q5, Q8, Q13): the subledger of record for fee revenue; the AP system and whether the supplier "
               "master sits in the ERP or in procurement; whether expense reimbursements owed to funds settle through AP. "
               "Decisions: CD-158, CD-260, CD-274, CD-297, CD-340, CD-343, CD-353."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-196": dict(
        definition=("The Head of Tax's view of corporate tax for every group legal entity: tax registrations, returns and their "
                    "filing status against due dates, the current and deferred tax provision by entity, jurisdiction and "
                    "component with its effective tax rate, indirect tax recoverability, and transfer pricing documentation "
                    "coverage of intercompany agreements, charges and loans. Pre-tax income is read from DP-191's balances; "
                    "the arm's length test of distribution charges stays DP-503's and is read here as evidence. Corporate tax "
                    "only: fund tax is 27 and shareholder tax reporting is DP-091 (CD-149)."),
        business_questions=[
            "Which corporate tax returns are due in the next 30 days or overdue, by entity, jurisdiction and tax type?",
            "What is the current and deferred tax expense and the effective tax rate by entity and for the group, and does the provision tie to the ledger?",
            "How large is the return-to-provision true-up for each entity and jurisdiction?",
            "Which intercompany agreements, charges and loans are not covered by contemporaneous transfer pricing documentation, and which charges fall outside the arm's length range?",
            "Does every active legal entity hold a corporate income tax registration in its jurisdiction, and how much indirect tax is irrecoverable?",
        ],
        grain="Legal entity x tax jurisdiction x tax type x tax period (returns and provision); intercompany agreement x fiscal year for transfer pricing coverage",
        dimensions=["Legal entity and group (DP-013)", "Tax jurisdiction", "Tax type", "Fiscal period and fiscal year (DP-013)",
                    "Provision component", "Tax return form and status", "Intercompany agreement, service type and TP method",
                    "TP documentation type", "Indirect tax type and recoverability"],
        measures=[
            ("Returns Due in 30 Days", "Count of Tax Returns with Return Filing Due Date within the next 30 days and Tax Return Status not in (Filed, Accepted, Amended), by Return Legal Entity, Return Tax Jurisdiction and Return Tax Type.",
             [("19", "Tax Return", "Tax Return ID"), ("19", "Tax Return", "Return Filing Due Date"), ("19", "Tax Return", "Tax Return Status"),
              ("19", "Tax Return", "Return Legal Entity"), ("19", "Tax Return", "Return Tax Jurisdiction"), ("19", "Tax Return", "Return Tax Type")]),
            ("Overdue Returns", "Count of Tax Returns whose Return Filing Due Date has passed and whose Tax Return Status is not in (Filed, Accepted, Amended, Extended).",
             [("19", "Tax Return", "Return Filing Due Date"), ("19", "Tax Return", "Tax Return Status")]),
            ("Filed On Time %", "Tax Returns whose Tax Return Status first reached Filed (from daily status snapshots) on or before the Return Filing Due Date, or that were Extended before it / all returns due in the period.",
             [("19", "Tax Return", "Tax Return Status"), ("19", "Tax Return", "Return Filing Due Date")]),
            ("Current Tax Expense", "Sum of Provision Amount with Provision Component in (Expense - Current Tax, Expense - Pillar Two Top-Up Tax), by Provision Legal Entity, Provision Tax Jurisdiction and Provision Fiscal Period.",
             [("19", "Tax Provision", "Provision Amount"), ("19", "Tax Provision", "Provision Component"),
              ("19", "Tax Provision", "Provision Legal Entity"), ("19", "Tax Provision", "Provision Tax Jurisdiction"),
              ("19", "Tax Provision", "Provision Fiscal Period")]),
            ("Deferred Tax Expense", "Sum of Provision Amount with Provision Component = Expense - Deferred Tax, by entity, jurisdiction and period.",
             [("19", "Tax Provision", "Provision Amount"), ("19", "Tax Provision", "Provision Component")]),
            ("Pre-Tax Income", "-1 x sum of (Closing Balance - Opening Balance) of Actual GL Account Balances on the entity's primary ledger (Ledger Role = Primary) for GL accounts with GL Account Type in (Revenue, Expense) and Financial Statement Class not Income Tax, by Ledger Legal Entity and fiscal period, read from DP-191's published balances; not a certified number.",
             [("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Opening Balance"),
              ("19", "GL Account Balance", "Balance Type"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Ledger"), ("19", "GL Account Balance", "Balance Fiscal Period"),
              ("19", "GL Account", "GL Account Type"), ("19", "GL Account", "Financial Statement Class"),
              ("19", "Ledger", "Ledger Role"), ("19", "Ledger", "Ledger Legal Entity")]),
            ("Effective Tax Rate", "(Current Tax Expense + Deferred Tax Expense) / Pre-Tax Income, year-to-date, by legal entity and for the group; not published where Pre-Tax Income is zero or negative (shown as not meaningful).",
             ["Current Tax Expense", "Deferred Tax Expense", "Pre-Tax Income"]),
            ("Provision-to-Ledger Difference", "Current Tax Expense + Deferred Tax Expense for the entity and period - (Closing Balance - Opening Balance) of Actual primary-ledger balances on GL accounts with Financial Statement Class = Income Tax (from DP-191); and the count of Tax Provision rows for hard-closed periods whose Provision Journal is blank or not a Journal Entry with Journal Status = Posted.",
             [("19", "Tax Provision", "Provision Journal"), ("19", "Journal Entry", "Journal ID"), ("19", "Journal Entry", "Journal Status"),
              ("19", "GL Account Balance", "Closing Balance"), ("19", "GL Account Balance", "Opening Balance"),
              ("19", "GL Account", "Financial Statement Class"), "Current Tax Expense", "Deferred Tax Expense"]),
            ("Return-to-Provision Difference", "Tax Liability Amount of the Corporate Income Tax return for the entity, jurisdiction and tax year - Current Tax Expense provided for the same entity, jurisdiction and fiscal year; the true-up booked in the following period.",
             [("19", "Tax Return", "Tax Liability Amount"), ("19", "Tax Return", "Return Tax Type"), ("19", "Tax Return", "Return Tax Period"),
              ("19", "Tax Return", "Return Legal Entity"), ("19", "Tax Return", "Return Tax Jurisdiction"), "Current Tax Expense"]),
            ("TP Documentation Coverage %", "Intercompany Agreements effective in the fiscal year that are listed in Covered Intercompany Agreements of a Transfer Pricing Documentation with TP Documentation Type in (Local File, Master File) and TP Documentation Fiscal Year = that year for the Service Provider Entity or Service Recipient Entity / all Intercompany Agreements effective in the year; also weighted by Charge Amount; contemporaneous share uses Contemporaneous Indicator = Y.",
             [("10", "Intercompany Agreement", "Intercompany Agreement ID"), ("10", "Intercompany Agreement", "Service Provider Entity"),
              ("10", "Intercompany Agreement", "Service Recipient Entity"), ("10", "Intercompany Agreement", "Agreement Effective From"),
              ("10", "Intercompany Agreement", "Agreement Effective To"), ("19", "Transfer Pricing Documentation", "Covered Intercompany Agreements"),
              ("19", "Transfer Pricing Documentation", "TP Documentation Type"), ("19", "Transfer Pricing Documentation", "TP Documentation Fiscal Year"),
              ("19", "Transfer Pricing Documentation", "Documented Legal Entity"), ("19", "Transfer Pricing Documentation", "Contemporaneous Indicator"),
              ("10", "Intercompany Charge", "Charge Amount")]),
            ("Documented vs Charged Value Difference", "Covered Transaction Value of each Transfer Pricing Documentation - sum of Charge Amount of Intercompany Charges whose Charging Agreement is covered by it and whose Charge Period falls in the TP Documentation Fiscal Year.",
             [("19", "Transfer Pricing Documentation", "Covered Transaction Value"), ("19", "Transfer Pricing Documentation", "Covered Intercompany Agreements"),
              ("19", "Transfer Pricing Documentation", "TP Documentation Fiscal Year"), ("10", "Intercompany Charge", "Charge Amount"),
              ("10", "Intercompany Charge", "Charging Agreement"), ("10", "Intercompany Charge", "Charge Period")]),
            ("Charges Outside Arm's Length Range", "Count and Charge Amount of intercompany agreements whose Arm's Length Flag in DP-503 is N for the fiscal year, read from DP-503 against the agreement's TP Policy Arm's Length Range Lower Bound and Upper Bound; not recalculated here.",
             [("10", "TP Policy", "Arm's Length Range Lower Bound"), ("10", "TP Policy", "Arm's Length Range Upper Bound"),
              ("10", "TP Policy", "TP Method"), ("10", "Intercompany Charge", "Charge Amount"), ("10", "Intercompany Charge", "Charging Agreement")]),
            ("Intercompany Loans Without TP Documentation", "Count and Loan Principal Amount of Intercompany Loans outstanding in the fiscal year (Loan Maturity Date after the year start) with no Pricing Documentation, or whose Pricing Documentation's TP Documentation Fiscal Year is earlier than the year (read through DP-203).",
             [("43", "Intercompany Loan", "Intercompany Loan ID"), ("43", "Intercompany Loan", "Loan Principal Amount"),
              ("43", "Intercompany Loan", "Loan Maturity Date"), ("43", "Intercompany Loan", "Pricing Documentation"),
              ("19", "Transfer Pricing Documentation", "TP Documentation ID"), ("19", "Transfer Pricing Documentation", "TP Documentation Fiscal Year")]),
            ("Entities Without Income Tax Registration", "Count of internal legal entities with Entity Status active and no Entity Tax Registration with Registration Tax Type = Corporate Income Tax in their Jurisdiction of Formation effective on the as-of date.",
             [("09", "Internal Legal Entity", "Legal Entity ID"), ("09", "Internal Legal Entity", "Entity Status"),
              ("09", "Internal Legal Entity", "Jurisdiction of Formation"), ("19", "Entity Tax Registration", "Registered Legal Entity"),
              ("19", "Entity Tax Registration", "Registration Tax Type"), ("19", "Entity Tax Registration", "Registration Tax Jurisdiction"),
              ("19", "Entity Tax Registration", "Registration Effective From"), ("19", "Entity Tax Registration", "Registration Effective To")]),
            ("Irrecoverable Indirect Tax", "Sum of Indirect Tax Amount x (1 - Recoverable Percentage) by legal entity and Indirect Tax Type, as in DP-195, split by Indirect Tax Recoverability.",
             [("19", "Indirect Tax Detail", "Indirect Tax Amount"), ("19", "Indirect Tax Detail", "Recoverable Percentage"),
              ("19", "Indirect Tax Detail", "Indirect Tax Recoverability"), ("19", "Indirect Tax Detail", "Indirect Tax Type")]),
        ],
        inputs=[
            ("19", "Entity Tax Registration", ["Registered Legal Entity", "Registration Tax Jurisdiction", "Registration Tax Type",
                                               "Tax Registration Number", "Registration Effective From", "Registration Effective To"]),
            ("19", "Tax Return", ["Tax Return ID", "Return Legal Entity", "Return Tax Jurisdiction", "Return Tax Type", "Tax Return Form",
                                  "Return Tax Period", "Return Filing Due Date", "Tax Return Status", "Tax Liability Amount"]),
            ("19", "Tax Provision", ["Provision Legal Entity", "Provision Fiscal Period", "Provision Tax Jurisdiction", "Provision Component",
                                     "Provision Amount", "Provision Journal"]),
            ("19", "Transfer Pricing Documentation", ["TP Documentation ID", "Documented Legal Entity", "TP Documentation Type",
                                                      "TP Documentation Fiscal Year", "Covered Intercompany Agreements",
                                                      "Covered Transaction Value", "Contemporaneous Indicator"]),
            ("19", "Indirect Tax Detail", ["Indirect Tax Type", "Indirect Tax Amount", "Indirect Tax Recoverability", "Recoverable Percentage"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Status", "Posting Accounting Period"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance",
                                          "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Legal Entity", "Ledger Role"]),
            ("10", "Intercompany Agreement", ["Intercompany Agreement ID", "Service Provider Entity", "Service Recipient Entity",
                                              "Intercompany Service Type", "Agreement Effective From", "Agreement Effective To"]),
            ("10", "TP Policy", ["TP Method", "Remuneration Basis", "Remuneration Rate", "Tested Party", "Arm's Length Range Lower Bound",
                                 "Arm's Length Range Upper Bound", "TP Documentation Reference"]),
            ("10", "Intercompany Charge", ["Intercompany Charge ID", "Charging Agreement", "Charge Period", "Charge Amount"]),
            ("43", "Intercompany Loan", ["Intercompany Loan ID", "Lending Entity", "Intercompany Borrowing Entity", "Loan Principal Amount",
                                         "Loan Maturity Date", "Pricing Documentation", "Loan Intercompany Agreement"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status", "Jurisdiction of Formation"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Period End Date"]),
        ],
        upstream=["DP-190", "DP-191", "DP-503", "DP-203", "DP-013"],
        refresh="Daily",
        timeliness="Filing calendar by 7am ET daily; provision and effective tax rate by business day 10 after quarter-end (after the provision journals post); transfer pricing coverage refreshed monthly",
        history="Every return, provision and TP documentation row kept for 10 years or the longest open statute of limitations, whichever is later; quarter-end provision snapshots locked",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Dashboard", "BI semantic model", "Warehouse table"],
        dq_rules=[
            "Every Tax Return has a Return Filing Due Date and a Return Legal Entity that is an internal legal entity in DP-013.",
            "Provision-to-Ledger Difference is zero for every hard-closed quarter-end, and every Tax Provision row for a hard-closed period has a posted Provision Journal.",
            "Every Covered Intercompany Agreements value of a Transfer Pricing Documentation resolves to a 10 Intercompany Agreement effective in the TP Documentation Fiscal Year.",
            "Every TP Policy TP Documentation Reference and every Intercompany Loan Pricing Documentation resolves to a Transfer Pricing Documentation row.",
            "Exactly one Corporate Income Tax return exists per legal entity, jurisdiction and tax year where an effective Corporate Income Tax registration exists.",
        ],
        notes=("W4 re-point (CW-910, CW-159): 10 Intercompany Charge.VAT Treatment dropped, no successor (no VAT on the US "
               "intercompany charges; US-only pass of 10); no measure read it. TP Documentation Reference keeps its name. "
               "Certified numbers: none owned. Pre-Tax Income is built from DP-191's published balances and is not a certified "
               "metric; certified revenue, operating expense and operating income stay DP-191's (CD-340). Corporate tax only "
               "(CD-149): fund tax is 27 and shareholder tax reporting is DP-091. DP-503 keeps the arm's length test of "
               "distribution intercompany charges and is upstream here as transfer pricing evidence (CD-343); Charges Outside "
               "Arm's Length Range reads its result and does not recalculate it. Intercompany loans are 43's (CD-275) and are "
               "read through DP-203. Indirect tax recoverability is shared with DP-195, which owns the AP view. If the client "
               "creates a Tax domain (Corporate A brief Q7), this product moves with the 19 Corporate Tax family unchanged. "
               "Uncertain tax position balances (Provision Component = Balance - Uncertain Tax Position Liability) are shown "
               "only to the tax team; the wider view drops them. If the parent is listed, unreleased provision figures are "
               "handled as Restricted - MNPI until the earnings release. Documentation Owner is not read, so the product holds "
               "no personal data. Taxonomy gap: Tax Return has no filed date and no extended due date, so Filed On Time % is "
               "derived from daily status snapshots and extensions are recognized only by status. Taxonomy gap: Tax Provision "
               "holds no pre-tax income, statutory rate or rate reconciliation items, so the effective tax rate is computed "
               "from DP-191 balances and its reconciliation to the statutory rate is not available. Taxonomy gap: Covered "
               "Intercompany Agreements is a multi-valued reference held as a list, so coverage is resolved by parsing it. "
               "Open SME questions (19 Q7): who owns corporate tax data today and whether a Tax domain is created. Decisions: "
               "CD-149, CD-191, CD-275, CD-340, CD-343."
               "WP1 re-point (CW-910, CW-240): upstream DP-074 (retired) replaced by its successor DP-503 Intercompany Charges & Transfer Pricing (WP1C_DIS candidate), which tests charges against the arm's length range on the 10 Intercompany Agreement, TP Policy and Intercompany Charge objects read here; Charges Outside Arm's Length Range reads DP-503's result. No input or measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-202": dict(
        definition=("Bank accounts and mandates of every group entity, intraday and end-of-day statements, cash positions, the "
                    "cash forecast by entity, currency and category, short-term investments and bank fees, reconciled to the cash "
                    "GL accounts in DP-191. It supports the Group Treasurer's daily liquidity, funding and investment decisions, "
                    "bank counterparty limits and bank mandate control. Corporate accounts only (CD-274): fund cash and CASS "
                    "client money are 28. 43 decides and 19 books (CD-275): the cash GL balance is DP-191's and is compared "
                    "here, not re-published. Corporate Bank Account is the SM-00 Bank Account dimension source until a "
                    "foundational treasury product is justified."),
        business_questions=[
            "How much cash does each group entity hold by bank and currency today, and what is the projected position for the next five business days?",
            "Does every bank account's balance agree with its cash GL account, and which statement entries are still unreconciled?",
            "How accurate was last week's cash forecast by entity and currency?",
            "Are deposits and balances with any bank above its counterparty limit, and which short-term investments mature this week?",
            "Which bank mandates still name signatories who have left, and which active accounts lack dual control?",
            "What are we paying in net bank fees by bank?",
        ],
        grain="Corporate bank account x value date x position version (cash); with bank statement entry, cash forecast line (forecast x legal entity x currency x cash flow category x value date bucket), short-term investment placement and bank account signatory x effective period as companion facts",
        dimensions=["Value date and fiscal period (DP-013)", "Legal entity (DP-013)", "Bank (DP-240 party)", "Corporate bank account and purpose",
                    "Currency (DP-013)", "Cash flow category", "Short-term investment type", "Signatory employee (DP-192)",
                    "Cash GL account (DP-190)", "Bank relationship tier"],
        measures=[
            ("Bank Cash Balance", "Closing Booked Balance of the account's End-of-Day Statement for the Statement Date (highest Statement Sequence Number), in Account Currency and translated to the group reporting currency (09 Currency with Group Reporting Currency Indicator = Y) at the Spot Rate of the DP-143 FX Rate Observation of the treasury rate type for that date, by Account Holder Entity, Account Servicing Bank, Account Currency and Bank Account Purpose.",
             [("43", "Bank Statement", "Closing Booked Balance"), ("43", "Bank Statement", "Bank Statement Type"),
              ("43", "Bank Statement", "Statement Date"), ("43", "Bank Statement", "Statement Sequence Number"),
              ("43", "Bank Statement", "Statement Account"), ("43", "Corporate Bank Account", "Account Currency"),
              ("43", "Corporate Bank Account", "Account Holder Entity"), ("43", "Corporate Bank Account", "Account Servicing Bank"),
              ("43", "Corporate Bank Account", "Bank Account Purpose"), ("09", "Currency", "Group Reporting Currency Indicator"),
              ("09", "FX Rate Type", "Approved Usage"), ("22", "FX Rate Observation", "Spot Rate"),
              ("22", "FX Rate Observation", "Observed FX Rate Type"), ("22", "FX Rate Observation", "FX Rate Date")]),
            ("Statement Continuity Breaks", "Count of end-of-day Bank Statements whose Opening Booked Balance differs from the Closing Booked Balance of the account's previous end-of-day statement, plus active accounts with no end-of-day statement for a business day (DP-013 calendar).",
             [("43", "Bank Statement", "Opening Booked Balance"), ("43", "Bank Statement", "Closing Booked Balance"),
              ("43", "Bank Statement", "Statement Date"), ("43", "Bank Statement", "Bank Statement Type"),
              ("43", "Corporate Bank Account", "Bank Account Status")]),
            ("Bank-to-Book Difference", "At each fiscal period end: sum of Bank Cash Balance (Account Currency) of the accounts sharing a Cash GL Account - Closing Balance of the Actual GL Account Balance of that GL account in the same Balance Currency (from DP-191); expected 0 after reconciling items.",
             [("43", "Corporate Bank Account", "Cash GL Account"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Currency"), ("19", "GL Account Balance", "Balance Type"),
              ("19", "GL Account Balance", "Balance Fiscal Period"), ("19", "GL Account Balance", "Closing Balance"),
              ("09", "Fiscal Period", "Period End Date"), "Bank Cash Balance"]),
            ("Unreconciled Bank Entries", "Count and sum of absolute Entry Amount of entries of end-of-day statements with Entry Reconciliation Status in (Break Open, Not Reconciled), aged by business days since Entry Value Date; entries marked reconciled with no Matched Journal Entry are counted as exceptions.",
             [("43", "Bank Statement Entry", "Entry Reconciliation Status"), ("43", "Bank Statement Entry", "Entry Amount"),
              ("43", "Bank Statement Entry", "Entry Value Date"), ("43", "Bank Statement Entry", "Matched Journal Entry"),
              ("43", "Bank Statement Entry", "Entry Statement"), ("43", "Bank Statement", "Bank Statement Type")]),
            ("Projected Liquidity", "Sum of Projected Closing Position of the latest Position Version per Position Bank Account and Position Value Date, for the next five business days, by entity and currency (through the account), plus Placement Amount of short-term investments maturing on those dates.",
             [("43", "Cash Position", "Projected Closing Position"), ("43", "Cash Position", "Position Version"),
              ("43", "Cash Position", "Position Bank Account"), ("43", "Cash Position", "Position Value Date"),
              ("43", "Short-Term Investment", "Placement Amount"), ("43", "Short-Term Investment", "Investment Maturity Date")]),
            ("Cash Forecast Accuracy %", "Per legal entity x currency x weekly bucket: 1 - |actual net movement - forecast net movement| / |actual net movement|, where actual = signed sum (Credit Debit Indicator) of Entry Amount of end-of-day statement entries on the entity's accounts with Entry Value Date in the bucket, and forecast = sum of Forecast Amount of the Cash Forecast Lines (all categories) of the latest Cash Forecast with Forecast Approval Status = Approved whose Forecast As-Of Date is before the Bucket Start Date.",
             [("43", "Bank Statement Entry", "Entry Amount"), ("43", "Bank Statement Entry", "Credit Debit Indicator"),
              ("43", "Bank Statement Entry", "Entry Value Date"), ("43", "Cash Forecast", "Forecast As-Of Date"),
              ("43", "Cash Forecast", "Forecast Approval Status"), ("43", "Cash Forecast Line", "Forecast Amount"),
              ("43", "Cash Forecast Line", "Line Legal Entity"), ("43", "Cash Forecast Line", "Line Currency"),
              ("43", "Cash Forecast Line", "Bucket Start Date"), ("43", "Cash Forecast Line", "Line Cash Forecast")]),
            ("Short-Term Investments Outstanding", "Sum of Placement Amount of Short-Term Investments with Placement Date <= as-of date < Investment Maturity Date, by Placing Entity, Short-Term Investment Type, Deposit Counterparty or Money Market Fund Share Class, with the amount maturing within 7 days and the amount-weighted Placement Interest Rate.",
             [("43", "Short-Term Investment", "Placement Amount"), ("43", "Short-Term Investment", "Placement Date"),
              ("43", "Short-Term Investment", "Investment Maturity Date"), ("43", "Short-Term Investment", "Placing Entity"),
              ("43", "Short-Term Investment", "Short-Term Investment Type"), ("43", "Short-Term Investment", "Deposit Counterparty"),
              ("43", "Short-Term Investment", "Money Market Fund Share Class"), ("43", "Short-Term Investment", "Placement Interest Rate")]),
            ("Bank Counterparty Limit Utilization %", "(Bank Cash Balance of accounts with Account Servicing Bank = the bank + Short-Term Investments Outstanding with Deposit Counterparty = the bank) / Bank Counterparty Limit Amount of the Bank Relationship Profile effective on the date; above 100% is a limit breach.",
             [("43", "Bank Relationship Profile", "Relationship Bank"), ("43", "Bank Relationship Profile", "Bank Counterparty Limit Amount"),
              ("43", "Bank Relationship Profile", "Profile Effective From"), ("43", "Bank Relationship Profile", "Profile Effective To"),
              "Bank Cash Balance", "Short-Term Investments Outstanding"]),
            ("Net Bank Fees", "Total Service Charges - Earnings Credit Amount of Bank Fee Statements, by bank (through the Fee Statement Account) and Fee Billing Period End.",
             [("43", "Bank Fee Statement", "Total Service Charges"), ("43", "Bank Fee Statement", "Earnings Credit Amount"),
              ("43", "Bank Fee Statement", "Fee Statement Account"), ("43", "Bank Fee Statement", "Fee Billing Period End")]),
            ("Signatories No Longer Employed", "Count of Bank Account Signatory rows effective on the as-of date (Signatory Effective From <= date < Signatory Effective To or open) whose Signatory Employee has Employment Status = Terminated or a Termination Date before the as-of date in DP-192.",
             [("43", "Bank Account Signatory", "Signatory Employee"), ("43", "Bank Account Signatory", "Signatory Effective From"),
              ("43", "Bank Account Signatory", "Signatory Effective To"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status"), ("20", "Employee", "Termination Date")]),
            ("Accounts Without Dual Control", "Count of accounts with Bank Account Status active that have fewer than two effective signatory rows, or whose effective signatories all have Dual Signature Required Indicator = N with no Signing Limit Amount.",
             [("43", "Bank Account Signatory", "Signatory Account"), ("43", "Bank Account Signatory", "Dual Signature Required Indicator"),
              ("43", "Bank Account Signatory", "Signing Limit Amount"), ("43", "Bank Account Signatory", "Signatory Authority Level"),
              ("43", "Corporate Bank Account", "Bank Account Status")]),
            ("Closed Accounts With Balance", "Count and Bank Cash Balance of accounts with Account Closed Date on or before the as-of date whose latest end-of-day Closing Booked Balance is not zero.",
             [("43", "Corporate Bank Account", "Account Closed Date"), ("43", "Corporate Bank Account", "Corporate Bank Account ID"),
              "Bank Cash Balance"]),
        ],
        inputs=[
            ("43", "Corporate Bank Account", ["Corporate Bank Account ID", "Account Holder Entity", "Account Servicing Bank", "Bank Account Number",
                                              "Account IBAN", "Account Currency", "Bank Account Purpose", "Cash GL Account",
                                              "Bank Account Status", "Account Opened Date", "Account Closed Date"]),
            ("43", "Bank Account Signatory", ["Signatory Account", "Signatory Employee", "Signatory Party", "Signatory Authority Level",
                                              "Dual Signature Required Indicator", "Signing Limit Amount", "Signatory Effective From",
                                              "Signatory Effective To"]),
            ("43", "Cash Pool Membership", ["Pool Participant Account", "Pool Header Account", "Cash Pool Role", "Pool Intercompany Loan",
                                            "Membership Effective From", "Membership Effective To"]),
            ("43", "Bank Relationship Profile", ["Relationship Bank", "Bank Relationship Tier", "Bank Counterparty Limit Amount",
                                                 "Profile Effective From", "Profile Effective To"]),
            ("43", "Bank Fee Statement", ["Fee Statement Account", "Fee Billing Period End", "Total Service Charges", "Earnings Credit Amount"]),
            ("43", "Bank Statement", ["Statement Account", "Bank Statement Type", "Statement Date", "Statement Sequence Number",
                                      "Opening Booked Balance", "Closing Booked Balance"]),
            ("43", "Bank Statement Entry", ["Entry Statement", "Entry Sequence Number", "Credit Debit Indicator", "Entry Amount", "Booking Date",
                                            "Entry Value Date", "Bank Transaction Code", "End-to-End Reference",
                                            "Entry Reconciliation Status", "Matched Journal Entry"]),
            ("43", "Cash Position", ["Position Bank Account", "Position Value Date", "Position Version", "Position Data Basis",
                                     "Starting Cash Position", "Projected Closing Position"]),
            ("43", "Cash Forecast", ["Cash Forecast ID", "Forecast As-Of Date", "Forecast Approval Status", "Aligned Financial Plan Version"]),
            ("43", "Cash Forecast Line", ["Line Cash Forecast", "Line Legal Entity", "Line Currency", "Cash Flow Category", "Bucket Start Date",
                                          "Forecast Amount", "Line Data Basis"]),
            ("43", "Short-Term Investment", ["Short-Term Investment Reference", "Placing Entity", "Short-Term Investment Type",
                                             "Deposit Counterparty", "Money Market Fund Share Class", "Placement Amount", "Placement Date",
                                             "Investment Maturity Date", "Placement Interest Rate"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Balance Currency",
                                          "Closing Balance", "Account Reconciliation Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Termination Date"]),
            ("22", "FX Rate Observation", ["Observed FX Rate Type", "Base Currency", "Quote Currency", "FX Rate Date", "Spot Rate",
                                           "FX Observation Status"]),
            ("09", "Currency", ["Currency Code", "Group Reporting Currency Indicator"]),
            ("09", "FX Rate Type", ["FX Rate Type Code", "Approved Usage"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Period End Date"]),
        ],
        upstream=["DP-190", "DP-191", "DP-192", "DP-013", "DP-004", "DP-143", "DP-240"],
        refresh="Intraday",
        timeliness="Intraday account reports within 30 minutes of each camt.052 receipt; end-of-day positions by 8am local time on T+1; month-end bank-to-book tie-out by business day 3",
        history="End-of-day statements, entries and positions kept for 10 years; intraday reports kept for 90 days; signatory and account history SCD type 2 for the life of the account plus 10 years",
        classification="Restricted",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every active Corporate Bank Account has a Cash GL Account that is an active GL account in DP-190 for the Account Holder Entity's ledger.",
            "Each end-of-day Bank Statement's Opening Booked Balance equals the previous end-of-day statement's Closing Booked Balance for the same account.",
            "Bank-to-Book Difference is zero, or fully explained by entries with Entry Reconciliation Status = Break Explained, before the ledger period is hard-closed.",
            "Every Bank Account Signatory row has exactly one of Signatory Employee and Signatory Party populated.",
            "Every effective Cash Pool Membership's Pool Participant Account and Pool Header Account are different active Corporate Bank Accounts with the same Account Currency.",
            "Only one Cash Forecast per forecast name and Forecast As-Of Date has Forecast Approval Status = Approved.",
        ],
        notes=("Certified numbers: none owned; the cash GL balance is DP-191's and is compared, never re-published (CD-275). "
               "Corporate accounts only (CD-274): fund cash and CASS client money are 28 (Fund Operations products), and a "
               "corporate bank account is never a 28 safekeeping account or a 15 account. Corporate Bank Account is the SM-00 "
               "Bank Account dimension source until a foundational treasury product is justified (Corporate A brief, hardest "
               "call 4); DP-195 reads accounts and entries from here. Banks and deposit counterparties are 02 parties from "
               "DP-240; money market fund share classes from DP-004; FX rates from DP-143. Operating model: in house on a "
               "treasury management system; open SME question (43 Q2) whether the TMS or 19 performs the bank reconciliation, "
               "which changes who sets Entry Reconciliation Status, not the grain. Classification Restricted because Bank "
               "Account Number and Account IBAN are restricted for corporate accounts; the wide view masks both and drops "
               "signatories (Confidential - Financial). PII = Y because Bank Account Signatory names employees and outside "
               "directors with their signing limits. CD-345: if 43 folds into 19, this product keeps its ID, name and scope "
               "with owning domain 19 and the owner role moves to the Finance treasury lead. Taxonomy gap: Bank Statement Entry "
               "has no cash flow category, so forecast accuracy is measured on net movement by entity and currency, not by "
               "Cash Flow Category. Taxonomy gap: Cash Position holds no currency or entity of its own; both are read through "
               "the account. Taxonomy gap: no attribute names the FX rate type approved for treasury translation; 09 FX Rate "
               "Type Approved Usage is used to select it. Open SME questions (43 Q2, Q9): the TMS and reconciliation owner; "
               "whether corporate cash is invested in own money market funds. Decisions: CD-274, CD-275, CD-297, CD-345."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-203": dict(
        definition=("Debt facilities with drawdowns and covenant headroom, intercompany loans and intra-group capital transactions "
                    "(dividends, capital contributions, share issues and reductions), corporate FX and interest rate exposures, "
                    "treasury deals with their valuations, and hedge relationships with effectiveness results. It supports the "
                    "Group Treasurer's funding, dividend and capital repatriation decisions and gives the Controller the hedge "
                    "accounting evidence to book. 43 decides and 19 books (CD-275): no balance or journal is mastered here; "
                    "intercompany loans are compared with DP-191's intercompany balances. It owns no certified number."),
        business_questions=[
            "How much is drawn and undrawn on each facility, what matures in the next 12 months, and how much covenant headroom remains?",
            "What intercompany loans are outstanding between which entities, and do they agree with the ledgers' intercompany balances?",
            "What dividends and capital have entities paid up and down the group this year?",
            "How much of each corporate FX and rate exposure is hedged, and what is the mark-to-market of treasury deals by counterparty bank?",
            "Which hedge relationships failed their effectiveness test, and is the ineffectiveness booked?",
            "Is every treasury deal with a counterparty approved for that dealing entity?",
        ],
        grain="Funding or hedging record (debt facility, drawdown, intercompany loan, intra-group capital transaction, corporate exposure, treasury deal, hedge relationship) x as-of date, with deal valuation, covenant test and effectiveness test by test or valuation date",
        dimensions=["As-of date and fiscal period (DP-013)", "Legal entity: borrowing, lending, dealing, paying and receiving (DP-013)",
                    "Lender and counterparty bank (DP-240, DP-115)", "Debt facility type", "Intercompany loan type",
                    "Treasury instrument type", "Currency and reference rate (DP-143)", "Corporate exposure type",
                    "Hedge type, hedged risk and accounting framework", "Covenant metric"],
        measures=[
            ("Drawn Debt", "Sum of Drawn Amount of Debt Facility Drawdowns with Drawdown Date <= as-of date and Actual Repayment Date blank or after it, by Drawn Debt Facility and Borrowing Entity.",
             [("43", "Debt Facility Drawdown", "Drawn Amount"), ("43", "Debt Facility Drawdown", "Drawdown Date"),
              ("43", "Debt Facility Drawdown", "Actual Repayment Date"), ("43", "Debt Facility Drawdown", "Drawn Debt Facility"),
              ("43", "Debt Facility", "Borrowing Entity")]),
            ("Facility Headroom", "Debt Facility Commitment Amount - Drawn Debt for facilities with Facility Maturity Date after the as-of date; Utilization % = Drawn Debt / Debt Facility Commitment Amount.",
             [("43", "Debt Facility", "Debt Facility Commitment Amount"), ("43", "Debt Facility", "Facility Maturity Date"), "Drawn Debt"]),
            ("Debt Maturing in 12 Months", "Drawn Debt whose Scheduled Repayment Date, or the facility's Facility Maturity Date, falls within 12 months of the as-of date, by quarter.",
             [("43", "Debt Facility Drawdown", "Scheduled Repayment Date"), ("43", "Debt Facility", "Facility Maturity Date"), "Drawn Debt"]),
            ("Covenant Headroom %", "For the latest Corporate Covenant Test per Tested Debt Facility and Covenant Metric: (Covenant Threshold Value - Measured Covenant Value) / Covenant Threshold Value when Threshold Is Maximum Indicator = Y, else (Measured Covenant Value - Covenant Threshold Value) / Covenant Threshold Value; below 10% is on watch.",
             [("43", "Corporate Covenant Test", "Covenant Threshold Value"), ("43", "Corporate Covenant Test", "Measured Covenant Value"),
              ("43", "Corporate Covenant Test", "Threshold Is Maximum Indicator"), ("43", "Corporate Covenant Test", "Covenant Test Date"),
              ("43", "Corporate Covenant Test", "Tested Debt Facility"), ("43", "Corporate Covenant Test", "Covenant Metric")]),
            ("Covenant Breaches", "Count of latest covenant tests with Covenant Met Indicator = N, by facility and metric.",
             [("43", "Corporate Covenant Test", "Covenant Met Indicator"), ("43", "Corporate Covenant Test", "Covenant Test Date")]),
            ("Intercompany Loans Outstanding", "Sum of Loan Principal Amount of Intercompany Loans with Loan Maturity Date after the as-of date, by Lending Entity, Intercompany Borrowing Entity and Intercompany Loan Type.",
             [("43", "Intercompany Loan", "Loan Principal Amount"), ("43", "Intercompany Loan", "Loan Maturity Date"),
              ("43", "Intercompany Loan", "Lending Entity"), ("43", "Intercompany Loan", "Intercompany Borrowing Entity"),
              ("43", "Intercompany Loan", "Intercompany Loan Type")]),
            ("Intercompany Loan to Ledger Difference", "Per lending x borrowing entity pair and fiscal period: Intercompany Loans Outstanding at the period end - Reporting Entity Balance of the lender's Intercompany Balances with Counterparty Entity = the borrower on the intercompany loan receivable GL accounts (from DP-191); pairs whose Intercompany Match Status is not reconciled are flagged.",
             [("19", "Intercompany Balance", "Reporting Entity"), ("19", "Intercompany Balance", "Counterparty Entity"),
              ("19", "Intercompany Balance", "Intercompany GL Account"), ("19", "Intercompany Balance", "Intercompany Period"),
              ("19", "Intercompany Balance", "Reporting Entity Balance"), ("19", "Intercompany Balance", "Intercompany Match Status"),
              "Intercompany Loans Outstanding"]),
            ("Intra-Group Capital Paid", "Sum of Capital Transaction Amount by Intra-Group Capital Transaction Type, Paying Entity and Receiving Entity, for transactions with Capital Transaction Effective Date in the year to date.",
             [("43", "Intra-Group Capital Transaction", "Capital Transaction Amount"), ("43", "Intra-Group Capital Transaction", "Intra-Group Capital Transaction Type"),
              ("43", "Intra-Group Capital Transaction", "Paying Entity"), ("43", "Intra-Group Capital Transaction", "Receiving Entity"),
              ("43", "Intra-Group Capital Transaction", "Capital Transaction Effective Date")]),
            ("Hedge Coverage %", "Per Corporate Exposure in its exposure period: sum of Deal Notional Amount of the Hedging Treasury Deals (Treasury Deal Status not in (Matured, Closed Out, Canceled)) of Hedge Relationships with Hedge Relationship Status active whose Hedged Exposure is the exposure / Exposure Amount; Unhedged Exposure = Exposure Amount - hedged notional, by Corporate Exposure Type, Exposure Currency and Exposure Legal Entity.",
             [("43", "Corporate Exposure", "Exposure Amount"), ("43", "Corporate Exposure", "Corporate Exposure Type"),
              ("43", "Corporate Exposure", "Exposure Currency"), ("43", "Corporate Exposure", "Exposure Legal Entity"),
              ("43", "Corporate Exposure", "Exposure Period Start"), ("43", "Corporate Exposure", "Exposure Period End"),
              ("43", "Hedge Relationship", "Hedged Exposure"), ("43", "Hedge Relationship", "Hedging Treasury Deals"),
              ("43", "Hedge Relationship", "Hedge Relationship Status"), ("43", "Treasury Deal", "Deal Notional Amount"),
              ("43", "Treasury Deal", "Treasury Deal Status")]),
            ("Treasury Deal Mark-to-Market", "Sum of Mark-to-Market Value at the latest Deal Valuation Date of treasury deals with Treasury Deal Status not in (Matured, Closed Out, Canceled), by Treasury Instrument Type, Dealing Entity and Deal Counterparty Bank; positive values by counterparty bank are the firm's credit exposure to it.",
             [("43", "Treasury Deal Valuation", "Mark-to-Market Value"), ("43", "Treasury Deal Valuation", "Deal Valuation Date"),
              ("43", "Treasury Deal Valuation", "Valued Treasury Deal"), ("43", "Treasury Deal", "Treasury Instrument Type"),
              ("43", "Treasury Deal", "Dealing Entity"), ("43", "Treasury Deal", "Deal Counterparty Bank"),
              ("43", "Treasury Deal", "Treasury Deal Status")]),
            ("Deals With Unapproved Counterparty", "Count and Deal Notional Amount of treasury deals with Deal Trade Date in the period whose Deal Counterparty Bank has no Counterparty Approval Scope (DP-115) with Scope Status active, Scope Trading Entity = Dealing Entity and Scope Effective From <= Deal Trade Date < Scope Effective To, or whose Governing Trading Agreement is not an active Trading Agreement with that counterparty (DP-147).",
             [("43", "Treasury Deal", "Deal Counterparty Bank"), ("43", "Treasury Deal", "Dealing Entity"), ("43", "Treasury Deal", "Deal Trade Date"),
              ("43", "Treasury Deal", "Deal Notional Amount"), ("43", "Treasury Deal", "Governing Trading Agreement"),
              ("25", "Counterparty Approval Scope", "Scope Counterparty"), ("25", "Counterparty Approval Scope", "Scope Trading Entity"),
              ("25", "Counterparty Approval Scope", "Scope Status"), ("25", "Counterparty Approval Scope", "Scope Effective From"),
              ("25", "Counterparty Approval Scope", "Scope Effective To"), ("26", "Trading Agreement", "Trading Agreement ID"),
              ("26", "Trading Agreement", "Agreement Counterparty"), ("26", "Trading Agreement", "Agreement Status")]),
            ("Ineffective Hedges", "Count of Hedge Relationships with Hedge Relationship Status active and Hedge Accounting Framework not Not Designated whose latest Hedge Effectiveness Test has Highly Effective Indicator = N; and the sum of Ineffectiveness Amount in the period, by Hedge Type and Hedged Risk.",
             [("43", "Hedge Effectiveness Test", "Highly Effective Indicator"), ("43", "Hedge Effectiveness Test", "Effectiveness Test Date"),
              ("43", "Hedge Effectiveness Test", "Ineffectiveness Amount"), ("43", "Hedge Effectiveness Test", "Tested Hedge Relationship"),
              ("43", "Hedge Relationship", "Hedge Accounting Framework"), ("43", "Hedge Relationship", "Hedge Type"),
              ("43", "Hedge Relationship", "Hedged Risk"), ("43", "Hedge Relationship", "Hedge Relationship Status")]),
            ("Unbooked Ineffectiveness", "Count and amount of Hedge Effectiveness Tests with Ineffectiveness Amount not zero whose Ineffectiveness Journal is blank or is not a Journal Entry with Journal Status = Posted, more than five business days after the Effectiveness Test Date.",
             [("43", "Hedge Effectiveness Test", "Ineffectiveness Amount"), ("43", "Hedge Effectiveness Test", "Ineffectiveness Journal"),
              ("43", "Hedge Effectiveness Test", "Effectiveness Test Date"), ("19", "Journal Entry", "Journal ID"),
              ("19", "Journal Entry", "Journal Status")]),
        ],
        inputs=[
            ("43", "Debt Facility", ["Debt Facility ID", "Borrowing Entity", "Debt Facility Type", "Lender Parties",
                                     "Debt Facility Commitment Amount", "Facility Reference Rate", "Facility Rate Tenor", "Facility Margin",
                                     "Facility Maturity Date"]),
            ("43", "Debt Facility Drawdown", ["Drawdown Reference", "Drawn Debt Facility", "Drawn Amount", "Drawdown Date", "Rate Fixing Used",
                                              "Reference Rate Fixing Value", "Scheduled Repayment Date", "Actual Repayment Date"]),
            ("43", "Corporate Covenant Test", ["Tested Debt Facility", "Covenant Metric", "Covenant Test Date", "Covenant Threshold Value",
                                               "Threshold Is Maximum Indicator", "Measured Covenant Value", "Covenant Met Indicator"]),
            ("43", "Intercompany Loan", ["Intercompany Loan ID", "Lending Entity", "Intercompany Borrowing Entity", "Intercompany Loan Type",
                                         "Loan Principal Amount", "Loan Reference Rate", "Loan Rate Tenor", "Loan Margin", "Loan Fixed Rate",
                                         "Loan Maturity Date", "Pricing Documentation", "Loan Intercompany Agreement"]),
            ("43", "Intra-Group Capital Transaction", ["Capital Transaction Reference", "Intra-Group Capital Transaction Type", "Paying Entity",
                                                       "Receiving Entity", "Capital Transaction Amount", "Capital Transaction Effective Date",
                                                       "Regulatory Prior Notice Required Indicator"]),
            ("43", "Corporate Exposure", ["Exposure Legal Entity", "Corporate Exposure Type", "Exposure Currency", "Exposure Rate Index",
                                          "Exposure Seed Commitment", "Exposure Debt Facility", "Exposure Period Start", "Exposure Period End",
                                          "Exposure Amount", "Exposure Data Basis"]),
            ("43", "Treasury Deal", ["Treasury Deal ID", "Treasury Instrument Type", "Dealing Entity", "Deal Counterparty Bank",
                                     "Governing Trading Agreement", "Deal Direction", "Deal Notional Amount", "Counter Currency", "Deal Rate",
                                     "Deal Trade Date", "Deal Value Date", "Deal Maturity Date", "Treasury Deal Status"]),
            ("43", "Treasury Deal Valuation", ["Valued Treasury Deal", "Deal Valuation Date", "Mark-to-Market Value", "Valuation Spot Rate"]),
            ("43", "Hedge Relationship", ["Hedge Relationship ID", "Hedge Type", "Hedge Accounting Framework", "Hedged Risk", "Hedged Exposure",
                                          "Hedged Debt Facility", "Hedged Net Investment Entity", "Hedged Seed Commitment",
                                          "Hedging Treasury Deals", "Hedging OTC Derivative Trades", "Hedge Ratio Percentage",
                                          "Designation Date", "Hedge Relationship Status"]),
            ("43", "Hedge Effectiveness Test", ["Tested Hedge Relationship", "Effectiveness Test Date", "Hedge Effectiveness Method",
                                                "Effectiveness Ratio", "Highly Effective Indicator", "Ineffectiveness Amount",
                                                "Ineffectiveness Journal"]),
            ("19", "Intercompany Balance", ["Reporting Entity", "Counterparty Entity", "Intercompany GL Account", "Intercompany Period",
                                            "Reporting Entity Balance", "Intercompany Difference", "Intercompany Match Status"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Status"]),
            ("22", "Reference Rate Fixing", ["Fixed Reference Rate", "Fixing Tenor", "Fixing Date", "Fixing Value"]),
            ("22", "FX Rate Observation", ["Observed FX Rate Type", "Base Currency", "Quote Currency", "FX Rate Date", "Spot Rate"]),
            ("25", "Counterparty Approval Scope", ["Scope Counterparty", "Approved Activity", "Scope Trading Entity", "Scope Status",
                                                   "Scope Effective From", "Scope Effective To"]),
            ("26", "Trading Agreement", ["Trading Agreement ID", "Agreement Counterparty", "Firm Contracting Entity", "Agreement Status"]),
        ],
        upstream=["DP-190", "DP-191", "DP-013", "DP-143", "DP-115", "DP-147", "DP-240", "DP-204"],
        refresh="Daily",
        timeliness="By 9am ET on T+1 after the end-of-day valuation rates are approved in DP-143; covenant tests on each test date; month-end hedge effectiveness by business day 3",
        history="Facility, loan, deal and hedge records kept for the life of the instrument plus 10 years; daily valuations and month-end snapshots kept for 10 years",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Dashboard", "BI semantic model", "Warehouse table"],
        dq_rules=[
            "Drawn Debt never exceeds Debt Facility Commitment Amount for any facility on any date.",
            "Reference Rate Fixing Value on each drawdown equals the DP-143 Fixing Value of the referenced Rate Fixing Used.",
            "Valuation Spot Rate on each Treasury Deal Valuation equals the DP-143 Spot Rate for the same currency pair and Deal Valuation Date.",
            "Every active Hedge Relationship with a Hedge Accounting Framework other than Not Designated has a Designation Date and at least one Hedge Effectiveness Test per quarter-end after it.",
            "Every Intercompany Loan's Lending Entity and Intercompany Borrowing Entity are different active internal legal entities in DP-013.",
            "Intercompany Loan to Ledger Difference is zero for every entity pair at each hard-closed period end.",
        ],
        notes=("Certified numbers: none owned. 43 decides, 19 books (CD-275): balances and journals are DP-191's; this product "
               "compares loans with intercompany balances and checks that hedge ineffectiveness is journaled. Seed-book hedges "
               "traded through the order management system stay 25 / 26 records (DP-141, DP-147), designated here by reference "
               "through Hedging OTC Derivative Trades; seed commitments come from DP-204. Valuation rates are DP-143's (rates on "
               "43 rows are derived copies). Deal counterparties are checked against DP-115's approval scope and DP-147's "
               "trading agreements; lenders are DP-240 parties. Fund-level credit facilities are 30 and out of scope. DP-196 "
               "reads intercompany loans and their pricing documentation from here; DP-205 reads intra-group capital "
               "transactions. CD-345: if 43 folds into 19, this product keeps its ID, name and scope with owning domain 19. "
               "Taxonomy gap: Treasury Deal has a Counter Currency but no deal (notional) currency, so the notional is assumed "
               "to be in the hedged exposure's currency when computing Hedge Coverage %. Taxonomy gap: Intercompany Balance has "
               "no reference to an Intercompany Loan, so loans are compared with ledger balances by entity pair, not loan by "
               "loan. Taxonomy gap: no attribute holds accrued interest or outstanding principal after partial repayment on an "
               "Intercompany Loan, so Loan Principal Amount is treated as outstanding until maturity. Open SME questions (43 Q4, "
               "Q7, Q10): whether seed hedges are traded by the investment desk or by treasury; whether hedge accounting is "
               "applied; whether intercompany loans are documented under 10 ICA- agreements or separate 39 loan agreements. "
               "Decisions: CD-274, CD-275, CD-276, CD-345."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-204": dict(
        definition=("Every seed, incubation, GP commitment and co-investment commitment of firm capital with its funding and "
                    "redemption movements, its valuation over time and the group's ownership share of each seeded product. "
                    "It supports the Group Treasurer's seed deployment and recycling decisions against exit triggers and gives "
                    "consolidation (DP-193) and launch teams one seed status: 43 Seed Capital Commitment is the only master of "
                    "seed status (CD-276). Seed Position Value is a treasury measure published only here and is never AUM; "
                    "seeded funds' net assets count in DP-241's Firm AUM (own funds slice, from DP-165 net assets) in full, and incubation books are "
                    "excluded from its institutional slice (CD-346, CD-292)."),
        business_questions=[
            "How much firm capital is approved, deployed and still undeployed in seed, incubation, GP and co-investment commitments, by product and investing entity?",
            "What is each seed position worth today, what has it gained or lost, and does its value tie to the NAV of record or the seed book?",
            "What share of each seeded product does the firm own, and which products crossed the consolidation review trigger?",
            "Which seed positions have been held longer than the track record target and are candidates for recycling?",
            "How much firm capital sits in seeded funds counted in Firm AUM, and how much sits in incubation books outside it?",
            "How much seed market exposure is unhedged?",
        ],
        grain="Seed capital commitment x valuation date (daily), with seeded product x ownership measurement date and seed capital movement as companion facts",
        dimensions=["Valuation date and fiscal period (DP-013)", "Seed commitment type and status", "Seeded product and share class (DP-004)",
                    "Investing legal entity (DP-013)", "Seed holding account (DP-093)", "Seed book portfolio (DP-140)",
                    "Seed movement type", "Exit trigger"],
        measures=[
            ("Approved Seed Capital", "Sum of Approved Commitment Amount of Seed Capital Commitments with Seed Commitment Status in (Approved, Funded, Partially Redeemed), by Seed Commitment Type, Investing Entity and Seeded Product.",
             [("43", "Seed Capital Commitment", "Approved Commitment Amount"), ("43", "Seed Capital Commitment", "Seed Commitment Status"),
              ("43", "Seed Capital Commitment", "Seed Commitment Type"), ("43", "Seed Capital Commitment", "Investing Entity"),
              ("43", "Seed Capital Commitment", "Seeded Product")]),
            ("Net Seed Capital Deployed", "Sum of Movement Amount of Seed Capital Movements with Movement Trade Date <= as-of date, positive for Seed Movement Type in (Initial Funding, Additional Funding, Capital Call Funding, In-Kind Delivery) and negative for (Partial Redemption, Full Redemption, Distribution Received); Transfer Between Entities is negative for the transferring commitment and positive for the receiving one (Transfer Counterparty Entity).",
             [("43", "Seed Capital Movement", "Movement Amount"), ("43", "Seed Capital Movement", "Seed Movement Type"),
              ("43", "Seed Capital Movement", "Movement Trade Date"), ("43", "Seed Capital Movement", "Movement Seed Commitment"),
              ("43", "Seed Capital Movement", "Transfer Counterparty Entity")]),
            ("Undeployed Commitment", "Approved Seed Capital - Net Seed Capital Deployed, floored at zero, for commitments with Seed Commitment Status in (Approved, Funded).",
             ["Approved Seed Capital", "Net Seed Capital Deployed"]),
            ("Seed Position Value", "Seed Position Value of the latest Seed Position Valuation on or before the as-of date per Valued Seed Commitment, by commitment type, product and investing entity. A treasury and consolidation measure published only by this product; never AUM and never added to Firm AUM (CD-346).",
             [("43", "Seed Position Valuation", "Seed Position Value"), ("43", "Seed Position Valuation", "Seed Valuation Date"),
              ("43", "Seed Position Valuation", "Valued Seed Commitment")]),
            ("Seed Gain (Loss)", "Seed Position Value - Net Seed Capital Deployed per commitment, cumulative since the first funding.",
             ["Seed Position Value", "Net Seed Capital Deployed"]),
            ("Seed Valuation Tie-Out", "Per commitment and valuation date, by valuation basis: fund rows: Seed Position Value - Seed Units Held x NAV per Share of the DP-165 NAV of record for the Seeded Share Class on the Seed Valuation Date, and Seed Units Held - Units Held of the 06 Fund Shareholder Position (DP-007) of the Seed Holding Account and Seeded Share Class; incubation rows: Seed Position Value - Total IBOR Market Value of the Seed Book's end-of-day Portfolio Valuation Summary (DP-142). Flagged beyond 0.01% of Seed Position Value.",
             [("43", "Seed Position Valuation", "Seed Position Value"), ("43", "Seed Position Valuation", "Seed Units Held"),
              ("43", "Seed Position Valuation", "Seed NAV per Share"), ("43", "Seed Position Valuation", "Seed Capital Balance"),
              ("43", "Seed Position Valuation", "Seed Valuation Date"), ("43", "Seed Capital Commitment", "Seeded Share Class"),
              ("43", "Seed Capital Commitment", "Seed Holding Account"),
              ("43", "Seed Capital Commitment", "Seed Book"), ("27", "Share Class NAV", "NAV per Share"),
              ("27", "Share Class NAV", "NAV Share Class"), ("27", "Share Class NAV", "Parent NAV Calculation"),
              ("27", "Fund NAV Calculation", "Valuation Date"), ("27", "Fund NAV Calculation", "NAV Approval Status"),
              ("06", "Fund Shareholder Position", "Units Held"), ("06", "Fund Shareholder Position", "Account"),
              ("06", "Fund Shareholder Position", "Share Class"), ("06", "Fund Shareholder Position", "Valuation Date"),
              ("18", "Portfolio Valuation Summary", "Total IBOR Market Value"), ("18", "Portfolio Valuation Summary", "Valued Portfolio"),
              ("18", "Portfolio Valuation Summary", "Valuation As-Of Date"), ("18", "Portfolio Valuation Summary", "Valuation View")]),
            ("Firm Ownership %", "Firm Ownership Percentage of the latest Seed Product Holding per Held Seeded Product, with Third-Party Net Assets = Product Net Assets Used x (1 - Firm Ownership Percentage) for third-party AUM exit triggers.",
             [("43", "Seed Product Holding", "Firm Ownership Percentage"), ("43", "Seed Product Holding", "Held Seeded Product"),
              ("43", "Seed Product Holding", "Ownership Measurement Date"), ("43", "Seed Product Holding", "Product Net Assets Used")]),
            ("Ownership Tie-Out", "Per seeded product and Ownership Measurement Date: Firm Ownership Percentage - (sum of Seed Position Value of the product's active commitments / Product Net Assets Used), and Product Net Assets Used - Fund Net Assets Amount of the DP-165 NAV of record on that date; each flagged beyond 0.01 percentage points or one unit of NAV rounding.",
             [("43", "Seed Product Holding", "Firm Ownership Percentage"), ("43", "Seed Product Holding", "Product Net Assets Used"),
              ("43", "Seed Product Holding", "Ownership Measurement Date"), ("27", "Fund NAV Calculation", "Fund Net Assets Amount"),
              ("27", "Fund NAV Calculation", "NAV Book"), "Seed Position Value"]),
            ("Consolidation Review Triggers", "Count of seeded products whose latest Seed Product Holding has Consolidation Review Trigger Indicator = Y; the list DP-193 reads for the consolidation assessment.",
             [("43", "Seed Product Holding", "Consolidation Review Trigger Indicator"), ("43", "Seed Product Holding", "Held Seeded Product")]),
            ("Firm Capital in Seeded Funds", "Seed Position Value of commitments with Seed Commitment Type in (Seed, GP Commitment, Co-Investment) whose Seeded Product's net assets are counted in the DP-241 Firm AUM Own Funds Slice (DP-165 fund net assets); published as the reconciling attribute for DP-241 (Cause: Seed Capital), never as an addition to AUM (CD-346).",
             [("43", "Seed Capital Commitment", "Seed Commitment Type"), ("43", "Seed Capital Commitment", "Seeded Product"),
              ("01", "Investment Product", "Product ID"), ("01", "Investment Product", "Vehicle Type"), "Seed Position Value"]),
            ("Incubation Value Outside Firm AUM", "Seed Position Value of commitments with Seed Commitment Type = Incubation Account whose Seed Book has Proprietary Capital Indicator = Y, which DP-241 excludes from the Firm AUM Institutional Slice (CD-346).",
             [("43", "Seed Capital Commitment", "Seed Commitment Type"), ("43", "Seed Capital Commitment", "Seed Book"),
              ("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Proprietary Capital Indicator"), "Seed Position Value"]),
            ("Seed Book Flag Mismatch", "Count of seed books of commitments with Seed Commitment Status in (Funded, Partially Redeemed) whose 18 Portfolio Proprietary Capital Indicator is not Y, plus portfolios with Proprietary Capital Indicator = Y that are the Seed Book of no such commitment (18 holds a derived copy of 43, CD-276).",
             [("43", "Seed Capital Commitment", "Seed Book"), ("43", "Seed Capital Commitment", "Seed Commitment Status"),
              ("18", "Portfolio", "Portfolio ID"), ("18", "Portfolio", "Proprietary Capital Indicator"), ("18", "Portfolio", "Portfolio Type")]),
            ("Seed Holding Period (Days)", "As-of date - earliest Movement Trade Date with Seed Movement Type = Initial Funding per commitment; commitments with Target Exit Trigger = Track Record Period held longer than the firm's track record standard (three years by default, a Treasury parameter) are flagged for recycling.",
             [("43", "Seed Capital Movement", "Movement Trade Date"), ("43", "Seed Capital Movement", "Seed Movement Type"),
              ("43", "Seed Capital Commitment", "Target Exit Trigger"), ("01", "Investment Product", "Product Inception Date")]),
            ("Unhedged Seed Market Exposure", "Exposure Amount of Corporate Exposures with Corporate Exposure Type in (Seed Investment Market Exposure, Seed Investment Currency Exposure) and an Exposure Seed Commitment, for the current exposure period, less Exposure Amount x Hedge Ratio Percentage of active Hedge Relationships whose Hedged Seed Commitment is the same commitment.",
             [("43", "Corporate Exposure", "Exposure Amount"), ("43", "Corporate Exposure", "Corporate Exposure Type"),
              ("43", "Corporate Exposure", "Exposure Seed Commitment"), ("43", "Corporate Exposure", "Exposure Period End"),
              ("43", "Hedge Relationship", "Hedged Seed Commitment"), ("43", "Hedge Relationship", "Hedge Ratio Percentage"),
              ("43", "Hedge Relationship", "Hedge Relationship Status")]),
        ],
        inputs=[
            ("43", "Seed Capital Commitment", ["Seed Capital Commitment ID", "Seed Commitment Type", "Seeded Product", "Seeded Share Class",
                                               "Investing Entity", "Approved Commitment Amount", "Commitment Approval Date",
                                               "Launch Change Initiative", "Seed Holding Account", "Seed Book",
                                               "Target Exit Trigger", "Seed Commitment Status"]),
            ("43", "Seed Capital Movement", ["Movement Reference", "Movement Seed Commitment", "Seed Movement Type", "Movement Amount",
                                             "Movement Trade Date", "Resulting Fund Order", "Resulting AP Order",
                                             "Transfer Counterparty Entity"]),
            ("43", "Seed Position Valuation", ["Valued Seed Commitment", "Seed Valuation Date", "Seed Units Held", "Seed NAV per Share",
                                               "Seed Capital Balance", "Source Shareholder Position", "Source NAV Record",
                                               "Seed Position Value"]),
            ("43", "Seed Product Holding", ["Held Seeded Product", "Ownership Measurement Date", "Product Net Assets Used",
                                            "Firm Ownership Percentage", "Consolidation Review Trigger Indicator"]),
            ("43", "Corporate Exposure", ["Exposure Seed Commitment", "Corporate Exposure Type", "Exposure Amount", "Exposure Period End"]),
            ("43", "Hedge Relationship", ["Hedge Relationship ID", "Hedged Seed Commitment", "Hedge Ratio Percentage",
                                          "Hedge Relationship Status"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Account", "Share Class", "Valuation Date", "Units Held"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                                       "Class Net Assets Amount"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Proprietary Capital Indicator"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Total IBOR Market Value"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type", "Product Inception Date"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
        ],
        upstream=["DP-004", "DP-007", "DP-093", "DP-013", "DP-165", "DP-140", "DP-142"],
        refresh="Daily",
        timeliness="By 10am ET on T+1 after the NAV of record is released in DP-165; month-end ownership and consolidation triggers by business day 5",
        history="Commitments and movements kept for the life of the commitment plus 10 years; daily valuations kept for 10 years; month-end ownership snapshots locked and kept for 10 years",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Dashboard", "BI semantic model", "Warehouse table", "API"],
        dq_rules=[
            "Every Seed Capital Commitment with Seed Commitment Status in (Funded, Partially Redeemed) has a Seed Position Valuation dated no more than one business day (fund rows) or one quarter (feeder fund interests valued on a general partner statement) before the as-of date.",
            "Seed Valuation Tie-Out is within 0.01% for every fund and incubation row before the month-end snapshot is locked.",
            "Every Seed Capital Commitment has exactly one valuation basis populated on its valuations: Seed Units Held with Seed NAV per Share, Seed Capital Balance, or a Seed Book.",
            "Seed Book Flag Mismatch is zero: the 18 Proprietary Capital Indicator is Y exactly for the seed books of funded commitments.",
            "Seed Position Value is never published in a Firm AUM measure or summed with DP-241 Firm AUM in any semantic model.",
        ],
        notes=("W4 re-point (CW-930, CW-166, CW-151): 43 Seed Capital Commitment.GP Investor Commitment and Seed Capital "
               "Movement.Resulting Capital Call and Resulting Private Fund Distribution dropped, no successor (the firm's own "
               "private funds leave with 30), with the 30 Investor Capital Account input, the private fund rows of Seed Valuation "
               "Tie-Out and DP-116 upstream; Resulting AP Order is read in their place for ETF seed movements. Seed Capital "
               "Balance is now mastered in 43 (no 30 master to test it against). 06 Position re-typed by name to Fund "
               "Shareholder Position (same columns). "
               "Certified numbers: none owned. Seed Position Value and Firm Ownership Percentage are treasury and consolidation "
               "measures defined only here (CD-346); Firm AUM is DP-241's (CW-206) and NAV per share and net assets stay DP-165's (CD-292, CD-330), and "
               "Firm Capital in Seeded Funds is the reconciling attribute for DP-241 Firm AUM & Client Assets Reconciliation, never an "
               "addition. Incubation books carry 18 Proprietary Capital Indicator and are excluded from DP-241's Firm AUM "
               "Institutional Slice. 43 is the only master of seed status (CD-276); DP-193 reads the ownership share and trigger for the "
               "consolidation decision and does not revalue seed; DP-203 reads commitments for seed hedges. The 43 valuation "
               "attributes Seed Units Held and Seed NAV per Share are derived copies of 06 and 27; "
               "they are read here only to test them against their masters (06 Fund Shareholder Position through DP-007, 27 NAV of record "
               "through DP-165, 18 valuation summary through DP-142), which is the "
               "copy-versus-master exception of CONTRACT.md rule 2; Seed Capital Balance is mastered in 43 (CW-166). PII = N: the validator warns that 06 Fund Shareholder Position and 15 Account attributes are flagged personal data; the only rows read are the seed holding accounts of group legal entities, so no personal data is published. "
               "Brief hardest call 4: if a Wave E1 product needs seed status (for example the Portfolio Master's proprietary "
               "capital indicator), this product's commitment register should be promoted to a foundational seed register; "
               "today DP-140 carries the 18 derived copy. CD-345: if 43 folds into 19, this product keeps its ID, name and "
               "scope with owning domain 19. Taxonomy gap: Target Exit Trigger is a type with no threshold value or target "
               "date, so holding period and third-party AUM triggers use Treasury parameters. Taxonomy gap: Seed Capital "
               "Movement has no settlement amount in product currency versus investing-entity currency, so Seed Gain (Loss) "
               "is in the commitment's currency and FX effects are not separated. Open SME questions (43 Q3, Q9; 19 Q6): who "
               "approves seed commitments and which exit triggers are standard; whether corporate cash is invested in own "
               "money market funds; who runs the consolidation assessment. Decisions: CD-276, CD-292, CD-330, CD-345, CD-346."
               "WP1 re-point (CW-206): Firm AUM and its slices moved from DP-165 to DP-241 (the DP-165 'Firm AUM' and 'Mandate & SMA Market Value' measures are dropped; the institutional slice is DP-241's Firm AUM Institutional Slice); the Firm AUM texts of the definition, measures, rule and notes are re-pointed. DP-241 lists this product upstream (Cause: Seed Capital), so DP-241 is not upstream here; no input or measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-205": dict(
        definition=("Capital requirements, resources and surplus by regulated entity and regime (SEC Rule 15c3-1 net capital of "
                    "the broker-dealer; OCC or state capital of the optional trust company) with their components (permanent "
                    "minimum, aggregate indebtedness or alternative standard requirement, haircuts and deductions), the Rule "
                    "17a-11 early-warning level and notification events, and the status of each regulatory financial return. 43 calculates and 19 files (CD-277): the "
                    "capital amounts of the approved calculation are this product's numbers of record, and the 19 return's "
                    "amounts are derived copies compared with them, not re-published. It evidences capital adequacy to the "
                    "board and regulators."),
        business_questions=[
            "What is each regulated entity's capital requirement, resources, surplus and coverage ratio under each regime, and how close is it to the early warning threshold?",
            "Which component sets the requirement (the permanent minimum or the aggregate indebtedness or alternative standard requirement), and how far is aggregate indebtedness from the 1200% early-warning ratio?",
            "Did every threshold breach and every capital withdrawal that needs prior notice produce a regulator notification in time?",
            "Do the capital amounts in each filed return equal the approved calculation, and which returns are due or overdue?",
        ],
        grain="Regulated entity x capital regime x calculation as-of date x calculation version, with capital requirement component, capital adequacy notification and regulatory financial return as companion facts",
        dimensions=["Calculation as-of date and fiscal period (DP-013)", "Regulated legal entity (DP-013)", "Capital regime",
                    "Regulator", "Net capital method", "Capital component type", "Regulatory return type and status",
                    "Notification trigger"],
        measures=[
            ("Capital Requirement", "Treasury Capital Requirement Amount of the latest Capital Requirement Calculation with Calculation Approval Status = Approved per Calculation Entity, Calculation Capital Regime and Calculation As-Of Date; the regulatory capital number of record (CD-277).",
             [("43", "Capital Requirement Calculation", "Treasury Capital Requirement Amount"), ("43", "Capital Requirement Calculation", "Calculation Approval Status"),
              ("43", "Capital Requirement Calculation", "Calculation Entity"), ("43", "Capital Requirement Calculation", "Calculation Capital Regime"),
              ("43", "Capital Requirement Calculation", "Calculation As-Of Date"), ("43", "Capital Requirement Calculation", "Capital Calculation ID")]),
            ("Capital Resources", "Treasury Capital Resources Amount of the same approved calculation.",
             [("43", "Capital Requirement Calculation", "Treasury Capital Resources Amount")]),
            ("Capital Surplus and Coverage", "Capital Surplus Amount and Capital Coverage Ratio of the approved calculation, checked against Capital Resources - Capital Requirement and Capital Resources / Capital Requirement.",
             [("43", "Capital Requirement Calculation", "Capital Surplus Amount"), ("43", "Capital Requirement Calculation", "Capital Coverage Ratio"),
              "Capital Resources", "Capital Requirement"]),
            ("Headroom to Early Warning", "Capital Resources - Net Capital Early Warning Level Amount of the same approved calculation (Rule 17a-11(b)); negative is a breach.",
             [("43", "Capital Requirement Calculation", "Net Capital Early Warning Level Amount"), "Capital Resources"]),
            ("Aggregate Indebtedness Early Warning", "Count of approved basic method calculations (Regulated Entity Capital Profile Net Capital Method = Basic (Aggregate Indebtedness)) whose Aggregate Indebtedness Ratio exceeds 1200% (Rule 17a-11(b)) or 1500% (Rule 15c3-1(a)(1)(i)), checked against Aggregate Indebtedness Amount / Capital Resources.",
             [("43", "Capital Requirement Calculation", "Aggregate Indebtedness Ratio"), ("43", "Capital Requirement Calculation", "Aggregate Indebtedness Amount"),
              ("43", "Regulated Entity Capital Profile", "Net Capital Method"), ("43", "Regulated Entity Capital Profile", "Capital Regulated Entity"),
              ("43", "Regulated Entity Capital Profile", "Capital Profile Effective From"), ("43", "Regulated Entity Capital Profile", "Capital Profile Effective To"),
              "Capital Resources"]),
            ("Requirement by Component", "Sum of Component Amount by Capital Component Type for the approved calculation; Binding Requirement = the higher of Permanent Minimum Requirement and Aggregate Indebtedness Requirement (basic method) or Alternative Standard Requirement (alternative method), checked to equal Minimum Net Capital Requirement and Capital Requirement.",
             [("43", "Capital Requirement Component", "Component Amount"), ("43", "Capital Requirement Component", "Capital Component Type"),
              ("43", "Capital Requirement Component", "Component Calculation"),
              ("43", "Capital Requirement Component", "Component Sequence"), "Capital Requirement"]),
            ("Own Funds to Equity Bridge", "Book equity of the entity at the Calculation As-Of Date (sum of Current Period Value of the approved, non-consolidated Balance Sheet lines of the entity in DP-193 whose lines map to GL accounts with Financial Statement Class = Equity, or between year-ends -1 x Closing Balance of those accounts in DP-191) - Capital Resources; the bridge should equal the sum of Component Amount of deduction and haircut component types (Net Capital Haircut, Non-Allowable Asset Deduction, Regulatory Capital Deduction); Capital Resources above book equity is flagged.",
             [("19", "Financial Statement", "Statement Reporting Entity"), ("19", "Financial Statement", "Consolidated Statement Indicator"),
              ("19", "Financial Statement", "Financial Statement Type"), ("19", "Financial Statement", "Statement Period End Date"),
              ("19", "Financial Statement", "Statement Approval Status"), ("19", "Financial Statement Line Value", "Current Period Value"),
              ("19", "Financial Statement Line Value", "Value Statement Line"), ("19", "Financial Statement Line Value", "Line Financial Statement"),
              ("19", "Financial Statement Line Mapping", "Mapped GL Account"), ("19", "Financial Statement Line Mapping", "Mapped Statement Line"),
              ("19", "GL Account", "Financial Statement Class"), ("19", "GL Account Balance", "Closing Balance"),
              ("43", "Capital Requirement Component", "Component Amount"), ("43", "Capital Requirement Component", "Capital Component Type"),
              "Capital Resources"]),
            ("Return Copy Difference", "For each Regulatory Financial Return carrying capital amounts: Capital Requirement Amount - Capital Requirement and Capital Resources Amount - Capital Resources of the approved calculation for the Return Filing Entity at the Return Reporting Period End; expected 0 (CD-277).",
             [("19", "Regulatory Financial Return", "Capital Requirement Amount"), ("19", "Regulatory Financial Return", "Capital Resources Amount"),
              ("19", "Regulatory Financial Return", "Return Filing Entity"), ("19", "Regulatory Financial Return", "Return Reporting Period End"),
              ("19", "Regulatory Financial Return", "Regulatory Return Type"), "Capital Requirement", "Capital Resources"]),
            ("Returns Due or Overdue", "Count of Regulatory Financial Returns with Return Due Date within 10 business days, or passed, and Regulatory Return Status not in (Filed, Accepted, Amended), by Return Filing Entity, Return Regulator and Regulatory Return Type.",
             [("19", "Regulatory Financial Return", "Return Due Date"), ("19", "Regulatory Financial Return", "Regulatory Return Status"),
              ("19", "Regulatory Financial Return", "Return Regulator"), ("19", "Regulatory Financial Return", "Return Frequency")]),
            ("Unnotified Threshold Breaches", "Count of approved calculations with Capital Resources below the Net Capital Early Warning Level Amount or below Capital Requirement for which no Capital Adequacy Notification has Triggering Calculation = the calculation; Notification Lag (hours) = Notification Sent Timestamp - Trigger Event Date for those notified.",
             [("43", "Capital Adequacy Notification", "Triggering Calculation"), ("43", "Capital Adequacy Notification", "Notification Sent Timestamp"),
              ("43", "Capital Adequacy Notification", "Trigger Event Date"), ("43", "Capital Adequacy Notification", "Capital Notification Trigger"),
              ("43", "Capital Adequacy Notification", "Notifying Entity"), "Headroom to Early Warning", "Capital Resources", "Capital Requirement"]),
            ("Capital Withdrawals Without Prior Notice", "Count and Capital Transaction Amount of Intra-Group Capital Transactions with Regulatory Prior Notice Required Indicator = Y paid by a regulated entity, with no Capital Adequacy Notification whose Related Capital Transaction is the transaction and whose Notification Sent Timestamp is before the Capital Transaction Effective Date.",
             [("43", "Intra-Group Capital Transaction", "Capital Transaction Reference"), ("43", "Intra-Group Capital Transaction", "Regulatory Prior Notice Required Indicator"),
              ("43", "Intra-Group Capital Transaction", "Paying Entity"), ("43", "Intra-Group Capital Transaction", "Capital Transaction Amount"),
              ("43", "Intra-Group Capital Transaction", "Capital Transaction Effective Date"), ("43", "Capital Adequacy Notification", "Related Capital Transaction"),
              ("43", "Capital Adequacy Notification", "Notification Sent Timestamp")]),
            ("Regulated Entities Without Capital Profile", "Count of Entity Authorizations (38, through DP-013) with Authorization Status active whose Authorization Type carries a capital regime, with no Regulated Entity Capital Profile effective on the as-of date whose Governing Authorization is that authorization.",
             [("38", "Entity Authorization", "Authorization ID"), ("38", "Entity Authorization", "Authorized Entity"),
              ("38", "Entity Authorization", "Authorization Type"), ("38", "Entity Authorization", "Authorization Status"),
              ("43", "Regulated Entity Capital Profile", "Governing Authorization"), ("43", "Regulated Entity Capital Profile", "Capital Profile Effective From"),
              ("43", "Regulated Entity Capital Profile", "Capital Profile Effective To")]),
        ],
        inputs=[
            ("43", "Regulated Entity Capital Profile", ["Capital Regulated Entity", "Capital Regime", "Governing Authorization",
                                                        "Net Capital Method", "Permanent Minimum Capital Amount", "Capital Profile Effective From",
                                                        "Capital Profile Effective To"]),
            ("43", "Capital Requirement Calculation", ["Capital Calculation ID", "Calculation Entity", "Calculation Capital Regime",
                                                       "Calculation As-Of Date", "Treasury Capital Requirement Amount",
                                                       "Treasury Capital Resources Amount", "Capital Surplus Amount", "Capital Coverage Ratio",
                                                       "Aggregate Indebtedness Amount", "Aggregate Indebtedness Ratio",
                                                       "Net Capital Early Warning Level Amount",
                                                       "Calculation Approval Status"]),
            ("43", "Capital Requirement Component", ["Component Calculation", "Component Sequence", "Capital Component Type",
                                                     "Component Input Measure", "Component Coefficient", "Component Amount"]),
            ("43", "Capital Adequacy Notification", ["Notifying Entity", "Capital Notification Trigger", "Notified Regulator",
                                                     "Trigger Event Date", "Notification Sent Timestamp", "Triggering Calculation",
                                                     "Related Capital Transaction"]),
            ("43", "Intra-Group Capital Transaction", ["Capital Transaction Reference", "Intra-Group Capital Transaction Type", "Paying Entity",
                                                       "Capital Transaction Amount", "Capital Transaction Effective Date",
                                                       "Regulatory Prior Notice Required Indicator"]),
            ("19", "Regulatory Financial Return", ["Return Filing Entity", "Return Regulator", "Regulatory Return Type",
                                                   "Return Reporting Period End", "Return Frequency", "Return Due Date",
                                                   "Regulatory Return Status", "Capital Requirement Amount", "Capital Resources Amount"]),
            ("19", "Financial Statement", ["Financial Statement ID", "Statement Reporting Entity", "Consolidated Statement Indicator",
                                           "Financial Statement Type", "Statement Period End Date", "Statement Approval Status"]),
            ("19", "Financial Statement Line Value", ["Line Financial Statement", "Value Statement Line", "Current Period Value"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Mapped Statement Line"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance",
                                          "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class"]),
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Regulator", "Authorization Type", "Authorization Status",
                                            "Permitted Activities"]),
        ],
        upstream=["DP-191", "DP-193", "DP-190", "DP-013", "DP-203"],
        refresh="Daily",
        timeliness="Daily calculations (SEC net capital) by 10am ET on T+1; month-end and quarter-end calculations approved by business day 10; notifications as events within one hour of being sent",
        history="Every calculation version, component and notification kept for 10 years; approved period-end calculations locked as the record behind each filed return",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Dashboard", "BI semantic model", "Warehouse table", "Regulatory report"],
        dq_rules=[
            "Capital Surplus Amount equals Treasury Capital Resources Amount - Treasury Capital Requirement Amount on every calculation.",
            "Every regulated entity with an effective Regulated Entity Capital Profile has an approved Capital Requirement Calculation for each required as-of date of its regime (daily for SEC net capital, at least quarterly for trust company capital).",
            "Return Copy Difference is zero for every return with Regulatory Return Status in (Filed, Accepted).",
            "Every Capital Requirement Component belongs to exactly one Capital Requirement Calculation and Component Sequence is unique within it.",
            "Every Capital Adequacy Notification has a Trigger Event Date on or before its Notification Sent Timestamp.",
        ],
        notes=("W1b re-point (CW-943): Regulated Entity Capital Profile.Early Warning Threshold Amount is replaced by Capital Requirement Calculation.Net Capital Early Warning Level Amount (Rule 17a-11(b), computed per calculation) in Headroom to Early Warning and Unnotified Threshold Breaches; the new Aggregate Indebtedness Amount and Ratio feed the added measure Aggregate Indebtedness Early Warning. W1b: ICARA Assessment, Regulated Entity Capital Profile.MIFIDPRU Firm Category, Capital Requirement Calculation.Liquid Assets Requirement Amount and Liquid Assets Held Amount, and Capital Requirement Component.K-Factor dropped, no successor (CW-943); the measures Own Funds Threshold Coverage %, Liquid Assets Coverage % and ICARA Review Overdue are removed; Requirement by Component no longer groups by K-factor; Fixed Overheads Check is removed because its filter value Fixed Overheads Requirement left the Capital Component Type list, with the 19 Ledger and 09 Fiscal Period inputs only it read; Own Funds to Equity Bridge filters on the US deduction types (Own Funds Deduction removed, Regulatory Capital Deduction added). Measure names are kept for SM-14. "
               "Certified numbers: none of the CD-293 families. The approved calculation's capital requirement, resources and "
               "surplus are this product's numbers of record (CD-277); the 19 Regulatory Financial Return amounts are derived "
               "copies compared through Return Copy Difference, and the return, its status and due date stay 19's. Book equity "
               "comes from DP-193 statements or DP-191 balances. Entity authorizations come from 38 through DP-013 (CD-250); intra-group capital "
               "transactions are read through DP-203; 42 publishes the net capital note of the broker-dealer statement of "
               "financial condition (SEC Rule 17a-5(c)) by reference. If the "
               "parent is listed, capital figures that would disclose unreleased results are handled as Restricted - MNPI "
               "until the earnings release. CD-345: if 43 folds into 19, this product keeps its ID, name and scope with owning "
               "domain 19 and the owner role moves to the Finance treasury lead; the Treasury capital amount names were chosen "
               "so that no duplicate name arises in 19. Taxonomy gap: Capital Requirement Calculation has no version number "
               "attribute (the version is inside the RCAP- key), so the latest approved calculation is chosen by key order. "
               "Taxonomy gap: Regulatory Financial Return has no "
               "capital regime attribute; it is matched to the calculation by Return Filing Entity and Regulatory Return Type. "
               "Taxonomy gap: no attribute marks which 38 Authorization Types carry a capital regime; Regulated Entities "
               "Without Capital Profile uses a Regulatory Capital mapping maintained by the Head of Regulatory Capital. Open "
               "SME questions (43 Q5, Q6; 19 Q3, Q10): which entities are regulated for capital; whether the CIT trustee is a firm entity with OCC capital requirements; which returns "
               "each entity files. Thresholds such as the 10-business-day due window are drafting assumptions. Decisions: "
               "CD-250, CD-277, CD-340, CD-345."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-206": dict(
        definition=("The corporate insurance program by coverage line, layer and carrier, with limits, attachment points, "
                    "retentions and premium, and every claim with its reserve and recoveries linked to the operational loss "
                    "event, legal matter or IT incident behind it. It supports the Group Treasurer's renewal and program design "
                    "decisions and gives operational risk the recoveries it nets against losses: 37 loss recoveries are derived "
                    "copies of Amount Recovered (CD-278). The fund fidelity bond is 35's and is referenced, not copied. It owns "
                    "no certified number."),
        business_questions=[
            "What limits, retentions and premium does the program carry by coverage line, and which policies renew in the next 90 days?",
            "Is each policy's tower complete, with every layer fully placed and the top of the tower equal to the program limit?",
            "How concentrated is our coverage by carrier?",
            "Which claims are open, what is reserved and recovered, and what is our recovery rate by coverage line?",
            "Do the recoveries operational risk nets against losses equal the amounts recovered on claims, and which large losses have no claim?",
        ],
        grain="Corporate insurance policy x policy period x layer number x carrier (program); insurance claim x as-of date (claims); daily snapshots",
        dimensions=["As-of date and policy period (DP-013 calendar)", "Insurance coverage line", "Coverage layer and layer type",
                    "Carrier, lead insurer and broker (DP-240)", "Named insured legal entity (DP-013)", "Claim status",
                    "Related operational loss event, legal matter or IT incident", "Governing contract (DP-213)"],
        measures=[
            ("Program Limit", "Sum of Program Aggregate Limit of Corporate Insurance Policies in force on the as-of date (Policy Period Start <= date <= Policy Period End), by Insurance Coverage Line, with Retention Amount shown beside it.",
             [("43", "Corporate Insurance Policy", "Program Aggregate Limit"), ("43", "Corporate Insurance Policy", "Policy Period Start"),
              ("43", "Corporate Insurance Policy", "Policy Period End"), ("43", "Corporate Insurance Policy", "Insurance Coverage Line"),
              ("43", "Corporate Insurance Policy", "Retention Amount")]),
            ("Annual Premium and Rate on Line", "Sum of Annual Premium Amount of in-force policies by coverage line, Lead Insurer and Insurance Broker; Rate on Line % = Annual Premium Amount / Program Aggregate Limit.",
             [("43", "Corporate Insurance Policy", "Annual Premium Amount"), ("43", "Corporate Insurance Policy", "Lead Insurer"),
              ("43", "Corporate Insurance Policy", "Insurance Broker"), "Program Limit"]),
            ("Tower Integrity Difference", "Per policy: Program Aggregate Limit - max over its layers of (Attachment Point Amount + Layer Limit Amount); and the count of layers whose Attachment Point Amount differs from the previous Layer Number's Attachment Point Amount + Layer Limit Amount (gaps or overlaps in the tower).",
             [("43", "Insurance Coverage Layer", "Layer Policy"), ("43", "Insurance Coverage Layer", "Layer Number"),
              ("43", "Insurance Coverage Layer", "Attachment Point Amount"), ("43", "Insurance Coverage Layer", "Layer Limit Amount"),
              ("43", "Corporate Insurance Policy", "Program Aggregate Limit")]),
            ("Layer Placement Gap %", "Per policy and Layer Number: 100% - sum of Carrier Participation Percentage across the layer's carriers; non-zero is an unplaced or over-placed layer.",
             [("43", "Insurance Coverage Layer", "Carrier Participation Percentage"), ("43", "Insurance Coverage Layer", "Layer Number"),
              ("43", "Insurance Coverage Layer", "Layer Policy")]),
            ("Carrier Concentration %", "Per Layer Carrier: sum of Layer Limit Amount x Carrier Participation Percentage over in-force policies / the same sum over all carriers.",
             [("43", "Insurance Coverage Layer", "Layer Carrier"), ("43", "Insurance Coverage Layer", "Layer Limit Amount"),
              ("43", "Insurance Coverage Layer", "Carrier Participation Percentage"), ("02", "Organization", "Legal Name")]),
            ("Policies Renewing in 90 Days", "Count, Program Aggregate Limit and Annual Premium Amount of in-force policies with Policy Period End within 90 days of the as-of date, by coverage line.",
             [("43", "Corporate Insurance Policy", "Policy Period End"), ("43", "Corporate Insurance Policy", "Insurance Policy ID"), "Program Limit"]),
            ("Policies Without Active Contract", "Count of in-force policies with no 39 Contract (DP-213) whose Typed Contract Link has Linked Insurance Policy = the policy and Contract Status active.",
             [("39", "Typed Contract Link", "Linked Insurance Policy"), ("39", "Typed Contract Link", "Typed Record Type"),
              ("39", "Contract", "Contract ID"), ("39", "Contract", "Contract Status"), ("43", "Corporate Insurance Policy", "Insurance Policy ID")]),
            ("Open Claims", "Count, Claimed Amount and Claim Reserve Amount of Insurance Claims with Insurance Claim Status not in (Paid, Denied, Closed), by coverage line of the Claimed Policy and claim status.",
             [("43", "Insurance Claim", "Insurance Claim Reference"), ("43", "Insurance Claim", "Insurance Claim Status"),
              ("43", "Insurance Claim", "Claimed Amount"), ("43", "Insurance Claim", "Claim Reserve Amount"),
              ("43", "Insurance Claim", "Claimed Policy")]),
            ("Recovery Rate %", "Sum of Amount Recovered / sum of Claimed Amount of claims with Insurance Claim Status in (Paid, Denied, Closed) and Claim Notice Date in the trailing three years, by coverage line.",
             [("43", "Insurance Claim", "Amount Recovered"), ("43", "Insurance Claim", "Claimed Amount"),
              ("43", "Insurance Claim", "Insurance Claim Status"), ("43", "Insurance Claim", "Claim Notice Date")]),
            ("Recovery Tie-Out to Loss Data", "Per operational loss event: sum of Amount Recovered of claims whose Related Operational Loss Event is the event - sum of Loss Amount of its Loss Event Amount rows with Loss Amount Component = Third-Party Recovery (the 37 derived copies, CD-278); expected 0 unless a non-insurance recovery is documented.",
             [("43", "Insurance Claim", "Related Operational Loss Event"), ("43", "Insurance Claim", "Amount Recovered"),
              ("37", "Loss Event Amount", "Amount Loss Event"), ("37", "Loss Event Amount", "Loss Amount Component"),
              ("37", "Loss Event Amount", "Loss Amount"), ("37", "Operational Loss Event", "Loss Event ID")]),
            ("Losses Above Retention Without Claim", "Count and Impact Amount of Operational Loss Events with Impact Amount above the Retention Amount of a policy in force on the event's earliest Loss Booking Date whose Named Insured Entities include the Loss Legal Entity, with no Insurance Claim referencing the event; candidates for notice to insurers.",
             [("37", "Operational Loss Event", "Impact Amount"), ("37", "Operational Loss Event", "Loss Legal Entity"),
              ("37", "Operational Loss Event", "Loss Status"), ("37", "Loss Event Amount", "Loss Booking Date"),
              ("43", "Corporate Insurance Policy", "Retention Amount"), ("43", "Corporate Insurance Policy", "Named Insured Entities"),
              ("43", "Corporate Insurance Policy", "Policy Period Start"), ("43", "Corporate Insurance Policy", "Policy Period End"),
              ("43", "Insurance Claim", "Related Operational Loss Event")]),
            ("Claim Notice Lag (Days)", "Claim Notice Date - earliest Loss Booking Date of the related operational loss event, per claim; median by coverage line.",
             [("43", "Insurance Claim", "Claim Notice Date"), ("43", "Insurance Claim", "Related Operational Loss Event"),
              ("37", "Loss Event Amount", "Loss Booking Date")]),
        ],
        inputs=[
            ("43", "Corporate Insurance Policy", ["Insurance Policy ID", "Insurance Coverage Line", "Lead Insurer", "Insurance Broker",
                                                  "Named Insured Entities", "Policy Period Start", "Policy Period End",
                                                  "Program Aggregate Limit", "Retention Amount", "Annual Premium Amount",
                                                  "Joint Fund Fidelity Bond"]),
            ("43", "Insurance Coverage Layer", ["Layer Policy", "Layer Number", "Coverage Layer Type", "Layer Carrier",
                                                "Carrier Participation Percentage", "Attachment Point Amount", "Layer Limit Amount"]),
            ("43", "Insurance Claim", ["Insurance Claim Reference", "Claimed Policy", "Claim Notice Date", "Related Operational Loss Event",
                                       "Related Legal Matter", "Related IT Incident", "Claimed Amount", "Claim Reserve Amount",
                                       "Amount Recovered", "Insurance Claim Status"]),
            ("37", "Operational Loss Event", ["Loss Event ID", "Loss Legal Entity", "Loss Business Line", "Loss Status", "Impact Amount"]),
            ("37", "Loss Event Amount", ["Amount Loss Event", "Loss Amount Sequence", "Loss Amount Component", "Loss Amount",
                                         "Loss Booking Date"]),
            ("39", "Legal Matter", ["Legal Matter ID", "Legal Matter Type", "Matter Status", "Privilege Indicator"]),
            ("39", "Contract", ["Contract ID", "Contract Status", "Contract Expiry Date"]),
            ("39", "Typed Contract Link", ["Typed Record Type", "Linked Insurance Policy"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
            ("02", "Organization", ["Legal Name"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
        ],
        upstream=["DP-013", "DP-240", "DP-213"],
        refresh="Daily",
        timeliness="By 8am ET on T+1; renewal and tower views refreshed on each policy change; quarter-end claim reserves by business day 10",
        history="Policies, layers and claims kept for the policy period plus 10 years (claims-made tails); daily claim snapshots kept for 3 years and quarter-end snapshots for 10 years",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Dashboard", "BI semantic model", "Warehouse table"],
        dq_rules=[
            "For every policy, the top of the tower (max Attachment Point Amount + Layer Limit Amount) equals Program Aggregate Limit and Layer Number 1 has Coverage Layer Type = Primary.",
            "Carrier Participation Percentage sums to 100% for every policy x layer.",
            "Every Insurance Claim references exactly one Claimed Policy whose policy period contains the Claim Notice Date or the related loss event's earliest Loss Booking Date.",
            "Every Lead Insurer, Insurance Broker and Layer Carrier resolves to an active organization party in DP-240.",
            "Recovery Tie-Out to Loss Data is zero for every loss event whose claims are Paid or Closed.",
        ],
        notes=("Certified numbers: none owned. Amount Recovered is mastered here; 37 Loss Event Amount recovery rows are derived "
               "copies (CD-278) and are read only to test them. Premium and claim payments are booked in 19 and are not "
               "re-published here; Annual Premium Amount is the placed premium, not the expense (CD-353). The fund fidelity "
               "bond is 35's (Rule 17g-1): a joint program references it through Joint Fund Fidelity Bond and copies none of "
               "it. Boundary with the Corporate B brief: DP-215 Operational Incidents, Losses & Regulatory Notifications reads "
               "claims and recoveries from here, so this product reads 37 loss events directly rather than listing DP-215 "
               "upstream, which would create a cycle; legal matters (39) and IT incidents (41) are carried as keys, and claims "
               "linked to a matter with Privilege Indicator = Y are visible only to legal and treasury. Insurers, brokers and "
               "carriers are 02 parties from DP-240; policies are 39 contracts typed in 43 (DP-213). CD-345: if 43 folds into "
               "19, this product keeps its ID, name and scope with owning domain 19. Taxonomy gap: 37 Loss Amount Component has "
               "no insurance-specific recovery value (CD-278 names 'recovery from insurance'), so the tie-out uses Third-Party "
               "Recovery rows and a non-insurance recovery shows as a difference. Taxonomy gap: Operational Loss Event has no "
               "occurrence or discovery date, so policy-period matching and notice lag use the earliest Loss Booking Date. "
               "Taxonomy gap: no attribute maps an operational loss event to the coverage line that would respond, so Losses "
               "Above Retention Without Claim tests every in-force policy naming the entity. Taxonomy gap: Corporate Insurance "
               "Policy has no renewal status or quoted renewal premium, so renewal tracking is by Policy Period End only. Open "
               "SME question (43 Q8): whether Treasury or Risk / Legal owns the insurance program and who records claims. "
               "Decisions: CD-278, CD-345, CD-353."),
    ),
}
