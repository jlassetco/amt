"""Data product specifications: Wave E4 consumer-aligned people, workplace and AI governance products.
20 Human Capital: DP-197 to DP-201; 44 Workplace & Corporate Services: DP-207 to DP-209; 21 Data Governance & Analytics:
DP-104. Candidates in consolidation/proposals_dp_corporate_a.py (brief Corporate_Finance_and_People.md) and
consolidation/proposals_dp_fdn_product.py (brief Foundations_and_Product_Range.md). See CONTRACT.md."""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-197": dict(
        definition=("Hires, internal moves, leaves of absence and terminations measured against budgeted workforce positions "
                    "and open job requisitions, with turnover, internal mobility, time to fill, vacancy and pre-employment "
                    "screening outcomes by org unit, legal entity, job level, location and employment type. It combines the "
                    "lifecycle events, positions and assignments that DP-192 publishes with the recruiting and screening records "
                    "of 20 Human Capital, so that HR and finance plan headcount from one set of movement rates, and compliance "
                    "can see that regulated roles were screened before the start date and that regulated leavers were flagged for "
                    "notification. Headcount and FTE are taken from DP-192 (CD-341); the rates here are derived measures, not "
                    "certified numbers."),
        business_questions=[
            "What are voluntary and total turnover rates by org unit, job level and legal entity this period and over the last 12 months, and where are first-year leavers concentrated?",
            "How long does it take to fill a requisition by job family and source, and which vacant positions, especially key-person positions, have no open requisition?",
            "How much of our hiring is internal mobility, and which candidate sources produce hires?",
            "Was every hire into a regulated role screened (criminal record, regulatory references, fingerprinting) before the start date, and which adverse results are still under adjudication?",
            "Which leavers from regulated roles are not flagged for regulatory notification, and which employees on leave are past their expected return date?",
            "Which unsuccessful candidates' data is past its retention end date and still held?",
        ],
        grain="Org unit x legal entity x job level x work location x employment type x fiscal period (movement and rate aggregate), with lifecycle event, leave of absence, job requisition, candidate application x requisition and background screening as event-level child tables",
        dimensions=["Fiscal period (month, quarter, year, rolling 12 months)", "Org unit", "Employing legal entity", "Work location",
                    "Cost center (DP-190)", "Job profile, family and level", "Regulated role category", "Employment type",
                    "Lifecycle event type and termination reason", "Voluntary / involuntary", "Requisition status and reason",
                    "Candidate source", "Screening type and result (restricted view)", "Leave type (restricted view)"],
        measures=[
            ("Average Headcount", "(Certified Headcount at the opening period end + Certified Headcount at the closing period end) / 2, both from DP-192 for the same breakdown; for a rolling 12-month rate, the mean of the 13 month-end values. Not recomputed here.",
             [("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Employment Type"),
              ("20", "Contingent Worker Detail", "Contingent Worker Type"), ("09", "Fiscal Period", "Period End Date")]),
            ("Hires", "Count of Employee Lifecycle Events with Lifecycle Event Type in (Hire, Rehire, Conversion) and Event Effective Date in the period, for workers with no Contingent Worker Type; the joiner count of DP-192's Joiners, Movers and Leavers.",
             [("20", "Employee Lifecycle Event", "Lifecycle Event ID"), ("20", "Employee Lifecycle Event", "Lifecycle Event Type"),
              ("20", "Employee Lifecycle Event", "Event Effective Date"), ("20", "Contingent Worker Detail", "Contingent Worker Type")]),
            ("Leavers", "Count of Employee Lifecycle Events with Lifecycle Event Type = Termination and Event Effective Date in the period, for workers with no Contingent Worker Type, split by Voluntary Termination Indicator and Termination Reason; Death and Transfer to Affiliate are reported but excluded from turnover.",
             [("20", "Employee Lifecycle Event", "Lifecycle Event Type"), ("20", "Employee Lifecycle Event", "Event Effective Date"),
              ("20", "Employee Lifecycle Event", "Voluntary Termination Indicator"), ("20", "Employee Lifecycle Event", "Termination Reason"),
              ("20", "Contingent Worker Detail", "Contingent Worker Type")]),
            ("Turnover Rate %", "Leavers (excluding Death and Transfer to Affiliate) / Average Headcount for the same breakdown and period, annualized for periods shorter than a year (x 12 / months in period).",
             ["Leavers", "Average Headcount"]),
            ("Voluntary Turnover Rate %", "Leavers with Voluntary Termination Indicator = Y / Average Headcount, annualized as Turnover Rate %.",
             [("20", "Employee Lifecycle Event", "Voluntary Termination Indicator"), "Leavers", "Average Headcount"]),
            ("First-Year Turnover %", "Leavers in the trailing 12 months whose Termination Date is less than 365 days after their Hire Date / Hires in the 12 months before that window's end.",
             [("20", "Employee", "Hire Date"), ("20", "Employee", "Termination Date"), "Leavers", "Hires"]),
            ("Internal Mobility Rate %", "Count of Employee Lifecycle Events with Lifecycle Event Type in (Transfer, Promotion, Job Change) and Event Effective Date in the period / Average Headcount, annualized.",
             [("20", "Employee Lifecycle Event", "Lifecycle Event Type"), ("20", "Employee Lifecycle Event", "Event Effective Date"),
              "Average Headcount"]),
            ("Time to Fill (Days)", "Median of Requisition Filled Date - Requisition Opened Date for Job Requisitions with Requisition Status = Filled and Requisition Filled Date in the period, by Requisition Reason and the job family of the Requisition Position.",
             [("20", "Job Requisition", "Requisition Filled Date"), ("20", "Job Requisition", "Requisition Opened Date"),
              ("20", "Job Requisition", "Requisition Status"), ("20", "Job Requisition", "Requisition Reason"),
              ("20", "Job Requisition", "Requisition Position"), ("20", "Workforce Position", "Position Job Profile"),
              ("20", "Job Profile", "Job Profile Family")]),
            ("Open Requisitions and Age", "Count of Job Requisitions with Requisition Status in (Open, On Hold) at the as-of date, with days open = as-of date - Requisition Opened Date, banded 0-30, 31-60, 61-90 and over 90 days.",
             [("20", "Job Requisition", "Job Requisition ID"), ("20", "Job Requisition", "Requisition Status"),
              ("20", "Job Requisition", "Requisition Opened Date")]),
            ("Internal Fill Rate %", "Requisitions filled in the period whose hired Candidate Application (Hired As Employee populated) has Internal Candidate Employee populated / requisitions filled in the period.",
             [("20", "Candidate Application", "Applied Requisition"), ("20", "Candidate Application", "Hired As Employee"),
              ("20", "Candidate Application", "Internal Candidate Employee"), ("20", "Job Requisition", "Requisition Status")]),
            ("Source of Hire Mix %", "Candidate Applications with Hired As Employee populated in the period, by Candidate Source / all hired applications in the period; applications per hire = Candidate Applications on filled requisitions / hired applications.",
             [("20", "Candidate Application", "Candidate Application ID"), ("20", "Candidate Application", "Candidate Source"),
              ("20", "Candidate Application", "Hired As Employee"), ("20", "Candidate Application", "Application Stage")]),
            ("Vacancy Rate %", "Vacant Positions as published by DP-192 (positions effective on the as-of date with Position Status = Open or no primary assignment) / Workforce Positions effective on the as-of date with Position Status not Closed, split by Key-Person Risk Indicator.",
             [("20", "Workforce Position", "Workforce Position ID"), ("20", "Workforce Position", "Position Status"),
              ("20", "Workforce Position", "Key-Person Risk Indicator"), ("20", "Workforce Position", "Position Effective From"),
              ("20", "Workforce Position", "Position Effective To"), ("20", "Employee Job Assignment", "Assigned Workforce Position"),
              ("20", "Employee Job Assignment", "Assignment Type")]),
            ("Vacant Positions Without Open Requisition", "Count of vacant positions (as in Vacancy Rate %) for which no Job Requisition with Requisition Position = the position has Requisition Status in (Pending Approval, Open, On Hold), split by Key-Person Risk Indicator and Position Org Unit.",
             [("20", "Job Requisition", "Requisition Position"), ("20", "Job Requisition", "Requisition Status"),
              ("20", "Workforce Position", "Key-Person Risk Indicator"), ("20", "Workforce Position", "Position Org Unit"),
              "Vacancy Rate %"]),
            ("Regulated Hires Screened Before Start %", "Hires whose primary assignment's Job Profile has a Regulated Role Category other than Not Regulated, and who have a Background Screening of every type the firm's screening matrix requires for that category with Screening Completed Date on or before the hire Event Effective Date and Background Screening Result in (Clear, Clear with Discrepancy) / all such hires in the period.",
             [("20", "Background Screening", "Screened Employee"), ("20", "Background Screening", "Screened Candidate Application"),
              ("20", "Background Screening", "Screening Type"), ("20", "Background Screening", "Screening Completed Date"),
              ("20", "Background Screening", "Background Screening Result"), ("20", "Job Profile", "Regulated Role Category"),
              ("20", "Employee Job Assignment", "Assigned Job Profile"), ("20", "Employee Lifecycle Event", "Event Effective Date"),
              "Hires"]),
            ("Adverse Screening Results Open", "Count of Background Screening rows with Background Screening Result = Adverse - Under Adjudication, by Screening Type and Screening Finding Severity, with days since Screening Completed Date (restricted HR view only).",
             [("20", "Background Screening", "Background Screening Result"), ("20", "Background Screening", "Screening Type"),
              ("20", "Background Screening", "Screening Finding Severity"), ("20", "Background Screening", "Screening Completed Date")]),
            ("Regulated Leavers Not Flagged", "Count of Termination events in the period for workers whose primary assignment's Job Profile has a Regulated Role Category other than Not Regulated and whose Regulatory Notification Required Indicator = N or blank.",
             [("20", "Employee Lifecycle Event", "Regulatory Notification Required Indicator"),
              ("20", "Employee Lifecycle Event", "Event Employee"), ("20", "Job Profile", "Regulated Role Category"), "Leavers"]),
            ("Leaves Past Expected Return", "Count of Leave of Absence rows with Expected Return Date before the as-of date and no Actual Return Date, by Leave Type (Medical Leave and Long-Term Disability shown only in the restricted view) and Job-Protected Leave Indicator.",
             [("20", "Leave of Absence", "Leave Employee"), ("20", "Leave of Absence", "Leave Type"),
              ("20", "Leave of Absence", "Expected Return Date"), ("20", "Leave of Absence", "Actual Return Date"),
              ("20", "Leave of Absence", "Job-Protected Leave Indicator")]),
            ("Candidate Records Past Retention", "Count of Candidate Applications with no Hired As Employee and Candidate Data Retention End Date before the as-of date that are still held.",
             [("20", "Candidate Application", "Candidate ID"), ("20", "Candidate Application", "Hired As Employee"),
              ("20", "Candidate Application", "Candidate Data Retention End Date")]),
        ],
        inputs=[
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Home Org Unit", "Work Location", "Employment Type",
                                "Employment Status", "Hire Date", "Termination Date"]),
            ("20", "Contingent Worker Detail", ["Contingent Worker Type"]),
            ("20", "Employee Lifecycle Event", ["Lifecycle Event ID", "Event Employee", "Lifecycle Event Type", "Event Effective Date",
                                                "Termination Reason", "Voluntary Termination Indicator", "Notice Period End Date",
                                                "Regulatory Notification Required Indicator", "Related Reorganization"]),
            ("20", "Leave of Absence", ["Leave Employee", "Leave Type", "Leave Start Date", "Expected Return Date", "Actual Return Date",
                                        "Job-Protected Leave Indicator"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assigned Workforce Position", "Assigned Job Profile", "Assignment Type",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("20", "Workforce Position", ["Workforce Position ID", "Position Job Profile", "Position Org Unit", "Position Legal Entity",
                                          "Position Location", "Position Cost Center", "Authorized FTE", "Position Status",
                                          "Key-Person Risk Indicator", "Position Effective From", "Position Effective To"]),
            ("20", "Job Profile", ["Job Profile ID", "Job Profile Family", "Job Level", "Regulated Role Category"]),
            ("20", "Job Requisition", ["Job Requisition ID", "Requisition Position", "Hiring Manager", "Requisition Reason",
                                       "Requisition Status", "Requisition Opened Date", "Requisition Filled Date"]),
            ("20", "Candidate Application", ["Candidate Application ID", "Candidate ID", "Applied Requisition", "Candidate Source",
                                             "Application Stage", "Internal Candidate Employee", "Hired As Employee",
                                             "Candidate Data Retention End Date"]),
            ("20", "Background Screening", ["Screened Employee", "Screened Candidate Application", "Screening Type", "Screening Vendor",
                                            "Screening Completed Date", "Background Screening Result", "Screening Finding Severity",
                                            "Related Individual Registration"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Period End Date"]),
            ("19", "Chart Segment Value", ["Chart Segment", "Segment Value Code", "Segment Value Name"]),
        ],
        upstream=["DP-192", "DP-190", "DP-013"],
        refresh="Daily",
        timeliness="Event-level tables by 8am ET on T+1; period movement and turnover rates by business day 4 after period end, once DP-192 has published certified headcount for the period (business day 3)",
        history="Locked month-end rate snapshots kept for 7 years at the org structure in effect for the period; lifecycle events and requisitions kept for the employment record retention period; candidate applications deleted at Candidate Data Retention End Date; screening results kept only as long as the screening policy allows",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Average Headcount for every breakdown and period equals the mean of the DP-192 Certified Headcount values for the same period ends and breakdown.",
            "Every Hire or Rehire event in the period has an Employee whose Hire Date equals the event's Event Effective Date.",
            "Every Job Requisition with Requisition Status = Filled has a Requisition Filled Date on or after its Requisition Opened Date and at least one Candidate Application with Hired As Employee populated.",
            "Every Background Screening row references exactly one of Screened Employee or Screened Candidate Application, and has a Screening Completed Date when Background Screening Result is populated.",
            "Every Termination event has a Termination Reason, and its Voluntary Termination Indicator matches the voluntary or involuntary mapping of that reason.",
            "No worker has two Leave of Absence rows whose periods (Leave Start Date to Actual Return Date, or Expected Return Date when not returned) overlap.",
        ],
        notes=("Certified numbers: none owned. Certified Headcount and FTE come from DP-192 (CD-341, applied there as every employed "
               "status: Active, Leave of Absence, Notice Period, Garden Leave); turnover, mobility, vacancy and time to fill are this "
               "product's derived measures and are never published as headcount. Hires and Leavers are the joiner and leaver counts "
               "DP-192 publishes in Joiners, Movers and Leavers, restricted to employees; contingent workers are excluded from rates "
               "as they are from Certified Headcount. Personal data tiers (CD-344): the product is Confidential - Personal Data; "
               "Background Screening results and severity (criminal record data under the FCRA; fingerprinting under FINRA Rule 3110(e) and state biometric laws) and Leave "
               "Type values Medical Leave and Long-Term Disability (health data) are published only in a Restricted - Personal Data "
               "HR view; the wide view shows counts without those breakdowns. Candidate Name is deliberately not read. Boundary: "
               "Form U5 filing and its timeliness stay 08 / DP-039; this product only tests that the 20 flag is set. Related "
               "Individual Registration (08) and Screening Vendor (02) are carried as keys. Cost center labels come from DP-190 "
               "(Position Cost Center). Open SME questions (20 Q1, Q7, Q10): whether the HRIS holds contractors; whether candidate "
               "data is in scope (if not, Internal Fill Rate %, Source of Hire Mix % and Candidate Records Past Retention are "
               "dropped); whether position management is used (without it Vacancy Rate % and Vacant Positions Without Open "
               "Requisition are empty). Taxonomy gap: there is no screening requirement matrix (which Screening Types each Regulated "
               "Role Category requires); Regulated Hires Screened Before Start % reads the firm's screening policy outside the "
               "taxonomy. Taxonomy gap: Job Requisition has no offer accepted or planned start date, so time to fill ends at "
               "Requisition Filled Date and time to start cannot be measured. Decisions: CD-151, CD-293, CD-341, CD-344."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-198": dict(
        definition=("Base pay, variable awards, payroll results by run and the benefit plans and enrollments of every employee, "
                    "with each payroll run reconciled to the payroll journals it posted to the ledger. It is the certified source "
                    "of compensation paid (CD-347): what payroll paid, by employee and run, set beside the incentive earned of the "
                    "03 Compensation Statement (governed in DP-390) and reconciled to the GL postings behind DP-191's compensation expense, so that Reward, payroll "
                    "operations and the Controller work from one paid number and can see every unpaid incentive statement, "
                    "every payment to a leaver and every run that does not tie to its journals."),
        business_questions=[
            "What did payroll pay this period in gross pay, net pay and employer social charges, by legal entity, run type and org unit?",
            "Does every payroll run tie exactly to the journals posted for it, and which runs are not yet posted or are out of balance?",
            "Which advisor incentive compensation statements were issued but not yet paid through payroll?",
            "Who was paid after their termination date, and which active employees were missing from a regular run?",
            "What did the annual pay review change, by pay change reason, job level and org unit, and what variable awards were granted for the performance year?",
            "What share of eligible employees is enrolled in each benefit plan, and which leavers still have active coverage?",
        ],
        grain="Employee x payroll run (payroll result), with payroll run (legal entity x pay period x run sequence), base pay record (employee x pay component x effective period), variable compensation award and benefit enrollment (employee x plan x coverage period) as child tables",
        dimensions=["Pay date and pay period", "Payroll run, run type and status", "Employing legal entity", "Org unit",
                    "Employee", "Pay component and pay change reason", "Variable award type and performance year",
                    "Benefit plan, plan type and plan year", "Coverage level", "Currency", "GL account and cost center (DP-190)"],
        measures=[
            ("Gross Pay Paid", "Sum of Gross Pay Amount of Payroll Results in Payroll Runs with Pay Date in the period and Payroll Run Status in (Paid, Posted to GL), by Payroll Run Legal Entity, Payroll Run Type and Payroll Currency. The certified compensation paid number (CD-347).",
             [("20", "Payroll Result", "Gross Pay Amount"), ("20", "Payroll Result", "Payroll Run"), ("20", "Payroll Result", "Payroll Currency"),
              ("20", "Payroll Run", "Pay Date"), ("20", "Payroll Run", "Payroll Run Status"), ("20", "Payroll Run", "Payroll Run Legal Entity"),
              ("20", "Payroll Run", "Payroll Run Type")]),
            ("Net Pay Paid", "Sum of Net Pay Amount of the same Payroll Results.",
             [("20", "Payroll Result", "Net Pay Amount"), "Gross Pay Paid"]),
            ("Employer Social Charges", "Sum of Employer Social Charges Amount of the same Payroll Results.",
             [("20", "Payroll Result", "Employer Social Charges Amount"), "Gross Pay Paid"]),
            ("Run-to-Journal Difference", "Per Payroll Run: (sum of Gross Pay Amount + sum of Employer Social Charges Amount of its Payroll Results) - sum of Posted Amount of debit GL Postings (Debit Credit Indicator = Debit) whose Source Payroll Run = the run, on the Journal Entries listed in Payroll Journal Entries with Journal Status posted. Expected zero.",
             [("20", "Payroll Result", "Gross Pay Amount"), ("20", "Payroll Result", "Employer Social Charges Amount"),
              ("20", "Payroll Run", "Payroll Run Identifier"), ("20", "Payroll Run", "Payroll Journal Entries"),
              ("19", "GL Posting", "Posted Amount"), ("19", "GL Posting", "Debit Credit Indicator"), ("19", "GL Posting", "Source Payroll Run"),
              ("19", "GL Posting", "Journal ID"), ("19", "Journal Entry", "Journal ID"), ("19", "Journal Entry", "Journal Status")]),
            ("Runs Not Reconciled", "Count of Payroll Runs with Payroll Run Status in (Paid, Posted to GL) and Pay Date more than 2 business days before the as-of date whose Run-to-Journal Difference is not zero or that have no Payroll Journal Entries.",
             [("20", "Payroll Run", "Payroll Run Status"), ("20", "Payroll Run", "Pay Date"), ("20", "Payroll Run", "Payroll Journal Entries"),
              "Run-to-Journal Difference"]),
            ("Incentive Statements Unpaid", "Count and Net Payable Amount of 03 Compensation Statements with Statement Status issued and Statement Issued Date on or before the as-of date that no Payroll Result lists in Incentive Payout Statements in a run with Pay Date on or after the Statement Issued Date, or whose Payroll Result Reference is empty.",
             [("03", "Compensation Statement", "Statement ID"), ("03", "Compensation Statement", "Net Payable Amount"),
              ("03", "Compensation Statement", "Statement Status"), ("03", "Compensation Statement", "Statement Issued Date"),
              ("03", "Compensation Statement", "Payroll Result Reference"), ("20", "Payroll Result", "Incentive Payout Statements"),
              ("20", "Payroll Run", "Pay Date")]),
            ("Payments to Leavers", "Count and Gross Pay Amount of Payroll Results in Payroll Runs with Payroll Run Type = Regular whose employee's Termination Date is before the run's Pay Period Start Date.",
             [("20", "Payroll Result", "Payroll Employee"), ("20", "Payroll Result", "Gross Pay Amount"),
              ("20", "Payroll Run", "Payroll Run Type"), ("20", "Payroll Run", "Pay Period Start Date"), ("20", "Employee", "Termination Date")]),
            ("Active Employees Not Paid", "Count of employees with an employed Employment Status throughout a Regular run's pay period, Employing Legal Entity = Payroll Run Legal Entity and no Contingent Worker Type, who have no Payroll Result in that run.",
             [("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Employing Legal Entity"),
              ("20", "Contingent Worker Detail", "Contingent Worker Type"), ("20", "Payroll Run", "Payroll Run Legal Entity"),
              ("20", "Payroll Run", "Pay Period Start Date"), ("20", "Payroll Run", "Pay Period End Date"), ("20", "Payroll Result", "Payroll Employee")]),
            ("Annualized Base Pay", "Per employee: sum over Base Pay Records effective on the as-of date of Pay Component Amount annualized by Pay Amount Basis (Annual x 1; Monthly x 12; Per Pay Period x pay periods per year of the employee's regular run; Hourly x the firm's standard annual hours x Assignment FTE), in Pay Currency; aggregated as the base pay bill by entity, org unit and job level.",
             [("20", "Base Pay Record", "Paid Employee"), ("20", "Base Pay Record", "Pay Component"), ("20", "Base Pay Record", "Pay Component Amount"),
              ("20", "Base Pay Record", "Pay Currency"), ("20", "Base Pay Record", "Pay Amount Basis"), ("20", "Base Pay Record", "Pay Effective From"),
              ("20", "Base Pay Record", "Pay Effective To"), ("20", "Employee Job Assignment", "Assignment FTE"),
              ("20", "Employee Job Assignment", "Assignment Type")]),
            ("Pay Review Increase %", "For Base Pay Records with Pay Change Reason in the review cycle and Pay Effective From in the cycle: (new Annualized Base Pay - Annualized Base Pay on the day before Pay Effective From) / Annualized Base Pay on the day before, averaged and summed by Pay Change Reason, job level and org unit.",
             [("20", "Base Pay Record", "Pay Change Reason"), ("20", "Base Pay Record", "Pay Effective From"), "Annualized Base Pay"]),
            ("Variable Awards Granted", "Sum of Award Amount of Variable Compensation Awards with Award Grant Date in the period, by Variable Award Type, Performance Year and Award Currency; upfront portion = Award Amount x (1 - Deferred Portion Percentage). Deferred tranches are DP-199's.",
             [("20", "Variable Compensation Award", "Award Amount"), ("20", "Variable Compensation Award", "Variable Award Type"),
              ("20", "Variable Compensation Award", "Performance Year"), ("20", "Variable Compensation Award", "Award Currency"),
              ("20", "Variable Compensation Award", "Deferred Portion Percentage"), ("20", "Variable Compensation Award", "Award Grant Date")]),
            ("Awards Granted Without Committee Approval", "Count of Variable Compensation Awards with Award Grant Date populated and Remuneration Committee Approval Date blank or later than Award Grant Date.",
             [("20", "Variable Compensation Award", "Award Grant Date"), ("20", "Variable Compensation Award", "Remuneration Committee Approval Date"),
              ("20", "Variable Compensation Award", "Variable Compensation Award ID")]),
            ("Benefit Enrollment Rate %", "Per Benefit Plan with Benefit Plan Status active in the plan year: distinct employees with a Benefit Enrollment in the plan with Coverage Level other than Waived and coverage effective on the as-of date / employees with an employed Employment Status whose Employing Legal Entity = Offering Legal Entity.",
             [("20", "Benefit Enrollment", "Enrolled Employee"), ("20", "Benefit Enrollment", "Enrolled Benefit Plan"),
              ("20", "Benefit Enrollment", "Coverage Level"), ("20", "Benefit Enrollment", "Coverage Start Date"),
              ("20", "Benefit Enrollment", "Coverage End Date"), ("20", "Benefit Plan", "Benefit Plan Status"),
              ("20", "Benefit Plan", "Offering Legal Entity"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Employing Legal Entity")]),
            ("Leavers With Active Coverage", "Count of Benefit Enrollments with Coverage End Date blank or later than the end of the month of the enrolled employee's Termination Date (the firm's default coverage rule), by Benefit Type.",
             [("20", "Benefit Enrollment", "Coverage End Date"), ("20", "Benefit Plan", "Benefit Type"), ("20", "Employee", "Termination Date")]),
        ],
        inputs=[
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Home Org Unit", "Employment Type", "Employment Status",
                                "Termination Date"]),
            ("20", "Contingent Worker Detail", ["Contingent Worker Type"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assigned Job Profile", "Assignment Type", "Assignment FTE",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("20", "Base Pay Record", ["Paid Employee", "Pay Component", "Pay Component Amount", "Pay Currency", "Pay Amount Basis",
                                       "Pay Change Reason", "Pay Effective From", "Pay Effective To"]),
            ("20", "Variable Compensation Award", ["Variable Compensation Award ID", "Award Recipient", "Variable Award Type",
                                                   "Performance Year", "Award Amount", "Award Currency", "Deferred Portion Percentage",
                                                   "Award Instrument", "Award Grant Date", "Remuneration Committee Approval Date"]),
            ("20", "Payroll Run", ["Payroll Run Identifier", "Payroll Run Legal Entity", "Payroll Run Type", "Pay Period Start Date",
                                   "Pay Period End Date", "Pay Date", "Payroll Provider", "Payroll Run Status", "Payroll Journal Entries"]),
            ("20", "Payroll Result", ["Payroll Employee", "Payroll Run", "Gross Pay Amount", "Income Tax Withheld Amount",
                                      "Employee Social Security Amount", "Employer Social Charges Amount", "Net Pay Amount",
                                      "Payroll Currency", "Incentive Payout Statements"]),
            ("20", "Benefit Plan", ["Benefit Plan ID", "Benefit Plan Year", "Benefit Plan Name", "Benefit Type", "Offering Legal Entity",
                                    "Benefit Provider", "Firm-Recordkept Plan Indicator", "Benefit Plan Status"]),
            ("20", "Benefit Enrollment", ["Enrolled Employee", "Enrolled Benefit Plan", "Coverage Level", "Enrollment Event",
                                          "Coverage Start Date", "Coverage End Date", "Own Plan Membership"]),
            ("03", "Compensation Statement", ["Statement ID", "Statement Participant", "Statement Period End", "Total Earned",
                                              "Net Payable Amount", "Statement Status", "Statement Issued Date",
                                              "Payroll Result Reference"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Ledger", "Journal Source", "Posting Date", "Posting Accounting Period",
                                     "Posting Legal Entity", "Journal Status"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount",
                                  "Cost Center Segment Value", "Source Payroll Run"]),
        ],
        upstream=["DP-192", "DP-191", "DP-190", "DP-013"],
        refresh="Daily",
        timeliness="Payroll results and run status by 8am ET on the business day after each Pay Date; run-to-journal reconciliation by business day 2 after Pay Date; base pay, awards and enrollments by 8am ET on T+1",
        history="Payroll runs and results kept for the payroll record retention period (at least 7 years); base pay, awards and enrollments SCD type 2 since HRIS go-live; month-end reconciliation snapshots kept for 7 years",
        classification="Confidential - Compensation",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Payroll Result has Net Pay Amount <= Gross Pay Amount, and Gross Pay Amount - Income Tax Withheld Amount - Employee Social Security Amount >= Net Pay Amount.",
            "Every Payroll Run with Payroll Run Status = Posted to GL has at least one Payroll Journal Entry and a Run-to-Journal Difference of zero.",
            "Every Payroll Employee resolves to a DP-192 worker whose Employing Legal Entity equals the Payroll Run Legal Entity during the pay period, or whose Termination Date falls in or before the period on a final-pay run.",
            "Base Pay Records of the same Paid Employee and Pay Component do not overlap in effective period.",
            "Every 03 Compensation Statement with a Payroll Result Reference is listed in that Payroll Result's Incentive Payout Statements, and its Statement Participant is the Payroll Employee.",
            "Every Benefit Enrollment's Coverage Start Date falls within the Benefit Plan Year of its Enrolled Benefit Plan.",
        ],
        notes=("W4 re-point (CW-907, CW-062): 07 Compensation Statement re-pointed to 03 Compensation Statement (CPS-, absorbed "
               "by 03 with 07's retirement), which now carries Statement Status, Statement Issued Date and the Payroll Result "
               "Reference; 07 Payroll Payment Instruction dropped, no successor (payment is the 20 Payroll Result); the measures "
               "Incentive Instructions Unpaid and Incentive Paid vs Earned Difference are replaced by Incentive Statements Unpaid, "
               "and paid versus earned per statement is not measurable until 20 carries a paid amount per statement (taxonomy gap). "
               "Certified numbers (CD-347): compensation paid (Gross Pay Paid, by employee and run) is this product's. Incentive "
               "earned and accrued stays 03's (Compensation Statement Total Earned, Net Payable Amount; governed by DP-390); compensation expense by cost center and period stays "
               "DP-191's Certified Compensation Expense. This product compares against both and redefines neither: it reconciles "
               "each run to its postings, not to the period expense, because accruals and reversals sit between them. Payroll posts "
               "in summary per run (Source Payroll Run), so there is no employee-level cost in the ledger. Personal data tier "
               "(CD-344): Confidential - Compensation; access limited to Reward, payroll and the Controller's payroll accounting "
               "role; no diversity data (DP-201) and no deferred tranches or MRT status (DP-199). Employee identity comes from "
               "DP-192 by key. Operating model (CD-297; 20 SME Q11; brief Q5): drafted at the in-house operational grain. If payroll "
               "and benefits administration are outsourced, the grain becomes the provider's payroll register and result file per "
               "run (Payroll Provider populated), the run-to-journal tie-out is unchanged, and the provider's SLA results (on-time "
               "run delivery, correction runs per period) are added as oversight measures. Own 401(k) memberships (Own Plan "
               "Membership) resolve to DP-094 by key; that product is not an upstream. Payroll Journal Entries and Source Payroll "
               "Run meet at the run identifier (20 Source_Notes, decision 3). Open SME questions (20 Q4, Q11, Q14): which "
               "compensation data may appear in the shared catalog; payroll in house or outsourced; whether a multi-entity run is "
               "ever posted as one journal. Taxonomy gap: Payroll Result has no pay component breakdown (base, overtime, bonus, "
               "incentive), so incentive paid through payroll cannot be isolated from gross pay; the paid-versus-earned test runs "
               "at instruction level. Taxonomy gap: Benefit Plan and Benefit Enrollment carry no premium or employer cost, so benefit "
               "cost is not measured here and is read from DP-191 expense accounts. Taxonomy gap: no pay grade or pay range on Job "
               "Profile, so compa-ratio and range penetration cannot be measured. Taxonomy gap: no standard weekly hours (as in "
               "DP-192), so Hourly pay is annualized with a firm parameter. Decisions: CD-151, CD-297, CD-344, CD-347."
               "WP1 re-point (CW-207, CW-062): upstream DP-033 (retired) dropped. Its successor DP-390 Incentive Plan Governance & Advisor Payouts (WP1C_CLA) lists this product upstream for certified pay, so it cannot also be upstream here (cycle); the 03 Compensation Statement attributes Paid vs Earned reads are taken from 03 directly, as the input already does. No measure or input dropped. The FOP+CORP brief's re-point to DP-390 conflicts with the CLA-B DP-390 candidate's upstream; reported to the lead."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-199 re-specified at WP1 in specs_w1c_fop_corp.py
    # ------------------------------------------------------------------------------------------------------------------
    "DP-200": dict(
        definition=("Performance ratings and objectives, succession cover for key-person positions, and the assignment and "
                    "completion of mandatory and regulatory training by population, requirement and due date. It combines the "
                    "talent and learning records of 20 Human Capital with the positions and assignments DP-192 publishes, so that "
                    "HR runs talent reviews and calibration from one record, Compliance sees where regulatory training (AML, conduct "
                    "rules, market abuse) is overdue, and operational resilience sees which key positions have no ready or "
                    "emergency successor. FINRA and FCA continuing education status stays with DP-039; this product shows "
                    "completions only."),
        business_questions=[
            "What share of mandatory training assignments was completed by the due date, by requirement, regulator, org unit and legal entity, and who is overdue?",
            "Which employees in a requirement's population have no assignment for the current cycle, and did new joiners complete induction training on time?",
            "Which key-person positions have no ready-now or emergency successor, and which succession plans have not been reviewed for a year?",
            "How are calibrated ratings distributed by org unit and job level, how far did calibration move proposed ratings, and which reviews are still open after cycle close?",
            "Whose review carries a conduct adjustment, for use in variable pay and malus decisions?",
            "Which open FINRA CE requirements have a completed Firm Element course in the learning record that has not reached the registration record?",
        ],
        grain="Employee x learning item x assignment due date (training), employee x review cycle x review type (performance) and workforce position x successor (succession), published with org unit x legal entity x requirement or cycle x period aggregates",
        dimensions=["Employee", "Org unit", "Employing legal entity", "Job profile and level", "Regulated role category",
                    "Mandatory training requirement, type and regulator", "Learning item and type", "Completion status",
                    "Due date and period", "Review cycle and review type", "Calibrated rating", "Workforce position and key-person flag",
                    "Successor readiness"],
        measures=[
            ("Mandatory Training On-Time Completion %", "Learning Completions for the Required Learning Item of an active Mandatory Training Requirement (effective on the due date), with Completion Due Date in the period, that have Completion Status = Completed and Completion Date <= Completion Due Date / all such assignments excluding Completion Status = Waived, by Training Requirement Type, Requirement Regulator, org unit and legal entity.",
             [("20", "Learning Completion", "Learner Employee"), ("20", "Learning Completion", "Completed Learning Item"),
              ("20", "Learning Completion", "Completion Due Date"), ("20", "Learning Completion", "Completion Status"),
              ("20", "Learning Completion", "Completion Date"), ("20", "Mandatory Training Requirement", "Required Learning Item"),
              ("20", "Mandatory Training Requirement", "Training Requirement Type"), ("20", "Mandatory Training Requirement", "Requirement Regulator"),
              ("20", "Mandatory Training Requirement", "Requirement Effective From"), ("20", "Mandatory Training Requirement", "Requirement Effective To")]),
            ("Overdue Mandatory Training", "Count of assignments of Required Learning Items with Completion Due Date before the as-of date and Completion Status not in (Completed, Waived), and the count of distinct employees with at least one, banded by days overdue (1-30, 31-60, over 60) and Training Requirement Type.",
             [("20", "Learning Completion", "Learner Employee"), ("20", "Learning Completion", "Completion Due Date"),
              ("20", "Learning Completion", "Completion Status"), ("20", "Mandatory Training Requirement", "Required Learning Item"),
              ("20", "Mandatory Training Requirement", "Training Requirement Type")]),
            ("Population Coverage Gaps", "Count of employees with an employed Employment Status who fall within a requirement's Applicable Population Rule but have no Learning Completion for its Required Learning Item due in the current Requirement Recurrence cycle.",
             [("20", "Mandatory Training Requirement", "Training Requirement ID"), ("20", "Mandatory Training Requirement", "Applicable Population Rule"),
              ("20", "Mandatory Training Requirement", "Requirement Recurrence"), ("20", "Mandatory Training Requirement", "Required Learning Item"),
              ("20", "Learning Completion", "Learner Employee"), ("20", "Employee", "Employment Status"),
              ("20", "Job Profile", "Regulated Role Category")]),
            ("New Joiner Training On Time %", "Employees with Hire Date in the period whose mandatory assignments due within their first 90 days were all completed by Completion Due Date / employees hired in the period.",
             [("20", "Employee", "Hire Date"), ("20", "Learning Completion", "Completion Due Date"), ("20", "Learning Completion", "Completion Date"),
              ("20", "Learning Completion", "Completion Status")]),
            ("Rating Distribution %", "Share of Performance Reviews with Review Status in (Completed, Acknowledged) by Calibrated Rating within each Review Cycle, Review Type, org unit and job level; Too New to Rate excluded from the denominator.",
             [("20", "Performance Review", "Calibrated Rating"), ("20", "Performance Review", "Review Status"),
              ("20", "Performance Review", "Review Cycle"), ("20", "Performance Review", "Review Type")]),
            ("Calibration Change %", "Completed reviews whose Calibrated Rating differs from Proposed Rating / completed reviews, split into moved up and moved down, by Review Cycle and org unit.",
             [("20", "Performance Review", "Calibrated Rating"), ("20", "Performance Review", "Proposed Rating"), "Rating Distribution %"]),
            ("Reviews Open After Cycle Close", "Count of Year-End Performance Reviews for employees employed at cycle end whose Review Status is not in (Completed, Acknowledged) after the cycle close date set by HR.",
             [("20", "Performance Review", "Reviewed Employee"), ("20", "Performance Review", "Review Type"),
              ("20", "Performance Review", "Review Status"), ("20", "Performance Review", "Review Cycle")]),
            ("Conduct Adjustments", "Count of Performance Reviews with Conduct Adjustment Indicator = Y by Review Cycle and org unit; employee-level rows are published to DP-199 for malus assessment.",
             [("20", "Performance Review", "Conduct Adjustment Indicator"), ("20", "Performance Review", "Reviewed Employee"),
              ("20", "Performance Review", "Review Cycle")]),
            ("Objective Weighting Breaks", "Count of employees and review cycles whose Performance Objectives' Objective Weight does not sum to 100%, or who have no objective with Objective Category = Risk & Conduct where their job profile is regulated.",
             [("20", "Performance Objective", "Objective Employee"), ("20", "Performance Objective", "Objective Review Cycle"),
              ("20", "Performance Objective", "Objective Weight"), ("20", "Performance Objective", "Objective Category"),
              ("20", "Job Profile", "Regulated Role Category")]),
            ("Key-Person Succession Cover %", "Workforce Positions effective on the as-of date with Key-Person Risk Indicator = Y and Position Status not Closed that have at least one Succession Plan Entry with Successor Readiness = Ready Now whose Successor Employee has an employed Employment Status / all such positions.",
             [("20", "Workforce Position", "Workforce Position ID"), ("20", "Workforce Position", "Key-Person Risk Indicator"),
              ("20", "Workforce Position", "Position Status"), ("20", "Workforce Position", "Position Effective From"),
              ("20", "Workforce Position", "Position Effective To"), ("20", "Succession Plan Entry", "Succession Position"),
              ("20", "Succession Plan Entry", "Successor Employee"), ("20", "Succession Plan Entry", "Successor Readiness"),
              ("20", "Employee", "Employment Status")]),
            ("Key Positions Without Emergency Successor", "Count of key-person positions (as in Key-Person Succession Cover %) with no Succession Plan Entry whose Emergency Successor Indicator = Y and whose Successor Employee is employed.",
             [("20", "Succession Plan Entry", "Emergency Successor Indicator"), ("20", "Succession Plan Entry", "Successor Employee"),
              "Key-Person Succession Cover %"]),
            ("Stale Succession Plans", "Count of key-person positions whose latest Succession Review Date is more than 12 months before the as-of date, or that have no Succession Plan Entry.",
             [("20", "Succession Plan Entry", "Succession Review Date"), ("20", "Succession Plan Entry", "Succession Position"),
              ("20", "Workforce Position", "Key-Person Risk Indicator")]),
            ("Successor Concentration", "Count of employees named as Successor Employee with Successor Readiness = Ready Now for three or more key-person positions.",
             [("20", "Succession Plan Entry", "Successor Employee"), ("20", "Succession Plan Entry", "Successor Readiness"),
              ("20", "Workforce Position", "Key-Person Risk Indicator")]),
            ("CE Requirements With Unrecorded Firm Element", "Count of 08 CE Requirements with CE Status not complete whose Registered Person has a Learning Completion with Completion Status = Completed, Completion Date on or before CE Due Date, of a Learning Item with Regulatory Credit Type = FINRA CE - Firm Element.",
             [("08", "CE Requirement", "CE Status"), ("08", "CE Requirement", "CE Due Date"), ("08", "CE Requirement", "CE Element"),
              ("08", "Individual Registration", "Registered Person"), ("20", "Learning Item", "Regulatory Credit Type"),
              ("20", "Learning Completion", "Completion Status"), ("20", "Learning Completion", "Completion Date")]),
        ],
        inputs=[
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Home Org Unit", "Employment Status", "Hire Date", "Termination Date"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assigned Workforce Position", "Assigned Job Profile", "Assignment Type",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("20", "Job Profile", ["Job Profile ID", "Job Level", "Regulated Role Category"]),
            ("20", "Workforce Position", ["Workforce Position ID", "Position Job Profile", "Position Org Unit", "Position Legal Entity",
                                          "Position Status", "Key-Person Risk Indicator", "Position Effective From", "Position Effective To"]),
            ("20", "Performance Review", ["Reviewed Employee", "Review Cycle", "Review Type", "Reviewer", "Proposed Rating", "Calibrated Rating",
                                          "Conduct Adjustment Indicator", "Review Status"]),
            ("20", "Performance Objective", ["Objective Employee", "Objective Review Cycle", "Objective Title", "Objective Category",
                                             "Objective Weight", "Objective Achievement Rating", "Linked Metric Definition"]),
            ("20", "Succession Plan Entry", ["Succession Position", "Successor Employee", "Successor Readiness",
                                             "Emergency Successor Indicator", "Succession Review Date"]),
            ("20", "Learning Item", ["Learning Item ID", "Learning Item Title", "Learning Item Type", "Learning Provider",
                                     "Regulatory Credit Type", "Learning Item Status"]),
            ("20", "Learning Completion", ["Learner Employee", "Completed Learning Item", "Completion Due Date", "Completion Status",
                                           "Completion Date", "Assessment Score", "Satisfied Training Requirement"]),
            ("20", "Mandatory Training Requirement", ["Training Requirement ID", "Training Requirement Name", "Training Requirement Type",
                                                      "Required Learning Item", "Applicable Population Rule", "Requirement Recurrence",
                                                      "Requirement Regulator", "Requirement Effective From", "Requirement Effective To"]),
            ("08", "Individual Registration", ["License ID", "Registered Person"]),
            ("08", "CE Requirement", ["CE Element", "CE Due Date", "CE Status"]),
        ],
        upstream=["DP-192", "DP-039", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET on T+1; month-end training compliance snapshot by business day 3 after month-end; review-cycle results after HR closes calibration",
        history="Learning completions kept for the regulatory record retention period (at least 6 years for AML and conduct training); reviews, objectives and succession entries SCD type 2 since HRIS go-live; month-end compliance snapshots kept for 7 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Learning Completion with Completion Status = Completed has a Completion Date, and none with another status has one.",
            "No Learning Completion has Completion Status = Overdue while its Completion Due Date is on or after the as-of date (Overdue is derived from the due date).",
            "Every Mandatory Training Requirement effective on the as-of date has a Required Learning Item whose Learning Item Status is active.",
            "Every Succession Plan Entry references a Workforce Position effective on its Succession Review Date and a Successor Employee who is not the position's current primary incumbent.",
            "Every Performance Review with Review Status in (Completed, Acknowledged) has a Calibrated Rating.",
        ],
        notes=("Certified numbers: none owned; headcount denominators are DP-192's. Boundary: FINRA and FCA CE status, registrations "
               "and SM&CR certification stay in 08 / DP-039 (20 Source_Notes boundary calls; brief §3); this product reads 08 CE "
               "Requirement only to show where a Firm Element completion has not reached the registration record, and never "
               "publishes CE status. Policy attestations are 38, not learning. Key-Person Risk Indicator is on Workforce Position "
               "(DP-192); mapping people to important business services is 37 Resilience Resource Mapping (CD-249), which reads "
               "Key Positions Without Emergency Successor from here. Conduct adjustments feed DP-199's vesting test. Performance "
               "Objective Linked Metric Definition resolves to a 21 Metric Definition (KPI-) through DP-101 by key. Ratings, "
               "readiness and objectives are opinions about individuals (personal data, not special category); the wide view "
               "publishes org-unit aggregates with no names, and named rows go to HR, line managers and Compliance for training. "
               "Open SME questions (20 Q3, Q9): whether firm-wide registrations stay in 08; which learning system holds completions "
               "and whether 08's CE tracking already depends on it. Taxonomy gap: Applicable Population Rule is free text, so "
               "Population Coverage Gaps evaluates firm-maintained rule logic outside the taxonomy. Taxonomy gap: Learning Item has "
               "no duration or hours (removed in 20 v0.1), so training hours per employee (ISO 30414, ESRS S1-13) cannot be "
               "measured. Taxonomy gap: Review Cycle is a text label with no cycle close date, so Reviews Open After Cycle Close uses "
               "a close date set by HR. Decisions: CD-151, CD-249, CD-341, CD-344."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-201": dict(
        definition=("Self-identified diversity of the workforce by org unit, job level and legal entity, gender and ethnicity pay "
                    "and bonus gaps, and the published human capital metric values for EEO-1 Component 1, state pay data reporting, voluntary "
                    "workforce disclosures and ISO 30414. It is the only product that reads special "
                    "category diversity data (CD-344); it combines that data with job, pay and award records and releases only "
                    "aggregates with a minimum cell size, so that HR, sustainability reporting and finance disclose one set of "
                    "workforce figures whose headcount ties to DP-192."),
        business_questions=[
            "What is the representation of women and of ethnic minority groups by job level, org unit and legal entity, and how is it trending against our targets?",
            "What are the mean and median gender pay and bonus gaps and the pay quartile composition for each US legal entity at the snapshot date?",
            "Which job levels in each legal entity show a gender pay gap of 5% or more that triggers the firm's pay equity review?",
            "What are the EEO-1 Component 1 counts by job category, race / ethnicity and sex for each US establishment?",
            "Do the human capital metric values we publish (headcount, turnover, diversity) tie to the certified numbers and to this product's calculations?",
            "What share of employees has self-identified, by jurisdiction, and where are cells too small to publish?",
        ],
        grain="Metric definition x legal entity, org unit or country x breakdown (diversity category, job level, EEO-1 job category, pay quartile, age band) x period end (snapshot); no employee-level row leaves the product",
        dimensions=["Snapshot date and reporting period", "Legal entity and jurisdiction", "Org unit", "Country", "Job level",
                    "EEO-1 job category", "Gender (legal gender for statutory gaps; gender identity for representation)",
                    "Race / ethnicity (US EEO-1 categories)", "Disability and veteran status", "Age band",
                    "Pay quartile", "Working pattern", "Metric definition and disclosure framework (DP-101)"],
        measures=[
            ("Snapshot Population", "Employees in DP-192 Certified Headcount at the snapshot date (no Contingent Worker Type), with their primary assignment's Job Profile and Working Pattern; the base of every measure below.",
             [("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Employing Legal Entity"),
              ("20", "Employee", "Home Org Unit"), ("20", "Employee Job Assignment", "Assigned Worker"), ("20", "Employee Job Assignment", "Assigned Job Profile"),
              ("20", "Employee Job Assignment", "Assignment Type"), ("20", "Employee Job Assignment", "Working Pattern")]),
            ("Self-Identification Rate %", "Employees in Snapshot Population with an Employee Diversity Profile whose Self-Identification Date is populated / Snapshot Population, by Diversity Collection Jurisdiction and legal entity.",
             [("20", "Employee Diversity Profile", "Self-Identification Date"), ("20", "Employee Diversity Profile", "Diversity Collection Jurisdiction"),
              "Snapshot Population"]),
            ("Representation %", "Employees in each Gender Identity, US Race / Ethnicity Category, Disability Status or Protected Veteran Status value / Snapshot Population in the same cell, by Job Level, org unit and legal entity; Prefer Not to Say shown as its own value; a category is reported only where the jurisdiction's Diversity Data Processing Basis permits; any cell with fewer than 10 employees is suppressed.",
             [("20", "Employee Diversity Profile", "Gender Identity"), ("20", "Employee Diversity Profile", "US Race / Ethnicity Category"),
              ("20", "Employee Diversity Profile", "Disability Status"),
              ("20", "Employee Diversity Profile", "Protected Veteran Status"), ("20", "Employee Diversity Profile", "Diversity Data Processing Basis"),
              ("20", "Job Profile", "Job Level"), "Snapshot Population"]),
            ("Women in Senior Leadership %", "Employees with Legal Gender = Female and a primary Job Profile with Job Level in (Managing Director, Executive) / all employees at those levels, by legal entity and firm-wide.",
             [("20", "Employee Personal Detail", "Legal Gender"), ("20", "Job Profile", "Job Level"), "Snapshot Population"]),
            ("FTE-Adjusted Pay", "Per employee in Snapshot Population: annualized fixed pay at the snapshot date (sum of Pay Component Amount of Base Pay Records effective on the date, annualized by Pay Amount Basis) / Assignment FTE of the primary assignment, in Pay Currency; the pay basis of every gap below.",
             [("20", "Base Pay Record", "Paid Employee"), ("20", "Base Pay Record", "Pay Component Amount"), ("20", "Base Pay Record", "Pay Amount Basis"),
              ("20", "Base Pay Record", "Pay Currency"), ("20", "Base Pay Record", "Pay Effective From"), ("20", "Base Pay Record", "Pay Effective To"),
              ("20", "Employee Job Assignment", "Assignment FTE"), "Snapshot Population"]),
            ("Gender Pay Gap (Mean and Median) %", "Per legal entity: (mean FTE-Adjusted Pay of men - mean FTE-Adjusted Pay of women) / mean FTE-Adjusted Pay of men, and the same with medians, on Legal Gender, at the snapshot date (voluntary disclosure and state pay data reporting). Indicative (FTE-adjusted annual pay until 20 Standard Weekly Hours and Hours Worked are populated, CD-364).",
             [("20", "Employee Personal Detail", "Legal Gender"), ("20", "Employee", "Employing Legal Entity"), "FTE-Adjusted Pay"]),
            ("Pay Quartile Composition %", "Per legal entity: employees ranked by FTE-Adjusted Pay and split into four equal-sized quartiles; share of women and of men in each quartile. Indicative (FTE-adjusted annual pay until 20 Standard Weekly Hours and Hours Worked are populated, CD-364).",
             [("20", "Employee Personal Detail", "Legal Gender"), "FTE-Adjusted Pay"]),
            ("Bonus Gap and Bonus Receipt %", "Per legal entity: (mean Award Amount of men - mean of women) / mean of men, and the same with medians, over Variable Compensation Awards with Award Grant Date in the 12 months to the snapshot date (Variable Award Type in Annual Cash Bonus, Deferred Award, Sign-On Award, Retention Award); bonus receipt % = employees with such an award / employees, by Legal Gender.",
             [("20", "Variable Compensation Award", "Award Recipient"), ("20", "Variable Compensation Award", "Award Amount"),
              ("20", "Variable Compensation Award", "Award Currency"), ("20", "Variable Compensation Award", "Variable Award Type"),
              ("20", "Variable Compensation Award", "Award Grant Date"), ("20", "Employee Personal Detail", "Legal Gender"), "Snapshot Population"]),
            ("Ethnicity Pay Gap %", "Per legal entity: (median FTE-Adjusted Pay of employees with US Race / Ethnicity Category = White - median of employees in the other declared categories) / median of White employees; Prefer Not to Say excluded; not published where either group has fewer than 10 employees. Indicative (FTE-adjusted annual pay until 20 Standard Weekly Hours and Hours Worked are populated, CD-364).",
             [("20", "Employee Diversity Profile", "US Race / Ethnicity Category"), "FTE-Adjusted Pay"]),
            ("Worker Categories With Gap of 5% or More", "Per legal entity: count of Job Levels whose Gender Pay Gap (Mean) % on FTE-Adjusted Pay is 5% or more (the firm's pay equity review trigger, a policy parameter). Indicative (FTE-adjusted annual pay until 20 Standard Weekly Hours and Hours Worked are populated, CD-364).",
             [("20", "Job Profile", "Job Level"), ("20", "Employee", "Employing Legal Entity"), "Gender Pay Gap (Mean and Median) %"]),
            ("EEO-1 Component 1 Counts", "Count of employees of US legal entities in Snapshot Population for the EEO-1 workforce snapshot period, by EEO-1 Job Category of the primary Job Profile x US Race / Ethnicity Category x Legal Gender, by establishment (Work Location).",
             [("20", "Job Profile", "EEO-1 Job Category"), ("20", "Employee Diversity Profile", "US Race / Ethnicity Category"),
              ("20", "Employee Personal Detail", "Legal Gender"), ("20", "Employee", "Work Location"), "Snapshot Population"]),
            ("Age Band Distribution %", "Employees by age at the snapshot date (from Date of Birth) in the bands under 30, 30 to 50, over 50 (voluntary workforce disclosure) / Snapshot Population, by legal entity and country of residence.",
             [("20", "Employee Personal Detail", "Date of Birth"), ("20", "Employee Personal Detail", "Country of Residence"), "Snapshot Population"]),
            ("Turnover by Gender %", "DP-197's Turnover Rate % definition applied by Legal Gender: Termination events (Death and Transfer to Affiliate excluded) in the year / average Snapshot Population, by legal entity.",
             [("20", "Employee Lifecycle Event", "Event Employee"), ("20", "Employee Lifecycle Event", "Lifecycle Event Type"),
              ("20", "Employee Lifecycle Event", "Event Effective Date"), ("20", "Employee Lifecycle Event", "Termination Reason"),
              ("20", "Employee Personal Detail", "Legal Gender"), "Snapshot Population"]),
            ("Published Value Mismatches", "Count of Human Capital Metric Value rows whose Metric Definition is a headcount or FTE metric and whose Metric Value differs from DP-192's certified value for the same Metric Period End Date, Metric Legal Entity or Metric Org Unit and Metric Breakdown, plus rows of metrics calculated here whose Metric Value differs from this product's value.",
             [("20", "Human Capital Metric Value", "Metric Definition"), ("20", "Human Capital Metric Value", "Metric Value"),
              ("20", "Human Capital Metric Value", "Metric Period End Date"), ("20", "Human Capital Metric Value", "Metric Legal Entity"),
              ("20", "Human Capital Metric Value", "Metric Org Unit"), ("20", "Human Capital Metric Value", "Metric Breakdown"),
              ("21", "Metric Definition", "Metric ID"), ("21", "Metric Definition", "Metric Source Data Product"), "Snapshot Population"]),
            ("Suppressed Cells", "Count of aggregate cells withheld because they contain fewer than 10 employees (or fewer than the jurisdiction's stricter limit), by measure and publication.",
             ["Representation %", "Ethnicity Pay Gap %", "EEO-1 Component 1 Counts"]),
        ],
        inputs=[
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Home Org Unit", "Work Location", "Employment Type",
                                "Employment Status", "Hire Date", "Termination Date"]),
            ("20", "Employee Personal Detail", ["Date of Birth", "Legal Gender", "Country of Residence"]),
            ("20", "Employee Diversity Profile", ["Diversity Collection Jurisdiction", "Diversity Data Processing Basis", "Gender Identity",
                                                  "US Race / Ethnicity Category", "Disability Status",
                                                  "Protected Veteran Status", "Sexual Orientation", "Self-Identification Date"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assigned Job Profile", "Assignment Type", "Assignment FTE",
                                               "Working Pattern", "Assignment Effective From", "Assignment Effective To",
                                               "Standard Weekly Hours"]),
            ("20", "Payroll Result", ["Payroll Employee", "Payroll Run", "Hours Worked"]),
            ("20", "Job Profile", ["Job Profile ID", "Job Profile Family", "Job Level", "EEO-1 Job Category"]),
            ("20", "Base Pay Record", ["Paid Employee", "Pay Component", "Pay Component Amount", "Pay Currency", "Pay Amount Basis",
                                       "Pay Effective From", "Pay Effective To"]),
            ("20", "Variable Compensation Award", ["Award Recipient", "Variable Award Type", "Performance Year", "Award Amount",
                                                   "Award Currency", "Award Grant Date"]),
            ("20", "Employee Lifecycle Event", ["Event Employee", "Lifecycle Event Type", "Event Effective Date", "Termination Reason",
                                                "Voluntary Termination Indicator"]),
            ("20", "Human Capital Metric Value", ["Metric Definition", "Metric Org Unit", "Metric Legal Entity", "Metric Country",
                                                  "Metric Breakdown", "Metric Period Type", "Metric Period End Date", "Metric Value",
                                                  "Disclosure Classification"]),
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Formula", "Metric Disclosure Frameworks",
                                         "Metric Source Data Product", "Metric Certification Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Jurisdiction of Formation"]),
        ],
        upstream=["DP-192", "DP-198", "DP-197", "DP-101", "DP-013"],
        refresh="Monthly",
        timeliness="Representation and self-identification by business day 5 after month-end; statutory disclosures by their deadlines (EEO-1 in the EEOC collection window; state pay data reports by the state deadline)",
        history="Monthly aggregate snapshots and every published disclosure kept for 10 years; the restricted employee-level working set is rebuilt at each run and not retained beyond the disclosure audit period",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Regulatory report", "File extract"],
        dq_rules=[
            "Snapshot Population for every legal entity and snapshot date equals DP-192 Certified Headcount for the same entity and date.",
            "No published cell (Representation %, Ethnicity Pay Gap %, EEO-1 Component 1 Counts, Age Band Distribution %) is based on fewer than 10 employees.",
            "Every Human Capital Metric Value row for a headcount or FTE metric equals DP-192's certified value for the same period end and breakdown.",
            "No diversity category is reported for a Diversity Collection Jurisdiction whose Diversity Data Processing Basis does not permit it.",
            "Every employee in a pay gap calculation has a Base Pay Record effective on the snapshot date and a primary assignment with Assignment FTE greater than zero.",
        ],
        notes=("W1b re-point (CW-920): Employee Diversity Profile.UK Ethnic Group dropped (removed with its list); Ethnicity Pay Gap % is re-pointed to US Race / Ethnicity Category (White against the other declared categories) and Representation % no longer reads it. The UK gender pay gap regulations, the EU Pay Transparency Directive and ESRS S1 left 20 with CW-920, so the gender pay gap measures are voluntary and state pay data figures per legal entity and Worker Categories With Gap of 5% or More is the firm's pay equity review trigger. "
               "Certified numbers: none owned. Headcount and FTE come from DP-192 (CD-341); Human Capital Metric Value rows for "
               "headcount must equal DP-192, and this product tests that. Turnover by Gender % applies DP-197's turnover definition "
               "(hence DP-197 upstream) because only this product may combine it with gender. Personal data tier (CD-344): the "
               "only reader of Employee Diversity Profile (special category: racial or ethnic origin, health, sexual orientation; "
               "CPRA sensitive personal information). The employee-level working set is Restricted - Personal Data, accessible only to named HR analytics "
               "roles; only aggregates with a minimum cell size of 10 leave the product, and published values take the Disclosure "
               "Classification of the Human Capital Metric Value row. Sexual Orientation is read only where the jurisdiction's "
               "processing basis allows; Nationality is not read. Gender pay gaps use Legal Gender (EEO-1 uses "
               "sex); Gender Identity is used for voluntary representation. Pay is read from 20 under the DP-198 compensation tier "
               "and never published at employee level. Metric definitions resolve to 21 (KPI-) through DP-101. Work-related "
               "injuries come from DP-208, not here. Open SME questions (20 Q8): which diversity data is collected in "
               "which jurisdictions and on what basis; whether VEVRAA / Section 503 apply. CD-364 (GAP-20-001, ruled "
               "2026-10-14): 20 now holds Standard Weekly Hours on Employee Job Assignment (with Full-Time Reference Hours on "
               "Workforce Position) and Hours Worked on Payroll Result, read here so the lineage exists; until they are populated, "
               "Gender Pay Gap (Mean and Median) %, Pay Quartile Composition %, Ethnicity Pay Gap % and Worker Categories With Gap "
               "of 5% or More are indicative on FTE-adjusted annualized fixed pay, which differs from hourly pay, and no statutory figure is published on that basis; once populated they re-specify on hourly pay. "
               "Taxonomy gap: Payroll Result has no pay component breakdown, so bonus paid in the 12 months is taken from "
               "Award Grant Date, not payment date. Taxonomy gap: no EEO-1 establishment identifier (Work Location is used). Taxonomy gap: no training hours (ISO 30414). "
               "Decisions: CD-341, CD-344, CD-347, CD-364."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-207": dict(
        definition=("The firm's sites and their profile, space and its assignment to org units, measured occupancy and desk use, "
                    "leases with rent schedules, options and critical dates and their ASC 842 / IFRS 16 measurement, and site energy "
                    "use and the operational Scope 1, 2 and 3 emissions of the firm's own operations. It combines the 44 real "
                    "estate, lease and sustainability records with the 09 site key, DP-192 headcount by work location and DP-191 "
                    "ledger balances, so that Corporate Real Estate decides site strategy, renewals and space moves from one "
                    "record, the Controller ties lease balances to the ledger, and sustainability reporting takes own-operations "
                    "emissions from the same source."),
        business_questions=[
            "How much space and how many workstations do we hold per site, how many people work there, and how well is the space used?",
            "Which lease notice deadlines and break or renewal options fall in the next 180 days, and were any missed?",
            "What are our contracted rent commitments by entity and year, and what is rent per square foot or meter by site?",
            "Do lease liabilities and right-of-use assets from the lease measurements tie to the ledger for each entity and ledger?",
            "What were each site's energy use and renewable share, and what are the firm's Scope 1, Scope 2 (location- and market-based) and operational Scope 3 emissions by entity and year?",
            "Which space is unassigned and which desks are booked but not used?",
        ],
        grain="Site (09 SITE-) x month, with building space, space assignment, occupancy measurement, space reservation, lease, leased space, lease payment schedule line, lease option or critical date, lease accounting measurement, utility consumption record and operational emission record as child tables",
        dimensions=["Site and site type", "Tenure type", "Country and legal entity (DP-013)", "Building space and space level / type",
                    "Org unit and chargeback cost center", "Lease, lease role and lease status", "Landlord (DP-240)",
                    "Lease contract (DP-213)", "Lease option type", "Ledger and accounting basis (DP-190)",
                    "Utility resource", "GHG scope category and calculation method", "Reporting year", "Month"],
        measures=[
            ("Site Gross Area and Capacity", "Sum of Site Gross Area (in Site Area Unit) and Workstation Capacity of Site Profiles effective on the as-of date, by Site Type, Tenure Type and country.",
             [("44", "Site Profile", "Profiled Site"), ("44", "Site Profile", "Site Gross Area"), ("44", "Site Profile", "Site Area Unit"),
              ("44", "Site Profile", "Workstation Capacity"), ("44", "Site Profile", "Site Type"), ("44", "Site Profile", "Tenure Type"),
              ("44", "Site Profile", "Profile Effective From"), ("44", "Site Profile", "Profile Effective To"),
              ("09", "Office Location", "Office Country / Subdivision")]),
            ("Site Headcount", "DP-192 Certified Headcount with Work Location = the site at the month end; not recomputed.",
             [("20", "Employee", "Employee ID"), ("20", "Employee", "Work Location"), ("20", "Employee", "Employment Status")]),
            ("Area per Head", "Site Gross Area / Site Headcount per site at the month end.",
             ["Site Gross Area and Capacity", "Site Headcount"]),
            ("Desks per Head", "Workstation Capacity / Site Headcount per site at the month end.",
             ["Site Gross Area and Capacity", "Site Headcount"]),
            ("Average Utilization %", "Mean of Utilization Percentage of site-level Site Occupancy Measurements (Measured Space blank) over the business days of the month; Peak Occupancy % = maximum Peak Occupancy Count in the month / Workstation Capacity.",
             [("44", "Site Occupancy Measurement", "Measured Site"), ("44", "Site Occupancy Measurement", "Measured Space"),
              ("44", "Site Occupancy Measurement", "Occupancy Measurement Date"), ("44", "Site Occupancy Measurement", "Utilization Percentage"),
              ("44", "Site Occupancy Measurement", "Peak Occupancy Count"), ("44", "Site Occupancy Measurement", "Attendance Count"),
              "Site Gross Area and Capacity"]),
            ("Booking No-Show Rate %", "Space Reservations with Reservation End in the month and Checked In Indicator = N / all Space Reservations ending in the month, by site and Space Type.",
             [("44", "Space Reservation", "Reserved Space"), ("44", "Space Reservation", "Reservation End"),
              ("44", "Space Reservation", "Checked In Indicator"), ("44", "Building Space", "Space Type")]),
            ("Unassigned Space %", "Space Area of Building Spaces at the lowest Space Level of each site with no Space Assignment effective on the as-of date / total Space Area at that level, excluding Space Type in (Circulation, Plant Room, Reception).",
             [("44", "Building Space", "Space ID"), ("44", "Building Space", "Space Site"), ("44", "Building Space", "Space Level"),
              ("44", "Building Space", "Space Area"), ("44", "Building Space", "Space Type"), ("44", "Space Assignment", "Assigned Space"),
              ("44", "Space Assignment", "Assignment Effective From"), ("44", "Space Assignment", "Assignment Effective To")]),
            ("Assigned Area by Cost Center", "Sum of Space Area of spaces with an effective Space Assignment, by Assigned Org Unit and Chargeback Cost Center, the basis for occupancy chargeback.",
             [("44", "Space Assignment", "Assigned Org Unit"), ("44", "Space Assignment", "Chargeback Cost Center"),
              ("44", "Building Space", "Space Area")]),
            ("Contracted Rent Commitment", "Sum of Scheduled Payment Amount of Lease Payment Schedule Lines with Payment Period Start after the as-of date for Leases with Lease Status active, by Firm Legal Entity, Lease Currency, Lease Charge Type and calendar year, undiscounted; Sublease Income shown separately.",
             [("44", "Lease Payment Schedule Line", "Schedule Lease"), ("44", "Lease Payment Schedule Line", "Scheduled Payment Amount"),
              ("44", "Lease Payment Schedule Line", "Payment Period Start"), ("44", "Lease Payment Schedule Line", "Lease Charge Type"),
              ("44", "Lease", "Lease Status"), ("44", "Lease", "Firm Legal Entity"), ("44", "Lease", "Lease Currency")]),
            ("Base Rent per Area", "Per lease and site: Scheduled Payment Amount with Lease Charge Type = Base Rent for the 12 months from the as-of date / Contractual Rentable Area of its effective Leased Space.",
             [("44", "Lease Payment Schedule Line", "Scheduled Payment Amount"), ("44", "Lease Payment Schedule Line", "Lease Charge Type"),
              ("44", "Lease Payment Schedule Line", "Payment Period Start"), ("44", "Leased Space", "Space Lease"),
              ("44", "Leased Space", "Contractual Rentable Area"), ("44", "Leased Space", "Leased Site")]),
            ("Critical Dates Due (180 Days)", "Count of Lease Options & Critical Dates with Notice Deadline Date between the as-of date and 180 days after it and no Exercise Decision Date, by Lease Option Type and site.",
             [("44", "Lease Option & Critical Date", "Option Lease"), ("44", "Lease Option & Critical Date", "Lease Option Type"),
              ("44", "Lease Option & Critical Date", "Notice Deadline Date"), ("44", "Lease Option & Critical Date", "Exercise Decision Date")]),
            ("Missed Notice Deadlines", "Count of Lease Options & Critical Dates with Notice Deadline Date before the as-of date, no Exercise Decision Date and Option Exercised Indicator blank, on Leases with Lease Status active.",
             [("44", "Lease Option & Critical Date", "Notice Deadline Date"), ("44", "Lease Option & Critical Date", "Exercise Decision Date"),
              ("44", "Lease Option & Critical Date", "Option Exercised Indicator"), ("44", "Lease", "Lease Status")]),
            ("Weighted Average Lease Term Remaining", "Sum over active Lessee leases of (Lease Expiry Date - as-of date, in years) x Contractual Rentable Area / total Contractual Rentable Area, by entity and country; leases expiring within 12 and 24 months counted separately.",
             [("44", "Lease", "Lease Expiry Date"), ("44", "Lease", "Lease Role"), ("44", "Lease", "Lease Status"),
              ("44", "Leased Space", "Contractual Rentable Area")]),
            ("Lease Liability and ROU Asset", "Per lease and Measurement Ledger: Lease Liability Amount and Right-of-Use Asset Amount of the latest Lease Accounting Measurement on or before the month end, summed by Firm Legal Entity, ledger and Lease Classification; leases with Recognition Exemption other than None excluded.",
             [("44", "Lease Accounting Measurement", "Measured Lease"), ("44", "Lease Accounting Measurement", "Measurement Ledger"),
              ("44", "Lease Accounting Measurement", "Lease Measurement Date"), ("44", "Lease Accounting Measurement", "Lease Liability Amount"),
              ("44", "Lease Accounting Measurement", "Right-of-Use Asset Amount"), ("44", "Lease Accounting Measurement", "Lease Classification"),
              ("44", "Lease Accounting Measurement", "Recognition Exemption"), ("44", "Lease", "Firm Legal Entity")]),
            ("Active Leases Without Measurement", "Count of Leases with Lease Status active, Lease Role = Lessee and Lease Commencement Date on or before the month end that have no Lease Accounting Measurement for each primary ledger of the Firm Legal Entity.",
             [("44", "Lease", "Lease ID"), ("44", "Lease", "Lease Commencement Date"), ("44", "Lease", "Lease Role"),
              ("44", "Lease Accounting Measurement", "Measured Lease"), ("44", "Lease Accounting Measurement", "Measurement Ledger")]),
            ("Lease Balance to GL Difference", "Per ledger and fiscal period: Lease Liability and ROU Asset totals - Closing Balance of GL Account Balances (Balance Type = Actual) on the lease liability and right-of-use asset accounts the Controller designates, from DP-191.",
             [("19", "GL Account Balance", "Balance Ledger"), ("19", "GL Account Balance", "Balance GL Account"),
              ("19", "GL Account Balance", "Balance Fiscal Period"), ("19", "GL Account Balance", "Balance Type"),
              ("19", "GL Account Balance", "Closing Balance"), "Lease Liability and ROU Asset"]),
            ("Energy Consumption and Renewable Share", "Sum of Consumption Quantity by Consumption Site, Utility Resource and Consumption Unit for records whose consumption period falls in the month (prorated by days where it spans months); renewable share = sum(Consumption Quantity x Renewable Share) / sum(Consumption Quantity) for Electricity; share estimated = quantity with Consumption Data Basis estimated / total.",
             [("44", "Utility Consumption Record", "Consumption Site"), ("44", "Utility Consumption Record", "Utility Resource"),
              ("44", "Utility Consumption Record", "Consumption Quantity"), ("44", "Utility Consumption Record", "Consumption Unit"),
              ("44", "Utility Consumption Record", "Consumption Period Start"), ("44", "Utility Consumption Record", "Consumption Period End"),
              ("44", "Utility Consumption Record", "Renewable Share"), ("44", "Utility Consumption Record", "Consumption Data Basis")]),
            ("Energy Intensity per Area", "Energy consumption (Electricity, Natural Gas, District Heating, District Cooling, Fuel Oil / Diesel, converted to kWh) per site per year / Site Gross Area.",
             ["Energy Consumption and Renewable Share", "Site Gross Area and Capacity"]),
            ("Operational Emissions", "Sum of Emissions tCO2e of Operational Emission Records with Emission Record Level = Entity Total, by Emission Reporting Entity, Reporting Year, GHG Scope Category and Calculation Method; Scope 2 location-based and market-based are reported side by side, never added.",
             [("44", "Operational Emission Record", "Emission Reporting Entity"), ("44", "Operational Emission Record", "Emission Record Level"),
              ("44", "Operational Emission Record", "Reporting Year"), ("44", "Operational Emission Record", "GHG Scope Category"),
              ("44", "Operational Emission Record", "Calculation Method"), ("44", "Operational Emission Record", "Emissions tCO2e")]),
            ("Emissions per Employee", "(Scope 1 + Scope 2 market-based Operational Emissions) / DP-192 Certified Headcount of the entity at the reporting year end.",
             ["Operational Emissions", "Site Headcount"]),
            ("Site-to-Entity Emission Difference", "Per entity, year, scope category and method: sum of Emissions tCO2e of Site rows - Entity Total row; non-zero differences are explained by emissions not allocated to a site.",
             [("44", "Operational Emission Record", "Emission Site"), ("44", "Operational Emission Record", "Emission Record Level"),
              ("44", "Operational Emission Record", "Emissions tCO2e"), "Operational Emissions"]),
        ],
        inputs=[
            ("44", "Site Profile", ["Profiled Site", "Site Type", "Tenure Type", "Site Gross Area", "Site Area Unit", "Workstation Capacity",
                                    "Building Certification", "FINRA Branch Office Indicator", "Profile Effective From", "Profile Effective To"]),
            ("44", "Building Space", ["Space ID", "Space Site", "Parent Space", "Space Level", "Space Type", "Space Area", "Space Capacity"]),
            ("44", "Space Assignment", ["Assigned Space", "Assigned Org Unit", "Chargeback Cost Center", "Assignment Effective From",
                                        "Assignment Effective To"]),
            ("44", "Site Occupancy Measurement", ["Measured Site", "Measured Space", "Occupancy Measurement Date", "Attendance Count",
                                                  "Peak Occupancy Count", "Utilization Percentage"]),
            ("44", "Space Reservation", ["Reserved Space", "Reservation Start", "Reservation End", "Checked In Indicator"]),
            ("44", "Lease", ["Lease ID", "Lease Role", "Lease Counterparty", "Firm Legal Entity", "Head Lease", "Lease Contract",
                             "Lease Commencement Date", "Lease Expiry Date", "Rent-Free Period Months", "Lease Currency", "Lease Status"]),
            ("44", "Leased Space", ["Space Lease", "Leased Site", "Leased Building Space", "Contractual Rentable Area",
                                    "Leased Space Effective From", "Leased Space Effective To"]),
            ("44", "Lease Payment Schedule Line", ["Schedule Lease", "Lease Charge Type", "Payment Period Start", "Payment Period End",
                                                   "Scheduled Payment Amount", "Escalation Basis", "Variable Payment Indicator"]),
            ("44", "Lease Option & Critical Date", ["Option Lease", "Lease Option Type", "Notice Deadline Date", "Option Effective Date",
                                                    "Option Term Months", "Option Penalty Amount", "Option Exercised Indicator",
                                                    "Exercise Decision Date"]),
            ("44", "Lease Accounting Measurement", ["Measured Lease", "Measurement Ledger", "Lease Measurement Date", "Lease Classification",
                                                    "Recognition Exemption", "Discount Rate", "Assessed Lease Term Months",
                                                    "Right-of-Use Asset Amount", "Lease Liability Amount", "Remeasurement Reason"]),
            ("44", "Utility Consumption Record", ["Consumption Site", "Meter Identifier", "Utility Resource", "Consumption Period Start",
                                                  "Consumption Period End", "Consumption Quantity", "Consumption Unit", "Renewable Share",
                                                  "Consumption Data Basis", "Source Utility Invoice"]),
            ("44", "Operational Emission Record", ["Emission Reporting Entity", "Emission Site", "Emission Record Level", "Reporting Year",
                                                   "GHG Scope Category", "Calculation Method", "Emissions tCO2e", "Activity Quantity",
                                                   "Activity Unit", "Emission Factor Source", "Emission Factor Version",
                                                   "Emission Data Basis", "Assurance Level", "Reported Indicator"]),
            ("09", "Office Location", ["Office ID", "Office Country / Subdivision", "Office Legal Entity"]),
            ("20", "Employee", ["Employee ID", "Work Location", "Employment Status"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Closing Balance"]),
        ],
        upstream=["DP-013", "DP-190", "DP-191", "DP-192", "DP-240", "DP-213"],
        refresh="Daily",
        timeliness="Occupancy and reservations by 8am local time on T+1; leases, critical dates and space monthly by business day 3 after month-end; lease balance tie-out after the ledger period hard close; emissions annually, with quarterly estimates by business day 20 after quarter-end",
        history="Site profiles, spaces, assignments and leases SCD type 2 for the life of the site or lease plus 7 years; daily occupancy kept 3 years and monthly aggregates 10 years; every lease measurement and every reporting year's emission records kept 10 years, with restated years versioned",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Site Profile, Building Space, Leased Space, Utility Consumption Record and site-level Operational Emission Record references an active 09 Office Location (SITE-) published by DP-013.",
            "Every Lease with Lease Status active has Lease Commencement Date before Lease Expiry Date, at least one effective Leased Space and at least one Base Rent schedule line, unless Lease Role = Sublessor.",
            "Every Operational Emission Record of Emission Record Level = Entity Total is unique per Emission Reporting Entity, Reporting Year, GHG Scope Category and Calculation Method.",
            "Scope 2 rows exist for both Location-Based and Market-Based calculation methods for every entity and reporting year with Electricity consumption.",
            "Lease Balance to GL Difference is zero for every primary ledger at each hard-closed period end, or carries an explanation from the Controller.",
            "Site Occupancy Measurement Utilization Percentage is between 0 and 100% when Peak Occupancy Count does not exceed Workstation Capacity.",
        ],
        notes=("Certified numbers: none owned. Headcount by work location is DP-192's Certified Headcount (CD-341); lease journals and "
               "balances are DP-191's, and this product compares the lease measurements with them rather than restating expense. "
               "09 keeps the SITE- key (CD-279); Site Profile never repeats country, time zone or legal entity, which come from "
               "DP-013. Lease Accounting Measurement rows are produced by the 19 Controller (CD-279) and move to 19 unchanged if "
               "lease accounting runs in the ERP (44 SME Q2), when this product would read them through DP-193. Landlords (Lease "
               "Counterparty, a 02 party that can be an individual, hence PII = Y) resolve through DP-240; lease documents (Lease "
               "Contract) through DP-213. Financed emissions are 34 (CD-281); 34 own-operations indicators are derived copies of the "
               "Entity Total rows here (Reported Indicator), and 42 Corporate Publication publishes them by reference. Business "
               "travel emissions (Scope 3 Category 6) are Operational Emission Record rows; their activity data comes from DP-209 "
               "Travel Booking Air Distance and spend. Space Reservation Booker is not read, so the occupancy view carries no names. "
               "Operating model: facilities and occupancy data are often supplied by an integrated facilities provider or IWMS "
               "vendor; the grain does not change. CD-345: if the client drops 44, this product is withdrawn; Lease Accounting "
               "Measurement moves to 19 and is read by DP-193. Open SME questions (44 Q1, Q2, Q6, Q7, Q8): whether an IWMS holds "
               "this data and whether 44 is kept; where lease accounting runs; whether occupancy is measured per person or only in "
               "aggregate; which entities fall under SB 253, CSRD and UK SECR; whether company vehicles are in scope. Taxonomy gap: "
               "no attribute designates the GL accounts that hold lease liabilities and right-of-use assets (19 Financial Statement "
               "Class combines fixed and right-of-use assets), so Lease Balance to GL Difference uses an account list the Controller "
               "maintains outside the taxonomy. Taxonomy gap: no energy unit conversion factors, so Energy Intensity per Area relies "
               "on 09 Unit of Measure conversions applied outside the taxonomy. Decisions: CD-279, CD-281, CD-297, CD-341, CD-345."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-208": dict(
        definition=("Facility assets, planned maintenance and work orders against SLA, access badges and zone grants reconciled to "
                    "employee status, visitors, physical security and health and safety incidents, workplace risk assessments and "
                    "emergency role cover by site. It combines the 44 workplace service, security and safety records with DP-192 "
                    "employment status and lifecycle events and 20 learning completions, so that Workplace Services evidences that "
                    "leavers lose physical access promptly, that statutory maintenance and OSHA recording and reporting are done on "
                    "time, and that every site has certified emergency roles. It holds two FN-48 decisions in one product because "
                    "both are run at site grain."),
        business_questions=[
            "Which leavers and expired contractors still hold an active badge or zone grant, and how quickly are leaver badges deactivated?",
            "Is statutory planned maintenance up to date at every site, and what share of work orders is completed within SLA by priority and vendor?",
            "How many OSHA recordable incidents and OSHA fatality or severe injury reports did we have by site, were they reported on time, and what is the recordable incident rate?",
            "Does every site and floor have a certified fire warden and first aider in post today?",
            "Which workplace risk assessments are past their review date, and which visitors have no departure record?",
            "What physical security incidents occurred by site, type and severity, and which are still open?",
        ],
        grain="Site (09 SITE-) x day for the control measures, with facility asset, maintenance schedule, work order, access badge, zone grant, visit, physical security incident, health and safety incident, risk assessment and emergency role assignment as event-level child tables",
        dimensions=["Site and floor", "Day and month", "Facility asset class", "Maintenance task type and statutory requirement",
                    "Work order type and priority", "Maintenance vendor (DP-210)", "Badge type and status", "Access zone",
                    "Employee and employment status (DP-192)", "Incident type, severity and injury outcome (restricted view)",
                    "Risk assessment type", "Emergency role"],
        measures=[
            ("Overdue Statutory Maintenance", "Count of Planned Maintenance Schedules with Statutory Requirement populated and Next Due Date before the as-of date, by site, Facility Asset Class and Maintenance Vendor; statutory compliance % = statutory schedules not overdue / statutory schedules on assets with Facility Asset Status active.",
             [("44", "Planned Maintenance Schedule", "Maintained Asset"), ("44", "Planned Maintenance Schedule", "Statutory Requirement"),
              ("44", "Planned Maintenance Schedule", "Next Due Date"), ("44", "Planned Maintenance Schedule", "Maintenance Vendor"),
              ("44", "Facility Asset", "Facility Asset Tag"), ("44", "Facility Asset", "Facility Asset Class"),
              ("44", "Facility Asset", "Asset Site"), ("44", "Facility Asset", "Facility Asset Status")]),
            ("Work Orders Within SLA %", "Facility Work Orders with Completed Timestamp in the period and Completed Timestamp <= SLA Completion Due Timestamp / Work Orders completed in the period, by Work Order Priority, Work Order Type, site and Assigned Vendor.",
             [("44", "Facility Work Order", "Work Order ID"), ("44", "Facility Work Order", "Completed Timestamp"),
              ("44", "Facility Work Order", "SLA Completion Due Timestamp"), ("44", "Facility Work Order", "Work Order Priority"),
              ("44", "Facility Work Order", "Work Order Type"), ("44", "Facility Work Order", "Work Order Site"),
              ("44", "Facility Work Order", "Assigned Vendor")]),
            ("Open Work Orders Past SLA", "Count of Facility Work Orders with no Completed Timestamp and SLA Completion Due Timestamp before the as-of timestamp, by priority and site.",
             [("44", "Facility Work Order", "Completed Timestamp"), ("44", "Facility Work Order", "SLA Completion Due Timestamp"),
              ("44", "Facility Work Order", "Work Order Status"), ("44", "Facility Work Order", "Work Order Priority")]),
            ("Leavers With Active Badge", "Count of Access Badges with Badge Status = Active whose Badge Holder has Employment Status = Terminated and Termination Date before the as-of date, or is a contingent worker whose Engagement End Date is before the as-of date.",
             [("44", "Access Badge", "Badge ID"), ("44", "Access Badge", "Badge Holder"), ("44", "Access Badge", "Badge Status"),
              ("20", "Employee", "Employment Status"), ("20", "Employee", "Termination Date"),
              ("20", "Contingent Worker Detail", "Engagement End Date")]),
            ("Leaver Badges Deactivated by Event %", "Badges of holders with a Termination lifecycle event in the period that have Badge Status = Deactivated and Deactivating Lifecycle Event = that Termination event / all badges of those holders that were Active on the day before the Event Effective Date.",
             [("44", "Access Badge", "Badge Status"), ("44", "Access Badge", "Deactivating Lifecycle Event"), ("44", "Access Badge", "Badge Holder"),
              ("20", "Employee Lifecycle Event", "Lifecycle Event ID"), ("20", "Employee Lifecycle Event", "Event Employee"),
              ("20", "Employee Lifecycle Event", "Lifecycle Event Type"), ("20", "Employee Lifecycle Event", "Event Effective Date")]),
            ("Restricted Zone Grants Without Approver", "Count of Physical Access Zone Grants effective on the as-of date with Access Zone not General Office and Grant Approver blank, or Grant Approver = the badge's Badge Holder.",
             [("44", "Physical Access Zone Grant", "Granted Badge"), ("44", "Physical Access Zone Grant", "Access Zone"),
              ("44", "Physical Access Zone Grant", "Grant Approver"), ("44", "Physical Access Zone Grant", "Grant Effective From"),
              ("44", "Physical Access Zone Grant", "Grant Effective To"), ("44", "Access Badge", "Badge Holder")]),
            ("Visits Without Departure", "Count of Visitor Registrations with Arrival Timestamp before the start of the as-of day and no Departure Timestamp, by Visited Site and Host Employee's org unit.",
             [("44", "Visitor Registration", "Visit Reference"), ("44", "Visitor Registration", "Visited Site"),
              ("44", "Visitor Registration", "Arrival Timestamp"), ("44", "Visitor Registration", "Departure Timestamp"),
              ("44", "Visitor Registration", "Host Employee")]),
            ("Physical Security Incidents", "Count of Physical Security Incidents with Security Incident Occurred Timestamp in the period, by Security Incident Site, Physical Incident Type and Security Incident Severity; open = Security Incident Status not closed.",
             [("44", "Physical Security Incident", "Security Incident Reference"), ("44", "Physical Security Incident", "Security Incident Site"),
              ("44", "Physical Security Incident", "Physical Incident Type"), ("44", "Physical Security Incident", "Security Incident Severity"),
              ("44", "Physical Security Incident", "Security Incident Occurred Timestamp"), ("44", "Physical Security Incident", "Security Incident Status")]),
            ("Recordable and Reportable Incidents", "Count of Health & Safety Incidents with H&S Incident Occurred Timestamp in the period with OSHA Recordable Indicator = Y, and with a Regulatory Report Date (reported to OSHA or the state plan agency as a fatality or severe injury), by site, H&S Incident Type and Injury Outcome; lost days = sum of Days Away From Work.",
             [("44", "Health & Safety Incident", "H&S Incident ID"), ("44", "Health & Safety Incident", "H&S Incident Occurred Timestamp"),
              ("44", "Health & Safety Incident", "OSHA Recordable Indicator"), ("44", "Health & Safety Incident", "Regulatory Report Date"),
              ("44", "Health & Safety Incident", "H&S Incident Site"), ("44", "Health & Safety Incident", "H&S Incident Type"),
              ("44", "Health & Safety Incident", "Injury Outcome"), ("44", "Health & Safety Incident", "Days Away From Work")]),
            ("Late OSHA Severe Injury Reports", "Count of incidents with Injury Outcome = Death whose Regulatory Report Date is blank or more than one calendar day after H&S Incident Occurred Timestamp (29 CFR 1904.39: 8 hours for a fatality), plus incidents with a Regulatory Report Date more than one calendar day after the occurrence (24 hours for an in-patient hospitalization, amputation or loss of an eye).",
             [("44", "Health & Safety Incident", "Regulatory Report Date"),
              ("44", "Health & Safety Incident", "H&S Incident Occurred Timestamp"), ("44", "Health & Safety Incident", "Injury Outcome"),
              ("44", "Health & Safety Incident", "H&S Incident Type")]),
            ("Recordable Incident Rate", "OSHA recordable incidents of US sites in the period x 200,000 / (average DP-192 Certified FTE of workers whose Work Location is a US site x 2,000 x months in period / 12).",
             [("20", "Employee Job Assignment", "Assignment FTE"), ("20", "Employee Job Assignment", "Assignment Type"),
              ("20", "Employee Job Assignment", "Assigned Worker"), ("20", "Employee", "Work Location"),
              "Recordable and Reportable Incidents"]),
            ("Risk Assessments Overdue", "Count of the latest Workplace Risk Assessment per site (or workstation) and Risk Assessment Type whose Next Review Date is before the as-of date, by type and Overall Risk Rating.",
             [("44", "Workplace Risk Assessment", "Risk Assessment Reference"), ("44", "Workplace Risk Assessment", "Risk Assessment Type"),
              ("44", "Workplace Risk Assessment", "Assessed Site"), ("44", "Workplace Risk Assessment", "Assessed Workstation"),
              ("44", "Workplace Risk Assessment", "Assessment Date"), ("44", "Workplace Risk Assessment", "Next Review Date"),
              ("44", "Workplace Risk Assessment", "Overall Risk Rating")]),
            ("Emergency Role Gaps", "Count of site and floor combinations (every Emergency Role Floor recorded for an active site) with no Emergency Role Assignment for Fire Warden or First Aider effective on the as-of date whose Role Holder is employed and whose Certifying Learning Completion has Completion Status = Completed.",
             [("44", "Emergency Role Assignment", "Role Holder"), ("44", "Emergency Role Assignment", "Emergency Role"),
              ("44", "Emergency Role Assignment", "Emergency Role Site"), ("44", "Emergency Role Assignment", "Emergency Role Floor"),
              ("44", "Emergency Role Assignment", "Certifying Learning Completion"), ("44", "Emergency Role Assignment", "Emergency Role Effective From"),
              ("44", "Emergency Role Assignment", "Emergency Role Effective To"), ("20", "Learning Completion", "Completion Status"),
              ("20", "Employee", "Employment Status")]),
            ("Emergency Role Holders Who Have Left", "Count of Emergency Role Assignments effective on the as-of date whose Role Holder has Employment Status = Terminated or whose Work Location is not the Emergency Role Site.",
             [("44", "Emergency Role Assignment", "Role Holder"), ("44", "Emergency Role Assignment", "Emergency Role Site"),
              ("20", "Employee", "Employment Status"), ("20", "Employee", "Work Location")]),
        ],
        inputs=[
            ("44", "Facility Asset", ["Facility Asset Tag", "Facility Asset Class", "Asset Site", "Asset Location Space", "Install Date",
                                      "Fixed Asset Number", "Asset Lease", "Facility Asset Status"]),
            ("44", "Planned Maintenance Schedule", ["Maintained Asset", "Maintenance Task Type", "Maintenance Frequency",
                                                    "Statutory Requirement", "Maintenance Vendor", "Next Due Date"]),
            ("44", "Facility Work Order", ["Work Order ID", "Work Order Type", "Work Order Priority", "Work Order Site", "Work Order Space",
                                           "Work Order Asset", "Assigned Vendor", "SLA Completion Due Timestamp", "Completed Timestamp",
                                           "Work Order Status", "Vendor Invoice", "Work Order Purchase Order"]),
            ("44", "Access Badge", ["Badge ID", "Badge Type", "Badge Holder", "Badge Visit", "Badge Expiry Date", "Badge Status",
                                    "Deactivating Lifecycle Event"]),
            ("44", "Physical Access Zone Grant", ["Granted Badge", "Access Zone", "Zone Site", "Zone Space", "Grant Approver",
                                                  "Grant Effective From", "Grant Effective To"]),
            ("44", "Visitor Registration", ["Visit Reference", "Visited Site", "Host Employee", "Visitor Party", "Visit Purpose",
                                            "Arrival Timestamp", "Departure Timestamp"]),
            ("44", "Physical Security Incident", ["Security Incident Reference", "Security Incident Site", "Physical Incident Type",
                                                  "Security Incident Occurred Timestamp", "Security Incident Severity", "Involved Badge",
                                                  "Security Incident Status"]),
            ("44", "Health & Safety Incident", ["H&S Incident ID", "H&S Incident Type", "Injury Outcome", "H&S Incident Site",
                                                "H&S Incident Occurred Timestamp", "Affected Employee", "OSHA Recordable Indicator",
                                                "Regulatory Report Date", "Days Away From Work"]),
            ("44", "Workplace Risk Assessment", ["Risk Assessment Reference", "Risk Assessment Type", "Assessed Site", "Assessed Workstation",
                                                 "Assessment Date", "Overall Risk Rating", "Next Review Date"]),
            ("44", "Emergency Role Assignment", ["Role Holder", "Emergency Role", "Emergency Role Site", "Emergency Role Floor",
                                                 "Certifying Learning Completion", "Emergency Role Effective From",
                                                 "Emergency Role Effective To"]),
            ("20", "Employee", ["Employee ID", "Work Location", "Employment Status", "Termination Date"]),
            ("20", "Contingent Worker Detail", ["Contingent Worker Type", "Engagement End Date"]),
            ("20", "Employee Lifecycle Event", ["Lifecycle Event ID", "Event Employee", "Lifecycle Event Type", "Event Effective Date"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assignment Type", "Assignment FTE"]),
            ("20", "Learning Completion", ["Learner Employee", "Completed Learning Item", "Completion Status", "Completion Date"]),
        ],
        upstream=["DP-192", "DP-013", "DP-210"],
        refresh="Daily",
        timeliness="Badge and leaver reconciliation by 7am local site time each day, after DP-192's leaver events (published within one hour of HRIS approval); work orders, visits and incidents by 8am local time on T+1; monthly safety statistics by business day 5 after month-end",
        history="Badges, zone grants and emergency role assignments SCD type 2 for the employment record retention period; visitor records kept for the visitor log retention period (SME question 5); health and safety incidents kept at least 5 years (OSHA 300 log, 29 CFR 1904.33); work orders and maintenance history kept for the life of the asset plus 7 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Access Badge with Badge Type Employee or Contingent Worker has a Badge Holder that resolves to a DP-192 worker, and every badge with Badge Status = Deactivated after a termination references that Termination lifecycle event.",
            "Every Facility Work Order with Work Order Status completed has a Completed Timestamp, and every open work order has an SLA Completion Due Timestamp.",
            "Every Health & Safety Incident with Injury Outcome in (Death, Days Away From Work, Job Transfer or Restriction, Other Recordable Case) at a US site has OSHA Recordable Indicator = Y.",
            "Every Emergency Role Assignment references a Certifying Learning Completion whose Learner Employee is the Role Holder.",
            "No Physical Access Zone Grant is effective after the Badge Expiry Date of its Granted Badge.",
        ],
        notes=("Certified numbers: none owned; FTE for the incident rate is DP-192's Certified FTE (CD-341). Personal data tiers "
               "(CD-344): the product is Confidential - Personal Data; Health & Safety Incident rows (special category health data) "
               "are published only in a Restricted - Personal Data view for Health & Safety and HR, and the wide view carries site "
               "counts without Affected Employee, Injury Description or Affected Non-Employee Name (the last two are not read). "
               "Visitor Name is not read; casual visitors are not 02 parties (CD-280), and a known visitor is a Visitor Party key. "
               "37 Operational Incident references these incidents (CD-266, CD-280) and this product does not read 37. IT assets and "
               "anything in the 41 CMDB are never Facility Assets (CD-279). Maintenance Vendor and Assigned Vendor resolve to the "
               "supplier engagement in DP-210. Emergency role certifications are 20 Learning Completions, the record DP-200 "
               "publishes; they are read by key here. Operating model (CD-297; brief Q5): drafted at the in-house operational grain. "
               "If an integrated facilities provider runs maintenance, Facility Work Order and Planned Maintenance Schedule become the "
               "provider's SLA and work-order feed (oversight grain) and SLA measures become provider oversight measures; badges, "
               "incidents and risk assessments stay firm records. CD-345: if the client drops 44, this product is withdrawn. Open "
               "SME questions (44 Q5, Q6, Q8): visitor log retention and which visitors are parties; whether occupancy may be "
               "measured per person; company vehicles. Taxonomy gap: Access Badge has no deactivation timestamp, so deactivation "
               "speed in hours cannot be measured; the control is tested at day grain. Taxonomy gap: there are no hours worked, so "
               "the OSHA incident rate uses Certified FTE x 2,000 hours, an approximation of the OSHA formula. Taxonomy gap: no "
               "required emergency role ratio per site or floor (fire warden and first aider minimums depend on occupancy and the "
               "first-aid needs assessment), so Emergency Role Gaps tests at least one of each per floor; Learning Completion also "
               "has no expiry date, so certificate expiry is not tested. Taxonomy gap: Health & Safety Incident has no severe injury indicator (in-patient hospitalization, amputation, loss of an eye), so Late OSHA Severe Injury Reports tests missing reports for deaths only and lateness for the incidents reported. Decisions: CD-266, CD-279, CD-280, CD-297, CD-341, CD-344, CD-345. "
               "W1b re-point (CW-944): Health & Safety Incident.RIDDOR Reportable Indicator dropped (removed); the re-sourced Regulatory Report Date (OSHA or state plan fatality or severe injury report) carries the reportable fact, so Recordable and Reportable Incidents counts reported incidents by that date and Late RIDDOR Reports is rewritten as Late OSHA Severe Injury Reports (29 CFR 1904.39)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-209": dict(
        definition=("Expense reports and lines, corporate card transactions and travel bookings by employee, cost owner org unit, "
                    "expense type and period, tested against the expense policy limits, with reimbursement status, ledger posting "
                    "and recharges to funds. It combines the 44 travel and expense records with DP-192 employees, job levels and "
                    "reporting lines, DP-191 postings and the 08 gifts and entertainment register, so that the Finance Controller "
                    "enforces expense policy, reconciles corporate cards and controls T&E cost, and compliance can see every "
                    "entertainment line tied to its gifts and entertainment record. T&E spend here is an operational measure that "
                    "reconciles to DP-191; it is never certified expense."),
        business_questions=[
            "What did we spend on travel and entertainment this month by expense type, cost owner org unit and employee, and how does it compare with prior periods?",
            "Which expense lines exceed the policy limit for their type, location band and job level, and what share of spend is out of policy?",
            "Which reports were approved by the claimant or by someone other than the claimant's line management chain?",
            "Which card transactions are unmatched after 30 and 60 days, how much personal spend is on corporate cards, and which leavers still hold an active card?",
            "Which client entertainment and gift lines have no gifts and entertainment record, and what was recharged to which funds?",
            "Does approved T&E posted to the ledger tie to the T&E journals for the period?",
        ],
        grain="Expense line (expense report x line number), with expense report, card transaction, corporate card, travel booking (trip) and expense policy limit as related tables; aggregated by claimant x cost owner org unit x expense type x month",
        dimensions=["Month and fiscal period", "Claimant (employee) and job level", "Cost owner org unit", "Employing legal entity",
                    "Expense type", "Merchant category code", "Expense approval status and reimbursement route",
                    "Corporate card and issuer", "Trip, destination country and travel class", "Recharge fund (DP-004)",
                    "Policy location band"],
        measures=[
            ("T&E Spend", "Sum of Transaction Amount of Expense Lines on Expense Reports with Expense Approval Status = Approved, by Expense Date month, Expense Type, Cost Owner Org Unit and claimant; an operational measure reconciled to DP-191, not certified expense.",
             [("44", "Expense Line", "Line Expense Report"), ("44", "Expense Line", "Transaction Amount"), ("44", "Expense Line", "Expense Type"),
              ("44", "Expense Line", "Expense Date"), ("44", "Expense Report", "Expense Approval Status"),
              ("44", "Expense Report", "Cost Owner Org Unit"), ("44", "Expense Report", "Claimant")]),
            ("Out-of-Policy Lines", "Count and Transaction Amount of Expense Lines whose Transaction Amount (per night for Hotel / Lodging, per day for Meals - Travel) exceeds the Limit Amount, or Per Diem Rate where set, of the Expense Policy Limit effective on the Expense Date for the same Expense Type (Limited Expense Type), the claimant's Location Band and the Job Level of the claimant's primary Job Profile (Applicable Job Level).",
             [("44", "Expense Line", "Transaction Amount"), ("44", "Expense Line", "Expense Type"), ("44", "Expense Line", "Expense Date"),
              ("44", "Expense Policy Limit", "Limited Expense Type"), ("44", "Expense Policy Limit", "Location Band"),
              ("44", "Expense Policy Limit", "Applicable Job Level"), ("44", "Expense Policy Limit", "Limit Amount"),
              ("44", "Expense Policy Limit", "Per Diem Rate"), ("44", "Expense Policy Limit", "Limit Effective From"),
              ("44", "Expense Policy Limit", "Limit Effective To"), ("20", "Job Profile", "Job Level"),
              ("20", "Employee Job Assignment", "Assigned Job Profile"), ("20", "Employee Job Assignment", "Assignment Type")]),
            ("Out-of-Policy Spend %", "Transaction Amount of Out-of-Policy Lines / T&E Spend, by org unit and Expense Type.",
             ["Out-of-Policy Lines", "T&E Spend"]),
            ("Self-Approved or Off-Chain Reports", "Count of Expense Reports with Expense Approval Status = Approved whose Expense Approver = Claimant, or whose Expense Approver is not in the claimant's chain of Solid-Line Manager reporting lines effective on the approval.",
             [("44", "Expense Report", "Expense Approver"), ("44", "Expense Report", "Claimant"), ("44", "Expense Report", "Expense Approval Status"),
              ("20", "Employee Reporting Line", "Reporting Employee"), ("20", "Employee Reporting Line", "Line Manager"),
              ("20", "Employee Reporting Line", "Reporting Line Type"), ("20", "Employee Reporting Line", "Reporting Effective From"),
              ("20", "Employee Reporting Line", "Reporting Effective To")]),
            ("Unmatched Card Transactions", "Count and Billed Amount of Card Transactions with Personal Spend Indicator not Y that no Expense Line references as Matched Card Transaction, by age since Card Posting Date (over 30 days, over 60 days) and cardholder.",
             [("44", "Card Transaction", "Transaction Card"), ("44", "Card Transaction", "Issuer Transaction Reference"),
              ("44", "Card Transaction", "Card Posting Date"), ("44", "Card Transaction", "Billed Amount"),
              ("44", "Card Transaction", "Personal Spend Indicator"), ("44", "Expense Line", "Matched Card Transaction"),
              ("44", "Corporate Card", "Cardholder")]),
            ("Personal Spend on Corporate Cards", "Sum of Billed Amount of Card Transactions with Personal Spend Indicator = Y, by cardholder and month.",
             [("44", "Card Transaction", "Billed Amount"), ("44", "Card Transaction", "Personal Spend Indicator"), ("44", "Card Transaction", "Card Posting Date")]),
            ("Active Cards of Leavers", "Count of Corporate Cards with Card Status = Active whose Cardholder has Employment Status = Terminated and Termination Date before the as-of date.",
             [("44", "Corporate Card", "Card Account ID"), ("44", "Corporate Card", "Card Status"), ("44", "Corporate Card", "Cardholder"),
              ("20", "Employee", "Employment Status"), ("20", "Employee", "Termination Date")]),
            ("Potential Duplicate Claims", "Count of Expense Lines sharing claimant, Expense Date, Merchant Name and Transaction Amount with a line on a different Expense Report.",
             [("44", "Expense Line", "Line Expense Report"), ("44", "Expense Line", "Expense Date"), ("44", "Expense Line", "Merchant Name"),
              ("44", "Expense Line", "Transaction Amount"), ("44", "Expense Report", "Claimant")]),
            ("Entertainment Lines Without G&E Record", "Count and Transaction Amount of approved Expense Lines with Expense Type in (Client Entertainment, Gift to External Party) and no Related Gift / Entertainment Items, or whose referenced GNE- record has a Giver other than the claimant.",
             [("44", "Expense Line", "Expense Type"), ("44", "Expense Line", "Related Gift / Entertainment Items"),
              ("44", "Expense Line", "Transaction Amount"), ("08", "Gift / Entertainment Item", "GNE ID"),
              ("08", "Gift / Entertainment Item", "Giver"), ("44", "Expense Report", "Claimant")]),
            ("Fund Recharges", "Sum of Transaction Amount of approved Expense Lines with Recharge Fund populated, by Recharge Fund and month; lines recharged to a fund with Business Purpose blank are counted separately.",
             [("44", "Expense Line", "Recharge Fund"), ("44", "Expense Line", "Transaction Amount"), ("44", "Expense Line", "Business Purpose"),
              ("44", "Expense Line", "Expense Date")]),
            ("Approved Reports Not Reimbursed", "Count and Expense Report Total Amount of Expense Reports with Expense Approval Status = Approved and Reimbursement Route in (Accounts Payable, Payroll) not yet paid, by age: for Accounts Payable, the referenced Supplier Payment has no Payment Value Date or Outgoing Payment Status not paid; for Payroll, Reimbursement Status not paid.",
             [("44", "Expense Report", "Expense Report ID"), ("44", "Expense Report", "Expense Report Total Amount"),
              ("44", "Expense Report", "Reimbursement Route"), ("44", "Expense Report", "Reimbursement Supplier Payment"),
              ("44", "Expense Report", "Reimbursement Status"), ("19", "Supplier Payment", "Supplier Payment Document Number"),
              ("19", "Supplier Payment", "Outgoing Payment Status"), ("19", "Supplier Payment", "Payment Value Date")]),
            ("T&E Subledger to GL Difference", "Per legal entity and fiscal period: sum of Expense Report Total Amount of approved reports whose Posting Journal Entry has Posting Accounting Period = the period - sum of debit Posted Amount of GL Postings on Journal Entries with Journal Source = Travel & Expense and the same Posting Accounting Period, from DP-191.",
             [("44", "Expense Report", "Expense Report Total Amount"), ("44", "Expense Report", "Posting Journal Entry"),
              ("19", "Journal Entry", "Journal ID"), ("19", "Journal Entry", "Journal Source"), ("19", "Journal Entry", "Posting Accounting Period"),
              ("19", "Journal Entry", "Posting Legal Entity"), ("19", "GL Posting", "Journal ID"), ("19", "GL Posting", "Posted Amount"),
              ("19", "GL Posting", "Debit Credit Indicator")]),
            ("Premium Travel Share %", "Travel Bookings with Trip Start Date in the period and Travel Class in (Business, First, Rail - First) / all bookings in the period, by traveler job level and org unit; air distance by Travel Class is supplied to DP-207 for Scope 3 business travel.",
             [("44", "Travel Booking", "Trip ID"), ("44", "Travel Booking", "Traveler"), ("44", "Travel Booking", "Trip Start Date"),
              ("44", "Travel Booking", "Travel Class"), ("44", "Travel Booking", "Air Distance")]),
        ],
        inputs=[
            ("44", "Expense Report", ["Expense Report ID", "Claimant", "Report Purpose", "Expense Report Total Amount",
                                      "Expense Approval Status", "Expense Approver", "Cost Owner Org Unit", "Reimbursement Route",
                                      "Reimbursement Supplier Payment", "Reimbursement Payroll Result", "Reimbursement Status",
                                      "Posting Journal Entry"]),
            ("44", "Expense Line", ["Line Expense Report", "Expense Line Number", "Expense Type", "Expense Date", "Merchant Name",
                                    "Transaction Amount", "Reimbursable Amount", "Business Purpose", "External Attendees",
                                    "Related Gift / Entertainment Items", "Matched Card Transaction", "Recharge Fund"]),
            ("44", "Corporate Card", ["Card Account ID", "Cardholder", "Card Issuer", "Card Billing Entity", "Card Credit Limit", "Card Status"]),
            ("44", "Card Transaction", ["Transaction Card", "Issuer Transaction Reference", "Card Posting Date", "Merchant Category Code",
                                        "Billed Amount", "Personal Spend Indicator"]),
            ("44", "Travel Booking", ["Trip ID", "Traveler", "Trip Start Date", "Trip End Date", "Destination Countries", "Travel Class",
                                      "Booking Agency", "Air Distance"]),
            ("44", "Expense Policy Limit", ["Limited Expense Type", "Location Band", "Applicable Job Level", "Limit Amount", "Per Diem Rate",
                                            "Governing Policy", "Limit Effective From", "Limit Effective To"]),
            ("08", "Gift / Entertainment Item", ["GNE ID", "Benefit Type", "Benefit Date", "Giver", "Recipient Individual"]),
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Home Org Unit", "Work Location", "Employment Status",
                                "Termination Date"]),
            ("20", "Employee Reporting Line", ["Reporting Employee", "Line Manager", "Reporting Line Type", "Reporting Effective From",
                                               "Reporting Effective To"]),
            ("20", "Employee Job Assignment", ["Assigned Worker", "Assigned Job Profile", "Assignment Type", "Assignment Effective From",
                                               "Assignment Effective To"]),
            ("20", "Job Profile", ["Job Profile ID", "Job Level"]),
            ("19", "Supplier Payment", ["Supplier Payment Document Number", "Outgoing Payment Status", "Payment Value Date"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Source", "Posting Date", "Posting Accounting Period", "Posting Legal Entity",
                                     "Journal Status"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount",
                                  "Cost Center Segment Value"]),
        ],
        upstream=["DP-192", "DP-191", "DP-190", "DP-038", "DP-013", "DP-004"],
        refresh="Daily",
        timeliness="Expense reports, card transactions and bookings by 8am ET on T+1; month-end policy and card reconciliation by business day 3 after month-end; GL tie-out after the period hard close",
        history="Expense reports, lines, card transactions and bookings kept 7 years (tax and audit retention); expense policy limits SCD type 2; month-end snapshots kept 7 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Expense Report Total Amount equals the sum of Transaction Amount of its Expense Lines for every report.",
            "Every Expense Report with Reimbursement Route = Accounts Payable references a Reimbursement Supplier Payment and none with Reimbursement Route = Payroll does; every Payroll-route report references a Reimbursement Payroll Result once reimbursed.",
            "Every Expense Line with Matched Card Transaction populated has Transaction Amount equal to the matched transaction's Billed Amount, and no Card Transaction is matched to more than one Expense Line.",
            "Every Expense Policy Limit has no overlapping effective period with another limit of the same Limited Expense Type, Location Band and Applicable Job Level.",
            "Every Claimant, Cardholder and Traveler resolves to a DP-192 worker.",
            "Every approved Expense Report has a Posting Journal Entry within 5 business days of approval, or by the period's hard close.",
        ],
        notes=("Certified numbers: none owned. T&E Spend is an operational measure that reconciles to the postings in DP-191 (CD-340, "
               "the pattern CD-353 applies to supplier spend); certified operating expense stays DP-191's. Primary function is "
               "FN-38 because C-13.17 belongs to the Finance Controller, though the records are owned in 44. Boundary: compliance "
               "facts on entertainment (limits, approvals, special recipients) stay 08 / DP-038 (CD-280); this product only tests "
               "that each entertainment line references its GNE- record. Reimbursement is a 19 Supplier Payment to a 02 party payee "
               "or a 20 Payroll Result (CD-280); the Payroll Result is carried as a key only and its pay amounts are not read, so "
               "the compensation tier stays in DP-198 (CD-344). Copy read on purpose: payroll-route status uses the 44 "
               "Reimbursement Status copy (set from 20 Payroll Run Pay Date) rather than reading payroll records, the CONTRACT.md "
               "rule 2 exception; AP-route status is read from its master, 19 Supplier Payment. Recharge "
               "Fund resolves through DP-004. DP-057 Wholesaler Productivity & Expense may take salesperson-level T&E from this "
               "product (CD-343, optional Wave E4 extension; no change made to DP-057 here); this product must then never list "
               "DP-057 upstream. CD-345: if the client drops 44, this product survives only if the T&E family moves to 19, with "
               "owning domain 19 and unchanged scope; otherwise it is withdrawn and DP-057's T&E gap reopens. Air distance and "
               "travel spend feed DP-207's Scope 3 Category 6 rows. PII = Y: every T&E record is person-keyed (44 PII rule); a "
               "view without claimant names, aggregated to org unit, is published for budget holders. Operating model: in house "
               "on a T&E platform; an outsourced expense audit service would add its audit flags as oversight data without "
               "changing the grain. Open SME question (44 Q4): whether employee expenses are reimbursed through payroll or "
               "accounts payable, by country. Taxonomy gap: Expense Line has no expense location and no link to the Travel "
               "Booking, so the policy Location Band is taken from the claimant's Work Location (travel lines are tested against "
               "the highest band until a location or trip link is added). Taxonomy gap: Expense Report has no submission or "
               "approval date, so reimbursement cycle time and the approver's reporting line on the approval date cannot be "
               "measured exactly; the reporting line effective on the latest Expense Date is used. Taxonomy gap: no merchant "
               "category code to expense type mapping, so card-to-line type consistency is not tested. Decisions: CD-280, CD-340, "
               "CD-343, CD-344, CD-345."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-104": dict(
        definition=("The register of the firm's AI and analytics use cases with their internal risk tier and NIST AI RMF profile, "
                    "the models (37) and deployed AI systems (41) behind them, and every approval to use a data asset with its "
                    "permitted AI uses, personal data categories, conditions and expiry, tested against the 14 license grant and "
                    "the asset's 21 classification. It applies CD-269 (use case in 21, model in 37, deployed system in 41) by reading "
                    "the model from DP-212 and the system from DP-211, so that the Chief Data Officer evidences AI governance to "
                    "compliance and risk and no use case runs on a model that is not validated or on data it is not approved or "
                    "licensed for."),
        business_questions=[
            "Which AI use cases are in pilot or production, with what internal AI risk tier and NIST AI RMF profile, and which are unclassified?",
            "Which live use cases have no current approval for the data they use, or use data whose license does not permit the AI use?",
            "Which approvals use personal data beyond the asset's classified categories or special category data, and which expire in the next 90 days?",
            "Which live use cases run on a model that has no approving validation, was rejected, or is untiered?",
            "Do our Tier 1 AI systems meet the firm's oversight controls: a named human oversight assignee and log retention of at least six months?",
            "Which use cases have a business owner who has left the firm?",
        ],
        grain="AI use case (AIU-) x effective period, with AI data usage approval (use case x data asset x approval), AI system use case link (application x use case x effective period) and model link (use case x model version) as child tables",
        dimensions=["AI use case and status", "Internal AI risk tier and NIST AI RMF profile",
                    "Human oversight mode", "Business owner (DP-192)", "Model, version and model tier (DP-212)",
                    "AI system / application (DP-211)", "Data asset and owning Data Domain (DP-101)",
                    "Information classification and personal data category (DP-100)", "Licensed dataset and permitted use category",
                    "Approval decision and expiry date"],
        measures=[
            ("Registered Use Cases", "Count of AI Use Cases by AI Use Case Status, Internal AI Risk Tier, NIST AI RMF Profile, AI Technique and Human Oversight Mode; live = AI Use Case Status in (In Pilot, In Production).",
             [("21", "AI Use Case", "AI Use Case ID"), ("21", "AI Use Case", "AI Use Case Status"), ("21", "AI Use Case", "AI Technique"),
              ("21", "AI Use Case", "Human Oversight Mode"), ("21", "AI Risk Classification", "Internal AI Risk Tier"),
              ("21", "AI Risk Classification", "NIST AI RMF Profile")]),
            ("Unclassified Use Cases", "Count of AI Use Cases with AI Use Case Status not in (Proposed, Rejected, Retired) and Internal AI Risk Tier blank.",
             [("21", "AI Use Case", "AI Use Case Status"), ("21", "AI Risk Classification", "Internal AI Risk Tier")]),
            ("Live Use Cases Without Approved Data", "Count of live AI Use Cases with no AI Data Usage Approval whose AI Data Usage Decision is in (Approved, Approved with Conditions) and AI Data Usage Expiry Date is blank or on or after the as-of date.",
             [("21", "AI Data Usage Approval", "Approved AI Use Case"), ("21", "AI Data Usage Approval", "AI Data Usage Decision"),
              ("21", "AI Data Usage Approval", "AI Data Usage Expiry Date"), "Registered Use Cases"]),
            ("Approvals Expiring (90 Days)", "Count of approvals (Approved or Approved with Conditions) on live use cases whose AI Data Usage Expiry Date falls in the next 90 days; expired approvals on live use cases counted separately.",
             [("21", "AI Data Usage Approval", "AI Data Usage Expiry Date"), ("21", "AI Data Usage Approval", "AI Data Usage Decision"),
              ("21", "AI Data Usage Approval", "Approved AI Use Case"), "Registered Use Cases"]),
            ("Approvals Beyond License", "Count of current approvals on Data Assets with a Cataloged Licensed Dataset whose Covering Permitted Use Grant is blank, has Permission Status in (Requires Additional License, Prohibited, Not Addressed), is outside its Grant Effective From / To on the as-of date, or covers a different Grant Dataset than the asset's licensed dataset.",
             [("21", "AI Data Usage Approval", "Approved Data Asset"), ("21", "AI Data Usage Approval", "Covering Permitted Use Grant"),
              ("21", "Data Asset", "Data Asset ID"), ("21", "Data Asset", "Cataloged Licensed Dataset"),
              ("14", "Permitted Use Grant", "Grant Dataset"), ("14", "Permitted Use Grant", "Permission Status"),
              ("14", "Permitted Use Grant", "Grant Effective From"), ("14", "Permitted Use Grant", "Grant Effective To"),
              ("14", "Permitted Use Grant", "Permitted Use Category")]),
            ("Personal Data Category Exceptions", "Count of current approvals whose Personal Data Categories Used include a category not in the Assigned Personal Data Categories of the asset's Data Classification Assignment effective on the as-of date; approvals on assets with Special Category Data Indicator = Y reported separately.",
             [("21", "AI Data Usage Approval", "Personal Data Categories Used"), ("21", "AI Data Usage Approval", "Approved Data Asset"),
              ("21", "Data Classification Assignment", "Classified Data Asset"), ("21", "Data Classification Assignment", "Assigned Personal Data Categories"),
              ("21", "Data Classification Assignment", "Special Category Data Indicator"),
              ("21", "Data Classification Assignment", "Classification Effective From"), ("21", "Data Classification Assignment", "Classification Effective To")]),
            ("Live Use Cases on Unvalidated Models", "Count of live AI Use Cases whose model (Model Name, and every Deployed Model of AI Systems linked to the use case through an effective AI System Use Case Link) has no Model Validation with Model Validation Outcome in (Approved, Approved with Conditions) for the deployed version, has a latest outcome of Rejected, or has no effective Model Tier Assignment.",
             [("21", "AI Use Case", "Model Name"), ("41", "AI System Use Case Link", "Linked AI System"),
              ("41", "AI System Use Case Link", "Served AI Use Case"), ("41", "AI System Model Deployment", "Model Deploying AI System"),
              ("41", "AI System Model Deployment", "Deployed Model"), ("37", "Model Validation", "Validated Model"),
              ("37", "Model Validation", "Model Validation Outcome"), ("37", "Model Validation", "Model Validation Completed Date"),
              ("37", "Model Tier Assignment", "Tiered Model"), ("37", "Model Tier Assignment", "Tier Effective From"),
              ("37", "Model Tier Assignment", "Tier Effective To"), "Registered Use Cases"]),
            ("Live Use Cases Without AI System", "Count of live AI Use Cases with no AI System Use Case Link effective on the as-of date to an Application with Application Status = In Production; and the reverse, AI systems in production linked to a use case that is not live.",
             [("41", "AI System Use Case Link", "Served AI Use Case"), ("41", "AI System Use Case Link", "Linked AI System"),
              ("41", "AI System Use Case Link", "Use Case Link Effective From"), ("41", "AI System Use Case Link", "Use Case Link Effective To"),
              ("41", "Application", "Application ID"), ("41", "Application", "Application Status"), "Registered Use Cases"]),
            ("Tier 1 Oversight Gaps", "Count of AI systems linked to a live use case with Internal AI Risk Tier = Tier 1 whose AI System Profile has Human Oversight Assignee blank or Log Retention Months below 6 (firm AI governance policy), or whose use case has Human Oversight Mode = Fully Automated.",
             [("41", "AI System Profile", "Human Oversight Assignee"), ("41", "AI System Profile", "Log Retention Months"),
              ("21", "AI Risk Classification", "Internal AI Risk Tier"), ("21", "AI Use Case", "Human Oversight Mode"),
              "Live Use Cases Without AI System"]),
            ("Use Cases With Departed Owner", "Count of AI Use Cases not Retired or Rejected whose AI Use Case Business Owner has Employment Status = Terminated in DP-192, plus Tier 1 AI systems whose Human Oversight Assignee has left.",
             [("21", "AI Use Case", "AI Use Case Business Owner"), ("21", "AI Use Case", "AI Use Case Status"),
              ("41", "AI System Profile", "Human Oversight Assignee"), ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status")]),
        ],
        inputs=[
            ("21", "AI Use Case", ["AI Use Case ID", "AI Use Case Name", "AI Use Case Purpose", "AI Use Case Business Owner", "AI Technique",
                                   "Model Name", "Model Provider", "Human Oversight Mode", "AI Use Case Status"]),
            ("21", "AI Risk Classification", ["Uses General-Purpose AI Model Indicator", "Internal AI Risk Tier", "NIST AI RMF Profile"]),
            ("21", "AI Data Usage Approval", ["Approved AI Use Case", "Approved Data Asset", "Covering Permitted Use Grant",
                                              "Permitted AI Data Uses", "Personal Data Categories Used", "AI Data Usage Decision",
                                              "AI Data Usage Conditions", "AI Data Usage Approved Date", "AI Data Usage Expiry Date"]),
            ("21", "Data Asset", ["Data Asset ID", "Data Asset Name", "Data Asset Type", "Hosting System", "Asset Owning Data Domain",
                                  "Cataloged Licensed Dataset", "Data Asset Status"]),
            ("21", "Data Classification Assignment", ["Classification Scheme", "Classified Data Asset", "Assigned Information Classification",
                                                      "Assigned Personal Data Categories", "Special Category Data Indicator",
                                                      "Classification Effective From", "Classification Effective To"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Type", "Model Purpose", "Model Owner",
                                             "Model Use Status"]),
            ("37", "Model Tier Assignment", ["Tiered Model", "Model Tier", "Tier Effective From", "Tier Effective To"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Completed Date", "Model Validation Outcome",
                                        "Model Validation Conditions"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Status", "Criticality Tier"]),
            ("41", "AI System Profile", ["AI System Provider", "Log Retention Months", "Human Oversight Assignee"]),
            ("41", "AI System Use Case Link", ["Linked AI System", "Served AI Use Case", "Use Case Link Effective From",
                                               "Use Case Link Effective To"]),
            ("41", "AI System Model Deployment", ["Model Deploying AI System", "Deployed Model", "Model Deployment Effective From",
                                                  "Model Deployment Effective To"]),
            ("14", "Permitted Use Grant", ["Grant Agreement", "Grant Dataset", "Permitted Use Category", "Permission Status",
                                           "Use Conditions", "Personal Data Use Restrictions", "Grant Effective From", "Grant Effective To"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-101", "DP-100", "DP-211", "DP-212", "DP-192"],
        refresh="Daily",
        timeliness="By 8am ET on T+1; a new or changed approval or use case status is visible the next day",
        history="SCD type 2 on every use case, classification, approval and link for the life of the use case plus 10 years (firm AI governance policy; SEC Rule 204-2 and FINRA Rule 4511 where a use case record is a book or record); month-end register snapshots kept 10 years",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every AI Use Case with AI Use Case Status in (Approved for Pilot, In Pilot, In Production) has an Internal AI Risk Tier.",
            "Every AI Data Usage Approval with AI Data Usage Decision in (Approved, Approved with Conditions) has an AI Data Usage Approved Date, at least one Permitted AI Data Uses value and, when Personal Data Categories Used is not empty, a Data Classification Assignment for the asset.",
            "AI Data Usage Expiry Date is after AI Data Usage Approved Date on every approval.",
            "Every Approved Data Asset with a Cataloged Licensed Dataset has a Covering Permitted Use Grant whose Grant Dataset is that dataset.",
            "Every Model Name resolves to a Model Inventory Entry in DP-212, and every Linked AI System resolves to an Application in DP-211.",
        ],
        notes=("W1b: AI Risk Classification.EU AI Act Risk Category, EU AI Act Operator Roles, Article 50 Transparency Obligations and Fundamental Rights Impact Assessment Required Indicator dropped, no successor (CW-921); the measures Prohibited Practice Use Cases and FRIA Required Use Cases are removed, Registered Use Cases and Unclassified Use Cases slice by Internal AI Risk Tier and NIST AI RMF Profile, and High-Risk Deployer Obligation Gaps is rewritten as Tier 1 Oversight Gaps on Internal AI Risk Tier = Tier 1. W1b re-point (CW-921): GDPR Special Category Data Indicator reads the renamed Special Category Data Indicator. W1b: AI System Profile.Input Data Controlled Indicator dropped, no successor (CW-941); no measure read it. "
               "Certified numbers: none owned. Use case in 21, model in 37, deployed system in 41 (CD-246, CD-269): this product reads "
               "the model, tier and validation from DP-212 and the application, AI system profile and links from DP-211, and adds no "
               "model or system attributes. AI Use Case Model Name is a reference to the 37 model. DP-212 holds no list of model "
               "uses (CD-294, CD-295); this product is where a model's AI use cases are seen. CD-294: scores and forecasts in other "
               "products reference the 37 model; this product has no scoring measure and so names no scoring model. Data assets "
               "and their catalog entries come from DP-101; classification and personal data categories from DP-100 (the 21 "
               "Data Classification Assignment); 14 Permitted Use Grant is read from 14, its master, by the grant key the approval "
               "holds; DP-044 Third-Party Data Usage, Entitlements & Cost keeps the license usage view and is not an upstream. PII "
               "= Y: AI Use Case Business Owner, Model Owner and Human Oversight Assignee are employee keys resolved through DP-192; "
               "a view with roles and org units but no names is published for wide use. AI use cases in recruitment and worker "
               "management (DP-197 data) may fall under state AI laws (for example Colorado SB 24-205) and appear here like any other use case. Open SME "
               "questions (21 Q7, Q12): who owns the AI use case register (CDO, CRO or CTO); which state AI laws reach the firm's use "
               "cases (tailoring lever). Taxonomy gap: AI Data Usage Approval has no approver, so who approved "
               "a data use cannot be evidenced or tested for segregation of duties. Taxonomy gap: AI Use Case holds one Model Name, so a use case served "
               "by several models is linked to the others only through its AI systems' model deployments. Decisions: CD-163, "
               "CD-246, CD-269, CD-294, CD-295, CD-361."),
    ),
}
