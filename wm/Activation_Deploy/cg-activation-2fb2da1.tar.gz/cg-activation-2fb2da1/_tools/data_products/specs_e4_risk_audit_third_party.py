"""Data product specifications, Wave E4: enterprise risk, internal audit and third-party products (DP-214 to DP-221).

Owning Data Domains 37 Enterprise & Operational Risk and 40 Procurement & Vendor Management. Candidates:
_tools/consolidation/proposals_dp_corporate_b.py; brief: 00_Program/Expansion/Product_Briefs/
Corporate_Risk_Compliance_Legal_and_Technology.md. See CONTRACT.md.

Upstream graph inside this group (no cycles): DP-214 <- DP-216 <- DP-215, DP-217, DP-218; DP-217 <- DP-220 <- DP-219;
DP-221 <- DP-219. DP-216 is the single remediation status (CD-356); DP-219 is the third-party oversight grain that
DP-073 (data vendors, CD-350) and DP-176 (fund service providers, CD-333, CD-355) are views or readers of.
"""


def _u(nn, obj, *attrs):
    """(NN, object, attribute) use tuples for one object."""
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ==================================================================================================================
    "DP-214": dict(
        definition=("The firm's risk and control profile at enterprise risk x assessment date: inherent and residual ratings "
                    "against the risk appetite, the controls that mitigate each risk with their latest test results by line "
                    "of defense, RCSA campaign completion, and key risk indicators against their amber and red thresholds. "
                    "It combines the 37 risk register, control library and KRI objects (CD-243) with the 21 metric "
                    "definitions some KRIs are built on, read from DP-101. It is the Risk and Control dimension that the 37 "
                    "and 38 products and the Wave E5 Enterprise Risk & Control view join to, and it tells the risk committee "
                    "which risks sit outside appetite and which key controls are failing. It owns no certified metric family; "
                    "a KRI built on a certified metric takes the certified value from the product that owns it (CD-293)."),
        business_questions=[
            "Which enterprise risks are outside appetite today, by risk category, business line and owning org unit, and how has that changed since the last committee?",
            "How is the residual risk profile spread, and which risks moved rating between their last two assessments?",
            "Which risks have no effective key control, and which key controls failed or were not tested in the last 12 months?",
            "Which KRIs are red or amber, which have been red for three observations running, and which are late?",
            "Which org units have not signed off their RCSA for the period?",
        ],
        grain="Enterprise risk (RISK-) x risk assessment date, with child grains control version x test date x test sequence, enterprise risk x control x effective period, and KRI version x observation date; month-end snapshots for the risk committee",
        dimensions=["Enterprise risk", "Risk category (taxonomy level 1 and 2)", "Basel event type (mapped)", "Owning org unit",
                    "Legal entity", "Business line", "Inherent and residual risk rating", "Within appetite indicator",
                    "Appetite category", "Control and control version", "Control type and nature", "Key control and SOX key control",
                    "Testing line", "Control test result", "KRI and KRI version", "KRI RAG status", "RCSA campaign",
                    "Assessment date", "Risk owner and control owner (employee)"],
        measures=[
            ("Residual Risk Profile", "Count of Enterprise Risks with Enterprise Risk Status = Active by the Residual Risk Rating of their latest Risk Assessment (highest Risk Assessment Date), shown beside the Inherent Risk Rating of the same assessment, by Risk Category rolled up through Parent Risk Category.",
             _u("37", "Enterprise Risk", "Risk ID", "Enterprise Risk Status", "Risk Category")
             + _u("37", "Risk Assessment", "Assessed Risk", "Risk Assessment Date", "Inherent Risk Rating", "Residual Risk Rating")
             + _u("37", "Risk Taxonomy Category", "Risk Category Code", "Parent Risk Category")),
            ("Risks Outside Appetite", "Count of active risks whose latest Risk Assessment has Within Appetite Indicator = N, by the Appetite Category of the Risk Appetite Statement effective on the assessment date for the risk's category and legal entity.",
             _u("37", "Risk Assessment", "Within Appetite Indicator")
             + _u("37", "Risk Appetite Statement", "Appetite Category", "Appetite Scope Entity", "Appetite Effective From", "Appetite Effective To")
             + ["Residual Risk Profile"]),
            ("Risk Rating Migration", "Count of active risks whose Residual Risk Rating differs between their two latest Risk Assessments, by from-rating and to-rating; Risk Trend shown beside.",
             _u("37", "Risk Assessment", "Assessed Risk", "Risk Assessment Date", "Residual Risk Rating", "Risk Trend")),
            ("Stale Risk Assessments", "Active risks whose latest Risk Assessment Date is more than 12 months before the as-of date, or that have none.",
             _u("37", "Risk Assessment", "Risk Assessment Date") + ["Residual Risk Profile"]),
            ("Risks Without Effective Key Control", "Active risks with Residual Risk Rating High or Critical that have no Risk Control Link effective on the as-of date to a Control version with Key Control Indicator = Y, Control Version Approval Status = Approved, and a latest Control Test Result of Effective or Effective with Exceptions.",
             _u("37", "Risk Control Link", "Linked Risk", "Linked Control", "Link Effective From", "Link Effective To")
             + _u("37", "Control", "Control ID", "Control Version", "Key Control Indicator", "Control Version Approval Status")
             + _u("37", "Control Test", "Tested Control", "Control Test Date", "Control Test Result")
             + ["Residual Risk Profile"]),
            ("Key Control Test Failure Rate", "Control Tests of key controls (Key Control Indicator = Y) with Control Test Result = Ineffective / Control Tests of key controls with Control Test Result in (Effective, Effective with Exceptions, Ineffective) in the period, by Testing Line and Control Test Type; tests with Not Tested or Control Not Operated are excluded from both.",
             _u("37", "Control Test", "Tested Control", "Control Test Date", "Control Test Type", "Testing Line", "Control Test Result")
             + _u("37", "Control", "Key Control Indicator")),
            ("Key Controls Not Tested (12 Months)", "Count of Control versions effective on the as-of date (Control Version Effective From <= as-of date < Control Version Effective To or open) with Key Control Indicator = Y and no Control Test with Control Test Result other than Not Tested in the 12 months to the as-of date; SOX key controls shown separately.",
             _u("37", "Control", "Control ID", "Control Version", "Key Control Indicator", "SOX Key Control Indicator",
                "Control Version Effective From", "Control Version Effective To")
             + _u("37", "Control Test", "Tested Control", "Control Test Date", "Control Test Result")),
            ("Controls With Departed Owner", "Key controls effective on the as-of date whose Control Owner has Employment Status = Terminated in DP-192.",
             _u("37", "Control", "Control Owner", "Key Control Indicator") + _u("20", "Employee", "Employee ID", "Employment Status")),
            ("RCSA Completion %", "RCSA Campaign rows (campaign x assessed org unit) with RCSA Campaign Status in (Resolved, Closed) and RCSA Sign-Off By populated / RCSA Campaign rows with RCSA Period End Date in the period, by Assessed Org Unit.",
             _u("37", "RCSA Campaign", "RCSA Campaign Code", "Assessed Org Unit", "RCSA Period End Date", "RCSA Sign-Off By", "RCSA Campaign Status")),
            ("KRI Breaches", "Count of KRI versions whose latest KRI Observation has KRI Observation RAG = Red, and separately Amber, by Measured Risk and its Risk Category.",
             _u("37", "KRI Observation", "Observed KRI", "KRI Observation Date", "KRI Observation RAG")
             + _u("37", "Key Risk Indicator", "KRI Code", "KRI Version", "Measured Risk")),
            ("Persistent KRI Breaches", "KRI versions whose three latest KRI Observations all have KRI Observation RAG = Red.",
             _u("37", "KRI Observation", "Observed KRI", "KRI Observation Date", "KRI Observation RAG")),
            ("Late KRI Observations", "KRI versions in use whose latest KRI Observation Date is older than one KRI Frequency interval before the as-of date (for example more than one month for a monthly KRI), or that have no observation.",
             _u("37", "Key Risk Indicator", "KRI Code", "KRI Version", "KRI Frequency")
             + _u("37", "KRI Observation", "Observed KRI", "KRI Observation Date")),
            ("KRIs on Uncertified Metrics", "KRI versions with a Source Metric Definition whose 21 Metric Definition (from DP-101) has Metric Certification Status other than Certified.",
             _u("37", "Key Risk Indicator", "Source Metric Definition") + _u("21", "Metric Definition", "Metric ID", "Metric Certification Status")),
        ],
        inputs=[
            ("37", "Risk Taxonomy Category", ["Risk Category Code", "Risk Taxonomy Version", "Risk Category Name", "Parent Risk Category",
                                              "Mapped Basel Event Type"]),
            ("37", "Enterprise Risk", ["Risk ID", "Risk Statement", "Risk Category", "Risk Owning Org Unit", "Risk Legal Entities",
                                       "Risk Owner", "Risk Business Lines", "Enterprise Risk Status"]),
            ("37", "Risk Assessment", ["Assessed Risk", "Risk Assessment Date", "Risk Assessment Basis", "Source RCSA Campaign",
                                       "Inherent Likelihood", "Inherent Impact", "Inherent Risk Rating", "Residual Likelihood",
                                       "Residual Impact", "Residual Risk Rating", "Risk Trend", "Within Appetite Indicator",
                                       "Risk Assessor"]),
            ("37", "Risk Appetite Statement", ["Appetite Statement Code", "Appetite Category", "Appetite Scope Entity",
                                               "Appetite Statement Text", "Appetite Tolerance Threshold", "Appetite Effective From",
                                               "Appetite Effective To"]),
            ("37", "RCSA Campaign", ["RCSA Campaign Code", "Assessed Org Unit", "RCSA Period End Date", "RCSA Sign-Off By",
                                     "RCSA Campaign Status"]),
            ("37", "Control", ["Control ID", "Control Version", "Control Objective", "Control Type", "Control Nature",
                               "Control Frequency", "Key Control Indicator", "SOX Key Control Indicator", "Control Execution Record Type",
                               "Control Owning Legal Entity", "Control Owner", "Control Version Approval Status",
                               "Control Version Effective From", "Control Version Effective To"]),
            ("37", "Risk Control Link", ["Linked Risk", "Linked Control", "Mitigation Strength", "Link Effective From", "Link Effective To"]),
            ("37", "Control Test", ["Tested Control", "Control Test Date", "Control Test Sequence", "Control Test Type", "Testing Line",
                                    "Control Tester", "Sampled Execution Records", "Control Test Result"]),
            ("37", "Key Risk Indicator", ["KRI Code", "KRI Version", "KRI Definition", "Measured Risk", "Source Metric Definition",
                                          "KRI Frequency"]),
            ("37", "KRI Threshold", ["KRI Threshold Direction", "KRI Amber Threshold", "KRI Red Threshold", "Linked Appetite Statement"]),
            ("37", "KRI Observation", ["Observed KRI", "KRI Observation Date", "KRI Observed Value", "KRI Observation RAG"]),
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Direction", "Metric Source Data Product",
                                         "Metric Certification Status"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-013", "DP-192", "DP-101"],
        refresh="Daily",
        timeliness="By 7am ET each business day; the month-end risk committee snapshot is locked on business day 5",
        history="SCD type 2 on risks, controls, links and KRI versions; every assessment, control test and KRI observation kept; month-end snapshots kept 10 years",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Enterprise Risk with Enterprise Risk Status = Active has a Risk Category that resolves to a Risk Taxonomy Category of the current Risk Taxonomy Version, a Risk Owner in DP-192 and at least one Risk Assessment.",
            "Residual Risk Rating is never higher than Inherent Risk Rating on the same Risk Assessment.",
            "Every Risk Control Link names a Control version whose Control Version Approval Status = Approved and whose effective period overlaps the link's effective period.",
            "Every KRI Observation RAG agrees with KRI Observed Value against the KRI Amber Threshold, KRI Red Threshold and KRI Threshold Direction of the observed KRI version, and KRI Threshold Direction equals the Metric Direction of its Source Metric Definition where one is set.",
            "For a KRI whose Source Metric Definition has Metric Certification Status = Certified, KRI Observed Value equals the value published for the KRI Observation Date by the product named in Metric Source Data Product (CD-293).",
            "Every Control Test of Testing Line Compliance or Risk names Sampled Execution Records, and no Control Test copies the result of a domain control execution (CD-243).",
        ],
        notes=("Master concepts read, not remastered: the risk register, control library, RCSA, KRIs and appetite are mastered in 37 "
               "(CD-243); this product publishes them as the Risk and Control dimension for consumer products, not as a foundational "
               "master (CD-354 keeps them consumer-aligned). Control executions in 06, 07, 10, 19, 27, 29 and 33 are sampled by "
               "Control Test as evidence keys only; no execution result is copied. KRI definitions built on a 21 Metric Definition "
               "are read from DP-101; the observed value is 37's, and for a certified metric it must equal the certified value "
               "(CD-293; for example headcount from DP-192, operating expense from DP-191). Remediation of failed tests and "
               "self-identified issues is DP-216's (CD-356); this product computes no issue status. Certified numbers: none. "
               "Policy parameters taken as drafting assumptions: 12-month assessment and key-control test currency; three "
               "consecutive red observations as persistent. Code values used: Shared Case Status (Resolved, Closed) for RCSA "
               "completion, Shared Approval Status (Approved), Control Test Result list. Open SME questions (37 Q2, Q6, Q10): the "
               "GRC platform of record; whether SOX 404 applies so the SOX key control flag is used; whether appetite is approved by "
               "the holding company board, the entity boards or both. Taxonomy gap: Enterprise Risk has no last-reviewed or "
               "next-assessment due date, so assessment currency uses a 12-month policy assumption. Taxonomy gap: Risk Appetite "
               "Statement holds a tolerance threshold but no link from Risk Assessment to the statement it was judged against; "
               "the statement is matched by category and scope entity. Taxonomy gap: Control has no test frequency or next test "
               "due date. PII = Y: Risk Owner, Risk Assessor, Control Owner, Control Tester and RCSA Sign-Off By are employee keys; "
               "the committee view shows roles and org units, not names. Decisions: CD-243, CD-293, CD-296, CD-354, CD-356."),
    ),
    # ==================================================================================================================
    "DP-215": dict(
        definition=("Every operational incident with its typed source records (trade errors, NAV errors, investment breaches, "
                    "risk limit exceedances, servicing errors, IT and physical security incidents, plan corrections), its "
                    "Basel classification, every customer and authority notification (Regulation S-P, state breach "
                    "laws, FINRA Rule 4530 where it applies) against its deadline, and the loss events with gross firm-borne loss, client impact, "
                    "third-party and insurance recovery. Incidents, classifications, notifications and losses are mastered in "
                    "37 (CD-244, CD-245); source facts stay in 25, 27, 33, 26 and 13 and are published as received (one loss, "
                    "one home). It lets operational risk see what went wrong, what it cost and whether every regulator was "
                    "notified in time. It owns no certified metric family: Gross Operational Loss is an operational measure "
                    "that reconciles to the 19 GL evidence journal from DP-191, never expense or P&L (CD-353, CD-361)."),
        business_questions=[
            "How many incidents occurred and were discovered this period, by Basel event type, cause, severity, legal entity and business line, and how many were near misses?",
            "What is the gross and net operational loss by event type and legal entity, and how much of it is still unreconciled to the general ledger?",
            "Which Regulation S-P customer notifications, state breach notices and FINRA Rule 4530 reports were sent late, and which are due in the next 24 hours?",
            "Which loss amounts copied from trade errors, NAV errors, breach compensation and settlement penalties no longer match their source?",
            "Which incidents still have overdue remediation, and what was the client impact?",
        ],
        grain="Operational incident (OPINC-), with child grains incident x source record, incident x notification regime x authority x notification stage, and operational loss event x amount sequence",
        dimensions=["Incident discovery and occurrence date", "Basel event type level 1 and 2", "Incident risk category", "Cause category",
                    "Incident severity", "Near miss indicator", "Incident source type", "Notification regime",
                    "Notification authority and stage", "Incident and loss legal entity", "Loss business line", "Loss amount component",
                    "Loss booking period", "Impacted product", "Incident status and loss status"],
        measures=[
            ("Incident Count", "Count of Operational Incidents by Incident Discovery Date period, Basel Event Type Level 1 and 2, Incident Severity and Incident Legal Entity; incidents with Near Miss Indicator = Y counted separately.",
             _u("37", "Operational Incident", "Operational Incident ID", "Incident Discovery Date", "Incident Severity", "Incident Legal Entity")
             + _u("37", "Incident Classification", "Basel Event Type Level 1", "Basel Event Type Level 2", "Near Miss Indicator")),
            ("Discovery Lag Days", "Incident Discovery Date - Incident Occurrence Date in calendar days; median and 90th percentile by Basel Event Type Level 1.",
             _u("37", "Operational Incident", "Incident Occurrence Date", "Incident Discovery Date")
             + _u("37", "Incident Classification", "Basel Event Type Level 1")),
            ("Gross Operational Loss", "Sum of Loss Amount on Loss Event Amount rows with Loss Amount Component in (Gross Loss, Provision), by Loss Booking Date period, Loss Legal Entity, Loss Business Line and the Basel event type of the Originating Incident; Near-Miss Estimate and Gain rows excluded. An operational measure under its own name, never expense (CD-353).",
             _u("37", "Loss Event Amount", "Amount Loss Event", "Loss Amount Component", "Loss Amount", "Loss Booking Date")
             + _u("37", "Operational Loss Event", "Loss Event ID", "Originating Incident", "Loss Legal Entity", "Loss Business Line")),
            ("Insurance Recoveries", "Sum of Amount Recovered on 43 Insurance Claims whose Related Operational Loss Event is the loss event, by the loss event's Loss Legal Entity; Claimed Amount shown beside.",
             _u("43", "Insurance Claim", "Related Operational Loss Event", "Claimed Amount", "Amount Recovered", "Insurance Claim Status")),
            ("Net Operational Loss", "Gross Operational Loss - Insurance Recoveries - sum of Loss Amount on rows with Loss Amount Component = Third-Party Recovery.",
             _u("37", "Loss Event Amount", "Loss Amount Component", "Loss Amount") + ["Gross Operational Loss", "Insurance Recoveries"]),
            ("Client Impact Amount", "Sum of Impact Amount on Operational Loss Events (the client or portfolio harm, a derived copy of the 25, 27, 33 or 13 source amount), by Loss Legal Entity and the Basel event type of the Originating Incident.",
             _u("37", "Operational Loss Event", "Impact Amount", "Originating Incident", "Loss Legal Entity")),
            ("Source Amount Mismatches", "Count and value of Loss Event Amount rows whose Loss Amount differs from the source: Reimbursement Amount of the Amount Source Trade Error, Fund Loss Amount of the Amount Source NAV Error Case where Reimbursing Entity is populated, Compensation Amount of the approved Loss Calculation Version of the Amount Source Breach Loss Calculation, or Penalty Amount of the Amount Source Settlement Penalty where Penalty Absorbed by Firm Indicator = Y.",
             _u("37", "Loss Event Amount", "Loss Amount", "Amount Source Trade Error", "Amount Source NAV Error Case",
                "Amount Source Breach Loss Calculation", "Amount Source Settlement Penalty")
             + _u("25", "Trade Error", "Trade Error Reference", "Reimbursement Amount")
             + _u("27", "NAV Error Case", "NAV Error Case ID", "Fund Loss Amount", "Reimbursing Entity")
             + _u("33", "Breach Loss Calculation", "Calculated Breach", "Loss Calculation Version", "Compensation Amount",
                  "Loss Calculation Approval Status")
             + _u("26", "Settlement Penalty", "Settlement Penalty ID", "Penalty Amount", "Penalty Absorbed by Firm Indicator")),
            ("Loss Reconciled to GL %", "Loss Event Amount rows with Loss Amount Component in (Gross Loss, Provision, Third-Party Recovery) whose GL Evidence Journal resolves to a DP-191 Journal Entry with Journal Status = Posted and whose debit GL Postings in that journal sum to Loss Amount within 1 unit of currency / all such rows; Unreconciled Loss Amount is the sum of Loss Amount on the rows that fail (CD-353).",
             _u("37", "Loss Event Amount", "Loss Amount Component", "Loss Amount", "GL Evidence Journal")
             + _u("19", "Journal Entry", "Journal ID", "Journal Status", "Posting Accounting Period")
             + _u("19", "GL Posting", "Journal ID", "Debit Credit Indicator", "Posted Amount")),
            ("Notification Timeliness %", "Incident Regulatory Notifications with Notification Sent Timestamp <= Notification Deadline Timestamp / notifications with Notification Deadline Timestamp in the period, by Incident Notification Regime, Notification Authority and Incident Notification Stage.",
             _u("37", "Incident Regulatory Notification", "Notified Incident", "Incident Notification Regime", "Notification Authority",
                "Incident Notification Stage", "Notification Deadline Timestamp", "Notification Sent Timestamp")),
            ("Overdue and Due Notifications", "Count of Incident Regulatory Notifications with no Notification Sent Timestamp and Notification Deadline Timestamp before now (overdue), and separately within the next 24 hours (due), by Incident Notification Regime, Notification Authority and Incident Notification Stage.",
             _u("37", "Incident Regulatory Notification", "Incident Notification Regime", "Notification Authority", "Incident Notification Stage",
                "Notification Deadline Timestamp", "Notification Sent Timestamp")),
            ("Notifications Missing a Final Stage", "Incidents with Incident Status Resolved or Closed that have a sent Incident Regulatory Notification of stage Initial under an Incident Notification Regime other than Internal and no sent notification of stage Final under the same regime, for each Notifying Legal Entity.",
             _u("37", "Incident Regulatory Notification", "Notified Incident", "Incident Notification Regime", "Incident Notification Stage",
                "Notifying Legal Entity", "Notification Sent Timestamp")
             + _u("37", "Operational Incident", "Incident Status")),
            ("IT-Caused Service Downtime", "Sum of Service Downtime Minutes of the 41 IT Incidents named as Source IT Incident, by Basel Event Type Level 2 and Incident Severity of the operational incident.",
             _u("41", "IT Incident", "IT Incident ID", "Service Downtime Minutes", "Incident Class")
             + _u("37", "Incident Source Record", "Source IT Incident")
             + _u("37", "Incident Classification", "Basel Event Type Level 2")
             + _u("37", "Operational Incident", "Incident Severity")),
            ("Incidents With Overdue Remediation", "Count of Operational Incidents named as Source Operational Incident of a Risk Issue whose Remediation Status from DP-216 is Overdue or Risk Acceptance Expired, by Incident Severity.",
             _u("37", "Risk Issue", "Risk Issue ID", "Source Operational Incident", "Issue Status", "Issue Due Date")
             + _u("37", "Operational Incident", "Operational Incident ID", "Incident Severity")),
        ],
        inputs=[
            ("37", "Operational Incident", ["Operational Incident ID", "Incident Occurrence Date", "Incident Discovery Date",
                                            "Incident Business Process", "Incident Legal Entity",
                                            "Impacted Products", "Incident Severity", "Incident Owner",
                                            "Incident Information Classification", "Whistleblowing Source Indicator", "Incident Status"]),
            ("37", "Incident Source Record", ["Source Incident", "Incident Source Type", "Source Trade Error", "Source NAV Error Case",
                                              "Source Investment Breach", "Source Risk Limit Exceedance", "Source Servicing Error",
                                              "Source IT Incident", "Source Physical Security Incident", "Source Plan Correction"]),
            ("37", "Incident Classification", ["Basel Event Type Level 2", "Basel Event Type Level 1", "Incident Risk Category",
                                               "Cause Category", "Near Miss Indicator"]),
            ("37", "Incident Regulatory Notification", ["Notified Incident", "Incident Notification Regime", "Notification Authority", "Incident Notification Stage",
                                                        "Notifying Legal Entity", "Notification Deadline Timestamp",
                                                        "Notification Sent Timestamp", "Authority Reference Number"]),
            ("37", "Operational Loss Event", ["Loss Event ID", "Originating Incident", "Loss Legal Entity", "Loss Business Line",
                                              "Loss Status", "Impact Amount", "Impact Source Servicing Error", "Related Legal Matter"]),
            ("37", "Loss Event Amount", ["Amount Loss Event", "Loss Amount Sequence", "Loss Amount Component", "Loss Amount",
                                         "Loss Booking Date", "GL Evidence Journal", "Amount Source Trade Error",
                                         "Amount Source NAV Error Case", "Amount Source Breach Loss Calculation",
                                         "Amount Source Settlement Penalty"]),
            ("37", "Risk Taxonomy Category", ["Risk Category Code", "Risk Category Name"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Source Operational Incident", "Issue Status", "Issue Due Date"]),
            ("41", "IT Incident", ["IT Incident ID", "Incident Class", "Incident Priority", "Major Incident Indicator",
                                   "Incident Detected Timestamp", "Service Restored Timestamp", "Service Downtime Minutes",
                                   "Affected Applications"]),
            ("43", "Insurance Claim", ["Insurance Claim Reference", "Related Operational Loss Event", "Claimed Amount", "Amount Recovered",
                                       "Insurance Claim Status"]),
            ("25", "Trade Error", ["Trade Error Reference", "Error Gain or Loss Amount", "Reimbursement Amount"]),
            ("27", "NAV Error Case", ["NAV Error Case ID", "Fund Loss Amount", "Material Error Indicator", "Reimbursing Entity"]),
            ("33", "Breach Loss Calculation", ["Calculated Breach", "Loss Calculation Version", "Breach Loss Amount", "Compensation Amount",
                                               "Loss Calculation Approval Status"]),
            ("26", "Settlement Penalty", ["Settlement Penalty ID", "Penalty Amount", "Penalty Absorbed by Firm Indicator"]),
            ("13", "Servicing Error", ["Servicing Error ID", "Total Financial Impact"]),
            ("19", "Journal Entry", ["Journal ID", "Posting Date", "Posting Accounting Period", "Journal Status"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-214", "DP-216", "DP-211", "DP-191", "DP-192", "DP-013", "DP-004"],
        refresh="Intraday",
        timeliness="Hourly during the business day for incidents, classifications and notification deadlines (a service provider's Regulation S-P notice falls due within 72 hours); losses and the GL reconciliation by 7am ET on T+1",
        history="Every incident, source link, classification change (SCD type 2), notification and loss amount kept for at least 10 years after the loss event closes (Basel OPE25 loss data history)",
        classification="Restricted",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "Event stream"],
        dq_rules=[
            "Every Incident Source Record has exactly one typed source column populated, matching its Incident Source Type, and every Investment Breach or Risk Limit Exceedance source has a Cause Category or an Operational Loss Event (CD-244).",
            "Every incident with Incident Status Resolved or Closed and Near Miss Indicator = N has Basel Event Type Level 2, and Basel Event Type Level 1 is the parent of Level 2.",
            "Every Incident Regulatory Notification has an Incident Notification Regime, an Incident Notification Stage and a Notification Deadline Timestamp.",
            "Every Loss Event Amount row with an Amount Source column has Loss Amount equal to the source amount on the same business day (row rule, CD-244), and rows without one name a GL Evidence Journal.",
            "Every GL Evidence Journal resolves to a DP-191 Journal Entry, and the Loss Booking Date falls in that journal's Posting Accounting Period.",
            "No insurance recovery is counted twice: a 43 Insurance Claim names at most one Related Operational Loss Event, and Loss Amount Component = Third-Party Recovery is never an insurance recovery.",
        ],
        notes=("W1b re-point (CW-937): the notification grain is Incident Notification Regime x Incident Notification Stage (stage values Initial, Update or Amendment, Final); Notification Timeliness % and Overdue and Due Notifications slice by regime, and Major ICT Incidents Missing a Report Stage is rewritten as Notifications Missing a Final Stage. W1b: Incident Classification.DORA Major ICT-Related Incident Indicator and DORA Classification Timestamp dropped, no successor (CW-937), with the measure DORA Classification Lag Hours; Operational Incident.Impacted Business Services dropped, no successor (CW-937; important business services are UK-only), and no measure read it. "
               "Master concepts: Operational Incident, Incident Source Record, Incident Classification, Incident Regulatory "
               "Notification, Operational Loss Event and Loss Event Amount are mastered in 37 (CD-244, CD-245). The 41 IT Incident "
               "is read only as the cause and for detection and downtime facts; 41 holds no notification and no 37 reference, the "
               "link is the 37 Incident Source Record (CD-266). Source objects of 25, 27, 33, 26 and 13 are read only to check the "
               "derived copies on Loss Event Amount and Operational Loss Event; their own facts are published by their domains' "
               "products. Insurance recoveries come from 43 Insurance Claim, which holds the only link. Certified numbers: none. "
               "Money (CD-353, CD-361): Gross Operational Loss, Net Operational Loss and Client Impact Amount are operational "
               "measures that reconcile to the 19 GL evidence journal taken from DP-191 (Journal Entry and GL Posting); the "
               "semantic layer publishes certified expense only from DP-191, and this product never labels a loss as expense. "
               "Remediation status of incident issues is taken from DP-216 (CD-356). Product dimension from DP-004 (Impacted "
               "Products); Impacted Portfolios (18) is not published because it can identify an SMA client. Notification deadlines "
               "(Regulation S-P customer notice as soon as practicable and within 30 days of becoming aware; the 72-hour "
               "service-provider notice; state breach law deadlines) are held as Notification Deadline Timestamp; the product does "
               "not hard-code them. Restricted because incidents can carry whistleblowing sources, legal matters and security detail; "
               "Whistleblowing Source Indicator rows are suppressed from all but the operational risk view. PII = Y: Incident Owner "
               "is an employee key. Open SME questions (37 Q3, Q4, Q5, Q12): the loss threshold for a loss event and whether near "
               "misses and gains are recorded; whether trade and NAV errors always raise an incident; whether the CISO team or "
               "operational risk decides that a customer notification is required. Taxonomy gap: Loss Event Amount has "
               "no currency attribute; amounts are assumed to be in the loss legal entity's functional currency. Taxonomy gap: "
               "13 Shareholder Remediation has no direct link to a Loss Event Amount, so servicing-error losses reconcile only at "
               "Impact Source Servicing Error (Total Financial Impact). Decisions: CD-244, CD-245, CD-266, CD-293, CD-353, CD-356, CD-361."),
    ),
    # ==================================================================================================================
    "DP-216": dict(
        definition=("One tracker of every risk issue and its actions, whatever raised it: audit findings, regulatory examination "
                    "findings, compliance program reviews, operational incidents, failed control tests, model validations, "
                    "third-party risk assessments, resilience tests and vulnerability findings, with owners, due dates, "
                    "overdue actions and risk acceptances nearing expiry. Risk Issue and Issue Action are mastered in 37 and "
                    "hold the one typed link to their source (CD-247); source records are read for their keys, ratings and "
                    "dates only. It is the single remediation status of the firm (CD-356): open, overdue and accepted-risk "
                    "counts are computed here once and audit, compliance, technology, third-party oversight and the boards "
                    "read them from this product. It owns no certified metric family."),
        business_questions=[
            "How many issues are open, overdue or risk-accepted, by rating, source type, owning org unit and owner?",
            "Which actions are past due, and which issues had their due dates extended more than once?",
            "Which risk acceptances expire in the next 60 days, and which have already expired with the issue still open?",
            "Which high-severity findings, failed tests, rejected validations or failed resilience tests have no issue raised against them?",
            "Which issues are owned by someone who has left the firm?",
        ],
        grain="Risk issue (ISSUE-) x as-of date (daily status), with child grain risk issue x action sequence; SCD type 2 history of every issue and action",
        dimensions=["Risk issue", "Issue source type", "Issue rating", "Remediation status", "Issue status", "Issue owner and owning org unit (employee)",
                    "Related enterprise risk and risk category", "Action type", "Due date month", "Risk acceptance expiry month", "As-of date"],
        measures=[
            ("Remediation Status", "Per issue on the as-of date: Closed where Issue Status in (Resolved, Closed, Canceled); otherwise Risk Accepted where an Issue Action has Issue Action Type = Risk Acceptance, Risk Acceptance Approver populated and Risk Acceptance Expiry Date >= as-of date; Risk Acceptance Expired where the latest such action's Risk Acceptance Expiry Date < as-of date; Overdue where Issue Due Date < as-of date; else Open - On Track. The single remediation status of CD-356.",
             _u("37", "Risk Issue", "Risk Issue ID", "Issue Status", "Issue Due Date")
             + _u("37", "Issue Action", "Action Issue", "Issue Action Type", "Risk Acceptance Approver", "Risk Acceptance Expiry Date")),
            ("Open Issues", "Count of issues with Remediation Status not Closed, by Issue Rating, Issue Source Type and the Issue Owner's org unit.",
             _u("37", "Risk Issue", "Issue Rating", "Issue Source Type", "Issue Owner") + ["Remediation Status"]),
            ("Overdue Issues", "Count of issues with Remediation Status in (Overdue, Risk Acceptance Expired), by Issue Rating and Issue Source Type, aged in days past Issue Due Date (1-30, 31-90, over 90).",
             _u("37", "Risk Issue", "Issue Rating", "Issue Source Type", "Issue Due Date") + ["Remediation Status"]),
            ("Overdue Actions", "Count of Issue Actions with no Issue Action Completed Date and Issue Action Due Date < as-of date, by Issue Action Type and Issue Action Owner.",
             _u("37", "Issue Action", "Action Issue", "Issue Action Sequence", "Issue Action Type", "Issue Action Owner",
                "Issue Action Due Date", "Issue Action Completed Date")),
            ("Risk-Accepted Issues", "Count of issues with Remediation Status = Risk Accepted, by Issue Rating; and Risk Acceptances Expiring (60 Days): those whose Risk Acceptance Expiry Date falls within 60 days of the as-of date.",
             _u("37", "Issue Action", "Risk Acceptance Expiry Date") + _u("37", "Risk Issue", "Issue Rating") + ["Remediation Status"]),
            ("Due Date Extensions", "Count of issues whose Issue Due Date in the SCD type 2 history is later than its first recorded value, and the share of open issues extended twice or more, by Issue Rating.",
             _u("37", "Risk Issue", "Risk Issue ID", "Issue Due Date", "Issue Rating")),
            ("Issue Age Days", "As-of date - the date the issue first appears in this product's SCD type 2 history (the 37 Risk Issue has no raised date), for open issues; median by Issue Source Type.",
             _u("37", "Risk Issue", "Risk Issue ID", "Issue Source Type") + ["Remediation Status"]),
            ("Untracked Source Items", "Count of source records that call for remediation and are named by no Risk Issue: Audit Findings with Audit Finding Rating High or Critical; Examination Findings with Finding Severity High or Critical; Control Tests with Control Test Result = Ineffective; Model Validations with Model Validation Outcome Rejected or Approved with Conditions; Third-Party Risk Assessments with Third-Party Residual Risk Rating High, Critical or Prohibited; Resilience Tests with Tolerance Met Indicator = N; Vulnerability Findings with Vulnerability Remediation Status = Risk Accepted.",
             _u("37", "Risk Issue", "Source Audit Finding", "Source Examination Finding", "Source Control Test", "Source Model Validation",
                "Source Third-Party Risk Assessment", "Source Resilience Test", "Source Vulnerability Finding")
             + _u("37", "Audit Finding", "Audit Finding ID", "Audit Finding Rating")
             + _u("38", "Examination Finding", "Finding Examination", "Finding Sequence", "Finding Severity")
             + _u("37", "Control Test", "Tested Control", "Control Test Date", "Control Test Result")
             + _u("37", "Model Validation", "Validated Model", "Model Validation Sequence", "Model Validation Outcome")
             + _u("37", "Third-Party Risk Assessment", "Third-Party Risk Assessment Reference", "Third-Party Residual Risk Rating")
             + _u("37", "Resilience Test", "Resilience Test Reference", "Resilience Test Date", "Tolerance Met Indicator")
             + _u("41", "Vulnerability Finding", "Vulnerability Finding ID", "Vulnerability Remediation Status")),
            ("Issues With Departed Owner", "Open issues whose Issue Owner, or open actions whose Issue Action Owner, has Employment Status = Terminated in DP-192.",
             _u("37", "Risk Issue", "Issue Owner") + _u("37", "Issue Action", "Issue Action Owner")
             + _u("20", "Employee", "Employee ID", "Employment Status") + ["Remediation Status"]),
        ],
        inputs=[
            ("37", "Risk Issue", ["Risk Issue ID", "Issue Description", "Issue Source Type", "Source Audit Finding",
                                  "Source Examination Finding", "Source Compliance Program Review", "Source Operational Incident",
                                  "Source Control Test", "Source Model Validation", "Source Third-Party Risk Assessment",
                                  "Source Resilience Test", "Source Vulnerability Finding", "Issue Rating", "Issue Related Risk",
                                  "Issue Owner", "Issue Due Date", "Issue Status"]),
            ("37", "Issue Action", ["Action Issue", "Issue Action Sequence", "Issue Action Type", "Issue Action Description",
                                    "Issue Action Owner", "Issue Action Due Date", "Issue Action Completed Date",
                                    "Risk Acceptance Approver", "Risk Acceptance Expiry Date"]),
            ("37", "Audit Finding", ["Audit Finding ID", "Audit Finding Rating", "Audit Finding Due Date"]),
            ("38", "Examination Finding", ["Finding Examination", "Finding Sequence", "Finding Severity", "Response Due Date"]),
            ("38", "Compliance Program Review", ["Program Review Type", "Reviewed Entity", "Review Report Date"]),
            ("37", "Operational Incident", ["Operational Incident ID", "Incident Severity", "Incident Discovery Date"]),
            ("37", "Control Test", ["Tested Control", "Control Test Date", "Control Test Sequence", "Control Test Result"]),
            ("37", "Model Validation", ["Validated Model", "Model Validation Sequence", "Model Validation Completed Date",
                                        "Model Validation Outcome"]),
            ("37", "Third-Party Risk Assessment", ["Third-Party Risk Assessment Reference", "Assessed Supplier Engagement",
                                                   "Third-Party Assessment Completed Date", "Third-Party Residual Risk Rating"]),
            ("37", "Resilience Test", ["Resilience Test Reference", "Resilience Test Date", "Tolerance Met Indicator"]),
            ("41", "Vulnerability Finding", ["Vulnerability Finding ID", "Vulnerability Severity", "Vulnerability Detected Date",
                                             "Remediation Due Date", "Vulnerability Remediation Status"]),
            ("37", "Enterprise Risk", ["Risk ID", "Risk Category", "Risk Owning Org Unit"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
        ],
        upstream=["DP-214", "DP-212", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day, with status as of the prior day's close",
        history="SCD type 2 on every issue and action (due dates, status, owner, acceptance) since the GRC platform go-live; daily status snapshots kept 2 years and month-end snapshots 10 years",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Risk Issue has exactly one typed source column populated that matches its Issue Source Type, except Issue Source Type = Self-Identified, which has none.",
            "Every open issue has Issue Rating, Issue Owner and Issue Due Date populated, and Issue Owner resolves to an employee in DP-192.",
            "Every Issue Action with Issue Action Type = Risk Acceptance has Risk Acceptance Approver and Risk Acceptance Expiry Date, and the approver is not the Issue Owner.",
            "No issue with Issue Status Resolved or Closed has an Issue Action with no Issue Action Completed Date other than a Risk Acceptance action.",
            "Every source key resolves: Source Audit Finding to an Audit Finding, Source Model Validation to a DP-212 Model Validation, Source Examination Finding to a 38 Examination Finding and Source Vulnerability Finding to a 41 Vulnerability Finding.",
            "Remediation Status is published once per issue per as-of date, and the counts consumed by DP-215, DP-217, DP-218 and DP-219 equal this product's counts for the same filter.",
        ],
        notes=("Master concepts: Risk Issue and Issue Action are mastered in 37; the issue holds the only link to its source "
               "(CD-247; 38 and 41 dropped their reverse links). Source objects are read for keys, ratings and dates only; "
               "source-specific status stays with its source product (CD-356): Finding Closure Validation with DP-218, "
               "Vulnerability Remediation Status with DP-232, Examination response tracking with DP-223, Model Validation outcome "
               "with DP-212. This product computes Remediation Status once; DP-215, DP-217, DP-218, DP-219, DP-223, DP-224, DP-232 "
               "and the Wave E5 Enterprise Risk & Control view take open, overdue and accepted-risk counts from it and compute none "
               "of their own (CD-356). Source records of products that list this one upstream (DP-218, DP-219, DP-223, DP-232) are "
               "read from their 37, 38 and 41 masters, not through those products, to avoid cycles. Model validations are the "
               "DP-212 registry's (CD-294). Certified numbers: none. Code values used: Shared Case Status (Resolved, Closed, "
               "Canceled), Shared Severity (High, Critical), Shared Risk Rating (High, Critical, Prohibited), Issue Action Type "
               "Risk Acceptance. PII = Y: Issue Owner, Issue Action Owner and Risk Acceptance Approver are employee keys. Open SME "
               "question (37 Q2): which GRC platform holds issues and whether Internal Audit uses the same platform. Taxonomy gap: "
               "Risk Issue has no raised (identified) date and no original due date, so Issue Age Days and Due Date Extensions are "
               "derived from this product's SCD type 2 history and start at the product go-live. Taxonomy gap: Risk Issue has no "
               "closed date; closure timing is taken from the Issue Status change in history. Taxonomy gap: 38 Examination Finding "
               "has no finding date, so untracked examination findings are aged from Response Due Date. Decisions: CD-243, CD-247, "
               "CD-253, CD-270, CD-294, CD-356."),
    ),
    # ==================================================================================================================
    # DP-217 re-specified at WP1 in specs_w1c_fop_corp.py
    # ==================================================================================================================
    "DP-218": dict(
        definition=("The audit universe with inherent audit risk and audit cycle, the audit plan approved by the audit committee "
                    "and its delivery, engagements with their ratings, findings by rating and age, and closure validation "
                    "outcomes, joined to the remediation status of the risk issue each finding raised (from DP-216) and to the "
                    "residual risk of the org units it covers (from DP-214). The Internal Audit family of 37 is owned by the "
                    "Chief Audit Executive (CD-247), so this product is too, and the audit opinion is not reshaped by the risk "
                    "products it audits. It gives the Chief Audit Executive and the audit committee coverage against cycle, plan "
                    "completion and overdue or reopened findings. It owns no certified metric family."),
        business_questions=[
            "Which auditable entities are past their audit cycle, and how much of the high-risk universe was covered in the cycle?",
            "How far has this year's approved audit plan been delivered, and how long do engagements take from fieldwork to report?",
            "How many findings are open by rating and age, which are past due, and which failed closure validation?",
            "Which findings have no management issue, and which did management close without Internal Audit validating the closure?",
            "Which org units carry high residual risk but have not been audited within their cycle?",
        ],
        grain="Audit finding (AUDF-) with its engagement (AUDIT-) and plan, plus auditable entity x effective period for coverage; child grain finding x validation attempt sequence",
        dimensions=["Auditable entity and type", "Inherent audit risk", "Covered org unit, legal entity and third party", "Audit plan year and version",
                    "Audit engagement and type", "Overall audit rating", "Audit finding rating", "Finding validation outcome",
                    "Remediation status (from DP-216)", "Report issued month", "Finding due month", "Co-sourced provider"],
        measures=[
            ("Coverage Overdue Entities", "Auditable Entities effective on the as-of date whose latest Audit Report Issued Date among engagements listing them in Covered Auditable Entities is more than Audit Cycle Months before the as-of date, or that have none; by Inherent Audit Risk.",
             _u("37", "Auditable Entity", "Auditable Entity Code", "Inherent Audit Risk", "Audit Cycle Months",
                "Auditable Entity Effective From", "Auditable Entity Effective To")
             + _u("37", "Audit Engagement", "Covered Auditable Entities", "Audit Report Issued Date")),
            ("Cycle Coverage %", "Auditable Entities effective on the as-of date that are not Coverage Overdue Entities / Auditable Entities effective on the as-of date, by Inherent Audit Risk.",
             _u("37", "Auditable Entity", "Auditable Entity Code", "Inherent Audit Risk") + ["Coverage Overdue Entities"]),
            ("Plan Approved by Audit Committee", "Y where the latest Audit Plan Version of the year is the Subject Audit Plan of a 39 Corporate Resolution Subject Link whose Corporate Resolution has an approving Corporate Resolution Outcome; the Corporate Resolution Effective Date is the approval date.",
             _u("37", "Audit Plan", "Audit Plan Year", "Audit Plan Version")
             + _u("39", "Corporate Resolution Subject Link", "Linked Corporate Resolution", "Corporate Resolution Subject Type", "Subject Audit Plan")
             + _u("39", "Corporate Resolution", "Corporate Resolution ID", "Corporate Resolution Outcome", "Corporate Resolution Effective Date")),
            ("Plan Completion %", "Engagements whose Engagement Audit Plan is the latest approved version for the year with Audit Report Issued Date on or before the as-of date / engagements of that plan version.",
             _u("37", "Audit Engagement", "Audit Engagement ID", "Engagement Audit Plan", "Audit Report Issued Date")
             + ["Plan Approved by Audit Committee"]),
            ("Engagement Rating Distribution", "Count of engagements with an Audit Report Issued Date in the period by Overall Audit Rating and Audit Engagement Type.",
             _u("37", "Audit Engagement", "Audit Report Issued Date", "Overall Audit Rating", "Audit Engagement Type")),
            ("Report Cycle Days", "Audit Report Issued Date - Fieldwork Start Date in calendar days; median by Audit Engagement Type.",
             _u("37", "Audit Engagement", "Fieldwork Start Date", "Audit Report Issued Date", "Audit Engagement Type")),
            ("Open Findings", "Count of Audit Findings with no Finding Closure Validation of Finding Validation Outcome in (Validated - Closed, Closed - Risk Accepted), by Audit Finding Rating and age in days since the engagement's Audit Report Issued Date (0-90, 91-180, over 180).",
             _u("37", "Audit Finding", "Audit Finding ID", "Finding Engagement", "Audit Finding Rating")
             + _u("37", "Finding Closure Validation", "Validated Finding", "Finding Validation Outcome")
             + _u("37", "Audit Engagement", "Audit Engagement ID", "Audit Report Issued Date")),
            ("Overdue Findings", "Open Findings with Audit Finding Due Date before the as-of date, by Audit Finding Rating.",
             _u("37", "Audit Finding", "Audit Finding Due Date", "Audit Finding Rating") + ["Open Findings"]),
            ("Closure Validation Failure Rate", "Finding Closure Validation attempts with Finding Validation Outcome = Not Validated - Remains Open / attempts with Closure Validation Date in the period; findings with two or more failed attempts listed.",
             _u("37", "Finding Closure Validation", "Validated Finding", "Validation Attempt Sequence", "Closure Validation Date",
                "Finding Validation Outcome")),
            ("Findings Without Management Issue", "Open Findings that no Risk Issue names as Source Audit Finding (from DP-216).",
             _u("37", "Risk Issue", "Risk Issue ID", "Source Audit Finding") + ["Open Findings"]),
            ("Management-Closed Not Validated", "Open Findings whose Risk Issue has Remediation Status = Closed in DP-216 (Issue Status Resolved or Closed) with no Validated - Closed attempt, aged since the issue closed.",
             _u("37", "Risk Issue", "Source Audit Finding", "Issue Status")
             + _u("37", "Finding Closure Validation", "Finding Validation Outcome") + ["Open Findings"]),
            ("Findings With Overdue Remediation", "Open Findings whose Risk Issue has Remediation Status Overdue or Risk Acceptance Expired in DP-216, by Audit Finding Rating.",
             _u("37", "Risk Issue", "Source Audit Finding", "Issue Status", "Issue Due Date")
             + _u("37", "Audit Finding", "Audit Finding Rating") + ["Open Findings"]),
            ("High-Risk Units Not Audited in Cycle", "Org units that own an active Enterprise Risk whose latest Residual Risk Rating (from DP-214) is High or Critical and that are the Covered Org Unit of a Coverage Overdue Entity or of no Auditable Entity.",
             _u("37", "Enterprise Risk", "Risk ID", "Risk Owning Org Unit", "Enterprise Risk Status")
             + _u("37", "Risk Assessment", "Assessed Risk", "Risk Assessment Date", "Residual Risk Rating")
             + _u("37", "Auditable Entity", "Covered Org Unit") + ["Coverage Overdue Entities"]),
        ],
        inputs=[
            ("37", "Auditable Entity", ["Auditable Entity Code", "Auditable Entity Name", "Auditable Entity Type", "Covered Org Unit",
                                        "Covered Legal Entity", "Covered Third Party", "Inherent Audit Risk", "Audit Cycle Months",
                                        "Auditable Entity Effective From", "Auditable Entity Effective To"]),
            ("37", "Audit Plan", ["Audit Plan Year", "Audit Plan Version", "Audit Plan Approval Status", "Co-Sourced Provider"]),
            ("37", "Audit Engagement", ["Audit Engagement ID", "Engagement Audit Plan", "Audit Engagement Type", "Covered Auditable Entities",
                                        "Engagement Lead", "Fieldwork Start Date", "Audit Report Issued Date", "Overall Audit Rating"]),
            ("37", "Audit Finding", ["Audit Finding ID", "Finding Engagement", "Audit Finding Rating", "Finding Root Cause",
                                     "Audit Finding Due Date"]),
            ("37", "Finding Closure Validation", ["Validated Finding", "Validation Attempt Sequence", "Closure Validated By",
                                                  "Closure Validation Date", "Finding Validation Outcome"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Source Audit Finding", "Issue Status", "Issue Due Date"]),
            ("37", "Enterprise Risk", ["Risk ID", "Risk Owning Org Unit", "Enterprise Risk Status"]),
            ("37", "Risk Assessment", ["Assessed Risk", "Risk Assessment Date", "Residual Risk Rating"]),
            ("39", "Corporate Resolution Subject Link", ["Linked Corporate Resolution", "Corporate Resolution Subject Type",
                                                         "Subject Audit Plan"]),
            ("39", "Corporate Resolution", ["Corporate Resolution ID", "Corporate Resolution Outcome", "Corporate Resolution Effective Date"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            ("02", "Party", ["Party ID", "Party Display Name"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-216", "DP-214", "DP-240", "DP-192", "DP-013"],
        refresh="Weekly",
        timeliness="By 8am ET each Monday; the audit committee pack snapshot is locked 10 business days before each committee meeting",
        history="SCD type 2 on the audit universe and plan versions; every engagement, finding and validation attempt kept for at least 7 years after the finding closes; committee pack snapshots kept 10 years",
        classification="Restricted",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Audit Finding names a Finding Engagement with an Audit Report Issued Date, and Audit Finding Due Date is after that date.",
            "Every Audit Engagement names an Engagement Audit Plan and at least one Covered Auditable Entity that resolves to an Auditable Entity effective on the Fieldwork Start Date.",
            "Audit Plan Approval Status (the 37 derived copy) equals the approval implied by the 39 Corporate Resolution linked through Subject Audit Plan on every run.",
            "Finding Validation Outcome = Closed - Risk Accepted only where the finding's Risk Issue has an Issue Action of Issue Action Type Risk Acceptance (DP-216).",
            "Validation Attempt Sequence increases with Closure Validation Date for each finding, and no attempt follows a Validated - Closed attempt.",
            "Closure Validated By is never the Issue Owner of the finding's Risk Issue.",
        ],
        notes=("Master concepts: Auditable Entity, Audit Plan, Audit Engagement, Audit Finding and Finding Closure Validation form the "
               "37 Internal Audit family owned by the Chief Audit Executive (CD-247); management remediation is the 37 Risk Issue "
               "whose source is the finding, and only a Finding Closure Validation closes a finding. Remediation status (open, "
               "overdue, risk accepted, closed) is taken from DP-216 and not recomputed (CD-356); finding validation status stays "
               "here as source-specific status. Audit committee approval of the plan is read from its master, 39 Corporate "
               "Resolution through Subject Audit Plan; the 37 Audit Plan Approval Status copy is read only for the DQ check. "
               "Residual risk by org unit is read from DP-214 (enterprise risk and assessment) for the coverage measure. Covered "
               "Third Party and Co-Sourced Provider are 02 party keys resolved through DP-240. Certified numbers: none. Operating "
               "model (CD-297): co-sourced audit does not change the grain; Co-Sourced Provider on Audit Plan marks provider-"
               "delivered plans. Independence: classified Restricted, published outside the firm-wide BI semantic model and "
               "accessible to Internal Audit and the audit committee (brief §8 Q8). PII = Y: Engagement Lead and Closure "
               "Validated By are employee keys. Open SME questions (37 Q1, Q11): whether Internal Audit becomes its own Data "
               "Domain; whether the audit universe is shared with the fund boards' audit committees (35). Taxonomy gap: Audit Plan "
               "has no planned engagement list, planned dates or engagement count (Planned Engagement Count was trimmed), so Plan "
               "Completion % counts only engagements already linked to the plan version. Taxonomy gap: co-sourcing is recorded on "
               "the plan, not on the engagement, so the provider-delivered share of engagements cannot be measured. Taxonomy gap: "
               "Audit Finding has no issued or agreed date of its own; age runs from the engagement's Audit Report Issued Date. "
               "Decisions: CD-247, CD-297, CD-356."),
    ),
    # ==================================================================================================================
    "DP-219": dict(
        definition=("One oversight view per supplier engagement: the 40 inherent criticality tier beside the 37 residual risk "
                    "rating and its risk domain results (never blended, CD-248), the 40 performance reviews and service level "
                    "results with service credits for services no specialized domain measures, software license true-up "
                    "exposure from 41, the notice and expiry dates of the governing 39 contract, the outsourcing flags "
                    "and exit plan from DP-220, and the open third-party issues from DP-216. It lets vendor management and "
                    "third-party risk prepare every renewal and exit decision before the notice deadline. It is the enterprise "
                    "product of which DP-073 Data Vendor Risk & Renewals is the data-vendor view (CD-298, CD-350) and which "
                    "DP-176 Fund Service Provider Oversight reads for engagement, tier, risk, contract and exit (CD-333, CD-355). "
                    "It owns no certified metric family; service credit amounts reconcile to 19 payable credit notes (CD-353)."),
        business_questions=[
            "Which engagements reach a renewal or termination notice deadline in the next 90 days, and which of them carry high residual risk, weak performance or overdue issues?",
            "How are active engagements spread across criticality tier and residual risk rating, and which critical engagements have no current risk assessment?",
            "Which critical or important outsourcings depend on a provider that is not exitable, not substitutable, or has an untested exit plan?",
            "Which suppliers missed contracted service levels, what service credits are due, and have the credits been received?",
            "Where are we under-licensed on software, and under which supplier contracts?",
            "For each data vendor and fund service provider, what tier, residual risk, contract dates and outsourcing flags do DP-073 and DP-176 read?",
        ],
        grain="Supplier engagement (VENG-) x as-of date (current oversight view), with child grains engagement x third-party risk assessment x risk domain, engagement x review period, contract x service level metric x measurement period, and contract x key date; month-end snapshots",
        dimensions=["Supplier (party) and supplier engagement", "Buying legal entity", "Business owner (employee)", "Procurement category",
                    "Third-party criticality tier", "Residual risk rating (37)", "Data vendor inherent risk rating (14)",
                    "Third-party risk domain", "Specialized provider type (data vendor, servicing, custody, fund service provider)",
                    "Governing contract and contract family", "Key date type and month", "Critical or important outsourcing indicator",
                    "Exit strategy type", "Performance rating", "Service level metric", "As-of date"],
        measures=[
            ("Active Engagements by Tier and Residual Rating", "Count of Supplier Engagements with Engagement Status = Active on the as-of date by the Third-Party Criticality Tier effective on that date (DP-210) and the Third-Party Residual Risk Rating of the latest Third-Party Risk Assessment of the engagement (highest Third-Party Assessment Completed Date), as a matrix; the two are never combined into one rating (CD-248).",
             _u("40", "Supplier Engagement", "Supplier Engagement ID", "Engagement Status")
             + _u("40", "Supplier Risk Tiering", "Tiered Engagement", "Third-Party Criticality Tier", "Tier Effective From", "Tier Effective To")
             + _u("37", "Third-Party Risk Assessment", "Assessed Supplier Engagement", "Third-Party Residual Risk Rating",
                  "Third-Party Assessment Completed Date")),
            ("Critical Engagements Without Current Assessment", "Active engagements in Tier 1 - Critical or Tier 2 - High with no Third-Party Risk Assessment completed in the 12 months to the as-of date (annual reassessment per the tier list), or whose latest assessment's Third-Party Next Assessment Due Date is before the as-of date.",
             _u("37", "Third-Party Risk Assessment", "Assessed Supplier Engagement", "Third-Party Assessment Completed Date",
                "Third-Party Next Assessment Due Date")
             + ["Active Engagements by Tier and Residual Rating"]),
            ("High Residual Risk Engagements", "Active engagements whose latest Third-Party Residual Risk Rating is High, Critical or Prohibited, by tier; Prohibited listed separately for exit.",
             _u("37", "Third-Party Risk Assessment", "Third-Party Residual Risk Rating") + ["Active Engagements by Tier and Residual Rating"]),
            ("Risk Domain Hotspots", "Count of Third-Party Risk Domain Results with Domain Risk Rating High, Critical or Prohibited on the latest assessment of active engagements, by Third-Party Risk Domain; results with no Domain Evidence Assurance Report counted separately.",
             _u("37", "Third-Party Risk Domain Result", "Result Assessment", "Third-Party Risk Domain", "Domain Risk Rating",
                "Domain Evidence Assurance Report")
             + _u("37", "Third-Party Risk Assessment", "Third-Party Risk Assessment Reference")),
            ("Open and Overdue Third-Party Issues", "Count of Risk Issues whose Source Third-Party Risk Assessment assessed the engagement, with Remediation Status not Closed, and those Overdue or Risk Acceptance Expired, taken from DP-216 (CD-356).",
             _u("37", "Risk Issue", "Risk Issue ID", "Source Third-Party Risk Assessment", "Issue Rating", "Issue Status", "Issue Due Date")
             + _u("37", "Third-Party Risk Assessment", "Third-Party Risk Assessment Reference", "Assessed Supplier Engagement")),
            ("Days to Notice Deadline", "Earliest Key Date Value of the engagement's governing contracts' Contract Key Dates with Key Date Type in (Renewal Notice Deadline, Termination Notice Deadline) and Key Date Action Status = Open, minus the as-of date. Governing contracts are the Profiled Contracts of Supplier Contract Profiles listing the engagement in Contracted Engagements, and for data-vendor engagements the 39 Contracts whose Typed Contract Link names a Data License Agreement of which the Specialized Data Vendor's party is Licensor.",
             _u("39", "Contract Key Date", "Key Date Contract", "Key Date Type", "Key Date Value", "Key Date Action Status")
             + _u("40", "Supplier Contract Profile", "Profiled Contract", "Contracted Engagements")
             + _u("39", "Typed Contract Link", "Typed Record Type", "Linked Data License Agreement")
             + _u("14", "Data License Agreement", "Data License Agreement ID", "Licensor")
             + _u("14", "Data Vendor", "Vendor Party")
             + _u("40", "Supplier Engagement", "Specialized Data Vendor")),
            ("Contracts Expiring (180 Days)", "Active engagements whose governing 39 Contract has Contract Status = Active and Contract Expiry Date within 180 days of the as-of date, by tier, with Total Contract Value shown.",
             _u("39", "Contract", "Contract ID", "Contract Status", "Contract Expiry Date")
             + _u("40", "Supplier Contract Profile", "Profiled Contract", "Total Contract Value")),
            ("Renewal Attention Flag", "Y where Days to Notice Deadline <= 90 and any of: latest Third-Party Residual Risk Rating High or above, latest Overall Performance Rating in (Partially Meets, Does Not Meet), Service Level Attainment % below 95 over the trailing 12 months, or at least one Overdue third-party issue from DP-216.",
             _u("37", "Third-Party Risk Assessment", "Third-Party Residual Risk Rating")
             + _u("40", "Supplier Performance Review", "Overall Performance Rating")
             + ["Days to Notice Deadline", "Service Level Attainment %", "Open and Overdue Third-Party Issues"]),
            ("Exit Readiness Gap", "Active engagements that support a critical or important function (an active Outsourcing Arrangement with Critical or Important Outsourcing Indicator = Y, from DP-220) and where any of: latest Exit Feasibility = Not Exitable, no Exit Plan on the arrangement (Exit Strategy Type blank), or Exit Plan Last Tested Date blank or more than 12 months old.",
             _u("40", "Outsourcing Arrangement", "Outsourcing Arrangement ID", "Outsourcing Engagement",
                "Critical or Important Outsourcing Indicator", "Outsourcing Arrangement Status")
             + _u("40", "Exit Plan", "Exit Strategy Type", "Exit Plan Last Tested Date")
             + _u("37", "Third-Party Risk Assessment", "Exit Feasibility")),
            ("Performance Below Expectations", "Active engagements without a Specialized Data Vendor, Specialized Servicing Provider Engagement or Specialized Custody Provider Profile whose latest Supplier Performance Review has Overall Performance Rating in (Partially Meets, Does Not Meet); and Tier 1 or Tier 2 engagements of that kind with no review whose Review Period End is in the last 12 months.",
             _u("40", "Supplier Performance Review", "Reviewed Engagement", "Review Period End", "Overall Performance Score",
                "Overall Performance Rating")
             + _u("40", "Supplier Engagement", "Specialized Data Vendor", "Specialized Servicing Provider Engagement",
                  "Specialized Custody Provider Profile")
             + ["Active Engagements by Tier and Residual Rating"]),
            ("Service Level Attainment %", "Service Level Measurement Results with Service Level Met Indicator = Y / results with Measurement Period End in the trailing 12 months, by engagement (through the Measured Contract's Supplier Contract Profile) and Measured Metric Name; only 40 Contracted Service Levels, which exist where no specialized domain measures the service (CD-355).",
             _u("40", "Service Level Measurement Result", "Measured Contract", "Measured Metric Name", "Measured Service Level Effective From",
                "Measurement Period End", "Actual Value", "Service Level Met Indicator")
             + _u("40", "Contracted Service Level", "Service Level Contract", "Service Level Metric Name", "Service Level Target",
                  "Service Level Effective From")),
            ("Service Credits Due", "Sum of Service Credit Due Amount on Service Level Measurement Results with Measurement Period End in the period, by supplier and engagement.",
             _u("40", "Service Level Measurement Result", "Measured Contract", "Measurement Period End", "Service Credit Due Amount")),
            ("Service Credits Received vs Due %", "Sum of Invoice Gross Amount (as a positive value) of 19 Payable Invoices with Payable Document Type = Credit Note from the same Supplier, with Invoice Date from the start of the period to 90 days after its end / Service Credits Due for the period; the reconciliation of service credits to 19 (CD-353).",
             _u("19", "Payable Invoice", "Payable Invoice ID", "Payable Document Type", "Supplier", "Invoice Date", "Invoice Gross Amount")
             + _u("40", "Supplier Engagement", "Engaged Supplier") + ["Service Credits Due"]),
            ("License True-Up Exposure", "Count of 41 Software License Positions at the latest License Measurement Date with License Compliance Gap < 0 (under-licensed) whose Governing Software Contract is a governing contract of the engagement, and the sum of the negative gaps by Licensing Metric.",
             _u("41", "Software License Position", "Licensed Application", "Licensing Metric", "License Measurement Date",
                "Entitled Quantity", "Deployed Quantity", "License Compliance Gap", "Governing Software Contract")
             + _u("40", "Supplier Contract Profile", "Profiled Contract", "Contracted Engagements")),
            ("Data Vendor Rating Divergence", "Data-vendor engagements (Specialized Data Vendor populated) whose 14 Vendor Risk Assessment Inherent Risk Rating is Low or Medium while the latest 37 Third-Party Residual Risk Rating is High or above, or the reverse; the 14 rating is shown beside the 40 tier and the 37 rating, never merged (CD-248, CD-350).",
             _u("14", "Vendor Risk Assessment", "Risk Assessment ID", "Assessed Vendor", "Inherent Risk Rating")
             + _u("14", "Data Vendor", "Vendor Party")
             + _u("40", "Supplier Engagement", "Specialized Data Vendor")
             + _u("37", "Third-Party Risk Assessment", "Third-Party Residual Risk Rating")),
        ],
        inputs=[
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engaged Supplier", "Service Description", "Engagement Business Owner",
                                           "Engagement Buying Entity", "Fund-Paid Indicator", "Specialized Data Vendor",
                                           "Specialized Servicing Provider Engagement", "Specialized Custody Provider Profile",
                                           "Fund Service Provider Role", "Engagement Start Date", "Engagement End Date",
                                           "Engagement Status"]),
            ("40", "Supplier Risk Tiering", ["Tiered Engagement", "Third-Party Criticality Tier", "Criticality Drivers", "Due-Diligence Depth",
                                             "Tier Effective From", "Tier Effective To"]),
            ("40", "Supplier Category Assignment", ["Categorized Engagement", "Procurement Category", "Category Effective From",
                                                    "Category Effective To"]),
            ("40", "Supplier Contract Profile", ["Profiled Contract", "Contracted Engagements", "Total Contract Value",
                                                 "Contract Pricing Model", "Exit Assistance Period"]),
            ("37", "Third-Party Risk Assessment", ["Third-Party Risk Assessment Reference", "Assessed Supplier Engagement",
                                                   "Assessed Third Party", "Third-Party Assessment Type",
                                                   "Third-Party Residual Risk Rating", "Exit Feasibility", "Third-Party Assessor",
                                                   "Third-Party Assessment Completed Date", "Third-Party Next Assessment Due Date"]),
            ("37", "Third-Party Risk Domain Result", ["Result Assessment", "Third-Party Risk Domain", "Domain Risk Rating",
                                                      "Domain Evidence Assurance Report"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Source Third-Party Risk Assessment", "Issue Rating", "Issue Status", "Issue Due Date"]),
            ("40", "Supplier Performance Review", ["Reviewed Engagement", "Review Period End", "Scored Dimensions",
                                                   "Overall Performance Score", "Overall Performance Rating"]),
            ("40", "Contracted Service Level", ["Service Level Contract", "Service Level Metric Name", "Service Level Target",
                                                "Service Level Unit", "Service Credit Rate", "Service Level Effective From",
                                                "Service Level Effective To"]),
            ("40", "Service Level Measurement Result", ["Measured Contract", "Measured Metric Name", "Measured Service Level Effective From",
                                                        "Measurement Period End", "Actual Value", "Service Level Met Indicator",
                                                        "Service Credit Due Amount"]),
            ("39", "Contract", ["Contract ID", "Contract Family", "Contract Status", "Contract Effective Date", "Contract Expiry Date",
                                "Contracting Entity"]),
            ("39", "Contract Key Date", ["Key Date Contract", "Key Date Type", "Key Date Sequence", "Key Date Value",
                                         "Key Date Action Status"]),
            ("39", "Typed Contract Link", ["Typed Record Type", "Linked Data License Agreement"]),
            ("40", "Outsourcing Arrangement", ["Outsourcing Arrangement ID", "Outsourcing Engagement",
                                               "Critical or Important Outsourcing Indicator", "Outsourcing Arrangement Status"]),
            ("40", "Exit Plan", ["Exit Strategy Type", "Exit Plan Last Tested Date"]),
            ("41", "Software License Position", ["Licensed Application", "Licensing Metric", "License Measurement Date", "Entitled Quantity",
                                                 "Deployed Quantity", "License Compliance Gap", "Governing Software Contract"]),
            ("14", "Data Vendor", ["Vendor Party"]),
            ("14", "Vendor Risk Assessment", ["Risk Assessment ID", "Assessed Vendor", "Inherent Risk Rating"]),
            ("14", "Data License Agreement", ["Data License Agreement ID", "Licensor"]),
            ("19", "Payable Invoice", ["Payable Invoice ID", "Payable Document Type", "Supplier", "Invoice Date", "Invoice Gross Amount"]),
            ("02", "Party", ["Party ID", "Party Display Name", "Party Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-210", "DP-213", "DP-211", "DP-216", "DP-220", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; the month-end oversight snapshot is locked on business day 5",
        history="Monthly snapshots kept 10 years; every assessment, domain result, performance review, service level result and key date kept for the life of the engagement plus 7 years; tier and contract links as SCD type 2 from DP-210 and DP-213",
        classification="Restricted - Commercial Terms",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every active engagement has exactly one Supplier Risk Tiering effective on the as-of date (from DP-210) and, in Tier 1 - Critical or Tier 2 - High, a Third-Party Risk Assessment with Third-Party Residual Risk Rating populated.",
            "Every Third-Party Risk Assessment's Assessed Supplier Engagement resolves to a DP-210 engagement whose Engaged Supplier equals Assessed Third Party.",
            "No 40 Contracted Service Level exists on a contract whose engagement has a Specialized Data Vendor, Specialized Servicing Provider Engagement or Specialized Custody Provider Profile (CD-355; those service levels are measured in 14, 13 and 28).",
            "Every Service Level Measurement Result resolves to a Contracted Service Level by Measured Contract, Measured Metric Name and Measured Service Level Effective From, and Service Credit Due Amount is populated only where Service Level Met Indicator = N.",
            "Every active data-vendor engagement resolves to a governing 39 Contract through a Data License Agreement whose Licensor is the vendor's party, so DP-073 receives contract dates for every data vendor row.",
            "Tier, residual rating and the 14 inherent rating are published in separate columns and no column combines them.",
        ],
        notes=("W1b: ICT Register Arrangement Header and ICT Register of Information Entry dropped, no successor (CW-940; the DORA register of information leaves 40). W1b re-point (CW-940): Exit Readiness Gap reads the exit plan from the 40 Exit Plan group of the Outsourcing Arrangement (Exit Strategy Type blank = no plan) instead of the register's Exit Plan Exists Indicator; the DORA Substitutability test is dropped with the header, and the critical or important function test reads only Outsourcing Arrangement.Critical or Important Outsourcing Indicator. Taxonomy gap: no 40 substitutability attribute for non-data-vendor engagements (14 Vendor Risk Assessment.Substitutability covers data vendors only). "
               "Master concepts read, not remastered: Supplier Engagement and Supplier Risk Tiering (40, through DP-210), "
               "Third-Party Risk Assessment and Domain Result (37, the enterprise register of CD-248), Contract and Contract Key Date "
               "(39, through DP-213). CD-248: the 40 tier and the 37 residual rating are shown side by side and never copied into "
               "each other; the 14 Vendor Risk Assessment Inherent Risk Rating stays mastered in 14 and is shown beside them for "
               "data vendors. View boundary (CD-298, CD-350): DP-073 Data Vendor Risk & Renewals becomes the data-vendor view of "
               "this product. On rows where Supplier Engagement.Specialized Data Vendor is filled, this product publishes what DP-073 "
               "takes: supplier identity, the 40 tier, the 37 residual rating (with the 14 inherent rating beside it), the notice "
               "deadline and expiry dates of the governing contract, and the outsourcing and exit plan flags (Exit Readiness Gap inputs). DP-073 keeps its ID, "
               "FN-17 owner and its license-specific measures (license audits, back-fees, usage from DP-044, vendor data SLAs and "
               "data issues), gains DP-219 and DP-210 upstream and stops computing its own risk assessment overdue and notice "
               "dates for those rows. DP-073 itself is not edited here (spec_common rule). Fund service providers (CD-333, CD-355): "
               "this product publishes engagement, tier, residual risk, contract and exit plan for every fund service provider "
               "(Fund Service Provider Role); TA, custody and fund administration service level results stay in DP-043 and the Fund "
               "Operations product DP-176, which reads this product and is never read by it. Performance reviews follow the 40 row "
               "rule: 14, 13 and 28 review data-vendor, servicing and custody engagements; 40 reviews every other engagement, so "
               "Performance Below Expectations covers only the 40-reviewed engagements. Remediation status of third-party issues "
               "is taken from DP-216 (CD-356). Outsourcing flags and the exit plan are read through DP-220, which masters "
               "the register view (CD-261, CD-268). Money (CD-353): Total Contract Value and Service Credits Due are operational "
               "amounts, never expense; service credits reconcile to 19 credit notes (19 Payable Invoice is read directly because "
               "no foundational product publishes payable invoices; DP-195 is the payables consumer product). Certified numbers: "
               "none. Operating model (CD-297): this product is the oversight grain for every outsourced provider (TA, fund "
               "administration, custody, middle office, P2P); the grain does not change with the operating model. Classified "
               "Restricted - Commercial Terms because contract values and service credits are supplier-confidential; a "
               "Confidential view without values serves DP-176 and the risk function. PII = Y: Engagement Business Owner and "
               "Third-Party Assessor are employee keys, and a supplier may be a sole trader. Open SME questions (40 Q3, Q5; 37 Q9; "
               "brief Q4, Q5): who sets the tier and whether it feeds 37; whether fund service providers are procured through 40 "
               "or appointed by fund boards; who assesses data vendors and servicing providers; whether the Data Office accepts "
               "DP-219 figures for DP-073. Taxonomy gap: Supplier Engagement has no direct reference to its governing contract; the "
               "link runs through Supplier Contract Profile.Contracted Engagements, and for data vendors (whose contracts carry no "
               "Supplier Contract Profile) only through the licensor party, which is ambiguous when a vendor has several engagements. "
               "Taxonomy gap: Software License Position holds quantities but no unit price, so true-up exposure is a quantity, not "
               "an amount. Taxonomy gap: there is no attribute linking a 19 credit note to the service level result it settles; "
               "credits are matched by supplier and date window. Decisions: CD-248, CD-260, CD-261, CD-268, CD-297, CD-298, CD-333, "
               "CD-350, CD-353, CD-355, CD-356."),
    ),
    # ==================================================================================================================
    "DP-220": dict(
        definition=("The outsourcing register of the group's internal entities: each Outsourcing Arrangement (OUTS-) with the "
                    "outsourced function, the regimes it is overseen under (FINRA Rule 3110 supervision of outsourced activities "
                    "and Regulatory Notice 21-29, Regulation S-P service providers, SEC Rules 206(4)-7 and 38a-1), the critical or "
                    "important functions it supports, the governing contract, the supplier engagement and the exit plan. 40 "
                    "masters the register (CD-261, CD-268), 39 the contract, 37 the critical or important functions. What remains "
                    "after CW-940 removed the DORA register of information, the outsourcing notifications and the ICT supply chain: "
                    "it shows which critical or important functions rest on a provider without a tested exit plan and how "
                    "concentrated the firm's reliance on each provider is. It owns no certified metric family."),
        business_questions=[
            "Which activities does each internal entity outsource, under which regimes, and which of them support a critical or important function?",
            "Which critical or important functions rest on an outsourcing without an exit plan, or with an exit plan not tested in the last 12 months?",
            "Which outsourcing providers have no LEI, and how concentrated is our reliance on each provider for critical or important functions?",
            "Which active arrangements point at an expired or inactive contract?",
        ],
        grain="Outsourcing arrangement (OUTS-) x effective period, with exit plan (arrangement, 1 : 0..1) and supported critical or important function (arrangement x function) as linked tables; month-end snapshots",
        dimensions=["Outsourcing entity", "Outsourcing arrangement and regime", "Supported critical or important function",
                    "Critical or important outsourcing indicator", "Intragroup outsourcing indicator", "Supplier engagement and provider",
                    "Provider LEI", "Governing contract", "Exit strategy type", "As-of date"],
        measures=[
            ("Active Outsourcing Arrangements", "Count of Outsourcing Arrangements with Outsourcing Arrangement Status = Active on the as-of date, by Outsourcing Entity, Outsourcing Regimes, Intragroup Outsourcing Indicator and Critical or Important Outsourcing Indicator.",
             _u("40", "Outsourcing Arrangement", "Outsourcing Arrangement ID", "Outsourcing Entity", "Outsourcing Regimes",
                "Intragroup Outsourcing Indicator", "Critical or Important Outsourcing Indicator", "Outsourcing Arrangement Status")),
            ("Critical Indicator Mismatches", "Active arrangements with Critical or Important Outsourcing Indicator = Y and no Supported Critical or Important Functions, or with a Supported Critical or Important Function effective on the as-of date and the indicator = N.",
             _u("40", "Outsourcing Arrangement", "Supported Critical or Important Functions", "Critical or Important Outsourcing Indicator")
             + _u("37", "Critical or Important Function", "Critical Function Code", "Function Effective From", "Function Effective To")
             + ["Active Outsourcing Arrangements"]),
            ("Critical Functions Without Tested Exit Plan", "Distinct Critical or Important Functions effective on the as-of date supported by at least one active arrangement whose Exit Plan has Exit Strategy Type blank, or Exit Plan Last Tested Date blank or more than 12 months before the as-of date.",
             _u("40", "Outsourcing Arrangement", "Supported Critical or Important Functions")
             + _u("40", "Exit Plan", "Exit Strategy Type", "Exit Plan Last Tested Date")
             + _u("37", "Critical or Important Function", "Critical Function Code", "Critical Function Name")
             + ["Active Outsourcing Arrangements"]),
            ("Exit Plans Not Tested (12 Months)", "Outsourcing Arrangements with Critical or Important Outsourcing Indicator = Y and Outsourcing Arrangement Status active whose Exit Plan Last Tested Date is blank or more than 12 months before the as-of date.",
             _u("40", "Outsourcing Arrangement", "Outsourcing Arrangement ID", "Critical or Important Outsourcing Indicator",
                "Outsourcing Arrangement Status")
             + _u("40", "Exit Plan", "Exit Plan Last Tested Date")),
            ("Providers Without LEI", "Count of distinct Engaged Supplier of the Outsourcing Engagement of active critical or important arrangements whose 02 party has no LEI Record with LEI Registration Status Issued (from DP-240).",
             _u("40", "Outsourcing Arrangement", "Outsourcing Engagement")
             + _u("40", "Supplier Engagement", "Supplier Engagement ID", "Engaged Supplier")
             + _u("02", "LEI Record", "LEI", "LEI Registration Status")
             + ["Active Outsourcing Arrangements"]),
            ("Provider Concentration Index", "Sum over providers (Engaged Supplier of the Outsourcing Engagement) of (share of active arrangements with Critical or Important Outsourcing Indicator = Y, in %) squared (Herfindahl-Hirschman index), per Outsourcing Entity; the top five providers by arrangement count listed.",
             _u("40", "Outsourcing Arrangement", "Outsourcing Engagement", "Outsourcing Entity", "Critical or Important Outsourcing Indicator")
             + _u("40", "Supplier Engagement", "Engaged Supplier")
             + ["Active Outsourcing Arrangements"]),
            ("Arrangements on Ended Contracts", "Active arrangements whose Outsourcing Contract has Contract Status other than Active, or Contract Expiry Date before the as-of date (39, from DP-213).",
             _u("40", "Outsourcing Arrangement", "Outsourcing Contract")
             + _u("39", "Contract", "Contract ID", "Contract Status", "Contract Expiry Date")
             + ["Active Outsourcing Arrangements"]),
        ],
        inputs=[
            ("40", "Outsourcing Arrangement", ["Outsourcing Arrangement ID", "Outsourcing Engagement", "Outsourcing Entity",
                                               "Outsourced Function Description", "Outsourcing Regimes",
                                               "Supported Critical or Important Functions",
                                               "Critical or Important Outsourcing Indicator", "Outsourcing Contract",
                                               "Intragroup Outsourcing Indicator", "Service Commencement Date",
                                               "Outsourcing Arrangement Status"]),
            ("40", "Exit Plan", ["Exit Strategy Type", "Alternative Providers", "Planned Transition Period", "Exit Plan Last Tested Date"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engaged Supplier", "Engagement Status"]),
            ("37", "Critical or Important Function", ["Critical Function Code", "Critical Function Name", "Designating Entity",
                                                      "Function Effective From", "Function Effective To"]),
            ("39", "Contract", ["Contract ID", "Parent Contract", "Contracting Entity", "Contract Status", "Contract Effective Date",
                                "Contract Expiry Date", "Governing Law"]),
            ("02", "Party", ["Party ID", "Party Display Name", "Party Status"]),
            ("02", "LEI Record", ["LEI", "LEI Registration Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Party Master Cross-Reference"]),
        ],
        upstream=["DP-210", "DP-213", "DP-217", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for the working register; the month-end snapshot is locked after the Head of Procurement signs off",
        history="SCD type 2 on every arrangement and exit plan; month-end register snapshots kept for at least 5 years after the arrangement ends",
        classification="Restricted - Commercial Terms",
        pii="Y",
        delivery=["Warehouse table", "File extract", "Dashboard"],
        dq_rules=[
            "Every Outsourcing Engagement resolves to an active DP-210 supplier engagement on the arrangement's effective dates.",
            "Every Supported Critical or Important Function resolves to a 37 Critical or Important Function effective on the as-of date, and every Outsourcing Entity to a DP-013 internal legal entity.",
            "Every Outsourcing Contract resolves to a DP-213 contract, and Service Commencement Date is on or after its Contract Effective Date.",
            "Every Outsourcing Arrangement with Critical or Important Outsourcing Indicator = Y has an Exit Plan with Exit Strategy Type populated.",
        ],
        notes=("WP0 re-scope candidate (CW-041): the register row keeps the name 'Outsourcing & DORA Register of Information' "
               "until WP0 renames it to a US outsourcing register or retires it (framework.py is the lead's). "
               "W1b: ICT Register Arrangement Header, ICT Register of Information Entry, Supply Chain Subcontractor and "
               "Outsourcing Notification dropped, no successor (CW-940), with Supplier Contract Profile.ICT Contractual "
               "Arrangement Type and Annual ICT Expense (CW-940), Outsourcing Arrangement.Supported Important Business Services and "
               "Critical or Important Function.Related Important Business Service (CW-937) and the 14 ICT Third-Party Register "
               "Entry (CW-914); the measures Register Entries, Register Completeness %, Missing Outsourcing Notifications, Open "
               "Authority Responses, Subcontracting Depth, Data Location Exposure and Annual ICT Expense in Register are removed, "
               "with the 41 IT Service input that only the register read and DP-211 upstream. W1b re-point (CW-940): Providers "
               "Without LEI and Provider Concentration Index read the provider from the Outsourcing Engagement's Engaged Supplier "
               "instead of the register header; Critical Functions on Unexitable Providers is rewritten as Critical Functions "
               "Without Tested Exit Plan on the Exit Plan group (substitutability left with the header); Entries on Ended Contracts "
               "is rewritten as Arrangements on Ended Contracts on Outsourcing Contract; Critical Indicator Mismatches and Active "
               "Outsourcing Arrangements are added so the remaining register is counted. "
               "Master concepts: the outsourcing register is mastered in 40 (CD-261, CD-268); 37 the critical or important "
               "functions (designated functions only), 39 the contract (through DP-213). Provider identity and LEI come from "
               "DP-240. DP-217 is upstream because critical functions and their resilience mapping are published there; DP-219 "
               "reads this product for its outsourcing flags and exit plan, never the reverse. Certified numbers: none. Operating "
               "model: in house; a P2P or register-tool provider changes the source, not the grain (CD-297). PII = Y: Alternative "
               "Providers are 02 party keys that can be sole traders. Classified Restricted - Commercial Terms because exit terms "
               "are supplier-confidential. Taxonomy gap: the removed register header held the only 40 to 41 links (Supported IT "
               "Services, Supported Applications) and the generic third-party facts the 2023 interagency guidance expects (last "
               "audit date, data storage and processing locations, substitutability); GAP-40-001 has no interim path (40 NOTES). "
               "Taxonomy gap: Outsourcing Regimes is a list, and there is no attribute saying which regime requires a notice "
               "(for example the Regulation S-P service-provider notice). Decisions: CD-249, CD-257, CD-261, CD-268, CD-297, "
               "CW-937, CW-940, CW-914, CW-041."),
    ),
    # ==================================================================================================================
    "DP-221": dict(
        definition=("The purchase-to-pay control chain from sourcing event and award through requisition, purchase order, "
                    "receipt and invoice match to the 19 payable invoice and supplier payment, with remittance-detail "
                    "verification, plus supplier spend by buying entity and fiscal period. Sourcing, ordering, receipt, match, "
                    "remittance and the spend summary are mastered in 40; invoices, payments and their journals are 19's "
                    "(CD-158, CD-260), with journal facts taken from DP-191 (CD-361). It shows procurement and accounts "
                    "payable which invoices are on match hold, which spend bypassed a purchase order or competition, where "
                    "committed spend sits against contract value, and which payments went to unverified bank details. It owns "
                    "no certified metric family: Supplier Spend is an operational measure that reconciles to 19 payable "
                    "invoices and postings; certified operating expense comes only from DP-191 (CD-293, CD-353)."),
        business_questions=[
            "Which invoices are on match hold, for how long and why, and how much price variance did we accept within tolerance?",
            "What share of supplier invoices had no purchase order, and which purchase orders were raised after the invoice?",
            "How much was awarded without competition, and which single-source awards lack a justification?",
            "Which contracts are close to or over their total value on committed purchase orders?",
            "Does supplier spend by entity and period reconcile to accounts payable and the general ledger?",
            "Were any payments made to suppliers whose bank details were unverified, or by a requester who also received the goods?",
        ],
        grain="Invoice match result (19 payable invoice line x purchase order line), with purchase order x line, receipt, requisition and sourcing award as linked tables; and supplier x buying legal entity x fiscal period for spend",
        dimensions=["Supplier (party) and supplier engagement", "Buying / ordering legal entity", "Fiscal period", "Procurement category",
                    "Purchase order type and status", "Match type and status", "Match hold reason", "Sourcing event type",
                    "Governing contract", "GL account and cost center", "Requester and receiver (employee)", "Invoice and payment date"],
        measures=[
            ("Invoices on Match Hold", "Count and Matched Amount of Invoice Match Results with Invoice Match Status = Held, by Match Hold Reason and age in business days since Match Timestamp (0-5, 6-15, over 15).",
             _u("40", "Invoice Match Result", "Matched Payable Invoice", "Matched Invoice Line Number", "Matched Amount",
                "Invoice Match Status", "Match Hold Reason", "Match Timestamp")),
            ("First-Pass Match Rate %", "Invoice lines whose match result has Invoice Match Status in (Matched, Matched Within Tolerance) without having been Held (per the SCD type 2 history) / invoice lines matched in the period, by Match Type.",
             _u("40", "Invoice Match Result", "Matched Payable Invoice", "Matched Invoice Line Number", "Match Type", "Invoice Match Status",
                "Match Timestamp")),
            ("Accepted Price Variance", "Sum of Price Variance Amount on match results with Invoice Match Status in (Matched Within Tolerance, Released), with Tolerance Applied shown, by supplier.",
             _u("40", "Invoice Match Result", "Price Variance Amount", "Quantity Variance", "Tolerance Applied", "Invoice Match Status")),
            ("No-PO Invoice Spend %", "Invoice Gross Amount of 19 Payable Invoices with Payable Document Type = Invoice and no Purchase Order Reference, excluding those with Source Data Invoice, Source Intermediary Communication Fee Invoice or Source Partner Invoice / Invoice Gross Amount of all such invoices, by Invoice Legal Entity and period.",
             _u("19", "Payable Invoice", "Payable Invoice ID", "Payable Document Type", "Invoice Legal Entity", "Invoice Date",
                "Invoice Gross Amount", "Purchase Order Reference", "Source Data Invoice",
                "Source Intermediary Communication Fee Invoice", "Source Partner Invoice")),
            ("After-the-Fact Purchase Orders", "Count and Order Total Amount of Purchase Orders whose Order Date is after the Invoice Date of a 19 Payable Invoice matched to them (Matched Purchase Order).",
             _u("40", "Purchase Order", "Purchase Order ID", "Order Date", "Order Total Amount")
             + _u("40", "Invoice Match Result", "Matched Payable Invoice", "Matched Purchase Order")
             + _u("19", "Payable Invoice", "Payable Invoice ID", "Invoice Date")),
            ("Non-Competitive Award Share %", "Sum of Awarded Value of Sourcing Awards on events with Sourcing Event Type = Single-Source Justification, or with fewer than two Sourcing Invitations having a Bid Amount and no Sourcing Disqualification Reason / total Awarded Value in the period; Single-Source Without Justification counts single-source events with Single-Source Justification blank.",
             _u("40", "Sourcing Award", "Award Sourcing Event", "Award Date", "Awarded Value")
             + _u("40", "Sourcing Event", "Sourcing Event ID", "Sourcing Event Type", "Single-Source Justification")
             + _u("40", "Sourcing Invitation", "Invitation Sourcing Event", "Bid Amount", "Sourcing Disqualification Reason")),
            ("Sourcing Savings %", "(Estimated Contract Value - sum of Awarded Value) / Estimated Contract Value for Sourcing Events with Sourcing Event Status = Awarded in the period.",
             _u("40", "Sourcing Event", "Estimated Contract Value", "Sourcing Event Status")
             + _u("40", "Sourcing Award", "Award Sourcing Event", "Awarded Value")),
            ("Contract Value Consumption %", "Sum of Order Total Amount of Purchase Orders with Purchase Order Status not Canceled under each Governing Contract / Total Contract Value of the contract's Supplier Contract Profile; contracts above 90% and above 100% flagged.",
             _u("40", "Purchase Order", "Governing Contract", "Order Total Amount", "Purchase Order Status")
             + _u("40", "Supplier Contract Profile", "Profiled Contract", "Total Contract Value")),
            ("Supplier Spend", "Invoiced Amount on Supplier Spend Summary by Spend Supplier, Spend Legal Entity and Spend Fiscal Period, with Committed Amount, Received Amount and Paid Amount beside it; an operational measure under its own name, never expense (CD-353).",
             _u("40", "Supplier Spend Summary", "Spend Supplier", "Spend Legal Entity", "Spend Fiscal Period", "Committed Amount",
                "Received Amount", "Invoiced Amount", "Paid Amount")),
            ("Spend Reconciled to AP %", "Supplier x legal entity x fiscal period rows where Invoiced Amount equals the sum of 19 Payable Invoice Invoice Gross Amount (credit notes negative by Payable Document Type) with Invoice Date in the Fiscal Period, and Paid Amount equals the sum of 19 Supplier Payment Payment Amount with Payment Value Date in the period, each within 1 unit of currency / all rows.",
             _u("40", "Supplier Spend Summary", "Spend Supplier", "Spend Legal Entity", "Spend Fiscal Period", "Invoiced Amount", "Paid Amount")
             + _u("19", "Payable Invoice", "Supplier", "Invoice Legal Entity", "Invoice Date", "Payable Document Type", "Invoice Gross Amount")
             + _u("19", "Supplier Payment", "Payee Supplier", "Paying Legal Entity", "Payment Amount", "Payment Value Date")
             + _u("09", "Fiscal Period", "Fiscal Period ID", "Period Start Date", "Period End Date")),
            ("Invoices Posted to GL %", "Payable Invoices with Payable Invoice Status posted or paid that have GL Posting rows with Source Payable Invoice = the invoice in a DP-191 Journal Entry with Journal Status = Posted / such invoices, by Posting Accounting Period.",
             _u("19", "Payable Invoice", "Payable Invoice ID", "Payable Invoice Status")
             + _u("19", "GL Posting", "Journal ID", "Source Payable Invoice", "Posted Amount")
             + _u("19", "Journal Entry", "Journal ID", "Journal Status", "Posting Accounting Period")),
            ("Requester-Receiver Conflicts", "Count of Goods and Service Receipts whose Receiver is the Requester of the Purchase Requisition named as Source Requisition on the received Purchase Order Line.",
             _u("40", "Goods and Service Receipt", "Receipt Purchase Order", "Receipt PO Line Number", "Receipt Sequence", "Receiver")
             + _u("40", "Purchase Order Line", "Line Purchase Order", "PO Line Number", "Source Requisition")
             + _u("40", "Purchase Requisition", "Purchase Requisition ID", "Requester")),
            ("Payments to Unverified Remittance Accounts", "Count and Payment Amount of 19 Supplier Payments whose Payee Supplier has a Supplier Remittance Detail effective on the Payment Value Date with Account Verified Date blank or after the Payment Value Date, or that are paid while the supplier's Supplier Status is Blocked.",
             _u("19", "Supplier Payment", "Supplier Payment Document Number", "Payee Supplier", "Payment Amount", "Payment Value Date")
             + _u("40", "Supplier Remittance Detail", "Remittance Supplier", "Account Verified Date", "Remittance Effective From",
                  "Remittance Effective To")
             + _u("40", "Supplier Profile", "Supplier Party", "Supplier Status", "Supplier Status Effective From", "Supplier Status Effective To")),
        ],
        inputs=[
            ("40", "Sourcing Event", ["Sourcing Event ID", "Sourcing Event Type", "Sourcing Owner", "Originating Requisition",
                                      "Event Issue Date", "Estimated Contract Value", "Sourcing Event Status",
                                      "Single-Source Justification"]),
            ("40", "Sourcing Invitation", ["Invitation Sourcing Event", "Invited Supplier", "Bid Amount", "Sourcing Disqualification Reason"]),
            ("40", "Sourcing Award", ["Award Sourcing Event", "Awarded Supplier", "Award Date", "Awarded Value", "Award Approval Status",
                                      "Resulting Supplier Engagement", "Resulting Contract"]),
            ("40", "Purchase Requisition", ["Purchase Requisition ID", "Requester", "Requisition Cost Center", "Requisition Amount",
                                            "Purchase Requisition Status", "Requisition Approval Status"]),
            ("40", "Purchase Order", ["Purchase Order ID", "Ordered Supplier", "Ordering Legal Entity", "Ordered Engagement",
                                      "Governing Contract", "Purchase Order Type", "Order Date", "Order Total Amount",
                                      "Purchase Order Status"]),
            ("40", "Purchase Order Line", ["Line Purchase Order", "PO Line Number", "Line Receipt Basis", "Line Amount", "Line GL Account",
                                           "Line Cost Center", "Source Requisition"]),
            ("40", "Goods and Service Receipt", ["Receipt Purchase Order", "Receipt PO Line Number", "Receipt Sequence", "Receipt Date",
                                                 "Received Quantity", "Accepted Service Amount", "Receiver"]),
            ("40", "Invoice Match Result", ["Matched Payable Invoice", "Matched Invoice Line Number", "Matched Purchase Order",
                                            "Matched PO Line Number", "Match Type", "Matched Amount", "Quantity Variance",
                                            "Price Variance Amount", "Tolerance Applied", "Invoice Match Status", "Match Hold Reason",
                                            "Match Timestamp"]),
            ("40", "Supplier Remittance Detail", ["Remittance Supplier", "Remittance Sequence", "Bank Account Number (Masked)",
                                                  "Account Verified Date", "Remittance Effective From", "Remittance Effective To"]),
            ("40", "Supplier Spend Summary", ["Spend Supplier", "Spend Legal Entity", "Spend Fiscal Period", "Committed Amount",
                                              "Received Amount", "Invoiced Amount", "Paid Amount"]),
            ("40", "Supplier Profile", ["Supplier Party", "Supplier Status", "Supplier Status Effective From", "Supplier Status Effective To"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engaged Supplier", "Fund-Paid Indicator", "Engagement Status"]),
            ("40", "Supplier Contract Profile", ["Profiled Contract", "Total Contract Value"]),
            ("19", "Payable Invoice", ["Payable Invoice ID", "Payable Document Type", "Supplier", "Supplier Invoice Number", "Invoice Date",
                                       "Invoice Legal Entity", "Invoice Currency", "Invoice Gross Amount", "Payment Due Date",
                                       "Payable Invoice Status", "Source Data Invoice", "Source Intermediary Communication Fee Invoice",
                                       "Source Partner Invoice", "Purchase Order Reference"]),
            ("19", "Payable Invoice Line", ["Line Payable Invoice", "Invoice Line Number", "Line Net Amount", "Line Expense Account",
                                            "Line Cost Center"]),
            ("19", "Supplier Payment", ["Supplier Payment Document Number", "Payee Supplier", "Paying Legal Entity", "Payment Amount",
                                        "Payment Value Date", "Outgoing Payment Status"]),
            ("19", "Supplier Payment Application", ["Applied Supplier Payment", "Settled Payable Invoice", "Applied Payment Amount"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Status", "Posting Accounting Period"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Amount", "Debit Credit Indicator", "Source Payable Invoice"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Period Start Date", "Period End Date"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-210", "DP-213", "DP-191", "DP-190", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; supplier spend by fiscal period final once DP-191 hard-closes the period",
        history="Every sourcing event, order, receipt, match result (latest run, with SCD type 2 status history from this product's go-live), invoice and payment kept for at least 7 years (record retention for books and records); remittance detail changes kept as SCD type 2",
        classification="Restricted",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Invoice Match Result's Matched Payable Invoice and Matched Invoice Line Number resolve to a 19 Payable Invoice Line, and its Matched Purchase Order and Matched PO Line Number to a 40 Purchase Order Line of the same supplier.",
            "Every Purchase Order has a Governing Contract that resolves to a DP-213 contract and an Ordered Supplier with Supplier Status Approved or Restricted on the Order Date (DP-210).",
            "No Purchase Order is raised for an engagement with Fund-Paid Indicator = Y.",
            "Supplier Spend Summary Invoiced Amount and Paid Amount equal the 19 payable invoice and supplier payment totals for the same supplier, legal entity and fiscal period on every run after period close (CD-353).",
            "Every Supplier Remittance Detail effective on a payment date has Account Verified Date populated, and Bank Account Number (Masked) never holds an unmasked number.",
            "Every Sourcing Award with Award Approval Status = Approved names a Resulting Contract that resolves to a DP-213 contract once Sourcing Event Status = Awarded.",
        ],
        notes=("Master concepts: sourcing, requisitions, purchase orders, receipts, the invoice match, remittance detail and the "
               "spend summary are mastered in 40; payable invoices, supplier payments and their postings in 19 (CD-158, CD-260). "
               "Supplier and engagement come from DP-210, contracts from DP-213, GL account and cost center dimensions from "
               "DP-190, and journal facts (Journal Entry, GL Posting) from DP-191, not DP-190 (CD-361). 19 Payable Invoice, Payable "
               "Invoice Line, Supplier Payment and Supplier Payment Application are read from 19 directly because no foundational "
               "product publishes them; DP-195 Payables, Receivables & Working Capital is the AP consumer product and owns payment "
               "timeliness and working capital, so this product does not measure them. Supplier Remittance Detail is published "
               "only here, never in the shared Vendor dimension (DP-210 notes). Money (CD-293, CD-353): Supplier Spend, Committed "
               "and Received Amounts are operational measures under their own names; Invoiced and Paid Amounts are derived copies "
               "of 19 and reconcile to it through Spend Reconciled to AP % and Invoices Posted to GL %; certified operating expense "
               "is published only from DP-191. Data invoices (14), intermediary communication fee invoices (05, IFI-, moved from 13 with CW-088) and partner "
               "invoices (05) follow their own approval flows and are excluded from the no-PO measure. Fund-paid engagements carry "
               "no purchase order. Operating model (CD-297): with an outsourced P2P provider the grain is unchanged and the source "
               "is the provider's suite. Classified Restricted because of remittance details and supplier pricing. PII = Y: "
               "Requester, Receiver and Sourcing Owner are employee keys; supplier parties and remittance accounts can belong to "
               "sole traders. Thresholds used are drafting assumptions: 90% contract consumption, 1 unit of currency "
               "reconciliation tolerance. Open SME questions (40 Q1, Q2, Q6, Q7, Q8, Q10): the procurement suite and ERP supplier "
               "master; who maintains remittance bank details; how contingent workers and legal spend are bought; which spend "
               "thresholds require a sourcing event and whether single-source justifications are recorded; whether four-way match "
               "is used and what price tolerance applies. Taxonomy gap: there is no sourcing threshold attribute, so spend that "
               "bypassed a required sourcing event cannot be tested; Non-Competitive Award Share % covers awards only. Taxonomy "
               "gap: 19 Supplier Payment holds no remit-to account reference (proposed by 40), so verification is tested against "
               "the remittance row effective on the payment date, not the account actually paid. Taxonomy gap: Purchase Order and "
               "Purchase Requisition hold no approver or approval date, so approval segregation of duties cannot be tested; only "
               "requester-receiver conflicts are. Taxonomy gap: Invoice Match Result keeps the latest run only; first-pass match "
               "depends on this product's own status history. Decisions: CD-158, CD-260, CD-293, CD-297, CD-353, CD-361."),
    ),
}
