"""Data product specifications, Wave E4 group "technology_communications": the consumer-aligned products of
41 Technology & Information Security and 42 Corporate Communications & Public Affairs.

DP-231 IT Service Management: Incidents, Problems & Changes; DP-232 Security Incidents, Testing & Vulnerabilities;
DP-233 Identity, Access & Device Lifecycle; DP-234 Change & Project Portfolio (41). DP-235 Brand Register, Usage
Rights & Trademark Protection; DP-236 Media, Coverage & Reputation; DP-237 Issues, Crisis & Internal Communications;
DP-238 Corporate Disclosures, Public Policy & Lobbying (42). Candidates: consolidation/proposals_dp_corporate_b.py.
Brief: 00_Program/Expansion/Product_Briefs/Corporate_Risk_Compliance_Legal_and_Technology.md. See CONTRACT.md.
"""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-231": dict(
        definition=("IT service performance from the ITSM record: every IT incident (ITINC-) by affected IT service, "
                    "application and priority with occurrence, detection and restoration times and downtime, the problems "
                    "and known errors behind recurring incidents, and every change request (CHRQ-) with its approval steps, "
                    "outcome, the release it implemented, its deployments and the incidents it caused. It lets the CIO and "
                    "the head of IT service management manage service availability and change success, shows procurement "
                    "which incidents third-party providers caused, and gives operational risk the technical facts behind "
                    "37 operational incidents (CD-266). Applications, IT services and configuration items are the SM-00 "
                    "Application dimension from DP-211; the product owns no certified metric family."),
        business_questions=[
            "How many P1 and P2 incidents hit each IT service and Tier 1 application this month, and how long did detection and restoration take?",
            "What was each business IT service's downtime and availability against its service hours?",
            "What share of implemented changes succeeded, how many were emergency changes, and which changes caused incidents?",
            "Which implemented changes lacked an approved approval step, or ran in a change freeze?",
            "Which recurring incidents have no problem record, and which known errors are still open without a resolving change?",
            "Which major IT incidents have no 37 operational incident recorded against them, and which third-party providers caused incidents?",
        ],
        grain=("IT incident (ITINC-) x affected IT service x affected application, with change request (CHRQ-) x approval step, "
               "problem record and release x environment x deployment timestamp as companion facts; daily status snapshot"),
        dimensions=["IT service and IT service category", "Application and criticality tier (DP-211)", "Configuration item class and environment",
                    "Incident class, priority and status", "Detection source", "Root cause category", "Change type, risk rating and outcome",
                    "Release type and deployment environment", "Third-party service provider (DP-210)", "Affected legal entity (DP-013)",
                    "Calendar date and reporting period (DP-013)"],
        measures=[
            ("IT Incidents Opened", "Count of IT Incidents with Incident Detected Timestamp in the period and IT Incident Status not Canceled, by Incident Class, Incident Priority, affected IT service (Affected IT Services) and affected application (Affected Applications).",
             [("41", "IT Incident", "IT Incident ID"), ("41", "IT Incident", "Incident Detected Timestamp"),
              ("41", "IT Incident", "IT Incident Status"), ("41", "IT Incident", "Incident Class"),
              ("41", "IT Incident", "Incident Priority"), ("41", "IT Incident", "Affected IT Services"),
              ("41", "IT Incident", "Affected Applications")]),
            ("Mean Time to Detect (hours)", "Average of Incident Detected Timestamp - Incident Occurrence Timestamp for incidents detected in the period, by Incident Priority and Detection Source.",
             [("41", "IT Incident", "Incident Detected Timestamp"), ("41", "IT Incident", "Incident Occurrence Timestamp"),
              ("41", "IT Incident", "Detection Source"),
              ("41", "IT Incident", "Incident Priority")]),
            ("Mean Time to Restore (hours)", "Average of Service Restored Timestamp - Incident Detected Timestamp for incidents of Incident Class Service Disruption or Data Integrity restored in the period, by Incident Priority and affected IT service.",
             [("41", "IT Incident", "Service Restored Timestamp"), ("41", "IT Incident", "Incident Detected Timestamp"),
              ("41", "IT Incident", "Incident Class"), ("41", "IT Incident", "Incident Priority"),
              ("41", "IT Incident", "Affected IT Services")]),
            ("Restoration Target Breaches", "Count of P1 - Critical and P2 - High incidents restored in the period whose Service Restored Timestamp - Incident Detected Timestamp exceeds the restoration target for the priority (parameter, drafted as 4 hours for P1 and 8 hours for P2), and of those still open past the target.",
             [("41", "IT Incident", "Incident Priority"), ("41", "IT Incident", "Service Restored Timestamp"),
              ("41", "IT Incident", "Incident Detected Timestamp"), ("41", "IT Incident", "IT Incident Status")]),
            ("Service Downtime Minutes", "Sum of Service Downtime Minutes of incidents restored in the period, attributed to each IT Service Code in Affected IT Services, by IT Service Category.",
             [("41", "IT Incident", "Service Downtime Minutes"), ("41", "IT Incident", "Affected IT Services"),
              ("41", "IT Service", "IT Service Code"), ("41", "IT Service", "IT Service Category")]),
            ("Service Availability %", "1 - Service Downtime Minutes / scheduled service minutes in the period, where scheduled minutes are derived from the IT service's Service Hours on the period's business days of the firm office calendar; IT services with IT Service Status active only.",
             [("41", "IT Service", "Service Hours"), ("41", "IT Service", "IT Service Status"),
              ("09", "Calendar Date", "Calendar Date"), ("09", "Calendar Date", "Day Type"), "Service Downtime Minutes"]),
            ("Tier 1 Application Incidents", "Count of P1 - Critical and P2 - High incidents whose Affected Applications include an Application with Criticality Tier = Tier 1 - Mission Critical, by Application ID.",
             [("41", "IT Incident", "Affected Applications"), ("41", "IT Incident", "Incident Priority"),
              ("41", "Application", "Application ID"), ("41", "Application", "Criticality Tier"), "IT Incidents Opened"]),
            ("Change Success Rate %", "Change Requests with Actual End Timestamp in the period and Change Outcome in (Successful, Successful with Issues) / Change Requests with Actual End Timestamp in the period and Change Outcome not Canceled, by Change Type and changed application.",
             [("41", "Change Request", "Change Request ID"), ("41", "Change Request", "Actual End Timestamp"),
              ("41", "Change Request", "Change Outcome"), ("41", "Change Request", "Change Type"),
              ("41", "Change Request", "Changed Applications")]),
            ("Emergency Change Share %", "Implemented changes (Change Outcome not Canceled, Actual End Timestamp in the period) with Change Type = Emergency / all implemented changes in the period.",
             [("41", "Change Request", "Change Type"), ("41", "Change Request", "Change Outcome"),
              ("41", "Change Request", "Actual End Timestamp")]),
            ("Change-Induced Incident Rate %", "Distinct Change Request IDs named as Causing Change on an IT Incident detected in the period / implemented changes in the period; incidents with Incident Root Cause Category = Change Implementation and no Causing Change are counted separately as untraced.",
             [("41", "IT Incident", "Causing Change"), ("41", "IT Incident", "Incident Root Cause Category"),
              ("41", "IT Incident", "Incident Detected Timestamp"), ("41", "Change Request", "Change Request ID"),
              "Emergency Change Share %"]),
            ("Changes Without Approval", "Implemented changes of Change Type Normal or Emergency with no Change Approval row with Change Approval Status = Approved, or whose only approvals have a Change Advisory Board Date after Planned Start Timestamp (Emergency changes: after Actual End Timestamp).",
             [("41", "Change Approval", "Approved Change"), ("41", "Change Approval", "Change Approval Step"),
              ("41", "Change Approval", "Change Approval Status"), ("41", "Change Approval", "Change Advisory Board Date"),
              ("41", "Change Request", "Planned Start Timestamp"), ("41", "Change Request", "Actual End Timestamp"),
              ("41", "Change Request", "Change Type"), ("41", "Change Request", "Change Outcome")]),
            ("Changes in Freeze Window", "Implemented changes of Change Type Normal whose Planned Start Timestamp date falls on a Calendar Date of the Change Freeze Calendar with Day Type other than Business Day.",
             [("41", "Change Request", "Change Freeze Calendar"), ("41", "Change Request", "Planned Start Timestamp"),
              ("41", "Change Request", "Change Type"), ("41", "Change Request", "Change Outcome"),
              ("09", "Calendar", "Calendar ID"), ("09", "Calendar Date", "Calendar Date"), ("09", "Calendar Date", "Day Type")]),
            ("Production Deployment Failure Rate %", "Release Deployments with Deployment Environment = Production in the period and Deployment Result in (Failed, Partially Succeeded) / all Production deployments in the period, by Released Application and Release Type.",
             [("41", "Release Deployment", "Deployed Release"), ("41", "Release Deployment", "Deployment Environment"),
              ("41", "Release Deployment", "Deployment Timestamp"), ("41", "Release Deployment", "Deployment Result"),
              ("41", "Release", "Released Application"), ("41", "Release", "Release Type")]),
            ("Open Known Errors", "Count and age (as-of date - date first seen in the daily snapshot) of Problem Records with Problem Status not closed and Known Error Indicator = Y; those with no Resolving Change shown separately.",
             [("41", "Problem Record", "Problem Code"), ("41", "Problem Record", "Problem Status"),
              ("41", "Problem Record", "Known Error Indicator"), ("41", "Problem Record", "Resolving Change")]),
            ("Recurring Incidents Without Problem", "Count of affected IT services with three or more P1 - Critical or P2 - High incidents in a rolling 90 days, at least one of which is not in the Linked IT Incidents of any Problem Record.",
             [("41", "Problem Record", "Linked IT Incidents"), ("41", "IT Incident", "IT Incident ID"),
              ("41", "IT Incident", "Affected IT Services"), ("41", "IT Incident", "Incident Priority"),
              ("41", "IT Incident", "Incident Detected Timestamp")]),
            ("Third-Party-Caused Incidents", "Count of incidents with Incident Root Cause Category = Third-Party Failure, by Third-Party Service Provider of the affected IT service (resolved to the DP-210 supplier).",
             [("41", "IT Incident", "Incident Root Cause Category"), ("41", "IT Incident", "Affected IT Services"),
              ("41", "IT Service", "Third-Party Service Provider")]),
            ("Major Incidents Without Operational Incident", "IT Incidents with Major Incident Indicator = Y or Incident Priority = P1 - Critical, detected more than 2 business days ago, that are not named as Source IT Incident on any 37 Incident Source Record.",
             [("41", "IT Incident", "Major Incident Indicator"), ("41", "IT Incident", "Incident Priority"),
              ("41", "IT Incident", "Incident Detected Timestamp"), ("37", "Incident Source Record", "Source Incident"),
              ("37", "Incident Source Record", "Incident Source Type"), ("37", "Incident Source Record", "Source IT Incident")]),
        ],
        inputs=[
            ("41", "IT Incident", ["IT Incident ID", "IT Incident Title", "Incident Class", "Incident Priority", "Major Incident Indicator",
                                   "Detection Source", "Incident Occurrence Timestamp",
                                   "Incident Detected Timestamp", "Service Restored Timestamp", "Incident Closed Timestamp",
                                   "Service Downtime Minutes", "Data Impact Types", "IT Incident Status", "Affected IT Services",
                                   "Affected Applications", "Affected Configuration Items", "Affected Legal Entities",
                                   "Incident Root Cause Category", "Causing Change", "Incident Manager"]),
            ("41", "Problem Record", ["Problem Code", "Problem Statement", "Problem Status", "Problem Root Cause Category",
                                      "Known Error Indicator", "Workaround Description", "Linked IT Incidents", "Resolving Change",
                                      "Problem Owner"]),
            ("41", "Change Request", ["Change Request ID", "Change Title", "Change Type", "Change Risk Rating", "Changed Applications",
                                      "Changed Configuration Items", "Planned Start Timestamp", "Planned End Timestamp",
                                      "Actual End Timestamp", "Change Freeze Calendar", "Change Outcome", "Implemented Release",
                                      "Change Requester"]),
            ("41", "Change Approval", ["Approved Change", "Change Approval Step", "Change Advisory Board Date", "Change Approver",
                                       "Change Approval Status"]),
            ("41", "Release", ["Release ID", "Released Application", "Release Version", "Release Type"]),
            ("41", "Release Deployment", ["Deployed Release", "Deployment Environment", "Deployment Timestamp", "Deployed By",
                                          "Deployment Result"]),
            ("41", "IT Service", ["IT Service Code", "IT Service Name", "IT Service Category", "ICT Service Type", "Supporting Applications",
                                  "IT Service Owner", "Third-Party Service Provider", "Service Hours", "IT Service Status"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Type", "Hosting Model", "Application Status",
                                   "Criticality Tier", "Owning Org Unit"]),
            ("41", "Configuration Item", ["Configuration Item ID", "Configuration Item Class", "Environment", "Instantiated Application"]),
            ("37", "Incident Source Record", ["Source Incident", "Incident Source Type", "Source IT Incident"]),
            ("09", "Calendar", ["Calendar ID", "Calendar Name", "Calendar Type"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
        ],
        upstream=["DP-211", "DP-210", "DP-192", "DP-013"],
        refresh="Intraday",
        timeliness="Hourly from the ITSM tool during business hours (P1 incidents within 15 minutes of an update); daily snapshot and period measures by 7am ET on T+1",
        history="Daily status snapshots kept for 25 months; incident, problem, change and deployment records kept for 7 years after closure as SEC Rule 17a-4, Regulation S-P and ISO/IEC 27001 evidence",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "For every IT Incident, Incident Occurrence Timestamp <= Incident Detected Timestamp <= Service Restored Timestamp <= Incident Closed Timestamp wherever the later values are populated.",
            "Every value in Affected IT Services, Affected Applications, Affected Configuration Items and Changed Applications resolves to an IT Service Code, Application ID or Configuration Item ID published by DP-211.",
            "Every Causing Change and Resolving Change resolves to a Change Request ID, and the Causing Change's Actual End Timestamp is before the incident's Incident Occurrence Timestamp.",
            "Every Change Request with Change Outcome other than Canceled has an Actual End Timestamp, and every Normal change has at least one Change Approval row.",
            "Service Downtime Minutes is not greater than the minutes between Incident Occurrence Timestamp and Service Restored Timestamp.",
            "Every IT Incident with Incident Status Resolved or Closed has an Incident Root Cause Category.",
        ],
        notes=("W1b: IT Incident.Occurrence Time Estimated Indicator dropped, no successor (CW-941); Mean Time to Detect (hours) no longer splits estimated occurrence times into a separate series. DORA Article 17 wording leaves the history line. "
               "Boundary (CD-266, CD-245): 41 holds the technical record; the 37 Operational Incident, its classification and "
               "every customer and authority notification are DP-215's. The link is held once, on 37 Incident Source "
               "Record, so this product reads that object directly for 'Major Incidents Without Operational Incident' and does "
               "not list DP-215 upstream; DP-215 may take the technical facts from this product without creating a cycle. "
               "Security events are counted here by Incident Class only; their security detail, Reg S-P determinations, tests "
               "and vulnerabilities are DP-232. Applications, IT services and configuration items come from DP-211 (CD-263, "
               "CD-160, CD-295); third-party service providers resolve to DP-210 suppliers. Operating model (CD-297): the IT "
               "service desk runs in house with managed services; where a managed service provider runs the service desk or "
               "infrastructure, incidents and changes arrive from the provider's ITSM at the same grain (provider-hosted "
               "platforms are Applications with Hosting Model = Provider-Hosted, CD-147), and the product adds the provider's "
               "SLA report as oversight data through DP-219. Supporting functions: FN-42 reads major incidents and change "
               "failures; FN-46 third-party-caused incidents; FN-49 and FN-27 incidents on reference data and book of record "
               "applications (Application Type and the 18 Book of Record System reference resolve to APPL-). PII = Y: Incident "
               "Manager, Problem Owner, Change Requester, Change Approver and Deployed By are employee keys; the wide view shows "
               "counts by service and team only. Taxonomy gap: IT Service has no restoration or availability target and Service "
               "Hours is free text, so restoration targets are a product parameter and scheduled minutes are parsed. Taxonomy "
               "gap: Change Approval has no approval timestamp (dropped in the 41 review), so approval before implementation "
               "is tested on Change Advisory Board Date. Taxonomy gap: no change freeze day type exists on 09 Calendar Date; "
               "freeze days are assumed to be the non-business days of the calendar named in Change Freeze Calendar (confirm). "
               "Open SME questions: 41 Q1 (inventory and ITSM tool), Q3 (security events in ITSM or a SOC tool), Q12 (CMDB "
               "states). Decisions: CD-147, CD-160, CD-245, CD-263, CD-266, CD-295, CD-296, CD-297."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-232": dict(
        definition=("The firm's security incident, testing and vulnerability record: security events (IT incidents of class "
                    "Security Event) with attack vector, personal data affected, the SEC Regulation S-P customer "
                    "notification determination and notice due date, containment and eradication; penetration, red "
                    "team and ICT disaster recovery tests with outcomes; and vulnerability findings (VULN-) by severity, "
                    "known exploitation and remediation deadline. It shows the CISO which customer notices are due, which "
                    "critical vulnerabilities are past due, which critical applications have not been tested and which "
                    "recovery tests missed the application's recovery time objective. Applications come from DP-211 and "
                    "risk acceptances from DP-216; the product owns no certified metric family."),
        business_questions=[
            "Which security events affected sensitive customer information, which Reg S-P determinations are still under investigation, and which customer notices fall due in the next 30 days?",
            "How quickly were security events detected, contained and eradicated, by attack vector and threat actor?",
            "How many critical and high vulnerabilities are open past their remediation due date, and how many are known to be exploited?",
            "Which Tier 1 or internet-facing applications have not had a penetration test or red team exercise in the last 12 months?",
            "Which disaster recovery failover tests missed the application's recovery time objective?",
            "Which risk-accepted vulnerabilities have no open 37 risk issue holding the acceptance?",
        ],
        grain=("Vulnerability finding (VULN-) x as-of date (daily snapshot), with security event (ITINC- of class Security Event, "
               "with its security detail) and security or resilience test x tested application as companion facts"),
        dimensions=["Application, criticality tier and internet-facing flag (DP-211)", "Configuration item and environment (DP-211)",
                    "Vulnerability severity and known-exploited flag", "Remediation status", "Attack vector and threat actor category",
                    "Customer notification determination", "Test type and outcome", "Tested financial entity and affected legal entity (DP-013)",
                    "External tester and notifying service provider (DP-210)", "As-of date and reporting period (DP-013)"],
        measures=[
            ("Security Events Opened", "Count of IT Incidents with Incident Class = Security Event and Incident Detected Timestamp in the period, by Attack Vector, Threat Actor Category and Detection Source.",
             [("41", "IT Incident", "IT Incident ID"), ("41", "IT Incident", "Incident Class"),
              ("41", "IT Incident", "Incident Detected Timestamp"), ("41", "IT Incident", "Detection Source"),
              ("41", "Security Incident Detail", "Attack Vector"), ("41", "Security Incident Detail", "Threat Actor Category")]),
            ("Personal Data Security Events", "Security events with Personal Data Affected Indicator = Y, with the subset where Sensitive Customer Information Compromised Indicator = Y and the sum of Affected Individuals Estimate.",
             [("41", "Security Incident Detail", "Personal Data Affected Indicator"),
              ("41", "Security Incident Detail", "Sensitive Customer Information Compromised Indicator"),
              ("41", "Security Incident Detail", "Affected Individuals Estimate"), "Security Events Opened"]),
            ("Reg S-P Determinations Pending", "Security events with Sensitive Customer Information Compromised Indicator = Y or Personal Data Affected Indicator = Y and Customer Notification Determination = Under Investigation, with days since Became Aware Date; those past 20 days are flagged.",
             [("41", "Security Incident Detail", "Customer Notification Determination"),
              ("41", "Security Incident Detail", "Became Aware Date"),
              ("41", "Security Incident Detail", "Sensitive Customer Information Compromised Indicator"),
              ("41", "Security Incident Detail", "Personal Data Affected Indicator")]),
            ("Customer Notices Due", "Security events with Customer Notification Determination = Notification Required and Customer Notice Due Date within the next 30 days, and those whose Customer Notice Due Date has passed, split by Attorney General Delay Indicator.",
             [("41", "Security Incident Detail", "Customer Notification Determination"),
              ("41", "Security Incident Detail", "Customer Notification Determination Date"),
              ("41", "Security Incident Detail", "Customer Notice Due Date"),
              ("41", "Security Incident Detail", "Attorney General Delay Indicator")]),
            ("Late Service Provider Notices", "Security events with a Notifying Service Provider whose Service Provider Notice Received Timestamp is more than 72 hours after Incident Occurrence Timestamp, by Notifying Service Provider.",
             [("41", "Security Incident Detail", "Notifying Service Provider"),
              ("41", "Security Incident Detail", "Service Provider Notice Received Timestamp"),
              ("41", "IT Incident", "Incident Occurrence Timestamp")]),
            ("Mean Time to Contain and Eradicate (days)", "Average of Containment Date - Incident Detected Timestamp date, and of Eradication Date - Incident Detected Timestamp date, for security events contained or eradicated in the period, by Attack Vector.",
             [("41", "Security Incident Detail", "Containment Date"), ("41", "Security Incident Detail", "Eradication Date"),
              ("41", "IT Incident", "Incident Detected Timestamp"), ("41", "Security Incident Detail", "Attack Vector")]),
            ("Open Vulnerabilities", "Count of Vulnerability Findings with Vulnerability Remediation Status in (Open, Remediation In Progress, Remediated - Pending Verification) on the as-of date, by Vulnerability Severity, Known Exploited Indicator and the Criticality Tier of the Vulnerable Application (or of the Vulnerable Configuration Item's Instantiated Application).",
             [("41", "Vulnerability Finding", "Vulnerability Finding ID"), ("41", "Vulnerability Finding", "Vulnerability Remediation Status"),
              ("41", "Vulnerability Finding", "Vulnerability Severity"), ("41", "Vulnerability Finding", "Known Exploited Indicator"),
              ("41", "Vulnerability Finding", "Vulnerable Application"), ("41", "Vulnerability Finding", "Vulnerable Configuration Item"),
              ("41", "Configuration Item", "Instantiated Application"), ("41", "Application", "Criticality Tier")]),
            ("Overdue Critical and High Vulnerabilities", "Open Vulnerabilities with Vulnerability Severity in (Critical, High) and Remediation Due Date before the as-of date, with days overdue; the Known Exploited Indicator = Y subset is reported separately.",
             [("41", "Vulnerability Finding", "Remediation Due Date"), ("41", "Vulnerability Finding", "Vulnerability Severity"),
              ("41", "Vulnerability Finding", "Known Exploited Indicator"), "Open Vulnerabilities"]),
            ("Mean Time to Remediate (days)", "Average of Remediated Date - Vulnerability Detected Date for findings with Vulnerability Remediation Status = Closed - Remediated and Remediated Date in the period, by Vulnerability Severity.",
             [("41", "Vulnerability Finding", "Remediated Date"), ("41", "Vulnerability Finding", "Vulnerability Detected Date"),
              ("41", "Vulnerability Finding", "Vulnerability Remediation Status"), ("41", "Vulnerability Finding", "Vulnerability Severity")]),
            ("Remediated Within Deadline %", "Findings closed in the period with Remediated Date <= Remediation Due Date / all findings closed in the period, by Vulnerability Severity.",
             [("41", "Vulnerability Finding", "Remediated Date"), ("41", "Vulnerability Finding", "Remediation Due Date"),
              "Mean Time to Remediate (days)"]),
            ("Risk Acceptances Without Open Issue", "Vulnerability Findings with Vulnerability Remediation Status = Risk Accepted that are not the Source Vulnerability Finding of a 37 Risk Issue with Issue Source Type = Vulnerability Finding and Issue Status open, or whose issue's Issue Due Date has passed (from DP-216).",
             [("41", "Vulnerability Finding", "Vulnerability Remediation Status"), ("37", "Risk Issue", "Risk Issue ID"),
              ("37", "Risk Issue", "Issue Source Type"), ("37", "Risk Issue", "Source Vulnerability Finding"),
              ("37", "Risk Issue", "Issue Status"), ("37", "Risk Issue", "Issue Due Date")]),
            ("Critical Applications Not Tested", "Applications with Application Status = In Production and (Criticality Tier in (Tier 1 - Mission Critical, Tier 2 - Business Critical) or Internet-Facing Indicator = Y) that appear in the Tested Applications of no Security & Resilience Test of Test Type in (Penetration Test, Red Team Exercise) with Test End Date in the last 12 months.",
             [("41", "Application", "Application ID"), ("41", "Application", "Application Status"), ("41", "Application", "Criticality Tier"),
              ("41", "Application", "Internet-Facing Indicator"), ("41", "Security & Resilience Test", "Tested Applications"),
              ("41", "Security & Resilience Test", "Test Type"), ("41", "Security & Resilience Test", "Test End Date")]),
            ("DR Tests Exceeding RTO", "Security & Resilience Tests of Test Type = ICT Disaster Recovery Failover in the period whose Achieved Recovery Time Hours exceeds the Recovery Time Objective Hours of a tested application, or whose Test Outcome = Failed.",
             [("41", "Security & Resilience Test", "Test Code"), ("41", "Security & Resilience Test", "Test Type"),
              ("41", "Security & Resilience Test", "Achieved Recovery Time Hours"), ("41", "Security & Resilience Test", "Tested Applications"),
              ("41", "Security & Resilience Test", "Test Outcome"), ("41", "Security & Resilience Test", "Test End Date"),
              ("41", "Application Recovery Profile", "Recovery Time Objective Hours")]),
            ("Test Findings and Failures", "Count of tests by Test Type and Test Outcome in the period, and count of Vulnerability Findings whose Source Test is the test, by Vulnerability Severity.",
             [("41", "Security & Resilience Test", "Test Code"), ("41", "Security & Resilience Test", "Test Outcome"),
              ("41", "Security & Resilience Test", "Test Type"), ("41", "Security & Resilience Test", "Test End Date"),
              ("41", "Vulnerability Finding", "Source Test"),
              ("41", "Vulnerability Finding", "Vulnerability Severity")]),
        ],
        inputs=[
            ("41", "IT Incident", ["IT Incident ID", "Incident Class", "Incident Priority", "Detection Source", "Incident Occurrence Timestamp",
                                   "Incident Detected Timestamp", "Service Restored Timestamp", "Incident Closed Timestamp",
                                   "Data Impact Types", "IT Incident Status", "Affected Applications", "Affected Legal Entities",
                                   "Incident Root Cause Category"]),
            ("41", "Security Incident Detail", ["Attack Vector", "Threat Actor Category", "Personal Data Affected Indicator",
                                                "Sensitive Customer Information Compromised Indicator", "Affected Individuals Estimate",
                                                "Became Aware Date", "Customer Notification Determination",
                                                "Customer Notification Determination Date", "Customer Notice Due Date",
                                                "Attorney General Delay Indicator", "Notifying Service Provider",
                                                "Service Provider Notice Received Timestamp", "Containment Date", "Eradication Date"]),
            ("41", "Security & Resilience Test", ["Test Code", "Test Type", "Tested Applications", "Tested IT Services",
                                                  "Tested Configuration Items", "Tested Financial Entity", "External Tester",
                                                  "Test Start Date", "Test End Date", "Test Outcome", "Achieved Recovery Time Hours"]),
            ("41", "Vulnerability Finding", ["Vulnerability Finding ID", "Vulnerable Configuration Item", "Vulnerable Application",
                                             "CVE Identifier", "CVSS Base Score", "CVSS Version", "Vulnerability Severity",
                                             "Known Exploited Indicator", "Source Test", "Vulnerability Detected Date",
                                             "Remediation Due Date", "Vulnerability Remediation Status", "Remediated Date",
                                             "Governing Vulnerability Policy"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Status", "Criticality Tier", "Hosting Model",
                                   "Internet-Facing Indicator", "Confidentiality Impact Level"]),
            ("41", "Application Recovery Profile", ["Recovery Tier", "Recovery Time Objective Hours"]),
            ("41", "Configuration Item", ["Configuration Item ID", "Configuration Item Class", "Environment", "Instantiated Application",
                                          "End of Vendor Support Date"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Issue Source Type", "Source Vulnerability Finding", "Issue Status", "Issue Due Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
        ],
        upstream=["DP-211", "DP-216", "DP-210", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a change of Customer Notification Determination or a new Known Exploited finding is visible in the next daily run",
        history="Daily vulnerability snapshots kept for 25 months; security events, tests and findings kept for 7 years after closure (Reg S-P incident response records, SEC Rule 17a-4 and ISO/IEC 27001 evidence)",
        classification="Restricted",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every IT Incident with Incident Class = Security Event has exactly one Security Incident Detail row with Became Aware Date populated.",
            "For every security event with Customer Notification Determination = Notification Required and Attorney General Delay Indicator not Y, Customer Notice Due Date is no later than Became Aware Date + 30 calendar days.",
            "Customer Notification Determination Date is populated whenever the determination is not Under Investigation, and is on or after Became Aware Date.",
            "Every Vulnerability Finding not closed or false positive has a Remediation Due Date and a Vulnerable Application or Vulnerable Configuration Item that resolves in DP-211.",
            "A Vulnerability Finding with Vulnerability Remediation Status = Closed - Remediated has a Remediated Date on or after Vulnerability Detected Date.",
            "Every test of Test Type ICT Disaster Recovery Failover with Test Outcome populated has Achieved Recovery Time Hours.",
        ],
        notes=("W1b: Security & Resilience Test.TLPT Attestation Date dropped, no successor (CW-941), with the measure Entities Without Recent TLPT and its taxonomy gap (GAP-41-003 closes with CW-941). W1b re-point (CW-941): Critical Applications Not Tested filters on Test Type in (Penetration Test, Red Team Exercise); the TLPT value left the list. "
               "Boundary (CD-245, CD-266, CD-270): incident classification and customer and authority notifications are DP-215's; the customer notices "
               "themselves are 13 or 12 communications; the Reg S-P determination, Became Aware Date and notice due date are 41 "
               "facts published here. Risk acceptance of a vulnerability is a 37 Risk Issue read through DP-216. Overdue and open "
               "issue counts are computed once, in DP-216 (CD-356); this product counts vulnerability findings against their "
               "own Remediation Due Date, a technical remediation deadline, and never counts issues or issue actions. The 37 "
               "Resilience Test reads DR results from 41 Security & Resilience Test; DP-217 may take them from this product, so "
               "this product never lists DP-217 or DP-215 upstream. Operating model (CD-297): the security operations center may "
               "be co-sourced with a managed detection provider; its case feed arrives at the same grain (one IT Incident per "
               "security event), and external testers are recorded as External Tester parties (DP-210 suppliers). Supporting "
               "functions: FN-42 resilience and incidents; FN-44 and FN-45 Reg S-P and breach notification decisions; FN-15 "
               "shareholder data breaches at the transfer agent (Notifying Service Provider); FN-43 test evidence. PII = N: no "
               "personal data is published (Affected Individuals Estimate is a count); classified Restricted because "
               "vulnerability and attack details are security-sensitive. Taxonomy gap: 41 holds no customer notice sent date and "
               "the proposed 13 / 12 'Related IT Incident' reference is not yet in the taxonomy, so notice timeliness can be "
               "shown only as due or past due, not as sent on time. Taxonomy gap: Vulnerability Finding has no risk acceptance "
               "expiry; the 37 Issue Due Date is used. Taxonomy gap: Security & Resilience Test holds one Achieved Recovery Time "
               "Hours for all Tested Applications, so the RTO comparison uses the strictest tested application's RTO. Open SME questions: 41 Q3 (SOC case tool), Q4 (who decides that a customer notification is required), "
               "Q9 (breaches without a security incident). Decisions: CD-245, CD-263, CD-266, CD-270, CD-296, CD-297, CD-356."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-233": dict(
        definition=("The identity and access control record: digital identities (workforce, external, service and privileged "
                    "accounts) with their owners and MFA status, access roles by application with privileged and segregation of "
                    "duties flags, every system access grant (ACSG-) with its request, approval, provisioning and revocation "
                    "dates and the joiner, mover or leaver event that triggered it, access review campaigns and decisions, and "
                    "end-user device assignments with return and wipe dates. It evidences that leavers lost access and returned "
                    "wiped devices on time, that privileged access was certified, and that grants provisioning licensed data "
                    "match an active 14 entitlement. People and lifecycle events come from DP-192, applications from DP-211; "
                    "the product owns no certified metric family."),
        business_questions=[
            "Which leavers still had active access or an enabled identity after their termination date, and how long did revocation take?",
            "Which leavers have not returned their devices, or returned devices that were not wiped?",
            "Were all privileged grants certified in the last review cycle, and were revoke decisions carried out on time?",
            "Which grants were provisioned without approval or approved by the grantee, and which identities hold conflicting roles?",
            "Which enabled identities have no MFA, no active owner or no sponsor?",
            "Which grants provision licensed data without an active entitlement, and which active entitlements have no matching grant?",
        ],
        grain=("System access grant (ACSG-) x as-of date (daily snapshot), with digital identity x as-of date, access review campaign "
               "x reviewed grant and end-user device x assignee x assignment period as companion facts"),
        dimensions=["Application and access role (DP-211)", "Privileged and segregation of duties flags", "Identity type and status",
                    "Employee, employment status, org unit and legal entity (DP-192)", "Lifecycle event type (DP-192)",
                    "Access review campaign and decision", "Configuration item class (end-user device)", "Licensed dataset and license (DP-044)",
                    "As-of date (DP-013)"],
        measures=[
            ("Enabled Identities", "Count of Digital Identities with Identity Status = Enabled on the as-of date, by Identity Type and the owner's Home Org Unit.",
             [("41", "Digital Identity", "Digital Identity ID"), ("41", "Digital Identity", "Identity Status"),
              ("41", "Digital Identity", "Identity Type"), ("41", "Digital Identity", "Identity Owner Employee"),
              ("20", "Employee", "Home Org Unit")]),
            ("Identities Without MFA %", "Enabled identities of Identity Type Workforce, External User or Privileged Account with MFA Enrolled Indicator = N / all enabled identities of those types.",
             [("41", "Digital Identity", "MFA Enrolled Indicator"), ("41", "Digital Identity", "Identity Type"), "Enabled Identities"]),
            ("Orphaned Identities", "Enabled identities whose Identity Owner Employee (Workforce, Privileged Account) or Service Account Sponsor (Service Account) has Employment Status = Terminated, or is blank.",
             [("41", "Digital Identity", "Identity Owner Employee"), ("41", "Digital Identity", "Service Account Sponsor"),
              ("41", "Digital Identity", "Identity Type"), ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"),
              "Enabled Identities"]),
            ("Leavers With Access After Termination", "For Employee Lifecycle Events with Lifecycle Event Type = Termination and Event Effective Date in the period: count of leavers with any System Access Grant on their identities that has Access Grant Status = Active, or Access Revoked Date later than Event Effective Date + 1 business day; privileged grants (Privileged Role Indicator = Y) reported separately.",
             [("20", "Employee Lifecycle Event", "Lifecycle Event ID"), ("20", "Employee Lifecycle Event", "Event Employee"),
              ("20", "Employee Lifecycle Event", "Lifecycle Event Type"), ("20", "Employee Lifecycle Event", "Event Effective Date"),
              ("41", "System Access Grant", "Grantee Identity"), ("41", "System Access Grant", "Access Grant Status"),
              ("41", "System Access Grant", "Access Revoked Date"), ("41", "System Access Grant", "Granted Access Role"),
              ("41", "Application Access Role", "Privileged Role Indicator"), ("41", "Digital Identity", "Identity Owner Employee")]),
            ("Leaver Revocation Lag (days)", "Median of Access Revoked Date - Event Effective Date over grants revoked for Termination events in the period, and median of Identity Disabled Date - Event Effective Date over the leavers' identities.",
             [("41", "System Access Grant", "Access Revoked Date"), ("41", "System Access Grant", "Revoking Lifecycle Event"),
              ("41", "Digital Identity", "Identity Disabled Date"), ("20", "Employee Lifecycle Event", "Event Effective Date"),
              "Leavers With Access After Termination"]),
            ("Leaver Devices Not Returned or Wiped", "IT Asset Assignments of leavers (Device Assignee with a Termination event in the period) with Returned Date blank or later than Event Effective Date + 5 business days, or with Returned Date populated and Data Wipe Date blank.",
             [("41", "IT Asset Assignment", "Assigned Configuration Item"), ("41", "IT Asset Assignment", "Device Assignee"),
              ("41", "IT Asset Assignment", "Returned Date"), ("41", "IT Asset Assignment", "Data Wipe Date"),
              ("20", "Employee Lifecycle Event", "Event Effective Date"), ("20", "Employee Lifecycle Event", "Lifecycle Event Type"),
              ("20", "Employee Lifecycle Event", "Event Employee")]),
            ("Mover Access Not Revisited", "Active grants provisioned before an Employee Lifecycle Event of type Transfer or Job Change of the identity's owner that are still Active 30 days after the event and were not the subject of an Access Review Decision after the event.",
             [("41", "System Access Grant", "Access Provisioned Date"), ("41", "System Access Grant", "Access Grant Status"),
              ("41", "System Access Grant", "System Access Grant ID"), ("20", "Employee Lifecycle Event", "Lifecycle Event Type"),
              ("20", "Employee Lifecycle Event", "Event Effective Date"), ("20", "Employee Lifecycle Event", "Event Employee"),
              ("41", "System Access Grant", "Grantee Identity"), ("41", "Digital Identity", "Identity Owner Employee"),
              ("41", "Access Review Decision", "Reviewed Grant"), ("41", "Access Review Decision", "Review Decision Date")]),
            ("Grants Without Valid Approval", "Grants with Access Provisioned Date populated and Access Approved Date blank or later than Access Provisioned Date, or whose Access Approver equals the identity's Identity Owner Employee.",
             [("41", "System Access Grant", "Access Provisioned Date"), ("41", "System Access Grant", "Access Approved Date"),
              ("41", "System Access Grant", "Access Approver"), ("41", "Digital Identity", "Identity Owner Employee")]),
            ("Active Privileged Grants", "Count of grants with Access Grant Status = Active on roles with Privileged Role Indicator = Y, by Role Application and Data Classification Ceiling.",
             [("41", "System Access Grant", "Access Grant Status"), ("41", "Application Access Role", "Privileged Role Indicator"),
              ("41", "Application Access Role", "Role Application"), ("41", "Application Access Role", "Data Classification Ceiling")]),
            ("Segregation of Duties Conflicts", "Count of employees whose identities hold Active grants to two or more different Access Role Codes that share the same Segregation of Duties Group (roles in one group are treated as mutually exclusive).",
             [("41", "Application Access Role", "Segregation of Duties Group"), ("41", "Application Access Role", "Access Role Code"),
              ("41", "System Access Grant", "Granted Access Role"), ("41", "System Access Grant", "Access Grant Status"),
              ("41", "Digital Identity", "Identity Owner Employee")]),
            ("Access Review Completion %", "Access Review Decisions with Review Decision Date on or before the campaign's Review Due Date / all decisions of campaigns with Review Due Date in the period; also shown for Privileged Access Only Indicator = Y campaigns.",
             [("41", "Access Review Decision", "Decision Campaign"), ("41", "Access Review Decision", "Review Decision Date"),
              ("41", "Access Review Campaign", "Access Review Campaign Code"), ("41", "Access Review Campaign", "Review Due Date"),
              ("41", "Access Review Campaign", "Privileged Access Only Indicator")]),
            ("Unreviewed Privileged Grants", "Active Privileged Grants that are not the Reviewed Grant of any Access Review Decision with Review Decision = Certify or Modify dated in the last 12 months.",
             [("41", "Access Review Decision", "Reviewed Grant"), ("41", "Access Review Decision", "Review Decision"),
              ("41", "Access Review Decision", "Review Decision Date"), "Active Privileged Grants"]),
            ("Revoke Decisions Not Remediated", "Access Review Decisions with Review Decision in (Revoke, Modify) whose Remediation Completed Date is blank or more than 10 business days after Review Decision Date, or whose Reviewed Grant is still Active with the same Granted Access Role.",
             [("41", "Access Review Decision", "Review Decision"), ("41", "Access Review Decision", "Remediation Completed Date"),
              ("41", "Access Review Decision", "Review Decision Date"), ("41", "Access Review Decision", "Reviewed Grant"),
              ("41", "System Access Grant", "Access Grant Status"), ("41", "System Access Grant", "Granted Access Role")]),
            ("Licensed-Data Grants Without Active Entitlement", "Active grants with a Provisioned Data Entitlement whose 14 Entitlement has Entitlement Status other than Active, a Revoked Date, or an Entitled User different from the identity's owner employee.",
             [("41", "System Access Grant", "Provisioned Data Entitlement"), ("41", "System Access Grant", "Access Grant Status"),
              ("14", "Entitlement", "Entitlement ID"), ("14", "Entitlement", "Entitlement Status"), ("14", "Entitlement", "Revoked Date"),
              ("14", "Entitlement", "Entitled User"), ("41", "Digital Identity", "Identity Owner Employee")]),
            ("Entitlements Without Provisioned Grant", "14 Entitlements with Entitlement Status = Active held by a user (Entitled User populated) that no Active grant references as Provisioned Data Entitlement; candidates for license reclaim in DP-044.",
             [("14", "Entitlement", "Entitlement ID"), ("14", "Entitlement", "Entitlement Status"), ("14", "Entitlement", "Entitled User"),
              ("41", "System Access Grant", "Provisioned Data Entitlement"), ("41", "System Access Grant", "Access Grant Status")]),
        ],
        inputs=[
            ("41", "Digital Identity", ["Digital Identity ID", "Username", "Identity Type", "Identity Owner Employee", "Identity Owner Party",
                                        "Service Account Sponsor", "Identity Status", "MFA Enrolled Indicator", "Identity Disabled Date",
                                        "Last Sign-In Timestamp"]),
            ("41", "Application Access Role", ["Role Application", "Access Role Code", "Access Role Name", "Privileged Role Indicator",
                                               "Segregation of Duties Group", "Role Approver", "Data Classification Ceiling"]),
            ("41", "System Access Grant", ["System Access Grant ID", "Grantee Identity", "Granted Access Role", "Access Grant Status",
                                           "Access Requested Date", "Access Approver", "Access Approved Date", "Access Provisioned Date",
                                           "Access Revoked Date", "Granting Lifecycle Event", "Revoking Lifecycle Event",
                                           "Provisioned Data Entitlement"]),
            ("41", "Access Review Campaign", ["Access Review Campaign Code", "Reviewed Application", "Privileged Access Only Indicator",
                                              "Review Due Date", "Governing Access Policy"]),
            ("41", "Access Review Decision", ["Decision Campaign", "Reviewed Grant", "Review Decision", "Access Reviewer",
                                              "Review Decision Date", "Remediation Completed Date"]),
            ("41", "IT Asset Assignment", ["Assigned Configuration Item", "Device Assignee", "Assigned Date", "Returned Date",
                                           "Data Wipe Date"]),
            ("41", "Configuration Item", ["Configuration Item ID", "Configuration Item Class", "Configuration Item Status"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Status", "Criticality Tier", "Owning Org Unit"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Termination Date", "Home Org Unit", "Employing Legal Entity",
                                "Employment Type"]),
            ("20", "Employee Lifecycle Event", ["Lifecycle Event ID", "Event Employee", "Lifecycle Event Type", "Event Effective Date"]),
            ("14", "Entitlement", ["Entitlement ID", "Entitlement Holder Type", "Entitled User", "Entitled Application", "Entitled Dataset",
                                   "Governing License", "Entitlement Status", "Revoked Date", "Last Recertification Date"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
        ],
        upstream=["DP-211", "DP-192", "DP-044", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 from the identity governance tool and the HR lifecycle feed; a termination event recorded by 6pm ET is tested in the next run",
        history="Daily grant and identity snapshots kept for 25 months (two annual review cycles); every grant, review decision and device assignment kept for 7 years after revocation or return as SOX ITGC and ISO/IEC 27001 evidence",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every System Access Grant resolves to one Digital Identity and one Application Access Role, and every Role Application resolves to an Application ID in DP-211.",
            "Every enabled Digital Identity of Identity Type Workforce or Privileged Account has an Identity Owner Employee in DP-192, and every Service Account has a Service Account Sponsor.",
            "A grant with Access Grant Status = Revoked has an Access Revoked Date, and a grant with Access Grant Status = Active has an Access Provisioned Date and no Access Revoked Date.",
            "For every grant, Access Requested Date <= Access Approved Date <= Access Provisioned Date <= Access Revoked Date wherever the later values are populated.",
            "Every Revoking Lifecycle Event and Granting Lifecycle Event resolves to a DP-192 Employee Lifecycle Event of the identity's owner employee.",
            "Every Access Review Decision's Reviewed Grant is a grant on a role of the campaign's Reviewed Application.",
        ],
        notes=("Boundary (CD-265): system access is 41; the person and lifecycle events are 20, read from DP-192; licensed-data "
               "entitlements stay 14. DP-044 counts licenses, usage and cost; this product checks that provisioning matches the "
               "entitlement (the link is held once, on System Access Grant.Provisioned Data Entitlement). Physical access zone "
               "grants are 44 (DP-208) and meet this product only through the employee. Supporting functions: FN-43 and FN-44 "
               "use it as access control evidence; FN-41 for the leaver process; FN-17 and FN-50 for licensed and sensitive "
               "data access (Data Classification Ceiling); FN-38 for SOX IT general controls on finance applications. PII = Y "
               "by design (every grant, identity, decision and device assignment attribute is flagged PII in 41): access is "
               "limited to the CISO's identity and access team, internal audit and compliance testing; publish aggregates by "
               "application and org unit for wider use. Operating model: in house; if identity administration is a managed "
               "service the provider's identity governance extract arrives at the same grain. Thresholds (1 business day for "
               "leaver revocation, 5 for device return, 10 for revoke remediation, 30 days for movers, 12 months for privileged "
               "certification) are drafting parameters to confirm against the 38 access policy. Taxonomy gap: the segregation "
               "of duties rule is only a group label on Application Access Role; there is no conflict matrix, so roles in one "
               "group are assumed mutually exclusive. Taxonomy gap: the governing 38 access policy holds no numeric revocation "
               "or review deadline. Taxonomy gap: IT Asset Assignment has no return due date. Taxonomy gap: Access Review "
               "Campaign has no launch date, so completion is measured only against Review Due Date. Open SME question 41 Q5 "
               "(identity sources feeding provisioning). Decisions: CD-265, CD-270, CD-296."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-234": dict(
        definition=("The enterprise change and project portfolio: change programs and projects (PRJT-) with sponsor, type, "
                    "phase and status, milestones against baseline, weekly RAG status, approved budget, actual cost to date and "
                    "forecast cost at completion, and what each project delivers through Project Scope Link: 36 product change "
                    "initiatives, 38 regulatory change items, 21 data products and data quality fixes, and 41 applications. It "
                    "lets the PMO and the portfolio committee prioritize and see slippage, and lets compliance and product "
                    "development see which dated commitments depend on a late project (CD-239, CD-267). Project Actual Cost is "
                    "an operational measure that reconciles to the GL postings of DP-191 (CD-353, CD-361); it is never "
                    "certified expense, which only DP-191 publishes."),
        business_questions=[
            "Which active projects are Red or Amber this week, and which milestones have slipped against baseline and by how much?",
            "How do actual cost to date and forecast cost at completion compare with the approved budget, by program and project type?",
            "Which regulatory change items and product change initiatives depend on a project whose go-live forecast falls after the compliance or effective date?",
            "Does each project's reported actual cost reconcile to the GL postings booked to it?",
            "Which active projects have no status report in the last two weeks, no scope link, or a departed manager or sponsor?",
            "How is the portfolio's budget spread across strategic objectives, business lines and project types?",
        ],
        grain=("Project (PRJT-) x status reporting date, with change program as parent and project milestone (project x milestone) and "
               "project scope link (project x delivered object x effective period) as child tables; weekly snapshot"),
        dimensions=["Change program and strategic objective", "Project, project type, phase, status and delivery methodology",
                    "Program business lines and impacted data domains", "Sponsor and project manager (DP-192)", "Milestone gate type",
                    "Delivered object type and delivered object (application DP-211, data product DP-101, DQ issue DP-103)",
                    "Budget plan version (19)", "Fiscal period (DP-013)", "Status reporting date"],
        measures=[
            ("Active Projects", "Count of Projects with Project Status = Active on the as-of date, by Project Type, Project Phase and Parent Change Program.",
             [("41", "Project", "Project ID"), ("41", "Project", "Project Status"), ("41", "Project", "Project Type"),
              ("41", "Project", "Project Phase"), ("41", "Project", "Parent Change Program")]),
            ("Projects by Overall RAG", "Active Projects counted by the Overall RAG of their latest Project Status Report (Status Reporting Date <= as-of date), with Schedule, Budget, Scope and Risk RAG as drill-downs.",
             [("41", "Project Status Report", "Reported Project"), ("41", "Project Status Report", "Status Reporting Date"),
              ("41", "Project Status Report", "Overall RAG"), ("41", "Project Status Report", "Schedule RAG"),
              ("41", "Project Status Report", "Budget RAG"), ("41", "Project Status Report", "Scope RAG"),
              ("41", "Project Status Report", "Risk RAG"), "Active Projects"]),
            ("Milestone Slippage (days)", "For each Project Milestone: (Actual Milestone Date, or Forecast Milestone Date if not achieved) - Baseline Milestone Date; project slippage is the maximum over its unachieved milestones.",
             [("41", "Project Milestone", "Milestone Project"), ("41", "Project Milestone", "Milestone Name"),
              ("41", "Project Milestone", "Baseline Milestone Date"), ("41", "Project Milestone", "Forecast Milestone Date"),
              ("41", "Project Milestone", "Actual Milestone Date")]),
            ("Late Milestones", "Count of Project Milestones with Baseline Milestone Date before the as-of date and no Actual Milestone Date, by Milestone Gate Type.",
             [("41", "Project Milestone", "Baseline Milestone Date"), ("41", "Project Milestone", "Actual Milestone Date"),
              ("41", "Project Milestone", "Milestone Gate Type")]),
            ("Projects Past Planned End", "Active Projects with Planned End Date before the as-of date and no Actual End Date.",
             [("41", "Project", "Planned End Date"), ("41", "Project", "Actual End Date"), "Active Projects"]),
            ("Project Actual Cost", "Actual Cost to Date from each project's latest Project Status Report; an operational measure under its own name (CD-353), never presented as expense.",
             [("41", "Project Status Report", "Actual Cost to Date"), ("41", "Project Status Report", "Status Reporting Date")]),
            ("Budget Variance at Completion", "Forecast Cost at Completion - Approved Budget Amount, and the same / Approved Budget Amount as a %; projects more than 10% over are flagged.",
             [("41", "Project Status Report", "Forecast Cost at Completion"), ("41", "Project", "Approved Budget Amount")]),
            ("Budget Consumed %", "Project Actual Cost / Approved Budget Amount, shown beside percent of milestones achieved (milestones with Actual Milestone Date / all milestones).",
             [("41", "Project", "Approved Budget Amount"), ("41", "Project Milestone", "Actual Milestone Date"), "Project Actual Cost"]),
            ("Project Cost Reconciliation Difference", "Project Actual Cost at fiscal period end - cumulative sum of Posted Amount (Debit Credit Indicator = Debit positive, Credit negative) of GL Postings on journals with Journal Status = Posted whose Other Segment Values carry the Project ID, through the same Posting Accounting Period (from DP-191); flagged when the absolute difference exceeds the tolerance (drafted as 5% of Project Actual Cost).",
             [("19", "GL Posting", "Journal ID"), ("19", "GL Posting", "Posted Amount"), ("19", "GL Posting", "Debit Credit Indicator"),
              ("19", "GL Posting", "Other Segment Values"), ("19", "GL Posting", "Posted Account"), ("19", "Journal Entry", "Journal ID"),
              ("19", "Journal Entry", "Journal Status"), ("19", "Journal Entry", "Posting Accounting Period"),
              ("09", "Fiscal Period", "Period End Date"), "Project Actual Cost"]),
            ("Budgets Without Approved Plan Version", "Active Projects whose Budget Plan Version is blank or has Plan Version Status not in (Approved, Locked).",
             [("41", "Project", "Budget Plan Version"), ("19", "Financial Plan Version", "Financial Plan Version ID"),
              ("19", "Financial Plan Version", "Plan Version Status"), "Active Projects"]),
            ("Stale Status Reports", "Active Projects whose latest Status Reporting Date is more than 14 days before the as-of date, or that have none.",
             [("41", "Project Status Report", "Status Reporting Date"), "Active Projects"]),
            ("Regulatory Changes at Risk", "Regulatory Change Items linked through an effective Project Scope Link (Delivered Regulatory Change Item) whose Change Compliance Date is before the project's Go-Live Approval milestone forecast (or Planned End Date), or whose project's latest Overall RAG is Red; Regulatory Change Stage in (Withdrawn, Implemented) excluded.",
             [("41", "Project Scope Link", "Scoping Project"), ("41", "Project Scope Link", "Delivered Regulatory Change Item"),
              ("41", "Project Scope Link", "Scope Link Effective From"), ("41", "Project Scope Link", "Scope Link Effective To"),
              ("38", "Regulatory Change Item", "Regulatory Change ID"), ("38", "Regulatory Change Item", "Change Compliance Date"),
              ("38", "Regulatory Change Item", "Regulatory Change Stage"), ("41", "Project Milestone", "Milestone Gate Type"),
              ("41", "Project Milestone", "Forecast Milestone Date"), ("41", "Project", "Planned End Date"), "Projects by Overall RAG"]),
            ("Product Changes at Risk", "Product Change Initiatives linked through an effective Project Scope Link (Delivered Change Initiative) whose Planned Effective Date is before the project's Go-Live Approval milestone forecast (or Planned End Date), or whose project's latest Overall RAG is Red; Change Status closed or withdrawn excluded.",
             [("41", "Project Scope Link", "Scoping Project"), ("41", "Project Scope Link", "Delivered Change Initiative"),
              ("41", "Project Scope Link", "Scope Link Effective From"), ("41", "Project Scope Link", "Scope Link Effective To"),
              ("36", "Product Change Initiative", "Product Change Initiative ID"),
              ("36", "Product Change Initiative", "Planned Effective Date"), ("36", "Product Change Initiative", "Change Status"),
              ("41", "Project Milestone", "Forecast Milestone Date"), ("41", "Project", "Planned End Date"), "Projects by Overall RAG"]),
            ("Projects Without Scope Link", "Active Projects of Project Type in (Product Launch, Regulatory, Data) with no effective Project Scope Link whose Delivered Object Type matches the project type.",
             [("41", "Project Scope Link", "Scoping Project"), ("41", "Project Scope Link", "Delivered Object Type"),
              ("41", "Project", "Project Type"), "Active Projects"]),
            ("Projects With Departed Leadership", "Active Projects whose Project Manager or Project Sponsor, or whose parent program's Program Sponsor, has Employment Status = Terminated in DP-192.",
             [("41", "Project", "Project Manager"), ("41", "Project", "Project Sponsor"), ("41", "Change Program", "Program Sponsor"),
              ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), "Active Projects"]),
            ("Portfolio Budget by Objective", "Sum of Approved Budget Amount and of Forecast Cost at Completion of Active Projects by the parent program's Strategic Objective and Program Business Lines.",
             [("41", "Change Program", "Strategic Objective"), ("41", "Change Program", "Program Business Lines"),
              ("41", "Project", "Approved Budget Amount"), ("41", "Project Status Report", "Forecast Cost at Completion"), "Active Projects"]),
            ("Delivered Data Fixes Open", "21 Data Quality Issues linked through an effective Project Scope Link (Delivered Data Quality Issue) whose DQ Issue Status is not closed after the project's Actual End Date, or whose DQ Issue Target Resolution Date is before the project's Planned End Date.",
             [("41", "Project Scope Link", "Delivered Data Quality Issue"), ("21", "Data Quality Issue", "DQ Issue ID"),
              ("21", "Data Quality Issue", "DQ Issue Status"), ("21", "Data Quality Issue", "DQ Issue Target Resolution Date"),
              ("41", "Project", "Actual End Date"), ("41", "Project", "Planned End Date")]),
        ],
        inputs=[
            ("41", "Change Program", ["Change Program Code", "Change Program Name", "Program Sponsor", "Strategic Objective",
                                      "Program Business Lines", "Program Start Date", "Program Status"]),
            ("41", "Project", ["Project ID", "Project Name", "Parent Change Program", "Project Type", "Delivery Methodology", "Project Phase",
                               "Project Status", "Project Sponsor", "Project Manager", "Planned Start Date", "Planned End Date",
                               "Actual End Date", "Approved Budget Amount", "Budget Plan Version", "Capitalization Candidate Indicator",
                               "Impacted Data Domains"]),
            ("41", "Project Milestone", ["Milestone Project", "Milestone Name", "Milestone Gate Type", "Baseline Milestone Date",
                                         "Forecast Milestone Date", "Actual Milestone Date"]),
            ("41", "Project Status Report", ["Reported Project", "Status Reporting Date", "Overall RAG", "Schedule RAG", "Budget RAG",
                                             "Scope RAG", "Risk RAG", "Actual Cost to Date", "Forecast Cost at Completion"]),
            ("41", "Project Scope Link", ["Scoping Project", "Delivered Object Type", "Delivered Change Initiative", "Delivered Data Product",
                                          "Delivered Data Quality Issue", "Delivered Application", "Delivered Regulatory Change Item",
                                          "Scope Link Effective From", "Scope Link Effective To"]),
            ("41", "Application", ["Application ID", "Application Name", "Application Status", "Production Go-Live Date"]),
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Change Title", "Product Change Type", "Change Status",
                                                 "Planned Effective Date", "Actual Effective Date", "Launch Project Code"]),
            ("38", "Regulatory Change Item", ["Regulatory Change ID", "Change Regulator", "Change Title", "Regulatory Change Stage",
                                              "Change Compliance Date"]),
            ("21", "Data Product", ["Data Product ID", "Data Product Name", "Data Product Status"]),
            ("21", "Data Quality Issue", ["DQ Issue ID", "DQ Issue Severity", "DQ Issue Status", "DQ Issue Target Resolution Date"]),
            ("19", "Financial Plan Version", ["Financial Plan Version ID", "Plan Cycle Name", "Financial Plan Type", "Plan Scenario",
                                              "Plan Fiscal Year", "Plan Version Status"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Ledger", "Journal Status", "Posting Accounting Period"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount",
                                  "Cost Center Segment Value", "Other Segment Values"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Period End Date"]),
        ],
        upstream=["DP-211", "DP-191", "DP-190", "DP-192", "DP-101", "DP-103", "DP-013"],
        refresh="Weekly",
        timeliness="By 9am ET each Monday for status reports submitted to the prior Friday; the GL cost reconciliation is refreshed on business day 8 after month-end, after DP-191's hard close",
        history="Weekly portfolio snapshots and every status report kept for the life of the project plus 7 years; milestone baselines kept as first recorded with every forecast change in the weekly snapshot",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Project with Project Status = Active has a Project Manager who resolves to an employee in DP-192 and a Planned End Date.",
            "There is at most one Project Status Report per Reported Project and Status Reporting Date, and its Forecast Cost at Completion is not less than its Actual Cost to Date.",
            "Every Project Scope Link has exactly one delivered reference populated, and it matches the Delivered Object Type.",
            "Every Product Change Initiative whose Launch Project Code is populated is the Delivered Change Initiative of an effective Project Scope Link from that Project ID (CD-267).",
            "No Actual Milestone Date and no Actual End Date is later than the snapshot date.",
            "Project Cost Reconciliation Difference is within tolerance for every project at each locked fiscal period, or carries a recorded reason.",
        ],
        notes=("Boundary (CD-239, CD-267): 41 masters the project and Project Scope Link is the only project link; 36 Launch "
               "Project Code is a derived copy checked here. DP-058 keeps go-to-market launch tracking and DP-107 launch "
               "readiness; DP-106 reads 41 Project directly. DP-223 Regulatory Examinations & Change Management lists this "
               "product upstream, so this product reads 38 Regulatory Change Item directly and must never list DP-223 (no "
               "cycle); 36 Product Change Initiative is likewise read directly, so DP-105 to DP-107 may depend on this product. "
               "Money (CD-353, CD-361): Project Actual Cost and Forecast Cost at Completion are operational measures from the "
               "PMO's status reports; the reconciliation reads GL postings from DP-191 and account types from DP-190; certified "
               "operating expense is only DP-191's. Capitalization is 19's decision: Capitalization Candidate Indicator is shown "
               "as a flag, never as a capitalized amount (41 SME Q8). Budget plan versions are read from 19 directly; DP-194 "
               "presents the plan and is not listed upstream so it may later take project forecasts from this product. Delivered "
               "data products resolve to the DP-101 catalog and data quality issues to DP-103. Supporting functions: FN-37 and "
               "FN-44 see launches and regulatory commitments at risk; FN-38 cost and reconciliation; FN-50 data deliverables; "
               "FN-01 the strategic portfolio. PII = Y: sponsors and project managers are employee keys; the committee view "
               "shows names, the wide view programs and RAG only. Taxonomy gap: 19 GL Posting has no project reference; the "
               "Project ID is matched inside Other Segment Values, so the reconciliation depends on a project segment in the "
               "chart (confirm with 19). Taxonomy gap: Project references only a Financial Plan Version, not the plan lines "
               "CD-267 names, so budget is the Approved Budget Amount on Project and is not dated. Taxonomy gap: Project has no "
               "baseline or forecast end date; go-live is taken from the Go-Live Approval milestone. Taxonomy gap: Project "
               "Status Report has no capital versus operating split of cost. Open SME questions: 41 Q7 (PMO remit: technology "
               "only or all change), Q8 (capitalization decision). Decisions: CD-239, CD-267, CD-293, CD-353, CD-361."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-235": dict(
        definition=("The brand register (BRD-) with brand levels, parent brands, owning entities and permitted jurisdictions, the "
                    "dated brand standard versions, who may use each brand under which contract (brand use authorizations), and "
                    "the trademark registrations (TMARK-), docket deadlines and trademark license grants that protect it. It "
                    "publishes the brand register mastered in 42 (CD-271) as the brand dimension other products join to, and "
                    "shows where a brand is permitted without a registered mark, which renewals and office actions are due, and "
                    "which licensees use a brand outside a license or contract. Contracts come from DP-213; the product owns no "
                    "certified metric family."),
        business_questions=[
            "Which active brands are permitted in a jurisdiction where no registered trademark protects them?",
            "Which trademark renewals, declarations of use and office action responses fall due in the next 90 days, and which were missed?",
            "Which brand use authorizations have no active contract, or run beyond the trademark license grant that covers the licensee?",
            "Which active brands have no current brand standard version?",
            "Which retired brands are still authorized for use or licensed to a third party?",
        ],
        grain=("Brand (BRD-) x effective period (SCD type 2), with brand standard version, brand use authorization (brand x licensee x "
               "effective period), trademark registration (TMARK-), docket deadline and trademark license grant as child tables"),
        dimensions=["Brand, brand level and parent brand", "Brand status", "Brand owning entity and licensee entity (DP-013)",
                    "Licensee party (DP-240)", "Permitted jurisdiction and IP office", "Trademark status and Nice class",
                    "Docket deadline type", "Brand use scope", "Contract (DP-213)", "Effective date"],
        measures=[
            ("Active Brands", "Count of Brands with Brand Status = Active on the as-of date, by Brand Level and Brand Owning Entity.",
             [("42", "Brand", "Brand ID"), ("42", "Brand", "Brand Status"), ("42", "Brand", "Brand Level"),
              ("42", "Brand", "Brand Owning Entity")]),
            ("Brands Without Current Standard", "Active Brands with no Brand Standard Version whose Standard Effective From <= as-of date < Standard Effective To (or open).",
             [("42", "Brand Standard Version", "Standard Brand"), ("42", "Brand Standard Version", "Standard Effective From"),
              ("42", "Brand Standard Version", "Standard Effective To"), "Active Brands"]),
            ("Unprotected Permitted Jurisdictions", "Count of (Active Brand x jurisdiction in Brand Permitted Jurisdictions) with no Trademark Registration whose Protected Brand is the brand, Trademark Status = Registered and IP Office covering the jurisdiction (national office, or a regional office such as EUIPO for its member countries, through the maintained office-to-country mapping); jurisdictions covered only by a pending application are shown separately.",
             [("42", "Brand", "Brand Permitted Jurisdictions"), ("39", "Trademark Registration", "Protected Brand"),
              ("39", "Trademark Registration", "Trademark Status"), ("39", "Trademark Registration", "IP Office"),
              ("09", "Country", "Country Code (Alpha-2)"), "Active Brands"]),
            ("Docket Deadlines Due (90 Days)", "Trademark Docket Deadlines with Docket Completed Date blank and Docket Due Date within the next 90 days, by Docket Deadline Type and protected brand.",
             [("39", "Trademark Docket Deadline", "Docket Registration"), ("39", "Trademark Docket Deadline", "Docket Deadline Type"),
              ("39", "Trademark Docket Deadline", "Docket Due Date"), ("39", "Trademark Docket Deadline", "Docket Completed Date")]),
            ("Missed Docket Deadlines", "Trademark Docket Deadlines with Docket Due Date before the as-of date and Docket Completed Date blank or after Docket Due Date.",
             [("39", "Trademark Docket Deadline", "Docket Due Date"), ("39", "Trademark Docket Deadline", "Docket Completed Date"),
              ("39", "Trademark Docket Deadline", "Docket Action Status")]),
            ("Lapsed Marks on Active Brands", "Trademark Registrations with Trademark Status in (Abandoned / Withdrawn, Canceled / Expired) whose Protected Brand is an Active Brand and that have no later Registered mark at the same IP Office.",
             [("39", "Trademark Registration", "Trademark Registration ID"), ("39", "Trademark Registration", "Trademark Status"),
              ("39", "Trademark Registration", "Protected Brand"), ("39", "Trademark Registration", "IP Office"), "Active Brands"]),
            ("Authorizations Without Active Contract", "Brand Use Authorizations effective on the as-of date whose Brand Use Contract is blank, or whose contract in DP-213 has Contract Status not in force or Contract Expiry Date before the as-of date.",
             [("42", "Brand Use Authorization", "Authorized Brand"), ("42", "Brand Use Authorization", "Brand Use Contract"),
              ("42", "Brand Use Authorization", "Brand Use Effective From"), ("42", "Brand Use Authorization", "Brand Use Effective To"),
              ("39", "Contract", "Contract ID"), ("39", "Contract", "Contract Status"), ("39", "Contract", "Contract Expiry Date")]),
            ("Authorizations Beyond License", "Brand Use Authorizations to a third party (Licensee Party, or a Licensee Entity other than the Trademark Owner Entity) with no Trademark License Grant to the same licensee on a registration protecting the brand, or whose Brand Use Effective To is later than the License Effective To.",
             [("42", "Brand Use Authorization", "Licensee Entity"), ("42", "Brand Use Authorization", "Licensee Party"),
              ("42", "Brand Use Authorization", "Brand Use Effective To"), ("39", "Trademark License Grant", "Licensed Registration"),
              ("39", "Trademark License Grant", "Licensee Entity"), ("39", "Trademark License Grant", "Licensee Party"),
              ("39", "Trademark License Grant", "License Effective To"), ("39", "Trademark Registration", "Trademark Owner Entity"),
              ("39", "Trademark Registration", "Protected Brand")]),
            ("Authorizations Expiring (90 Days)", "Brand Use Authorizations and Trademark License Grants whose Brand Use Effective To or License Effective To falls in the next 90 days, by Brand Use Scopes.",
             [("42", "Brand Use Authorization", "Brand Use Effective To"), ("42", "Brand Use Authorization", "Brand Use Scopes"),
              ("39", "Trademark License Grant", "License Effective To")]),
            ("Retired Brands Still Authorized", "Brands with Brand Status = Retired that have a Brand Use Authorization or a Trademark License Grant on a protecting registration effective on the as-of date.",
             [("42", "Brand", "Brand Status"), ("42", "Brand Use Authorization", "Authorized Brand"),
              ("42", "Brand Use Authorization", "Brand Use Effective From"), ("42", "Brand Use Authorization", "Brand Use Effective To"),
              ("39", "Trademark License Grant", "License Effective From"), ("39", "Trademark License Grant", "License Effective To"),
              ("39", "Trademark License Grant", "Licensed Registration"), ("39", "Trademark Registration", "Protected Brand")]),
        ],
        inputs=[
            ("42", "Brand", ["Brand ID", "Brand Name", "Brand Level", "Parent Brand", "Brand Status", "Brand Permitted Jurisdictions",
                             "Brand Owning Entity"]),
            ("42", "Brand Standard Version", ["Standard Brand", "Standard Version Number", "Visual Identity Rules Summary",
                                              "Standard Approved By", "Standard Effective From", "Standard Effective To"]),
            ("42", "Brand Use Authorization", ["Authorized Brand", "Licensee Entity", "Licensee Party", "Brand Use Scopes",
                                               "Brand Use Contract", "Brand Use Effective From", "Brand Use Effective To"]),
            ("39", "Trademark Registration", ["Trademark Registration ID", "Mark Text", "Trademark Owner Entity", "IP Office",
                                              "Trademark Application Number", "Trademark Registration Number",
                                              "Trademark Registration Date", "Nice Classes", "Trademark Status", "Protected Brand"]),
            ("39", "Trademark Docket Deadline", ["Docket Registration", "Docket Deadline Type", "Docket Due Date", "Docket Completed Date",
                                                 "Docket Action Status"]),
            ("39", "Trademark License Grant", ["Licensed Registration", "Licensee Entity", "Licensee Party", "Licensing Contract",
                                               "Permitted Use", "License Effective From", "License Effective To"]),
            ("39", "Contract", ["Contract ID", "Contract Title", "Contract Status", "Contract Effective Date", "Contract Expiry Date",
                                "Contracting Entity"]),
            ("02", "Party", ["Party ID", "Party Display Name", "Party Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("09", "Country", ["Country Code (Alpha-2)", "Country Short Name"]),
        ],
        upstream=["DP-213", "DP-240", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a new brand, authorization or docket deadline is published the business day after it is recorded",
        history="SCD type 2 on every brand, standard, authorization, registration and license grant, kept indefinitely (trademark rights depend on the history of use and registration)",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Brand has a Brand Level, and every Parent Brand resolves to an existing Brand ID with no cycle in the brand hierarchy.",
            "Every Protected Brand on a Trademark Registration resolves to a Brand ID, and every Docket Registration and Licensed Registration resolves to a Trademark Registration ID.",
            "Every Brand Use Authorization has exactly one of Licensee Entity or Licensee Party populated and Brand Use Effective From <= Brand Use Effective To.",
            "Every Brand Use Contract and Licensing Contract resolves to a Contract ID in DP-213.",
            "Brand Standard Version periods for one brand do not overlap.",
            "A Trademark Registration with Trademark Status = Registered has a Trademark Registration Number and Trademark Registration Date.",
        ],
        notes=("Master concept: the brand register (BRD-) moved from 04 to 42 under CD-271 option A; Corporate Brand, Affiliate / "
               "Boutique Brand and Co-Brand rows are stewarded by Corporate Communications and Sub-Brand and Product Range "
               "Brand rows by 04 Marketing, under the row rule on the register. Trademarks are 39 (CD-259), read here with the "
               "contracts from DP-213 (CD-354). This is a consumer-aligned Master & Reference product: it publishes the brand "
               "dimension that DP-236 and other products join to. Boundary with DP-090 Social Media & Brand Performance: DP-090 "
               "stays the distribution marketing view of brand performance on the firm's social and paid channels and keeps "
               "reading 42 Brand as its brand dimension (it may take it from this product); this product holds the register, "
               "standards, usage rights and protection and measures no channel performance. Reputation measurement by brand is "
               "DP-236. Licensee parties come from DP-240 and entities from DP-013. Contract Status, Contract Effective Date and Contract Expiry Date on 39 Contract are derived copies of the typed agreement's values; they are read as DP-213 publishes them (CD-257), not from the typed owner. Supporting functions: FN-45 trademark "
               "docket and licenses; FN-09 brand standards; FN-37 brands for new product ranges; FN-04 co-brands with "
               "distribution partners. PII = Y only through Standard Approved By (an employee key); the register itself carries "
               "no personal data. Taxonomy gap: Brand Use Authorization has no jurisdiction and no approval status (dropped in "
               "the 42 review), so use outside a permitted territory cannot be tested; out-of-authorization use is tested only "
               "against license grants and contracts. Taxonomy gap: Brand Permitted Jurisdictions is a text list and Trademark "
               "Registration has no jurisdiction attribute, only IP Office, so coverage depends on a maintained office-to-"
               "country mapping. Open SME question: 42 Q1 (register run by corporate communications or marketing). Decisions: "
               "CD-259, CD-271, CD-296, CD-354. "
               "W1: EU Member State Indicator (09 Country) dropped, no successor in the wealth 09 (CW-909); EUIPO coverage of "
               "EU countries is read from the same office-to-country mapping as every other regional IP office (09 suggests "
               "a Geographic Group if a report needs the membership)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-236": dict(
        definition=("Media relations and reputation for the firm as a company: media inquiries (MEDQ-) with response deadline "
                    "and response type, press releases (NEWS-) with embargo, issue time and the 08 compliance review of releases "
                    "about funds in offering, coverage items (MCOV-) by outlet, sentiment, reach, mentioned brand and quoted "
                    "spokesperson, spokesperson authorizations, reputation measurements by brand, measure and stakeholder group, "
                    "corporate events and award entries. It tells corporate communications which topics and releases drive "
                    "coverage and sentiment, whether inquiry deadlines were met, and whether fund releases were approved before "
                    "issue. Brands come from DP-235, the compliance review from DP-036 and fund and manager award results from "
                    "11 Award, read directly; the product owns no certified metric family."),
        business_questions=[
            "How many media inquiries did we receive by topic and outlet, and how many are open past their response deadline?",
            "Which press releases about funds in offering were issued without an approved compliance review, or before it was approved?",
            "What coverage did each release generate, with what reach and sentiment, and were any embargoes broken?",
            "How is each brand's reputation trending by measure and stakeholder group?",
            "Were spokespeople quoted in coverage authorized on the publication date?",
            "Which award entries won, and which fund or manager wins are paid-to-participate or lack citation approval?",
        ],
        grain=("Media coverage item (MCOV-) x mentioned brand, with media inquiry (MEDQ-), press release (NEWS-), reputation measurement "
               "(brand x measure x provider x stakeholder group x period) and award entry (program x category x year x entrant) as "
               "companion facts"),
        dimensions=["Brand and brand level (DP-235)", "Media outlet and outlet type (DP-240)", "Media beat and inquiry topic",
                    "Coverage sentiment", "Press release type and issuing entity (DP-013)", "Release subject product (DP-004)",
                    "Spokesperson (DP-192)", "Reputation measure, provider and stakeholder group", "Award program and entrant type",
                    "Publication date and reporting period (DP-013)"],
        measures=[
            ("Media Inquiries Received", "Count of Media Inquiries with Inquiry Received Timestamp in the period, by Inquiry Topic, Inquiring Outlet's Media Outlet Type and Inquiry Response Type.",
             [("42", "Media Inquiry", "Media Inquiry ID"), ("42", "Media Inquiry", "Inquiry Received Timestamp"),
              ("42", "Media Inquiry", "Inquiry Topic"), ("42", "Media Inquiry", "Inquiring Outlet"),
              ("42", "Media Inquiry", "Inquiry Response Type"), ("42", "Media Contact Profile", "Media Outlet Type")]),
            ("Inquiries Open Past Deadline", "Media Inquiries with Inquiry Status open on the as-of timestamp and Inquiry Response Deadline before it; from the daily snapshots, the share of inquiries closed on or before their deadline is published as Response Deadline Met %.",
             [("42", "Media Inquiry", "Inquiry Status"), ("42", "Media Inquiry", "Inquiry Response Deadline"), "Media Inquiries Received"]),
            ("Declined to Comment Share %", "Inquiries with Inquiry Response Type = Declined to Comment / inquiries closed in the period, by Inquiry Topic.",
             [("42", "Media Inquiry", "Inquiry Response Type"), ("42", "Media Inquiry", "Inquiry Topic"), "Media Inquiries Received"]),
            ("Fund Releases Without Prior Approval", "Press Releases with Press Release Status in (Issued, Corrected) and Fund in Offering Indicator = Y whose Release Compliance Review is blank, or whose 08 Compliance Approval has Approval Status not approved or Approval Decision Date after Release Timestamp.",
             [("42", "Press Release", "Press Release ID"), ("42", "Press Release", "Press Release Status"),
              ("42", "Press Release", "Fund in Offering Indicator"), ("42", "Press Release", "Release Compliance Review"),
              ("42", "Press Release", "Release Timestamp"), ("08", "Compliance Review", "Review ID"),
              ("08", "Compliance Approval", "Approval Status"), ("08", "Compliance Approval", "Approval Decision Date")]),
            ("Coverage Volume and Reach", "Count of Media Coverage Items and sum of Estimated Reach with Coverage Publication Date in the period, by Coverage Outlet, Media Outlet Type, Coverage Mentioned Brands and Coverage Sentiment.",
             [("42", "Media Coverage Item", "Coverage Item ID"), ("42", "Media Coverage Item", "Coverage Publication Date"),
              ("42", "Media Coverage Item", "Estimated Reach"), ("42", "Media Coverage Item", "Coverage Outlet"),
              ("42", "Media Coverage Item", "Coverage Mentioned Brands"), ("42", "Media Coverage Item", "Coverage Sentiment"),
              ("42", "Media Contact Profile", "Media Outlet Type")]),
            ("Net Coverage Sentiment %", "(Coverage items with Coverage Sentiment = Positive - items with Negative) / all coverage items in the period, by brand; Mixed and Neutral count in the denominator only.",
             [("42", "Media Coverage Item", "Coverage Sentiment"), "Coverage Volume and Reach"]),
            ("Coverage per Release", "Count of Media Coverage Items whose Originating Press Release is the release, and their summed Estimated Reach, for releases issued in the period, by Press Release Type.",
             [("42", "Media Coverage Item", "Originating Press Release"), ("42", "Media Coverage Item", "Estimated Reach"),
              ("42", "Press Release", "Press Release Type"), ("42", "Press Release", "Release Timestamp")]),
            ("Embargo Breaches", "Coverage items with an Originating Press Release whose Coverage Publication Date is earlier than the release's Embargo Until Timestamp date.",
             [("42", "Media Coverage Item", "Originating Press Release"), ("42", "Media Coverage Item", "Coverage Publication Date"),
              ("42", "Press Release", "Embargo Until Timestamp")]),
            ("Unauthorized Spokesperson Quotes", "Coverage items whose Quoted Spokesperson has no Spokesperson Authorization with Spokesperson Effective From <= Coverage Publication Date < Spokesperson Effective To (or open), or whose employee has Employment Status = Terminated at publication.",
             [("42", "Media Coverage Item", "Quoted Spokesperson"), ("42", "Media Coverage Item", "Coverage Publication Date"),
              ("42", "Spokesperson Authorization", "Spokesperson"), ("42", "Spokesperson Authorization", "Spokesperson Effective From"),
              ("42", "Spokesperson Authorization", "Spokesperson Effective To"), ("20", "Employee", "Employee ID"),
              ("20", "Employee", "Employment Status")]),
            ("Reputation Measure Change", "Measurement Value for the period - Measurement Value for the prior period with the same Measured Brand, Reputation Measure, Measurement Provider, Measurement Stakeholder Group and Measurement Data Basis.",
             [("42", "Reputation Measurement", "Measured Brand"), ("42", "Reputation Measurement", "Reputation Measure"),
              ("42", "Reputation Measurement", "Measurement Value"), ("42", "Reputation Measurement", "Measurement Provider"),
              ("42", "Reputation Measurement", "Measurement Stakeholder Group"), ("42", "Reputation Measurement", "Measurement Data Basis"),
              ("42", "Reputation Measurement", "Measurement Period Start"), ("42", "Reputation Measurement", "Measurement Period End")]),
            ("Award Wins", "Corporate Award Entries in the Award Year with Firm Award Result = Winner (Award Entrant Type Firm or Individual (Corporate)), plus product and manager entries whose Fund or Manager Award Record has Award Outcome = Winner in 11; 11 wins with Paid to Participate Indicator = Y or no Citation Approval are shown separately.",
             [("42", "Corporate Award Entry", "Award Program Name"), ("42", "Corporate Award Entry", "Award Year"),
              ("42", "Corporate Award Entry", "Award Entrant Type"), ("42", "Corporate Award Entry", "Firm Award Result"),
              ("42", "Corporate Award Entry", "Fund or Manager Award Record"), ("11", "Award", "Award ID"),
              ("11", "Award", "Award Outcome"), ("11", "Award", "Paid to Participate Indicator"), ("11", "Award", "Citation Approval")]),
            ("Inquiries Escalated to Issues", "Media Inquiries with Inquiry Communications Issue populated, by Inquiry Topic; the issue itself is tracked in DP-237.",
             [("42", "Media Inquiry", "Inquiry Communications Issue"), ("42", "Media Inquiry", "Inquiry Topic")]),
        ],
        inputs=[
            ("42", "Media Contact Profile", ["Media Party", "Media Outlet", "Media Outlet Type", "Media Beats", "Media Relationship Owner",
                                             "Media Profile Effective From", "Media Profile Effective To"]),
            ("42", "Media Inquiry", ["Media Inquiry ID", "Inquiring Journalist", "Inquiring Outlet", "Inquiry Received Timestamp",
                                     "Inquiry Topic", "Inquiry Response Deadline", "Inquiry Handled By", "Inquiry Response Type",
                                     "Inquiry Status", "Inquiry Communications Issue"]),
            ("42", "Press Release", ["Press Release ID", "Press Release Type", "Press Release Headline", "Issuing Entity",
                                     "Release Subject Products", "Release Change Initiative", "Embargo Until Timestamp",
                                     "Release Timestamp", "Release Publication Property", "Release Compliance Review",
                                     "Fund in Offering Indicator", "Release Approved By", "Press Release Status",
                                     "Coordinated Shareholder Communication"]),
            ("42", "Media Coverage Item", ["Coverage Item ID", "Coverage Outlet", "Coverage Author", "Coverage Publication Date",
                                           "Coverage Headline", "Estimated Reach", "Coverage Sentiment", "Coverage Mentioned Brands",
                                           "Quoted Spokesperson", "Originating Press Release", "Originating Media Inquiry"]),
            ("42", "Spokesperson Authorization", ["Spokesperson", "Authorized Topics", "Authorized Markets",
                                                  "Media Training Completion Date", "Spokesperson Effective From",
                                                  "Spokesperson Effective To"]),
            ("42", "Reputation Measurement", ["Measured Brand", "Reputation Measure", "Measurement Value", "Measurement Stakeholder Group",
                                              "Measurement Provider", "Measurement Data Basis", "Measurement Period Start",
                                              "Measurement Period End"]),
            ("42", "Brand", ["Brand ID", "Brand Name", "Brand Level"]),
            ("42", "Corporate Event", ["Corporate Event ID", "Corporate Event Name", "Corporate Event Type",
                                       "Corporate Event Start Timestamp", "Event Press Release"]),
            ("42", "Corporate Award Entry", ["Award Program Name", "Award Organizer", "Entry Category", "Award Year", "Award Entrant Type",
                                             "Entrant Entity", "Entrant Product", "Entrant Employee", "Firm Award Result",
                                             "Fund or Manager Award Record"]),
            ("11", "Award", ["Award ID", "Award Outcome", "Award Date", "Paid to Participate Indicator", "Citation Approval"]),
            ("08", "Compliance Review", ["Review ID", "Review Type", "Products Featured", "Submission Timestamp"]),
            ("08", "Compliance Approval", ["Approval Status", "Approval Decision Date"]),
            ("01", "Investment Product", ["Product ID", "Product Marketing Name"]),
            ("02", "Party", ["Party ID", "Party Display Name"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
        ],
        upstream=["DP-235", "DP-036", "DP-004", "DP-240", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 from the PR CRM and the media monitoring feed; reputation measurements on receipt from the provider",
        history="Daily inquiry snapshots kept for 25 months; inquiries, releases, coverage, authorizations and award entries kept for 7 years; reputation measurements kept indefinitely for trend",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Press Release with Fund in Offering Indicator = Y and Press Release Status in (Scheduled, Issued, Corrected) has a Release Compliance Review that resolves to an 08 Review ID in DP-036.",
            "Every Coverage Mentioned Brands value and every Measured Brand resolves to a Brand ID in DP-235.",
            "Every Originating Press Release and Originating Media Inquiry on a coverage item resolves to an existing release or inquiry, and the release's Release Timestamp is not after the coverage's Coverage Publication Date unless an embargo breach is flagged.",
            "Inquiry Response Deadline is not earlier than Inquiry Received Timestamp for any Media Inquiry.",
            "Measurement Period Start <= Measurement Period End for every Reputation Measurement, and no two rows share brand, measure, provider, stakeholder group, data basis and period.",
            "Every Corporate Award Entry with Award Entrant Type Product or Portfolio Manager and a result has Fund or Manager Award Record populated, and Firm Award Result is held only for Firm and Individual (Corporate) entries.",
        ],
        notes=("Boundary (CD-272): 42 masters the corporate message; 04 keeps web and social channels and social listening "
               "(DP-090), 08 the compliance review of releases about funds in offering (DP-036, read here, never re-reviewed), "
               "and 11 the fund and manager award results and the paid-to-participate fact (read from 11 Award directly, "
               "as no live product publishes it). Issues and crisis statements are DP-237; brand register is DP-235. Journalists and outlets are "
               "02 parties (DP-240). Supporting functions: FN-09 brand and coverage; FN-13 review of fund releases; FN-37 "
               "product launch releases (Release Change Initiative); FN-16 share of voice and reputation against peers. PII = "
               "Y: journalist profiles, inquiring journalists, coverage authors, spokespeople and award entrants are personal "
               "data; publish outlet-level and brand-level aggregates for wide use, and keep journalist-level rows to the media "
               "relations team. Operating model: in house; PR agencies and monitoring providers do not change the grain "
               "(Measurement Provider and monitoring feeds are sources). Taxonomy gap: Media Inquiry has no response timestamp, "
               "so deadline performance is derived from Inquiry Status in daily snapshots and is accurate only to the day. "
               "Taxonomy gap: Media Coverage Item has no topic, so a spokesperson's Authorized Topics cannot be checked against "
               "what was quoted; only the authorization period is tested. Taxonomy gap: share of voice against competitors is "
               "available only as a provider Reputation Measure value; coverage of competitor brands is not recorded. Open SME "
               "question: 42 Q4 (are all fund releases reviewed by 08, or only those mentioning performance). Decisions: CD-271, "
               "CD-272, CD-296."
               "WP1 re-point (CW-160, CW-240): upstream DP-030 (retired; successors DP-506 and DP-507) dropped. DP-506 Competitive Pricing & Fee Benchmarks does not publish 11 Award, and DP-507 Own-Fund Peer Rankings & Ratings, which does, is in the backlog (merged into DP-506 if picked up); the 11 Award attributes are read directly, as the input already lists them. No measure lost; DP-506 is the upstream to add if it takes DP-507's Award scope."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-237": dict(
        definition=("Communications issues (CRIS-) by level and trigger (operational incident, IT incident, legal matter, health "
                    "and safety or physical security incident, external event) with the statements released to each audience, "
                    "the crisis communication plans and the business continuity plans they link to, and internal "
                    "communications with their audiences and aggregate engagement. It shows how quickly the firm spoke to each "
                    "stakeholder group in an issue, whether level 3 statements were approved, and whether crisis updates and "
                    "policy announcements reached the intended staff. Trigger records come from DP-215, DP-231 and DP-229, "
                    "continuity plans from DP-217 and certified headcount from DP-192; the product owns no certified metric "
                    "family."),
        business_questions=[
            "Which communications issues are open by level and trigger, and how long did it take to release the first statement after the issue opened and after the triggering incident was detected?",
            "For each level 2 and level 3 issue, which affected stakeholder groups have not yet received a statement?",
            "Were all level 3 statements approved before release, and was a crisis plan activated?",
            "Which crisis communication plans are not approved, are out of date or link to a business continuity plan that is not current?",
            "What share of the intended staff viewed each crisis update and policy launch notice, by channel?",
        ],
        grain=("Communications issue (CRIS-) x issue statement (statement type x audience x version), with crisis communication plan x "
               "version and internal communication x audience segment x channel x measurement date as companion facts"),
        dimensions=["Issue level, trigger type and status", "Affected stakeholder group and statement audience", "Statement type and delivery method",
                    "Crisis plan and linked business continuity plan (DP-217)", "Internal communication type and channel",
                    "Audience segment, org unit, office and legal entity (DP-013)", "Issue lead and approver (DP-192)",
                    "Calendar date (DP-013)"],
        measures=[
            ("Open Issues", "Count of Communications Issues with Issue Status open on the as-of date, by Issue Level and Issue Trigger Type.",
             [("42", "Communications Issue", "Communications Issue ID"), ("42", "Communications Issue", "Issue Status"),
              ("42", "Communications Issue", "Issue Level"), ("42", "Communications Issue", "Issue Trigger Type")]),
            ("Time to First Statement (hours)", "Earliest Statement Release Timestamp of the issue's Issue Statements - Issue Opened Timestamp, by Issue Level; issues with no released statement are shown as open with elapsed hours.",
             [("42", "Issue Statement", "Statement Issue"), ("42", "Issue Statement", "Statement Release Timestamp"),
              ("42", "Communications Issue", "Issue Opened Timestamp"), ("42", "Communications Issue", "Issue Level")]),
            ("Trigger-to-Statement Time (hours)", "Earliest Statement Release Timestamp - trigger detection time: Incident Detected Timestamp of the Trigger IT Incident (DP-231), Incident Discovery Date of the Trigger Operational Incident (DP-215) or Matter Opened Date of the Trigger Legal Matter (DP-229); external, health and safety and physical security triggers use Issue Opened Timestamp.",
             [("42", "Communications Issue", "Trigger IT Incident"), ("42", "Communications Issue", "Trigger Operational Incident"),
              ("42", "Communications Issue", "Trigger Legal Matter"), ("41", "IT Incident", "IT Incident ID"),
              ("41", "IT Incident", "Incident Detected Timestamp"), ("37", "Operational Incident", "Operational Incident ID"),
              ("37", "Operational Incident", "Incident Discovery Date"), ("39", "Legal Matter", "Legal Matter ID"),
              ("39", "Legal Matter", "Matter Opened Date"), "Time to First Statement (hours)"]),
            ("Stakeholder Groups Without Statement", "For open issues with Issue Level in (Level 2 - Significant Issue, Level 3 - Crisis): count of values in Affected Stakeholder Groups with no Issue Statement whose Statement Audience is that group and whose Statement Release Timestamp is populated.",
             [("42", "Communications Issue", "Affected Stakeholder Groups"), ("42", "Issue Statement", "Statement Issue"),
              ("42", "Issue Statement", "Statement Audience"),
              ("42", "Issue Statement", "Statement Release Timestamp"), "Open Issues"]),
            ("Unapproved Released Statements", "Issue Statements with Statement Release Timestamp populated and Statement Approved By blank; level 3 issues reported separately.",
             [("42", "Issue Statement", "Statement Approved By"), ("42", "Issue Statement", "Statement Release Timestamp"),
              ("42", "Issue Statement", "Statement Version"), ("42", "Communications Issue", "Issue Level")]),
            ("Crises Without Activated Plan", "Communications Issues with Issue Level = Level 3 - Crisis and Activated Crisis Plan blank, or whose activated plan's Crisis Scenario Types do not include the Issue Trigger Type.",
             [("42", "Communications Issue", "Activated Crisis Plan"), ("42", "Communications Issue", "Issue Level"),
              ("42", "Communications Issue", "Issue Trigger Type"), ("42", "Crisis Communication Plan", "Crisis Scenario Types")]),
            ("Crisis Plans Not Current", "Crisis Communication Plans with Crisis Plan Status active whose Crisis Plan Approval Date is more than 12 months before the as-of date, or whose Linked Business Continuity Plan has Plan Approval Status not approved or Plan Last Reviewed Date more than 12 months old (from DP-217).",
             [("42", "Crisis Communication Plan", "Crisis Plan Code"), ("42", "Crisis Communication Plan", "Crisis Plan Version"),
              ("42", "Crisis Communication Plan", "Crisis Plan Status"), ("42", "Crisis Communication Plan", "Crisis Plan Approval Date"),
              ("42", "Crisis Communication Plan", "Linked Business Continuity Plan"),
              ("37", "Business Continuity Plan", "Business Continuity Plan Code"), ("37", "Business Continuity Plan", "Plan Approval Status"),
              ("37", "Business Continuity Plan", "Plan Last Reviewed Date")]),
            ("Uncovered Crisis Scenarios", "Issue Trigger Type values not included in the Crisis Scenario Types of any active Crisis Communication Plan.",
             [("42", "Crisis Communication Plan", "Crisis Scenario Types"), ("42", "Crisis Communication Plan", "Crisis Plan Status")]),
            ("Internal Communications Sent", "Count of Internal Communications with Internal Publish Timestamp in the period, by Internal Communication Type and Internal Channels; those linked to an issue (Internal Communication Issue) shown separately.",
             [("42", "Internal Communication", "Internal Communication ID"), ("42", "Internal Communication", "Internal Publish Timestamp"),
              ("42", "Internal Communication", "Internal Communication Type"), ("42", "Internal Communication", "Internal Channels"),
              ("42", "Internal Communication", "Internal Communication Issue")]),
            ("Internal Reach %", "For each internal communication and channel, Unique Viewers Count at the latest Engagement Measurement Date / sum of Audience Recipient Count of the communication's audience segments; View Rate as reported is shown beside it.",
             [("42", "Internal Communication Engagement", "Engagement Communication"), ("42", "Internal Communication Engagement", "Engagement Channel"),
              ("42", "Internal Communication Engagement", "Engagement Measurement Date"), ("42", "Internal Communication Engagement", "Unique Viewers Count"),
              ("42", "Internal Communication Engagement", "View Rate"), ("42", "Internal Communication Audience", "Audience Communication"),
              ("42", "Internal Communication Audience", "Audience Recipient Count")]),
            ("Crisis Update Reach Within 24 Hours", "For Internal Communications of Internal Communication Type = Crisis Update: Internal Reach % at the first Engagement Measurement Date within 24 hours of Internal Publish Timestamp.",
             [("42", "Internal Communication", "Internal Communication Type"), ("42", "Internal Communication", "Internal Publish Timestamp"),
              ("42", "Internal Communication Engagement", "Engagement Measurement Date"), "Internal Reach %"]),
            ("Policy Notice Reach", "Internal Reach % of Internal Communications with Announced Policy populated, by Announced Policy.",
             [("42", "Internal Communication", "Announced Policy"), "Internal Reach %"]),
            ("All-Staff Audience Coverage %", "Audience Recipient Count of audience segments with Audience Segment Type = All Staff / Certified Headcount at the latest month-end from DP-192 (never recomputed here); values well below 100% flag a distribution list out of step with the workforce.",
             [("42", "Internal Communication Audience", "Audience Segment Type"), ("42", "Internal Communication Audience", "Audience Recipient Count"),
              ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status")]),
        ],
        inputs=[
            ("42", "Communications Issue", ["Communications Issue ID", "Issue Title", "Issue Level", "Issue Trigger Type",
                                            "Trigger Operational Incident", "Trigger IT Incident", "Trigger Legal Matter",
                                            "Trigger Health and Safety Incident", "Trigger Physical Security Incident",
                                            "Trigger External Event Description", "Issue Status", "Issue Lead",
                                            "Affected Stakeholder Groups", "Related Social Mentions", "Issue Opened Timestamp",
                                            "Activated Crisis Plan"]),
            ("42", "Issue Statement", ["Statement Issue", "Statement Version", "Statement Type", "Statement Audience",
                                       "Statement Approved By", "Statement Release Timestamp", "Statement Delivery Methods"]),
            ("42", "Crisis Communication Plan", ["Crisis Plan Code", "Crisis Plan Name", "Crisis Plan Version", "Crisis Scenario Types",
                                                 "Crisis Plan Owner", "Linked Business Continuity Plan", "Crisis Plan Approval Date",
                                                 "Crisis Plan Status"]),
            ("42", "Internal Communication", ["Internal Communication ID", "Internal Communication Type", "Internal Communication Title",
                                              "Internal Communication Sender", "Internal Channels", "Internal Publish Timestamp",
                                              "Internal Communication Issue", "Announced Policy"]),
            ("42", "Internal Communication Audience", ["Audience Communication", "Audience Segment Type", "Audience Org Unit",
                                                       "Audience Office", "Audience Legal Entity", "Audience Job Profile",
                                                       "Audience Recipient Count"]),
            ("42", "Internal Communication Engagement", ["Engagement Communication", "Engagement Channel", "Engagement Measurement Date",
                                                         "Unique Viewers Count", "View Rate"]),
            ("37", "Business Continuity Plan", ["Business Continuity Plan Code", "Business Continuity Plan Version", "Plan Approval Status",
                                                "Plan Last Reviewed Date"]),
            ("37", "Operational Incident", ["Operational Incident ID", "Incident Discovery Date", "Incident Severity", "Incident Status"]),
            ("41", "IT Incident", ["IT Incident ID", "Incident Class", "Incident Priority", "Incident Detected Timestamp"]),
            ("39", "Legal Matter", ["Legal Matter ID", "Legal Matter Type", "Matter Opened Date"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
        ],
        upstream=["DP-215", "DP-217", "DP-231", "DP-229", "DP-192", "DP-013"],
        refresh="Intraday",
        timeliness="Within 1 hour of an issue or statement update in the communications tool; internal engagement measures by 7am ET on T+1",
        history="Issues, statements and crisis plan versions kept for 10 years; internal communications and daily engagement measurements kept for 7 years",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Communications Issue has exactly the trigger reference that its Issue Trigger Type requires populated (for example Trigger IT Incident for IT Incident), and that reference resolves in its source product.",
            "Every Issue Statement resolves to a Communications Issue, and its Statement Release Timestamp is not earlier than the issue's Issue Opened Timestamp.",
            "Every Communications Issue with Issue Level = Level 3 - Crisis has an Issue Lead and at least one Issue Statement within 24 hours of Issue Opened Timestamp, or is flagged.",
            "Every Linked Business Continuity Plan resolves to a 37 Business Continuity Plan Code in DP-217.",
            "Unique Viewers Count is not greater than the communication's summed Audience Recipient Count, and View Rate is between 0 and 1.",
            "Internal Communication Engagement holds aggregate counts only; no row identifies an individual viewer.",
        ],
        notes=("Boundary (CD-272): the issue holds its trigger once; 37, 39, 41 and 44 hold no reference back. Operational "
               "incidents are DP-215's, IT incidents DP-231's, legal matters DP-229's (only the matter ID, type and opened date "
               "are read; privileged matter content is never read), continuity plans DP-217's, and health and safety and "
               "physical security incidents are counted by trigger type only (DP-208 holds them). Social mentions are 04 (DP-090) "
               "and referenced, not read. Media inquiries escalated to an issue are counted in DP-236. Certified headcount comes "
               "from DP-192 (CD-293, CD-341) and is never recomputed. Supporting functions: FN-42 incident and continuity "
               "communications; FN-51 cyber incident statements; FN-45 legal review of statements; FN-41 and FN-44 staff and "
               "policy announcements. PII = Y through employee keys (Issue Lead, Statement Approved By, Crisis Plan Owner, "
               "Internal Communication Sender); engagement is aggregate only (42 SME Q7). Classified Confidential; an issue "
               "about the listed parent before its statement is released may be inside information and is restricted to the "
               "crisis team until release. Operating model: in house; agencies do not change the grain. Taxonomy gap: Issue "
               "Statement has no target audience size, so reach of external statements is not measurable. Taxonomy gap: 37 "
               "Operational Incident has only a discovery date, not a timestamp, so trigger-to-statement time for operational "
               "incidents is accurate to the day. Taxonomy gap: Internal Communication Audience Recipient Count may double-count "
               "people in overlapping segments; reach uses the sum as reported. Open SME questions: 42 Q5 (crisis tool shared "
               "with 37 incident management), Q7 (aggregate engagement). Decisions: CD-266, CD-272, CD-293, CD-341."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-238": dict(
        definition=("Corporate publications (the broker-dealer statement of financial condition under SEC Rule 17a-5(c), the "
                    "corporate responsibility report and the annual review) against their deadlines with board approval and the source record of "
                    "every published figure, public policy positions and consultation responses, contacts with government "
                    "officials, trade association dues and their lobbying portion, and lobbying registrations, registered "
                    "lobbyists and LD-2, LD-203 and state lobbying reports. It shows which statutory disclosures and "
                    "lobbying reports are due or late, and that every published figure traces to its owning domain: "
                    "workforce figures from DP-201 and DP-192, capital figures from DP-205, board approvals from DP-230 and "
                    "political contributions from DP-225 (CD-272, CD-273). It recomputes no certified number."),
        business_questions=[
            "Which statutory publications are due in the next 90 days for each publishing entity, and which were published late?",
            "Was each published statement approved by the board before publication, and does every figure in it trace to a source record as of the right date?",
            "Which LD-2, LD-203 and state lobbying reports are due or late for each registration?",
            "Did any lobbying contact with officials take place without the attending employee being a registered lobbyist?",
            "Are all political contributions of registered lobbyists accounted for on their LD-203 reports?",
            "How much of our trade association dues is attributable to lobbying, and is it reported?",
        ],
        grain=("Corporate publication version (type x publishing entity x period end x version) and lobbying disclosure report (LOBR-: "
               "registration x filer x report type x period x amendment) as the two main facts, with publication source link, policy "
               "position, consultation response, official contact, trade association membership, registration and registered "
               "lobbyist as companion tables"),
        dimensions=["Publication type, publishing entity and period (DP-013)", "Publication status", "Lobbying regime, registration and registrant category",
                    "Registered lobbyist and firm attendee (DP-192)", "Report type and period", "General issue area",
                    "Policy topic and jurisdiction", "Government agency, trade association and consulting body (DP-240)",
                    "Member entity and responding entity (DP-013)"],
        measures=[
            ("Publications Due (90 Days)", "Corporate Publications (latest version per type, entity and period) with Publication Deadline Date within the next 90 days and Publication Status not Published, by Corporate Publication Type and Publishing Entity.",
             [("42", "Corporate Publication", "Corporate Publication ID"), ("42", "Corporate Publication", "Corporate Publication Type"),
              ("42", "Corporate Publication", "Publishing Entity"), ("42", "Corporate Publication", "Publication Period End"),
              ("42", "Corporate Publication", "Publication Deadline Date"), ("42", "Corporate Publication", "Publication Status")]),
            ("Late Publications", "Publications whose Publication Date is after Publication Deadline Date, or whose deadline has passed with Publication Status not Published, by Corporate Publication Type.",
             [("42", "Corporate Publication", "Publication Date"), ("42", "Corporate Publication", "Publication Deadline Date"),
              ("42", "Corporate Publication", "Publication Status"), ("42", "Corporate Publication", "Corporate Publication Type")]),
            ("Publications Without Board Approval", "Published Statements of Financial Condition and Corporate Responsibility Reports (types the client confirms need board approval) that are not the Subject Corporate Publication of a 39 Corporate Resolution Subject Link whose resolution has an approving Corporate Resolution Outcome and Corporate Resolution Effective Date on or before Publication Date (from DP-230); a Publication Board Approval Date that differs from that date is flagged.",
             [("42", "Corporate Publication", "Publication Board Approval Date"), ("42", "Corporate Publication", "Publication Date"),
              ("42", "Corporate Publication", "Corporate Publication Type"), ("42", "Corporate Publication", "Publication Status"),
              ("39", "Corporate Resolution Subject Link", "Linked Corporate Resolution"),
              ("39", "Corporate Resolution Subject Link", "Corporate Resolution Subject Type"),
              ("39", "Corporate Resolution Subject Link", "Subject Corporate Publication"), ("39", "Corporate Resolution", "Corporate Resolution ID"),
              ("39", "Corporate Resolution", "Corporate Resolution Outcome"), ("39", "Corporate Resolution", "Corporate Resolution Effective Date"),
              "Late Publications"]),
            ("Untraced Publication Figures", "Published Statements of Financial Condition and Corporate Responsibility Reports with no Publication Source Link, or with a source link whose Source As-Of Date differs from Publication Period End, or whose source is a 43 Capital Requirement Calculation with Calculation Approval Status not approved (from DP-205) or a 20 Human Capital Metric Value with Metric Period End Date different from Publication Period End (from DP-201).",
             [("42", "Publication Source Link", "Linked Publication"), ("42", "Publication Source Link", "Source Human Capital Metric Value"),
              ("42", "Publication Source Link", "Source Capital Requirement Calculation"),
              ("42", "Publication Source Link", "Source Operational Emission Record"), ("42", "Publication Source Link", "Other Source Record Key"),
              ("42", "Publication Source Link", "Source As-Of Date"), ("43", "Capital Requirement Calculation", "Capital Calculation ID"),
              ("43", "Capital Requirement Calculation", "Calculation Approval Status"), ("20", "Human Capital Metric Value", "Metric Definition"),
              ("20", "Human Capital Metric Value", "Metric Period End Date"), ("42", "Corporate Publication", "Publication Period End"),
              ("42", "Corporate Publication", "Corporate Publication Type"), ("42", "Corporate Publication", "Publication Status")]),
            ("Missing or Late Lobbying Reports", "For each Lobbying Registration effective in a report period: expected reports by regime (LD-2 Quarterly Activity Report due 20 days after quarter end; LD-203 Semiannual Contribution Report due 30 days after half-year end, for the registrant and each Registered Lobbyist effective in the half-year; US State Periodic Report on the state's schedule, a parameter) with no Lobbying Disclosure Report for that registration, filer, type and period, or with Report Filed Timestamp after the derived due date.",
             [("42", "Lobbying Registration", "Lobbying Registration ID"), ("42", "Lobbying Registration", "Lobbying Regime"),
              ("42", "Lobbying Registration", "Registration Effective Date"), ("42", "Lobbying Registration", "Registration Termination Date"),
              ("42", "Registered Lobbyist", "Lobbyist"), ("42", "Registered Lobbyist", "Lobbyist Registration"),
              ("42", "Registered Lobbyist", "Lobbyist Effective From"), ("42", "Registered Lobbyist", "Lobbyist Effective To"),
              ("42", "Lobbying Disclosure Report", "Report Registration"), ("42", "Lobbying Disclosure Report", "Filing Lobbyist"),
              ("42", "Lobbying Disclosure Report", "Lobbying Report Type"), ("42", "Lobbying Disclosure Report", "Report Period"),
              ("42", "Lobbying Disclosure Report", "Report Filed Timestamp")]),
            ("Reported Lobbying Expense", "Sum of Lobbying Expense Amount of the latest (non-amended) LD-2 report per registration and period, by Registrant Entity and Expense Reporting Method.",
             [("42", "Lobbying Disclosure Report", "Lobbying Expense Amount"), ("42", "Lobbying Disclosure Report", "Expense Reporting Method"),
              ("42", "Lobbying Disclosure Report", "Amended Report"),
              ("42", "Lobbying Registration", "Registrant Entity")]),
            ("Unregistered Lobbying Contacts", "Government Official Contacts with Lobbying Contact Indicator = Y in which a Firm Attendee was not a Registered Lobbyist on any registration effective on the Official Contact Date.",
             [("42", "Government Official Contact", "Official Contact ID"), ("42", "Government Official Contact", "Lobbying Contact Indicator"),
              ("42", "Government Official Contact", "Firm Attendees"), ("42", "Government Official Contact", "Official Contact Date"),
              ("42", "Registered Lobbyist", "Lobbyist"), ("42", "Registered Lobbyist", "Lobbyist Effective From"),
              ("42", "Registered Lobbyist", "Lobbyist Effective To")]),
            ("LD-203 Contribution Gaps", "38 Political Contributions whose Contributor Employee is a Registered Lobbyist effective on the Contribution Date and whose Political Recipient Type is a federal candidate, party or PAC, that are not in the Reported Political Contributions of that lobbyist's LD-203 report for the half-year (from DP-225; no amount is copied).",
             [("38", "Political Contribution", "Political Contribution ID"), ("38", "Political Contribution", "Contributor Employee"),
              ("38", "Political Contribution", "Contribution Date"), ("38", "Political Contribution", "Political Recipient Type"),
              ("42", "Lobbying Disclosure Report", "Reported Political Contributions"), ("42", "Lobbying Disclosure Report", "Filing Lobbyist"),
              ("42", "Lobbying Disclosure Report", "Lobbying Report Type"), ("42", "Lobbying Disclosure Report", "Report Period"),
              ("42", "Registered Lobbyist", "Lobbyist"), ("42", "Registered Lobbyist", "Lobbyist Effective From"),
              ("42", "Registered Lobbyist", "Lobbyist Effective To")]),
            ("Trade Association Lobbying Dues", "Sum of Annual Dues Amount x Dues Lobbying Portion Percentage for memberships effective in the year, by Member Entity and Trade Association; the part with Lobbying Portion Reported Indicator = N shown separately (the tax treatment is 19's).",
             [("42", "Trade Association Membership", "Trade Association"), ("42", "Trade Association Membership", "Member Entity"),
              ("42", "Trade Association Membership", "Annual Dues Amount"), ("42", "Trade Association Membership", "Dues Lobbying Portion Percentage"),
              ("42", "Trade Association Membership", "Lobbying Portion Reported Indicator"),
              ("42", "Trade Association Membership", "Membership Effective From"), ("42", "Trade Association Membership", "Membership Effective To")]),
            ("Consultation Responses Submitted", "Count of Consultation Responses with Response Submission Date in the period, by Consultation Body Type, Consulting Regulator and Responding Entity; joint responses through an association shown separately.",
             [("42", "Consultation Response", "Consultation Reference"), ("42", "Consultation Response", "Response Submission Date"),
              ("42", "Consultation Response", "Consultation Body Type"), ("42", "Consultation Response", "Consulting Regulator"),
              ("42", "Consultation Response", "Responding Entity"), ("42", "Consultation Response", "Joint Response Association")]),
            ("Active Policy Positions", "Count of Public Policy Positions (latest version) effective on the as-of date, by Policy Topic and Policy Position Jurisdictions, with the count of official contacts in the period that discussed each (Discussed Position).",
             [("42", "Public Policy Position", "Policy Position ID"), ("42", "Public Policy Position", "Policy Position Version"),
              ("42", "Public Policy Position", "Policy Topic"), ("42", "Public Policy Position", "Policy Position Jurisdictions"),
              ("42", "Public Policy Position", "Policy Position Effective From"), ("42", "Public Policy Position", "Policy Position Effective To"),
              ("42", "Government Official Contact", "Discussed Position")]),
            ("Departed Registered Lobbyists", "Registered Lobbyists with Lobbyist Effective To blank whose employee has Employment Status = Terminated in DP-192 (the registration needs a lobbyist termination on the next report).",
             [("42", "Registered Lobbyist", "Lobbyist"), ("42", "Registered Lobbyist", "Lobbyist Effective To"),
              ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Termination Date")]),
        ],
        inputs=[
            ("42", "Corporate Publication", ["Corporate Publication ID", "Corporate Publication Type", "Publishing Entity", "Publication Period End",
                                             "Publication Version", "Publication Signatory", "Publication Board Approval Date",
                                             "Publication Deadline Date", "Publication Date", "Publication Property",
                                             "Publication Status"]),
            ("42", "Publication Source Link", ["Linked Publication", "Source Human Capital Metric Value",
                                               "Source Capital Requirement Calculation", "Source Operational Emission Record",
                                               "Other Source Record Key", "Source As-Of Date"]),
            ("42", "Public Policy Position", ["Policy Position ID", "Policy Position Version", "Policy Position Title", "Policy Topic",
                                              "Policy Position Jurisdictions", "Policy Position Effective From", "Policy Position Effective To"]),
            ("42", "Consultation Response", ["Consultation Body Type", "Consulting Regulator", "Consulting Body", "Consultation Reference",
                                             "Responding Entity", "Response Submission Date", "Response Position", "Joint Response Association"]),
            ("42", "Government Official Contact", ["Official Contact ID", "Contacted Official", "Official Agency", "Firm Attendees",
                                                   "Official Contact Date", "Official Contact Topics", "Discussed Position",
                                                   "Lobbying Contact Indicator", "Related Hospitality Item"]),
            ("42", "Trade Association Membership", ["Trade Association", "Member Entity", "Membership Tier", "Annual Dues Amount",
                                                    "Dues Lobbying Portion Percentage", "Lobbying Portion Reported Indicator",
                                                    "Membership Effective From", "Membership Effective To"]),
            ("42", "Lobbying Registration", ["Lobbying Registration ID", "Lobbying Regime", "Registrant Category", "Registrant Entity",
                                             "Outside Lobbying Firm", "Registration Jurisdiction", "Registration Effective Date",
                                             "Registration Termination Date"]),
            ("42", "Registered Lobbyist", ["Lobbyist", "Lobbyist Registration", "Covered Official Position Held", "Lobbyist Effective From",
                                           "Lobbyist Effective To"]),
            ("42", "Lobbying Disclosure Report", ["Lobbying Report ID", "Report Registration", "Filing Lobbyist", "Lobbying Report Type",
                                                  "Report Period", "Report Filed Timestamp", "Report Filing ID", "Lobbying Expense Amount",
                                                  "Below LD-2 Reporting Floor Indicator", "Expense Reporting Method",
                                                  "Amended Report", "Reported Political Contributions", "Gift Rule Certification Indicator"]),
            ("42", "Lobbying Report Issue Line", ["Issue Line Report", "General Issue Area Code", "Specific Lobbying Issues",
                                                  "Entities Contacted", "Issue Line Lobbyists"]),
            ("38", "Political Contribution", ["Political Contribution ID", "Contributor Employee", "Political Recipient Type",
                                              "Contribution Date"]),
            ("39", "Corporate Resolution Subject Link", ["Linked Corporate Resolution", "Corporate Resolution Subject Type",
                                                         "Subject Corporate Publication"]),
            ("39", "Corporate Resolution", ["Corporate Resolution ID", "Corporate Resolution Outcome", "Corporate Resolution Effective Date"]),
            ("20", "Human Capital Metric Value", ["Metric Definition", "Metric Legal Entity", "Metric Breakdown", "Metric Period End Date",
                                                  "Metric Value", "Disclosure Classification"]),
            ("43", "Capital Requirement Calculation", ["Capital Calculation ID", "Calculation Entity", "Calculation Capital Regime",
                                                       "Calculation As-Of Date", "Calculation Approval Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Termination Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Jurisdiction of Formation"]),
        ],
        upstream=["DP-230", "DP-225", "DP-201", "DP-205", "DP-240", "DP-192", "DP-013"],
        refresh="Weekly",
        timeliness="By 7am ET each Monday; in the 30 days before an LD-2, LD-203, state lobbying report or publication deadline the due and late lists are also refreshed on demand",
        history="Every publication version, source link, registration, report and amendment kept indefinitely (public filings and their evidence); official contacts and memberships kept for 7 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Corporate Publication with Publication Status = Published has a Publication Date and, for Statement of Financial Condition and Corporate Responsibility Report, at least one Publication Source Link.",
            "Every Publication Source Link has exactly one source populated (a typed source reference or Other Source Record Key), and every typed source resolves in its owning product (DP-201, DP-205).",
            "Every Lobbying Disclosure Report's Report Registration resolves to a Lobbying Registration ID, and an LD-203 report's Filing Lobbyist is a Registered Lobbyist of that registration or blank for the registrant row.",
            "An Amended Report resolves to an earlier report with the same registration, filer, report type and period.",
            "Every Reported Political Contributions value resolves to a 38 Political Contribution ID whose Contribution Date falls in the report's half-year.",
            "Dues Lobbying Portion Percentage is between 0 and 100 for every Trade Association Membership.",
        ],
        notes=("W1b: Corporate Publication.Government Portal Submission Date, Publication Source Link.Source PAI Calculation and Lobbying Disclosure Report.EU TR Cost Band dropped, no successor (CW-942, CW-934); Late Publications no longer tests portal submission, Untraced Publication Figures no longer reads the PAI source and Reported Lobbying Expense no longer shows the EU TR band. W1b re-point (CW-942): the publication-type filters read the US Publication Type values (Statement of Financial Condition, Corporate Responsibility Report) in place of the removed Modern Slavery Statement, Gender Pay Gap Report, MIFIDPRU 8 Disclosure and Tax Strategy values, and the EU TR Annual Update expectation becomes the US State Periodic Report. "
               "Boundary (CD-272, CD-273): 42 publishes; 20, 34, 43 and 44 produce the figures and 39 holds board approvals. "
               "Published figures are read as certified from their owners and never recomputed (CD-293): human "
               "capital metric values from DP-201, headcount from DP-192, regulatory capital from DP-205; emissions "
               "sources (44) are traced only by the link and checked by their own products. Board approval is held only on "
               "39 Corporate Resolution Subject Link (DP-230); 42 holds a derived Publication Board Approval Date that is "
               "compared, not trusted. Political contributions and pay-to-play are 38's (DP-225); LD-203 rows reference them and "
               "copy no amount, so Contribution Amount is not read. The tax treatment of the dues lobbying portion (IRC 162(e)) "
               "is 19's (FN-39). Officials, agencies, associations and outside lobbying firms are 02 parties (DP-240). "
               "Supporting functions: FN-44 lobbying and pay-to-play compliance; FN-41 workforce figures; FN-40 net capital in the "
               "statement of financial condition; FN-39 tax treatment of dues; FN-45 board approvals. PII = Y: contacted officials, firm attendees, lobbyists, covered "
               "positions held and political contributions are personal data; lobbying reports become public once filed, the "
               "underlying contacts and contributions do not. Operating model: in house; an outside lobbying firm reporting the "
               "firm as a client is recorded as Outside Lobbying Firm and does not change the grain. Thresholds and due-date "
               "rules (LD-2 20 days after quarter end, LD-203 30 days after half-year end, LD-2 expense floor) follow the LDA "
               "Guidance as summarized in the 42 source notes and are to be confirmed against the current guidance. Taxonomy "
               "gap: Lobbying Disclosure Report has no due date (dropped as derivable), so due dates are derived from report "
               "type and period. Taxonomy gap: 38 Political Contribution scope is Rule 206(4)-5 pay-to-play and may not hold "
               "every LD-203 item (FECA contributions of USD 200 or more, honorary expenses), so LD-203 Contribution Gaps can "
               "under-report (42 source notes §3). Taxonomy gap: Corporate Publication has no attribute saying whether the type "
               "requires board approval; the rule is a product parameter. Open SME questions: 42 Q2 and Q3 (LDA and state "
               "registrations), Q6 (which publications the board approves), Q10 (source of association lobbying portions). "
               "Decisions: CD-272, CD-273, CD-293, CD-341."),
    ),
}
