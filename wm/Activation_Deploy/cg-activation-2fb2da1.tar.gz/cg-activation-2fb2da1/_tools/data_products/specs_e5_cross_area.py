"""Data product specifications, Wave E5: cross-area enterprise products (DP-241 to DP-248; DP-241 is re-specified at
WP1 in specs_w1f_certified.py).

The program lead's cross-area group (CD-362): products that read the foundational and area products of Waves E1 to
E4 and recombine their published numbers for one cross-area decision. No candidate entries exist; the brief is the
register row (framework.WAVE_E5), Data_Products_Expansion_Plan.md §7 (E5) and the decisions each product names.
See CONTRACT.md.

Rule for every product here: a certified number is read from its owning product and the formula says "from DP-nnn";
nothing is recalculated (CD-293, CD-320, CD-330, CD-340, CD-341). Inputs list only the attributes the measures read,
traced through the owning product.

Upstream graph inside this group (no cycles): DP-245 <- DP-247; DP-248 <- DP-247. Every other upstream is an E1 to E4
or distribution product, and none of them lists a Wave E5 product.

WP1 lineage pass: the specs of the retired DP-244 are deleted (framework.RETIRED_PRODUCTS; register rows kept).
"""


def _u(nn, obj, *attrs):
    """(NN, object, attribute) use tuples for one object."""
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ==================================================================================================================
    # DP-241 re-specified at WP1 in specs_w1f_certified.py
    # ==================================================================================================================
    "DP-242": dict(
        definition=("One view per fund and share class across its lifecycle, from the proposal that created it to liquidation: "
                    "reference and status (DP-004), launch and change events (DP-105 to DP-109), net assets, NAV and expense "
                    "ratios (DP-165), flows and client assets (DP-008), official returns (DP-145), "
                    "fee revenue (DP-012), product P&L (DP-499), the tie of fee revenue to certified revenue (DP-191) and board "
                    "approvals (DP-182). It exists so product management decides on launches, repricing, mergers and closures "
                    "from one set of numbers. Every certified number is read from its owner and named; nothing is "
                    "recalculated. It owns no certified number."),
        business_questions=[
            "For each fund and share class, what are net assets, flows, returns against benchmark, expense ratios and P&L this month and over 12 months?",
            "Which funds lose money after distribution and allocated cost, and which were rated below expectations in their latest product review?",
            "Which funds are on the watch list, and what changes (fee changes, mergers, liquidations) are already in flight for them?",
            "Did launched funds reach the AUM and revenue their business case projected for year 3?",
            "Does fee revenue by fund tie to certified revenue in the ledger, and when do the fund's board approvals expire?",
        ],
        grain=("Share class x month-end (with fund-level rows rolling up the classes), across the lifecycle from proposal to "
               "liquidation; change initiatives, board resolutions and product reviews as dated child rows"),
        dimensions=["Fund (investment product) and share class (DP-004)", "Vehicle type, legal form and domicile (DP-004)",
                    "Business line and asset class (DP-004)", "Share class status and lifecycle stage", "Month-end and fiscal period (DP-013)",
                    "Distribution channel (DP-008)", "Benchmark (DP-145)", "Product change type and status (DP-106)",
                    "Review type and outcome (DP-109)", "Board resolution type (DP-182)", "Watch list flag"],
        measures=[
            ("Lifecycle Status",
             "Share Class Status, Share Class Launch Date and months since launch, with the latest Lifecycle Event (Lifecycle Event Type, Event Effective Date, Lifecycle Status) per share class (from DP-004).",
             _u("01", "Share Class", "Share Class ID", "Parent Product", "Share Class Status", "Share Class Launch Date")
             + _u("01", "Lifecycle Event", "Lifecycle Status", "Lifecycle Event Type", "Event Effective Date")),
            ("Projected vs Realized at Year 3 (from DP-105)",
             "Realized vs Projected AUM % and Realized vs Projected Net Revenue % published by DP-105 for the proposal whose launch Product Change Initiative (Originating Proposal) created the share class (Changed Product Scope), against Projected AUM Year 3 and Projected Net Revenue Year 3 of the highest Business Case Version.",
             _u("36", "Product Change Initiative", "Originating Proposal", "Actual Effective Date")
             + _u("36", "Changed Product Scope", "Scope Change Initiative", "Scope Share Class")
             + _u("36", "Product Business Case", "Business Case Version", "Projected AUM Year 3", "Projected Net Revenue Year 3")),
            ("Open Product Changes (from DP-106, DP-108)",
             "Count of Product Change Initiatives whose Changed Product Scope names the fund or share class and whose Change Status is not complete or withdrawn, by Product Change Type (fee or term change, merger, conversion, liquidation), with Planned Effective Date and DP-106's Effective Date at Risk flag; mergers and liquidations as DP-108 publishes them.",
             _u("36", "Product Change Initiative", "Product Change Initiative ID", "Product Change Type", "Change Status", "Planned Effective Date")
             + _u("36", "Changed Product Scope", "Scope Product", "Scope Share Class")),
            ("Launch Readiness (from DP-107)",
             "For share classes in launch: Readiness Complete % of the latest Readiness Plan Version and days from the as-of date to Planned First NAV Date, as DP-107 publishes them.",
             _u("36", "Product Readiness Plan", "Readiness Change Initiative", "Readiness Plan Version", "Planned First NAV Date")
             + _u("36", "Readiness Check", "Check Readiness Plan", "Readiness Check Status")),
            ("Latest Review Outcome (from DP-109)",
             "Review Outcome of the latest Product Review per share class and Product Review Type, with the count of Product Review Criterion Results by Criterion Rating.",
             _u("36", "Product Review", "Product Review ID", "Review Share Class", "Product Review Type", "Review Period End", "Review Outcome")
             + _u("36", "Product Review Criterion Result", "Criterion Share Class", "Product Review Criterion", "Criterion Rating")),
            ("Net Assets and NAV (from DP-165)",
             "Class Net Assets, NAV per Share and Shares Outstanding of the share class at the NAV of record of the month-end valuation date, and Fund Total Net Assets on the fund row; certified in DP-165 (CD-330), shown here.",
             _u("27", "Share Class NAV", "NAV Share Class", "Parent NAV Calculation", "NAV per Share", "Class Net Assets Amount", "Shares Outstanding")
             + _u("27", "Fund NAV Calculation", "NAV Book", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount")),
            ("Expense Ratios (from DP-165)",
             "Net and Gross Expense Ratio (Trailing) and the Audited Gross and Net Expense Ratio (Highlights Gross Expense Ratio, Highlights Net Expense Ratio) published by DP-165 (CD-330), with the prospectus Net Expense Ratio of the 01 Cost Disclosure (DP-004) beside it and the difference in basis points; the prospectus ratio is a disclosure, not a certified actual.",
             _u("27", "Fund Expense Accrual", "Accrual Share Class", "Accrued Expense Amount")
             + _u("27", "Expense Cap & Waiver Accrual", "Waiver Share Class", "Waived Fee Amount", "Reimbursed Expense Amount")
             + _u("27", "Financial Highlights", "Highlights Share Class", "Highlights Gross Expense Ratio", "Highlights Net Expense Ratio")
             + _u("01", "Cost Disclosure", "Gross Expense Ratio", "Net Expense Ratio")),
            ("Flows and Client Assets (from DP-008)",
             "Gross Sales, Redemptions, Net Flows (Net Sales), Ending Client Assets, Average Client Assets and Client Organic Growth Rate (CW-011) of the share class for the month and trailing 12 months from the locked DP-008 snapshots, by Distribution Channel.",
             _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot")
             + _u("06", "Flow Measures", "Gross Sales", "Redemptions", "Net Flows (Net Sales)")
             + _u("06", "Client Asset Measures", "Ending Client Assets", "Average Client Assets", "Client Organic Growth Rate")
             + _u("06", "Market & Client Dimensions", "Distribution Channel")),
            ("Official Returns (from DP-145)",
             "Official Return (net of fees) for 1, 3, 5 years and since inception at the month-end, Benchmark Return of the primary Product Benchmark Assignment and Excess Return, as DP-145 certifies them (Return Status Final or Restated, highest version, CD-320).",
             _u("32", "Performance Return", "Performance Return ID", "Return Share Class", "Return Period Start Date", "Return Period End Date",
                "Return Fee Basis", "Return Value", "Return Version", "Return Status")
             + _u("32", "Benchmark Return", "Return Benchmark", "Benchmark Period End Date", "Benchmark Return Value", "Benchmark Return Status")
             + _u("01", "Product Benchmark Assignment", "Assigned Product / Share Class", "Assigned Benchmark", "Benchmark Role")),
            ("Fee Revenue (from DP-012)",
             "Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate of the share class for the accounting period (Revenue Data Basis final where available), and Waiver Cost (Waived Fee Amount + Reimbursed Expense Amount), as DP-012 certifies them.",
             _u("10", "Fee Revenue Record", "Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period",
                "Gross Fee Revenue", "Net Fee Revenue", "Effective Net Fee Rate", "Revenue Data Basis")
             + _u("10", "Waiver Record", "Supported Share Class", "Waived Fee Amount", "Reimbursed Expense Amount")),
            ("Product P&L (from DP-499)",
             "Gross Revenue, Distribution Payments, Contribution Margin, Allocated Indirect Cost, Operating Profit, Operating Margin and Net Revenue Yield of the Profitability Record at Product / Share Class grain (actual Data Version) for the period, as DP-499 publishes them; fund rows sum the classes.",
             _u("10", "Profitability Record", "Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain", "Product / Share Class")
             + _u("10", "Profitability Measure", "Gross Revenue", "Distribution Payments", "Contribution Margin", "Allocated Indirect Cost",
                  "Operating Profit", "Operating Margin", "Net Revenue Yield")),
            ("Certified Revenue Tie-Out (from DP-191)",
             "Per fund and fiscal period: sum of Net Fee Revenue of the fund's share classes (from DP-012) - Certified Revenue from DP-191 on Actual balances of Revenue GL accounts whose product segment value represents the fund (Chart Segment Value Represented Product, DP-190); a difference is a reconciling item, never a second revenue (CD-340).",
             _u("19", "GL Account Balance", "Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period", "Balance Type",
                "Opening Balance", "Closing Balance")
             + _u("19", "GL Account", "GL Account ID", "GL Account Type")
             + _u("19", "Chart Segment Value", "Chart Segment", "Segment Value Code", "Represented Product")
             + ["Fee Revenue (from DP-012)"]),
            ("Board Approval Status (from DP-182)",
             "For the fund's board-approved subjects (advisory agreement, share class, product change): Board Approval Status as DP-182 publishes it, and approvals expiring in 90 days (Resolution Expiry Date) with no superseding resolution.",
             _u("35", "Resolution Subject Link", "Linked Resolution", "Resolution Subject Type", "Subject Product", "Subject Share Class")
             + _u("35", "Board Resolution", "Board Resolution ID", "Resolution Type", "Resolution Outcome", "Resolution Effective Date", "Resolution Expiry Date")),
            ("Watch List Flag",
             "Y for an active share class when any of: 3-year Excess Return below zero; trailing 12-month Operating Profit below zero; trailing 12-month Net Flows below zero with Ending Client Assets below the firm's minimum viable size (a Product parameter); or an advisory agreement approval expiring in 90 days. A rule, not a model score.",
             ["Official Returns (from DP-145)", "Product P&L (from DP-499)", "Flows and Client Assets (from DP-008)",
              "Board Approval Status (from DP-182)"]),
        ],
        inputs=[
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type", "Product Inception Date"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status", "Share Class Launch Date"]),
            ("01", "Lifecycle Event", ["Lifecycle Status", "Lifecycle Event Type", "Event Effective Date"]),
            ("01", "Cost Disclosure", ["Gross Expense Ratio", "Net Expense Ratio"]),
            ("01", "Product Benchmark Assignment", ["Assigned Product / Share Class", "Assigned Benchmark", "Benchmark Role"]),
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Product Change Type", "Change Status",
                                                 "Originating Proposal", "Planned Effective Date", "Actual Effective Date"]),
            ("36", "Changed Product Scope", ["Scope Change Initiative", "Scope Product", "Scope Share Class"]),
            ("36", "Product Business Case", ["Business Case Proposal", "Business Case Version", "Projected AUM Year 3",
                                             "Projected Net Revenue Year 3"]),
            ("36", "Product Readiness Plan", ["Readiness Change Initiative", "Readiness Plan Version", "Planned First NAV Date"]),
            ("36", "Readiness Check", ["Check Readiness Plan", "Readiness Check Status"]),
            ("36", "Product Review", ["Product Review ID", "Review Share Class", "Product Review Type", "Review Period End", "Review Outcome"]),
            ("36", "Product Review Criterion Result", ["Criterion Share Class", "Product Review Criterion", "Criterion Rating"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                                       "Class Net Assets Amount", "Shares Outstanding"]),
            ("27", "Fund Expense Accrual", ["Accrual Share Class", "Accrued Expense Amount"]),
            ("27", "Expense Cap & Waiver Accrual", ["Waiver Share Class", "Waived Fee Amount", "Reimbursed Expense Amount"]),
            ("27", "Financial Highlights", ["Highlights Share Class", "Highlights Gross Expense Ratio", "Highlights Net Expense Ratio"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Flow Measures", ["Gross Sales", "Redemptions", "Net Flows (Net Sales)"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Average Client Assets", "Client Organic Growth Rate"]),
            ("06", "Market & Client Dimensions", ["Distribution Channel"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Share Class", "Return Period Start Date", "Return Period End Date",
                                          "Return Fee Basis", "Return Value", "Return Version", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period End Date", "Benchmark Return Value", "Benchmark Return Status"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period",
                                          "Gross Fee Revenue", "Net Fee Revenue", "Effective Net Fee Rate", "Revenue Data Basis"]),
            ("10", "Waiver Record", ["Supported Share Class", "Waived Fee Amount", "Reimbursed Expense Amount"]),
            ("10", "Profitability Record", ["Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain",
                                            "Product / Share Class"]),
            ("10", "Profitability Measure", ["Gross Revenue", "Distribution Payments", "Contribution Margin", "Allocated Indirect Cost",
                                             "Operating Profit", "Operating Margin", "Net Revenue Yield"]),
            ("19", "GL Account Balance", ["Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period", "Balance Type",
                                          "Opening Balance", "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type"]),
            ("19", "Chart Segment Value", ["Chart Segment", "Segment Value Code", "Represented Product"]),
            ("35", "Resolution Subject Link", ["Linked Resolution", "Resolution Subject Type", "Subject Product", "Subject Share Class"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Resolution Type", "Resolution Outcome", "Resolution Effective Date",
                                        "Resolution Expiry Date"]),
        ],
        upstream=["DP-004", "DP-105", "DP-106", "DP-107", "DP-108", "DP-109", "DP-165", "DP-008", "DP-145", "DP-012",
                  "DP-499", "DP-191", "DP-190", "DP-182", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, after DP-008 locks (business day 8), DP-145 closes (business day 7) and DP-499 publishes the month",
        history="Month-end snapshots since each share class's launch (or the product go-live), kept for the life of the fund plus 10 years; change initiatives, reviews and resolutions with their dates",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every active share class in DP-004 has one row per month-end, and every fund row equals the sum of its classes for additive measures.",
            "Class Net Assets, Net Flows, Official Return, Net Fee Revenue and Operating Profit equal the owning product's published value for the same key and period; none is recomputed.",
            "Official Returns are shown only for Return Status Final or Restated; a Preliminary return shows as missing.",
            "Certified Revenue Tie-Out is computed for every fund with a product segment value in DP-190; a fund without one is listed as unmapped.",
            "A share class with Share Class Status liquidated or merged keeps its history and has no rows after its last Event Effective Date.",
        ],
        notes=("W1b: 31 Product Risk Indicator Calculation dropped, no successor (CW-931; PRIIPs SRI and UCITS SRRI have no US fund), with the measure Risk Indicator (from DP-156) and DP-156 upstream; US fund risk disclosure is the prospectus narrative, not a computed indicator. "
               "Certified numbers: none owned; reads net assets, NAV and expense ratios from DP-165 (CD-330), flows and client "
               "assets from DP-008, official returns from DP-145 (CD-320), fee revenue from DP-012, revenue from DP-191 (CD-340). "
               "Product P&L is DP-499's management profitability (an allocated view), not certified operating income; the "
               "tie to DP-191 is a reconciling item. Watch List Flag is a published rule, not a model (no DP-212 entry needed; "
               "CD-294 applies if a score is added). Boundary: DP-040, DP-058 and DP-059 keep their distribution views of "
               "product health, launch and pricing; this product is the cross-area view and adds no measure they own. "
               "Drafting assumptions: the minimum viable fund size is a Product parameter; the 90-day approval expiry window. "
               "Taxonomy gap: no attribute holds a fund's minimum viable size or watch list status. Taxonomy gap: 19 Chart "
               "Segment Value Represented Product is the only fund-to-ledger link; funds without a product segment value cannot "
               "be tied to certified revenue. Fund-level P&L for mandates is out of scope (DP-243 and DP-067 hold mandate "
               "revenue). PII = N: 32 Return Value is flagged personal because account-level returns exist; this product reads share class returns only (Return Share Class), so the validator's PII warning is accepted. Decisions: CD-217, CD-292, CD-293, CD-302, CD-303, CD-320, CD-330, CD-340. "
               "W4 re-point (CW-161, CW-936; proposals_w4_36.py READERS): 36 Value Assessment Criterion Result is replaced by "
               "Product Review Criterion Result (Value Assessment Criterion read as Product Review Criterion; Criterion Rating "
               "now the local Meets Expectations / Monitor / Below Expectations / Not Assessed list); the Not Providing Value "
               "flag is dropped (no UK assessment of value), and with it its clause of the Watch List Flag. 06 Measure Value "
               "Share Class is read as Dimension Type and Dimension Key (06 review). DP-109 is re-scoped at WP0 to Product "
               "Reviews & Criterion Results."
               "WP1 re-point (CW-159, CW-240, CW-203): upstream DP-035 (retired) replaced by its successor DP-499 Client, Offering & Advisor Profitability (10 Profitability Record and Measure); measure 'Product P&L (from DP-035)' renamed 'Product P&L (from DP-499)'. DP-008 no longer publishes the wholesale Ending AUM, Average AUM and Organic Growth Rate; the share class view reads the certified Ending Client Assets, Average Client Assets and Client Organic Growth Rate (06 Client Asset Measures, CW-011) at Dimension Type share class, so 'Flows and Attributed AUM (from DP-008)' is renamed 'Flows and Client Assets (from DP-008)' and its 06 Asset Measures input is replaced. SM-06, which still named the old measure names, was retired at WP2 (CW-209)."),
    ),
    # ==================================================================================================================
    # DP-243 re-specified at WP1 in specs_w1c_dis.py
    # ==================================================================================================================
    # DP-244 retired into DP-498 (CW-206); spec deleted by the WP1 lineage pass (dp_model skips RETIRED_PRODUCTS)
    # ==================================================================================================================
    "DP-245": dict(
        definition=("The published form of the firm's certified metrics (CD-293): for every Metric Definition with Metric "
                    "Certification Status = certified in DP-101 (CD-163), its current value and history read from the one "
                    "product that owns it, with that product named on every row: flows and client assets from DP-008, fee "
                    "revenue from DP-012, Firm AUM, NAV, net assets and expense ratios from DP-165, returns and private fund IRR "
                    "from DP-145, VaR and tracking error from DP-146, liquidity classification from DP-155, revenue, operating "
                    "expense and operating income from DP-191, headcount and FTE from DP-192 and compensation paid from DP-198. "
                    "It holds no definition of its own (DP-101 holds them) and computes no value (the owner does). It is the "
                    "one place reports, packs and KRIs take certified numbers from."),
        business_questions=[
            "What is the current certified value of each enterprise KPI, which product owns it, and what was it last period and a year ago?",
            "Which certified metrics have no value yet for the latest closed period, and which owners are late?",
            "Is any certified metric sourced from a product other than its owner under CD-293, or bound to no semantic model?",
            "Which certified values were restated after first publication, by how much and why?",
        ],
        grain=("Certified metric (21 Metric Definition, Metric ID) x period end x dimension combination of the metric's grain x "
               "value version (the owning product's snapshot or version), with the definition and its certification status as "
               "the parent row"),
        dimensions=["Certified metric and metric family", "Owning product and owning semantic model", "Metric owning Data Domain",
                    "Period end and period type (DP-013)", "Metric dimensions (as each metric's grain defines)", "Value version and data basis",
                    "Certification status", "Unit of measure and currency basis"],
        measures=[
            ("Certified Metrics Published",
             "Count of Metric Definitions with Metric Certification Status = certified, by Metric Owning Data Domain and Owning Semantic Model (DP-101's Certified Metric Count).",
             _u("21", "Metric Definition", "Metric ID", "Metric Owning Data Domain", "Owning Semantic Model", "Metric Certification Status")),
            ("Owner Conformance",
             "Y per certified metric when Metric Source Data Product is the owner of its family: DP-008 (flows, client assets and NNA), DP-012 (fee revenue), DP-241 (Firm AUM and its slices), DP-165 (NAV, net assets, expense ratios), DP-145 (returns), DP-146 (VaR, tracking error), DP-155 (liquidity classification), DP-191 (revenue, operating expense, operating income), DP-192 (headcount, FTE), DP-198 (compensation paid) (CD-293, CD-320, CD-330, CD-340, CD-341, CD-347). A metric with N is not published.",
             _u("21", "Metric Definition", "Metric ID", "Metric Name", "Metric Source Data Product", "Metric Certification Status")),
            ("Flow & Attributed AUM Values (from DP-008)",
             "Measure Amount of the locked DP-008 snapshot (Snapshot Type locked) for Gross Sales, Redemptions, Net Flows (Net Sales), Ending Client Assets, Average Client Assets and Client Organic Growth Rate at the metric's Dimension Type and period; the row names DP-008.",
             _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot")
             + _u("06", "Flow Measures", "Gross Sales", "Redemptions", "Net Flows (Net Sales)")
             + _u("06", "Client Asset Measures", "Ending Client Assets", "Average Client Assets", "Client Organic Growth Rate")
             + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Fee Revenue Values (from DP-012)",
             "Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate by Revenue Accounting Period and Revenue Data Basis, as DP-012 certifies them.",
             _u("10", "Fee Revenue Record", "Revenue Share Class / Mandate", "Revenue Accounting Period", "Gross Fee Revenue", "Net Fee Revenue",
                "Effective Net Fee Rate", "Revenue Data Basis")),
            ("Fund Metric Values (from DP-165)",
             "Fund Total Net Assets, Class Net Assets, NAV per Share, Shares Outstanding, Net and Gross Expense Ratio (Trailing) and the audited ratios, as DP-165 certifies them at the NAV of record (CD-292, CD-330).",
             _u("27", "Fund NAV Calculation", "NAV Book", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount")
             + _u("27", "Share Class NAV", "NAV Share Class", "NAV per Share", "Class Net Assets Amount", "Shares Outstanding")
             + _u("27", "Financial Highlights", "Highlights Share Class", "Highlights Gross Expense Ratio", "Highlights Net Expense Ratio")),
            ("Return Values (from DP-145)",
             "Official Return and Benchmark Return (Final or Restated, highest version), as DP-145 certifies them (CD-320).",
             _u("32", "Performance Return", "Return Period End Date", "Return Value", "Return Version", "Return Status")
             + _u("32", "Benchmark Return", "Benchmark Period End Date", "Benchmark Return Value", "Benchmark Return Status")),
            ("Risk Values (from DP-146, DP-155)",
             "Ex-Ante VaR and Ex-Ante Tracking Error (Risk Measure Value) from approved runs (DP-146) and the liquidity category percentages of the Fund Liquidity Profile (DP-155), as certified there (CD-320).",
             _u("31", "Portfolio Risk Measure", "Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Measure Value")
             + _u("31", "Risk Calculation Run", "Run As-Of Date", "Run Approval Status")
             + _u("31", "Fund Liquidity Profile", "Profile Fund", "Profile Measurement Date", "Highly Liquid Percent", "Illiquid Percent")),
            ("Corporate Finance Values (from DP-191)",
             "Certified Revenue, Certified Operating Expense and Certified Operating Income by legal entity and fiscal period, as DP-191 certifies them (CD-340).",
             _u("19", "GL Account Balance", "Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance")
             + _u("19", "GL Account", "GL Account Type", "Financial Statement Class")
             + _u("19", "Accounting Period Status", "Period Close Status")),
            ("People Values (from DP-192, DP-198)",
             "Certified Headcount and Certified FTE at the period end (DP-192, CD-341) and Gross Pay Paid in the period (DP-198, compensation paid, CD-347), at firm, legal entity and org unit grain.",
             _u("20", "Employee", "Employee ID", "Employment Status")
             + _u("20", "Employee Job Assignment", "Assignment Type", "Assignment FTE")
             + _u("20", "Payroll Run", "Pay Date", "Payroll Run Status") + _u("20", "Payroll Result", "Payroll Run", "Gross Pay Amount")),
            ("Value Coverage %",
             "Certified metrics with Owner Conformance = Y that have a value for the latest closed period of their period type / certified metrics with Owner Conformance = Y, by owning product.",
             _u("21", "Metric Definition", "Metric Grain") + ["Owner Conformance", "Flow & Attributed AUM Values (from DP-008)"]),
            ("Late Values",
             "Certified metrics whose owning product has not published the period's value by its stated Data Product Timeliness (DP-101 Data Product, Data Product Status published), by owning product and days late.",
             _u("21", "Data Product", "Data Product ID", "Data Product Timeliness", "Data Product Status") + ["Value Coverage %"]),
            ("Restated Values",
             "Count and amount of certified values changed after first publication in this registry: DP-008 Restatements (Net Impact Amount, Affected Periods), DP-145 Performance Restatements (Material Error Indicator), new DP-165 NAV versions and DP-191 balances of reopened periods; each restated row keeps the prior value.",
             _u("06", "Restatement", "Restatement ID", "Affected Periods", "Net Impact Amount")
             + _u("32", "Performance Restatement", "Restated Return", "Restatement Date", "Material Error Indicator")),
            ("Uncertified Copies Detected",
             "DP-101's Certification Copy Mismatches (06 Measure Definitions whose Certified Indicator differs from the certification status of the Metric Definition that registers them) plus certified metrics whose Metric ID is in no Semantic Model Binding's Bound Certified Metrics (Unbound Certified Metrics).",
             _u("06", "Measure Definition", "Measure ID", "Certified Indicator") + _u("21", "Metric Definition", "Registered Measure Definition")
             + _u("21", "Semantic Model Binding", "Semantic Model", "Bound Certified Metrics")),
            ("Change vs Prior Period and Prior Year",
             "Per metric and dimension combination: value - value of the prior period, and value - value of the same period a year earlier, with % change where the metric's Metric Aggregation Rule allows; display only.",
             _u("21", "Metric Definition", "Metric Aggregation Rule", "Metric Direction") + ["Flow & Attributed AUM Values (from DP-008)"]),
        ],
        inputs=[
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Owning Data Domain", "Registered Measure Definition",
                                         "Metric Business Definition", "Metric Formula", "Metric Unit of Measure", "Metric Currency Basis",
                                         "Metric Aggregation Rule", "Metric Direction", "Metric Grain", "Metric Dimensions",
                                         "Owning Semantic Model", "Semantic Model Metric Name", "Metric Source Data Product",
                                         "Metric Certification Status"]),
            ("21", "Semantic Model Binding", ["Semantic Model", "Bound Certified Metrics"]),
            ("21", "Data Product", ["Data Product ID", "Data Product Timeliness", "Data Product Status"]),
            ("06", "Measure Definition", ["Measure ID", "Certified Indicator"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Flow Measures", ["Gross Sales", "Redemptions", "Net Flows (Net Sales)"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Average Client Assets", "Client Organic Growth Rate"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Restatement", ["Restatement ID", "Affected Periods", "Net Impact Amount"]),
            ("10", "Fee Revenue Record", ["Revenue Share Class / Mandate", "Revenue Accounting Period", "Gross Fee Revenue", "Net Fee Revenue",
                                          "Effective Net Fee Rate", "Revenue Data Basis"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount"]),
            ("27", "Share Class NAV", ["NAV Share Class", "NAV per Share", "Class Net Assets Amount", "Shares Outstanding"]),
            ("27", "Financial Highlights", ["Highlights Share Class", "Highlights Gross Expense Ratio", "Highlights Net Expense Ratio"]),
            ("32", "Performance Return", ["Return Period End Date", "Return Value", "Return Version", "Return Status"]),
            ("32", "Benchmark Return", ["Benchmark Period End Date", "Benchmark Return Value", "Benchmark Return Status"]),
            ("32", "Performance Restatement", ["Restated Return", "Restatement Date", "Material Error Indicator"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Measure Value"]),
            ("31", "Risk Calculation Run", ["Run As-Of Date", "Run Approval Status"]),
            ("31", "Fund Liquidity Profile", ["Profile Fund", "Profile Measurement Date", "Highly Liquid Percent", "Illiquid Percent"]),
            ("19", "GL Account Balance", ["Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance"]),
            ("19", "GL Account", ["GL Account Type", "Financial Statement Class"]),
            ("19", "Accounting Period Status", ["Period Close Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("20", "Employee Job Assignment", ["Assignment Type", "Assignment FTE"]),
            ("20", "Payroll Run", ["Pay Date", "Payroll Run Status"]),
            ("20", "Payroll Result", ["Payroll Run", "Gross Pay Amount"]),
        ],
        upstream=["DP-101", "DP-008", "DP-012", "DP-165", "DP-145", "DP-146", "DP-155", "DP-191", "DP-192", "DP-198", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET each business day, picking up every value the owners published the previous day; month-end values on the owners' own close days",
        history="Every published value and every restated version since the registry go-live, with the owner's snapshot or version reference; 10 years",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Dashboard"],
        dq_rules=[
            "Every value row names its Metric ID, its owning product (equal to Metric Source Data Product) and the owner's snapshot or version.",
            "Only metrics with Metric Certification Status = certified and Owner Conformance = Y are published.",
            "Each value equals the owning product's published value for the same key, period and version to the unit.",
            "No metric family has values from more than one product.",
            "A value replaced by its owner is kept as a prior version and flagged in Restated Values, never overwritten.",
        ],
        notes=("Certified numbers: none owned or computed; this is the published form of the CD-293 families, each value read "
               "from its owner (CD-293, CD-320, CD-330, CD-340, CD-341, CD-347). Definitions and certification status are "
               "DP-101's (CD-163); DP-101 holds definitions, never values, and this product adds the values (Foundations brief "
               "hardest call 3). CD-295 exports the catalog as 21 records; this registry is the value side of that export. "
               "PII = N: employee and payroll attributes are read only to take DP-192 and DP-198 aggregates; no person-level row "
               "is published; 32 Return Value and 31 Measured Portfolio (flagged personal because account and SMA-level rows exist) are read only for certified metrics at fund, share class, composite or firm grain; the validator's PII warning is accepted. Boundary: DP-075 stays the distribution "
               "view of the catalog; DP-214 KRIs and DP-247 packs take certified values from here. Taxonomy gap: 21 has no "
               "Metric Value (metric observation) object, so values are published as product output keyed to Metric ID and "
               "the owner's record, not as taxonomy records. Taxonomy gap: 21 Metric Definition has no version or effective "
               "dates, so a definition change cannot be tied to the values computed under it. Taxonomy gap: no attribute names "
               "a metric's metric family. Primary function FN-50. Decisions: CD-163, CD-293, CD-295, CD-301, CD-320, CD-330, "
               "CD-340, CD-341, CD-347. "
               "W4 re-point (06 review): 06 Measure Value Dimension Grain is read as Dimension Type and Dimension Key, and Snapshot "
               "Status as Snapshot Type. W4: 32 Private Markets Performance Measure dropped, no successor (private markets "
               "retired, CW-930; 32 re-cut, CW-129); with it the private fund IRR and multiples in Return Values (from DP-145)."
               "WP1 re-point (CW-203, CW-206): DP-008's certified asset measures are now Ending Client Assets, Average Client Assets and Client Organic Growth Rate (06 Client Asset Measures), read under the kept measure name 'Flow & Attributed AUM Values (from DP-008)' (SM-17 hides it by that name); Firm AUM moved from DP-165 to DP-241 (CW-206), so Owner Conformance names DP-241 for Firm AUM and Fund Metric Values (from DP-165) no longer lists it. The Firm AUM value row is not carried by this wholesale measure set: it returns from DP-241 when the registry is re-cut at WP2 (CERTIFIED_WEALTH, SM-20). The definition's 'Firm AUM ... from DP-165' is read as DP-241."),
    ),
    # ==================================================================================================================
    "DP-246": dict(
        definition=("The firm-wide index of regulatory submissions and the evidence behind them: fund filings and event filings "
                    "(DP-184, with as-filed data in DP-185 and DP-186), firm filings and ownership disclosures (DP-222), "
                    "regulator request items (DP-223), capital returns (DP-205) "
                    "and product reporting obligations (DP-083), with event triggers from investment breaches (DP-163) and "
                    "liquidity and derivatives programs (DP-155). One row per submission with its deadline, status and the "
                    "certified inputs used. It does not reassemble any form (CD-334): it reads the as-filed products and their "
                    "data sources. It owns no certified number."),
        business_questions=[
            "Which regulatory submissions are due in the next 30 and 90 days across funds, firm entities and regulators, and which are overdue?",
            "Which filings went in late or were amended, by form type, filer and regulator?",
            "For each fund filing, were all data sources certified, reconciled and signed off, and has a source changed since filing?",
            "Which breaches, limit exceedances or liquidity shortfalls require an event filing that has not been made?",
            "Do capital returns agree with the approved capital calculation, and are ownership disclosures filed when required?",
        ],
        grain=("Regulatory submission (fund filing REGF-, firm filing, regulatory financial return, "
               "entity annual filing or regulator request item) x filer (fund or legal entity) x reporting period "
               "end or event date x submission sequence, with a daily status snapshot"),
        dimensions=["Submission source type", "Form or return type", "Regulator", "Filer fund (DP-004) or legal entity (DP-013)",
                    "Reporting period end or event date", "Due date and due month", "Submission status", "Submission sequence and amendment",
                    "Data source type and certified source product", "Reportable event type", "As-of date"],
        measures=[
            ("Submissions Due (30 and 90 Days)",
             "Count of submissions with a due date within 30 and 90 days of the as-of date and not yet submitted, by source type: fund filings (Filing Due Date, Filing Status not filed, DP-184); firm filings (Filing Due Date, Filing Submitted Timestamp empty, DP-222); capital returns (Return Due Date, Regulatory Return Status not submitted, DP-205); entity annual filings (Annual Filing Due Date of active Entity Authorizations, DP-222); regulator request items (Request Due Date, Request Produced Date empty, DP-223).",
             _u("35", "Fund Regulatory Filing", "Regulatory Filing ID", "Filing Form Type", "Filing Due Date", "Filing Status")
             + _u("38", "Firm Regulatory Filing", "Firm Filing ID", "Filing Form Type", "Filing Due Date", "Filing Submitted Timestamp")
             + _u("19", "Regulatory Financial Return", "Regulatory Return Type", "Return Due Date", "Regulatory Return Status")
             + _u("38", "Entity Authorization", "Authorization ID", "Authorization Status", "Annual Filing Due Date")
             + _u("38", "Regulator Request Item", "Request Examination", "Request Sequence", "Request Due Date", "Request Produced Date")),
            ("Overdue Submissions",
             "Count of submissions past their due date and not submitted, by source type, filer and regulator, with business days overdue on the 09 calendar (Day Type).",
             _u("09", "Calendar Date", "Calendar Date", "Day Type") + ["Submissions Due (30 and 90 Days)"]),
            ("On-Time Submission %",
             "Submissions made on or before their due date / submissions due in the period, by source type: fund filings Official Filing Date <= Filing Due Date (DP-184 On-Time Filing %); firm filings Filing Submitted Timestamp date (ET) <= Filing Due Date (DP-222); request items Request Produced Date <= Request Due Date (DP-223); originals only, amendments excluded.",
             _u("35", "Fund Regulatory Filing", "Official Filing Date", "Filing Due Date", "Amended Filing")
             + _u("38", "Firm Regulatory Filing", "Filing Submitted Timestamp", "Filing Due Date", "Filing Submission Type")
             + _u("38", "Regulator Request Item", "Request Due Date", "Request Produced Date")),
            ("Missing Periodic Fund Filings (from DP-184)",
             "Count of effective Filing Obligations x reporting periods whose due date has passed with no Fund Regulatory Filing for the obligation, by Obligation Form Type and Obligation Regulator, as DP-184 publishes it.",
             _u("35", "Filing Obligation", "Obligated Product", "Obligated Entity", "Obligation Form Type", "Obligation Regulator",
                "Filing Frequency", "Obligation Effective From", "Obligation Effective To")
             + _u("35", "Fund Regulatory Filing", "Met Obligation", "Reporting Period End Date")),
            ("Amendments (Trailing 12 Months)",
             "Count of fund filings with Amended Filing populated and firm filings with Amended Firm Filing populated in the trailing 12 months, over the originals of the same form type.",
             _u("35", "Fund Regulatory Filing", "Amended Filing", "Filing Form Type", "Official Filing Date")
             + _u("38", "Firm Regulatory Filing", "Amended Firm Filing", "Filing Form Type")),
            ("Certified Inputs Used %",
             "Fund filings whose every Filing Data Source has Source Reconciled Indicator = Y and a Source Data Basis of final / fund filings submitted in the period, by form type; the evidence that as-filed values came from their certified source products (DP-185, DP-186, CD-334).",
             _u("35", "Filing Data Source", "Source Filing", "Filing Data Source Type", "Source Record Key", "Source As-Of Date",
                "Source Data Basis", "Source Reconciled Indicator")),
            ("Certification Completeness (from DP-184)",
             "Filings of form types that require certification with a Filing Certification whose Certification Signed Date is on or before Official Filing Date and Sub-Certifications Complete Indicator = Y / such filings.",
             _u("35", "Filing Certification", "Certification Type", "Certification Signed Date", "Sub-Certifications Complete Indicator")
             + _u("35", "Fund Regulatory Filing", "Official Filing Date")),
            ("Source Drift Since Filing (from DP-185, DP-186)",
             "Count of filed fund filings for which DP-185 or DP-186 reports Source Drift Since Filing beyond the form's tolerance (a later version of a Filing Data Source record than the one filed), by form type: candidates for amendment.",
             _u("35", "Filing Data Source", "Source Filing", "Source Record Key", "Source As-Of Date", "Source Data Basis")
             + _u("35", "Fund Regulatory Filing", "Filing Status")),
            ("Event Filings Pending",
             "Count of events that require a filing and have none: Breach Reviews with Regulatory Notification Required Indicator = Y and Resulting Reportable Fund Event empty (from DP-163); Risk Limit Exceedances with Form N-RN Trigger Indicator = Y named by no Reportable Fund Event (from DP-155); Fund Liquidity Profiles with HLIM Shortfall Indicator = Y and Consecutive HLIM Shortfall Days above 7 named by no Reportable Fund Event; and Reportable Fund Events with Resulting Filing empty (DP-184).",
             _u("33", "Breach Review", "Reviewed Breach", "Regulatory Notification Required Indicator", "Resulting Reportable Fund Event")
             + _u("31", "Risk Limit Exceedance", "Risk Limit Exceedance ID", "Exceedance Start Date", "Form N-RN Trigger Indicator")
             + _u("31", "Fund Liquidity Profile", "Profile Fund", "Profile Measurement Date", "HLIM Shortfall Indicator", "Consecutive HLIM Shortfall Days")
             + _u("35", "Reportable Fund Event", "Event Fund", "Reportable Event Type", "Event Date", "Source Investment Breach",
                  "Source Risk Limit Exceedance", "Source Fund Liquidity Profile", "Resulting Filing")),
            ("Ownership Disclosures Unfiled (from DP-222)",
             "Count of Ownership Disclosure Determinations with Filing Required Indicator = Y and Resulting Firm Filing empty, by Disclosure Regime and days since Determination Date.",
             _u("38", "Ownership Disclosure Determination", "Disclosure Regime", "Determination Date", "Filing Required Indicator", "Resulting Firm Filing")),
            ("Capital Return Consistency (from DP-205)",
             "Per Regulatory Financial Return carrying capital amounts: Capital Requirement Amount - Treasury Capital Requirement Amount and Capital Resources Amount - Treasury Capital Resources Amount of the approved Capital Requirement Calculation of the same entity and as-of date (DP-205's Return Copy Difference); flagged when not zero.",
             _u("19", "Regulatory Financial Return", "Return Filing Entity", "Return Reporting Period End", "Capital Requirement Amount", "Capital Resources Amount")
             + _u("43", "Capital Requirement Calculation", "Calculation Entity", "Calculation As-Of Date", "Treasury Capital Requirement Amount",
                  "Treasury Capital Resources Amount", "Calculation Approval Status")),
        ],
        inputs=[
            ("35", "Filing Obligation", ["Obligated Product", "Obligated Entity", "Obligation Form Type", "Obligation Regulator",
                                         "Filing Frequency", "Obligation Effective From", "Obligation Effective To"]),
            ("35", "Fund Regulatory Filing", ["Regulatory Filing ID", "Filing Form Type", "Filer Product", "Filer Entity", "Met Obligation",
                                              "Reporting Period End Date", "Event or As-Of Date", "Filing Due Date", "Submission Sequence",
                                              "Official Filing Date", "Accession Number", "Filing Status", "Amended Filing"]),
            ("35", "Filing Certification", ["Certification Type", "Certification Signed Date", "Sub-Certifications Complete Indicator"]),
            ("35", "Filing Data Source", ["Source Filing", "Filing Data Source Type", "Source Record Key", "Source As-Of Date",
                                          "Source Data Basis", "Source Reconciled Indicator"]),
            ("35", "Reportable Fund Event", ["Event Fund", "Reportable Event Type", "Event Date", "Source Investment Breach",
                                             "Source Risk Limit Exceedance", "Source Fund Liquidity Profile", "Resulting Filing"]),
            ("38", "Firm Regulatory Filing", ["Firm Filing ID", "Filer Entity", "Filing Form Type", "Filing Submission Type",
                                              "Filing Period End Date", "Filing Due Date", "Filing Submitted Timestamp", "Firm Filing Status",
                                              "Amended Firm Filing"]),
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Regulator", "Authorization Type",
                                            "Authorization Status", "Annual Filing Due Date"]),
            ("38", "Ownership Disclosure Determination", ["Disclosure Regime", "Determination Date", "Filing Required Indicator",
                                                          "Resulting Firm Filing"]),
            ("38", "Regulatory Examination", ["Examination ID", "Examining Regulator", "Examined Entities"]),
            ("38", "Regulator Request Item", ["Request Examination", "Request Sequence", "Request Due Date", "Request Produced Date"]),
            ("19", "Regulatory Financial Return", ["Return Filing Entity", "Return Regulator", "Regulatory Return Type",
                                                   "Return Reporting Period End", "Return Due Date", "Regulatory Return Status",
                                                   "Capital Requirement Amount", "Capital Resources Amount"]),
            ("43", "Capital Requirement Calculation", ["Calculation Entity", "Calculation As-Of Date", "Treasury Capital Requirement Amount",
                                                       "Treasury Capital Resources Amount", "Calculation Approval Status"]),
            ("33", "Breach Review", ["Reviewed Breach", "Regulatory Notification Required Indicator", "Resulting Reportable Fund Event"]),
            ("31", "Risk Limit Exceedance", ["Risk Limit Exceedance ID", "Exceedance Start Date", "Form N-RN Trigger Indicator"]),
            ("31", "Fund Liquidity Profile", ["Profile Fund", "Profile Measurement Date", "HLIM Shortfall Indicator", "Consecutive HLIM Shortfall Days"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type"]),
            ("01", "Regulatory Authorization", ["Competent Authority", "Regulatory Reporting Obligations"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
        ],
        upstream=["DP-184", "DP-185", "DP-186", "DP-083", "DP-222", "DP-223", "DP-163", "DP-155", "DP-205", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET each business day with status as of the prior day's close",
        history="Daily status snapshots kept 2 years, month-end snapshots and every submission and amendment kept for the regulatory retention period (at least 7 years)",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every submission row has a source type, a filer that resolves to a DP-004 product or a DP-013 legal entity, a regulator and a due date.",
            "A fund filing appears once per Regulatory Filing ID and Submission Sequence, and an amendment links to the filing it amends.",
            "Certified Inputs Used % counts a filing as certified only when all its Filing Data Sources are reconciled; a filing with no data source counts as not certified.",
            "Every Reportable Fund Event with a Resulting Filing resolves to a Fund Regulatory Filing whose Event or As-Of Date is on or after the Event Date.",
            "No as-filed value is recomputed or overwritten here: drift is read from DP-185 and DP-186, and the hub publishes counts and links only.",
        ],
        notes=("Certified numbers: none owned; as-filed values stay in DP-185 and DP-186 keyed to their certified sources, and the "
               "hub never reassembles a form or serves current values (CD-334, CD-234). Event triggers are read from DP-163 "
               "(breach reviews) and DP-155 (limit exceedances, HLIM shortfalls); the event register itself is DP-184's. DP-083 "
               "is read for the product reporting obligations it carries; firm-level obligations and attestations are DP-224's "
               "(CD-351) and are not filings. Regulator request items (DP-223) are submissions to an examiner, not filings, and "
               "are a separate source type. Drafting assumptions: the seven-business-day HLIM shortfall trigger for Form N-RN; "
               "Regulatory Return Status and Filing Status code values for 'submitted' and 'filed'. Taxonomy gap: 19 Regulatory "
               "Financial Return has no submitted date, so its on-time rate is taken from the daily status history. Taxonomy "
               "gap: no single submission object spans 35, 38 and 19; the hub's submission key is derived (source type + source "
               "key). Primary function FN-36. Decisions: CD-234, CD-334, CD-351. "
               "W2: 08 Cross-Border Marketing Notification dropped, no successor in the wealth 08 (EU / UK fund marketing "
               "passports, US only; CW-908, CW-003); with it the measure Pending Marketing Notifications (from DP-041), the "
               "notification source type and the upstream DP-041."
               "WP1 re-point (CW-260): measure 'Product Obligations Without Filing Calendar (from DP-083)' dropped: the re-scoped DP-083 no longer reads 01 Regulatory Authorization (fund regimes are DP-004's and the funds' filings DP-184's); the successor view is DP-509 Regulatory Horizon & Change Watch (backlog), so no live product restores it yet. The SM-11 metric on it is removed; the 01 and 35 inputs stay as read by the other measures or as filing context."),
    ),
    # ==================================================================================================================
    "DP-247": dict(
        definition=("The monthly and quarterly management and board reporting pack at firm, business area, business line and "
                    "legal entity level. It reads certified metrics only, through the Enterprise KPI & Metrics Registry "
                    "(DP-245, CD-293), plus budget, forecast and actual operating expense and revenue (DP-194, which takes "
                    "actuals from DP-191), headcount and FTE (DP-192), the risk and control summary (DP-248) and board "
                    "approvals (DP-182). It exists so management and the board see one set of numbers each period, and no "
                    "line can carry an uncertified figure. It owns no certified number."),
        business_questions=[
            "What are this period's certified KPIs (flows, AUM, revenue, operating income, returns, headcount) against last period, last year and budget?",
            "Where are we over or under budget, what is the full-year outturn, and how is operating margin trending?",
            "How do headcount and FTE compare with plan and authorized positions?",
            "What does the risk and control summary say: risks outside appetite, red KRIs, overdue issues and losses?",
            "Which board approvals were given this period and which expire soon?",
        ],
        grain=("Pack edition (month-end or quarter-end) x reporting level (firm, business area, business line, legal entity) x "
               "pack section x pack line (certified metric, plan line, headcount, risk summary item or board approval)"),
        dimensions=["Pack edition and period (DP-013)", "Reporting level", "Business area and business line", "Legal entity (DP-013)",
                    "Pack section", "Certified metric and owning product (DP-245)", "Statement line and cost center (DP-190)",
                    "Plan version (DP-194)", "Risk category (DP-248)", "Board resolution type (DP-182)"],
        measures=[
            ("Certified KPI Lines (from DP-245)",
             "For each certified metric selected for the pack: its value for the edition's period and reporting level, with the owning product named, read from DP-245; a metric whose Metric Certification Status is not certified is never shown.",
             _u("21", "Metric Definition", "Metric ID", "Metric Name", "Metric Unit of Measure", "Metric Source Data Product",
                "Owning Semantic Model", "Metric Certification Status")),
            ("KPI Change vs Prior Period and Prior Year (from DP-245)",
             "DP-245's Change vs Prior Period and Prior Year for each pack metric, with direction shown against Metric Direction (higher or lower is better).",
             _u("21", "Metric Definition", "Metric Direction") + ["Certified KPI Lines (from DP-245)"]),
            ("Uncertified Lines Excluded",
             "Count of metrics requested for the pack whose Metric Certification Status is not certified or whose DP-245 Owner Conformance is N; must be zero for a released pack, otherwise each is listed as an exception.",
             _u("21", "Metric Definition", "Metric ID", "Metric Certification Status", "Metric Source Data Product")),
            ("Actuals (from DP-194)",
             "Actual Revenue, Actual Operating Expense and Actual Operating Income by legal entity, statement line and period, as DP-194 publishes them from DP-191 certified balances (CD-340).",
             _u("19", "GL Account Balance", "Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance")
             + _u("19", "GL Account", "GL Account ID", "GL Account Type", "Financial Statement Class")
             + _u("19", "Ledger", "Ledger ID", "Ledger Legal Entity", "Ledger Role")),
            ("Budget, Forecast and Variance (from DP-194)",
             "Budget, Latest Forecast, Variance to Budget and Variance %, and Full-Year Outturn by legal entity, statement line and period, as DP-194 publishes them.",
             _u("19", "Financial Plan Version", "Financial Plan Version ID", "Financial Plan Type", "Plan Fiscal Year", "Actuals Through Period", "Plan Version Status")
             + _u("19", "Financial Plan Line", "Line Plan Version", "Plan Legal Entity", "Plan GL Account", "Plan Line Period", "Plan Line Amount")
             + ["Actuals (from DP-194)"]),
            ("Operating Margin % (from DP-194)",
             "Actual Operating Income / Actual Revenue year to date by legal entity, and the same ratio on Budget and Latest Forecast, as DP-194 publishes them.",
             ["Actuals (from DP-194)", "Budget, Forecast and Variance (from DP-194)"]),
            ("Headcount and FTE (from DP-192, DP-194)",
             "Certified Headcount and Certified FTE at the period end (DP-192, CD-341) by legal entity, with DP-194's FTE Variance to Plan against Planned FTE.",
             _u("20", "Employee", "Employee ID", "Employing Legal Entity", "Employment Status")
             + _u("20", "Employee Job Assignment", "Assignment Type", "Assignment FTE")
             + _u("19", "Financial Plan Line", "Planned FTE")),
            ("Risk & Control Summary (from DP-248)",
             "DP-248's Risks Outside Appetite, red KRIs, overdue issues (from DP-216 through DP-248), incident count and Net Operational Loss for the period, by risk category and legal entity.",
             _u("37", "Enterprise Risk", "Risk ID", "Risk Category", "Enterprise Risk Status")
             + _u("37", "Risk Assessment", "Assessed Risk", "Risk Assessment Date", "Within Appetite Indicator")
             + _u("37", "KRI Observation", "Observed KRI", "KRI Observation Date", "KRI Observation RAG")
             + _u("37", "Risk Issue", "Risk Issue ID", "Issue Rating", "Issue Status", "Issue Due Date")
             + _u("37", "Loss Event Amount", "Loss Amount Component", "Loss Amount", "Loss Booking Date")),
            ("Board Approvals (from DP-182)",
             "Count of Board Resolutions with Resolution Outcome approved and Resolution Effective Date in the period by Resolution Type, and approvals expiring in the next 90 days (Resolution Expiry Date) with no superseding resolution, as DP-182 publishes them.",
             _u("35", "Board Resolution", "Board Resolution ID", "Resolution Type", "Resolution Outcome", "Resolution Effective Date", "Resolution Expiry Date")
             + _u("35", "Resolution Subject Link", "Linked Resolution", "Resolution Subject Type", "Subject Product")),
            ("Pack Completeness %",
             "Pack lines with a value for the edition / pack lines defined for the edition and reporting level; a pack is released at 100% or with each missing line listed.",
             ["Certified KPI Lines (from DP-245)", "Actuals (from DP-194)", "Headcount and FTE (from DP-192, DP-194)",
              "Risk & Control Summary (from DP-248)", "Board Approvals (from DP-182)"]),
        ],
        inputs=[
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Unit of Measure", "Metric Direction",
                                         "Owning Semantic Model", "Metric Source Data Product", "Metric Certification Status"]),
            ("19", "Financial Plan Version", ["Financial Plan Version ID", "Financial Plan Type", "Plan Fiscal Year",
                                              "Actuals Through Period", "Plan Version Status"]),
            ("19", "Financial Plan Line", ["Line Plan Version", "Plan Legal Entity", "Plan GL Account", "Plan Line Period",
                                           "Plan Line Amount", "Planned FTE"]),
            ("19", "GL Account Balance", ["Balance Ledger", "Balance GL Account", "Balance Fiscal Period", "Balance Type",
                                          "Opening Balance", "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Legal Entity", "Ledger Role"]),
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Employment Status"]),
            ("20", "Employee Job Assignment", ["Assignment Type", "Assignment FTE"]),
            ("37", "Enterprise Risk", ["Risk ID", "Risk Category", "Enterprise Risk Status"]),
            ("37", "Risk Assessment", ["Assessed Risk", "Risk Assessment Date", "Within Appetite Indicator"]),
            ("37", "KRI Observation", ["Observed KRI", "KRI Observation Date", "KRI Observation RAG"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Issue Rating", "Issue Status", "Issue Due Date"]),
            ("37", "Loss Event Amount", ["Loss Amount Component", "Loss Amount", "Loss Booking Date"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Resolution Type", "Resolution Outcome", "Resolution Effective Date",
                                        "Resolution Expiry Date"]),
            ("35", "Resolution Subject Link", ["Linked Resolution", "Resolution Subject Type", "Subject Product"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Fiscal Period Type", "Period End Date"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
        ],
        upstream=["DP-245", "DP-194", "DP-192", "DP-248", "DP-182", "DP-190", "DP-013"],
        refresh="Monthly",
        timeliness="Management pack by business day 12 after month-end; quarterly board pack by business day 20 after quarter-end",
        history="Every released edition kept as issued, with any reissue as a new version; 10 years",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every KPI line takes its value from DP-245 and names the owning product; no KPI line reads a product other than DP-245.",
            "A released edition has Uncertified Lines Excluded = 0, or each exception is listed in the edition.",
            "Actuals equal DP-194's Actual figures (and so DP-191's certified balances) for the same entity, statement line and period.",
            "Headcount and FTE equal DP-192's certified values at the period end.",
            "A released edition is never changed; corrections are issued as a new version with the reason.",
        ],
        notes=("Certified numbers: none owned; KPIs only through DP-245 (CD-293), actuals through DP-194 from DP-191 (CD-340), "
               "headcount and FTE from DP-192 (CD-341). The risk summary is DP-248's and remediation status DP-216's (CD-356); "
               "this product shows them, it counts nothing itself. PII = N: employee keys are counted for headcount, never "
               "published; the validator's PII warning on 20 Employee and Employee Job Assignment is accepted on that basis. Boundary: DP-194 stays the FP&A product; DP-182 keeps fund board governance and the 39 corporate "
               "board is not yet read (no product publishes corporate resolutions for the pack). Taxonomy gap: no object holds "
               "a reporting pack definition (sections, lines, audience, edition, release approval). Taxonomy gap: no attribute "
               "names a business area on the ledger or the metric dimensions; area grain needs the capability map's area "
               "mapping of org units. Taxonomy gap: no attribute records a pack's release or reissue reason. Primary function "
               "FN-38. Decisions: CD-293, CD-340, CD-341, CD-356."),
    ),
    # ==================================================================================================================
    "DP-248": dict(
        definition=("One risk and control view for the risk committee, by risk category, legal entity and business line: the "
                    "risk profile, appetite and KRIs and key control testing (DP-214), operational incidents and losses "
                    "(DP-215), remediation status (DP-216, computed once, CD-356), business continuity and critical functions (DP-217), internal "
                    "audit findings (DP-218), third-party oversight (DP-219), the compliance program (DP-224), investment "
                    "breaches (DP-163), distribution regulatory horizon items (DP-083) and security incidents and "
                    "vulnerabilities (DP-232). Every figure is read from its owning product; losses are operational amounts that "
                    "reconcile to the ledger (CD-353). It owns no certified number and computes no remediation status."),
        business_questions=[
            "Which risks are outside appetite, by category and legal entity, and which moved rating this month?",
            "Where are KRIs red, key controls failing and issues overdue, and which areas need the committee's attention?",
            "What were operational incidents and net losses this period, and do the losses reconcile to the ledger?",
            "Did continuity plans meet their recovery objectives in testing, and are audit, third-party, compliance and security exposures under control?",
            "How many investment breaches are open, and are material breaches signed off by the CCO?",
        ],
        grain=("Risk category (taxonomy level 1 and 2) x legal entity x business line x month-end, with one child row per source "
               "panel (risk, control, KRI, incident and loss, issue, resilience, audit, third party, compliance, investment "
               "breach, horizon item, security)"),
        dimensions=["Month-end (DP-013)", "Risk category level 1 and 2 (DP-214)", "Legal entity (DP-013)", "Business line",
                    "Source panel", "Residual risk rating", "Issue rating and remediation status (DP-216)", "Basel event type (DP-215)",
                    "Business continuity plan (DP-217)", "Third-party criticality tier (DP-219)", "Vulnerability severity (DP-232)",
                    "Attention flag"],
        measures=[
            ("Residual Risk Profile (from DP-214)",
             "Count of active Enterprise Risks by Residual Risk Rating of their latest Risk Assessment, by risk category, legal entity (Risk Legal Entities) and business line (Risk Business Lines), and Risk Rating Migration since the prior month-end, as DP-214 publishes them.",
             _u("37", "Enterprise Risk", "Risk ID", "Risk Category", "Risk Legal Entities", "Risk Business Lines", "Enterprise Risk Status")
             + _u("37", "Risk Assessment", "Assessed Risk", "Risk Assessment Date", "Residual Risk Rating")
             + _u("37", "Risk Taxonomy Category", "Risk Category Code", "Risk Category Name", "Parent Risk Category")),
            ("Risks Outside Appetite (from DP-214)",
             "Count of active risks whose latest Risk Assessment has Within Appetite Indicator = N, by risk category and legal entity.",
             _u("37", "Risk Assessment", "Within Appetite Indicator") + ["Residual Risk Profile (from DP-214)"]),
            ("KRI Breaches (from DP-214)",
             "Count of KRI versions whose latest KRI Observation has KRI Observation RAG Red, and Amber, by the Measured Risk's category, and Persistent KRI Breaches (three latest Red), as DP-214 publishes them.",
             _u("37", "Key Risk Indicator", "KRI Code", "KRI Version", "Measured Risk")
             + _u("37", "KRI Observation", "Observed KRI", "KRI Observation Date", "KRI Observation RAG")),
            ("Key Control Test Failure Rate (from DP-214)",
             "Control Tests of key controls (Key Control Indicator = Y) with Control Test Result = Ineffective / Control Tests of key controls in the trailing 12 months, as DP-214 publishes it.",
             _u("37", "Control", "Control ID", "Control Version", "Key Control Indicator")
             + _u("37", "Control Test", "Tested Control", "Control Test Date", "Control Test Result")),
            ("Incidents and Net Operational Loss (from DP-215)",
             "Incident Count by Basel Event Type Level 1 and Incident Severity (near misses separate), Gross Operational Loss, Insurance Recoveries and Net Operational Loss by Loss Booking Date period, Loss Legal Entity and Loss Business Line, and Loss Reconciled to GL %, as DP-215 publishes them; operational amounts, not expense (CD-353).",
             _u("37", "Operational Incident", "Operational Incident ID", "Incident Discovery Date", "Incident Legal Entity", "Incident Severity")
             + _u("37", "Incident Classification", "Basel Event Type Level 1", "Incident Risk Category", "Near Miss Indicator")
             + _u("37", "Operational Loss Event", "Loss Event ID", "Originating Incident", "Loss Legal Entity", "Loss Business Line")
             + _u("37", "Loss Event Amount", "Amount Loss Event", "Loss Amount Component", "Loss Amount", "Loss Booking Date", "GL Evidence Journal")
             + _u("43", "Insurance Claim", "Related Operational Loss Event", "Amount Recovered")),
            ("Remediation Status (from DP-216)",
             "Open Issues, Overdue Issues and Risk-Accepted Issues by Issue Rating, Issue Source Type and the related risk's category, exactly as DP-216 computes them (CD-356); never recomputed here.",
             _u("37", "Risk Issue", "Risk Issue ID", "Issue Source Type", "Issue Rating", "Issue Related Risk", "Issue Due Date", "Issue Status")),
            ("Resilience (from DP-217)",
             "Plans Meeting Recovery Objectives % and Plans Untested (12 Months) for approved Business Continuity Plans at the month-end, from the latest Scenario Test Resilience Test of each plan, as DP-217 publishes them.",
             _u("37", "Business Continuity Plan", "Business Continuity Plan Code", "Business Continuity Plan Version", "Plan Approval Status")
             + _u("37", "Resilience Test", "Resilience Test Reference", "Resilience Test Date", "Resilience Test Type", "Tested Continuity Plan", "Tolerance Met Indicator")),
            ("Audit Findings (from DP-218)",
             "Open Findings and Overdue Findings (Audit Finding Due Date before the month-end) by Audit Finding Rating, open meaning no Finding Closure Validation with a closed Finding Validation Outcome, as DP-218 publishes them.",
             _u("37", "Audit Finding", "Audit Finding ID", "Audit Finding Rating", "Audit Finding Due Date")
             + _u("37", "Finding Closure Validation", "Validated Finding", "Finding Validation Outcome")),
            ("Third-Party Risk (from DP-219)",
             "High Residual Risk Engagements (latest Third-Party Residual Risk Rating High, Critical or Prohibited) and Critical Engagements Without Current Assessment, by Third-Party Criticality Tier, for active Supplier Engagements, as DP-219 publishes them.",
             _u("40", "Supplier Engagement", "Supplier Engagement ID", "Engagement Status")
             + _u("40", "Supplier Risk Tiering", "Tiered Engagement", "Third-Party Criticality Tier")
             + _u("37", "Third-Party Risk Assessment", "Third-Party Risk Assessment Reference", "Assessed Supplier Engagement",
                  "Third-Party Residual Risk Rating", "Third-Party Assessment Completed Date")),
            ("Compliance Program (from DP-224)",
             "Obligations Without Monitoring Control by Applicable Legal Entity as DP-224 publishes it, and Attestation Completion % as DP-083 publishes it (WP1: DP-083 owns the attestation measures).",
             _u("38", "Regulatory Obligation", "Obligation ID", "Applicable Legal Entity", "Monitoring Control")
             + _u("38", "Attestation", "Attestation Type", "Attestation Status", "Attestation Completed Date")),
            ("Investment Breaches (from DP-163)",
             "Open Breaches and New Breaches in the month by Breach Type, and Material Breaches Without CCO Sign-Off, as DP-163 publishes them.",
             _u("33", "Investment Breach", "Investment Breach ID", "Breach Type", "Breach Detected Date", "Material Breach Indicator", "Breach Status", "Breach Closure Date")
             + _u("33", "Breach Review", "Reviewed Breach", "CCO Sign-Off Date")),
            ("Security (from DP-232)",
             "Security Events Opened in the month (IT Incidents with Incident Class = Security Event), those with Personal Data Affected Indicator = Y, and Overdue Critical and High Vulnerabilities (Remediation Due Date before the month-end, not remediated), as DP-232 publishes them.",
             _u("41", "IT Incident", "IT Incident ID", "Incident Class", "Incident Detected Timestamp")
             + _u("41", "Security Incident Detail", "Personal Data Affected Indicator")
             + _u("41", "Vulnerability Finding", "Vulnerability Finding ID", "Vulnerability Severity", "Remediation Due Date", "Vulnerability Remediation Status")),
            ("Attention Flag",
             "Y for a risk category and legal entity when any of: a risk outside appetite; a persistent red KRI; an overdue issue rated High or Critical linked to one of its risks (Issue Related Risk); a key control test failure in the month; or a gross loss above the committee's reporting threshold. A published rule, not a model score.",
             ["Risks Outside Appetite (from DP-214)", "KRI Breaches (from DP-214)", "Remediation Status (from DP-216)",
              "Key Control Test Failure Rate (from DP-214)", "Incidents and Net Operational Loss (from DP-215)"]),
        ],
        inputs=[
            ("37", "Risk Taxonomy Category", ["Risk Category Code", "Risk Category Name", "Parent Risk Category"]),
            ("37", "Enterprise Risk", ["Risk ID", "Risk Category", "Risk Legal Entities", "Risk Business Lines", "Enterprise Risk Status"]),
            ("37", "Risk Assessment", ["Assessed Risk", "Risk Assessment Date", "Residual Risk Rating", "Within Appetite Indicator"]),
            ("37", "Key Risk Indicator", ["KRI Code", "KRI Version", "Measured Risk"]),
            ("37", "KRI Observation", ["Observed KRI", "KRI Observation Date", "KRI Observation RAG"]),
            ("37", "Control", ["Control ID", "Control Version", "Key Control Indicator"]),
            ("37", "Control Test", ["Tested Control", "Control Test Date", "Control Test Result"]),
            ("37", "Operational Incident", ["Operational Incident ID", "Incident Discovery Date", "Incident Legal Entity", "Incident Severity"]),
            ("37", "Incident Classification", ["Basel Event Type Level 1", "Incident Risk Category", "Near Miss Indicator"]),
            ("37", "Operational Loss Event", ["Loss Event ID", "Originating Incident", "Loss Legal Entity", "Loss Business Line"]),
            ("37", "Loss Event Amount", ["Amount Loss Event", "Loss Amount Component", "Loss Amount", "Loss Booking Date", "GL Evidence Journal"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Issue Source Type", "Issue Rating", "Issue Related Risk", "Issue Due Date", "Issue Status"]),
            ("37", "Business Continuity Plan", ["Business Continuity Plan Code", "Business Continuity Plan Version", "Plan Approval Status"]),
            ("37", "Resilience Test", ["Resilience Test Reference", "Resilience Test Date", "Resilience Test Type", "Tested Continuity Plan",
                                       "Tolerance Met Indicator"]),
            ("37", "Audit Finding", ["Audit Finding ID", "Audit Finding Rating", "Audit Finding Due Date"]),
            ("37", "Finding Closure Validation", ["Validated Finding", "Finding Validation Outcome"]),
            ("37", "Third-Party Risk Assessment", ["Third-Party Risk Assessment Reference", "Assessed Supplier Engagement",
                                                   "Third-Party Residual Risk Rating", "Third-Party Assessment Completed Date"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engagement Status"]),
            ("40", "Supplier Risk Tiering", ["Tiered Engagement", "Third-Party Criticality Tier"]),
            ("43", "Insurance Claim", ["Related Operational Loss Event", "Amount Recovered"]),
            ("38", "Regulatory Obligation", ["Obligation ID", "Applicable Legal Entity", "Monitoring Control"]),
            ("38", "Attestation", ["Attestation Type", "Attestation Status", "Attestation Completed Date"]),
            ("33", "Investment Breach", ["Investment Breach ID", "Breach Type", "Breach Detected Date", "Material Breach Indicator",
                                         "Breach Status", "Breach Closure Date"]),
            ("33", "Breach Review", ["Reviewed Breach", "CCO Sign-Off Date"]),
            ("11", "Regulatory Horizon Item", ["Regulator / Body", "Expected Effective Date", "Market Impact Assessment"]),
            ("41", "IT Incident", ["IT Incident ID", "Incident Class", "Incident Detected Timestamp"]),
            ("41", "Security Incident Detail", ["Personal Data Affected Indicator"]),
            ("41", "Vulnerability Finding", ["Vulnerability Finding ID", "Vulnerability Severity", "Remediation Due Date",
                                             "Vulnerability Remediation Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
        ],
        upstream=["DP-214", "DP-215", "DP-216", "DP-217", "DP-218", "DP-219", "DP-224", "DP-163", "DP-083", "DP-404", "DP-232", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 7 after month-end, for the risk committee; source panels as of the month-end close",
        history="Month-end snapshots kept 10 years; each committee edition kept as issued",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every count equals the owning product's published value for the same month-end and filter; Remediation Status counts equal DP-216's (CD-356).",
            "Every risk, incident, loss and issue row resolves to a risk category in the 37 Risk Taxonomy Category and to a DP-013 legal entity, or is shown as unmapped.",
            "Net Operational Loss = Gross Operational Loss - Insurance Recoveries - third-party recoveries for every row, and is never labeled expense.",
            "Attention Flag is Y only when at least one of its stated conditions holds, and each flagged row lists the conditions met.",
            "The month-end edition is locked once issued to the committee; later source corrections appear in the next edition.",
        ],
        notes=("W1b re-point (CW-937): the resilience panel reads DP-217's Plans Meeting Recovery Objectives % and Plans Untested (12 Months) through 37 Business Continuity Plan and Resilience Test.Tested Continuity Plan; Important Business Service and Resilience Test.Tested Business Service were removed (no successor), and the dimension is the continuity plan. "
               "Certified numbers: none owned. Remediation status is computed once in DP-216 and read here (CD-356); losses and "
               "recoveries are DP-215's operational measures that reconcile to DP-191, never expense (CD-353). Attention Flag "
               "is a published rule, not a model score (CD-294 applies only if a scored risk index is added, which would then "
               "be registered in DP-212). DP-083 is read for distribution horizon items only; obligations and attestations come "
               "from DP-224, of which DP-083 is the distribution view (CD-351). PII = N: owners and approvers are not read; "
               "panels are counts by category and entity. Drafting assumptions: the committee's gross loss reporting "
               "threshold is a Risk parameter; code values Ineffective, Red, Security Event and Critical / High follow the "
               "source products. Taxonomy gap: 41 IT Incident and 33 Investment Breach carry no risk category, so security and "
               "breach panels are mapped to the 37 taxonomy by a fixed category (information security, investment compliance) "
               "until 37 holds a mapping. Taxonomy gap: 38 Regulatory Obligation and 40 Supplier Engagement carry no business "
               "line. Taxonomy gap: no attribute holds the committee's loss reporting threshold. Primary function FN-42. "
               "Decisions: CD-243, CD-294, CD-351, CD-353, CD-356."
               "WP1 re-point (CW-260): Attestation Completion % is read from the re-scoped DP-083 (already upstream), which now owns it; DP-224 dropped it. The measure name 'Compliance Program (from DP-224)' is kept for its readers."
               "WP1 re-point (CW-260): measure 'Distribution Horizon Items (from DP-083)' dropped: the re-scoped DP-083 dropped the regulatory horizon (11 Regulatory Horizon Item); its successor is DP-509 Regulatory Horizon & Change Watch (backlog), which would restore the panel. The SM-16 committee column on it is removed."
               "WP1 re-point (CW-224): DP-404 Retail Conduct Supervision (CLA-B, specs_w1c_cla_b.py), which took the registration, CE and FINRA-filing indicators of the re-scoped DP-036 and DP-039, is added upstream as the retail conduct feeder of this view; DP-404 does not list this product. No conduct panel measure is added at WP1 (scope change left for this product's re-spec)."),
    ),
}
