"""Data product specifications, Wave 2: the data catalog and lineage product DP-075. See CONTRACT.md."""

# DP-058, DP-059, DP-064, DP-072 and DP-076 retired at WP0 (framework.RETIRED_PRODUCTS); their specs were deleted in the WP2 retirement sweep.
SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-075": dict(
        definition=("The catalog of the distribution data estate: every data product with its owner, tier, inputs and "
                    "certification, together with the governed building blocks it draws on, including licensed datasets and "
                    "their key fields, inbound data feeds and loads, registered code lists and mappings, the marketing "
                    "systems that produce engagement and campaign data, certified measure definitions and data quality rules. It records lineage from source feed and licensed dataset through "
                    "taxonomy objects to data products and consuming applications, kept in step with this taxonomy, so that "
                    "data products are discoverable, their trust level is visible and the impact of a change can be traced."),
        business_questions=[
            "Which data products exist, who owns them, what grain and classification do they have, and are they certified?",
            "Which feeds, licensed datasets and taxonomy objects feed a given data product, and which products and applications are affected if a feed or dataset changes?",
            "Which licensed datasets and code lists have no recorded consumer, and which consumers use a dataset without a covering permitted use?",
            "Which measure definitions are certified, and which data products use uncertified measures?",
            "Which feeds missed their expected loads or have failing data quality rules, and which products depend on them?",
            "Which marketing systems (marketing automation, CRM, web analytics, event and social tools) are sources for which data products and code mappings?",
        ],
        grain="Catalog entry (data product, licensed dataset, data feed, code list, marketing system, measure definition or DQ rule) x version, with a lineage edge child grain (source entry x target entry x effective period)",
        dimensions=["Catalog entry type", "Data Domain", "Owner and steward", "Tier and product type", "Certification status",
                    "Classification and personal data indicator", "Source system / data provider", "Marketing system category",
                    "Consuming application",
                    "Effective date / version"],
        measures=[
            ("Catalog Completeness %", "Catalog entries with owner, definition, grain, classification and refresh populated / catalog entries, by entry type.",
             [("06", "Data Feed", "Feed ID"), ("06", "Data Feed", "Data Provider"), ("06", "Data Feed", "Feed Grain"),
              ("06", "Data Feed", "Delivery Frequency"), ("14", "Dataset", "Dataset ID"),
              ("14", "Dataset", "Dataset Business Owner"), ("14", "Dataset", "Information Sensitivity"),
              ("09", "Code List", "Code List ID"), ("09", "Code List", "Data Owner"),
              ("09", "Code List", "Code List Definition")]),
            ("Lineage Completeness %", "Data product inputs traced to at least one data feed or licensed dataset / data product inputs.",
             [("14", "Dataset Consumption", "Consumed Dataset"),
              ("14", "Dataset Consumption", "Consuming Business Domain"),
              ("14", "Dataset Consumption", "Target Concept"), ("06", "Data Feed", "Feed ID"),
              ("06", "Data Feed", "Data Content")]),
            ("Certified Measure Share %", "Measure definitions used by data products with Certified Indicator = Y / measure definitions used by data products.",
             [("06", "Measure Definition", "Certified Indicator")]),
            ("Orphan Dataset Count", "Licensed datasets with Dataset Status active and no Dataset Consumption in force on the as-of date.",
             [("14", "Dataset", "Dataset Status")]),
            ("Uncovered Consumption Count", "Dataset Consumption records in force with no Covering Permitted Use.",
             [("14", "Dataset Consumption", "Covering Permitted Use")]),
            ("Feed Freshness Flag", "Y when the latest Load with Load Status = Received has a Business Date older than the feed's Delivery Frequency allows.",
             [("06", "Load", "Load Status"), ("06", "Data Feed", "Delivery Frequency"),
              ("06", "Load", "Business Date"), ("06", "Load", "Feed")]),
            ("DQ Rule Pass Rate", "DQ Rules with DQ Result % >= DQ Threshold % / DQ Rules evaluated, rolled up to each dependent data product.",
             [("21", "Data Quality Rule", "DQ Threshold %"), ("21", "Data Quality Result", "DQ Result %")]),
            ("Unmapped Source Values", "Code Mappings with Mapping Status not approved, by source system and target code list.",
             [("09", "Code Mapping", "Target Code List"), ("09", "Code Mapping", "Mapping Status"),
              ("09", "Code Mapping", "Source System"), ("09", "Code Mapping", "Target Code")]),
            ("Downstream Impact Count", "Count of data products and consuming applications reachable from a catalog entry through lineage edges.",
             [("14", "Dataset Consumption", "Consumed Dataset"),
              ("14", "Dataset Consumption", "Consuming Application"),
              ("14", "Consuming Application", "Consuming Application ID"), ("06", "Data Feed", "Feed ID"),
              ("09", "Code List Consumer", "Consuming Domain")]),
            ("Uncataloged Marketing Source Count", "Distinct Source System values on Code Mappings, or source systems named in Data Domain 04 data, that match no Marketing System System Name, for marketing-owned code lists.",
             [("09", "Code Mapping", "Source System"), ("04", "Marketing System", "System Name")]),
        ],
        inputs=[
            ("09", "Code List", ["Code List ID", "Code List Name", "Code List Definition", "Source Standard",
                                 "Owning Business Domain", "Data Owner", "Data Steward", "Registration Status",
                                 "Current Version"]),
            ("09", "Code List Consumer", ["Consuming Domain", "Consuming Attribute", "Usage Type"]),
            ("09", "Code List Version", ["Code List Version ID", "Version Effective From", "Change Summary"]),
            ("09", "Code Mapping", ["Code Mapping ID", "Source System", "Source Value", "Target Code List", "Target Code",
                                    "Mapping Status"]),
            ("09", "Reference Data Subscription", ["Reference Data Set", "Subscribing System", "Distribution Method"]),
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Subject Area", "Data Basis",
                               "Contains Personal Data Indicator", "Information Sensitivity", "Dataset Status",
                               "Dataset Business Owner"]),
            ("14", "Dataset Key Field", ["Field Name", "Field Business Definition", "Identifier Scheme", "Match Target Concept"]),
            ("14", "Dataset Delivery", ["Delivery Method", "Delivery Format", "Technical Feed"]),
            ("14", "Dataset Consumption", ["Consumed Dataset", "Consuming Business Domain", "Consuming Application",
                                           "Target Concept", "Use Case", "Covering Permitted Use",
                                           "Authoritative Source Indicator", "Consumption Effective From",
                                           "Consumption Effective To"]),
            ("14", "Consuming Application", ["Consuming Application ID", "Application Name", "Usage Mode",
                                             "External Output Indicator"]),
            ("06", "Data Feed", ["Feed ID", "Feed Name", "Data Provider", "Feed Type", "Data Content", "Delivery Frequency",
                                 "Feed Grain", "License Use Restriction", "Feed Status", "Source Precedence Rank"]),
            ("06", "Load", ["Load ID", "Feed", "Business Date", "Load Status"]),
            ("06", "Measure Definition", ["Measure ID", "Measure Name", "Business Definition", "Calculation Formula",
                                          "Certified Indicator"]),
            ("21", "Data Quality Rule", ["DQ Rule ID", "DQ Rule Description", "DQ Dimension", "DQ Threshold %"]),
            ("21", "Data Quality Result", ["DQ Result ID", "Tested DQ Rule", "DQ Execution Timestamp", "DQ Result %"]),
            ("04", "Marketing System", ["System Name", "System Category"]),
        ],
        upstream=["DP-013", "DP-101"],   # the distribution view of DP-101 Governance Metadata & Enterprise Catalog, Wave E1 (CD-301)
        refresh="Daily",
        timeliness="By 7am ET each business day; a change to a data product specification or to the taxonomy is reflected by the next daily build",
        history="Every catalog entry and lineage edge kept as SCD type 2 indefinitely, so the lineage of any product version on any past date can be shown",
        classification="Internal",
        pii="N",
        delivery=["Warehouse table", "API", "Dashboard"],
        dq_rules=[
            "Every data product in the register has exactly one owner, a tier, a type, an owning Data Domain and a specification whose inputs all resolve to current taxonomy objects and attributes.",
            "The upstream graph of data products has no cycles, and no foundational product depends on a consumer-aligned product.",
            "Every active Data Feed with a Technical Feed link from a Dataset Delivery resolves to an active Dataset, and every active Dataset has a Dataset Business Owner.",
            "Every Code List with Registration Status = registered has a Data Owner and a Current Version that exists in Code List Version.",
            "Every lineage edge points to catalog entries that exist and are in force on the edge's effective dates.",
            "Every Marketing System has a unique System Name and a System Category, and every marketing system used as a lineage source appears in the catalog.",
        ],
        notes=("Foundational product: it builds only on DP-013 (code lists and enterprise reference) and on the taxonomy and data "
               "product register themselves, so that every other product can be cataloged without circular dependencies. Owner "
               "fields hold roles, not named individuals, so PII = N. The data product register, specifications and the "
               "taxonomy's L3 and L4 identifiers are loaded from the program's own model (framework and specs) rather than from "
               "a Data Domain. Health metrics are summarized here only for discovery; operational data quality monitoring "
               "belongs to DP-045. Third-party license compliance belongs to DP-044. "
               "Marketing System (04) catalogs the marketing application estate and is used as the source-system entry for "
               "marketing lineage; it has no identifier attribute, so System Name is the catalog key. "
               "Taxonomy gap: there are no objects for data product, data product input, data product certification, "
               "non-marketing source systems or lineage edge in any Data Domain; these are held in the catalog's own model until a metadata family is "
               "added to Data Domain 09. Taxonomy gap: source-system mapping to taxonomy attributes is a Phase D task, so "
               "attribute-level lineage below the data feed is incomplete until that work is done. "
               "W4 re-point (06 review): Load Completeness Status is merged into Load Status (Expected, Received Late, Partial "
               "and Missing added). 04 Marketing System is kept by name in its new family (CW-904).")
    ),
}
