"""Data product specifications: Wave 4 products for 15 Account and 16 Retirement Plan Administration.
DP-093 Account Master (re-specified at WP1 in specs_w1f_client.py), DP-094 Recordkept Plan & Participant Core, DP-095 (re-specified in specs_w1c_bwo.py) Plan Contribution, Loan & Distribution Operations
and DP-096 (re-specified in specs_w1c_bwo.py) Plan Compliance Testing & Filing Status. See CONTRACT.md."""

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    # DP-093 re-specified at WP1 in specs_w1f_client.py
    # ------------------------------------------------------------------------------------------------------------------
    "DP-094": dict(
        definition=("The conformed master of the plans the firm recordkeeps and the participants in them: the current plan "
                    "document and its amendments and provisions (plan type and plan year, eligibility, deferral and automatic "
                    "features, employer contribution formulas, vesting schedules, withdrawal, forfeiture and loan provisions), "
                    "fiduciary and service role assignments, the recordkeeping service arrangement and fee schedule, the plan "
                    "investment menu and fund changes, each participant's plan membership, employment events, deferral and "
                    "investment elections, vesting service and vested balances, and plan conversions. It keys every plan to the "
                    "conformed Retirement Plan (DP-003) and every participant to the conformed Account (DP-093), so that "
                    "operations, compliance and DCIO products read one plan and participant record."),
        business_questions=[
            "Which plans do we recordkeep today, under which program and agreement, with which plan type, plan year end, safe harbor design and automatic enrollment features?",
            "Who are the named fiduciaries, trustees, 3(16) administrators and 3(38) managers of each plan, and which plans have a fiduciary role unfilled?",
            "How many eligible and active participants does each plan have, what share are deferring, at what average rate, and how many sit in the default investment?",
            "Which share classes are on each plan menu and in which role (core, QDIA, target date, model), and which fund changes are mapping assets this quarter?",
            "Which participants are fully vested, which have a beneficiary designation on file, and which conversions are in blackout or awaiting reconciliation?",
        ],
        grain="Participant plan membership x effective period (SCD type 2 version), with the recordkept plan (plan document, provisions, roles, service arrangement, investment menu) as a conformed parent keyed on Sponsor EIN + Plan Number",
        dimensions=["Retirement plan (Sponsor EIN + Plan Number)", "Plan sponsor", "Administered plan type and ERISA coverage", "Plan year end",
                    "Recordkeeping program and payroll integration type", "Plan role type and fiduciary indicator", "Investment option and menu role",
                    "Share class", "Participant", "Participant account", "Membership status", "Enrollment method", "Employer money source",
                    "Conversion type and status", "Effective date"],
        measures=[
            ("Active Recordkept Plans", "Count of distinct Administered Plan with a Plan Document with Document Status = active on the as-of date and a Service Arrangement with Arrangement Status = active, by Administered Plan Type and Recordkeeping Program.",
             [("16", "Plan Document", "Administered Plan"), ("16", "Plan Document", "Document Status"),
              ("16", "Service Arrangement", "Arrangement Plan"), ("16", "Service Arrangement", "Arrangement Status"),
              ("16", "Service Arrangement", "Recordkeeping Program"), ("16", "Plan Type Detail", "Administered Plan Type")]),
            ("Active Participants", "Count of Participant Plan Membership rows with Membership Status = active on the as-of date, by Membership Plan.",
             [("16", "Participant Plan Membership", "Membership Status"), ("16", "Participant Plan Membership", "Membership Plan"),
              ("16", "Participant Plan Membership", "Membership ID")]),
            ("Eligible Not Enrolled", "Count of memberships with Eligibility Date on or before the as-of date, no Plan Entry Date and Membership Status not terminated.",
             [("16", "Participant Plan Membership", "Eligibility Date"), ("16", "Participant Plan Membership", "Plan Entry Date"),
              ("16", "Participant Plan Membership", "Membership Status")]),
            ("Participation Rate %", "Active Participants with a Deferral Election effective on the as-of date whose Pre-Tax Deferral Percentage + Roth Deferral Percentage > 0 / Active Participants, by plan.",
             [("16", "Deferral Election", "Election Membership"), ("16", "Deferral Election", "Pre-Tax Deferral Percentage"),
              ("16", "Deferral Election", "Roth Deferral Percentage"), ("16", "Deferral Election", "Deferral Election Effective From"),
              ("16", "Deferral Election", "Deferral Election Effective To"), "Active Participants"]),
            ("Average Deferral Rate %", "Mean of Pre-Tax Deferral Percentage + Roth Deferral Percentage over deferring active participants on the as-of date, by plan and Election Source.",
             [("16", "Deferral Election", "Pre-Tax Deferral Percentage"), ("16", "Deferral Election", "Roth Deferral Percentage"),
              ("16", "Deferral Election", "Election Source"), "Participation Rate %"]),
            ("Default Investment Share %", "Active participants whose Investment Election rows effective on the as-of date all have Default Election Indicator = Y / Active Participants, by plan.",
             [("16", "Investment Election", "Investment Election Membership"), ("16", "Investment Election", "Default Election Indicator"),
              ("16", "Investment Election", "Investment Election Effective From"), ("16", "Investment Election", "Investment Election Effective To"),
              "Active Participants"]),
            ("Investment Election Allocation Check", "Sum of Allocation Percentage over a membership's Investment Election rows effective on the as-of date; flagged when not equal to 100% or when an Elected Investment Option has Option Status not active.",
             [("16", "Investment Election", "Allocation Percentage"), ("16", "Investment Election", "Elected Investment Option"),
              ("16", "Plan Investment Option", "Investment Option ID"), ("16", "Plan Investment Option", "Option Status")]),
            ("Menu Options", "Count of Plan Investment Option rows with Option Status = active per Menu Plan, by Menu Role and Offered Share Class.",
             [("16", "Plan Investment Option", "Menu Plan"), ("16", "Plan Investment Option", "Option Status"),
              ("16", "Plan Investment Option", "Menu Role"), ("16", "Plan Investment Option", "Offered Share Class")]),
            ("Fiduciary Role Completeness %", "Active recordkept plans with an open Plan Role Assignment with Fiduciary Indicator = Y for each Plan Role Type the plan document requires (at least named fiduciary and trustee) / Active Recordkept Plans.",
             [("16", "Plan Role Assignment", "Role Plan"), ("16", "Plan Role Assignment", "Plan Role Type"),
              ("16", "Plan Role Assignment", "Fiduciary Indicator"), ("16", "Plan Role Assignment", "Role Effective From"),
              ("16", "Plan Role Assignment", "Role Effective To"), "Active Recordkept Plans"]),
            ("Beneficiary Designation on File %", "Active participants whose Beneficiary Designation on File resolves to a Beneficiary Designation with no Designation Effective To / Active Participants.",
             [("16", "Participant Plan Membership", "Beneficiary Designation on File"),
              ("15", "Beneficiary Designation", "Beneficiary Designation ID"), ("15", "Beneficiary Designation", "Designation Effective To"),
              "Active Participants"]),
            ("Fully Vested Share %", "Active participants whose latest Vested Balance by Source row per Vested Contribution Source has Vested Percentage = 100 / Active Participants; Total Years of Vesting Service shown alongside.",
             [("16", "Vested Balance by Source", "Vested Balance Membership"), ("16", "Vested Balance by Source", "Vested Contribution Source"),
              ("16", "Vested Balance by Source", "Vested Percentage"), ("16", "Vested Balance by Source", "Vested Balance As-Of Date"),
              ("16", "Vesting Service Record", "Total Years of Vesting Service"), "Active Participants"]),
            ("Open Conversions", "Count of Plan Conversion rows with Conversion Status not Live or cancelled, by Conversion Type; Blackout Notice Gap Flag = Y when Blackout Period Start is within 30 days and Blackout Notice Sent Date is null.",
             [("16", "Plan Conversion", "Conversion Status"), ("16", "Plan Conversion", "Conversion Type"),
              ("16", "Plan Conversion", "Blackout Period Start"), ("16", "Plan Conversion", "Blackout Notice Sent Date")]),
        ],
        inputs=[
            ("16", "Plan Document", ["Plan Document ID", "Administered Plan", "Document Type", "Document Effective Date", "Document Status"]),
            ("16", "Plan Amendment", ["Amendment ID", "Amended Plan Document", "Amendment Type", "Amendment Effective Date"]),
            ("16", "Plan Type Detail", ["Administered Plan Type", "ERISA Covered Indicator", "Safe Harbor Design", "Plan Year End"]),
            ("16", "Eligibility Provisions", ["Minimum Age Requirement", "Service Requirement Months", "Entry Date Frequency",
                                              "Long-Term Part-Time Eligibility Applied Indicator"]),
            ("16", "Deferral & Automatic Features", ["Automatic Enrollment Type", "Default Deferral Rate", "Automatic Escalation Increment",
                                                     "Catch-Up Contributions Permitted Indicator", "Roth Catch-Up Required Indicator"]),
            ("16", "Employer Contribution Formula", ["Formula Contribution Source", "Formula Type", "Formula Description", "Formula Effective From",
                                                     "Formula Effective To"]),
            ("16", "Vesting Schedule", ["Vesting Contribution Source", "Vesting Schedule Type", "Vesting Computation Method",
                                        "Vesting Schedule Effective From"]),
            ("16", "Withdrawal & Forfeiture Provisions", ["Hardship Withdrawals Permitted Indicator", "Hardship Self-Certification Permitted Indicator",
                                                          "Mandatory Cash-Out Threshold", "Forfeiture Use Permitted"]),
            ("16", "SIMPLE IRA & SEP Program Detail", ["IRS Model Program Form", "SIMPLE Employer Contribution Election", "Annual Notice Delivered Date"]),
            ("16", "Plan Loan Provisions", ["Loans Permitted Indicator", "Maximum Outstanding Loans", "Maximum General Loan Term Months"]),
            ("16", "Plan Role Assignment", ["Plan Role ID", "Role Plan", "Role Party", "Plan Role Type", "Fiduciary Indicator", "Role Effective From",
                                            "Role Effective To"]),
            ("16", "Service Arrangement", ["Service Arrangement ID", "Arrangement Plan", "Recordkeeping Program", "Governing Agreement",
                                           "Payroll Integration Type", "Arrangement Effective From", "Arrangement Status"]),
            ("16", "Plan Fee Schedule", ["Plan Fee Line ID", "Fee Service Arrangement", "Fee Component", "Fee Amount", "Fee Rate", "Fee Payer", "Fee Effective From"]),
            ("16", "Plan Investment Option", ["Investment Option ID", "Menu Plan", "Offered Share Class", "Menu Role", "Model Portfolio",
                                              "Option Added Date", "Option Status"]),
            ("16", "Fund Change Event", ["Fund Change ID", "Change Plan", "Fund Change Type", "From Investment Option", "To Investment Option",
                                         "Mapping Effective Date", "Mapping Transactions"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant", "Membership Plan", "Participant Account", "Membership Status",
                                                   "Membership Status Effective From", "Eligibility Date", "Plan Entry Date", "Enrollment Method",
                                                   "Automatic Enrollment Opt-Out Date", "Beneficiary Designation on File",
                                                   "Spousal Consent on File Indicator", "Highly Compensated Employee Indicator"]),
            ("16", "Employment Event", ["Event Membership", "Employment Event Type", "Employment Event Date", "Payroll Employee ID"]),
            ("16", "Deferral Election", ["Deferral Election ID", "Election Membership", "Pre-Tax Deferral Percentage", "Roth Deferral Percentage",
                                         "Catch-Up Election Type", "Election Source", "Deferral Election Effective From",
                                         "Deferral Election Effective To"]),
            ("16", "Investment Election", ["Investment Election Membership", "Elected Investment Option", "Allocation Percentage",
                                           "Default Election Indicator", "Automatic Rebalancing Frequency", "Investment Election Effective From",
                                           "Investment Election Effective To"]),
            ("16", "Vesting Service Record", ["Vesting Membership", "Vesting Plan Year", "Hours of Service Credited",
                                              "Year of Vesting Service Credited Indicator", "Total Years of Vesting Service"]),
            ("16", "Vested Balance by Source", ["Vested Balance Membership", "Vested Contribution Source", "Vested Percentage", "Vesting Basis",
                                                "Vested Balance As-Of Date", "Source Participant Balance"]),
            ("16", "Plan Conversion", ["Conversion ID", "Converted Plan", "Conversion Type", "Counterparty Recordkeeper", "Blackout Period Start",
                                       "Blackout Period End", "Blackout Notice Sent Date", "Asset Transfer Date", "Record Reconciliation Status",
                                       "Investment Mapping Event", "Conversion Status"]),
            ("02", "Retirement Plan", ["Plan Sponsor", "Sponsor EIN", "Plan Number", "Plan Name", "Plan Type"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Plan Participant Account", ["Participant", "Retirement Plan", "Plan Account", "Money Sources Held"]),
            ("15", "Beneficiary Designation", ["Beneficiary Designation ID", "Designated Account", "Designation Effective From",
                                               "Designation Effective To"]),
            ("01", "Share Class", ["Share Class ID", "Share Class Status"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name"]),
        ],
        upstream=["DP-003", "DP-093", "DP-001", "DP-004", "DP-213", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET on T+1 for recordkeeping system changes of the prior business day; plan document and amendment versions within two business days of execution",
        history="SCD type 2 on membership, elections, roles, menu and provisions since plan conversion to the firm; plan document versions and amendments kept for the life of the plan plus seven years; vesting records kept by plan year",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "API"],
        dq_rules=[
            "Every Administered Plan, Role Plan, Arrangement Plan, Menu Plan, Change Plan, Membership Plan and Converted Plan resolves to a Retirement Plan (Sponsor EIN + Plan Number) in DP-003, and each active plan has exactly one Plan Document with Document Status = active and at most one Service Arrangement with Arrangement Status = active.",
            "Every Participant Account resolves to an Account in DP-093 with Account Type = Participant Account whose Plan Participant Account Retirement Plan equals the Membership Plan, and every Participant and Role Party resolves to an active 02 Party.",
            "Pre-Tax Deferral Percentage and Roth Deferral Percentage are between 0 and 100, and a membership has at most one Deferral Election effective on any date.",
            "Allocation Percentage over a membership's Investment Election rows effective on any date sums to 100%, and every Elected Investment Option resolves to a Plan Investment Option of the Membership Plan.",
            "Every Offered Share Class resolves to a Share Class in DP-004 with Share Class Status not closed on Option Added Date, and every Fund Change Event with a Mapping Effective Date on or before the as-of date has From Investment Option and To Investment Option on the same plan.",
            "Vested Percentage is between 0 and 100, equals 100 when Vesting Basis is a full vesting event, and every Vested Contribution Source has a Vesting Schedule on the plan document effective on the Vested Balance As-Of Date.",
        ],
        notes=("Participants, their deferral rates, payroll IDs, compensation status and vested balances are personal data "
               "(classification Restricted - Personal Data, PII = Y); a plan-level view with participant counts and rates but no "
               "membership rows is published for DCIO use (DP-024); publication through the BI semantic model was proposed for "
               "SM-04 and not approved (SM-04 retired at WP2, CW-209; DP-094 is bound to no semantic model). Boundary: the Retirement Plan "
               "itself (sponsor, EIN, plan number, Form 5500 attributes) stays mastered in 02 and published by DP-003; this "
               "product reads the plan identity only and adds what the firm knows as recordkeeper. The participant account is "
               "the DP-093 Account; Plan Participant Account is read here for the participant's account status and money "
               "sources. Plan Loan Provisions sit with the plan document here; loans themselves are in DP-095. Plan Notice is "
               "published by DP-096 as a compliance obligation. Plan Termination is published by DP-096 because its deadlines "
               "and final filing are compliance-tracked. Vesting Service Record and Vested Balance by Source are here as "
               "participant status; Forfeiture Record is a money movement and is in DP-095. "
               "Taxonomy gap: Plan Role Assignment carries no attribute saying which roles a plan document requires, so "
               "Fiduciary Role Completeness % uses a fixed minimum set (named fiduciary and trustee). Taxonomy gap: there is no "
               "participant compensation or hours-based eligibility measure at membership level other than Plan Compensation for "
               "Period on contributions and Hours of Service Credited on vesting records, so eligibility is taken as the "
               "recordkeeper's Eligibility Date. "
               "W3 re-point (CW-125, CW-127; proposals_w3_16.py NOTES): Vested Balance by Source Source Position is renamed "
               "Source Participant Balance and resolves inside 16 (Participant Balance, the participant book of record), no "
               "longer to DP-007; Plan Fee Schedule is keyed by Plan Fee Line ID (PFEE-); Service Arrangement Governing "
               "Agreement now references 39 Contract (published by DP-213, which replaces DP-005 upstream), and Fund Change Event Mapping Transactions the 16 "
               "Participant Ledger Posting; 15 Plan Participant Account status, enrollment and default-investment facts are "
               "Derived copies of 16, read here unchanged. WP0: publish 16 Participant Balance and the moved Recordkeeper "
               "Profile and Plan Service Provider."
               "WP1 re-point (CW-204): DP-093 no longer publishes the 15 Plan Participant Account derived copies of 16 (Participant Account Status, Default Investment Indicator, Terminated Participant Indicator); no measure or rule here read them, and the participant status is read from its 16 master, Participant Plan Membership Membership Status, which this product already reads, so the three copies leave the 15 input. Money Sources Held (mastered in 15) stays."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    # DP-095 re-specified at WP1 in specs_w1c_bwo.py
    # ------------------------------------------------------------------------------------------------------------------
    # DP-096 re-specified at WP1 in specs_w1c_bwo.py
}
