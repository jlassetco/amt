"""Wave WP1C (consumer), area BWO (Brokerage, Cash & Workplace), agent C-3: attribute-level specifications of the
wealth-manager rework (Wealth_Manager_Rework_Plan.md sections 8.3 and 10; 00_Program/Rework/Product_Briefs/WP1_Method.md
section 5; WP1_Scope.md section 6).

Products, in specification order:
- DP-445 Customer Reserve & Possession-and-Control Control Pack (49 Clearing, Settlement & Client Asset Custody)
- DP-456 Fraud & Elder-Exploitation Holds (50 Money Movement, Cash & Sweep)
- DP-435 Order Lifecycle & CAT Completeness (48 Brokerage Orders & Execution)
- DP-436 Execution Quality & Routing (605/606) (48)
- DP-437 Trade Corrections & Errors (48)
- DP-438 Trade Confirmations & Regulatory Trade Reporting (48)
- DP-446 Stock Record Reconciliation & Security Counts (49)
- DP-447 Client Settlement & Fails (49)
- DP-448 ACATS In and Out (49)
- DP-452 Client Corporate Action Entitlements & Elections (49)
- DP-457 Cash Sweep & Program Bank Allocation (50)
- DP-459 Debit Card, Checkwriting & Regulation E Disputes (50)
- DP-460 Money Movement AML Monitoring & Payment Sanctions Screening (50)
- DP-466 Participant Outcomes (16 Retirement Plan Administration)
- DP-467 Rollover Capture (16)
- re-scoped in place (CW-233): DP-095 Plan Contribution, Loan & Distribution Operations (16; supporting FN-71 and
  FN-66) and DP-096 Plan Compliance Testing & Filing Status (16; supporting FN-44 and FN-71); the hold-back is lifted
  and their wholesale specs have been deleted from specs_q_accounts_plans.py.

Not specified (backlog per WP1_Scope.md section 5): DP-462 (merge target DP-392) and DP-468 (merge target DP-466, which
takes its two 16 reads).

WP1 decisions applied: consumers read the books and facts through the WP1F foundations (DP-300, DP-301, DP-302, DP-430,
DP-580) and the masters through DP-093, DP-094, DP-240, DP-431 and DP-432, and read a 48, 49, 50 or 16 object directly
only where no foundation publishes it (WP1F F3 rulings); certified numbers are read from DP-008 and DP-145 and never
recomputed (CW-011, CW-142, CW-230); the Rule 15c3-3 reserve computation is published once, by DP-445, and corporate
products read it (CW-103, CW-262); special-category facts reach these products only through DP-322, with DP-456 the one
restricted view over the special-category Money Movement Hold rows (CW-213, CW-231, CD-344); cash-movement holds are
DP-456's, the protection register DP-322's and holds on registered shares FOP+CORP DP-583's (CW-264); self-clearing is
the reference operating model (CW-235). See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


_MV = ("Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot")

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-445": dict(
        definition=("The broker-dealer's daily SEC Rule 15c3-3 control pack: the approved customer and PAB reserve "
                    "computations with every Exhibit A formula line, the reserve requirement against the deposit on hand "
                    "and the deposit or withdrawal due by its deadline, and the possession-or-control determination of "
                    "every security with each deficit by source, age and action deadline. It reads the 49 Reserve "
                    "Computation and Possession or Control Determination directly, because the books product DP-300 "
                    "publishes only their inputs (free credit balances, margin debits, segregated quantities), and it "
                    "proves those inputs and the 43 net capital copy of aggregate debit items against the computation. "
                    "It is the one published source of the reserve requirement: corporate products read it and never "
                    "recompute it (CW-262). It owns no certified metric family."),
        business_questions=[
            "What is today's customer reserve requirement and PAB reserve requirement, what is on deposit in the reserve bank accounts, and what deposit or withdrawal is due by when (acceptance question 6)?",
            "Which client securities are out of possession or control today, in what quantity and value, from which deficit source, and which deficits are past their action deadline (acceptance question 6)?",
            "Do the Exhibit A credit and debit lines add up to the computation totals, and do free credit balances and margin debit balances in the client books tie to Exhibit A items 1 and 10?",
            "Does the aggregate debit items amount that net capital uses equal the approved customer computation?",
            "Is each broker-dealer computing at the frequency its average total credits require, and was every computation approved before its deposit deadline?",
        ],
        grain=("Computing broker-dealer x computation date x Reserve Computation Type (Customer, PAB) for the reserve "
               "computation, with its Exhibit A lines (computation x formula item) as companion rows, and instrument x "
               "business date x deficit source for the possession-or-control determination; daily, append-only "
               "versions of each approved computation"),
        dimensions=["Computing broker-dealer (DP-013)", "Reserve Computation Type (Customer, PAB)", "Computation date and frequency (DP-013)",
                    "Exhibit A formula item", "Supporting cash balance type", "Instrument (DP-097)", "Deficit source",
                    "Deficit age bucket", "Control location party (DP-240) and control location type", "Reserve bank account (43)",
                    "Computation approval status"],
        measures=[
            ("Customer Reserve Requirement", "Reserve Requirement Amount of the Reserve Computation with Reserve Computation Type = Customer and Computation Approval Status = Approved for the latest Computation Date, by Computing Broker-Dealer; the one published reserve requirement (SEC Rule 15c3-3(e) and Exhibit A), read by DP-600 and DP-205 and never recomputed there (CW-262).",
             _u("49", "Reserve Computation", "Reserve Computation ID", "Computing Broker-Dealer", "Reserve Computation Type", "Computation Date", "Reserve Requirement Amount", "Computation Approval Status")),
            ("PAB Reserve Requirement", "Reserve Requirement Amount of the approved Reserve Computation with Reserve Computation Type = PAB for the latest Computation Date, by Computing Broker-Dealer (SEC Rule 15c3-3(e)(1) PAB account computation); usually zero under the reference default.",
             _u("49", "Reserve Computation", "Reserve Computation Type", "Computation Date", "Reserve Requirement Amount", "Computation Approval Status")),
            ("Reserve Deposit on Hand", "Reserve Deposit on Hand of the approved computation of each Reserve Computation Type, with the Reserve Bank Accounts it is held in. A 43 Corporate Bank Account counts as a reserve bank account only by being named in the computation's Reserve Bank Accounts reference (the 49 designation), with Bank Account Status active; Bank Account Purpose has no special-reserve value and is not used to select them.",
             _u("49", "Reserve Computation", "Reserve Deposit on Hand", "Reserve Bank Accounts", "Reserve Computation Type") + _u("43", "Corporate Bank Account", "Corporate Bank Account ID", "Account Holder Entity", "Bank Account Status")),
            ("Required Reserve Deposit or Withdrawal", "Deposit or Withdrawal Amount of the approved computation (positive: deposit due; negative: withdrawal permitted) with its Deposit Deadline Timestamp, by Computing Broker-Dealer and Reserve Computation Type.",
             _u("49", "Reserve Computation", "Deposit or Withdrawal Amount", "Deposit Deadline Timestamp", "Computing Broker-Dealer", "Reserve Computation Type")),
            ("Reserve Excess or Deficiency", "Reserve Deposit on Hand - Reserve Requirement Amount of the same approved computation; a negative value is a deficiency that the Required Reserve Deposit or Withdrawal must cure by the Deposit Deadline Timestamp.",
             _u("49", "Reserve Computation", "Reserve Deposit on Hand", "Reserve Requirement Amount") + ["Customer Reserve Requirement", "PAB Reserve Requirement"]),
            ("Deposits Not Evidenced by Next Computation", "Count of approved computations with Deposit or Withdrawal Amount > 0 where the next approved computation of the same Computing Broker-Dealer and Reserve Computation Type shows Reserve Deposit on Hand below the prior Reserve Requirement Amount: a deposit that may not have been made by the deadline.",
             _u("49", "Reserve Computation", "Deposit or Withdrawal Amount", "Reserve Deposit on Hand", "Reserve Requirement Amount", "Computation Date") + ["Required Reserve Deposit or Withdrawal"]),
            ("Computations Not Approved Before Deadline", "Count of Reserve Computation rows whose Computation Approval Status is not Approved when the Deposit Deadline Timestamp passes, by Computing Broker-Dealer and Reserve Computation Type.",
             _u("49", "Reserve Computation", "Computation Approval Status", "Deposit Deadline Timestamp", "Computing Broker-Dealer", "Reserve Computation Type")),
            ("Exhibit A Line Totals", "Sum of Line Amount of Reserve Computation Line rows by Exhibit A Formula Item (CREDIT-01 to CREDIT-09, DEBIT-10 to DEBIT-15) for each approved computation, keyed by Line Reserve Computation.",
             _u("49", "Reserve Computation Line", "Line Reserve Computation", "Exhibit A Formula Item", "Line Amount")),
            ("Exhibit A Tie-Out Breaks", "Count of approved computations where the sum of the CREDIT lines differs from Total Credits, or the sum of the DEBIT lines (Aggregate Debit Items Amount) reduced by Debit Items Reduction Percentage differs from Total Debits, or Reserve Requirement Amount differs from the greater of zero and Total Credits - Total Debits, by more than USD 1.",
             _u("49", "Reserve Computation", "Total Credits", "Total Debits", "Aggregate Debit Items Amount", "Debit Items Reduction Percentage", "Reserve Requirement Amount") + ["Exhibit A Line Totals"]),
            ("Free Credit Balances to Exhibit A Item 1 Difference", "Sum of Cash Balance Amount of 49 Account Cash Balance rows with Cash Balance Type = Free Credit Balance and Balance Basis = Settlement Date on the Cash Balance Business Date equal to the Computation Date (read from DP-300, aggregated, never published by account) minus the Line Amount of the customer computation's line whose Supporting Cash Balance Type = Free Credit Balance.",
             _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Type", "Balance Basis", "Cash Balance Business Date", "Cash Balance Amount", "Cash Balance Currency") + _u("49", "Reserve Computation Line", "Supporting Cash Balance Type") + ["Exhibit A Line Totals"]),
            ("Margin Debits to Exhibit A Item 10 Difference", "Sum of Cash Balance Amount with Cash Balance Type = Margin Debit Balance and Balance Basis = Settlement Date on the Computation Date (from DP-300; the 49 Account Cash Balance is used rather than the Margin Balance Snapshot behind DP-300 Margin Debit Balances because Exhibit A item 10 covers debits in cash as well as margin accounts and is computed on the settlement-date cash book) minus the Line Amount of the line whose Supporting Cash Balance Type = Margin Debit Balance (Exhibit A item 10).",
             _u("49", "Account Cash Balance", "Cash Balance Type", "Cash Balance Amount", "Balance Basis", "Cash Balance Business Date") + _u("49", "Reserve Computation Line", "Supporting Cash Balance Type") + ["Exhibit A Line Totals"]),
            ("Aggregate Debit Items Tie to Net Capital", "43 Capital Requirement Calculation.Aggregate Debit Items Amount of the approved calculation whose Reserve Computation names this customer computation (same Calculation Entity and Calculation As-Of Date) minus the 49 Aggregate Debit Items Amount; must be zero, because 43 carries a Derived copy (CW-103) and computes net capital from it (SEC Rule 15c3-1 alternative standard).",
             _u("43", "Capital Requirement Calculation", "Capital Calculation ID", "Calculation Entity", "Calculation As-Of Date", "Aggregate Debit Items Amount", "Reserve Computation", "Calculation Approval Status") + _u("49", "Reserve Computation", "Aggregate Debit Items Amount")),
            ("Daily Computation Required", "Flag per Computing Broker-Dealer: Average Total Credits (customer plus PAB, the twelve month-end average) at or above USD 250 million requires Reserve Computation Frequency = Daily (SEC Rule 15c3-3(e)(3)(i)); a computing broker-dealer above the threshold with a Weekly frequency is an exception.",
             _u("49", "Reserve Computation", "Average Total Credits", "Reserve Computation Frequency", "Computing Broker-Dealer")),
            ("Securities Out of Possession or Control", "Count of distinct Determination Instrument and sum of Possession or Control Deficit Quantity of Possession or Control Determination rows with Deficit Source other than No Deficit on the Determination Business Date, by Deficit Source (SEC Rule 15c3-3(d) and (h)).",
             _u("49", "Possession or Control Determination", "Determination Instrument", "Determination Business Date", "Possession or Control Deficit Quantity", "Deficit Source")),
            ("Possession or Control Deficit Market Value", "Possession or Control Deficit Quantity x the instrument's unit value on the business date, taken on one quantity basis: the sum of Market Value in USD over the sum of Trade-Date Quantity of the End of Day 49 Client Holding rows in that Held Instrument (from DP-300; Market Value is trade-date quantity x price), by Deficit Source.",
             _u("49", "Client Holding", "Held Instrument", "Client Holding Date", "Client Holding View", "Trade-Date Quantity") + _u("49", "Client Holding Valuation", "Market Value in USD") + ["Securities Out of Possession or Control"]),
            ("Deficits Past Action Deadline", "Securities Out of Possession or Control whose Action Deadline Date is before the Determination Business Date, with Deficit Age Days, by Deficit Source and age bucket (0 to 5, 6 to 30, 31 to 45, over 45 days).",
             _u("49", "Possession or Control Determination", "Action Deadline Date", "Deficit Age Days", "Deficit Source") + ["Securities Out of Possession or Control"]),
            ("Determination Arithmetic Breaks", "Count of Possession or Control Determination rows where Fully Paid Quantity Required + Excess Margin Quantity Required - Quantity at Good Control Locations, floored at zero, differs from the total Possession or Control Deficit Quantity of the instrument and date.",
             _u("49", "Possession or Control Determination", "Fully Paid Quantity Required", "Excess Margin Quantity Required", "Quantity at Good Control Locations", "Possession or Control Deficit Quantity")),
            ("Segregated Quantity Below Requirement", "Count of instruments whose sum of Segregated Quantity on End of Day 49 Client Holding rows (from DP-300) is below Fully Paid Quantity Required + Excess Margin Quantity Required of the determination for the same date, by more than 0.0001 shares.",
             _u("49", "Client Holding", "Segregated Quantity", "Held Instrument", "Client Holding Date") + _u("49", "Possession or Control Determination", "Fully Paid Quantity Required", "Excess Margin Quantity Required", "Determination Instrument")),
            ("Determinations Counting Unapproved Locations", "Count of determinations whose Control Locations Counted includes a Control Location without Control Location Approval Status = Approved, or outside Location Effective From to Location Effective To, on the Determination Business Date; quantity there is not good control.",
             _u("49", "Possession or Control Determination", "Control Locations Counted", "Determination Business Date") + _u("49", "Control Location", "Control Location Party", "Control Location Type", "Control Location Approval Status", "Location Effective From", "Location Effective To")),
        ],
        inputs=[
            ("49", "Reserve Computation", ["Reserve Computation ID", "Computing Broker-Dealer", "Reserve Computation Type", "Computation Date",
                                           "Reserve Computation Frequency", "Average Total Credits", "Total Credits", "Total Debits",
                                           "Aggregate Debit Items Amount", "Debit Items Reduction Percentage", "Reserve Requirement Amount",
                                           "Reserve Deposit on Hand", "Deposit or Withdrawal Amount", "Deposit Deadline Timestamp",
                                           "Reserve Bank Accounts", "Computation Approval Status"]),
            ("49", "Reserve Computation Line", ["Line Reserve Computation", "Exhibit A Formula Item", "Line Amount", "Supporting Cash Balance Type"]),
            ("49", "Possession or Control Determination", ["Determination Instrument", "Determination Business Date", "Fully Paid Quantity Required",
                                                           "Excess Margin Quantity Required", "Quantity at Good Control Locations",
                                                           "Control Locations Counted", "Possession or Control Deficit Quantity",
                                                           "Deficit Source", "Deficit Age Days", "Action Deadline Date"]),
            ("49", "Control Location", ["Control Location Party", "Control Location Type", "Location Country", "SEC Designation Reference",
                                        "Control Location Approval Status", "Location Effective From", "Location Effective To"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Currency", "Cash Balance Type", "Cash Balance Business Date",
                                            "Balance Basis", "Cash Balance Amount"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View",
                                      "Trade-Date Quantity", "Segregated Quantity"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("43", "Capital Requirement Calculation", ["Capital Calculation ID", "Calculation Entity", "Calculation As-Of Date",
                                                       "Aggregate Debit Items Amount", "Reserve Computation", "Calculation Approval Status"]),
            ("43", "Corporate Bank Account", ["Corporate Bank Account ID", "Account Holder Entity", "Bank Account Status"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Instrument Status"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
        ],
        upstream=["DP-300", "DP-097", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Approved computation by 10am ET on the business day after the Computation Date and in any case before its Deposit Deadline Timestamp; possession-or-control determinations by 9am ET each business day",
        history="Daily snapshots of every computation, its Exhibit A lines and every determination kept at least six years, the first two in an easily accessible place (SEC Rule 17a-4(b)); snapshots append-only, no deletion (the 49 computation itself has no version, see the taxonomy gap)",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API", "Regulatory report"],
        dq_rules=[
            "Every Computing Broker-Dealer and Calculation Entity resolves to an active DP-013 internal legal entity, every Determination Instrument to an active DP-097 instrument, every Control Location Party to a DP-240 party with Party Status active, and every Reserve Bank Accounts entry to a 43 Corporate Bank Account with Bank Account Status active.",
            "There is exactly one Reserve Computation row per Computing Broker-Dealer x Computation Date x Reserve Computation Type (the 49 key), and Control Location rows of one Control Location Party and Control Location Type do not overlap in effective period, with Location Effective To on or after Location Effective From.",
            "For every approved computation the CREDIT lines sum to Total Credits and the DEBIT lines to Aggregate Debit Items Amount within USD 1, Reserve Requirement Amount equals the greater of zero and Total Credits - Total Debits within USD 1, and the 43 Capital Requirement Calculation that references it carries the same Aggregate Debit Items Amount.",
            "Total Credits, Total Debits, Aggregate Debit Items Amount, Reserve Requirement Amount, Reserve Deposit on Hand, Deposit or Withdrawal Amount and Deposit Deadline Timestamp are populated on every approved computation, and Deficit Source and Possession or Control Deficit Quantity on every determination.",
            "No output row carries a Cash Balance Account, Holding Account or bank account number: 49 Account Cash Balance and Client Holding are aggregated to the computation date, formula item and instrument before publication.",
            "The approved customer and PAB computations of each Computation Date are published before their Deposit Deadline Timestamp, and every load is kept as a dated snapshot of the product, so a later change to an approved computation appears as a difference between snapshots and the snapshot that carried the prior figures is kept.",
        ],
        notes=("Certified numbers: none owned or read; the reserve requirement is a regulatory control figure, not a "
               "client-asset number. Operating model (CD-297, CD-331): self-clearing (reference default); the grain is the "
               "firm's own computation. Under fully disclosed clearing the clearing firm computes the reserve and the "
               "product is withdrawn (CW-235). PII tier: none. The dp_model warning is accepted: the validator flags 49 "
               "Reserve Computation, Possession or Control Determination and Control Location attributes because their Notes"
               " carry the tier line 'Object PII tier: No PII'; the account-level 49 Account Cash Balance and Client Holding"
               " attributes are read only to form aggregates (DQ5), Control Location Party is a depository, bank or clearing"
               " agency (an entity), and the reserve bank account number and the computation approver are not read, so pii ="
               " N. Boundaries: the computation is 49's and net capital 43's (CW-103); this product publishes the reserve "
               "requirement, deposit on hand and deposit or withdrawal amount once, and FOP+CORP DP-600 (customer reserve "
               "funding and program bank exposure) and DP-205 (regulatory capital) read them by reference and compare, never"
               " recompute (CW-262). For that reason DP-205 and DP-600 are not listed upstream (their edge to this product "
               "would close a cycle); the 43 Capital Requirement Calculation and Corporate Bank Account rows are read "
               "directly, because no foundational product publishes them. DP-300 publishes the client-book inputs (free "
               "credit balances, margin debit balances, segregated quantity) and never reads Reserve Computation; the 49 "
               "Reserve Computation, Reserve Computation Line, Possession or Control Determination and Control Location are "
               "read directly from 49, because no foundation publishes them (lead ruling Q6). Stock record breaks and Rule "
               "17a-13 counts are DP-446's; fails DP-447's. Backlog DP-453 (Brokerage Operations Daily Control Dashboard) "
               "names this product as its merge target; nothing of it is specified here at WP1. Acceptance question 6 (plan "
               "section 8.5): answered by Customer Reserve Requirement, Reserve Deposit on Hand, Required Reserve Deposit or"
               " Withdrawal, Securities Out of Possession or Control, Deficits Past Action Deadline and Aggregate Debit "
               "Items Tie to Net Capital; mastering domains 49, 43. Tailoring lever: computation frequency. Reference "
               "default: daily, required once average total credits reach USD 250 million (49 lever 2); weekly is the "
               "alternative below the threshold, with the 3 percent debit reduction unchanged. Tailoring lever: PAB "
               "computation. Reference default: computed, usually zero; it may be dropped (49 lever 3). Tailoring lever: "
               "in-house transfer agent as a good control location. Reference default: counted, basis to confirm (49 SME "
               "question 3). Tailoring lever: clearing model. Reference default: self-clearing (CW-235). Taxonomy gap: "
               "Reserve Computation has no deposit-made timestamp or deposit amount actually transferred, so a deposit made "
               "after the deadline is detected only from the next computation's Reserve Deposit on Hand. Taxonomy gap: "
               "Possession or Control Determination carries no price or value, so the deficit is valued from DP-300 client "
               "holdings. Taxonomy gap: the 43 Bank Account Purpose list has no Special Reserve value (Special Reserve Bank "
               "Account for the Exclusive Benefit of Customers, or of PAB), so reserve accounts are identified only through "
               "the 49 Reserve Computation.Reserve Bank Accounts reference, and the 15c3-3(f) written bank notice cannot be "
               "evidenced. Taxonomy gap: Reserve Computation has no version or supersedes attribute, so the 49 key "
               "(broker-dealer x computation date x type) holds one row and a correction overwrites it; the product keeps "
               "the prior state only as its own daily snapshot. Regulatory values: SEC Rule 15c3-3(e) and Exhibit A; the "
               "15c3-3(d) and (h) deficit time frames carried in Deficit Source; the USD 250 million daily-computation "
               "threshold (SEC Rule 15c3-3(e)(3)(i), in force June 30, 2026). Drafting assumptions: the deposit deadline is "
               "taken from Deposit Deadline Timestamp as 49 sets it (one hour after banking opens on the second business day"
               " after the computation, to confirm against the eCFR); the USD 1 and 0.0001-share tolerances; the deficit age"
               " buckets; Approved as the approval value. Decisions: CW-007, CW-101, CW-103, CW-115, CW-235, CW-262. WP1 new"
               " (CW-235): new consumer product of the BWO brief, specified first in wave C-3 because DP-600 reads it."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-456": dict(
        definition=("The restricted record of every cash movement on hold, other than AML holds, with its hold type, reason, "
                    "dates, expiry, notices, the paired account restriction and the fraud risk assessment behind it: "
                    "funds-availability, fraud, FINRA Rule 2165 disbursement holds, legal process, sanctions and deceased-"
                    "owner holds. It is the one product that reads the special-category 50 Money Movement Hold rows (Rule "
                    "2165 and exploitation reasons); the client protection facts of 02 and the 08 senior investor case "
                    "reach it only through DP-322 (the Protection Flag Present indicator) and the named restricted view DP-403 "
                    "(the case key and the Rule 2165 hold clock, read as DP-403 defines it). It publishes a restricted "
                    "row-level view for money movement, senior investor and compliance roles and, for everyone else, only "
                    "the non-special hold counts as DP-302 publishes them. It owns no certified metric family."),
        business_questions=[
            "Which cash movements are on hold today for fraud or elder-exploitation review, for how many business days, and for what amount (acceptance question 7)?",
            "Which Rule 2165 disbursement holds are past their permitted business days or their expiry, or lack the two-business-day notice to the trusted contact and authorized parties?",
            "Which Rule 2165 holds have no open senior investor case in DP-403, and which are paired with an account restriction?",
            "How many fraud holds came from a fraud model decision, how many were confirmed as fraud, and how many disbursements were stopped?",
            "Which holds involve a movement to a bank instruction that failed or never passed verification?",
        ],
        grain=("Money movement hold (MMHLD-) x as-of business date (daily snapshot of open and recently closed holds), "
               "with the held money movement, its fraud risk assessments and the bank account verification events of its "
               "bank instruction as companion facts; restricted row-level view, and an aggregate view limited to the "
               "non-special holds (hold type x age bucket x outcome)"),
        dimensions=["Client account (DP-093)", "Client party (DP-240)", "Hold type", "Hold reason (restricted view only)",
                    "Hold status", "Hold age bucket in business days (DP-013)", "Money movement type, payment rail and direction (DP-302)",
                    "Fraud decision and fraud model (DP-212)", "Verification method and result", "Protection Flag Present (DP-322)",
                    "As-of date (DP-013)"],
        measures=[
            ("Open Cash Movement Holds", "Restricted view only: count of Money Movement Hold rows with Hold Status in (Active, Extended) on the as-of date and Hold Type not AML, by Hold Type and Hold Reason. Never published as an aggregate outside the restricted roles, because it includes the special-category holds.",
             _u("50", "Money Movement Hold", "Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Reason", "Hold Status", "Hold Placed Date")),
            ("Active Money Movement Holds (from DP-302)", "The aggregate view's hold count: Money Movement Hold rows with Hold Status in (Active, Extended) on the as-of date, by Hold Type and Hold Reason, over DP-302's published rows only (Hold Type in Funds Availability, Fraud, Legal Process, Sanctions, Deceased Owner; Hold Reason neither special category nor AML Investigation), exactly as DP-302 defines it; the special-category holds are never added to it or shown beside it outside the restricted view (complementary suppression).",
             _u("50", "Money Movement Hold", "Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Reason", "Hold Status")),
            ("Amount on Hold", "Sum of Movement Amount of the Held Movement (read from DP-302) within one Movement Currency, by Hold Type, Money Movement Type and Payment Rail: over Open Cash Movement Holds in the restricted view, and over Active Money Movement Holds (from DP-302) only in the aggregate view.",
             _u("50", "Money Movement", "Money Movement ID", "Movement Amount", "Movement Currency", "Money Movement Type", "Payment Rail", "Movement Direction") + ["Open Cash Movement Holds", "Active Money Movement Holds (from DP-302)"]),
            ("Protection Flag Present (from DP-322)", "Indicator per hold: Y when the owner party of the Movement Account (15 Account Party Role of an owner Account Role Type, effective on the as-of date) is on the DP-322 Client Protection Flags & Senior Investor Register; the flag carries no detail and is joined on the 02 Party ID and the 15 Account ID only.",
             _u("02", "Party", "Party ID") + _u("15", "Account", "Account ID") + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account") + _u("50", "Money Movement", "Movement Account")),
            ("Holds for Fraud or Elder-Exploitation Review", "Restricted view: Open Cash Movement Holds with Hold Type in (Fraud, FINRA Rule 2165 Disbursement Hold, FINRA Rule 2166 Temporary Delay) or Hold Reason in (Suspected Account Takeover, New Payee Velocity, Suspected Financial Exploitation, Diminished Capacity Concern, Undue Influence, Scam Victim - Specified Adult), with Amount on Hold, the Senior Investor Case key resolved to the 08 Senior Investor Case ID published by DP-403, and Protection Flag Present (from DP-322). Outside the restricted view only its Fraud-type, non-special part is shown, as Active Money Movement Holds (from DP-302) of Hold Type Fraud.",
             _u("50", "Money Movement Hold", "Hold Type", "Hold Reason", "Senior Investor Case") + _u("08", "Senior Investor Case", "Senior Investor Case ID") + ["Open Cash Movement Holds", "Amount on Hold", "Protection Flag Present (from DP-322)", "Active Money Movement Holds (from DP-302)"]),
            ("Business Days on Hold", "DP-013 business days from Hold Placed Date to the as-of date, or to Hold Released Date for a released hold, per hold; reported as the average and as buckets (0 to 5, 6 to 15, 16 to 25, 26 to 55, over 55).",
             _u("50", "Money Movement Hold", "Hold Placed Date", "Hold Released Date", "Hold Status")),
            ("Active Rule 2165 Holds (from DP-403)", "Restricted view: count of 50 Money Movement Hold rows with Senior Investor Case populated, Hold Type = FINRA Rule 2165 Disbursement Hold and Hold Status = Active, plus 15 Account Restriction rows of Account Restriction Type = FINRA Rule 2165 Temporary Hold with Account Restriction Lifted Date empty, at the as-of date, exactly as DP-403 defines it; read, never recomputed, joined to this product's rows on Money Movement Hold ID.",
             _u("50", "Money Movement Hold", "Money Movement Hold ID", "Senior Investor Case", "Hold Type", "Hold Status") + _u("15", "Account Restriction", "Account Restriction ID", "Account Restriction Type", "Account Restriction Lifted Date")),
            ("Holds Past Day Limit (from DP-403)", "Restricted view: count of Active Rule 2165 Holds (from DP-403) whose business days since Hold Placed Date (or Account Restriction Effective From) exceed the limit in force for them: 15 business days, 25 with one extension, 55 where an 08 External Protection Report supports the further extension; and of holds within 3 business days of the limit, exactly as DP-403 defines it (the extensions come from the 08 case actions and reports, not from Hold Status); shown here with Amount on Hold.",
             _u("50", "Money Movement Hold", "Hold Placed Date", "Hold Expiry Date", "Senior Investor Case") + _u("15", "Account Restriction", "Account Restriction Effective From", "Restriction Review Due Date") + _u("08", "External Protection Report", "Reported Case", "Report Date") + ["Active Rule 2165 Holds (from DP-403)", "Amount on Hold"]),
            ("Holds Past Expiry (from DP-302)", "Active Money Movement Holds (from DP-302) whose Hold Expiry Date is before the as-of date and Hold Released Date is blank, by Hold Type, with age since Hold Placed Date, exactly as DP-302 defines it; the Rule 2165 limits are Holds Past Day Limit (from DP-403).",
             _u("50", "Money Movement Hold", "Hold Expiry Date", "Hold Released Date", "Hold Placed Date") + ["Active Money Movement Holds (from DP-302)"]),
            ("Hold Notice Timeliness % (from DP-403)", "Restricted view: Rule 2165 holds placed in the period with Hold Notice Date within 2 business days of Hold Placed Date / Rule 2165 holds placed in the period, exactly as DP-403 defines it (FINRA Rule 2165(b)(2)); read, never recomputed.",
             _u("50", "Money Movement Hold", "Hold Notice Date", "Hold Placed Date", "Hold Type")),
            ("Rule 2165 Holds Without Open Case", "Restricted view: count of open FINRA Rule 2165 Disbursement Hold rows whose Senior Investor Case is blank, or resolves to an 08 Senior Investor Case (key, status and closed date from DP-403) whose Case Status is Resolved / Completed, Closed or Canceled, or whose Case Closed Date is before the as-of date.",
             _u("50", "Money Movement Hold", "Hold Type", "Senior Investor Case") + _u("08", "Senior Investor Case", "Senior Investor Case ID", "Case Status", "Case Closed Date") + ["Open Cash Movement Holds"]),
            ("Holds Paired With Account Restriction", "Count of Open Cash Movement Holds whose Paired Account Restriction resolves to a 15 Account Restriction effective on the as-of date (Account Restriction Effective From on or before it, Account Restriction Lifted Date blank or after it), by Hold Type: the hold that stops the cash and the restriction that stops the account.",
             _u("50", "Money Movement Hold", "Paired Account Restriction") + _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Type", "Account Restriction Effective From", "Account Restriction Lifted Date") + ["Open Cash Movement Holds"]),
            ("Holds on Accounts Without Trusted Contact Provided", "Restricted view: Open Cash Movement Holds of type Fraud or FINRA Rule 2165 Disbursement Hold whose owner party has no 02 Trusted Contact Designation with Designation Status = Provided effective on the as-of date (Designation Effective From to Designation Effective To; read from DP-240; FINRA Rule 4512(a)(1)(F)).",
             _u("02", "Trusted Contact Designation", "Trusted Contact Designation ID", "Designating Client", "Designation Status", "Designation Effective From", "Designation Effective To") + ["Open Cash Movement Holds", "Protection Flag Present (from DP-322)"]),
            ("Fraud Model Holds", "Count of holds that are the Resulting Hold of a Fraud Risk Assessment with Fraud Decision = Hold, by Fraud Model (DP-212, CD-294) and assessment month; Fraud Risk Score is shown in the restricted view only.",
             _u("50", "Fraud Risk Assessment", "Assessed Movement", "Assessment Timestamp", "Fraud Model", "Fraud Risk Score", "Fraud Decision", "Resulting Hold")),
            ("Fraud Hold Confirmation Rate", "Fraud Model Holds whose Fraud Risk Assessment has Confirmed Fraud Indicator = Y / Fraud Model Holds released or closed in the period, by Fraud Model.",
             _u("50", "Fraud Risk Assessment", "Confirmed Fraud Indicator") + ["Fraud Model Holds"]),
            ("Disbursements Stopped", "Count and sum of Movement Amount of held movements with Movement Direction = Outflow whose Money Movement Status became Canceled or Rejected while a hold was open: the client money the holds protected.",
             _u("50", "Money Movement", "Money Movement Status", "Movement Direction", "Movement Amount") + ["Open Cash Movement Holds"]),
            ("Holds on Unverified Bank Instructions", "Count of Open Cash Movement Holds whose held movement's Bank Instruction Used has no Bank Account Verification Event with Verification Result = Verified before Hold Placed Date, or whose latest event has Verification Result = Failed.",
             _u("50", "Money Movement", "Bank Instruction Used") + _u("50", "Bank Account Verification Event", "Verified Bank Instruction", "Verification Attempt Number", "Verification Result", "Verification Timestamp") + ["Open Cash Movement Holds"]),
            ("Bank Verification Failure Rate", "Bank Account Verification Event rows with Verification Result = Failed / all verification attempts in the period, by Verification Method and Account Owner Name Matched.",
             _u("50", "Bank Account Verification Event", "Verification Method", "Verification Result", "Account Owner Name Matched", "Verification Timestamp")),
        ],
        inputs=[
            ("50", "Money Movement Hold", ["Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Reason", "Hold Status", "Hold Placed Date",
                                           "Hold Expiry Date", "Trusted Contact Notified", "Hold Notice Date",
                                           "Paired Account Restriction", "Senior Investor Case", "Hold Released Date"]),
            ("50", "Fraud Risk Assessment", ["Assessed Movement", "Assessment Timestamp", "Fraud Model", "Fraud Risk Score", "Fraud Decision",
                                             "Resulting Hold", "Confirmed Fraud Indicator"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Money Movement Type", "Payment Rail", "Movement Direction",
                                      "Movement Amount", "Movement Currency", "Requested Date", "Initiation Channel", "Third-Party Indicator",
                                      "Bank Instruction Used", "Money Movement Status"]),
            ("50", "Bank Account Verification Event", ["Verified Bank Instruction", "Verification Attempt Number", "Verification Method",
                                                       "Verification Result", "Account Owner Name Matched", "Verification Timestamp"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type", "Account Restriction Effective From",
                                           "Account Restriction Lifted Date", "Restriction Review Due Date"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Open Date"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From", "Account Role Effective To"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
            ("02", "Trusted Contact Designation", ["Trusted Contact Designation ID", "Designating Client", "Designation Status",
                                                   "Designation Effective From", "Designation Effective To"]),
            ("08", "Senior Investor Case", ["Senior Investor Case ID", "Case Status", "Case Closed Date"]),
            ("08", "External Protection Report", ["Reported Case", "Report Date"]),
        ],
        upstream=["DP-302", "DP-322", "DP-403", "DP-093", "DP-240", "DP-212", "DP-013"],
        refresh="Intraday",
        timeliness="Holds placed or changed by 5pm ET visible in the restricted view within 30 minutes; the daily snapshot and aggregate view by 7am ET on T+1",
        history="Daily snapshots of every hold kept seven years; hold rows, notices and assessments kept at least six years after the hold closes (SEC Rule 17a-4; FINRA Rule 2165(e) documentation); append-only, no deletion",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Held Movement resolves to a DP-302 Money Movement, every Movement Account and Restricted Account to an active DP-093 account, every Role Party and Designating Client to an active DP-240 party, every Senior Investor Case and Reported Case to a DP-403 case, and every Fraud Model to a DP-212 model inventory entry.",
            "Hold Expiry Date and Hold Released Date are on or after Hold Placed Date, a movement has at most one hold of each Hold Type with Hold Status in (Active, Extended) at a time, and Account Restriction Lifted Date, when present, is on or after Account Restriction Effective From.",
            "On each business day every hold counted in Active Rule 2165 Holds (from DP-403) matches a restricted-view hold row by Money Movement Hold ID with the same Hold Placed Date, and Amount on Hold equals the sum of DP-302 Movement Amount of the held movements within USD 0.01.",
            "Hold Type, Hold Reason, Hold Status, Hold Placed Date and Hold Expiry Date are populated on every hold, and Hold Notice Date and Senior Investor Case on every FINRA Rule 2165 Disbursement Hold older than two business days.",
            "Rows and counts that include a hold with Hold Type FINRA Rule 2165 Disbursement Hold or FINRA Rule 2166 Temporary Delay, or a special-category Hold Reason, exist only in the restricted view for the money movement, senior investor and compliance roles; the aggregate view publishes only Active Money Movement Holds (from DP-302) and their amounts, with no total, Protection category or difference that would let the special-category count be derived (complementary suppression), cells under 10 holds are suppressed, and AML holds, Hold Reason Narrative, Source Vulnerability Concern and every 02 Specified Adult Status and Vulnerability Concern attribute are never read.",
            "The restricted view refreshes at least every 30 minutes between 7am and 8pm ET on business days, and the daily snapshot for date D is complete by 7am ET on D+1 with no hold row changed after its snapshot is locked.",
        ],
        notes=("Certified numbers: none owned or read; Amount on Hold is an operational payment amount. PII tier: special "
               "category (CD-344). Publication rule (the WP1 restricted-view rule for DP-456): two outputs; the restricted "
               "row-level view (Restricted - Personal Data) for the money movement, senior investor and compliance roles, "
               "and the aggregate view for every other role, which carries only the non-special counts and amounts "
               "(Active Money Movement Holds (from DP-302)) by Hold Type, age and outcome, minimum cell 10 as in DP-322 "
               "and DP-403, and never a total or group from which the special-category count could be derived (lead "
               "ruling 2, DQ5). Bank instruction numbers are not read; the Bank Instruction Used key is "
               "masked outside the restricted view. Special category (CW-213, CW-231): this product reads the 50 Money "
               "Movement Hold rows directly, including the special-category rows that DP-302 suppresses (F3 ruling); it "
               "never reads 02 Specified Adult Status or Vulnerability Concern, or the 15 and 50 Source Vulnerability "
               "Concern keys. The 02 cause reaches it through DP-322 only: Protection Flag Present is traced to the 02 Party "
               "ID, the 15 Account ID and the 15 Account Party Role it joins on. The 08 Senior Investor Case is read for "
               "its key, status and closed date only, as the named restricted view DP-403 publishes them, and the Rule "
               "2165 hold clock (Active Rule 2165 Holds, Holds Past Day Limit, Hold Notice Timeliness %) is read from "
               "DP-403 exactly as DP-403 defines it, with extensions taken from the 08 case actions and External "
               "Protection Reports (lead ruling 1: one owner of the clock); DP-403 feeds this product and does not list it. The case review is 08's and DP-403's and is never re-scored here. Boundaries (CW-264): cash-movement holds "
               "are this product's; the client protection register is DP-322's; holds on TA-registered shares and "
               "redemptions are FOP+CORP DP-583's, which links the 50 hold and reads this product (so DP-583 is not "
               "listed upstream); securities and whole-account restrictions are 15 Account Restrictions (DP-093) and are "
               "shown only when paired. AML holds belong to DP-460 and the 38 AML product DP-226 (31 CFR 1023.320(e)) and "
               "are excluded at ingestion. Fraud Risk Score is produced by the 37 model named in Fraud Model (DP-212, "
               "CD-294); the assessment timestamp is the score date. Takes 50 Bank Account Verification Event from the "
               "backlog DP-455 (WP1 scope). Acceptance question 7 (plan section 8.5): answered by Holds for Fraud or "
               "Elder-Exploitation Review, Open Cash Movement Holds, Amount on Hold, Business Days on Hold and Protection "
               "Flag Present (from DP-322); mastering domains 50, 02, 08. DP-583 receives only the Money Movement Hold ID and Paired "
               "Account Restriction of the holds it links, never Hold Type or Hold Reason, so the link does not reveal "
               "special-category status. Tailoring lever: FINRA Rule 2166 temporary "
               "delays. Reference default: the Hold Type value exists but is unused until the rule is adopted; when "
               "adopted, its delays are recorded here as special category (50 lever 9). Tailoring lever: Rule 2165 scope. "
               "Reference default: disbursement holds here, securities transaction holds as 15 Account Restrictions (50 "
               "lever 6). Tailoring lever: funds availability holds. Reference default: firm policy aligned to Regulation "
               "CC timing (50 lever 5). Tailoring lever: minimum aggregate cell size. Reference default: 10 holds (CW-225). "
               "Taxonomy gap: Money Movement Hold has no held amount, so a partial hold cannot be shown and Amount on Hold "
               "is the full Movement Amount. Taxonomy gap: Money Movement Hold has no extension count or extension dates; "
               "DP-403 takes the extension from the 08 case actions and reports, and this product reads that. Taxonomy gap: "
               "Money Movement Hold has no reason for an omitted trusted contact notice (unavailable or suspected). "
               "Regulatory values: FINRA Rule 2165(b)(2) two business days for notice and (b)(3) 15 + 10 + up to 30 "
               "business days; FINRA Rule 4512 trusted contact. Drafting assumptions: the fraud-related Hold Reason values "
               "grouped with the exploitation reasons; the age buckets; Resolved / Completed, Closed and Canceled as closed Case Status values; the 30-minute "
               "intraday cycle. Decisions: CW-030, CW-109, CW-115, CW-213, CW-231, CW-264, CD-294, CD-344. WP1 new "
               "(CW-231): new consumer product of the BWO brief; adds 50 Bank Account Verification Event (moved read from "
               "backlog DP-455) and the 02 Trusted Contact Designation from DP-240; leaves the AML holds to DP-460."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-435": dict(
        definition=("Every client order from receipt to final state, with its order-time eligibility checks, events, routes, "
                    "executions, allocations and option legs, matched to the CAT Reportable Events each step must produce and "
                    "to their submission, rejection and repair status. It also holds the Rule 15c3-5 market-access evidence: "
                    "the pre-trade limits that applied, the orders they blocked, the overrides and the limits past their "
                    "annual review. Trading operations works late, rejected and unrepaired CAT records and order-state breaks "
                    "from it before the repair deadline. It reads the order and CAT facts from DP-301 and the 48 Order "
                    "Eligibility Check directly, and owns no certified metric family."),
        business_questions=[
            "Which order lifecycle steps of yesterday have no CAT record, which CAT records were submitted after 8am ET on T+1, and which were rejected?",
            "Which rejected CAT records are still unrepaired, and which are past their repair deadline?",
            "Which day orders have no terminal status, and which orders have event sequences that do not add up?",
            "Which orders did order-time checks block or override, by check type and approver, and which pre-trade limits blocked them?",
            "Which Rule 15c3-5 pre-trade limits have not been reviewed in the last year?",
        ],
        grain=("Client order (CLORD-) x trade date for the lifecycle row, with order-time checks (order x check type), order "
               "events, routes, executions, allocations and CAT Reportable Events (one per lifecycle event) as companion "
               "facts at their own grain, and Pre-Trade Risk Limit versions (SCD type 2) as a reference companion; daily "
               "snapshot of open exceptions"),
        dimensions=["Client account (DP-093)", "Instrument and option series (DP-097)", "Venue and routing rule (DP-432)",
                    "Order source and entry channel", "Client order type, time in force and trading session", "Client order status",
                    "Eligibility check type and check result", "Pre-trade limit type and scope", "CAT event type, report status and error code",
                    "Entering employee and override approver (DP-192)", "Trade date and CAT submission date (DP-013)"],
        measures=[
            ("Client Orders Received (from DP-301)", "Count of Client Order rows with Order Received Timestamp in the period, by Order Source, Order Entry Channel, Client Order Type, Order Side, Solicited Indicator, Discretionary Order Indicator and the Instrument Type of Order Instrument, exactly as DP-301 defines it.",
             _u("48", "Client Order", "Client Order ID", "Order Received Timestamp", "Order Source", "Order Entry Channel", "Order Side", "Solicited Indicator", "Discretionary Order Indicator", "Order Instrument") + _u("48", "Order Instruction Detail", "Client Order Type") + _u("17", "Instrument", "Instrument Type")),
            ("Day Orders Without Terminal Status (from DP-301)", "Count of Client Orders with Time in Force = Day, Order Received Timestamp before the current trade date and Client Order Status in (Pending New, New, Partially Filled, Pending Cancel, Pending Replace), exactly as DP-301 defines it; this product adds the work queue by Order Entry Channel and age.",
             _u("48", "Client Order", "Client Order Status", "Order Received Timestamp") + _u("48", "Order Instruction Detail", "Time in Force")),
            ("Order Event Sequence Breaks", "Count of orders whose first Client Order Event (lowest Event Sequence Number) is not Received, or whose latest event has Cumulative Filled Quantity + Leaves Quantity different from Order Quantity while the order is open, or whose Cumulative Filled Quantity decreases from one event to the next.",
             _u("48", "Client Order Event", "Event Client Order", "Event Sequence Number", "Client Order Event Type", "Cumulative Filled Quantity", "Leaves Quantity") + _u("48", "Client Order", "Order Quantity")),
            ("Expected CAT Events", "Count of lifecycle records that must produce a CAT record on the trade date: one New Order (Option New Order for orders with Option Order Leg rows) per Client Order, one Order Route per Order Route, one Trade or Order Fulfillment per Client Execution and one Post-Trade Allocation per Client Allocation (CAT NMS Plan; FINRA Rule 6830).",
             _u("48", "Client Order", "Client Order ID") + _u("48", "Option Order Leg", "Leg Client Order") + _u("48", "Order Route", "Order Route ID", "Routed Client Order") + _u("48", "Client Execution", "Client Execution ID") + _u("48", "Client Allocation", "Allocated Client Order", "Allocated Account")),
            ("CAT Events Missing", "Expected CAT Events with no CAT Reportable Event of the matching CAT Event Type whose CAT Source Client Order, CAT Source Order Route, CAT Source Client Execution or CAT Source Client Allocation names the record, by CAT Event Type.",
             _u("48", "CAT Reportable Event", "CAT Record ID", "CAT Event Type", "CAT Source Client Order", "CAT Source Order Route", "CAT Source Client Execution", "CAT Source Client Allocation") + ["Expected CAT Events"]),
            ("CAT Completeness %", "(Expected CAT Events - CAT Events Missing) / Expected CAT Events, by trade date and CAT Event Type.",
             ["Expected CAT Events", "CAT Events Missing"]),
            ("CAT Records Submitted Late", "Count of CAT Reportable Event rows whose CAT Submission Date is after the business day following the date of CAT Event Timestamp, or on that day after 8am ET (FINRA Rule 6830 and the CAT NMS Plan T+1 8am ET deadline), by CAT Event Type.",
             _u("48", "CAT Reportable Event", "CAT Submission Date", "CAT Event Timestamp", "CAT Event Type")),
            ("CAT Records Rejected", "Count of CAT Reportable Event rows with CAT Report Status = Rejected, by CAT Error Code and CAT Event Type.",
             _u("48", "CAT Reportable Event", "CAT Report Status", "CAT Error Code", "CAT Event Type")),
            ("CAT Repairs Past Deadline", "CAT Records Rejected whose CAT Repair Deadline is before the as-of timestamp and whose CAT Report Status has not moved to Corrected or Accepted, with days past deadline (repair by 8am ET on T+3).",
             _u("48", "CAT Reportable Event", "CAT Repair Deadline", "CAT Report Status") + ["CAT Records Rejected"]),
            ("CAT Records Without Firm Designated ID", "Count of CAT Reportable Event rows of type New Order or Option New Order whose Firm Designated ID is blank; the FDID is the only customer key a CAT record may carry (CW-115).",
             _u("48", "CAT Reportable Event", "Firm Designated ID", "CAT Event Type")),
            ("Receipt to First Route Latency (from DP-301)", "Median over client orders of (the earliest Routed Timestamp of the routes whose Routed Client Order is the order) minus Order Received Timestamp, in milliseconds, by Order Entry Channel and Trading Session, exactly as DP-301 defines it.",
             _u("48", "Order Route", "Routed Client Order", "Routed Timestamp") + _u("48", "Client Order", "Order Received Timestamp", "Order Entry Channel") + _u("48", "Order Instruction Detail", "Trading Session")),
            ("Unallocated Block Quantity (from DP-301)", "For each Client Block Order created before the current trade date, the Executed Quantity of the Client Executions whose Execution Order Route is a route whose Routed Client Block Order is the block minus the sum of Allocated Quantity and Fractional Remainder Quantity of its Client Allocation rows (Allocation Client Block Order), reported where nonzero by Block Origin, exactly as DP-301 defines it (executed, not ordered, quantity); a nonzero value leaves Post-Trade Allocation CAT events unreported.",
             _u("48", "Client Block Order", "Client Block Order ID", "Block Origin", "Block Created Timestamp") + _u("48", "Order Route", "Routed Client Block Order") + _u("48", "Client Execution", "Execution Order Route", "Executed Quantity") + _u("48", "Client Allocation", "Allocation Client Block Order", "Allocated Quantity", "Fractional Remainder Quantity")),
            ("Multi-Leg Option Orders Missing Legs", "Count of Client Orders whose Option Strategy Type is a multi-leg strategy and that have fewer than two Option Order Leg rows (Leg Client Order), or a leg without Leg Option Series or Leg Open Close Indicator.",
             _u("48", "Order Instruction Detail", "Option Strategy Type") + _u("48", "Option Order Leg", "Leg Client Order", "Leg Sequence Number", "Leg Option Series", "Leg Open Close Indicator")),
            ("Orders Blocked at Order Time", "Count of Order Eligibility Check rows with Check Result = Failed - Blocked, by Eligibility Check Type and Check Failure Reason, and the share of Client Orders in Lifecycle they represent.",
             _u("48", "Order Eligibility Check", "Checked Client Order", "Eligibility Check Type", "Check Result", "Check Failure Reason", "Check Timestamp") + ["Client Orders Received (from DP-301)"]),
            ("Order-Time Overrides", "Count of Order Eligibility Check rows with Check Result = Failed - Overridden, by Eligibility Check Type and Override Approver (DP-192), and Order-Time Overrides / (Orders Blocked at Order Time + Order-Time Overrides) as the override rate.",
             _u("48", "Order Eligibility Check", "Check Result", "Eligibility Check Type", "Override Approver") + ["Orders Blocked at Order Time"]),
            ("Orders Blocked by Pre-Trade Limit", "Orders Blocked at Order Time whose Applied Pre-Trade Risk Limit is populated, by Pre-Trade Limit Type, with Hard Block Indicator of the limit (SEC Rule 15c3-5(c)(1)).",
             _u("48", "Order Eligibility Check", "Applied Pre-Trade Risk Limit") + _u("48", "Pre-Trade Risk Limit", "Pre-Trade Limit Type", "Hard Block Indicator", "Limit Threshold Value", "Limit Threshold Unit") + ["Orders Blocked at Order Time"]),
            ("Pre-Trade Limits Past Annual Review", "Count of Pre-Trade Risk Limit versions effective on the as-of date (Limit Effective From on or before, Limit Effective To blank or after) whose Limit Last Review Date is more than 12 months before the as-of date, by Pre-Trade Limit Scope (SEC Rule 15c3-5(e) annual review).",
             _u("48", "Pre-Trade Risk Limit", "Limit Last Review Date", "Limit Effective From", "Limit Effective To", "Pre-Trade Limit Scope", "Limit Scope Value", "Limit Approved By")),
            ("Stale Buying Power at Order Entry", "Count of Order Eligibility Check rows with Eligibility Check Type = Buying Power whose Buying Power As-Of Timestamp is more than 15 minutes before Check Timestamp; the buying power used is a copy of the 49 balance (48 lever 9).",
             _u("48", "Order Eligibility Check", "Eligibility Check Type", "Buying Power At Entry", "Buying Power As-Of Timestamp", "Check Timestamp")),
        ],
        inputs=[
            ("48", "Client Order", ["Client Order ID", "Order Account", "Order Instrument", "Order Side", "Order Quantity", "Order Source",
                                    "Entering Employee", "Order Entry Channel", "Solicited Indicator", "Discretionary Order Indicator", "Order Received Timestamp", "Client Order Status"]),
            ("48", "Order Instruction Detail", ["Client Order Type", "Time in Force", "Trading Session", "Option Strategy Type"]),
            ("48", "Option Order Leg", ["Leg Client Order", "Leg Sequence Number", "Leg Option Series", "Leg Open Close Indicator"]),
            ("48", "Client Order Event", ["Event Client Order", "Event Sequence Number", "Client Order Event Type", "Event Timestamp",
                                          "Cumulative Filled Quantity", "Leaves Quantity"]),
            ("48", "Order Route", ["Order Route ID", "Routed Client Order", "Routed Client Block Order", "Route Venue", "Routed Timestamp", "Applied Routing Rule"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Executed Quantity", "Execution Timestamp", "Execution Trade Date"]),
            ("48", "Client Allocation", ["Allocation Client Block Order", "Allocated Client Order", "Allocated Account", "Allocated Quantity", "Fractional Remainder Quantity", "Allocation Timestamp"]),
            ("48", "Client Block Order", ["Client Block Order ID", "Block Origin", "Aggregate Quantity", "Block Created Timestamp"]),
            ("48", "CAT Reportable Event", ["CAT Record ID", "CAT Event Type", "CAT Source Client Order", "CAT Source Order Route",
                                            "CAT Source Client Execution", "CAT Source Client Allocation", "Firm Designated ID",
                                            "CAT Event Timestamp", "CAT Submission Date", "CAT Report Status", "CAT Error Code",
                                            "CAT Repair Deadline"]),
            ("48", "Order Eligibility Check", ["Checked Client Order", "Eligibility Check Type", "Check Result", "Check Failure Reason",
                                               "Check Timestamp", "Checked Account Feature", "Checked Account Restriction",
                                               "Checked Client Restriction", "Checked Restricted List Entry", "Buying Power At Entry",
                                               "Buying Power As-Of Timestamp", "Applied Pre-Trade Risk Limit", "Override Approver"]),
            ("48", "Pre-Trade Risk Limit", ["Pre-Trade Limit Type", "Pre-Trade Limit Scope", "Limit Scope Value", "Limit Scope Account",
                                            "Limit Instrument Class", "Limit Threshold Value", "Limit Threshold Unit", "Hard Block Indicator",
                                            "Limit Approved By", "Limit Last Review Date", "Limit Effective From", "Limit Effective To"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type"]),
        ],
        upstream=["DP-301", "DP-432", "DP-093", "DP-097", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="Lifecycle and CAT status of trade date T by 9am ET on T+1, after the 8am ET CAT submission deadline; CAT feedback refreshed by 9am ET on T+2 and T+3 for the repair window",
        history="Order lifecycle, checks and CAT records kept six years (SEC Rule 17a-4(b) and (f); CAT NMS Plan record retention); daily exception snapshots kept 25 months; pre-trade limit versions as SCD type 2",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Order Account resolves to an active DP-093 account, every Order Instrument and Leg Option Series to a DP-097 instrument, every Route Venue to a DP-432 venue, and every CAT Source Client Order, CAT Source Order Route, CAT Source Client Execution and CAT Source Client Allocation to the DP-301 record it names.",
            "Pre-Trade Risk Limit versions of one Pre-Trade Limit Type, Pre-Trade Limit Scope and Limit Scope Value do not overlap and Limit Effective To is on or after Limit Effective From; Client Order Event rows of one order have unique, increasing Event Sequence Number.",
            "For each trade date the count of Client Orders read equals DP-301 Client Orders Received for the same date, and the count of CAT Reportable Event rows with CAT Report Status Accepted equals the accepted count in the CAT feedback for that date within zero records.",
            "CAT Event Type, CAT Submission Date and CAT Report Status are populated on every CAT Reportable Event, Firm Designated ID on every New Order and Option New Order record, and Eligibility Check Type and Check Result on every Order Eligibility Check.",
            "No CAT record published here carries a customer name, address, date of birth or account number: only the Firm Designated ID; account-level views are restricted to trading operations and supervision roles, and Limit Scope Account is shown only to the market-access control owner.",
            "The lifecycle and CAT status of trade date T is complete by 9am ET on T+1 for every trade date with orders, and CAT Repairs Past Deadline is recomputed after each CAT feedback file before 9am ET.",
        ],
        notes=("Certified numbers: none. PII tier: financial (account-level orders); CAT records carry the FDID only (CW-115). "
               "Boundaries (lead ruling 3, F3 fix pass): DP-301 publishes the order, route, execution, allocation, CAT "
               "Reportable Event and Pre-Trade Risk Limit facts, and this product owns the CAT completeness and market-access "
               "counts and work queues, reading those facts 'from DP-301'. The 48 Order Eligibility Check is read directly "
               "because no foundation publishes it (moved read from backlog DP-439, which names this product as its merge "
               "target); the approvals, restrictions and restricted lists it checks stay in 15, 02, 01 and 38 and are carried "
               "as keys (CW-099). Execution quality and routing analytics are DP-436's, corrections DP-437's, confirmations "
               "and trade reports DP-438's, option exercises DP-452's, trade surveillance 38's. Operating model: "
               "self-clearing; as an introducing broker the grain is kept with the clearing firm's references (48 lever 1, "
               "CW-235). Tailoring lever: clearing model. Reference default: self-clearing. Tailoring lever: buying power at "
               "entry. Reference default: a copy of the 49 balance taken at check time (48 lever 9). Tailoring lever: "
               "overnight session. Reference default: none; an Overnight session adds trading-session values and CAT events "
               "(48 lever 4). Taxonomy gap: CAT Reportable Event has no correction-submission date, so a repair's timeliness "
               "is read from the status change in the CAT feedback, not from a repair timestamp. Taxonomy gap: Order "
               "Eligibility Check has no link to the Supervisory Review that approves an override pattern. Regulatory values: "
               "CAT NMS Plan and FINRA Rule 6830 (submit by 8am ET on T+1; repair by 8am ET on T+3); SEC Rule 15c3-5(c) and "
               "(e). Drafting assumptions: the open order statuses; the multi-leg Option Strategy Type values; the 15-minute "
               "buying power staleness window; 'Corrected' and 'Accepted' as repaired report statuses. Decisions: CW-096, "
               "CW-099, CW-100, CW-115, CW-176, CW-235. WP1 new (CW-235): new consumer product of the BWO brief; takes the "
               "backlog DP-439 reads (Order Eligibility Check, Pre-Trade Risk Limit) per WP1 scope."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-436": dict(
        definition=("Execution quality by venue, order class and client order type: price improvement rate and amount, "
                    "effective over quoted spread and the quote at routing, with the Rule 605 monthly report lines, the Rule "
                    "606 quarterly routing disclosure, the Rule 606(b) customer requests and the best-execution committee "
                    "reviews behind each venue and routing rule. It reads the 48 Execution Quality Measure, Rule 606 lines "
                    "and disclosure requests directly, the venues, routing rules and Rule 605 lines from DP-432, the routes "
                    "and executions from DP-301 and the 22 quote observations as the quote snapshot. It is the evidence pack "
                    "for the FINRA Rule 5310 regular and rigorous review and owns no certified metric family."),
        business_questions=[
            "What is execution quality by venue and order type this month: price improvement rate, average price improvement per share and effective over quoted spread (acceptance question 5)?",
            "How does each venue's price improvement on our executions compare with the quote at the time of routing, and does the routed NBBO agree with the 22 quote snapshot?",
            "What do the Rule 605 lines show for price-improved shares, effective spread and time to execution by order type and size bucket?",
            "Where did non-directed orders go by venue and order class in the Rule 606 report, and what net payment for order flow was received?",
            "Which venues and routing rules lack a current best-execution committee review, and which Rule 606(b) requests were answered late?",
        ],
        grain=("Measurement period x order class x client order type x venue for execution quality (48 Execution Quality "
               "Measure), with Rule 605 lines (month x security x order type x size bucket), Rule 606 lines (quarter x month x "
               "order class x venue), routing disclosure requests, executions with their routes and quotes, and committee "
               "reviews as companion facts; monthly and quarterly snapshots"),
        dimensions=["Venue and venue affiliation (DP-432)", "Routing rule (DP-432)", "Order class (Routing Instrument Class)", "Client order type",
                    "Rule 605 order type and size bucket", "Rule 606 order class", "Security (DP-097)", "Reporting broker-dealer (DP-013)",
                    "Measurement period, report month and quarter (DP-013)", "Committee review (08)"],
        measures=[
            ("Price Improvement Rate by Venue", "Measured Order Count-weighted average of Price Improvement Rate of Execution Quality Measure rows for the measurement period, by Measured Venue, Measure Order Class and Measure Client Order Type; published as 48 computes it (CW-100), never recomputed.",
             _u("48", "Execution Quality Measure", "Measure Period Start", "Measure Period End", "Measure Order Class", "Measure Client Order Type", "Measured Venue", "Measured Order Count", "Price Improvement Rate")),
            ("Average Price Improvement Per Share by Venue", "Measured Order Count-weighted average of Average Price Improvement Per Share, by Measured Venue, Measure Order Class and Measure Client Order Type.",
             _u("48", "Execution Quality Measure", "Average Price Improvement Per Share", "Measured Order Count", "Measured Venue", "Measure Client Order Type")),
            ("Effective Over Quoted Spread by Venue", "Measured Order Count-weighted average of Effective Over Quoted Spread, by Measured Venue and Measure Order Class; below 100 percent means executions inside the quote.",
             _u("48", "Execution Quality Measure", "Effective Over Quoted Spread", "Measured Order Count", "Measured Venue", "Measure Order Class")),
            ("Price Improvement Amount (from DP-301)", "Sum of Price Improvement Per Share x Executed Quantity over Client Executions in the period, by Execution Venue MIC and Extended-Hours Execution Indicator, exactly as DP-301 defines it; this product adds the cut by the Route Venue of the Execution Order Route (DP-432 venue) and the Client Order Type of the order.",
             _u("48", "Client Execution", "Price Improvement Per Share", "Executed Quantity", "Execution Venue MIC", "Extended-Hours Execution Indicator", "Execution Order Route") + _u("48", "Order Route", "Order Route ID", "Route Venue", "Routed Client Order") + _u("48", "Order Instruction Detail", "Client Order Type")),
            ("Quoted Spread at Route", "Average of NBBO Offer At Route - NBBO Bid At Route over Order Route rows of NMS stock orders, in USD per share and as a percentage of the midpoint, by Route Venue and order type: the quote snapshot taken at routing.",
             _u("48", "Order Route", "NBBO Bid At Route", "NBBO Offer At Route", "Route Venue")),
            ("Execution Price Versus Quote at Route", "Per share, for buys NBBO Offer At Route - Execution Price and for sells Execution Price - NBBO Bid At Route (Order Side of the order), averaged weighted by Executed Quantity by venue; an independent check of the 48 price improvement statistics.",
             _u("48", "Client Execution", "Execution Price", "Executed Quantity") + _u("48", "Order Route", "NBBO Bid At Route", "NBBO Offer At Route") + _u("48", "Client Order", "Order Side")),
            ("Routed Quotes Without 22 Quote Snapshot", "Count of Order Route rows of NMS stock orders for which no 22 Price Observation of the Order Instrument exists with Observed Price Type Bid and Ask, Observation Price Origin Composite / Consolidated Price and Observation As-Of Timestamp within one second before Routed Timestamp: the quote snapshot coverage of acceptance question 5.",
             _u("22", "Price Observation", "Observed Instrument", "Observed Price Type", "Observation Price Origin", "Observation As-Of Timestamp") + _u("48", "Order Route", "Routed Timestamp") + _u("48", "Client Order", "Order Instrument")),
            ("Routed NBBO Differs From 22 Quote", "Count of Order Route rows whose NBBO Bid At Route or NBBO Offer At Route differs by more than USD 0.005 from the Observed Price Value of the matching 22 Bid or Ask Price Observation, by Route Venue.",
             _u("22", "Price Observation", "Observed Price Value", "Observed Price Type") + _u("48", "Order Route", "NBBO Bid At Route", "NBBO Offer At Route", "Route Venue") + ["Routed Quotes Without 22 Quote Snapshot"]),
            ("Rule 605 Price-Improved Share %", "Sum of Price Improved Shares / sum of Covered Order Shares of Rule 605 Report Line rows (from DP-432) for the Rule 605 Report Month, by Rule 605 Order Type and Rule 605 Order Size Bucket.",
             _u("48", "Rule 605 Report Line", "Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Order Type", "Rule 605 Order Size Bucket", "Price Improved Shares", "Covered Order Shares")),
            ("Rule 605 Effective Spread and Time to Execution", "Covered Order Shares-weighted Average Effective Spread and Average Time To Execution of the Rule 605 lines of the month, by Rule 605 Order Type, Rule 605 Order Size Bucket and Rule 605 Notional Size Range.",
             _u("48", "Rule 605 Report Line", "Average Effective Spread", "Average Time To Execution", "Covered Order Shares", "Rule 605 Notional Size Range", "Rule 605 Order Type")),
            ("Rule 606 Non-Directed Order Share by Venue", "Non-Directed Order Percentage of Rule 606 Report Line rows by Rule 606 Report Quarter, Rule 606 Report Month, Rule 606 Order Class and Rule 606 Venue, with the market, marketable limit, non-marketable limit and other order percentages (SEC Rule 606(a)(1)).",
             _u("48", "Rule 606 Report Line", "Rule 606 Reporting Entity", "Rule 606 Report Quarter", "Rule 606 Report Month", "Rule 606 Order Class", "Rule 606 Venue", "Non-Directed Order Percentage", "Market Order Percentage", "Marketable Limit Order Percentage", "Non-Marketable Limit Order Percentage", "Other Order Percentage")),
            ("Rule 606 Net Payment for Order Flow", "Sum of Net Order Flow Payment Amount of Rule 606 lines by quarter, order class and venue; zero under the reference default (no payment for order flow accepted), checked against the Payment for Order Flow Indicator of the DP-432 venue profile.",
             _u("48", "Rule 606 Report Line", "Net Order Flow Payment Amount", "Rule 606 Venue") + _u("48", "Execution Venue Profile", "Venue Party", "Payment for Order Flow Indicator", "Affiliated Venue Indicator")),
            ("Rule 606 Venues Without Material Aspects Discussion", "Count of Rule 606 lines of the quarter for venues receiving non-directed orders whose Material Aspects Discussion is blank (SEC Rule 606(a)(1)(iv)).",
             _u("48", "Rule 606 Report Line", "Material Aspects Discussion", "Non-Directed Order Percentage")),
            ("Routed Quantity Share by Venue", "Sum of Routed Quantity of Order Route rows by Route Venue / total Routed Quantity for the month, by Rule Instrument Class of the Applied Routing Rule, with affiliated venues flagged from DP-432.",
             _u("48", "Order Route", "Routed Quantity", "Route Venue", "Applied Routing Rule") + _u("48", "Routing Rule", "Routing Rule Code", "Rule Instrument Class", "Primary Venue") + _u("48", "Execution Venue Profile", "Affiliated Venue Indicator")),
            ("Venues Without Current Committee Review", "Count of Measured Venue values of the latest quarter whose Execution Quality Measure rows have a blank Reviewing Committee Review, or whose 08 Supervisory Review has a Review Completed Date older than the quarter end (FINRA Rule 5310.09 regular and rigorous review, at least quarterly), and Routing Rule versions in force whose Approving Review is blank.",
             _u("48", "Execution Quality Measure", "Reviewing Committee Review", "Measured Venue", "Measure Period End") + _u("48", "Routing Rule", "Approving Review", "Routing Rule Effective From", "Routing Rule Effective To") + _u("08", "Supervisory Review", "Supervisory Review ID", "Supervisory Review Type", "Review Completed Date")),
            ("Committee Reviews With Exceptions", "Count of 08 Supervisory Review rows of the best-execution type with Review Outcome other than no exception, by Reviewed Routing Rule and Reviewed Execution Venue; the review itself is 08's, read and never re-scored.",
             _u("08", "Supervisory Review", "Supervisory Review Type", "Review Outcome", "Reviewed Routing Rule", "Reviewed Execution Venue", "Review Completed Date")),
            ("Routing Disclosure Requests Answered Late", "Count of Order Routing Disclosure Request rows whose Response Delivered Date is blank or more than seven business days after Request Received Date, by Routing Disclosure Request Type (SEC Rule 606(b)(1) and (b)(3)).",
             _u("48", "Order Routing Disclosure Request", "Routing Disclosure Request Type", "Request Received Date", "Response Delivered Date", "Request Account")),
        ],
        inputs=[
            ("48", "Execution Quality Measure", ["Measure Period Start", "Measure Period End", "Measure Order Class", "Measure Client Order Type",
                                                 "Measured Venue", "Measured Order Count", "Price Improvement Rate",
                                                 "Average Price Improvement Per Share", "Effective Over Quoted Spread",
                                                 "Reviewing Committee Review"]),
            ("48", "Rule 605 Report Line", ["Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Security", "Rule 605 Order Type",
                                            "Rule 605 Order Size Bucket", "Rule 605 Notional Size Range", "Covered Order Count",
                                            "Covered Order Shares", "Average Effective Spread", "Price Improved Shares",
                                            "Average Time To Execution"]),
            ("48", "Rule 606 Report Line", ["Rule 606 Reporting Entity", "Rule 606 Report Quarter", "Rule 606 Report Month", "Rule 606 Order Class",
                                            "Rule 606 Venue", "Non-Directed Order Percentage", "Market Order Percentage",
                                            "Marketable Limit Order Percentage", "Non-Marketable Limit Order Percentage",
                                            "Other Order Percentage", "Net Order Flow Payment Amount", "Material Aspects Discussion"]),
            ("48", "Order Routing Disclosure Request", ["Requesting Party", "Request Account", "Routing Disclosure Request Type", "Request Received Date",
                                                        "Look-Back Start Date", "Response Delivered Date"]),
            ("48", "Execution Venue Profile", ["Venue Party", "Venue Type", "Venue MIC", "Payment for Order Flow Indicator", "Affiliated Venue Indicator",
                                               "Venue Profile Effective From", "Venue Profile Effective To"]),
            ("48", "Routing Rule", ["Routing Rule Code", "Rule Instrument Class", "Primary Venue", "Approving Review", "Routing Rule Effective From",
                                    "Routing Rule Effective To"]),
            ("48", "Order Route", ["Order Route ID", "Routed Client Order", "Route Venue", "Routed Quantity", "Routed Timestamp", "Applied Routing Rule",
                                   "NBBO Bid At Route", "NBBO Offer At Route"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Executed Quantity", "Execution Price", "Execution Trade Date",
                                        "Execution Venue MIC", "Price Improvement Per Share", "Extended-Hours Execution Indicator"]),
            ("48", "Client Order", ["Client Order ID", "Order Instrument", "Order Side", "NBBO Midpoint At Receipt"]),
            ("48", "Order Instruction Detail", ["Client Order Type", "Trading Session"]),
            ("08", "Supervisory Review", ["Supervisory Review ID", "Supervisory Review Type", "Reviewed Routing Rule", "Reviewed Execution Venue",
                                          "Review Completed Date", "Review Outcome"]),
            ("22", "Price Observation", ["Price Observation Key", "Observed Instrument", "Observed Price Type", "Observation Price Origin",
                                         "Observation As-Of Timestamp", "Observed Price Value"]),
        ],
        upstream=["DP-432", "DP-301", "DP-097", "DP-240", "DP-093", "DP-013"],
        refresh="Monthly",
        timeliness="Execution quality and Rule 605 views by the 25th calendar day of the month after the measurement month; Rule 606 view by the 20th day after quarter-end, ahead of publication within one month after quarter-end; routing disclosure request status daily by 9am ET",
        history="Monthly and quarterly snapshots kept six years (SEC Rule 17a-4); Rule 605 and 606 lines as published, with restatements as new versions; committee review links kept with the review",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Measured Venue, Rule 606 Venue, Route Venue and Primary Venue resolves to a DP-432 venue with an Execution Venue Profile effective in the period, every Rule 605 Security and Observed Instrument to a DP-097 instrument, and every Request Account to an active DP-093 account.",
            "Execution Quality Measure periods of one venue, order class and client order type do not overlap and Measure Period End is on or after Measure Period Start; Routing Rule versions read do not overlap in effective period.",
            "For each Rule 605 Report Month the Rule 605 lines read equal DP-432 Rule 605 Covered Orders and Rule 605 Price-Improved Shares for the same month, and for each Rule 606 Report Month and Rule 606 Order Class the Non-Directed Order Percentage of the reported venues sums to no more than 100 percent and each line's market, marketable limit, non-marketable limit and other percentages sum to 100 percent within 0.1 point.",
            "Measured Order Count, Price Improvement Rate and Average Price Improvement Per Share are populated on every Execution Quality Measure row, and NBBO Bid At Route and NBBO Offer At Route on every Order Route of an NMS stock order.",
            "Requesting Party and Request Account of Order Routing Disclosure Request rows are visible only to brokerage compliance and client service roles; the Rule 605 and 606 extracts and the venue views carry no personal data.",
            "The Rule 605 view of month M is complete by the 25th calendar day of M+1 and the Rule 606 view of quarter Q by the 20th day after its end, and published report lines are never changed in place.",
        ],
        notes=("Certified numbers: none; Net Order Flow Payment Amount is a disclosure figure, and revenue is 10's. PII tier: "
               "identity (Rule 606(b) requesters, restricted view, DQ5); report lines and measures carry no personal data. "
               "Boundaries (F3 ruling 3): DP-432 publishes the venue, routing rule and Rule 605 line facts and this product "
               "owns the execution-quality analytics, reading the 48 Execution Quality Measure, Rule 606 Report Line and "
               "Order Routing Disclosure Request directly (no foundation publishes them) and the Rule 605 lines 'from "
               "DP-432'. The 48 statistics are computed in 48 (CW-100); this product publishes and compares them and never "
               "recomputes them. The committee review is the 08 Supervisory Review, read directly for its key, type, outcome "
               "and date because no foundational product publishes it, and never re-scored; the portfolio best-execution "
               "reviews of the fund desk are 25's. Orders and executions are DP-301's, corrections DP-437's. The 22 quote "
               "snapshot (the WP1 item left open at WP0): read as 22 Price Observation rows of Observed Price Type Bid and "
               "Ask from the consolidated feed, directly, because DP-143 publishes approved prices and not observations; "
               "DP-143 is therefore not listed upstream. Acceptance question 5 (plan section 8.5): answered by Price "
               "Improvement Rate by Venue, Average Price Improvement Per Share by Venue, Effective Over Quoted Spread by "
               "Venue, Price Improvement Amount (from DP-301) and Routed NBBO Differs From 22 Quote; mastering domains 48, 22. "
               "Tailoring lever: Rule 605 scope. Reference default: 100,000 or more customers, Rule 605 lines kept; a "
               "smaller firm keeps Execution Quality Measure only (48 lever 7). Tailoring lever: payment for order flow. "
               "Reference default: none accepted; if accepted, Rule 606 Net Payment for Order Flow becomes a monitored "
               "conflict measure (48 lever 2). Taxonomy gap: 22 has no NBBO quote snapshot object (consolidated best bid "
               "and offer at a timestamp for an instrument); the snapshot is approximated by 22 Price Observation Bid and "
               "Ask rows and checked against the 48 NBBO Bid At Route and NBBO Offer At Route. Taxonomy gap: Execution "
               "Quality Measure has no Measured Order Count by size bucket or notional size, so venue comparisons cannot be "
               "size-adjusted outside Rule 605. Taxonomy gap: Order Routing Disclosure Request has no due date. Regulatory "
               "values: SEC Rules 605 and 606 (as amended in 2024), FINRA Rule 5310 Supplementary Material .09. Drafting "
               "assumptions: the seven-business-day response target for Rule 606(b) requests; the one-second quote match "
               "window and USD 0.005 tolerance; the best-execution Supervisory Review Type value. Decisions: CW-100, CW-115, "
               "CW-176, CW-234. WP1 new (CW-234): new consumer product of the BWO brief; takes the Execution Quality Measure "
               "object and the execution-quality measures from DP-432 (F3 fix pass) and adds the 22 quote snapshot."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-437": dict(
        definition=("Every trade correction (cancel, correct, cancel and rebill, as-of trade, venue bust) with the "
                    "superseded and resulting confirmations, and every trade error case with its cause, severity, gain or "
                    "loss and whether the client was made whole, joined to the orders, executions and allocations they "
                    "change. It answers which client orders were corrected and why, and hands error losses to the 37 "
                    "operational loss event without booking them. It reads the correction and confirmation facts from "
                    "DP-301 and the 48 Trade Error Case directly, and owns no certified metric family."),
        business_questions=[
            "Which client orders were corrected this month, by correction type, reason, order source and order type (acceptance question 5)?",
            "What is the correction rate per 10,000 allocations, and what share of corrections were as-of trades?",
            "Which trade errors occurred, by cause and severity, what did they cost, and was every affected client made whole?",
            "Which error losses have no operational loss event in 37, and which error cases are still open and how old are they?",
            "Which corrections lack an approver or a correctly superseding confirmation?",
        ],
        grain=("Trade correction (TCORR-) and trade error case (case number) as the two main rows, each joined to the client "
               "order, execution and allocation it concerns and to the superseded and resulting confirmation versions; "
               "monthly snapshot of open error cases; append-only"),
        dimensions=["Client account (DP-093)", "Order source and client order type (DP-301)", "Correction type and correction reason",
                    "Trade error cause and severity", "Venue (DP-432)", "Approver (DP-192)", "Operational loss event (37, DP-215)",
                    "Trade date and correction month (DP-013)"],
        measures=[
            ("Trade Corrections (from DP-301)", "Count of Trade Correction rows by Correction Type and Trade Correction Reason for the period, as DP-301 publishes them.",
             _u("48", "Trade Correction", "Trade Correction ID", "Correction Type", "Trade Correction Reason", "Corrected Client Allocation")),
            ("Corrected Client Orders", "Count of distinct Client Orders whose Client Allocation (Allocated Client Order of the Corrected Client Allocation) has at least one Trade Correction in the period, by Order Source, Client Order Type and Correction Type: the corrected orders of acceptance question 5.",
             _u("48", "Client Allocation", "Allocated Client Order", "Allocated Account", "Allocated Quantity") + _u("48", "Client Order", "Client Order ID", "Order Source") + _u("48", "Order Instruction Detail", "Client Order Type") + ["Trade Corrections (from DP-301)"]),
            ("Corrections per 10,000 Allocations (from DP-301)", "Trade Corrections (from DP-301) / count of Client Allocation rows with Allocation Timestamp in the period x 10,000, by Correction Type; the DP-301 value is read and shown by correction reason and order source here.",
             _u("48", "Client Allocation", "Allocation Timestamp") + ["Trade Corrections (from DP-301)"]),
            ("As-Of Trade Share", "Trade Correction rows with As-Of Trade Indicator = Y / Trade Corrections (from DP-301), by month.",
             _u("48", "Trade Correction", "As-Of Trade Indicator") + ["Trade Corrections (from DP-301)"]),
            ("Corrections Without Approver", "Count of Trade Correction rows whose Correction Approved By is blank, by Correction Type.",
             _u("48", "Trade Correction", "Correction Approved By", "Correction Type")),
            ("Resulting Confirmations Not Superseding", "Count of Trade Correction rows whose Resulting Confirmation has Confirmation Type other than Corrected, Cancel or As-Of, or a blank Superseded Confirmation, or an Originating Trade Correction that does not name the correction.",
             _u("48", "Trade Correction", "Resulting Confirmation") + _u("48", "Client Trade Confirmation", "Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type", "Superseded Confirmation", "Originating Trade Correction")),
            ("Venue Busts by Venue", "Count of Trade Correction rows with Correction Type = Venue Bust or Trade Correction Reason = Clearly Erroneous Execution, by Execution Venue MIC of the Corrected Client Execution (DP-432 venue).",
             _u("48", "Trade Correction", "Corrected Client Execution", "Correction Type", "Trade Correction Reason") + _u("48", "Client Execution", "Client Execution ID", "Execution Venue MIC")),
            ("Trade Error Cases Opened", "Count of Trade Error Case rows with Error Detected Date in the period, by Trade Error Cause and Error Severity, covering a client order, a client block order or a missed instruction.",
             _u("48", "Trade Error Case", "Trade Error Case Number", "Error Detected Date", "Trade Error Cause", "Error Severity", "Error Client Order", "Error Client Block Order", "Missed Instruction Description")),
            ("Trade Error Gain or Loss", "Sum of Error Gain or Loss Amount of Trade Error Case rows by Trade Error Cause, shown separately for losses (negative) and gains; an operational amount, never booked here.",
             _u("48", "Trade Error Case", "Error Gain or Loss Amount", "Trade Error Cause") + ["Trade Error Cases Opened"]),
            ("Client Made Whole Rate", "Trade Error Case rows with an Error Account and Client Made Whole Indicator = Y / Trade Error Case rows with an Error Account and Error Case Status closed, by Trade Error Cause.",
             _u("48", "Trade Error Case", "Error Account", "Client Made Whole Indicator", "Error Case Status")),
            ("Open Error Cases by Age", "Count of Trade Error Case rows with Error Case Status not closed, by age bucket from Error Detected Date (0 to 5, 6 to 30, over 30 days) and Error Severity.",
             _u("48", "Trade Error Case", "Error Case Status", "Error Detected Date", "Error Severity")),
            ("Error Losses Without Loss Event", "Count and Error Gain or Loss Amount of loss cases (Error Gain or Loss Amount below zero) whose Related Loss Event is blank or does not resolve to a 37 Operational Loss Event; and Trade Error Gain or Loss minus the Impact Amount of the linked loss events, which should tie.",
             _u("48", "Trade Error Case", "Related Loss Event", "Error Gain or Loss Amount") + _u("37", "Operational Loss Event", "Loss Event ID", "Impact Amount", "Loss Status") + ["Trade Error Gain or Loss"]),
            ("Error Cases Without Correction", "Count of Trade Error Case rows on a client order or block whose number is named by no Trade Correction.Related Trade Error Case, by Trade Error Cause.",
             _u("48", "Trade Correction", "Related Trade Error Case") + _u("48", "Trade Error Case", "Trade Error Case Number", "Trade Error Cause")),
        ],
        inputs=[
            ("48", "Trade Correction", ["Trade Correction ID", "Corrected Client Execution", "Corrected Client Allocation", "Correction Type",
                                        "Trade Correction Reason", "Fields Corrected", "Correction Approved By", "As-Of Trade Indicator",
                                        "Resulting Confirmation", "Related Trade Error Case"]),
            ("48", "Trade Error Case", ["Trade Error Case Number", "Error Client Order", "Error Client Block Order", "Missed Instruction Description",
                                        "Error Detected Date", "Trade Error Cause", "Error Severity", "Error Account", "Error Account Quantity",
                                        "Error Gain or Loss Amount", "Client Made Whole Indicator", "Related Loss Event", "Error Case Status"]),
            ("48", "Client Trade Confirmation", ["Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type", "Confirmed Client Allocation",
                                                 "Superseded Confirmation", "Originating Trade Correction"]),
            ("48", "Client Allocation", ["Allocation Client Block Order", "Allocated Client Order", "Allocated Account", "Allocated Quantity", "Allocation Timestamp"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Execution Venue MIC", "Execution Trade Date"]),
            ("48", "Client Order", ["Client Order ID", "Order Account", "Order Source", "Client Order Status"]),
            ("48", "Order Instruction Detail", ["Client Order Type"]),
            ("37", "Operational Loss Event", ["Loss Event ID", "Impact Amount", "Loss Status"]),
        ],
        upstream=["DP-301", "DP-432", "DP-093", "DP-215", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="Corrections and error cases of business day D by 9am ET on D+1; monthly rates by business day 3 after month-end",
        history="Corrections, confirmations and error cases kept six years (SEC Rule 17a-4(b)); monthly snapshots kept 25 months; append-only",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Corrected Client Allocation, Corrected Client Execution and Resulting Confirmation resolves to the DP-301 record it names, every Error Account and Allocated Account to a DP-093 account, and every Related Loss Event to a 37 Operational Loss Event published by DP-215.",
            "A Resulting Confirmation's Confirmation Version is higher than the version it supersedes, the Confirmed Trade Date of a Resulting Confirmation is on or before the date its Trade Correction is loaded, and Error Detected Date is on or after the Execution Trade Date of the Corrected Client Execution of any correction that names the error case.",
            "For each month the Trade Corrections read equal DP-301 Trade Corrections for the same month, and Trade Error Gain or Loss of closed loss cases ties to the Impact Amount of their linked loss events within USD 1.",
            "Correction Type and Corrected Client Allocation are populated on every Trade Correction, and Trade Error Cause, Error Detected Date and Error Case Status on every Trade Error Case.",
            "Account-level correction and error rows are visible only to trading operations, supervision and operational risk roles; Missed Instruction Description is shown only in that view.",
            "Corrections and error cases of business day D are loaded by 9am ET on D+1, and closed error cases are never reopened in place (a reopening is a new case referencing the old one).",
        ],
        notes=("Certified numbers: none; Error Gain or Loss Amount is an operational amount and losses are booked in 37 "
               "(CW-100). PII tier: financial. Boundaries: corrections and confirmations are published by DP-301, and the "
               "correction rate is DP-301's (read 'from DP-301'); the 48 Trade Error Case is read directly because no "
               "foundation publishes it. Loss events stay in 37 (Related Loss Event) and DP-215 publishes them; this product "
               "never books the loss and DP-215 does not read this product. Confirmation remuneration and trade reporting "
               "are DP-438's; execution quality DP-436's; fund desk trade errors are 25's (DP-215 reads them). Acceptance "
               "question 5 (plan section 8.5): answered by Corrected Client Orders and Corrections per 10,000 Allocations "
               "(from DP-301); mastering domains 48 (the 22 part of the question is DP-436's quote snapshot). Tailoring "
               "lever: error account practice. Reference default: errors booked to the firm error account and the client "
               "made whole on every loss; a de minimis threshold is the alternative. Taxonomy gap: Trade Correction has no "
               "correction timestamp or correction date, so the correction month is taken from the Resulting "
               "Confirmation's trade date and as-of corrections cannot be aged precisely. Taxonomy gap: Trade Error Case has "
               "no closed date, so case age stops only at the snapshot that shows the status closed. Drafting assumptions: "
               "the closed Error Case Status values; the age buckets; the USD 1 tolerance. Decisions: CW-096, CW-098, "
               "CW-100, CW-115. WP1 new (CW-235): new consumer product of the BWO brief."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-438": dict(
        definition=("The SEC Rule 10b-10 confirmation record by version, with commission, regulatory fees and the markup or "
                    "markdown disclosure of FINRA Rule 2232 and MSRB Rule G-15, joined to the 13 confirmation delivery and to "
                    "the TRF, TRACE and RTRS reports of each execution. It shows which confirmations were sent late or not at "
                    "all, which lack a required markup disclosure or rest on a doubtful prevailing market price, which were "
                    "superseded, and which trade reports were late, rejected or missing. It reads the confirmations from "
                    "DP-301, the deliveries from DP-382 and the disclosure and trade-report objects of 48 directly, and owns "
                    "no certified metric family."),
        business_questions=[
            "Which confirmations were not delivered by the end of the business day after the trade, and which allocations have no confirmation delivery at all?",
            "Which in-scope fixed income confirmations lack the markup or markdown disclosure, and how does the prevailing market price compare with the approved price?",
            "What markups were charged, by security type and prevailing market price basis?",
            "Which TRF, TRACE and RTRS reports were late or rejected, and which reportable executions have no trade report?",
            "Which confirmations were superseded by a correction, and which fund orders lack a breakpoint basis?",
        ],
        grain=("Client trade confirmation version (CCONF-; client allocation x confirmation version) with its remuneration "
               "disclosure and delivery, and regulatory trade report (client execution x facility x submission) as companion "
               "facts; daily, append-only"),
        dimensions=["Client account (DP-093)", "Instrument (DP-097)", "Confirmation type and version", "Execution capacity",
                    "Markup disclosure scope condition and exception", "Prevailing market price basis", "Trade reporting facility",
                    "Trade report status", "Share class (DP-004)", "Trade date and settlement date (DP-013)"],
        measures=[
            ("Confirmations Issued (from DP-301)", "Count of Client Trade Confirmation rows by Confirmation Type and Confirmed Trade Date, as DP-301 publishes them, with Commission Charged and Regulatory Transaction Fees summed.",
             _u("48", "Client Trade Confirmation", "Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type", "Confirmed Trade Date", "Commission Charged", "Regulatory Transaction Fees")),
            ("Confirmations Delivered Late", "Count of confirmations whose 13 Confirmation Delivery (from DP-382) has Confirmation Sent Date after the business day following Confirmed Trade Date, or after Confirmed Settlement Date, excluding Periodic Confirmation Indicator = Y (SEC Rule 10b-10(a): at or before completion of the transaction; 10b-10(b) periodic statements).",
             _u("13", "Confirmation Delivery", "Client Trade Confirmation", "Confirmation Sent Date", "Confirmation Timing") + _u("48", "Client Trade Confirmation", "Confirmed Trade Date", "Confirmed Settlement Date", "Periodic Confirmation Indicator")),
            ("Allocations Without Confirmation Delivery", "Count of Client Trade Confirmation rows of the latest version with no 13 Confirmation Delivery by the end of Confirmed Settlement Date, by Confirmation Type.",
             _u("13", "Confirmation Delivery", "Client Trade Confirmation") + _u("48", "Client Trade Confirmation", "Confirmed Client Allocation", "Confirmed Settlement Date") + ["Confirmations Issued (from DP-301)"]),
            ("Markup Disclosures Required", "Count of confirmations whose Confirmation Remuneration Disclosure has Markup Disclosure Scope Condition = In Scope and no Markup Disclosure Exception, by Confirmed Capacity (principal retail fixed income trades offset the same day; FINRA Rule 2232(c), MSRB Rule G-15(a)(i)(A)(1)(f)).",
             _u("48", "Confirmation Remuneration Disclosure", "Markup Disclosure Scope Condition", "Markup Disclosure Exception") + _u("48", "Client Trade Confirmation", "Confirmed Capacity")),
            ("Markup Disclosures Missing", "Markup Disclosures Required with Markup Markdown Amount, Markup Markdown Percentage or Trade Data Hyperlink blank.",
             _u("48", "Confirmation Remuneration Disclosure", "Markup Markdown Amount", "Markup Markdown Percentage", "Trade Data Hyperlink") + ["Markup Disclosures Required"]),
            ("Average Markup Percentage", "Confirmed Quantity-weighted average of Markup Markdown Percentage over Markup Disclosures Required, by Instrument Type (DP-097) and Prevailing Market Price Basis.",
             _u("48", "Confirmation Remuneration Disclosure", "Markup Markdown Percentage", "Prevailing Market Price Basis") + _u("48", "Client Trade Confirmation", "Confirmed Quantity", "Confirmed Instrument") + _u("17", "Instrument", "Instrument Type") + ["Markup Disclosures Required"]),
            ("Prevailing Market Price Off Approved Price", "Count of disclosures whose Prevailing Market Price differs from the Approved Price Value of the 22 Approved Price named in Reference Approved Price (from DP-143) by more than 2 percent, by Prevailing Market Price Basis (FINRA Rule 2121.02 waterfall).",
             _u("48", "Confirmation Remuneration Disclosure", "Prevailing Market Price", "Reference Approved Price", "Prevailing Market Price Basis") + _u("22", "Approved Price", "Approved Price ID", "Approved Price Value", "Price Date")),
            ("Confirmations Superseded", "Count of Client Trade Confirmation rows with Superseded Confirmation populated / Confirmations Issued (from DP-301), by Confirmation Type, with the Originating Trade Correction (DP-437).",
             _u("48", "Client Trade Confirmation", "Superseded Confirmation", "Originating Trade Correction") + ["Confirmations Issued (from DP-301)"]),
            ("Equity Confirmations Without Order Flow Statement", "Count of agency equity confirmations (Confirmed Capacity Agency) with Order Flow Remuneration Statement blank (SEC Rule 10b-10(a)(2)(i)(C)); under the reference default the statement says none is received.",
             _u("48", "Client Trade Confirmation", "Order Flow Remuneration Statement", "Confirmed Capacity")),
            ("Regulatory Trade Reports Late", "Count of Regulatory Trade Report rows with Late Report Indicator = Y, by Trade Reporting Facility and Reported Capacity (TRACE and RTRS within 15 minutes, TRF within 10 seconds of execution).",
             _u("48", "Regulatory Trade Report", "Reported Client Execution", "Trade Reporting Facility", "Report Submission Timestamp", "Late Report Indicator", "Reported Capacity")),
            ("Regulatory Trade Reports Rejected", "Count of Regulatory Trade Report rows with Trade Report Status = Rejected and no later Accepted or Corrected submission for the same Reported Client Execution and Trade Reporting Facility.",
             _u("48", "Regulatory Trade Report", "Trade Report Status", "Reported Client Execution", "Trade Reporting Facility", "Facility Control Number")),
            ("Reportable Executions Without Trade Report", "Count of Client Execution rows of orders whose Fixed Income Order Detail has Trade Reporting Eligibility set, or of OTC equity executions in principal capacity, with no Regulatory Trade Report (Reported Client Execution).",
             _u("48", "Fixed Income Order Detail", "Trade Reporting Eligibility", "New Issue Order Indicator") + _u("48", "Client Execution", "Client Execution ID", "Execution Order Route", "Execution Capacity") + _u("48", "Regulatory Trade Report", "Reported Client Execution")),
            ("Fund Orders Without Breakpoint Basis", "Count of client orders with a Fund Order Detail whose Fund Order Share Class carries a front-end sales charge (DP-004) and whose Breakpoint Basis Amount is blank (FINRA Rule 2342 breakpoint obligations).",
             _u("48", "Fund Order Detail", "Fund Order Share Class", "Breakpoint Basis Amount", "Transaction Fee Category Applied") + _u("01", "Share Class", "Share Class ID", "Share Class Type")),
        ],
        inputs=[
            ("48", "Client Trade Confirmation", ["Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type", "Confirmed Client Allocation",
                                                 "Confirmation Account", "Confirmed Instrument", "Confirmed Trade Date", "Confirmed Settlement Date",
                                                 "Confirmed Quantity", "Confirmed Price", "Confirmed Capacity", "Accrued Interest Amount", "Commission Charged",
                                                 "Regulatory Transaction Fees", "Net Amount", "Order Flow Remuneration Statement", "Periodic Confirmation Indicator",
                                                 "Superseded Confirmation", "Originating Trade Correction"]),
            ("48", "Confirmation Remuneration Disclosure", ["Markup Markdown Amount", "Markup Markdown Percentage", "Prevailing Market Price",
                                                            "Prevailing Market Price Basis", "Reference Approved Price",
                                                            "Markup Disclosure Scope Condition", "Markup Disclosure Exception",
                                                            "Trade Data Hyperlink"]),
            ("48", "Regulatory Trade Report", ["Reported Client Execution", "Trade Reporting Facility", "Report Submission Timestamp", "Facility Control Number",
                                               "Reported Capacity", "Trade Report Status", "Late Report Indicator"]),
            ("48", "Fixed Income Order Detail", ["Yield Limit", "New Issue Order Indicator", "Trade Reporting Eligibility"]),
            ("48", "Fund Order Detail", ["Fund Order Share Class", "Breakpoint Basis Amount", "Transaction Fee Category Applied"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Execution Capacity", "Execution Timestamp"]),
            ("13", "Confirmation Delivery", ["Client Trade Confirmation", "Confirmation Timing", "Confirmation Sent Date"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Price Date", "Approved Price Value"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("01", "Share Class", ["Share Class ID", "Share Class Type"]),
        ],
        upstream=["DP-301", "DP-382", "DP-143", "DP-097", "DP-004", "DP-093", "DP-013"],
        refresh="Daily",
        timeliness="Confirmations and deliveries of trade date T by 9am ET on T+2; trade report status of T by 9am ET on T+1",
        history="Confirmation versions, disclosures and trade reports kept six years (SEC Rule 17a-4(b)); delivery evidence kept with the confirmation; append-only",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Confirmation Account resolves to an active DP-093 account, every Confirmed Instrument to a DP-097 instrument, every Fund Order Share Class to a DP-004 share class, every Reference Approved Price to a DP-143 approved price and every Reported Client Execution to a DP-301 execution.",
            "Confirmation Version numbers of one Confirmed Client Allocation are unique and increasing, and Confirmed Settlement Date is on or after Confirmed Trade Date.",
            "For each trade date the confirmations read equal the DP-301 confirmations of that date, and Net Amount equals Confirmed Quantity x Confirmed Price plus or minus Commission Charged, Regulatory Transaction Fees and accrued interest within USD 0.01.",
            "Confirmation Type, Confirmed Capacity and Commission Charged are populated on every confirmation, Markup Disclosure Scope Condition on every principal fixed income confirmation, and Trade Report Status on every trade report.",
            "Account-level confirmation rows are visible only to brokerage operations, supervision and client service roles; confirmation and markup aggregates published more widely carry no account key.",
            "Every confirmation of trade date T is loaded with its delivery status by 9am ET on T+2, and a published confirmation version is never changed in place.",
        ],
        notes=("Certified numbers: none; Commission Charged is an operational billed amount and client fee revenue is DP-012's. "
               "PII tier: financial. Boundaries: the confirmation is 48's and its delivery 13's (CW-081, CW-098); DP-301 "
               "publishes the confirmation facts and DP-382 the deliveries; the 48 Confirmation Remuneration Disclosure, "
               "Regulatory Trade Report, Fixed Income Order Detail and Fund Order Detail are read directly because no "
               "foundation publishes them. Commission rates are 47's (DP-305), not read: the 47 Commission Fee Schedule key "
               "is left to DP-346. Corrections are DP-437's. Tailoring lever: fixed income capacity. Reference default: "
               "principal riskless trades with markup disclosure; agency fixed income blanks the markup fields (48 lever "
               "6). Tailoring lever: payment for order flow. Reference default: none, stated on the confirmation (48 lever "
               "2). Taxonomy gap: Regulatory Trade Report has no execution timestamp of its own, so Late Report Indicator "
               "is taken as set by 48 rather than recomputed from the execution time. Taxonomy gap: 13 Confirmation "
               "Delivery has no delivery method or failure status, so a delivery that bounced is not distinguished. "
               "Regulatory values: SEC Rule 10b-10; FINRA Rules 2232, 2121.02 and 2342; MSRB Rule G-15; FINRA Rule 6730 "
               "(TRACE, 15 minutes), the TRF 10-second rule (FINRA Rule 6282 and 6380 series) and MSRB Rule G-14 (RTRS). "
               "Drafting assumptions: the 2 percent prevailing-price tolerance; the front-end sales charge Share Class Type "
               "values; the T+1 delivery test. Decisions: CW-081, CW-096, CW-098, CW-100, CW-115. WP1 new (CW-235): new "
               "consumer product of the BWO brief."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-446": dict(
        definition=("The daily stock record reconciliations of the broker-dealer by type (depository, own-fund omnibus at the "
                    "transfer agent, program-bank sweep, OCC, Fed book-entry, bank custodian) with every break, its cause, "
                    "owner, age and short-difference status, and the quarterly SEC Rule 17a-13 security counts with the "
                    "differences found and recorded. It is where the 49 Sweep Balance is shown to equal the 50 Sweep "
                    "Allocations, and the 49 own-fund client holdings to equal the 29 broker-dealer omnibus register. It "
                    "reads the 49 reconciliation and count objects directly, the client books from DP-300, the allocations "
                    "from DP-302, the program banks from DP-431 and the register from DP-580, and owns no certified metric "
                    "family."),
        business_questions=[
            "Which stock record reconciliations are not reconciled today, by type and control location, and which breaks are open, how old, and whose?",
            "Which short stock record differences are open, and which have passed seven business days unresolved?",
            "Does every account's Sweep Balance equal the sum of its program-bank Sweep Allocations, and do program-bank allocation totals equal the bank daily totals?",
            "Do own-fund client holdings in brokerage accounts equal the broker-dealer omnibus shares on the 29 register for each share class?",
            "Was every control location counted this quarter, and were count differences recorded within seven business days?",
        ],
        grain=("Stock record reconciliation (type x business date x control location or sweep program) with its breaks (break "
               "sequence) as companion rows, account x program bank x business date for the sweep tie, share class x "
               "business date for the omnibus tie, and broker-dealer x quarter x control location x count date for security "
               "counts; daily snapshots"),
        dimensions=["Reconciliation type", "Control location party and type (DP-240)", "Sweep Program and Program Bank (DP-431)",
                    "Share class (DP-004)", "Instrument (DP-097)", "Break cause and status", "Break owner and count performer (DP-192)",
                    "Client account (DP-093)", "Broker-dealer (DP-013)", "Business date and count quarter (DP-013)"],
        measures=[
            ("Reconciliations Performed", "Count of Stock Record Reconciliation rows per Reconciliation Business Date, by Stock Record Reconciliation Type and Stock Record Reconciliation Status.",
             _u("49", "Stock Record Reconciliation", "Reconciliation Broker-Dealer", "Stock Record Reconciliation Type", "Reconciliation Business Date", "Stock Record Reconciliation Status")),
            ("Reconciliations Not Reconciled", "Reconciliations Performed with Stock Record Reconciliation Status in (Break Open, Not Reconciled), by type and Reconciled Control Location or Reconciled Sweep Program.",
             _u("49", "Stock Record Reconciliation", "Stock Record Reconciliation Status", "Reconciled Control Location", "Reconciled Sweep Program") + ["Reconciliations Performed"]),
            ("Reconciliations Without Sign-Off", "Reconciliations Performed whose Reconciliation Signed Off By is blank at the end of the business day after Reconciliation Business Date.",
             _u("49", "Stock Record Reconciliation", "Reconciliation Signed Off By") + ["Reconciliations Performed"]),
            ("Open Stock Record Breaks", "Count of Stock Record Break rows with Break Status in (Open, Under Investigation) and the sums of absolute Break Quantity Difference and Break Amount Difference, by reconciliation type, Break Cause and Break Instrument.",
             _u("49", "Stock Record Break", "Break Reconciliation", "Break Sequence", "Break Instrument", "Break Quantity Difference", "Break Amount Difference", "Break Cause", "Break Status")),
            ("Break Age", "DP-013 business days from Break Open Date to the as-of date for open breaks (to Break Resolution Date for resolved ones), by bucket (0 to 2, 3 to 7, over 7 business days).",
             _u("49", "Stock Record Break", "Break Open Date", "Break Resolution Date", "Break Status")),
            ("Open Short Stock Record Differences", "Open Stock Record Breaks with Short Stock Record Difference Indicator = Y, with those older than seven business days flagged: unresolved short differences that net capital must charge (SEC Rule 15c3-1(c)(2)(v)) and possession or control must cover (SEC Rule 15c3-3(h), DP-445).",
             _u("49", "Stock Record Break", "Short Stock Record Difference Indicator") + ["Open Stock Record Breaks", "Break Age"]),
            ("Breaks Without Owner", "Open Stock Record Breaks with Break Owner blank.",
             _u("49", "Stock Record Break", "Break Owner") + ["Open Stock Record Breaks"]),
            ("Sweep Balance to Allocation Breaks", "Count of accounts and sum of absolute difference where the 49 Cash Balance Amount of Cash Balance Type = Sweep Balance (from DP-300) differs from the sum of Allocated Balance of the account's 50 Sweep Allocation rows (from DP-302) for the same business date by more than USD 0.01 (CW-102), by Balance Sweep Program.",
             _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Type", "Cash Balance Business Date", "Cash Balance Amount", "Balance Sweep Program") + _u("50", "Sweep Allocation", "Allocation Account", "Allocation Program Bank", "Allocation Business Date", "Allocated Balance")),
            ("Program Bank Allocation to Daily Total Difference", "Sum of Allocated Balance of Sweep Allocation rows per Allocation Program Bank and business date minus Aggregate Customer Deposits of the 50 Program Bank Daily Total of that bank and date (from DP-431), by Daily Total Sweep Program.",
             _u("50", "Sweep Allocation", "Allocation Program Bank", "Allocated Balance") + _u("50", "Program Bank Daily Total", "Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date", "Aggregate Customer Deposits")),
            ("Own-Fund Omnibus Share Difference", "Per own share class and business date: sum of Settled Quantity of End of Day 49 Client Holding rows with Own Share Class Indicator = Y (from DP-300; Held Instrument resolved to its Own Share Class in DP-097) minus Registered Shares of 29 Share Register Balance rows with Register Account Category = Broker-Dealer Omnibus (from DP-580), by more than 0.001 shares.",
             _u("49", "Client Holding", "Held Instrument", "Client Holding Date", "Client Holding View", "Settled Quantity", "Own Share Class Indicator") + _u("17", "Instrument", "Instrument ID", "Own Share Class") + _u("29", "Share Register Balance", "Register Account", "Register Share Class", "Register Business Date", "Register Account Category", "Registered Shares")),
            ("Control Locations Not Counted This Quarter", "Count of 49 Control Location rows with Control Location Approval Status = Approved effective in the quarter that have no Security Count with Counted Control Location naming them and Count Date in the quarter (SEC Rule 17a-13(b): the examination, count, verification and comparison at least once in each calendar quarter, with the physical count under (b)(1)).",
             _u("49", "Control Location", "Control Location Party", "Control Location Type", "Control Location Approval Status", "Location Effective From", "Location Effective To") + _u("49", "Security Count", "Counted Control Location", "Count Quarter", "Count Date")),
            ("Count Differences Not Recorded in Time", "Count of Security Count rows with Differences Found Count above zero whose Differences Recorded Date is blank or more than seven business days after Count Date (SEC Rule 17a-13(b)(5): unresolved differences recorded within seven business days), with Short Difference Market Value.",
             _u("49", "Security Count", "Differences Found Count", "Differences Recorded Date", "Count Date", "Short Difference Market Value")),
            ("Count Short Difference Market Value", "Sum of Short Difference Market Value of Security Count rows of the quarter, by Count Broker-Dealer, Count Type and Counted Control Location.",
             _u("49", "Security Count", "Count Broker-Dealer", "Count Type", "Counted Control Location", "Short Difference Market Value", "Securities Counted Count")),
        ],
        inputs=[
            ("49", "Stock Record Reconciliation", ["Reconciliation Broker-Dealer", "Stock Record Reconciliation Type", "Reconciliation Business Date",
                                                   "Reconciled Control Location", "Reconciled Register Balances", "Reconciled Sweep Program",
                                                   "Breaks Open Count", "Stock Record Reconciliation Status", "Reconciliation Signed Off By"]),
            ("49", "Stock Record Break", ["Break Reconciliation", "Break Sequence", "Break Instrument", "Break Account", "Break Quantity Difference",
                                          "External Quantity", "Break Amount Difference", "Break Cause", "Break Open Date",
                                          "Short Stock Record Difference Indicator", "Break Owner", "Break Resolution Date", "Break Status"]),
            ("49", "Security Count", ["Count Broker-Dealer", "Count Quarter", "Counted Control Location", "Count Type", "Count Date",
                                      "Securities Counted Count", "Differences Found Count", "Short Difference Market Value",
                                      "Differences Recorded Date", "Count Performed By"]),
            ("49", "Control Location", ["Control Location Party", "Control Location Type", "Control Location Approval Status", "Location Effective From",
                                        "Location Effective To"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Type", "Cash Balance Business Date", "Balance Basis", "Cash Balance Amount",
                                            "Balance Sweep Program"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View",
                                      "Settled Quantity", "Own Share Class Indicator"]),
            ("50", "Sweep Allocation", ["Allocation Account", "Allocation Program Bank", "Allocation Business Date", "Allocated Balance"]),
            ("50", "Program Bank Daily Total", ["Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date", "Aggregate Customer Deposits"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date", "Register Account Category", "Registered Shares"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Own Share Class"]),
        ],
        upstream=["DP-300", "DP-302", "DP-431", "DP-580", "DP-097", "DP-240", "DP-093", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="Reconciliations, breaks and the sweep and omnibus ties of business date D by 10am ET on D+1; security counts within one business day of the count",
        history="Daily reconciliation and break history kept six years; security counts and difference records kept at least three years, the first two easily accessible (SEC Rules 17a-4(b) and 17a-13); append-only",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Reconciled Control Location and Counted Control Location resolves to an approved 49 Control Location whose party is active in DP-240, every Reconciled Sweep Program and Allocation Program Bank to DP-431, every Break Account and Cash Balance Account to a DP-093 account, and every Break Instrument to DP-097.",
            "Control Location effective periods of one party and type do not overlap, Break Resolution Date is on or after Break Open Date, and Differences Recorded Date is on or after Count Date.",
            "For every business date the sum of Sweep Allocation Allocated Balance equals the sum of 49 Sweep Balance cash balances within USD 0.01 per account, the number of open breaks of each reconciliation equals its Breaks Open Count, and own-fund client holdings equal the Broker-Dealer Omnibus register shares within 0.001 shares per share class unless an open break explains the difference.",
            "Stock Record Reconciliation Type, Reconciliation Business Date and Stock Record Reconciliation Status are populated on every reconciliation, Break Quantity Difference and Break Status on every break, and Count Date and Differences Found Count on every security count.",
            "Break Account and the account-level sweep tie are visible only to brokerage operations and the financial and operations principal; published reconciliation and count views aggregate to reconciliation type, control location and program bank.",
            "The reconciliations of business date D are complete for every reconciliation type in use by 10am ET on D+1, and a signed-off reconciliation is never changed in place.",
        ],
        notes=("Certified numbers: none; the sweep and omnibus ties are operational proofs of the books, and Client Assets "
               "is DP-008's. Operating model (CD-297, CD-331): self-clearing; the grain is the firm's own stock record. "
               "Under fully disclosed clearing it becomes oversight of the clearing firm's received reconciliations "
               "(CW-235). PII tier: financial (Break Account and the account-level sweep tie, restricted, DQ5); counts and "
               "control locations carry no personal data. Boundaries: the 49 Stock Record Reconciliation, Stock Record "
               "Break, Security Count and Control Location are read directly because no foundation publishes them; the "
               "client books come from DP-300, the Sweep Allocation side from DP-302 (F3 ruling: DP-446 lists DP-302 for "
               "Sweep Allocation, because DP-302 does not read the 49 Reconciled Sweep Balance key), the Sweep Program, "
               "Program Bank and Program Bank Daily Total from DP-431, and the 29 register from DP-580. Possession or "
               "control is DP-445's; the omnibus proof to the register on the TA side is FOP DP-177 and DP-178's. Tailoring "
               "lever: own-fund account model at the TA. Reference default: omnibus at the in-house TA reconciled daily; "
               "networked accounts replace the omnibus reconciliation type (49 lever 4). Tailoring lever: sweep vehicle. "
               "Reference default: money market fund sweep by default with bank sweep by account type; a fund-only sweep "
               "removes the program-bank tie (50 lever 3). Taxonomy gap: Security Count has no attribute stating that the "
               "count was performed by persons without custody responsibility (SEC Rule 17a-13(b): counts made or supervised"
               " by persons whose regular duties do not include custody of the securities or keeping the records; paragraph "
               "to confirm against the eCFR), so independence is not testable. Taxonomy gap: Stock Record Reconciliation has"
               " no register-share total or tolerance (Reconciled Register Balances is only a reference), so the omnibus tie"
               " is recomputed from DP-300 and DP-580. Drafting assumptions: the USD 0.01 and 0.001-share tolerances; the "
               "seven-business-day short difference window; the break age buckets. Decisions: CW-101, CW-102, CW-115, "
               "CW-122, CW-235. WP1 new (CW-235): new consumer product of the BWO brief."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-447": dict(
        definition=("Street settlement obligations by clearing channel (NSCC CNS, DTC trade-for-trade, OCC, Fed book-entry, "
                    "Fund/SERV, the own-fund omnibus at the transfer agent) against actual settlement, and client settlement "
                    "fails with their close-out deadlines, resolutions and the freeriding restrictions they cause. Cage and "
                    "settlement staff work Regulation SHO, Regulation T and Rule 15c3-3(m) close-outs from it. It reads the "
                    "49 Street Settlement Obligation and Client Settlement Fail directly, the postings from DP-300 and the "
                    "own-fund settlement obligations from DP-580, and owns no certified metric family."),
        business_questions=[
            "Which street obligations failed to settle on contractual settlement date, by clearing channel, and how old are the fails?",
            "Which client fails must be closed out today, and which are past their close-out deadline, by fail type?",
            "How were fails resolved (paid, delivered, liquidated, bought in, extended), and which liquidations have no close-out order?",
            "Which accounts were restricted for freeriding after a Regulation T liquidation, and is every restriction in force?",
            "Do own-fund omnibus street obligations agree with the transfer agent's settlement obligations?",
        ],
        grain=("Settling broker-dealer x clearing channel x instrument x contractual settlement date for street obligations, "
               "and client account activity x fail type for client fails; daily snapshot of open obligations and fails"),
        dimensions=["Clearing channel", "Clearing counterparty (DP-240)", "Instrument (DP-097)", "Client account (DP-093)", "Fail type",
                    "Fail resolution", "Street settlement status", "Settling broker-dealer (DP-013)", "Contractual settlement date and close-out deadline (DP-013)"],
        measures=[
            ("Street Obligations Due", "Count of Street Settlement Obligation rows and sum of Net Settlement Amount with Contractual Settlement Date on the business date, by Clearing Channel and Settling Broker-Dealer.",
             _u("49", "Street Settlement Obligation", "Settling Broker-Dealer", "Clearing Channel", "Obligation Instrument", "Contractual Settlement Date", "Net Obligation Quantity", "Net Settlement Amount")),
            ("Street Settlement Rate %", "Street Obligations Due with Actual Settlement Date equal to Contractual Settlement Date / Street Obligations Due, by Clearing Channel.",
             _u("49", "Street Settlement Obligation", "Actual Settlement Date", "Contractual Settlement Date") + ["Street Obligations Due"]),
            ("Open Street Fails", "Count and Net Settlement Amount of Street Settlement Obligation rows with Street Settlement Status in (Open, Partially Settled, Failed) after Contractual Settlement Date, by Clearing Channel, Clearing Counterparty and age in business days.",
             _u("49", "Street Settlement Obligation", "Street Settlement Status", "Clearing Counterparty", "Contractual Settlement Date", "Net Settlement Amount")),
            ("Own-Fund Street to TA Settlement Difference", "For Clearing Channel = Own-Fund Omnibus at Transfer Agent (29): Net Settlement Amount of the street obligation minus Obligation Amount of the 29 Settlement Obligation named in Own-Fund Settlement Obligation (from DP-580), with the 29 Obligation Settlement Status.",
             _u("49", "Street Settlement Obligation", "Own-Fund Settlement Obligation", "Net Settlement Amount", "Clearing Channel") + _u("29", "Settlement Obligation", "Settlement Obligation ID", "Obligation Amount", "Contractual Settlement Date", "Obligation Settlement Status", "Actual Settlement Date")),
            ("Open Client Fails", "Count and sum of Fail Amount of Client Settlement Fail rows with Fail Case Status not closed, by Fail Type (Reg T 220.8 failure to pay, Rule 15c3-3(m) failure to deliver a long sale, Reg SHO Rule 204 short sale close-out).",
             _u("49", "Client Settlement Fail", "Failed Client Activity", "Fail Type", "Fail Start Date", "Fail Quantity", "Fail Amount", "Fail Case Status")),
            ("Close-Outs Due Today", "Open Client Fails with Close-Out Deadline on the business date, by Fail Type.",
             _u("49", "Client Settlement Fail", "Close-Out Deadline", "Fail Type") + ["Open Client Fails"]),
            ("Close-Outs Past Deadline", "Open Client Fails with Close-Out Deadline before the business date and Fail Resolved Date blank, with days past deadline, by Fail Type.",
             _u("49", "Client Settlement Fail", "Close-Out Deadline", "Fail Resolved Date", "Fail Type") + ["Open Client Fails"]),
            ("Fails Resolved by Resolution", "Count and Fail Amount of Client Settlement Fail rows with Fail Resolved Date in the period, by Fail Resolution and Fail Type, with average days from Fail Start Date to Fail Resolved Date.",
             _u("49", "Client Settlement Fail", "Fail Resolution", "Fail Resolved Date", "Fail Start Date", "Fail Type", "Fail Amount")),
            ("Liquidations Without Close-Out Order", "Fails with Fail Resolution in (Liquidated (Sell-Out), Bought In) whose Close-Out Client Order is blank or does not resolve to a DP-301 Client Order with Order Source Regulation SHO Close-Out or Margin Liquidation.",
             _u("49", "Client Settlement Fail", "Fail Resolution", "Close-Out Client Order") + _u("48", "Client Order", "Client Order ID", "Order Source")),
            ("Freeriding Restrictions in Force", "Count of fails with Fail Type = Customer Failure to Pay (Reg T 220.8) resolved by liquidation whose Freeriding Restriction resolves to a 15 Account Restriction (from DP-093) effective for 90 calendar days from the liquidation (Regulation T 220.8(c)); a liquidation without such a restriction is an exception.",
             _u("49", "Client Settlement Fail", "Freeriding Restriction", "Fail Type", "Fail Resolution") + _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Type", "Account Restriction Effective From", "Account Restriction Lifted Date")),
            ("Client Fail Rate per 1,000 Settlements", "Count of Client Settlement Fail rows with Fail Start Date in the period / posted 49 Client Account Activity rows of trade Activity Types (Buy, Sell, Sell Short, Buy to Cover) with Settlement Date in the period (from DP-300) x 1,000, by Fail Type.",
             _u("49", "Client Settlement Fail", "Fail Start Date", "Fail Type") + _u("49", "Client Account Activity", "Client Account Activity ID", "Activity Account", "Activity Type", "Settlement Date", "Activity Status")),
            ("Activity Pending Past Settlement Date", "Count and Activity Net Amount of 49 Client Account Activity rows of trade Activity Types with Activity Status = Pending and Settlement Date before the business date, by Activity Type.",
             _u("49", "Client Account Activity", "Activity Status", "Settlement Date", "Activity Type", "Activity Net Amount")),
        ],
        inputs=[
            ("49", "Street Settlement Obligation", ["Settling Broker-Dealer", "Clearing Channel", "Own-Fund Settlement Obligation", "Clearing Counterparty",
                                                    "Obligation Instrument", "Contractual Settlement Date", "Net Obligation Quantity",
                                                    "Net Settlement Amount", "Actual Settlement Date", "Street Settlement Status"]),
            ("49", "Client Settlement Fail", ["Failed Client Activity", "Fail Type", "Fail Start Date", "Fail Quantity", "Fail Amount", "Close-Out Deadline",
                                              "Fail Resolution", "Close-Out Client Order", "Freeriding Restriction", "Fail Resolved Date",
                                              "Fail Case Status"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Type", "Activity Instrument", "Trade Date",
                                               "Settlement Date", "Activity Net Amount", "Activity Status"]),
            ("29", "Settlement Obligation", ["Settlement Obligation ID", "Obligation Fund Order", "Obligation Amount", "Contractual Settlement Date",
                                             "Order Settlement Method", "Obligation Settlement Status", "Actual Settlement Date"]),
            ("48", "Client Order", ["Client Order ID", "Order Source"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type", "Account Restriction Effective From",
                                           "Account Restriction Lifted Date"]),
        ],
        upstream=["DP-300", "DP-580", "DP-301", "DP-093", "DP-097", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Street obligations and client fails of business date D by 7am ET on D+1, before the Regulation SHO close-out window opens",
        history="Daily obligation and fail snapshots kept six years (SEC Rule 17a-4(b)); fail resolutions and close-out orders kept with the fail; append-only",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Failed Client Activity resolves to a DP-300 Client Account Activity, every Obligation Instrument to DP-097, every Clearing Counterparty to an active DP-240 party, every Own-Fund Settlement Obligation to a DP-580 Settlement Obligation and every Freeriding Restriction to a DP-093 Account Restriction.",
            "Fail Resolved Date and Close-Out Deadline are on or after Fail Start Date, Actual Settlement Date is on or after Contractual Settlement Date less one business day, and a client activity has at most one open fail per Fail Type.",
            "For every own-fund omnibus obligation Net Settlement Amount equals the DP-580 Obligation Amount within USD 0.01, and an obligation with Street Settlement Status Settled has an Actual Settlement Date.",
            "Clearing Channel, Contractual Settlement Date and Street Settlement Status are populated on every street obligation, and Fail Type, Fail Amount and Close-Out Deadline on every client fail.",
            "Account-level fail rows are visible only to cage, settlement, margin and supervision roles; street obligations carry no personal data and are published firm-wide.",
            "The snapshot of business date D is complete by 7am ET on D+1, before close-outs due on D+1 are worked, and a resolved fail is never reopened in place.",
        ],
        notes=("Certified numbers: none. Operating model (CD-297, CD-331): self-clearing; under fully disclosed clearing the"
               " clearing firm settles and the product is withdrawn (CW-235). PII tier: financial for client fails "
               "(restricted, DQ5); street obligations carry no personal data. Boundaries: the 49 Street Settlement "
               "Obligation and Client Settlement Fail are read directly because DP-300 does not publish them; the postings "
               "are DP-300's and the own-fund settlement cash stays 29's (DP-580, CW-102); close-out orders are DP-301's, "
               "margin calls DP-600's (from backlog DP-450), account restrictions 15's (DP-093). Tailoring lever: clearing "
               "model. Reference default: self-clearing. Tailoring lever: margin. Reference default: offered to approved "
               "non-retirement accounts; without margin the Reg T failure to pay remains for cash accounts (49 lever 6). "
               "Taxonomy gap: Client Settlement Fail has no extension request or extension approval attribute, so a "
               "Regulation T 220.8(d) extension is visible only as Fail Resolution Extension Granted. Taxonomy gap: Street "
               "Settlement Obligation has no fail start or age attribute; age is counted from Contractual Settlement Date. "
               "Regulatory values: Regulation SHO Rule 204 (close out by market open of T+1 after settlement date for short "
               "sales, T+3 for long sales), Regulation T 220.8 (payment period and the 90-day freeze), SEC Rule 15c3-3(m) "
               "(10 business days after settlement date), SEC Rule 15c6-1 (T+1). Drafting assumptions: the closed Fail Case "
               "Status values; the trade Activity Types counted as settlements; the USD 0.01 tolerance. Decisions: CW-101, "
               "CW-102, CW-115, CW-235. WP1 new (CW-235): new consumer product of the BWO brief."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-448": dict(
        definition=("Every account transfer in and out (ACATS full, partial and residual credit, non-ACATS, internal "
                    "re-registration) with its validation and settlement dates, rejects, asset lines, non-transferable "
                    "assets, debit balances and the IRC section 6045A cost basis statement due and sent or received. It "
                    "shows cycle time against the FINRA Rule 11870 time frames, reject rates by contra firm and reason, and "
                    "the transferred value by direction as an operational value, set beside Net New Assets read from DP-008. "
                    "It reads transfers and statements from DP-300, the asset lines from 49 directly and the originating "
                    "service request from DP-381, and owns no certified metric family."),
        business_questions=[
            "How many transfers came in and went out this month, by channel and contra firm, and what value did they carry?",
            "Which transfers were rejected, for what reason and by which contra firm, and what is the reject rate?",
            "Which incoming transfers were validated or settled outside the FINRA Rule 11870 time frames?",
            "Which assets could not be transferred, and which cost basis transfer statements are late or missing?",
            "What share of Net New Assets did account transfers carry, without relabeling transfer value as NNA?",
        ],
        grain=("Account transfer (ACXF-) with its asset lines (transfer x asset line sequence) and cost basis transfer "
               "statements (transfer x direction x version) as companion facts, joined to the originating service request; "
               "daily snapshot of open transfers"),
        dimensions=["Client account (DP-093)", "Transfer direction and channel", "Transfer status and reject reason", "Contra firm (DP-240)",
                    "Instrument (DP-097)", "Non-transferable reason", "Statement direction", "Distribution channel (DP-008)",
                    "Request, validation and settlement dates (DP-013)"],
        measures=[
            ("Transfers Initiated", "Count of Account Transfer rows by Transfer Direction, Transfer Channel and month of the Received Timestamp of the Originating Service Request (from DP-381).",
             _u("49", "Account Transfer", "Account Transfer ID", "Transfer Account", "Transfer Direction", "Transfer Channel", "Originating Service Request") + _u("13", "Service Request", "Service Request ID", "Received Timestamp", "Request Type")),
            ("Account Transfers by Status (from DP-300)", "Count of Account Transfer rows with Transfer Status in (Requested, Validated, Settlement Pending) on the as-of date, with age since Validation Date, and count of rows with Transfer Status = Settled and Transfer Settlement Date in the period, by Transfer Direction and Transfer Channel, exactly as DP-300 defines it.",
             _u("49", "Account Transfer", "Account Transfer ID", "Transfer Account", "Transfer Status", "Transfer Direction", "Transfer Channel", "Validation Date", "Transfer Settlement Date")),
            ("Transfer Reject Rate %", "Account Transfer rows with Transfer Status = Rejected / Transfers Initiated, by Transfer Reject Reason, Contra Firm and Transfer Direction.",
             _u("49", "Account Transfer", "Transfer Status", "Transfer Reject Reason", "Contra Firm") + ["Transfers Initiated"]),
            ("Transfers In Validated Within One Business Day %", "Transfer In ACATS transfers (Transfer Direction = Transfer In) whose Validation Date is no later than one DP-013 business day after the Received Timestamp of the Originating Service Request, the transfer request the firm received from its client / Transfer In ACATS transfers validated. This is the receiving-side view only: FINRA Rule 11870(b) puts the one-business-day validation duty on the carrying firm, whose Transfer Out rows arrive as an ACATS transfer initiation without a firm service request and cannot be timed (taxonomy gap).",
             _u("49", "Account Transfer", "Validation Date", "Transfer Channel", "Transfer Direction", "Originating Service Request") + _u("13", "Service Request", "Service Request ID", "Received Timestamp") + ["Transfers Initiated"]),
            ("Settled Within Three Business Days of Validation %", "ACATS transfers settled in the period (Account Transfers by Status (from DP-300), Settled) whose Transfer Settlement Date is no later than three DP-013 business days after Validation Date / ACATS transfers settled in the period, by Transfer Direction and Contra Firm (FINRA Rule 11870: completion within three business days after validation).",
             _u("49", "Account Transfer", "Transfer Settlement Date", "Validation Date", "Contra Firm") + ["Account Transfers by Status (from DP-300)"]),
            ("Transfer Cycle Days", "Median and 90th percentile of DP-013 business days from the originating request's Received Timestamp to Transfer Settlement Date, by Transfer Channel and Transfer Direction.",
             _u("49", "Account Transfer", "Transfer Settlement Date", "Transfer Channel") + _u("13", "Service Request", "Received Timestamp") + ["Account Transfers by Status (from DP-300)"]),
            ("Transfer Value by Direction", "Sum over Account Transfer Asset Line rows of settled transfers of Transfer Asset Quantity x the Approved Price Value of the instrument on the Transfer Settlement Date (from DP-143), plus Transfer Cash Amount, by Transfer Direction and Transfer Channel: an operational transfer value, never labeled Net New Assets (CW-230).",
             _u("49", "Account Transfer Asset Line", "Line Account Transfer", "Asset Line Sequence", "Transfer Asset Instrument", "Transfer Asset Quantity", "Transfer Cash Amount") + _u("22", "Approved Price", "Approved Price ID", "Priced Instrument", "Price Date", "Approved Price Value") + ["Account Transfers by Status (from DP-300)"]),
            ("Net Transfer Value", "Transfer Value by Direction of Transfer In minus that of Transfer Out for the period, excluding Internal Re-Registration.",
             ["Transfer Value by Direction"]),
            ("Net New Assets (from DP-008)", "Measure Amount of the DP-008 Measure Value with Measure MSR-NNA (Net New Assets) for the Period End Date at Dimension Type Total and Dimension Key ALL, in the locked DP-008 Snapshot; read, never recomputed.",
             _u("06", "Measure Value", *_MV) + _u("06", "Client Asset Measures", "Net New Assets") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Net Transfer Value Share of Net New Assets", "Net Transfer Value / Net New Assets (from DP-008) for the same period, firm total only (transfer value carries no channel, so no channel cut is published): the share of NNA that account transfers carry, a ratio shown beside the certified figure and never added to it.",
             ["Net Transfer Value", "Net New Assets (from DP-008)"]),
            ("Non-Transferable Asset Lines", "Count of Account Transfer Asset Line rows with Non-Transferable Reason populated, by reason and Transfer Direction, with their Transfer Asset Quantity.",
             _u("49", "Account Transfer Asset Line", "Non-Transferable Reason", "Transfer Asset Quantity") + _u("49", "Account Transfer", "Transfer Direction")),
            ("Debit Balances Transferred", "Count of transfers and sum of Debit Balance Transferred with a non-zero value, by Transfer Direction.",
             _u("49", "Account Transfer", "Debit Balance Transferred", "Transfer Direction")),
            ("Asset Lines Without Resulting Activity", "Count of asset lines of settled transfers whose Resulting Activity is blank one business day after Transfer Settlement Date: assets transferred but not booked in 49.",
             _u("49", "Account Transfer Asset Line", "Resulting Activity") + ["Account Transfers by Status (from DP-300)"]),
            ("Late Cost Basis Transfer Statements (from DP-300)", "Count of Cost Basis Transfer Statement rows with Transfer Statement Direction = Sent whose Statement Sent or Received Date is after Statement Due Date, or is blank with Statement Due Date before the as-of date (IRC section 6045A), exactly as DP-300 defines it.",
             _u("49", "Cost Basis Transfer Statement", "Statement Account Transfer", "Transfer Statement Direction", "Statement Due Date", "Statement Sent or Received Date")),
            ("Inbound Cost Basis Statements Late or Missing", "This product's addition to the DP-300 count: Cost Basis Transfer Statement rows with Transfer Statement Direction = Received whose Statement Sent or Received Date is blank after Statement Due Date or later than it, and settled Transfer In transfers with an asset line whose Line Cost Basis Transfer Statement is blank 15 days after Transfer Settlement Date (Treas. Reg. 1.6045A-1), by Statement Counterparty Firm.",
             _u("49", "Cost Basis Transfer Statement", "Transfer Statement Direction", "Statement Due Date", "Statement Sent or Received Date", "Statement Counterparty Firm", "Noncovered Security Notice Indicator") + _u("49", "Account Transfer Asset Line", "Line Cost Basis Transfer Statement") + ["Account Transfers by Status (from DP-300)"]),
        ],
        inputs=[
            ("49", "Account Transfer", ["Account Transfer ID", "Transfer Account", "Transfer Direction", "Transfer Channel", "Contra Firm", "ACATS Control Number",
                                        "Validation Date", "Transfer Settlement Date", "Transfer Reject Reason", "Debit Balance Transferred",
                                        "Originating Service Request", "Transfer Status"]),
            ("49", "Account Transfer Asset Line", ["Line Account Transfer", "Asset Line Sequence", "Transfer Asset Instrument", "Transfer Asset Quantity",
                                                   "Transfer Cash Amount", "Non-Transferable Reason", "Line Cost Basis Transfer Statement",
                                                   "Resulting Activity"]),
            ("49", "Cost Basis Transfer Statement", ["Statement Account Transfer", "Transfer Statement Direction", "Statement Version", "Statement Counterparty Firm",
                                                     "Statement Due Date", "Statement Sent or Received Date", "Noncovered Security Notice Indicator"]),
            ("13", "Service Request", ["Service Request ID", "Request Type", "Received Timestamp", "Request Status"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Price Date", "Approved Price Value"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot"]),
            ("06", "Client Asset Measures", ["Net New Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
        ],
        upstream=["DP-300", "DP-381", "DP-008", "DP-143", "DP-093", "DP-097", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Transfer status of business date D by 7am ET on D+1; monthly values after the DP-008 snapshot of the month is locked",
        history="Transfers, asset lines and statements kept six years (SEC Rule 17a-4(b)); 6045A statements kept with the transfer; daily snapshots kept 25 months",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Transfer Account resolves to a DP-093 account, every Contra Firm and Statement Counterparty Firm to a DP-240 party, every Transfer Asset Instrument to DP-097, every Originating Service Request to DP-381 and every Resulting Activity to a DP-300 Client Account Activity.",
            "Transfer Settlement Date is on or after Validation Date, and each Cost Basis Transfer Statement version of one transfer and direction is unique.",
            "Net New Assets (from DP-008) equals the DP-008 published Measure Amount of the same snapshot and dimension, and the count of transfers read equals DP-300 Account Transfers by Status for the same date.",
            "Transfer Direction, Transfer Channel, Transfer Status and Validation Date are populated on every validated transfer, and Transfer Asset Quantity or Transfer Cash Amount on every asset line.",
            "Contra Firm Account Number is not read and ACATS Control Number is shown only to transfer operations; aggregate views by contra firm carry no account key.",
            "Transfer status of business date D is complete by 7am ET on D+1, and monthly values are published only after the DP-008 snapshot of the month is locked.",
        ],
        notes=("Certified numbers: reads Net New Assets from DP-008 (CW-011, CW-142); Transfer Value by Direction and Net "
               "Transfer Value are operational transfer values and never labeled NNA (CW-230). PII tier: financial (contra "
               "account numbers not read). Boundaries: DP-300 publishes Account Transfer and Cost Basis Transfer Statement "
               "and this product owns the transfer work queues and cycle measures; Account Transfer Asset Line is read "
               "directly because no foundation publishes it; the service request is DP-381's; the NNA treatment of "
               "transfers is DP-008's flow treatment rule. Lot detail and 1099-B readiness stay with DP-300 (backlog DP-417 "
               "and DP-449). Tailoring lever: fractional shares on transfers out. Reference default: liquidated and "
               "sent as cash; fractional delivery where the contra firm accepts it (49 lever 8). Tailoring lever: "
               "valuation of transferred assets. Reference default: the 22 approved price of the settlement date. Taxonomy "
               "gap: Account Transfer has no request received date and no ACATS transfer initiation (TIF) receipt "
               "timestamp; the Received Timestamp of the 13 Originating Service Request times Transfer In rows, and Transfer "
               "Out rows, where the Rule 11870(b) validation duty falls, cannot be timed. "
               "Taxonomy gap: Account Transfer Asset Line has no transferred value, so value is computed from the "
               "approved price. Regulatory values: FINRA Rule 11870 (validate within one business day, complete within "
               "three business days after validation); IRC section 6045A and Treas. Reg. 1.6045A-1 (15 days). Drafting "
               "assumptions: ACATS channels are ACATS Full, ACATS Partial and ACATS Residual Credit; Internal "
               "Re-Registration is excluded from net value. Decisions: CW-011, CW-101, CW-115, CW-142, CW-230. WP1 new "
               "(CW-230): new consumer product of the BWO brief."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-452": dict(
        definition=("Client entitlements for each 17 corporate action event (record-date quantity, cash and securities "
                    "entitled, withholding, cash in lieu, payment), dividend reinvestment allocations and voluntary "
                    "elections against the internal deadline with defaults applied, together with option exercise "
                    "instructions and OCC assignment allocations. Reorganization and options staff work unelected positions, "
                    "unpaid entitlements, late exercises and late assignment notices from it. It reads entitlements from "
                    "DP-300, events from DP-099 and the 49 election and reinvestment and 48 options objects directly, and "
                    "owns no certified metric family."),
        business_questions=[
            "Which client entitlements are unpaid after their payment date, and which record-date quantities disagree with the 49 holdings?",
            "Which accounts with an entitlement on an open voluntary event have not elected, and which elections arrived after the internal deadline or defaulted?",
            "Which elections were not confirmed by the agent before the market deadline?",
            "Which dividend reinvestments lag the payment date or have no resulting tax lot?",
            "Which exercise instructions arrived after the cut-off or were not booked, and which assignment notices reached clients late?",
        ],
        grain=("Corporate action event (17) x account for the entitlement (CLCAE-), with the reinvestment allocation, the "
               "voluntary elections (entitlement x option x election), the option exercise instructions (account x series x "
               "date) and the assignment allocations (OCC notice x account) as companion facts; daily snapshots"),
        dimensions=["Client account (DP-093)", "Corporate action event, event type and mandatory or voluntary (DP-099)", "Corporate action option (DP-099)",
                    "Instrument and option series (DP-097)", "Entitlement status", "Election status and instruction channel",
                    "Exercise instruction type", "Assignment allocation method", "Record, payment and deadline dates (DP-013)"],
        measures=[
            ("Client Entitlements", "Count of Client Corporate Action Entitlement rows and sums of Entitled Cash Amount and Entitled Securities Quantity, by Corporate Action Event Type and Entitlement Status (from DP-300).",
             _u("49", "Client Corporate Action Entitlement", "Client Corporate Action Entitlement ID", "Entitlement Event", "Entitled Account", "Entitled Cash Amount", "Entitled Securities Quantity", "Entitlement Status") + _u("17", "Corporate Action Event", "Corporate Action Event ID", "Corporate Action Event Type")),
            ("Overdue Corporate Action Entitlements (from DP-300)", "Count and sum of Entitled Cash Amount of Client Corporate Action Entitlement rows with Entitlement Status in (Projected, Confirmed) and Entitlement Payment Date before the as-of date, or Entitlement Status = Paid and Payment Activity blank, exactly as DP-300 defines it; this product adds the cut by Corporate Action Event Type and days overdue.",
             _u("49", "Client Corporate Action Entitlement", "Client Corporate Action Entitlement ID", "Entitlement Event", "Entitled Account", "Entitlement Status", "Entitlement Payment Date", "Payment Activity", "Entitled Cash Amount") + ["Client Entitlements"]),
            ("Record Date Quantity Breaks", "Count of entitlements whose Record Date Client Holding Quantity differs by more than 0.0001 shares from the Settled Quantity of the End of Day 49 Client Holding of the Entitled Account in the Event Instrument on the event Record Date (from DP-300), by Due Bill Indicator.",
             _u("49", "Client Corporate Action Entitlement", "Record Date Client Holding Quantity", "Due Bill Indicator") + _u("17", "Corporate Action Event", "Event Instrument", "Record Date") + _u("49", "Client Holding", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View", "Settled Quantity")),
            ("Withholding and Cash in Lieu", "Sums of Entitlement Withholding Amount, Foreign Tax Withheld Amount and Cash in Lieu Amount of paid entitlements in the period, by event type.",
             _u("49", "Client Corporate Action Entitlement", "Entitlement Withholding Amount", "Foreign Tax Withheld Amount", "Cash in Lieu Amount") + ["Client Entitlements"]),
            ("Dividend Reinvestments", "Count and sum of Reinvested Amount and Reinvested Shares of Dividend Reinvestment Allocation rows with Reinvestment Date in the period, and the average days from Entitlement Payment Date to Reinvestment Date.",
             _u("49", "Dividend Reinvestment Allocation", "Reinvested Amount", "Reinvested Shares", "Reinvestment Price", "Reinvestment Date") + _u("49", "Client Corporate Action Entitlement", "Entitlement Payment Date")),
            ("Reinvestments Without Resulting Lot", "Dividend Reinvestments whose Resulting Client Tax Lot is blank, or whose DRIP Feature Applied does not resolve to a 15 Account Feature in force on the Reinvestment Date (from DP-093).",
             _u("49", "Dividend Reinvestment Allocation", "Resulting Client Tax Lot", "DRIP Feature Applied") + _u("15", "Account Feature", "Account Feature ID", "Feature Type", "Feature Status", "Feature Effective From", "Feature Effective To") + ["Dividend Reinvestments"]),
            ("Voluntary Entitlements Without Election", "Count of entitlements on events with Mandatory Voluntary Type = Voluntary and Corporate Action Announcement Status active that have no Client Voluntary Election, by days to the earliest Internal Election Deadline of their options.",
             _u("17", "Corporate Action Event", "Mandatory Voluntary Type", "Corporate Action Announcement Status") + _u("49", "Client Voluntary Election", "Elected Entitlement", "Internal Election Deadline") + ["Client Entitlements"]),
            ("Elections After Internal Deadline", "Count of Client Voluntary Election rows whose Election Received Timestamp is after Internal Election Deadline, by Election Instruction Channel.",
             _u("49", "Client Voluntary Election", "Election Received Timestamp", "Internal Election Deadline", "Election Instruction Channel")),
            ("Default Option Applied Rate", "Client Voluntary Election rows with Default Option Applied Indicator = Y / Client Voluntary Election rows of the period, by event type and whether the Elected Option is the event's Default Option Indicator option (from DP-099).",
             _u("49", "Client Voluntary Election", "Default Option Applied Indicator", "Elected Option") + _u("17", "Corporate Action Option", "Option Event", "Option Number", "Default Option Indicator")),
            ("Elections Not Confirmed Before Market Deadline", "Count and Elected Quantity of Client Voluntary Election rows whose Election Status is not Confirmed by Agent when the Market Deadline of the Elected Option passes.",
             _u("49", "Client Voluntary Election", "Election Status", "Elected Quantity") + _u("17", "Corporate Action Option", "Market Deadline")),
            ("Exercise Instructions After Cut-Off", "Count of Option Exercise Instruction rows whose Instruction Received Timestamp is later than Exercise Cut-Off Time Applied on the Exercise Date, by Exercise Instruction Type (FINRA Rule 2360(b)(23)(A): contrary instructions by 5:30pm ET on expiration).",
             _u("48", "Option Exercise Instruction", "Exercise Account", "Exercised Option Series", "Exercise Date", "Exercise Instruction Type", "Instruction Received Timestamp", "Exercise Cut-Off Time Applied")),
            ("Exercises Not Booked", "Count and Contracts Instructed of exercise instructions other than Contrary Instruction - Do Not Exercise whose Resulting Exercise Activity is blank one business day after Exercise Date.",
             _u("48", "Option Exercise Instruction", "Contracts Instructed", "Resulting Exercise Activity", "Exercise Instruction Type", "Exercise Date")),
            ("Assignment Notices Late to Clients", "Count of Option Assignment Allocation rows whose Client Notification Timestamp is blank or later than the opening of the business day after Assignment Date, by Assignment Allocation Method (FINRA Rule 2360(b)(23)(C)).",
             _u("48", "Option Assignment Allocation", "OCC Assignment Notice Reference", "Assigned Account", "Assigned Contracts", "Assignment Allocation Method", "Assignment Date", "Client Notification Timestamp")),
            ("Assignments Without Activity", "Option Assignment Allocation rows whose Resulting Assignment Activity is blank one business day after Assignment Date.",
             _u("48", "Option Assignment Allocation", "Resulting Assignment Activity", "Assignment Date")),
        ],
        inputs=[
            ("49", "Client Corporate Action Entitlement", ["Client Corporate Action Entitlement ID", "Entitlement Event", "Entitled Account",
                                                           "Record Date Client Holding Quantity", "Due Bill Indicator", "Entitled Cash Amount",
                                                           "Entitled Securities Quantity", "Entitlement Withholding Amount",
                                                           "Foreign Tax Withheld Amount", "Cash in Lieu Amount", "Entitlement Payment Date",
                                                           "Payment Activity", "Entitlement Status"]),
            ("49", "Dividend Reinvestment Allocation", ["Reinvested Amount", "Reinvestment Price", "Reinvested Shares", "Reinvestment Date",
                                                        "Resulting Client Tax Lot", "DRIP Feature Applied"]),
            ("49", "Client Voluntary Election", ["Elected Entitlement", "Elected Option", "Elected Quantity", "Election Instruction Channel",
                                                 "Election Received Timestamp", "Internal Election Deadline", "Default Option Applied Indicator",
                                                 "Election Status"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View", "Settled Quantity"]),
            ("48", "Option Exercise Instruction", ["Exercise Account", "Exercised Option Series", "Exercise Date", "Exercise Instruction Type",
                                                   "Contracts Instructed", "Exercise Threshold Applied", "Instruction Received Timestamp",
                                                   "Exercise Cut-Off Time Applied", "Resulting Exercise Activity"]),
            ("48", "Option Assignment Allocation", ["OCC Assignment Notice Reference", "Assigned Option Series", "Assigned Account", "Assigned Contracts",
                                                    "Assignment Allocation Method", "Assignment Date", "Client Notification Timestamp",
                                                    "Resulting Assignment Activity"]),
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Event Instrument", "Corporate Action Event Type", "Mandatory Voluntary Type",
                                              "Corporate Action Announcement Status", "Ex-Date", "Record Date", "Corporate Action Payment Date"]),
            ("17", "Corporate Action Option", ["Option Event", "Option Number", "Corporate Action Option Type", "Default Option Indicator", "Market Deadline"]),
            ("15", "Account Feature", ["Account Feature ID", "Feature Account", "Feature Type", "Feature Status", "Feature Effective From", "Feature Effective To"]),
        ],
        upstream=["DP-300", "DP-099", "DP-093", "DP-097", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Entitlements, elections and options activity of business date D by 7am ET on D+1; voluntary election status refreshed at noon ET on deadline days",
        history="Entitlements, elections, reinvestments, exercise instructions and assignment allocations kept six years (SEC Rule 17a-4(b)); daily snapshots kept 25 months; append-only",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Entitlement Event resolves to a DP-099 corporate action event, every Elected Option to a DP-099 option of the same event, every Entitled Account, Exercise Account and Assigned Account to a DP-093 account, and every option series to DP-097.",
            "Entitlement Payment Date is on or after the event Record Date, Reinvestment Date is on or after Entitlement Payment Date, and an entitlement has at most one Client Voluntary Election per option with Election Status not Withdrawn.",
            "For each event the sum of Record Date Client Holding Quantity over entitlements equals the sum of Settled Quantity of the event instrument's End of Day Client Holdings on the Record Date within 0.0001 shares, and paid entitlements have a Payment Activity.",
            "Entitlement Status and Record Date Client Holding Quantity are populated on every entitlement, Election Status and Internal Election Deadline on every election, and Exercise Instruction Type and Instruction Received Timestamp on every exercise instruction.",
            "Account-level rows are visible only to reorganization, options operations and client service roles; Instructing Party is not read.",
            "Elections received by the noon ET refresh on an Internal Election Deadline day are visible by 12:30pm ET, and the D+1 7am ET snapshot is complete for every event with a payment or deadline on D.",
        ],
        notes=("Certified numbers: none. PII tier: financial. Boundaries: event 17 (DP-099), fund entitlements 28, client "
               "entitlements 49 (CW-106); DP-300 publishes the Client Corporate Action Entitlement and Client Holding facts; "
               "Dividend Reinvestment Allocation and Client Voluntary Election (49) and Option Exercise Instruction and "
               "Option Assignment Allocation (48) are read directly because no foundation publishes them (the 48 objects are "
               "moved reads from backlog DP-441, which names this product as its merge target). Cost basis adjustments from "
               "corporate actions stay with DP-300; tax forms are the backlog DP-417's. Operating model: self-clearing; "
               "under fully disclosed clearing the product becomes oversight of received entitlements (CW-235). Tailoring "
               "lever: options offered. Reference default: offered to approved accounts; without options the exercise and "
               "assignment measures drop. Tailoring lever: assignment allocation. Reference default: random (48 Assignment "
               "Allocation Method). Tailoring lever: DRIP basis. Reference default: reinvest at the payable-date price from "
               "the 15 DRIP feature (49 lever 5). Taxonomy gap: Client Voluntary Election has no confirmation-by-agent "
               "timestamp, so confirmation timeliness is read from the status at the market deadline. Taxonomy gap: Option "
               "Exercise Instruction has no OCC exercise-by-exception threshold flag beyond Exercise Threshold Applied. "
               "Regulatory values: FINRA Rule 2360(b)(23) exercise cut-off and allocation of assignments; OCC Rule 805 "
               "exercise by exception. Drafting assumptions: the next-business-day opening for assignment notices; the "
               "active Corporate Action Announcement Status values; the 0.0001-share tolerance. Decisions: CW-101, CW-106, "
               "CW-115, CW-235. WP1 new (CW-235): new consumer product of the BWO brief; takes the backlog DP-441 reads."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-457": dict(
        definition=("Where swept client cash sits and how it moves: the daily sweep runs, the account Sweep Allocations by "
                    "program bank, program bank totals against capacity and concentration, the client rate tiers in force "
                    "beside the net spread read from DP-012, FDIC coverage above the insured limit, and the client cash forecast "
                    "against actual sweep flows. It reads the program and bank masters, daily totals and FDIC assessments "
                    "from DP-431, the allocations from DP-302, the 49 cash balances from DP-300 and the 50 sweep runs and "
                    "cash forecasts directly, and sets the cash and sweep Client Assets read from DP-008 beside them. It owns "
                    "no certified metric family; program revenue is 10's."),
        business_questions=[
            "How much swept cash sits at each program bank today, how concentrated is it, and which banks are near their capacity?",
            "Did every sweep run complete, and how much was swept in and out by program and day?",
            "What client rate does each balance tier pay, and what net spread does DP-012 report for each program bank?",
            "Which clients hold deposits above FDIC coverage at a program bank, and which allocations break a client's bank exclusion or sweep election?",
            "How accurate was the client cash forecast against actual sweep flows, and what share of cash Client Assets is in the bank sweep?",
        ],
        grain=("Sweep program x program bank x business date for the program view, account x program bank x business date for "
               "allocations, sweep program x business date x run cycle for runs, party x ownership category x program bank x "
               "assessment date for FDIC coverage, and forecast x value date x cash flow category x sweep program for the "
               "forecast; daily snapshots"),
        dimensions=["Sweep Program and sweep program type (DP-431)", "Program Bank and allocation priority (DP-431)", "Rate tier basis and balance band",
                    "Client account (DP-093)", "Client party (DP-240)", "FDIC ownership category", "Sweep vehicle type and election",
                    "Client cash flow category", "Business date, value date and forecast as-of date (DP-013)"],
        measures=[
            ("Sweep Runs by Status", "Count of Sweep Run rows per Run Business Date by Run Sweep Program and Sweep Run Status; runs with status Failed or Completed with Exceptions are exceptions.",
             _u("50", "Sweep Run", "Run Sweep Program", "Run Business Date", "Run Cycle Number", "Sweep Run Status")),
            ("Net Sweep Amount", "Sum of Net Sweep Amount of completed Sweep Run rows by Run Sweep Program and Run Business Date (positive into the program).",
             _u("50", "Sweep Run", "Net Sweep Amount", "Sweep Run Status", "Run Sweep Program", "Run Business Date")),
            ("Sweep Allocated Balance (from DP-302)", "Sum of Allocated Balance of Sweep Allocation rows of the Allocation Business Date, by Allocation Program Bank, with Interest Accrued Amount, exactly as DP-302 defines it; this product adds the count of accounts allocated. An operational allocated balance, never labeled Client Assets.",
             _u("50", "Sweep Allocation", "Allocation Account", "Allocation Program Bank", "Allocation Business Date", "Allocated Balance", "Interest Accrued Amount")),
            ("Program Bank Concentration %", "Sweep Allocated Balance (from DP-302) by bank / its total for the program on the business date, with the largest bank's share flagged when above 40 percent.",
             ["Sweep Allocated Balance (from DP-302)"]),
            ("Program Banks Near Capacity", "Count of Program Bank Participation rows effective on the business date whose bank's Aggregate Customer Deposits (Program Bank Daily Total, from DP-431) is at or above 95 percent of Bank Capacity Amount, by Participation Sweep Program and Allocation Priority.",
             _u("50", "Program Bank Participation", "Participation Sweep Program", "Participating Program Bank", "Allocation Priority", "Bank Capacity Amount", "Participation Effective From", "Participation Effective To") + _u("50", "Program Bank Daily Total", "Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date", "Aggregate Customer Deposits")),
            ("Daily Net Flow to Program Banks (from DP-431)", "Sum of Net Flow Amount of Program Bank Daily Total rows of the business date, by program and bank, exactly as DP-431 defines it; shown here with the Settlement Wire IMAD that moved it.",
             _u("50", "Program Bank Daily Total", "Net Flow Amount", "Daily Total Business Date", "Settlement Wire IMAD", "Daily Total Program Bank")),
            ("Balance-Weighted Client Interest Rate", "Sweep Allocated Balance (from DP-302)-weighted average of the Client Interest Rate of the Sweep Rate Tier in force (Tier Effective From to Tier Effective To) whose Tier Lower Bound and Tier Upper Bound bracket the account's balance on the Rate Tier Basis, by sweep program.",
             _u("50", "Sweep Rate Tier", "Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Upper Bound", "Client Interest Rate", "Tier Effective From", "Tier Effective To") + ["Sweep Allocated Balance (from DP-302)"]),
            ("Net Spread (from DP-012)", "Net Spread and Average Swept Balance of the 10 Cash Program Economics row of the sweep program, program bank and economics period, as DP-012 publishes them with Cash Program Revenue; read, never recomputed (CW-156, CW-244), and shown beside the Balance-Weighted Client Interest Rate of the same bank.",
             _u("10", "Cash Program Economics", "Economics Sweep Program", "Economics Program Bank", "Economics Period", "Average Swept Balance", "Net Spread") + ["Balance-Weighted Client Interest Rate"]),
            ("Allocations Against Bank Exclusion or Election", "Count of Sweep Allocation rows with Allocated Balance above zero at a program bank listed in the account's 15 Cash Sweep Election Excluded Program Banks, or on an account whose election in force has Sweep Vehicle Type for a money market fund sweep (from DP-093), and the count with Bank Exclusion Applied = Y.",
             _u("50", "Sweep Allocation", "Bank Exclusion Applied", "Allocation Account", "Allocation Program Bank") + _u("15", "Cash Sweep Election", "Sweep Election Account", "Sweep Vehicle Type", "Elected Sweep Program", "Excluded Program Banks", "Sweep Election Effective From", "Sweep Election Effective To")),
            ("Sweep Balances (from DP-300)", "Sum of Cash Balance Amount of rows with Cash Balance Type = Sweep Balance and Balance Basis = Settlement Date on the as-of date, by Balance Sweep Program, exactly as DP-300 defines it; compared with Sweep Allocated Balance (from DP-302), the break detail being DP-446's.",
             _u("49", "Account Cash Balance", "Cash Balance Type", "Balance Basis", "Cash Balance Amount", "Balance Sweep Program", "Cash Balance Business Date")),
            ("Uninsured Deposits (from DP-431)", "Sum of Uninsured Amount of FDIC Coverage Assessment rows at the latest Assessment Date, by Assessed Program Bank and FDIC Ownership Category, exactly as DP-431 defines it; this product adds Insured Amount beside it.",
             _u("50", "FDIC Coverage Assessment", "Assessed Party", "Assessed Program Bank", "FDIC Ownership Category", "Assessment Date", "Uninsured Amount", "Insured Amount")),
            ("Parties With Uninsured Deposits (from DP-431)", "Count of distinct Assessed Party with Uninsured Amount > 0 at the latest Assessment Date, by Assessed Program Bank, exactly as DP-431 defines it; this product adds the party list with Deposits Through Firm and Client-Declared Direct Deposits, in the client service view only.",
             _u("50", "FDIC Coverage Assessment", "Assessed Party", "Uninsured Amount", "Assessment Date", "Deposits Through Firm", "Client-Declared Direct Deposits", "Pass-Through Recordkeeping Basis")),
            ("Client Cash Forecast Error %", "Absolute difference between Expected Inflow Amount - Expected Outflow Amount of the approved forecast (Forecast Approval Status Approved, latest Forecast As-Of Date before the value date) and the actual Net Sweep Amount, divided by the absolute actual, by Line Sweep Program and Line Value Date.",
             _u("50", "Client Cash Forecast Line", "Line Client Cash Forecast", "Line Value Date", "Line Cash Flow Category", "Line Sweep Program", "Expected Inflow Amount", "Expected Outflow Amount") + _u("50", "Client Cash Forecast", "Client Cash Forecast ID", "Forecast As-Of Date", "Forecast Approval Status") + ["Net Sweep Amount"]),
            ("Forecast Inflow and Outflow by Category", "Sums of Expected Inflow Amount and Expected Outflow Amount of the latest approved forecast by Line Cash Flow Category and Line Value Date for the next ten business days, with Line Data Basis.",
             _u("50", "Client Cash Forecast Line", "Expected Inflow Amount", "Expected Outflow Amount", "Line Cash Flow Category", "Line Data Basis") + _u("50", "Client Cash Forecast", "Forecast Approval Status")),
            ("Client Assets in Cash and Sweep (from DP-008)", "Measure Amount of the DP-008 Measure Value with Measure MSR-CLIENTASSETS (Ending Client Assets), Dimension Type Holding Type and the Dimension Key of the 06 Holding Type Cash and Sweep (CASH_AND_SWEEP, in the OWN_ETF key form) for the Period End Date, in the locked DP-008 Snapshot; read, never recomputed (CW-011).",
             _u("06", "Measure Value", *_MV) + _u("06", "Client Asset Measures", "Ending Client Assets") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Bank Sweep Share of Cash Client Assets", "Sweep Balances (from DP-300) at the period end / Client Assets in Cash and Sweep (from DP-008): the share of certified cash Client Assets held at program banks, a ratio shown beside the certified figure.",
             ["Sweep Balances (from DP-300)", "Client Assets in Cash and Sweep (from DP-008)"]),
        ],
        inputs=[
            ("50", "Sweep Run", ["Run Sweep Program", "Run Business Date", "Run Cycle Number", "Net Sweep Amount", "Sweep Run Status"]),
            ("50", "Sweep Allocation", ["Allocation Account", "Allocation Program Bank", "Allocation Business Date", "Allocated Balance", "Interest Accrued Amount",
                                        "Bank Exclusion Applied"]),
            ("50", "Program Bank Daily Total", ["Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date", "Aggregate Customer Deposits",
                                                "Net Flow Amount", "Settlement Wire IMAD", "Interest Paid by Bank"]),
            ("50", "Program Bank Participation", ["Participation Sweep Program", "Participating Program Bank", "Allocation Priority", "Bank Capacity Amount",
                                                  "Participation Effective From", "Participation Effective To"]),
            ("50", "Sweep Rate Tier", ["Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Upper Bound", "Client Interest Rate",
                                       "Tier Effective From", "Tier Effective To"]),
            ("50", "Sweep Program", ["Sweep Program ID", "Sweep Program Name", "Sweep Program Type", "Program Status"]),
            ("50", "Program Bank", ["Program Bank ID", "Bank Party", "Program Bank Status"]),
            ("50", "FDIC Coverage Assessment", ["Assessed Party", "FDIC Ownership Category", "Assessed Program Bank", "Assessment Date", "Deposits Through Firm",
                                                "Client-Declared Direct Deposits", "Insured Amount", "Uninsured Amount",
                                                "Pass-Through Recordkeeping Basis"]),
            ("50", "Client Cash Forecast", ["Client Cash Forecast ID", "Forecast As-Of Date", "Forecast Approval Status"]),
            ("50", "Client Cash Forecast Line", ["Line Client Cash Forecast", "Line Value Date", "Line Cash Flow Category", "Line Sweep Program",
                                                 "Expected Inflow Amount", "Expected Outflow Amount", "Line Data Basis"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Type", "Balance Basis", "Cash Balance Business Date", "Cash Balance Amount",
                                            "Balance Sweep Program"]),
            ("15", "Cash Sweep Election", ["Sweep Election Account", "Sweep Vehicle Type", "Elected Sweep Program", "Elected Sweep Fund", "Excluded Program Banks",
                                           "Sweep Election Effective From", "Sweep Election Effective To"]),
            ("10", "Cash Program Economics", ["Economics Sweep Program", "Economics Program Bank", "Economics Period", "Average Swept Balance", "Net Spread"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot"]),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
        ],
        upstream=["DP-431", "DP-302", "DP-300", "DP-093", "DP-008", "DP-012", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Sweep runs, allocations and program bank totals of business date D by 9am ET on D+1; FDIC coverage by 9am ET after each assessment; forecasts by 8am ET on the forecast as-of date",
        history="Daily snapshots kept six years (SEC Rule 17a-4); FDIC coverage assessments kept with the pass-through records (12 CFR 330.5); forecasts kept by version for 25 months",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Run Sweep Program, Tier Sweep Program, Line Sweep Program and Allocation Program Bank resolves to an active DP-431 sweep program or program bank, every Allocation Account and Sweep Election Account to a DP-093 account, and every Assessed Party to an active DP-240 party.",
            "Sweep Rate Tier rows of one Tier Sweep Program and Rate Tier Basis do not overlap in balance band or effective period, and Program Bank Participation and Cash Sweep Election effective periods end on or after they start.",
            "For each program bank and business date the sum of Allocated Balance equals the DP-431 Aggregate Customer Deposits within USD 1, and Client Assets in Cash and Sweep (from DP-008) equals the DP-008 published Measure Amount of the same snapshot.",
            "Net Sweep Amount and Sweep Run Status are populated on every run, Allocated Balance on every allocation, Client Interest Rate on every tier and Insured Amount and Uninsured Amount on every FDIC assessment.",
            "Account and party rows (Sweep Allocation, FDIC Coverage Assessment) are visible only to cash programs and client service roles; every other view aggregates to sweep program, program bank, tier and ownership category, and the omnibus deposit account number is not read.",
            "The business date D view is complete by 9am ET on D+1 for every sweep program with a run on D, and approved forecasts are never changed in place (a revision is a new Forecast As-Of Date).",
        ],
        notes=("Certified numbers: reads Ending Client Assets at Holding Type Cash and Sweep from DP-008 (CW-011, CW-142); Sweep "
               "Allocated Balance (from DP-302) and Sweep Balances (from DP-300) are operational balances (CW-230); the "
               "foundation facts (DP-302, DP-300, DP-431) are read exactly as defined and labeled '(from DP-nnn)'; "
               "program revenue and Net Spread are 10's, read from DP-012 (CW-156, CW-244), and DIS DP-497 owns revenue yield. PII tier: financial (account allocations "
               "and FDIC party rows, restricted views, DQ5). Boundaries: the program and bank masters, daily totals and "
               "FDIC assessments are DP-431's (the FDIC read moved from backlog DP-458, which names this product as merge "
               "target, and is now taken through DP-431); the allocations are published by DP-302 and the Sweep Balance by "
               "DP-300; the allocation-to-balance reconciliation is DP-446's (CW-102); the 50 Sweep Run, Client Cash "
               "Forecast and Client Cash Forecast Line are read directly because no foundation publishes them (the forecast "
               "reads moved from backlog DP-461); customer reserve funding and program bank exposure are FOP+CORP DP-600's. "
               "Operating model: self-clearing; under fully disclosed clearing the clearing firm's program applies and the "
               "allocations become received copies (50 lever 1, CW-235). Tailoring lever: program banks. Reference "
               "default: several banks with priority and client exclusions; one bank collapses the bank dimension (50 lever "
               "2). Tailoring lever: sweep vehicle. Reference default: own money market fund by default, bank sweep by "
               "account type or election (50 lever 3). Tailoring lever: thresholds. Reference default: 95 percent capacity "
               "and 40 percent concentration alerts. Taxonomy gap: 50 has no client cash forecast actual or variance "
               "object, so actuals are taken from Sweep Run Net Sweep Amount, which covers swept cash only. Regulatory values: USD 250,000 standard maximum deposit insurance amount (12 "
               "CFR 330.1(o)); pass-through recordkeeping (12 CFR 330.5); sweep program change notice tested in DP-431. Drafting assumptions: the money market fund Sweep Vehicle Type value; the Dimension Key "
               "CASH_AND_SWEEP for the 06 Holding Type Cash and Sweep; the ten-day forecast window. Decisions: CW-102, CW-108, CW-115, CW-142, CW-156, "
               "CW-230, CW-234, CW-244. WP1 new (CW-230): new consumer product of the BWO brief; takes the backlog DP-458 and "
               "DP-461 reads."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-459": dict(
        definition=("Debit cards issued on brokerage cash-management accounts with their status and limits, card "
                    "transactions, checkwriting drafts honored by own money market fund redemptions, and Regulation E error "
                    "notices with provisional credit and investigation deadlines. Card and check operations meet the "
                    "Regulation E clocks and work stopped drafts from it. It reads the card and check payment detail and "
                    "movements from DP-302, the 50 Debit Card and Card Dispute directly, the 15 card feature from DP-093 and "
                    "the redeeming fund orders from DP-580, and owns no certified metric family."),
        business_questions=[
            "Which Regulation E error notices have not received provisional credit within 10 business days, and which investigations are past their due date?",
            "What were the outcomes of card disputes, how much consumer liability was assessed, and what is the dispute rate per 10,000 card transactions?",
            "How many debit cards are active, and which active cards have no card feature in force on the account?",
            "Which card transactions posted on a card that was locked, suspended or reported lost?",
            "Which checkwriting drafts have no settled redeeming fund order?",
        ],
        grain=("Debit card (DCARD-) x business date for the card view, card money movement for transactions, card money "
               "movement x dispute for Regulation E, and check money movement for drafts; daily snapshots of open disputes"),
        dimensions=["Client account (DP-093)", "Cardholder (DP-240)", "Card status", "Issuing program bank (DP-431)", "Regulation E error type",
                    "Dispute outcome and status", "ATM and foreign transaction indicators", "Redeeming fund order and share class (DP-580)",
                    "Business date (DP-013)"],
        measures=[
            ("Debit Cards by Status", "Count of Debit Card rows by Card Status and Issuing Program Bank on the business date.",
             _u("50", "Debit Card", "Debit Card ID", "Card Account", "Card Status", "Issuing Program Bank", "Card Issue Date")),
            ("Active Cards Without Card Feature", "Debit Cards by Status with Card Status = Active whose Card Feature does not resolve to a 15 Account Feature with Feature Status active in force on the business date (from DP-093).",
             _u("50", "Debit Card", "Card Feature") + _u("15", "Account Feature", "Account Feature ID", "Feature Type", "Feature Status", "Feature Effective From", "Feature Effective To") + ["Debit Cards by Status"]),
            ("Card Transaction Amount", "Sum of Movement Amount and count of settled Money Movement rows with Payment Rail = Debit Card Network (from DP-302), by ATM Indicator and Foreign Transaction Indicator of the Card Transaction Detail.",
             _u("50", "Money Movement", "Money Movement ID", "Payment Rail", "Movement Amount", "Money Movement Status") + _u("50", "Card Transaction Detail", "Transaction Debit Card", "ATM Indicator", "Foreign Transaction Indicator", "Card Settlement Date")),
            ("Transactions on Blocked Cards", "Count of card transactions whose Authorization Timestamp is after the card entered Card Status Locked by Client, Suspended or Reported Lost or Stolen.",
             _u("50", "Card Transaction Detail", "Authorization Timestamp", "Transaction Debit Card") + _u("50", "Debit Card", "Card Status")),
            ("Regulation E Error Notices", "Count of Card Dispute rows with Error Notice Date in the period, by Regulation E Error Type.",
             _u("50", "Card Dispute", "Disputed Movement", "Error Notice Date", "Regulation E Error Type")),
            ("Provisional Credit Late", "Regulation E Error Notices with Dispute Status open whose Provisional Credit Date is blank or more than 10 DP-013 business days after Error Notice Date (12 CFR 1005.11(c)(2)), with the Provisional Credit Movement.",
             _u("50", "Card Dispute", "Provisional Credit Date", "Provisional Credit Movement", "Dispute Status", "Error Notice Date") + ["Regulation E Error Notices"]),
            ("Investigations Past Due", "Card Dispute rows with Dispute Status open and Investigation Due Date before the business date, and rows whose Investigation Due Date is more than 45 calendar days (90 for foreign, point-of-sale or new-account transfers) after Error Notice Date (12 CFR 1005.11(c)(3)).",
             _u("50", "Card Dispute", "Investigation Due Date", "Dispute Status", "Error Notice Date") + _u("50", "Card Transaction Detail", "Foreign Transaction Indicator") + ["Regulation E Error Notices"]),
            ("Dispute Outcomes", "Count of closed Card Dispute rows by Dispute Outcome, and the share with Dispute Outcome = No Error - Provisional Credit Reversed.",
             _u("50", "Card Dispute", "Dispute Outcome", "Dispute Status")),
            ("Consumer Liability Assessed", "Sum of Consumer Liability Amount of closed disputes with Regulation E Error Type = Unauthorized Electronic Fund Transfer, by Dispute Outcome, and the count of those with Consumer Liability Amount above USD 50, which a reviewer checks against the 12 CFR 1005.6(b) tiers; the two-business-day window runs from when the client learned of the loss or theft, which the taxonomy does not record (taxonomy gap), so the tier itself is not computed.",
             _u("50", "Card Dispute", "Consumer Liability Amount", "Regulation E Error Type", "Dispute Outcome", "Dispute Status")),
            ("Dispute Rate per 10,000 Card Transactions", "Regulation E Error Notices / count of Card Transaction Amount transactions in the period x 10,000.",
             ["Regulation E Error Notices", "Card Transaction Amount"]),
            ("Checkwriting Drafts Honored", "Count and Movement Amount of Money Movement rows with Payment Rail = Check and Money Movement Type = Checkwriting Draft whose Check Detail has a Redeeming Fund Order, by Drawn-On Program Bank.",
             _u("50", "Check Detail", "Check Number", "Drawn-On Program Bank", "Redeeming Fund Order") + _u("50", "Money Movement", "Money Movement Type", "Movement Amount")),
            ("Drafts Without Settled Redemption", "Checkwriting drafts whose Redeeming Fund Order is blank or resolves to a 29 Fund Order (from DP-580) with Fund Order Status not completed by the business day after presentment.",
             _u("50", "Check Detail", "Redeeming Fund Order") + _u("29", "Fund Order", "Fund Order ID", "Fund Order Status", "Order Share Class", "Requested Amount") + ["Checkwriting Drafts Honored"]),
        ],
        inputs=[
            ("50", "Debit Card", ["Debit Card ID", "Card Account", "Card Feature", "Cardholder", "Issuing Program Bank", "Card Status", "Card Issue Date",
                                  "Daily ATM Withdrawal Limit", "Daily Purchase Limit"]),
            ("50", "Card Transaction Detail", ["Transaction Debit Card", "Merchant Category Code", "Authorization Timestamp", "Card Settlement Date",
                                               "ATM Indicator", "Foreign Transaction Indicator"]),
            ("50", "Card Dispute", ["Disputed Movement", "Error Notice Date", "Regulation E Error Type", "Provisional Credit Date",
                                    "Provisional Credit Movement", "Investigation Due Date", "Dispute Outcome", "Consumer Liability Amount",
                                    "Dispute Status"]),
            ("50", "Check Detail", ["Check Number", "Remote Deposit Capture Indicator", "Drawn-On Program Bank", "Redeeming Fund Order"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Money Movement Type", "Payment Rail", "Movement Amount", "Value Date",
                                      "Money Movement Status"]),
            ("15", "Account Feature", ["Account Feature ID", "Feature Account", "Feature Type", "Feature Status", "Feature Effective From", "Feature Effective To"]),
            ("29", "Fund Order", ["Fund Order ID", "Fund Order Type", "Order Share Class", "Requested Amount", "Fund Order Status"]),
        ],
        upstream=["DP-302", "DP-093", "DP-580", "DP-431", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Cards, card transactions, drafts and disputes of business date D by 7am ET on D+1; Regulation E clocks recomputed by 7am ET each business day",
        history="Card, transaction and dispute records kept at least two years after the dispute closes (12 CFR 1005.13(b)) and six years under SEC Rule 17a-4; daily dispute snapshots kept 25 months",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Card Account resolves to a DP-093 account, every Cardholder to an active DP-240 party, every Issuing Program Bank and Drawn-On Program Bank to DP-431, every Disputed Movement to a DP-302 card money movement and every Redeeming Fund Order to a DP-580 fund order.",
            "Provisional Credit Date and Investigation Due Date are on or after Error Notice Date, and a card has one Card Status at a time with Card Issue Date before any of its transactions.",
            "For each business date the card transactions read equal DP-302 Debit Card Transaction Amount, and the amount of honored drafts equals the Requested Amount of their redeeming fund orders within USD 0.01.",
            "Error Notice Date, Regulation E Error Type, Investigation Due Date and Dispute Status are populated on every dispute, and Card Status on every card.",
            "Masked Card Number, check images and merchant names are not published; account and cardholder rows are visible only to card operations and client service roles.",
            "The Regulation E clocks of every open dispute are recomputed by 7am ET each business day, and a closed dispute is never changed in place.",
        ],
        notes=("Certified numbers: none. PII tier: financial (card and check data restricted; Masked Card Number, Check Image "
               "Reference and Merchant Name not read, DQ5). Boundaries: the 50 card and check payment detail and movements "
               "are DP-302's; Debit Card and Card Dispute are read directly because no foundation publishes them; the card "
               "feature is 15's (CW-111) through DP-093; checkwriting redemptions are 29 fund orders through DP-580; fraud "
               "holds on card movements are DP-456's. Tailoring lever: card and checkwriting. Reference default: "
               "checkwriting on own money market funds and one program-bank debit card; either may be dropped, and "
               "checkwriting through a program bank changes the redeeming fund order link (50 lever 7). Taxonomy gap: "
               "Debit Card has no status-change history or status effective timestamp, so Transactions on Blocked Cards "
               "uses the status on the snapshot of the authorization date. Taxonomy gap: Card Dispute has no "
               "investigation extension reason (foreign, point-of-sale or new account), so the 90-day limit is applied from "
               "Foreign Transaction Indicator only. Taxonomy gap: Card Dispute has no date on which the client learned of the loss or theft of the card, so the 12 CFR 1005.6(b) liability tier cannot be tested. Regulatory values: Regulation E, 12 CFR 1005.11 (10 business days for "
               "provisional credit, 45 or 90 days to investigate), 1005.6(b) liability limits and 1005.13 record "
               "retention. Drafting assumptions: open Dispute Status values; the completed Fund Order Status value. "
               "Decisions: CW-107, CW-111, CW-115. WP1 new (CW-230): new consumer product of the BWO brief."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-460": dict(
        definition=("Money-movement monitoring alerts by scenario with their disposition and escalation to the 38 AML case, "
                    "and payment sanctions screening results with blocked and rejected payments. It measures alert volumes, "
                    "aging, false positive and escalation rates, the movements screened before release, and the blocked "
                    "payments reported. It reads the 50 alert and screening records directly, the movements and their events "
                    "from DP-302 and the AML case key from DP-226, exposes only whether an alert was escalated, as one combined "
                    "value, and never a SAR decision or status (31 CFR 1023.320(e)), and owns no certified metric family."),
        business_questions=[
            "How many money-movement alerts did each scenario generate, how many are open and how old are they?",
            "What are the false positive and escalation rates by scenario, and which escalation links do not resolve to an AML case?",
            "Were all outgoing wires and ACH payments screened against the sanctions lists before release to the rail?",
            "Which potential sanctions matches are pending review, and which payments were blocked or rejected and reported?",
            "How long does it take from alert generation to opening an AML case?",
        ],
        grain=("Money movement monitoring alert (MMALT-) with its movements in scope, and money movement x screening run for "
               "sanctions screening, as the two main rows; daily snapshot of open alerts and pending screenings"),
        dimensions=["Monitoring scenario (alerts other than Elder Exploitation Pattern)", "Alert priority, status and disposition", "Alert reviewer (DP-192)",
                    "Subject party (DP-240)", "Client account (DP-093)", "Screening result and sanctions disposition", "Payment rail and money movement type (DP-302)",
                    "Alert date and screening date (DP-013)"],
        measures=[
            ("Monitoring Alerts Generated", "Count of Money Movement Monitoring Alert rows with Alert Generated Timestamp in the period, by Monitoring Scenario and Alert Priority, excluding Monitoring Scenario = Elder Exploitation Pattern.",
             _u("50", "Money Movement Monitoring Alert", "Money Movement Monitoring Alert ID", "Monitoring Scenario", "Alert Generated Timestamp", "Alert Priority")),
            ("Open Alerts by Age", "Count of alerts with Alert Status other than Resolved / Completed, Closed or Canceled, by age bucket from Alert Generated Timestamp (0 to 10, 11 to 30, over 30 calendar days) and Monitoring Scenario; Alert Status is published only as Open or Closed, because the value Escalated may reveal SAR consideration.",
             _u("50", "Money Movement Monitoring Alert", "Alert Status", "Alert Generated Timestamp", "Monitoring Scenario")),
            ("Alert False Positive Rate", "Alerts with Alert Disposition in (Closed - No Further Action, Closed - Customer Verified) / dispositioned alerts, by Monitoring Scenario.",
             _u("50", "Money Movement Monitoring Alert", "Alert Disposition", "Monitoring Scenario")),
            ("Alert Escalation Rate", "Alerts whose Alert Disposition is any escalation value (the escalation values of the 50 Monitoring Alert Disposition list, including Fraud Confirmed) / dispositioned alerts, by Monitoring Scenario. The disposition is published only as one combined value, Escalated; the value that names a SAR decision never leaves the product, and whether a SAR was filed is not read (31 CFR 1023.320(e)).",
             _u("50", "Money Movement Monitoring Alert", "Alert Disposition", "Monitoring Scenario")),
            ("AML Case Links Unresolved", "Count of alerts whose Escalated AML Case is populated but does not resolve to a 38 AML Case Number published by DP-226: a broken escalation link. The test uses the case key only and never filters on or publishes a disposition value.",
             _u("50", "Money Movement Monitoring Alert", "Escalated AML Case") + _u("38", "AML Case", "AML Case Number")),
            ("Alert to Case Days", "Median calendar days from Alert Generated Timestamp to the Case Opened Date of the Escalated AML Case, by Monitoring Scenario.",
             _u("50", "Money Movement Monitoring Alert", "Alert Generated Timestamp", "Escalated AML Case") + _u("38", "AML Case", "Case Opened Date")),
            ("Alerts per 10,000 Movements", "Monitoring Alerts Generated / count of DP-302 Money Movement rows in scope (Movements in Scope) of the period x 10,000, by Payment Rail.",
             _u("50", "Money Movement Monitoring Alert", "Movements in Scope") + _u("50", "Money Movement", "Money Movement ID", "Payment Rail", "Requested Date") + ["Monitoring Alerts Generated"]),
            ("Alerts Without Reviewer", "Open Alerts by Age whose Alert Reviewer is blank.",
             _u("50", "Money Movement Monitoring Alert", "Alert Reviewer") + ["Open Alerts by Age"]),
            ("Outgoing Payments Released Unscreened", "Count and Movement Amount of outgoing Money Movement rows (Movement Direction Outflow) on Payment Rail Fedwire Funds, International Wire or ACH with a Sent to Rail Money Movement Event and no Payment Sanctions Screening whose Screening Timestamp precedes that event.",
             _u("50", "Money Movement", "Movement Direction", "Movement Amount", "Payment Rail") + _u("50", "Money Movement Event", "Event Movement", "Money Movement Event Type", "Event Timestamp") + _u("50", "Payment Sanctions Screening", "Screened Movement", "Screening Timestamp")),
            ("Potential Matches Pending Review", "Count of Payment Sanctions Screening rows with Screening Result = Potential Match - Under Review and Sanctions Screening Disposition = Pending Review, with hours since Screening Timestamp.",
             _u("50", "Payment Sanctions Screening", "Screening Result", "Sanctions Screening Disposition", "Screening Timestamp")),
            ("Sanctions False Positive Rate", "Screenings with Screening Result = False Positive / screenings whose result was a potential or confirmed match, by Sanctions Lists Screened.",
             _u("50", "Payment Sanctions Screening", "Screening Result", "Sanctions Lists Screened")),
            ("Blocked or Rejected Payments", "Count and Movement Amount of screened movements with Sanctions Screening Disposition in (Blocked, Rejected), by Payment Rail.",
             _u("50", "Payment Sanctions Screening", "Sanctions Screening Disposition", "Screened Movement") + _u("50", "Money Movement", "Movement Amount", "Payment Rail")),
            ("Blocked or Rejected Payments Not Reported", "Blocked or Rejected Payments whose Blocked or Rejected Report is blank ten business days after Screening Timestamp (31 CFR 501.603 and 501.604).",
             _u("50", "Payment Sanctions Screening", "Blocked or Rejected Report", "Screening Timestamp") + ["Blocked or Rejected Payments"]),
        ],
        inputs=[
            ("50", "Money Movement Monitoring Alert", ["Money Movement Monitoring Alert ID", "Monitoring Scenario", "Movements in Scope", "Alert Subject Party",
                                                       "Alert Accounts", "Alert Generated Timestamp", "Alert Priority", "Alert Status",
                                                       "Alert Disposition", "Alert Reviewer", "Escalated AML Case"]),
            ("50", "Payment Sanctions Screening", ["Screened Movement", "Screening Timestamp", "Screened Parties", "Sanctions Lists Screened", "Screening Result",
                                                   "Sanctions Screening Disposition", "Blocked or Rejected Report"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Money Movement Type", "Payment Rail", "Movement Direction", "Movement Amount",
                                      "Requested Date", "Money Movement Status"]),
            ("50", "Money Movement Event", ["Event Movement", "Money Movement Event Type", "Event Timestamp"]),
            ("38", "AML Case", ["AML Case Number", "Case Opened Date"]),
        ],
        upstream=["DP-302", "DP-226", "DP-093", "DP-240", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="Alerts and screenings of business date D by 7am ET on D+1; pending potential matches refreshed hourly during payment cut-off windows",
        history="Alerts, dispositions and screenings kept at least five years (31 CFR 1010.430) and six years under SEC Rule 17a-4; blocked-payment records kept five years after release (31 CFR 501.601)",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard"],
        dq_rules=[
            "Every Alert Subject Party and party in Screened Parties resolves to a DP-240 party, every Alert Accounts entry to a DP-093 account, every Movements in Scope and Screened Movement entry to a DP-302 money movement and every Escalated AML Case to a DP-226 AML case.",
            "A Payment Sanctions Screening Screening Timestamp is on or after the Requested Date of its movement, and a Case Opened Date is on or after the Alert Generated Timestamp of the alert that escalated to it.",
            "For each business date the outgoing wire and ACH movements read equal the DP-302 movements of those rails and direction, and every movement with Sanctions Screening Disposition Blocked has Money Movement Status other than Settled.",
            "Monitoring Scenario, Alert Status and Alert Generated Timestamp are populated on every alert, Alert Disposition on every closed alert, and Screening Result and Sanctions Screening Disposition on every screening.",
            "No output carries SAR Decision, the Alert Disposition value Escalated for SAR Decision or the Alert Status value Escalated: dispositions are published only as Closed or Escalated and statuses only as Open or Closed (31 CFR 1023.320(e)); alerts with Monitoring Scenario Elder Exploitation Pattern are excluded at ingestion; row-level views are visible only to the AML and sanctions compliance roles.",
            "The snapshot of business date D is complete by 7am ET on D+1, and a dispositioned alert is never changed in place.",
        ],
        notes=("Certified numbers: none. PII tier: identity and financial (subject parties, screened names, restricted "
               "classification for AML confidentiality). Boundaries (CW-110): the AML program, cases and SARs are 38's and "
               "DP-226's; this product owns the 50 alert and screening record and reads the AML case only for its number "
               "and opening date, never SAR Decision (31 CFR 1023.320(e)). The 50 Money Movement Monitoring Alert and Payment "
               "Sanctions Screening are read directly: DP-302 publishes only non-special, non-AML alert rows, and the AML "
               "alerts and holds are this product's and DP-226's (F3 ruling). Special category (CD-344): alerts with the "
               "Elder Exploitation Pattern scenario are special category; Monitoring Scenario is read for them only as an "
               "extraction filter that drops the rows at ingestion and is never published for them (the DP-307 and DP-583 "
               "precedent); DP-226 reads them in 38 "
               "under its own restriction, and the related holds are DP-456's. AML holds on movements are not counted "
               "here or in DP-456 (taxonomy gap below). Party screening is 02's (DP-077). Tailoring lever: review "
               "targets. Reference default: alerts dispositioned within 30 calendar days. Taxonomy gap: Money Movement "
               "Monitoring Alert has no disposition date or closed timestamp, so alert aging stops only at the snapshot "
               "where Alert Status closes. Taxonomy gap: no WP1 product publishes AML-type Money Movement Hold rows for "
               "AML operations other than DP-226 through the Related AML Case key, so AML hold duration is not measured. "
               "Regulatory values: 31 CFR 1023.320 (SAR confidentiality), 31 CFR "
               "501.603 and 501.604 (blocked and rejected reports within 10 business days), 31 CFR 1010.430 (five-year "
               "retention). Drafting assumptions: Resolved / Completed, Closed and Canceled as closed Alert Status values; the escalation disposition set; the age buckets; the rails screened. "
               "Decisions: CW-107, CW-110, CW-115, CD-344. WP1 new (CW-230): new consumer product of the BWO brief."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-466": dict(
        definition=("Retirement readiness of the recordkept plans by plan, plan design and participant cohort: participation, "
                    "deferral and automatic-feature effects, default-option and QDIA use, loan and withdrawal leakage, "
                    "vesting, balances, personal rates of return and the take-up of in-plan managed accounts. Workplace "
                    "leadership and plan sponsors use it to judge plan design and nudges. It reads balances from DP-430, "
                    "memberships, elections and plan design from DP-094, model assignments of participant accounts from "
                    "DP-304, Personal Return Value from DP-145 and the 16 loan, distribution, limit and managed-account "
                    "service objects directly, and publishes aggregates only. It owns no certified metric family."),
        business_questions=[
            "What share of eligible employees participate in each plan, at what average deferral rate, and how do plans with automatic enrollment and escalation compare?",
            "How many participants are in the default investment or the QDIA, and how many concentrate their balance in one option?",
            "How much leaks out through loans, hardship and in-service withdrawals, and cash-outs at separation?",
            "What personal rate of return did participants earn, by plan and cohort, as DP-145 computes it?",
            "Which plans offer the participant managed account, on what fiduciary basis, and what share of participants is enrolled?",
        ],
        grain=("Plan x participant cohort (plan entry year and membership status) x as-of month, aggregated from memberships, "
               "elections, balances and distributions; a plan-level companion row for plan design and managed-account "
               "service; monthly snapshots, minimum cell size 10 participants"),
        dimensions=["Retirement plan and plan design (DP-094)", "Participant cohort: plan entry year and membership status", "Enrollment method",
                    "Plan investment option, menu role and share class (DP-004)", "Contribution source", "Distribution type",
                    "Managed account availability and fiduciary basis", "Personal return method and fee basis (DP-145)", "As-of month (DP-013)"],
        measures=[
            ("Participation Rate % (from DP-094)", "Active Participants with a Deferral Election effective on the as-of date whose Pre-Tax Deferral Percentage + Roth Deferral Percentage > 0 / Active Participants, by plan, exactly as DP-094 defines it; this product adds only the cohort cut (plan entry year).",
             _u("16", "Deferral Election", "Election Membership", "Pre-Tax Deferral Percentage", "Roth Deferral Percentage", "Deferral Election Effective From", "Deferral Election Effective To") + _u("16", "Participant Plan Membership", "Plan Entry Date") + ["Active Participants (from DP-094)"]),
            ("Active Participants (from DP-094)", "Count of Participant Plan Membership rows with Membership Status = active on the as-of date, by Membership Plan, exactly as DP-094 defines it; cut here by cohort.",
             _u("16", "Participant Plan Membership", "Membership Status", "Membership Plan", "Membership ID")),
            ("Average Deferral Rate % (from DP-094)", "Mean of Pre-Tax Deferral Percentage + Roth Deferral Percentage over deferring active participants on the as-of date, by plan and Election Source, exactly as DP-094 defines it; cut here by cohort.",
             _u("16", "Deferral Election", "Pre-Tax Deferral Percentage", "Roth Deferral Percentage", "Election Source") + ["Participation Rate % (from DP-094)"]),
            ("Automatic Enrollment Opt-Out Rate", "Memberships with Enrollment Method = Automatic Enrollment and Automatic Enrollment Opt-Out Date populated / memberships with Enrollment Method = Automatic Enrollment, by plan and plan entry year.",
             _u("16", "Participant Plan Membership", "Enrollment Method", "Automatic Enrollment Opt-Out Date")),
            ("Participation by Automatic Feature Design", "Participation Rate % (from DP-094) and Average Deferral Rate % (from DP-094) grouped by the plan's Automatic Enrollment Type, Default Deferral Rate and whether Automatic Escalation Increment is above zero (from DP-094).",
             _u("16", "Deferral & Automatic Features", "Automatic Enrollment Type", "Default Deferral Rate", "Automatic Escalation Increment") + ["Participation Rate % (from DP-094)", "Average Deferral Rate % (from DP-094)"]),
            ("Default Investment Share % (from DP-094)", "Active participants whose Investment Election rows effective on the as-of date all have Default Election Indicator = Y / Active Participants, by plan, exactly as DP-094 defines it; cut here by cohort.",
             _u("16", "Investment Election", "Investment Election Membership", "Default Election Indicator", "Investment Election Effective From", "Investment Election Effective To") + ["Active Participants (from DP-094)"]),
            ("QDIA Balance Share", "Sum of Balance Market Value of Participant Balance rows (from DP-430) in Plan Investment Options with Menu Role = QDIA / total Balance Market Value of the plan on the month-end Valuation Date.",
             _u("16", "Participant Balance", "Balance Membership", "Balance Investment Option", "Valuation Date", "Balance Market Value") + _u("16", "Plan Investment Option", "Investment Option ID", "Menu Plan", "Menu Role", "Offered Share Class")),
            ("Single-Option Concentration", "Share of participants with a balance whose largest Balance Investment Option, other than a Target Date Series Member or QDIA option, holds 90 percent or more of their Balance Market Value.",
             _u("16", "Participant Balance", "Balance Membership", "Balance Investment Option", "Balance Market Value") + _u("16", "Plan Investment Option", "Menu Role")),
            ("Participant Balance Market Value (from DP-430)", "Sum of Balance Market Value of Participant Balance rows of the Valuation Date, by the Membership Plan of Balance Membership, Balance Investment Option and Balance Contribution Source, exactly as DP-430 defines it (a recordkeeping balance, never Client Assets).",
             _u("16", "Participant Balance", "Balance Membership", "Balance Investment Option", "Balance Contribution Source", "Valuation Date", "Balance Market Value") + _u("16", "Participant Plan Membership", "Membership ID", "Membership Plan")),
            ("Average Balance per Participant", "Participant Balance Market Value (from DP-430) / count of distinct Balance Membership with Balance Market Value above zero, by plan and cohort, with the median per participant; this product's cohort statistic.",
             _u("16", "Participant Balance", "Balance Membership", "Balance Market Value") + ["Participant Balance Market Value (from DP-430)"]),
            ("Average Vested Percentage", "Average Vested Percentage of Vested Balance by Source rows of the latest Vested Balance As-Of Date for employer money sources, by plan and cohort.",
             _u("16", "Vested Balance by Source", "Vested Balance Membership", "Vested Contribution Source", "Vested Percentage", "Vested Balance As-Of Date")),
            ("Loan Usage and Leakage", "Share of participants with a Participant Loan of Loan Status in (Active, Delinquent), and sum of Outstanding Principal Balance / Participant Balance Market Value (from DP-430) of those participants, by plan.",
             _u("16", "Participant Loan", "Loan ID", "Loan Membership", "Loan Status", "Outstanding Principal Balance", "Original Principal Amount") + ["Participant Balance Market Value (from DP-430)"]),
            ("Pre-Retirement Withdrawals", "Count and Gross Distribution Amount of paid Distribution Request rows with Distribution Type in (Hardship, Emergency Personal Expense, In-Service Age 59 1/2) in the period, by plan; shown only where at least 10 participants are counted, and never by Hardship Reason.",
             _u("16", "Distribution Request", "Distribution ID", "Distribution Membership", "Distribution Type", "Gross Distribution Amount", "Payment Date", "Distribution Status")),
            ("Cash-Out at Separation Rate", "Paid distributions with Distribution Type in (Termination Lump Sum, Mandatory Cash-Out) and Rollover Direction = Not a Rollover / all paid termination distributions in the period, by plan.",
             _u("16", "Distribution Request", "Distribution Type", "Rollover Direction", "Distribution Status")),
            ("Participants at Deferral Limit", "Count of memberships whose Annual Limit Tracking row of Limit Type 402(g) Elective Deferral has Year-to-Date Amount at or above Statutory Limit Amount for the Limit Plan Year, by plan.",
             _u("16", "Annual Limit Tracking", "Limit Membership", "Limit Plan Year", "Limit Type", "Statutory Limit Amount", "Year-to-Date Amount")),
            ("Median Personal Return Value (from DP-145)", "Median of Personal Return Value of final Personal Rate of Return rows (Personal Return Status final) with Personal Return Subject Type Account whose Personal Return Account is a participant account of the plan, for the trailing 12-month period, by Personal Return Method and Personal Return Fee Basis; read from DP-145, never recomputed (CW-011).",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Subject Type", "Personal Return Account", "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Method", "Personal Return Fee Basis", "Personal Return Value", "Personal Return Status") + _u("16", "Participant Plan Membership", "Participant Account")),
            ("Plans Offering Managed Accounts", "Count of plans with a Plan Managed Account Service in force (Service Effective From to Service Effective To), by Service Availability (opt-in or QDIA default) and Fiduciary Basis.",
             _u("16", "Plan Managed Account Service", "Managed Account Service Plan", "Managed Account Service Offering", "Service Availability", "Fiduciary Basis", "Service Effective From", "Service Effective To")),
            ("Participant Managed Account Enrollment Rate", "Memberships whose Participant Account has a 46 Model Assignment with Assignment Status active in force on the as-of date (from DP-304) / memberships with a balance in plans offering the service, by Service Availability.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assignment Status", "Assignment Effective From", "Assignment Effective To") + _u("16", "Participant Plan Membership", "Participant Account") + ["Plans Offering Managed Accounts"]),
            ("Participant Service Elections", "Count of Participant Service Election rows in force by Service Election Type (In-Plan Roth Conversion, Roth Employer Contribution Designation, Automatic Portability Opt-Out, PLESA Participation, PLESA Opt-Out) per 1,000 memberships, by plan.",
             _u("16", "Participant Service Election", "Service Election Membership", "Service Election Type", "Service Election Effective From", "Service Election Effective To") + ["Participation Rate % (from DP-094)"]),
        ],
        inputs=[
            ("16", "Participant Plan Membership", ["Membership ID", "Membership Plan", "Participant Account", "Membership Status", "Eligibility Date", "Plan Entry Date",
                                                   "Enrollment Method", "Automatic Enrollment Opt-Out Date"]),
            ("16", "Deferral Election", ["Deferral Election ID", "Election Membership", "Pre-Tax Deferral Percentage", "Roth Deferral Percentage", "Election Source",
                                         "Deferral Election Effective From", "Deferral Election Effective To"]),
            ("16", "Investment Election", ["Investment Election Membership", "Elected Investment Option", "Allocation Percentage", "Default Election Indicator",
                                           "Investment Election Effective From", "Investment Election Effective To"]),
            ("16", "Deferral & Automatic Features", ["Automatic Enrollment Type", "Default Deferral Rate", "Automatic Escalation Increment"]),
            ("16", "Plan Investment Option", ["Investment Option ID", "Menu Plan", "Offered Share Class", "Menu Role", "Option Status"]),
            ("16", "Participant Balance", ["Balance Membership", "Balance Contribution Source", "Balance Investment Option", "Valuation Date", "Balance Market Value",
                                           "Vested Amount"]),
            ("16", "Vested Balance by Source", ["Vested Balance Membership", "Vested Contribution Source", "Vested Percentage", "Vested Balance As-Of Date"]),
            ("16", "Participant Loan", ["Loan ID", "Loan Membership", "Loan Status", "Original Principal Amount", "Outstanding Principal Balance"]),
            ("16", "Distribution Request", ["Distribution ID", "Distribution Membership", "Distribution Type", "Gross Distribution Amount", "Rollover Direction",
                                            "Payment Date", "Distribution Status"]),
            ("16", "Annual Limit Tracking", ["Limit Membership", "Limit Plan Year", "Limit Type", "Statutory Limit Amount", "Year-to-Date Amount"]),
            ("16", "Plan Managed Account Service", ["Managed Account Service Plan", "Managed Account Service Offering", "Service Availability", "Fiduciary Basis",
                                                    "Service Effective From", "Service Effective To"]),
            ("16", "Participant Service Election", ["Service Election Membership", "Service Election Type", "Service Election Effective From", "Service Election Effective To"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Status", "Assignment Effective From", "Assignment Effective To"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Subject Type", "Personal Return Account", "Personal Return Period Start Date",
                                               "Personal Return Period End Date", "Personal Return Method", "Personal Return Fee Basis",
                                               "Personal Return Value", "Personal Return Status"]),
        ],
        upstream=["DP-430", "DP-094", "DP-145", "DP-304", "DP-093", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end, after the DP-430 month-end balances and the DP-145 monthly personal returns are final",
        history="Monthly aggregate snapshots kept ten years for plan-design trend analysis; no participant rows retained in the product",
        classification="Confidential - Client",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Membership Plan, Menu Plan and Managed Account Service Plan resolves to a DP-094 retirement plan, every Participant Account and Assigned Account to a DP-093 account, every Offered Share Class to DP-004 and every Personal Return Account to the DP-145 return of that account.",
            "Deferral Election, Investment Election, Participant Service Election and Plan Managed Account Service effective periods of one membership or plan do not overlap and end on or after they start.",
            "For each plan and month-end the sum of Balance Market Value read equals DP-430 Participant Balance Market Value for the same plan and date within USD 1, and Median Personal Return Value (from DP-145) is computed only from Personal Return Value rows DP-145 publishes as final.",
            "Membership Status and Plan Entry Date are populated on every membership, and Allocation Percentage of the investment elections in force of a membership sums to 100 percent.",
            "No output row identifies a participant: every cell counts at least 10 memberships, a suppressed cell is protected by suppressing at least one more cell of the same plan (or the plan total) so it cannot be derived by subtraction (complementary suppression), Pre-Retirement Withdrawals is published at plan level only, and Hardship Reason and participant identifiers are not read or published.",
            "The month-end snapshot is published by business day 5 after month-end and is not changed after publication; a restatement is a new snapshot version.",
        ],
        notes=("Certified numbers: reads Personal Return Value from DP-145 (CW-011, CW-129) and never recomputes it; Participant "
               "Balance Market Value is DP-430's recordkeeping balance, never Client Assets, and Advised Assets is DP-008's "
               "(participant managed accounts are excluded from it under the DP-008 reference default). PII tier: none "
               "published. The dp_model warning is accepted: membership, election, balance, loan, distribution and return "
               "attributes are personal financial data, but the product publishes only plan and cohort aggregates with a "
               "minimum cell of 10 with complementary suppression, as in DP-322 (DQ5, lead ruling 2), so pii = N. Financial hardship is special category (CD-344) and only reaches "
               "products through DP-322: Hardship Reason is not read, and hardship withdrawals are counted by Distribution "
               "Type only (CW-231). Boundaries: balances DP-430; memberships, elections and plan design DP-094, whose Active Participants, Participation Rate %, Average Deferral Rate % and Default Investment Share % are read exactly as DP-094 defines them (lead ruling 5) and only cut by cohort and plan design here; model "
               "assignments DP-304; the 16 Participant Loan, Distribution Request and Annual Limit Tracking are read directly "
               "because no foundation publishes them (DP-095 is their operational product and a consumer); Plan Managed "
               "Account Service and Participant Service Election are moved reads from backlog DP-468 (Participant Managed "
               "Account Program), which names this product as its merge target. Dropped from the candidate: 45 Goal "
               "Projection Result, because 16 has no key from a membership to a 45 planning scenario; projected outcomes "
               "are read by CLA-A DP-337 (Goal Progress & Funded Status). Sponsor report packages are DIS DP-514's. "
               "Acceptance question 9: listed as a feeding product; it consumes Personal Return Value from DP-145 and shows "
               "it by plan and cohort (Median Personal Return Value (from DP-145)), and feeds no answering product, because "
               "DP-145 and DP-532 must not read a consumer of DP-145. Tailoring lever: participant managed accounts. "
               "Reference default: offered under ERISA 3(38) as opt-in and as a QDIA where the sponsor elects (16 lever "
               "7.7.3); without them the two managed-account measures drop. Tailoring lever: cohort basis. Reference "
               "default: plan entry year and membership status; age bands need the 02 date of birth and are not used. "
               "Tailoring lever: minimum cell size. Reference default: 10 participants (CW-225). Taxonomy gap: 16 has no projected "
               "retirement income or income replacement ratio for a participant, so readiness is shown through behavior "
               "and balance measures only. Taxonomy gap: Plan Managed Account Service has no participant enrollment record; "
               "enrollment is inferred from a 46 Model Assignment on the participant account. Drafting assumptions: the "
               "90 percent concentration threshold; the employer money sources for vesting; final as the Personal Return "
               "Status used; the trailing 12-month return period. Decisions: CW-011, CW-125, CW-129, CW-230, CW-231, "
               "CW-232. WP1 new (CW-230): new consumer product of the BWO brief; takes the backlog DP-468 reads."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-467": dict(
        definition=("The separation-to-rollover funnel of the recordkept plans: separations and other hand-off triggers, "
                    "participant retail hand-offs with consent to contact, referral to an advice engagement or advisor, the "
                    "outcome by destination (firm IRA, firm-recordkept plan, external, stayed, cashed out), the linked "
                    "distribution requests and their receiving accounts' channel, incoming rollover contributions, and the "
                    "PTE 2020-02 documentation status where a rollover was recommended. It shows the share of rolled-over "
                    "money that came into the direct business beside Net Inter-Channel Transfers read from DP-008. It owns "
                    "the funnel counts and no certified metric family."),
        business_questions=[
            "Which participants separated this quarter, and what share of the money they rolled over came into the direct business (acceptance question 10)?",
            "How many separated participants had a hand-off, consented to contact and were referred to advice, and with what outcome?",
            "How do rollovers into firm accounts compare with Net Inter-Channel Transfers out of the workplace channel as DP-008 certifies them?",
            "How much rolled out to external institutions, and how much rolled in from other plans and IRAs?",
            "Which referred rollovers have complete PTE 2020-02 documentation, and how long does a separation take to reach a rollover?",
        ],
        grain=("Participant retail hand-off (PRTHO-; membership x trigger) with its separation event, linked distribution "
               "requests and their receiving account's channel, referral and rollover recommendation as companion facts, and "
               "incoming rollover contributions; quarterly and monthly snapshots"),
        dimensions=["Retirement plan and participant membership (DP-094)", "Participant (DP-240)", "Hand-off trigger and outcome", "Referred advisor (DP-009)",
                    "Receiving account and its distribution channel (DP-093, DP-008)", "Distribution type and rollover direction", "Rollover source type",
                    "PTE 2020-02 documentation status (DP-303)", "Trigger quarter and payment date (DP-013)"],
        measures=[
            ("Separations", "Count of distinct memberships with an Employment Event of Employment Event Type Termination or Retirement and Employment Event Date in the quarter, by plan (from DP-094).",
             _u("16", "Employment Event", "Event Membership", "Employment Event Type", "Employment Event Date") + _u("16", "Participant Plan Membership", "Membership ID", "Membership Plan", "Participant Account", "Membership Status")),
            ("Participant Hand-Offs Triggered (from DP-393)", "Count of Participant Retail Hand-Off rows with Trigger Date in the period, by Hand-Off Trigger and plan (Hand-Off Membership, DP-094), exactly as DP-393 defines it; the hand-off facts are DP-430's.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off ID", "Hand-Off Membership", "Hand-Off Trigger", "Trigger Date")),
            ("Separated Participants Without Hand-Off (from DP-430)", "Count of memberships with Membership Status in (Terminated with Balance, Retired with Balance), counted in DP-430 Participants With Balance, that have no Participant Retail Hand-Off with Hand-Off Membership = the membership, exactly as DP-430 defines it; it is a status-based count and is not restricted to the Separations of the quarter.",
             _u("16", "Participant Plan Membership", "Membership Status") + _u("16", "Participant Retail Hand-Off", "Hand-Off Membership") + _u("16", "Participant Balance", "Balance Membership", "Balance Market Value")),
            ("Contact Consent Rate", "Participant Hand-Offs Triggered (from DP-393) with Contact Consent populated / Participant Hand-Offs Triggered (from DP-393), by trigger and plan; this product's funnel stage.",
             _u("16", "Participant Retail Hand-Off", "Contact Consent") + ["Participant Hand-Offs Triggered (from DP-393)"]),
            ("Hand-Off to Advice Engagement Rate % (from DP-393)", "Participant Hand-Offs Triggered (from DP-393) with Referral Advice Engagement populated / Participant Hand-Offs Triggered (from DP-393), by Hand-Off Trigger and Referred Advisor's channel, exactly as DP-393 defines it; read, never redefined.",
             _u("16", "Participant Retail Hand-Off", "Referral Advice Engagement", "Referred Advisor") + ["Participant Hand-Offs Triggered (from DP-393)"]),
            ("Hand-Off Rollover Amount (from DP-430)", "Sum of Hand-Off Rollover Amount of hand-offs with Outcome Date in the period, by Hand-Off Outcome, exactly as DP-430 defines it, with the count of hand-offs by outcome; an operational amount, never the certified Net Inter-Channel Transfers.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off Rollover Amount", "Outcome Date", "Hand-Off Outcome", "Linked Distribution Request")),
            ("Hand-Off Capture Rate", "Hand-offs with Hand-Off Outcome = Rolled to Firm IRA / hand-offs with an outcome other than Open in the period: the funnel capture count of this product, an operational rate and not a certified family.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off Outcome") + ["Hand-Off Rollover Amount (from DP-430)"]),
            ("Rollovers Out Paid", "Sum of Gross Distribution Amount and count of paid Distribution Request rows (Distribution Status Paid) with Rollover Direction in (Direct Rollover Out, Indirect Rollover Out) and Payment Date in the period, by plan and Distribution Type.",
             _u("16", "Distribution Request", "Distribution ID", "Distribution Membership", "Distribution Type", "Gross Distribution Amount", "Rollover Direction", "Payment Date", "Distribution Status")),
            ("Rollovers Into the Direct Business", "Rollovers Out Paid whose Receiving Account resolves to a firm 15 account (from DP-093) with an 06 Account Channel Assignment in force on the Payment Date (Channel Effective From to Channel Effective To, from DP-008) whose Assigned Distribution Channel is a direct-business channel (self-directed, advised or managed), by Assigned Business Line and the linked Originating Hand-Off.",
             _u("16", "Distribution Request", "Receiving Account", "Originating Hand-Off", "Payment Date") + _u("15", "Account", "Account ID", "Account Type", "Account Status", "Account Open Date") + _u("06", "Account Channel Assignment", "Channel Assignment ID", "Assigned Account", "Assigned Distribution Channel", "Assigned Business Line", "Channel Effective From", "Channel Effective To") + ["Rollovers Out Paid"]),
            ("Direct Business Rollover Share", "Rollovers Into the Direct Business / Rollovers Out Paid of the separated participants (memberships in Separations), by quarter and plan: the share rolled into the direct business of acceptance question 10.",
             ["Rollovers Into the Direct Business", "Rollovers Out Paid", "Separations"]),
            ("Net Inter-Channel Transfers (from DP-008)", "Measure Amount of the DP-008 Measure Value of Net Inter-Channel Transfers at Dimension Type Channel for the workplace channel (out) and the direct channels (in), for the quarter's Period End Date in the locked DP-008 Snapshot; read, never recomputed (CW-142: a rollover from a firm plan into a firm IRA is an inter-channel transfer, not NNA).",
             _u("06", "Measure Value", *_MV) + _u("06", "Client Asset Measures", "Net Inter-Channel Transfers") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Rollover Capture to Inter-Channel Transfer Difference", "Rollovers Into the Direct Business minus the workplace-channel outflow of Net Inter-Channel Transfers (from DP-008) for the quarter; a residual explained by timing, indirect rollovers and non-rollover channel changes.",
             ["Rollovers Into the Direct Business", "Net Inter-Channel Transfers (from DP-008)"]),
            ("Rollovers to External Institutions", "Rollovers Out Paid whose Receiving Account is not a firm account, by Receiving Institution (DP-240) and whether Auto-Rollover IRA Provider is populated.",
             _u("16", "Distribution Request", "Receiving Institution", "Auto-Rollover IRA Provider") + ["Rollovers Out Paid"]),
            ("Rollover Contributions Received (from DP-095)", "Count and Contribution Amount of Contribution Record rows with Contribution Source in (Rollover In, Roth Rollover In) received in the period, by Rollover Source Type and Automatic Portability Indicator, with Roth Basis Amount for Roth rollovers, exactly as DP-095 defines it; cut here by Distributing Institution.",
             _u("16", "Contribution Record", "Contribution ID", "Contribution Source", "Contribution Amount") + _u("16", "Rollover Contribution Detail", "Rollover Source Type", "Distributing Institution", "Roth Basis Amount", "Automatic Portability Indicator")),
            ("Referred Rollover Recommendations", "The DP-335 Rollover Recommendations (count of Recommendation ID with Recommendation Type = Rollover and Recommendation Presented Timestamp in the period, from DP-335) whose Recommendation Engagement (from DP-303) is the Referral Advice Engagement of a hand-off, with the Rollover Amount of the Supporting Rollover Analysis and the Client Decision; this product adds only the hand-off filter.",
             _u("45", "Recommendation", "Recommendation ID", "Recommendation Type", "Recommendation Presented Timestamp", "Recommendation Engagement", "Supporting Rollover Analysis", "Client Decision", "Client Decision Date") + _u("45", "Rollover Analysis", "Rollover Analysis ID", "Rollover Recommendation", "Rollover Amount", "Rollover Analysis Status", "Analysis Completed Date") + _u("16", "Participant Retail Hand-Off", "Referral Advice Engagement")),
            ("Referred Rollovers Without PTE 2020-02 Documentation (from DP-335)", "Referred Rollover Recommendations with the DP-335 PTE Documentation Gap Flag = Y, the flag read exactly as DP-335 defines it: Y for a Rollover Recommendation with no Rollover Analysis (Rollover Recommendation = Recommendation ID), or whose analysis has Fiduciary Status Basis = Acknowledged Fiduciary - PTE 2020-02 and any of: Fiduciary Acknowledgment Delivered Date, Services and Conflicts Disclosure Delivered Date or Rollover Reasons Delivered Date blank or after Client Decision Date; Impartial Conduct Standards Attestation not Y; Best Interest Reasons blank; or no Best Interest Evidence row of Best Interest Component = PTE 2020-02 Impartial Conduct Standards with Component Satisfied Indicator = Y. Shown with their share of Referred Rollover Recommendations; never redefined.",
             _u("45", "Rollover Analysis", "Rollover Analysis ID", "Rollover Recommendation", "Fiduciary Status Basis", "Best Interest Reasons") + _u("45", "PTE 2020-02 Documentation", "Fiduciary Acknowledgment Delivered Date", "Services and Conflicts Disclosure Delivered Date", "Rollover Reasons Delivered Date", "Impartial Conduct Standards Attestation") + _u("45", "Recommendation", "Client Decision Date") + _u("45", "Best Interest Evidence", "Evidence Recommendation", "Best Interest Component", "Component Satisfied Indicator") + ["Referred Rollover Recommendations"]),
            ("Days From Separation to Rollover", "Median days from Trigger Date to Outcome Date of hand-offs with Hand-Off Outcome Rolled to Firm IRA or Rolled to Firm-Recordkept Plan, by trigger and plan.",
             _u("16", "Participant Retail Hand-Off", "Trigger Date", "Outcome Date", "Hand-Off Outcome")),
            ("Hand-Offs Open Past 90 Days (from DP-430)", "Count of Participant Retail Hand-Off rows with Hand-Off Outcome = Open and Trigger Date more than 90 days before the as-of date, by Hand-Off Trigger, exactly as DP-430 defines it.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off ID", "Hand-Off Outcome", "Trigger Date", "Hand-Off Trigger")),
        ],
        inputs=[
            ("16", "Participant Retail Hand-Off", ["Hand-Off ID", "Hand-Off Membership", "Hand-Off Trigger", "Trigger Date", "Contact Consent",
                                                   "Referral Advice Engagement", "Referred Advisor", "Hand-Off Outcome", "Outcome Date",
                                                   "Linked Distribution Request", "Hand-Off Rollover Amount"]),
            ("16", "Employment Event", ["Event Membership", "Employment Event Type", "Employment Event Date"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant", "Membership Plan", "Participant Account", "Membership Status"]),
            ("16", "Distribution Request", ["Distribution ID", "Distribution Membership", "Distribution Account", "Distribution Type", "Gross Distribution Amount",
                                            "Receiving Institution", "Receiving Account", "Originating Hand-Off", "Rollover Direction", "Payment Date",
                                            "Distribution Status", "Auto-Rollover IRA Provider"]),
            ("16", "Contribution Record", ["Contribution ID", "Contribution Membership", "Contribution Account", "Contribution Source", "Contribution Amount"]),
            ("16", "Rollover Contribution Detail", ["Rollover Source Type", "Distributing Institution", "Roth Basis Amount", "Automatic Portability Indicator"]),
            ("16", "Participant Balance", ["Balance Membership", "Valuation Date", "Balance Market Value"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommendation Presented Timestamp", "Recommendation Engagement", "Supporting Rollover Analysis", "Client Decision",
                                      "Client Decision Date"]),
            ("45", "Rollover Analysis", ["Rollover Analysis ID", "Rollover Recommendation", "Source Retirement Plan", "Rollover Amount", "Fiduciary Status Basis",
                                         "Best Interest Reasons", "Rollover Analysis Status",
                                         "Analysis Completed Date"]),
            ("45", "PTE 2020-02 Documentation", ["Fiduciary Acknowledgment Delivered Date", "Services and Conflicts Disclosure Delivered Date",
                                                 "Rollover Reasons Delivered Date", "Impartial Conduct Standards Attestation"]),
            ("45", "Best Interest Evidence", ["Evidence Recommendation", "Best Interest Component", "Component Satisfied Indicator"]),
            ("06", "Account Channel Assignment", ["Channel Assignment ID", "Assigned Account", "Assigned Distribution Channel", "Assigned Business Line",
                                                  "Channel Effective From", "Channel Effective To"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot"]),
            ("06", "Client Asset Measures", ["Net Inter-Channel Transfers"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Open Date"]),
        ],
        upstream=["DP-430", "DP-094", "DP-303", "DP-335", "DP-393", "DP-095", "DP-008", "DP-093", "DP-240", "DP-009", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end, after the DP-008 snapshot of the month is locked; the open hand-off queue daily by 9am ET",
        history="Monthly and quarterly snapshots kept seven years; hand-off, distribution and recommendation links kept with the source records (SEC Rule 17a-4; ERISA section 107)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Hand-Off Membership, Event Membership, Distribution Membership and Contribution Membership resolves to a DP-094 membership, every Receiving Account and Participant Account to a DP-093 account, every Referred Advisor to DP-009, and every Referral Advice Engagement and Rollover Recommendation to DP-303.",
            "Outcome Date is on or after Trigger Date, Payment Date is on or after the request's trigger, and Account Channel Assignment periods of one account do not overlap, so each receiving account has one channel on the Payment Date.",
            "Net Inter-Channel Transfers (from DP-008) equals the DP-008 published Measure Amount for the same snapshot and channel, and the hand-off amounts and queues read equal DP-430 Hand-Off Rollover Amount and Hand-Offs Open Past 90 Days for the same date.",
            "Hand-Off Trigger, Trigger Date and Hand-Off Outcome are populated on every hand-off, and Rollover Direction, Receiving Account (for direct rollovers) and Distribution Status on every paid distribution.",
            "Participant rows are visible only to workplace participant services and advice roles; management views aggregate to plan, trigger, outcome and channel with no participant key, and Hardship Reason is not read.",
            "The month-end snapshot is published only after the DP-008 snapshot of the month is locked and by business day 5, and is never changed after publication.",
        ],
        notes=("Certified numbers: reads Net Inter-Channel Transfers from DP-008 (CW-011, CW-142); Hand-Off Capture Rate, "
               "Rollovers Into the Direct Business and Direct Business Rollover Share are operational funnel values owned "
               "here and never labeled Net New Assets or Client Assets (CW-230). PII tier: financial. Boundaries: the "
               "hand-off record and its queues are DP-430's; memberships and employment events DP-094's; the advice, "
               "Rollover Analysis and PTE 2020-02 documentation are 45's through DP-303 and supervised in 08, read and never "
               "re-scored; the documentation gap flag and work queue are CLA-A DP-335's and the referral funnel CLA-B DP-393's, both read here; the channel of the receiving "
               "account is read from 06 Account Channel Assignment through DP-008, never derived here; 16 Distribution "
               "Request, Contribution Record and Rollover Contribution Detail are read directly because no foundation "
               "publishes them. Acceptance question 10 (plan section 8.5): answered by Separations, Rollovers Into the "
               "Direct Business, Direct Business Rollover Share, Hand-Off Capture Rate, Net Inter-Channel Transfers (from "
               "DP-008) and Referred Rollovers Without PTE 2020-02 Documentation (from DP-335); mastering domains 16, 45, 15, "
               "06. Read exactly as their owners define them (lead ruling 4): the hand-off count and engagement rate from "
               "DP-393, the PTE Documentation Gap Flag from DP-335 (with Fiduciary Status Basis and every DP-335 condition; "
               "the Impartial Conduct Standards Attestation condition is DP-335's own, not added here), Separated "
               "Participants Without Hand-Off, Hand-Off Rollover Amount and Hand-Offs Open Past 90 Days from DP-430, and "
               "Rollover Contributions Received from DP-095; none of them lists this product. Separations is this "
               "product's own event-based count and differs from DP-430's status-based queue by design. "
               "Acceptance question 3: feeds no answering product; it shows the DP-335 gap for referred rollovers (45). Tailoring lever: rollover outreach. Reference default: outreach after consent to "
               "contact; outreach on notice with opt-out keeps the same stage measures (16 lever 7.7.4). Tailoring lever: "
               "auto-rollover IRA provider. Reference default: the firm, so small-balance automatic rollovers land in a firm "
               "IRA (16 lever 7.7.7). Tailoring lever: direct-business channels. Reference default: the self-directed, "
               "advised and managed channels of the CW-004 lines DB, DA and HA, and directly held fund-only accounts (PF). Taxonomy gap: DP-008 publishes no "
               "certified rollover capture rate (CW-126 names one for 06; 06 Client Asset Measures has none), so the "
               "funnel rate here is operational and the certified comparison is Net Inter-Channel Transfers. Taxonomy gap: "
               "06 Measure Value has no rollover or plan Dimension Type, so the DP-008 figure cannot be cut by plan. "
               "Taxonomy gap: 16 Participant Retail Hand-Off has no separation event key; the separation is matched on "
               "membership and date. Drafting assumptions: the direct-business Assigned Distribution Channel values; "
               "Termination and Retirement as separation events; Rollover as the Recommendation Type value; the 90-day "
               "window. Decisions: CW-011, CW-045, CW-126, CW-142, CW-230. WP1 new (CW-230): new consumer product of the "
               "BWO brief."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-095": dict(
        definition=("The daily operational view of money movement in the recordkept plans: payroll contribution batches and "
                    "the contribution records in them, incoming rollover contributions, annual limit tracking, late deposit "
                    "cases, participant loans with repayments and default or offset detail, forfeitures, distribution "
                    "requests with withholding, Form 1099-R detail and distribution elections, required minimum distribution "
                    "calculations and QDRO cases. It joins each record to the DP-094 plan and membership, the DP-093 account "
                    "and the 16 Participant Ledger Posting that books it (DP-430), and adds good-order, aging and limit flags "
                    "so that plan services operations work the day's exceptions from one list. It owns no certified metric "
                    "family."),
        business_questions=[
            "Which payroll batches received are not in good order or not yet posted, for which plans, how old are they, and which were deposited late?",
            "Which participants are at or over an annual contribution limit for the plan year, and which contributions are unposted to the participant ledger or tied to a plan correction?",
            "Which participant loans are delinquent, how close are they to the cure period end, and which have been deemed distributed or offset?",
            "Which distribution requests are pending and aging, which are missing a special tax notice, withholding or a withholding election, and which RMDs for the distribution year remain unsatisfied?",
            "Which late deposit cases and QDRO cases are open, what lost earnings are outstanding, and what rollover contributions came in?",
        ],
        grain=("Operational record (contribution batch, contribution, limit tracking row, late deposit case, loan, loan "
               "repayment, forfeiture, distribution request, distribution election, RMD calculation or QDRO case) x retirement "
               "plan x participant membership x business date snapshot"),
        dimensions=["Business date (DP-013)", "Retirement plan (DP-094)", "Participant (DP-094, DP-240)", "Participant account (DP-093)",
                    "Payroll date and funding method", "Contribution source and money source", "Rollover source type", "Limit type and plan year",
                    "Loan type and loan status", "Distribution type, rollover direction and distribution status", "Distribution election type",
                    "Form 1099-R distribution code", "RMD distribution year and status", "Good order and late deposit status",
                    "Ledger posting (DP-430)"],
        measures=[
            ("Batches Not in Good Order", "Count of Payroll Contribution Batch rows with Good Order Status not Posted on the business date, by Batch Plan and Funding Method; Batch Age Days = business date - Batch Received Timestamp date.",
             _u("16", "Payroll Contribution Batch", "Contribution Batch ID", "Good Order Status", "Batch Plan", "Funding Method", "Batch Received Timestamp")),
            ("Late Deposit Rate %", "Batches with Late Deposit Indicator = Y / batches with Payroll Date in the period, by plan; Total Batch Amount of late batches shown alongside (DOL 29 CFR 2510.3-102).",
             _u("16", "Payroll Contribution Batch", "Late Deposit Indicator", "Payroll Date", "Total Batch Amount")),
            ("Lost Earnings Outstanding", "Sum of Lost Earnings Amount over Late Deposit Case rows with Late Deposit Case Status not closed, by Correction Program Used.",
             _u("16", "Late Deposit Case", "Lost Earnings Amount", "Late Deposit Case Status", "Correction Program Used")),
            ("Unposted Contribution Amount", "Sum of Contribution Amount over Contribution Record rows in batches with Good Order Status = Posted whose Posting Transaction does not resolve to a Ledger Posting ID of a DP-430 Participant Ledger Posting with Posting Type Contribution or Rollover In, by Contribution Source; Correction-Linked Flag = Y when Related Plan Correction is populated.",
             _u("16", "Contribution Record", "Contribution Amount", "Contribution Source", "Posting Transaction", "Contribution Batch", "Related Plan Correction") + _u("16", "Payroll Contribution Batch", "Good Order Status") + _u("16", "Participant Ledger Posting", "Ledger Posting ID", "Posting Type")),
            ("Contributions Posted at Different Amount", "Count of Contribution Record rows whose Posting Transaction resolves to a Participant Ledger Posting whose Posted Amount differs from Contribution Amount by more than USD 0.01.",
             _u("16", "Contribution Record", "Posting Transaction", "Contribution Amount") + _u("16", "Participant Ledger Posting", "Ledger Posting ID", "Posted Amount")),
            ("Batch Reconciliation Variance", "Total Batch Amount - sum of Contribution Amount of the batch's Contribution Record rows; flagged when not zero.",
             _u("16", "Payroll Contribution Batch", "Total Batch Amount") + _u("16", "Contribution Record", "Contribution Amount", "Contribution Batch")),
            ("Rollover Contributions Received", "Count and Contribution Amount of Contribution Record rows with Contribution Source in (Rollover In, Roth Rollover In) received in the period, by Rollover Source Type and Automatic Portability Indicator, with Roth Basis Amount for Roth rollovers.",
             _u("16", "Contribution Record", "Contribution ID", "Contribution Source", "Contribution Amount") + _u("16", "Rollover Contribution Detail", "Rollover Source Type", "Distributing Institution", "Rollover Eligibility Determination Date", "Roth Basis Amount", "Automatic Portability Indicator")),
            ("Limit Utilization %", "Year-to-Date Amount / Statutory Limit Amount per membership x Limit Type x Limit Plan Year; Limit Breach Flag = Y when above 100%, Limit Warning Flag = Y when above 90%.",
             _u("16", "Annual Limit Tracking", "Year-to-Date Amount", "Statutory Limit Amount", "Limit Type", "Limit Plan Year")),
            ("Loans Outstanding", "Count of Participant Loan rows with Loan Status in (Active, Delinquent) and sum of Outstanding Principal Balance, by plan and Loan Type.",
             _u("16", "Participant Loan", "Loan ID", "Loan Status", "Outstanding Principal Balance", "Loan Type")),
            ("Loans Approaching Deemed Distribution", "Count of loans with Loan Status = Delinquent, Cure Period End Date within 30 days of the business date and no Deemed Distribution Date; Days to Cure End = Cure Period End Date - business date (IRC section 72(p)).",
             _u("16", "Participant Loan", "Loan Status") + _u("16", "Loan Default & Offset", "Cure Period End Date", "Deemed Distribution Date")),
            ("Repayments Collected", "Sum of Principal Portion + Interest Portion over Loan Repayment rows with Repayment Date in the period, by loan; Missed Repayment Flag = Y when an active loan has no Loan Repayment in the last payroll cycle.",
             _u("16", "Loan Repayment", "Principal Portion", "Interest Portion", "Repayment Date", "Repaid Loan") + ["Loans Outstanding"]),
            ("Pending Distributions Aging", "Count of Distribution Request rows with Distribution Status not Paid, Rejected or Canceled, by Distribution Type; Request Age Days = business date - Request Received Date, flagged when above 10 business days; Gross Distribution Amount pending shown alongside.",
             _u("16", "Distribution Request", "Distribution ID", "Distribution Status", "Distribution Type", "Request Received Date", "Gross Distribution Amount")),
            ("Special Tax Notice Gap", "Count of distributions with Rollover Direction other than Not a Rollover, or with a rollover-eligible Distribution Type and a Payment Date, where Special Tax Notice Delivered Date is null or fewer than 30 days before Payment Date (IRC section 402(f)); Withholding Check Flag = Y when Federal Withholding Amount differs from Taxable Amount x Federal Withholding Rate.",
             _u("16", "Distribution Request", "Rollover Direction", "Distribution Type", "Payment Date", "Special Tax Notice Delivered Date") + _u("16", "Tax Withholding & 1099-R Detail", "Taxable Amount", "Federal Withholding Rate", "Federal Withholding Amount")),
            ("Distributions Without Withholding Election", "Count of pending or paid Distribution Request rows whose Distribution Membership has no Participant Distribution Election of Distribution Election Type Federal Withholding - Nonperiodic (Form W-4R) or Federal Withholding - Periodic (Form W-4P) in force on Request Received Date, by Distribution Type.",
             _u("16", "Participant Distribution Election", "Distribution Election Membership", "Distribution Election Type", "Elected Withholding Rate", "Distribution Election Effective From", "Distribution Election Effective To") + _u("16", "Distribution Request", "Distribution Membership", "Request Received Date", "Distribution Type")),
            ("RMD Outstanding", "Count of RMD Calculation rows for the RMD Distribution Year with RMD Status not Satisfied or Satisfied from Another Plan / IRA and sum of their Required Amount, by plan; Past Required Beginning Date Flag = Y when Required Beginning Date is before the business date.",
             _u("16", "RMD Calculation", "RMD Distribution Year", "RMD Status", "Required Amount", "Required Beginning Date")),
        ],
        inputs=[
            ("16", "Payroll Contribution Batch", ["Contribution Batch ID", "Batch Plan", "Payroll Date", "Batch Received Timestamp", "Funding Method", "Total Batch Amount",
                                                  "Good Order Status", "Late Deposit Indicator"]),
            ("16", "Contribution Record", ["Contribution ID", "Contribution Batch", "Contribution Membership", "Contribution Account", "Contribution Source",
                                           "Contribution Amount", "Posting Transaction", "Related Plan Correction"]),
            ("16", "Rollover Contribution Detail", ["Rollover Source Type", "Distributing Institution", "Rollover Eligibility Determination Date", "Roth Basis Amount",
                                                    "Automatic Portability Indicator"]),
            ("16", "Annual Limit Tracking", ["Limit Membership", "Limit Plan Year", "Limit Type", "Statutory Limit Amount", "Year-to-Date Amount"]),
            ("16", "Late Deposit Case", ["Late Deposit Case ID", "Late Batch", "Lost Earnings Amount", "Correction Program Used", "Late Deposit Case Status"]),
            ("16", "Participant Loan", ["Loan ID", "Loan Membership", "Loan Account", "Loan Type", "Loan Origination Date", "Original Principal Amount",
                                        "Loan Interest Rate", "Loan Term Months", "Outstanding Principal Balance", "Loan Status", "Loan Status Effective From",
                                        "Disbursement Transaction"]),
            ("16", "Loan Repayment", ["Repaid Loan", "Repayment Date", "Principal Portion", "Interest Portion", "Repayment Batch"]),
            ("16", "Loan Default & Offset", ["Cure Period End Date", "Deemed Distribution Date", "Loan Offset Date", "Related Offset Distribution"]),
            ("16", "Forfeiture Record", ["Forfeiture ID", "Forfeiture Plan", "Forfeiting Membership", "Forfeiture Event Type", "Forfeiture Date", "Forfeited Amount",
                                         "Forfeiture Use Type", "Forfeiture Transaction"]),
            ("16", "Distribution Request", ["Distribution ID", "Distribution Membership", "Distribution Account", "Distribution Type", "Request Received Date",
                                            "Gross Distribution Amount", "Receiving Institution", "Rollover Direction", "Special Tax Notice Delivered Date",
                                            "Payment Date", "Distribution Status", "Settlement Transactions", "Auto-Rollover IRA Provider"]),
            ("16", "Tax Withholding & 1099-R Detail", ["Taxable Amount", "Federal Withholding Rate", "Federal Withholding Amount", "Form 1099-R Distribution Code"]),
            ("16", "Participant Distribution Election", ["Distribution Election Membership", "Distribution Election Type", "Installment Frequency", "Elected Withholding Rate",
                                                         "Distribution Election Effective From", "Distribution Election Effective To"]),
            ("16", "RMD Calculation", ["RMD Membership", "RMD Distribution Year", "Required Beginning Date", "Required Amount", "RMD Status"]),
            ("16", "QDRO Case", ["QDRO Case ID", "QDRO Membership", "Alternate Payee", "Order Received Date", "Qualification Status", "Awarded Percentage",
                                 "Alternate Payee Account", "Resulting Distribution"]),
            ("16", "Participant Ledger Posting", ["Ledger Posting ID", "Posting Membership", "Posting Type", "Posted Amount", "Posting Trade Date"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant", "Membership Plan", "Participant Account", "Membership Status"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Plan Participant Account", ["Plan Account", "Money Sources Held", "Participant Account Status"]),
        ],
        upstream=["DP-094", "DP-430", "DP-093", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for recordkeeping records of the prior business day, with intraday refresh of batch good-order status at noon ET",
        history="Daily snapshots kept for 25 months; batches, contributions, loans, distributions and cases kept for the life of the plan plus seven years (ERISA section 107); limit tracking kept by plan year",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Contribution Membership, Loan Membership, Distribution Membership, Distribution Election Membership, RMD Membership, QDRO Membership, Forfeiting Membership and Limit Membership resolves to a Membership ID in DP-094, every Contribution Account, Loan Account, Distribution Account and Alternate Payee Account to a DP-093 account, and every Distributing Institution, Receiving Institution and Alternate Payee to a DP-240 party.",
            "Participant Distribution Election periods of one membership and election type do not overlap and end on or after they start, Repayment Date is on or after Loan Origination Date, and Payment Date is on or after Request Received Date.",
            "Total Batch Amount equals the sum of Contribution Amount of the batch's Contribution Record rows for every batch with Good Order Status = Posted, and every Posting Transaction, Disbursement Transaction, Forfeiture Transaction and Settlement Transactions reference resolves to a DP-430 Participant Ledger Posting whose Posted Amount equals the record's amount within USD 0.01.",
            "Outstanding Principal Balance never exceeds Original Principal Amount and is zero when Loan Status is Paid Off, Deemed Distributed or Offset, and every Distribution Request with Distribution Status = Paid has a Payment Date, a Gross Distribution Amount above zero and a Form 1099-R Distribution Code.",
            "Participant rows (contributions, loans, distributions, QDRO cases with the Alternate Payee) and Distribution Type at row level are visible only in the restricted companion view for plan services operations roles; the wide view shares plan-level exception counts only, with the Distribution Type value Disability folded into Other and complementary suppression applied so it cannot be derived by subtraction, and Hardship Reason is not read.",
            "Records of business date D are loaded by 7am ET on D+1 and batch good-order status is refreshed by 12:30pm ET, with Year-to-Date Amount non-negative and Statutory Limit Amount populated for every Limit Type x Limit Plan Year row at load.",
        ],
        notes=("Certified numbers: none; contribution, loan and distribution amounts are recordkeeping amounts, and plan "
               "flows reach Net New Assets only through DP-006 and DP-008. Operating model (CD-297): in-house recordkeeping;"
               " under TPA-partnered programs the batch and distribution rows are received records with the grain unchanged "
               "(16 lever 7.7.1). PII tier: financial. Hardship Reason is special category (CD-344) and is not read; QDRO "
               "alternate payees are identity data shown only in the operations view (DQ5). The classification moves from "
               "Restricted - Personal Data to Confidential - Personal Data, because no special-category attribute is read "
               "(WP1 classification rule). Boundaries: plan provisions, memberships, elections and employment events are "
               "DP-094's; balances, ledger postings and hand-offs DP-430's; accounts DP-093's. Forfeiture Record is "
               "published here as a money movement; vesting is DP-094's. Plan corrections referenced by Related Plan "
               "Correction are published in DP-096. Plan distributions run on the recordkeeper's rail (16), not through 50 "
               "(50 lever 8). IRA RMDs are 15's; the combined RMD view is CLA-A DP-329's (merge target of backlog DP-470). "
               "Rollover capture is DP-467's; participant outcomes DP-466's. Tailoring lever: distributions through the 50 "
               "hub. Reference default: no; with one payment hub the product reads DP-302 for payment status (16 lever "
               "7.7.8). Tailoring lever: thresholds. Reference default: 10 business days distribution aging, 30-day cure "
               "warning, 90 percent limit warning. Taxonomy gap: the 16 Distribution Type list does not mark Disability as special category (health data, CD-344); 16 should flag it, and until then this product folds it into Other outside the restricted view (DQ5). Taxonomy gap: Payroll Contribution Batch has no deposit deadline or "
               "days-late attribute, so lateness is read from Late Deposit Indicator as set by the recordkeeping system. "
               "Taxonomy gap: Loan Repayment has no sequence attribute, so two repayments of one loan on the same date are "
               "aggregated. Taxonomy gap: Distribution Request has no good-order or NIGO reason attribute. Drafting "
               "assumptions: the closed Late Deposit Case Status values; Contribution and Rollover In as the Posting Types "
               "of contributions; the USD 0.01 tolerance. Decisions: CW-034, CW-125, CW-126, CW-232, CW-233. WP1 re-scope "
               "(CW-233): keeps id, name, grain, owner and every measure name. Inputs dropped: 06 Transaction, Transaction "
               "Dates and Transaction Status (read by the measure Unposted Contribution Amount and DQ3; the four 16 posting "
               "references now resolve to 16 Participant Ledger Posting, CW-125). Inputs added: 16 Participant Ledger "
               "Posting (from DP-430), Rollover Contribution Detail and Participant Distribution Election. Upstream DP-006, "
               "DP-003 and DP-001 dropped; DP-430 and DP-240 added (the retirement plan is read through DP-094, parties "
               "through DP-240). Measures added: Contributions Posted at Different Amount, Rollover Contributions Received, "
               "Distributions Without Withholding Election. For the lineage agent: the DP-095 logical model "
               "(models_f4_accounts_plans) has dimension 'Transaction' conformed to DP-006, which becomes Participant Ledger"
               " Posting conformed to DP-430; 'Retirement Plan' stays conformed to DP-003, which in its WP1F re-scope "
               "publishes the 02 Retirement Plan; 'Receiving Institution' and 'Alternate Payee' conformed to DP-001 'Party' "
               "become DP-240 'Party'. The register row now carries supporting functions FN-71 and FN-66 (CW-233). Input "
               "dropped at the fix pass: 16 Contribution Record Plan Compensation for Period (compensation data no measure "
               "used)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-096": dict(
        definition=("The compliance status of every recordkept plan by plan year: nondiscrimination test results (ADP, ACP, "
                    "top-heavy, coverage) with their corrections and deadlines, plan correction cases under IRS and DOL "
                    "programs, Form 5500 series and Form 8955-SSA filings with their due dates and status, Form 5500 counts "
                    "and assets tied to the participant book, plan audits and opinions, required participant notices and "
                    "plan terminations with their final distribution and filing deadlines. It reads the plan document's plan "
                    "year from DP-094 and the participant balances from DP-430, derives each deadline and overdue flag once, "
                    "and gives plan compliance one register of what is due, late and corrected. It owns no certified metric "
                    "family."),
        business_questions=[
            "Which plans failed a nondiscrimination test for the plan year, by how much did the HCE average exceed the NHCE average, and which corrections are open or past their deadline?",
            "Which plan corrections are open under SCP, VCP or VFCP, how long since the failure was discovered, and which are tied to a complaint?",
            "Which Form 5500, 5500-SF, 5500-EZ and 8955-SSA filings are due in the next 60 days, which are overdue, and what share was filed on time?",
            "Do the Form 5500 plan assets and participant counts agree with the participant book at plan year end, and which large plan filers lack an audit opinion?",
            "Which required participant notices are overdue by notice type, and which terminating plans have passed their final distribution deadline or final Form 5500 filing?",
        ],
        grain="Compliance item (nondiscrimination test, test correction, plan correction, government filing, plan audit, plan notice or plan termination) x retirement plan x plan year",
        dimensions=["Retirement plan (DP-094)", "Plan sponsor (DP-003)", "Plan year", "Administered plan type and ERISA coverage", "Test type and test result",
                    "Correction program and failure type", "Filing form type and filing status", "Large plan filer indicator",
                    "Audit firm and audit opinion (DP-240)", "Notice type", "Termination status", "Due date month (DP-013)"],
        measures=[
            ("Tests Failed", "Count of Nondiscrimination Test rows with Test Result = Fail for the Test Plan Year, by Tested Plan and Test Type.",
             _u("16", "Nondiscrimination Test", "Test ID", "Test Result", "Test Plan Year", "Tested Plan", "Test Type")),
            ("HCE / NHCE Spread", "HCE Average Percentage - NHCE Average Percentage for ADP and ACP tests, in percentage points (IRC sections 401(k)(3) and 401(m)(2)).",
             _u("16", "Nondiscrimination Test", "HCE Average Percentage", "NHCE Average Percentage", "Test Type")),
            ("Test Corrections Overdue", "Count of Test Correction rows with Correction Deadline Date before the as-of date and no Correction Completed Date, by Test Correction Method; Days to Correction Deadline = Correction Deadline Date - as-of date for open corrections.",
             _u("16", "Test Correction", "Correction Deadline Date", "Correction Completed Date", "Test Correction Method")),
            ("Open Plan Corrections", "Count of Plan Correction rows with Plan Correction Status not closed, by Correction Program and Failure Type; Correction Age Days = as-of date - Failure Discovery Date; Complaint-Linked Flag = Y when Related Complaint resolves to an 08 Complaint.",
             _u("16", "Plan Correction", "Plan Correction Status", "Correction Program", "Failure Type", "Failure Discovery Date", "Related Complaint") + _u("08", "Complaint", "Complaint ID", "Received Date")),
            ("Filings Overdue", "Count of Government Filing rows with Filing Status not Filed or Accepted and Filing Due Date before the as-of date, by Filing Form Type; Days Overdue = as-of date - Filing Due Date.",
             _u("16", "Government Filing", "Filing Status", "Filing Due Date", "Filing Form Type")),
            ("Filings Due (60 Days)", "Count of Government Filing rows with Filing Status not Filed or Accepted and Filing Due Date within 60 days after the as-of date, by Filing Form Type and Filing Plan.",
             _u("16", "Government Filing", "Filing Status", "Filing Due Date", "Filing Form Type", "Filing Plan")),
            ("On-Time Filing Rate %", "Filings for the Filing Plan Year with Filed Date on or before Filing Due Date / filings for the plan year with a Filed Date, by Filing Form Type.",
             _u("16", "Government Filing", "Filed Date", "Filing Due Date", "Filing Plan Year", "Filing Form Type")),
            ("Form 5500 Assets Tie to Participant Balances", "Total Plan Assets at Year End of the plan year's Form 5500 Detail minus the sum of Balance Market Value of 16 Participant Balance rows (from DP-430) of the plan's memberships on the plan year end Valuation Date; flagged when the difference exceeds 1 percent (the 16 attribute is a Derived copy of the participant book, CW-125).",
             _u("16", "Form 5500 Detail", "Total Plan Assets at Year End") + _u("16", "Participant Balance", "Balance Membership", "Valuation Date", "Balance Market Value") + _u("16", "Participant Plan Membership", "Membership ID", "Membership Plan") + _u("16", "Plan Type Detail", "Plan Year End")),
            ("Form 5500 Participant Count Tie", "Participants with Balances at Year End of the Form 5500 Detail minus the count of distinct memberships of the plan with Balance Market Value above zero on the plan year end Valuation Date (from DP-430).",
             _u("16", "Form 5500 Detail", "Participants with Balances at Year End") + _u("16", "Participant Balance", "Balance Membership", "Balance Market Value", "Valuation Date") + _u("16", "Participant Plan Membership", "Membership Plan")),
            ("Audit Gap", "Count of Form 5500 filings with Independent Audit Required Indicator = Y or Large Plan Filer Indicator = Y and no Plan Audit for the same Audited Plan and Audit Plan Year with an Audit Opinion; Audit Package Late Flag = Y when Audit Package Delivered Date is null and Filing Due Date is within 60 days (ERISA section 103(a)(3)).",
             _u("16", "Form 5500 Detail", "Independent Audit Required Indicator", "Large Plan Filer Indicator") + _u("16", "Plan Audit", "Audited Plan", "Audit Plan Year", "Audit Opinion", "Audit Package Delivered Date") + _u("16", "Government Filing", "Filing Due Date", "Filing Plan", "Filing Plan Year")),
            ("Separated Participants Reported", "Count of Separated Participant Entry rows per Form 8955-SSA filing, by SSA Entry Code.",
             _u("16", "Separated Participant Entry", "Reported Membership", "SSA Entry Code")),
            ("Notices Overdue", "Count of Plan Notice rows with Notice Due Date before the as-of date and no Notice Delivered Date, by Notice Type and Notice Plan, with the four 404(a)(5) participant fee disclosure Notice Types (DOL 29 CFR 2550.404a-5) and the 408(b)(2) service provider disclosure shown separately; On-Time Notice Rate % = notices with Notice Delivered Date on or before Notice Due Date / notices due in the period.",
             _u("16", "Plan Notice", "Notice Due Date", "Notice Delivered Date", "Notice Type", "Notice Plan")),
            ("Terminations Past Deadline", "Count of Plan Termination rows with Plan Termination Status not Completed and Final Distribution Deadline before the as-of date and no Final Distribution Completed Date; Final Filing Gap Flag = Y when Final Distribution Completed Date is set and Final Form 5500 Filing is null.",
             _u("16", "Plan Termination", "Plan Termination Status", "Final Distribution Deadline", "Final Distribution Completed Date", "Final Form 5500 Filing")),
        ],
        inputs=[
            ("16", "Nondiscrimination Test", ["Test ID", "Tested Plan", "Test Plan Year", "Test Type", "HCE Average Percentage", "NHCE Average Percentage", "Test Result",
                                              "Test Performed By"]),
            ("16", "Test Correction", ["Test Correction ID", "Corrected Test", "Test Correction Method", "Correction Deadline Date", "Correction Completed Date",
                                       "Resulting Distributions"]),
            ("16", "Plan Correction", ["Plan Correction ID", "Corrected Plan", "Failure Type", "Failure Discovery Date", "Correction Program",
                                       "Correction Method Description", "Correction Completed Date", "Plan Correction Status", "Related Complaint"]),
            ("16", "Government Filing", ["Filing ID", "Filing Plan", "Filing Plan Year", "Filing Form Type", "Filing Due Date", "Filing Signer", "Filed Date", "Filing Status"]),
            ("16", "Form 5500 Detail", ["Large Plan Filer Indicator", "Independent Audit Required Indicator", "Participants with Balances at Year End",
                                        "Total Plan Assets at Year End"]),
            ("16", "Separated Participant Entry", ["Reported Membership", "SSA Entry Code", "Deferred Vested Benefit Amount"]),
            ("16", "Plan Audit", ["Plan Audit ID", "Audited Plan", "Audit Plan Year", "Audit Firm", "Audit Scope Type", "Audit Package Delivered Date", "Audit Opinion"]),
            ("16", "Plan Notice", ["Plan Notice ID", "Notice Plan", "Notice Type", "Notice Due Date", "Notice Delivered Date", "Delivery Communication"]),
            ("16", "Plan Termination", ["Plan Termination ID", "Terminated Plan", "Plan Termination Effective Date", "Final Distribution Deadline",
                                        "Final Distribution Completed Date", "Final Form 5500 Filing", "Plan Termination Status"]),
            ("16", "Plan Document", ["Plan Document ID", "Administered Plan", "Document Status"]),
            ("16", "Plan Type Detail", ["Administered Plan Type", "ERISA Covered Indicator", "Safe Harbor Design", "Plan Year End"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Membership Plan", "Membership Status"]),
            ("16", "Participant Balance", ["Balance Membership", "Valuation Date", "Balance Market Value"]),
            ("08", "Complaint", ["Complaint ID", "Received Date"]),
            ("02", "Retirement Plan", ["Plan Sponsor", "Sponsor EIN", "Plan Number", "Plan Name", "Plan Type"]),
            ("16", "Plan Sponsor Profile", ["Sponsor Party", "Employee Count"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name"]),
        ],
        upstream=["DP-094", "DP-003", "DP-430", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; test results within one business day of the test run, filing status within one business day of EFAST2 acknowledgment",
        history="Every plan year kept for the life of the plan plus seven years (ERISA section 107); tests kept per run with the latest run flagged; filing and correction status changes kept as a daily history",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Tested Plan, Corrected Plan, Filing Plan, Audited Plan, Notice Plan and Terminated Plan resolves to a DP-094 retirement plan with an active Plan Document, every Reported Membership to a DP-094 membership with Membership Status Terminated with Balance or Terminated Paid Out, every Audit Firm, Test Performed By and Filing Signer to a DP-240 party, and every Related Complaint to an 08 Complaint.",
            "Test Plan Year, Filing Plan Year and Audit Plan Year end on the plan document's Plan Year End, Plan Termination Effective Date is on or before Final Distribution Deadline, and Correction Completed Date, when present, is on or after Failure Discovery Date.",
            "For each Form 5500 filing Total Plan Assets at Year End agrees with the DP-430 participant balances of the plan at plan year end within 1 percent, and Participants with Balances at Year End with the count of memberships holding a balance, unless the filing explains the difference.",
            "Every Government Filing has a Filing Due Date, every Nondiscrimination Test with Test Result = Fail has at least one Test Correction with a Correction Deadline Date, and Filed Date is populated when Filing Status is Filed or Accepted.",
            "Participant-level detail (Separated Participant Entry, Deferred Vested Benefit Amount) is visible only to plan compliance roles; the compliance dashboard shows plan-level status.",
            "Test results are loaded within one business day of the test run and filing status within one business day of the EFAST2 acknowledgment, and a filed government filing is never changed in place (an amendment is a new filing row).",
        ],
        notes=("Certified numbers: none; Form 5500 plan assets are a filing figure tested against the DP-430 recordkeeping "
               "balances, never Client Assets. Operating model (CD-297): in-house recordkeeping and testing; under "
               "TPA-partnered programs the test and filing rows are received records with the grain kept (16 lever 7.7.1). "
               "PII tier: identity and financial (separated participants, HCE indicator, filing signers), restricted to plan"
               " compliance (DQ5). Boundaries: plan documents, plan year, memberships and the 02 Retirement Plan party are "
               "read through DP-094 as conformed dimensions, the plan sponsor through DP-003 and other parties through "
               "DP-240; balances through DP-430. Plan Termination and Plan Notice are published here because their deadlines"
               " are compliance-tracked; the delivered communication resolves to 13 (DP-382). Related Complaint resolves to "
               "the 08 Complaint, read directly for its key and received date because no foundational product publishes it "
               "(the wholesale DP-061 is retired). Tailoring lever: TPA testing and filing. Reference default: in house; "
               "TPA-partnered programs receive the rows (16 lever 7.7.1). Tailoring lever: tie tolerance. Reference default:"
               " 1 percent of plan assets. Taxonomy gap: Government Filing has no extension indicator or extended due date "
               "(Form 5558), so Filing Due Date is taken as the effective due date. Taxonomy gap: Nondiscrimination Test has"
               " no run date or run sequence, so the latest run is the only one kept per plan x test type x plan year. "
               "Taxonomy gap: Plan Notice has no attribute for the required delivery window or the population noticed. "
               "Taxonomy gap: Form 5500 Detail has no plan-asset breakdown, so assets held outside the participant book "
               "(forfeiture or unallocated accounts) explain the tie only by note. Drafting assumptions: the 60-day filing "
               "window; the terminated Membership Status values. Decisions: CW-125, CW-232, CW-233. WP1 re-scope (CW-233): "
               "keeps id, name, grain, owner and every measure name. Inputs added: 16 Participant Balance (from DP-430), 16 "
               "Plan Sponsor Profile (from DP-003) and 08 Complaint; the Related Complaint now resolves to 08 Complaint "
               "instead of the retired DP-061. Upstream DP-001 dropped; DP-003 kept for the plan sponsor; DP-430 and DP-240 "
               "added. Measures added: Form 5500 Assets Tie to Participant Balances and Form 5500 Participant Count Tie. For"
               " the lineage agent: the DP-096 logical model (models_f4_accounts_plans) has 'Retirement Plan' conformed to "
               "DP-003, which stays, and 'Audit Firm', 'Test Provider' and 'Filing Signer' conformed to DP-001 'Party', "
               "which become DP-240 'Party'; the plan sponsor is read through DP-003 (16 Plan Sponsor Profile, "
               "shared-dimension table; lead ruling 8). The register row now carries supporting functions FN-44 and FN-71 "
               "(CW-233). Input dropped at the fix pass: Highly Compensated Employee Indicator (no measure used it)."),
    ),
}
