"""Data product specifications, Wave WP1C (consumer), area CLA, agent C-1 "CLA-A": client, account, advice, managed
account, billing and trust consumer products of the wealth-manager reference model.

DP-345 Managed Account Assets, Models & Composites (46); DP-322 Client Protection Flags & Senior Investor Register (02);
DP-324 Client Contactability, Preferences & Consent (02); DP-334 Plan Quality & Recommendation Evidence (Reg BI File) (45);
DP-335 Rollover Recommendations & PTE 2020-02 Evidence (45); DP-350 Fee Invoicing, Mandate Billing & Performance Fees (47);
DP-320 Household 360 (02); DP-321 Authorized Persons, Trusted Contacts & Beneficiaries (02); DP-329 Retirement Account RMD &
Distribution Tracker (15); DP-332 Advisory Program Enrollment & Rule 3a-4 Compliance (15); DP-333 Advice Funnel & Conversion
(45); DP-337 Goal Progress & Funded Status (45); DP-341 Drift & Rebalance Monitor (46); DP-342 Rebalance & Tax-Loss Harvest
Effectiveness (46); DP-346 Fee Billing Accuracy & Custody-Rule Evidence (47); DP-349 Brokerage Commissions & Account Service
Charges (47); re-scoped in place: DP-077 Client Eligibility, KYC & Restrictions Status (02) and DP-080 Consumer Privacy Rights &
Opt-Out Evidence (02); trust products last (tailoring lever, optional TR line): DP-351 Fiduciary Account Review Compliance,
DP-352 Discretionary Distribution Decisions, DP-353 Trust Principal & Income Accounting, DP-354 Estate Settlement Case Tracker
and DP-355 Fiduciary Tax Filing & K-1 Status (51).

WP1 decisions applied: CW-011 and CW-142 (certified numbers read from DP-008, DP-241, DP-145 and DP-012, never recomputed),
CW-007 (Client Holding, 49, is the client book of record, read through DP-300), CW-210 (DP-077 and DP-080 re-scoped in place),
CW-211 (Household 360 owns no certified number), CW-212 (DP-345 publishes the managed account slice that DP-241 certifies),
CW-213 and CD-344 (special-category facts only through DP-322, and DP-352 for trust distribution purposes), CW-214 (billed fees
are operational; client fee revenue is DP-012's), CW-215 (evidence assembled, never re-scored), CW-216 (DP-350 succeeds
DP-067), and the WP1F rulings that the foundational products carry the 46, 47 and 51 facts and the consumers read them. See
CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


# The one unrestricted special-category field (CW-213): consumers carry it, keyed on the non-special party or account key.
FLAG_NOTE = ("Protection Flag Present is read from DP-322 as published (Y or N per 02 party and 15 account, no reason, basis or "
             "date) and joined on the non-special keys this product reads; no special-category attribute is read here (CW-213, "
             "CD-344). ")

GAP6 = ("Taxonomy gap: six one-to-one sub-objects carry no key or parent reference of their own (45 Recommendation Rationale, 45 PTE "
        "2020-02 Documentation, 46 Tax Management Setting, 47 Performance Fee Terms, 52 Manager-of-Managers Hire Condition and 15 "
        "Account Registration Detail), so their join to the parent is implicit and cannot be stated in a measure's uses. ")


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-345": dict(
        definition=("Retail managed accounts (15 accounts managed in 46, never 18 portfolios) and their market value by program, "
                    "model, discretion and regulatory AUM classification, model adoption and the assets that moved with model "
                    "changes, sleeves and sub-advised sleeves, and managed account composite membership with its exclusions and "
                    "the composite returns and dispersion read from DP-145. Values come from the brokerage book of record, 49 "
                    "Client Holding, through DP-300; the model assignments, sleeves and composites from DP-304. It publishes the "
                    "operational measure Managed Account Assets (Discretionary and Non-Discretionary), from which DP-241 "
                    "certifies the Firm AUM Managed Account Slice (CW-011, CW-212) and reconciles it to Client Assets. It owns "
                    "no certified metric family."),
        business_questions=[
            "What is the market value of the firm's managed accounts today, by program, model, discretion exercised and regulatory AUM classification?",
            "What are the discretionary and non-discretionary managed account assets at month-end that DP-241 certifies as the managed account slice of Firm AUM, and how much of the managed assets sit outside regulatory AUM or in own funds?",
            "Which models are adopted by how many accounts and how much money, and what assets moved with model changes this period?",
            "Which eligible managed accounts are outside their composite, for what reason, and what share of the program's assets does each composite cover?",
            "What did each managed account composite return, and how widely did its member accounts' personal returns disperse around it?",
        ],
        grain=("Managed account (15) x active model assignment (46) x business date, valued from End of Day 49 Client Holdings, "
               "with composite membership (composite x account x membership period) as a companion fact; published aggregate at "
               "program x model x regulatory AUM classification x month-end; daily snapshots, month-ends locked"),
        dimensions=["Client account (DP-093)", "Client Household (DP-240)", "Program enrollment and service offering (DP-004)",
                    "Model portfolio (DP-004)", "Regulatory AUM Classification (DP-304)", "Discretion exercised (DP-304)",
                    "Sleeve and sub-adviser engagement (DP-304, DP-306)", "Managed account composite (DP-304)",
                    "Composite exclusion reason", "Account business line", "Business date and month-end (DP-013)"],
        measures=[
            ("Managed Accounts",
             "Count of distinct Assigned Account of 46 Model Assignment rows with Assignment Status = Active and Assignment "
             "Effective From <= business date < Assignment Effective To (or open) whose 15 Account has Account Type = Managed "
             "Advisory Account and Account Status = Open, by Enrolled Service Offering of the Assignment Program Enrollment, "
             "Assigned Model Portfolio, Discretion Exercised and Regulatory AUM Classification.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assignment Program Enrollment",
                "Assigned Model Portfolio", "Discretion Exercised", "Regulatory AUM Classification", "Assignment Status",
                "Assignment Effective From", "Assignment Effective To")
             + _u("15", "Account", "Account ID", "Account Type", "Account Status")
             + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Service Offering")),
            ("Managed Account Market Value",
             "For the Managed Accounts on the business date: Market Value in USD of their 49 Client Holdings with Client Holding "
             "View = End of Day and Client Holding Date = business date, plus Cash Balance Amount of their Account Cash Balance "
             "rows with Balance Basis = Settlement Date and Cash Balance Type in (Free Credit Balance, Sweep Balance, Short Sale Proceeds) on Cash Balance Business Date = business date (the DP-007 client cash rule), less Margin Debit Balance of "
             "their Margin Balance Snapshot on Margin Snapshot Business Date = business date; own-fund holdings included; by "
             "program, model, Discretion Exercised and Regulatory AUM Classification (USD).",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type",
                  "Balance Basis", "Cash Balance Amount")
             + _u("49", "Margin Balance Snapshot", "Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Debit Balance")
             + ["Managed Accounts"]),
            ("Own-Fund Holdings in Managed Accounts",
             "Market Value in USD of the End of Day 49 Client Holdings with Own Share Class Indicator = Y on the business date of "
             "the Managed Accounts whose active assignment has Regulatory AUM Classification in (Discretionary, Non-Discretionary): own mutual funds, ETFs and CITs held in managed accounts, which Firm AUM counts in the own funds "
             "slice at NAV and therefore leaves out of the managed account slice.",
             _u("49", "Client Holding", "Own Share Class Indicator", "Client Holding View", "Client Holding Date")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("46", "Model Assignment", "Regulatory AUM Classification") + ["Managed Accounts"]),
            ("Managed Account Assets (Discretionary and Non-Discretionary)",
             "Operational measure (not certified here); DP-241 certifies the Firm AUM Managed Account Slice from it (CW-011, "
             "CW-212): at each month-end (the last business day, End of "
             "Day), for the 15 accounts with a 46 Model Assignment of Assignment Status = Active in force on the month-end "
             "(Assignment Effective From <= month-end < Assignment Effective To or open), whose 15 Account has Account Type = Managed "
             "Advisory Account and Account Status = Open, and Regulatory AUM Classification in "
             "(Discretionary, Non-Discretionary): Market Value in USD of their End of Day 49 Client Holdings with Own Share Class "
             "Indicator not Y, plus Cash Balance Amount under the DP-007 client cash rule (Balance Basis = Settlement Date and Cash Balance Type in (Free Credit Balance, Sweep Balance, Short Sale Proceeds), Cash Balance Business Date = month-end), "
             "less Margin Debit Balance (Margin Snapshot Business Date = month-end); each account counted once even with several "
             "sleeves. Published by program, model and Regulatory AUM Classification and as one firm total (USD); restated only "
             "as a new version of the month.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assignment Status",
                "Regulatory AUM Classification", "Assignment Effective From", "Assignment Effective To")
             + _u("15", "Account", "Account ID", "Account Type", "Account Status")
             + _u("49", "Client Holding", "Holding Account", "Client Holding Date", "Client Holding View", "Own Share Class Indicator")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type",
                  "Balance Basis", "Cash Balance Amount")
             + _u("49", "Margin Balance Snapshot", "Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Debit Balance")),
            ("Managed Assets Outside Regulatory AUM",
             "Managed Account Market Value of the Managed Accounts whose active assignment has Regulatory AUM Classification = Not "
             "Regulatory AUM (for example model-delivery or advice-only arrangements), shown beside Managed Account Assets (Discretionary and Non-Discretionary) so the "
             "difference to Managed Account Market Value is explained.",
             _u("46", "Model Assignment", "Regulatory AUM Classification") + ["Managed Account Market Value"]),
            ("Discretionary Share of Managed Account Assets %",
             "Managed Account Assets (Discretionary and Non-Discretionary) of the accounts with Regulatory AUM Classification = Discretionary / "
             "Managed Account Assets (Discretionary and Non-Discretionary), at the month-end, by program.",
             _u("46", "Model Assignment", "Regulatory AUM Classification") + ["Managed Account Assets (Discretionary and Non-Discretionary)"]),
            ("Model Adoption",
             "Per Assigned Model Portfolio on the business date: count of Managed Accounts and their Managed Account Market Value, "
             "with the model's share of its program's Managed Account Market Value (%), by Model Portfolio Name and the model's "
             "Implemented Strategy.",
             _u("46", "Model Assignment", "Assigned Model Portfolio")
             + _u("01", "Model Portfolio", "Model Portfolio ID", "Model Portfolio Name", "Implemented Strategy")
             + ["Managed Accounts", "Managed Account Market Value"]),
            ("Assets Moved by Model Change",
             "Managed Account Market Value, on the day before Assignment Effective From, of the accounts whose new Model Assignment "
             "(Previous Model Assignment populated) took effect in the period, by from and to Assigned Model Portfolio and "
             "Assignment Reason (USD).",
             _u("46", "Model Assignment", "Previous Model Assignment", "Assignment Reason", "Assignment Effective From",
                "Assigned Model Portfolio")
             + ["Managed Account Market Value"]),
            ("Sub-Advised Sleeve Accounts",
             "Count of Managed Accounts with at least one 46 Sleeve Assignment (Sleeve Model Assignment = Model Assignment ID) in "
             "effect on the business date (Sleeve Effective From <= date < Sleeve Effective To or open) whose Sleeve Sub-Adviser "
             "Engagement is populated, and the count with two or more sleeves in effect, by Sleeve Model Portfolio.",
             _u("46", "Sleeve Assignment", "Sleeve Model Assignment", "Sleeve Sequence", "Sleeve Model Portfolio",
                "Sleeve Sub-Adviser Engagement", "Sleeve Effective From", "Sleeve Effective To")
             + ["Managed Accounts"]),
            ("Composite Member Market Value",
             "Per 46 Managed Account Composite with Composite Status = Active on the business date (Composite Effective From / To): "
             "count of Managed Account Composite Membership rows with Membership Start Date <= date and Membership End Date blank "
             "or after it, and the Managed Account Market Value of those Member Accounts (USD), by Composite Program and "
             "Composite Model Portfolio.",
             _u("46", "Managed Account Composite", "Managed Account Composite ID", "Composite Name", "Composite Program",
                "Composite Model Portfolio", "Composite Status", "Composite Effective From", "Composite Effective To")
             + _u("46", "Managed Account Composite Membership", "Membership Composite", "Member Account", "Membership Start Date",
                  "Membership End Date")
             + ["Managed Account Market Value"]),
            ("Eligible Accounts Outside Composite",
             "Count and Managed Account Market Value of Managed Accounts whose active assignment's program (Enrolled Service "
             "Offering) and Assigned Model Portfolio match an active composite's Composite Program and Composite Model Portfolio, "
             "with Managed Account Market Value at or above Composite Minimum Account Value, and no current membership of that "
             "composite; with the excluded memberships counted by Composite Exclusion Reason and Discretion Check Passed "
             "Indicator.",
             _u("46", "Managed Account Composite", "Composite Program", "Composite Model Portfolio", "Composite Minimum Account Value")
             + _u("46", "Managed Account Composite Membership", "Membership Model Assignment", "Composite Exclusion Reason",
                  "Discretion Check Passed Indicator")
             + ["Managed Accounts", "Managed Account Market Value", "Composite Member Market Value"]),
            ("Composite Coverage %",
             "Composite Member Market Value / Managed Account Market Value of the Managed Accounts in the composite's program and "
             "model, on the business date.",
             ["Composite Member Market Value", "Managed Account Market Value"]),
            ("Managed Account Composite Return (from DP-145)",
             "Return Value of the 32 Performance Return rows with Return Subject Type = Managed Account Composite, Return Managed "
             "Account Composite = Managed Account Composite ID and Return Status in (Final, Restated), highest version, by Return "
             "Period Start Date, Return Period End Date and Return Fee Basis, as DP-145 publishes it; never recomputed here.",
             _u("32", "Performance Return", "Performance Return ID", "Return Subject Type", "Return Managed Account Composite",
                "Return Period Start Date", "Return Period End Date", "Return Fee Basis", "Return Value", "Return Status")),
            ("Composite Excess Return (from DP-145)",
             "Managed Account Composite Return (from DP-145) minus the Benchmark Return Value of the composite's benchmark for "
             "the same period (32 Benchmark Return with Benchmark Return Status Final, highest Benchmark Return Version, as DP-145 "
             "publishes it); never recomputed here.",
             _u("32", "Benchmark Return", "Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                "Benchmark Return Version", "Benchmark Return Value", "Benchmark Return Status")
             + ["Managed Account Composite Return (from DP-145)"]),
            ("Composite Return Dispersion",
             "Per composite and period: the asset-weighted standard deviation of the account Personal Return Value (from DP-145; "
             "Personal Return Method = Time-Weighted, Personal Return Status in (Final, Restated)) of the Member Accounts that were "
             "members for the whole period, weighted by their Managed Account Market Value at period start; not calculated for "
             "fewer than 6 such members.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Account",
                "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Method",
                "Personal Return Value", "Personal Return Status")
             + _u("46", "Managed Account Composite Membership", "Membership Start Date", "Membership End Date")
             + ["Managed Account Market Value"]),
            ("Managed Accounts Without Valuation",
             "Count of Managed Accounts with no End of Day 49 Client Holding and no Account Cash Balance row with Balance Basis = Settlement Date on the "
             "business date: accounts missing from the managed account assets for a data reason, by program.",
             _u("49", "Client Holding", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Business Date", "Balance Basis")
             + ["Managed Accounts"]),
        ],
        inputs=[
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Program Enrollment",
                                        "Assigned Model Portfolio", "Assignment Reason", "Discretion Exercised",
                                        "Regulatory AUM Classification", "Assignment Status", "Assignment Effective From",
                                        "Assignment Effective To", "Previous Model Assignment"]),
            ("46", "Sleeve Assignment", ["Sleeve Model Assignment", "Sleeve Sequence", "Sleeve Model Portfolio",
                                         "Sleeve Sub-Adviser Engagement", "Sleeve Effective From", "Sleeve Effective To"]),
            ("46", "Managed Account Composite", ["Managed Account Composite ID", "Composite Name", "Composite Program",
                                                 "Composite Model Portfolio", "Composite Minimum Account Value", "Composite Status",
                                                 "Composite Effective From", "Composite Effective To"]),
            ("46", "Managed Account Composite Membership", ["Membership Composite", "Member Account", "Membership Model Assignment",
                                                            "Membership Start Date", "Membership End Date",
                                                            "Discretion Check Passed Indicator", "Composite Exclusion Reason"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name", "Implemented Strategy"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Service Offering"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View",
                                      "Own Share Class Indicator"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type", "Balance Basis",
                                            "Cash Balance Amount"]),
            ("49", "Margin Balance Snapshot", ["Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Debit Balance"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Subject Type", "Return Managed Account Composite",
                                          "Return Period Start Date", "Return Period End Date", "Return Fee Basis",
                                          "Return Value", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Version", "Benchmark Return Value", "Benchmark Return Status"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Account",
                                               "Personal Return Period Start Date", "Personal Return Period End Date",
                                               "Personal Return Method", "Personal Return Value", "Personal Return Status"]),
        ],
        upstream=["DP-304", "DP-300", "DP-145", "DP-093", "DP-004", "DP-240", "DP-306", "DP-013"],
        refresh="Daily",
        timeliness="Daily by 8am ET on T+1 from the End of Day 49 Client Holdings; the month-end managed account assets locked by business day 3 after month-end, before DP-241 runs",
        history="Daily snapshots kept 2 years and month-end versions kept 7 years, every restatement as a new version of the month; account-grain rows retained 6 years with the advisory records (SEC Rule 204-2)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Assigned Account and Member Account resolves to an open DP-093 account with Account Type = Managed Advisory Account (never an 18 portfolio), every Assigned Model Portfolio and Sleeve Model Portfolio to DP-004, and every Membership Composite to a DP-304 Managed Account Composite.",
            "No account has two Active Model Assignment rows in force on one date, composite memberships of one account and composite do not overlap, and every effective-to and end date is on or after its start.",
            "The month-end Market Value in USD summed here for each managed account equals DP-300's Client Holdings Market Value for the same account and date within USD 1, and Managed Account Market Value = Managed Account Assets (Discretionary and Non-Discretionary) + Own-Fund Holdings in Managed Accounts + Managed Assets Outside Regulatory AUM within USD 1 (DP-241 ties its slice to this product, never the reverse).",
            "Regulatory AUM Classification, Discretion Exercised and Assignment Effective From are populated on every active assignment, and every Managed Account has an End of Day 49 Client Holding or an Account Cash Balance row with Balance Basis = Settlement Date and Cash Balance Type in (Free Credit Balance, Sweep Balance, Short Sale Proceeds) on the business date (Managed Accounts Without Valuation = 0 at month-end before the lock).",
            "Account-grain rows are published only in the Confidential - Client view to managed account operations, finance and supervision roles; the BI semantic model carries the managed account assets and market values by program, model, classification and composite only, and dispersion is not shown for composites with fewer than 6 full-period members.",
            "The month-end managed account assets are locked on business day 3 after month-end; a later change to a 49 valuation or a 46 assignment creates a new version of the month that DP-241 picks up, and a locked version is never overwritten.",
        ],
        notes=("Certified numbers: none owned. Publishes the operational measure Managed Account Assets (Discretionary and "
               "Non-Discretionary) (F5 review ruling); DP-241 certifies the Firm AUM Managed Account Slice (CW-011; "
               "semantic_model/register.CERTIFIED_WEALTH 'Firm AUM - Managed Accounts') from it, owns Firm AUM and the "
               "reconciliation to Client Assets (CW-206, CW-212), and this product never lists DP-241. Slice owner: Head of Managed Account "
               "Operations. Own-fund holdings are removed from these assets because the own funds slice counts them at NAV (F5 "
               "netting ruling); the Client Assets overlap is netted only in DP-241. Reads Personal Return Value and the managed "
               "account composite returns from DP-145 (CW-251) and never computes a return. Client Assets are DP-008's and are "
               "never summed with these assets. Book of record: Client Holding (49) through DP-300 (CW-007); a retail managed account "
               "is a 15 account managed in 46, never an 18 portfolio. PII tier: financial. Account-grain rows are Confidential - "
               "Client; aggregates only in the semantic model (DQ5). Boundaries: DP-304 publishes the assignments, sleeves and "
               "composite memberships and their counts (Active Model Assignments, Model Changes, Active Composite Members); this "
               "product values them and never redefines those counts. Drift and rebalancing are DP-341's, tax management "
               "DP-342's, billing DP-346's. Backlog DP-534 Managed Account Program Performance & Dispersion folds in here "
               "(composite returns against benchmark, and dispersion); DP-534's 24 Model Lineup Position is not read: lineup "
               "positions are DP-530's and the composite is keyed to the model, not the lineup. Objects of the candidate: 01 Service Offering is read through DP-004 by the "
               "Enrolled Service Offering key and is not re-read; all other candidate objects are read. Acceptance question 1 "
               "(plan section 8.5): feeds DP-241 with Managed Account Assets (Discretionary and Non-Discretionary), certified there as Firm AUM Managed Account Slice (mastering domains 46 and 49). Tailoring "
               "lever: managed account slice scope. Reference default: Discretionary and Non-Discretionary regulatory AUM, own "
               "funds removed, margin debit netted. Tailoring lever: participant managed accounts (16, WR line). Reference "
               "default: outside this product and DP-241's slice (they are not 15 managed advisory accounts). Register note: supporting function FN-33 Fund Accounting & Administration does not decide on retail managed accounts (FN-38 or FN-75 would fit); reported, not changed. Tailoring lever: GIPS "
               "presentation of managed account composites (46 SME 8). Reference default: operational composites only; Linked "
               "GIPS Composite blank is not a defect. Tailoring lever: self-directed-only firm (plan section 4 item 4). Reference "
               "default: managed accounts offered; without them this product and the managed account slice of DP-241 drop. Taxonomy gap: 46 Model "
               "Assignment carries no month-end slice lock or version, so the version of the month is held by this product's "
               "snapshot. Drafting assumptions: Assignment Status and Composite Status = Active; the DP-007 client cash rule (Balance Basis Settlement Date; Free Credit Balance, Sweep Balance, Short Sale Proceeds); "
               "Personal Return Method value Time-Weighted; the minimum of 6 members for dispersion; the USD 1 tolerance; business "
               "day 3 lock. Decisions: CW-007, CW-011, CW-047, CW-050, CW-142, CW-206, CW-209, CW-212, CW-251. WP1 new (CW-205, "
               "CW-212): first specification, written first in the CLA-A wave so DP-241 can read the managed account assets."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-322": dict(
        definition=("The restricted register of clients the firm must protect: specified adult status under FINRA Rule 2165, "
                    "vulnerability concerns (suspected exploitation, diminished capacity, undue influence, scam victimization, "
                    "financial hardship), the temporary holds placed on securities transactions (15) and disbursements (50) under "
                    "Rule 2165, the 08 senior investor cases, protective actions and external reports opened on them, and the "
                    "trusted contacts and authority grants that bear on each case. It is the restricted view every "
                    "special-category client read goes through (CW-213, CD-344), and it publishes the one unrestricted field other "
                    "products may carry: Protection Flag Present, with no reason, basis or date. It owns no certified metric family."),
        business_questions=[
            "Which clients carry an open vulnerability concern, an impairment-based specified adult status or an active Rule 2165 hold today, and which carry the protection flag?",
            "Which Rule 2165 holds on disbursements and transactions are active, on which accounts and for how much money?",
            "Which senior investor cases are open or closed, and which concerns and holds do they cover?",
            "Which protected clients have no trusted contact on file, or an active power of attorney or other authority grant that bears on the case?",
            "Which specified adults and open concerns are in the register, by basis and concern type?",
        ],
        grain=("Protected client (02 party) x as-of date, with Protection Flag Present per party and per 15 account; companion "
               "restricted facts at vulnerability concern, account restriction (Rule 2165 rows), money movement hold (Rule 2165 "
               "and 2166 rows), senior investor case, case action and external protection report; daily snapshot, SCD type 2 on "
               "the flag"),
        dimensions=["Client and Client Household (DP-240)", "Client account (DP-093)", "Specified adult basis (restricted)",
                    "Concern type (restricted)", "Hold type and hold status (restricted)", "Senior investor case status",
                    "As-of date (DP-013)"],
        measures=[
            ("Protection Flag Present",
             "The one unrestricted field (CW-213): Y for a 02 Party ID on the as-of date when any of: a Specified Adult Status row "
             "in effect (Specified Adult Status Effective From <= as-of < Specified Adult Status Effective To or open) with "
             "Specified Adult Indicator = Y and Specified Adult Basis = Age 18 or Older - Reasonable Belief of Impairment; a "
             "Vulnerability Concern (Concern Party = Party ID) with Concern Status not in (Resolved / Completed, Closed, Canceled); "
             "an 08 Senior Investor Case (Case Client) with Case Status open; an active 15 Account Restriction of Account "
             "Restriction Type = Financial Exploitation (Account Restriction Effective From <= as-of, Account Restriction Lifted "
             "Date blank or later) on an account where the party holds an Account Party Role in effect; or a 50 Money Movement "
             "Hold of Hold Type in (FINRA Rule 2165 Disbursement Hold, FINRA Rule 2166 Temporary Delay) with Hold Status in "
             "(Active, Extended) on a Money Movement of such an account. Y for a 15 Account ID when any owner party is Y or the "
             "account carries such a restriction or hold. Otherwise N. Published with Party ID or Account ID only.",
             _u("02", "Party", "Party ID")
             + _u("02", "Specified Adult Status", "Specified Adult Indicator", "Specified Adult Basis",
                  "Specified Adult Status Effective From", "Specified Adult Status Effective To")
             + _u("02", "Vulnerability Concern", "Concern Party", "Concern Status")
             + _u("08", "Senior Investor Case", "Case Client", "Case Status")
             + _u("15", "Account Restriction", "Restricted Account", "Account Restriction Type", "Account Restriction Effective From",
                  "Account Restriction Lifted Date")
             + _u("15", "Account Party Role", "Role Party", "Role Account", "Account Role Effective From", "Account Role Effective To")
             + _u("15", "Account", "Account ID")
             + _u("50", "Money Movement Hold", "Held Movement", "Hold Type", "Hold Status")
             + _u("50", "Money Movement", "Money Movement ID", "Movement Account")),
            ("Protected Clients",
             "Count of distinct Party ID with Protection Flag Present = Y on the as-of date, with the count of accounts flagged.",
             _u("02", "Party", "Party ID") + ["Protection Flag Present"]),
            ("Specified Adults",
             "Count of parties with a Specified Adult Status row in effect on the as-of date and Specified Adult Indicator = Y, by "
             "Specified Adult Basis (restricted view).",
             _u("02", "Specified Adult Status", "Specified Adult Indicator", "Specified Adult Basis",
                "Specified Adult Status Effective From", "Specified Adult Status Effective To", "Specified Adult Determination Date")),
            ("Open Vulnerability Concerns",
             "Count of Vulnerability Concern ID with Concern Status not in (Resolved / Completed, Closed, Canceled) on the as-of "
             "date, by Concern Type, with the median days since Concern Raised Date (restricted view).",
             _u("02", "Vulnerability Concern", "Vulnerability Concern ID", "Concern Type", "Concern Raised Date", "Concern Status")),
            ("Active Rule 2165 Holds",
             "Count of active 15 Account Restriction rows with Account Restriction Type = Financial Exploitation plus 50 Money "
             "Movement Hold rows with Hold Type = FINRA Rule 2165 Disbursement Hold and Hold Status in (Active, Extended), on the "
             "as-of date, with the sum of Movement Amount of the held disbursements (USD), by hold kind; the hold rows are published "
             "in the restricted view with Hold Placed Date, Hold Expiry Date, Hold Notice Date, Trusted Contact Notified, Hold "
             "Released Date and their Senior Investor Case and Paired Account Restriction keys, without any hold-clock measure "
             "(DP-403 owns the Rule 2165 clock).",
             _u("15", "Account Restriction", "Account Restriction ID", "Account Restriction Type",
                "Account Restriction Effective From", "Account Restriction Lifted Date")
             + _u("50", "Money Movement Hold", "Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Status",
                  "Hold Placed Date", "Hold Expiry Date", "Hold Notice Date", "Trusted Contact Notified", "Hold Released Date",
                  "Senior Investor Case", "Paired Account Restriction", "Source Vulnerability Concern")
             + _u("50", "Money Movement", "Money Movement ID", "Movement Amount")),
            ("Rule 2165 Restriction Rows",
             "The published restricted rows of 15 Account Restriction with Account Restriction Type = Financial Exploitation: "
             "Account Restriction ID, Restricted Account, Account Restriction Effective From, Account Restriction Lifted Date, "
             "Restriction Review Due Date and Source Vulnerability Concern, with the count active on the as-of date (restricted "
             "view; DP-403 and DP-456 read the rows and own their clocks).",
             _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Type",
                "Account Restriction Effective From", "Account Restriction Lifted Date", "Restriction Review Due Date",
                "Source Vulnerability Concern")),
            ("Senior Investor Case Rows",
             "The published 08 Senior Investor Case key rows: Senior Investor Case ID, Case Client, Source Vulnerability Concern, "
             "Case Status and Case Closed Date, with the count open on the as-of date (restricted view); case work, actions and "
             "reports are DP-403's.",
             _u("08", "Senior Investor Case", "Senior Investor Case ID", "Case Client", "Source Vulnerability Concern",
                "Case Status", "Case Closed Date")),
            ("Protected Clients Without Trusted Contact",
             "Protected Clients with no Trusted Contact Designation (Designating Client = Party ID) in effect with Designation "
             "Status = Provided.",
             _u("02", "Trusted Contact Designation", "Designating Client", "Designation Status", "Designation Effective From",
                "Designation Effective To")
             + ["Protected Clients"]),
            ("Protected Clients With Active Authority Grant",
             "Protected Clients who are Grantor Party of an Authority Grant with Grant Effective From <= as-of date and Revoked Date "
             "blank, by Authority Type and Authority Scope: the agent relationships a case review must test.",
             _u("02", "Authority Grant", "Authority Grant ID", "Grantor Party", "Authority Holder", "Authority Type",
                "Authority Scope", "Grant Effective From", "Revoked Date")
             + ["Protected Clients"]),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
            ("02", "Specified Adult Status", ["Specified Adult Indicator", "Specified Adult Basis", "Specified Adult Determination Date",
                                              "Specified Adult Status Effective From", "Specified Adult Status Effective To",
                                              "Determined By"]),
            ("02", "Vulnerability Concern", ["Vulnerability Concern ID", "Concern Party", "Concern Type", "Concern Raised Date",
                                             "Trusted Contact Contacted Date", "Trusted Contact Designation Used",
                                             "Escalation Case Reference", "Concern Status"]),
            ("02", "Trusted Contact Designation", ["Trusted Contact Designation ID", "Designating Client", "Trusted Contact Person",
                                                   "Designation Status", "Designation Effective From", "Designation Effective To"]),
            ("02", "Authority Grant", ["Authority Grant ID", "Grantor Party", "Authority Holder", "Authority Type",
                                       "Authority Scope", "Grant Effective From", "Revoked Date"]),
            ("15", "Account", ["Account ID", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date",
                                           "Restriction Review Due Date", "Source Vulnerability Concern"]),
            ("08", "Senior Investor Case", ["Senior Investor Case ID", "Case Client", "Source Vulnerability Concern", "Case Status",
                                            "Case Closed Date"]),
            ("50", "Money Movement Hold", ["Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Status", "Hold Placed Date",
                                           "Hold Expiry Date", "Trusted Contact Notified", "Hold Notice Date",
                                           "Source Vulnerability Concern", "Paired Account Restriction", "Senior Investor Case",
                                           "Hold Released Date"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Movement Amount"]),
        ],
        upstream=["DP-240", "DP-093", "DP-302", "DP-192", "DP-013"],
        refresh="Intraday",
        timeliness="Protection Flag Present refreshed within 15 minutes of a concern, case, hold or specified adult change; full rebuild by 6am ET daily",
        history="SCD type 2 on Protection Flag Present and every restricted row, kept 6 years after the case or concern closes (SEC Rule 17a-4 and FINRA Rule 2165(c) records of holds); daily snapshots kept as evidence of what consumers were given",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["API", "Event stream", "Warehouse table", "Dashboard"],
        dq_rules=[
            "Every Concern Party, Case Client, Designating Client and Grantor Party resolves to an active DP-240 party, every Restricted Account and Role Account to a DP-093 account, every Held Movement to a DP-302 money movement, and every Determined By to a DP-192 employee.",
            "Specified Adult Status periods of one party do not overlap for the same Specified Adult Basis, and Specified Adult Status Effective To, Account Restriction Lifted Date, Hold Released Date and Case Closed Date are on or after their start dates.",
            "Every 15 Account Restriction with Account Restriction Type = Financial Exploitation and every 50 hold of a Rule 2165 or 2166 Hold Type has a Senior Investor Case (directly or through Source Vulnerability Concern), and Protection Flag Present = Y on every party and account those rows name; Active Rule 2165 Holds reconciles to the special-category hold rows DP-302 suppresses, count for count.",
            "Concern Type, Concern Raised Date and Concern Status are populated on every Vulnerability Concern, Hold Placed Date and Hold Expiry Date on every Rule 2165 hold, and Case Status on every Senior Investor Case (Case Closed Date on every closed case).",
            "Restricted-view rule: only Party ID, Account ID and Protection Flag Present are published outside the restricted view; every other column is visible only to retail conduct, the senior investor team and named service roles; Concern Description, Hold Reason Narrative and Purpose texts are never read; any aggregate shown outside the restricted view has a minimum cell size of 10 parties and smaller cells are suppressed.",
            "Protection Flag Present changes are published within 15 minutes of the source change, and a flag that was Y is never removed from a prior daily snapshot.",
        ],
        notes=("Master concept: none mastered; it is the CW-213 restricted view over 02 Specified Adult Status and Vulnerability "
               "Concern, the Rule 2165 rows of 15 Account Restriction and 50 Money Movement Hold, and the 08 senior investor "
               "case. Certified numbers: none (It owns no certified metric family). PII tier: special category (CD-344). The "
               "restricted-view rule (WP1 item for DP-322, DP-456 and DP-403): only Party ID, Account ID and Protection Flag "
               "Present leave the restricted view; detail rows are visible to retail conduct, the senior investor team and named "
               "service roles; aggregates outside it carry a minimum cell size of 10 (DQ5). This is the one product that reads 02, "
               "15, 50 and 08 special-category rows directly; DP-302 suppresses the special-category hold values and leaves the "
               "hold facts to this product (F3 ruling). Narrower named restricted views: DP-403 reads the 08 Rule 2165 case and "
               "DP-352 the 51 special-needs purposes. Every other product lists DP-322 upstream and carries only Protection Flag "
               "Present (from DP-322). Boundaries: DP-456 (Fraud & Elder-Exploitation Holds, BWO) answers acceptance question 7 "
               "over this view and DP-403 (Senior Investor Case Management & Rule 2165 Holds, CLA-B) works the cases; DP-583 "
               "reads it too; none of them is listed here. DP-321 owns the trusted contact register. Acceptance question 7: feeds "
               "DP-456 with Protection Flag Present (DP-456 reads the 50 hold rows itself); DP-403 reads the Rule 2165 hold, "
               "restriction and case key rows published here (mastering domains 02, 50, 08). Publication ruling (C-1 fix pass, "
               "with C-2 and C-3): this product publishes rows and register counts only; the hold clock, notice timeliness, case "
               "ageing and agency reporting measures belong to DP-403. Tailoring lever: which special-category facts advisors may record (02 SME 5). "
               "Reference default: specified adult status and vulnerability concerns only. Tailoring lever: whether age-based "
               "specified adult status alone sets the flag. Reference default: no; only the impairment basis, open concerns, "
               "cases and holds set it (age is derivable from the 02 date of birth and would flag a large share of clients). "
               "Tailoring lever: FINRA Rule 2166 temporary delay. Reference default: included as proposed (confirm). Taxonomy "
               "gap: 02 Specified Adult Status is an attribute group with no party key of its own, so its join to Party ID is "
               "implicit. Drafting assumptions: the open Case Status "
               "values; Hold Status Active and Extended; minimum cell size 10. Decisions: CW-007, CW-213, CD-344. WP1 new "
               "(CW-213): first specification, written second in the CLA-A wave because DP-403, DP-456 and DP-583 read it."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-324": dict(
        definition=("The one answer to whether, how and about what the firm may contact each client: valid and verified contact "
                    "points and postal addresses, do-not-contact channels, topic subscriptions and their consents, the GLBA and "
                    "affiliate-marketing opt-outs, e-delivery elections and mail holds, joined to the marketing suppression list. "
                    "Campaigns, service outreach and statement production read its per-party contact permissions instead of "
                    "re-deriving contact rules. It owns no certified metric family."),
        business_questions=[
            "Which clients can be contacted today on each channel, and which have no valid, verified contact point at all?",
            "Which clients may receive marketing on which topics and channels, and are their opt-ins backed by a granted, unexpired consent?",
            "Which opt-outs, withdrawn consents and do-not-contact instructions have not reached the suppression list within the service standard?",
            "Which accounts have been on a mail hold for over 3 months without the re-verification FINRA Rule 3150 expects, and which clients have returned mail at their address of record?",
            "Which affiliate-marketing opt-outs are about to expire, and which deceased clients are still contactable for marketing?",
        ],
        grain=("Party (02) x contact channel x as-of date (contact permission), with companion facts at party x subscription topic "
               "x channel (marketing permission) and account x delivery election (statement contact mode); SCD type 2 on every "
               "permission"),
        dimensions=["Client and Client Household (DP-240)", "Client account (DP-093)", "Contact channel", "Contact point usage",
                    "Subscription topic", "Consent purpose", "Delivery preference and document scope (DP-382)",
                    "Suppression reason", "As-of date (DP-013)"],
        measures=[
            ("Contactable Clients by Channel",
             "Count of distinct Contact Point Party with a Contact Point of the Contact Channel in effect (Contact Point Effective "
             "From <= as-of < Contact Point Effective To or open) and Contact Point Verified Indicator = Y, whose Party Status = "
             "Active, Do Not Contact Indicator is not Y, Date of Death is blank, and the channel is not in Do Not Contact Channels "
             "of the Contact Preference in effect; by Contact Channel and Contact Point Usage.",
             _u("02", "Contact Point", "Contact Point ID", "Contact Point Party", "Contact Channel", "Contact Point Usage",
                "Contact Point Verified Indicator", "Contact Point Effective From", "Contact Point Effective To")
             + _u("02", "Party", "Party ID", "Party Status")
             + _u("02", "Privacy Profile", "Do Not Contact Indicator")
             + _u("02", "Individual", "Date of Death")
             + _u("02", "Contact Preference", "Preference Holder", "Do Not Contact Channels", "Preference Effective From",
                  "Preference Effective To")),
            ("Clients Without Valid Contact Point",
             "Count of active client parties with no Contact Point in effect with Contact Point Verified Indicator = Y on any "
             "channel, and the count with no Primary Contact Point Indicator = Y in effect.",
             _u("02", "Contact Point", "Contact Point Party", "Contact Point Verified Indicator", "Primary Contact Point Indicator",
                "Contact Point Effective From", "Contact Point Effective To")
             + _u("02", "Party", "Party ID", "Party Status")),
            ("Preferred Contact Point Invalid",
             "Count of Contact Preference rows in effect whose Preferred Contact Point resolves to a Contact Point that has ended, "
             "is not verified, or whose Contact Channel differs from Preferred Contact Channel.",
             _u("02", "Contact Preference", "Preferred Contact Channel", "Preferred Contact Point", "Preference Effective From",
                "Preference Effective To")
             + _u("02", "Contact Point", "Contact Point ID", "Contact Channel", "Contact Point Verified Indicator",
                  "Contact Point Effective To")),
            ("Clients With Returned Mail",
             "Count of parties whose postal Contact Point in effect has a Postal Address with Mail Returned Date on or after "
             "Contact Point Effective From: the address of record is known bad and postal contact is suspended until a new "
             "address is verified.",
             _u("02", "Postal Address", "Postal Code", "Country", "Mail Returned Date")
             + _u("02", "Contact Point", "Contact Point Party", "Contact Channel", "Contact Point Effective From")),
            ("Marketing Permissions by Topic and Channel",
             "Count of Communication Preference rows with Opt-In Status = Opted In, by Preference Topic and Preference Channel, "
             "for parties counted in Contactable Clients by Channel for that channel; email, text and telephone permissions count "
             "only where Consent Record Reference resolves to a Consent Record with Consent Status = Granted and Consent Expiry "
             "Date blank or after the as-of date (Consent Purpose Marketing Email, Marketing Text Messages or Marketing Telephone).",
             _u("02", "Communication Preference", "Preference Party", "Preference Topic", "Preference Channel", "Opt-In Status",
                "Consent Record Reference")
             + _u("02", "Consent Record", "Consent Record ID", "Consent Purpose", "Consent Status", "Consent Expiry Date")
             + ["Contactable Clients by Channel"]),
            ("Marketing Permission",
             "Per party x Preference Topic x Preference Channel: Y when the party is counted in Contactable Clients by Channel for "
             "the channel and its Communication Preference has Opt-In Status = Opted In backed (for email, text and telephone) by a "
             "Granted, unexpired Consent Record, and no Suppression Entry is in effect for it; N otherwise. The per-party field "
             "audiences (DP-412) read.",
             _u("02", "Communication Preference", "Preference Party", "Preference Topic", "Preference Channel", "Opt-In Status")
             + _u("04", "Suppression Entry", "Suppressed Identifier", "Suppression Effective From")
             + ["Contactable Clients by Channel", "Marketing Permissions by Topic and Channel"]),
            ("Opt-Ins Without Valid Consent",
             "Communication Preference rows with Opt-In Status = Opted In on Preference Channel email, text or telephone whose "
             "Consent Record Reference is blank or resolves to a Consent Record with Consent Status in (Withdrawn, Expired, "
             "Declined) or Consent Expiry Date before the as-of date.",
             _u("02", "Communication Preference", "Opt-In Status", "Preference Channel", "Consent Record Reference")
             + _u("02", "Consent Record", "Consent Status", "Consent Expiry Date", "Consent Withdrawn Timestamp")),
            ("Opt-Outs Not Suppressed",
             "Count of Communication Preference rows with Opt-Out Timestamp, Consent Record rows with Consent Withdrawn Timestamp "
             "for a marketing Consent Purpose, and parties with Do Not Contact Indicator = Y, for which no 04 Suppression Entry "
             "(Revoked Consent Record = the Consent Record ID, or the party's hashed contact point as Suppressed Identifier) has "
             "Suppression Effective From within 10 business days of the opt-out; by Suppression Reason expected.",
             _u("02", "Communication Preference", "Opt-Out Timestamp", "Consent Record Reference")
             + _u("02", "Consent Record", "Consent Record ID", "Consenting Party", "Consent Purpose", "Consent Withdrawn Timestamp")
             + _u("02", "Privacy Profile", "Do Not Contact Indicator")
             + _u("04", "Suppression Entry", "Suppressed Identifier", "Suppression Reason", "Suppression Scope",
                  "Suppression Effective From", "Revoked Consent Record")),
            ("Suppression Coverage %",
             "Parties with an opt-out, withdrawn marketing consent or Do Not Contact Indicator = Y that have a Suppression Entry "
             "in effect / all such parties; the one owner of suppression coverage (DP-080 reads it for privacy requesters).",
             _u("04", "Suppression Entry", "Suppressed Identifier", "Suppression Effective From")
             + ["Opt-Outs Not Suppressed"]),
            ("Affiliate Marketing Opt-Outs Expiring",
             "Count of parties with Affiliate Marketing Opt-Out Indicator = Y whose Affiliate Marketing Opt-Out Expiry Date falls "
             "within the next 90 days (Regulation S-AM renewal notice); the opt-outs in force are counted in DP-080.",
             _u("02", "Privacy Profile", "Affiliate Marketing Opt-Out Indicator", "Affiliate Marketing Opt-Out Expiry Date")),
            ("Paper-Only Accounts",
             "Count of open accounts whose owners have no 13 E-Delivery Election in effect with Delivery Preference electronic for "
             "Election Document Scope statements (Election Revoked Timestamp blank), so postal delivery is the contact mode; and "
             "the count of those accounts whose owner is in Clients With Returned Mail.",
             _u("13", "E-Delivery Election", "Delivery Election ID", "Election Account", "Election Document Scope",
                "Delivery Preference", "Election Revoked Timestamp", "Linked Consent Record")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")
             + ["Clients With Returned Mail"]),
            ("Mail Holds Over 3 Months Without Re-Verification",
             "Count of accounts with Mail Hold Indicator = Y whose Mail Hold Start Date is more than 3 months before the as-of "
             "date and Mail Hold End Date is blank or later; FINRA Rule 3150 sets no maximum but expects the client's instruction "
             "to be re-verified periodically for longer holds, and 13 records no re-verification date, so every such hold is "
             "listed for re-verification, by Mail Hold Reason.",
             _u("13", "Mail Hold", "Mail Hold Indicator", "Mail Hold Reason", "Mail Hold Start Date", "Mail Hold End Date")),
            ("Deceased Parties Not Suppressed",
             "Count of parties with Date of Death populated that still have Communication Preference rows with Opt-In Status = "
             "Opted In or no Suppression Entry with Suppression Reason = Deceased in effect.",
             _u("02", "Individual", "Date of Death")
             + _u("02", "Communication Preference", "Preference Party", "Opt-In Status")
             + _u("04", "Suppression Entry", "Suppression Reason", "Suppression Effective From")),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
            ("02", "Individual", ["Date of Death"]),
            ("02", "Contact Point", ["Contact Point ID", "Contact Point Party", "Contact Channel", "Contact Point Usage",
                                     "Primary Contact Point Indicator", "Contact Point Verified Indicator",
                                     "Contact Point Effective From", "Contact Point Effective To"]),
            ("02", "Postal Address", ["Postal Code", "Country", "Mail Returned Date"]),
            ("02", "Contact Preference", ["Preference Holder", "Preferred Contact Channel", "Preferred Contact Point",
                                          "Preferred Language", "Do Not Contact Channels", "Preference Effective From",
                                          "Preference Effective To"]),
            ("02", "Communication Preference", ["Preference Party", "Preference Topic", "Preference Channel", "Opt-In Status",
                                                "Opt-Out Timestamp", "Consent Record Reference"]),
            ("02", "Consent Record", ["Consent Record ID", "Consenting Party", "Consent Purpose", "Consent Status",
                                      "Consent Captured Timestamp", "Consent Expiry Date", "Consent Withdrawn Timestamp"]),
            ("02", "Privacy Profile", ["Affiliate Marketing Opt-Out Indicator",
                                       "Affiliate Marketing Opt-Out Expiry Date", "Do Not Contact Indicator"]),
            ("13", "E-Delivery Election", ["Delivery Election ID", "Election Account", "Election Document Scope",
                                           "Delivery Preference", "Election Revoked Timestamp", "Linked Consent Record"]),
            ("13", "Mail Hold", ["Mail Hold Indicator", "Mail Hold Reason", "Mail Hold Start Date", "Mail Hold End Date"]),
            ("04", "Suppression Entry", ["Suppressed Identifier", "Suppression Reason", "Suppression Scope",
                                         "Suppression Effective From", "Revoked Consent Record"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
        ],
        upstream=["DP-240", "DP-093", "DP-382", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET daily for the prior day's changes; opt-outs and do-not-contact instructions also streamed within 1 hour of capture",
        history="SCD type 2 on each permission, kept 6 years after the relationship ends (SEC Rule 17a-4 customer records; TCPA consent evidence 5 years); daily snapshots kept 2 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["API", "Reverse ETL to CRM", "Event stream", "Warehouse table"],
        dq_rules=[
            "Every Contact Point Party, Preference Holder, Preference Party and Consenting Party resolves to a DP-240 party, every Election Account and Role Account to a DP-093 account, and every Preference Topic to an active 04 Subscription Topic.",
            "Contact Point periods of one party, channel and usage do not overlap, Contact Preference periods of one party do not overlap, and every effective-to date is on or after its effective-from date.",
            "Every party counted in Opt-Outs Not Suppressed after 10 business days is zero at the monthly control, and the count of Opted In email permissions equals the count of Granted Marketing Email consents they reference.",
            "Contact Channel, Contact Point Verified Indicator and Contact Point Effective From are populated on every Contact Point, Opt-In Status on every Communication Preference, and Consent Status and Consent Purpose on every Consent Record.",
            "Email addresses, phone numbers and street address lines are not published here (consumers take them from DP-240 by Contact Point ID); suppression identifiers are published hashed only; Date of Death is used as a filter and not published.",
            "A permission change is effective in the published view by 6am ET the next business day, and opt-outs within 1 hour; a prior day's permission snapshot is never rewritten.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: identity. Contact values are not "
               "published; consumers resolve Contact Point ID through DP-240 (DQ5). Boundaries: DP-080 is the evidence register "
               "of privacy requests and opt-out handling; this product is the operational contact rule set. DP-382 owns the "
               "documents and delivery records and the measures E-Delivery Election Coverage %, Electronic Elections Without "
               "Consent Evidence and Accounts on Mail Hold, which are not redefined here; this product reads the 13 elections "
               "and mail holds only to set the contact mode. DP-412 (marketing audiences, CLA-B) reads this product's contact and marketing permissions; it is "
               "not listed here; DP-412's measures 'Subscribers by Topic (from DP-324)' and 'Do-Not-Contact Parties in "
               "Segments (from DP-324)' should read Marketing Permission and Contactable Clients by Channel (reported to CLA-B). "
               "DP-080 reads Suppression Coverage %. 02 Postal Address Mail Returned Date is a Derived copy of 13 read here because the returned address is "
               "known only on the 02 contact point it belongs to (CONTRACT rule 2 exception). The household is not used here; "
               "permissions are per party. Tailoring lever: state privacy regimes in scope (02 SME 8). Reference default: GLBA, "
               "Regulation S-P and S-AM, CCPA/CPRA and the other state laws flagged on the Privacy Profile. Tailoring lever: "
               "suppression service standard. Reference default: 10 business days (CAN-SPAM) for email, same day for telephone "
               "(TCPA). Taxonomy gap: 04 Suppression Entry has no party key; it is matched by Revoked Consent Record or the hashed "
               "contact point. Taxonomy gap: 13 Mail Hold has no re-verification date for long holds. Taxonomy gap: 13 Mail Hold is an attribute group of the delivery election with no account key of "
               "its own. Drafting assumptions: Delivery Preference and Election Document Scope values for electronic statements; "
               "the closed Consent Status values; the 3-month re-verification review point for Rule 3150 holds; 90-day S-AM window; 10 business days. Decisions: "
               "CW-021, CW-027, CW-213. WP1 new (CW-205): first specification; written early because DP-404 and DP-412 read it."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-334": dict(
        definition=("The Reg BI file: for every recommendation, the evidence chain that Reg BI's care obligation (Exchange Act "
                    "Rule 15l-1), the Advisers Act fiduciary duty and SEC Rule 17a-3(a)(35) require, assembled from 45 as "
                    "mastered: the investor profile version and plan version relied on, the rationale, the alternatives and "
                    "their costs, each best-interest component with its attestation, the disclosures delivered before the "
                    "recommendation, and the 08 supervisory review outcome as recorded. It defines the Evidence Gap Flag that "
                    "answers acceptance question 3 (first half) and scores the plan inputs a recommendation rests on; it never "
                    "re-scores best interest (CW-215). It owns no certified metric family."),
        business_questions=[
            "Which recommendations lack best-interest evidence (acceptance question 3), by recommendation type, capacity, advisor and the element missing?",
            "Which recommendations rested on an investor profile that was stale or superseded, or on a plan version that was superseded or incomplete?",
            "Which recommendations were made before Form CRS or the Reg BI disclosure was delivered, or considered alternatives without costing them?",
            "Which recommendations have not been supervised, and which evidence gaps did supervision approve without an exception?",
            "Which alternative investment subscriptions relied on a missing or expired investor qualification?",
        ],
        grain=("Recommendation (45, RECOM-) x presented timestamp, one row per recommendation with its evidence flags, with "
               "companion rows at recommendation x best interest component and at client financial plan version (plan input "
               "completeness); recommendation rows are locked once Client Decision is not Pending, flags re-evaluated daily "
               "until the 08 review closes"),
        dimensions=["Recommendation type, capacity, source and channel (DP-303)", "Recommending advisor (DP-009)",
                    "Client and Client Household (DP-240)", "Client account (DP-093)", "Recommended service offering and share class (DP-004)",
                    "Best interest component", "Evidence gap element", "Supervisory review outcome (DP-398)", "Presented date (DP-013)"],
        measures=[
            ("Recommendations in File",
             "Count of Recommendation ID with Recommendation Presented Timestamp in the period and Recommendation Status not Draft, "
             "by Recommendation Type, Recommendation Capacity, Recommendation Source, Recommendation Channel and Recommending "
             "Advisor.",
             _u("45", "Recommendation", "Recommendation ID", "Recommendation Type", "Recommendation Capacity",
                "Recommendation Source", "Recommending Advisor", "Recommendation Channel", "Recommendation Presented Timestamp",
                "Recommendation Status")),
            ("Missing Rationale Flag",
             "Y for a recommendation whose Recommendation Rationale has Rationale Basis blank, Profile Factors Considered blank, "
             "Costs Considered Indicator not Y or Alternatives Considered Indicator not Y; and, for Recommendation Type = Security "
             "or Investment Strategy recommended as part of a series, Series of Transactions Considered Indicator not Y.",
             _u("45", "Recommendation Rationale", "Rationale Basis", "Profile Factors Considered", "Costs Considered Indicator",
                "Alternatives Considered Indicator", "Series of Transactions Considered Indicator")
             + _u("45", "Recommendation", "Recommendation Type")),
            ("Required Component Missing Flag",
             "Y when a component the capacity requires has no Best Interest Evidence row (Evidence Recommendation = Recommendation "
             "ID): Recommendation Capacity = Broker-Dealer Reg BI requires Reg BI Disclosure Obligation, Reg BI Care Obligation, "
             "Reg BI Conflict of Interest Obligation and Reg BI Compliance Obligation; Investment Adviser Fiduciary requires "
             "Adviser Duty of Care and Adviser Duty of Loyalty; Recommendation Type = Rollover adds PTE 2020-02 Impartial Conduct "
             "Standards.",
             _u("45", "Best Interest Evidence", "Evidence Recommendation", "Best Interest Component")
             + _u("45", "Recommendation", "Recommendation Capacity", "Recommendation Type")),
            ("Unsatisfied or Unattested Component Flag",
             "Y when any Best Interest Evidence row of the recommendation has Component Satisfied Indicator not Y, Evidence "
             "Attester blank, or Evidence Attested Date blank or more than 5 business days after the Recommendation Presented "
             "Timestamp.",
             _u("45", "Best Interest Evidence", "Component Satisfied Indicator", "Evidence Attester", "Evidence Attested Date")
             + _u("45", "Recommendation", "Recommendation Presented Timestamp")),
            ("Stale Profile Flag",
             "Y when Recommendation Profile Version is blank, or resolves to a 02 Investor Profile (Investor Profile ID) whose "
             "Attested Date is blank or after the Recommendation Presented Timestamp, that was superseded by then (another "
             "version of the same Profile Client with a higher Profile Version Number and Attested Date on or before the "
             "timestamp), whose Next Review Date was before the timestamp, or whose Investment Objective, Risk Tolerance or Time "
             "Horizon is blank; the test uses version number and attestation date because 02 holds no profile effective dates.",
             _u("45", "Recommendation", "Recommendation Profile Version", "Recommendation Presented Timestamp")
             + _u("02", "Investor Profile", "Investor Profile ID", "Profile Client", "Profile Version Number", "Attested Date",
                  "Next Review Date", "Investment Objective", "Risk Tolerance", "Time Horizon")),
            ("Evidence Gap Flag",
             "Acceptance question 3, defined here only: Y for a recommendation in file when Missing Rationale Flag, Required "
             "Component Missing Flag, Unsatisfied or Unattested Component Flag or Stale Profile Flag is Y; the first flag met is "
             "published as the gap element.",
             ["Missing Rationale Flag", "Required Component Missing Flag", "Unsatisfied or Unattested Component Flag",
              "Stale Profile Flag"]),
            ("Recommendations Without Best-Interest Evidence",
             "Acceptance question 3 (first half): count of Recommendations in File with Evidence Gap Flag = Y, with the 08 "
             "Supervisory Review Outcome recorded for each (Reviewed Recommendation; read as DP-398 publishes it), by gap element, "
             "Recommendation Type, Recommendation Capacity and Recommending Advisor.",
             _u("08", "Supervisory Review", "Reviewed Recommendation", "Review Outcome")
             + ["Recommendations in File", "Evidence Gap Flag"]),
            ("Evidence Gap Rate %",
             "Recommendations Without Best-Interest Evidence / Recommendations in File, by advisor and month.",
             ["Recommendations Without Best-Interest Evidence", "Recommendations in File"]),
            ("Disclosure Not Delivered Before Recommendation",
             "Recommendations in File with Recommendation Capacity = Broker-Dealer Reg BI and no 15 Account Disclosure Delivery of "
             "Disclosure Type in (Form CRS, Regulation Best Interest Disclosure) on a Recommendation Accounts account with "
             "Disclosure Delivered Date on or before the presented date, and no Best Interest Evidence Client-Level Form CRS "
             "Delivered Date on or before it (Reg BI disclosure obligation and Form CRS delivery timing).",
             _u("15", "Account Disclosure Delivery", "Disclosure Account", "Disclosure Type", "Disclosure Version",
                "Disclosure Delivered Date")
             + _u("45", "Best Interest Evidence", "Client-Level Form CRS Delivered Date", "Evidence Disclosure Delivery")
             + _u("45", "Recommendation", "Recommendation Accounts", "Recommendation Capacity")
             + ["Recommendations in File"]),
            ("Alternatives Without Cost",
             "Recommendations in File with Alternatives Considered Indicator = Y and no Recommendation Alternative row "
             "(Alternative Recommendation = Recommendation ID) with Alternative Estimated Annual Cost populated, or alternatives "
             "with Reason Not Selected blank.",
             _u("45", "Recommendation Alternative", "Alternative Recommendation", "Alternative Number",
                "Alternative Estimated Annual Cost", "Reason Not Selected")
             + _u("45", "Recommendation Rationale", "Alternatives Considered Indicator")
             + ["Recommendations in File"]),
            ("Unreviewed Recommendations",
             "Recommendations in File presented more than 30 days before the as-of date with no 08 Supervisory Review (Reviewed "
             "Recommendation = Recommendation ID) of a recommendation Supervisory Review Type with Review Completed Date "
             "populated.",
             _u("08", "Supervisory Review", "Supervisory Review ID", "Supervisory Review Type", "Reviewed Recommendation",
                "Review Completed Date")
             + ["Recommendations in File"]),
            ("Evidence Gaps Approved in Review",
             "Recommendations with Evidence Gap Flag = Y whose completed 08 Supervisory Review has Review Outcome = No Exception, "
             "or whose Best Interest Review Detail shows Alternatives Evidence Present Indicator = Y or Cost Evidence Present "
             "Indicator = Y while Alternatives Without Cost applies, or Profile Current Indicator = Y while Stale Profile Flag = Y; "
             "the 08 outcome is carried as recorded and not re-scored (CW-215).",
             _u("08", "Supervisory Review", "Review Outcome")
             + _u("08", "Best Interest Review Detail", "Investor Profile Version Checked", "Profile Current Indicator",
                  "Alternatives Evidence Present Indicator", "Cost Evidence Present Indicator", "Evidence Exceptions")
             + ["Evidence Gap Flag", "Alternatives Without Cost", "Stale Profile Flag"]),
            ("Plan Input Completeness Score",
             "Per Client Financial Plan Version presented or accepted: 20 points each for (1) Plan Profile Version Relied On "
             "resolving to an attested Investor Profile version (Attested Date on or before Plan Data As-Of Date), (2) at least one Planning Cash Flow Input of an income Cash Flow Item Type "
             "with Cash Flow Amount populated, (3) at least one Planning Balance Sheet Item with Balance Sheet Item Value and Item "
             "Value As-Of Date populated, (4) Planning Federal Marginal Tax Rate populated, and (5) Plan Data As-Of Date within 12 "
             "months of Plan Presented Date (0 to 100). Healthcare Expense cash-flow rows are excluded.",
             _u("45", "Client Financial Plan Version", "Client Financial Plan Version ID", "Versioned Plan",
                "Client Financial Plan Version Status", "Plan Data As-Of Date", "Plan Profile Version Relied On", "Plan Presented Date")
             + _u("45", "Planning Cash Flow Input", "Cash Flow Plan Version", "Cash Flow Item Number", "Cash Flow Item Type",
                  "Cash Flow Amount")
             + _u("45", "Planning Balance Sheet Item", "Balance Sheet Plan Version", "Balance Sheet Item Number",
                  "Balance Sheet Item Value", "Item Value As-Of Date")
             + _u("45", "Client Planning Assumptions", "Planning Federal Marginal Tax Rate")
             + _u("02", "Investor Profile", "Investor Profile ID", "Attested Date")),
            ("Recommendations on Weak Plan",
             "Recommendations in File whose Supporting Plan Version has Plan Input Completeness Score below 80, or Client Financial "
             "Plan Version Status = Superseded at the Recommendation Presented Timestamp, by Client Financial Plan Type.",
             _u("45", "Recommendation", "Supporting Plan Version")
             + _u("45", "Client Financial Plan Version", "Client Financial Plan Version Status")
             + _u("45", "Client Financial Plan", "Client Financial Plan ID", "Client Financial Plan Type")
             + ["Plan Input Completeness Score", "Recommendations in File"]),
            ("Unqualified Alternative Investment Subscriptions",
             "Count of 15 Alternative Investment Subscription rows with Subscription Status not in (Draft, Rejected, Withdrawn) whose Investor "
             "Qualification Relied On is blank, or resolves to a 02 Investor Qualification of the subscribing owner with "
             "Qualification Standard = None Evidenced, Determination Date blank, or Qualification Expiry Date before Subscription "
             "Accepted Date, by Feeder Product.",
             _u("15", "Alternative Investment Subscription", "Subscription ID", "Subscribing Account", "Feeder Product",
                "Investor Qualification Relied On", "Subscription Status", "Subscription Accepted Date")
             + _u("02", "Investor Qualification", "Qualified Party", "Qualification Standard", "Qualification Basis",
                  "Determination Date", "Qualification Expiry Date")),
        ],
        inputs=[
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommendation Capacity", "Recommendation Source",
                                      "Recommending Advisor", "Recommended Client", "Recommendation Accounts",
                                      "Recommendation Profile Version", "Supporting Plan Version", "Recommended Service Offering",
                                      "Recommended Share Class", "Recommendation Channel", "Recommendation Presented Timestamp",
                                      "Client Decision", "Recommendation Status"]),
            ("45", "Recommendation Rationale", ["Rationale Basis", "Profile Factors Considered", "Costs Considered Indicator",
                                                "Alternatives Considered Indicator", "Series of Transactions Considered Indicator"]),
            ("45", "Recommendation Alternative", ["Alternative Recommendation", "Alternative Number",
                                                  "Alternative Estimated Annual Cost", "Reason Not Selected"]),
            ("45", "Best Interest Evidence", ["Evidence Recommendation", "Best Interest Component", "Evidence Type",
                                              "Evidence Disclosure Delivery", "Client-Level Form CRS Delivered Date",
                                              "Component Satisfied Indicator", "Evidence Attester", "Evidence Attested Date"]),
            ("45", "Client Financial Plan", ["Client Financial Plan ID", "Plan Subject", "Client Financial Plan Type",
                                             "Client Financial Plan Status"]),
            ("45", "Client Financial Plan Version", ["Client Financial Plan Version ID", "Versioned Plan",
                                                     "Client Financial Plan Version Status", "Plan Data As-Of Date",
                                                     "Plan Profile Version Relied On", "Plan Presented Date", "Plan Accepted Date"]),
            ("45", "Client Planning Assumptions", ["Planning Federal Marginal Tax Rate"]),
            ("45", "Planning Cash Flow Input", ["Cash Flow Plan Version", "Cash Flow Item Number", "Cash Flow Item Type",
                                                "Cash Flow Amount"]),
            ("45", "Planning Balance Sheet Item", ["Balance Sheet Plan Version", "Balance Sheet Item Number",
                                                   "Balance Sheet Item Value", "Item Value As-Of Date"]),
            ("02", "Investor Profile", ["Investor Profile ID", "Profile Client", "Profile Version Number", "Investment Objective",
                                        "Risk Tolerance", "Time Horizon", "Attested Date", "Next Review Date", "Profile Status"]),
            ("02", "Investor Qualification", ["Qualified Party", "Qualification Standard", "Qualification Basis",
                                              "Determination Date", "Qualification Expiry Date"]),
            ("15", "Account Disclosure Delivery", ["Disclosure Account", "Disclosure Type", "Disclosure Version",
                                                   "Disclosure Delivered Date"]),
            ("15", "Alternative Investment Subscription", ["Subscription ID", "Subscribing Account", "Feeder Product",
                                                           "Investor Qualification Relied On", "Subscription Status",
                                                           "Subscription Accepted Date"]),
            ("08", "Supervisory Review", ["Supervisory Review ID", "Supervisory Review Type", "Reviewed Recommendation",
                                          "Review Completed Date", "Review Outcome"]),
            ("08", "Best Interest Review Detail", ["Investor Profile Version Checked", "Profile Current Indicator",
                                                   "Alternatives Evidence Present Indicator", "Cost Evidence Present Indicator",
                                                   "Evidence Exceptions"]),
        ],
        upstream=["DP-303", "DP-398", "DP-240", "DP-093", "DP-004", "DP-009", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for recommendations presented and evidence attested through the prior day",
        history="Recommendation rows locked at client decision and kept 6 years (SEC Rule 17a-4(e)(5) and Rule 17a-3(a)(35) records; Advisers Act Rule 204-2), flag history SCD type 2 until the 08 review closes",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Recommendation ID resolves to a DP-303 recommendation, every Recommended Client to a DP-240 party, every Recommending Advisor to a DP-009 advisor, every Recommendation Accounts value to a DP-093 account and every Recommended Service Offering and Recommended Share Class to DP-004.",
            "Each Recommendation Profile Version and Plan Profile Version Relied On resolves to one 02 Investor Profile version of the same client, Profile Version Number is unique per Profile Client, and Attested Date does not decrease as Profile Version Number increases.",
            "Recommendations in File equals DP-303 Recommendations Presented for the same period and filters, and each recommendation's Best Interest Evidence rows equal those DP-303 publishes (count by component); a difference stops publication of the file.",
            "Recommendation Type, Recommendation Capacity, Recommendation Profile Version and Recommendation Presented Timestamp are populated on every recommendation in file, and Best Interest Component and Component Satisfied Indicator on every evidence row.",
            "Rows are published at recommendation grain only in the Confidential - Personal Data view to advice supervision and compliance; the semantic model carries counts by advisor, type and gap element; 45 Client Planning Assumptions life expectancy and healthcare bases and Healthcare Expense cash-flow rows are never read (CD-344).",
            "A recommendation's flags are recomputed daily until its 08 Supervisory Review is completed, then frozen; the file as of each month-end is kept as a locked snapshot.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: financial. Recommendation rows only in the "
               "Confidential - Personal Data view; special-category planning bases are not read (DQ5). Boundaries: 45 masters "
               "the recommendation, rationale and evidence and DP-303 publishes them; DP-303 publishes component-level counts "
               "(Unattested Evidence Components, Recommendation Acceptance Rate) and no gap flag, and this product defines the "
               "Evidence Gap Flag and the missing-rationale test (WP1F ruling). 08 supervises; the review outcome is carried as "
               "recorded from CLA-B DP-398 Principal Review Queue, which lists this product nowhere (DP-398 publishes Recommendation Review Coverage % and Reviews Recording Evidence Exceptions, not redefined here), and the 08 brief's products own surveillance scores and alerts (CW-215). Rollover evidence and the "
               "PTE 2020-02 documentation flag are DP-335's. Backlog DP-323 Investor Profile Currency & Suitability Inputs folds "
               "in here: the Stale Profile Flag and the 02 Investor Qualification read (moved read). Objects of DP-323 not read "
               "here: 02 Investment Experience and 15 Options Approval Detail (read by DP-240 and DP-093 for options approval), 02 "
               "Regulatory Classification (read by DP-077 for the Reg BI retail customer test), 15 Account Investment Profile "
               "(DP-093), 15 Account Feature (DP-093) and 45 Advice Review (DP-303, DP-332). 45 Client Planning Assumptions "
               "Planning Federal Marginal Tax Rate is a Derived copy of 02 read as the value the plan used, never as the client's "
               "current rate. DP-404 (Retail Conduct Risk Indicators) reads this product and is not listed here. "
               "Acceptance question 3 (plan section 8.5): answered by Evidence Gap Flag, Recommendations Without "
               "Best-Interest Evidence (with the 08 review outcome), Unreviewed Recommendations and Evidence Gaps Approved in "
               "Review; mastering domains 45, 08 (with the profile from 02). 08 Supervisory Review and Best Interest Review "
               "Detail are read directly, matching DP-398's published outcome; WP2 foundation candidate. Tailoring lever: brokerage security "
               "recommendations recorded (45 SME 2). Reference default: every recommendation the firm defines under Reg BI, "
               "including Security type. Tailoring lever: investor profile per client or with household scope (02 SME 1). "
               "Reference default: per client with household scope. Tailoring lever: FINRA Rule 2111 suitability component for "
               "brokerage recommendations to non-retail customers. Reference default: not required (Reg BI capacity components "
               "only); a firm that records it adds FINRA Rule 2111 Suitability to the required set. Tailoring lever: evidence attestation window. Reference "
               "default: 5 business days. Taxonomy gap: 45 has no record of which Best Interest Component values a Recommendation "
               "Capacity requires; the rule is held in Required Component Missing Flag. Taxonomy gap: 15 Alternative Investment "
               "Subscription names no subscribing party, so the qualification is matched through the account's owner role. "
               "Taxonomy gap: 02 Investor Profile has no effective-from or effective-to dates, so the profile in force at a "
               "recommendation is inferred from Profile Version Number and Attested Date. "
               + GAP6 +
               "Drafting assumptions: the component sets per capacity; 30-day supervisory review window; 80-point completeness "
               "threshold and the five plan inputs; income Cash Flow Item Types (Employment, Self-Employment, Pension, Social "
               "Security, Rental, Other Income); Recommendation Status Draft excluded; Subscription Status Draft, Rejected and Withdrawn excluded. "
               "Decisions: CW-008, CW-015, CW-044, CW-213, CW-215, CD-344. WP1 new (CW-215): first specification; takes the "
               "Q3 gap flag DP-303 left to it."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-335": dict(
        definition=("Every rollover recommendation with its analysis, the options compared and their costs, the fiduciary status "
                    "basis and the DOL PTE 2020-02 documentation (fiduciary acknowledgment, services and conflicts disclosure, "
                    "rollover reasons, impartial conduct attestation), joined to the plan distribution (16) that implemented it "
                    "and the receiving firm account (15). It defines the PTE Documentation Gap Flag that answers acceptance "
                    "question 3 (second half), finds rollovers into firm accounts with no recommendation record, and feeds the "
                    "08 annual retrospective review; it assembles the 45 evidence and never re-scores it (CW-215). It owns no "
                    "certified metric family."),
        business_questions=[
            "Which rollover recommendations lack PTE 2020-02 documentation (acceptance question 3), by advisor and missing element?",
            "Were the rollover options compared with their costs, and where the firm's option costs more than staying in the plan, is the reason documented?",
            "How often does the analysis rely on benchmark fee data instead of the plan's own fees, and how many rollovers were treated as non-fiduciary?",
            "Which rollovers from firm-recordkept plans into firm IRAs were paid with no rollover recommendation on record?",
            "How many rollover recommendations of the year are covered by the 08 retrospective review, and which reviews found documentation missing?",
        ],
        grain=("Rollover analysis (45, ROLV-) x rollover recommendation, with option comparison rows (analysis x rollover option) "
               "and the implementing 16 distribution as companions; rows locked at the client decision, PTE documentation "
               "re-evaluated daily until complete"),
        dimensions=["Recommending advisor (DP-009)", "Client (DP-240)", "Source retirement plan and membership (DP-094)",
                    "Receiving account (DP-093)", "Rollover option", "Fiduciary status basis", "Plan fee data source",
                    "PTE documentation element", "Hand-off trigger and outcome (DP-430)", "Supervisory review outcome (DP-398)", "Presented date (DP-013)"],
        measures=[
            ("Rollover Recommendations",
             "Count of Recommendation ID with Recommendation Type = Rollover and Recommendation Presented Timestamp in the period, "
             "by Recommendation Capacity, Recommending Advisor and the Rollover Option with Recommended Option Indicator = Y.",
             _u("45", "Recommendation", "Recommendation ID", "Recommendation Type", "Recommendation Capacity",
                "Recommending Advisor", "Recommendation Presented Timestamp")
             + _u("45", "Rollover Option Comparison", "Comparison Analysis", "Rollover Option", "Recommended Option Indicator")),
            ("PTE Documentation Gap Flag",
             "Acceptance question 3, defined here only: Y for a Rollover Recommendation with no Rollover Analysis (Rollover "
             "Recommendation = Recommendation ID), or whose analysis has Fiduciary Status Basis = Acknowledged Fiduciary - PTE "
             "2020-02 and any of: Fiduciary Acknowledgment Delivered Date, Services and Conflicts Disclosure Delivered Date or "
             "Rollover Reasons Delivered Date blank or after Client Decision Date; Impartial Conduct Standards Attestation not Y; "
             "Best Interest Reasons blank; or no Best Interest Evidence row of Best Interest Component = PTE 2020-02 Impartial "
             "Conduct Standards with Component Satisfied Indicator = Y.",
             _u("45", "Rollover Analysis", "Rollover Analysis ID", "Rollover Recommendation", "Fiduciary Status Basis",
                "Best Interest Reasons")
             + _u("45", "PTE 2020-02 Documentation", "Fiduciary Acknowledgment Delivered Date",
                  "Services and Conflicts Disclosure Delivered Date", "Rollover Reasons Delivered Date",
                  "Impartial Conduct Standards Attestation")
             + _u("45", "Recommendation", "Client Decision Date")
             + _u("45", "Best Interest Evidence", "Evidence Recommendation", "Best Interest Component", "Component Satisfied Indicator")
             + ["Rollover Recommendations"]),
            ("Rollovers Without PTE 2020-02 Documentation",
             "Acceptance question 3 (second half): count of Rollover Recommendations with PTE Documentation Gap Flag = Y, by "
             "missing element and Recommending Advisor, with the sum of their Rollover Amount (USD as recorded) and the 08 "
             "Supervisory Review Outcome recorded for each (Reviewed Recommendation; read as DP-398 publishes it).",
             _u("45", "Rollover Analysis", "Rollover Amount")
             + _u("08", "Supervisory Review", "Reviewed Recommendation", "Review Outcome")
             + ["Rollover Recommendations", "PTE Documentation Gap Flag"]),
            ("PTE Documentation Gap Rate %",
             "Rollovers Without PTE 2020-02 Documentation / Rollover Recommendations, by month and advisor.",
             ["Rollovers Without PTE 2020-02 Documentation", "Rollover Recommendations"]),
            ("Documentation Delivered After Decision",
             "Rollover analyses with any of the three PTE delivery dates after the recommendation's Client Decision Date, or "
             "Documentation Delivery Record blank while the dates are populated.",
             _u("45", "PTE 2020-02 Documentation", "Fiduciary Acknowledgment Delivered Date",
                "Services and Conflicts Disclosure Delivered Date", "Rollover Reasons Delivered Date", "Documentation Delivery Record")
             + _u("45", "Recommendation", "Client Decision Date")),
            ("Incomplete Option Comparisons",
             "Rollover analyses with Rollover Analysis Status in (Completed, Presented) that lack a Rollover Option Comparison row "
             "with Estimated Annual Total Cost populated for each of Leave in Current Plan, Roll Over to IRA and Take a "
             "Distribution.",
             _u("45", "Rollover Analysis", "Rollover Analysis Status")
             + _u("45", "Rollover Option Comparison", "Comparison Analysis", "Rollover Option", "Estimated Annual Total Cost")),
            ("Recommended Option Cost Premium",
             "Per analysis: Estimated Annual Total Cost of the option with Recommended Option Indicator = Y minus that of Leave in "
             "Current Plan (USD a year); with the count of analyses where the premium is positive and Best Interest Reasons is "
             "blank.",
             _u("45", "Rollover Option Comparison", "Rollover Option", "Estimated Annual Total Cost", "Recommended Option Indicator",
                "Option Fee Schedule")
             + _u("45", "Rollover Analysis", "Best Interest Reasons")),
            ("Benchmark Fee Data Share %",
             "Rollover analyses completed in the period with Plan Fee Data Source = Industry Benchmark / all completed, and the "
             "count with Collected Fee Disclosure Date blank where Source Retirement Plan is not a firm-recordkept plan.",
             _u("45", "Rollover Analysis", "Plan Fee Data Source", "Collected Fee Disclosure Date", "Source Retirement Plan",
                "Analysis Completed Date")),
            ("Non-Fiduciary Rollover Determinations",
             "Count of rollover analyses with Fiduciary Status Basis = Non-Fiduciary - Five-Part Test Not Met, by advisor; expected "
             "zero under the reference default.",
             _u("45", "Rollover Analysis", "Fiduciary Status Basis", "Analysis Completed Date")),
            ("Unrecorded Rollovers Into Firm Accounts",
             "Count and Gross Distribution Amount of 16 Distribution Request rows with Rollover Direction = Direct Rollover Out, "
             "Distribution Status = Paid and Receiving Account resolving to a firm 15 Account of an IRA Account Registration "
             "Type (Traditional IRA, Rollover IRA, Roth IRA) in the period, for which no Rollover "
             "Analysis has Source Plan Membership = Distribution Membership with Analysis Completed Date before Payment Date; "
             "split by whether a 16 Participant Retail Hand-Off of the membership (Linked Distribution Request) named a Referral "
             "Advice Engagement.",
             _u("16", "Distribution Request", "Distribution ID", "Distribution Membership", "Gross Distribution Amount",
                "Receiving Account", "Rollover Direction", "Payment Date", "Distribution Status")
             + _u("15", "Account", "Account ID", "Account Registration Type")
             + _u("16", "Participant Retail Hand-Off", "Hand-Off ID", "Hand-Off Membership", "Linked Distribution Request",
                  "Referral Advice Engagement")
             + _u("45", "Rollover Analysis", "Source Plan Membership", "Analysis Completed Date")),
            ("Rollover Implementation Rate",
             "Rollover Recommendations with Client Decision in (Accepted, Accepted with Changes) that have a Recommendation "
             "Implementation Link of Implementing Record Type = Plan Distribution whose Implementing Distribution is a 16 "
             "Distribution Request with Distribution Status = Paid / accepted Rollover Recommendations.",
             _u("45", "Recommendation", "Client Decision")
             + _u("45", "Recommendation Implementation Link", "Implemented Recommendation", "Implementing Record Type",
                  "Implementing Distribution", "Implementation Date")
             + _u("16", "Distribution Request", "Distribution ID", "Distribution Status")
             + ["Rollover Recommendations"]),
            ("Retrospective Review Coverage %",
             "Rollover Recommendations of the calendar year with an 08 Supervisory Review of Supervisory Review Type = Rollover "
             "Recommendation Review whose Best Interest Review Detail Rollover Analysis Reviewed is populated / Rollover "
             "Recommendations of the year: the population the PTE 2020-02 annual retrospective review draws on.",
             _u("08", "Supervisory Review", "Supervisory Review ID", "Supervisory Review Type", "Reviewed Recommendation",
                "Review Completed Date")
             + _u("08", "Best Interest Review Detail", "Rollover Analysis Reviewed")
             + ["Rollover Recommendations"]),
            ("Reviews Finding Documentation Missing",
             "Completed rollover reviews with PTE Documentation Present Indicator not Y or Evidence Exceptions populated, with "
             "their Review Outcome as recorded, and the count where this product's PTE Documentation Gap Flag disagrees with the "
             "reviewer's indicator.",
             _u("08", "Best Interest Review Detail", "PTE Documentation Present Indicator", "Evidence Exceptions")
             + _u("08", "Supervisory Review", "Review Outcome")
             + ["PTE Documentation Gap Flag"]),
        ],
        inputs=[
            ("45", "Rollover Analysis", ["Rollover Analysis ID", "Rollover Recommendation", "Source Retirement Plan",
                                         "Source Plan Membership", "Rollover Amount", "Plan Fee Data Source",
                                         "Collected Fee Disclosure Date", "Fiduciary Status Basis", "Best Interest Reasons",
                                         "Rollover Analysis Status", "Analysis Completed Date"]),
            ("45", "PTE 2020-02 Documentation", ["Fiduciary Acknowledgment Delivered Date",
                                                 "Services and Conflicts Disclosure Delivered Date",
                                                 "Rollover Reasons Delivered Date", "Impartial Conduct Standards Attestation",
                                                 "Attesting Employee", "Documentation Delivery Record"]),
            ("45", "Rollover Option Comparison", ["Comparison Analysis", "Rollover Option", "Estimated Annual Total Cost",
                                                  "Option Fee Schedule", "Recommended Option Indicator"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommendation Capacity",
                                      "Recommending Advisor", "Recommended Client", "Recommendation Accounts",
                                      "Recommendation Presented Timestamp", "Client Decision", "Client Decision Date"]),
            ("45", "Best Interest Evidence", ["Evidence Recommendation", "Best Interest Component",
                                              "Component Satisfied Indicator", "Evidence Attester", "Evidence Attested Date"]),
            ("45", "Recommendation Implementation Link", ["Implemented Recommendation", "Implementing Record Type",
                                                          "Implementing Distribution", "Implementation Date"]),
            ("16", "Distribution Request", ["Distribution ID", "Distribution Membership",
                                            "Gross Distribution Amount", "Receiving Account", "Rollover Direction",
                                            "Payment Date", "Distribution Status"]),
            ("16", "Participant Retail Hand-Off", ["Hand-Off ID", "Hand-Off Membership", "Hand-Off Trigger", "Trigger Date",
                                                   "Referral Advice Engagement", "Referred Advisor", "Hand-Off Outcome",
                                                   "Linked Distribution Request"]),
            ("15", "Account", ["Account ID", "Account Registration Type"]),
            ("08", "Supervisory Review", ["Supervisory Review ID", "Supervisory Review Type", "Reviewed Recommendation",
                                          "Review Completed Date", "Review Outcome"]),
            ("08", "Best Interest Review Detail", ["Rollover Analysis Reviewed", "PTE Documentation Present Indicator",
                                                   "Evidence Exceptions"]),
        ],
        upstream=["DP-303", "DP-398", "DP-430", "DP-094", "DP-093", "DP-240", "DP-009", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; the year's file for the retrospective review frozen on business day 10 of January",
        history="Analysis and documentation rows locked at the client decision and kept 6 years (PTE 2020-02 Section IV recordkeeping, confirm against the amended text; SEC Rule 17a-4), daily flag history SCD type 2",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Rollover Recommendation resolves to a DP-303 recommendation of Recommendation Type = Rollover, every Source Retirement Plan and Source Plan Membership to DP-094, every Receiving Account to a DP-093 account, and every Recommending Advisor to a DP-009 advisor.",
            "A recommendation has at most one Rollover Analysis with Rollover Analysis Status other than Superseded, and Analysis Completed Date is on or before the Client Decision Date of the recommendation.",
            "Rollover Recommendations equals the count of DP-303 Recommendations Presented with Recommendation Type = Rollover for the period, and the Rollover Recommendations with no Rollover Analysis equal DP-303's Rollover Recommendations Without Analysis for the same period.",
            "Fiduciary Status Basis, Best Interest Reasons and Analysis Completed Date are populated on every analysis with Rollover Analysis Status in (Completed, Presented), and Distribution Status, Rollover Direction and Payment Date on every paid 16 distribution read.",
            "Rows are published at recommendation grain only in the Confidential - Personal Data view; 16 Distribution Request Hardship Reason and Distribution Type are never read and only rows with Rollover Direction = Direct Rollover Out are extracted, so hardship rows never enter (CD-344); the semantic model carries counts and amounts by advisor, plan and element only.",
            "A recommendation's PTE flag is frozen at the completion of its 08 review, and the calendar-year file is locked on business day 10 of January for the retrospective review.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: financial. Hardship reasons (special "
               "category) are not read (DQ5). Boundaries: DP-303 publishes Rollover Analysis, PTE 2020-02 Documentation and the "
               "counts Rollover Recommendations Without Analysis and Rollover Amount Analyzed, which are not redefined; this "
               "product defines the PTE Documentation Gap Flag (CW-215). The rollover capture rate (acceptance question 10) is "
               "DP-467's (BWO); DP-430 publishes the hand-offs and Hand-Off Rollover Amount; DP-008 Net Inter-Channel Transfers "
               "carries the certified money. 08 supervises and runs the PTE 2020-02 retrospective review; this product supplies "
               "its population and carries the review outcome as recorded from CLA-B DP-398 Principal Review Queue (which does not list this product; its Rollover Reviews Recording Missing PTE Documentation is not redefined). Objects of the candidate not read: 16 Rollover "
               "Contribution Detail (incoming rollovers into a recordkept plan; no recommendation evidence depends on it; read "
               "by the BWO participant products through DP-430). Acceptance question 3 (plan section 8.5): answered by PTE "
               "Documentation Gap Flag, Rollovers Without PTE 2020-02 Documentation (with the 08 review outcome), Retrospective "
               "Review Coverage % and Reviews Finding Documentation Missing; mastering domains 45, 08. 08 Supervisory Review and "
               "Best Interest Review Detail are read directly, matching DP-398's published outcome; WP2 foundation candidate. "
               "Acceptance question 10: feeds DP-467 with Rollover Recommendations and PTE Documentation Gap Flag. Tailoring lever: every rollover recommendation treated as fiduciary advice (45 SME 9). "
               "Reference default: yes, Acknowledged Fiduciary - PTE 2020-02. Tailoring lever: DOL fiduciary rule status "
               "(confirm). Reference default: PTE 2020-02 as amended, applied to every rollover recommendation. Taxonomy gap: 45 "
               "Rollover Analysis has no receiving firm account; the receiving account is taken from the implementing 16 "
               "Distribution Request. " + GAP6 +
               "Drafting assumptions: the three options required in a comparison; Rollover Analysis Status values Completed and "
               "Presented; Distribution Status Paid; the January freeze date. Decisions: CW-008, CW-015, CW-215, CW-232, CD-344. "
               "WP1 new (CW-215): first specification."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-350": dict(
        definition=("Invoiced client fees: institutional mandate billing arrangements (IA and OCIO) with their schedules, "
                    "most-favored-nation terms and qualified-client determinations, performance fee calculations re-performed "
                    "against their terms, invoices for mandates and for planning-only advice engagements, and their collection "
                    "from the 19 receivables ledger, with disputes and true-ups. Billing operations and institutional service "
                    "track what was invoiced, collected and disputed, and this product owns the invoice-to-receivable tie. The billing facts are "
                    "DP-305's and are read, never redefined; billed amounts are operational and client fee revenue is DP-012's "
                    "(CW-214). It owns no certified metric family."),
        business_questions=[
            "What did we invoice this period in management and performance fees, by mandate, client type and fee schedule, and how much is still uncollected?",
            "Which performance fees cannot be re-performed from their terms, hurdle and high-water mark, or were invoiced without an approved calculation?",
            "Which performance-fee arrangements lack a current qualified-client determination under Advisers Act Rule 205-3?",
            "Which invoices bill assets that differ from the mandate's portfolio value, or do not reconcile to a receivable?",
            "What did most-favored-nation true-ups and invoice disputes cost, and which invoices are past their payment terms?",
        ],
        grain=("Fee invoice (47, BIL-) x billing period, for billing arrangements (mandate x bill-to party x effective period) and "
               "planning-engagement fee schedule assignments, with performance fee calculations (arrangement x calculation "
               "period end) and the 19 receivable as companions; monthly, closed periods final"),
        dimensions=["Billing arrangement and fee schedule (DP-305)", "Investment mandate (DP-004)", "Institutional client (DP-003)",
                    "Bill-to party (DP-240)", "Portfolio (DP-140)", "Advice engagement (DP-303)", "Fee schedule type",
                    "Performance fee eligibility basis", "Payment status band", "Billing period (DP-013)"],
        measures=[
            ("Active Billing Arrangements",
             "Count of Billing Arrangement ID with Billing Effective From <= as-of < Billing Effective To (or open), by Fee "
             "Schedule Type of the Applied Fee Schedule, Billing Frequency, Fee Collection Method and the Institutional Client "
             "Type of the Bill-To Party.",
             _u("47", "Billing Arrangement", "Billing Arrangement ID", "Bill-To Party", "Applied Fee Schedule", "Billing Frequency",
                "Fee Collection Method", "Billing Effective From", "Billing Effective To")
             + _u("47", "Fee Schedule", "Fee Schedule ID", "Fee Schedule Type")
             + _u("12", "Institutional Client", "Institutional Client Party", "Institutional Client Type")),
            ("Invoiced Management Fees",
             "Sum of Management Fee Amount of Fee Invoice rows with Billing Period End in the period, by Invoice Billing "
             "Arrangement's Billed Mandate and Mandate Type (Billing Currency; no FX conversion).",
             _u("47", "Fee Invoice", "Invoice ID", "Invoice Billing Arrangement", "Billing Period End", "Management Fee Amount")
             + _u("47", "Billing Arrangement", "Billed Mandate", "Billing Currency")
             + _u("01", "Investment Mandate", "Mandate ID", "Mandate Type")),
            ("Performance Fees Crystallized",
             "Sum of Calculated Performance Fee of Performance Fee Calculation rows with Crystallized Indicator = Y and Calculation "
             "Period End in the period, by Hurdle Type and High-Water Mark Indicator of the arrangement's Performance Fee Terms.",
             _u("47", "Performance Fee Calculation", "Performance Fee Billing Arrangement", "Calculation Period End",
                "Calculated Performance Fee", "Crystallized Indicator")
             + _u("47", "Performance Fee Terms", "Hurdle Type", "High-Water Mark Indicator")),
            ("Performance Fee Re-Performance Variance",
             "Per crystallized calculation: Calculated Performance Fee minus Performance Fee Rate x max(0, ending value above "
             "the greater of High-Water Mark Value and the hurdle) where the hurdle is Hurdle Rate (Hurdle Type fixed) or the "
             "Benchmark Return Value of the Hurdle Benchmark (from DP-145) over the Performance Period, the portfolio return is "
             "the gross-of-fee Return Value of the mandate's primary implementing portfolio (from DP-145) and the base is its "
             "Total IBOR Market Value at period start (from DP-142); the count with variance above 1% of the fee.",
             _u("47", "Performance Fee Calculation", "Calculated Performance Fee", "High-Water Mark Value", "Hurdle Benchmark")
             + _u("47", "Performance Fee Terms", "Performance Fee Rate", "Hurdle Type", "Hurdle Rate", "Performance Period",
                  "Performance Fee Basis")
             + _u("32", "Performance Return", "Return Portfolio", "Return Period Start Date", "Return Period End Date",
                  "Return Fee Basis", "Return Value", "Return Status")
             + _u("32", "Benchmark Return", "Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                  "Benchmark Return Value", "Benchmark Return Status")
             + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value")
             + ["Performance Fees Crystallized"]),
            ("Unapproved Performance Fee Calculations",
             "Performance Fee Calculation rows with Calculated Performance Fee above zero and Calculation Approved By blank whose "
             "arrangement has a Fee Invoice with Performance Fee Amount above zero for the period.",
             _u("47", "Performance Fee Calculation", "Calculated Performance Fee", "Calculation Approved By")
             + _u("47", "Fee Invoice", "Performance Fee Amount")),
            ("Arrangements Without Qualified-Client Determination",
             "Active Billing Arrangements whose Applied Fee Schedule has Performance Fee Terms with Performance Fee Rate above zero "
             "and whose Performance Fee Eligibility Basis is blank or Not Applicable, Qualified Client Determination is blank, or "
             "Qualified Client Determination Date is after Billing Effective From (Advisers Act Rule 205-3, determined at contract "
             "entry).",
             _u("47", "Billing Arrangement", "Performance Fee Eligibility Basis", "Qualified Client Determination",
                "Qualified Client Determination Date", "Qualified Client Thresholds Applied", "Billing Effective From")
             + _u("47", "Performance Fee Terms", "Performance Fee Rate")
             + ["Active Billing Arrangements"]),
            ("Invoice Billable Assets Variance %",
             "Per mandate invoice: (Billable Assets - Total IBOR Market Value of the mandate's primary implementing portfolio "
             "(18 Portfolio Implementation Link with Implemented Mandate = Billed Mandate and Primary Implementation Indicator = Y) "
             "at Billing Period End) / Total IBOR Market Value; invoices beyond 0.5% are listed, unless Billing Basis is Average "
             "Daily Value or Committed Capital.",
             _u("47", "Fee Invoice", "Billable Assets", "Billing Period End")
             + _u("47", "Billing Arrangement", "Billed Mandate", "Billing Basis")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implemented Mandate",
                  "Primary Implementation Indicator", "Implementation Effective From", "Implementation Effective To")
             + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value")),
            ("Invoice Arithmetic Breaks",
             "Fee Invoice rows where Invoice Total differs from Management Fee Amount + Performance Fee Amount by more than 0.01, "
             "or where the annualized Management Fee Amount is below the Minimum Annual Fee of the schedule without being equal "
             "to it.",
             _u("47", "Fee Invoice", "Invoice Total", "Management Fee Amount", "Performance Fee Amount", "Billing Period Start",
                "Billing Period End")
             + _u("47", "Fee Schedule", "Minimum Annual Fee")),
            ("Open Fee Receivables",
             "Sum of Open Receivable Amount of 19 Receivable Item rows whose Source Fee Invoice is a Fee Invoice ID, by age band of "
             "Receivable Due Date (current, 1-30, 31-90, over 90 days) and Receivable Status; the ledger view of collection, "
             "beside DP-305's Outstanding Fee Invoice Amount from the 47 Payment Status copy.",
             _u("19", "Receivable Item", "Receivable Document Number", "Customer Party", "Source Fee Invoice", "Receivable Due Date",
                "Open Receivable Amount", "Receivable Status")
             + _u("47", "Fee Invoice", "Invoice ID")),
            ("Invoices Past Payment Terms",
             "Fee invoices with Open Receivable Amount above zero (or, before the receivable posts, Payment Status in Issued, Partially Paid, Overdue or Disputed) whose Invoice Date plus Payment Terms Days of the arrangement is "
             "before the as-of date, with the sum open.",
             _u("47", "Fee Invoice", "Invoice Date", "Payment Status")
             + _u("47", "Billing Arrangement", "Payment Terms Days")
             + _u("19", "Receivable Item", "Open Receivable Amount")),
            ("Invoice to Receivable Breaks",
             "Fee invoices with Invoice Date in the period and Fee Collection Method = Invoice that have no 19 Receivable Item "
             "with Source Fee Invoice = Invoice ID, or whose Original Receivable Amount differs from Invoice Total by more than "
             "0.01.",
             _u("47", "Fee Invoice", "Invoice ID", "Invoice Total", "Invoice Date")
             + _u("47", "Billing Arrangement", "Fee Collection Method")
             + _u("19", "Receivable Item", "Source Fee Invoice", "Original Receivable Amount")),
            ("Disputed Invoice Share %",
             "Sum of Disputed Amount of Billing Dispute rows whose Disputed Invoice was dated in the period / Invoiced total "
             "(sum of Invoice Total) of the period, by Dispute Reason.",
             _u("47", "Billing Dispute", "Billing Dispute ID", "Disputed Invoice", "Dispute Reason", "Disputed Amount",
                "Dispute Status")
             + _u("47", "Fee Invoice", "Invoice Total", "Invoice Date")),
            ("MFN True-Up Cost",
             "Sum of Adjustment Amount Value of Fee Adjustment rows with Adjustment Type = MFN True-Up whose Adjusted Invoice "
             "belongs to an arrangement with MFN Clause Indicator = Y, by mandate and Billing Period End.",
             _u("47", "Fee Adjustment", "Fee Adjustment ID", "Adjustment Type", "Adjusted Invoice", "Adjustment Amount Value",
                "Related Billing Dispute")
             + _u("47", "Billing Arrangement", "MFN Clause Indicator")),
            ("Planning Engagement Invoices",
             "Count and sum of Invoice Total of Fee Invoice rows whose Invoice Fee Schedule Assignment has Billed Advice "
             "Engagement populated, by Engagement Type of the 45 Advice Engagement and Fee Collection Method of the assignment.",
             _u("47", "Fee Invoice", "Invoice Fee Schedule Assignment", "Invoice Total")
             + _u("47", "Fee Schedule Assignment", "Fee Schedule Assignment ID", "Billed Advice Engagement", "Fee Collection Method")
             + _u("45", "Advice Engagement", "Advice Engagement ID", "Engagement Type")),
        ],
        inputs=[
            ("47", "Billing Arrangement", ["Billing Arrangement ID", "Billed Mandate", "Bill-To Party", "Applied Fee Schedule",
                                           "Billing Frequency", "Billing Basis", "Fee Collection Method", "Billing Currency",
                                           "MFN Clause Indicator", "Performance Fee Eligibility Basis",
                                           "Qualified Client Determination", "Qualified Client Determination Date",
                                           "Qualified Client Thresholds Applied", "Payment Terms Days",
                                           "Billing Effective From", "Billing Effective To"]),
            ("47", "Performance Fee Calculation", ["Performance Fee Billing Arrangement", "Calculation Period End",
                                                   "Hurdle Benchmark", "High-Water Mark Value", "Calculated Performance Fee",
                                                   "Crystallized Indicator", "Calculation Approved By"]),
            ("47", "Performance Fee Terms", ["Performance Fee Rate", "Hurdle Type", "Hurdle Rate", "High-Water Mark Indicator",
                                             "Crystallization Frequency", "Performance Period", "Performance Fee Basis"]),
            ("47", "Fee Schedule", ["Fee Schedule ID", "Fee Schedule Type", "Schedule Version Number", "Minimum Annual Fee"]),
            ("47", "Fee Invoice", ["Invoice ID", "Invoice Billing Arrangement", "Invoice Fee Schedule Assignment",
                                   "Invoice Bill-To Party", "Billing Period Start", "Billing Period End", "Billable Assets",
                                   "Management Fee Amount", "Performance Fee Amount", "Invoice Total", "Invoice Date",
                                   "Payment Status"]),
            ("47", "Fee Schedule Assignment", ["Fee Schedule Assignment ID", "Billed Advice Engagement", "Assigned Fee Schedule",
                                               "Fee Collection Method"]),
            ("47", "Billing Dispute", ["Billing Dispute ID", "Disputed Invoice", "Dispute Reason", "Disputed Amount",
                                       "Dispute Status"]),
            ("47", "Fee Adjustment", ["Fee Adjustment ID", "Adjustment Type", "Adjusted Invoice", "Adjustment Amount Value",
                                      "Related Billing Dispute"]),
            ("12", "Institutional Client", ["Institutional Client Party", "Institutional Client Type", "ERISA Plan Indicator",
                                            "Government Entity Indicator"]),
            ("01", "Investment Mandate", ["Mandate ID", "Mandate Name", "Mandate Type", "Client"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Mandate",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Portfolio", "Return Period Start Date",
                                          "Return Period End Date", "Return Fee Basis", "Return Value", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Value", "Benchmark Return Status"]),
            ("19", "Receivable Item", ["Receivable Document Number", "Customer Party", "Source Fee Invoice", "Receivable Due Date",
                                       "Original Receivable Amount", "Open Receivable Amount", "Receivable Status"]),
            ("45", "Advice Engagement", ["Advice Engagement ID", "Engagement Type"]),
        ],
        upstream=["DP-305", "DP-003", "DP-004", "DP-140", "DP-142", "DP-145", "DP-303", "DP-240", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after each billing period end, refreshed daily for collections and disputes",
        history="Invoices, calculations and receivable status kept 7 years by billing period (Advisers Act Rule 204-2 books and records; Rule 205-3 determinations for the life of the contract plus 5 years); closed periods final",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Billed Mandate resolves to a DP-004 investment mandate, every Bill-To Party to a DP-240 party (an institutional client in DP-003 for mandates), every Implementing Portfolio to DP-140 and every Billed Advice Engagement to DP-303.",
            "Billing Arrangement periods of one mandate and bill-to party do not overlap, and every Billing Period End is on or after Billing Period Start and within the arrangement's effective period.",
            "Invoiced Management Fees plus Performance Fee Amount by period equals the sum of Invoice Total that DP-305 publishes for the same invoices within 0.01, and Open Fee Receivables equals the 19 open balance for the fee invoices in the ledger.",
            "Billable Assets, Invoice Total and Billing Period End are populated on every invoice, and Performance Fee Eligibility Basis and Qualified Client Determination Date on every arrangement whose schedule has Performance Fee Terms.",
            "Invoices of individual bill-to parties (planning engagements) are published only in the Confidential - Client view; the semantic model carries amounts by mandate type, client type and schedule type only.",
            "A billing period is final on business day 5 after its end; later adjustments arrive as Fee Adjustment rows and never overwrite a closed invoice.",
        ],
        notes=("Certified numbers: reads the official portfolio and benchmark returns "
               "from DP-145 (CW-251) for re-performance only and the portfolio values from DP-142. It owns no "
               "certified metric family. Billed and collected amounts are operational; client fee revenue (Gross Fee Revenue, "
               "Net Fee Revenue) is DP-012's and is not read or recomputed here (CW-214). Book: institutional mandates are 18 "
               "portfolios (Portfolio Valuation Summary through DP-142), never 49. PII tier: identity (bill-to parties of "
               "planning engagements); mandate rows are client-confidential. Boundaries: DP-305 publishes Billing Arrangement, "
               "Performance Fee Calculation, Fee Invoice, Fee Adjustment and Billing Dispute and the measures Performance Fees "
               "Invoiced, Outstanding Fee Invoice Amount, Fee Adjustment Amount and Open Billing Disputes, which are not "
               "redefined here. DP-243 (DIS) shows fee invoices on the institutional relationship and reads this product's Fee Invoice (Invoice ID, Billing Period End, Invoice Total, Payment Status) and Billing Dispute rows; it is not listed here. DP-598 (FOP) ties recognized revenue to the ledger and leaves Invoice to Receivable Breaks and Open Fee Receivables to this product; DP-012 recognizes revenue. "
               "Successor of DP-067 Institutional Fee Billing & Revenue Leakage (CW-216); revenue leakage left to DP-012 and the "
               "backlog DP-348 (merged into DP-349). 19 Receivable Item is read directly (no foundational product publishes it); WP2 foundation candidate. "
               "Objects of the candidate: 18 Holding Valuation is replaced by 18 Portfolio Valuation Summary (the portfolio total "
               "is the billing comparison; the holding-level valuation is DP-142's). Tailoring lever: performance fees offered "
               "to institutional clients. Reference default: yes, for qualified clients only. Tailoring lever: most-favored-nation "
               "clauses. Reference default: honored by MFN True-Up adjustments. Tailoring lever: planning-only fees invoiced or "
               "deducted. Reference default: invoiced. Taxonomy gap: Fee Invoice has no billing currency of its own; the "
               "arrangement's Billing Currency is used. Taxonomy gap: Billing Dispute has no opened or resolved date (DP-305). "
               + GAP6 +
               "Drafting assumptions: 0.5% asset tolerance; 1% re-performance tolerance; receivable age bands; business day 5 "
               "close; Return Status Final or Restated and gross-of-fee basis for the hurdle test. Decisions: CW-011, CW-012, "
               "CW-054, CW-214, CW-216, CW-251. WP1 new (CW-216): first specification, written early in the wave as DP-067's successor."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-320": dict(
        definition=("One view of each Client Household (02 party of type Household, PTY-HH-) and its members: who they are and "
                    "how they are related, the accounts they own and the programs and models those accounts are in, the "
                    "household's client assets and advised assets as decompositions of the certified DP-008 numbers, its "
                    "personal rate of return from DP-145, held-away assets from account aggregation, goals, plans and their "
                    "status, the 47 fee household its accounts bill in, service tier and segment, advisor coverage, recent "
                    "service contact, the trust link and the DP-322 protection flag. It exists so an advisor, planner or service "
                    "associate sees the whole household before a review or a call (CW-211). It owns no certified metric family."),
        business_questions=[
            "Who is in this household, how are they related, and which accounts, programs and models do they hold?",
            "What are the household's client assets and advised assets today, and how do the households add up to the firm's certified Client Assets?",
            "What is the household's personal rate of return, and what does it hold away from the firm?",
            "Which households have no current accepted plan, goals off track, no primary advisor, or a service tier their assets no longer support?",
            "Do the household's accounts bill in one fee household, and does any member carry the protection flag or a recent complaint signal?",
        ],
        grain=("Client Household (02 PTY-HH-) x as-of date, with companion rows at household x member party (membership period) "
               "and household x member account (owner role period); daily snapshot; the household is the 02 household, never "
               "the 13 mailing householding group or the 47 fee household"),
        dimensions=["Client Household and member (DP-240)", "Household member role", "Client account (DP-093)",
                    "Service offering and model portfolio (DP-004)", "Service tier (DP-004) and client segment (DP-240)",
                    "Covering advisor (DP-009)", "Fee household (DP-305)", "Holding type (DP-007)", "Return period and method (DP-145)",
                    "Protection Flag Present (DP-322)", "As-of date (DP-013)"],
        measures=[
            ("Households (from DP-008)",
             "Certified (CW-011), read: Measure Amount of the 06 Measure Value with Measure = MSR-HOUSEHOLDS, Dimension Type = "
             "Total and the period end, from the latest DP-008 Snapshot of Snapshot Type Final or Restated; never recounted here.",
             _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot")),
            ("Households in View",
             "Count of 02 parties with Party Type = Household and Party Status = Active that have at least one Household "
             "Membership with Membership Status = Active in effect (Membership Effective From <= as-of < Membership Effective To "
             "or open), with Household Name, Household Formation Basis and Primary Member populated, and the count whose "
             "Membership Last Confirmed Date is more than 12 months old; the difference to Households (from DP-008) is households "
             "with no funded account.",
             _u("02", "Party", "Party ID", "Party Type", "Party Status")
             + _u("02", "Household", "Household Name", "Household Formation Basis", "Primary Member",
                  "Membership Last Confirmed Date")
             + _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From",
                  "Membership Effective To")),
            ("Household Members",
             "Count of active Household Membership rows per household, by Household Member Role, with the count of members whose "
             "Date of Death is populated.",
             _u("02", "Household Membership", "Household", "Household Member", "Household Member Role", "Membership Status")
             + _u("02", "Individual", "Date of Death")),
            ("Household Client Assets",
             "Per household, the household part of Ending Client Assets under DP-008's rule, applied by reference and never "
             "restated: the DP-007 06 Account Asset Summary rows DP-008 counts (Summary Source Book in DP-008's scope, Summary "
             "As-Of Date = as-of date) plus the DP-007 Fund Shareholder Positions with Aggregation Role = Counted - Intermediary, "
             "of the accounts (Summary Account; position Account) on which a member of the household (02 Household Membership "
             "in effect, the Party Household of DP-240) holds an owner Account Role Type in effect, each account assigned once, "
             "to the household of its Primary Owner; by Summary Holding Type. An operational decomposition of Ending Client "
             "Assets (from DP-008) (CW-211).",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Holding Type",
                "Summary Source Book", "Summary Market Value")
             + _u("06", "Fund Shareholder Position", "Account", "Valuation Date", "Aggregation Role", "Market Value")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")
             + _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From",
                  "Membership Effective To")),
            ("Ending Client Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of the 06 Measure Value with Measure = MSR-CLIENTASSETS, Dimension Type = "
             "Total at the period end, with the Ending Client Assets attribute of its Client Asset Measures, from the latest "
             "Final or Restated DP-008 snapshot.",
             _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Measure Amount", "Snapshot")
             + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Non-Household Client Assets",
             "The named reconciling items between the households and the DP-008 Total, under the same rule: the Omnibus Residual "
             "Amount (06 Omnibus Look-Through, once per Omnibus Parent Account and date), plus the summary rows and Counted - "
             "Intermediary positions of accounts with no household owner on the as-of date.",
             _u("06", "Omnibus Look-Through", "Omnibus Parent Account", "Omnibus Residual Amount")
             + _u("06", "Account Asset Summary", "Summary Account", "Summary Market Value")
             + _u("06", "Fund Shareholder Position", "Account", "Aggregation Role", "Market Value")),
            ("Household Client Assets Tie-Out Variance",
             "At each month-end: sum of Household Client Assets over all households + Non-Household Client Assets - Ending "
             "Client Assets (from DP-008) for the Total row.",
             ["Household Client Assets", "Non-Household Client Assets", "Ending Client Assets (from DP-008)"]),
            ("Household Advised Assets",
             "Per household, the household part of Advised Assets under DP-008's rule, applied by reference: the household's "
             "Account Asset Summary rows with Advised Assets Indicator = Y whose Summary Account has a fee-based advice, managed "
             "or trust 15 Program Enrollment with Enrollment Status = Active in force on the as-of date (Enrollment Effective Date "
             "on or before it, Enrollment Termination Date blank or after it); an operational decomposition of Advised Assets "
             "(from DP-008).",
             _u("06", "Account Asset Summary", "Advised Assets Indicator", "Summary Market Value")
             + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                  "Enrollment Status", "Enrollment Effective Date", "Enrollment Termination Date")
             + ["Household Client Assets"]),
            ("Advised Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of Measure = MSR-ADVISEDASSETS, Dimension Type = Total, with the Advised "
             "Assets attribute of its Client Asset Measures, from the same snapshot; the households' advised assets plus the "
             "advised assets of accounts with no household owner tie to it.",
             _u("06", "Measure Value", "Measure", "Dimension Type", "Measure Amount", "Snapshot")
             + _u("06", "Client Asset Measures", "Advised Assets")),
            ("Managed Share of Household Assets %",
             "Household Client Assets of accounts with a 46 Model Assignment of Assignment Status = Active in effect / Household "
             "Client Assets, with the count of distinct Assigned Model Portfolio.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assigned Model Portfolio", "Assignment Status",
                "Assignment Effective From", "Assignment Effective To")
             + ["Household Client Assets"]),
            ("Household Personal Rate of Return (from DP-145)",
             "Certified (CW-011), read: Personal Return Value of the 32 Personal Rate of Return rows with Personal Return Subject "
             "Type = Household Performance Group, Personal Return Group = the household's Household Performance Group of Performance Group "
             "Type = Default (All Household Accounts) and Performance Group Status = Active, Personal Return Status in (Final, Restated), highest version, "
             "with Personal Return Method, Personal Return Calculation Method and Personal Return Fee Basis shown beside it; "
             "blank where DP-145 suppresses it.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Subject Type", "Personal Return Group",
                "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Method",
                "Personal Return Calculation Method", "Personal Return Fee Basis", "Personal Return Value", "Personal Return Status")
             + _u("32", "Household Performance Group", "Household Performance Group ID", "Group Household", "Performance Group Type",
                  "Performance Group Status")),
            ("Held-Away Assets",
             "Per household: sum of the latest Aggregated Balance Amount (Balance As-Of Date within 7 days) of Aggregated Accounts "
             "owned by members (Aggregated Account Owner) with Aggregation Connection Status = Connected and an Aggregation Consent "
             "resolving to a Consent Record with Consent Status = Granted, by FDX Account Type, with the equity, fixed income and "
             "cash mix; never Client Assets (CW-024), shown beside the stated Outside Investable Assets Band of the member's active "
             "Investor Profile; with the count of members' aggregated accounts whose Aggregation Connection Status is not "
             "Connected or whose Last Successful Refresh Timestamp is more than 7 days old (stale connections).",
             _u("45", "Aggregated Account", "Aggregated Account ID", "Aggregated Account Owner", "FDX Account Type",
                "Aggregation Consent", "Aggregation Connection Status", "Last Successful Refresh Timestamp")
             + _u("45", "Aggregated Account Balance", "Balance Aggregated Account", "Balance As-Of Date", "Aggregated Balance Amount",
                  "Equity Allocation Percentage", "Fixed Income Allocation Percentage", "Cash Allocation Percentage")
             + _u("02", "Consent Record", "Consent Record ID", "Consent Status")
             + _u("02", "Investor Profile", "Profile Client", "Outside Investable Assets Band", "Profile Status")),
            ("Households Without Current Plan",
             "Households with an Advice Engagement of Engagement Status = Active owned by the household or a member (Engagement "
             "Client) and no Client Financial Plan (Plan Subject = household or member) with Client Financial Plan Status = Active "
             "whose latest version has Client Financial Plan Version Status = Accepted, or whose accepted version has Plan Data "
             "As-Of Date more than 12 months old.",
             _u("45", "Advice Engagement", "Advice Engagement ID", "Engagement Client", "Engagement Type", "Engagement Status")
             + _u("45", "Client Financial Plan", "Client Financial Plan ID", "Plan Subject", "Client Financial Plan Status")
             + _u("45", "Client Financial Plan Version", "Versioned Plan", "Client Financial Plan Version Status",
                  "Plan Accepted Date", "Plan Data As-Of Date")),
            ("Household Goals Off Track",
             "Count of Active Financial Goals owned by the household or a member whose latest Goal Progress Snapshot has On-Track "
             "Status in (At Risk, Off Track), with the lowest Goal Funded Ratio.",
             _u("45", "Financial Goal", "Financial Goal ID", "Goal Owner", "Goal Type", "Goal Status")
             + _u("45", "Goal Progress Snapshot", "Snapshot Goal", "Snapshot As-Of Date", "Goal Funded Ratio", "On-Track Status")),
            ("Fee Household Alignment Breaks",
             "Household accounts that are a Member Account of an active 47 Fee Household Membership whose Fee Household's Anchor "
             "Client Household is a different 02 household, and households whose member accounts bill in more than one active "
             "Fee Household: the 47 fee aggregation group compared with the 02 household.",
             _u("47", "Fee Household", "Fee Household ID", "Anchor Client Household", "Fee Household Status")
             + _u("47", "Fee Household Membership", "Membership Fee Household", "Member Account", "Fee Household Membership Status",
                  "Fee Household Membership Effective From", "Fee Household Membership Effective To")
             + _u("46", "Household Managed Group", "Managed Group Household", "Group Member Account", "Group Membership Status")),
            ("Households Without Primary Advisor",
             "Households with Household Advised Assets above zero and no 03 Party Coverage Assignment (Covered Party = household "
             "or a member) with Primary Coverage Indicator = Y and Party Coverage Role = Primary Advisor in effect.",
             _u("03", "Party Coverage Assignment", "Coverage Assignment ID", "Covered Party", "Covering Advisor",
                "Party Coverage Role", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To")
             + ["Household Advised Assets"]),
            ("Service Tier Qualification Mismatch",
             "Households whose Service Tier Assignment in effect (Tier Party = household) has Tier Assignment Method other than "
             "Manual Override or Grandfathered and whose Household Client Assets is below the 01 Service Tier Tier Asset Threshold "
             "of the Assigned Service Tier, or at or above the threshold of the next higher tier; by Assigned Service Tier, with "
             "overrides lacking Override Approver counted separately.",
             _u("02", "Service Tier Assignment", "Tier Party", "Assigned Service Tier", "Tier Assignment Method", "Override Approver",
                "Tier Effective From", "Tier Effective To")
             + _u("01", "Service Tier", "Service Tier Code", "Tier Asset Threshold", "Tier Measurement Basis")
             + ["Household Client Assets"]),
            ("Recent Service Contacts",
             "Count of 13 Contact Center Interaction rows of household members (Interaction Party) with Interaction Start "
             "Timestamp in the trailing 90 days, and the count with Dissatisfaction Expressed Indicator = Y, by Contact Reason.",
             _u("13", "Contact Center Interaction", "Interaction ID", "Interaction Party", "Interaction Start Timestamp",
                "Contact Reason", "Dissatisfaction Expressed Indicator")),
            ("Trust-Linked Households",
             "Households with a member party that is the Trust Party of a 51 Trust with Trust Status = Active (the optional trust "
             "panel), by Revocability.",
             _u("51", "Trust", "Trust ID", "Trust Party", "Revocability", "Trust Status")
             + _u("02", "Household Membership", "Household Member")),
            ("Protection Flag Present (from DP-322)",
             "Y for a household when DP-322 publishes Protection Flag Present = Y for any member's Party ID or any household "
             "account's Account ID; read as published, joined on the non-special keys; no reason or detail is carried.",
             _u("02", "Party", "Party ID") + _u("15", "Account", "Account ID")
             + _u("02", "Household Membership", "Household Member")),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Relationship Stage"]),
            ("02", "Individual", ["Given Name", "Family Name", "Date of Birth", "Date of Death"]),
            ("02", "Household", ["Household Name", "Household Formation Basis", "Primary Member", "Membership Last Confirmed Date"]),
            ("02", "Household Membership", ["Household", "Household Member", "Household Member Role", "Membership Status",
                                            "Membership Effective From", "Membership Effective To"]),
            ("02", "Service Tier Assignment", ["Tier Party", "Assigned Service Tier", "Tier Assignment Method", "Override Approver",
                                               "Tier Effective From", "Tier Effective To"]),
            ("02", "Investor Profile", ["Investor Profile ID", "Profile Client", "Outside Investable Assets Band", "Profile Status"]),
            ("02", "Consent Record", ["Consent Record ID", "Consent Purpose", "Consent Status"]),
            ("01", "Service Tier", ["Service Tier Code", "Service Tier Name", "Tier Asset Threshold", "Tier Measurement Basis"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status", "Account Business Line"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                                          "Enrollment Status", "Enrollment Effective Date", "Enrollment Termination Date"]),
            ("45", "Advice Engagement", ["Advice Engagement ID", "Engagement Client", "Engagement Type", "Engagement Advisor",
                                         "Engagement Status"]),
            ("45", "Financial Goal", ["Financial Goal ID", "Goal Owner", "Goal Type", "Goal Status"]),
            ("45", "Goal Progress Snapshot", ["Snapshot Goal", "Snapshot As-Of Date", "Goal Funded Ratio", "On-Track Status"]),
            ("45", "Client Financial Plan", ["Client Financial Plan ID", "Plan Subject", "Client Financial Plan Status"]),
            ("45", "Client Financial Plan Version", ["Versioned Plan", "Client Financial Plan Version Status", "Plan Data As-Of Date",
                                                     "Plan Accepted Date"]),
            ("45", "Aggregated Account", ["Aggregated Account ID", "Aggregated Account Owner", "FDX Account Type",
                                          "Aggregation Consent", "Aggregation Connection Status",
                                          "Last Successful Refresh Timestamp"]),
            ("45", "Aggregated Account Balance", ["Balance Aggregated Account", "Balance As-Of Date", "Aggregated Balance Amount",
                                                  "Equity Allocation Percentage", "Fixed Income Allocation Percentage",
                                                  "Cash Allocation Percentage"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assigned Model Portfolio", "Assignment Status",
                                        "Assignment Effective From", "Assignment Effective To"]),
            ("46", "Household Managed Group", ["Managed Group Household", "Group Member Account", "Managed-Together Basis",
                                               "Group Membership Status"]),
            ("47", "Fee Household", ["Fee Household ID", "Anchor Client Household", "Fee Household Status"]),
            ("47", "Fee Household Membership", ["Membership Fee Household", "Member Account", "Fee Household Membership Status",
                                                "Fee Household Membership Effective From",
                                                "Fee Household Membership Effective To"]),
            ("51", "Trust", ["Trust ID", "Trust Party", "Revocability", "Trust Status"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Account", "Share Class", "Valuation Date", "Aggregation Role",
                                                 "Market Value"]),
            ("06", "Omnibus Look-Through", ["Omnibus Parent Account", "Omnibus Residual Amount"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Holding Type", "Summary Source Book",
                                             "Summary Market Value", "Advised Assets Indicator"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Advised Assets"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Subject Type", "Personal Return Group",
                                               "Personal Return Period Start Date", "Personal Return Period End Date",
                                               "Personal Return Method", "Personal Return Calculation Method",
                                               "Personal Return Fee Basis", "Personal Return Value", "Personal Return Status"]),
            ("32", "Household Performance Group", ["Household Performance Group ID", "Group Household", "Performance Group Type",
                                                   "Performance Group Status"]),
            ("03", "Party Coverage Assignment", ["Coverage Assignment ID", "Covered Party", "Covering Advisor", "Party Coverage Role",
                                                 "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To"]),
            ("13", "Contact Center Interaction", ["Interaction ID", "Interaction Party", "Interaction Start Timestamp",
                                                  "Contact Reason", "Dissatisfaction Expressed Indicator"]),
        ],
        upstream=["DP-240", "DP-093", "DP-004", "DP-007", "DP-008", "DP-145", "DP-303", "DP-304", "DP-305", "DP-307",
                  "DP-009", "DP-381", "DP-322", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1, after DP-007 publishes the account asset summaries; month-end tie-out after the DP-008 snapshot locks",
        history="Daily household snapshots kept 2 years and month-end snapshots 7 years; membership, coverage and tier history SCD type 2 from DP-240 and DP-009",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["CRM embed", "API", "BI semantic model", "Warehouse table"],
        dq_rules=[
            "Every household and member resolves to an active DP-240 party (Party Type = Household for the household), every account to a DP-093 account, every Covering Advisor to DP-009, every Assigned Service Tier to DP-004 and every Fee Household to DP-305.",
            "Household Membership periods of one member do not overlap across households, and each firm client account is assigned to exactly one household (or to none) on each as-of date.",
            "At each month-end Household Client Assets Tie-Out Variance is within USD 1 against the DP-008 Total row, the households' Household Advised Assets plus those of accounts with no household owner are within USD 1 of Advised Assets (from DP-008), and Households (from DP-008) and Household Personal Rate of Return (from DP-145) equal the owners' published values for the same snapshot and version.",
            "Household Name and Primary Member are populated on every active household, Summary Market Value on every summary row read, and Personal Return Method and Personal Return Fee Basis on every return shown.",
            "Special-category facts appear only as Protection Flag Present (from DP-322); Date of Birth is published as age only and government identifiers are never read; held-away balances are shown only where Aggregation Consent is Granted; household rows are visible only to roles covering or servicing the household.",
            "The daily view is published by 7am ET on T+1 and the month-end view only after the DP-008 snapshot of the month is Final; a published month-end snapshot is never overwritten.",
        ],
        notes=("Master concept: the Client Household is DP-240's (CW-005, CW-027; household dimension stays in DP-240). Certified "
               "numbers: reads Households, Ending Client Assets and Advised Assets from DP-008 and Personal Return Value from "
               "DP-145; owns none (CW-211). Household Client Assets and Household Advised Assets are operational decompositions "
               "of the certified numbers: they apply DP-008's rules by reference (its Summary Source Book scope, the Counted - "
               "Intermediary positions, the program-enrollment condition for advised assets) to DP-007's rows through the DP-240 "
               "household, and Non-Household Client Assets (omnibus residual and accounts with no household owner) is the named "
               "reconciling item to the DP-008 Total (DQ3); the rules are never restated here. Client Assets are never summed with Firm AUM or with held-away assets. PII tier: financial "
               "(identity for members). " + FLAG_NOTE +
               "Boundaries: DP-243 Total Client Relationship stays the institutional (IA) relationship view. Goals and plans are "
               "shown, not scored: goal progress is DP-337's and the Reg BI file DP-334's. The trust panel is optional with DP-307. "
               "Backlog DP-325 Service Tier Qualification & Client Segments folds in (Service Tier Qualification Mismatch, "
               "segments, read through the DP-240 client segment dimension; 01 Service Offering is reached through DP-004 by "
               "the Enrolled Service Offering key and not re-read) and DP-338 Held-Away Assets & Consolidation Opportunity folds in (45 Aggregated Account and Aggregated "
               "Account Balance, moved reads; Held-Away Assets). Objects of the candidates not read: 06 Client Asset Measures is "
               "read (Ending Client Assets, Advised Assets); 02 Service Tier Assignment Qualifying Client Assets and Qualifying "
               "Assets As-Of Date are Derived copies of 06 and are not read (current household assets are used); 16 Separated "
               "Participant Entry (DP-338) is a Form 8955-SSA row read by the workplace products and adds nothing to the household "
               "view. 02 Party Relationship and Segment Assignment are not read (relationships and segments are DP-240 "
               "dimensions). Acceptance question 9: feeds DP-145 and DP-532 with Household Personal Rate of Return (from "
               "DP-145), shown with its method (mastering domains 32, 02, 49). Tailoring lever: household "
               "definition (02 SME 2). Reference default: client-defined households with proposed memberships held. Tailoring "
               "lever: household assignment of joint accounts. Reference default: the Primary Owner's household. Tailoring "
               "lever: trust line not adopted. Reference default: offered; without it the trust panel and DP-307 drop. Tailoring "
               "lever: workplace plan assets counted toward tier (02 SME 10). Reference default: not counted. Taxonomy gap: DP-008 "
               "publishes no Household Dimension Type, so household client assets are a decomposition from DP-007 rows rather "
               "than a certified household value. Taxonomy gap: 02 Household carries no household-level advisor of record; "
               "coverage is read from 03. Drafting assumptions: the owner Account Role Types; Snapshot Type Final or Restated; "
               "7-day aggregation freshness; 12-month plan data; trailing 90 days for service contact; Performance Group Type "
               "Default. Decisions: CW-005, CW-011, CW-024, CW-027, CW-211, CW-213, CW-251. WP1 new (CW-211): first "
               "specification; the plan section 8.3 Household 360 example."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-321": dict(
        definition=("The current register of who may act for, or be contacted about, each client and account: authority grants "
                    "(powers of attorney, trading authorizations, guardianships, executors) with their scope, evidence and "
                    "accounts covered, trusted contact designations under FINRA Rule 4512, beneficiary and TOD designations, and "
                    "death notifications with the account restrictions they trigger. Account services and operations work its "
                    "exceptions; supervision uses its Rule 4512 coverage evidence. It owns no certified metric family."),
        business_questions=[
            "For which accounts did we fail to make a reasonable effort to obtain a trusted contact (FINRA Rule 4512), and how current are the contacts we hold?",
            "Which authority grants are active without evidence, cover accounts the grantor does not own, or survive the grantor's death?",
            "Which beneficiary designations name a deceased beneficiary or lack required spousal consent?",
            "Which deaths were notified but the decedent's accounts are not yet restricted, and how long does restriction take?",
            "Where is a trusted contact also the client's agent, so the Rule 2165 notice may need another recipient?",
        ],
        grain=("Account (15) x as-of date for the Rule 4512 and beneficiary tests, with companion registers at authority grant "
               "(AGNT-), trusted contact designation (TCNT-), beneficiary designation and death notification (DTHN-); SCD type 2 "
               "on every designation and grant"),
        dimensions=["Client and Client Household (DP-240)", "Client account and registration type (DP-093)", "Authority type and scope",
                    "Trusted contact designation status", "Beneficiary designation type and beneficiary type",
                    "Death notification status", "Protection Flag Present (DP-322)", "As-of date (DP-013)"],
        measures=[
            ("Accounts Requiring Trusted Contact Request",
             "Count of open 15 accounts (Account Status = Open) of Account Type in (Brokerage Account, Fund-Only Account, Managed "
             "Advisory Account) whose Primary Owner is an individual (Party Type = Individual) and that were opened or had owner "
             "information updated on or after 2018-02-05 (Account Open Date, or a later owner Account Role Effective From).",
             _u("15", "Account", "Account ID", "Account Type", "Account Status", "Account Open Date")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")
             + _u("02", "Party", "Party ID", "Party Type")),
            ("Trusted Contact Coverage Rate",
             "Accounts Requiring Trusted Contact Request whose Primary Owner has a Trusted Contact Designation (Designating Client) "
             "in effect covering the account (Account Scope blank or containing the account) with Designation Status in "
             "(Provided, Declined by Client) or Reasonable Efforts Date populated / Accounts Requiring Trusted Contact Request: "
             "the Rule 4512(a)(1)(F) reasonable-effort evidence.",
             _u("02", "Trusted Contact Designation", "Trusted Contact Designation ID", "Designating Client", "Designation Status",
                "Account Scope", "Reasonable Efforts Date", "Designation Effective From", "Designation Effective To")
             + ["Accounts Requiring Trusted Contact Request"]),
            ("Trusted Contact Provided %",
             "Accounts Requiring Trusted Contact Request covered by a designation in effect with Designation Status = Provided / "
             "Accounts Requiring Trusted Contact Request.",
             _u("02", "Trusted Contact Designation", "Designation Status") + ["Accounts Requiring Trusted Contact Request"]),
            ("Trusted Contacts Not Reconfirmed",
             "Designations in effect with Designation Status = Provided whose Last Confirmed Date (or Designation Effective From "
             "where blank) is more than 3 years before the as-of date.",
             _u("02", "Trusted Contact Designation", "Designation Status", "Last Confirmed Date", "Designation Effective From")),
            ("Trusted Contact Disclosure Missing",
             "Designations in effect with Designation Status = Provided and Trusted Contact Disclosure Date blank (the Rule "
             "4512(a)(1)(F) disclosure that the firm may contact the person).",
             _u("02", "Trusted Contact Designation", "Designation Status", "Trusted Contact Disclosure Date")),
            ("Trusted Contact Is Agent",
             "Designations in effect whose Trusted Contact Person is also the Authority Holder of an Authority Grant of the same "
             "Grantor Party in effect (Revoked Date blank).",
             _u("02", "Trusted Contact Designation", "Designating Client", "Trusted Contact Person")
             + _u("02", "Authority Grant", "Grantor Party", "Authority Holder", "Revoked Date")),
            ("Active Authority Grants",
             "Count of Authority Grant ID with Grant Effective From <= as-of date and Revoked Date blank or later, by Authority "
             "Type and Authority Scope.",
             _u("02", "Authority Grant", "Authority Grant ID", "Authority Type", "Authority Scope", "Grant Effective From",
                "Revoked Date")),
            ("Authority Grants Without Evidence",
             "Active Authority Grants with Authority Evidence blank, by Authority Type and Intake Service Request status.",
             _u("02", "Authority Grant", "Authority Evidence", "Intake Service Request") + ["Active Authority Grants"]),
            ("Grants Covering Unowned or Closed Accounts",
             "Active Authority Grants whose Accounts Covered includes an account that is not Open or on which the Grantor Party "
             "holds no owner Account Party Role in effect.",
             _u("02", "Authority Grant", "Grantor Party", "Accounts Covered")
             + _u("15", "Account", "Account Status")
             + _u("15", "Account Party Role", "Role Party", "Role Account", "Account Role Type")
             + ["Active Authority Grants"]),
            ("Grants Surviving Grantor Death",
             "Active Authority Grants of Authority Type in (Durable Power of Attorney, Limited Power of Attorney, Springing Power "
             "of Attorney, Trading Authorization) whose Grantor Party is the Deceased Party of a Death Notification received more "
             "than 2 business days earlier: authority ends at death.",
             _u("02", "Authority Grant", "Authority Type", "Grantor Party")
             + _u("02", "Death Notification", "Deceased Party", "Notification Received Date")
             + ["Active Authority Grants"]),
            ("Deceased Beneficiaries",
             "Beneficiary Designation rows in effect (Designation Effective From / To) whose Beneficiary has an 02 Date of Death "
             "or is the Deceased Party of a Death Notification, by Beneficiary Designation Type and Beneficiary Type.",
             _u("15", "Beneficiary Designation", "Beneficiary Designation ID", "Designated Account", "Beneficiary",
                "Beneficiary Designation Type", "Beneficiary Type", "Designation Effective From", "Designation Effective To")
             + _u("02", "Individual", "Date of Death")
             + _u("02", "Death Notification", "Deceased Party")),
            ("Spousal Consent Missing",
             "Primary beneficiary designations in effect on IRA accounts (Account Registration Type in Traditional IRA, Rollover "
             "IRA, SEP IRA, SIMPLE IRA) whose owner has a Party Relationship of Relationship Type = Spouse Of in effect, where the "
             "Beneficiary is not that spouse, the allocation to non-spouse beneficiaries is above zero and Spousal Consent Obtained "
             "Indicator is not Y.",
             _u("15", "Beneficiary Designation", "Beneficiary", "Beneficiary Type", "Beneficiary Allocation Percentage",
                "Spousal Consent Obtained Indicator")
             + _u("15", "Account", "Account Registration Type")
             + _u("02", "Party Relationship", "From Party", "To Party", "Relationship Type", "Relationship Effective From",
                  "Relationship Effective To")),
            ("Deaths Notified Not Restricted",
             "Death Notifications with Notification Received Date more than 2 business days before the as-of date whose Deceased "
             "Party owns an open account with no 15 Account Restriction of Account Restriction Type = Deceased Owner in effect "
             "(Account Restriction Effective From on or after the notification, Account Restriction Lifted Date blank).",
             _u("02", "Death Notification", "Death Notification ID", "Deceased Party", "Notification Received Date",
                "Notification Status")
             + _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Type",
                  "Account Restriction Effective From", "Account Restriction Lifted Date")
             + _u("15", "Account Party Role", "Role Party", "Role Account")),
            ("Notification to Restriction Days",
             "Median business days from Notification Received Date to the first Deceased Owner Account Restriction Effective From "
             "on the decedent's accounts, for notifications received in the period, with the share where Death Certificate "
             "Received Date is still blank.",
             _u("02", "Death Notification", "Notification Received Date", "Death Certificate Received Date")
             + _u("15", "Account Restriction", "Account Restriction Type", "Account Restriction Effective From")),
            ("Protection Flag Present (from DP-322)",
             "Y per 02 party and 15 account as DP-322 publishes it, carried beside the trusted contact and authority registers so "
             "service routes the client to trained staff; joined on Party ID and Account ID only.",
             _u("02", "Party", "Party ID") + _u("15", "Account", "Account ID")),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Status"]),
            ("02", "Individual", ["Date of Death"]),
            ("02", "Authority Grant", ["Authority Grant ID", "Grantor Party", "Authority Holder", "Authority Type",
                                       "Authority Scope", "Accounts Covered", "Authority Evidence", "Grant Effective From",
                                       "Revoked Date", "Intake Service Request"]),
            ("02", "Trusted Contact Designation", ["Trusted Contact Designation ID", "Designating Client", "Trusted Contact Person",
                                                   "Designation Status", "Account Scope", "Reasonable Efforts Date",
                                                   "Trusted Contact Disclosure Date", "Last Confirmed Date",
                                                   "Designation Effective From", "Designation Effective To"]),
            ("02", "Death Notification", ["Death Notification ID", "Deceased Party", "Notification Received Date",
                                          "Reported Date of Death", "Death Certificate Received Date", "Estate Representative",
                                          "Representative Authority Grant", "Notification Status"]),
            ("02", "Party Relationship", ["From Party", "To Party", "Relationship Type", "Relationship Effective From",
                                          "Relationship Effective To"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status", "Account Open Date"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("15", "Beneficiary Designation", ["Beneficiary Designation ID", "Designated Account", "Beneficiary",
                                               "Beneficiary Designation Type", "Beneficiary Type",
                                               "Beneficiary Allocation Percentage", "Spousal Consent Obtained Indicator",
                                               "Designation Effective From", "Designation Effective To"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date"]),
        ],
        upstream=["DP-240", "DP-093", "DP-381", "DP-322", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; death notifications and revocations applied intraday through the DP-240 feed",
        history="SCD type 2 on grants, designations and notifications, kept 6 years after the account closes (SEC Rule 17a-3(a)(17) and FINRA Rule 4512 account records; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["CRM embed", "API", "Warehouse table", "Dashboard"],
        dq_rules=[
            "Every Grantor Party, Authority Holder, Designating Client, Trusted Contact Person, Beneficiary and Deceased Party resolves to a DP-240 party, and every Accounts Covered, Account Scope and Designated Account value to a DP-093 account.",
            "Trusted Contact Designation periods of one client and contact do not overlap, Beneficiary Designation periods of one account, beneficiary and type do not overlap, and Revoked Date and every effective-to date are on or after their starts.",
            "Primary Beneficiary Allocation Percentage of each account's designations in effect sums to 100 within 0.01 (or no primary row), matching DP-093's Beneficiary Allocation Check, and Accounts Requiring Trusted Contact Request reconciles to the DP-093 open accounts of the same types.",
            "Designation Status is populated on every Trusted Contact Designation, Authority Type, Authority Scope and Grant Effective From on every Authority Grant, and Notification Received Date and Notification Status on every Death Notification.",
            "15 Account Restriction rows of Account Restriction Type = Financial Exploitation are excluded at extraction and never published (special category, CW-213); dates of birth and government identifiers of third parties are not read; only Protection Flag Present (from DP-322) is carried.",
            "Death notifications are applied within 1 business day of receipt and a prior day's snapshot of grants and designations is never rewritten.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: identity (third parties named as agents, "
               "trusted contacts and beneficiaries). " + FLAG_NOTE +
               "Boundaries: DP-240 publishes the parties and DP-093 the account roles, beneficiaries and the Beneficiary "
               "Allocation Check, which is not redefined here; DP-381 publishes the service requests and Estate Requests With "
               "Documents Outstanding; estate settlement is DP-354's; the Rule 2165 holds and cases are DP-322's and DP-403's. "
               "Objects of the candidate not read: 13 Transfer of Ownership & Estate (an attribute group of 13 Service Request "
               "read through DP-381 and by DP-354) and 39 Power of Attorney (the firm's own signing authority granted by a 09 "
               "legal entity, a different concept from a client's 02 Authority Grant; read by the legal products). Tailoring lever: "
               "trusted contact per client or per account (02 SME 6). Reference default: per client, Account Scope blank meaning "
               "all accounts. Tailoring lever: trusted contact reconfirmation cycle. Reference default: 3 years. Tailoring lever: "
               "spousal consent rule for IRAs. Reference default: required in community property states; tested here on every "
               "IRA with a spouse on record (the state is not tested). Taxonomy gap: 15 Account has no last owner-information "
               "update date, so Rule 4512 applicability is approximated from Account Open Date and owner role changes. Taxonomy "
               "gap: no attribute records the owner's state of residence for the community property test. Drafting assumptions: "
               "account types in Rule 4512 scope; the 2018-02-05 effective date; owner Account Role Types; Authority Types that end "
               "at death; 2 business days to restrict. Decisions: CW-005, CW-021, CW-213, CD-344. WP1 new (lead ruling "
               "2026-10-15, pulled back from the backlog for Rule 4512): first specification."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-329": dict(
        definition=("For every IRA-family and inherited IRA account, the required minimum distribution of the year with its "
                    "prior year-end fair market value (from 49 Client Holdings) and divisor, what has been distributed so far "
                    "(50), the withholding election that applies, the beneficiary rules (required beginning date, the 10-year "
                    "rule for inherited accounts) and the scheduled instructions and managed account cash raises that will meet "
                    "the shortfall. Service and advisors work the shortfall list before year-end and operations evidences that "
                    "RMDs were calculated, noticed and paid. It owns no certified metric family."),
        business_questions=[
            "Which IRA owners still have an RMD shortfall this year, how large is it, and is a distribution scheduled to meet it?",
            "Does each RMD required amount agree to the prior year-end fair market value divided by the life expectancy divisor?",
            "Which owners face their first RMD by April 1 after the year they reach their required beginning date, and which inherited IRAs approach the end of their 10-year period?",
            "Which IRA distributions were paid without a withholding election on file, so default withholding applied?",
            "Which RMDs were missed last year and need correction?",
        ],
        grain="IRA account (15) x distribution year (RMD Record), with distributions (50 money movements) and withholding elections as companion facts; daily through the year, the year closed at January 31 of the following year",
        dimensions=["Client and Client Household (DP-240)", "Client account and registration type (DP-093)", "Distribution year",
                    "RMD status", "Beneficiary class", "Withholding election type", "Managed account (DP-304)", "Value date (DP-013)"],
        measures=[
            ("RMD Accounts",
             "Count of RMD Record rows of the distribution year with RMD Status other than Not Yet Required on open IRA accounts, "
             "by Account Registration Type and RMD Aggregation Indicator.",
             _u("15", "RMD Record", "RMD Account", "RMD Distribution Year", "RMD Status", "RMD Aggregation Indicator")
             + _u("15", "Account", "Account ID", "Account Registration Type", "Account Status")),
            ("RMD Required Amount",
             "Sum of RMD Required Amount of RMD Accounts for the distribution year (USD).",
             _u("15", "RMD Record", "RMD Required Amount") + ["RMD Accounts"]),
            ("Prior Year-End Fair Market Value",
             "Per RMD account: Market Value in USD of its End of Day 49 Client Holdings on the last business day of the prior "
             "year plus its client cash on that date under the DP-007 client cash rule (Account Cash Balance with Balance Basis = Settlement Date and Cash Balance Type in (Free Credit Balance, Sweep Balance, Short Sale Proceeds); from DP-300), less any Margin Debit Balance; the book value the RMD rests on.",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type",
                  "Balance Basis", "Cash Balance Amount")
             + _u("49", "Margin Balance Snapshot", "Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Debit Balance")),
            ("RMD Calculation Variance",
             "Per RMD account: RMD Required Amount - Prior Year-End Fair Market Value / Distribution Period Divisor; the count of "
             "accounts where the absolute variance exceeds USD 1, by RMD Life Expectancy Table.",
             _u("15", "RMD Record", "RMD Required Amount", "Distribution Period Divisor", "RMD Life Expectancy Table")
             + ["Prior Year-End Fair Market Value"]),
            ("RMD Distributed to Date",
             "Per RMD account: sum of Movement Amount of 50 Money Movement rows with Movement Account = the account, Money Movement "
             "Type = Retirement Distribution, Movement Direction = Outflow, Money Movement Status = Settled and Value Date in the "
             "distribution year (USD).",
             _u("50", "Money Movement", "Money Movement ID", "Movement Account", "Money Movement Type", "Movement Direction",
                "Movement Amount", "Value Date", "Money Movement Status")),
            ("RMD Shortfall",
             "Per RMD account with RMD Aggregation Indicator not Y: max(0, RMD Required Amount - RMD Distributed to Date); for "
             "aggregated IRAs, computed once per owner (Primary Owner Account Party Role) across the owner's aggregated IRAs; with "
             "the count of owners with a shortfall.",
             _u("15", "RMD Record", "RMD Required Amount", "RMD Aggregation Indicator")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account")
             + ["RMD Distributed to Date"]),
            ("Unscheduled Shortfalls",
             "Owners with RMD Shortfall above zero on or after December 1 whose accounts have no Account Standing Instruction of "
             "Instruction Type in (Automatic RMD, Systematic Withdrawal) with Instruction Status active and a Next Run Date before "
             "December 31, and no 46 Managed Account Cash Instruction of Cash Instruction Type = Raise for RMD that is not "
             "Canceled.",
             _u("15", "Account Standing Instruction", "Standing Instruction ID", "Instruction Type", "Instruction Account",
                "Instruction Status", "Instruction Amount", "Next Run Date")
             + _u("46", "Managed Account Cash Instruction", "Cash Instruction ID", "Instruction Account", "Cash Instruction Type",
                  "Cash Instruction Status")
             + ["RMD Shortfall"]),
            ("Managed Account RMD Raises Late",
             "46 Managed Account Cash Instructions of Cash Instruction Type = Raise for RMD with Source RMD Record populated whose "
             "Cash Instruction Status is not in (Cash Available, Invested, Canceled) within 5 business days of Required By Date, "
             "with the sum of Instruction Amount.",
             _u("46", "Managed Account Cash Instruction", "Cash Instruction Type", "Instruction Amount", "Source RMD Record",
                "Required By Date", "Cash Instruction Status")),
            ("Missed RMDs",
             "RMD Records of the prior distribution year with RMD Status = Missed, or with RMD Shortfall above zero at December 31 "
             "(April 1 for a first-year RMD), by Account Registration Type.",
             _u("15", "RMD Record", "RMD Status", "RMD Distribution Year") + ["RMD Shortfall"]),
            ("First-Year RMD Owners",
             "Owners whose Required Beginning Date falls in the year after the distribution year (first RMD due by April 1), from "
             "15 Retirement Account Detail, with the owner's age taken from 02 Date of Birth against the SECURE 2.0 applicable age (73 for births 1951 to 1959, 75 for 1960 and later).",
             _u("15", "Retirement Account Detail", "Required Beginning Date")
             + _u("02", "Individual", "Date of Birth")
             + ["RMD Accounts"]),
            ("Inherited IRA Ten-Year Deadlines",
             "Open inherited IRAs (Account Registration Type in Inherited IRA, Inherited Roth IRA) with Beneficiary Class = "
             "Designated Beneficiary (Ten-Year Rule) whose Ten-Year Period End Date falls within 2 years of the as-of date, with "
             "their Prior Year-End Fair Market Value.",
             _u("15", "Retirement Account Detail", "Inherited IRA Decedent", "Beneficiary Class", "Ten-Year Period End Date")
             + _u("15", "Account", "Account Registration Type")
             + ["Prior Year-End Fair Market Value"]),
            ("Distributions Without Withholding Election",
             "Settled retirement distributions of the year whose account had no Retirement Distribution Election of Withholding "
             "Election Type = Federal - Nonperiodic (Form W-4R) in effect on the Value Date (Withholding Election Effective From / "
             "To), so the 10% default withholding applied; count and amount.",
             _u("15", "Retirement Distribution Election", "Withholding Election Account", "Withholding Election Type",
                "Withholding Rate", "Withholding State", "Withholding Election Effective From", "Withholding Election Effective To")
             + ["RMD Distributed to Date"]),
            ("IRAs Without Primary Beneficiary",
             "Open IRA accounts with no Beneficiary Designation of Beneficiary Type = Primary in effect.",
             _u("15", "Beneficiary Designation", "Designated Account", "Beneficiary", "Beneficiary Type",
                "Beneficiary Allocation Percentage", "Designation Effective From", "Designation Effective To")
             + _u("15", "Account", "Account Registration Type", "Account Status")),
            ("Participant Distribution Elections",
             "Count of 16 Participant Distribution Election rows in effect by Distribution Election Type (Automatic RMD, "
             "Installment Schedule and the withholding elections), with the median Elected Withholding Rate: the plan-side "
             "elections of participants whose retail IRAs are tracked here.",
             _u("16", "Participant Distribution Election", "Distribution Election Membership", "Distribution Election Type",
                "Installment Frequency", "Elected Withholding Rate", "Distribution Election Effective From",
                "Distribution Election Effective To")),
        ],
        inputs=[
            ("15", "RMD Record", ["RMD Account", "RMD Distribution Year", "RMD Life Expectancy Table", "Distribution Period Divisor",
                                  "RMD Required Amount", "RMD Aggregation Indicator", "RMD Status"]),
            ("15", "Retirement Account Detail", ["Inherited IRA Decedent", "Beneficiary Class", "Ten-Year Period End Date",
                                                 "Required Beginning Date"]),
            ("15", "Retirement Distribution Election", ["Withholding Election Account", "Withholding Election Type",
                                                        "Withholding Rate", "Withholding State",
                                                        "Withholding Election Effective From",
                                                        "Withholding Election Effective To"]),
            ("15", "Beneficiary Designation", ["Designated Account", "Beneficiary", "Beneficiary Type",
                                               "Beneficiary Allocation Percentage", "Designation Effective From",
                                               "Designation Effective To"]),
            ("15", "Account", ["Account ID", "Account Registration Type", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account"]),
            ("15", "Account Standing Instruction", ["Standing Instruction ID", "Instruction Type", "Instruction Account",
                                                    "Instruction Status", "Instruction Amount", "Next Run Date"]),
            ("02", "Individual", ["Date of Birth", "Date of Death"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("49", "Margin Balance Snapshot", ["Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Debit Balance"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type", "Balance Basis",
                                            "Cash Balance Amount"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Money Movement Type", "Movement Direction",
                                      "Movement Amount", "Value Date", "Money Movement Status"]),
            ("46", "Managed Account Cash Instruction", ["Cash Instruction ID", "Instruction Account", "Cash Instruction Type",
                                                        "Instruction Amount", "Source RMD Record", "Required By Date",
                                                        "Cash Instruction Status"]),
            ("16", "Participant Distribution Election", ["Distribution Election Membership", "Distribution Election Type",
                                                         "Installment Frequency", "Elected Withholding Rate",
                                                         "Distribution Election Effective From",
                                                         "Distribution Election Effective To"]),
        ],
        upstream=["DP-093", "DP-240", "DP-300", "DP-302", "DP-304", "DP-094", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; the year's RMD file closed by January 31 after year-end, when Form 5498 RMD reporting is due",
        history="RMD rows per account and distribution year kept 7 years (IRS Form 5498 RMD reporting; SEC Rule 17a-4), daily shortfall snapshots kept for the year plus 2 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "CRM embed", "Dashboard", "API"],
        dq_rules=[
            "Every RMD Account, Withholding Election Account, Designated Account and Instruction Account resolves to an open or recently closed DP-093 IRA account, every owner to a DP-240 party, and every Distribution Election Membership to a DP-094 participant plan membership.",
            "One RMD Record per account and distribution year, Retirement Distribution Election periods of one account and type do not overlap, and every effective-to date is on or after its start.",
            "Prior Year-End Fair Market Value equals DP-300's Client Holdings Market Value plus client cash (DP-007 rule) for the account and date within USD 1, and RMD Calculation Variance is zero within USD 1 on every RMD account.",
            "RMD Required Amount, Distribution Period Divisor and RMD Status are populated on every RMD Record with RMD Status other than Not Yet Required, and Required Beginning Date on every IRA owned by a party who has reached the SECURE 2.0 applicable age (73 for owners born 1951 to 1959, 75 for owners born 1960 or later).",
            "Dates of birth are published as age only and never as dates; account-grain rows are visible only to account services, advisors covering the household and operations; the semantic model carries counts and amounts only.",
            "The shortfall list is refreshed daily by 7am ET from December 1 to December 31, and the closed year is never rewritten after January 31.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). Book of record: Client Holding (49) through DP-300 "
               "for the prior year-end value (CW-007); the 15 RMD Record Prior Year-End Value and RMD Satisfied Amount are Derived "
               "copies of 49 and 50 and are not read (the masters are read and compared). PII tier: financial. Boundaries: DP-093 "
               "publishes RMDs Outstanding (a count of open RMD records), which is not redefined; plan-side RMDs are the 16 RMD "
               "Calculation of the workplace products (DP-430 and the BWO wave). Backlog DP-470 Required Minimum Distribution "
               "Readiness folds in here, with its 16 Participant Distribution Election read (moved read). Objects of the "
               "candidate not read: 15 Education & Health Savings Account Detail (no CDE that bears on RMDs; 529 and HSA "
               "distributions are not RMDs; read by DP-093) and 49 Client Account Activity (distributions are taken from 50 Money "
               "Movement, the money movement book, and the activity postings are DP-300's). Tailoring lever: RMD service for every "
               "IRA with aggregation flagged (15 SME 6). Reference default: calculated per IRA, the owner's aggregation election "
               "recorded on RMD Aggregation Indicator. Tailoring lever: RMD applicable age. Reference default: the SECURE 2.0 ages, 73 for owners born 1951 to 1959 and 75 for owners born "
               "1960 or later (earlier births keep the age that applied to them). Tailoring lever: shortfall outreach start. Reference default: December 1. "
               "Taxonomy gap: 50 Money Movement has no distribution reason code that separates an RMD from another retirement "
               "distribution, so every settled retirement distribution in the year counts toward the RMD. Taxonomy gap: the 15 "
               "RMD Record has no notice-sent date for the IRS RMD statement. Drafting assumptions: Money Movement Type Retirement "
               "Distribution; IRA registration types; the 10% default withholding; "
               " 5-business-day raise window; USD 1 tolerance. Decisions: CW-007, CW-044, CW-213. WP1 "
               "new (CW-205): first specification; takes the DP-470 scope."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-332": dict(
        definition=("Every advisory program enrollment tested against the conditions of the SEC Rule 3a-4 safe harbor and the "
                    "advisory agreement: the annual contact that confirms the client's financial situation and profile, the "
                    "quarterly statement, the reasonable restrictions the client asked for (02) and how 46 implements each, and "
                    "the source recommendation behind the enrollment (45). Program management and supervision use it to show "
                    "that each account in a Rule 3a-4 program is individually managed. It owns no certified metric family."),
        business_questions=[
            "Which Rule 3a-4 program enrollments lack an annual contact in the last 12 months, or a quarterly statement for the last quarter?",
            "Which reasonable restrictions accepted from clients are not implemented as a 46 investment constraint, and how long does implementation take?",
            "Which enrollments rest on an investor profile older than a year or have no source recommendation on record?",
            "What share of active Rule 3a-4 enrollments meets every individualized-management condition at once?",
            "Why do enrollments terminate, by offering and reason?",
        ],
        grain="Program enrollment (15) x as-of date, for enrollments in offerings with Rule 3a-4 Program Indicator = Y, with the accepted reasonable restrictions (02 Client Restriction x enrollment) as companion rows; daily, quarterly snapshots locked",
        dimensions=["Program enrollment and service offering (DP-004)", "Client account (DP-093)", "Client and Client Household (DP-240)",
                    "Model portfolio (DP-304)", "Restriction category", "Constraint type and implementation rule (DP-304)",
                    "Enrollment termination reason", "Quarter end (DP-013)"],
        measures=[
            ("Active Rule 3a-4 Enrollments",
             "Count of Program Enrollment ID with Enrollment Status = Active on the as-of date whose Enrolled Service Offering is "
             "an 01 Service Offering with Rule 3a-4 Program Indicator = Y, by Offering Type, Discretion Type and Wrap Fee Program "
             "Indicator.",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                "Enrollment Status", "Enrollment Effective Date")
             + _u("01", "Service Offering", "Offering ID", "Offering Type", "Discretion Type", "Rule 3a-4 Program Indicator",
                  "Wrap Fee Program Indicator")),
            ("Annual Contact Overdue",
             "Active Rule 3a-4 Enrollments older than 12 months with no 45 Advice Review of Advice Review Type = Rule 3a-4 Annual "
             "Contact whose Reviewed Program Enrollments contains the enrollment and whose Review Held Date is within the 12 months "
             "before the as-of date; with the count where the last held contact has Profile Version Confirmed blank.",
             _u("45", "Advice Review", "Advice Review ID", "Reviewed Program Enrollments", "Advice Review Type", "Review Due Date",
                "Review Held Date", "Profile Version Confirmed", "Financial Situation Changed Indicator")
             + _u("15", "Program Enrollment", "Enrollment Effective Date")
             + ["Active Rule 3a-4 Enrollments"]),
            ("Quarterly Statement Missing",
             "Active Rule 3a-4 Enrollments open at the last quarter end with no 13 Investor Document for the Enrolled Account of a "
             "Periodic Statement definition (Investor Document Category = Periodic Statement) with Period End Date = that quarter "
             "end and Delivered Date within 30 days after it, or with Delivery Status in (Returned Undeliverable, Failed).",
             _u("13", "Investor Document", "Investor Document ID", "Document Definition", "Document Account", "Period End Date",
                "Delivery Status", "Delivered Date")
             + _u("13", "Investor Document Definition", "Document Definition Code", "Investor Document Category", "Statement Type")
             + ["Active Rule 3a-4 Enrollments"]),
            ("Reasonable Restrictions Accepted",
             "Count of 02 Client Restriction rows with Rule 3a-4 Reasonable Restriction Indicator = Y and Restriction Status = "
             "Active in effect (Restriction Effective From / To) referenced in the Reasonable Restrictions of an Active Rule 3a-4 "
             "Enrollment, by Restriction Category.",
             _u("02", "Client Restriction", "Client Restriction ID", "Restricted Party", "Restricted Accounts",
                "Restriction Category", "Rule 3a-4 Reasonable Restriction Indicator", "Restriction Status",
                "Restriction Effective From", "Restriction Effective To")
             + _u("15", "Program Enrollment", "Reasonable Restrictions")
             + ["Active Rule 3a-4 Enrollments"]),
            ("Restrictions Not Implemented",
             "Reasonable Restrictions Accepted for which no 46 Account Investment Constraint on the Enrolled Account has Source "
             "Client Restriction = Client Restriction ID, Constraint Status = Active and Constraint Effective From on or before the "
             "as-of date; with the count older than 5 business days.",
             _u("46", "Account Investment Constraint", "Constrained Account", "Source Client Restriction", "Constraint Type",
                "Implementation Rule", "Constraint Status", "Constraint Effective From", "Constraint Effective To")
             + ["Reasonable Restrictions Accepted"]),
            ("Restriction Implementation Days",
             "Median business days from Restriction Effective From to the Constraint Effective From of the first active 46 "
             "constraint sourced from it, for restrictions accepted in the period, by Constraint Type.",
             _u("02", "Client Restriction", "Restriction Effective From")
             + _u("46", "Account Investment Constraint", "Source Client Restriction", "Constraint Effective From", "Constraint Type")),
            ("Constraints Without Accepted Restriction",
             "Active 46 Account Investment Constraints on Rule 3a-4 accounts whose Source Client Restriction resolves to a Client "
             "Restriction that is no longer Active or is not in the enrollment's Reasonable Restrictions: constraints that outlive "
             "the client's instruction.",
             _u("46", "Account Investment Constraint", "Source Client Restriction", "Constraint Status")
             + _u("02", "Client Restriction", "Restriction Status")
             + _u("15", "Program Enrollment", "Reasonable Restrictions")),
            ("Stale Profile Enrollments",
             "Active Rule 3a-4 Enrollments whose owner's latest 02 Investor Profile with Profile Status = Active has Attested Date "
             "more than 12 months before the as-of date.",
             _u("02", "Investor Profile", "Investor Profile ID", "Profile Client", "Attested Date", "Profile Status")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account")
             + ["Active Rule 3a-4 Enrollments"]),
            ("Enrollments Without Source Recommendation",
             "Enrollments with Enrollment Effective Date in the period whose Source Recommendation is blank, or resolves to a 45 "
             "Recommendation of Recommendation Type other than Program Enrollment or Client Decision not in (Accepted, Accepted "
             "with Changes).",
             _u("15", "Program Enrollment", "Source Recommendation", "Enrollment Effective Date")
             + _u("45", "Recommendation", "Recommendation ID", "Recommendation Type", "Client Decision")),
            ("Enrollments Without Model Implementation",
             "Active Rule 3a-4 Enrollments of offerings with Discretion Type other than Non-Discretionary for which no 46 Model "
             "Assignment with Assignment Program Enrollment = Program Enrollment ID is Active, and enrollments whose active "
             "assignment has Discretion Exercised = Non-Discretionary while Discretionary Authority Indicator = Y.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assignment Program Enrollment", "Discretion Exercised",
                "Assignment Status", "Assignment Effective From", "Assignment Effective To")
             + _u("15", "Program Enrollment", "Discretionary Authority Indicator")
             + ["Active Rule 3a-4 Enrollments"]),
            ("Individualized Management Evidence Complete %",
             "Active Rule 3a-4 Enrollments with none of Annual Contact Overdue, Quarterly Statement Missing, Restrictions Not "
             "Implemented, Stale Profile Enrollments or an unsigned advisory agreement (Advisory Agreement not resolving to an "
             "Account Agreement of Account Agreement Type = Investment Advisory Agreement with Agreement Signed Date populated and "
             "Agreement Status active) / Active Rule 3a-4 Enrollments.",
             _u("15", "Program Enrollment", "Advisory Agreement")
             + _u("15", "Account Agreement", "Account Agreement ID", "Agreement Account", "Account Agreement Type",
                  "Agreement Signed Date", "Agreement Status")
             + ["Active Rule 3a-4 Enrollments", "Annual Contact Overdue", "Quarterly Statement Missing",
                "Restrictions Not Implemented", "Stale Profile Enrollments"]),
            ("Enrollment Terminations",
             "Count of enrollments with Enrollment Termination Date in the period, by Enrollment Termination Reason and Enrolled "
             "Service Offering, with the share terminated within 12 months of Enrollment Effective Date.",
             _u("15", "Program Enrollment", "Enrollment Termination Date", "Enrollment Termination Reason",
                "Enrollment Effective Date", "Enrolled Service Offering")),
            ("Linked-Account Enrollments",
             "Active Rule 3a-4 Enrollments whose Enrolled Account is the Child Account of an Account Hierarchy Link in effect, by "
             "Account Link Type: accounts managed together under one enrollment decision.",
             _u("15", "Account Hierarchy Link", "Parent Account", "Child Account", "Account Link Type", "Link Effective From",
                "Link Effective To")
             + ["Active Rule 3a-4 Enrollments"]),
        ],
        inputs=[
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                                          "Enrollment Status", "Enrollment Effective Date", "Enrollment Termination Date",
                                          "Enrollment Termination Reason", "Source Recommendation",
                                          "Discretionary Authority Indicator", "Advisory Agreement", "Reasonable Restrictions"]),
            ("15", "Account Agreement", ["Account Agreement ID", "Agreement Account", "Account Agreement Type", "Agreement Version",
                                         "Agreement Signed Date", "Agreement Status"]),
            ("15", "Account Hierarchy Link", ["Parent Account", "Child Account", "Account Link Type", "Link Effective From",
                                              "Link Effective To"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account"]),
            ("45", "Advice Review", ["Advice Review ID", "Reviewed Program Enrollments", "Advice Review Type", "Review Due Date",
                                     "Review Held Date", "Profile Version Confirmed", "Financial Situation Changed Indicator"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Client Decision"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Program Enrollment",
                                        "Discretion Exercised", "Assignment Status", "Assignment Effective From",
                                        "Assignment Effective To"]),
            ("46", "Account Investment Constraint", ["Constrained Account", "Source Client Restriction", "Constraint Type",
                                                     "Implementation Rule", "Constraint Status", "Constraint Effective From",
                                                     "Constraint Effective To"]),
            ("02", "Client Restriction", ["Client Restriction ID", "Restricted Party", "Restricted Accounts", "Restriction Category",
                                          "Rule 3a-4 Reasonable Restriction Indicator", "Restriction Status",
                                          "Restriction Effective From", "Restriction Effective To"]),
            ("02", "Investor Profile", ["Investor Profile ID", "Profile Client", "Attested Date", "Profile Status"]),
            ("13", "Investor Document", ["Investor Document ID", "Document Definition", "Document Account", "Period End Date",
                                         "Delivery Status", "Delivered Date"]),
            ("13", "Investor Document Definition", ["Document Definition Code", "Investor Document Category", "Statement Type"]),
            ("01", "Service Offering", ["Offering ID", "Offering Name", "Offering Type", "Discretion Type",
                                        "Rule 3a-4 Program Indicator", "Wrap Fee Program Indicator"]),
        ],
        upstream=["DP-093", "DP-304", "DP-303", "DP-004", "DP-240", "DP-382", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; the quarterly evidence snapshot locked on business day 35 after each quarter end, after statements are delivered",
        history="Daily enrollment flags SCD type 2 and quarterly snapshots kept 6 years (Advisers Act Rule 204-2; Rule 3a-4 program records)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Enrolled Account resolves to an open DP-093 account, every Enrolled Service Offering to a DP-004 offering, every Reasonable Restrictions value to an 02 Client Restriction of the account's owner, and every Source Recommendation to a DP-303 recommendation.",
            "An account has at most one Active enrollment per offering, Account Investment Constraint periods sourced from one restriction do not overlap, and termination and effective-to dates are on or after their starts.",
            "Active Rule 3a-4 Enrollments reconciles to DP-093 Active Program Enrollments restricted to the Rule 3a-4 offerings, and the annual contacts counted equal DP-303's Rule 3a-4 Annual Contact reviews for the same window.",
            "Enrollment Status, Enrollment Effective Date and Advisory Agreement are populated on every active enrollment, and Rule 3a-4 Reasonable Restriction Indicator and Restriction Status on every restriction referenced by one.",
            "Account-grain rows are visible only to managed account operations, advice supervision and compliance; the semantic model carries counts by offering only; restriction descriptions are not read.",
            "The quarterly snapshot is locked on business day 35 after quarter end and never rewritten; later evidence is shown as late, not back-filled.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: financial. Boundaries: 15 records which "
               "restrictions the client asked for and the enrollment accepted, 46 how each is implemented (46 Source_Notes); "
               "DP-093 publishes Active Program Enrollments and Enrollments Without Active Advisory Agreement, DP-303 Rule 3a-4 "
               "Annual Contacts On Time % and Reviews Without Profile Confirmation, DP-304 Active Enrollments Without Model "
               "Assignment and Discretion Mismatch Assignments; none is redefined, and this product combines them per enrollment. "
               "The 15 Program Enrollment Rule 3a-4 Annual Contact Date is a Derived copy of 45 and is not read; the 45 Advice "
               "Review is read instead. Billing of the enrollments is DP-346's. Objects of the candidate: all read (01 Service "
               "Offering for the Rule 3a-4 Program Indicator, the relationship the filter needs). Tailoring lever: enrollment per "
               "account or per household (15 SME 1). Reference default: per account, with linked accounts shown through Account "
               "Hierarchy Link. Tailoring lever: whether the Rule 3a-4 annual contact creates a profile version (02 SME 3). "
               "Reference default: it confirms or creates one. Taxonomy gap: 15 Program Enrollment has no record of the quarterly "
               "notice that the client may contact the sponsor (Rule 3a-4(a)(2)(iii)); the quarterly statement is used as the "
               "nearest evidence. Drafting assumptions: Enrollment Status Active; Restriction Status and Constraint Status Active; "
               "12-month contact and profile windows; 30-day statement window; 5 business days to implement; business day 35 lock. "
               "Decisions: CW-008, CW-044, CW-047, CW-205. WP1 new (lead ruling 2026-10-15, pulled back from the backlog for Rule "
               "3a-4): first specification."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-333": dict(
        definition=("The advice funnel, from the first advice touch to an advised relationship: referrals into an advice channel "
                    "(03) and leads handed off to advice (04), advice engagements opened (45), plans presented and accepted, "
                    "program recommendations accepted, program enrollments (15) and the assets enrolled, by channel, advisor, "
                    "offering and engagement type, with Advised Assets and Net New Assets read from DP-008. Advice leadership "
                    "uses it to see where prospects and clients drop out and which channels convert. Its funnel starts where "
                    "DP-392's acquisition funnel hands off. It owns no certified metric family."),
        business_questions=[
            "How many referrals and leads entered the advice funnel this period, from which channels, and how many became advice engagements?",
            "Of the engagements opened, how many reached a presented plan, an accepted plan and an enrollment, and where do they drop out?",
            "How long does it take to go from referral to enrollment, by advisor and engagement type?",
            "What assets were enrolled into advice programs, and how do they compare with each advisor's Advised Assets and Net New Assets from DP-008?",
            "Which advisors accept new clients, and how does their conversion compare?",
        ],
        grain=("Funnel entry (03 channel referral to an advice channel, or 04 lead whose converted party opened an engagement) x "
               "stage reached, with the advice engagement, plan version, program recommendation and program enrollment as stage "
               "facts; cohorts by entry month; daily refresh, month-end snapshots"),
        dimensions=["Referral source and target channel", "Lead type and source", "Engagement type, capacity and delivery channel (DP-303)",
                    "Advisor (DP-009)", "Service offering (DP-004)", "Client and Client Household (DP-240)", "Funnel stage",
                    "Entry cohort month and stage date (DP-013)"],
        measures=[
            ("Advice Referrals",
             "Count of 03 Channel Referral ID with Referral Date in the period and Referral Target Channel in (Digital Advice, "
             "Human Advice, Trust Company), by Referral Source Channel and Target Advisor.",
             _u("03", "Channel Referral", "Referral ID", "Referral Date", "Referred Party", "Referral Source Channel",
                "Referral Target Channel", "Target Advisor")),
            ("Leads Handed Off to Advice",
             "Count of 04 Marketing Lead rows with Lead Type in (Advice Prospect, Trust & Estate Prospect) whose Lead Conversion "
             "Converted Party is the Engagement Client of an Advice Engagement with Engagement Start Date within 90 days after the "
             "Conversion Timestamp: the hand-off point from DP-392's acquisition funnel, by Lead Source.",
             _u("04", "Marketing Lead", "Lead ID", "Lead Type", "Lead Party", "Lead Source")
             + _u("04", "Lead Conversion", "Conversion Outcome", "Converted Party", "Conversion Timestamp")
             + _u("45", "Advice Engagement", "Engagement Client", "Engagement Start Date")),
            ("Referral to Engagement Rate",
             "Advice Referrals of the entry cohort whose Resulting Advice Engagement is populated (or whose Referral Status reached "
             "Converted) / Advice Referrals of the cohort.",
             _u("03", "Channel Referral", "Resulting Advice Engagement", "Referral Status") + ["Advice Referrals"]),
            ("Advice Engagements Opened",
             "Count of Advice Engagement ID with Engagement Start Date in the period, by Engagement Type, Engagement Advice "
             "Capacity, Engagement Delivery Channel, Engagement Advisor and Engagement Service Offering.",
             _u("45", "Advice Engagement", "Advice Engagement ID", "Engagement Type", "Engagement Advice Capacity",
                "Engagement Delivery Channel", "Engagement Advisor", "Engagement Service Offering", "Engagement Start Date")),
            ("Engagement to Plan Presented Rate",
             "Engagements of the cohort with a Client Financial Plan (Plan Engagement = Advice Engagement ID) whose version has "
             "Plan Presented Date within 90 days of Engagement Start Date / Advice Engagements Opened in the cohort; engagements of "
             "Engagement Type Brokerage Recommendations excluded.",
             _u("45", "Client Financial Plan", "Client Financial Plan ID", "Plan Engagement")
             + _u("45", "Client Financial Plan Version", "Versioned Plan", "Plan Presented Date")
             + _u("45", "Advice Engagement", "Engagement Type", "Engagement Start Date")
             + ["Advice Engagements Opened"]),
            ("Plan Acceptance Rate",
             "Client Financial Plan Versions presented in the period with Plan Accepted Date populated (Client Financial Plan "
             "Version Status = Accepted) / versions presented in the period, by the Engagement Type of the plan's engagement "
             "(Versioned Plan to Client Financial Plan Plan Engagement to Advice Engagement).",
             _u("45", "Client Financial Plan Version", "Client Financial Plan Version ID", "Versioned Plan",
                "Client Financial Plan Version Status", "Plan Presented Date", "Plan Accepted Date")
             + _u("45", "Client Financial Plan", "Client Financial Plan ID", "Plan Engagement")
             + _u("45", "Advice Engagement", "Advice Engagement ID", "Engagement Type")),
            ("Program Recommendations Accepted",
             "Count of 45 Recommendation rows with Recommendation Type = Program Enrollment, Recommendation Engagement populated "
             "and Client Decision in (Accepted, Accepted with Changes) with Client Decision Date in the period, by Recommended "
             "Service Offering, with the sum of Recommended Amount.",
             _u("45", "Recommendation", "Recommendation ID", "Recommendation Type", "Recommendation Engagement",
                "Recommended Service Offering", "Client Decision", "Client Decision Date", "Recommended Amount")),
            ("Days Accepted to Enrolled",
             "Median days from Client Decision Date to Implementation Date of the Recommendation Implementation Link with "
             "Implementing Record Type = Program Enrollment, over Program Recommendations Accepted that were implemented.",
             _u("45", "Recommendation Implementation Link", "Implemented Recommendation", "Implementing Record Type",
                "Implementing Enrollment", "Implementation Date")
             + _u("45", "Recommendation", "Client Decision Date")
             + ["Program Recommendations Accepted"]),
            ("Enrollments From Advice",
             "Count of 15 Program Enrollment ID with Enrollment Effective Date in the period and Source Recommendation populated, "
             "by Enrolled Service Offering, with the share of all new enrollments.",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                "Enrollment Effective Date", "Source Recommendation")),
            ("Assets Enrolled",
             "Sum of Summary Market Value of the DP-007 06 Account Asset Summary rows of the Enrolled Accounts of Enrollments From "
             "Advice at the end of the enrollment month (USD): operational enrolled assets, not Advised Assets.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Market Value")
             + ["Enrollments From Advice"]),
            ("Advised Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of the 06 Measure Value of Measure = MSR-ADVISEDASSETS, Dimension Type = "
             "Advisor, Dimension Key = the advisor, at the period end of the latest Final or Restated snapshot.",
             _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot")
             + _u("06", "Client Asset Measures", "Advised Assets")),
            ("Net New Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of Measure = MSR-NNA, Dimension Type = Advisor, for the period, shown beside "
             "the advisor's funnel; never recomputed from enrollments.",
             _u("06", "Measure Value", "Measure", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot")
             + _u("06", "Client Asset Measures", "Net New Assets")),
            ("End-to-End Conversion Rate",
             "Advice Referrals and Leads Handed Off to Advice of the entry cohort that reached an Enrollments From Advice row for "
             "the same party within 180 days / the cohort.",
             ["Advice Referrals", "Leads Handed Off to Advice", "Enrollments From Advice"]),
            ("Days Referral to Enrollment",
             "Median days from Referral Date (or Conversion Timestamp) to Enrollment Effective Date over the entries that enrolled, "
             "by Engagement Type and advisor.",
             _u("03", "Channel Referral", "Referral Date")
             + _u("04", "Lead Conversion", "Conversion Timestamp")
             + _u("15", "Program Enrollment", "Enrollment Effective Date")),
            ("Engagements Ended Without Enrollment",
             "Advice Engagements with Engagement Status = Ended and Engagement End Date in the period that produced no accepted "
             "program recommendation, by the last stage reached (engagement, plan presented, plan accepted) and Engagement Type.",
             _u("45", "Advice Engagement", "Engagement Status", "Engagement End Date")
             + ["Program Recommendations Accepted", "Plan Acceptance Rate"]),
            ("Advisors Accepting New Clients",
             "Count of 03 Advisor rows with Advisor Status active and Accepting New Clients Indicator = Y, with their Advice "
             "Engagements Opened in the period.",
             _u("03", "Advisor", "Employee", "Advisor Status", "Accepting New Clients Indicator")
             + ["Advice Engagements Opened"]),
        ],
        inputs=[
            ("45", "Advice Engagement", ["Advice Engagement ID", "Engagement Client", "Engagement Type", "Engagement Advice Capacity",
                                         "Engagement Delivery Channel", "Engagement Advisor", "Engagement Service Offering",
                                         "Engagement Business Line", "Engagement Status", "Engagement Start Date",
                                         "Engagement End Date"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommendation Engagement",
                                      "Recommended Client", "Recommended Service Offering", "Recommendation Presented Timestamp",
                                      "Client Decision", "Client Decision Date", "Recommended Amount"]),
            ("45", "Recommendation Implementation Link", ["Implemented Recommendation", "Implementing Record Type",
                                                          "Implementing Enrollment", "Implementation Date"]),
            ("45", "Client Financial Plan", ["Client Financial Plan ID", "Plan Engagement"]),
            ("45", "Client Financial Plan Version", ["Client Financial Plan Version ID", "Versioned Plan",
                                                     "Client Financial Plan Version Status", "Plan Presented Date",
                                                     "Plan Accepted Date"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                                          "Enrollment Status", "Enrollment Effective Date", "Source Recommendation"]),
            ("04", "Marketing Lead", ["Lead ID", "Lead Type", "Lead Party", "Lead Source", "Original Campaign"]),
            ("04", "Lead Conversion", ["Conversion Outcome", "Converted Party", "Conversion Timestamp"]),
            ("03", "Channel Referral", ["Referral ID", "Referral Date", "Referred Party", "Referral Source Channel",
                                        "Referral Target Channel", "Target Advisor", "Referral Status",
                                        "Resulting Advice Engagement", "Resulting Program Enrollment", "Resulting Marketing Lead"]),
            ("03", "Advisor", ["Employee", "Advisor Status", "Accepting New Clients Indicator"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Market Value"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Snapshot"]),
            ("06", "Client Asset Measures", ["Advised Assets", "Net New Assets"]),
        ],
        upstream=["DP-303", "DP-240", "DP-093", "DP-004", "DP-007", "DP-008", "DP-009", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET on T+1; month-end cohort snapshot on business day 5 after the DP-008 snapshot locks",
        history="Month-end cohort snapshots kept 7 years; daily stage facts kept 3 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["BI semantic model", "Dashboard", "Warehouse table"],
        dq_rules=[
            "Every Referred Party, Lead Party, Converted Party and Engagement Client resolves to a DP-240 party, every Target Advisor and Engagement Advisor to a DP-009 advisor, every Enrolled Account to DP-093 and every offering to DP-004.",
            "Each funnel entry is counted once per cohort: a party with both a referral and a lead in the same 90 days enters by the earlier, and stage dates are on or after the entry date.",
            "Advised Assets (from DP-008) and Net New Assets (from DP-008) equal DP-008's published Measure Amount for the same advisor, period and snapshot, and every Advice Engagements Opened row is a DP-303 Advice Engagement whose Engagement Start Date falls in the period (count equal to DP-303's engagements started in the period).",
            "Referral Date, Referral Target Channel and Referral Status are populated on every referral, Engagement Start Date and Engagement Advisor on every engagement, and Client Decision Date on every accepted recommendation.",
            "Party-level drill is visible only to advice leadership and the covering advisor; the semantic model carries counts and rates by channel, advisor, offering and cohort; captured lead names and emails are not read.",
            "Month-end cohorts are locked on business day 5 after the DP-008 snapshot of the month is Final, and a locked cohort is never rewritten.",
        ],
        notes=("Certified numbers: reads Advised Assets and Net New Assets from DP-008 by advisor (CW-011); owns none (It owns no "
               "certified metric family). Assets Enrolled is an operational value from DP-007 rows, never presented as Advised "
               "Assets or NNA. PII tier: financial (prospect and client keys). Hand-off with DP-392 (CLA-B, Acquisition Funnel & "
               "Account Opening Conversion): DP-392 owns the acquisition funnel from lead to funded account (lead capture, "
               "qualification, application journey, account opening and funding, promotions and referrals as acquisition "
               "sources); DP-333 owns the advice funnel from the first advice touch (a referral into an advice channel, or a lead "
               "of an advice type whose converted party opens an advice engagement) to program enrollment and enrolled assets. "
               "The boundary is the opening of the 45 Advice Engagement: DP-392 never publishes engagement, plan or enrollment "
               "rates and DP-333 never publishes lead qualification or account-opening rates; Leads Handed Off to Advice is the "
               "only measure that reads the 04 lead, and it counts the hand-off itself. Acceptance question 2 (NNA by advisor and "
               "campaign) resolves in DP-008, DP-491 and DP-492; this product shows the funnel behind it. Boundaries: DP-303 "
               "publishes Recommendation Acceptance Rate and Accepted Recommendations Implemented %, which are not redefined. "
               "Tailoring lever: self-directed-only firm. Reference default: advice offered; without it this product drops. "
               "Tailoring lever: funnel windows. Reference default: 90 days to plan, 180 days end to end. Taxonomy gap: 04 Lead "
               "Conversion has no link to an advice engagement, so the hand-off is matched by party and date. Drafting "
               "assumptions: advice Referral Target Channels; advice Lead Types; Advisor Status active; MSR-ADVISEDASSETS and "
               "MSR-NNA codes; the 90 and 180-day windows. Decisions: CW-011, CW-142, CW-205; framing ruling on the DP-333/DP-392 "
               "hand-off. WP1 new (CW-205): first specification; the plan section 8.3 Advice Funnel & Conversion example."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-337": dict(
        definition=("Each financial goal's progress: target and target date, the firm accounts and aggregated outside accounts "
                    "funding it, the funded ratio and on-track status of its latest progress snapshot, the probability of "
                    "success, projected shortfall and required saving of the accepted planning scenario, retirement-income and "
                    "education detail, the assumption set and plan version it rests on and the reviews due on its engagement, "
                    "with the funding accounts' personal rate of return read from DP-145. The digital experience shows it to "
                    "clients and advice leadership sees goal outcomes across the book; 45 never computes returns. It owns no "
                    "certified metric family."),
        business_questions=[
            "What share of active goals is on track, which moved off track since the last snapshot, and how far from funded are they?",
            "What is the probability of success and projected shortfall of the goals in accepted scenarios, and how much more saving would close it?",
            "How much of each goal is funded by firm accounts and by outside accounts, and which goals have no funding link at all?",
            "Which off-track goals sit on an engagement with an overdue review, a stale plan or an inactive assumption set?",
            "How do retirement-income goals compare projected income with desired income, and what personal return have their funding accounts earned?",
        ],
        grain=("Financial goal (45, FGOAL-) x snapshot as-of date, with the accepted scenario's goal projection result, funding "
               "links and plan goal inclusion as companions; daily snapshots from the planning engine, month-end kept"),
        dimensions=["Goal owner: client or Client Household (DP-240)", "Goal type and priority", "Advice engagement and advisor (DP-303, DP-009)",
                    "Funding account (DP-093)", "Planning scenario type and assumption set (DP-303, DP-530)", "Planning projection model and version (DP-212)", "Scenario run date", "On-track status",
                    "Snapshot as-of date (DP-013)"],
        measures=[
            ("Goals With Current Snapshot %",
             "Active Financial Goals (Goal Status = Active) with a Goal Progress Snapshot whose Snapshot As-Of Date is within 31 "
             "days of the as-of date / active goals, by Goal Type.",
             _u("45", "Financial Goal", "Financial Goal ID", "Goal Owner", "Goal Type", "Goal Status")
             + _u("45", "Goal Progress Snapshot", "Snapshot Goal", "Snapshot As-Of Date")),
            ("Goals On Track %",
             "Active goals whose latest Goal Progress Snapshot has On-Track Status = On Track / active goals with a latest snapshot "
             "other than Not Assessed, by Goal Type and Goal Priority.",
             _u("45", "Goal Progress Snapshot", "Snapshot Goal", "Snapshot As-Of Date", "On-Track Status")
             + _u("45", "Financial Goal", "Goal Type", "Goal Priority", "Goal Status")),
            ("Goals Moved Off Track",
             "Active goals whose latest snapshot has On-Track Status in (At Risk, Off Track) and whose previous snapshot was On "
             "Track, in the period.",
             _u("45", "Goal Progress Snapshot", "Snapshot Goal", "Snapshot As-Of Date", "On-Track Status")),
            ("Target-Weighted Funded Ratio",
             "Sum of Goal Funded Ratio x Goal Target Amount / sum of Goal Target Amount over active goals with a latest snapshot, "
             "by Goal Type (USD as recorded).",
             _u("45", "Goal Progress Snapshot", "Goal Funded Ratio")
             + _u("45", "Financial Goal", "Goal Target Amount")),
            ("Median Probability of Success",
             "Median Probability of Success of the Goal Projection Result rows (Result Goal) of each goal's latest Planning "
             "Scenario with Accepted Scenario Indicator = Y, by Goal Type and Projection Method; a forecast of the planning "
             "projection model named by the scenario's Projection Engine (a 37 Model Inventory Entry: Model ID, Model Version, "
             "Model Name, from DP-212), with Scenario Run Timestamp as the run-date dimension (CD-294).",
             _u("45", "Goal Projection Result", "Result Scenario", "Result Goal", "Probability of Success")
             + _u("45", "Planning Scenario", "Planning Scenario ID", "Scenario Plan Version", "Accepted Scenario Indicator",
                  "Projection Method", "Projection Engine", "Scenario Run Timestamp")
             + _u("37", "Model Inventory Entry", "Model ID", "Model Version", "Model Name", "Model Type")),
            ("Projected Shortfall",
             "Sum of Projected Shortfall Amount and of Required Additional Annual Saving of the accepted-scenario Goal Projection "
             "Results of active goals, with the Tenth Percentile Projected Outcome against Goal Target Amount; a forecast of the "
             "same planning projection model and run as Median Probability of Success (CD-294).",
             _u("45", "Goal Projection Result", "Result Scenario", "Projected Shortfall Amount", "Required Additional Annual Saving",
                "Median Projected Outcome", "Tenth Percentile Projected Outcome")
             + _u("45", "Planning Scenario", "Projection Engine", "Scenario Run Timestamp")
             + _u("37", "Model Inventory Entry", "Model ID", "Model Version")
             + _u("45", "Financial Goal", "Goal Target Amount")),
            ("Firm Assets Funding Goals",
             "Per goal: sum over Goal Funding Link rows in effect (Funding Effective From / To) with Funding Account populated of "
             "the account's Summary Market Value on the as-of date (DP-007 06 Account Asset Summary) x Funding Allocation "
             "Percentage (USD).",
             _u("45", "Goal Funding Link", "Funded Goal", "Funding Account", "Funding Allocation Percentage",
                "Funding Effective From", "Funding Effective To")
             + _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Market Value")),
            ("Outside Assets Funding Goals",
             "Per goal: sum over Goal Funding Link rows in effect with Funding Aggregated Account populated of the latest "
             "Aggregated Balance Amount x Funding Allocation Percentage (USD); never Client Assets.",
             _u("45", "Goal Funding Link", "Funding Aggregated Account", "Funding Allocation Percentage")
             + _u("45", "Aggregated Account Balance", "Balance Aggregated Account", "Balance As-Of Date",
                  "Aggregated Balance Amount")),
            ("Goals Without Funding Link",
             "Active goals of Goal Type other than Debt Payoff with no Goal Funding Link in effect, and goals with Planned "
             "Contribution Amount blank on every link.",
             _u("45", "Goal Funding Link", "Funded Goal", "Planned Contribution Amount", "Planned Contribution Frequency",
                "Funding Effective From", "Funding Effective To")
             + _u("45", "Financial Goal", "Goal Type", "Goal Status")),
            ("Retirement Income Replacement %",
             "For Retirement Income goals: Projected Income of the accepted scenario's Projection Year Result in the first year in "
             "which Primary Client Age in Year reaches Planned Retirement Age / Desired Annual Retirement Income, with the count "
             "below 80%.",
             _u("45", "Projection Year Result", "Year Result Scenario", "Projection Year", "Primary Client Age in Year",
                "Projected Income", "Projected Spending")
             + _u("45", "Retirement Income Goal Detail", "Retiring Party", "Planned Retirement Age",
                  "Desired Annual Retirement Income")),
            ("Education Funding Gap",
             "For Education goals: Annual Education Cost x Years of Education x Percentage of Cost to Fund minus Firm Assets "
             "Funding Goals and Outside Assets Funding Goals, by Education Start Year (undiscounted, USD).",
             _u("45", "Education Goal Detail", "Student", "Education Start Year", "Years of Education", "Annual Education Cost",
                "Percentage of Cost to Fund")
             + ["Firm Assets Funding Goals", "Outside Assets Funding Goals"]),
            ("Goals on Stale Plan or Assumptions",
             "Active goals included (Plan Goal Inclusion, Included Goal) in the latest accepted Client Financial Plan Version whose "
             "Plan Data As-Of Date is more than 12 months old, or whose Version Assumption Set resolves to a Planning Assumption "
             "Set with Assumption Set Status other than Active or not effective on the as-of date.",
             _u("45", "Plan Goal Inclusion", "Inclusion Plan Version", "Included Goal", "Version Goal Target Amount")
             + _u("45", "Client Financial Plan Version", "Client Financial Plan Version ID", "Client Financial Plan Version Status",
                  "Plan Data As-Of Date", "Version Assumption Set", "Plan Accepted Date")
             + _u("45", "Planning Assumption Set", "Assumption Set Code", "Capital Market Assumption Set", "Assumption Set Status",
                  "Assumption Set Effective From", "Assumption Set Effective To")),
            ("Off-Track Goals With Overdue Review",
             "Goals counted in Goals Moved Off Track or with latest On-Track Status = Off Track whose Goal Source Engagement has an "
             "Advice Review (Reviewed Engagement) with Review Due Date before the as-of date and Review Held Date blank.",
             _u("45", "Financial Goal", "Goal Source Engagement")
             + _u("45", "Advice Review", "Advice Review ID", "Reviewed Engagement", "Advice Review Type", "Review Due Date",
                  "Review Held Date")
             + ["Goals Moved Off Track"]),
            ("Goal Target Changes",
             "Goals whose Version Goal Target Amount differs between the latest two accepted plan versions that include them, with "
             "the net change (USD).",
             _u("45", "Plan Goal Inclusion", "Included Goal", "Version Goal Target Amount", "Inclusion Plan Version")),
            ("Funding Account Personal Return (from DP-145)",
             "Certified (CW-011), read: Personal Return Value of the funding accounts (Personal Return Account = Funding Account; "
             "Personal Return Status in (Final, Restated), highest version) for the trailing 12 months, by Personal Return Method "
             "and Personal Return Fee Basis, shown beside the goal and never blended into a goal return here.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Account",
                "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Method",
                "Personal Return Fee Basis", "Personal Return Value", "Personal Return Status")
             + _u("45", "Goal Funding Link", "Funding Account")),
        ],
        inputs=[
            ("45", "Financial Goal", ["Financial Goal ID", "Goal Owner", "Goal Type", "Goal Priority", "Goal Target Amount",
                                      "Goal Target Date", "Goal Status", "Goal Source Engagement"]),
            ("45", "Goal Funding Link", ["Funded Goal", "Funding Account", "Funding Aggregated Account",
                                         "Funding Allocation Percentage", "Planned Contribution Amount",
                                         "Planned Contribution Frequency", "Funding Effective From", "Funding Effective To"]),
            ("45", "Retirement Income Goal Detail", ["Retiring Party", "Planned Retirement Age", "Desired Annual Retirement Income",
                                                     "Income Needed Through Age"]),
            ("45", "Education Goal Detail", ["Student", "Education Start Year", "Years of Education", "Annual Education Cost",
                                             "Percentage of Cost to Fund"]),
            ("45", "Goal Progress Snapshot", ["Snapshot Goal", "Snapshot As-Of Date", "Goal Funded Ratio",
                                              "Snapshot Probability of Success", "On-Track Status", "Snapshot Scenario"]),
            ("45", "Planning Scenario", ["Planning Scenario ID", "Scenario Plan Version", "Planning Scenario Type",
                                         "Scenario Assumption Set", "Projection Method", "Projection Engine", "Scenario Run Timestamp",
                                         "Accepted Scenario Indicator"]),
            ("45", "Goal Projection Result", ["Result Scenario", "Result Goal", "Probability of Success", "Median Projected Outcome",
                                              "Tenth Percentile Projected Outcome", "Projected Shortfall Amount",
                                              "Required Additional Annual Saving"]),
            ("45", "Projection Year Result", ["Year Result Scenario", "Projection Year", "Primary Client Age in Year",
                                              "Median Projected Portfolio Value", "Tenth Percentile Projected Portfolio Value",
                                              "Projected Income", "Projected Spending"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Name", "Model Type"]),
            ("45", "Planning Assumption Set", ["Assumption Set Code", "Capital Market Assumption Set", "General Inflation Rate",
                                               "Assumption Set Status", "Assumption Set Effective From",
                                               "Assumption Set Effective To"]),
            ("45", "Plan Goal Inclusion", ["Inclusion Plan Version", "Included Goal", "Version Goal Target Amount"]),
            ("45", "Client Financial Plan Version", ["Client Financial Plan Version ID", "Versioned Plan",
                                                     "Client Financial Plan Version Status", "Plan Data As-Of Date",
                                                     "Version Assumption Set", "Plan Accepted Date"]),
            ("45", "Advice Review", ["Advice Review ID", "Reviewed Engagement", "Advice Review Type", "Review Due Date",
                                     "Review Held Date", "Next Review Due Date"]),
            ("45", "Aggregated Account Balance", ["Balance Aggregated Account", "Balance As-Of Date", "Aggregated Balance Amount"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Market Value"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Account",
                                               "Personal Return Period Start Date", "Personal Return Period End Date",
                                               "Personal Return Method", "Personal Return Fee Basis", "Personal Return Value",
                                               "Personal Return Status"]),
        ],
        upstream=["DP-303", "DP-145", "DP-007", "DP-530", "DP-212", "DP-240", "DP-093", "DP-009", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET daily after the planning engine's overnight snapshot run; month-end view on business day 3",
        history="Daily goal snapshots kept 2 years and month-end snapshots for the life of the goal plus 6 years (Advisers Act Rule 204-2 advice records)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["API", "Dashboard", "BI semantic model", "Warehouse table"],
        dq_rules=[
            "Every Goal Owner resolves to a DP-240 party or Client Household, every Funding Account to a DP-093 account, every Goal Source Engagement to a DP-303 engagement and every Capital Market Assumption Set to a DP-530 CMA set.",
            "Goal Funding Link periods of one goal and funding source do not overlap, the Funding Allocation Percentage of one funding account across goals in effect does not exceed 100, and effective-to dates are on or after their starts.",
            "Each goal has at most one accepted scenario per plan version, Probability of Success and Snapshot Probability of Success lie between 0 and 1 and Goal Funded Ratio is zero or greater (both held as fractions), and Funding Account Personal Return (from DP-145) equals DP-145's published value for the account and period.",
            "Goal Target Amount, Goal Target Date and Goal Status are populated on every active goal, and Goal Funded Ratio and On-Track Status on every snapshot.",
            "45 Client Planning Assumptions longevity and healthcare-cost bases and Healthcare Expense cash flows are never read (CD-344); client-grain rows are visible only to the client (digital experience), the covering advisor and advice leadership; the semantic model carries rates and amounts by goal type.",
            "The daily snapshot is published by 7am ET and a published month-end snapshot is never rewritten; a re-run of the planning engine creates a new snapshot date.",
        ],
        notes=("Certified numbers: reads Personal Return Value from DP-145 (CW-011, CW-251); 45 never computes returns. It owns no "
               "certified metric family. Firm assets funding goals are operational values from DP-007 rows, never Client Assets "
               "restated; outside assets are never Client Assets (CW-024). The 45 Goal Progress Snapshot Firm Assets Assigned to "
               "Goal and Contributions to Date are Derived copies of 49 and 50 and are not read; the DP-007 summaries are read "
               "instead. PII tier: financial. Special-category planning bases excluded (45 SME 6; DQ5). Boundaries: DP-303 "
               "publishes Active Financial Goals, Active Goal Target Amount, Accepted Plans With Stale Data and Plan Versions on "
               "Inactive Assumptions, which are not redefined (this product works at goal grain). DP-320 shows goals off track per "
               "household. Backlog DP-336 Advice Review Cadence & Plan Currency folds in (45 Planning Assumption Set, moved read; "
               "Plan Goal Inclusion, Advice Review, plan versions); its other objects are read by DP-303 (Advice Engagement, Client "
               "Financial Plan), DP-332 (Program Enrollment) and DP-334 (Investor Profile). Backlog DP-339 Digital Advice Engine "
               "Outcomes merges into DP-385 (CLA-B); its Planning Assumption Set read is here. Acceptance question 9: feeds DP-145 "
               "and DP-532 with Funding Account Personal Return (from DP-145), the goal view of Personal Return Value. "
               "Forecasts: Median Probability of Success and Projected Shortfall come from the planning projection model "
               "inventoried in 37 (DP-212, CD-294); the run date is Scenario Run Timestamp. Tailoring lever: goals per client or per household (45 SME 1). Reference default: either; Goal "
               "Owner is a 02 party or PTY-HH-. Tailoring lever: health-based longevity in projections (45 SME 6). Reference "
               "default: not used. Taxonomy gap: 45 Goal Progress Snapshot has no link to the plan version whose scenario it used "
               "beyond Snapshot Scenario. Drafting assumptions: Goal Status Active; 31-day snapshot currency; 80% income "
               "replacement; 12-month plan data; Assumption Set Status Active. Decisions: CW-011, CW-024, CW-044, CW-251, CD-294, CD-344. "
               "WP1 new (CW-205): first specification; takes DP-336's plan-currency reads."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-341": dict(
        definition=("Every managed account's drift against its target: the latest drift assessment and asset-class lines (from "
                    "DP-304), the tolerance and override lines in force, the rebalance trigger rule of its program and model, the "
                    "rebalance decision taken or deferred, and, folded in from the trade-proposal backlog, the proposals, lot "
                    "selections, pre-trade exceptions and cash instructions that carry the decision to release. Managed account "
                    "operations works the accounts outside tolerance and evidences that each was rebalanced or deferred for a "
                    "recorded reason; it answers acceptance question 4 (first half). Values are 49 Client Holdings through "
                    "DP-300. It owns no certified metric family."),
        business_questions=[
            "Which managed accounts are outside drift tolerance today (acceptance question 4), by program, model and drift method, and how much money do they hold?",
            "How long have breached accounts been outside tolerance, and which breaches have no rebalance decision?",
            "Which rebalances were skipped or deferred, for what reason, and were the skips reviewed?",
            "Which trade proposals are blocked or overridden by pre-trade checks, and which cash instructions are past their required date?",
            "Does the breach flag on each assessment agree with the tolerance in force, and does every program and model have an active threshold rule?",
        ],
        grain=("Managed account (15) x latest drift assessment (DRFT-) per day, with drift assessment lines, rebalance events "
               "(ARBE-), trade proposals (TRPR-) with lot selections and exceptions, and cash instructions (CSHI-) as companion "
               "facts; daily, intraday on trigger events"),
        dimensions=["Client account (DP-093)", "Program and service offering (DP-004)", "Model portfolio and target set (DP-004, DP-530)",
                    "Drift method", "Asset class", "Rebalance trigger type and decision", "Rebalance skip reason",
                    "Pre-trade check type and exception outcome", "Cash instruction type", "Assessment date (DP-013)"],
        measures=[
            ("Managed Accounts Assessed",
             "Count of distinct Assigned Account of active 46 Model Assignments (Assignment Status = Active, Assignment Effective "
             "From <= date < Assignment Effective To or open) with a Drift Assessment (Assessed Account) whose Assessment Timestamp "
             "falls on the as-of date, by program and Drift Method.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assignment Program Enrollment",
                "Assigned Model Portfolio", "Assignment Status", "Assignment Effective From", "Assignment Effective To")
             + _u("46", "Drift Assessment", "Drift Assessment ID", "Assessed Account", "Assessment Timestamp", "Drift Method")),
            ("Accounts Outside Drift Tolerance",
             "Acceptance question 4 (first half): count of distinct Assessed Account of active assignments whose latest Drift "
             "Assessment on or before the as-of date has Tolerance Breached Indicator = Y, by Enrolled Service Offering, Assigned "
             "Model Portfolio and Drift Method, with the median Total Drift; an assessment counts only when it was run on the "
             "account's current End of Day 49 Client Holdings (Holdings As-Of Timestamp on or after the Client Holding As-Of "
             "Timestamp of the latest End of Day Client Holding of the account, from DP-300).",
             _u("46", "Drift Assessment", "Assessed Account", "Assessment Timestamp", "Total Drift", "Tolerance Breached Indicator",
                "Drift Method")
             + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Service Offering")
             + _u("46", "Drift Assessment", "Holdings As-Of Timestamp")
             + _u("49", "Client Holding", "Holding Account", "Client Holding Date", "Client Holding View",
                  "Client Holding As-Of Timestamp")
             + ["Managed Accounts Assessed"]),
            ("Market Value Outside Tolerance",
             "Market Value in USD of the End of Day 49 Client Holdings on the as-of date of the Accounts Outside Drift Tolerance "
             "(from DP-300).",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + ["Accounts Outside Drift Tolerance"]),
            ("Tolerance Flag Disagreements",
             "Latest assessments where Maximum Asset Class Drift or any Drift Assessment Line Line Drift (absolute) exceeds the "
             "Asset Class Drift Tolerance of the Managed Account Target in force (Assessed Account Target), or the Override "
             "Tolerance of an Account Target Override Line for that Line Asset Class or Line Instrument, while Tolerance Breached "
             "Indicator = N, and the reverse.",
             _u("46", "Drift Assessment", "Assessed Account Target", "Maximum Asset Class Drift", "Cash Drift",
                "Tolerance Breached Indicator")
             + _u("46", "Drift Assessment Line", "Line Drift Assessment", "Line Asset Class", "Line Instrument", "Line Drift")
             + _u("46", "Managed Account Target", "Target Model Assignment", "Account Target Version", "Asset Class Drift Tolerance",
                  "Account Cash Target", "Target Approval Status", "Target Effective From")
             + _u("46", "Account Target Override Line", "Override Account Target", "Override Asset Class", "Override Instrument",
                  "Override Tolerance")),
            ("Days Outside Tolerance",
             "For Accounts Outside Drift Tolerance: business days since the first of the consecutive assessments with Tolerance "
             "Breached Indicator = Y; the count above 5 business days by program.",
             _u("46", "Drift Assessment", "Assessment Timestamp", "Tolerance Breached Indicator")
             + ["Accounts Outside Drift Tolerance"]),
            ("Breaches Without Rebalance Decision",
             "Breached assessments older than 2 business days with no Account Rebalance Event whose Triggering Drift Assessment = "
             "Drift Assessment ID, and no later event for the account.",
             _u("46", "Account Rebalance Event", "Rebalance Event ID", "Rebalanced Account", "Triggering Drift Assessment",
                "Rebalance Event Timestamp")
             + _u("46", "Drift Assessment", "Drift Assessment ID", "Tolerance Breached Indicator", "Assessment Timestamp")),
            ("Rebalance Events by Trigger",
             "Count of Account Rebalance Event rows with Rebalance Event Timestamp in the period, by Event Trigger Type and "
             "Rebalance Decision, with the median Estimated Turnover.",
             _u("46", "Account Rebalance Event", "Rebalance Event ID", "Event Trigger Type", "Rebalance Decision",
                "Estimated Turnover", "Rebalance Event Timestamp")),
            ("Deferred Rebalances by Reason",
             "Rebalance events with Rebalance Decision in (Skip, Partial Rebalance, Cash Flow Only) on breached assessments, by "
             "Rebalance Skip Reason, with the count where Decision Reviewed By is blank.",
             _u("46", "Account Rebalance Event", "Rebalance Decision", "Rebalance Skip Reason", "Triggering Drift Assessment",
                "Decision Reviewed By")),
            ("Programs Without Threshold Rule",
             "Program and model combinations of active assignments with no 46 Rebalance Trigger Rule of Trigger Type = Threshold, "
             "Rule Status active and Rule Effective From / To spanning the as-of date (Rule Program and, where set, Rule Model "
             "Portfolio), with the Drift Threshold of the rules in force otherwise.",
             _u("46", "Rebalance Trigger Rule", "Rule Program", "Rule Model Portfolio", "Trigger Type", "Drift Threshold",
                "Evaluation Frequency", "Minimum Trade Amount", "Rule Status", "Rule Effective From", "Rule Effective To")
             + _u("46", "Model Assignment", "Assigned Model Portfolio")),
            ("Proposals Blocked or Overridden",
             "Count of 46 Trade Proposal Exception rows with Exception Raised Timestamp in the period by Pre-Trade Check Type and "
             "Exception Outcome, with the count Overridden and Override Approver blank.",
             _u("46", "Trade Proposal Exception", "Exception Trade Proposal", "Pre-Trade Check Type", "Exception Outcome",
                "Exception Raised Timestamp", "Override Approver")),
            ("Proposals Pending Past Cycle",
             "Trade Proposal rows with Proposal Status in (Proposed, Exception, Approved) whose Proposal Batch has Batch Cycle Date "
             "more than 1 business day before the as-of date, with the sum of Proposed Amount, by Batch Program and Proposal "
             "Side; proposals from a Source Rebalance Event counted separately.",
             _u("46", "Trade Proposal", "Trade Proposal ID", "Proposal Batch", "Proposal Account", "Proposal Instrument",
                "Proposal Side", "Proposed Amount", "Source Rebalance Event", "Source Cash Instruction", "Proposal Status",
                "Release Timestamp")
             + _u("46", "Trade Proposal Batch", "Batch ID", "Batch Program", "Batch Cycle Date", "Batch Status")),
            ("Lot Selections on Stale Lot Data",
             "Proposed Client Lot Selection rows of proposals released in the period whose Lot Data As-Of Timestamp is more than 1 "
             "business day before the batch's Batch Released Timestamp, with the sum of Estimated Lot Gain and of Quantity to "
             "Relieve.",
             _u("46", "Proposed Client Lot Selection", "Lot Selection Proposal", "Selected Client Tax Lot", "Quantity to Relieve",
                "Estimated Lot Gain", "Lot Data As-Of Timestamp")
             + _u("46", "Trade Proposal Batch", "Batch Released Timestamp")),
            ("Cash Instructions Past Required Date",
             "Managed Account Cash Instruction rows with Cash Instruction Status not in (Cash Available, Invested, Canceled) "
             "whose Required By Date is before the as-of date, by Cash Instruction Type, with the sum of Instruction Amount and "
             "the count with Proposals Generated Count = 0.",
             _u("46", "Managed Account Cash Instruction", "Cash Instruction ID", "Instruction Account", "Cash Instruction Type",
                "Instruction Amount", "Required By Date", "Cash Instruction Status", "Proposals Generated Count")),
            ("Assessments on Unapproved or Superseded Target",
             "Latest assessments whose Assessed Account Target is a Managed Account Target with Target Approval Status other than "
             "Approved, or not the latest Account Target Version effective on the assessment date.",
             _u("46", "Drift Assessment", "Assessed Account Target", "Assessment Timestamp")
             + _u("46", "Managed Account Target", "Account Target Version", "Target Approval Status", "Target Effective From",
                  "Applied Model Target Set", "Custom Target Indicator")),
        ],
        inputs=[
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Program Enrollment",
                                        "Assigned Model Portfolio", "Assignment Status", "Assignment Effective From",
                                        "Assignment Effective To"]),
            ("46", "Drift Assessment", ["Drift Assessment ID", "Assessed Account", "Assessed Account Target",
                                        "Assessment Timestamp", "Holdings As-Of Timestamp", "Total Drift",
                                        "Maximum Asset Class Drift", "Cash Drift", "Tolerance Breached Indicator", "Drift Method"]),
            ("46", "Drift Assessment Line", ["Line Drift Assessment", "Line Asset Class", "Line Instrument", "Line Drift"]),
            ("46", "Managed Account Target", ["Target Model Assignment", "Account Target Version", "Applied Model Target Set",
                                              "Custom Target Indicator", "Account Cash Target", "Asset Class Drift Tolerance",
                                              "Target Approval Status", "Target Effective From"]),
            ("46", "Account Target Override Line", ["Override Account Target", "Override Asset Class", "Override Instrument",
                                                    "Override Weight", "Override Tolerance", "Override Reason"]),
            ("46", "Rebalance Trigger Rule", ["Rule Program", "Rule Model Portfolio", "Trigger Type", "Drift Threshold",
                                              "Evaluation Frequency", "Minimum Trade Amount", "Rule Status",
                                              "Rule Effective From", "Rule Effective To"]),
            ("46", "Account Rebalance Event", ["Rebalance Event ID", "Rebalanced Account", "Event Trigger Type", "Triggering Rule",
                                               "Triggering Drift Assessment", "Applied Account Target", "Rebalance Decision",
                                               "Rebalance Skip Reason", "Estimated Turnover", "Rebalance Event Timestamp",
                                               "Event Proposal Batch", "Decision Reviewed By"]),
            ("46", "Trade Proposal Batch", ["Batch ID", "Batch Program", "Batch Cycle Date", "Batch Released Timestamp",
                                            "Batch Status"]),
            ("46", "Trade Proposal", ["Trade Proposal ID", "Proposal Batch", "Proposal Account", "Proposal Instrument",
                                      "Proposal Side", "Proposed Amount", "Source Rebalance Event", "Source Cash Instruction",
                                      "Proposal Status", "Release Timestamp"]),
            ("46", "Proposed Client Lot Selection", ["Lot Selection Proposal", "Selected Client Tax Lot", "Quantity to Relieve",
                                                     "Estimated Lot Gain", "Lot Data As-Of Timestamp"]),
            ("46", "Trade Proposal Exception", ["Exception Trade Proposal", "Pre-Trade Check Type", "Exception Outcome",
                                                "Exception Raised Timestamp", "Override Approver"]),
            ("46", "Managed Account Cash Instruction", ["Cash Instruction ID", "Instruction Account", "Cash Instruction Type",
                                                        "Instruction Amount", "Required By Date", "Cash Instruction Status",
                                                        "Proposals Generated Count"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Service Offering"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View",
                                      "Client Holding As-Of Timestamp"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
        ],
        upstream=["DP-304", "DP-300", "DP-093", "DP-004", "DP-530", "DP-097", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 after the overnight drift run, refreshed intraday after each trade proposal batch release",
        history="Daily snapshots of the latest assessment per account kept 2 years; rebalance events, proposals and exceptions kept 6 years (Advisers Act Rule 204-2 trading records)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "API"],
        dq_rules=[
            "Every Assessed Account, Rebalanced Account, Proposal Account and Instruction Account resolves to an open DP-093 account with an active DP-304 Model Assignment, every Applied Model Target Set to a DP-530 target set and every Proposal Instrument to DP-097.",
            "Each account has one latest Drift Assessment per day, Managed Account Target versions of one assignment do not overlap, and Rule Effective To is on or after Rule Effective From.",
            "Accounts Outside Drift Tolerance counts only assessments DP-304 publishes (Drift Assessment ID present there), and Market Value Outside Tolerance equals DP-300's Client Holdings Market Value for those accounts and date within USD 1.",
            "Total Drift, Tolerance Breached Indicator and Assessment Timestamp are populated on every assessment, Rebalance Decision on every rebalance event, and Exception Outcome on every trade proposal exception.",
            "Account-grain rows are visible only to managed account operations, advice and supervision; the semantic model carries counts and amounts by program, model and reason only.",
            "The daily view is published by 7am ET; released proposals and recorded assessments are immutable and a skipped breach stays listed until a later assessment clears it.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). Book of record: Client Holding (49) through DP-300 "
               "(CW-007); the 46 Drift Assessment Account Market Value and Drift Assessment Line Actual Weight are Derived copies "
               "of 49 and are not read. A retail managed account is a 15 account managed in 46, never an 18 portfolio. PII tier: "
               "financial. Boundaries: DP-304 publishes Drift Assessment, Trade Proposal Batch and Trade Proposal and the measures "
               "Accounts Without Current Drift Assessment, Drift Assessments on Stale Holdings, Trade Proposals Released and "
               "Released Proposals Without Execution Link, which are not redefined; this product decides on breaches. Proposals end "
               "at release to 48 (DP-301; CW-010). Drift reduction after rebalances and tax effects are DP-342's. Backlog DP-344 "
               "Trade Proposals, Cash Raises & Pre-Trade Exceptions folds in (moved reads: 46 Trade Proposal, Proposed Client Lot "
               "Selection, Trade Proposal Exception, Managed Account Cash Instruction); its 48 Client Order, 16 Participant "
               "Investment Transfer and 50 Money Movement reads stay with DP-301, DP-430 and DP-302. Objects of the candidate: 46 "
               "Sleeve Assignment is not read (sleeves share the account target, 46 SME 2; DP-345 reads them). Acceptance question 4 "
               "(plan section 8.5): answered by Accounts Outside Drift Tolerance (tested against the current 49 holdings) and "
               "Market Value Outside Tolerance, with Tolerance Flag Disagreements and Breaches Without Rebalance Decision; "
               "mastering domains 46, 49. Tailoring lever: drift cadence (46 SME 6). Reference "
               "default: daily for Digital Only offerings, on event with a 90-day backstop for advisor-led ones. Tailoring lever: "
               "breach decision window. Reference default: 2 business days, 5 business days outside tolerance escalated. "
               "Taxonomy gap: 46 Account Rebalance Event has no decision status for a deferral that is later reversed, so a "
               "deferred breach is cleared only by a later assessment. Drafting assumptions: Assignment Status and Rule Status "
               "active; Target Approval Status Approved; the 1, 2 and 5 business-day windows; USD 1 tolerance. Decisions: CW-007, "
               "CW-010, CW-047, CW-049, CW-205. WP1 new (CW-205): first specification; reads the drift and proposal facts from "
               "DP-304 per the WP1F ruling."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-342": dict(
        definition=("What rebalancing and tax management achieved for managed accounts: losses harvested and realized in the 49 "
                    "lots, the estimated tax saving read from DP-304 as 46 masters it, harvests skipped and why, wash sales "
                    "controlled or incurred across household managed groups and substantially identical security groups, gains "
                    "realized against each account's tax budget, asset location coverage, drift reduction after rebalances and "
                    "tax-aware model transitions, by program, model and household, with personal returns read from DP-145. It "
                    "answers acceptance question 4 (second half): what tax-loss harvesting saved clients and whether tax "
                    "management is worth its trading. It owns no certified metric family."),
        business_questions=[
            "What did tax-loss harvesting save clients this year (acceptance question 4), by program, model, tax saving method and household?",
            "How much loss was actually realized in the 49 lots against the loss seen at the scan, and which harvests were skipped and why?",
            "Were wash sales controlled: how many windows ended with a wash sale, and which purchases fell inside open windows in controlled or monitored accounts?",
            "Which accounts realized gains beyond their tax budget or short-term gains they asked to avoid?",
            "How much drift did rebalances remove, how much were tax-aware model transitions deferred, and what personal return did tax-managed accounts earn?",
        ],
        grain=("Tax-loss harvest decision (TLH-) x the 49 client lot reliefs it produced, with wash sale control windows, account "
               "tax budgets (account x tax year), asset location decisions and rebalance events as companions; daily, tax-year "
               "totals closed at year-end"),
        dimensions=["Client account (DP-093)", "Client Household and household managed group (DP-240, DP-304)",
                    "Program and model portfolio (DP-004)", "Harvest decision and skip reason", "Tax saving method",
                    "Holding period term", "Security sold and replacement (DP-097)", "Substantially identical security group",
                    "Tax year and scan date (DP-013)"],
        measures=[
            ("Harvest Rate %",
             "Tax-Loss Harvest Decision rows with Harvest Decision in (Harvest, Partial Harvest) / all decisions with Scan "
             "Timestamp in the period, by program and model (the Harvest Account's active 46 Model Assignment: Assigned Model "
             "Portfolio and Assignment Program Enrollment) and Harvest Loss Term.",
             _u("46", "Tax-Loss Harvest Decision", "Harvest Decision ID", "Harvest Account", "Scan Timestamp", "Harvest Decision",
                "Harvest Loss Term")
             + _u("46", "Model Assignment", "Assigned Account", "Assigned Model Portfolio", "Assignment Program Enrollment",
                  "Assignment Status", "Assignment Effective From", "Assignment Effective To")),
            ("Realized Harvested Losses",
             "Acceptance question 4: sum of Realized Gain or Loss (negative values) of the 49 Client Lot Relief rows whose Relieved "
             "Client Tax Lot is one of the Harvest Client Tax Lots of a harvest decision (Harvest or Partial Harvest) and whose "
             "Closing Activity has Trade Date within 3 business days after the Scan Timestamp, by Holding Period Term (USD; shown "
             "as a negative amount).",
             _u("46", "Tax-Loss Harvest Decision", "Harvest Client Tax Lots", "Harvest Decision", "Scan Timestamp")
             + _u("49", "Client Lot Relief", "Relieved Client Tax Lot", "Closing Activity", "Realized Gain or Loss",
                  "Holding Period Term")
             + _u("49", "Client Account Activity", "Client Account Activity ID", "Trade Date")),
            ("Estimated Tax Saving (from DP-304)",
             "Acceptance question 4: sum of Estimated Tax Saving of Tax-Loss Harvest Decision rows with Harvest Decision in "
             "(Harvest, Partial Harvest) and Scan Timestamp in the period, by Tax Saving Method, as DP-304 publishes it (Estimated "
             "Harvest Tax Saving); never recomputed from a tax rate here.",
             _u("46", "Tax-Loss Harvest Decision", "Estimated Tax Saving", "Tax Saving Method", "Harvest Decision", "Scan Timestamp")),
            ("Tax Saving per Dollar Harvested",
             "Estimated Tax Saving (from DP-304) / absolute Realized Harvested Losses, by Tax Saving Method and program.",
             ["Estimated Tax Saving (from DP-304)", "Realized Harvested Losses"]),
            ("Harvest Capture %",
             "Realized Harvested Losses / Unrealized Loss at Scan of the same harvest decisions: loss lost to price movement "
             "between scan and execution.",
             _u("46", "Tax-Loss Harvest Decision", "Unrealized Loss at Scan") + ["Realized Harvested Losses"]),
            ("Harvests Skipped by Reason",
             "Count and sum of Unrealized Loss at Scan of decisions with Harvest Decision = Skip, by Harvest Skip Reason, and the "
             "count skipped for Client Not Elected on accounts whose Tax Management Setting has Tax-Loss Harvesting Elected = Y.",
             _u("46", "Tax-Loss Harvest Decision", "Harvest Decision", "Harvest Skip Reason", "Unrealized Loss at Scan")
             + _u("46", "Tax Management Setting", "Tax-Loss Harvesting Elected", "Minimum Harvest Loss Amount",
                  "Tax Setting Effective From")),
            ("Wash Sales Incurred in Windows",
             "Count of Wash Sale Control Window rows with Window End Date in the period and Window Status = Wash Sale Incurred, "
             "with the sum of Wash Sale Loss Disallowed of the 49 Client Lot Relief rows of their Triggering Harvest Decision's "
             "lots, by Window Security Group.",
             _u("46", "Wash Sale Control Window", "Window Household", "Window Account", "Window Security Group",
                "Triggering Harvest Decision", "Window Start Date", "Window End Date", "Window Status")
             + _u("49", "Client Lot Relief", "Wash Sale Loss Disallowed", "Wash Sale Replacement Lot")),
            ("Purchases Inside Open Windows",
             "Count of posted 49 Client Account Activity rows with Activity Type in (Buy, Fund Purchase) in the Controlled Accounts "
             "in Scope or Monitored Accounts in Scope of a window, whose Activity Instrument is a Group Member Instrument of the "
             "Window Security Group in effect and whose Trade Date lies between Window Start Date and Window End Date; controlled "
             "accounts (expected zero) and monitored accounts shown separately.",
             _u("46", "Wash Sale Control Window", "Controlled Accounts in Scope", "Monitored Accounts in Scope", "Window Security Group",
                "Window Start Date", "Window End Date")
             + _u("46", "Substantially Identical Security Group", "Security Group Code", "Group Member Instrument",
                  "Member Effective From", "Member Effective To")
             + _u("49", "Client Account Activity", "Activity Account", "Activity Instrument", "Activity Type", "Trade Date",
                  "Activity Status")),
            ("Wash Sale Basis Adjustments",
             "Sum of Basis Adjustment Amount of 49 Cost Basis Adjustment rows with Basis Adjustment Type = Wash Sale and "
             "Adjustment Effective Date in the period on managed accounts, by Window Security Group of the open window: the basis "
             "deferred into replacement lots.",
             _u("49", "Cost Basis Adjustment", "Adjusted Client Tax Lot", "Basis Adjustment Type", "Basis Adjustment Amount",
                "Adjustment Effective Date")
             + _u("49", "Client Tax Lot", "Client Tax Lot ID", "Lot Account", "Lot Instrument", "Wash Sale Deferred Loss")),
            ("Unapproved Security Groups in Use",
             "Substantially Identical Security Groups referenced by open windows whose Group Policy Approval Status is not "
             "approved, by Security Group Basis.",
             _u("46", "Substantially Identical Security Group", "Security Group Basis", "Group Policy Approval Status")
             + _u("46", "Wash Sale Control Window", "Window Security Group", "Window Status")),
            ("Gains Realized Against Tax Budget %",
             "Per account and tax year: sum of Realized Gain or Loss of the account's 49 Client Lot Relief rows with Closing "
             "Activity Trade Date in the Budget Tax Year / Net Realized Gain Budget; the count of accounts above 100%, and of "
             "accounts above their Short-Term Gain Budget on Holding Period Term = Short-Term reliefs.",
             _u("46", "Account Tax Budget", "Budget Account", "Budget Tax Year", "Net Realized Gain Budget", "Short-Term Gain Budget",
                "Loss Harvesting Target")
             + _u("49", "Client Lot Relief", "Realized Gain or Loss", "Holding Period Term", "Closing Activity")
             + _u("49", "Client Account Activity", "Trade Date", "Activity Account")),
            ("Short-Term Gains in Avoidance Accounts",
             "Accounts whose Tax Management Setting has Short-Term Gain Avoidance Indicator = Y with a positive sum of Realized "
             "Gain or Loss on Holding Period Term = Short-Term reliefs in the tax year, with that sum.",
             _u("46", "Tax Management Setting", "Short-Term Gain Avoidance Indicator")
             + _u("49", "Client Lot Relief", "Realized Gain or Loss", "Holding Period Term")),
            ("Asset Location Coverage %",
             "Client Households with a Household Managed Group of Managed-Together Basis including Asset Location whose Asset "
             "Location Decision rows in effect have Placement Weight summing to 100% per Location Asset Class / such households, "
             "by Asset Location Basis.",
             _u("46", "Asset Location Decision", "Location Household", "Location Asset Class", "Location Account", "Placement Weight",
                "Asset Location Basis", "Location Effective From", "Location Effective To")
             + _u("46", "Household Managed Group", "Managed Group Household", "Group Member Account", "Managed-Together Basis",
                  "Group Membership Status", "Group Effective From", "Group Effective To")
             + _u("46", "Tax Management Setting", "Asset Location Enabled Indicator")),
            ("Drift Reduction After Rebalance",
             "Mean of Total Drift of the Triggering Drift Assessment minus Total Drift of the account's first Drift Assessment "
             "after the Rebalance Event Timestamp, over events with Rebalance Decision in (Rebalance, Partial Rebalance), with the "
             "mean Estimated Turnover and Estimated Realized Gain per event, by Event Trigger Type.",
             _u("46", "Account Rebalance Event", "Rebalance Event ID", "Rebalanced Account", "Event Trigger Type",
                "Triggering Drift Assessment", "Rebalance Decision", "Estimated Turnover", "Estimated Realized Gain",
                "Rebalance Event Timestamp")
             + _u("46", "Drift Assessment", "Drift Assessment ID", "Assessed Account", "Assessment Timestamp", "Total Drift")),
            ("Tax-Aware Transition Deferral %",
             "For Model Change Implementation rows with Tax-Aware Transition Indicator = Y and Implementation Window End in the "
             "period: Accounts Deferred Count / Accounts in Scope Count, by Changed Model Portfolio and Implementation Status.",
             _u("46", "Model Change Implementation", "Changed Model Portfolio", "From Target Set", "To Target Set",
                "Implementation Window Start", "Implementation Window End", "Tax-Aware Transition Indicator",
                "Accounts in Scope Count", "Accounts Deferred Count", "Implementation Status")),
            ("Personal Return of Tax-Managed Accounts (from DP-145)",
             "Certified (CW-011), read: median Personal Return Value (Personal Return Status in (Final, Restated), highest version, "
             "net of fees) of managed accounts with Tax-Loss Harvesting Elected = Y and of those without, by program and period; "
             "never computed here.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Account",
                "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Method",
                "Personal Return Fee Basis", "Personal Return Value", "Personal Return Status")
             + _u("46", "Tax Management Setting", "Tax-Loss Harvesting Elected")),
        ],
        inputs=[
            ("46", "Tax-Loss Harvest Decision", ["Harvest Decision ID", "Harvest Account", "Scan Timestamp", "Security Sold",
                                                 "Harvest Client Tax Lots", "Replacement Security", "Unrealized Loss at Scan",
                                                 "Harvest Loss Term", "Estimated Tax Saving", "Tax Saving Method",
                                                 "Harvest Decision", "Harvest Skip Reason", "Resulting Wash Sale Window"]),
            ("46", "Account Tax Budget", ["Budget Account", "Budget Tax Year", "Net Realized Gain Budget", "Short-Term Gain Budget",
                                          "Loss Harvesting Target"]),
            ("46", "Tax Management Setting", ["Tax-Loss Harvesting Elected", "Minimum Harvest Loss Amount",
                                              "Short-Term Gain Avoidance Indicator", "Asset Location Enabled Indicator",
                                              "Tax Setting Effective From"]),
            ("46", "Asset Location Decision", ["Location Household", "Location Asset Class", "Location Account", "Placement Weight",
                                               "Asset Location Basis", "Location Effective From", "Location Effective To"]),
            ("46", "Account Rebalance Event", ["Rebalance Event ID", "Rebalanced Account", "Event Trigger Type",
                                               "Triggering Drift Assessment", "Rebalance Decision", "Estimated Turnover",
                                               "Estimated Realized Gain", "Rebalance Event Timestamp"]),
            ("46", "Drift Assessment", ["Drift Assessment ID", "Assessed Account", "Assessment Timestamp", "Total Drift"]),
            ("46", "Household Managed Group", ["Managed Group Household", "Group Member Account", "Managed-Together Basis",
                                               "Group Membership Status", "Group Effective From", "Group Effective To"]),
            ("46", "Model Change Implementation", ["Changed Model Portfolio", "From Target Set", "To Target Set",
                                                   "Implementation Window Start", "Implementation Window End",
                                                   "Tax-Aware Transition Indicator", "Accounts in Scope Count",
                                                   "Accounts Deferred Count", "Implementation Status"]),
            ("46", "Substantially Identical Security Group", ["Security Group Code", "Group Member Instrument",
                                                              "Security Group Basis", "Group Policy Approval Status",
                                                              "Member Effective From", "Member Effective To"]),
            ("46", "Wash Sale Control Window", ["Window Household", "Window Account", "Window Security Group",
                                                "Triggering Harvest Decision", "Window Start Date", "Window End Date",
                                                "Controlled Accounts in Scope", "Monitored Accounts in Scope", "Window Status"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assigned Model Portfolio",
                                        "Assignment Program Enrollment", "Assignment Status", "Assignment Effective From",
                                        "Assignment Effective To"]),
            ("49", "Client Lot Relief", ["Relieved Client Tax Lot", "Closing Activity", "Relieved Cost Basis", "Relief Proceeds",
                                         "Realized Gain or Loss", "Holding Period Term", "Wash Sale Loss Disallowed",
                                         "Wash Sale Replacement Lot"]),
            ("49", "Client Tax Lot", ["Client Tax Lot ID", "Lot Account", "Lot Instrument", "Acquisition Date", "Remaining Quantity",
                                      "Adjusted Cost Basis", "Wash Sale Deferred Loss"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Instrument",
                                               "Activity Type", "Trade Date", "Activity Status"]),
            ("49", "Cost Basis Adjustment", ["Adjusted Client Tax Lot", "Basis Adjustment Type", "Basis Adjustment Amount",
                                             "Adjustment Effective Date"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Account",
                                               "Personal Return Period Start Date", "Personal Return Period End Date",
                                               "Personal Return Method", "Personal Return Fee Basis", "Personal Return Value",
                                               "Personal Return Status"]),
        ],
        upstream=["DP-304", "DP-300", "DP-145", "DP-093", "DP-240", "DP-004", "DP-097", "DP-530", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET on T+1 after the lot reliefs of the prior day post; tax-year totals final on business day 10 of January",
        history="Harvest decisions, windows and reliefs kept 7 years by tax year (IRS cost basis records; Advisers Act Rule 204-2); daily snapshots kept 2 years",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Harvest Account, Budget Account, Location Account and Window Account resolves to a DP-093 managed account with a DP-304 Model Assignment, every Window Household and Location Household to a DP-240 Client Household, and every Security Sold and Group Member Instrument to DP-097.",
            "Wash Sale Control Windows of one household or account and security group do not overlap, Window End Date is on or after Window Start Date, and Substantially Identical Security Group memberships of one instrument do not overlap within a group.",
            "Estimated Tax Saving (from DP-304) equals DP-304's Estimated Harvest Tax Saving for the same period and filters to the cent, and every Harvest Client Tax Lots value resolves to a DP-300 Client Tax Lot of the Harvest Account.",
            "Harvest Decision, Unrealized Loss at Scan and Scan Timestamp are populated on every decision, Realized Gain or Loss and Holding Period Term on every relief read, and Window Status on every window.",
            "Account-grain rows are visible only to managed account operations and advice; the semantic model carries amounts by program, model, method and tax year only; 46 Applied Federal Marginal Tax Rate and Tax Rate Source Profile and the 02 tax-rate fields are not read.",
            "A tax year's totals are final on business day 10 of January; later 49 corrections arrive as restatement rows and never overwrite the closed year.",
        ],
        notes=("Certified numbers: reads Personal Return Value from DP-145 (CW-011, CW-251); owns none (It owns no certified metric "
               "family). Estimated Tax Saving and Tax Saving Method are read from DP-304 as 46 masters them and never recomputed "
               "(WP1F ruling); the realized loss is the 49 book (Client Lot Relief through DP-300). Book of record: Client Holding, "
               "Client Tax Lot and Client Lot Relief (49), never 18 (CW-007); the 46 Account Tax Budget Realized Net Gain to Date "
               "and Realized Short-Term Gain to Date are Derived copies of 49 and are not read. PII tier: financial. Boundaries: "
               "DP-304 publishes Harvest Decisions, Harvested Unrealized Loss, Estimated Harvest Tax Saving, Harvests Without Wash "
               "Sale Window and Open Wash Sale Windows, which are not redefined; DP-300 publishes Wash Sale Loss Disallowed and "
               "Realized Gain or Loss for all accounts; this product measures effectiveness on managed accounts. Backlog DP-343 "
               "Wash-Sale Control & Household Tax Coordination folds in (moved reads: 46 Substantially Identical Security Group and "
               "Wash Sale Control Window; Cost Basis Adjustment); its 48 Client Execution read is replaced by the posted 49 Client "
               "Account Activity (the booked purchase, DP-301 keeps executions). Objects of the candidate not read: 02 Investor "
               "Profile (the Federal Marginal Tax Rate is not used because the saving is read from DP-304, and DP-304 reads no tax "
               "rate either). Acceptance question 4 (plan section 8.5): answered by Estimated Tax Saving (from DP-304) and "
               "Realized Harvested Losses; mastering domains 46, 49. Tailoring lever: tax saving at the client's marginal rate or a "
               "flat rate (46 SME 7). Reference default: Client Marginal Rate where 46 holds one, Flat Assumed Rate otherwise, "
               "shown by Tax Saving Method. Tailoring lever: wash sale window scope (46 SME 3). Reference default: the seller's and "
               "spouse's accounts in the household managed group, managed accounts blocked and self-directed accounts monitored. "
               "Tailoring lever: substantially identical policy (46 SME 4). Reference default: index-twin funds treated as "
               "identical. Taxonomy gap: 46 Tax-Loss Harvest Decision has no link to the executing client order or closing activity, "
               "so realized losses are matched by lot and a 3-business-day window. Drafting "
               "assumptions: Activity Type Buy and Fund Purchase; Activity Status Posted; 3-business-day match window; Group Policy "
               "Approval Status approved value; the January close. Decisions: CW-007, CW-047, CW-049, CW-205, CW-251. WP1 new "
               "(CW-205): first specification; the plan section 8.3 Rebalance & Tax-Loss Harvest Effectiveness example."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-346": dict(
        definition=("Every advisory fee calculation run re-performed: run reconciliation status, each account's fee re-performed "
                    "from its assigned schedule version, tiers, fee household breakpoint, overrides and waivers, the billable "
                    "assets re-performed from 49 Client Holdings with their exclusions, calculation exceptions, debits posted "
                    "against calculations, refunds and billing-error disputes, and for each debited account the deduction "
                    "authorization, custody-rule basis, custodian statements and fee disclosures in force. Billing operations and "
                    "compliance use it to answer the SEC fee-billing risk alert findings, evidence the Advisers Act Rule "
                    "206(4)-2 conditions and answer acceptance question 8. The billing facts are DP-305's and are read, never "
                    "redefined; run totals are tied to the certified client fee revenue of DP-012 (CW-214). It owns no certified "
                    "metric family."),
        business_questions=[
            "Which fee calculation runs failed reconciliation (acceptance question 8), and by how much do they miss their control totals?",
            "Which accounts were billed outside their schedule (acceptance question 8): wrong version, wrong tier, missed household breakpoint, unapproved override or waiver?",
            "Are billable assets right: do they agree to the 49 holdings, and were own-fund holdings excluded where the schedule says so?",
            "Was every fee debit authorized, debited from the authorized account, posted to the account and covered by custodian statements and, where required, a surprise examination?",
            "What did billing errors cost in refunds, and were fee changes noticed in advance?",
        ],
        grain=("Account fee calculation (fee calculation run x billed subject) with its re-performed fee, flags and the fee debit "
               "it produced; companion rows at fee calculation run (reconciliation) and at debited account x quarter (custody-rule "
               "evidence); monthly or quarterly by billing period, re-tested on each recalculation run"),
        dimensions=["Fee calculation run and run type (DP-305)", "Client account (DP-093)", "Fee schedule and version (DP-305)",
                    "Fee household (47 fee aggregation group, DP-305)", "Client Household (DP-240)", "Service offering (DP-004)",
                    "Fee exception type", "Exclusion category", "Custody rule basis", "Billing period (DP-013)"],
        measures=[
            ("Fee Runs Tested",
             "Count of Fee Calculation Run ID with Run Status in (Approved, Released), Run Type other than Simulation and Run "
             "Billing Period End in the period, by Run Type.",
             _u("47", "Fee Calculation Run", "Fee Calculation Run ID", "Run Billing Period Start", "Run Billing Period End",
                "Run Type", "Run Status")),
            ("Run Control Total Variance (from DP-305)",
             "Per run: DP-305's published Run Control Total Variance, read by name and never recomputed (DP-305 defines it as "
             "Run Net Fee Total minus the sum of Net Fee of the run's Account Fee Calculation rows; USD).",
             _u("47", "Fee Calculation Run", "Run Net Fee Total")
             + _u("47", "Account Fee Calculation", "Calculation Run", "Net Fee")),
            ("Failed Fee Runs",
             "Acceptance question 8 (first half): Fee Runs Tested with Fee Reconciliation Status in (Break Open, Not Reconciled), "
             "or with absolute Run Control Total Variance (from DP-305) above USD 0.01, or released with Run Approved By blank; by Run "
             "Type and Fee Reconciliation Status.",
             _u("47", "Fee Calculation Run", "Fee Reconciliation Status", "Run Approved By")
             + ["Fee Runs Tested", "Run Control Total Variance (from DP-305)"]),
            ("Re-Performed Fee",
             "Per Account Fee Calculation: the fee re-performed from the Fee Schedule Assignment in force at Run Billing Period End "
             "(Calculated Assignment = Fee Schedule Assignment ID; Assignment Effective From / To): its Assigned Fee Schedule "
             "version effective on that date (Version Effective From / To), applying Fee Schedule Tier rows (Tier Lower Bound, "
             "Tier Upper Bound, Tier Rate) by Tier Method to Fee Household Assets where the account is an active member of the "
             "Assigned Fee Household, else to Billable Assets; replaced by Override Rate of an active Fee Rate Override; capped by "
             "Maximum Fee Rate and floored by Minimum Annual Fee; reduced by Waiver Percentage or Waiver Amount of an active Fee "
             "Waiver; times Pro-Ration Days / 365 (USD).",
             _u("47", "Fee Schedule Assignment", "Fee Schedule Assignment ID", "Assigned Fee Schedule", "Assigned Fee Household",
                "Negotiated Rate Indicator", "Assignment Effective From", "Assignment Effective To")
             + _u("47", "Fee Schedule", "Fee Schedule ID", "Schedule Version Number", "Version Effective From",
                  "Version Effective To", "Tier Method", "Minimum Annual Fee", "Maximum Fee Rate")
             + _u("47", "Fee Schedule Tier", "Tier Fee Schedule", "Tier Sequence", "Tier Lower Bound", "Tier Upper Bound",
                  "Tier Rate")
             + _u("47", "Fee Rate Override", "Overridden Assignment", "Override Rate", "Override Effective From",
                  "Override Expiry Date")
             + _u("47", "Fee Waiver", "Fee Waiver ID", "Waived Assignment", "Waiver Percentage", "Waiver Amount",
                  "Waiver Period Start", "Waiver Period End")
             + _u("47", "Fee Household Membership", "Membership Fee Household", "Member Account",
                  "Fee Household Membership Status", "Fee Household Membership Effective From",
                  "Fee Household Membership Effective To")
             + _u("47", "Account Fee Calculation", "Calculated Assignment", "Schedule Version Applied", "Billable Assets",
                  "Fee Household Assets", "Pro-Ration Days")
             + _u("47", "Fee Calculation Run", "Run Billing Period End")),
            ("Off-Schedule Flag",
             "Acceptance question 8 (second half), defined here: Y for an Account Fee Calculation when Schedule Version Applied is "
             "not the version used by Re-Performed Fee, when Effective Annual Rate differs from the re-performed annual rate by "
             "more than 0.005 percentage points, or when Net Fee differs from Re-Performed Fee by more than USD 1.",
             _u("47", "Account Fee Calculation", "Schedule Version Applied", "Effective Annual Rate", "Net Fee")
             + ["Re-Performed Fee"]),
            ("Accounts Billed Off Schedule",
             "Acceptance question 8 (second half): count of distinct billed 15 accounts (Fee Schedule Assignment Billed Account, "
             "resolving to an Account ID with Account Status = Open or closed in the period) with Off-Schedule Flag = Y in the billing "
             "period, by Fee Schedule Type and cause (version, tier or breakpoint, override, waiver).",
             _u("47", "Fee Schedule", "Fee Schedule Type")
             + _u("47", "Fee Schedule Assignment", "Billed Account", "Fee Schedule Assignment ID")
             + _u("47", "Account Fee Calculation", "Calculated Assignment")
             + _u("15", "Account", "Account ID", "Account Status")
             + ["Off-Schedule Flag"]),
            ("Billing Variance",
             "Sum of Net Fee minus Re-Performed Fee over calculations with Off-Schedule Flag = Y, overbilled and underbilled shown "
             "separately (USD).",
             _u("47", "Account Fee Calculation", "Net Fee") + ["Re-Performed Fee", "Off-Schedule Flag"]),
            ("Household Breakpoint Not Applied",
             "Calculations of accounts that are active members of a Fee Household with more than one active member account whose "
             "Fee Household Assets is blank or equal to Billable Assets.",
             _u("47", "Account Fee Calculation", "Fee Household Assets", "Billable Assets")
             + _u("47", "Fee Household", "Fee Household ID", "Anchor Client Household", "Fee Household Status")
             + _u("47", "Fee Household Membership", "Membership Fee Household", "Member Account")),
            ("Billable Asset Variance %",
             "Per calculation: (Billable Assets + sum of Excluded Amount of its Billable Asset Exclusion rows) / (Market Value in "
             "USD of the account's End of Day 49 Client Holdings on the run's Valuation As-Of Date) - 1, for Billing Basis = "
             "Period-End Value; calculations beyond 0.5% are listed.",
             _u("47", "Account Fee Calculation", "Billable Assets")
             + _u("47", "Billable Asset Exclusion", "Excluded From Calculation", "Exclusion Category", "Excluded Amount")
             + _u("47", "Fee Calculation Run", "Valuation As-Of Date")
             + _u("47", "Fee Schedule", "Billing Basis")
             + _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")),
            ("Own-Fund Holdings Billed",
             "For calculations whose schedule has Own-Fund Treatment = Excluded: Market Value in USD of the account's End of Day "
             "Client Holdings with Own Share Class Indicator = Y on the Valuation As-Of Date not covered by a Billable Asset "
             "Exclusion of Exclusion Category = Own-Fund Offset (Excluded Client Holding) and with Own-Fund Credit Amount blank or "
             "zero: the double-charging the SEC fee-billing alerts cite.",
             _u("47", "Fee Schedule", "Own-Fund Treatment")
             + _u("47", "Billable Asset Exclusion", "Exclusion Category", "Excluded Client Holding")
             + _u("47", "Account Fee Calculation", "Own-Fund Credit Amount", "Calculated Assignment")
             + _u("47", "Fee Calculation Run", "Valuation As-Of Date")
             + _u("47", "Fee Schedule Assignment", "Billed Account")
             + _u("49", "Client Holding", "Own Share Class Indicator", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")),
            ("Unapproved Overrides and Waivers Applied",
             "Calculations in the period that applied a Fee Rate Override with Override Approved By blank or a Fee Waiver (Waivers "
             "Applied, Waiver Amount Applied above zero) with Waiver Approved By blank, by Waiver Reason.",
             _u("47", "Fee Rate Override", "Override Approved By")
             + _u("47", "Fee Waiver", "Waiver Reason", "Waiver Approved By")
             + _u("47", "Account Fee Calculation", "Waivers Applied", "Waiver Amount Applied")),
            ("Open Calculation Exceptions",
             "Fee Calculation Exception rows with Exception Resolved Date blank, by Fee Exception Type and age from Exception Raised "
             "Date, with the count of Billed Outside Schedule exceptions closed without an Exception Supervisory Review.",
             _u("47", "Fee Calculation Exception", "Exception Calculation", "Fee Exception Type", "Exception Raised Date",
                "Exception Resolution", "Exception Resolved Date", "Exception Supervisory Review")),
            ("Debits Without Authorization",
             "Fee Debit rows with Fee Debit Status = Posted and Debit Date in the period with no Fee Deduction Authorization of "
             "the Debited Account with Authorization Status = Active, Authorization Effective Date on or before Debit Date, "
             "Authorization Revoked Date blank or later and Fee Types Authorized covering Charged Fee Type, or whose Debited "
             "Account differs from the Authorized Fee-Paying Account, or whose Authorizing Agreement is not a 15 Account Agreement "
             "of Account Agreement Type = Investment Advisory Agreement with Agreement Signed Date populated and Agreement Status "
             "active; count and amount.",
             _u("47", "Fee Debit", "Fee Debit ID", "Debited Calculation", "Charged Fee Type", "Debited Account", "Debit Amount",
                "Debit Date", "Fee Debit Status")
             + _u("47", "Fee Deduction Authorization", "Authorized Account", "Authorizing Agreement", "Fee Types Authorized",
                  "Authorized Fee-Paying Account", "Authorization Status", "Authorization Effective Date",
                  "Authorization Revoked Date")
             + _u("15", "Account Agreement", "Account Agreement ID", "Agreement Account", "Account Agreement Type",
                  "Agreement Signed Date", "Agreement Status")),
            ("Debit to Calculation Breaks",
             "Posted Fee Debits whose Debit Amount differs from the Net Fee of the Debited Calculation by more than USD 0.01, or "
             "that have no posted 49 Client Account Activity with Source Fee Debit = Fee Debit ID and Activity Net Amount equal "
             "to minus Debit Amount.",
             _u("47", "Fee Debit", "Debit Amount", "Debited Calculation", "Debit Posting")
             + _u("47", "Account Fee Calculation", "Net Fee")
             + _u("49", "Client Account Activity", "Client Account Activity ID", "Activity Account", "Activity Type",
                  "Activity Net Amount", "Activity Status", "Source Fee Debit")),
            ("Custody Rule Evidence Gaps",
             "Debited accounts of the quarter whose authorization has Custody Rule Basis = Fee Deduction Only - Rule "
             "206(4)-2(b)(3) and no 13 Investor Document periodic statement with Period End Date = the quarter end delivered "
             "(Last Custodian Statement or the account's statement); plus adviser entities whose 38 Adviser Custody Profile in "
             "effect has Surprise Examination Required Indicator = Y and no 38 Custody Surprise Examination in the last 12 months "
             "with Form ADV-E Filing populated, or one with Material Discrepancies Found Indicator = Y.",
             _u("47", "Fee Deduction Authorization", "Custody Rule Basis", "Qualified Custodian", "Last Custodian Statement")
             + _u("13", "Investor Document", "Investor Document ID", "Document Account", "Period End Date", "Delivered Date")
             + _u("38", "Adviser Custody Profile", "Custody Adviser Entity", "Custody Profile Effective From",
                  "Custody Profile Effective To", "Custody Bases", "Surprise Examination Required Indicator")
             + _u("38", "Custody Surprise Examination", "Surprise Examined Adviser", "Surprise Examination Date",
                  "Form ADV-E Filing", "Material Discrepancies Found Indicator")),
            ("Fee Changes Without Advance Notice",
             "Calculations whose Schedule Version Applied differs from the version applied to the same subject in the prior "
             "billing period, with no Fee Disclosure Delivery of Fee Disclosure Type = Advance Notice of Fee Change to the account "
             "(Fee Disclosure Account) for that Disclosed Fee Schedule delivered at least 30 days before Fee Change Effective "
             "Date; and active enrollments with no Form ADV Part 2 Fee Section delivery (Related Program Enrollment).",
             _u("47", "Fee Disclosure Delivery", "Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type",
                "Disclosed Fee Schedule", "Fee Disclosure Delivered Date", "Fee Change Effective Date",
                "Related Program Enrollment")
             + _u("47", "Account Fee Calculation", "Schedule Version Applied", "Calculated Assignment")
             + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrollment Status")),
            ("Billing Error Refunds",
             "Count and sum of Adjustment Amount Value of Fee Adjustment rows with Adjustment Type in (Error Correction, Overbilling "
             "Refund) whose Adjusted Fee Calculation's run ended in the period, with the share linked to a Billing Dispute "
             "(Related Billing Dispute) and the count lacking Adjustment Approved By.",
             _u("47", "Fee Adjustment", "Fee Adjustment ID", "Adjustment Type", "Adjusted Fee Calculation",
                "Adjustment Amount Value", "Related Billing Dispute", "Credit Posting", "Adjustment Approved By")),
            ("Disputes Citing Billing Errors",
             "Count and Disputed Amount of Billing Dispute rows on account calculations (Disputed Fee Calculation) with Dispute "
             "Reason in (Asset Value Disagreement, Rate Applied Incorrectly, Period Error, Household Breakpoint Not Applied, Fee "
             "Not Disclosed), with the share whose calculation also has Off-Schedule Flag = Y.",
             _u("47", "Billing Dispute", "Billing Dispute ID", "Disputed Fee Calculation", "Dispute Reason", "Disputed Amount",
                "Dispute Status", "Related Complaint")
             + ["Off-Schedule Flag"]),
            ("Billed to Client Fee Revenue Variance (from DP-012)",
             "Per fiscal month and 47 client fee stream: Net Fee of the released runs' calculations minus DP-012's published "
             "Client Fee Revenue for the same Client Revenue Stream and Client Revenue Period (read by name, with the Source "
             "Calculation Record link used only to align the calculations); an operational tie-out, not a certified number "
             "(CW-214).",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Client Revenue Stream", "Client Revenue Period",
                "Source Calculation Record", "Recognized Revenue Amount")
             + _u("47", "Account Fee Calculation", "Net Fee")),
        ],
        inputs=[
            ("47", "Fee Calculation Run", ["Fee Calculation Run ID", "Run Billing Period Start", "Run Billing Period End",
                                           "Run Type", "Valuation As-Of Date", "Run Status", "Fee Reconciliation Status",
                                           "Run Net Fee Total", "Run Approved By"]),
            ("47", "Account Fee Calculation", ["Calculation Run", "Calculated Assignment", "Schedule Version Applied",
                                               "Billable Assets", "Fee Household Assets", "Effective Annual Rate",
                                               "Pro-Ration Days", "Gross Fee", "Discount Amount", "Waivers Applied",
                                               "Waiver Amount Applied", "Own-Fund Credit Amount", "Net Fee", "Exception Indicator"]),
            ("47", "Billable Asset Exclusion", ["Excluded From Calculation", "Exclusion Category", "Excluded Client Holding",
                                                "Excluded Amount", "Exclusion Authority"]),
            ("47", "Fee Calculation Exception", ["Exception Calculation", "Fee Exception Type", "Exception Raised Date",
                                                 "Exception Resolution", "Exception Resolved Date",
                                                 "Exception Supervisory Review"]),
            ("47", "Fee Schedule Assignment", ["Fee Schedule Assignment ID", "Billed Enrollment", "Billed Account",
                                               "Assigned Fee Schedule", "Fee-Paying Account", "Fee Collection Method",
                                               "Assigned Fee Household", "Negotiated Rate Indicator",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("47", "Fee Schedule", ["Fee Schedule ID", "Fee Schedule Type", "Schedule Version Number", "Version Effective From",
                                    "Version Effective To", "Billing Basis", "Tier Method", "Minimum Annual Fee",
                                    "Maximum Fee Rate", "Own-Fund Treatment"]),
            ("47", "Fee Schedule Tier", ["Tier Fee Schedule", "Tier Sequence", "Tier Lower Bound", "Tier Upper Bound", "Tier Rate"]),
            ("47", "Fee Rate Override", ["Overridden Assignment", "Override Rate", "Override Approved By",
                                         "Override Effective From", "Override Expiry Date"]),
            ("47", "Fee Waiver", ["Fee Waiver ID", "Waived Assignment", "Waiver Reason", "Waiver Percentage", "Waiver Amount",
                                  "Waiver Period Start", "Waiver Period End", "Waiver Approved By"]),
            ("47", "Fee Adjustment", ["Fee Adjustment ID", "Adjustment Type", "Adjusted Fee Calculation",
                                      "Adjustment Amount Value", "Applied Fee Waiver", "Related Billing Dispute",
                                      "Credit Posting", "Adjustment Approved By"]),
            ("47", "Billing Dispute", ["Billing Dispute ID", "Disputed Fee Calculation", "Dispute Reason", "Disputed Amount",
                                       "Dispute Status", "Related Complaint"]),
            ("47", "Fee Household", ["Fee Household ID", "Anchor Client Household", "Fee Household Status"]),
            ("47", "Fee Household Membership", ["Membership Fee Household", "Member Account", "Fee Household Membership Status",
                                                "Fee Household Membership Effective From",
                                                "Fee Household Membership Effective To"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Debited Calculation", "Charged Fee Type", "Debited Account", "Debit Amount",
                                 "Debit Date", "Fee Debit Status", "Debit Posting"]),
            ("47", "Fee Deduction Authorization", ["Authorized Account", "Authorizing Agreement", "Fee Types Authorized",
                                                   "Authorized Fee-Paying Account", "Qualified Custodian", "Custody Rule Basis",
                                                   "Last Custodian Statement", "Authorization Status",
                                                   "Authorization Effective Date", "Authorization Revoked Date"]),
            ("47", "Fee Disclosure Delivery", ["Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type",
                                               "Disclosed Fee Schedule", "Fee Disclosure Delivered Date",
                                               "Fee Change Effective Date", "Related Program Enrollment"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrollment Status", "Advisory Agreement"]),
            ("15", "Account", ["Account ID", "Account Status"]),
            ("15", "Account Agreement", ["Account Agreement ID", "Agreement Account", "Account Agreement Type",
                                         "Agreement Signed Date", "Agreement Status"]),
            ("38", "Adviser Custody Profile", ["Custody Adviser Entity", "Custody Profile Effective From",
                                               "Custody Profile Effective To", "Custody Bases",
                                               "Surprise Examination Required Indicator"]),
            ("38", "Custody Surprise Examination", ["Surprise Examined Adviser", "Surprise Examination Date", "Form ADV-E Filing",
                                                    "Material Discrepancies Found Indicator"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View",
                                      "Own Share Class Indicator"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Type",
                                               "Activity Net Amount", "Activity Status", "Source Fee Debit"]),
            ("13", "Investor Document", ["Investor Document ID", "Document Account", "Period End Date", "Delivered Date"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Client Revenue Stream", "Client Revenue Period",
                                             "Source Calculation Record", "Recognized Revenue Amount"]),
        ],
        upstream=["DP-305", "DP-300", "DP-093", "DP-012", "DP-004", "DP-240", "DP-382", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 3 after each billing run is released, and again after any recalculation run; the quarterly custody evidence on business day 45 after quarter end",
        history="Re-performance results kept 6 years by billing period (Advisers Act Rule 204-2(a)(7) and the custody rule records), every re-test as a new version",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Calculated Assignment resolves to a DP-305 Fee Schedule Assignment, every Debited Account and Authorized Account to a DP-093 account, every Assigned Fee Schedule and Schedule Version Applied to a DP-305 fee schedule version, and every Billed Enrollment to a DP-093 program enrollment.",
            "Fee Schedule versions of one schedule do not overlap, Fee Schedule Tier bounds of one version are contiguous and do not overlap, and at most one Fee Rate Override and one Fee Waiver are active per assignment on any date.",
            "Failed Fee Runs includes every run whose Run Control Total Variance (from DP-305) is nonzero beyond USD 0.01 and every run with Fee Reconciliation Status in (Break Open, Not Reconciled), and Billed to Client Fee Revenue Variance (from DP-012) is within USD 1 per fiscal month and stream after DP-012's period closes.",
            "Billable Assets, Effective Annual Rate, Net Fee and Schedule Version Applied are populated on every account fee calculation, and Custody Rule Basis and Authorization Status on every fee deduction authorization.",
            "Calculation rows are published per account only in the Confidential - Personal Data view to billing operations and compliance; the semantic model carries counts and amounts by run, schedule type and cause; bill-to names are not carried.",
            "Re-performance runs within business day 3 of each released run and results of a closed billing period are versioned, never overwritten.",
        ],
        notes=("Certified numbers: none owned (It owns no certified metric family). Reads DP-012's published Client Fee Revenue "
               "(the client fee slice of certified Gross Fee Revenue) for the tie-out (CW-011, CW-214); billed amounts are "
               "operational and never presented as revenue. Billable assets are a Derived copy of 49 valuations re-checked against DP-300 and "
               "are never Client Assets or Firm AUM. The fee household is the 47 fee aggregation group, not the 02 Client "
               "Household (CW-027). PII tier: financial. Boundaries: DP-305 publishes the schedules, runs, calculations, debits, "
               "waivers, adjustments, disputes, authorizations and disclosures and the measures Run Control Total Variance, "
               "Assignments Off Offering Schedule, Average Effective Annual Rate, Failed Fee Debits, Active Fee Waivers, Fee "
               "Adjustment Amount, Open Billing Disputes and Active Fee Deduction Authorizations, which are not redefined (the run "
               "control is read by name). Backlog DP-347 Fee Waivers, Adjustments & Billing Disputes folds in (47 Fee Adjustment, "
               "moved read; Billing Error Refunds, Disputes Citing Billing Errors); its 08 Complaint read stays with the 08 "
               "products through Related Complaint. 15 Account Agreement is read in Debits Without Authorization. Custody-rule status is read from the 38 Adviser Custody Profile and Custody Surprise Examination objects (CW-263) and the fee runs from DP-305. Acceptance question 8 (plan section 8.5): answered by "
               "Failed Fee Runs, Off-Schedule Flag, Accounts Billed Off Schedule (through the billed 15 account) and Billable "
               "Asset Variance % (against the 49 holdings), with Billing Variance; mastering domains 47, 15, 49. Operating model (CD-297): with outsourced fee billing the grain stays the account fee calculation of the "
               "vendor's run, re-performed on a sample instead of every account. Tailoring lever: own-fund offset (47 SME 4). "
               "Reference default: own funds excluded from billable assets. Tailoring lever: household breakpoints (47 SME 12). "
               "Reference default: on billable assets of member accounts. Tailoring lever: fee billing outsourced. Reference "
               "default: in house, every account re-performed. Tailoring lever: advance notice period for fee changes. Reference "
               "default: 30 days. Taxonomy gap: 47 Fee Schedule Tier has no rule for blended versus cliff tiers beyond Tier Method "
               "text values; the re-performance assumes Tier Method values Blended and Cliff. Taxonomy gap: 47 Fee Adjustment has "
               "no adjustment date (DP-305). Taxonomy gap: Billable Asset Exclusion Excluded Amount is a Derived copy; the "
               "excluded holding is matched by Excluded Client Holding. Drafting assumptions: Run Status Approved and Released; "
               "the 0.005 percentage-point rate and USD 1 fee tolerances; 0.5% asset tolerance; Period-End Value basis for the "
               "asset test; Authorization Status Active; 30-day notice; business days 3 and 45. Decisions: CW-011, CW-012, "
               "CW-027, CW-051, CW-052, CW-053, CW-214, CW-263, CD-297. WP1 new (CW-214): first specification; the plan section 8.3 Fee "
               "Billing Accuracy example."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-349": dict(
        definition=("Commissions and transaction charges on client trade confirmations and event-based account service charges "
                    "(wires, ACATS transfers out, paper delivery, IRA closing) re-performed against the 47 schedule in force, its "
                    "discount rules and service-tier waivers, with the markup and remuneration disclosed on the confirmation "
                    "under SEC Rule 10b-10 and FINRA Rule 2232. Billing and brokerage operations clear mischarges and missed "
                    "charges and evidence what was charged and disclosed; pricing sees the value of discounts realized. The "
                    "schedules and debits are DP-305's and the confirmations DP-301's; it owns no certified metric family."),
        business_questions=[
            "Which confirmations were charged a commission different from the schedule, discount and channel in force, and by how much were clients overcharged?",
            "Which principal fixed income confirmations lack the markup disclosure FINRA Rule 2232 requires, and what markups are we charging?",
            "Which service charges were debited without a triggering event, at the wrong amount, or despite a tier waiver or e-delivery election?",
            "Which wires and transfers out were not charged when the schedule says they should be?",
            "What is the value of commission discounts realized, by discount basis and service tier?",
        ],
        grain=("Client trade confirmation (CCONF-, latest version) with its re-performed charge, and fee debit (FDBT-) of Charged "
               "Fee Type = Account Service with its triggering money movement or account transfer, as two fact sets; daily on T+1, "
               "monthly summaries"),
        dimensions=["Client account (DP-093)", "Instrument charge category and charge channel", "Order entry channel (DP-301)",
                    "Confirmed capacity", "Account service type", "Fee schedule and version (DP-305)", "Discount basis",
                    "Service tier (DP-004)", "Trade date and debit date (DP-013)"],
        measures=[
            ("Commissionable Confirmations",
             "Count of 48 Client Trade Confirmation rows of the latest Confirmation Version (Superseded Confirmation not pointing "
             "at them) with Confirmation Type other than Cancel and Confirmed Trade Date in the period, by Commission Fee Schedule, "
             "Confirmed Capacity and the Order Entry Channel of the allocated client order.",
             _u("48", "Client Trade Confirmation", "Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type",
                "Confirmed Client Allocation", "Confirmation Account", "Confirmed Trade Date", "Confirmed Capacity",
                "Commission Fee Schedule", "Superseded Confirmation")
             + _u("48", "Client Allocation", "Allocated Client Order", "Allocated Account")
             + _u("48", "Client Order", "Client Order ID", "Order Entry Channel")),
            ("Expected Commission",
             "Per confirmation: from the Commission & Transaction Charge Rate of the Fee Schedule assigned to the account (Billed "
             "Account, assignment in effect on Confirmed Trade Date) for the instrument's Instrument Charge Category and the "
             "Charge Channel mapped from Order Entry Channel: Base Charge Per Trade + Per-Unit Charge x Confirmed Quantity + "
             "Broker-Assisted Surcharge where the channel is representative-assisted, bounded by Minimum Charge and Maximum "
             "Charge, less Rate Reduction or Fee Percentage Discount of each Fee Discount Rule in effect for the schedule whose "
             "Qualifying Service Tier is the owner's service tier (only one unless Stackable Indicator = Y) (USD).",
             _u("47", "Commission & Transaction Charge Rate", "Charge Fee Schedule", "Instrument Charge Category", "Charge Channel",
                "Base Charge Per Trade", "Per-Unit Charge", "Minimum Charge", "Maximum Charge", "Broker-Assisted Surcharge")
             + _u("47", "Fee Schedule Assignment", "Billed Account", "Assigned Fee Schedule", "Assignment Effective From",
                  "Assignment Effective To")
             + _u("47", "Fee Discount Rule", "Discount Rule Code", "Discounted Fee Schedule", "Discount Basis",
                  "Qualifying Service Tier", "Rate Reduction", "Fee Percentage Discount", "Stackable Indicator",
                  "Discount Effective From", "Discount Effective To")
             + _u("48", "Client Trade Confirmation", "Confirmed Quantity", "Confirmed Trade Date")
             + _u("48", "Client Order", "Order Entry Channel")
             + _u("02", "Service Tier Assignment", "Tier Party", "Assigned Service Tier", "Tier Effective From", "Tier Effective To")),
            ("Mischarged Confirmations",
             "Commissionable Confirmations where Commission Charged differs from Expected Commission by more than USD 0.01, by "
             "Instrument Charge Category and channel, with the sum of the difference.",
             _u("48", "Client Trade Confirmation", "Commission Charged")
             + ["Commissionable Confirmations", "Expected Commission"]),
            ("Commission Overcharged",
             "Sum of max(0, Commission Charged - Expected Commission) over Mischarged Confirmations in the period (USD), the "
             "refund exposure.",
             _u("48", "Client Trade Confirmation", "Commission Charged")
             + ["Expected Commission", "Mischarged Confirmations"]),
            ("Discount Value Realized",
             "Sum over Commissionable Confirmations of the undiscounted expected charge minus Expected Commission, by Discount "
             "Basis and Qualifying Service Tier: the value of commission discounts given.",
             _u("47", "Fee Discount Rule", "Discount Basis", "Qualifying Service Tier")
             + ["Expected Commission", "Commissionable Confirmations"]),
            ("Confirmations Without Schedule",
             "Commissionable Confirmations with Commission Charged above zero and Commission Fee Schedule blank, or whose Commission "
             "Fee Schedule is not the schedule assigned to the account on the trade date.",
             _u("48", "Client Trade Confirmation", "Commission Charged", "Commission Fee Schedule")
             + _u("47", "Fee Schedule Assignment", "Assigned Fee Schedule")
             + ["Commissionable Confirmations"]),
            ("Markup Disclosure Gaps",
             "Confirmations with Confirmed Capacity in (Principal, Riskless Principal) whose Confirmation Remuneration Disclosure "
             "has Markup Disclosure Scope Condition met and Markup Markdown Amount or Markup Markdown Percentage blank without a "
             "Markup Disclosure Exception, or Prevailing Market Price blank (FINRA Rule 2232, MSRB Rule G-15).",
             _u("48", "Confirmation Remuneration Disclosure", "Markup Markdown Amount", "Markup Markdown Percentage",
                "Prevailing Market Price", "Markup Disclosure Scope Condition", "Markup Disclosure Exception")
             + _u("48", "Client Trade Confirmation", "Confirmed Capacity")),
            ("Average Markup %",
             "Mean Markup Markdown Percentage of principal confirmations in the period, by instrument charge category, with the "
             "share above 2%.",
             _u("48", "Confirmation Remuneration Disclosure", "Markup Markdown Percentage")
             + _u("48", "Client Trade Confirmation", "Confirmed Capacity")),
            ("Agency Confirmations Without Remuneration Statement",
             "Agency confirmations (Confirmed Capacity = Agency) of equity and option orders with Order Flow Remuneration Statement "
             "blank (SEC Rule 10b-10(a)(2)(i)(C)).",
             _u("48", "Client Trade Confirmation", "Confirmed Capacity", "Order Flow Remuneration Statement")),
            ("Service Charges Debited",
             "Count and sum of Debit Amount of Fee Debit rows with Charged Fee Type = Account Service and Fee Debit Status = Posted "
             "in the period, by Charged Service Type.",
             _u("47", "Fee Debit", "Fee Debit ID", "Charged Fee Type", "Charged Service Type", "Charged Service Fee Schedule",
                "Debited Account", "Debit Amount", "Debit Date", "Fee Debit Status")),
            ("Service Charge Amount Variance",
             "Service Charges Debited whose Debit Amount differs from the Service Fee Amount of the Account Service Fee Item of the "
             "Charged Service Fee Schedule and Charged Service Type in force on Debit Date, with the sum of the difference.",
             _u("47", "Account Service Fee Item", "Service Fee Schedule", "Account Service Type", "Service Fee Amount",
                "Service Fee Frequency")
             + _u("47", "Fee Schedule", "Fee Schedule ID", "Version Effective From", "Version Effective To")
             + ["Service Charges Debited"]),
            ("Service Charges Without Triggering Event",
             "Service Charges Debited of Charged Service Type outgoing wire or ACATS transfer out whose Triggering Money Movement "
             "(or Triggering Account Transfer) is blank or not settled (Money Movement Status = Settled; Transfer Status = "
             "Settled).",
             _u("47", "Fee Debit", "Triggering Money Movement", "Triggering Account Transfer")
             + _u("50", "Money Movement", "Money Movement ID", "Money Movement Status")
             + _u("49", "Account Transfer", "Account Transfer ID", "Transfer Status")
             + ["Service Charges Debited"]),
            ("Missed Service Charges",
             "Settled outgoing wires (Payment Rail in Fedwire Funds, International Wire; Movement Direction = Outflow) and settled "
             "ACATS transfers out (Transfer Direction = Transfer Out, Transfer Channel ACATS Full or ACATS Partial) in the period "
             "with no Fee Debit naming them as trigger, excluding accounts whose owner's service tier is the Waiver Service Tier of "
             "the item and accounts with an active Fee Waiver of the Waived Service Type; count and Service Fee Amount foregone.",
             _u("50", "Money Movement", "Movement Account", "Payment Rail", "Movement Direction", "Value Date",
                "Money Movement Status")
             + _u("49", "Account Transfer", "Transfer Account", "Transfer Direction", "Transfer Channel", "Transfer Settlement Date",
                  "Transfer Status")
             + _u("47", "Account Service Fee Item", "Waivable Indicator", "Waiver Service Tier", "Service Fee Amount")
             + _u("47", "Fee Waiver", "Waived Assignment", "Waived Service Type", "Waiver Period Start", "Waiver Period End")),
            ("Waivable Charges Not Waived",
             "Service Charges Debited whose item has Waivable Indicator = Y and whose account owner's Service Tier Assignment in "
             "effect on Debit Date has Assigned Service Tier = Waiver Service Tier.",
             _u("47", "Account Service Fee Item", "Waivable Indicator", "Waiver Condition", "Waiver Service Tier")
             + _u("02", "Service Tier Assignment", "Tier Party", "Assigned Service Tier")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account")
             + ["Service Charges Debited"]),
            ("Paper Fees on E-Delivery Accounts",
             "Service Charges Debited of Charged Service Type = Paper Statement and Confirmation Delivery on accounts with a 13 "
             "E-Delivery Election in effect with an electronic Delivery Preference (Election Revoked Timestamp blank) for the "
             "billed period.",
             _u("13", "E-Delivery Election", "Election Account", "Delivery Preference", "Election Revoked Timestamp")
             + ["Service Charges Debited"]),
        ],
        inputs=[
            ("47", "Commission & Transaction Charge Rate", ["Charge Fee Schedule", "Instrument Charge Category", "Charge Channel",
                                                            "Transaction Fee Category", "Base Charge Per Trade",
                                                            "Per-Unit Charge", "Minimum Charge", "Maximum Charge",
                                                            "Broker-Assisted Surcharge"]),
            ("47", "Account Service Fee Item", ["Service Fee Schedule", "Account Service Type", "Service Fee Amount",
                                                "Service Fee Frequency", "Waivable Indicator", "Waiver Condition",
                                                "Waiver Service Tier"]),
            ("47", "Fee Discount Rule", ["Discount Rule Code", "Discounted Fee Schedule", "Discount Basis",
                                         "Qualifying Service Tier", "Rate Reduction", "Fee Percentage Discount",
                                         "Stackable Indicator", "Discount Effective From", "Discount Effective To"]),
            ("47", "Fee Schedule", ["Fee Schedule ID", "Fee Schedule Type", "Schedule Version Number", "Version Effective From",
                                    "Version Effective To"]),
            ("47", "Fee Schedule Assignment", ["Fee Schedule Assignment ID", "Billed Account", "Assigned Fee Schedule",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Charged Fee Type", "Charged Service Type", "Charged Service Fee Schedule",
                                 "Triggering Money Movement", "Triggering Account Transfer", "Debited Account", "Debit Amount",
                                 "Debit Date", "Fee Debit Status"]),
            ("47", "Fee Waiver", ["Fee Waiver ID", "Waived Assignment", "Waived Service Type", "Waiver Reason", "Waiver Amount",
                                  "Waiver Period Start", "Waiver Period End"]),
            ("48", "Client Trade Confirmation", ["Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type",
                                                 "Confirmed Client Allocation", "Confirmation Account", "Confirmed Instrument",
                                                 "Confirmed Trade Date", "Confirmed Quantity", "Confirmed Price",
                                                 "Confirmed Capacity", "Commission Charged", "Commission Fee Schedule",
                                                 "Regulatory Transaction Fees", "Net Amount", "Order Flow Remuneration Statement",
                                                 "Superseded Confirmation"]),
            ("48", "Confirmation Remuneration Disclosure", ["Markup Markdown Amount", "Markup Markdown Percentage",
                                                            "Prevailing Market Price", "Markup Disclosure Scope Condition",
                                                            "Markup Disclosure Exception"]),
            ("48", "Client Allocation", ["Allocated Client Order", "Allocated Account", "Allocated Quantity"]),
            ("48", "Client Order", ["Client Order ID", "Order Account", "Order Entry Channel"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Payment Rail", "Movement Direction", "Value Date",
                                      "Money Movement Status"]),
            ("49", "Account Transfer", ["Account Transfer ID", "Transfer Account", "Transfer Direction", "Transfer Channel",
                                        "Transfer Settlement Date", "Transfer Status"]),
            ("02", "Service Tier Assignment", ["Tier Party", "Assigned Service Tier", "Tier Effective From", "Tier Effective To"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account"]),
            ("13", "E-Delivery Election", ["Election Account", "Delivery Preference", "Election Revoked Timestamp"]),
        ],
        upstream=["DP-305", "DP-301", "DP-302", "DP-300", "DP-093", "DP-240", "DP-004", "DP-097", "DP-382", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET on T+1 for the prior day's confirmations and debits; monthly summary on business day 3",
        history="Re-performance results kept 6 years with the confirmations (SEC Rule 17a-4(b) and Rule 10b-10 records); monthly summaries 7 years",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model"],
        dq_rules=[
            "Every Confirmation Account and Debited Account resolves to a DP-093 account, every Confirmed Instrument to DP-097, every Commission Fee Schedule and Charged Service Fee Schedule to a DP-305 schedule version, and every Assigned Service Tier to DP-004.",
            "Commission & Transaction Charge Rate rows of one schedule version, charge category and channel are unique, Fee Discount Rule periods of one rule do not overlap, and only the latest Confirmation Version of each allocation is tested.",
            "Commission Charged summed over Commissionable Confirmations equals DP-301's Commission Charged on Confirmations for the same period within USD 0.01, and Service Charges Debited equals the DP-305 posted Account Service debits for the period.",
            "Commission Charged, Confirmed Capacity and Confirmed Trade Date are populated on every confirmation tested, and Charged Service Type and Debit Amount on every Account Service fee debit.",
            "Account-grain rows are visible only to billing and brokerage operations and supervision; the semantic model carries counts and amounts by charge category, channel and service type only.",
            "Each day's confirmations are re-performed by 9am ET on T+1; results for a trade date are versioned when a corrected confirmation arrives and never overwritten.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family); commissions and service charges are operational "
               "amounts, and client transaction revenue is DP-012's (CW-214). PII tier: financial. Boundaries: DP-305 publishes "
               "the schedules, assignments, debits and waivers; DP-301 publishes the confirmations and Commission Charged on "
               "Confirmations, which is not redefined (it is the DQ3 tie-out); execution quality and Rule 605/606 are DP-436's. "
               "Backlog DP-348 Client Pricing Realization & Breakpoints folds in (47 Fee Discount Rule, moved read; its 01 Offering "
               "Fee Schedule Link and Service Offering reads stay with DP-004 and DP-305, which publish the offering schedule links; Discount Value "
               "Realized); its advisory breakpoint and override realization stays with DP-346 and DP-305, its 10 Pricing Scenario "
               "read moved to DP-497. Objects of the candidate not read: 48 Client Execution (fills are DP-301's; the charge and "
               "disclosure are on the confirmation). Tailoring lever: commission-free online equity and ETF trades (47 SME 5). "
               "Reference default: zero Base Charge Per Trade for Listed Equity and ETF online, broker-assisted surcharge kept. "
               "Tailoring lever: service charge waivers by tier. Reference default: Waiver Service Tier on each waivable item. "
               "Taxonomy gap: no attribute maps 48 Order Entry Channel values to 47 Charge Channel values; the mapping is a "
               "drafting assumption (Website and Mobile App to Online / Mobile, Automated Phone to Automated Phone, the "
               "Representative channels to Broker-Assisted, Advisor Desktop to Advisor-Placed). Taxonomy gap: 47 Fee Debit has no "
               "billed period for recurring service charges. Drafting assumptions: the channel mapping; Fee Debit Status Posted; "
               "Settled statuses; the 2% markup band; wire Payment Rails; USD 0.01 tolerance. Decisions: CW-010, CW-012, CW-214. "
               "WP1 new (CW-205): first specification; takes the DP-348 discount reads."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-077": dict(
        definition=("One current eligibility status per client party and account, reduced from the KYC profile, customer "
                    "identification (CIP) verification, beneficial ownership certification under the FinCEN CDD rule, US tax "
                    "status and TIN certification, Reg BI and FINRA classification, every active client restriction and "
                    "restricted-client status, account restrictions and new issue eligibility (FINRA Rules 5130 and 5131), with "
                    "the DP-322 protection flag as a routing condition. Advice, managed accounts, marketing, money movement and "
                    "the AML and guideline products read the status, reason and restricted product scope instead of re-deriving "
                    "restrictions; compliance uses it to evidence that due diligence is current. It owns no certified metric "
                    "family."),
        business_questions=[
            "Which clients and accounts are excluded from new business or recommendations today, which are conditional, and why?",
            "Which clients have KYC overdue, an open sanctions match, a PEP status, or CIP verification that is pending or failed?",
            "Which legal entity customers lack a current beneficial ownership certification with both the ownership and control prongs?",
            "Which accounts carry an active trading or disbursement restriction, who imposed it, and is its review overdue?",
            "Which accounts are restricted from new issues, and which tax certifications are missing so backup withholding applies?",
        ],
        grain=("Party (02) or account (15) x eligibility as-of date: one current row per client party and per account with an "
               "active restriction, with the restrictions driving it as companion rows; SCD type 2 on eligibility status"),
        dimensions=["Client party and party type (DP-240)", "Client account and account type (DP-093)", "Primary country",
                    "Eligibility status (Excluded, Conditional, Eligible)", "Eligibility reason", "Restriction category and source",
                    "AML risk rating and due diligence level", "KYC status", "Restricted products and instruments (DP-004, DP-097)",
                    "Ultimate parent (DP-240)", "As-of date (DP-013)"],
        measures=[
            ("Eligibility Status",
             "Excluded when any of: Restricted Client Status = Prohibited in effect on the as-of date (Status Effective From / To); "
             "an active Client Restriction (Restriction Status = Active, as-of between Restriction Effective From and Restriction "
             "Effective To) of Restriction Category in (Regulatory, Product Eligibility) with Excluded Instruments blank (all "
             "products); Sanctions Screening Result = Confirmed Match; KYC Status = Failed; AML Risk Rating = Prohibited; or the "
             "latest Identity Verification has Verification Result in (Unable to Verify, Failed). Conditional when not excluded "
             "and any of: Restricted Client Status in (Watch, Restricted); an active Client Restriction limited to Excluded "
             "Instruments or of Restriction Category in (Investment Exclusion, Security-Specific Restriction, Contact & "
             "Engagement, Data Use); an active Account Restriction on one of its accounts; Sanctions Screening Result = Potential "
             "Match - Under Review; PEP Status other than Not a PEP; KYC Overdue Flag = Y; CIP Verification Pending Flag = Y; "
             "Beneficial Ownership Complete Flag = N; Tax Classification Complete Flag = N; or Protection Flag Present (from "
             "DP-322) = Y. Otherwise Eligible.",
             _u("02", "Restricted Client Status", "Status Party", "Restricted Client Status", "Status Effective From",
                "Status Effective To")
             + _u("02", "Client Restriction", "Restricted Party", "Restriction Category", "Excluded Instruments",
                  "Restriction Status", "Restriction Effective From", "Restriction Effective To")
             + _u("02", "KYC Profile", "Sanctions Screening Result", "KYC Status", "AML Risk Rating", "PEP Status")
             + _u("02", "Identity Verification", "Verified Party", "Verification Result", "Verification Date")
             + ["Account Dealing Block Flag", "KYC Overdue Flag", "CIP Verification Pending Flag",
                "Beneficial Ownership Complete Flag", "Tax Classification Complete Flag", "Protection Flag Present (from DP-322)"]),
            ("Eligibility Reason",
             "The first rule met in the Eligibility Status sequence, with the Client Restriction ID, Account Restriction ID, "
             "Restricted Client Status or flag that triggered it; a Protection Flag Present condition is published only as "
             "'Route to trained staff', never with its basis.",
             _u("02", "Client Restriction", "Client Restriction ID")
             + _u("15", "Account Restriction", "Account Restriction ID")
             + ["Eligibility Status"]),
            ("Inherited Exclusion Flag",
             "Y when the party is not itself excluded but its Direct Parent or Ultimate Parent (Legal Entity Hierarchy in effect, "
             "Hierarchy Effective From / To) has Eligibility Status = Excluded for a sanctions, KYC or prohibited-status reason.",
             _u("02", "Legal Entity Hierarchy", "Subsidiary Party", "Direct Parent", "Ultimate Parent", "Hierarchy Effective From",
                "Hierarchy Effective To")
             + ["Eligibility Status"]),
            ("Account Dealing Block Flag",
             "Y for an account with an Account Restriction whose Account Restriction Effective From <= as-of date and Account "
             "Restriction Lifted Date blank or later, with the Restriction Scope it blocks (under the product-level extraction "
             "filter, DQ5).",
             _u("15", "Account Restriction", "Restricted Account", "Account Restriction Type", "Account Restriction Effective From",
                "Account Restriction Lifted Date", "Restriction Scope")),
            ("KYC Overdue Flag",
             "Y when Next KYC Review Date is before the as-of date, or KYC Status is not Complete, for a party holding an owner "
             "Account Party Role on an open account (Account Status = Open).",
             _u("02", "KYC Profile", "Next KYC Review Date", "KYC Status")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")
             + _u("15", "Account", "Account ID", "Account Status")),
            ("CIP Verification Pending Flag",
             "Y for an owner party whose latest Identity Verification (by Verification Date) under the account's CIP Program has "
             "Verification Result = Pending, or Verified - Discrepancy Resolved with Discrepancy Resolution blank, or no "
             "verification with Government List Check Date populated.",
             _u("02", "Identity Verification", "Identity Verification ID", "Verified Party", "CIP Program", "Verification Method",
                "Verification Result", "Verification Date", "Discrepancy Resolution", "Government List Check Date")),
            ("Beneficial Ownership Complete Flag",
             "For a legal entity party whose Legal Entity Customer Exclusion Basis = Not Excluded: Y when its latest Beneficial "
             "Ownership Certification (Certified Entity) has Certification Status = Active and Recertification Due Date on or after "
             "the as-of date, and Beneficial Ownership rows under it include Ownership Prong = Control and every owner of 25% or "
             "more on Ownership Prong = Ownership, each with Owner Identity Verification populated (FinCEN CDD rule, 31 CFR "
             "1010.230); N otherwise; not applicable for excluded entities (control prong only for Nonprofit - Control Prong Only).",
             _u("02", "Organization", "Legal Entity Customer Exclusion Basis")
             + _u("02", "Beneficial Ownership Certification", "Beneficial Ownership Certification ID", "Certified Entity",
                  "Certification Date", "Certification Status", "Recertification Due Date")
             + _u("02", "Beneficial Ownership", "Ownership Certification", "Beneficial Owner", "Ownership Prong",
                  "Beneficial Ownership Percentage", "Owner Identity Verification")),
            ("Tax Classification Complete Flag",
             "Y when the party's Tax Profile has US Person Indicator and Tax Classification populated (FATCA Status for "
             "non-US entities) and each of its open accounts has an Account Tax Certification with TIN Certification Status = "
             "Certified and Certification Expiry Date blank or after the as-of date (W-9 for US persons, W-8 for others) and "
             "Backup Withholding Indicator not Y; only the flag is published, never a TIN.",
             _u("02", "Tax Profile", "US Person Indicator", "Tax Classification", "Nonresident Alien Indicator", "FATCA Status")
             + _u("15", "Account Tax Certification", "Tax Certification ID", "Certified Account", "Tax Form Type",
                  "TIN Certification Status", "Certification Expiry Date")
             + _u("15", "Account Tax Reporting Status", "Backup Withholding Indicator")),
            ("Reg BI Classification Missing",
             "Count of client parties with an owner role on an open account and no 02 Regulatory Classification (Classified "
             "Party) with Reg BI Retail Customer Indicator and FINRA Institutional Account Indicator populated.",
             _u("02", "Regulatory Classification", "Classified Party", "Categorization Date", "Reg BI Retail Customer Indicator",
                "FINRA Institutional Account Indicator", "Investor Category")
             + ["KYC Overdue Flag"]),
            ("New Issue Restricted Accounts",
             "Count of open accounts whose New Issue Eligibility has Rule 5130 Status = Restricted Person or Rule 5131 Covered "
             "Person Indicator = Y, and accounts whose New Issue Recertification Due Date is before the as-of date (eligibility "
             "lapses to restricted).",
             _u("15", "New Issue Eligibility", "Rule 5130 Status", "Rule 5131 Covered Person Indicator", "New Issue Certification Date",
                "New Issue Recertification Due Date")),
            ("Restriction Review Overdue Count",
             "Count of Restricted Client Status rows in effect with Status Next Review Date before the as-of date, plus active "
             "Client Restrictions past Restriction Effective To that still show Restriction Status = Active, plus active Account "
             "Restrictions with Restriction Review Due Date before the as-of date.",
             _u("02", "Restricted Client Status", "Restricted Client Status", "Status Next Review Date", "Status Approved By")
             + _u("02", "Client Restriction", "Restriction Effective To", "Restriction Status")
             + _u("15", "Account Restriction", "Restriction Review Due Date")),
            ("Excluded and Conditional Parties",
             "Count of client parties by Eligibility Status and Eligibility Reason on the as-of date, with the count of parties "
             "with an Inherited Exclusion Flag.",
             _u("02", "Party", "Party ID", "Party Type", "Party Status") + ["Eligibility Status", "Eligibility Reason",
                                                                            "Inherited Exclusion Flag"]),
            ("Protection Flag Present (from DP-322)",
             "Y per 02 party and 15 account as DP-322 publishes it, joined on Party ID and Account ID; it makes the status "
             "Conditional (route to trained staff) and carries no special-category detail.",
             _u("02", "Party", "Party ID") + _u("15", "Account", "Account ID")),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Primary Country"]),
            ("02", "Organization", ["Legal Name", "Legal Entity Customer Exclusion Basis"]),
            ("02", "Legal Entity Hierarchy", ["Subsidiary Party", "Direct Parent", "Ultimate Parent", "Hierarchy Effective From",
                                              "Hierarchy Effective To"]),
            ("02", "KYC Profile", ["KYC Status", "AML Risk Rating", "Due Diligence Level", "PEP Status",
                                   "Sanctions Screening Result", "Last Screening Date", "Next KYC Review Date"]),
            ("02", "Identity Verification", ["Identity Verification ID", "Verified Party", "CIP Program", "Verification Method",
                                             "Verification Result", "Verification Date", "Discrepancy Resolution",
                                             "Government List Check Date"]),
            ("02", "Beneficial Ownership Certification", ["Beneficial Ownership Certification ID", "Certified Entity",
                                                          "Certification Date", "Certification Status",
                                                          "Recertification Due Date"]),
            ("02", "Beneficial Ownership", ["Ownership Certification", "Beneficial Owner", "Ownership Prong",
                                            "Beneficial Ownership Percentage", "Owner Identity Verification"]),
            ("02", "Tax Profile", ["US Person Indicator", "Tax Classification", "Nonresident Alien Indicator", "FATCA Status"]),
            ("02", "Regulatory Classification", ["Classified Party", "Categorization Date", "Reg BI Retail Customer Indicator",
                                                 "FINRA Institutional Account Indicator", "Investor Category"]),
            ("02", "Client Restriction", ["Client Restriction ID", "Restricted Party", "Restricted Accounts", "Restriction Category",
                                          "Restriction Source", "Excluded Instruments", "Restriction Status",
                                          "Restriction Effective From", "Restriction Effective To"]),
            ("02", "Restricted Client Status", ["Status Party", "Restricted Client Status", "Restricted Status Reason",
                                                "Status Effective From", "Status Effective To", "Status Next Review Date",
                                                "Status Approved By"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Imposed By", "Account Restriction Effective From",
                                           "Account Restriction Lifted Date", "Lift Approved By", "Restriction Review Due Date",
                                           "Restriction Scope"]),
            ("15", "New Issue Eligibility", ["Rule 5130 Status", "Rule 5131 Covered Person Indicator", "New Issue Certification Date",
                                             "New Issue Recertification Due Date"]),
            ("15", "Account Tax Certification", ["Tax Certification ID", "Certified Account", "Tax Form Type",
                                                 "TIN Certification Status", "Certification Expiry Date"]),
            ("15", "Account Tax Reporting Status", ["Backup Withholding Indicator"]),
        ],
        upstream=["DP-240", "DP-093", "DP-322", "DP-004", "DP-097", "DP-013"],
        refresh="Intraday",
        timeliness="New or lifted restrictions, restricted-client statuses, sanctions results and protection flags applied within 1 hour of approval; full rebuild by 6am ET daily",
        history="SCD type 2 on eligibility status and every restriction; CIP and CDD records kept 5 years after the account closes (31 CFR 1023.220 and 1010.230), account records 6 years (SEC Rule 17a-4); daily snapshots kept as evidence of what consumers were given",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["API", "Event stream", "Reverse ETL to CRM", "Warehouse table"],
        dq_rules=[
            "Every Restricted Party, Status Party, Verified Party and Certified Entity resolves to a DP-240 party, every Restricted Account and Certified Account to a DP-093 account, and every Excluded Instruments value to a DP-097 instrument or DP-004 share class.",
            "Restricted Client Status periods of one party do not overlap, Client Restriction and Legal Entity Hierarchy effective-to dates are on or after their starts, and Account Restriction Lifted Date is on or after Account Restriction Effective From.",
            "No party with Sanctions Screening Result = Confirmed Match or Restricted Client Status = Prohibited has Eligibility Status other than Excluded, and the counts of excluded, conditional and eligible parties sum to the DP-240 client parties in scope (missing KYC yields Conditional, never Eligible).",
            "Every party with an owner role on an open account has KYC Status, AML Risk Rating and Next KYC Review Date populated, and every active Client Restriction has Restriction Category and Restriction Source populated.",
            "Extraction filter for the whole product: 15 Account Restriction rows with Account Restriction Type = Financial Exploitation are excluded at extraction for every measure, flag and reason (they reach this product only as Protection Flag Present (from DP-322)), and the free-text Account Restriction Reason is not read; consumers receive Eligibility Status, Eligibility Reason, Account Dealing Block Flag and the restricted product scope, and the named AML consumers DP-180 and DP-226 also receive AML Risk Rating and PEP Status; beneficial owners, tax status and the other KYC detail stay in the Restricted - Personal Data view; TINs and document numbers are not read.",
            "Status changes are published within 1 hour of approval and a published daily snapshot is never rewritten.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: financial (KYC, beneficial ownership and "
               "tax status; criminal-offense-adjacent screening results restricted). " + FLAG_NOTE +
               "Publication (DQ5): consumers get status, reason, dealing block and restricted product scope; AML Risk Rating and "
               "PEP Status are kept published to DP-180 and DP-226, which read them through this product (semantic "
               "out/products/DP-180.yaml sources them here). One extraction filter for the whole product excludes Financial "
               "Exploitation account restriction rows. Scope: the firm "
               "performs CIP and KYC on parties it onboards directly; for intermediary-sold fund accounts KYC is the "
               "intermediary's or the transfer agent's and only notified restrictions appear. Boundaries: DP-240 publishes the "
               "KYC, CIP and beneficial ownership counts (KYC Incomplete or Overdue, CIP Verification Gap, Beneficial Ownership "
               "Coverage %, Open Client Restrictions); DP-093 Open Restrictions; this product reduces them to one status and "
               "never republishes those counts. AML cases are DP-226's; the guideline and SMA restriction coding is DP-130's and "
               "DP-161's; shareholder CIP alerts DP-180's; those four live dependents keep pointing at this id. Operating model "
               "(CD-297): with an outsourced transfer agent, fund-only CIP stays with the agent and this product reads the "
               "oversight result through the same 02 Identity Verification rows. Tailoring lever: beneficial ownership threshold. "
               "Reference default: 25% (FinCEN CDD rule; confirm against the Corporate Transparency Act changes). Tailoring "
               "lever: whether PEP status alone makes a client conditional. Reference default: yes. Taxonomy gap: there is no "
               "object for sanctions or PEP screening matches (list, match score, disposition, reviewer); only the current "
               "Sanctions Screening Result is held. Taxonomy gap: 02 KYC Profile and Tax Profile are attribute groups with no "
               "party key of their own; their join to Party ID is implicit. Drafting assumptions: Restriction Category groupings "
               "for exclusion and condition; KYC Status Complete; owner Account Role Types; 25% threshold; 1-hour latency. "
               "Decisions: CW-003, CW-021, CW-210, CW-213, CD-297, CD-344. WP1 re-scope (CW-210): name kept (Client Eligibility, "
               "KYC & Restrictions Status), owning domain 02, primary function FN-13 to FN-62 as registered. Inputs dropped: 08 "
               "Distributor Due Diligence and Due Diligence Outcome (distributor firms are 05 roles; any distributor eligibility "
               "is the channel products'), 02 Onboarding Case (DP-240 reads it), 02 Tax Profile Tax Identification Number, CRS "
               "Entity Classification, Tax Form Type and GIIN (removed or not needed; EU and UK regimes removed, CW-003), 02 "
               "Client Restriction Restricted Products / Strategies, Exclusion List Reference, Restriction Evidence and "
               "Restriction Description (replaced by Excluded Instruments). Inputs added: 02 Identity Verification, Beneficial "
               "Ownership Certification, Regulatory Classification and Organization; 15 New Issue Eligibility, Account Tax "
               "Certification and Account Tax Reporting Status; DP-322 for the protection flag. Measures kept by name: Eligibility "
               "Status, Eligibility Reason, Inherited Exclusion Flag, Account Dealing Block Flag, KYC Overdue Flag, Beneficial "
               "Ownership Complete Flag, Tax Classification Complete Flag, Restriction Review Overdue Count (rules rewritten for "
               "the US: the distributor due diligence branch, the EU AMLD and UK MLRs thresholds and CRS are gone). Measures "
               "added: CIP Verification Pending Flag, Reg BI Classification Missing, New Issue Restricted Accounts, Excluded and "
               "Conditional Parties, Protection Flag Present (from DP-322). Dimensions: 'Party and party type' now from DP-240, "
               "'Restricted products / strategies' becomes 'Restricted products and instruments'. Upstream: DP-001, DP-002, "
               "DP-003, DP-037, DP-007 and DP-009 dropped (DP-002 retired into DP-001; none is needed); DP-240, DP-093, DP-322 and "
               "DP-097 added. Readers for the lineage pass: data_models/models_077_pilot.py (Party conformed to DP-001 and the Fact "
               "Distributor Due Diligence and Fact Onboarding Case entities: re-conform Party to DP-240 and drop the two facts), "
               "models_c2_marketing_product.py and models_c1_sales.py notes, semantic SM-12 (KYC profile read through DP-077) "
               "and SM-04 notes; live upstream readers DP-130, DP-161, DP-180, DP-226 (and the then-pending DP-027, DP-028, DP-046 and DP-092, retired at WP0 and deleted at WP2). "
               "The W4 pending line is superseded."
               " WP2 retirement sweep (CW-209): SM-04, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-080": dict(
        definition=("The register of consumer privacy requests under US state privacy laws (know, access, delete, correct, opt "
                    "out of sale or sharing, limit use of sensitive personal information) with their statutory deadlines, the "
                    "GLBA exemption applied and their status, and the Regulation S-P, FCRA and Regulation S-AM opt-outs in force, "
                    "joined to the consents, preferences, digital identities and marketing leads that hold "
                    "the same person's data and to the 21 retention rules that override deletion. It evidences that requests "
                    "were answered on time and that opt-outs and deletions reached every record they must. It owns no certified "
                    "metric family."),
        business_questions=[
            "Which consumer privacy requests are open, how many days remain before the statutory due date, and which are overdue?",
            "What share of requests in each regime was closed by the statutory due date this quarter, and how many were answered under the GLBA exemption?",
            "After a deletion or an opt-out of sale or sharing, is the person still present in marketing leads, digital identities or sendable preferences?",
            "Are the browser opt-out signals, Regulation S-P sharing opt-outs and affiliate-marketing opt-outs applied to every record?",
            "Which deletion requests were limited by a retention requirement, and does each cite a governing rule?",
        ],
        grain=("Consumer privacy request (02, party x request received) x request status as-of date, with companion rows at "
               "party x opt-out (Privacy Profile) and party x holding record (consent, lead, visitor, suppression); daily status "
               "snapshots"),
        dimensions=["Request type", "Request regime", "Request status", "GLBA exemption applied", "Primary country and state",
                    "Party type (DP-240)", "Holding record (consent, lead, visitor, suppression)", "Retention record class (21)",
                    "Due month (DP-013)"],
        measures=[
            ("Days to Statutory Due Date",
             "Statutory Due Date - as-of date for requests whose Request Status is not in (Resolved / Completed, Closed, Rejected, "
             "Canceled), negative when overdue; Statutory Due Date is set at intake from Request Received Date and Request Regime "
             "(CCPA/CPRA: 45 calendar days, extendable once by 45 with notice; opt-out of sale or sharing and limit requests as "
             "soon as feasible and within 15 business days; other state laws per their statute).",
             _u("02", "Consumer Privacy Request", "Privacy Request ID", "Request Received Date", "Statutory Due Date",
                "Request Regime", "Request Status")),
            ("Overdue Request Flag",
             "Y when Request Status is not closed and the as-of date is after Statutory Due Date.",
             _u("02", "Consumer Privacy Request", "Statutory Due Date", "Request Status")),
            ("On-Time Closure Rate",
             "Requests whose Request Status first became Resolved / Completed or Closed on or before Statutory Due Date / requests "
             "closed in the period, by Request Regime and Request Type (closure date from the daily status snapshot).",
             _u("02", "Consumer Privacy Request", "Statutory Due Date", "Request Status", "Request Type", "Request Regime")),
            ("GLBA-Exempt Responses",
             "Count of requests closed with GLBA Exemption Applied Indicator = Y, by Request Type, and the share of the requester's "
             "data held under GLBA (Privacy Profile GLBA-Covered Data Indicator = Y): the data exempt from the state laws because "
             "it is held to provide a financial product.",
             _u("02", "Consumer Privacy Request", "GLBA Exemption Applied Indicator", "Request Type")
             + _u("02", "Privacy Profile", "GLBA-Covered Data Indicator", "Personal Data Categories Held")),
            ("Erasure Propagation Exceptions",
             "For each Delete request closed as completed without the GLBA exemption: count of remaining 04 Marketing Lead rows with "
             "Lead Party = the Requesting Party, Web Visitor / Known User rows with Matched Party = the party and Consent Record "
             "rows for the party with Consent Status = Granted, after the closure date; target zero.",
             _u("02", "Consumer Privacy Request", "Requesting Party", "Request Type", "Request Status")
             + _u("04", "Marketing Lead", "Lead ID", "Lead Party")
             + _u("04", "Web Visitor / Known User", "Visitor ID", "Matched Party")
             + _u("02", "Consent Record", "Consent Record ID", "Consenting Party", "Consent Status")),
            ("Suppression Coverage",
             "Read from DP-324 (Suppression Coverage %, the one owner of the test): the coverage DP-324 publishes, restricted to "
             "the Requesting Party of completed Delete and Opt Out of Sale / Sharing requests, so the person is not re-added from "
             "a list or a vendor load; never recomputed here.",
             _u("02", "Consumer Privacy Request", "Request Type", "Request Status", "Requesting Party")
             + _u("02", "Party", "Party ID")),
            ("Opt-Out Applied Flag",
             "For an Opt Out of Sale / Sharing or Limit Use of Sensitive Personal Information request closed as completed: Y when "
             "Sale / Sharing Opt-Out Indicator = Y on the party's Privacy Profile, marketing Communication Preference rows show an "
             "Opt-Out Timestamp on or before closure, and Consent Records of Consent Purpose Third-Party Data Sharing (FDX) are "
             "Withdrawn.",
             _u("02", "Privacy Profile", "Sale / Sharing Opt-Out Indicator")
             + _u("02", "Communication Preference", "Preference Party", "Opt-In Status", "Opt-Out Timestamp")
             + _u("02", "Consent Record", "Consent Purpose", "Consent Status", "Consent Withdrawn Timestamp")
             + _u("02", "Consumer Privacy Request", "Request Type")),
            ("Browser Opt-Out Signals Not Applied",
             "Count of 04 Tracking Consent Choice rows with Sale / Sharing Opt-Out Signal Indicator = Y whose Choice Visitor is a "
             "known user (Matched Party populated) whose Privacy Profile Sale / Sharing Opt-Out Indicator is not Y within 15 "
             "business days of the Choice Timestamp (global privacy control honored as an opt-out request).",
             _u("04", "Tracking Consent Choice", "Choice Visitor", "Choice Timestamp", "Sale / Sharing Opt-Out Signal Indicator")
             + _u("04", "Web Visitor / Known User", "Visitor ID", "Matched Party", "Applied Tracking Consent")
             + _u("02", "Privacy Profile", "Sale / Sharing Opt-Out Indicator")),
            ("Regulation S-P and S-AM Opt-Outs in Force",
             "Count of parties with Nonaffiliated Sharing Opt-Out Indicator = Y (GLBA, Regulation S-P) and with Affiliate "
             "Marketing Opt-Out Indicator = Y and Affiliate Marketing Opt-Out Expiry Date on or after the as-of date (FCRA, "
             "Regulation S-AM), with the count of clients whose Initial Privacy Notice is blank.",
             _u("02", "Privacy Profile", "Nonaffiliated Sharing Opt-Out Indicator", "Affiliate Marketing Opt-Out Indicator",
                "Affiliate Marketing Opt-Out Expiry Date", "Initial Privacy Notice", "Applicable Privacy Regimes")),
            ("Initial Privacy Notices Not Delivered",
             "Client parties whose Initial Privacy Notice resolves to a 13 Investor Document with Delivered Date blank or after the "
             "first account's opening plus 30 days (Regulation S-P initial notice).",
             _u("02", "Privacy Profile", "Initial Privacy Notice")
             + _u("13", "Investor Document", "Investor Document ID", "Delivered Date", "Delivery Status")),
            ("Retention-Limited Deletions",
             "Delete requests closed with data kept under a retention requirement, by the 21 Retention Rule Record Class and "
             "Governing Requirement applied (for example SEC Rule 17a-4 and Rule 204-2 customer and advisory records), with the "
             "count citing no active Retention Rule (Retention Rule Status active).",
             _u("21", "Retention Rule", "Retention Rule ID", "Record Class", "Governing Requirement", "Retention Period (Years)",
                "Retention Trigger", "Retention Rule Status")
             + _u("02", "Consumer Privacy Request", "Request Type", "Request Status")),
        ],
        inputs=[
            ("02", "Consumer Privacy Request", ["Privacy Request ID", "Requesting Party", "Request Type", "Request Regime",
                                                "Request Received Date", "Statutory Due Date",
                                                "GLBA Exemption Applied Indicator", "Request Status"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status", "Primary Country"]),
            ("02", "Privacy Profile", ["Applicable Privacy Regimes", "Personal Data Categories Held", "GLBA-Covered Data Indicator",
                                       "Nonaffiliated Sharing Opt-Out Indicator", "Affiliate Marketing Opt-Out Indicator",
                                       "Affiliate Marketing Opt-Out Expiry Date", "Sale / Sharing Opt-Out Indicator",
                                       "Do Not Contact Indicator", "Initial Privacy Notice"]),
            ("02", "Consent Record", ["Consent Record ID", "Consenting Party", "Consent Purpose", "Consent Status",
                                      "Consent Withdrawn Timestamp", "Data Recipient"]),
            ("02", "Communication Preference", ["Preference Party", "Preference Topic", "Preference Channel", "Opt-In Status",
                                                "Opt-Out Timestamp"]),
            ("04", "Web Visitor / Known User", ["Visitor ID", "Identity Namespace", "Matched Party", "Applied Tracking Consent"]),
            ("04", "Tracking Consent Choice", ["Choice Visitor", "Choice Timestamp", "Choice Source",
                                               "Sale / Sharing Opt-Out Signal Indicator"]),
            ("04", "Marketing Lead", ["Lead ID", "Lead Party", "Lead Source"]),
            ("21", "Retention Rule", ["Retention Rule ID", "Record Class", "Governing Requirement", "Retention Period (Years)",
                                      "Retention Trigger", "Retention Rule Status"]),
            ("13", "Investor Document", ["Investor Document ID", "Delivered Date", "Delivery Status"]),
        ],
        upstream=["DP-240", "DP-324", "DP-011", "DP-382", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day, covering requests and record changes to the prior day's close",
        history="Daily request status snapshots kept for the life of the request plus 3 years as evidence of handling (CCPA regulations require 24 months of request records); deleted parties carried only as a pseudonymous request key and suppression hash",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "API"],
        dq_rules=[
            "Every Requesting Party resolves to a DP-240 party or to a recorded unverified-requester key, and every Matched Party, Lead Party and Consenting Party read to a DP-240 party.",
            "Statutory Due Date is on or after Request Received Date and no later than the regime's maximum period from receipt including extension (CCPA/CPRA 90 calendar days).",
            "No party with a completed Delete request without the GLBA exemption appears as Lead Party, Matched Party or a Granted Consent Record after the closure date, unless a Retention Rule is cited for the record class.",
            "Request Type, Request Regime, Request Received Date, Statutory Due Date and Request Status are populated on every Consumer Privacy Request.",
            "The register is visible only to the Privacy Officer's team and data stewards; requests of deleted parties are published only by pseudonymous key; captured emails and names of leads are not read.",
            "The daily status snapshot is published by 7am ET and never rewritten; closure dates are taken from the first snapshot showing a closed status.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: identity (the people who exercised their "
               "rights, joined across systems); Restricted - Personal Data. Boundaries: DP-324 is the operational contact rule set "
               "(permissions, suppression timeliness); this product is the evidence register of privacy requests and opt-out "
               "handling. Consent, preferences and opt-outs are mastered in 02 and read from there; DP-011 publishes the 04 digital "
               "identities. Regulatory retention (SEC Rule 17a-4, Rule 204-2) overrides deletion for in-scope records through 21 "
               "Retention Rule. Tailoring lever: state privacy regimes in scope (02 SME 8). Reference default: CCPA/CPRA and the "
               "other comprehensive state laws, with GLBA-covered data exempt. Tailoring lever: honoring browser opt-out signals. "
               "Reference default: honored as opt-out of sale or sharing for known users. Taxonomy gap: 02 Consumer Privacy "
               "Request has no completion date, outcome, identity verification status or extension notice; closure is inferred "
               "from daily snapshots. Taxonomy gap: there is no record of which systems a deletion or correction reached; "
               "Erasure Propagation Exceptions checks only the 02 and 04 objects read. Taxonomy gap: no link from a request to the "
               "21 Retention Rule applied, so Retention-Limited Deletions is matched by record class. Taxonomy gap: 02 Privacy "
               "Profile is an attribute group with no party key of its own. Drafting assumptions: the closed Request Status "
               "values; the statutory periods; 15 business days for opt-outs; 30 days for the initial privacy notice. Decisions: "
               "CW-003, CW-210, CW-213. WP1 re-scope (CW-210): name kept (Consumer Privacy Rights & Opt-Out Evidence), owning "
               "domain 02, primary function FN-17 to FN-62 as registered. GDPR and UK GDPR removed (US only, CW-003). Inputs "
               "dropped: 02 Data Subject Request, Retention and Processing Legal Basis (removed from 02), 08 Retention Rule (moved "
               "to 21), 14 Dataset (licensed vendor datasets of intermediary advisors; vendor data governance is DP-044's, re-scoped with DP-519's scope), 04 "
               "Marketing Lead Captured Email. Inputs added: 02 Consumer Privacy Request, 04 Tracking Consent Choice, 21 Retention "
               "Rule, 13 Investor Document, and the Privacy Profile GLBA, S-P and S-AM attributes. Measures kept by name: Days to "
               "Statutory Due Date, Overdue Request Flag, On-Time Closure Rate, Erasure Propagation Exceptions, Suppression "
               "Coverage (rules rewritten for the US regimes; Suppression Coverage is now read from DP-324's Suppression "
               "Coverage %, which owns the test, and DP-324 is added upstream). Measures dropped: Objection Applied Flag (renamed Opt-Out Applied "
               "Flag), Erasure Backlog (the 02 Retention schedule no longer exists; replaced by Retention-Limited Deletions). "
               "Measures added: GLBA-Exempt Responses, Browser Opt-Out Signals Not Applied, Regulation S-P and S-AM Opt-Outs in "
               "Force, Initial Privacy Notices Not Delivered, Retention-Limited Deletions. Upstream: DP-002 (retired), DP-003, "
               "DP-028 (retired), DP-044 (re-scoped with DP-519's scope; not needed) and DP-075 dropped; DP-240, DP-011, DP-382 kept or added. Readers for the "
               "lineage pass: data_models/models_c5_advisor_privacy.py DP-080 model (entities for Data Subject Request, "
               "Retention, Processing Legal Basis and Dataset to drop; Party to conform to DP-240); no live product lists DP-080 "
               "upstream. The W4 pending line is superseded."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-351": dict(
        definition=("Every fiduciary account review 12 CFR 9.6 requires of the trust company (pre-acceptance, initial "
                    "post-acceptance within 60 days, annual investment review) with due and completed dates, the exceptions "
                    "raised and cleared, the conflicts they cite (12 CFR 9.12), and the trust's roles, terms and investment "
                    "constraint provisions tested against their 46 implementation. Trust management and the trust committee "
                    "track late reviews and open exceptions. The fiduciary facts are DP-307's; optional with the trust line (TR). "
                    "It owns no certified metric family."),
        business_questions=[
            "Which discretionary trusts missed their annual investment review this calendar year, and which initial post-acceptance reviews were late?",
            "Were pre-acceptance reviews completed before the trust company accepted each appointment?",
            "Which review exceptions are open, how severe and how old are they, and which involve conflicts or self-dealing?",
            "Which investment constraint provisions of trust instruments are not implemented as 46 constraints on the trust's accounts?",
            "How is the review workload spread across trust officers and committees?",
        ],
        grain="Fiduciary account review (FIRV-; trust x review type x due date) with its exceptions as companion rows; daily, calendar-year compliance snapshot locked in January",
        dimensions=["Trust (DP-307)", "Trust officer (DP-009)", "Reviewer (DP-192)", "Fiduciary review type",
                    "Investment discretion", "Review exception type and severity", "Revocability and situs",
                    "Client account (DP-093)", "Review due date (DP-013)"],
        measures=[
            ("Reviews Due",
             "Count of Fiduciary Review ID with Review Due Date in the period, by Fiduciary Review Type and Investment Discretion "
             "Indicator.",
             _u("51", "Fiduciary Account Review", "Fiduciary Review ID", "Review Trust", "Fiduciary Review Type",
                "Investment Discretion Indicator", "Review Due Date")),
            ("Late Review Rate %",
             "Reviews Due completed with Review Completed Date after Review Due Date, plus those not completed by the as-of date "
             "after their due date / Reviews Due.",
             _u("51", "Fiduciary Account Review", "Review Completed Date", "Review Due Date") + ["Reviews Due"]),
            ("Discretionary Trusts Without Annual Review",
             "Trusts with Trust Status = Active and a trust company Trust Role (Role Holder Entity populated, Trust Role Type in "
             "Trustee, Co-Trustee, Directed Trustee) in effect, with a review of Investment Discretion Indicator = Y in their "
             "history, that have no review of Fiduciary Review Type = Annual Investment Review (9.6(c)) completed in the calendar "
             "year.",
             _u("51", "Trust", "Trust ID", "Trust Status")
             + _u("51", "Trust Role", "Role Trust", "Trust Role Type", "Role Holder Entity", "Role Effective From", "Role Effective To")
             + _u("51", "Fiduciary Account Review", "Review Trust", "Fiduciary Review Type", "Investment Discretion Indicator",
                  "Review Completed Date")),
            ("Late Post-Acceptance Reviews",
             "Trust company appointments (Trust Role with Role Holder Entity and Role Acceptance Date) whose Initial "
             "Post-Acceptance Review (9.6(b)) was completed more than 60 days after Role Acceptance Date, or is not completed 60 "
             "days after it.",
             _u("51", "Trust Role", "Role Trust", "Role Holder Entity", "Role Acceptance Date")
             + _u("51", "Fiduciary Account Review", "Review Trust", "Fiduciary Review Type", "Review Completed Date")),
            ("Acceptances Without Pre-Acceptance Review",
             "Trust company appointments with Role Acceptance Date in the period and no Pre-Acceptance Review (9.6(a)) of the trust "
             "completed on or before Role Acceptance Date.",
             _u("51", "Trust Role", "Role Acceptance Date", "Role Holder Entity")
             + _u("51", "Fiduciary Account Review", "Fiduciary Review Type", "Review Completed Date")),
            ("Open Review Exceptions",
             "Count of Fiduciary Review Exception rows with Exception Resolved Date blank, by Review Exception Type and Exception "
             "Severity, with the median days since the review's Review Completed Date.",
             _u("51", "Fiduciary Review Exception", "Exception Review", "Exception Sequence", "Review Exception Type",
                "Exception Severity", "Required Action", "Exception Resolved Date")
             + _u("51", "Fiduciary Account Review", "Review Completed Date")),
            ("Aged High-Severity Exceptions",
             "Open Review Exceptions of Exception Severity in (High, Critical) more than 90 days after the review was completed.",
             _u("51", "Fiduciary Review Exception", "Exception Severity") + ["Open Review Exceptions"]),
            ("Exception Resolution Days",
             "Median days from Review Completed Date to Exception Resolved Date for exceptions resolved in the period, by Review "
             "Exception Type.",
             _u("51", "Fiduciary Review Exception", "Review Exception Type", "Exception Resolved Date")
             + _u("51", "Fiduciary Account Review", "Review Completed Date")),
            ("Conflict Exceptions",
             "Exceptions with Review Exception Type = Self-Dealing or Conflict or with Related Conflict populated (12 CFR 9.12), "
             "open and raised in the period.",
             _u("51", "Fiduciary Review Exception", "Review Exception Type", "Related Conflict", "Exception Resolved Date")),
            ("Constraint Provisions Not Implemented",
             "Trust Term Provision rows with Investment Constraint Indicator = Y in effect (Provision Effective From / To) for which "
             "no active 46 Account Investment Constraint (Constraint Status active, in effect) on an open account of the trust "
             "(15 Account Registration Detail Governing Trust = Trust ID) has Source Trust Term Provision = the provision.",
             _u("51", "Trust Term Provision", "Provision Trust", "Provision Type", "Provision Sequence",
                "Investment Constraint Indicator", "Provision Effective From", "Provision Effective To")
             + _u("46", "Account Investment Constraint", "Constrained Account", "Source Trust Term Provision", "Constraint Type",
                  "Constraint Status", "Constraint Effective From", "Constraint Effective To")
             + _u("15", "Account Registration Detail", "Governing Trust")
             + _u("15", "Account", "Account ID", "Account Status")),
            ("Discretionary Reviews Without Committee",
             "Completed reviews with Investment Discretion Indicator = Y and Reviewing Committee blank, or with Review Conclusion "
             "blank.",
             _u("51", "Fiduciary Account Review", "Investment Discretion Indicator", "Reviewing Committee", "Review Conclusion",
                "Review Completed Date")),
            ("Reviews Due per Trust Officer",
             "Reviews Due and the overdue share per Administering Trust Officer of the reviewed trust.",
             _u("51", "Trust", "Administering Trust Officer") + ["Reviews Due", "Late Review Rate %"]),
        ],
        inputs=[
            ("51", "Fiduciary Account Review", ["Fiduciary Review ID", "Review Trust", "Fiduciary Review Type",
                                                "Investment Discretion Indicator", "Accounts Reviewed", "Reviewer",
                                                "Reviewing Committee", "Review Due Date", "Review Completed Date",
                                                "Review Conclusion"]),
            ("51", "Fiduciary Review Exception", ["Exception Review", "Exception Sequence", "Review Exception Type",
                                                  "Exception Severity", "Required Action", "Related Conflict",
                                                  "Exception Resolved Date"]),
            ("51", "Trust", ["Trust ID", "Trust Party", "Revocability", "Situs Jurisdiction", "Administering Trust Officer",
                             "Trust Status"]),
            ("51", "Trust Role", ["Role Trust", "Trust Role Type", "Role Holder Party", "Role Holder Entity", "Role Acceptance Date",
                                  "Role Effective From", "Role Effective To"]),
            ("51", "Trust Term Provision", ["Provision Trust", "Provision Type", "Provision Sequence",
                                            "Investment Constraint Indicator", "Provision Effective From",
                                            "Provision Effective To"]),
            ("46", "Account Investment Constraint", ["Constrained Account", "Source Trust Term Provision", "Constraint Type",
                                                     "Constraint Status", "Constraint Effective From", "Constraint Effective To"]),
            ("15", "Account Registration Detail", ["Governing Trust"]),
            ("15", "Account", ["Account ID", "Account Status"]),
        ],
        upstream=["DP-307", "DP-304", "DP-093", "DP-009", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET daily; the calendar-year review compliance snapshot locked on business day 10 of January",
        history="Reviews and exceptions kept 10 years after the trust terminates (firm policy; 12 CFR 9.8 requires 3 years); calendar-year snapshots kept",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "BI semantic model"],
        dq_rules=[
            "Every Review Trust resolves to a DP-307 trust, every Reviewer to a DP-192 employee, every Administering Trust Officer to a DP-009 advisor or trust officer, and every Constrained Account to a DP-093 account.",
            "Trust Role periods of one trust, holder and role type do not overlap, Provision Effective To is on or after Provision Effective From, and Review Completed Date is on or after the trust company's Role Acceptance Date except for pre-acceptance reviews.",
            "Reviews Due and the overdue reviews reconcile to DP-307's Overdue Fiduciary Reviews for the as-of date, review for review.",
            "Fiduciary Review Type and Review Due Date are populated on every review, and Review Exception Type and Exception Severity on every exception.",
            "Trust Term Provision rows of Provision Type = Special Needs Purpose are excluded at extraction (CD-344; DP-352's restricted view) and Trust Instrument Type is not read; trust-level rows are visible only to trust management and the trust committee; aggregates with fewer than 10 trusts are suppressed.",
            "The calendar-year compliance snapshot is locked on business day 10 of January and never rewritten.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). Operating model (CD-297, CD-331): trust "
               "administration is in house by default; the review grain stays the trust company's own review record if trust "
               "operations are outsourced. PII tier: identity. Special-needs provisions excluded (DQ5). Boundaries: DP-307 "
               "publishes the trusts, roles, provisions and reviews and the measures Overdue Fiduciary Reviews and Investment "
               "Constraint Provisions, which are not redefined; 46 constraints are DP-304's. Conflicts are 38's (Related "
               "Conflict). Objects of the candidate: 46 Model Assignment not read (a missing model is not a review finding; "
               "DP-304 publishes assignments); 51 Trust Instrument Document is not read (instrument completeness is DP-307's Trusts Without Instrument Document). Tailoring lever: "
               "trust line offered (plan section 15 item 2). Reference default: offered; without it this product drops. "
               "Tailoring lever: post-acceptance deadline (51 SME 5). Reference default: 60 days (12 CFR 9.6(b)). Tailoring "
               "lever: trust company charter. Reference default: 12 CFR Part 9 applied as the standard; a state charter's rules "
               "are a tailoring of the dates. Taxonomy gap: 51 Fiduciary Account Review has no exception count or committee "
               "decision date. Drafting assumptions: trust company role types; 60 and 90-day windows; minimum cell size 10; "
               "January lock. Decisions: CW-018, CW-075, CW-076, CW-213, CD-297, CD-344. WP1 new (CW-205): first specification, "
               "written last as a tailoring lever."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-352": dict(
        definition=("Each discretionary distribution request with the beneficiary's interest, the distribution standard of the "
                    "governing provision, the decision, its authority and approver against the delegated limit, the other "
                    "resources considered and the payment that followed (50). It is the named restricted view of trust "
                    "distribution purposes (CW-213): it alone reads the special-category purposes (health, disability, hardship) "
                    "and the special-needs provisions, shows them only in its restricted view, and publishes the coded purpose "
                    "group elsewhere. Trust officers work open requests; the trust committee sees decisions above limits and the "
                    "standard cited. Optional with the trust line. It owns no certified metric family."),
        business_questions=[
            "Which distribution requests are open and how long have they waited, including requests for medical, disability or hardship needs?",
            "What share of requests was approved, for how much, by which authority, and which approvals exceeded the officer's delegated limit?",
            "Did each decision cite the governing distribution standard, consider the beneficiary's other resources and record a rationale?",
            "Were supplemental-needs trusts kept to supplemental purposes, and were principal distributions made only where the instrument allows?",
            "Which approved distributions have not been paid, and which decisions were made by an interested co-trustee?",
        ],
        grain="Trust distribution request (TDRQ-) with its latest decision and the resulting 50 money movement; daily, decisions locked when paid or declined",
        dimensions=["Trust (DP-307)", "Beneficiary (DP-240)", "Distribution purpose (restricted view) and purpose group",
                    "Distribution standard (restricted view for supplemental needs)", "Distribution decision and decision authority",
                    "Decided by (DP-192)", "Distribution source (principal or income)", "Received and decision dates (DP-013)"],
        measures=[
            ("Distribution Requests Received",
             "Count and sum of Requested Amount of Trust Distribution Request rows with Request Received Date in the period, by "
             "Distribution Purpose in the restricted view and by purpose group (Restricted Purpose for Health / Medical, Disability "
             "Care and Hardship / Emergency; the coded value otherwise) in the default view.",
             _u("51", "Trust Distribution Request", "Distribution Request ID", "Request Trust", "Request Beneficiary",
                "Distribution Purpose", "Requested Amount", "Request Received Date")),
            ("Open Requests Aging",
             "Requests with Request Status not in (Resolved / Completed, Closed, Rejected, Canceled) on the as-of date by age band "
             "from Request Received Date (0-10, 11-30, over 30 days) and by the trust's Administering Trust Officer, including "
             "restricted-purpose requests DP-307 leaves out.",
             _u("51", "Trust Distribution Request", "Request Trust", "Request Status", "Request Received Date", "Intake Service Request")
             + _u("51", "Trust", "Trust ID", "Trust Status", "Administering Trust Officer")),
            ("Decision Turnaround Days",
             "Median days from Request Received Date to Decision Date over decisions dated in the period, by Decision Authority.",
             _u("51", "Distribution Decision", "Decision Request", "Decision Date", "Decision Authority")
             + _u("51", "Trust Distribution Request", "Request Received Date")),
            ("Approval Rate %",
             "Decisions in (Approved, Approved - Reduced Amount, Approved with Conditions) / decisions other than Deferred - "
             "Information Requested, dated in the period, by purpose group (Distribution Purpose; restricted values grouped in the "
             "default view) and the Distribution Standard of the Provision Applied.",
             _u("51", "Distribution Decision", "Distribution Decision", "Decision Date", "Provision Applied", "Decision Request")
             + _u("51", "Trust Distribution Request", "Distribution Request ID", "Distribution Purpose")
             + _u("51", "Trust Term Provision", "Distribution Standard")),
            ("Approved Amount",
             "Sum of Approved Amount of approved decisions dated in the period, by Decision Authority and Distribution Source, with "
             "the ratio to Requested Amount.",
             _u("51", "Distribution Decision", "Approved Amount", "Distribution Source", "Decision Authority")
             + _u("51", "Trust Distribution Request", "Requested Amount")),
            ("Decisions Above Delegated Limit",
             "Approved decisions with Decision Authority = Trust Officer (Within Delegated Limit) and Approved Amount above the "
             "delegated limit, or with Decided By blank.",
             _u("51", "Distribution Decision", "Decision Authority", "Approved Amount", "Decided By")),
            ("Decisions Without Standard Cited",
             "Decisions whose Provision Applied is blank or does not resolve to a Trust Term Provision of the request's trust of "
             "Provision Type in (Distribution Standard - Income, Distribution Standard - Principal, Special Needs Purpose) in effect "
             "on Decision Date.",
             _u("51", "Distribution Decision", "Provision Applied", "Decision Date")
             + _u("51", "Trust Term Provision", "Provision Trust", "Provision Type", "Provision Sequence",
                  "Provision Effective From", "Provision Effective To")),
            ("Decisions Inconsistent With Standard",
             "Approved decisions with Distribution Source = Principal or Split under a provision of Provision Type = Distribution "
             "Standard - Income only; decisions on a provision of Distribution Standard = Mandatory All Income or Mandatory Fixed "
             "Amount treated as discretionary; and, in the restricted view, approvals under Distribution Standard = Supplemental "
             "Needs Only for Distribution Purpose = Maintenance and Support or Housing (a risk to the beneficiary's means-tested "
             "benefits).",
             _u("51", "Distribution Decision", "Distribution Source", "Distribution Decision", "Provision Applied")
             + _u("51", "Trust Term Provision", "Provision Type", "Distribution Standard")
             + _u("51", "Trust Distribution Request", "Distribution Purpose")),
            ("Other Resources Not Considered",
             "Approved decisions under a provision with Distribution Standard in (HEMS (Ascertainable Standard), Supplemental Needs "
             "Only, Best Interests / Welfare) whose Other Resources Considered Indicator is not Y.",
             _u("51", "Distribution Decision", "Other Resources Considered Indicator")
             + _u("51", "Trust Term Provision", "Distribution Standard")),
            ("Decisions Without Rationale",
             "Decisions dated in the period with Decision Rationale blank (presence tested; the text is not published).",
             _u("51", "Distribution Decision", "Decision Rationale", "Decision Date")),
            ("Requests From Non-Beneficiaries",
             "Requests whose Request Beneficiary has no Beneficial Interest in the trust (Interest Trust, Beneficiary Party) in "
             "effect on Request Received Date with a current Beneficial Interest Type (Current Income, Current Principal, Current "
             "Income and Principal, Unitrust or Annuity Recipient).",
             _u("51", "Beneficial Interest", "Interest Trust", "Beneficiary Party", "Beneficial Interest Type",
                "Interest Share Percentage", "Interest Effective From", "Interest Effective To")
             + _u("51", "Trust Distribution Request", "Request Beneficiary", "Request Received Date")),
            ("Approved Not Paid",
             "Approved decisions with no settled 50 Money Movement (Source Trust Distribution Request = Distribution Request ID, "
             "Money Movement Status = Settled) within 10 business days of Decision Date, and paid amounts that differ from "
             "Approved Amount; count and amount.",
             _u("50", "Money Movement", "Money Movement ID", "Movement Account", "Movement Amount", "Value Date",
                "Money Movement Status", "Source Trust Distribution Request")
             + _u("51", "Distribution Decision", "Approved Amount", "Decision Date")),
            ("Interested Trustee Decisions",
             "Decisions with Decision Authority = Co-Trustee Joint Decision on trusts where a co-trustee (Trust Role Type = "
             "Co-Trustee, Role Holder Party, in effect) is also the Request Beneficiary or holds a Beneficial Interest in the trust.",
             _u("51", "Trust Role", "Role Trust", "Trust Role Type", "Role Holder Party", "Role Effective From", "Role Effective To")
             + _u("51", "Distribution Decision", "Decision Authority")
             + _u("51", "Beneficial Interest", "Beneficiary Party")),
        ],
        inputs=[
            ("51", "Trust Distribution Request", ["Distribution Request ID", "Request Trust", "Request Beneficiary",
                                                  "Distribution Purpose", "Requested Amount", "Request Received Date",
                                                  "Intake Service Request", "Request Status"]),
            ("51", "Distribution Decision", ["Decision Request", "Distribution Decision", "Provision Applied", "Decision Authority",
                                             "Decided By", "Approved Amount", "Distribution Source",
                                             "Other Resources Considered Indicator", "Decision Rationale", "Decision Date"]),
            ("51", "Beneficial Interest", ["Interest Trust", "Beneficiary Party", "Beneficial Interest Type",
                                           "Interest Share Percentage", "Interest Effective From", "Interest Effective To"]),
            ("51", "Trust Term Provision", ["Provision Trust", "Provision Type", "Provision Sequence", "Distribution Standard",
                                            "Provision Effective From", "Provision Effective To"]),
            ("51", "Trust Role", ["Role Trust", "Trust Role Type", "Role Holder Party", "Role Holder Entity",
                                  "Role Effective From", "Role Effective To"]),
            ("51", "Trust", ["Trust ID", "Trust Status", "Administering Trust Officer"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Movement Amount", "Value Date",
                                      "Money Movement Status", "Source Trust Distribution Request"]),
        ],
        upstream=["DP-307", "DP-302", "DP-240", "DP-192", "DP-009", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET daily; decisions visible to the trust committee within 1 business day of recording",
        history="Requests and decisions kept 10 years after the trust terminates (firm policy; 12 CFR 9.8 requires 3 years), SCD type 2 on decision status",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table"],
        dq_rules=[
            "Every Request Trust resolves to a DP-307 trust, every Request Beneficiary and Role Holder Party to a DP-240 party, every Decided By to a DP-192 employee, and every paying money movement to DP-302.",
            "Each request has at most one current Distribution Decision, Beneficial Interest and Trust Role periods do not overlap for the same party and type, and Decision Date is on or after Request Received Date.",
            "Requests in the default view equal DP-307's published (non-special) distribution requests plus the restricted-purpose requests, count for count, and Approved Amount paid reconciles to the settled DP-302 trust distributions within USD 0.01.",
            "Distribution Decision, Decision Authority and Decision Date are populated on every decided request, and Requested Amount and Request Received Date on every request.",
            "Restricted-view rule: Distribution Purpose values Health / Medical, Disability Care and Hardship / Emergency, Provision Type = Special Needs Purpose and Distribution Standard = Supplemental Needs Only are shown only in the restricted view to trust officers and the trust committee (Restricted - Personal Data, CD-344); the default view shows 'Restricted Purpose'; Purpose Description is never read and Decision Rationale is tested for presence only; slices of fewer than 10 requests are suppressed.",
            "Decisions are locked once the payment settles or the request is declined, and a locked decision is never rewritten.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). PII tier: special category (CD-344) in the "
               "restricted view; financial in the default view. Named restricted view (CW-213): this product, not DP-322, holds "
               "the trust special-needs and medical purposes; DP-307 blanks and excludes them (WP1F ruling) and no other product "
               "reads them. DP-322 is not listed: its client protection facts are not needed for distribution decisions. "
               "Boundaries: DP-307 publishes the non-special requests (Open Distribution Requests, Distribution Request Age Days), "
               "which are not redefined; payments are 50 through DP-302. Tailoring lever: decision authority and delegated limits "
               "(51 SME 4). Reference default: trust officer up to USD 50,000 per request, senior trust officer up to USD 250,000, "
               "trust committee above. Tailoring lever: special-needs purposes recorded (51 SME 8). Reference default: recorded "
               "in 51 and shown only here. Taxonomy gap: no object holds the delegated distribution limit of an officer, so the "
               "limit is a drafting assumption. Taxonomy gap: 51 Distribution Decision has no paid date; payment is matched to 50 "
               "by Source Trust Distribution Request. Drafting assumptions: the limits; purpose groups; current interest types; "
               "10 business days to pay; minimum cell size 10. Decisions: CW-018, CW-075, CW-213, CD-344. WP1 new (CW-213): first "
               "specification, written last as a tailoring lever."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-353": dict(
        definition=("Principal and income accounting of every trust: each receipt and disbursement posted to the trust's accounts "
                    "(49 activity, 50 money movements, 47 trustee fees) and its principal and income allocation (51), the "
                    "fiduciary accounting statement of each period, and the principal and income cash that does not agree to "
                    "the 49 cash balance. Trust accounting closes periods and produces beneficiary accountings from it. Trust "
                    "accounting is a principal and income ledger, not a book of record (CW-076): holdings and cash stay 49's. "
                    "Optional with the trust line. It owns no certified metric family."),
        business_questions=[
            "Which posted receipts and disbursements of trust accounts have no principal and income allocation, and which allocations do not agree to their source activity?",
            "Does each trust's closing principal and income cash agree to the 49 cash balance of its accounts at period end?",
            "How are trustee fees charged between principal and income, and which fee debits are unallocated?",
            "Which mandatory-income trusts hold undistributed income or show income overdrawn?",
            "Which period statements are unapproved or their trustee reports late, and which court accountings are pending?",
        ],
        grain=("Trust x accounting period end (Fiduciary Accounting Statement), with principal and income allocations (trust x "
               "source event x sequence) and the source 49 activities as companions; daily allocation checks, period close "
               "monthly or as the instrument requires"),
        dimensions=["Trust (DP-307)", "Client account (DP-093)", "Receipt or disbursement type", "Allocation character",
                    "Allocation rule", "Statement approval status", "Accounting period end (DP-013)"],
        measures=[
            ("Unallocated Trust Activity",
             "Count and sum of Activity Net Amount of posted 49 Client Account Activity rows (Activity Status = Posted) of open "
             "trust accounts (15 Account Registration Detail Governing Trust populated) with Trade Date in the period and no "
             "Principal and Income Allocation whose Source Account Activity = Client Account Activity ID, by Activity Type.",
             _u("49", "Client Account Activity", "Client Account Activity ID", "Activity Account", "Activity Type", "Trade Date",
                "Activity Net Amount", "Activity Status")
             + _u("51", "Principal and Income Allocation", "Allocation Trust", "Source Account Activity")
             + _u("15", "Account Registration Detail", "Governing Trust")
             + _u("15", "Account", "Account ID", "Account Status")),
            ("Allocation Amount Breaks",
             "Allocations whose Principal Amount + Income Amount summed over the Allocation Sequence rows of one source event "
             "differs from the source Activity Net Amount (or 50 Movement Amount) by more than USD 0.01.",
             _u("51", "Principal and Income Allocation", "Source Account Activity", "Source Money Movement", "Allocation Sequence",
                "Principal Amount", "Income Amount")
             + _u("49", "Client Account Activity", "Activity Net Amount")
             + _u("50", "Money Movement", "Money Movement ID", "Movement Amount")),
            ("Trustee Fee Principal Share %",
             "Principal Amount / (Principal Amount + Income Amount) of allocations with Receipt or Disbursement Type = Trustee Fee "
             "in the period, by trust and Allocation Rule (the Uniform Principal and Income Act default charges half to each).",
             _u("51", "Principal and Income Allocation", "Receipt or Disbursement Type", "Principal Amount", "Income Amount",
                "Allocation Rule", "Allocation Date")),
            ("Unallocated Trustee Fees",
             "Posted 47 Fee Debits of Charged Fee Type = Trust Administration on trust accounts whose 49 Client Account Activity "
             "(Source Fee Debit = Fee Debit ID) has no allocation; count and Debit Amount.",
             _u("47", "Fee Debit", "Fee Debit ID", "Charged Fee Type", "Debited Account", "Debit Amount", "Debit Date",
                "Fee Debit Status")
             + _u("49", "Client Account Activity", "Source Fee Debit")
             + ["Unallocated Trust Activity"]),
            ("Principal and Income Cash Break",
             "Per trust and Accounting Period End: Closing Principal Cash + Closing Income Cash minus the sum of Cash Balance "
             "Amount under the DP-007 client cash rule (Balance Basis = Settlement Date and Cash Balance Type in (Free Credit Balance, Sweep Balance, Short Sale Proceeds), Cash Balance Business Date = Accounting Period End) of the trust's accounts "
             "(USD).",
             _u("51", "Fiduciary Accounting Statement", "Statement Trust", "Accounting Period Start", "Accounting Period End",
                "Closing Principal Cash", "Closing Income Cash")
             + _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type",
                  "Balance Basis", "Cash Balance Amount")),
            ("Trusts With Cash Break",
             "Count of trusts whose absolute Principal and Income Cash Break exceeds USD 1 at the latest period end, with the sum "
             "of absolute breaks.",
             ["Principal and Income Cash Break"]),
            ("Income Overdrawn Trusts",
             "Trusts with Closing Income Cash below zero at the period end.",
             _u("51", "Fiduciary Accounting Statement", "Closing Income Cash")),
            ("Undistributed Income on Mandatory-Income Trusts",
             "Sum of Undistributed Income at period end of trusts with a Trust Term Provision in effect of Distribution Standard = "
             "Mandatory All Income (the only provision rows extracted), with the count above zero.",
             _u("51", "Fiduciary Accounting Statement", "Undistributed Income", "Accounting Period End")
             + _u("51", "Trust Term Provision", "Provision Trust", "Distribution Standard", "Provision Effective From",
                  "Provision Effective To")),
            ("Statement Closing Market Value",
             "Per trust and period end: Market Value in USD of the trust accounts' End of Day 49 Client Holdings on Accounting "
             "Period End plus their client cash under the DP-007 client cash rule (from DP-300), the value the statement reports.",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type",
                  "Balance Basis", "Cash Balance Amount")
             + _u("51", "Fiduciary Accounting Statement", "Statement Trust", "Accounting Period End")),
            ("Statements Not Approved",
             "Fiduciary Accounting Statements more than 30 days past Accounting Period End with Statement Approval Status not in "
             "(Approved, Approved with Conditions, Retrospectively Approved, Not Required).",
             _u("51", "Fiduciary Accounting Statement", "Accounting Period End", "Statement Approval Status")),
            ("Late Trustee Reports",
             "Statements of an annual period end with no 13 Investor Document of the trust accounts for that Period End Date "
             "delivered within 60 days (Delivered Date), the trustee's annual report to beneficiaries.",
             _u("13", "Investor Document", "Investor Document ID", "Document Account", "Period End Date", "Delivered Date")
             + _u("51", "Fiduciary Accounting Statement", "Accounting Period End")),
            ("Court Accountings Pending",
             "Statements with Court Accounting Indicator = Y and Statement Approval Status = Pending, by Governing Law "
             "Jurisdiction of the trust.",
             _u("51", "Fiduciary Accounting Statement", "Court Accounting Indicator", "Statement Approval Status")
             + _u("51", "Trust", "Trust ID", "Governing Law Jurisdiction")),
            ("Allocations by Rule and Character",
             "Count and amount of allocations in the period by Allocation Rule, Allocation Character and Receipt or Disbursement "
             "Type, with the share allocated by the trust instrument rather than the governing act.",
             _u("51", "Principal and Income Allocation", "Allocation Rule", "Allocation Character", "Receipt or Disbursement Type",
                "Allocation Date", "Principal Amount", "Income Amount")),
        ],
        inputs=[
            ("51", "Principal and Income Allocation", ["Allocation Trust", "Source Account Activity", "Source Money Movement",
                                                       "Allocation Date", "Allocation Sequence", "Receipt or Disbursement Type",
                                                       "Allocation Character", "Principal Amount", "Income Amount",
                                                       "Allocation Rule"]),
            ("51", "Fiduciary Accounting Statement", ["Statement Trust", "Accounting Period Start", "Accounting Period End",
                                                      "Closing Principal Cash", "Closing Income Cash", "Undistributed Income",
                                                      "Court Accounting Indicator", "Statement Approval Status"]),
            ("51", "Trust", ["Trust ID", "Trust Status", "Governing Law Jurisdiction"]),
            ("51", "Trust Term Provision", ["Provision Trust", "Distribution Standard",
                                            "Provision Effective From", "Provision Effective To"]),
            ("15", "Account Registration Detail", ["Governing Trust"]),
            ("15", "Account", ["Account ID", "Account Status"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Type", "Trade Date",
                                               "Settlement Date", "Activity Net Amount", "Activity Status", "Source Fee Debit"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Business Date", "Cash Balance Type", "Balance Basis",
                                            "Cash Balance Amount"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Movement Amount"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Charged Fee Type", "Debited Account", "Debit Amount", "Debit Date",
                                 "Fee Debit Status"]),
            ("13", "Investor Document", ["Investor Document ID", "Document Account", "Period End Date", "Delivered Date"]),
        ],
        upstream=["DP-307", "DP-300", "DP-302", "DP-305", "DP-093", "DP-382", "DP-013"],
        refresh="Daily",
        timeliness="Allocation checks by 7am ET on T+1; period close checks on business day 10 after each accounting period end",
        history="Allocations and statements kept 10 years after the trust terminates (firm policy; 12 CFR 9.8 requires 3 years); closed periods final",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Allocation Trust and Statement Trust resolves to a DP-307 trust, every Source Account Activity to a DP-300 client account activity of an account governed by that trust, and every Source Money Movement to DP-302.",
            "Fiduciary Accounting Statement periods of one trust do not overlap and Accounting Period End is on or after Accounting Period Start; allocation sequences of one source event are unique.",
            "Principal Allocated and Income Allocated summed here equal DP-307's published Principal Allocated and Income Allocated for the period, and no Fiduciary Accounting Statement reaches Statement Approval Status = Approved while its trust is counted in Trusts With Cash Break.",
            "Allocation Character, Principal Amount and Income Amount are populated on every allocation, and Closing Principal Cash and Closing Income Cash on every statement.",
            "Trust-level rows are visible only to trust accounting and trust officers; only Trust Term Provision rows with Distribution Standard = Mandatory All Income are extracted, Provision Type is not read and the Special Needs Purpose and Supplemental Needs Only values never enter (CD-344, DP-352's restricted view); Trust Instrument Type is not read; aggregates with fewer than 10 trusts are suppressed.",
            "A period is closed on business day 10 after its end; later allocations to a closed period are posted as adjustments in the open period and never rewrite the closed statement.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). Book of record: Client Holding, Client Account "
               "Activity and Account Cash Balance (49) through DP-300; the 51 statement Closing Market Value and Trustee Report "
               "Delivered Date are Derived copies of 49 and 13 and are not read (CW-007, CW-076). Operating model (CD-297, "
               "CD-331): in house by default; with outsourced trust accounting the allocations arrive as provider data and this "
               "product keeps the statement checks and the cash break, the grain unchanged. PII tier: financial. Boundaries: "
               "DP-307 publishes the allocations and Principal Allocated, Income Allocated and Inconsistent Allocation Character, "
               "which are not redefined; trustee fees are billed in 47 (DP-305) and only their character is allocated in 51 "
               "(51 Source_Notes). Tailoring lever: principal and income act per trust or firm-wide (51 SME 3). Reference default: "
               "the governing-law state's act recorded per allocation (Allocation Rule). Tailoring lever: outsourced trust "
               "accounting. Reference default: in house. Taxonomy gap: 13 Investor Document has no document type for the trustee "
               "report, so any delivered statement of the trust accounts for the period end counts. Drafting assumptions: Activity "
               "Status Posted; the DP-007 client cash rule; USD 0.01 and USD 1 tolerances; 30 and 60-day windows; business day 10 "
               "close; minimum cell size 10. Decisions: CW-007, CW-018, CW-075, CW-076, CD-297, CD-344. WP1 new (CW-205): first "
               "specification, written last as a tailoring lever."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-354": dict(
        definition=("Each estate the trust company acts for, from death notification (02) through settlement: the firm's estate "
                    "role and probate status, milestones and tasks (51), the decedent's accounts restricted and re-registered (15), "
                    "the ownership-transfer and beneficiary claims in service (13) and the beneficiaries paid (50). Estate "
                    "specialists track aging cases and service sees the status when heirs call. One fact each: the notification "
                    "is 02's, the transfer request 13's, the estate case 51's (CW-077). Optional with the trust line. It owns no "
                    "certified metric family."),
        business_questions=[
            "Which estate cases are aging, which milestones are overdue, and where does each case stand?",
            "Are the decedent's accounts restricted after the death notification, and re-registered or closed once the estate distributes?",
            "Which personal representatives act without a verified authority grant, and which cases still lack letters?",
            "Which beneficiary and ownership-transfer claims are open, and what has been paid to beneficiaries?",
            "What are the decedent's accounts worth today?",
        ],
        grain="Estate settlement case (ESTATE-) x as-of date, with its tasks, the decedent's accounts and the related service requests and payments as companions; daily",
        dimensions=["Estate case and decedent (DP-307, DP-240)", "Firm estate role", "Probate status and jurisdiction",
                    "Estate milestone and task status", "Decedent account (DP-093)", "Service request type (DP-381)",
                    "Notification received date (DP-013)"],
        measures=[
            ("Estate Case Age",
             "Per open case (Case Status not in Resolved / Completed, Closed, Rejected, Canceled): days since the Notification "
             "Received Date of its Case Death Notification; median and the count above 12 and 24 months, by Firm Estate Role and "
             "Probate Status.",
             _u("51", "Estate Settlement Case", "Estate Settlement Case ID", "Decedent", "Case Death Notification",
                "Firm Estate Role", "Probate Jurisdiction", "Probate Status", "Case Status")
             + _u("02", "Death Notification", "Death Notification ID", "Notification Received Date")),
            ("Overdue Milestones",
             "Estate Settlement Task rows of open cases with Task Due Date before the as-of date and Task Completed Date blank, by "
             "Estate Milestone.",
             _u("51", "Estate Settlement Task", "Task Case", "Estate Milestone", "Task Sequence", "Task Due Date",
                "Task Completed Date", "Task Status")),
            ("Milestone Completion %",
             "Per open case: tasks with Task Completed Date populated / all tasks of the case.",
             _u("51", "Estate Settlement Task", "Task Case", "Task Completed Date")),
            ("Cases Without Letters",
             "Open cases with Firm Estate Role in (Executor, Co-Executor, Administrator, Administrator with Will Annexed) whose "
             "Letters Received milestone is not completed 60 days after the death notification was received.",
             _u("51", "Estate Settlement Case", "Firm Estate Role")
             + _u("51", "Estate Settlement Task", "Estate Milestone", "Task Completed Date")
             + _u("02", "Death Notification", "Notification Received Date")),
            ("Representative Authority Not Verified",
             "Open cases with Personal Representative populated and Representative Authority Grant blank or resolving to an 02 "
             "Authority Grant of Authority Type other than Executor / Personal Representative or Estate Administrator, or with "
             "Revoked Date populated.",
             _u("51", "Estate Settlement Case", "Personal Representative", "Representative Authority Grant")
             + _u("02", "Authority Grant", "Authority Grant ID", "Authority Type", "Grant Effective From", "Revoked Date")),
            ("Decedent Accounts Not Restricted",
             "Open accounts on which the Decedent holds an owner Account Party Role with no 15 Account Restriction of Account "
             "Restriction Type = Deceased Owner in effect.",
             _u("15", "Account", "Account ID", "Account Status", "Account Registration Type")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")
             + _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Type",
                  "Account Restriction Effective From", "Account Restriction Lifted Date")
             + _u("51", "Estate Settlement Case", "Decedent")),
            ("Decedent Accounts Open After Final Distribution",
             "Accounts of the Decedent still Open (Account Close Date blank) more than 30 days after the case's Final "
             "Distribution milestone was completed.",
             _u("15", "Account", "Account Close Date", "Account Status")
             + _u("15", "Account Party Role", "Role Party", "Role Account")
             + _u("51", "Estate Settlement Case", "Decedent")
             + _u("51", "Estate Settlement Task", "Task Case", "Estate Milestone", "Task Completed Date")),
            ("Decedent Account Value",
             "Sum of Summary Market Value of the decedent's accounts on the as-of date (DP-007 06 Account Asset Summary), by open "
             "case.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Market Value")),
            ("Open Estate Claims",
             "13 Service Request rows whose Transfer of Ownership & Estate group names the case (Estate Settlement Case), with "
             "Ownership Transfer Reason = Death of Owner (the only rows extracted), and whose "
             "Request Status is open, by Request Type, with the count with Estate Documents Outstanding populated and the median "
             "age from Received Timestamp.",
             _u("13", "Service Request", "Service Request ID", "Request Type", "Account", "Received Timestamp", "Request Status",
                "Completed Timestamp")
             + _u("13", "Transfer of Ownership & Estate", "Ownership Transfer Reason", "Related Death Notification",
                  "Estate Documents Outstanding", "Claimed Beneficiary Designation", "Estate Settlement Case",
                  "Deceased-Account Restriction")),
            ("Beneficiary Distributions Paid",
             "Count and sum of Movement Amount of settled 50 Money Movement rows with Source Death Notification = the case's "
             "notification (Money Movement Status = Settled) in the period, with the share of designated beneficiaries of the "
             "decedent's accounts (15 Beneficiary Designation) that have been paid.",
             _u("50", "Money Movement", "Money Movement ID", "Movement Account", "Movement Amount", "Value Date",
                "Money Movement Status", "Source Death Notification")
             + _u("15", "Beneficiary Designation", "Beneficiary Designation ID", "Designated Account", "Beneficiary",
                  "Beneficiary Type", "Beneficiary Allocation Percentage")),
            ("Cases Past Creditor Claim Period Without Distribution",
             "Open cases whose Creditor Claim Period End Date passed more than 90 days ago with no Interim Distribution or Final "
             "Distribution milestone completed.",
             _u("51", "Estate Settlement Case", "Creditor Claim Period End Date")
             + _u("51", "Estate Settlement Task", "Estate Milestone", "Task Completed Date")),
        ],
        inputs=[
            ("51", "Estate Settlement Case", ["Estate Settlement Case ID", "Decedent", "Case Death Notification", "Firm Estate Role",
                                              "Fiduciary Entity", "Personal Representative", "Representative Authority Grant",
                                              "Probate Jurisdiction", "Probate Status", "Estate Valuation Date",
                                              "Creditor Claim Period End Date", "Testamentary Trust", "Case Status",
                                              "Case Closed Date"]),
            ("51", "Estate Settlement Task", ["Task Case", "Estate Milestone", "Task Sequence", "Task Due Date",
                                              "Task Completed Date", "Task Status"]),
            ("02", "Death Notification", ["Death Notification ID", "Deceased Party", "Notification Received Date",
                                          "Reported Date of Death", "Death Certificate Received Date", "Notification Status"]),
            ("02", "Authority Grant", ["Authority Grant ID", "Authority Type", "Grant Effective From", "Revoked Date"]),
            ("13", "Service Request", ["Service Request ID", "Request Type", "Account", "Received Timestamp", "Request Status",
                                       "Completed Timestamp"]),
            ("13", "Transfer of Ownership & Estate", ["Ownership Transfer Reason", "Related Death Notification",
                                                      "Estate Documents Outstanding", "Claimed Beneficiary Designation",
                                                      "Estate Settlement Case", "Deceased-Account Restriction"]),
            ("15", "Account", ["Account ID", "Account Status", "Account Registration Type", "Account Close Date"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date"]),
            ("15", "Beneficiary Designation", ["Beneficiary Designation ID", "Designated Account", "Beneficiary",
                                               "Beneficiary Type", "Beneficiary Allocation Percentage"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Movement Amount", "Value Date",
                                      "Money Movement Status", "Source Death Notification"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Market Value"]),
        ],
        upstream=["DP-307", "DP-240", "DP-093", "DP-381", "DP-302", "DP-007", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET daily",
        history="Cases, tasks and payments kept 10 years after the case closes (firm policy; 12 CFR 9.8 requires 3 years; SEC Rule 17a-4 for the account records)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Dashboard", "CRM embed", "Warehouse table"],
        dq_rules=[
            "Every case resolves to a DP-307 estate case, every Decedent and Personal Representative to a DP-240 party, every decedent account to DP-093 and every estate claim to a DP-381 service request.",
            "Tasks of one case have unique Task Sequence values, Task Completed Date is on or after the case's death notification, and Case Closed Date is on or after every completed task.",
            "Open cases here equal DP-307's Open Estate Settlement Cases, and every open case has a Case Death Notification (DP-307 Estate Cases Without Death Notification = 0) before its milestones are measured.",
            "Firm Estate Role, Case Status and Probate Status are populated on every case, and Estate Milestone and Task Due Date on every task.",
            "15 Account Restriction rows of Account Restriction Type = Financial Exploitation and 13 Transfer of Ownership & Estate rows with Ownership Transfer Reason other than Death of Owner (Incapacity / Guardianship is special category) are excluded at extraction (CW-213, CD-344); case rows are visible only to estate specialists, trust officers and service roles handling the estate; heirs' identities are shown only on the case.",
            "The daily view is published by 7am ET and a closed case is frozen at Case Closed Date.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family); the decedent account value is an operational value "
               "from DP-007 rows. PII tier: identity. Boundaries: one fact each (CW-077): 02 Death Notification (DP-240, and "
               "DP-321 for the restriction timeliness of every death), 13 ownership transfer (DP-381, which publishes Estate "
               "Requests With Documents Outstanding, not redefined), 51 estate case (DP-307, which publishes Open Estate "
               "Settlement Cases and Estate Cases Without Death Notification). Tailoring lever: executor or agent only (51 SME 6). "
               "Reference default: both Firm Estate Role groups. Tailoring lever: trust line offered. Reference default: offered; "
               "without it this product drops and estates are handled as 13 transfers only. Taxonomy gap: 51 Estate Settlement "
               "Case has no case opened date; age is measured from the death notification. Drafting assumptions: open Case "
               "Status values; 60, 30 and 90-day windows; Money Movement Status Settled. Decisions: CW-018, CW-075, CW-077, CW-213. "
               "WP1 new (CW-205): first specification, written last as a tailoring lever."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-355": dict(
        definition=("Each trust's and estate's fiduciary income tax return for the tax year (Form 1041 and Form 5227): filing "
                    "status and dates against the due and extended due dates, distributable net income, state returns, and the "
                    "Schedule K-1 allocations to beneficiaries with their delivery, tested against the beneficiaries' interests "
                    "and the income distributed. Fiduciary tax tracks filings due and K-1s not delivered. Preparation is "
                    "outsourced by default and 51 holds the filing facts. Optional with the trust line. It owns no certified "
                    "metric family."),
        business_questions=[
            "Which fiduciary returns are due this season, which were filed on time, and which are on extension?",
            "Which K-1s have not been delivered to beneficiaries, and which go to someone with no interest in the trust that year?",
            "Do the K-1 income allocations stay within distributable net income and agree to the income distributed?",
            "Which closed estates and terminated trusts lack a final K-1, and which state returns are missing?",
            "Are revocable (grantor) trusts filing under the grantor-type method?",
        ],
        grain="Fiduciary tax return (TXRT-; trust or estate x tax year end x return) with its beneficiary K-1 allocations as companion rows; daily in filing season, annual",
        dimensions=["Trust or estate (DP-307)", "Filing entity (DP-240)", "K-1 beneficiary (DP-240)", "Fiduciary return type",
                    "Return status", "Revocability and situs", "Tax year (DP-013)"],
        measures=[
            ("Returns Due",
             "Count of Fiduciary Tax Return ID whose due date (Extended Due Date where populated, otherwise the 15th day of the "
             "fourth month after Tax Year End Date) falls in the period, by Fiduciary Return Type.",
             _u("51", "Fiduciary Tax Return", "Fiduciary Tax Return ID", "Return Trust", "Return Estate Case", "Tax Year End Date",
                "Fiduciary Return Type", "Extended Due Date")),
            ("Returns Filed On Time %",
             "Returns Due with Return Filed Date on or before the due date / Returns Due, and the share filed by the original due "
             "date.",
             _u("51", "Fiduciary Tax Return", "Return Filed Date", "Extended Due Date", "Tax Year End Date") + ["Returns Due"]),
            ("Returns on Extension",
             "Count of returns of the tax year with Extended Due Date populated, by Fiduciary Return Type and Return Status.",
             _u("51", "Fiduciary Tax Return", "Extended Due Date", "Return Status")),
            ("K-1s Issued",
             "Count of Beneficiary Tax Allocation rows of returns with Return Filed Date populated, by Fiduciary Return Type.",
             _u("51", "Beneficiary Tax Allocation", "Allocation Return", "K-1 Beneficiary")
             + _u("51", "Fiduciary Tax Return", "Return Filed Date", "Fiduciary Return Type")),
            ("K-1s Not Delivered",
             "K-1s Issued for which no 13 Investor Document addressed to the K-1 Beneficiary (Document Recipient) with Period End "
             "Date = Tax Year End Date has Delivered Date populated by the return's filing date.",
             _u("13", "Investor Document", "Investor Document ID", "Document Recipient", "Period End Date", "Delivered Date",
                "Delivery Status")
             + _u("51", "Beneficiary Tax Allocation", "K-1 Beneficiary")
             + ["K-1s Issued"]),
            ("K-1 Income Above DNI",
             "Returns whose sum over K-1 rows of Interest Income Allocated + Ordinary Dividends Allocated + Net Short-Term Capital "
             "Gain Allocated + Net Long-Term Capital Gain Allocated exceeds Distributable Net Income plus any capital gain the "
             "instrument allocates to income, by more than USD 1 (simple and complex trusts).",
             _u("51", "Beneficiary Tax Allocation", "Interest Income Allocated", "Ordinary Dividends Allocated",
                "Qualified Dividends Allocated", "Net Short-Term Capital Gain Allocated", "Net Long-Term Capital Gain Allocated")
             + _u("51", "Fiduciary Tax Return", "Distributable Net Income", "Fiduciary Return Type")),
            ("K-1 Allocation to Distribution Variance",
             "Per return: sum of K-1 Interest Income and Ordinary Dividends Allocated minus the Income Amount of Principal and "
             "Income Allocation rows of Receipt or Disbursement Type = Distribution to Beneficiary with Allocation Date in the tax "
             "year (USD).",
             _u("51", "Principal and Income Allocation", "Allocation Trust", "Allocation Date", "Receipt or Disbursement Type",
                "Income Amount")
             + _u("51", "Beneficiary Tax Allocation", "Interest Income Allocated", "Ordinary Dividends Allocated")),
            ("K-1 Recipients Without Interest",
             "K-1 rows whose K-1 Beneficiary has no Beneficial Interest in the trust (Interest Trust, Beneficiary Party) effective "
             "at any time in the tax year (Interest Effective From / To), estates excepted.",
             _u("51", "Beneficial Interest", "Interest Trust", "Beneficiary Party", "Beneficial Interest Type",
                "Interest Effective From", "Interest Effective To")
             + _u("51", "Beneficiary Tax Allocation", "K-1 Beneficiary")),
            ("Final K-1s Missing",
             "Estates whose case closed (Case Closed Date) and trusts terminated (Trust Termination Date) in the tax year whose "
             "return has no K-1 with Final K-1 Indicator = Y.",
             _u("51", "Estate Settlement Case", "Estate Settlement Case ID", "Case Status", "Case Closed Date")
             + _u("51", "Trust", "Trust ID", "Trust Termination Date")
             + _u("51", "Beneficiary Tax Allocation", "Final K-1 Indicator")),
            ("Grantor Trust Filing Mismatches",
             "Returns of trusts with Revocability = Revocable whose Fiduciary Return Type is not in (Form 1041 - Grantor Type Trust, "
             "Grantor Trust Optional Method).",
             _u("51", "Trust", "Revocability", "Trust Status")
             + _u("51", "Fiduciary Tax Return", "Fiduciary Return Type")),
            ("State Returns Missing",
             "Filed returns with State Returns Filed blank for trusts whose Situs Jurisdiction is a state with a fiduciary income "
             "tax, by Situs Jurisdiction.",
             _u("51", "Fiduciary Tax Return", "State Returns Filed", "Return Filed Date")
             + _u("51", "Trust", "Situs Jurisdiction")),
        ],
        inputs=[
            ("51", "Fiduciary Tax Return", ["Fiduciary Tax Return ID", "Return Trust", "Return Estate Case", "Filing Entity Party",
                                            "Filer EIN", "Tax Year End Date", "Fiduciary Return Type", "Tax Elections",
                                            "Distributable Net Income", "Extended Due Date", "Return Filed Date",
                                            "State Returns Filed", "Return Status"]),
            ("51", "Beneficiary Tax Allocation", ["Allocation Return", "K-1 Beneficiary", "Interest Income Allocated",
                                                  "Ordinary Dividends Allocated", "Qualified Dividends Allocated",
                                                  "Net Short-Term Capital Gain Allocated", "Net Long-Term Capital Gain Allocated",
                                                  "Final K-1 Indicator"]),
            ("51", "Trust", ["Trust ID", "Trust Status", "Revocability", "Situs Jurisdiction", "Trust Termination Date"]),
            ("51", "Estate Settlement Case", ["Estate Settlement Case ID", "Case Status", "Case Closed Date"]),
            ("51", "Beneficial Interest", ["Interest Trust", "Beneficiary Party", "Beneficial Interest Type",
                                           "Interest Effective From", "Interest Effective To"]),
            ("51", "Principal and Income Allocation", ["Allocation Trust", "Allocation Date", "Receipt or Disbursement Type",
                                                       "Income Amount"]),
            ("13", "Investor Document", ["Investor Document ID", "Document Recipient", "Period End Date", "Delivered Date",
                                         "Delivery Status"]),
        ],
        upstream=["DP-307", "DP-382", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET daily from January to October (filing season and extensions); annual summary after the extended due date",
        history="Returns and K-1 allocations kept 7 years after filing (IRS record retention for Form 1041; 12 CFR 9.8 requires 3 years)",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Dashboard", "Warehouse table", "File extract"],
        dq_rules=[
            "Every Return Trust resolves to a DP-307 trust and every Return Estate Case to a DP-307 estate case (exactly one of the two per return), and every Filing Entity Party and K-1 Beneficiary to a DP-240 party.",
            "One return per trust or estate, tax year end and Fiduciary Return Type (amended returns as new versions), Extended Due Date after the original due date, and Return Filed Date on or after Tax Year End Date.",
            "Distributable Net Income Reported and the overdue returns reconcile to DP-307's Distributable Net Income Reported and Fiduciary Returns Due Not Filed for the same tax year.",
            "Tax Year End Date, Fiduciary Return Type and Return Status are populated on every return, and K-1 Beneficiary on every allocation row.",
            "Filer EIN is published masked to its last four digits and beneficiary TINs are never read; K-1 rows are visible only to fiduciary tax and trust officers (Restricted - Personal Data); aggregates with fewer than 10 returns are suppressed.",
            "A filed return is locked at Return Filed Date; corrections arrive as an amended return and never rewrite the filed row.",
        ],
        notes=("Certified numbers: none (It owns no certified metric family). Operating model (CD-297, CD-331): preparation of "
               "Form 1041 is outsourced by default; 51 holds the filing facts and the grain is unchanged if it is brought in house. "
               "PII tier: financial (tax data of beneficiaries); Restricted - Personal Data (DQ5). Boundaries: DP-307 publishes "
               "the returns and Fiduciary Returns Due Not Filed and Distributable Net Income Reported, which are not redefined; "
               "client 1099 forms are 13 Tax Form Records of the brokerage products. Objects of the candidate: 13 Tax Form Record "
               "is not read (its Tax Document Type list has no Schedule K-1; the K-1 delivery is matched on 13 Investor Document). "
               "Tailoring lever: Form 1041 preparation outsourced (51 SME 7). Reference default: outsourced. Tailoring lever: trust "
               "line offered. Reference default: offered. Taxonomy gap: 13 has no K-1 document type or K-1 delivery record; "
               "delivery is matched by recipient and period end. Taxonomy gap: 51 Fiduciary Tax Return has no original due date "
               "(derived from Tax Year End Date, as in DP-307). Drafting assumptions: the due-date rule; states with a fiduciary "
               "income tax; USD 1 tolerance; minimum cell size 10. Decisions: CW-018, CW-075, CD-297. WP1 new (CW-205): first "
               "specification, written last as a tailoring lever."),
    ),
}
