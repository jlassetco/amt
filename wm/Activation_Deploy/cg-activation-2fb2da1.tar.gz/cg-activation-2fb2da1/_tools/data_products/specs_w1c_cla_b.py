"""Data product specifications, Stage WP1 Products, consumer wave (WP1C), area CLA, group CLA-B (agent C-2): offering,
conduct and engagement (Data Domains 01, 36, 03, 04, 13, 08).

New consumer products (owning Data Domain), in the WP1_Scope.md order:
- DP-383 Platform Shelf, Availability & Due Diligence Status (01);
- DP-384 Advice Service & Platform Feature Development Pipeline (36);
- DP-385 Advice Program Outcomes Evidence (36);
- DP-387 Advisor Capacity & Book Health (03);
- DP-390 Incentive Plan Governance & Advisor Payouts (03);
- DP-391 Supervisory Structure & Principal Coverage (03);
- DP-392 Acquisition Funnel & Account Opening Conversion (04);
- DP-393 Channel Referrals & Advice Hand-Offs (03);
- DP-394 Digital Engagement & Experiments (04);
- DP-398 Principal Review Queue & Supervisory Approvals (08);
- DP-399 Form CRS & Reg BI Disclosure Delivery Control (08);
- DP-400 Sales Practice Surveillance & Corrective Action (08);
- DP-402 Supervisory Controls, Branch Inspections & Findings (08);
- DP-403 Senior Investor Case Management & Rule 2165 Holds (08);
- DP-414 Complaints & Rule 4530 Reporting (08);
- DP-404 Retail Conduct Risk Indicators (08);
- DP-405 Contact Center Operations (13);
- DP-408 Proxy Solicitation, Pass-Through & Voting Choice (13);
- DP-409 Servicing Errors & Client Remediation (13);
- DP-410 Campaign Performance & Spend (04);
- DP-412 Marketing Audiences, Subscriptions & Tracking Consent (04);
- DP-418 Escheatment, Dormancy & Lost Client Monitoring (13).

Re-scoped in place (ids kept; the wholesale specs stay in their old modules until the lineage agent deletes them):
- DP-036 Communications Review & FINRA Filing (08; old entry in specs_f_compliance.py);
- DP-038 Gifts & Non-Cash Compensation (08; specs_f_compliance.py);
- DP-039 Representative Registrations, Licensing & CE (08; specs_f_compliance.py);
- DP-069 Client Communications Delivery, Householding & Cost (13; specs_l_shareholder_vendor.py);
- DP-078 Communications Capture & Surveillance (08; specs_n_compliance_controls.py);
- DP-079 Fund Dealing & Operational Reference (01; specs_o_operations.py);
- DP-085 Account Maintenance, Authentication & Takeover Monitoring (13; specs_o_operations.py);
- DP-109 Product Reviews & Criterion Results (36; specs_e3_private_markets_product_range.py).

WP1 decisions applied (WP1_Method.md section 2): certified numbers are read, never recomputed, from DP-008 (Client Assets,
Net New Assets, Advised Assets, Households), DP-012 (client fee revenue) and DP-145 (Personal Return Value) (CW-011,
CW-226, CW-227); special-category client facts reach these products only through the DP-322 restricted view, with the
DP-403 exception for the 08 Rule 2165 case (CW-213, CW-225, CD-344); Reg BI evidence is assembled by DP-334 and DP-335 and
never re-scored here: DP-398 publishes the principal's review outcome as recorded (CW-215, CW-224); nudge determinations
are reported as recorded in 08 (CW-228); books of record per CW-007 (49 Client Holding through DP-300, the 29 register
through DP-580; never 06 or 18); DP-380 is folded into DP-004 (CW-221); DP-389, DP-401 and DP-416 are backlog products
(merge targets DP-387, DP-398 and DP-585) and are not specified. The retail conduct products get semantic model SM-29 at
WP2.

Upstream inside the module (no cycles): DP-391 <- DP-398, DP-402; DP-414 <- DP-385, DP-404; DP-385 <- DP-109; DP-039 <-
DP-078, DP-404; DP-036, DP-398, DP-400, DP-402, DP-403 <- DP-404. Products that read this module must not be listed here:
DP-106 reads DP-384 and DP-069, DP-107 reads DP-383, DP-456 reads DP-403 (the Rule 2165 clock), DP-467 reads DP-393,
DP-492 reads DP-410 (funnel outcomes) and DP-498 reads DP-392 and DP-410 (amended CW-227). DP-491 and DP-492 read DP-008
directly and no edge exists between them and DP-387 or DP-392. DP-390 lists DP-198 upstream (certified pay); DP-198 names
DP-390 as the successor of the 07 compensation products in its notes and never lists it.

Lineage items for the lineage agent (other modules; not edited here): DP-106 to list DP-384 (and DP-382 beside DP-069);
DP-107 to read DP-383 (DP-058 successor); DP-169 and DP-176 to read DP-405 and DP-409 (DP-043 successors); DP-248 to
list DP-404; DP-492 to list DP-410 and DP-498 to list DP-392 and DP-410 under the measure names Attributed Outcomes
(Primary Model), Campaign Spend and Funded Households Acquired; DP-456 reads DP-403's clock measures and DP-322 drops its
own (C-1); DP-467 reads DP-393 Hand-Off to Advice Engagement Rate %. Renames for readers: DP-069 E-Delivery Adoption Rate,
Undeliverable Rate, Deadline Met Rate, Householding Revocation Timeliness and Document Furnish Timeliness become the DP-382
names '(from DP-382)' (SM-07 excluded-metric notes cite the old names; SM-07 line 958 also cites dropped Cascade
Confirmation Rate); DP-398 'Review Ageing (Business Days)' is now 'Review Aging (Business Days)'; DP-109 'Share Class Net
Flows' is now 'Share Class Net Flows (from DP-008)'; DP-410 'Campaign Actual' + ' Cost' is now 'Campaign Spend'.
See CONTRACT.md.
WP2 retirement sweep (CW-209): SM-07, named above, is retired and its definition file deleted.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


# Certified client-asset reads from DP-008 (published as 06 measure values; CW-011)
_MV = ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]


def _mv(*extra):
    return _u("06", "Measure Value", "Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount",
              *extra)


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-383": dict(
        definition=("Which own share classes and third-party instruments are available on the brokerage platform and in advice "
                    "models, under which transaction fee category and tradable-universe rule, set against the 52 product due "
                    "diligence approval behind each third-party product and the currency of the product documents and "
                    "investment commentary published for them. Brokerage product management and manager research use it to find "
                    "products offered without a current approval, approvals on watch, availability changes coming into effect "
                    "and stale documents still in use. It owns no certified metric family."),
        business_questions=[
            "Which third-party products are available on the platform today without a current due diligence approval, or with an approval whose next review date has passed?",
            "Which available products are on watch, and which complex products are offered without a full due diligence review?",
            "Which availability changes come into effect in the next 30 days, by status and transaction fee category?",
            "Which platform features are live without a governing tradable-universe rule or without the registration types they apply to?",
            "Which product documents and investment commentaries in use are past their currency date or were published without investment sign-off?",
        ],
        grain=("Platform availability (own share class or third-party instrument x availability effective date), with the "
               "governing due diligence (52 Product Due Diligence) and its criterion results as companion facts; companion "
               "tables at platform feature x effective date, tradable-universe rule, product document version and commentary; "
               "SCD type 2 on availability and rules"),
        dimensions=["Share class (DP-004)", "Third-party instrument (DP-097)", "Platform availability status",
                    "Transaction fee category", "Tradable universe rule type", "Platform feature type",
                    "Due diligence outcome and product use scope (DP-306)", "Complex product indicator",
                    "Document type and language", "Commentary type and scope", "Availability effective date (DP-013)"],
        measures=[
            ("Available Platform Products", "Count of Platform Product Availability rows in force at the as-of date (latest Availability Effective From on or before it) with Platform Availability Status = Available, split by Available Share Class (own) and Available Third-Party Instrument (third party) and by Transaction Fee Category.",
             _u("01", "Platform Product Availability", "Platform Availability ID", "Available Share Class", "Available Third-Party Instrument",
                "Platform Availability Status", "Transaction Fee Category", "Availability Effective From")),
            ("Available Products on Lapsed or Missing Approval", "Count of Available Platform Products with Available Third-Party Instrument populated whose Due Diligence Approval is empty, or resolves to a Product Due Diligence with Product Due Diligence Outcome not in Approved or Approved - Watch, or with Product Next Review Due Date before the as-of date; DP-004 publishes only the missing-approval count as a stewardship measure.",
             _u("01", "Platform Product Availability", "Due Diligence Approval", "Available Third-Party Instrument")
             + _u("52", "Product Due Diligence", "Product Due Diligence ID", "Product Due Diligence Outcome", "Product Next Review Due Date")
             + ["Available Platform Products"]),
            ("Shelf Due Diligence Coverage %", "(Available third-party products - Available Products on Lapsed or Missing Approval) / available third-party products (Available Platform Products with Available Third-Party Instrument populated).",
             _u("01", "Platform Product Availability", "Available Third-Party Instrument")
             + ["Available Platform Products", "Available Products on Lapsed or Missing Approval"]),
            ("Available Products on Watch", "Count of Available Platform Products whose Due Diligence Approval resolves to a Product Due Diligence with Product Due Diligence Outcome = Approved - Watch, by Product Use Scopes.",
             _u("01", "Platform Product Availability", "Due Diligence Approval")
             + _u("52", "Product Due Diligence", "Product Due Diligence Outcome", "Product Use Scopes") + ["Available Platform Products"]),
            ("Complex Products Offered Without Full Review", "Count of Available Platform Products whose governing Product Due Diligence has Complex Product Indicator = Y and Full Due Diligence Indicator not Y.",
             _u("52", "Product Due Diligence", "Complex Product Indicator", "Full Due Diligence Indicator") + ["Available Platform Products"]),
            ("Failed Criteria on Available Products", "Count of Product Due Diligence Criterion Result rows with Criterion Result = Fail whose Criterion Product Review is the governing Product Due Diligence of an available product, by Product Due Diligence Criterion.",
             _u("52", "Product Due Diligence Criterion Result", "Criterion Product Review", "Product Due Diligence Criterion", "Criterion Result")
             + ["Available Platform Products"]),
            ("Availability Changes Due (30 Days)", "Count of Platform Product Availability rows with Availability Effective From after the as-of date and no more than 30 calendar days after it, by Platform Availability Status (new availability, restriction, removal).",
             _u("01", "Platform Product Availability", "Platform Availability ID", "Availability Effective From", "Platform Availability Status")),
            ("Universe Rules Expiring (30 Days)", "Count of Tradable Universe Policy Rule rows with Rule Status = Active and Rule Effective To within the next 30 calendar days, by Universe Rule Type.",
             _u("01", "Tradable Universe Policy Rule", "Policy Rule ID", "Rule Status", "Rule Effective To", "Universe Rule Type")),
            ("Features Without Active Governing Rule", "Count of Platform Feature rows in force (Feature Effective From on or before the as-of date) whose Feature Governing Policy Rule is empty or resolves to a Tradable Universe Policy Rule with Rule Status not Active or Rule Effective From after the as-of date, by Platform Feature Type.",
             _u("01", "Platform Feature", "Platform Feature Type", "Feature Governing Policy Rule", "Feature Effective From")
             + _u("01", "Tradable Universe Policy Rule", "Policy Rule ID", "Rule Status", "Rule Effective From")),
            ("Features Without Eligibility Scope", "Count of Platform Feature rows in force with Eligible Offerings or Eligible Account Registration Types empty, or with Client Activation Required Indicator = Y and Required Disclosure Type empty.",
             _u("01", "Platform Feature", "Eligible Offerings", "Eligible Account Registration Types", "Client Activation Required Indicator",
                "Required Disclosure Type", "Feature Effective From")),
            ("Product Documents Past Currency", "Count of the latest Product Document version per document subject, Document Type and Document Language with Document Version Date more than 13 months before the as-of date (annual prospectus and fact sheet update), by Document Type.",
             _u("01", "Product Document", "Document Type", "Document Language", "Document Version Date")),
            ("Commentary in Use Past Use-By Date", "Count of Investment Commentary rows with Commentary Status = Published whose Use-By Date is before the as-of date, by Commentary Type and Permitted Audience.",
             _u("01", "Investment Commentary", "Commentary ID", "Commentary Type")
             + _u("01", "Commentary Approval", "Commentary Status", "Use-By Date", "Permitted Audience")),
            ("Commentary Published Without Sign-Off", "Count of Investment Commentary rows with Commentary Status = Published and Investment Sign-Off Date empty or later than the commentary's first publication; the 08 review of the communication is DP-036's.",
             _u("01", "Investment Commentary", "Commentary ID") + _u("01", "Commentary Approval", "Commentary Status", "Investment Sign-Off Date")),
            ("Commentary Currency Lag (Days)", "For each Subject Product / Mandate and Commentary Type, calendar days from the latest published Commentary Period End Date to the as-of date, compared with the Commentary Frequency (quarterly commentary is stale after 45 days past quarter-end plus 92 days).",
             _u("01", "Investment Commentary", "Subject Product / Mandate", "Commentary Type", "Commentary Period End Date", "Commentary Frequency")
             + _u("01", "Commentary Approval", "Commentary Status")),
        ],
        inputs=[
            ("01", "Platform Product Availability", ["Platform Availability ID", "Available Share Class", "Available Third-Party Instrument",
                                                     "Platform Availability Status", "Transaction Fee Category", "Due Diligence Approval",
                                                     "Availability Effective From"]),
            ("01", "Tradable Universe Policy Rule", ["Policy Rule ID", "Rule Name", "Universe Rule Type", "Rule Criteria",
                                                     "Rule Effective From", "Rule Effective To", "Rule Status"]),
            ("01", "Platform Feature", ["Platform Feature Type", "Eligible Offerings", "Eligible Account Registration Types",
                                        "Required Disclosure Type", "Client Activation Required Indicator",
                                        "Feature Governing Policy Rule", "Feature Effective From"]),
            ("52", "Product Due Diligence", ["Product Due Diligence ID", "Reviewed Instrument", "Product Use Scopes",
                                             "Full Due Diligence Indicator", "Complex Product Indicator", "Product Due Diligence Outcome",
                                             "Product Review Effective Date", "Product Next Review Due Date"]),
            ("52", "Product Due Diligence Criterion Result", ["Criterion Product Review", "Product Due Diligence Criterion", "Criterion Result"]),
            ("01", "Product Document", ["Document Type", "Document Language", "Document Version Date", "Document Location"]),
            ("01", "Investment Commentary", ["Commentary ID", "Commentary Type", "Commentary Scope", "Subject Strategy",
                                             "Subject Product / Mandate", "Commentary Frequency", "Commentary Period End Date",
                                             "Commentary Data As-Of Date"]),
            ("01", "Commentary Approval", ["Commentary Status", "Investment Sign-Off Date", "Permitted Audience", "Use-By Date"]),
        ],
        upstream=["DP-004", "DP-097", "DP-306", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for availability, rules, features, due diligence outcomes, documents and commentary as of the prior business day",
        history=("Availability, rules and features kept as SCD type 2 with every version; due diligence outcomes and criterion "
                 "results as immutable facts; kept six years (SEC Rule 17a-4 and Rule 204-2 for the due diligence and "
                 "communications support)"),
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Available Share Class resolves to an active DP-004 Share Class ID, every Available Third-Party Instrument to a DP-097 instrument, every Due Diligence Approval to a DP-306 Product Due Diligence ID, and exactly one of Available Share Class and Available Third-Party Instrument is populated on each row.",
            "No two Platform Product Availability rows for the same share class or instrument share an Availability Effective From, and every Tradable Universe Policy Rule has Rule Effective To empty or on or after Rule Effective From.",
            "For every row with a Due Diligence Approval, the Reviewed Instrument of that Product Due Diligence equals the Available Third-Party Instrument, and the count of available third-party products ties to DP-004 Platform Availability by Status for the same as-of date with no difference.",
            "Platform Availability Status, Transaction Fee Category and Availability Effective From are populated on every availability row, Product Due Diligence Outcome and Product Next Review Due Date on every due diligence row, and Commentary Status on every commentary.",
            "The published tables carry no column sourced from Commentary Author, Investment Sign-Off By or Product Reviewer, and no published value matches the EMP- or PTY- key pattern (no personal data).",
            "The prior business day is complete by 7am ET on T+1, and an availability change is loaded before its Availability Effective From.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: none. The validator flags Platform Availability ID, Product Due Diligence ID and Criterion Product Review "
               "only because their catalog notes read 'Object PII tier: No PII'; author, sign-off "
               "and reviewer names are not read, so pii is N. "
               "Boundaries: DP-004 conforms availability, rules and features and publishes the stewardship counts (Platform "
               "Availability by Status, Third-Party Products Available Without Due Diligence Approval); this product joins them "
               "to the due diligence lifecycle and reports gaps, never re-deciding eligibility. Due diligence and the approved, "
               "watch and restricted lists are 52, published by DP-306 (CW-120); instrument eligibility flags are 17 (DP-516); "
               "order-time checks are 48 (DP-435, CW-099); fee amounts are 47 (CW-037). Third-party platforms' shelves are DP-005 "
               "and the backlog DP-484. DP-107 Product Launch Readiness reads this product (the go-to-market part of retired "
               "DP-058), so DP-107 is not upstream. The 08 review of commentary as a communication is DP-036. "
               "Tailoring lever: platform curation (01 SME 4). Reference default: curated platform with a 52 approval for every "
               "third-party product; an open platform drops the due diligence join and Shelf Due Diligence Coverage %. "
               "Tailoring lever: third-party products offered (CW-014). Reference default: yes; a firm without third-party products "
               "drops the 52 inputs. "
               "Tailoring lever: published commentary. Reference default: quarterly commentary for own funds and models; a firm "
               "publishing none drops the commentary measures. "
               "Taxonomy gap: 01 Product Document has no attribute for the product or share class it documents (only the grain "
               "names it); the document subject is taken from the row key. "
               "Taxonomy gap: 01 Platform Product Availability has no reference to the Tradable Universe Policy Rule that admits "
               "the product; rule coverage of available products cannot be traced. "
               "Drafting assumptions: Platform Availability Status value Available; due diligence outcomes Approved and Approved - "
               "Watch; Criterion Result value Fail; the 13-month document currency; the 30-day windows; the quarterly commentary "
               "staleness rule. "
               "Decisions: CW-014, CW-037, CW-073, CW-099, CW-120, CW-901, CW-220. "
               "WP1 new (CW-220): supersedes the go-to-market part of DP-058; also reads 01 Product Document, Investment "
               "Commentary and Commentary Approval (moved from backlog DP-386, WP1_Scope.md section 4). The candidate's "
               "objects are all read."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-384": dict(
        definition=("Every advice program, service tier and platform feature in development or change, from the 36 change "
                    "initiative through its service offering or platform feature specification, scope, impact assessment and "
                    "each regulatory requirement (Form ADV and Form CRS amendments, advance fee notices, agreement amendments) "
                    "against its due date. Product, technology, billing and compliance plan each advice or platform launch and "
                    "change from one calendar; the fund side of the calendar is DP-106. It owns no certified metric family."),
        business_questions=[
            "Which advice program, service tier and platform feature changes are in the pipeline, at what status, and which take effect in the next 90 days?",
            "Which regulatory requirements of those changes (Form ADV and Form CRS amendments, advance fee notices, agreement amendments) are overdue or due in the next 30 days?",
            "Which changes will be effective before the client notice period has run?",
            "Which changes have no impact assessment, which impacts are high severity, and how many accounts and how much cost do they affect?",
            "Which launched offerings and features were not created in the offering catalog, or went live without a governing rule?",
        ],
        grain=("Product change initiative (LCHG-) carrying a service offering or platform feature specification, with its "
               "changed scope, impact assessments and regulatory requirements as companion facts; SCD type 2 on initiative "
               "status and planned dates"),
        dimensions=["Product change initiative and change type", "Change status", "Specified offering type and delivery mode",
                    "Proposed discretion type and advisory capacity", "Specified feature type",
                    "Service offering, service tier and model portfolio in scope (DP-004)", "Regulatory requirement type",
                    "Requirement status", "Impact area and severity", "Change sponsor (DP-192)", "Planned effective date (DP-013)"],
        measures=[
            ("Advice and Platform Changes in Pipeline", "Count of Product Change Initiatives with at least one Service Offering Specification or Platform Feature Specification and Change Status not in Completed or Withdrawn, by Product Change Type and Change Status.",
             _u("36", "Product Change Initiative", "Product Change Initiative ID", "Product Change Type", "Change Status")
             + _u("36", "Service Offering Specification", "Offering Specification Change Initiative")
             + _u("36", "Platform Feature Specification", "Feature Specification Change Initiative")),
            ("Changes Effective in Next 90 Days", "Advice and Platform Changes in Pipeline with Planned Effective Date after the as-of date and no more than 90 calendar days after it, by Product Change Type.",
             _u("36", "Product Change Initiative", "Planned Effective Date", "Product Change Type") + ["Advice and Platform Changes in Pipeline"]),
            ("Advice Change Effective Date Slippage (Days)", "For initiatives with Actual Effective Date populated, Actual Effective Date - the first recorded Planned Effective Date (SCD type 2 history) in calendar days; mean and maximum by Product Change Type.",
             _u("36", "Product Change Initiative", "Actual Effective Date", "Planned Effective Date", "Product Change Type")),
            ("Requirements Overdue", "Count of Change Regulatory Requirement rows of the pipeline initiatives with Requirement Due Date before the as-of date and Requirement Status not Satisfied or Requirement Satisfied Date empty, by Regulatory Requirement Type.",
             _u("36", "Change Regulatory Requirement", "Requirement Change Initiative", "Regulatory Requirement Type", "Requirement Due Date",
                "Requirement Status", "Requirement Satisfied Date") + ["Advice and Platform Changes in Pipeline"]),
            ("Requirements Due in 30 Days", "Count of Change Regulatory Requirement rows with Requirement Status not Satisfied and Requirement Due Date within the next 30 calendar days, by Regulatory Requirement Type and Requirement Product.",
             _u("36", "Change Regulatory Requirement", "Requirement Status", "Requirement Due Date", "Regulatory Requirement Type", "Requirement Product")),
            ("Notice Period Shortfall", "Count of Change Regulatory Requirement rows with Minimum Notice Days populated where Requirement Satisfied Date (the notice sent, Satisfying Shareholder Communication) plus Minimum Notice Days falls after the initiative's Planned Effective Date, or where the requirement is unsatisfied fewer than Minimum Notice Days before it.",
             _u("36", "Change Regulatory Requirement", "Minimum Notice Days", "Requirement Satisfied Date", "Satisfying Shareholder Communication",
                "Requirement Change Initiative") + _u("36", "Product Change Initiative", "Planned Effective Date")),
            ("Form ADV and Form CRS Amendments Pending", "Count of Change Regulatory Requirement rows with Regulatory Requirement Type in Form ADV Amendment or Form CRS Amendment, Requirement Status not Satisfied and Satisfying Firm Filing empty.",
             _u("36", "Change Regulatory Requirement", "Regulatory Requirement Type", "Requirement Status", "Satisfying Firm Filing")),
            ("Changes Without Impact Assessment", "Count of Advice and Platform Changes in Pipeline with no Change Impact Assessment row (Impact Change Initiative), by Change Status.",
             _u("36", "Change Impact Assessment", "Impact Change Initiative") + _u("36", "Product Change Initiative", "Change Status")
             + ["Advice and Platform Changes in Pipeline"]),
            ("High-Severity Impacts Open", "Count of Change Impact Assessment rows with Impact Severity = High on pipeline initiatives, by Impact Area.",
             _u("36", "Change Impact Assessment", "Impact Severity", "Impact Area") + ["Advice and Platform Changes in Pipeline"]),
            ("Accounts Affected by Pipeline Changes", "Sum of Affected Shareholder Accounts Count over the Change Impact Assessment rows of pipeline initiatives, taking the latest Impact Assessment Date per initiative and Impact Area.",
             _u("36", "Change Impact Assessment", "Affected Shareholder Accounts Count", "Impact Assessment Date", "Impact Area")),
            ("Estimated Impact Cost", "Sum of Estimated Impact Cost over the latest Change Impact Assessment per initiative and Impact Area, by Product Change Type (USD).",
             _u("36", "Change Impact Assessment", "Estimated Impact Cost", "Impact Assessment Date") + _u("36", "Product Change Initiative", "Product Change Type")),
            ("Launched Offerings Not in Catalog", "Count of Service Offering Specification rows whose initiative has Actual Effective Date on or before the as-of date and whose Created Service Offering is empty or resolves to an 01 Service Offering with Offering Status not Active (DP-004).",
             _u("36", "Service Offering Specification", "Created Service Offering", "Offering Specification Change Initiative")
             + _u("36", "Product Change Initiative", "Actual Effective Date") + _u("01", "Service Offering", "Offering ID", "Offering Status")),
            ("Feature Specifications Without Governing Rule", "Count of Platform Feature Specification rows of pipeline initiatives with Governing Policy Rule empty, or launched (Created Platform Feature populated) without Required Disclosure Type where Client Activation Required Indicator = Y.",
             _u("36", "Platform Feature Specification", "Governing Policy Rule", "Created Platform Feature", "Required Disclosure Type",
                "Client Activation Required Indicator")),
            ("Share Class Scope Without Successor Mapping", "Count of Changed Product Scope rows of pipeline initiatives with Scope Share Class populated, Change Scope Role = Removed or Merged and Mapped Successor Share Class empty, by Scope Service Offering.",
             _u("36", "Changed Product Scope", "Scope Change Initiative", "Scope Share Class", "Change Scope Role", "Mapped Successor Share Class", "Scope Service Offering")
             + ["Advice and Platform Changes in Pipeline"]),
            ("Fee Schedule Changes in Pipeline", "Count of Service Offering Specification rows of pipeline initiatives with Proposed Offering Fee Schedule populated, split by Proposed Wrap Fee Program Indicator and Proposed Rule 3a-4 Program Indicator; each needs the advance fee notice requirement.",
             _u("36", "Service Offering Specification", "Proposed Offering Fee Schedule", "Proposed Wrap Fee Program Indicator",
                "Proposed Rule 3a-4 Program Indicator") + ["Advice and Platform Changes in Pipeline"]),
        ],
        inputs=[
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Change Title", "Product Change Type", "Change Status",
                                                 "Originating Proposal", "Change Sponsor", "Planned Effective Date",
                                                 "Actual Effective Date", "Launch Project Code"]),
            ("36", "Service Offering Specification", ["Offering Specification Change Initiative", "Offering Specification Sequence",
                                                      "Specified Offering Type", "Proposed Delivery Mode", "Proposed Discretion Type",
                                                      "Proposed Advisory Capacity", "Proposed Program Minimum",
                                                      "Proposed Offering Fee Schedule", "Proposed Rule 3a-4 Program Indicator",
                                                      "Proposed Wrap Fee Program Indicator", "Created Service Offering"]),
            ("36", "Platform Feature Specification", ["Feature Specification Change Initiative", "Specified Feature Type",
                                                      "Governing Policy Rule", "Created Platform Feature", "Eligible Offerings",
                                                      "Required Disclosure Type", "Client Activation Required Indicator"]),
            ("36", "Changed Product Scope", ["Scope Change Initiative", "Scope Product", "Scope Share Class", "Mapped Successor Share Class", "Scope Service Offering", "Scope Service Tier",
                                             "Scope Model Portfolio", "Change Scope Role", "Scope Added Date", "Scope Removed Date"]),
            ("36", "Change Impact Assessment", ["Impact Change Initiative", "Impact Area", "Impact Severity",
                                                "Affected Shareholder Accounts Count", "Estimated Impact Cost", "Impact Assessment Date"]),
            ("36", "Change Regulatory Requirement", ["Requirement Change Initiative", "Regulatory Requirement Type", "Requirement Product",
                                                     "Minimum Notice Days", "Requirement Due Date", "Requirement Status",
                                                     "Requirement Satisfied Date", "Satisfying Firm Filing",
                                                     "Satisfying Shareholder Communication"]),
            ("01", "Service Offering", ["Offering ID", "Offering Status"]),
        ],
        upstream=["DP-004", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for initiative, specification, impact and requirement changes of the prior business day",
        history="Initiatives, specifications and requirements kept as SCD type 2 with every version; kept six years after the change is effective (SEC Rule 204-2 for Form ADV support)",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Change Sponsor resolves to a DP-192 employee, every Scope Service Offering, Scope Service Tier and Scope Model Portfolio to DP-004, every Created Service Offering to an 01 Offering ID in DP-004, and every specification, scope, impact and requirement row to a Product Change Initiative ID of this product.",
            "Scope Removed Date is empty or on or after Scope Added Date, and Actual Effective Date is populated only when Change Status is Completed or Effective.",
            "Every Change Regulatory Requirement with Requirement Status = Satisfied has Requirement Satisfied Date and one of Satisfying Firm Filing or Satisfying Shareholder Communication populated, and every requirement's Requirement Change Initiative resolves to an initiative with a Service Offering Specification or Platform Feature Specification.",
            "Product Change Type, Change Status and Planned Effective Date are populated on every initiative, Specified Offering Type on every offering specification, Specified Feature Type on every feature specification, and Regulatory Requirement Type, Requirement Due Date and Requirement Status on every requirement.",
            "Every Change Sponsor value matches the DP-192 EMP- key pattern, no column carries a 02 client PTY- key, and Impact Assessed By is not read.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. Affected Shareholder Accounts Count and Estimated Impact Cost are 36 "
               "planning estimates, not certified numbers; 36 Change Impact Assessment Affected AUM is not read (it would be a "
               "planning figure named AUM that is not Firm AUM). "
               "PII tier: identity (employee keys only). "
               "Boundaries: the fund side of the change calendar stays DP-106 (CW-161); DP-106 reads this product for the advice "
               "and platform side (DP-106 RESPEC), so DP-106 is not upstream. Proposed values are 36 until the effective date, "
               "then DP-004 (CD-236). Readiness checks are DP-107. The candidate's DP-211 upstream is dropped: 41 Project and "
               "release objects are not read; Launch Project Code is carried as a key. "
               "Tailoring lever: a separate advice program committee (36 SME 1). Reference default: one product committee for "
               "funds and advice programs. "
               "Tailoring lever: platform features governed under 41 change management only (36 SME 2). Reference default: "
               "features are 36 initiatives as well. "
               "Tailoring lever: negative-consent agreement amendments (36 SME 4). Reference default: allowed with advance notice. "
               "Taxonomy gap: 36 Change Regulatory Requirement has no notice-sent date distinct from Requirement Satisfied Date; "
               "the notice date is taken from the satisfied date. "
               "Drafting assumptions: Change Status values Completed, Withdrawn and Effective; Requirement Status Satisfied; "
               "Regulatory Requirement Type values Form ADV Amendment and Form CRS Amendment; Impact Severity High; the 30- and "
               "90-day windows. "
               "Decisions: CW-161, CW-221, CW-220; CD-236. "
               "WP1 new (CW-220): read by the DP-106 re-spec; the six candidate objects are read, with 01 Service Offering added "
               "for the catalog check."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-385": dict(
        definition=("The client-outcome evidence behind each review of an advice program (36 Product Review of a service "
                    "offering or model portfolio): drift outcomes, personal returns, fees, complaints, enrollments, terminations "
                    "and net new assets by program, with the review's criterion results and actions. Product governance concludes "
                    "whether each program still serves the clients enrolled in it and records what it will change. Returns, "
                    "client assets, fee revenue and complaint counts are read from DP-145, DP-008, DP-012 and DP-414, never "
                    "recomputed. It owns no certified metric family."),
        business_questions=[
            "Which advice program reviews are overdue, and which concluded that a program does not serve its clients?",
            "How do the programs compare on accounts outside drift tolerance, personal returns, net fee revenue, complaints and terminations over the review period?",
            "What net new assets did each program gather in the review period (from DP-491), and what advised assets does its advice channel hold (from DP-008)?",
            "Which criterion results lack the evidence their criterion needs?",
            "Which review actions are overdue, and how many became change initiatives?",
        ],
        grain=("Advice program review (36 Product Review of a service offering or model portfolio) x product review criterion, "
               "with program evidence at service offering x review period (enrollments, drift, returns, revenue, complaints, "
               "flows) and review actions as companion facts; immutable per review version"),
        dimensions=["Service offering and model portfolio (DP-004)", "Product review type", "Review period", "Review outcome",
                    "Product review criterion and criterion rating", "Review action type and status",
                    "Enrollment termination reason", "Personal return method and fee basis (DP-145)", "As-of date (DP-013)"],
        measures=[
            ("Program Reviews Overdue", "Count of service offerings whose latest Product Review with Review Service Offering populated has Next Review Due Date before the as-of date and no later review of the same Review Service Offering and Product Review Type.",
             _u("36", "Product Review", "Product Review ID", "Review Service Offering", "Product Review Type", "Next Review Due Date", "Review Period End")),
            ("Programs Concluded Not Serving Clients", "Count of program reviews in the period with Review Outcome in Changes Required or Not Providing Value, or any Criterion Rating at the lowest level of the scale, by Review Service Offering.",
             _u("36", "Product Review", "Review Outcome", "Review Service Offering", "Review Status")
             + _u("36", "Product Review Criterion Result", "Criterion Review", "Criterion Rating")),
            ("Program Criterion Rating Distribution", "Count of Product Review Criterion Result rows of program reviews by Product Review Criterion and Criterion Rating, by Review Period End.",
             _u("36", "Product Review Criterion Result", "Criterion Review", "Product Review Criterion", "Criterion Rating")
             + _u("36", "Product Review", "Review Period End")),
            ("Program Criteria Without Evidence", "Count of program criterion results whose criterion needs evidence and whose evidence column is empty: drift needs Drift Exception Evidence Count, performance Performance Evidence Return, flows Flow Evidence Measure Value, complaints Complaint Evidence Count; any criterion needs Evidence Metric Definition or Criterion Conclusion.",
             _u("36", "Product Review Criterion Result", "Product Review Criterion", "Drift Exception Evidence Count", "Performance Evidence Return",
                "Flow Evidence Measure Value", "Complaint Evidence Count", "Evidence Metric Definition", "Criterion Conclusion")),
            ("Enrolled Accounts", "Count of distinct Enrolled Account of Program Enrollment rows with Enrollment Status = Active at Review Period End (Enrollment Effective Date on or before it and Enrollment Termination Date empty or after it), by Enrolled Service Offering (DP-093).",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status",
                "Enrollment Effective Date", "Enrollment Termination Date")),
            ("Program Termination Rate %", "Program Enrollment rows with Enrollment Termination Date in the review period / Enrolled Accounts at Review Period Start, by Enrolled Service Offering and Enrollment Termination Reason.",
             _u("15", "Program Enrollment", "Enrollment Termination Date", "Enrollment Termination Reason", "Enrolled Service Offering")
             + _u("36", "Product Review", "Review Period Start") + ["Enrolled Accounts"]),
            ("Accounts Outside Drift Tolerance % (from DP-304)", "Enrolled Accounts whose latest Drift Assessment on or before Review Period End has Tolerance Breached Indicator = Y / Enrolled Accounts with a Drift Assessment in the period, by program; the drift assessment is DP-304's, read as published.",
             _u("46", "Drift Assessment", "Drift Assessment ID", "Assessed Account", "Assessment Timestamp", "Tolerance Breached Indicator")
             + ["Enrolled Accounts"]),
            ("Median Personal Return by Program (from DP-145)", "Median of Personal Return Value of Personal Rate of Return rows with Personal Return Status = Final, Personal Return Subject Type = Account, Personal Return Method = Time-Weighted, Personal Return Fee Basis = Net of Fees and period equal to the review period, over the program's Enrolled Accounts; the 25th and 75th percentiles beside it. Each value is DP-145's certified Personal Return Value, read and never recomputed.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Account", "Personal Return Subject Type",
                "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Method", "Personal Return Fee Basis",
                "Personal Return Value", "Personal Return Status") + ["Enrolled Accounts"]),
            ("NNA by Offering and Program (from DP-491)", "DP-491's published NNA by Offering and Program for the program's Offering ID, summed over the months of the review period: an operational decomposition of the DP-008 Net New Assets by the Service Offering of 06 Market & Client Dimensions at each Attribution Record's Attributed Amount, which ties to the DP-008 total; not a certified number (DP-008 publishes no offering slice). Read, never re-weighted here.",
             _u("06", "Market & Client Dimensions", "Service Offering") + _u("06", "Attribution Record", "Attribution Record ID", "Attributed Amount")
             + _u("06", "Client Asset Measures", "Net New Assets")),
            ("Advice Channel Advised Assets (from DP-008)", "Measure Amount of MSR-ADVISEDASSETS at Dimension Type Channel for the program's distribution channel (Direct - Digital Advice, Direct - Human Advice or Direct - Trust) at Review Period End, from the Final or Restated DP-008 Snapshot; DP-008 publishes no offering slice of Advised Assets.",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Advised Assets") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Net Fee Revenue by Program (from DP-012)", "DP-012 Net Fee Revenue at its Revenue Service Offering dimension for the program, over the Client Revenue Periods of the review period (the Client Revenue Records it is published from are named for traceability); certified, read and never recomputed.",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Revenue Service Offering", "Client Revenue Period",
                "Client Revenue Stream", "Recognized Revenue Amount")),
            ("Complaints per 1,000 Enrolled Accounts (from DP-414)", "Count of DP-414 complaints with Received Date in the review period whose Account is an Enrolled Account of the program / Enrolled Accounts x 1,000; complaints are counted and classified by DP-414, never reclassified here.",
             _u("08", "Complaint", "Complaint ID", "Received Date", "Account") + ["Enrolled Accounts"]),
            ("Program Review Actions Overdue", "Count of Review Action rows of program reviews with Review Action Due Date before the as-of date and Review Action Completed Date empty, by Review Action Type.",
             _u("36", "Review Action", "Action Review", "Review Action Sequence", "Review Action Due Date", "Review Action Completed Date",
                "Review Action Type")),
            ("Program Actions Converted to Change %", "Review Action rows of program reviews with Review Action Type a change type and Resulting Change Initiative populated / Review Action rows of a change type, with Review Action Status.",
             _u("36", "Review Action", "Review Action Type", "Resulting Change Initiative", "Review Action Status")),
        ],
        inputs=[
            ("36", "Product Review", ["Product Review ID", "Review Product", "Review Model Portfolio", "Review Service Offering",
                                      "Product Review Type", "Review Period Start", "Review Period End", "Review Status",
                                      "Review Outcome", "Next Review Due Date"]),
            ("36", "Product Review Criterion Result", ["Criterion Review", "Product Review Criterion", "Criterion Rating",
                                                       "Criterion Conclusion", "Performance Evidence Return", "Flow Evidence Measure Value",
                                                       "Complaint Evidence Count", "Drift Exception Evidence Count",
                                                       "Evidence Metric Definition"]),
            ("36", "Review Action", ["Action Review", "Review Action Sequence", "Review Action Type", "Review Action Due Date",
                                     "Review Action Completed Date", "Review Action Status", "Resulting Change Initiative"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status",
                                          "Enrollment Effective Date", "Enrollment Termination Date", "Enrollment Termination Reason"]),
            ("46", "Drift Assessment", ["Drift Assessment ID", "Assessed Account", "Assessment Timestamp", "Tolerance Breached Indicator"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Account", "Personal Return Subject Type",
                                               "Personal Return Period Start Date", "Personal Return Period End Date",
                                               "Personal Return Method", "Personal Return Fee Basis", "Personal Return Value",
                                               "Personal Return Status"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Net New Assets", "Advised Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Market & Client Dimensions", ["Service Offering"]),
            ("06", "Attribution Record", ["Attribution Record ID", "Attributed Amount"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Revenue Service Offering", "Client Revenue Period",
                                             "Client Revenue Stream", "Recognized Revenue Amount"]),
            ("08", "Complaint", ["Complaint ID", "Received Date", "Account"]),
        ],
        upstream=["DP-004", "DP-093", "DP-304", "DP-145", "DP-008", "DP-491", "DP-012", "DP-414", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, after the DP-008 Final snapshot and the DP-145 period close; review evidence packs on event when a program review opens",
        history="Monthly program evidence snapshots and every review version kept immutable; ten years (product governance record; SEC Rule 204-2 for the supporting records)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Review Service Offering and Enrolled Service Offering resolves to a DP-004 Offering ID, every Enrolled Account, Assessed Account, Personal Return Account and complaint Account to a DP-093 Account ID, and every Criterion Review and Action Review to a Product Review ID of this product.",
            "Review Period End is on or after Review Period Start on every review, and an enrolled account is counted in only one Program Enrollment of the same Enrolled Service Offering at Review Period End (no overlapping enrollment periods).",
            "NNA by Offering and Program (from DP-491) equals the DP-491 published value for the same Offering ID and months, Advice Channel Advised Assets equals the DP-008 Measure Amount for the same Dimension Key and Snapshot ID, and Net Fee Revenue by Program equals the DP-012 Recognized Revenue Amount for the same Revenue Service Offering and period, with no difference.",
            "Review Service Offering, Product Review Type, Review Period Start, Review Period End and Next Review Due Date are populated on every program review, and Product Review Criterion and Criterion Rating on every criterion result.",
            "Account-level rows (enrollments, drift, personal returns, complaints) are kept in a restricted drill for product governance; the published product is at program and review period grain with a minimum of 10 enrolled accounts per cell.",
            "Program evidence for a month is published only after the DP-008 snapshot of that month is Final and the DP-145 period is closed, by business day 10.",
        ],
        notes=("Certified numbers: reads DP-491's operational offering decomposition of DP-008 Net New Assets (not certified), Advised Assets at the advice "
               "channel (DP-008), Personal Return Value (DP-145, extended) and client fee revenue (DP-012) at program grain; owns "
               "none. "
               "PII tier: financial (account keys in the restricted drill). Published at program and cohort grain. "
               "Boundaries: DP-109 Product Reviews & Criterion Results stays the review register for funds and programs and reads "
               "this product for advice program evidence (DP-109 RESPEC), so DP-109 is not upstream (the candidate listed it). "
               "Drift is DP-304's assessment, read as published; complaints are counted by DP-414; the program review cycle is 36 "
               "Product Review Next Review Due Date. The candidate's 01 Product Governance is not read: its grain is the investment "
               "product, not the advice program, and DP-109 reads it for funds. DP-339 Digital Advice Engine Outcomes & Oversight "
               "(backlog) folds in here. "
               "Tailoring lever: advice offerings run (01 SME 1). Reference default: digital, hybrid, personal advisor, wealth "
               "management, planning-only, workplace managed account and OCIO programs; a self-directed-only firm drops this "
               "product. "
               "Tailoring lever: risk-based review cycles (36 SME 3). Reference default: annual review of every program. "
               "Tailoring lever: criterion rating scale (36 SME 7). Reference default: four-point scale, lowest = does not meet. "
               "Taxonomy gap: 06 Measure Value carries no Service Offering dimension type for DP-008 values (Total, Channel, Holding "
               "Type, Business Line, Share Class, Segment, Advisor, Campaign); the offering slice of Net New Assets comes from "
               "DP-491 and Advised Assets is shown at the advice channel. "
               "Taxonomy gap: 36 Product Review Criterion Result has no fee or net fee revenue evidence for a service offering "
               "(Fee Evidence Study and Cost Evidence Profitability Record are fund evidence); program fee evidence is traced to "
               "10 Client Revenue Record. "
               "Drafting assumptions: Review Outcome values Changes Required and Not Providing Value; the personal return method "
               "and fee basis filters; the minimum cell of 10 accounts. "
               "Decisions: CW-011, CW-129, CW-161, CW-220; CD-238. "
               "WP1 new (CW-220): read by the DP-109 re-spec; absorbs backlog DP-339. Complaint counts come from DP-414 and "
               "returns from DP-145; DP-040 (retired) is not read."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-387": dict(
        definition=("Each advisor's and coverage team's book against capacity: households, clients and accounts assigned, "
                    "capacity used, client assets, net new assets and advised assets by advisor of record (from DP-008), advice "
                    "review completion, service demand, household attrition and reassignments, credentials, and the profile of "
                    "the book (service tier mix, protected households as a count from DP-322). Practice managers decide hiring, "
                    "book rebalancing and which advisors take new clients. It owns no certified metric family."),
        business_questions=[
            "Which advisors and teams are over or near household capacity, and which accepting new clients still have room?",
            "What client assets, advised assets and net new assets does each advisor's book hold and gather this quarter (from DP-008)?",
            "Which advisors are behind on advice reviews, and where is service demand per household highest?",
            "Which books lost households this period, and how many households were reassigned in and with how much notice?",
            "How is each book made up by service tier, and how many protected households does it hold?",
        ],
        grain=("Advisor or coverage team x capacity as-of date (03 Advisor Capacity Snapshot), with the book's households "
               "(03 Party Coverage Assignment), certified asset values by advisor of record, advice reviews, reassignments and "
               "credentials as companion facts; monthly snapshots"),
        dimensions=["Advisor and coverage team (DP-009)", "Coverage role and primary coverage", "Service tier (DP-004)",
                    "Advisor status and accepting-new-clients indicator", "Advice channel offered",
                    "Client household (DP-240)", "Advice review type (DP-303)", "Reassignment reason",
                    "Credential type", "As-of month (DP-013)"],
        measures=[
            ("Assigned Households", "Assigned Household Count of the Advisor Capacity Snapshot at Capacity As-Of Date, by Capacity Subject Advisor and Capacity Subject Team, with Assigned Client Count and Assigned Account Count beside it.",
             _u("03", "Advisor Capacity Snapshot", "Capacity Subject Advisor", "Capacity Subject Team", "Capacity As-Of Date",
                "Assigned Household Count", "Assigned Client Count", "Assigned Account Count")),
            ("Capacity Utilization %", "Assigned Household Count / Household Capacity Limit of the same snapshot; where Household Capacity Limit is empty, the Maximum Households per Advisor of the Coverage Model whose Delivery Mode matches the advisor's Advice Channels Offered.",
             _u("03", "Advisor Capacity Snapshot", "Assigned Household Count", "Household Capacity Limit")
             + _u("03", "Coverage Model", "Coverage Model Code", "Delivery Mode", "Maximum Households per Advisor")
             + _u("03", "Advisor", "Advice Channels Offered")),
            ("Advisors Over Capacity", "Count of advisors with Capacity Utilization % above 100%, and of those between 90% and 100% (near capacity), by Capacity Subject Team.",
             _u("03", "Advisor Capacity Snapshot", "Capacity Subject Team") + ["Capacity Utilization %"]),
            ("Advisors Open to New Clients With Capacity", "Count of advisors with Advisor Status = Active, Accepting New Clients Indicator = Y and Available Household Capacity > 0 at the snapshot, with the sum of Available Household Capacity.",
             _u("03", "Advisor", "Employee", "Advisor Status", "Accepting New Clients Indicator")
             + _u("03", "Advisor Capacity Snapshot", "Available Household Capacity")),
            ("Book Client Assets by Advisor (from DP-008)", "Measure Amount of the DP-008 Measure Value with Measure MSR-CLIENTASSETS (Ending Client Assets), Dimension Type Advisor and Dimension Key = the advisor's Employee, at the month end, from the Final or Restated Snapshot; read, never recomputed. The 03 Book Client Assets copy is used only in DQ3.",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Ending Client Assets") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Book Net New Assets by Advisor (from DP-008)", "Measure Amount of MSR-NNA at Dimension Type Advisor for the advisor, summed over the months of the quarter from the same DP-008 snapshots; advisor of record from the 03 primary Party Coverage Assignment as DP-008 applies it.",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Net New Assets")),
            ("Book Advised Assets by Advisor (from DP-008)", "Measure Amount of MSR-ADVISEDASSETS at Dimension Type Advisor for the advisor at the month end.",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Advised Assets")),
            ("Households Without Primary Advisor", "Count of client households (Covered Party of Party Coverage Role Household or the household of a covered client, DP-240) with no Party Coverage Assignment with Primary Coverage Indicator = Y effective at the as-of date (Coverage Effective From on or before it and Coverage Effective To empty or after it), by Covering Coverage Team of the last assignment.",
             _u("03", "Party Coverage Assignment", "Covered Party", "Party Coverage Role", "Primary Coverage Indicator", "Coverage Effective From",
                "Coverage Effective To", "Covering Coverage Team") + _u("02", "Household Membership", "Household", "Household Member", "Membership Status")),
            ("Advice Review Completion %", "Advice Review rows with Review Due Date in the period and Review Held Date on or before Review Due Date / Advice Review rows with Review Due Date in the period, by Review Conducted By and Advice Review Type (DP-303).",
             _u("45", "Advice Review", "Advice Review ID", "Review Due Date", "Review Held Date", "Review Conducted By", "Advice Review Type")),
            ("Service Requests per Household (from DP-381)", "Count of DP-381 Service Request rows with Received Timestamp in the period whose Account has a 15 Account Party Role owner (Role Party) who is a Household Member of a household in the advisor's book / Assigned Households.",
             _u("13", "Service Request", "Service Request ID", "Account", "Received Timestamp") + _u("15", "Account Party Role", "Role Account", "Role Party")
             + _u("02", "Household Membership", "Household", "Household Member") + ["Assigned Households"]),
            ("Household Attrition Rate %", "Households whose primary Party Coverage Assignment to the advisor ended in the period (Coverage Effective To in the period) without a Coverage Reassignment Item moving them to another advisor and without a later primary assignment / Assigned Households at period start.",
             _u("03", "Party Coverage Assignment", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective To")
             + _u("03", "Coverage Reassignment Item", "Reassigned Household") + ["Assigned Households"]),
            ("Households Reassigned In", "Count of Coverage Reassignment Item rows of reassignments with To Advisor = the advisor and Reassignment Effective Date in the period, by Reassignment Reason and From Advisor.",
             _u("03", "Coverage Reassignment", "Reassignment ID", "To Advisor", "From Advisor", "Reassignment Effective Date", "Reassignment Reason")
             + _u("03", "Coverage Reassignment Item", "Reassigned Household")),
            ("Reassignment Notice Timeliness %", "Coverage Reassignment Item rows with Client Notice Sent Date on or before the Planned Client Notice Date of their reassignment / Coverage Reassignment Item rows with Reassignment Effective Date in the period.",
             _u("03", "Coverage Reassignment Item", "Client Notice Sent Date")
             + _u("03", "Coverage Reassignment", "Planned Client Notice Date", "Reassignment Effective Date")),
            ("Book Service Tier Mix", "Count of the advisor's households by Assigned Service Tier of the 02 Service Tier Assignment in force at the as-of date (Tier Effective From on or before it, Tier Effective To empty or after it).",
             _u("02", "Service Tier Assignment", "Tier Party", "Assigned Service Tier", "Tier Effective From", "Tier Effective To")
             + _u("03", "Party Coverage Assignment", "Covered Party", "Covering Advisor")),
            ("Protected Households in Book (from DP-322)", "Count of the advisor's households with at least one member whose Protection Flag Present (from DP-322) = Y, joined on the 02 party key (Household Member) only; published only where the count is 10 or more.",
             _u("02", "Household Membership", "Household", "Household Member") + _u("03", "Party Coverage Assignment", "Covered Party", "Covering Advisor")),
            ("Advisors With Lapsed Credentials", "Count of advisors with an Advisor Credential whose Credential Status is Lapsed or Expired, or whose Credential Effective To is before the as-of date, for credentials named in Advisor Specialties, by Credential Type.",
             _u("03", "Advisor Credential", "Credential Holder", "Credential Type", "Credential Status", "Credential Effective To")
             + _u("03", "Advisor", "Advisor Specialties")),
        ],
        inputs=[
            ("03", "Advisor Capacity Snapshot", ["Capacity Subject Advisor", "Capacity Subject Team", "Capacity As-Of Date",
                                                 "Assigned Household Count", "Assigned Client Count", "Assigned Account Count",
                                                 "Book Client Assets", "Household Capacity Limit", "Available Household Capacity"]),
            ("03", "Party Coverage Assignment", ["Coverage Assignment ID", "Covered Party", "Covering Advisor", "Covering Coverage Team",
                                                 "Party Coverage Role", "Primary Coverage Indicator", "Coverage Effective From",
                                                 "Coverage Effective To"]),
            ("03", "Coverage Model", ["Coverage Model Code", "Delivery Mode", "Target Households per Advisor", "Maximum Households per Advisor"]),
            ("03", "Advisor", ["Employee", "Advisor Status", "Accepting New Clients Indicator", "Advice Channels Offered",
                               "Advisor Specialties"]),
            ("03", "Advisor Credential", ["Credential Holder", "Credential Type", "Credential Status", "Credential Effective To"]),
            ("03", "Coverage Reassignment", ["Reassignment ID", "Reassignment Reason", "From Advisor", "To Advisor",
                                             "Reassignment Effective Date", "Planned Client Notice Date"]),
            ("03", "Coverage Reassignment Item", ["Reassigned Household", "Client Notice Sent Date"]),
            ("45", "Advice Review", ["Advice Review ID", "Advice Review Type", "Review Due Date", "Review Held Date", "Review Conducted By"]),
            ("13", "Service Request", ["Service Request ID", "Account", "Received Timestamp"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status"]),
            ("15", "Account Party Role", ["Role Account", "Role Party", "Account Role Type"]),
            ("02", "Service Tier Assignment", ["Tier Party", "Assigned Service Tier", "Tier Effective From", "Tier Effective To"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Net New Assets", "Advised Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
        ],
        upstream=["DP-009", "DP-008", "DP-240", "DP-004", "DP-303", "DP-381", "DP-322", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end, after the DP-008 Final snapshot; capacity and coverage refreshed weekly in the advisor-manager view",
        history="Monthly snapshots kept seven years; coverage and reassignments as SCD type 2 from DP-009",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Capacity Subject Advisor, Covering Advisor, From Advisor, To Advisor, Credential Holder and Review Conducted By resolves to an active DP-009 advisor, every Covered Party, Reassigned Household and Tier Party to a DP-240 party, and every Dimension Key of Dimension Type Advisor to a DP-009 advisor.",
            "Party Coverage Assignment periods with Primary Coverage Indicator = Y do not overlap for the same Covered Party and Party Coverage Role, and Coverage Effective To is empty or on or after Coverage Effective From.",
            "Book Client Assets by Advisor (from DP-008) equals the DP-008 Measure Amount for the same advisor, month end and Snapshot ID, and the 03 Book Client Assets copy on the Advisor Capacity Snapshot ties to it within 0.5% per advisor; a larger gap is a stewardship exception on 03, never a correction of the certified value.",
            "Assigned Household Count, Household Capacity Limit or a matching Coverage Model, and Capacity As-Of Date are populated on every snapshot, and Review Due Date on every advice review.",
            "Protected Households in Book carries only the DP-322 Protection Flag Present count joined on party keys, published only at counts of 10 or more; no 02 Specified Adult Status, Vulnerability Concern or reason is read, and household-level rows are restricted to the advisor's practice manager.",
            "A month is published only after its DP-008 snapshot is Final, by business day 5.",
        ],
        notes=("Plan section 8.3 example (Advisor Capacity & Book Health). "
               "Certified numbers: reads Ending Client Assets, Net New Assets and Advised Assets by advisor of record from DP-008 "
               "(CW-011, CW-226); owns none. The 03 Book Client Assets copy is never published as a value. "
               "PII tier: financial (advisor identity and household keys with book assets); protected households only as a "
               "DP-322 count (CD-344, CW-225). "
               "Boundaries: assets and NNA by advisor are DP-008's; DP-491 (DIS) publishes NNA by channel, offering and advisor "
               "from DP-008 directly; no edge exists between DP-491 and this product (amended CW-227). Reassignment retention (backlog DP-388) "
               "and contact cadence (backlog DP-389) fold in here; the advisor's action list is DP-340 (backlog). Coverage, teams "
               "and assignment rules are conformed by DP-009. Advisor departure risk (from retired DP-048) is not published: "
               "no scoring model for it is registered in 37 (DP-212). "
               "Acceptance question 2: context for the advisor slice that DP-491 answers from DP-008 (Assigned Households, "
               "Capacity Utilization % beside Book Net New Assets by Advisor (from DP-008)); not an edge. "
               "Tailoring lever: pooled teams (03 SME 2). Reference default: household grain with pooled coverage teams for "
               "digital advice; pooled books are measured at Capacity Subject Team. "
               "Tailoring lever: household or client grain (03 SME 3). Reference default: household. "
               "Taxonomy gap: 03 Advisor and Coverage Team have no reference to the Coverage Model an advisor works under; the "
               "model capacity is matched through Delivery Mode and Advice Channels Offered. "
               "Taxonomy gap: 03 Party Coverage Assignment has no end reason; attrition is inferred from the absence of a "
               "reassignment or later assignment. "
               "Drafting assumptions: the 90% near-capacity band; Credential Status values Lapsed and Expired; the minimum count "
               "of 10; Dimension Type value Advisor on 06 Measure Value. "
               "Decisions: CW-011, CW-063, CW-138, CW-143, CW-226, CW-213; CD-344. "
               "WP1 new (CW-226): plan section 8.3 example; also reads 03 Coverage Reassignment Item (moved from backlog DP-388) "
               "and absorbs DP-388 and DP-389 scope (WP1_Scope.md). The candidate objects are all read."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-390": dict(
        definition=("Each advisor incentive compensation plan and component with the 08 Reg BI incentive conflict review behind "
                    "it, every participant, the compensation statements and earnings lines per period and the recognition awards. "
                    "Compensation and conduct see which components lack a current review, which measures could favor a product "
                    "or a rollover, and what was earned on each component, with asset-based results tied to DP-008. It is the "
                    "successor of the 07 compensation products DP-032, DP-033 and DP-082. It owns no certified metric family: "
                    "certified pay stays DP-198."),
        business_questions=[
            "Which incentive plan components and recognition awards in force lack a current Reg BI conflict review, and which reviews found a conflict?",
            "Which components are product-specific and time-limited, linked to proprietary products, or not rollover-neutral?",
            "What did each component pay this period, and how does earned compare with target by plan and advisor role?",
            "Do asset-based measured results agree with the certified Net New Assets and Client Assets by advisor (from DP-008)?",
            "Which participants have not acknowledged their plan, and which statements were issued but not paid through payroll?",
        ],
        grain=("Compensation statement (advisor x statement period) x plan component earnings line, with plans, components, "
               "participation, recognition awards and incentive conflict reviews as companion tables; statements immutable "
               "once issued, plans and components SCD type 2"),
        dimensions=["Incentive plan, plan type and plan year", "Plan component and component measure", "Advisor and advisor role (DP-009)",
                    "Employee (DP-192)", "Payout frequency", "Conflict review outcome", "Recognition program and award type",
                    "Statement period (DP-013)"],
        measures=[
            ("Active Incentive Plans", "Count of Incentive Compensation Plan rows with Plan Approval Status = Approved effective at the as-of date (Plan Effective From on or before it, Plan Effective To empty or after it), by Incentive Plan Type and Incentive Plan Year.",
             _u("03", "Incentive Compensation Plan", "Incentive Plan ID", "Plan Approval Status", "Plan Effective From", "Plan Effective To",
                "Incentive Plan Type", "Incentive Plan Year")),
            ("Components Without Current Conflict Review", "Count of Incentive Plan Component rows of Active Incentive Plans with no Incentive Conflict Review whose Reviewed Incentive Plan Component is the component and whose Conflict Review Date is within the 12 months before the as-of date.",
             _u("03", "Incentive Plan Component", "Component ID", "Parent Incentive Plan")
             + _u("08", "Incentive Conflict Review", "Reviewed Incentive Plan Component", "Conflict Review Date") + ["Active Incentive Plans"]),
            ("Product-Specific Time-Limited Components", "Count of components of Active Incentive Plans with Product-Specific Time-Limited Indicator = Y (prohibited under Reg BI's conflict obligation), and of those with Proprietary Product Linked Indicator = Y, by Component Measure.",
             _u("03", "Incentive Plan Component", "Product-Specific Time-Limited Indicator", "Proprietary Product Linked Indicator", "Component Measure")
             + ["Active Incentive Plans"]),
            ("Components Not Rollover-Neutral", "Count of components of Active Incentive Plans with Rollover Neutral Indicator not Y, by Component Measure and Component Weight band.",
             _u("03", "Incentive Plan Component", "Rollover Neutral Indicator", "Component Measure", "Component Weight") + ["Active Incentive Plans"]),
            ("Conflict Reviews With Adverse Finding", "Count of Incentive Conflict Review rows in the period with Conflict Review Outcome in Mitigation Required or Prohibited, or Proprietary Product Incentive Finding populated, split by whether Mitigation Applied is populated.",
             _u("08", "Incentive Conflict Review", "Conflict Review Date", "Conflict Review Outcome", "Proprietary Product Incentive Finding",
                "Mitigation Applied", "Conflict Tests Applied")),
            ("Recognition Awards on Product-Specific Criteria", "Count of Recognition Award rows with Award Date in the period and Product-Specific Criteria Indicator = Y, with the sum of Non-Cash Award Value, by Recognition Program.",
             _u("03", "Recognition Award", "Recognition Award ID", "Award Date", "Product-Specific Criteria Indicator", "Non-Cash Award Value",
                "Recognition Program")),
            ("Recognition Awards Without Conduct Review", "Count of Recognition Award rows in the period with Award Conduct Review Reference empty and no Incentive Conflict Review with Reviewed Recognition Award = the award.",
             _u("03", "Recognition Award", "Recognition Award ID", "Award Conduct Review Reference", "Award Date")
             + _u("08", "Incentive Conflict Review", "Reviewed Recognition Award")),
            ("Participants Without Plan Acknowledgment", "Count of Incentive Plan Participation rows effective at the as-of date with Participant Eligibility Status = Eligible and Plan Acknowledgment Date empty, by Assigned Plan.",
             _u("03", "Incentive Plan Participation", "Plan Participant", "Assigned Plan", "Participant Eligibility Status", "Plan Acknowledgment Date",
                "Participation Effective From", "Participation Effective To")),
            ("Incentive Earned by Component", "Sum of Earned Amount of Incentive Earnings Line rows on Compensation Statements with Statement Period End in the period, by Earning Component and Component Measure (USD).",
             _u("03", "Incentive Earnings Line", "Earning Component", "Earned Amount") + _u("03", "Compensation Statement", "Statement ID", "Statement Period End")
             + _u("03", "Incentive Plan Component", "Component Measure")),
            ("Mean Attainment by Component", "Mean Attainment Percentage of Incentive Earnings Line rows by Earning Component for statements in the period, with the share at or above the component's Threshold Attainment and at the Cap Amount.",
             _u("03", "Incentive Earnings Line", "Earning Component", "Attainment Percentage", "Earned Amount")
             + _u("03", "Incentive Plan Component", "Threshold Attainment", "Cap Amount")),
            ("Earned vs Target %", "Sum of Total Earned of the participant's Compensation Statements in the Incentive Plan Year / Target Incentive Amount of the participant's Incentive Plan Participation, by Assigned Plan and advisor role.",
             _u("03", "Compensation Statement", "Statement Participant", "Total Earned", "Statement Period End")
             + _u("03", "Incentive Plan Participation", "Plan Participant", "Assigned Plan", "Target Incentive Amount")),
            ("Net Payable on Issued Statements", "Sum of Net Payable Amount of Compensation Statements with Statement Status = Issued and Statement Issued Date in the period (USD), by statement period.",
             _u("03", "Compensation Statement", "Net Payable Amount", "Statement Status", "Statement Issued Date")),
            ("Issued Statements Not Paid Through Payroll", "Count of Compensation Statements with Statement Status = Issued, Statement Issued Date more than 30 days before the as-of date and Payroll Result Reference empty; the payroll result itself is DP-198's.",
             _u("03", "Compensation Statement", "Statement ID", "Statement Status", "Statement Issued Date", "Payroll Result Reference")),
            ("Earned Tie-Out to Variable Awards (from DP-198)", "Sum of Total Earned of a participant's Compensation Statements in the Incentive Plan Year - Award Amount of the 20 Variable Compensation Awards of Variable Award Type = Advisor Incentive for the same Award Recipient and Performance Year, as DP-198 publishes them (USD, Award Currency); differences above USD 1 listed.",
             _u("03", "Compensation Statement", "Statement Participant", "Total Earned", "Statement Period End")
             + _u("20", "Variable Compensation Award", "Variable Compensation Award ID", "Award Recipient", "Variable Award Type", "Performance Year", "Award Amount", "Award Currency")),
            ("Asset-Based Results Differing From DP-008", "Count of Incentive Earnings Line rows whose component has Component Measure Net New Assets or Client Assets and whose Measured Result differs by more than 0.5% from the DP-008 Measure Amount (MSR-NNA or MSR-CLIENTASSETS) at Dimension Type Advisor for the Statement Participant and Statement Period End, from the Final snapshot; the certified value is never replaced here.",
             _u("03", "Incentive Earnings Line", "Measured Result", "Earning Component") + _u("03", "Incentive Plan Component", "Component Measure")
             + _u("03", "Compensation Statement", "Statement Participant", "Statement Period End") + _mv("Snapshot")
             + _u("06", "Client Asset Measures", "Net New Assets", "Ending Client Assets")),
        ],
        inputs=[
            ("03", "Incentive Compensation Plan", ["Incentive Plan ID", "Incentive Plan Name", "Incentive Plan Type", "Incentive Plan Year",
                                                   "Payout Frequency", "Eligible Advisor Roles", "Plan Approval Status",
                                                   "Plan Effective From", "Plan Effective To"]),
            ("03", "Incentive Plan Component", ["Component ID", "Parent Incentive Plan", "Component Measure", "Component Weight",
                                                "Threshold Attainment", "Cap Amount", "Product-Specific Time-Limited Indicator",
                                                "Proprietary Product Linked Indicator", "Rollover Neutral Indicator",
                                                "Incentive Conflict Review Reference"]),
            ("03", "Incentive Plan Participation", ["Plan Participant", "Assigned Plan", "Target Incentive Amount",
                                                    "Participant Eligibility Status", "Plan Acknowledgment Date",
                                                    "Participation Effective From", "Participation Effective To"]),
            ("03", "Compensation Statement", ["Statement ID", "Statement Participant", "Statement Period End", "Total Earned",
                                              "Net Payable Amount", "Statement Status", "Statement Issued Date", "Payroll Result Reference"]),
            ("03", "Incentive Earnings Line", ["Earning Component", "Measured Result", "Attainment Percentage", "Earned Amount"]),
            ("03", "Recognition Award", ["Recognition Award ID", "Award Recipient", "Recognition Program", "Recognition Award Type",
                                         "Award Date", "Non-Cash Award Value", "Product-Specific Criteria Indicator",
                                         "Award Conduct Review Reference"]),
            ("20", "Variable Compensation Award", ["Variable Compensation Award ID", "Award Recipient", "Variable Award Type", "Performance Year",
                                                   "Award Amount", "Award Currency"]),
            ("08", "Incentive Conflict Review", ["Reviewed Incentive Plan Component", "Reviewed Recognition Award", "Conflict Review Date",
                                                 "Conflict Tests Applied", "Proprietary Product Incentive Finding",
                                                 "Conflict Review Outcome", "Mitigation Applied"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Net New Assets", "Ending Client Assets"]),
        ],
        upstream=["DP-009", "DP-192", "DP-198", "DP-008", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 8 after each statement period end; conflict reviews and plan changes daily by 7am ET",
        history="Statements and earnings lines immutable once issued; plans, components, participation and reviews SCD type 2; kept seven years (FINRA Rule 4511 books and records, SEC Rule 17a-4)",
        classification="Confidential - Compensation",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Statement Participant, Plan Participant and Award Recipient resolves to a DP-009 advisor and DP-192 employee, every Parent Incentive Plan and Assigned Plan to an Incentive Plan ID, and every Reviewed Incentive Plan Component and Reviewed Recognition Award to a Component ID or Recognition Award ID of this product.",
            "Incentive Plan Participation periods do not overlap for the same Plan Participant and Assigned Plan, and every period and plan effective range ends on or after it starts.",
            "The Component Weight of the components of each plan sums to 100% within 0.1%, the Earned Amount of a statement's earnings lines sums to its Total Earned to the cent, and asset-based Measured Results are compared with the DP-008 published value as in Asset-Based Results Differing From DP-008.",
            "Component Measure, Product-Specific Time-Limited Indicator and Rollover Neutral Indicator are populated on every component, Conflict Review Outcome on every conflict review, and Net Payable Amount and Statement Status on every statement.",
            "Individual amounts are visible only to compensation, HR and compliance roles; other views carry plan and component aggregates with at least 10 participants per cell, and no 20 pay or bank data is read.",
            "A statement period is locked once its statements are Issued; later corrections arrive as a new statement version, never as an edit.",
        ],
        notes=("Certified numbers: reads Net New Assets and Ending Client Assets by advisor (DP-008) for the asset-based tie-out "
               "(CW-226); certified pay stays DP-198; owns none. "
               "PII tier: financial (employee compensation; Confidential - Compensation; restricted to compensation, HR and "
               "compliance). "
               "Boundaries: incentives in reduced form are 03, pay in 20, the Reg BI incentive review in 08 (CW-064, CW-168). This "
               "product succeeds the 07 compensation products DP-032, DP-033 and DP-082 (WP0 ruling) and is the re-point target of "
               "live DP-198 (DP-198 names this product as the successor in its notes and never lists it). This product lists DP-198 "
               "upstream for the certified pay tie-out (Earned Tie-Out to Variable Awards (from DP-198)), reading 20 Variable "
               "Compensation Award as DP-198 publishes it. "
               "The candidate's DP-012 upstream is dropped: no component measure is tied to fee revenue at WP1 (revenue by "
               "advisor book is DP-499). FOP+CORP withdrew DP-597 in favor of this product. Channel referral incentives are "
               "flagged on 03 Channel Referral (DP-393). "
               "Tailoring lever: allowed incentive measures (03 SME 5). Reference default: client outcomes and firm results only; "
               "no product-specific time-limited components. "
               "Tailoring lever: referral incentives (03 SME 6). Reference default: a reviewed plan component, rollover-neutral. "
               "Drafting assumptions: Conflict Review Outcome values Mitigation Required and Prohibited; Statement Status Issued; "
               "Plan Approval Status Approved; Participant Eligibility Status Eligible; the 12-month review currency, 30-day payroll "
               "lag, 0.5% tie-out tolerance and minimum cell of 10. "
               "Decisions: CW-062, CW-064, CW-168, CW-226, CW-907. "
               "WP1 new (CW-226): successor of DP-032, DP-033 and DP-082 (07, retired); lists DP-198 upstream."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-391": dict(
        definition=("The firm's supervisory structure under FINRA Rule 3110(a) and (b): the branch, OSJ and non-branch office "
                    "designations, the supervisory hierarchy, each principal's designations and the representatives assigned to "
                    "each supervisor, matched to the Form BR branch registrations and to the supervisors' own principal "
                    "registrations. Supervision sees representatives without a qualified supervisor, branches without a "
                    "registration and principals over their span. It owns no certified metric family."),
        business_questions=[
            "Which registered representatives have no supervisor assigned today, or a supervisor without a principal registration?",
            "Which branch offices and OSJs have no current Form BR registration, or are registered as a different branch type?",
            "Which OSJs have no designated principal, and which principal designations lack the qualifying registration?",
            "How many representatives does each principal supervise, and which principals are over the span the firm allows?",
            "Where are the residential supervisory locations and the heightened-supervision assignments?",
        ],
        grain=("Supervised person x assigned supervisor x assignment type x assignment effective period, with the branch office "
               "designation, supervisory hierarchy link and principal designation as conformed tables and the 08 branch and "
               "individual registrations matched; SCD type 2"),
        dimensions=["Supervising office and branch type (DP-009)", "Supervisory unit and parent unit", "Principal designation type",
                    "Supervisory assignment type", "Supervised person and assigned supervisor (DP-009, DP-192)",
                    "Registration category and jurisdiction", "Office state (DP-013)", "Effective date"],
        measures=[
            ("Active Branch Designations", "Count of Firm Branch Office rows with Branch Status = Active and the designation in force at the as-of date (Branch Designation Effective From on or before it, Branch Designation Effective To empty or after it), by Branch Type.",
             _u("03", "Firm Branch Office", "Office", "Branch Type", "Branch Status", "Branch Designation Effective From", "Branch Designation Effective To")),
            ("Branches Without Form BR Registration", "Count of active designations with Branch Type in Office of Supervisory Jurisdiction or Branch Office whose Office has no 08 Branch Registration (Registered Office) with a Branch CRD Number and Branch Closing Date empty.",
             _u("08", "Branch Registration", "Registered Office", "Branch CRD Number", "Branch Closing Date") + ["Active Branch Designations"]),
            ("Registered Branch Type Mismatches", "Count of active designations whose 08 Branch Registration Registered Branch Type differs from the 03 Branch Type in force.",
             _u("08", "Branch Registration", "Registered Office", "Registered Branch Type") + _u("03", "Firm Branch Office", "Branch Type")),
            ("Closed Registrations Still Designated", "Count of Firm Branch Office rows with Branch Status = Active whose Branch Registration has Branch Closing Date before the as-of date, or whose latest Form BR Filing Type is a closing filing.",
             _u("08", "Branch Registration", "Branch Closing Date", "Form BR Filing Type", "Form BR Filed Date") + _u("03", "Firm Branch Office", "Branch Status")),
            ("Representatives Without Qualified Supervisor", "Count of persons with an 08 Individual Registration of Registration Status = Approved and a representative Registration Category with no Supervisory Assignment effective at the as-of date, or whose Assigned Supervisor holds no Individual Registration with a principal Registration Category and Registration Status = Approved.",
             _u("08", "Individual Registration", "Registered Person", "Registration Category", "Registration Status")
             + _u("03", "Supervisory Assignment", "Supervised Person", "Assigned Supervisor", "Assignment Effective From", "Assignment Effective To")),
            ("Supervisors Without Principal Registration", "Count of distinct Assigned Supervisor values of Supervisory Assignments in force with no Individual Registration of a principal Registration Category with Registration Status = Approved.",
             _u("03", "Supervisory Assignment", "Assigned Supervisor") + _u("08", "Individual Registration", "Registered Person", "Registration Category", "Registration Status")),
            ("Principal Span of Supervision", "Count of distinct Supervised Person per Assigned Supervisor over Supervisory Assignments in force with Supervisory Assignment Type = Primary, with the median and maximum across principals.",
             _u("03", "Supervisory Assignment", "Supervised Person", "Assigned Supervisor", "Supervisory Assignment Type")),
            ("Principals Over Span Limit", "Count of Assigned Supervisors whose Principal Span of Supervision exceeds 25 supervised persons, by Supervising Office.",
             _u("03", "Supervisory Assignment", "Supervising Office") + ["Principal Span of Supervision"]),
            ("OSJs Without Designated Principal", "Count of active designations with Branch Type = Office of Supervisory Jurisdiction with no Principal Designation in force whose Designation Office is the Office and Principal Designation Type = OSJ Principal.",
             _u("03", "Principal Designation", "Designation Office", "Principal Designation Type", "Designation Effective From", "Designation Effective To")
             + _u("03", "Firm Branch Office", "Office", "Branch Type")),
            ("Designations Without Qualifying Registration", "Count of Principal Designation rows in force whose Qualifying Registration is empty or resolves to an Individual Registration with Registration Status not Approved, by Principal Designation Type.",
             _u("03", "Principal Designation", "Designated Principal", "Qualifying Registration", "Principal Designation Type")
             + _u("08", "Individual Registration", "License ID", "Registration Status")),
            ("Supervisory Units Without Parent", "Count of Child Supervisory Unit values in force with no Supervisory Hierarchy Link to a Parent Supervisory Unit, other than the home office root unit.",
             _u("03", "Supervisory Hierarchy Link", "Child Supervisory Unit", "Parent Supervisory Unit", "Supervisory Link Type", "Link Effective From", "Link Effective To")),
            ("Residential Supervisory Locations", "Count of active designations with Residential Supervisory Location Indicator = Y (FINRA Rule 3110.19), and of offices with Supervises Non-Branch Locations Indicator = Y, by office state.",
             _u("03", "Firm Branch Office", "Residential Supervisory Location Indicator", "Supervises Non-Branch Locations Indicator")
             + _u("09", "Office Location", "Office ID", "Office Country / Subdivision")),
            ("Heightened Supervision Assignments", "Count of Supervisory Assignments in force with Heightened Supervision Plan Reference populated, by Supervising Office.",
             _u("03", "Supervisory Assignment", "Heightened Supervision Plan Reference", "Supervising Office")),
        ],
        inputs=[
            ("03", "Firm Branch Office", ["Office", "Branch Type", "Supervises Non-Branch Locations Indicator",
                                          "Residential Supervisory Location Indicator", "Branch Registration Reference", "Branch Status",
                                          "Branch Designation Effective From", "Branch Designation Effective To"]),
            ("03", "Supervisory Hierarchy Link", ["Child Supervisory Unit", "Parent Supervisory Unit", "Supervisory Link Type",
                                                  "Link Effective From", "Link Effective To"]),
            ("03", "Principal Designation", ["Designated Principal", "Principal Designation Type", "Designation Office", "Supervised Functions",
                                             "Qualifying Registration", "Designation Effective From", "Designation Effective To"]),
            ("03", "Supervisory Assignment", ["Supervised Person", "Assigned Supervisor", "Supervisory Assignment Type", "Supervising Office",
                                              "Heightened Supervision Plan Reference", "Assignment Effective From", "Assignment Effective To"]),
            ("08", "Branch Registration", ["Registered Office", "Branch CRD Number", "Registered Branch Type", "Form BR Filing Type",
                                           "Form BR Filed Date", "Branch Closing Date"]),
            ("08", "Individual Registration", ["License ID", "Registered Person", "Registration Category", "Registration Jurisdiction",
                                               "Registration Status", "Registration Effective Date", "Registration Termination Date"]),
            ("09", "Office Location", ["Office ID", "Office Country / Subdivision"]),
        ],
        upstream=["DP-009", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for designations, assignments and registrations as of the prior business day",
        history="SCD type 2 on designations, hierarchy links, principal designations and assignments; kept six years after the person or office leaves (FINRA Rule 3110 and Rule 4511 records; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Office, Designation Office, Supervising Office and Registered Office resolves to a DP-013 Office ID, every Supervised Person, Assigned Supervisor and Designated Principal to a DP-192 employee and a DP-009 advisor or principal, and every Qualifying Registration to an 08 License ID.",
            "Firm Branch Office designations do not overlap for the same Office, Supervisory Assignments of type Primary do not overlap for the same Supervised Person, and every effective period ends on or after it starts.",
            "Every active OSJ and branch office designation has exactly one Branch Registration with Branch Closing Date empty, and its Branch Registration Reference equals that registration's Branch CRD Number.",
            "Branch Type, Branch Status and Branch Designation Effective From are populated on every designation, Principal Designation Type and Qualifying Registration on every principal designation, and Assigned Supervisor and Supervisory Assignment Type on every assignment.",
            "Person-level rows are published to supervision and registration roles only; Individual CRD Number is not read, and the residential supervisory location is shown at office state, never as an address.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (employees). "
               "Boundaries: structure is 03 and registrations are 08 (CW-061, CW-072); registrations are read directly from 08 as "
               "DP-009 does, and DP-039 (registrations and CE) is not upstream; written supervisory procedures are 38 Policies "
               "read by DP-402. DP-398 and DP-402 read this product for the supervisor and office of each review and inspection. "
               "Tailoring lever: remote-only firm (03 SME 8). Reference default: a branch network with OSJs; a remote-only firm "
               "keeps the home-office OSJ and residential supervisory locations only. "
               "Tailoring lever: span of supervision limit. Reference default: 25 supervised persons per principal. "
               "Taxonomy gap: 03 Supervisory Assignment and Principal Designation carry no reference to the 03 Supervisory "
               "Hierarchy Link unit; units are matched through the office. "
               "Drafting assumptions: Branch Type values Office of Supervisory Jurisdiction and Branch Office; Principal Designation "
               "Type OSJ Principal; Supervisory Assignment Type Primary; Registration Status Approved; the principal Registration "
               "Category values (for example General Securities Principal); the span limit of 25. "
               "Decisions: CW-061, CW-072, CW-903. "
               "WP1 new (CW-220): upstream of DP-398 and DP-402 (Rule 3110 supervisory structure); all six candidate objects read, "
               "with 09 Office Location added for the office state."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-392": dict(
        definition=("The acquisition funnel from marketing lead through qualification, application start, submission, account "
                    "opening and funding, with abandonment by journey step, time between milestones, not-in-good-order openings, "
                    "promotions and client referrals, and conversion by campaign, lead source, channel and offering. Marketing "
                    "and digital decide spend, journey fixes and lead routing to digital or human advice. The funnel ends at "
                    "account opening and funding; DP-333 takes the client from the advice engagement to enrollment. Net new "
                    "assets by campaign are read from DP-008. It owns no certified metric family."),
        business_questions=[
            "How many leads did each campaign and lead source bring this quarter, and how many reached application, account opening and funding?",
            "Where in the application journey do applicants abandon, and how long does each step take from start to open and from open to funded?",
            "How many openings were not in good order, and why?",
            "What net new assets did each campaign bring this quarter (from DP-008), beside its funded accounts?",
            "How do promotions and client referrals convert, which awards are owed but unpaid, and which referrals lack the endorsement disclosure?",
        ],
        grain=("Acquisition milestone (party x milestone type x milestone date, with the account where applicable), with the "
               "marketing lead and its qualification, assignment and conversion, the application journey and the account "
               "opening as companion facts; promotions, enrollments and client referrals as companion tables; immutable events"),
        dimensions=["Campaign (DP-011)", "Lead source and lead type", "Lifecycle stage and lead status", "Journey type and last completed step",
                    "Abandonment reason", "Account type and business line (DP-093)", "Service offering (DP-004)",
                    "Assigned advisor (DP-009)", "Promotion and award type", "Milestone date (DP-013)"],
        measures=[
            ("Leads Captured", "Count of Marketing Lead rows whose first Lead Status Effective Timestamp falls in the period, by Lead Source, Lead Type and Original Campaign.",
             _u("04", "Marketing Lead", "Lead ID", "Lead Source", "Lead Type", "Original Campaign") + _u("04", "Lead Qualification", "Lead Status Effective Timestamp")),
            ("Lead to Application Rate %", "Leads Captured with Lead Conversion Resulting Application Journey populated / Leads Captured, by Original Campaign and Lead Source.",
             _u("04", "Lead Conversion", "Resulting Application Journey", "Conversion Timestamp") + ["Leads Captured"]),
            ("Leads Past Follow-Up SLA", "Count of leads with Lead Status not Disqualified or Converted, Follow-Up SLA Due before the as-of timestamp and First Sales Activity empty, by Assigned Advisor.",
             _u("04", "Lead Qualification", "Lead Status") + _u("04", "Lead Assignment", "Assigned Advisor", "Follow-Up SLA Due", "First Sales Activity")),
            ("Applications Started", "Count of Application Journey rows with Journey Start Timestamp in the period, by Journey Type.",
             _u("04", "Application Journey", "Journey ID", "Journey Start Timestamp", "Journey Type")),
            ("Application Abandonment Rate %", "Application Journeys started in the period with Journey Status = Abandoned / Applications Started, by Last Completed Step and Abandonment Reason.",
             _u("04", "Application Journey", "Journey Status", "Last Completed Step", "Abandonment Reason") + ["Applications Started"]),
            ("Application Submission Rate %", "Application Journeys started in the period with Submission Timestamp populated / Applications Started, by Journey Type.",
             _u("04", "Application Journey", "Submission Timestamp", "Journey Type") + ["Applications Started"]),
            ("Submitted to Opened Rate %", "Submitted journeys whose Resulting Account resolves to a 15 Account with Account Open Date populated / submitted journeys, by Account Type.",
             _u("04", "Application Journey", "Resulting Account", "Submission Timestamp") + _u("15", "Account", "Account ID", "Account Open Date", "Account Type")),
            ("Median Days Start to Open", "Median calendar days from Journey Start Timestamp to the Account Open Date of the Resulting Account, for accounts opened in the period, by Journey Type.",
             _u("04", "Application Journey", "Journey Start Timestamp", "Resulting Account", "Journey Type") + _u("15", "Account", "Account Open Date")),
            ("Opening Not In Good Order %", "Accounts opened in the period whose Account Opening has Opening NIGO Reasons populated or Good Order Date after Application Received Date / accounts opened in the period, by Opening NIGO Reasons; the opening record is DP-093's.",
             _u("15", "Account Opening", "Opening NIGO Reasons", "Good Order Date", "Application Received Date", "Account Approval Date")
             + _u("15", "Account", "Account Open Date")),
            ("Opened to Funded Rate %", "Accounts opened in the period with an Acquisition Milestone of Milestone Type = Account Funded (Milestone Account = the account) within 30 calendar days of Account Open Date, or with Account Opening Initial Funding Transaction populated / accounts opened in the period.",
             _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account")
             + _u("15", "Account Opening", "Initial Funding Transaction") + _u("15", "Account", "Account Open Date")),
            ("Median Days Open to Funded", "Median calendar days from Account Open Date to the Milestone Date of the Account Funded milestone of the same account, for accounts funded in the period.",
             _u("04", "Acquisition Milestone", "Milestone Type", "Milestone Date", "Milestone Account") + _u("15", "Account", "Account Open Date")),
            ("Funded Accounts by Original Campaign", "Count of distinct Milestone Account values with Milestone Type = Account Funded in the period whose party's Marketing Lead has Original Campaign = the campaign (first touch), by Campaign Business Line; the attributed view under the 04 attribution model is DP-410's.",
             _u("04", "Acquisition Milestone", "Milestone Type", "Milestone Account", "Milestone Party")
             + _u("04", "Marketing Lead", "Lead Party", "Original Campaign")),
            ("Funded Households Acquired", "Count of distinct 02 Client Households (Household of an active Household Membership of the Milestone Party, DP-240 Party Household) whose first Acquisition Milestone of Milestone Type = Account Funded falls in the period, by Original Campaign and Lead Source of the party's Marketing Lead; each household counted once, beside Funded Accounts by Original Campaign.",
             _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date")
             + _u("02", "Household Membership", "Household", "Household Member", "Membership Status")
             + _u("04", "Marketing Lead", "Lead Party", "Original Campaign", "Lead Source")),
            ("Applications With Open Onboarding Case", "Count of submitted Application Journeys whose Resulting Onboarding Case resolves to a 02 Onboarding Case with Case Status not Closed more than 5 business days after Case Opened Date, by Case Type (KYC or CIP pending).",
             _u("04", "Application Journey", "Resulting Onboarding Case", "Submission Timestamp")
             + _u("02", "Onboarding Case", "Onboarding Case ID", "Case Type", "Case Status", "Case Opened Date")),
            ("Net New Assets by Campaign (from DP-008)", "Measure Amount of the DP-008 Measure Value with Measure MSR-NNA, Dimension Type Campaign and Dimension Key = the Campaign ID, summed over the months of the period from the Final or Restated Snapshot: the 04 attribution weights applied once in DP-008 and never re-weighted here (the same value DP-492 publishes).",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Net New Assets") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Promotion Qualification Rate %", "Promotion Enrollment rows with Enrollment Status in Qualified or Awarded / Promotion Enrollment rows, by Enrolled Promotion and Promotion Award Type.",
             _u("04", "Promotion Enrollment", "Enrolled Promotion", "Enrolled Party", "Enrollment Status") + _u("04", "Promotion Offer", "Promotion ID", "Promotion Award Type")),
            ("Promotion Awards Owed Unpaid", "Count and sum of Award Value of Promotion Enrollments with Enrollment Status = Qualified more than 60 days ago with no settled 50 Money Movement whose Source Promotion Enrollment is the enrollment and no Award Fee Waiver (DP-302 for the payment, DP-305 for the waiver).",
             _u("04", "Promotion Enrollment", "Enrollment Status", "Award Fee Waiver", "Enrolled Account") + _u("04", "Promotion Offer", "Award Value")
             + _u("50", "Money Movement", "Money Movement ID", "Source Promotion Enrollment", "Money Movement Status", "Movement Amount")),
            ("Promotions Without Compliance Review", "Count of Promotion Offer rows with Promotion Status = Active (Offer Start Date on or before the as-of date, Offer End Date empty or after it) and Promotion Compliance Review empty; the review itself is 08's (DP-036).",
             _u("04", "Promotion Offer", "Promotion Status", "Offer Start Date", "Offer End Date", "Promotion Compliance Review", "Promotion Campaign")),
            ("Client Referral Conversion Rate %", "Client Referral rows with Referral Status = Funded / Client Referral rows created in the period, with the count of referrals whose Endorsement Disclosure Delivered Indicator is not Y (Marketing Rule endorsement disclosure).",
             _u("04", "Client Referral", "Referral ID", "Referrer Party", "Referee Party", "Referral Status", "Endorsement Disclosure Delivered Indicator")),
            ("Form 1099-MISC Reportable Awards", "Count and Award Value of Promotion Enrollments and Client Referral rewards (Referral Reward Enrollment) awarded in the tax year with Form 1099-MISC Reportable Indicator = Y; the form itself is 13's.",
             _u("04", "Promotion Enrollment", "Form 1099-MISC Reportable Indicator", "Enrollment Status") + _u("04", "Promotion Offer", "Award Value")
             + _u("04", "Client Referral", "Referral Reward Enrollment")),
        ],
        inputs=[
            ("04", "Marketing Lead", ["Lead ID", "Lead Type", "Lead Party", "Lead Source", "Original Campaign"]),
            ("04", "Lead Qualification", ["Lead Status", "Lead Status Effective Timestamp", "Lifecycle Stage", "Disqualification Reason"]),
            ("04", "Lead Assignment", ["Assigned Advisor", "Follow-Up SLA Due", "First Sales Activity"]),
            ("04", "Lead Conversion", ["Conversion Outcome", "Converted Party", "Resulting Application Journey", "Conversion Timestamp"]),
            ("04", "Application Journey", ["Journey ID", "Journey Applicant Party", "Journey Type", "Journey Start Timestamp",
                                           "Last Completed Step", "Journey Status", "Abandonment Reason", "Submission Timestamp",
                                           "Resulting Onboarding Case", "Resulting Account"]),
            ("04", "Acquisition Milestone", ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"]),
            ("02", "Onboarding Case", ["Onboarding Case ID", "Case Party", "Case Type", "Case Status", "Case Opened Date"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status"]),
            ("15", "Account Opening", ["Application Received Date", "Good Order Date", "Opening NIGO Reasons", "Initial Funding Transaction",
                                       "Account Approval Date"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Open Date", "Account Business Line"]),
            ("04", "Promotion Offer", ["Promotion ID", "Promotion Name", "Promotion Award Type", "Offer Start Date", "Offer End Date",
                                       "Award Value", "Promotion Campaign", "Promotion Compliance Review", "Promotion Status"]),
            ("04", "Promotion Enrollment", ["Enrolled Promotion", "Enrolled Party", "Enrolled Account", "Enrollment Status",
                                            "Award Fee Waiver", "Form 1099-MISC Reportable Indicator"]),
            ("04", "Client Referral", ["Referral ID", "Referrer Party", "Referee Party", "Referral Status",
                                       "Endorsement Disclosure Delivered Indicator", "Referral Reward Enrollment"]),
            ("50", "Money Movement", ["Money Movement ID", "Source Promotion Enrollment", "Money Movement Status", "Movement Amount"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Net New Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
        ],
        upstream=["DP-011", "DP-240", "DP-093", "DP-004", "DP-009", "DP-302", "DP-305", "DP-008", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for leads, journeys, milestones and promotions; campaign net new assets by business day 5 after month-end with the DP-008 Final snapshot",
        history="Leads, journeys, milestones and enrollments kept as immutable events with lead status as SCD type 2; kept seven years; captured lead contact data purged with the lead under the 04 retention rule",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Reverse ETL to CRM"],
        dq_rules=[
            "Every Lead Party, Journey Applicant Party, Milestone Party, Enrolled Party, Referrer Party and Referee Party resolves to a DP-240 party once past the identity threshold, every Resulting Account, Milestone Account and Enrolled Account to a DP-093 Account ID, every Original Campaign and Promotion Campaign to a DP-011 Campaign ID, and every Assigned Advisor to a DP-009 advisor.",
            "Submission Timestamp is on or after Journey Start Timestamp, Offer End Date is empty or on or after Offer Start Date, and each account has at most one Acquisition Milestone of each Milestone Type.",
            "Accounts opened in the period from submitted journeys tie to DP-093 accounts opened through the digital and assisted application channels within 1%, and Net New Assets by Campaign (from DP-008) equals the DP-008 Measure Amount for the same Campaign ID and Snapshot ID with no difference.",
            "Lead Source and Original Campaign are populated on every lead, Journey Type, Journey Status and Journey Start Timestamp on every journey, and Milestone Type and Milestone Date on every milestone.",
            "Captured Name and Captured Email of pre-threshold leads are not read; party keys are published to marketing operations only, and campaign and channel views are aggregates of at least 10 parties.",
            "The prior day is complete by 7am ET on T+1, and campaign net new assets are published only after the DP-008 snapshot of the month is Final.",
        ],
        notes=("Certified numbers: reads Net New Assets by campaign from DP-008, where the 04 attribution weights are applied "
               "once (CW-085, CW-227); computes counts, rates and durations only; owns none. "
               "PII tier: identity (lead and applicant keys; captured contact data not read, CW-083). "
               "Boundaries: the funnel ends at account opening and funding (CW-083, CW-085); DP-333 (CLA-A) starts at the advice "
               "engagement, so a prospect who opens an account and later engages advice appears in both at different stages and "
               "is never counted twice as a conversion. DP-492 (DIS) publishes NNA by campaign and acquisition cohort from DP-008 "
               "directly and has no edge with this product; the campaign NNA here is read from DP-008, which carries the "
               "Attributed Campaign split (amended CW-227). DP-498 reads Funded Households Acquired. Campaign spend and the attributed view under each 04 attribution model are DP-410. "
               "Awards are paid as 50 money movements (DP-302) or 47 fee waivers (DP-305); tax forms are 13 (backlog DP-417); the "
               "promotion review is 08. Absorbs backlog DP-396 (promotions and referrals), DP-327 (account opening good order) "
               "and DP-462 (account funding journey); supersedes DP-027. The 02 Onboarding Case is read directly: DP-240 does not "
               "publish it. "
               "Acceptance question 2: shows the funnel beside campaign net new assets (Leads Captured, Funded Accounts by Original "
               "Campaign, Opened to Funded Rate %); DP-492 answers from DP-008, not an edge. "
               "Acceptance question 11: feeds DP-498 with Funded Households Acquired and Funded Accounts by Original Campaign by "
               "Lead Source, for acquisition cost and lifetime value by acquisition channel. "
               "Tailoring lever: identity threshold (04 SME 1). Reference default: a lead becomes a 02 party at a name plus a "
               "verified contact point or at application start. "
               "Tailoring lever: attribution model (04 SME 7). Reference default: position-based over milestones, applied in "
               "DP-008; this product shows first touch beside it. "
               "Tailoring lever: promotions and referral rewards (04 SME 4). Reference default: both in scope; a firm running "
               "neither drops the promotion and referral measures. "
               "Taxonomy gap: 04 Promotion Enrollment has no qualification or award date; the 60-day unpaid test uses the date the enrollment status first read Qualified at load. "
               "Taxonomy gap: 04 Marketing Lead has no created timestamp; the lead period is taken from Lead Status Effective "
               "Timestamp of the first status. "
               "Drafting assumptions: Journey Status Abandoned; Lead Status Disqualified and Converted; Milestone Type Account "
               "Funded; Enrollment Status Qualified and Awarded; Referral Status Funded; the 30- and 60-day windows; the minimum "
               "cell of 10; Dimension Type Campaign on 06 Measure Value. "
               "Decisions: CW-083, CW-085, CW-092, CW-143, CW-227 (amended at the C-2 fix pass). "
               "WP1 new (CW-227): supersedes DP-027; also reads 04 Promotion Offer, Client Referral and Promotion Enrollment "
               "(moved from backlog DP-396 and DP-417)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-393": dict(
        definition=("Every internal hand-off of a client between channels (digital to human advice, service to advisor, trust "
                    "referrals) from the 03 channel referral through acceptance to the resulting advice engagement and program "
                    "enrollment, and every workplace participant hand-off to the retail business from its 16 trigger to its "
                    "outcome and rollover amount. Channel leaders see conversion and leakage at each hand-off. It owns no "
                    "certified metric family."),
        business_questions=[
            "How many referrals did each channel send to each other channel this quarter, and how many were accepted, engaged and enrolled?",
            "Where do referrals leak, and how long does a referral take to become an advice engagement?",
            "How many separated or eligible participants were handed off to the retail business, with contact consent, and how many reached an advice engagement?",
            "What rollover amount did the participant hand-offs bring (from DP-430), beside the net inter-channel transfers (from DP-008)?",
            "Which referrals are open past 30 days, and how many trust referrals resulted in a trust?",
        ],
        grain=("Channel referral (RFRL-) with its status history, and participant retail hand-off (membership x trigger event, "
               "PRTHO-) as a companion fact, each joined to the resulting advice engagement and program enrollment; immutable "
               "events with status history"),
        dimensions=["Referral source channel and target channel", "Referral reason and status", "Referring employee (DP-192)",
                    "Target advisor and coverage team (DP-009)", "Hand-off trigger and outcome", "Plan (DP-094)",
                    "Advice engagement type and delivery channel (DP-303)", "Service offering (DP-004)", "Referral date (DP-013)"],
        measures=[
            ("Referrals Made", "Count of Channel Referral rows with Referral Date in the period, by Referral Source Channel, Referral Target Channel and Referral Reason.",
             _u("03", "Channel Referral", "Referral ID", "Referral Date", "Referral Source Channel", "Referral Target Channel", "Referral Reason")),
            ("Referral Acceptance Rate %", "Referrals Made whose Referral Status reached Accepted, Engaged or Enrolled (Referral Status History) / Referrals Made, by Referral Target Channel.",
             _u("03", "Referral Status History", "History Referral Status", "Status Change Timestamp") + _u("03", "Channel Referral", "Referral Status")
             + ["Referrals Made"]),
            ("Referral to Engagement Rate %", "Referrals Made with Resulting Advice Engagement populated / Referrals Made, by Referral Source Channel and Referral Target Channel.",
             _u("03", "Channel Referral", "Resulting Advice Engagement") + ["Referrals Made"]),
            ("Referral to Enrollment Rate %", "Referrals Made with Resulting Program Enrollment resolving to a 15 Program Enrollment with Enrollment Status = Active / Referrals Made, by Enrolled Service Offering.",
             _u("03", "Channel Referral", "Resulting Program Enrollment") + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrollment Status", "Enrolled Service Offering")
             + ["Referrals Made"]),
            ("Referral Leakage %", "Referrals Made whose final Referral Status is Declined, Expired or No Contact / Referrals Made, by Referral Target Channel and Target Coverage Team.",
             _u("03", "Channel Referral", "Referral Status", "Target Coverage Team") + ["Referrals Made"]),
            ("Median Days Referral to Engagement", "Median calendar days from Referral Date to the Engagement Start Date of the Resulting Advice Engagement, by Referral Target Channel.",
             _u("03", "Channel Referral", "Referral Date", "Resulting Advice Engagement") + _u("45", "Advice Engagement", "Advice Engagement ID", "Engagement Start Date")),
            ("Referrals Open Past 30 Days", "Count of Channel Referral rows whose Referral Status is not terminal and whose last Status Change Timestamp is more than 30 days before the as-of date, by Target Advisor.",
             _u("03", "Channel Referral", "Referral Status", "Target Advisor") + _u("03", "Referral Status History", "Status Change Timestamp")),
            ("Participant Hand-Offs Triggered", "Count of Participant Retail Hand-Off rows with Trigger Date in the period, by Hand-Off Trigger and plan (Hand-Off Membership, DP-094); the hand-off facts are DP-430's.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off ID", "Hand-Off Membership", "Hand-Off Trigger", "Trigger Date")),
            ("Hand-Offs With Contact Consent %", "Participant Hand-Offs Triggered with Contact Consent populated / Participant Hand-Offs Triggered.",
             _u("16", "Participant Retail Hand-Off", "Contact Consent") + ["Participant Hand-Offs Triggered"]),
            ("Hand-Off to Advice Engagement Rate %", "Participant Hand-Offs Triggered with Referral Advice Engagement populated / Participant Hand-Offs Triggered, by Hand-Off Trigger and Referred Advisor's channel.",
             _u("16", "Participant Retail Hand-Off", "Referral Advice Engagement", "Referred Advisor") + ["Participant Hand-Offs Triggered"]),
            ("Hand-Off Outcome Mix", "Count of hand-offs with Outcome Date in the period by Hand-Off Outcome (rolled over to a firm IRA, stayed in plan, left the firm, no response).",
             _u("16", "Participant Retail Hand-Off", "Hand-Off Outcome", "Outcome Date")),
            ("Hand-Off Rollover Amount (from DP-430)", "Sum of Hand-Off Rollover Amount of hand-offs with Hand-Off Outcome = Rolled Over to Firm IRA and Outcome Date in the period, as DP-430 publishes it.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off Rollover Amount", "Hand-Off Outcome", "Outcome Date")),
            ("Net Inter-Channel Transfers by Target Channel (from DP-008)", "Measure Amount of the DP-008 Measure Value of Net Inter-Channel Transfers (Client Asset Measures), Dimension Type Channel and Dimension Key = the distribution channel of the Referral Target Channel, over the period, from the Final or Restated Snapshot; shown beside the hand-off counts, never recomputed.",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Net Inter-Channel Transfers") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Referral Incentive Eligible Referrals", "Count of Referrals Made with Referral Incentive Eligible Indicator = Y, by Referring Employee's channel; the incentive itself is a DP-390 plan component.",
             _u("03", "Channel Referral", "Referral Incentive Eligible Indicator", "Referring Employee") + ["Referrals Made"]),
            ("Trust Referrals Resulting in Trust", "Count of Referrals Made with Referral Target Channel = Trust and Resulting Trust populated, and that count / trust referrals.",
             _u("03", "Channel Referral", "Referral Target Channel", "Resulting Trust") + ["Referrals Made"]),
        ],
        inputs=[
            ("03", "Channel Referral", ["Referral ID", "Referral Date", "Referred Party", "Referral Source Channel", "Referring Employee",
                                        "Referral Target Channel", "Target Advisor", "Target Coverage Team", "Referral Reason",
                                        "Referral Status", "Source Service Request", "Resulting Advice Engagement",
                                        "Resulting Program Enrollment", "Resulting Marketing Lead", "Resulting Trust",
                                        "Referral Incentive Eligible Indicator"]),
            ("03", "Referral Status History", ["History Referral Status", "Status Change Timestamp"]),
            ("16", "Participant Retail Hand-Off", ["Hand-Off ID", "Hand-Off Membership", "Hand-Off Trigger", "Trigger Date",
                                                   "Contact Consent", "Referral Advice Engagement", "Referred Advisor",
                                                   "Hand-Off Outcome", "Outcome Date", "Hand-Off Rollover Amount"]),
            ("45", "Advice Engagement", ["Advice Engagement ID", "Engagement Type", "Engagement Delivery Channel", "Engagement Status",
                                         "Engagement Start Date"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Net Inter-Channel Transfers"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
        ],
        upstream=["DP-009", "DP-240", "DP-303", "DP-093", "DP-094", "DP-430", "DP-004", "DP-008", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for referrals, status changes and hand-offs; inter-channel transfers by business day 5 after month-end",
        history="Referrals and hand-offs kept as immutable events with status history; kept seven years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Referred Party resolves to a DP-240 party, every Target Advisor and Referred Advisor to a DP-009 advisor, every Referring Employee to a DP-192 employee, every Resulting Advice Engagement and Referral Advice Engagement to a DP-303 engagement, every Resulting Program Enrollment to a DP-093 enrollment and every Hand-Off Membership to a DP-094 plan membership.",
            "Status Change Timestamp values of a referral are strictly increasing and the first is on or after Referral Date; Outcome Date of a hand-off is on or after its Trigger Date.",
            "Hand-Off Rollover Amount (from DP-430) equals the DP-430 published Hand-Off Rollover Amount for the same period with no difference, and Net Inter-Channel Transfers by Target Channel equals the DP-008 Measure Amount for the same Dimension Key and Snapshot ID.",
            "Referral Source Channel, Referral Target Channel, Referral Status and Referral Date are populated on every referral, and Hand-Off Trigger and Trigger Date on every hand-off.",
            "Party and participant keys are published to channel leaders and advisor managers only; other views are aggregates of at least 10 referrals or hand-offs, and Hardship Reason and other 16 distribution reasons are not read.",
            "The prior day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: reads Net Inter-Channel Transfers from DP-008; owns none. Hand-Off Rollover Amount is DP-430's "
               "published hand-off fact, not a certified number. "
               "PII tier: identity (client and participant keys). "
               "Boundaries: channel referrals are 03, client-to-friend referrals 04 (CW-065, CW-092; DP-392); DP-333 (CLA-A) "
               "counts referrals entering the advice funnel and this product covers every hand-off and its leakage. The rollover "
               "capture rate (acceptance question 10) is DP-467's; the PTE 2020-02 evidence of each rollover is DP-335. DP-467 "
               "reads this product, so it is not upstream. "
               "Hand-Off to Advice Engagement Rate % is owned here; DP-467 reads it as defined here (C-3 ruling). "
               "Acceptance question 10: feeds DP-467 with Participant Hand-Offs Triggered, Hand-Off to Advice Engagement Rate % and "
               "Hand-Off Rollover Amount (from DP-430), beside Net Inter-Channel Transfers by Target Channel (from DP-008). "
               "Tailoring lever: channel referral routing (03 SME 6). Reference default: referrals to human advice go to a coverage "
               "team, then an advisor. "
               "Tailoring lever: trust referrals (03 SME 7; trust is a lever). Reference default: trust offered; a firm without "
               "trust drops Trust Referrals Resulting in Trust. "
               "Taxonomy gap: 03 Channel Referral has no closed or expiry date; open age is taken from the last status change. "
               "Drafting assumptions: Referral Status values Accepted, Engaged, Enrolled, Declined, Expired and No Contact; Hand-Off "
               "Outcome value Rolled Over to Firm IRA; Referral Target Channel value Trust; the "
               "30-day window and minimum cell of 10. "
               "Decisions: CW-065, CW-092, CW-143, CW-226, CW-232. "
               "WP1 new (CW-226): Q10 feeder (hand-off); all four candidate objects read, with 15 Program Enrollment added for the "
               "enrollment conversion."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-394": dict(
        definition=("Logged-in and anonymous engagement by digital property, page, feature and journey; digital profile health "
                    "(MFA enrollment, login recency); every experiment with its variants, exposures and the lift on its primary "
                    "metric, computed here; and every nudge with its trigger, recommendation risk class, the 08 determination "
                    "recorded for it and the 45 recommendation a delivery carried. Digital product owners decide which journeys "
                    "and features to change and which variants to ship; supervision sees that no potential-recommendation nudge "
                    "went out without a determination. It owns no certified metric family."),
        business_questions=[
            "How many clients are active on the digital properties, with MFA enrolled, and which features and journeys do they use?",
            "Which experiments are running, how many visitors and clients were exposed to each variant, and what lift did each variant show on its primary metric?",
            "Which experiments were decided before reaching their minimum exposure?",
            "Which nudges went out by type and channel, and how did clients respond?",
            "Did any nudge classed as a potential recommendation go out without its 08 determination, or without the 45 recommendation it should carry?",
        ],
        grain=("Engagement event (visitor or party x event type x event timestamp) under the applied tracking consent, with "
               "sessions, digital profiles, experiment assignments and nudge deliveries as companion facts; experiment and nudge "
               "definitions as dimensions; immutable events"),
        dimensions=["Digital property and page", "Engagement event type and digital feature", "Session source / medium and login method",
                    "Experiment and variant", "Nudge type, version and delivery channel", "Recommendation risk class",
                    "Client and household (DP-240)", "Product or share class on page (DP-004)", "Metric definition (DP-101)",
                    "Event date (DP-013)"],
        measures=[
            ("Active Digital Profiles", "Count of Digital Profile rows with Digital Profile Status = Active at the as-of date, with those whose Last Login Timestamp is within the 30 days before it.",
             _u("04", "Digital Profile", "Digital Profile ID", "Digital Profile Party", "Digital Profile Status", "Last Login Timestamp")),
            ("MFA Enrollment Rate %", "Active Digital Profiles with MFA Factors Enrolled populated / Active Digital Profiles, with the share with Biometric Login Enabled Indicator = Y.",
             _u("04", "Digital Profile", "MFA Factors Enrolled", "Biometric Login Enabled Indicator") + ["Active Digital Profiles"]),
            ("Sessions by Source", "Count of Session rows in the period by Session Source / Medium and Session Login Method (logged-in or anonymous), by Digital Property of the session's pages.",
             _u("04", "Session", "Session ID", "Session Source / Medium", "Session Login Method", "Session Visitor")
             + _u("04", "Digital Property", "Property ID", "Property Type")),
            ("Feature Usage", "Count of Engagement Event rows and distinct Event Visitor / Party in the period by Digital Feature Used and Engagement Event Type, over events whose visitor's Applied Tracking Consent permits analytics.",
             _u("04", "Engagement Event", "Event Timestamp", "Engagement Event Type", "Event Visitor / Party", "Digital Feature Used")
             + _u("04", "Web Visitor / Known User", "Visitor ID", "Applied Tracking Consent")),
            ("Journey Events by Page Type", "Count of Engagement Event rows with Event Application Journey populated by Page Type of the page viewed and Page Product / Share Class, in the period.",
             _u("04", "Engagement Event", "Event Application Journey", "Event Session") + _u("04", "Web Page", "Page URL", "Page Type", "Page Product / Share Class")),
            ("Experiments Running", "Count of Experiment rows with Experiment Status = Running at the as-of date.",
             _u("04", "Experiment", "Experiment ID", "Experiment Status")),
            ("Experiment Exposure by Variant", "Count of distinct Assigned Visitor / Party by Assigned Experiment and Assigned Variant with First Exposure Timestamp populated in the period.",
             _u("04", "Experiment Assignment", "Assigned Experiment", "Assigned Visitor / Party", "Assigned Variant", "First Exposure Timestamp")),
            ("Variant Lift on Primary Metric %", "For each experiment, (share of exposed visitors in the variant with an Engagement Event matching the Primary Metric's Metric Formula after First Exposure Timestamp - the same share in the control variant) / the control share; computed here (CW-091), with the Metric Direction of the 21 Metric Definition deciding which way is better.",
             _u("04", "Experiment", "Primary Metric", "Experiment Variants") + _u("21", "Metric Definition", "Metric ID", "Metric Formula", "Metric Direction")
             + _u("04", "Engagement Event", "Exposed Experiment", "Engagement Event Type") + ["Experiment Exposure by Variant"]),
            ("Experiments Decided Below Minimum Exposure", "Count of Experiment rows with Experiment Decision populated whose smallest variant's Experiment Exposure by Variant is below 1,000.",
             _u("04", "Experiment", "Experiment Decision") + ["Experiment Exposure by Variant"]),
            ("Nudges Delivered", "Count of Nudge Delivery rows with Delivered Timestamp in the period, by Nudge Type of the Delivered Nudge and Delivery Channel.",
             _u("04", "Nudge Delivery", "Delivered Nudge", "Delivery Party", "Delivered Timestamp", "Delivery Channel")
             + _u("04", "Nudge Definition", "Nudge ID", "Nudge Version", "Nudge Type")),
            ("Nudge Response Rate %", "Nudges Delivered with Nudge Response populated and not Dismissed / Nudges Delivered, by Nudge Type.",
             _u("04", "Nudge Delivery", "Nudge Response") + ["Nudges Delivered"]),
            ("Potential-Recommendation Nudges Without Determination", "Count of Nudges Delivered whose Delivered Nudge has Recommendation Risk Class = Potential Recommendation and whose Nudge Compliance Review is empty or resolves to an 08 Compliance Review whose Compliance Approval Approval Status is not Approved at the Delivered Timestamp; the determination is reported as recorded in 08, never made here (CW-228).",
             _u("04", "Nudge Definition", "Recommendation Risk Class", "Nudge Compliance Review")
             + _u("08", "Compliance Review", "Review ID") + _u("08", "Compliance Approval", "Approval Status", "Approval Decision Date")
             + _u("04", "Nudge Delivery", "Delivered Timestamp") + ["Nudges Delivered"]),
            ("Recommendation Nudges Without Linked Recommendation", "Count of Nudges Delivered whose Delivered Nudge has Recommendation Risk Class = Recommendation and whose Linked Recommendation is empty or does not resolve to a DP-303 Recommendation ID.",
             _u("04", "Nudge Delivery", "Linked Recommendation") + _u("04", "Nudge Definition", "Recommendation Risk Class")
             + _u("45", "Recommendation", "Recommendation ID") + ["Nudges Delivered"]),
            ("Nudges Delivered Without Suppression Check", "Count of Nudges Delivered with Suppression Check Result empty or Not Checked, by Delivery Channel.",
             _u("04", "Nudge Delivery", "Suppression Check Result", "Delivery Channel") + ["Nudges Delivered"]),
        ],
        inputs=[
            ("04", "Experiment", ["Experiment ID", "Experiment Name", "Experiment Status", "Experiment Variants", "Primary Metric",
                                  "Experiment Decision"]),
            ("04", "Experiment Assignment", ["Assigned Experiment", "Assigned Visitor / Party", "Assigned Variant", "First Exposure Timestamp"]),
            ("04", "Digital Profile", ["Digital Profile ID", "Digital Profile Party", "Digital Profile Status", "MFA Factors Enrolled",
                                       "Biometric Login Enabled Indicator", "Last Login Timestamp"]),
            ("04", "Session", ["Session ID", "Session Visitor", "Session Source / Medium", "Session Login Method"]),
            ("04", "Engagement Event", ["Event Timestamp", "Engagement Event Type", "Event Visitor / Party", "Event Session",
                                        "Digital Feature Used", "Event Application Journey", "Exposed Experiment"]),
            ("04", "Web Page", ["Page URL", "Page Type", "Page Product / Share Class"]),
            ("04", "Digital Property", ["Property ID", "Property Name", "Property Type", "Property Status"]),
            ("04", "Web Visitor / Known User", ["Visitor ID", "Matched Party", "Applied Tracking Consent"]),
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Formula", "Metric Direction"]),
            ("04", "Nudge Definition", ["Nudge ID", "Nudge Version", "Nudge Type", "Trigger Rule", "Recommendation Risk Class",
                                        "Nudge Compliance Review"]),
            ("04", "Nudge Delivery", ["Delivered Nudge", "Delivery Party", "Delivered Timestamp", "Delivery Channel",
                                      "Suppression Check Result", "Nudge Response", "Linked Recommendation"]),
            ("08", "Compliance Review", ["Review ID"]),
            ("08", "Compliance Approval", ["Approval Status", "Approval Decision Date"]),
            ("45", "Recommendation", ["Recommendation ID"]),
        ],
        upstream=["DP-011", "DP-101", "DP-240", "DP-004", "DP-303", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET on T+1 for the prior day's events, sessions, assignments and nudge deliveries",
        history="Events kept 25 months at event grain (anonymous events 13 months) and as monthly aggregates thereafter; experiment and nudge definitions SCD type 2; nudge deliveries kept six years (SEC Rule 17a-4 where a nudge is a communication)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Digital Profile Party, Delivery Party and Matched Party resolves to a DP-240 party, every Page Product / Share Class to DP-004, every Primary Metric to a 21 Metric ID in DP-101, and every Linked Recommendation to a DP-303 Recommendation ID.",
            "First Exposure Timestamp of an assignment is on or after the experiment start and each visitor has one Assigned Variant per Assigned Experiment; Nudge Definition versions of the same Nudge ID do not overlap.",
            "Engagement Event counts per day tie to the DP-011 engagement fact for the same day and event type within 0.5%.",
            "Engagement Event Type, Event Timestamp and Event Visitor / Party are populated on every event, Primary Metric on every experiment, and Recommendation Risk Class and Nudge Compliance Review on every nudge version classed Potential Recommendation or Recommendation.",
            "Events of visitors whose Applied Tracking Consent does not permit analytics are excluded at read, visitor keys are pseudonymous, and variant and nudge results are published as aggregates of at least 50 exposed visitors.",
            "The prior day is complete by 6am ET on T+1.",
        ],
        notes=("Plan section 8.3 example (Digital Engagement & Experiments). "
               "Certified numbers: none read or owned. "
               "PII tier: identity (pseudonymous visitor and client keys under the tracking consent). "
               "Boundaries: experiment results are computed here, not stored in 04 (CW-091); the primary metric's definition is "
               "21's (DP-101). A nudge that may be a recommendation is routed to 45 and 08 (CW-091, CW-228): this product reports "
               "the 08 determination as recorded (08 Compliance Review and Compliance Approval, read directly because no "
               "foundational product publishes them; DP-036 is the review product) and the 45 recommendation a delivery carried, "
               "never classifying one; recommendations are evidenced in DP-334 and reviewed in DP-398. Engagement scores and "
               "email engagement stay DP-011's. Absorbs backlog DP-395 (nudges and recommendation determinations); supersedes "
               "DP-052 for clients. "
               "Tailoring lever: nudges as recommendations (04 SME 3). Reference default: each nudge determined by 08; a firm with "
               "educational nudges only drops the determination join. "
               "Tailoring lever: anonymous event retention (04 SME 2). Reference default: 13 months at event grain. "
               "Taxonomy gap: 08 has no attribute recording a nudge's recommendation determination as such; the 08 Compliance Approval Approval Status of the nudge's review is used as the recorded determination. "
               "Taxonomy gap: 04 Experiment has no start date, control variant or minimum sample; the start is taken from the first "
               "First Exposure Timestamp and the first listed variant is the control. "
               "Drafting assumptions: Recommendation Risk Class values Potential Recommendation and Recommendation; Experiment "
               "Status Running; Nudge Response value Dismissed; Approval Status Approved; the minimum exposure of 1,000 and "
               "aggregate floor of 50. "
               "Decisions: CW-057, CW-086, CW-091, CW-228, CW-904. "
               "WP1 new (CW-228): plan section 8.3 example; also reads 04 Nudge Delivery and Nudge Definition (moved from backlog "
               "DP-389 and DP-395)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-398": dict(
        definition=("Every supervisory review a registered principal performs (recommendation, rollover, new account, account "
                    "feature and options approval, transaction, correspondence and best-execution reviews), with its queue, "
                    "aging, outcome, escalation and the best-interest review detail checked, by principal, branch and review "
                    "type. Supervision staffs the queue and evidences timely approvals; DP-334 and DP-335 read the review outcome "
                    "as recorded here for the Reg BI and PTE 2020-02 evidence file. It never re-scores evidence. It owns no "
                    "certified metric family."),
        business_questions=[
            "How many reviews of each type did principals complete this week, with what outcomes, and how many are waiting in the queue?",
            "Which reviews have aged past the review standard, by principal and branch?",
            "What share of the recommendations presented this period received the principal review they required, and which reviews recorded best-interest or PTE 2020-02 evidence exceptions?",
            "Which reviews were performed by a principal who is not the representative's assigned supervisor, or by the representative themself?",
            "How many options approvals and best-execution reviews were completed, by options level and review subject?",
        ],
        grain=("Supervisory review (one principal review of one subject; PRNR-) with its best-interest review detail, joined to "
               "the reviewed recommendation, account, account feature, client order, routing rule or venue; immutable once "
               "completed, open reviews snapshot daily"),
        dimensions=["Supervisory review type", "Review outcome", "Reviewing principal and supervised representative (DP-009, DP-192)",
                    "Supervising office (DP-391)", "Standard of conduct applied", "Recommendation type and source (DP-303)",
                    "Account and registration type (DP-093)", "Account feature type and options approval level",
                    "Routing rule and venue (DP-432)", "Review completed date (DP-013)"],
        measures=[
            ("Supervisory Reviews Completed", "Count of Supervisory Review rows with Review Completed Date in the period, by Supervisory Review Type and Review Outcome.",
             _u("08", "Supervisory Review", "Supervisory Review ID", "Supervisory Review Type", "Review Completed Date", "Review Outcome")),
            ("Open Review Queue", "Count of Supervisory Review rows with Review Completed Date empty at the as-of date, by Supervisory Review Type and Reviewing Principal.",
             _u("08", "Supervisory Review", "Supervisory Review ID", "Review Completed Date", "Supervisory Review Type", "Reviewing Principal")),
            ("Review Aging (Business Days)", "Business days (DP-013 calendar) from the subject timestamp to Review Completed Date, or to the as-of date for open reviews: the Recommendation Presented Timestamp of the Reviewed Recommendation, the Application Received Date of the Reviewed Account's opening, the Feature Approval Date of the Reviewed Account Feature, or the Order Received Timestamp of the Reviewed Client Order; median and 90th percentile by Supervisory Review Type.",
             _u("08", "Supervisory Review", "Reviewed Recommendation", "Reviewed Account", "Reviewed Account Feature", "Reviewed Client Order",
                "Review Completed Date", "Supervisory Review Type")
             + _u("45", "Recommendation", "Recommendation Presented Timestamp") + _u("15", "Account Opening", "Application Received Date")
             + _u("15", "Account Feature", "Feature Approval Date") + _u("48", "Client Order", "Order Received Timestamp")),
            ("Reviews Past Review Standard", "Count of reviews whose Review Aging (Business Days) exceeds the standard of their Supervisory Review Type (recommendation and rollover 2 business days, new account 3, account feature and options approval 1, correspondence 5), open or completed in the period, by Supervising Office.",
             _u("08", "Supervisory Review", "Supervisory Review Type") + _u("03", "Supervisory Assignment", "Supervising Office")
             + ["Review Aging (Business Days)"]),
            ("Recommendation Review Coverage %", "DP-303 Recommendations presented in the period of a Recommendation Type that requires principal review with a Supervisory Review whose Reviewed Recommendation is the recommendation / those recommendations, by Recommendation Source (advisor or digital engine).",
             _u("45", "Recommendation", "Recommendation ID", "Recommendation Type", "Recommendation Source", "Recommendation Presented Timestamp")
             + _u("08", "Supervisory Review", "Reviewed Recommendation")),
            ("Review Exception Rate %", "Supervisory Reviews Completed with Review Outcome in Rejected, Approved with Exception or Escalated / Supervisory Reviews Completed, by Supervisory Review Type and Supervised Representative.",
             _u("08", "Supervisory Review", "Review Outcome", "Supervised Representative") + ["Supervisory Reviews Completed"]),
            ("Reviews Escalated", "Count of Supervisory Reviews Completed with Review Outcome = Escalated, and of reviews raised from a Source Sales Practice Alert (DP-400), by Supervisory Review Type.",
             _u("08", "Supervisory Review", "Review Outcome", "Source Sales Practice Alert", "Supervisory Review Type")),
            ("Reviews Recording Evidence Exceptions", "Count of completed recommendation and rollover reviews whose Best Interest Review Detail records Profile Current Indicator = N, Alternatives Evidence Present Indicator = N, Cost Evidence Present Indicator = N or Evidence Exceptions populated, by Standard of Conduct Applied: the outcome as the principal recorded it, published for DP-334, never re-scored.",
             _u("08", "Best Interest Review Detail", "Profile Current Indicator", "Alternatives Evidence Present Indicator", "Cost Evidence Present Indicator",
                "Evidence Exceptions", "Standard of Conduct Applied", "Investor Profile Version Checked") + _u("08", "Supervisory Review", "Supervisory Review Type")),
            ("Rollover Reviews Recording Missing PTE Documentation", "Count of completed reviews with Supervisory Review Type = Rollover whose Best Interest Review Detail has Rollover Analysis Reviewed not Y or PTE Documentation Present Indicator = N, as recorded, published for DP-335.",
             _u("08", "Best Interest Review Detail", "Rollover Analysis Reviewed", "PTE Documentation Present Indicator")
             + _u("08", "Supervisory Review", "Supervisory Review Type", "Review Completed Date")),
            ("Reviews by Unassigned Principal", "Count of completed reviews whose Reviewing Principal is not the Assigned Supervisor of a Supervisory Assignment of the Supervised Representative in force at Review Completed Date (DP-391), by Supervisory Review Type.",
             _u("08", "Supervisory Review", "Reviewing Principal", "Supervised Representative", "Review Completed Date")
             + _u("03", "Supervisory Assignment", "Supervised Person", "Assigned Supervisor", "Assignment Effective From", "Assignment Effective To")),
            ("Self-Reviews", "Count of Supervisory Review rows whose Reviewing Principal equals the Supervised Representative (prohibited without the Rule 3110(b)(6) exception).",
             _u("08", "Supervisory Review", "Reviewing Principal", "Supervised Representative")),
            ("Options Approvals Reviewed by Level", "Count of completed reviews whose Reviewed Account Feature is an Account Feature with Feature Type = Options, by Options Approval Level, with the share completed before the first options order (FINRA Rule 2360(b)(16)).",
             _u("08", "Supervisory Review", "Reviewed Account Feature") + _u("15", "Account Feature", "Account Feature ID", "Feature Type", "Feature Approved By")
             + _u("15", "Options Approval Detail", "Options Approval Level")),
            ("Best Execution Reviews Completed", "Count of completed reviews with Supervisory Review Type = Best Execution by subject: Reviewed Routing Rule, Reviewed Execution Venue or Reviewed Client Order (DP-432, DP-301), with Review Outcome.",
             _u("08", "Supervisory Review", "Reviewed Routing Rule", "Reviewed Execution Venue", "Reviewed Client Order", "Review Outcome")
             + _u("48", "Client Order", "Client Order ID")),
            ("Reviews per Principal", "Supervisory Reviews Completed per Reviewing Principal in the period, with the Open Review Queue per principal, by Supervising Office.",
             _u("08", "Supervisory Review", "Reviewing Principal") + _u("03", "Supervisory Assignment", "Supervising Office")
             + ["Supervisory Reviews Completed", "Open Review Queue"]),
        ],
        inputs=[
            ("08", "Supervisory Review", ["Supervisory Review ID", "Supervisory Review Type", "Reviewed Recommendation", "Reviewed Account",
                                          "Reviewed Account Feature", "Reviewed Client Order", "Reviewed Correspondence",
                                          "Reviewed Routing Rule", "Reviewed Execution Venue", "Supervised Representative",
                                          "Reviewing Principal", "Applied Supervisory Control", "Source Sales Practice Alert",
                                          "Review Completed Date", "Review Outcome"]),
            ("08", "Best Interest Review Detail", ["Standard of Conduct Applied", "Investor Profile Version Checked", "Profile Current Indicator",
                                                   "Best Interest Evidence Reviewed", "Rollover Analysis Reviewed",
                                                   "Alternatives Evidence Present Indicator", "Cost Evidence Present Indicator",
                                                   "PTE Documentation Present Indicator", "Disclosure Delivery Checked",
                                                   "Evidence Exceptions"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommendation Source", "Recommending Advisor",
                                      "Recommendation Presented Timestamp"]),
            ("15", "Account Opening", ["Application Received Date", "Account Approval Date", "Account Approved By"]),
            ("15", "Account Feature", ["Account Feature ID", "Feature Account", "Feature Type", "Feature Approval Date", "Feature Approved By"]),
            ("15", "Options Approval Detail", ["Options Approval Level"]),
            ("48", "Client Order", ["Client Order ID", "Order Account", "Order Received Timestamp"]),
            ("03", "Supervisory Assignment", ["Supervised Person", "Assigned Supervisor", "Supervising Office", "Assignment Effective From",
                                              "Assignment Effective To"]),
        ],
        upstream=["DP-391", "DP-009", "DP-192", "DP-093", "DP-240", "DP-303", "DP-301", "DP-432", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for reviews completed and opened the prior business day; the open queue intraday every hour on the supervision dashboard",
        history="Completed reviews immutable; open queue snapshots daily; kept six years (FINRA Rule 3110 and Rule 4511; SEC Rule 17a-4; Reg BI records under SEC Rule 17a-4(e)(5))",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Supervised Representative and Reviewing Principal resolves to a DP-192 employee and DP-009 advisor or principal, every Reviewed Recommendation to a DP-303 Recommendation ID, every Reviewed Account to a DP-093 Account ID, every Reviewed Client Order to a DP-301 order and every Reviewed Routing Rule and Reviewed Execution Venue to DP-432.",
            "Review Completed Date is on or after the subject timestamp used in Review Aging (Business Days), and a subject has at most one completed review of each Supervisory Review Type unless a later review records Review Outcome = Re-Review.",
            "Every completed recommendation or rollover review has its Reviewed Recommendation resolving to a DP-303 Recommendation ID of a matching Recommendation Type, and every Best Interest Review Detail row belongs to a Supervisory Review with Supervisory Review Type recommendation or rollover.",
            "Supervisory Review Type, Supervised Representative, Reviewing Principal and Review Outcome are populated on every completed review, and the Best Interest Review Detail with Standard of Conduct Applied is present on every recommendation and rollover review.",
            "Client and representative identity is visible to supervision roles only; Exception Description free text is not read, and other views carry counts by review type, office and principal.",
            "The prior business day is complete by 7am ET on T+1, and a completed review is never edited: a correction is a new review row.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (client and representative keys; restricted to supervision). "
               "Boundaries: the Reg BI evidence file of plan section 8.3 and acceptance question 3 is DP-334 and DP-335 (CLA-A), "
               "which read the review outcome as recorded here; this product owns the workflow and its timeliness and never "
               "re-scores evidence (CW-066, CW-215, CW-224). Recommendations are DP-303's, orders DP-301's, routing rules and "
               "venues DP-432's (the best-execution review subject), account features and options approvals DP-093's; the "
               "supervisor of record is DP-391's. Absorbs backlog DP-401 options approval oversight (its 49 Client Margin Call "
               "read moved to DP-600). DP-334 and DP-335 may list this product upstream; it does not list them. "
               "Acceptance question 3: feeds DP-334 and DP-335 with the principal's review outcome (Review Outcome and Review "
               "Completed Date per review, Reviews Recording Evidence Exceptions, Rollover Reviews Recording Missing PTE "
               "Documentation) as recorded. "
               "Tailoring lever: one or several review objects (08 SME 1). Reference default: one Supervisory Review object for "
               "every review type. "
               "Tailoring lever: digital advice review grain (08 SME 2). Reference default: digital recommendations reviewed by "
               "model and population with exception sampling; Recommendation Review Coverage % then counts sampled reviews. "
               "Tailoring lever: options and margin offered (plan section 15 ruling 3). Reference default: options approvals in "
               "scope; a firm without options drops Options Approvals Reviewed by Level. "
               "Taxonomy gap: 08 Supervisory Review has no queued or assigned timestamp; aging starts at the subject's own "
               "timestamp. "
               "Drafting assumptions: Review Outcome values Rejected, Approved with Exception, Escalated and Re-Review; Supervisory "
               "Review Type values Rollover and Best Execution; Feature Type Options; the review standards in business days. "
               "Decisions: CW-031, CW-066, CW-215, CW-224, CW-908. "
               "WP1 new (CW-224): Q3 feeder (principal review); absorbs backlog DP-401; the two candidate objects are read with "
               "the subjects they review."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-399": dict(
        definition=("Each Form CRS and Reg BI disclosure trigger (account opening, recommendation, material change, new account "
                    "type, fee change) checked by 08 against the delivery evidence held by its owner: 15 account-opening "
                    "disclosures, 13 recipient deliveries, 47 fee disclosures and the 38 Form CRS filing in force. Compliance "
                    "evidences the disclosure obligation, finds late, missing, wrong-version and failed deliveries, and builds "
                    "the populations to re-deliver to. It owns no certified metric family."),
        business_questions=[
            "Which disclosure checks failed this month, by trigger, and which retail investors are missing a Form CRS or Reg BI disclosure they were owed?",
            "Which deliveries were late, sent the wrong Form CRS version, or failed or came back as returned mail?",
            "Which accounts opened this month have no Form CRS delivered on or before opening?",
            "After the latest Form CRS amendment, which existing retail investors still need the updated summary, and was it posted on time?",
            "Which fee changes took effect without the fee disclosure delivered in advance?",
        ],
        grain=("Disclosure delivery check (account or retail investor x disclosure trigger x check date), with the account, "
               "recipient and fee delivery evidence it relied on and the Form CRS filing in force as companion facts; immutable "
               "per check"),
        dimensions=["Disclosure trigger", "Check result", "Disclosure type and version", "Form CRS version and filer capacity",
                    "Delivery method and delivery status", "Fee disclosure type", "Account and registration type (DP-093)",
                    "Retail investor and household (DP-240)", "Trigger date (DP-013)"],
        measures=[
            ("Disclosure Checks Performed", "Count of Disclosure Delivery Check rows with Check Date in the period, by Disclosure Trigger and Disclosures Checked.",
             _u("08", "Disclosure Delivery Check", "Checked Account", "Checked Retail Investor", "Disclosure Trigger", "Disclosures Checked", "Check Date")),
            ("Disclosure Check Failure Rate %", "Disclosure Checks Performed with Check Result in Missing, Late, Wrong Version or Failed Delivery / Disclosure Checks Performed, by Disclosure Trigger and Check Result.",
             _u("08", "Disclosure Delivery Check", "Check Result", "Disclosure Trigger") + ["Disclosure Checks Performed"]),
            ("Missing Disclosures", "Count of checks with Check Result = Missing, by Disclosure Trigger and the evidence column left empty (Account Delivery Evidence, Client-Level Delivery Evidence, Communication Delivery Evidence, Fee Disclosure Evidence).",
             _u("08", "Disclosure Delivery Check", "Check Result", "Disclosure Trigger", "Account Delivery Evidence", "Client-Level Delivery Evidence",
                "Communication Delivery Evidence", "Fee Disclosure Evidence")),
            ("Late Disclosures", "Count of checks whose evidence delivery date (the Disclosure Delivered Date of the 15 Account Disclosure Delivery, or for communication evidence the delivery of the 13 Recipient Delivery Record with Recipient Delivery Status = Delivered and no Returned Mail Date) is after the Trigger Date for account opening and recommendation triggers, or more than 30 days after it for a material change.",
             _u("08", "Disclosure Delivery Check", "Trigger Date", "Disclosure Trigger", "Account Delivery Evidence")
             + _u("15", "Account Disclosure Delivery", "Disclosure Delivered Date") + _u("13", "Recipient Delivery Record", "Recipient Delivery Status", "Returned Mail Date")
             + _u("08", "Disclosure Delivery Check", "Communication Delivery Evidence")),
            ("Wrong Form CRS Version Delivered", "Count of checks whose Form CRS Version Required differs from the Disclosure Version of the 15 Account Disclosure Delivery of Disclosure Type = Form CRS relied on.",
             _u("08", "Disclosure Delivery Check", "Form CRS Version Required") + _u("15", "Account Disclosure Delivery", "Disclosure Type", "Disclosure Version")),
            ("Failed or Returned Deliveries Relied On", "Count of checks whose Communication Delivery Evidence resolves to a 13 Recipient Delivery Record with Recipient Delivery Status = Failed or Returned Mail Date populated (DP-382).",
             _u("08", "Disclosure Delivery Check", "Communication Delivery Evidence")
             + _u("13", "Recipient Delivery Record", "Distribution Job", "Recipient Account", "Recipient Delivery Status", "Returned Mail Date")),
            ("Accounts Opened Without Form CRS", "Count of retail 15 Accounts with Account Open Date in the period with no Account Disclosure Delivery of Disclosure Type = Form CRS and Disclosure Delivered Date on or before Account Open Date, by Account Type.",
             _u("15", "Account", "Account ID", "Account Open Date", "Account Type")
             + _u("15", "Account Disclosure Delivery", "Disclosure Account", "Disclosure Type", "Disclosure Delivered Date")),
            ("Account Opening Check Coverage %", "Disclosure Checks Performed with Disclosure Trigger = Account Opening / retail accounts with Account Open Date in the period.",
             _u("08", "Disclosure Delivery Check", "Disclosure Trigger") + _u("15", "Account", "Account Open Date") + ["Disclosure Checks Performed"]),
            ("Form CRS Posting Lag (Days)", "For each Form CRS filing, calendar days from the Filing Submitted Timestamp of its 38 Firm Regulatory Filing to the Posted to Website Date of the Relationship Summary Version (posting is required by the filing date).",
             _u("38", "Form CRS Filing Detail", "Form CRS Filing", "Relationship Summary Version", "Posted to Website Date")
             + _u("38", "Firm Regulatory Filing", "Firm Filing ID", "Filing Submitted Timestamp")),
            ("Form CRS Amendment Re-Delivery Outstanding", "Count of retail investors owning a retail 15 Account (Account Type retail, Account Open Date before it) open at the Posted to Website Date of an amended Relationship Summary Version (Form CRS Amendment Trigger populated) and no delivery of that version within 60 days, from the checks with Disclosure Trigger = Material Change.",
             _u("38", "Form CRS Filing Detail", "Form CRS Amendment Trigger", "Relationship Summary Version", "Posted to Website Date", "Form CRS Filer Capacity")
             + _u("08", "Disclosure Delivery Check", "Checked Retail Investor", "Disclosure Trigger", "Check Result")
             + _u("15", "Account", "Account ID", "Account Open Date", "Account Type")),
            ("Fee Changes Without Advance Disclosure", "Count of fee disclosure checks whose 47 Fee Disclosure Delivery has Fee Disclosure Delivered Date after Fee Change Effective Date, or no Fee Disclosure Delivery for the Disclosed Fee Schedule before its Fee Change Effective Date (DP-305).",
             _u("08", "Disclosure Delivery Check", "Fee Disclosure Evidence")
             + _u("47", "Fee Disclosure Delivery", "Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type", "Disclosed Fee Schedule",
                  "Fee Disclosure Delivered Date", "Fee Change Effective Date")),
            ("Re-Delivery Population", "Count of distinct Checked Retail Investor values with an open failed check (Check Result not Pass and no later passing check for the same Disclosure Trigger), by Disclosure Trigger: the population compliance sends the disclosure to again.",
             _u("08", "Disclosure Delivery Check", "Checked Retail Investor", "Check Result", "Disclosure Trigger", "Check Date")),
        ],
        inputs=[
            ("08", "Disclosure Delivery Check", ["Checked Account", "Checked Retail Investor", "Disclosure Trigger", "Trigger Date",
                                                 "Disclosures Checked", "Form CRS Version Required", "Account Delivery Evidence",
                                                 "Client-Level Delivery Evidence", "Communication Delivery Evidence",
                                                 "Fee Disclosure Evidence", "Check Date", "Check Result"]),
            ("15", "Account Disclosure Delivery", ["Disclosure Account", "Disclosure Type", "Disclosure Version", "Disclosure Delivery Method",
                                                   "Disclosure Delivered Date", "Related Program Enrollment"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Open Date"]),
            ("13", "Recipient Delivery Record", ["Distribution Job", "Delivered Investor Document", "Recipient Account",
                                                 "Recipient Delivery Method", "Recipient Delivery Status", "Returned Mail Date"]),
            ("38", "Form CRS Filing Detail", ["Form CRS Filing", "Form CRS Filer Capacity", "Relationship Summary Version",
                                              "Form CRS Amendment Trigger", "Posted to Website Date"]),
            ("38", "Firm Regulatory Filing", ["Firm Filing ID", "Filing Submitted Timestamp", "Firm Filing Status"]),
            ("47", "Fee Disclosure Delivery", ["Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type",
                                               "Disclosed Fee Schedule", "Disclosure Document Version", "Fee Disclosure Delivered Date",
                                               "Fee Change Effective Date"]),
        ],
        upstream=["DP-382", "DP-093", "DP-240", "DP-305", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for checks performed and deliveries recorded the prior business day",
        history="Checks immutable; delivery evidence as received from its owners; kept six years (SEC Rule 17a-4(e)(10) for Form CRS delivery records; Reg BI records)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Checked Account and Disclosure Account resolves to a DP-093 Account ID, every Checked Retail Investor to a DP-240 party with the Reg BI retail customer classification, every Communication Delivery Evidence to a DP-382 Recipient Delivery Record and every Fee Disclosure Evidence to a DP-305 Fee Disclosure Delivery.",
            "Check Date is on or after Trigger Date on every check, and Relationship Summary Versions of the same Form CRS Filer Capacity do not overlap in their posting periods.",
            "Every check with Check Result = Pass names at least one populated evidence column whose delivery date is on or before the trigger deadline, and every Account Delivery Evidence resolves to an Account Disclosure Delivery of the Checked Account.",
            "Disclosure Trigger, Trigger Date, Check Date and Check Result are populated on every check, and Disclosure Type and Disclosure Delivered Date on every account disclosure delivery.",
            "Recipient names and addresses are not read; client and account keys are published to compliance only, and other views carry counts by trigger and result.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (client and account keys on delivery rows). "
               "Boundaries: who delivers which disclosure: 15 account opening, 13 periodic and event communications (DP-382), 47 fee "
               "disclosures (DP-305), 38 the Form CRS filing (CW-087, CW-162, CW-223); 08 owns the check. Absorbs backlog DP-328 "
               "(account features, agreements and disclosure evidence); 15 Account Disclosure Delivery is read directly because "
               "DP-093 does not publish it. The client-level Form CRS evidence on each recommendation (45 Best Interest Evidence) "
               "is DP-334's. 38 Form CRS Filing Detail and Firm Regulatory Filing are read directly: no foundational product "
               "publishes 38 filings. "
               "Tailoring lever: sample-based checks (08 SME 3). Reference default: every account opening and every recommendation "
               "trigger checked; periodic triggers sampled. "
               "Taxonomy gap: 08 Disclosure Delivery Check has no deadline attribute per trigger; the deadlines are drafting "
               "thresholds. "
               "Drafting assumptions: Check Result values Pass, Missing, Late, Wrong Version and Failed Delivery; Disclosure Trigger "
               "values Account Opening and Material Change; Disclosure Type Form CRS; Recipient Delivery Status Failed; the 30-day "
               "material change and 60-day amendment re-delivery windows. "
               "Decisions: CW-056, CW-087, CW-162, CW-223, CW-908. "
               "WP1 new (CW-220): absorbs backlog DP-328; all five candidate objects read, with 15 Account and 38 Firm Regulatory "
               "Filing added for the opening population and the filing date."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-400": dict(
        definition=("Every sales-practice surveillance scenario (excessive trading, concentration, share class and account type "
                    "selection, switching, rollover patterns, complex products) with its alerts, dispositions, corrective actions "
                    "against representatives and heightened supervision plans. Supervision manages the alert queue and evidences "
                    "that exceptions were reviewed and acted on. Market-abuse surveillance is 38 (DP-228). It owns no certified "
                    "metric family."),
        business_questions=[
            "How many alerts did each scenario generate this month, how many are open and how old, and how were the closed ones disposed of?",
            "Which corrective actions are overdue, and which involved client remediation?",
            "Which representatives have repeat alerts, and which are under heightened supervision?",
            "How many alerts concern complex or high-risk products, and are concentrated accounts covered by the concentration scenario?",
            "Which scenarios are due for threshold review?",
        ],
        grain=("Sales practice alert (SPA-) with its scenario version and corrective actions, joined to the triggering "
               "recommendation, account and representative; heightened supervision plans as a companion table; immutable alerts "
               "with disposition history"),
        dimensions=["Surveillance scenario and scenario type", "Alert type and disposition", "Alerted representative (DP-009)",
                    "Account and registration type (DP-093)", "Corrective action type and status", "Firm risk rating (DP-004)",
                    "Scenario model (DP-212)", "Alert generated date (DP-013)"],
        measures=[
            ("Active Scenarios", "Count of Surveillance Scenario versions with Scenario Status = Active in force at the as-of date (Scenario Effective From on or before it, Scenario Effective To empty or after it), by Scenario Type.",
             _u("08", "Surveillance Scenario", "Scenario ID", "Scenario Type", "Scenario Status", "Scenario Effective From", "Scenario Effective To")),
            ("Alerts Generated", "Count of Sales Practice Alert rows with Alert Generated Date in the period, by Alert Scenario and Alert Type.",
             _u("08", "Sales Practice Alert", "Sales Practice Alert ID", "Alert Generated Date", "Alert Scenario", "Alert Type")),
            ("Open Alerts", "Count of Sales Practice Alert rows with Alert Disposition empty or Open at the as-of date, with mean and maximum age in calendar days since Alert Generated Date, by Alert Scenario.",
             _u("08", "Sales Practice Alert", "Alert Disposition", "Alert Generated Date", "Alert Scenario")),
            ("Alerts Past Review Standard", "Open Alerts more than 30 calendar days after Alert Generated Date, by Alert Scenario and Alerted Representative's supervisor.",
             _u("08", "Sales Practice Alert", "Alert Generated Date", "Alerted Representative") + ["Open Alerts"]),
            ("Alert Disposition Mix", "Count of alerts dispositioned in the period by Alert Disposition (no further action, explained, escalated to review, corrective action), by Alert Scenario.",
             _u("08", "Sales Practice Alert", "Alert Disposition", "Alert Scenario")),
            ("Alert to Corrective Action Rate %", "Dispositioned alerts with a Conduct Corrective Action whose Source Sales Practice Alert is the alert / dispositioned alerts, by Alert Scenario.",
             _u("08", "Conduct Corrective Action", "Corrective Action ID", "Source Sales Practice Alert") + _u("08", "Sales Practice Alert", "Alert Disposition")),
            ("Corrective Actions Overdue", "Count of Conduct Corrective Action rows with Action Due Date before the as-of date and Action Status not Completed, by Corrective Action Type and Action Subject Representative.",
             _u("08", "Conduct Corrective Action", "Action Due Date", "Action Status", "Corrective Action Type", "Action Subject Representative")),
            ("Corrective Actions With Client Remediation", "Count of Conduct Corrective Action rows opened in the period with Client Remediation populated, by Corrective Action Type and source (Source Sales Practice Alert or Source Supervisory Review).",
             _u("08", "Conduct Corrective Action", "Client Remediation", "Corrective Action Type", "Source Sales Practice Alert", "Source Supervisory Review")),
            ("Representatives Under Heightened Supervision", "Count of distinct Supervised Representative of Heightened Supervision Plan rows in force at the as-of date (Plan Start Date on or before it, Plan End Date empty or after it).",
             _u("08", "Heightened Supervision Plan", "Heightened Supervision Plan ID", "Supervised Representative", "Plan Start Date", "Plan End Date")),
            ("Repeat-Alert Representatives", "Count of Alerted Representative values with three or more alerts with Alert Disposition not No Further Action in the 12 months to the as-of date, split by whether a Heightened Supervision Plan is in force for them.",
             _u("08", "Sales Practice Alert", "Alerted Representative", "Alert Generated Date", "Alert Disposition")
             + _u("08", "Heightened Supervision Plan", "Supervised Representative")),
            ("Complex Product Alerts", "Alerts Generated whose Triggering Recommendation resolves to a DP-303 Recommendation whose Recommended Share Class has Firm Risk Rating = High or Derivatives Risk Category populated (01 Product Risk Indicator, DP-004), by Alert Scenario.",
             _u("08", "Sales Practice Alert", "Triggering Recommendation") + _u("45", "Recommendation", "Recommendation ID", "Recommended Share Class")
             + _u("01", "Product Risk Indicator", "Firm Risk Rating", "Derivatives Risk Category") + ["Alerts Generated"]),
            ("Concentrated Accounts Without Alert", "Count of accounts whose largest Held Instrument position is more than 25% of the account's total Market Value in USD in 49 Client Holding Valuation on the month-end Client Holding Date with Client Holding View = End of Day (DP-300), excluding own funds of a diversified type, with no concentration-scenario alert (Alert Account) in the 90 days before; a coverage check of the scenario, not a new alert.",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View", "Own Share Class Indicator")
             + _u("49", "Client Holding Valuation", "Market Value in USD") + _u("08", "Sales Practice Alert", "Alert Account", "Alert Scenario")),
            ("Scenarios Due for Threshold Review", "Count of Active Scenarios whose current version's Scenario Effective From is more than 12 months before the as-of date, or whose Scenario Model is no longer validated in DP-212, by Scenario Type.",
             _u("08", "Surveillance Scenario", "Scenario Effective From", "Scenario Model", "Threshold Parameters", "Scenario Rule Basis") + ["Active Scenarios"]),
            ("Alerts per 1,000 Accounts", "Alerts Generated / distinct DP-093 accounts open in the period x 1,000, by Alert Scenario and Account Registration Type.",
             _u("15", "Account", "Account ID", "Account Status", "Account Registration Type") + ["Alerts Generated"]),
        ],
        inputs=[
            ("08", "Surveillance Scenario", ["Scenario ID", "Scenario Type", "Scenario Rule Basis", "Threshold Parameters", "Scenario Model",
                                             "Scenario Status", "Scenario Effective From", "Scenario Effective To"]),
            ("08", "Sales Practice Alert", ["Sales Practice Alert ID", "Alert Scenario", "Alert Type", "Alert Account", "Alerted Representative",
                                            "Triggering Transaction", "Triggering Recommendation", "Alert Generated Date",
                                            "Alert Disposition"]),
            ("08", "Conduct Corrective Action", ["Corrective Action ID", "Source Supervisory Review", "Source Sales Practice Alert",
                                                 "Corrective Action Type", "Action Subject Representative", "Action Due Date",
                                                 "Action Status", "Client Remediation"]),
            ("08", "Heightened Supervision Plan", ["Heightened Supervision Plan ID", "Supervised Representative", "Plan Start Date", "Plan End Date"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommended Share Class", "Recommended Instrument"]),
            ("01", "Product Risk Indicator", ["Firm Risk Rating", "Derivatives Risk Category"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View", "Own Share Class Indicator"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("15", "Account", ["Account ID", "Account Status", "Account Registration Type"]),
        ],
        upstream=["DP-009", "DP-093", "DP-240", "DP-300", "DP-301", "DP-303", "DP-004", "DP-212", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for alerts generated and dispositioned the prior business day; concentration coverage monthly by business day 3",
        history="Alerts, dispositions and corrective actions immutable with status history; scenario versions SCD type 2; kept six years (FINRA Rule 3110 and Rule 4511; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Alert Account resolves to a DP-093 Account ID, every Alerted Representative, Action Subject Representative and Supervised Representative to a DP-009 advisor, every Triggering Recommendation to a DP-303 Recommendation ID, every Alert Scenario to a Scenario ID and every Scenario Model to a DP-212 model.",
            "Surveillance Scenario versions of one Scenario ID do not overlap, and Plan End Date and Scenario Effective To are empty or on or after their start dates.",
            "Every alert's Alert Scenario was Active on its Alert Generated Date, and every Conduct Corrective Action with Source Sales Practice Alert populated points to an alert with Alert Disposition = Corrective Action.",
            "Alert Scenario, Alert Type, Alert Account, Alert Generated Date and Alert Disposition (once closed) are populated on every alert, and Corrective Action Type, Action Due Date and Action Status on every corrective action.",
            "Heightened Supervision Plan Basis, Plan Conditions and any disclosure-event link are not read (the basis may be a criminal disclosure, CD-344); client and representative identity is visible to supervision only.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (client and representative keys; restricted to supervision). Heightened supervision plans are "
               "read without their basis, which can be special category (CD-344). "
               "Boundaries: sales-practice surveillance is 08 and market-abuse surveillance 38 (DP-228; CW-163). Holdings read are "
               "Client Holding (49) through DP-300, never 06 or 18 (CW-007); recommendations are DP-303's, executions DP-301's "
               "(the Triggering Transaction key). The 01 firm risk rating (Product Risk Indicator, DP-004) sets the complex-product "
               "scenarios. Supersedes DP-060: share class selection becomes a scenario; brokerage breakpoints are 47 fee "
               "householding (CW-052). Frequent trading in own funds is backlog DP-416, merged into DP-585. DP-404 reads this "
               "product's alert and action counts. "
               "Tailoring lever: scenarios by product line. Reference default: options, margin and complex-product scenarios on; "
               "they drop with the product lines (plan section 15 ruling 3). "
               "Tailoring lever: concentration threshold. Reference default: 25% of account market value in one instrument. "
               "Taxonomy gap: 08 Sales Practice Alert has no disposition date; the disposition period is taken from the alert's "
               "status history at load. "
               "Drafting assumptions: Alert Disposition values Open, No Further Action and Corrective Action; Firm Risk Rating High; "
               "Action Status Completed; the 30-day review standard, 12-month threshold review and 25% concentration threshold. "
               "Decisions: CW-007, CW-052, CW-066, CW-163, CD-294. "
               "WP1 new (CW-220): supersedes DP-060; upstream of DP-404; all six candidate objects read, with 49 Client Holding "
               "Valuation and 15 Account added for the coverage and rate measures."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-402": dict(
        definition=("The supervisory control system under FINRA Rules 3110 and 3120: each supervisory control and its test, branch "
                    "and OSJ inspections against their cycle, the findings they raised with the corrective actions owed, "
                    "heightened supervision plans, and the Rule 3130 certification attested in 38. Supervision and the CCO "
                    "evidence the annual Rule 3120 report and the Rule 3130 certification. It owns no certified metric family."),
        business_questions=[
            "Which supervisory controls were tested this year, which failed, and which tests require a change to the written supervisory procedures?",
            "Which branches and OSJs are overdue for inspection against their cycle, and how quickly are inspection reports issued?",
            "Which findings are open by severity, and which have no corrective action or an overdue one?",
            "Which heightened supervision plans are in force, and which lack a heightened supervisor?",
            "Has the Rule 3120 report been delivered and the Rule 3130 certification completed for the year?",
        ],
        grain=("Supervisory control x test period, with branch inspections (office x inspection), supervisory findings and their "
               "corrective actions, heightened supervision plans and attestations as companion facts; immutable once completed"),
        dimensions=["Supervisory control and governing WSP policy", "Supervised activity", "Test result", "Inspected office and branch type (DP-391)",
                    "Inspection cycle", "Finding source and severity", "Corrective action status", "Inspector and control tester (DP-192)",
                    "Attestation type and period", "Test period (DP-013)"],
        measures=[
            ("Active Supervisory Controls", "Count of Supervisory Control rows with Control Status = Active at the as-of date, by Supervised Activity and Control Frequency.",
             _u("08", "Supervisory Control", "Supervisory Control Number", "Control Status", "Supervised Activity", "Control Frequency")),
            ("Controls Tested in Year %", "Active Supervisory Controls with a Supervisory Control Test whose Test Period End Date falls in the Rule 3120 report year / Active Supervisory Controls.",
             _u("08", "Supervisory Control Test", "Tested Control", "Test Period End Date") + ["Active Supervisory Controls"]),
            ("Control Test Failure Rate %", "Supervisory Control Tests in the year with Test Result in Fail or Partially Effective / Supervisory Control Tests in the year, by Supervised Activity.",
             _u("08", "Supervisory Control Test", "Tested Control", "Test Result", "Test Period End Date") + _u("08", "Supervisory Control", "Supervised Activity")),
            ("Tests Requiring WSP Amendment", "Count of Supervisory Control Tests in the year with WSP Amendment Required Indicator = Y, by Governing WSP Policy.",
             _u("08", "Supervisory Control Test", "WSP Amendment Required Indicator") + _u("08", "Supervisory Control", "Governing WSP Policy")),
            ("Controls on Inactive WSP Policy", "Count of Active Supervisory Controls whose Governing WSP Policy resolves to a 38 Policy with Policy Status not Active.",
             _u("08", "Supervisory Control", "Governing WSP Policy") + _u("38", "Policy", "Policy ID", "Policy Status") + ["Active Supervisory Controls"]),
            ("Inspections Overdue", "Count of active branch designations (DP-391) whose latest Branch Inspection Inspection Date is older than its Inspection Cycle (OSJ and supervising branch annually, non-supervising branch every three years, non-branch location periodically) at the as-of date, by Branch Type.",
             _u("08", "Branch Inspection", "Branch Inspection ID", "Inspected Office", "Inspection Cycle", "Inspection Date")
             + _u("03", "Firm Branch Office", "Office", "Branch Type", "Branch Status")),
            ("Inspections On Cycle %", "Active branch designations whose latest inspection is within its Inspection Cycle / active branch designations, by Branch Type at Inspection.",
             _u("08", "Branch Inspection", "Branch Type at Inspection", "Inspection Cycle", "Inspection Date") + _u("03", "Firm Branch Office", "Office")),
            ("Inspection Report Lag (Days)", "Median calendar days from Inspection Date to Inspection Report Date for inspections in the year, by Inspector.",
             _u("08", "Branch Inspection", "Inspection Date", "Inspection Report Date", "Inspector")),
            ("Remote Inspection Share %", "Branch Inspections in the year with Remote Inspection Indicator = Y / Branch Inspections in the year (FINRA Rule 3110.18 remote inspections).",
             _u("08", "Branch Inspection", "Remote Inspection Indicator", "Inspection Date")),
            ("Open Findings by Severity", "Count of Supervisory Finding rows with Finding Status not Closed, by Finding Severity and Finding Source (branch inspection, control test, examination).",
             _u("08", "Supervisory Finding", "Supervisory Finding ID", "Finding Status", "Finding Severity", "Finding Source",
                "Source Branch Inspection", "Source Control Test")),
            ("Findings Without Corrective Action", "Count of open findings of Finding Severity High or Medium with no Conduct Corrective Action whose Source Supervisory Finding is the finding.",
             _u("08", "Conduct Corrective Action", "Source Supervisory Finding") + _u("08", "Supervisory Finding", "Finding Severity") + ["Open Findings by Severity"]),
            ("Finding Corrective Actions Overdue", "Count of Conduct Corrective Action rows with Source Supervisory Finding populated, Action Due Date before the as-of date and Action Status not Completed, by Action Owner.",
             _u("08", "Conduct Corrective Action", "Corrective Action ID", "Source Supervisory Finding", "Action Due Date", "Action Status", "Action Owner")),
            ("Heightened Supervision Plans Without Supervisor", "Count of Heightened Supervision Plan rows in force (Plan Start Date on or before the as-of date, Plan End Date empty or after it) with Heightened Supervisor empty, beside the count of plans in force.",
             _u("08", "Heightened Supervision Plan", "Heightened Supervision Plan ID", "Heightened Supervisor", "Plan Start Date", "Plan End Date")),
            ("Rule 3120 Report Delivered", "Y when at least one Supervisory Control Test of the report year has Rule 3120 Report Date populated on or before the firm's report deadline, with that date.",
             _u("08", "Supervisory Control Test", "Rule 3120 Report Date", "Test Period End Date")),
            ("Rule 3130 Certification Complete", "Y when an Attestation of Attestation Type = Rule 3130 CEO Certification for the year's Attestation Period has Attestation Status = Completed, with its Attestation Completed Date.",
             _u("38", "Attestation", "Attestation Type", "Attestation Period", "Attestation Status", "Attestation Completed Date", "Attester")),
        ],
        inputs=[
            ("08", "Supervisory Control", ["Supervisory Control Number", "Governing WSP Policy", "Supervised Activity", "Responsible Designation",
                                           "Control Frequency", "Control Rule Basis", "Control Status"]),
            ("08", "Supervisory Control Test", ["Tested Control", "Test Period End Date", "Test Result", "Control Tester",
                                                "WSP Amendment Required Indicator", "Rule 3120 Report Date"]),
            ("08", "Branch Inspection", ["Branch Inspection ID", "Inspected Office", "Branch Type at Inspection", "Inspection Cycle",
                                         "Remote Inspection Indicator", "Inspection Date", "Inspector", "Inspection Report Date"]),
            ("08", "Supervisory Finding", ["Supervisory Finding ID", "Finding Source", "Source Branch Inspection", "Source Control Test",
                                           "Finding Severity", "Finding Status"]),
            ("08", "Conduct Corrective Action", ["Corrective Action ID", "Source Supervisory Finding", "Action Owner", "Action Due Date", "Action Status"]),
            ("08", "Heightened Supervision Plan", ["Heightened Supervision Plan ID", "Supervised Representative", "Heightened Supervisor",
                                                   "Plan Start Date", "Plan End Date"]),
            ("03", "Firm Branch Office", ["Office", "Branch Type", "Branch Status"]),
            ("38", "Attestation", ["Attestation Type", "Attester", "Attestation Completed Date", "Attestation Status", "Attestation Period"]),
            ("38", "Policy", ["Policy ID", "Policy Title", "Policy Status"]),
        ],
        upstream=["DP-391", "DP-009", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; the Rule 3120 and Rule 3130 status refreshed on event",
        history="Tests, inspections, findings and attestations immutable; controls and plans SCD type 2; kept six years (FINRA Rules 3110, 3120, 3130 and 4511; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Inspected Office resolves to a DP-391 branch designation, every Inspector, Control Tester, Action Owner, Heightened Supervisor and Attester to a DP-192 employee, every Governing WSP Policy to a 38 Policy ID, and every Tested Control to a Supervisory Control Number.",
            "Inspection Report Date is on or after Inspection Date, Plan End Date is empty or on or after Plan Start Date, and a control has at most one test per Test Period End Date.",
            "Every finding with Finding Source = Branch Inspection has Source Branch Inspection populated and every finding with Finding Source = Control Test has Source Control Test populated, and every Source Branch Inspection and Source Control Test resolves to an inspection or test of this product.",
            "Control Status and Supervised Activity are populated on every control, Test Result on every test, Inspection Cycle and Inspection Date on every inspection, and Finding Severity and Finding Status on every finding.",
            "Heightened Supervision Plan Basis and Finding Description are not read (they can name special-category or disciplinary facts, CD-344); person-level rows are published to supervision and the CCO only.",
            "The prior business day is complete by 7am ET on T+1, and a Rule 3120 report year is locked once the report is delivered.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (employees). "
               "Boundaries: written supervisory procedures are 38 Policies and the Rule 3130 certification a 38 Attestation "
               "(CW-066), read directly as no foundational product publishes them; the branch structure is DP-391's; corrective "
               "actions raised from alerts are DP-400's; regulatory examination findings are 38 (Related Examination Finding key). "
               "DP-404 reads the open findings. "
               "Tailoring lever: branch network size (03 SME 8). Reference default: OSJs and branches inspected on the Rule 3110(c) "
               "cycle; a remote-only firm keeps the home-office OSJ and residential supervisory locations. "
               "Taxonomy gap: 08 Supervisory Finding has no owner, due date or closed date; ownership and due dates are taken from "
               "the Conduct Corrective Action raised from the finding. "
               "Drafting assumptions: Test Result values Fail and Partially Effective; Finding Status Closed; Finding Severity High "
               "and Medium; Attestation Type Rule 3130 CEO Certification; Attestation Status Completed; the inspection cycles. "
               "Decisions: CW-061, CW-066, CW-908. "
               "WP1 new (CW-220): Rule 3120 and Rule 3130 controls; all seven candidate objects read, with 08 Conduct Corrective "
               "Action and 38 Policy added for the finding actions and the WSP link."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-403": dict(
        definition=("Every senior investor case from the vulnerability concern that raised it through trusted contact outreach, "
                    "temporary holds on disbursements and securities under FINRA Rule 2165 against their day limits, external "
                    "reports to adult protective services and regulators, and resolution. The senior investor team runs its cases "
                    "and compliance evidences each hold and report. It is the named restricted view for the 08 Rule 2165 case "
                    "(CW-213, CW-225): the 02 protection facts and the special-category hold rows are read through DP-322's "
                    "restricted view, and every other product sees only counts or the DP-322 flag. It owns no certified metric "
                    "family."),
        business_questions=[
            "Which senior investor cases are open, how old are they, and how many concerns were substantiated?",
            "Which Rule 2165 holds on disbursements and securities are active, how much is held, and which are near or past their day limit?",
            "Were the client and the trusted contact notified within two business days of each hold, and which cases have no trusted contact on file?",
            "Which holds were extended without the external report the extension requires, and how many reports went to adult protective services and regulators?",
            "How long do cases take to close, and how many were linked to an AML case?",
        ],
        grain=("Senior investor case (SNRC-) with its protective actions, holds (50 money movement holds and 15 Rule 2165 account "
               "restrictions linked to the case) and external protection reports as companion facts; restricted view; status "
               "history kept"),
        dimensions=["Case status", "Specified adult basis", "Protection action type", "Hold type and status", "Report recipient type",
                    "Case owner (DP-192)", "Client and household (DP-240, restricted)", "Account (DP-093)", "Case opened date (DP-013)"],
        measures=[
            ("Open Senior Investor Cases", "Count of Senior Investor Case rows with Case Status not Closed at the as-of date, by Case Status and Case Owner.",
             _u("08", "Senior Investor Case", "Senior Investor Case ID", "Case Status", "Case Owner")),
            ("Cases Opened", "Count of Senior Investor Case rows with Case Opened Date in the period.",
             _u("08", "Senior Investor Case", "Senior Investor Case ID", "Case Opened Date")),
            ("Open Case Age (Business Days)", "Business days (DP-013 calendar) from Case Opened Date to the as-of date for open cases; median and maximum.",
             _u("08", "Senior Investor Case", "Case Opened Date", "Case Status")),
            ("Concern Substantiation Rate %", "Cases closed in the period with Concern Substantiated Indicator = Y / cases closed in the period.",
             _u("08", "Senior Investor Case", "Concern Substantiated Indicator", "Case Closed Date")),
            ("Active Rule 2165 Holds", "Count of 50 Money Movement Hold rows with Senior Investor Case populated, Hold Type = FINRA Rule 2165 Disbursement Hold and Hold Status in (Active, Extended), plus 15 Account Restriction rows of Account Restriction Type = Financial Exploitation with Account Restriction Lifted Date empty, at the as-of date; both read through the DP-322 restricted view. DP-403 owns the Rule 2165 clock; DP-456 reads it.",
             _u("50", "Money Movement Hold", "Money Movement Hold ID", "Senior Investor Case", "Hold Type", "Hold Status")
             + _u("15", "Account Restriction", "Account Restriction ID", "Account Restriction Type", "Account Restriction Lifted Date")),
            ("Amount Held on Rule 2165 Disbursement Holds", "Sum of Movement Amount of the 50 Money Movements named as Held Movement by Rule 2165 disbursement holds with Hold Status in (Active, Extended) (DP-302 movement amount), in USD.",
             _u("50", "Money Movement Hold", "Held Movement", "Hold Type", "Hold Status") + _u("50", "Money Movement", "Money Movement ID", "Movement Amount")),
            ("Holds Past Day Limit", "Count of active Rule 2165 holds whose business days since Hold Placed Date (or Account Restriction Effective From) exceed the limit in force for them: 15 business days, 25 with one extension, 55 where an External Protection Report supports the further extension; and of holds within 3 business days of the limit.",
             _u("50", "Money Movement Hold", "Hold Placed Date", "Hold Expiry Date", "Senior Investor Case")
             + _u("15", "Account Restriction", "Account Restriction Effective From", "Restriction Review Due Date")
             + _u("08", "External Protection Report", "Reported Case", "Report Date") + ["Active Rule 2165 Holds"]),
            ("Hold Notice Timeliness %", "Rule 2165 holds placed in the period with Hold Notice Date within 2 business days of Hold Placed Date / Rule 2165 holds placed in the period.",
             _u("50", "Money Movement Hold", "Hold Notice Date", "Hold Placed Date", "Hold Type")),
            ("Trusted Contact Outreach Timeliness %", "Holds placed in the period whose case has Trusted Contact Contacted Date, or a hold with Trusted Contact Notified populated, within 2 business days of Hold Placed Date / holds placed in the period, excluding cases where the trusted contact is the suspected party.",
             _u("08", "Senior Investor Case", "Trusted Contact Contacted Date") + _u("50", "Money Movement Hold", "Trusted Contact Notified", "Hold Placed Date")),
            ("Cases Without Trusted Contact on File", "Count of open cases whose Case Client has no 02 Trusted Contact Designation with Designation Status = Active (DP-240), and of those with a Senior Investor Case Action of Protection Action Type = Trusted Contact Requested.",
             _u("08", "Senior Investor Case", "Case Client") + _u("02", "Trusted Contact Designation", "Trusted Contact Designation ID", "Designating Client", "Designation Status")
             + _u("08", "Senior Investor Case Action", "Protection Action Type")),
            ("External Protection Reports", "Count of External Protection Report rows with Report Date in the period, by Report Recipient Type (adult protective services, state securities regulator, law enforcement, FinCEN through the AML case).",
             _u("08", "External Protection Report", "Reported Case", "Report Recipient Type", "Recipient Agency", "Report Date")),
            ("Holds Extended Without External Report", "Count of active Rule 2165 holds beyond 25 business days whose case has no External Protection Report with Report Date on or before the extension, the condition for the further extension.",
             _u("08", "External Protection Report", "Reported Case", "Report Date") + _u("08", "Senior Investor Case Action", "Protection Action Type", "Action Date")
             + ["Holds Past Day Limit"]),
            ("Protective Actions by Type", "Count of Senior Investor Case Action rows with Action Date in the period by Protection Action Type, with those where Account Hold = Y or Disbursement Hold = Y, and those using a Trusted Contact Designation Used.",
             _u("08", "Senior Investor Case Action", "Protection Action Type", "Action Date", "Account Hold", "Disbursement Hold", "Trusted Contact Designation Used")),
            ("Cases Linked to AML", "Count of cases with Related AML Case populated, opened in the period; the AML case itself is 38's (DP-226).",
             _u("08", "Senior Investor Case", "Related AML Case", "Case Opened Date")),
            ("Case Closure Cycle Time (Business Days)", "Median business days from Case Opened Date to Case Closed Date for cases closed in the period, by Specified Adult Basis.",
             _u("08", "Senior Investor Case", "Case Opened Date", "Case Closed Date", "Specified Adult Basis")),
        ],
        inputs=[
            ("08", "Senior Investor Case", ["Senior Investor Case ID", "Case Client", "Source Vulnerability Concern", "Trusted Contact Contacted Date",
                                            "Specified Adult Basis", "Case Opened Date", "Case Owner", "Case Status",
                                            "Concern Substantiated Indicator", "Related AML Case", "Case Closed Date"]),
            ("08", "Senior Investor Case Action", ["Protection Action Type", "Action Date", "Trusted Contact Designation Used", "Account Hold",
                                                   "Disbursement Hold"]),
            ("08", "External Protection Report", ["Reported Case", "Report Recipient Type", "Recipient Agency", "Report Date"]),
            ("50", "Money Movement Hold", ["Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Status", "Hold Placed Date",
                                           "Hold Expiry Date", "Trusted Contact Notified", "Hold Notice Date", "Senior Investor Case",
                                           "Hold Released Date"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Movement Amount"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date", "Restriction Review Due Date"]),
            ("02", "Trusted Contact Designation", ["Trusted Contact Designation ID", "Designating Client", "Designation Status", "Last Confirmed Date"]),
        ],
        upstream=["DP-322", "DP-240", "DP-093", "DP-302", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; holds approaching their day limit pushed to the senior investor team on the event stream within 1 hour of the daily hold-clock run at 6am ET",
        history="Cases, actions, holds and reports kept as immutable facts with status history; kept six years after the case closes (FINRA Rule 2165 records, FINRA Rule 4511, SEC Rule 17a-4)",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "Event stream"],
        dq_rules=[
            "Every Case Client and Designating Client resolves to a DP-240 party, every Restricted Account and Movement Account to a DP-093 Account ID, every Case Owner to a DP-192 employee, every Reported Case and every hold's Senior Investor Case to a Senior Investor Case ID, and every Source Vulnerability Concern to a DP-322 concern key.",
            "Case Closed Date is empty or on or after Case Opened Date, Hold Released Date and Account Restriction Lifted Date are empty or on or after their placement dates, and a case has no two active Rule 2165 holds on the same Held Movement.",
            "Every Rule 2165 hold read here has a Senior Investor Case that resolves to a case of this product whose Case Client owns the Movement Account of the Held Movement, and every Financial Exploitation restriction's Restricted Account belongs to the Case Client of an open case; unmatched rows are reported, never dropped.",
            "Case Status, Case Opened Date and Source Vulnerability Concern are populated on every case, a Trusted Contact Designation with Designation Status is read for every Case Client (FINRA Rule 4512 trusted contact; FINRA Rule 2165 outreach), Hold Placed Date, Hold Type and Hold Status on every hold, and Report Recipient Type and Report Date on every external report.",
            "The product is a restricted view (Restricted - Personal Data) entitled to the senior investor team and retail conduct compliance only; 02 Specified Adult Status and Vulnerability Concern detail, Hold Reason and Hold Reason Narrative are never read; any view outside the entitlement carries counts by status and type with a minimum cell of 10 cases (CD-344, CW-213, CW-225).",
            "The hold clock runs daily by 6am ET and the prior day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: special category (CD-344). Restricted view; aggregates elsewhere with a minimum cell of 10 (CW-225). "
               "Boundaries: CW-071 and CW-109: the case is 08, the concern 02, holds 15 and 50. Program ruling (C-2 fix pass): this product owns the Rule 2165 clock and the case counts; DP-322 drops its clock and case measures (C-1) and DP-456 reads this product's. DP-322 (CLA-A) is the protection "
               "register (who is protected); this product is the named restricted view for the 08 Rule 2165 case and the hold "
               "clock (CW-213). It reads the 02 protection facts and the special-category hold rows (50 Money Movement Hold and "
               "15 Account Restriction of Rule 2165 type, which DP-302 and DP-093 suppress) through DP-322's restricted view, and "
               "reads the 08 case objects directly as the named exception. Cash on hold for fraud or elder-exploitation review "
               "(acceptance question 7) is BWO DP-456, which reads DP-322 and may read this product; DP-456 is not upstream. DP-583 "
               "(FOP) covers holds on TA-registered accounts. The AML case is 38 (DP-226). DP-322 must not list this product "
               "upstream. "
               "Acceptance question 7: feeds DP-456 with the Senior Investor Case key behind each elder hold and the Rule 2165 hold "
               "clock (Active Rule 2165 Holds, Holds Past Day Limit, Hold Notice Timeliness %). "
               "Tailoring lever: case scope (08 SME 5). Reference default: a case for every escalated vulnerability concern, not "
               "for every specified adult. "
               "Tailoring lever: case home (08 SME 9). Reference default: cases run in 08 by retail conduct compliance; a firm "
               "running them in 38 moves the case objects there. "
               "Tailoring lever: FINRA Rule 2166 temporary delays (50 lever 9). Reference default: not adopted; if adopted they join "
               "the hold clock with their own limits. "
               "Taxonomy gap: 08 Senior Investor Case has no attribute marking the trusted contact as the suspected party; the exclusion in Trusted Contact Outreach Timeliness % is applied from the case action record at load. "
               "Taxonomy gap: 50 Money Movement Hold has no extension count or extension date; the extension is taken from the "
               "Senior Investor Case Action of type hold extended. "
               "Drafting assumptions: the Rule 2165 limits of 15, 25 and 55 business days (to confirm against the current FINRA "
               "rule text); Hold Type FINRA Rule 2165 Disbursement Hold and Account Restriction Type Financial Exploitation; "
               "Hold Status Active and Extended; Designation Status Active; Protection Action Type Trusted Contact Requested; the 2-business-day "
               "notice standard and 3-day warning band; the minimum cell of 10. "
               "Decisions: CW-030, CW-071, CW-109, CW-163, CW-213, CW-225; CD-344. "
               "WP1 new (CW-225): Q7 feeder (Rule 2165 case); all five candidate objects read, with 50 Money Movement (amounts) and "
               "02 Trusted Contact Designation added; the candidate's DP-381 upstream is dropped (no 13 object is read)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-414": dict(
        definition=("Every complaint with its FINRA problem and product codes, handling, outcome, redress and root cause, by "
                    "offering, channel, advisor and branch, with the FINRA Rule 4530(d) quarterly statistics, the 4530(a) and Form "
                    "U4 reportable events, and the dissatisfaction seen in service contacts and surveys that was not logged as a "
                    "complaint. Complaints teams meet response deadlines; product and service owners act on systemic causes. The "
                    "Rule 4530 definition decides what is a complaint (CW-070). It owns no certified metric family."),
        business_questions=[
            "How many complaints did we receive this quarter by category, source and offering, how many are open and how many are past their response due date?",
            "What are the Rule 4530(d) statistics by FINRA problem and product code, and which complaints are reportable under Rule 4530(a) or on Form U4?",
            "Which advisors and offices are named most often, and what redress did we pay?",
            "Which service contacts and survey responses expressed dissatisfaction but were never logged as complaints?",
            "Which root causes recur, and how many complaints concern a recommendation?",
        ],
        grain=("Complaint (CPL-) with its classification, handling and regulatory reporting attribute groups, joined to the "
               "account, offering, advisor of record and intake service request; companion facts for unlogged dissatisfaction "
               "(13 interactions, 04 survey responses); immutable intake with handling status as SCD type 2"),
        dimensions=["Complaint category and FINRA problem and product codes", "Complaint source and written or oral", "Complaint status and outcome",
                    "Root cause", "Associated person named and advisor of record (DP-009)", "Complaint office (DP-391)",
                    "Account and registration type (DP-093)", "Service offering (DP-004)", "Product or share class (DP-004)",
                    "Rule 4530(d) reporting quarter", "Received date (DP-013)"],
        measures=[
            ("Complaints Received", "Count of Complaint rows with Received Date in the period, by Complaint Category, Complaint Source and Written Complaint Indicator.",
             _u("08", "Complaint", "Complaint ID", "Received Date", "Complaint Source", "Written Complaint Indicator")
             + _u("08", "Complaint Classification", "Complaint Category")),
            ("Open Complaints", "Count of complaints with Complaint Status not Closed at the as-of date, with mean age in calendar days since Received Date, by Complaint Category.",
             _u("08", "Complaint Handling", "Complaint Status") + _u("08", "Complaint", "Received Date") + _u("08", "Complaint Classification", "Complaint Category")),
            ("Final Responses Past Due", "Count of complaints with Final Response Date after Final Response Due Date, or open with Final Response Due Date before the as-of date, by Complaint Category.",
             _u("08", "Complaint Handling", "Final Response Date", "Final Response Due Date", "Complaint Status")),
            ("Median Days to Final Response", "Median calendar days from Received Date to Final Response Date of complaints with a final response in the period, by Complaint Source.",
             _u("08", "Complaint", "Received Date", "Complaint Source") + _u("08", "Complaint Handling", "Final Response Date")),
            ("Complaint Outcome Mix", "Count of complaints closed in the period by Complaint Outcome (upheld, partially upheld, not upheld, withdrawn), with the upheld share.",
             _u("08", "Complaint Handling", "Complaint Outcome", "Complaint Status", "Final Response Date")),
            ("Redress Paid", "Sum of Redress Amount of complaints closed in the period, by Complaint Category, with the count linked to a Client Remediation (DP-409) or an Arbitration Matter.",
             _u("08", "Complaint Handling", "Redress Amount", "Client Remediation", "Arbitration Matter", "Final Response Date")),
            ("Rule 4530(d) Statistics", "Count of written complaints by FINRA 4530(d) Reporting Quarter x FINRA Problem Code x FINRA Product Code, as filed quarterly.",
             _u("08", "Complaint Regulatory Report", "FINRA 4530(d) Reporting Quarter") + _u("08", "Complaint Classification", "FINRA Problem Code", "FINRA Product Code")
             + _u("08", "Complaint", "Written Complaint Indicator")),
            ("Rule 4530(a) Reportable Events", "Count of complaints with FINRA 4530(a) Event Reportable Indicator = Y in the period, and of those with Form U4 Reportable Indicator = Y with Related Disclosure Event populated.",
             _u("08", "Complaint Regulatory Report", "FINRA 4530(a) Event Reportable Indicator", "Form U4 Reportable Indicator", "Related Disclosure Event")),
            ("Complaints Naming an Associated Person", "Count of Complaints Received with Associated Person Named populated, by Associated Person Named and Complaint Office.",
             _u("08", "Complaint", "Associated Person Named", "Complaint Office") + ["Complaints Received"]),
            ("Complaints per 1,000 Accounts by Offering", "Complaints Received whose Account has an active 15 Program Enrollment in the offering / accounts enrolled in the offering x 1,000; self-directed accounts form their own row.",
             _u("08", "Complaint", "Account") + _u("15", "Program Enrollment", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status")
             + ["Complaints Received"]),
            ("Complaints by Advisor of Record", "Complaints Received by the Covering Advisor of the primary 03 Party Coverage Assignment of the complaint's Account (Covered Account) in force at Received Date (DP-009).",
             _u("03", "Party Coverage Assignment", "Covered Account", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To")
             + _u("08", "Complaint", "Account", "Received Date")),
            ("Unlogged Service Dissatisfaction", "Count of 13 Contact Center Interaction rows in the period with Dissatisfaction Expressed Indicator = Y whose Linked Service Request has no Escalated Complaint and with no Complaint whose Intake Service Request is that request (DP-381); the candidates for Rule 4530 review.",
             _u("13", "Contact Center Interaction", "Interaction ID", "Interaction Start Timestamp", "Dissatisfaction Expressed Indicator", "Linked Service Request")
             + _u("13", "Service Request", "Service Request ID", "Escalated Complaint") + _u("08", "Complaint", "Intake Service Request")),
            ("Survey Complaint Referrals", "Count of 04 Survey Response rows in the period with Complaint Referral populated, split by whether the referral resolves to an 08 Complaint ID.",
             _u("04", "Survey Response", "Response ID", "Response Timestamp", "Complaint Referral") + _u("08", "Complaint", "Complaint ID")),
            ("Recurring Root Causes", "Count of complaints by Root Cause in the trailing quarter, listing root causes with 5 or more complaints and their FINRA Product Code mix.",
             _u("08", "Complaint Classification", "Root Cause", "FINRA Product Code") + _u("08", "Complaint", "Received Date")),
            ("Recommendation-Related Complaints", "Count of Complaints Received with Related Recommendation populated, by Complaint Category; the evidence of the recommendation is DP-334's.",
             _u("08", "Complaint", "Related Recommendation") + _u("08", "Complaint Classification", "Complaint Category") + ["Complaints Received"]),
            ("Complaints From Protected Clients (from DP-322)", "Count of Complaints Received whose Complainant has Protection Flag Present (from DP-322) = Y, joined on the 02 party key only; published at counts of 10 or more.",
             _u("08", "Complaint", "Complainant") + ["Complaints Received"]),
        ],
        inputs=[
            ("08", "Complaint", ["Complaint ID", "Received Date", "Complaint Source", "Complainant", "Written Complaint Indicator",
                                 "Intake Service Request", "Account", "Product / Share Class", "Related Recommendation",
                                 "Associated Person Named", "Complaint Office"]),
            ("08", "Complaint Classification", ["Complaint Category", "FINRA Problem Code", "FINRA Product Code", "Root Cause"]),
            ("08", "Complaint Handling", ["Complaint Status", "Final Response Due Date", "Final Response Date", "Complaint Outcome",
                                          "Redress Amount", "Client Remediation", "Arbitration Matter"]),
            ("08", "Complaint Regulatory Report", ["FINRA 4530(d) Reporting Quarter", "FINRA 4530(a) Event Reportable Indicator",
                                                   "Form U4 Reportable Indicator", "Related Disclosure Event"]),
            ("13", "Contact Center Interaction", ["Interaction ID", "Interaction Account", "Interaction Start Timestamp",
                                                  "Dissatisfaction Expressed Indicator", "Linked Service Request"]),
            ("13", "Service Request", ["Service Request ID", "Escalated Complaint"]),
            ("04", "Survey Response", ["Response ID", "Response Timestamp", "Complaint Referral"]),
            ("03", "Party Coverage Assignment", ["Covered Account", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From",
                                                 "Coverage Effective To"]),
            ("15", "Program Enrollment", ["Enrolled Account", "Enrolled Service Offering", "Enrollment Status"]),
        ],
        upstream=["DP-381", "DP-009", "DP-240", "DP-093", "DP-004", "DP-322", "DP-391", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; Rule 4530(d) statistics locked by business day 10 after quarter-end for the filing due on the 15th",
        history="Complaints kept from intake with handling status as SCD type 2; Rule 4530(d) quarters locked as filed; kept four years at minimum and six years by firm policy (FINRA Rule 4513; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Complainant resolves to a DP-240 party, every Account to a DP-093 Account ID, every Associated Person Named and Covering Advisor to a DP-009 advisor, every Product / Share Class to DP-004, every Intake Service Request to a DP-381 Service Request ID and every Complaint Office to a DP-391 office.",
            "Final Response Date is empty or on or after Received Date, and Party Coverage Assignment periods with Primary Coverage Indicator = Y do not overlap for the same Covered Account.",
            "Every written complaint with Received Date in a calendar quarter carries that quarter as FINRA 4530(d) Reporting Quarter, and every complaint with FINRA 4530(a) Event Reportable Indicator = Y or Form U4 Reportable Indicator = Y has FINRA Problem Code and FINRA Product Code populated.",
            "Received Date, Complaint Source, Written Complaint Indicator and Complainant are populated on every complaint, FINRA Problem Code and FINRA Product Code on every written complaint, and Complaint Outcome and Final Response Date on every closed complaint.",
            "Complaint Summary, Related Vulnerability Concern and survey Verbatim Comment are not read; protected-client complaints are counted through the DP-322 flag only, at counts of 10 or more; complainant identity is visible in the complaints drill only (CD-344, CW-225).",
            "The prior business day is complete by 7am ET on T+1, and a Rule 4530(d) quarter is locked when filed.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (complainant and account keys; restricted drill); a complaint that reveals a vulnerability is "
               "counted only through the DP-322 flag. "
               "Boundaries: complaints are 08 and service requests 13; the Rule 4530 definition decides (CW-070). Service "
               "interactions are DP-381's; voice-of-client surveys are 04 (CW-093), with scores in DP-405; remediation paid is "
               "DP-409's. DP-385 and DP-404 read this product's complaint counts. Supersedes DP-061; Consumer Duty outcome metrics "
               "left with CW-908. The candidate's DP-381 upstream carries the 13 reads; 04 Survey Response is read directly (DP-011 "
               "does not publish it). "
               "Tailoring lever: complaint scope (08 SME 4). Reference default: every written grievance plus oral grievances "
               "recorded and flagged by firm policy. "
               "Taxonomy gap: 04 Survey Response Complaint Referral has no referral status; the link to a logged complaint is "
               "tested by resolving the reference. "
               "Drafting assumptions: Complaint Status Closed; Complaint Outcome values; the 5-complaint recurrence threshold; the "
               "minimum cell of 10; the business-day-10 lock. "
               "Decisions: CW-070, CW-093, CW-225, CW-908. "
               "WP1 new (CW-220): supersedes DP-061; upstream of DP-404 (Q3); all seven candidate objects read, with 13 Service "
               "Request and 15 Program Enrollment added for the unlogged and offering measures."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-404": dict(
        definition=("Conduct risk indicators by business line, offering, office and advisor: recommendation and rollover evidence "
                    "gaps as DP-334 and DP-335 publish them, supervisory review exceptions, sales-practice alerts and overdue "
                    "corrective actions, open findings, complaint rates, protected-client counts, registration and CE lapses and "
                    "overdue communications filings. Rates are normalized by the households and client assets DP-008 publishes "
                    "at the advisor and business line slices. The CCO and the risk committee steer conduct risk and choose where "
                    "to impose heightened supervision. Every count is read from its owning product under the owner's measure "
                    "name; nothing is re-derived or re-scored. It owns no certified metric family."),
        business_questions=[
            "How many recommendations lacked best-interest evidence and how many rollovers lacked PTE 2020-02 documentation this quarter, by advisor, office and offering (from DP-334 and DP-335)?",
            "Which advisors and business lines have the highest alert and complaint rates per 1,000 households and per USD 1 billion of client assets?",
            "Where are supervisory review exceptions, open findings and overdue corrective actions concentrated?",
            "Which advisors are active without a registration, which are overdue on CE, and how many communications filings are overdue?",
            "Which advisors breach two or more indicator thresholds and are candidates for heightened supervision?",
        ],
        grain=("Indicator x business line x offering x office x advisor x month, each indicator a count or rate read from its "
               "owning product; rates normalized by DP-008 Households and Ending Client Assets only at the advisor and business "
               "line slices (DP-008 publishes no office or offering slice), other slices show counts only; monthly snapshots"),
        dimensions=["Advisor (DP-009)", "Office (DP-391)", "Business line", "Service offering (DP-004)", "Indicator and threshold band",
                    "Alert scenario (DP-400)", "Complaint category (DP-414)", "Finding severity (DP-402)", "Month (DP-013)"],
        measures=[
            ("Recommendations Without Best-Interest Evidence (from DP-334)", "DP-334's published count of Recommendations in File with Evidence Gap Flag = Y, read by Recommending Advisor, offering and month; the flag and its definition are DP-334's (CW-215, CW-224) and are never re-derived here.",
             _u("45", "Recommendation", "Recommendation ID", "Recommending Advisor", "Recommended Service Offering", "Recommendation Presented Timestamp")),
            ("Evidence Gap Rate % (from DP-334)", "DP-334's published Evidence Gap Rate % (Recommendations Without Best-Interest Evidence / Recommendations in File) by advisor and month, read as published.",
             _u("45", "Recommendation", "Recommendation ID", "Recommending Advisor") + ["Recommendations Without Best-Interest Evidence (from DP-334)"]),
            ("Rollovers Without PTE 2020-02 Documentation (from DP-335)", "DP-335's published count of Rollover Recommendations with PTE Documentation Gap Flag = Y, read by advisor of the Rollover Recommendation and month; never re-derived here.",
             _u("45", "Rollover Analysis", "Rollover Analysis ID", "Rollover Recommendation") + _u("45", "Recommendation", "Recommendation ID", "Recommending Advisor")),
            ("PTE Documentation Gap Rate % (from DP-335)", "DP-335's published PTE Documentation Gap Rate % (Rollovers Without PTE 2020-02 Documentation / Rollover Recommendations) by advisor and month.",
             _u("45", "Rollover Analysis", "Rollover Recommendation") + ["Rollovers Without PTE 2020-02 Documentation (from DP-335)"]),
            ("Review Exception Rate % (from DP-398)", "DP-398's published Review Exception Rate % by Supervised Representative and month.",
             _u("08", "Supervisory Review", "Supervisory Review ID", "Review Outcome", "Review Completed Date", "Supervised Representative")),
            ("Sales Practice Alerts per 1,000 Households (from DP-400)", "DP-400 Alerts Generated in the month by Alerted Representative / Households (from DP-008) of the same advisor x 1,000.",
             _u("08", "Sales Practice Alert", "Sales Practice Alert ID", "Alert Generated Date", "Alerted Representative") + ["Households (from DP-008)"]),
            ("Alerts Past Review Standard (from DP-400)", "DP-400's published Alerts Past Review Standard by Alerted Representative at the month end.",
             _u("08", "Sales Practice Alert", "Alert Disposition", "Alert Generated Date", "Alerted Representative")),
            ("Corrective Actions Overdue (from DP-400)", "DP-400's published Corrective Actions Overdue by Action Subject Representative at the month end.",
             _u("08", "Conduct Corrective Action", "Corrective Action ID", "Action Due Date", "Action Status", "Action Subject Representative")),
            ("Open Findings by Severity (from DP-402)", "DP-402's published Open Findings by Severity at the month end, by office of the Source Branch Inspection.",
             _u("08", "Supervisory Finding", "Supervisory Finding ID", "Finding Status", "Finding Severity", "Source Branch Inspection")),
            ("Complaints per 1,000 Households (from DP-414)", "DP-414 Complaints Received in the month by Associated Person Named / Households (from DP-008) of the same advisor x 1,000; by Complaint Office as a count only.",
             _u("08", "Complaint", "Complaint ID", "Received Date", "Associated Person Named", "Complaint Office") + ["Households (from DP-008)"]),
            ("Complaints per USD 1 Billion Client Assets (from DP-414)", "DP-414 Complaints Received in the month for the advisor or business line / Ending Client Assets (from DP-008) of the same slice x 1,000,000,000.",
             _u("08", "Complaint", "Complaint ID", "Received Date") + ["Ending Client Assets (from DP-008)"]),
            ("Clients Under Protection (from DP-322)", "Count of distinct client parties in the advisor's book with Protection Flag Present (from DP-322) = Y at the month end, joined on the 02 party key only; this replaces a senior investor case count, which stays inside DP-403's restricted view; published at counts of 10 or more.",
             _u("02", "Party", "Party ID") + _u("03", "Party Coverage Assignment", "Covered Party", "Covering Advisor", "Primary Coverage Indicator")),
            ("Active Advisors Without Registration (from DP-039)", "DP-039's published Active Advisors Without Registration at the month end, by advisor and office.",
             _u("08", "Individual Registration", "License ID", "Registered Person", "Registration Status") + _u("03", "Party Coverage Assignment", "Covering Advisor")),
            ("CE Overdue Count (from DP-039)", "DP-039's published CE Overdue Count at the month end, by CE Person.",
             _u("08", "CE Requirement", "CE Person", "CE Due Date", "CE Status")),
            ("Overdue Filings (from DP-036)", "DP-036's published Overdue Filings at the month end, with its FINRA Filing Timeliness % beside it.",
             _u("08", "FINRA Advertising Filing", "FINRA Filing Requirement", "Filing Due Date", "Filed Date")),
            ("Households (from DP-008)", "Measure Amount of the DP-008 Measure Value with Measure MSR-HOUSEHOLDS at the month end at Dimension Type Advisor or Business Line and its Dimension Key, from the Final or Restated Snapshot; read, never recomputed.",
             _mv("Snapshot") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Ending Client Assets (from DP-008)", "Measure Amount of MSR-CLIENTASSETS (Ending Client Assets) at the month end at Dimension Type Advisor or Business Line, from the same DP-008 snapshot.",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Advisors Breaching Two or More Indicators", "Count of advisors for whom at least two of Evidence Gap Rate % (from DP-334) above 5%, PTE Documentation Gap Rate % (from DP-335) above 5%, Sales Practice Alerts per 1,000 Households above 20, Complaints per 1,000 Households above 5, Alerts Past Review Standard above 3 and Corrective Actions Overdue above 0 hold in the month; a rules-based screen, not a model score.",
             ["Evidence Gap Rate % (from DP-334)", "PTE Documentation Gap Rate % (from DP-335)", "Sales Practice Alerts per 1,000 Households (from DP-400)",
              "Complaints per 1,000 Households (from DP-414)", "Alerts Past Review Standard (from DP-400)", "Corrective Actions Overdue (from DP-400)"]),
        ],
        inputs=[
            ("45", "Recommendation", ["Recommendation ID", "Recommending Advisor", "Recommended Service Offering", "Recommendation Presented Timestamp"]),
            ("45", "Rollover Analysis", ["Rollover Analysis ID", "Rollover Recommendation"]),
            ("08", "Supervisory Review", ["Supervisory Review ID", "Review Outcome", "Review Completed Date", "Supervised Representative"]),
            ("08", "Sales Practice Alert", ["Sales Practice Alert ID", "Alert Generated Date", "Alert Disposition", "Alerted Representative"]),
            ("08", "Complaint", ["Complaint ID", "Received Date", "Associated Person Named", "Complaint Office"]),
            ("08", "Supervisory Finding", ["Supervisory Finding ID", "Finding Status", "Finding Severity", "Source Branch Inspection"]),
            ("08", "Conduct Corrective Action", ["Corrective Action ID", "Action Due Date", "Action Status", "Action Subject Representative"]),
            ("08", "Individual Registration", ["License ID", "Registered Person", "Registration Status"]),
            ("08", "CE Requirement", ["CE Person", "CE Due Date", "CE Status"]),
            ("08", "FINRA Advertising Filing", ["FINRA Filing Requirement", "Filing Due Date", "Filed Date"]),
            ("02", "Party", ["Party ID"]),
            ("03", "Party Coverage Assignment", ["Covered Party", "Covering Advisor", "Primary Coverage Indicator"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
        ],
        upstream=["DP-334", "DP-335", "DP-398", "DP-400", "DP-402", "DP-414", "DP-039", "DP-036", "DP-322", "DP-303", "DP-009",
                  "DP-391", "DP-004", "DP-008", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, after the DP-008 Final snapshot and the month-end runs of the owning products",
        history="Monthly indicator snapshots kept seven years; thresholds versioned with the month they applied to",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Recommending Advisor, Supervised Representative, Alerted Representative, Action Subject Representative, Covering Advisor and CE Person resolves to a DP-009 advisor, every Complaint Office to a DP-391 office, every Recommended Service Offering to DP-004, and every Dimension Key of Dimension Type Advisor or Business Line to its DP-008 code.",
            "Each indicator has one threshold version in force per month, and a published month snapshot is never overwritten.",
            "Each '(from DP-nnn)' value equals the owner's published measure of the same name for the same advisor and month with no difference (DP-334, DP-335, DP-398, DP-400, DP-402, DP-414, DP-039, DP-036), and Households and Ending Client Assets equal the DP-008 Measure Amount for the same Measure, Dimension Key and Snapshot ID.",
            "Every indicator row has its numerator and month populated, and a normalized row has its DP-008 denominator populated; office and offering rows carry no rate.",
            "No row carries an 08 Senior Investor Case attribute or a 02 protection reason; every published Clients Under Protection (from DP-322) cell has a count of 10 or more; and advisor-level rows are returned only to the CCO, retail supervision and the advisor's principal roles.",
            "The month is published only after the DP-008 snapshot of the month is Final and each owning product has completed its month-end run, by business day 10.",
        ],
        notes=("Certified numbers: reads Households and Ending Client Assets from DP-008 as denominators at the advisor and "
               "business line slices (CW-011, CW-226); owns none. "
               "PII tier: identity (advisor-level indicators are employee performance data; no client-level rows). "
               "Boundaries: counts are read from the owning products under the owners' measure names and normalized by DP-008; "
               "nothing is re-derived (CW-224, program ruling at the C-2 fix pass). The evidence gaps are DP-334's Evidence Gap "
               "Flag and DP-335's PTE Documentation Gap Flag with their own denominators (Recommendations in File, Rollover "
               "Recommendations); this product keeps only the 45 join keys. Supervisory outcomes DP-398; alerts and corrective "
               "actions DP-400; findings DP-402; complaints DP-414; registrations and CE DP-039; filings DP-036. Senior investor "
               "cases are not counted here: the case is special category and stays in DP-403's restricted view, so the "
               "candidate's 08 Senior Investor Case input is dropped and replaced by the DP-322 flag count (CD-344, CW-225). "
               "DP-248 Enterprise Risk & Control View is to read this product (lineage item). "
               "Acceptance question 3: reads the answer of DP-334 and DP-335 (Recommendations Without Best-Interest Evidence, "
               "Rollovers Without PTE 2020-02 Documentation and their rates) and reports it by advisor, office and offering. "
               "Tailoring lever: indicator thresholds. Reference default: evidence gap rates above 5%, alerts above 20 and "
               "complaints above 5 per 1,000 households, more than 3 alerts past review standard, any overdue corrective action. "
               "Drafting assumptions: the thresholds above; the minimum cell of 10; Dimension Type values Advisor and Business "
               "Line. "
               "Decisions: CW-011, CW-066, CW-215, CW-224, CW-225, CW-226; CD-344. "
               "WP1 new (CW-224): Q3 reader of DP-334 and DP-335 (counts); feeds DP-248."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-405": dict(
        definition=("Contact volumes, speed of answer, handle time, abandonment, first-contact resolution, repeat contacts, "
                    "authentication outcomes and QA scores by channel, queue, contact reason and agent, against the service level "
                    "definitions, with transactional survey scores (NPS, satisfaction) on the interactions that triggered them. "
                    "Contact center managers staff queues and act on missed service levels. It owns no certified metric family."),
        business_questions=[
            "How many contacts did we handle by channel and queue today and this month, with what speed of answer, handle time and abandonment?",
            "Which service levels were missed, including the contractual ones, and in which queues?",
            "What share of contacts were resolved first time, and which contact reasons drive repeat contacts?",
            "How often does authentication fail at the first attempt or need step-up?",
            "What QA scores and transactional NPS do queues and agents achieve?",
        ],
        grain=("Assisted-service interaction (DP-381) x queue x day, with service level measurements (definition x measurement "
               "period), QA reviews and transactional survey responses as companion facts; daily aggregates and interaction "
               "detail"),
        dimensions=["Interaction channel and queue", "Contact reason", "Contact center agent (DP-192)", "Service level definition and scope",
                    "Authentication method and result", "Survey and survey trigger", "NPS category", "Account (DP-093)",
                    "Interaction date and hour (DP-013)"],
        measures=[
            ("Contacts Handled", "Count of Contact Center Interaction rows with Interaction Start Timestamp in the period, by Interaction Channel, Interaction Queue and Contact Reason.",
             _u("13", "Contact Center Interaction", "Interaction ID", "Interaction Start Timestamp", "Interaction Channel", "Interaction Queue", "Contact Reason")),
            ("Average Speed of Answer (Seconds)", "Mean Wait Time (Seconds) of Contacts Handled with Interaction Channel in Phone, Chat or Video, by Interaction Queue and hour.",
             _u("13", "Contact Center Interaction", "Wait Time (Seconds)", "Interaction Channel", "Interaction Queue") + ["Contacts Handled"]),
            ("Answered Within Target %", "Contacts Handled with Wait Time (Seconds) at or below the Target Value of the queue's Service Level Definition with Metric Name = Speed of Answer (30 seconds for phone by default) / Contacts Handled, by Interaction Queue.",
             _u("13", "Contact Center Interaction", "Wait Time (Seconds)", "Interaction Queue") + _u("13", "Service Level Definition", "SLA ID", "Metric Name", "Target Value", "SLA Scope")
             + ["Contacts Handled"]),
            ("Abandonment Rate %", "Actual Value of the Service Level Measurement whose Service Level Definition has Metric Name = Abandonment Rate, by SLA Scope (queue) and Measurement Period.",
             _u("13", "Service Level Measurement", "Measurement Period", "Actual Value") + _u("13", "Service Level Definition", "Metric Name", "SLA Scope")),
            ("Average Handle Time (Seconds) (from DP-381)", "DP-381's published Average Handle Time (Seconds), shown by Interaction Queue, Contact Reason and Interaction Agent.",
             _u("13", "Contact Center Interaction", "Handle Time (Seconds)", "Interaction Queue", "Contact Reason", "Interaction Agent") + ["Contacts Handled"]),
            ("First Contact Resolution Rate % (from DP-381)", "DP-381's published First Contact Resolution Rate %, shown by Contact Reason.",
             _u("13", "Contact Center Interaction", "First Contact Resolution Indicator", "Contact Reason") + ["Contacts Handled"]),
            ("Repeat Contacts Within 7 Days %", "Contacts Handled with an earlier interaction of the same Interaction Account and Contact Reason in the 7 days before / Contacts Handled, by Contact Reason.",
             _u("13", "Contact Center Interaction", "Interaction Account", "Contact Reason", "Interaction Start Timestamp") + ["Contacts Handled"]),
            ("Authentication Failure Rate % (from DP-381)", "DP-381's published Authentication Failure Rate % (failed attempts / attempts) by Interaction Channel, with the share of attempts with Step-Up Required Indicator = Y beside it.",
             _u("13", "Interaction Authentication", "Authenticated Interaction", "Authentication Attempt Number", "Authentication Result", "Step-Up Required Indicator")
             + _u("13", "Contact Center Interaction", "Interaction Channel")),
            ("QA Pass Rate % (from DP-381)", "DP-381's published QA Pass Rate % with the mean QA Score, shown by Interaction Agent and Interaction Queue of the reviewed interactions.",
             _u("13", "QA Review", "Reviewed Item", "QA Score", "QA Outcome") + _u("13", "Contact Center Interaction", "Interaction Agent", "Interaction Queue")),
            ("Service Levels Missed", "Count of Service Level Measurement rows in the period with SLA Met Indicator = N, by Service Level Definition (Metric Name, SLA Scope) and split by Contractual SLA Indicator.",
             _u("13", "Service Level Measurement", "Measurement Period", "SLA Met Indicator") + _u("13", "Service Level Definition", "SLA ID", "Metric Name", "SLA Scope", "Contractual SLA Indicator")),
            ("Service Level Attainment Gap", "Actual Value - Target Value of each Service Level Measurement in the period, in the Metric Unit of its definition, by SLA Scope.",
             _u("13", "Service Level Measurement", "Actual Value") + _u("13", "Service Level Definition", "Target Value", "Metric Unit", "SLA Scope")),
            ("Transactional NPS", "Share of Survey Responses with NPS Category = Promoter - share with NPS Category = Detractor, over responses whose Triggering Interaction is an interaction in the period and whose Response Survey has Survey Type = Transactional, by Interaction Queue.",
             _u("04", "Survey Response", "Response ID", "Response Survey", "Response Timestamp", "NPS Category", "Triggering Interaction")
             + _u("04", "Client Survey", "Survey ID", "Survey Type") + _u("13", "Contact Center Interaction", "Interaction Queue")),
            ("Average Satisfaction Score", "Mean Response Score of transactional survey responses triggered by interactions in the period, by Survey Trigger and Interaction Channel.",
             _u("04", "Survey Response", "Response Score", "Triggering Interaction") + _u("04", "Client Survey", "Survey Trigger")
             + _u("13", "Contact Center Interaction", "Interaction Channel")),
            ("Contacts per 1,000 Accounts", "Contacts Handled / distinct DP-093 accounts open at the period end x 1,000, by Contact Reason.",
             _u("15", "Account", "Account ID", "Account Status") + ["Contacts Handled"]),
            ("Digital Self-Service Events", "Count of 04 Engagement Event rows in the period with Engagement Event Type = Self-Service Completed, by Digital Feature Used: the deflection shown beside Contacts per 1,000 Accounts (DP-011).",
             _u("04", "Engagement Event", "Event Timestamp", "Engagement Event Type", "Digital Feature Used")),
        ],
        inputs=[
            ("13", "Contact Center Interaction", ["Interaction ID", "Interaction Channel", "Interaction Account", "Interaction Agent",
                                                  "Interaction Queue", "Interaction Start Timestamp", "Wait Time (Seconds)",
                                                  "Handle Time (Seconds)", "Contact Reason", "First Contact Resolution Indicator",
                                                  "Linked Service Request"]),
            ("13", "Interaction Authentication", ["Authenticated Interaction", "Authentication Attempt Number", "Authentication Result",
                                                  "Step-Up Required Indicator"]),
            ("13", "QA Review", ["Reviewed Item", "QA Score", "QA Outcome"]),
            ("13", "Service Level Definition", ["SLA ID", "Metric Name", "SLA Scope", "Target Value", "Metric Unit", "Contractual SLA Indicator"]),
            ("13", "Service Level Measurement", ["Measurement Period", "Actual Value", "SLA Met Indicator"]),
            ("04", "Client Survey", ["Survey ID", "Survey Name", "Survey Type", "Survey Trigger"]),
            ("04", "Survey Response", ["Response ID", "Response Survey", "Response Timestamp", "Response Score", "NPS Category", "Triggering Interaction"]),
            ("04", "Engagement Event", ["Event Timestamp", "Engagement Event Type", "Digital Feature Used"]),
            ("15", "Account", ["Account ID", "Account Status"]),
        ],
        upstream=["DP-381", "DP-192", "DP-011", "DP-093", "DP-013"],
        refresh="Intraday",
        timeliness="Queue statistics every 15 minutes during service hours; the day complete by 6am ET on T+1; service level measurements by business day 2 after each measurement period",
        history="Interaction-level facts from DP-381; daily queue aggregates and service level measurements kept seven years; survey responses kept with the interaction",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Interaction Agent resolves to a DP-192 employee, every Interaction Account to a DP-093 Account ID, every Triggering Interaction and Reviewed Item to a DP-381 interaction, and every Response Survey to a Survey ID.",
            "Service Level Measurement periods of one definition do not overlap, and every interaction's Authentication Attempt Number sequence starts at 1.",
            "Contacts Handled per day and channel equals DP-381 Assisted Interactions for the same day and channel with no difference, and SLA Met Indicator agrees with Actual Value against Target Value for every measurement.",
            "Interaction Channel, Interaction Queue, Interaction Start Timestamp, Wait Time (Seconds) and Handle Time (Seconds) are populated on every interaction, and Target Value and Metric Unit on every service level definition.",
            "Survey Verbatim Comment, Recording Reference and interaction notes are not read; agent-level views go to contact center managers only, and client keys stay in the interaction drill.",
            "Intraday queue statistics are no more than 15 minutes old during service hours, and the day is complete by 6am ET on T+1.",
        ],
        notes=("Plan section 8.3 example (Contact Center Operations). "
               "Certified numbers: none read or owned. "
               "PII tier: identity (client keys and agent ids; aggregates for leadership). Survey verbatims, which can be special "
               "category, are not read (CW-225). "
               "Boundaries: the service fact is DP-381 (CW-222), and its contact measures (Average Handle Time (Seconds), First "
               "Contact Resolution Rate %, Authentication Failure Rate %, QA Pass Rate %) are read from it under its names (facts "
               "owned once; renamed from this product's first draft names, no reader yet); complaints are DP-414; voice of client surveys are 04 (CW-093) and "
               "this product takes the transactional survey scores of backlog DP-397 Voice of Client: Surveys & NPS and the scope "
               "of backlog DP-406 Service Request Fulfillment; relationship NPS by advisor stays with DP-397 when it is picked up. "
               "Outsourced-TA oversight is 29's (CW-088). Cost per contact is DP-498's (CW-157). Supersedes the service-level part "
               "of DP-043; re-point target of live DP-169 and DP-176 with DP-409. "
               "Tailoring lever: one service request master (13 SME 1). Reference default: yes, so contacts for brokerage, "
               "fund-only and participant accounts are in one queue set. "
               "Tailoring lever: outsourced contact center. Reference default: in house; outsourced, the same grain is received "
               "from the provider and the contractual SLAs are the oversight form. "
               "Taxonomy gap: 13 Contact Center Interaction has no abandoned indicator or outcome; abandonment is read from the "
               "13 Service Level Measurement of the Abandonment Rate definition. "
               "Taxonomy gap: 04 Engagement Event has no contact reason, so digital deflection cannot be matched to a contact "
               "reason; it is shown by Digital Feature Used. "
               "Drafting assumptions: the 30-second phone target; Authentication Result Passed; QA Outcome values; Survey Type "
               "Transactional; Engagement Event Type Self-Service Completed; the 7-day repeat window. "
               "Decisions: CW-086, CW-088, CW-093, CW-157, CW-222. "
               "WP1 new (CW-222): plan section 8.3 example; also reads 04 Client Survey (moved from backlog DP-397); all five "
               "candidate objects read."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-408": dict(
        definition=("Own-fund shareholder meetings (votes against quorum by channel and voting intermediary, adjournments) and, for "
                    "brokerage clients, third-party issuer proxy pass-through (materials delivered, voting instructions received "
                    "and transmitted, OBO and NOBO elections), with own-fund voting choice elections. Record-date entitlements are "
                    "checked against the books: Client Holding (49) through DP-300 and the 29 share register through DP-580, "
                    "never 06. Client communications and fund legal steer solicitation to quorum and evidence pass-through. It "
                    "owns no certified metric family."),
        business_questions=[
            "Which own-fund meetings are below quorum within 10 days of the meeting date, and which were adjourned?",
            "What share of outstanding shares has voted on each proposal, through which intermediaries, and how many broker non-votes are there?",
            "Were brokerage clients' issuer proxy materials delivered and their voting instructions transmitted on time?",
            "Do pass-through entitlements and own-fund record-date shares agree with the client holdings and the share register on the record date?",
            "How many accounts hold NOBO elections and voting choice elections, by fund and voting policy?",
        ],
        grain=("Proxy proposal x tally as-of date for own-fund campaigns; issuer meeting x brokerage account for pass-through; "
               "account x fund x effective period for voting choice and account x effective period for OBO / NOBO elections; "
               "immutable tallies and instructions"),
        dimensions=["Proxy campaign, meeting type and registrant / fund (DP-004)", "Proxy proposal type and vote standard",
                    "Voting intermediary", "Issuer meeting and corporate action event (DP-099)", "Pass-through delivery method",
                    "Voting instruction status", "Beneficial owner disclosure status", "Voting choice fund and chosen voting policy",
                    "Account (DP-093)", "Record date and meeting date (DP-013)"],
        measures=[
            ("Active Proxy Campaigns", "Count of Proxy Campaign rows with Meeting Status in Scheduled, Soliciting or Adjourned at the as-of date, by Meeting Type.",
             _u("13", "Proxy Campaign", "Proxy Campaign ID", "Meeting Status", "Meeting Type")),
            ("Percent of Outstanding Voted", "Percent of Outstanding Voted of the latest Vote Tally (Tally As-Of Date) of each proxy proposal, with Shares Voted For and Shares Voted Against.",
             _u("13", "Vote Tally", "Tally As-Of Date", "Percent of Outstanding Voted", "Shares Voted For", "Shares Voted Against")
             + _u("13", "Proxy Proposal", "Proposal ID")),
            ("Campaigns Below Quorum Near Meeting", "Count of Active Proxy Campaigns with Meeting Date within 10 calendar days whose latest tally has Quorum Achieved Indicator not Y, with the shares still needed (Quorum Requirement x Shares Outstanding at Record Date - shares voted).",
             _u("13", "Proxy Campaign", "Meeting Date", "Quorum Requirement", "Shares Outstanding at Record Date")
             + _u("13", "Vote Tally", "Quorum Achieved Indicator", "Shares Voted For", "Shares Voted Against") + ["Active Proxy Campaigns"]),
            ("Adjourned Meetings", "Count of Proxy Campaign rows with Adjourned To Date populated in the period, by Solicitation Agent.",
             _u("13", "Proxy Campaign", "Adjourned To Date", "Solicitation Agent")),
            ("Proposal Pass Rate %", "Proxy Proposal rows with Proposal Outcome = Passed / proposals decided in the period, by Proposal Type and Vote Standard.",
             _u("13", "Proxy Proposal", "Proposal Outcome", "Proposal Type", "Vote Standard")),
            ("Broker Non-Vote Share %", "Broker Non-Votes / (Shares Voted For + Shares Voted Against + Broker Non-Votes) of the latest tally per proposal, with Mirror / Echo Voted Shares shown beside it.",
             _u("13", "Vote Tally", "Broker Non-Votes", "Shares Voted For", "Shares Voted Against", "Mirror / Echo Voted Shares")),
            ("Intermediary Instructions Received", "Sum of Shares Instructed and Instructions Received Count of Intermediary Vote Instruction rows by Voting Intermediary for each proposal, with the share where Broker Discretionary Vote Permitted Indicator = Y.",
             _u("13", "Intermediary Vote Instruction", "Voting Intermediary", "Instructions Received Count", "Shares Instructed", "Broker Discretionary Vote Permitted Indicator")),
            ("Pass-Through Materials Delivered On Time %", "Issuer Proxy Pass-Through rows with Materials Delivered Date at least 15 calendar days before the Meeting Date of the Issuer Meeting's 17 Corporate Action Event / pass-through rows of meetings in the period, by Pass-Through Delivery Method.",
             _u("13", "Issuer Proxy Pass-Through", "Issuer Meeting", "Pass-Through Account", "Materials Delivered Date", "Pass-Through Delivery Method")
             + _u("17", "Corporate Action Event", "Corporate Action Event ID", "Meeting Date")),
            ("Pass-Through Instructions Transmitted Late", "Count of pass-through rows with Voting Instruction Status = Received whose Voting Instruction Transmitted Timestamp is empty or more than 1 business day after Voting Instruction Received Timestamp, or after the Meeting Date.",
             _u("13", "Issuer Proxy Pass-Through", "Voting Instruction Status", "Voting Instruction Received Timestamp", "Voting Instruction Transmitted Timestamp")
             + _u("17", "Corporate Action Event", "Meeting Date")),
            ("Pass-Through Entitlement Breaks", "Count of pass-through rows whose Record Date Entitled Quantity differs from the Settled Quantity of the 49 Client Holding of the Pass-Through Account in the Event Instrument on the Record Date of the 17 Corporate Action Event (Client Holding Date = Record Date, DP-300).",
             _u("13", "Issuer Proxy Pass-Through", "Record Date Entitled Quantity", "Pass-Through Account", "Issuer Meeting")
             + _u("17", "Corporate Action Event", "Event Instrument", "Record Date")
             + _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Settled Quantity")),
            ("Own-Fund Record Date Share Breaks", "For each own-fund campaign, Shares Outstanding at Record Date - the sum of Registered Shares of the 29 Share Register Balance of the fund's share classes on the Record Date (Register Business Date, DP-580), where the difference exceeds 0.01%.",
             _u("13", "Proxy Campaign", "Shares Outstanding at Record Date", "Record Date", "Registrant / Fund")
             + _u("29", "Share Register Balance", "Register Account", "Register Share Class", "Register Business Date", "Registered Shares")),
            ("NOBO Election Rate %", "Brokerage accounts with a Beneficial Owner Disclosure Election in force with Beneficial Owner Disclosure Status = NOBO / accounts with an election in force, with the share where Disclosure Default Applied Indicator = Y.",
             _u("13", "Beneficial Owner Disclosure Election", "Disclosure Election Account", "Beneficial Owner Disclosure Status", "Disclosure Election Effective From",
                "Disclosure Election Effective To", "Disclosure Default Applied Indicator")),
            ("Active Voting Choice Elections", "Count of Voting Choice Election rows in force at the as-of date (Voting Choice Effective From on or before it, Voting Choice Effective To empty or after it), by Voting Choice Fund and Chosen Voting Policy, with the share where Voting Choice Default Applied Indicator = Y.",
             _u("13", "Voting Choice Election", "Voting Choice Election ID", "Voting Choice Account", "Voting Choice Fund", "Chosen Voting Policy",
                "Voting Choice Effective From", "Voting Choice Effective To", "Voting Choice Default Applied Indicator")),
            ("Voting Choice Coverage %", "Accounts with Active Voting Choice Elections in a fund / accounts holding the fund on the as-of date (49 Client Holding through DP-300 for brokerage accounts, 29 Share Register Balance through DP-580 for registered accounts).",
             _u("13", "Voting Choice Election", "Voting Choice Account", "Voting Choice Fund") + _u("49", "Client Holding", "Holding Account", "Held Instrument")
             + _u("29", "Share Register Balance", "Register Account", "Register Share Class") + ["Active Voting Choice Elections"]),
        ],
        inputs=[
            ("13", "Proxy Campaign", ["Proxy Campaign ID", "Meeting Type", "Registrant / Fund", "Record Date", "Meeting Date", "Proxy Mailing Date",
                                      "Solicitation Agent", "Shares Outstanding at Record Date", "Quorum Requirement", "Meeting Status",
                                      "Adjourned To Date"]),
            ("13", "Proxy Proposal", ["Proposal ID", "Proposal Type", "Vote Standard", "Proposal Outcome"]),
            ("13", "Vote Tally", ["Tally As-Of Date", "Shares Voted For", "Shares Voted Against", "Broker Non-Votes", "Percent of Outstanding Voted",
                                  "Quorum Achieved Indicator", "Mirror / Echo Voted Shares"]),
            ("13", "Intermediary Vote Instruction", ["Voting Intermediary", "Instructions Received Count", "Shares Instructed",
                                                     "Broker Discretionary Vote Permitted Indicator"]),
            ("13", "Issuer Proxy Pass-Through", ["Issuer Meeting", "Pass-Through Account", "Record Date Entitled Quantity", "Pass-Through Delivery Method",
                                                 "Materials Delivered Date", "Voting Instruction Status", "Voting Instruction Received Timestamp",
                                                 "Voting Instruction Transmitted Timestamp", "Broker Discretionary Vote Permitted Indicator"]),
            ("13", "Beneficial Owner Disclosure Election", ["Disclosure Election Account", "Beneficial Owner Disclosure Status",
                                                            "Disclosure Election Effective From", "Disclosure Election Effective To",
                                                            "Disclosure Default Applied Indicator"]),
            ("13", "Voting Choice Election", ["Voting Choice Election ID", "Voting Choice Account", "Voting Choice Fund", "Chosen Voting Policy",
                                              "Voting Choice Effective From", "Voting Choice Effective To", "Voting Choice Default Applied Indicator"]),
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Event Instrument", "Corporate Action Event Type", "Record Date", "Meeting Date"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Settled Quantity"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date", "Registered Shares"]),
        ],
        upstream=["DP-382", "DP-580", "DP-300", "DP-099", "DP-093", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; tallies of campaigns within 10 days of the meeting refreshed intraday as the solicitation agent reports",
        history="Tallies, instructions and pass-through rows immutable; elections SCD type 2; kept six years (SEC Rule 17a-4; Investment Company Act proxy records)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Pass-Through Account, Disclosure Election Account and Voting Choice Account resolves to a DP-093 Account ID, every Registrant / Fund and Voting Choice Fund to DP-004, every Issuer Meeting to a DP-099 Corporate Action Event ID, and every Proposal to its Proxy Campaign.",
            "OBO / NOBO and voting choice election periods do not overlap for the same account (and fund), and Tally As-Of Date values of a proposal are on or before its Meeting Date or Adjourned To Date.",
            "Record Date Entitled Quantity equals the DP-300 settled Client Holding quantity on the record date for every pass-through row, and Shares Outstanding at Record Date ties to the DP-580 register total within 0.01%; breaks are reported, never corrected here.",
            "Record Date, Meeting Date, Shares Outstanding at Record Date and Quorum Requirement are populated on every campaign, and Voting Instruction Status on every pass-through row.",
            "Account keys are published to client communications and fund legal only; shareholder names and addresses are not read, and other views carry counts and shares by campaign, intermediary and fund.",
            "The prior day is complete by 7am ET on T+1, and a campaign's tallies are locked when Meeting Status becomes Closed.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: financial (account keys with record-date entitlements). "
               "Boundaries: pass-through and elections are 13 (CW-082, CW-090); the record-date position is a derived copy of 49 "
               "Client Holding (DP-300) or the 29 register (DP-580), never 06 (CW-007); the issuer meeting is the 17 corporate "
               "action event (DP-099). Own funds' portfolio votes are 34. NOBO list and beneficial owner distribution requests to "
               "intermediaries are DP-585 (FOP); intermediary distribution requests left 13 (CW-088). Absorbs backlog DP-541 "
               "(investor choice proxy voting program). Supersedes DP-071 (plan section 15 ruling 7). "
               "Tailoring lever: voting choice offered (13 SME 3). Reference default: offered for selected own funds. "
               "Tailoring lever: issuer pass-through processing (13 SME 4). Reference default: an agent processes pass-through "
               "and reports instructions back. "
               "Tailoring lever: proxy solicitation agent (13 SME 9). Reference default: one agent per campaign. "
               "Taxonomy gap: 13 Intermediary Vote Instruction and Vote Tally carry no key to their Proxy Proposal in the attribute "
               "list (only the grain names it); the proposal is taken from the row key. "
               "Drafting assumptions: Meeting Status values Scheduled, Soliciting, Adjourned and Closed; Proposal Outcome Passed; "
               "Beneficial Owner Disclosure Status NOBO; Voting Instruction Status Received; the 15-day materials standard, "
               "1-business-day transmission standard, 10-day quorum window and 0.01% tolerance. "
               "Decisions: CW-007, CW-082, CW-088, CW-090, CW-913. "
               "WP1 new (CW-220): supersedes DP-071; absorbs backlog DP-541; all nine candidate objects read, with 17 Corporate "
               "Action Event added for the issuer meeting dates."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-409": dict(
        definition=("Every servicing and processing error affecting clients, with its root cause, accounts affected and "
                    "financial impact, the remediation owed and paid to each account and its timeliness, the payment that "
                    "settled it and the operational incident raised for it. Client service and risk see recurring errors and "
                    "remediation still owed. It owns no certified metric family."),
        business_questions=[
            "How many servicing errors occurred this month by type and root cause, how many were material, and how many accounts did they affect?",
            "What remediation is owed and unpaid, for how long, and which remediation payments have not settled?",
            "How long does it take from an error to paying the clients it affected?",
            "Which errors have fewer remediated accounts than accounts impacted?",
            "Which root causes recur, and which errors were raised as operational incidents?",
        ],
        grain=("Servicing error x remediated account (13 Shareholder Remediation), with the servicing error as parent and the "
               "remediation money movement and operational incident link as companion facts; immutable events with payment status"),
        dimensions=["Servicing error type", "Root cause category", "Responsible party", "Affected business line", "Remediation type",
                    "Cost borne by", "Account (DP-093)", "Operational incident and severity (DP-215)", "Error occurrence date (DP-013)"],
        measures=[
            ("Servicing Errors", "Count of Servicing Error rows with Error Occurrence Date in the period, by Servicing Error Type, Root Cause Category and Affected Business Line.",
             _u("13", "Servicing Error", "Servicing Error ID", "Error Occurrence Date", "Servicing Error Type", "Root Cause Category", "Affected Business Line")),
            ("Material Servicing Errors", "Count of Servicing Errors with Materiality Threshold Exceeded Indicator = Y, by Servicing Error Type, with those linked to a NAV error (Related NAV Error Case populated, remediated under DP-169).",
             _u("13", "Servicing Error", "Materiality Threshold Exceeded Indicator", "Related NAV Error Case", "Servicing Error Type") + ["Servicing Errors"]),
            ("Accounts Impacted", "Sum of Accounts Impacted Count of Servicing Errors in the period, by Servicing Error Type.",
             _u("13", "Servicing Error", "Accounts Impacted Count", "Servicing Error Type")),
            ("Total Financial Impact", "Sum of Total Financial Impact of Servicing Errors in the period (USD), by Responsible Party and Root Cause Category.",
             _u("13", "Servicing Error", "Total Financial Impact", "Responsible Party", "Root Cause Category")),
            ("Remediation Owed Unpaid", "Count and sum of Compensation Amount of Shareholder Remediation rows with Compensation Paid Date empty at the as-of date, by Remediation Type.",
             _u("13", "Shareholder Remediation", "Remediation ID", "Remediated Account", "Compensation Amount", "Compensation Paid Date", "Remediation Type")),
            ("Remediation Paid", "Sum of Compensation Amount of Shareholder Remediation rows with Compensation Paid Date in the period, by Cost Borne By.",
             _u("13", "Shareholder Remediation", "Compensation Amount", "Compensation Paid Date", "Cost Borne By")),
            ("Remediation Cycle Time (Days)", "Median calendar days from the Error Occurrence Date of the servicing error to Compensation Paid Date of its remediations paid in the period, by Servicing Error Type.",
             _u("13", "Servicing Error", "Error Occurrence Date", "Servicing Error Type") + _u("13", "Shareholder Remediation", "Compensation Paid Date")),
            ("Remediation Unpaid Past 30 Days", "Count of unpaid Shareholder Remediation rows whose servicing error's Error Occurrence Date is more than 30 days before the as-of date.",
             _u("13", "Shareholder Remediation", "Compensation Paid Date") + _u("13", "Servicing Error", "Error Occurrence Date") + ["Remediation Owed Unpaid"]),
            ("Errors With Incomplete Remediation", "Count of Servicing Errors whose count of distinct Remediated Account is below Accounts Impacted Count, where remediation is owed (Total Financial Impact above zero).",
             _u("13", "Shareholder Remediation", "Remediated Account") + _u("13", "Servicing Error", "Accounts Impacted Count", "Total Financial Impact")),
            ("Remediation Payments Not Settled", "Count of paid remediations whose Remediation Money Movement resolves to a 50 Money Movement with Money Movement Status not Settled more than 3 business days after Compensation Paid Date (DP-302).",
             _u("13", "Shareholder Remediation", "Remediation Money Movement", "Compensation Paid Date")
             + _u("50", "Money Movement", "Money Movement ID", "Money Movement Status", "Movement Amount", "Value Date")),
            ("Errors Raised as Operational Incidents %", "Material Servicing Errors named as Source Servicing Error by a 37 Incident Source Record of an Operational Incident (DP-215) / Material Servicing Errors, with the Incident Severity mix.",
             _u("37", "Incident Source Record", "Source Incident", "Incident Source Type", "Source Servicing Error")
             + _u("37", "Operational Incident", "Operational Incident ID", "Incident Severity", "Incident Status") + ["Material Servicing Errors"]),
            ("Recurring Root Causes", "Count of Root Cause Category values with 3 or more Servicing Errors in the trailing quarter, with their Total Financial Impact.",
             _u("13", "Servicing Error", "Root Cause Category", "Error Occurrence Date", "Total Financial Impact")),
            ("Firm-Borne Remediation Cost", "Sum of Compensation Amount of remediations paid in the period with Cost Borne By = Firm, beside those borne by a fund or a provider.",
             _u("13", "Shareholder Remediation", "Compensation Amount", "Cost Borne By", "Compensation Paid Date")),
        ],
        inputs=[
            ("13", "Servicing Error", ["Servicing Error ID", "Servicing Error Type", "Error Occurrence Date", "Responsible Party", "Root Cause Category",
                                       "Related NAV Error Case", "Materiality Threshold Exceeded Indicator", "Affected Business Line",
                                       "Accounts Impacted Count", "Total Financial Impact", "Correction Transactions"]),
            ("13", "Shareholder Remediation", ["Remediation ID", "Remediated Account", "Remediation Type", "Compensation Amount",
                                               "Compensation Paid Date", "Remediation Money Movement", "Cost Borne By"]),
            ("50", "Money Movement", ["Money Movement ID", "Money Movement Status", "Movement Amount", "Value Date"]),
            ("37", "Incident Source Record", ["Source Incident", "Incident Source Type", "Source Servicing Error"]),
            ("37", "Operational Incident", ["Operational Incident ID", "Incident Severity", "Incident Status", "Incident Discovery Date"]),
        ],
        upstream=["DP-381", "DP-093", "DP-302", "DP-215", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for errors, remediations and payments recorded the prior business day",
        history="Errors and remediations kept as immutable facts with payment status history; kept six years (SEC Rule 17a-4; Rule 17Ad-10 for TA-registered accounts)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Remediated Account resolves to a DP-093 Account ID, every Remediation Money Movement to a DP-302 Money Movement ID, every Related NAV Error Case to a 27 NAV error case and every Source Servicing Error of a 37 Incident Source Record to a Servicing Error ID of this product.",
            "Compensation Paid Date is empty or on or after the Error Occurrence Date of its error, and each Remediated Account appears once per servicing error.",
            "The sum of Compensation Amount of an error's remediations is within 1% of its Total Financial Impact once remediation is complete, and every paid remediation's Movement Amount equals its Compensation Amount to the cent.",
            "Servicing Error Type, Error Occurrence Date, Root Cause Category, Accounts Impacted Count and Total Financial Impact are populated on every error, and Compensation Amount and Remediation Type on every remediation.",
            "Account keys and amounts are published to client service and operational risk only; other views carry counts and amounts by error type and root cause.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: financial (account keys with remediation amounts). "
               "Boundaries: supersedes the error and remediation part of DP-043; with DP-405 it is the re-point target of live "
               "DP-169 and DP-176. NAV-error remediation stays DP-169; the operational incident is 37 (DP-215), linked through the "
               "37 Incident Source Record, which is the only link between a servicing error and its incident. Remediation payments "
               "are 50 (DP-302, CW-107). DP-381 publishes the service requests behind each error. DP-215 must not list this "
               "product upstream while this product reads it. "
               "Tailoring lever: remediation materiality threshold. Reference default: the firm threshold on 13 Materiality "
               "Threshold Exceeded Indicator (USD 25 per account for de minimis). "
               "Taxonomy gap: 13 Servicing Error has no discovery date, status or link to its operational incident; the incident "
               "link is read from 37 Incident Source Record and cycle time starts at Error Occurrence Date. "
               "Drafting assumptions: Money Movement Status Settled; Cost Borne By values Firm, Fund and Provider; the 30-day and "
               "3-business-day thresholds; the 1% tie-out. "
               "Decisions: CW-088, CW-107, CW-913. "
               "WP1 new (CW-220): re-point target of DP-169 and DP-176; all three candidate objects read, with the 37 incident link "
               "objects added."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-410": dict(
        definition=("Cost, reach, response, leads and funnel milestones for every campaign node (program, campaign, wave, tactic, "
                    "including client events and webinars) under the primary and alternative 04 attribution models, with budgets, "
                    "spend lines, paid media delivery, tracked URLs, social posts and the content featured, and net new assets by "
                    "campaign read from DP-008 beside spend. Marketing reallocates spend between campaigns and channels. It "
                    "computes no net new assets; acquisition cost and lifetime value are DP-498's. It owns no certified metric "
                    "family."),
        business_questions=[
            "What did each campaign spend against budget this quarter, by spend category and paid media channel?",
            "How many members responded, how many leads, applications and funded accounts are attributed to each campaign under the primary model and under the alternatives?",
            "What did each funded account cost by campaign, and what net new assets did the campaign bring (from DP-008)?",
            "How did client events and webinars perform on registration and attendance, and at what cost per attendee?",
            "Which social posts went out without a compliance review, which social accounts are not archived, and which campaign tactics carry no tracking code?",
        ],
        grain=("Campaign node x attribution model x month, with spend lines, media placements and deliveries, members, touchpoints, "
               "attributed outcomes, events and registrations, social posts and campaign products as companion facts; monthly "
               "snapshots with campaign hierarchy as SCD type 2"),
        dimensions=["Campaign hierarchy (program, campaign, wave, tactic; DP-011)", "Campaign type and business line", "Marketing theme",
                    "Attribution model and primary indicator", "Outcome type", "Spend category and paid media channel",
                    "Marketing event type and attendance mode", "Campaign product or share class (DP-004)", "Social platform",
                    "Content type and audience restriction", "Month (DP-013)"],
        measures=[
            ("Campaign Spend", "Actual Cost of the Campaign Budget of each campaign node, rolled up the Parent Campaign hierarchy, in Budget Currency, with Budgeted Cost and the Actual Cost / Budgeted Cost %.",
             _u("04", "Campaign Budget", "Budgeted Cost", "Actual Cost", "Budget Currency") + _u("04", "Campaign", "Campaign ID", "Parent Campaign", "Campaign Level")),
            ("Campaigns Over Budget", "Count of campaign nodes with Campaign Status Active or Completed whose Actual Cost exceeds Budgeted Cost by more than 10%.",
             _u("04", "Campaign", "Campaign Status") + _u("04", "Campaign Budget", "Actual Cost", "Budgeted Cost")),
            ("Spend by Category", "Sum of Spend Amount of Spend Line rows by Spend Category for each campaign node and month.",
             _u("04", "Spend Line", "Spend Category", "Spend Amount")),
            ("Paid Media Cost per Thousand Impressions", "Sum of Actual Spend / sum of Impressions x 1,000 over Paid Media Delivery rows of the Media Placements of the campaign (Placement Campaign), by Paid Media Channel, with Planned Placement Spend beside it.",
             _u("04", "Paid Media Delivery", "Impressions", "Actual Spend") + _u("04", "Media Placement", "Placement ID", "Placement Campaign", "Paid Media Channel", "Planned Placement Spend")),
            ("Campaign Response Rate %", "Campaign Member rows with Responded Indicator = Y / Campaign Member rows, by campaign node and Member Status.",
             _u("04", "Campaign Member", "Member Party", "Member Lead", "Member Status", "Responded Indicator")),
            ("Attributed Outcomes (Primary Model)", "Sum of Attribution Weight of Attributed Outcome rows whose Applied Attribution Model has Primary Model Indicator = Y, by Attributed Campaign and Outcome Type (lead, application, account opened, account funded).",
             _u("04", "Attributed Outcome", "Outcome Type", "Attributed Milestone", "Attributed Campaign", "Applied Attribution Model", "Attribution Weight")
             + _u("04", "Attribution Model", "Attribution Model ID", "Primary Model Indicator")),
            ("Attributed Outcomes by Alternative Model", "Sum of Attribution Weight of Attributed Outcome rows per Attribution Model Type and Lookback Window for models with Primary Model Indicator not Y, beside the primary result, by Attributed Campaign.",
             _u("04", "Attributed Outcome", "Attribution Weight", "Attributed Campaign", "Applied Attribution Model")
             + _u("04", "Attribution Model", "Attribution Model Type", "Lookback Window", "Primary Model Indicator")),
            ("Cost per Funded Account", "Campaign Spend / Attributed Outcomes (Primary Model) with Outcome Type = Account Funded for the campaign node; acquisition cost per funded household by channel is DP-498's.",
             _u("04", "Attributed Outcome", "Outcome Type") + _u("04", "Acquisition Milestone", "Milestone Type", "Milestone Account")
             + ["Campaign Spend", "Attributed Outcomes (Primary Model)"]),
            ("Net New Assets by Campaign (from DP-008)", "Measure Amount of the DP-008 Measure Value with Measure MSR-NNA, Dimension Type Campaign and Dimension Key = the Campaign ID, over the months of the period, from the Final or Restated Snapshot; shown beside spend and never recomputed or re-weighted (the value DP-492 publishes).",
             _mv("Snapshot") + _u("06", "Client Asset Measures", "Net New Assets") + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")),
            ("Touchpoints by Type", "Count of Marketing Touchpoint rows in the period by Touchpoint Type and Touchpoint Campaign, with distinct Touchpoint Party.",
             _u("04", "Marketing Touchpoint", "Touchpoint Party", "Touchpoint Timestamp", "Touchpoint Type", "Touchpoint Campaign")),
            ("Event Attendance Rate %", "Event Registration rows with Attended Indicator = Y / Event Registration rows with Registration Status = Registered, by Marketing Event Event Type and Attendance Mode.",
             _u("04", "Event Registration", "Registrant Party", "Registration Status", "Attended Indicator")
             + _u("04", "Marketing Event", "Event ID", "Event Type", "Attendance Mode", "Event Start", "Owning Campaign")),
            ("Cost per Event Attendee", "Campaign Spend of the event's Owning Campaign / Event Registration rows with Attended Indicator = Y.",
             _u("04", "Marketing Event", "Owning Campaign") + _u("04", "Event Registration", "Attended Indicator") + ["Campaign Spend"]),
            ("Campaign Tracking Coverage %", "Campaign nodes at Campaign Level = Tactic with at least one Campaign Tracking Code with utm_id populated / Campaign nodes at Campaign Level = Tactic, by Campaign Type.",
             _u("04", "Campaign Tracking Code", "Tracked URL", "utm_id", "utm_source", "utm_medium", "utm_campaign") + _u("04", "Campaign", "Campaign Level", "Campaign Type")),
            ("Social Posts Without Compliance Review", "Count of Social Post rows with Post Timestamp in the period and Post Compliance Review empty, by Post Campaign and Social Platform of the account; the review is 08's (DP-036).",
             _u("04", "Social Post", "Platform Post ID", "Post Timestamp", "Post Campaign", "Post Compliance Review") + _u("04", "Social Media Account", "Social Account ID", "Social Platform")),
            ("Social Accounts Not Archived", "Count of firm Social Media Account rows with Archiving Enrolled Indicator not Y (SEC Rule 17a-4 and FINRA Rule 3110(b)(4) capture), by Social Account Type; advisors' own accounts are DP-078's.",
             _u("04", "Social Media Account", "Social Account ID", "Social Account Type", "Archiving Enrolled Indicator")),
            ("Campaign Products Featured", "Count of campaign nodes by Campaign Product / Share Class and Product Role in Campaign, with the count of content assets featuring the same product (Asset Classification Featured Products / Share Classes) by Audience Restriction and Permitted Jurisdictions.",
             _u("04", "Campaign Product", "Campaign Product / Share Class", "Product Role in Campaign")
             + _u("04", "Asset Classification", "Featured Products / Share Classes", "Content Topics")
             + _u("04", "Audience Restriction", "Audience Restriction", "Permitted Jurisdictions") + _u("04", "Content Asset", "Asset ID", "Content Type")),
            ("Targeted Campaigns by Audience", "Count of campaign nodes active in the period by Target Audience Types, Target Segments and Marketing Channel Mix of their Campaign Targeting, with the Primary KPI named.",
             _u("04", "Campaign Targeting", "Target Audience Types", "Target Segments", "Target Jurisdictions", "Marketing Channel Mix", "Primary KPI", "Primary Objective")
             + _u("04", "Campaign", "Campaign Status", "Planned Start Date", "Planned End Date")),
        ],
        inputs=[
            ("04", "Campaign", ["Campaign ID", "Campaign Name", "Campaign Level", "Parent Campaign", "Campaign Type", "Campaign Status",
                                "Planned Start Date", "Planned End Date", "Marketing Theme", "Campaign Business Line"]),
            ("04", "Campaign Targeting", ["Primary Objective", "Primary KPI", "Target Audience Types", "Target Segments", "Target Jurisdictions",
                                          "Marketing Channel Mix"]),
            ("04", "Campaign Product", ["Campaign Product / Share Class", "Product Role in Campaign"]),
            ("04", "Campaign Budget", ["Budgeted Cost", "Actual Cost", "Budget Currency"]),
            ("04", "Spend Line", ["Spend Category", "Spend Amount"]),
            ("04", "Campaign Tracking Code", ["Tracked URL", "utm_id", "utm_source", "utm_medium", "utm_campaign"]),
            ("04", "Campaign Member", ["Member Party", "Member Lead", "Member Status", "Responded Indicator"]),
            ("04", "Media Placement", ["Placement ID", "Placement Campaign", "Paid Media Channel", "Planned Placement Spend"]),
            ("04", "Paid Media Delivery", ["Impressions", "Actual Spend"]),
            ("04", "Attribution Model", ["Attribution Model ID", "Attribution Model Type", "Lookback Window", "Primary Model Indicator"]),
            ("04", "Attributed Outcome", ["Outcome Type", "Attributed Milestone", "Attributed Campaign", "Applied Attribution Model",
                                          "Attribution Weight", "Attributed Amount"]),
            ("04", "Acquisition Milestone", ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"]),
            ("04", "Marketing Touchpoint", ["Touchpoint Party", "Touchpoint Timestamp", "Touchpoint Type", "Touchpoint Campaign"]),
            ("04", "Marketing Event", ["Event ID", "Event Type", "Attendance Mode", "Event Status", "Event Start", "Owning Campaign",
                                       "Event Audience Restriction"]),
            ("04", "Event Registration", ["Registrant Party", "Registration Status", "Attended Indicator"]),
            ("04", "Content Asset", ["Asset ID", "Content Type"]),
            ("04", "Audience Restriction", ["Audience Restriction", "Permitted Jurisdictions"]),
            ("04", "Asset Classification", ["Featured Products / Share Classes", "Content Topics"]),
            ("04", "Social Media Account", ["Social Account ID", "Social Platform", "Social Account Type", "Archiving Enrolled Indicator"]),
            ("04", "Social Post", ["Platform Post ID", "Post Timestamp", "Post Campaign", "Post Compliance Review"]),
            ("06", "Measure Value", list(_MV)),
            ("06", "Client Asset Measures", ["Net New Assets"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
        ],
        upstream=["DP-011", "DP-004", "DP-240", "DP-008", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for spend, media delivery, members, touchpoints, outcomes and registrations; campaign net new assets by business day 5 after month-end",
        history="Monthly snapshots kept seven years; campaign hierarchy SCD type 2; spend lines and attributed outcomes immutable per attribution model version",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Parent Campaign, Placement Campaign, Attributed Campaign, Touchpoint Campaign, Owning Campaign and Post Campaign resolves to a DP-011 Campaign ID, every Campaign Product / Share Class and Featured Products / Share Classes value to DP-004, and every Member Party, Touchpoint Party and Registrant Party to a DP-240 party.",
            "Planned End Date is on or after Planned Start Date, a campaign node has one parent in force, and attribution model versions of one Attribution Model ID do not overlap.",
            "For each Attributed Milestone the Attribution Weight of the rows of one Applied Attribution Model sums to 1 within 0.001, the Spend Amount of a campaign's spend lines ties to its Actual Cost within 1%, and Net New Assets by Campaign equals the DP-008 Measure Amount for the same Campaign ID and Snapshot ID.",
            "Campaign Level, Campaign Status and Campaign Business Line are populated on every campaign node, Actual Cost and Budget Currency on every budget, and Outcome Type and Attribution Weight on every attributed outcome.",
            "Member, touchpoint and registrant keys are visible to marketing operations only; published campaign views are aggregates of at least 10 parties, and Accessibility / Dietary Requirements and captured registrant emails are not read.",
            "The prior day is complete by 7am ET on T+1, and campaign net new assets are published only after the DP-008 snapshot of the month is Final.",
        ],
        notes=("Certified numbers: reads Net New Assets by campaign from DP-008, where the 04 attribution weights are applied "
               "once (CW-085, CW-227); computes counts, costs and rates only; owns none. "
               "PII tier: identity (member, touchpoint and registrant keys in the drill); published views are aggregates. "
               "Boundaries: supersedes DP-025 (spend, response and funnel) and DP-051 (events as tactics); takes the content "
               "performance scope of backlog DP-411 and the social and brand scope of backlog DP-413 in reduced form (WP1_Scope.md). "
               "Net new assets and funded households by campaign and acquisition cohort are DP-492 (DIS), which reads DP-008 and "
               "lists this product upstream for the funnel outcomes (Attributed Outcomes (Primary Model)) under the amended "
               "CW-227; the campaign NNA here is read from DP-008, the same value. Acquisition cost and lifetime value are DP-498 (CW-157), which reads this product. Advisors' own social "
               "accounts are 08 Approved Communication Channel, read by DP-078 (CW-067); the 08 review of posts and promotions is "
               "DP-036. Nudge determinations are DP-394's. The acquisition funnel is DP-392. "
               "Acceptance question 2: feeds DP-492 with the funnel outcomes (Attributed Outcomes (Primary Model)) beside Campaign Spend; "
               "the answer itself is Net New Assets by Campaign (from DP-008). "
               "Acceptance question 11: feeds DP-498 with acquisition spend (Campaign Spend, Spend by Category, Cost per "
               "Funded Account). "
               "Tailoring lever: attribution model (04 SME 7). Reference default: position-based over milestones as primary, "
               "first and last touch as alternatives. "
               "Tailoring lever: campaign hierarchy depth (04 SME 8). Reference default: program, campaign, wave, tactic. "
               "Taxonomy gap: 04 Spend Line has no spend date; spend is assigned to the month of the campaign node's Planned Start "
               "Date unless the budget is phased. "
               "Taxonomy gap: 04 Audience Restriction and Asset Classification have no link to the campaign that uses the content; "
               "products featured are matched through Campaign Product. "
               "Drafting assumptions: Campaign Level value Tactic; Outcome Type Account Funded; Registration Status Registered; the "
               "10% over-budget band; the minimum cell of 10; Dimension Type Campaign on 06 Measure Value. "
               "Decisions: CW-067, CW-085, CW-143, CW-157, CW-227, CW-242. "
               "WP1 new (CW-227): supersedes DP-025 and DP-051; also reads 04 Audience Restriction and Asset Classification (from "
               "backlog DP-411) and Social Media Account and Social Post (from backlog DP-413). All fourteen candidate objects read, "
               "with 04 Acquisition Milestone and Content Asset added."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-412": dict(
        definition=("The marketing audience for every send and personalization: segment membership, subscription topics, "
                    "suppression entries and visitor tracking choices from 04, joined to the opt-in state and contact rules of "
                    "each party that DP-324 conforms from 02, so each send is built from one eligibility answer. Marketing "
                    "operations builds audiences and proves that opt-outs, suppressions and tracking choices were honored. It owns "
                    "no certified metric family."),
        business_questions=[
            "How many parties are in each marketing segment and subscribed to each topic today?",
            "Were any promotional emails delivered to parties who had opted out of the topic or set email as a do-not-contact channel?",
            "Were unsubscribes written back to the contact rules within 10 business days, and which were never written back?",
            "Which suppressed identifiers lack a current do-not-call registry scrub, and how many suppressions came from revoked consent?",
            "How many visitors opted out of sale or sharing, and are any visitors tracked beyond their latest choice?",
        ],
        grain=("Party x marketing segment x effective period, with subscription opt-ins (from DP-324), suppression entries, email "
               "sends and interactions and visitor tracking choices as companion facts; SCD type 2 on membership and choices"),
        dimensions=["Marketing segment and segment type", "Subscription topic and category", "Suppression reason and scope",
                    "Email send type", "Tracking consent source and permitted categories", "Party and household (DP-240)",
                    "Opt-in status and channel (DP-324)", "Effective date (DP-013)"],
        measures=[
            ("Active Segments", "Count of Marketing Segment rows with at least one Segment Membership in force at the as-of date, by Segment Type.",
             _u("04", "Marketing Segment", "Segment ID", "Segment Type") + _u("04", "Segment Membership", "Member Party", "Membership Effective From", "Membership Effective To")),
            ("Segment Members", "Count of distinct Member Party of Segment Membership rows in force at the as-of date, by Marketing Segment.",
             _u("04", "Segment Membership", "Member Party", "Membership Effective From", "Membership Effective To") + _u("04", "Marketing Segment", "Segment ID", "Segment Name")),
            ("Subscribers by Topic (from DP-324)", "Count of distinct parties with DP-324's published Marketing Permission (per party, by topic and channel) granted for the Preference Topic on Preference Channel = Email at the as-of date, by Subscription Topic and Subscription Category; DP-324's consent rule is applied by reading Marketing Permission, never re-derived.",
             _u("02", "Communication Preference", "Preference Party", "Preference Topic", "Preference Channel", "Opt-In Status")
             + _u("04", "Subscription Topic", "Subscription Topic ID", "Subscription Topic Name", "Subscription Category")),
            ("Promotional Emails to Opted-Out Parties", "Count of Email Interaction rows with Delivery Status = Delivered of Email Sends with Email Send Type = Promotional whose Recipient Party, under the contact rule DP-324 publishes (read, not re-derived), had Opt-In Status = Opted Out for the Email Subscription Topic with Opt-Out Timestamp before the Planned Start Date of the Email Campaign, or a Contact Preference with Email in Do Not Contact Channels (DP-324).",
             _u("04", "Email Interaction", "Recipient Party", "Delivery Status") + _u("04", "Email Send", "Email Campaign", "Email Send Type", "Email Subscription Topic")
             + _u("02", "Communication Preference", "Opt-In Status", "Opt-Out Timestamp") + _u("02", "Contact Preference", "Preference Holder", "Do Not Contact Channels")
             + _u("04", "Campaign", "Campaign ID", "Planned Start Date")),
            ("Unsubscribe Rate %", "Email Interaction rows with Unsubscribe Timestamp in the period / Email Interaction rows with Delivery Status = Delivered in the period, by Email Send Type.",
             _u("04", "Email Interaction", "Unsubscribe Timestamp", "Delivery Status") + _u("04", "Email Send", "Email Send Type")),
            ("Unsubscribes Written Back Late", "Count of Email Interaction rows with Unsubscribe Timestamp in the period whose Unsubscribe Written Back Timestamp is more than 10 business days later (CAN-SPAM), and of those not written back at all.",
             _u("04", "Email Interaction", "Unsubscribe Timestamp", "Unsubscribe Written Back Timestamp")),
            ("Suppressed Identifiers by Reason", "Count of Suppression Entry rows in force (Suppression Effective From on or before the as-of date) by Suppression Reason and Suppression Scope.",
             _u("04", "Suppression Entry", "Suppressed Identifier", "Suppression Reason", "Suppression Scope", "Suppression Effective From")),
            ("Registry Scrubs Overdue", "Count of Suppression Entry rows of Suppression Reason = National Do Not Call whose Registry Scrub Date is more than 31 days before the as-of date (Telemarketing Sales Rule).",
             _u("04", "Suppression Entry", "Suppression Reason", "Registry Scrub Date")),
            ("Suppressions From Revoked Consent", "Count of Suppression Entry rows with Revoked Consent Record populated, by Suppression Scope.",
             _u("04", "Suppression Entry", "Revoked Consent Record", "Suppression Scope")),
            ("Sale or Sharing Opt-Out Rate %", "Visitors whose latest Tracking Consent Choice has Sale / Sharing Opt-Out Signal Indicator = Y / visitors with a Tracking Consent Choice, by Choice Source (banner, Global Privacy Control signal, preference center).",
             _u("04", "Tracking Consent Choice", "Choice Visitor", "Choice Timestamp", "Choice Source", "Sale / Sharing Opt-Out Signal Indicator")),
            ("Visitors Tracked Beyond Consent", "Count of Web Visitor / Known User rows whose Applied Tracking Consent includes a category not in the Permitted Tracking Categories of the visitor's latest Tracking Consent Choice.",
             _u("04", "Web Visitor / Known User", "Visitor ID", "Applied Tracking Consent") + _u("04", "Tracking Consent Choice", "Choice Visitor", "Choice Timestamp", "Permitted Tracking Categories")),
            ("Do-Not-Contact Parties in Segments (from DP-324)", "Count of Segment Members who are not in DP-324's published Contactable Clients by Channel for the segment's channel (their 02 Contact Preference in force lists it in Do Not Contact Channels, or no valid contact point), by Marketing Segment; read from DP-324, never re-derived.",
             _u("02", "Contact Preference", "Preference Holder", "Do Not Contact Channels", "Preference Effective From", "Preference Effective To") + ["Segment Members"]),
            ("Restricted Topics and Segments", "Count of Subscription Topics with Topic Audience Restriction populated and of Marketing Segments with Segment Audience Restriction populated, beside their members.",
             _u("04", "Subscription Topic", "Topic Audience Restriction") + _u("04", "Marketing Segment", "Segment Audience Restriction") + ["Segment Members"]),
        ],
        inputs=[
            ("04", "Marketing Segment", ["Segment ID", "Segment Name", "Segment Type", "Segment Rule Definition", "Segment Audience Restriction"]),
            ("04", "Segment Membership", ["Member Party", "Membership Effective From", "Membership Effective To"]),
            ("04", "Subscription Topic", ["Subscription Topic ID", "Subscription Topic Name", "Subscription Category", "Topic Audience Restriction"]),
            ("04", "Suppression Entry", ["Suppressed Identifier", "Suppression Reason", "Suppression Scope", "Suppression Effective From",
                                         "Registry Scrub Date", "Revoked Consent Record"]),
            ("04", "Tracking Consent Choice", ["Choice Visitor", "Choice Timestamp", "Choice Source", "Permitted Tracking Categories",
                                               "Sale / Sharing Opt-Out Signal Indicator"]),
            ("04", "Email Send", ["Email Template Asset", "Email Campaign", "Email Send Type", "Email Subscription Topic"]),
            ("04", "Email Interaction", ["Recipient Party", "Delivery Status", "Unsubscribe Timestamp", "Unsubscribe Written Back Timestamp"]),
            ("04", "Campaign", ["Campaign ID", "Planned Start Date"]),
            ("04", "Web Visitor / Known User", ["Visitor ID", "Matched Party", "Applied Tracking Consent"]),
            ("02", "Communication Preference", ["Preference Party", "Preference Topic", "Preference Channel", "Opt-In Status", "Opt-Out Timestamp"]),
            ("02", "Contact Preference", ["Preference Holder", "Do Not Contact Channels", "Preference Effective From", "Preference Effective To"]),
        ],
        upstream=["DP-324", "DP-011", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET on T+1, before the day's sends are built; suppression and opt-out changes on the event stream within 1 hour",
        history="Memberships, choices and suppressions SCD type 2; email interactions kept three years; suppression evidence kept for the life of the suppression plus five years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Reverse ETL to CRM", "Event stream"],
        dq_rules=[
            "Every Member Party, Recipient Party, Preference Party, Preference Holder and Matched Party resolves to a DP-240 party, every Email Subscription Topic and Preference Topic to a Subscription Topic ID, and every Email Campaign to a DP-011 Campaign ID.",
            "Segment Membership periods do not overlap for the same Member Party and segment, and Contact Preference periods do not overlap for the same Preference Holder.",
            "Opt-In Status per party, topic and channel equals DP-324's published contact rule for the same as-of date with no difference, so the send and the contact rule give one answer.",
            "Suppression Reason and Suppression Effective From are populated on every suppression entry, Choice Timestamp and Permitted Tracking Categories on every tracking choice, and Email Send Type on every send.",
            "Suppressed Identifier is held hashed and never published in clear, Recipient Email Address is not read, and party keys are published to marketing operations only.",
            "The day's audience is built by 6am ET from data complete to the prior day, and opt-outs and suppressions reach the event stream within 1 hour.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (party keys and hashed identifiers). "
               "Boundaries: opt-in state, consent and privacy are 02 and conformed by DP-324 Client Contactability, Preferences & "
               "Consent (CLA-A); topics, suppression and tracking choices are 04 (CW-084, CW-094); 02 client segments are not "
               "marketing audiences (CW-094). The 02 Communication Preference and Contact Preference are read as DP-324 publishes "
               "them. Supersedes DP-028 with DP-324 (GDPR inputs left, CW-904). DP-394 reads the applied tracking consent for its "
               "events. "
               "Tailoring lever: marketing platform masters opt-ins (04 SME 9). Reference default: 02 masters opt-ins and the "
               "marketing platform writes unsubscribes back. "
               "Tailoring lever: state privacy regimes (02 SME 8). Reference default: the opt-out of sale or sharing is honored "
               "for every visitor, not only residents of states that require it. "
               "Taxonomy gap: 04 Email Send has no send timestamp; the send date is taken from the Planned Start Date of its Email "
               "Campaign. "
               "Drafting assumptions: Opt-In Status values Opted In and Opted Out; Email Send Type Promotional; Delivery Status "
               "Delivered; Suppression Reason National Do Not Call; the 10-business-day write-back and 31-day scrub standards. "
               "Decisions: CW-084, CW-086, CW-094, CW-904. "
               "WP1 new (CW-220): supersedes DP-028 (with DP-324); all six candidate objects read, with 04 Email Interaction, "
               "Campaign and Web Visitor / Known User and the 02 preference objects added."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-418": dict(
        definition=("Lost securityholder status and the SEC Rule 17Ad-17 searches, state dormancy assessments and due diligence "
                    "letters, presumed-abandoned dates, escheatment deliveries, state reports, remittances and reclaims, for "
                    "TA-registered accounts (the 29 share register through DP-580) and brokerage accounts (Client Holding, 49, "
                    "through DP-300), with owner-generated contact from DP-381. Client service and the transfer agent stop accounts "
                    "escheating that should not and file every state on time. It owns no certified metric family."),
        business_questions=[
            "Which accounts are lost securityholders, and were the Rule 17Ad-17 database searches done in time?",
            "Which accounts will be presumed abandoned in the next 180 days, and were their due diligence letters sent in time?",
            "Which dormant accounts had owner-generated contact that should have reset dormancy?",
            "What value and shares are at risk of escheatment, and what was escheated and remitted by state this year?",
            "Which state reports are due or late, which remittances have not settled, and which reclaims are open?",
        ],
        grain=("Account x reporting state x dormancy assessment cycle, with lost securityholder episodes, escheatment reports and "
               "remittances, reclaims, owner contact and the account's holdings and register balances as companion facts; "
               "status history as SCD type 2"),
        dimensions=["Owner state of last known address", "Dormancy trigger basis and property type", "Escheatment status",
                    "Lost securityholder and unresponsive payee indicators", "Searching entity", "Reporting state",
                    "Register account category (DP-580)", "Account and registration type (DP-093)", "Assessment date (DP-013)"],
        measures=[
            ("Lost Securityholders", "Count of Lost Shareholder Status rows with Lost Securityholder Indicator = Y at the as-of date, by Status Account type (TA-registered or brokerage).",
             _u("13", "Lost Shareholder Status", "Status Account", "Lost Securityholder Indicator", "First Returned Mail Date")),
            ("Late Rule 17Ad-17 Searches", "Count of lost securityholders whose First Database Search Date is empty more than 12 months after First Returned Mail Date or earlier than 3 months after it, or whose Second Database Search Date is not between 6 and 12 months after the first, by Searching Entity.",
             _u("13", "Lost Shareholder Status", "First Returned Mail Date", "First Database Search Date", "Second Database Search Date", "Searching Entity")),
            ("Unresponsive Payees Without Notice", "Count of Lost Shareholder Status rows with Unresponsive Payee Indicator = Y and Unresponsive Payee Notice Date empty (SEC Rule 17Ad-17(b) notice).",
             _u("13", "Lost Shareholder Status", "Unresponsive Payee Indicator", "Unresponsive Payee Notice Date")),
            ("Accounts Approaching Presumed Abandonment", "Count of Dormancy Assessment rows with Escheatment Status not Escheated and Presumed Abandoned Date within the next 180 days, by Owner State of Last Known Address and Property Type Code.",
             _u("13", "Dormancy Assessment", "Dormancy Account", "Presumed Abandoned Date", "Escheatment Status", "Owner State of Last Known Address", "Property Type Code")),
            ("Due Diligence Letters Late", "Count of Dormancy Assessment rows with Presumed Abandoned Date within 60 days (or past) and Due Diligence Letter Sent Date empty or less than 60 days before Presumed Abandoned Date, by Owner State of Last Known Address.",
             _u("13", "Dormancy Assessment", "Presumed Abandoned Date", "Due Diligence Letter Sent Date", "Owner State of Last Known Address")),
            ("Dormant Accounts With Recent Owner Contact", "Count of Dormancy Assessment rows not yet escheated whose account has a DP-381 Service Request (Account, Received Timestamp) or Contact Center Interaction (Interaction Account, Interaction Start Timestamp) from the owner after the Last Owner-Generated Contact Date: dormancy that should be reset before escheat.",
             _u("13", "Dormancy Assessment", "Dormancy Account", "Last Owner-Generated Contact Date", "Escheatment Status")
             + _u("13", "Service Request", "Service Request ID", "Account", "Received Timestamp", "Requester Role")
             + _u("13", "Contact Center Interaction", "Interaction Account", "Interaction Start Timestamp")),
            ("Brokerage Value at Risk of Escheatment", "Sum of Market Value in USD of 49 Client Holding Valuation of the Client Holdings (Client Holding Date = as-of date, Client Holding View = End of Day, DP-300) of brokerage accounts counted in Accounts Approaching Presumed Abandonment, by Owner State of Last Known Address.",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View") + _u("49", "Client Holding Valuation", "Market Value in USD")
             + ["Accounts Approaching Presumed Abandonment"]),
            ("Registered Shares at Risk of Escheatment", "Sum of Registered Shares of 29 Share Register Balance rows (Register Business Date = as-of date, DP-580) of TA-registered accounts counted in Accounts Approaching Presumed Abandonment, by Register Share Class and Register Account Category.",
             _u("29", "Share Register Balance", "Register Account", "Register Share Class", "Register Business Date", "Register Account Category", "Registered Shares")
             + ["Accounts Approaching Presumed Abandonment"]),
            ("Accounts Escheated", "Count of Dormancy Assessment rows whose Escheatment Status changed to Escheated in the period, by Owner State of Last Known Address and Dormancy Trigger Basis.",
             _u("13", "Dormancy Assessment", "Escheatment Status", "Owner State of Last Known Address", "Dormancy Trigger Basis")),
            ("State Reports Due or Late", "Count of Escheatment Report & Remittance rows with Report Due Date in the next 60 days and Report Filed Date empty, and of those with Report Filed Date after Report Due Date or still unfiled past it, by Reporting State.",
             _u("13", "Escheatment Report & Remittance", "Escheatment Report ID", "Reporting State", "Report Due Date", "Report Filed Date")),
            ("Amount Remitted by State", "Sum of Amount Remitted of Escheatment Report & Remittance rows filed in the year, by Reporting State (USD).",
             _u("13", "Escheatment Report & Remittance", "Amount Remitted", "Reporting State", "Report Filed Date")),
            ("Remittances Not Settled", "Count of filed reports whose Remittance Money Movement resolves to a 50 Money Movement with Money Movement Status not Settled more than 5 business days after Report Filed Date (DP-302).",
             _u("13", "Escheatment Report & Remittance", "Remittance Money Movement", "Report Filed Date")
             + _u("50", "Money Movement", "Money Movement ID", "Money Movement Status", "Movement Amount", "Value Date")),
            ("Open Unclaimed Property Reclaims", "Count of Unclaimed Property Reclaim rows with Reclaim Status not Paid or Denied, by Reclaim Source.",
             _u("13", "Unclaimed Property Reclaim", "Reclaim ID", "Claimant", "Reclaim Status", "Reclaim Source")),
        ],
        inputs=[
            ("13", "Lost Shareholder Status", ["Status Account", "Lost Securityholder Indicator", "First Returned Mail Date", "First Database Search Date",
                                               "Second Database Search Date", "Unresponsive Payee Indicator", "Unresponsive Payee Notice Date",
                                               "Searching Entity"]),
            ("13", "Dormancy Assessment", ["Dormancy Account", "Owner State of Last Known Address", "Last Owner-Generated Contact Date",
                                           "Dormancy Trigger Basis", "Dormancy Period (Years)", "Presumed Abandoned Date",
                                           "Due Diligence Letter Sent Date", "Property Type Code", "Escheatment Status"]),
            ("13", "Escheatment Report & Remittance", ["Escheatment Report ID", "Reporting State", "Report Due Date", "Amount Remitted",
                                                       "Remittance Money Movement", "Report Filed Date"]),
            ("13", "Unclaimed Property Reclaim", ["Reclaim ID", "Claimant", "Reclaim Source", "Reclaim Status"]),
            ("13", "Service Request", ["Service Request ID", "Account", "Received Timestamp", "Requester Role"]),
            ("13", "Contact Center Interaction", ["Interaction Account", "Interaction Start Timestamp"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date", "Register Account Category",
                                              "Registered Shares"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("50", "Money Movement", ["Money Movement ID", "Money Movement Status", "Movement Amount", "Value Date"]),
        ],
        upstream=["DP-381", "DP-580", "DP-300", "DP-302", "DP-093", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; state report status refreshed on event; value at risk monthly by business day 3",
        history="Lost episodes, assessments, reports and reclaims kept as SCD type 2 with every status; kept until the later of ten years or the state's record requirement after escheatment (SEC Rule 17Ad-17 records; state unclaimed property laws)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Status Account, Dormancy Account, Register Account and Holding Account resolves to a DP-093 Account ID, every Claimant to a DP-240 party, every Remittance Money Movement to a DP-302 Money Movement ID, and every Reporting State to the state code list.",
            "Lost episodes of one account do not overlap, Second Database Search Date is empty or after First Database Search Date, and Report Filed Date is empty or on or after the assessments it reports.",
            "Amount Remitted of each filed report equals the Movement Amount of its Remittance Money Movement to the cent, and the shares escheated from TA-registered accounts tie to the DP-580 register transactions of escheatment type for the same report within zero shares.",
            "Owner State of Last Known Address, Last Owner-Generated Contact Date, Presumed Abandoned Date and Escheatment Status are populated on every dormancy assessment, and Reporting State and Report Due Date on every report.",
            "Owner names and addresses are not read; account keys are published to client service, the transfer agent and unclaimed property staff only, and filing views carry state-level aggregates.",
            "The prior business day is complete by 7am ET on T+1, and a state report is locked once Report Filed Date is set.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: financial (account keys with values at risk and owner state). "
               "Boundaries: books are the 29 Share Register Balance (DP-580) for TA-registered accounts and Client Holding (49, "
               "DP-300) for brokerage accounts (CW-007); never 06. Owner-generated contact comes from DP-381; returned mail from "
               "DP-382 is the source of 13 Lost Shareholder Status. Remittances are 50 movements (DP-302). Supersedes DP-070 (no "
               "live dependent, so a new id); FOP+CORP withdrew DP-584 as a duplicate and its notes re-point here. "
               "Tailoring lever: escheatment service provider. Reference default: the firm runs dormancy assessment and state "
               "reporting in house with a search vendor; with a provider the same grain is received from it. "
               "Taxonomy gap: 13 Dormancy Assessment has no link to the Escheatment Report & Remittance that reported it; account "
               "to report matching uses Reporting State and the report year. "
               "Taxonomy gap: 13 Escheatment Report & Remittance carries no share quantity for register escheatment; the share tie "
               "is taken from the 29 register transactions. "
               "Drafting assumptions: Escheatment Status Escheated; Reclaim Status values Paid and Denied; Money Movement Status "
               "Settled; Requester Role Owner; the 3-to-12-month and 6-to-12-month search windows, the 60-day letter standard and "
               "the 180-day watch window. "
               "Decisions: CW-007, CW-089, CW-107, CW-913. "
               "WP1 new (CW-220): supersedes DP-070; all eight candidate objects read, with 49 Client Holding Valuation and 13 "
               "Contact Center Interaction added."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-036": dict(
        definition=("Every communication submitted for review, from submission through review steps, principal approval, FINRA "
                    "filing, expiry and withdrawal, with the US classification that decides which rules apply (FINRA Rule 2210 "
                    "category, Rule 482 fund communication, Marketing Rule advertisement under Rule 206(4)-1) and the performance "
                    "shown. Advertising review manages its workload and evidences approval before first use, timely filing under "
                    "FINRA Rules 2210 and 2212 and, for performance, the track record and declared content behind it. It owns no "
                    "certified metric family."),
        business_questions=[
            "How long do reviews take from submission to principal approval, how big is the open backlog, and how many pass first time?",
            "Which communications required FINRA filing, which were filed late or are overdue, and how often did FINRA comment?",
            "Was any communication used before approval or after its approval expired, and which approvals expire in the next 30 days?",
            "Was every approval given by a principal with the right registration?",
            "Which communications show performance or hypothetical performance, and does each have its declared content, net presentation and track record basis?",
        ],
        grain=("Communication review (REV-) x asset version, with its US classification, performance presentation, review steps, "
               "approval and FINRA filing attribute groups; immutable review history with approval status as SCD type 2"),
        dimensions=["Submission and approval date", "Review type", "Content type", "Intended audience", "FINRA communication category",
                    "Marketing Rule advertisement type", "Investment company communication type", "Product featured (DP-004)",
                    "Approval status", "Reviewer / approving principal (DP-009)", "Submitting team (DP-192)"],
        measures=[
            ("Review Cycle Time", "Median business days from Submission Timestamp to Approval Decision Date of reviews decided in the period, by Review Type and FINRA Communication Category.",
             _u("08", "Compliance Review", "Review ID", "Submission Timestamp", "Review Type") + _u("08", "Compliance Approval", "Approval Decision Date")
             + _u("08", "US Communication Classification", "FINRA Communication Category")),
            ("Step Cycle Time", "Median hours between consecutive Step Completed Timestamp values of the Review Steps of a review (the first measured from Submission Timestamp), by Reviewer Role.",
             _u("08", "Review Step", "Review Step Sequence", "Step Completed Timestamp", "Reviewer Role") + _u("08", "Compliance Review", "Submission Timestamp")),
            ("Open Review Backlog", "Count of Compliance Reviews with Submission Timestamp before the as-of date and no Compliance Approval with Approval Status in Approved, Approved with Changes or Rejected, by Review Type and age band.",
             _u("08", "Compliance Review", "Review ID", "Submission Timestamp", "Review Type") + _u("08", "Compliance Approval", "Approval Status")),
            ("First-Pass Approval Rate", "Reviews decided in the period approved with no Review Step with Step Outcome = Changes Requested / reviews decided in the period.",
             _u("08", "Review Step", "Step Outcome") + _u("08", "Compliance Approval", "Approval Status", "Approval Decision Date")),
            ("FINRA Filing Timeliness %", "FINRA Advertising Filings with FINRA Filing Requirement populated and Filed Date on or before Filing Due Date / FINRA Advertising Filings due in the period (ten business days after First Use Date for retail communications that require it, before first use where pre-filing applies).",
             _u("08", "FINRA Advertising Filing", "FINRA Filing Requirement", "Filed Date", "Filing Due Date", "First Use Date")),
            ("Overdue Filings", "Count of FINRA Advertising Filings with Filing Due Date before the as-of date and Filed Date empty.",
             _u("08", "FINRA Advertising Filing", "Filing Due Date", "Filed Date", "FINRA Filing Requirement")),
            ("Used Before Approval Flag", "Y for a review whose First Use Date or the asset version's Publication Date is before the Approval Decision Date of an approving decision, or with no approving decision.",
             _u("08", "FINRA Advertising Filing", "First Use Date") + _u("04", "Asset Version", "Publication Date")
             + _u("08", "Compliance Approval", "Approval Decision Date", "Approval Status")),
            ("Expired In Use Flag", "Y for an asset version with Asset Lifecycle Status = Published whose Compliance Approval has Approval Expiry Date before the as-of date or Withdrawal Date populated, or whose own Expiry Date has passed.",
             _u("04", "Asset Version", "Asset Lifecycle Status", "Expiry Date") + _u("08", "Compliance Approval", "Approval Expiry Date", "Withdrawal Date")),
            ("Approvals Expiring Next 30 Days", "Count of Compliance Approvals with Approval Status approving and Approval Expiry Date within the next 30 calendar days whose asset version is still Published.",
             _u("08", "Compliance Approval", "Approval Status", "Approval Expiry Date") + _u("04", "Asset Version", "Asset Lifecycle Status")),
            ("Principal Qualification Exception", "Y for an approval whose Approving Principal License is empty or resolves to an 08 Individual Registration of the Approving Principal with Registration Status not Approved or a Registration Category that cannot approve the FINRA Communication Category (for example a retail communication about investment company products without a Series 24 or 26).",
             _u("08", "Compliance Approval", "Approving Principal", "Approving Principal License")
             + _u("08", "Individual Registration", "License ID", "Registered Person", "Registration Category", "Registration Status")
             + _u("08", "US Communication Classification", "FINRA Communication Category")),
            ("FINRA Comment Rate", "FINRA Advertising Filings with FINRA Review Outcome other than No Comment / filings with a FINRA Review Outcome in the period.",
             _u("08", "FINRA Advertising Filing", "FINRA Review Outcome", "FINRA Filing Reference")),
            ("Marketing Rule Advertisements Reviewed", "Count of reviews decided in the period with Marketing Rule Advertisement Indicator = Y, by Marketing Rule Advertisement Type, with those carrying a Testimonial / Endorsement Indicator or Third-Party Rating Indicator.",
             _u("08", "US Communication Classification", "Marketing Rule Advertisement Indicator", "Marketing Rule Advertisement Type",
                "Testimonial / Endorsement Indicator", "Third-Party Rating Indicator") + _u("08", "Compliance Approval", "Approval Decision Date")),
            ("Performance Shown Without Declaration", "Count of reviews with Performance Shown Indicator = Y whose asset version's 04 Asset Compliance Reference has Performance Content Declared Indicator not Y, or with Hypothetical Performance Declared Indicator = Y and Performance Type not Hypothetical.",
             _u("08", "Performance Presentation", "Performance Shown Indicator", "Performance Type")
             + _u("04", "Asset Compliance Reference", "Compliance Review Reference", "Performance Content Declared Indicator", "Hypothetical Performance Declared Indicator")),
            ("Gross-Only Performance in Advertisements", "Count of Marketing Rule advertisements with Performance Shown Indicator = Y and Gross / Net Presentation = Gross Only (Rule 206(4)-1(d)(1) requires net with gross).",
             _u("08", "Performance Presentation", "Performance Shown Indicator", "Gross / Net Presentation", "Performance As-Of Date")
             + _u("08", "US Communication Classification", "Marketing Rule Advertisement Indicator")),
            ("Performance Without Track Record Basis", "Count of reviews with Performance Shown Indicator = Y whose Products Featured include a share class (DP-004) with 01 Performance Track Record Performance Inception Date or Track Record Source empty.",
             _u("08", "Compliance Review", "Products Featured") + _u("08", "Performance Presentation", "Performance Shown Indicator")
             + _u("01", "Share Class", "Share Class ID") + _u("01", "Performance Track Record", "Performance Inception Date", "Track Record Source", "Performance Calculation Basis")),
            ("Mirrored Approval Status Mismatch", "Count of asset versions whose 04 Asset Compliance Reference Approval Status (Mirrored) differs from the Approval Status of the 08 Compliance Approval named by Compliance Review Reference.",
             _u("04", "Asset Compliance Reference", "Compliance Review Reference", "Approval Status (Mirrored)") + _u("08", "Compliance Approval", "Approval Status")),
        ],
        inputs=[
            ("08", "Compliance Review", ["Review ID", "Communication Asset", "Submitted By", "Submission Timestamp", "Review Type",
                                         "Products Featured", "Services Featured", "Intended Audience"]),
            ("08", "US Communication Classification", ["FINRA Communication Category", "Investment Company Communication Type",
                                                       "Marketing Rule Advertisement Indicator", "Marketing Rule Advertisement Type",
                                                       "Testimonial / Endorsement Indicator", "Third-Party Rating Indicator",
                                                       "Fair and Balanced Check"]),
            ("08", "Performance Presentation", ["Performance Shown Indicator", "Performance Type", "Gross / Net Presentation", "Performance As-Of Date"]),
            ("08", "Review Step", ["Review Step Sequence", "Reviewer", "Reviewer Role", "Step Outcome", "Step Completed Timestamp"]),
            ("08", "Compliance Approval", ["Approval Status", "Approval Decision Date", "Approving Principal", "Approving Principal License",
                                           "Approval Expiry Date", "Withdrawal Date"]),
            ("08", "FINRA Advertising Filing", ["FINRA Filing Requirement", "FINRA Filing Reference", "First Use Date", "Filing Due Date",
                                                "Filed Date", "FINRA Review Outcome"]),
            ("08", "Individual Registration", ["License ID", "Registered Person", "Registration Category", "Registration Status"]),
            ("04", "Content Asset", ["Asset ID", "Content Type"]),
            ("04", "Asset Version", ["Version Number", "Asset Lifecycle Status", "Publication Date", "Expiry Date", "Withdrawal Reason"]),
            ("04", "Asset Compliance Reference", ["Compliance Review Reference", "Approval Status (Mirrored)", "Performance Content Declared Indicator",
                                                  "Hypothetical Performance Declared Indicator", "Testimonial / Endorsement / Rating Declared Indicator"]),
            ("01", "Share Class", ["Share Class ID"]),
            ("01", "Performance Track Record", ["Performance Inception Date", "Track Record Source", "Performance Calculation Basis"]),
        ],
        upstream=["DP-004", "DP-009", "DP-011", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for submissions, steps, approvals and filings of the prior business day",
        history="Reviews, steps and filings kept as immutable history with approval status as SCD type 2; kept three years from last use and six years by firm policy (FINRA Rule 2210(b)(4), SEC Rule 17a-4(b)(4), Rule 204-2(a)(11) and (16))",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Communication Asset resolves to a DP-011 Asset ID, every Products Featured value to DP-004, every Approving Principal and Reviewer to a DP-009 or DP-192 person, every Approving Principal License to an 08 License ID, and every Compliance Review Reference on 04 to a Review ID of this product.",
            "Approval Expiry Date and Withdrawal Date are empty or on or after Approval Decision Date, and Review Step Sequence runs from 1 without gaps on each review.",
            "Every asset version with Asset Lifecycle Status = Published has an Asset Compliance Reference whose Approval Status (Mirrored) equals the 08 Approval Status, and every FINRA Advertising Filing with Filed Date has a FINRA Filing Reference.",
            "Submission Timestamp, Review Type and Intended Audience are populated on every review, FINRA Communication Category on every review of a broker-dealer communication, and Approval Status and Approval Decision Date on every decided review.",
            "Submitter, reviewer and principal identities are published to advertising review and compliance only; communication content is referenced by asset, never copied.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned; returns shown in communications are DP-145's and not read here. "
               "PII tier: identity (employees: submitters, reviewers, principals). "
               "Boundaries: communications review and FINRA filing in retail form (CW-073); retention is 21 (CW-068); the content "
               "asset is 04 (DP-011); fund performance figures are DP-145's. Marketing Rule substantiation (backlog DP-415) merges "
               "here: its 01 Performance Track Record and 04 Asset Compliance Reference reads moved to this product, and the full "
               "substantiation pack waits for DP-415. Live DP-236 reads this product's 08 Review ID for press releases about funds "
               "in offering. DP-394, DP-392 and DP-410 report the review references of nudges, promotions and posts and read 08 "
               "directly. "
               "Tailoring lever: advice programs inside the GIPS firm (W2 to W4 ruling). Reference default: outside; advice program "
               "performance in advertisements uses the composite track record of DP-145. "
               "Taxonomy gap: 08 Compliance Review carries no review deadline or requested first-use date; the backlog age band "
               "runs from Submission Timestamp. "
               "Drafting assumptions: Approval Status values Approved, Approved with Changes and Rejected; Step Outcome Changes "
               "Requested; FINRA Review Outcome No Comment; Gross / Net Presentation Gross Only; Performance Type Hypothetical; "
               "the 30-day window; the principal Registration Category rule. "
               "Decisions: CW-068, CW-073, CW-908, CW-220. "
               "WP1 re-scope (CW-220): kept in place because live DP-236 depends on the id; name unchanged; owning domain 08 "
               "unchanged. Inputs dropped: 08 EU / UK Communication Classification, Required Disclosures and Other Regulator "
               "Filing (CW-908; not in the retail 08). Inputs added: 04 Asset Compliance Reference and 01 Performance Track Record "
               "(moved from backlog DP-415), 01 Share Class. Measures kept with their names (all eleven read by SM-05: Review Cycle "
               "Time, Step Cycle Time, Open Review Backlog, First-Pass Approval Rate, FINRA Filing Timeliness %, Overdue Filings, "
               "Used Before Approval Flag, Expired In Use Flag, Approvals Expiring Next 30 Days, Principal Qualification Exception, "
               "FINRA Comment Rate); measures added: Marketing Rule Advertisements Reviewed, Performance Shown Without Declaration, "
               "Gross-Only Performance in Advertisements, Performance Without Track Record Basis, Mirrored Approval Status Mismatch. "
               "Dimension dropped: 'FCA financial promotion type' (no reader found); 'Jurisdiction of use' dropped (US only). "
               "Upstream unchanged except DP-192 added. Entities of models_c4_compliance DP-036 keep their backing objects except "
               "the EU / UK classification. Semantic layer: SM-29 at WP2 (framing ruling)."
               " WP2 retirement sweep (CW-209): SM-05, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-038": dict(
        definition=("Every gift, entertainment item and sponsor-paid training or education meeting given or received by the "
                    "firm's people, valued per recipient and summed per recipient per year against the FINRA Rule 3220 limit, "
                    "the Rule 2341 non-cash compensation conditions, approvals and the special-recipient controls (ERISA plan "
                    "fiduciaries, union officials, government officials). Compliance evidences the limits and sees "
                    "concentrations by recipient firm and advisor. It owns no certified metric family."),
        business_questions=[
            "Which recipients are near or over the annual gift limit, and how many limit breaches occurred this year?",
            "Which items lacked approval or were approved late, and which non-cash compensation arrangements failed a Rule 2341 condition?",
            "How often is each recipient entertained, and how much is spent by recipient firm?",
            "Which items involved an ERISA plan fiduciary, union official or government official?",
            "Does the gift and entertainment spend reconcile to the expense ledger?",
        ],
        grain=("Gift, entertainment or non-cash compensation item (GNE-) with its valuation, approval and training meeting "
               "attribute groups, joined to the giver's advisor role and the related event; recipient x year as the limit view; "
               "immutable items"),
        dimensions=["Benefit date / year", "Direction (given / received)", "Benefit type", "Giver (DP-192)", "Giver advisor role and producing indicator (DP-009)",
                    "Recipient individual and recipient firm (DP-240)", "Related event (DP-011)", "Applicable limit rule", "Approval status",
                    "Special recipient category"],
        measures=[
            ("Recipient Year-to-Date Value", "Recipient Year-to-Date Value of the latest Benefit Valuation per Recipient Individual and calendar year (gifts only; entertainment with the host present is outside the limit), from 08.",
             _u("08", "Benefit Valuation", "Recipient Year-to-Date Value", "Applicable Limit Rule") + _u("08", "Gift / Entertainment Item", "Recipient Individual", "Benefit Date", "Benefit Type", "Host Present Indicator")),
            ("Limit Utilization %", "Recipient Year-to-Date Value / Annual Limit Amount of the Applicable Limit Rule (USD 300 per person per year under FINRA Rule 3220 as amended; confirm), by recipient.",
             _u("08", "Benefit Valuation", "Annual Limit Amount") + ["Recipient Year-to-Date Value"]),
            ("Near-Limit Recipients", "Count of recipients with Limit Utilization % of 80% or more and below 100% in the year.",
             ["Limit Utilization %"]),
            ("Limit Breach Count", "Count of items with Limit Breach Indicator = Y in the year, by Giver and Recipient Firm.",
             _u("08", "Benefit Valuation", "Limit Breach Indicator") + _u("08", "Gift / Entertainment Item", "Giver", "Recipient Firm", "Benefit Date")),
            ("Late or Missing Approval Count", "Count of items whose G&E Approval Status is empty, Pending past the Benefit Date, or Rejected while the benefit was given, by Benefit Type.",
             _u("08", "G&E Approval", "G&E Approval Status", "G&E Approver") + _u("08", "Gift / Entertainment Item", "Benefit Date", "Benefit Type", "Direction")),
            ("Non-Cash Compensation Exception", "Count of training or education meetings with Member Firm Prior Approval Indicator not Y or Guest Expenses Paid Indicator = Y, and of items with Sales Target Precondition Indicator = Y (FINRA Rule 2341(l)(5) conditions), by Sponsor Firm.",
             _u("08", "Training / Education Meeting", "Meeting Event", "Sponsor Firm", "Member Firm Prior Approval Indicator", "Guest Expenses Paid Indicator")
             + _u("08", "Benefit Valuation", "Sales Target Precondition Indicator")),
            ("Entertainment Frequency per Recipient", "Count of entertainment items (Benefit Type = Business Entertainment) per Recipient Individual in the trailing 12 months, with recipients above 12 listed.",
             _u("08", "Gift / Entertainment Item", "Benefit Type", "Recipient Individual", "Benefit Date")),
            ("Spend by Recipient Firm", "Sum of Total Cost of items given in the year by Recipient Firm, with Per-Recipient Value summed per individual.",
             _u("08", "Benefit Valuation", "Total Cost", "Per-Recipient Value") + _u("08", "Gift / Entertainment Item", "Recipient Firm", "Direction")),
            ("Special Recipient Items", "Count and Total Cost of items with ERISA Plan Fiduciary Indicator, Union Official Indicator or Government Official Indicator = Y in the year, by indicator (ERISA, LMRDA reporting and pay-to-play controls).",
             _u("08", "Gift / Entertainment Item", "ERISA Plan Fiduciary Indicator", "Union Official Indicator", "Government Official Indicator")
             + _u("08", "Benefit Valuation", "Total Cost")),
            ("Items Given by Producing Advisors", "Count and Total Cost of items given in the year whose Giver holds an 03 Advisor Role Assignment with Producing Indicator = Y in force at Benefit Date, by Advisor Role.",
             _u("03", "Advisor Role Assignment", "Role Advisor", "Advisor Role", "Producing Indicator", "Role Effective From", "Role Effective To")
             + _u("08", "Gift / Entertainment Item", "Giver", "Benefit Date") + _u("08", "Benefit Valuation", "Total Cost")),
            ("Event-Linked Items", "Count of items with Related Event populated, by 04 Marketing Event Event Type, with their Total Cost.",
             _u("08", "Gift / Entertainment Item", "Related Event") + _u("04", "Marketing Event", "Event ID", "Event Type", "Event Start") + _u("08", "Benefit Valuation", "Total Cost")),
            ("Unreconciled G&E Spend", "Total Cost of items given in the month - Expense Amount of 10 Distribution Cost Item rows with Distribution Expense Category = Gifts & Entertainment whose Service Period Start falls in the month; shown when the absolute difference exceeds 2%.",
             _u("10", "Distribution Cost Item", "Distribution Cost Item ID", "Distribution Expense Category", "Source Record", "Expense Amount", "Service Period Start")
             + _u("08", "Benefit Valuation", "Total Cost")),
        ],
        inputs=[
            ("08", "Gift / Entertainment Item", ["GNE ID", "Direction", "Benefit Type", "Benefit Date", "Giver", "Recipient Individual", "Recipient Firm",
                                                 "Host Present Indicator", "Related Event", "Union Official Indicator", "ERISA Plan Fiduciary Indicator",
                                                 "Government Official Indicator"]),
            ("08", "Benefit Valuation", ["Total Cost", "Per-Recipient Value", "Applicable Limit Rule", "Annual Limit Amount", "Recipient Year-to-Date Value",
                                         "Limit Breach Indicator", "Sales Target Precondition Indicator"]),
            ("08", "G&E Approval", ["G&E Approval Status", "G&E Approver"]),
            ("08", "Training / Education Meeting", ["Meeting Event", "Sponsor Firm", "Member Firm Prior Approval Indicator", "Guest Expenses Paid Indicator"]),
            ("03", "Advisor Role Assignment", ["Role Advisor", "Advisor Role", "Producing Indicator", "Role Effective From", "Role Effective To"]),
            ("04", "Marketing Event", ["Event ID", "Event Type", "Event Start"]),
            ("10", "Distribution Cost Item", ["Distribution Cost Item ID", "Distribution Expense Category", "Source Record", "Expense Amount",
                                              "Service Period Start"]),
        ],
        upstream=["DP-009", "DP-240", "DP-192", "DP-011", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for items logged and approved the prior business day; the ledger reconciliation by business day 8 after month-end",
        history="Items, valuations and approvals immutable; kept six years (FINRA Rule 3220.02 records, Rule 4511; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Giver and G&E Approver resolves to a DP-192 employee, every Role Advisor to a DP-009 advisor, every Recipient Individual and Recipient Firm to a DP-240 party, every Related Event and Meeting Event to a DP-011 Event ID and every Source Record of a gifts cost item to a GNE ID.",
            "Advisor Role Assignment periods of the same Role Advisor and Advisor Role do not overlap, and each item has one Benefit Date in one limit year.",
            "Recipient Year-to-Date Value equals the sum of Per-Recipient Value of the recipient's gift items in the year to the cent, Limit Breach Indicator = Y exactly when it exceeds Annual Limit Amount, and the month's G&E Total Cost ties to the 10 ledger cost items within 2%.",
            "Direction, Benefit Type, Benefit Date, Giver and Recipient Individual are populated on every item, and Total Cost, Per-Recipient Value and Applicable Limit Rule on every valuation.",
            "Giver and recipient identities are published to compliance only; other views carry totals by recipient firm, benefit type and advisor role, and no client account data is read.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (givers, recipients; values attributed to named recipients are PII - financial). "
               "Boundaries: the inducement assessment left with CW-067; travel and expense policy compliance is DP-209 (44), which "
               "reads this product for entertainment facts; the code of ethics and conflicts are DP-225 (38). Recipients are 02 "
               "parties (clients, plan fiduciaries, intermediary staff) through DP-240. "
               "Tailoring lever: aggregation basis of the limit (08 SME 6). Reference default: per recipient per calendar year. "
               "Tailoring lever: gifts received from product sponsors (08 SME 10). Reference default: logged and valued under the "
               "same limit. "
               "Taxonomy gap: 08 G&E Approval has no approval date; lateness is tested against Benefit Date and the approval status "
               "history at load. "
               "Drafting assumptions: the USD 300 limit (moving rule, confirm); Benefit Type Business Entertainment; G&E Approval Status values Pending and "
               "Rejected; Distribution Expense Category Gifts & Entertainment; the 80% near-limit band, 12-per-year frequency flag "
               "and 2% ledger tolerance. "
               "Decisions: CW-067, CW-220, CW-908. "
               "WP1 re-scope (CW-220): kept in place because live DP-209 depends on the id; name and owning domain 08 unchanged. "
               "Inputs dropped: 08 Inducement Assessment (CW-067), 08 Special Recipient Flags (now attributes of the item), 02 "
               "Individual, 02 Financial Professional and 02 Distributor Firm (wholesale; recipients are DP-240 parties), 03 Sales "
               "Role. Inputs added: 03 Advisor Role Assignment. Measures kept with their names: Recipient Year-to-Date Value, Limit "
               "Utilization %, Near-Limit Recipients, Limit Breach Count, Late or Missing Approval Count, Non-Cash Compensation "
               "Exception, Entertainment Frequency per Recipient, Spend by Recipient Firm, Special Recipient Items, Unreconciled G&E "
               "Spend; added: Items Given by Producing Advisors, Event-Linked Items. Dimensions dropped: 'Giver sales role and team' "
               "(renamed 'Giver advisor role and producing indicator'), 'Distribution channel'. Upstream drops DP-001, DP-002 "
               "(retired) and DP-005; adds DP-240 and DP-192. No semantic model source reads this product's measures. Semantic "
               "layer: SM-29 at WP2."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-039": dict(
        definition=("Every registration, qualification exam, Form U4 and U5 filing, disclosure event and continuing education "
                    "requirement of the firm's own registered representatives and investment adviser representatives, matched "
                    "to the states their covered clients live in. Licensing stops a representative serving a client or state they "
                    "are not registered for, files on time and tracks CE. Registrations are 08's; 03 License & Registration "
                    "Reference is a derived copy checked for currency. It owns no certified metric family."),
        business_questions=[
            "Which advisors cover clients who live in a state where the advisor is not registered?",
            "Which representatives are overdue or due in the next 60 days on continuing education?",
            "Were Form U5 filings made within 30 days of termination, and were Form U4 amendments for disclosure events made within 30 days?",
            "Which disclosure events are open, and which registrations are pending a qualifying exam?",
            "How many registered representatives and IARs do we have by registration category, and is the 03 copy of each registration current?",
        ],
        grain=("Registered person x registration category x jurisdiction (LIC-), with exams, uniform form filings, disclosure "
               "events and CE requirements as companion facts and the covered clients' states as a coverage bridge; SCD type 2 on "
               "registration status"),
        dimensions=["Registered person (DP-192)", "Advisor and advisor role (DP-009)", "Registering firm (DP-013)", "Registration category",
                    "Registration jurisdiction and body", "Registration status", "Form type", "Disclosure event type (restricted)",
                    "CE element", "Client state of residence (DP-240)", "Employment status (DP-192)"],
        measures=[
            ("Registered Headcount", "Count of distinct Registered Person with at least one Individual Registration with Registration Status = Approved at the as-of date, by Registration Category and Registering Firm.",
             _u("08", "Individual Registration", "License ID", "Registered Person", "Registration Category", "Registration Status", "Registering Firm")),
            ("Registration Coverage %", "Covered client parties whose state of residence (Country Subdivision of the 02 Postal Address of their primary Contact Point, DP-240) is a Registration Jurisdiction of an Approved registration of the Covering Advisor of the right category (broker-dealer agent or IAR) / covered client parties, by advisor.",
             _u("03", "Party Coverage Assignment", "Covered Party", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To")
             + _u("02", "Contact Point", "Contact Point ID", "Contact Point Party", "Primary Contact Point Indicator") + _u("02", "Postal Address", "Country Subdivision")
             + _u("08", "Individual Registration", "Registered Person", "Registration Jurisdiction", "Registration Category", "Registration Status")),
            ("Unregistered Coverage Exception", "Count of primary coverage assignments in force where the Covering Advisor holds no Approved Individual Registration in the client's state, by Covering Advisor and state (03 SME 4 registered-state check).",
             _u("03", "Party Coverage Assignment", "Covering Advisor", "Covered Party") + _u("08", "Individual Registration", "Registration Jurisdiction")
             + ["Registration Coverage %"]),
            ("CE Overdue Count", "Count of CE Requirement rows with CE Due Date before the as-of date and CE Status not Complete, by CE Element (Regulatory Element, Firm Element, IAR CE).",
             _u("08", "CE Requirement", "CE Person", "CE Registration", "CE Element", "CE Due Date", "CE Status")),
            ("CE Due Next 60 Days", "Count of CE Requirement rows with CE Status not Complete and CE Due Date within the next 60 days, with Credits Completed.",
             _u("08", "CE Requirement", "CE Due Date", "CE Status", "Credits Completed")),
            ("U5 Filing Timeliness", "Form U5 filings (Registration Filing Form Type = U5) with Form Filing Date within 30 calendar days of the person's DP-192 Termination Date / terminations of registered persons in the period, with Termination Reason.",
             _u("08", "Registration Filing", "Filed For Person", "Form Type", "Form Filing Date", "Termination Reason")
             + _u("20", "Employee", "Employee ID", "Termination Date", "Employment Status")),
            ("Late U4 Disclosure Amendments", "Count of Disclosure Event rows with Reported On Filing populated whose Form U4 amendment Form Filing Date is more than 30 days after Event Date, or with Reported On Filing empty more than 30 days after Event Date.",
             _u("08", "Disclosure Event", "Disclosure Event ID", "Event Date", "Reported On Filing") + _u("08", "Registration Filing", "Form Filing Date", "Form Type")),
            ("Open Disclosure Events", "Count of Disclosure Event rows with Disclosure Status not Resolved, by Disclosure Event Type (restricted view).",
             _u("08", "Disclosure Event", "Disclosure Event ID", "Disclosed Person", "Disclosure Event Type", "Disclosure Status")),
            ("Exam Pass Pending", "Count of Individual Registrations with Registration Status = Pending whose Qualifying Registration exam has no Exam Result = Pass, by Exam Code, with the latest Exam Date.",
             _u("08", "Exam Result", "Examined Person", "Exam Code", "Exam Attempt Sequence", "Exam Date", "Qualifying Registration", "Exam Result")
             + _u("08", "Individual Registration", "License ID", "Registration Status")),
            ("Registrations Terminated While Covering", "Count of Individual Registrations with Registration Termination Date before the as-of date whose Registered Person is still the Covering Advisor of a primary coverage assignment in force.",
             _u("08", "Individual Registration", "Registration Termination Date", "Registered Person") + _u("03", "Party Coverage Assignment", "Covering Advisor")),
            ("Registration Copy Stale", "Count of advisors whose 03 License & Registration Reference has Registration Copy As-Of more than 1 business day old, or Registered States, Registered Representative Indicator or Investment Adviser Representative Indicator differing from their Approved 08 registrations.",
             _u("03", "License & Registration Reference", "License Reference", "Registered Representative Indicator", "Investment Adviser Representative Indicator",
                "Registered States", "Registration Copy As-Of") + _u("08", "Individual Registration", "Registration Jurisdiction", "Registration Category")),
            ("Active Advisors Without Registration", "Count of 03 Advisor rows with Advisor Status = Active and Producing role whose Employee has no Approved Individual Registration.",
             _u("03", "Advisor", "Employee", "Advisor Status") + _u("08", "Individual Registration", "Registered Person", "Registration Status")),
        ],
        inputs=[
            ("08", "Individual Registration", ["License ID", "Registered Person", "Registering Firm", "Registration Category", "Registration Jurisdiction",
                                               "Registration Body", "Registration Status", "Registration Effective Date", "Registration Termination Date"]),
            ("08", "Exam Result", ["Examined Person", "Exam Code", "Exam Attempt Sequence", "Exam Date", "Qualifying Registration", "Exam Result"]),
            ("08", "Registration Filing", ["Filed For Person", "Form Type", "Form Filing Date", "Termination Reason", "Triggering Lifecycle Event"]),
            ("08", "Disclosure Event", ["Disclosure Event ID", "Disclosed Person", "Related Registration", "Disclosure Event Type", "Disclosure Status",
                                        "Event Date", "Reported On Filing"]),
            ("08", "CE Requirement", ["CE Person", "CE Registration", "CE Element", "CE Due Date", "Credits Completed", "CE Status"]),
            ("03", "License & Registration Reference", ["License Reference", "Registered Representative Indicator", "Investment Adviser Representative Indicator",
                                                        "Registered States", "Registration Copy As-Of"]),
            ("03", "Advisor", ["Employee", "Advisor Status"]),
            ("03", "Party Coverage Assignment", ["Covered Party", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To"]),
            ("02", "Contact Point", ["Contact Point ID", "Contact Point Party", "Primary Contact Point Indicator"]),
            ("02", "Postal Address", ["Country Subdivision"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Termination Date"]),
        ],
        upstream=["DP-009", "DP-192", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1, after the overnight CRD and IARD registration file",
        history="Registrations SCD type 2; exams, filings, disclosure events and CE kept as immutable facts; kept three years after termination at minimum and six years by firm policy (FINRA Rule 4511; SEC Rule 17a-3(a)(12))",
        classification="Restricted - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Registrations follow FINRA Rule 1210 and CE FINRA Rule 1240: every Registered Person, Examined Person, Filed For Person, Disclosed Person and CE Person resolves to a DP-192 employee, every Covering Advisor to a DP-009 advisor, every Covered Party and Contact Point Party to a DP-240 party, and every CE Registration and Related Registration to an 08 License ID.",
            "Registration Termination Date is empty or on or after Registration Effective Date, and a person has one registration per Registration Category and Registration Jurisdiction in force.",
            "Registered States on each 03 License & Registration Reference equals the set of Registration Jurisdiction values of the person's Approved 08 registrations on the copy's Registration Copy As-Of date.",
            "Registration Category, Registration Jurisdiction and Registration Status are populated on every registration, Form Type and Form Filing Date on every filing (Form U5 within 30 days of termination and U4 amendments within 30 days under FINRA By-Laws Article V), and CE Element, CE Due Date and CE Status on every CE requirement.",
            "Disclosure Event Type and Disclosure Status are returned only to registration and licensing compliance roles (they can reveal criminal or financial history, CD-344), every count by Disclosure Event Type has a cell of 10 or more or is suppressed, Individual CRD Number is not read, and no published row carries both a client key and a client state.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: special category (CD-344) for disclosure events in the restricted view; identity otherwise. Program ruling: "
               "this product is the restricted view for registration and licensing compliance and may read 08 Disclosure Event Type "
               "as a CW-213 exception, with a minimum cell of 10 on any count by event type. "
               "Boundaries: licensing and registration of own representatives are 08; the role requirement is 20; 03 holds derived "
               "copies (CW-072). The client state of residence comes from DP-240 (03 SME 4). Live DP-200 reads this product for "
               "registered-role eligibility, and DP-078 and DP-404 read it; DP-391 reads the 08 registrations through DP-009. "
               "FOP+CORP withdrew DP-596 in this product's favor. State notice filings of the firm are 38 (CW-069). "
               "Tailoring lever: registered-state check (03 SME 4). Reference default: every advisor covering a client must hold "
               "the agent or IAR registration of the client's state of residence. "
               "Taxonomy gap: 08 Disclosure Event links to the Form U4 amendment only by Reported On Filing; the filing date is "
               "taken from the 08 Registration Filing it names. "
               "Drafting assumptions: Registration Status values Approved, Pending and Terminated; Form Type U5; Exam Result Pass; "
               "Disclosure Status Resolved; CE Status Complete; the 30- and 60-day windows. "
               "Decisions: CW-069, CW-072, CW-220, CW-908; CD-344. "
               "WP1 re-scope (CW-072, CW-220): kept in place because live DP-200 depends on the id; name and owning domain 08 "
               "unchanged; classification raised to Restricted - Personal Data for the disclosure event view. Inputs dropped: 08 "
               "Certification & Competence (SM&CR), 03 Sales Person and Sales Role (wholesale 03), 07 Territory Salesperson "
               "Assignment and Territory Geographic Unit (07 retired, CW-907). Inputs added: 03 Advisor, 03 Party Coverage "
               "Assignment, 02 Contact Point and Postal Address. Measures kept with their names: Registration Coverage %, "
               "Unregistered Coverage Exception (now by client state, not territory), CE Overdue Count, CE Due Next 60 Days, U5 "
               "Filing Timeliness, Open Disclosure Events, Exam Pass Pending, Registered Headcount; dropped: Certificate Renewals "
               "Due (SM&CR, no reader found); added: Late U4 Disclosure Amendments, Registrations Terminated While Covering, "
               "Registration Copy Stale, Active Advisors Without Registration. Dimensions dropped: 'Primary sales role', 'Sales "
               "function', 'Territory', 'SM&CR population', 'Certification function'; added: advisor role, client state. Upstream "
               "adds DP-192 and DP-240. No semantic model source reads this product's measures. Semantic layer: SM-29 at WP2."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-069": dict(
        definition=("Regulatory communications (tailored shareholder reports, prospectuses, notices) and periodic client "
                    "documents by type, delivery method (print, e-delivery, householded, suppressed) and route, with e-delivery "
                    "adoption, householding savings, returned mail and the print, postage and processing cost borne by the funds "
                    "and the firm, for every account type. Communications and finance decide e-delivery campaigns and see that "
                    "each mailing met its deadline. Delivery facts come from DP-382; the mailing household is the 13 Householding "
                    "Group, not the 02 or 47 household. It owns no certified metric family."),
        business_questions=[
            "How many pieces did we deliver this month by communication type and delivery method, and what share went electronically?",
            "What did print, postage and processing cost per piece, in total and by who bore it, and what did e-delivery and householding avoid?",
            "Which mailings missed their regulatory deadline, and how much returned mail did they produce?",
            "Were householding revocations honored within 30 days, and were client documents furnished on time?",
            "Were shareholder notices sent with the required notice period, and how are prospectuses delivered?",
        ],
        grain=("Communication or document type x delivery method x month (aggregate), built from DP-382 recipient delivery records "
               "and investor documents, with communication distributions, production runs and cost items as companion facts"),
        dimensions=["Month (DP-013)", "Communication type and regulatory basis", "Investor document category", "Product and share class (DP-004)",
                    "Delivery method", "Print / delivery vendor", "Funding source (fund-borne / firm-borne)", "Account type and registration type (DP-093)",
                    "Prospectus delivery basis and trigger", "Notice type", "Document regulatory basis"],
        measures=[
            ("Pieces by Delivery Method", "Count of Recipient Delivery Record rows in the month by Recipient Delivery Method and the Communication Type of the distribution's Shareholder Communication, plus Investor Document rows by Delivery Method and Investor Document Category.",
             _u("13", "Recipient Delivery Record", "Distribution Job", "Recipient Account", "Recipient Delivery Method")
             + _u("13", "Communication Distribution", "Distribution Job ID", "Distributed Communication", "Mail Date")
             + _u("13", "Shareholder Communication", "Communication ID", "Communication Type")
             + _u("13", "Investor Document", "Investor Document ID", "Delivery Method", "Period End Date") + _u("13", "Investor Document Definition", "Investor Document Category")),
            ("E-Delivery Election Coverage % (from DP-382)", "DP-382's published E-Delivery Election Coverage % (accounts with an E-Delivery Election in force with Delivery Preference = Electronic for the Election Document Scope), shown by scope and Account Type of open DP-093 accounts; read, not re-derived.",
             _u("13", "E-Delivery Election", "Delivery Election ID", "Election Account", "Election Document Scope", "Delivery Preference", "Consent Captured Timestamp", "Election Revoked Timestamp")
             + _u("15", "Account", "Account ID", "Account Status", "Account Type")),
            ("Householding Suppression Rate", "Recipient deliveries suppressed because a Householding Group with Householding Status = Active covers the Recipient Account for the Householded Document Scope / deliveries before suppression, by Communication Type.",
             _u("13", "Householding Group", "Householding Group ID", "Member Accounts", "Householded Document Scope", "Householding Status")
             + _u("13", "Recipient Delivery Record", "Recipient Delivery Status") + ["Pieces by Delivery Method"]),
            ("Suppression Rate", "Documents Suppressed Count / (Documents Produced Count + Documents Suppressed Count) of Production Run rows in the month, by Print / Delivery Vendor, with the Suppression Reason mix of Investor Documents.",
             _u("13", "Production Run", "Production Run ID", "Documents Produced Count", "Documents Suppressed Count", "Print / Delivery Vendor", "Run Date")
             + _u("13", "Investor Document", "Suppression Reason")),
            ("Print & Postage Cost per Piece", "Sum of Expense Amount of 10 Distribution Cost Item rows with Distribution Expense Category in Print, Postage or Communication Processing in the month / printed and mailed pieces in the month, by Communication Type and Funding Source.",
             _u("10", "Distribution Cost Item", "Distribution Cost Item ID", "Distribution Expense Category", "Expense Amount", "Funding Source", "Service Period Start", "Source Record")
             + ["Pieces by Delivery Method"]),
            ("Total Communication Cost", "Sum of Expense Amount of the communication cost items in the month, by Funding Source (fund-borne under the fund's expense allocation, firm-borne), Bearing Legal Entity and Direct Product / Share Class.",
             _u("10", "Distribution Cost Item", "Expense Amount", "Funding Source", "Bearing Legal Entity", "Direct Product / Share Class")),
            ("Avoided Cost", "(Pieces delivered electronically + pieces suppressed by householding) x Print & Postage Cost per Piece of the month, by Communication Type.",
             _u("13", "Recipient Delivery Record", "Recipient Delivery Method") + ["Print & Postage Cost per Piece", "Householding Suppression Rate", "Pieces by Delivery Method"]),
            ("Failed or Returned Deliveries (from DP-382)", "DP-382's published Failed or Returned Deliveries for the month, shown per printed piece (/ Pieces by Delivery Method) by Communication Type.",
             _u("13", "Recipient Delivery Record", "Returned Mail Date", "Recipient Delivery Method") + ["Pieces by Delivery Method"]),
            ("Communication Distributions Missing Deadline (from DP-382)", "DP-382's published Communication Distributions Missing Deadline (Deadline Met Indicator = N) for the month, by Communication Type and Communication Regulatory Basis, against Required Delivery Deadline.",
             _u("13", "Communication Distribution", "Deadline Met Indicator", "Mail Date", "Audience Record Date")
             + _u("13", "Shareholder Communication", "Communication Type", "Communication Regulatory Basis", "Required Delivery Deadline")),
            ("Householding Revocations Overdue (from DP-382)", "DP-382's published Householding Revocations Overdue (individual delivery not resumed by Individual Delivery Resume Due Date, 30 days under Rule 30e-1(f)), with Annual Revocation Notice Date currency.",
             _u("13", "Householding Group", "Householding Revocation Date", "Individual Delivery Resume Due Date", "Annual Revocation Notice Date")),
            ("Documents Delivered Late (from DP-382)", "DP-382's published Documents Delivered Late (Delivered Date after the Recipient Furnish Deadline Rule of the Investor Document Definition) for the month, by Investor Document Category.",
             _u("13", "Investor Document", "Delivered Date", "Period End Date", "Document Definition") + _u("13", "Investor Document Definition", "Document Definition Code", "Recipient Furnish Deadline Rule", "Investor Document Category")),
            ("Tailored Shareholder Report Timeliness", "Tailored Shareholder Reports whose Mail Date is within 60 days of Report Period End Date and whose Website Availability Date is on or before it (Rule 30e-1, Form N-CSR) / reports due in the month.",
             _u("13", "Tailored Shareholder Report", "TSR Period Type", "Form N-CSR Filing Date", "Website Availability Date")
             + _u("13", "Shareholder Communication", "Report Period End Date") + _u("13", "Communication Distribution", "Mail Date")),
            ("Prospectus Delivery Mix and Cost", "Prospectus pieces by Prospectus Delivery Basis (summary prospectus, statutory prospectus, notice and access) and Prospectus Delivery Trigger, with their share of Total Communication Cost.",
             _u("13", "Prospectus Delivery", "Prospectus Delivery Basis", "Prospectus Delivery Trigger") + _u("13", "Communication Distribution", "Notice-and-Access Indicator")
             + ["Pieces by Delivery Method", "Total Communication Cost"]),
            ("Notice Period Met Rate", "Shareholder Notices whose Mail Date is at least Minimum Notice Period (Days) before Change Effective Date / notices mailed in the month, by Notice Type.",
             _u("13", "Shareholder Notice", "Notice Type", "Minimum Notice Period (Days)", "Change Effective Date", "Shareholder Approval Required Indicator")
             + _u("13", "Communication Distribution", "Mail Date")),
            ("Free Redemption Window Check", "For notices of a change that is adverse to shareholders (Notice Type a fee increase or strategy change, Shareholder Approval Required Indicator not Y), Y when the Mail Date leaves at least the Minimum Notice Period (Days) for shareholders to redeem before Change Effective Date without a sales charge.",
             _u("13", "Shareholder Notice", "Notice Type", "Shareholder Approval Required Indicator", "Minimum Notice Period (Days)", "Change Effective Date")
             + _u("13", "Communication Distribution", "Mail Date")),
        ],
        inputs=[
            ("13", "Shareholder Communication", ["Communication ID", "Communication Type", "Communication Regulatory Basis", "Covered Share Classes",
                                                 "Report Period End Date", "Required Delivery Deadline", "Communication Status"]),
            ("13", "Tailored Shareholder Report", ["TSR Period Type", "Form N-CSR Filing Date", "Website Availability Date"]),
            ("13", "Prospectus Delivery", ["Prospectus Delivery Basis", "Prospectus Delivery Trigger"]),
            ("13", "Shareholder Notice", ["Notice Type", "Minimum Notice Period (Days)", "Change Effective Date", "Shareholder Approval Required Indicator"]),
            ("13", "Communication Distribution", ["Distribution Job ID", "Distributed Communication", "Audience Record Date", "Notice-and-Access Indicator",
                                                  "Mail Date", "Deadline Met Indicator"]),
            ("13", "Recipient Delivery Record", ["Distribution Job", "Recipient Account", "Recipient Delivery Method", "Recipient Delivery Status", "Returned Mail Date"]),
            ("13", "Investor Document", ["Investor Document ID", "Document Definition", "Document Account", "Period End Date", "Delivery Method",
                                         "Delivered Date", "Suppression Reason"]),
            ("13", "Investor Document Definition", ["Document Definition Code", "Investor Document Category", "Recipient Furnish Deadline Rule"]),
            ("13", "Production Run", ["Production Run ID", "Print / Delivery Vendor", "Run Date", "Documents Produced Count", "Documents Suppressed Count"]),
            ("13", "E-Delivery Election", ["Delivery Election ID", "Election Account", "Election Document Scope", "Delivery Preference",
                                           "Consent Captured Timestamp", "Election Revoked Timestamp"]),
            ("13", "Householding Group", ["Householding Group ID", "Member Accounts", "Householded Document Scope", "Householding Status",
                                          "Householding Revocation Date", "Individual Delivery Resume Due Date", "Annual Revocation Notice Date"]),
            ("10", "Distribution Cost Item", ["Distribution Cost Item ID", "Distribution Expense Category", "Source Record", "Bearing Legal Entity",
                                              "Funding Source", "Direct Product / Share Class", "Service Period Start", "Expense Amount"]),
            ("15", "Account", ["Account ID", "Account Status", "Account Type"]),
        ],
        upstream=["DP-382", "DP-004", "DP-093", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 8 after month-end, after the cost items are booked; deadline status of each distribution daily by 7am ET",
        history="Monthly aggregates kept seven years; delivery detail stays in DP-382",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Account statement documents follow FINRA Rule 2231 (at least quarterly): every Distribution Job, Investor Document and Production Run resolves to DP-382, every Covered Share Classes and Direct Product / Share Class value to DP-004, every Recipient Account, Election Account and Document Account to a DP-093 Account ID, and every Bearing Legal Entity to a DP-013 legal entity.",
            "E-Delivery Election periods of one account and Election Document Scope do not overlap, and Householding Revocation Date is on or after the group's start.",
            "Pieces by Delivery Method for the month equals the DP-382 Documents Issued and recipient deliveries for the same month and types with no difference, and Total Communication Cost ties to the 10 ledger cost items of the communication categories within 1%.",
            "Communication Type, Required Delivery Deadline and Mail Date are populated on every distribution, Delivery Method on every document, and Expense Amount, Funding Source and Distribution Expense Category on every cost item.",
            "Only aggregates by communication type, method, vendor and month are published; account keys are used inside the aggregation and never published, so the product carries no personal data.",
            "The month is published by business day 8 after month-end and is not changed after publication except by a dated restatement.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: none in the published product. pii is N although account keys (Recipient Account, Election Account, "
               "Document Account, Member Accounts) are read: they are used only to aggregate by account type and method, and no "
               "account-level row is published; the validator warning on those attributes is justified here, and the other "
               "flagged attributes (Communication ID, TSR Period Type, Prospectus Delivery Basis, Notice Type, Distribution Job ID) "
               "carry the catalog note 'Object PII tier: No PII'. "
               "Boundaries: delivery evidence is conformed by DP-382 (CW-223); the mailing household is the 13 Householding Group, "
               "not the 02 client household or the 47 fee household (CW-027). Intermediary distribution requests, notice cascades "
               "and intermediary communication fee invoices are 29 (CW-088) and leave this product. Live DP-106 reads this product "
               "and gains DP-382 (RESPEC). DP-399 checks disclosure delivery; this product measures delivery mix, timeliness and "
               "cost. "
               "Tailoring lever: household statements (13 SME 5). Reference default: householding of regulatory documents by "
               "address with implied consent; household statements offered. "
               "Tailoring lever: annual privacy notice (13 SME 6). Reference default: not mailed where the Regulation S-P exception "
               "applies. "
               "Taxonomy gap: 10 Distribution Cost Item has no link to the communication or production run it pays for beyond "
               "Source Record; cost per piece is allocated by month and communication category. "
               "Drafting assumptions: Delivery Preference Electronic; Householding Status Active; Distribution Expense Category "
               "values Print, Postage and Communication Processing; the 30-day revocation and 60-day TSR standards; the 1% ledger "
               "tolerance. "
               "Decisions: CW-027, CW-088, CW-223, CW-913, CW-220. "
               "WP1 re-scope (CW-220): kept in place because live DP-106 depends on the id; name and owning domain 13 unchanged. "
               "Inputs dropped: 13 EU/UK Investor Information Provision (CW-913), 13 Intermediary Distribution Request, Notice "
               "Cascade and Intermediary Communication Fee Invoice (CW-088), 13 Mail Hold (read by DP-382 and DP-324). Inputs "
               "kept: the 13 communication, delivery, document, production, election and householding objects, now read as DP-382 "
               "publishes them, and 10 Distribution Cost Item. Measures kept with their names: Pieces by Delivery Method, "
               "Householding Suppression Rate, Suppression Rate, Print & Postage Cost per Piece, Total Communication Cost, "
               "Avoided Cost, Prospectus Delivery Mix and Cost, Notice Period Met Rate, Free Redemption Window Check "
               "(SM-07 reads Pieces by Delivery Method, Total Communication Cost, Avoided Cost and Print & Postage Cost per Piece); "
               "renamed to the DP-382 owner names (program ruling, facts owned once): E-Delivery Adoption Rate becomes E-Delivery "
               "Election Coverage % (from DP-382), Undeliverable Rate becomes Failed or Returned Deliveries (from DP-382), Deadline "
               "Met Rate becomes Communication Distributions Missing Deadline (from DP-382), Householding Revocation Timeliness "
               "becomes Householding Revocations Overdue (from DP-382), Document Furnish Timeliness becomes Documents Delivered "
               "Late (from DP-382) (SM-07 cites the old names in its excluded-metric notes); dropped: Intermediary Fee Cost per "
               "Position and Cascade Confirmation Rate (also cited at SM-07 line 958) (CW-088; SM-07 metric source 'Intermediary "
               "Fee Cost per Beneficial Owner Account' already had no matching measure); added: Tailored Shareholder Report "
               "Timeliness. Dimensions dropped: 'Delivery route (direct registered / intermediary beneficial owner)', 'Intermediary "
               "(invoicing party)', 'Notice type and change classification' (renamed 'Notice type'), 'Cascading platform / nominee "
               "and cascade method'. Upstream drops DP-043 (retired), DP-001 and DP-007; adds DP-382 and DP-093. Model "
               "models_c10_shareholder_ops DP-069: entities intermediary_fee_invoice and intermediary_distribution (SM-07) lose "
               "their backing objects."
               " WP2 retirement sweep (CW-209): SM-07, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-078": dict(
        definition=("Evidence that business communications are captured, retained and supervised: the approved-channel register "
                    "(advisors' own social accounts included), archived messages and calls with their retention rule and legal hold "
                    "status, and lexicon and policy surveillance alerts with their review and disposition, joined to the registered "
                    "population, their supervisors and the activities recorded in the CRM. Compliance sees capture gaps, unreviewed "
                    "alerts and records at risk of early deletion (SEC Rule 17a-4(b)(4), FINRA Rule 3110(b)(4)). It owns no certified "
                    "metric family."),
        business_questions=[
            "Which registered employees produced no captured communications in the period, and which recorded advisor activities have no archive reference?",
            "Which channels and social accounts are used for business without approval or without capture?",
            "How many surveillance alerts are open, how old are they, and how many were escalated?",
            "Which captured records will expire before their retention period, and how many are under legal hold?",
            "How many in-scope employees does the capture program cover, by legal entity and supervisor?",
        ],
        grain=("Captured communication record (ARC-) with its capture channel and retention, joined to the approved channel, the "
               "captured employee and the surveillance alerts on it; daily employee x channel capture facts; immutable records with "
               "alert review status history"),
        dimensions=["Capture date and period", "Monitored employee and supervisor (DP-192, DP-391)", "Employing legal entity (DP-013)",
                    "Org unit and job family (DP-192)", "Registration category (DP-039)", "Channel type and capture method",
                    "Alert source and policy / lexicon", "Alert review status and disposition", "Retention record class and governing requirement (21)",
                    "Social platform and account use type"],
        measures=[
            ("In-Scope Employee", "Count of distinct employees with Employment Status = Active and an 08 Individual Registration with Registration Status = Approved, or a 03 Advisor row with Advisor Status = Active, at the as-of date, by Employing Legal Entity.",
             _u("20", "Employee", "Employee ID", "Employment Status", "Employing Legal Entity") + _u("08", "Individual Registration", "Registered Person", "Registration Status")
             + _u("03", "Advisor", "Employee", "Advisor Status")),
            ("Captured Communication Count", "Count of Captured Communication Record rows with Communication Timestamp in the period, by Capture Channel and Captured Employee.",
             _u("08", "Captured Communication Record", "Communication Record ID", "Communication Timestamp", "Capture Channel", "Captured Employee")),
            ("Silent Employee Flag", "Y for an In-Scope Employee with no Captured Communication Record as Captured Employee in the period (10 business days by default) while their Employment Status is Active.",
             _u("08", "Captured Communication Record", "Captured Employee", "Communication Timestamp") + ["In-Scope Employee"]),
            ("Recorded Activity Capture Gap", "Count of 03 Advisor Activity rows in the period with Interaction Medium in Email, Text Message, Chat, Social Media or Recorded Phone whose Activity Capture has Recorded Communication Indicator = Y and Communication Archive Reference empty or not resolving to a Communication Record ID, by Activity Owner.",
             _u("03", "Advisor Activity", "Activity ID", "Activity Type", "Interaction Medium", "Activity Start Timestamp", "Activity Owner")
             + _u("03", "Activity Capture", "Communication Archive Reference", "Recorded Communication Indicator", "Capture Method")
             + _u("08", "Captured Communication Record", "Communication Record ID")),
            ("Unapproved Channel Activity", "Count of Captured Communication Records and recorded Advisor Activities in the period on a Capture Channel or Interaction Medium with no Approved Communication Channel of the same Channel Type with Approved for Business Use Indicator = Y in force for the employee (Approval Effective From on or before, Approval Effective To empty or after the timestamp).",
             _u("08", "Approved Communication Channel", "Channel Approval ID", "Channel Type", "Account Owner", "Approved for Business Use Indicator", "Approval Effective From", "Approval Effective To")
             + _u("08", "Captured Communication Record", "Capture Channel", "Captured Employee") + _u("03", "Advisor Activity", "Interaction Medium")),
            ("Open Alert Count and Age", "Count of Surveillance Alert rows with Alert Review Status not Closed at the as-of date, with mean and maximum age in business days since the Communication Timestamp of the Flagged Communication, by Alert Source and Policy / Lexicon Hit.",
             _u("08", "Surveillance Alert", "Alert ID", "Alert Review Status", "Alert Source", "Policy / Lexicon Hit", "Flagged Communication")
             + _u("08", "Captured Communication Record", "Communication Timestamp")),
            ("Alert Escalation Rate", "Surveillance Alerts closed in the period with Alert Disposition = Escalated or Related Complaint populated / alerts closed in the period, by Alert Source.",
             _u("08", "Surveillance Alert", "Alert Disposition", "Related Complaint", "Alert Source", "Alert Review Status")),
            ("Retention Shortfall Flag", "Y for a Captured Communication Record whose Retention Expiry Date is earlier than Communication Timestamp plus the Retention Period (Years) of its 21 Retention Rule (three years, the first two easily accessible, for broker-dealer communications under SEC Rule 17a-4(b)(4); five years for adviser records under Rule 204-2), the period always taken from the 21 rule.",
             _u("08", "Captured Communication Record", "Retention Rule", "Retention Expiry Date", "Communication Timestamp")
             + _u("21", "Retention Rule", "Retention Rule ID", "Record Class", "Governing Requirement", "Retention Period (Years)")),
            ("Legal Hold Exposure", "Count of Captured Communication Records with Legal Hold Indicator = Y, and of those with Retention Expiry Date in the next 90 days (deletion must be suspended).",
             _u("08", "Captured Communication Record", "Legal Hold Indicator", "Retention Expiry Date")),
            ("Unsupervised Social Account Flag", "Y for an Approved Communication Channel with Channel Type = Social Media and Account Use Type = Business whose Capture Method is empty or None, or whose Firm Social Media Account is empty while Social Platform is populated.",
             _u("08", "Approved Communication Channel", "Channel Type", "Account Use Type", "Capture Method", "Firm Social Media Account", "Social Platform")),
            ("Employees Without Supervisor Assignment", "Count of In-Scope Employees with no 03 Supervisory Assignment in force at the as-of date (DP-391), the supervisor who reviews their communications.",
             _u("03", "Supervisory Assignment", "Supervised Person", "Assigned Supervisor", "Assignment Effective From", "Assignment Effective To") + ["In-Scope Employee"]),
            ("Alerts per 1,000 Captured Communications", "Surveillance Alerts generated on records captured in the period / Captured Communication Count x 1,000, by Capture Channel.",
             _u("08", "Surveillance Alert", "Flagged Communication", "Monitored Employee") + ["Captured Communication Count"]),
        ],
        inputs=[
            ("08", "Approved Communication Channel", ["Channel Approval ID", "Channel Type", "Social Platform", "Firm Social Media Account", "Account Owner",
                                                      "Account Use Type", "Approved for Business Use Indicator", "Capture Method",
                                                      "Approval Effective From", "Approval Effective To"]),
            ("08", "Captured Communication Record", ["Communication Record ID", "Capture Channel", "Captured Employee", "Communication Timestamp",
                                                     "Retention Rule", "Retention Expiry Date", "Legal Hold Indicator"]),
            ("08", "Surveillance Alert", ["Alert ID", "Alert Source", "Policy / Lexicon Hit", "Flagged Communication", "Monitored Employee",
                                          "Alert Review Status", "Alert Disposition", "Related Complaint"]),
            ("08", "Individual Registration", ["License ID", "Registered Person", "Registration Category", "Registration Status"]),
            ("21", "Retention Rule", ["Retention Rule ID", "Record Class", "Governing Requirement", "Retention Period (Years)"]),
            ("03", "Advisor", ["Employee", "Advisor Status"]),
            ("03", "Advisor Activity", ["Activity ID", "Activity Type", "Interaction Medium", "Activity Start Timestamp", "Activity Owner"]),
            ("03", "Activity Capture", ["Communication Archive Reference", "Recorded Communication Indicator", "Capture Method"]),
            ("03", "Supervisory Assignment", ["Supervised Person", "Assigned Supervisor", "Assignment Effective From", "Assignment Effective To"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Employing Legal Entity", "Home Org Unit", "Job Family"]),
        ],
        upstream=["DP-009", "DP-010", "DP-039", "DP-391", "DP-192", "DP-101", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1 for captured records, alerts and activities of the prior business day",
        history="Capture facts and alerts immutable with review status history; the channel register SCD type 2; kept six years by firm policy (SEC Rule 17a-4(b)(4) requires three; FINRA Rule 4511)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Captured Employee, Monitored Employee, Account Owner, Activity Owner and Supervised Person resolves to a DP-192 Employee ID, every Retention Rule to a 21 Retention Rule ID (DP-101), every Flagged Communication to a Communication Record ID, and every Related Complaint to an 08 Complaint ID.",
            "Approved Communication Channel periods do not overlap for the same Account Owner, Channel Type and Social Platform, and Approval Effective To is empty or on or after Approval Effective From.",
            "Every Communication Archive Reference on 03 Activity Capture resolves to a Communication Record ID, and every Flagged Communication of a Surveillance Alert resolves to a captured record whose Captured Employee equals the alert's Monitored Employee.",
            "Capture Channel, Captured Employee, Communication Timestamp, Retention Rule and Retention Expiry Date are populated on every captured record, and Alert Source, Alert Review Status and Alert Disposition (once closed) on every alert.",
            "Message content, Participants and Client Involved are not read (content can carry special-category facts, CD-344); employee keys are published to compliance surveillance only.",
            "The prior business day is complete by 7am ET on T+1.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (employees); message content restricted to surveillance and not read here. "
               "Boundaries: SEC Rule 17a-4(b)(4) and FINRA Rule 3110(b)(4) capture and supervision of communications; the retention "
               "schedule is 21 (CW-068), conformed by DP-101; the registered population is DP-039's; the CRM activity record is "
               "03 (DP-010); supervisors are DP-391's; firm social accounts are 04 (DP-410) and advisors' own social accounts the 08 "
               "Approved Communication Channel (CW-067). Live DP-228 Trade Surveillance & Suspicious Activity Reporting reads this "
               "product's 08 Alert ID (lead ruling 2026-10-15: DP-078 stays in place as DP-228's upstream). Market-abuse "
               "surveillance is 38 (CW-163). "
               "Tailoring lever: off-channel communications policy. Reference default: text messaging permitted only through the "
               "captured firm application; every other text channel is unapproved. "
               "Tailoring lever: silent-employee window. Reference default: 10 business days. "
               "Taxonomy gap: 08 Surveillance Alert has no alert generated date; age is measured from the flagged communication's "
               "timestamp. "
               "Drafting assumptions: Interaction Medium values Email, Text Message, Chat, Social Media and Recorded Phone; Channel "
               "Type Social Media; Account Use Type Business; Alert Disposition Escalated; Alert Review Status Closed; the 90-day "
               "legal hold window. "
               "Decisions: CW-067, CW-068, CW-073, CW-138, CW-163, CW-220. "
               "WP1 re-scope (CW-220): kept in place because live DP-228 depends on the id; name and owning domain 08 unchanged; "
               "primary function FN-13 (retired) becomes FN-68 in the register. Inputs dropped: 08 Retention Rule (moved to 21, "
               "now read as 21 Retention Rule), 08 Social Media Account (firm accounts are 04, advisors' accounts are 08 Approved "
               "Communication Channel), 20 Employee Reporting Line (the supervisor is 03 Supervisory Assignment), 09 Internal Legal "
               "Entity (Employing Legal Entity on 20 Employee), 03 Sales Person, Sales Activity and Internal Participant (wholesale "
               "03). Inputs added: 21 Retention Rule, 03 Advisor, 03 Advisor Activity, 03 Supervisory Assignment. Measures kept "
               "with their names: In-Scope Employee, Captured Communication Count, Silent Employee Flag, Recorded Activity Capture "
               "Gap, Unapproved Channel Activity, Open Alert Count and Age, Alert Escalation Rate, Retention Shortfall Flag, Legal "
               "Hold Exposure, Unsupervised Social Account Flag (the model models_c4_compliance notes cite them); added: Employees "
               "Without Supervisor Assignment, Alerts per 1,000 Captured Communications. Dimension 'Monitored employee and line "
               "manager (supervisor)' renamed 'Monitored employee and supervisor'; 'Registration category and jurisdiction' "
               "becomes 'Registration category'. Upstream adds DP-391 and DP-101. Semantic layer: SM-29 at WP2."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-079": dict(
        definition=("The operational terms needed to trade, settle and service each own share class on the brokerage platform, "
                    "through the transfer agent and at intermediaries: dealing frequency, cut-off and calendar, settlement periods, "
                    "valuation point, listings and ETF characteristics, income distribution, currency hedging, minimums and sales "
                    "charges, US tax status, identifiers and the dealer setups of the thin intermediary channel. Platforms, the TA "
                    "and intermediaries trade on one published set of terms; the terms are mastered in 01 and conformed by DP-004. "
                    "It owns no certified metric family."),
        business_questions=[
            "When is each share class's next dealing date, and which weekdays in the next 90 days are not dealing days?",
            "Which open-end share classes would pay redemptions later than seven days, and which settle beyond T+1?",
            "Which share classes have incomplete dealing, valuation or distribution terms, and which ETF classes lack a primary listing?",
            "Which dealing or operational terms change in the next 30 days?",
            "Which share classes lack a Fund/SERV code or a CUSIP, and which dealer setups lack an NSCC participant number?",
        ],
        grain=("Share class x effective date (SCD type 2) with the dealing, valuation, listing, distribution, hedging, eligibility, "
               "charge and tax terms of the share class and its product, and dealer setups (partner x TA dealer number) as a "
               "companion table"),
        dimensions=["Product and share class (DP-004)", "Vehicle type", "US fund type", "Share class currency", "Dealing frequency",
                    "Cut-off time zone", "Dealing calendar (DP-013)", "Listing exchange", "Distribution policy", "Hedged / unhedged",
                    "Partner firm and dealer setup (DP-001, DP-005)", "Dealing route", "Account structure", "Effective date"],
        measures=[
            ("Next Dealing Date", "First Calendar Date after the as-of date with Day Type = Business Day in the Base Business Calendar of the share class's Dealing Calendar Rule (Dealing Calendar of its Dealing Terms), not closed under its Market Closure Calendars and fitting the Dealing Day Pattern.",
             _u("01", "Dealing Terms", "Dealing Calendar", "Dealing Frequency") + _u("09", "Dealing Calendar Rule", "Dealing Calendar ID", "Base Business Calendar", "Market Closure Calendars", "Dealing Day Pattern")
             + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
            ("Non-Dealing Days (Next 90 Days)", "Count of weekdays in the next 90 days that are not dealing days under the share class's Dealing Calendar Rule, listed by Calendar Date and Holiday Name for platform and partner circulation.",
             _u("09", "Calendar Date", "Calendar Date", "Day Type", "Holiday Name") + _u("09", "Dealing Calendar Rule", "Dealing Calendar ID", "Market Closure Calendars")),
            ("Redemption Payment Limit Flag", "Y for a share class of a registered open-end fund (US Fund Type open-end, Vehicle Type mutual fund) whose Redemption Settlement Period exceeds 7 calendar days (Investment Company Act Section 22(e)).",
             _u("01", "Dealing Terms", "Redemption Settlement Period") + _u("01", "Regulatory Classification", "US Fund Type") + _u("01", "Investment Product", "Product ID", "Vehicle Type")),
            ("Classes Settling Beyond T+1", "Count of open share classes whose Subscription Settlement Period or Redemption Settlement Period exceeds 1 business day, by Vehicle Type and Pricing Basis (ETF secondary trades settle T+1 under Exchange Act Rule 15c6-1).",
             _u("01", "Dealing Terms", "Subscription Settlement Period", "Redemption Settlement Period", "Pricing Basis") + _u("01", "Investment Product", "Vehicle Type")
             + _u("01", "Share Class", "Share Class ID", "Share Class Status")),
            ("Dealing Reference Completeness %", "Open share classes with Dealing Frequency, Dealing Cut-off Time, Cut-off Time Zone, Dealing Calendar, Valuation Frequency, Valuation Point, Distribution Policy and Currency Hedged Indicator populated / open share classes (Share Class Status = Open).",
             _u("01", "Dealing Terms", "Dealing Frequency", "Dealing Cut-off Time", "Cut-off Time Zone", "Dealing Calendar")
             + _u("01", "Valuation Terms", "Valuation Frequency", "Valuation Point") + _u("01", "Income Distribution", "Distribution Policy")
             + _u("01", "Currency Hedging", "Currency Hedged Indicator") + _u("01", "Share Class", "Share Class ID", "Share Class Status")),
            ("ETF Classes Without Primary Listing", "Count of open share classes of products with ETF Characteristics (ETF Share Class Indicator = Y or Vehicle Type = ETF) with no Listing with Primary Listing Indicator = Y and Delisting Date empty.",
             _u("01", "ETF Characteristics", "ETF Share Class Indicator", "Replication Method") + _u("01", "Listing", "Listing Exchange", "Exchange Ticker", "Primary Listing Indicator", "Delisting Date")
             + _u("01", "Investment Product", "Vehicle Type")),
            ("Upcoming Change Count", "Count of 01 Lifecycle Event rows with Event Effective Date in the next 30 days on own share classes, by Lifecycle Event Type (dealing, valuation, listing, distribution, hedging, tax and successor changes).",
             _u("01", "Lifecycle Event", "Lifecycle Event Type", "Event Effective Date", "Successor Product / Share Class", "Lifecycle Status")),
            ("Classes With Sales Charges", "Count of open share classes with Maximum Entry Charge or Maximum Exit Charge above zero or a CDSC Schedule populated, by Share Class Type.",
             _u("01", "Investor Transaction Charge", "Maximum Entry Charge", "Maximum Exit Charge", "CDSC Schedule") + _u("01", "Share Class", "Share Class Type")),
            ("Minimum Investment Coverage %", "Open share classes with Minimum Initial Investment and Minimum Subsequent Investment populated (zero allowed) / open share classes, by Eligible Investor Type.",
             _u("01", "Investor Eligibility", "Eligible Investor Type", "Minimum Initial Investment", "Minimum Subsequent Investment") + _u("01", "Share Class", "Share Class Status")),
            ("Fund/SERV and CUSIP Coverage %", "Open mutual fund share classes with DTCC Fund/SERV Code populated / open mutual fund share classes, and open share classes with CUSIP populated / open share classes.",
             _u("01", "External Cross-Reference", "DTCC Fund/SERV Code", "Bloomberg Ticker") + _u("01", "Security Identifier", "CUSIP", "ISIN")
             + _u("01", "Share Class", "Share Class Status")),
            ("Tax Status Gaps", "Count of open products with US Tax Classification empty, or with FATCA GIIN empty where Tax Residence Country is not US.",
             _u("01", "Product Tax Status", "US Tax Classification", "FATCA GIIN", "Tax Residence Country", "Tax Transparency Indicator")),
            ("Dealer Setups Without NSCC Participant Number", "Count of Partner Dealer Setup rows with Dealer Setup Status = Active and Dealing Route = NSCC Fund/SERV whose NSCC Participant Number is empty, by Account Structure.",
             _u("05", "Partner Dealer Setup", "Dealer Setup Partner", "TA Dealer Number", "NSCC Participant Number", "Dealer Setup Status", "Dealing Route", "Account Structure")),
            ("Hedged Share Classes", "Count of open share classes with Currency Hedged Indicator = Y by Hedging Type, with the mean Hedge Target Ratio.",
             _u("01", "Currency Hedging", "Currency Hedged Indicator", "Hedging Type", "Hedge Target Ratio")),
        ],
        inputs=[
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Legal Name", "Share Class Type", "Share Class Currency",
                                   "Share Class Launch Date", "Share Class Status"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("01", "Regulatory Classification", ["US Fund Type"]),
            ("01", "Security Identifier", ["ISIN", "CUSIP"]),
            ("01", "External Cross-Reference", ["Bloomberg Ticker", "DTCC Fund/SERV Code"]),
            ("01", "Dealing Terms", ["Dealing Frequency", "Dealing Cut-off Time", "Cut-off Time Zone", "Subscription Settlement Period",
                                     "Redemption Settlement Period", "Redemption Notice Period", "Pricing Basis", "Dealing Calendar"]),
            ("01", "Valuation Terms", ["Valuation Frequency", "Valuation Point", "NAV Decimal Precision", "NAV Publication Channel"]),
            ("01", "Listing", ["Listing Exchange", "Exchange Ticker", "Trading Currency", "Primary Listing Indicator", "Listing Date", "Delisting Date", "iNAV Ticker"]),
            ("01", "ETF Characteristics", ["Replication Method", "Creation Unit Size", "Index Tracked", "ETF Share Class Indicator"]),
            ("01", "Income Distribution", ["Distribution Policy", "Distribution Frequency", "Distribution Payment Method"]),
            ("01", "Currency Hedging", ["Currency Hedged Indicator", "Hedging Type", "Hedge Target Ratio"]),
            ("01", "Investor Eligibility", ["Eligible Investor Type", "Minimum Initial Investment", "Minimum Subsequent Investment", "Minimum Holding"]),
            ("01", "Investor Transaction Charge", ["Maximum Entry Charge", "Maximum Exit Charge", "CDSC Schedule"]),
            ("01", "Product Tax Status", ["Tax Residence Country", "US Tax Classification", "FATCA GIIN", "Tax Transparency Indicator"]),
            ("01", "Lifecycle Event", ["Lifecycle Status", "Lifecycle Event Type", "Event Effective Date", "Successor Product / Share Class"]),
            ("09", "Dealing Calendar Rule", ["Dealing Calendar ID", "Base Business Calendar", "Market Closure Calendars", "Dealing Day Pattern"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type", "Holiday Name"]),
            ("05", "Partner Dealer Setup", ["Dealer Setup Partner", "TA Dealer Number", "NSCC Participant Number", "Dealer Setup Status",
                                            "Dealer Setup Effective Date", "Dealing Route", "Account Structure"]),
        ],
        upstream=["DP-004", "DP-097", "DP-005", "DP-001", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET on each business day, before the platform and TA open; term changes published at least one business day before their effective date",
        history="SCD type 2 on every term with effective dates; kept for the life of the share class plus six years",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "API", "File extract"],
        dq_rules=[
            "Every share class resolves to an active DP-004 Share Class ID and its Parent Product to a Product ID, every Dealing Calendar to a DP-013 Dealing Calendar ID, and every Dealer Setup Partner to a DP-001 firm with a DP-005 agreement.",
            "Term versions of one share class do not overlap in effect, Listing Delisting Date is empty or on or after Listing Date, and a share class has at most one Listing with Primary Listing Indicator = Y in force.",
            "The terms published here equal the DP-004 conformed terms for the same share class and effective date with no difference, so the platform, the TA and intermediaries read one set.",
            "Dealing Frequency, Dealing Cut-off Time, Cut-off Time Zone, Dealing Calendar and Redemption Settlement Period are populated on every open share class, and Primary Listing Indicator on every ETF listing.",
            "No published value matches the EMP- key pattern or a 02 individual PTY- key (Dealer Setup Partner resolves to a DP-001 firm of party type organization), and TA Dealer Number and NSCC Participant Number columns are returned only to operations and partner roles.",
            "The terms are published by 6am ET each business day, and a change is published at least one business day before its effective date.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: none. pii is N: product terms and partner firm setups only; the validator flags Dealer Setup Partner "
               "only because its catalog note reads 'Object PII tier: No PII' (a firm key). "
               "Boundaries: terms are mastered in 01 and conformed by DP-004; the cut-off control on fund orders is DP-177 (29), "
               "which reads this product (live dependent); dealer setups and agreements are 05 (DP-005, DP-001; thin intermediary "
               "channel). Brokerage order-time checks are 48 (CW-099). Rule context: US open-end funds price at the next NAV "
               "after receipt (Rule 22c-1); Section 22(e) limits redemption payment to 7 days; ETF secondary trades settle T+1 "
               "(Rule 15c6-1 since May 28, 2024). "
               "Tailoring lever: hedged share classes and non-US tax residence (Hedged Share Classes, the FATCA GIIN part of Tax Status Gaps). Reference default: kept for a US-only range as completeness checks that should read zero; a firm drops them. "
               "Listings are 01 Listing, also published by DP-097 for the exchange instrument; DP-097 is listed upstream. "
               "Tailoring lever: intermediary channel depth (CW-021). Reference default: thin; dealer setups only, no partner "
               "trading setup or cut-off. "
               "Taxonomy gap: 05 Partner Dealer Setup has no order cut-off time, settlement cycle or time zone (the wholesale 05 "
               "Trading Setup left, CW-901), so partner cut-off and settlement mismatches cannot be tested. "
               "Drafting assumptions: Share Class Status Open; Day Type Business Day; Dealer Setup Status Active; Dealing Route "
               "value NSCC Fund/SERV; US Fund Type open-end. "
               "Decisions: CW-099, CW-221, CW-901, CW-220. "
               "WP1 re-scope (CW-220): kept in place because live DP-177 depends on the id; name and owning domain 01 unchanged; "
               "primary function FN-15 becomes FN-78 in the register. Inputs dropped: 01 Share Class Tax Reporting (UK reporting fund "
               "and EU tax status, CW-901), 05 Trading Setup (left, CW-901), 05 Shelf Placement (DP-005's), the attributes SEDOL, "
               "Fees Charged to Capital Indicator, CRS Entity Classification, Non-Dealing Day Threshold and the wholesale "
               "Anti-Dilution and Swing Factor reads. Inputs added: 01 Investment Product, Regulatory Classification, ETF "
               "Characteristics and Lifecycle Event. Measures kept with their names: Next Dealing Date, Non-Dealing Days (Next 90 "
               "Days), Redemption Payment Limit Flag, Upcoming Change Count (now from 01 Lifecycle Event), Dealing Reference "
               "Completeness %; dropped: Cut-off in Partner Time, Partner Cut-off Breach Flag and Settlement Mismatch Flag (their "
               "05 Trading Setup inputs left; models_c7_product_data DP-079 partner child entity loses its backing); added: Classes "
               "Settling Beyond T+1, ETF Classes Without Primary Listing, Classes With Sales Charges, Minimum Investment Coverage %, "
               "Fund/SERV and CUSIP Coverage %, Tax Status Gaps, Dealer Setups Without NSCC Participant Number, Hedged Share "
               "Classes. Dimensions dropped: 'Fund domicile' (US only), 'UK reporting fund status', 'Dealing route' kept on dealer "
               "setups; added 'US fund type'. Upstream drops DP-041 (retired); keeps DP-004, DP-005, DP-001, DP-013."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-085": dict(
        definition=("Every change to contact data, bank instructions, standing instructions, registration and beneficiaries, with "
                    "the assisted-service authentication behind it and the digital login profile around it, linked to the "
                    "disbursements, fraud assessments and fraud holds that follow, flagging account takeover patterns such as a "
                    "bank or email change followed by a withdrawal. Client service and fraud teams stop losses and evidence the "
                    "Regulation S-ID red-flag program. Special-category facts are not read: the old specified-adult indicator is "
                    "replaced by the DP-322 protection flag. It owns no certified metric family."),
        business_questions=[
            "Which accounts had a contact or bank instruction change followed within 30 days by a withdrawal, and how much was withdrawn?",
            "Which accounts had several high-risk changes in a short window, and which changes were made after a failed or step-up authentication?",
            "Which high-risk changes and new bank instructions were not verified, and which withdrawals went to an unverified bank instruction?",
            "How many fraud holds did the patterns lead to, how long did they last, and how much confirmed fraud loss was there?",
            "Which deceased or dormant accounts saw activity, and how long are estate requests pending?",
        ],
        grain=("Account maintenance change (service request x maintained data element) with its authentication, joined to the "
               "account's bank and standing instructions, digital profile and the money movements, fraud assessments and fraud "
               "holds in the 30 days after; daily account pattern flags; immutable events"),
        dimensions=["Event date (DP-013)", "Request type and maintained data element", "Intake channel", "Servicing provider (DP-240)",
                    "Signature guarantee type", "Good order status", "Authentication method and result", "Account type and registration type (DP-093)",
                    "Fraud pattern flag", "Fraud decision", "Hold type (fraud only)"],
        measures=[
            ("Change-then-Redeem Flag", "Y for an account with an Account Maintenance Change of Maintained Data Element in Mailing Address, Email Address, Phone Number or Bank Instruction on a completed Service Request followed within 30 calendar days of Completed Timestamp by an outgoing 50 Money Movement (Movement Direction = Outgoing) of a withdrawal or redemption Money Movement Type.",
             _u("13", "Account Maintenance Change", "Maintained Data Element") + _u("13", "Service Request", "Service Request ID", "Account", "Request Status", "Completed Timestamp")
             + _u("50", "Money Movement", "Money Movement ID", "Movement Account", "Movement Direction", "Money Movement Type", "Requested Date")),
            ("Flagged Redemption Value", "Sum of Movement Amount of the outgoing money movements behind each Change-then-Redeem Flag, in USD, by Payment Rail.",
             _u("50", "Money Movement", "Movement Amount", "Payment Rail") + ["Change-then-Redeem Flag"]),
            ("Rapid Multiple Change Flag", "Y for an account with two or more high-risk Account Maintenance Changes (different Maintained Data Element values) on Service Requests received within 5 calendar days.",
             _u("13", "Account Maintenance Change", "Maintained Data Element") + _u("13", "Service Request", "Account", "Received Timestamp")),
            ("Changes After Weak Authentication", "Count of high-risk changes whose request's assisted interaction (Linked Service Request) had an Interaction Authentication with Authentication Result = Failed before success, Step-Up Required Indicator = Y or Red Flag Raised Indicator = Y, by Authentication Method.",
             _u("13", "Interaction Authentication", "Authenticated Interaction", "Authentication Result", "Step-Up Required Indicator", "Red Flag Raised Indicator", "Authentication Method")
             + _u("13", "Account Maintenance Change", "Maintained Data Element")),
            ("Signature Guarantee Coverage", "Share of completed ownership, bank instruction and large-withdrawal requests with Signature Guarantee Type populated or Call-Back Verification Indicator = Y, by Request Type.",
             _u("13", "Request Controls", "Signature Guarantee Type", "Call-Back Verification Indicator") + _u("13", "Service Request", "Request Type", "Request Status")),
            ("Unverified Bank Instructions Added", "Count of 15 Bank Instruction rows with Bank Instruction Effective From in the period whose Bank Verification Status is not Verified, by Bank Verification Method and Third-Party Bank Indicator (DP-093).",
             _u("15", "Bank Instruction", "Bank Instruction ID", "Bank Instruction Account", "Bank Verification Status", "Bank Verification Method",
                "Third-Party Bank Indicator", "Bank Instruction Effective From")),
            ("Withdrawals to Unverified Bank Instructions", "Count and Movement Amount of outgoing money movements in the period whose Bank Instruction Used has Bank Verification Status not Verified, and of standing instructions (Account Standing Instruction, Linked Bank Instruction) pointing at one.",
             _u("50", "Money Movement", "Bank Instruction Used", "Movement Direction", "Movement Amount")
             + _u("15", "Account Standing Instruction", "Standing Instruction ID", "Instruction Account", "Instruction Type", "Linked Bank Instruction", "Instruction Status")
             + _u("15", "Bank Instruction", "Bank Verification Status")),
            ("Changed Accounts Without MFA", "Count of accounts with a high-risk change in the period whose owner's 04 Digital Profile has Digital Profile Status = Active and MFA Factors Enrolled empty, with the Last Login Timestamp within 1 day of the change.",
             _u("04", "Digital Profile", "Digital Profile ID", "Digital Profile Party", "Digital Profile Status", "MFA Factors Enrolled", "Last Login Timestamp")
             + _u("13", "Service Request", "Requesting Party") + _u("13", "Account Maintenance Change", "Maintained Data Element")),
            ("Fraud Holds From Patterns", "Count of 50 Money Movement Holds with Hold Type = Fraud placed on movements of accounts with a Change-then-Redeem Flag or Rapid Multiple Change Flag, by Fraud Decision of the Fraud Risk Assessment behind them (DP-302; special-category hold rows are suppressed there).",
             _u("50", "Money Movement Hold", "Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Status", "Hold Placed Date")
             + _u("50", "Fraud Risk Assessment", "Assessed Movement", "Fraud Decision", "Resulting Hold") + ["Change-then-Redeem Flag", "Rapid Multiple Change Flag"]),
            ("Hold Duration (Business Days)", "Median business days from Hold Placed Date to Hold Released Date of fraud holds released in the period.",
             _u("50", "Money Movement Hold", "Hold Placed Date", "Hold Released Date", "Hold Type")),
            ("Confirmed Fraud Loss Events", "Count of Fraud Risk Assessments in the period with Confirmed Fraud Indicator = Y and Fraud Loss Event populated, split by whether a pattern flag was raised before the movement.",
             _u("50", "Fraud Risk Assessment", "Assessed Movement", "Assessment Timestamp", "Confirmed Fraud Indicator", "Fraud Loss Event")
             + ["Change-then-Redeem Flag"]),
            ("Estate Pending Age", "Business days since Received Timestamp of open estate and ownership-transfer requests with Estate Documents Outstanding populated.",
             _u("13", "Transfer of Ownership & Estate", "Estate Documents Outstanding", "Related Death Notification") + _u("13", "Service Request", "Received Timestamp", "Request Status")),
            ("Post-Death Activity Flag", "Y for an account with a Transfer of Ownership & Estate request linked to a 02 Death Notification whose outgoing money movements or high-risk changes have a Requested Date or Received Timestamp after the Notification Received Date, other than by the Estate Representative (DP-240).",
             _u("13", "Transfer of Ownership & Estate", "Related Death Notification") + _u("02", "Death Notification", "Death Notification ID", "Deceased Party", "Notification Received Date", "Estate Representative")
             + _u("50", "Money Movement", "Requested Date", "Initiating Party") + _u("13", "Service Request", "Received Timestamp")),
            ("Dormant Reactivation Flag", "Y for an account with no Service Request and no money movement in the 12 months before a high-risk change, followed by an outgoing money movement within 30 days.",
             _u("13", "Service Request", "Account", "Received Timestamp") + _u("50", "Money Movement", "Movement Account", "Requested Date", "Movement Direction")),
            ("Flagged Accounts With Protection Flag (from DP-322)", "Count of accounts with a Change-then-Redeem Flag or Rapid Multiple Change Flag whose owner has Protection Flag Present (from DP-322) = Y, joined on the 15 account key only; published at counts of 10 or more. Replaces the wholesale Specified Adult Indicator.",
             _u("13", "Service Request", "Account") + ["Change-then-Redeem Flag", "Rapid Multiple Change Flag"]),
        ],
        inputs=[
            ("13", "Service Request", ["Service Request ID", "Request Type", "Account", "Requesting Party", "Intake Channel", "Received Timestamp",
                                       "Servicing Provider", "Good Order Status", "Request Status", "Completed Timestamp"]),
            ("13", "Request Controls", ["Signature Guarantee Type", "Call-Back Verification Indicator"]),
            ("13", "Account Maintenance Change", ["Maintained Data Element", "Updated Master Record"]),
            ("13", "Transfer of Ownership & Estate", ["Related Death Notification", "Estate Documents Outstanding"]),
            ("13", "Interaction Authentication", ["Authenticated Interaction", "Authentication Method", "Authentication Result", "Step-Up Required Indicator",
                                                  "Red Flag Raised Indicator"]),
            ("04", "Digital Profile", ["Digital Profile ID", "Digital Profile Party", "Digital Profile Status", "MFA Factors Enrolled", "Last Login Timestamp"]),
            ("15", "Bank Instruction", ["Bank Instruction ID", "Bank Instruction Account", "Bank Verification Status", "Bank Verification Method",
                                        "Third-Party Bank Indicator", "Bank Instruction Effective From"]),
            ("15", "Account Standing Instruction", ["Standing Instruction ID", "Instruction Type", "Instruction Account", "Instruction Status", "Linked Bank Instruction"]),
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Money Movement Type", "Payment Rail", "Movement Direction", "Movement Amount",
                                      "Requested Date", "Initiating Party", "Bank Instruction Used"]),
            ("50", "Money Movement Hold", ["Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Status", "Hold Placed Date", "Hold Released Date"]),
            ("50", "Fraud Risk Assessment", ["Assessed Movement", "Assessment Timestamp", "Fraud Decision", "Resulting Hold", "Confirmed Fraud Indicator",
                                             "Fraud Loss Event"]),
            ("02", "Death Notification", ["Death Notification ID", "Deceased Party", "Notification Received Date", "Estate Representative"]),
        ],
        upstream=["DP-381", "DP-093", "DP-240", "DP-302", "DP-322", "DP-011", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET on T+1; Change-then-Redeem flags on the event stream within 15 minutes of an outgoing movement request",
        history="Changes, authentications, movements and holds kept as immutable facts; daily account flags kept seven years (Regulation S-ID program records; SEC Rule 17a-4)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "Event stream"],
        dq_rules=[
            "Every Account, Bank Instruction Account, Instruction Account and Movement Account resolves to a DP-093 Account ID, every Requesting Party, Digital Profile Party, Deceased Party and Initiating Party to a DP-240 party, every Held Movement and Assessed Movement to a DP-302 Money Movement ID, and every Authenticated Interaction to a DP-381 interaction.",
            "Bank Instruction effective periods of one bank account do not overlap for the same account, and Hold Released Date is empty or on or after Hold Placed Date.",
            "Every high-risk Account Maintenance Change read here appears in DP-381 for the same Service Request ID, and every Hold Type = Fraud hold resolves to the Resulting Hold of a Fraud Risk Assessment on its Held Movement.",
            "Maintained Data Element, Request Type, Received Timestamp and Completed Timestamp (when completed) are populated on every change, and Movement Direction, Money Movement Type and Requested Date on every money movement.",
            "No special-category fact is read: 50 holds other than Hold Type = Fraud, Hold Reason, Ownership Transfer Reason and 02 Specified Adult Status are excluded, protection appears only as the DP-322 flag count at 10 or more, and authentication evidence and credentials are never read (CD-344, CW-086).",
            "The prior day is complete by 6am ET on T+1, and pattern flags reach the event stream within 15 minutes.",
        ],
        notes=("Certified numbers: none read or owned. "
               "PII tier: identity (client and account keys); never credentials. "
               "Boundaries: authentication is split 04 digital logins, 13 assisted service, 02 CIP and 41 controls (CW-086); holds "
               "are 50 (CW-109), read through DP-302, which suppresses special-category and AML hold rows; service requests and "
               "authentication through DP-381; bank and standing instructions through DP-093; the death notification through "
               "DP-240. 04 Digital Profile is read directly: DP-011 publishes engagement but not the profile. Shareholder CIP, AML "
               "and fraud alerts on TA accounts are live DP-180, which reads this product's pattern flags. Fraud and "
               "elder-exploitation cash holds are DP-456; the Rule 2165 case is DP-403. "
               "Tailoring lever: advisor personal recognition as authentication (13 SME 8). Reference default: allowed for "
               "low-risk requests only; high-risk changes need a call-back. "
               "Tailoring lever: pattern windows. Reference default: 30 days change-to-withdrawal, 5 days for multiple changes, 12 "
               "months dormancy. "
               "Taxonomy gap: 13 Account Maintenance Change has no change timestamp; the change is dated by its request's Completed "
               "Timestamp. "
               "Drafting assumptions: the high-risk Maintained Data Element values; Movement Direction Outgoing; Hold Type Fraud; Bank Verification Status Verified; Authentication Result Failed; the windows above and the minimum cell "
               "of 10. "
               "Decisions: CW-086, CW-089, CW-107, CW-109, CW-213, CW-220; CD-344. "
               "WP1 re-scope (CW-220): kept in place because live DP-180 depends on the id; name and owning domain 13 unchanged. "
               "Inputs dropped: 13 Contact Center Interaction (read through 13 Interaction Authentication and DP-381), 15 Account "
               "and 15 Account Restriction (Rule 2165 rows are special category, DP-403), 02 Individual (date of birth for the "
               "specified adult indicator), 06 Transaction, Transaction Dates, Transaction Amounts, Order Source and Position "
               "(withdrawals are 50 money movements, CW-107; 06 is never a book). Inputs added: 13 Interaction Authentication, 04 "
               "Digital Profile, 15 Bank Instruction, 50 Money Movement, Money Movement Hold and Fraud Risk Assessment, 02 Death "
               "Notification. Measures kept with their names: Change-then-Redeem Flag (now any outgoing money movement), Flagged "
               "Redemption Value, Rapid Multiple Change Flag, Signature Guarantee Coverage, Hold Duration (Business Days), Estate "
               "Pending Age, Post-Death Activity Flag, Dormant Reactivation Flag; dropped: Specified Adult Indicator (special "
               "category; replaced by Flagged Accounts With Protection Flag (from DP-322); models_c10_shareholder_ops DP-085 note "
               "on Individual date of birth to drop); added: Changes After Weak Authentication, Unverified Bank Instructions Added, "
               "Withdrawals to Unverified Bank Instructions, Changed Accounts Without MFA, Fraud Holds From Patterns, Confirmed "
               "Fraud Loss Events. Dimensions dropped: 'Specified adult (65+) indicator' (no account-level protection flag is "
               "published; protection appears only as the DP-322 count), 'Account restriction type', 'Product and share class'; added authentication, fraud decision and hold "
               "type. Upstream drops DP-043, DP-070 and DP-002 (retired), DP-006, DP-007, DP-004 and DP-001; adds DP-381, DP-093, "
               "DP-240, DP-302, DP-322 and DP-011."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-109": dict(
        definition=("Every US product review of an own fund, share class, model portfolio or advice offering (36 Product Review): "
                    "the review calendar, each criterion result with its rating and the evidence it cites (official returns and "
                    "benchmark returns from DP-145, fee benchmarks from DP-506, cost and margin from DP-499, net flows from DP-008, "
                    "advice program outcome evidence from DP-385), the conclusion and the actions and change initiatives that "
                    "follow. Product governance evidences that every product was reviewed on time against its criteria and acted "
                    "on. It owns no certified metric family."),
        business_questions=[
            "Which products and offerings are overdue for review, and which reviews were approved on time?",
            "How are criterion ratings distributed, and which share classes and programs were concluded not to provide value?",
            "Which criterion results lack the evidence their criterion needs?",
            "For each reviewed share class, how do returns compare with the benchmark, fees with peers and margins with plan, and what were its net flows?",
            "Which review actions are overdue, and how many became change initiatives?",
        ],
        grain=("Product review (PRVW-) x product review criterion x share class (or the reviewed subject as a whole), with the "
               "evidence records each criterion result cites and the review actions as companion facts; immutable per review "
               "version"),
        dimensions=["Product review and review type", "Review period", "Product, share class, model portfolio and service offering (DP-004)",
                    "Product review criterion", "Criterion rating", "Review outcome", "Review action type and status",
                    "Action owner (DP-192)", "Product governing body (01)", "As-of date (DP-013)"],
        measures=[
            ("Reviews Overdue", "Count of products and review types whose latest Product Review has Next Review Due Date before the as-of date and no later review of the same Review Product (or Review Service Offering) and Product Review Type, compared with 01 Product Governance Next Product Review Date for funds.",
             _u("36", "Product Review", "Product Review ID", "Review Product", "Review Service Offering", "Product Review Type", "Next Review Due Date", "Review Period End")
             + _u("01", "Product Governance", "Next Product Review Date", "Last Product Review Date")),
            ("Assessments Approved on Time %", "Product Reviews with Review Status = Approved within 90 calendar days after Review Period End / reviews whose Review Period End is 90 or more days before the as-of date, by Product Review Type and Governing Body.",
             _u("36", "Product Review", "Review Status", "Review Period End", "Review Approver", "Product Review Type") + _u("01", "Product Governance", "Governing Body")),
            ("Criterion Rating Distribution", "Count of Product Review Criterion Results by Product Review Criterion and Criterion Rating, by review period.",
             _u("36", "Product Review Criterion Result", "Criterion Review", "Product Review Criterion", "Criterion Rating") + _u("36", "Product Review", "Review Period End")),
            ("Share Classes Not Providing Value", "Count of share classes whose review has Review Outcome = Not Providing Value, or any Criterion Rating at the lowest level for the Criterion Share Class, by product.",
             _u("36", "Product Review", "Review Outcome", "Review Product") + _u("36", "Product Review Criterion Result", "Criterion Share Class", "Criterion Rating") + _u("01", "Share Class", "Share Class ID", "Share Class Status")),
            ("Criteria Without Required Evidence", "Count of criterion results missing the evidence their criterion needs: performance needs Performance Evidence Return and Benchmark Evidence Return; costs Cost Evidence Profitability Record; fee competitiveness Fee Evidence Study; peer comparison Peer Evidence Universe; flows Flow Evidence Measure Value; complaints Complaint Evidence Count; drift Drift Exception Evidence Count; any criterion Evidence Metric Definition resolving to a 21 Metric Definition with Metric Certification Status populated.",
             _u("36", "Product Review Criterion Result", "Product Review Criterion", "Performance Evidence Return", "Benchmark Evidence Return",
                "Cost Evidence Profitability Record", "Fee Evidence Study", "Peer Evidence Universe", "Flow Evidence Measure Value",
                "Complaint Evidence Count", "Drift Exception Evidence Count", "Evidence Metric Definition")
             + _u("21", "Metric Definition", "Metric ID", "Metric Certification Status")),
            ("Performance vs Benchmark Evidence", "Return Value of the Performance Evidence Return (Return Status Final or Restated, from DP-145) - Benchmark Return Value of the Benchmark Evidence Return for the same period; ratings resting on a Preliminary return are flagged. Read, not certified here.",
             _u("32", "Performance Return", "Performance Return ID", "Return Share Class", "Return Period End Date", "Return Fee Basis", "Return Value", "Return Status")
             + _u("32", "Benchmark Return", "Return Benchmark", "Benchmark Period End Date", "Benchmark Return Value", "Benchmark Return Status")
             + _u("36", "Product Review Criterion Result", "Performance Evidence Return", "Benchmark Evidence Return")),
            ("Fee Position Evidence", "Own Fee Percentile and Own Fee Rate - Peer Median Fee (bps) of the Fee Benchmark Result of the cited Fee Evidence Study (from DP-506), with its Fee Competitiveness Assessment.",
             _u("11", "Fee Benchmark Study", "Fee Study ID", "Subject Share Class", "Subject Service Offering", "Fee Measure Compared", "Study Date")
             + _u("11", "Fee Benchmark Result", "Own Fee Rate", "Peer Median Fee", "Own Fee Percentile", "Fee Competitiveness Assessment")
             + _u("36", "Product Review Criterion Result", "Fee Evidence Study")),
            ("Cost and Margin Evidence", "Net Revenue Yield and Operating Margin of the cited Cost Evidence Profitability Record (from DP-499), by share class and profitability period.",
             _u("10", "Profitability Record", "Profitability Record ID", "Profitability Period", "Product / Share Class", "Data Version")
             + _u("10", "Profitability Measure", "Net Revenue Yield", "Operating Margin") + _u("36", "Product Review Criterion Result", "Cost Evidence Profitability Record")),
            ("Share Class Net Flows (from DP-008)", "Trailing 12-month certified Net Flows (Net Sales) of the reviewed share class to Review Period End: the DP-008 Measure Value at Dimension Type Share Class and Dimension Key = the Criterion Share Class, from the Final or Restated Snapshot, shown as context; read, never recomputed.",
             _mv("Reporting Period", "Data Basis", "Snapshot") + _u("06", "Flow Measures", "Net Flows (Net Sales)") + _u("36", "Product Review Criterion Result", "Flow Evidence Measure Value")),
            ("Advice Program Evidence Cited (from DP-385)", "Count of criterion results of service offering and model portfolio reviews whose Drift Exception Evidence Count, Complaint Evidence Count or Flow Evidence Measure Value is populated from the DP-385 program evidence of the same review period, beside those without it.",
             _u("36", "Product Review", "Review Service Offering", "Review Model Portfolio") + _u("36", "Product Review Criterion Result", "Drift Exception Evidence Count", "Complaint Evidence Count")),
            ("Review Actions Overdue", "Count of Review Actions with Review Action Due Date before the as-of date and Review Action Completed Date empty, by Review Action Owner and Review Action Type.",
             _u("36", "Review Action", "Action Review", "Review Action Sequence", "Review Action Due Date", "Review Action Completed Date", "Review Action Owner", "Review Action Type")),
            ("Actions Converted to Change %", "Review Actions of a change type with a Resulting Change Initiative / all Review Actions of a change type; with the Change Status of the resulting initiative.",
             _u("36", "Review Action", "Review Action Type", "Resulting Change Initiative") + _u("36", "Product Change Initiative", "Product Change Initiative ID", "Change Status")),
        ],
        inputs=[
            ("36", "Product Review", ["Product Review ID", "Review Product", "Review Share Class", "Review Model Portfolio", "Review Service Offering",
                                      "Product Review Type", "Review Period Start", "Review Period End", "Review Status", "Review Outcome",
                                      "Review Approver", "Next Review Due Date", "Review Report Document"]),
            ("36", "Product Review Criterion Result", ["Criterion Review", "Criterion Share Class", "Product Review Criterion", "Criterion Rating",
                                                       "Criterion Conclusion", "Performance Evidence Return", "Benchmark Evidence Return",
                                                       "Peer Evidence Universe", "Fee Evidence Study", "Cost Evidence Profitability Record",
                                                       "Flow Evidence Measure Value", "Complaint Evidence Count", "Drift Exception Evidence Count",
                                                       "Evidence Metric Definition"]),
            ("36", "Review Action", ["Action Review", "Review Action Sequence", "Review Action Type", "Review Action Description", "Action Share Class",
                                     "Review Action Owner", "Review Action Due Date", "Review Action Completed Date", "Review Action Status",
                                     "Resulting Change Initiative"]),
            ("36", "Product Change Initiative", ["Product Change Initiative ID", "Product Change Type", "Change Status"]),
            ("01", "Product Governance", ["Product Owner", "Last Product Review Date", "Next Product Review Date", "Governing Body"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Share Class", "Return Period End Date", "Return Fee Basis", "Return Value",
                                          "Return Version", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period End Date", "Benchmark Return Value", "Benchmark Return Version",
                                        "Benchmark Return Status"]),
            ("11", "Fee Benchmark Study", ["Fee Study ID", "Subject Share Class", "Subject Service Offering", "Fee Measure Compared", "Study Date"]),
            ("11", "Fee Benchmark Result", ["Own Fee Rate", "Peer Median Fee", "Own Fee Percentile", "Fee Competitiveness Assessment"]),
            ("10", "Profitability Record", ["Profitability Record ID", "Profitability Period", "Product / Share Class", "Data Version"]),
            ("10", "Profitability Measure", ["Net Revenue Yield", "Operating Margin"]),
            ("21", "Metric Definition", ["Metric ID", "Metric Name", "Metric Certification Status"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount",
                                     "Data Basis", "Snapshot"]),
            ("06", "Flow Measures", ["Net Flows (Net Sales)"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
        ],
        upstream=["DP-004", "DP-385", "DP-499", "DP-506", "DP-008", "DP-101", "DP-145", "DP-192", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, after the DP-145 period close and the DP-008 Final snapshot; review status daily by 7am ET",
        history="Every review version, criterion result and action kept immutable; ten years (product governance and Section 15(c) support records)",
        classification="Confidential",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Review Product, Review Share Class, Criterion Share Class, Review Model Portfolio and Review Service Offering resolves to DP-004, every Performance Evidence Return and Benchmark Evidence Return to DP-145, every Fee Evidence Study to DP-506, every Cost Evidence Profitability Record to DP-499, every Flow Evidence Measure Value to DP-008 and every Evidence Metric Definition to a 21 Metric ID in DP-101.",
            "Review Period End is on or after Review Period Start, and reviews of the same subject and Product Review Type do not have overlapping review periods.",
            "Performance vs Benchmark Evidence uses the DP-145 Return Value and Benchmark Return Value of the cited records unchanged, Share Class Net Flows (from DP-008) equals the DP-008 Measure Amount for the same Dimension Key and Snapshot ID, and program evidence equals the DP-385 values of the same review period, with no difference.",
            "Review Product or Review Service Offering, Product Review Type, Review Period Start, Review Period End and Next Review Due Date are populated on every review, and Product Review Criterion and Criterion Rating on every criterion result.",
            "Every Review Approver and Review Action Owner value matches the DP-192 EMP- key pattern, no column carries a 02 client PTY- key, and the employee columns are returned only to product governance roles.",
            "A review version is locked once Review Status = Approved; changes arrive as a new version.",
        ],
        notes=("Certified numbers: none owned; reads Net Flows (Net Sales) from DP-008 and official returns from DP-145 as context "
               "and evidence, never recomputed. "
               "PII tier: identity (employee keys only). "
               "Boundaries: DP-109 is the review register for funds and programs; DP-385 assembles the advice program evidence it "
               "cites (36 SME 3); fee benchmarks are DP-506, cost and margin DP-499, returns DP-145 (CD-217, CD-320). Product "
               "change initiatives are DP-106's calendar. Live DP-242 Fund 360 reads this product (Latest Review Outcome). The "
               "MiFID target market and Consumer Duty assessments of retired DP-040 are out of scope (CW-207). DP-385, DP-499 and "
               "DP-506 must not list this product upstream. "
               "Tailoring lever: risk-based review cycles (36 SME 3). Reference default: annual review of every fund, share class "
               "and advice program. "
               "Tailoring lever: criterion rating scale (36 SME 7). Reference default: four-point scale. "
               "Drafting assumptions: Review Status Approved; Review Outcome Not Providing Value; the 90-day approval window; "
               "Return Status values Final, Restated and Preliminary; Dimension Type Share Class on 06 Measure Value. "
               "Decisions: CW-161, CW-207, CW-208, CW-220; CD-217, CD-238, CD-303, CD-320. "
               "W4 re-point (CW-161, CW-170, CW-936): 36 Value Assessment Criterion Result re-pointed to its successor Product Review "
               "Criterion Result; 06 Measure Value.Share Class re-pointed to Dimension Type and Dimension Key (CW-906). "
               "WP1 re-scope (CW-208): name 'Product Reviews & Criterion Results' on 36 Product Review Criterion Result; owning "
               "domain 36; US product reviews of funds, models and advice offerings (CW-161). Upstreams DP-040 (retired), DP-035 and "
               "DP-030 (retired) are replaced by DP-385, DP-499 and DP-506. Inputs added: 01 Product Governance (the fund review "
               "calendar, which DP-385 does not read), 36 Product Review Criterion Result Drift Exception Evidence Count, 11 Fee "
               "Benchmark Study Subject Service Offering. Measure renamed: 'Share Class Net Flows' becomes 'Share Class Net Flows (from DP-008)' (no semantic reader). Measures kept with their names: Reviews Overdue, Criterion Rating "
               "Distribution, Share Classes Not Providing Value, Criteria Without Required Evidence, Performance vs Benchmark "
               "Evidence, Fee Position Evidence, Cost and Margin Evidence, Share Class Net Flows, Review Actions Overdue, Actions "
               "Converted to Change %; restored: Assessments Approved on Time % (read by SM-06, dropped at W4, now on the US review "
               "approval); added: Advice Program Evidence Cited (from DP-385). Target Market Concerns (read by SM-06) stays dropped "
               "(MiFID, CW-207): SM-06 lines 1687 and 1691 lose their source. Dimensions renamed: 'Product, share class and model "
               "portfolio' becomes 'Product, share class, model portfolio and service offering (DP-004)', 'Action owner "
               "(employee)' becomes 'Action owner (DP-192)'; 'Product governing body (01)' added."
               " WP2 retirement sweep (CW-209): SM-06, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
}
