"""Data product specifications, wave WP1C (consumer), group DIS: Distribution, Channels & Client Economics (agent C-5).

Products (owning Data Domain in brackets):
- DP-505 Industry Flows, Market Share & Sizing [11]
- DP-487 Intermediary Payments, Sub-Accounting & Platform Fees [10]
- DP-486 Intermediary Oversight: Due Diligence, Obligations & Payment Disclosure [05]
- DP-488 Institutional & Plan Sponsor Pipeline [05]
- DP-491 Net New Assets by Channel, Offering & Advisor [06]
- DP-492 Net New Assets by Campaign & Acquisition Cohort [06]
- DP-493 Intermediary Channel Flows [06]
- DP-495 Client Asset Data Supply Chain, Reconciliation & Suspense [06]
- DP-496 Client Asset Mix & Own-Fund Penetration [06]
- DP-497 Client Revenue Yield by Stream, Offering & Segment [10]
- DP-498 Cost to Serve & Client Lifetime Value [10]
- DP-499 Client, Offering & Advisor Profitability [10]
- DP-490 Client Assets & Flows Executive Scorecard [06]
- DP-503 Intercompany Charges & Transfer Pricing [10]
- DP-506 Competitive Pricing & Fee Benchmarks [11]
- DP-510 Institutional Relationship Health & Service [12]
- DP-511 Institutional & OCIO Client Reporting Delivery [12]
- DP-514 Plan Sponsor Servicing & Plan Reviews [12]
- DP-243 Total Client Relationship [12] (re-scoped in place to the institutional relationship view; the wholesale spec
  in specs_e5_cross_area.py is superseded and is deleted by the lineage agent)

Decisions applied: CW-011 and CW-241 (certified numbers are read from their one owner, never defined: Client Assets,
Net New Assets, Advised Assets and the counts from DP-008, Firm AUM and its slices from DP-241, client fee revenue
from DP-012, Personal Rate of Return from DP-145; Client Assets and Firm AUM are never summed and the own-fund overlap
is netted only in DP-241), CW-142 and CW-242 (attribution products slice certified NNA and add no flow treatment or
weight), CW-243 and CD-344 (household and advisor economics are restricted views registered in DP-518), CW-007 (books
of record: Client Holding 49 through DP-300, Portfolio Holding 18 through DP-142, Fund Shareholder Position 06 a view),
CW-213 (special-category facts only through DP-322; none of these products reads them), CW-240 (new ids supersede the
wholesale products), CW-245 (thin intermediary channel), CW-246 (institutional billing is 47), CW-206 (DP-243 re-scope;
DP-244 retires into DP-498). Prospects stay 02 parties (05 Sales Opportunity Prospect / Client).

Upstream graph inside this module (no cycles): DP-505 <- DP-490; DP-487 <- DP-486, DP-499; DP-492 <- DP-498;
DP-498 <- DP-499 <- DP-490; DP-497 <- DP-490; DP-488, DP-510, DP-511 <- DP-243. Every other upstream is foundational
or a sibling consumer product (DP-241, DP-320, DP-350, DP-392, DP-410, DP-518) that lists none of these.
See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    """(NN, object, attribute) use tuples for one object."""
    return [(nn, obj, a) for a in attrs]


def _mv(*attrs):
    """06 Measure Value attributes: how a certified DP-008 number is read."""
    return _u("06", "Measure Value", *attrs)


# The locked DP-008 read: measure, period end, dimension, amount, data basis and snapshot of a Final or Restated snapshot.
_MV_READ = _mv("Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot") \
    + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type")

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-505": dict(
        definition=("Industry assets and flows by channel, vehicle and category from the licensed industry datasets, the firm's "
                    "share and rank in each, the size of addressable investor segments and plan markets, and the competitor "
                    "moves that explain share changes (competitor reported assets, events, personnel moves, channel footprint, "
                    "trends and intelligence items). Channel and segment share numerators are the certified Client Assets and "
                    "Net New Assets read from DP-008; fund category share uses the industry dataset on both sides. Leadership "
                    "sees where the market grows and where the firm gains or loses share. It owns no certified metric family."),
        business_questions=[
            "How fast are industry assets and flows growing by channel, vehicle and category, and how does the firm's organic growth compare?",
            "What is the firm's share of client assets and of net new assets in each retail channel and investor segment, and how did it change this quarter?",
            "Where does the firm rank in each fund category, and which categories are gaining or losing share?",
            "How large is each addressable investor segment and plan market, and what share of it does the firm already serve?",
            "Which competitor events, personnel moves and channel moves coincide with share changes?",
        ],
        grain=("Market share record (share definition x period end x period type x category or segment x channel x vehicle "
               "type) as the main output, with industry flow observations (release x category x channel x vehicle), market "
               "sizing records, competitor metric snapshots and event, move, trend and intelligence counts as companion facts; "
               "one version per industry data release, superseded releases kept"),
        dimensions=["Period end and period type (DP-013)", "Industry data release and dataset (DP-014)", "Industry category and mapped share class (DP-014, DP-004)",
                    "Distribution channel", "Vehicle type", "Region / market", "Share definition and share measure basis",
                    "Investor segment, wealth band and age band", "Sizing metric", "Competitor and competitor tier (DP-481)",
                    "Intermediary firm (DP-001)", "Competitor event type and move type", "Trend topic"],
        measures=[
            ("Industry Net Flow (from DP-014)",
             'Read: Industry Net Flow as DP-014 publishes it for the current release, by Industry Category, Distribution Channel, Vehicle Type and Region / Market, with Value Basis shown; never recomputed here.',
             _u("11", "Industry Flow Observation", "Data Release", "Industry Category", "Distribution Channel", "Vehicle Type", "Region / Market", "Net Flow", "Observation Currency", "Value Basis") + _u("11", "Industry Data Release", "Data Release ID", "Release Status", "Supersedes Release")),
            ("Industry Ending Assets",
             "Sum of Ending Assets of the same current-release observations at the release As-of Date, by category, channel and vehicle; the denominator of every asset share.",
             _u("11", "Industry Flow Observation", "Data Release", "Industry Category", "Distribution Channel", "Vehicle Type", "Ending Assets")
             + _u("11", "Industry Data Release", "Data Release ID", "As-of Date", "Release Status")),
            ("Industry Organic Growth Rate (from DP-014)",
             'Read: Industry Organic Growth Rate as DP-014 publishes it for the same category, channel and vehicle; never recomputed here.',
             _u("11", "Industry Flow Observation", "Industry Category", "Distribution Channel", "Vehicle Type", "Net Flow", "Ending Assets")),
            ("Firm Client Assets by Channel (from DP-008)",
             "Measure Amount of MSR-CLIENTASSETS (Ending Client Assets) at Dimension Type Channel and at Dimension Type Segment for the period end, in the locked DP-008 snapshot (Snapshot Type Final or Restated). Read, never recomputed; the numerator of channel and segment asset share.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Firm Net New Assets by Channel (from DP-008)",
             "Measure Amount of MSR-NNA (Net New Assets) at Dimension Type Channel and Segment for the period in the locked DP-008 snapshot. Read, never recomputed; the numerator of net new asset share.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("Channel Market Share of Client Assets %",
             "Market Share of Market Share Records whose Share Definition has Share Measure Basis Assets and Share Dimension Channel or Investor Segment and Numerator Source DP-008: Firm Value / Industry Value x 100, where Firm Value must equal Firm Client Assets by Channel (from DP-008) for the same Period End Date and Channel (DQ3).",
             _u("11", "Market Share Record", "Market Share Record ID", "Share Definition", "Period End Date", "Period Type", "Category / Segment", "Channel", "Firm Value", "Industry Value", "Market Share")
             + _u("11", "Market Share Definition", "Share Definition Code", "Share Measure Basis", "Share Dimension", "Numerator Source")
             + ["Firm Client Assets by Channel (from DP-008)"]),
            ("Channel Market Share of Net New Assets %",
             "Market Share of records whose Share Definition has Share Measure Basis Net New Assets: Firm Value (equal to Firm Net New Assets by Channel (from DP-008)) / Industry Value x 100; Negative Flow Treatment of the definition applied when the industry total is negative.",
             _u("11", "Market Share Record", "Share Definition", "Period End Date", "Channel", "Firm Value", "Industry Value", "Market Share")
             + _u("11", "Market Share Definition", "Share Definition Code", "Share Measure Basis", "Negative Flow Treatment")
             + ["Firm Net New Assets by Channel (from DP-008)"]),
            ("Fund Category Market Share %",
             "For each Industry Category: Ending Assets of current-release observations whose Fund Manager Firm is the firm / Industry Ending Assets of the category x 100, numerator and denominator from the same dataset; own share classes resolved through Category Mapping (Mapped Share Class, Mapping Effective From / To at the As-of Date).",
             _u("11", "Industry Flow Observation", "Industry Category", "Fund Manager Firm", "Ending Assets")
             + _u("11", "Category Mapping", "Category Scheme", "External Category Value", "Mapped Share Class", "Mapping Effective From", "Mapping Effective To")
             + ["Industry Ending Assets"]),
            ("Market Share Change (bps)",
             "Market Share at the period end minus Market Share at the prior period end of the same Share Definition, Category / Segment, Channel and Vehicle Type, x 100 (basis points).",
             _u("11", "Market Share Record", "Share Definition", "Period End Date", "Category / Segment", "Channel", "Vehicle Type", "Market Share")),
            ("Firm Industry Rank",
             "Rank Position of the firm (Ranked Firm) in each Ranking Universe for the market share record of the period end, with the change from the prior period end.",
             _u("11", "Industry Ranking", "Ranked Firm", "Rank Position", "Ranking Universe")
             + _u("11", "Market Share Record", "Market Share Record ID", "Period End Date")),
            ("Addressable Market Size",
             "Sizing Value of the latest Market Sizing Record (Sizing As-of Date) per Sizing Subject Type, Sizing Metric (Investable Household Assets, Advised Household Assets, Self-Directed Household Assets, Household Count, DC Plan Assets, IRA Rollover assets), Channel, Wealth Band, Age Band and Mapped Firm Segment; Source Dataset shown.",
             _u("11", "Market Sizing Record", "Market Sizing Record ID", "Sizing Subject Type", "Sizing Metric", "Channel", "Wealth Band", "Age Band", "Mapped Firm Segment", "Sizing Value", "Sizing As-of Date", "Source Dataset")),
            ("Firm Penetration of Addressable Assets %",
             "Firm Client Assets by Channel (from DP-008) at Dimension Type Segment for the segment named by Mapped Firm Segment / Addressable Market Size of Sizing Metric Investable Household Assets for that segment x 100, at the latest common date.",
             ["Firm Client Assets by Channel (from DP-008)", "Addressable Market Size"]),
            ("Intermediary Firm White Space",
             "Addressable Assets - Firm Assets with Party of the latest Opportunity Potential (Potential As-of Date) per Target Party that is a partner firm, with Wallet Share; firm level only, never advisor level (CW-160, CW-245).",
             _u("11", "Opportunity Potential", "Target Party", "Addressable Assets", "Firm Assets with Party", "Wallet Share", "Potential As-of Date")),
            ("Competitor Reported Client Assets and NNA",
             "Reported Client Assets, Reported Net New Assets, Total AUM and Client Account Count of each competitor's latest Competitor Metric Snapshot (As-of Date) by Competitor Tier, beside the firm's figures from DP-008; competitor figures are as reported and never compared to Firm AUM.",
             _u("11", "Competitor Profile", "Competitor Profile ID", "Competitor Party", "Competitor Tier")
             + _u("11", "Competitor Metric Snapshot", "As-of Date", "Total AUM", "Reported Client Assets", "Reported Net New Assets", "Client Account Count")),
            ("Competitor Channel Presence",
             "Presence Strength and Estimated Advisor Headcount of each competitor's Competitor Distribution Footprint by Channel, counted by Competitor Tier.",
             _u("11", "Competitor Profile", "Competitor Profile ID", "Competitor Tier")
             + _u("11", "Competitor Distribution Footprint", "Channel", "Presence Strength", "Estimated Advisor Headcount")),
            ("Competitor Events and Moves in Period",
             "Count of Competitor Events by Competitor and Event Type with Event Date in the period, and count of Competitor Personnel Moves by Move Type, From Competitor and To Competitor with Move Date in the period; counts only, the Individual is never published (DQ5).",
             _u("11", "Competitor Event", "Competitor Event ID", "Competitor", "Event Type", "Event Date", "Assessed Impact")
             + _u("11", "Competitor Personnel Move", "Individual", "Move Type", "From Competitor", "To Competitor", "Move Date")),
            ("Market Signals in Period",
             "Count of Market Trends by Trend Topic and Trend Direction with Indicator As-of Date in the period and their latest Indicator Value; count of Intelligence Items by Relevance Rating with Publication Date in the period and a Linked Competitors entry; count of Market Research Reports by Research Topics.",
             _u("11", "Market Trend", "Market Trend ID", "Trend Topic", "Indicator Value", "Indicator As-of Date", "Trend Direction")
             + _u("11", "Intelligence Item", "Intelligence Item ID", "Publication Date", "Linked Competitors", "Relevance Rating")
             + _u("11", "Market Research Report", "Research Report ID", "Research Topics", "Licensed Dataset")),
            ("Mapped Coverage % (from DP-014)",
             "Read: Mapped Coverage % as DP-014 publishes it (share of current-release industry assets whose Industry Category has a Category Mapping in force for the dataset's Category Scheme); the coverage behind Fund Category Market Share %.",
             _u("11", "Industry Flow Observation", "Industry Category", "Ending Assets") + _u("11", "Industry Dataset Profile", "Licensed Dataset", "Category Scheme") + _u("11", "Category Mapping", "Category Scheme", "External Category Value", "Mapping Effective From", "Mapping Effective To")),
        ],
        inputs=[
            ("11", "Industry Dataset Profile", ["Licensed Dataset", "Dataset Family", "Industry Data Provider", "Flow Estimation Method", "Category Scheme", "Vehicles Covered", "Coverage Basis"]),
            ("11", "Industry Data Release", ["Data Release ID", "As-of Date", "Publication Date", "Release Status", "Supersedes Release"]),
            ("11", "Industry Flow Observation", ["Data Release", "Industry Category", "Distribution Channel", "Vehicle Type", "Region / Market", "Distributor Firm", "Fund Manager Firm", "Gross Sales", "Redemptions", "Net Flow", "Ending Assets", "Observation Currency", "Value Basis"]),
            ("11", "Category Mapping", ["Category Scheme", "External Category Value", "Mapped Share Class", "Internal Market Segment", "Mapping Effective From", "Mapping Effective To"]),
            ("11", "Market Share Definition", ["Share Definition Code", "Share Measure Basis", "Share Dimension", "Numerator Source", "Denominator Dataset", "Negative Flow Treatment"]),
            ("11", "Market Share Record", ["Market Share Record ID", "Share Definition", "Period End Date", "Period Type", "Category / Segment", "Channel", "Region / Market", "Vehicle Type", "Firm Value", "Industry Value", "Market Share"]),
            ("11", "Industry Ranking", ["Ranked Firm", "Rank Position", "Ranking Universe"]),
            ("11", "Market Sizing Record", ["Market Sizing Record ID", "Sizing Subject Type", "Sizing Metric", "Channel", "Wealth Band", "Age Band", "Mapped Firm Segment", "Sizing Value", "Sizing As-of Date", "Source Dataset"]),
            ("11", "Opportunity Potential", ["Target Party", "Addressable Assets", "Firm Assets with Party", "Wallet Share", "Potential As-of Date"]),
            ("11", "Competitor Profile", ["Competitor Profile ID", "Competitor Party", "Competitor Tier"]),
            ("11", "Competitor Metric Snapshot", ["As-of Date", "Total AUM", "Reported Client Assets", "Reported Net New Assets", "Client Account Count"]),
            ("11", "Competitor Distribution Footprint", ["Channel", "Presence Strength", "Estimated Advisor Headcount"]),
            ("11", "Competitor Event", ["Competitor Event ID", "Competitor", "Event Type", "Event Date", "Assessed Impact"]),
            ("11", "Competitor Personnel Move", ["Individual", "Move Type", "From Competitor", "To Competitor", "Move Date"]),
            ("11", "Market Research Report", ["Research Report ID", "Research Topics", "Licensed Dataset"]),
            ("11", "Market Trend", ["Market Trend ID", "Trend Topic", "Indicator Value", "Indicator As-of Date", "Trend Direction"]),
            ("11", "Intelligence Item", ["Intelligence Item ID", "Publication Date", "Linked Competitors", "Relevance Rating"]),
            ("11", "Redistribution Restriction", ["Redistribution Permitted Indicator"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Net New Assets"]),
        ],
        upstream=["DP-014", "DP-008", "DP-481", "DP-001", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, or two business days after an industry data release is published if later; quarterly sizing and share definitions by business day 15 after quarter-end",
        history="Every release kept with its supersession chain; market share and ranking history monthly since go-live, kept 10 years; competitor events, moves and intelligence counts kept 7 years",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Mapped Share Class resolves to an own share class in DP-004, every Competitor Profile ID to DP-481, every Licensed Dataset to a DP-014 dataset profile, and every Distributor Firm on an observation and every Opportunity Potential Target Party to a DP-001 partner firm.",
            "Category Mapping rows of one Category Scheme and External Category Value do not overlap and Mapping Effective To is on or after Mapping Effective From; a dataset has one current release per As-of Date (no two Final releases where neither supersedes the other).",
            "Firm Value of every Market Share Record whose Share Definition has Numerator Source DP-008 equals the locked DP-008 Measure Amount (Ending Client Assets or Net New Assets) for the same Period End Date and Channel or segment within USD 1, Market Share equals Firm Value / Industry Value within 0.0001, and Industry Net Flow, Industry Organic Growth Rate and Mapped Coverage % equal DP-014's published values for the release.",
            "Industry Category, Net Flow, Ending Assets and Value Basis are populated on every observation of a Final release, and Sizing Metric, Sizing Value and Sizing As-of Date on every Market Sizing Record.",
            "Competitor Personnel Move Individual is read only to count moves and is never published, and Opportunity Potential rows are published only where Target Party is a partner firm, never an external advisor (CW-160).",
            "Rows from a dataset whose Redistribution Permitted Indicator is N are delivered only to entitled internal users (warehouse, semantic model and dashboard) and never in a file extract, and the product uses only the latest Final release available on the build date.",
        ],
        notes=("Certified numbers: reads Ending Client Assets and Net New Assets from DP-008 (Measure Value of the locked snapshot) as the "
               "numerators of channel and segment share (CW-241, CW-011); owns none. Competitor Total AUM is the competitor's reported "
               "figure and is never compared with or added to Firm AUM or Client Assets. "
               "PII tier: none at publication. pii = N: Competitor Personnel Move Individual (PII - identity, professional facts) is "
               "read only to count moves (DQ5); the validator's PII warning on the other attributes is the lexical 'No PII' object-tier "
               "note on each object's first attribute, and those objects carry no personal data. "
               "Boundaries: DP-014 conforms the industry datasets, categories and peer universes and DP-481 the competitors and their "
               "offerings; this product computes the shares and penetration views and never re-masters either. Competitor pricing and "
               "fee benchmarks are DP-506's. The leadership scorecard DP-490 reads the share measures from here. Successor of DP-031 "
               "(CW-240). WP1 scope: also reads 11 Opportunity Potential (from backlog DP-482) and 11 Competitor Distribution Footprint, "
               "Competitor Event, Competitor Personnel Move, Market Research Report, Market Trend and Intelligence Item (from backlog "
               "DP-508), which fold in here if those products are picked up. "
               "Tailoring lever: competitor set and capture (11 SME 1 to 3). Reference default: primary and secondary competitor tiers "
               "from public sources; lever: a licensed vendor dataset. Tailoring lever: competitor personnel moves (11 SME 7). Reference "
               "default: counted only; lever: drop the object. Tailoring lever: segment share basis (11 SME 8). Reference default: "
               "household investable assets from the Federal Reserve Survey of Consumer Finances and a vendor sizing dataset. "
               "Taxonomy gap: 11 Industry Flow Observation has no flag marking the firm's own observation; Fund Category Market Share % "
               "relies on Fund Manager Firm naming the firm. Taxonomy gap: 11 Market Sizing Record Mapped Firm Segment has no typed "
               "reference to the 02 segmentation scheme, so penetration joins on the segment code. "
               "Drafting assumptions: Release Status value Final; Sizing Metric values listed; Relevance Rating High; Numerator Source "
               "value DP-008; tolerances USD 1 and 0.0001; business days 10 and 15. "
               "Decisions: CW-011, CW-160, CW-240, CW-241, CW-245. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eleven "
               "objects (06 Client Asset Measures read with Measure Value and Snapshot) plus 11 Competitor Profile as the key of the "
               "metric snapshot and footprint groups and the seven moved reads; upstream DP-001 added for the partner-firm keys. Fix pass: DP-014's measures are read under their own names, never recomputed: 'Industry Net Flow' and 'Industry Organic Growth Rate' renamed with '(from DP-014)', and 'Unmapped Industry Assets %' replaced by 'Mapped Coverage % (from DP-014)' (no reader of the old names)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-487": dict(
        definition=("The calculated, invoiced, accrued and paid amount of every platform, sub-accounting, networking, omnibus "
                    "processing, data, model marketplace and intermediary communication fee the firm pays to intermediaries: "
                    "the 05 arrangement terms applied to the basis, checked against the client asset positions of DP-007, the "
                    "sub-account and networked account counts behind per-account fees, and the 10 cost items and accruals that "
                    "book them. Finance accrues correctly, the fund-paid share stays within the board-approved cap, and the "
                    "channel can show what each intermediary was paid and why. It owns no certified metric family."),
        business_questions=[
            "What did we calculate, get invoiced for and pay each intermediary this month, by payment type and funding source?",
            "Do the calculated payments agree with the arrangement terms and with the assets and accounts we hold through the partner?",
            "How much of the sub-accounting cost did the funds bear within the board-approved cap, and how much did the adviser bear?",
            "Are accruals complete for the period, and how large were the true-ups when invoices arrived?",
            "Which arrangements are near their annual cap or paying outside their effective period?",
        ],
        grain=("Payment calculation (payment arrangement x calculation period) as the main output, with partner invoices, partner "
               "payments, intermediary communication fee invoices, distribution cost items and accruals as companion facts; closed "
               "accrual periods locked, true-ups appended"),
        dimensions=["Partner firm (DP-001)", "Payment arrangement and governing agreement (DP-005)", "Payment type", "Funding source",
                    "Calculation basis and tiering method", "Calculation period and accrual period (DP-013)", "Share class (DP-004)",
                    "Bearing legal entity (DP-013)", "Cost center (DP-190)", "Distribution expense category", "Invoice and payment status",
                    "Data feed (governed by a data agreement)"],
        measures=[
            ("Calculated Partner Payments",
             "Sum of Calculated Amount of Payment Calculations whose Calculation Period End falls in the period, by Calculated Arrangement, Payment Type, Funding Source and Payee Entity.",
             _u("05", "Payment Calculation", "Calculation ID", "Calculated Arrangement", "Calculation Period Start", "Calculation Period End", "Calculated Amount")
             + _u("05", "Payment Arrangement", "Payment Arrangement ID", "Payment Type", "Funding Source", "Payee Entity")),
            ("Recalculated Payment Variance",
             "Calculated Amount minus the amount re-derived from the terms in force for the Calculation Period: Basis Value x Base Rate (Calculation Basis asset-based, Tiering Method None), Basis Value banded by Rate Tier (Tier Lower Bound, Tier Upper Bound, Tier Rate by Tier Sequence; Incremental or Cliff / Whole Balance), Flat Fee Amount, or Per-Account Fee Amount x Basis Value for per-account bases; pro-rated for a partial period.",
             _u("05", "Payment Calculation", "Calculation ID", "Calculation Period Start", "Calculation Period End", "Basis Value", "Calculated Amount")
             + _u("05", "Rate Schedule", "Calculation Basis", "Base Rate", "Flat Fee Amount", "Tiering Method", "Rate Schedule Effective From", "Rate Schedule Effective To")
             + _u("05", "Rate Tier", "Tier Sequence", "Tier Lower Bound", "Tier Upper Bound", "Tier Rate")
             + _u("05", "Sub-Accounting Fee Terms", "Per-Account Fee Amount")),
            ("Payment Basis Variance to Client Asset Positions",
             "Basis Value of asset-based calculations minus the average of Market Value of DP-007 Fund Shareholder Positions with Aggregation Role Counted - Intermediary on the partner's accounts (Agreement Account Link of the governing agreement) and the arrangement's share classes, over the Valuation Dates of the calculation period; Basis Snapshot names the 06 snapshot used.",
             _u("05", "Payment Calculation", "Calculation ID", "Basis Value", "Basis Snapshot")
             + _u("06", "Fund Shareholder Position", "Position ID", "Account", "Share Class", "Valuation Date", "Aggregation Role", "Market Value")
             + _u("05", "Agreement Account Link", "Linked Account", "Account Link Effective From", "Account Link Effective To")),
            ("Sub-Accounts Billed vs Look-Through",
             "For per-account sub-accounting calculations: Calculated Amount / Per-Account Fee Amount (accounts billed) minus the count of distinct Sub-Account Identifier As Delivered under the partner's Omnibus Parent Accounts with a Look-Through Source on the period end, plus networked accounts whose 15 Intermediary Account Servicing names the partner as Dealer of Record with Networking Level billed per account; a count of accounts, never identifiers.",
             _u("05", "Payment Calculation", "Calculated Amount")
             + _u("05", "Sub-Accounting Fee Terms", "Per-Account Fee Amount")
             + _u("06", "Omnibus Look-Through", "Omnibus Parent Account", "Sub-Account Identifier As Delivered", "Look-Through Source")
             + _u("15", "Intermediary Account Servicing", "Networking Level", "Dealer of Record")),
            ("Fund-Paid Amount Above Sub-TA Cap",
             "For arrangements with Funding Source Fund - Non-Distribution Services: Calculated Amount minus Fund-Paid Sub-TA Cap x the accounts or assets billed for the period, where positive; the excess is adviser-borne when Excess Borne by Adviser Indicator is Y and is a cap breach otherwise.",
             _u("05", "Payment Calculation", "Calculated Amount", "Basis Value")
             + _u("05", "Payment Arrangement", "Funding Source")
             + _u("05", "Sub-Accounting Fee Terms", "Fund-Paid Sub-TA Cap", "Excess Borne by Adviser Indicator")),
            ("Adviser-Borne Cost",
             "Sum of Adviser-Borne Amount by Adviser-Borne Cost Type and Related Payment Arrangement for the period: the sub-accounting excess and other intermediary costs the adviser pays from its own resources.",
             _u("10", "Adviser-Borne Cost", "Adviser-Borne Cost Type", "Related Payment Arrangement", "Adviser-Borne Amount")),
            ("Invoice to Calculation Variance",
             "Invoiced Amount of Partner Invoices from the Invoicing Partner for the period minus Calculated Partner Payments of the partner's arrangements for the same period; reported per partner and invoice.",
             _u("05", "Partner Invoice", "Partner Invoice Number", "Invoicing Partner", "Invoiced Amount", "Invoice Status")
             + ["Calculated Partner Payments"]),
            ("Partner Payments Made",
             "Sum of Payment Amount of Partner Payments with Payment Status Paid and Payment Date in the period, by Charged Entity and the partner of the Invoices Settled.",
             _u("05", "Partner Payment", "Partner Payment ID", "Payment Date", "Payment Amount", "Charged Entity", "Payment Status", "Invoices Settled")),
            ("Approved Invoices Unpaid",
             "Invoiced Amount of Partner Invoices with Invoice Status Approved that no Partner Payment with Payment Status Paid lists in Invoices Settled, by age from the end of the invoiced period.",
             _u("05", "Partner Invoice", "Partner Invoice Number", "Invoiced Amount", "Invoice Status")
             + _u("05", "Partner Payment", "Payment Status", "Invoices Settled")),
            ("Annual Cap Utilization %",
             "Calendar year-to-date Calculated Partner Payments of an arrangement / Annual Payment Cap x 100, for arrangements with a cap; arrangements above 90% flagged.",
             _u("05", "Payment Arrangement", "Payment Arrangement ID", "Annual Payment Cap")
             + ["Calculated Partner Payments"]),
            ("Calculations Outside Arrangement Terms",
             "Count of Payment Calculations whose Calculation Period is not inside Arrangement Effective From / To of the arrangement, whose arrangement has a Payment Arrangement Status other than Active, or for which no Rate Schedule is in force for the period.",
             _u("05", "Payment Calculation", "Calculation ID", "Calculated Arrangement", "Calculation Period Start", "Calculation Period End")
             + _u("05", "Payment Arrangement", "Payment Arrangement Status", "Arrangement Effective From", "Arrangement Effective To")
             + _u("05", "Rate Schedule", "Rate Schedule Effective From", "Rate Schedule Effective To")),
            ("Intermediary Communication Fees",
             "Sum of Invoice Amount of Intermediary Communication Fee Invoices by Fee Type, Fee Paid By and Invoicing Party for the period, with the Governing Agreement named.",
             _u("05", "Intermediary Communication Fee Invoice", "Fee Invoice ID", "Invoicing Party", "Fee Type", "Invoice Amount", "Fee Paid By", "Governing Agreement")),
            ("Data Fees by Governed Feed",
             "Calculated Partner Payments of arrangements with Payment Type Data Fee by the 06 Data Feed whose Partner Data Feed Arrangement names the arrangement's Governing Agreement as Governing Data Agreement, and the count of intermediary feeds (Feed Type Intermediary Sub-Accounting, SMA / UMA Sponsor, Third-Party Recordkeeper) with no Governing Data Agreement.",
             _u("05", "Partner Data Feed Arrangement", "Data Feed", "Governing Data Agreement")
             + _u("05", "Payment Arrangement", "Governing Agreement", "Payment Type")
             + _u("06", "Data Feed", "Feed ID", "Feed Name", "Feed Type")
             + ["Calculated Partner Payments"]),
            ("Accrued Intermediary Cost",
             "Sum of Accrued Amount of Accruals for the Accrual Period on Distribution Cost Items whose Source Domain is 05, by Distribution Expense Category, Bearing Legal Entity, Cost Center and Direct Product / Share Class.",
             _u("10", "Accrual", "Accrual ID", "Accrued Cost Item", "Accrual Period", "Accrued Amount")
             + _u("10", "Distribution Cost Item", "Distribution Cost Item ID", "Distribution Expense Category", "Source Domain", "Bearing Legal Entity", "Cost Center", "Direct Product / Share Class")),
            ("Accrual True-Up",
             "Sum of True-Up Amount by True-Up Reason for the period and True-Up Amount / Accrued Amount x 100 of the accrual period it corrects.",
             _u("10", "Accrual", "Accrual Period", "Accrued Amount", "True-Up Amount", "True-Up Reason")),
            ("Accrual to Calculation Variance",
             "Accrued Amount of Distribution Cost Items whose Source Record is a Payment Calculation minus that calculation's Calculated Amount, for the Accrual Period that contains the Calculation Period End.",
             _u("10", "Distribution Cost Item", "Source Record", "Service Period Start", "Service Period End", "Expense Amount")
             + _u("10", "Accrual", "Accrued Cost Item", "Accrual Period", "Accrued Amount")
             + _u("05", "Payment Calculation", "Calculation ID", "Calculation Period End", "Calculated Amount")),
            ("Fund-Borne and Firm-Borne Intermediary Cost",
             "Expense Amount of Distribution Cost Items with Source Domain 05 split by Funding Source (fund-paid within the cap against adviser or distributor own resources) and Cost Counterparty for the period.",
             _u("10", "Distribution Cost Item", "Source Domain", "Funding Source", "Cost Counterparty", "Service Period Start", "Service Period End", "Expense Amount")),
            ("Pass-Through Distribution Revenue %",
             "Amount Passed Through / Gross Distribution Revenue x 100 of Distribution Revenue Records by Distribution Revenue Type and Paying Share Class (from DP-012); empty under the reference default (no Rule 12b-1 plans), populated when the revenue sharing and 12b-1 lever is on.",
             _u("10", "Distribution Revenue Record", "Distribution Revenue Type", "Paying Share Class", "Gross Distribution Revenue", "Amount Passed Through")),
        ],
        inputs=[
            ("05", "Payment Arrangement", ["Payment Arrangement ID", "Governing Agreement", "Payment Type", "Payer Entity", "Payee Entity", "Funding Source", "Services Compensated", "Payment Arrangement Status", "Arrangement Effective From", "Arrangement Effective To", "Annual Payment Cap"]),
            ("05", "Rate Schedule", ["Calculation Basis", "Base Rate", "Flat Fee Amount", "Tiering Method", "Rate Schedule Effective From", "Rate Schedule Effective To"]),
            ("05", "Rate Tier", ["Tier Lower Bound", "Tier Sequence", "Tier Upper Bound", "Tier Rate"]),
            ("05", "Sub-Accounting Fee Terms", ["Per-Account Fee Amount", "Fund-Paid Sub-TA Cap", "Excess Borne by Adviser Indicator"]),
            ("05", "Payment Calculation", ["Calculation ID", "Calculated Arrangement", "Calculation Period Start", "Calculation Period End", "Basis Value", "Basis Snapshot", "Calculated Amount"]),
            ("05", "Partner Invoice", ["Partner Invoice Number", "Invoicing Partner", "Invoiced Amount", "Invoice Status"]),
            ("05", "Partner Payment", ["Partner Payment ID", "Payment Date", "Payment Amount", "Charged Entity", "Payment Status", "Invoices Settled"]),
            ("05", "Intermediary Communication Fee Invoice", ["Fee Invoice ID", "Invoicing Party", "Fee Type", "Invoice Amount", "Fee Paid By", "Governing Agreement"]),
            ("05", "Partner Data Feed Arrangement", ["Data Feed", "Governing Data Agreement"]),
            ("05", "Agreement Account Link", ["Linked Account", "Account Link Effective From", "Account Link Effective To"]),
            ("10", "Distribution Cost Item", ["Distribution Cost Item ID", "Distribution Expense Category", "Source Domain", "Source Record", "Cost Counterparty", "Bearing Legal Entity", "Funding Source", "Cost Center", "Direct Product / Share Class", "Service Period Start", "Service Period End", "Expense Amount"]),
            ("10", "Accrual", ["Accrual ID", "Accrued Cost Item", "Accrual Period", "Accrued Amount", "True-Up Amount", "True-Up Reason"]),
            ("10", "Adviser-Borne Cost", ["Adviser-Borne Cost Type", "Related Payment Arrangement", "Adviser-Borne Amount"]),
            ("10", "Distribution Revenue Record", ["Distribution Revenue Type", "Paying Share Class", "Gross Distribution Revenue", "Amount Passed Through"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Account", "Share Class", "Valuation Date", "Aggregation Role", "Market Value"]),
            ("06", "Omnibus Look-Through", ["Omnibus Parent Account", "Sub-Account Identifier As Delivered", "Look-Through Source"]),
            ("06", "Data Feed", ["Feed ID", "Feed Name", "Feed Type"]),
            ("15", "Intermediary Account Servicing", ["Networking Level", "Dealer of Record"]),
        ],
        upstream=["DP-005", "DP-001", "DP-007", "DP-012", "DP-093", "DP-190", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Calculations and accruals by business day 3 after month-end; invoices and payments refreshed daily as they post",
        history="Monthly calculations, invoices, payments and accruals kept 7 years with every true-up appended (Rule 17a-4 and Rule 31a-2 support for fund-paid amounts); closed accrual periods immutable",
        classification="Restricted - Commercial Terms",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Calculated Arrangement resolves to a DP-005 Payment Arrangement with a Governing Agreement, every Invoicing Partner, Charged Entity, Payee Entity and Invoicing Party to a DP-001 partner firm or a DP-013 legal entity, every Direct Product / Share Class to DP-004 and every Cost Center to DP-190.",
            "Rate Schedule periods of one arrangement do not overlap and end on or after they start, Rate Tier bands of a schedule are contiguous by Tier Sequence, and every Calculation Period Start is on or before its Calculation Period End and inside the arrangement's effective period.",
            "Recalculated Payment Variance is within USD 1 per calculation, Payment Basis Variance to Client Asset Positions within 0.5% of the DP-007 value, and Partner Payments Made of a payment equals the Invoiced Amount of the invoices it settles; a breach holds the calculation from accrual.",
            "Calculated Amount, Basis Value, Payment Type and Funding Source are populated on every calculation, and Expense Amount, Cost Center and Bearing Legal Entity on every Distribution Cost Item.",
            "Sub-Account Identifier As Delivered and the 15 account keys are read only to count accounts and are never published; outputs are at partner x arrangement x period grain.",
            "Accruals for a month are complete by business day 3 after month-end and the accrual period is locked after the close; any later change is recorded as a True-Up Amount with a True-Up Reason, never as an edit.",
        ],
        notes=("Certified numbers: none owned or read; distribution revenue records are read as DP-012 publishes them, and the asset "
               "basis is checked against DP-007 client asset positions, never against Client Assets or Firm AUM. "
               "PII tier: none at publication. pii = N: 06 Omnibus Look-Through Sub-Account Identifier As Delivered (PII - financial at "
               "sub-account level) and the 15 Intermediary Account Servicing keys are read only to count accounts (DQ5); the other PII "
               "warnings are the lexical 'No PII' object-tier notes of the 05 and 06 objects, whose partners are firms. "
               "Boundaries: the arrangement terms are DP-005's (master) and this product never re-masters them; 05 Basis Value is a "
               "Derived copy of 06 and is checked here; 47 client fees are not read (client fees are DP-305's and DP-012's); the 19 "
               "payable and the ledger tie-out are DP-191's and DP-598's, so DP-191 (listed by the candidate) is not upstream. "
               "Intermediary oversight and the payment disclosure reconciliation read the payments from here (DP-486); profitability "
               "reads them as distribution costs (DP-499). Successor of DP-034 (CW-136, CW-240). WP1 scope: also reads 05 Partner Data "
               "Feed Arrangement (from backlog DP-485 and DP-494); the sub-accounting basis checks of backlog DP-494 (look-through "
               "sub-accounts and networked accounts behind per-account fees) are taken here. "
               "Tailoring lever: payments to intermediaries (05 SME 3). Reference default: platform, sub-accounting, networking, "
               "omnibus processing, data and model marketplace fees; lever: revenue sharing and Rule 12b-1 values, which fill "
               "Pass-Through Distribution Revenue. Tailoring lever: fund-paid sub-accounting cap. Reference default: per-account cap "
               "approved by the fund boards, excess borne by the adviser. "
               "Taxonomy gap: 05 Payment Calculation has no attribute naming the share classes or accounts in its basis, so the DP-007 "
               "comparison selects them through Agreement Account Link and the arrangement's agreement coverage. Taxonomy gap: 05 "
               "Partner Invoice has no invoiced period, so Invoice to Calculation Variance matches on partner and the calculation "
               "period that precedes the invoice. "
               "Drafting assumptions: Payment Status Paid; Invoice Status Approved; Funding Source and Payment Type values as listed in "
               "the 05 code lists; Source Domain value 05; tolerances USD 1 and 0.5%; the 90% cap threshold; business day 3. "
               "Decisions: CW-131, CW-136, CW-240, CW-245, CW-246. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's twelve "
               "05 and 10 objects with the moved read, plus 05 Agreement Account Link, 06 Fund Shareholder Position, Omnibus Look-Through "
               "and Data Feed and 15 Intermediary Account Servicing for the basis checks; upstream DP-191 dropped, DP-093 and DP-190 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-486": dict(
        definition=("The oversight record of each intermediary partner and agreement: annual distributor due diligence and its "
                    "findings, agreement obligations and amendments with their compliance status, networking and SEC Rule 22c-2 "
                    "set-up of the dealer accounts, and the payments made (from DP-487) reconciled to the payment disclosures "
                    "(prospectus and SAI statements, ERISA section 408(b)(2) information for plan accounts). It shows which "
                    "partners are overdue for review, which obligations are breached and which payments are not disclosed. "
                    "It owns no certified metric family."),
        business_questions=[
            "Which active partners are overdue for their annual due diligence review, and which reviews ended restricted or suspended?",
            "Which due diligence findings are open, how severe are they and how long have they been open?",
            "Which agreement obligations are not being met, and which agreements lack an executed contract or a current review?",
            "Are all omnibus and networked dealer set-ups covered by a Rule 22c-2 agreement?",
            "Which payments made this year are not covered by a current payment disclosure, including 408(b)(2) disclosures for plan accounts?",
        ],
        grain=("Partner firm x distribution agreement x as-of date as the main output, with due diligence reviews and findings, "
               "obligations, amendments, dealer set-ups and payment disclosures as companion facts; monthly snapshots, findings and "
               "obligation status SCD type 2"),
        dimensions=["Partner firm (DP-001)", "Distribution agreement, agreement type and status (DP-005)", "Due diligence review type and outcome",
                    "Residual risk rating", "Finding category and severity", "Obligation category and compliance status",
                    "Dealing route, account structure and networking level", "Payment type and funding source (DP-005)",
                    "Disclosure type", "Executed contract (DP-213)", "As-of date (DP-013)"],
        measures=[
            ("Partners Overdue for Due Diligence",
             "Count of partner firms with an Agreement Status Active agreement whose latest Distributor Due Diligence has Next Review Due Date before the as-of date and no later review with a Due Diligence Completed Date, or that have no review at all.",
             _u("05", "Distributor Due Diligence", "Due Diligence ID", "Distributor Firm", "Due Diligence Completed Date", "Next Review Due Date")
             + _u("05", "Distribution Agreement", "Agreement ID", "Agreement Status")),
            ("Reviews Completed by Outcome",
             "Count of Distributor Due Diligence reviews with Due Diligence Completed Date in the period by Due Diligence Review Type and Due Diligence Outcome (Approved, Approved with Conditions, Restricted, Suspended, Terminated).",
             _u("05", "Distributor Due Diligence", "Due Diligence ID", "Due Diligence Review Type", "Due Diligence Outcome", "Due Diligence Completed Date")),
            ("High Residual Risk Partners",
             "Count of partner firms whose latest completed review has Residual Risk Rating High, with their Due Diligence Outcome.",
             _u("05", "Distributor Due Diligence", "Distributor Firm", "Residual Risk Rating", "Due Diligence Outcome", "Due Diligence Completed Date")),
            ("Review Evidence Gaps",
             "Count of completed reviews where Sanctions Screening Result is not Clear, Regulatory Status Verified Indicator is not Y, Questionnaire Received Date is empty, or SOC 1 Report Received Date is empty for a partner whose dealer set-up has Recordkeeping Responsibility Intermediary.",
             _u("05", "Distributor Due Diligence", "Due Diligence ID", "Sanctions Screening Result", "Regulatory Status Verified Indicator", "Questionnaire Received Date", "SOC 1 Report Received Date")
             + _u("05", "Networking Setup", "Recordkeeping Responsibility")),
            ("Open Due Diligence Findings",
             "Count of Due Diligence Findings with Remediation Status not Closed by Finding Category and Finding Severity, with age in days from the parent review's Due Diligence Completed Date.",
             _u("05", "Due Diligence Finding", "Due Diligence Finding Key", "Finding Category", "Finding Severity", "Remediation Status")
             + _u("05", "Distributor Due Diligence", "Due Diligence Completed Date")),
            ("Obligations Not Met",
             "Count of Agreement Obligations with Obligation Compliance Status Non-Compliant or At Risk by Obligation Category, plus SLA obligations whose Latest Measured Value misses the SLA Target Value.",
             _u("05", "Agreement Obligation", "Obligation ID", "Obligation Category", "Obligation Compliance Status", "SLA Target Value", "Latest Measured Value")),
            ("Amendments in Period",
             "Count of Agreement Amendments with Amendment Effective Date in the period, by agreement and Agreement Type.",
             _u("05", "Agreement Amendment", "Amendment ID", "Amendment Effective Date")
             + _u("05", "Distribution Agreement", "Agreement ID", "Agreement Type")),
            ("Agreements Without Current Due Diligence",
             "Count of Agreement Status Active agreements whose Distributor Due Diligence Reference names a review completed more than 12 months before the as-of date, or a review with Due Diligence Outcome Suspended or Terminated.",
             _u("05", "Distribution Agreement", "Agreement ID", "Agreement Status", "Distributor Due Diligence Reference")
             + _u("05", "Distributor Due Diligence", "Due Diligence ID", "Due Diligence Outcome", "Due Diligence Completed Date")),
            ("Agreements Without Executed Contract",
             "Count of Agreement Status Active agreements with no Executed Contract, or whose 39 Contract has Contract Status other than Executed or a Contract Expiry Date before the as-of date while Next Renewal Date is past.",
             _u("05", "Distribution Agreement", "Agreement ID", "Agreement Status", "Executed Contract")
             + _u("39", "Contract", "Contract ID", "Contract Status", "Contract Expiry Date")
             + _u("05", "Agreement Term", "Next Renewal Date")),
            ("Rule 22c-2 Coverage %",
             "Active Partner Dealer Setups (Dealer Setup Status Active) with Account Structure Omnibus or Networked whose Networking Setup has Rule 22c-2 Agreement in Place Indicator Y / all such active set-ups x 100, by Dealing Route and Networking Level.",
             _u("05", "Partner Dealer Setup", "Dealer Setup Partner", "TA Dealer Number", "Dealer Setup Status", "Dealing Route", "Account Structure")
             + _u("05", "Networking Setup", "Networking Level", "Rule 22c-2 Agreement in Place Indicator")),
            ("Payments Made (from DP-487)",
             "Payment Amount of Partner Payments with Payment Status Paid and Payment Date in the calendar year to date, by Charged Entity and the payment arrangement of the settled invoices, as DP-487 publishes them (Partner Payments Made).",
             _u("05", "Partner Payment", "Partner Payment ID", "Payment Date", "Payment Amount", "Charged Entity", "Payment Status")),
            ("Undisclosed Payments",
             "Payments Made (from DP-487) under arrangements with Prospectus Disclosure Indicator N, or not listed in the Disclosed Arrangements of any Payment Disclosure published by the Disclosing Party within the last 13 months; reported by Payment Type and Funding Source.",
             _u("05", "Payment Arrangement", "Payment Arrangement ID", "Payment Type", "Funding Source", "Prospectus Disclosure Indicator")
             + _u("05", "Payment Disclosure", "Disclosure Type", "Disclosing Party", "Disclosed Arrangements", "Disclosure Publication Date")
             + ["Payments Made (from DP-487)"]),
            ("Payments Disclosed %",
             "(Payments Made (from DP-487) - Undisclosed Payments) / Payments Made (from DP-487) x 100, by partner and funding source.",
             ["Payments Made (from DP-487)", "Undisclosed Payments"]),
            ("ERISA 408(b)(2) Disclosure Gaps",
             "Count of active arrangements whose governing agreement links plan accounts (Agreement Account Link to a 15 Account with Account Type Plan Participant Account or plan omnibus, in force on the as-of date) and pays a Covered Service Provider without a Payment Disclosure of Disclosure Type ERISA 408(b)(2) naming that Covered Service Provider with an Indirect Compensation Description.",
             _u("05", "Agreement Account Link", "Linked Account", "Account Link Role", "Account Link Effective From", "Account Link Effective To")
             + _u("15", "Account", "Account ID", "Account Type", "Account Status")
             + _u("05", "Payment Disclosure", "Disclosure Type", "Covered Service Provider", "Indirect Compensation Description")
             + _u("05", "Payment Arrangement", "Governing Agreement", "Payment Arrangement Status")),
            ("Linked Accounts Without Active Agreement",
             "Count of Agreement Account Links in force on the as-of date whose agreement has Agreement Status other than Active or a Termination Date before the as-of date.",
             _u("05", "Agreement Account Link", "Linked Account", "Account Link Effective From", "Account Link Effective To")
             + _u("05", "Distribution Agreement", "Agreement Status")
             + _u("05", "Agreement Term", "Termination Date")),
        ],
        inputs=[
            ("05", "Distributor Due Diligence", ["Due Diligence ID", "Distributor Firm", "Due Diligence Review Type", "Residual Risk Rating", "Sanctions Screening Result", "Regulatory Status Verified Indicator", "Questionnaire Received Date", "SOC 1 Report Received Date", "Due Diligence Outcome", "Due Diligence Completed Date", "Next Review Due Date"]),
            ("05", "Due Diligence Finding", ["Due Diligence Finding Key", "Finding Category", "Finding Severity", "Remediation Status"]),
            ("05", "Agreement Obligation", ["Obligation ID", "Obligation Category", "Obligation Compliance Status", "SLA Target Value", "Latest Measured Value"]),
            ("05", "Agreement Amendment", ["Amendment ID", "Amendment Effective Date"]),
            ("05", "Distribution Agreement", ["Agreement ID", "Agreement Type", "Agreement Status", "Distributor Due Diligence Reference", "Executed Contract"]),
            ("05", "Agreement Term", ["Agreement Effective Date", "Next Renewal Date", "Termination Date"]),
            ("05", "Partner Dealer Setup", ["Dealer Setup Partner", "TA Dealer Number", "Dealer Setup Status", "Dealing Route", "Account Structure"]),
            ("05", "Networking Setup", ["Networking Level", "Recordkeeping Responsibility", "Rule 22c-2 Agreement in Place Indicator"]),
            ("05", "Payment Disclosure", ["Disclosure Type", "Disclosing Party", "Disclosed Arrangements", "Disclosure Publication Date", "Covered Service Provider", "Indirect Compensation Description"]),
            ("05", "Payment Arrangement", ["Payment Arrangement ID", "Governing Agreement", "Payment Type", "Funding Source", "Payment Arrangement Status", "Prospectus Disclosure Indicator"]),
            ("05", "Agreement Account Link", ["Linked Account", "Account Link Role", "Account Link Effective From", "Account Link Effective To"]),
            ("05", "Partner Payment", ["Partner Payment ID", "Payment Date", "Payment Amount", "Charged Entity", "Payment Status"]),
            ("39", "Contract", ["Contract ID", "Contract Status", "Contract Expiry Date"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
        ],
        upstream=["DP-005", "DP-001", "DP-487", "DP-213", "DP-093", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end, after DP-487 has posted the month's payments; due diligence and finding status refreshed weekly",
        history="Monthly snapshots kept 7 years; due diligence reviews, findings and payment disclosures kept for the life of the agreement plus 6 years (FINRA Rule 2341 and Rule 22c-2 records, Rule 17a-4)",
        classification="Restricted - Commercial Terms",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Distributor Firm, Dealer Setup Partner, Disclosing Party and Covered Service Provider resolves to an active DP-001 party, every agreement to DP-005, every Executed Contract to a DP-213 contract and every Linked Account to a DP-093 account.",
            "Agreement Account Link periods of one agreement and account do not overlap and end on or after they start, and every finding belongs to exactly one Distributor Due Diligence review.",
            "Payments Made (from DP-487) equals DP-487's published Partner Payments Made for the same partner and period within USD 1, and Undisclosed Payments never exceeds Payments Made (from DP-487).",
            "Due Diligence Outcome, Residual Risk Rating and Due Diligence Completed Date are populated on every completed review, and Obligation Compliance Status on every Agreement Obligation of an active agreement.",
            "Partner parties that are individuals (sole-practitioner RIAs) are published with their 02 party key and firm name only, as professional data under CW-150, and no employee or advisor attribute is published.",
            "The monthly snapshot is taken from the DP-005 and DP-487 data as of the last business day of the month and is locked once published; corrections create a new snapshot version.",
        ],
        notes=("Certified numbers: none owned or read. "
               "PII tier: identity (professional data, CW-150): partner firms can be individuals (sole-practitioner RIAs) whose 02 party "
               "key and name identify a person; no employee, advisor or client attribute is published (DQ5). "
               "Boundaries: the agreements, payment arrangements, dealer set-ups and shelf are DP-005's (master); payment calculation and "
               "payment accounting are DP-487's, read as published; 08 retail conduct supervision is not this product's. Successor of "
               "DP-063 and DP-081 (CW-136, CW-240), and of the oversight part of DP-037 (CLA-B disposition); EU/UK inducement content "
               "dropped (CW-905). The candidate's 05 Agreement Obligation owner is not read: the object has no owner attribute and the "
               "agreement's Business Owner (an employee) is left out, so the dashboard is by agreement and partner. "
               "Tailoring lever: oversight form (05 SME 6). Reference default: an annual review per active partner; lever: attestation on "
               "the agreement instead of a review for low-risk partners. Tailoring lever: payments to intermediaries (05 SME 3). Reference "
               "default: platform, sub-accounting and networking fees disclosed in the prospectus and SAI; lever: revenue sharing, which "
               "adds the FINRA Rule 2341 and SEC disclosure checks to Undisclosed Payments. "
               "Taxonomy gap: 05 Payment Disclosure Disclosed Arrangements is free text or a list, so matching to Payment Arrangement ID "
               "is by reference value. Taxonomy gap: 05 Due Diligence Finding has no remediation due date, so findings age from the "
               "review completion date. "
               "Drafting assumptions: Agreement Status Active; Dealer Setup Status Active; Account Structure values Omnibus and Networked; "
               "Recordkeeping Responsibility value Intermediary; Disclosure Type value ERISA 408(b)(2); Obligation Compliance Status "
               "values Non-Compliant and At Risk; Remediation Status Closed; Sanctions Screening Result Clear; Contract Status Executed; "
               "the 12- and 13-month windows; business day 5. "
               "Decisions: CW-131, CW-135, CW-136, CW-150, CW-240, CW-245. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eight "
               "objects plus 05 Distribution Agreement, Agreement Term, Partner Dealer Setup, Payment Arrangement and Partner Payment and "
               "15 Account for the oversight joins; upstream DP-213 and DP-093 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-488": dict(
        definition=("Open and decided opportunities by type (institutional mandate or OCIO search, intermediary shelf or model "
                    "placement, plan sponsor recordkeeping prospect), stage, weighted value and outcome, with the RFPs, consultant "
                    "ratings and database submissions behind institutional searches, the mandate search events in the market and "
                    "the plan market white space behind sponsor prospecting. Institutional advisory, workplace and intermediary "
                    "teams forecast wins, see which ratings and submissions are at risk and learn why they lose. Prospects stay "
                    "02 parties; won assets count as Net New Assets only when funded (DP-008). It owns no certified metric family."),
        business_questions=[
            "What is the open and weighted pipeline by opportunity type, stage and business line, and what is expected to fund in the next 90 days?",
            "What is our win rate by opportunity type and consultant, and why do we lose?",
            "How many RFPs did we receive and submit, how many were late or lacked final compliance approval, and how many did we win?",
            "Which consultant ratings have fallen and which database submissions are late?",
            "How large is the plan recordkeeping white space, and how much of it do we cover with open prospects?",
        ],
        grain=("Sales opportunity (OPP-) x as-of date as the main output, with RFP requests and submissions, consultant ratings, "
               "database submissions, mandate search events, plan market records and win/loss analyses as companion facts; weekly "
               "pipeline snapshots, stage history SCD type 2"),
        dimensions=["Opportunity type and business type", "Sales stage", "Opportunity sales channel and business line", "Prospect or client (DP-240)",
                    "Institution, consultant and plan (DP-003)", "Retirement plan and recordkeeper (DP-094, DP-003)", "Target platform or sponsor (DP-001)",
                    "Proposed offering or strategy (DP-004)", "Opportunity owner (DP-192)", "Win/loss reason and winning competitor (DP-481)",
                    "Request type", "Manager database", "Mandate asset class", "As-of date (DP-013)"],
        measures=[
            ("Open Pipeline Value",
             "Sum of Expected Amount of opportunities whose Sales Stage is not Closed Won - Funded, Closed Lost or Closed Withdrawn, by Opportunity Type, Sales Stage, Opportunity Sales Channel and Opportunity Business Line.",
             _u("05", "Sales Opportunity", "Opportunity ID", "Opportunity Type", "Opportunity Sales Channel", "Opportunity Business Line")
             + _u("05", "Pipeline Status", "Sales Stage")
             + _u("05", "Opportunity Value", "Expected Amount")),
            ("Weighted Pipeline Value",
             "Sum over open opportunities of Expected Amount x Probability, by Opportunity Type and Sales Stage.",
             _u("05", "Pipeline Status", "Sales Stage", "Probability")
             + _u("05", "Opportunity Value", "Expected Amount")),
            ("Weighted Expected Annual Revenue",
             "Sum over open opportunities of Expected Annual Revenue x Probability, by Opportunity Type and Proposed Offering or Strategy.",
             _u("05", "Sales Opportunity", "Proposed Offering or Strategy")
             + _u("05", "Pipeline Status", "Probability")
             + _u("05", "Opportunity Value", "Expected Annual Revenue")),
            ("Expected Fundings Next 90 Days",
             "Weighted Pipeline Value of open opportunities with Expected Funding Date within 90 days of the as-of date.",
             _u("05", "Pipeline Status", "Expected Funding Date")
             + ["Weighted Pipeline Value"]),
            ("Opportunities Past Expected Close",
             "Count and Expected Amount of open opportunities whose Expected Close Date is before the as-of date.",
             _u("05", "Pipeline Status", "Sales Stage", "Expected Close Date")
             + _u("05", "Opportunity Value", "Expected Amount")),
            ("Won Amount",
             "Sum of Expected Amount of opportunities with Opportunity Outcome Won and Actual Close Date in the period, by Opportunity Type, Business Type and Search Consultant.",
             _u("05", "Sales Opportunity", "Opportunity Type", "Business Type", "Search Consultant")
             + _u("05", "Win / Loss", "Opportunity Outcome")
             + _u("05", "Opportunity Value", "Expected Amount", "Actual Close Date")),
            ("Win Rate %",
             "Count of opportunities with Opportunity Outcome Won / count with Opportunity Outcome Won or Lost, Actual Close Date in the period, x 100; by Opportunity Type, Search Consultant and Proposed Offering or Strategy.",
             _u("05", "Sales Opportunity", "Opportunity Type", "Search Consultant", "Proposed Offering or Strategy")
             + _u("05", "Win / Loss", "Opportunity Outcome")
             + _u("05", "Opportunity Value", "Actual Close Date")),
            ("Losses by Reason and Competitor",
             "Count and Expected Amount of opportunities with Opportunity Outcome Lost in the period by Primary Win / Loss Reason and Winning Competitor, beside the 11 Win/Loss Analysis Top Loss Reasons and Most Frequent Winning Competitor of the Analysis Segment.",
             _u("05", "Win / Loss", "Opportunity Outcome", "Primary Win / Loss Reason", "Winning Competitor")
             + _u("05", "Opportunity Value", "Expected Amount")
             + _u("11", "Win/Loss Analysis", "Analysis Period End", "Analysis Segment", "Win Rate", "Top Loss Reasons", "Most Frequent Winning Competitor")),
            ("RFPs Received and Submitted",
             "Count of RFP Requests by Request Type and Request Status received in the period, and of those with an RFP Submission Submission Timestamp.",
             _u("05", "RFP Request", "RFP ID", "Request Type", "Issuing Party", "Request Status")
             + _u("05", "RFP Submission", "Submission Timestamp")),
            ("RFP Award Rate %",
             "Count of RFP Submissions with RFP Outcome Awarded / count with RFP Outcome Awarded or Not Awarded in the period x 100, by Request Type and the Related Opportunity's Opportunity Type.",
             _u("05", "RFP Request", "RFP ID", "Request Type", "Related Opportunity")
             + _u("05", "RFP Submission", "RFP Outcome")
             + _u("05", "Sales Opportunity", "Opportunity ID", "Opportunity Type")),
            ("RFPs Late or Without Compliance Approval",
             "Count of RFP Submissions whose Submission Timestamp is after the Response Due Date of the request, or that have no Final Compliance Approval.",
             _u("05", "RFP Request", "RFP ID", "Response Due Date")
             + _u("05", "RFP Submission", "Submission Timestamp", "Final Compliance Approval")),
            ("Consultant Ratings Downgraded",
             "Count of rated strategies or products (Rated Strategy / Product) whose latest Consultant Rating Rating Value is lower than the previous rating of the same Rating Provider and Rating Type, by Rating Date in the period.",
             _u("05", "Consultant Rating", "Rating Provider", "Rated Strategy / Product", "Rating Type", "Rating Value", "Rating Date")),
            ("Database Submissions Late %",
             "Count of Database Submissions with Submission Status Late, or with Submitted Date more than 30 days after Submission Period End / all submissions due in the period x 100, by Manager Database.",
             _u("05", "Database Profile", "Database Profile ID", "Manager Database", "Linked Strategy / Product")
             + _u("05", "Database Submission", "Submission Period End", "Submitted Date", "Submission Status")),
            ("Searches in Market",
             "Count of Mandate Search Events by Search Event Type, Mandate Asset Class and Consultant with Event Date in the period, their Mandate Size, and the share where Winning / Hired Manager is the firm; events linked to an opportunity (Linked Opportunity) counted separately.",
             _u("11", "Mandate Search Event", "Search Event ID", "Search Event Type", "Asset Owner", "Consultant", "Mandate Asset Class", "Mandate Size", "Winning / Hired Manager", "Event Date", "Linked Opportunity")),
            ("Plan Recordkeeping White Space",
             "Sum of Recordkeeping Opportunity Value and Total Plan Assets of the latest Plan Market Record (Form 5500 Plan Year) of plans whose Recordkeeper is not the firm, by plan asset band and recordkeeper (Recordkeeper Profile Recordkeeper Model).",
             _u("11", "Plan Market Record", "Plan Party", "Form 5500 Plan Year", "Total Plan Assets", "Participant Count", "Recordkeeper", "Recordkeeping Opportunity Value")
             + _u("16", "Recordkeeper Profile", "Recordkeeper Party", "Recordkeeper Model")),
            ("White Space Covered by Open Prospects %",
             "Recordkeeping Opportunity Value of white-space plans named as Retirement Plan on an open opportunity of Opportunity Type Plan Sponsor Recordkeeping Prospect / Plan Recordkeeping White Space x 100.",
             _u("05", "Placement & Plan Detail", "Retirement Plan", "Plan Recordkeeper")
             + _u("05", "Sales Opportunity", "Opportunity Type")
             + _u("05", "Pipeline Status", "Sales Stage")
             + ["Plan Recordkeeping White Space"]),
            ("Placement Opportunities by Platform",
             "Count and Expected Amount of open opportunities of Opportunity Type Intermediary Placement - Shelf or - Model by Target Platform / Sponsor and Placement Type.",
             _u("05", "Placement & Plan Detail", "Target Platform / Sponsor", "Placement Type")
             + _u("05", "Sales Opportunity", "Opportunity Type")
             + _u("05", "Opportunity Value", "Expected Amount")),
            ("Won Opportunities Funded %",
             "Count of opportunities with Opportunity Outcome Won that have a 12 Mandate Onboarding (Won Opportunity) with an Actual Funding Date / count of won opportunities of Opportunity Type Institutional Mandate Search or OCIO Search x 100; the funded amount enters Net New Assets only through DP-008.",
             _u("05", "Win / Loss", "Opportunity Outcome")
             + _u("05", "Sales Opportunity", "Opportunity ID", "Opportunity Type")
             + _u("12", "Mandate Onboarding", "Won Opportunity", "Actual Funding Date")),
        ],
        inputs=[
            ("05", "Sales Opportunity", ["Opportunity ID", "Opportunity Name", "Opportunity Type", "Business Type", "Opportunity Sales Channel", "Opportunity Business Line", "Prospect / Client", "Opportunity Owner", "Proposed Offering or Strategy", "Search Consultant", "Originating Campaign"]),
            ("05", "Pipeline Status", ["Sales Stage", "Probability", "Expected Close Date", "Expected Funding Date"]),
            ("05", "Opportunity Value", ["Expected Amount", "Expected Annual Revenue", "Actual Close Date"]),
            ("05", "Placement & Plan Detail", ["Target Platform / Sponsor", "Placement Type", "Retirement Plan", "Plan Recordkeeper"]),
            ("05", "Win / Loss", ["Opportunity Outcome", "Primary Win / Loss Reason", "Winning Competitor"]),
            ("05", "RFP Request", ["RFP ID", "Request Type", "Issuing Party", "Related Opportunity", "Response Due Date", "Request Status"]),
            ("05", "RFP Submission", ["Submission Timestamp", "Final Compliance Approval", "RFP Outcome"]),
            ("05", "Consultant Rating", ["Rating Provider", "Rated Strategy / Product", "Rating Type", "Rating Value", "Rating Date"]),
            ("05", "Database Profile", ["Database Profile ID", "Manager Database", "Linked Strategy / Product"]),
            ("05", "Database Submission", ["Submission Period End", "Submitted Date", "Submission Status"]),
            ("11", "Plan Market Record", ["Plan Party", "Form 5500 Plan Year", "Total Plan Assets", "Participant Count", "Recordkeeper", "Recordkeeping Opportunity Value"]),
            ("11", "Win/Loss Analysis", ["Analysis Period End", "Analysis Segment", "Win Rate", "Top Loss Reasons", "Most Frequent Winning Competitor"]),
            ("11", "Mandate Search Event", ["Search Event ID", "Search Event Type", "Asset Owner", "Consultant", "Mandate Asset Class", "Mandate Size", "Winning / Hired Manager", "Event Date", "Linked Opportunity"]),
            ("16", "Recordkeeper Profile", ["Recordkeeper Party", "Recordkeeper Model"]),
            ("12", "Mandate Onboarding", ["Won Opportunity", "Actual Funding Date"]),
        ],
        upstream=["DP-001", "DP-003", "DP-094", "DP-240", "DP-481", "DP-004", "DP-192", "DP-013"],
        refresh="Weekly",
        timeliness="By 7am ET each Monday for the prior week's pipeline; month-end snapshot by business day 2",
        history="Weekly pipeline snapshots kept 5 years and month-end snapshots 10 years; RFP submissions and consultant database submissions kept 6 years (Rule 204-2 and Marketing Rule support for performance shown in submissions)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Prospect / Client, Issuing Party, Asset Owner and Plan Party resolves to a DP-240 party, every Search Consultant and Consultant to a DP-003 consultant, every Target Platform / Sponsor to DP-001, every Proposed Offering or Strategy and Rated Strategy / Product to DP-004, every Opportunity Owner to an active DP-192 employee and every Winning Competitor to DP-481.",
            "An opportunity has one Sales Stage at a time; an opportunity with Sales Stage Closed Won - Funded, Closed Lost or Closed Withdrawn has an Opportunity Outcome and an Actual Close Date, and an open one has neither.",
            'Won Amount equals the Expected Amount of opportunities with Opportunity Outcome Won and Sales Stage Closed Won - Funded closed in the period within USD 1, every Related Opportunity of an RFP Request and every Linked Opportunity of a Mandate Search Event resolves to a Sales Opportunity, and Probability lies between 0 and 1 on every open opportunity.',
            "Opportunity Type, Expected Amount and Expected Close Date are populated on every open opportunity, and Response Due Date and Request Status on every RFP Request.",
            "Opportunity Owner is published as the DP-192 employee key and name only, to sales and service leadership; prospects that are individuals (trustees of a small plan) are shown by 02 party key and plan name, and no other personal attribute is published.",
            "The Monday snapshot is built from opportunities as of Sunday 11:59pm ET and is never changed; month-end snapshots lock on business day 2.",
        ],
        notes=("Certified numbers: none owned or read; won assets are shown as Expected Amount and become Net New Assets only when "
               "funded, in DP-008 (CW-241). "
               "PII tier: identity (opportunity owners are employees; a few prospects and plan fiduciaries are individuals). "
               "Boundaries: institutions, consultants and plans are DP-003's (master) and intermediary platforms DP-001's; the advice "
               "funnel (prospect to advice enrollment) is CLA-A DP-333 and the retail acquisition funnel (lead to account) CLA-B DP-392, "
               "so retail leads are not opportunities here; institutional onboarding and service health after funding are DP-510's. "
               "Takes the pipeline scope of the 03-owned DP-019 (CW-220 disposition) and the plan prospecting of DP-024 and DP-066 "
               "(CW-139). WP1 scope: also reads 05 Database Profile, Database Submission, Consultant Rating, RFP Request and RFP "
               "Submission and 11 Mandate Search Event (from backlog DP-489, which folds in here if picked up). "
               "Tailoring lever: OCIO offered (12 SME 1). Reference default: offered; lever: drop the OCIO Search opportunity type. "
               "Tailoring lever: RFP answer content (05 SME 7). Reference default: kept in the RFP tool, only outcomes and timeliness here. "
               "Taxonomy gap: 05 Sales Opportunity has no created date, so sales cycle length cannot be measured; Opportunities Past "
               "Expected Close is used instead. Taxonomy gap: 11 Mandate Search Event Winning / Hired Manager is not a typed reference, "
               "so the firm's wins are recognized by name. "
               "Drafting assumptions: the standard probability per Sales Stage from the 05 Sales Stage code list (no attribute holds it); Sales Stage, Opportunity Outcome, Request Type and RFP Outcome values from the 05 code lists; the "
               "firm's name as Winning / Hired Manager and Recordkeeper; the 30-day database submission window; the 90-day funding "
               "window; Monday 7am ET. "
               "Decisions: CW-133, CW-134, CW-139, CW-147, CW-220, CW-240. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eight "
               "objects plus the six moved reads and 12 Mandate Onboarding Won Opportunity for the funded check; upstream DP-014 "
               "dropped (no 11 object it publishes is read), DP-240 and DP-481 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-491": dict(
        definition=("Net New Assets and their components (cash deposits and withdrawals, ACATS and in-kind transfers, rollovers, "
                    "plan contributions and distributions, mandate funding and inter-channel transfers) by channel, business line, "
                    "offering, holding type, client segment and advisor of record as of the flow date. The certified NNA is read "
                    "from DP-008 at the dimensions it publishes; the offering cross-tab and the components roll up DP-008's own NNA "
                    "attribution rows and tie back to the certified total, so this product adds no flow treatment (CW-242). It answers where assets come from and which advisors and offerings gather them. "
                    "It owns no certified metric family."),
        business_questions=[
            "What were Net New Assets this quarter by channel, advisor of record and offering, and how do they compare with last quarter?",
            "Which flow types (deposits, ACATS transfers, rollovers, plan contributions, mandate fundings) drove net new assets in each channel?",
            "Which advisors had net outflows, and how much NNA came from households with no advisor of record?",
            "How much NNA moved between advisors because coverage changed during the quarter?",
            "How much intermediary and institutional NNA is credited to each covering employee?",
        ],
        grain=("Measure value of DP-008 NNA (period x dimension type x dimension key x snapshot) as the main output, with the "
               "offering and flow-type cross-tab (period x channel x service offering x transaction type) and the advisor rows "
               "(period x advisor of record) as companion facts; one version per DP-008 snapshot"),
        dimensions=["Reporting period (DP-013)", "Distribution channel", "Business line", "Service offering and program (DP-004)",
                    "Holding type and share class (DP-004)", "Client segment (DP-240)", "Advisor of record (DP-009)",
                    "Credited salesperson (DP-001 partner coverage)", "Transaction type and flow direction", "Money movement type and payment rail (DP-302)",
                    "Client account (DP-093)", "DP-008 snapshot and data basis"],
        measures=[
            ("Net New Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-NNA at Dimension Type Total, Dimension Key ALL, for the period, in the DP-008 snapshot (Snapshot Type Final or Restated for closed periods, Flash for the daily view); never recomputed.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("NNA by Channel (from DP-008)",
             "Measure Amount of MSR-NNA at Dimension Type Channel; the Dimension Key is the Distribution Channel of the account's channel assignment at the Trade Date, as DP-008 attributes it.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets") + _u("06", "Market & Client Dimensions", "Distribution Channel")),
            ("NNA by Business Line (from DP-008)",
             "Measure Amount of MSR-NNA at Dimension Type Business Line (the eight CW-004 lines).",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets") + _u("06", "Market & Client Dimensions", "Business Line")),
            ("NNA by Advisor of Record (from DP-008)",
             "Measure Amount of MSR-NNA at Dimension Type Advisor; the Dimension Key is the Covering Advisor (EMP-) of the primary 03 Party Coverage Assignment (Primary Coverage Indicator Y) in force on the Trade Date (Coverage Effective From / To), carried on the attribution record as Advisor Coverage Assignment.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")
             + _u("06", "Market & Client Dimensions", "Covering Advisor", "Advisor Coverage Assignment")
             + _u("03", "Party Coverage Assignment", "Coverage Assignment ID", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To")),
            ("NNA by Holding Type and Share Class (from DP-008)",
             "Measure Amount of MSR-NNA at Dimension Type Holding Type and at Dimension Type Share Class.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("NNA by Client Segment (from DP-008)",
             "Measure Amount of MSR-NNA at Dimension Type Segment (the 02 segment of the household at period end).",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("NNA Attribution Rows (from DP-008)",
             "The attribution records DP-008 counts in MSR-NNA for the snapshot and period (Source Record Type Transaction, the flow rows after DP-008's Measure Definition and Flow Treatment Rule; rows with Flow Scope Inter-Channel Transfer excluded), with their signed Attributed Amount, Trade Date and Account, read as DP-008 publishes them and never re-selected from DP-006. Their sum equals Net New Assets (from DP-008) (DQ3).",
             _u("06", "Attribution Record", "Attribution Record ID", "Source Record Type", "Source Transaction", "Attributed Amount", "Attribution Effective Date") + _u("06", "Transaction", "Transaction ID", "Flow Scope", "Account") + _u("06", "Transaction Dates", "Trade Date")),
            ("NNA by Offering and Program",
             "Sum of Attributed Amount of NNA Attribution Rows (from DP-008) rolled up by Service Offering and Program through the account's 15 Program Enrollment in force on the Trade Date (Enrolled Account = Account, Enrollment Status Active, Enrollment Effective Date to Enrollment Termination Date; accounts with no enrollment shown as Self-Directed), and by Distribution Channel; it ties to Net New Assets (from DP-008) at Dimension Type Total (DQ3).",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status", "Enrollment Effective Date", "Enrollment Termination Date") + _u("06", "Transaction", "Account") + _u("06", "Market & Client Dimensions", "Distribution Channel") + ["NNA Attribution Rows (from DP-008)"]),
            ("Gross Client Inflows",
             'NNA Attribution Rows (from DP-008) with Flow Direction Inflow: sum of Attributed Amount by Transaction Type and channel.',
             _u("06", "Transaction", "Transaction Type", "Flow Direction") + _u("06", "Attribution Record", "Attributed Amount") + ["NNA Attribution Rows (from DP-008)"]),
            ("Gross Client Outflows",
             'NNA Attribution Rows (from DP-008) with Flow Direction Outflow: sum of Attributed Amount by Transaction Type and channel, shown positive.',
             _u("06", "Transaction", "Transaction Type", "Flow Direction") + _u("06", "Attribution Record", "Attributed Amount") + ["NNA Attribution Rows (from DP-008)"]),
            ("NNA Components by Flow Type",
             "Gross Client Inflows - Gross Client Outflows grouped into deposits and withdrawals (Cash Deposit, Cash Withdrawal), ACATS and in-kind transfers, rollovers, plan contributions and distributions (Contribution Source Type shown), mandate funding and withdrawal, and SMA flows; deposit and withdrawal rows whose Flow Source Book is 49 are split by Money Movement Type and Payment Rail of the 50 movement named in Source Money Movement of the Source Client Account Activity.",
             _u("06", "Order Source", "Flow Source Book", "Source Client Account Activity", "Contribution Source Type")
             + _u("49", "Client Account Activity", "Client Account Activity ID", "Activity Type", "Source Money Movement")
             + _u("50", "Money Movement", "Money Movement ID", "Money Movement Type", "Payment Rail")
             + ["Gross Client Inflows", "Gross Client Outflows"]),
            ("Net Inter-Channel Transfers by Channel (from DP-008)",
             "Certified (CW-142), read: Net Inter-Channel Transfers of MSR-NNA's companion measure at Dimension Type Channel for the period; zero at Dimension Type Total.",
             _MV_READ + _u("06", "Client Asset Measures", "Net Inter-Channel Transfers")),
            ("Client Organic Growth Rate by Channel and Advisor (from DP-008)",
             "Certified (CW-142), read: Client Organic Growth Rate at Dimension Type Channel and Advisor for the period (NNA / Beginning Client Assets of the dimension, annualized).",
             _MV_READ + _u("06", "Client Asset Measures", "Client Organic Growth Rate", "Beginning Client Assets")),
            ("Advisors With Net Outflows",
             "Count of advisors with Advisor Status Active whose NNA by Advisor of Record (from DP-008) is below zero for the period, and the sum of their outflow.",
             _u("03", "Advisor", "Employee", "Advisor Status")
             + ["NNA by Advisor of Record (from DP-008)"]),
            ("NNA Without Advisor of Record",
             "Net New Assets (from DP-008) minus the sum of NNA by Advisor of Record (from DP-008) over all advisors: flows of households with no primary coverage on the Trade Date (self-directed and digital-only clients, unassigned households).",
             ["Net New Assets (from DP-008)", "NNA by Advisor of Record (from DP-008)"]),
            ("Advisor Attribution Coverage %",
             'Absolute Attributed Amount of NNA Attribution Rows (from DP-008) with a Covering Advisor whose Attribution Method is Account-Keyed and whose Advisor Coverage Assignment is in force on the Attribution Effective Date / absolute Attributed Amount of the rows of households that have a primary coverage on that date x 100.',
             _u("06", "Attribution Record", "Attributed Amount", "Attribution Effective Date") + _u("06", "Attribution Method", "Attribution Method") + _u("06", "Market & Client Dimensions", "Covering Advisor", "Advisor Coverage Assignment", "Client Household") + _u("03", "Party Coverage Assignment", "Covered Party", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To") + ["NNA Attribution Rows (from DP-008)"]),
            ("NNA Moved by Coverage Changes",
             'Sum of Attributed Amount of NNA Attribution Rows (from DP-008) in the period of households (Client Household) whose primary Party Coverage Assignment started in the period (Coverage Effective From), split into rows before and after the change and credited to the advisor in force on each Trade Date.',
             _u("03", "Party Coverage Assignment", "Covered Party", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From") + _u("06", "Market & Client Dimensions", "Client Household") + _u("06", "Attribution Record", "Attributed Amount", "Attribution Effective Date") + ["NNA Attribution Rows (from DP-008)"]),
            ("Salesperson-Credited NNA",
             'For the IC and IA lines only: sum of Attributed Amount x Credit Split % of NNA Attribution Rows (from DP-008) with a Salesperson Credit, by Credited Salesperson and Credit Role, under the 05 Partner Coverage Assignment named in Source Partner Coverage Assignment (Partner Coverage Role); Credit Split % sums to 100 per attribution record and Credit Role (DQ3).',
             _u("06", "Salesperson Credit", "Credited Salesperson", "Source Partner Coverage Assignment", "Credit Split %", "Credit Role") + _u("05", "Partner Coverage Assignment", "Partner Coverage Assignment ID", "Covered Party", "Partner Coverage Role") + _u("06", "Attribution Record", "Attributed Amount") + ["NNA Attribution Rows (from DP-008)"]),
            ("Same-Owner Transfers Excluded",
             "Sum of Reporting Currency Amount of current transfer rows with Same-Owner Indicator Y in the period, by Transfer Type and From / To Distribution Channel: the rows DP-008's Transfer Treatment excludes from NNA, shown beside it for explanation and never added back.",
             _u("06", "Linked Transaction", "Transfer Type", "Same-Owner Indicator", "From Distribution Channel", "To Distribution Channel") + _u("06", "Flow Treatment Rule", "Transfer Treatment") + _u("06", "Transaction Amounts", "Reporting Currency Amount")),
            ("Rollover Flows by Source",
             'Rollover In rows among the NNA Attribution Rows (from DP-008) (rollovers from plans the firm does not recordkeep, counted in NNA) against firm-plan rollovers that DP-008 reports as inter-channel transfers (Flow Scope Inter-Channel Transfer, Transfer Type Direct Rollover, From Distribution Channel Workplace - Recordkept Plan) under its Rollover Treatment, by receiving channel.',
             _u("06", "Transaction", "Transaction Type", "Flow Scope") + _u("06", "Linked Transaction", "Transfer Type", "From Distribution Channel", "To Distribution Channel") + _u("06", "Flow Treatment Rule", "Rollover Treatment", "Inter-Channel Transfer Treatment") + _u("06", "Transaction Amounts", "Reporting Currency Amount") + ["NNA Attribution Rows (from DP-008)"]),
        ],
        inputs=[
            ("06", "Measure Value", ["Measure", "Period Type", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type", "As-Of Date"]),
            ("06", "Client Asset Measures", ["Beginning Client Assets", "Net New Assets", "Net Inter-Channel Transfers", "Client Organic Growth Rate"]),
            ("06", "Flow Treatment Rule", ["Transfer Treatment", "Inter-Channel Transfer Treatment", "Rollover Treatment"]),
            ("06", "Transaction", ["Transaction ID", "Transaction Type", "Flow Direction", "Flow Scope", "Holding Type", "Share Class", "Account"]),
            ("06", "Transaction Dates", ["Trade Date"]),
            ("06", "Transaction Amounts", ["Reporting Currency Amount"]),
            ("06", "Transaction Status", ["Transaction Status"]),
            ("06", "Order Source", ["Flow Source Book", "Source Client Account Activity", "Contribution Source Type"]),
            ("06", "Linked Transaction", ["Transfer Type", "Same-Owner Indicator", "From Distribution Channel", "To Distribution Channel"]),
            ("06", "Attribution Record", ['Attribution Record ID', 'Source Record Type', 'Source Transaction', 'Attributed Amount', 'Attribution Effective Date']),
            ("06", "Market & Client Dimensions", ["Distribution Channel", "Business Line", "Service Offering", "Covering Advisor", "Advisor Coverage Assignment", "Client Household"]),
            ("06", "Attribution Method", ["Attribution Method"]),
            ("06", "Salesperson Credit", ["Credited Salesperson", "Source Partner Coverage Assignment", "Credit Split %", "Credit Role"]),
            ("03", "Party Coverage Assignment", ["Coverage Assignment ID", "Covered Party", "Covering Advisor", "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To"]),
            ("03", "Advisor", ["Employee", "Advisor Status"]),
            ("05", "Partner Coverage Assignment", ["Partner Coverage Assignment ID", "Covered Party", "Partner Coverage Role"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Type", "Source Money Movement"]),
            ("50", "Money Movement", ["Money Movement ID", "Money Movement Type", "Payment Rail"]),
            ("15", "Program Enrollment", ['Program Enrollment ID', 'Enrolled Account', 'Enrolled Service Offering', 'Enrollment Status', 'Enrollment Effective Date', 'Enrollment Termination Date']),
        ],
        upstream=["DP-008", "DP-006", "DP-009", "DP-001", "DP-093", "DP-240", "DP-004", "DP-300", "DP-302", "DP-013"],
        refresh="Daily",
        timeliness="Daily flash by 9am ET on T+1 from the DP-008 flash snapshot; month-end and quarter-end views on business day 9, the day after DP-008 locks",
        history="One version per DP-008 snapshot; month-end and quarter-end versions kept 10 years, daily flash versions 13 months; superseded versions kept for restatement comparison",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Dimension Key of Dimension Type Advisor resolves to a DP-009 advisor (03 Advisor Employee), every Credited Salesperson to a DP-192 employee via the DP-001 partner coverage, every Service Offering and share class to DP-004, every Account to DP-093 and every Client Household to DP-240.",
            "For a household at a Trade Date at most one primary Party Coverage Assignment is in force (Coverage Effective From / To do not overlap and end on or after they start), and each attribution record's Attribution Effective Date falls inside the coverage it names.",
            'For the same DP-008 snapshot: NNA Attribution Rows (from DP-008), NNA by Offering and Program, NNA by Channel and NNA by Business Line each sum to Net New Assets (from DP-008) at Dimension Type Total within USD 1; NNA Without Advisor of Record equals the Attributed Amount of NNA Attribution Rows (from DP-008) of households with no primary Party Coverage Assignment in force on the Trade Date within USD 1; and Credit Split % sums to 100 per attribution record and Credit Role; otherwise the cross-tabs are withheld for the period.',
            "Transaction Type, Flow Scope, Flow Direction, Trade Date and Reporting Currency Amount are populated on every current row in scope, and every in-scope row has an attribution record with a Distribution Channel.",
            "Advisor and salesperson rows (EMP- keys with their NNA) are released only through the advisor restricted view to the advisor, their line managers and channel leadership, household-level rows are never published, and a segment cell with fewer than 10 households is suppressed.",
            "Closed periods are built only from a DP-008 snapshot with Snapshot Type Final or Restated; the daily view carries Data Basis and Snapshot Type Flash, and a restated DP-008 snapshot creates a new version, never an edit.",
        ],
        notes=("Certified numbers: reads Net New Assets, Net Inter-Channel Transfers and Client Organic Growth Rate from DP-008 at its "
               "Dimension Types (Total, Channel, Business Line, Advisor, Holding Type, Share Class, Segment); owns none (CW-011, CW-241, "
               "CW-242). The offering, flow-type and coverage cuts roll up DP-008's own NNA attribution rows (Inter-Channel Transfer rows excluded) "
               "and tie to the certified total at Dimension Type Total (DQ3); DP-006 rows are never re-selected and no treatment rule is "
               "applied here (one NNA rule, lead ruling). Offering is reached through the account's DP-093 Program Enrollment. "
               "PII tier: identity (employee advisor and salesperson keys with their performance); client flows are aggregated and "
               "household rows are never published (DQ5). "
               "Boundaries: NNA by campaign and acquisition cohort is DP-492's; intermediary partner flows are DP-493's; advisor "
               "capacity and book health is CLA-B DP-387, which reads advisor NNA from DP-008 directly (no edge either way); rollover capture of separated "
               "participants is BWO DP-467. Advisor of record comes from 03 coverage as of the flow date (CW-143). Takes DP-483's "
               "salesperson credit for the IC and IA lines: WP1 scope moved read 06 Salesperson Credit (from backlog DP-483, which "
               "folds in here if picked up). "
               "The advisor-of-record and campaign keys on 06 (the DIS item left open at WP0) resolve to 06 Market & Client Dimensions "
               "Covering Advisor and Advisor Coverage Assignment (03 CVA-) and Attributed Campaign, Campaign Attribution Weight and "
               "Source Attributed Outcome (04); no taxonomy gap remains for them. "
               "Acceptance question 2 (plan section 8.5): answered by Net New Assets (from DP-008), NNA by Channel (from DP-008), NNA by "
               "Advisor of Record (from DP-008) and NNA Components by Flow Type; mastering domains 06, 03, 49, 50 (04, campaign, through "
               "DP-492). "
               "Tailoring lever: rollover and advice-conversion treatment (06 SME 2, 7). Reference default: firm-plan to firm-IRA "
               "rollovers and self-directed to advice enrollments are inter-channel transfers, applied in DP-008 only; this product "
               "shows them in Rollover Flows by Source and Net Inter-Channel Transfers by Channel (from DP-008). Tailoring lever: advisor "
               "view audience. Reference default: advisor, line manager and channel leadership. "
               "Taxonomy gap: 06 Attribution Record has no Measure or Snapshot reference, so the set of attribution rows DP-008 counts in "
               "MSR-NNA is identified by DP-008's publication, not by an attribute (an NNA-counted flag on the 06 row would close it). "
               "Taxonomy gap: 06 Measure Value has one dimension per row, so channel x advisor and channel x offering cross-tabs come "
               "from DP-008's NNA attribution rows, not from DP-008 Measure Values. "
               "Drafting assumptions: Transaction Status values excluded; Attribution Method Account-Keyed; Channel value Workplace - "
               "Recordkept Plan; the 10-household minimum cell; USD 1 tolerance; 9am ET and business day 9. "
               "Decisions: CW-011, CW-140, CW-142, CW-143, CW-144, CW-150, CW-240, CW-241, CW-242. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's twelve "
               "objects (06 Account Channel Assignment is read through DP-008's channel dimension instead of directly) plus 06 Measure "
               "Value, Snapshot, Client Asset Measures and Measure Definition for the certified read, the moved Salesperson Credit, 03 "
               "Advisor, 05 Partner Coverage Assignment and the 49 and 50 source keys for the components; upstream DP-001, DP-300 and "
               "DP-302 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-492": dict(
        definition=("Net New Assets and funded households attributed to campaigns through the 04 attribution weights, and the "
                    "households of each acquisition cohort (month of first funding) tracked month by month after funding: "
                    "assets, net new assets and retention. Campaign NNA is read from DP-008 at its Campaign dimension, whose "
                    "weights are Derived copies of 04 Attribution Weight; this product never re-weights (CW-242, CW-085). "
                    "Marketing learns which campaigns bring assets that stay, and client economics gets the cohort basis for "
                    "lifetime value by acquisition channel (DP-498). It owns no certified metric family."),
        business_questions=[
            "How much Net New Assets did each campaign bring this quarter, and what share of total NNA is campaign-attributed?",
            "How many households did each campaign help fund, and how much did each funded household bring in its first 12 months?",
            "How do the assets and households of each acquisition cohort hold up 3, 6, 12 and 24 months after funding?",
            "How sensitive is campaign NNA to the attribution model chosen?",
            "How many funded households have no campaign attribution at all?",
        ],
        grain=("Campaign x period (campaign NNA and funded households) and acquisition cohort month x months since funding "
               "(cohort assets, NNA and retention) as the two main outputs, aggregated over households; one version per DP-008 "
               "snapshot and 04 attribution run"),
        dimensions=["Campaign and parent campaign (DP-011)", "Campaign type and business line", "Attribution model (04)", "Acquisition cohort month",
                    "Months since funding", "Distribution channel", "Milestone type", "Reporting period (DP-013)", "DP-008 snapshot"],
        measures=[
            ("Net New Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-NNA at Dimension Type Total for the period in the locked DP-008 snapshot.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("NNA by Campaign (from DP-008)",
             "Certified, read: Measure Amount of MSR-NNA at Dimension Type Campaign; the Dimension Key is the Attributed Campaign and the amount is weighted by Campaign Attribution Weight, the Derived copy of the 04 Attribution Weight of the primary attribution model (Source Attributed Outcome).",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")
             + _u("06", "Market & Client Dimensions", "Attributed Campaign", "Campaign Attribution Weight", "Source Attributed Outcome")
             + _u("04", "Campaign", "Campaign ID", "Campaign Status")),
            ("Campaign-Attributed Share of NNA %",
             "Sum over campaigns of NNA by Campaign (from DP-008) / Net New Assets (from DP-008) x 100 for the period.",
             ["NNA by Campaign (from DP-008)", "Net New Assets (from DP-008)"]),
            ("Funded Households Attributed by Campaign",
             "Attributed Outcomes (Primary Model) as CLA-B DP-410 publishes them, restricted to Outcome Type Account Funded: for each household's first Account Funded milestone (Milestone Date in the period, milestone party rolled to its 02 Household), the Attribution Weight of each Attributed Campaign under the model with Primary Model Indicator Y, summed by campaign; the weights of one household sum to 1, so households are fractional by campaign and whole in total.",
             _u("04", "Attributed Outcome", "Outcome Type", "Attributed Milestone", "Attributed Campaign", "Applied Attribution Model", "Attribution Weight") + _u("04", "Attribution Model", "Attribution Model ID", "Primary Model Indicator") + _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date") + _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From", "Membership Effective To")),
            ("NNA per Funded Household by Campaign",
             "NNA by Campaign (from DP-008) / Funded Households Attributed by Campaign for the period, by campaign and Campaign Type.",
             _u("04", "Campaign", "Campaign Type", "Campaign Business Line")
             + ["NNA by Campaign (from DP-008)", "Funded Households Attributed by Campaign"]),
            ("Funded Households by Acquisition Cohort",
             "Count of distinct 02 Client Households whose first Acquisition Milestone of Milestone Type Account Funded (earliest Milestone Date of any member) falls in the cohort month.",
             _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account")
             + _u("02", "Household Membership", "Household", "Household Member", "Membership Effective From", "Membership Effective To")),
            ("Cohort NNA Since Funding",
             "Cumulative sum of Attributed Amount of the attribution records DP-008 counts in MSR-NNA (Inter-Channel Transfer rows excluded) on the cohort households' accounts (account owner to 02 Household, see notes), from the cohort Milestone Date to the period end, by cohort month and months since funding; DP-008's rows rolled up by funding cohort, never re-selected from DP-006.",
             _u("06", "Attribution Record", "Attribution Record ID", "Source Record Type", "Source Transaction", "Attributed Amount") + _u("06", "Transaction", "Transaction ID", "Flow Scope", "Account") + _u("06", "Transaction Dates", "Trade Date") + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From", "Account Role Effective To") + _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From", "Membership Effective To") + ["Funded Households by Acquisition Cohort"]),
            ("Cohort Client Assets (from DP-320)",
             'Household Client Assets as CLA-A DP-320 publishes it, summed over the cohort households on the period end, by cohort month and months since funding (DP-320 sums the DP-007 Account Asset Summary rows of the accounts a member owns and ties them to DP-008).',
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Market Value") + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From", "Account Role Effective To") + _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From", "Membership Effective To") + ["Funded Households by Acquisition Cohort"]),
            ("Cohort Household Retention %",
             'Households of the cohort whose Household Client Assets (from DP-320) is above zero on the period end / Funded Households by Acquisition Cohort x 100, by months since funding.',
             ["Cohort Client Assets (from DP-320)", "Funded Households by Acquisition Cohort"]),
            ("Cohort Asset Retention %",
             'Cohort Client Assets (from DP-320) on the period end / Cohort Client Assets (from DP-320) at the end of the cohort month x 100, by months since funding.',
             ["Cohort Client Assets (from DP-320)"]),
            ("Twelve-Month NNA per Acquired Household by Campaign",
             "Cohort NNA Since Funding at 12 months since funding of the households attributed to a campaign, weighted by their Attribution Weight / Funded Households Attributed by Campaign for the cohort; the cohort basis DP-498 uses for lifetime value by acquisition channel.",
             _u("04", "Attributed Outcome", "Attributed Campaign", "Attribution Weight")
             + ["Cohort NNA Since Funding", "Funded Households Attributed by Campaign"]),
            ("Attribution Model Sensitivity",
             "For each campaign: Attributed Outcomes (Primary Model) minus Attributed Outcomes by Alternative Model, as CLA-B DP-410 publishes them (Attributed Amount of 04 Attributed Outcomes by Applied Attribution Model, Attribution Model Type and Lookback Window) for the period; the alternative weights are 04's, shown only.",
             _u("04", "Attributed Outcome", "Attributed Campaign", "Applied Attribution Model", "Attributed Amount") + _u("04", "Attribution Model", "Attribution Model ID", "Attribution Model Type", "Lookback Window", "Primary Model Indicator")),
            ("Funded Households Without Campaign Attribution",
             "Count of households with an Account Funded milestone in the period that have no Attributed Outcome under the primary model, by Distribution Channel of the funded account.",
             _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account")
             + _u("04", "Attributed Outcome", "Attributed Milestone", "Applied Attribution Model")
             + _u("06", "Market & Client Dimensions", "Distribution Channel")),
            ("Touchpoints per Funded Household",
             "Touchpoints by Type as CLA-B DP-410 publishes them, restricted to the Marketing Touchpoints of household members (Touchpoint Party rolled to its 02 Household through Household Membership) with Touchpoint Timestamp within the primary model's Lookback Window before the funding Milestone Date / funded households, by Touchpoint Campaign and Touchpoint Type.",
             _u("04", "Marketing Touchpoint", "Touchpoint Party", "Touchpoint Timestamp", "Touchpoint Type", "Touchpoint Campaign") + _u("04", "Attribution Model", "Lookback Window") + _u("02", "Household Membership", "Household", "Household Member", "Membership Effective From", "Membership Effective To") + ["Funded Households by Acquisition Cohort"]),
            ("Campaign Weight Copy Breaks",
             "Count of 06 attribution records whose Campaign Attribution Weight differs from the Attribution Weight of the 04 Attributed Outcome named in Source Attributed Outcome by more than 0.0001.",
             _u("06", "Attribution Record", "Attribution Record ID")
             + _u("06", "Market & Client Dimensions", "Campaign Attribution Weight", "Source Attributed Outcome")
             + _u("04", "Attributed Outcome", "Attribution Weight")),
        ],
        inputs=[
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Net New Assets"]),
            ("06", "Attribution Record", ['Attribution Record ID', 'Source Record Type', 'Source Transaction', 'Attributed Amount']),
            ("06", "Market & Client Dimensions", ["Distribution Channel", "Attributed Campaign", "Campaign Attribution Weight", "Source Attributed Outcome"]),
            ("06", "Transaction", ['Transaction ID', 'Flow Scope', 'Account']),
            ("06", "Transaction Dates", ["Trade Date"]),
            ("06", "Account Asset Summary", ['Summary Account', 'Summary As-Of Date', 'Summary Market Value']),
            ("04", "Attributed Outcome", ["Outcome Type", "Attributed Milestone", "Attributed Campaign", "Applied Attribution Model", "Attribution Weight", "Attributed Amount"]),
            ("04", "Attribution Model", ["Attribution Model ID", "Attribution Model Type", "Lookback Window", "Primary Model Indicator"]),
            ("04", "Acquisition Milestone", ["Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account"]),
            ("04", "Campaign", ["Campaign ID", "Campaign Name", "Parent Campaign", "Campaign Type", "Campaign Status", "Campaign Business Line"]),
            ("04", "Marketing Touchpoint", ["Touchpoint Party", "Touchpoint Timestamp", "Touchpoint Type", "Touchpoint Campaign"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status", "Membership Effective From", "Membership Effective To"]),
            ("15", "Account Party Role", ['Account Role Type', 'Role Party', 'Role Account', 'Account Role Effective From', 'Account Role Effective To']),
        ],
        upstream=['DP-008', 'DP-006', 'DP-320', 'DP-410', 'DP-011', 'DP-240', 'DP-093', 'DP-013'],
        refresh="Monthly",
        timeliness="Business day 9 after month-end, the day after DP-008 locks and once the 04 attribution run for the month is final",
        history="Monthly campaign and cohort snapshots kept 10 years, one version per DP-008 snapshot and attribution run; cohorts tracked to 60 months since funding",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Attributed Campaign and Touchpoint Campaign resolves to a DP-011 campaign, every Milestone Party and Household to DP-240, every Milestone Account to DP-093, and the primary attribution model is exactly one Attribution Model with Primary Model Indicator Y for the period.",
            "Household Membership periods of one member do not overlap and end on or after they start, so each milestone party maps to one household on the Milestone Date, and a household belongs to exactly one acquisition cohort.",
            "For each Attributed Campaign, NNA by Campaign (from DP-008) equals the sum of Attributed Amount x Campaign Attribution Weight of DP-008's NNA attribution rows with that Attributed Campaign within USD 1; Campaign Weight Copy Breaks is zero; the Attribution Weights of one milestone under one model sum to 1 within 0.0001; and Cohort NNA Since Funding of the period summed over all cohorts, plus the NNA attribution rows of accounts with no cohort household, equals Net New Assets (from DP-008) at Dimension Type Total within USD 1.",
            "Milestone Type, Milestone Date and Milestone Party are populated on every milestone, and Attributed Milestone, Applied Attribution Model and Attribution Weight on every Attributed Outcome.",
            "Outputs are campaign and cohort aggregates only; no household or party key is published and any campaign or cohort cell with fewer than 10 households is suppressed.",
            "A month is built only from a DP-008 snapshot with Snapshot Type Final or Restated and a final attribution run; a later restatement creates a new version of the month.",
        ],
        notes="Certified numbers: reads Net New Assets from DP-008 at Dimension Type Total and Campaign; owns none (CW-011, CW-241, CW-242). Cohort NNA rolls up DP-008's own NNA attribution rows (Inter-Channel Transfer rows excluded) by funding cohort and ties to NNA at Dimension Type Total (DQ3); DP-006 rows are never re-selected (one NNA rule, lead ruling). Cohort Client Assets is DP-320's Household Client Assets; neither cohort figure is certified. Household path (stated once): an account reaches its 02 Household through its owner Account Party Role (DP-093) and the owner party's Household Membership in force (DP-240); milestone and touchpoint parties reach it through Household Membership. It is the 02 household, never the 13 mailing group or the 47 Fee Household. PII tier: none at publication. pii = N: 02 Household Membership, 15 Account Party Role, 04 Acquisition Milestone, Marketing Touchpoint and the 06 account rows (PII - financial and identity) are read only to group households into campaigns and cohorts; outputs are aggregates with a 10-household minimum cell (DQ5). Boundaries: the 04 attribution weights and models are 04's (Derived copies in 06, CW-085); campaign spend, attributed outcomes and touchpoints are read from CLA-B DP-410 (Attributed Outcomes (Primary Model), Attributed Outcomes by Alternative Model, Touchpoints by Type), which lists neither this product nor DP-498; DP-392 and DP-410 read Net New Assets by Campaign from DP-008 directly (CW-227 as amended at the CLA-B integration), so CW-242's 'by reading DP-492' wording is superseded for them. Household Client Assets is CLA-A DP-320's, which does not list this product. NNA by advisor and channel is DP-491's. Takes the NNA-by-campaign part of DP-025 (CW-220 disposition). 04 Acquisition Milestone is read directly: no foundational product publishes it. Acceptance question 2 (plan section 8.5): answered for campaign by NNA by Campaign (from DP-008); mastering domains 06, 04. Acceptance question 11: feeds DP-498 with Twelve-Month NNA per Acquired Household by Campaign. Tailoring lever: post-milestone flow window (06 SME 9). Reference default: DP-008 attributes only the funding flow of the milestone to the campaign; the cohort view follows households for 60 months. Tailoring lever: attribution model. Reference default: 04's primary model; alternatives shown in Attribution Model Sensitivity only. Taxonomy gap: 04 Acquisition Milestone has no household attribute, so milestones roll to the 02 household through Household Membership. Taxonomy gap: 06 Attribution Record has no Measure or Snapshot reference, so DP-008's MSR-NNA row set is identified by DP-008's publication, not by an attribute. Drafting assumptions: Milestone Type and Outcome Type value Account Funded; owner Account Role Types as DP-320 uses them; 60-month tracking; 10-household minimum cell; tolerances USD 1 and 0.0001; business day 9. Decisions: CW-085, CW-142, CW-143, CW-220, CW-227, CW-240, CW-241, CW-242. WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eight objects (06 Client Asset Measures with Measure Value and Snapshot) plus the DP-008 attribution rows, 06 Account Asset Summary through DP-320, 15 Account Party Role and 02 Household Membership; upstream DP-320, DP-410, DP-240 and DP-093 added. Fix pass: cohort NNA re-based on DP-008's attribution rows; Cohort Client Assets renamed 'Cohort Client Assets (from DP-320)' (no reader).",
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-493": dict(
        definition=("Own-fund, ETF, CIT and model net flows and assets held through intermediaries by partner firm, office, "
                    "platform, third-party recordkeeper, sponsor program and vehicle: certified intermediary channel Client Assets "
                    "and NNA from DP-008, partner flows and intermediary-held own-fund positions from DP-006 and DP-007, ETF "
                    "creations and broker holdings, plan positions in plans recordkept by others, sponsor-reported program assets, "
                    "and the model deliveries behind them. It is the channel view the plan names Intermediary Channel Flows. "
                    "It owns no certified metric family."),
        business_questions=[
            "What are intermediary channel client assets and net new assets this quarter by sub-channel, and how fast is the channel growing?",
            "Which partner firms and offices are adding or withdrawing own-fund assets, and how much of the flow is still unresolved to a partner?",
            "How much of our own funds sits in plans recordkept by others and in sponsor model programs, and which placements produce assets?",
            "What are ETF primary market flows by authorized participant, and where are our ETFs held by broker (estimated)?",
            "Are model deliveries to sponsor programs acknowledged on time?",
        ],
        grain=("Partner firm x vehicle type x period (flows and intermediary-held own-fund assets) as the main output, with the "
               "certified intermediary sub-channel values, ETF primary market flows, ETF holdings by broker, third-party recordkept "
               "plan positions, sponsor program assets and model delivery events as companion facts; monthly, with daily flows"),
        dimensions=["Intermediary sub-channel", "Partner firm and office (DP-001)", "Sponsor program and model placement (DP-005)",
                    "Third-party recordkeeper and retirement plan (DP-001, DP-003)", "Product, vehicle type and share class (DP-004)",
                    "Model portfolio (DP-004)", "Authorized participant (DP-115)", "Holding broker / DTC participant (DP-115)", "Look-through level",
                    "Model delivery type", "Reporting period (DP-013)", "DP-008 snapshot"],
        measures=[
            ("Intermediary Client Assets by Sub-Channel (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-CLIENTASSETS (Ending Client Assets) at Dimension Type Channel for the Intermediary sub-channels (Wirehouse, National / Regional Broker-Dealer, Independent Broker-Dealer, RIA, Bank / Trust, TAMP / Model Marketplace, Brokerage Platform, Third-Party Recordkeeper) at the period end, locked snapshot.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Intermediary NNA by Sub-Channel (from DP-008)",
             "Certified, read: Measure Amount of MSR-NNA at Dimension Type Channel for the Intermediary sub-channels for the period.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("Intermediary Organic Growth Rate (from DP-008)",
             "Certified, read: Client Organic Growth Rate at Dimension Type Channel for the Intermediary sub-channels.",
             _MV_READ + _u("06", "Client Asset Measures", "Client Organic Growth Rate")),
            ("Own-Fund Sales and Redemptions by Sub-Channel (from DP-008)",
             "Certified (CW-203), read: Gross Sales, Redemptions and Net Flows (Net Sales) at Dimension Type Channel for the Intermediary sub-channels.",
             _MV_READ + _u("06", "Flow Measures", "Gross Sales", "Redemptions", "Net Flows (Net Sales)")),
            ("Own-Fund Assets by Channel (from DP-008)",
             "Read: DP-008's Own-Fund Assets by Channel for the Intermediary sub-channels at the period end (06 Asset Measures Ending AUM, Average AUM and Market Movement of the Measure Value rows): a fund view of own-fund assets held through intermediaries, kept under its 06 attribute names; never Firm AUM and never added to Client Assets.",
             _MV_READ + _u("06", "Asset Measures", "Ending AUM", "Average AUM", "Market Movement")),
            ("Net Flows by Partner Firm",
             "Sum of Attributed Amount, signed by Flow Direction, of attribution records of current DP-006 rows (Transaction Status not Canceled, Reversed or Rejected) with Flow Scope Fund Flow or Client Asset and Fund Flow in an Intermediary channel, Trade Date in the period, by Distributor Firm and Distributor Office / Branch of the attribution record's 06 Distributor Hierarchy (Hierarchy Version Date) and by Vehicle Type of the Product.",
             _u("06", "Transaction", "Transaction ID", "Flow Direction", "Flow Scope", "Product", "Share Class")
             + _u("06", "Transaction Dates", "Trade Date")
             + _u("06", "Transaction Status", "Transaction Status")
             + _u("06", "Attribution Record", "Attribution Record ID", "Source Transaction", "Attributed Amount")
             + _u("06", "Distributor Hierarchy", "Distributor Firm", "Distributor Office / Branch", "Hierarchy Version Date")
             + _u("06", "Market & Client Dimensions", "Distribution Channel")
             + _u("01", "Investment Product", "Product ID", "Vehicle Type")),
            ("Unresolved Intermediary Flows",
             "Sum of Reporting Currency Amount, signed by Flow Direction, of current intermediary-feed rows in the period whose Intermediary As Delivered has no Resolved Distributor Firm, by Intermediary Identifier Scheme and Look-Through Level; the absolute amount is shown beside it for suspense size, and the suspense workflow is DP-495's.",
             _u("06", "Transaction", "Transaction ID", "Flow Direction", "Look-Through Level") + _u("06", "Transaction Amounts", "Reporting Currency Amount") + _u("06", "Intermediary As Delivered", "Dealer / Firm Number", "Intermediary Identifier Scheme", "Resolved Distributor Firm", "Resolved Office / Branch")),
            ("Intermediary-Held Own-Fund Assets by Partner Firm",
             "Sum of Market Value of DP-007 Fund Shareholder Positions with Aggregation Role Counted - Intermediary on the period-end Valuation Date, attributed (Source Position) to the Distributor Firm of the attribution record, plus the Omnibus Residual Amount of the partner's omnibus parent accounts.",
             _u("06", "Fund Shareholder Position", "Position ID", "Account", "Share Class", "Valuation Date", "Aggregation Role", "Market Value")
             + _u("06", "Attribution Record", "Source Position", "Attributed Amount")
             + _u("06", "Distributor Hierarchy", "Distributor Firm")
             + _u("06", "Omnibus Look-Through", "Omnibus Parent Account", "Omnibus Residual Amount")),
            ("Look-Through Coverage by Partner %",
             "Market-value-weighted average of Look-Through Coverage % of the partner's omnibus parent accounts on the period end.",
             _u("06", "Omnibus Look-Through", "Omnibus Parent Account", "Look-Through Coverage %")
             + _u("06", "Fund Shareholder Position", "Market Value")),
            ("ETF Primary Market Flows",
             "Creation Units and Reporting Currency Amount of current ETF Creation and ETF Redemption transactions in the period by Authorized Participant and share class.",
             _u("06", "Transaction", "Transaction Type", "Share Class")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount")
             + _u("06", "ETF Creation / Redemption", "Authorized Participant", "Creation Units")),
            ("Estimated ETF Holdings by Broker",
             "ETF Shares Held and Market Value of own-ETF positions by Holding Custodian / Broker and DTC Participant Number on the latest as-of date, labeled with ETF Holdings Source (aggregator, depository report, 13F or estimate); secondary-market holdings are estimates and never certified.",
             _u("06", "ETF Holding", "Holding Custodian / Broker", "DTC Participant Number", "ETF Shares Held", "ETF Holdings Source")
             + _u("06", "Fund Shareholder Position", "Share Class", "Valuation Date", "Market Value")),
            ("Third-Party Recordkept Plan Assets",
             "Market Value of own-fund positions with a Plan Position on the period end by Recordkeeper and Retirement Plan, with Plan Participant Count: own funds in plans recordkept by others (channel Intermediary - Third-Party Recordkeeper, CW-139).",
             _u("06", "Plan Position", "Retirement Plan", "Recordkeeper", "Plan Participant Count")
             + _u("06", "Fund Shareholder Position", "Valuation Date", "Aggregation Role", "Market Value")),
            ("Sponsor Program Assets",
             "Market Value of positions with Sponsor-Reported Assets on the period end by Sponsor and Sponsor Reporting Basis; rows with Model-Delivery Assets Indicator Y (model-delivery assets the firm does not manage) shown as a memo line outside Client Assets and Firm AUM.",
             _u("06", "Sponsor-Reported Assets", "Sponsor", "Sponsor Reporting Basis", "Model-Delivery Assets Indicator")
             + _u("06", "Fund Shareholder Position", "Valuation Date", "Aggregation Role", "Market Value")),
            ("Sponsor Program Net Flows",
             "Sum of Reporting Currency Amount, signed by Flow Direction, of current SMA Contribution and SMA Withdrawal rows in the period by Sponsor Program and Model Portfolio.",
             _u("06", "Transaction", "Transaction Type", "Flow Direction")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount")
             + _u("06", "SMA Flow", "Sponsor Program", "Model Portfolio")),
            ("Model Deliveries Acknowledged On Time %",
             "Model Delivery Events with an Acknowledged Timestamp within one business day of Delivered Timestamp / all Model Delivery Events delivered in the period x 100, by Delivery Program Agreement and Model Delivery Type.",
             _u("05", "Model Delivery Event", "Model Delivery Event ID", "Delivered Model Portfolio", "Delivery Program Agreement", "Model Delivery Type", "Delivered Timestamp", "Acknowledged Timestamp")),
            ("Model Placements Producing Assets %",
             "Active Model Program Placements (Model Placement Status Active) whose Placed Model Portfolio has Sponsor Program Assets above zero on the period end / active placements x 100, by Sponsor Program Agreement.",
             _u("05", "Model Program Placement", "Sponsor Program Agreement", "Placed Model Portfolio", "Model Placement Status")
             + ["Sponsor Program Assets"]),
        ],
        inputs=[
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Net New Assets", "Client Organic Growth Rate"]),
            ("06", "Flow Measures", ["Gross Sales", "Redemptions", "Net Flows (Net Sales)"]),
            ("06", "Transaction", ["Transaction ID", "Transaction Type", "Flow Direction", "Flow Scope", "Share Class", "Product", "Look-Through Level"]),
            ("06", "Transaction Dates", ["Trade Date"]),
            ("06", "Transaction Amounts", ["Reporting Currency Amount"]),
            ("06", "Transaction Status", ["Transaction Status"]),
            ("06", "Intermediary As Delivered", ["Dealer / Firm Number", "Intermediary Identifier Scheme", "Resolved Distributor Firm", "Resolved Office / Branch"]),
            ("06", "ETF Creation / Redemption", ["Authorized Participant", "Creation Units"]),
            ("06", "SMA Flow", ["Sponsor Program", "Model Portfolio"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Account", "Share Class", "Valuation Date", "Aggregation Role", "Market Value"]),
            ("06", "Omnibus Look-Through", ["Omnibus Parent Account", "Look-Through Coverage %", "Omnibus Residual Amount"]),
            ("06", "ETF Holding", ["Holding Custodian / Broker", "DTC Participant Number", "ETF Shares Held", "ETF Holdings Source"]),
            ("06", "Plan Position", ["Retirement Plan", "Recordkeeper", "Plan Participant Count"]),
            ("06", "Sponsor-Reported Assets", ["Sponsor", "Sponsor Reporting Basis", "Model-Delivery Assets Indicator"]),
            ("06", "Attribution Record", ["Attribution Record ID", "Source Transaction", "Source Position", "Attributed Amount"]),
            ("06", "Distributor Hierarchy", ["Distributor Firm", "Distributor Office / Branch", "Hierarchy Version Date"]),
            ("06", "Market & Client Dimensions", ["Distribution Channel"]),
            ("05", "Model Delivery Event", ["Model Delivery Event ID", "Delivered Model Portfolio", "Delivery Program Agreement", "Model Delivery Type", "Delivered Timestamp", "Acknowledged Timestamp"]),
            ("05", "Model Program Placement", ["Sponsor Program Agreement", "Placed Model Portfolio", "Model Placement Status"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("06", "Asset Measures", ['Ending AUM', 'Average AUM', 'Market Movement']),
        ],
        upstream=['DP-008', 'DP-006', 'DP-007', 'DP-001', 'DP-005', 'DP-003', 'DP-115', 'DP-004', 'DP-013'],
        refresh="Monthly",
        timeliness="Business day 9 after month-end for the certified and position views; partner flows refreshed daily by 9am ET on T+1 as intermediary feeds load",
        history="Monthly snapshots kept 10 years, one version per DP-008 snapshot; daily partner flows 3 years; model delivery events 6 years (Rule 204-2 support for model delivery records)",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Distributor Firm, Resolved Distributor Firm, Sponsor and Recordkeeper resolves to a DP-001 party, every Retirement Plan to DP-003, every Sponsor Program Agreement and Delivery Program Agreement to a DP-005 agreement, and every Product, Share Class and Model Portfolio to DP-004.",
            "A 06 Distributor Hierarchy path is taken at one Hierarchy Version Date per attribution record, and a Model Program Placement has one Model Placement Status in force at a time.",
            "Net Flows by Partner Firm plus Unresolved Intermediary Flows, both signed by Flow Direction, equals Own-Fund Sales and Redemptions by Sub-Channel (from DP-008) Net Flows (Net Sales) for the Intermediary channels within 0.5% for the period, and the certified sub-channel values and Own-Fund Assets by Channel (from DP-008) equal DP-008's locked snapshot.",
            "Flow Scope, Flow Direction, Trade Date and Reporting Currency Amount are populated on every in-scope row, and Aggregation Role and Market Value on every Fund Shareholder Position read.",
            "Rows are published at partner firm, office, plan, sponsor and broker grain; Plan Advisor, Advisor / Rep and Representative Name As Delivered are not read, and a firm that is an individual is shown by its 02 party key and firm name only.",
            "A month is built only from a DP-008 snapshot with Snapshot Type Final or Restated; ETF holdings by broker carry their ETF Holdings Source and are never mixed into certified values.",
        ],
        notes=("Certified numbers: reads Ending Client Assets, Net New Assets, Client Organic Growth Rate, Gross Sales, Redemptions and "
               "Net Flows at the Intermediary channel dimension from DP-008; owns none (CW-011, CW-241). Partner, plan, sponsor and broker "
               "views are analytical cuts of DP-006 and DP-007 rows. Model-delivery assets are outside both Client Assets and Firm AUM "
               "(DP-241) and appear only as a memo. "
               "PII tier: none at publication. pii = N: the 06 position, flow and plan attributes noted PII are firm- and plan-level "
               "here; external advisor and rep attributes are not read (DQ5); the remaining warnings are the lexical 'No PII' notes. "
               "Book: Fund Shareholder Position (06) is the view read for intermediary-held own-fund assets (TA and intermediary data); "
               "Client Holding (49) is not read. "
               "Boundaries: partner masters and placements are DP-001's and DP-005's; the look-through reconciliation and feed "
               "suspense are DP-495's; partner payments are DP-487's. Plan section 8.3 example. Takes DP-029's own-fund footprint for "
               "IC and DP-024's intermediary-recordkeeper assets (CW-139). WP1 scope: also reads 05 Model Delivery Event (from backlog "
               "DP-485, which folds in here if picked up). "
               "Tailoring lever: intermediary depth (05 SME 1, 06 SME 5). Reference default: firm and office level, advisor level only "
               "where feeds allow and never published here; lever: restore advisor-level views from wholesale-v1.0. Tailoring lever: "
               "model delivery (05 SME 5). Reference default: model delivery and sponsor-reported assets kept. "
               "Taxonomy gap: 06 Sponsor-Reported Assets and Plan Position carry no market value of their own; the value is the parent "
               "Fund Shareholder Position's Market Value. Taxonomy gap: 06 ETF Holding has no estimation confidence attribute beyond "
               "ETF Holdings Source. "
               "Drafting assumptions: the Intermediary sub-channel values of the shared Distribution Channel list; Model Placement "
               "Status Active; the one-business-day acknowledgment standard; 0.5% tolerance; business day 9. "
               "Decisions: CW-137, CW-139, CW-140, CW-141, CW-142, CW-240, CW-241, CW-245. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's nine "
               "06 objects (06 Asset Measures restored in the fix pass for Own-Fund Assets by Channel (from DP-008)) plus the 06 flow and position attributes, Distributor Hierarchy for the partner path, the moved 05 Model "
               "Delivery Event, 05 Model Program Placement and 01 Investment Product; upstream DP-005, DP-003 and DP-115 (authorized participants and holding brokers) added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-495": dict(
        definition=("The health of every feed into the client flow and client asset facts (DP-006, DP-007) and so into the "
                    "certified Client Assets and NNA of DP-008: load timeliness and rejects, control and DQ results, "
                    "reconciliation match rates and breaks, identity matching of intermediary records, unattributed suspense by "
                    "channel and age, attribution overrides and restatements, and the vendor data issues behind them. Stewards "
                    "know where to act and consumers know how far a period's numbers can be relied on. Suspense is reported, "
                    "never re-attributed here. It owns no certified metric family."),
        business_questions=[
            "Did every feed for yesterday and for the month-end arrive on time and complete, and which loads were rejected or partial?",
            "Which reconciliations are below their match target, and which breaks are open, over tolerance or ageing?",
            "How much of Client Assets and flows sits in unattributed suspense, in which channel and for how long?",
            "How well are intermediary records matching to partners and accounts, and how many suggested matches await review?",
            "Which overrides and restatements changed a closed period, and can this month's certified numbers be relied on?",
        ],
        grain=("Data feed x business date (load health) and reconciliation x run business date (reconciliation health) as the "
               "main outputs, with breaks, unattributed items, crosswalk match results, overrides, restatements, DQ results and "
               "vendor data issues as companion facts; daily, with a month-end reliance record per reporting period"),
        dimensions=["Data feed, feed type and data provider", "Business date and reporting period (DP-013)", "Reconciliation and reconciliation type",
                    "Break type, status and root cause", "Suspense channel and unattributed reason", "Age bucket",
                    "Match rule, match status and match source", "Override scope and reason", "Restatement reason",
                    "Intermediary firm (DP-001)", "Governing agreement (DP-005)", "DQ rule (DP-101)", "Vendor issue severity"],
        measures=[
            ("Loads Received On Time %",
             "Loads with Load Status Received, Loaded or Loaded with Warnings for the Business Date / all loads expected for the Business Date (including Expected, Missing, Partial and Received Late) x 100, by Feed, Feed Type and Data Provider.",
             _u("06", "Load", "Load ID", "Feed", "Business Date", "Load Status")
             + _u("06", "Data Feed", "Feed ID", "Feed Type", "Data Provider")),
            ("Missing, Partial or Rejected Loads",
             "Count of Loads with Load Status Missing, Partial or Rejected in the period, by Feed, Feed Type, Delivery Frequency and Data Provider.",
             _u("06", "Load", "Load ID", "Feed", "Business Date", "Load Status")
             + _u("06", "Data Feed", "Feed ID", "Feed Name", "Feed Type", "Delivery Frequency", "Data Provider")),
            ("Load Reject Rate %",
             "Sum of Rejected Record Count / sum of Record Count of loads in the period x 100, by Feed.",
             _u("06", "Load", "Feed", "Record Count", "Rejected Record Count")),
            ("DQ Rule Pass Rate %",
             "Mean DQ Result % of 21 Data Quality Results whose Tested Load is a 06 load in the period, and the count with Threshold Met Indicator N, by Tested DQ Rule; Records Failed / Records Tested shown.",
             _u("21", "Data Quality Result", "DQ Result ID", "Tested DQ Rule", "DQ Execution Timestamp", "Tested Load", "Records Tested", "Records Failed", "DQ Result %", "Threshold Met Indicator")),
            ("Reconciliation Match Rate %",
             "Matched % of the latest Reconciliation Run of each Reconciliation on the business date, by Reconciliation Type (TA vs Intermediary Feed, Client Asset Summary vs Source Book, Broker-Dealer Omnibus vs Client Holdings, Flows vs Asset Roll-Forward).",
             _u("06", "Reconciliation", "Reconciliation ID", "Reconciliation Name", "Reconciliation Type", "Reconciliation Frequency")
             + _u("06", "Reconciliation Run", "Run Business Date", "Matched %")),
            ("Open Breaks by Age",
             "Count and sum of absolute Difference Amount of Breaks with Break Status Open or Investigating, by Break Age (Days) bucket (0-5, 6-30, over 30), Reconciliation Type, Break Type and Root Cause Category.",
             _u("06", "Break", "Break ID", "Break Type", "Difference Amount", "Root Cause Category", "Break Status", "Break Age (Days)")
             + _u("06", "Reconciliation", "Reconciliation Type")),
            ("Breaks Over Tolerance",
             "Count of open Breaks whose absolute Difference Amount exceeds the Absolute Tolerance of their Reconciliation or whose relative difference exceeds Relative Tolerance %.",
             _u("06", "Break", "Break ID", "Difference Amount", "Break Status")
             + _u("06", "Reconciliation", "Absolute Tolerance", "Relative Tolerance %", "Compared Measure")),
            ("Breaks Resolved in Period",
             "Count of Breaks with Resolution Date in the period by Root Cause Category, and the mean days from detection to Resolution Date.",
             _u("06", "Break", "Break ID", "Root Cause Category", "Break Age (Days)", "Resolution Date")),
            ("Unattributed Suspense Amount",
             "Sum of Unattributed Amount of Unattributed Items with Resolution Status New, Under Investigation or Awaiting Source on the as-of date, by Suspense Channel, Unattributed Reason and Lowest Resolved Level.",
             _u("06", "Unattributed Item", "Unattributed Item ID", "Lowest Resolved Level", "Unattributed Reason", "Unattributed Amount", "Suspense Channel", "Resolution Status")),
            ("Suspense Aged Over 30 Days",
             "Unattributed Suspense Amount of items whose First Seen Date is more than 30 days before the as-of date.",
             _u("06", "Unattributed Item", "First Seen Date")
             + ["Unattributed Suspense Amount"]),
            ("Ending Client Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-CLIENTASSETS at Dimension Type Channel and Total on the period end in the DP-008 snapshot (Flash daily, Final at month-end); the denominator of the suspense share.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Suspense Share of Client Assets %",
             "Unattributed Suspense Amount / Ending Client Assets (from DP-008) x 100, by Suspense Channel against the same channel.",
             ["Unattributed Suspense Amount", "Ending Client Assets (from DP-008)"]),
            ("Items Written Off to House",
             "Sum of Unattributed Amount and count of Unattributed Items moved to Resolution Status Written Off to House in the period, by Suspense Channel.",
             _u("06", "Unattributed Item", "Unattributed Item ID", "Unattributed Amount", "Suspense Channel", "Resolution Status")),
            ("Intermediary Identity Match Rate %",
             "Identifier Crosswalk entries in force (Crosswalk Effective From / To) whose latest Match Result has Match Status Matched - Auto or Matched - Manual / all entries in force x 100, by Source Feed and Source Identifier Type; intermediary feeds only (internal books are account-keyed, CW-144).",
             _u("06", "Identifier Crosswalk", "Crosswalk ID", "Source Feed", "Source Identifier Type", "Resolved Party", "Resolved Account", "Crosswalk Effective From", "Crosswalk Effective To")
             + _u("06", "Match Result", "Match Status", "Match Date")),
            ("Suggested Matches Awaiting Review",
             "Count of Match Results with Match Status Suggested whose Match Score is at or above the Review Threshold and below the Auto-Accept Threshold of the Match Rule Applied, by Match Rule Type and age from Match Date.",
             _u("06", "Match Result", "Match Status", "Match Source", "Match Rule Applied", "Match Score", "Match Date")
             + _u("06", "Match Rule", "Match Rule ID", "Match Rule Type", "Auto-Accept Threshold", "Review Threshold")),
            ("Active Attribution Overrides",
             "Count of Attribution Overrides in force on the as-of date (Override Effective From / To) by Override Scope and Override Reason, and the count with no Approved By.",
             _u("06", "Attribution Override", "Override ID", "Override Scope", "Override Reason", "Approved By", "Override Effective From", "Override Effective To")),
            ("Restatements and Net Impact",
             "Count of Restatements approved in the period and sum of Net Impact Amount by Restatement Reason, with the snapshots they supersede (Snapshot Type Restated, Supersedes Snapshot).",
             _u("06", "Restatement", "Restatement ID", "Restatement Reason", "Affected Periods", "Net Impact Amount", "Restatement Approved By")
             + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type", "Supersedes Snapshot")),
            ("Open Vendor Data Issues",
             "Count of 14 Vendor Data Issues with Issue Status not Resolved whose Issue Dataset is delivered through a 06 Data Feed, by Issue Type and Issue Severity, with days open from Detected Date.",
             _u("14", "Vendor Data Issue", "Vendor Data Issue ID", "Issue Dataset", "Issue Type", "Issue Severity", "Detected Date", "Issue Status", "Resolved Date")),
            ("Period Reliance Flag",
             "Y for a reporting period when, at the DP-008 lock, Loads Received On Time % is 100 for the month-end business date, Breaks Over Tolerance is zero, Suspense Share of Client Assets % is below 0.5 in every channel and no Vendor Data Issue of Issue Severity High is open; N otherwise, with the failing tests listed.",
             ["Loads Received On Time %", "Breaks Over Tolerance", "Suspense Share of Client Assets %", "Open Vendor Data Issues"]),
        ],
        inputs=[
            ("06", "Data Feed", ["Feed ID", "Feed Name", "Data Provider", "Feed Type", "Delivery Frequency", "Feed Grain", "Governing Agreement", "Feed Status", "Source Precedence Rank"]),
            ("06", "Load", ["Load ID", "Feed", "Business Date", "Record Count", "Control Total", "Rejected Record Count", "Load Status"]),
            ("06", "Reconciliation", ["Reconciliation ID", "Reconciliation Name", "Reconciliation Type", "Left Source", "Right Source", "Compared Measure", "Absolute Tolerance", "Relative Tolerance %", "Reconciliation Frequency"]),
            ("06", "Reconciliation Run", ["Run Business Date", "Matched %"]),
            ("06", "Break", ["Break ID", "Break Type", "Difference Amount", "Root Cause Category", "Break Status", "Break Age (Days)", "Resolution Date"]),
            ("06", "Unattributed Item", ["Unattributed Item ID", "Lowest Resolved Level", "Unattributed Reason", "Unattributed Amount", "Suspense Channel", "First Seen Date", "Resolution Status"]),
            ("06", "Attribution Override", ["Override ID", "Override Scope", "Override Reason", "Approved By", "Override Effective From", "Override Effective To"]),
            ("06", "Identifier Crosswalk", ["Crosswalk ID", "Source Feed", "Source Identifier Type", "Source Identifier Value", "Resolved Party", "Resolved Account", "Crosswalk Effective From", "Crosswalk Effective To"]),
            ("06", "Match Rule", ["Match Rule ID", "Match Rule Type", "Auto-Accept Threshold", "Review Threshold", "Applicable Feeds"]),
            ("06", "Match Result", ["Match Status", "Match Source", "Match Rule Applied", "Match Score", "Match Date"]),
            ("06", "Restatement", ["Restatement ID", "Restatement Reason", "Affected Periods", "Net Impact Amount", "Restatement Approved By"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type", "Supersedes Snapshot"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
            ("21", "Data Quality Result", ["DQ Result ID", "Tested DQ Rule", "DQ Execution Timestamp", "Tested Load", "Records Tested", "Records Failed", "DQ Result %", "Threshold Met Indicator"]),
            ("14", "Vendor Data Issue", ["Vendor Data Issue ID", "Issue Dataset", "Issue Type", "Issue Severity", "Detected Date", "Issue Status", "Resolved Date"]),
        ],
        upstream=["DP-006", "DP-007", "DP-008", "DP-101", "DP-001", "DP-005", "DP-240", "DP-093", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET on T+1 for the prior business date; the month-end reliance record on business day 8, at the DP-008 lock",
        history="Daily load, reconciliation and suspense history kept 3 years and month-end reliance records 10 years; breaks, overrides and restatements kept 7 years with their approvals (Rule 17a-4 support where the 49 and 29 books are compared)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "API"],
        dq_rules=[
            "Every Load Feed resolves to a 06 Data Feed with Feed Status Production, every Data Provider to a DP-001 or DP-240 party, every Governing Agreement to DP-005, every Tested Load to a 06 Load and Tested DQ Rule to a DP-101 rule, and every Resolved Party and Resolved Account to DP-240 and DP-093.",
            "Identifier Crosswalk entries of one Source Feed, Source Identifier Type and Source Identifier Value do not overlap in time, and Attribution Override periods of one Override Scope value do not overlap; each ends on or after it starts.",
            "Unattributed Suspense Amount on a date equals DP-006 Unattributed Amount plus DP-007 Unattributed Position Amount for the same date within USD 1, and Ending Client Assets (from DP-008) equals DP-008's published value for the snapshot read.",
            "Load Status and Business Date are populated on every load, Break Status and Difference Amount on every break, and Unattributed Reason, Unattributed Amount and First Seen Date on every unattributed item.",
            "Source Identifier Value and the crosswalk's resolved keys are shown only in the steward drill-down to the 06 data stewards; Source Name Text and Source Address / ZIP Code are not read, and the summary is published at feed, channel and reconciliation grain.",
            "The daily build runs after the last scheduled load of the business date and the month-end reliance record is fixed at the DP-008 lock; a later restatement updates the record as a new version.",
        ],
        notes=("Certified numbers: reads Ending Client Assets from DP-008 as the suspense denominator; owns none. Suspense balances "
               "are reported here and never re-attributed (CW-144); attribution and resolution stay in DP-006 and DP-007. "
               "PII tier: identity in the steward drill-down (intermediary source identifiers such as rep codes resolve to external "
               "advisors and accounts); the summary carries no personal data (DQ5). "
               "Boundaries: the feed, load, reconciliation and break facts are mastered in 06 and published in detail by DP-006 and "
               "DP-007; this product monitors them across feeds. The 49-to-29 omnibus book reconciliation is 49's (CW-122). 21 Data "
               "Quality Result and 14 Vendor Data Issue are read directly: no foundational product publishes them (DP-101 conforms the "
               "rule catalog). Matching applies to intermediary feeds only (CW-144). Successor of DP-045 (CW-240); its compensation use "
               "retired with 07. "
               "Operating model (CD-297): when transfer agency or clearing is outsourced, the 29 and 49 feeds arrive from the provider "
               "and are monitored here as provider feeds; the grain does not change. "
               "Tailoring lever: reliance thresholds. Reference default: all month-end loads on time, no break over tolerance, suspense "
               "below 0.5% of channel Client Assets. Tailoring lever: intermediary identity resolution (06 SME 5). Reference default: "
               "deterministic CRD and source-key matches auto-accepted, fuzzy matches reviewed. "
               "Taxonomy gap: 06 Load has no expected arrival time, so on-time is judged against the feed's Delivery Frequency and the "
               "business date. Taxonomy gap: 06 Break has no detection date; age is read from Break Age (Days). "
               "Drafting assumptions: Load Status, Break Status, Resolution Status and Match Status values from the 06 code lists; age "
               "buckets 0-5, 6-30 and over 30 days; the 0.5% suspense threshold; Issue Severity High; 8am ET and business day 8. "
               "Decisions: CW-122, CW-140, CW-141, CW-144, CW-150, CW-240, CW-241. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's thirteen "
               "objects plus 06 Snapshot, Measure Value and Client Asset Measures for the certified denominator and the reliance "
               "record; upstream DP-005, DP-240 and DP-093 added for the key checks."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-496": dict(
        definition='Client Assets by holding type (own funds, third-party funds, securities, cash and sweep, feeders) per channel, offering and segment, the own-fund share of client wallets and its change, and the own-fund overlap that also counts in Firm AUM, shown beside certified Firm AUM. Client Assets at Dimension Types Channel and Holding Type, Advised Assets and the overlap are read from DP-008 as the published margins, and Firm AUM and its reconciling own-fund line from DP-241; the channel x holding type cross-tab decomposes the DP-007 rows DP-008 counts (account summaries, counted intermediary positions and omnibus residuals) and ties to both margins. The overlap is shown as DP-008 reports it and netted nowhere here. It owns no certified metric family.',
        business_questions=[
            "What are Client Assets by channel and holding type at quarter-end, and how do they reconcile to Firm AUM?",
            "What share of client assets is in our own funds, ETFs and CITs in each channel, offering and segment, and how did it change?",
            "Where do third-party funds and individual securities take wallet share from our own funds?",
            "How large is the own-fund overlap between Client Assets and Firm AUM, and how much own-fund AUM sits outside Client Assets?",
            "Does the holding-type split tie to the brokerage, recordkeeping, transfer agent and portfolio books?",
        ],
        grain=("Period end x distribution channel x holding type (cross-tab of DP-007 account summaries) as the main output, with "
               "offering and segment cuts, the certified DP-008 and DP-241 reads and the source-book tie-out as companion facts; "
               "month-end snapshots, one version per DP-008 snapshot"),
        dimensions=["Period end (DP-013)", "Distribution channel", "Holding type and CW-011 holding type group", "Summary source book",
                    "Service offering (DP-004)", "Client segment (DP-240)", "Own-product indicator", "Share class and vehicle (DP-004)",
                    "Instrument type (DP-097)", "Firm AUM slice (DP-241)", "DP-008 snapshot"],
        measures=[
            ("Ending Client Assets (from DP-008)",
             'Certified (CW-011), read: Measure Amount of MSR-CLIENTASSETS at Dimension Type Total, Channel and Holding Type on the period end in the locked DP-008 snapshot (Snapshot Type Final or Restated); the Channel and Holding Type rows are the published margins of the cross-tab.',
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Client Assets by Channel and Holding Type",
             "Decomposition of the DP-007 rows that DP-008 counts in Client Assets, by channel x holding type on the period end: Summary Market Value of Account Asset Summary rows by Summary Distribution Channel and Summary Holding Type; plus Market Value of Fund Shareholder Positions with Aggregation Role Counted - Intermediary at the Distribution Channel of their attribution record (Source Position) and the holding type of their share class (Parent Product Vehicle Type: mutual fund to Own Mutual Fund, ETF to Own ETF, CIT to Own CIT); plus the Omnibus Residual Amount once per Omnibus Parent Account x share class x Valuation Date at the parent's channel and the same holding type. It applies DP-008's summing rule by cell and never redefines it; both margins must equal Ending Client Assets (from DP-008) (DQ3).",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Holding Type", "Summary Market Value", "Summary Distribution Channel") + _u("06", "Fund Shareholder Position", "Position ID", "Share Class", "Valuation Date", "Aggregation Role", "Market Value") + _u("06", "Attribution Record", "Source Position") + _u("06", "Market & Client Dimensions", "Distribution Channel") + _u("06", "Omnibus Look-Through", "Omnibus Parent Account", "Omnibus Residual Amount") + _u("01", "Share Class", "Share Class ID", "Parent Product") + _u("01", "Investment Product", "Product ID", "Vehicle Type") + ["Ending Client Assets (from DP-008)"]),
            ("Client Assets by Holding Type Group",
             "Client Assets by Channel and Holding Type collapsed to the four CW-011 holding type groups: Own Funds (Own Mutual Fund, Own ETF, Own CIT), Third-Party Funds (Third-Party Mutual Fund, Third-Party ETF, Alternative Feeder), Securities (Equity, Fixed Income and CDs, Options, Other) and Cash (Cash and Sweep).",
             ["Client Assets by Channel and Holding Type"]),
            ("Own-Fund Share of Client Assets %",
             "Sum of Summary Market Value with Own-Product Indicator Y / total Summary Market Value x 100 on the period end, by channel, offering and segment.",
             _u("06", "Account Asset Summary", "Summary Market Value", "Own-Product Indicator", "Summary Distribution Channel")
             + ["Client Assets by Channel and Holding Type"]),
            ("Own-Fund Share Change (bps)",
             "Own-Fund Share of Client Assets % at the period end minus at the prior period end of the same cut, x 100.",
             ["Own-Fund Share of Client Assets %"]),
            ("Client Assets by Offering",
             "Sum of Attributed Amount of DP-007 attribution records whose Source Account Asset Summary is a period-end summary, by Service Offering and Summary Holding Type.",
             _u("06", "Attribution Record", "Attribution Record ID", "Source Account Asset Summary", "Attributed Amount")
             + _u("06", "Market & Client Dimensions", "Service Offering")
             + _u("06", "Account Asset Summary", "Summary Holding Type")),
            ("Client Assets by Segment (from DP-008)",
             "Certified, read: Measure Amount of MSR-CLIENTASSETS at Dimension Type Segment on the period end.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Advised Assets Share % (from DP-008)",
             "Advised Assets / Ending Client Assets x 100 by channel, both read from the locked DP-008 snapshot.",
             _MV_READ + _u("06", "Client Asset Measures", "Advised Assets", "Ending Client Assets")),
            ("Own-Fund Overlap Amount (from DP-008)",
             "Certified (CW-142), read: Own-Fund Overlap Amount of the locked DP-008 snapshot at Dimension Type Total and Channel: own funds inside Client Assets that are also in the own funds slice of Firm AUM. Shown as reported; nothing here subtracts it.",
             _MV_READ + _u("06", "Client Asset Measures", "Own-Fund Overlap Amount")),
            ("Firm AUM (from DP-241)",
             "Certified (CW-011), read: Firm AUM and its three slices at the month-end as DP-241 publishes them; the slice definitions are DP-241's (the managed account slice from DP-345). Shown beside Client Assets, never added to it.",
             _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount") + _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assignment Status", "Regulatory AUM Classification") + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value")),
            ("Own Funds Outside Client Assets (from DP-241)",
             "Certified reconciling line, read as DP-241 publishes it: the own funds slice at NAV less the Own-Fund Overlap Amount netted in DP-241 only (seed capital, own funds held by own funds, registered units in no counted account).",
             _u("27", "Fund NAV Calculation", "Fund Net Assets Amount")
             + _u("06", "Client Asset Measures", "Own-Fund Overlap Amount")),
            ("Own-Fund Client Holdings Market Value (from DP-300)",
             "Market Value in USD of End of Day 49 Client Holdings with Own Share Class Indicator Y on the period end, as DP-300 publishes it, against the own-fund summary rows with Summary Source Book 49 (Brokerage Book of Record).",
             _u("49", "Client Holding", "Holding Account", "Client Holding Date", "Client Holding View", "Own Share Class Indicator")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("06", "Account Asset Summary", "Summary Source Book", "Own-Product Indicator", "Summary Market Value")),
            ("Third-Party and Securities Wallet Share by Instrument Type",
             "Market Value in USD of End of Day 49 Client Holdings with Own Share Class Indicator N on the period end by 17 Instrument Type and Asset Class of the Held Instrument, as a share of the brokerage book's Client Assets: where wallet goes to products other than own funds.",
             _u("49", "Client Holding", "Held Instrument", "Client Holding Date", "Client Holding View", "Own Share Class Indicator")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("17", "Instrument", "Instrument ID", "Instrument Type", "Asset Class")),
            ("Own-Fund Share by Share Class Vehicle",
             "Market Value of counted Fund Shareholder Positions on the period end by Share Class and its Vehicle Type (mutual fund, ETF, CIT), as a share of own-fund Client Assets, by Position Source Book.",
             _u("06", "Fund Shareholder Position", "Share Class", "Valuation Date", "Position Source Book", "Aggregation Role", "Market Value")
             + _u("01", "Investment Product", "Product ID", "Vehicle Type")
             + _u("01", "Share Class", "Share Class ID", "Parent Product")),
        ],
        inputs=[
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Advised Assets", "Own-Fund Overlap Amount"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Holding Type", "Summary Source Book", "Summary Market Value", "Own-Product Indicator", "Summary Distribution Channel", "Advised Assets Indicator"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Share Class", "Valuation Date", "Position Source Book", "Aggregation Role", "Market Value"]),
            ("06", "Attribution Record", ['Attribution Record ID', 'Source Position', 'Source Account Asset Summary', 'Attributed Amount']),
            ("06", "Market & Client Dimensions", ['Distribution Channel', 'Service Offering']),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View", "Own Share Class Indicator"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class"]),
            ("27", "Fund NAV Calculation", ["Valuation Date", "NAV Approval Status", "Fund Net Assets Amount"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Status", "Regulatory AUM Classification"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product"]),
            ("06", "Omnibus Look-Through", ['Omnibus Parent Account', 'Omnibus Residual Amount']),
        ],
        upstream=['DP-008', 'DP-007', 'DP-241', 'DP-300', 'DP-097', 'DP-093', 'DP-004', 'DP-240', 'DP-013'],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, the day after DP-241 publishes the month's Firm AUM (business day 9)",
        history="Month-end snapshots since go-live kept 10 years, one version per DP-008 snapshot and DP-241 version; restated months keep the prior version",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            'Every Summary Account resolves to a DP-093 account, every Share Class and Parent Product to DP-004, every Held Instrument to DP-097 and every Omnibus Parent Account to a DP-093 omnibus account.',
            'Each account contributes one Account Asset Summary per holding type and period end, each counted Fund Shareholder Position has exactly one attribution record with a Distribution Channel, and each Omnibus Residual Amount is counted once per Omnibus Parent Account, share class and Valuation Date.',
            "Client Assets by Channel and Holding Type summed over holding types equals Ending Client Assets (from DP-008) at Dimension Type Channel for every channel, and summed over channels equals it at Dimension Type Holding Type for every holding type, within USD 1; Firm AUM (from DP-241) and Own Funds Outside Client Assets (from DP-241) equal DP-241's published values.",
            "Summary Holding Type, Summary Source Book, Summary Distribution Channel, Own-Product Indicator and Summary Market Value are populated on every period-end summary.",
            'Outputs are published at channel, holding type, offering, segment and share class grain only; the 49 and 06 account-level rows are read to aggregate and no account or household row is published, and segment cells under 10 households are suppressed.',
            "A month is published only from a DP-008 snapshot with Snapshot Type Final or Restated and the DP-241 version of the same month; Client Assets and Firm AUM are shown side by side and never summed, and the overlap is never subtracted here.",
        ],
        notes="Certified numbers: reads Ending Client Assets (at Dimension Types Total, Channel and Holding Type), Advised Assets and Own-Fund Overlap Amount from DP-008 and Firm AUM and Own Funds Outside Client Assets from DP-241; owns none (CW-011, CW-241). The channel x holding type cross-tab decomposes the DP-007 rows DP-008 counts, including the counted intermediary positions and the Omnibus Residual Amount, and ties to both DP-008 margins (DQ3); the Firm AUM slice definitions are DP-241's and are not restated here. 'AUM' names Firm AUM only. Books (CW-007): Client Holding (49) through DP-300 and the DP-007 Account Asset Summary; Fund Shareholder Position (06) as the view for intermediary-held positions; the 16, 29 and 18 books reach this product only through DP-007's summaries and DP-008; client holdings are never taken from 18 or 06 alone. PII tier: none at publication. pii = N: the 49, 46 and 06 account-level attributes noted PII are read only to aggregate (DQ5). Boundaries: the Client Assets to Firm AUM reconciliation by cause is DP-241's and is read, not repeated; the summary-to-book tie-out is DP-007's (Summary to Book Variance) and the certified Households count DP-008's, neither repeated here; managed account assets are CLA-A DP-345's; client asset supply chain checks are DP-495's. Successor of DP-029 for product footprint (CW-240). Acceptance question 1 (plan section 8.5): answered by Client Assets by Channel and Holding Type, Ending Client Assets (from DP-008), Own-Fund Overlap Amount (from DP-008), Firm AUM (from DP-241), Own Funds Outside Client Assets (from DP-241) and Own-Fund Client Holdings Market Value (from DP-300); mastering domains 06, 49, 27, 46 and 18 here, and 16 and 29 through DP-008 and DP-007 (as in DP-241). Tailoring lever: holding-type list (06 SME 4). Reference default: the eleven Holding Type values, collapsed to the four CW-011 groups in Client Assets by Holding Type Group. Tailoring lever: own-fund overlap scope (06 SME 8). Reference default: own funds in every channel, as DP-008 reports it. Taxonomy gap: no 06 or 27 attribute stores the certified Firm AUM; Firm AUM (from DP-241) traces to the attributes DP-241 computes it from. Taxonomy gap: 06 Fund Shareholder Position has no holding type attribute; counted intermediary positions take it from the share class's Vehicle Type. Taxonomy gap: 06 Account Asset Summary has no segment attribute; segment cuts use DP-008's Segment dimension. Drafting assumptions: the holding type grouping and the Vehicle Type to Holding Type mapping; Client Holding View End of Day; USD 1 tolerance; the 10-household minimum cell; business day 10. Decisions: CW-007, CW-011, CW-141, CW-142, CW-206, CW-240, CW-241. WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's four 06 objects plus the certified reads (Measure Value, Snapshot, the DP-241 source attributes in 27, 46 and 18), 06 Omnibus Look-Through and the attribution channel for the decomposition, the 49 holdings through DP-300, 17 Instrument and 01 product keys. Fix pass: measures 'Holding Type Split Tie-Out to Source Books' and 'Households Holding Own Funds %' dropped (no reader); 16, 29 and 27 Share Class NAV inputs and upstream DP-430, DP-580, DP-165, DP-142 and DP-140 dropped.",
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-497": dict(
        definition=("Recognized client revenue by stream (advisory and wrap fees, planning and subscription fees, commissions, "
                    "account fees, margin interest, fully paid lending, bank sweep, recordkeeping, trust and OCIO fees) and own-fund "
                    "management fee revenue, per offering, channel and client segment, and its yield on average Client Assets. "
                    "Revenue is read from DP-012 and the denominator from DP-008; the 47 billing, 48 confirmation and 49 lending "
                    "records explain realization and never recompute revenue. Pricing scenarios show the projected effect of fee "
                    "changes. Leadership and pricing see which streams and segments carry revenue and where yield is drifting. "
                    "It owns no certified metric family."),
        business_questions=[
            "What is client revenue by stream, offering, channel and segment this quarter, and what yield does it earn on average Client Assets?",
            "Where is yield drifting against last year, and is it price, mix or fee reductions?",
            "How much of the billed advisory fee is realized after discounts, waivers and own-fund credits?",
            "What do commissions, fully paid lending and cash sweep contribute, and what spread does the sweep earn?",
            "What revenue impact do the pricing scenarios under review project?",
        ],
        grain=("Fiscal period x revenue stream x service offering x channel x client segment (aggregated Client Revenue Records) as "
               "the main output, with own-fund fee revenue (share class x period), billing realization (offering x billing period), "
               "cash program economics (sweep program x program bank x period) and pricing scenario results (scenario x projection "
               "year) as companion facts; closed periods final"),
        dimensions=["Fiscal period (DP-013)", "Revenue stream", "Service offering (DP-004)", "Distribution channel", "Business line",
                    "Client segment (DP-240)", "Share class (DP-004)", "Recognizing legal entity (DP-013)", "Sweep program and program bank (DP-431)",
                    "Pricing scenario and type", "Projection year"],
        measures=[
            ("Gross Fee Revenue (from DP-012)",
             "Certified (CW-011), read: Gross Fee Revenue of DP-012 for the fiscal period by offering, channel and business line: client fee-stream Recognized Revenue Amount plus own-fund Gross Fee Revenue.",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount")
             + _u("10", "Fee Revenue Record", "Fee Revenue Record ID", "Revenue Accounting Period", "Gross Fee Revenue")),
            ("Net Fee Revenue (from DP-012)",
             "Certified (CW-011), read: Net Fee Revenue of DP-012 (Gross Fee Revenue less the Waiver and Reimbursement Offset of the Fee Revenue Records).",
             _u("10", "Fee Revenue Record", "Waiver and Reimbursement Offset", "Net Fee Revenue")
             + ["Gross Fee Revenue (from DP-012)"]),
            ("Effective Net Fee Rate (from DP-012)",
             "Certified (CW-011), read: Effective Net Fee Rate of DP-012 per share class and asset-based client stream; never recomputed over Client Assets.",
             _u("10", "Fee Revenue Record", "Revenue Share Class / Mandate", "Fee Basis Average Assets", "Effective Net Fee Rate")),
            ("Client Revenue by Stream",
             "Sum of Recognized Revenue Amount of DP-012 Client Revenue Records for the Client Revenue Period by Client Revenue Stream, Revenue Service Offering, Revenue Channel, Revenue Business Line, Client Segment at Period End and Recognizing Legal Entity.",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Client Revenue Stream", "Revenue Service Offering", "Client Revenue Period", "Recognized Revenue Amount", "Recognizing Legal Entity", "Revenue Channel", "Revenue Business Line", "Client Segment at Period End")),
            ("Average Client Assets (from DP-008)",
             "Certified (CW-142), read: Measure Amount of MSR-AVGCLIENTASSETS for the period at Dimension Type Total, Channel and Segment from the locked DP-008 snapshot; the yield denominator.",
             _MV_READ + _u("06", "Client Asset Measures", "Average Client Assets")),
            ("Client Revenue Yield (bps)",
             "Annualized Client Revenue by Stream summed over all client streams / Average Client Assets (from DP-008) x 10,000, by channel and by segment (revenue Client Segment at Period End against the DP-008 Segment dimension).",
             ["Client Revenue by Stream", "Average Client Assets (from DP-008)"]),
            ("Fee Revenue Yield (bps)",
             "Annualized Client Revenue by Stream of the fee streams (Advisory Fee, Wrap Fee, Planning Fee, Subscription Fee, Account Service Fee, Recordkeeping Fee, Trust Fee, OCIO Fee) / Average Client Assets (from DP-008) x 10,000, by channel and segment.",
             ["Client Revenue by Stream", "Average Client Assets (from DP-008)"]),
            ("Yield Drift (bps)",
             "Client Revenue Yield (bps) of the period minus that of the same period a year earlier, split into rate (yield change at constant mix) and mix (change in the stream and segment weights of Average Client Assets).",
             ["Client Revenue Yield (bps)"]),
            ("Own-Fund Management Fee Revenue (from DP-012)",
             "Net Fee Revenue of DP-012 Fee Revenue Records by Revenue Share Class / Mandate for the Revenue Accounting Period, with the share class's Waiver Records (Waived Fee Amount, Reimbursed Expense Amount by Waiver Type): fund revenue, shown beside client revenue and never divided by Client Assets.",
             _u("10", "Fee Revenue Record", "Revenue Share Class / Mandate", "Revenue Accounting Period", "Net Fee Revenue")
             + _u("10", "Waiver Record", "Waiver Record ID", "Waiver Type", "Supported Share Class", "Waived Fee Amount", "Reimbursed Expense Amount")),
            ("Billed Fee Realization % (from DP-305)",
             "Sum of Net Fee / sum of Gross Fee of 47 Account Fee Calculations of runs whose billing period falls in the fiscal period x 100, by offering, as DP-305 publishes the billing runs.",
             _u("47", "Account Fee Calculation", "Calculation Run", "Calculated Assignment", "Gross Fee", "Net Fee")),
            ("Fee Reductions by Type (from DP-305)",
             "Sum of Discount Amount, Waiver Amount Applied and Own-Fund Credit Amount of the same Account Fee Calculations, with the 47 Fee Waivers by Waiver Reason (Waiver Amount), by offering.",
             _u("47", "Account Fee Calculation", "Discount Amount", "Waiver Amount Applied", "Own-Fund Credit Amount")
             + _u("47", "Fee Waiver", "Fee Waiver ID", "Waiver Reason", "Waiver Amount")),
            ("Billed Effective Annual Rate (from DP-305)",
             "Billable Assets-weighted average of Effective Annual Rate of the Account Fee Calculations, by offering and fee schedule type; compared with the Effective Net Fee Rate (from DP-012) of the asset-based streams.",
             _u("47", "Account Fee Calculation", "Billable Assets", "Effective Annual Rate")
             + ["Effective Net Fee Rate (from DP-012)"]),
            ("Commission Revenue per Confirmation (from DP-301)",
             "Sum of Commission Charged / count of Client Trade Confirmations with Confirmed Trade Date in the period (from DP-301), against Client Revenue by Stream of stream Commission.",
             _u("48", "Client Trade Confirmation", "Client Trade Confirmation ID", "Confirmed Trade Date", "Commission Charged")
             + ["Client Revenue by Stream"]),
            ("Fully Paid Lending Revenue Check (from DP-300)",
             "Sum of Firm Lending Fee Amount of Fully Paid Securities Loans with Loan Status Active or Returned in the period (from DP-300) minus Client Revenue by Stream of stream Fully Paid Lending Revenue; empty when the lending lever is off.",
             _u("49", "Fully Paid Securities Loan", "Fully Paid Securities Loan ID", "Loan Status", "Firm Lending Fee Amount")
             + ["Client Revenue by Stream"]),
            ("Cash Program Net Spread (from DP-012)",
             "Net Spread, Program Bank Fee Earned, Average Client Rate Paid, Average Swept Balance and Money Market Sweep Fund Revenue of DP-012 Cash Program Economics by Economics Sweep Program, Economics Program Bank and Economics Period.",
             _u("10", "Cash Program Economics", "Economics Sweep Program", "Economics Program Bank", "Economics Period", "Average Swept Balance", "Program Bank Fee Earned", "Average Client Rate Paid", "Net Spread", "Money Market Sweep Fund Revenue")),
            ("Revenue by Client Segment Scheme",
             "Client Revenue by Stream regrouped by the 02 Segment Assignment (Segmentation Scheme, Segment) in force at the period end of the record's 02 Household (the household on the 02 Party, via DP-240): account rows reach it through the owner Account Party Role of the Revenue Account / Household and the owner's Household Membership in force; 47 Fee Household rows through the Anchor Client Household; plan-paid rows (16 service arrangement) are excluded. Used for schemes other than the one stamped on Client Segment at Period End.",
             _u("10", "Client Revenue Record", "Revenue Account / Household") + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From", "Account Role Effective To") + _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From", "Membership Effective To") + _u("47", "Fee Household", "Fee Household ID", "Anchor Client Household") + _u("02", "Segment Assignment", "Segmented Party", "Segmentation Scheme", "Segment", "Segment Effective From", "Segment Effective To") + ["Client Revenue by Stream"]),
            ("Pricing Scenario Revenue Impact",
             "Projected Revenue Impact and Projected Revenue Under Scenario of each Pricing Scenario by Projection Year, Pricing Scenario Type and Priced Subject, with Assumed Retention Rate and Assumed Flow Response; projections, labeled as such and never certified.",
             _u("10", "Pricing Scenario", "Pricing Scenario ID", "Pricing Scenario Type", "Priced Subject", "Proposed Schedule Version", "Scenario Base Date", "Assumed Retention Rate", "Assumed Flow Response")
             + _u("10", "Pricing Scenario Result", "Projection Year", "Projected Revenue Under Scenario", "Projected Revenue Impact")),
            ("Scenario Affected Assets Share %",
             "Affected Client Assets of a Pricing Scenario at its Scenario Base Date / Average Client Assets (from DP-008) of the priced offering's channel x 100.",
             _u("10", "Pricing Scenario", "Affected Client Assets", "Scenario Base Date")
             + ["Average Client Assets (from DP-008)"]),
        ],
        inputs=[
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Revenue Account / Household", "Client Revenue Stream", "Revenue Service Offering", "Client Revenue Period", "Recognized Revenue Amount", "Recognizing Legal Entity", "Revenue Channel", "Revenue Business Line", "Client Segment at Period End"]),
            ("10", "Fee Revenue Record", ['Fee Revenue Record ID', 'Revenue Share Class / Mandate', 'Revenue Accounting Period', 'Fee Basis Average Assets', 'Gross Fee Revenue', 'Waiver and Reimbursement Offset', 'Net Fee Revenue', 'Effective Net Fee Rate', 'Revenue Data Basis']),
            ("10", "Waiver Record", ["Waiver Record ID", "Waiver Type", "Supported Share Class", "Waived Fee Amount", "Reimbursed Expense Amount"]),
            ("10", "Cash Program Economics", ["Economics Sweep Program", "Economics Program Bank", "Economics Period", "Average Swept Balance", "Program Bank Fee Earned", "Average Client Rate Paid", "Net Spread", "Money Market Sweep Fund Revenue"]),
            ("10", "Pricing Scenario", ["Pricing Scenario ID", "Pricing Scenario Type", "Priced Subject", "Proposed Schedule Version", "Affected Client Assets", "Scenario Base Date", "Assumed Retention Rate", "Assumed Flow Response"]),
            ("10", "Pricing Scenario Result", ["Projection Year", "Projected Revenue Under Scenario", "Projected Revenue Impact"]),
            ("47", "Account Fee Calculation", ["Calculation Run", "Calculated Assignment", "Billable Assets", "Effective Annual Rate", "Gross Fee", "Discount Amount", "Waiver Amount Applied", "Own-Fund Credit Amount", "Net Fee"]),
            ("47", "Fee Waiver", ["Fee Waiver ID", "Waiver Reason", "Waiver Amount"]),
            ("48", "Client Trade Confirmation", ["Client Trade Confirmation ID", "Confirmed Trade Date", "Commission Charged"]),
            ("49", "Fully Paid Securities Loan", ["Fully Paid Securities Loan ID", "Loan Status", "Firm Lending Fee Amount"]),
            ("02", "Segment Assignment", ["Segmented Party", "Segmentation Scheme", "Segment", "Segment Effective From", "Segment Effective To"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Average Client Assets"]),
            ("15", "Account Party Role", ['Account Role Type', 'Role Party', 'Role Account', 'Account Role Effective From', 'Account Role Effective To']),
            ("02", "Household Membership", ['Household', 'Household Member', 'Membership Status', 'Membership Effective From', 'Membership Effective To']),
            ("47", "Fee Household", ['Fee Household ID', 'Anchor Client Household']),
        ],
        upstream=['DP-012', 'DP-008', 'DP-305', 'DP-301', 'DP-300', 'DP-431', 'DP-093', 'DP-240', 'DP-004', 'DP-013'],
        refresh="Monthly",
        timeliness="Business day 11 after month-end, after DP-012 closes the fiscal period (business day 10); pricing scenarios refreshed on event",
        history="Monthly aggregates kept 10 years; closed periods final, estimated versions kept until superseded; pricing scenarios kept 7 years with their results",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Revenue Service Offering and Revenue Share Class / Mandate resolves to DP-004, every Economics Sweep Program and Program Bank to DP-431, every Recognizing Legal Entity to DP-013 and every Segmented Party to a DP-240 household or party.",
            "Segment Assignment periods of one party and Segmentation Scheme do not overlap and end on or after they start, so each record maps to one segment per scheme at the period end.",
            "Gross Fee Revenue (from DP-012), Net Fee Revenue (from DP-012) and Effective Net Fee Rate (from DP-012) equal DP-012's published values for the same fiscal period within USD 1 (0.0001 for the rate), and Average Client Assets (from DP-008) equals the locked DP-008 value.",
            "Client Revenue Stream, Revenue Service Offering, Revenue Channel and Recognized Revenue Amount are populated on every Client Revenue Record read, and Net Fee and Gross Fee on every Account Fee Calculation.",
            "Outputs are published at stream, offering, channel and segment grain; account and household Client Revenue Records are read only to aggregate, and any segment cell with fewer than 10 households is suppressed (CW-243).",
            'A fiscal period is published only when every Fee Revenue Record of the period has Revenue Data Basis Actual or Restated (DP-012 closed); pricing scenario rows carry their Scenario Base Date and are never mixed into actual revenue.',
        ],
        notes=("Certified numbers: reads Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate from DP-012 and Average Client "
               "Assets from DP-008; owns none (CW-011, CW-156, CW-241). 47, 48 and 49 records are read to explain realization, never "
               "to recompute revenue. Yield is client revenue over Client Assets; own-fund management fees are fund revenue and are "
               "never divided by Client Assets or Firm AUM here. "
               "PII tier: none at publication. pii = N: Client Revenue Record, 47, 48, 49 and 02 rows (PII - financial) are read only to "
               "aggregate to segment and offering (DQ5); household revenue views are restricted and belong to DP-498 and DP-499's "
               "registered views (CW-243). "
               "Boundaries: billing accuracy is CLA-A DP-346's and fee invoicing DP-350's; cost to serve and profitability are DP-498 "
               "and DP-499's; the ledger tie-out is DP-598's. Cash sweep balances and FDIC coverage are BWO DP-457's; spread is read "
               "from DP-012 Cash Program Economics (CW-244). WP1 scope: also reads 10 Pricing Scenario and Pricing Scenario Result "
               "(from backlog DP-348 and DP-500); backlog DP-500 and DP-501 fold in here if picked up. "
               "Household grouping: the 02 Household on the Party (DP-240), reached from account rows through the owner Account Party Role and from "
               "47 Fee Household rows through the Anchor Client Household; never the 13 mailing group; the 47 Fee Household is only a route. "
               "Acceptance question 8: WP0_Integration_Notes section 5 names this product a feeder of CLA-A DP-346 (Billed Fee Realization % and Fee "
               "Reductions by Type); DP-346 reads the billing facts from DP-305 directly and does not list this product, so no feed edge is "
               "claimed (for the lead to confirm). Pricing scenarios are deterministic scenario arithmetic held in 10 (Pricing Scenario Result), "
               "not a scoring or forecasting model, so CD-294 and DP-212 do not apply. "
               "Tailoring lever: household grain (10 SME 1). Reference default: segment aggregates only; lever: a restricted household "
               "revenue view registered in DP-518. Tailoring lever: fully paid lending and margin. Reference default: offered; the "
               "Fully Paid Lending Revenue Check is empty when the program is off. Tailoring lever: sweep vehicle (10 SME 2). Reference "
               "default: money market sweep fund, bank sweep the lever. "
               "Taxonomy gap: 10 Client Revenue Record has no average asset basis per record, so stream yield is computed at channel "
               "and segment grain against DP-008, not per account. "
               "Drafting assumptions: the fee-stream list as DP-012 uses it; Loan Status values Active and Returned; the 10-household "
               "minimum cell; tolerances USD 1 and 0.0001; business day 11. "
               "Decisions: CW-011, CW-156, CW-158, CW-240, CW-241, CW-243, CW-244. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eight "
               "objects plus 10 Cash Program Economics, the two moved pricing objects and the DP-008 denominator (Measure Value, "
               "Snapshot, Client Asset Measures); upstream DP-431 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-498": dict(
        definition=("The cost to serve each client segment, service tier, offering and channel in its six 10 Cost-to-Serve Profile "
                    "components (coverage and servicing, client service, platform and technology, clearing and client asset "
                    "custody, money movement, communications and regulatory), built on the DP-480 allocation run and tied to "
                    "certified operating expense; the acquisition cost per funded household by acquisition channel and campaign; "
                    "and household lifetime value by model version, acquisition channel and cohort. Asset and household counts "
                    "are read from DP-008, revenue from DP-012 and cohort flows from DP-492. It answers what each segment costs "
                    "and what it is worth, and is the successor of the retired DP-244. It owns no certified metric family."),
        business_questions=[
            "What does it cost to serve each client segment and service tier, per household and in basis points of client assets, and which component drives it?",
            "What is the lifetime value of a household by acquisition channel and cohort, and how does it compare with what we spent to acquire it?",
            "What does it cost to acquire a funded household through each channel and campaign, and does that tie to campaign spend?",
            "Do segments earn more revenue than they cost to serve, and where is service contact volume highest?",
            "How much of certified operating expense does the cost-to-serve view explain?",
        ],
        grain=("Profitability period x served dimension (client segment, service tier, service offering, channel) of the Cost-to-Serve "
               "Profile as the main output, with acquisition cost records (acquisition channel x campaign x cohort month) and "
               "lifetime value aggregates (model version x acquisition channel x cohort x segment) as companion facts; one version per "
               "DP-480 allocation run and LTV model version; household-grain rows only in the restricted view"),
        dimensions=["Profitability period (DP-013)", "Client segment and service tier (DP-240)", "Service offering (DP-004)", "Distribution channel",
                    "Business line", "Cost-to-serve component (DP-480)", "Allocation run and hierarchy version (DP-480)", "Acquisition channel",
                    "Campaign (DP-011, DP-410)", "Acquisition cohort month", "Lifetime value model and version (DP-212)", "Estimate as-of date"],
        measures=[
            ("Total Cost to Serve",
             'Sum of Total Cost-to-Serve of Profitability Records with Data Version Actual, the current Hierarchy Version and a Source Allocation Run with Run Status Final, for the Profitability Period; each published cut reads only the records whose Dimension Grain is exactly that cut (Client Segment, Service Tier, Service Offering, Channel or Business Line), so no amount is read twice; Household and Account grain records are read only in the restricted view.',
             _u("10", "Profitability Record", "Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain", "Channel", "Business Line", "Service Offering", "Service Tier", "Client Segment", "Hierarchy Version", "Source Allocation Run") + _u("10", "Cost-to-Serve Profile", "Total Cost-to-Serve") + _u("10", "Allocation Run", "Allocation Run ID", "Run Status")),
            ("Cost to Serve by Component",
             "Coverage and Servicing Cost, Client Service Cost, Platform & Technology Cost, Clearing & Client Asset Custody Cost, Money Movement Cost and Communications & Regulatory Cost of the same records, by cut; their sum equals Total Cost to Serve.",
             _u("10", "Cost-to-Serve Profile", "Coverage and Servicing Cost", "Client Service Cost", "Platform & Technology Cost", "Clearing & Client Asset Custody Cost", "Money Movement Cost", "Communications & Regulatory Cost")
             + ["Total Cost to Serve"]),
            ("Average Client Assets (from DP-008)",
             "Certified (CW-142), read: Measure Amount of MSR-AVGCLIENTASSETS for the period at Dimension Type Segment, Channel and Business Line from the locked DP-008 snapshot.",
             _MV_READ + _u("06", "Client Asset Measures", "Average Client Assets")),
            ("Households (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-HOUSEHOLDS at the period end at Dimension Type Segment and Channel.",
             _MV_READ),
            ("Cost to Serve Rate (bps)",
             "Annualized Total Cost to Serve / Average Client Assets (from DP-008) x 10,000 for the same segment, channel or business line; at the served-subject grain the 10 Cost-to-Serve Rate stays the published figure.",
             _u("10", "Cost-to-Serve Profile", "Cost-to-Serve Rate")
             + ["Total Cost to Serve", "Average Client Assets (from DP-008)"]),
            ("Cost to Serve per Household",
             'Annualized Total Cost to Serve / Households (from DP-008), by client segment and channel only (DP-008 publishes Households at Dimension Type Segment and Channel; no Service Tier dimension, see taxonomy gap).',
             ["Total Cost to Serve", "Households (from DP-008)"]),
            ("Allocated Cost Tie-Out (from DP-480)",
             "Allocated Cost by Cost-to-Serve Component of the Source Allocation Run as DP-480 publishes it (Allocated Amount of Allocation Results grouped by the Source Cost Pool's Cost-to-Serve Component) minus Cost to Serve by Component for the same run, per component.",
             _u("10", "Allocation Result", "Allocated Rule", "Target Dimension Member", "Allocated Amount")
             + _u("10", "Allocation Rule", "Allocation Rule ID", "Source Cost Pool", "Target Dimension")
             + _u("10", "Cost Pool", "Cost Pool ID", "Cost-to-Serve Component")
             + ["Cost to Serve by Component"]),
            ("Certified Operating Expense (from DP-191)",
             'Certified Operating Expense of the fiscal period as DP-191 publishes it (the same value DP-480 reads at cost center grain); read, never recomputed.',
             _u("19", "GL Account Balance", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance") + _u("19", "GL Account", "GL Account ID", "Financial Statement Class")),
            ("Cost Coverage of Certified Expense",
             "(Total Cost to Serve + Allocated Acquisition Cost of the period) / Certified Operating Expense (from DP-191) x 100, firm total: the share of certified operating expense the cost-to-serve and acquisition views explain; the rest is corporate overhead not allocated to clients.",
             _u("10", "Client Acquisition Cost Record", "Allocated Acquisition Cost")
             + ["Total Cost to Serve", "Certified Operating Expense (from DP-191)"]),
            ("Revenue to Cost to Serve Ratio",
             "Recognized Revenue Amount of DP-012 Client Revenue Records for the period by Client Segment at Period End / Total Cost to Serve of the same segment.",
             _u("10", "Client Revenue Record", "Client Revenue Period", "Recognized Revenue Amount", "Client Segment at Period End")
             + ["Total Cost to Serve"]),
            ("Service Requests per Household (from DP-381)",
             "Count of 13 Service Requests with Received Timestamp in the period (from DP-381), rolled from Account to its 02 Household (owner Account Party Role, then the owner's Household Membership in force) and to the household's 02 Segment Assignment at the period end, / Households (from DP-008) at Dimension Type Segment: the service volume behind the client service component.",
             _u("13", "Service Request", "Service Request ID", "Request Type", "Account", "Received Timestamp") + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From", "Account Role Effective To") + _u("02", "Household Membership", "Household", "Household Member", "Membership Effective From", "Membership Effective To") + _u("02", "Segment Assignment", "Segmented Party", "Segmentation Scheme", "Segment", "Segment Effective From", "Segment Effective To") + ["Households (from DP-008)"]),
            ("Acquisition Cost per Funded Household",
             "Allocated Acquisition Cost / New Households Acquired of Client Acquisition Cost Records by Acquisition Channel, Acquisition Campaign (04 Campaign, or ALL) and Cohort Month.",
             _u("10", "Client Acquisition Cost Record", "Acquisition Channel", "Acquisition Campaign", "Cohort Month", "Allocated Acquisition Cost", "New Households Acquired")
             + _u("04", "Campaign", "Campaign ID", "Campaign Type")),
            ("Campaign Spend (from DP-410)",
             'Campaign Actual Cost and Spend by Category of the campaigns of the period as CLA-B DP-410 publishes them (04 Campaign Budget Actual Cost and Budgeted Cost; Spend Line Spend Amount by Spend Category).',
             _u("04", "Campaign Budget", "Budgeted Cost", "Actual Cost") + _u("04", "Spend Line", "Spend Category", "Spend Amount") + _u("04", "Campaign", "Campaign ID")),
            ("Acquisition Cost Tie-Out to Campaign Spend",
             "Allocated Acquisition Cost of the campaign rows of the period minus Campaign Spend (from DP-410) of the same campaigns; non-campaign acquisition cost (advisor referral, workplace rollover) shown separately.",
             _u("10", "Client Acquisition Cost Record", "Acquisition Campaign", "Allocated Acquisition Cost")
             + ["Campaign Spend (from DP-410)"]),
            ("Funded Accounts by Original Campaign (from DP-392)",
             "Funded Accounts by Original Campaign as CLA-B DP-392 publishes it (distinct Milestone Accounts with Milestone Type Account Funded whose party's Marketing Lead has that Original Campaign), beside Allocated Acquisition Cost of the same campaign: the first-touch funnel count against which campaign acquisition cost is read.",
             _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date", "Milestone Account") + _u("04", "Marketing Lead", "Lead ID", "Lead Party", "Original Campaign") + _u("10", "Client Acquisition Cost Record", "Acquisition Campaign", "Allocated Acquisition Cost")),
            ("Funded Households by Acquisition Cohort (from DP-492)",
             'Funded Households by Acquisition Cohort as DP-492 publishes it, against New Households Acquired of the acquisition cost records of the same Cohort Month (the 04 Derived count the acquisition cost denominator uses).',
             _u("04", "Acquisition Milestone", "Milestone Party", "Milestone Type", "Milestone Date") + _u("10", "Client Acquisition Cost Record", "Cohort Month", "New Households Acquired")),
            ("Twelve-Month NNA per Acquired Household (from DP-492)",
             "Read as DP-492 publishes Twelve-Month NNA per Acquired Household by Campaign: DP-008's NNA attribution rows of the cohort households in the 12 months after the funding Milestone Date, weighted by the 04 Attribution Weight, per funded household; shown beside acquisition cost.",
             _u("04", "Attributed Outcome", "Attributed Campaign", "Attribution Weight") + _u("04", "Acquisition Milestone", "Milestone Date") + _u("06", "Attribution Record", "Attributed Amount")),
            ("Average Household Lifetime Value",
             "Mean Client Lifetime Value of Client Lifetime Value Estimates at the latest Estimate As-Of Date under the Lifetime Value Model Version in use, by Household Acquisition Channel, acquisition cohort and client segment; household estimates enter only as these aggregates.",
             _u("10", "Client Lifetime Value Estimate", "Valued Household", "Valuation Model Version", "Estimate As-Of Date", "Client Lifetime Value", "Household Acquisition Channel")
             + _u("10", "Lifetime Value Model", "Lifetime Value Model ID", "Lifetime Value Model Version")),
            ("Lifetime Value to Acquisition Cost Ratio",
             "Average Household Lifetime Value / Acquisition Cost per Funded Household for the same acquisition channel and cohort month.",
             ["Average Household Lifetime Value", "Acquisition Cost per Funded Household"]),
            ("Estimates on Unapproved Model Version",
             "Count of Client Lifetime Value Estimates whose Valuation Model Version is not a 37 Model Inventory Entry (Model ID, Model Version) of Model Type Lifetime Value with Model Use Status Approved for Use (CD-294).",
             _u("10", "Client Lifetime Value Estimate", "Valuation Model Version")
             + _u("37", "Model Inventory Entry", "Model ID", "Model Version", "Model Type", "Model Use Status")),
        ],
        inputs=[
            ("10", "Profitability Record", ["Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain", "Channel", "Business Line", "Service Offering", "Service Tier", "Client / Account", "Client Segment", "Hierarchy Version", "Source Allocation Run"]),
            ("10", "Cost-to-Serve Profile", ["Served Party", "Coverage and Servicing Cost", "Client Service Cost", "Platform & Technology Cost", "Clearing & Client Asset Custody Cost", "Money Movement Cost", "Communications & Regulatory Cost", "Total Cost-to-Serve", "Cost-to-Serve Rate"]),
            ("10", "Client Acquisition Cost Record", ["Acquisition Channel", "Acquisition Campaign", "Cohort Month", "Allocated Acquisition Cost", "New Households Acquired"]),
            ("10", "Lifetime Value Model", ["Lifetime Value Model ID", "Lifetime Value Model Version", "Lifetime Value Method", "Projection Horizon Years", "Discount Rate", "Attrition Assumption Basis", "Margin Basis"]),
            ("10", "Client Lifetime Value Estimate", ["Valued Household", "Valuation Model Version", "Estimate As-Of Date", "Expected Lifetime Revenue", "Expected Lifetime Cost to Serve", "Client Lifetime Value", "Household Acquisition Channel"]),
            ("10", "Allocation Run", ["Allocation Run ID", "Run Period", "Run Status"]),
            ("10", "Allocation Rule", ["Allocation Rule ID", "Source Cost Pool", "Target Dimension"]),
            ("10", "Allocation Result", ["Allocated Rule", "Target Dimension Member", "Allocated Amount"]),
            ("10", "Cost Pool", ["Cost Pool ID", "Cost-to-Serve Component"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Client Revenue Period", "Recognized Revenue Amount", "Client Segment at Period End"]),
            ("04", "Campaign", ["Campaign ID", "Campaign Type"]),
            ("04", "Campaign Budget", ["Budgeted Cost", "Actual Cost"]),
            ("04", "Spend Line", ["Spend Category", "Spend Amount"]),
            ("04", "Acquisition Milestone", ['Milestone Party', 'Milestone Type', 'Milestone Date', 'Milestone Account']),
            ("04", "Attributed Outcome", ["Attributed Campaign", "Attribution Weight"]),
            ("13", "Service Request", ["Service Request ID", "Request Type", "Account", "Received Timestamp"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Type", "Model Use Status"]),
            ("19", "GL Account Balance", ["Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "Financial Statement Class"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Average Client Assets"]),
            ("06", "Attribution Record", ['Attributed Amount']),
            ("02", "Segment Assignment", ['Segmented Party', 'Segmentation Scheme', 'Segment', 'Segment Effective From', 'Segment Effective To']),
            ("02", "Household Membership", ['Household', 'Household Member', 'Membership Effective From', 'Membership Effective To']),
            ("15", "Account Party Role", ['Account Role Type', 'Role Party', 'Role Account', 'Account Role Effective From', 'Account Role Effective To']),
            ("04", "Marketing Lead", ['Lead ID', 'Lead Party', 'Original Campaign']),
        ],
        upstream=['DP-480', 'DP-012', 'DP-008', 'DP-492', 'DP-381', 'DP-392', 'DP-410', 'DP-011', 'DP-191', 'DP-212', 'DP-518', 'DP-093', 'DP-240', 'DP-004', 'DP-013'],
        refresh="Monthly",
        timeliness="Business day 12 after month-end, after the DP-480 allocation run is Final (business day 10) and DP-012 has closed the period; lifetime value estimates quarterly by business day 15",
        history="Monthly cost-to-serve and acquisition cost aggregates kept 10 years, one version per allocation run; lifetime value aggregates kept per model version for 10 years; restricted household rows kept 7 years",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Source Allocation Run resolves to a DP-480 run, every Client Segment, Service Tier and Valued Household to DP-240, every Service Offering to DP-004, every Acquisition Campaign to a DP-011 campaign and every Valuation Model Version to a DP-212 model entry.",
            'Segment Assignment and Household Membership periods of one party do not overlap and end on or after they start, a Profitability Record is read for one Hierarchy Version and one Dimension Grain per published cut, and one Lifetime Value Model Version is in use for each estimate date.',
            "Cost to Serve by Component sums to Total Cost to Serve within USD 1, Allocated Cost Tie-Out (from DP-480) is within 0.5% per component, Certified Operating Expense (from DP-191) equals DP-191's published value, and Average Client Assets and Households equal the locked DP-008 values.",
            "Total Cost-to-Serve and Cost-to-Serve Rate are populated on every Profitability Record read, Allocated Acquisition Cost and New Households Acquired on every acquisition cost record, and Client Lifetime Value and Household Acquisition Channel on every estimate.",
            "The published product carries segment, tier, channel, campaign and cohort aggregates with a 10-household minimum cell; household rows (Valued Household, Served Party and Client / Account keys with their cost and value) are released only through the 'DP-498 Household Economics' restricted view registered in DP-518 to entitled client economics and advice leadership roles (CW-243).",
            "A month is published only from a Final allocation run and a closed DP-012 period; a re-run of the allocation or a new LTV model version creates a new version, and the prior version is kept.",
        ],
        notes=("Certified numbers: reads Average Client Assets and Households from DP-008, client revenue from DP-012 and Certified "
               "Operating Expense from DP-191 (through DP-480's read); owns none (CW-011, CW-241). Cost to serve is an allocated "
               "management view that reconciles to certified operating expense (Cost Coverage of Certified Expense) and is never a "
               "ledger figure. "
               "PII tier: financial (household lifetime value and cost to serve are PII - financial inferences, CW-157); published as "
               "aggregates, household rows only in the restricted view registered in DP-518 (DQ5); no special-category data is read. "
               "Boundaries: allocation pools, rules, runs and results are DP-480's (foundational); this product reads 10 Cost-to-Serve "
               "Profile and the DP-480 allocation and never re-runs it. Profitability and margin are DP-499's, which reads this "
               "product's cost to serve. Campaign spend is CLA-B DP-410's (Campaign Actual Cost, Spend by Category) and the acquisition funnel "
               "CLA-B DP-392's (Funded Accounts by Original Campaign), read under those names and not redefined; neither lists this "
               "product. Cohort NNA and the funded-household count are DP-492's. DP-499 reads this product, so DP-499 is not upstream. DP-244 retires into this product (lead ruling 2026-10-15, CW-206): its measures "
               "'Total Cost to Serve', 'Cost to Serve Rate (bps)' and 'Cost Coverage of Certified Expense' are kept by name here for "
               "the SM-14 readers (re-point the SM-14 metric sources from DP-244 to DP-498); DP-244's channel x vehicle roll-up is the "
               "Channel cut of Total Cost to Serve. DP-244 measures with no successor here (lineage to re-point or retire their SM-14 "
               "rows): 'Attributed AUM and Flows (from DP-008)' (read DP-008 directly), 'Distribution Cost Components (from DP-035)' and "
               "'Cost per Unit of Sales' (DP-499 Net Revenue After Distribution Costs), 'Firm-Borne Waivers (from DP-170)' and "
               "'Fund-Borne Servicing Expense (from DP-170)' (DP-497 Own-Fund Management Fee Revenue and DP-165), 'Operating Volumes "
               "(from DP-177, DP-178, DP-043)' and 'Servicing Cost per Order' (retire), 'Certified Distribution Expense (from DP-191)', "
               "'Distribution Actual vs Budget (from DP-056)' and 'Distribution Headcount and FTE (from DP-192)' (retire with the "
               "wholesale distribution expense view). Plan section 8.3 example (Cost to Serve & CLV). "
               "Acceptance question 11 (plan section 8.5): answered by Total Cost to Serve, Cost to Serve per Household, Average "
               "Household Lifetime Value and Lifetime Value to Acquisition Cost Ratio (with Acquisition Cost per Funded Household); "
               "mastering domains 10, 04. "
               "Tailoring lever: lifetime value method and cost components (10 SME 6, 9). Reference default: discounted margin over 20 "
               "years with attrition, six stored cost components (communications and regulatory combined); lever: seven components "
               "or a cohort revenue multiple. Tailoring lever: household economics visibility (10 SME 7). Reference default: "
               "restricted; lever: an advisor-facing household view registered in DP-518. "
               "Taxonomy gap: 06 Measure Value has no Service Tier Dimension Type, so Households (from DP-008) cannot be cut by service tier; "
               "Total Cost to Serve is shown by Service Tier from the 10 records, but Cost to Serve per Household and Cost to Serve Rate "
               "(bps) are published by segment and channel only. Household path: an account reaches its 02 Household through the owner "
               "Account Party Role (DP-093) and Household Membership (DP-240). "
               "Taxonomy gap: 10 Client Acquisition Cost Record has no data version or allocation run reference, so acquisition cost "
               "versions follow the period. Taxonomy gap: 10 Client Lifetime Value Estimate has no cohort month; the cohort is the "
               "household's first funding month from DP-492. "
               "Drafting assumptions: Data Version Actual; Run Status Final; Model Type Lifetime Value and Model Use Status Approved "
               "for Use; Milestone Type Account Funded; the 10-household minimum cell; tolerances USD 1 and 0.5%; business days 12 and "
               "15. "
               "Decisions: CW-011, CW-157, CW-159, CW-206, CW-240, CW-241, CW-242, CW-243, CD-294, CD-344. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eight "
               "objects plus the 10 Profitability Record key, the DP-480 allocation objects, 10 Client Revenue Record, 13 Service "
               "Request, 04 Acquisition Milestone, Marketing Lead and Attributed Outcome, 15 Account Party Role, 02 Household Membership and "
               "Segment Assignment (02 Service Tier Assignment dropped in the fix pass), 19 GL balances and the DP-008 reads; upstream "
               "DP-381, DP-392, DP-410, DP-191, DP-212, DP-093 and DP-518 added; measure 'Funded Households Acquired (from DP-392)' "
               "renamed 'Funded Accounts by Original Campaign (from DP-392)' and 'Expected Lifetime Margin' dropped in the fix pass (no "
               "reader); DP-518 (FDN) registers the member-level restricted views of DP-480 that this product releases and lists neither DP-498 nor DP-499, so no cycle arises."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-499": dict(
        definition=("Revenue, distribution payments, direct and allocated cost and margin by client segment, service offering, "
                    "channel, business line, product and partner firm on the governed management hierarchy, from the 10 "
                    "Profitability Records of the final DP-480 allocation run; advisor book and household profitability only in "
                    "restricted views. Revenue ties to DP-012, distribution payments to DP-487, cost to serve to DP-498 and "
                    "operating profit to certified operating income in DP-191. Leaders see which segments, offerings and books "
                    "create value after the cost of serving them. It owns no certified metric family."),
        business_questions=[
            "Which client segments, offerings and channels earn a positive contribution margin and operating margin this year?",
            "How does net revenue yield on client assets compare across offerings and business lines?",
            "Which offerings or partner firms lose money after distribution payments and cost to serve?",
            "How profitable is each advisor's book, and how is household profitability distributed within each segment (restricted)?",
            "Does management operating profit tie to certified operating income?",
        ],
        grain=("Profitability record (dimension combination x profitability period x data version x hierarchy version) as the main "
               "output, published at segment, offering, channel, business line, product and partner firm grains; advisor and "
               "household grains only in the restricted views; one version per allocation run"),
        dimensions=["Profitability period (DP-013)", "Data version", "Management hierarchy and node (DP-480)", "Client segment and service tier (DP-240)",
                    "Service offering and product / share class (DP-004)", "Distribution channel", "Business line", "Partner firm (DP-001)",
                    "Advisor (DP-009, restricted)", "Reporting legal entity (DP-013)", "Operating segment"],
        measures=[
            ("Gross Revenue",
             "Sum of Gross Revenue of Profitability Records with Data Version Actual, the current Hierarchy Version and a Source Allocation Run with Run Status Final, for the Profitability Period, by Dimension Grain cut (Client Segment, Service Offering, Channel, Business Line, Product / Share Class, Partner Firm).",
             _u("10", "Profitability Record", "Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain", "Channel", "Business Line", "Service Offering", "Product / Share Class", "Partner Firm", "Client Segment", "Hierarchy Version", "Source Allocation Run")
             + _u("10", "Profitability Measure", "Gross Revenue")
             + _u("10", "Allocation Run", "Allocation Run ID", "Run Status")),
            ("Revenue Tie-Out to DP-012",
             "Gross Revenue at Dimension Grain Business Line minus, for the same fiscal period and business line, Recognized Revenue Amount of DP-012 Client Revenue Records plus Gross Fee Revenue of DP-012 Fee Revenue Records (the gross basis DP-012's Gross Fee Revenue uses).",
             _u("10", "Client Revenue Record", "Client Revenue Period", "Recognized Revenue Amount", "Revenue Business Line") + _u("10", "Fee Revenue Record", "Revenue Accounting Period", "Gross Fee Revenue") + ["Gross Revenue"]),
            ("Distribution Payments (from DP-487)",
             "Distribution Payments of the same records; at Dimension Grain Partner Firm tied to the Expense Amount of 10 Distribution Cost Items of intermediary payment categories for the Service Period, as DP-487 accrues them.",
             _u("10", "Profitability Measure", "Distribution Payments")
             + _u("10", "Distribution Cost Item", "Distribution Cost Item ID", "Distribution Expense Category", "Direct Channel", "Service Period Start", "Service Period End", "Expense Amount")),
            ("Net Revenue After Distribution Costs",
             "Net Revenue After Distribution Costs of the same records (Gross Revenue - Distribution Payments), by cut.",
             _u("10", "Profitability Measure", "Net Revenue After Distribution Costs")
             + ["Gross Revenue", "Distribution Payments (from DP-487)"]),
            ("Direct Sales & Marketing Cost",
             "Direct Sales & Marketing Cost of the same records, with the share of 10 Distribution Cost Items marked Directly Attributable Indicator Y for the cut's Direct Product / Share Class or Direct Channel.",
             _u("10", "Profitability Measure", "Direct Sales & Marketing Cost")
             + _u("10", "Distribution Cost Item", "Direct Product / Share Class", "Direct Channel", "Directly Attributable Indicator", "Expense Amount")),
            ("Contribution Margin",
             "Contribution Margin of the same records and Contribution Margin / Gross Revenue x 100, by cut.",
             _u("10", "Profitability Measure", "Contribution Margin")
             + ["Gross Revenue"]),
            ("Allocated Indirect Cost (from DP-480)",
             "Allocated Indirect Cost of the same records, as allocated by the DP-480 run named in Source Allocation Run.",
             _u("10", "Profitability Measure", "Allocated Indirect Cost")
             + _u("10", "Profitability Record", "Source Allocation Run")),
            ("Cost to Serve (from DP-498)",
             "Total Cost-to-Serve of the Cost-to-Serve Profile of the same records, as DP-498 publishes Total Cost to Serve for the cut.",
             _u("10", "Cost-to-Serve Profile", "Total Cost-to-Serve")),
            ("Operating Profit",
             "Operating Profit and Operating Margin of the same records, by cut and by management hierarchy node rolled up through Management Hierarchy Node Parent Node to the Operating Segment Mapping.",
             _u("10", "Profitability Measure", "Operating Profit", "Operating Margin")
             + _u("10", "Management Hierarchy", "Management Hierarchy ID", "Hierarchy Type", "Hierarchy Status")
             + _u("10", "Management Hierarchy Node", "Node ID", "Parent Node", "Leaf Member", "Operating Segment Mapping")),
            ("Average Client Assets (from DP-008)",
             "Certified (CW-142), read: Measure Amount of MSR-AVGCLIENTASSETS for the period at Dimension Type Segment, Channel and Business Line from the locked DP-008 snapshot.",
             _MV_READ + _u("06", "Client Asset Measures", "Average Client Assets")),
            ("Net Revenue Yield on Client Assets (bps)",
             "Annualized Net Revenue After Distribution Costs / Average Client Assets (from DP-008) x 10,000 for the same segment, channel or business line; the 10 Net Revenue Yield of the record shown beside it (its Average AUM Reference basis is not used).",
             _u("10", "Profitability Measure", "Net Revenue Yield")
             + ["Net Revenue After Distribution Costs", "Average Client Assets (from DP-008)"]),
            ("Offerings and Segments With Negative Contribution",
             "Count and Gross Revenue of Service Offering and Client Segment cuts whose Contribution Margin is below zero for the trailing four quarters.",
             ["Contribution Margin", "Gross Revenue"]),
            ("Partner Firm Profitability",
             "Net Revenue After Distribution Costs and Operating Profit at Dimension Grain Partner Firm for the IC line, ranked, with the partner's Distribution Payments (from DP-487).",
             ["Net Revenue After Distribution Costs", "Operating Profit", "Distribution Payments (from DP-487)"]),
            ("Advisor Book Profitability (restricted)",
             "Gross Revenue, Contribution Margin and Operating Profit of records with Dimension Grain Advisor by Advisor, for advisors with Advisor Status Active and their Advisor Business Lines; released only in the 'DP-499 Advisor Book' restricted view (allocated compensation cost, CD-344 tier).",
             _u("10", "Profitability Record", "Advisor")
             + _u("03", "Advisor", "Employee", "Advisor Status", "Advisor Business Lines")
             + ["Gross Revenue", "Contribution Margin", "Operating Profit"]),
            ("Household Profitability Distribution",
             "Operating Profit of records with Dimension Grain Household grouped into deciles within each Client Segment: the published product shows decile boundaries and counts only; household rows (Client / Account) only in the 'DP-499 Household Profitability' restricted view.",
             _u("10", "Profitability Record", "Client / Account", "Client Segment")
             + ["Operating Profit"]),
            ("Operating Profit Tie-Out to Certified Operating Income (from DP-191)",
             "Operating Profit at Dimension Grain Business Line summed over the firm minus Certified Operating Income of the fiscal period as DP-191 publishes it, by Reporting Legal Entity; DP-191's value is read, never recomputed.",
             _u("10", "Profitability Record", "Reporting Legal Entity", "Reporting Currency") + _u("19", "GL Account Balance", "Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance") + _u("19", "GL Account", "GL Account ID", "Financial Statement Class") + ["Operating Profit"]),
            ("Measure Formula Conformance",
             "Count of Profitability Measure Codes whose Measure Formula differs from the version in force at the start of the year, and of records whose Operating Profit differs from Contribution Margin - Allocated Indirect Cost by more than USD 1.",
             _u("10", "Profitability Measure Definition", "Profitability Measure Code", "Measure Formula")
             + ["Operating Profit", "Contribution Margin", "Allocated Indirect Cost (from DP-480)"]),
        ],
        inputs=[
            ("10", "Profitability Record", ["Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain", "Channel", "Business Line", "Service Offering", "Service Tier", "Partner Firm", "Product / Share Class", "Advisor", "Client / Account", "Client Segment", "Reporting Legal Entity", "Hierarchy Version", "Source Allocation Run", "Reporting Currency"]),
            ("10", "Profitability Measure", ["Gross Revenue", "Distribution Payments", "Net Revenue After Distribution Costs", "Net Revenue Yield", "Direct Sales & Marketing Cost", "Contribution Margin", "Allocated Indirect Cost", "Operating Profit", "Operating Margin"]),
            ("10", "Profitability Measure Definition", ["Profitability Measure Code", "Measure Formula"]),
            ("10", "Cost-to-Serve Profile", ["Total Cost-to-Serve"]),
            ("10", "Distribution Cost Item", ["Distribution Cost Item ID", "Distribution Expense Category", "Direct Product / Share Class", "Direct Channel", "Service Period Start", "Service Period End", "Expense Amount", "Directly Attributable Indicator"]),
            ("10", "Allocation Run", ["Allocation Run ID", "Run Period", "Run Status"]),
            ("10", "Management Hierarchy", ["Management Hierarchy ID", "Hierarchy Type", "Hierarchy Status"]),
            ("10", "Management Hierarchy Node", ["Node ID", "Parent Node", "Leaf Member", "Operating Segment Mapping"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Client Revenue Period", "Recognized Revenue Amount", "Revenue Business Line"]),
            ("10", "Fee Revenue Record", ['Fee Revenue Record ID', 'Revenue Accounting Period', 'Gross Fee Revenue']),
            ("03", "Advisor", ["Employee", "Advisor Status", "Advisor Business Lines"]),
            ("19", "GL Account Balance", ["Balance GL Account", "Balance Fiscal Period", "Balance Type", "Opening Balance", "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "Financial Statement Class"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Average Client Assets"]),
        ],
        upstream=["DP-480", "DP-012", "DP-487", "DP-498", "DP-008", "DP-009", "DP-191", "DP-518", "DP-001", "DP-240", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 13 after month-end, the day after DP-498 publishes; quarterly views by business day 15 after quarter-end",
        history="Monthly profitability by cut kept 10 years, one version per allocation run and hierarchy version (restatements under 10 Hierarchy Restatement keep the prior version); restricted advisor and household rows kept 7 years",
        classification="Confidential - Compensation",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Source Allocation Run resolves to a DP-480 run, every Hierarchy Version to a DP-480 Management Hierarchy, every Service Offering and Product / Share Class to DP-004, every Partner Firm to DP-001, every Advisor to DP-009 and every Client Segment and Client / Account to DP-240.",
            "A Profitability Record is read for exactly one Data Version, Hierarchy Version and Source Allocation Run per period, and Management Hierarchy Node parents resolve to nodes of the same hierarchy version with no cycle.",
            "Revenue Tie-Out to DP-012 is within 0.5% per business line, Distribution Payments (from DP-487) within USD 1 per partner, Operating Profit Tie-Out to Certified Operating Income (from DP-191) within 0.5% firm-wide, and Average Client Assets equals the locked DP-008 value.",
            "Gross Revenue, Contribution Margin, Allocated Indirect Cost and Operating Profit are populated on every Profitability Record read, and Dimension Grain names every dimension attribute populated on the record.",
            "Advisor rows (allocated compensation cost) and household and account rows (PII - financial) are released only through the 'DP-499 Advisor Book' and 'DP-499 Household Profitability' restricted views registered in DP-518 to entitled finance and line leadership; the published product is at segment, offering, channel, business line, product and partner grain with a 10-household minimum cell (CW-243).",
            "A period is published only from a Final allocation run after DP-012 closes the period; a hierarchy restatement or allocation re-run creates a new version and the prior version is kept.",
        ],
        notes=("Certified numbers: reads client revenue from DP-012, Average Client Assets from DP-008 and certified operating "
               "income from DP-191; owns none (CW-011, CW-241). Margins are allocated management views that reconcile to DP-191 "
               "(DQ3), never ledger figures. "
               "PII tier: financial and compensation (household profitability is PII - financial; advisor book rows carry allocated "
               "employee compensation cost, CD-344 tier); both only in the restricted views registered in DP-518 (DQ5); no "
               "special-category data is read. "
               "Boundaries: allocation and the management hierarchy are DP-480's; cost to serve is DP-498's and is read; distribution "
               "payments are DP-487's; revenue recognition is DP-012's and the ledger tie-out view DP-598's. Successor of DP-035 "
               "(CW-159, CW-243, CW-240); live DP-109 and DP-183 list this product upstream, so it lists neither. Feeds DP-490 with "
               "Operating Margin by business line. It reads DP-498's cost to serve and does not feed DP-498 (no Q11 feed is claimed). "
               "Tailoring lever: advisor-facing household views (10 SME 7). Reference default: restricted to finance and line "
               "leadership; lever: advisor access to their own book's households through a DP-518 view. Tailoring lever: partner firm "
               "profitability (05 SME 1). Reference default: firm level for the thin IC line. "
               "Taxonomy gap: 10 Profitability Record Average AUM Reference names a wholesale AUM basis; the yield here uses Average "
               "Client Assets from DP-008 instead. Taxonomy gap: 10 Profitability Measure Definition has no version or effective "
               "date, so formula conformance compares against the year-start extract. "
               "Drafting assumptions: Data Version Actual; Run Status Final; intermediary payment Distribution Expense Category "
               "values; tolerances USD 1 and 0.5%; trailing four quarters; the 10-household minimum cell; business days 13 and 15. "
               "Decisions: CW-011, CW-157, CW-159, CW-240, CW-241, CW-243, CD-344. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's five "
               "objects plus the Cost-to-Serve Profile, DP-480 run and hierarchy objects, the DP-012 revenue records, 19 GL balances "
               "and the DP-008 denominator; upstream DP-001, DP-240 and DP-518 (the restricted-view register of the advisor and household views) added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-490": dict(
        definition=("The monthly leadership view of the firm's client franchise: Client Assets, Net New Assets, organic growth, "
                    "market movement, Advised Assets and the household, client and funded account counts by channel and business "
                    "line from DP-008; Firm AUM and its three slices from DP-241, shown beside and never summed with Client Assets; "
                    "client fee revenue from DP-012 and its yield from DP-497; operating margin from DP-499; market share from "
                    "DP-505; and NNA and revenue against plan and forecast. It reads every certified number from its one owner, so "
                    "leadership reviews one set of figures. It owns no certified metric family."),
        business_questions=[
            "What are Client Assets, Net New Assets and organic growth this month and year to date by channel and business line?",
            "How do Client Assets compare with certified Firm AUM and its own funds, managed account and institutional slices?",
            "How are NNA and revenue tracking against plan and the latest forecast, and what drives the variance?",
            "How many households, clients and funded accounts do we serve, and is the base growing?",
            "What are revenue yield, operating margin and market share by channel?",
        ],
        grain=("Reporting period (month, quarter, year to date) x channel or business line x scorecard measure as the main output, "
               "with the firm-level Firm AUM slices, plan and forecast variance and restatement rows as companion facts; one version "
               "per DP-008 snapshot"),
        dimensions=["Reporting period and period type (DP-013)", "Distribution channel", "Business line", "Firm AUM slice (DP-241)", "Revenue stream (DP-012)",
                    "Plan version and scenario", "Variance driver", "Market share definition (DP-505)", "DP-008 snapshot and data basis"],
        measures=[
            ("Ending Client Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-CLIENTASSETS at Dimension Type Total, Channel and Business Line at the period end in the locked DP-008 snapshot.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Net New Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-NNA at Dimension Type Total, Channel and Business Line for the period.",
             _MV_READ + _u("06", "Client Asset Measures", "Net New Assets")),
            ("Client Organic Growth Rate (from DP-008)",
             "Certified (CW-142), read: Client Organic Growth Rate at the same dimensions, with Beginning Client Assets.",
             _MV_READ + _u("06", "Client Asset Measures", "Client Organic Growth Rate", "Beginning Client Assets")),
            ("Client Market Movement and Other (from DP-008)",
             "Certified (CW-142), read: Client Market Movement and Other at the same dimensions, so that Beginning Client Assets + Net New Assets + Net Inter-Channel Transfers + Client Market Movement and Other = Ending Client Assets.",
             _MV_READ + _u("06", "Client Asset Measures", "Client Market Movement and Other", "Net Inter-Channel Transfers")),
            ("Advised Assets (from DP-008)",
             "Certified (CW-011), read: Advised Assets at Dimension Type Total and Channel at the period end.",
             _MV_READ + _u("06", "Client Asset Measures", "Advised Assets")),
            ("Households, Clients and Funded Accounts (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-HOUSEHOLDS, MSR-CLIENTS and MSR-FUNDEDACCOUNTS at Dimension Type Total and Channel at the period end.",
             _MV_READ),
            ("Net Household Change",
             "Households (from DP-008) at the period end minus at the prior period end, by channel: the client base movement view of backlog DP-326.",
             ["Households, Clients and Funded Accounts (from DP-008)"]),
            ("Own-Fund Net Flows (from DP-008)",
             "Certified (CW-203), read: Gross Sales, Redemptions and Net Flows (Net Sales) at Dimension Type Total and Channel for the period: own-fund flows across every channel.",
             _MV_READ + _u("06", "Flow Measures", "Gross Sales", "Redemptions", "Net Flows (Net Sales)")),
            ("Firm AUM and Slices (from DP-241)",
             "Certified (CW-011), read: Firm AUM, Firm AUM Own Funds Slice, Firm AUM Managed Account Slice and Firm AUM Institutional Slice at the month-end as DP-241 publishes them; the slice definitions are DP-241's (the managed account slice from DP-345). Displayed in its own section, never added to Client Assets.",
             _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Approval Status", "Fund Net Assets Amount") + _u("46", "Model Assignment", "Model Assignment ID", "Assignment Status", "Regulatory AUM Classification") + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value")),
            ("Net Fee Revenue (from DP-012)",
             "Certified (CW-011), read: Net Fee Revenue of DP-012 for the fiscal period by business line and channel (client fee streams of Client Revenue Records and own-fund Net Fee Revenue).",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount", "Revenue Channel", "Revenue Business Line")
             + _u("10", "Fee Revenue Record", "Revenue Accounting Period", "Net Fee Revenue")),
            ("Client Revenue Yield (from DP-497)",
             "Client Revenue Yield (bps) by channel as DP-497 publishes it: annualized client revenue over Average Client Assets (from DP-008).",
             _u("10", "Client Revenue Record", "Recognized Revenue Amount", "Revenue Channel")
             + _u("06", "Client Asset Measures", "Average Client Assets")),
            ("Operating Margin by Business Line (from DP-499)",
             "Operating Margin of DP-499 Profitability Records at Dimension Grain Business Line for the Profitability Period (Data Version Actual).",
             _u("10", "Profitability Record", "Profitability Period", "Data Version", "Dimension Grain", "Business Line")
             + _u("10", "Profitability Measure", "Operating Margin")),
            ("Channel Market Share (from DP-505)",
             "Market Share of DP-505 Market Share Records whose Share Definition measures Client Assets or Net New Assets by Channel, at the latest Period End Date.",
             _u("11", "Market Share Record", "Share Definition", "Period End Date", "Channel", "Market Share")),
            ("NNA Forecast vs Plan",
             "Forecast Gross Sales - Forecast Redemptions of the 10 Flow & Revenue Forecast lines of the current Plan Version of Plan Type Rolling Forecast by Forecast Channel, against the same of the Annual Budget Plan Version, and against Net New Assets (from DP-008) year to date; forecasts are labeled and not certified.",
             _u("10", "Plan Version", "Plan Version ID", "Plan Type", "Scenario", "Plan Fiscal Year", "Plan Version Status")
             + _u("10", "Flow & Revenue Forecast", "Forecast Channel", "Forecast Gross Sales", "Forecast Redemptions")
             + ["Net New Assets (from DP-008)"]),
            ("Revenue vs Plan and Forecast",
             "Net Fee Revenue (from DP-012) year to date against the Planned Amount of the revenue Plan P&L Lines of the Annual Budget for the Plan Period and against Forecast Net Revenue of the current Rolling Forecast, by channel; Forecast Net Fee Rate and Forecast Average AUM (the forecast's average client asset basis) shown.",
             _u("10", "Plan Line", "Plan P&L Line", "Plan Dimension Members", "Plan Period", "Planned Amount")
             + _u("10", "Flow & Revenue Forecast", "Forecast Channel", "Forecast Average AUM", "Forecast Net Fee Rate", "Forecast Net Revenue")
             + ["Net Fee Revenue (from DP-012)"]),
            ("Plan Variance by Driver",
             "Variance Amount of 10 Variance lines of the Compared Plan Version for the period by Variance Driver, with Variance Commentary, for the NNA and revenue lines.",
             _u("10", "Variance", "Compared Plan Version", "Variance Amount", "Variance Driver", "Variance Commentary")),
            ("Restatement Impact (from DP-008)",
             "Net Impact Amount of DP-008 Restatements approved in the period by Restatement Reason and Affected Periods, so leadership sees which prior figures changed.",
             _u("06", "Restatement", "Restatement ID", "Restatement Reason", "Affected Periods", "Net Impact Amount")),
        ],
        inputs=[
            ("06", "Measure Value", ["Measure", "Period Type", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type", "As-Of Date"]),
            ("06", "Reporting Period", ["Reporting Period ID", "Period Type", "Final Close Date"]),
            ("06", "Restatement", ["Restatement ID", "Restatement Reason", "Affected Periods", "Net Impact Amount"]),
            ("06", "Client Asset Measures", ["Beginning Client Assets", "Ending Client Assets", "Net New Assets", "Client Market Movement and Other", "Net Inter-Channel Transfers", "Client Organic Growth Rate", "Advised Assets", "Average Client Assets"]),
            ("06", "Flow Measures", ["Gross Sales", "Redemptions", "Net Flows (Net Sales)"]),
            ("27", "Fund NAV Calculation", ["Valuation Date", "NAV Approval Status", "Fund Net Assets Amount"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assignment Status", "Regulatory AUM Classification"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount", "Revenue Channel", "Revenue Business Line"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Accounting Period", "Net Fee Revenue"]),
            ("10", "Profitability Record", ["Profitability Record ID", "Profitability Period", "Data Version", "Dimension Grain", "Business Line"]),
            ("10", "Profitability Measure", ["Operating Margin"]),
            ("10", "Plan Version", ["Plan Version ID", "Plan Type", "Scenario", "Plan Fiscal Year", "Plan Version Status"]),
            ("10", "Plan Line", ["Plan P&L Line", "Plan Dimension Members", "Plan Period", "Planned Amount"]),
            ("10", "Flow & Revenue Forecast", ["Forecast Channel", "Forecast Gross Sales", "Forecast Redemptions", "Forecast Average AUM", "Forecast Net Fee Rate", "Forecast Net Revenue"]),
            ("10", "Variance", ["Compared Plan Version", "Variance Amount", "Variance Driver", "Variance Commentary"]),
            ("11", "Market Share Record", ["Market Share Record ID", "Share Definition", "Period End Date", "Channel", "Market Share"]),
        ],
        upstream=["DP-008", "DP-241", "DP-012", "DP-497", "DP-499", "DP-505", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 13 after month-end, once DP-008 (business day 8), DP-241 (business day 9), DP-012 (business day 10) and DP-499 (business day 13) have published; a flash version of the DP-008 measures on business day 3",
        history="Monthly scorecards kept 10 years, one version per DP-008 snapshot; flash versions kept 13 months; restated months keep the prior version beside the restatement",
        classification="Confidential - Financial",
        pii="N",
        delivery=["BI semantic model", "Dashboard", "Warehouse table"],
        dq_rules=[
            "Every channel and business line key is a value of the shared Distribution Channel and Business Line lists, every Firm AUM slice is one of DP-241's three, and every Plan Version and Compared Plan Version resolves to a 10 Plan Version of the fiscal year (DP-013).",
            "One DP-008 snapshot, one DP-241 version and one DP-012 closed period are used per published month, and Reporting Period boundaries do not overlap.",
            "Every certified value equals its owner's published value for the same period and snapshot (DP-008, DP-241, DP-012) within USD 1, and Beginning Client Assets + Net New Assets + Net Inter-Channel Transfers + Client Market Movement and Other equals Ending Client Assets within USD 1 per channel.",
            "Every scorecard measure is populated for every channel and business line with a non-zero Ending Client Assets, and the plan and forecast values exist for the current fiscal year.",
            "The scorecard publishes aggregates only: no account, household, advisor or employee row is published; the 46 Model Assignment, 27 and 18 attributes are named only as the source of DP-241's published slices and are never queried row by row here.",
            "The monthly scorecard publishes on business day 13 and is locked; a later restatement by an owner publishes a new version with Restatement Impact (from DP-008) shown, and Client Assets and Firm AUM are never summed in any total.",
        ],
        notes=("Certified numbers: reads Client Assets, NNA, organic growth, market movement, Advised Assets, the counts and own-fund "
               "flows from DP-008, Firm AUM and its slices from DP-241 and Net Fee Revenue from DP-012; owns none (CW-011, CW-241). "
               "Firm AUM is shown in its own section and never added to Client Assets; 'AUM' names Firm AUM only (the 10 attribute "
               "'Forecast Average AUM' is read under its catalog name as the forecast's average client asset basis). "
               "PII tier: none at publication. pii = N: the product reads DP-008 Measure Values, DP-012 and DP-499 aggregates, plan lines "
               "and DP-241's published slices; the 10 Client Revenue Record and 46 Model Assignment attributes noted PII are named only as "
               "the sources of their owners' published values (DQ5), and the other warnings are the lexical 'No PII' notes. Forecast lines "
               "are FP&A plan versions held in 10 (Plan Type Rolling Forecast), not a scoring or statistical model output, so CD-294 and "
               "DP-212 do not apply; a statistical forecast model would be registered in 37 and DP-212 added. "
               "Boundaries: each number's owner publishes its detail (DP-491 and DP-492 NNA by advisor and campaign, DP-496 the "
               "holding-type mix, DP-497 yield, DP-499 margin, DP-505 share); this product only assembles them. DP-245 lists the "
               "certified families with their owners; the scorecard reads the owners directly rather than through DP-245 (no DP-245 "
               "measure is read, so it is not upstream). Successor of DP-015 (CW-240). WP1 scope: also reads 10 Flow & Revenue "
               "Forecast and Variance (from backlog DP-502, which folds in here if picked up); backlog DP-326 Client Base Movement "
               "folds in here (Net Household Change). "
               "Acceptance question 1 (plan section 8.5): answered with DP-496 by Ending Client Assets (from DP-008) and Firm AUM and "
               "Slices (from DP-241); mastering domains 06, 27, 46, 18 here, 49 through DP-496's Own-Fund Client Holdings Market "
               "Value (from DP-300), and 16 and 29 through DP-008 and DP-007. Acceptance question 2: answered at channel by Net New Assets (from DP-008); mastering domain "
               "06 here, with advisor (03, 49, 50) through DP-491 and campaign (04) through DP-492. "
               "Tailoring lever: listed parent. Reference default: not listed; if listed, unreleased quarterly figures are Restricted - "
               "MNPI until the earnings release. Tailoring lever: forecast method. Reference default: run-rate plus seasonality "
               "rolling forecast held in 10. "
               "Taxonomy gap: no 06 or 27 attribute stores the certified Firm AUM; Firm AUM and Slices (from DP-241) traces to the "
               "attributes DP-241 computes it from. Taxonomy gap: 10 Flow & Revenue Forecast has no forecast NNA attribute; forecast "
               "NNA is Forecast Gross Sales - Forecast Redemptions. "
               "Drafting assumptions: Plan Type values Rolling Forecast and Annual Budget; Data Version Actual; Measure IDs as DP-008 "
               "publishes them; USD 1 tolerance; business days 3 and 13. "
               "Decisions: CW-011, CW-142, CW-203, CW-206, CW-240, CW-241. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's eight "
               "objects plus the moved forecast reads, 06 Flow Measures, 10 Fee Revenue Record and Profitability objects and the "
               "DP-241 source attributes; upstream DP-014 and DP-245 dropped (no measure reads them), DP-497 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-503": dict(
        definition=("Charges between the firm's legal entities (parent, RIA, broker-dealer, fund adviser, transfer agent, "
                    "recordkeeper, trust company and service company) under each intercompany agreement and its transfer pricing "
                    "policy: the expected charge from the policy's method and remuneration rate applied to its basis (the DP-480 "
                    "allocated cost of the service or the DP-012 revenue shared), the charge booked in 10 and posted in 19, and the "
                    "test against the arm's length range. It supports IRC section 482 documentation, eliminations and legal-entity "
                    "profitability. It owns no certified metric family."),
        business_questions=[
            "Did each entity charge what its intercompany agreement and transfer pricing policy require this period?",
            "Which charges fall outside the arm's length range, and for which tested party?",
            "Are all intercompany charges booked in the ledger, settled and flagged for elimination?",
            "Which agreements lack contemporaneous transfer pricing documentation for the fiscal year?",
            "What does each legal entity earn and pay across its intercompany services?",
        ],
        grain=("Intercompany agreement x charge period (expected and booked charge, arm's length test) as the main output, with "
               "transfer pricing documentation (documented entity x fiscal year x type) and entity roll-ups as companion facts; "
               "closed periods final, agreement and policy history SCD type 2"),
        dimensions=["Intercompany agreement and service type", "Service provider and recipient entity (DP-013)", "Tested party", "TP method",
                    "Charge period and fiscal year (DP-013)", "Settlement status", "Entity distribution role", "TP documentation type",
                    "Cost center and GL account (DP-190)"],
        measures=[
            ("Booked Intercompany Charges",
             "Sum of Charge Amount of Intercompany Charges whose Charge Period is in the fiscal period, by Charging Agreement, Intercompany Service Type, Service Provider Entity and Service Recipient Entity.",
             _u("10", "Intercompany Charge", "Intercompany Charge ID", "Charging Agreement", "Charge Period", "Charge Amount")
             + _u("10", "Intercompany Agreement", "Intercompany Agreement ID", "Service Provider Entity", "Service Recipient Entity", "Intercompany Service Type")),
            ("Charge Basis",
             "The basis named by the TP Policy Remuneration Basis for the charge period: for cost-based methods (Services Cost Method, Cost of Services Plus Method) the Allocated Amount of Final DP-480 Allocation Results whose Target Dimension is Legal Entity and whose member is the Service Provider Entity, for the pools of the covered service; for revenue-based remuneration (Fee Sharing, Distribution Services) the Recognized Revenue Amount of DP-012 Client Revenue Records and Net Fee Revenue of Fee Revenue Records of the covered products recognized by the paying entity.",
             _u("10", "TP Policy", "TP Method", "Remuneration Basis")
             + _u("10", "Allocation Result", "Allocated Rule", "Target Dimension Member", "Allocated Amount")
             + _u("10", "Allocation Rule", "Allocation Rule ID", "Target Dimension")
             + _u("10", "Allocation Run", "Allocation Run ID", "Run Period", "Run Status")
             + _u("10", "Client Revenue Record", "Client Revenue Period", "Recognized Revenue Amount", "Recognizing Legal Entity")
             + _u("10", "Fee Revenue Record", "Revenue Share Class / Mandate", "Revenue Accounting Period", "Net Fee Revenue")
             + _u("10", "Intercompany Agreement", "Covered Products")),
            ("Expected Intercompany Charge",
             "Charge Basis x Remuneration Rate of the TP Policy in force for the charge period (cost plus the markup for cost-based methods, the revenue share for revenue-based remuneration).",
             _u("10", "TP Policy", "Remuneration Rate")
             + ["Charge Basis"]),
            ("Expected vs Booked Variance",
             "Booked Intercompany Charges - Expected Intercompany Charge per agreement and period, and as a percentage of the expected charge.",
             ["Booked Intercompany Charges", "Expected Intercompany Charge"]),
            ("Tested Party Return",
             "For cost-based methods: (Booked Intercompany Charges / Charge Basis - 1) x 100, the markup earned by the Tested Party; for other methods the return on the policy's basis; per agreement and fiscal year.",
             _u("10", "TP Policy", "Tested Party", "TP Method")
             + ["Booked Intercompany Charges", "Charge Basis"]),
            ("Arm's Length Flag",
             "Y when Tested Party Return for the fiscal year lies between the TP Policy Arm's Length Range Lower Bound and Arm's Length Range Upper Bound, N otherwise; per agreement and fiscal year.",
             _u("10", "TP Policy", "Arm's Length Range Lower Bound", "Arm's Length Range Upper Bound")
             + ["Tested Party Return"]),
            ("Charges Outside Arm's Length Range",
             "Count of agreements with Arm's Length Flag N for the fiscal year and the sum of their Booked Intercompany Charges, with the adjustment needed to reach the nearest bound.",
             ["Arm's Length Flag", "Booked Intercompany Charges", "Tested Party Return"]),
            ("Unsettled Intercompany Charges",
             "Sum of Charge Amount of charges with Settlement Status Pending or Invoiced more than 60 days after the end of the Charge Period, by entity pair.",
             _u("10", "Intercompany Charge", "Charge Period", "Charge Amount", "Settlement Status")),
            ("Charges Not Flagged for Elimination",
             "Count and Charge Amount of charges between two consolidated entities (both Internal Legal Entities with Entity Status Active) whose Elimination Indicator is not Y.",
             _u("10", "Intercompany Charge", "Intercompany Charge ID", "Charge Amount", "Elimination Indicator")
             + _u("09", "Internal Legal Entity", "Legal Entity ID", "Entity Category", "Entity Status")),
            ("Ledger Booking Tie-Out (from DP-191)",
             "Booked Intercompany Charges minus the Posted Amount of 19 GL Postings whose Source Finance Record is the charge and whose Intercompany Partner Entity is the counterparty entity, per charge, as DP-191 publishes the journals.",
             _u("19", "GL Posting", "Journal ID", "Journal Line Number", "Posted Account", "Posted Amount", "Source Finance Record", "Intercompany Partner Entity")
             + ["Booked Intercompany Charges"]),
            ("Agreements Without TP Documentation",
             "Count of agreements in force in the fiscal year (Agreement Effective From / To) that no Transfer Pricing Documentation with Contemporaneous Indicator Y lists in Covered Intercompany Agreements for that TP Documentation Fiscal Year, or whose TP Policy TP Documentation Reference is empty.",
             _u("10", "Intercompany Agreement", "Intercompany Agreement ID", "Agreement Effective From", "Agreement Effective To")
             + _u("10", "TP Policy", "TP Documentation Reference")
             + _u("19", "Transfer Pricing Documentation", "TP Documentation ID", "Documented Legal Entity", "TP Documentation Type", "TP Documentation Fiscal Year", "Covered Intercompany Agreements", "Contemporaneous Indicator")),
            ("Documented Transaction Value Coverage %",
             "Covered Transaction Value of the fiscal year's documentation / Booked Intercompany Charges of the covered agreements for the year x 100, by Documented Legal Entity.",
             _u("19", "Transfer Pricing Documentation", "Documented Legal Entity", "TP Documentation Fiscal Year", "Covered Transaction Value")
             + ["Booked Intercompany Charges"]),
            ("Distribution Services Charges",
             "Booked Intercompany Charges of agreements with Intercompany Service Type Distribution Services whose Service Provider Entity holds the 09 Entity Distribution Role of principal underwriter (Default Contracting Entity Indicator shown, Role Effective From in force).",
             _u("09", "Entity Distribution Role", "Role Entity", "Distribution Role", "Default Contracting Entity Indicator", "Role Effective From")
             + _u("10", "Intercompany Agreement", "Intercompany Service Type")
             + ["Booked Intercompany Charges"]),
            ("Net Intercompany Position by Entity",
             "For each Internal Legal Entity (Legal Name, Accounting Company Code): Booked Intercompany Charges as Service Provider Entity minus those as Service Recipient Entity for the fiscal period, beside its recognized client revenue from DP-012 (Recognizing Legal Entity).",
             _u("09", "Internal Legal Entity", "Legal Entity ID", "Legal Name", "Accounting Company Code")
             + _u("10", "Client Revenue Record", "Recognizing Legal Entity", "Recognized Revenue Amount")
             + ["Booked Intercompany Charges"]),
        ],
        inputs=[
            ("10", "Intercompany Agreement", ["Intercompany Agreement ID", "Service Provider Entity", "Service Recipient Entity", "Intercompany Service Type", "Covered Products", "Agreement Effective From", "Agreement Effective To"]),
            ("10", "TP Policy", ["TP Method", "Remuneration Basis", "Remuneration Rate", "Tested Party", "Arm's Length Range Lower Bound", "Arm's Length Range Upper Bound", "TP Documentation Reference"]),
            ("10", "Intercompany Charge", ["Intercompany Charge ID", "Charging Agreement", "Charge Period", "Charge Amount", "Settlement Status", "Elimination Indicator"]),
            ("10", "Allocation Run", ["Allocation Run ID", "Run Period", "Run Status"]),
            ("10", "Allocation Rule", ["Allocation Rule ID", "Target Dimension"]),
            ("10", "Allocation Result", ["Allocated Rule", "Target Dimension Member", "Allocated Amount"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Client Revenue Period", "Recognized Revenue Amount", "Recognizing Legal Entity"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period", "Net Fee Revenue"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category", "Entity Status", "Accounting Company Code"]),
            ("09", "Entity Distribution Role", ["Role Entity", "Distribution Role", "Default Contracting Entity Indicator", "Role Effective From"]),
            ("19", "Transfer Pricing Documentation", ["TP Documentation ID", "Documented Legal Entity", "TP Documentation Type", "TP Documentation Fiscal Year", "Covered Intercompany Agreements", "Covered Transaction Value", "Contemporaneous Indicator"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Posted Amount", "Source Finance Record", "Intercompany Partner Entity"]),
        ],
        upstream=['DP-480', 'DP-012', 'DP-191', 'DP-190', 'DP-518', 'DP-004', 'DP-013'],
        refresh="Monthly",
        timeliness="Business day 10 after month-end for expected and booked charges; the annual arm's length test and documentation coverage by 60 days after fiscal year-end",
        history="Monthly charges and tests kept 10 years; transfer pricing documentation and the annual tests kept for the IRS assessment period plus 3 years (IRC section 6662(e) documentation)",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Service Provider Entity, Service Recipient Entity, Tested Party, Role Entity and Documented Legal Entity resolves to an active DP-013 Internal Legal Entity, every Covered Products entry to DP-004 and every Posted Account to a DP-190 GL account.",
            "TP Policy periods of one agreement do not overlap and end on or after they start, Arm's Length Range Lower Bound is at or below Arm's Length Range Upper Bound, and every Charge Period falls inside its agreement's effective period.",
            "Ledger Booking Tie-Out (from DP-191) is within USD 1 per charge, and the Charge Basis drawn from DP-480 and DP-012 equals those products' published values for the run and period used.",
            "TP Method, Remuneration Basis, Remuneration Rate and Tested Party are populated on every TP Policy in force, and Charge Amount and Settlement Status on every Intercompany Charge.",
            "The 10 Allocation Result read runs only under the DP-518 restricted view 'DP-503 Member-Level Allocation Read' and only for Allocation Rules with Target Dimension Legal Entity; outputs are entity- and agreement-level, the 19 posting rows are read only to tie out, and Documentation Owner (an employee) is not read.",
            "A charge period is published once DP-191 hard-closes it and is then locked; a true-up is a new Intercompany Charge, never an edit of a booked one.",
        ],
        notes=("Certified numbers: none owned; reads recognized revenue from DP-012 and allocated cost from DP-480 as charge bases, "
               "and journals from DP-191 (CW-241). "
               "PII tier: none at publication. pii = N: the member-level 10 Allocation Result read (Target Dimension Member and Allocated "
               "Amount, PII - financial on household and account rows) is a restricted view registered in DP-518 as 'DP-503 Member-Level "
               "Allocation Read', limited to rows whose Target Dimension is Legal Entity; the 10 Client Revenue Record rows are summed by "
               "Recognizing Legal Entity; no household, account or employee row is published (DQ5). "
               "Boundaries: allocation is DP-480's; revenue recognition DP-012's; journals and eliminations DP-191's; legal entities "
               "DP-013's. Live DP-196 lists this product upstream and reads its Arm's Length Flag (Charges Outside Arm's Length Range), "
               "so the flag keeps that name and DP-196 is not listed here. Successor of DP-074 without the EU/UK distribution entities "
               "and VAT (CW-910, CW-240). "
               "Tailoring lever: trust company entity (TR line). Reference default: present, charging the RIA for trust services; "
               "lever: no trust entity. Tailoring lever: transfer pricing method per service (10 SME 8). Reference default: Services "
               "Cost Method or Cost of Services Plus for shared, technology and operations services, fee sharing for distribution "
               "services; IRC section 482 primary. "
               "Taxonomy gap: 10 TP Policy has no effective-period attributes in the catalog, so the policy in force is the group's "
               "version for the agreement. Taxonomy gap: 10 Intercompany Charge has no link to the allocation run or revenue records "
               "its basis came from. "
               "Drafting assumptions: TP Method and Intercompany Service Type values from the 10 code lists; Settlement Status values "
               "Pending and Invoiced; Distribution Role value principal underwriter; the 60-day settlement window; USD 1 tolerance; "
               "business day 10. "
               "Decisions: CW-156, CW-159, CW-240, CW-910. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's six "
               "objects plus the DP-480 allocation results, the DP-012 revenue records and 19 GL Posting for the basis and tie-out; "
               "upstream DP-190 and DP-004 added, and DP-518 (restricted-view register) in the fix pass."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-506": dict(
        definition=("The firm's advisory and wrap fees, commissions, account fees, cash sweep rates and own-fund expense ratios set "
                    "against competitor offerings (DP-481) and fee benchmark studies, by offering, balance tier and as-of date, with "
                    "the third-party ratings of own share classes. Own rates are read from their owners: 47 fee schedules through "
                    "DP-305, 01 fund fee terms through DP-004, net expense ratios from DP-165 and sweep client rates through DP-431; "
                    "benchmark statistics come from 11. Pricing and product governance see where the firm is above or below market. "
                    "It owns no certified metric family."),
        business_questions=[
            "Where is our advisory fee above or below the competitor median at each balance tier, by offering?",
            "Which own share classes have net expense ratios above their peer median, and by how much?",
            "How do our commissions, account fees and cash sweep rates compare with the primary competitors?",
            "Which offerings sit outside the recommended fee range of their latest benchmark study, and which studies are stale?",
            "How are our share classes rated, and which ratings changed this quarter?",
        ],
        grain=("Fee benchmark study (subject x comparison set x fee measure x study date) as the main output, with own rate x "
               "competitor observation comparisons (offering x price component x balance tier x as-of date) and own-fund rating "
               "observations as companion facts; history by study date and as-of date"),
        dimensions=["Own service offering and share class (DP-004)", "Own fee schedule and version (DP-305)", "Competitor and competitor offering (DP-481)",
                    "Price component and quote basis", "Balance tier", "Fee measure compared", "Peer universe (DP-014)",
                    "Rating scheme and rating time period", "Study date and observation as-of date (DP-013)"],
        measures=[
            ("Own Advisory Fee Rate at Balance",
             "Effective annual rate of the active 47 Fee Schedule version in force (Schedule Status Active, Version Effective From / To) at a reference balance: Tier Rate of the tier containing the balance (Tier Method Cliff) or the tier-weighted rate across Tier Lower Bound / Tier Upper Bound bands (Incremental), with Minimum Annual Fee applied; by Fee Schedule Type.",
             _u("47", "Fee Schedule", "Fee Schedule ID", "Fee Schedule Type", "Schedule Version Number", "Schedule Status", "Version Effective From", "Version Effective To", "Billing Basis", "Tier Method", "Minimum Annual Fee")
             + _u("47", "Fee Schedule Tier", "Tier Fee Schedule", "Tier Sequence", "Tier Lower Bound", "Tier Upper Bound", "Tier Rate")),
            ("Competitor Median Advisory Fee Rate (from DP-481)",
             "Median Observed Rate of the latest Competitor Pricing Observation (Observation As-of Date) with Price Component Advisory Fee Rate per competitor offering of Offering Status Active whose Comparable Own Offering is the own offering, at the Balance Tier Lower Bound at or below the reference balance; as DP-481 publishes it.",
             _u("11", "Competitor Pricing Observation", "Priced Offering", "Price Component", "Observation As-of Date", "Observed Rate", "Balance Tier Lower Bound")
             + _u("11", "Competitor Offering", "Competitor Offering ID", "Comparable Own Offering", "Offering Status")),
            ("Competitor Median Commission per Trade (from DP-481)",
             'Read: Competitor Median Commission per Trade as DP-481 publishes it (latest observations with Price Component Commission per Trade of active competitor offerings); never recomputed here.',
             _u("11", "Competitor Pricing Observation", "Price Component", "Observed Amount", "Price Quote Basis", "Observation As-of Date")),
            ("Competitor Median Cash Sweep Yield (from DP-481)",
             'Read: Competitor Median Cash Sweep Yield as DP-481 publishes it, by Balance Tier Lower Bound; never recomputed here.',
             _u("11", "Competitor Pricing Observation", "Price Component", "Observed Rate", "Balance Tier Lower Bound")),
            ("Peer Median Expense Ratio (from DP-014)",
             "Read: Peer Median Expense Ratio as DP-014 publishes it for the share class's peer universe at the latest Snapshot Date; never recomputed here.",
             _u("11", "Peer Metric Snapshot", "Snapshot Subject", "Snapshot Date", "Expense Ratio", "Peer Universe")),
            ("Advisory Fee Gap (bps)",
             "(Own Advisory Fee Rate at Balance - Competitor Median Advisory Fee Rate (from DP-481)) x 10,000 at each reference balance and offering.",
             ["Own Advisory Fee Rate at Balance", "Competitor Median Advisory Fee Rate (from DP-481)"]),
            ("Own Fee Percentile",
             "Own Fee Percentile and Own Fee Rate of each Fee Benchmark Result at its Reference Balance, by Subject Service Offering, Subject Share Class and Fee Measure Compared, latest Study Date.",
             _u("11", "Fee Benchmark Study", "Fee Study ID", "Subject Share Class", "Subject Service Offering", "Fee Measure Compared", "Study Date")
             + _u("11", "Fee Benchmark Result", "Own Fee Rate", "Reference Balance", "Own Fee Percentile")),
            ("Peer Fee Distribution",
             "Peer 25th Percentile Fee, Peer Median Fee and Peer 75th Percentile Fee of each Fee Benchmark Result, with the Peer Universe and Comparison Offerings of the study.",
             _u("11", "Fee Benchmark Study", "Fee Study ID", "Peer Universe", "Comparison Offerings", "Measure Unit")
             + _u("11", "Fee Benchmark Result", "Peer Median Fee", "Peer 25th Percentile Fee", "Peer 75th Percentile Fee")),
            ("Offerings Priced Above Peer 75th Percentile",
             "Count of subjects whose latest Own Fee Rate exceeds Peer 75th Percentile Fee, by Fee Measure Compared and Fee Competitiveness Assessment.",
             _u("11", "Fee Benchmark Result", "Own Fee Rate", "Peer 75th Percentile Fee", "Fee Competitiveness Assessment")
             + _u("11", "Fee Benchmark Study", "Fee Measure Compared")),
            ("Own Net Expense Ratio (from DP-165)",
             "Highlights Net Expense Ratio of the latest 27 Financial Highlights per own share class as DP-165 publishes it (Audited Gross and Net Expense Ratio), with the 01 Management Fee Rate and Other Ongoing Fees rates (Administration / Operating Fee Rate, Distribution (12b-1) Fee Rate, Shareholder Servicing Fee Rate) that make it up.",
             _u("27", "Financial Highlights", "Highlights Share Class", "Highlights Net Expense Ratio")
             + _u("01", "Management Fee", "Management Fee Rate")
             + _u("01", "Other Ongoing Fees", "Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate", "Shareholder Servicing Fee Rate")
             + _u("01", "Share Class", "Share Class ID", "Parent Product", "Share Class Status")),
            ("Expense Ratio Gap to Peer Median (bps)",
             '(Own Net Expense Ratio (from DP-165) - Peer Median Expense Ratio (from DP-014)) x 10,000, by share class.',
             ["Own Net Expense Ratio (from DP-165)", "Peer Median Expense Ratio (from DP-014)"]),
            ("Commission and Account Fee Comparison",
             "Own Tier Flat Amount of 47 Fee Schedules of Fee Schedule Type commission or account service against Competitor Median Commission per Trade (from DP-481), and against DP-481's Latest Observed Amount of observations with Price Component Account Service Fee or Options Contract Fee and the same Price Quote Basis.",
             _u("47", "Fee Schedule", "Fee Schedule ID", "Fee Schedule Type") + _u("47", "Fee Schedule Tier", "Tier Fee Schedule", "Tier Flat Amount") + _u("11", "Competitor Pricing Observation", "Price Component", "Observed Amount", "Price Quote Basis") + ["Competitor Median Commission per Trade (from DP-481)"]),
            ("Cash Sweep Rate Comparison",
             'Own Client Interest Rate of the 50 Sweep Rate Tier in force (Tier Effective From / To) per Tier Sweep Program and balance band (Tier Lower Bound, Tier Upper Bound), through DP-431, against Competitor Median Cash Sweep Yield (from DP-481) at the same balance tier.',
             _u("50", "Sweep Rate Tier", "Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Upper Bound", "Client Interest Rate", "Tier Effective From", "Tier Effective To") + ["Competitor Median Cash Sweep Yield (from DP-481)"]),
            ("Position in Recommended Fee Range",
             "For each study: Below, Within or Above according to Own Fee Rate against Recommended Fee Range Low and Recommended Fee Range High of its Pricing Input, with the Rationale.",
             _u("11", "Pricing Input", "Recommended Fee Range Low", "Recommended Fee Range High", "Rationale")
             + _u("11", "Fee Benchmark Result", "Own Fee Rate")),
            ("Stale Benchmark Studies",
             "Count of active own offerings and share classes whose latest Fee Benchmark Study Study Date is more than 12 months old, by Study Purpose.",
             _u("11", "Fee Benchmark Study", "Subject Share Class", "Subject Service Offering", "Study Date", "Study Purpose")
             + _u("01", "Service Offering", "Offering ID", "Offering Status")),
            ("Own Share Class Rating Distribution",
             "Count of own share classes by Rating Value of the latest Rating Observation per Rating Scheme and Rating Time Period, with Number of Funds Rated in Peer Group; rating schemes from 11 Rating Scheme (Rated Object Type share class).",
             _u("11", "Rating Scheme", "Rating Scheme Code", "Rated Object Type")
             + _u("11", "Rating Observation", "Rating Observation ID", "Rating Scheme", "Rated Share Class / Fund", "Rating Time Period", "Rating Value", "Rating Date", "Number of Funds Rated in Peer Group")),
            ("Rating Changes in Period",
             "Count of own share classes whose Rating Value under a Rating Scheme and Rating Time Period changed between the last two Rating Dates, split into upgrades and downgrades, with Rating Date in the period.",
             _u("11", "Rating Observation", "Rated Share Class / Fund", "Rating Scheme", "Rating Time Period", "Rating Value", "Rating Date")),
        ],
        inputs=[
            ("11", "Fee Benchmark Study", ["Fee Study ID", "Subject Share Class", "Subject Service Offering", "Subject Fee Schedule", "Peer Universe", "Comparison Offerings", "Fee Measure Compared", "Measure Unit", "Study Date", "Study Purpose"]),
            ("11", "Fee Benchmark Result", ["Own Fee Rate", "Reference Balance", "Peer Median Fee", "Peer 25th Percentile Fee", "Peer 75th Percentile Fee", "Own Fee Percentile", "Fee Competitiveness Assessment"]),
            ("11", "Pricing Input", ["Recommended Fee Range Low", "Recommended Fee Range High", "Rationale"]),
            ("11", "Competitor Pricing Observation", ["Priced Offering", "Price Component", "Observation As-of Date", "Observed Rate", "Observed Amount", "Price Quote Basis", "Balance Tier Lower Bound", "Price Source Type"]),
            ("11", "Competitor Offering", ["Competitor Offering ID", "Offering Competitor", "Competitor Offering Type", "Comparable Own Offering", "Offering Status"]),
            ("11", "Peer Metric Snapshot", ["Snapshot Subject", "Snapshot Date", "Expense Ratio", "Peer Universe"]),
            ("11", "Rating Scheme", ["Rating Scheme Code", "Rated Object Type"]),
            ("11", "Rating Observation", ["Rating Observation ID", "Rating Scheme", "Rated Share Class / Fund", "Rating Time Period", "Rating Value", "Rating Date", "Number of Funds Rated in Peer Group"]),
            ("47", "Fee Schedule", ["Fee Schedule ID", "Fee Schedule Type", "Schedule Version Number", "Schedule Status", "Version Effective From", "Version Effective To", "Billing Basis", "Tier Method", "Minimum Annual Fee"]),
            ("47", "Fee Schedule Tier", ["Tier Fee Schedule", "Tier Sequence", "Tier Lower Bound", "Tier Upper Bound", "Tier Rate", "Tier Flat Amount"]),
            ("50", "Sweep Rate Tier", ["Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Upper Bound", "Client Interest Rate", "Tier Effective From", "Tier Effective To"]),
            ("27", "Financial Highlights", ["Highlights Share Class", "Highlights Net Expense Ratio"]),
            ("01", "Management Fee", ["Management Fee Rate"]),
            ("01", "Other Ongoing Fees", ["Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate", "Shareholder Servicing Fee Rate"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("01", "Service Offering", ["Offering ID", "Offering Name", "Offering Type", "Offering Status"]),
        ],
        upstream=["DP-481", "DP-305", "DP-004", "DP-165", "DP-014", "DP-431", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end; competitor price changes refreshed weekly as DP-481 captures them",
        history="Studies and comparisons kept 7 years by study date and as-of date; rating observations kept 10 years (Marketing Rule substantiation support for any rating used in marketing)",
        classification="Confidential - Licensed",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Subject Share Class, Subject Service Offering, Comparable Own Offering and Rated Share Class / Fund resolves to DP-004, every Subject Fee Schedule to a DP-305 fee schedule, every Priced Offering and Offering Competitor to DP-481 and every Tier Sweep Program to DP-431.",
            "Fee Schedule versions of one schedule do not overlap (Version Effective From / To), Fee Schedule Tier bands of a version are contiguous by Tier Sequence, and Sweep Rate Tier periods of one program and band do not overlap.",
            "Own Net Expense Ratio (from DP-165) equals DP-165's published audited net expense ratio for the share class, Peer Median Expense Ratio (from DP-014) equals DP-014's published value, the three DP-481 medians equal DP-481's published medians for the same as-of date, and every Fee Benchmark Result has Peer 25th Percentile Fee at or below Peer Median Fee at or below Peer 75th Percentile Fee.",
            "Fee Measure Compared, Study Date and Own Fee Rate are populated on every study and result, and Price Component, Observation As-of Date and Observed Rate or Observed Amount on every competitor observation.",
            'Competitor Pricing Observations with Price Source Type Vendor Pricing Dataset are delivered only to entitled internal users through the warehouse, semantic model and dashboard and never in a file extract; no personal attribute is read.',
            "The monthly view uses only observations and studies dated on or before the last business day of the month, and a rating observation is shown only after its Rating Date.",
        ],
        notes=("Certified numbers: none owned; reads the audited net expense ratio from DP-165 and competitor medians from DP-481; "
               "fees are rates, not revenue (revenue is DP-012's). "
               "PII tier: none. pii = N: the validator's PII warnings are the lexical 'No PII' object-tier notes of the 11, 47 and 50 "
               "objects; no personal attribute is read. "
               "Boundaries: competitor offerings and price observations are DP-481's (master); fee schedules DP-305's; peer universes "
               "DP-014's; pricing scenarios are DP-497's (moved from backlog DP-500). Live DP-109, DP-183 and DP-236 read this "
               "product and INV DP-536 lists it upstream (for 11 Fee Benchmark Result Own Fee Percentile and Peer Median Fee, published here under the 11 names), so none of them is listed here. Takes the fee part of DP-030 (CW-240). WP1 "
               "scope: also reads 11 Rating Scheme and Rating Observation (from backlog DP-507, which folds in here if picked up); "
               "11 Award stays with DP-236 (CW-160 re-point note there). "
               "Tailoring lever: competitor set and price capture (11 SME 1 to 3). Reference default: public fee schedules, Form ADV "
               "Part 2A and Form CRS of primary and secondary competitors; lever: a licensed vendor pricing dataset. Tailoring lever: "
               "ratings used. Reference default: star and medalist schemes for own share classes only. "
               "Taxonomy gap: 11 Fee Benchmark Result has no own-rate source attribute, so whether Own Fee Rate came from 47 or 01 is "
               "inferred from the study subject (fee schedule or share class). Taxonomy gap: 11 Pricing Input has no effective date. "
               "Drafting assumptions: Price Component values from the 11 list; Schedule Status Active; Tier Method values Cliff and "
               "Incremental; the 12-month staleness window; business day 5. "
               "Decisions: CW-158, CW-160, CW-240. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's six "
               "objects plus the moved rating reads, 11 Fee Benchmark Result and Pricing Input, Competitor Offering, Peer Metric "
               "Snapshot, 47 Fee Schedule Tier, 50 Sweep Rate Tier, 27 Financial Highlights and the 01 keys; upstream DP-165, DP-014 "
               "and DP-431 added. Fix pass: DP-481's and DP-014's medians are read under their own names ('Competitor Median Commission "
               "per Trade (from DP-481)', 'Competitor Median Cash Sweep Yield (from DP-481)', 'Peer Median Expense Ratio (from DP-014)', "
               "added), never recomputed."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-510": dict(
        definition=("Per OCIO, institutional separate account, pooled and plan sponsor service relationship: requests against "
                    "service standards, reviews held to the tier's cadence, guideline breach notifications and compliance "
                    "certificates, survey results, health score, billing disputes (from DP-305) and terminations, beside the "
                    "relationship's client assets (DP-007 attribution to the 12 Institutional Client, institutional channel totals "
                    "from DP-008). It also carries mandate onboarding, cash flow notice controls, client custodian set-ups and "
                    "client data feeds. Client service acts on at-risk relationships before they terminate. It owns no certified "
                    "metric family."),
        business_questions=[
            "Which institutional and OCIO relationships are at risk, and how much client assets do they hold?",
            "Are we meeting request service standards and holding reviews to each tier's cadence?",
            "Were guideline breaches notified to clients within the deadline, and are compliance certificates current?",
            "Which mandates gave termination notice this quarter and why?",
            "Are new mandates funding on the target date, and are client cash flow notices received on time and verified by call-back?",
        ],
        grain=("Service relationship x month-end (relationship health) as the main output, with service requests, reviews, health "
               "scores, breach notifications, compliance certificates, terminations, onboardings, cash flow notifications, survey "
               "responses and billing disputes as companion facts; monthly snapshots, events kept at their own grain"),
        dimensions=["Institutional client and type (DP-003)", "Service relationship and servicing segment (DP-003)", "Institutional service tier",
                    "Service team and service employee (DP-192)", "Mandate (DP-004)", "Advising consultant (DP-003)", "OCIO delegation scope and ERISA fiduciary status",
                    "External manager in scope (DP-306)", "Request type and status", "Review type", "Termination reason", "Onboarding checklist status", "Month-end (DP-013)"],
        measures=[
            ("Active Relationships by Segment",
             "Count of Service Relationships with Service Relationship Status Active or Under Notice by Servicing Segment, Service Tier and Relationship Business Line at the month-end.",
             _u("12", "Service Relationship", "Service Relationship ID", "Client", "Servicing Segment", "Relationship Business Line", "Service Tier", "Relationship Start Date", "Service Relationship Status")),
            ("Relationship Client Assets",
             "Sum of Attributed Amount of DP-007 attribution records whose Source Account Asset Summary has Summary As-Of Date = month-end and whose Institutional Client is the relationship's Client: the client assets of the relationship, analytical, not certified.",
             _u("06", "Attribution Record", "Source Account Asset Summary", "Attributed Amount")
             + _u("06", "Market & Client Dimensions", "Institutional Client")
             + _u("06", "Account Asset Summary", "Summary As-Of Date")),
            ("Institutional Client Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-CLIENTASSETS at Dimension Type Channel for the Institutional sub-channels (Direct, Consultant-Led, OCIO) at the month-end, locked snapshot; Relationship Client Assets summed over relationships must not exceed it.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Requests Within Service Standard %",
             "Client Service Requests with Request Status Resolved or Closed in the period whose resolution came before Request SLA Due Timestamp / all resolved in the period x 100, by Request Type and Service Tier; the SLA comes from the Service Standard of metric Request Resolution Time in force for the tier or relationship.",
             _u("12", "Client Service Request", "Service Request ID", "Request Type", "Request Service Relationship", "Request Received Timestamp", "Request Status", "Request SLA Due Timestamp", "Resolution Code")
             + _u("12", "Service Standard", "Service Standard ID", "Service Standard Metric", "Target Value", "Target Unit", "Applies To Tier / Relationship", "Standard Effective From")),
            ("Open Requests Past Service Standard",
             "Count of Client Service Requests not Resolved, Closed or Canceled whose Request SLA Due Timestamp is before the as-of timestamp, by relationship, with those linked to a Related Complaint.",
             _u("12", "Client Service Request", "Service Request ID", "Request Status", "Request SLA Due Timestamp", "Related Complaint")),
            ("Reviews Held to Cadence %",
             "Active relationships with a Client Review (Review Held Date) within the Standard Review Meeting Cadence of their Institutional Service Tier before the month-end / active relationships x 100, by Review Type.",
             _u("12", "Client Review", "Client Review ID", "Review Type", "Reviewed Relationship", "Review Held Date", "Review Outcome")
             + _u("12", "Institutional Service Tier", "Service Tier Code", "Standard Review Meeting Cadence")
             + ["Active Relationships by Segment"]),
            ("At-Risk Relationships",
             "Count of relationships whose latest Relationship Health Score (Health Score Date) has At-Risk Indicator Y, by At-Risk Reason, with their Relationship Client Assets; the score is 12's published score, shown as published.",
             _u("12", "Relationship Health Score", "Health Score Date", "Scored Relationship", "Health Status", "At-Risk Indicator", "At-Risk Reason")
             + ["Relationship Client Assets"]),
            ("Average Health Score",
             "Client-assets-weighted mean of Overall Health Score of the latest score per relationship, by Servicing Segment and Service Tier.",
             _u("12", "Relationship Health Score", "Health Score Date", "Scored Relationship", "Overall Health Score")
             + ["Relationship Client Assets"]),
            ("Breach Notifications Late",
             "Count of Breach Notifications with Client Notification Required Indicator Y whose Client Notified Timestamp is later than Breach Detected Date plus the Breach Notification Deadline of the mandate's Guideline Monitoring Arrangement, or still empty past the deadline; consultant notifications required counted.",
             _u("12", "Breach Notification", "Breach Notification ID", "Breached Mandate", "Breach Detected Date", "Client Notification Required Indicator", "Client Notified Timestamp")
             + _u("12", "Guideline Monitoring Arrangement", "Monitored Mandate", "Breach Notification Deadline", "Consultant Notification Required Indicator")),
            ("Compliance Certificates Overdue",
             "Count of monitored mandates whose latest Compliance Certificate Certificate Period End is older than their Compliance Certificate Frequency allows at the month-end, and certificates with Exceptions Reported Indicator Y in the period.",
             _u("12", "Compliance Certificate", "Certified Mandate", "Certificate Period End", "Exceptions Reported Indicator")
             + _u("12", "Guideline Monitoring Arrangement", "Monitored Mandate", "Compliance Certificate Frequency")),
            ("Institutional Net Promoter Score",
             "Percentage of 04 Survey Responses with NPS Category Promoter minus percentage Detractor, Response Timestamp in the trailing 12 months, of respondents who are contacts of the relationship's Client, by Servicing Segment; mean Response Score shown; respondents never shown.",
             _u("04", "Survey Response", "Response ID", "Respondent Party", "Response Timestamp", "Response Score", "NPS Category")),
            ("Open Billing Disputes (from DP-305)",
             "Count and Disputed Amount of 47 Billing Disputes with Dispute Status Open on the relationship's invoices by Dispute Reason, as DP-305 publishes Open Billing Disputes.",
             _u("47", "Billing Dispute", "Billing Dispute ID", "Disputed Invoice", "Dispute Reason", "Disputed Amount", "Dispute Status")),
            ("Termination Notices",
             "Count of Mandate Terminations with Notice Received Date in the period by Termination Reason and Termination Scope, with the Relationship Client Assets of the terminated mandates and the Effective Termination Date.",
             _u("12", "Mandate Termination", "Termination ID", "Terminated Mandate", "Termination Scope", "Notice Received Date", "Termination Reason", "Effective Termination Date")
             + ["Relationship Client Assets"]),
            ("Mandates Funded On Target %",
             "Mandate Onboardings with Actual Funding Date in the period on or before Target Funding Date / onboardings funded in the period x 100; open onboardings by Onboarding Checklist Status and days since Onboarding Start Date.",
             _u("12", "Mandate Onboarding", "Onboarded Mandate", "Onboarding Start Date", "Onboarding Service Relationship", "Target Funding Date", "Actual Funding Date", "Onboarding Checklist Status")),
            ("Cash Flow Notices Outside Controls",
             "Count and Notified Amount of Cash Flow Notifications with Requested Value Date in the period whose Notice Period Met Indicator is N against the mandate's Cash Flow Arrangement Notice Period Days, or whose Call-Back Verification Performed is N, by Flow Direction.",
             _u("12", "Cash Flow Notification", "Cash Flow Notification ID", "Notified Mandate", "Flow Direction", "Notified Amount", "Requested Value Date", "Notice Period Met Indicator", "Call-Back Verification Performed")
             + _u("12", "Cash Flow Arrangement", "Arrangement Mandate", "Notice Period Days", "Notification Cut-Off Time")),
            ("Custodian Set-Ups Without Standing Instructions",
             "Count of Client Custodian Account set-ups (Client Custodian Account Set-Up ID) for active mandates with no Created Standing Settlement Instructions, by Custodian.",
             _u("12", "Client Custodian Account", "Client Custodian Account Set-Up ID", "Client Account", "Client Custodian Mandate", "Custodian", "Created Standing Settlement Instructions")),
            ("Client Data Feeds Without Data-Sharing Agreement",
             "Count of Client Data Feeds by Feed Content Type and Feed Frequency whose Data-Sharing Agreement is empty.",
             _u("12", "Client Data Feed", "Client Data Feed ID", "Feed Recipient", "Feed Content Type", "Feed Frequency", "Data-Sharing Agreement")),
            ("OCIO Relationships by Delegation",
             "Count of OCIO relationships and their Relationship Client Assets by OCIO Delegation Scope and ERISA Fiduciary Status, with Delegated Asset Share, Total Portfolio Indicator, the Governing IPS and the count of external managers in scope (Managers in Scope, DP-306).",
             _u("12", "OCIO Service Detail", "OCIO Delegation Scope", "ERISA Fiduciary Status", "OCIO Service Offering", "Total Portfolio Indicator", "Delegated Asset Share", "Managers in Scope", "Governing IPS")
             + ["Relationship Client Assets"]),
            ("Relationships Without Primary Contact",
             "Count of active relationships with no Service Coverage Assignment of Primary Contact Indicator Y in force at the month-end (Assignment Effective From / To), by Service Team.",
             _u("12", "Service Coverage Assignment", "Service Assignment ID", "Assigned Service Employee", "Service Role", "Covered Service Relationship", "Primary Contact Indicator", "Service Team", "Assignment Effective From", "Assignment Effective To")
             + _u("12", "Service Team", "Service Team ID", "Service Team Name")
             + ["Active Relationships by Segment"]),
            ("Institutional Clients Without Current Profile",
             "Count of Institutional Clients with an active relationship whose Assets As-Of Date is more than 12 months old, by Institutional Client Type and Primary Business Line, with their Total Investable Assets as last reported.",
             _u("12", "Institutional Client", "Institutional Client Party", "Institutional Client Type", "Primary Business Line", "Total Investable Assets", "Assets As-Of Date")),
        ],
        inputs=[
            ("12", "Institutional Client", ["Institutional Client Party", "Institutional Client Type", "Primary Business Line", "Total Investable Assets", "Assets As-Of Date"]),
            ("12", "Service Relationship", ["Service Relationship ID", "Client", "Servicing Segment", "Relationship Business Line", "Serviced Mandates", "Advising Consultant", "Service Tier", "Relationship Start Date", "Service Relationship Status"]),
            ("12", "Institutional Service Tier", ["Service Tier Code", "Standard Review Meeting Cadence", "Standard Reporting Frequency"]),
            ("12", "Service Standard", ["Service Standard ID", "Service Standard Metric", "Target Value", "Target Unit", "Contractual Indicator", "Applies To Tier / Relationship", "Standard Effective From"]),
            ("12", "Service Team", ["Service Team ID", "Service Team Name", "Service Team Lead"]),
            ("12", "Service Coverage Assignment", ["Service Assignment ID", "Assigned Service Employee", "Service Role", "Covered Service Relationship", "Primary Contact Indicator", "Service Team", "Assignment Effective From", "Assignment Effective To"]),
            ("12", "Client Service Request", ["Service Request ID", "Request Type", "Request Service Relationship", "Request Received Timestamp", "Request Status", "Request SLA Due Timestamp", "Resolution Code", "Related Complaint"]),
            ("12", "Client Review", ["Client Review ID", "Review Type", "Reviewed Relationship", "Review Held Date", "Review Outcome"]),
            ("12", "Relationship Health Score", ["Health Score Date", "Scored Relationship", "Overall Health Score", "Health Status", "At-Risk Indicator", "At-Risk Reason"]),
            ("12", "Guideline Monitoring Arrangement", ["Monitored Mandate", "Breach Notification Deadline", "Consultant Notification Required Indicator", "Compliance Certificate Frequency"]),
            ("12", "Breach Notification", ["Breach Notification ID", "Breached Mandate", "Breach Detected Date", "Client Notification Required Indicator", "Client Notified Timestamp"]),
            ("12", "Compliance Certificate", ["Certified Mandate", "Certificate Period End", "Exceptions Reported Indicator"]),
            ("12", "Mandate Termination", ["Termination ID", "Terminated Mandate", "Termination Scope", "Notice Received Date", "Termination Reason", "Effective Termination Date"]),
            ("12", "OCIO Service Detail", ["OCIO Delegation Scope", "ERISA Fiduciary Status", "OCIO Service Offering", "Total Portfolio Indicator", "Delegated Asset Share", "Managers in Scope", "Governing IPS"]),
            ("12", "Mandate Onboarding", ["Onboarded Mandate", "Onboarding Start Date", "Onboarding Service Relationship", "Target Funding Date", "Actual Funding Date", "Onboarding Checklist Status"]),
            ("12", "Cash Flow Notification", ["Cash Flow Notification ID", "Notified Mandate", "Flow Direction", "Notified Amount", "Requested Value Date", "Notice Period Met Indicator", "Call-Back Verification Performed"]),
            ("12", "Cash Flow Arrangement", ["Arrangement Mandate", "Notice Period Days", "Notification Cut-Off Time"]),
            ("12", "Client Custodian Account", ["Client Custodian Account Set-Up ID", "Client Account", "Client Custodian Mandate", "Custodian", "Created Standing Settlement Instructions"]),
            ("12", "Client Data Feed", ["Client Data Feed ID", "Feed Recipient", "Feed Content Type", "Feed Frequency", "Data-Sharing Agreement"]),
            ("04", "Survey Response", ["Response ID", "Respondent Party", "Response Timestamp", "Response Score", "NPS Category"]),
            ("47", "Billing Dispute", ["Billing Dispute ID", "Disputed Invoice", "Dispute Reason", "Disputed Amount", "Dispute Status"]),
            ("06", "Attribution Record", ["Source Account Asset Summary", "Attributed Amount"]),
            ("06", "Market & Client Dimensions", ['Institutional Client', 'Distribution Channel']),
            ("06", "Account Asset Summary", ["Summary As-Of Date"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
        ],
        upstream=["DP-003", "DP-008", "DP-007", "DP-305", "DP-306", "DP-192", "DP-093", "DP-004", "DP-005", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 9 after month-end for the relationship snapshot; requests, breach notifications, onboardings and cash flow notices refreshed daily by 7am ET",
        history="Monthly relationship snapshots kept 10 years; requests, reviews, breach notifications, certificates, terminations and cash flow notices kept 6 years after the relationship ends (Rule 204-2 and ERISA record support)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Client and Institutional Client Party resolves to a DP-003 institutional client, every Advising Consultant to DP-003, every mandate to DP-004, every Assigned Service Employee and Service Team Lead to an active DP-192 employee, every Client Account to DP-093 and every Managers in Scope entry to DP-306.",
            "Service Coverage Assignment periods of one employee, relationship and Service Role do not overlap and end on or after they start, and one Primary Contact Indicator Y is in force per relationship at a time.",
            "Relationship Client Assets summed over relationships equals Institutional Client Assets (from DP-008) plus the Attributed Amount of institutional-client attribution rows (Institutional Client populated) whose Distribution Channel is not an Institutional sub-channel, minus the institutional-channel Client Assets of accounts with no Institutional Client, within 0.5%; and Institutional Client Assets equals DP-008's locked value within USD 1.",
            "Service Relationship Status and Servicing Segment are populated on every relationship, Request SLA Due Timestamp on every request, Client Notification Required Indicator on every breach notification and Actual Funding Date on every funded onboarding.",
            'Service employees are published by DP-192 key and name to institutional service management only; survey respondents, authorized signatories and report recipients are not published, and survey results are shown only for groups of 10 or more responses.',
            "The month-end snapshot is built from data as of the last business day of the month and locked; daily event views carry their own timestamps, and a corrected health score creates a new score row.",
        ],
        notes=("Certified numbers: reads institutional channel Ending Client Assets from DP-008; owns none. Relationship Client Assets "
               "is an analytical cut of DP-007 attribution records by 12 Institutional Client and is never certified (CW-241). "
               "Overall Health Score is 12's published score, shown as published. "
               "PII tier: identity (service employees; individual survey respondents and signatories are read only to aggregate or not "
               "at all, DQ5). "
               "Boundaries: institutions, consultants, plans and service relationships are DP-003's (master); billing disputes are "
               "DP-305's facts and fee invoicing CLA-A DP-350's (CW-246); surveys are 04's (CW-093); external managers are DP-306's "
               "and sub-adviser oversight INV DP-536's; reporting delivery is DP-511's; plan sponsor servicing DP-514's; the cross-line "
               "relationship view DP-243 reads this product. Successor of DP-042 without MiFID depreciation notices (CW-145, CW-240) "
               "and of the institutional slice of DP-092 (CW-220 disposition). WP1 scope: also reads 12 OCIO Service Detail (from "
               "backlog DP-512 and DP-540) and 12 Cash Flow Notification, Mandate Onboarding, Client Custodian Account, Cash Flow "
               "Arrangement and Client Data Feed (from backlog DP-513), which fold in here if those products are picked up. "
               "Tailoring lever: OCIO offered (12 SME 1). Reference default: offered; lever: drop the OCIO measures and segment. "
               "Tailoring lever: health score method. Reference default: 12's score from service, survey and asset signals; this "
               "product never rescores. "
               "Taxonomy gap: 06 Market & Client Dimensions Institutional Client is the only client key on attributed assets, so "
               "retail and intermediary-held assets of an institution's group are not in Relationship Client Assets (DP-243 note). "
               "Taxonomy gap: 04 Survey Response has no link to the 12 service relationship; respondents are matched to the client "
               "through 02 party relationships. "
               "Drafting assumptions: Service Relationship Status values Active and Under Notice; Request Status values; Service "
               "Standard Metric Request Resolution Time; NPS Category values Promoter and Detractor; the 10-response minimum; the trailing 12-month "
               "NPS window; the 12-month profile window; business day 9 and 7am ET. "
               "Decisions: CW-093, CW-133, CW-145, CW-146, CW-147, CW-220, CW-240, CW-246. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's fifteen "
               "objects plus the six moved 12 reads and the 06 attribution and certified-read attributes; upstream DP-007, DP-306, "
               "DP-093, DP-004 and DP-005 added. Fix pass: "
               "Overall Health Score is a rules-based composite stored by client service in 12 and shown as published, not computed by a "
               "scoring model here, so CD-294 applies to its producer and DP-212 is not listed; the survey minimum is 10 responses."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-511": dict(
        definition=("The timeliness, completeness and restatement of every institutional, OCIO and plan sponsor report run against "
                    "its schedule and service standard, the delivery of each run to every recipient on the package's distribution "
                    "list, and the presentation, holdings disclosure and GIPS provisions behind it, checked against the "
                    "performance period close of DP-145. Reporting commitments stay visible and misconfigured reports are caught "
                    "before they go out. It owns no certified metric family."),
        business_questions=[
            "Which client reports due this period were delivered late or not at all, and to which recipients did delivery fail?",
            "How many reports were restated, why, and were they signed off and compliance-reviewed before delivery?",
            "Were any reports produced before the period's returns were final?",
            "Which presentation profiles, GIPS provisions or holdings disclosure settings are incomplete or out of date?",
            "Are post-transition reports delivered after every completed transition?",
        ],
        grain=("Report run (report package or definition x reporting period end x version) as the main output, with report deliveries "
               "(run x recipient), presentation profiles, GIPS provisions and transition events as companion facts; every version "
               "kept"),
        dimensions=["Institutional client and package (DP-003)", "Report definition, type and scope level", "Report template and output format",
                    "Mandate or vehicle covered (DP-004)", "Retirement plan covered (DP-003)", "Reporting period end (DP-013)", "Production status",
                    "Delivery channel and status", "Return methodology and fee basis shown", "GIPS composite (DP-004)", "Signed-off by (DP-192)",
                    "Transition type"],
        measures=[
            ("Report Runs Due",
             "Count of report runs expected for the period: each active Report Package (Package Effective From) by Package Frequency and its Included Report Definitions, at each Reporting Period End in the period.",
             _u("12", "Report Package", "Report Package ID", "Package Client", "Included Report Definitions", "Package Frequency", "Package Effective From")),
            ("Reports Delivered On Time %",
             "Report Runs whose every Report Delivery has Delivered Timestamp on or before Reporting Period End plus the Delivery Due Offset of the Report Schedule (Business Calendar business days) / Report Runs Due x 100, by Report Type and client; SLA Met Indicator shown.",
             _u("12", "Report Run", "Report Run ID", "Run Package / Report", "Reporting Period End", "SLA Met Indicator")
             + _u("12", "Report Schedule", "Scheduled Package / Report", "Delivery Due Offset", "Business Calendar")
             + _u("12", "Report Delivery", "Delivered Run", "Delivered Timestamp")
             + _u("12", "Report Definition", "Report Definition ID", "Report Type")
             + ["Report Runs Due"]),
            ("Runs Late or Missing",
             "Report Runs Due with no Report Run of Production Status Delivered by the due date, by Production Status reached (Data Pending, In Production, In Review, Signed Off).",
             _u("12", "Report Run", "Run Package / Report", "Reporting Period End", "Production Status")
             + ["Report Runs Due"]),
            ("Delivery Completeness %",
             "Report Deliveries with Delivery Status Delivered or Opened / recipients on the package's Distribution List (Distribution Package) for the run x 100, by Delivery Channel.",
             _u("12", "Report Delivery", "Delivered Run", "Delivery Recipient", "Delivery Status")
             + _u("12", "Distribution List", "Distribution List ID", "Distribution Package", "Recipient", "Delivery Channel")),
            ("Failed or Recalled Deliveries",
             "Count of Report Deliveries with Delivery Status Failed or Recalled in the period, by Delivery Channel and Report Type.",
             _u("12", "Report Delivery", "Delivered Run", "Delivery Status", "Delivered Timestamp")
             + _u("12", "Distribution List", "Delivery Channel")),
            ("Restated Reports",
             "Count of Report Runs with Restatement Indicator Y and Version Number above 1 in the period by Restatement Reason, and as a share of runs delivered (the Report Accuracy standard).",
             _u("12", "Report Run", "Report Run ID", "Version Number", "Restatement Indicator", "Restatement Reason", "Production Status")),
            ("Runs Delivered Without Sign-Off or Review",
             "Count of delivered Report Runs with no Signed Off By or a Sign-Off Timestamp after the first Delivered Timestamp, and of runs of definitions with a Regulatory Driver or performance content that have no Compliance Review.",
             _u("12", "Report Run", "Report Run ID", "Signed Off By", "Sign-Off Timestamp", "Compliance Review")
             + _u("12", "Report Definition", "Regulatory Driver")
             + _u("12", "Report Delivery", "Delivered Timestamp")),
            ("Reports Produced Before Performance Close (from DP-145)",
             "Count of Report Runs whose Data Cut-Off Timestamp is before the Final Release Timestamp of the 32 Performance Period Close (Close Period End Date = Reporting Period End, Period Close Status Final) of the close group, or that show a 32 Performance Return whose Return Status is not Final, as DP-145 publishes the close.",
             _u("12", "Report Run", "Report Run ID", "Reporting Period End", "Data Cut-Off Timestamp")
             + _u("32", "Performance Period Close", "Close Group", "Close Period End Date", "Period Close Status", "Final Release Timestamp")
             + _u("32", "Performance Return", "Performance Return ID", "Return Period End Date", "Return Status")),
            ("Incomplete Presentation Profiles",
             "Count of Presentation Profiles in use (Applies To Package / Mandate of an active package) with Return Methodology Shown, Fee Basis Shown, Reporting Currency or Primary Benchmark Shown empty, or with net returns shown (Fee Basis Shown Net) and no Net Return Fee Treatment.",
             _u("12", "Presentation Profile", "Presentation Profile ID", "Applies To Package / Mandate", "Return Methodology Shown", "Fee Basis Shown", "Reporting Currency", "Primary Benchmark Shown", "Performance Start Date Shown", "Net Return Fee Treatment")),
            ("Holdings Disclosure Settings Outside Policy",
             "Count of presentation profiles whose Portfolio Holdings Disclosure Lag Days is below the firm minimum for the package's vehicles, or that show look-through (Look-Through Indicator Y) for a Portfolio Holdings Detail Level the template does not support.",
             _u("12", "Portfolio Holdings Presentation", "Portfolio Holdings Detail Level", "Look-Through Indicator", "Portfolio Holdings Disclosure Lag Days")),
            ("GIPS Reports Not Current",
             "Count of GIPS Report Provisions with GIPS Report Required Indicator Y whose GIPS Report As-Of Date is more than 12 months before the period end, by GIPS Report Type and Related GIPS Composite.",
             _u("12", "GIPS Report Provision", "Related GIPS Composite", "GIPS Report Type", "GIPS Report Required Indicator", "GIPS Report As-Of Date")),
            ("Packages Without Recipients",
             "Count of active Report Packages with no Distribution List entry, or whose only recipients had every delivery Failed in the last two runs.",
             _u("12", "Report Package", "Report Package ID", "Package Effective From")
             + _u("12", "Distribution List", "Distribution Package", "Recipient")
             + _u("12", "Report Delivery", "Delivery Status")),
            ("Bespoke Report Share %",
             "Report Runs of definitions with Standard / Bespoke Indicator Bespoke or a Report Template with Co-Branding / White-Label Type set / all runs x 100, by Report Scope Level and Output Format: the production load the standard catalog does not cover.",
             _u("12", "Report Definition", "Report Definition ID", "Report Scope Level", "Standard / Bespoke Indicator", "Report Template")
             + _u("12", "Report Template", "Template ID", "Output Format", "Co-Branding / White-Label Type")
             + _u("12", "Report Run", "Report Run ID")),
            ("Commentary Missing on Delivered Runs",
             "Count of delivered runs of definitions with a Report Component of Commentary Required Indicator Y (or Mandatory Component Indicator Y of Component Type commentary) whose Commentary Used is empty.",
             _u("12", "Report Component", "Component ID", "Component Type", "Commentary Required Indicator", "Mandatory Component Indicator")
             + _u("12", "Report Run", "Report Run ID", "Commentary Used", "Production Status")),
            ("Post-Transition Reports Outstanding",
             "Count of Transition Events with Actual Completion Date more than 30 days before the as-of date whose Post-Transition Report Delivered Indicator is not Y, by Transition Type.",
             _u("12", "Transition Event", "Transition ID", "Transition Type", "Transition Mandate", "Actual Completion Date", "Post-Transition Report Delivered Indicator")),
        ],
        inputs=[
            ("12", "Report Definition", ["Report Definition ID", "Report Name", "Report Type", "Report Scope Level", "Standard / Bespoke Indicator", "Regulatory Driver", "Report Template"]),
            ("12", "Report Component", ["Component ID", "Component Type", "Commentary Required Indicator", "Mandatory Component Indicator"]),
            ("12", "Report Template", ["Template ID", "Template Name", "Output Format", "Co-Branding / White-Label Type"]),
            ("12", "Report Package", ["Report Package ID", "Package Client", "Included Report Definitions", "Covered Mandates / Vehicles", "Covered Retirement Plans", "Package Frequency", "Package Effective From"]),
            ("12", "Presentation Profile", ["Presentation Profile ID", "Applies To Package / Mandate", "Return Methodology Shown", "Fee Basis Shown", "Reporting Currency", "Primary Benchmark Shown", "Performance Start Date Shown", "Net Return Fee Treatment"]),
            ("12", "Portfolio Holdings Presentation", ["Portfolio Holdings Detail Level", "Look-Through Indicator", "Portfolio Holdings Disclosure Lag Days"]),
            ("12", "GIPS Report Provision", ["Related GIPS Composite", "GIPS Report Type", "GIPS Report Required Indicator", "GIPS Report As-Of Date"]),
            ("12", "Report Schedule", ["Scheduled Package / Report", "Data Cut-Off Offset", "Delivery Due Offset", "Business Calendar"]),
            ("12", "Report Run", ["Report Run ID", "Run Package / Report", "Reporting Period End", "Data Cut-Off Timestamp", "Production Status", "Signed Off By", "Sign-Off Timestamp", "Version Number", "Restatement Indicator", "Restatement Reason", "Compliance Review", "Commentary Used", "SLA Met Indicator"]),
            ("12", "Distribution List", ["Distribution List ID", "Distribution Package", "Recipient", "Delivery Channel"]),
            ("12", "Report Delivery", ["Delivered Run", "Delivery Recipient", "Delivery Status", "Delivered Timestamp"]),
            ("12", "Transition Event", ["Transition ID", "Transition Type", "Transition Mandate", "Actual Completion Date", "Post-Transition Report Delivered Indicator"]),
            ("32", "Performance Period Close", ["Close Group", "Close Period End Date", "Period Close Status", "Final Release Timestamp"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Period End Date", "Return Status"]),
        ],
        upstream=["DP-003", "DP-145", "DP-004", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET daily for runs and deliveries of the prior business day; the monthly service view by business day 15 after month-end, after quarterly reports are due",
        history="Every report run version and delivery kept 6 years after the relationship ends (Rule 204-2 client communications; GIPS record keeping); presentation and GIPS provision history SCD type 2",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Package Client resolves to a DP-003 institutional client, every Covered Mandates / Vehicles entry and Related GIPS Composite to DP-004, every Covered Retirement Plans entry to DP-003, every Signed Off By to a DP-192 employee and every Delivered Run to a Report Run.",
            "A report package has one Report Schedule in force, one Presentation Profile per package or mandate at a time, and Report Run versions of one package and period end are numbered without gaps.",
            "Every Report Run with Production Status Delivered has at least one Report Delivery, and Delivery Completeness % uses the Distribution List in force on the delivery date; SLA Met Indicator agrees with the computed due date in every run.",
            "Reporting Period End, Production Status and Version Number are populated on every run, and Delivery Status and Delivered Timestamp on every delivery.",
            "Recipients and Delivery Contact Points are published only to client reporting operations, by recipient key; Signed Off By is shown by DP-192 key and name to reporting management; no client account data is read.",
            "The daily view includes runs and deliveries up to 11:59pm ET of the prior business day; a restated run is a new Report Run version and the delivered version is never changed.",
        ],
        notes=("Certified numbers: none owned or read; the returns shown in reports are DP-145's and only their close status is read "
               "here. "
               "PII tier: identity (report recipients at institutional clients and sign-off employees). "
               "Boundaries: report packages, definitions and runs are mastered in 12; the performance shown is DP-145's; relationship "
               "health is DP-510's; plan sponsor reports DP-514's. Successor of DP-068 without the ILPA, CTI and MiFID templates "
               "(CW-912, CW-240). The cross-line relationship view DP-243 reads Reports Delivered On Time % from here. "
               "Tailoring lever: OCIO offered (12 SME 1). Reference default: offered, with OCIO Total Portfolio Reports; lever: drop "
               "the OCIO report types. Tailoring lever: holdings disclosure lag. Reference default: 15 days after month-end for "
               "mutual fund holdings shown to institutional clients. "
               "Taxonomy gap: 12 Report Schedule names Delivery Due Offset but no unit; business days under the Business Calendar are "
               "assumed. Taxonomy gap: 12 Report Run has no link to the Performance Return versions it shows; the close group of the "
               "package's mandates is used. "
               "Drafting assumptions: Production Status, Delivery Status and Period Close Status values from the code lists; the "
               "12-month GIPS currency window; the 30-day post-transition window; the 15-day holdings lag; 7am ET and business day 15. "
               "Decisions: CW-145, CW-147, CW-240, CW-912. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's twelve "
               "12 objects plus 32 Performance Period Close and Performance Return through DP-145; upstream DP-004 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-514": dict(
        definition=("Per recordkept plan sponsor and plan: the service relationship, tier and recordkeeping arrangement, plan "
                    "reviews and fiduciary committee meetings held against the plan's review cadence, line-up changes and plan "
                    "conversions with their blackout notices, the participation and plan asset figures presented (from DP-094 and "
                    "DP-430, with workplace channel Client Assets from DP-008), and open sponsor requests. Workplace relationship "
                    "managers keep sponsors served and see which plans are due a review. It owns no certified metric family."),
        business_questions=[
            "Which recordkept plans are due or overdue for a plan review or fiduciary committee meeting?",
            "What participation, enrollment and plan asset figures should we present to each sponsor this quarter?",
            "Which line-up changes and plan conversions are in progress, and were blackout notices sent on time?",
            "Which sponsor requests are open past their service standard?",
            "How many sponsors use the sponsor portal, and which plans have no primary relationship manager?",
        ],
        grain=("Recordkept plan x plan sponsor service relationship x quarter-end as the main output, with plan reviews, sponsor "
               "requests, fund change events, plan conversions and participation aggregates as companion facts; quarterly snapshots "
               "with monthly refresh"),
        dimensions=["Plan sponsor and retirement plan (DP-094, DP-003)", "Service relationship and service tier (DP-003)", "Recordkeeping program",
                    "Plan investment option and share class (DP-004)", "Menu role", "Fund change type", "Conversion type and status",
                    "Enrollment method", "Review type", "Request type", "Quarter-end and period (DP-013)"],
        measures=[
            ("Serviced Recordkept Plans",
             "Count of Plan Sponsor Servicing Detail rows whose Sponsor Service Relationship has Servicing Segment Plan Sponsor - Recordkept and Service Relationship Status Active, and whose Recordkeeping Service Arrangement has Arrangement Status Active, by Service Tier and Recordkeeping Program.",
             _u("12", "Plan Sponsor Servicing Detail", "Sponsor Service Relationship", "Serviced Retirement Plan", "Recordkeeping Service Arrangement")
             + _u("12", "Service Relationship", "Service Relationship ID", "Servicing Segment", "Service Tier", "Service Relationship Status")
             + _u("16", "Service Arrangement", "Service Arrangement ID", "Arrangement Plan", "Recordkeeping Program", "Arrangement Status")),
            ("Plan Assets Recordkept (from DP-430)",
             "Sum of Balance Market Value of Participant Balances at the quarter-end Valuation Date of the plan's memberships (Balance Membership of a Participant Plan Membership of the plan), as DP-430 publishes Participant Balance Market Value.",
             _u("16", "Participant Balance", "Balance Membership", "Valuation Date", "Balance Market Value")
             + _u("16", "Participant Plan Membership", "Membership ID", "Membership Plan")),
            ("Workplace Client Assets (from DP-008)",
             "Certified (CW-011), read: Measure Amount of MSR-CLIENTASSETS at Dimension Type Channel for Workplace - Recordkept Plan at the quarter-end, locked snapshot; Plan Assets Recordkept summed over plans ties to it.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Active Participants",
             "Count of Participant Plan Memberships of the plan with Membership Status Active at the quarter-end (Membership Status Effective From), and of those with a balance above zero.",
             _u("16", "Participant Plan Membership", "Membership ID", "Membership Plan", "Membership Status", "Membership Status Effective From")
             + ["Plan Assets Recordkept (from DP-430)"]),
            ("Participation Rate % (from DP-094)",
             "Memberships with Membership Status Active and a Plan Entry Date / memberships with an Eligibility Date on or before the quarter-end x 100, as DP-094 publishes Participation Rate %.",
             _u("16", "Participant Plan Membership", "Membership Plan", "Membership Status", "Eligibility Date", "Plan Entry Date")),
            ("New Participants by Enrollment Method",
             "Count of memberships with Plan Entry Date in the quarter by Enrollment Method (automatic or affirmative), and automatic enrollments opted out (Automatic Enrollment Opt-Out Date in the quarter).",
             _u("16", "Participant Plan Membership", "Membership Plan", "Plan Entry Date", "Enrollment Method", "Automatic Enrollment Opt-Out Date")),
            ("Plan Reviews Held to Cadence %",
             "Serviced plans whose latest Client Review of Review Type Plan Review or Fiduciary Committee Meeting for the sponsor relationship (Review Held Date) is within the plan's Plan Review Cadence / Serviced Recordkept Plans x 100.",
             _u("12", "Client Review", "Client Review ID", "Review Type", "Reviewed Relationship", "Review Held Date", "Review Outcome")
             + _u("12", "Plan Sponsor Servicing Detail", "Plan Review Cadence")
             + ["Serviced Recordkept Plans"]),
            ("Plans Due a Review in 60 Days",
             "Count of serviced plans whose next review date (latest Review Held Date plus Plan Review Cadence) falls within 60 days of the as-of date, with those already overdue.",
             _u("12", "Client Review", "Reviewed Relationship", "Review Held Date")
             + _u("12", "Plan Sponsor Servicing Detail", "Plan Review Cadence", "Plan Fiduciary Committee")),
            ("Line-Up Changes in Period",
             "Count of Fund Change Events with Mapping Effective Date in the quarter by Fund Change Type, and of Plan Investment Options added (Option Added Date) or set to a closed Option Status in the quarter, by Menu Role.",
             _u("16", "Fund Change Event", "Fund Change ID", "Change Plan", "Fund Change Type", "Mapping Effective Date")
             + _u("16", "Plan Investment Option", "Investment Option ID", "Menu Plan", "Offered Share Class", "Menu Role", "Option Added Date", "Option Status")),
            ("Active Menu Options",
             "Count of Plan Investment Options with Option Status Active per plan by Menu Role, and of plans with no option of Menu Role QDIA.",
             _u("16", "Plan Investment Option", "Menu Plan", "Menu Role", "Option Status")),
            ("Plan Conversions In Progress",
             "Count of Plan Conversions with Conversion Status not Complete by Conversion Type, with Blackout Period Start and Blackout Period End.",
             _u("16", "Plan Conversion", "Conversion ID", "Converted Plan", "Conversion Type", "Blackout Period Start", "Blackout Period End", "Conversion Status")),
            ("Blackout Notices Sent Late",
             "Count of Plan Conversions whose Blackout Notice Sent Date is less than 30 days before Blackout Period Start (ERISA section 101(i)), or empty within 30 days of the start.",
             _u("16", "Plan Conversion", "Conversion ID", "Blackout Period Start", "Blackout Notice Sent Date")),
            ("Open Sponsor Requests Past Standard",
             "Count of Client Service Requests of the sponsor relationship not Resolved, Closed or Canceled whose Request SLA Due Timestamp has passed, by Request Type.",
             _u("12", "Client Service Request", "Service Request ID", "Request Type", "Request Service Relationship", "Request Status", "Request SLA Due Timestamp")),
            ("Sponsor Portal Adoption %",
             "Serviced plans with Sponsor Portal Access Indicator Y / Serviced Recordkept Plans x 100, by plan size band (16 Plan Sponsor Profile Employee Count).",
             _u("12", "Plan Sponsor Servicing Detail", "Sponsor Portal Access Indicator")
             + _u("16", "Plan Sponsor Profile", "Sponsor Party", "Employee Count")
             + ["Serviced Recordkept Plans"]),
            ("Plans Without Primary Relationship Manager",
             "Count of serviced plans whose sponsor relationship has no Service Coverage Assignment with Primary Contact Indicator Y in force at the quarter-end (Assignment Effective From / To).",
             _u("12", "Service Coverage Assignment", "Assigned Service Employee", "Covered Service Relationship", "Primary Contact Indicator", "Assignment Effective From", "Assignment Effective To")
             + ["Serviced Recordkept Plans"]),
        ],
        inputs=[
            ("12", "Plan Sponsor Servicing Detail", ["Sponsor Service Relationship", "Serviced Retirement Plan", "Recordkeeping Service Arrangement", "Plan Fiduciary Committee", "Plan Review Cadence", "Sponsor Portal Access Indicator"]),
            ("12", "Service Relationship", ["Service Relationship ID", "Client", "Servicing Segment", "Service Tier", "Service Relationship Status"]),
            ("12", "Client Review", ["Client Review ID", "Review Type", "Reviewed Relationship", "Review Held Date", "Review Outcome"]),
            ("12", "Client Service Request", ["Service Request ID", "Request Type", "Request Service Relationship", "Request Status", "Request SLA Due Timestamp"]),
            ("12", "Service Coverage Assignment", ["Assigned Service Employee", "Covered Service Relationship", "Primary Contact Indicator", "Assignment Effective From", "Assignment Effective To"]),
            ("16", "Plan Sponsor Profile", ["Sponsor Party", "Employee Count"]),
            ("16", "Service Arrangement", ["Service Arrangement ID", "Arrangement Plan", "Recordkeeping Program", "Arrangement Effective From", "Arrangement Status"]),
            ("16", "Plan Investment Option", ["Investment Option ID", "Menu Plan", "Offered Share Class", "Menu Role", "Option Added Date", "Option Status"]),
            ("16", "Fund Change Event", ["Fund Change ID", "Change Plan", "Fund Change Type", "Mapping Effective Date"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Membership Plan", "Membership Status", "Membership Status Effective From", "Eligibility Date", "Plan Entry Date", "Enrollment Method", "Automatic Enrollment Opt-Out Date"]),
            ("16", "Participant Balance", ["Balance Membership", "Valuation Date", "Balance Market Value"]),
            ("16", "Plan Conversion", ["Conversion ID", "Converted Plan", "Conversion Type", "Blackout Period Start", "Blackout Period End", "Blackout Notice Sent Date", "Conversion Status"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Ending Client Assets"]),
        ],
        upstream=["DP-094", "DP-003", "DP-430", "DP-008", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 10 after month-end, with the quarter-end sponsor figures by business day 10 after quarter-end; open requests and conversions refreshed daily",
        history="Quarterly sponsor snapshots kept 10 years; plan reviews, committee meetings, conversions and blackout notices kept 6 years after the plan year (ERISA section 107 records)",
        classification="Confidential - Client",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Serviced Retirement Plan, Arrangement Plan, Menu Plan, Change Plan and Converted Plan resolves to a DP-094 recordkept plan, every Sponsor Service Relationship to a DP-003 service relationship and every Offered Share Class to DP-004.",
            "One Service Arrangement with Arrangement Status Active is in force per plan, Service Coverage Assignment periods do not overlap per relationship and role, and Blackout Period End is on or after Blackout Period Start.",
            "Plan Assets Recordkept summed over plans equals DP-430's published Participant Balance Market Value for the same Valuation Date within USD 1 and ties to Workplace Client Assets (from DP-008) within 0.1%.",
            "Plan Review Cadence is populated on every serviced plan, Membership Status and Plan Entry Date on every active membership, and Blackout Notice Sent Date on every conversion with a blackout.",
            'Participant figures are published as plan-level counts and amounts only, with a minimum of 10 participants per figure; no participant, employee or sponsor contact attribute is published (Assigned Service Employee is read only to test coverage).',
            "The quarter-end sponsor view is fixed on business day 10 after quarter-end and is the version presented to sponsors; later corrections create a new version.",
        ],
        notes=("Certified numbers: reads workplace channel Ending Client Assets from DP-008; owns none. Plan assets come from the "
               "recordkeeping book (16, DP-430), which is not a CW-007 client holdings book (WP1F F3 ruling) and is never compared to "
               "Firm AUM. "
               "PII tier: none at publication. pii = N: 16 Participant Plan Membership and Participant Balance (PII - financial) and "
               "12 Service Coverage Assignment (employee) are read only to count and aggregate per plan (DQ5); the other warnings are "
               "the lexical 'No PII' object-tier notes. "
               "Boundaries: CW-146: 16 owns the plan, menu and arrangements (DP-094, DP-430); 12 owns the sponsor relationship and "
               "reviews (DP-003); participant outcomes and rollover capture are BWO DP-466 and DP-467; institutional health is DP-510's. "
               "Backlog DP-465 (plan sponsor reporting data) and DP-469 (plan conversion and fund change tracker) fold in here. "
                              "Tailoring lever: sponsor reporting home (12 SME 4). Reference default: sponsor relationship and reviews in 12, plan data "
               "in 16; lever: move sponsor reporting to 16. Tailoring lever: review cadence. Reference default: annual plan review, "
               "quarterly committee meetings for plans over 500 employees. "
               "Taxonomy gap: 16 Plan Investment Option has no own-fund indicator, so the own-fund share of plan menus is not "
               "published here (DP-004 resolves the share class). Taxonomy gap: 12 Client Review has no plan attribute; reviews are "
               "tied to the plan through the sponsor relationship. "
               "Drafting assumptions: Servicing Segment Plan Sponsor - Recordkept; Review Type values Plan Review and Fiduciary "
               "Committee Meeting; Menu Role QDIA; Conversion Status Complete; the 30-day ERISA 101(i) notice; the 60-day window; the "
               "10-participant minimum; tolerances USD 1 and 0.1%; business day 10. "
               "Decisions: CW-146, CW-232, CW-240. "
               "WP1 new (CW-240): consumer product of the DIS+FDN brief registered in WAVE_WP1C DIS; inputs are the candidate's six "
               "objects plus 12 Service Relationship, Client Review, Client Service Request and Service Coverage Assignment, 16 "
               "Participant Balance and Plan Conversion and the DP-008 read; upstream DP-430 and DP-004 added."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-243": dict(
        definition=("An institution's whole relationship with the firm, keyed on the 02 party and rolled up to the ultimate parent "
                    "(DP-240): OCIO and advisory mandates and the portfolios that implement them, pooled vehicles held, recordkept "
                    "plans it sponsors, intermediary agreements it is party to, its accounts, client assets and net flows (DP-007 "
                    "and DP-006 attribution to the 12 Institutional Client), fee revenue (DP-012), billing (DP-350), service health "
                    "(DP-510), reporting (DP-511) and pipeline (DP-488). It answers what one institution is worth to the firm "
                    "across lines before a review, a search or a renewal; the household equivalent is CLA-A DP-320 Household 360. "
                    "It owns no certified metric family."),
        business_questions=[
            "What does each institutional client group hold with us across mandates, pooled vehicles, recordkept plans and intermediary agreements?",
            "What are the group's client assets, net flows and fee revenue this year?",
            "Is the relationship healthy: service health, reporting timeliness, billing disputes and termination notices?",
            "Which consultants advise the group, and what open pipeline do we have with it?",
            "Which party links (merged parties, missing ultimate parent, accounts without a resolved owner) need fixing before the review?",
        ],
        grain=("Client party rolled up to its ultimate parent (DP-240 Party ID) x month-end as the main output, with child rows party x "
               "relationship line (service relationship, mandate, account, recordkept plan, intermediary agreement, opportunity) as "
               "a companion bridge; monthly snapshots"),
        dimensions=["Client party and ultimate parent (DP-240)", "Party type and client role type (DP-240)", "Institutional client type (12)", "Legal jurisdiction",
                    "Business line (DP-140, DP-004)", "Relationship type", "Mandate and implementing portfolio (DP-140)", "Consultant (DP-003)",
                    "Service tier (DP-510)", "Servicing segment (DP-003)", "Month-end (DP-013)"],
        measures=[
            ("Relationship Footprint",
             "Per ultimate parent at the month-end: count of active Service Relationships, Investment Mandates (Client), accounts held in an owner Account Role Type (Account Status Open), recordkept plans sponsored (02 Retirement Plan Plan Sponsor in the group, active 16 Service Arrangement), active intermediary Distribution Agreements with a group party as Agreement Party, and open opportunities.",
             _u("12", "Service Relationship", "Service Relationship ID", "Client", "Service Relationship Status")
             + _u("01", "Investment Mandate", "Mandate ID", "Client")
             + _u("15", "Account", "Account ID", "Account Status")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account")
             + _u("02", "Retirement Plan", "Plan Name", "Plan Sponsor")
             + _u("16", "Service Arrangement", "Service Arrangement ID", "Arrangement Plan", "Arrangement Status")
             + _u("05", "Distribution Agreement", "Agreement ID", "Agreement Status")
             + _u("05", "Agreement Party Role", "Agreement Party", "Agreement Party Role")
             + _u("02", "Legal Entity Hierarchy", "Subsidiary Party", "Ultimate Parent", "Hierarchy Effective From", "Hierarchy Effective To")),
            ("Business Lines Held",
             "Count of distinct CW-004 business lines across the group's relationship lines: Relationship Business Line of service relationships, Business Line of implementing portfolios (18 Portfolio) and of pooled products held (01 Firm Product Classification), the WR line for sponsored recordkept plans and the IC line for intermediary agreements.",
             _u("12", "Service Relationship", "Relationship Business Line", "Serviced Pooled Vehicles")
             + _u("18", "Portfolio", "Portfolio ID", "Business Line")
             + _u("01", "Firm Product Classification", "Business Line")
             + ["Relationship Footprint"]),
            ("Relationship Client Assets",
             'Sum of Attributed Amount of DP-007 attribution records of month-end Account Asset Summaries (Source Account Asset Summary, Summary As-Of Date = month-end) whose Institutional Client is a member of the group: analytical client assets of the relationship, not certified.',
             _u("06", "Attribution Record", "Attribution Record ID", "Source Account Asset Summary", "Attributed Amount") + _u("06", "Market & Client Dimensions", "Institutional Client") + _u("06", "Account Asset Summary", "Summary As-Of Date")),
            ("Relationship Net Flows",
             'Sum of Attributed Amount, signed by Flow Direction, of DP-006 attribution records of current flows (Transaction Status not Canceled, Reversed or Rejected) with Flow Scope Client Asset Flow or Client Asset and Fund Flow and Trade Date in the period whose Institutional Client is a member of the group: analytical, not certified.',
             _u("06", "Attribution Record", "Source Transaction", "Attributed Amount") + _u("06", "Market & Client Dimensions", "Institutional Client") + _u("06", "Transaction", "Flow Direction", "Flow Scope") + _u("06", "Transaction Dates", "Trade Date") + _u("06", "Transaction Status", "Transaction Status")),
            ("Institutional Channel Client Assets and Flows (from DP-008)",
             "Certified (CW-011), read: Ending Client Assets and Net New Assets at Dimension Type Channel for the Institutional sub-channels and Net Flows (Net Sales) of own funds, from the locked DP-008 snapshot; the context for the group's share.",
             _MV_READ + _u("06", "Client Asset Measures", "Ending Client Assets", "Net New Assets") + _u("06", "Flow Measures", "Net Flows (Net Sales)")),
            ("Mandate Portfolio Value (from DP-142)",
             "Total IBOR Market Value of the month-end 18 Portfolio Valuation Summary of the portfolios whose primary Portfolio Implementation Link names one of the group's mandates (Implemented Mandate), as DP-142 publishes it; a portfolio value, not Firm AUM.",
             _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implemented Mandate", "Primary Implementation Indicator")
             + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value")),
            ("Institutional Client Profile (from DP-003)",
             "Institutional Client Type, Total Investable Assets (Assets As-Of Date), ERISA Plan Indicator and Government Entity Indicator of the group's Institutional Clients as DP-003 publishes them, with the Legal Name and Legal Jurisdiction of the 02 Organization.",
             _u("12", "Institutional Client", "Institutional Client Party", "Institutional Client Type", "Total Investable Assets", "Assets As-Of Date", "ERISA Plan Indicator", "Government Entity Indicator")
             + _u("02", "Organization", "Legal Name", "Legal Jurisdiction")),
            ("Consultant Coverage (from DP-003)",
             "Count and names of consultant firms (05 Consultant Profile Consultant Type) with a Consultant Advisory Relationship to a group party in force at the month-end (Engagement Effective From / To), and of service relationships with an Advising Consultant.",
             _u("05", "Consultant Profile", "Consultant Party", "Consultant Type")
             + _u("05", "Consultant Advisory Relationship", "Consultant Firm", "Advised Client", "Engagement Effective From", "Engagement Effective To")
             + _u("12", "Service Relationship", "Advising Consultant")),
            ("Relationship Revenue (from DP-012)",
             "Recognized Revenue Amount of DP-012 Client Revenue Records for the fiscal year to date on the group's accounts (Revenue Account / Household) by Client Revenue Stream (OCIO Fee, Advisory Fee, Recordkeeping Fee), plus Net Fee Revenue of DP-012 Fee Revenue Records of the group's mandates (Revenue Share Class / Mandate); pooled fund revenue has no client split and is excluded.",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Revenue Account / Household", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount")
             + _u("10", "Fee Revenue Record", "Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period", "Net Fee Revenue")),
            ("Fee Billing (from DP-350)",
             "Invoice Total of 47 Fee Invoices of the group's Billing Arrangements (Billed Mandate, Bill-To Party in the group) with Billing Period End in the year to date, invoices with Payment Status not Paid more than 60 days after Invoice Date, and the Disputed Amount of Billing Disputes with Dispute Status Open, as CLA-A DP-350 publishes mandate billing.",
             _u("47", "Billing Arrangement", "Billing Arrangement ID", "Billed Mandate", "Bill-To Party")
             + _u("47", "Fee Invoice", "Invoice ID", "Invoice Billing Arrangement", "Billing Period End", "Invoice Total", "Invoice Date", "Payment Status")
             + _u("47", "Billing Dispute", "Disputed Invoice", "Disputed Amount", "Dispute Status")),
            ("Service Health (from DP-510)",
             "Latest Overall Health Score and At-Risk Indicator of the group's service relationships (Scored Relationship, Health Score Date), with the count at risk, as DP-510 publishes them (At-Risk Relationships, Average Health Score).",
             _u("12", "Relationship Health Score", "Health Score Date", "Scored Relationship", "Overall Health Score", "At-Risk Indicator")
             + _u("12", "Service Relationship", "Service Tier")),
            ("Client Reporting Timeliness (from DP-511)",
             "Share of the group's Report Runs (Run Package / Report of a Report Package whose Package Client is in the group) with SLA Met Indicator Y in the trailing 12 months, and the count with Restatement Indicator Y, as DP-511 publishes Reports Delivered On Time %.",
             _u("12", "Report Package", "Report Package ID", "Package Client")
             + _u("12", "Report Run", "Run Package / Report", "Reporting Period End", "SLA Met Indicator", "Restatement Indicator")),
            ("Terminations Notified",
             "Count of Mandate Terminations of the group's mandates with Notice Received Date in the trailing 12 months, with their Effective Termination Date.",
             _u("12", "Mandate Termination", "Termination ID", "Terminated Mandate", "Notice Received Date", "Effective Termination Date")),
            ("Pipeline with Client (from DP-488)",
             "Open Expected Amount and Expected Amount x Probability of 05 Sales Opportunities whose Prospect / Client is a group party (Sales Stage not closed), and Expected Amount won in the year (Opportunity Outcome Won, Actual Close Date), by Opportunity Type and Business Type, as DP-488 publishes the pipeline.",
             _u("05", "Sales Opportunity", "Opportunity ID", "Opportunity Type", "Business Type", "Prospect / Client")
             + _u("05", "Pipeline Status", "Sales Stage", "Probability")
             + _u("05", "Opportunity Value", "Expected Amount", "Actual Close Date")
             + _u("05", "Win / Loss", "Opportunity Outcome")),
            ("Plans Sponsored",
             "Count of recordkept plans sponsored by group parties with an active Service Arrangement, with the sponsor's Employee Count (16 Plan Sponsor Profile).",
             _u("16", "Plan Sponsor Profile", "Sponsor Party", "Employee Count")
             + _u("02", "Retirement Plan", "Plan Sponsor")
             + _u("16", "Service Arrangement", "Arrangement Plan", "Arrangement Status")),
            ("Unresolved Party Links",
             "Count of group parties with Merged Into Party set, Party Status not Active while holding an active role, no Ultimate Parent in force, or an Institutional Client with no active 02 Party Role of Role Type Institutional Client; plus accounts whose owner Role Party does not resolve to the group.",
             _u("02", "Party", "Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party")
             + _u("02", "Party Role", "Role Party", "Role Type", "Role Status", "Role Effective From", "Role Effective To")
             + _u("02", "Legal Entity Hierarchy", "Subsidiary Party", "Ultimate Parent")
             + _u("15", "Account Party Role", "Role Party", "Role Account")),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party"]),
            ("02", "Organization", ["Legal Name", "Legal Jurisdiction"]),
            ("02", "Legal Entity Hierarchy", ["Subsidiary Party", "Direct Parent", "Ultimate Parent", "Hierarchy Effective From", "Hierarchy Effective To"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status", "Role Effective From", "Role Effective To"]),
            ("02", "Retirement Plan", ["Plan Name", "Plan Sponsor"]),
            ("12", "Institutional Client", ["Institutional Client Party", "Institutional Client Type", "Total Investable Assets", "Assets As-Of Date", "Government Entity Indicator", "ERISA Plan Indicator"]),
            ("12", "Service Relationship", ["Service Relationship ID", "Client", "Servicing Segment", "Relationship Business Line", "Serviced Mandates", "Serviced Pooled Vehicles", "Advising Consultant", "Service Tier", "Service Relationship Status"]),
            ("12", "Relationship Health Score", ["Health Score Date", "Scored Relationship", "Overall Health Score", "At-Risk Indicator"]),
            ("12", "Report Package", ["Report Package ID", "Package Client"]),
            ("12", "Report Run", ["Run Package / Report", "Reporting Period End", "SLA Met Indicator", "Restatement Indicator"]),
            ("12", "Mandate Termination", ["Termination ID", "Terminated Mandate", "Notice Received Date", "Effective Termination Date"]),
            ("05", "Consultant Profile", ["Consultant Party", "Consultant Type"]),
            ("05", "Consultant Advisory Relationship", ["Consultant Firm", "Advised Client", "Engagement Effective From", "Engagement Effective To"]),
            ("05", "Sales Opportunity", ["Opportunity ID", "Opportunity Type", "Business Type", "Prospect / Client"]),
            ("05", "Pipeline Status", ["Sales Stage", "Probability"]),
            ("05", "Opportunity Value", ["Expected Amount", "Actual Close Date"]),
            ("05", "Win / Loss", ["Opportunity Outcome"]),
            ("05", "Distribution Agreement", ["Agreement ID", "Agreement Status"]),
            ("05", "Agreement Party Role", ["Agreement Party", "Agreement Party Role"]),
            ("16", "Plan Sponsor Profile", ["Sponsor Party", "Employee Count"]),
            ("16", "Service Arrangement", ["Service Arrangement ID", "Arrangement Plan", "Arrangement Status"]),
            ("01", "Investment Mandate", ["Mandate ID", "Mandate Type", "Client"]),
            ("01", "Firm Product Classification", ["Business Line"]),
            ("18", "Portfolio", ["Portfolio ID", "Business Line"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implemented Mandate", "Primary Implementation Indicator"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account"]),
            ("06", "Attribution Record", ["Attribution Record ID", "Source Transaction", "Source Account Asset Summary", "Attributed Amount"]),
            ("06", "Market & Client Dimensions", ['Institutional Client', 'Distribution Channel']),
            ("06", "Account Asset Summary", ["Summary As-Of Date"]),
            ("06", "Transaction", ["Flow Direction", "Flow Scope"]),
            ("06", "Transaction Dates", ["Trade Date"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Net New Assets"]),
            ("06", "Flow Measures", ["Net Flows (Net Sales)"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Revenue Account / Household", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period", "Net Fee Revenue"]),
            ("47", "Billing Arrangement", ["Billing Arrangement ID", "Billed Mandate", "Bill-To Party"]),
            ("47", "Fee Invoice", ["Invoice ID", "Invoice Billing Arrangement", "Billing Period End", "Invoice Total", "Invoice Date", "Payment Status"]),
            ("47", "Billing Dispute", ["Disputed Invoice", "Disputed Amount", "Dispute Status"]),
            ("06", "Transaction Status", ['Transaction Status']),
        ],
        upstream=["DP-240", "DP-003", "DP-093", "DP-140", "DP-142", "DP-007", "DP-006", "DP-008", "DP-012", "DP-350", "DP-305",
                  "DP-094", "DP-001", "DP-005", "DP-488", "DP-510", "DP-511", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 12 after month-end, after DP-012 closes the period and DP-510 publishes the month's relationship health",
        history="Monthly relationship snapshots kept 10 years; party roll-ups versioned with the 02 Legal Entity Hierarchy in force (SCD type 2)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "CRM embed"],
        dq_rules=[
            "Every Party ID, Subsidiary Party, Ultimate Parent, Role Party, Plan Sponsor, Agreement Party and Prospect / Client resolves to DP-240, every Institutional Client Party and Service Relationship to DP-003, every mandate to DP-004, every implementing portfolio to DP-140 and every Role Account to DP-093.",
            "02 Legal Entity Hierarchy periods of one Subsidiary Party do not overlap and end on or after they start, so each party rolls up to one ultimate parent at the month-end, and no party is counted in two groups.",
            "Relationship Revenue (from DP-012) equals DP-012's published Recognized Revenue Amount and Net Fee Revenue for the same records and Institutional Channel Client Assets and Flows (from DP-008) equals the locked DP-008 values within USD 1; and Relationship Client Assets summed over all groups does not exceed the institutional-channel Ending Client Assets (from DP-008) plus the Attributed Amount of institutional-client attribution rows whose Distribution Channel is not an Institutional sub-channel.",
            "Party Type, Party Status and the Ultimate Parent are populated for every group party, and Service Relationship Status for every service relationship read.",
            "Individuals in an institutional group (trustees, small-plan sponsors) are shown by 02 party key and display name only; no date of birth, identifier or account number is read, and no household or special-category data is read.",
            "The month-end snapshot is built after DP-012, DP-510 and DP-511 publish the month and is locked; a change in the 02 hierarchy re-groups from the next snapshot, never in a published one.",
        ],
        notes=("Master concept read, not remastered: Party (02, PTY-) through DP-240 (CD-143, CD-360); institutional role profiles "
               "and service relationships stay with DP-003, accounts with DP-093. "
               "Certified numbers: reads institutional channel Ending Client Assets, Net New Assets and own-fund Net Flows from DP-008 "
               "and fee revenue from DP-012; owns none. The group's client assets and flows are analytical cuts of DP-007 and DP-006 "
               "attribution records keyed by 12 Institutional Client, and Mandate Portfolio Value is a DP-142 portfolio value; neither "
               "is Firm AUM, which only DP-241 certifies (CW-011, CW-241). "
               "PII tier: identity (a few group parties are individuals, such as trustees or small-plan sponsors; DQ5). "
               "Boundaries: the household equivalent is CLA-A DP-320 Household 360; service health is DP-510's, reporting timeliness "
               "DP-511's, pipeline DP-488's and mandate billing CLA-A DP-350's (with the 47 billing facts from DP-305); this product "
               "reads their published figures at group grain and computes none of its own. "
               "Tailoring lever: group roll-up. Reference default: 02 Legal Entity Hierarchy Ultimate Parent; lever: a relationship "
               "group defined by client service. Tailoring lever: OCIO offered (12 SME 1). Reference default: offered. "
               "Taxonomy gap: 06 Market & Client Dimensions Institutional Client is the only client key on attributed client assets, "
               "so retail and intermediary-held assets of an institutional group are not in Relationship Client Assets or Relationship Net Flows "
               "(carried from the wholesale spec). Taxonomy gap: pooled fund revenue has no client split, so Relationship Revenue "
               "covers mandates and accounts only (carried). "
               "Drafting assumptions: owner Account Role Types; Role Type Institutional Client; Payment Status Paid; the 60-day "
               "receivable threshold; the trailing 12-month windows of Terminations Notified and Client Reporting Timeliness; Dispute Status Open; USD 1 tolerance; business day 12. "
               "Decisions: CD-001, CD-143, CD-360, CW-132, CW-133, CW-134, CW-145, CW-206, CW-220, CW-241, CW-246. "
               "W1 re-point (CW-902) and W4 re-point (CW-132, CW-133, CW-134, CW-145) lines of the wholesale spec: their object moves "
               "(Institutional Client to 12, Consultant Advisory Relationship and Consultant Profile to 05, the billing family to 47, "
               "Survey Response to 04, the pipeline objects to 05) are kept; the 30 private fund objects stay dropped (CW-930). "
               "WP1 re-scope (CW-206): name kept; owning domain 02 -> 12, owner Head of Institutional Client Service and primary "
               "function FN-75 per the WP0 row; now the institutional relationship view (household view CLA-A DP-320). Upstream: the "
               "retired DP-019, DP-042 and DP-067 replaced by DP-488, DP-510 and DP-511, and DP-350; DP-142, DP-007, DP-006, DP-305, "
               "DP-094, DP-001 and DP-005 added. Inputs dropped: 06 Asset Measures (wholesale Ending AUM), 04 Survey Response (survey "
               "results now inside DP-510's Service Health), 12 Client Service Request (DP-510). Inputs added: 05 Distribution "
               "Agreement and Agreement Party Role, 16 Plan Sponsor Profile and Service Arrangement, 18 Portfolio Valuation Summary, "
               "06 Attribution Record, Account Asset Summary, Transaction, Transaction Dates, Snapshot and Client Asset Measures, 10 "
               "Client Revenue Record. The objects behind the logical-model entities (15 Account, 15 Account Party Role, 47 Billing "
               "Arrangement, Fee Invoice, Billing Dispute, 12 Mandate Termination, 01 Investment Mandate, 18 Portfolio and "
               "Portfolio Implementation Link, 06 Measure Value) are kept. Measures kept by name: Relationship Footprint, Business "
               "Lines Held, Institutional Client Profile (from DP-003), Consultant Coverage (from DP-003), Relationship Revenue (from "
               "DP-012), Terminations Notified, Unresolved Party Links (SM-04 reads Relationship Footprint, Business Lines Held, "
               "Terminations Notified, Consultant Coverage (from DP-003) and Unresolved Party Links). Measures renamed: 'Attributed AUM "
               "and Net Flows (from DP-008)' split into 'Relationship Client Assets' and 'Relationship Net Flows' (no semantic reader found) with "
               "'Institutional Channel Client Assets and Flows (from DP-008)' added for the certified context; 'Fee Billing (from "
               "DP-067)' to 'Fee Billing (from DP-350)' (read by SM-04 at sm_04_institutional_retirement.py lines 1001, 1007 and 1013: "
               "re-point); 'Service Health (from DP-042)' to 'Service Health (from DP-510)'; 'Client Reporting Timeliness (from "
               "DP-042)' to 'Client Reporting Timeliness (from DP-511)'; 'Pipeline with Client (from DP-019)' to 'Pipeline with Client "
               "(from DP-488)' (no semantic reader found for the last three). Added: Mandate Portfolio Value (from DP-142), Plans "
               "Sponsored. Dimension 'Service tier (DP-042)' renamed 'Service tier (DP-510)'; 'Servicing segment (DP-003)' added. "
               "SM-04's 'Private Fund Commitments and Capital (from DP-116, DP-117)' rows and its private fund entities have no "
               "source since W4 and retire with SM-04. The wholesale entry in specs_e5_cross_area.py is superseded and is deleted by "
               "the lineage agent."
               " WP2 retirement sweep (CW-209): SM-04, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
}
