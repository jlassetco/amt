"""Wave WP1C, consumer group C-4 'Fund Operations and Corporate Functions' (FOP + CORP): attribute-level specifications of
the wealth-manager rework (Wealth_Manager_Rework_Plan.md sections 8.3, 8.5 and 10; 00_Program/Rework/Product_Briefs/
WP1_Method.md section 5; WP1_Scope.md, WP1C_FOP and WP1C_CORP).

New consumer products (WP1C_FOP, WP1C_CORP):
- DP-583 Shareholder Account Holds & Rule 2165 Restrictions (29 Transfer Agency Operations)
- DP-585 Intermediary Shareholder Requests: Rule 22c-2 and Beneficial Owner Distribution (29 Transfer Agency Operations)
- DP-586 Fund Fee Accrual Assurance (27 Fund Accounting & Valuation)
- DP-588 Fund Distribution Payment & Reinvestment Posting Control (29 Transfer Agency Operations)
- DP-595 Client Data Safeguards: Reg S-P, Reg S-ID & Customer Notification (41 Technology & Information Security)
- DP-598 Client Revenue Recognition & Ledger Tie-Out (19 Finance & Accounting)
- DP-600 Customer Reserve Funding & Program Bank Exposure (43 Corporate Treasury & Capital)

Re-scoped in place (WP1_RESCOPED, WP1C_CORP; ids kept, the wholesale specs stay in their old modules until the lineage
pass deletes them):
- DP-083 Regulatory Obligations, Attestations & Horizon (38 Corporate Compliance & Regulatory Affairs; CW-260; old entry
  specs_n_compliance_controls.py)
- DP-199 Deferred Awards & Clawback (20 Human Capital; CW-208; old entry specs_e4_people_workplace_ai.py)
- DP-217 Critical Functions & Business Continuity (37 Enterprise & Operational Risk; CW-208; old entry
  specs_e4_risk_audit_third_party.py)
- DP-228 Trade Surveillance & Suspicious Activity Reporting (38 Corporate Compliance & Regulatory Affairs; CW-208,
  CW-163; old entry specs_e4_compliance_legal.py)

Not specified here: DP-582, DP-587, DP-592, DP-593, DP-602, DP-603 and DP-604 are in the Backlog wave (WP1_Scope.md
section 5); DP-241 was specified with the certified foundations (specs_w1f_certified.py).

WP1 decisions applied: certified numbers are read from their owners, never recomputed (CW-011): client fee revenue from
DP-012 (CW-265), fund net assets and NAV from DP-165. The customer reserve computation is 49's and is read from BWO DP-445,
never recomputed (CW-262). Custody-rule evidence is published once, in CLA-A DP-346 (CW-263). Holds on registered shares
are DP-583's and holds on cash movements BWO DP-456's (CW-264). Special-category facts reach these products only through
the DP-322 Protection Flag Present indicator (CW-213, CD-344). The share register is read from DP-580 (CW-261); client
holdings and entitlements from DP-300 (CW-007). See CONTRACT.md.
"""


# Module notes for the lineage agent and the lead (fix pass, 2026-10-15). Not read by the validator.
NOTES = (
    "Readers of content dropped by the DP-083 re-scope: DP-248 'Distribution Horizon Items (from DP-083)' "
    "(specs_e5_cross_area.py lines 811-813) cites the dropped 'Unassessed Horizon Item Flag' and is read by SM-16 "
    "(sm_16_risk_compliance_legal_audit.py line 556); DP-246 'Product Obligations Without Filing Calendar (from DP-083)' "
    "(specs_e5_cross_area.py lines 559-560) reads the dropped 01 Regulatory Authorization 'as DP-083 reads them' and is read "
    "by SM-11 (sm_11_fund_accounting_custody_governance.py line 2006). The successor DP-509 is in the backlog, so the lineage "
    "agent drops those two measures with a WP1 note; DP-083 stays as re-scoped. DP-083's register row still names retired "
    "FN-13 and FN-18 (the CW-260 proposal is primary FN-44, supporting FN-68, FN-36, FN-43). "
    "Live re-specs that must land for these products to hold: DP-224 leaves the obligation and attestation measures to "
    "DP-083; DP-170 drops 'Fee Rate Exceptions' (accrual-to-terms testing is DP-586's); DP-180 moves register holds to DP-583; "
    "DP-171 reads reinvestment postings from DP-580; DP-191 and the 19 GL Posting.Source Finance Record reference reach 10 "
    "Client Revenue Record and Cash Program Economics (DP-598). Products other groups must publish: DP-322 Protection Flag "
    "Present per Party ID; DP-456 'Holds Paired With Account Restriction' with Paired Account Restriction and Hold Status; "
    "DP-445 the approved 49 Reserve Computation attributes and its Deposit Deadline Timestamp; DP-012 the client fee stream "
    "slice of Gross Fee Revenue as a named measure; DP-004 the 01 Management Fee, Other Ongoing Fees and Cost Disclosure "
    "groups; DP-240 Trusted Contact Designation.Account Scope; DP-181 'Capital Stock Proof Difference'; DP-171 'Distribution "
    "Amount'; DP-198 'Annualized Base Pay'; DP-431 'Program Bank Capacity Utilization %'; DP-580 'Escrowed, Pledged or "
    "Restricted Shares'; DP-078 (CLA-B re-spec) 08 Surveillance Alert ID and Alert Disposition. For BWO: DP-445 resolves "
    "reserve accounts to a special reserve Bank Account Purpose that 43 does not have; DP-600 records it as a taxonomy gap."
)


def _u(nn, obj, *attrs):
    """(NN, object, attribute) use tuples for one object."""
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-583": dict(
        definition=("Every hold and restriction on an account registered at the in-house transfer agent and on its shares: "
                    "the 15 Account Restrictions in force on registered accounts, the restricted, escrowed and pledged shares "
                    "on the DP-580 share register, the redemptions and transfers they block, the monitoring alerts whose "
                    "disposition placed them and the 50 payment hold DP-456 pairs with a register hold, with the age of each "
                    "hold. Restrictions of type Financial Exploitation (FINRA Rule 2165) are filtered out at extraction and "
                    "never published; their reason, clock and case are CLA-A DP-322's and CLA-B DP-403's. Holds on clients who "
                    "carry the DP-322 Protection Flag Present indicator are marked so the TA hold desk routes them to trained "
                    "staff. Transfer agency and retail supervision use it to release holds on time and to show that no "
                    "restricted share moved. It owns no certified metric family."),
        business_questions=[
            "Which registered accounts are under a hold today, by restriction type, scope and register account category, and how many shares and how much value at NAV do the holds block?",
            "How old are the holds in force, and which were lifted this period after how long?",
            "Which redemptions, exchanges and transfers out are waiting on a restriction, and for how long?",
            "Did any redemption or transfer post to a registered account while a restriction covering it was in force?",
            "Which held registered accounts belong to a client with the DP-322 protection flag and no trusted contact on file, and which register holds have a paired payment hold?",
        ],
        grain=("Account restriction (15) in force on a TA-registered account x as-of date, Financial Exploitation rows "
               "excluded at extraction, with the account x share class register rows it governs (from DP-580), the blocked "
               "fund orders, the originating monitoring alert and the DP-456 hold pair as companion facts; daily snapshots"),
        dimensions=["Registered account (DP-093)", "Share class (DP-004)", "Register Account Category (DP-580)",
                    "Account restriction type and restriction scope (compliance types grouped outside the compliance view)",
                    "Imposed by (compliance view only)", "Protection Flag Present (from DP-322)", "Trusted contact status (DP-240)",
                    "Hold age band", "As-of date and business date (DP-013)"],
        measures=[
            ("Active Register Restrictions",
             "Count of Account Restriction rows with Account Restriction Effective From on or before the as-of date and Account "
             "Restriction Lifted Date blank or later, whose Restricted Account is the Register Account of a Share Register "
             "Balance row on the as-of Register Business Date, by Account Restriction Type, Restriction Scope and Register "
             "Account Category; rows of type Financial Exploitation never enter the product, and outside the compliance view "
             "the type AML / Sanctions and the Imposed By value AML / Financial Crimes are grouped as Compliance Hold (DQ5).",
             _u("15", "Account Restriction", "Restricted Account", "Account Restriction Type", "Imposed By",
                "Account Restriction Effective From", "Account Restriction Lifted Date", "Restriction Scope")
             + _u("29", "Share Register Balance", "Register Account", "Register Business Date", "Register Account Category")),
            ("Escrowed, Pledged or Restricted Shares (from DP-580)",
             "The Escrowed, Pledged or Restricted Shares DP-580 publishes for the as-of Register Business Date (Escrowed or "
             "Pledged Shares plus Restricted Shares), by Register Share Class and Register Account Category; read, never re-summed.",
             _u("29", "Share Register Balance", "Register Share Class", "Register Business Date", "Register Account Category",
                "Restricted Shares", "Escrowed or Pledged Shares")),
            ("Value of Restricted Registered Shares (at NAV from DP-165)",
             "Escrowed, Pledged or Restricted Shares (from DP-580) x NAV per Share of the Share Class NAV of record (NAV "
             "Approval Status = Approved, highest NAV Version Number) of the same NAV Share Class on the Register Business "
             "Date, as DP-165 publishes it; an operational value of blocked shares, never Client Assets or Firm AUM.",
             ["Escrowed, Pledged or Restricted Shares (from DP-580)"]
             + _u("27", "Share Class NAV", "NAV Share Class", "Parent NAV Calculation", "NAV per Share")
             + _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Approval Status", "NAV Version Number")),
            ("Restricted Shares Without Governing Restriction",
             "Count of Share Register Balance rows with Restricted Shares > 0 whose Governing Account Restriction is blank, or "
             "whose Register Account has no Active Register Restriction on the Register Business Date (the key is matched to "
             "the restriction keys DP-093 publishes and is not carried into the product).",
             _u("29", "Share Register Balance", "Register Account", "Restricted Shares", "Governing Account Restriction",
                "Register Business Date")
             + ["Active Register Restrictions"]),
            ("Fund Orders Blocked by Restriction",
             "Count and sum of Requested Amount of Fund Orders with Fund Order Type in (Redemption, Exchange Out, Transfer Out) "
             "that have an Order Exception with Order Exception Type = Restricted Account, Blocking Account Restriction "
             "populated and Exception Status not in (Resolved / Completed, Closed, Canceled) on the as-of date, by business days "
             "since Exception Raised Timestamp (0-2, 3-5, 6-15, over 15); orders blocked by an excluded restriction are not "
             "counted (DQ5).",
             _u("29", "Fund Order", "Fund Order ID", "Fund Order Type", "Order Account", "Requested Amount", "Fund Order Status")
             + _u("29", "Order Exception", "Exception Fund Order", "Order Exception Type", "Exception Raised Timestamp",
                  "Blocking Account Restriction", "Exception Status", "Exception Resolved Timestamp")),
            ("Restriction Breaches",
             "Count of Register Transactions with Register Transaction Status = Posted, Share Movement Direction = Outflow and "
             "Register Transaction Type in (Redemption, Exchange Out, Fund Share Transfer Out, Share Class Conversion Out) whose "
             "Posting Account had an Active Register Restriction on the Register Trade Date with Restriction Scope in (Sale / "
             "Redemption, Exchange Out, Transfer Out, All Activity) matching the movement; each one is a control failure.",
             _u("29", "Register Transaction", "Register Transaction ID", "Register Transaction Type", "Posting Account",
                "Register Trade Date", "Share Movement Direction", "Register Transaction Status")
             + _u("15", "Account Restriction", "Restricted Account", "Account Restriction Effective From",
                  "Account Restriction Lifted Date", "Restriction Scope")),
            ("Register Hold Age (Days)",
             "Calendar days from Account Restriction Effective From to the as-of date for Active Register Restrictions, averaged "
             "and at the maximum, by Account Restriction Type (grouped as in DQ5) and age band (0-15, 16-30, 31-90, over 90).",
             ["Active Register Restrictions"] + _u("15", "Account Restriction", "Account Restriction Effective From")),
            ("Holds Placed From Monitoring Alerts",
             "Active Register Restrictions on accounts that are the Alert Account of an Account Monitoring Alert with Alert "
             "Resulting Account Restriction populated and Disposition Date on or before Account Restriction Effective From, "
             "with the calendar days from Alert Generated Timestamp to Account Restriction Effective From; alerts of category "
             "Fraud - Elder Financial Exploitation never enter the product, AML - Suspicious Activity and Sanctions alerts are "
             "counted in the compliance view only, and no disposition value or rationale is read (DQ5).",
             ["Active Register Restrictions"]
             + _u("29", "Account Monitoring Alert", "Account Monitoring Alert ID", "Monitoring Alert Category", "Alert Account",
                  "Alert Generated Timestamp")
             + _u("29", "Alert Disposition", "Disposition Date", "Alert Resulting Account Restriction")
             + _u("15", "Account Restriction", "Account Restriction Effective From")),
            ("Protection Flag Present (from DP-322)",
             "Y where a Role Party of the registered account (any Account Party Role open on the as-of date) carries the DP-322 "
             "Protection Flag Present indicator, as DP-322 publishes it per Party ID with the accounts flagged; joined on the 02 "
             "Party ID and 15 Account ID only, with no special-category attribute read here.",
             _u("02", "Party", "Party ID") + _u("15", "Account", "Account ID")
             + _u("15", "Account Party Role", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")),
            ("Register Holds on Protected Clients",
             "Active Register Restrictions on accounts with Protection Flag Present (from DP-322) = Y, with the shares they "
             "govern; a routing count for the TA hold desk, not a Rule 2165 view (Financial Exploitation rows are excluded).",
             ["Active Register Restrictions", "Protection Flag Present (from DP-322)",
              "Escrowed, Pledged or Restricted Shares (from DP-580)"]),
            ("Protected Register Holds Without Trusted Contact",
             "Register Holds on Protected Clients whose owner party is the Designating Client of no Trusted Contact Designation "
             "with Designation Status = Provided, open on the as-of date (Designation Effective From <= date < Designation "
             "Effective To or open) and with Account Scope blank or naming the held account.",
             ["Register Holds on Protected Clients"]
             + _u("02", "Trusted Contact Designation", "Trusted Contact Designation ID", "Designating Client",
                  "Designation Status", "Account Scope", "Designation Effective From", "Designation Effective To")),
            ("Register Holds With Paired Payment Hold (from DP-456)",
             "Active Register Restrictions that are the Paired Account Restriction of an Open Cash Movement Hold as DP-456 "
             "publishes the pair (Hold Status in (Active, Extended); AML holds already excluded by DP-456), and the count of "
             "pairs where one side is released: Account Restriction Lifted Date on or before the as-of date while the hold is "
             "Active or Extended, or Hold Status in (Released, Expired, Canceled) while the restriction is in force. Cash holds "
             "themselves are counted only in DP-456 (CW-264).",
             ["Active Register Restrictions"]
             + _u("50", "Money Movement Hold", "Paired Account Restriction", "Hold Status")
             + _u("15", "Account Restriction", "Account Restriction Lifted Date")),
            ("Register Holds Lifted in Period",
             "Count of Account Restrictions on registered accounts with Account Restriction Lifted Date in the period, with "
             "the average calendar days held (Account Restriction Lifted Date - Account Restriction Effective From), by "
             "Account Restriction Type (grouped as in DQ5).",
             _u("15", "Account Restriction", "Restricted Account", "Account Restriction Type",
                "Account Restriction Effective From", "Account Restriction Lifted Date")
             + _u("29", "Share Register Balance", "Register Account")),
        ],
        inputs=[
            ("15", "Account Restriction", ["Restricted Account", "Account Restriction Type", "Imposed By",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date",
                                           "Restriction Scope"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date",
                                              "Register Account Category", "Registered Shares", "Restricted Shares",
                                              "Escrowed or Pledged Shares", "Governing Account Restriction"]),
            ("29", "Register Transaction", ["Register Transaction ID", "Register Transaction Type", "Posting Account",
                                            "Posting Share Class", "Register Trade Date", "Share Movement Direction",
                                            "Register Transaction Status"]),
            ("29", "Fund Order", ["Fund Order ID", "Fund Order Type", "Order Account", "Order Share Class", "Requested Amount",
                                  "Fund Order Status"]),
            ("29", "Order Exception", ["Exception Fund Order", "Order Exception Type", "Exception Raised Timestamp",
                                       "Blocking Account Restriction", "Exception Status", "Exception Resolved Timestamp"]),
            ("29", "Account Monitoring Alert", ["Account Monitoring Alert ID", "Monitoring Alert Category", "Alert Account",
                                                "Alert Generated Timestamp"]),
            ("29", "Alert Disposition", ["Disposition Date", "Alert Resulting Account Restriction"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share"]),
            ("27", "Fund NAV Calculation", ["Valuation Date", "NAV Approval Status", "NAV Version Number"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("02", "Party", ["Party ID"]),
            ("02", "Trusted Contact Designation", ["Trusted Contact Designation ID", "Designating Client", "Designation Status",
                                                   "Account Scope", "Designation Effective From", "Designation Effective To"]),
            ("50", "Money Movement Hold", ["Paired Account Restriction", "Hold Status"]),
        ],
        upstream=["DP-580", "DP-093", "DP-240", "DP-322", "DP-456", "DP-180", "DP-165", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on D+1, after DP-580 locks business date D; restrictions placed or lifted during the day appear in the next run",
        history="Daily snapshots kept 6 years and restrictions kept as SCD type 2 for 6 years after they are lifted (SEC Rule 17Ad-7 transfer agent records); account-level hold rows follow the same period",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Restricted Account, Register Account, Posting Account and Order Account resolves to an active DP-093 account, every Governing Account Restriction and Blocking Account Restriction to a restriction key DP-093 publishes, every Register Share Class to a DP-004 share class, and every Paired Account Restriction to a pair DP-456 publishes.",
            "On every Account Restriction, Account Restriction Lifted Date is on or after Account Restriction Effective From, and no account has two restrictions in force with the same Account Restriction Type and Restriction Scope on the same date.",
            "On the as-of date every Share Register Balance row with Restricted Shares > 0 has an Active Register Restriction on its Register Account, and every Active Register Restriction with Restriction Scope in (Sale / Redemption, All Activity) governs Restricted Shares > 0 on that account's rows (zero tolerance; breaks are Restricted Shares Without Governing Restriction), and the share totals equal DP-580's Escrowed, Pledged or Restricted Shares within 0.001 shares.",
            "Account Restriction Type, Restriction Scope and Account Restriction Effective From are populated on every restriction in force on a registered account, and Blocking Account Restriction is populated on every Order Exception with Order Exception Type = Restricted Account.",
            "No row with Account Restriction Type = Financial Exploitation, no Order Exception or alert-placed hold tied to such a restriction and no Account Monitoring Alert with Monitoring Alert Category = Fraud - Elder Financial Exploitation is present in any published table (extraction filters, tested by a zero-row check); AML / Sanctions restrictions, the Imposed By value AML / Financial Crimes and holds from AML - Suspicious Activity or Sanctions alerts appear only in the compliance view and as Compliance Hold elsewhere; no Restriction Review Due Date, Account Restriction ID, Alert Disposition value or rationale column exists; aggregates suppress cells under 10 accounts.",
            "The run for business date D completes by 7am ET on D+1 against the DP-580 register locked for D, and a restriction placed or lifted after the lock is reported in the next run, never by changing a published snapshot.",
        ],
        notes=("Certified numbers: none owned; NAV per Share is read from DP-165 only to value blocked shares, and the value is "
               "never Client Assets or Firm AUM. Operating model (CD-297, CD-331): in-house transfer agent (reference default); "
               "outsourced, the provider's restriction and register files are received records and the TA hold desk keeps "
               "oversight; the grain is unchanged. PII tier: financial. Account-level hold rows carry account keys and share "
               "counts; party names, TINs and dates of birth are not joined in; aggregates suppress cells under 10 accounts "
               "(DQ5, the C-3 minimum cell). No special-category row remains, so the classification is Confidential - Personal "
               "Data (fix-pass ruling). Special category (CW-213, CD-344): rows with Account Restriction Type = Financial "
               "Exploitation are filtered at extraction and never published or counted (the DP-307 extraction-filter "
               "precedent; C-4 fix-pass ruling 1); the 29 alert category Fraud - Elder Financial Exploitation is filtered the "
               "same way (the same ruling applied to the matching alert attribute; noted for the lead). Restriction Review "
               "Due Date and Account Restriction ID are not read (both special category on Rule 2165 rows), so restriction "
               "keys on register rows, order exceptions and alerts are matched to the keys DP-093 publishes for the remaining "
               "rows. The product never reads 02 Specified Adult Status, 02 Vulnerability Concern or 08 Senior Investor Case. "
               "The Rule 2165 hold clock, its 15, 25 and 55 business-day limits and the case counts are DP-403's; DP-322 publishes "
               "the restriction rows only. AML treatment: AML / Sanctions restrictions, the AML / "
               "Financial Crimes Imposed By value and holds from AML and sanctions alerts are kept out of wide aggregates, in "
               "line with the F3 ruling on DP-302 and DP-456. Candidate objects dropped: 08 Senior Investor Case (special "
               "category; DP-403 and DP-322 read it). Boundaries (CW-264): holds on registered shares and redemptions are "
               "counted here; cash-movement holds are BWO DP-456's and the client protection register CLA-A DP-322's. The hold "
               "pair is taken from what DP-456 publishes ('Holds Paired With Account Restriction': the Paired Account "
               "Restriction and Hold Status of its Open Cash Movement Holds, AML holds excluded), never from 50 Money Movement "
               "Hold rows directly; pairs on excluded Financial Exploitation restrictions drop out. AML, sanctions and fraud "
               "alert analytics stay with DP-180 (RESPEC DP-180 moves the register holds here); its dispositions are read only "
               "for the restriction they placed. Fund order exceptions other than restrictions are DP-177's. The register is "
               "DP-580's (CW-261). Acceptance question 7: DP-583 is a reader of the answering product DP-456 (over DP-322), not "
               "a feeder; it adds the register side of a held redemption through Register Holds With Paired Payment Hold "
               "(from DP-456) (29, 15, 50); the lead amends WP1_Scope. Tailoring lever: Rule 2165 hold limits. Reference "
               "default: 15 business days, extended to 25 and to 55 in total once a report is made (FINRA Rule 2165(b)(3)), "
               "held and tested in DP-403. Tailoring lever: holds on fund-only accounts. Reference default: fund-only accounts "
               "kept (DP-580 lever); a firm that converts them to brokerage accounts takes securities holds from 15 on 49 "
               "holdings and drops the register measures. Tailoring lever: outsourced TA. Reference default: in house. "
               "Taxonomy gap: 29 Share Register Balance has no restricted-share link back to the monitoring alert; the alert "
               "is joined through Alert Account and Alert Resulting Account Restriction. Drafting assumptions: the "
               "restriction-scope to movement match (Sale / Redemption for redemptions, Exchange Out, Transfer Out, All "
               "Activity for every outbound movement); age bands; the 7am ET timeliness. Decisions: CW-007, CW-122, CW-213, "
               "CW-261, CW-264, CD-297, CD-344. WP1 new (CW-264): new consumer product of the FOP brief; adds 29 Fund Order, "
               "Order Exception and Register Transaction facts (from DP-580 and the 29 order exceptions) and 15 Account Party "
               "Role for the flag join; reads 02 Trusted Contact Designation through DP-240 (PII - identity, not special "
               "category); its Account Scope is read from 02 directly because DP-240 does not publish it (DP-240 should add it "
               "at WP2). Fix pass: Financial Exploitation rows excluded at extraction; 'Restrictions Past Review Date' and "
               "'Protected Register Holds Past Review Date' dropped; 'Restricted Registered Shares' renamed 'Escrowed, Pledged "
               "or Restricted Shares (from DP-580)'; the pair measure renamed 'Register Holds With Paired Payment Hold (from "
               "DP-456)'."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-585": dict(
        definition=("The requests the transfer agent makes of intermediaries that hold own-fund shares in omnibus and networked "
                    "accounts on the DP-580 register: SEC Rule 22c-2 shareholder information requests with their response "
                    "timeliness and the trading restrictions they lead to, and the beneficial owner distribution and NOBO list "
                    "requests behind each shareholder communication and proxy mailing. It joins the requests to the 05 "
                    "dealer setup and distribution agreement of each intermediary (DP-005) and to the 13 communications they "
                    "serve (DP-382). Transfer agency and the intermediary channel use it to chase late intermediaries and "
                    "to show the fund board that the market-timing and shareholder-communication obligations were met. It owns "
                    "no certified metric family."),
        business_questions=[
            "Which information requests rest on no active shareholder information agreement, and which frequent trading cases on omnibus accounts had no request behind them?",
            "Which Rule 22c-2 information requests are overdue, and how long do intermediaries take to respond?",
            "How many requests led to a restriction instruction, and how many trading restrictions on omnibus accounts are in force for market timing?",
            "For each shareholder communication, were the beneficial owner distribution requests sent to every intermediary and confirmed before the delivery deadline?",
            "Which NOBO list requests were made, for which permitted use, and which intermediaries have not confirmed distribution?",
        ],
        grain=("Shareholder information request (request x intermediary x request period), with intermediary distribution "
               "request (communication x intermediary, BOD-) and its NOBO list detail as a second fact, and the omnibus "
               "register accounts (from DP-580) as the population; monthly snapshots and daily request status"),
        dimensions=["Intermediary (DP-001)", "Intermediary dealer setup and agreement (DP-005)", "Omnibus account (DP-093)",
                    "Share class (DP-004)", "Register Account Category (DP-580)", "Request period and response due date",
                    "Shareholder communication and audience (DP-382)", "Beneficial owner holding model", "As-of date (DP-013)"],
        measures=[
            ("Information Requests Issued",
             "Count of Shareholder Information Requests with Request Period End Date in the period, by Requested Intermediary, "
             "Requested Share Classes and the presence of a Related Frequent Trading Case.",
             _u("29", "Shareholder Information Request", "Information Request Reference", "Requested Intermediary",
                "Requested Share Classes", "Request Period End Date", "Related Frequent Trading Case")),
            ("Overdue Information Requests",
             "Requests with Response Due Date before the as-of date and Response Received Date blank, by Requested Intermediary, "
             "with business days overdue and the Information Request Status.",
             _u("29", "Shareholder Information Request", "Information Request Reference", "Requested Intermediary",
                "Response Due Date", "Response Received Date", "Information Request Status")),
            ("Request Response Timeliness %",
             "Requests with Response Received Date on or before Response Due Date / requests with Response Due Date in the "
             "period, by Requested Intermediary.",
             _u("29", "Shareholder Information Request", "Response Due Date", "Response Received Date", "Requested Intermediary")),
            ("Average Response Days",
             "Mean business days from Request Period End Date to Response Received Date for requests answered in the period, "
             "by Requested Intermediary (DP-013 calendar).",
             _u("29", "Shareholder Information Request", "Request Period End Date", "Response Received Date",
                "Requested Intermediary")),
            ("Requests Without Agreement Reference",
             "Requests whose Shareholder Information Agreement is blank or resolves to a Distribution Agreement with Agreement "
             "Status other than Active on the request date.",
             _u("29", "Shareholder Information Request", "Information Request Reference", "Shareholder Information Agreement")
             + _u("05", "Distribution Agreement", "Agreement ID", "Agreement Type", "Agreement Status")),
            ("Restriction Instructions Sent",
             "Requests with Restriction Instruction Sent Indicator = Y in the period, by Requested Intermediary and the "
             "Action Taken of the Related Frequent Trading Case; the case and its trading test are 08's and are not re-scored.",
             _u("29", "Shareholder Information Request", "Restriction Instruction Sent Indicator", "Related Frequent Trading Case",
                "Requested Intermediary")
             + _u("08", "Frequent Trading Case", "Frequent Trading Case ID", "Action Taken")),
            ("Frequent Trading Cases Without Information Request",
             "Frequent Trading Cases with Look-Back Window End Date in the period on an Account or Omnibus that is an omnibus "
             "register account, that are the Related Frequent Trading Case of no Shareholder Information Request.",
             _u("08", "Frequent Trading Case", "Frequent Trading Case ID", "Account or Omnibus", "Fund Share Class",
                "Look-Back Window End Date")
             + _u("29", "Shareholder Information Request", "Related Frequent Trading Case")
             + _u("29", "Share Register Balance", "Register Account", "Register Account Category")),
            ("Market Timing Restrictions in Force",
             "Count of Account Restrictions with Account Restriction Type = Market Timing in force on the as-of date "
             "(Account Restriction Effective From on or before it, Account Restriction Lifted Date blank or later) on omnibus "
             "register accounts, by Restriction Scope.",
             _u("15", "Account Restriction", "Account Restriction ID", "Restricted Account", "Account Restriction Type",
                "Account Restriction Effective From", "Account Restriction Lifted Date", "Restriction Scope")
             + _u("29", "Share Register Balance", "Register Account", "Register Account Category")),
            ("Distribution Requests per Communication",
             "Count of Intermediary Distribution Requests and sum of Beneficial Owner Account Count by BOD Communication, "
             "Communication Type and Beneficial Owner Holding Model.",
             _u("29", "Intermediary Distribution Request", "Intermediary Distribution ID", "BOD Communication", "Intermediary",
                "Beneficial Owner Holding Model", "Beneficial Owner Account Count")
             + _u("13", "Shareholder Communication", "Communication ID", "Communication Type")),
            ("Intermediaries Not Reached",
             "Per Shareholder Communication whose Communication Distribution has Audience Basis = Beneficial Owners via "
             "Intermediaries: intermediaries with an active Partner Dealer Setup (Dealer Setup Status = Active) whose Account "
             "Structure is omnibus or networked that are the Intermediary of no Intermediary Distribution Request for the "
             "communication; the share-class filter waits for the omnibus-to-intermediary link (see the gap).",
             _u("13", "Shareholder Communication", "Communication ID", "Covered Share Classes")
             + _u("13", "Communication Distribution", "Distribution Job ID", "Distributed Communication", "Audience Basis",
                  "Audience Record Date")
             + _u("29", "Intermediary Distribution Request", "BOD Communication", "Intermediary")
             + _u("05", "Partner Dealer Setup", "Dealer Setup Partner", "Dealer Setup Status", "Account Structure")),
            ("Distributions Confirmed Before Deadline %",
             "Intermediary Distribution Requests with Distribution Confirmed Date on or before the Required Delivery Deadline "
             "of their communication / requests for communications with a deadline in the period; with the communication's "
             "Deadline Met Indicator and Mail Date alongside.",
             _u("29", "Intermediary Distribution Request", "BOD Communication", "Broker Search Date", "Distribution Confirmed Date")
             + _u("13", "Shareholder Communication", "Required Delivery Deadline", "Communication Status")
             + _u("13", "Communication Distribution", "Mail Date", "Deadline Met Indicator")),
            ("NOBO List Requests",
             "Count of Intermediary Distribution Requests with NOBO List Request Date in the period, by NOBO Permitted Use and "
             "Intermediary.",
             _u("29", "NOBO List Request", "NOBO List Request Date", "NOBO Permitted Use")
             + _u("29", "Intermediary Distribution Request", "Intermediary Distribution ID", "Intermediary")),
        ],
        inputs=[
            ("29", "Shareholder Information Request", ["Information Request Reference", "Requested Intermediary",
                                                       "Shareholder Information Agreement", "Omnibus Account Covered",
                                                       "Requested Share Classes", "Request Period Start Date",
                                                       "Request Period End Date", "Response Due Date", "Response Received Date",
                                                       "Information Request Status", "Related Frequent Trading Case",
                                                       "Restriction Instruction Sent Indicator"]),
            ("29", "Intermediary Distribution Request", ["Intermediary Distribution ID", "BOD Communication", "Intermediary",
                                                         "Beneficial Owner Holding Model", "Broker Search Date",
                                                         "Beneficial Owner Account Count", "Distribution Confirmed Date"]),
            ("29", "NOBO List Request", ["NOBO List Request Date", "NOBO Permitted Use"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date",
                                              "Register Account Category", "Registered Shares"]),
            ("08", "Frequent Trading Case", ["Frequent Trading Case ID", "Account or Omnibus", "Fund Share Class",
                                             "Look-Back Window End Date", "Action Taken"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date",
                                           "Restriction Scope"]),
            ("13", "Shareholder Communication", ["Communication ID", "Communication Type", "Communication Regulatory Basis",
                                                 "Covered Share Classes", "Required Delivery Deadline", "Communication Status"]),
            ("13", "Communication Distribution", ["Distribution Job ID", "Distributed Communication", "Audience Basis",
                                                  "Audience Record Date", "Mail Date", "Deadline Met Indicator"]),
            ("05", "Distribution Agreement", ["Agreement ID", "Agreement Type", "Agreement Status"]),
            ("05", "Partner Dealer Setup", ["Dealer Setup Partner", "TA Dealer Number", "Dealer Setup Status", "Account Structure"]),
        ],
        upstream=["DP-580", "DP-005", "DP-001", "DP-382", "DP-093", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="Request status by 8am ET on T+1; the omnibus population and the monthly board view by business day 5 after month-end",
        history="Requests, responses and distribution requests kept 6 years (SEC Rule 17Ad-7 transfer agent records; the Rule 22c-2 agreements themselves are kept under Rule 22c-2(a)(3) and read through DP-005); monthly snapshots kept 6 years; SCD type 2 on request status",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Requested Intermediary and Intermediary resolves to a DP-001 intermediary firm, every Shareholder Information Agreement to a DP-005 Distribution Agreement, every Omnibus Account Covered and Register Account to a DP-093 account, every Requested Share Class to DP-004 and every BOD Communication to a DP-382 Shareholder Communication.",
            "Request Period End Date is on or after Request Period Start Date and Response Due Date is on or after Request Period End Date on every request, and Distribution Confirmed Date is on or after Broker Search Date on every distribution request.",
            "Every Shareholder Information Request with Restriction Instruction Sent Indicator = Y names a Related Frequent Trading Case, and every Omnibus Account Covered is a Register Account whose Register Account Category is Intermediary Omnibus, Networked or Broker-Dealer Omnibus on the Request Period End Date (DP-580); a failing row is listed.",
            "Requested Intermediary, Request Period End Date and Response Due Date are populated on every Shareholder Information Request, and Intermediary, BOD Communication and Beneficial Owner Account Count on every Intermediary Distribution Request.",
            "No published table has a Response Data Load column (column check), Frequent Trading Case rows are published with the case key, share class and Action Taken only, and account-level rows are visible to transfer agency and compliance roles; the board and channel views aggregate to intermediary x share class.",
            "Request status is published by 8am ET on T+1 and the month-end view is locked on business day 5; later responses update the next month's view, never a locked one.",
        ],
        notes=("Certified numbers: none owned; it counts shares and requests, never market value. Operating model (CD-297): "
               "in-house transfer agent (reference default); outsourced, the provider issues the requests and the TA keeps "
               "oversight of the request log as a received record; the grain is unchanged. PII tier: identity. Information "
               "Request Reference and Beneficial Owner Account Count are noted PII because a response can identify a "
               "shareholder; Response Data Load (the shareholder-level response) is not read (DQ5). Boundaries: frequent "
               "trading cases and the trading test are 08's; CLA-B DP-416 (backlog, merge target this product) would score "
               "trading, so the case is read here only for its key, share class and Action Taken, and DP-585 counts the "
               "restriction instructions it sends. Proxy tallies and vote instructions stay with CLA-B DP-408; the communication "
               "and its delivery are DP-382's. Fund order cut-off and omnibus aggregation are DP-177's (from DP-580). The "
               "intermediary profile is 05 through DP-001 and DP-005 (thin channel, CW-021). Candidate upstream DP-177 dropped: "
               "no fund-order fact is read here; candidate upstream DP-240 dropped: intermediaries resolve through DP-001, which "
               "conforms their 02 parties, and no shareholder party is read. Intermediaries without a Rule 22c-2 agreement are "
               "DP-005's 'Dealer Setups Without Rule 22c-2 Agreement', read there and not repeated (fix pass). Tailoring lever: intermediary channel depth (CW-021). Reference default: thin "
               "channel, few omnibus intermediaries; a deeper channel adds intermediaries, not grain. Tailoring lever: "
               "networked sub-accounts (29 SME 2). Reference default: one omnibus account per share class; networked "
               "accounts are counted with the omnibus population. Taxonomy gap: 29 Shareholder Information Request has no "
               "request sent date of its own, so timeliness is measured from Request Period End Date. Taxonomy gap: "
               "Intermediary Distribution Request has no requested quantity of materials or vote material type, so "
               "completeness is tested by intermediary only. Taxonomy gap: no object links an omnibus or networked register account "
               "(29 Share Register Balance.Register Account, 15) to the intermediary that holds it: 05 Agreement Account Link "
               "carries no agreement or party key and 05 Partner Dealer Setup no account, so shares held per intermediary and "
               "the share-class filter of Intermediaries Not Reached cannot be computed (the measure 'Omnibus Shares Held by "
               "Intermediaries' was dropped in the fix pass). Drafting assumptions: Register Account Category values used for "
               "the omnibus population; Account Restriction Type value Market Timing; Audience Basis value Beneficial Owners "
               "via Intermediaries; Account Structure values for omnibus and networked dealers. "
               "Decisions: CW-021, CW-082, CW-122, CW-261, CD-297. WP1 new (CW-261): new consumer product of the FOP brief, "
               "covering the two 29 objects with CDEs no live product read; adds 05 Partner Dealer Setup and Distribution "
               "Agreement and 15 Account Restriction to the candidate's objects. Fix pass: drops 'Omnibus Shares Held by "
               "Intermediaries' and 'Omnibus Intermediaries Without Rule 22c-2 Agreement' (DP-005's) and the 05 Networking "
               "Setup and Agreement Account Link reads."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-586": dict(
        definition=("Daily proof that each own fund's management, administration, 12b-1 and shareholder servicing fee "
                    "accruals in 27 equal the board-approved rates and breakpoints of the 01 fund fee terms (Management Fee, "
                    "Other Ongoing Fees) applied to the net assets of record, that cap and waiver accruals follow the expense "
                    "limitation terms, and that the sub-transfer agency fees the fund pays stay within the board-approved "
                    "Fund-Paid Sub-TA Fee Cap on the intermediary-held assets of the DP-580 register. The fee terms are read "
                    "against the 35 Agreement Fund Schedule and Board Resolution that approved them. The fund treasurer and the "
                    "board use it to catch fee errors before they become NAV errors. It owns no certified metric family; "
                    "expense ratios stay certified in DP-165."),
        business_questions=[
            "Which share classes accrued a management, 12b-1, servicing or administration fee yesterday that differs from the board-approved rate and breakpoints applied to the net assets of record?",
            "Which accruals ran under a fee schedule that has no current board approval, or past the continuation end date of the advisory agreement?",
            "Which classes are waiving less, or more, than the expense limitation terms require, and where does the cap rate applied differ from the terms?",
            "Is the sub-transfer agency fee the fund pays within the board-approved cap on the assets intermediaries service?",
            "Which cumulative fee variances are large enough to be raised as a NAV error case?",
        ],
        grain=("Share class (or fund) x accrual expense type x accrual date, compared with the 01 fee terms in force and the "
               "NAV of record of the prior valuation date; companion rows for cap and waiver accruals (share class x waiver "
               "type x date) and fund-paid sub-TA payments (fund x payment); daily, history kept as published"),
        dimensions=["Fund and share class (DP-004)", "Accrual expense type", "Fee schedule (01, through DP-004)",
                    "Advisory agreement and approval cycle (DP-183)", "Board resolution (DP-182)", "Waiver type",
                    "Accrual date and valuation date (DP-013)"],
        measures=[
            ("Expected Management Fee Accrual",
             "Accrual Basis Amount x the annual rate of the 01 Management Fee schedule named in Applied Fee Schedule (Management "
             "Fee Rate for a flat schedule; for a Fee Breakpoint Schedule, the blended rate of the tiers applied to the fund's "
             "net assets) / 365, for rows with Accrual Expense Type = Management Fee whose terms have Fee Accrual Basis = "
             "Average Net Assets (a Fixed Fee schedule is compared to its fixed amount pro rata).",
             _u("27", "Fund Expense Accrual", "Accrual Share Class", "Expense Accrual Date", "Accrual Expense Type",
                "Applied Fee Schedule", "Accrual Basis Amount")
             + _u("01", "Management Fee", "Management Fee Rate", "Fee Breakpoint Schedule", "Fee Accrual Basis")),
            ("Management Fee Accrual Variance",
             "Accrued Expense Amount - Expected Management Fee Accrual per share class (or fund) and Expense Accrual Date, and "
             "the count of rows whose absolute variance exceeds USD 1 or 0.01% of the expected amount.",
             _u("27", "Fund Expense Accrual", "Accrued Expense Amount") + ["Expected Management Fee Accrual"]),
            ("Fee Rate Applied Differs From Terms",
             "Count of Fund Expense Accrual rows of an asset-based Accrual Expense Type whose Fee Rate Applied differs by more "
             "than 0.0001 percentage points from the rate of the terms (Management Fee Rate or the blended breakpoint rate, "
             "the sum of Distribution (12b-1) Fee Rate and Shareholder Servicing Fee Rate for Distribution and Service Fee, or "
             "Administration / Operating Fee Rate for Administration Fee), or exceeds Maximum Management Fee Rate.",
             _u("27", "Fund Expense Accrual", "Accrual Share Class", "Accrual Expense Type", "Fee Rate Applied")
             + _u("01", "Management Fee", "Management Fee Rate", "Maximum Management Fee Rate", "Fee Breakpoint Schedule")
             + _u("01", "Other Ongoing Fees", "Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate",
                  "Shareholder Servicing Fee Rate")),
            ("Distribution and Servicing Fee Accrual Variance",
             "Per share class and Expense Accrual Date: for Accrual Expense Type = Distribution and Service Fee, Accrued "
             "Expense Amount - Accrual Basis Amount x (Distribution (12b-1) Fee Rate + Shareholder Servicing Fee Rate) / 365 "
             "(the 27 list carries one combined type); for Accrual Expense Type = Administration Fee, the same against "
             "Administration / Operating Fee Rate.",
             _u("27", "Fund Expense Accrual", "Accrual Share Class", "Expense Accrual Date", "Accrual Expense Type",
                "Accrual Basis Amount", "Accrued Expense Amount")
             + _u("01", "Other Ongoing Fees", "Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate",
                  "Shareholder Servicing Fee Rate")),
            ("Accrual Basis Differs From NAV of Record",
             "Count of asset-based accrual rows whose Accrual Basis Amount differs by more than 0.01% from the Class Net Assets "
             "Amount of the Share Class NAV of record (NAV Approval Status = Approved, highest NAV Version Number, as DP-165 "
             "publishes it) of the prior Valuation Date.",
             _u("27", "Fund Expense Accrual", "Accrual Share Class", "Expense Accrual Date", "Accrual Basis Amount")
             + _u("27", "Share Class NAV", "Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation",
                  "Class Net Assets Amount")
             + _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Approval Status", "NAV Version Number")),
            ("Accruals Under Unapproved Schedule",
             "Count of accrual rows whose Applied Fee Schedule is not the Fund Fee Schedule of an Agreement Fund Schedule of the "
             "fund with Fund Approval Outcome in (Initially Approved, Continued, Continued with Fee Reduction, Continued with "
             "Conditions, Continued for Short Term) and Fund Continuation End Date on or after the Expense Accrual Date.",
             _u("27", "Fund Expense Accrual", "Accrual Fund", "Expense Accrual Date", "Applied Fee Schedule")
             + _u("35", "Agreement Fund Schedule", "Schedule Agreement", "Covered Fund", "Fund Fee Schedule",
                  "Fund Approval Outcome", "Fund Continuation End Date")),
            ("Expense Cap Rate Mismatch",
             "Count of Expense Cap & Waiver Accrual rows whose Expense Cap Rate Applied differs from the Expense Cap Rate of the "
             "share class's 01 Cost Disclosure with the latest Cost Reference Date on or before Waiver Accrual Date, or that "
             "accrue a contractual waiver after the Waiver Expiry Date.",
             _u("27", "Expense Cap & Waiver Accrual", "Waiver Share Class", "Waiver Accrual Date", "Waiver Type",
                "Expense Cap Rate Applied")
             + _u("01", "Cost Disclosure", "Expense Cap Rate", "Waiver Expiry Date", "Cost Reference Date")),
            ("Required Waiver Shortfall",
             "Per share class and date: required waiver = the greater of zero and (sum of Accrued Expense Amount of the class "
             "for the date - Expense Cap Rate Applied x Class Net Assets Amount of the NAV of record / 365); shortfall = "
             "required waiver - (Waived Fee Amount + Reimbursed Expense Amount); a negative value is an over-waiver.",
             _u("27", "Fund Expense Accrual", "Accrual Share Class", "Expense Accrual Date", "Accrued Expense Amount")
             + _u("27", "Expense Cap & Waiver Accrual", "Waiver Share Class", "Waiver Accrual Date", "Expense Cap Rate Applied",
                  "Waived Fee Amount", "Reimbursed Expense Amount")
             + _u("27", "Share Class NAV", "Class Net Assets Amount")),
            ("Waivers Without Expense Limitation Terms",
             "Count of 10 Waiver Records with Waiver Type = Contractual Fee Waiver or Expense Reimbursement whose Expense Cap "
             "Terms Reference is blank or does not resolve to the 01 terms of the Supported Share Class.",
             _u("10", "Waiver Record", "Waiver Record ID", "Waiver Type", "Supported Share Class", "Expense Cap Terms Reference")),
            ("Intermediary-Serviced Assets",
             "Per share class and date: Registered Shares of Share Register Balance rows with Register Account Category in "
             "(Intermediary Omnibus, Networked) x NAV per Share of the NAV of record (from DP-165); the asset base the "
             "Fund-Paid Sub-TA Fee Cap applies to, never Firm AUM.",
             _u("29", "Share Register Balance", "Register Share Class", "Register Business Date", "Register Account Category",
                "Registered Shares")
             + _u("27", "Share Class NAV", "NAV per Share")),
            ("Sub-TA Fee Paid Rate (bps)",
             "Per fund and trailing 12 months: sum of Payment Amount of Fund Expense Payments with Payment Expense Type = "
             "Transfer Agency Fee, Fund Payment Status = Paid / Settled and an Expense Payee that is an intermediary firm "
             "(DP-001), not the in-house transfer agent / average Intermediary-Serviced Assets of the fund's classes x 10,000 "
             "(the payee test stands in for a sub-TA expense type; see the gap).",
             _u("27", "Fund Expense Payment", "Fund Payment Reference", "Paying Fund", "Expense Payee", "Payment Expense Type",
                "Payment Amount", "Payment Date", "Fund Payment Status")
             + ["Intermediary-Serviced Assets"]),
            ("Sub-TA Fee Cap Breaches",
             "Funds whose Sub-TA Fee Paid Rate (bps) exceeds the lowest Fund-Paid Sub-TA Fee Cap of their share classes, or, "
             "where the board approved a per-account cap, whose sub-TA payments exceed Fund-Paid Sub-TA Fee Cap Per Account x "
             "the serviced accounts reported; with the excess amount.",
             ["Sub-TA Fee Paid Rate (bps)"]
             + _u("01", "Management Fee", "Fund-Paid Sub-TA Fee Cap", "Fund-Paid Sub-TA Fee Cap Per Account")),
            ("Sub-TA Caps Without Current Board Approval",
             "Share classes with Fund-Paid Sub-TA Fee Cap populated whose Approving Board Resolution is blank, or resolves to a "
             "Board Resolution with Resolution Outcome not in (Adopted, Adopted as Amended) or with Resolution Expiry Date "
             "before the as-of date.",
             _u("01", "Management Fee", "Fund-Paid Sub-TA Fee Cap", "Approving Board Resolution")
             + _u("35", "Board Resolution", "Board Resolution ID", "Resolution Type", "Resolution Outcome",
                  "Resolution Effective Date", "Resolution Expiry Date")
             + _u("01", "Share Class", "Share Class ID", "Share Class Status")),
            ("Cumulative Fee Variance per Share",
             "Per share class: running sum since the last NAV error review of Management Fee Accrual Variance and Distribution "
             "and Servicing Fee Accrual Variance / Shares Outstanding of the NAV of record; classes at or above USD 0.005 per "
             "share are raised to DP-169 as a 27 NAV Error Case, never handled here.",
             ["Management Fee Accrual Variance", "Distribution and Servicing Fee Accrual Variance"]
             + _u("27", "Share Class NAV", "Shares Outstanding")),
        ],
        inputs=[
            ("27", "Fund Expense Accrual", ["Accrual Fund", "Accrual Share Class", "Expense Accrual Date", "Accrual Expense Type",
                                            "Applied Fee Schedule", "Fee Rate Applied", "Accrual Basis Amount",
                                            "Accrued Expense Amount", "Accrued Expense Balance"]),
            ("27", "Expense Cap & Waiver Accrual", ["Waiver Share Class", "Waiver Accrual Date", "Waiver Type",
                                                    "Expense Cap Rate Applied", "Waived Fee Amount",
                                                    "Reimbursed Expense Amount"]),
            ("27", "Fund Expense Payment", ["Fund Payment Reference", "Paying Fund", "Expense Payee", "Payment Expense Type",
                                            "Payment Amount", "Payment Date", "Fund Payment Status"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                                       "Class Net Assets Amount", "Shares Outstanding"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Approval Status", "NAV Version Number"]),
            ("01", "Management Fee", ["Management Fee Rate", "Maximum Management Fee Rate", "Fee Accrual Basis",
                                      "Fee Breakpoint Schedule", "Fund-Paid Sub-TA Fee Cap",
                                      "Fund-Paid Sub-TA Fee Cap Per Account", "Approving Board Resolution"]),
            ("01", "Other Ongoing Fees", ["Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate",
                                          "Shareholder Servicing Fee Rate"]),
            ("01", "Cost Disclosure", ["Expense Cap Rate", "Waiver Expiry Date", "Cost Reference Date"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Status"]),
            ("35", "Agreement Fund Schedule", ["Schedule Agreement", "Covered Fund", "Fund Fee Schedule", "Fund Approval Outcome",
                                               "Fund Continuation End Date"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Resolution Type", "Resolution Outcome",
                                        "Resolution Effective Date", "Resolution Expiry Date"]),
            ("10", "Waiver Record", ["Waiver Record ID", "Waiver Type", "Supported Share Class", "Expense Cap Terms Reference"]),
            ("29", "Share Register Balance", ["Register Share Class", "Register Business Date", "Register Account Category",
                                              "Registered Shares"]),
        ],
        upstream=["DP-165", "DP-004", "DP-170", "DP-183", "DP-182", "DP-580", "DP-001", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET on T+1, after the NAV of record for T is approved in DP-165 and before the T+1 accruals are struck",
        history="Daily comparison rows kept 6 years (SEC Rule 31a-2 fund records), with the fee terms version and NAV of record they were tested against; never restated in place",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Accrual Share Class, Waiver Share Class, Supported Share Class and Register Share Class resolves to an active DP-004 share class, every Applied Fee Schedule and Fund Fee Schedule to 01 fee terms of the same share class or fund, every Approving Board Resolution to a DP-182 Board Resolution and every Schedule Agreement to a DP-183 Fund Advisory Agreement.",
            "The 01 fee terms version tested is the one in force on Expense Accrual Date, and for each fund at most one Agreement Fund Schedule with Fund Approval Outcome = Approved has a Fund Continuation End Date covering any accrual date.",
            "The NAV of record used equals the DP-165 NAV of Record Flag row for the share class and prior Valuation Date, and Intermediary-Serviced Assets uses Registered Shares equal to the DP-580 Look-Through Category Registered Shares of the same categories within 0.001 shares.",
            "Accrual Expense Type, Accrued Expense Amount and Expense Accrual Date are populated on every accrual row, Accrual Basis Amount and Fee Rate Applied on every asset-based row, and Expense Cap Rate Applied on every cap and waiver accrual row.",
            "Every published row is keyed by fund or share class, and no published table has a Register Account, party name or employee key column (column check); Expense Payee appears only as a DP-001 intermediary key.",
            "The comparison for accrual date T is published by 8am ET on T+1 and locked; a correction to an accrual posts as a new accrual row and is compared in the next run.",
        ],
        notes=("Certified numbers: none owned. Class Net Assets Amount, NAV per Share and Shares Outstanding of the NAV of record "
               "are read from DP-165 (CD-330) only as the basis of the test; expense ratios stay certified in DP-165 and are "
               "not computed here. Operating model (CD-297, CD-331): in-house fund accounting (reference default) strikes the "
               "accruals; outsourced, the administrator's accrual file is a received record and this product is the treasurer's "
               "oversight test at the same grain. PII tier: none. pii is N although 29 Registered Shares is noted PII: only share class x Register Account Category totals are read for the serviced asset base, never Register Account, so no account-level value enters or leaves the product. The fund fee terms are 01 (Management Fee, Other Ongoing Fees, "
               "Cost Disclosure; the FSCH- fee schedule), typed Reference (Management Fee, 01); the 47 client Fee Schedule is "
               "never read (CW-051). DP-004 does not yet publish the 01 Management Fee and Other Ongoing Fees groups, so they are "
               "read from 01 directly and keyed through DP-004; DP-004 should publish them at WP2. Boundaries: DP-170 keeps "
               "budgets, payments, cap headroom and waiver tie-outs; accrual-to-terms testing moves here (RESPEC DP-170), so "
               "DP-170's 'Fee Rate Exceptions' should leave DP-170 at its re-spec. A variance over the NAV error threshold is "
               "raised as a 27 NAV Error Case in DP-169, never resolved here. Sub-TA payments to intermediaries are recorded "
               "on the fund side in 27; the intermediary payment arrangements (05 Sub-Accounting Fee Terms) are DIS DP-487's, "
               "so the cap is tested against the 01 terms the board approved. The Section 15(c) review of the advisory fee is "
               "DP-183's and INV DP-538's. Tailoring lever: fund accounting outsourced. Reference default: in house. Tailoring "
               "lever: sub-TA cap basis. Reference default: basis points of intermediary-serviced assets; a board that approves "
               "a per-account cap uses Fund-Paid Sub-TA Fee Cap Per Account. Taxonomy gap: 27 Fund Expense Type has no "
               "sub-transfer agency value (only Transfer Agency Fee, which also covers the in-house TA fee), so sub-TA payments "
               "are isolated by an intermediary Expense Payee. Taxonomy gap: 27 Fund Expense Payment has no share "
               "class and no serviced period or serviced account count, so the sub-TA cap is tested at fund level over a "
               "trailing 12 months and the per-account variant has no count to multiply. Taxonomy gap: 01 Fee Breakpoint "
               "Schedule is a reference to fee tiers with no tier rows readable here; the blended rate is re-derived from the "
               "27 Fee Rate Applied rule of the terms. Code values are from the 27 Fund Expense Type, Shared: Outgoing "
               "Payment Status, 35 Fund Contract Approval Outcome and Board Resolution Outcome lists. Drafting assumptions: "
               "the intermediary payee test; tolerances "
               "of USD 1, 0.01% and 0.0001 percentage points; the USD 0.005 per share escalation threshold; 365-day count. "
               "Decisions: CW-051, CW-159, CW-261, CD-297, CD-330. WP1 new (CW-261): new consumer product of the FOP brief; "
               "adds 01 Cost Disclosure and Share Class, 27 Fund NAV Calculation and 29 Share Register Balance (for the "
               "serviced asset base) to the candidate's objects. Fix pass: code values aligned to the "
               "real lists; Distribution and Service Fee compared to the sum of the two 01 rates; DP-001 added upstream for the "
               "payee test."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-588": dict(
        definition=("For each declared own-fund distribution (27, through DP-171), proof that every account registered at the "
                    "transfer agent on the record date received its reinvestment posting at the reinvest NAV, that the "
                    "broker-dealer omnibus reinvestment was allocated in full to the brokerage client entitlements and "
                    "dividend reinvestments of the 49 book (DP-300), and that the shares and amounts posted tie to the "
                    "declared distribution. Transfer agency and fund accounting use it to close each distribution cycle "
                    "without unallocated residue. Distribution amounts and tax character stay DP-171's; it owns no certified "
                    "metric family."),
        business_questions=[
            "For this distribution, do the reinvestments and withholding posted on the register tie to the declared amount, and where is the residue?",
            "Which registered accounts held shares on the record date but received no reinvestment posting?",
            "Which reinvestments posted at a price other than the reinvest NAV, late, or as-of?",
            "Was the broker-dealer omnibus reinvestment allocated in full to the brokerage clients entitled, in shares and in cash?",
            "Do the record-date shares of the brokerage clients equal the omnibus register balance on the record date?",
        ],
        grain=("Distribution declaration (FDIV-) x register account, with the declaration-level tie-out and the omnibus "
               "allocation (declaration x broker-dealer omnibus account x 49 entitlement) as companion facts; one row per "
               "cycle, closed when the cycle closes"),
        dimensions=["Distribution declaration and distribution type (DP-171)", "Share class (DP-004)",
                    "Register account (DP-093)", "Register Account Category (DP-580)", "Record date, ex-date and payable date (DP-013)",
                    "Corporate action event (DP-099)", "Exception type"],
        measures=[
            ("Distribution Amount (from DP-171)",
             "The Distribution Amount DP-171 publishes per declaration, read and never recomputed here; traced to the 27 "
             "attributes DP-171 computes it from (Distribution Rate per Share and Shares Outstanding of the NAV of record of "
             "the Declaring Share Class on the Record Date).",
             _u("27", "Distribution Declaration", "Distribution Declaration ID", "Declaring Share Class", "Record Date",
                "Distribution Rate per Share")
             + _u("27", "Share Class NAV", "NAV Share Class", "Shares Outstanding")),
            ("Record-Date Registered Shares",
             "Sum of Registered Shares of Share Register Balance rows of the Declaring Share Class with Register Business Date = "
             "Record Date, by Register Account Category.",
             _u("29", "Share Register Balance", "Register Account", "Register Share Class", "Register Business Date",
                "Register Account Category", "Registered Shares")
             + _u("27", "Distribution Declaration", "Record Date")),
            ("Capital Stock Proof Difference on Record Date (from DP-181)",
             "The Capital Stock Proof Difference DP-181 publishes for the Declaring Share Class with Control Business Date = "
             "Record Date (TA Control Check of TA Control Type = Capital Stock Proof, its Control Difference and Control "
             "Result), read and never recomputed; a non-zero proof on the record date means the record-date shares the "
             "postings are tested against are not proven.",
             _u("29", "TA Control Check", "TA Control Check ID", "TA Control Type", "Control Share Class",
                "Control Business Date", "Control Difference", "Control Result")
             + _u("27", "Distribution Declaration", "Record Date")),
            ("Reinvestment Shares and Amount Posted",
             "Count, sum of Shares Posted, Gross Amount, Tax Withheld Amount and Net Amount of Register Transactions with "
             "Register Transaction Type in (Dividend Reinvestment, Capital Gain Reinvestment), Register Transaction Status = "
             "Posted and Originating Distribution Declaration = the declaration, by Register Account Category.",
             _u("29", "Register Transaction", "Register Transaction ID", "Register Transaction Type", "Posting Account",
                "Shares Posted", "Gross Amount", "Tax Withheld Amount", "Net Amount", "Originating Distribution Declaration",
                "Register Transaction Status")),
            ("Distribution Posting Residue",
             "Distribution Amount (from DP-171) - Gross Amount of Reinvestment Shares and Amount Posted, per "
             "declaration; the residue is the cash distributions and unposted entitlements, reported until the cycle closes.",
             ["Distribution Amount (from DP-171)", "Reinvestment Shares and Amount Posted"]),
            ("Expected Account Distribution",
             "Per register account, for declarations with Daily Dividend Indicator = N only: Registered Shares on the Record "
             "Date x Distribution Rate per Share; the account-level expectation the postings are matched to (daily-dividend "
             "classes accrue on each day's shares, see the gap).",
             _u("29", "Share Register Balance", "Register Account", "Registered Shares")
             + _u("27", "Distribution Declaration", "Distribution Rate per Share", "Daily Dividend Indicator")),
            ("Registered Accounts Without Reinvestment Posting",
             "Count of register accounts with Registered Shares > 0 on the Record Date that are the Posting Account of no posted "
             "reinvestment Register Transaction for the declaration by Payable Date + 1 business day, excluding accounts whose "
             "cash payment is evidenced (see notes), by Register Account Category.",
             _u("29", "Share Register Balance", "Register Account", "Registered Shares", "Register Business Date")
             + _u("29", "Register Transaction", "Posting Account", "Originating Distribution Declaration")
             + _u("27", "Distribution Declaration", "Payable Date")),
            ("Account Posting Differences",
             "Per register account, for non-daily declarations: Gross Amount of its reinvestment postings for the declaration "
             "- Expected Account Distribution; count of accounts with an absolute difference above USD 0.01.",
             ["Expected Account Distribution"]
             + _u("29", "Register Transaction", "Posting Account", "Gross Amount", "Originating Distribution Declaration")),
            ("Reinvest Price Exceptions",
             "Count of posted reinvestment Register Transactions whose Price per Share Applied differs from the Reinvest NAV of "
             "the declaration by more than 0.00005.",
             _u("29", "Register Transaction", "Register Transaction ID", "Price per Share Applied",
                "Originating Distribution Declaration")
             + _u("27", "Distribution Declaration", "Reinvest NAV")),
            ("Late or As-Of Reinvestments",
             "Count of posted reinvestment Register Transactions with Register Trade Date other than the Payable Date (or the "
             "Ex-Date for daily dividend share classes, Daily Dividend Indicator = Y), or As-Of Posting Indicator = Y.",
             _u("29", "Register Transaction", "Register Transaction ID", "Register Trade Date", "Posting Date",
                "As-Of Posting Indicator")
             + _u("27", "Distribution Declaration", "Payable Date", "Ex-Date", "Daily Dividend Indicator")),
            ("Omnibus Allocation Difference",
             "Per declaration and broker-dealer omnibus account: Shares Posted of its reinvestment Register Transaction - sum of "
             "Reinvested Shares of the Dividend Reinvestment Allocations of the 49 Client Corporate Action Entitlements whose "
             "Entitlement Event is the 17 Corporate Action Event of the same instrument (Own Share Class) and Record Date; and "
             "Gross Amount of the omnibus posting - sum of Entitled Cash Amount of those entitlements.",
             _u("29", "Register Transaction", "Posting Account", "Shares Posted", "Gross Amount",
                "Originating Distribution Declaration")
             + _u("49", "Client Corporate Action Entitlement", "Client Corporate Action Entitlement ID", "Entitlement Event",
                  "Entitled Cash Amount")
             + _u("49", "Dividend Reinvestment Allocation", "Reinvested Shares", "Reinvestment Price", "Reinvestment Date")
             + _u("17", "Corporate Action Event", "Corporate Action Event ID", "Event Instrument", "Record Date")
             + _u("17", "Instrument", "Instrument ID", "Own Share Class")),
            ("Unallocated Omnibus Residue",
             "Count of declarations with a non-zero Omnibus Allocation Difference (shares beyond 0.001, cash beyond USD 0.01) "
             "after Payable Date + 1 business day, and the residue amount.",
             ["Omnibus Allocation Difference"] + _u("27", "Distribution Declaration", "Payable Date")),
            ("Brokerage Record-Date Quantity Difference",
             "Registered Shares of the Broker-Dealer Omnibus row on the Record Date - sum of Record Date Client Holding Quantity "
             "of the matching 49 Client Corporate Action Entitlements; a record-date unit break, raised to BWO DP-446.",
             _u("29", "Share Register Balance", "Register Account Category", "Registered Shares", "Register Business Date")
             + _u("49", "Client Corporate Action Entitlement", "Entitlement Event", "Record Date Client Holding Quantity")),
            ("Client Entitlements Unpaid After Payable Date",
             "Count of matching 49 Client Corporate Action Entitlements with Entitlement Payment Date before the as-of date and "
             "Payment Activity blank.",
             _u("49", "Client Corporate Action Entitlement", "Client Corporate Action Entitlement ID", "Entitlement Payment Date",
                "Payment Activity", "Entitlement Status")),
        ],
        inputs=[
            ("27", "Distribution Declaration", ["Distribution Declaration ID", "Declaring Share Class", "Distribution Type",
                                                "Daily Dividend Indicator", "Record Date", "Ex-Date", "Payable Date",
                                                "Distribution Rate per Share", "Reinvest NAV"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "Shares Outstanding"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date",
                                              "Register Account Category", "Registered Shares"]),
            ("29", "TA Control Check", ["TA Control Check ID", "TA Control Type", "Control Share Class", "Control Business Date",
                                        "Control Difference", "Control Result"]),
            ("29", "Register Transaction", ["Register Transaction ID", "Register Transaction Type", "Posting Account",
                                            "Posting Share Class", "Register Trade Date", "Posting Date", "As-Of Posting Indicator",
                                            "Shares Posted", "Price per Share Applied", "Gross Amount", "Tax Withheld Amount",
                                            "Net Amount", "Originating Distribution Declaration", "Register Transaction Status"]),
            ("49", "Client Corporate Action Entitlement", ["Client Corporate Action Entitlement ID", "Entitlement Event",
                                                           "Entitled Account", "Record Date Client Holding Quantity",
                                                           "Entitled Cash Amount", "Entitlement Payment Date", "Payment Activity",
                                                           "Entitlement Status"]),
            ("49", "Dividend Reinvestment Allocation", ["Reinvested Amount", "Reinvested Shares", "Reinvestment Price",
                                                        "Reinvestment Date", "Resulting Client Tax Lot"]),
            ("17", "Corporate Action Event", ["Corporate Action Event ID", "Event Instrument", "Ex-Date", "Record Date",
                                              "Corporate Action Payment Date"]),
            ("17", "Instrument", ["Instrument ID", "Own Share Class"]),
            ("15", "Account", ["Account ID", "Account Type"]),
        ],
        upstream=["DP-580", "DP-171", "DP-181", "DP-165", "DP-300", "DP-099", "DP-097", "DP-093", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET on the business day after Payable Date for the cycle, then daily until the cycle closes with no residue",
        history="Each cycle's tie-out and exception rows kept 6 years (SEC Rule 17Ad-7 and Rule 31a-2); cycles kept as closed, never restated",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Originating Distribution Declaration resolves to a DP-171 Distribution Declaration, every Posting Account and Register Account to a DP-093 account, every Entitlement Event to a DP-099 Corporate Action Event and every Declaring Share Class to a DP-004 share class that is the Own Share Class of a DP-097 instrument.",
            "On every declaration Record Date is on or before Payable Date and Ex-Date, and Register Trade Date of every reinvestment posting is on or after Ex-Date.",
            "Per declaration, Gross Amount of Reinvestment Shares and Amount Posted plus the cash residue equals Distribution Amount (from DP-171) within USD 1, and the Omnibus Allocation Difference is zero within 0.001 shares and USD 0.01 when the cycle closes.",
            "Distribution Rate per Share, Record Date, Payable Date and Reinvest NAV are populated on every declaration, and Originating Distribution Declaration, Shares Posted and Price per Share Applied on every reinvestment Register Transaction.",
            "Account-level exception rows carry account keys and amounts only and are visible to transfer agency and fund accounting roles; the cycle view aggregates to declaration x Register Account Category.",
            "A cycle is published by 9am ET on the business day after Payable Date and locked when its residue reaches zero; later corrections post as new Register Transactions and reopen the cycle as a new version.",
        ],
        notes=("Certified numbers: none owned; Shares Outstanding is read from DP-165 and the distribution amount and character "
               "from DP-171 (27). Operating model (CD-297, CD-331): in-house transfer agent (reference default); outsourced, "
               "the provider's posting file is a received record and the tie-out is the TA oversight test at the same grain. "
               "PII tier: financial. Account-level exception rows are personal data; the cycle view carries none. Books "
               "(CW-007): the register (29, DP-580) for TA-registered accounts and the omnibus rows; Client Holding (49, DP-300) "
               "for the brokerage look-through; Fund Shareholder Position (06) is never read. Boundaries: DP-171 keeps "
               "distribution amounts, character, excise and RIC tests and reads reinvestment postings from DP-580 (RESPEC "
               "DP-171); completeness moves here. The record-date unit break is raised to BWO DP-446 (stock record "
               "reconciliation), which owns the omnibus unit proof; corporate action processing of client accounts is BWO "
               "DP-452's. Candidate object dropped: 15 Account Standing Instruction, which carries no distribution option "
               "(see the gap). Tailoring lever: fund-only accounts. Reference default: kept, none opened; converting them to "
               "brokerage accounts moves the whole test to the omnibus allocation. Tailoring lever: daily dividend funds. "
               "Reference default: money market and bond funds accrue daily and reinvest monthly at the Payable Date. "
               "Taxonomy gap: 15 has no distribution option (reinvest or cash) for a TA-registered account, and 29 Register "
               "Transaction Type and 50 Movement Source Type have no cash-distribution value or link to the 27 declaration, so "
               "cash distributions to fund-only shareholders cannot be traced; they remain in Distribution Posting Residue and "
               "the accounts paid in cash are excluded from Registered Accounts Without Reinvestment Posting only once that "
               "link exists. Taxonomy gap: 29 has no daily accrual record per "
               "account for daily-dividend share classes, so their account-level postings cannot be re-performed; only the "
               "declaration-level residue is tested for them. Taxonomy gap: 49 Client Corporate Action Entitlement references a 17 Corporate Action Event, not "
               "the 27 Distribution Declaration; the match is by instrument (Own Share Class) and Record Date. Drafting "
               "assumptions: tolerances of 0.001 shares, USD 0.01 per account and USD 1 per declaration; the 0.00005 price "
               "tolerance; Payable Date + 1 business day. Decisions: CW-007, CW-106, CW-122, CW-261, CD-297. WP1 new (CW-261): "
               "new consumer product of the FOP brief; adds 27 Share Class NAV, 17 Corporate Action Event and Instrument and "
               "15 Account to the candidate's objects. Fix pass: 'Declared Distribution Amount (from DP-171)' renamed 'Distribution "
               "Amount (from DP-171)' and read; 'Record-Date Shares Tie to Shares Outstanding' replaced by 'Capital Stock Proof "
               "Difference on Record Date (from DP-181)' (DP-181 listed upstream, 29 TA Control Check added); account-level "
               "expectation limited to non-daily classes."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-595": dict(
        definition=("The Regulation S-P safeguards and incident response programs and the Regulation S-ID identity theft "
                    "prevention programs (41 Information Security Program) that must cover each broker-dealer, investment "
                    "adviser, transfer agent and fund entity of the firm, with the security incidents that compromised "
                    "sensitive customer information (41, through DP-232), the 30-day customer notification test of amended "
                    "Regulation S-P against the notifications actually sent (37 Incident Regulatory Notification, through "
                    "DP-215), the incidents reported by service providers, and the annual program reviews and board reports "
                    "(38, through DP-224). The CISO and compliance use it for the Reg S-P and Reg S-ID program reviews and the "
                    "board report. It counts programs and incidents only, reads no client record and owns no certified metric "
                    "family."),
        business_questions=[
            "Is every entity that holds customer information covered by an approved Reg S-P incident response program and, where it holds covered accounts, a Reg S-ID program?",
            "Which programs are overdue for their annual review or board report, or were not in place by the compliance date?",
            "For each incident that compromised sensitive customer information, was the notification determination made and the customer notice sent within 30 days of becoming aware?",
            "Which incidents were reported to us by service providers, and how many affected our clients?",
            "Did each entity complete its Reg S-P program review and Reg S-ID annual report this year, and what material matters did they raise?",
        ],
        grain=("Information security program (program code) x covered legal entity x as-of date, with security incidents "
               "involving client information (IT incident of class Security Event) and their regulatory notifications as "
               "companion facts; monthly snapshots and daily incident status"),
        dimensions=["Legal entity and entity type (DP-013)", "Entity authorization type (DP-222)", "Security program type",
                    "Incident detected month", "Customer notification determination", "Notification regime and stage",
                    "Notifying service provider (DP-210)", "Program review type (DP-224)"],
        measures=[
            ("Covered Entities Without Reg S-P Program",
             "Count of covered entities that are in the Covered Legal Entities of no Information Security Program with Security "
             "Program Type = Regulation S-P Safeguards and Incident Response and Security Program Status = Active. Covered "
             "entities: Internal Legal Entities with Entity Status active and an Entity Authorization with Authorization Status "
             "in (Registered, Authorized) and Authorization Type in (Broker-Dealer Registration and FINRA Membership, SEC "
             "Investment Adviser Registration, Transfer Agent Registration (Form TA-1)); and the fund registrants (Entity "
             "Category = Fund Trust (registrant)) of 01 Investment Products with Vehicle Type in (Open-Ended Fund, "
             "Exchange-Traded Fund, Closed-End Fund, Interval Fund) and Regulatory Regime = US 1940 Act Registered (no "
             "authorization type exists for a registered fund; see the gap).",
             _u("09", "Internal Legal Entity", "Legal Entity ID", "Entity Category", "Entity Status")
             + _u("38", "Entity Authorization", "Authorized Entity", "Authorization Type", "Authorization Status")
             + _u("01", "Investment Product", "Product ID", "Vehicle Type") + _u("01", "Fund Legal Structure", "Regulatory Regime")
             + _u("41", "Information Security Program", "Security Program Code", "Security Program Type",
                  "Covered Legal Entities", "Security Program Status")),
            ("Covered Entities Without Reg S-ID Program",
             "Count of the broker-dealer, investment adviser and fund registrant entities selected as in Covered Entities "
             "Without Reg S-P Program (the transfer agent left out) that are in the Covered Legal Entities of no program with "
             "Security Program Type = Regulation S-ID Identity Theft Prevention and Security Program Status = Active.",
             _u("09", "Internal Legal Entity", "Legal Entity ID", "Entity Category", "Entity Status")
             + _u("38", "Entity Authorization", "Authorized Entity", "Authorization Type", "Authorization Status")
             + _u("41", "Information Security Program", "Security Program Type", "Covered Legal Entities",
                  "Security Program Status")),
            ("Programs Overdue for Review or Board Report",
             "Active Reg S-P and Reg S-ID programs whose Program Last Review Date or Last Board Report Date is more than 12 "
             "months before the as-of date, or blank.",
             _u("41", "Information Security Program", "Security Program Code", "Security Program Type",
                "Program Last Review Date", "Last Board Report Date", "Security Program Status")),
            ("Programs Not Approved by Compliance Date",
             "Active Reg S-P programs whose Program Approval Date is blank or later than Program Compliance Date, or whose "
             "Program Policy is blank or resolves to a Policy with Policy Status other than active.",
             _u("41", "Information Security Program", "Security Program Code", "Program Approval Date", "Program Compliance Date",
                "Program Policy")
             + _u("38", "Policy", "Policy ID", "Policy Regulatory Basis", "Policy Status")),
            ("Client Information Incidents",
             "Count of IT Incidents with Incident Class = Security Event and Sensitive Customer Information Compromised "
             "Indicator = Y or Personal Data Affected Indicator = Y, by Became Aware Date month, Affected Legal Entities and "
             "Customer Notification Determination, with the sum of Affected Individuals Estimate.",
             _u("41", "IT Incident", "IT Incident ID", "Incident Class", "Affected Legal Entities")
             + _u("41", "Security Incident Detail", "Personal Data Affected Indicator",
                  "Sensitive Customer Information Compromised Indicator", "Affected Individuals Estimate", "Became Aware Date",
                  "Customer Notification Determination")),
            ("Determinations Past Notice Window",
             "Client Information Incidents with Customer Notification Determination = Under Investigation whose Customer Notice "
             "Due Date is before the as-of date, or whose Customer Notification Determination Date is after Customer Notice "
             "Due Date.",
             ["Client Information Incidents"]
             + _u("41", "Security Incident Detail", "Customer Notification Determination", "Customer Notification Determination Date",
                  "Customer Notice Due Date")),
            ("Customer Notices Sent On Time %",
             "Incidents with Customer Notification Determination = Notification Required that have an Incident Regulatory "
             "Notification with Incident Notification Regime = Regulation S-P Customer Notification whose Notification Sent "
             "Timestamp date is on or before Customer Notice Due Date (extended where Attorney General Delay Indicator = Y) / "
             "incidents with Notification Required; the 41 incident joins the 37 notification through the Incident Source "
             "Record of the operational incident.",
             _u("41", "Security Incident Detail", "Customer Notification Determination", "Customer Notice Due Date",
                "Attorney General Delay Indicator")
             + _u("41", "IT Incident", "IT Incident ID")
             + _u("37", "Incident Source Record", "Source Incident", "Incident Source Type", "Source IT Incident")
             + _u("37", "Incident Regulatory Notification", "Notified Incident", "Incident Notification Regime",
                  "Notification Sent Timestamp")),
            ("Late Regulatory and State Notifications",
             "Count of Incident Regulatory Notifications of client information incidents with Incident Notification Regime in "
             "(State Breach Notification, SEC or Other Regulator Notification, FINRA Rule 4530 Report) whose Notification Sent "
             "Timestamp is after Notification Deadline Timestamp or blank past it, by Notification Authority and Notifying "
             "Legal Entity.",
             _u("37", "Incident Regulatory Notification", "Notified Incident", "Notification Authority",
                "Incident Notification Regime", "Incident Notification Stage", "Notifying Legal Entity",
                "Notification Deadline Timestamp", "Notification Sent Timestamp")
             + ["Client Information Incidents"]),
            ("Incidents Outside a Response Program",
             "Client Information Incidents whose Governing Response Program is blank, or resolves to a program that is not an "
             "active Reg S-P program covering every one of the incident's Affected Legal Entities.",
             ["Client Information Incidents"]
             + _u("41", "Security Incident Detail", "Governing Response Program")
             + _u("41", "Information Security Program", "Security Program Code", "Covered Legal Entities")),
            ("Service Provider Incidents Affecting Clients",
             "Client Information Incidents with Notifying Service Provider populated, by provider and the Engagement Status of "
             "its 40 Supplier Engagement, with the hours from Service Provider Notice Received Timestamp back to Became Aware "
             "Date (the provider's 72-hour notice is DP-232's 'Late Service Provider Notices').",
             ["Client Information Incidents"]
             + _u("41", "Security Incident Detail", "Notifying Service Provider", "Service Provider Notice Received Timestamp",
                  "Became Aware Date")
             + _u("40", "Supplier Engagement", "Supplier Engagement ID", "Engaged Supplier", "Engagement Status",
                  "Shared Data Assets")),
            ("Identity Theft Red Flag Events",
             "Count of IT Incidents with Identity Theft Red Flag Indicator = Y in the period, by Affected Legal Entities; the "
             "count the Reg S-ID annual report gives the board.",
             _u("41", "IT Incident", "IT Incident ID", "Affected Legal Entities", "Incident Detected Timestamp")
             + _u("41", "Security Incident Detail", "Identity Theft Red Flag Indicator")),
            ("Program Review Currency Gaps",
             "Covered entities with no Compliance Program Review of Program Review Type = Regulation S-P Program Review, and "
             "broker-dealer, adviser and fund entities with none of Program Review Type = Regulation S-ID Annual Report, with "
             "Review Period End in the last 12 months.",
             _u("38", "Compliance Program Review", "Program Review Type", "Reviewed Entity", "Review Period End")
             + _u("09", "Internal Legal Entity", "Legal Entity ID")),
            ("Program Reviews With Material Matters",
             "Count of Reg S-P and Reg S-ID Compliance Program Reviews with Review Report Date in the period by Program "
             "Assessment Conclusion, with those whose Material Compliance Matters is populated.",
             _u("38", "Compliance Program Review", "Program Review Type", "Review Report Date", "Program Assessment Conclusion",
                "Material Compliance Matters")),
        ],
        inputs=[
            ("41", "Information Security Program", ["Security Program Code", "Security Program Type", "Covered Legal Entities",
                                                    "Program Policy", "Program Approval Date", "Program Last Review Date",
                                                    "Last Board Report Date", "Program Compliance Date",
                                                    "Security Program Status"]),
            ("41", "IT Incident", ["IT Incident ID", "Incident Class", "Incident Detected Timestamp", "Affected Legal Entities",
                                   "IT Incident Status"]),
            ("41", "Security Incident Detail", ["Personal Data Affected Indicator",
                                                "Sensitive Customer Information Compromised Indicator",
                                                "Affected Individuals Estimate", "Became Aware Date",
                                                "Customer Notification Determination",
                                                "Customer Notification Determination Date", "Customer Notice Due Date",
                                                "Attorney General Delay Indicator", "Notifying Service Provider",
                                                "Service Provider Notice Received Timestamp", "Governing Response Program",
                                                "Identity Theft Red Flag Indicator"]),
            ("37", "Incident Source Record", ["Source Incident", "Incident Source Type", "Source IT Incident"]),
            ("37", "Incident Regulatory Notification", ["Notified Incident", "Notification Authority",
                                                        "Incident Notification Regime", "Incident Notification Stage",
                                                        "Notifying Legal Entity", "Notification Deadline Timestamp",
                                                        "Notification Sent Timestamp"]),
            ("38", "Compliance Program Review", ["Program Review Type", "Reviewed Entity", "Review Period End",
                                                 "Review Report Date", "Program Assessment Conclusion",
                                                 "Material Compliance Matters"]),
            ("38", "Policy", ["Policy ID", "Policy Regulatory Basis", "Policy Status"]),
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Authorization Type", "Authorization Status"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engaged Supplier", "Engagement Status", "Shared Data Assets"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category", "Entity Status"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("01", "Fund Legal Structure", ["Regulatory Regime"]),
        ],
        upstream=["DP-232", "DP-215", "DP-224", "DP-222", "DP-210", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="Incident and notification status by 8am ET each business day; program coverage and the board view by business day 5 after month-end",
        history="Monthly snapshots and every incident determination and notification kept 6 years (Regulation S-P, 17 CFR 248.30(c), and SEC Rule 17a-4 for the broker-dealer); SCD type 2 on programs and determinations",
        classification="Restricted",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "Regulatory report"],
        dq_rules=[
            "Every Covered Legal Entities value, Affected Legal Entities value, Reviewed Entity and Authorized Entity resolves to an active DP-013 internal legal entity, every Program Policy to a DP-224 Policy, every Notifying Service Provider to a DP-210 supplier party and every Source IT Incident to a DP-232 IT Incident.",
            "On every program Program Approval Date is on or before Program Last Review Date, and on every incident Became Aware Date is on or after the Incident Detected Timestamp date and Customer Notice Due Date is 30 calendar days after Became Aware Date unless Attorney General Delay Indicator = Y.",
            "Every client information incident with Customer Notification Determination = Notification Required and Customer Notice Due Date before the as-of date has, through its 37 Incident Source Record, an Incident Regulatory Notification with Incident Notification Regime = Regulation S-P Customer Notification and Notification Sent Timestamp populated; each incident that fails is listed.",
            "Security Program Type, Covered Legal Entities and Security Program Status are populated on every program, and Customer Notification Determination and Became Aware Date on every incident with Sensitive Customer Information Compromised Indicator = Y.",
            "No client record, affected individual or employee name is read; Affected Individuals Estimate is published as a total per incident and entity, and incident rows are visible to the CISO office, compliance and legal only.",
            "Incident status is published by 8am ET each business day, and the month-end program view is locked on business day 5 for the board report; later determinations appear in the next month.",
        ],
        notes=("Certified numbers: none. PII tier: none. pii is N: the product reads programs, incidents, notifications and "
               "reviews; Program Owner, Review Lead and Incident Manager are not read, Notifying Service Provider and Engaged "
               "Supplier are supplier party keys (noted PII because a supplier can be a sole proprietor; no name is read), and Affected Individuals Estimate is a count. Classified Restricted because "
               "incident detail is security-sensitive. Boundaries (CW-029, CW-163): privacy oversight and program reviews are "
               "38 (DP-224), safeguards and incidents 41 (DP-232), consents 02 and notices 13; this product is the Reg S-P and "
               "Reg S-ID program view across them. DP-232 keeps incident operations, 'Reg S-P Determinations Pending', "
               "'Customer Notices Due' and 'Late Service Provider Notices'; this product adds the notice sent against the due "
               "date, program coverage and review currency (RESPEC DP-232: client data incidents feed DP-595). Operational "
               "incident records and their regulatory notifications are DP-215's. Candidate object dropped: 40 Outsourcing "
               "Arrangement (its CDEs are the critical-function and contract links read by DP-220 and DP-217); 40 Supplier "
               "Engagement carries the shared data assets that matter here. Candidate "
               "upstream DP-219 dropped: provider risk ratings are not read; the provider is matched to its DP-210 engagement. "
               "DP-211 dropped in the fix pass (nothing of it is read); DP-004 added for the fund selection. Tailoring lever: entity scope of Reg S-ID. "
               "Reference default: the broker-dealer, the investment adviser and the funds that hold covered accounts; the "
               "transfer agent is covered by Reg S-P only. Tailoring lever: compliance date. Reference default: the larger-"
               "entity date (December 3, 2025) for every entity; a smaller entity uses June 3, 2026 (confirm). Taxonomy gap: "
               "41 Security Incident Detail has no customer notice sent date; the notice is joined through 37 Incident Source "
               "Record and Incident Regulatory Notification, which needs the operational incident to be raised. Taxonomy gap: 38 Entity "
               "Authorization Type has no value for a registered investment company and 01 Investment Product has no link to "
               "the 09 fund registrant entity, so funds are selected by 01 Vehicle Type and Regulatory Regime and matched to "
               "the Fund Trust (registrant) entities by a maintained crosswalk. Taxonomy gap: "
               "41 Information Security Program has no link to the 38 Compliance Program Review that assessed it; the review "
               "is matched by entity and review type. Code values are from the 38 Entity Authorization Type, Authorization "
               "Status, 09 Internal Entity Category and 01 Vehicle Type lists. Drafting assumptions: the product-to-registrant "
               "crosswalk; the "
               "12-month review and board report cycle; the 30-day notice window of 17 CFR 248.30(a)(4). Decisions: CW-029, "
               "CW-163, CD-270, CD-297. WP1 new (CW-260 block, CORP brief): new consumer product covering 41 Information "
               "Security Program (no live reader); adds 37 Incident Source Record, 38 Entity Authorization, 40 Supplier "
               "Engagement and 09 Internal Legal Entity to the candidate's objects. Fix pass: real authorization "
               "values, funds selected through 01, DQ3 replaced by the notification test, DP-211 removed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-598": dict(
        definition=("Ties the month's client revenue records (10 Client Revenue Record: advisory, wrap and planning fees, "
                    "account service fees, commissions and markups, margin interest, fully paid lending and bank sweep fees) "
                    "and the program bank fees of 10 Cash Program Economics to the 19 journals, ledger postings and fee "
                    "receivables that record them, to the 47 fee debits and invoices behind them (through DP-305 and DP-350), "
                    "and to the ASC 606 revenue contracts and performance obligations and the ASC 340-40 capitalized contract costs "
                    "of 10. It "
                    "publishes the record- and posting-level breaks (unposted, orphaned, mis-mapped and late items) and the "
                    "posted amount by GL account beneath DP-012's own 'Ledger Tie-Out Variance', and sets the ledger beside the "
                    "client fee slice of DP-012's certified Gross Fee Revenue (CW-265). The "
                    "controller uses it to close revenue and to explain the revenue line. It never publishes a revenue total "
                    "of its own and owns no certified metric family."),
        business_questions=[
            "How does the client fee revenue posted to the ledger this month compare with the client fee slice of DP-012's certified Gross Fee Revenue, by legal entity and stream, and which record- and posting-level breaks explain DP-012's Ledger Tie-Out Variance?",
            "Which client revenue records were not posted, posted at a different amount, or posted to a GL account mapped to the wrong revenue line?",
            "Which postings to client revenue accounts have no source record, were made manually, or landed after the period was hard closed?",
            "Do the program bank fees earned tie to the sweep fee postings, and which fee debits have no revenue record behind them?",
            "Is every revenue stream covered by an ASC 606 contract and performance obligation, and what ASC 340-40 capitalized contract costs are carried and amortized?",
        ],
        grain=("Legal entity x fiscal period x Management P&L line x GL account (the tie-out row), with client revenue record, "
               "GL posting, receivable item and fee debit exception rows as companion facts; monthly, kept as closed"),
        dimensions=["Legal entity (DP-013)", "Fiscal period (DP-013)", "GL account and Management P&L line (DP-190)",
                    "Client revenue stream", "Revenue disaggregation category (DP-190)", "Journal source and type (DP-191)",
                    "Sweep program and program bank (DP-431)", "Revenue contract type and performance obligation",
                    "Exception type"],
        measures=[
            ("Certified Client Fee Revenue (from DP-012 Client Fee Revenue)",
             "The client fee stream slice of the certified Gross Fee Revenue DP-012 publishes (CW-011): its Client Revenue "
             "Record rows with Client Revenue Stream in the fee streams (Advisory Fee, Wrap Fee, Planning Fee, Subscription "
             "Fee, Account Service Fee, Recordkeeping Fee, Trust Fee, OCIO Fee, Mandate Performance Fee), by fiscal period and "
             "Recognizing Legal Entity; read and never recomputed. The own-fund management fees of 10 Fee Revenue Record in "
             "the same certified measure are out of this product's scope and are not read.",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount",
                "Recognizing Legal Entity")),
            ("Client Revenue Posted to Ledger",
             "Sum of Posted Amount (credits less debits by Debit Credit Indicator) of GL Postings on GL Accounts with GL Account "
             "Type = Revenue of Journal Entries with Journal Status = Posted and Journal Source = Client Revenue & "
             "Profitability in the Posting Accounting Period, by Posting Legal Entity, Posted Account and the Management P&L "
             "Line of the Account Mapping in effect; an operational ledger amount for the tie-out, never a certified figure.",
             _u("19", "GL Posting", "Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount")
             + _u("19", "Journal Entry", "Journal ID", "Journal Source", "Journal Status", "Posting Accounting Period",
                  "Posting Legal Entity")
             + _u("19", "GL Account", "GL Account ID", "GL Account Type")
             + _u("10", "Account Mapping", "Management P&L Line", "GL Natural Account", "Mapping Effective From",
                  "Mapping Effective To")),
            ("Revenue by Stream Posted vs Recognized",
             "Per legal entity, fiscal period and Client Revenue Stream: Recognized Revenue Amount of Client Revenue Records - "
             "Client Revenue Posted to Ledger on the GL accounts mapped to that stream (the stream-to-line crosswalk), for every "
             "stream including commissions, margin interest and fully paid lending.",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Client Revenue Period", "Recognized Revenue Amount",
                "Recognizing Legal Entity")
             + ["Client Revenue Posted to Ledger"]),
            ("Unposted Revenue Records",
             "Count and Recognized Revenue Amount of Client Revenue Records of a closed Client Revenue Period that are the "
             "Source Finance Record of no posted GL Posting, by stream and entity (see the gap on the posting link).",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Client Revenue Stream", "Client Revenue Period",
                "Recognized Revenue Amount")
             + _u("19", "GL Posting", "Source Finance Record")),
            ("Orphan Revenue Postings",
             "Count and Posted Amount of GL Postings on the GL accounts mapped (Account Mapping in effect) to the Management "
             "P&L Lines of the client fee streams, in Journal Entries with Journal Source = Client Revenue & Profitability, "
             "whose Source Finance Record is blank or resolves to no Client Revenue Record or Cash Program Economics row; "
             "postings sourced from FRR-, WVR- and other fund-side records are on fund fee lines and are not tested here.",
             _u("19", "GL Posting", "Journal ID", "Posted Account", "Posted Amount", "Source Finance Record")
             + _u("19", "Journal Entry", "Journal Source")
             + _u("10", "Account Mapping", "Management P&L Line", "GL Natural Account")),
            ("Mis-Mapped Revenue Postings",
             "Count and Posted Amount of revenue postings whose Posted Account carries, in its Financial Statement Line Mapping "
             "in effect, a Revenue Disaggregation Category other than the one the source record's Client Revenue Stream "
             "belongs to (the maintained stream crosswalk).",
             _u("19", "GL Posting", "Posted Account", "Posted Amount", "Source Finance Record")
             + _u("19", "Financial Statement Line Mapping", "Mapped GL Account", "Revenue Disaggregation Category",
                  "Line Mapping Effective From", "Line Mapping Effective To")
             + _u("10", "Client Revenue Record", "Client Revenue Stream")),
            ("Revenue Postings After Hard Close",
             "Count and Posted Amount of client revenue postings whose Journal Entry Posting Date is after the Hard Close Date "
             "of the Accounting Period Status of the Posting Accounting Period, or posted into a period with Period Close "
             "Status = Reopened.",
             _u("19", "Journal Entry", "Journal ID", "Posting Date", "Posting Accounting Period", "Journal Ledger")
             + _u("19", "Accounting Period Status", "Status Ledger", "Status Fiscal Period", "Period Close Status",
                  "Hard Close Date")),
            ("Manual Revenue Journals",
             "Count and summed Posted Amount of posted journals with Manual Journal Indicator = Y that post to client revenue "
             "accounts, by Journal Type and entity.",
             _u("19", "Journal Entry", "Journal ID", "Journal Type", "Manual Journal Indicator", "Posting Legal Entity")
             + _u("19", "GL Posting", "Posted Account", "Posted Amount")),
            ("Program Bank Fee Posting Difference",
             "Per Economics Sweep Program, Economics Program Bank and Economics Period: Program Bank Fee Earned - Posted Amount "
             "of the GL Postings whose Source Finance Record is that Cash Program Economics row (DP-012 ties the allocated "
             "account records; this measure ties the ledger).",
             _u("10", "Cash Program Economics", "Economics Sweep Program", "Economics Program Bank", "Economics Period",
                "Program Bank Fee Earned")
             + _u("19", "GL Posting", "Posted Amount", "Source Finance Record")),
            ("Fee Debits Without Revenue Record",
             "Count and Debit Amount of Fee Debits with Fee Debit Status = Posted and Debit Date in the period whose Fee Debit ID "
             "or Debited Calculation is named in the Source Calculation Record of no Client Revenue Record.",
             _u("47", "Fee Debit", "Fee Debit ID", "Debited Calculation", "Debit Amount", "Debit Date", "Fee Debit Status")
             + _u("10", "Client Revenue Record", "Source Calculation Record")),
            ("Streams Without Performance Obligation",
             "Client Revenue Streams recognized in the period by a Recognizing Legal Entity that are the Revenue Stream of no "
             "Performance Obligation of a Revenue Contract with Contracting Legal Entity = that entity and Accounting "
             "Framework = US GAAP.",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Recognizing Legal Entity")
             + _u("10", "Revenue Contract", "Revenue Contract ID", "Revenue Contract Type", "Contracting Legal Entity",
                  "Accounting Framework")
             + _u("10", "Performance Obligation", "Performance Obligation Type", "Satisfaction Pattern", "Revenue Stream",
                  "Stream Principal vs Agent Conclusion")),
            ("Capitalized Contract Costs",
             "Sum of Net Carrying Amount and of Impairment Loss Amount of Contract Cost Assets at period end, by Cost Asset Type, "
             "Amortization Method and the Contracting Legal Entity of the Related Revenue Contract, with Capitalized Amount "
             "added in the period.",
             _u("10", "Contract Cost Asset", "Contract Cost Asset ID", "Cost Asset Type", "Related Revenue Contract",
                "Capitalized Amount", "Amortization Method", "Amortization Period", "Net Carrying Amount",
                "Impairment Loss Amount")
             + _u("10", "Revenue Contract", "Revenue Contract ID", "Contracting Legal Entity")),
            ("Contract Cost Amortization Posting Difference",
             "Per Contract Cost Asset and period: the change in Net Carrying Amount net of Capitalized Amount added and "
             "Impairment Loss Amount - Posted Amount of GL Postings whose Source Finance Record is the asset.",
             _u("10", "Contract Cost Asset", "Contract Cost Asset ID", "Capitalized Amount", "Net Carrying Amount",
                "Impairment Loss Amount")
             + _u("19", "GL Posting", "Posted Amount", "Source Finance Record")),
            ("Cost Sources Assessed for Capitalization",
             "Count of Capitalization Assessments by Assessment Conclusion, Incremental Indicator and Practical Expedient Applied "
             "Indicator; a cost source concluded as capitalizable with no Contract Cost Asset is flagged.",
             _u("10", "Capitalization Assessment", "Assessed Cost Source", "Incremental Indicator", "Customer Contract Linkage",
                "Practical Expedient Applied Indicator", "Assessment Conclusion")
             + _u("10", "Contract Cost Asset", "Contract Cost Asset ID")),
        ],
        inputs=[
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Debit Credit Indicator", "Posted Amount",
                                  "Source Finance Record"]),
            ("19", "Journal Entry", ["Journal ID", "Journal Ledger", "Journal Type", "Journal Source", "Posting Date",
                                     "Posting Accounting Period", "Posting Legal Entity", "Journal Status",
                                     "Manual Journal Indicator"]),
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status", "Hard Close Date"]),
            ("19", "GL Account", ["GL Account ID", "Natural Account Number", "GL Account Type", "Financial Statement Class"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Revenue Disaggregation Category",
                                                        "Line Mapping Effective From", "Line Mapping Effective To"]),
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Revenue Account / Household", "Client Revenue Stream",
                                             "Revenue Service Offering", "Client Revenue Period", "Source Calculation Record",
                                             "Recognized Revenue Amount", "Recognizing Legal Entity"]),
            ("10", "Cash Program Economics", ["Economics Sweep Program", "Economics Program Bank", "Economics Period",
                                              "Program Bank Fee Earned"]),
            ("10", "Revenue Contract", ["Revenue Contract ID", "Revenue Contract Type", "Identified Customer",
                                        "Contracting Legal Entity", "Accounting Framework"]),
            ("10", "Performance Obligation", ["Performance Obligation Type", "Satisfaction Pattern", "Revenue Stream",
                                              "Stream Principal vs Agent Conclusion"]),
            ("10", "Account Mapping", ["Account Mapping ID", "Management P&L Line", "GL Natural Account", "Mapping Effective From",
                                       "Mapping Effective To"]),
            ("10", "Contract Cost Asset", ["Contract Cost Asset ID", "Cost Asset Type", "Related Revenue Contract",
                                           "Capitalized Amount", "Amortization Method", "Amortization Period",
                                           "Net Carrying Amount", "Impairment Loss Amount"]),
            ("10", "Capitalization Assessment", ["Assessed Cost Source", "Incremental Indicator", "Customer Contract Linkage",
                                                 "Practical Expedient Applied Indicator", "Assessment Conclusion"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Debited Calculation", "Debited Account", "Debit Amount", "Debit Date",
                                 "Fee Debit Status"]),
        ],
        upstream=["DP-012", "DP-191", "DP-190", "DP-305", "DP-431", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end for the close, with a daily pre-close run from business day 1",
        history="Each closed period's tie-out and exception rows kept 7 years (SEC Rule 17a-4 for the broker-dealer, Rule 204-2 for the adviser, and the firm's financial records policy); periods kept as closed, never restated",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Posted Account resolves to a DP-190 GL Account, every Posting Legal Entity, Recognizing Legal Entity and Contracting Legal Entity to a DP-013 internal legal entity, every Debited Calculation and Fee Debit ID to a DP-305 Account Fee Calculation or Fee Debit, and every Economics Program Bank to a DP-431 program bank.",
            "Account Mapping and Financial Statement Line Mapping rows for one GL account do not overlap in effect (Mapping Effective To and Line Mapping Effective To on or after their From dates), so each posting maps to exactly one Management P&L Line and one Revenue Disaggregation Category.",
            "Certified Client Fee Revenue (from DP-012 Client Fee Revenue) equals the client fee stream rows of the Gross Fee Revenue DP-012 publishes for the same entity and period (zero tolerance), and for each stream and closed period Revenue by Stream Posted vs Recognized is within USD 1,000 per entity once Unposted Revenue Records, Mis-Mapped Revenue Postings and Revenue Postings After Hard Close are taken out.",
            "Client Revenue Stream, Client Revenue Period, Recognized Revenue Amount and Recognizing Legal Entity are populated on every Client Revenue Record, and Posted Account, Posted Amount and Debit Credit Indicator on every GL Posting read.",
            "Account-grain rows (Revenue Account / Household, Debited Account) appear only in the exception lists, visible to finance controllership and billing operations; the ledger view is by entity, line, stream and GL account and carries no client key.",
            "The tie-out for period P is locked when the Accounting Period Status of P reaches Hard Close; postings after the lock are reported as Revenue Postings After Hard Close in the next period, never by restating P.",
        ],
        notes=("Certified numbers: reads the client fee stream slice of Gross Fee Revenue from DP-012 (CW-011, CW-265) and never "
               "recomputes it (DP-012 should publish that slice as its own named measure at WP2; today it is the client fee "
               "rows of Gross Fee Revenue); 10 Fee Revenue Record is not read; Net Fee Revenue "
               "and Effective Net Fee Rate stay in DP-012; enterprise Certified Revenue is DP-191's. DP-598 publishes "
               "differences and posted amounts by GL account only, never a revenue total of its own. PII tier: financial. "
               "Client Revenue Record and Fee Debit are account-grain personal data and appear only in exception rows (DQ5); "
               "Debited Account is a key, and no name, TIN or bank detail is read. Boundaries: DP-012 certifies revenue and keeps "
               "its own 'Ledger Tie-Out Variance' at Management P&L line level and the 'Billed to Recognized Variance'; this "
               "product is the record- and posting-level reconciliation beneath them, with the contract-cost view, and does not "
               "repeat DP-012's line-level variance (fix pass). Billing runs and fee debits are DP-305's; invoices, receivables, "
               "'Invoice to Receivable Breaks' and 'Open Fee Receivables' are CLA-A DP-350's and are not repeated here, so 19 "
               "Receivable Item and 47 Fee Invoice are no longer read and DP-350 is not upstream; yield "
               "analytics are DIS DP-497's and the cash program measures DP-012's. Fee "
               "billing accuracy and custody-rule evidence are CLA-A DP-346's (CW-263). The general ledger is DP-191's and the "
               "chart DP-190's (RESPEC DP-190: Journal Source values for 10 client revenue; RESPEC DP-191: postings sourced "
               "from Client Revenue Record and Cash Program Economics). Takes the reads of backlog DP-504 (10 Contract Cost "
               "Asset, Capitalization Assessment; ASC 340-40). Acceptance question 8: not an answering product; DP-346 answers it, and this "
               "product shows whether the fees billed and debited reached revenue and the ledger (Fee Debits Without Revenue "
               "Record). Tailoring lever: fully paid lending and margin. Reference default: both offered; without them the "
               "streams drop out of Revenue by Stream Posted vs Recognized. Tailoring lever: trust services. Reference default: "
               "not offered; a trust company adds its fee stream and entity. Taxonomy gap: 19 GL Posting.Source Finance Record "
               "references FRR-, WVR-, DCO-, ACR-, CCA-, ARN- and ICC- records but not 10 Client Revenue Record (CLREV-) or "
               "Cash Program Economics, so record-level posting links (Unposted Revenue Records, Program Bank Fee Posting "
               "Difference) depend on extending that reference; until then the tie-out runs at entity x stream x GL account. "
               "Taxonomy gap: 10 Capitalization Assessment is keyed to the cost source, not to the Contract Cost Asset it "
               "produced. Drafting assumptions: Journal Source value Client Revenue & Profitability; Journal Status value "
               "Posted; GL Account Type value Revenue; Accounting Framework value US GAAP; the stream-to-line and "
               "stream-to-disaggregation crosswalks; the USD 1,000 unexplained tolerance; business day 5. Decisions: CW-011, "
               "CW-051, CW-156, CW-263, CW-265, CD-158. WP1 new (CW-265): new consumer product of the CORP brief; adds 19 "
               "GL Account and Financial Statement Line Mapping, 10 Account Mapping and the moved reads of DP-504 to the "
               "candidate's objects. Fix pass: 'Certified Gross Fee Revenue (from DP-012)' renamed 'Certified Client Fee Revenue "
               "(from DP-012 Gross Fee Revenue)' (client fee slice); 'Ledger to Certified Fee Revenue Difference', 'Invoiced "
               "Fees Without Receivable' and 'Fee Receivables Past Due' dropped; 'Orphan Revenue Postings' limited to client fee "
               "lines."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-600": dict(
        definition=("Treasury's view of the cash the self-clearing broker-dealer must hold in its special reserve bank accounts "
                    "after each approved SEC Rule 15c3-3 reserve computation (the requirement, deposit on hand and deposit or "
                    "withdrawal due with its deadline, read from BWO DP-445, never recomputed), the bank balances and credits "
                    "that fund it (43, through DP-202), the corporate cash available, the margin calls outstanding that drive "
                    "customer debits, and the concentration of client sweep deposits by program bank (50, through DP-431) "
                    "against the firm's bank counterparty limits. The treasurer uses it to fund reserve deposits on time and "
                    "to manage program bank counterparty risk. Program bank deposits are client money and are shown as "
                    "exposure, never as corporate cash; it owns no certified metric family."),
        business_questions=[
            "What deposit does today's approved reserve computation require for the customer and PAB reserves, by when, and is it funded?",
            "Does the deposit on hand in the reserve computation equal the balances of the special reserve bank accounts, and how concentrated are those balances by bank?",
            "How much corporate cash is available at the broker-dealer to fund the next deposit, and how much margin call money is outstanding?",
            "How are client sweep deposits spread across program banks, and which banks exceed the firm's counterparty limit or concentration threshold?",
            "Does the net capital computation reference the approved reserve computation and its aggregate debit items?",
        ],
        grain=("Broker-dealer x reserve computation type x computation date (the reserve funding row), with reserve bank account "
               "x statement date, program bank x business date and margin call totals as companion facts; daily snapshots"),
        dimensions=["Computing broker-dealer (DP-013)", "Reserve computation type (Customer, PAB)", "Computation date",
                    "Reserve bank account and servicing bank (DP-202)", "Program bank and sweep program (DP-431)",
                    "Bank relationship tier", "Margin call type", "Business date (DP-013)"],
        measures=[
            ("Reserve Requirement (from DP-445)",
             "Reserve Requirement Amount of the Reserve Computation with Computation Approval Status = Approved per Computing "
             "Broker-Dealer, Reserve Computation Type and Computation Date, as DP-445 publishes it; read, never recomputed "
             "(CW-262).",
             _u("49", "Reserve Computation", "Reserve Computation ID", "Computing Broker-Dealer", "Reserve Computation Type",
                "Computation Date", "Reserve Requirement Amount", "Computation Approval Status")),
            ("Reserve Deposit Due (from DP-445)",
             "Deposit or Withdrawal Amount (positive = deposit due) and Deposit Deadline Timestamp of the same approved "
             "computation, as DP-445 publishes them.",
             _u("49", "Reserve Computation", "Deposit or Withdrawal Amount", "Deposit Deadline Timestamp",
                "Computation Approval Status")),
            ("Reserve Bank Balance",
             "Sum of Closing Booked Balance of the latest Bank Statement with Bank Statement Type = End-of-Day Statement (highest Statement Sequence Number) of each "
             "Corporate Bank Account named in Reserve Bank Accounts of the computation, on the Computation Date, by Account "
             "Servicing Bank.",
             _u("49", "Reserve Computation", "Reserve Bank Accounts", "Computation Date")
             + _u("43", "Corporate Bank Account", "Corporate Bank Account ID", "Account Servicing Bank", "Account Currency")
             + _u("43", "Bank Statement", "Statement Account", "Bank Statement Type", "Statement Date", "Statement Sequence Number",
                  "Closing Booked Balance")),
            ("Deposit on Hand to Bank Difference",
             "Reserve Deposit on Hand of the approved computation (from DP-445) - Reserve Bank Balance on the Computation Date; "
             "flagged when the absolute difference exceeds USD 1, compared and never corrected here. Where the deposit on hand "
             "includes qualified securities held in the reserve account, the cash balance alone falls short of it; that part "
             "cannot be separated in the taxonomy (see the gap and the qualified-securities lever) and is shown as an "
             "unexplained positive difference.",
             _u("49", "Reserve Computation", "Reserve Deposit on Hand") + ["Reserve Bank Balance"]),
            ("Reserve Deposit Funded by Deadline",
             "Sum of Entry Amount of credit Bank Statement Entries (Credit Debit Indicator = CRDT) to the reserve bank accounts "
             "after the Computation Date that meet the deadline date and hour of Deposit Deadline Timestamp (from DP-445): "
             "entries with Entry Value Date before the deadline date count; entries dated on the deadline date count only when "
             "they appear on a Bank Statement of Bank Statement Type = Intraday Account Report whose Statement Sequence Number "
             "is one the bank sends before the deadline hour (the bank's report schedule, see the gap). A deposit is funded "
             "when the credits, plus any qualified securities delivered (lever), equal or exceed Reserve Deposit Due (from "
             "DP-445).",
             _u("43", "Bank Statement Entry", "Entry Statement", "Entry Sequence Number", "Credit Debit Indicator", "Entry Amount",
                "Entry Value Date", "Bank Transaction Code")
             + _u("43", "Bank Statement", "Statement Account", "Bank Statement Type", "Statement Date", "Statement Sequence Number")
             + _u("49", "Reserve Computation", "Reserve Bank Accounts", "Computation Date", "Deposit Deadline Timestamp")
             + ["Reserve Deposit Due (from DP-445)"]),
            ("Reserve Funding Shortfall",
             "Reserve Deposit Due (from DP-445) - the credits counted in Reserve Deposit Funded by Deadline, when positive at "
             "the deadline; any value above zero is a Rule 15c3-3(e) deposit breach for treasury and the FINOP.",
             ["Reserve Deposit Due (from DP-445)", "Reserve Deposit Funded by Deadline"]),
            ("Reserve Balance Concentration by Bank",
             "Per Account Servicing Bank: its share of Reserve Bank Balance, and its balance / Bank Counterparty Limit Amount of "
             "the bank's Bank Relationship Profile in effect; banks above 100% of limit, or holding more than the "
             "concentration threshold of reserve cash, are flagged.",
             ["Reserve Bank Balance"]
             + _u("43", "Bank Relationship Profile", "Relationship Bank", "Bank Relationship Tier", "Bank Counterparty Limit Amount",
                  "Profile Effective From", "Profile Effective To")),
            ("Unreconciled Reserve Account Entries",
             "Count and absolute Entry Amount of entries on reserve bank accounts with Entry Reconciliation Status = Break Open, aged in business days since Booking Date.",
             _u("43", "Bank Statement Entry", "Entry Statement", "Entry Amount", "Booking Date", "Entry Reconciliation Status")
             + _u("43", "Bank Statement", "Statement Account") + _u("49", "Reserve Computation", "Reserve Bank Accounts")),
            ("Broker-Dealer Cash Available for Funding",
             "Sum of Projected Closing Position (latest Position Version) of the broker-dealer's Corporate Bank Accounts with "
             "Bank Account Purpose = Operating on the deadline date, less Reserve Deposit Due (from DP-445); negative is a "
             "funding gap.",
             _u("43", "Cash Position", "Position Bank Account", "Position Value Date", "Position Version",
                "Projected Closing Position")
             + _u("43", "Corporate Bank Account", "Account Holder Entity", "Bank Account Purpose", "Bank Account Status")
             + ["Reserve Deposit Due (from DP-445)"]),
            ("Forecast Broker-Dealer Net Cash Flow",
             "Sum of Forecast Amount of Cash Forecast Lines of the broker-dealer (Line Legal Entity) for the next 5 business-day "
             "buckets, by Cash Flow Category; the reserve funding itself has no category of its own (see the gap).",
             _u("43", "Cash Forecast Line", "Line Cash Forecast", "Line Legal Entity", "Cash Flow Category", "Bucket Start Date",
                "Forecast Amount")),
            ("Margin Calls Outstanding",
             "Count and sum of Margin Call Amount of Client Margin Calls with Margin Call Status in (Open, Extended) on the "
             "as-of date, by Margin Call Type, with the subset past Margin "
             "Call Due Date (or Extended Due Date) and Call Met Date blank; program totals only.",
             _u("49", "Client Margin Call", "Client Margin Call ID", "Margin Call Type", "Margin Call Date", "Margin Call Amount",
                "Margin Call Due Date", "Extended Due Date", "Call Met Date", "Margin Call Status")),
            ("Program Bank Deposits (from DP-431)",
             "Aggregate Customer Deposits of Program Bank Daily Total rows of the business date by Daily Total Program Bank and "
             "Daily Total Sweep Program, as DP-431 publishes them (its Aggregate Customer Deposits); client money held at the "
             "bank, never corporate cash and never added to it.",
             _u("50", "Program Bank Daily Total", "Daily Total Sweep Program", "Daily Total Program Bank",
                "Daily Total Business Date", "Aggregate Customer Deposits")),
            ("Program Bank Concentration %",
             "Program Bank Deposits (from DP-431) at a program bank / Program Bank Deposits over all active program banks of "
             "the Bank Deposit Sweep Program on the business date.",
             ["Program Bank Deposits (from DP-431)"]
             + _u("50", "Sweep Program", "Sweep Program ID", "Sweep Program Type", "Program Status")
             + _u("50", "Program Bank", "Program Bank ID", "Bank Party", "Program Bank Status")),
            ("Program Bank Exposure to Limit %",
             "Program Bank Deposits (from DP-431) at a bank / Bank Counterparty Limit Amount of the Bank Relationship Profile "
             "whose Relationship Bank is the program bank's Bank Party, in effect on the business date; banks above 100% are "
             "flagged, and the firm's own corporate and reserve balances at the same bank are shown beside it, not summed "
             "with it.",
             ["Program Bank Deposits (from DP-431)"]
             + _u("50", "Program Bank", "Bank Party")
             + _u("43", "Bank Relationship Profile", "Relationship Bank", "Bank Counterparty Limit Amount")
             + _u("02", "Party", "Party ID")),
            ("Program Bank Capacity Utilization % (from DP-431)",
             "The Program Bank Capacity Utilization % DP-431 publishes per program and bank on the business date (Aggregate "
             "Customer Deposits / Bank Capacity Amount of the Participation in effect), read and never recomputed; shown beside "
             "the exposure to limit (allocation itself is BWO DP-457's).",
             ["Program Bank Deposits (from DP-431)"]
             + _u("50", "Program Bank Participation", "Participation Sweep Program", "Participating Program Bank",
                  "Bank Capacity Amount", "Participation Effective From", "Participation Effective To")),
            ("Net Capital Reserve Reference Check",
             "Count of approved Capital Requirement Calculations of the broker-dealer whose Reserve Computation is blank or is "
             "not the latest approved Reserve Computation on or before Calculation As-Of Date, or whose Aggregate Debit Items "
             "Amount differs from that computation's Aggregate Debit Items Amount (from DP-445); compared, never recomputed "
             "(CW-262).",
             _u("43", "Capital Requirement Calculation", "Capital Calculation ID", "Calculation Entity", "Calculation As-Of Date",
                "Aggregate Debit Items Amount", "Reserve Computation", "Calculation Approval Status")
             + _u("49", "Reserve Computation", "Reserve Computation ID", "Aggregate Debit Items Amount",
                  "Computation Approval Status")),
        ],
        inputs=[
            ("49", "Reserve Computation", ["Reserve Computation ID", "Computing Broker-Dealer", "Reserve Computation Type",
                                           "Computation Date", "Aggregate Debit Items Amount", "Reserve Requirement Amount",
                                           "Reserve Deposit on Hand", "Deposit or Withdrawal Amount",
                                           "Deposit Deadline Timestamp", "Reserve Bank Accounts", "Computation Approval Status"]),
            ("49", "Client Margin Call", ["Client Margin Call ID", "Margin Call Type", "Margin Call Date", "Margin Call Amount",
                                          "Margin Call Due Date", "Extended Due Date", "Call Met Date", "Margin Call Status"]),
            ("43", "Corporate Bank Account", ["Corporate Bank Account ID", "Account Holder Entity", "Account Servicing Bank",
                                              "Account Currency", "Bank Account Purpose", "Bank Account Status"]),
            ("43", "Bank Statement", ["Statement Account", "Bank Statement Type", "Statement Date", "Statement Sequence Number",
                                      "Closing Booked Balance"]),
            ("43", "Bank Statement Entry", ["Entry Statement", "Entry Sequence Number", "Credit Debit Indicator", "Entry Amount",
                                            "Booking Date", "Entry Value Date", "Bank Transaction Code",
                                            "Entry Reconciliation Status"]),
            ("43", "Cash Position", ["Position Bank Account", "Position Value Date", "Position Version",
                                     "Projected Closing Position"]),
            ("43", "Cash Forecast Line", ["Line Cash Forecast", "Line Legal Entity", "Cash Flow Category", "Bucket Start Date",
                                          "Forecast Amount"]),
            ("43", "Bank Relationship Profile", ["Relationship Bank", "Bank Relationship Tier", "Bank Counterparty Limit Amount",
                                                 "Profile Effective From", "Profile Effective To"]),
            ("43", "Capital Requirement Calculation", ["Capital Calculation ID", "Calculation Entity", "Calculation As-Of Date",
                                                       "Aggregate Debit Items Amount", "Reserve Computation",
                                                       "Calculation Approval Status"]),
            ("50", "Sweep Program", ["Sweep Program ID", "Sweep Program Type", "Sponsoring Broker-Dealer", "Program Status"]),
            ("50", "Program Bank", ["Program Bank ID", "Bank Party", "Program Bank Status"]),
            ("50", "Program Bank Participation", ["Participation Sweep Program", "Participating Program Bank",
                                                  "Bank Capacity Amount", "Participation Effective From",
                                                  "Participation Effective To"]),
            ("50", "Program Bank Daily Total", ["Daily Total Sweep Program", "Daily Total Program Bank",
                                                "Daily Total Business Date", "Aggregate Customer Deposits"]),
            ("02", "Party", ["Party ID", "Party Status"]),
        ],
        upstream=["DP-445", "DP-202", "DP-205", "DP-431", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET on the business day after each computation date, and again at 10am ET on the deposit deadline day with the intraday bank statements",
        history="Daily snapshots and every computation, deposit and bank balance compared kept 6 years (SEC Rule 17a-4(b) for the broker-dealer's reserve records); never restated",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Computing Broker-Dealer, Account Holder Entity, Line Legal Entity and Calculation Entity resolves to an active DP-013 internal legal entity, every Reserve Bank Accounts value to a DP-202 Corporate Bank Account, every Daily Total Program Bank to a DP-431 Program Bank and every Bank Party and Relationship Bank to a DP-240 party.",
            "Bank Relationship Profile and Program Bank Participation rows of one bank (and program) do not overlap in effect, and Deposit Deadline Timestamp is after Computation Date on every approved computation.",
            "Reserve Requirement (from DP-445), Reserve Deposit Due (from DP-445) and the deposit on hand equal the values DP-445 publishes for the same approved computation (zero tolerance), and Program Bank Deposits (from DP-431) equals DP-431 Aggregate Customer Deposits for the same program, bank and date.",
            "Reserve Requirement Amount, Reserve Deposit on Hand, Deposit or Withdrawal Amount, Deposit Deadline Timestamp and Reserve Bank Accounts are populated on every approved computation, and a Closing Booked Balance exists for every reserve bank account on every Computation Date.",
            "No account-level row is read or published: margin calls are counted and summed by Margin Call Type without Margin Call Account, and bank account numbers are not read.",
            "The funding view for a computation is published by 9am ET on the next business day and locked after the deposit deadline; a re-approved computation appears as a new version, never by overwriting the locked one.",
        ],
        notes=("Certified numbers: none owned. The reserve requirement, deposit on hand and deposit or withdrawal amount are 49's "
               "and are read from BWO DP-445 by reference and compared, never recomputed (CW-262); net capital is DP-205's "
               "(43, CW-103). Operating model (CD-297): self-clearing broker-dealer in house (reference default); a fully "
               "disclosed clearing model removes the reserve computation and this product keeps only the program bank "
               "exposure. PII tier: none. pii is N although 49 Reserve Computation ID and the 49 Client Margin Call attributes "
               "are noted PII: the computation is a firm record keyed by broker-dealer (CW-115, 'No PII') and margin calls are "
               "read without Margin Call Account and published as program totals only (DQ5). Boundaries: corporate cash, bank "
               "accounts and counterparty limits on corporate deposits are DP-202's ('Bank Counterparty Limit Utilization %'); "
               "this product adds the reserve accounts and the program bank deposits. Sweep allocation and program bank "
               "allocation operations are BWO DP-457's; the program bank master and daily totals DP-431's; program economics "
               "DP-012 and DIS DP-497. Program bank deposits are client money, never a 43 Cash Position; customer reserve bank "
               "accounts are 43 Corporate Bank Accounts referenced by 49. Takes the read of 49 Client Margin Call from backlog "
               "DP-401, DP-450 and DP-603 (merge target of DP-603); customer debits enter the reserve formula in DP-445 and are "
               "not re-derived here. Acceptance question 6: DP-445 answers it (49, 43); DP-600 is a reader of "
               "the answering product, not a feeder (the lead amends WP1_Scope), and takes the answer to treasury with Reserve "
               "Requirement (from DP-445), Reserve Deposit Due (from DP-445) and Reserve Funding Shortfall. Tailoring lever: "
               "qualified securities in the reserve account (SEC Rule 15c3-3(e)). Reference default: deposits are made in cash; "
               "a firm that deposits qualified securities counts their value toward the deposit, which needs the gap below "
               "closed. Tailoring lever: margin and fully paid lending. Reference default: margin offered; without "
               "it Margin Calls Outstanding drops. Tailoring lever: reserve computation frequency (49 lever 2). Reference "
               "default: daily; a weekly computation keeps the grain. Tailoring lever: PAB reserve (49 lever 3). Reference "
               "default: computed; without PAB accounts the PAB rows are empty. Tailoring lever: bank concentration "
               "threshold. Reference default: 15% of reserve cash at one bank and 100% of the counterparty limit. Taxonomy "
               "gap: 43 Bank Account Purpose has no value for a special reserve bank account; the reserve accounts are "
               "identified only through 49 Reserve Computation.Reserve Bank Accounts. Taxonomy gap: 43 "
               "Bank Statement Entry has no booking timestamp, so the deadline hour is tested only through the intraday "
               "statement sequence. Taxonomy gap: 49 Reserve Computation does not split Reserve Deposit on Hand between cash and "
               "qualified securities, and 43 holds no securities in a bank account, so qualified-securities deposits cannot be "
               "traced. Taxonomy gap: 43 Cash Flow Category has "
               "no reserve deposit or withdrawal category, so the forecast cannot show reserve funding. Taxonomy gap: 43 Bank "
               "Relationship Profile holds one counterparty limit per bank, with no split between corporate deposits and "
               "client program deposits. Code values are from the Shared: Approval Status, 43 Bank Statement Type, "
               "Bank Account Purpose, Shared: Reconciliation Status, ISO 20022 CreditDebitCode, 49 Margin Call Status and 50 "
               "Sweep Program Type lists. Drafting assumptions: the bank's intraday report schedule; USD 1 tolerance; 9am and 10am ET. Decisions: CW-007, "
               "CW-102, CW-103, CW-115, CW-156, CW-262, CD-297. WP1 new (CW-262): new consumer product of the CORP brief; "
               "adds 43 Bank Statement, Bank Relationship Profile and Capital Requirement Calculation, 50 Program Bank "
               "Participation and 02 Party to the candidate's objects. Fix pass: deadline date and hour tested, "
               "qualified-securities treatment stated, code values aligned, 'Program Bank Capacity Headroom' replaced by "
               "'Program Bank Capacity Utilization % (from DP-431)'."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-083": dict(
        definition=("The register of US regulatory obligations that apply to each legal entity of the firm (38 Regulatory "
                    "Obligation): FINRA Rules 3110, 3120 and 3130 for the broker-dealer, Advisers Act Rules 204A-1 and 206(4)-7 "
                    "for the adviser, Investment Company Act Rule 38a-1 for the funds, Regulation S-P and S-ID, and the Bank "
                    "Secrecy Act programs of 31 CFR Parts 1023, 1024 and 1032, each with its accountable owner, its compliance "
                    "assessment and the attestations completed against it (38 Attestation). It keeps a minimal horizon view: "
                    "the firm's own regulatory change items due in the next 12 months and the obligations they affect (38 "
                    "Regulatory Change Item and Impact). Compliance uses it to show who owns each rule, whether it was attested "
                    "and which coming changes have no impact assessment. It owns no certified metric family."),
        business_questions=[
            "Which obligations apply to each legal entity, who owns each one, and which have no current compliance assessment?",
            "Which required rule families are missing from an entity's register, for example Rule 3130 for the broker-dealer or Rule 38a-1 for the funds?",
            "What share of required attestations were completed on time this period, by attestation type, legal entity and org unit, and who is overdue?",
            "Where obligation owners have left the firm or moved entity, which obligations need reassignment?",
            "Which regulatory changes take effect in the next 12 months, which entities and obligations do they affect, and which have no impact assessment or implementation owner?",
        ],
        grain=("Regulatory obligation (OBL-: rule citation x applicable legal entity) x as-of date, with attestation (attester x "
               "attestation type x period) and regulatory change item x impacted scope as companion facts; weekly snapshots, "
               "SCD type 2 on obligations"),
        dimensions=["As-of date and attestation period (DP-013)", "Applicable legal entity and entity category (DP-013)",
                    "Regulator and authorization type (DP-222)", "Source regulation and rule citation",
                    "Obligation owner, org unit and line manager (DP-192)", "Attestation type and status",
                    "Regulatory change stage and compliance date"],
        measures=[
            ("Obligation Coverage",
             "Count of Regulatory Obligations in effect (Obligation Effective From <= as-of date and Obligation Effective To "
             "blank or later) by Applicable Legal Entity and Source Regulation; an obligation is covered when Obligation Owner "
             "resolves to an active Employee and Compliance Assessment is populated.",
             _u("38", "Regulatory Obligation", "Obligation ID", "Source Regulation", "Applicable Legal Entity", "Obligation Owner",
                "Compliance Assessment", "Obligation Effective From", "Obligation Effective To")
             + _u("20", "Employee", "Employee ID", "Employment Status")),
            ("Unowned Obligation Flag",
             "Y where an obligation in effect has Obligation Owner blank or resolving to an Employee with Employment Status "
             "other than Active.",
             _u("38", "Regulatory Obligation", "Obligation Owner", "Obligation Effective To")
             + _u("20", "Employee", "Employment Status")),
            ("Obligations Without Compliance Assessment",
             "Count of obligations in effect with Compliance Assessment blank, by Applicable Legal Entity and Source Regulation.",
             _u("38", "Regulatory Obligation", "Obligation ID", "Compliance Assessment", "Applicable Legal Entity",
                "Source Regulation")),
            ("Entity Without Obligations Flag",
             "Y where an Internal Legal Entity with Entity Status active and an Entity Authorization with Authorization Status "
             "in (Registered, Authorized) has no Regulatory Obligation in effect with that Applicable Legal Entity.",
             _u("09", "Internal Legal Entity", "Legal Entity ID", "Entity Status")
             + _u("38", "Entity Authorization", "Authorized Entity", "Authorization Status")
             + _u("38", "Regulatory Obligation", "Applicable Legal Entity")),
            ("Required Rule Gaps",
             "Count of entity x required rule pairs with no obligation in effect: for each active entity, the rule citations "
             "its Authorization Type requires (Broker-Dealer Registration and FINRA Membership: FINRA Rules 3110, 3120, 3130, "
             "4370, 4512 and 31 CFR 1023; SEC Investment Adviser Registration: Advisers Act Rules 204A-1, 206(4)-7 and 31 CFR "
             "1032; Transfer Agent Registration (Form TA-1): SEC Rules 17Ad-1 to 17Ad-22; every one of them: Regulation S-P), "
             "and for each fund registrant (Entity Category = Fund Trust (registrant)) of 01 Investment Products with Vehicle "
             "Type in (Open-Ended Fund, Exchange-Traded Fund, Closed-End Fund, Interval Fund) and Regulatory Regime = US 1940 "
             "Act Registered: Rule 38a-1, 31 CFR 1024 and Regulation S-P and S-ID; matched on Rule Citation.",
             _u("38", "Entity Authorization", "Authorized Entity", "Authorization Type", "Regulator", "Authorization Status")
             + _u("09", "Internal Legal Entity", "Legal Entity ID", "Entity Category")
             + _u("01", "Investment Product", "Product ID", "Vehicle Type") + _u("01", "Fund Legal Structure", "Regulatory Regime")
             + _u("38", "Regulatory Obligation", "Rule Citation", "Applicable Legal Entity", "Obligation Effective From",
                  "Obligation Effective To")),
            ("Obligations With Departed or Moved Owner",
             "Obligations in effect whose Obligation Owner has Employment Status = Terminated or Notice Period, or whose "
             "Employing Legal Entity differs from the Applicable Legal Entity and from every entity the owner's Line Manager "
             "chain covers; the reassignment list, with the Line Manager for escalation.",
             _u("38", "Regulatory Obligation", "Obligation ID", "Obligation Owner", "Applicable Legal Entity")
             + _u("20", "Employee", "Employee ID", "Employment Status", "Employing Legal Entity")
             + _u("20", "Employee Reporting Line", "Reporting Employee", "Line Manager", "Reporting Line Type",
                  "Reporting Effective From", "Reporting Effective To")),
            ("Attestation Completion %",
             "Attestations with Attestation Status in (Completed, Completed with Exceptions) and Attestation Completed Date on "
             "or before the due date of the Attestation Campaign / attestations issued for the Attestation Period, by "
             "Attestation Type, the attester's Employing Legal Entity and Home Org Unit.",
             _u("38", "Attestation", "Attestation Type", "Attester", "Attestation Completed Date", "Attestation Status",
                "Attestation Period", "Attestation Campaign")
             + _u("20", "Employee", "Employing Legal Entity", "Home Org Unit")
             + _u("09", "Org Unit", "Org Unit ID", "Org Unit Name")),
            ("Overdue Attestation Count",
             "Attestations with Attestation Status = Overdue, or Issued past the campaign due date, with the attester's Line "
             "Manager (solid line) for escalation.",
             _u("38", "Attestation", "Attester", "Attestation Status", "Attestation Campaign")
             + _u("20", "Employee Reporting Line", "Reporting Employee", "Line Manager", "Reporting Line Type")),
            ("Annual Certification Currency",
             "Entities with an Entity Authorization of Authorization Type = Broker-Dealer Registration and FINRA Membership "
             "and no Attestation of Attestation Type = FINRA Rule 3130 CEO Certification, and entities "
             "with no Attestation of Attestation Type = Annual Compliance Certification, completed in the last 12 months by an "
             "attester employed by the entity.",
             _u("38", "Attestation", "Attestation Type", "Attester", "Attestation Completed Date", "Attestation Status")
             + _u("20", "Employee", "Employing Legal Entity")
             + _u("38", "Entity Authorization", "Authorized Entity", "Authorization Type")),
            ("Regulatory Changes Due (12 Months)",
             "Count of Regulatory Change Items with Change Compliance Date within 12 months of the as-of date and Regulatory "
             "Change Stage in (Proposed, Adopted, Effective, Compliance Date Deferred), by Change Regulator and stage; the "
             "minimal horizon view (the market horizon itself is backlog DP-509's).",
             _u("38", "Regulatory Change Item", "Regulatory Change ID", "Change Regulator", "Change Title",
                "Regulatory Change Stage", "Change Compliance Date")),
            ("Changes Without Impacted Obligation",
             "Regulatory Changes Due (12 Months) with no Regulatory Change Impact naming an Impacted Entity and Affected "
             "Obligations, or whose impacts have Impact Implementation Status other than Resolved / Completed within 90 days of the "
             "Change Compliance Date.",
             ["Regulatory Changes Due (12 Months)"]
             + _u("38", "Regulatory Change Impact", "Impacted Change Item", "Impacted Entity", "Impact Rating",
                  "Impact Implementation Status", "Affected Obligations")
             + _u("38", "Regulatory Change Item", "Change Compliance Date")),
        ],
        inputs=[
            ("38", "Regulatory Obligation", ["Obligation ID", "Source Regulation", "Rule Citation", "Obligation Summary",
                                             "Applicable Legal Entity", "Obligation Owner", "Compliance Assessment",
                                             "Obligation Effective From", "Obligation Effective To", "Monitoring Control"]),
            ("38", "Attestation", ["Attestation Type", "Attester", "Attestation Completed Date", "Attestation Status",
                                   "Attestation Period", "Attestation Campaign"]),
            ("38", "Entity Authorization", ["Authorization ID", "Authorized Entity", "Regulator", "Authorization Type",
                                            "Authorization Status"]),
            ("38", "Regulatory Change Item", ["Regulatory Change ID", "Change Regulator", "Change Title",
                                              "Regulatory Change Stage", "Change Compliance Date", "Source Horizon Item"]),
            ("38", "Regulatory Change Impact", ["Impacted Change Item", "Impacted Entity", "Impact Rating",
                                                "Impact Implementation Status", "Affected Obligations"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Category", "Entity Status"]),
            ("20", "Employee", ["Employee ID", "Job Title", "Employing Legal Entity", "Home Org Unit", "Employment Status"]),
            ("20", "Employee Reporting Line", ["Reporting Employee", "Line Manager", "Reporting Line Type",
                                               "Reporting Effective From", "Reporting Effective To"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name", "Org Unit Type"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("01", "Fund Legal Structure", ["Regulatory Regime"]),
        ],
        upstream=["DP-013", "DP-192", "DP-222", "DP-004"],
        refresh="Weekly",
        timeliness="By Monday 8am ET for the prior week; attestation status refreshed daily during an open attestation campaign",
        history="Weekly snapshots of the obligation register and change items kept 7 years; attestation records kept 6 years after the attestation period (SEC Rule 17a-4 for the broker-dealer, Rule 204-2 for the adviser, Rule 38a-1(d) for the funds); obligations kept as SCD type 2 so ownership changes are visible",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Applicable Legal Entity, Authorized Entity and Impacted Entity resolves to an active DP-013 internal legal entity, and every Obligation Owner, Attester, Reporting Employee and Line Manager to a DP-192 Employee ID.",
            "Obligation Effective To is on or after Obligation Effective From, and no two obligations in effect share the same Rule Citation and Applicable Legal Entity.",
            "Entity Authorizations counted equal the DP-222 Active Authorizations for the same entity and date, and every Affected Obligations value resolves to an Obligation ID in effect on the change's Change Compliance Date.",
            "Obligation ID, Rule Citation, Source Regulation and Applicable Legal Entity are populated on every obligation; Attestation Completed Date is populated if and only if Attestation Status is Completed or Completed with Exceptions.",
            "Owner and attester rows name employees and are visible to compliance roles; the wide view aggregates to legal entity x org unit x attestation type, and no attestation exception text is read.",
            "The weekly snapshot is published by Monday 8am ET and locked; changes after the lock appear in the next snapshot.",
        ],
        notes=("Certified numbers: none. PII tier: identity. Obligation owners and attesters are named employees; completion by "
               "person is visible to compliance only (DQ5). Boundaries (CW-260): compliance program reviews, policies, policy "
               "attestations, monitoring controls and training stay in DP-224; firm authorizations and filings, and 'Upcoming "
               "Entity Filing', are DP-222's; the market horizon (11 Regulatory Horizon Item) is backlog DP-509's, so this "
               "product keeps only the firm's own change items (38) as its minimal horizon view (WP1_Scope.md ruling 4). "
               "Supervisory controls behind the Rule 3120 report are CLA-B DP-402's. DP-224 published 'Obligation "
               "Coverage', 'Unowned Obligation Flag', 'Entity Without Obligations Flag', 'Attestation Completion %' and "
               "'Overdue Attestation Count' 'for DP-083' in its wholesale form; under RESPEC DP-224 they stay here, and DP-248 "
               "already reads Attestation Completion % from DP-083. Tailoring lever: "
               "trust company. Reference default: not offered; a trust company adds its OCC or state rules (12 CFR Part 9) to "
               "Required Rule Gaps. Tailoring lever: BSA program for advisers. Reference default: 31 CFR Part 1032 obligations "
               "registered now with the 2028 effective date (confirm). Taxonomy gap: 38 Attestation has no attested obligation "
               "or legal entity; the entity is the attester's Employing Legal Entity and the campaign due date comes from "
               "Attestation Campaign. Taxonomy gap: 38 Entity Authorization Type has no value for a registered investment company and 01 "
               "Investment Product has no link to its 09 fund registrant, so funds are selected by 01 Vehicle Type and "
               "Regulatory Regime and matched to the Fund Trust (registrant) entity by a maintained crosswalk. Taxonomy gap: 38 "
               "Regulatory Obligation has no required-by-entity-type flag, so Required "
               "Rule Gaps uses a maintained crosswalk from Authorization Type to rule citations. Drafting assumptions: the "
               "required rule crosswalk above; Authorization Status values Registered and Authorized; Employment Status values "
               "Active, Notice Period and Terminated; Impact Implementation Status value complete; the 12-month and 90-day "
               "windows. Decisions: CW-003, CW-163, CW-248, CW-260, CW-938, CD-344. WP1 re-scope (CW-260): register row "
               "'Regulatory Obligations, Attestations & Horizon' (owner 38) kept; the definition is US only. Register-row "
               "mismatch (for the lead): the row still names primary FN-13 and supporting FN-18, both retired (CW-200), so the "
               "validator errors once DP-083 leaves RESCOPE_OPEN; the CW-260 proposal is primary FN-44 Corporate Compliance "
               "with supporting FN-68, FN-36 and FN-43, which this spec is written to. Inputs dropped: 11 Regulatory Horizon "
               "Item (to DP-509), 09 Legal Entity Identifier (W4 attribute drops; DP-222 reads it) and 01 Regulatory "
               "Authorization (the funds' filings are DP-184's); 01 Investment Product and Fund Legal Structure are kept with "
               "fewer attributes for the fund selection. "
               "Inputs added: 38 Regulatory Change Item and Regulatory Change Impact. Logical model (models_c8_compliance2 "
               "DP-083, for the lineage pass): Fact Regulatory Obligation, Fact Attestation, Employee, Employee Reporting Line, "
               "Org Unit, Legal Entity and Entity Authorization keep their objects; Fact Regulatory Horizon Item, Horizon "
               "Obligation Crosswalk, Obligation Fund Crosswalk, Investment Product and Competent Authority lose theirs, and a "
               "fact for 38 Regulatory Change Item and Impact is new. Measures dropped: 'Horizon Items Due 12m' and "
               "'Unassessed Horizon Item Flag' (to DP-509; replaced here by 'Regulatory Changes Due (12 Months)' and "
               "'Changes Without Impacted Obligation') and 'Upcoming Entity Filing' (DP-222 owns it). Measures added: "
               "'Obligations Without Compliance Assessment', 'Required Rule Gaps', 'Obligations With Departed or Moved Owner' "
               "and 'Annual Certification Currency'. Upstream drops DP-041 (retired), DP-001 and DP-224 (no fact read from it) and "
               "keeps DP-004 for the fund selection (01 Investment Product and Fund Legal Structure re-read; 01 Regulatory "
               "Authorization dropped). Readers of dropped content (for the lineage pass; see also the module NOTES): DP-248 "
               "'Distribution Horizon Items (from DP-083)' (specs_e5_cross_area lines 811-813) cites the dropped 'Unassessed "
               "Horizon Item Flag' and is read by SM-16 (sm_16_risk_compliance_legal_audit line 556); DP-246 'Product "
               "Obligations Without Filing Calendar (from DP-083)' (specs_e5_cross_area lines 559-560) reads 01 Regulatory "
               "Authorization 'as DP-083 reads them' and is read by SM-11 (sm_11_fund_accounting_custody_governance line "
               "2006). The successor DP-509 is in the backlog, so by the fix-pass ruling the lineage agent drops those two DP-246 "
               "and DP-248 measures with a WP1 note; DP-083 stays as re-scoped. The DP-083 logical model is listed above. The FCA SYSC and SM&CR obligations drop (CW-938)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-199": dict(
        definition=("Variable compensation awards by employee, legal entity and performance year (20 Variable Compensation "
                    "Award), with the deferred portion, payment in cash, shares or units of the firm's own funds, the vesting "
                    "tranches and their malus and clawback status (20 Deferred Award Tranche), and the conduct adjustments from "
                    "performance review that must be considered before a tranche vests. Reward, compliance and the "
                    "compensation committee use it to apply the firm's deferral and clawback policy, the forfeiture of "
                    "unvested awards on leaving, and SEC Rule 10D-1 recovery where a listed parent applies it, from one record. "
                    "It owns no certified metric family; compensation paid stays certified in DP-198."),
        business_questions=[
            "What variable compensation was awarded per employee and entity this performance year, how much is deferred, and how much is paid in shares or own-fund units?",
            "Which deferred tranches vest in the next 90 days for people with a conduct adjustment that has not been assessed for malus?",
            "How much deferred compensation is unvested by vesting year, and how much has been reduced by malus or recovered by clawback?",
            "Which leavers still hold unvested tranches that the plan says should be forfeited?",
            "Which awards were granted without compensation committee approval, or have a tranche schedule that does not add up to the deferred amount?",
        ],
        grain="Variable compensation award (employee x performance year x award), with deferred award tranche (award x tranche) as child table; monthly snapshots",
        dimensions=["Performance year", "Employing legal entity (DP-013)", "Employee (DP-192)",
                    "Variable award type and award instrument", "Linked fund (DP-004)", "Vesting date and vesting year",
                    "Tranche vesting status", "Malus / clawback status"],
        measures=[
            ("Total Variable Remuneration", "Per Award Recipient, Performance Year and Award Currency: sum of Award Amount of Variable Compensation Awards, with the recipient's Employing Legal Entity; amounts are kept by currency and never converted (no 22 FX rate is read).",
             [("20", "Variable Compensation Award", "Award Recipient"), ("20", "Variable Compensation Award", "Performance Year"),
              ("20", "Variable Compensation Award", "Award Amount"), ("20", "Variable Compensation Award", "Award Currency"),
              ("20", "Employee", "Employing Legal Entity")]),
            ("Fixed Remuneration", "Per employee, performance year and Pay Currency: the Annualized Base Pay DP-198 publishes (read, not re-derived), prorated to the days of the performance year each Base Pay Record was effective (Pay Effective From to Pay Effective To); a prorated derivation of DP-198's figure, kept by currency.",
             [("20", "Base Pay Record", "Paid Employee"), ("20", "Base Pay Record", "Pay Component Amount"), ("20", "Base Pay Record", "Pay Amount Basis"),
              ("20", "Base Pay Record", "Pay Currency"), ("20", "Base Pay Record", "Pay Effective From"), ("20", "Base Pay Record", "Pay Effective To")]),
            ("Variable-to-Fixed Ratio", "Total Variable Remuneration / Fixed Remuneration per employee and performance year where both are in the same currency, compared with the ratio the firm's own compensation policy sets for the role family (a firm policy test; no regulatory bonus cap applies to a US firm).",
             ["Total Variable Remuneration", "Fixed Remuneration"]),
            ("Instrument Share %", "Per employee and year: sum of Award Amount with Award Instrument in (Shares, Units in Managed Funds, Share-Linked Instrument) / Total Variable Remuneration, with the own-fund part (Linked Fund populated) shown separately.",
             [("20", "Variable Compensation Award", "Award Instrument"), ("20", "Variable Compensation Award", "Linked Fund"),
              ("20", "Variable Compensation Award", "Award Amount"), "Total Variable Remuneration"]),
            ("Tranche Schedule Breaks", "Count of awards with Deferred Portion Percentage > 0 where the sum of Tranche Amount of their Deferred Award Tranches differs from Award Amount x Deferred Portion Percentage by more than one currency unit.",
             [("20", "Deferred Award Tranche", "Tranche Award"), ("20", "Deferred Award Tranche", "Tranche Amount"),
              ("20", "Variable Compensation Award", "Award Amount"), ("20", "Variable Compensation Award", "Deferred Portion Percentage")]),
            ("Unvested Deferred Remuneration", "Sum of Tranche Amount of Deferred Award Tranches with Tranche Vesting Status = Unvested, by year of Vesting Date, Vesting Basis and entity.",
             [("20", "Deferred Award Tranche", "Tranche Amount"), ("20", "Deferred Award Tranche", "Tranche Vesting Status"),
              ("20", "Deferred Award Tranche", "Vesting Date"), ("20", "Deferred Award Tranche", "Vesting Basis")]),
            ("Vesting With Unassessed Conduct Flag", "Count of Unvested tranches with Vesting Date in the next 90 days whose award recipient has a Performance Review with Conduct Adjustment Indicator = Y in a Review Cycle after the Award Grant Date, and whose Malus / Clawback Status = Not Applied.",
             [("20", "Deferred Award Tranche", "Vesting Date"), ("20", "Deferred Award Tranche", "Tranche Vesting Status"),
              ("20", "Deferred Award Tranche", "Malus / Clawback Status"), ("20", "Performance Review", "Reviewed Employee"),
              ("20", "Performance Review", "Review Cycle"), ("20", "Performance Review", "Conduct Adjustment Indicator"),
              ("20", "Variable Compensation Award", "Award Grant Date")]),
            ("Malus and Clawback Applied", "Sum of Malus / Clawback Adjustment Amount by Malus / Clawback Status (Malus Applied, Clawback Applied, Clawback Recovered), performance year of the award and entity.",
             [("20", "Deferred Award Tranche", "Malus / Clawback Adjustment Amount"), ("20", "Deferred Award Tranche", "Malus / Clawback Status"),
              ("20", "Variable Compensation Award", "Performance Year")]),
            ("Remuneration Under Clawback", "Sum of Tranche Amount of tranches with Tranche Vesting Status = Vested and Clawback Period End Date on or after the as-of date.",
             [("20", "Deferred Award Tranche", "Tranche Amount"), ("20", "Deferred Award Tranche", "Tranche Vesting Status"),
              ("20", "Deferred Award Tranche", "Clawback Period End Date")]),
            ("Unvested Tranches of Leavers", "Count and Tranche Amount of tranches with Tranche Vesting Status = Unvested whose award recipient has Employment Status = Terminated and a Termination Date before the as-of date, by Vesting Basis; each is a forfeiture not yet booked (Forfeited - Leaver) unless the plan's good-leaver terms keep it (no leaver reason on the tranche, see the gap).",
             [("20", "Deferred Award Tranche", "Tranche Vesting Status"), ("20", "Deferred Award Tranche", "Tranche Amount"),
              ("20", "Deferred Award Tranche", "Vesting Basis"), ("20", "Deferred Award Tranche", "Tranche Award"),
              ("20", "Employee", "Employee ID"), ("20", "Employee", "Employment Status"), ("20", "Employee", "Termination Date")]),
            ("Awards Without Committee Approval", "Count and Award Amount of awards with Variable Award Type in (Deferred Award, Retention Award, Sign-On Award, Buy-Out Award) whose Remuneration Committee Approval Date is blank or after Award Grant Date.",
             [("20", "Variable Compensation Award", "Variable Compensation Award ID"), ("20", "Variable Compensation Award", "Variable Award Type"),
              ("20", "Variable Compensation Award", "Award Amount"), ("20", "Variable Compensation Award", "Award Grant Date"),
              ("20", "Variable Compensation Award", "Remuneration Committee Approval Date")]),
            ("Own-Fund Deferral by Fund", "Sum of Tranche Amount of Unvested tranches of awards with Award Instrument = Units in Managed Funds, by Linked Fund (DP-004) and Vesting Date year; the firm's deferred co-investment in its own funds.",
             [("20", "Variable Compensation Award", "Award Instrument"), ("20", "Variable Compensation Award", "Linked Fund"),
              ("20", "Deferred Award Tranche", "Tranche Amount"), ("20", "Deferred Award Tranche", "Tranche Vesting Status"),
              ("20", "Deferred Award Tranche", "Vesting Date")]),
        ],
        inputs=[
            ("20", "Variable Compensation Award", ["Variable Compensation Award ID", "Award Recipient", "Variable Award Type",
                                                   "Performance Year", "Award Amount", "Award Currency", "Deferred Portion Percentage",
                                                   "Award Instrument", "Linked Fund", "Award Grant Date",
                                                   "Remuneration Committee Approval Date"]),
            ("20", "Deferred Award Tranche", ["Tranche Award", "Tranche Number", "Tranche Amount", "Vesting Basis", "Vesting Date",
                                              "Tranche Vesting Status", "Malus / Clawback Status",
                                              "Malus / Clawback Adjustment Amount", "Clawback Period End Date"]),
            ("20", "Base Pay Record", ["Paid Employee", "Pay Component", "Pay Component Amount", "Pay Currency", "Pay Amount Basis",
                                       "Pay Effective From", "Pay Effective To"]),
            ("20", "Performance Review", ["Reviewed Employee", "Review Cycle", "Review Type", "Calibrated Rating",
                                          "Conduct Adjustment Indicator", "Review Status"]),
            ("20", "Employee", ["Employee ID", "Employing Legal Entity", "Employment Status", "Termination Date"]),
        ],
        upstream=["DP-192", "DP-198", "DP-013", "DP-004"],
        refresh="Monthly",
        timeliness="Business day 5 after month-end; the annual award round published within 10 business days of the compensation committee's approval (Remuneration Committee Approval Date)",
        history="Every performance year's awards and tranches kept for the longest clawback period plus 7 years (SEC Rule 10D-1 recovery look-back where it applies; IRC section 409A plan records); monthly snapshots kept 10 years",
        classification="Confidential - Compensation",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Award Recipient resolves to an employee in DP-192 whose Employing Legal Entity is active in DP-013 for the performance year, and every Linked Fund to a DP-004 investment product.",
            "Tranche Numbers of an award are consecutive from 1, Vesting Dates increase with Tranche Number, and Clawback Period End Date, when populated, is on or after the tranche's Vesting Date.",
            "Every Variable Compensation Award with Deferred Portion Percentage > 0 has Deferred Award Tranches whose Tranche Amount sums to Award Amount x Deferred Portion Percentage within one currency unit, and every employee with Fixed Remuneration for a performance year has an Annualized Base Pay row in DP-198 on at least one day of that year; failing awards and employees are listed.",
            "Award Recipient, Variable Award Type, Performance Year and Award Amount are populated on every award, and Tranche Amount, Vesting Date and Tranche Vesting Status on every tranche.",
            "A tranche with Malus / Clawback Status in (Malus Applied, Clawback Applied, Clawback Recovered) has a Malus / Clawback Adjustment Amount greater than zero and not greater than its Tranche Amount; employee-level rows are visible to Reward, compliance and the compensation committee secretariat only.",
            "The month-end snapshot is published by business day 5 and locked; award round changes after the lock appear in the next month.",
        ],
        notes=("Certified numbers: none owned; amounts are compensation records, and compensation paid stays DP-198's (CD-347). "
               "Carry is not read (30 retired); the Linked Fund resolves through DP-004. PII tier: financial (employee "
               "compensation). Classified Confidential - Compensation, restricted to Reward, compliance and the compensation "
               "committee secretariat (DQ5). Boundaries: pay, payroll and benefits are DP-198's (base pay is read as it "
               "publishes it); performance ratings and conduct adjustments are 20 records published through DP-192; the code "
               "of ethics and conduct cases that cause an adjustment are DP-225's and 08's. Tailoring lever: SEC Rule 10D-1 "
               "recovery. Reference default: not applied (the firm is not listed); a listed parent adds the "
               "erroneously-awarded-compensation recovery to Remuneration Under Clawback. Tailoring lever: Dodd-Frank Section "
               "956 incentive compensation rules. Reference default: not in force (re-proposed 2024, not adopted). Tailoring "
               "lever: own-fund deferral. Reference default: deferred awards may be paid in units of the firm's own funds "
               "(Award Instrument = Units in Managed Funds). Taxonomy gap: no compensation policy parameter object (deferral "
               "minimum, deferral period, instrument share and ratio by role family). Taxonomy gap: Variable Compensation Award "
               "holds one Award Instrument per award, so a mixed cash and fund-unit award must be recorded as two awards for "
               "Instrument Share % to work. Taxonomy gap: 20 Deferred Award Tranche has no leaver reason or good-leaver treatment (Award Vesting Basis is "
               "Time-Based, Performance-Based or Time and Performance), so Unvested Tranches of Leavers cannot leave out tranches "
               "that vest on death, disability or retirement. Taxonomy gap: no IRC section 409A deferral election or distribution event on the "
               "award or tranche, so 409A timing compliance cannot be tested. Drafting assumptions: Employment Status value "
               "Terminated (20 list); the 90-day window. Decisions: CD-205, CD-344, CD-347, "
               "CW-208, CW-920. W4 re-point (CW-930, CW-165): 20 Variable Compensation Award.Carried Interest Points dropped, no "
               "successor (carried interest leaves with 30); no measure read it. W1b: Material Risk Taker Identification "
               "dropped, no successor (CW-920), with the measures Identified MRTs, Identifications Not Approved, Senior "
               "Managers Not Identified, Deferral Shortfalls, Invalid Deferral Exemptions and Identified Staff Copy Mismatches "
               "and the inputs only they read; Deferred Award Tranche.Retention Period End Date dropped (measure Early Releases "
               "Before Retention End removed). W1b re-point (CW-920): Total Variable Remuneration is keyed on Award Recipient "
               "and Performance Year; Remuneration Under Clawback filters on Tranche Vesting Status = Vested; Instrument Share % "
               "no longer tests the UCITS and AIFMD 50% rule. WP1 re-scope (CW-208): register row renamed 'Deferred Awards & "
               "Clawback' (from 'Remuneration Code: Material Risk Takers & Deferred Awards'); owner 20 and primary FN-41 kept; "
               "the definition is US only. Every measure name read by SM-15 (Total Variable Remuneration, Fixed Remuneration, "
               "Variable-to-Fixed Ratio, Instrument Share %, Tranche Schedule Breaks, Unvested Deferred Remuneration, Vesting "
               "With Unassessed Conduct Flag, Malus and Clawback Applied, Remuneration Under Clawback) and the entities "
               "Variable Compensation Award and Deferred Award Tranche of models_e8c_people_workplace_ai are kept; "
               "Variable-to-Fixed Ratio is redefined as a firm policy test. Measures added: 'Unvested Tranches of Leavers', "
               "'Awards Without Committee Approval' and 'Own-Fund Deferral by Fund'. No input dropped; 'Regulatory report' "
               "delivery dropped (no US remuneration report). Fix pass: Fixed Remuneration reads DP-198's Annualized Base Pay; "
               "amounts kept by currency (no conversion); the good-leaver exclusion dropped with a gap line; DQ3 replaced."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-217": dict(
        definition=("The firm's critical business functions with the people, applications, IT services, sites, suppliers and "
                    "business processes each depends on, their business impact analyses, business continuity plans and "
                    "resilience test results against the recovery objectives. Functions, mapping, BIAs, plans and tests are "
                    "mastered in 37 (CD-249); the recovery tier, RTO and RPO of each application and the technical DR test "
                    "results come from 41 through DP-211 (CD-270), and the supplier tier from DP-210. Its main measure is the "
                    "gap between what the business needs (37 BIA) and what technology recovers (41 recovery profile). It "
                    "evidences the FINRA Rule 4370 business continuity plan of the broker-dealer (annual review, mission "
                    "critical systems, critical business constituents, banks and counterparties, and emergency communication), "
                    "the continuity elements of the adviser's and funds' compliance programs (Rules 206(4)-7 and 38a-1) and the "
                    "interagency sound practices, and owns no certified metric family."),
        business_questions=[
            "Did each business continuity plan meet its recovery objectives in its latest scenario test, and which plans are untested or unreviewed in the last 12 months (the Rule 4370 annual review)?",
            "Which mission critical applications supporting a critical business function recover more slowly, or lose more data, than the business impact analysis allows?",
            "Which mapped applications failed their last disaster recovery test or missed their RTO in it?",
            "Which functions lack a mapped resource of each type, and which depend on a Tier 1 supplier, program bank or clearing utility with no outsourcing arrangement recorded?",
            "Which plans have had no call tree test of their emergency communications in the last 12 months, and which resilience test issues are still open?",
        ],
        grain="Critical business function x effective period, with child grains function x mapped resource, business process x BIA date, continuity plan x version and resilience test x test date; weekly snapshots",
        dimensions=["Critical or important function", "Designating legal entity (DP-013)", "Resilience resource type",
                    "Mapped application and recovery tier (DP-211)", "Mapped IT service", "Mapped supplier engagement and criticality tier (DP-210)",
                    "Mapped site", "Business process", "Continuity plan", "Resilience test type and date", "Tolerance met indicator"],
        measures=[
            ("Plans Meeting Recovery Objectives %", "Business Continuity Plans (latest Business Continuity Plan Version) whose latest Resilience Test of Resilience Test Type = Scenario Test naming the plan as Tested Continuity Plan has Tolerance Met Indicator = Y (the covered processes recovered within their BIA recovery time objectives) / Business Continuity Plans with Plan Approval Status = Approved.",
             _u("37", "Business Continuity Plan", "Business Continuity Plan Code", "Business Continuity Plan Version", "Plan Approval Status")
             + _u("37", "Resilience Test", "Resilience Test Date", "Resilience Test Type", "Tested Continuity Plan", "Tolerance Met Indicator")),
            ("Plans Untested (12 Months)", "Approved Business Continuity Plans with no Resilience Test naming them as Tested Continuity Plan with a Resilience Test Date in the 12 months to the as-of date.",
             _u("37", "Resilience Test", "Resilience Test Date", "Tested Continuity Plan")
             + _u("37", "Business Continuity Plan", "Business Continuity Plan Code", "Plan Approval Status")),
            ("Application RTO Gap Hours", "For each Resilience Resource Mapping of Resilience Resource Type = Application effective on the as-of date: Recovery Time Objective Hours of the Mapped Application (41, from DP-211) - the smallest Recovery Time Objective Hours of the latest Business Impact Analysis of each business process mapped to the same function; a positive value is a gap. Count of mapped applications with a gap, by function.",
             _u("37", "Resilience Resource Mapping", "Mapped Function", "Resilience Resource Type",
                "Mapped Application", "Mapped Business Process", "Mapping Effective From", "Mapping Effective To")
             + _u("41", "Application", "Application ID")
             + _u("41", "Application Recovery Profile", "Recovery Time Objective Hours")
             + _u("37", "Business Impact Analysis", "Analyzed Business Process", "BIA Date", "Recovery Time Objective Hours")),
            ("Application RPO Gap", "For each mapped application: Recovery Point Objective Minutes (41) - 60 x the smallest Recovery Point Objective Hours of the latest BIAs of business processes mapped to the same function; count of mapped applications with a positive gap.",
             _u("41", "Application Recovery Profile", "Recovery Point Objective Minutes")
             + _u("37", "Business Impact Analysis", "Analyzed Business Process", "BIA Date", "Recovery Point Objective Hours")
             + _u("37", "Resilience Resource Mapping", "Mapped Application", "Mapped Business Process", "Mapped Function")),
            ("Mapped Applications Failing DR", "Mapped applications whose latest 41 Security & Resilience Test of Test Type = ICT Disaster Recovery Failover listing them in Tested Applications has Test Outcome = Failed, or Achieved Recovery Time Hours > the application's Recovery Time Objective Hours; also those with no such test in 12 months.",
             _u("41", "Security & Resilience Test", "Test Code", "Test Type", "Tested Applications", "Test End Date", "Test Outcome",
                "Achieved Recovery Time Hours")
             + _u("41", "Application Recovery Profile", "Recovery Time Objective Hours")
             + _u("37", "Resilience Resource Mapping", "Mapped Application")),
            ("Mapping Gaps", "Critical or Important Functions effective on the as-of date lacking an effective Resilience Resource Mapping of each Resilience Resource Type People, Application, Site and Third Party; count by missing type.",
             _u("37", "Resilience Resource Mapping", "Mapped Function", "Resilience Resource Type",
                "Mapping Effective From", "Mapping Effective To")
             + _u("37", "Critical or Important Function", "Critical Function Code", "Function Effective From", "Function Effective To")),
            ("Critical Supplier Dependencies", "Count of Mapped Supplier Engagements of active engagements by Third-Party Criticality Tier (from DP-210) per function, including program banks, sub-transfer agents and clearing utilities engaged as suppliers; flagged where the engagement is Tier 1 - Critical and no 40 Outsourcing Arrangement for that engagement lists the function in Supported Critical or Important Functions.",
             _u("37", "Resilience Resource Mapping", "Mapped Supplier Engagement", "Mapped Function")
             + _u("40", "Supplier Engagement", "Supplier Engagement ID", "Engagement Status")
             + _u("40", "Supplier Risk Tiering", "Tiered Engagement", "Third-Party Criticality Tier", "Tier Effective From", "Tier Effective To")
             + _u("40", "Outsourcing Arrangement", "Outsourcing Engagement", "Supported Critical or Important Functions")),
            ("Key-Person Dependencies", "Count of Mapped Workforce Positions with Key-Person Risk Indicator = Y and Position Status in (Open, Filled) (from DP-192), by function.",
             _u("37", "Resilience Resource Mapping", "Mapped Workforce Position")
             + _u("20", "Workforce Position", "Workforce Position ID", "Key-Person Risk Indicator", "Position Status")),
            ("Stale BIAs and Plans", "Count of business processes mapped to a function whose latest BIA Date is more than 12 months old, plus Business Continuity Plans (latest version) with Plan Approval Status other than Approved or Plan Last Reviewed Date more than 12 months old (the FINRA Rule 4370(b) annual review).",
             _u("37", "Business Impact Analysis", "Analyzed Business Process", "BIA Date")
             + _u("37", "Business Continuity Plan", "Business Continuity Plan Code", "Business Continuity Plan Version",
                  "Plan Approval Status", "Plan Last Reviewed Date")),
            ("Plans Without Call Tree Test (12 Months)", "Approved Business Continuity Plans with no Resilience Test of Resilience Test Type = Call Tree Test naming them as Tested Continuity Plan in the 12 months to the as-of date; the evidence that the emergency communications with employees, clients and regulators (Rule 4370(c)) work.",
             _u("37", "Resilience Test", "Resilience Test Type", "Resilience Test Date", "Tested Continuity Plan")
             + _u("37", "Business Continuity Plan", "Business Continuity Plan Code", "Plan Approval Status")),
            ("Open Resilience Issues", "Count of Risk Issues with a Source Resilience Test and Issue Status not in (Resolved / Completed, Closed, Canceled) (from DP-216), and those past Issue Due Date, by the test's Tested Continuity Plan.",
             _u("37", "Risk Issue", "Risk Issue ID", "Source Resilience Test", "Issue Status", "Issue Due Date")
             + _u("37", "Resilience Test", "Resilience Test Reference", "Tested Continuity Plan")),
        ],
        inputs=[
            ("37", "Critical or Important Function", ["Critical Function Code", "Critical Function Name", "Designating Entity",
                                                      "Function Effective From", "Function Effective To"]),
            ("37", "Resilience Resource Mapping", ["Mapped Function", "Resilience Resource Type",
                                                   "Mapped Workforce Position", "Mapped Business Process", "Mapped Application",
                                                   "Mapped IT Service", "Mapped Site", "Mapped Supplier Engagement",
                                                   "Mapping Effective From", "Mapping Effective To"]),
            ("37", "Business Impact Analysis", ["Analyzed Business Process", "BIA Date", "Recovery Time Objective Hours",
                                                "Recovery Point Objective Hours", "Maximum Tolerable Period of Disruption Hours"]),
            ("37", "Business Continuity Plan", ["Business Continuity Plan Code", "Business Continuity Plan Version", "Plan Scope",
                                                "Plan Invocation Criteria", "Plan Owner", "Plan Approval Status",
                                                "Plan Last Reviewed Date"]),
            ("37", "Resilience Test", ["Resilience Test Reference", "Resilience Test Date", "Resilience Test Type",
                                       "Tested Continuity Plan", "Resilience Test Scenario",
                                       "Source Security and Resilience Test", "Tolerance Met Indicator"]),
            ("37", "Risk Issue", ["Risk Issue ID", "Source Resilience Test", "Issue Status", "Issue Due Date"]),
            ("41", "Application", ["Application ID", "Application Name", "Criticality Tier", "Application Status"]),
            ("41", "Application Recovery Profile", ["Recovery Tier", "Recovery Time Objective Hours", "Recovery Point Objective Minutes",
                                                    "Disaster Recovery Strategy"]),
            ("41", "Security & Resilience Test", ["Test Code", "Test Type", "Tested Applications", "Tested IT Services", "Test End Date",
                                                  "Test Outcome", "Achieved Recovery Time Hours"]),
            ("41", "IT Service", ["IT Service Code", "IT Service Name", "Supporting Applications", "Third-Party Service Provider",
                                  "IT Service Status"]),
            ("40", "Supplier Engagement", ["Supplier Engagement ID", "Engaged Supplier", "Engagement Status"]),
            ("40", "Supplier Risk Tiering", ["Tiered Engagement", "Third-Party Criticality Tier", "Tier Effective From", "Tier Effective To"]),
            ("40", "Outsourcing Arrangement", ["Outsourcing Arrangement ID", "Outsourcing Engagement",
                                               "Supported Critical or Important Functions"]),
            ("20", "Workforce Position", ["Workforce Position ID", "Key-Person Risk Indicator", "Position Status"]),
            ("20", "Employee", ["Employee ID", "Employment Status"]),
            ("09", "Office Location", ["Office ID", "Office Country / Subdivision"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name"]),
        ],
        upstream=["DP-211", "DP-210", "DP-214", "DP-216", "DP-192", "DP-013"],
        refresh="Weekly",
        timeliness="By 8am ET each Monday, and on demand after a resilience test or a mapping change; the annual FINRA Rule 4370 plan review snapshot is locked when senior management approves it",
        history="SCD type 2 on functions, mappings and plans; every BIA and resilience test kept; annual plan review snapshots kept 6 years (SEC Rule 17a-4 for the broker-dealer's plan records)",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Critical or Important Function effective on the as-of date has a Designating Entity that resolves to an active internal legal entity in DP-013, every Mapped Application resolves to a DP-211 Application with Application Status = In Production and an Application Recovery Profile, and every Mapped Supplier Engagement to a DP-210 engagement.",
            "Mapping Effective To is on or after Mapping Effective From and Function Effective To on or after Function Effective From, and every Resilience Resource Mapping has exactly one typed resource column populated, matching its Resilience Resource Type.",
            "Every Resilience Test of type DR Test Result Received names a Source Security and Resilience Test that resolves to a 41 test of Test Type ICT Disaster Recovery Failover, and Open Resilience Issues equals the DP-216 count of open issues with a Source Resilience Test.",
            "Recovery Time Objective Hours and Maximum Tolerable Period of Disruption Hours are populated on every BIA, with Recovery Time Objective Hours not greater than Maximum Tolerable Period of Disruption Hours, and Plan Approval Status and Plan Last Reviewed Date on every plan version.",
            "Plan Owner and Mapped Workforce Position are employee keys visible to operational resilience and the plan owners; the wide view shows counts by function, plan and resource type.",
            "The weekly snapshot is published by Monday 8am ET; the annual Rule 4370 review snapshot is locked on senior management approval and never changed.",
        ],
        notes=("Inputs and their masters: Critical or Important Function, Resilience Resource Mapping, Business Impact Analysis, Business "
               "Continuity Plan and Resilience Test are mastered in 37 (CD-249); the application recovery tier, RTO and RPO and "
               "the technical DR results are 41's, read through DP-211 (CD-270); the BIA holds the business requirement and the "
               "gap between them is the product's main measure. Supplier identity and the inherent tier come from DP-210 "
               "(CD-248). 40 Outsourcing Arrangement is read only for the function it supports, because that relationship lives "
               "on the arrangement (CD-261); the outsourcing register itself is DP-220, which lists this product upstream. "
               "Key-person flags are read from 20 Workforce Position through DP-192 (CD-249). Mapped Site is a 09 Office "
               "Location key (DP-013). Remediation status of resilience test issues is DP-216's (CD-356). Certified numbers: "
               "none. PII tier: identity. Plan Owner is an employee key and Mapped Workforce Position can identify a key person; "
               "the wide view shows counts (DQ5). Boundaries: Reg S-P incident response programs are DP-595's and security "
               "incidents DP-232's; this product holds continuity, not incident response. Program banks, sub-transfer agents "
               "and clearing utilities enter as 40 supplier engagements (RESPEC DP-219 adds them to the critical provider "
               "tiers). Tailoring lever: trust company. Reference default: not offered; a trust company adds its functions "
               "and plans under the same grain. Tailoring lever: review cycle. Reference default: 12 months (FINRA Rule 4370 "
               "requires an annual review). Tailoring lever: business process keys (37 Q13). Reference "
               "default: business process codes stay capability codes held as text; a mastered capability map turns them into "
               "references with the same grain. Taxonomy gap: Business Impact Analysis is keyed by business process "
               "text (a capability code), not by function, so the RTO gap joins BIA to functions only through the Mapped "
               "Business Process of the mapping. Taxonomy gap: Business Continuity Plan and Resilience Test hold no reference "
               "to a Critical or Important Function, so plan and test results are not rolled up to functions. Taxonomy gap: "
               "Resilience Test holds no achieved recovery time of its own for scenario tests; only 41 DR tests carry Achieved "
               "Recovery Time Hours. Taxonomy gap: 37 has no record of the FINRA Rule 4370(f) emergency contact persons or of "
               "their annual update in the FINRA Contact System. Drafting assumptions: the 12-month windows (Resilience Test "
               "Type, Position Status and Shared: Case Status values are from their lists). Decisions: CD-248, CD-249, CD-261, "
               "CD-268, CD-270, CD-356, CW-208, CW-937, CW-940. W1b: Important Business Service and Impact Tolerance dropped, "
               "no successor (CW-937; the UK SYSC 15A regime has no US entity), with the service-keyed attributes and the "
               "measures Services Within Tolerance %, Services Untested (12 Months) and Services Without Impact Tolerance. W1b "
               "re-point (CW-937): the critical or important function is kept as a US concept (interagency sound practices, "
               "FINRA Rule 4370), so the product is keyed on it. WP1 re-scope (CW-208): register row renamed 'Critical "
               "Functions & Business Continuity' (from 'Operational Resilience & Impact Tolerances'); owner 37 and primary FN-42 "
               "kept; the definition and questions are FINRA Rule 4370 and the US sound practices, with no DORA or UK "
               "operational resilience content. Every measure name read by SM-16 and the entities Critical or Important "
               "Function, Resilience Resource Mapping, Business Impact Analysis, Resilience Test, Business Continuity Plan, "
               "Outsourcing Arrangement and Workforce Position of models_e8c_risk_audit_third_party are kept. Measure added: "
               "'Plans Without Call Tree Test (12 Months)'. Inputs added: 37 Business Continuity Plan.Plan Invocation Criteria "
               "and Risk Issue.Issue Due Date. No input or measure dropped. Fix pass: classification Confidential - Personal Data "
               "(was Confidential); Position Status and Issue Status values aligned to their lists."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-228": dict(
        definition=("Trade surveillance alerts by scenario (38 Trade Surveillance Alert) on the firm's portfolio orders and "
                    "executions (25, through DP-123), on clients' brokerage orders and executions (48, through DP-301) and on "
                    "employees' personal transactions (38, through DP-225), with their review status and disposition, the "
                    "related communications alert where one exists, and the escalation of suspicious trading to an AML case "
                    "for the FinCEN suspicious activity report decision (31 CFR 1023.320). It shows compliance alert volumes, "
                    "aging and outcomes by desk, business line and scenario, and evidences market-abuse surveillance under "
                    "Advisers Act Section 204A, FINRA Rules 3110, 5270 and 5320 and the hand-off of suspicious activity to the "
                    "AML program without disclosing whether a SAR was filed. It owns no certified metric family."),
        business_questions=[
            "How many trade surveillance alerts were generated this month, by scenario, desk, business line and subject type (portfolio order, client order or personal transaction), and how does that trend?",
            "How many alerts are open and how old are they, and which scenarios carry the backlog?",
            "What share of alerts were closed as no issue or explained, or escalated to an AML case, a code of ethics violation or legal, by scenario?",
            "Which client-order alerts (trading ahead, front running of customer orders) arose on discretionary or advised accounts?",
            "How many alerts were escalated for a suspicious activity review, and how quickly did the AML program open a case (AML officer view)?",
        ],
        grain=("Trade surveillance alert (TRSV-) x as-of date, with bridge rows alert x subject portfolio order, alert x subject "
               "execution, alert x subject client order, alert x subject client execution and alert x subject personal "
               "transaction; daily backlog snapshots"),
        dimensions=["Alert generated date", "Surveillance scenario", "Alert status and disposition", "Desk (trader's org unit, DP-192)",
                    "Trading legal entity (DP-013)", "Instrument, issuer and asset class (DP-097)", "Portfolio type and business line (DP-140)",
                    "Client account type and business line (DP-093)", "Executing broker (DP-115)",
                    "Subject type (portfolio order, client order or personal transaction)", "Age bucket"],
        measures=[
            ("Alerts Generated", "Count of Trade Surveillance Alerts by Alert Generated Timestamp period and Surveillance Scenario, sliced by the subject portfolio order's Trading Legal Entity, the instrument's Asset Class and the Assigned Trader's Home Org Unit (desk), or for client-order alerts by the order account's Account Business Line.",
             [("38", "Trade Surveillance Alert", "Trade Surveillance Alert ID"), ("38", "Trade Surveillance Alert", "Alert Generated Timestamp"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario"), ("38", "Trade Surveillance Alert", "Subject Trade Orders"),
              ("25", "Trade Order", "Trade Order ID"), ("25", "Trade Order", "Trading Legal Entity"),
              ("25", "Trade Order", "Order Instrument"), ("17", "Instrument", "Asset Class"),
              ("25", "Trade Order", "Assigned Trader"), ("20", "Employee", "Home Org Unit"),
              ("15", "Account", "Account Business Line")]),
            ("Open Alert Backlog", "Alerts with Surveillance Alert Status not in (Resolved / Completed, Closed, Canceled), aged in business days since Alert Generated Timestamp (0-5, 6-20, 21-60, over 60), by Surveillance Scenario.",
             [("38", "Trade Surveillance Alert", "Surveillance Alert Status"), ("38", "Trade Surveillance Alert", "Alert Generated Timestamp"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario")]),
            ("Disposition Mix", "Share of alerts closed in the period by Surveillance Disposition (Closed - No Issue, Closed - Explained, Escalated - AML Case, Escalated - Code of Ethics Violation, Escalated - Legal), by Surveillance Scenario; the false-positive rate is the share closed as no issue.",
             [("38", "Trade Surveillance Alert", "Surveillance Disposition"), ("38", "Trade Surveillance Alert", "Surveillance Scenario"),
              ("38", "Trade Surveillance Alert", "Surveillance Alert Status")]),
            ("Personal Dealing Alert Share", "Alerts with Subject Personal Transactions populated / alerts generated in the period, by Surveillance Scenario; personal transactions resolve to DP-225 rows.",
             [("38", "Trade Surveillance Alert", "Subject Personal Transactions"), ("38", "Personal Transaction", "Broker Transaction Reference"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario")]),
            ("Client Order Alerts", "Alerts with Subject Client Orders or Subject Client Executions populated, by Surveillance Scenario (Trading Ahead of Customer Orders, Front Running of Block Transactions and the others), with the share whose client orders have Discretionary Order Indicator = Y or a Source Recommendation, and by Order Source; client orders and executions resolve to DP-301 rows.",
             [("38", "Trade Surveillance Alert", "Subject Client Orders"), ("38", "Trade Surveillance Alert", "Subject Client Executions"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario"), ("48", "Client Order", "Client Order ID"),
              ("48", "Client Order", "Order Account"), ("48", "Client Order", "Order Source"),
              ("48", "Client Order", "Discretionary Order Indicator"), ("48", "Client Order", "Source Recommendation"),
              ("48", "Client Execution", "Client Execution ID")]),
            ("Client Order Alerts Before Portfolio Orders", "Client Order Alerts of scenario Trading Ahead of Customer Orders or Front Running of Portfolio Orders whose subject client order's Order Received Timestamp precedes a subject portfolio order's Order Created Timestamp in the same Order Instrument on the same day; the cross-book pattern the firm's own flow creates.",
             ["Client Order Alerts"]
             + [("48", "Client Order", "Order Received Timestamp"), ("48", "Client Order", "Order Instrument"),
                ("25", "Trade Order", "Order Created Timestamp"), ("25", "Trade Order", "Order Instrument")]),
            ("Communications Linkage Rate", "Escalated alerts with Related Communications Alert populated / escalated alerts. The 08 alert is read only to confirm it exists and its Alert Disposition; no communications alert is counted here (CD-256).",
             [("38", "Trade Surveillance Alert", "Related Communications Alert"), ("38", "Trade Surveillance Alert", "Surveillance Disposition"),
              ("08", "Surveillance Alert", "Alert ID"), ("08", "Surveillance Alert", "Alert Disposition")]),
            ("Alerts on Restricted Names", "Alerts whose subject order's Order Instrument, or its Issuer, was on an open Restricted List Entry (from DP-227) at Order Created Timestamp, by Surveillance Scenario.",
             [("25", "Trade Order", "Order Instrument"), ("25", "Trade Order", "Order Created Timestamp"), ("17", "Instrument", "Issuer"),
              ("38", "Restricted List Entry", "Restricted Issuer"), ("38", "Restricted List Entry", "Restricted Instruments"),
              ("38", "Restricted List Entry", "Entry Added Timestamp"), ("38", "Restricted List Entry", "Entry Removed Timestamp"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario")]),
            ("Alerts Escalated to AML",
             "Count of alerts with Surveillance Disposition = Escalated - AML Case in the period, by Surveillance Scenario and "
             "subject type; the hand-off to the AML program for the SAR decision. Published in the AML officer and "
             "surveillance-lead view only; other views show Disposition Mix without this split (DQ5).",
             [("38", "Trade Surveillance Alert", "Trade Surveillance Alert ID"), ("38", "Trade Surveillance Alert", "Surveillance Disposition"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario")]),
            ("Escalation to Case Days",
             "Calendar days from Alert Generated Timestamp to the Case Opened Date of the AML Case whose Source Trade "
             "Surveillance Alert is the alert, averaged and at the maximum, by Surveillance Scenario; cases with AML Case Type "
             "= Elder Financial Exploitation are excluded at extraction, and the measure is published in the AML officer view "
             "only (DQ5).",
             [("38", "Trade Surveillance Alert", "Alert Generated Timestamp"), ("38", "AML Case", "Source Trade Surveillance Alert"),
              ("38", "AML Case", "AML Case Type"), ("38", "AML Case", "Case Opened Date"),
              ("38", "Trade Surveillance Alert", "Surveillance Scenario")]),
        ],
        inputs=[
            ("38", "Trade Surveillance Alert", ["Trade Surveillance Alert ID", "Surveillance Scenario", "Alert Generated Timestamp",
                                                "Subject Trade Orders", "Subject Executions", "Subject Client Orders",
                                                "Subject Client Executions", "Subject Personal Transactions",
                                                "Related Communications Alert", "Surveillance Alert Status",
                                                "Surveillance Disposition"]),
            ("25", "Trade Order", ["Trade Order ID", "Order Portfolio", "Order Instrument", "Order Side", "Order Created Timestamp",
                                   "Assigned Trader", "Trading Legal Entity"]),
            ("25", "Execution", ["Execution ID", "Execution Placement", "Executed Quantity", "Execution Price", "Execution Timestamp",
                                 "Execution Venue"]),
            ("25", "Broker Placement", ["Placement Block Order", "Placement Sequence Number", "Placement Broker"]),
            ("48", "Client Order", ["Client Order ID", "Order Account", "Order Instrument", "Order Side", "Order Source",
                                    "Source Recommendation", "Discretionary Order Indicator", "Order Received Timestamp"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Executed Quantity", "Execution Price",
                                        "Execution Timestamp", "Execution Venue MIC"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Business Line"]),
            ("38", "Personal Transaction", ["Broker Transaction Reference", "Transaction Account", "Personal Trade Date", "Traded Security"]),
            ("38", "Restricted List Entry", ["Restricted List Entry ID", "Restricted Issuer", "Restricted Instruments",
                                             "Entry Added Timestamp", "Entry Removed Timestamp"]),
            ("38", "AML Case", ["AML Case Number", "AML Case Type", "Source Trade Surveillance Alert", "Case Opened Date"]),
            ("08", "Surveillance Alert", ["Alert ID", "Alert Disposition"]),
            ("17", "Instrument", ["Instrument ID", "Issuer", "Instrument Type", "Asset Class"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Managing Entity"]),
            ("20", "Employee", ["Employee ID", "Home Org Unit"]),
            ("09", "Org Unit", ["Org Unit ID", "Org Unit Name"]),
        ],
        upstream=["DP-123", "DP-301", "DP-227", "DP-225", "DP-078", "DP-097", "DP-115", "DP-140", "DP-093", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET each business day for alerts generated on the prior trading day (T+1)",
        history="Alerts and dispositions kept as SCD type 2 for 6 years (SEC Rule 17a-4 and FINRA Rule 4511; at least 5 years under Advisers Act Rule 204-2); AML case linkage kept 5 years from the case decision (31 CFR 1023.320(d)); daily backlog snapshots kept 3 years",
        classification="Restricted - Legal",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "File extract"],
        dq_rules=[
            "Every Trade Surveillance Alert has at least one of Subject Trade Orders, Subject Executions, Subject Client Orders, Subject Client Executions or Subject Personal Transactions populated, each resolving to a DP-123 Trade Order or Execution, a DP-301 Client Order or Client Execution, or a DP-225 Personal Transaction, and every Order Account to a DP-093 account.",
            "Alert Generated Timestamp is on or after the Order Created Timestamp of every subject portfolio order and the Order Received Timestamp of every subject client order.",
            "Every alert with Surveillance Disposition in (Escalated - AML Case, Escalated - Code of Ethics Violation, Escalated - Legal) has Surveillance Alert Status in (Escalated, Resolved / Completed, Closed), every AML Case read names a Source Trade Surveillance Alert that resolves to an alert with Surveillance Disposition = Escalated - AML Case, and every Related Communications Alert resolves to an 08 Alert ID.",
            "Every alert with Surveillance Alert Status = Closed has a Surveillance Disposition, and Surveillance Scenario and Alert Generated Timestamp are populated on every alert.",
            "SAR Decision, Case Decision Date, AML Case Actions and Case Subject Parties are never read, and AML Case rows with AML Case Type = Elder Financial Exploitation never enter the product (zero-row check), so the product cannot show whether or when a SAR was filed (31 CFR 1023.320(e)); Alerts Escalated to AML and Escalation to Case Days exist only in the AML officer view, individual alert rows go to compliance surveillance and the AML officer only, and other views show counts by scenario and desk without the AML split.",
            "Alerts of trading day T are published by 9am ET on T+1, and the daily backlog snapshot is locked once published.",
        ],
        notes=("Certified numbers: none. Operating model (CD-297): if surveillance runs on a vendor engine (38 SME question 8), alerts arrive as provider data at the same grain and dispositions stay 38's. PII tier: identity. Personal transactions, assigned traders, client order accounts and "
               "Order Portfolio (flagged for institutional separate accounts) identify individuals; individual rows go to compliance surveillance "
               "only (DQ5). Classified Restricted - Legal: escalations must not be disclosed to the persons concerned and SAR "
               "confidentiality applies (31 CFR 1023.320(e)); the AML Case is read only for its key, its Source Trade "
               "Surveillance Alert link and its opened and decision dates. Boundaries: the AML case, the SAR decision and its "
               "filing timeliness are DP-226's ('Days to SAR Decision', 'Report Filing Timeliness %', 'Unlinked Escalations'); DP-226 lists this "
               "product upstream and reads the escalated alerts from here, so this product reads 38 AML Case directly and must "
               "not take DP-226 upstream (no cycle). Communications surveillance stays in DP-078 (CD-256, CD-298); the 08 "
               "Surveillance Alert is read only through Related Communications Alert to confirm linkage, and DP-078 stays "
               "upstream by the CLA-B ruling (it was pending re-scope when this was written; CLA-B re-specified it at WP1, which "
               "cleared the pending-dependency warning). Sales-practice surveillance is 08 (CW-163). Portfolio orders and "
               "executions are read through DP-123 (CD-314), client orders and executions through DP-301, personal transactions "
               "through DP-225, restricted names through DP-227; brokers resolve to DP-115 through Placement Broker. Tailoring lever: client-order surveillance scope. Reference default: "
               "every brokerage and advisory client order is in scope of the trading-ahead and front-running scenarios. "
               "Tailoring lever: surveillance vendor. Reference default: in-house rules engine. Taxonomy gap: Trade Surveillance "
               "Alert has no reviewer, review closed timestamp or suspicion-formed timestamp, so time to close and the SAR "
               "window are measured from Alert Generated Timestamp. Taxonomy gap: Surveillance Scenario has no link to the "
               "market abuse type (insider dealing, manipulation); a maintained crosswalk is needed. Drafting assumptions: "
               "the age buckets (Surveillance Alert Status and Surveillance Disposition values are from their lists). "
               "Decisions: CD-256, CD-297, CD-298, CD-314, CW-110, CW-163, CW-208, CW-938. W4 re-point (CW-938, CW-163): 38 "
               "Suspicious Transaction and Order Report dropped, no successor (EU and UK MAR Article 16 STORs), with the "
               "measures STOR Count and Rate, Alert-to-STOR Days and Escalated Without STOR Flag. WP1 re-scope (CW-208): "
               "register row renamed 'Trade Surveillance & Suspicious Activity Reporting'; owner 38 and primary FN-44 kept; the "
               "FinCEN SAR hand-off replaces the STOR (measures added: 'Alerts Escalated to AML' and 'Escalation to Case Days', "
               "both in the AML officer view); 48 client orders and executions "
               "become subjects (inputs added: 38 Trade Surveillance Alert.Subject Client Orders and Subject Client Executions, "
               "48 Client Order, 48 Client Execution, 15 Account, 38 AML Case; measures added: 'Client Order Alerts' and "
               "'Client Order Alerts Before Portfolio Orders'); upstream adds DP-301 and DP-093. Input dropped: 25 Approved "
               "Counterparty Profile (brokers resolve through DP-115). Every earlier measure name and the Trade Surveillance "
               "Alert entity of models_e8c_compliance_legal (read by the DP-226 model) are kept; classification moves from "
               "Restricted to Restricted - Legal. Dimensions changed from the wholesale spec: 'Desk (trader's org unit)' now names "
               "DP-192, 'Trading legal entity', 'Instrument, issuer and asset class', 'Portfolio type and business line' and "
               "'Executing broker' name their source products, 'Client account type and business line (DP-093)' is added and "
               "'Subject type (firm order or personal transaction)' becomes 'Subject type (portfolio order, client order or "
               "personal transaction)'; no semantic model reads DP-228 dimensions. Fix pass: drops 'Escalations Without AML "
               "Case' (DP-226's 'Unlinked Escalations') and 'Escalated Cases Undecided After 30 Days' (DP-226's SAR-decision "
               "timing); 38 AML Case.Case Decision Date no longer read and AML Case Type read to exclude elder-exploitation "
               "cases; AML-linked measures moved to the AML officer view."),
    ),
}
