"""Wave WP1C (consumer), agent C-6 'INV + IOP + FDN': attribute-level specifications of the wealth-manager rework
(Wealth_Manager_Rework_Plan.md sections 8.2, 8.5 and 10; 00_Program/Rework/Product_Briefs/WP1_Method.md section 5;
WP1_Scope.md sections 3 and 6).

Products, in dependency order:
- DP-531 CMA & Model Lineup Governance and Lineup Drift (24 Portfolio Management & Construction)
- DP-535 Manager Search, Selection & Due Diligence (52 External Manager & Sub-Adviser Oversight; backlog DP-539 folds in)
- DP-536 Sub-Adviser Oversight Scorecard (52; backlog DP-537 folds in; acceptance question 12)
- DP-538 Sub-Adviser Hires, Terminations & Section 15(c) Renewal Evidence (52; acceptance question 12)
- DP-544 Trade Rotation & Cross-Book Allocation Fairness (25 Trading & Execution)
- DP-532 Household & Account Performance View (32 Performance & Attribution; acceptance question 9)
- DP-533 Personal Return Exceptions, Suppression & Restatements (32)
- DP-515 Reference Data & Code List Governance (09 Shared & Enterprise Reference Data)
- DP-516 Retail Tradable Instrument Coverage & Eligibility (17 Instrument & Issuer Reference; backlog DP-543 folds in)
- DP-518 Personal Data Tiers & Restricted-View Register (21 Data Governance & Analytics)
- DP-044 Third-Party Data Entitlements, Usage & Cost (14 Third-Party Data & Licensing): re-scoped in place with the scope
  of candidate DP-519 by the program lead's WP0 ruling (five live dependents keep the id); DP-519 is merged into it and
  backlog DP-520, DP-521 and DP-522 fold in
- DP-130 Institutional Separate Account Tax Management (24; register name still SMA Customization & Tax Management): re-scoped in place to the 18 portfolio book of institutional separate
  accounts (CW-048, CW-208)

Not specified (WP1_Scope.md section 5, backlog): DP-517, DP-534, DP-537, DP-539, DP-540, DP-541, DP-542, DP-543, DP-520 to
DP-522. DP-135 stays live on its Wave E2 specification (RESCOPE_BACKLOG).

WP1 decisions applied: certified numbers are read from their owners, never recomputed (CW-011): Personal Return Value
from DP-145 only (CW-251), fund net assets from DP-165; client holdings are the 49 brokerage book (DP-300), fund and
institutional holdings the 18 book (DP-142), never 06 (CW-007); sub-adviser oversight readings are Derived copies pinned
to their source version (CW-119, CW-252); Section 15(c) content is DP-538's and the renewal DP-183's (CW-253); Product
List Status is read from DP-306 (CW-254); 25 and 48 trade records are joined by key only (CW-255); household and advisor
economics reach users only through registered restricted views (CW-243). See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    """(NN, object, attribute) use tuples for one object."""
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-531": dict(
        definition=("The investment committee's control view of the advice models: whether every capital market assumption "
                    "set and model lineup in use carries a current committee approval, whether each lineup still points at "
                    "the latest CMA set, which building blocks have lost their Approved status on the 52 Advice Models list, "
                    "and how far each model's effective target weights have drifted from the design of its lineup position "
                    "(nominal equity share, glide path point and allocation policy bands). It reads the CMA sets, lineups, "
                    "building blocks and model target sets published by DP-530 and the list status published by DP-306 and "
                    "lets the committee show that every advice model rests on an approved set and approved products. It owns "
                    "no certified metric family."),
        business_questions=[
            "Does every advice model in use rest on a capital market assumption set and a model lineup that the investment committee approved within the review cycle (DP-530's 400-day staleness threshold)?",
            "Which lineups still point at a superseded CMA set version, and which CMA sets rest on a generating model that is no longer in use?",
            "Which lineup positions carry model target weights whose equity share has drifted from the position's nominal equity share or glide path point beyond tolerance?",
            "Which model target sets break the minimum and maximum bands of the lineup's asset allocation policy?",
            "Which building blocks are no longer Approved on the 52 Advice Models list, and which models and lineup positions still use them?",
        ],
        grain=("Model lineup version x lineup position (01 model portfolio) x as-of date, with the position's effective model "
               "target set, its building blocks and the lineup's CMA set and allocation policy as companion facts; daily "
               "snapshots, every lineup, CMA set and target set version kept"),
        dimensions=["Model lineup and version (DP-530)", "Model lineup purpose", "Model portfolio (DP-004)",
                    "Service offering (DP-004)", "Capital market assumption set and version (DP-530)",
                    "Asset allocation policy and glide path (DP-127)", "Committee decision and decision type (DP-126)",
                    "Asset class", "Building block role and slot", "Instrument (DP-097)",
                    "List scope and product list status (DP-306)", "Risk band", "Horizon band",
                    "Generating model (DP-212)", "As-of date (DP-013)"],
        measures=[
            ("Lineups Under Current Approval",
             "Count of Model Lineup ID x Model Lineup Version with Model Lineup Status = Active and Lineup Effective From <= as-of date whose Lineup Approving Committee Decision resolves to an Investment Committee Decision (Decision Committee, Decision Meeting Date, Decision Item Number) with Committee Decision Type = Model Lineup Approval, Committee Decision Outcome in (Approved, Approved with Conditions) and Decision Effective Date no more than 400 days before the as-of date (the same staleness threshold DP-530 applies to CMA sets; one lever), by Model Lineup Purpose and Lineup Service Offering.",
             _u("24", "Model Lineup", "Model Lineup ID", "Model Lineup Version", "Model Lineup Status", "Lineup Effective From",
                "Lineup Approving Committee Decision", "Model Lineup Purpose", "Lineup Service Offering")
             + _u("24", "Investment Committee Decision", "Decision Committee", "Decision Meeting Date", "Decision Item Number",
                  "Committee Decision Type", "Committee Decision Outcome", "Decision Effective Date")),
            ("Lineups Past Annual Review",
             "Active lineups (Model Lineup Status = Active, Lineup Effective From <= as-of date) not counted in Lineups Under Current Approval: no approving decision, a decision of another Committee Decision Type, an outcome other than approved, or a Decision Effective Date more than 400 days old.",
             _u("24", "Model Lineup", "Model Lineup Status", "Lineup Effective From") + ["Lineups Under Current Approval"]),
            ("CMA Sets Stale or Unapproved (from DP-530)",
             "DP-530's controls as published: Active CMA sets counted in DP-530 CMA Sets Without Committee Approval (CMA Approving Committee Decision blank, or not of Committee Decision Type = CMA Approval with Committee Decision Outcome in (Approved, Approved with Conditions)) or with DP-530 CMA Set Age Days above 400 (as-of date minus CMA As-Of Date), by CMA Purposes; read, with no second staleness rule.",
             _u("24", "Capital Market Assumption Set", "Capital Market Assumption Set ID", "CMA Set Version", "CMA Set Status",
                "CMA Approving Committee Decision", "CMA Purposes", "CMA As-Of Date")
             + _u("24", "Investment Committee Decision", "Committee Decision Type", "Committee Decision Outcome")),
            ("Lineups on Superseded CMA Set",
             "Active lineups whose Lineup CMA Set resolves to a CMA Set Version lower than the highest CMA Set Version with CMA Set Status = Active and CMA Effective From <= as-of date of the same Capital Market Assumption Set ID; lineups on an inactive set or without approval are DP-530's Lineups on Inactive CMA Set and are not recounted here.",
             _u("24", "Model Lineup", "Lineup CMA Set", "Model Lineup Status")
             + _u("24", "Capital Market Assumption Set", "Capital Market Assumption Set ID", "CMA Set Version", "CMA Set Status",
                  "CMA Effective From")),
            ("Allocation Policies on Superseded CMA Set",
             "Asset Allocation Policy versions with Policy Status = Active named as Lineup Allocation Policy of an active lineup whose Policy CMA Set differs from the lineup's Lineup CMA Set or is not the highest active CMA Set Version of its set.",
             _u("24", "Asset Allocation Policy", "Policy Model Portfolio", "Policy Version Number", "Policy CMA Set", "Policy Status")
             + _u("24", "Model Lineup", "Lineup Allocation Policy", "Lineup CMA Set")
             + _u("24", "Capital Market Assumption Set", "CMA Set Version", "CMA Set Status")),
            ("Model Equity Weight",
             "Per model portfolio, the effective model target set (Target Subject Type = Model Portfolio, Target Set Status = Effective, highest Target Set Version with Target Effective Timestamp <= as-of): sum of Target Weight of its Target Allocation Lines (Line Target Set) with Target Component Type = Asset Class and Target Asset Class = Equity, plus lines with Target Component Type = Instrument whose Target Instrument has 17 Asset Class = Equity, in percent.",
             _u("24", "Target Allocation Set", "Target Set ID", "Target Subject Type", "Target Model Portfolio", "Target Set Version",
                "Target Set Status", "Target Effective Timestamp")
             + _u("24", "Target Allocation Line", "Line Target Set", "Target Component Type", "Target Asset Class", "Target Instrument",
                  "Target Weight")
             + _u("17", "Instrument", "Instrument ID", "Asset Class")),
            ("Lineup Equity Drift",
             "Per active lineup position: Model Equity Weight of the Position Model Portfolio - Nominal Equity Share of the Model Lineup Position, in percentage points (positive = the model holds more equity than the position's design).",
             _u("24", "Model Lineup Position", "Position Model Lineup", "Position Model Portfolio", "Nominal Equity Share")
             + ["Model Equity Weight"]),
            ("Positions Outside Equity Drift Tolerance",
             "Count of active lineup positions whose absolute Lineup Equity Drift exceeds 2 percentage points, by Position Model Lineup, Position Risk Band and Position Horizon Band.",
             _u("24", "Model Lineup Position", "Position Risk Band", "Position Horizon Band") + ["Lineup Equity Drift"]),
            ("Glide Path Drift",
             "Per active lineup position with Years to Retirement Position populated: Model Equity Weight - Glide Path Weight of the Glide Path Point whose Glide Path Policy is the lineup's Lineup Allocation Policy, Years to Target Date = Years to Retirement Position and Glide Path Asset Class = Equity, in percentage points; flagged where Model Equity Weight is outside Glide Path Minimum Weight to Glide Path Maximum Weight.",
             _u("24", "Model Lineup Position", "Position Model Lineup", "Position Model Portfolio", "Years to Retirement Position")
             + _u("24", "Glide Path Point", "Glide Path Policy", "Years to Target Date", "Glide Path Asset Class", "Glide Path Weight",
                  "Glide Path Minimum Weight", "Glide Path Maximum Weight")
             + _u("24", "Model Lineup", "Lineup Allocation Policy")
             + ["Model Equity Weight"]),
            ("Policy Band Breaches",
             "Count of model portfolio x asset class pairs of active lineup positions whose summed Target Weight of the effective model target set for the asset class (Target Asset Class, or the 17 Asset Class of Instrument lines) lies below Minimum Weight or above Maximum Weight of the Asset Allocation Policy Line (Line Allocation Policy = the lineup's Lineup Allocation Policy, Policy Asset Class = the asset class), with the Neutral Weight shown beside it.",
             _u("24", "Asset Allocation Policy Line", "Line Allocation Policy", "Policy Asset Class", "Neutral Weight", "Minimum Weight",
                "Maximum Weight")
             + _u("24", "Target Allocation Line", "Line Target Set", "Target Component Type", "Target Asset Class", "Target Instrument",
                  "Target Weight")
             + _u("24", "Target Allocation Set", "Target Set ID", "Target Model Portfolio", "Target Set Status", "Target Set Version",
                  "Target Effective Timestamp")
             + _u("24", "Model Lineup Position", "Position Model Lineup", "Position Model Portfolio")
             + _u("24", "Model Lineup", "Lineup Allocation Policy")
             + _u("17", "Instrument", "Asset Class")),
            ("Building Blocks Not Approved for Advice Models",
             "Count of Model Building Block rows effective on the as-of date (Building Block Effective From <= as-of < Building Block Effective To or open) whose Building Block Instrument has no Product List Status row (from DP-306) with Listed Instrument = the instrument, List Scope = Advice Models, Product List Status = Approved and List Status Effective From <= as-of < List Status Effective To (or open), by Building Block Role and Product List Status.",
             _u("24", "Model Building Block", "Building Block Model Portfolio", "Building Block Instrument", "Building Block Role",
                "Building Block Effective From", "Building Block Effective To")
             + _u("52", "Product List Status", "Listed Instrument", "List Scope", "Product List Status", "List Status Effective From",
                  "List Status Effective To")),
            ("Building Block List Status Mismatches",
             "Tie-out of the Derived copy (CW-250): count of effective Model Building Block rows whose Building Block Product List Status differs from the Product List Status of the DP-306 row for the same Listed Instrument and List Scope = Advice Models effective on the as-of date; zero expected one business day after a list change.",
             _u("24", "Model Building Block", "Building Block Product List Status", "Building Block Instrument")
             + _u("52", "Product List Status", "Listed Instrument", "List Scope", "Product List Status")),
            ("Lineup Positions on Non-Approved Blocks",
             "Count of active lineup positions whose Position Model Portfolio is the Building Block Model Portfolio of a block counted in Building Blocks Not Approved for Advice Models with Building Block Role = Primary, by Building Block Slot.",
             _u("24", "Model Lineup Position", "Position Model Portfolio")
             + _u("24", "Model Building Block", "Building Block Model Portfolio", "Building Block Role", "Building Block Slot")
             + ["Building Blocks Not Approved for Advice Models"]),
            ("CMA Sets With Inactive Generating Model",
             "Active CMA sets whose CMA Generating Model resolves to a 37 Model Inventory Entry (Model ID, Model Version) with Model Use Status other than Active (from DP-212), or is blank.",
             _u("24", "Capital Market Assumption Set", "CMA Generating Model", "CMA Set Status")
             + _u("37", "Model Inventory Entry", "Model ID", "Model Version", "Model Use Status")),
            ("Committee Approvals Without Subject Record",
             "Count of Investment Committee Decisions in the period with Committee Decision Type in (CMA Approval, Model Lineup Approval) and Committee Decision Outcome in (Approved, Approved with Conditions) that no CMA Approving Committee Decision or Lineup Approving Committee Decision references (CW-128 decision-to-subject check).",
             _u("24", "Investment Committee Decision", "Committee Decision Type", "Committee Decision Outcome", "Decision Meeting Date")
             + _u("24", "Capital Market Assumption Set", "CMA Approving Committee Decision")
             + _u("24", "Model Lineup", "Lineup Approving Committee Decision")),
            ("Models Outside Any Active Lineup",
             "Count of Target Model Portfolio values with an effective model target set that are not the Position Model Portfolio of any active lineup, by 01 Model Portfolio; informational (IC sponsor models and workplace models may stand outside an advice lineup).",
             _u("24", "Target Allocation Set", "Target Model Portfolio", "Target Set Status")
             + _u("24", "Model Lineup Position", "Position Model Portfolio")
             + _u("01", "Model Portfolio", "Model Portfolio ID", "Model Portfolio Name")),
        ],
        inputs=[
            ("24", "Capital Market Assumption Set", ["Capital Market Assumption Set ID", "CMA Set Version", "CMA As-Of Date",
                                                     "CMA Purposes", "CMA Generating Model", "CMA Approving Committee Decision",
                                                     "CMA Set Status", "CMA Effective From"]),
            ("24", "Model Lineup", ["Model Lineup ID", "Model Lineup Version", "Model Lineup Name", "Model Lineup Purpose",
                                    "Lineup Service Offering", "Lineup Allocation Policy", "Lineup CMA Set",
                                    "Lineup Approving Committee Decision", "Model Lineup Status", "Lineup Effective From"]),
            ("24", "Model Lineup Position", ["Position Model Lineup", "Position Model Portfolio", "Position Risk Band",
                                             "Position Horizon Band", "Years to Retirement Position", "Nominal Equity Share"]),
            ("24", "Model Building Block", ["Building Block Model Portfolio", "Building Block Role", "Building Block Slot",
                                            "Building Block Share Class", "Building Block Instrument",
                                            "Building Block Product List Status", "Building Block Effective From",
                                            "Building Block Effective To"]),
            ("24", "Target Allocation Set", ["Target Set ID", "Target Subject Type", "Target Model Portfolio", "Target Set Version",
                                             "Target Set Status", "Target Effective Timestamp", "Governing Allocation Policy"]),
            ("24", "Target Allocation Line", ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class",
                                              "Target Weight"]),
            ("24", "Asset Allocation Policy", ["Policy Model Portfolio", "Policy Version Number", "Allocation Policy Type",
                                               "Policy Purpose", "Policy CMA Set", "Approving Committee Decision", "Policy Status",
                                               "Policy Effective From", "Policy Effective To"]),
            ("24", "Asset Allocation Policy Line", ["Line Allocation Policy", "Policy Asset Class", "Neutral Weight",
                                                    "Minimum Weight", "Maximum Weight"]),
            ("24", "Glide Path Point", ["Glide Path Policy", "Years to Target Date", "Glide Path Asset Class", "Glide Path Weight",
                                        "Glide Path Minimum Weight", "Glide Path Maximum Weight"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number",
                                                     "Committee Decision Type", "Committee Decision Outcome",
                                                     "Decision Effective Date"]),
            ("52", "Product List Status", ["Listed Instrument", "List Scope", "Product List Status", "List Status Effective From",
                                           "List Status Effective To"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Use Status"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name"]),
            ("17", "Instrument", ["Instrument ID", "Asset Class"]),
        ],
        upstream=["DP-530", "DP-126", "DP-127", "DP-306", "DP-212", "DP-004", "DP-097", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day on the prior day's committee decisions, list status and model target sets",
        history=("Daily snapshots kept 7 years; every CMA set, lineup, allocation policy and model target set version kept "
                 "indefinitely as the investment committee record (Advisers Act Rule 204-2 books and records)"),
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Position Model Portfolio, Target Model Portfolio and Building Block Model Portfolio resolves to a DP-004 model portfolio, every Building Block Instrument and Target Instrument to an active DP-097 instrument, every Lineup CMA Set to a DP-530 CMA set version, and every Lineup Approving Committee Decision and CMA Approving Committee Decision to a DP-126 Investment Committee Decision.",
            "Model Building Block rows of one Building Block Model Portfolio x Building Block Slot x Building Block Role do not overlap in effect, DP-306 Product List Status rows of one Listed Instrument x List Scope do not overlap, and every Effective To is on or after its Effective From.",
            "Each effective model target set's Target Weight sums to 100 within 0.01 percentage points as DP-530 publishes it (Target Weight Sum Variance), and Building Block List Status Mismatches is zero one business day after any DP-306 list change.",
            "Nominal Equity Share is populated on every position of an active lineup, Years to Retirement Position on every position of a lineup whose Model Lineup Purpose is Workplace Managed Account and whose Lineup Allocation Policy is a glide path policy, and Glide Path Weight on every Glide Path Point of a policy named as a Lineup Allocation Policy.",
            "No employee, client or committee member reference is published: committee decisions are shown by Decision Committee, Decision Meeting Date and Decision Item Number only.",
            "The daily snapshot is complete by 7am ET; a lineup, CMA set or target set version that takes effect on a date appears in that date's snapshot, and past snapshots are never changed.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family); expected returns in the CMA sets "
               "are assumptions, never returns (DP-145). "
               "PII tier: none. pii = N: Capital Market Assumption Set ID, Model Lineup ID and 52 Listed Instrument are flagged "
               "personal by the validator only because their notes read 'Object PII tier: No PII' (the flag matches the "
               "word); no client or employee attribute is read, so no "
               "row or column carries personal data. "
               "Boundaries: CMA sets, lineups, building blocks and model target sets are DP-530's and are read, never "
               "remastered; asset allocation policies and glide paths are DP-127's; Product List Status is DP-306's "
               "(CW-254) and the Building Block Product List Status on 24 is a Derived copy tied out here (CW-250); "
               "committee decisions are DP-126's; account drift, rebalancing and tax-loss harvesting are 46 (DP-304, "
               "DP-341, DP-342), not lineup drift (INV+IOP brief boundary 9). Projections shown to clients are 45 and "
               "reviewed by 08. The candidate's 37 Model Inventory Entry is read for the generating model check through "
               "DP-212. "
               "Acceptance question 4: context for DP-341 (reader named here; DP-341 does not list this product upstream, "
               "so the edge stays one-way): Lineup Equity Drift and Positions Outside Equity Drift Tolerance show when a "
               "model's own weights left the lineup design, which explains account drift that is not the account's. "
               "Tailoring lever: lineups per purpose (24 SME 2). Reference default: one lineup per Model Lineup "
               "Purpose (Digital Advice, Human and Hybrid Advice, Workplace Managed Account, Intermediary Model Delivery), so "
               "drift is compared across lineups. Tailoring lever: licensed CMA (24 SME 1). Reference default: built in house with a 37 "
               "generating model and approved annually; with a vendor set the generating model check drops. Tailoring "
               "lever: equity drift tolerance. Reference default: 2 percentage points. Tailoring lever: review cycle. "
               "Reference default: DP-530's 400-day CMA staleness threshold, applied here also to the lineup approval "
               "(one lever, set in DP-530). "
               "Taxonomy gap: 24 Model Lineup Position has no position sequence, so the order of positions along the risk "
               "scale cannot be tested (no monotonic equity check). Taxonomy gap: 24 Asset Allocation Policy has no single "
               "policy key attribute; Lineup Allocation Policy and Glide Path Policy resolve to the policy by its subject "
               "and Policy Version Number. Taxonomy gap: 24 Capital Market Assumption Set and Model Lineup have no review due "
               "date, so currency is measured from CMA As-Of Date (DP-530) and the lineup's approving decision. "
               "Drafting assumptions: Committee Decision Type values CMA Approval and Model Lineup Approval; Committee "
               "Decision Outcome values Approved and Approved with Conditions; Model Lineup Status, CMA Set Status and "
               "Policy Status Active; Target Set Status Effective; Model Lineup Purpose value Workplace Managed Account for glide "
               "paths; List Scope "
               "Advice Models and Product List Status Approved; Asset Class value Equity; the 2-point tolerance and the 400-day "
               "threshold (DP-530). "
               "Decisions: CW-046, CW-120, CW-128, CW-130, CW-250, CW-254, CD-176, CD-294. "
               "WP1 new (CW-250): first specification; inputs as in the INV+IOP candidate, adding 24 Investment Committee "
               "Decision for the approval tests, 01 Model Portfolio and 17 Instrument (asset class of instrument lines, "
               "read through DP-004 and DP-097); DP-097 added upstream. Fix pass (C-6 review, lead ruling 3): 'CMA Sets "
               "Past Annual Review' becomes CMA Sets Stale or Unapproved (from DP-530), read as DP-530 publishes it; "
               "the lineup approval uses the same 400-day threshold; 'Building Blocks on Inactive Share Classes' is "
               "dropped (DP-530 Building Blocks on Inactive Vehicles) with its 01 Share Class read; Lineups on "
               "Superseded CMA Set no longer recounts DP-530's inactive-set lineups. Hand-off: DP-530 publishes the "
               "master controls, DP-531 decides with them and adds the lineup, glide path, band and list-status tests."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-535": dict(
        definition=("Every manager search from need to recommendation, with its candidate strategies, stages and eliminations "
                    "and the committee decision behind the outcome, and every investment and operational due diligence "
                    "review of an external manager with its questionnaire, factor scores, onsite visits and key-person "
                    "background checks; with backlog DP-539 folded in, it also carries the third-party product due "
                    "diligence evidence (criterion results and Rule 12d1-4 fund-of-funds detail) behind the list status "
                    "DP-306 publishes. It evidences the care behind each hire and each product approval for fund boards, "
                    "OCIO clients and trust fiduciaries. It owns no certified metric family."),
        business_questions=[
            "Which manager searches are open, at which stage, and how long has each run?",
            "Was every selected strategy approved by the investment committee and backed by completed investment and operational due diligence before the recommendation date?",
            "Which covered managers are overdue for their next due diligence review, onsite visit or key-person background check?",
            "How did each review score by factor, and which questionnaires came back late or on a template no longer in force?",
            "Which third-party products were approved despite a failed criterion or without a committee decision, and which fund-of-funds uses above the Section 12(d)(1) limits lack a Rule 12d1-4 investment agreement?",
        ],
        grain=("Manager search x candidate strategy, and manager due diligence review x scoring factor, as the two main "
               "facts; companion facts onsite visit, background check result (restricted view), product due diligence x "
               "criterion and fund-of-funds use; event grain, every review kept"),
        dimensions=["External manager and strategy (DP-306)", "Search need", "Search stage and elimination reason",
                    "Target fund or mandate (DP-004)", "Due diligence review type", "Questionnaire template and version",
                    "Scoring factor", "Key person role (DP-306)", "Background check type", "Instrument (DP-097)",
                    "Product use scope", "Acquiring fund (DP-004)", "Committee decision (DP-126)", "Reviewer (DP-192)",
                    "Period (DP-013)"],
        measures=[
            ("Open Manager Searches",
             "Count of Manager Search ID with Search Status not in (Resolved / Completed, Closed, Canceled), by Search Need, with Search Age Days = as-of date - Search Opened Date and the Target Product or Target Mandate searched for.",
             _u("52", "Manager Search", "Manager Search ID", "Search Status", "Search Need", "Search Opened Date", "Target Product",
                "Target Mandate")),
            ("Search Cycle Days",
             "For searches with Search Closed Date in the period and a Selected Strategy on their Search Outcome: Search Closed Date - Search Opened Date in calendar days, median and maximum by Search Need.",
             _u("52", "Manager Search", "Search Opened Date", "Search Closed Date", "Search Need")
             + _u("52", "Search Outcome", "Selected Strategy")),
            ("Candidates by Search Stage",
             "Count of Search Candidate rows (Candidate Search x Candidate Strategy) by Search Stage, and of eliminated candidates by Elimination Reason, per open search.",
             _u("52", "Search Candidate", "Candidate Search", "Candidate Strategy", "Search Stage", "Elimination Reason")),
            ("Recommendations Without Committee Approval",
             "Count of Search Outcomes with Recommendation Date in the period whose Approving Committee Decision is blank or resolves to an Investment Committee Decision (from DP-126) with Committee Decision Type other than Manager Hire or Committee Decision Outcome not in (Approved, Approved with Conditions).",
             _u("52", "Search Outcome", "Recommendation Date", "Approving Committee Decision")
             + _u("24", "Investment Committee Decision", "Decision Committee", "Decision Meeting Date", "Decision Item Number",
                  "Committee Decision Type", "Committee Decision Outcome")),
            ("Selected Strategies Without Completed Due Diligence",
             "Count of Search Outcomes whose Selected Strategy has, for either Questionnaire Type Investment or Operational (of the review's Questionnaire Template Used), no Manager Due Diligence Review with Reviewed Strategy = the strategy (or, for Operational, Reviewed Manager = its Strategy Manager), Due Diligence Outcome in (Approve, Approve with Conditions) and Review Completed Date on or before the Recommendation Date; the candidate's Candidate Due Diligence Reviews are shown beside it.",
             _u("52", "Search Outcome", "Selected Strategy", "Recommendation Date")
             + _u("52", "External Manager Strategy", "External Manager Strategy ID", "Strategy Manager")
             + _u("52", "Manager Due Diligence Review", "Reviewed Strategy", "Reviewed Manager", "Questionnaire Template Used",
                  "Due Diligence Outcome", "Review Completed Date")
             + _u("52", "Due Diligence Questionnaire Template", "Questionnaire Type")
             + _u("52", "Search Candidate", "Candidate Due Diligence Reviews")),
            ("Approved Hires Without Engagement",
             "Search Outcomes approved (Recommendations Without Committee Approval excluded) whose Resulting Engagement is blank more than 90 days after Recommendation Date or does not resolve to a DP-306 Sub-Adviser Engagement; Interim Contract Indicator shown.",
             _u("52", "Search Outcome", "Resulting Engagement", "Recommendation Date", "Interim Contract Indicator")
             + _u("52", "Sub-Adviser Engagement", "Sub-Adviser Engagement ID", "Engagement Status")
             + ["Recommendations Without Committee Approval"]),
            ("Due Diligence Reviews Overdue",
             "Count of covered managers (External Manager Profile with Research Coverage Status in (Approved, Watch) effective on the as-of date) whose latest Manager Due Diligence Review of each Questionnaire Type (Investment, Operational) has Next Review Due Date before the as-of date and no later completed review, by Questionnaire Type, Due Diligence Review Type (Initial, Periodic, Event-Driven) and External Manager Types.",
             _u("52", "External Manager Profile", "Profiled Manager", "Research Coverage Status", "External Manager Types",
                "Profile Effective From", "Profile Effective To")
             + _u("52", "Manager Due Diligence Review", "Manager Due Diligence Review ID", "Reviewed Manager", "Due Diligence Review Type",
                  "Questionnaire Template Used", "Review Completed Date", "Next Review Due Date")
             + _u("52", "Due Diligence Questionnaire Template", "Questionnaire Type")),
            ("Questionnaire Turnaround Days",
             "Questionnaire Received Date - Questionnaire Sent Date per review, median by Questionnaire Type of the Questionnaire Template Used; reviews with Questionnaire Sent Date more than 45 days ago and no Questionnaire Received Date are counted as outstanding.",
             _u("52", "Manager Due Diligence Review", "Questionnaire Sent Date", "Questionnaire Received Date", "Questionnaire Template Used")
             + _u("52", "Due Diligence Questionnaire Template", "Questionnaire Template Code", "Questionnaire Template Version",
                  "Questionnaire Type")),
            ("Reviews on Superseded Templates",
             "Count of reviews whose Questionnaire Template Used resolves to a template version with Template Status other than Active on the Questionnaire Sent Date, or whose Template Effective To is before it.",
             _u("52", "Manager Due Diligence Review", "Questionnaire Template Used", "Questionnaire Sent Date")
             + _u("52", "Due Diligence Questionnaire Template", "Template Status", "Template Effective From", "Template Effective To")),
            ("Weighted Due Diligence Score",
             "Per Scored Review: sum of Factor Score x Factor Weight / sum of Factor Weight over its Due Diligence Score rows (1 to 5 scale), with the score by Scoring Factor; reviews whose Overall Due Diligence Rating is shown beside it for comparison.",
             _u("52", "Due Diligence Score", "Scored Review", "Scoring Factor", "Factor Score", "Factor Weight")
             + _u("52", "Manager Due Diligence Review", "Overall Due Diligence Rating")),
            ("Operational Reviews Without Onsite Visit",
             "Count of completed reviews whose Questionnaire Template Used has Questionnaire Type = Operational that have no Onsite Visit (Visited Review = the review) with Visit Date in the 24 months before Review Completed Date; reviews whose only visit has Virtual Visit Indicator = Y are counted separately.",
             _u("52", "Manager Due Diligence Review", "Questionnaire Template Used", "Review Completed Date")
             + _u("52", "Due Diligence Questionnaire Template", "Questionnaire Type")
             + _u("52", "Onsite Visit", "Visited Review", "Visit Date", "Virtual Visit Indicator")),
            ("Key Persons Without Current Background Check",
             "Count of Manager Key Person rows with Key Person Indicator = Y and Departure Date blank, of covered managers (Due Diligence Reviews Overdue population), with no Background Check Result for the key person (Checked Key Person) with Check Date in the last 36 months and Subject Authorization Obtained Indicator = Y, by Key Person Role.",
             _u("52", "Manager Key Person", "Key Person Manager", "Key Person", "Key Person Role", "Key Person Indicator", "Departure Date")
             + _u("52", "Background Check Result", "Checked Key Person", "Check Date", "Subject Authorization Obtained Indicator")
             + _u("52", "External Manager Profile", "Research Coverage Status")),
            ("Adverse Background Check Outcomes",
             "Restricted view (DQ5): count of Background Check Result rows with Check Date in the period whose Background Check Outcome is other than Clear or whose Regulatory Disclosure Found Indicator = Y, by Background Check Type and Key Person Manager, published only inside the manager research restricted view; any count outside it is by Background Check Type only and suppressed below 10 rows, so no individual at a small manager can be inferred.",
             _u("52", "Background Check Result", "Background Check Type", "Check Date", "Background Check Outcome",
                "Regulatory Disclosure Found Indicator", "Checked Key Person")
             + _u("52", "Manager Key Person", "Key Person Manager")),
            ("Products Approved Despite Failed Criteria",
             "Count of Product Due Diligence rows with Product Due Diligence Outcome in (Approve, Approve with Conditions) and Product Review Effective Date in the period that have at least one Product Due Diligence Criterion Result (Criterion Product Review) with Criterion Result = Fail, by Product Use Scopes and Product Due Diligence Criterion, with Criterion Value and Criterion Threshold shown.",
             _u("52", "Product Due Diligence", "Product Due Diligence ID", "Product Due Diligence Outcome", "Product Review Effective Date",
                "Product Use Scopes")
             + _u("52", "Product Due Diligence Criterion Result", "Criterion Product Review", "Product Due Diligence Criterion",
                  "Criterion Result", "Criterion Value", "Criterion Threshold")),
            ("Full Product Reviews Without Committee Decision",
             "Count of Product Due Diligence rows with Full Due Diligence Indicator = Y and an approving Product Due Diligence Outcome whose Product Approving Decision is blank or resolves to an Investment Committee Decision with Committee Decision Type other than Third-Party Product Approval, by Complex Product Indicator and Reviewed Instrument type.",
             _u("52", "Product Due Diligence", "Full Due Diligence Indicator", "Product Due Diligence Outcome", "Product Approving Decision",
                "Complex Product Indicator", "Reviewed Instrument")
             + _u("24", "Investment Committee Decision", "Committee Decision Type")),
            ("Fund of Funds Uses Without Investment Agreement",
             "Count of Fund of Funds Use Detail rows with Exceeds Section 12(d)(1) Limits Indicator = Y whose Fund of Funds Investment Agreement is blank (SEC Rule 12d1-4 requires a fund of funds investment agreement unless the acquiring and acquired funds are in the same group of investment companies), by Acquiring Fund.",
             _u("52", "Fund of Funds Use Detail", "Fund of Funds Product Review", "Acquiring Fund",
                "Exceeds Section 12(d)(1) Limits Indicator", "Fund of Funds Investment Agreement")),
            ("Fund of Funds Evaluations Incomplete",
             "Count of Fund of Funds Use Detail rows whose Evaluation Findings Date or Duplicative Fees Assessment is blank, or whose Evaluation Findings Date is more than 12 months before the as-of date, by Acquiring Fund.",
             _u("52", "Fund of Funds Use Detail", "Acquiring Fund", "Evaluation Findings Date", "Duplicative Fees Assessment")),
        ],
        inputs=[
            ("52", "Manager Search", ["Manager Search ID", "Search Need", "Target Product", "Target Mandate", "Search Owner",
                                      "Search Status", "Search Opened Date", "Search Closed Date"]),
            ("52", "Search Outcome", ["Selected Strategy", "Recommendation Date", "Approving Committee Decision",
                                      "Interim Contract Indicator", "Resulting Engagement"]),
            ("52", "Search Candidate", ["Candidate Search", "Candidate Strategy", "Search Stage", "Elimination Reason",
                                        "Candidate Due Diligence Reviews"]),
            ("52", "Due Diligence Questionnaire Template", ["Questionnaire Template Code", "Questionnaire Template Version",
                                                            "Questionnaire Type", "Template Status", "Template Effective From",
                                                            "Template Effective To"]),
            ("52", "Manager Due Diligence Review", ["Manager Due Diligence Review ID", "Reviewed Manager", "Reviewed Strategy",
                                                    "Due Diligence Review Type", "Questionnaire Template Used",
                                                    "Questionnaire Sent Date", "Questionnaire Received Date", "Lead Reviewer",
                                                    "Overall Due Diligence Rating", "Due Diligence Outcome",
                                                    "Review Completed Date", "Next Review Due Date"]),
            ("52", "Due Diligence Score", ["Scored Review", "Scoring Factor", "Factor Score", "Factor Weight"]),
            ("52", "Onsite Visit", ["Visited Review", "Visit Date", "Virtual Visit Indicator", "Areas Inspected"]),
            ("52", "Background Check Result", ["Checked Key Person", "Background Check Type", "Check Date",
                                               "Subject Authorization Obtained Indicator",
                                               "Regulatory Disclosure Found Indicator", "Background Check Outcome"]),
            ("52", "External Manager Profile", ["Profiled Manager", "External Manager Types", "Research Coverage Status",
                                                "Profile Effective From", "Profile Effective To"]),
            ("52", "Manager Key Person", ["Key Person Manager", "Key Person", "Key Person Role", "Key Person Indicator",
                                          "Departure Date"]),
            ("52", "External Manager Strategy", ["External Manager Strategy ID", "Strategy Manager", "Manager Strategy Name",
                                                 "Strategy Asset Class"]),
            ("52", "Sub-Adviser Engagement", ["Sub-Adviser Engagement ID", "Engagement Status"]),
            ("52", "Product Due Diligence", ["Product Due Diligence ID", "Reviewed Instrument", "Product Use Scopes",
                                             "Full Due Diligence Indicator", "Complex Product Indicator",
                                             "Product Due Diligence Outcome", "Product Approving Decision",
                                             "Product Review Effective Date"]),
            ("52", "Product Due Diligence Criterion Result", ["Criterion Product Review", "Product Due Diligence Criterion",
                                                              "Criterion Value", "Criterion Threshold", "Criterion Result"]),
            ("52", "Fund of Funds Use Detail", ["Fund of Funds Product Review", "Acquiring Fund",
                                                "Exceeds Section 12(d)(1) Limits Indicator", "Fund of Funds Investment Agreement",
                                                "Evaluation Findings Date", "Duplicative Fees Assessment"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number",
                                                     "Committee Decision Type", "Committee Decision Outcome"]),
        ],
        upstream=["DP-306", "DP-126", "DP-240", "DP-192", "DP-097", "DP-004", "DP-213", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day on the prior day's search, review and product due diligence records",
        history=("Event grain kept indefinitely while the manager or product is covered and 6 years after coverage ends (Advisers "
                 "Act Rule 204-2; fund board 15(c) evidence and ERISA fiduciary files); review versions are never overwritten"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Reviewed Manager, Key Person Manager and Strategy Manager resolves to an External Manager Profile in DP-306 (and its 02 party in DP-240), every Selected Strategy and Candidate Strategy to a DP-306 External Manager Strategy, every Approving Committee Decision and Product Approving Decision to a DP-126 Investment Committee Decision, every Reviewed Instrument to DP-097, and every Target Product and Acquiring Fund to DP-004.",
            "Search Closed Date is on or after Search Opened Date, Questionnaire Received Date on or after Questionnaire Sent Date, Review Completed Date on or after Questionnaire Sent Date, Template Effective To on or after Template Effective From, and no two template versions of one Questionnaire Template Code are in force on the same date.",
            "Factor Weight, held as a decimal fraction, sums to 1.000 within 0.001 over the Due Diligence Score rows of each completed review, and every approved Product Due Diligence used as Deciding Product Review by a DP-306 Product List Status row exists here with the same Reviewed Instrument.",
            "Due Diligence Outcome, Overall Due Diligence Rating and Review Completed Date are populated on every completed review, Search Stage on every Search Candidate, and Criterion Result on every Product Due Diligence Criterion Result of a completed product review.",
            "Background Check Result rows are published only to the manager research restricted view as Background Check Type, Check Date, Subject Authorization Obtained Indicator and Background Check Outcome (no report content), never joined to the key person's name outside it; key persons and employee references (Search Owner, Lead Reviewer) are identity-tier personal data visible only to manager research, fund legal and compliance roles.",
            "The daily build is complete by 7am ET; a completed review or outcome is locked once its committee decision is recorded, and a change after that is a new review, never an edit.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family); Reported Firm AUM and Reported "
               "Strategy AUM of 52 are the managers' own figures (14 copies) and are not read. "
               "PII tier: identity. Key persons are individuals (02 parties), Search Owner and Lead Reviewer are employee "
               "references (DP-192); Background Check Result is a consumer report under the FCRA, published as outcome and "
               "authorization only in a restricted view (DQ5); no financial or special-category data. "
               "Boundaries: the manager, strategy, key person, engagement and Product List Status masters are DP-306's "
               "(read, never remastered; CW-116, CW-254); committee decisions are DP-126's (DP-126 RESPEC: it states that "
               "52 records the engagement and DP-535 and DP-538 read the decision); oversight of hired managers is DP-536's "
               "and the hire, termination and Section 15(c) lifecycle DP-538's; manager research is not 23 (CW-119). "
               "Backlog DP-539 Third-Party Product Due Diligence & Approved Lists folds in here (WP1_Scope.md section 5): "
               "this product takes its 52 Product Due Diligence, Product Due Diligence Criterion Result and Fund of Funds "
               "Use Detail reads (WP1 scope moved read from DP-539); the list status itself stays DP-306's, platform "
               "availability 01's (DP-383), and the DP-539 measures on 01 availability, 24 building blocks (DP-531) and 45 "
               "recommendations are not carried. "
               "Tailoring lever: manager research in house or outsourced (52 SME 2). Reference default: in house; with an "
               "outsourced research provider the reviews are received and the grain is unchanged. Tailoring lever: "
               "platform curation depth (52 SME 4). Reference default: a screen for self-directed platform listings and "
               "full due diligence for Advice Models, Plan Menus, Fund of Funds and recommended uses. Tailoring lever: "
               "review cycle and background check window. Reference default: annual investment and operational reviews, "
               "an onsite or virtual visit at least every 24 months, key-person background checks every 36 months. "
               "Taxonomy gap: 52 Search Outcome is an attribute group with no key of its own, so its join to Manager Search "
               "is implicit. Taxonomy gap: 52 Manager Due Diligence Review has no completion status attribute; a review is "
               "taken as completed when Review Completed Date is populated. "
               "Drafting assumptions: Search Status values Resolved / Completed, Closed and Canceled (shared Case Status); Committee Decision Type values Manager Hire "
               "and Third-Party Product Approval; Committee Decision Outcome values Approved and Approved with Conditions; "
               "Due Diligence Outcome values Approve and Approve with Conditions; Questionnaire Type values Investment and "
               "Operational; Research Coverage Status values Approved and Watch; Background Check Outcome value Clear; Criterion Result value Fail; Template Status Active; the 90-, 45-day, 24- and 36-month windows. "
               "Decisions: CW-116, CW-118, CW-119, CW-120, CW-121, CW-254, CD-060. "
               "WP1 new (CW-205, CW-254): first specification; inputs as in the INV+IOP candidate (24 Investment Committee "
               "Decision is read for the approval tests), adding 52 Sub-Adviser Engagement for the hire link and, from "
               "backlog DP-539, 52 Product Due Diligence and Product Due Diligence Criterion Result; 52 Fund of Funds Use "
               "Detail is the WP1 scope moved read from DP-539. DP-213 is upstream for the 39 fund-of-funds investment "
               "agreement key; DP-126 is not yet re-specified (its RESPEC adds the decision-type dimensions)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-536": dict(
        definition=("The sub-adviser oversight scorecard: per sub-adviser engagement and review period, the oversight review "
                    "and its conclusion, the watch status in force and why, each oversight metric reading (excess return, "
                    "ex-post and ex-ante tracking error, information ratio, peer percentile, fee versus peers, turnover, "
                    "breach count, style drift, active share) against the threshold approved for that engagement, key-person departures, and, "
                    "with backlog DP-537 folded in, the compliance certifications, guideline rule versions, oversight findings "
                    "and remediation actions. Every reading is a Derived copy pinned to the source record and version it "
                    "copies, and the scorecard ties each back to DP-145, DP-146, DP-157, DP-014, DP-165 and DP-163 rather than "
                    "publishing a return or risk number of its own (CW-252). It answers which sub-advisers are under review "
                    "and why. It owns no certified metric family."),
        business_questions=[
            "Which sub-advisers are under review or on watch today, since when, why, and by which oversight review was that decided?",
            "Which engagements breached or approached an approved oversight threshold this period, on which metric?",
            "Does every oversight reading tie to the official return, risk statistic, peer ranking, fund ratio or breach record it copies?",
            "Which engagements lack a current oversight review, approved thresholds or an on-time compliance certification?",
            "Which oversight findings and remediation actions are open past their due dates, and which certified exceptions name no investment breach?",
        ],
        grain=("Sub-adviser engagement x oversight review (review period) x oversight metric, with the watch status effective on "
               "the review end and as of today, the threshold in force and the source record of each reading; companion "
               "facts certification, guideline rule inclusion, finding and remediation action; every review and watch "
               "period kept"),
        dimensions=["Sub-adviser engagement (DP-306)", "External manager and strategy (DP-306)",
                    "Engaged fund or mandate (DP-004)", "Sleeve portfolio (DP-140)", "Engagement scope", "Watch status and reason",
                    "Oversight review type and period", "Oversight metric", "Metric source domain", "Threshold result",
                    "Certification type", "Finding category and severity", "Compliance rule and version (DP-161)",
                    "Reviewer (DP-192)", "Review period end (DP-013)"],
        measures=[
            ("Engagements Under Review",
             "Count of Sub-Adviser Engagements with Engagement Status = Active whose Sub-Adviser Watch Status row effective on the as-of date (Watch Effective From <= as-of < Watch Effective To or open) has Watch Status in (Watch, Under Review, Termination Recommended), by Watch Status, Watch Reason, Engagement Scope and Engaged Fund or Delegated Mandate, with Watch Effective From and Watch Review Deadline shown.",
             _u("52", "Sub-Adviser Engagement", "Sub-Adviser Engagement ID", "Engagement Status", "Engagement Scope", "Engaged Fund",
                "Delegated Mandate")
             + _u("52", "Sub-Adviser Watch Status", "Watched Engagement", "Watch Status", "Watch Reason", "Watch Effective From",
                  "Watch Effective To", "Watch Review Deadline")),
            ("Engagements Placed on Watch in Period",
             "Count of Sub-Adviser Watch Status rows with Watch Effective From in the period and Watch Status in (Watch, Under Review, Termination Recommended), by Watch Reason, with the Engagement Review Conclusion and Conclusion Commentary of the Deciding Oversight Review.",
             _u("52", "Sub-Adviser Watch Status", "Watch Status", "Watch Reason", "Watch Effective From", "Deciding Oversight Review")
             + _u("52", "Oversight Review", "Oversight Review ID", "Engagement Review Conclusion", "Conclusion Commentary")),
            ("Watch Status Without Deciding Review",
             "Watch Status rows in force whose Deciding Oversight Review is blank, or resolves to an Oversight Review whose Reviewed Engagement is another engagement or whose Engagement Review Conclusion differs from the Watch Status.",
             _u("52", "Sub-Adviser Watch Status", "Deciding Oversight Review", "Watched Engagement", "Watch Status")
             + _u("52", "Oversight Review", "Reviewed Engagement", "Engagement Review Conclusion")),
            ("Engagements Without Current Oversight Review",
             "Active engagements with no Oversight Review (Reviewed Engagement) whose Review Period End falls in the last completed calendar quarter and whose Review Completed Date is populated, by Engagement Scope.",
             _u("52", "Oversight Review", "Reviewed Engagement", "Review Period End", "Review Completed Date")
             + _u("52", "Sub-Adviser Engagement", "Engagement Status", "Engagement Scope")),
            ("Oversight Reviews Completed On Time %",
             "Oversight Reviews of the period with Review Completed Date no more than 45 days after Review Period End / all Oversight Reviews with Review Period End in the period, by Oversight Review Type.",
             _u("52", "Oversight Review", "Oversight Review Type", "Review Period Start", "Review Period End", "Review Completed Date")),
            ("Metric Threshold Breaches",
             "Count of Oversight Metric Readings with Metric Flag = Outside Threshold in reviews of the period, by Oversight Metric and engagement; each shown with Metric Value, Metric Unit and the Threshold Value and Threshold Limit Type of the Oversight Metric Threshold (Threshold Engagement = the review's Reviewed Engagement, Threshold Metric = Oversight Metric) effective on Review Period End; readings with Metric Flag = Exception Approved (outside threshold under a committee exception) are shown beside the breaches.",
             _u("52", "Oversight Metric Reading", "Reading Review", "Oversight Metric", "Metric Value", "Metric Unit", "Metric Flag")
             + _u("52", "Oversight Metric Threshold", "Threshold Engagement", "Threshold Metric", "Threshold Value", "Threshold Limit Type",
                  "Threshold Effective From", "Threshold Effective To")
             + _u("52", "Oversight Review", "Reviewed Engagement", "Review Period End")),
            ("Metric Threshold Warnings",
             "Count of readings with Metric Flag = Near Threshold (between Warning Value and Threshold Value) in reviews of the period, by Oversight Metric, with Warning Value and Threshold Value shown.",
             _u("52", "Oversight Metric Reading", "Metric Flag", "Oversight Metric")
             + _u("52", "Oversight Metric Threshold", "Warning Value", "Threshold Value")),
            ("Engagements Without Approved Thresholds",
             "Active engagements lacking an effective Oversight Metric Threshold for any of the standard metrics (Excess Return - 3 Years, Tracking Error, Peer Percentile - 3 Years, Breach Count, Style Drift), or whose threshold has Threshold Approving Decision blank or resolving to an Investment Committee Decision without Committee Decision Outcome in (Approved, Approved with Conditions).",
             _u("52", "Oversight Metric Threshold", "Threshold Engagement", "Threshold Metric", "Threshold Approving Decision",
                "Threshold Effective From", "Threshold Effective To")
             + _u("24", "Investment Committee Decision", "Decision Committee", "Decision Meeting Date", "Decision Item Number",
                  "Committee Decision Outcome")
             + _u("52", "Sub-Adviser Engagement", "Engagement Status")),
            ("Readings Without Pinned Source",
             "Count of Oversight Metric Readings whose source reference for their Metric Source Domain is blank: 32 readings without Source Performance Return (and Source Return Version), Source Benchmark Return or Source Ex-Post Risk Statistic, 31 without Source Risk Measure, 11 without Source Peer Metric Snapshot or Source Fee Benchmark Result, 27 without Source Financial Highlights, 33 without Source Investment Breaches or Breach Count Guideline Set; 52-computed metrics (style drift, active share) need Holdings As-Of Date.",
             _u("52", "Oversight Metric Reading", "Metric Source Domain", "Source Performance Return", "Source Return Version",
                "Source Benchmark Return", "Source Ex-Post Risk Statistic", "Source Risk Measure", "Source Peer Metric Snapshot",
                "Source Fee Benchmark Result", "Source Financial Highlights", "Source Investment Breaches",
                "Breach Count Guideline Set", "Holdings As-Of Date")),
            ("Return Reading Tie-Out (to DP-145)",
             "For readings with Metric Source Domain 32: Metric Value - Return Value of the Source Performance Return at Source Return Version (Return Status in (Final, Restated)) for a return metric, or Metric Value - (that Return Value - Benchmark Return Value of the Source Benchmark Return, Benchmark Return Status in (Final, Restated)) for the Excess Return - 1, 3 and 5 Years metrics; flagged beyond 0.0001, and where Source Return Version is not the highest Return Version (a restated return the scorecard has not picked up).",
             _u("52", "Oversight Metric Reading", "Metric Value", "Oversight Metric", "Source Performance Return", "Source Return Version",
                "Source Benchmark Return")
             + _u("32", "Performance Return", "Performance Return ID", "Return Version", "Return Value", "Return Status")
             + _u("32", "Benchmark Return", "Return Benchmark", "Benchmark Return Version", "Benchmark Return Value",
                  "Benchmark Return Status")),
            ("Risk Reading Tie-Out (to DP-146 and DP-157)",
             "Metric Value - Risk Measure Value of the Source Risk Measure (31 Portfolio Risk Measure of the engagement's sleeve or fund portfolio) for Ex-Ante Tracking Error, and Metric Value - Statistic Value of the Source Ex-Post Risk Statistic (Statistic Status in (Final, Restated)) for Tracking Error and Information Ratio; flagged beyond 0.0001.",
             _u("52", "Oversight Metric Reading", "Metric Value", "Source Risk Measure", "Source Ex-Post Risk Statistic")
             + _u("31", "Portfolio Risk Measure", "Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Measure Value")
             + _u("32", "Ex-Post Risk Statistic", "Ex-Post Statistic Type", "Statistic Version", "Statistic Value", "Statistic Status")),
            ("Peer and Fee Reading Tie-Out (to DP-014 and DP-506)",
             "Metric Value - Category Percentile Rank of the Source Peer Metric Snapshot for Peer Percentile - 3 Years readings, and Metric Value - Own Fee Percentile of the Source Fee Benchmark Result for Fee versus Peers readings; flagged when not zero.",
             _u("52", "Oversight Metric Reading", "Metric Value", "Source Peer Metric Snapshot", "Source Fee Benchmark Result")
             + _u("11", "Peer Metric Snapshot", "Snapshot Subject", "Snapshot Date", "Category Percentile Rank")
             + _u("11", "Fee Benchmark Result", "Own Fee Percentile")),
            ("Fund Ratio Reading Tie-Out (to DP-165)",
             "Metric Value - Portfolio Turnover Rate of the Source Financial Highlights for Turnover readings (the audited fund-level figure published by DP-165; 52 SME 8), flagged beyond 0.0001; the share class of Highlights Share Class must belong to the Engaged Fund.",
             _u("52", "Oversight Metric Reading", "Metric Value", "Source Financial Highlights")
             + _u("27", "Financial Highlights", "Highlights Share Class", "Portfolio Turnover Rate")
             + _u("52", "Sub-Adviser Engagement", "Engaged Fund")),
            ("Breach Count Tie-Out (to DP-163)",
             "Metric Value of Breach Count readings - count of the Investment Breaches listed in Source Investment Breaches whose Breached Portfolio is the engagement's Sleeve Portfolio and whose Breach Start Date falls in the review period; flagged when not zero, with the count of Material Breach Indicator = Y breaches.",
             _u("52", "Oversight Metric Reading", "Metric Value", "Source Investment Breaches", "Breach Count Guideline Set")
             + _u("33", "Investment Breach", "Investment Breach ID", "Breached Portfolio", "Breach Start Date", "Material Breach Indicator")
             + _u("52", "Sub-Adviser Engagement", "Sleeve Portfolio")
             + _u("52", "Oversight Review", "Review Period Start", "Review Period End")),
            ("Key Person Departures at Engaged Managers",
             "Count of Manager Key Person rows (from DP-306) with Key Person Indicator = Y and Departure Date in the period whose Key Person Manager is the Engaged Sub-Adviser of an active engagement, by Key Person Role, with the count notified more than 5 business days after departure (Departure Notified Date).",
             _u("52", "Manager Key Person", "Key Person Manager", "Key Person Role", "Key Person Indicator", "Departure Date",
                "Departure Notified Date")
             + _u("52", "Sub-Adviser Engagement", "Engaged Sub-Adviser")),
            ("Certifications Overdue",
             "Count of Sub-Adviser Compliance Certifications with Certification Due Date before the as-of date and Certification Received Date blank, or received after the due date in the period, by Certification Type and Certifying Manager or Certifying Engagement.",
             _u("52", "Sub-Adviser Compliance Certification", "Certifying Manager", "Certifying Engagement", "Certification Type",
                "Certification Period End", "Certification Due Date", "Certification Received Date")),
            ("Certified Exceptions Without Linked Breach",
             "Count of certifications with Exceptions Reported Indicator = Y whose Linked Investment Breaches is blank or names no DP-163 Investment Breach of the engagement's Sleeve Portfolio (the 'breach disclosed in a certification' flag DP-163 is to carry, RESPEC).",
             _u("52", "Sub-Adviser Compliance Certification", "Exceptions Reported Indicator", "Linked Investment Breaches")
             + _u("33", "Investment Breach", "Breached Portfolio")),
            ("Guideline Inclusions on Superseded Rule Versions",
             "Count of Guideline Rule Inclusion rows of each engagement's current Sub-Adviser Guideline Set (highest Guideline Version with Guideline Effective Date <= as-of) whose Included Rule Version is not the 33 Compliance Rule version in force (Version Effective From <= as-of < Version Effective To, Rule Status Active) of the Included Compliance Rule (from DP-161), by Inclusion Type.",
             _u("52", "Guideline Rule Inclusion", "Inclusion Guideline Set", "Included Compliance Rule", "Included Rule Version",
                "Inclusion Type")
             + _u("52", "Sub-Adviser Guideline Set", "Guideline Set ID", "Guideline Engagement", "Guideline Version",
                  "Guideline Effective Date")
             + _u("33", "Compliance Rule", "Compliance Rule ID", "Rule Version", "Version Effective From", "Version Effective To",
                  "Rule Status")),
            ("Open Oversight Findings Past Due",
             "Count of Oversight Findings with Finding Status not in (Resolved / Completed, Closed, Canceled) and Finding Due Date before the as-of date, by Finding Severity, Finding Category, Finding Source Type and Finding Manager; with the count closed in the period (Finding Closed Date).",
             _u("52", "Oversight Finding", "Oversight Finding ID", "Finding Status", "Finding Due Date", "Finding Severity",
                "Finding Category", "Finding Source Type", "Finding Manager", "Finding Closed Date")),
            ("Remediation Actions Overdue",
             "Count of Remediation Action rows with Committed Date before the as-of date and Completed Date blank, by the Finding Severity of the Remediated Finding.",
             _u("52", "Remediation Action", "Remediated Finding", "Action Sequence", "Committed Date", "Completed Date")
             + _u("52", "Oversight Finding", "Finding Severity")),
        ],
        inputs=[
            ("52", "Sub-Adviser Engagement", ["Sub-Adviser Engagement ID", "Engaged Sub-Adviser", "Engaged Strategy", "Engaged Fund",
                                              "Delegated Mandate", "Sleeve Portfolio", "Engagement Scope", "Engagement Status",
                                              "Engagement Start Date", "Engagement End Date"]),
            ("52", "Sub-Adviser Watch Status", ["Watched Engagement", "Watch Status", "Watch Reason", "Deciding Oversight Review",
                                                "Watch Review Deadline", "Watch Effective From", "Watch Effective To"]),
            ("52", "Oversight Review", ["Oversight Review ID", "Reviewed Engagement", "Oversight Review Type", "Review Period Start",
                                        "Review Period End", "Oversight Reviewer", "Engagement Review Conclusion",
                                        "Conclusion Commentary", "Review Completed Date"]),
            ("52", "Oversight Metric Reading", ["Reading Review", "Oversight Metric", "Metric Value", "Metric Unit",
                                                "Metric Source Domain", "Source Performance Return", "Source Return Version",
                                                "Source Benchmark Return", "Source Ex-Post Risk Statistic", "Source Risk Measure",
                                                "Source Peer Metric Snapshot", "Source Fee Benchmark Result",
                                                "Source Financial Highlights", "Breach Count Guideline Set",
                                                "Source Investment Breaches", "Holdings As-Of Date", "Metric Flag"]),
            ("52", "Oversight Metric Threshold", ["Threshold Engagement", "Threshold Metric", "Threshold Limit Type",
                                                  "Threshold Value", "Warning Value", "Threshold Approving Decision",
                                                  "Threshold Effective From", "Threshold Effective To"]),
            ("52", "Manager Key Person", ["Key Person Manager", "Key Person Role", "Key Person Indicator", "Departure Date",
                                          "Departure Notified Date"]),
            ("52", "Sub-Adviser Guideline Set", ["Guideline Set ID", "Guideline Engagement", "Guideline Version",
                                                 "Guideline Effective Date"]),
            ("52", "Guideline Rule Inclusion", ["Inclusion Guideline Set", "Included Compliance Rule", "Included Rule Version",
                                                "Included Investment Restriction", "Inclusion Type"]),
            ("52", "Sub-Adviser Compliance Certification", ["Certifying Manager", "Certifying Engagement", "Certification Type",
                                                            "Certification Period End", "Certification Due Date",
                                                            "Certification Received Date", "Exceptions Reported Indicator",
                                                            "Linked Investment Breaches"]),
            ("52", "Oversight Finding", ["Oversight Finding ID", "Finding Source Type", "Source Oversight Review",
                                         "Source Certification", "Finding Manager", "Finding Category", "Finding Severity",
                                         "Finding Due Date", "Finding Status", "Finding Closed Date"]),
            ("52", "Remediation Action", ["Remediated Finding", "Action Sequence", "Committed Date", "Completed Date"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Value", "Return Status"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Return Version", "Benchmark Return Value",
                                        "Benchmark Return Status"]),
            ("32", "Ex-Post Risk Statistic", ["Ex-Post Statistic Type", "Statistic Version", "Statistic Value", "Statistic Status"]),
            ("31", "Portfolio Risk Measure", ["Measure Calculation Run", "Measured Portfolio", "Risk Measure", "Risk Measure Value"]),
            ("11", "Peer Metric Snapshot", ["Snapshot Subject", "Snapshot Date", "Category Percentile Rank"]),
            ("11", "Fee Benchmark Result", ["Own Fee Percentile", "Peer Median Fee"]),
            ("27", "Financial Highlights", ["Highlights Share Class", "Portfolio Turnover Rate"]),
            ("33", "Investment Breach", ["Investment Breach ID", "Breached Portfolio", "Breach Start Date",
                                         "Material Breach Indicator", "Breach Status"]),
            ("33", "Compliance Rule", ["Compliance Rule ID", "Rule Version", "Version Effective From", "Version Effective To",
                                       "Rule Status"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number",
                                                     "Committee Decision Outcome"]),
        ],
        upstream=["DP-306", "DP-145", "DP-146", "DP-157", "DP-014", "DP-506", "DP-165", "DP-163", "DP-161", "DP-126",
                  "DP-140", "DP-192", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness=("By 7am ET each business day on the prior day's watch, review and certification records; quarterly "
                    "scorecard readings Final within 45 days of quarter-end, after DP-145 month-end returns are Final"),
        history=("Every oversight review, reading, threshold and watch period kept indefinitely while the engagement runs and "
                 "6 years after it ends (Rule 38a-1 and Advisers Act Rule 204-2 oversight records; Section 15(c) evidence); "
                 "readings keep the source version they copied"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Watched Engagement, Reviewed Engagement, Threshold Engagement, Guideline Engagement and Certifying Engagement resolves to a DP-306 Sub-Adviser Engagement, every Key Person Manager, Certifying Manager and Finding Manager to a DP-306 external manager, every Sleeve Portfolio to DP-140, every Included Compliance Rule to DP-161 and every Threshold Approving Decision to a DP-126 Investment Committee Decision.",
            "Sub-Adviser Watch Status rows of one engagement and Oversight Metric Threshold rows of one engagement x metric do not overlap in effect, every Effective To is on or after its Effective From, and Review Period End is on or after Review Period Start.",
            "Return Reading Tie-Out (to DP-145), Risk Reading Tie-Out (to DP-146 and DP-157), Peer and Fee Reading Tie-Out (to DP-014 and DP-506), Fund Ratio Reading Tie-Out (to DP-165) and Breach Count Tie-Out (to DP-163) are within their tolerances (0.0001, or zero for counts and ranks) before a quarterly review is marked complete; a reading is never published as an official return.",
            "Oversight Metric, Metric Value, Metric Source Domain and Metric Flag are populated on every reading of a completed review, Engagement Review Conclusion and Review Completed Date on every completed review, and Watch Status and Watch Effective From on every watch row.",
            "Oversight Reviewer and key persons are identity-tier personal data visible only to manager research, fund legal, investment compliance and the fund board's reporting roles; no client account or household data is read or published.",
            "The daily build is complete by 7am ET; a completed quarterly review and its readings are locked, and a correction is a new reading pinned to the corrected source version.",
        ],
        notes=("Certified numbers: reads Official Return and Benchmark Return (DP-145), ex-ante risk measures such as "
               "ex-ante tracking error certified by DP-146 (31 Portfolio Risk Measure), ex-post statistics (tracking error, "
               "information ratio) that are 32 Ex-Post Risk Statistic rows read through DP-157 (not a DP-146 family), and "
               "the audited fund turnover (DP-165) only through "
               "the pinned source references of 52 Oversight Metric Readings, and ties each reading back to its owner; it "
               "owns none (It owns no certified metric family). Only excess return, breach count, style drift and active "
               "share are computed in 52 (CW-252). "
               "PII tier: identity (Oversight Reviewer is an employee reference; key persons are individuals). "
               "Hand-off with DP-306: DP-306 counts the master (Engagements by Watch Status, Watch Reviews Past Deadline, "
               "Key Person Departures, Late Key Person Notifications); this product decides with them per engagement and "
               "review (Engagements Under Review adds the reason and deciding review; Key Person Departures at Engaged "
               "Managers restricts to engaged sub-advisers). Boundaries: engagements, watch status, key persons and "
               "guideline sets are DP-306's master data (read, never "
               "remastered); manager searches and due diligence are DP-535's; hires, terminations and Section 15(c) "
               "renewal submissions DP-538's; fund-level performance results stay DP-159's (DP-159 RESPEC adds the "
               "sub-advised indicator; fund results versus engagement oversight); investment breaches are DP-163's and "
               "coded rules DP-161's (guidelines defined in 01, coded in 33, delivered and certified in 52, CW-118). "
               "Backlog DP-537 Sub-Adviser Guidelines, Certifications & Findings folds in here: the WP1 scope moved reads "
               "52 Guideline Rule Inclusion, Sub-Adviser Compliance Certification, Oversight Finding and Remediation Action "
               "are read by this product. Backlog DP-540 (OCIO and trust delegated managers) also names this product as its "
               "merge target; OCIO and trust engagements appear here through Engagement Scope, and 12 OCIO Service Detail "
               "moved to DP-510. Peer fee benchmarks: DP-506 (WP1C DIS, in progress) is listed as the source of 11 Fee "
               "Benchmark Result because DP-014 publishes peer rankings only. "
               "Acceptance question 12 (plan section 8.5): answered with DP-538 by Engagements Under Review, Engagements "
               "Placed on Watch in Period and Return Reading Tie-Out (to DP-145); mastering domains 52 and 32 (the 35 "
               "renewal half is DP-538's Last Section 15(c) Renewal Evidence). Under the lead's ruling DP-536 reads 52 "
               "Sub-Adviser Watch Status itself, so Q12 needs no DP-512. "
               "Tailoring lever: thresholds per engagement or per strategy type (52 SME 7). Reference default: per "
               "engagement and metric, stored once with direction and warning band. Tailoring lever: sleeve-level turnover "
               "(52 SME 8). Reference default: fund-level turnover from 27 Financial Highlights; a sleeve turnover would be "
               "computed in 32 or 52 from 18 transactions. Tailoring lever: review cadence. Reference default: quarterly "
               "reviews completed within 45 days of quarter-end. Tailoring lever: OCIO and trust scopes (52 SME 6, TR "
               "line). Reference default: OCIO on, trust on only where the TR line is offered. "
               "Taxonomy gap: 52 Oversight Metric Reading has no source version for 31, 11 and 27 sources (only Source "
               "Return Version for 32), so those tie-outs compare against the current source row. Taxonomy gap: 52 "
               "Sub-Adviser Compliance Certification has no certification status, so overdue is computed from due and "
               "received dates. "
               "Drafting assumptions: Watch Status values Watch, Under Review and Termination Recommended; Metric Flag "
               "values Outside Threshold and Near Threshold; the standard metric list; Finding Status (shared Case Status) "
               "Resolved / Completed, Closed and Canceled; Rule Status Active; Return "
               "Status and Statistic Status Final and Restated; the 0.0001 tolerance, the 45-day and 5-business-day windows. "
               "Decisions: CW-116, CW-118, CW-119, CW-252, CW-253, CD-320. "
               "WP1 new (CW-252): first specification; inputs as in the INV+IOP candidate, adding 52 Sub-Adviser Guideline "
               "Set, 33 Compliance Rule and 24 Investment Committee Decision for the guideline and threshold-approval "
               "checks, and the four WP1 scope moved reads from backlog DP-537; DP-161, DP-126, DP-506 and DP-192 added "
               "upstream."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-538": dict(
        definition=("Each sub-adviser engagement's lifecycle evidence: the hire, with board approval and, under a "
                    "manager-of-managers order, the exemptive relief relied on and the information statement due and sent; "
                    "each annual Section 15(c) renewal submission with the sub-adviser questionnaire, the oversight reviews it "
                    "includes and the recommendation made to the board; and each termination with the deciding committee "
                    "decision, the replacement engagement and the 12 transition event. It gives the fund board, through 35 "
                    "and DP-183, the renewal data on every sub-adviser and evidences hire and termination conditions. It "
                    "owns no certified metric family."),
        business_questions=[
            "When was each sub-adviser's last Section 15(c) renewal submission delivered, what did it recommend, which oversight reviews did it include and what did the board resolve?",
            "Which fund engagements have no renewal submission for this year's renewal, or a submission delivered after the board materials?",
            "Which sub-advisers hired under the manager-of-managers order lack exemptive relief in force or had their information statement sent late?",
            "Which hires started before a board-approved agreement, and which recommendations to continue concern a sub-adviser under review?",
            "Which terminations lack a committee decision, a replacement or a completed transition, and which terminated engagements still carry an active agreement?",
        ],
        grain=("Sub-adviser engagement x lifecycle event (hire, Section 15(c) renewal submission per 35 renewal year, "
               "termination), with the governing 35 agreement, renewal and board resolution and the 12 transition event as "
               "companion facts; event grain, every renewal year kept"),
        dimensions=["Sub-adviser engagement (DP-306)", "External manager (DP-306)", "Engaged fund (DP-004)",
                    "Delegated mandate (DP-004)", "Engagement scope", "Advisory agreement and type (DP-213)",
                    "Renewal year", "Renewal recommendation", "Board resolution (DP-182)", "Exemptive relief type",
                    "Termination reason", "Committee decision (DP-126)", "Transition type", "Event date (DP-013)"],
        measures=[
            ("Sub-Adviser Hires in Period",
             "Count of Sub-Adviser Engagements with Engagement Start Date in the period, by Engagement Scope and Engaged Fund or Delegated Mandate, with the count hired under a manager-of-managers order (a Manager-of-Managers Hire Condition is recorded).",
             _u("52", "Sub-Adviser Engagement", "Sub-Adviser Engagement ID", "Engagement Start Date", "Engagement Scope", "Engaged Fund",
                "Delegated Mandate")
             + _u("52", "Manager-of-Managers Hire Condition", "Relied-On Exemptive Relief")),
            ("Hires Without Board-Approved Agreement",
             "Hires in the period with Engaged Fund populated whose Board Approval Date is blank or after Engagement Start Date, or whose Governing Fund Agreement resolves to a 35 Fund Advisory Agreement with Agreement Effective Date after Engagement Start Date or Advisory Agreement Status other than Active.",
             _u("52", "Sub-Adviser Engagement", "Board Approval Date", "Engagement Start Date", "Governing Fund Agreement", "Engaged Fund")
             + _u("35", "Fund Advisory Agreement", "Advisory Agreement ID", "Agreement Effective Date", "Advisory Agreement Status")
             + ["Sub-Adviser Hires in Period"]),
            ("Hires Without Exemptive Relief in Force",
             "Manager-of-Managers Hire Condition rows whose Relied-On Exemptive Relief resolves to no 35 Exemptive Relief Reliance with Relying Fund = the Engaged Fund, Exemptive Relief Type = Manager of Managers and Reliance Effective From <= Engagement Start Date < Reliance Effective To (or open), excluding rows with Shareholder Approval Required Indicator = Y.",
             _u("52", "Manager-of-Managers Hire Condition", "Relied-On Exemptive Relief", "Shareholder Approval Required Indicator")
             + _u("35", "Exemptive Relief Reliance", "Relying Fund", "Exemptive Relief Type", "Reliance Effective From",
                  "Reliance Effective To")
             + _u("52", "Sub-Adviser Engagement", "Engaged Fund", "Engagement Start Date")),
            ("Information Statements Sent Late",
             "Count of hire conditions with Information Statement Sent Date after Information Statement Due Date (90 days after the hire under the order), with the days late, plus those with Information Statement Due Date passed and Information Statement Sent Date blank; Notice and Access Indicator shown.",
             _u("52", "Manager-of-Managers Hire Condition", "Information Statement Due Date", "Information Statement Sent Date",
                "Notice and Access Indicator")),
            ("Information Statement Record Mismatches",
             "Hire conditions whose Information Statement Communication is blank once Information Statement Sent Date is populated, or resolves to a 13 Shareholder Communication whose Required Delivery Deadline differs from Information Statement Due Date or whose Communication Status is not Distributed (from DP-382); the 52 sent date is a Derived copy of 13.",
             _u("52", "Manager-of-Managers Hire Condition", "Information Statement Communication", "Information Statement Sent Date",
                "Information Statement Due Date")
             + _u("13", "Shareholder Communication", "Communication ID", "Communication Type", "Required Delivery Deadline",
                  "Communication Status")),
            ("Renewal Submissions by Recommendation",
             "Count of Section 15(c) Renewal Submissions whose Submission Renewal is an Advisory Contract Renewal of the Renewal Year, by Renewal Recommendation and Engaged Fund.",
             _u("52", "Section 15(c) Renewal Submission", "Submission Engagement", "Submission Renewal", "Renewal Recommendation")
             + _u("35", "Advisory Contract Renewal", "Renewal ID", "Renewal Year")),
            ("Fund Engagements Without Renewal Submission",
             "Active engagements (Engagement Status = Active) with Engaged Fund populated whose Governing Fund Agreement has an Advisory Contract Renewal (Renewed Agreement) for the current Renewal Year with 15(c) Request Date populated and no Section 15(c) Renewal Submission with Submission Engagement = the engagement and Submission Renewal = that renewal.",
             _u("52", "Sub-Adviser Engagement", "Engagement Status", "Engaged Fund", "Governing Fund Agreement")
             + _u("35", "Advisory Contract Renewal", "Renewed Agreement", "Renewal Year", "15(c) Request Date")
             + _u("52", "Section 15(c) Renewal Submission", "Submission Engagement", "Submission Renewal")),
            ("Sub-Adviser Response Days",
             "Sub-Adviser Response Received Date - Questionnaire Sent to Sub-Adviser Date per submission, median by Renewal Year; submissions with the questionnaire sent more than 30 days ago and no response are counted as outstanding.",
             _u("52", "Section 15(c) Renewal Submission", "Questionnaire Sent to Sub-Adviser Date", "Sub-Adviser Response Received Date")),
            ("Submissions Delivered After Board Materials",
             "Count of submissions whose Submission Delivered Date is after the Materials Delivered Date of their Submission Renewal, or blank when Materials Delivered Date is populated.",
             _u("52", "Section 15(c) Renewal Submission", "Submission Delivered Date", "Submission Renewal")
             + _u("35", "Advisory Contract Renewal", "Materials Delivered Date")),
            ("Submissions Without Current Oversight Review",
             "Count of submissions whose Included Oversight Reviews is blank or names no Oversight Review of the same engagement (Reviewed Engagement) with Review Completed Date populated and Review Period End in the 12 months before the renewal's 15(c) Request Date (reviews from DP-536).",
             _u("52", "Section 15(c) Renewal Submission", "Included Oversight Reviews", "Submission Engagement")
             + _u("52", "Oversight Review", "Oversight Review ID", "Reviewed Engagement", "Review Period End", "Review Completed Date")
             + _u("35", "Advisory Contract Renewal", "15(c) Request Date")),
            ("Continue Recommendations on Engagements Under Review",
             "Count of submissions with Renewal Recommendation in (Continue, Continue with Conditions) whose engagement had a Sub-Adviser Watch Status in (Under Review, Termination Recommended) effective on the Submission Delivered Date, with the Recommendation Rationale shown for board review.",
             _u("52", "Section 15(c) Renewal Submission", "Renewal Recommendation", "Recommendation Rationale", "Submission Delivered Date")
             + _u("52", "Sub-Adviser Watch Status", "Watched Engagement", "Watch Status", "Watch Effective From", "Watch Effective To")),
            ("Last Section 15(c) Renewal Evidence",
             "Per active fund engagement: the Section 15(c) Renewal Submission of the highest Renewal Year, with its Renewal Recommendation, Submission Delivered Date, Included Oversight Reviews, the renewal's 15(c) Request Date and Materials Delivered Date, and the Resolution Outcome and Resolution Effective Date of the Renewal Approving Resolution (35 Board Resolution, from DP-182); engagements whose last approved renewal is more than 12 months old are flagged.",
             _u("52", "Section 15(c) Renewal Submission", "Submission Engagement", "Submission Renewal", "Renewal Recommendation",
                "Submission Delivered Date", "Included Oversight Reviews")
             + _u("35", "Advisory Contract Renewal", "Renewal Year", "15(c) Request Date", "Materials Delivered Date",
                  "Renewal Approving Resolution")
             + _u("35", "Board Resolution", "Board Resolution ID", "Resolution Outcome", "Resolution Effective Date")),
            ("Sub-Adviser Terminations in Period",
             "Count of Manager Termination rows with Termination Effective Date in the period, by Termination Reason and Engagement Scope of the Terminated Engagement, with the notice lead time (Termination Effective Date - Termination Notice Date).",
             _u("52", "Manager Termination", "Terminated Engagement", "Termination Reason", "Termination Effective Date",
                "Termination Notice Date")
             + _u("52", "Sub-Adviser Engagement", "Engagement Scope")),
            ("Terminations Without Committee Decision",
             "Terminations in the period whose Deciding Committee Decision is blank or resolves to an Investment Committee Decision (from DP-126) with Committee Decision Type other than Manager Termination or Committee Decision Outcome not in (Approved, Approved with Conditions), or with Decision Effective Date after Termination Notice Date.",
             _u("52", "Manager Termination", "Deciding Committee Decision", "Termination Notice Date")
             + _u("24", "Investment Committee Decision", "Decision Committee", "Decision Meeting Date", "Decision Item Number",
                  "Committee Decision Type", "Committee Decision Outcome", "Decision Effective Date")
             + ["Sub-Adviser Terminations in Period"]),
            ("Terminations Without Replacement or Transition",
             "Terminations in the period with Replacement Engagement blank and Transition Event blank, by Termination Reason; with Originating Search shown where a replacement search was opened (DP-535).",
             _u("52", "Manager Termination", "Replacement Engagement", "Transition Event", "Originating Search", "Termination Reason")),
            ("Transition Completion Days and Cost",
             "For terminations with a Transition Event: Actual Completion Date - Termination Effective Date in calendar days, and Transition Total Cost, by Transition Type and In-Specie Indicator; transitions with Post-Transition Report Delivered Indicator other than Y 30 days after completion are flagged.",
             _u("52", "Manager Termination", "Transition Event", "Termination Effective Date")
             + _u("12", "Transition Event", "Transition ID", "Transition Type", "In-Specie Indicator", "Actual Completion Date",
                  "Transition Total Cost", "Post-Transition Report Delivered Indicator")),
            ("Terminated Engagements Still Active",
             "Terminations whose Termination Effective Date is more than 30 days before the as-of date and whose Terminated Engagement still has Engagement Status = Active or Engagement End Date blank, or whose Governing Fund Agreement has Advisory Agreement Status = Active and Agreement Termination Date blank.",
             _u("52", "Manager Termination", "Terminated Engagement", "Termination Effective Date")
             + _u("52", "Sub-Adviser Engagement", "Engagement Status", "Engagement End Date", "Governing Fund Agreement")
             + _u("35", "Fund Advisory Agreement", "Advisory Agreement Status", "Agreement Termination Date")),
        ],
        inputs=[
            ("52", "Sub-Adviser Engagement", ["Sub-Adviser Engagement ID", "Engaged Sub-Adviser", "Governing Fund Agreement",
                                              "Governing Contract", "Engaged Fund", "Delegated Mandate", "Engagement Scope",
                                              "Engagement Status", "Engagement Start Date", "Engagement End Date",
                                              "Board Approval Date"]),
            ("52", "Manager-of-Managers Hire Condition", ["Relied-On Exemptive Relief", "Shareholder Approval Required Indicator",
                                                          "Information Statement Due Date", "Information Statement Communication",
                                                          "Information Statement Sent Date", "Notice and Access Indicator"]),
            ("52", "Section 15(c) Renewal Submission", ["Submission Engagement", "Submission Renewal",
                                                        "Questionnaire Sent to Sub-Adviser Date",
                                                        "Sub-Adviser Response Received Date", "Included Oversight Reviews",
                                                        "Renewal Recommendation", "Recommendation Rationale",
                                                        "Submission Delivered Date"]),
            ("52", "Manager Termination", ["Terminated Engagement", "Termination Reason", "Deciding Committee Decision",
                                           "Termination Notice Date", "Termination Effective Date", "Replacement Engagement",
                                           "Originating Search", "Transition Event"]),
            ("52", "Sub-Adviser Watch Status", ["Watched Engagement", "Watch Status", "Watch Effective From", "Watch Effective To"]),
            ("52", "Oversight Review", ["Oversight Review ID", "Reviewed Engagement", "Review Period End", "Review Completed Date"]),
            ("35", "Advisory Contract Renewal", ["Renewal ID", "Renewed Agreement", "Renewal Year", "15(c) Request Date",
                                                 "Materials Delivered Date", "Renewal Approving Resolution"]),
            ("35", "Fund Advisory Agreement", ["Advisory Agreement ID", "External Sub-Adviser", "Advisory Agreement Type",
                                               "Advisory Agreement Status", "Agreement Effective Date",
                                               "Agreement Termination Date"]),
            ("35", "Exemptive Relief Reliance", ["Relying Fund", "Exemptive Relief Type", "Reliance Effective From",
                                                 "Reliance Effective To"]),
            ("35", "Board Resolution", ["Board Resolution ID", "Resolution Type", "Resolution Outcome", "Resolution Effective Date"]),
            ("13", "Shareholder Communication", ["Communication ID", "Communication Type", "Required Delivery Deadline",
                                                 "Communication Status"]),
            ("12", "Transition Event", ["Transition ID", "Transition Type", "In-Specie Indicator", "Actual Completion Date",
                                        "Transition Total Cost", "Post-Transition Report Delivered Indicator"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number",
                                                     "Committee Decision Type", "Committee Decision Outcome",
                                                     "Decision Effective Date"]),
        ],
        upstream=["DP-306", "DP-536", "DP-126", "DP-182", "DP-382", "DP-213", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day on the prior day's engagement, submission and termination records",
        history=("Event grain kept for the life of each engagement plus 6 years (Investment Company Act Rule 31a-2 for board "
                 "materials; manager-of-managers order conditions; Advisers Act Rule 204-2), every renewal year kept"),
        classification="Restricted - Legal",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "File extract"],
        dq_rules=[
            "Every Submission Engagement, Terminated Engagement, Replacement Engagement and Watched Engagement resolves to a DP-306 Sub-Adviser Engagement, every Governing Fund Agreement to a 35 Fund Advisory Agreement whose External Sub-Adviser is the Engaged Sub-Adviser, every Engaged Fund and Relying Fund to DP-004, every Renewal Approving Resolution to a DP-182 Board Resolution and every Deciding Committee Decision to a DP-126 Investment Committee Decision.",
            "There is at most one Section 15(c) Renewal Submission per Submission Engagement x Submission Renewal, Engagement End Date is on or after Engagement Start Date, Termination Effective Date on or after Termination Notice Date, and Exemptive Relief Reliance periods of one fund x relief type do not overlap.",
            "Information Statement Sent Date is populated only when the 13 Shareholder Communication it names has Communication Status Distributed (Information Statement Record Mismatches = 0 after five business days), and every renewal submission's Submission Renewal resolves to a 35 Advisory Contract Renewal whose Renewed Agreement is the engagement's Governing Fund Agreement.",
            "Renewal Recommendation and Submission Delivered Date are populated on every submission whose renewal has Materials Delivered Date, Information Statement Due Date on every hire condition, and Termination Reason and Deciding Committee Decision on every termination.",
            "The product publishes no personal data: sub-advisers are organizations and committee decisions are shown by committee, meeting date and item number; Recommendation Rationale is visible only to fund legal, manager research and the fund board reporting roles.",
            "No Section 15(c) Renewal Submission changes Renewal Recommendation, Recommendation Rationale or Included Oversight Reviews after its Submission Delivered Date (tested day over day against the prior snapshot; any change is an exception to fund legal), and the daily build is complete by 7am ET.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family); the fees, returns and "
               "profitability presented to the board are cited by DP-183 from their owners. "
               "PII tier: none. pii = N: the 52, 13 and 12 identifiers flagged by the validator carry the note 'Object PII "
               "tier: No PII' (the flag matches the word); sub-advisers are organizations and no client, shareholder or "
               "employee attribute is read. "
               "Boundaries: the sub-advisory contract, renewal and board approval stay 35 (CW-117): DP-183 keeps the renewal "
               "and the board's findings and is to list DP-538 upstream at WP1 (CW-253, INV+IOP RESPEC; the lineage agent "
               "adds the edge), so this product reads 35 Advisory Contract Renewal, Fund Advisory Agreement and Exemptive "
               "Relief Reliance directly and does not list DP-183, which would make a cycle. Board resolutions come from "
               "DP-182; the information statement is a 13 shareholder communication (DP-382); the 12 Transition Event is "
               "read directly because no live foundational product publishes it (DP-068, its earlier reader, is retired). "
               "Hand-off with DP-306: DP-306 counts the master (Fund Engagements Without Board Approval, Engagements "
               "Without Active Agreement, Overdue Information Statements, Manager Terminations); this product decides with "
               "them at the lifecycle event: Hires Without Board-Approved Agreement, Information Statements Sent Late and "
               "Sub-Adviser Terminations in Period are scoped to the period's hires and terminations and add the 35 and 13 "
               "evidence. Engagement master data and watch status are DP-306's; oversight reviews and readings DP-536's; manager "
               "searches DP-535's. "
               "Acceptance question 12 (plan section 8.5): answered with DP-536 by Last Section 15(c) Renewal Evidence, "
               "Renewal Submissions by Recommendation and Fund Engagements Without Renewal Submission; mastering domains "
               "52 and 35 (the 32 half is DP-536's Return Reading Tie-Out). "
               "Tailoring lever: manager-of-managers order (52 SME 3). Reference default: relied on for unaffiliated "
               "sub-advisers, information statement within 90 days of the hire (Release 33-8312 timing marked confirm); "
               "without the order, Hires Without Exemptive Relief in Force, Information Statements Sent Late and "
               "Information Statement Record Mismatches drop and shareholder approval moves to DP-183. Tailoring lever: "
               "OCIO and trust engagements (52 SME 6). Reference default: included through Engagement Scope, governed by "
               "a 39 contract rather than a 35 agreement, with no Section 15(c) submission. "
               "Taxonomy gap: 52 Manager-of-Managers Hire Condition is an attribute group with no key or parent reference, "
               "so its join to the engagement is implicit (as DP-306 records). Taxonomy gap: 52 Section 15(c) Renewal "
               "Submission has no version or status, so a resubmission overwrites the row. "
               "Drafting assumptions: Exemptive Relief Type value Manager of Managers; Renewal Recommendation values "
               "Continue and Continue with Conditions; Watch Status values Under Review and Termination Recommended; "
               "Communication Status Distributed; Engagement Status Active; Committee "
               "Decision Type Manager Termination; the 30-day, 90-day and 12-month windows. "
               "Decisions: CW-116, CW-117, CW-121, CW-253, CD-237. "
               "WP1 new (CW-253): first specification; inputs as in the INV+IOP candidate, adding 52 Sub-Adviser Watch "
               "Status and Oversight Review (renewal conflicts and included reviews) and 35 Board Resolution (the board's "
               "outcome); the candidate's DP-183 upstream is replaced by direct 35 reads to keep the CW-253 edge one-way, "
               "and DP-182, DP-382 and DP-213 are added upstream."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-544": dict(
        definition=("When one investment decision reaches more than one book (fund and institutional portfolios traded by the "
                    "25 desk, and managed accounts whose 46 trade proposal batches are released as 48 client block orders), "
                    "the sequence and timing of each book's release and first execution, and the execution price difference "
                    "between the books on the same instrument, side and trade date, tested against the rotation policy. It "
                    "joins the 25 and 48 trade records by key only and re-publishes no execution, so trading and compliance "
                    "can evidence that no book is systematically traded ahead of another (Advisers Act section 206 fair "
                    "allocation). It owns no certified metric family."),
        business_questions=[
            "Which investment decisions reached both the fund and institutional desk and the managed account program, and in what order was each book released and executed?",
            "Is one book systematically released or executed first across decisions this quarter, against the rotation policy?",
            "What was the execution price difference between the books on the same decision, instrument, side and trade date, and which decisions exceed tolerance?",
            "Which client block orders from managed account rebalancing name no source trade proposal batch, and which desk orders name no originating decision or rotation program?",
        ],
        grain=("Investment decision x instrument x side x book (25 fund and institutional desk; 46/48 managed account program), "
               "with release timestamp, first execution timestamp and volume-weighted execution price per book as the "
               "companion facts; event grain, kept by trade date"),
        dimensions=["Investment decision and action (DP-126)", "Instrument (DP-097)", "Order side", "Book (25 desk or 46/48 managed account program)",
                    "Portfolio type and business line (DP-140)", "Managed account program (DP-004)", "Trade rotation program",
                    "Trade date (DP-013)"],
        measures=[
            ("Multi-Book Decisions",
             "Count of Investment Decisions with Decision Timestamp in the period that have at least one 25 Trade Order (Originating Investment Decision = the decision) and at least one 46 Trade Proposal Batch released (Batch Status in (Released, Partially Released), Batch Released Timestamp) within 2 business days of Decision Timestamp whose Trade Proposals (Proposal Batch) are in the Decision Instrument with the same side, by Decision Action.",
             _u("24", "Investment Decision", "Investment Decision ID", "Decision Timestamp", "Decision Instrument", "Decision Action")
             + _u("25", "Trade Order", "Trade Order ID", "Originating Investment Decision", "Order Instrument", "Order Side")
             + _u("46", "Trade Proposal Batch", "Batch ID", "Batch Status", "Batch Released Timestamp")
             + _u("46", "Trade Proposal", "Proposal Batch", "Proposal Instrument", "Proposal Side")),
            ("Book Release Sequence",
             "Per multi-book decision x instrument x side: the release timestamp of each book (desk book: the earliest Order Created Timestamp of its Trade Orders, split by the Business Line of the Order Portfolio; managed account book: the Batch Released Timestamp, or the Block Created Timestamp of the 48 Client Block Order whose Source Trade Proposal Batch is the batch) and its rank (1 = first).",
             _u("25", "Trade Order", "Order Created Timestamp", "Order Portfolio")
             + _u("18", "Portfolio", "Portfolio ID", "Business Line")
             + _u("46", "Trade Proposal Batch", "Batch Released Timestamp")
             + _u("48", "Client Block Order", "Client Block Order ID", "Source Trade Proposal Batch", "Block Created Timestamp")
             + ["Multi-Book Decisions"]),
            ("Rotation Lag Minutes",
             "Per multi-book decision: the last book's release timestamp minus the first book's, in minutes, from Book Release Sequence; median and 90th percentile by Decision Action.",
             ["Book Release Sequence"]),
            ("Desk Book First Share %",
             "Multi-book decisions in the period whose desk book ranks 1 in Book Release Sequence / all multi-book decisions in the period; shown by quarter so a share persistently far from the rotation policy's pattern is visible.",
             ["Book Release Sequence", "Multi-Book Decisions"]),
            ("First Execution Lead Minutes",
             "Per multi-book decision: the earliest 25 Execution Timestamp of executions (Execution Type a fill) on the Broker Placements of the Block Orders containing its Trade Orders (Block Order Membership) minus the earliest 48 Execution Timestamp of Client Executions on the Order Routes of its Client Block Order (Routed Client Block Order), in minutes (negative = the desk book executed first).",
             _u("25", "Execution", "Execution ID", "Execution Placement", "Execution Type", "Execution Timestamp")
             + _u("25", "Broker Placement", "Placement Block Order", "Placement Timestamp")
             + _u("25", "Block Order Membership", "Member Block Order", "Member Trade Order")
             + _u("48", "Client Execution", "Client Execution ID", "Execution Order Route", "Execution Timestamp")
             + _u("48", "Order Route", "Order Route ID", "Routed Client Block Order")),
            ("Cross-Book Price Difference bps",
             "Per multi-book decision x trade date: (volume-weighted Execution Price of the managed account book's Client Executions - volume-weighted Execution Price of the desk book's Executions) / the desk book price x 10,000, weighted by Executed Quantity, signed so that a positive value means the managed account book paid more on a buy or received less on a sell.",
             _u("25", "Execution", "Executed Quantity", "Execution Price")
             + _u("48", "Client Execution", "Executed Quantity", "Execution Price", "Execution Trade Date")
             + _u("25", "Block Order", "Block Order ID", "Block Side")
             + _u("25", "Block Order Membership", "Member Block Order", "Member Trade Order")
             + _u("25", "Broker Placement", "Placement Block Order")
             + _u("25", "Execution", "Execution Placement")
             + _u("48", "Order Route", "Routed Client Block Order")
             + _u("48", "Client Execution", "Execution Order Route")),
            ("Decisions With Price Difference Beyond Tolerance",
             "Count of multi-book decisions whose absolute Cross-Book Price Difference bps exceeds 10 basis points, by order side and the book that was disadvantaged.",
             ["Cross-Book Price Difference bps"]),
            ("Same-Day Completion %",
             "Multi-book decisions whose desk book and managed account book both have executions on the decision's first trade date (25 Execution Timestamp date and 48 Execution Trade Date) / all multi-book decisions.",
             _u("25", "Execution", "Execution Timestamp") + _u("48", "Client Execution", "Execution Trade Date")
             + ["Multi-Book Decisions"]),
            ("Client Blocks Without Source Batch",
             "Count of 48 Client Block Orders with Block Origin = Managed Account Trade Proposal Batch whose Source Trade Proposal Batch is blank or does not resolve to a DP-304 Trade Proposal Batch, by Block Created Timestamp date; such blocks cannot be joined to a decision.",
             _u("48", "Client Block Order", "Block Origin", "Source Trade Proposal Batch", "Block Created Timestamp")
             + _u("46", "Trade Proposal Batch", "Batch ID")),
            ("Desk Rebalance Orders Without Originating Decision",
             "Count of 25 Trade Orders created in the period with Order Reason = Rebalance and Originating Investment Decision blank, by the Business Line of the Order Portfolio; such orders cannot be rotated against the managed account book.",
             _u("25", "Trade Order", "Order Reason", "Originating Investment Decision", "Order Created Timestamp", "Order Portfolio")
             + _u("18", "Portfolio", "Business Line")),
            ("Multi-Book Orders Without Rotation Program",
             "Count of Trade Orders of multi-book decisions whose Order Handling Instruction has Trade Rotation Program blank, with the count where Trade-Away Indicator = Y.",
             _u("25", "Order Handling Instruction", "Trade Rotation Program", "Trade-Away Indicator")
             + ["Multi-Book Decisions"]),
        ],
        inputs=[
            ("24", "Investment Decision", ["Investment Decision ID", "Decision Action", "Decision Strategy", "Decision Instrument",
                                           "Decision Timestamp"]),
            ("25", "Trade Order", ["Trade Order ID", "Order Portfolio", "Order Instrument", "Order Side", "Order Quantity",
                                   "Trade Order Status", "Order Created Timestamp", "Order Reason",
                                   "Originating Investment Decision"]),
            ("25", "Order Handling Instruction", ["Trade-Away Indicator", "Trade Rotation Program"]),
            ("25", "Block Order", ["Block Order ID", "Block Instrument", "Block Side", "Block Created Timestamp"]),
            ("25", "Block Order Membership", ["Member Block Order", "Member Trade Order"]),
            ("25", "Broker Placement", ["Placement Block Order", "Placement Timestamp"]),
            ("25", "Execution", ["Execution ID", "Execution Placement", "Execution Type", "Executed Quantity", "Execution Price",
                                 "Execution Timestamp"]),
            ("46", "Trade Proposal Batch", ["Batch ID", "Batch Program", "Batch Cycle Date", "Batch Released Timestamp",
                                            "Batch Status"]),
            ("46", "Trade Proposal", ["Trade Proposal ID", "Proposal Batch", "Proposal Instrument", "Proposal Side"]),
            ("48", "Client Block Order", ["Client Block Order ID", "Block Origin", "Source Trade Proposal Batch", "Block Instrument",
                                          "Block Side", "Aggregate Quantity", "Block Created Timestamp"]),
            ("48", "Order Route", ["Order Route ID", "Routed Client Block Order", "Routed Timestamp"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Executed Quantity", "Execution Price",
                                        "Execution Timestamp", "Execution Trade Date"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line"]),
        ],
        upstream=["DP-123", "DP-126", "DP-301", "DP-304", "DP-140", "DP-097", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 9am ET on T+1 for the prior trade date's decisions, releases and executions",
        history=("Event grain kept 6 years (Advisers Act Rule 204-2 trade allocation records; SEC Rule 17a-4 for the 48 client "
                 "order side), with the rotation results of each quarter kept as a locked snapshot"),
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Originating Investment Decision resolves to a DP-126 Investment Decision, every Order Portfolio to an active DP-140 portfolio, every Source Trade Proposal Batch to a DP-304 Trade Proposal Batch, every Execution Order Route to a DP-301 Order Route and every Decision Instrument, Order Instrument and Block Instrument to DP-097.",
            "Each Trade Order belongs to at most one Block Order at a time (Block Order Membership), each Client Execution to one Order Route, and every release and execution timestamp of a decision falls on or after its Decision Timestamp.",
            "The sum of Executed Quantity of the desk book's Executions for a decision equals the sum of Order Quantity of its filled Trade Orders within one share (DP-123), and the managed account book's Client Execution quantity equals the Aggregate Quantity of its Client Block Order within one share (DP-301).",
            "Decision Timestamp, Order Created Timestamp, Batch Released Timestamp, Execution Timestamp, Execution Price and Executed Quantity are populated on every row a measure reads.",
            "Rows are published at book level only (fund and institutional desk book, managed account program book): no 15 account, Trade Proposal account or institutional separate account owned by a natural person is published, so no personal data leaves the product.",
            "The T+1 build is complete by 9am ET; a quarter's rotation results are locked at quarter-end and corrections to past trade dates are shown as restated rows with the correction date.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family); execution quality under Rules 605 "
               "and 606 is 48's (DP-436). "
               "PII tier: none at publication. pii = N: 25 Order Portfolio and the 46 and 48 client-side attributes are "
               "noted PII where an institutional separate account belongs to a natural person or a proposal names a 15 "
               "account; the product reads them only to join books and publishes book-level aggregates (DQ5). "
               "Boundaries: 25 orders, blocks and executions stay DP-123's and 48 client orders and executions DP-301's; this "
               "product joins them by key only and re-publishes no execution (CW-255, CD-314). Trade proposals are 46 "
               "(DP-304); investment decisions DP-126's. Intermediary model delivery (DP-129) is not read: delivered models "
               "are traded by the sponsor, not by the firm, so they have no execution to rotate; the candidate's DP-129 "
               "upstream is dropped for that reason. "
               "Acceptance question 5: context for DP-436 (reader named here; DP-436 does not list this product upstream, so the "
               "edge stays one-way), with Cross-Book Price Difference bps (fund desk versus client "
               "execution on the same decision) as context for execution quality by order type. "
               "Tailoring lever: trade routing of managed accounts (INV+IOP brief lever 11). Reference default: managed "
               "account blocks are routed through 48 as client block orders; a firm that routes them through the fund desk "
               "reads 25 only, and the rotation becomes a 25 allocation test. Tailoring lever: rotation policy. Reference "
               "default: random or alternating rotation recorded as a 05 Trade Rotation Program on each order. "
               "Tailoring lever: price tolerance. Reference default: 10 basis points. "
               "Taxonomy gap: 46 Trade Proposal Batch and 46 Trade Proposal carry no reference to the 24 Investment "
               "Decision that drove a model change, so the managed account book is matched to the decision by instrument, "
               "side and a two-business-day window. Taxonomy gap: 25 Order Handling Instruction.Trade Rotation Program "
               "references a 05 object while rotation is a 25 policy; the rotation policy itself has no 25 object. "
               "Drafting assumptions: Batch Status Released and Partially Released; Block Origin value Managed Account Trade Proposal Batch; Order "
               "Reason value Rebalance; Execution Type fill values; the two-business-day window, 10-basis-point tolerance "
               "and 9am build. "
               "Decisions: CW-007, CW-255, CD-314. "
               "WP1 new (CW-255): first specification; inputs as in the INV+IOP candidate, adding the 25 order handling, "
               "block membership and broker placement links, 46 Trade Proposal for the batch instrument, 48 Order Route "
               "for the execution-to-block link and 18 Portfolio for the book's business line; DP-140 and DP-004 added "
               "upstream and DP-129 dropped."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-532": dict(
        definition=("The presentation view of the certified Personal Rate of Return: for each client account and household "
                    "performance group, over standard and client-chosen periods, the Personal Return Value read from DP-145 "
                    "with the method (time- or money-weighted), calculation method, fee basis, period basis, annualization "
                    "and suppression state printed beside it, the beginning and ending values, external flows and fees it "
                    "rests on, the statement market value of the account from the 49 brokerage book, and the client's "
                    "comparison benchmark return. Advisors, the digital experience and statements read it; it never "
                    "recalculates a return and never shows a suppressed or Preliminary row as a number (CW-251). It owns no "
                    "certified metric family."),
        business_questions=[
            "What is each household's and each account's personal rate of return for the period, and how is it computed (time- or money-weighted, calculation method, fee basis, period basis)?",
            "Which account and household returns are shown as suppressed or withheld as Preliminary, and why?",
            "What beginning value, ending value, external flows and fees does each return rest on, and does the ending value agree with the account's statement market value?",
            "How did each account and household do against its comparison benchmark over the same period?",
            "Which open accounts and households have no displayable personal return, and which displayed rows have no advisor of record under the account, client, household precedence?",
        ],
        grain=("Personal return subject (15 client account or 32 household performance group of an 02 Client Household) x "
               "period start x period end x method x fee basis, current version only, as displayed on the period's "
               "publication date; companion facts comparison benchmark return and statement market value; monthly "
               "snapshots with every displayed version kept"),
        dimensions=["Client account (DP-093)", "Client household (DP-240)", "Household performance group and type (DP-145)",
                    "Personal return method and calculation method (DP-145)", "Personal return fee basis (DP-145)",
                    "Period basis and period end", "Return status and suppression reason (DP-145)",
                    "Comparison benchmark (DP-145)", "Advisor of record (DP-009)", "Account type and business line (DP-093)",
                    "Publication date (DP-013)"],
        measures=[
            ("Personal Return Value (from DP-145)",
             "The certified Personal Return Value as DP-145 publishes it: the value of the highest Personal Return Version per Personal Rate of Return ID with Personal Return Status in (Final, Restated), on account rows (Personal Return Account) and household rows (Personal Return Group), by Personal Return Method, Personal Return Fee Basis and period; read, never recalculated, and displayed blank with a suppression label where DP-145 publishes it null.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Version", "Personal Return Subject Type",
                "Personal Return Account", "Personal Return Group", "Personal Return Period Start Date",
                "Personal Return Period End Date", "Personal Return Method", "Personal Return Fee Basis", "Personal Return Value",
                "Personal Return Status")),
            ("Displayed Personal Returns",
             "Count of account and household rows displayed with a Personal Return Value (from DP-145) for the period, by Personal Return Subject Type, Personal Return Method, Personal Return Fee Basis and Personal Return Period Basis.",
             _u("32", "Personal Rate of Return", "Personal Return Subject Type", "Personal Return Period Basis")
             + ["Personal Return Value (from DP-145)"]),
            ("Suppressed Personal Returns (from DP-145)",
             "DP-145's Suppressed Personal Returns as published (subjects whose Personal Return Value is null under DP-145's suppression rule), shown row by row with the suppression label DP-145 carries: the Return Suppression Reason of the subject's Client Performance Profile, or the Client Return Exception Type of the open Client Return Exception with Suppresses Return Indicator = Y; this product applies no suppression rule of its own.",
             _u("32", "Client Performance Profile", "Client Profile Subject Type", "Client Profile Account", "Client Profile Group",
                "Return Suppression Reason")
             + _u("32", "Client Return Exception", "Exception Account", "Client Return Exception Type", "Return Exception Status",
                  "Suppresses Return Indicator")
             + ["Personal Return Value (from DP-145)"]),
            ("Preliminary Returns Withheld",
             "Count of current-version rows with Personal Return Status = Preliminary that are withheld from display for the period (shown as 'not yet final'), by Personal Return Period Basis.",
             _u("32", "Personal Rate of Return", "Personal Return Status", "Personal Return Period Basis")),
            ("Return Method and Basis Disclosure",
             "For each displayed row, the computation printed beside the value: Personal Return Method, Personal Return Calculation Method, Personal Return Fee Basis, Personal Return Period Basis and Personal Return Annualized Indicator, with the External Cash Flow Timing and Large Cash Flow Threshold of the Client Applied Calculation Policy (Performance Calculation Policy, by Calculation Policy Code and Version); the measure is the share of displayed rows with all five fields and the policy populated.",
             _u("32", "Personal Rate of Return", "Personal Return Method", "Personal Return Calculation Method",
                "Personal Return Fee Basis", "Personal Return Period Basis", "Personal Return Annualized Indicator")
             + _u("32", "Client Performance Profile", "Client Applied Calculation Policy")
             + _u("32", "Performance Calculation Policy", "Calculation Policy Code", "Calculation Policy Version",
                  "External Cash Flow Timing", "Large Cash Flow Threshold")
             + ["Displayed Personal Returns"]),
            ("Personal Return Inputs Shown (from DP-145)",
             "Beginning Market Value, Ending Market Value, Net External Flows and, on net-of-fee rows, Fees Deducted of the displayed version, as DP-145 publishes them on the account row or the household row itself (never summed from member accounts). Ending Market Value is DP-145's book value: for brokerage and managed accounts the 49 holdings plus client cash under the DP-007 cash rule less the end-of-day margin debit, tied out by DP-145's Personal Return Ending Value Tie-Out; no second value or tie-out is computed here.",
             _u("32", "Personal Rate of Return", "Beginning Market Value", "Ending Market Value", "Net External Flows",
                "Fees Deducted")
             + ["Personal Return Value (from DP-145)"]),
            ("Comparison Benchmark Return (from DP-145)",
             "Benchmark Return Value of the Client Comparison Benchmark of the subject's Client Performance Profile for the same Benchmark Period Start Date and End Date as the displayed row, highest Benchmark Return Version with Benchmark Return Status in (Final, Restated) and Benchmark Return Type = Net Total Return; certified by DP-145, read as published.",
             _u("32", "Benchmark Return", "Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                "Benchmark Return Type", "Benchmark Return Version", "Benchmark Return Value", "Benchmark Return Status")
             + _u("32", "Client Performance Profile", "Client Comparison Benchmark")
             + _u("01", "Benchmark", "Benchmark ID", "Benchmark Name")),
            ("Personal Return Less Comparison Benchmark",
             "Personal Return Value (from DP-145) - Comparison Benchmark Return (from DP-145) for the same period and annualization, in percentage points; a presentation difference of two certified numbers, not a return, blank wherever either is blank.",
             ["Personal Return Value (from DP-145)", "Comparison Benchmark Return (from DP-145)"]),
            ("Profiles Without Comparison Benchmark",
             "Count of Client Performance Profiles effective on the period end (Client Profile Effective From) with Client Comparison Benchmark blank, by Client Profile Subject Type.",
             _u("32", "Client Performance Profile", "Client Comparison Benchmark", "Client Profile Effective From",
                "Client Profile Subject Type")),
            ("Account Return Coverage %",
             "Open accounts (15 Account Status Open, Account Open Date before the period start) with a displayed account-row Personal Return Value (from DP-145) or a suppression label for the period / open accounts with a Client Performance Profile whose Performance Start Date is on or before the period start, by Account Type and Account Business Line.",
             _u("15", "Account", "Account ID", "Account Type", "Account Status", "Account Open Date", "Account Business Line")
             + _u("32", "Client Performance Profile", "Performance Start Date", "Client Profile Account")
             + ["Displayed Personal Returns", "Suppressed Personal Returns (from DP-145)"]),
            ("Household Return Coverage %",
             "02 Client Households with at least one member (Household Membership with Membership Status Active effective on the period end) owning a profiled account (15 Account Party Role with Account Role Type in (Primary Owner, Joint Owner) effective on the period end) that have a displayed household-row value of their Household Performance Group of Performance Group Type = Default (All Household Accounts) / all such households.",
             _u("02", "Household Membership", "Household", "Household Member", "Membership Status", "Membership Effective From",
                "Membership Effective To")
             + _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                  "Account Role Effective To")
             + _u("32", "Household Performance Group", "Household Performance Group ID", "Group Household", "Performance Group Type",
                  "Performance Group Status")
             + ["Displayed Personal Returns"]),
            ("Household Group Members Shown",
             "Count of member accounts (Household Performance Group Member with Member Inclusion Date <= period end < Member Exclusion Date or open) of each displayed household group, by Performance Group Type, printed with the household row so the client sees which accounts the household return covers.",
             _u("32", "Household Performance Group Member", "Member Performance Group", "Member Account", "Member Inclusion Date",
                "Member Exclusion Date")
             + _u("32", "Household Performance Group", "Performance Group Type")),
            ("Rows Without Advisor of Record",
             "Displayed rows with no advisor of record under the 03 precedence (DP-009): for an account row, the primary Party Coverage Assignment (Primary Coverage Indicator = Y, Party Coverage Role = Primary Advisor, effective on the period end) whose Covered Account is the account; failing that, one whose Covered Party is an owner of the account (15 Account Party Role, Account Role Type in (Primary Owner, Joint Owner)) and Covered Account is blank; failing that, one whose Covered Party is the account's Client Household (02 Household Membership); for a household row, the household's assignment. One primary per scope and date; rows without one are visible to the client and the service roles only.",
             _u("03", "Party Coverage Assignment", "Covered Party", "Covered Account", "Covering Advisor", "Party Coverage Role",
                "Primary Coverage Indicator", "Coverage Effective From", "Coverage Effective To")
             + _u("32", "Household Performance Group", "Group Household")
             + _u("32", "Personal Rate of Return", "Personal Return Account")
             + _u("15", "Account Party Role", "Role Party", "Role Account", "Account Role Type")
             + _u("02", "Household Membership", "Household", "Household Member")
             + ["Displayed Personal Returns"]),
            ("Restated Returns Displayed",
             "Count of displayed rows with Personal Return Status = Restated, with the superseded value (Supersedes Personal Return) available to the client and service roles, by period end.",
             _u("32", "Personal Rate of Return", "Personal Return Status", "Supersedes Personal Return")
             + ["Displayed Personal Returns"]),
        ],
        inputs=[
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Version", "Personal Return Subject Type",
                                               "Personal Return Account", "Personal Return Group",
                                               "Personal Return Period Start Date", "Personal Return Period End Date",
                                               "Personal Return Period Basis", "Personal Return Method",
                                               "Personal Return Calculation Method", "Personal Return Fee Basis",
                                               "Personal Return Value", "Personal Return Annualized Indicator",
                                               "Beginning Market Value", "Ending Market Value", "Net External Flows",
                                               "Fees Deducted", "Personal Return Status", "Supersedes Personal Return"]),
            ("32", "Client Performance Profile", ["Client Profile Subject Type", "Client Profile Account", "Client Profile Group",
                                                  "Performance Start Date", "Client Methods Produced", "Client Fee Bases Produced",
                                                  "Client Comparison Benchmark", "Client Applied Calculation Policy",
                                                  "Return Suppression Reason", "Client Profile Effective From"]),
            ("32", "Household Performance Group", ["Household Performance Group ID", "Group Household", "Performance Group Type",
                                                   "Performance Group Status"]),
            ("32", "Household Performance Group Member", ["Member Performance Group", "Member Account", "Member Inclusion Date",
                                                          "Member Exclusion Date"]),
            ("32", "Client Return Exception", ["Exception Account", "Client Return Exception Type", "Return Exception Status",
                                               "Suppresses Return Indicator"]),
            ("32", "Performance Calculation Policy", ["Calculation Policy Code", "Calculation Policy Version",
                                                      "External Cash Flow Timing", "Large Cash Flow Threshold"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date",
                                        "Benchmark Return Type", "Benchmark Return Version", "Benchmark Return Value",
                                        "Benchmark Return Status"]),
            ("01", "Benchmark", ["Benchmark ID", "Benchmark Name"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Open Date", "Account Business Line"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status", "Membership Effective From",
                                            "Membership Effective To"]),
            ("03", "Party Coverage Assignment", ["Covered Party", "Covered Account", "Covering Advisor", "Party Coverage Role",
                                                 "Primary Coverage Indicator", "Coverage Effective From",
                                                 "Coverage Effective To"]),
        ],
        upstream=["DP-145", "DP-093", "DP-240", "DP-009", "DP-013"],
        refresh="Daily",
        timeliness=("Month-end and quarter-end returns displayed by business day 8 after period end (one day after DP-145 marks "
                    "them Final); client-chosen periods on request from the current Final versions; refreshed daily for "
                    "restatements"),
        history=("Every displayed version kept 6 years with its publication date (SEC Rule 17a-4 and Advisers Act Rule 204-2 for "
                 "returns shown on statements and client reports); monthly snapshots"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "CRM embed"],
        dq_rules=[
            "Every Personal Return Account and Client Profile Account resolves to an open or closed DP-093 client account, every Group Household to a DP-240 Client Household (party type Household), every Client Comparison Benchmark to a 01 Benchmark that DP-145 publishes Benchmark Returns for, and every Covering Advisor to a DP-009 advisor.",
            "Household Performance Group Member inclusion periods of one Member Account in one group do not overlap, Member Exclusion Date is blank or on or after Member Inclusion Date, and Personal Return Period End Date is on or after Personal Return Period Start Date on every displayed row.",
            "Every displayed Personal Return Value (from DP-145) equals DP-145's published value for the same Personal Rate of Return ID and Personal Return Version (display rounding to two decimals only), every Comparison Benchmark Return (from DP-145) equals DP-145's Benchmark Return, and no number is displayed where DP-145 publishes the value null (the row shows its suppression label).",
            "Personal Return Method, Personal Return Fee Basis, Personal Return Period Basis and Personal Return Status are populated on every displayed row, and Client Applied Calculation Policy on every effective Client Performance Profile.",
            "Account and household rows are entitled at row level to the client, the advisor of record (DP-009 Party Coverage Assignment, account then client then household precedence) and the performance, service and supervision roles; a suppressed or Preliminary row is never shown as a number; an account-free aggregate view (counts and coverage only) serves wide use.",
            "Month-end rows are displayed only after DP-145 marks them Final and by business day 8; a restatement replaces the displayed version the next day and the prior displayed version is kept, never edited.",
        ],
        notes=("Certified numbers: reads Personal Return Value and Benchmark Return from DP-145 (certified, CW-011, CD-320) and "
               "never recalculates them (CW-251); Personal Return Less Comparison Benchmark is a presentation difference of two "
               "certified numbers. The beginning and ending values, flows and fees are DP-145's as published; DP-145 owns "
               "the ending-value, flow and fee tie-outs (ending value = 49 holdings plus DP-007 client cash less margin debit) "
               "and this product computes none (lead ruling on the C-6 review). DP-145's control measures (Suppressed Personal "
               "Returns, Restated Personal Returns Requiring Notification) are read as published. "
               "PII tier: financial (account and household returns, values, flows and fees; no special-category data, so "
               "DP-322 is not read). Classification Confidential - Personal Data, row-level entitlement by advisor of "
               "record. "
               "Boundaries: the household is the 02 Client Household (DP-240); the Household Performance Group is a "
               "performance grouping of DP-145, not the 13 mailing group, the 46 managed group or the 47 Fee Household; the "
               "household dimension stays inside DP-240 (lead ruling). Suppression and restatement workflow is DP-533's; "
               "managed account dispersion was DP-534's (backlog, merge target DP-345); goal progress is DP-337's. Advisor "
               "of record is read from 03 Party Coverage Assignment through DP-009. "
               "Acceptance question 9 (plan section 8.5): answered by Personal Return Value (from DP-145), Return Method and "
               "Basis Disclosure, Personal Return Inputs Shown (from DP-145) and Household Return Coverage %; mastering "
               "domains 32 and 02 directly, and 49 through DP-145 (Ending Market Value is the 32 Derived copy of the 49 "
               "brokerage book, tied out by DP-145's Personal Return Ending Value Tie-Out, whose uses read 49 Client Holding "
               "Valuation); the 49 read was removed from this product by the lead's ruling. "
               "Tailoring lever: headline personal return (32 SME 1, 2, 4). Reference default: net of fees, money-weighted as "
               "the retail headline and time-weighted for program reporting; returns for periods shorter than one full "
               "period after Performance Start Date are suppressed. Tailoring lever: household groups (32 SME 3). Reference "
               "default: the Default (All Household Accounts) group, with client-defined subsets shown as further groups. "
               "Tailoring lever: comparison benchmark. Reference default: the benchmark of the account's model or risk "
               "band, set on the Client Performance Profile. "
               "Taxonomy gap: 32 Personal Rate of Return has no publication or display date, so the displayed version is "
               "recorded by this product's snapshot date. Taxonomy gap: 32 Client Performance Profile has no profile end "
               "date (only Client Profile Effective From), so the profile in force is the latest one on or before the period "
               "end. "
               "Drafting assumptions: Personal Return Status values Final, Restated and Preliminary; Return Exception Status "
               "Open; Account Status Open; Membership Status Active; Performance Group "
               "Type Default (All Household Accounts); Benchmark Return Type Net Total Return; Account Role Type Primary Owner and Joint Owner; Party Coverage Role Primary Advisor; business day 8. "
               "Decisions: CW-005, CW-011, CW-027, CW-129, CW-251, CD-217, CD-320. "
               "WP1 new (CW-251): first specification; inputs as in the INV+IOP candidate (32 Client Account Performance "
               "objects, 15 Account, 02 Household Membership, 01 Benchmark), adding 32 Client Return Exception and "
               "Performance Calculation Policy (suppression label and 'how computed'), 32 Benchmark Return (comparison), 15 "
               "Account Party Role (household to account) and 03 Party Coverage Assignment (advisor of record); the "
               "candidate's 02 Household object is not read because the household key and membership are on 02 Household "
               "Membership; DP-009 added upstream. Fix pass (C-6 review): the 49 statement value measure and DP-300 are "
               "removed, the suppression count reads DP-145's measure, household inputs are shown as DP-145 publishes the "
               "household row, the advisor of record follows the account, client, household precedence, and the "
               "comparison benchmark is sourced to DP-145 (DP-004 dropped from upstream)."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-533": dict(
        definition=("The control behind the certified Personal Rate of Return: open and aged client return exceptions (missing "
                    "price, unposted corporate action, large flow, conversion gap) with the accounts and household "
                    "performance groups they suppress, profile-level suppressions, client performance profiles missing a "
                    "start date or a calculation policy, personal returns restated and flagged for client notification, and "
                    "institutional account return restatements. It checks that no Personal Return Value is published while "
                    "an exception or profile suppresses it, reading the values from DP-145 and never recalculating them "
                    "(CW-251). It owns no certified metric family."),
        business_questions=[
            "Which client return exceptions are open, of which type, how old are they, and which accounts and household groups do they suppress?",
            "Is any personal return published as a value while its account or household is suppressed?",
            "Which client performance profiles are missing a performance start date or a current calculation policy, and which open accounts have no profile at all?",
            "Which personal returns were restated this period, by how much and why, and which are flagged for client notification?",
            "Which large-flow exceptions were raised although the flow was below the policy threshold, and which institutional account returns were restated with client notification required?",
        ],
        grain=("Client return exception (15 account x exception date x exception type), with the suppressed account and "
               "household performance groups as companion rows; plus personal return restatement (Personal Rate of Return "
               "version superseding another) and client performance profile control rows; daily snapshots, every exception "
               "and version kept"),
        dimensions=["Client account (DP-093)", "Client household (DP-240)", "Household performance group (DP-145)",
                    "Client return exception type and status", "Suppression reason", "Restatement cause",
                    "Performance calculation policy and version", "Personal return method and fee basis (DP-145)",
                    "Account type and status (DP-093)", "Exception date and as-of date (DP-013)"],
        measures=[
            ("Open Return Exceptions",
             "Count of Client Return Exception rows with Return Exception Status = Open, by Client Return Exception Type and Suppresses Return Indicator, with age in business days from Exception Date to the as-of date in buckets (0-2, 3-5, 6-10, over 10).",
             _u("32", "Client Return Exception", "Exception Account", "Exception Date", "Client Return Exception Type",
                "Return Exception Status", "Suppresses Return Indicator")),
            ("Exceptions Aged Over 5 Business Days",
             "Open Return Exceptions older than 5 business days, by Client Return Exception Type and the queue that owns the cause (Missing Price: pricing, DP-148; Unposted Corporate Action: client asset servicing, DP-452; Large External Flow and Conversion Gap: performance operations).",
             _u("32", "Client Return Exception", "Exception Date", "Client Return Exception Type") + ["Open Return Exceptions"]),
            ("Suppressed Personal Returns (from DP-145)",
             "DP-145's Suppressed Personal Returns as published: account and household subjects whose Personal Return Value DP-145 publishes null for the period under its suppression rule (a Return Suppression Reason on the subject's Client Performance Profile, or an open Client Return Exception with Suppresses Return Indicator = Y on the account or on a member account of the household group), by Return Suppression Reason, Client Return Exception Type and Client Profile Subject Type; read, not re-derived.",
             _u("32", "Client Performance Profile", "Client Profile Subject Type", "Client Profile Account", "Client Profile Group",
                "Return Suppression Reason", "Client Profile Effective From")
             + _u("32", "Client Return Exception", "Exception Account", "Suppresses Return Indicator", "Return Exception Status",
                  "Client Return Exception Type")
             + _u("32", "Personal Rate of Return", "Personal Return Value", "Personal Return Account", "Personal Return Group")),
            ("Household Groups Affected by Open Exceptions",
             "Count of active Household Performance Groups (Performance Group Status Active) with a member account (Household Performance Group Member with Member Inclusion Date <= as-of < Member Exclusion Date or open) that carries an open suppressing exception, by Performance Group Type and Client Return Exception Type: the operations worklist of household rows that clear when the account exception clears (the suppression itself is DP-145's).",
             _u("32", "Household Performance Group", "Household Performance Group ID", "Group Household", "Performance Group Type",
                "Performance Group Status")
             + _u("32", "Household Performance Group Member", "Member Performance Group", "Member Account", "Member Inclusion Date",
                  "Member Exclusion Date")
             + ["Open Return Exceptions"]),
            ("Suppressed Returns Published as Values",
             "Control, zero expected: count of current Personal Rate of Return versions (highest Personal Return Version per Personal Rate of Return ID) with Personal Return Status in (Final, Restated) and Personal Return Value populated whose subject DP-145's own suppression rule marks as suppressed for the period end (the subjects of Suppressed Personal Returns (from DP-145)); it tests DP-145's publication against DP-145's rule and states no rule of its own.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Version", "Personal Return Status",
                "Personal Return Value", "Personal Return Period End Date")
             + ["Suppressed Personal Returns (from DP-145)"]),
            ("Profiles Missing Start Date or Policy",
             "Count of Client Performance Profiles in force with Performance Start Date blank, Client Applied Calculation Policy blank, or a Client Applied Calculation Policy that resolves to no Performance Calculation Policy (Calculation Policy Code, Calculation Policy Version) with Policy Effective From on or before the as-of date.",
             _u("32", "Client Performance Profile", "Performance Start Date", "Client Applied Calculation Policy")
             + _u("32", "Performance Calculation Policy", "Calculation Policy Code", "Calculation Policy Version",
                  "Policy Effective From")),
            ("Profiles on Superseded Policy Version",
             "Profiles in force whose Client Applied Calculation Policy names a Calculation Policy Version lower than the highest version of the same Calculation Policy Code effective on the as-of date.",
             _u("32", "Client Performance Profile", "Client Applied Calculation Policy")
             + _u("32", "Performance Calculation Policy", "Calculation Policy Code", "Calculation Policy Version",
                  "Policy Effective From")),
            ("Open Accounts Without Performance Profile",
             "Count of 15 accounts with Account Status Open, Account Open Date more than one month before the as-of date and Account Type among DP-145's personal-return subjects (Brokerage Account, Fund-Only Account, Managed Advisory Account, Participant Account, Fiduciary Account) that have no Client Performance Profile (Client Profile Account), by Account Type and Account Business Line.",
             _u("15", "Account", "Account Status", "Account Open Date", "Account Business Line", "Account Type")
             + _u("32", "Client Performance Profile", "Client Profile Account")),
            ("Exceptions on Closed Accounts",
             "Open exceptions whose Exception Account has Account Status Closed and an Account Close Date before the Exception Date (raised in error or after the final statement).",
             _u("32", "Client Return Exception", "Exception Account", "Exception Date", "Return Exception Status")
             + _u("15", "Account", "Account Status", "Account Close Date")),
            ("Large Flow Exceptions Below Policy Threshold",
             "Count of exceptions with Client Return Exception Type = Large External Flow whose account's monthly personal return row containing the Exception Date has |Net External Flows| / Beginning Market Value (from DP-145) below the Large Cash Flow Threshold of the profile's Client Applied Calculation Policy; a check on the exception trigger, not a return calculation.",
             _u("32", "Client Return Exception", "Client Return Exception Type", "Exception Date", "Exception Account")
             + _u("32", "Personal Rate of Return", "Net External Flows", "Beginning Market Value", "Personal Return Period Start Date")
             + _u("32", "Performance Calculation Policy", "Large Cash Flow Threshold")
             + _u("32", "Client Performance Profile", "Client Applied Calculation Policy")),
            ("Restated Personal Returns",
             "Count of Personal Rate of Return versions with Personal Return Status = Restated and Supersedes Personal Return populated whose Personal Return Period End Date falls in a closed period, by Personal Return Restatement Cause, with the mean absolute change in Personal Return Value (from DP-145) against the superseded version.",
             _u("32", "Personal Rate of Return", "Personal Return Status", "Supersedes Personal Return",
                "Personal Return Restatement Cause", "Personal Return Value", "Personal Return Period End Date")),
            ("Restated Personal Returns Requiring Notification (from DP-145)",
             "DP-145's Restated Personal Returns Requiring Notification as published (Restated versions with a Supersedes Personal Return and Personal Return Client Notification Indicator = Y), by Personal Return Restatement Cause, Personal Return Method and Personal Return Fee Basis, with the size of each change from Restated Personal Returns: the population performance and service operations must notify.",
             _u("32", "Personal Rate of Return", "Personal Return Client Notification Indicator", "Personal Return Method",
                "Personal Return Fee Basis", "Supersedes Personal Return", "Personal Return Restatement Cause")
             + ["Restated Personal Returns"]),
            ("Material Restatements (from DP-145), Institutional Accounts",
             "DP-145's Material Restatements as published, sliced to Performance Returns with Return Subject Type = Account (institutional separate accounts, CW-129): count of Performance Restatements (Restated Return) with Material Error Indicator = Y in the period (Restatement Date) and the mean absolute Restatement Return Difference, by Restatement Cause, with the count where Client Notification Required Indicator = Y.",
             _u("32", "Performance Restatement", "Restated Return", "Restatement Cause", "Restatement Date", "Material Error Indicator",
                "Client Notification Required Indicator", "Restatement Return Difference")
             + _u("32", "Performance Return", "Performance Return ID", "Return Subject Type", "Return Account")),
        ],
        inputs=[
            ("32", "Client Return Exception", ["Exception Account", "Exception Date", "Client Return Exception Type",
                                               "Return Exception Status", "Suppresses Return Indicator", "Exception Resolution"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Version", "Personal Return Account",
                                               "Personal Return Group", "Personal Return Period Start Date",
                                               "Personal Return Period End Date", "Personal Return Method",
                                               "Personal Return Fee Basis", "Personal Return Value", "Beginning Market Value",
                                               "Net External Flows", "Personal Return Status", "Supersedes Personal Return",
                                               "Personal Return Restatement Cause",
                                               "Personal Return Client Notification Indicator"]),
            ("32", "Client Performance Profile", ["Client Profile Subject Type", "Client Profile Account", "Client Profile Group",
                                                  "Performance Start Date", "Client Applied Calculation Policy",
                                                  "Return Suppression Reason", "Client Profile Effective From"]),
            ("32", "Performance Calculation Policy", ["Calculation Policy Code", "Calculation Policy Version",
                                                      "Large Cash Flow Threshold", "Policy Effective From"]),
            ("32", "Household Performance Group", ["Household Performance Group ID", "Group Household", "Performance Group Type",
                                                   "Performance Group Status"]),
            ("32", "Household Performance Group Member", ["Member Performance Group", "Member Account", "Member Inclusion Date",
                                                          "Member Exclusion Date"]),
            ("32", "Performance Restatement", ["Restated Return", "Restatement Sequence", "Restatement Cause", "Restatement Date",
                                               "Restatement Return Difference", "Material Error Indicator",
                                               "Client Notification Required Indicator"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Subject Type", "Return Account"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Open Date", "Account Close Date",
                               "Account Business Line"]),
        ],
        upstream=["DP-145", "DP-093", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="By 8am ET each business day on the prior day's exceptions, profiles and personal return versions",
        history=("Every exception, profile and personal return version kept 6 years (SEC Rule 17a-4 and Advisers Act Rule 204-2 "
                 "for returns shown to clients); daily snapshots of the open exception population kept 2 years"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Exception Account, Client Profile Account, Personal Return Account and Member Account resolves to a DP-093 client account, every Group Household to a DP-240 Client Household, and every Restated Return to a DP-145 Performance Return.",
            "One Client Return Exception exists per Exception Account x Exception Date x Client Return Exception Type, Household Performance Group Member periods of one account in one group do not overlap, and Member Exclusion Date is blank or on or after Member Inclusion Date.",
            "Suppressed Returns Published as Values is zero for every period end against DP-145's own suppression rule and Suppressed Personal Returns (from DP-145) equals DP-145's published count, and every Personal Return Value read equals DP-145's published value for the same Personal Rate of Return ID and Personal Return Version.",
            "Client Return Exception Type, Return Exception Status and Suppresses Return Indicator are populated on every exception, Exception Resolution on every exception whose status is Resolved, and Personal Return Restatement Cause on every Restated personal return.",
            "Rows are visible only to performance measurement, client service operations and supervision; household and account identifiers are not published outside those roles, and the aggregate dashboard shows counts by type, reason and cause only.",
            "The daily snapshot is complete by 8am ET; an exception's history is never edited (a resolution sets Return Exception Status and Exception Resolution), and restatement counts for a closed month are locked at the next month-end.",
        ],
        notes=("Certified numbers: reads Personal Return Value from DP-145 (certified, CW-011) to test suppression and measure "
               "restatement size; never recalculates a return (CW-251); Large Flow Exceptions Below Policy Threshold compares "
               "DP-145's own flow and value copies with the policy threshold, a trigger check only. "
               "PII tier: financial (account and household returns and exceptions). "
               "Boundaries: Personal Return Value, the suppression rule and the tie-outs are DP-145's; presentation is "
               "DP-532's. Causes route to their owners and are not re-mastered here: missing and stale prices to pricing "
               "control (DP-148; backlog DP-543's coverage view folds into DP-516), unposted corporate actions and 49 "
               "posting breaks to the BWO products (DP-452, DP-446). The candidate's DP-143 upstream is dropped because no "
               "22 price is read. The household is the 02 Client Household (DP-240); the Household Performance Group is a "
               "performance grouping, not the 13, 46 or 47 grouping. "
               "Acceptance question 9: context for DP-532, which reads the suppression state from DP-145 and does not list "
               "this product upstream (one-way); this product supplies the exception worklist behind it (Open Return "
               "Exceptions, Household Groups Affected by Open Exceptions). "
               "Tailoring lever: exception service level. Reference default: exceptions resolved within 5 business days of "
               "Exception Date, before the month-end Final at business day 7. Tailoring lever: restatement notification "
               "(32 SME 11). Reference default: clients notified of any restated personal return already shown on a "
               "statement or report, through 13 communications. Tailoring lever: personal-return scope. Reference default: "
               "the account types DP-145 computes personal returns for (brokerage, fund-only from 29, managed advisory, "
               "participant from 16 balances, fiduciary where TR is offered). "
               "Taxonomy gap: 32 Client Return Exception has no resolved date or owner, so time to resolve cannot be "
               "measured and only open age is published. Taxonomy gap: no attribute records that a client was notified of "
               "a restated personal return (32 has the flag; 13 Shareholder Communication has no link to the 32 version), "
               "so notification completion cannot be tested. Taxonomy gap: 32 Personal Rate of Return has no restatement "
               "date; restatements are dated by the period they restate. "
               "Drafting assumptions: Client Return Exception Type values Missing Price, Unposted Corporate Action, Large "
               "External Flow and Conversion Gap; Return Exception Status values Open and Resolved; Personal Return Status values Final and "
               "Restated; Return Subject Type value Account; Performance Group Status Active; Account Status Open and "
               "Closed; the business-line scope, the 5-business-day threshold and aging buckets. "
               "Decisions: CW-011, CW-129, CW-251, CD-217, CD-320. "
               "WP1 new (CW-251): first specification; inputs as in the INV+IOP candidate, adding 32 Household Performance "
               "Group and Member (household suppression) and 32 Performance Return (subject of institutional restatements); "
               "DP-240 added and DP-143 dropped upstream. Fix pass (C-6 review, lead ruling 2): DP-145's control "
               "measures are read, not restated: 'Accounts Suppressed by Exceptions', 'Household Groups Suppressed' and "
               "'Profile Suppressions by Reason' are replaced by Suppressed Personal Returns (from DP-145) and the "
               "worklist Household Groups Affected by Open Exceptions; 'Restated Returns Flagged for Notification' becomes "
               "Restated Personal Returns Requiring Notification (from DP-145); 'Institutional Account Restatements' "
               "becomes Material Restatements (from DP-145), Institutional Accounts; the profile coverage scope follows "
               "DP-145's subject account types. No reader keys on the dropped names."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-515": dict(
        definition=("The governance view of the firm's shared and local code lists: every registered list with its owner, "
                    "steward, registration status and current version, the domains and attributes that consume it, the "
                    "taxonomy attributes that name a list not yet registered, retired codes without a replacement, source "
                    "system mappings that point at inactive codes, open change requests and their impact assessments, the "
                    "systems subscribing to reference data, and the completeness of fund dealing and business calendars. "
                    "Reference data stewards see which consumers a list change will touch and which mappings and calendars "
                    "are stale. Values themselves are published by DP-013; this product reports versions, use and impact. "
                    "It owns no certified metric family."),
        business_questions=[
            "Which code lists lack an owner, a steward or a current version, and which taxonomy attributes name a code list that is not registered?",
            "Which domains, attributes and subscribing systems will a change to a given code list touch?",
            "Which retired codes have no replacement, and which source system mappings still point at inactive codes or are still awaiting approval?",
            "Which change requests are undecided or were approved without an impact assessment?",
            "Which fund dealing calendars lack a base or market closure calendar, and which business calendars have no dates loaded for next year?",
        ],
        grain=("Code list x code list version, with code values, consumers, mappings, change requests and subscriptions as "
               "companion facts; plus calendar x year for calendar completeness; daily snapshots, SCD type 2 on lists and "
               "versions"),
        dimensions=["Code list and class", "Code list version", "Owning business domain", "Registration status",
                    "Consuming domain and usage type", "Source system (DP-211)", "Mapping type and status", "Change type and decision",
                    "Distribution method", "Calendar and calendar type (DP-013)", "Taxonomy release (DP-100)", "As-of date (DP-013)"],
        measures=[
            ("Registered Code Lists",
             "Count of Code List ID by Registration Status, Code List Class, Owning Business Domain and Extensibility.",
             _u("09", "Code List", "Code List ID", "Registration Status", "Code List Class", "Owning Business Domain", "Extensibility")),
            ("Code Lists Without Owner or Steward",
             "Code lists with Registration Status in (Qualified, Standard, Preferred Standard) whose Data Owner or Data Steward is blank, by Owning Business Domain.",
             _u("09", "Code List", "Registration Status", "Data Owner", "Data Steward", "Owning Business Domain")),
            ("Code Lists Without Current Version",
             "Code lists with Registration Status not in (Superseded, Retired) whose Current Version is blank or names no Code List Version ID with Version Effective From on or before the as-of date.",
             _u("09", "Code List", "Registration Status", "Current Version")
             + _u("09", "Code List Version", "Code List Version ID", "Version Effective From")),
            ("Code List Consumers",
             "Count of Code List Consumer rows by Consuming Domain and Usage Type for each code list; the impact base a change request is assessed against (Validate and Store consumers are the ones a value change breaks).",
             _u("09", "Code List Consumer", "Consuming Domain", "Consuming Attribute", "Usage Type")),
            ("Taxonomy Attributes on Unregistered Code Lists",
             "Count of 21 Taxonomy Element Registration rows of the latest Published release (Registering Release with Taxonomy Release Status Published) whose Element Code List is populated and resolves to no Code List, or to one with Registration Status in (Candidate, Recorded, Superseded, Retired), by Mastered In Data Domain (from DP-100).",
             _u("21", "Taxonomy Element Registration", "Registered Taxonomy Element", "Registering Release", "Element Code List",
                "Mastered In Data Domain")
             + _u("21", "Taxonomy Release", "Taxonomy Release ID", "Taxonomy Release Status")
             + _u("09", "Code List", "Code List ID", "Registration Status")),
            ("Retired Codes Without Replacement",
             "Count of Code Value rows of current versions with Code Value Status in (Deprecated, Retired) and Replaced By Code blank, by code list.",
             _u("09", "Code Value", "Code", "Code Value Status", "Replaced By Code")),
            ("Mappings to Inactive Codes",
             "Count of Code Mapping rows with Mapping Status = Approved whose Target Code is a Code Value of the Target Code List's current version with Code Value Status other than Active, or is not a code of that version, by Source System.",
             _u("09", "Code Mapping", "Code Mapping ID", "Mapping Status", "Target Code List", "Target Code", "Source System")
             + _u("09", "Code Value", "Code", "Code Value Status")
             + _u("09", "Code List", "Current Version")),
            ("Mappings Awaiting Approval",
             "Count of Code Mapping rows with Mapping Status = Proposed, by Source System, Target Code List and Mapping Type; with the share of all non-retired mappings of the source system.",
             _u("09", "Code Mapping", "Mapping Status", "Source System", "Target Code List", "Mapping Type", "Source Value")),
            ("Open Change Requests",
             "Count of Code List Change Request rows with Change Decision blank or Deferred, by Change Type, with the count lacking an Impact Assessment.",
             _u("09", "Code List Change Request", "Change Request Reference", "Change Type", "Change Decision", "Impact Assessment")),
            ("Changes Approved Without Impact Assessment",
             "Count of change requests with Change Decision in (Approved, Approved with Changes) and Change Type in (Deprecate Value, Merge Values, Split Value, Retire List) whose Impact Assessment is blank.",
             _u("09", "Code List Change Request", "Change Decision", "Change Type", "Impact Assessment")),
            ("Subscriptions by Distribution Method",
             "Count of Reference Data Subscription rows by Reference Data Set and Distribution Method.",
             _u("09", "Reference Data Subscription", "Reference Data Set", "Subscribing System", "Distribution Method")),
            ("Subscriptions to Decommissioned Systems",
             "Reference Data Subscription rows whose Subscribing System resolves to a 41 Application (from DP-211) with Application Status in (Sunsetting, Decommissioned) or a Decommission Date before the as-of date.",
             _u("09", "Reference Data Subscription", "Subscribing System")
             + _u("41", "Application", "Application ID", "Application Status", "Decommission Date")),
            ("Open Harmonization Candidates",
             "Count of code lists with Harmonization Candidate populated and Registration Status not in (Superseded, Retired), by Harmonization Candidate (the shared concept a list is to merge into).",
             _u("09", "Code List", "Harmonization Candidate", "Registration Status")),
            ("Dealing Calendars Without Closure Calendars",
             "Count of Dealing Calendar Rule rows (calendars of Calendar Type Fund Dealing) with Base Business Calendar blank or Market Closure Calendars blank, or whose Base Business Calendar resolves to no Calendar ID, by Dealing Day Pattern.",
             _u("09", "Dealing Calendar Rule", "Dealing Calendar ID", "Base Business Calendar", "Market Closure Calendars",
                "Dealing Day Pattern")
             + _u("09", "Calendar", "Calendar ID", "Calendar Type")),
            ("Calendars Without Next-Year Dates",
             "From October 1: count of calendars with Calendar Type in (Public Holiday, Settlement (CSD / Payment System), Exchange, Bond Market, Fund Dealing) that have no Calendar Date rows dated in the next calendar year, or no row with Day Type = Holiday in it, by Calendar Type and Calendar Country.",
             _u("09", "Calendar", "Calendar ID", "Calendar Type", "Calendar Country", "Calendar Source")
             + _u("09", "Calendar Date", "Calendar Date", "Day Type")),
        ],
        inputs=[
            ("09", "Code List", ["Code List ID", "Code List Name", "Code List Class", "Owning Business Domain", "Data Owner",
                                 "Data Steward", "Registration Status", "Current Version", "Harmonization Candidate",
                                 "Extensibility"]),
            ("09", "Code List Version", ["Code List Version ID", "Version Effective From", "Change Summary"]),
            ("09", "Code List Consumer", ["Consuming Domain", "Consuming Attribute", "Usage Type"]),
            ("09", "Code Value", ["Code", "Code Label", "Code Value Status", "Replaced By Code"]),
            ("09", "Code Mapping", ["Code Mapping ID", "Source System", "Source Value", "Target Code List", "Target Code",
                                    "Mapping Type", "Mapping Status"]),
            ("09", "Code List Change Request", ["Change Request Reference", "Change Type", "Impact Assessment", "Change Decision"]),
            ("09", "Reference Data Subscription", ["Reference Data Set", "Subscribing System", "Distribution Method"]),
            ("09", "Dealing Calendar Rule", ["Dealing Calendar ID", "Base Business Calendar", "Market Closure Calendars",
                                             "Dealing Day Pattern"]),
            ("09", "Calendar", ["Calendar ID", "Calendar Name", "Calendar Type", "Calendar Country", "Calendar Source"]),
            ("09", "Calendar Date", ["Calendar Date", "Day Type"]),
            ("21", "Taxonomy Element Registration", ["Registered Taxonomy Element", "Registering Release", "Element Code List",
                                                     "Mastered In Data Domain"]),
            ("21", "Taxonomy Release", ["Taxonomy Release ID", "Taxonomy Release Status"]),
            ("41", "Application", ["Application ID", "Application Status", "Decommission Date"]),
        ],
        upstream=["DP-013", "DP-100", "DP-101", "DP-211"],
        refresh="Daily",
        timeliness="By 7am ET each business day on the prior day's registry, mapping and calendar changes",
        history="Daily snapshots kept 3 years; code list versions, values, mappings and change requests kept indefinitely (SCD type 2)",
        classification="Internal",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Target Code List and Element Code List resolves to a registered Code List ID, every Source System and Subscribing System to a DP-211 application, and every Base Business Calendar and Market Closure Calendar to a DP-013 Calendar ID.",
            "Code List Version Effective From dates of one list are distinct and increasing, at most one version per list is current on any date, and one Source System x Source Value x Target Code List has at most one Approved mapping.",
            "The Code Value rows of each current version equal the values DP-013 publishes for that list on the same date (count and codes), and Current Version names the latest version effective on the as-of date.",
            "Data Owner, Registration Status and Owning Business Domain are populated on every list, Code Value Status on every value, and Day Type on every Calendar Date.",
            "The product publishes registry metadata only: Data Owner and Data Steward are role or team names, and no personal data is read or published.",
            "The daily snapshot is complete by 7am ET; a code list change takes effect only from its Version Effective From date, and past snapshots are never changed.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family). "
               "PII tier: none. "
               "Boundaries: code values, calendars, currencies and legal entities are published by DP-013 (09 foundational) "
               "and read, never remastered; the taxonomy registry and ownership are DP-100's and the enterprise catalog "
               "DP-101's; applications are DP-211's. DP-075 Distribution Metadata & Lineage Catalog stays live by the WP0 "
               "ruling until DP-101 absorbs its lineage; this product takes the code-list version and subscription view the "
               "DIS+FDN brief assigned it from DP-075 (CW-247) without listing DP-075 upstream, so DP-075's retirement needs "
               "no change here. "
               "Tailoring lever: code list registry scope. Reference default: every shared list and every local list with "
               "Validate and Store consumers is registered under ISO/IEC 11179 statuses. Tailoring lever: calendar loading. "
               "Reference default: next year's dates loaded by October 1 for public holiday, settlement, exchange, bond "
               "market and fund dealing calendars. "
               "Taxonomy gap: 09 Code List Version, Code List Consumer and Code Value carry no reference to their Code List "
               "(and Code Value none to its Code List Version) in the catalog, so the joins are implicit in the grain. "
               "Taxonomy gap: 09 Calendar Date has no Calendar reference attribute; the calendar is the parent of the row. "
               "Taxonomy gap: 09 Code List Change Request has no reference to the Code List it changes or a request date, "
               "so open requests cannot be aged or attributed to a list. "
               "Drafting assumptions: Registration Status values (ISO/IEC 11179) Candidate, Recorded, Qualified, Standard, "
               "Preferred Standard, Superseded, Retired; Code Value Status values Active, Deprecated, Retired; Mapping "
               "Status Proposed and Approved; Change Decision values; Application Status Sunsetting and Decommissioned; "
               "Taxonomy Release Status Published; the October 1 deadline. "
               "Decisions: CW-247, CD-300, CD-301. "
               "WP1 new (CW-247): first specification; inputs as in the DIS+FDN candidate, adding 09 Calendar and Calendar "
               "Date (calendar completeness beside the Dealing Calendar Rule), 21 Taxonomy Element Registration and "
               "Taxonomy Release (lists named by the taxonomy, from DP-100) and 41 Application (subscriber status, DP-211); "
               "DP-211 added upstream."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-516": dict(
        definition=("The completeness of the instrument record for what clients can trade on the brokerage platform: listed "
                    "option series with their OCC terms and symbols, brokered CDs with their FDIC flag, municipal bonds and "
                    "529 portfolios with their municipal terms, the CUSIP of every available instrument, fractional and "
                    "extended-hours eligibility flags against the 01 tradable universe rules, set-up requests that block a "
                    "client order, and, with backlog DP-543 folded in, the client-held instruments that have no approved "
                    "price at the client reporting snapshot. Brokerage and platform teams see which instruments cannot be "
                    "offered, traded or valued and why. The instrument is published by DP-097; this product reports coverage "
                    "and conforms nothing (CW-249, CD-300). It owns no certified metric family."),
        business_questions=[
            "Which instruments available on the platform are not active, or lack the terms their instrument type needs (option series, brokered CD, municipal bond, 529 portfolio)?",
            "Which available instruments have no active CUSIP, and which listed options have no OCC option symbol?",
            "Which instruments are flagged fractional or extended-hours eligible without an active tradable universe rule behind the flag?",
            "Which instrument set-up requests are past their required time or were rejected, and how long does set-up take?",
            "Which instruments held in client brokerage accounts have no approved price at the client reporting snapshot, or are no longer active?",
        ],
        grain=("Instrument x as-of date for platform-available and client-held instruments, with type-specific term "
               "completeness flags, identifier coverage and eligibility rule checks; companion fact instrument set-up "
               "request; daily snapshots"),
        dimensions=["Instrument and instrument type (DP-097)", "Asset class", "Instrument status",
                    "Platform availability status and transaction fee category (DP-004)",
                    "Tradable universe rule and rule type (DP-004)", "Identifier scheme", "Setup request type and status",
                    "Requesting function", "Pricing point (DP-143)", "As-of date (DP-013)"],
        measures=[
            ("Client-Tradable Instruments",
             "Count of distinct instruments with a Platform Product Availability row effective on the as-of date (latest Availability Effective From on or before it) with Platform Availability Status in (Available, Hold and Sell Only), third-party instruments by Available Third-Party Instrument and own share classes by the 17 Instrument whose Own Share Class is the Available Share Class, by Instrument Type and Transaction Fee Category.",
             _u("01", "Platform Product Availability", "Platform Availability ID", "Available Share Class",
                "Available Third-Party Instrument", "Platform Availability Status", "Transaction Fee Category",
                "Availability Effective From")
             + _u("17", "Instrument", "Instrument ID", "Instrument Type", "Own Share Class")),
            ("Available Instruments Not Active",
             "Client-Tradable Instruments whose Platform Availability Status = Available and Instrument Status is other than Active (Pending Setup, Matured, Called / Redeemed, Expired, Inactive), by Instrument Status.",
             _u("17", "Instrument", "Instrument Status") + ["Client-Tradable Instruments"]),
            ("Option Series Terms Completeness %",
             "Client-Tradable Instruments of Instrument Type = Listed Option with Contract Multiplier, Expiry Date, Option Right, Strike Price, Settlement Method and Option Expiration Type populated and an Instrument Identifier of scheme OCC Option Symbol (OSI) with Instrument Identifier Status Active / all client-tradable listed options; Adjusted Option Indicator = Y series are shown separately.",
             _u("17", "Listed Derivative Contract Terms", "Contract Multiplier", "Expiry Date", "Option Right", "Strike Price",
                "Settlement Method", "Option Expiration Type", "Adjusted Option Indicator")
             + _u("17", "Instrument Identifier", "Identified Instrument", "Instrument Identifier Scheme", "Instrument Identifier Status")
             + _u("17", "Instrument", "Instrument Type")
             + ["Client-Tradable Instruments"]),
            ("Expired Option Series Still Available",
             "Count of listed option instruments with Expiry Date before the as-of date whose Platform Availability Status is still Available.",
             _u("17", "Listed Derivative Contract Terms", "Expiry Date")
             + _u("01", "Platform Product Availability", "Platform Availability Status")),
            ("Municipal Bond Terms Completeness %",
             "Client-Tradable Instruments of Instrument Type = Municipal Bond with Municipal Issuer State, Municipal Security Type, AMT Subject Indicator, Tax-Exempt Indicator and Maturity Date populated and an active Instrument Identifier of scheme CUSIP or MSRB EMMA Security ID / all client-tradable municipal bonds.",
             _u("17", "Municipal Security Terms", "Municipal Issuer State", "Municipal Security Type", "AMT Subject Indicator")
             + _u("17", "Debt Terms", "Tax-Exempt Indicator", "Maturity Date")
             + _u("17", "Instrument Identifier", "Instrument Identifier Scheme", "Instrument Identifier Status")
             + ["Client-Tradable Instruments"]),
            ("529 Portfolio Terms Completeness %",
             "Client-Tradable Instruments of Instrument Type = Municipal Fund Security with Municipal Fund Security Type, Plan Sponsoring State, Program Manager and Plan Portfolio Allocation Type populated (Target Enrollment Year as well for age-based portfolios) / all client-tradable municipal fund securities.",
             _u("17", "Municipal Fund Security Terms", "Municipal Fund Security Type", "Plan Sponsoring State", "Program Manager",
                "Plan Portfolio Allocation Type", "Target Enrollment Year")
             + ["Client-Tradable Instruments"]),
            ("Brokered CD Terms Completeness %",
             "Client-Tradable Instruments of Instrument Type = Certificate of Deposit with FDIC Insured Indicator, Maturity Date, Coupon Type, Coupon Rate, Minimum Denomination and Callable Indicator populated / all client-tradable CDs.",
             _u("17", "Debt Terms", "FDIC Insured Indicator", "Maturity Date", "Coupon Type", "Coupon Rate", "Minimum Denomination",
                "Callable Indicator")
             + ["Client-Tradable Instruments"]),
            ("Available Instruments Without Active CUSIP",
             "Client-Tradable Instruments other than listed options with no Instrument Identifier of scheme CUSIP with Instrument Identifier Status Active and Identifier Effective From <= as-of < Identifier Effective To (or open), by Instrument Type.",
             _u("17", "Instrument Identifier", "Identified Instrument", "Instrument Identifier Scheme", "Instrument Identifier Value",
                "Instrument Identifier Status", "Identifier Effective From", "Identifier Effective To")
             + ["Client-Tradable Instruments"]),
            ("Fractional Eligibility Without Rule",
             "Count of instruments with Fractional Trading Eligible Indicator = Y whose Fractional Trading Eligibility Rule is blank or resolves to a Tradable Universe Policy Rule with Universe Rule Type other than Fractional Eligibility, Rule Status other than Active, or Rule Effective From / To not covering the as-of date.",
             _u("17", "Instrument", "Fractional Trading Eligible Indicator", "Fractional Trading Eligibility Rule")
             + _u("01", "Tradable Universe Policy Rule", "Policy Rule ID", "Universe Rule Type", "Rule Status", "Rule Effective From",
                  "Rule Effective To")),
            ("Extended-Hours Eligibility Without Rule",
             "Count of instruments with Extended-Hours Eligible Indicator = Y whose Extended-Hours Eligibility Rule is blank or resolves to a rule with Universe Rule Type other than Extended-Hours Eligibility, Rule Status other than Active, or an effective period not covering the as-of date.",
             _u("17", "Instrument", "Extended-Hours Eligible Indicator", "Extended-Hours Eligibility Rule")
             + _u("01", "Tradable Universe Policy Rule", "Policy Rule ID", "Universe Rule Type", "Rule Status", "Rule Effective From",
                  "Rule Effective To")),
            ("Setup Requests Past Required Time",
             "Count of Instrument Setup Request rows with Setup Request Status not in (Resolved / Completed, Closed, Rejected, Canceled) and Required By Timestamp before the as-of timestamp, by Setup Request Type, Requested Instrument Type and Requesting Function (brokerage requests block a client order until the instrument is active).",
             _u("17", "Instrument Setup Request", "Setup Request ID", "Setup Request Status", "Required By Timestamp", "Setup Request Type",
                "Requested Instrument Type", "Requesting Function")),
            ("Setup Request Turnaround Hours",
             "Completion Timestamp - Request Timestamp in hours for requests completed in the period with a Resulting Instrument, median and 90th percentile by Setup Request Type and Requested Instrument Type.",
             _u("17", "Instrument Setup Request", "Request Timestamp", "Completion Timestamp", "Resulting Instrument", "Setup Request Type",
                "Requested Instrument Type")),
            ("Rejected Setup Requests",
             "Count of set-up requests in the period with Setup Request Status = Rejected or Setup Approval Status = Rejected, by Requested Instrument Type and Rejection Reason.",
             _u("17", "Instrument Setup Request", "Setup Request Status", "Setup Approval Status", "Rejection Reason",
                "Requested Instrument Type")),
            ("Client-Held Instruments Without Approved Price",
             "From backlog DP-543: count of distinct Held Instrument of Client Holdings with Client Holding View = End of Day on Client Holding Date = the as-of date (DP-300, counted by instrument only) that have no Approved Price (Priced Instrument) with Approved Pricing Point = a Pricing Point of Pricing Point Purpose Client Reporting Snapshot, Price Date = the as-of date and Price Approval Status = Approved (DP-143), by Instrument Type.",
             _u("49", "Client Holding", "Client Holding ID", "Held Instrument", "Client Holding Date", "Client Holding View")
             + _u("22", "Approved Price", "Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date",
                  "Price Approval Status")
             + _u("22", "Pricing Point", "Pricing Point Code", "Pricing Point Purpose")
             + _u("17", "Instrument", "Instrument Type")),
            ("Client-Held Instruments Not Active",
             "Count of distinct Held Instrument of end-of-day Client Holdings on the as-of date whose Instrument Status is Matured, Called / Redeemed, Expired or Inactive (a corporate action or redemption not yet processed in the brokerage book), by Instrument Status.",
             _u("49", "Client Holding", "Held Instrument", "Client Holding View", "Client Holding Date")
             + _u("17", "Instrument", "Instrument Status")),
        ],
        inputs=[
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Instrument Status", "Own Share Class",
                                  "Fractional Trading Eligible Indicator", "Fractional Trading Eligibility Rule",
                                  "Extended-Hours Eligible Indicator", "Extended-Hours Eligibility Rule"]),
            ("17", "Municipal Security Terms", ["Municipal Issuer State", "Municipal Security Type", "AMT Subject Indicator"]),
            ("17", "Municipal Fund Security Terms", ["Municipal Fund Security Type", "Plan Sponsoring State", "Program Manager",
                                                     "Plan Portfolio Allocation Type", "Target Enrollment Year"]),
            ("17", "Listed Derivative Contract Terms", ["Contract Multiplier", "Expiry Date", "Option Right", "Strike Price",
                                                        "Settlement Method", "Option Expiration Type",
                                                        "Adjusted Option Indicator"]),
            ("17", "Debt Terms", ["Coupon Type", "Coupon Rate", "Maturity Date", "Minimum Denomination", "Callable Indicator",
                                  "Tax-Exempt Indicator", "FDIC Insured Indicator"]),
            ("17", "Instrument Identifier", ["Identified Instrument", "Instrument Identifier Scheme", "Instrument Identifier Value",
                                             "Primary Identifier Indicator", "Instrument Identifier Status",
                                             "Identifier Effective From", "Identifier Effective To"]),
            ("17", "Instrument Setup Request", ["Setup Request ID", "Setup Request Type", "Requested Instrument Type",
                                                "Requesting Function", "Request Timestamp", "Required By Timestamp",
                                                "Setup Request Status", "Setup Approval Status", "Resulting Instrument",
                                                "Completion Timestamp", "Rejection Reason"]),
            ("01", "Tradable Universe Policy Rule", ["Policy Rule ID", "Rule Name", "Universe Rule Type", "Rule Criteria",
                                                     "Rule Effective From", "Rule Effective To", "Rule Status"]),
            ("01", "Platform Product Availability", ["Platform Availability ID", "Available Share Class",
                                                     "Available Third-Party Instrument", "Platform Availability Status",
                                                     "Transaction Fee Category", "Availability Effective From"]),
            ("49", "Client Holding", ["Client Holding ID", "Held Instrument", "Client Holding Date", "Client Holding View"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Approved Pricing Point", "Price Date",
                                      "Price Approval Status"]),
            ("22", "Pricing Point", ["Pricing Point Code", "Pricing Point Purpose"]),
        ],
        upstream=["DP-097", "DP-004", "DP-383", "DP-300", "DP-143", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET each business day, before the market opens, on the prior evening's security master and holdings",
        history="Daily snapshots kept 3 years; set-up requests kept 7 years (SEC Rule 17a-4 for records that support order handling)",
        classification="Internal",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard", "Event stream"],
        dq_rules=[
            "Every Available Third-Party Instrument, Identified Instrument, Resulting Instrument, Held Instrument and Priced Instrument resolves to a DP-097 instrument, every Available Share Class to a DP-004 share class, every eligibility rule to a DP-004 Tradable Universe Policy Rule and every Approved Pricing Point to a DP-143 pricing point.",
            "Instrument Identifier rows of one instrument and scheme do not overlap in effect, at most one is the Primary Identifier Indicator = Y row on any date, Tradable Universe Policy Rule Effective To is on or after Effective From, and Completion Timestamp is on or after Request Timestamp.",
            "The count of distinct end-of-day client-held instruments equals the count of distinct Held Instrument in DP-300 for the same date, and every Available Third-Party Instrument counted in Client-Tradable Instruments resolves to an instrument DP-097 publishes on the same date (instrument rows missing from the security master are counted as a break).",
            "Instrument Type and Instrument Status are populated on every instrument read, Platform Availability Status on every availability row, and Setup Request Status and Request Timestamp on every set-up request.",
            "Client Holding is read at instrument grain only: no Holding Account, quantity or value is read or published, so no client personal data leaves the product.",
            "The snapshot is complete by 6am ET each business day so that order capture sees the day's eligibility; a late snapshot is flagged to brokerage operations and the prior snapshot is not overwritten.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family). "
               "PII tier: none. pii = N: 49 Client Holding attributes are noted personal (account holdings); the product "
               "reads only Client Holding ID, Held Instrument, date and view to list distinct instruments and publishes no "
               "account, quantity or value (DQ5); Requested By and Approved By on set-up requests are not read; Platform Availability ID is flagged only because its note reads 'Object PII tier: No PII'. "
               "Boundaries: the instrument golden record and the W1 retail additions are published by DP-097 (CW-249; its "
               "spec change at WP1 is the 17 owner's); this product reports completeness and eligibility and conforms "
               "nothing (CD-300). Platform availability is 01 (DP-004, with the shelf view in DP-383); the due diligence "
               "verdict is 52 (DP-306). Approved prices are 22 (DP-143); price challenges and pricing control are DP-148's. "
               "Instrument set-up quality for the investment book stays DP-102's; this product covers the client trading "
               "universe. Issuers are not read, so the candidate's DP-098 upstream is dropped; DP-383 and DP-300 are added. "
               "Backlog DP-543 Client-Held Instrument Pricing Coverage folds in here (WP1_Scope.md section 5) as the two "
               "client-held measures; its staleness, evaluated-price share and validation-exception measures are not "
               "carried (DP-148 holds price validation). "
               "Acceptance question 5: context for DP-436 and DP-435 (readers named here; neither lists this product upstream, "
               "so the edge stays one-way), with the instrument eligibility dimension (fractional and "
               "extended-hours eligibility with the rule behind it) by which execution quality and order completeness are "
               "sliced. "
               "Tailoring lever: product range on the platform (options, municipal bonds, 529 plans, brokered CDs). "
               "Reference default: all offered; a firm without options or municipal trading drops those completeness "
               "measures. Tailoring lever: identifier standard. Reference default: CUSIP for every non-option instrument and "
               "the OCC option symbol for listed options. "
               "Taxonomy gap: 17 Instrument Setup Request has no reference to the client order it blocks (48), so blocked "
               "orders are inferred from Requesting Function. Taxonomy gap: the 17 type-specific attribute groups (Debt "
               "Terms, Municipal Security Terms, Municipal Fund Security Terms, Listed Derivative Contract Terms) carry no "
               "instrument key of their own; the instrument is their parent. "
               "Drafting assumptions: Platform Availability Status values Available and Hold and Sell Only; Instrument Type "
               "values Listed Option, Municipal Bond, Municipal Fund Security and Certificate of Deposit; Instrument Status "
               "values; Instrument Identifier Scheme values CUSIP, OCC Option Symbol (OSI) and MSRB EMMA Security ID; "
               "Universe Rule Type values Fractional Eligibility and Extended-Hours Eligibility; Rule Status Active; shared "
               "Case Status closed values; Pricing Point Purpose Client Reporting Snapshot; the 6am deadline. "
               "Decisions: CW-037, CW-249, CW-917, CD-300. "
               "WP1 new (CW-249): first specification; inputs as in the DIS+FDN candidate, adding 17 Instrument Identifier "
               "(CUSIP and OCC symbol coverage) and, from backlog DP-543, 49 Client Holding and 22 Approved Price and "
               "Pricing Point."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-518": dict(
        definition=("The register of personal data tiers and restricted views across the data product catalog: for every "
                    "registered data product, the personal data categories and CD-344 tier its inputs carry (special category, "
                    "PII - financial, employee compensation, identity), the classification it is published under, the data "
                    "contracts that release it to named consumers, and the products that read special-category data outside "
                    "the named restricted views (DP-322, DP-403, DP-352, and DP-456 for hold rows) or member-level household and advisor economics "
                    "outside the restricted views of DP-498, DP-499 and DP-503. Privacy and the data office prove that vulnerability, "
                    "household economics and pay data reach only entitled users (CW-213, CW-243). It reads catalog and "
                    "classification metadata only and owns no certified metric family."),
        business_questions=[
            "Which data products read special-category elements, and does any product other than DP-322, DP-403, DP-352 and DP-456 (hold rows) read them other than as a filter?",
            "Is every product that reads special-category or member-level economics data classified Restricted - Personal Data, Confidential - Personal Data or Confidential - Compensation and released only through an active data contract to a named consumer?",
            "Which products read personal data but declare that they publish none, or are classified below Confidential - Personal Data?",
            "Which products read member-level allocation results for households, accounts, clients or advisors outside the registered restricted views of DP-498 and DP-499?",
            "Which input elements of registered products have no personal data classification, and which personal-data CDEs must a masking rule cover?",
        ],
        grain=("Data product x input taxonomy element x as-of date, with the element's effective classification assignment and "
               "the product's active data contracts as companion facts; daily snapshots, classification and contract history "
               "kept by effective period"),
        dimensions=["Data product, tier and status (DP-101)", "Owning data domain", "Data product classification",
                    "Taxonomy element and data domain (DP-100)", "Personal data category", "Special category indicator",
                    "CPRA sensitive indicator", "Data contract and consumer org unit (DP-101; org unit DP-013)",
                    "Allocation target dimension (DP-480)", "CDE scope and regulatory driver (DP-100)", "As-of date (DP-013)"],
        measures=[
            ("Registered Data Products by Classification",
             "Count of Data Product ID with Data Product Status in (Specified, In Build, Published), by Data Product Classification, Data Product Contains Personal Data, Data Product Tier and Data Product Owning Data Domain.",
             _u("21", "Data Product", "Data Product ID", "Data Product Status", "Data Product Classification",
                "Data Product Contains Personal Data", "Data Product Tier", "Data Product Owning Data Domain")),
            ("Products Reading Special-Category Elements",
             "Count of data products with a Data Product Input (Input Data Product) whose Input Taxonomy Element has a Data Classification Assignment (Classified Taxonomy Element) effective on the as-of date with Special Category Data Indicator = Y, with the elements read and their Input Role.",
             _u("21", "Data Product Input", "Input Data Product", "Input Taxonomy Element", "Input Role")
             + _u("21", "Data Classification Assignment", "Classified Taxonomy Element", "Special Category Data Indicator",
                  "Classification Effective From", "Classification Effective To")),
            ("Special-Category Readers Outside Named Views",
             "Control, zero expected: Products Reading Special-Category Elements whose Data Product ID is not one of the named exceptions, DP-322 (Client Protection Flags & Senior Investor Register), DP-403 (Rule 2165 case), DP-352 (trust special-needs purpose) and DP-456 (its read of the special-category hold rows, F3 ruling), counting only reads whose Input Role is other than Filter / Rule; filter-only reads (by ruling DP-302, DP-307 and DP-583, which use special values as extraction filters and never publish them) are excluded (CW-213, CD-344). Every other product reads only the 'Protection Flag Present' indicator from DP-322.",
             _u("21", "Data Product", "Data Product ID") + _u("21", "Data Product Input", "Input Role")
             + ["Products Reading Special-Category Elements"]),
            ("Special-Category Products Not Restricted",
             "Products Reading Special-Category Elements with at least one read whose Input Role is other than Filter / Rule and whose Data Product Classification is other than Restricted - Personal Data (filter-only readers are excluded, as in the control above).",
             _u("21", "Data Product", "Data Product Classification") + _u("21", "Data Product Input", "Input Role")
             + ["Products Reading Special-Category Elements"]),
            ("Personal-Data Readers Declaring No Personal Data",
             "Count of products with Data Product Contains Personal Data = N that have at least one input element whose effective Data Classification Assignment of Classification Scheme = Personal Data Category has Assigned Personal Data Categories other than No Personal Data; each needs the publication justification its notes give (aggregates only, keys only).",
             _u("21", "Data Product", "Data Product Contains Personal Data")
             + _u("21", "Data Classification Assignment", "Classification Scheme", "Assigned Personal Data Categories")
             + _u("21", "Data Product Input", "Input Data Product", "Input Taxonomy Element")),
            ("Personal-Data Products Classified Below Confidential",
             "Count of products with Data Product Contains Personal Data = Y and Data Product Classification in (Public, Internal, Confidential), by Data Product Owning Data Domain.",
             _u("21", "Data Product", "Data Product Contains Personal Data", "Data Product Classification",
                "Data Product Owning Data Domain")),
            ("Restricted Products Without Active Data Contract",
             "Count of products with Data Product Classification in (Restricted - Personal Data, Confidential - Personal Data, Confidential - Compensation), and DP-498, DP-499 and DP-503 by Data Product ID whatever their classification, with Data Product Status Published that have no Data Contract (Contracted Data Product) with Data Contract Status = Active and Data Contract Effective From <= as-of < Data Contract Effective To (or open) naming a Consumer Org Unit: the restricted view is not registered.",
             _u("21", "Data Product", "Data Product Classification", "Data Product Status")
             + _u("21", "Data Contract", "Data Contract ID", "Contracted Data Product", "Data Contract Status", "Consumer Org Unit",
                  "Data Contract Effective From", "Data Contract Effective To")),
            ("Restricted Data Released Externally",
             "Count of active Data Contracts of products classified Restricted - Personal Data, Confidential - Personal Data or Confidential - Compensation with Consumer External Party populated, by Contracted Data Product and Data Contract Version.",
             _u("21", "Data Contract", "Consumer External Party", "Data Contract Version", "Data Contract Status", "Contracted Data Product")
             + _u("21", "Data Product", "Data Product Classification")),
            ("Named Restricted Views Registered",
             "For each named restricted view of member-level economics: 'DP-498 Household Economics' (household cost and value rows), 'DP-499 Advisor Book' (advisor rows with allocated compensation cost), 'DP-499 Household Profitability' (household and account rows) and 'DP-503 Member-Level Allocation Read' (DP-503's restricted read of 10 Allocation Result members): Y where the product has at least one Data Contract (Contracted Data Product) with Data Contract Status = Active effective on the as-of date naming a Consumer Org Unit; the count of named views without one is zero expected.",
             _u("21", "Data Contract", "Contracted Data Product", "Data Contract Status", "Consumer Org Unit",
                "Data Contract Effective From", "Data Contract Effective To")
             + _u("21", "Data Product", "Data Product ID")),
            ("Member-Level Economics Rules",
             "Count of 10 Allocation Rules effective on the as-of date (Rule Effective From <= as-of < Rule Effective To or open) with Target Dimension in (Household, Account, Client, Advisor), by Target Dimension and Source Cost Pool (from DP-480): the allocations whose member-level results are PII - financial or employee compensation (CW-243).",
             _u("10", "Allocation Rule", "Allocation Rule ID", "Source Cost Pool", "Target Dimension", "Rule Effective From",
                "Rule Effective To")),
            ("Unregistered Readers of Member-Level Economics",
             "Control, zero expected while Member-Level Economics Rules is above zero: count of data products other than the registered readers DP-480 (the allocation chain), DP-498, DP-499 and DP-503 (intercompany charges, restricted view) with a Data Product Input whose Input Taxonomy Element is the 10 Allocation Result Target Dimension Member or Allocated Amount (Element Data Domain = 10, Element Object Name = Allocation Result), plus DP-498, DP-499 and DP-503 (tested by Data Product ID) if any has no Active Data Contract.",
             _u("21", "Data Product Input", "Input Data Product", "Input Taxonomy Element")
             + _u("21", "Taxonomy Element", "Taxonomy Element Key", "Element Data Domain", "Element Object Name",
                  "Element Attribute Name")
             + ["Member-Level Economics Rules", "Restricted Products Without Active Data Contract"]),
            ("Unclassified Input Elements",
             "Count of distinct Input Taxonomy Element of registered products with no Data Classification Assignment of Classification Scheme in (Information Classification, Personal Data Category) effective on the as-of date, by Element Data Domain, with the share of all input elements.",
             _u("21", "Data Product Input", "Input Taxonomy Element")
             + _u("21", "Data Classification Assignment", "Classification Scheme", "Classified Taxonomy Element",
                  "Assigned Information Classification")
             + _u("21", "Taxonomy Element", "Element Data Domain", "Taxonomy Element Status")),
            ("CPRA Sensitive Elements Read",
             "Count of data products reading at least one element whose effective assignment has CPRA Sensitive Personal Information Indicator = Y, with the elements read, by Data Product Classification.",
             _u("21", "Data Classification Assignment", "CPRA Sensitive Personal Information Indicator", "Classified Taxonomy Element")
             + _u("21", "Data Product Input", "Input Data Product", "Input Taxonomy Element")
             + _u("21", "Data Product", "Data Product Classification")),
            ("Personal-Data CDEs",
             "Count of Critical Data Elements effective on the as-of date (CDE Effective From / To) whose CDE Taxonomy Attribute has an effective assignment with Assigned Personal Data Categories other than No Personal Data, by CDE Scope and CDE Regulatory Driver: the CDEs a masking or restricted-view rule must name.",
             _u("21", "Critical Data Element", "CDE ID", "CDE Taxonomy Attribute", "CDE Scope", "CDE Regulatory Driver",
                "CDE Effective From", "CDE Effective To")
             + _u("21", "Data Classification Assignment", "Assigned Personal Data Categories")),
        ],
        inputs=[
            ("21", "Data Product", ["Data Product ID", "Data Product Name", "Data Product Tier", "Data Product Owning Data Domain",
                                    "Data Product Owner Role", "Upstream Data Products", "Data Product Classification",
                                    "Data Product Contains Personal Data", "Data Product Status"]),
            ("21", "Data Product Input", ["Input Data Product", "Input Taxonomy Element", "Input Role"]),
            ("21", "Data Contract", ["Data Contract ID", "Contracted Data Product", "Consumer Org Unit", "Consumer External Party",
                                     "Data Contract Version", "Data Contract Status", "Data Contract Effective From",
                                     "Data Contract Effective To"]),
            ("21", "Data Classification Assignment", ["Classification Scheme", "Classified Taxonomy Element",
                                                      "Assigned Information Classification", "Assigned Personal Data Categories",
                                                      "Special Category Data Indicator",
                                                      "CPRA Sensitive Personal Information Indicator",
                                                      "Classification Effective From", "Classification Effective To"]),
            ("21", "Critical Data Element", ["CDE ID", "CDE Taxonomy Attribute", "CDE Scope", "CDE Regulatory Driver",
                                             "CDE Effective From", "CDE Effective To"]),
            ("21", "Taxonomy Element", ["Taxonomy Element Key", "Element Data Domain", "Element Object Name",
                                        "Element Attribute Name", "Taxonomy Element Status"]),
            ("10", "Allocation Rule", ["Allocation Rule ID", "Source Cost Pool", "Target Dimension", "Rule Effective From",
                                       "Rule Effective To"]),
        ],
        upstream=["DP-100", "DP-101", "DP-480", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day on the prior day's catalog, classification and contract changes",
        history=("Daily snapshots kept 6 years as privacy program evidence (Regulation S-P safeguards and CPRA records); "
                 "classification assignments and data contracts kept by effective period indefinitely"),
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Input Data Product and Contracted Data Product resolves to a DP-101 Data Product ID that is registered in framework.PRODUCTS, every Input Taxonomy Element, Classified Taxonomy Element and CDE Taxonomy Attribute to a DP-100 Taxonomy Element Key, and every Consumer Org Unit to a DP-013 org unit.",
            "Data Classification Assignments of one Classified Taxonomy Element and Classification Scheme do not overlap in effect, Data Contract versions of one product and consumer do not overlap, and every Effective To is on or after its Effective From.",
            "Special-Category Readers Outside Named Views and Unregistered Readers of Member-Level Economics are zero on every snapshot, and Data Product Classification and Data Product Contains Personal Data equal the classification and pii values of the product's specification in the catalog build.",
            "Data Product Classification and Data Product Contains Personal Data are populated on every registered product, and Special Category Data Indicator and Assigned Personal Data Categories on every Personal Data Category assignment.",
            "The register publishes metadata only: no personal data values are read, Data Product Owner Role is a role name, and Consumer Org Unit and Consumer External Party are organization references.",
            "The snapshot is complete by 7am ET; a control result above zero opens a privacy issue the same day, and past snapshots are never changed.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family). "
               "PII tier: none (metadata only). "
               "Boundaries: the catalog, data contracts and lineage are DP-101's and the taxonomy, classification and CDE "
               "registry DP-100's; this product registers and tests the restricted-view rule over them and remasters "
               "nothing. The special-category register itself is DP-322's (CW-213; DP-403 and DP-352 are the narrower named "
               "exceptions); the member-level allocation chain is DP-480's, released at member grain only through the "
               "restricted views of DP-498 and DP-499 (CW-243; DP-480 notes name this product as their register). "
               "Enforcement of row-level entitlement is in the consuming platform; this product evidences it. The candidate's "
               "DP-517 retention view is in the backlog (stands alone). "
               "Acceptance question 7: context for DP-456, DP-322 and DP-403 (readers named here; none lists this product "
               "upstream, so the edge stays one-way): Special-Category Readers Outside Named Views and Special-Category "
               "Products Not Restricted evidence the restricted-view rule the answering product relies on. "
               "Tailoring lever: household economics visibility (10 SME 7). Reference default: restricted; advisor-facing "
               "household views register here as Data Contracts of DP-498 and DP-499 with the advisor org unit as consumer. "
               "Tailoring lever: classification scheme. Reference default: the 09 Information Classification list with the "
               "CD-344 tiers mapped to its qualifiers (special category to Restricted - Personal Data, compensation to "
               "Confidential - Compensation). "
               "Taxonomy gap: 21 has no object for a restricted view or its entitlement (who may see which rows); the "
               "restricted view is evidenced by an Active 21 Data Contract naming a Consumer Org Unit, and row-level "
               "entitlement rules are not recorded. Taxonomy gap: 21 Data Product Input has no attribute saying whether an "
               "input is published or used only as a filter beyond Input Role, so 'reads in detail' is approximated by "
               "Input Role other than Filter / Rule. Taxonomy gap: 21 Data Classification Assignment has no CD-344 tier "
               "attribute; the tier is derived from Special Category Data Indicator, Assigned Personal Data Categories and "
               "Assigned Information Classification. "
               "Drafting assumptions: Data Product Status values Specified, In Build and Published; Data Contract Status "
               "Active; Classification Scheme values Information Classification and Personal Data Category; Personal Data "
               "Category value No Personal Data; Input Role value Filter / Rule; Profitability Dimension values Household, "
               "Account, Client and Advisor. "
               "Decisions: CW-030, CW-213, CW-243, CD-344. "
               "WP1 new (CW-243): first specification; inputs as in the DIS+FDN candidate, adding 21 Taxonomy Element "
               "(element names for the economics test) and 10 Allocation Rule (member-level targets, read through DP-480); "
               "DP-480 and DP-013 added upstream. Fix pass (C-6 review, lead ruling 5): the outside-named-views control "
               "exempts DP-322, DP-403, DP-352 and DP-456's hold-row read and excludes filter-only reads (DP-302, DP-307, "
               "DP-583); the contract tests cover Restricted - Personal Data, Confidential - Personal Data and Confidential "
               "- Compensation, and DP-498 and DP-499 are tested by id. Coordinator addition: DP-503 is a registered reader of member-level 10 Allocation Result economics "
               "(restricted view), exempt from Unregistered Readers of Member-Level Economics and tested by id; the named "
               "views registered here are 'DP-498 Household Economics', 'DP-499 Advisor Book', 'DP-499 Household "
               "Profitability' and 'DP-503 Member-Level Allocation Read' (measure Named Restricted Views Registered). "
               "Taxonomy gap: 21 Data Contract has no view name attribute, so a named view is evidenced by an Active "
               "contract of its product, not by name. Drafting assumption: the exempt and filter-only "
               "product lists follow the F2, F3 and C-4 rulings and change only by ruling."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-044": dict(
        definition=("The data office's single control view of third-party data: every licensed dataset with its coverage, "
                    "delivery and key fields, the agreements and schedules that license it, who and which applications are "
                    "entitled to it (including brokerage clients entitled to real-time quotes and their professional or "
                    "non-professional status), whether each use is covered by a permitted use grant, declared usage, audits "
                    "and findings, invoices and cost allocation, the indexes the firm's funds and benchmarks rely on with "
                    "their license fees, and vendor service levels, assurance reports, renewals and exit obligations. It "
                    "controls license compliance, exchange reporting and vendor spend from one place. Re-scoped in place with "
                    "the scope of candidate DP-519 (the program lead's WP0 ruling). It owns no certified metric family."),
        business_questions=[
            "Who and which applications are entitled to each licensed dataset, how does that compare with the licensed counts, and which entitlements are unused, unrecertified or held by leavers?",
            "Which uses of licensed data are not covered by a permitted use grant, and what audit exposure, back-fees and true-ups are open?",
            "Which brokerage clients hold real-time quote entitlements without a current professional or non-professional attestation, and does the exchange subscriber declaration agree with the entitlements?",
            "Which indexes are used by the firm's funds and benchmarks without an active license, and what license fees do they imply on fund net assets?",
            "What does each agreement cost against its invoices and allocation, and which renewals reach their notice deadline without a decision?",
            "Which vendors breached service levels or reported assurance exceptions, and which terminated agreements still carry a data destruction obligation?",
        ],
        grain=("Dataset x data license agreement x month, with entitlement, consumption, declaration, audit finding, invoice, "
               "index product coverage and renewal case as drill-down companion facts; monthly snapshots plus daily "
               "entitlement state"),
        dimensions=["Month", "Data vendor (licensor)", "Data license agreement", "Dataset and subject area",
                    "Consuming application", "Consuming business domain and use case", "Org unit (cost allocation)",
                    "Licensee legal entity", "Dataset geographic coverage and granularity", "License audit and audit status",
                    "Permitted use category", "Entitlement holder type and entitlement type", "Market data subscriber status",
                    "Licensed index and index use type", "Covered product and share class (DP-004)", "Employee (DP-192)",
                    "Client (DP-240)"],
        measures=[
            ("Active Entitlements",
             "Count of Entitlement ID with Entitlement Status = Active at month-end, by Entitled Dataset, Governing License, Entitlement Holder Type and Entitlement Type.",
             _u("14", "Entitlement", "Entitlement ID", "Entitlement Status", "Entitled Dataset", "Governing License",
                "Entitlement Holder Type")),
            ("Entitlement Utilization %",
             "Active Entitlements with Entitlement Holder Type = User and Last Used Date in the last 90 days / Licensed User Count of the Licensed Dataset Schedule (Licensed Dataset = Entitled Dataset) effective at month-end x 100.",
             _u("14", "Entitlement", "Last Used Date", "Entitlement Holder Type")
             + _u("14", "Licensed Dataset Schedule", "Licensed Dataset", "Licensed User Count", "Scope Effective From", "Scope Effective To")
             + ["Active Entitlements"]),
            ("Over-Deployment",
             "Active user entitlements - Licensed User Count, where positive; likewise active application entitlements (Entitled Application populated) - Licensed Application Count, per dataset and schedule, with the entitled Consuming Applications of Usage Mode Non-Display or Display and Non-Display whose Declared to Vendor Indicator = N listed (undeclared non-display use).",
             _u("14", "Entitlement", "Entitled User", "Entitled Application")
             + _u("14", "Consuming Application", "Consuming Application ID", "Usage Mode", "Declared to Vendor Indicator")
             + _u("14", "Licensed Dataset Schedule", "Licensed User Count", "Licensed Application Count")
             + ["Active Entitlements"]),
            ("Uncovered Use Count",
             "Count of Dataset Consumption rows effective at month-end whose Covering Permitted Use has no Permitted Use Grant for the same Grant Dataset and Permitted Use Category with Permission Status in (Permitted, Permitted with Conditions), Legal Interpretation Confirmed Indicator = Y and Grant Effective From / To covering the date.",
             _u("14", "Dataset Consumption", "Consumed Dataset", "Covering Permitted Use", "Use Case", "Consumption Effective From",
                "Consumption Effective To")
             + _u("14", "Permitted Use Grant", "Grant Dataset", "Permitted Use Category", "Permission Status",
                  "Legal Interpretation Confirmed Indicator", "Grant Effective From", "Grant Effective To")),
            ("Overdue Recertifications",
             "Active entitlements whose Last Recertification Date is more than 12 months before month-end, plus active user entitlements whose Entitled User is a 20 Employee with Employment Status other than Active or a Termination Date before month-end (leavers, from DP-192).",
             _u("14", "Entitlement", "Last Recertification Date", "Entitled User", "Entitlement Status")
             + _u("20", "Employee", "Employee ID", "Employment Status", "Termination Date")),
            ("Cost per Active User",
             "Annual Contract Value of the agreement (Commercial Terms, in Contract Currency) / the count of distinct Entitled User of its Entitlements (Governing License = the agreement) with Entitlement Status = Active, Entitlement Holder Type = User and Last Used Date in the last 90 days at month-end.",
             _u("14", "Commercial Terms", "Annual Contract Value", "Contract Currency")
             + _u("14", "Entitlement", "Entitled User", "Governing License", "Entitlement Status", "Entitlement Holder Type",
                  "Last Used Date")),
            ("Invoice Variance",
             "Invoice Net Amount - Annual Contract Value x (Service Period End - Service Period Start + 1) / 365 per Data Invoice, flagged where Contract Validation Result is other than Matched.",
             _u("14", "Data Invoice", "Data Invoice ID", "Invoiced Agreement", "Service Period Start", "Service Period End",
                "Invoice Net Amount", "Contract Validation Result")
             + _u("14", "Commercial Terms", "Annual Contract Value")),
            ("Declared Fund Assets Variance (from DP-165)",
             "For Usage Declarations with Declaration Type = AUM-Linked Fee Declaration: Declared AUM - the sum, over the declaration agreement's covered own products (Index Product Coverage of its Index Uses effective at Declaration Period End), of Fund Total Net Assets of the NAV of record (Fund Net Assets Amount of the Fund NAV Calculation with NAV Approval Status Approved and the highest NAV Version Number on the last Valuation Date on or before Declaration Period End, from DP-165) on the Fee AUM Basis; never Client Assets or Firm AUM.",
             _u("14", "Usage Declaration", "Declaration Type", "Declared AUM", "Declaration Period End", "Declaration Agreement")
             + _u("14", "Index Product Coverage", "Covered Product", "Fee AUM Basis", "Coverage Effective From", "Coverage Effective To")
             + _u("14", "Index Use", "Index License Agreement")
             + _u("27", "Fund NAV Calculation", "NAV Book", "Valuation Date", "Fund Net Assets Amount", "NAV Approval Status",
                  "NAV Version Number")
             + _u("27", "Fund Accounting Book", "Book Fund")),
            ("Compliance Exposure",
             "Sum of True-Up Amount on License Compliance Findings with Finding Status in (Open, In Remediation), by Finding Type and Finding Severity, with the count past Remediation Due Date.",
             _u("14", "License Compliance Finding", "Finding Reference", "True-Up Amount", "Finding Status", "Finding Type",
                "Finding Severity", "Remediation Due Date")),
            ("Back-Fees Claimed (open audits)",
             "Sum of Back-Fees Claimed on License Audits whose Audit Status is not Closed, by Audited Vendor and Audit Type.",
             _u("14", "License Audit", "License Audit ID", "Back-Fees Claimed", "Audit Status", "Audited Vendor", "Audit Type")),
            ("Audit-Exposed Agreements",
             "Active agreements (Agreement Status = Active) with Vendor Audit Right Indicator = Y, with the Audit Notice Period and the count of user entitlements counted in Overdue Recertifications under each.",
             _u("14", "Data License Agreement", "Data License Agreement ID", "Agreement Status")
             + _u("14", "Compliance Clauses", "Vendor Audit Right Indicator", "Audit Notice Period")
             + ["Overdue Recertifications"]),
            ("Usage Reporting Compliance %",
             "Declaration periods with a Usage Declaration of Declaration Status in (Submitted, Acknowledged) and Submitted Date on or before Submission Due Date / declaration periods required by the agreement's Usage Reporting Frequency.",
             _u("14", "Usage Declaration", "Usage Declaration ID", "Declaration Status", "Submitted Date", "Submission Due Date")
             + _u("14", "Compliance Clauses", "Usage Reporting Frequency")),
            ("Coverage Overlap Count",
             "Datasets with Dataset Status = In Production in the same Dataset Subject Area that share Geographic Coverage, Covered Entity Types and Data Granularity with another such dataset; candidates for consolidation at renewal (Overlapping Datasets of the Renewal Case).",
             _u("14", "Dataset", "Dataset ID", "Dataset Subject Area", "Dataset Status")
             + _u("14", "Dataset Coverage", "Geographic Coverage", "Covered Entity Types", "Data Granularity")),
            ("Client Subscriber Attestation and Declaration Variance",
             "Active entitlements with Entitlement Holder Type = Client Subscriber whose Entitled Client has no Market Data Subscriber row with Subscriber Status Attested Date in the last 12 months (unattested count), and, per Exchange Subscriber Report declaration, Declared User Count - the count of those active client entitlements at Declaration Period End by Market Data Subscriber Status (from backlog DP-520).",
             _u("14", "Entitlement", "Entitled Client", "Entitlement Holder Type")
             + _u("14", "Market Data Subscriber", "Subscriber Client", "Market Data Subscriber Status", "Subscriber Status Attested Date",
                  "Subscriber Status Effective From")
             + _u("14", "Usage Declaration", "Declared User Count", "Declaration Type")
             + ["Active Entitlements"]),
            ("Index Uses Without Active License",
             "Count of Index Use rows (Licensed Index, Index Use Type) whose Index License Agreement is blank or has Agreement Status other than Active, plus Index Product Coverage rows effective on the as-of date whose Covered Product or Covered Share Class is not covered by an active Index Use (from backlog DP-521).",
             _u("14", "Index Use", "Index License Agreement", "Licensed Index", "Index Provider", "Index Use Type")
             + _u("14", "Index Product Coverage", "Covered Product", "Covered Share Class", "Coverage Effective From", "Coverage Effective To")
             + _u("14", "Data License Agreement", "Agreement Status")),
            ("Estimated Index License Fees (from DP-165)",
             "Per Index Product Coverage effective in the year: License Fee Rate (basis points) x the covered fund's net assets on its Fee AUM Basis (Fund Total Net Assets of the NAV of record, from DP-165) / 10,000, floored at Minimum Annual Fee where License Fee Basis = Minimum Fee plus Basis Points, compared with the invoices of the Index License Agreement (Invoice Net Amount).",
             _u("14", "Index Product Coverage", "License Fee Basis", "License Fee Rate", "Minimum Annual Fee", "Fee AUM Basis")
             + _u("27", "Fund NAV Calculation", "Fund Net Assets Amount")
             + _u("14", "Data Invoice", "Invoice Net Amount")
             + ["Declared Fund Assets Variance (from DP-165)"]),
            ("Renewal and Exit Actions Due",
             "Active agreements with Notice Deadline Date in the next 90 days (Auto-Renewal Indicator shown) and no Renewal Case (Renewing Agreement) with Renewal Decision other than Pending, with Negotiated Annual Value against Annual Contract Value where decided (from backlog DP-522); plus agreements with Agreement Status in (Terminated, Expired) whose Termination Obligations have Data Destruction Required Indicator = Y, with the days left to the Data Destruction Deadline after Current Term End Date, flagged where Derived Data Survival Indicator or Regulatory Archive Exception Indicator applies or entitlements to the agreement's datasets are still Active.",
             _u("14", "Data License Agreement", "Notice Deadline Date", "Auto-Renewal Indicator", "Current Term End Date",
                "Agreement Status")
             + _u("14", "Renewal Case", "Renewal Case ID", "Renewing Agreement", "Renewal Decision", "Negotiated Annual Value",
                  "Overlapping Datasets")
             + _u("14", "Commercial Terms", "Annual Contract Value")
             + _u("14", "Termination Obligations", "Data Destruction Required Indicator", "Data Destruction Deadline",
                  "Derived Data Survival Indicator", "Regulatory Archive Exception Indicator")
             + ["Active Entitlements"]),
            ("Vendor Service Exceptions",
             "Count of Vendor Data SLA rows with SLA Breach Indicator = Y in the month by SLA Dataset and SLA Metric (Measured Result against SLA Target), plus Assurance Reports with Report Period End in the last 12 months that have Exceptions Noted Indicator = Y or an Auditor Opinion other than Unqualified, by Assurance Report Type (from backlog DP-522).",
             _u("14", "Vendor Data SLA", "SLA Dataset", "SLA Metric", "SLA Target", "Measured Result", "SLA Breach Indicator")
             + _u("14", "Assurance Report", "Assurance Report Type", "Report Period End", "Exceptions Noted Indicator",
                  "Auditor Opinion")),
            ("Allocated Data Cost by Org Unit",
             "Per agreement and month: Annual Contract Value / 12 x Allocation Share of each Data Cost Allocation row (Allocated Agreement) effective in the month (Allocation Effective From / To), by Allocated Org Unit and Allocation Driver, in Contract Currency; shown against the month's Invoice Net Amount of the agreement's Data Invoices (Invoiced Agreement, service period in the month), with the unallocated share (100% - the summed Allocation Share).",
             _u("14", "Data Cost Allocation", "Allocated Agreement", "Allocated Org Unit", "Allocation Share", "Allocation Driver",
                "Allocation Effective From", "Allocation Effective To")
             + _u("14", "Commercial Terms", "Annual Contract Value", "Contract Currency")
             + _u("14", "Data Invoice", "Invoiced Agreement", "Invoice Net Amount", "Service Period Start", "Service Period End")),
            ("Datasets Without Delivery or Key Field Definition",
             "Datasets with Dataset Status = In Production whose Dataset Delivery has Delivery Method or Technical Feed blank, or that have no Dataset Key Field with Identifier Scheme and Match Target Concept populated (the delivery and key field inputs DP-075 held, CW-247).",
             _u("14", "Dataset", "Dataset Status")
             + _u("14", "Dataset Delivery", "Delivery Method", "Delivery Format", "Technical Feed")
             + _u("14", "Dataset Key Field", "Field Name", "Identifier Scheme", "Match Target Concept")),
        ],
        inputs=[
            ("14", "Dataset", ["Dataset ID", "Dataset Name", "Dataset Vendor", "Dataset Subject Area",
                               "Contains Personal Data Indicator", "Dataset Status", "Dataset Business Owner"]),
            ("14", "Dataset Coverage", ["Geographic Coverage", "Covered Entity Types", "Universe Description", "Data Granularity",
                                        "Update Frequency", "Data Latency", "Licensed History Depth"]),
            ("14", "Dataset Delivery", ["Delivery Method", "Delivery Format", "Technical Feed"]),
            ("14", "Dataset Key Field", ["Field Name", "Identifier Scheme", "Match Target Concept"]),
            ("14", "Dataset Consumption", ["Consumed Dataset", "Consuming Business Domain", "Consuming Application", "Use Case",
                                           "Covering Permitted Use", "Consumption Effective From", "Consumption Effective To"]),
            ("14", "Data License Agreement", ["Data License Agreement ID", "Agreement Name", "Licensor", "Licensee Legal Entity",
                                              "License Model", "Agreement Status", "Current Term End Date",
                                              "Auto-Renewal Indicator", "Notice Deadline Date"]),
            ("14", "Licensed Dataset Schedule", ["Licensed Dataset", "Licensed Territory", "Licensed Legal Entities",
                                                 "Licensed User Count", "Licensed Application Count", "Scope Effective From",
                                                 "Scope Effective To"]),
            ("14", "Compliance Clauses", ["Vendor Audit Right Indicator", "Audit Notice Period", "Usage Reporting Frequency"]),
            ("14", "Permitted Use Grant", ["Grant Agreement", "Grant Dataset", "Permitted Use Category", "Permission Status",
                                           "Use Conditions", "Legal Interpretation Confirmed Indicator", "Grant Effective From",
                                           "Grant Effective To"]),
            ("14", "Entitlement", ["Entitlement ID", "Entitlement Holder Type", "Entitled User", "Entitled Client",
                                   "Entitled Application", "Entitled Dataset", "Governing License", "Entitlement Type",
                                   "Entitlement Status", "Approved Date", "Provisioned Date", "Revoked Date",
                                   "Last Recertification Date", "Last Used Date"]),
            ("14", "Consuming Application", ["Consuming Application ID", "Application Name", "Usage Mode",
                                             "External Output Indicator", "Declared to Vendor Indicator"]),
            ("14", "Usage Declaration", ["Usage Declaration ID", "Declaration Agreement", "Declaration Type",
                                         "Declaration Period End", "Declared User Count", "Declared AUM",
                                         "Submission Due Date", "Submitted Date", "Declaration Status"]),
            ("14", "License Audit", ["License Audit ID", "Audited Vendor", "Audit Type", "Audit Scope Period", "Audit Status",
                                     "Back-Fees Claimed"]),
            ("14", "License Compliance Finding", ["Finding Reference", "Finding Type", "Finding Severity", "Remediation Due Date",
                                                  "True-Up Amount", "Finding Status"]),
            ("14", "Commercial Terms", ["Annual Contract Value", "Contract Currency", "Annual Price Escalator"]),
            ("14", "Data Invoice", ["Data Invoice ID", "Invoiced Agreement", "Service Period Start", "Service Period End",
                                    "Invoice Net Amount", "Contract Validation Result", "Invoice Status"]),
            ("14", "Data Cost Allocation", ["Allocated Agreement", "Allocated Org Unit", "Allocation Share", "Allocation Driver",
                                            "Allocation Effective From", "Allocation Effective To"]),
            ("14", "Market Data Subscriber", ["Subscriber Client", "Market Data Subscriber Status", "Subscriber Status Attested Date",
                                              "Subscriber Status Effective From"]),
            ("14", "Index Use", ["Index License Agreement", "Licensed Index", "Index Provider", "Index Use Type"]),
            ("14", "Index Product Coverage", ["Covered Product", "Covered Share Class", "License Fee Basis", "License Fee Rate",
                                              "Minimum Annual Fee", "Fee AUM Basis", "Coverage Effective From",
                                              "Coverage Effective To"]),
            ("14", "Assurance Report", ["Assurance Report Type", "Report Period Start", "Report Period End", "Auditor Opinion",
                                        "Exceptions Noted Indicator"]),
            ("14", "Termination Obligations", ["Data Destruction Required Indicator", "Data Destruction Deadline",
                                               "Derived Data Survival Indicator", "Regulatory Archive Exception Indicator"]),
            ("14", "Renewal Case", ["Renewal Case ID", "Renewing Agreement", "Renewal Decision", "Negotiated Annual Value",
                                    "Overlapping Datasets"]),
            ("14", "Vendor Data SLA", ["SLA Dataset", "SLA Metric", "SLA Target", "Measured Result", "SLA Breach Indicator"]),
            ("20", "Employee", ["Employee ID", "Employment Status", "Termination Date"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "Fund Net Assets Amount", "NAV Approval Status",
                                            "NAV Version Number"]),
            ("27", "Fund Accounting Book", ["Book Fund"]),
        ],
        upstream=["DP-101", "DP-210", "DP-211", "DP-192", "DP-240", "DP-004", "DP-165", "DP-013"],
        refresh="Daily",
        timeliness=("Entitlement state by 7am ET each business day; the monthly view (declarations, invoices, allocation, fees) "
                    "by business day 5 after month-end"),
        history=("Monthly snapshots kept 7 years and agreement, entitlement, declaration and audit records for the agreement term "
                 "plus 7 years (the vendor and exchange agreements' audit look-back periods; whether SEC Rule 17a-4 also applies to client market data entitlement records: confirm)"),
        classification="Restricted - Commercial Terms",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every Licensor and Dataset Vendor resolves to a DP-210 vendor, every Consuming Application ID to a DP-211 application, every Entitled User to a DP-192 employee, every Entitled Client and Subscriber Client to a DP-240 party, every Covered Product and Covered Share Class to DP-004, and every Governing License, Grant Agreement and Renewing Agreement to a Data License Agreement ID.",
            "Licensed Dataset Schedule scopes of one agreement and dataset, Permitted Use Grants of one agreement, dataset and category, Index Product Coverage periods of one index use and product, and Market Data Subscriber status rows of one client do not overlap, and every Effective To is on or after its Effective From.",
            "Every Data Invoice with Contract Validation Result = Matched has Invoice Variance within 1% of the prorated Annual Contract Value, Data Cost Allocation shares of one agreement sum to 100% on every date, and the fund net assets read for Declared Fund Assets Variance (from DP-165) equal DP-165's published Fund Total Net Assets for the same fund and date.",
            "Entitlement Status, Entitled Dataset and Governing License are populated on every entitlement, Last Recertification Date on every Active user entitlement, Market Data Subscriber Status on every client subscriber, and License Fee Rate and Fee AUM Basis on every basis-point Index Product Coverage.",
            "Rows naming an Entitled User, Entitled Client or Subscriber Client are visible only to market data administration and the data office; cost, coverage and declaration views are published without user or client detail, and Vendor User ID is not read.",
            "The daily entitlement state is complete by 7am ET and the monthly view by business day 5; a month is locked once its declarations are submitted, and later corrections are new declaration rows.",
        ],
        notes=("Certified numbers: reads Fund Total Net Assets (certified, CD-330) from DP-165 for AUM-linked declarations and "
               "index license fees, never Client Assets (DP-008) or Firm AUM (DP-241) (CW-241); owns none (It owns no "
               "certified metric family). "
               "PII tier: identity (employee entitlements; brokerage clients entitled to real-time quotes, with their "
               "professional or non-professional status). Classification Restricted - Commercial Terms because contract "
               "values and pricing are vendor-confidential. "
               "Boundaries: supplier-level oversight stays DP-219 and the vendor master DP-210; the catalog and lineage of "
               "datasets is DP-101's; DP-075 stays live by the WP0 ruling until DP-101 absorbs its lineage, and this product "
               "takes its dataset delivery and key field reads (CW-247). The index licensing, client subscriber and vendor "
               "renewal scopes of backlog DP-521, DP-520 and DP-522 fold in here, which also succeed the retired DP-072 and "
               "DP-073 (their BMR and DORA content removed, CW-914). "
               "Tailoring lever: client real-time quotes (14). Reference default: offered, with each client's professional "
               "status attested at least every 12 months; a non-display-only firm drops the subscriber measures. Tailoring "
               "lever: licensed CMA and research data. Reference default: in house CMA; vendor research datasets licensed "
               "per named user. Tailoring lever: recertification cycle. Reference default: 12 months, 90 days for "
               "utilization. "
               "Taxonomy gap: 14 Usage Declaration.Declared AUM is typed a Derived copy of 06 (the wholesale AUM measures); "
               "in the wealth model asset-linked index declarations use fund net assets from 27 (DP-165), so the source note "
               "should change. Taxonomy gap: 14 Commercial Terms has no per-dataset price, so cost per user is computed at "
               "agreement level. Taxonomy gap: 14 Assurance Report, Vendor Data SLA, Termination Obligations and Renewal "
               "Case carry no data vendor or agreement key of their own where their grain names one (Assurance Report has "
               "no vendor attribute), so the joins are implicit. Taxonomy gap: 14 Index Use and Index Product Coverage hold "
               "no license fee invoice link; fees are compared with the agreement's invoices. "
               "Drafting assumptions: Entitlement Status Active; Entitlement Holder Type values User and Client Subscriber; "
               "Permission Status values Permitted and Permitted with Conditions; Declaration Type values AUM-Linked Fee "
               "Declaration and Exchange Subscriber Report; Declaration Status values Submitted and Acknowledged; Finding "
               "Status values Open and In Remediation; Audit Status Closed; Agreement Status values; Renewal Decision "
               "Pending; Dataset Status In Production; Auditor Opinion Unqualified; the 90-day, 12-month and 1% thresholds. "
               "Decisions: CW-112, CW-240, CW-241, CW-247, CW-914, CD-330. "
               "WP1 re-scope (CW-240, lead WP0 ruling): DP-044 keeps its id because five live products depend on it (DP-120, "
               "DP-122, DP-134, DP-148, DP-233); it takes the scope of candidate DP-519 Third-Party Data Entitlements, Usage "
               "& Cost, whose id is merged here and should not be specified (framework records DP-044 as superseded by "
               "DP-519; the register row and the WP0_DISPOSITIONS entry need the lead's correction). The register row keeps "
               "the old name 'Third-Party Data Usage, Entitlements & Cost' with FN-17 primary and FN-12 and FN-13 (retired) "
               "supporting; by the ruling the product takes DP-519's name 'Third-Party Data Entitlements, Usage & Cost' "
               "and supporting FN-50, FN-38 and FN-46 (rename and row: lineage agent and lead; DP-044 also leaves "
               "RETIRED_PRODUCTS and RESCOPE_PENDING so the retired-spec sweep does not delete this spec). Inputs added: 14 Dataset Delivery and Dataset Key "
               "Field (from DP-075, CW-247), the WP1 scope moved reads 14 Market Data Subscriber (from DP-520), Index Use "
               "and Index Product Coverage (from DP-521), Assurance Report, Termination Obligations, Renewal Case and "
               "Vendor Data SLA (from DP-522), and 27 Fund NAV Calculation and Fund Accounting Book (fund net assets from "
               "DP-165). Inputs dropped: 06 Asset Measures (wholesale AUM; replaced by DP-165 fund net assets); 14 Commercial "
               "Terms Pricing Basis. Measures kept by name: Active Entitlements, Entitlement Utilization %, Over-Deployment, "
               "Uncovered Use Count, Overdue Recertifications (now also counting leavers), Cost per Active User, Invoice "
               "Variance, Compliance Exposure, Back-Fees Claimed (open audits), Audit-Exposed Agreements, Usage Reporting "
               "Compliance % and Coverage Overlap Count. Measure renamed: 'Declared AUM Variance' becomes 'Declared Fund "
               "Assets Variance (from DP-165)' (no reader found in specs, models or semantic files; the old formula read the "
               "certified Ending AUM of DP-008, which no longer exists). Measures added: Client Subscriber Attestation and "
               "Declaration Variance, Index Uses Without Active License, Estimated Index License Fees (from DP-165), "
               "Renewal and Exit Actions Due, Vendor Service Exceptions, Allocated Data Cost by Org Unit, Datasets Without "
               "Delivery or Key Field Definition. Fix pass (C-6 review, lead ruling 6): Cost per Active User now counts "
               "the entitlements it divides by; Allocated Data Cost by Org Unit answers business question 5 from 14 Data "
               "Cost Allocation; the renewal and destruction measures are merged to stay within 20; Consuming "
               "Application is used in Over-Deployment. Upstream: DP-008 and DP-009 dropped; DP-101, DP-210, DP-211, DP-192, "
               "DP-240, DP-004 and DP-165 added. Every earlier dimension name is kept (the data vendor resolves through "
               "DP-210, the consuming application through DP-211, org unit, legal entity and month through DP-013); seven "
               "dimensions are added. The old DP-044 entry in "
               "specs_e_comp_finance_service.py is to be deleted by the lineage agent; models_c3_comp_finance_service.py "
               "keeps the DP-044 logical model to re-cut."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-130": dict(
        definition=("For each tax-aware institutional separate account managed as an 18 portfolio (IA line), or a sleeve of one: "
                    "the client's tax budget for the year against gains realized to date, the lots selected for each proposed "
                    "sale with their estimated gains and wash sale risk, the losses harvested and still available, the gain a "
                    "rebalance run would realize, and the client's hard construction constraints and IMA restrictions that "
                    "apply. It drives tax-loss harvesting and gain budgeting on the portfolio book and gives institutional "
                    "client service an account-level view of tax outcomes. Realized gains and lot relief are read from "
                    "DP-142 (18 Portfolio Holding and Tax Lot, the IBOR book); retail managed accounts are 15 accounts managed "
                    "in 46 and are out of scope (CW-048). It owns no certified metric family."),
        business_questions=[
            "How much of each institutional separate account's net realized gain budget has been used this tax year, and which accounts will exceed it if pending proposals or the latest rebalance run trade?",
            "How much short-term gain has each account realized against its short-term budget?",
            "How much loss has been harvested against each account's target, and how much unrealized loss is still available to harvest?",
            "Which proposed sales carry wash sale risk, and how much loss has been disallowed under the wash sale rule this year?",
            "Which tax-aware accounts have no budget for the current tax year, and which proposals are for portfolios with active hard constraints or client IMA restrictions?",
        ],
        grain=("Institutional separate account portfolio (18, or its sleeve) x tax year x as-of date, with proposed trade x 18 "
               "tax lot as the lot selection detail and rebalance run x portfolio as the run estimate; daily snapshots"),
        dimensions=["Institutional separate account (DP-093)", "Portfolio and sleeve (DP-140)", "Tax year", "Instrument (DP-097)",
                    "Holding period term", "Proposed trade status", "Lot selection method",
                    "Constraint type and restriction source (DP-128; 01 Investment Restriction)", "Business line", "As-of date"],
        measures=[
            ("Budget Used %",
             "Realized Gain to Date / Net Realized Gain Budget for the Budget Portfolio and Tax Year; Realized Gain to Date is a Derived copy of 18 read as given.",
             _u("24", "Tax Budget", "Budget Portfolio", "Tax Year", "Realized Gain to Date", "Net Realized Gain Budget")),
            ("Realized Gain Tie-Out",
             "Realized Gain to Date - sum of Realized Gain / Loss Base of 18 Lot Relief rows whose Relieved Tax Lot has Lot Portfolio = the Budget Portfolio and whose Closing Transaction has a Trade Date in the tax year (DP-141), from DP-142; non-zero values show a stale copy.",
             _u("24", "Tax Budget", "Realized Gain to Date", "Budget Portfolio")
             + _u("18", "Lot Relief", "Relieved Tax Lot", "Realized Gain / Loss Base", "Closing Transaction")
             + _u("18", "Tax Lot", "Tax Lot ID", "Lot Portfolio")
             + _u("18", "Portfolio Transaction", "Portfolio Transaction ID", "Trade Date")),
            ("Pending Proposal Gain",
             "Sum of Estimated Lot Gain of Proposed Lot Selections whose Proposed Trade has Proposed Trade Status in (Proposed, Accepted) for the Budget Portfolio.",
             _u("24", "Proposed Lot Selection", "Lot Selection Trade", "Estimated Lot Gain")
             + _u("24", "Proposed Trade", "Proposed Trade ID", "Proposed Trade Status", "Proposed Trade Portfolio")),
            ("Projected Budget Breach",
             "Y where Realized Gain to Date + Pending Proposal Gain > Net Realized Gain Budget, with the excess amount.",
             _u("24", "Tax Budget", "Realized Gain to Date", "Net Realized Gain Budget") + ["Pending Proposal Gain"]),
            ("Rebalance Run Gain Against Remaining Budget",
             "For the latest Rebalance Portfolio Result of the portfolio (Result Portfolio, Result Rebalance Run) with Result Accepted Indicator not yet N: Estimated Realized Gain - (Net Realized Gain Budget - Realized Gain to Date); positive values mean the run would breach the budget if accepted (run estimates from DP-128).",
             _u("24", "Rebalance Portfolio Result", "Result Rebalance Run", "Result Portfolio", "Estimated Realized Gain",
                "Result Accepted Indicator")
             + _u("24", "Tax Budget", "Net Realized Gain Budget", "Realized Gain to Date")),
            ("Short-Term Gain vs Budget",
             "Sum of Realized Gain / Loss Base of the portfolio's Lot Relief rows with Holding Period Term = Short-Term in the tax year / Short-Term Gain Budget.",
             _u("18", "Lot Relief", "Holding Period Term", "Realized Gain / Loss Base") + _u("24", "Tax Budget", "Short-Term Gain Budget")),
            ("Losses Harvested vs Target %",
             "Absolute sum of negative Realized Gain / Loss Base of the portfolio's Lot Relief rows in the tax year, net of Wash-Sale Loss Disallowed / Loss Harvesting Target.",
             _u("18", "Lot Relief", "Realized Gain / Loss Base", "Wash-Sale Loss Disallowed") + _u("24", "Tax Budget", "Loss Harvesting Target")),
            ("Unrealized Loss Available",
             "Sum over open tax lots of the portfolio (Lot Closed Indicator = N) of min(0, Remaining Quantity x Price Used of the portfolio's End of Day Portfolio Holding in the Lot Instrument - Adjusted Cost Basis Base), from DP-142.",
             _u("18", "Tax Lot", "Lot Instrument", "Remaining Quantity", "Adjusted Cost Basis Base", "Lot Closed Indicator")
             + _u("18", "Portfolio Holding", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View")
             + _u("18", "Holding Valuation", "Price Used")),
            ("Wash Sale Risk Proposals",
             "Count and Proposed Quantity of Proposed Trades with Wash Sale Risk Indicator = Y that are not yet Released, and the Wash-Sale Loss Disallowed amount booked in the tax year with its Wash-Sale Replacement Lot (from DP-142).",
             _u("24", "Proposed Trade", "Wash Sale Risk Indicator", "Proposed Quantity", "Proposed Trade Status")
             + _u("18", "Lot Relief", "Wash-Sale Loss Disallowed", "Wash-Sale Replacement Lot")),
            ("Lot Selection Quantity Check",
             "Proposed Quantity of each sale - sum of Quantity to Relieve of its Proposed Lot Selections; zero expected for sales with Lot Selection Method = Specific Lot Identification or Tax-Optimized.",
             _u("24", "Proposed Trade", "Proposed Quantity", "Lot Selection Method", "Proposed Trade Side")
             + _u("24", "Proposed Lot Selection", "Quantity to Relieve", "Selected Tax Lot")),
            ("Tax-Aware Accounts Without Budget",
             "Count of Active portfolios with SMA Portfolio Detail Tax-Aware Management Indicator = Y and Sponsor Program Agreement blank (IA institutional separate accounts, not IC sponsor program books) whose primary Portfolio Implementation Link of Implementation Link Type = Manages Account names a 15 account of Account Type Institutional Separate Account, and that have no Tax Budget for the current Tax Year.",
             _u("18", "SMA Portfolio Detail", "Tax-Aware Management Indicator", "Sponsor Program Agreement")
             + _u("18", "Portfolio", "Portfolio ID", "Portfolio Status")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implementation Link Type", "Managed Account",
                  "Primary Implementation Indicator")
             + _u("15", "Account", "Account ID", "Account Type")
             + _u("24", "Tax Budget", "Tax Year")),
            ("Proposals on Restricted Accounts",
             "Count of open Proposed Trades (Proposed Trade Status in (Proposed, Accepted)) for portfolios with a Portfolio Construction Constraint (Constrained Portfolio) with Constraint Status Active effective on the as-of date that has Hard Constraint Indicator = Y or a Buffered Investment Restriction with Restriction Source = Client IMA, by Constraint Type and Restriction Category, for review that the restriction was applied.",
             _u("24", "Proposed Trade", "Proposed Trade Portfolio", "Proposed Trade Status")
             + _u("24", "Portfolio Construction Constraint", "Constrained Portfolio", "Constraint Type", "Hard Constraint Indicator",
                  "Buffered Investment Restriction", "Constraint Status", "Constraint Effective From", "Constraint Effective To")
             + _u("01", "Investment Restriction", "Restriction ID", "Restriction Source", "Restriction Category")),
        ],
        inputs=[
            ("24", "Tax Budget", ["Budget Portfolio", "Tax Year", "Net Realized Gain Budget", "Short-Term Gain Budget",
                                  "Loss Harvesting Target", "Realized Gain to Date", "Budget Instructed By"]),
            ("24", "Proposed Trade", ["Proposed Trade ID", "Proposing Rebalance Run", "Proposed Trade Portfolio",
                                      "Proposed Trade Instrument", "Proposed Trade Side", "Proposed Quantity",
                                      "Proposed Trade Status", "Lot Selection Method", "Wash Sale Risk Indicator"]),
            ("24", "Proposed Lot Selection", ["Lot Selection Trade", "Selected Tax Lot", "Quantity to Relieve", "Estimated Lot Gain"]),
            ("24", "Rebalance Portfolio Result", ["Result Rebalance Run", "Result Portfolio", "Estimated Realized Gain",
                                                  "Result Accepted Indicator"]),
            ("24", "Portfolio Construction Constraint", ["Constrained Portfolio", "Constraint Type", "Hard Constraint Indicator",
                                                         "Buffered Investment Restriction", "Constraint Status",
                                                         "Constraint Effective From", "Constraint Effective To"]),
            ("01", "Investment Restriction", ["Restriction ID", "Restriction Source", "Restriction Category"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Business Line", "Portfolio Status"]),
            ("18", "SMA Portfolio Detail", ["Sponsor Program Agreement", "Full Discretion Indicator",
                                            "Tax-Aware Management Indicator", "Tax Loss Harvesting Indicator"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Managed Account",
                                                     "Primary Implementation Indicator", "Implementation Effective From",
                                                     "Implementation Effective To"]),
            ("18", "Tax Lot", ["Tax Lot ID", "Lot Portfolio", "Lot Instrument", "Lot Open Date", "Remaining Quantity",
                               "Adjusted Cost Basis Base", "Holding Period Start Date", "Lot Closed Indicator"]),
            ("18", "Lot Relief", ["Relieved Tax Lot", "Closing Transaction", "Relief Method Applied", "Relieved Quantity",
                                  "Realized Gain / Loss Base", "Holding Period Term", "Wash-Sale Loss Disallowed",
                                  "Wash-Sale Replacement Lot"]),
            ("18", "Portfolio Transaction", ["Portfolio Transaction ID", "Transaction Portfolio", "Trade Date"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Price Used", "Market Value Base"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type"]),
        ],
        upstream=["DP-128", "DP-142", "DP-141", "DP-140", "DP-093", "DP-097", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness=("By 7am ET each business day on the prior day's lot relief; proposal-level lot selections and run estimates "
                    "as each rebalance run completes (through DP-128)"),
        history="Tax budgets by tax year and daily portfolio snapshots kept 7 years; lot selections kept with their proposed trades for 7 years (Advisers Act Rule 204-2)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "Dashboard", "API"],
        dq_rules=[
            "Every Tax Budget names a Budget Portfolio that resolves to an active DP-140 portfolio whose Manages Account link names a DP-093 account of Account Type Institutional Separate Account; every Constrained Portfolio and Proposed Trade Portfolio resolves to DP-140 and every Buffered Investment Restriction to a 01 Investment Restriction (read directly; no foundational product publishes it).",
            "There is at most one Tax Budget per Budget Portfolio and Tax Year, and Portfolio Construction Constraint and Portfolio Implementation Link periods of one portfolio and type do not overlap, with every Effective To on or after its Effective From.",
            "Realized Gain Tie-Out is within one unit of base currency for every portfolio at each daily snapshot, and every Proposed Lot Selection references a Selected Tax Lot of the same portfolio and instrument as its proposed trade with Quantity to Relieve not above the lot's Remaining Quantity.",
            "Net Realized Gain Budget is populated on every Tax Budget, Short-Term Gain Budget where filled is not greater than Net Realized Gain Budget, and Lot Selection Method is populated on every sale.",
            "Budget Instructed By (an institutional client's officer, trustee or consultant, a natural person in some cases) and the amounts of a separate account owned by a natural person are visible only to institutional portfolio management and client service; no retail 15 account is read.",
            "The daily snapshot is complete by 7am ET; a closed tax year's budget is locked after the year-end tie-out, and corrections are new budget rows with the correction noted.",
        ],
        notes=("Certified numbers: none read or owned (It owns no certified metric family); realized gains are read from "
               "DP-142 lot relief and Realized Gain to Date is tied out, never recomputed from transactions. "
               "PII tier: identity and financial where the institutional separate account belongs to a natural person or "
               "the budget is instructed by an individual (24 notes); classification Confidential - Client. "
               "Operating model (CD-297): 24 is in house; if the institutional middle office is outsourced the 18 inputs "
               "arrive as provider IBOR through DP-142 and the grain is unchanged. "
               "Boundaries: tax management of retail managed accounts (15 accounts in 46: Account Tax Budget, harvest "
               "decisions, wash-sale windows) is DP-304's and DP-342's and is not read (CW-048). Proposed trades, lot "
               "selections and rebalance runs of 18 portfolios are DP-128's (24); lots and lot relief DP-142's (18). "
               "Client restrictions of institutional accounts are the 01 IMA restrictions buffered into 24 construction "
               "constraints; coded rule checks remain 33's (DP-161, DP-162). DP-128 is to be restricted to portfolio-subject "
               "target sets at this wave (lineage RESPEC note, not edited here). "
               "Tailoring lever: where the gain budget is held (24 SME 9). Reference default: one 24 Tax Budget per "
               "portfolio and tax year, instructed by the client. Tailoring lever: sleeve-level budgets in multi-sleeve "
               "institutional accounts (24 SME 13). Reference default: budget on the account's lead portfolio, sleeves "
               "rolled up through the implementation link. Tailoring lever: IC sponsor program books. Reference default: "
               "excluded (the sponsor manages the tax outcome); including them adds books with Sponsor Program Agreement "
               "populated. "
               "Taxonomy gap: 24 Rebalance Portfolio Result has no attribute for the restrictions or constraints applied, "
               "so this product shows active restrictions beside open proposals rather than proving each was applied. "
               "Taxonomy gap: 01 Investment Restriction carries no product or mandate reference in the catalog, so client "
               "IMA restrictions are reached only through 24 Portfolio Construction Constraint.Buffered Investment "
               "Restriction. "
               "Drafting assumptions: Proposed Trade Status values Proposed, Accepted and Released; Holding Period Term "
               "Short-Term; Lot Selection Method values Specific Lot Identification and Tax-Optimized; Implementation Link "
               "Type Manages Account; Account Type Institutional Separate Account; Portfolio Status Active; Constraint "
               "Status Active; Restriction Source Client IMA; the one-unit tolerance. The tax year of a realized gain is the "
               "Trade Date of the Lot Relief's Closing Transaction (DP-141). "
               "Decisions: CD-178, CD-221, CD-297, CD-324, CW-007, CW-048, CW-208. "
               "W3 re-point (CW-048, CW-128): 24 Tax Budget.Budget Account dropped; the budget is keyed Budget Portfolio x "
               "Tax Year. "
               "WP1 re-scope (CW-208, CW-048): renamed by the C-6 ruling from 'SMA Customization & Tax Management' to "
               "'Institutional Separate Account Tax Management' (register row: lineage agent and lead; no reader keys on "
               "the name); owning domain 24 and primary FN-22 unchanged; dimension 'SMA account (DP-093)' renamed "
               "'Institutional separate account (DP-093)' (no reader); scope "
               "narrowed from 'tax-aware separately managed accounts' to institutional separate accounts on the 18 book "
               "(IA line); retail managed accounts move to 46 (DP-304, DP-342). Inputs dropped: 02 Client Restriction "
               "(retail restrictions, read through pending DP-077, which leaves upstream). Inputs added: 24 Portfolio "
               "Construction Constraint and 01 Investment Restriction (institutional IMA restrictions), 18 Portfolio "
               "Business Line and Portfolio Implementation Link Primary Implementation Indicator; 18 Portfolio Implementation "
               "Link Implemented Mandate is not read. Measures kept by name: Budget Used %, Realized Gain Tie-Out, Pending "
               "Proposal Gain, Projected Budget Breach, Short-Term Gain vs Budget, Losses Harvested vs Target %, "
               "Unrealized Loss Available, Wash Sale Risk Proposals, Lot Selection Quantity Check, Tax-Aware Accounts "
               "Without Budget and Proposals on Restricted Accounts (re-sourced from 24 constraints and 01 IMA restrictions "
               "instead of 02 Client Restriction). Measure added: Rebalance Run Gain Against Remaining Budget. Dimension "
               "'Client restriction category (DP-077)' becomes 'Constraint type and restriction source (DP-128; 01 Investment Restriction)'; "
               "'Business line' added; the others are kept. Upstream: DP-077 dropped; DP-004 added. Readers: no spec or "
               "semantic file reads DP-130 measures; data_models/models_e8c_portfolio_stewardship.py DP-130 conforms "
               "'Client Restriction' (02, DP-077) and 'Account' and needs re-cutting by the lineage agent (Client "
               "Restriction replaced by Portfolio Construction Constraint). Classification changes from Restricted - "
               "Personal Data to Confidential - Client because retail accounts leave the scope. The old DP-130 entry in "
               "specs_e2_portfolio_stewardship.py is to be deleted by the lineage agent. The W1 re-point line on Client "
               "Restriction Restricted Accounts (CW-902) no longer applies and is dropped."),
    ),
}
