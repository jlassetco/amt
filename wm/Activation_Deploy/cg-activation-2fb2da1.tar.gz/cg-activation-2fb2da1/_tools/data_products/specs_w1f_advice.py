"""Data product specifications, Wave WP1F (foundational), group F2 "advice": advice, managed accounts, fees, model
construction, manager and trust masters of the wealth-manager reference model.

DP-303 Advice Plans & Recommendations (45); DP-304 Managed Account Model Assignments (46); DP-305 Fee Schedules & Billing
Runs (47); DP-530 Capital Market Assumptions, Model Lineups & Model Weights (24); DP-306 Manager & Sub-Adviser Master (52);
DP-307 Trust Fiduciary Record (51, optional; a tailoring lever, written last).

WP1 decisions applied: CW-205 (new foundational products DP-300 to DP-307), CW-250 (DP-530 takes the model-subject rows of
24 out of DP-128), CW-254 (Product List Status in DP-306), CW-214 (billed fees are operational; client fee revenue is DP-012's),
CW-251 (Personal Rate of Return is DP-145's), CW-212 (the managed-account slice of Firm AUM is published by DP-345, not here),
CW-213 and CD-344 (special-category facts only through DP-322 and the named restricted views). See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


# One gap line shared by the products that read one of the six keyless one-to-one sub-objects (review finding L).
GAP6 = ("Taxonomy gap: six one-to-one sub-objects carry no key or parent reference of their own (45 Recommendation Rationale, 45 PTE "
        "2020-02 Documentation, 46 Tax Management Setting, 47 Performance Fee Terms, 52 Manager-of-Managers Hire Condition and 15 "
        "Account Registration Detail), so their join to the parent is implicit and cannot be stated in a measure's uses. ")


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-303": dict(
        definition=("The conformed advice record of every client and Client Household: advice engagements and their "
                    "participants, advice reviews including the Rule 3a-4 annual contact, financial goals, client financial "
                    "plans and their versions with the planning scenarios run on them, and every recommendation with its "
                    "rationale, alternatives, best-interest evidence, implementation links and, for rollovers, the rollover "
                    "analysis and PTE 2020-02 documentation, as 45 masters them. It publishes the CONCEPT_OWNERSHIP rows Advice "
                    "Engagement, Advice Review, Financial Goal, Client Financial Plan, Planning Scenario, Recommendation and "
                    "Rollover Analysis (45) once, so that the Reg BI file, supervision, the advice funnel, goal progress and "
                    "rollover capture assemble the same evidence and never re-score it. It owns no certified metric family."),
        business_questions=[
            "How many advice engagements are active today, by engagement type, advice capacity, delivery channel and business line, and which lack a primary client?",
            "Which advice reviews, including Rule 3a-4 annual contacts, are overdue, and which reviews were held without confirming an investor profile version?",
            "Which clients have a current accepted financial plan, how old is its data, and which plan versions rest on an assumption set or capital market assumption set that is not active?",
            "How many recommendations were presented in the period, by type, capacity and source, what share did clients accept, and what share of accepted recommendations is implemented?",
            "Which presented recommendations carry unattested best-interest evidence components, and which rollover recommendations have no rollover analysis?",
        ],
        grain=("Recommendation x client (02 party or Client Household) x presented timestamp, with best-interest evidence components, "
               "alternatives and implementation links as companion facts; companion masters advice engagement x participant x "
               "period, advice review, financial goal, client financial plan x version x scenario, and rollover analysis with "
               "its PTE 2020-02 documentation; SCD type 2 on engagement, goal and plan status, versions kept as recorded"),
        dimensions=["Client and Client Household (DP-240)", "Client account (DP-093)", "Advisor (DP-009)",
                    "Service offering (DP-004)", "Model portfolio (DP-004)", "Share class (DP-004)", "Instrument (DP-097)",
                    "Recommendation engine and planning engine (DP-212)", "Capital market assumption set (DP-530)",
                    "Engagement type", "Advice capacity", "Advice delivery channel", "Business line", "Advice review type",
                    "Recommendation type", "Recommendation source", "Client decision", "Best interest component",
                    "Fiduciary status basis", "Calendar date (DP-013)"],
        measures=[
            ("Active Advice Engagements",
             "Count of distinct Advice Engagement ID with Engagement Status = Active, Engagement Start Date <= as-of date and Engagement End Date blank or after the as-of date, by Engagement Type, Engagement Advice Capacity, Engagement Delivery Channel and Engagement Business Line.",
             _u("45", "Advice Engagement", "Advice Engagement ID", "Engagement Status", "Engagement Start Date", "Engagement End Date",
                "Engagement Type", "Engagement Advice Capacity", "Engagement Delivery Channel", "Engagement Business Line")),
            ("Engagements Without Primary Client",
             "Active Advice Engagements with no Engagement Participant row whose Participant Engagement is the engagement, Engagement Participant Role = Primary Client and Participant Effective From <= as-of date < Participant Effective To (or open).",
             _u("45", "Engagement Participant", "Participant Engagement", "Engagement Participant Role", "Participant Effective From",
                "Participant Effective To") + ["Active Advice Engagements"]),
            ("Overdue Advice Reviews",
             "Count of Advice Review rows of Active Advice Engagements (Reviewed Engagement) with Review Due Date before the as-of date and Review Held Date blank, by Advice Review Type and Review Channel.",
             _u("45", "Advice Review", "Advice Review ID", "Reviewed Engagement", "Review Due Date", "Review Held Date",
                "Advice Review Type", "Review Channel") + ["Active Advice Engagements"]),
            ("Rule 3a-4 Annual Contacts On Time %",
             "Advice Review rows with Advice Review Type = Rule 3a-4 Annual Contact, Review Due Date in the trailing 12 months and Review Held Date <= Review Due Date / Advice Review rows with Advice Review Type = Rule 3a-4 Annual Contact and Review Due Date in the trailing 12 months.",
             _u("45", "Advice Review", "Advice Review Type", "Review Due Date", "Review Held Date")),
            ("Reviews Without Profile Confirmation",
             "Count of Advice Review rows with Review Held Date in the period and Profile Version Confirmed blank, by Advice Review Type and Review Outcome.",
             _u("45", "Advice Review", "Review Held Date", "Profile Version Confirmed", "Advice Review Type", "Review Outcome")),
            ("Active Financial Goals",
             "Count of Financial Goal ID with Goal Status = Active on the as-of date, by Goal Type and Goal Priority.",
             _u("45", "Financial Goal", "Financial Goal ID", "Goal Status", "Goal Type", "Goal Priority")),
            ("Active Goal Target Amount",
             "Sum of Goal Target Amount of Active Financial Goals, by Goal Type and year of Goal Target Date, at the grain of the Goal Owner (a household-owned goal counts once at household grain and is never also counted at member grain); amounts are in USD as recorded (no FX conversion).",
             _u("45", "Financial Goal", "Goal Target Amount", "Goal Target Date") + ["Active Financial Goals"]),
            ("Current Accepted Plans",
             "Count of Client Financial Plan ID with Client Financial Plan Status = Active whose latest Client Financial Plan Version (highest Plan Version Number of the Versioned Plan) has Client Financial Plan Version Status = Accepted and Plan Accepted Date <= as-of date, by Client Financial Plan Type.",
             _u("45", "Client Financial Plan", "Client Financial Plan ID", "Client Financial Plan Status", "Client Financial Plan Type")
             + _u("45", "Client Financial Plan Version", "Versioned Plan", "Plan Version Number", "Client Financial Plan Version Status",
                  "Plan Accepted Date")),
            ("Accepted Plans With Stale Data",
             "Current Accepted Plans whose accepted version has Plan Data As-Of Date more than 12 months before the as-of date, by Client Financial Plan Type.",
             _u("45", "Client Financial Plan Version", "Plan Data As-Of Date") + ["Current Accepted Plans"]),
            ("Plan Versions Without Accepted Scenario",
             "Count of Client Financial Plan Version ID with Client Financial Plan Version Status in (Presented, Accepted) and Plan Presented Date in the period for which no Planning Scenario with Scenario Plan Version = the version has Accepted Scenario Indicator = Y, by Planning Scenario Type of the scenarios run.",
             _u("45", "Client Financial Plan Version", "Client Financial Plan Version ID", "Client Financial Plan Version Status",
                "Plan Presented Date")
             + _u("45", "Planning Scenario", "Planning Scenario ID", "Scenario Plan Version", "Accepted Scenario Indicator",
                  "Planning Scenario Type")),
            ("Plan Versions on Inactive Assumptions",
             "Count of Client Financial Plan Version ID with Plan Presented Date in the period whose Version Assumption Set resolves to a Planning Assumption Set (Assumption Set Code) with Assumption Set Status other than Active, or not effective on Plan Data As-Of Date (Assumption Set Effective From / To), or whose Capital Market Assumption Set resolves to a 24 Capital Market Assumption Set version with CMA Set Status other than Active (from DP-530).",
             _u("45", "Client Financial Plan Version", "Client Financial Plan Version ID", "Version Assumption Set", "Plan Presented Date",
                "Plan Data As-Of Date")
             + _u("45", "Planning Assumption Set", "Assumption Set Code", "Assumption Set Status", "Assumption Set Effective From",
                  "Assumption Set Effective To", "Capital Market Assumption Set")
             + _u("24", "Capital Market Assumption Set", "Capital Market Assumption Set ID", "CMA Set Status")),
            ("Recommendations Presented",
             "Count of Recommendation ID with Recommendation Presented Timestamp in the period, by Recommendation Type, Recommendation Capacity, Recommendation Source and Recommendation Channel.",
             _u("45", "Recommendation", "Recommendation ID", "Recommendation Presented Timestamp", "Recommendation Type",
                "Recommendation Capacity", "Recommendation Source", "Recommendation Channel")),
            ("Recommendation Acceptance Rate",
             "Recommendations Presented with Client Decision in (Accepted, Accepted with Changes) / Recommendations Presented with Client Decision other than Pending, by Recommendation Type and Recommendation Source.",
             _u("45", "Recommendation", "Client Decision") + ["Recommendations Presented"]),
            ("Accepted Recommendations Implemented %",
             "Recommendations Presented with Client Decision in (Accepted, Accepted with Changes) that have at least one Recommendation Implementation Link (Implemented Recommendation = Recommendation ID) with Implementation Date <= as-of date / Recommendations Presented with Client Decision in (Accepted, Accepted with Changes), by Implementing Record Type.",
             _u("45", "Recommendation", "Client Decision")
             + _u("45", "Recommendation Implementation Link", "Implemented Recommendation", "Implementing Record Type", "Implementation Date")
             + ["Recommendations Presented"]),
            ("Unattested Evidence Components",
             "Count of Best Interest Evidence rows of Recommendations Presented (Evidence Recommendation) with Evidence Attester blank or Evidence Attested Date blank, by Best Interest Component and Evidence Type; component-level completeness only (the evidence gap flag is DP-334's).",
             _u("45", "Best Interest Evidence", "Evidence Recommendation", "Best Interest Component", "Evidence Type",
                "Evidence Attester", "Evidence Attested Date") + ["Recommendations Presented"]),
            ("Rollover Recommendations Without Analysis",
             "Recommendations Presented with Recommendation Type = Rollover whose Supporting Rollover Analysis is blank and for which no Rollover Analysis has Rollover Recommendation = Recommendation ID.",
             _u("45", "Recommendation", "Recommendation Type", "Supporting Rollover Analysis")
             + _u("45", "Rollover Analysis", "Rollover Analysis ID", "Rollover Recommendation") + ["Recommendations Presented"]),
            ("Rollover Amount Analyzed",
             "Sum of Rollover Amount of Rollover Analysis rows with Rollover Analysis Status in (Completed, Presented) and Analysis Completed Date in the period, by Fiduciary Status Basis and Plan Fee Data Source; Rollover Amount is a Derived copy held as recorded, in USD.",
             _u("45", "Rollover Analysis", "Rollover Amount", "Rollover Analysis Status", "Analysis Completed Date",
                "Fiduciary Status Basis", "Plan Fee Data Source")),
        ],
        inputs=[
            ("45", "Advice Engagement", ["Advice Engagement ID", "Engagement Client", "Engagement Type", "Engagement Advice Capacity",
                                         "Engagement Delivery Channel", "Engagement Advisor", "Engagement Service Offering",
                                         "Engagement Advisory Agreement", "Engagement Business Line", "Agreed Review Frequency",
                                         "Engagement Status", "Engagement Start Date", "Engagement End Date"]),
            ("45", "Engagement Participant", ["Participant Engagement", "Participant Party", "Engagement Participant Role",
                                              "Decision Authority Indicator", "Participant Effective From", "Participant Effective To"]),
            ("45", "Advice Review", ["Advice Review ID", "Reviewed Engagement", "Reviewed Program Enrollments", "Advice Review Type",
                                     "Review Due Date", "Review Held Date", "Review Channel", "Review Conducted By",
                                     "Profile Version Confirmed", "Review Outcome", "Next Review Due Date"]),
            ("45", "Financial Goal", ["Financial Goal ID", "Goal Owner", "Goal Type", "Goal Priority", "Goal Target Amount",
                                      "Goal Target Date", "Goal Status", "Goal Source Engagement"]),
            ("45", "Client Financial Plan", ["Client Financial Plan ID", "Plan Subject", "Plan Engagement", "Client Financial Plan Type",
                                             "Client Financial Plan Status"]),
            ("45", "Client Financial Plan Version", ["Client Financial Plan Version ID", "Versioned Plan", "Plan Version Number",
                                                     "Client Financial Plan Version Status", "Plan Data As-Of Date", "Plan Preparer",
                                                     "Plan Profile Version Relied On", "Planning Engine", "Version Assumption Set",
                                                     "Plan Presented Date", "Plan Accepted Date"]),
            ("45", "Planning Assumption Set", ["Assumption Set Code", "Capital Market Assumption Set", "General Inflation Rate",
                                               "Assumption Set Status", "Assumption Set Effective From", "Assumption Set Effective To"]),
            ("45", "Planning Scenario", ["Planning Scenario ID", "Scenario Plan Version", "Planning Scenario Type", "Scenario Assumption Set",
                                         "Projection Method", "Projection Engine", "Scenario Run Timestamp", "Accepted Scenario Indicator"]),
            ("45", "Recommendation", ["Recommendation ID", "Recommendation Type", "Recommendation Capacity", "Recommendation Source",
                                      "Recommending Advisor", "Recommendation Engine", "Recommended Client", "Recommendation Accounts",
                                      "Recommendation Engagement", "Recommendation Profile Version", "Supporting Plan Version",
                                      "Supporting Rollover Analysis", "Recommended Service Offering", "Recommended Model Portfolio",
                                      "Recommended Share Class", "Recommended Instrument", "Recommended Amount",
                                      "Recommendation Channel", "Recommendation Presented Timestamp", "Client Decision",
                                      "Client Decision Date", "Recommendation Status"]),
            ("45", "Recommendation Rationale", ["Rationale Basis", "Profile Factors Considered", "Costs Considered Indicator",
                                                "Alternatives Considered Indicator"]),
            ("45", "Recommendation Alternative", ["Alternative Recommendation", "Alternative Number", "Alternative Estimated Annual Cost"]),
            ("45", "Best Interest Evidence", ["Evidence Recommendation", "Best Interest Component", "Evidence Type", "Conflicts Identified",
                                              "Component Satisfied Indicator", "Evidence Attester", "Evidence Attested Date"]),
            ("45", "Recommendation Implementation Link", ["Implemented Recommendation", "Implementing Record Type", "Implementing Enrollment",
                                                          "Implementing Account", "Implementing Model Assignment",
                                                          "Implementing Client Order", "Implementation Date"]),
            ("45", "Rollover Analysis", ["Rollover Analysis ID", "Rollover Recommendation", "Source Retirement Plan", "Rollover Amount",
                                         "Plan Fee Data Source", "Fiduciary Status Basis", "Best Interest Reasons",
                                         "Rollover Analysis Status", "Analysis Completed Date"]),
            ("45", "PTE 2020-02 Documentation", ["Fiduciary Acknowledgment Delivered Date", "Services and Conflicts Disclosure Delivered Date",
                                                 "Rollover Reasons Delivered Date", "Impartial Conduct Standards Attestation",
                                                 "Attesting Employee"]),
            ("24", "Capital Market Assumption Set", ["Capital Market Assumption Set ID", "CMA Set Version", "CMA Set Status"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status", "Merged Into Party"]),
            ("02", "Investor Profile", ["Investor Profile ID", "Profile Client", "Profile Version Number", "Profile Status"]),
            ("03", "Advisor", ["Employee", "Advisor Status"]),
        ],
        upstream=["DP-240", "DP-093", "DP-004", "DP-009", "DP-097", "DP-530", "DP-212", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a recommendation presented or a client decision recorded is published intraday through the event stream",
        history=("Every engagement, review, goal, plan version, scenario, recommendation and evidence row kept as recorded; SCD type 2 on "
                 "engagement, goal and plan status; recommendation records kept at least 6 years under SEC Rule 17a-4 (Reg BI, Rule 15l-1) "
                 "and 5 years under Rule 204-2 for advisory capacity, whichever is longer; PTE 2020-02 documentation kept 6 years"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "CRM embed"],
        dq_rules=[
            "Every Engagement Client, Participant Party, Goal Owner, Plan Subject and Recommended Client resolves to a DP-240 party with Party Status = Active (or Inactive for closed engagements) and no Merged Into Party; every Engagement Advisor and Recommending Advisor resolves to a DP-009 Advisor; every Recommendation Accounts and Implementing Account to a DP-093 account; Recommended Service Offering, Recommended Model Portfolio and Recommended Share Class to DP-004; Recommended Instrument to DP-097; Recommendation Engine, Planning Engine and Projection Engine to a DP-212 Model Inventory Entry.",
            "Engagement Participant rows for the same Participant Engagement, Participant Party and Engagement Participant Role do not overlap, and Participant Effective To and Engagement End Date are on or after their start dates; Planning Assumption Set versions of one Assumption Set Code do not overlap in effective period.",
            "Recommendation Profile Version and Plan Profile Version Relied On each resolve to a 02 Investor Profile version of the same client whose Profile Status was Active on Recommendation Presented Timestamp (or Plan Data As-Of Date); Capital Market Assumption Set on every Planning Assumption Set equals a CMA Set published by DP-530.",
            "Recommendation Type, Recommendation Capacity, Recommendation Source, Recommendation Profile Version, Recommendation Presented Timestamp and Client Decision are populated on every presented recommendation, and Fiduciary Status Basis, Best Interest Reasons and Analysis Completed Date on every Rollover Analysis with Rollover Analysis Status in (Completed, Presented); Fiduciary Acknowledgment Delivered Date, Services and Conflicts Disclosure Delivered Date, Rollover Reasons Delivered Date and Impartial Conduct Standards Attestation are populated on every Rollover Analysis with Rollover Analysis Status = Presented and Fiduciary Status Basis = Acknowledged Fiduciary - PTE 2020-02.",
            "Account-grain and client-grain rows are published only in the Confidential - Personal Data view to advice, supervision and service roles; the BI semantic model carries counts by dimension only; 45 Client Planning Assumptions, Planning Cash Flow Input rows of type Healthcare Expense and any special-category planning basis are never read or published (CD-344).",
            "A Client Financial Plan Version with Client Financial Plan Version Status = Accepted, and a Recommendation once Client Decision is not Pending, is locked: changes arrive as a new version or a new recommendation, and the prior row is never overwritten.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Advice Engagement (ADENG-), Advice Review (AVREV-), Financial Goal (FGOAL-), "
               "Client Financial Plan (FPLAN-), Planning Scenario (PLNSC-), Recommendation (RECOM-) and Rollover Analysis (ROLV-), all 45; "
               "source of the conformed Recommendation, Advice Engagement and Client Financial Plan dimensions of the WP2 conformed set. "
               "Delivery channel (digital or human) is an attribute, not a separate record (CW-044). Rollup rule: an engagement, goal, plan or "
               "recommendation whose owner (Engagement Client, Goal Owner, Plan Subject, Recommended Client) is a Client Household party is "
               "counted once at household grain and never also at member grain; rows owned by an individual roll up to the household through "
               "DP-240 Household Membership effective on the as-of date. A household engagement is found through Party Type = Household of the "
               "Engagement Client (CW-005), and the 08 Supervisory Review holds the link to the recommendation it reviews, by design. "
               "Certified numbers: none owned (It owns no certified metric family). Personal Rate of Return is DP-145's (CW-251); 45 never computes "
               "returns; Client Assets and Advised Assets are DP-008's. "
               "PII tier: financial. Client and household keys, recommendation and plan rows are personal data; published at row grain only in "
               "the Confidential - Personal Data view, aggregates elsewhere. Special-category data (45 Client Planning Assumptions life "
               "expectancy and healthcare bases, Healthcare Expense cash-flow items) is not read (CD-344, CW-060); Protection Flag Present is not "
               "carried here because DP-322 is consumer-aligned and a foundational product cannot list it; consumers join it from DP-322. "
               "Boundaries: DP-334 (Reg BI file) and DP-335 (rollover and PTE 2020-02 evidence) compute the evidence gap flags from the rows "
               "published here (CW-215) and read the 08 Supervisory Review outcome; this product publishes component-level completeness only. DP-334 defines the Q3 evidence gap flag, including the missing-rationale test, from the Recommendation Rationale and Best Interest Evidence rows published here; this product publishes no rationale-gap measure. The 24 Capital Market Assumption Set and 03 Advisor reads are key checks only; those dimensions are DP-530's and DP-009's. "
               "DP-333 builds the advice funnel from engagements and recommendations; DP-337 reads goals and scenarios with Goal Progress "
               "Snapshot and Goal Projection Result; DP-320 shows engagements, goals and plans. Objects of the candidate not read here and their "
               "readers: Goal Progress Snapshot, Goal Projection Result and Projection Year Result (DP-337, DP-466), Rollover Option Comparison "
               "(DP-335), Planning Cash Flow Input, Planning Balance Sheet Item and Client Planning Assumptions (DP-334), Aggregated Account and "
               "Aggregated Account Balance (DP-320). 15 Program Enrollment.Source Recommendation and 48 Client Order.Source Recommendation are "
               "keys into this product: DP-301 and DP-430 list this product upstream (F3 ruling), so DP-300, DP-301, DP-302, DP-430 and DP-580 "
               "are never listed here; DP-093 carries the 15 keys and must not list DP-303 because this product lists DP-093. "
               "Acceptance question 3: feeds DP-334 and DP-335 with Recommendation, Best Interest Evidence, Rollover Analysis and PTE 2020-02 "
               "Documentation rows and the measures Unattested Evidence Components and Rollover "
               "Recommendations Without Analysis. Acceptance question 10: feeds DP-467 with Rollover Analysis and Rollover Amount Analyzed. "
               "Tailoring lever: goals per client or per household (45 SME 1). Reference default: either; Goal Owner is a 02 party or PTY-HH-. "
               "Tailoring lever: brokerage security recommendations recorded (45 SME 2). Reference default: every recommendation the firm defines "
               "under Reg BI, including Security type. Tailoring lever: digital advice plans (45 SME 3). Reference default: plan type Goal-Only "
               "with versions. Tailoring lever: Rule 3a-4 annual contact (45 SME 4). Reference default: an Advice Review that confirms or creates "
               "a 02 profile version. Tailoring lever: rollover fiduciary status (45 SME 9). Reference default: every rollover recommendation is "
               "Acknowledged Fiduciary - PTE 2020-02. Tailoring lever: planning engines (45 SME 8). Reference default: one in-house engine "
               "inventoried in 37 (DP-212). Tailoring lever: plan data currency threshold. Reference default: 12 months. "
               "Taxonomy gap: 45 has no record of which Best Interest Component values a Recommendation Capacity requires, so a missing "
               "component row cannot be told from a component not required; the rule sits in DP-334. " + GAP6 + ""
               "Drafting assumptions: Engagement Status = Active; Client Financial Plan Status = Active (shared Record Status); Assumption Set "
               "Status and CMA Set Status = Active; Client Decision values Accepted and Accepted with Changes count as acceptance; the 12-month "
               "plan data threshold and trailing 12-month Rule 3a-4 window; every presented plan version is expected to carry an accepted scenario (Plan Versions Without Accepted Scenario). "
               "Decisions: CW-008, CW-015, CW-024, CW-042, CW-043, CW-044, CW-045, CW-046, CW-205, CW-215, CW-251, CW-213, CD-294, CD-344. "
               "WP1 new (CW-205): first specification; inputs taken from the framing candidate, adding 45 Planning Assumption Set, Planning "
               "Scenario and the DP-530 CMA set link for plan currency."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-304": dict(
        definition=("The conformed record of how every retail managed account is managed: the model assigned to each account under "
                    "its program enrollment, with sleeves, the account target and its override lines, investment constraints, tax "
                    "management settings and household managed groups, and the operating facts 46 produces on them: drift "
                    "assessments, trade proposal batches and proposals up to release, tax-loss harvest decisions, wash sale control "
                    "windows and the membership of each managed account composite. It publishes the CONCEPT_OWNERSHIP rows Model "
                    "Assignment (MASGN-), Managed Account Target, Account Investment Constraint, Drift Assessment, Trade Proposal, "
                    "Tax-Loss Harvest Decision, Wash Sale Control Window and Managed Account Composite (46) once, so that drift, "
                    "rebalancing, harvesting, billing, program performance and the managed-account slice read the same accounts and "
                    "models. A retail managed account is a 15 account managed in 46, never an 18 portfolio. It owns no certified "
                    "metric family."),
        business_questions=[
            "Which managed accounts have an active model assignment today, under which program and model, with what discretion and Regulatory AUM Classification, and which active enrollments have none?",
            "Which assignments lack an approved account target, run a custom target, or apply a model target set that is not the model's effective set in DP-530?",
            "Which accounts have no current drift assessment, or were assessed on stale Client Holding data?",
            "How many trade proposals were released in the period by reason and route, and which released proposals have no order or participant transfer link?",
            "How many harvest decisions were taken, how much unrealized loss was harvested and with what estimated tax saving, which harvests opened no wash sale window, and how many windows are open?",
            "Which accounts are members of each managed account composite, and which members fail the discretion check?",
        ],
        grain=("Managed account (15) x model assignment x assignment period, with sleeves, account target version, override lines, "
               "constraints, tax management settings and composite memberships as conformed attributes; companion facts drift "
               "assessment (account x timestamp), trade proposal (batch x account x instrument x side), tax-loss harvest decision "
               "and wash sale control window; SCD type 2 on assignments, targets, constraints and memberships"),
        dimensions=["Client account (DP-093)", "Client Household (DP-240)", "Program enrollment and service offering (DP-004)",
                    "Model portfolio (DP-004)", "Model target set (DP-530)", "Sub-adviser engagement (DP-306)", "Instrument (DP-097)",
                    "Regulatory AUM Classification", "Discretion exercised", "Assignment reason", "Constraint type", "Proposal reason",
                    "Execution route", "Harvest decision", "Managed account composite", "Assessment date (DP-013)"],
        measures=[
            ("Active Model Assignments",
             "Count of Model Assignment ID with Assignment Status = Active and Assignment Effective From <= as-of date < Assignment Effective To (or open), by Assigned Model Portfolio, Regulatory AUM Classification and Discretion Exercised.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assignment Status", "Assignment Effective From", "Assignment Effective To",
                "Assigned Model Portfolio", "Regulatory AUM Classification", "Discretion Exercised")),
            ("Active Enrollments Without Model Assignment",
             "Count of 15 Program Enrollment ID with Enrollment Status = Active in a Service Offering whose Model Portfolios Used is populated, for which no Active Model Assignment has Assignment Program Enrollment = Program Enrollment ID, by Enrolled Service Offering.",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrollment Status", "Enrolled Service Offering")
             + _u("01", "Service Offering", "Offering ID", "Model Portfolios Used")
             + _u("46", "Model Assignment", "Assignment Program Enrollment") + ["Active Model Assignments"]),
            ("Discretion Mismatch Assignments",
             "Active Model Assignments where Discretion Exercised in (Full Discretion, Limited Discretion - Rebalance Only) and the enrollment's Discretionary Authority Indicator is not Y, or Regulatory AUM Classification = Discretionary and Discretion Exercised = Non-Discretionary, or the offering's Discretion Type = Non-Discretionary and Regulatory AUM Classification = Discretionary.",
             _u("46", "Model Assignment", "Discretion Exercised", "Regulatory AUM Classification", "Assignment Program Enrollment")
             + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Service Offering", "Discretionary Authority Indicator")
             + _u("01", "Service Offering", "Offering ID", "Discretion Type") + ["Active Model Assignments"]),
            ("Model Changes",
             "Count of Model Assignment rows with Assignment Effective From in the period and Previous Model Assignment populated, by Assignment Reason and from and to Assigned Model Portfolio.",
             _u("46", "Model Assignment", "Assignment Effective From", "Previous Model Assignment", "Assignment Reason",
                "Assigned Model Portfolio")),
            ("Assignments Without Approved Target",
             "Active Model Assignments with no Managed Account Target (Target Model Assignment = Model Assignment ID) whose Target Approval Status = Approved and Target Effective From <= as-of date.",
             _u("46", "Managed Account Target", "Target Model Assignment", "Target Approval Status", "Target Effective From")
             + ["Active Model Assignments"]),
            ("Custom Target Accounts",
             "Count of distinct Assigned Account of Active Model Assignments whose current approved Managed Account Target (Target Model Assignment = Model Assignment ID, Target Approval Status = Approved) has Custom Target Indicator = Y or at least one Account Target Override Line (Override Account Target), by Override Reason.",
             _u("46", "Managed Account Target", "Target Model Assignment", "Custom Target Indicator", "Account Target Version",
                "Target Approval Status")
             + _u("46", "Account Target Override Line", "Override Account Target", "Override Reason")
             + _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account") + ["Active Model Assignments"]),
            ("Targets Not on Effective Model Set",
             "Current approved Managed Account Target rows (joined to their assignment by Target Model Assignment = Model Assignment ID) with Custom Target Indicator other than Y whose Applied Model Target Set resolves to a 24 Target Allocation Set (from DP-530) with Target Subject Type other than Model Portfolio, Target Set Status other than Effective, or Target Model Portfolio different from the assignment's Assigned Model Portfolio.",
             _u("46", "Managed Account Target", "Target Model Assignment", "Applied Model Target Set", "Custom Target Indicator")
             + _u("24", "Target Allocation Set", "Target Set ID", "Target Subject Type", "Target Set Status", "Target Model Portfolio")
             + _u("46", "Model Assignment", "Model Assignment ID", "Assigned Model Portfolio")),
            ("Active Investment Constraints",
             "Count of Account Investment Constraint rows with Constraint Status = Active and Constraint Effective From <= as-of date < Constraint Effective To (or open), by Constraint Type and Implementation Rule.",
             _u("46", "Account Investment Constraint", "Constrained Account", "Constraint Status", "Constraint Effective From",
                "Constraint Effective To", "Constraint Type", "Implementation Rule")),
            ("Constraints Without Source",
             "Active Investment Constraints whose Source Client Restriction and Source Trust Term Provision are both blank.",
             _u("46", "Account Investment Constraint", "Source Client Restriction", "Source Trust Term Provision")
             + ["Active Investment Constraints"]),
            ("Accounts Without Current Drift Assessment",
             "Count of Assigned Account of Active Model Assignments with no Drift Assessment (Assessed Account) whose Assessment Timestamp is within the last business day where the offering of its enrollment (Assignment Program Enrollment = Program Enrollment ID, Enrolled Service Offering = Offering ID) has Delivery Mode = Digital Only, or within the last 90 days otherwise, by Delivery Mode.",
             _u("46", "Drift Assessment", "Assessed Account", "Assessment Timestamp")
             + _u("46", "Model Assignment", "Assigned Account", "Assignment Program Enrollment")
             + _u("15", "Program Enrollment", "Program Enrollment ID", "Enrolled Service Offering")
             + _u("01", "Service Offering", "Offering ID", "Delivery Mode") + ["Active Model Assignments"]),
            ("Drift Assessments on Stale Holdings",
             "Count of Drift Assessment ID with Assessment Timestamp in the period where Assessment Timestamp minus Holdings As-Of Timestamp exceeds one business day, by Drift Method.",
             _u("46", "Drift Assessment", "Drift Assessment ID", "Assessment Timestamp", "Holdings As-Of Timestamp", "Drift Method")),
            ("Trade Proposals Released",
             "Count of Trade Proposal ID with Proposal Status = Released and Release Timestamp in the period, by Proposal Reason, Execution Route, Proposal Side and the Batch Program of its Proposal Batch (Batch ID), with the sum of Proposed Amount (USD).",
             _u("46", "Trade Proposal", "Trade Proposal ID", "Proposal Status", "Release Timestamp", "Proposal Reason", "Execution Route",
                "Proposal Side", "Proposed Amount", "Proposal Batch") + _u("46", "Trade Proposal Batch", "Batch ID", "Batch Program")),
            ("Released Proposals Without Execution Link",
             "Trade Proposals Released with Execution Route = Brokerage Client Order and Released Client Order blank, or Execution Route = Participant Investment Transfer and Released Participant Investment Transfer blank.",
             _u("46", "Trade Proposal", "Execution Route", "Released Client Order", "Released Participant Investment Transfer")
             + ["Trade Proposals Released"]),
            ("Harvest Decisions",
             "Count of Harvest Decision ID with Scan Timestamp in the period, by Harvest Decision and Harvest Skip Reason.",
             _u("46", "Tax-Loss Harvest Decision", "Harvest Decision ID", "Scan Timestamp", "Harvest Decision", "Harvest Skip Reason")),
            ("Harvested Unrealized Loss",
             "Sum of Unrealized Loss at Scan of Tax-Loss Harvest Decision rows with Harvest Decision in (Harvest, Partial Harvest) and Scan Timestamp in the period, by Harvest Loss Term (a Derived copy of 49 Client Tax Lot values as of the scan, USD; held and reported as a negative amount, as 46 records it).",
             _u("46", "Tax-Loss Harvest Decision", "Unrealized Loss at Scan", "Harvest Decision", "Scan Timestamp", "Harvest Loss Term")),
            ("Estimated Harvest Tax Saving",
             "Sum of Estimated Tax Saving of Tax-Loss Harvest Decision rows with Harvest Decision in (Harvest, Partial Harvest) and Scan Timestamp in the period, by Tax Saving Method and Harvest Loss Term (USD, as 46 masters it); DP-342 reads it from here and never recomputes it.",
             _u("46", "Tax-Loss Harvest Decision", "Estimated Tax Saving", "Tax Saving Method", "Harvest Loss Term", "Harvest Decision",
                "Scan Timestamp")),
            ("Harvests Without Wash Sale Window",
             "Harvest Decisions with Harvest Decision in (Harvest, Partial Harvest) whose Resulting Wash Sale Window is blank and for which no Wash Sale Control Window has Triggering Harvest Decision = Harvest Decision ID.",
             _u("46", "Tax-Loss Harvest Decision", "Resulting Wash Sale Window", "Harvest Decision")
             + _u("46", "Wash Sale Control Window", "Triggering Harvest Decision") + ["Harvest Decisions"]),
            ("Open Wash Sale Windows",
             "Count of Wash Sale Control Window rows with Window Status = Open and Window Start Date <= as-of date <= Window End Date, by Window Security Group, with the count of Controlled Accounts in Scope and Monitored Accounts in Scope.",
             _u("46", "Wash Sale Control Window", "Window Status", "Window Start Date", "Window End Date", "Window Security Group",
                "Controlled Accounts in Scope", "Monitored Accounts in Scope")),
            ("Active Composite Members",
             "Count of Managed Account Composite Membership rows with Membership Start Date <= as-of date and Membership End Date blank or after the as-of date, in composites with Composite Status = Active, by Membership Composite.",
             _u("46", "Managed Account Composite Membership", "Membership Composite", "Member Account", "Membership Start Date",
                "Membership End Date") + _u("46", "Managed Account Composite", "Managed Account Composite ID", "Composite Status")),
            ("Composite Members Failing Discretion Check",
             "Active Composite Members with Discretion Check Passed Indicator other than Y, or whose Membership Model Assignment has Discretion Exercised = Non-Discretionary.",
             _u("46", "Managed Account Composite Membership", "Discretion Check Passed Indicator", "Membership Model Assignment")
             + _u("46", "Model Assignment", "Discretion Exercised") + ["Active Composite Members"]),
        ],
        inputs=[
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status",
                                          "Enrollment Effective Date", "Enrollment Termination Date", "Discretionary Authority Indicator"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Program Enrollment", "Assigned Model Portfolio",
                                        "Source Recommendation", "Assignment Reason", "Discretion Exercised",
                                        "Regulatory AUM Classification", "Assignment Status", "Assignment Effective From",
                                        "Assignment Effective To", "Previous Model Assignment", "Assignment Approved By"]),
            ("46", "Tax Management Setting", ["Tax-Loss Harvesting Elected", "Minimum Harvest Loss Amount", "Short-Term Gain Avoidance Indicator",
                                              "Asset Location Enabled Indicator", "Managed Sale Lot Selection Method",
                                              "Tax Setting Effective From"]),
            ("46", "Sleeve Assignment", ["Sleeve Model Assignment", "Sleeve Sequence", "Sleeve Model Portfolio",
                                         "Sleeve Sub-Adviser Engagement", "Sleeve Effective From", "Sleeve Effective To"]),
            ("46", "Household Managed Group", ["Managed Group Household", "Group Member Account", "Managed-Together Basis",
                                               "Group Membership Status", "Group Effective From", "Group Effective To"]),
            ("46", "Managed Account Target", ["Target Model Assignment", "Account Target Version", "Applied Model Target Set",
                                              "Custom Target Indicator", "Account Cash Target", "Asset Class Drift Tolerance",
                                              "Target Approval Status", "Target Effective From"]),
            ("46", "Account Target Override Line", ["Override Account Target", "Override Asset Class", "Override Instrument",
                                                    "Override Weight", "Override Reason"]),
            ("46", "Account Investment Constraint", ["Constrained Account", "Source Client Restriction", "Source Trust Term Provision",
                                                     "Constraint Type", "Implementation Rule", "Constraint Status",
                                                     "Constraint Effective From", "Constraint Effective To"]),
            ("46", "Drift Assessment", ["Drift Assessment ID", "Assessed Account", "Assessed Account Target", "Assessment Timestamp",
                                        "Holdings As-Of Timestamp", "Total Drift", "Tolerance Breached Indicator", "Drift Method"]),
            ("46", "Trade Proposal Batch", ["Batch ID", "Batch Program", "Batch Cycle Date", "Batch Status", "Batch Released Timestamp",
                                            "Batch Proposal Count"]),
            ("46", "Trade Proposal", ["Trade Proposal ID", "Proposal Batch", "Proposal Account", "Proposal Instrument", "Proposal Side",
                                      "Proposed Quantity", "Proposed Amount", "Proposal Reason", "Proposal Status", "Execution Route",
                                      "Released Client Order", "Released Participant Investment Transfer", "Release Timestamp"]),
            ("46", "Tax-Loss Harvest Decision", ["Harvest Decision ID", "Harvest Account", "Scan Timestamp", "Security Sold",
                                                 "Harvest Client Tax Lots", "Replacement Security", "Unrealized Loss at Scan",
                                                 "Harvest Loss Term", "Estimated Tax Saving", "Tax Saving Method", "Harvest Decision", "Harvest Skip Reason", "Resulting Wash Sale Window"]),
            ("46", "Wash Sale Control Window", ["Window Household", "Window Account", "Window Security Group", "Triggering Harvest Decision",
                                                "Window Start Date", "Window End Date", "Controlled Accounts in Scope",
                                                "Monitored Accounts in Scope", "Window Status"]),
            ("46", "Managed Account Composite", ["Managed Account Composite ID", "Composite Name", "Composite Program",
                                                 "Composite Model Portfolio", "Composite Minimum Account Value", "Linked GIPS Composite",
                                                 "Composite Status", "Composite Effective From", "Composite Effective To"]),
            ("46", "Managed Account Composite Membership", ["Membership Composite", "Member Account", "Membership Model Assignment",
                                                            "Membership Start Date", "Membership End Date",
                                                            "Discretion Check Passed Indicator", "Composite Exclusion Reason"]),
            ("24", "Target Allocation Set", ["Target Set ID", "Target Subject Type", "Target Model Portfolio", "Target Set Status"]),
            ("01", "Service Offering", ["Offering ID", "Offering Type", "Delivery Mode", "Discretion Type", "Wrap Fee Program Indicator",
                                        "Model Portfolios Used"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name"]),
        ],
        upstream=["DP-093", "DP-240", "DP-004", "DP-530", "DP-306", "DP-097", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET on each business day for assignments, targets and constraints; drift assessments, proposals and harvest decisions intraday through the event stream as 46 records them",
        history=("SCD type 2 on assignments, sleeves, targets, override lines, constraints, household groups and composite memberships since "
                 "account inception; every drift assessment, proposal, harvest decision and wash sale window kept; at least 5 years under "
                 "Advisers Act Rule 204-2 (6 years where a proposal becomes a 48 order record under SEC Rule 17a-4)"),
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Assigned Account, Group Member Account, Constrained Account, Assessed Account, Proposal Account, Harvest Account and Member Account resolves to an open DP-093 account; every Assignment Program Enrollment to a DP-093 Program Enrollment of the same account; Managed Group Household and Window Household to a DP-240 party with Party Type = Household; Assigned Model Portfolio and Sleeve Model Portfolio to DP-004; Sleeve Sub-Adviser Engagement to a DP-306 Sub-Adviser Engagement; Proposal Instrument and Security Sold to DP-097.",
            "No account has two Model Assignment rows with Assignment Status = Active whose effective periods overlap, Household Managed Group and composite memberships of one account do not overlap for the same group or composite, and every effective-to or end date is on or after its start.",
            "Every Applied Model Target Set of a non-custom target equals a model-subject Target Allocation Set published by DP-530 for the assignment's Assigned Model Portfolio, and every Harvest Client Tax Lots value is a 49 Client Tax Lot key (CTLOT-) of the Harvest Account, checked by key format and account only because DP-300 is not upstream.",
            "Discretion Exercised, Regulatory AUM Classification and Assignment Effective From are populated on every active assignment, Asset Class Drift Tolerance on every approved target, and Total Drift and Tolerance Breached Indicator on every Drift Assessment.",
            "Account-grain rows are published only in the Confidential - Client view to managed account operations, advice, billing and supervision roles; the BI semantic model carries counts and amounts by program, model and composite only; Applied Federal Marginal Tax Rate and Tax Rate Source Profile are not read or published.",
            "A Trade Proposal with Proposal Status = Released, and a Drift Assessment or Tax-Loss Harvest Decision once recorded, is immutable; the nightly snapshot of assignments and targets is published by 6am ET.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Model Assignment (MASGN-), Managed Account Target, Account Investment Constraint, Drift "
               "Assessment (DRFT-), Trade Proposal (TRPR-), Trade Proposal Batch (TPBAT-), Tax-Loss Harvest Decision (TLH-), Wash Sale Control "
               "Window and Managed Account Composite (MACP-), all 46; source of the conformed Model Assignment and Managed Account Composite "
               "dimensions of the WP2 conformed set. The model (01 MDL-) is DP-004's; model weights are DP-530's (CD-176, CW-047); the "
               "enrollment is 15's through DP-093. "
               "Certified numbers: none owned (It owns no certified metric family). The managed-account slice of Firm AUM is published by "
               "DP-345 over this product and DP-300 (CW-212 as proposed; CW-206), and DP-241 certifies it; no market value or AUM amount is "
               "summed here. Returns and composite performance are DP-145's (CW-251). "
               "PII tier: financial. Account-grain rows only in the Confidential - Client view; aggregates elsewhere. Book of record: Client "
               "Holding (49); drift and harvest values are Derived copies of 49 held as of their timestamps, never re-mastered (CW-007). "
               "DP-300 is not listed upstream (coordinator ruling 2026-10-15: DP-301 lists DP-304 and DP-300 lists DP-301, so the edge would "
               "close a cycle); 49 facts are read only as the Derived copies and keys the 46 row rules define. "
               "Boundaries: DP-341 decides drift and rebalance (Tolerance Breached Indicator, Drift Assessment Line, Account Rebalance Event, "
               "Proposed Client Lot Selection, Trade Proposal Exception, Managed Account Cash Instruction); DP-342 measures harvest effectiveness "
               "and reads Estimated Tax Saving and Tax Saving Method from this product, never recomputing them (with Account Tax Budget, Asset Location Decision, Model Change Implementation, Substantially Identical Security "
               "Group); DP-345 publishes managed assets by model and composite; DP-346 bills from the enrollments; proposals end at release to "
               "48 (CW-049, CW-010). Edge direction: 48 Client Order.Source Trade Proposal and 50 Money Movement.Source Managed Account Cash "
               "Instruction are keys into this product; DP-301 lists this product upstream (F3 ruling) and DP-300, DP-301, DP-302, DP-430 and "
               "DP-580 are never listed here; this product "
               "carries Released Client Order and Released Participant Investment Transfer as keys only. Account Investment Constraint.Source "
               "Trust Term Provision is read as a key only so that this product does not depend on the optional DP-307. "
               "Acceptance question 4: feeds DP-341 with Drift Assessment rows and Accounts Without Current Drift Assessment, and DP-342 with "
               "Tax-Loss Harvest Decision rows, Harvested Unrealized Loss, Estimated Harvest Tax Saving and Open Wash Sale Windows. Acceptance question 1: feeds DP-345 (and "
               "through it DP-241) with Active Model Assignments by Regulatory AUM Classification and Active Composite Members. "
               "Tailoring lever: wrap and managed account composites presented under GIPS (46 SME 8). Reference default: operational only; "
               "Linked GIPS Composite is populated only where the wrap-composite lever is taken, and a blank link is not a defect. Tailoring "
               "lever: model assigned per account or per household (46 SME 1). Reference default: per account, with a Household Managed Group "
               "for asset location and wash-sale scope. Tailoring lever: multi-sleeve accounts (46 SME 2). Reference default: Sleeve Assignment "
               "kept, sleeves sharing the account target. Tailoring lever: wash sale window scope (46 SME 3). Reference default: the seller's and "
               "spouse's accounts in the household managed group, managed accounts blocked and self-directed accounts monitored. Tailoring lever: "
               "drift cadence (46 SME 6). Reference default: daily for Digital Only offerings, on event (90-day backstop) for advisor-led ones. "
               "Tailoring lever: participant managed account proposals (46 SME 10). Reference default: released as 16 Participant Investment "
               "Transfers. "
               "Boundary note: the drift cadence is read through the enrollment's Service Offering Delivery Mode, the normalized design; Linked "
               "GIPS Composite is the GIPS presentation indicator. The 24 Target Allocation Set and 01 Service Offering and Model Portfolio "
               "reads are key checks only; those dimensions are DP-530's and DP-004's. " + GAP6 + ""
               "Drafting assumptions: Assignment Status, Constraint Status and Composite Status = Active (Record Status); Target Approval Status "
               "= Approved; Enrollment Status = Active; the one-business-day holdings staleness and drift recency thresholds; the 90-day backstop; every active constraint is expected to have a client-restriction or trust-term source, so a firm-imposed constraint counts in Constraints Without Source until 46 records such a source. "
               "Decisions: CW-007, CW-010, CW-047, CW-048, CW-049, CW-050, CW-205, CW-206, CW-212, CW-250, CW-251, CD-176. "
               "WP1 new (CW-205): first specification. The foundational products carry the facts the candidates had given to consumers: this product publishes "
               "Drift Assessment, Trade Proposal Batch, Trade Proposal, Tax-Loss Harvest Decision and Wash Sale Control Window, and DP-341 and "
               "DP-342 read them from here and do not redefine them. Adds the DP-530 model target set link."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-305": dict(
        definition=("The conformed record of client billing as 47 masters it: fee schedules and their versions, tiers and performance fee "
                    "terms, the schedules linked to each 01 offering, schedule assignments to enrollments, accounts, advice engagements "
                    "and mandates (billing arrangements), rate overrides, fee households and their member accounts, fee waivers, and every "
                    "fee calculation run with its account fee calculations, fee debits, fee invoices, fee adjustments and billing disputes, "
                    "together with fee deduction authorizations and fee disclosure deliveries. It publishes the CONCEPT_OWNERSHIP rows Fee "
                    "Schedule (CLFEE-), Fee Schedule Assignment, Fee Household, Fee Calculation Run, Fee Debit, Fee Invoice, Fee Waiver and "
                    "Billing Arrangement (47) once, so that billing accuracy, custody-rule evidence, pricing realization and client fee "
                    "revenue read the same schedules and runs. It publishes billed, waived, adjusted and collected amounts, never "
                    "recognized revenue: certified client fee revenue is DP-012's. It owns no certified metric family."),
        business_questions=[
            "Which fee schedule versions are active today, by schedule type, billing basis and tier method, and which active enrollments have no fee schedule assignment?",
            "Which assignments carry negotiated rate overrides or fee waivers, and which fee households and member accounts set the breakpoints?",
            "What did each fee calculation run bill, gross and net, on what billable assets and at what effective annual rate, and does each run's control total tie to its account calculations?",
            "Which fee debits failed, which invoices are outstanding, and what fee adjustments and open billing disputes were recorded?",
            "Which accounts hold an active fee deduction authorization, and which fee disclosures were delivered in the period?",
        ],
        grain=("Account fee calculation: fee calculation run x billed subject (fee schedule assignment or billing arrangement), with the fee "
               "debit and fee invoice it produced, adjustments and disputes as companion facts; companion masters fee schedule x version x "
               "tier, fee schedule assignment x period, fee household x member account x period, waivers, authorizations and disclosure "
               "deliveries; runs kept as recorded, masters SCD type 2"),
        dimensions=["Client account (DP-093)", "Program enrollment and service offering (DP-004)", "Client Household and bill-to party (DP-240)",
                    "Advice engagement (DP-303)", "Investment mandate (DP-004)", "Fee schedule and version", "Fee schedule type",
                    "Billing basis", "Billing frequency and timing", "Fee collection method", "Fee household (47 fee aggregation group)",
                    "Run type", "Billing period (DP-013)", "Waiver reason", "Adjustment type", "Custody rule basis"],
        measures=[
            ("Active Fee Schedule Versions",
             "Count of Fee Schedule ID x Schedule Version Number with Schedule Status = Active and Version Effective From <= as-of date < Version Effective To (or open), by Fee Schedule Type, Billing Basis and Tier Method.",
             _u("47", "Fee Schedule", "Fee Schedule ID", "Schedule Version Number", "Schedule Status", "Version Effective From",
                "Version Effective To", "Fee Schedule Type", "Billing Basis", "Tier Method")),
            ("Active Fee Schedule Assignments",
             "Count of Fee Schedule Assignment ID with Assignment Effective From <= as-of date < Assignment Effective To (or open), by Fee Schedule Type of the Assigned Fee Schedule, Fee Collection Method and Negotiated Rate Indicator.",
             _u("47", "Fee Schedule Assignment", "Fee Schedule Assignment ID", "Assignment Effective From", "Assignment Effective To",
                "Assigned Fee Schedule", "Fee Collection Method", "Negotiated Rate Indicator") + _u("47", "Fee Schedule", "Fee Schedule Type")),
            ("Active Enrollments Without Fee Schedule Assignment",
             "Count of 15 Program Enrollment ID with Enrollment Status = Active for which no active Fee Schedule Assignment has Billed Enrollment = Program Enrollment ID, by Enrolled Service Offering.",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrollment Status", "Enrolled Service Offering")
             + _u("47", "Fee Schedule Assignment", "Billed Enrollment") + ["Active Fee Schedule Assignments"]),
            ("Assignments Off Offering Schedule",
             "Active Fee Schedule Assignments with Billed Enrollment populated and Negotiated Rate Indicator other than Y whose Assigned Fee Schedule is not the Linked Fee Schedule of an 01 Offering Fee Schedule Link for the enrollment's Enrolled Service Offering (Linked Offering) effective on the as-of date (Link Effective From / To); a master-data check of the assignment, not DP-346's off-schedule flag, which re-performs the billed rate.",
             _u("47", "Fee Schedule Assignment", "Billed Enrollment", "Assigned Fee Schedule", "Negotiated Rate Indicator")
             + _u("01", "Offering Fee Schedule Link", "Linked Offering", "Linked Fee Schedule", "Link Effective From", "Link Effective To")
             + _u("15", "Program Enrollment", "Enrolled Service Offering") + ["Active Fee Schedule Assignments"]),
            ("Active Rate Overrides",
             "Count of Fee Rate Override rows with Override Effective From <= as-of date and Override Expiry Date blank or after the as-of date, by Override Reason, with the count where Override Approved By is blank.",
             _u("47", "Fee Rate Override", "Overridden Assignment", "Override Effective From", "Override Expiry Date", "Override Reason",
                "Override Approved By")),
            ("Fee Household Member Accounts",
             "Count of Fee Household Membership rows with Fee Household Membership Status = Active and Fee Household Membership Effective From <= as-of date < Fee Household Membership Effective To (or open), in Fee Households with Fee Household Status = Active, by Formation Basis.",
             _u("47", "Fee Household Membership", "Membership Fee Household", "Member Account", "Fee Household Membership Status",
                "Fee Household Membership Effective From", "Fee Household Membership Effective To")
             + _u("47", "Fee Household", "Fee Household ID", "Fee Household Status", "Formation Basis")),
            ("Active Fee Waivers",
             "Count of Fee Waiver ID whose Waiver Period Start <= as-of date <= Waiver Period End (or open), by Waiver Reason, with the count where Waiver Approved By is blank.",
             _u("47", "Fee Waiver", "Fee Waiver ID", "Waiver Period Start", "Waiver Period End", "Waiver Reason", "Waiver Approved By")),
            ("Fee Calculation Runs",
             "Count of Fee Calculation Run ID with Run Billing Period End in the period, by Run Type, Run Status and Fee Reconciliation Status.",
             _u("47", "Fee Calculation Run", "Fee Calculation Run ID", "Run Billing Period End", "Run Type", "Run Status",
                "Fee Reconciliation Status")),
            ("Run Control Total Variance",
             "For each Fee Calculation Run with Run Status in (Approved, Released): Run Net Fee Total minus the sum of Net Fee of its Account Fee Calculation rows (Calculation Run = Fee Calculation Run ID), USD.",
             _u("47", "Fee Calculation Run", "Fee Calculation Run ID", "Run Status", "Run Net Fee Total")
             + _u("47", "Account Fee Calculation", "Calculation Run", "Net Fee")),
            ("Billable Assets Billed",
             "Sum of Billable Assets over the billed calculation set: Account Fee Calculation rows (Calculation Run = Fee Calculation Run ID) of runs with Run Status = Released, Run Type other than Simulation and Run Billing Period End in the period, keeping for each billed subject (Calculated Assignment or Calculated Billing Arrangement) and billing period only the row of the latest released run, so a Recalculation run replaces the run it corrects and is never added to it; at each run's Valuation As-Of Date, by Fee Schedule Type of Schedule Version Applied and billing period; a Derived copy of 49 (or 18 for mandates), never Client Assets.",
             _u("47", "Account Fee Calculation", "Calculation Run", "Calculated Assignment", "Calculated Billing Arrangement",
                "Billable Assets", "Schedule Version Applied")
             + _u("47", "Fee Calculation Run", "Fee Calculation Run ID", "Run Status", "Run Type", "Run Billing Period End",
                  "Valuation As-Of Date") + _u("47", "Fee Schedule", "Fee Schedule Type")),
            ("Gross Billed Fees",
             "Sum of Gross Fee over the billed calculation set of Billable Assets Billed (one row per billed subject, billing period and latest released run; Simulation runs excluded), by Fee Schedule Type of Schedule Version Applied and the Fee Collection Method of the Calculated Assignment (Fee Schedule Assignment ID) (USD); billed, not recognized revenue.",
             _u("47", "Account Fee Calculation", "Gross Fee", "Calculation Run", "Calculated Assignment", "Schedule Version Applied")
             + _u("47", "Fee Calculation Run", "Fee Calculation Run ID") + _u("47", "Fee Schedule", "Fee Schedule Type")
             + _u("47", "Fee Schedule Assignment", "Fee Schedule Assignment ID", "Fee Collection Method") + ["Billable Assets Billed"]),
            ("Fee Reductions Applied",
             "Sum of Discount Amount + Waiver Amount Applied + Own-Fund Credit Amount of the same Account Fee Calculation rows as Gross Billed Fees, by component.",
             _u("47", "Account Fee Calculation", "Discount Amount", "Waiver Amount Applied", "Own-Fund Credit Amount") + ["Gross Billed Fees"]),
            ("Net Billed Fees",
             "Sum of Net Fee of the same Account Fee Calculation rows as Gross Billed Fees (USD), by Fee Schedule Type, Fee Collection Method and billing period; DP-012 reads it to tie certified client fee revenue and never the reverse.",
             _u("47", "Account Fee Calculation", "Net Fee") + ["Gross Billed Fees"]),
            ("Average Effective Annual Rate",
             "Sum of (Effective Annual Rate x Billable Assets) / sum of Billable Assets over the billed calculation set of Billable Assets Billed, by Fee Schedule Type and Fee Household Assets band; an operational billed rate, neither DP-012's certified Effective Net Fee Rate nor DP-346's off-schedule flag.",
             _u("47", "Account Fee Calculation", "Effective Annual Rate", "Billable Assets", "Fee Household Assets") + ["Billable Assets Billed"]),
            ("Failed Fee Debits",
             "Count and sum of Debit Amount of Fee Debit ID with Fee Debit Status = Failed and Debit Date in the period, by Debit Failure Reason and Charged Fee Type.",
             _u("47", "Fee Debit", "Fee Debit ID", "Fee Debit Status", "Debit Date", "Debit Amount", "Debit Failure Reason", "Charged Fee Type")),
            ("Outstanding Fee Invoice Amount",
             "Sum of Invoice Total of Fee Invoice ID with Payment Status in (Issued, Partially Paid, Overdue, Disputed) on the as-of date, by Payment Status and age band of Invoice Date (Payment Status is a Derived copy of 19).",
             _u("47", "Fee Invoice", "Invoice ID", "Invoice Total", "Payment Status", "Invoice Date")),
            ("Performance Fees Invoiced",
             "Sum of Performance Fee Amount of Fee Invoice rows with Invoice Date in the period, by the Hurdle Type and High-Water Mark Indicator of the billing arrangement's Applied Fee Schedule (Performance Fee Terms).",
             _u("47", "Fee Invoice", "Performance Fee Amount", "Invoice Date", "Invoice Billing Arrangement")
             + _u("47", "Billing Arrangement", "Billing Arrangement ID", "Applied Fee Schedule")
             + _u("47", "Performance Fee Terms", "Hurdle Type", "High-Water Mark Indicator")),
            ("Fee Adjustment Amount",
             "Sum of Adjustment Amount Value of Fee Adjustment ID by Adjustment Type, dated by the Billing Period End of the Adjusted Invoice or the Run Billing Period End of the Adjusted Fee Calculation's run.",
             _u("47", "Fee Adjustment", "Fee Adjustment ID", "Adjustment Amount Value", "Adjustment Type", "Adjusted Invoice",
                "Adjusted Fee Calculation") + _u("47", "Fee Invoice", "Billing Period End")
             + _u("47", "Fee Calculation Run", "Run Billing Period End")),
            ("Open Billing Disputes",
             "Count and sum of Disputed Amount of Billing Dispute ID with Dispute Status not in (Resolved / Completed, Closed, Rejected, Canceled), by Dispute Reason.",
             _u("47", "Billing Dispute", "Billing Dispute ID", "Dispute Status", "Disputed Amount", "Dispute Reason")),
            ("Active Fee Deduction Authorizations",
             "Count of Fee Deduction Authorization rows with Authorization Status = Active, Authorization Effective Date <= as-of date and Authorization Revoked Date blank, by Custody Rule Basis; with the count of Fee Disclosure Delivery rows with Fee Disclosure Delivered Date in the period by Fee Disclosure Type.",
             _u("47", "Fee Deduction Authorization", "Authorized Account", "Authorization Status", "Authorization Effective Date",
                "Authorization Revoked Date", "Custody Rule Basis")
             + _u("47", "Fee Disclosure Delivery", "Fee Disclosure Delivered Date", "Fee Disclosure Type")),
        ],
        inputs=[
            ("47", "Fee Schedule", ["Fee Schedule ID", "Fee Schedule Name", "Fee Schedule Type", "Schedule Version Number", "Schedule Status",
                                    "Version Effective From", "Version Effective To", "Billing Basis", "Tier Method",
                                    "Default Billing Frequency", "Default Billing Timing", "Minimum Annual Fee", "Maximum Fee Rate",
                                    "Own-Fund Treatment", "Form ADV Disclosure Reference", "Superseded Schedule Version"]),
            ("47", "Performance Fee Terms", ["Performance Fee Rate", "Hurdle Type", "High-Water Mark Indicator", "Crystallization Frequency",
                                             "Performance Fee Basis"]),
            ("47", "Fee Schedule Tier", ["Tier Fee Schedule", "Tier Sequence", "Tier Lower Bound", "Tier Upper Bound", "Tier Rate"]),
            ("47", "Fee Schedule Assignment", ["Fee Schedule Assignment ID", "Billed Enrollment", "Billed Account", "Billed Advice Engagement",
                                               "Assigned Fee Schedule", "Fee-Paying Account", "Fee Collection Method", "Billing Timing",
                                               "Billing Frequency", "Assigned Fee Household", "Negotiated Rate Indicator",
                                               "Assignment Effective From", "Assignment Effective To"]),
            ("47", "Fee Rate Override", ["Overridden Assignment", "Override Rate", "Override Reason", "Override Approved By",
                                         "Override Effective From", "Override Expiry Date"]),
            ("47", "Billing Arrangement", ["Billing Arrangement ID", "Billed Mandate", "Bill-To Party", "Applied Fee Schedule",
                                           "Billing Frequency", "Billing Basis", "Performance Fee Eligibility Basis",
                                           "Qualified Client Determination Date", "Billing Effective From", "Billing Effective To"]),
            ("47", "Fee Household", ["Fee Household ID", "Anchor Client Household", "Formation Basis", "Fee Household Status",
                                     "Fee Household Effective From", "Fee Household Effective To"]),
            ("47", "Fee Household Membership", ["Membership Fee Household", "Member Account", "Inclusion Basis",
                                                "Fee Household Membership Status", "Fee Household Membership Effective From",
                                                "Fee Household Membership Effective To"]),
            ("47", "Fee Waiver", ["Fee Waiver ID", "Waived Assignment", "Waived Billing Arrangement", "Waiver Reason", "Waiver Percentage",
                                  "Waiver Amount", "Waiver Period Start", "Waiver Period End", "Waiver Approved By"]),
            ("47", "Fee Calculation Run", ["Fee Calculation Run ID", "Run Billing Period Start", "Run Billing Period End", "Run Type",
                                           "Valuation As-Of Date", "Run Status", "Fee Reconciliation Status", "Run Net Fee Total",
                                           "Run Approved By"]),
            ("47", "Account Fee Calculation", ["Calculation Run", "Calculated Assignment", "Calculated Billing Arrangement",
                                               "Schedule Version Applied", "Account Valuation", "Billable Assets", "Fee Household Assets",
                                               "Effective Annual Rate", "Gross Fee", "Discount Amount", "Waiver Amount Applied",
                                               "Own-Fund Credit Amount", "Net Fee", "Exception Indicator"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Debited Calculation", "Charged Fee Type", "Debited Account", "Debit Amount", "Debit Date",
                                 "Fee Debit Status", "Debit Posting", "Debit Failure Reason"]),
            ("47", "Fee Invoice", ["Invoice ID", "Invoice Billing Arrangement", "Invoice Fee Schedule Assignment", "Invoice Bill-To Party",
                                   "Billing Period End", "Billable Assets", "Management Fee Amount", "Performance Fee Amount",
                                   "Invoice Total", "Invoice Date", "Payment Status"]),
            ("47", "Fee Adjustment", ["Fee Adjustment ID", "Adjustment Type", "Adjusted Invoice", "Adjusted Fee Calculation",
                                      "Adjustment Amount Value", "Applied Fee Waiver", "Related Billing Dispute", "Credit Posting",
                                      "Adjustment Approved By"]),
            ("47", "Billing Dispute", ["Billing Dispute ID", "Disputed Invoice", "Disputed Fee Calculation", "Dispute Reason",
                                       "Disputed Amount", "Dispute Status", "Related Complaint"]),
            ("47", "Fee Deduction Authorization", ["Authorized Account", "Authorizing Agreement", "Fee Types Authorized",
                                                   "Authorized Fee-Paying Account", "Qualified Custodian", "Custody Rule Basis",
                                                   "Authorization Status", "Authorization Effective Date", "Authorization Revoked Date"]),
            ("47", "Fee Disclosure Delivery", ["Fee Disclosure Recipient", "Fee Disclosure Account", "Fee Disclosure Type",
                                               "Disclosed Fee Schedule", "Fee Disclosure Delivery Method", "Fee Disclosure Delivered Date",
                                               "Fee Change Effective Date", "Related Program Enrollment"]),
            ("01", "Offering Fee Schedule Link", ["Linked Offering", "Linked Fee Schedule", "Fee Schedule Link Type", "Link Effective From",
                                                  "Link Effective To"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering", "Enrollment Status"]),
        ],
        upstream=["DP-093", "DP-240", "DP-004", "DP-303", "DP-300", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="Masters by 6am ET daily; each released fee calculation run with its calculations, debits and invoices by business day 2 after Run Billing Period End; debit status changes by 7am ET on T+1",
        history=("Fee schedule versions, assignments, overrides, households and waivers SCD type 2 for the life of the relationship plus 6 "
                 "years; every run, calculation, debit, invoice, adjustment and dispute kept as recorded for at least 5 years under Advisers "
                 "Act Rule 204-2 and 6 years where a debit is a 49 posting under SEC Rule 17a-4"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract"],
        dq_rules=[
            "Every Billed Enrollment, Billed Account, Fee-Paying Account, Member Account, Debited Account, Authorized Account and Fee Disclosure Account resolves to a DP-093 account or enrollment; Anchor Client Household resolves to a DP-240 party with Party Type = Household, and Bill-To Party, Invoice Bill-To Party and Fee Disclosure Recipient to a DP-240 party; Billed Advice Engagement resolves to a DP-303 Advice Engagement; Billed Mandate and Linked Offering resolve to DP-004.",
            "Versions of one Fee Schedule ID do not overlap (Version Effective From / To), assignments for the same billed subject do not overlap, an account belongs to at most one active Fee Household at a time, and every effective-to, expiry or period-end date is on or after its start.",
            "For every run with Run Status in (Approved, Released), Run Control Total Variance is within USD 0.01, and on every Account Fee Calculation Net Fee equals Gross Fee - Discount Amount - Waiver Amount Applied - Own-Fund Credit Amount within USD 0.01; for broker-dealer accounts, Account Valuation equals DP-300 Client Holdings Market Value for that Client account (DP-093) on the schedule's Billing Basis within 0.5 percent: the value at Run Billing Period End for Period-End Value, at Run Billing Period Start for Beginning-of-Period Value, the average of the daily DP-300 values from Run Billing Period Start to Run Billing Period End for Average Daily Value, and the average of the month-end values for Average Month-End Value; and Billable Assets does not exceed Account Valuation.",
            "Billing Basis, Tier Method and Form ADV Disclosure Reference are populated on every active Asset-Based Advisory, Wrap Fee and Participant Managed Account schedule version; Billable Assets, Effective Annual Rate and Net Fee on every Account Fee Calculation; Debited Account, Debit Amount and Debit Date on every Fee Debit; Performance Fee Rate and Hurdle Type on every Institutional Mandate version with Performance Fee Terms.",
            "Account-grain and invoice rows of individual clients are published only in the Confidential - Personal Data view to billing, operations and supervision roles; the BI semantic model carries amounts by fee schedule type, offering and billing period only; Bill-To Party names of individuals are not carried into the BI model.",
            "A Fee Calculation Run with Run Status = Released and its Account Fee Calculation rows are immutable: corrections arrive as a run with Run Type = Recalculation or as Fee Adjustment rows; each released run is published by business day 2 after Run Billing Period End.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Fee Schedule (CLFEE-), Fee Schedule Assignment (FEASG-), Fee Household (FHHG-), Fee "
               "Calculation Run (FCRUN-), Account Fee Calculation, Fee Debit (FDBT-), Fee Invoice (BIL-), Fee Waiver (FWV-), Billing "
               "Arrangement (BLA-), Billing Dispute (BDP-), Fee Adjustment (FADJ-), Fee Disclosure Delivery and Fee Deduction Authorization, "
               "all 47; source of the Fee Schedule and Fee Household dimensions of the WP2 conformed set. The fee household is the 47 fee "
               "aggregation group, not the 02 Client Household and not the 13 mailing householding group (CW-027). "
               "Certified numbers: none owned (It owns no certified metric family). Billed, waived, adjusted and collected amounts are "
               "operational (CW-214); certified client fee revenue (Gross Fee Revenue, Net Fee Revenue, Effective Net Fee Rate) is DP-012's, "
               "which lists this product upstream and ties Net Billed Fees by run; this product never lists DP-012. DP-300 is upstream for billable assets (coordinator ruling; DP-300 does not list DP-305) and is joined on its Client account (DP-093) and Holding date dimensions and its Client Holdings Market Value measure. Billable Assets is a Derived "
               "copy of 49 Client Holding valuations (DP-300) and is never Client Assets or Firm AUM. "
               "PII tier: financial (Fee Disclosure Delivery identity). Row grain only in the Confidential - Personal Data view. "
               "Boundaries: DP-346 decides billing accuracy and custody-rule evidence (Billable Asset Exclusion, Fee Calculation Exception, failed "
               "reconciliation and off-schedule flags against Fee Deduction Authorization and Fee Disclosure Delivery); DP-347's waiver, adjustment "
               "and dispute analysis folds into DP-346; DP-348 and DP-349 (pricing realization, commissions) read Fee Discount Rule, Commission & "
               "Transaction Charge Rate and Account Service Fee Item, which are not read here; DP-350 reads Billing Arrangement, Performance Fee "
               "Calculation and Fee Invoice for mandates; DP-598 ties Fee Debit and Fee Invoice to the ledger. Edge direction: 49 Client Account "
               "Activity.Source Fee Debit and 50 Money Movement.Source Fee Debit are keys into this product; DP-300 must not list DP-305 because "
               "this product lists DP-300; DP-302 is not listed here. 01 Offering Fee Schedule Link is read here (the relationship lives in "
               "01); DP-004 also reads it and must not list DP-305 because this product lists DP-004. "
               "Acceptance question 8: feeds DP-346 with Fee Calculation Runs (Fee Reconciliation Status), Run Control Total Variance, Average "
               "Effective Annual Rate inputs (Effective Annual Rate, Billable Assets, Fee Household Assets) and Active Fee Schedule Assignments. "
               "Tailoring lever: fee assignment subject (47 SME 1). Reference default: per enrollment for advisory programs, per account for "
               "brokerage and account service schedules, the Billing Arrangement for mandates. Tailoring lever: fee household (47 SME 2). "
               "Reference default: starts from 02 Client Household membership with client-requested links and entity groups. Tailoring lever: "
               "billing timing (47 SME 3). Reference default: monthly in arrears on average daily value for digital advice, quarterly in advance "
               "for human advice. Tailoring lever: own-fund offset (47 SME 4). Reference default: Excluded from Billable Assets. Tailoring lever: "
               "household breakpoints (47 SME 12). Reference default: billable assets of member accounts. Tailoring lever: trust administration "
               "fees. Reference default: Fee Schedule Type = Trust Administration exists only with the trust line (DP-307). "
               "Taxonomy gap: Fee Adjustment has no adjustment date or status, so Fee Adjustment Amount is dated by the adjusted invoice or run. "
               "Taxonomy gap: Billing Dispute has no opened or resolved date, so dispute age cannot be measured. " + GAP6 + ""
               "Drafting assumptions: Schedule Status, Fee Household Status, Fee Household Membership Status and Authorization Status = Active "
               "(Record Status); Run Status values Approved and Released; outstanding Payment Status values; Dispute Status closed values; the "
               "USD 0.01 tolerance; business day 2 publication; the billed calculation set (latest released non-Simulation run per billed subject and billing period); the 0.5 percent valuation tolerance in DQ3. "
               "Decisions: CW-011, CW-012, CW-027, CW-051, CW-052, CW-053, CW-054, CW-055, CW-205, CW-214. "
               "WP1 new (CW-205): first specification. The foundational products carry the facts the candidates had given to consumers: this product "
               "publishes Performance Fee Terms, Fee Waiver, Fee Adjustment, Billing Dispute, Fee Deduction Authorization and Fee Disclosure "
               "Delivery, and DP-346 and DP-350 read them from here and do not redefine them. No candidate object is dropped; DP-382 is not "
               "upstream because no 13 delivery record is read."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-530": dict(
        definition=("The conformed master of what the firm's models hold and on which assumptions they were built: approved capital market "
                    "assumption sets with their asset class return, volatility and correlation assumptions, the advice model lineups with "
                    "the position of each 01 model portfolio on the risk and horizon scale, the building blocks (share classes and "
                    "instruments) of each model, and the model-subject rows of 24 Target Allocation Set and Line, the target weights of "
                    "every model version. It publishes the CONCEPT_OWNERSHIP rows Capital Market Assumption Set (CMASET-), Model Lineup "
                    "(MLNUP-) and Target Allocation Set (model subject, 24) once, so that 45 planning, 46 model assignment, 16 workplace "
                    "managed accounts and model delivery read the same models and weights. Portfolio-subject target sets stay with DP-128 "
                    "(CW-250). It owns no certified metric family."),
        business_questions=[
            "Which capital market assumption sets are active, approved by which committee decision, how old are they, and are their return, volatility and correlation assumptions complete?",
            "Which model lineups are active for each purpose, on which CMA set, and which lineup positions have no effective model target set?",
            "Which model target sets are effective today, were they approved, and do their weights sum to 100%?",
            "Which model building blocks sit on products restricted or removed from the approved list, on inactive vehicles, or leave a model slot without a primary block?",
            "Which effective model target lines name an instrument that is not a current building block of the model?",
        ],
        grain=("Model portfolio (01) x target set version x target line, with the lineup position, building blocks and the capital market "
               "assumption set of its lineup as conformed attributes; companion masters CMA set x version x asset class (and correlation "
               "pairs) and model lineup x version x position; every version kept"),
        dimensions=["Model portfolio (DP-004)", "Service offering (DP-004)", "Share class (DP-004)", "Instrument (DP-097)",
                    "Benchmark (DP-004)", "Generating model (DP-212)", "Capital market assumption set and version", "CMA purpose",
                    "Model lineup and version", "Model lineup purpose", "Risk band", "Horizon band", "Asset class",
                    "Target component type", "Building block role", "Effective date (DP-013)"],
        measures=[
            ("Active CMA Sets",
             "Count of Capital Market Assumption Set ID x CMA Set Version with CMA Set Status = Active and CMA Effective From <= as-of date, by CMA Purposes and CMA Horizon Years.",
             _u("24", "Capital Market Assumption Set", "Capital Market Assumption Set ID", "CMA Set Version", "CMA Set Status",
                "CMA Effective From", "CMA Purposes", "CMA Horizon Years")),
            ("CMA Sets Without Committee Approval",
             "Active CMA Sets whose CMA Approving Committee Decision is blank or resolves to an Investment Committee Decision with Committee Decision Type other than CMA Approval or Committee Decision Outcome not in (Approved, Approved with Conditions).",
             _u("24", "Capital Market Assumption Set", "CMA Approving Committee Decision")
             + _u("24", "Investment Committee Decision", "Decision Committee", "Decision Meeting Date", "Decision Item Number",
                  "Committee Decision Type", "Committee Decision Outcome") + ["Active CMA Sets"]),
            ("CMA Set Age Days",
             "For each Active CMA Set: as-of date minus CMA As-Of Date in calendar days, with the count of sets older than 400 days, by CMA Purposes.",
             _u("24", "Capital Market Assumption Set", "CMA As-Of Date", "CMA Purposes") + ["Active CMA Sets"]),
            ("Incomplete Return Assumption Lines",
             "Count of Asset Class Return Assumption rows of Active CMA Sets (Return Assumption CMA Set) with Expected Geometric Return or Expected Volatility blank, by Assumption Asset Class.",
             _u("24", "Asset Class Return Assumption", "Return Assumption CMA Set", "Assumption Asset Class", "Assumption Sub-Class",
                "Expected Geometric Return", "Expected Volatility") + ["Active CMA Sets"]),
            ("Correlation Matrix Completeness %",
             "For each Active CMA Set: count of Asset Class Correlation Assumption rows (Correlation CMA Set) with distinct First Assumption Line and Second Assumption Line and Expected Correlation between -1 and 1 / (n x (n - 1) / 2), where n is the count of its Asset Class Return Assumption lines.",
             _u("24", "Asset Class Correlation Assumption", "Correlation CMA Set", "First Assumption Line", "Second Assumption Line",
                "Expected Correlation") + _u("24", "Asset Class Return Assumption", "Return Assumption CMA Set") + ["Active CMA Sets"]),
            ("Active Model Lineups",
             "Count of Model Lineup ID x Model Lineup Version with Model Lineup Status = Active and Lineup Effective From <= as-of date, by Model Lineup Purpose and Lineup Service Offering.",
             _u("24", "Model Lineup", "Model Lineup ID", "Model Lineup Version", "Model Lineup Status", "Lineup Effective From",
                "Model Lineup Purpose", "Lineup Service Offering")),
            ("Lineups on Inactive CMA Set",
             "Active Model Lineups whose Lineup CMA Set is blank or is not an Active CMA Set, or whose Lineup Approving Committee Decision is blank.",
             _u("24", "Model Lineup", "Lineup CMA Set", "Lineup Approving Committee Decision") + ["Active Model Lineups", "Active CMA Sets"]),
            ("Lineup Positions",
             "Count of Model Lineup Position rows of Active Model Lineups (Position Model Lineup), by Position Risk Band and Position Horizon Band, with the average Nominal Equity Share.",
             _u("24", "Model Lineup Position", "Position Model Lineup", "Position Model Portfolio", "Position Risk Band",
                "Position Horizon Band", "Nominal Equity Share") + ["Active Model Lineups"]),
            ("Effective Model Target Sets",
             "Count of Target Set ID with Target Subject Type = Model Portfolio, Target Set Status = Effective and Target Effective Timestamp <= as-of, by Target Model Portfolio.",
             _u("24", "Target Allocation Set", "Target Set ID", "Target Subject Type", "Target Set Status", "Target Effective Timestamp",
                "Target Model Portfolio")),
            ("Lineup Positions Without Effective Target Set",
             "Lineup Positions whose Position Model Portfolio has no Effective Model Target Set (Target Model Portfolio = Position Model Portfolio).",
             _u("24", "Model Lineup Position", "Position Model Portfolio") + _u("24", "Target Allocation Set", "Target Model Portfolio")
             + ["Lineup Positions", "Effective Model Target Sets"]),
            ("Effective Sets Without Approval",
             "Effective Model Target Sets with Target Set Approval Status other than Approved or Approved with Conditions.",
             _u("24", "Target Allocation Set", "Target Set Approval Status") + ["Effective Model Target Sets"]),
            ("Target Weight Sum Variance",
             "For each Effective Model Target Set: 100% minus the sum of Target Weight of its Target Allocation Line rows (Line Target Set) with Target Component Type in (Instrument, Cash), or in (Asset Class, Cash) where the set has no Instrument lines; in percentage points.",
             _u("24", "Target Allocation Line", "Line Target Set", "Target Component Type", "Target Weight") + ["Effective Model Target Sets"]),
            ("Building Blocks on Restricted Products",
             "Count of Model Building Block rows effective on the as-of date (Building Block Effective From / To) with Building Block Product List Status in (Watch, Restricted for New Recommendations, Removed), by Building Block Role; the status is a Derived copy of 52 held as recorded (tie-out in DP-531).",
             _u("24", "Model Building Block", "Building Block Model Portfolio", "Building Block Role", "Building Block Product List Status",
                "Building Block Effective From", "Building Block Effective To")),
            ("Model Slots Without Primary Block",
             "Count of Building Block Model Portfolio x Building Block Slot combinations with at least one effective Model Building Block row and no effective row with Building Block Role = Primary.",
             _u("24", "Model Building Block", "Building Block Model Portfolio", "Building Block Slot", "Building Block Role",
                "Building Block Effective From", "Building Block Effective To")),
            ("Building Blocks on Inactive Vehicles",
             "Effective Model Building Block rows whose Building Block Share Class has Share Class Status other than Active, or whose Building Block Instrument has Instrument Status other than Active.",
             _u("24", "Model Building Block", "Building Block Share Class", "Building Block Instrument")
             + _u("01", "Share Class", "Share Class ID", "Share Class Status") + _u("17", "Instrument", "Instrument ID", "Instrument Status")),
            ("Target Lines Outside Building Blocks",
             "Count of Target Allocation Line rows of Effective Model Target Sets with Target Component Type = Instrument whose Target Instrument is not the Building Block Instrument of an effective Model Building Block of the same model (Building Block Model Portfolio = Target Model Portfolio).",
             _u("24", "Target Allocation Line", "Target Instrument", "Target Component Type")
             + _u("24", "Model Building Block", "Building Block Instrument", "Building Block Model Portfolio")
             + ["Effective Model Target Sets"]),
        ],
        inputs=[
            ("24", "Capital Market Assumption Set", ["Capital Market Assumption Set ID", "CMA Set Version", "CMA Horizon Years", "CMA As-Of Date",
                                                     "CMA Base Currency", "Inflation Assumption", "CMA Purposes", "CMA Generating Model",
                                                     "CMA Approving Committee Decision", "CMA Set Status", "CMA Effective From"]),
            ("24", "Asset Class Return Assumption", ["Return Assumption CMA Set", "Assumption Asset Class", "Assumption Sub-Class",
                                                     "Expected Arithmetic Return", "Expected Geometric Return", "Expected Volatility",
                                                     "Expected Income Yield", "Assumption Proxy Benchmark"]),
            ("24", "Asset Class Correlation Assumption", ["Correlation CMA Set", "First Assumption Line", "Second Assumption Line",
                                                          "Expected Correlation"]),
            ("24", "Model Lineup", ["Model Lineup ID", "Model Lineup Version", "Model Lineup Name", "Model Lineup Purpose",
                                    "Lineup Service Offering", "Lineup Allocation Policy", "Lineup CMA Set",
                                    "Lineup Approving Committee Decision", "Model Lineup Status", "Lineup Effective From"]),
            ("24", "Model Lineup Position", ["Position Model Lineup", "Position Model Portfolio", "Position Risk Band", "Position Horizon Band",
                                             "Years to Retirement Position", "Nominal Equity Share"]),
            ("24", "Model Building Block", ["Building Block Model Portfolio", "Building Block Role", "Building Block Slot",
                                            "Alternate For Building Block", "Building Block Share Class", "Building Block Instrument",
                                            "Building Block Product List Status", "Building Block Effective From",
                                            "Building Block Effective To"]),
            ("24", "Target Allocation Set", ["Target Set ID", "Target Subject Type", "Target Model Portfolio", "Target Set Version",
                                             "Target Set Status", "Target Set Approval Status", "Target Effective Timestamp",
                                             "Governing Allocation Policy", "Copied From Target Set"]),
            ("24", "Target Allocation Line", ["Line Target Set", "Target Component Type", "Target Instrument", "Target Asset Class",
                                              "Target Weight", "Lower Tolerance Band", "Upper Tolerance Band"]),
            ("24", "Investment Committee Decision", ["Decision Committee", "Decision Meeting Date", "Decision Item Number",
                                                     "Committee Decision Type", "Committee Decision Outcome", "Decision Effective Date"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name", "Implemented Strategy", "Rebalance Frequency"]),
            ("01", "Service Offering", ["Offering ID", "Offering Name", "Offering Type", "Offering Status"]),
            ("01", "Benchmark", ["Benchmark ID", "Benchmark Name"]),
            ("01", "Share Class", ["Share Class ID", "Share Class Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Status"]),
            ("37", "Model Inventory Entry", ["Model ID", "Model Version", "Model Use Status"]),
        ],
        upstream=["DP-004", "DP-097", "DP-212", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET daily; a model target set that becomes Effective is published within 1 hour of its Target Effective Timestamp through the event stream",
        history=("Every CMA set, lineup, position, building block and target set version kept with its approval; no deletion; kept at least "
                 "5 years under Advisers Act Rule 204-2 as the basis of advice and model recommendations"),
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Position Model Portfolio, Building Block Model Portfolio and Target Model Portfolio resolves to a DP-004 Model Portfolio, Lineup Service Offering to a DP-004 Service Offering, Building Block Share Class to a DP-004 Share Class, Building Block Instrument and Target Instrument to a DP-097 Instrument, Assumption Proxy Benchmark to a DP-004 Benchmark, and CMA Generating Model to a DP-212 Model Inventory Entry with Model Use Status = Active.",
            "Each model portfolio has at most one Target Allocation Set with Target Subject Type = Model Portfolio and Target Set Status = Effective at any time; Model Building Block rows for the same model, slot and role do not overlap and Building Block Effective To is on or after Building Block Effective From.",
            "Target Weight Sum Variance is within 0.01 percentage point for every Effective Model Target Set, and every Active CMA Set has one Asset Class Correlation Assumption row per unordered pair of its return lines (Correlation Matrix Completeness % = 100%).",
            "Expected Geometric Return and Expected Volatility are populated on every return line of an Active CMA Set, and Position Risk Band and Nominal Equity Share on every position of an Active Model Lineup.",
            "No personal data is published: employee references (Target Set Approved By, committee members) are not read; CMA sets with CMA Set Status other than Active are visible only in the investment committee view and never to advice or planning consumers.",
            "Only rows with Target Subject Type = Model Portfolio are published; portfolio-subject target sets are excluded and remain DP-128's; the daily snapshot is published by 6am ET.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Capital Market Assumption Set (CMASET-), Model Lineup (MLNUP-) and Target Allocation Set "
               "(TGT-, model subject rows only), 24; source of the Model lineup dimension of the WP2 conformed set and of model weights. "
               "Certified numbers: none owned (It owns no certified metric family). Expected returns are assumptions, never returns; returns "
               "are DP-145's. "
               "PII tier: none. pii = N: the only attributes flagged personal by the validator are Capital Market Assumption Set ID and Model "
               "Lineup ID, whose notes read 'No PII' (the flag matches the words); no employee reference is read, so no row or column carries "
               "personal data. "
               "Boundaries: model-subject Target Allocation Set and Line rows move here from DP-128, which keeps portfolio-subject sets "
               "(CW-250); DP-128's spec still reads Target Allocation Set unfiltered and should be restricted to Target Subject Type = Portfolio "
               "at the INV wave (not edited here). Building Block Product List Status is a Derived copy of 52 held as recorded; the tie-out "
               "against DP-306 Product List Status is DP-531's, so DP-306 is not upstream. Lineup drift and glide-path drift are DP-531's; "
               "account drift is DP-304 and DP-341 (46). Asset Allocation Policy, Glide Path Point and the Model Change Summary are read by "
               "DP-531 and DP-129. DP-303 (planning assumption sets) and DP-304 (applied model target set) read this product; it reads neither. "
               "Tailoring lever: licensed capital market assumptions (24 SME 1). Reference default: assumptions built in house with a 37 "
               "generating model; with a vendor CMA the set becomes a 14 licensed dataset with 24 approval only and the classification becomes "
               "Confidential - Licensed. Tailoring lever: model target sets shared with a lead portfolio (24 SME 3). Reference default: maintained "
               "separately per model portfolio. Tailoring lever: CMA staleness threshold. Reference default: 400 days. "
               "Taxonomy gap: Model Lineup Position has no position sequence, so the order of positions along the risk scale is inferred from "
               "Position Risk Band. Taxonomy gap: Capital Market Assumption Set has no expiry or review due date. "
               "Drafting assumptions: CMA Set Status and Model Lineup Status = Active (shared Record Status); Share Class Status and Instrument "
               "Status = Active; Product List Status values counted as restricted; the 0.01 percentage point tolerance and 400-day threshold. "
               "Decisions: CW-046, CW-120, CW-128, CW-130, CW-250, CD-176, CD-294. "
               "WP1 new (CW-250): first specification; inputs as in the INV+IOP candidate, adding 24 Investment Committee Decision for approval "
               "evidence and the 01 Share Class and 17 Instrument status checks; DP-144 is not upstream because no 22 index data is read (benchmarks are read from 01 through DP-004). The 01 Share Class and 17 "
               "Instrument reads are key and status checks only; those dimensions are DP-004's and DP-097's."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-306": dict(
        definition=("The conformed master of every external manager the firm hires or researches: the manager's research profile on its 02 "
                    "party, key persons and strategies, the sub-adviser engagements with their manager-of-managers hire conditions, "
                    "guideline sets, watch status and terminations, and the product due diligence verdicts and approved-list status of "
                    "third-party products. It publishes the CONCEPT_OWNERSHIP rows External Manager Profile, External Manager Strategy "
                    "(EMSTR-), Sub-Adviser Engagement (SADV-), Sub-Adviser Guideline Set (GDLN-), Product Due Diligence (TPDUE-) and "
                    "Product List Status (52) once, so that sub-adviser oversight, Section 15(c) evidence, OCIO line-ups, model building "
                    "blocks and advice name the same manager and the same list status. It owns no certified metric family."),
        business_questions=[
            "Which external managers are covered today, by type and coverage status, and which have a Form ADV review older than 12 months?",
            "Which sub-adviser engagements are active, for which funds, mandates and sleeves, and which lack an active agreement, board approval or an acknowledged current guideline set?",
            "Which engagements are on watch, under review or recommended for termination, and which watch reviews are past their deadline?",
            "Which key persons departed in the period, and how quickly was each departure notified?",
            "Which third-party products are on the approved, watch or restricted lists by scope, and which listed products lack current due diligence?",
        ],
        grain=("Sub-adviser engagement (sub-adviser x fund or mandate x sleeve x engagement period), with guideline set version, watch status "
               "and termination as conformed attributes; companion masters external manager (02 party) x profile period, key person x role "
               "period, manager strategy, and third-party product x list scope x status period with its product due diligence; SCD type 2"),
        dimensions=["External manager and sub-adviser (02 party, DP-240)", "Manager strategy", "Fund and investment mandate (DP-004)",
                    "Sleeve portfolio (DP-140)", "Governing contract (DP-213)", "Instrument (DP-097)", "External manager type",
                    "Research coverage status", "Engagement scope", "Engagement status", "Watch status", "Key person role",
                    "Termination reason", "List scope", "Product list status", "Effective date (DP-013)"],
        measures=[
            ("Covered External Managers",
             "Count of distinct Profiled Manager with Research Coverage Status in (Under Review, Approved, Watch) and Profile Effective From <= as-of date < Profile Effective To (or open), by External Manager Types and Affiliated Person Indicator.",
             _u("52", "External Manager Profile", "Profiled Manager", "Research Coverage Status", "Profile Effective From",
                "Profile Effective To", "External Manager Types", "Affiliated Person Indicator")),
            ("Managers With Stale Form ADV Review",
             "Covered External Managers whose Form ADV Last Reviewed Date is blank or more than 12 months before the as-of date.",
             _u("52", "External Manager Profile", "Form ADV Last Reviewed Date") + ["Covered External Managers"]),
            ("Key Person Departures",
             "Count of Manager Key Person rows with Key Person Indicator = Y and Departure Date in the period, by Key Person Role.",
             _u("52", "Manager Key Person", "Key Person Manager", "Key Person", "Key Person Indicator", "Departure Date", "Key Person Role")),
            ("Late Key Person Notifications",
             "Key Person Departures whose Departure Notified Date is blank or more than 5 business days after Departure Date.",
             _u("52", "Manager Key Person", "Departure Notified Date", "Departure Date") + ["Key Person Departures"]),
            ("Active Sub-Adviser Engagements",
             "Count of Sub-Adviser Engagement ID with Engagement Status = Active, Engagement Start Date <= as-of date and Engagement End Date blank or after it, by Engagement Scope, Investment Discretion Indicator and Trading Delegated Indicator.",
             _u("52", "Sub-Adviser Engagement", "Sub-Adviser Engagement ID", "Engagement Status", "Engagement Start Date",
                "Engagement End Date", "Engagement Scope", "Investment Discretion Indicator", "Trading Delegated Indicator")),
            ("Engagements Without Active Agreement",
             "Active Sub-Adviser Engagements with Engaged Fund populated whose Governing Fund Agreement is blank or resolves to a 35 Fund Advisory Agreement with Advisory Agreement Status other than Active, or with Delegated Mandate populated whose Governing Contract is blank or resolves to a 39 Contract with Contract Status other than Active.",
             _u("52", "Sub-Adviser Engagement", "Engaged Fund", "Governing Fund Agreement", "Delegated Mandate", "Governing Contract")
             + _u("35", "Fund Advisory Agreement", "Advisory Agreement ID", "Advisory Agreement Status")
             + _u("39", "Contract", "Contract ID", "Contract Status") + ["Active Sub-Adviser Engagements"]),
            ("Fund Engagements Without Board Approval",
             "Active Sub-Adviser Engagements with Engaged Fund populated and Board Approval Date blank or after Engagement Start Date.",
             _u("52", "Sub-Adviser Engagement", "Engaged Fund", "Board Approval Date", "Engagement Start Date") + ["Active Sub-Adviser Engagements"]),
            ("Overdue Information Statements",
             "Count of Manager-of-Managers Hire Condition rows with Information Statement Due Date before the as-of date and Information Statement Sent Date blank, by Relied-On Exemptive Relief.",
             _u("52", "Manager-of-Managers Hire Condition", "Information Statement Due Date", "Information Statement Sent Date",
                "Relied-On Exemptive Relief")),
            ("Engagements Without Acknowledged Guidelines",
             "Active Sub-Adviser Engagements whose latest Sub-Adviser Guideline Set (Guideline Engagement, highest Guideline Version with Guideline Effective Date <= as-of) is missing, or has Guideline Delivered Date or Guideline Acknowledged Date blank.",
             _u("52", "Sub-Adviser Guideline Set", "Guideline Set ID", "Guideline Engagement", "Guideline Version", "Guideline Effective Date",
                "Guideline Delivered Date", "Guideline Acknowledged Date") + ["Active Sub-Adviser Engagements"]),
            ("Engagements by Watch Status",
             "Count of Active Sub-Adviser Engagements by the Watch Status of their Sub-Adviser Watch Status row effective on the as-of date (Watch Effective From <= as-of < Watch Effective To or open) and Watch Reason.",
             _u("52", "Sub-Adviser Watch Status", "Watched Engagement", "Watch Status", "Watch Reason", "Watch Effective From",
                "Watch Effective To") + ["Active Sub-Adviser Engagements"]),
            ("Watch Reviews Past Deadline",
             "Engagements by Watch Status with Watch Status in (Watch, Under Review, Termination Recommended) and Watch Review Deadline before the as-of date.",
             _u("52", "Sub-Adviser Watch Status", "Watch Status", "Watch Review Deadline") + ["Engagements by Watch Status"]),
            ("Manager Terminations",
             "Count of Manager Termination rows with Termination Effective Date in the period, by Termination Reason, with the count where Replacement Engagement is blank.",
             _u("52", "Manager Termination", "Terminated Engagement", "Termination Effective Date", "Termination Reason",
                "Replacement Engagement")),
            ("Listed Third-Party Products",
             "Count of Product List Status rows with List Status Effective From <= as-of date < List Status Effective To (or open), by List Scope and Product List Status.",
             _u("52", "Product List Status", "Listed Instrument", "List Scope", "Product List Status", "List Status Effective From",
                "List Status Effective To")),
            ("Approved Products Without Current Due Diligence",
             "Listed Third-Party Products with Product List Status = Approved whose Deciding Product Review and Deciding Oversight Review are both blank, or for whose Listed Instrument no Product Due Diligence (Reviewed Instrument) has Product Next Review Due Date on or after the as-of date.",
             _u("52", "Product List Status", "Product List Status", "Deciding Product Review", "Deciding Oversight Review")
             + _u("52", "Product Due Diligence", "Product Due Diligence ID", "Reviewed Instrument", "Product Next Review Due Date")
             + ["Listed Third-Party Products"]),
            ("Complex Products Approved Without Full Review",
             "Count of Product Due Diligence rows with Complex Product Indicator = Y, Product Due Diligence Outcome in (Approve, Approve with Conditions) and Full Due Diligence Indicator other than Y, by Product Use Scopes.",
             _u("52", "Product Due Diligence", "Complex Product Indicator", "Product Due Diligence Outcome", "Full Due Diligence Indicator",
                "Product Use Scopes")),
            ("Own Products on Third-Party List",
             "Listed Third-Party Products whose Listed Instrument has Own Share Class populated in 17 Instrument (own products are 36's product governance, never 52's).",
             _u("17", "Instrument", "Instrument ID", "Own Share Class") + ["Listed Third-Party Products"]),
        ],
        inputs=[
            ("52", "External Manager Profile", ["Profiled Manager", "External Manager Types", "Research Coverage Status", "Coverage Analyst",
                                                "Ownership Structure", "Form ADV Last Reviewed Date", "Affiliated Person Indicator",
                                                "Profile Effective From", "Profile Effective To"]),
            ("52", "Manager Key Person", ["Key Person Manager", "Key Person", "Key Person Role", "Key Person Strategies", "Key Person Indicator",
                                          "Role Start Date", "Departure Date", "Departure Notified Date"]),
            ("52", "External Manager Strategy", ["External Manager Strategy ID", "Strategy Manager", "Manager Strategy Name",
                                                 "Strategy Asset Class", "Strategy Style", "Vehicles Available", "Strategy Research Status"]),
            ("52", "Sub-Adviser Engagement", ["Sub-Adviser Engagement ID", "Engaged Sub-Adviser", "Engaged Strategy", "Governing Fund Agreement",
                                              "Governing Contract", "Overseeing Adviser Entity", "Engaged Fund", "Delegated Mandate",
                                              "Sleeve Portfolio", "Engagement Scope", "Investment Discretion Indicator",
                                              "Trading Delegated Indicator", "Proxy Voting Delegated Indicator", "Engagement Status",
                                              "Engagement Start Date", "Engagement End Date", "Board Approval Date"]),
            ("52", "Manager-of-Managers Hire Condition", ["Relied-On Exemptive Relief", "Shareholder Approval Required Indicator",
                                                          "Information Statement Due Date", "Information Statement Sent Date"]),
            ("52", "Sub-Adviser Guideline Set", ["Guideline Set ID", "Guideline Engagement", "Guideline Version", "Guideline Effective Date",
                                                 "Guideline Delivered Date", "Guideline Acknowledged Date",
                                                 "Sub-Adviser Pre-Trade Checks Indicator"]),
            ("52", "Sub-Adviser Watch Status", ["Watched Engagement", "Watch Status", "Watch Reason", "Watch Review Deadline",
                                                "Watch Effective From", "Watch Effective To"]),
            ("52", "Manager Termination", ["Terminated Engagement", "Termination Reason", "Deciding Committee Decision",
                                           "Termination Notice Date", "Termination Effective Date", "Replacement Engagement"]),
            ("52", "Product Due Diligence", ["Product Due Diligence ID", "Reviewed Instrument", "Product Use Scopes", "Full Due Diligence Indicator",
                                             "Complex Product Indicator", "Product Due Diligence Outcome", "Product Review Effective Date",
                                             "Product Next Review Due Date"]),
            ("52", "Product List Status", ["Listed Instrument", "List Scope", "Product List Status", "List Status Reason",
                                           "Deciding Product Review", "Deciding Oversight Review", "List Status Effective From",
                                           "List Status Effective To"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party"]),
            ("02", "Organization", ["Legal Name", "Primary Regulator"]),
            ("35", "Fund Advisory Agreement", ["Advisory Agreement ID", "External Sub-Adviser", "Advisory Agreement Status",
                                               "Agreement Effective Date", "Agreement Termination Date"]),
            ("39", "Contract", ["Contract ID", "Contract Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Status", "Own Share Class"]),
        ],
        upstream=["DP-240", "DP-004", "DP-213", "DP-097", "DP-140", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; a watch status change, termination or list status change is published intraday through the event stream",
        history=("SCD type 2 on profiles, key person roles, engagements, guideline versions, watch status and list status since the first "
                 "engagement; every due diligence and termination kept; at least 6 years under Investment Company Act Rule 31a-2 for fund "
                 "engagements and 5 years under Advisers Act Rule 204-2"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Profiled Manager, Engaged Sub-Adviser and Key Person resolves to a DP-240 party with Party Status = Active and no Merged Into Party (Profiled Manager and Engaged Sub-Adviser with an organization Party Type, Key Person with Party Type = Individual); Engaged Fund and Delegated Mandate resolve to DP-004; Sleeve Portfolio to DP-140; Governing Contract to DP-213; Listed Instrument and Reviewed Instrument to DP-097.",
            "Watch Status rows of one engagement, list status rows of one Listed Instrument and List Scope, and profile periods of one manager do not overlap, and every effective-to or end date is on or after its start; an engagement with a Manager Termination has Engagement End Date on or after Termination Effective Date.",
            "Every Engaged Sub-Adviser of an Active fund engagement equals the External Sub-Adviser of its Governing Fund Agreement, and every Deciding Product Review resolves to a Product Due Diligence of the same Listed Instrument.",
            "Engagement Status, Engagement Scope and Engagement Start Date are populated on every engagement, Information Statement Due Date on every Manager-of-Managers Hire Condition, and Product Due Diligence Outcome and Product Next Review Due Date on every Product Due Diligence.",
            "Key person rows are personal (identity) data and are published only in the Confidential - Personal Data view to manager research, oversight and fund governance roles; Background Check Result is never read; the BI semantic model carries counts by manager, engagement and list scope only.",
            "A list status change is published within 1 hour as an event and in the next daily snapshot by 7am ET; a superseded list status row is closed by List Status Effective To, never deleted.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows External Manager Profile (keyed by 02 PTY-), Manager Key Person, External Manager Strategy "
               "(EMSTR-), Sub-Adviser Engagement (SADV-), Sub-Adviser Guideline Set (GDLN-), Product Due Diligence (TPDUE-) and Product List "
               "Status, all 52; source of the Manager and sub-adviser dimension of the WP2 conformed set. Party identity is DP-240's and never "
               "copied (CW-116). "
               "Certified numbers: none owned (It owns no certified metric family). Reported Firm AUM and Reported Strategy AUM of 52 are 14 "
               "dataset copies of the manager's own assets, not the firm's Firm AUM, and are not read. "
               "PII tier: identity. Key persons are individuals; Coverage Analyst is an employee reference. "
               "Boundaries: Product List Status is published here by the lead's ruling (CW-254; the framing candidate), so DP-535 (which absorbs "
               "backlog DP-539) and any foundational reader take list status from this product; DP-530 holds a Derived copy on Model Building "
               "Block and DP-531 ties it out. Oversight reviews, metric readings, thresholds, certifications, findings and remediation are DP-536's; "
               "manager searches and due diligence reviews DP-535's; Section 15(c) Renewal Submission DP-538's; the sub-advisory contract and "
               "renewal stay 35 (CW-117), read here only for agreement status because no foundational product publishes 35 Fund Advisory "
               "Agreement (DP-213 publishes the contract link). Edge direction: 01 Platform Product Availability.Due Diligence Approval is a key "
               "into this product; DP-004 must not list DP-306 because this product lists DP-004. 10 Fee Revenue Record.Sub-Adviser Engagement "
               "is a key into this product. "
               "Acceptance question 12: feeds DP-536 with Engagements by Watch Status, Watch Reviews Past Deadline and Active Sub-Adviser "
               "Engagements, and DP-538 with Sub-Adviser Engagement, Manager-of-Managers Hire Condition and Manager Termination rows. "
               "Tailoring lever: sleeves of multi-manager funds or whole funds (52 SME 1). Reference default: both. Tailoring lever: "
               "manager-of-managers order (52 SME 3). Reference default: relied on for unaffiliated sub-advisers; without it the hire condition "
               "group and Overdue Information Statements drop. Tailoring lever: platform curation depth (52 SME 4). Reference default: screen "
               "for self-directed platform listing, full due diligence for Advice Models, Plan Menus, Fund of Funds and recommended uses. "
               "Tailoring lever: OCIO and trust mandates share the objects (52 SME 6). Reference default: yes, IA line, under a 39 contract. "
               "Tailoring lever: key person notification window. Reference default: 5 business days. "
               "Boundary note: watch decisions are evidenced by Deciding Oversight Review and list approvals by Deciding Product Review or "
               "Deciding Oversight Review, by design. The 39 Contract and 17 Instrument reads are key and status checks only; those dimensions "
               "are DP-213's and DP-097's. " + GAP6 + ""
               "Drafting assumptions: Engagement Status = Active; Advisory Agreement Status and Contract Status = Active (shared Agreement Status); "
               "Research Coverage Status values counted as covered; the 12-month Form ADV review threshold. "
               "Decisions: CW-116, CW-117, CW-118, CW-119, CW-120, CW-121, CW-130, CW-205, CW-254. "
               "WP1 new (CW-205): first specification; inputs as in the framing candidate with Product Due Diligence added for the list status "
               "evidence and 35 Fund Advisory Agreement, 39 Contract and 17 Instrument added for the agreement and own-product checks."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-307": dict(
        definition=("The conformed fiduciary record of each trust and estate the trust company acts for: the trust and its instrument "
                    "documents, term provisions, trustee, co-trustee, grantor and other roles and the beneficial interests under it, the "
                    "accounts that hold its assets, and the fiduciary facts 51 masters on it: distribution requests (without their "
                    "purpose, and without the requests whose purpose is special category), fiduciary account reviews under 12 CFR 9.6, principal and income allocations, fiduciary tax returns and "
                    "estate settlement cases. It publishes the CONCEPT_OWNERSHIP rows Trust (TRUST-), Trust Term Provision, Trust Role, "
                    "Beneficial Interest, Fiduciary Account Review (FIRV-), Fiduciary Tax Return (TXRT-) and Estate Settlement Case "
                    "(ESTATE-) once, so that distributions, principal and income accounting, account reviews and fiduciary tax read the "
                    "same trust. It is optional: it exists only where the firm offers trust services (TR line). It owns no certified "
                    "metric family."),
        business_questions=[
            "Which trusts does the trust company administer today, by revocability and situs, and which lack a current trustee, an instrument document or a linked account?",
            "Do the current beneficial interests of each trust sum to 100%, and which trusts carry investment constraint provisions?",
            "Which distribution requests are open, for how much and for how long?",
            "Which fiduciary account reviews are overdue, by review type?",
            "How much was allocated to principal and to income in the period, and which fiduciary returns are due and not filed; which estate settlement cases are open?",
        ],
        grain=("Trust x role holder x trust role type x role period, with instrument documents, term provisions, beneficial interests and "
               "linked accounts as conformed attributes; companion facts distribution request, fiduciary account review, principal and "
               "income allocation (trust x source event x sequence), fiduciary tax return (trust or estate x tax year) and estate "
               "settlement case; SCD type 2 on trust status, roles, provisions and interests"),
        dimensions=["Trust and grantor, trustee, beneficiary parties (DP-240)", "Client account (DP-093)", "Trust officer (DP-009)",
                    "Reviewer (DP-192)", "Revocability", "Situs jurisdiction", "Trust instrument type (special-needs value blanked)", "Trust role type",
                    "Beneficial interest type", "Fiduciary review type", "Allocation character", "Receipt or disbursement type",
                    "Fiduciary return type", "Firm estate role", "Probate status", "Calendar date (DP-013)"],
        measures=[
            ("Administered Trusts",
             "Count of Trust ID with Trust Status = Active that have a Trust Role with Trust Role Type in (Trustee, Co-Trustee, Directed Trustee, Agent for Trustee) held by a Role Holder Entity (the trust company, 09) effective on the as-of date (Role Effective From <= as-of < Role Effective To or open), by Revocability and Situs Jurisdiction; any published slice with fewer than 10 trusts is suppressed.",
             _u("51", "Trust", "Trust ID", "Trust Status", "Revocability", "Situs Jurisdiction")
             + _u("51", "Trust Role", "Role Trust", "Trust Role Type", "Role Holder Entity", "Role Effective From", "Role Effective To")),
            ("Trusts Without Current Trustee",
             "Count of Trust ID with Trust Status = Active and no Trust Role of Trust Role Type in (Trustee, Co-Trustee, Directed Trustee, Successor Trustee) effective on the as-of date, whether held by a Role Holder Party or a Role Holder Entity.",
             _u("51", "Trust", "Trust ID", "Trust Status")
             + _u("51", "Trust Role", "Role Trust", "Trust Role Type", "Role Holder Party", "Role Holder Entity", "Role Effective From",
                  "Role Effective To")),
            ("Trusts Without Instrument Document",
             "Administered Trusts with no Trust Instrument Document row (Instrument Trust) of Instrument Document Type in (Trust Agreement, Declaration of Trust, Last Will and Testament, Certification of Trust) and Certification of Trust Received Date blank on every row.",
             _u("51", "Trust Instrument Document", "Instrument Trust", "Instrument Document Type", "Certification of Trust Received Date")
             + ["Administered Trusts"]),
            ("Trusts Without Linked Account",
             "Administered Trusts for which no 15 Account with Account Status = Open has Account Registration Detail Governing Trust = Trust ID.",
             _u("15", "Account", "Account ID", "Account Status") + _u("15", "Account Registration Detail", "Governing Trust")
             + ["Administered Trusts"]),
            ("Beneficial Interest Share Gaps",
             "Count of Administered Trusts failing either of two separate tests on Beneficial Interest rows (Interest Trust) effective on the as-of date (Interest Effective From / To): the income test, the sum of Interest Share Percentage of rows with Beneficial Interest Type in (Current Income, Current Income and Principal, Unitrust or Annuity Recipient), and the principal test, the sum over rows with Beneficial Interest Type in (Current Principal, Current Income and Principal); a test fails when its sum is above 0 and differs from 100% by more than 0.01 (a trust with no current principal interest passes the principal test).",
             _u("51", "Beneficial Interest", "Interest Trust", "Beneficial Interest Type", "Interest Share Percentage",
                "Interest Effective From", "Interest Effective To") + ["Administered Trusts"]),
            ("Investment Constraint Provisions",
             "Count of Trust Term Provision rows with Investment Constraint Indicator = Y effective on the as-of date (Provision Effective From / To) of Administered Trusts, by Provision Type (the Special Needs Purpose value blanked).",
             _u("51", "Trust Term Provision", "Provision Trust", "Investment Constraint Indicator", "Provision Effective From",
                "Provision Effective To", "Provision Type") + ["Administered Trusts"]),
            ("Open Distribution Requests",
             "Count and sum of Requested Amount of Trust Distribution Request rows with Request Status not in (Resolved / Completed, Closed, Rejected, Canceled) on the as-of date, by trust, over the published rows only: rows with Distribution Purpose in (Health / Medical, Disability Care, Hardship / Emergency) are excluded at extraction, and Distribution Purpose is used as that filter only and never published.",
             _u("51", "Trust Distribution Request", "Distribution Request ID", "Request Trust", "Request Status", "Requested Amount",
                "Distribution Purpose")),
            ("Distribution Request Age Days",
             "Median of as-of date minus Request Received Date over Open Distribution Requests, with the count older than 30 days.",
             _u("51", "Trust Distribution Request", "Request Received Date") + ["Open Distribution Requests"]),
            ("Overdue Fiduciary Reviews",
             "Count of Fiduciary Review ID with Review Due Date before the as-of date and Review Completed Date blank, by Fiduciary Review Type and Investment Discretion Indicator.",
             _u("51", "Fiduciary Account Review", "Fiduciary Review ID", "Review Due Date", "Review Completed Date", "Fiduciary Review Type",
                "Investment Discretion Indicator")),
            ("Principal Allocated",
             "Sum of Principal Amount of Principal and Income Allocation rows with Allocation Date in the period, by Receipt or Disbursement Type and Allocation Rule (USD).",
             _u("51", "Principal and Income Allocation", "Allocation Trust", "Allocation Date", "Principal Amount",
                "Receipt or Disbursement Type", "Allocation Rule")),
            ("Income Allocated",
             "Sum of Income Amount of Principal and Income Allocation rows with Allocation Date in the period, by Receipt or Disbursement Type and Allocation Rule (USD).",
             _u("51", "Principal and Income Allocation", "Allocation Date", "Income Amount", "Receipt or Disbursement Type", "Allocation Rule")),
            ("Inconsistent Allocation Character",
             "Count of Principal and Income Allocation rows with Allocation Character = Principal and Income Amount not zero, or Allocation Character = Income and Principal Amount not zero, or Allocation Character = Split with either amount blank.",
             _u("51", "Principal and Income Allocation", "Allocation Character", "Principal Amount", "Income Amount")),
            ("Fiduciary Returns Due Not Filed",
             "Count of Fiduciary Tax Return ID with Return Filed Date blank whose due date has passed: Extended Due Date where populated, otherwise the 15th day of the fourth month after Tax Year End Date, by Fiduciary Return Type.",
             _u("51", "Fiduciary Tax Return", "Fiduciary Tax Return ID", "Return Filed Date", "Extended Due Date", "Tax Year End Date",
                "Fiduciary Return Type")),
            ("Distributable Net Income Reported",
             "Sum of Distributable Net Income of Fiduciary Tax Return rows with Return Filed Date populated, by Fiduciary Return Type and year of Tax Year End Date (USD).",
             _u("51", "Fiduciary Tax Return", "Distributable Net Income", "Return Filed Date", "Fiduciary Return Type", "Tax Year End Date")),
            ("Open Estate Settlement Cases",
             "Count of Estate Settlement Case ID with Case Status not in (Resolved / Completed, Closed, Rejected, Canceled), by Firm Estate Role and Probate Status.",
             _u("51", "Estate Settlement Case", "Estate Settlement Case ID", "Case Status", "Firm Estate Role", "Probate Status")),
            ("Estate Cases Without Death Notification",
             "Open Estate Settlement Cases with Case Death Notification blank.",
             _u("51", "Estate Settlement Case", "Case Death Notification") + ["Open Estate Settlement Cases"]),
        ],
        inputs=[
            ("51", "Trust", ["Trust ID", "Trust Party", "Trust Instrument Type", "Revocability", "Situs Jurisdiction", "Governing Law Jurisdiction",
                             "Administering Trust Officer", "Trust Status", "Trust Termination Date"]),
            ("51", "Trust Instrument Document", ["Instrument Trust", "Instrument Version Number", "Instrument Document Type", "Execution Date",
                                                 "Certification of Trust Received Date"]),
            ("51", "Trust Term Provision", ["Provision Trust", "Provision Type", "Provision Sequence", "Provision Instrument Version",
                                            "Distribution Standard", "Investment Constraint Indicator", "Provision Effective From",
                                            "Provision Effective To"]),
            ("51", "Trust Role", ["Role Trust", "Trust Role Type", "Role Holder Party", "Role Holder Entity", "Appointment Source",
                                  "Role Acceptance Date", "Role Effective From", "Role Effective To"]),
            ("51", "Beneficial Interest", ["Interest Trust", "Beneficiary Party", "Beneficial Interest Type", "Interest Share Percentage",
                                           "Qualified Beneficiary Indicator", "Interest Effective From", "Interest Effective To"]),
            ("51", "Trust Distribution Request", ["Distribution Request ID", "Request Trust", "Request Beneficiary", "Distribution Purpose",
                                                  "Requested Amount", "Request Received Date", "Request Status"]),
            ("51", "Fiduciary Account Review", ["Fiduciary Review ID", "Review Trust", "Fiduciary Review Type", "Investment Discretion Indicator",
                                                "Accounts Reviewed", "Reviewer", "Review Due Date", "Review Completed Date", "Review Conclusion"]),
            ("51", "Principal and Income Allocation", ["Allocation Trust", "Source Account Activity", "Source Money Movement", "Allocation Date",
                                                       "Allocation Sequence", "Receipt or Disbursement Type", "Allocation Character",
                                                       "Principal Amount", "Income Amount", "Allocation Rule"]),
            ("51", "Fiduciary Accounting Statement", ["Statement Trust", "Accounting Period End", "Statement Approval Status"]),
            ("51", "Fiduciary Tax Return", ["Fiduciary Tax Return ID", "Return Trust", "Return Estate Case", "Filing Entity Party", "Filer EIN",
                                            "Tax Year End Date", "Fiduciary Return Type", "Distributable Net Income", "Extended Due Date",
                                            "Return Filed Date", "Return Status"]),
            ("51", "Estate Settlement Case", ["Estate Settlement Case ID", "Decedent", "Case Death Notification", "Firm Estate Role",
                                              "Fiduciary Entity", "Personal Representative", "Probate Status", "Testamentary Trust",
                                              "Case Status", "Case Closed Date"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status"]),
            ("15", "Account", ["Account ID", "Account Registration Type", "Account Status"]),
            ("15", "Account Registration Detail", ["Governing Trust"]),
        ],
        upstream=["DP-240", "DP-093", "DP-009", "DP-192", "DP-300", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET on T+1; principal and income allocations by business day 1 after posting; review and tax return status daily",
        history=("SCD type 2 on trust status, roles, provisions and interests for the life of the trust plus 10 years; every review, "
                 "allocation, tax return and estate case kept as recorded; fiduciary records kept at least 3 years after account "
                 "termination under 12 CFR 9.8 and as the trust's governing law requires, and tax returns 7 years"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Trust Party, Role Holder Party, Beneficiary Party, Request Beneficiary, Filing Entity Party, Decedent and Personal Representative resolves to a DP-240 party with no merge (Trust Party with Party Type = Trust, Decedent with Party Type = Individual); Role Holder Entity and Fiduciary Entity resolve to a DP-013 internal legal entity; Administering Trust Officer to DP-009; Reviewer to DP-192; Governing Trust on 15 Account Registration Detail to a Trust ID.",
            "Trust Role rows of one trust, role holder and Trust Role Type do not overlap; Beneficial Interest rows of one trust, beneficiary and type do not overlap; Role Effective To, Interest Effective To and Provision Effective To are on or after their start dates.",
            "Beneficial Interest Share Gaps is zero for every Administered Trust (income and principal tested separately), and on every Principal and Income Allocation with Allocation Character = Split, Principal Amount + Income Amount equals the source event's amount in DP-300 (Source Account Activity) within USD 0.01.",
            "Trust Instrument Type, Revocability, Situs Jurisdiction and Trust Status are populated on every trust; Trust Role Type and Role Effective From on every role; Review Due Date on every fiduciary review; Tax Year End Date and Fiduciary Return Type on every return.",
            "Trust Instrument Type, Provision Type and Distribution Standard are published with the value blank wherever it is Special Needs / Supplemental Needs Trust, Special Needs Purpose or Supplemental Needs Only (blanked, never relabeled), Trust Distribution Request rows with Distribution Purpose in (Health / Medical, Disability Care, Hardship / Emergency) are absent from every published row and aggregate, and Distribution Purpose, Purpose Description, Distribution Decision, Provision Summary and Role End Reason are never published; Filer EIN is published masked to its last four digits; any published slice of trusts or requests with fewer than 10 trusts is suppressed, not merged.",
            "A Principal and Income Allocation whose Allocation Date is on or before the Accounting Period End of a Fiduciary Accounting Statement of the same trust (Statement Trust = Allocation Trust) with Statement Approval Status = Approved is locked; a correction is a new allocation row with a new Allocation Sequence; daily publication by 7am ET.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Trust / Trust Instrument (TRUST-), Trust Term Provision, Trust Role, Beneficial Interest, "
               "Trust Distribution Request (TDRQ-), Fiduciary Account Review (FIRV-), Fiduciary Tax Return (TXRT-) and Estate Settlement Case "
               "(ESTATE-), all 51; source of the Trust dimension of the WP2 conformed set. The trust is not a party or an account: the party "
               "is 02's (DP-240), the account 15's (DP-093) (CW-075). "
               "Certified numbers: none owned (It owns no certified metric family). Trust assets are Client Holdings (49, DP-300) of the trust's "
               "accounts and count in DP-008 Client Assets; nothing here is summed as assets. "
               "Operating model (CD-297, CD-331): the grain is the trust company's own fiduciary record; trust accounting is a principal and "
               "income ledger, not a book of record (CW-076). If trust accounting is outsourced, principal and income allocations arrive as "
               "provider data with the provider as source and the Fiduciary Accounting Statement stays the firm's; if Form 1041 preparation is "
               "outsourced (reference default) 51 holds the filing facts only. "
               "PII tier: financial (identity for parties and estate cases). The three special-needs code values (Trust Instrument Type = Special Needs / Supplemental Needs Trust, Provision Type = Special Needs Purpose, Distribution Standard = Supplemental Needs Only) are blanked, not relabeled, in every published row, and Trust Distribution Request rows with a special-category Distribution Purpose (Health / Medical, Disability Care, Hardship / Emergency) are excluded from the published rows; those special-category facts stay in 51 for DP-352's restricted view (CW-213, CD-344). "
               "DP-352 is the only restricted view of distribution purposes and decisions (CW-213), and this product does not list DP-322 "
               "because a foundational product cannot depend on a consumer one. "
               "Boundaries: DP-351 decides fiduciary review compliance (Fiduciary Review Exception, the post-acceptance deadline); DP-352 "
               "discretionary distribution decisions; DP-353 principal and income accounting with the Fiduciary Accounting Statement (read here only for the DQ6 lock) and "
               "trustee fees (47); DP-354 estate settlement tasks with 02 death notifications and 13 ownership transfers; DP-355 beneficiary K-1 "
               "allocations. Edge direction: 50 Money Movement.Source Trust Distribution Request and 15 Account Registration Detail.Governing "
               "Trust are keys into this product; DP-302 is not listed here (Source Money Movement read as a key only) and DP-093 must not list "
               "DP-307 because this product lists DP-093. 46 Account Investment Constraint reads Source Trust Term Provision as a key. "
               "Tailoring lever: trust services offered at all (CW-018 optional domain 51; plan section 15). Reference default: offered (TR line); "
               "without it this product and DP-351 to DP-355 drop. Tailoring lever: trust records for client-trustee trusts not administered "
               "(51 SME 1). Reference default: held, with no Trust Role for the trust company; Administered Trusts counts only those with one. "
               "Tailoring lever: directed trusts (51 SME 2). Reference default: supported. Tailoring lever: principal and income act (51 SME 3). "
               "Reference default: the governing-law state's act recorded per allocation (Allocation Rule). Tailoring lever: executor or agent "
               "only (51 SME 6). Reference default: both Firm Estate Role values. Tailoring lever: special-needs purposes recorded (51 SME 8). "
               "Reference default: recorded as special category in 51 and blanked here. "
               "Taxonomy gap: Trust Distribution Request has no decided or paid date outside the restricted Distribution Decision group, so "
               "request age is measured to the as-of date only. Taxonomy gap: Fiduciary Tax Return has no original due date; it is derived from "
               "Tax Year End Date. Boundary note: the trust-account link is held once, in 15 Account Registration Detail.Governing Trust, by design (CW-075). " + GAP6 + ""
               "Drafting assumptions: Trust Status = Active; Account Status = Open; Request Status and Case Status closed values from the shared "
               "Case Status list; trustee role types; the 30-day request age band; minimum cell size 10 with suppression; USD 0.01 tolerance; the income and principal interest-type groupings of Beneficial Interest Share Gaps; the special-category Distribution Purpose values excluded. "
               "Decisions: CW-018, CW-075, CW-076, CW-077, CW-205, CW-213, CD-297, CD-344. "
               "WP1 new (CW-205): first specification, written last in group F2 as a tailoring lever. The foundational products carry the facts "
               "the candidates had given to consumers: this product publishes Trust Distribution Request (non-special rows, no purpose), "
               "Fiduciary Account Review, Principal and Income Allocation, Fiduciary Tax Return and Estate Settlement Case, and DP-351 to DP-355 "
               "read them from here and do not redefine them. Beneficial Interest and Trust Instrument Document kept from the candidate."),
    ),
}
