"""Wave WP1F (foundational), group F3 'books of record': attribute-level specifications of the wealth-manager rework
(Wealth_Manager_Rework_Plan.md sections 8.2 and 10; 00_Program/Rework/Product_Briefs/WP1_Method.md section 3).

Products, in dependency order:
- DP-432 Execution Venues & Routing Rules (48 Brokerage Orders & Execution)
- DP-580 Fund Share Register & Postings (29 Transfer Agency Operations)
- DP-301 Client Orders & Executions (48 Brokerage Orders & Execution)
- DP-431 Sweep Programs & Program Banks (50 Money Movement, Cash & Sweep)
- DP-302 Money Movement Transactions (50 Money Movement, Cash & Sweep)
- DP-300 Client Holdings, Lots & Cost Basis (49 Clearing, Settlement & Client Asset Custody)
- DP-430 Participant Balances & Ledger (16 Retirement Plan Administration)

WP1 decisions applied: the three books of record are named distinctly (CW-007, CW-101, CW-122, CW-125); one flow book per
account type (49 Client Account Activity for brokerage and managed accounts, 29 Register Transaction for TA-registered
accounts, 16 Participant Ledger Posting for participant accounts) which 06 copies (DP-006, DP-007) and nothing here
recomputes (CW-141); special-category hold and alert rows are never published here and reach consumers only through
DP-322 and the restricted views DP-456 and DP-403 (CW-213, CW-231, CD-344); the Rule 15c3-3 reserve computation is BWO
DP-445's, never DP-300's (CW-103); Program Bank and Execution Venue are conformed once, by DP-431 and DP-432 (CW-234);
the share register is published once, by DP-580 (CW-261). See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-432": dict(
        definition=("The conformed master of the execution venues the self-clearing broker-dealer routes client orders to "
                    "and of the versioned routing rules that send each order class to a primary and fallback venue. It "
                    "publishes the CONCEPT_OWNERSHIP rows Execution Venue Profile and Routing Rule (48, CW-100, CW-176) on "
                    "the 02 venue party, with the 48 Rule 605 Report Line rows as companion facts. It is the one source of "
                    "the Venue and Routing Rule dimensions, so routes, executions, Rule 605 and 606 reporting and the "
                    "best-execution review mean the same venue. The execution-quality analytics are BWO DP-436's, which "
                    "reads the venue and the Rule 605 lines from here. It owns no certified metric family."),
        business_questions=[
            "Which execution venues are active today, of which type and affiliation, and which accept payment for order flow?",
            "Which routing rule version applies to each instrument class, order type and trading session, and which rules lack an approving review or a fallback venue?",
            "Which active routing rules point at a venue whose profile is not active on the as-of date?",
            "Which Rule 605 lines exist for each report month, and what covered orders, covered shares and price-improved shares do they carry by order type and size bucket?",
        ],
        grain=("Venue party (02 PTY-) x profile effective period for the venue master, and routing rule code x effective "
               "period for the rule master, with Rule 605 Report Line (reporting broker-dealer x month x security x Rule 605 order "
               "type x size bucket) as companion facts; SCD type 2 on profiles and rules"),
        dimensions=["Venue (02 party) and Venue MIC", "Venue Type", "Affiliated Venue Indicator", "Payment for Order Flow Indicator",
                    "Routing Rule (code and version)", "Rule Instrument Class", "Order class and client order type",
                    "Trading session", "Rule 605 order type and size bucket", "Reporting broker-dealer (DP-013)",
                    "Security (DP-097)", "Report month (DP-013)", "Effective date"],
        measures=[
            ("Active Execution Venues", "Count of distinct Venue Party with Venue Profile Status = Active and Venue Profile Effective From <= as-of date < Venue Profile Effective To (or open), by Venue Type.",
             _u("48", "Execution Venue Profile", "Venue Party", "Venue Profile Status", "Venue Profile Effective From", "Venue Profile Effective To", "Venue Type")),
            ("Market Venues Without MIC", "Active Execution Venues whose Venue Type is National Securities Exchange, Options Exchange or Alternative Trading System and whose Venue MIC is blank.",
             _u("48", "Execution Venue Profile", "Venue MIC") + ["Active Execution Venues"]),
            ("Affiliated Venues", "Active Execution Venues with Affiliated Venue Indicator = Y.",
             _u("48", "Execution Venue Profile", "Affiliated Venue Indicator") + ["Active Execution Venues"]),
            ("Venues Accepting Payment for Order Flow", "Active Execution Venues with Payment for Order Flow Indicator = Y, shown with Order Flow Payment Terms; zero under the reference default (no payment for order flow accepted).",
             _u("48", "Execution Venue Profile", "Payment for Order Flow Indicator", "Order Flow Payment Terms") + ["Active Execution Venues"]),
            ("Active Routing Rules", "Count of Routing Rule versions with Routing Rule Effective From <= as-of date < Routing Rule Effective To (or open), by Rule Instrument Class, Rule Order Types and Rule Trading Sessions.",
             _u("48", "Routing Rule", "Routing Rule Code", "Routing Rule Effective From", "Routing Rule Effective To", "Rule Instrument Class", "Rule Order Types", "Rule Trading Sessions")),
            ("Routing Rules Without Approving Review", "Active Routing Rules whose Approving Review (the 08 best-execution committee review) is blank.",
             _u("48", "Routing Rule", "Approving Review") + ["Active Routing Rules"]),
            ("Routing Rules Without Fallback Venue", "Active Routing Rules whose Fallback Venues is blank.",
             _u("48", "Routing Rule", "Fallback Venues") + ["Active Routing Rules"]),
            ("Routing Rules Pointing at Inactive Venue", "Active Routing Rules whose Primary Venue, or any party in Fallback Venues, has no Execution Venue Profile with Venue Profile Status = Active effective on the as-of date.",
             _u("48", "Routing Rule", "Primary Venue", "Fallback Venues") + ["Active Routing Rules", "Active Execution Venues"]),
            ("Instrument Classes Without Active Routing Rule", "Count of Rule Instrument Class values of the Routing Instrument Class list for which no Active Routing Rule exists on the as-of date.",
             _u("48", "Routing Rule", "Rule Instrument Class") + ["Active Routing Rules"]),
            ("Rule 605 Covered Orders", "Sum of Covered Order Count and of Covered Order Shares on Rule 605 Report Line rows of the Rule 605 Report Month, by Rule 605 Reporting Entity, Rule 605 Order Type, Rule 605 Order Size Bucket and Rule 605 Notional Size Range.",
             _u("48", "Rule 605 Report Line", "Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Order Type", "Rule 605 Order Size Bucket", "Rule 605 Notional Size Range", "Covered Order Count", "Covered Order Shares")),
            ("Rule 605 Price-Improved Shares", "Sum of Price Improved Shares on the Rule 605 Report Line rows of the Rule 605 Report Month, by Rule 605 Order Type and Rule 605 Order Size Bucket, published as reported; the price-improvement rates and venue comparisons are DP-436's.",
             _u("48", "Rule 605 Report Line", "Price Improved Shares", "Rule 605 Report Month", "Rule 605 Order Type", "Rule 605 Order Size Bucket")),
            ("Rule 605 Report Lines Published", "Count of Rule 605 Report Line rows per Rule 605 Reporting Entity and Rule 605 Report Month, by Rule 605 Order Type and Rule 605 Order Size Bucket, with the count of distinct Rule 605 Security; the completeness count of the monthly report.",
             _u("48", "Rule 605 Report Line", "Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Order Type", "Rule 605 Order Size Bucket", "Rule 605 Security")),
        ],
        inputs=[
            ("48", "Execution Venue Profile", ["Venue Party", "Venue Type", "Venue MIC", "Rule 606 Venue Name", "Payment for Order Flow Indicator",
                                               "Order Flow Payment Terms", "Affiliated Venue Indicator", "Venue Profile Status",
                                               "Venue Profile Effective From", "Venue Profile Effective To"]),
            ("48", "Routing Rule", ["Routing Rule Code", "Rule Instrument Class", "Rule Order Types", "Rule Size Range", "Rule Trading Sessions",
                                    "Primary Venue", "Fallback Venues", "Approving Review", "Routing Rule Effective From",
                                    "Routing Rule Effective To"]),
            ("48", "Rule 605 Report Line", ["Rule 605 Reporting Entity", "Rule 605 Report Month", "Rule 605 Security", "Rule 605 Order Type",
                                            "Rule 605 Order Size Bucket", "Rule 605 Notional Size Range", "Covered Order Count",
                                            "Covered Order Shares", "Average Effective Spread", "Price Improved Shares",
                                            "Average Time To Execution"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Merged Into Party"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Instrument Status"]),
        ],
        upstream=["DP-240", "DP-013", "DP-097"],
        refresh="Daily",
        timeliness="Venue and rule changes by 7am ET on the business day after approval (event stream on change); Rule 605 lines by the 25th calendar day of the month after the report month (SEC Rule 605(a)(3): published within one month after month-end)",
        history="SCD type 2 on venue profiles and routing rule versions since the start of the order management record; Rule 605 lines kept at least six years (SEC Rule 17a-4); no deletion",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "Regulatory report"],
        dq_rules=[
            "Every Venue Party, Primary Venue and party in Fallback Venues resolves to a DP-240 party with Party Status active and no Merged Into Party; every Rule 605 Reporting Entity resolves to an active DP-013 internal legal entity and every Rule 605 Security to a DP-097 instrument.",
            "Execution Venue Profile rows of one Venue Party do not overlap in effective period and Venue Profile Effective To is on or after Venue Profile Effective From; the same holds for the versions of one Routing Rule Code.",
            "On every business day each Routing Rule version effective that day has a Primary Venue with an Execution Venue Profile of Venue Profile Status Active effective that day, and on every Rule 605 Report Line Price Improved Shares is not greater than Covered Order Shares and Covered Order Shares is zero only when Covered Order Count is zero.",
            "Venue Type, Venue Profile Status and (for exchanges and ATSs) Venue MIC are populated on every profile; Rule Instrument Class and Primary Venue on every routing rule; Covered Order Count, Covered Order Shares, Average Effective Spread and Average Time To Execution on every Rule 605 line.",
            "No Execution Venue Profile has a Venue Party whose Party Type is an individual, so the product publishes firm-level data only and its views carry no personal data.",
            "Rule 605 Report Line rows for report month M are complete for every Rule 605 Order Type and Rule 605 Order Size Bucket traded by the 25th calendar day of month M+1, ahead of the SEC Rule 605(a)(3) requirement to publish the report within one month after the end of the month.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Execution Venue Profile and Routing Rule (48, CW-100, W5 concept sweep "
               "CW-176); source of the Venue and Routing Rule dimensions of the WP2 conformed set (plan section 8.4). Party "
               "identity, LEI and CRD of the venue are read from 02 through DP-240 and never copied (row rule on Venue Party). "
               "Certified numbers: none. PII tier: none. The dp_model warning is accepted: it fires on the 48 attributes Venue "
               "Party, Routing Rule Code and Rule 605 Reporting Entity only because their Notes carry the tier line 'Object PII "
               "tier: No PII', which the validator's PII pattern matches; they are not personal data. The only personal-data "
               "attributes read are the 02 Party attributes (Party ID, Party Type, Party Display Name), which are personal data only for individuals, and DQ5 "
               "keeps individual parties out, so pii = N. Boundaries (lead ruling, F3 fix pass): this foundation publishes "
               "the venue and routing-rule facts and the Rule 605 Report Line facts; the execution-quality analytics (the 48 "
               "Execution Quality Measure, price improvement and effective-spread statistics, the Rule 605 ratios, the Rule "
               "606 lines, the routing disclosure requests, the 22 quote snapshot and the venue comparison) are BWO DP-436's, "
               "which reads the Venue and Routing Rule dimensions and the Rule 605 lines 'from DP-432' and reads Execution "
               "Quality Measure directly from 48. The client orders, routes and executions that use the venue are DP-301's; "
               "the best-execution committee review is 08's (CW-100) and is carried only as the Approving Review key; trade "
               "surveillance is 38's. Register-row note: the row is Master & Reference; by assignment it also carries the "
               "Rule 605 Report Line fact object. Acceptance question 5: feeds DP-436 and DP-437 with the Venue and Routing "
               "Rule dimensions, Rule 605 Covered Orders and Rule 605 Price-Improved Shares (48). "
               "Tailoring lever: payment for order flow. Reference default: none accepted; Order Flow Payment Terms holds "
               "'None accepted' and becomes a CDE if the firm accepts it (48 lever 2). Tailoring lever: Rule 605 scope. "
               "Reference default: the broker-dealer has 100,000 or more customers and publishes Rule 605 lines; a smaller "
               "firm drops them and keeps Execution Quality Measure (48 lever 7). Tailoring lever: overnight trading. "
               "Reference default: pre-market and after-hours only; an Overnight session adds routing rules to overnight ATSs "
               "(48 lever 4). Tailoring lever: clearing model. Reference default: self-clearing; under an introducing "
               "arrangement the product keeps its grain (CW-235). Taxonomy gap: Routing Rule has no rule status; an active "
               "rule is one whose effective period covers the date. Regulatory timing: Rule 605 reports are published within "
               "one month after month-end (SEC Rule 605(a)(3)). Drafting assumptions: venue types counted as market venues "
               "for the MIC test; the 25th-day load for Rule 605 lines. Decisions: CW-007, CW-100, CW-115, "
               "CW-176, CW-234, CW-235, CD-143. WP1 new (CW-234): new foundational master of the BWO brief, specified in "
               "group F3 with the Rule 605 lines assigned to it; at the F3 fix pass the Execution Quality Measure object and "
               "the execution-quality measures moved to DP-436 (lead ruling 3)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-580": dict(
        definition=("The transfer agent's book of record for every account registered at the in-house TA (SEC Rule "
                    "17Ad-10): the daily Share Register Balance by registered account, share class and business date, and "
                    "every posted Register Transaction with its NAV applied, amounts, originating fund order, AP order or "
                    "distribution, together with the Fund Orders (including the Brokerage Omnibus Order Detail of the "
                    "broker-dealer omnibus account) and Settlement Obligations that produce them, as facts. It publishes "
                    "the CONCEPT_OWNERSHIP rows Share Register Balance and Register Transaction (29, CW-122) once (CW-261). "
                    "It carries shares and posted amounts only, never market value or Client Assets, and publishes shares "
                    "by Register Account Category so that the 06 view counts only the directly registered client accounts "
                    "and treats the omnibus, nominee and plan rows as look-through books. It is not one of the three books "
                    "of record of client holdings (CW-007) and owns no certified metric family."),
        business_questions=[
            "How many shares of each share class are registered today, by register account category and register keeper, and how many are uncollected, escrowed or restricted?",
            "How many shares are held in directly registered client accounts (fund-only and institutional direct), and how many sit in omnibus, nominee and plan accounts whose look-through is another book?",
            "Which register accounts do not roll forward from yesterday's balance through today's posted transactions?",
            "Which register transactions were posted as-of, reversed or corrected, and which posted at a price other than the applied NAV?",
            "What gross amounts, sales charges, redemption fees and tax withheld were posted, by register transaction type?",
        ],
        grain=("Registered account (15) x share class (01) x business date for Share Register Balance (daily snapshot), with "
               "Register Transaction (RGTX-), Fund Order (FNDO-) with its Brokerage Omnibus Order Detail, and Settlement "
               "Obligation as companion facts at their own grain; append-only postings"),
        dimensions=["Registered account (DP-093)", "Share class (DP-004)", "Register Account Category", "Register Keeper (DP-240)",
                    "Register transaction type and share movement direction", "Fund order type and order origin",
                    "Cut-off result", "Order settlement method", "Business date, trade date and settlement date (DP-013)"],
        measures=[
            ("Registered Shares", "Sum of Registered Shares on Share Register Balance rows of the Register Business Date, by Register Share Class, Register Account Category (every category) and Register Keeper.",
             _u("29", "Share Register Balance", "Register Account", "Register Share Class", "Register Business Date", "Register Account Category", "Registered Shares", "Register Keeper")),
            ("Fund-Only Registered Shares", "Registered Shares on rows whose Register Account Category is Fund-Only or Institutional Direct: the directly registered client accounts, whose register shares the 06 Fund Shareholder Position view reads as its source (CW-122). Every other category is excluded from this selection.",
             _u("29", "Share Register Balance", "Register Account Category") + ["Registered Shares"]),
            ("Look-Through Category Registered Shares", "Registered Shares on rows whose Register Account Category is Broker-Dealer Omnibus, Plan Omnibus, DTC Nominee, Intermediary Omnibus, Networked or CIT Unitholder, by category: shares whose owners are counted in another book (49 Client Holding through DP-300, 16 Participant Balance through DP-430, the DTC participants' books, or the 06 intermediary look-through), never added to Fund-Only Registered Shares. Firm Proprietary rows are firm assets and are shown only in Registered Shares.",
             _u("29", "Share Register Balance", "Register Account Category") + ["Registered Shares"]),
            ("Uncollected Shares", "Sum of Uncollected Shares on the Register Business Date, by Register Share Class.",
             _u("29", "Share Register Balance", "Uncollected Shares", "Register Share Class", "Register Business Date")),
            ("Escrowed, Pledged or Restricted Shares", "Sum of Escrowed or Pledged Shares plus Restricted Shares on the Register Business Date, with the count of rows carrying a Governing Account Restriction (the 15 restriction key only; its type is not read, and Rule 2165 restrictions are DP-583's over DP-322).",
             _u("29", "Share Register Balance", "Escrowed or Pledged Shares", "Restricted Shares", "Governing Account Restriction", "Register Business Date")),
            ("Register Roll-Forward Breaks", "Count of register account x share class pairs where Registered Shares on day D minus Registered Shares on the prior business day differs from the sum of Shares Posted (signed by Share Movement Direction) of Register Transactions with Register Transaction Status = Posted and Posting Date = D, by more than 0.001 shares.",
             _u("29", "Register Transaction", "Posting Account", "Posting Share Class", "Shares Posted", "Share Movement Direction", "Register Transaction Status", "Posting Date") + ["Registered Shares"]),
            ("Register Transactions Posted", "Count of Register Transaction rows and sum of Shares Posted with Register Transaction Status = Posted and Register Trade Date in the period, by Register Transaction Type and Share Movement Direction.",
             _u("29", "Register Transaction", "Register Transaction ID", "Register Transaction Type", "Register Trade Date", "Register Transaction Status", "Shares Posted", "Share Movement Direction")),
            ("Gross Amount Posted", "Sum of Gross Amount of posted Register Transactions in the period, by Register Transaction Type, within one Register Transaction Currency; an operational posted amount, never a flow or Net New Assets figure (those are DP-006 and DP-008).",
             _u("29", "Register Transaction", "Gross Amount", "Register Transaction Currency", "Register Transaction Type") + ["Register Transactions Posted"]),
            ("Charges and Withholding Posted", "Sum of Sales Charge Amount, Redemption Fee Amount and Tax Withheld Amount, and of Net Amount, on posted Register Transactions in the period, within one Register Transaction Currency.",
             _u("29", "Register Transaction", "Sales Charge Amount", "Redemption Fee Amount", "Tax Withheld Amount", "Net Amount", "Register Transaction Currency") + ["Register Transactions Posted"]),
            ("As-Of Posting Rate", "Register Transactions Posted with As-Of Posting Indicator = Y / Register Transactions Posted, by Register Trade Date month.",
             _u("29", "Register Transaction", "As-Of Posting Indicator") + ["Register Transactions Posted"]),
            ("Reversed or Corrected Register Transactions", "Count of Register Transaction rows with Register Transaction Status in (Reversed, Corrected) and Posting Date in the period, each linked to its Reversed Register Transaction.",
             _u("29", "Register Transaction", "Register Transaction Status", "Reversed Register Transaction", "Posting Date")),
            ("Price Applied Differs From NAV", "Count of posted Register Transactions with Sales Charge Amount = 0 whose Price per Share Applied differs from the NAV per Share of the 27 Share Class NAV named in Applied NAV Record (read from DP-165) by more than 0.00005.",
             _u("29", "Register Transaction", "Price per Share Applied", "Applied NAV Record", "Sales Charge Amount") + _u("27", "Share Class NAV", "Share Class NAV ID", "NAV per Share") + ["Register Transactions Posted"]),
        ],
        inputs=[
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date", "Register Account Category",
                                              "Registered Shares", "Collected Shares", "Uncollected Shares", "Escrowed or Pledged Shares",
                                              "Restricted Shares", "Governing Account Restriction", "Last Register Transaction",
                                              "Register Keeper"]),
            ("29", "Register Transaction", ["Register Transaction ID", "Register Transaction Type", "Posting Account", "Posting Share Class",
                                            "Register Trade Date", "Register Settlement Date", "Posting Date", "As-Of Posting Indicator",
                                            "Shares Posted", "Share Movement Direction", "Applied NAV Record", "Price per Share Applied",
                                            "Gross Amount", "Sales Charge Amount", "Redemption Fee Amount", "Tax Withheld Amount",
                                            "Net Amount", "Register Transaction Currency", "Originating Fund Order",
                                            "Originating AP Order", "Originating Distribution Declaration",
                                            "Register Transaction Status", "Reversed Register Transaction"]),
            ("29", "Fund Order", ["Fund Order ID", "Fund Order Type", "Order Share Class", "Order Account", "Requested Amount", "Requested Units",
                                  "Order Received Timestamp", "Cut-Off Result", "Trade Date Assigned", "Fund Order Status",
                                  "Order Origin", "Resulting Transaction"]),
            ("29", "Brokerage Omnibus Order Detail", ["Omnibus Aggregation Date", "Omnibus Aggregation Cycle", "Aggregated Client Order Count",
                                                      "Aggregated Purchase Amount", "Aggregated Redemption Amount",
                                                      "Aggregated Redemption Units", "Side Netting Indicator"]),
            ("29", "Settlement Obligation", ["Settlement Obligation ID", "Obligation Fund Order", "Obligation AP Order", "Obligation Flow Direction",
                                             "Obligation Amount", "Contractual Settlement Date", "Order Settlement Method",
                                             "Obligation Settlement Status", "Actual Settlement Date"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "NAV per Share"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("01", "Share Class", ["Share Class ID", "Share Class Status"]),
        ],
        upstream=["DP-093", "DP-004", "DP-013", "DP-165", "DP-240"],
        refresh="Daily",
        timeliness="The daily refresh applies to the register: balances and postings of business date D by 6am ET on D+1, after the TA nightly cycle; fund orders and settlement obligations are also streamed intraday as facts by event stream",
        history="Daily register balance snapshots and every register transaction kept permanently for the life of the account and at least six years after (SEC Rules 17Ad-6 and 17Ad-7, 17Ad-10 record of securityholders); postings append-only with reversals as new rows",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "File extract"],
        dq_rules=[
            "Every Register Account, Posting Account and Order Account resolves to a DP-093 account, every Register Share Class, Posting Share Class and Order Share Class to a DP-004 share class, every Applied NAV Record to a DP-165 Share Class NAV of the same share class, and every Register Keeper to a DP-240 party.",
            "There is exactly one Share Register Balance row per Register Account x Register Share Class x Register Business Date, and Register Settlement Date is on or after Register Trade Date on every Register Transaction.",
            "For every Register Account x Register Share Class and business date D, Registered Shares on D equals Registered Shares on the prior business date plus the signed Shares Posted of Register Transactions with Register Transaction Status Posted and Posting Date D, within 0.001 shares, and on every Share Register Balance row Collected Shares plus Uncollected Shares equals Registered Shares within 0.001 shares.",
            "Register Account Category and Registered Shares are populated on every balance row; Register Transaction Type, Shares Posted, Share Movement Direction, Register Trade Date, Gross Amount, Net Amount and Register Transaction Status on every transaction; Trade Date Assigned and Cut-Off Result on every priced fund order.",
            "Account-level rows are visible to transfer agency, compliance and fund accounting roles only; every other view aggregates to share class x Register Account Category x date; no party name, TIN or date of birth is joined into the product, and Governing Account Restriction is published as a key only.",
            "Postings of business date D are published by 6am ET on D+1 and a business date is locked once the TA control checks for D are signed off; later changes post as new Register Transactions with As-Of Posting Indicator = Y or Register Transaction Status Reversed or Corrected.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Share Register Balance and Register Transaction (29, CW-122), and Fund "
               "Order (29, FNDO-) as the order that produces the posting; source of the share register for the 06 Fund "
               "Shareholder Position view (DP-007), the stock record reconciliation (DP-446), the capital stock proof "
               "(DP-181) and fund filings. It is the flow book of TA-registered (fund-only) accounts: DP-006 copies Register "
               "Transactions as declared-source flows and nothing is recomputed here (CW-141). Certified numbers: none owned; "
               "it publishes shares, never market value or Client Assets. NAV per Share is read from DP-165 (27) only to test "
               "the price applied; shares outstanding stay DP-165's. Operating model (CD-297, CD-331): in-house transfer agent "
               "(reference default): the grain is the operational register; outsourced, the provider's register file is a "
               "received record, Register Keeper names the provider and the grain is unchanged. PII tier: financial. "
               "Account-level balances of individuals' fund-only accounts are personal data; the share-class aggregate view "
               "carries none (DQ5). Book selection (lead ruling, F3 fix pass): shares are published by every Register Account "
               "Category with Register Keeper; Fund-Only Registered Shares selects only the directly registered client "
               "accounts (Fund-Only, Institutional Direct). Broker-Dealer Omnibus rows look through to 49 Client Holding "
               "(DP-300), Plan Omnibus rows to 16 Participant Balance (DP-430), DTC Nominee rows to the DTC participants' "
               "books (the firm's own share through DP-300), and Intermediary Omnibus and Networked rows to the 06 "
               "intermediary look-through; Firm Proprietary rows are firm assets and never client assets. DP-007 selects the "
               "counted rows by the 06 Aggregation Role; this product never sums across books. Boundaries (lead ruling 3): "
               "this foundation publishes the register, the posted transactions and the fund orders, omnibus order detail "
               "and settlement obligations as facts; the analytics on them are the live consumers': cut-off control, "
               "forward-pricing tests and fund-order processing exceptions are DP-177 Fund Order Processing & Cut-Off "
               "Control's, and settlement obligations past due, intermediary settlement batches and fund-side settlement cash "
               "(29 Cash Movement) are DP-178 Shareholder Settlement with Intermediaries'. Both should read these facts 'from "
               "DP-580' at their re-spec. The omnibus aggregation evidence was the candidate DP-582's, now in the backlog with "
               "no merge target (WP1_Scope.md), which is why Brokerage Omnibus Order Detail is published here as a fact and "
               "not analyzed. The 49-to-29 omnibus reconciliation is DP-446's; client lots of fund-only accounts are 49 "
               "Client Tax Lots (DP-300) opened and relieved by these transactions; frequent-trading and Rule 22c-2 requests "
               "are DP-585's; holds and Rule 2165 restrictions are DP-583's; distribution amounts are DP-171's. The Brokerage "
               "Omnibus Order Detail aggregates are Derived copies of 48 held only on the 29 order, so they are read here and "
               "reconciled to DP-301 by the consumer (no DP-301 edge, which keeps DP-301 free to read Resulting Fund Order "
               "from here). Acceptance question 1: feeds DP-007 (and through it DP-008) and DP-446 with Fund-Only Registered "
               "Shares and Look-Through Category Registered Shares (29). Tailoring lever: networked brokerage sub-accounts. Reference "
               "default: one omnibus account per share class; networked, the register holds one row per sub-account and the "
               "fund order becomes one per client order (29 SME 2). Tailoring lever: outsourced TA. Reference default: in "
               "house. Tailoring lever: fund-only accounts. Reference default: existing accounts kept, none opened; the lever "
               "converts them to brokerage accounts and drops Fund-Only (29 SME 3). Tailoring lever: side netting on the "
               "omnibus order. Reference default: not netted (29 SME 7). Design note: a settlement obligation is keyed to "
               "the fund order or AP order by design, so obligation-to-posting is matched through Obligation Fund Order and "
               "Originating Fund Order. Drafting assumptions: the "
               "0.001-share roll-forward tolerance; the 0.00005 price tolerance; Institutional Direct counted with Fund-Only "
               "as directly registered client accounts. Decisions: CW-007, CW-097, CW-107, "
               "CW-122, CW-123, CW-141, CW-261, CD-199, CD-200, CD-297. WP1 new (CW-261): new foundational product of the FOP "
               "brief; adds Fund Order, Brokerage Omnibus Order Detail and Settlement Obligation to the candidate's objects "
               "by assignment as published facts; reads 27 Share Class NAV for the price test only. F3 fix pass: drops "
               "'Registered Shares Excluding Broker-Dealer Omnibus' (replaced by Fund-Only Registered Shares and Look-Through "
               "Category Registered Shares) and hands the cut-off, omnibus and settlement measures to DP-177 and DP-178."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-301": dict(
        definition=("Every client order in every product the platform offers, with its instruction detail, option legs, "
                    "lifecycle events and routes, the block orders that aggregate them, and the executions, allocations to "
                    "accounts, Rule 10b-10 confirmations, trade corrections and CAT reportable events that follow, plus the "
                    "pre-trade risk limits orders are checked against. It publishes the CONCEPT_OWNERSHIP rows Client Order "
                    "(48, CLORD-), Order Route, Client Execution, Client Block Order, Client Allocation, Client Trade "
                    "Confirmation and Trade Correction (CW-096, CW-098) once, so execution quality, CAT completeness, "
                    "managed-account trading, commissions and surveillance read the same orders. Venues and routing rules "
                    "come from DP-432 and are never copied. It owns no certified metric family."),
        business_questions=[
            "How many client orders were received today by source, entry channel, order type and instrument type, and how many filled, were rejected or remain open?",
            "How long did orders take from receipt to first route, and which routes left the routing rule default?",
            "Which block orders are not fully allocated, and which allocations have no Rule 10b-10 confirmation by the next business day?",
            "How many trade corrections were made per 10,000 allocations, by correction type and reason, and how many were as-of trades?",
        ],
        grain=("Client order (CLORD-) with its instruction detail, with option legs, order events, routes (ROUTE-), client "
               "block orders (CLBLK-), executions (CLEXE-), allocations, confirmation versions (CCONF-), trade corrections "
               "(TCORR-) and CAT reportable events as companion facts at their own grain, and Pre-Trade Risk Limit as a "
               "reference companion (SCD type 2); facts append-only"),
        dimensions=["Client account (DP-093)", "Instrument (DP-097)", "Venue and Routing Rule (DP-432)", "Order source and entry channel",
                    "Client order type, time in force and trading session", "Order side", "Execution capacity",
                    "Block origin and allocation method", "Correction type and reason", "CAT event type and report status",
                    "Pre-trade limit type and scope", "Entering and block employee (DP-192)",
                    "Executing broker-dealer (DP-013)", "Trade date and settlement date (DP-013)"],
        measures=[
            ("Client Orders Received", "Count of Client Order rows with Order Received Timestamp in the period, by Order Source, Order Entry Channel, Client Order Type, Order Side, Solicited Indicator, Discretionary Order Indicator and the Instrument Type of Order Instrument.",
             _u("48", "Client Order", "Client Order ID", "Order Received Timestamp", "Order Source", "Order Entry Channel", "Order Side", "Solicited Indicator", "Discretionary Order Indicator", "Order Instrument") + _u("48", "Order Instruction Detail", "Client Order Type") + _u("17", "Instrument", "Instrument Type")),
            ("Client Orders Filled %", "Client Orders Received whose Client Order Status = Filled / Client Orders Received with Client Order Status not Rejected.",
             _u("48", "Client Order", "Client Order Status") + ["Client Orders Received"]),
            ("Client Orders Rejected", "Client Orders Received with Client Order Status = Rejected, by Order Rejection Reason.",
             _u("48", "Client Order", "Client Order Status", "Order Rejection Reason") + ["Client Orders Received"]),
            ("Day Orders Without Terminal Status", "Count of Client Orders with Time in Force = Day, Order Received Timestamp before the current trade date and Client Order Status in (Pending New, New, Partially Filled, Pending Cancel, Pending Replace).",
             _u("48", "Client Order", "Client Order Status", "Order Received Timestamp") + _u("48", "Order Instruction Detail", "Time in Force")),
            ("Executed Quantity and Notional", "Sum of Executed Quantity and of Executed Quantity x Execution Price of Client Execution rows by Execution Trade Date, Execution Venue MIC and Execution Capacity, within one Execution Currency.",
             _u("48", "Client Execution", "Client Execution ID", "Executed Quantity", "Execution Price", "Execution Currency", "Execution Trade Date", "Execution Venue MIC", "Execution Capacity")),
            ("Price Improvement Amount", "Sum of Price Improvement Per Share x Executed Quantity over Client Executions in the period, by Execution Venue MIC and Extended-Hours Execution Indicator.",
             _u("48", "Client Execution", "Price Improvement Per Share", "Executed Quantity", "Execution Venue MIC", "Extended-Hours Execution Indicator")),
            ("Route Fill Ratio", "Sum of Executed Quantity of executions whose Execution Order Route is the route / sum of Routed Quantity, by Route Venue and Applied Routing Rule.",
             _u("48", "Client Execution", "Execution Order Route", "Executed Quantity") + _u("48", "Order Route", "Order Route ID", "Routed Quantity", "Route Venue", "Applied Routing Rule")),
            ("Receipt to First Route Latency", "Median over client orders of (the earliest Routed Timestamp of the routes whose Routed Client Order is the order) minus Order Received Timestamp, in milliseconds, by Order Entry Channel and Trading Session.",
             _u("48", "Order Route", "Routed Client Order", "Routed Timestamp") + _u("48", "Client Order", "Order Received Timestamp", "Order Entry Channel") + _u("48", "Order Instruction Detail", "Trading Session")),
            ("Routes Off Routing Rule Default %", "Order Route rows whose Routing Decision Basis is Fallback - Venue Unavailable or Manual Trader Handling / all Order Route rows routed in the period.",
             _u("48", "Order Route", "Routing Decision Basis", "Routed Timestamp")),
            ("Unallocated Block Quantity", "For each Client Block Order created before the current trade date, the Executed Quantity of the Client Executions whose Execution Order Route is a route whose Routed Client Block Order is the block minus the sum of Allocated Quantity and Fractional Remainder Quantity of its Client Allocation rows (Allocation Client Block Order); reported where nonzero, by Block Origin.",
             _u("48", "Client Block Order", "Client Block Order ID", "Block Origin", "Block Created Timestamp") + _u("48", "Order Route", "Routed Client Block Order") + _u("48", "Client Execution", "Execution Order Route") + _u("48", "Client Allocation", "Allocation Client Block Order", "Allocated Quantity", "Fractional Remainder Quantity") + ["Executed Quantity and Notional"]),
            ("Allocations Without Confirmation", "Count of Client Allocation rows with Allocation Timestamp on trade date T for which no Client Trade Confirmation with Confirmed Client Allocation = the allocation and Confirmation Type = Original exists by the end of T+1 (SEC Rule 10b-10).",
             _u("48", "Client Allocation", "Allocated Client Order", "Allocation Timestamp") + _u("48", "Client Trade Confirmation", "Confirmed Client Allocation", "Confirmation Type")),
            ("Confirmed Net Amount", "Sum of Net Amount of the current confirmation version (no later version names it in Superseded Confirmation) by Confirmed Trade Date and Confirmed Capacity.",
             _u("48", "Client Trade Confirmation", "Client Trade Confirmation ID", "Confirmation Version", "Superseded Confirmation", "Net Amount", "Confirmed Trade Date", "Confirmed Capacity")),
            ("Commission Charged on Confirmations", "Sum of Commission Charged on current confirmation versions by Confirmed Trade Date; an operational billed amount, never client fee revenue (DP-012).",
             _u("48", "Client Trade Confirmation", "Commission Charged", "Confirmed Trade Date") + ["Confirmed Net Amount"]),
            ("Trade Corrections", "Count of Trade Correction rows in the period by Correction Type, Trade Correction Reason and As-Of Trade Indicator.",
             _u("48", "Trade Correction", "Trade Correction ID", "Corrected Client Allocation", "Correction Type", "Trade Correction Reason", "As-Of Trade Indicator")),
            ("Corrections per 10,000 Allocations", "Trade Corrections / count of Client Allocation rows with Allocation Timestamp in the period x 10,000.",
             _u("48", "Client Allocation", "Allocation Timestamp") + ["Trade Corrections"]),
            ("Corrections Without Resulting Confirmation", "Trade Corrections of Correction Type in (Correct, Cancel and Rebill, As-Of Trade) whose Resulting Confirmation is blank, or whose resulting confirmation does not name the correction in Originating Trade Correction.",
             _u("48", "Trade Correction", "Resulting Confirmation") + _u("48", "Client Trade Confirmation", "Originating Trade Correction") + ["Trade Corrections"]),
        ],
        inputs=[
            ("48", "Client Order", ["Client Order ID", "Order Account", "Order Instrument", "Order Side", "Order Quantity", "Order Notional Amount",
                                    "Order Quantity Basis", "Order Source", "Source Trade Proposal", "Source Recommendation",
                                    "Entering Employee", "Order Entry Channel", "Solicited Indicator", "Discretionary Order Indicator",
                                    "Order Received Timestamp", "Client Order Status", "Order Rejection Reason", "Original Client Order",
                                    "Parent Client Block Order", "Executing Broker-Dealer"]),
            ("48", "Order Instruction Detail", ["Client Order Type", "Limit Price", "Time in Force", "Trading Session"]),
            ("48", "Option Order Leg", ["Leg Client Order", "Leg Sequence Number", "Leg Option Series", "Leg Open Close Indicator"]),
            ("48", "Client Order Event", ["Event Client Order", "Event Sequence Number", "Client Order Event Type", "Event Timestamp",
                                          "Event Order Route", "Cumulative Filled Quantity", "Leaves Quantity"]),
            ("48", "Order Route", ["Order Route ID", "Routed Client Order", "Routed Client Block Order", "Route Venue", "Routed Quantity",
                                   "Routed Timestamp", "Applied Routing Rule", "Routing Decision Basis", "Resulting Fund Order",
                                   "Order Route Status"]),
            ("48", "Client Block Order", ["Client Block Order ID", "Block Origin", "Source Trade Proposal Batch", "Block Advisor", "Block Instrument",
                                          "Block Side", "Aggregate Quantity", "Block Created Timestamp"]),
            ("48", "Client Execution", ["Client Execution ID", "Execution Order Route", "Executed Quantity", "Execution Price", "Execution Currency",
                                        "Execution Timestamp", "Execution Trade Date", "Execution Venue MIC", "Execution Capacity",
                                        "Price Improvement Per Share", "Extended-Hours Execution Indicator"]),
            ("48", "Client Allocation", ["Allocation Client Block Order", "Allocated Client Order", "Allocated Account", "Allocated Quantity",
                                         "Allocation Average Price", "Client Allocation Method", "Fractional Remainder Quantity",
                                         "Allocation Timestamp"]),
            ("48", "Client Trade Confirmation", ["Client Trade Confirmation ID", "Confirmation Version", "Confirmation Type", "Confirmed Client Allocation",
                                                 "Confirmation Account", "Confirmed Instrument", "Confirmed Trade Date",
                                                 "Confirmed Settlement Date", "Confirmed Quantity", "Confirmed Price", "Confirmed Capacity",
                                                 "Commission Charged", "Net Amount", "Superseded Confirmation",
                                                 "Originating Trade Correction"]),
            ("48", "Trade Correction", ["Trade Correction ID", "Corrected Client Execution", "Corrected Client Allocation", "Correction Type",
                                        "Trade Correction Reason", "Correction Approved By", "As-Of Trade Indicator",
                                        "Resulting Confirmation"]),
            ("48", "CAT Reportable Event", ["CAT Record ID", "CAT Event Type", "CAT Source Client Order", "CAT Source Order Route",
                                            "CAT Source Client Execution", "CAT Source Client Allocation", "Firm Designated ID",
                                            "CAT Event Timestamp", "CAT Submission Date", "CAT Report Status", "CAT Error Code",
                                            "CAT Repair Deadline"]),
            ("48", "Pre-Trade Risk Limit", ["Pre-Trade Limit Type", "Pre-Trade Limit Scope", "Limit Scope Value", "Limit Scope Account",
                                            "Limit Instrument Class", "Limit Threshold Value", "Limit Threshold Unit", "Hard Block Indicator",
                                            "Limit Approved By", "Limit Last Review Date", "Limit Effective From", "Limit Effective To"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Business Line"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Own Share Class"]),
        ],
        upstream=["DP-093", "DP-097", "DP-432", "DP-580", "DP-304", "DP-303", "DP-192", "DP-013"],
        refresh="Intraday",
        timeliness="Orders, events, routes and executions stream as they occur; the end-of-day order book, allocations and confirmations of trade date T by 7am ET on T+1; CAT status by 8am ET on T+1",
        history="Append-only order, route, execution, allocation, confirmation and correction records kept at least six years (SEC Rule 17a-3(a)(6) and (a)(8), Rule 17a-4(b)); CAT reportable events kept with them; SCD type 2 on pre-trade risk limits",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "Regulatory report"],
        dq_rules=[
            "Every Order Account, Allocated Account and Confirmation Account resolves to a DP-093 account that is not closed at Order Received Timestamp; every Order Instrument, Block Instrument, Confirmed Instrument and Leg Option Series to a DP-097 instrument; every Route Venue and Applied Routing Rule to a DP-432 venue profile and routing rule version effective at Routed Timestamp; every Resulting Fund Order to a DP-580 Fund Order.",
            "Pre-Trade Risk Limit rows of one Pre-Trade Limit Type, Pre-Trade Limit Scope, Limit Scope Value and Limit Instrument Class do not overlap in effective period and Limit Effective To is on or after Limit Effective From; each Superseded Confirmation names a lower Confirmation Version of the same Confirmed Client Allocation.",
            "For every client order with Client Order Status = Filled the sum of Executed Quantity of the executions on its routes equals Order Quantity on a share or contract basis, and for every allocated order or block the sum of Allocated Quantity plus Fractional Remainder Quantity over its Client Allocation rows equals that executed quantity (zero tolerance).",
            "Order Received Timestamp, Order Side, Order Quantity, Order Source and Client Order Status are populated on every order; Executed Quantity, Execution Price and Execution Timestamp on every execution; Confirmed Settlement Date, Commission Charged and Net Amount on every confirmation; CAT Event Type and CAT Report Status on every CAT record.",
            "Published views carry accounts as the DP-093 key only and join no party name, TIN or date of birth; CAT Reportable Event rows carry no customer identifying information (CW-115) and their Firm Designated ID ('PII - financial (restricted)') is visible to CAT reporting and compliance roles only and masked elsewhere; row-level access is limited to brokerage trading, operations, supervision and compliance roles.",
            "Every order event and execution of trade date T is published by 7am ET on T+1, and CAT Report Status is refreshed by 8am ET on T+1, the CAT reporting deadline.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Client Order (48, CLORD-; term conflict 'Order' with the 25 fund desk "
               "Trade Order), Order Route, Client Execution, Client Block Order, Client Allocation, Client Trade Confirmation "
               "and Trade Correction (48, CW-096, CW-098), plus the W5 rows Option Order Leg, Client Order Event, Pre-Trade "
               "Risk Limit and CAT Reportable Event (CW-176); source of the Client Order dimension of the WP2 conformed set. "
               "Certified numbers: none; Commission Charged is an operational billed amount and client fee revenue is DP-012's. "
               "PII tier: financial. Account-level orders and confirmations are personal data (48 object tiers); CAT records "
               "carry the FDID only (CW-115); block orders and limits without a scope account carry none. Boundaries: venues "
               "and routing rules are DP-432's (CW-234), never copied; the Rule 605/606 and venue comparison products are "
               "DP-436; the CAT completeness and market-access (Rule 15c3-5) counts and work queues (orders without a CAT New "
               "Order event, rejected or late CAT records, repairs past deadline, pre-trade limits past their annual review) "
               "are DP-435 Order Lifecycle & CAT Completeness's (lead ruling 3, F3 fix pass): this foundation publishes the "
               "CAT Reportable Event and Pre-Trade Risk Limit facts and DP-435 reads them 'from DP-301', with the backlog "
               "DP-439 reads (Order Eligibility Check stays with DP-435); corrections and error cases are DP-437 (Trade Error "
               "Case is read there); confirmation remuneration disclosure and regulatory trade reports are DP-438; option "
               "exercises and assignments are DP-452; trade surveillance is 38's. The 49 postings of these allocations are "
               "DP-300's: 49 holds the link (Source Client Allocation), so DP-301 is upstream of DP-300 and never the reverse. "
               "For the same reason the 48 Specified Client Tax Lots attribute (a 49 lot reference) is not read here; DP-342 "
               "and DP-300 resolve lot selection. Resulting Fund Order is read from DP-580's Fund Order; Source Trade Proposal "
               "and Source Trade Proposal Batch key to DP-304 (46) and Source Recommendation to DP-303 (45), carried as keys "
               "and never re-scored. Order Notional Amount, Limit Price and the other instruction fields are published for "
               "DP-435 and DP-436. Fund desk orders stay in 25 (DP-121). Acceptance question 5: feeds DP-436 and DP-437 with "
               "Executed Quantity and Notional, Price Improvement Amount, Routes Off Routing Rule Default %, Trade Corrections "
               "and Corrections per 10,000 Allocations (48). Tailoring lever: clearing model. Reference default: "
               "self-clearing; as an introducing broker the grain is kept and the clearing firm's confirmation becomes a "
               "received record (48 lever 1, CW-235). Tailoring lever: fractional shares. Reference default: riskless "
               "principal against a facilitation account; agency-only fractional changes Fractional Handling Method (48 lever "
               "3). Tailoring lever: block allocation. Reference default: pro rata at average price with fractional remainder "
               "to the facilitation account; rotation is the alternative (48 lever 5). Tailoring lever: own-fund omnibus "
               "orders. Reference default: one 29 Fund Order per side per share class and dealing cycle; networked makes "
               "Resulting Fund Order one to one (48 lever 8). Taxonomy gap: Client Execution has no venue party reference; the "
               "venue is matched on Execution Venue MIC to the DP-432 profile and through Execution Order Route to Route Venue. "
               "Taxonomy gap: Client Allocation has no identifier; it is identified by Allocation Client Block Order or "
               "Allocated Client Order x Allocated Account, although Client Trade Confirmation.Confirmed Client Allocation "
               "and Trade Correction.Corrected Client Allocation reference it. Taxonomy gap: Client Allocation has no "
               "allocation status, so an allocation is final once its confirmation exists. Regulatory timing: the "
               "confirmation test applies SEC Rule 10b-10 (written notice at or before completion of the transaction, "
               "tested by the end of T+1); CAT events are due by 8am ET on T+1 (CAT NMS Plan; FINRA Rule 6830); the annual "
               "review of pre-trade limits is SEC Rule 15c3-5(e) (DP-435). Drafting assumptions: the open-status list for "
               "day orders. Decisions: CW-007, "
               "CW-096, CW-097, CW-098, CW-100, CW-114, CW-115, CW-123, CW-176, CW-205, CW-234, CW-235. WP1 new (CW-205): new "
               "foundational product of the WP0 framing; adds 48 Client Order Event, CAT Reportable Event and Pre-Trade Risk "
               "Limit by assignment (Pre-Trade Risk Limit was read only by backlog DP-439). F3 fix pass: the four CAT and "
               "market-access measures move to DP-435."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-431": dict(
        definition=("The conformed master of the cash sweep programs and the program banks behind them: Sweep Program with "
                    "its eligibility and eligible sweep funds, Program Bank as a role profile of the 02 bank party, Program "
                    "Bank Participation with priority, capacity, agreement and primary-purpose basis, and Sweep Rate Tier, "
                    "with Program Bank Daily Total and FDIC Coverage Assessment as companion facts. It publishes the "
                    "CONCEPT_OWNERSHIP rows Sweep Program (SWEEP-) and Program Bank (PGBNK-) (50, CW-108) and is the one "
                    "source of the Sweep Program and Program Bank dimensions (plan section 8.4) for 49, 50, 10 and 15 "
                    "readers. Bank identity is read from DP-240, agreements from DP-213. It owns no certified metric family; "
                    "program revenue is 10's."),
        business_questions=[
            "Which sweep programs and program banks are active today, and which banks are active without an approval?",
            "How much capacity does each program bank offer each program, and how much of it do today's customer deposits use?",
            "Which participations lack an active agreement or a filed primary-purpose exception notice?",
            "What client interest rate applies in each tier, and do any tiers overlap or leave gaps?",
            "How much of the deposits placed through the firm is uninsured, by program bank and FDIC ownership category?",
        ],
        grain=("Sweep program (SWEEP-) and program bank (PGBNK-, bank party x role period), joined by program bank "
               "participation (sweep program x program bank x effective period) and sweep rate tier (program x tier basis x "
               "band x effective period), with Program Bank Daily Total (program x bank x business date) and FDIC Coverage "
               "Assessment (party x ownership category x program bank x assessment date) as companion facts; SCD type 2 on "
               "the masters"),
        dimensions=["Sweep Program", "Sweep Program Type", "Program Bank (02 bank party, DP-240)", "Bank charter type",
                    "Allocation priority", "Rate tier basis and balance band", "Eligible sweep fund (DP-004)",
                    "Sponsoring broker-dealer (DP-013)", "Program bank agreement (DP-213)", "FDIC ownership category",
                    "Business date and assessment date (DP-013)"],
        measures=[
            ("Active Sweep Programs", "Count of Sweep Program rows with Program Status = Active and Program Effective From on or before the as-of date, by Sweep Program Type and Sponsoring Broker-Dealer.",
             _u("50", "Sweep Program", "Sweep Program ID", "Program Status", "Program Effective From", "Sweep Program Type", "Sponsoring Broker-Dealer")),
            ("Active Program Banks", "Count of Program Bank rows with Program Bank Status = Active, Bank Onboarding Date on or before the as-of date and Bank Exit Date blank or later, by Bank Charter Type.",
             _u("50", "Program Bank", "Program Bank ID", "Program Bank Status", "Bank Onboarding Date", "Bank Exit Date", "Bank Charter Type")),
            ("Program Banks Active Without Approval", "Active Program Banks whose Bank Approval Status is not Approved.",
             _u("50", "Program Bank", "Bank Approval Status") + ["Active Program Banks"]),
            ("Active Participations", "Count of Program Bank Participation rows with Participation Effective From <= as-of date < Participation Effective To (or open) whose Participating Program Bank is an Active Program Bank, by Participation Sweep Program and Allocation Priority.",
             _u("50", "Program Bank Participation", "Participation Sweep Program", "Participating Program Bank", "Participation Effective From", "Participation Effective To", "Allocation Priority") + ["Active Program Banks"]),
            ("Program Capacity", "Sum of Bank Capacity Amount of Active Participations, by Participation Sweep Program.",
             _u("50", "Program Bank Participation", "Bank Capacity Amount") + ["Active Participations"]),
            ("Aggregate Customer Deposits", "Sum of Aggregate Customer Deposits of Program Bank Daily Total rows of the Daily Total Business Date, by Daily Total Sweep Program and Daily Total Program Bank.",
             _u("50", "Program Bank Daily Total", "Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date", "Aggregate Customer Deposits")),
            ("Program Bank Capacity Utilization %", "Aggregate Customer Deposits / Bank Capacity Amount of the Active Participation of the same program and bank, on the business date.",
             _u("50", "Program Bank Participation", "Bank Capacity Amount") + ["Aggregate Customer Deposits", "Active Participations"]),
            ("Program Banks Over Capacity", "Count of program x bank pairs whose Program Bank Capacity Utilization % exceeds 100 on the business date.",
             ["Program Bank Capacity Utilization %"]),
            ("Daily Net Flow to Program Banks", "Sum of Net Flow Amount of Program Bank Daily Total rows of the business date, by program and bank; an operational bank movement, never a client flow.",
             _u("50", "Program Bank Daily Total", "Net Flow Amount", "Daily Total Business Date")),
            ("Interest Paid by Program Banks", "Sum of Interest Paid by Bank over the period by program and bank, as reported by the bank; program revenue is 10's (CW-156) and is never computed here.",
             _u("50", "Program Bank Daily Total", "Interest Paid by Bank", "Daily Total Business Date")),
            ("Programs Overstating Insured Coverage", "Active Sweep Programs whose Maximum Program Insured Coverage exceeds the count of their Active Participations x USD 250,000, the standard maximum deposit insurance amount per depositor, per insured bank, per ownership category (12 CFR 330.1(o)).",
             _u("50", "Sweep Program", "Maximum Program Insured Coverage") + ["Active Sweep Programs", "Active Participations"]),
            ("Client Interest Rate by Tier", "Client Interest Rate of each Sweep Rate Tier effective on the as-of date (Tier Effective From <= date < Tier Effective To or open), by Tier Sweep Program, Rate Tier Basis, Tier Lower Bound and Tier Upper Bound; published as set, never recomputed.",
             _u("50", "Sweep Rate Tier", "Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Upper Bound", "Client Interest Rate", "Tier Effective From", "Tier Effective To")),
            ("Rate Tier Gaps or Overlaps", "Count of program x Rate Tier Basis sets whose effective tiers, ordered by Tier Lower Bound, have a Tier Upper Bound that is not the next tier's Tier Lower Bound.",
             _u("50", "Sweep Rate Tier", "Tier Lower Bound", "Tier Upper Bound", "Rate Tier Basis") + ["Client Interest Rate by Tier"]),
            ("Participations Without Active Agreement", "Active Participations whose Program Bank Agreement is blank or resolves to a 39 Contract with Contract Status other than active or Contract Expiry Date before the as-of date.",
             _u("50", "Program Bank Participation", "Program Bank Agreement") + _u("39", "Contract", "Contract ID", "Contract Status", "Contract Expiry Date") + ["Active Participations"]),
            ("Primary Purpose Notices Missing", "Active Participations with Primary Purpose Exception Basis in (25 Percent Test Notice, Enabling Transactions Notice) and Exception Notice Filed Date blank.",
             _u("50", "Program Bank Participation", "Primary Purpose Exception Basis", "Exception Notice Filed Date") + ["Active Participations"]),
            ("Program Changes With Short Notice", "Sweep Program rows whose Program Change Effective Date is fewer than 30 calendar days after Program Change Notice Date (the 30-day customer notice of a sweep program change, SEC Rule 15c3-3(j)(2)(ii)).",
             _u("50", "Sweep Program", "Program Change Notice Date", "Program Change Effective Date")),
            ("Uninsured Deposits", "Sum of Uninsured Amount of FDIC Coverage Assessment rows at the latest Assessment Date, by Assessed Program Bank and FDIC Ownership Category.",
             _u("50", "FDIC Coverage Assessment", "Assessed Party", "Assessed Program Bank", "FDIC Ownership Category", "Assessment Date", "Uninsured Amount")),
            ("Parties With Uninsured Deposits", "Count of distinct Assessed Party with Uninsured Amount > 0 at the latest Assessment Date, by Assessed Program Bank.",
             _u("50", "FDIC Coverage Assessment", "Assessed Party", "Uninsured Amount", "Assessment Date")),
            ("Insured Share of Deposits Through Firm %", "Sum of Insured Amount / sum of Deposits Through Firm at the latest Assessment Date, by Assessed Program Bank and Pass-Through Recordkeeping Basis.",
             _u("50", "FDIC Coverage Assessment", "Insured Amount", "Deposits Through Firm", "Pass-Through Recordkeeping Basis")),
        ],
        inputs=[
            ("50", "Sweep Program", ["Sweep Program ID", "Sweep Program Name", "Sweep Program Type", "Sponsoring Broker-Dealer", "Eligible Account Types",
                                     "Eligible Business Lines", "Eligible Sweep Funds", "Customer Disclosure Version",
                                     "Program Change Notice Date", "Program Change Effective Date", "Maximum Program Insured Coverage",
                                     "Program Status", "Program Effective From"]),
            ("50", "Program Bank", ["Program Bank ID", "Bank Party", "FDIC Certificate Number", "Bank Charter Type", "Program Bank Status",
                                    "Bank Approval Status", "Bank Approved By", "Bank Onboarding Date", "Bank Exit Date"]),
            ("50", "Program Bank Participation", ["Participation Sweep Program", "Participating Program Bank", "Allocation Priority", "Bank Capacity Amount",
                                                  "Omnibus Account Titling", "Program Bank Agreement", "Bank Rate Formula",
                                                  "Primary Purpose Exception Basis", "Exception Notice Filed Date",
                                                  "Participation Effective From", "Participation Effective To"]),
            ("50", "Sweep Rate Tier", ["Tier Sweep Program", "Rate Tier Basis", "Tier Lower Bound", "Tier Upper Bound", "Client Interest Rate",
                                       "Tier Effective From", "Tier Effective To"]),
            ("50", "Program Bank Daily Total", ["Daily Total Sweep Program", "Daily Total Program Bank", "Daily Total Business Date",
                                                "Aggregate Customer Deposits", "Net Flow Amount", "Interest Paid by Bank"]),
            ("50", "FDIC Coverage Assessment", ["Assessed Party", "FDIC Ownership Category", "Assessed Program Bank", "Assessment Date", "Accounts Assessed",
                                                "Deposits Through Firm", "Client-Declared Direct Deposits", "Insured Amount",
                                                "Uninsured Amount", "Pass-Through Recordkeeping Basis"]),
            ("39", "Contract", ["Contract ID", "Contract Status", "Contract Expiry Date"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Status", "Merged Into Party"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Entity Status"]),
            ("01", "Share Class", ["Share Class ID", "Share Class Status"]),
        ],
        upstream=["DP-240", "DP-213", "DP-004", "DP-013", "DP-192", "DP-093"],
        refresh="Daily",
        timeliness="Program and bank master changes by 7am ET on the business day after approval (event stream on change); daily totals of business date D by 9am ET on D+1, after the program banks' settlement wires; FDIC assessments by business day 2 after each assessment date",
        history="SCD type 2 on programs, banks, participations and rate tiers since program inception; daily totals and FDIC assessments kept six years (SEC Rule 17a-4; FDIC 12 CFR 330.5 pass-through recordkeeping)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Bank Party resolves to a DP-240 party of an organization type with Party Status active and no Merged Into Party; every Sponsoring Broker-Dealer to an active DP-013 legal entity; every Eligible Sweep Funds entry to an active DP-004 share class; every Program Bank Agreement to a DP-213 contract; every Assessed Party to a DP-240 party and every Accounts Assessed entry to a DP-093 account.",
            "Program Bank Participation rows of one Participation Sweep Program and Participating Program Bank do not overlap in effective period and Participation Effective To is on or after Participation Effective From; Sweep Rate Tier rows of one program and Rate Tier Basis do not overlap in band within an effective period.",
            "For every program and program bank and business date, Aggregate Customer Deposits equals the prior business date's Aggregate Customer Deposits plus Net Flow Amount, plus Interest Paid by Bank on the days the bank credits interest to the deposits, within USD 1, and on every FDIC Coverage Assessment Insured Amount plus Uninsured Amount equals Deposits Through Firm plus Client-Declared Direct Deposits within USD 1.",
            "Program Status, Sweep Program Type and Sponsoring Broker-Dealer are populated on every program; FDIC Certificate Number and Program Bank Status on every bank; Allocation Priority and Bank Capacity Amount on every participation; Client Interest Rate on every tier; Aggregate Customer Deposits on every daily total.",
            "FDIC Coverage Assessment rows are visible at party grain to cash program and compliance roles only and are otherwise published aggregated to program bank x ownership category; the master and daily totals carry no personal data, Bank Approved By is published as the DP-192 employee key only and the omnibus deposit account number is not published.",
            "Daily totals of business date D are published by 9am ET on D+1 and locked once the program bank settlement for D is reconciled; master changes are effective-dated and never edited in place.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Sweep Program (SWEEP-) and Program Bank (PGBNK-), 50 (CW-108), with the "
               "rows Program Bank Participation, Program Bank Daily Total and FDIC Coverage Assessment (50); source of the "
               "Sweep Program and Program Bank dimensions of the WP2 conformed set (plan section 8.4). Bank identity comes "
               "from 02 through DP-240; FDIC Certificate Number and Bank Charter Type are read from the 50 Program Bank "
               "profile, because 02 does not yet hold them (W5 proposal to 02; see the taxonomy gap); contracts come from "
               "DP-213. Certified numbers: none; Client Assets of the cash "
               "and sweep holding type are DP-008's, and program revenue is 10's (CW-156). PII tier: financial (FDIC Coverage "
               "Assessment only; every other object is 'No PII' under CW-115). Boundaries: client elections are 15 Cash Sweep "
               "Election (DP-093); account-level Sweep Allocation rows are published by DP-302 and the 49 Sweep Balance by "
               "DP-300; the allocation-to-balance reconciliation is DP-446's (CW-102); sweep runs, cash forecasts and the "
               "allocation analytics are DP-457's, which now reads FDIC Coverage Assessment through this product rather than "
               "directly; customer reserve funding and program bank exposure are DP-600's. Omnibus Deposit Account Number is "
               "not read (restricted account number). DP-446 must list DP-302 upstream for the Sweep Allocation side of the "
               "sweep reconciliation and this product for the Sweep Program and Program Bank keys. Register-row note: the row is Master & Reference; by assignment it also "
               "carries Program Bank Daily Total and FDIC Coverage Assessment as companion facts, so pii = Y on a master "
               "product. Tailoring lever: program banks. Reference default: several banks with "
               "priority order and client exclusions; one bank is the alternative (50 lever 2). Tailoring lever: sweep "
               "vehicle. Reference default: the firm's own money market fund by default with the bank deposit sweep by account "
               "type or election; bank only or fund only are the alternatives (50 lever 3). Tailoring lever: clearing model. "
               "Reference default: self-clearing; under fully disclosed clearing the clearing firm's program applies and the "
               "product becomes oversight of a received copy (50 lever 1, CW-235). Design note: utilization uses the "
               "participation's effective-dated Bank Capacity Amount for the business date. Taxonomy gap: 02 has no FDIC "
               "certificate number scheme and no bank charter attribute for a bank party, so the 50 Program Bank profile "
               "keeps them as Derived copies until the W5 proposal to 02 lands. Regulatory values: USD 250,000 standard "
               "maximum deposit insurance amount (12 CFR 330.1(o)); 30-day sweep change notice (SEC Rule 15c3-3(j)(2)(ii)); "
               "pass-through recordkeeping (12 CFR 330.5). Drafting assumptions: Contract Status 'active' as the 39 value "
               "for an in-force agreement; the USD 1 tolerances; interest-crediting days taken from Interest Paid by Bank. "
               "Decisions: CW-102, CW-107, CW-108, CW-115, CW-156, CW-234, CW-235. WP1 new (CW-234): new "
               "foundational master of the BWO brief; adds Program Bank Daily Total and FDIC Coverage Assessment (the latter "
               "read before only by backlog DP-458) by assignment and keeps the candidate's Sweep Rate Tier."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-302": dict(
        definition=("Every movement of cash into, out of and between client accounts of any account type (ACH, wire, check, "
                    "internal journal and debit card), with its rail detail, events, returns and exceptions, the non-special "
                    "money movement holds and fraud risk assessments applied to it, the money movement monitoring alerts it "
                    "raised and the daily Sweep Allocation of sweep balances to program banks, as 50 masters them; special-category "
                    "and AML holds are neither published nor inferable from it. It "
                    "publishes the CONCEPT_OWNERSHIP rows Money Movement (MMVMT-), Money Movement Hold (MMHLD-) and Money "
                    "Movement Monitoring Alert (MMALT-) (50, CW-107, CW-109, CW-110) once, so funding journeys, fraud holds, "
                    "AML monitoring, distributions and the 06 flow copy read the same payments. It is the payment record, "
                    "not a flow book: brokerage flows post in 49 (DP-300). It owns no certified metric family."),
        business_questions=[
            "How much cash settled into and out of client accounts today, by money movement type, payment rail and initiation channel?",
            "What are this month's ACH return and unauthorized return rates, and which exceptions are still open?",
            "Which money movements are on a funds availability, fraud, legal, sanctions or deceased-owner hold, for how much, and which holds are past expiry?",
            "How many fraud assessments allowed, stepped up, held or declined movements, and how many allowed movements were later confirmed as fraud?",
            "Which outgoing wires lack a complete Travel Rule record, and which movements used a bank instruction that is not verified?",
            "How are sweep balances allocated across program banks today?",
        ],
        grain=("Money movement (MMVMT-) with its rail detail groups, with Money Movement Event, Return, Exception, non-special "
               "Money Movement Hold, Fraud Risk Assessment and Money Movement Monitoring Alert as companion facts at their own "
               "grain, and Sweep Allocation (account x program bank x business date) as a daily companion snapshot; facts "
               "append-only"),
        dimensions=["Client account (DP-093)", "Initiating party (DP-240)", "Money movement type", "Payment rail", "Movement direction",
                    "Initiation channel", "Movement source type", "Money movement status", "Return reason code", "Exception type",
                    "Hold type and hold reason (published values only)", "Fraud decision and fraud model (DP-212)",
                    "Monitoring scenario (non-special values only)", "Program Bank and Sweep Program (DP-431)",
                    "Value date and business date (DP-013)"],
        measures=[
            ("Money Movement Count", "Count of Money Movement rows with Requested Date in the period, by Money Movement Type, Payment Rail, Movement Direction, Initiation Channel, Movement Source Type and published Money Movement Status (for a movement held under a suppressed hold, the status before the hold, DQ5).",
             _u("50", "Money Movement", "Money Movement ID", "Requested Date", "Money Movement Type", "Payment Rail", "Movement Direction", "Initiation Channel", "Movement Source Type", "Money Movement Status")),
            ("Settled Inflow Amount", "Sum of Movement Amount of movements with Money Movement Status = Settled, Movement Direction inbound, Payment Rail other than Internal Journal and Value Date in the period, within one Movement Currency; an operational payment amount, never Net New Assets (DP-008).",
             _u("50", "Money Movement", "Movement Amount", "Movement Currency", "Movement Direction", "Payment Rail", "Money Movement Status", "Value Date")),
            ("Settled Outflow Amount", "Sum of Movement Amount of movements with Money Movement Status = Settled, Movement Direction outbound, Payment Rail other than Internal Journal and Value Date in the period, within one Movement Currency.",
             _u("50", "Money Movement", "Movement Amount", "Movement Currency", "Movement Direction", "Payment Rail", "Money Movement Status", "Value Date")),
            ("Settled ACH Movements", "Count of movements with Payment Rail = ACH, Money Movement Status = Settled and Value Date in the period, by Movement Direction and Standard Entry Class Code; the denominator of the ACH return rates.",
             _u("50", "Money Movement", "Payment Rail", "Money Movement Status", "Value Date", "Movement Direction") + _u("50", "ACH Entry Detail", "Standard Entry Class Code")),
            ("Movements Settled After Value Date", "Count of settled movements whose Money Movement Event of Money Movement Event Type = Settled has an Event Timestamp date later than Value Date, by Payment Rail.",
             _u("50", "Money Movement Event", "Event Movement", "Money Movement Event Type", "Event Timestamp", "Resulting Movement Status") + _u("50", "Money Movement", "Value Date", "Payment Rail")),
            ("ACH Return Rate %", "Count of Money Movement Return rows with Return Received Date in the period on movements whose Payment Rail = ACH / Settled ACH Movements, by Return Reason Code and Standard Entry Class Code.",
             _u("50", "Money Movement Return", "Returned Movement", "Return Sequence", "Return Received Date", "Return Reason Code", "Return Type") + _u("50", "ACH Entry Detail", "Standard Entry Class Code", "ACH Trace Number") + ["Settled ACH Movements"]),
            ("Unauthorized Return Rate %", "ACH returns with Unauthorized Return Indicator = Y / Settled ACH Movements with Movement Direction = Inflow (debits the firm originated) and Standard Entry Class Code in (PPD, WEB, TEL), tested against the 0.5 percent unauthorized entry return rate threshold of the NACHA Operating Rules (section 2.17.2).",
             _u("50", "Money Movement Return", "Unauthorized Return Indicator") + _u("50", "ACH Entry Detail", "Standard Entry Class Code") + _u("50", "Money Movement", "Movement Direction") + ["Settled ACH Movements", "ACH Return Rate %"]),
            ("Open Money Movement Exceptions", "Count of Money Movement Exception rows with Exception Status not closed, by Exception Type and age in business days since Exception Raised Date.",
             _u("50", "Money Movement Exception", "Exception Movement", "Exception Sequence", "Exception Type", "Exception Raised Date", "Exception Status")),
            ("Active Money Movement Holds", "Count of Money Movement Hold rows with Hold Status in (Active, Extended) on the as-of date, by Hold Type and Hold Reason, over published rows only: Hold Type in (Funds Availability, Fraud, Legal Process, Sanctions, Deceased Owner) and Hold Reason neither special category nor AML Investigation (DQ5).",
             _u("50", "Money Movement Hold", "Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Reason", "Hold Status")),
            ("Held Amount", "Sum of Movement Amount of the movements named in Held Movement of Active Money Movement Holds, within one Movement Currency.",
             _u("50", "Money Movement", "Movement Amount", "Movement Currency") + ["Active Money Movement Holds"]),
            ("Holds Past Expiry", "Active Money Movement Holds whose Hold Expiry Date is before the as-of date and Hold Released Date is blank, by Hold Type, with age since Hold Placed Date.",
             _u("50", "Money Movement Hold", "Hold Expiry Date", "Hold Released Date", "Hold Placed Date") + ["Active Money Movement Holds"]),
            ("Fraud Decisions", "Count of Fraud Risk Assessment rows with Assessment Timestamp in the period, by Fraud Decision and Fraud Model, with the mean Fraud Risk Score; scores are produced by the 37 model named in Fraud Model (DP-212). Resulting Hold is published only where it names a published hold.",
             _u("50", "Fraud Risk Assessment", "Assessed Movement", "Assessment Timestamp", "Fraud Decision", "Fraud Model", "Fraud Risk Score", "Resulting Hold")),
            ("Fraud Missed Rate %", "Fraud Risk Assessment rows with Fraud Decision = Allow and Confirmed Fraud Indicator = Y / Fraud Decisions with Fraud Decision = Allow, by Fraud Model.",
             _u("50", "Fraud Risk Assessment", "Confirmed Fraud Indicator", "Fraud Decision") + ["Fraud Decisions"]),
            ("Open Monitoring Alerts", "Count of Money Movement Monitoring Alert rows with Alert Status open, by Monitoring Scenario (Elder Exploitation Pattern excluded, DQ5) and age since Alert Generated Timestamp; disposition published as escalated or closed only.",
             _u("50", "Money Movement Monitoring Alert", "Money Movement Monitoring Alert ID", "Monitoring Scenario", "Alert Status", "Alert Generated Timestamp", "Alert Disposition")),
            ("Outgoing Wires Without Complete Travel Rule Record", "Outbound movements with Payment Rail in (Fedwire Funds, International Wire) and Movement Amount of USD 3,000 or more (Movement Currency USD, or the USD equivalent at Exchange Rate Applied) whose Travel Rule Record Complete Indicator is not Y (31 CFR 1010.410(f)).",
             _u("50", "Wire Transfer Detail", "IMAD", "Travel Rule Record Complete Indicator", "Beneficiary Bank Identifier", "Exchange Rate Applied") + _u("50", "Money Movement", "Payment Rail", "Movement Direction", "Movement Amount", "Movement Currency")),
            ("Movements to Unverified Bank Instructions", "Count of ACH and wire movements requested in the period whose Bank Instruction Used resolves to a 15 Bank Instruction whose current Bank Verification Status is other than Verified, by Third-Party Indicator (15 keeps the current status only; the attempt history is the 50 Bank Account Verification Event, read by DP-456).",
             _u("50", "Money Movement", "Bank Instruction Used", "Third-Party Indicator", "Requested Date") + _u("15", "Bank Instruction", "Bank Instruction ID", "Bank Verification Status")),
            ("Sweep Allocated Balance", "Sum of Allocated Balance of Sweep Allocation rows of the Allocation Business Date, by Allocation Program Bank, with Interest Accrued Amount; the account total ties to the 49 Sweep Balance in DP-446, not here.",
             _u("50", "Sweep Allocation", "Allocation Account", "Allocation Program Bank", "Allocation Business Date", "Allocated Balance", "Interest Accrued Amount")),
            ("Debit Card Transaction Amount", "Count and sum of Movement Amount of movements with Payment Rail = Debit Card Network and Card Settlement Date in the period, by ATM Indicator and Foreign Transaction Indicator.",
             _u("50", "Card Transaction Detail", "Transaction Debit Card", "Card Settlement Date", "ATM Indicator", "Foreign Transaction Indicator") + _u("50", "Money Movement", "Movement Amount", "Payment Rail")),
            ("Checkwriting Drafts Without Redeeming Fund Order", "Count of movements with Money Movement Type = Checkwriting Draft and Money Movement Status = Settled whose Check Detail Redeeming Fund Order is blank.",
             _u("50", "Check Detail", "Check Number", "Redeeming Fund Order") + _u("50", "Money Movement", "Money Movement Type", "Money Movement Status")),
            ("Internal Journals Pending Approval", "Count of movements with Payment Rail = Internal Journal whose Journal Approval Status is Pending, by Same Owner Indicator and Retirement Tax Coding.",
             _u("50", "Internal Transfer Detail", "Destination Account", "Same Owner Indicator", "Retirement Tax Coding", "Journal Approval Status") + _u("50", "Money Movement", "Payment Rail")),
        ],
        inputs=[
            ("50", "Money Movement", ["Money Movement ID", "Movement Account", "Money Movement Type", "Payment Rail", "Movement Direction",
                                      "Movement Amount", "Movement Currency", "Requested Date", "Value Date", "Initiation Channel",
                                      "Initiating Party", "Movement Source Type", "Source Standing Instruction", "Bank Instruction Used",
                                      "Third-Party Indicator", "Money Movement Status"]),
            ("50", "Money Movement Event", ["Event Movement", "Event Sequence", "Money Movement Event Type", "Event Timestamp", "Resulting Movement Status"]),
            ("50", "ACH Entry Detail", ["Standard Entry Class Code", "Same Day ACH Indicator", "Effective Entry Date", "ACH Trace Number"]),
            ("50", "Wire Transfer Detail", ["Wire Message Type", "IMAD", "UETR", "Beneficiary Bank Identifier", "Beneficiary Bank Country",
                                            "Travel Rule Record Complete Indicator", "Callback Verification Timestamp", "Exchange Rate Applied"]),
            ("50", "Check Detail", ["Check Number", "Remote Deposit Capture Indicator", "Endorsement Verified Indicator", "Drawn-On Program Bank",
                                    "Redeeming Fund Order"]),
            ("50", "Internal Transfer Detail", ["Destination Account", "Same Owner Indicator", "Retirement Tax Coding", "Contribution Tax Year",
                                                "Journal Approval Status"]),
            ("50", "Card Transaction Detail", ["Transaction Debit Card", "Merchant Category Code", "Authorization Timestamp", "Card Settlement Date",
                                               "ATM Indicator", "Foreign Transaction Indicator"]),
            ("50", "Money Movement Return", ["Returned Movement", "Return Sequence", "Return Type", "Return Reason Code", "Return Received Date",
                                             "Unauthorized Return Indicator"]),
            ("50", "Money Movement Exception", ["Exception Movement", "Exception Sequence", "Exception Type", "Exception Raised Date", "Exception Status"]),
            ("50", "Money Movement Hold", ["Money Movement Hold ID", "Held Movement", "Hold Type", "Hold Reason", "Hold Status", "Hold Placed Date",
                                           "Hold Expiry Date", "Hold Released Date"]),
            ("50", "Fraud Risk Assessment", ["Assessed Movement", "Assessment Timestamp", "Fraud Model", "Fraud Risk Score", "Fraud Decision",
                                             "Resulting Hold", "Confirmed Fraud Indicator"]),
            ("50", "Money Movement Monitoring Alert", ["Money Movement Monitoring Alert ID", "Monitoring Scenario", "Movements in Scope", "Alert Accounts",
                                                       "Alert Generated Timestamp", "Alert Status", "Alert Disposition"]),
            ("50", "Sweep Allocation", ["Allocation Account", "Allocation Program Bank", "Allocation Business Date", "Allocated Balance",
                                        "Interest Accrued Amount", "Bank Exclusion Applied"]),
            ("15", "Bank Instruction", ["Bank Instruction ID", "Bank Instruction Account", "Third-Party Bank Indicator", "Bank Verification Status",
                                        "Bank Instruction Status"]),
            ("15", "Account Standing Instruction", ["Standing Instruction ID", "Instruction Type", "Instruction Account", "Instruction Status",
                                                    "Instruction Amount", "Next Run Date"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Open Date"]),
        ],
        upstream=["DP-093", "DP-240", "DP-431", "DP-580", "DP-212", "DP-192", "DP-013"],
        refresh="Intraday",
        timeliness="Movements, events, holds and fraud decisions stream as they occur; the end-of-day movement book, returns and exceptions of value date D by 7am ET on D+1; Sweep Allocation of business date D by 9am ET on D+1",
        history="Append-only movements, events, returns, exceptions, holds, assessments and alerts kept at least six years (SEC Rule 17a-4; Bank Secrecy Act recordkeeping 31 CFR 1010.430 five years); daily Sweep Allocation snapshots kept six years",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Movement Account, Destination Account, Allocation Account and Bank Instruction Account resolves to a DP-093 account; every Bank Instruction Used to a 15 Bank Instruction of the same account; every Initiating Party to a DP-240 party; every Allocation Program Bank to an active DP-431 program bank; every Redeeming Fund Order to a DP-580 Fund Order; every Fraud Model to a DP-212 model.",
            "Money Movement Event rows of one movement have strictly increasing Event Sequence and Event Timestamp, Hold Expiry Date is on or after Hold Placed Date on every hold, and there is one Sweep Allocation row per Allocation Account x Allocation Program Bank x Allocation Business Date.",
            "In the source record the Resulting Movement Status of each movement's latest event equals its Money Movement Status, and every movement with Money Movement Status = Settled has exactly one event of Money Movement Event Type = Settled; the published view keeps this tie after the DQ5 suppression.",
            "Movement Account, Money Movement Type, Payment Rail, Movement Direction, Movement Amount, Value Date and Money Movement Status are populated on every movement; ACH Trace Number on every ACH movement; IMAD on every Fedwire movement; Return Reason Code on every return; Fraud Decision on every assessment.",
            "At ingestion, no Money Movement Hold row with Hold Type in (FINRA Rule 2165 Disbursement Hold, FINRA Rule 2166 Temporary Delay, AML) or Hold Reason in (Suspected Financial Exploitation, Diminished Capacity Concern, Undue Influence, Scam Victim - Specified Adult, AML Investigation), and no Money Movement Monitoring Alert with Monitoring Scenario Elder Exploitation Pattern, is loaded; for a movement held only under such a hold, Money Movement Status On Hold is published as the status before the hold, Money Movement Event rows of type Held and Released are omitted, and Fraud Risk Assessment.Resulting Hold is blank; bank account, card and check numbers and wire beneficiary account data are not published or are masked; Alert Disposition is published only as escalated or closed, and alert rows are visible to AML and money movement roles only.",
            "Movements of value date D are published by 7am ET on D+1 and a value date is locked once the 49 posting of D is complete; corrections enter as new events, returns or reversing movements, never as edits.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Money Movement (50, MMVMT-; CW-107), Money Movement Hold (MMHLD-; "
               "CW-109) and Money Movement Monitoring Alert (MMALT-; CW-110), with Sweep Allocation (50, CW-102); source of "
               "the Money Movement facts of the WP2 conformed set. Instructions are 15's (CW-033) and are read through "
               "DP-093; programs and banks are DP-431's (CW-234). Certified numbers: none; settled amounts are operational "
               "payment amounts and Net New Assets is DP-008's. One flow book per account type: this product is the payment "
               "record, not a flow book; DP-006 takes brokerage flows from 49 Client Account Activity (DP-300, which holds "
               "Source Money Movement), fund-only flows from 29 (DP-580) and participant flows from 16 (DP-430), and reads "
               "this product only for payment attributes, so nothing is counted twice and nothing is recomputed here. PII "
               "tier: financial (restricted columns masked). Special category and AML (lead ruling 2, F3 fix pass): the row "
               "filter of DQ5 runs at ingestion, and Hold Type, Hold Reason and Monitoring Scenario are read only to apply it. "
               "Special-category and AML holds must not be inferable, so for a movement held only under a suppressed hold the "
               "published Money Movement Status is the status before the hold, the Held and Released events are omitted and "
               "Fraud Risk Assessment.Resulting Hold is blank. The hold facts belong elsewhere: the special-category holds to "
               "DP-322 (special category, CD-344) and to the restricted views DP-456 and DP-403, which alone read those 50 "
               "Money Movement Hold rows (only the 02 facts reach DP-456 through DP-322); the AML holds and alerts to the 38 "
               "AML product DP-226 and to DP-460 (31 CFR 1023.320(e)). Sanctions holds stay published. The special-category "
               "hold detail (Hold Reason Narrative, Source Vulnerability Concern, Senior Investor Case, Trusted Contact "
               "Notified, Paired Account Restriction) is not read. This foundational product cannot list the consumer DP-322 "
               "upstream, so it carries no Protection Flag Present indicator. Boundaries: Rule 2165 and "
               "fraud hold analytics are DP-456 (acceptance question 7), which also reads Bank Account Verification Event; "
               "payment sanctions screening and the AML alert workflow are DP-460, AML cases and SARs DP-226 (38); debit "
               "cards, card disputes and Regulation E are DP-459; sweep runs and cash forecasts DP-457; the 49 posting of each "
               "movement and the Sweep Balance are DP-300's, and the allocation-to-balance reconciliation is DP-446's. The 50 "
               "Sweep Allocation.Reconciled Sweep Balance (a 49 reference) is not read, so that DP-300 can stay downstream "
               "of this product; DP-446 must therefore list DP-302 upstream for the allocation side of the sweep "
               "reconciliation. Source Fee Debit (47) and the other source references are not read, because DP-305 lists "
               "DP-300 upstream and an edge to it would close a cycle; Movement Source Type carries the source class. Fraud "
               "Risk Score is produced by the 37 model in Fraud Model (DP-212, CD-294). Plan distributions run on the "
               "recordkeeper's rail (16), not here. Acceptance question 7: feeds DP-456 with Active Money Movement Holds, Held "
               "Amount, Holds Past Expiry and Fraud Decisions for the published holds, and the Money Movement keys its "
               "restricted view joins on (50). Acceptance question 2: feeds DP-006 and DP-008 with the payment attributes of "
               "Settled Inflow Amount and Settled Outflow Amount (50). Tailoring lever: clearing model. Reference default: "
               "self-clearing (50 lever 1, CW-235). Tailoring lever: instant payments. Reference default: RTP and FedNow not "
               "offered; adding them adds rail values and a detail group (50 lever 4). Tailoring lever: funds availability "
               "holds. Reference default: firm-policy holds aligned to Regulation CC; no holds on verified bank accounts is the "
               "alternative (50 lever 5). Tailoring lever: checkwriting and debit card. Reference default: checkwriting on the "
               "firm's own money market funds and one program-bank debit card; either may be dropped (50 lever 7). Tailoring "
               "lever: payment hub. Reference default: plan distributions on the recordkeeper's rail; one hub moves them here "
               "(50 lever 8). Taxonomy gap: Money Movement Hold has no held amount; the held amount is the Movement Amount of "
               "the Held Movement, so a partial hold cannot be shown. Design note: the link to the 49 posting is held by the "
               "later record (49 Source Money Movement), so the posting check runs from DP-300. Regulatory values: the 0.5 "
               "percent unauthorized entry return rate threshold (NACHA Operating Rules section 2.17.2); the USD 3,000 Travel "
               "Rule threshold (31 CFR 1010.410(f)). Drafting assumptions: Inflow and Outflow as the Movement Direction values "
               "(the 50 Flow Direction list); 'not closed' exception and alert status values; Pending as the Journal Approval "
               "Status awaiting approval; the pre-hold status taken from the event before the Held event. Decisions: CW-033, CW-102, CW-107, CW-108, CW-109, CW-110, CW-115, "
               "CW-141, CW-205, CW-213, CW-231, CW-234, CD-294, CD-344. WP1 new (CW-205): new foundational product of the WP0 "
               "framing; by assignment adds Money Movement Hold (non-special rows), Fraud Risk Assessment, Money Movement "
               "Monitoring Alert, Sweep Allocation and Card Transaction Detail to the candidate's objects (the candidate had "
               "left holds to DP-456 and cards to DP-459); keeps 15 Bank Instruction and Account Standing Instruction."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-300": dict(
        definition=("The brokerage book of record at account grain: every Client Holding of any security with its "
                    "valuation, client tax lots, lot reliefs, cost basis adjustments and transfer statements, account cash "
                    "balances by balance type and balance basis (including the Sweep Balance), every pending and posted "
                    "Client Account Activity, account transfers, margin balance snapshots, client corporate action "
                    "entitlements and fully paid securities loans, as 49 masters them. It publishes the CONCEPT_OWNERSHIP "
                    "rows Client Holding (CLHLD-), Client Tax Lot (CTLOT-) and Client Account Activity (CLACT-) (49, "
                    "CW-007, CW-101) once, so client assets, advice, managed accounts, billing, statements, trust accounting "
                    "and personal returns read the same holdings. It is Client Holding, never a Portfolio Holding of 18 or a "
                    "Fund Shareholder Position of 06. It owns no certified metric family: Client Assets are DP-008's and the "
                    "Rule 15c3-3 reserve computation is DP-445's."),
        business_questions=[
            "What is the end-of-day market value of every client account's Client Holdings, and how much of it is held in the firm's own share classes?",
            "Which Client Holdings do not tie to their open Client Tax Lots, and which open lots have no usable cost basis?",
            "What gains and losses were realized this year by holding period term and Form 1099-B category, and how much wash-sale loss was disallowed?",
            "Which pending activities are outstanding, and which posted activities lack the source record they should reference?",
            "What free credit, sweep and margin debit balances does each account carry today, and which margin accounts are in maintenance deficit?",
            "Which corporate action entitlements are overdue, which account transfers are open, and which cost basis transfer statements are late?",
        ],
        grain=("Client account (15) x instrument (17) x holding date x Client Holding View (CLHLD-), with its valuation, as "
               "the main output; client tax lots, lot reliefs, cost basis adjustments, transfer statements, client account "
               "activity, account cash balances (account x currency x balance type x balance basis x business date), account "
               "transfers, margin balance snapshots, client corporate action entitlements and fully paid securities loans "
               "as companion facts at their own grain; daily End of Day snapshots, append-only postings"),
        dimensions=["Client account (DP-093)", "Instrument (DP-097)", "Client Holding View", "Holding date and business date (DP-013)",
                    "Own Share Class Indicator", "Lot acquisition method and covered security class", "Holding period term",
                    "Form 1099-B reporting category", "Activity type and activity status", "Cash balance type and balance basis",
                    "Sweep Program (DP-431)", "Transfer direction and channel", "Corporate action event (DP-099)",
                    "Borrowing entity (DP-013)", "Contra firm (DP-240)"],
        measures=[
            ("Client Holdings Market Value", "Sum of Market Value in USD of Client Holding Valuation for Client Holding rows with Client Holding View = End of Day and Client Holding Date = the as-of date, by Holding Account and Held Instrument; the book value DP-007 and DP-008 copy, never the certified Client Assets.",
             _u("49", "Client Holding", "Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View") + _u("49", "Client Holding Valuation", "Market Value in USD")),
            ("Open Client Holdings", "Count of End of Day Client Holding rows on the as-of date with Trade-Date Quantity, Settled Quantity or Short Quantity not zero, by the Instrument Type and Asset Class of Held Instrument.",
             _u("49", "Client Holding", "Trade-Date Quantity", "Settled Quantity", "Short Quantity", "Client Holding View", "Client Holding Date") + _u("17", "Instrument", "Instrument Type", "Asset Class")),
            ("Own-Fund Client Holdings Market Value", "Client Holdings Market Value of rows with Own Share Class Indicator = Y; the input of the 06 Fund Shareholder Position view for brokerage accounts and of the own-fund overlap that DP-008 reports and DP-241 nets.",
             _u("49", "Client Holding", "Own Share Class Indicator") + ["Client Holdings Market Value"]),
            ("Holdings Valued at Unapproved Price %", "Open Client Holdings whose Valuation Price Record is blank, or names a 22 Approved Price with Price Approval Status other than Approved or Price Date before Valuation Date / Open Client Holdings.",
             _u("49", "Client Holding Valuation", "Valuation Price Record", "Valuation Date") + _u("22", "Approved Price", "Approved Price ID", "Price Approval Status", "Price Date") + ["Open Client Holdings"]),
            ("Client Holding to Client Tax Lot Quantity Breaks", "Count of Open Client Holdings whose Trade-Date Quantity differs from the sum of Remaining Quantity of Client Tax Lot rows with Client Tax Lot Status = Open and the same Lot Account and Lot Instrument, by more than 0.0001 shares.",
             _u("49", "Client Tax Lot", "Lot Account", "Lot Instrument", "Remaining Quantity", "Client Tax Lot Status") + _u("49", "Client Holding", "Trade-Date Quantity") + ["Open Client Holdings"]),
            ("Open Lots Without Usable Cost Basis", "Count of open Client Tax Lots with Covered Security Indicator = Y and Adjusted Cost Basis blank, plus open lots with Covered Security Class = Noncovered and Noncovered Basis Source = Unknown, by Lot Acquisition Method.",
             _u("49", "Client Tax Lot", "Client Tax Lot ID", "Covered Security Indicator", "Covered Security Class", "Adjusted Cost Basis", "Noncovered Basis Source", "Lot Acquisition Method", "Client Tax Lot Status")),
            ("Realized Gain or Loss", "Sum of Realized Gain or Loss of Client Lot Relief rows whose closing date (the Trade Date of the Closing Activity, or the 29 Register Trade Date of the Closing Register Transaction read from DP-580) is in the tax year, by Holding Period Term and Form 1099-B Reporting Category, with Relieved Cost Basis and Relief Proceeds.",
             _u("49", "Client Lot Relief", "Relieved Client Tax Lot", "Closing Activity", "Closing Register Transaction", "Realized Gain or Loss", "Holding Period Term", "Form 1099-B Reporting Category", "Relieved Cost Basis", "Relief Proceeds") + _u("49", "Client Account Activity", "Trade Date") + _u("29", "Register Transaction", "Register Transaction ID", "Register Trade Date")),
            ("Wash Sale Loss Disallowed", "Sum of Wash Sale Loss Disallowed of Client Lot Relief rows closed in the tax year, with the deferred amount carried as Wash Sale Deferred Loss on the replacement lots.",
             _u("49", "Client Lot Relief", "Wash Sale Loss Disallowed") + _u("49", "Client Tax Lot", "Wash Sale Deferred Loss") + ["Realized Gain or Loss"]),
            ("Relief Method Differs From Election", "Count of Client Lot Relief rows with Relief Method Source = Account Default Election (15) whose Relief Method Applied differs from the Cost Basis Method of the 15 Cost Basis Election of the lot's account effective on the closing date.",
             _u("49", "Client Lot Relief", "Relief Method Source", "Relief Method Applied") + _u("15", "Cost Basis Election", "Election Account", "Cost Basis Method", "Cost Basis Election Scope", "Election Effective From", "Election Effective To") + ["Realized Gain or Loss"]),
            ("Pending Activity Net Amount", "Sum of Activity Net Amount of Client Account Activity rows with Activity Status = Pending on the as-of date, by Activity Type and Settlement Date, within one Activity Currency.",
             _u("49", "Client Account Activity", "Client Account Activity ID", "Activity Account", "Activity Type", "Activity Status", "Activity Net Amount", "Activity Currency", "Settlement Date")),
            ("Posted Activity Net Amount", "Count of Client Account Activity rows and sum of Activity Net Amount with Activity Status = Posted and Trade Date in the period, by Activity Type, within one Activity Currency; the brokerage flow source DP-006 copies and DP-145 reads, never Net New Assets (DP-008).",
             _u("49", "Client Account Activity", "Activity Status", "Activity Net Amount", "Activity Currency", "Activity Type", "Trade Date")),
            ("Activities Without Source Record", "Count of posted Client Account Activity rows of Activity Type Buy, Sell, Sell Short or Buy to Cover with Source Client Allocation blank; Money Movement In or Out with Source Money Movement blank; Fee Debit with Source Fee Debit blank; Dividend, Capital Gain Distribution or Corporate Action with Source Entitlement blank (Interest is excluded, because credit interest on cash and sweep balances has no entitlement); Account Transfer In or Out with Source Account Transfer blank; Fund Purchase or Fund Redemption with Source Fund Order blank.",
             _u("49", "Client Account Activity", "Activity Type", "Activity Status", "Source Client Allocation", "Source Money Movement", "Source Fee Debit", "Source Entitlement", "Source Account Transfer", "Source Fund Order")),
            ("Free Credit Balances", "Sum of Cash Balance Amount of Account Cash Balance rows with Cash Balance Type = Free Credit Balance, Balance Basis = Settlement Date and Cash Balance Business Date = the as-of date, within one Cash Balance Currency; the input DP-445 reads for the reserve computation, never computed into a reserve here.",
             _u("49", "Account Cash Balance", "Cash Balance Account", "Cash Balance Type", "Balance Basis", "Cash Balance Business Date", "Cash Balance Amount", "Cash Balance Currency")),
            ("Sweep Balances", "Sum of Cash Balance Amount of rows with Cash Balance Type = Sweep Balance and Balance Basis = Settlement Date on the as-of date, by Balance Sweep Program; their tie to the 50 Sweep Allocations is DP-446's (CW-102).",
             _u("49", "Account Cash Balance", "Cash Balance Type", "Balance Basis", "Cash Balance Amount", "Balance Sweep Program", "Cash Balance Business Date")),
            ("Margin Debit Balances", "Sum of Margin Debit Balance of Margin Balance Snapshot rows with Margin Snapshot Type = End of Day and Margin Snapshot Business Date = the as-of date, with Account Equity, Maintenance Requirement and Margin Interest Accrued.",
             _u("49", "Margin Balance Snapshot", "Margin Snapshot Account", "Margin Snapshot Type", "Margin Snapshot Business Date", "Margin Debit Balance", "Account Equity", "Maintenance Requirement", "Margin Interest Accrued")),
            ("Accounts in Maintenance Deficit", "Count of accounts whose End of Day Margin Balance Snapshot on the as-of date has Maintenance Excess or Deficit below zero, with the sum of the deficit; calls are DP-600's.",
             _u("49", "Margin Balance Snapshot", "Maintenance Excess or Deficit", "Margin Snapshot Account") + ["Margin Debit Balances"]),
            ("On-Loan Quantity Breaks", "Count of account x instrument pairs where the sum of Loan Quantity of Fully Paid Securities Loan rows with Loan Status in (Open, Recalled) differs from On-Loan Quantity of the End of Day Client Holding of the Lending Account and Loaned Instrument.",
             _u("49", "Fully Paid Securities Loan", "Fully Paid Securities Loan ID", "Lending Account", "Loaned Instrument", "Loan Quantity", "Loan Status") + _u("49", "Client Holding", "On-Loan Quantity")),
            ("Overdue Corporate Action Entitlements", "Count and sum of Entitled Cash Amount of Client Corporate Action Entitlement rows with Entitlement Status in (Projected, Confirmed) and Entitlement Payment Date before the as-of date, or Entitlement Status = Paid and Payment Activity blank.",
             _u("49", "Client Corporate Action Entitlement", "Client Corporate Action Entitlement ID", "Entitlement Event", "Entitled Account", "Entitlement Status", "Entitlement Payment Date", "Payment Activity", "Entitled Cash Amount")),
            ("Account Transfers by Status", "Count of Account Transfer rows with Transfer Status in (Requested, Validated, Settlement Pending) on the as-of date, with age since Validation Date, and count of rows with Transfer Status = Settled and Transfer Settlement Date in the period, by Transfer Direction and Transfer Channel; the brokerage transfer source DP-006 copies, never Net New Assets.",
             _u("49", "Account Transfer", "Account Transfer ID", "Transfer Account", "Transfer Status", "Transfer Direction", "Transfer Channel", "Validation Date", "Transfer Settlement Date")),
            ("Late Cost Basis Transfer Statements", "Count of Cost Basis Transfer Statement rows with Transfer Statement Direction = Sent whose Statement Sent or Received Date is after Statement Due Date, or is blank with Statement Due Date before the as-of date (IRC section 6045A).",
             _u("49", "Cost Basis Transfer Statement", "Statement Account Transfer", "Transfer Statement Direction", "Statement Due Date", "Statement Sent or Received Date")),
        ],
        inputs=[
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date", "Client Holding View",
                                      "Client Holding As-Of Timestamp", "Trade-Date Quantity", "Settled Quantity", "Short Quantity",
                                      "Segregated Quantity", "Margin Pledged Quantity", "On-Loan Quantity", "Restricted Quantity",
                                      "Fractional Quantity", "Own Share Class Indicator", "Principal Control Location"]),
            ("49", "Client Holding Valuation", ["Valuation Date", "Valuation Price Record", "Valuation Currency", "Market Value", "Market Value in USD",
                                                "Accrued Interest", "Total Cost Basis", "Unrealized Gain or Loss",
                                                "Unrealized Short-Term Gain or Loss", "Unrealized Long-Term Gain or Loss"]),
            ("49", "Client Tax Lot", ["Client Tax Lot ID", "Lot Account", "Lot Instrument", "Acquisition Date", "Holding Period Start Date",
                                      "Lot Acquisition Method", "Acquisition Activity", "Acquisition Register Transaction", "Original Quantity",
                                      "Remaining Quantity", "Original Cost", "Adjusted Cost Basis", "Covered Security Indicator",
                                      "Covered Security Class", "Noncovered Basis Source", "Wash Sale Deferred Loss", "Client Tax Lot Status"]),
            ("49", "Client Lot Relief", ["Relieved Client Tax Lot", "Closing Activity", "Closing Register Transaction", "Relief Method Applied",
                                         "Relief Method Source", "Relieved Quantity", "Relieved Cost Basis", "Relief Proceeds",
                                         "Realized Gain or Loss", "Holding Period Term", "Wash Sale Loss Disallowed",
                                         "Form 1099-B Reporting Category"]),
            ("49", "Cost Basis Adjustment", ["Adjusted Client Tax Lot", "Adjustment Sequence", "Basis Adjustment Type", "Basis Adjustment Amount",
                                             "Quantity Adjustment", "Adjustment Effective Date", "Source Corporate Action Event",
                                             "Adjustment Approval Status"]),
            ("49", "Cost Basis Transfer Statement", ["Statement Account Transfer", "Transfer Statement Direction", "Statement Version", "Statement Counterparty Firm",
                                                     "Statement Due Date", "Statement Sent or Received Date",
                                                     "Noncovered Security Notice Indicator"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Type", "Activity Instrument", "Trade Date",
                                               "Settlement Date", "Entry Date", "Activity Quantity", "Activity Price", "Activity Net Amount",
                                               "Activity Currency", "Activity Status", "Source Client Allocation", "Source Money Movement",
                                               "Source Fee Debit", "Source Entitlement", "Source Account Transfer", "Source Fund Order",
                                               "Reversed Activity"]),
            ("49", "Account Cash Balance", ["Cash Balance Account", "Cash Balance Currency", "Cash Balance Type", "Cash Balance Business Date",
                                            "Balance Basis", "Cash Balance Amount", "Cash Balance As-Of Timestamp", "Balance Sweep Program"]),
            ("49", "Account Transfer", ["Account Transfer ID", "Transfer Account", "Transfer Direction", "Transfer Channel", "Contra Firm",
                                        "ACATS Control Number", "Validation Date", "Transfer Settlement Date", "Transfer Status"]),
            ("49", "Margin Balance Snapshot", ["Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Snapshot Type", "Margin Snapshot As-Of Timestamp",
                                               "Margin Debit Balance", "Account Equity", "Reg T Excess", "Maintenance Requirement",
                                               "Maintenance Excess or Deficit", "Buying Power", "Margin Interest Accrued"]),
            ("49", "Client Corporate Action Entitlement", ["Client Corporate Action Entitlement ID", "Entitlement Event", "Entitled Account",
                                                           "Record Date Client Holding Quantity", "Entitled Cash Amount",
                                                           "Entitled Securities Quantity", "Entitlement Withholding Amount",
                                                           "Entitlement Payment Date", "Payment Activity", "Entitlement Status"]),
            ("49", "Fully Paid Securities Loan", ["Fully Paid Securities Loan ID", "Lending Account", "Lending Agreement", "Borrowing Entity",
                                                  "Loaned Instrument", "Loan Quantity", "Loan Start Date", "Collateral Amount",
                                                  "Collateral Mark Date", "Client Loan Fee Rate", "Loan Return Date", "Loan Status"]),
            ("29", "Register Transaction", ["Register Transaction ID", "Register Trade Date"]),
            ("22", "Approved Price", ["Approved Price ID", "Priced Instrument", "Price Date", "Approved Price Value", "Approved Price Currency",
                                      "Price Approval Status"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status", "Carrying Entity", "Account Business Line"]),
            ("15", "Cost Basis Election", ["Cost Basis Method", "Election Account", "Cost Basis Election Scope", "Election Effective From",
                                           "Election Effective To"]),
            ("17", "Instrument", ["Instrument ID", "Instrument Type", "Asset Class", "Own Share Class", "Instrument Status"]),
        ],
        upstream=["DP-093", "DP-301", "DP-302", "DP-580", "DP-431", "DP-097", "DP-099", "DP-143", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="End of Day holdings, valuation, lots, activity and settlement-date cash balances of business date D by 6am ET on D+1, before the daily reserve computation; the Intraday holding view and intraday margin snapshot refresh every 15 minutes in market hours",
        history="Daily End of Day snapshots of holdings, valuation, cash balances and margin kept six years; lots, reliefs, adjustments, transfer statements and activity append-only for the life of the account plus six years (SEC Rules 17a-3(a)(3) and 17a-4(b); IRC sections 6045 and 6045A basis records); SCD type 2 on cost basis elections",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "File extract"],
        dq_rules=[
            "Every Holding Account, Lot Account, Activity Account, Cash Balance Account, Transfer Account, Margin Snapshot Account, Entitled Account and Lending Account resolves to a DP-093 account; every Held Instrument, Lot Instrument, Activity Instrument and Loaned Instrument to DP-097; every Entitlement Event and Source Corporate Action Event to DP-099; every Source Client Allocation to DP-301, Source Money Movement to DP-302, Source Fund Order, Acquisition Register Transaction and Closing Register Transaction to DP-580, and Balance Sweep Program to DP-431.",
            "There is one Client Holding per Holding Account x Held Instrument x Client Holding Date x Client Holding View and one Account Cash Balance per account x currency x Cash Balance Type x Balance Basis x business date; exactly one of Acquisition Activity or Acquisition Register Transaction is filled on every lot and one of Closing Activity or Closing Register Transaction on every relief; Cost Basis Election periods of one Election Account and Cost Basis Election Scope do not overlap.",
            "For every End of Day Client Holding, Trade-Date Quantity equals the sum of Remaining Quantity of the Client Tax Lots with Client Tax Lot Status Open for the same Lot Account and Lot Instrument within 0.0001 shares, and on End of Day snapshots Margin Debit Balance equals the settlement-date Account Cash Balance of Cash Balance Type Margin Debit Balance for the same account and date (49 row rule).",
            "Market Value, Trade-Date Quantity and Settled Quantity are populated on every End of Day Client Holding; Acquisition Date, Remaining Quantity, Adjusted Cost Basis (covered lots) and Covered Security Indicator on every open lot; Activity Type, Trade Date, Settlement Date, Activity Net Amount and Activity Status on every activity; Cash Balance Amount on every cash balance.",
            "Published views carry accounts as the DP-093 key only and join no party name, TIN or date of birth; Contra Firm Account Number is not read or published; row-level access is limited to brokerage operations, tax, advice, billing and trust roles, and every other reader receives aggregates by account type, instrument type or holding type.",
            "The End of Day view of business date D is published by 6am ET on D+1 and locked; later changes post as new Client Account Activity with Activity Status Reversed and a replacement row, never as edits to a locked date.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Client Holding (CLHLD-), Client Tax Lot (CTLOT-), Client Account Activity "
               "(CLACT-), Account Transfer (ACXF-), Fully Paid Securities Loan (CSLN-) and Client Corporate Action Entitlement "
               "(CLCAE-), with Client Lot Relief, Cost Basis Adjustment, Cost Basis Transfer Statement, Account Cash Balance and "
               "Margin Balance Snapshot (49, CW-007, CW-101, CW-104, CW-105, CW-106, CW-176); source of the client holdings, "
               "lots, cost basis and brokerage activity facts of the WP2 conformed set. Book: Client Holding (49), the "
               "brokerage book of record; never a Portfolio Holding (18) or a Fund Shareholder Position (06). It is also the "
               "flow book of brokerage and managed (15 accounts managed in 46) accounts: DP-006 and DP-007 copy Client Account "
               "Activity, Account Transfer and Client Holding Valuation with declared sources and nothing is recomputed here "
               "(CW-141). Certified numbers: none owned. Client Holdings Market Value is the book value that DP-007 and DP-008 "
               "copy; Client Assets, Net New Assets and the own-fund overlap are DP-008's, Firm AUM and the netting DP-241's, "
               "and Personal Rate of Return DP-145's. Operating model (CD-297, CD-331): self-clearing (reference default); the "
               "grain is the operational book of record. Under fully disclosed clearing the clearing firm carries the "
               "accounts and the product becomes a received copy of Client Holdings, Client Tax Lots and activity with its reconciliation (49 "
               "lever 1, CW-235). PII tier: financial. Boundaries: the Rule 15c3-3 reserve computation, possession or control "
               "and control locations are DP-445's; this product publishes only their inputs (Free Credit Balances, Margin "
               "Debit Balances, Segregated Quantity) and never reads Reserve Computation (CW-103). Margin calls are DP-600's "
               "(from backlog DP-450). Stock record reconciliation, the 49-to-29 omnibus proof and the sweep-to-allocation tie "
               "are DP-446's. Street settlement and fails are DP-447's. ACATS work queues and asset lines are DP-448's. "
               "Elections and DRIP are DP-452's. Form 1099-B readiness has no WP1 owner: DP-417 and DP-449 are in the backlog, "
               "so the hand-off is held for the backlog and this product publishes the lot, relief and 1099-B category facts "
               "it would read. Billing is DP-305 and "
               "DP-346, and DP-305 lists this product upstream, so the 47 Source Fee Debit is carried as a key and DP-305 is "
               "not listed (the edge would close a cycle). Lot selection by managed accounts is DP-342's. 15 holds the cost "
               "basis method election, never lots. Fund-only account lots are 49 Client Tax Lots opened and relieved by 29 "
               "Register Transactions read from DP-580 (CW-034, CW-122). 49 postings reference 48 allocations and 50 "
               "movements (the later record holds the link), so DP-301 and DP-302 are upstream. Design note: a Fully Paid "
               "Securities Loan is matched to the daily Client Holding by Lending Account and Loaned Instrument, because a "
               "daily snapshot row is not a reference target. Acceptance question 1: feeds "
               "DP-007, DP-008, DP-241 and DP-496 with Client Holdings Market Value and Own-Fund Client Holdings Market Value "
               "(49). Acceptance question 2: feeds DP-006 with Posted Activity Net Amount and Account Transfers by "
               "Status as the brokerage flow source (49). Acceptance question 4: feeds DP-341 and DP-342 with Client Holding Valuation, Realized Gain "
               "or Loss and Wash Sale Loss Disallowed (49). Acceptance question 6: feeds DP-445 with Free Credit Balances, "
               "Margin Debit Balances and the Segregated Quantity of Client Holding (49). Acceptance question 8: feeds DP-346 "
               "with Client Holdings Market Value as the billable value (49). Acceptance question 9: feeds DP-145 with "
               "Client Holdings Market Value and Posted Activity Net Amount (49). Tailoring lever: clearing model. Reference "
               "default: self-clearing (49 lever 1). Tailoring lever: margin. Reference default: offered to approved "
               "non-retirement accounts; dropping it removes Margin Balance Snapshot (49 lever 6). Tailoring lever: fully paid "
               "lending. Reference default: offered with the firm as principal borrower; a Vanguard-type firm may not offer "
               "it, and Fully Paid Securities Loan drops; an agency program makes Borrowing Entity a 02 party (49 lever 7; "
               "backlog DP-451 stands alone). Tailoring lever: default lot relief. Reference default: FIFO for securities and "
               "average cost for funds, from 15; tax-optimized is the alternative (49 lever 5). Tailoring lever: cash balance "
               "basis. Reference default: both trade-date and settlement-date balances, settlement date the book of record "
               "(49 lever 10). Tailoring lever: fund-only account lots. Reference default: 49 Client Tax Lots; the TA platform "
               "may keep them (49 lever 12). Taxonomy gap: Client Tax Lot has no as-of snapshot, so lot state on a past date is rebuilt from Acquisition Date and Client Lot "
               "Relief. Drafting assumptions: Activity Status 'Posted' as the posted state; the 0.0001-share lot tolerance; "
               "the 15-minute intraday refresh; the Form 1099-B tax year as the realized-gain period. Decisions: CW-007, "
               "CW-034, CW-101, CW-102, CW-103, CW-104, CW-105, CW-106, CW-115, CW-122, CW-141, CW-176, CW-205, CW-235. WP1 "
               "new (CW-205): new foundational product of the WP0 framing; adds Account Transfer, Client Corporate Action "
               "Entitlement and Fully Paid Securities Loan by assignment (the candidate left them to the BWO consumers), and "
               "reads 22 Approved Price and 29 Register Transaction keys for the valuation and relief tests. F3 fix pass: "
               "adds Posted Activity Net Amount and Account Transfers by Status (replacing Open Account Transfers) for the Q2 "
               "and Q9 feeds; drops Cost Basis Adjustments Pending Approval (the adjustment facts stay published)."),
    ),

    # ------------------------------------------------------------------------------------------------------------------
    "DP-430": dict(
        definition=("The participant book of record of the plans the firm recordkeeps: the daily Participant Balance by "
                    "membership, money source and plan investment option with units, unit value, market value and vested "
                    "amount, every Participant Ledger Posting and Participant Investment Transfer, the link from each "
                    "membership to its 15 participant account, and the Participant Retail Hand-Off that starts rollover "
                    "capture. It publishes the CONCEPT_OWNERSHIP rows Participant Balance, Participant Ledger Posting "
                    "(PLPST-), Participant Investment Transfer (PEXC-) and Participant Retail Hand-Off (PRTHO-) (16, CW-125, "
                    "CW-126) once. It is the recordkeeping (participant) book of record (CW-125), distinct from the three "
                    "books of record of CW-007, and the only source of plan balances for 06, 32, 46 and the workplace "
                    "products. It owns no certified metric family."),
        business_questions=[
            "What is the market value and vested amount of participant balances today, by plan, investment option and money source?",
            "Which balances do not roll forward through the day's ledger postings, and which carry a unit value different from the fund's NAV?",
            "Which postings lack their source record or the plan fund order that should have traded them?",
            "Which investment transfers are pending or were rejected for excessive trading?",
            "Which separated participants with a balance have no retail hand-off, and which hand-offs have been open for more than 90 days?",
        ],
        grain=("Participant plan membership x money source x plan investment option x valuation date for Participant Balance "
               "(daily snapshot), with Participant Ledger Posting, Participant Investment Transfer and Participant Retail "
               "Hand-Off as companion facts at their own grain; append-only postings"),
        dimensions=["Participant plan membership and participant (DP-094, DP-240)", "Retirement plan (DP-094)", "Participant account (DP-093)",
                    "Plan investment option and share class (DP-004)", "Money source (contribution source)", "Posting type",
                    "Investment transfer source and status", "Hand-off trigger and outcome", "Referred advisor (DP-009)",
                    "Valuation date and trade date (DP-013)"],
        measures=[
            ("Participant Balance Market Value", "Sum of Balance Market Value of Participant Balance rows of the Valuation Date, by the Membership Plan of Balance Membership, Balance Investment Option and Balance Contribution Source; the book value DP-007 and DP-008 copy for the workplace channel, never the certified Client Assets.",
             _u("16", "Participant Balance", "Balance Membership", "Balance Investment Option", "Balance Contribution Source", "Valuation Date", "Balance Market Value") + _u("16", "Participant Plan Membership", "Membership ID", "Membership Plan")),
            ("Participant Vested Amount", "Sum of Vested Amount of Participant Balance rows of the Valuation Date, by plan and money source.",
             _u("16", "Participant Balance", "Vested Amount", "Valuation Date", "Balance Contribution Source")),
            ("Participants With Balance", "Count of distinct Balance Membership with Balance Market Value greater than zero on the Valuation Date, by plan and Membership Status.",
             _u("16", "Participant Balance", "Balance Membership", "Balance Market Value") + _u("16", "Participant Plan Membership", "Membership Status")),
            ("Unit Value Differs From NAV", "Count of Participant Balance rows whose Unit Value Applied differs by more than 0.0001 from the NAV per Share (DP-165) of the Share Class NAV of the Offered Share Class of the Balance Investment Option whose Parent NAV Calculation has Valuation Date = the balance Valuation Date, NAV Version Type official and NAV Status final.",
             _u("16", "Participant Balance", "Unit Value Applied", "Balance Investment Option", "Valuation Date") + _u("16", "Plan Investment Option", "Investment Option ID", "Offered Share Class") + _u("27", "Share Class NAV", "NAV Share Class", "NAV per Share", "Parent NAV Calculation") + _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Version Type", "NAV Status")),
            ("Balance Value Arithmetic Breaks", "Count of Participant Balance rows where the absolute difference between Unit Balance x Unit Value Applied and Balance Market Value exceeds USD 0.01.",
             _u("16", "Participant Balance", "Unit Balance", "Unit Value Applied", "Balance Market Value")),
            ("Balance Roll-Forward Breaks", "Count of membership x money source x option sets where Unit Balance on day D minus Unit Balance on the prior valuation date differs from the sum of Posted Units of Participant Ledger Postings with the same Posting Membership, Posting Contribution Source and Posting Investment Option and Posting Trade Date = D, by more than 0.0001 units.",
             _u("16", "Participant Balance", "Unit Balance", "Valuation Date") + _u("16", "Participant Ledger Posting", "Posting Membership", "Posting Contribution Source", "Posting Investment Option", "Posted Units", "Posting Trade Date")),
            ("Ledger Posted Amount", "Count of Participant Ledger Posting rows and sum of Posted Amount with Posting Trade Date in the period, by Posting Type and plan; the participant flow source DP-006 copies, never Net New Assets.",
             _u("16", "Participant Ledger Posting", "Ledger Posting ID", "Posting Type", "Posted Amount", "Posting Trade Date", "Posting Unit Value")),
            ("Postings Without Source Record", "Count of Participant Ledger Posting rows with Posting Type in (Contribution, Rollover In, Loan Disbursement, Loan Repayment, Distribution, Forfeiture, Fund Change Mapping, Exchange In, Exchange Out, Correction) and Posting Source Record blank.",
             _u("16", "Participant Ledger Posting", "Posting Type", "Posting Source Record") + ["Ledger Posted Amount"]),
            ("Postings Without Plan Fund Order", "Count of postings with Posting Type in (Contribution, Distribution, Exchange In, Exchange Out) on an option whose Offered Share Class has a 29 Share Register Balance whose Register Keeper is the firm's transfer agent (read from DP-580), and whose Resulting Plan Fund Order is blank one business day after Posting Trade Date.",
             _u("16", "Participant Ledger Posting", "Resulting Plan Fund Order", "Posting Investment Option") + _u("16", "Plan Investment Option", "Offered Share Class") + _u("29", "Share Register Balance", "Register Share Class", "Register Keeper") + ["Ledger Posted Amount"]),
            ("Pending Investment Transfers", "Count and sum of Requested Transfer Amount of Participant Investment Transfer rows with Transfer Status in (Received, Pending Trade Date) more than one business day after Transfer Request Timestamp, by Transfer Source.",
             _u("16", "Participant Investment Transfer", "Investment Transfer ID", "Transfer Membership", "Transfer Status", "Transfer Request Timestamp", "Requested Transfer Amount", "Transfer Source")),
            ("Transfers Rejected for Excessive Trading", "Count of Participant Investment Transfer rows with Transfer Status = Rejected - Excessive Trading Restriction in the period, by Transfer From Option and Transfer To Option.",
             _u("16", "Participant Investment Transfer", "Transfer Status", "Transfer From Option", "Transfer To Option")),
            ("Memberships Without Participant Account", "Count of Participant Plan Membership rows whose Participant Account is blank or does not resolve to an open DP-093 account.",
             _u("16", "Participant Plan Membership", "Participant Account") + _u("15", "Account", "Account ID", "Account Status")),
            ("Separated Participants Without Hand-Off", "Count of memberships with Membership Status in (Terminated with Balance, Retired with Balance), counted in Participants With Balance, that have no Participant Retail Hand-Off with Hand-Off Membership = the membership.",
             _u("16", "Participant Plan Membership", "Membership Status") + _u("16", "Participant Retail Hand-Off", "Hand-Off Membership") + ["Participants With Balance"]),
            ("Hand-Offs Open Past 90 Days", "Count of Participant Retail Hand-Off rows with Hand-Off Outcome = Open and Trigger Date more than 90 days before the as-of date, by Hand-Off Trigger.",
             _u("16", "Participant Retail Hand-Off", "Hand-Off ID", "Hand-Off Outcome", "Trigger Date", "Hand-Off Trigger")),
            ("Referrals Without Contact Consent", "Count of hand-offs with Referral Advice Engagement or Referred Advisor populated and Contact Consent blank.",
             _u("16", "Participant Retail Hand-Off", "Referral Advice Engagement", "Referred Advisor", "Contact Consent")),
            ("Hand-Off Rollover Amount", "Sum of Hand-Off Rollover Amount of hand-offs with Outcome Date in the period, by Hand-Off Outcome; an operational amount, never the certified Net Inter-Channel Transfers or rollover capture rate (DP-008).",
             _u("16", "Participant Retail Hand-Off", "Hand-Off Rollover Amount", "Outcome Date", "Hand-Off Outcome", "Linked Distribution Request")),
        ],
        inputs=[
            ("16", "Participant Balance", ["Balance Membership", "Balance Contribution Source", "Balance Investment Option", "Valuation Date", "Unit Balance",
                                           "Unit Value Applied", "Balance Market Value", "Vested Amount"]),
            ("16", "Participant Ledger Posting", ["Ledger Posting ID", "Posting Membership", "Posting Type", "Posting Contribution Source",
                                                  "Posting Investment Option", "Posted Units", "Posting Unit Value", "Posted Amount",
                                                  "Posting Trade Date", "Posting Source Record", "Resulting Plan Fund Order"]),
            ("16", "Participant Investment Transfer", ["Investment Transfer ID", "Transfer Membership", "Transfer Source", "Transfer From Option",
                                                       "Transfer To Option", "Requested Transfer Amount", "Transfer Request Timestamp",
                                                       "Transfer Status"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant", "Membership Plan", "Participant Account", "Membership Status",
                                                   "Plan Entry Date"]),
            ("16", "Plan Investment Option", ["Investment Option ID", "Menu Plan", "Offered Share Class", "Menu Role", "Option Status"]),
            ("16", "Participant Retail Hand-Off", ["Hand-Off ID", "Hand-Off Membership", "Hand-Off Trigger", "Trigger Date", "Contact Consent",
                                                   "Referral Advice Engagement", "Referred Advisor", "Hand-Off Outcome", "Outcome Date",
                                                   "Linked Distribution Request", "Hand-Off Rollover Amount"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "NAV per Share", "Parent NAV Calculation"]),
            ("27", "Fund NAV Calculation", ["Valuation Date", "NAV Version Type", "NAV Status"]),
            ("29", "Share Register Balance", ["Register Share Class", "Register Keeper"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
        ],
        upstream=["DP-094", "DP-093", "DP-165", "DP-004", "DP-580", "DP-303", "DP-009", "DP-240", "DP-013"],
        refresh="Daily",
        timeliness="Balances valued at the Valuation Date NAV and the postings of trade date D by 6am ET on D+1, after the recordkeeping nightly cycle; hand-offs by 7am ET on the day after the trigger event",
        history="Daily balance snapshots and every ledger posting, investment transfer and hand-off kept for the life of the plan plus six years (ERISA section 107 record retention); postings append-only with corrections as Correction or Reversal postings",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract"],
        dq_rules=[
            "Every Balance Membership, Posting Membership, Transfer Membership and Hand-Off Membership resolves to a DP-094 Participant Plan Membership; every Participant Account to a DP-093 account; every Balance Investment Option and Posting Investment Option to a Plan Investment Option of the same Membership Plan whose Offered Share Class resolves to DP-004; every Referred Advisor to DP-009 and every Resulting Plan Fund Order to a DP-580 Fund Order.",
            "There is one Participant Balance per Balance Membership x Balance Contribution Source x Balance Investment Option x Valuation Date, and Outcome Date is on or after Trigger Date on every hand-off.",
            "For every membership x money source x option and valuation date D, Unit Balance on D equals Unit Balance on the prior valuation date plus the Posted Units of the postings with Posting Trade Date D within 0.0001 units, and on every Participant Balance row Unit Balance x Unit Value Applied equals Balance Market Value within USD 0.01.",
            "Unit Balance, Unit Value Applied and Balance Market Value are populated on every balance; Posting Type, Posted Units, Posted Amount and Posting Trade Date on every posting; Transfer Status on every transfer; Hand-Off Trigger, Trigger Date and Hand-Off Outcome on every hand-off.",
            "Participants are published as the 02 party and membership keys only, with no name, SSN or date of birth; the Highly Compensated Employee Indicator (personal data) is not read, and hardship reasons (special category, CD-344) are not read; row-level data is visible to recordkeeping, participant services and workplace roles, and plan sponsors and analytics receive plan-level aggregates.",
            "Balances and postings of trade date D are published by 6am ET on D+1 and a valuation date is locked once the plan's daily cycle closes; corrections post as Correction or Reversal postings, never as edits.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Participant Balance, Participant Ledger Posting (PLPST-), Participant "
               "Investment Transfer (PEXC-) and Participant Retail Hand-Off (PRTHO-) (16, CW-125, CW-126); source of the "
               "participant balance facts of the WP2 conformed set. Book: Participant Balance (16), the recordkeeping book of "
               "record under the W1 ruling (CW-125), not one of the three books of CW-007 (Portfolio Holding 18, Client "
               "Holding 49, Fund Shareholder Position 06) and never mixed with them; CW-232's text ('third book of record') "
               "is amended the same way at integration (module NOTES); brokerage windows and IRAs are 49 (DP-300). It is "
               "the flow book of participant accounts: DP-006 and DP-007 copy Participant Ledger Posting and Participant "
               "Balance with declared sources, and nothing is recomputed here (CW-141). The membership, plan and menu masters "
               "are DP-094's; this product reads the membership only for its Participant Account link (the 15 Plan "
               "Participant Account) and its status. Certified numbers: none owned. Unit values are tested against DP-165 NAV "
               "per Share; rollover capture and Net Inter-Channel Transfers are DP-008's, and Personal Rate of Return is "
               "DP-145's. Operating model (CD-297): in-house recordkeeping (reference default); outsourced functions become "
               "received records with the grain unchanged (16 lever 7.7.1). PII tier: financial (identity only through the 02 "
               "participant key). The candidate proposed Restricted - Personal Data; financial data of clients takes "
               "Confidential - Personal Data under the WP1 rule, because no special-category attribute is read (Distribution "
               "Request with Hardship Reason is not an input). Boundaries: the funnel, capture rate and outreach are DP-467's; "
               "participant outcomes and the managed account program DP-466's; distributions, RMDs and QDROs DP-094 and "
               "DP-329; plan omnibus shares at the TA are DP-580's. Acceptance question 1: feeds DP-007 and DP-008 with "
               "Participant Balance Market Value (16). Acceptance question 10: feeds DP-467 with Separated Participants "
               "Without Hand-Off, Hand-Offs Open Past 90 Days and Hand-Off Rollover Amount, and the hand-off record keyed to "
               "the membership and participant account (16, 15). Tailoring lever: balances on the brokerage platform. "
               "Reference default: 16 keeps them; a platform merge moves balances to 49 and this product keeps only the ledger "
               "(16 lever 7.7.2). Tailoring lever: rollover outreach. Reference default: a hand-off for every separation with "
               "a vested balance, outreach after consent to contact (16 lever 7.7.4). Tailoring lever: auto-rollover IRA "
               "custodian. Reference default: the firm (Hand-Off Outcome Rolled to Firm IRA) (16 lever 7.7.7). Tailoring "
               "lever: product split. Reference default: a product separate from DP-094 (CW-232). Taxonomy gap: 16 has no link "
               "from a plan or Plan Investment Option to the 29 Plan Omnibus register account, so participant units cannot "
               "be proved to the DP-580 register by key. Taxonomy gap: Participant Balance has no as-of timestamp or valuation "
               "version, so a re-valued day overwrites rather than versions. Drafting assumptions: the 0.0001 unit and NAV "
               "tolerances; the USD 0.01 arithmetic tolerance; the 90-day open hand-off window; the posting types that require "
               "a source record or plan fund order; 'official' and 'final' as the NAV Version Type and NAV Status of the NAV "
               "used. Decisions: CW-007, CW-125, CW-126, CW-141, CW-230, CW-232, CD-297. WP1 new "
               "(CW-232): new foundational product of the BWO brief; adds Participant Retail Hand-Off and the 15 participant "
               "account link by assignment and keeps the candidate's Participant Plan Membership and Plan Investment Option. "
               "F3 fix pass: the NAV test reads the 27 Fund NAV Calculation valuation date and version; the transfer-agent "
               "test reads the 29 Register Keeper (DP-580)."),
    ),
}


# Hand-offs and register notes for the consumer agents and the lead (F3 fix pass, 2026-10-15, lead rulings 1 to 5).
NOTES = [
    "DP-436 (BWO): owns the execution-quality analytics (48 Execution Quality Measure read directly, price improvement, "
    "effective spread, the Rule 605 ratios, Rule 606 and the venue comparison); reads the Venue and Routing Rule dimensions "
    "and the Rule 605 Report Line facts 'from DP-432' (Rule 605 Covered Orders, Rule 605 Price-Improved Shares) and never "
    "re-defines them. Taxonomy gap for DP-436: Execution Quality Measure carries no Routing Rule reference.",
    "DP-435 (BWO): owns the CAT completeness and market-access counts (orders without a CAT New Order event, rejected or "
    "late CAT records, repairs past deadline, pre-trade limits past their SEC Rule 15c3-5(e) annual review); reads the CAT "
    "Reportable Event and Pre-Trade Risk Limit facts 'from DP-301'.",
    "DP-177 and DP-178 (live, re-spec): DP-177 owns cut-off control, forward-pricing tests and fund-order processing "
    "exceptions, DP-178 the settlement obligations past due and intermediary settlement; both should read the 29 fund "
    "order, omnibus order detail and settlement obligation facts 'from DP-580'. DP-582 (omnibus aggregation evidence) is in "
    "the backlog with no merge target.",
    "DP-007 (F5): reads DP-580 Fund-Only Registered Shares for directly registered client accounts and treats Look-Through "
    "Category Registered Shares as other books (49, 16, DTC participants, 06 intermediary look-through), selecting the "
    "counted rows by the 06 Aggregation Role; Firm Proprietary rows are never client assets.",
    "DP-446 (BWO): must list DP-302 upstream for the Sweep Allocation side of the sweep reconciliation, with DP-300 and DP-431.",
    "DP-456, DP-403, DP-322 and DP-460: special-category and AML Money Movement Hold rows and Elder Exploitation Pattern "
    "alerts are not in DP-302; the restricted views read them from 50 directly; AML holds belong to the 38 AML product "
    "(DP-226) and DP-460.",
    "Lead, integration: CW-232's text calling Participant Balances & Ledger 'the third book of record' is amended to 'the "
    "recordkeeping (participant) book of record (CW-125), distinct from the three books of record of CW-007'.",
]
