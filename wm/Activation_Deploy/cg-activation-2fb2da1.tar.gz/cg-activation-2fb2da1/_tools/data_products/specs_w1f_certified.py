"""Wave WP1F (foundational), group F5 'certified client assets & revenue': attribute-level specifications of the
wealth-manager rework (Wealth_Manager_Rework_Plan.md sections 8.2, 8.5 and 10; 00_Program/Rework/Product_Briefs/WP1_Method.md
section 3).

Products, in dependency order (re-scoped or extended in place; ids kept):
- DP-006 Client Flow Transactions (06 Client Assets, Flows & Channel Attribution)
- DP-007 Client Asset Positions (06 Client Assets, Flows & Channel Attribution)
- DP-008 Client Assets & Net New Assets (06 Client Assets, Flows & Channel Attribution)
- DP-165 NAV & Fund Financials (27 Fund Accounting & Valuation; gives Firm AUM to DP-241)
- DP-012 Client Fee Revenue (10 Client Revenue, Pricing Economics & Profitability)
- DP-145 Official Returns (32 Performance & Attribution; extended with Personal Rate of Return)
- DP-241 Firm AUM & Client Assets Reconciliation (27 Fund Accounting & Valuation; consumer-aligned, specified here by the
  lead's ruling because it certifies Firm AUM)

WP1 decisions applied: each certified number is defined in one product and carries the measure name fixed by
semantic_model/register.CERTIFIED_WEALTH (CW-011, CW-209): the Client Assets family and the funded account, client and
household counts in DP-008, published as 06 Measure Values; Firm AUM and its three slices in DP-241; Personal Return
Value in DP-145; Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate in DP-012. Client Assets are net equity
(06 ruling 4). One flow book per account type (06 ruling 2): DP-006 copies 49 Client Account Activity, 29 Register
Transaction, 16 Participant Ledger Posting and 18 Portfolio Capital Activity and masters only intermediary-feed rows.
The three books of record stay distinct (CW-007): client holdings are 49 (DP-300), never 18 or 06; Fund Shareholder
Position (06) is a view. Client Assets and Firm AUM are reconciled, never summed, and the own-fund overlap is netted in
DP-241 only. DP-305 publishes billed amounts and never recognized revenue; DP-012 recognizes. See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    """(NN, object, attribute) use tuples for one object."""
    return [(nn, obj, a) for a in attrs]


def _mv(*attrs):
    return _u("06", "Measure Value", *attrs)


# Rules stated once and referenced by name (fix pass of the F5 review, rulings 2 and 4).
_CASH_RULE = ("Client cash rule (DP-007): Cash Balance Amount of 49 Account Cash Balance rows with Balance Basis Settlement "
              "Date and Cash Balance Type Free Credit Balance, Sweep Balance or Short Sale Proceeds (never the computed Cash "
              "Available to Invest or Cash Available to Withdraw rows, Uncollected Deposits or the Margin Debit Balance row), "
              "less the Margin Debit Balance of the one Margin Balance Snapshot of Margin Snapshot Type End of Day with the "
              "latest Margin Snapshot As-Of Timestamp for the account and business date; margin debit is subtracted only there")
_UNIT_RULE = ("Unit coverage rule (DP-007): the register units that must have a counted Fund Shareholder Position are the "
              "Registered Shares of 29 Share Register Balance rows whose Register Account Category is Fund-Only, "
              "Institutional Direct or Networked (and CIT Unitholder rows of firm client accounts), compared with the Units "
              "Held of the Fund Shareholder Positions copied from those rows (Position Source Book Transfer Agent Register "
              "(29), same Register Account Category). Units in the Broker-Dealer Omnibus, Intermediary Omnibus, Plan Omnibus "
              "and DTC Nominee categories are never counted as unloaded: they are already inside Client Assets and the "
              "Own-Fund Overlap through the 49 rows, the look-through rows and omnibus residual, the 16 participant "
              "summaries of recordkept plans and the 18 summaries of nominee-held IA mandates; Firm Proprietary units are "
              "seed capital (DP-204)")
_MARGIN = ("Margin Snapshot Account", "Margin Snapshot Business Date", "Margin Snapshot Type", "Margin Snapshot As-Of Timestamp",
           "Margin Debit Balance")
_CASH = ("Cash Balance Account", "Cash Balance Type", "Cash Balance Business Date", "Balance Basis", "Cash Balance Amount")


NOTES = (
    "Lineage notes of the F5 fix pass (for the lineage agent and the semantic register; the product notes carry the same "
    "lines per product). "
    "1) DP-008: the wholesale Asset Measures names Ending AUM, Beginning AUM, Average AUM, Market Movement and Organic "
    "Growth Rate are replaced by the certified measures Ending Client Assets, Beginning Client Assets, Average Client "
    "Assets, Client Market Movement and Other and Client Organic Growth Rate. CERTIFIED (register.py) and the SM-01 "
    "metrics must re-point to these DP-008 measure names as a stopgap until SM-20; the 06 Asset Measures attribute names "
    "stay as DP-008 inputs, so sm_model will not flag the rename on its own. Also re-point: SM-01 flows_aum facts "
    "beginning_aum, ending_aum, average_aum and market_movement; SM-01 'Distributor Firm' rows and dimensions of flows_aum, "
    "attributed_transactions and attributed_positions (06 Distributor Hierarchy is no longer read by DP-006, DP-007 or "
    "DP-008); spec readers DP-242 'Flows and Attributed AUM (from DP-008)' (and SM-06 through it), DP-243 'Attributed AUM "
    "and Net Flows (from DP-008)', DP-245 'Flow & Attributed AUM Values (from DP-008)', DP-105 'Realized vs Projected AUM "
    "%' and DP-108 'Affected Attributed AUM' (which also reads 06 Distributor Hierarchy). Kept: Gross Sales, Redemptions, "
    "Net Flows, Restatement Impact; Net Exchanges is now a measure. "
    "2) DP-007: 'Attributed AUM (Reporting Currency)' becomes 'Attributed Position Value' (SM-01 attributed_positions "
    "column attributed_aum), 'Unattributed AUM' becomes 'Unattributed Position Amount' and 'Advisory Program AUM' becomes "
    "'Advised Account Summary Market Value' (SM-01 metrics). "
    "3) DP-006: measure names kept; the dimension 'Distributor firm / office / team / advisor' becomes 'Intermediary firm "
    "/ office (DP-001)' and 'Credited salesperson' is dropped; 06 Distributor Hierarchy readers to re-point: SM-01 "
    "attributed_transactions 'Distributor Firm', and the conformers in models_c1_sales, models_c2_marketing_product and "
    "models_c10_shareholder_ops. "
    "4) DP-165: drops 'Firm AUM' and 'Mandate & SMA Market Value' (SM-11 metrics, CERTIFIED 'Firm AUM' (SM-11, DP-165)); "
    "readers to re-point to DP-241: DP-245 'Fund Metric Values (from DP-165)', DP-204 (definition, business question, DQ "
    "rule and notes). Re-cut models_e8_book_of_record (drop the 18, 17 and 22 entities). "
    "5) DP-241: 'Firm AUM (from DP-165)', 'Fund Net Assets Slice (from DP-165)', 'Mandate & SMA Slice (from DP-165)' and "
    "'Attributed AUM (from DP-008)' become Firm AUM, Firm AUM Own Funds Slice, Firm AUM Institutional Slice and Ending "
    "Client Assets (from DP-008); SM-11 aum_bridge facts fund_net_assets_slice, mandate_sma_slice, firm_aum and "
    "attributed_aum re-point accordingly; the dropped causes and memos are listed in the DP-241 notes; re-cut "
    "models_e8c_cross_area. "
    "6) DP-012: 'Effective Net Fee Rate' keeps its name on the client fee basis; the fund-basis rate is the new 'Fund "
    "Effective Net Fee Rate' (SM-07 to choose). "
    "7) Every new measure must be published or excluded by its owning semantic model: SM-01 (DP-006, DP-007, DP-008), "
    "SM-07 (DP-012), SM-08 (DP-145), SM-11 (DP-165, DP-241)."
    " 8) Lineage addition for C-4 (2026-10-15): DP-012 publishes 'Client Fee Revenue', the client fee slice of Gross Fee "
    "Revenue (47 client fee streams on 10 Client Revenue Record, excluding own-fund management fees), read by DP-598; SM-07 "
    "excludes it until SM-28."
    " 9) WP2 retirement sweep (CW-209): SM-01, SM-06 and SM-07, named above, are retired and their definition files "
    "deleted; SM-20 and SM-28 own the flow, asset and fee revenue families and publish or exclude every measure."
)

SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-006": dict(
        definition=("The conformed client flow record: every external flow into or out of a firm client account and every "
                    "own-fund purchase, redemption, exchange or reinvestment, one 06 Transaction (glossary Flow Transaction, "
                    "TXN-) per source record and cancel/correct version. Internal rows are Derived copies of the one flow "
                    "book of their account (49 Client Account Activity for brokerage, managed and trust accounts, with 50 "
                    "money movements only through their 49 posting; 29 Register Transaction for direct registered accounts; "
                    "16 Participant Ledger Posting for participant accounts; 18 Portfolio Capital Activity for institutional "
                    "mandates); intermediary-feed rows are mastered here as delivered, and inter-channel transfer rows are "
                    "generated from Account Channel Assignment. It publishes the CONCEPT_OWNERSHIP row Transaction (06, "
                    "TXN-) with flow scope, holding type, the account's channel on the trade date and the attribution to "
                    "advisor of record, household, campaign, plan, institutional client and intermediary, with unattributed "
                    "amounts in suspense. It is the transaction input of DP-008 and owns no certified metric family."),
        business_questions=[
            "Which client flows were loaded yesterday from each flow book and intermediary feed, and do their totals tie to the source books?",
            "How much flowed into and out of client accounts by flow scope, holding type and channel, before DP-008 applies the flow treatment rules?",
            "Which inter-channel transfers (advice enrollments, journals between channels, rollovers from firm plans into firm IRAs) were generated, and does every pair net to zero?",
            "How much flow is attributed to an advisor of record, a household and a campaign, and how much sits unattributed in suspense, at which level and why?",
            "Which flows were canceled or corrected after their period closed, and which source records were loaded twice?",
        ],
        grain=("Flow transaction (06 Transaction, TXN-: flow source book x source transaction reference x cancel/correct "
               "version), with attribution records (transaction x dimension combination x effective date, one split basis "
               "per record) and unattributed items as companion facts; append-only versions, prior attributions kept"),
        dimensions=["Trade date / as-of date (DP-013)", "Transaction type and flow direction", "Flow scope", "Holding type",
                    "Flow source book", "Client account (DP-093)", "Client household (DP-240)",
                    "Product and share class (DP-004)", "Distribution channel", "Business line",
                    "Covering advisor (DP-009)", "Campaign (DP-011)", "Retirement plan (DP-094)",
                    "Institutional client / consultant (DP-003)", "Intermediary firm / office (DP-001)",
                    "Order entry channel", "Source feed", "Attribution method and confidence band"],
        measures=[
            ("Flow Transactions Loaded",
             "Count of current Transaction versions (the highest version per Flow Source Book and Source Transaction Reference, Transaction Status not Canceled, Reversed or Rejected: the current-row rule DP-008 applies too) by Flow Source Book, Source Feed, Transaction Type and Trade Date.",
             _u("06", "Transaction", "Transaction ID", "Source Transaction Reference", "Source Feed", "Transaction Type")
             + _u("06", "Order Source", "Flow Source Book") + _u("06", "Transaction Status", "Transaction Status")
             + _u("06", "Transaction Dates", "Trade Date")),
            ("Client Asset Flow Amount (Pre-Treatment)",
             "Sum of Reporting Currency Amount, signed by Flow Direction (Inflow positive, Outflow negative), of current rows with Flow Scope Client Asset Flow or Client Asset and Fund Flow, by Transaction Type, Holding Type and channel. It is the input to which DP-008 applies the Flow Treatment Rule; it is never Net New Assets.",
             _u("06", "Transaction Amounts", "Reporting Currency Amount")
             + _u("06", "Transaction", "Flow Direction", "Flow Scope", "Transaction Type", "Holding Type")
             + _u("06", "Transaction Status", "Transaction Status")),
            ("Own-Fund Flow Amount (Pre-Treatment)",
             "Sum of Reporting Currency Amount, signed by Flow Direction, of current rows with Flow Scope Fund Flow or Client Asset and Fund Flow and a Share Class, by Transaction Type (Purchase, Redemption, Exchange In, Exchange Out, Reinvestment, ETF Creation, ETF Redemption, Share Class Conversion), Share Class and Order Entry Channel; DP-008 derives Gross Sales, Redemptions and Net Flows from it.",
             _u("06", "Transaction Amounts", "Reporting Currency Amount")
             + _u("06", "Transaction", "Flow Scope", "Share Class", "Transaction Type", "Flow Direction")
             + _u("06", "Order Source", "Order Entry Channel")),
            ("Inter-Channel Transfer Amount",
             "Sum of Gross Amount of rows with Flow Scope Inter-Channel Transfer, signed by Flow Direction, by From Distribution Channel and To Distribution Channel. Rows generated from an Account Channel Assignment change (Flow Source Book Account Channel Assignment (06): advice enrollments and terminations) name their Source Channel Assignment and carry as Gross Amount the sum of Summary Market Value of the account's Account Asset Summary rows (from DP-007) on the last day of the old assignment (Channel Effective To); journals and firm-plan rollovers carry the amount of their contra leg. The firm-wide total is zero.",
             _u("06", "Transaction", "Flow Scope", "Flow Direction") + _u("06", "Transaction Amounts", "Gross Amount")
             + _u("06", "Linked Transaction", "From Distribution Channel", "To Distribution Channel")
             + _u("06", "Order Source", "Source Channel Assignment", "Flow Source Book")
             + _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Market Value")
             + _u("06", "Account Channel Assignment", "Channel Effective To")),
            ("Inter-Channel Transfer Pairing Breaks",
             "Count of Inter-Channel Transfer rows without a Linked Transaction ID of the opposite Flow Direction and equal Gross Amount on the same Trade Date, plus rows whose From Distribution Channel differs from the Assigned Distribution Channel of the account's Account Channel Assignment whose Channel Effective To is the day before the Trade Date.",
             _u("06", "Linked Transaction", "Linked Transaction ID", "From Distribution Channel")
             + _u("06", "Transaction", "Flow Scope", "Flow Direction", "Account") + _u("06", "Transaction Amounts", "Gross Amount")
             + _u("06", "Transaction Dates", "Trade Date")
             + _u("06", "Account Channel Assignment", "Assigned Account", "Assigned Distribution Channel", "Channel Effective To")),
            ("Flows Without Source Record",
             "Count of current rows whose Flow Source Book is Brokerage Book of Record (49), Transfer Agent Register (29), Workplace Recordkeeping (16) or Institutional Portfolio Book (18) and whose source reference for that book (Source Client Account Activity, Source Register Transaction, Source Participant Ledger Posting or Source Portfolio Capital Activity) is blank or does not resolve to a row of the book (Client Account Activity ID, Register Transaction ID, Ledger Posting ID, or Activity Portfolio x Activity Trade Date x Capital Activity Type).",
             _u("06", "Order Source", "Flow Source Book", "Source Client Account Activity", "Source Register Transaction",
                "Source Participant Ledger Posting", "Source Portfolio Capital Activity")
             + _u("49", "Client Account Activity", "Client Account Activity ID")
             + _u("29", "Register Transaction", "Register Transaction ID")
             + _u("16", "Participant Ledger Posting", "Ledger Posting ID")
             + _u("18", "Portfolio Capital Activity", "Activity Portfolio", "Activity Trade Date", "Capital Activity Type")),
            ("Source Book Reconciliation Variance",
             "Per flow book and business date: sum of Gross Amount of current rows minus the source total of the same flows: Activity Net Amount of 49 Client Account Activity rows of the flow Activity Types with Activity Status Posted; Gross Amount of 29 Register Transactions of direct registered accounts with Register Transaction Status Posted; Posted Amount of 16 Participant Ledger Postings of the flow Posting Types; Activity Amount Base of 18 Portfolio Capital Activity of the client contribution and withdrawal types.",
             _u("06", "Transaction Amounts", "Gross Amount") + _u("06", "Order Source", "Flow Source Book")
             + _u("06", "Transaction Dates", "Trade Date")
             + _u("49", "Client Account Activity", "Activity Type", "Trade Date", "Activity Net Amount", "Activity Status")
             + _u("29", "Register Transaction", "Register Transaction Type", "Register Trade Date", "Gross Amount", "Register Transaction Status")
             + _u("16", "Participant Ledger Posting", "Posting Type", "Posting Trade Date", "Posted Amount")
             + _u("18", "Portfolio Capital Activity", "Activity Amount Base")),
            ("Duplicate Source Records",
             "Count of Flow Source Book and Source Transaction Reference pairs with more than one current row that is not a cancel/correct version of the other (Original Transaction ID blank on both).",
             _u("06", "Order Source", "Flow Source Book") + _u("06", "Transaction", "Source Transaction Reference")
             + _u("06", "Transaction Status", "Original Transaction ID")),
            ("Same-Owner Movement Flag",
             "Y when a Linked Transaction has Same-Owner Indicator = Y: an exchange, transfer or conversion with no change of owner, which governs the firm-wide figure only (journals between channels stay inter-channel transfers).",
             _u("06", "Linked Transaction", "Same-Owner Indicator", "Linked Transaction ID")),
            ("Late Correction Flag",
             "Y when Cancel / Correct Indicator is Cancel, Correct or Reversal and As-Of Date falls in a reporting period whose Final Close Date has passed.",
             _u("06", "Transaction Status", "Cancel / Correct Indicator", "Original Transaction ID")
             + _u("06", "Reporting Period", "Final Close Date") + _u("06", "Transaction Dates", "As-Of Date")),
            ("Attributed Amount (Reporting Currency)",
             "Reporting Currency Amount x Attribution Share % for each attribution record whose Source Transaction is the row, signed by Flow Direction; the records of one split basis sum to the source amount.",
             _u("06", "Transaction Amounts", "Reporting Currency Amount")
             + _u("06", "Attribution Record", "Attribution Share %", "Attributed Amount", "Source Transaction")
             + _u("06", "Transaction", "Flow Direction")),
            ("Attribution Rate %",
             "Sum of Attributed Amount of records with a Covering Advisor (firm client accounts) or a Resolved Distributor Firm (intermediary rows) / sum of Reporting Currency Amount of the same transactions and period.",
             _u("06", "Attribution Record", "Attributed Amount") + _u("06", "Market & Client Dimensions", "Covering Advisor")
             + _u("06", "Intermediary As Delivered", "Resolved Distributor Firm")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount")),
            ("Unattributed Amount",
             "Sum of Unattributed Amount by Lowest Resolved Level, Unattributed Reason and Suspense Channel; attributed plus unattributed equals the source total.",
             _u("06", "Unattributed Item", "Lowest Resolved Level", "Unattributed Reason", "Unattributed Amount", "Suspense Channel")),
            ("Flows Without Channel Assignment",
             "Count and Reporting Currency Amount of current rows whose Account has no Account Channel Assignment with Channel Effective From on or before the Trade Date and Channel Effective To blank or on or after it.",
             _u("06", "Transaction", "Account") + _u("06", "Transaction Dates", "Trade Date")
             + _u("06", "Account Channel Assignment", "Assigned Account", "Channel Effective From", "Channel Effective To")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount")),
            ("Advisor and Campaign Attributed Flow Amount",
             "Sum of Attributed Amount of attribution records with Source Record Type Transaction, by Covering Advisor (with its Advisor Coverage Assignment) and Client Household on salesperson-free records, and by Attributed Campaign on campaign-basis records (Campaign Attribution Weight applied); pre-treatment keys that DP-008 and the DIS products read.",
             _u("06", "Attribution Record", "Attributed Amount", "Source Record Type")
             + _u("06", "Market & Client Dimensions", "Covering Advisor", "Advisor Coverage Assignment", "Client Household",
                  "Attributed Campaign", "Campaign Attribution Weight")),
            ("Intermediary Rows Resolved %",
             "Intermediary-feed rows (Flow Source Book Intermediary Feed) whose Dealer / Firm Number resolves through an Identifier Crosswalk effective on the Trade Date to a Resolved Distributor Firm / all intermediary-feed rows, by Intermediary Identifier Scheme and Source Feed.",
             _u("06", "Order Source", "Flow Source Book")
             + _u("06", "Intermediary As Delivered", "Dealer / Firm Number", "Resolved Distributor Firm", "Intermediary Identifier Scheme")
             + _u("06", "Identifier Crosswalk", "Source Identifier Value", "Resolved Party", "Crosswalk Effective From", "Crosswalk Effective To")
             + _u("06", "Transaction Dates", "Trade Date")),
        ],
        inputs=[
            ("06", "Transaction", ["Transaction ID", "Source Transaction Reference", "Source Feed", "Transaction Type",
                                   "Source Transaction Code", "Flow Direction", "Flow Scope", "Holding Type", "Share Class",
                                   "Product", "Account", "Originating Fund Order", "Look-Through Level"]),
            ("06", "Transaction Dates", ["Trade Date", "Settlement Date", "As-Of Date"]),
            ("06", "Transaction Amounts", ["Units", "Gross Amount", "Net Amount", "Reporting Currency Amount"]),
            ("06", "Order Source", ["Flow Source Book", "Source Client Account Activity", "Source Account Transfer",
                                    "Source Register Transaction", "Source Participant Ledger Posting",
                                    "Source Portfolio Capital Activity", "Source Channel Assignment", "Order Entry Channel",
                                    "Systematic Plan Indicator", "Contribution Source Type"]),
            ("06", "Intermediary As Delivered", ["Dealer / Firm Number", "Branch Number", "Representative Number",
                                                 "Intermediary Identifier Scheme", "Resolved Distributor Firm",
                                                 "Resolved Office / Branch", "Resolved Advisor / Rep"]),
            ("06", "Linked Transaction", ["Linked Transaction ID", "Contra Share Class", "Transfer Type", "Same-Owner Indicator",
                                          "From Distribution Channel", "To Distribution Channel"]),
            ("06", "ETF Creation / Redemption", ["Authorized Participant", "Creation Units", "Basket Type"]),
            ("06", "SMA Flow", ["Sponsor Program", "Model Portfolio"]),
            ("06", "Transaction Status", ["Transaction Status", "Cancel / Correct Indicator", "Original Transaction ID",
                                          "Correction Reason"]),
            ("06", "Account Channel Assignment", ["Channel Assignment ID", "Assigned Account", "Assigned Distribution Channel",
                                                  "Assigned Business Line", "Channel Assignment Basis", "Channel Effective From",
                                                  "Channel Effective To"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Market Value"]),
            ("06", "Attribution Record", ["Attribution Record ID", "Source Record Type", "Source Transaction", "Attributed Amount",
                                          "Attribution Share %", "Attribution Effective Date"]),
            ("06", "Market & Client Dimensions", ["Distribution Channel", "Business Line", "Service Offering", "Covering Advisor",
                                                  "Advisor Coverage Assignment", "Client Household", "Retirement Plan",
                                                  "Institutional Client", "Consultant", "Attributed Campaign",
                                                  "Campaign Attribution Weight"]),
            ("06", "Attribution Method", ["Attribution Method", "Attribution Source", "Match Confidence Band", "Allocation Basis"]),
            ("06", "Unattributed Item", ["Unattributed Item ID", "Lowest Resolved Level", "Unattributed Reason",
                                         "Unattributed Amount", "Suspense Channel", "First Seen Date", "Resolution Status"]),
            ("06", "Identifier Crosswalk", ["Crosswalk ID", "Source Feed", "Source Identifier Type", "Source Identifier Value",
                                            "Resolved Party", "Resolved Account", "Crosswalk Effective From",
                                            "Crosswalk Effective To"]),
            ("06", "Data Feed", ["Feed ID", "Feed Name", "Data Provider", "Feed Type", "Source Precedence Rank"]),
            ("06", "Reporting Period", ["Reporting Period ID", "Period Type", "Final Close Date"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Type", "Trade Date",
                                               "Activity Net Amount", "Activity Status", "Source Money Movement"]),
            ("29", "Register Transaction", ["Register Transaction ID", "Register Transaction Type", "Posting Account",
                                            "Register Trade Date", "Gross Amount", "Register Transaction Status"]),
            ("16", "Participant Ledger Posting", ["Ledger Posting ID", "Posting Type", "Posted Amount", "Posting Trade Date"]),
            ("18", "Portfolio Capital Activity", ["Activity Portfolio", "Activity Account", "Capital Activity Type",
                                                  "Activity Trade Date", "Activity Amount Base"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
        ],
        upstream=["DP-300", "DP-580", "DP-430", "DP-141", "DP-007", "DP-093", "DP-094", "DP-240", "DP-001", "DP-003",
                  "DP-004", "DP-009", "DP-011", "DP-013"],
        refresh="Daily",
        timeliness=("By 7am ET on T+1 for rows copied from the 49, 29, 16 and 18 books (after their nightly cycles); "
                    "intermediary-feed rows within 1 business day of receipt; inter-channel transfer rows on the business day "
                    "after the channel assignment changes"),
        history=("Every transaction version and attribution record kept since the 06 go-live, append-only; prior attributions "
                 "are retained when a re-attribution or override applies; account-level rows kept at least six years, the "
                 "retention of the books they copy (SEC Rule 17a-4, Rule 204-2)"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Account resolves to a DP-093 account, every Share Class and Product to DP-004, every Covering Advisor to a DP-009 coverage open on the Trade Date, every Client Household to a DP-240 household, every Resolved Distributor Firm to DP-001, every Institutional Client to DP-003 and every Attributed Campaign to a DP-011 campaign.",
            "Account Channel Assignment periods of one Assigned Account do not overlap and Channel Effective To is blank or on or after Channel Effective From, so every flow has exactly one channel on its Trade Date; Identifier Crosswalk periods per Source Feed, Source Identifier Type and Source Identifier Value do not overlap.",
            "Source Book Reconciliation Variance is within USD 1.00 per flow book and business date, Inter-Channel Transfer Pairing Breaks is zero, and Attributed Amount plus Unattributed Amount equals Reporting Currency Amount for each transaction and split basis.",
            "Transaction Type, Flow Direction, Flow Scope, Holding Type, Account, Trade Date, Reporting Currency Amount and Flow Source Book are populated on every current row, and the source reference the Flow Source Book names is set on every row whose Flow Source Book is Brokerage Book of Record (49), Transfer Agent Register (29), Workplace Recordkeeping (16) or Institutional Portfolio Book (18).",
            "Representative Name As Delivered, Sub-Account Identifier As Delivered and Identifier Crosswalk Source Name Text and Source Address / ZIP Code are not read; account, household and advisor keys are published only to client and channel analytics, operations and supervision roles, and every other reader receives channel, holding type and business line aggregates.",
            "Rows of trade date D are published by 7am ET on D+1; a 29 omnibus or nominee posting and a 50 money movement instruction are never loaded as flows, and a corrected source record creates a new version (Cancel / Correct Indicator Correct or Reversal, with Original Transaction ID), never an edit.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP row Transaction (06, TXN-; glossary Flow Transaction, CW-141), with the 06 rows "
               "Attribution Record (ATR-), Data Feed (technical, FEED-) and Identifier Crosswalk (XWK-) it publishes for flows; "
               "source of the client flow facts of the SM-20 conformed set. Book: the flow record, never a book of record; each internal row "
               "is a Derived copy of the one flow book of its account (row rule CD-289, 06 ruling 2), and only intermediary-feed "
               "rows are mastered here. Certified numbers: none owned; DP-008 applies the Measure Definitions and Flow Treatment "
               "Rule to these rows to certify Net New Assets, Net Inter-Channel Transfers and the own-fund flows. PII tier: "
               "financial (account-level client flows; identity only through the 02 household key and the 03 advisor key). "
               "Boundaries: client orders are DP-301's and the register DP-580's; money movements (DP-302) are lineage only, "
               "through 49 Client Account Activity Source Money Movement; DP-006 reads no 50 attribute, so DP-302 is not upstream "
               "(module convention: DP-302 is listed wherever a 50 attribute is read, as DP-008 does); the amount of a generated "
               "inter-channel transfer is the DP-007 Account Asset Summary total, so DP-007 is upstream; salesperson credit for the "
               "IC and IA lines and the distributor hierarchy path are not published here (DIS DP-491, with DP-483's Salesperson "
               "Credit, and DP-001); the client asset data supply chain, suspense aging and feed SLAs are DIS DP-495's. "
               "18 Portfolio Capital Activity is read through DP-141, which publishes it. "
               "Acceptance question 2 (plan section 8.5): feeds DP-008, DP-491 and DP-492 with Client Asset Flow Amount "
               "(Pre-Treatment) and Advisor and Campaign Attributed Flow Amount (the advisor-of-record and campaign keys on 06, "
               "from 03 coverage and 04 attribution) over rows copied from 49 Client Account Activity, whose Source Money "
               "Movement links 50. Acceptance question 10: feeds DP-008 and DP-467 with Inter-Channel Transfer Amount (rollover "
               "pairs of the 16 distribution posting and the 49 IRA receipt). "
               "Tailoring lever: intermediary attribution depth. Reference default: advisor level where feeds allow, firm level "
               "otherwise (06 SME question 5). Tailoring lever: campaign window. Reference default: the funding flow of the "
               "milestone only (06 SME question 9). Tailoring lever: rollover treatment. Reference default: firm-plan to "
               "firm-IRA rollovers are inter-channel transfers; the treatment is applied in DP-008 (06 SME question 2). "
               "Taxonomy gap: 18 Portfolio Capital Activity has no identifier, so Source Portfolio Capital Activity resolves on "
               "Activity Portfolio x Activity Trade Date x Capital Activity Type. Taxonomy gap: 06 Transaction has no attribute "
               "naming the 47 Fee Debit behind a Fee Debit row; it is reached through 49 Client Account Activity Source Fee "
               "Debit. Drafting assumptions: the USD 1.00 reconciliation tolerance; the 7am ET deadline; the 49 Activity Types, "
               "16 Posting Types and 18 Capital Activity Types counted as flows. Decisions: CW-007, CW-122, CW-141, CW-142, CW-143, CW-144, CW-150, CW-203, CD-289. "
               "WP1 re-scope (CW-203): renamed Client Flow Transactions; owning domain 06 unchanged; upstream DP-002 (retired) "
               "replaced by DP-001, DP-005 dropped, DP-300, DP-580, DP-430, DP-141, DP-007, DP-093, DP-094, DP-240 and DP-011 "
               "added; "
               "inputs 06 Distributor Hierarchy, 06 Salesperson Credit and 09 FX Rate Type dropped (DP-001 and DP-491; USD only) "
               "and Transaction Amounts Price, Transaction Currency and FX Rate Applied dropped; 06 Account Channel Assignment, "
               "06 Account Asset Summary (generated transfer amounts), the new Transaction, Order Source and Linked Transaction "
               "attributes and the 49, 29, 16 and 18 source books added; "
               "measures Attribution Rate %, Unattributed Amount (both read by SM-01), Attributed Amount (Reporting Currency), "
               "Same-Owner Movement Flag and Late Correction Flag kept by name; dimensions 'Distributor firm / office / team / "
               "advisor' renamed 'Intermediary firm / office (DP-001)' and 'Credited salesperson' dropped. Readers of the "
               "dropped 06 Distributor Hierarchy: the SM-01 attributed_transactions dimension 'Distributor Firm', and the "
               "data-model conformers in models_c1_sales, models_c2_marketing_product and models_c10_shareholder_ops; "
               "re-point them to DP-001 or drop them. Measures added that SM-01 (until SM-20) must publish or exclude: Flow "
               "Transactions Loaded, Client Asset Flow Amount (Pre-Treatment), Own-Fund Flow Amount (Pre-Treatment), "
               "Inter-Channel Transfer Amount, Inter-Channel Transfer Pairing Breaks, Flows Without Source Record, Source Book "
               "Reconciliation Variance, Duplicate Source Records, Flows Without Channel Assignment, Advisor and Campaign "
               "Attributed Flow Amount, Intermediary Rows Resolved %. The objects behind the conformed entities Transaction, Attribution Record, Data Feed, Linked "
               "Transaction and Identifier Crosswalk are kept. Earlier stage lines (W4 re-point CW-132, CW-133, CW-141, CW-143, "
               "CW-151) are superseded by this re-scope."
               " WP2 retirement sweep (CW-209): SM-01, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-007": dict(
        definition=("The daily client asset summaries and own-fund shareholder positions of every account, copied with their "
                    "source book and never a book of record (CW-007, CW-141): the 06 Account Asset Summary (firm client "
                    "account x as-of date x holding type, net equity summed from 49 Client Holding Valuation, Account Cash "
                    "Balance and Margin Balance Snapshot for brokerage, managed and trust accounts, from the 29 register at "
                    "the 27 NAV for direct registered accounts, from 16 Participant Balance for participant accounts and from "
                    "18 for institutional mandates) and the 06 Fund Shareholder Position (account x own share class x "
                    "valuation date x source, a view of 49 Client Holding or 29 Share Register Balance, mastered only on "
                    "intermediary look-through rows) with its Aggregation Role. It publishes the CONCEPT_OWNERSHIP row Fund "
                    "Shareholder Position (06, POS-), assigns every account its channel on the as-of date and reconciles each "
                    "summary to its book. It is the client asset input of DP-008 and DP-241 and owns no certified metric family."),
        business_questions=[
            "What is the net equity of every firm client account by holding type, channel and source book on the as-of date, before DP-008 certifies Client Assets?",
            "Which fund shareholder positions are counted (firm client account or intermediary), excluded as omnibus, nominee or firm proprietary, or kept for attribution only?",
            "Do account asset summaries tie to the 49, 29, 16 and 18 books, and fund shareholder positions to the 29 register, and where are the breaks?",
            "How much intermediary-held own-fund value can we see through omnibus, ETF, plan and sponsor sources, and how much is omnibus residual?",
            "Which accounts have no channel, or two channels, on the as-of date, and which feeds were late or missing?",
        ],
        grain=("Account Asset Summary (firm client account x as-of date x holding type) as the main output, with Fund "
               "Shareholder Position (account x own share class x valuation date x position source, with Aggregation Role "
               "and Position Source Book) and its look-through, ETF, plan and sponsor attribute groups, attribution records, "
               "loads, reconciliation runs and breaks as companion facts; daily snapshots"),
        dimensions=["Valuation date (DP-013)", "Product and share class (DP-004)",
                    "Account and account registration type (DP-093)", "Distribution channel", "Business line",
                    "Holding type", "Own-product indicator", "Source book", "Aggregation role",
                    "Retirement plan (DP-094)", "Recordkeeper (DP-001)", "Institutional client / consultant (DP-003)",
                    "Sponsor program (DP-005)", "Client household (DP-240)", "Position source",
                    "Attribution method and confidence band"],
        measures=[
            ("Account Asset Summary Market Value",
             "Sum of Summary Market Value (net equity: long value, shorts negative, cash and sweep less margin debit) by Summary Holding Type, Summary Distribution Channel and Summary Source Book on the Summary As-Of Date, over firm client accounts; the input DP-008 certifies, never Client Assets itself.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Holding Type",
                "Summary Source Book", "Summary Market Value", "Summary Distribution Channel")),
            ("Own-Product Summary Market Value",
             "Sum of Summary Market Value of Account Asset Summary rows with Own-Product Indicator = Y (own mutual funds, ETFs and CITs), by Summary Holding Type.",
             _u("06", "Account Asset Summary", "Own-Product Indicator", "Summary Market Value", "Summary Holding Type")),
            ("Advised Account Summary Market Value",
             "Sum of Summary Market Value of Account Asset Summary rows with Advised Assets Indicator = Y, as the 06 summary carries the indicator, by Summary Account and as-of date. An account-level input only: the certified Advised Assets rule (enrollment in force, channel roll-up) is defined in DP-008 alone.",
             _u("06", "Account Asset Summary", "Advised Assets Indicator", "Summary Market Value", "Summary Account",
                "Summary As-Of Date")),
            ("Counted Fund Shareholder Position Value",
             "Sum of Market Value of Fund Shareholder Positions by Aggregation Role (Counted - Firm Client Account, Counted - Intermediary; the Excluded and Attribution Only roles shown separately), Share Class, Position Source Book and Valuation Date.",
             _u("06", "Fund Shareholder Position", "Market Value", "Aggregation Role", "Share Class", "Valuation Date",
                "Position Source Book")),
            ("Intermediary-Held Own-Fund Value",
             "Market Value of Fund Shareholder Positions with Aggregation Role Counted - Intermediary plus the Omnibus Residual Amount taken once per Omnibus Parent Account x Share Class x Valuation Date; the basis DP-008 removes for Client Assets Excluding Intermediary-Held.",
             _u("06", "Fund Shareholder Position", "Aggregation Role", "Market Value", "Share Class", "Valuation Date")
             + _u("06", "Omnibus Look-Through", "Omnibus Residual Amount", "Omnibus Parent Account")),
            ("Look-Through Coverage %",
             "Value resolved below the omnibus parent / omnibus parent market value, per Omnibus Parent Account and Valuation Date.",
             _u("06", "Omnibus Look-Through", "Look-Through Coverage %")
             + _u("06", "Fund Shareholder Position", "Valuation Date", "Market Value")),
            ("Attributed Position Value",
             "Market Value (or Summary Market Value) x Attribution Share % for each attribution record whose Source Position or Source Account Asset Summary is the row, by Distribution Channel, Covering Advisor and Client Household.",
             _u("06", "Attribution Record", "Attribution Share %", "Source Position", "Source Account Asset Summary")
             + _u("06", "Fund Shareholder Position", "Market Value") + _u("06", "Account Asset Summary", "Summary Market Value")
             + _u("06", "Market & Client Dimensions", "Distribution Channel", "Covering Advisor", "Client Household")),
            ("Unattributed Position Amount",
             "Sum of Unattributed Amount of fund shareholder position and summary suspense items by Lowest Resolved Level, Unattributed Reason and Suspense Channel, aged from First Seen Date while Resolution Status is not Resolved.",
             _u("06", "Unattributed Item", "Lowest Resolved Level", "Unattributed Reason", "Unattributed Amount",
                "Suspense Channel", "First Seen Date", "Resolution Status")),
            ("Source Reconciliation Variance",
             "Per own share class and valuation date, under the unit coverage rule stated here once (DP-241 references it): Registered Shares of the 29 Share Register Balance rows on the Register Business Date whose Register Account Category is Fund-Only, Institutional Direct or Networked (and CIT Unitholder rows of firm client accounts) minus the Units Held of the Fund Shareholder Positions with Position Source Book Transfer Agent Register (29) and the same Register Account Category; units in the Broker-Dealer Omnibus, Intermediary Omnibus, Plan Omnibus and DTC Nominee categories are never counted as unreconciled, because the 49 rows, the look-through rows and residual, the 16 participant summaries and the 18 summaries of nominee-held IA mandates already carry them; Firm Proprietary units are seed (DP-204). Valued at the 27 NAV per Share; within the Reconciliation's Absolute Tolerance to pass.",
             _u("06", "Reconciliation", "Absolute Tolerance")
             + _u("06", "Fund Shareholder Position", "Valuation Date", "Units Held", "Share Class", "Position Source Book",
                  "Register Account Category")
             + _u("29", "Share Register Balance", "Register Share Class", "Register Business Date", "Register Account Category",
                  "Registered Shares")
             + _u("27", "Share Class NAV", "NAV Share Class", "NAV per Share")),
            ("Summary to Book Variance",
             "Per Summary Account and Summary As-Of Date: Summary Market Value total minus its book: for Summary Source Book Brokerage Book of Record (49), Market Value in USD of the account's Client Holdings of Client Holding View End of Day plus client cash under the client cash rule stated here once (" + _CASH_RULE + "); for Workplace Recordkeeping (16), Balance Market Value of the memberships whose Participant Account is the account; for Institutional Portfolio Book (18), Total IBOR Market Value of the Portfolio Valuation Summary of Valuation View End of Day of the portfolio whose primary Portfolio Implementation Link names the account as Managed Account; for Fund Shareholder Position (06), Market Value of the account's register Fund Shareholder Positions.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Source Book", "Summary Market Value")
             + _u("49", "Client Holding", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("49", "Account Cash Balance", *_CASH)
             + _u("49", "Margin Balance Snapshot", *_MARGIN)
             + _u("16", "Participant Balance", "Balance Membership", "Valuation Date", "Balance Market Value")
             + _u("16", "Participant Plan Membership", "Membership ID", "Participant Account")
             + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Valuation View",
                  "Total IBOR Market Value")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Managed Account", "Primary Implementation Indicator")
             + _u("06", "Fund Shareholder Position", "Account", "Position Source Book", "Market Value")),
            ("Accounts Without Channel Assignment",
             "Count of Summary Accounts with no Account Channel Assignment whose Channel Effective From is on or before the Summary As-Of Date and Channel Effective To blank or on or after it.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date")
             + _u("06", "Account Channel Assignment", "Assigned Account", "Channel Effective From", "Channel Effective To")),
            ("Overlapping Channel Assignments",
             "Count of Assigned Accounts with two Account Channel Assignment rows (Channel Assignment ID) in force on one date, by Channel Assignment Basis.",
             _u("06", "Account Channel Assignment", "Channel Assignment ID", "Assigned Account", "Channel Effective From",
                "Channel Effective To", "Channel Assignment Basis")),
            ("Stale Summaries",
             "Count of Account Asset Summary rows and Fund Shareholder Positions whose Source As-Of Timestamp is earlier than the latest End of Day Client Holding As-Of Timestamp of the account for the as-of date.",
             _u("06", "Account Asset Summary", "Source As-Of Timestamp")
             + _u("06", "Fund Shareholder Position", "Source As-Of Timestamp")
             + _u("49", "Client Holding", "Client Holding As-Of Timestamp")),
            ("Loads Not Received",
             "Count of Loads of the Business Date with Load Status Missing, Partial, Received Late or Rejected, by Data Feed and Feed Type; fund shareholder positions of an affected feed are flagged estimated.",
             _u("06", "Load", "Load ID", "Feed", "Business Date", "Load Status") + _u("06", "Data Feed", "Feed ID", "Feed Type")),
            ("Open Reconciliation Breaks",
             "Count and sum of Difference Amount of Breaks with Break Status Open or Investigating, by Reconciliation Type and Break Age (Days), with Matched % of the latest Reconciliation Run.",
             _u("06", "Break", "Break ID", "Difference Amount", "Break Status", "Break Age (Days)")
             + _u("06", "Reconciliation", "Reconciliation Type") + _u("06", "Reconciliation Run", "Matched %")),
            ("Plan, ETF and Sponsor Reported Value",
             "Market Value of intermediary Fund Shareholder Positions by source: Plan Position rows by Retirement Plan and Recordkeeper (with Plan Participant Count), ETF Holding rows by Holding Custodian / Broker (ETF Shares Held), and Sponsor-Reported Assets by Sponsor and Model-Delivery Assets Indicator (Attribution Only; model-delivery assets are outside Client Assets and Firm AUM).",
             _u("06", "Fund Shareholder Position", "Market Value", "Aggregation Role")
             + _u("06", "Plan Position", "Retirement Plan", "Recordkeeper", "Plan Participant Count")
             + _u("06", "ETF Holding", "Holding Custodian / Broker", "ETF Shares Held")
             + _u("06", "Sponsor-Reported Assets", "Sponsor", "Model-Delivery Assets Indicator")),
        ],
        inputs=[
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Holding Type", "Summary Source Book",
                                             "Summary Market Value", "Own-Product Indicator", "Summary Distribution Channel",
                                             "Advised Assets Indicator", "Source As-Of Timestamp"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Account", "Share Class", "Valuation Date", "Position Source Book",
                                                 "Register Account Category", "Aggregation Role", "Source Client Holding",
                                                 "Source Share Register Balance", "Units Held", "Valuation NAV", "Market Value",
                                                 "Position Basis", "Position Source", "Source As-Of Timestamp"]),
            ("06", "Omnibus Look-Through", ["Omnibus Parent Account", "Look-Through Source", "Look-Through Coverage %",
                                            "Omnibus Residual Amount"]),
            ("06", "ETF Holding", ["Holding Custodian / Broker", "DTC Participant Number", "ETF Shares Held", "ETF Holdings Source"]),
            ("06", "Plan Position", ["Retirement Plan", "Recordkeeper", "Plan Participant Count"]),
            ("06", "Sponsor-Reported Assets", ["Sponsor", "Sponsor Reporting Basis", "Model-Delivery Assets Indicator"]),
            ("06", "Account Channel Assignment", ["Channel Assignment ID", "Assigned Account", "Assigned Distribution Channel",
                                                  "Assigned Business Line", "Channel Assignment Basis", "Basis Program Enrollment",
                                                  "Channel Effective From", "Channel Effective To"]),
            ("06", "Attribution Record", ["Attribution Record ID", "Source Record Type", "Source Position",
                                          "Source Account Asset Summary", "Attributed Amount", "Attribution Share %",
                                          "Attribution Effective Date"]),
            ("06", "Market & Client Dimensions", ["Distribution Channel", "Business Line", "Covering Advisor", "Client Household",
                                                  "Retirement Plan", "Institutional Client"]),
            ("06", "Attribution Method", ["Attribution Method", "Match Confidence Band"]),
            ("06", "Unattributed Item", ["Unattributed Item ID", "Lowest Resolved Level", "Unattributed Reason",
                                         "Unattributed Amount", "Suspense Channel", "First Seen Date", "Resolution Status"]),
            ("06", "Data Feed", ["Feed ID", "Feed Name", "Data Provider", "Feed Type", "Feed Grain", "Source Precedence Rank"]),
            ("06", "Load", ["Load ID", "Feed", "Business Date", "Record Count", "Control Total", "Load Status"]),
            ("06", "Reconciliation", ["Reconciliation ID", "Reconciliation Type", "Left Source", "Right Source",
                                      "Absolute Tolerance", "Relative Tolerance %"]),
            ("06", "Reconciliation Run", ["Run Business Date", "Matched %"]),
            ("06", "Break", ["Break ID", "Break Type", "Difference Amount", "Root Cause Category", "Break Status",
                             "Break Age (Days)"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Registration Type", "Account Status"]),
            ("15", "Account Hierarchy Link", ["Parent Account", "Child Account", "Account Link Type", "Link Effective From",
                                              "Link Effective To"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                                          "Enrollment Status", "Enrollment Effective Date", "Enrollment Termination Date"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Held Instrument", "Client Holding Date",
                                      "Client Holding View", "Client Holding As-Of Timestamp", "Own Share Class Indicator"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("49", "Account Cash Balance", list(_CASH)),
            ("49", "Margin Balance Snapshot", list(_MARGIN)),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date",
                                              "Register Account Category", "Registered Shares"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "NAV per Share"]),
            ("16", "Participant Balance", ["Balance Membership", "Valuation Date", "Balance Market Value"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant Account"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View",
                                                   "Total IBOR Market Value"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Managed Account", "Primary Implementation Indicator"]),
        ],
        upstream=["DP-300", "DP-580", "DP-430", "DP-142", "DP-140", "DP-165", "DP-093", "DP-094", "DP-240", "DP-001",
                  "DP-003", "DP-004", "DP-005", "DP-009", "DP-013"],
        refresh="Daily",
        timeliness=("Summaries and the 49 and register fund shareholder positions of as-of date D by 7am ET on D+1, after the 49 End of Day, 29 "
                    "register close, 16 and 18 cycles; intermediary look-through, ETF and plan fund shareholder positions within 2 business "
                    "days; sponsor-reported assets within 10 business days after month-end"),
        history=("Daily summaries and fund shareholder positions kept for 25 months; month-end summaries, fund shareholder positions and attributions kept since "
                 "the 06 go-live with superseded versions; each row keeps the Source As-Of Timestamp it was derived from"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Summary Account resolves to a DP-093 firm client account (never Account Type Omnibus Account at Transfer Agent or Networked Investor Account), every Fund Shareholder Position Account to DP-093, every Share Class to DP-004, every Retirement Plan to DP-094, every Sponsor to DP-001 and every Basis Program Enrollment to a DP-093 enrollment.",
            "Account Channel Assignment periods of one Assigned Account do not overlap and end on or after they start, and each account x share class x valuation date has exactly one Fund Shareholder Position with a Counted Aggregation Role, chosen by Source Precedence Rank.",
            "Summary to Book Variance is within USD 0.01 per account and as-of date under the client cash rule, Source Reconciliation Variance under the unit coverage rule is within the Reconciliation's Absolute Tolerance per share class, and Omnibus Residual Amount is non-negative, held once per Omnibus Parent Account x Share Class x Valuation Date and equal to the omnibus register value less the look-through total.",
            "Summary Market Value, Summary Holding Type, Summary Source Book, Own-Product Indicator, Summary Distribution Channel and Advised Assets Indicator are populated on every summary, and Aggregation Role, Position Source Book, Units Held and Market Value on every fund shareholder position; a 49 row has Source Client Holding and a register row Source Share Register Balance and Valuation NAV.",
            "Account-level summaries and fund shareholder positions are published only to client and channel analytics, operations and supervision roles; Sub-Account Identifier As Delivered and Plan Advisor are not read; every other reader receives channel x holding type x business line aggregates; no special-category data is read.",
            "Summaries of as-of date D are published by 7am ET on D+1; a summary is never edited, only re-derived from its book with a new Source As-Of Timestamp, and a locked DP-008 snapshot keeps the timestamps it used.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP row Fund Shareholder Position (06, POS-; CW-007, CW-141) and the 06 Account "
               "Asset Summary and Account Channel Assignment (CHASG-) rows it publishes, with the 06 rows Attribution Record "
               "(ATR-), Data Feed (technical, FEED-) and Load (LOAD-) for positions; source of the client position facts "
               "of the SM-20 conformed set. Two rules are stated once here and referenced by DP-008, DP-145 and DP-241: the "
               "client cash rule (Summary to Book Variance: settlement-date client cash of the named 49 cash types, margin "
               "debit subtracted once from the End of Day Margin Balance Snapshot) and the unit coverage rule (Source "
               "Reconciliation Variance: only units of the Fund-Only, Institutional Direct, Networked and CIT Unitholder "
               "register categories must have a 06 row; omnibus, plan omnibus and nominee units are already in Client "
               "Assets through other rows). Book: Fund Shareholder Position (06) is a view of Client Holding (49, DP-300) for "
               "brokerage, managed and trust accounts and of the 29 Share Register Balance (DP-580) for every other registered "
               "account; Account Asset Summary is computed by summing the named book (49, 16 through DP-430, 18 Portfolio "
               "Valuation Summary through DP-142 and DP-140, the register at the 27 NAV through DP-165); client holdings are "
               "never taken from 18 or 06. Certified numbers: none owned; Client Assets, Advised Assets and the own-fund "
               "overlap are certified in DP-008 from these rows. PII tier: financial (account-level client data, CW-150). "
               "Boundaries: the 49-to-29 omnibus reconciliation is 49's (CW-122) and is not restated here; Source "
               "Reconciliation Variance compares the counted 06 rows to the register only; feed SLAs and suspense workflow are "
               "DIS DP-495's; managed-account market value for Firm AUM is CLA-A DP-345's. "
               "Acceptance question 1 (plan section 8.5): feeds DP-008 and DP-241 with Account Asset Summary Market Value, "
               "Own-Product Summary Market Value and Counted Fund Shareholder Position Value, traced to 49, 16, 29 and 18. "
               "Tailoring lever: net equity or gross long value. Reference default: net equity (margin debit deducted; 06 "
               "ruling 4). Tailoring lever: intermediary-held own-fund assets in Client Assets. Reference default: included "
               "as their own channels (06 SME question 3). Tailoring lever: holding-type list. Reference default: the eleven "
               "Holding Type values (06 SME question 4). "
               "Taxonomy gap: no attribute records which position source won under Source Precedence Rank for an account, "
               "share class and date; it is derived. Taxonomy gap: 06 Account Asset Summary has no reference to the 18 "
               "portfolio it summarizes; the link is the 18 Portfolio Implementation Link Managed Account. "
               "Drafting assumptions: the USD 0.01 tolerance; the 7am ET deadline; the Load Status values counted as not "
               "received; Short Sale Proceeds counted as client cash (lever: exclude it with the short positions); CIT "
               "Unitholder rows counted only for firm client accounts. Decisions: CW-007, CW-122, CW-139, CW-141, CW-142, CW-150, CW-203, CD-289. "
               "WP1 re-scope (CW-203): renamed Client Asset Positions; owning domain 06 unchanged; upstream DP-002 (retired) "
               "replaced by DP-001, DP-300, DP-580, DP-430, DP-142, DP-140, DP-165, DP-094 and DP-240 added; inputs 06 "
               "Distributor Hierarchy, 15 Intermediary Account Servicing and 09 FX Rate Type dropped (DP-001 and DP-093 "
               "publish the intermediary path; USD only); 06 Account Asset Summary, Account Channel Assignment, Break and the "
               "49, 29, 27, 16 and 18 books added; measures renamed: 'Attributed AUM (Reporting Currency)' to 'Attributed "
               "Position Value', 'Unattributed AUM' to 'Unattributed Position Amount' (read by SM-01), 'Advisory Program AUM' "
               "to 'Advised Account Summary Market Value' (read by SM-01; it no longer applies its own enrollment rule); "
               "'Attributed AUM (Reporting Currency)' is read by the SM-01 attributed_positions table (column "
               "attributed_aum) and must be re-pointed to 'Attributed Position Value'; the dropped 06 Distributor Hierarchy "
               "is read by the SM-01 attributed_positions dimension 'Distributor Firm' (re-point to DP-001 or drop); "
               "'Look-Through Coverage %' and 'Source Reconciliation Variance' kept (read by SM-01; the latter now "
               "reconciles units to the register under the unit coverage rule); 'AUM' is reserved for Firm AUM. Measures "
               "added that SM-01 (until SM-20) must publish or exclude: Account Asset Summary Market Value, Own-Product "
               "Summary Market Value, Counted Fund Shareholder Position Value, Intermediary-Held Own-Fund Value, Summary to "
               "Book Variance, Accounts Without Channel Assignment, Overlapping Channel Assignments, Stale Summaries, Loads "
               "Not Received, Open Reconciliation Breaks, Plan, ETF and Sponsor Reported Value. The objects behind the conformed entities Account (15 Account) and Position (06 Fund "
               "Shareholder Position) are kept, as are Data Feed, Attribution Record and Reconciliation. Earlier stage lines "
               "(W1 re-point CW-021, W4 re-point CW-007, CW-141, CW-151) are superseded by this re-scope."
               " WP2 retirement sweep (CW-209): SM-01, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-008": dict(
        definition=("The firm's certified client asset family (CW-011, CW-142): Ending, Beginning and Average Client Assets, "
                    "Net New Assets, Advised Assets, Client Market Movement and Other, Net Inter-Channel Transfers, Client "
                    "Organic Growth Rate, Client Assets Excluding Intermediary-Held and the Own-Fund Overlap Amount (reported, "
                    "never netted here), the own-fund Gross Sales, Redemptions and Net Flows by channel, and the counts of "
                    "Funded Accounts, Clients and Households, each certified (CW-011). It applies the 06 Measure Definitions "
                    "and Flow Treatment Rule once to the flows of DP-006 and the account asset summaries and fund shareholder positions of DP-007, stores "
                    "every value as a 06 Measure Value keyed by measure x period end x Dimension Type x Dimension Key x data "
                    "basis x snapshot, locks period-end snapshots and records every restatement. It publishes the "
                    "CONCEPT_OWNERSHIP rows Flow & Client Asset Measure Definition (06, MSR-) and Snapshot (06, SNP-) and is "
                    "the only source of these numbers; Firm AUM is DP-241's and is never added to them."),
        business_questions=[
            "What were Client Assets at month-end by channel and holding type, the certified figure DP-241 reconciles to Firm AUM?",
            "What were Net New Assets this quarter by channel, advisor and campaign, and how much of the change in Client Assets came from market movement, income and fees?",
            "How much moved between channels (advice enrollments, journals, rollovers from firm plans into firm IRAs), and what are Advised Assets?",
            "What were own-fund gross sales, redemptions and net flows by channel and share class?",
            "How many funded accounts, clients and households does the firm have by channel and segment?",
            "Which values were restated after the period was locked, by how much, and does the change affect compensation?",
        ],
        grain=("Measure value (06 Measure Value): measure x period end x Dimension Type (Total, Channel, Holding Type, Business "
               "Line, Advisor, Campaign, Share Class, Segment) x Dimension Key x data basis x snapshot, one dimension per row; "
               "Measure Definition with its Flow Treatment Rule (definition version) and Restatement as companions; daily "
               "flash and monthly locked snapshots, superseded versions kept"),
        dimensions=["Reporting period (DP-013)", "Distribution channel", "Business line", "Holding type",
                    "Advisor of record (DP-009)", "Campaign (DP-011)", "Product and share class (DP-004)",
                    "Client segment (DP-240)",
                    "Data basis (actual / estimated)", "Snapshot version", "Measure definition version"],
        measures=[
            ("Ending Client Assets",
             "Certified (CW-011). Measure Amount of MSR-CLIENTASSETS on the last business day of the period (End of Day): the sum of Summary Market Value of DP-007 Account Asset Summary rows with Summary As-Of Date = Period End Date over firm client accounts (Summary Source Book Brokerage Book of Record (49), Fund Shareholder Position (06) for the 29 register, Workplace Recordkeeping (16) and Institutional Portfolio Book (18)), plus Market Value of DP-007 Fund Shareholder Positions with Aggregation Role Counted - Intermediary, plus the Omnibus Residual Amount taken once per Omnibus Parent Account x Share Class x Valuation Date; rows of every Excluded role are never counted, so nothing is added twice. Net equity under DP-007's client cash rule. Split by Summary Distribution Channel, Summary Holding Type and the Assigned Business Line in force; intermediary rows and residuals take Holding Type Own Mutual Fund, Own ETF or Own CIT from the Vehicle Type of the share class's Parent Product (DP-004). Each summary is the copy of its book: 49 Client Holding Valuation, 16 Participant Balance, 29 Share Register Balance, 18 Portfolio Valuation Summary.",
             _u("06", "Client Asset Measures", "Ending Client Assets")
             + _mv("Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot")
             + _u("06", "Measure Definition", "Measure ID", "Certified Indicator")
             + _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Holding Type",
                  "Summary Source Book", "Summary Market Value", "Summary Distribution Channel")
             + _u("06", "Fund Shareholder Position", "Aggregation Role", "Market Value", "Valuation Date", "Share Class")
             + _u("06", "Omnibus Look-Through", "Omnibus Residual Amount", "Omnibus Parent Account")
             + _u("06", "Account Channel Assignment", "Assigned Business Line")
             + _u("01", "Share Class", "Share Class ID", "Parent Product") + _u("01", "Investment Product", "Vehicle Type")
             + _u("49", "Client Holding", "Holding Account", "Client Holding Date")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("16", "Participant Balance", "Balance Membership", "Valuation Date", "Balance Market Value")
             + _u("29", "Share Register Balance", "Register Account", "Register Business Date", "Registered Shares")
             + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value")),
            ("Beginning Client Assets",
             "Ending Client Assets of the prior period's locked snapshot (Snapshot Type Final or Restated) for the same Dimension Type and Dimension Key.",
             _u("06", "Client Asset Measures", "Beginning Client Assets")
             + _mv("Period Start Date", "Snapshot", "Dimension Type", "Dimension Key")
             + _u("06", "Snapshot", "Snapshot Type") + ["Ending Client Assets"]),
            ("Average Client Assets",
             "Certified (CW-142). Measure Amount of MSR-AVGCLIENTASSETS: the mean of the Ending Client Assets of each business day of the period under the 09 business calendar (month-end average for quarter and year periods); the asset basis 10 reads for basis-point measures.",
             _u("06", "Client Asset Measures", "Average Client Assets") + _mv("Period Type")
             + _u("09", "Reporting Period Definition", "Period Basis Calendar", "Business Day Convention")
             + _u("06", "Account Asset Summary", "Summary As-Of Date") + ["Ending Client Assets"]),
            ("Net New Assets",
             "Certified (CW-011). Measure Amount of MSR-NNA: sum of Reporting Currency Amount, signed by Flow Direction, of current DP-006 rows (Transaction Status not Canceled, Reversed or Rejected) with Flow Scope Client Asset Flow or Client Asset and Fund Flow and a Transaction Type in the Included and not the Excluded Transaction Types, assigned to periods by Time Basis (Trade Date), under the Flow Treatment Rule defaults: Income Treatment and Fee Treatment exclude income and fees to market movement and other, Rollover Treatment makes firm-plan to firm-IRA rollovers inter-channel transfers, Transfer Treatment excludes same-owner transfers firm-wide; Inter-Channel Transfer rows are never counted. By channel (the Assigned Distribution Channel of the account's Account Channel Assignment in force on the Trade Date, carried as Distribution Channel on the attribution record), advisor of record (Covering Advisor from the 03 primary Party Coverage Assignment) and campaign (Attributed Campaign at its Campaign Attribution Weight, 04 Campaign). Rows of 49 accounts copy 49 Client Account Activity, whose Source Money Movement names the 50 movement.",
             _u("06", "Client Asset Measures", "Net New Assets")
             + _mv("Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount")
             + _u("06", "Measure Definition", "Included Transaction Types", "Excluded Transaction Types", "Time Basis")
             + _u("06", "Flow Treatment Rule", "Income Treatment", "Fee Treatment", "Rollover Treatment", "Transfer Treatment")
             + _u("06", "Transaction", "Transaction Type", "Flow Direction", "Flow Scope", "Account")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount") + _u("06", "Transaction Dates", "Trade Date")
             + _u("06", "Transaction Status", "Transaction Status") + _u("06", "Linked Transaction", "Same-Owner Indicator")
             + _u("06", "Order Source", "Flow Source Book", "Source Client Account Activity")
             + _u("06", "Market & Client Dimensions", "Covering Advisor", "Attributed Campaign", "Campaign Attribution Weight",
                  "Distribution Channel")
             + _u("06", "Account Channel Assignment", "Assigned Account", "Assigned Distribution Channel",
                  "Channel Effective From", "Channel Effective To")
             + _u("06", "Attribution Record", "Attributed Amount")
             + _u("49", "Client Account Activity", "Client Account Activity ID", "Activity Type", "Source Money Movement")
             + _u("50", "Money Movement", "Money Movement ID", "Money Movement Type")
             + _u("03", "Party Coverage Assignment", "Coverage Assignment ID", "Covering Advisor", "Primary Coverage Indicator")
             + _u("04", "Campaign", "Campaign ID")),
            ("Advised Assets",
             "Certified (CW-011); the Advised Assets rule is defined here only (DP-007 publishes the account-level summary value without a rule). Measure Amount of MSR-ADVISEDASSETS: sum of Summary Market Value of Account Asset Summary rows with Advised Assets Indicator = Y on the period end whose Summary Account has a fee-based advice, managed or trust 15 Program Enrollment with Enrollment Status Active, Enrollment Effective Date on or before the period end and Enrollment Termination Date blank or after it, equal to the roll-up of the Included Distribution Channels Direct - Digital Advice, Direct - Human Advice and Direct - Trust; participant managed accounts and institutional mandates excluded by default.",
             _u("06", "Client Asset Measures", "Advised Assets")
             + _u("06", "Measure Definition", "Included Distribution Channels")
             + _u("06", "Account Asset Summary", "Advised Assets Indicator", "Summary Market Value", "Summary As-Of Date")
             + _u("15", "Program Enrollment", "Enrolled Account", "Enrollment Status", "Enrolled Service Offering",
                  "Enrollment Effective Date", "Enrollment Termination Date")
             + _mv("Measure Amount")),
            ("Client Market Movement and Other",
             "Certified (CW-142). Ending Client Assets - Beginning Client Assets - Net New Assets - Net Inter-Channel Transfers for the same Dimension Type and Key: market appreciation, income and fees.",
             _u("06", "Client Asset Measures", "Client Market Movement and Other")
             + ["Ending Client Assets", "Beginning Client Assets", "Net New Assets", "Net Inter-Channel Transfers"]),
            ("Net Inter-Channel Transfers",
             "Certified (CW-142). Sum of Gross Amount of DP-006 rows with Flow Scope Inter-Channel Transfer into the channel (To Distribution Channel) less those out of it (From Distribution Channel), under the Inter-Channel Transfer Treatment and Rollover Treatment; zero at Dimension Type Total.",
             _u("06", "Client Asset Measures", "Net Inter-Channel Transfers")
             + _u("06", "Transaction", "Flow Scope") + _u("06", "Transaction Amounts", "Gross Amount")
             + _u("06", "Linked Transaction", "From Distribution Channel", "To Distribution Channel")
             + _u("06", "Flow Treatment Rule", "Inter-Channel Transfer Treatment", "Rollover Treatment")),
            ("Client Organic Growth Rate",
             "Certified (CW-142). Net New Assets / Beginning Client Assets for the period, annualized for periods shorter than a year (Period Type).",
             _u("06", "Client Asset Measures", "Client Organic Growth Rate") + _mv("Period Type")
             + ["Net New Assets", "Beginning Client Assets"]),
            ("Client Assets Excluding Intermediary-Held",
             "Certified (CW-011). Ending Client Assets less the Market Value of Fund Shareholder Positions with Aggregation Role Counted - Intermediary and the Omnibus Residual Amount (once per Omnibus Parent Account x Share Class x Valuation Date): the assets of firm client accounts only.",
             _u("06", "Client Asset Measures", "Client Assets Excluding Intermediary-Held")
             + _u("06", "Fund Shareholder Position", "Aggregation Role", "Market Value", "Share Class", "Valuation Date")
             + _u("06", "Omnibus Look-Through", "Omnibus Residual Amount", "Omnibus Parent Account") + ["Ending Client Assets"]),
            ("Own-Fund Overlap Amount",
             "Certified (CW-142); reported, never netted here. Sum of Summary Market Value of Account Asset Summary rows with Own-Product Indicator = Y plus the Market Value of Fund Shareholder Positions with Aggregation Role Counted - Intermediary and the Omnibus Residual Amount (once per Omnibus Parent Account x Share Class x Valuation Date) at the period end: own-fund, own-ETF and own-CIT assets inside Client Assets that are also in the own funds slice of Firm AUM. No measure of this product subtracts it; it is netted only in DP-241.",
             _u("06", "Client Asset Measures", "Own-Fund Overlap Amount")
             + _u("06", "Account Asset Summary", "Own-Product Indicator", "Summary Market Value")
             + _u("06", "Fund Shareholder Position", "Aggregation Role", "Market Value", "Share Class", "Valuation Date")
             + _u("06", "Omnibus Look-Through", "Omnibus Residual Amount", "Omnibus Parent Account") + _mv("Measure Amount")),
            ("Gross Sales",
             "Certified (CW-203). Sum of Reporting Currency Amount of current DP-006 inflow rows with Flow Scope Fund Flow or Client Asset and Fund Flow and Transaction Type Purchase, Exchange In (Exchange Treatment Include in Gross), Transfer In of a new owner or ETF Creation (ETF Flow Basis), by account across every channel (brokerage-account purchases from 49, never the omnibus posting); reinvestments excluded (Reinvestment Treatment), share class conversions under Share Class Conversion Treatment, money market funds under Money Market Inclusion.",
             _u("06", "Flow Measures", "Gross Sales", "Reinvested Distributions")
             + _u("06", "Flow Treatment Rule", "Reinvestment Treatment", "Exchange Treatment", "ETF Flow Basis",
                  "Money Market Inclusion", "Share Class Conversion Treatment")
             + _u("06", "Transaction", "Transaction Type", "Share Class", "Flow Direction", "Flow Scope")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount")),
            ("Redemptions",
             "Certified (CW-203). Sum of Reporting Currency Amount of current own-fund outflow rows (Redemption, Exchange Out, Transfer Out of a new owner, ETF Redemption) under the same treatment rules, shown as a positive amount.",
             _u("06", "Flow Measures", "Redemptions")
             + _u("06", "Transaction", "Transaction Type", "Flow Direction", "Flow Scope")
             + _u("06", "Transaction Amounts", "Reporting Currency Amount")),
            ("Net Exchanges",
             "Exchanges in less exchanges out within the own fund family (Transaction Type Exchange In and Exchange Out), reported separately when Exchange Treatment is Net Only.",
             _u("06", "Flow Measures", "Net Exchanges") + _u("06", "Flow Treatment Rule", "Exchange Treatment")
             + _u("06", "Transaction", "Transaction Type") + _u("06", "Transaction Amounts", "Reporting Currency Amount")),
            ("Net Flows",
             "Certified (CW-203). Gross Sales - Redemptions, plus Net Exchanges where Exchange Treatment is Net Only.",
             _u("06", "Flow Measures", "Net Flows (Net Sales)") + _u("06", "Flow Treatment Rule", "Exchange Treatment")
             + ["Gross Sales", "Redemptions", "Net Exchanges"]),
            ("Funded Accounts",
             "Certified (CW-011). Measure Amount of MSR-FUNDEDACCOUNTS: count of distinct Summary Accounts whose total Summary Market Value on the period end is greater than zero, over 15 accounts with Account Status Open whose Account Type is a firm client account type, by Summary Distribution Channel. A distinct count (Measure Definition Aggregation Behavior Non-Additive): an account counts once at Total, and channel values do not sum to Total.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary Market Value", "Summary As-Of Date",
                "Summary Distribution Channel")
             + _u("15", "Account", "Account ID", "Account Status", "Account Type")
             + _u("06", "Measure Definition", "Aggregation Behavior") + _mv("Measure", "Measure Amount")),
            ("Clients",
             "Certified (CW-011). Measure Amount of MSR-CLIENTS: count of distinct 02 parties that, on the period end, hold an owner Account Role Type (Primary Owner, Joint Owner, Inherited IRA Owner) on a funded account (Account Role Effective From / To), or are the Participant of a 16 Participant Plan Membership whose Participant Account is funded, with an active 02 Party Role of Role Type Client or Plan Participant (CW-011 counts workplace participants; lever below). A distinct count (Non-Additive): channel and segment values do not sum to Total.",
             _u("15", "Account Party Role", "Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                "Account Role Effective To")
             + _u("16", "Participant Plan Membership", "Participant", "Participant Account", "Membership Status")
             + _u("02", "Party Role", "Role Party", "Role Type", "Role Status") + _u("02", "Party", "Party ID", "Party Type")
             + _u("06", "Measure Definition", "Aggregation Behavior") + ["Funded Accounts"]),
            ("Households",
             "Certified (CW-011). Measure Amount of MSR-HOUSEHOLDS: count of distinct 02 Client Households (PTY-HH-) with at least one of the Clients as a member under a Household Membership with Membership Status Active effective on the period end. The 02 household, never the 13 mailing householding group or the 47 Fee Household. A distinct count (Non-Additive): channel and segment values do not sum to Total.",
             _u("02", "Household Membership", "Household", "Household Member", "Membership Status",
                "Membership Effective From", "Membership Effective To") + ["Clients"]),
            ("Restatement Impact",
             "Net Impact Amount of restatements affecting a period after it was locked, by Restatement Reason and Affected Periods, with Compensation Impact Indicator.",
             _u("06", "Restatement", "Restatement ID", "Net Impact Amount", "Affected Periods", "Restatement Reason",
                "Compensation Impact Indicator")),
        ],
        inputs=[
            ("06", "Measure Definition", ["Measure ID", "Measure Name", "Measure Category", "Business Definition",
                                          "Calculation Formula", "Included Transaction Types", "Excluded Transaction Types",
                                          "Included Distribution Channels", "Aggregation Behavior", "Time Basis",
                                          "Measure Owner Role", "Certified Indicator"]),
            ("06", "Flow Treatment Rule", ["Reinvestment Treatment", "Exchange Treatment", "Transfer Treatment",
                                           "Share Class Conversion Treatment", "ETF Flow Basis", "Model-Delivery Inclusion",
                                           "Money Market Inclusion", "Income Treatment", "Fee Treatment",
                                           "Inter-Channel Transfer Treatment", "Rollover Treatment"]),
            ("06", "Measure Value", ["Measure", "Period Type", "Period Start Date", "Period End Date", "Dimension Type",
                                     "Dimension Key", "Reporting Period", "Measure Amount", "Data Basis", "Snapshot",
                                     "Attributed Share %"]),
            ("06", "Client Asset Measures", ["Beginning Client Assets", "Ending Client Assets", "Net New Assets",
                                             "Client Market Movement and Other", "Net Inter-Channel Transfers",
                                             "Client Organic Growth Rate", "Advised Assets", "Average Client Assets",
                                             "Client Assets Excluding Intermediary-Held", "Own-Fund Overlap Amount"]),
            ("06", "Flow Measures", ["Gross Sales", "Redemptions", "Net Exchanges", "Net Flows (Net Sales)",
                                     "Reinvested Distributions"]),
            ("06", "Asset Measures", ["Beginning AUM", "Ending AUM", "Market Movement", "Average AUM", "Organic Growth Rate"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Holding Type",
                                             "Summary Source Book", "Summary Market Value", "Own-Product Indicator",
                                             "Summary Distribution Channel", "Advised Assets Indicator"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Share Class", "Valuation Date", "Aggregation Role",
                                                 "Market Value"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant", "Participant Account", "Membership Status"]),
            ("06", "Omnibus Look-Through", ["Omnibus Parent Account", "Omnibus Residual Amount"]),
            ("06", "Transaction", ["Transaction ID", "Transaction Type", "Flow Direction", "Flow Scope", "Holding Type",
                                   "Share Class", "Account"]),
            ("06", "Transaction Dates", ["Trade Date"]),
            ("06", "Transaction Amounts", ["Gross Amount", "Reporting Currency Amount"]),
            ("06", "Transaction Status", ["Transaction Status"]),
            ("06", "Linked Transaction", ["Same-Owner Indicator", "From Distribution Channel", "To Distribution Channel"]),
            ("06", "Order Source", ["Flow Source Book", "Source Client Account Activity"]),
            ("06", "Account Channel Assignment", ["Channel Assignment ID", "Assigned Account", "Assigned Distribution Channel",
                                                  "Assigned Business Line", "Channel Effective From", "Channel Effective To"]),
            ("06", "Attribution Record", ["Attribution Record ID", "Source Record Type", "Source Transaction",
                                          "Source Account Asset Summary", "Attributed Amount"]),
            ("06", "Market & Client Dimensions", ["Distribution Channel", "Business Line", "Service Offering",
                                                  "Covering Advisor", "Advisor Coverage Assignment", "Client Household",
                                                  "Attributed Campaign", "Campaign Attribution Weight"]),
            ("06", "Reporting Period", ["Reporting Period ID", "Period Type", "Final Close Date"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type", "As-Of Date", "Supersedes Snapshot", "Approved By"]),
            ("06", "Restatement", ["Restatement ID", "Restatement Reason", "Affected Periods", "Net Impact Amount",
                                   "Compensation Impact Indicator", "Restatement Approved By"]),
            ("09", "Reporting Period Definition", ["Reporting Period Definition Code", "Period Basis Calendar",
                                                   "As-Of Date Convention", "Business Day Convention"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("15", "Program Enrollment", ["Enrolled Account", "Enrolled Service Offering", "Enrollment Status",
                                          "Enrollment Effective Date", "Enrollment Termination Date"]),
            ("02", "Party", ["Party ID", "Party Type"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status", "Membership Effective From",
                                            "Membership Effective To"]),
            ("03", "Party Coverage Assignment", ["Coverage Assignment ID", "Covering Advisor", "Primary Coverage Indicator",
                                                 "Coverage Effective From", "Coverage Effective To"]),
            ("04", "Campaign", ["Campaign ID", "Campaign Status"]),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Type", "Source Money Movement"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("50", "Money Movement", ["Money Movement ID", "Money Movement Type"]),
            ("16", "Participant Balance", ["Balance Membership", "Valuation Date", "Balance Market Value"]),
            ("29", "Share Register Balance", ["Register Account", "Register Business Date", "Registered Shares"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Total IBOR Market Value"]),
        ],
        upstream=["DP-006", "DP-007", "DP-093", "DP-240", "DP-009", "DP-011", "DP-004", "DP-013", "DP-300", "DP-302",
                  "DP-430", "DP-580", "DP-142", "DP-094"],
        refresh="Daily",
        timeliness=("Flash values by 9am ET on T+1; preliminary month-end by business day 3 after month-end; Final (locked) by "
                    "business day 8 (Reporting Period Final Close Date); quarter and year from the locked months"),
        history=("Every locked snapshot (Snapshot Type Final and Restated) kept indefinitely with every superseded version and "
                 "restatement; flash and preliminary snapshots kept 25 months; measure definition and treatment rule versions "
                 "kept by version"),
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Dashboard"],
        dq_rules=[
            "Every Measure resolves to a Measure Definition with Certified Indicator = Y, and every Dimension Key resolves for its Dimension Type: Channel and Business Line to their code lists, Advisor to an active DP-009 advisor, Campaign to a DP-011 campaign, Share Class to DP-004 and Segment to the DP-240 segmentation scheme.",
            "Measure Definition and Flow Treatment Rule versions of one Measure ID do not overlap in effect, and the Account Channel Assignment periods applied do not overlap, so each account has one channel on each date.",
            "Ending Client Assets at Dimension Type Total equals the sum over Channel and over Holding Type (the semi-additive measures; the three counts are distinct counts and are tested against a recount at Total instead); Net New Assets at Total equals the DP-006 Client Asset Flow Amount (Pre-Treatment) of the period less the rows the Flow Treatment Rule excludes, within USD 1.00; Net Inter-Channel Transfers at Total is zero; Beginning equals the prior locked Ending; and Ending Client Assets per source book ties to the DP-007 summaries and the 49, 16, 29 and 18 book totals within USD 1.00.",
            "Every Measure Value has Measure, Period End Date, Dimension Type, Dimension Key, Measure Amount, Data Basis and Snapshot; unattributed amounts are carried in suspense with Attributed Share %, never dropped; and each Omnibus Residual Amount enters a measure once per Omnibus Parent Account x Share Class x Valuation Date.",
            "Values at Dimension Type Advisor and Campaign are restricted views for the advisor of record, their management and client and channel analytics; the wide audience receives Total, Channel, Holding Type, Business Line, Share Class and Segment rows, and a Segment row covering fewer than 10 households is suppressed; no account-level row is published.",
            "A Final snapshot changes only through a Restatement with Restatement Approved By, the month is Final by business day 8, and no measure of this product subtracts Own-Fund Overlap Amount or adds Firm AUM.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Flow & Client Asset Measure Definition (06, MSR-) and Snapshot (locked "
               "month-end) (06, SNP-); source of the Measure Value, Reporting Period and Snapshot entities of the SM-20 conformed set. "
               "Certified numbers (CW-011, CW-142, CW-203): Ending Client Assets, Beginning Client Assets, Average Client "
               "Assets, Net New Assets, Advised Assets, Client Market Movement and Other, Net Inter-Channel Transfers, Client "
               "Organic Growth Rate, Own-Fund Overlap Amount (reported, never netted here), Client Assets Excluding "
               "Intermediary-Held, Gross Sales, Redemptions, Net Flows, Funded Accounts, Clients and Households, named exactly "
               "as semantic_model/register.CERTIFIED_WEALTH reads them (SM-20 at WP2); defined here only. Firm AUM is DP-241's; "
               "the two families are reconciled there and never summed. Counts are published as 06 Measure Values of "
               "MSR-FUNDEDACCOUNTS, MSR-CLIENTS and MSR-HOUSEHOLDS (lead ruling), from DP-093 accounts and DP-240 parties and "
               "households (participants of recordkept plans included through 16 Participant Plan Membership, read through "
               "DP-094). The three counts are distinct counts (Aggregation Behavior Non-Additive): channel and segment values "
               "do not add to Total. The 06 Asset Measures attributes (Beginning AUM, Ending AUM, Market Movement, Average "
               "AUM, Organic Growth Rate) stay as inputs under their 06 names (an own-fund view by channel that 06 keeps for "
               "its readers); no measure is published from them, and no measure of this product is named AUM. PII tier: financial (account and flow rows are read; outputs are aggregates, with advisor (EMP-) "
               "and campaign rows as restricted views). Boundaries: NNA by advisor, campaign and offering for decisions is DIS "
               "DP-491 and DP-492; client asset supply chain and suspense DIS DP-495; rollover capture DP-467; revenue yield on "
               "Average Client Assets DP-497. Convention: DP-302 is upstream because Net New Assets reads the 50 Money Movement "
               "keys behind 49 Client Account Activity Source Money Movement (lineage only, never a flow). "
               "Acceptance question 1 (plan section 8.5): answered by Ending Client Assets by Channel and Holding Type; "
               "mastering domains 06, 49, 16, 29 and 18 (27 and 46 through DP-241). "
               "Acceptance question 2: feeds DP-491 and DP-492 with Net New Assets at Dimension Type Channel, Advisor and "
               "Campaign; its uses reach 06, 03, 04, 49 and 50. Acceptance question 10: feeds DP-467 with Net Inter-Channel "
               "Transfers. "
               "Tailoring lever: NNA flow treatment rule. Reference default: income and fees excluded, firm-plan to firm-IRA "
               "rollovers inter-channel, same-owner transfers excluded firm-wide (CW-142; 06 SME questions 1 and 2). Tailoring "
               "lever: Advised Assets scope. Reference default: fee-based advice, managed and trust enrollments; planning-only "
               "clients, participant managed accounts and IA mandates excluded (06 SME question 6). Tailoring lever: "
               "self-directed-to-advice enrollment. Reference default: inter-channel transfer only, no separate advice "
               "conversion measure (06 SME question 7). Tailoring lever: own-fund overlap scope. Reference default: own funds "
               "in every channel; the advisory-slice overlap is handled in DP-241 (06 SME question 8). Tailoring lever: stored "
               "cross-tabs. Reference default: one dimension per Measure Value row; cross-tabs come from the flow and summary "
               "rows. Tailoring lever: workplace participants in Clients and Households. Reference default: counted (CW-011 "
               "counts every client of the firm, including participants of recordkept plans); lever: owners of 15 non-plan "
               "accounts only. Tailoring lever: short sale proceeds in client cash. Reference default: counted, under DP-007's "
               "client cash rule. "
               "Taxonomy gap: 06 Client Asset Measures has no Funded Accounts, Clients or Households attribute; the counts are "
               "Measure Values whose Measure Amount is typed as a USD amount. Taxonomy gap: 06 Measure Value has no household "
               "Dimension Type, so household Client Assets come from DP-007 rows (DP-320). "
               "Drafting assumptions: the Measure IDs MSR-FUNDEDACCOUNTS, MSR-CLIENTS and MSR-HOUSEHOLDS; the owner Account "
               "Role Types (Primary Owner, Joint Owner, Inherited IRA Owner); Role Types Client and Plan Participant; "
               "Membership Status Active; the USD 1.00 tolerance; the 10-household minimum cell; business days 3 and 8. "
               "Decisions: CW-007, CW-011, CW-140, CW-141, CW-142, CW-143, CW-203, CW-209, CD-041. "
               "WP1 re-scope (CW-203): renamed Client Assets & Net New Assets; owning domain 06 unchanged; upstream DP-001 "
               "dropped, DP-093, DP-240, DP-009, DP-011, DP-300, DP-302, DP-430, DP-580, DP-142 and DP-094 added; inputs 06 "
               "Distributor Hierarchy dropped, Client Asset Measures, Account Asset Summary, Fund Shareholder Position, Account "
               "Channel Assignment and the flow attributes added, with the 15, 16, 01, 02, 03, 04, 49, 50, 29 and 18 attributes "
               "the certified chains trace to. The wholesale DP-008 published Ending, Beginning and Average AUM, Market "
               "Movement and Organic Growth Rate as Asset Measures attributes and measures; the certified client asset "
               "measures replace them: Ending AUM by 'Ending Client Assets', Beginning AUM by 'Beginning Client Assets', "
               "Average AUM by 'Average Client Assets', Market Movement by 'Client Market Movement and Other', Organic Growth "
               "Rate by 'Client Organic Growth Rate'. Readers to re-point (full list in the module NOTES): SM-01 metrics and "
               "CERTIFIED 'Ending AUM', 'Beginning AUM', 'Average AUM', 'Market Movement' and 'Organic Growth Rate' must "
               "re-point to these DP-008 measure names as a stopgap until SM-20 (the 06 Asset Measures attributes stay as "
               "inputs, so sm_model will not flag the rename by itself); SM-01 flows_aum facts beginning_aum, ending_aum, "
               "average_aum and market_movement; specs DP-242 'Flows and Attributed AUM (from DP-008)' (and SM-06 through it), "
               "DP-243 'Attributed AUM and Net Flows (from DP-008)', DP-245 'Flow & Attributed AUM Values (from DP-008)', "
               "DP-105 'Realized vs Projected AUM %' and DP-108 'Affected Attributed AUM' (which also reads 06 Distributor "
               "Hierarchy). Kept by name: Gross Sales, Redemptions, Net Flows, Restatement Impact (SM-01); 'Net Exchanges' is "
               "new as a measure (the wholesale DP-008 held it as an attribute; SM-01 reads it). 'Attributed AUM' as read by "
               "the wholesale DP-241 is not published; DP-241 now reads Ending Client Assets and Own-Fund Overlap Amount. "
               "Dimension 'Distributor firm / office / team / advisor' dropped (SM-01 'Distributor Firm' rows of flows_aum "
               "re-point to DP-001 or drop); 'Reporting period' and 'Product and share class' gain their source products "
               "(DP-013, DP-004). Measures added that SM-01 (until SM-20) must publish or exclude: every measure except Gross "
               "Sales, Redemptions, Net Flows, Net Exchanges and Restatement Impact. Entities Measure Value, Measure Definition, Reporting Period, Snapshot and "
               "Restatement keep their objects. The specs_00_reference.py wholesale entry is superseded; CONTRACT.md's worked "
               "example pointer moves here (lead ruling 2026-10-16). W4 stage text (CW-141, CW-143) is superseded."
               " WP2 retirement sweep (CW-209): SM-01 and SM-06, named above as readers, are retired and their definition files deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-165": dict(
        definition=("The official, approved NAV of every fund and share class by valuation date - total and class net assets, "
                    "NAV per share, swung and market-based NAV, shares outstanding and CIT unit values - with its release, "
                    "the Rule 18f-3 class allocation behind it, fund expense and waiver accruals and the fund's audited "
                    "statement sets and financial highlights. It publishes the 27 concepts Share Class NAV (NAV-), Fund NAV "
                    "Calculation and NAV Dissemination of CONCEPT_OWNERSHIP (CD-187, CD-207) without remastering them. It is "
                    "the only source of the certified NAV per share, total and class net assets, shares outstanding and fund "
                    "expense ratios (CD-293, CD-330), all taken from the NAV of record, and it publishes month-end fund net "
                    "assets at NAV as the input from which DP-241 certifies the own funds slice of Firm AUM; it no longer "
                    "certifies Firm AUM."),
        business_questions=[
            "What is the NAV of record of each fund and share class today - net assets, NAV per share, swung NAV and shares outstanding - and from which calculation source and version?",
            "What are month-end fund net assets at NAV by fund, vehicle type and business line, the input DP-241 certifies Firm AUM from?",
            "When was each NAV released, which releases were corrected, and which funds released late?",
            "What are each share class's trailing twelve-month gross and net expense ratios, and its audited ratios from the last annual report?",
            "Do class net assets sum to fund net assets, and do audited statement net assets agree with the NAV of record at fiscal year-end?",
        ],
        grain=("Share class x fund NAV calculation (fund accounting book x valuation date x NAV calculation source x NAV "
               "version), flagged for the NAV of record; with fund-level NAV calculation, class allocation, NAV release, "
               "expense and waiver accrual (share class x type x accrual date) and financial statement set x share class as "
               "companion facts; month-end fund net assets at fund x month-end"),
        dimensions=["Fund (investment product)", "Share class", "Fund accounting book and accounting basis", "Valuation date",
                    "NAV calculation source", "NAV version and version type", "Fund accounting operating model and administrator",
                    "Vehicle type", "Business line", "Currency", "Expense type", "Waiver type", "Fiscal period", "Data basis"],
        measures=[
            ("NAV of Record Flag", "Y for the Fund NAV Calculation with NAV Approval Status = Approved and the highest NAV Version Number per NAV Book and Valuation Date among rows whose NAV Calculation Source is the official source of the book's Fund Book Operating Period on that date (Fund Accounting when Fund Accounting Operating Model is In House; Administrator when it is Outsourced to Administrator, Outsourced with Shadow NAV or Trustee Bank). Firm Shadow rows are never the NAV of record (CD-330).",
             _u("27", "Fund NAV Calculation", "NAV Approval Status", "NAV Version Number", "NAV Calculation Source", "NAV Book",
                "Valuation Date")
             + _u("27", "Fund Book Operating Period", "Operated Book", "Fund Accounting Operating Model",
                  "Operating Period Effective From", "Operating Period Effective To")),
            ("Fund Total Net Assets", "Fund Net Assets Amount of the NAV of record, in the Book Reporting Currency; certified (CD-330).",
             _u("27", "Fund NAV Calculation", "Fund Net Assets Amount") + _u("27", "Fund Accounting Book", "Book Reporting Currency")
             + ["NAV of Record Flag"]),
            ("Class Net Assets", "Class Net Assets Amount of the Share Class NAV whose Parent NAV Calculation is the NAV of record; certified (CD-330).",
             _u("27", "Share Class NAV", "Class Net Assets Amount", "Parent NAV Calculation") + ["NAV of Record Flag"]),
            ("NAV per Share", "NAV per Share (and Swung NAV per Share where a swing was applied) of the Share Class NAV of the NAV of record, in NAV Currency; certified (CD-330).",
             _u("27", "Share Class NAV", "NAV per Share", "Swung NAV per Share", "NAV Currency") + ["NAV of Record Flag"]),
            ("Shares Outstanding", "Shares Outstanding of the Share Class NAV of the NAV of record; certified (CD-330).",
             _u("27", "Share Class NAV", "Shares Outstanding") + ["NAV of Record Flag"]),
            ("Month-End Fund Net Assets at NAV",
             "Per fund and month-end: Fund Total Net Assets of the NAV of record at the month-end valuation date (or the last valuation date on or before it), in the Book Reporting Currency, with the fund's Vehicle Type, Business Line, Master-Feeder Role and Fund of Funds Indicator so that DP-241 can apply the Firm AUM slice rules (feeder exclusion, fund-of-funds gross count). An input to Firm AUM, not Firm AUM and not certified as such here.",
             _u("01", "Fund Legal Structure", "Master-Feeder Role", "Fund of Funds Indicator")
             + _u("01", "Investment Product", "Product ID", "Vehicle Type")
             + _u("27", "Fund Accounting Book", "Book Fund", "Business Line", "Book Reporting Currency")
             + ["Fund Total Net Assets"]),
            ("Net and Gross Expense Ratio (Trailing)", "Gross: sum over the trailing 12 months of Accrued Expense Amount for the share class plus its Allocated Amount of fund-level accruals (Class Allocation of the same valuation date), divided by the average of daily Class Net Assets over the same days. Net: the same numerator less Waived Fee Amount and Reimbursed Expense Amount of the class. Both annualized; certified (CD-330).",
             _u("27", "Fund Expense Accrual", "Accrued Expense Amount", "Accrual Share Class", "Accrual Fund", "Expense Accrual Date")
             + _u("27", "Class Allocation", "Allocated Amount", "Allocation Share Class", "Class Allocation Item")
             + _u("27", "Expense Cap & Waiver Accrual", "Waived Fee Amount", "Reimbursed Expense Amount", "Waiver Share Class",
                  "Waiver Accrual Date") + ["Class Net Assets"]),
            ("Audited Gross and Net Expense Ratio", "Highlights Gross Expense Ratio and Highlights Net Expense Ratio of the share class from the latest Fund Financial Statement with Audited Indicator = Y and Statement Approval Status = Approved; certified (CD-330).",
             _u("27", "Financial Highlights", "Highlights Gross Expense Ratio", "Highlights Net Expense Ratio", "Highlights Share Class")
             + _u("27", "Fund Financial Statement", "Audited Indicator", "Statement Approval Status", "Statement Period End Date")),
            ("Class Net Assets Tie-Out", "Fund Total Net Assets - sum of Class Net Assets over the classes of the NAV of record, and Class Net Assets Amount - NAV per Share x Shares Outstanding per class; each flagged beyond one unit of the class's NAV rounding.",
             _u("27", "Share Class NAV", "Class Net Assets Amount", "NAV per Share", "Shares Outstanding")
             + ["Fund Total Net Assets", "Class Net Assets"]),
            ("NAV Release Timeliness", "Share class NAVs of record with a NAV Dissemination of NAV Release Status = Released and Release Timestamp by 6pm ET on the valuation date (US funds) / all share class NAVs of record due; corrected releases (Corrected Release Indicator = Y) counted separately.",
             _u("27", "NAV Dissemination", "Released NAV", "NAV Release Status", "Release Timestamp", "Corrected Release Indicator")
             + ["NAV of Record Flag"]),
            ("Statement Net Assets Tie-Out", "Statement Net Assets - Fund Total Net Assets of the NAV of record at Statement Period End Date, for every audited statement set; flagged when not zero.",
             _u("27", "Fund Financial Statement", "Statement Net Assets", "Statement Period End Date", "Statement Book")
             + ["Fund Total Net Assets"]),
        ],
        inputs=[
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number", "NAV Version Type",
                                            "NAV Status", "Total Assets Amount", "Total Liabilities Amount", "Fund Net Assets Amount",
                                            "Capital Activity Data Basis", "NAV Approval Status"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share", "Class Net Assets Amount",
                                       "Shares Outstanding", "NAV Currency", "Offer Price", "Swung NAV per Share",
                                       "Applied Swing Decision", "Market-Based NAV per Share"]),
            ("27", "CIT Unit Value Detail", ["CIT Valuation Basis", "Admission and Withdrawal Date Indicator"]),
            ("27", "Class Allocation", ["Allocation NAV Calculation", "Allocation Share Class", "Class Allocation Item", "Class Allocation Method",
                                        "Allocation Ratio", "Allocation Basis Amount", "Allocated Amount"]),
            ("27", "NAV Dissemination", ["Released NAV", "Release Sequence", "Release Timestamp", "NAV Release Status", "Corrected Release Indicator",
                                         "Corrected Release"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Accounting Basis", "Book Code", "Business Line", "Book Reporting Currency", "Book Status"]),
            ("27", "Fund Book Operating Period", ["Operated Book", "Fund Accounting Operating Model", "Fund Administrator of Record",
                                                  "Operating Period Effective From", "Operating Period Effective To"]),
            ("27", "Fund Financial Statement", ["Statement Book", "Statement Period End Date", "Statements Included", "Audited Indicator",
                                                "Statement Auditor", "Statement Net Assets", "Statement Approval Status"]),
            ("27", "Financial Highlights", ["Highlights Share Class", "Beginning NAV per Share", "Net Investment Income per Share", "Net Gain per Share",
                                            "Ending NAV per Share", "Total Return", "Highlights Gross Expense Ratio", "Highlights Net Expense Ratio",
                                            "Portfolio Turnover Rate"]),
            ("27", "Fund Expense Accrual", ["Accrual Fund", "Accrual Share Class", "Expense Accrual Date", "Accrual Expense Type", "Applied Fee Schedule",
                                            "Fee Rate Applied", "Accrual Basis Amount", "Accrued Expense Amount", "Accrued Expense Balance"]),
            ("27", "Expense Cap & Waiver Accrual", ["Waiver Share Class", "Waiver Accrual Date", "Waiver Type", "Expense Cap Rate Applied",
                                                    "Waived Fee Amount", "Reimbursed Expense Amount", "Recoupable Balance"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Vehicle Type", "Base Currency", "Fiscal Year End"]),
            ("01", "Fund Legal Structure", ["Master-Feeder Role", "Master Fund", "Fund of Funds Indicator"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Type", "Share Class Currency", "Share Class Status"]),
        ],
        upstream=["DP-166", "DP-143", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness=("NAV of record by 6:30pm ET on the valuation date for US daily-dealing funds; month-end fund net assets at "
                    "NAV by business day 3 after month-end; trailing expense ratios by business day 5 after month-end; audited "
                    "ratios when the annual report is approved"),
        history=("Every NAV calculation version, share class NAV and release kept for 10 years (Rule 31a-2), with superseded "
                 "versions; month-end fund net assets locked and kept indefinitely with restatements; statement sets kept "
                 "indefinitely"),
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract", "Regulatory report"],
        dq_rules=[
            "Every Fund Accounting Book has exactly one Fund Book Operating Period effective on every valuation date, and every NAV Share Class resolves to an active Share Class in DP-004 whose Parent Product is the Book Fund.",
            "Exactly one Fund NAV Calculation per NAV Book and Valuation Date carries the NAV of Record Flag, it has NAV Status = Final, and its NAV Calculation Source is never Firm Shadow.",
            "The sum of Class Net Assets Amount over the share classes of a NAV calculation equals its Fund Net Assets Amount, Fund Net Assets Amount = Total Assets Amount - Total Liabilities Amount, and Class Net Assets Amount = NAV per Share x Shares Outstanding within one unit of the class's NAV rounding.",
            "Month-End Fund Net Assets at NAV is published for every fund with a NAV of record at the month-end, each with its Master-Feeder Role and Fund of Funds Indicator populated.",
            "Statement Net Assets of every audited statement set equals the Fund Net Assets Amount of the NAV of record at Statement Period End Date.",
            "The NAV of record is published by 6:30pm ET on the valuation date, and a locked month-end fund net assets value changes only through a recorded restatement that DP-241 picks up as a new version of the month.",
        ],
        notes=("Master concepts: Share Class NAV (NAV-), Fund NAV Calculation and NAV Dissemination, 27 (CD-187, CD-207). "
               "Certified numbers (CD-293, CD-330): Fund Total Net Assets, Class Net Assets, NAV per Share, Shares Outstanding, "
               "Net and Gross Expense Ratio (trailing twelve months, accrual basis) and Audited Gross and Net Expense Ratio, "
               "defined here only. Firm AUM and its slices are certified in DP-241 (lead ruling 2026-10-15, CW-011, CW-206): "
               "this product publishes Month-End Fund Net Assets at NAV, from which DP-241 takes the own funds slice. The 01 "
               "prospectus ratio (Cost Disclosure) stays a disclosure in DP-004. Financial Highlights Total Return is published "
               "as held but is not certified here until CD-217 is decided (option A reads it from DP-145). Feeder, tender-offer "
               "and interval funds that strike a NAV in 27 publish their NAV of record (CW-166). Operating model (CD-297, "
               "CD-331): in house the source is the fund accounting platform. If an administrator keeps the book the grain is "
               "unchanged and the official NAV Calculation Source becomes Administrator, as Fund Book Operating Period records "
               "per book and period, so a mixed range is rows, not products. A Trustee Bank book is treated as Administrator "
               "sourced (27 SME question 1). Firm Shadow rows are published only to DP-168. PII tier: none (fund-level data; "
               "NAV Approved By is not read). Boundaries: the fund share register (DP-580) and participant balances (DP-430) "
               "read NAV per Share from here; DP-165 never lists them. Dependency direction (CD-321): depends on DP-143 for the "
               "prices behind the NAV; DP-143 never lists this product. Fund and share class dimensions from DP-004; 01 Fund "
               "Legal Structure is read directly for Master-Feeder Role and Fund of Funds Indicator (rule 2). Fund Accounting "
               "Book Business Line (Derived copy, 18) and Book Reporting Currency (Derived copy, 01) are read as held on the "
               "book, because they are the book's own slicing and reporting attributes. "
               "Acceptance question 1 (plan section 8.5): feeds DP-241 with Month-End Fund Net Assets at NAV (27). "
               "The fund-of-funds netting lever is DP-241's (CD-292 ruling 2026-10-14). Tailoring lever: shares outstanding master. Reference default: fund "
               "accounting, tied to the 29 register by DP-181 (27 SME question 3). Tailoring lever: certified expense ratio "
               "basis. Reference default: accrual basis, trailing twelve months. "
               "Taxonomy gap: no attribute holds a fund's NAV release deadline; NAV Release Timeliness uses 6pm ET for US funds "
               "until 01 Dealing Terms or 27 records it. "
               "Drafting assumptions: 6pm ET release and 6:30pm ET publication; business days 3 and 5. "
               "Decisions: CD-187, CD-188, CD-207, CD-217, CD-292, CD-293, CD-297, CD-321, CD-330, CD-331, CW-011, CW-166, "
               "CW-206. W4 re-point (CW-930, CW-166, CW-011): the 30 inputs (Investor Commitment, Investor Capital Account, "
               "Capital Call, Capital Call Allocation, Distribution, Distribution Allocation) dropped, no successor (30 "
               "retires), with the measure Private Fund Net Assets and DP-116 and DP-117 upstream. W2 re-point (CW-051): 27 Fund "
               "Expense Accrual.Applied Fee Schedule is typed Reference (Management Fee, 01), the fund fee terms (Fund Fee "
               "Schedule, FSCH-) that stay in 01; it is not the 47 client Fee Schedule (CLFEE-). W1b: Share Class NAV.Bid Price "
               "dropped, no successor (CW-927). "
               "WP1 re-scope (CW-206, CW-011; lead ruling 2026-10-15): Firm AUM moves to DP-241. Drops measure 'Firm AUM' "
               "(successor DP-241 'Firm AUM'; read by SM-11 metric Firm AUM and CERTIFIED 'Firm AUM' (SM-11, DP-165), and by the "
               "wholesale DP-241 'Firm AUM (from DP-165)') and measure 'Mandate & SMA Market Value' (successor DP-241 'Firm AUM "
               "Institutional Slice'; read by SM-11 metric Mandate & SMA Market Value and the wholesale DP-241 'Mandate & SMA "
               "Slice (from DP-165)'); adds 'Month-End Fund Net Assets at NAV'; the business question on Firm AUM and DQ rule 5 "
               "are rewritten; inputs 18 Portfolio, Portfolio Implementation Link, Portfolio Valuation Summary, Portfolio "
               "Holding and Holding Valuation, 17 Instrument and 22 FX Rate Observation dropped (they served only the Firm AUM "
               "slices and translation, now DP-241's) and upstream DP-140 and DP-142 dropped. Every other measure name, "
               "dimension name and input is kept. Readers of the dropped 'Firm AUM' still to re-point: DP-245 'Fund Metric Values "
               "(from DP-165)' (names Firm AUM) and DP-204 (definition, business question, DQ rule and notes treat Firm AUM as "
               "DP-165's); re-point both to DP-241. Re-cut for the lineage pass: the DP-165 logical model "
               "(models_e8_book_of_record) still holds 18 Portfolio, Portfolio Implementation Link, Portfolio Valuation "
               "Summary, Portfolio Holding, Holding Valuation, 17 Instrument and 22 FX Rate Observation; drop them. SM-11 must "
               "publish or exclude the new measure Month-End Fund Net Assets at NAV. Owning domain 27 and tier unchanged. "
               "Register-row mismatch for the lead (not changed here): the supporting functions still include FN-15 and FN-12, "
               "and the FOP+CORP RESPEC asks for a re-point to FN-77, FN-78, FN-72 and FN-36."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-012": dict(
        definition=("The firm's certified client fee revenue (CW-011, CW-204): revenue recognized per client account, or per "
                    "47 Fee Household, per revenue stream and month on the 10 Client Revenue Record (advisory, wrap, planning, "
                    "subscription, account service, recordkeeping, trust and OCIO fees, with commissions and markups, margin "
                    "interest, fully paid lending and bank sweep fees beside them), and the own-fund management fee revenue "
                    "per share class on the 10 Fee Revenue Record after fund-level waivers, with the intermediary channel's "
                    "distribution revenue. Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate are certified "
                    "(CW-011) and defined only here; each stream carries its principal-versus-agent conclusion, and every "
                    "client row ties to the billed amounts DP-305 publishes from 47, which never publishes recognized "
                    "revenue. It publishes the CONCEPT_OWNERSHIP rows Client Revenue Record (10, CLREV-) and Fee Revenue "
                    "Record (10, FRR-), applies recognition once and reconciles to the general ledger (DP-191)."),
        business_questions=[
            "What were gross and net fee revenue and the effective net fee rate by offering, channel, business line and share class last quarter?",
            "How much client fee revenue did each household and client segment generate, and on which fee schedules?",
            "Does recognized client revenue tie to what 47 billed, debited and adjusted, and does bank sweep revenue tie to the cash program economics?",
            "Which streams are presented gross (principal) and which net (agent), and how much was passed through to sub-advisers and intermediaries?",
            "Does revenue by management P&L line reconcile to the GL for each legal entity and closed period, and which reconciliation controls are still open?",
        ],
        grain=("Client Revenue Record (account or 47 Fee Household x revenue stream x fiscal period) and Fee Revenue Record "
               "(own-fund share class x fiscal period) as the main outputs, with performance fee, distribution revenue, cash "
               "program economics (sweep program x program bank x period) and waiver records and reconciliation controls as "
               "companion facts; closed periods final, estimated versions kept until superseded"),
        dimensions=["Accounting period (fiscal)", "Client account (DP-093)", "Client household (DP-240)",
                    "Fee household (DP-305)", "Revenue type and stream", "Service offering (DP-004)",
                    "Product and share class / mandate", "Distribution channel", "Business line", "Client segment",
                    "Receiving legal entity", "Principal or agent conclusion", "Sweep program and program bank (DP-431)",
                    "Revenue contract and identified customer", "Management P&L line", "Data basis (estimated / final)",
                    "Reconciliation type and status"],
        measures=[
            ("Gross Fee Revenue",
             "Certified (CW-011). For the fiscal period: Recognized Revenue Amount of Client Revenue Records whose Client Revenue Stream is a fee stream (Advisory Fee, Wrap Fee, Planning Fee, Subscription Fee, Account Service Fee, Recordkeeping Fee, Trust Fee, OCIO Fee, Mandate Performance Fee), plus Gross Fee Revenue of Fee Revenue Records (own-fund management fees before fund-level waivers); by Revenue Service Offering, Revenue Channel, Revenue Business Line and share class. Client rows are recognized at the 47 net fee (after discounts, waivers and own-fund credits).",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Client Revenue Stream", "Client Revenue Period",
                "Recognized Revenue Amount", "Revenue Service Offering", "Revenue Channel", "Revenue Business Line")
             + _u("10", "Fee Revenue Record", "Fee Revenue Record ID", "Revenue Share Class / Mandate",
                  "Revenue Accounting Period", "Gross Fee Revenue")
             + _u("09", "Fiscal Period", "Fiscal Period ID")),
            ("Client Fee Revenue",
             "The client fee slice of Gross Fee Revenue, published read-only for consumers (DP-598): Recognized Revenue Amount of Client Revenue Records whose Client Revenue Stream is a 47 client fee stream (Advisory Fee, Wrap Fee, Planning Fee, Subscription Fee, Account Service Fee, Recordkeeping Fee, Trust Fee, OCIO Fee, Mandate Performance Fee) for the fiscal period, by Revenue Service Offering, Revenue Channel and Revenue Business Line; own-fund management fees (10 Fee Revenue Record) are excluded. Gross Fee Revenue = Client Fee Revenue + the Fee Revenue Record Gross Fee Revenue; not a separate certified family.",
             _u("10", "Client Revenue Record", "Client Revenue Record ID", "Client Revenue Stream", "Client Revenue Period",
                "Recognized Revenue Amount", "Revenue Service Offering", "Revenue Channel", "Revenue Business Line")
             + _u("09", "Fiscal Period", "Fiscal Period ID") + ["Gross Fee Revenue"]),
            ("Net Fee Revenue",
             "Certified (CW-011). Gross Fee Revenue - Waiver and Reimbursement Offset of the Fee Revenue Records: client fee streams as recognized plus the Net Fee Revenue of each Fee Revenue Record.",
             _u("10", "Fee Revenue Record", "Waiver and Reimbursement Offset", "Net Fee Revenue") + ["Gross Fee Revenue"]),
            ("Effective Net Fee Rate",
             "Certified (CW-011), one denominator: annualized Recognized Revenue Amount of the asset-based client fee streams (Client Revenue Stream Advisory Fee, Wrap Fee, OCIO Fee, Trust Fee, Recordkeeping Fee) / the average Billable Assets of the 47 Account Fee Calculations named in their Source Calculation Record whose Fee Calculation Run billing period falls in the fiscal period (from DP-305), by offering, channel and business line; a row and its roll-ups always use this basis. Own-fund management fee rates are Fund Effective Net Fee Rate, never blended into this ratio; neither is computed over Client Assets or Firm AUM here.",
             _u("10", "Client Revenue Record", "Source Calculation Record", "Client Revenue Stream", "Recognized Revenue Amount")
             + _u("47", "Account Fee Calculation", "Billable Assets", "Calculation Run")
             + _u("47", "Fee Calculation Run", "Run Billing Period Start", "Run Billing Period End")),
            ("Fund Effective Net Fee Rate",
             "Per own-fund share class and fiscal period: annualized Net Fee Revenue of the Fee Revenue Record / its Fee Basis Average Assets (the 10 Effective Net Fee Rate attribute); the fund view the wholesale Effective Net Fee Rate published, never blended with the client rate.",
             _u("10", "Fee Revenue Record", "Fee Basis Average Assets", "Effective Net Fee Rate", "Net Fee Revenue",
                "Revenue Share Class / Mandate")),
            ("Client Transaction and Interest Revenue",
             "Recognized Revenue Amount of Client Revenue Records with Client Revenue Stream Commission, Markup / Markdown, Margin Interest, Fully Paid Lending Revenue, Bank Sweep Fee or Order Routing Payment, by stream and Recognizing Legal Entity; client revenue that is not fee revenue.",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Recognized Revenue Amount", "Recognizing Legal Entity")),
            ("Client Fee Revenue by Household",
             "Client fee-stream Recognized Revenue Amount rolled to the 02 Client Household: account rows through the owner Account Party Role of the account and the 02 Household Membership effective at the period end; Fee Household rows through the Anchor Client Household of the 47 Fee Household. The grouping reported is the 02 household; the 47 fee group is only the route for fee-household-grain rows. By Client Segment at Period End.",
             _u("10", "Client Revenue Record", "Revenue Account / Household", "Recognized Revenue Amount",
                "Client Segment at Period End")
             + _u("47", "Fee Household", "Fee Household ID", "Anchor Client Household")
             + _u("15", "Account Party Role", "Role Account", "Role Party", "Account Role Type")
             + _u("02", "Household Membership", "Household", "Household Member", "Membership Effective From",
                  "Membership Effective To")),
            ("Fee Revenue as Presented",
             "Per Revenue Stream, Gross Fee Revenue presented under its Stream Principal vs Agent Conclusion: Principal streams gross, with Sub-Advisory Fee Payable and distribution Amount Passed Through as expense; Agent streams net of them; Distribution Revenue Records follow their own Principal vs Agent Conclusion.",
             _u("10", "Performance Obligation", "Revenue Stream", "Stream Principal vs Agent Conclusion")
             + _u("10", "Distribution Revenue Record", "Principal vs Agent Conclusion", "Amount Passed Through")
             + _u("10", "Fee Revenue Record", "Sub-Advisory Fee Payable") + ["Gross Fee Revenue"]),
            ("Billed to Recognized Variance",
             "Per account or Fee Household, stream and fiscal period: Recognized Revenue Amount - the sum of the 47 amounts named in Source Calculation Record (Account Fee Calculation Net Fee, Fee Invoice Invoice Total, Fee Debit Debit Amount of Fee Debit Status Posted, Fee Adjustment Adjustment Amount Value), read through DP-305; zero expected.",
             _u("10", "Client Revenue Record", "Source Calculation Record", "Recognized Revenue Amount")
             + _u("47", "Account Fee Calculation", "Net Fee") + _u("47", "Fee Invoice", "Invoice ID", "Invoice Total")
             + _u("47", "Fee Debit", "Fee Debit ID", "Debit Amount", "Fee Debit Status")
             + _u("47", "Fee Adjustment", "Fee Adjustment ID", "Adjustment Amount Value")),
            ("Client Fee Reductions Billed (from DP-305)",
             "Discount Amount + Waiver Amount Applied + Own-Fund Credit Amount of the Account Fee Calculations of the period's fee calculation runs, as DP-305 publishes them: the reductions already netted from recognized client fees.",
             _u("47", "Account Fee Calculation", "Discount Amount", "Waiver Amount Applied", "Own-Fund Credit Amount", "Gross Fee")),
            ("Waiver Cost",
             "Sum of Waived Fee Amount + Reimbursed Expense Amount on Waiver Records, by Waiver Type and Supported Share Class.",
             _u("10", "Waiver Record", "Reimbursed Expense Amount", "Waived Fee Amount", "Waiver Type", "Supported Share Class")),
            ("Gross Distribution Revenue",
             "Sum of Gross Distribution Revenue by Distribution Revenue Type (12b-1 fees of intermediary channel share classes) and Paying Share Class.",
             _u("10", "Distribution Revenue Record", "Gross Distribution Revenue", "Distribution Revenue Type", "Paying Share Class")),
            ("Net Distribution Revenue Retained",
             "Gross Distribution Revenue - Amount Passed Through, by distribution revenue type.",
             _u("10", "Distribution Revenue Record", "Gross Distribution Revenue", "Distribution Revenue Type",
                "Amount Passed Through")),
            ("Cash Program Revenue",
             "Program Bank Fee Earned per Economics Sweep Program, Economics Program Bank and Economics Period, with Average Swept Balance and Net Spread.",
             _u("10", "Cash Program Economics", "Economics Sweep Program", "Economics Program Bank", "Economics Period",
                "Program Bank Fee Earned", "Average Swept Balance", "Net Spread")),
            ("Bank Sweep Fee Allocation Tie-Out",
             "Sum of Recognized Revenue Amount of Client Revenue Records with Client Revenue Stream Bank Sweep Fee for the fiscal period - Cash Program Revenue for the same period.",
             _u("10", "Client Revenue Record", "Client Revenue Stream", "Recognized Revenue Amount", "Client Revenue Period")
             + ["Cash Program Revenue"]),
            ("Fee Basis Variance",
             "Fee Basis Average Assets - the average of daily Class Net Assets Amount of the NAV of record (NAV Approval Status Approved, highest NAV Version Number) of the same share class over the period's valuation dates (from DP-165), as a percentage of the latter.",
             _u("10", "Fee Revenue Record", "Fee Basis Average Assets", "Revenue Share Class / Mandate")
             + _u("27", "Share Class NAV", "NAV Share Class", "Class Net Assets Amount", "Parent NAV Calculation")
             + _u("27", "Fund NAV Calculation", "Valuation Date", "NAV Approval Status", "NAV Version Number")),
            ("Performance Fee Revenue Recognized",
             "Recognized Performance Fee Revenue of Performance Fee Records (fulcrum fee adjustments of own funds) where Constraint Assessment Outcome is Unconstrained (or Partially Constrained, up to the unconstrained amount), with Clawback Exposure Indicator; institutional performance fees are Client Revenue Records (Mandate Performance Fee).",
             _u("10", "Performance Fee Record", "Recognized Performance Fee Revenue", "Constraint Assessment Outcome",
                "Clawback Exposure Indicator", "Performance Fee Share Class / Mandate")),
            ("Ledger Tie-Out Variance",
             "For each closed fiscal period and legal entity: revenue by Management P&L Line (Client Revenue Records by Recognizing Legal Entity and Fee Revenue Records) - the sum of Posted Amount of GL Postings to the GL Natural Accounts mapped by Account Mapping in effect, in Journal Entries of that Posting Accounting Period and Posting Legal Entity, where Period Close Status is Hard Close or Permanently Closed.",
             _u("10", "Account Mapping", "Management P&L Line", "GL Natural Account", "Mapping Effective From", "Mapping Effective To")
             + _u("19", "GL Posting", "Journal ID", "Posted Account", "Posted Amount", "Source Finance Record")
             + _u("19", "Journal Entry", "Posting Accounting Period", "Posting Legal Entity")
             + _u("19", "Accounting Period Status", "Period Close Status")
             + _u("10", "Client Revenue Record", "Recognizing Legal Entity")),
            ("Reconciliation Control Completion %",
             "Control executions for the accounting period with Reconciliation Status Reconciled / all control executions for that period, by Reconciliation Type.",
             _u("10", "Control", "Reconciliation Status", "Reconciliation Type", "Control Period")),
        ],
        inputs=[
            ("10", "Client Revenue Record", ["Client Revenue Record ID", "Revenue Account / Household", "Client Revenue Stream",
                                             "Revenue Service Offering", "Client Revenue Period", "Source Calculation Record",
                                             "Recognized Revenue Amount", "Recognizing Legal Entity", "Revenue Channel",
                                             "Revenue Business Line", "Client Segment at Period End"]),
            ("10", "Fee Revenue Record", ["Fee Revenue Record ID", "Revenue Share Class / Mandate", "Revenue Accounting Period",
                                          "Fee Basis Average Assets", "Fee Basis Source", "Applied Gross Fee Rate",
                                          "Gross Fee Revenue", "Waiver and Reimbursement Offset", "Net Fee Revenue",
                                          "Effective Net Fee Rate", "Revenue Data Basis", "Sub-Advisory Fee Payable",
                                          "Sub-Adviser Engagement"]),
            ("10", "Revenue Contract", ["Revenue Contract ID", "Revenue Contract Type", "Identified Customer",
                                        "Customer Determination Basis", "Contracting Legal Entity", "Accounting Framework"]),
            ("10", "Performance Obligation", ["Performance Obligation Type", "Satisfaction Pattern", "Revenue Stream",
                                              "Stream Principal vs Agent Conclusion"]),
            ("10", "Performance Fee Record", ["Performance Fee Record ID", "Performance Fee Share Class / Mandate",
                                              "Crystallization Date", "Constraint Assessment Outcome",
                                              "Recognized Performance Fee Revenue", "Clawback Exposure Indicator"]),
            ("10", "Distribution Revenue Record", ["Distribution Revenue Type", "Receiving Entity", "Paying Share Class",
                                                   "Gross Distribution Revenue", "Amount Passed Through",
                                                   "Principal vs Agent Conclusion", "Trailing Fee Constraint Indicator"]),
            ("10", "Cash Program Economics", ["Economics Sweep Program", "Economics Program Bank", "Economics Period",
                                              "Average Swept Balance", "Program Bank Fee Earned", "Average Client Rate Paid",
                                              "Net Spread", "Money Market Sweep Fund Revenue"]),
            ("10", "Waiver Record", ["Waiver Record ID", "Waiver Type", "Supported Share Class", "Waived Fee Amount",
                                     "Reimbursed Expense Amount", "Waiver Accounting Treatment", "Recoupment Eligible Indicator",
                                     "Recoupment Expiry Date"]),
            ("10", "Account Mapping", ["Account Mapping ID", "Management P&L Line", "GL Natural Account",
                                       "Mapping Effective From", "Mapping Effective To"]),
            ("10", "Control", ["Reconciliation Type", "Control Period", "Reconciliation Status", "Control Reference"]),
            ("47", "Account Fee Calculation", ["Calculation Run", "Calculated Assignment", "Billable Assets", "Gross Fee",
                                               "Discount Amount", "Waiver Amount Applied", "Own-Fund Credit Amount", "Net Fee"]),
            ("47", "Fee Calculation Run", ["Fee Calculation Run ID", "Run Billing Period Start", "Run Billing Period End",
                                           "Run Status", "Fee Reconciliation Status"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Debited Account", "Debit Amount", "Debit Date", "Fee Debit Status"]),
            ("47", "Fee Invoice", ["Invoice ID", "Invoice Bill-To Party", "Billing Period End", "Invoice Total", "Payment Status"]),
            ("47", "Fee Adjustment", ["Fee Adjustment ID", "Adjustment Type", "Adjustment Amount Value"]),
            ("47", "Fee Household", ["Fee Household ID", "Anchor Client Household", "Fee Household Status"]),
            ("19", "Financial Statement Line Mapping", ["Mapped GL Account", "Mapped Statement Line",
                                                        "Revenue Disaggregation Category", "Line Mapping Effective From"]),
            ("19", "Journal Entry", ["Journal ID", "Posting Accounting Period", "Posting Legal Entity"]),
            ("19", "GL Posting", ["Journal ID", "Journal Line Number", "Posted Account", "Posted Amount", "Source Finance Record"]),
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status"]),
            ("09", "Fiscal Period", ["Fiscal Period ID", "Fiscal Year", "Fiscal Period Type", "Period Start Date",
                                     "Period End Date"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation",
                                       "Class Net Assets Amount"]),
            ("27", "Fund NAV Calculation", ["Valuation Date", "NAV Approval Status", "NAV Version Number"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Account Role Effective From",
                                          "Account Role Effective To"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status", "Membership Effective From",
                                            "Membership Effective To"]),
        ],
        upstream=["DP-305", "DP-093", "DP-240", "DP-004", "DP-001", "DP-005", "DP-165", "DP-431", "DP-190", "DP-191",
                  "DP-013"],
        refresh="Monthly",
        timeliness=("Estimated by business day 5 after month-end; final when the fiscal period closes (Period Close Status Hard "
                    "Close), typically business day 10"),
        history=("All closed periods kept as final since the 10 go-live; estimated versions kept until superseded by final; "
                 "corrections recorded in the period posted; account-level revenue records kept six years (SEC Rule 17a-4, "
                 "Rule 204-2)"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Revenue Account / Household resolves to a DP-093 account, a DP-305 Fee Household or a DP-094 plan service arrangement; every Revenue Service Offering and Revenue Share Class / Mandate to DP-004; every Recognizing Legal Entity to DP-013; every Economics Sweep Program and Program Bank to DP-431; and every Source Calculation Record to a DP-305 record.",
            "Account Mapping periods of one Management P&L Line and GL Natural Account do not overlap and end on or after they start, and there is one Client Revenue Record per account or Fee Household, Client Revenue Stream and Client Revenue Period.",
            "Billed to Recognized Variance is zero for every account, stream and period, Bank Sweep Fee Allocation Tie-Out is within USD 1.00, Net Fee Revenue = Gross Fee Revenue - Waiver and Reimbursement Offset on every Fee Revenue Record, and Ledger Tie-Out Variance is zero to the cent for every closed period and legal entity.",
            "Client Revenue Stream, Recognized Revenue Amount, Client Revenue Period, Revenue Service Offering, Recognizing Legal Entity and Source Calculation Record are populated on every Client Revenue Record, and every Revenue Stream has a Stream Principal vs Agent Conclusion other than Under Review before its period is final.",
            "Account and household revenue rows are visible only to client revenue finance, pricing and billing and business line leadership; every other reader receives offering, channel, business line, share class and segment aggregates, and a segment row covering fewer than 10 households is suppressed; no party name or TIN is read.",
            "A period is published final only when Period Close Status is Hard Close or Permanently Closed and every revenue-to-GL Control has Reconciliation Status Reconciled and a Control Reference; corrections arrive as 47 Fee Adjustments booked in the period recorded, never as edits to a closed period.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows Client Revenue Record (10, CLREV-; CW-156) and Fee Revenue Record (10, "
               "FRR-; booked revenue, CD-040), with the 10 Cash Program Economics row (sweep program x program bank x period) "
               "it publishes for cash program revenue; source of the client economics revenue facts of SM-28. Certified numbers "
               "(CW-011, CW-204): Gross Fee Revenue, Net Fee Revenue and Effective Net Fee Rate, named as "
               "semantic_model/register.CERTIFIED_WEALTH reads them; defined here only. Calculated fee is 47 (DP-305, billed "
               "amounts, never recognized revenue), recognized revenue is 10 (here), certified enterprise revenue is 19 "
               "(DP-191); Client Fee Reductions Billed and the Billable Assets basis are read from DP-305, never recalculated. "
               "PII tier: financial (revenue earned from identified accounts and households). Boundaries: revenue yield on "
               "Client Assets, profitability and cost to serve are DIS+FDN DP-497 to DP-499; the ledger tie-out view with the "
               "revenue recognition controls in detail is FOP+CORP DP-598; fund expense accruals and expense ratios are DP-165's. "
               "Household rows use the 02 Client Household; the 47 Fee Household is the billing group and is reached only "
               "through its Anchor Client Household. "
               "Acceptance question 11 (plan section 8.5): feeds DP-498 with Client Fee Revenue by Household and Client Segment "
               "at Period End (10, 02). "
               "Tailoring lever: gross presentation of client fees. Reference default: recognized at the 47 net fee, with 47 "
               "reductions reported beside it (Client Fee Reductions Billed); lever: 47 Gross Fee as revenue and reductions "
               "as contra-revenue. Tailoring lever: sub-advised fund fees. Reference default: principal, gross with "
               "sub-advisory fees as expense (10 Stream Principal vs Agent Conclusion). Tailoring lever: sweep vehicle. "
               "Reference default: money market sweep fund, with bank sweep fees the lever. Tailoring lever: payment for order "
               "flow. Reference default: none (Order Routing Payment stream empty). Tailoring lever: listed parent. Reference "
               "default: not listed; if listed, unreleased quarterly revenue is Restricted - MNPI until earnings release. "
               "Taxonomy gap: 10 Client Revenue Record has no attribute splitting a multi-valued Source Calculation Record's "
               "amount by record, so Billed to Recognized Variance compares totals per row. Taxonomy gap: no 10 attribute "
               "holds the pass-through amount of an agent client stream (for example a third-party manager's share of a wrap "
               "fee). "
               "Drafting assumptions: the fee-stream list and the asset-based stream list; Fee Debit Status Posted; the USD 1.00 tolerance; the 10-household "
               "minimum cell; business days 5 and 10. Decisions: CW-011, CW-012, CW-156, CW-159, CW-204, CD-040, CD-340, "
               "CD-343. "
               "WP1 re-scope (CW-204): renamed Client Fee Revenue; owning domain 10 unchanged; upstream DP-008 dropped (the "
               "wholesale Fee Basis Variance read Average AUM), DP-305, DP-093, DP-240, DP-165 and DP-431 added; inputs 06 "
               "Measure Value and 06 Asset Measures dropped, 10 Client Revenue Record and Cash Program Economics, the 47 billed "
               "objects, 27 NAV, 15 Account Party Role and 02 Household Membership added; measures 'Gross Fee Revenue', 'Net "
               "Fee Revenue' kept by name with the client fee streams added (read by SM-07 and CERTIFIED (SM-07); "
               "CERTIFIED_WEALTH moves them to SM-28 at WP2); 'Effective Net Fee Rate' kept by name but redefined to the "
               "client fee basis (one denominator, 47 Billable Assets), and the wholesale fund-basis rate (Net Fee Revenue / "
               "Fee Basis Average Assets) moves to the new measure 'Fund Effective Net Fee Rate': the SM-07 metric Effective "
               "Net Fee Rate and CERTIFIED (SM-07) keep their name but now read the client rate, so SM-07 must decide which "
               "it shows and re-point to 'Fund Effective Net Fee Rate' if it means the fund rate; 'Waiver Cost', 'Net Distribution Revenue "
               "Retained' and 'Reconciliation Control Completion %' kept, 'Fee Basis Variance' kept and re-based on DP-165 "
               "Class Net Assets (read by SM-07), 'Gross Distribution Revenue' added as a measure (SM-07 reads it by that "
               "name). Measures added that SM-07 (until SM-28) must publish or exclude: Client Transaction and Interest "
               "Revenue, Client Fee Revenue by Household, Fee Revenue as Presented, Billed to Recognized Variance, Client Fee "
               "Reductions Billed (from DP-305), Cash Program Revenue, Bank Sweep Fee Allocation Tie-Out, Fund Effective Net "
               "Fee Rate, Performance Fee Revenue Recognized, Ledger Tie-Out Variance, Gross Distribution Revenue. Entities Fee Revenue Record, Accounting Period Status and Revenue Contract keep their objects. The W4 "
               "re-point line (CW-906) is superseded."
               "WP1 lineage addition (CW-265, C-4 fix pass): measure 'Client Fee Revenue' publishes the client fee slice of the certified Gross Fee Revenue (47 client fee streams on 10 Client Revenue Record, excluding own-fund management fees) for DP-598's revenue tie-out; it is a slice of Gross Fee Revenue, not a second revenue number. No input changed."
               " WP2 retirement sweep (CW-209): SM-07, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-145": dict(
        definition=("The firm's official, signed-off performance: portfolio, share class, institutional account, composite, "
                    "managed account composite and model portfolio returns by fee, net fee, price, tax and sales-charge basis "
                    "and currency, benchmark returns, with the calculation policy and measurement profile in force, the "
                    "period close and every restatement; and the certified Personal Rate of Return of every client account "
                    "and household performance group (32 Client Account Performance, CW-129) by period, method, calculation "
                    "method, fee basis and version, with its suppression state. It publishes the 32 concepts Performance "
                    "Return (RETURN-), Benchmark Return, Personal Rate of Return (PRROR-) and Household Performance Group "
                    "(HPGRP-) without remastering them. It is the only source of the certified Official Return, Benchmark "
                    "Return (CD-293, CD-320) and Personal Return Value (certified, CW-011): every statement, client report, "
                    "shareholder report, marketing piece and scorecard takes its returns from here."),
        business_questions=[
            "What is the official return of each share class, portfolio, composite, model and institutional account for each period, gross and net of fees, and what was its benchmark's return?",
            "What is each household's and account's personal rate of return, and how is it computed (time- or money-weighted, calculation method, fee basis, period)?",
            "Which personal returns are suppressed, and why, and do their values, flows and fees tie to the 49, 29, 16 and 47 books?",
            "Which periods are closed and Final, which returns are still Preliminary, and which were restated after release and need client notification?",
            "What did each managed account composite return, and how many accounts does it hold?",
            "Do share class returns rest on the NAV of record, and do benchmark returns tie to the index levels?",
        ],
        grain=("Performance return (RETURN-): subject x period start x period end x fee basis x net fee basis x calculation "
               "type x price basis x tax basis x sales charge basis x currency x version; with benchmark return (benchmark x "
               "period x return type x currency x hedged basis x version) and Personal Rate of Return (PRROR-: account or "
               "household performance group x period start x period end x method x fee basis x version) as companion facts; "
               "every version kept"),
        dimensions=["Measured subject (portfolio, share class, account, composite, model portfolio)", "Return subject type",
                    "Period start and end", "Period basis", "Fee basis and net fee basis", "Calculation type", "Price basis",
                    "Tax basis", "Sales charge basis", "Return currency", "Return status and version", "Benchmark",
                    "Close group", "Return source", "Personal return subject (account (DP-093), household performance group)",
                    "Client household (DP-240)", "Personal return method and calculation method", "Personal return fee basis",
                    "Return suppression reason", "Managed account composite (DP-304)"],
        measures=[
            ("Official Return", "Return Value of the Performance Return with the highest Return Version per return key and Return Status in (Final, Restated); certified (CD-320). Preliminary rows are published with Official Return null.",
             _u("32", "Performance Return", "Return Value", "Return Version", "Return Status", "Performance Return ID")),
            ("Benchmark Return", "Benchmark Return Value of the highest Benchmark Return Version per benchmark, period, Benchmark Return Type, Benchmark Return Currency and Benchmark Hedged Basis Indicator with Benchmark Return Status in (Final, Restated); certified (CD-320).",
             _u("32", "Benchmark Return", "Benchmark Return Value", "Benchmark Return Version", "Benchmark Return Status",
                "Return Benchmark", "Benchmark Return Type", "Benchmark Return Currency", "Benchmark Hedged Basis Indicator")),
            ("Excess Return", "For share class subjects, Official Return - Benchmark Return of the Product Benchmark Assignment of the Return Share Class with Benchmark Role = Primary effective at Return Period End Date, for the same period and Return Currency (arithmetic); portfolio, composite and account excess returns are left to DP-158 and DP-159. Derived from two certified numbers; not itself a certified family.",
             _u("01", "Product Benchmark Assignment", "Benchmark Role", "Assigned Benchmark", "Assigned Product / Share Class")
             + _u("32", "Performance Return", "Return Period End Date", "Return Share Class", "Return Currency")
             + ["Official Return", "Benchmark Return"]),
            ("Share Class Returns on NAV of Record %", "Share class Official Returns whose Start NAV Record and End NAV Record both resolve to a Share Class NAV whose Parent NAV Calculation has NAV Approval Status = Approved, the highest NAV Version Number and NAV Calculation Source other than Firm Shadow / all share class Official Returns.",
             _u("32", "Return Component Detail", "Start NAV Record", "End NAV Record") + _u("32", "Performance Return", "Return Subject Type")
             + _u("27", "Share Class NAV", "Share Class NAV ID", "Parent NAV Calculation")
             + _u("27", "Fund NAV Calculation", "NAV Approval Status", "NAV Version Number", "NAV Calculation Source")
             + ["Official Return"]),
            ("Benchmark Return Tie-Out", "For benchmarks with Blended Benchmark Indicator = N, Benchmark Return Value - (End Index Level / Start Index Level - 1), where Start and End Index Level match the 22 Index Level Value of the Return Benchmark at the period start and end dates for the same variant and currency; flagged beyond 0.0001.",
             _u("32", "Benchmark Return", "Benchmark Return Value", "Start Index Level", "End Index Level")
             + _u("22", "Index Level Observation", "Index Level Value", "Index Benchmark", "Level Date")
             + _u("01", "Benchmark", "Blended Benchmark Indicator")),
            ("Return Component Tie-Out", "Return Value - (Income Return + Capital Return) for single-period time-weighted returns with components; flagged beyond 0.0001.",
             _u("32", "Return Component Detail", "Income Return", "Capital Return")
             + _u("32", "Performance Return", "Return Value", "Return Calculation Type")),
            ("Periods Closed On Time %", "Performance Period Close rows reaching Period Close Status = Final with Final Release Timestamp by business day 7 after Close Period End Date / all close group x period rows due.",
             _u("32", "Performance Period Close", "Period Close Status", "Final Release Timestamp", "Close Period End Date", "Close Group")),
            ("Material Restatements", "Count of Performance Restatements with Material Error Indicator = Y in the period, and the mean absolute Restatement Return Difference, by Restatement Cause.",
             _u("32", "Performance Restatement", "Material Error Indicator", "Restatement Return Difference", "Restatement Cause",
                "Restatement Date")),
            ("Unreviewed Hypothetical Returns", "Count of Performance Returns with Hypothetical Indicator = Y whose Hypothetical Performance Detail has no Hypothetical Compliance Review.",
             _u("32", "Performance Return", "Hypothetical Indicator") + _u("32", "Hypothetical Performance Detail", "Hypothetical Compliance Review")),
            ("Personal Return Value",
             "Certified (CW-011). Personal Return Value of the highest Personal Return Version per Personal Rate of Return ID with Personal Return Status in (Final, Restated), on account rows (Personal Return Account) and household rows (Personal Return Group: a Household Performance Group of an 02 Client Household, whose default group follows 02 Household Membership), by Personal Return Method (time-weighted and money-weighted), Personal Return Calculation Method, Personal Return Fee Basis, period start and end and Personal Return Period Basis. Null while the subject's Client Performance Profile has a Return Suppression Reason or an open Client Return Exception with Suppresses Return Indicator = Y. Computed from Beginning and Ending Market Value and Net External Flows, Derived copies of the 49 brokerage book (Client Holding Valuation), the 29 register and 16 participant balances.",
             _u("32", "Personal Rate of Return", "Personal Rate of Return ID", "Personal Return Version",
                "Personal Return Subject Type", "Personal Return Account", "Personal Return Group",
                "Personal Return Period Start Date", "Personal Return Period End Date", "Personal Return Period Basis",
                "Personal Return Method", "Personal Return Calculation Method", "Personal Return Fee Basis",
                "Personal Return Value", "Personal Return Status", "Beginning Market Value", "Ending Market Value",
                "Net External Flows")
             + _u("32", "Client Performance Profile", "Return Suppression Reason")
             + _u("32", "Client Return Exception", "Suppresses Return Indicator", "Return Exception Status")
             + _u("32", "Household Performance Group", "Household Performance Group ID", "Group Household")
             + _u("02", "Household Membership", "Household", "Household Member")
             + _u("49", "Client Holding Valuation", "Market Value in USD")),
            ("Suppressed Personal Returns",
             "Count of account and household subjects whose Personal Return Value is null for the period, by Return Suppression Reason and, for open exceptions, Client Return Exception Type.",
             _u("32", "Client Performance Profile", "Client Profile Subject Type", "Client Profile Account", "Client Profile Group",
                "Return Suppression Reason")
             + _u("32", "Client Return Exception", "Exception Account", "Exception Date", "Client Return Exception Type",
                  "Return Exception Status", "Suppresses Return Indicator")
             + ["Personal Return Value"]),
            ("Personal Return Ending Value Tie-Out",
             "Account rows: Ending Market Value - the book value at Personal Return Period End Date: for brokerage and managed accounts, Market Value in USD of the account's Client Holdings of Client Holding View End of Day plus client cash under DP-007's client cash rule (" + _CASH_RULE + ") (DP-300); for fund-only accounts, Registered Shares x the 27 NAV per Share (DP-580, DP-165); for participant accounts, Balance Market Value of the memberships whose Participant Account is the account (DP-430); flagged beyond USD 0.01.",
             _u("32", "Personal Rate of Return", "Ending Market Value", "Personal Return Account", "Personal Return Period End Date")
             + _u("49", "Client Holding", "Holding Account", "Client Holding Date", "Client Holding View")
             + _u("49", "Client Holding Valuation", "Market Value in USD")
             + _u("49", "Account Cash Balance", *_CASH)
             + _u("49", "Margin Balance Snapshot", *_MARGIN)
             + _u("29", "Share Register Balance", "Register Account", "Register Share Class", "Register Business Date", "Registered Shares")
             + _u("27", "Share Class NAV", "NAV per Share", "NAV Share Class")
             + _u("16", "Participant Balance", "Balance Membership", "Valuation Date", "Balance Market Value")
             + _u("16", "Participant Plan Membership", "Membership ID", "Participant Account")),
            ("Personal Return Flow Tie-Out",
             "Account rows: Net External Flows - the external flows of the period: Activity Net Amount of the account's posted 49 Client Account Activity of deposit, withdrawal and transfer Activity Types; Net Amount of 29 Register Transactions that cross the account boundary (purchases, redemptions, transfers with a Transfer Counter Account outside it); Posted Amount of 16 contribution and distribution Posting Types; flagged beyond USD 0.01.",
             _u("32", "Personal Rate of Return", "Net External Flows", "Personal Return Period Start Date")
             + _u("49", "Client Account Activity", "Activity Account", "Activity Type", "Trade Date", "Activity Net Amount", "Activity Status")
             + _u("29", "Register Transaction", "Posting Account", "Register Transaction Type", "Register Trade Date", "Net Amount",
                  "Transfer Counter Account")
             + _u("16", "Participant Ledger Posting", "Posting Membership", "Posting Type", "Posting Trade Date", "Posted Amount")),
            ("Personal Return Fee Tie-Out",
             "Rows with Personal Return Fee Basis Net of Fees: Fees Deducted - the sum of Debit Amount of the account's 47 Fee Debits with Fee Debit Status Posted and Debit Date in the period, or Invoice Total of its Fee Invoices with Billing Period End in the period where the fee is billed (from DP-305); blank on gross rows.",
             _u("32", "Personal Rate of Return", "Fees Deducted", "Personal Return Fee Basis")
             + _u("47", "Fee Debit", "Debited Account", "Debit Amount", "Debit Date", "Fee Debit Status")
             + _u("47", "Fee Invoice", "Invoice Fee Schedule Assignment", "Billing Period End", "Invoice Total")),
            ("Households Without Default Performance Group",
             "Count of 02 Client Households with a member owning an account that has a Client Performance Profile but no active Household Performance Group of Performance Group Type Default (All Household Accounts); plus default groups whose Household Performance Group Members differ from the accounts of the Household Membership members on the period end.",
             _u("32", "Household Performance Group", "Group Household", "Performance Group Type", "Performance Group Status")
             + _u("32", "Household Performance Group Member", "Member Performance Group", "Member Account", "Member Inclusion Date",
                  "Member Exclusion Date")
             + _u("02", "Household Membership", "Membership Effective From", "Membership Effective To")
             + _u("15", "Account Party Role", "Role Account", "Role Party")),
            ("Restated Personal Returns Requiring Notification",
             "Count of Personal Rate of Return versions with Personal Return Status Restated, a Supersedes Personal Return and Personal Return Client Notification Indicator = Y, by Personal Return Restatement Cause.",
             _u("32", "Personal Rate of Return", "Supersedes Personal Return", "Personal Return Restatement Cause",
                "Personal Return Client Notification Indicator")),
            ("Managed Account Composite Return",
             "Official Return of Performance Returns with Return Subject Type Managed Account Composite, with the count of accounts in the Return Managed Account Composite (46 Managed Account Composite Membership open on Return Period End Date, Discretion Check Passed Indicator = Y, no Composite Exclusion Reason) from DP-304.",
             _u("32", "Performance Return", "Return Managed Account Composite")
             + _u("46", "Managed Account Composite", "Managed Account Composite ID", "Composite Status")
             + _u("46", "Managed Account Composite Membership", "Membership Composite", "Member Account", "Membership Start Date",
                  "Membership End Date", "Discretion Check Passed Indicator", "Composite Exclusion Reason")
             + ["Official Return"]),
        ],
        inputs=[
            ("32", "Performance Calculation Policy", ["Calculation Policy Code", "Calculation Policy Version", "Covered Business Lines",
                                                      "External Cash Flow Timing", "Large Cash Flow Threshold", "Error Materiality Threshold",
                                                      "Policy Effective From"]),
            ("32", "Performance Measurement Profile", ["Profiled Subject Type", "Profiled Portfolio", "Profiled Share Class", "Profiled Account",
                                                       "Profiled Composite", "Profiled Model Portfolio", "Profiled Managed Account Composite",
                                                       "Applied Calculation Policy", "Calculation Frequency", "Return Methodology",
                                                       "Net Fee Treatments Produced", "Model Fee Rate", "Performance Close Group",
                                                       "Track Record Continuity Change", "Profile Effective From", "Profile Effective To"]),
            ("32", "Performance Return", ["Performance Return ID", "Return Version", "Return Subject Type", "Return Portfolio", "Return Share Class",
                                          "Return Account", "Return Composite", "Return Model Portfolio", "Return Managed Account Composite",
                                          "Return Period Start Date", "Return Period End Date", "Return Period Basis", "Return Calculation Type",
                                          "Return Calculation Method", "Return Fee Basis", "Return Net Fee Basis", "Price Basis", "Return Tax Basis",
                                          "Sales Charge Adjusted Indicator", "Return Currency", "Return Value", "Annualized Indicator",
                                          "Return Status", "Return Source", "Hypothetical Indicator"]),
            ("32", "Return Component Detail", ["Beginning Portfolio Value", "Ending Portfolio Value", "Net External Cash Flow", "Start NAV Record",
                                               "End NAV Record", "Start Market Price Statistic", "End Market Price Statistic", "Applied FX Rate Type",
                                               "Income Return", "Capital Return", "Fees Deducted Amount"]),
            ("32", "Hypothetical Performance Detail", ["Hypothetical Performance Category", "Hypothetical Methodology Description",
                                                       "Hypothetical Compliance Review"]),
            ("32", "Benchmark Return", ["Return Benchmark", "Benchmark Period Start Date", "Benchmark Period End Date", "Benchmark Period Basis",
                                        "Benchmark Return Type", "Benchmark Return Currency", "Benchmark Hedged Basis Indicator",
                                        "Benchmark Return Version", "Supersedes Benchmark Return", "Benchmark Return Value", "Benchmark Return Source",
                                        "Start Index Level", "End Index Level", "Blend Components Applied", "Blend Rebalancing Frequency",
                                        "Benchmark Return Status"]),
            ("32", "Performance Period Close", ["Close Group", "Close Period End Date", "Close Period Type", "Period Close Status",
                                                "Final Release Timestamp"]),
            ("32", "Performance Restatement", ["Restated Return", "Restatement Sequence", "Superseded Return Version", "Restating Return Version",
                                               "Restatement Cause", "Restatement Date", "Related NAV Error Case", "Restatement Return Difference",
                                               "Material Error Indicator", "GIPS Disclosure Required Indicator",
                                               "Client Notification Required Indicator"]),
            ("32", "Client Performance Profile", ["Client Profile Subject Type", "Client Profile Account", "Client Profile Group",
                                                  "Performance Start Date", "Client Methods Produced", "Client Fee Bases Produced",
                                                  "Client Comparison Benchmark", "Client Applied Calculation Policy",
                                                  "Return Suppression Reason", "Client Profile Effective From"]),
            ("32", "Household Performance Group", ["Household Performance Group ID", "Group Household", "Performance Group Type",
                                                   "Performance Group Status"]),
            ("32", "Household Performance Group Member", ["Member Performance Group", "Member Account", "Member Inclusion Date",
                                                          "Member Exclusion Date"]),
            ("32", "Personal Rate of Return", ["Personal Rate of Return ID", "Personal Return Version", "Personal Return Subject Type",
                                               "Personal Return Account", "Personal Return Group", "Personal Return Period Start Date",
                                               "Personal Return Period End Date", "Personal Return Period Basis",
                                               "Personal Return Method", "Personal Return Calculation Method",
                                               "Personal Return Fee Basis", "Personal Return Value",
                                               "Personal Return Annualized Indicator", "Beginning Market Value",
                                               "Ending Market Value", "Net External Flows", "Fees Deducted",
                                               "Personal Return Status", "Supersedes Personal Return",
                                               "Personal Return Restatement Cause",
                                               "Personal Return Client Notification Indicator"]),
            ("32", "Client Return Exception", ["Exception Account", "Exception Date", "Client Return Exception Type",
                                               "Return Exception Status", "Suppresses Return Indicator", "Exception Resolution"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "Parent NAV Calculation", "NAV Share Class", "NAV per Share"]),
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number", "NAV Approval Status"]),
            ("22", "Index Level Observation", ["Index Benchmark", "Level Date", "Index Level Variant", "Level Currency", "Index Level Value"]),
            ("01", "Benchmark", ["Benchmark ID", "Blended Benchmark Indicator", "Blend Components"]),
            ("01", "Product Benchmark Assignment", ["Assigned Product / Share Class", "Assigned Benchmark", "Benchmark Role",
                                                    "Assignment Effective From", "Assignment Effective To"]),
            ("46", "Managed Account Composite", ["Managed Account Composite ID", "Composite Program", "Composite Model Portfolio",
                                                 "Composite Status"]),
            ("46", "Managed Account Composite Membership", ["Membership Composite", "Member Account", "Membership Start Date",
                                                            "Membership End Date", "Discretion Check Passed Indicator",
                                                            "Composite Exclusion Reason"]),
            ("49", "Client Holding", ["Client Holding ID", "Holding Account", "Client Holding Date", "Client Holding View"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("49", "Account Cash Balance", list(_CASH)),
            ("49", "Margin Balance Snapshot", list(_MARGIN)),
            ("49", "Client Account Activity", ["Client Account Activity ID", "Activity Account", "Activity Type", "Trade Date",
                                               "Activity Net Amount", "Activity Status"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date", "Registered Shares"]),
            ("29", "Register Transaction", ["Register Transaction ID", "Posting Account", "Register Transaction Type",
                                            "Register Trade Date", "Net Amount", "Transfer Counter Account"]),
            ("16", "Participant Balance", ["Balance Membership", "Valuation Date", "Balance Market Value"]),
            ("16", "Participant Plan Membership", ["Membership ID", "Participant Account"]),
            ("16", "Participant Ledger Posting", ["Ledger Posting ID", "Posting Membership", "Posting Type", "Posting Trade Date",
                                                  "Posted Amount"]),
            ("47", "Fee Debit", ["Fee Debit ID", "Debited Account", "Debit Amount", "Debit Date", "Fee Debit Status"]),
            ("47", "Fee Invoice", ["Invoice ID", "Invoice Fee Schedule Assignment", "Billing Period End", "Invoice Total"]),
            ("02", "Household Membership", ["Household", "Household Member", "Membership Status", "Membership Effective From",
                                            "Membership Effective To"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account"]),
        ],
        upstream=["DP-140", "DP-141", "DP-142", "DP-143", "DP-144", "DP-004", "DP-093", "DP-165", "DP-240", "DP-300",
                  "DP-580", "DP-430", "DP-094", "DP-305", "DP-304", "DP-013"],
        refresh="Daily",
        timeliness=("Preliminary daily returns by 10am ET on T+1; month-end returns and personal returns Final by business day "
                    "7 after month-end (Performance Period Close); benchmark returns with the same close"),
        history=("Every return, benchmark return and personal return version kept indefinitely (GIPS and Marketing Rule record "
                 "keeping; personal returns shown on statements kept at least six years, SEC Rule 17a-4 and Rule 204-2), with "
                 "superseded versions and restatements; measurement profiles, client performance profiles and calculation "
                 "policies kept by version"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "File extract"],
        dq_rules=[
            "Every Performance Return and Personal Rate of Return fills exactly the one subject reference its subject type names: Return Account only for Institutional Separate Account accounts in DP-093, Personal Return Account for any other DP-093 client account, Personal Return Group for a Household Performance Group whose Group Household resolves to DP-240, Return Managed Account Composite to DP-304 and Return Share Class to DP-004; each subject has a profile effective on the period end.",
            "Performance Measurement Profile and Client Performance Profile periods of one subject do not overlap, Household Performance Group Member Member Exclusion Date is blank or on or after Member Inclusion Date, and every period end is on or after its start.",
            "Each return key has exactly one current version and a Restated row names the version it supersedes; every Final share class return names Start and End NAV Records of the NAV of record in DP-165; and Personal Return Ending Value Tie-Out, Flow Tie-Out and Fee Tie-Out are within USD 0.01 before a personal return becomes Final.",
            "Personal Return Value, Personal Return Method, Personal Return Fee Basis, Personal Return Status and Beginning and Ending Market Value are populated on every Final personal return, and every Performance Return with Hypothetical Indicator = Y has a Hypothetical Performance Category and a Hypothetical Compliance Review before it is Final.",
            "Account and household returns are visible only to the client, the advisor of record (DP-009) and performance, service and supervision roles; an account-free view serves wide use; no Personal Return Value is released while its subject is suppressed; Close Signed Off By and Restatement Approver are not published.",
            "No return of a close group becomes Final before its Performance Period Close is Final for the period end, month-end returns are Final by business day 7, and a correction creates a new version, never an edit.",
        ],
        notes=("Master concepts: 'Performance Return', 32, RETURN-; 'Benchmark Return', 32; 'Personal Rate of Return', 32, "
               "PRROR-; 'Household Performance Group', 32, HPGRP- (CD-217, CW-129). Certified numbers (CD-293, CD-320, CW-011): "
               "Official Return (Final and Restated rows; Preliminary rows are flagged, never certified), Benchmark Return and "
               "Personal Return Value (time- and money-weighted, account and household grain), named as "
               "semantic_model/register.CERTIFIED_WEALTH reads it (SM-08); published only here, never recalculated by DP-532, "
               "DP-533, DP-534, 13 statements or 45 goal reports. Sources: share class returns use the 27 NAV of record "
               "(DP-165); portfolio and institutional account returns use 18 values (DP-140 to DP-142) and prices (DP-143); "
               "benchmark returns use 22 index levels (DP-144) and 01 blend components; personal returns copy values and flows "
               "from 49 (DP-300), 29 (DP-580) and 16 (DP-430) and fees from 47 (DP-305), checked by the three tie-out "
               "measures; managed account composite returns use 46 membership (DP-304, CW-050). The component values on Return "
               "Component Detail and the Start and End Index Level on Benchmark Return are Derived copies read as held (rule 2 "
               "exception). Dimensions: DP-004 does not yet carry 01 Benchmark or Product Benchmark Assignment (CD-322); until "
               "then they are read directly. Operating model (CD-297): in house; where a fund administrator calculates (Return Source "
               "Fund Administrator) the Performance Return row is held as received and approved and the grain does not change. "
               "Return Account is an institutional separate account only, so the 'Recordkeeping Platform' source no longer "
               "applies to Performance Return rows; a participant return calculated on the recordkeeping platform is a "
               "Personal Rate of Return row, which carries no Return Source (taxonomy gap below). PII tier: financial (account and household personal returns, "
               "values, flows and fees; no special-category data). Classification Confidential - Personal Data; share class "
               "and composite returns become public once released. The household is the 02 Client Household; the Household "
               "Performance Group is a performance grouping only, not the 13 mailing group, the 46 managed group or the 47 Fee "
               "Household. Boundaries: presentation of personal returns is DP-532's, suppression and restatement workflow "
               "DP-533's, managed account dispersion DP-534's; GIPS composites DP-158. "
               "Acceptance question 9 (plan section 8.5): answered by Personal Return Value with its method, calculation "
               "method, fee basis and suppression state; mastering domains 32, 02 and 49. "
               "Tailoring lever: household performance groups. Reference default: one default group of all household accounts; "
               "client-defined subsets allowed (32 SME lever 5). Tailoring lever: calculation method. Reference default: true "
               "IRR for the money-weighted headline, Modified Dietz linked monthly for time-weighted. Tailoring lever: fee "
               "basis shown to clients. Reference default: net of fees, with gross available. Tailoring lever: CD-217 option A "
               "or B. Reference default: option B until ruled (27 Financial Highlights Total Return not a copy). "
               "Taxonomy gap: no attribute records the business-day deadline of a performance close; Periods Closed On Time % "
               "uses business day 7 (32 SME question 8). Taxonomy gap: 32 Personal Rate of Return has no Return Source, so a "
               "recordkeeper-calculated participant return is not distinguishable on the row. "
               "Drafting assumptions: the USD 0.01 tie-out tolerance; the 49 Activity Types, 29 Register Transaction Types and "
               "16 Posting Types counted as external flows; Fee Debit Status Posted; business day 7. "
               "Decisions: CD-217, CD-219, CD-292, CD-293, CD-297, CD-320, CD-322, CW-011, CW-050, CW-129. "
               "W4 re-point (CW-930, CW-166): 32 Private Markets Performance Measure dropped, no successor, with the 30 Capital "
               "Call and Distribution inputs (DP-116 and DP-117 leave upstream); the certified measure Private Fund IRR and "
               "Multiples and its tie-out, question, dimensions and rule are removed. "
               "WP1 extension (CW-129, CW-011): adds the 32 Client Account Performance objects (Client Performance Profile, "
               "Household Performance Group and Member, Personal Rate of Return, Client Return Exception), the 46 managed "
               "account composite objects, the 49, 29, 16, 47, 02 and 15 tie-out inputs and Profiled and Return Managed Account "
               "Composite; adds measures Personal Return Value (certified), Suppressed Personal Returns, the three tie-outs, "
               "Households Without Default Performance Group, Restated Personal Returns Requiring Notification and Managed "
               "Account Composite Return; adds upstream DP-240, DP-300, DP-580, DP-430, DP-094, DP-305, DP-304 and DP-013. "
               "Every existing measure and dimension name is kept (SM-08 reads Official Return, Benchmark Return, Excess "
               "Return, Share Class Returns on NAV of Record %, Benchmark Return Tie-Out, Return Component Tie-Out, Periods "
               "Closed On Time %, Material Restatements and Unreviewed Hypothetical Returns). Return Account and Profiled "
               "Account are institutional separate accounts only (CW-129 supersedes CD-220 option A); the W3 'publish at WP1' "
               "note and the CD-220 PII statement are superseded. The business questions are extended to six and the DQ rules "
               "reordered DQ1 to DQ6 with the personal return rules added."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-241": dict(
        definition=("The certified Firm AUM (CW-011) with its three slices, each certified: the own funds slice at NAV "
                    "(month-end fund net assets of the NAV of record from DP-165, feeders excluded), the managed account "
                    "slice (retail managed accounts at 49 market value from CLA-A DP-345 over DP-304 and DP-300) and the "
                    "institutional slice (IA separate accounts and OCIO mandates at 18 portfolio market value from DP-142), "
                    "with own-fund Client Holdings (49) and Portfolio Holdings (18) removed from the two advisory slices so each asset is in Firm AUM once. It "
                    "reconciles Firm AUM to certified Client Assets (DP-008) every month-end, netting the own-fund overlap "
                    "here and only here and explaining every other difference by cause; the two families are reconciled, "
                    "never summed. 'AUM' names Firm AUM only."),
        business_questions=[
            "What is certified Firm AUM at month-end and how much is in each slice: own funds at NAV, managed accounts and institutional mandates?",
            "How do Client Assets by channel and holding type reconcile to Firm AUM, and how much of the difference is the own-fund overlap?",
            "How much Firm AUM sits outside Client Assets (seed capital, own funds held by own funds, registered units in no account) and how much Client Assets sits outside Firm AUM?",
            "How large is the unexplained residual, which slices carry it, and is it within tolerance?",
            "Which portfolios are in no Firm AUM slice, and what would Firm AUM be net of own-fund holdings?",
        ],
        grain=("Month-end x Firm AUM slice (own funds, managed account, institutional) x fund, share class or portfolio x "
               "reconciling cause, with a firm-level row per month-end; built on the locked DP-008 snapshot, the NAVs of "
               "record of the month and the DP-345 slice of the month; one version per input version"),
        dimensions=["Month-end and reporting period (DP-013)", "Firm AUM slice", "Fund and share class (DP-004)",
                    "Vehicle type and master-feeder role (DP-004)", "Portfolio and implementation link type (DP-140)",
                    "Managed account program and regulatory AUM classification (DP-345, DP-304)", "Business line",
                    "Reconciling cause", "Seed commitment type (DP-204)", "Currency", "DP-008 snapshot and data basis",
                    "Reconciled flag"],
        measures=[
            ("Firm AUM Own Funds Slice",
             "Certified (CW-011). Sum over own funds of Month-End Fund Net Assets at NAV (from DP-165): the Fund Net Assets Amount of the NAV of record that DP-165's NAV of Record Flag selects (NAV Approval Status Approved, highest NAV Version Number, NAV Calculation Source equal to the official source of the book's Fund Book Operating Period on the date) at the month-end Valuation Date or the last one before it; excluding funds whose Master-Feeder Role is Feeder (their master's net assets hold them) and counting fund-of-funds Portfolio Holdings of own funds gross (CD-292); books whose Book Reporting Currency is not USD translated at the month-end Spot Rate of the 22 FX Rate Observation whose Observed FX Rate Type is the 09 FX Rate Type with Approved Usage AUM Reporting Translation.",
             _u("27", "Fund NAV Calculation", "NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                "NAV Approval Status", "Fund Net Assets Amount")
             + _u("27", "Fund Book Operating Period", "Operated Book", "Fund Accounting Operating Model",
                  "Operating Period Effective From", "Operating Period Effective To")
             + _u("09", "FX Rate Type", "FX Rate Type Code", "Approved Usage")
             + _u("27", "Fund Accounting Book", "Book Fund", "Book Reporting Currency")
             + _u("01", "Fund Legal Structure", "Master-Feeder Role") + _u("01", "Investment Product", "Product ID", "Vehicle Type")
             + _u("22", "FX Rate Observation", "Spot Rate", "Observed FX Rate Type", "FX Rate Date")),
            ("Firm AUM Managed Account Slice",
             "Certified (CW-011). The month-end value of 'Managed Account Assets (Discretionary and Non-Discretionary)' published by CLA-A DP-345 (from DP-345; slice owner Head of Managed Account Operations), read and never recomputed here; the slice is defined once, by that DP-345 measure. The uses are the attributes DP-345 publishes the value on: the 46 Model Assignment keys and classification (Assigned Account, Assignment Status Active, Regulatory AUM Classification Discretionary or Non-Discretionary, in force at the month-end) and the 49 Client Holding Valuation Market Value in USD of non-own share classes (Own Share Class Indicator not set), with client cash under DP-007's client cash rule.",
             _u("46", "Model Assignment", "Model Assignment ID", "Assigned Account", "Assignment Status",
                "Regulatory AUM Classification", "Assignment Effective From", "Assignment Effective To")
             + _u("49", "Client Holding", "Own Share Class Indicator")
             + _u("49", "Client Holding Valuation", "Market Value in USD")),
            ("Firm AUM Institutional Slice",
             "Certified (CW-011). Total IBOR Market Value of the Portfolio Valuation Summary (Valuation View End of Day, locked Summary Snapshot) at the month-end for Active portfolios of Portfolio Type Standalone Book (sleeves and aggregates are never counted, so each mandate or account counts once) whose primary Portfolio Implementation Link in force (Implementation Effective From / To) names an Implemented Mandate or a Managed Account (IA separate accounts and OCIO mandates) and no Implemented Product, less the Market Value Base of their end-of-day Portfolio Holdings whose Held Instrument has Own Share Class set (in the own funds slice), excluding portfolios with Proprietary Capital Indicator set (CD-346); from DP-142 and DP-140.",
             _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Summary Snapshot",
                "Total IBOR Market Value")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implemented Product", "Implemented Mandate",
                  "Managed Account", "Primary Implementation Indicator", "Implementation Effective From", "Implementation Effective To")
             + _u("18", "Portfolio", "Portfolio ID", "Portfolio Type", "Portfolio Status", "Proprietary Capital Indicator")
             + _u("18", "Portfolio Holding", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View")
             + _u("18", "Holding Valuation", "Market Value Base") + _u("17", "Instrument", "Instrument ID", "Own Share Class")),
            ("Firm AUM",
             "Certified (CW-011). Firm AUM Own Funds Slice + Firm AUM Managed Account Slice + Firm AUM Institutional Slice, in USD; each asset counted once (own-fund Client Holdings and Portfolio Holdings removed from the advisory slices). Displayed by slice; never added to Client Assets.",
             ["Firm AUM Own Funds Slice", "Firm AUM Managed Account Slice", "Firm AUM Institutional Slice"]),
            ("Ending Client Assets (from DP-008)",
             "Measure Amount of the Measure Value with Measure MSR-CLIENTASSETS (Ending Client Assets), Dimension Type Total and Dimension Key ALL, at the Period End Date of the month, in the DP-008 Snapshot with Snapshot Type Final or Restated; Data Basis shown. Read, never recomputed.",
             _mv("Measure", "Period End Date", "Dimension Type", "Dimension Key", "Measure Amount", "Data Basis", "Snapshot")
             + _u("06", "Snapshot", "Snapshot ID", "Snapshot Type") + _u("06", "Client Asset Measures", "Ending Client Assets")),
            ("Own-Fund Overlap Amount (from DP-008)",
             "Own-Fund Overlap Amount of the same locked DP-008 snapshot at Dimension Type Total: own funds inside Client Assets that are also in the own funds slice. Read, never recomputed.",
             _mv("Measure", "Measure Amount", "Snapshot") + _u("06", "Client Asset Measures", "Own-Fund Overlap Amount")),
            ("Own Funds Outside Client Assets",
             "Firm AUM Own Funds Slice - Own-Fund Overlap Amount (from DP-008): the own-fund overlap netted, here and only here; the own-fund assets that no firm client account or counted intermediary row holds.",
             ["Firm AUM Own Funds Slice", "Own-Fund Overlap Amount (from DP-008)"]),
            ("Gross Difference",
             "Firm AUM - Ending Client Assets (from DP-008), at the firm total (Client Assets are read at Dimension Type Total; the slice view of the difference is given by the cause rows); positive means in Firm AUM and not in Client Assets.",
             ["Firm AUM", "Ending Client Assets (from DP-008)"]),
            ("Cause: Client Assets Outside Firm AUM",
             "- Sum of Summary Market Value at the month-end of Account Asset Summary rows (from DP-007) with Own-Product Indicator = N whose Summary Account is in neither advisory slice (not an account of the DP-345 managed account slice, and Summary Source Book not Institutional Portfolio Book (18)): self-directed securities, third-party funds and cash, workplace third-party options and non-managed trust assets.",
             _u("06", "Account Asset Summary", "Summary Account", "Summary As-Of Date", "Summary Source Book",
                "Own-Product Indicator", "Summary Market Value")
             + _u("46", "Model Assignment", "Assigned Account", "Regulatory AUM Classification")),
            ("Cause: Own Funds Held by Own Funds",
             "+ Market Value Base of end-of-day Portfolio Holdings whose Held Instrument has Own Share Class set and whose Holding Portfolio's primary Portfolio Implementation Link names an Implemented Product (fund-of-funds and target-date Portfolio Holdings of own funds): counted gross in the own funds slice (CD-292) and held by no client account.",
             _u("18", "Portfolio Holding", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View")
             + _u("18", "Holding Valuation", "Market Value Base") + _u("17", "Instrument", "Own Share Class")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implemented Product",
                  "Primary Implementation Indicator")),
            ("Firm AUM Net of Own-Fund Holdings (memo)",
             "Firm AUM - Cause: Own Funds Held by Own Funds. Memo only: the published Firm AUM counts fund-of-funds Portfolio Holdings gross (CD-292, ruled 2026-10-14); this line shows what netting would remove.",
             ["Firm AUM", "Cause: Own Funds Held by Own Funds"]),
            ("Cause: Seed Capital",
             "+ Seed Position Value at the month-end of commitments of Seed Commitment Type Seed whose Seeded Product is in the own funds slice (from DP-204): Excluded - Firm Proprietary in Client Assets, counted in full in Firm AUM and never added (CD-346).",
             _u("43", "Seed Capital Commitment", "Seed Capital Commitment ID", "Seed Commitment Type", "Seeded Product",
                "Seeded Share Class")
             + _u("43", "Seed Position Valuation", "Valued Seed Commitment", "Seed Valuation Date", "Seed Position Value")),
            ("Cause: Unloaded Register Positions",
             "+ Per own share class, under DP-007's unit coverage rule (" + _UNIT_RULE + "): (Registered Shares of the month-end 29 Share Register Balance rows of the Fund-Only, Institutional Direct, Networked and firm-client CIT Unitholder categories - Units Held of the Fund Shareholder Positions copied from them, Position Source Book Transfer Agent Register (29), from DP-007) x NAV per Share of the NAV of record (from DP-165): registered units in Counted categories that lack a position row. Units of the omnibus, plan omnibus and nominee categories are never counted here, so each own-fund unit has one cause.",
             _u("29", "Share Register Balance", "Register Share Class", "Register Business Date", "Register Account Category",
                "Registered Shares")
             + _u("06", "Fund Shareholder Position", "Share Class", "Valuation Date", "Units Held", "Position Source Book",
                  "Register Account Category")
             + _u("27", "Share Class NAV", "NAV per Share", "NAV Share Class")),
            ("Cause: Timing & Valuation Basis",
             "+/- Per own share class: sum over counted Fund Shareholder Positions (from DP-007) of Units Held x NAV per Share of the NAV of record at the month-end (from DP-165) - Market Value, for rows valued otherwise: 49 rows of own ETFs at the approved market price (Position Source Book Brokerage Book of Record (49), Valuation NAV blank) and rows whose Valuation Date differs from the Valuation Date of the NAV of record.",
             _u("06", "Fund Shareholder Position", "Position ID", "Units Held", "Market Value", "Valuation Date",
                "Position Source Book", "Valuation NAV")
             + _u("27", "Share Class NAV", "Share Class NAV ID", "NAV per Share")
             + _u("27", "Fund NAV Calculation", "Valuation Date")),
            ("Cause: Advisory Slice Scope & Valuation",
             "+ (Firm AUM Managed Account Slice + Firm AUM Institutional Slice) - Summary Market Value of Account Asset Summary rows with Own-Product Indicator = N of the accounts in either slice (from DP-007): managed accounts outside regulatory AUM, IA mandates at client custodians outside Client Assets, and valuation timing between 18 IBOR and the summary.",
             _u("06", "Account Asset Summary", "Summary Account", "Own-Product Indicator", "Summary Market Value")
             + ["Firm AUM Managed Account Slice", "Firm AUM Institutional Slice"]),
            ("Cause: FX Translation",
             "+/- For share classes whose NAV Currency is not USD: Firm AUM translation at the 22 month-end Spot Rate (FX Rate Date the month-end) of the Observed FX Rate Type whose 09 Approved Usage is AUM Reporting Translation - the USD Market Value DP-007 carries; zero while every own share class is USD.",
             _u("27", "Share Class NAV", "NAV Currency")
             + _u("22", "FX Rate Observation", "Base Currency", "Quote Currency", "Spot Rate", "FX Rate Date",
                  "Observed FX Rate Type")
             + _u("09", "FX Rate Type", "FX Rate Type Code", "Approved Usage")
             + _u("06", "Fund Shareholder Position", "Market Value")),
            ("Explained Difference",
             "Cause: Client Assets Outside Firm AUM + Cause: Own Funds Held by Own Funds + Cause: Seed Capital + Cause: Unloaded Register Positions + Cause: Timing & Valuation Basis + Cause: Advisory Slice Scope & Valuation + Cause: FX Translation.",
             ["Cause: Client Assets Outside Firm AUM", "Cause: Own Funds Held by Own Funds", "Cause: Seed Capital",
              "Cause: Unloaded Register Positions", "Cause: Timing & Valuation Basis",
              "Cause: Advisory Slice Scope & Valuation", "Cause: FX Translation"]),
            ("Unexplained Residual",
             "Gross Difference - Explained Difference, at the firm total; the own-fund part is Own Funds Outside Client Assets less the own-fund causes.",
             ["Gross Difference", "Explained Difference", "Own Funds Outside Client Assets"]),
            ("Reconciled Flag",
             "Y when the absolute Unexplained Residual is within 0.05% of Firm AUM at the firm total; Explained % = Explained Difference / Gross Difference shown beside it.",
             ["Unexplained Residual", "Firm AUM", "Explained Difference", "Gross Difference"]),
            ("Portfolios in No Slice",
             "Count and Total IBOR Market Value of Active portfolios of Portfolio Type Standalone Book that have no effective primary Portfolio Implementation Link to a product, mandate or managed account and no Proprietary Capital Indicator: each is a scope question for DP-140, not an exclusion.",
             _u("18", "Portfolio", "Portfolio ID", "Portfolio Type", "Portfolio Status", "Proprietary Capital Indicator")
             + _u("18", "Portfolio Implementation Link", "Implementing Portfolio", "Implementation Link Type",
                  "Primary Implementation Indicator")
             + _u("18", "Portfolio Valuation Summary", "Valued Portfolio", "Total IBOR Market Value")),
        ],
        inputs=[
            ("27", "Fund NAV Calculation", ["NAV Book", "Valuation Date", "NAV Calculation Source", "NAV Version Number",
                                            "NAV Approval Status", "Fund Net Assets Amount"]),
            ("27", "Share Class NAV", ["Share Class NAV ID", "NAV Share Class", "Parent NAV Calculation", "NAV per Share",
                                       "Shares Outstanding", "NAV Currency"]),
            ("27", "Fund Accounting Book", ["Book Fund", "Book Reporting Currency"]),
            ("01", "Investment Product", ["Product ID", "Vehicle Type"]),
            ("01", "Fund Legal Structure", ["Master-Feeder Role", "Fund of Funds Indicator"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product"]),
            ("18", "Portfolio", ["Portfolio ID", "Portfolio Type", "Portfolio Status", "Business Line",
                                 "Proprietary Capital Indicator"]),
            ("18", "Portfolio Implementation Link", ["Implementing Portfolio", "Implementation Link Type", "Implemented Product",
                                                     "Implemented Mandate", "Managed Account", "Primary Implementation Indicator",
                                                     "Implementation Effective From", "Implementation Effective To"]),
            ("18", "Portfolio Valuation Summary", ["Valued Portfolio", "Valuation As-Of Date", "Valuation View", "Summary Snapshot",
                                                   "Total IBOR Market Value"]),
            ("18", "Portfolio Holding", ["Holding ID", "Holding Portfolio", "Held Instrument", "Holding Date", "Holding View"]),
            ("18", "Holding Valuation", ["Market Value Base"]),
            ("17", "Instrument", ["Instrument ID", "Own Share Class"]),
            ("46", "Model Assignment", ["Model Assignment ID", "Assigned Account", "Assignment Status",
                                        "Regulatory AUM Classification", "Assignment Effective From", "Assignment Effective To"]),
            ("49", "Client Holding", ["Client Holding ID", "Own Share Class Indicator"]),
            ("49", "Client Holding Valuation", ["Market Value in USD"]),
            ("29", "Share Register Balance", ["Register Account", "Register Share Class", "Register Business Date",
                                              "Register Account Category", "Registered Shares"]),
            ("27", "Fund Book Operating Period", ["Operated Book", "Fund Accounting Operating Model",
                                                  "Operating Period Effective From", "Operating Period Effective To"]),
            ("06", "Measure Value", ["Measure", "Period End Date", "Dimension Type", "Dimension Key", "Reporting Period",
                                     "Measure Amount", "Data Basis", "Snapshot"]),
            ("06", "Client Asset Measures", ["Ending Client Assets", "Own-Fund Overlap Amount"]),
            ("06", "Snapshot", ["Snapshot ID", "Snapshot Type", "As-Of Date"]),
            ("06", "Account Asset Summary", ["Summary Account", "Summary As-Of Date", "Summary Source Book", "Summary Holding Type",
                                             "Own-Product Indicator", "Summary Market Value"]),
            ("06", "Fund Shareholder Position", ["Position ID", "Share Class", "Valuation Date", "Position Source Book",
                                                 "Register Account Category", "Aggregation Role", "Units Held",
                                                 "Valuation NAV", "Market Value"]),
            ("06", "Omnibus Look-Through", ["Omnibus Parent Account", "Omnibus Residual Amount"]),
            ("43", "Seed Capital Commitment", ["Seed Capital Commitment ID", "Seed Commitment Type", "Seeded Product",
                                               "Seeded Share Class"]),
            ("43", "Seed Position Valuation", ["Valued Seed Commitment", "Seed Valuation Date", "Seed Position Value"]),
            ("22", "FX Rate Observation", ["Observed FX Rate Type", "Base Currency", "Quote Currency", "FX Rate Date", "Spot Rate"]),
            ("09", "FX Rate Type", ["FX Rate Type Code", "Approved Usage"]),
        ],
        upstream=["DP-165", "DP-008", "DP-007", "DP-345", "DP-304", "DP-300", "DP-580", "DP-142", "DP-140", "DP-204",
                  "DP-143", "DP-097", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness=("Business day 9 after month-end: the day after DP-008 locks (business day 8), once DP-165 has the month-end "
                    "NAVs of record and DP-345 its managed account slice"),
        history=("Every month-end since go-live, one version per DP-008 snapshot, DP-165 NAV version and DP-345 slice version; a "
                 "restatement of any input adds a version and keeps the prior one; Firm AUM kept indefinitely (Form ADV Part 1A "
                 "Item 5.F support, Rule 204-2), the bridge 10 years"),
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "Dashboard"],
        dq_rules=[
            "Every fund resolves to DP-004 with a Fund Accounting Book in DP-165, every portfolio to DP-140, every Assigned Account to a DP-093 account of Account Type Managed Advisory Account (never an 18 portfolio), and every Seeded Product to DP-004.",
            "At a month-end a portfolio or account is in at most one Firm AUM slice: only Portfolio Type Standalone Book portfolios enter the institutional slice, one counted portfolio per Implemented Mandate or Managed Account, a portfolio whose primary link names an Implemented Product is never in it, an account with an active Model Assignment is never an Implementing Portfolio's Managed Account, and the Model Assignment and implementation link periods used do not overlap.",
            "Firm AUM Own Funds Slice equals DP-165's Month-End Fund Net Assets at NAV for the same funds to the unit, Firm AUM Managed Account Slice equals DP-345's published value, Ending Client Assets and Own-Fund Overlap Amount (from DP-008) equal the locked DP-008 snapshot, otherwise the run stops; and the absolute Unexplained Residual is within 0.05% of Firm AUM at the firm total, otherwise the month is published with Reconciled Flag = N and escalated to the slice owners.",
            "Every slice, cause and residual row names its month-end and its slice, fund, share class or portfolio, and every fund shareholder position, seed commitment and portfolio holding is assigned to at most one cause.",
            "Rows are published at firm, slice, fund, share class and portfolio grain only; the 49 and 06 account-level rows are read to aggregate and no account or household row is published.",
            "The run uses only a DP-008 snapshot with Snapshot Type Final or Restated and NAVs of record; a later snapshot, NAV version or DP-345 restatement creates a new version of the month, Firm AUM and Client Assets are never summed, and the overlap is subtracted only in Own Funds Outside Client Assets.",
        ],
        notes=("Certified numbers (CW-011; lead ruling 2026-10-15): Firm AUM, Firm AUM Own Funds Slice, Firm AUM Managed Account "
               "Slice and Firm AUM Institutional Slice, named as semantic_model/register.CERTIFIED_WEALTH reads them (SM-11); "
               "defined here only. Reads Month-End Fund Net Assets at NAV and NAV per Share from DP-165, Ending Client "
               "Assets and Own-Fund Overlap Amount from DP-008, the managed account slice from CLA-A DP-345, seed from DP-204; "
               "the own-fund overlap is netted here only (Own Funds Outside Client Assets). Slice owners: the Head of Fund "
               "Accounting ratifies the own funds and institutional slices, the Head of Managed Account Operations the managed "
               "account slice (CW-011). Books: managed accounts are 15 accounts managed in 46 valued from 49 Client Holding "
               "(DP-300), never 18 portfolios; IA mandates are 18 Portfolio Holding (DP-142). Operating model (CD-297): the NAV "
               "of record may come from the fund accounting platform or an administrator per Fund Book Operating Period; this "
               "product reads DP-165's NAV of record either way and its grain does not change. PII tier: none at publication. "
               "pii = N: the 49 Client Holding, 46 Model Assignment and 06 account-level attributes noted as PII are read only "
               "to aggregate to slice, fund and firm totals; no account- or household-level row is published (DQ5), so the "
               "validator's PII warning is accepted. "
               "Boundaries: ABOR to IBOR breaks are DP-172's and the GIPS firm assets DP-158's (both comparisons dropped from "
               "this bridge); the 06 data checks are DP-495's; the capital stock proof is DP-181's; Firm AUM by channel and "
               "offering for distribution decisions is DIS DP-490 and DP-496. "
               "Acceptance question 1 (plan section 8.5): answered by Firm AUM, Firm AUM Own Funds Slice, Firm AUM Managed "
               "Account Slice and Firm AUM Institutional Slice reconciled to Ending Client Assets (from DP-008); mastering "
               "domains 27, 46, 49, 18 and 06 (16 and 29 through DP-008 and DP-007). "
               "Requirement on CLA-A DP-345 (not yet specified; listed upstream by id; lead ruling on the F5 fix pass): DP-345 "
               "publishes the operational measure 'Managed Account Assets (Discretionary and Non-Discretionary)' and defines "
               "the managed account slice there, once; DP-241 certifies 'Firm AUM Managed Account Slice' as that value read "
               "from DP-345, with no recomputation from 46 or 49. DP-345's measure must be: for each month-end, the 15 accounts "
               "with a 46 Model Assignment of Assignment Status Active in force (Assignment Effective From / To) and Regulatory "
               "AUM Classification Discretionary or Non-Discretionary; Market Value in USD of their 49 Client Holdings of "
               "Client Holding View End of Day whose Own Share Class Indicator is not set (own share classes are in the own "
               "funds slice); plus client cash under DP-007's client cash rule (Account Cash Balance at Balance Basis "
               "Settlement Date, Cash Balance Type Free Credit Balance, Sweep Balance or Short Sale Proceeds), less the Margin "
               "Debit Balance of the one End of Day Margin Balance Snapshot, subtracted once. DP-345 publishes it with the "
               "Assigned Account and Regulatory AUM Classification keys, and must not list DP-241 upstream. "
               "Tailoring lever: Firm AUM slice definitions. Reference default: own funds at NAV excluding feeders, managed "
               "accounts in regulatory AUM (Discretionary and Non-Discretionary), institutional mandates and OCIO at IBOR, "
               "own-fund Client Holdings and Portfolio Holdings removed from the advisory slices. Tailoring lever: fund-of-funds netting. Reference default: "
               "gross, with the memo line (CD-292). Tailoring lever: participant managed accounts. Reference default: outside "
               "the managed account slice unless DP-345 includes them. Tailoring lever: IA mandates at client custodians in "
               "Client Assets. Reference default: included (06 SME question 3). The unloaded-units cause follows DP-007's unit "
               "coverage rule: plan omnibus units of recordkept plans and nominee-held IA mandate units are already in Client "
               "Assets and the overlap and are never counted as unloaded. "
               "Taxonomy gap: no attribute names the firm reporting currency or the FX rate type approved for AUM; 09 FX Rate "
               "Type Approved Usage is read. Taxonomy gap: no 29 Register Account Category or 06 Aggregation Role value marks "
               "an own fund's register balance in another own fund; it is assumed to be Excluded - Firm Proprietary. Taxonomy gap: no "
               "object holds a reconciliation commentary or sign-off for a cause or residual. "
               "Drafting assumptions: the tolerance 0.05% of Firm AUM; Assignment Status Active; Portfolio Type "
               "Standalone Book; Seed Commitment Type Seed (Incubation Account commitments sit in proprietary books outside "
               "Firm AUM). Decisions: CW-007, CW-011, CW-050, CW-142, CW-206, CW-209, "
               "CD-292, CD-297, CD-320, CD-330, CD-335, CD-346. "
               "WP1 re-scope (CW-206): renamed Firm AUM & Client Assets Reconciliation; owner domain 27 and functions as "
               "registered; it now certifies Firm AUM and its slices instead of reading them from DP-165. Measures renamed: "
               "'Firm AUM (from DP-165)' to 'Firm AUM' (read by CERTIFIED_WEALTH; the SM-11 metric Firm AUM and CERTIFIED "
               "'Firm AUM' still point at DP-165 and must be re-pointed here), 'Fund Net Assets Slice (from DP-165)' to 'Firm "
               "AUM Own Funds Slice', 'Mandate & SMA Slice (from DP-165)' to 'Firm AUM Institutional Slice' (SM-11 'Mandate & "
               "SMA Market Value' reads DP-165 today), 'Attributed AUM (from DP-008)' to 'Ending Client Assets (from DP-008)'; "
               "added 'Firm AUM Managed Account Slice', 'Own-Fund Overlap Amount (from DP-008)', 'Own Funds Outside Client "
               "Assets', 'Cause: Client Assets Outside Firm AUM', 'Cause: Own Funds Held by Own Funds' and 'Cause: Advisory "
               "Slice Scope & Valuation'. Kept by name (SM-11 reads them): Gross Difference, Cause: Seed Capital, Cause: "
               "Unloaded Register Positions, Cause: Timing & Valuation Basis, Cause: FX Translation, Explained Difference, "
               "Unexplained Residual, Reconciled Flag, Firm AUM Net of Own-Fund Holdings (memo), Portfolios in No Slice. "
               "Dropped (SM-11 readers to re-point or retire): Cause: Mandate & SMA Assets Outside Attribution, Cause: "
               "Model-Delivery Assets (model-delivery assets are outside both families), Cause: Feeder Fund Exclusion (feeder "
               "holdings are in the master's net assets and in Client Assets alike), Cause: Suspense & Unattributed Amounts "
               "(omnibus residuals are counted in Client Assets), Portfolio Market Value (from DP-142), IBOR to NAV Difference "
               "(Pooled Funds) (DP-172), Own-Fund Holdings in Mandates (now inside the slice formulas), Proprietary Books "
               "Outside Firm AUM and GIPS Firm Assets Comparison (memo) (DP-158). Inputs dropped: 27 ABOR to IBOR "
               "Reconciliation, 32 GIPS Firm Assets, 06 Asset Measures, Flow Treatment Rule, Attribution Record, "
               "Sponsor-Reported Assets and Unattributed Item, 01 Investment Product Product Legal Name; the candidate's 46 "
               "Managed Account Composite and Membership are read by DP-145 and DP-304 instead. Upstream DP-172 and DP-158 "
               "dropped; DP-345, DP-304, DP-300 and DP-580 added. Further readers for the lineage pass: the SM-11 aum_bridge "
               "table facts fund_net_assets_slice ('Fund Net Assets Slice (from DP-165)'), mandate_sma_slice ('Mandate & SMA "
               "Slice (from DP-165)'), firm_aum ('Firm AUM (from DP-165)') and attributed_aum ('Attributed AUM (from DP-008)') "
               "re-point to Firm AUM Own Funds Slice, Firm AUM Institutional Slice, Firm AUM and Ending Client Assets (from "
               "DP-008); SM-11 must publish or exclude the new measures listed above. Re-cut for the lineage pass: the DP-241 "
               "logical model (models_e8c_cross_area) still holds 27 ABOR to IBOR Reconciliation, 32 GIPS Firm Assets, 06 "
               "Asset Measures, Flow Treatment Rule, Sponsor-Reported Assets and Unattributed Item; drop them and add 29 Share "
               "Register Balance, 27 Fund Book Operating Period, 46 Model Assignment and the 06 Account Asset Summary and "
               "Client Asset Measures. The W4 re-point line and the 'owns no certified number' statement are superseded."),
    ),
}
