"""Data product specifications: Wave WP1F (foundational), group F4 'channels' of the wealth-manager rework.

Products (owning domain):
- DP-001 Intermediary Partner Master (05; re-scoped in place, absorbs DP-002, which retires under CW-202)
- DP-003 Institutional, Consultant & Plan Relationships (12; re-scoped in place)
- DP-005 Intermediary Agreements & Platform Placement (05; re-scoped in place, shrunk to the thin intermediary channel)
- DP-480 Cost Allocation & Management Hierarchy (10; new)
- DP-481 Competitor Offerings & Price Observations (11; new)

WP1 decisions applied: CW-202 (the three re-scopes), CW-132, CW-133, CW-134, CW-138 (restored 05, 12 and 16 objects and
the three coverage records), CW-150 (personal data in 05 and 12), CW-157, CW-159, CW-243 (household and advisor economics
are restricted views, CD-344), CW-160 (the retail competitor set), CW-240 (DIS+FDN successors), CW-007 and CW-011 (no
book of record and no certified number is mastered here). The DP-075 ruling (WP1_Method.md section 2) is applied by not
specifying DP-075: it stays live on its current spec until DP-101 absorbs its lineage inputs (CW-247), so nothing in this
module reads or re-points it. Program-lead rulings applied: prospects stay 02 Party references (no Institutional Client
row for a prospect); 11 Mandate Search Event.Asset Owner is not an Institutional Client (CW-133); household-level cost
allocation is restricted under CD-344 (CW-243). See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-001": dict(
        definition=("The master of the thin intermediary channel's partners and the people in them: partner firms "
                    "(05 Distributor Firm with its Form ADV Profile), their regulatory and operating hierarchy nodes, branches "
                    "and offices, external advisor teams and memberships, home-office research contacts (05 Gatekeeper "
                    "Profile), and the external financial professionals with their practice profile, employment "
                    "affiliations, vendor classifications and the firm's partner coverage. Every row is a role profile keyed "
                    "by the 02 Party (PTY-) that DP-240 conforms; party identity, legal parents and identifiers are taken "
                    "from DP-240 by key and never remastered. It conforms the intermediary firm and external advisor once "
                    "(CONCEPT_OWNERSHIP rows 'Distributor Hierarchy' and the CW-132 role profiles, 05), so that intermediary "
                    "flows, placement, payments and coverage name the same partner and advisor. It owns no certified "
                    "metric family."),
        business_questions=[
            "Which partner firms are active in the intermediary channel today, in which Distribution Channel, and are their regulatory identifiers and ultimate parents complete?",
            "How is each partner firm organized into hierarchy nodes, branches and offices, and are any nodes orphaned from their firm?",
            "Which external financial professionals are active and registered, at which firm and office, in which team, and whose profiles are incomplete?",
            "Which external advisors changed firms recently, and how long has each been at the current firm?",
            "Which partner firms, external advisors, consultants and recordkeepers have a primary coverage assignment, and which active firms have none?",
        ],
        grain=("Intermediary party (partner firm, branch or office, advisor team, home-office contact or external financial "
               "professional) x role profile x role effective period, with hierarchy nodes, team memberships, employment "
               "affiliations, external classifications and partner coverage assignments as effective-dated companion "
               "bridges; SCD type 2"),
        dimensions=["Party (DP-240 identity of the intermediary party)", "Party type", "Party role type",
                    "Distributor firm", "Distribution channel", "Firm registration type", "Hierarchy type and level",
                    "Branch / office and branch type", "Advisor team", "External financial professional",
                    "Professional type and registration status", "Advisor business model", "Partner coverage role",
                    "Covering employee (DP-192)", "Ultimate parent", "Primary regulator", "Country", "Effective date"],
        measures=[
            ("Active Firm Count",
             "Count of distinct Distributor Firm Party whose 02 Party has Party Status = Active and an open 02 Party Role "
             "with Role Type = Distributor Firm and Role Status = Active (Role Effective To blank or after the as-of date), "
             "joined on Distributor Firm Party = Party ID = Role Party.",
             _u("05", "Distributor Firm", "Distributor Firm Party") + _u("02", "Party", "Party ID", "Party Status")
             + _u("02", "Party Role", "Role Party", "Role Type", "Role Status", "Role Effective To")),
            ("Active Firms by Distribution Channel",
             "Active Firm Count grouped by Distributor Firm.Distribution Channel and Firm Registration Type on the as-of date.",
             _u("05", "Distributor Firm", "Distribution Channel", "Firm Registration Type") + ["Active Firm Count"]),
            ("Identifier Coverage %",
             "Active firms with a Firm CRD Number, or an LEI with LEI Registration Status = Issued / Active Firm Count.",
             _u("02", "US Regulatory Identifier", "Firm CRD Number") + _u("02", "LEI Record", "LEI", "LEI Registration Status")
             + ["Active Firm Count"]),
            ("Ultimate Parent Coverage %",
             "Active firms with an open 02 Legal Entity Hierarchy row (Subsidiary Party = the firm, Parent Relationship Basis "
             "= Accounting Consolidation, Hierarchy Effective From on or before and Hierarchy Effective To blank or after the "
             "as-of date) whose Ultimate Parent is populated / Active Firm Count.",
             _u("02", "Legal Entity Hierarchy", "Subsidiary Party", "Ultimate Parent", "Parent Relationship Basis",
                "Hierarchy Effective From", "Hierarchy Effective To") + ["Active Firm Count"]),
            ("Form ADV Currency %",
             "Active firms with Firm Registration Type in (SEC-Registered Investment Adviser, Dual Registrant (BD + RIA)) whose "
             "Form ADV Filing Date is within 15 months of the as-of date / active firms of those registration types.",
             _u("05", "Form ADV Profile", "Form ADV Filing Date") + _u("05", "Distributor Firm", "Firm Registration Type")
             + ["Active Firm Count"]),
            ("Orphan Node Count",
             "Count of open Hierarchy Node rows (Node Effective To blank or after the as-of date) whose Hierarchy Level is not "
             "Firm and whose Parent Node is blank or is not an open node of the same Hierarchy Type, by Hierarchy Type.",
             _u("05", "Hierarchy Node", "Hierarchy Node Party", "Hierarchy Type", "Hierarchy Level", "Parent Node",
                "Node Effective From", "Node Effective To")),
            ("Active Branch Count",
             "Count of distinct Branch Party with an open 02 Party Role (Role Party = Branch Party) of Role Type = Branch / "
             "Office and Role Status = Active, by Branch Type and by the firm reached by walking the branch's open Hierarchy "
             "Node (Hierarchy Node Party = Branch Party) through Parent Node to Hierarchy Level = Firm.",
             _u("05", "Branch / Office", "Branch Party", "Branch Type")
             + _u("02", "Party Role", "Role Party", "Role Type", "Role Status")
             + _u("05", "Hierarchy Node", "Hierarchy Node Party", "Hierarchy Level", "Parent Node", "Node Effective To")),
            ("Active Advisor Count",
             "Count of distinct Financial Professional Party with Party Status = Active, Registration Status in (Active - BD, "
             "Active - IA, Active - BD and IA), an open 02 Party Role Role Type = Financial Advisor, and an open Employment "
             "Affiliation (Affiliation End Date blank or after the as-of date) whose Employing Firm is an active firm.",
             _u("05", "Financial Professional", "Financial Professional Party", "Registration Status")
             + _u("02", "Party", "Party Status") + _u("02", "Party Role", "Role Type", "Role Effective To")
             + _u("05", "Employment Affiliation", "Affiliated Professional", "Employing Firm", "Affiliation End Date")
             + ["Active Firm Count"]),
            ("Profile Completeness %",
             "Per active external advisor: populated critical items (Professional Type, Registration Status, an Individual CRD "
             "Number, an open Employment Affiliation with Office of Record, an Advisor Practice Business Model with Practice "
             "Data As-Of Date within 180 days, the window DQ6 uses) / 5; reported as the average over Active Advisor Count.",
             _u("05", "Financial Professional", "Professional Type", "Registration Status")
             + _u("02", "US Regulatory Identifier", "Individual CRD Number")
             + _u("05", "Employment Affiliation", "Office of Record")
             + _u("05", "Advisor Practice", "Business Model", "Practice Data As-Of Date") + ["Active Advisor Count"]),
            ("Contactable Flag",
             "Y for an external advisor when the party's Privacy Profile has Do Not Contact Indicator = N and Affiliate "
             "Marketing Opt-Out Indicator = N and at least one open Contact Point (Contact Point Party = the advisor, Contact "
             "Point Effective To blank or after the as-of date) has Contact Point Verified Indicator = Y.",
             _u("02", "Privacy Profile", "Do Not Contact Indicator", "Affiliate Marketing Opt-Out Indicator")
             + _u("02", "Contact Point", "Contact Point Party", "Contact Point Verified Indicator",
                  "Contact Point Effective To") + _u("05", "Financial Professional", "Financial Professional Party")),
            ("Recent Move Flag",
             "Y for an external advisor with a Move Detected Date in the last 90 days, or an Employment Affiliation whose "
             "Affiliation End Date is in the last 90 days with Affiliation Change Reason in (Moved to Another Firm, Breakaway "
             "to Independent RIA, Joined Hybrid / Independent BD, Team Lift-Out).",
             _u("05", "Employment Affiliation", "Affiliated Professional", "Move Detected Date", "Affiliation End Date",
                "Affiliation Change Reason")),
            ("Advisor Moves in Period",
             "Count of Employment Affiliation rows whose Affiliation End Date falls in the period and whose Affiliation Change "
             "Reason is one of the Recent Move Flag values, by the Employing Firm left and Affiliation Change Reason.",
             _u("05", "Employment Affiliation", "Employing Firm", "Affiliation End Date", "Affiliation Change Reason")),
            ("Tenure at Firm (Years)",
             "(As-of date - Affiliation Start Date) / 365.25 on the advisor's open Employment Affiliation with Affiliation "
             "Type in (Employee, Independent Contractor).",
             _u("05", "Employment Affiliation", "Affiliation Start Date", "Affiliation End Date", "Affiliation Type")),
            ("Active Advisor Teams",
             "Count of distinct Advisor Team Party with at least one open Team Membership (Team Membership Effective To blank or "
             "after the as-of date), with the average count of open members per team.",
             _u("05", "Advisor Team", "Advisor Team Party")
             + _u("05", "Team Membership", "Team", "Team Member", "Team Membership Effective From",
                  "Team Membership Effective To")),
            ("Home-Office Contacts by Function",
             "Count of distinct Gatekeeper Party with an open 02 Party Role Role Type = Gatekeeper / Research, by Gatekeeper "
             "Function and Asset Class Coverage.",
             _u("05", "Gatekeeper Profile", "Gatekeeper Party", "Gatekeeper Function", "Asset Class Coverage")
             + _u("02", "Party Role", "Role Type")),
            ("Vendor Classification Currency %",
             "Active advisors whose latest External Classification (any Classification Vendor) has a Vendor Classification "
             "As-Of Date within 180 days of the as-of date / Active Advisor Count.",
             _u("05", "External Classification", "Classified Party", "Classification Vendor",
                "Vendor Classification As-Of Date") + ["Active Advisor Count"]),
            ("Covered Partner Count",
             "Count of distinct Covered Party with an open Partner Coverage Assignment (Coverage Effective To blank or after the "
             "as-of date) with Primary Coverage Indicator = Y, by Partner Coverage Role.",
             _u("05", "Partner Coverage Assignment", "Covered Party", "Partner Coverage Role", "Primary Coverage Indicator",
                "Coverage Effective From", "Coverage Effective To")),
            ("Active Firms Without Primary Coverage",
             "Active Firm Count minus the active firms that are a Covered Party of an open primary Partner Coverage Assignment.",
             _u("05", "Partner Coverage Assignment", "Covered Party", "Primary Coverage Indicator")
             + ["Active Firm Count"]),
        ],
        inputs=[
            ("05", "Distributor Firm", ["Distributor Firm Party", "Distribution Channel", "Firm Registration Type",
                                        "Number of Registered Representatives", "Clearing Firm", "Primary Custodian",
                                        "Product Platforms Offered", "Firm Operating Model"]),
            ("05", "Form ADV Profile", ["Regulatory Assets Under Management", "Advisory Client Types", "Form ADV Filing Date"]),
            ("05", "Hierarchy Node", ["Hierarchy Node Party", "Hierarchy Type", "Hierarchy Level", "Parent Node",
                                      "Node Effective From", "Node Effective To"]),
            ("05", "Branch / Office", ["Branch Party", "Branch Type", "Supervising OSJ"]),
            ("05", "Advisor Team", ["Advisor Team Party", "Team Rep Code"]),
            ("05", "Team Membership", ["Team", "Team Member", "Team Member Role", "Team Membership Effective From",
                                       "Team Membership Effective To"]),
            ("05", "Gatekeeper Profile", ["Gatekeeper Party", "Gatekeeper Function", "Asset Class Coverage"]),
            ("05", "Financial Professional", ["Financial Professional Party", "Professional Type", "Professional Designations",
                                              "Qualification Exams", "Registration Status"]),
            ("05", "Advisor Practice", ["Business Model", "Retirement Plan Practice Indicator", "Practice Data As-Of Date"]),
            ("05", "Employment Affiliation", ["Affiliated Professional", "Employing Firm", "Office of Record", "Affiliation Type",
                                              "Affiliation Start Date", "Affiliation End Date", "Affiliation Change Reason",
                                              "Move Detected Date"]),
            ("05", "External Classification", ["Classified Party", "Classification Vendor", "Vendor Channel",
                                               "Vendor Advisor Segment", "Vendor Classification As-Of Date"]),
            ("05", "Partner Coverage Assignment", ["Partner Coverage Assignment ID", "Covered Party", "Covering Employee",
                                                   "Partner Coverage Role", "Primary Coverage Indicator",
                                                   "Coverage Effective From", "Coverage Effective To"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Relationship Stage",
                             "Merged Into Party", "Primary Country"]),
            ("02", "Individual", ["Given Name", "Family Name", "Preferred Name", "Date of Death"]),
            ("02", "Organization", ["Legal Name", "Legal Jurisdiction", "Primary Regulator"]),
            ("02", "Legal Entity Hierarchy", ["Subsidiary Party", "Direct Parent", "Ultimate Parent", "Parent Relationship Basis",
                                              "Hierarchy Effective From", "Hierarchy Effective To"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status", "Role Effective From", "Role Effective To"]),
            ("02", "Party Identifier", ["Identified Party", "Identifier Value", "Identifier Scheme", "Identifier Status",
                                        "Identifier Effective From"]),
            ("02", "Contact Point", ["Contact Point ID", "Contact Point Party", "Contact Point Verified Indicator",
                                     "Contact Point Effective To"]),
            ("02", "Privacy Profile", ["Do Not Contact Indicator", "Affiliate Marketing Opt-Out Indicator"]),
            ("02", "LEI Record", ["LEI", "LEI Registration Status"]),
            ("02", "US Regulatory Identifier", ["Firm CRD Number", "Individual CRD Number", "SEC File Number"]),
            ("02", "Market Infrastructure & Vendor Identifier", ["NSCC Participant Number", "DTC Participant Number",
                                                                 "Transfer Agent Dealer Number"]),
        ],
        upstream=["DP-240", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET each business day, with vendor advisor files (Discovery Data, Broadridge) loaded within 2 business days of receipt",
        history="SCD type 2 on every role profile, hierarchy node, team membership, affiliation and coverage assignment for 7 years; month-end versions frozen for flow attribution and coverage reporting",
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Reverse ETL to CRM"],
        dq_rules=[
            "Every Distributor Firm Party, Branch Party, Advisor Team Party, Gatekeeper Party, Financial Professional Party and Covered Party resolves to a DP-240 party with Merged Into Party blank that holds the matching open 02 Party Role (Distributor Firm, Branch / Office, Advisor Team, Gatekeeper / Research, Financial Advisor), and every Covering Employee resolves to an active DP-192 employee.",
            "Hierarchy Node, Team Membership, Employment Affiliation and Partner Coverage Assignment periods end on or after they start, and no party has two overlapping open Hierarchy Node rows of the same Hierarchy Type or two overlapping open primary Partner Coverage Assignments with the same Partner Coverage Role.",
            "Each active firm has exactly one open Hierarchy Node with Hierarchy Level = Firm in the Regulatory (CRD) hierarchy, walking Parent Node from any open node reaches that Firm node within six steps without a cycle, and no two active firms share an active Firm CRD Number or LEI.",
            "Distribution Channel and Firm Registration Type are populated on 100% of active firms, and Professional Type and Registration Status on 100% of active external advisors.",
            "External advisor rows (Financial Professional, Advisor Practice, Employment Affiliation, Team Membership, External Classification, Partner Coverage Assignment, and the Individual, Contact Point and Privacy Profile columns of a party with Party Type = Individual) are returned only to the entitled intermediary-distribution roles, and a query from the firm-only view returns no row whose Party Type = Individual; Contactable Flag is the only privacy column published.",
            "The daily build completes by 6am ET; an External Classification or Advisor Practice row whose as-of date is older than 180 days is flagged stale and excluded from Profile Completeness % numerators.",
        ],
        notes=("Master concept: the CONCEPT_OWNERSHIP rows 'Distributor Hierarchy (firm > office > branch > team > advisor)' and "
               "the CW-132 role-profile rows Distributor Firm, Hierarchy Node, Branch / Office, Advisor Team, Gatekeeper "
               "Profile, Financial Professional, Employment Affiliation, External Classification, Team Membership and Partner "
               "Coverage Assignment (05, PCVG-). It is the source of the SM-00 intermediary firm and external advisor "
               "dimensions (distributor_firm, distributor_office, advisor_team, and the external advisor that SM-00 and SM-02 "
               "read from DP-002 today) and of the WP2 conformed dimension 'Intermediary firm and external advisor'. The party "
               "core (Party, Organization, Legal Entity Hierarchy, identifiers) is DP-240's: it is read by PTY- key so that "
               "the Party entity, which 82 logical models conform, keeps its backing objects. "
               "Certified numbers: none owned or read. Own-fund client assets and flows through a partner are DP-008's, read by "
               "DP-493; this product carries only the partner and advisor keys they slice by. "
               "PII tier: identity (professional data of external advisors, team members and home-office contacts, CW-150). "
               "Firm, branch and hierarchy rows of organization parties carry none and can be published in a firm-only view at "
               "Confidential; Disclosure Events Count (restricted, CW-150) is not read. No financial or special-category data. "
               "Boundaries: the firm's own advisors are DP-009 (03 Advisor) and its employees DP-192; 05 Partner Coverage "
               "Assignment covers partners only, client coverage is 03 Party Coverage Assignment (DP-009) and servicing roles "
               "12 Service Coverage Assignment (CW-138). Consultant profiles and their advisory relationships are published by "
               "DP-003, agreements, shelf and dealer set-up by DP-005, payments by DP-487. Legal ownership (02 Legal Entity "
               "Hierarchy, Ultimate Parent) and the operating hierarchy (05 Hierarchy Node) are different trees; partner "
               "totals roll up by Ultimate Parent, flow attribution by Hierarchy Node. 05 Gatekeeper Profile is held here as "
               "the partner's home-office research and platform contact, at the thin depth of CW-013. The Partner Status and "
               "Partner Since Date attributes of Distributor Firm and Branch CRD Number of Branch / Office are Derived copies "
               "of 02 and are not read; the 02 Party Role and Party Identifier masters are read instead. Advisor Practice "
               "Practice AUM and Number of Client Households (vendor estimates) and Form ADV Profile Compensation Arrangements "
               "are not read; the Form ADV attribute Regulatory Assets Under Management is the adviser's regulatory assets "
               "under Form ADV Item 5.F, never Firm AUM. Contact points and privacy opt-outs stay mastered in 02 (DP-240): this "
               "product reads only the verified-contact and opt-out indicators behind Contactable Flag and the Individual name "
               "columns the semantic advisor tables hide; household membership and segment assignments of external advisors "
               "are not read (DP-240 party core). "
               "Tailoring lever: depth of the intermediary channel (05 SME 1). Reference default: thin (firms, external "
               "advisors at practice level); restoring territories, crediting and advisor scoring from wholesale-v1.0 adds them "
               "to the consumer products, not here. "
               "Tailoring lever: external advisors held individually (05 SME 4). Reference default: yes, where a feed or vendor "
               "identifies them; firm-level only drops Financial Professional, Advisor Practice, Employment Affiliation, Team "
               "Membership and the advisor measures, and the product becomes PII N. "
               "Tailoring lever: a firm without an intermediary channel (CW-132). Reference default: channel present; without "
               "it the product is retired and the 02 roles stay. "
               "Taxonomy gap: 05 Branch / Office has no link to its Distributor Firm other than the Hierarchy Node chain; the "
               "branch's firm is derived by walking Parent Node to Hierarchy Level = Firm. "
               "Taxonomy gap: 05 Hierarchy Node has no attribute naming the Distributor Firm whose tree it belongs to; Active "
               "Branch Count and Orphan Node Count derive it from the chain. "
               "Drafting assumptions: Registration Status 'active' values (Active - BD, Active - IA, Active - BD and IA); move "
               "reasons for Recent Move Flag; 90-day move window; 15-month Form ADV window (annual amendment within 90 days of "
               "fiscal year end plus slack); 180-day vendor currency window; Affiliation Type values counted for tenure; "
               "Role Status value 'Active'. "
               "Decisions: CW-202, CW-132, CW-138, CW-150, CW-013, CW-140, CW-164, CW-021. "
               "WP1 re-scope (CW-202): renamed from 'Distributor Hierarchy' to 'Intermediary Partner Master'; owning domain 02 "
               "-> 05; owner Head of Distribution Data Management -> Head of Intermediary Distribution; primary function "
               "FN-74. Absorbs retired DP-002 Financial Professional Profile. Continuity rule (lead, F4 fix pass): every "
               "attribute a live logical model or semantic table reads is kept. Inputs added: the twelve 05 objects listed "
               "above; from DP-002, 02 Individual (Given Name, Family Name, Preferred Name, Date of Death; hidden by SM-00 "
               "advisor), 02 US Regulatory Identifier Individual CRD Number, 02 Contact Point (Contact Point ID, Contact Point "
               "Party, Contact Point Verified Indicator, Contact Point Effective To) and 02 Privacy Profile (Do Not Contact "
               "Indicator, Affiliate Marketing Opt-Out Indicator). Kept for live readers: 02 Party Relationship Stage (SM-00 "
               "distributor_firm, SM-00 and SM-02 advisor), 02 Organization Legal Jurisdiction (SM-00 distributor_firm), 02 "
               "Legal Entity Hierarchy Parent Relationship Basis and Hierarchy Effective From (SM-00 distributor_firm_parent "
               "and the models_pilot_er.py pk) and 02 Party Identifier Identifier Effective From (models_pilot_er.py pk). "
               "Inputs dropped, with reader and successor: 09 Code Mapping and 09 Code List (models_pilot_er.py 'Code Mapping' "
               "and 'Code List' entities; successor DP-013, which masters both); 02 Party Party Origin, 02 Organization Legal "
               "Form, 02 Legal Entity Hierarchy (no other attribute) and 02 Party Identifier Identifier Effective From for "
               "DP-002 (no live reader found). DP-002 inputs not carried, with reader and successor: 02 Segment Assignment "
               "(SM-00 advisor_segment, models_f1.py DP-002 'Segment Assignment'; successor 05 External Classification Vendor "
               "Advisor Segment in this product, or DP-240 for a firm segmentation scheme), 02 Household and Household "
               "Membership (SM-00 advisor hidden Household Name, models_f1.py 'Household Membership'; household rows are "
               "filtered out of the advisor table, successor DP-240), 02 Party Relationship (models_f1.py DP-002 'Party "
               "Relationship'; successor DP-240), 02 Postal Address and the other Contact Point columns (models_f1.py DP-002 "
               "'Contact Point'; successor DP-240, with the Contact Point entity kept here on Contact Point ID for the "
               "Contactable Flag columns). Measures kept by name: Active Firm Count (redefined on the 05 Distributor Firm "
               "profile with the 02 role; SM-00 metric source), Identifier Coverage % and Ultimate Parent Coverage % (SM-00 "
               "exclusion list, as product quality checks). Measures taken from DP-002 by name: Active Advisor Count and "
               "Profile Completeness % (SM-00 metric sources today on DP-002; lineage re-points them to DP-001), Contactable "
               "Flag (restored: read by the SM-00 advisor table's contactable column), Recent Move Flag and Tenure at Firm "
               "(Years) (dropped from DP-002 at W1, restored on 05). Measure restored from the wholesale DP-001: Orphan Node "
               "Count. DP-002 measures dropped: Household Advisor Count, Linked Advisor Count and Primary Contact Point "
               "Coverage %; all three are in the SM-00 exclusion list (not published in the semantic layer), so no live reader "
               "is lost. Entities for the lineage pass: Financial Professional (21 conformers), Employment Affiliation (5), "
               "External Classification (1) and Team Membership (1) are now backed by the 05 objects of the same name. The "
               "Financial Professional entity's key changes from 02 Party ID to 05 Financial Professional Party (the same PTY- "
               "value); the identity columns its readers use stay on the DP-001 'Party' entity, because 02 Party can back only "
               "one entity: SM-00 advisor (Party Display Name, Individual CRD Number, Party Status, Relationship Stage, "
               "Contactable Flag, hidden Individual names, Date of Death and Do Not Contact Indicator), SM-02 advisor (Party "
               "Display Name, Relationship Stage) and SM-04 plan_advisor (Party Display Name) reach them through the "
               "Financial Professional Party = Party ID join. The DP-001 'Party' entity keeps 02 Party, Organization, US "
               "Regulatory Identifier and Market Infrastructure & Vendor Identifier with pk Party ID; 'Party Role', 'Legal "
               "Entity Hierarchy' and 'Party Identifier' keep their objects and full pks. Earlier stage lines (W1 re-point "
               "CW-021, CW-902; W4 CW-132) are superseded: the restored 05 objects they deferred are now read."
               " WP2 retirement sweep (CW-209): SM-02 and SM-04, named above as readers, are retired and their definition files deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-003": dict(
        definition=("The golden record of the firm's institutional relationships: institutional advisory and OCIO clients "
                    "(12 Institutional Client) with their investment policy statement versions and service relationships, "
                    "the investment consultants (05 Consultant Profile) and the clients each advises, and the plan sponsors, "
                    "recordkeepers, plan profiles and plan fiduciary and service roles of retirement plans (16), joined to the "
                    "mandates (01) and institutional accounts (15) each client holds. Every profile is a role profile keyed "
                    "by the 02 Party that DP-240 conforms; prospects stay 02 parties with the Prospect role and get no "
                    "Institutional Client row. It conforms the institution, consultant and plan sponsor once (CONCEPT_OWNERSHIP "
                    "rows 'Institutional Client' (12), 'Consultant Profile' (05) and 'Plan Fiduciary and Service Role "
                    "Assignment' (16)) so that institutional servicing, pipeline, sponsor servicing and the total client "
                    "relationship name the same institution. It owns no certified metric family."),
        business_questions=[
            "Which institutional clients do we serve, by client type and servicing segment, and are their profiles complete and current?",
            "Which OCIO clients have an adopted investment policy statement that is current, and which IPS reviews are overdue?",
            "Which consultants advise which of our institutional clients, and how much investable capital do those clients report?",
            "Which recordkeeper, sponsor, advisor of record and fiduciaries does each retirement plan have?",
            "Which mandates and institutional accounts does each client hold, and are any mandates without an open account?",
        ],
        grain=("Institutional party (institutional client, consultant, plan sponsor, recordkeeper or retirement plan) x role "
               "profile x effective period, with IPS versions, service relationships, consultant advisory relationships, plan "
               "role assignments and mandate-to-account links as effective-dated companion bridges; SCD type 2"),
        dimensions=["Institutional client", "Institutional client type", "Servicing segment", "Business line",
                    "Party type", "Consultant firm", "Consulting engagement type", "Retirement plan", "Plan type",
                    "Plan sponsor", "Recordkeeper", "Plan role type", "Investment mandate", "IPS status",
                    "Institutional account (DP-093)", "Strategy (DP-004)", "Ultimate parent", "Jurisdiction",
                    "Effective date"],
        measures=[
            ("Active Institutional Clients",
             "Count of distinct Institutional Client Party with Party Status = Active, an open 02 Party Role Role Type = "
             "Institutional Client, and at least one Service Relationship with Service Relationship Status in (Onboarding, "
             "Active, Under Notice), by Institutional Client Type and Servicing Segment.",
             _u("12", "Institutional Client", "Institutional Client Party", "Institutional Client Type")
             + _u("02", "Party", "Party Status") + _u("02", "Party Role", "Role Type", "Role Effective To")
             + _u("12", "Service Relationship", "Client", "Servicing Segment", "Service Relationship Status")),
            ("Client Profile Completeness %",
             "Active institutional clients whose Institutional Client Type, Governance Model, Government Entity Indicator, "
             "ERISA Plan Indicator, Legal Jurisdiction and a Total Investable Assets with Assets As-Of Date within 400 days "
             "are all populated / Active Institutional Clients.",
             _u("12", "Institutional Client", "Institutional Client Type", "Governance Model", "Government Entity Indicator",
                "ERISA Plan Indicator", "Total Investable Assets", "Assets As-Of Date")
             + _u("02", "Organization", "Legal Jurisdiction") + ["Active Institutional Clients"]),
            ("Government Entity Clients",
             "Active institutional clients with Government Entity Indicator = Y (the Advisers Act Rule 206(4)-5 population), "
             "by Institutional Client Type.",
             _u("12", "Institutional Client", "Government Entity Indicator", "Institutional Client Type")
             + ["Active Institutional Clients"]),
            ("ERISA Plan Clients",
             "Active institutional clients with ERISA Plan Indicator = Y, by Servicing Segment.",
             _u("12", "Institutional Client", "ERISA Plan Indicator") + _u("12", "Service Relationship", "Servicing Segment")
             + ["Active Institutional Clients"]),
            ("IPS Currency %",
             "Active clients with a Service Relationship of Servicing Segment = OCIO that have an IPS version with IPS Status "
             "= Adopted, IPS Effective Date on or before the as-of date and Next IPS Review Due Date on or after it / active "
             "clients with an OCIO Service Relationship.",
             _u("12", "Investment Policy Statement", "IPS Client", "IPS Status", "IPS Effective Date",
                "Next IPS Review Due Date") + _u("12", "Service Relationship", "Client", "Servicing Segment")
             + ["Active Institutional Clients"]),
            ("Overdue IPS Reviews",
             "Count of IPS versions with IPS Status = Adopted whose Next IPS Review Due Date is before the as-of date, by IPS "
             "Review Frequency.",
             _u("12", "Investment Policy Statement", "IPS Version ID", "IPS Status", "Next IPS Review Due Date",
                "IPS Review Frequency")),
            ("Consultant-Advised Client Count",
             "Count of distinct Advised Client per Consultant Firm on open Consultant Advisory Relationship rows "
             "(Engagement Effective To blank or after the as-of date), by Consulting Engagement Type and Consultant Type.",
             _u("05", "Consultant Advisory Relationship", "Consultant Firm", "Advised Client", "Consulting Engagement Type",
                "Engagement Effective From", "Engagement Effective To") + _u("05", "Consultant Profile", "Consultant Type")),
            ("Consultant-Advised Client Investable Assets",
             "Sum of Institutional Client.Total Investable Assets (as of each client's Assets As-Of Date, client-reported, "
             "USD) of the Advised Clients counted in Consultant-Advised Client Count that are institutional clients, per "
             "Consultant Firm, excluding clients whose Assets As-Of Date is more than 400 days before the as-of date (DQ6). "
             "It is neither Client Assets nor Advised Assets (both DP-008) nor Firm AUM (DP-241).",
             _u("12", "Institutional Client", "Institutional Client Party", "Total Investable Assets", "Assets As-Of Date")
             + _u("05", "Consultant Advisory Relationship", "Consultant Firm", "Advised Client")
             + ["Consultant-Advised Client Count"]),
            ("Consultant-Led Relationship %",
             "Active Service Relationships (Service Relationship Status in (Onboarding, Active, Under Notice)) with Advising "
             "Consultant populated / active Service Relationships, by Servicing Segment.",
             _u("12", "Service Relationship", "Service Relationship ID", "Advising Consultant", "Service Relationship Status",
                "Servicing Segment")),
            ("Recordkeeper Plan Count",
             "Per recordkeeper party (a Recordkeeper Party of 16 Recordkeeper Profile): count of distinct retirement plans in "
             "the union of the plans with an open 16 Plan Role Assignment of Plan Role Type = Recordkeeper (Role Party = the "
             "recordkeeper, Role Plan = the plan) and the plans with an open 02 Party Relationship of Relationship Type = "
             "Services Plan from the recordkeeper (From Party) to the plan (To Party); a plan in both sets counts once.",
             _u("16", "Recordkeeper Profile", "Recordkeeper Party", "Recordkeeper Model")
             + _u("16", "Plan Role Assignment", "Role Plan", "Role Party", "Plan Role Type", "Role Effective To")
             + _u("02", "Party Relationship", "From Party", "To Party", "Relationship Type", "Relationship Effective To")),
            ("Plans With Advisor of Record",
             "Count of distinct Role Plan with an open Plan Role Assignment of Plan Role Type = Advisor of Record whose Role "
             "Party resolves to an external financial professional or partner firm in DP-001, by Plan Type.",
             _u("16", "Plan Role Assignment", "Role Plan", "Role Party", "Plan Role Type", "Role Effective To")
             + _u("02", "Retirement Plan", "Plan Type")),
            ("Plan Sponsor Profile Coverage %",
             "Retirement plans with an active Service Relationship of Servicing Segment in (Plan Sponsor - Recordkept, Plan "
             "Sponsor - CIT Only) whose 02 Retirement Plan.Plan Sponsor has a 16 Plan Sponsor Profile / those plans.",
             _u("02", "Retirement Plan", "Plan Sponsor", "Plan Number", "Sponsor EIN")
             + _u("16", "Plan Sponsor Profile", "Sponsor Party")
             + _u("12", "Service Relationship", "Client", "Servicing Segment", "Service Relationship Status")),
            ("Plan Profile Currency %",
             "Retirement plans counted in Recordkeeper Plan Count whose latest 16 Retirement Plan Profile has Profile Plan "
             "Year equal to the current or prior plan year / those plans.",
             _u("16", "Retirement Plan Profile", "Profile Plan", "Profile Plan Year") + ["Recordkeeper Plan Count"]),
            ("Institutional Mandate Count",
             "Count of Investment Mandates per Client (an institutional client), by Mandate Type, with the count linked to an "
             "open 15 account through Institutional Account.Related Mandate (Account Status open).",
             _u("01", "Investment Mandate", "Mandate ID", "Mandate Type", "Client")
             + _u("15", "Institutional Account", "Related Mandate") + _u("15", "Account", "Account ID", "Account Status")),
            ("Mandates Without Open Account",
             "Investment Mandates with an Investment Management Agreement Date on or before the as-of date and no "
             "Institutional Account whose Related Mandate is the mandate and whose Account Status is open.",
             _u("01", "Investment Mandate", "Mandate ID", "Investment Management Agreement Date")
             + _u("15", "Institutional Account", "Related Mandate") + _u("15", "Account", "Account Status")),
            ("FINRA Institutional Classification Coverage %",
             "Active institutional clients with a 02 Regulatory Classification row whose FINRA Institutional Account "
             "Indicator is populated (latest Categorization Date) / Active Institutional Clients.",
             _u("02", "Regulatory Classification", "Classified Party", "Categorization Date",
                "FINRA Institutional Account Indicator") + ["Active Institutional Clients"]),
        ],
        inputs=[
            ("12", "Institutional Client", ["Institutional Client Party", "Institutional Client Type", "Primary Business Line",
                                            "Total Investable Assets", "Assets As-Of Date", "Governance Model",
                                            "Funded Status", "Funded Status As-Of Date", "Government Entity Indicator",
                                            "ERISA Plan Indicator", "UPMIFA Applicability Indicator", "Fiscal Year End"]),
            ("12", "Investment Policy Statement", ["IPS Version ID", "IPS Client", "IPS Version Number", "IPS Status",
                                                   "Firm-Drafted Indicator", "Governing Body Approval Date",
                                                   "IPS Effective Date", "Governed Mandates", "IPS Review Frequency",
                                                   "Next IPS Review Due Date"]),
            ("12", "Service Relationship", ["Service Relationship ID", "Client", "Servicing Segment",
                                            "Relationship Business Line", "Serviced Mandates", "Advising Consultant",
                                            "Service Tier", "Relationship Start Date", "Service Relationship Status"]),
            ("05", "Consultant Profile", ["Consultant Party", "Consultant Type", "Assets Under Advisement",
                                          "Discretionary OCIO Assets", "Competing OCIO Indicator"]),
            ("05", "Consultant Advisory Relationship", ["Consultant Firm", "Advised Client", "Consulting Engagement Type",
                                                        "Engagement Effective From", "Engagement Effective To"]),
            ("16", "Plan Sponsor Profile", ["Sponsor Party", "Controlled Group Members", "Employee Count"]),
            ("16", "Recordkeeper Profile", ["Recordkeeper Party", "Recordkeeper Model", "Plan Market Segments Served"]),
            ("16", "Retirement Plan Profile", ["Profile Plan", "Profile Plan Year", "Plan Characteristic Codes", "Plan Assets",
                                               "QDIA Type"]),
            ("16", "Plan Role Assignment", ["Plan Role ID", "Role Plan", "Role Party", "Plan Role Type", "Fiduciary Indicator",
                                            "Role Effective From", "Role Effective To"]),
            ("16", "Plan Service Provider", ["Schedule C Service Codes"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Relationship Stage",
                             "Merged Into Party"]),
            ("02", "Organization", ["Legal Name", "Legal Form", "Legal Jurisdiction", "Industry Classification",
                                    "Primary Regulator"]),
            ("02", "Legal Entity Hierarchy", ["Subsidiary Party", "Direct Parent", "Ultimate Parent", "Parent Relationship Basis",
                                              "Hierarchy Effective From"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status", "Role Effective From", "Role Effective To"]),
            ("02", "Party Identifier", ["Identified Party", "Identifier Value", "Identifier Scheme", "Identifier Effective From"]),
            ("02", "LEI Record", ["LEI"]),
            ("02", "Investor Qualification", ["Qualified Party", "Qualification Standard"]),
            ("02", "Retirement Plan", ["Plan Name", "Plan Number", "Plan Type", "Plan Sponsor", "Sponsor EIN"]),
            ("02", "Party Relationship", ["From Party", "To Party", "Relationship Type", "Relationship Effective From",
                                          "Relationship Effective To"]),
            ("02", "Regulatory Classification", ["Classified Party", "Categorization Date",
                                                 "FINRA Institutional Account Indicator",
                                                 "FINRA Institutional Investor Indicator", "Investor Category"]),
            ("15", "Account", ["Account ID", "Account Type", "Account Status", "Account Open Date", "Account Close Date"]),
            ("15", "Institutional Account", ["Related Mandate", "Related Retirement Plan", "Custodian"]),
            ("01", "Investment Mandate", ["Mandate ID", "Mandate Name", "Mandate Type", "Client", "Implemented Strategy",
                                          "Investment Management Agreement Date"]),
        ],
        upstream=["DP-240", "DP-001", "DP-093", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness="By 6am ET each business day",
        history="SCD type 2 on client profiles, IPS versions, service relationships, consultant engagements and plan role assignments for 10 years; IPS versions and advisory relationship records kept at least 5 years after the relationship ends (Advisers Act Rule 204-2)",
        classification="Confidential - Client",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Reverse ETL to CRM"],
        dq_rules=[
            "Every Institutional Client Party, Consultant Party, Sponsor Party, Recordkeeper Party and Role Party resolves to a DP-240 party with Merged Into Party blank holding the matching open 02 Party Role (Institutional Client, Investment Consultant / OCIO, Plan Sponsor, Recordkeeper), every Investment Mandate Client resolves to an Institutional Client, every Related Mandate to an Investment Mandate, and every institutional Account ID to an account in DP-093.",
            "Consultant Advisory Relationship and Plan Role Assignment periods end on or after they start, and for each IPS Client exactly one IPS version has IPS Status = Adopted on any date on or after its first IPS Effective Date.",
            "Each retirement plan is unique on Sponsor EIN + Plan Number, each active recordkept plan has exactly one open Plan Role Assignment with Plan Role Type = Recordkeeper, and every active Service Relationship with Advising Consultant populated has an open Consultant Advisory Relationship from that consultant to the Service Relationship Client.",
            "Institutional Client Type, Government Entity Indicator and ERISA Plan Indicator are populated on 100% of active institutional clients, Servicing Segment and Service Relationship Status on every Service Relationship, and Plan Role Type on every Plan Role Assignment.",
            "Rows whose party has Party Type = Individual (individual plan sponsors, advisors of record, individual consultants) are published only to entitled institutional and workplace roles, with Party Display Name withheld from the organization-only view; no special-category or client account financial data is carried.",
            "The daily build completes by 6am ET; an Institutional Client whose Assets As-Of Date is older than 400 days is flagged stale and excluded from Consultant-Advised Client Investable Assets.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Institutional Client' (12, role profile of a 02 party, CW-133), 'Investment "
               "Policy Statement' (12, IPSV-, CW-147), 'Consultant Profile' and 'Consultant Advisory Relationship' (05, "
               "CW-132), 'Recordkeeper Profile' (16, CW-125) and 'Plan Fiduciary and Service Role Assignment' (16, PROL-). It is "
               "the source of the SM-00 and SM-04 institutional client, consultant, recordkeeper, retirement plan, mandate and "
               "plan provider dimensions and of the WP2 conformed dimension 'Institution, consultant, plan sponsor'. "
               "Certified numbers: none owned or read. Total Investable Assets, Assets Under Advisement and Plan Assets are "
               "client- or filing-reported figures, never Client Assets (DP-008) or Firm AUM (DP-241). "
               "PII tier: identity, on the minority of rows whose party is an individual; institutional profiles carry none "
               "(CW-150). Contacts, signatories and recipients of 12 are not read. "
               "Boundaries: prospects stay 02 parties with Party Role Type = Prospect and appear only as Party references in "
               "the pipeline (DP-488, 05 Sales Opportunity); 11 Mandate Search Event.Asset Owner stays a Party and is never "
               "counted as an Institutional Client (CW-133 ruling). Relationship manager of record is 03 Party Coverage "
               "Assignment (DP-009); servicing roles, service standards and relationship health are DP-510's; consultant "
               "ratings, databases and RFPs are DP-488's (backlog DP-489 folded there); billing is 47 (DP-305, DP-350); plan "
               "administration and participant balances are DP-430's. The mandate-to-client link is read from 01 Investment "
               "Mandate and the mandate-to-account link from 15 Institutional Account, because those relationships live there "
               "(rule 2 exception); account facts are DP-093's. DP-001 is upstream for the external Advisor of Record and the "
               "partner coverage of consultants and recordkeepers. 12 Plan Sponsor Servicing Detail and OCIO Service Detail "
               "are left to DP-510 (WP1 moved read). "
               "Tailoring lever: OCIO offered at all (12 SME 1). Reference default: offered; without it IPS Currency % and "
               "Overdue IPS Reviews drop and the Investment Policy Statement input goes. "
               "Tailoring lever: plan sponsors serviced in 12 or 16 (12 SME 1, 4). Reference default: 12 Service Relationship "
               "with the Plan Sponsor segments; a recordkeeper-only firm reads the sponsor from 16 only. "
               "Tailoring lever: institutional client types not carried (12 SME 10). Reference default: out of scope. "
               "Taxonomy gap: 12 Service Relationship has no link to the retirement plan it services; Plan Sponsor Profile "
               "Coverage % joins through Service Relationship.Client = Retirement Plan.Plan Sponsor (12 Plan Sponsor Servicing "
               "Detail holds the plan link and is not read here). "
               "Taxonomy gap: there is still no attribute for the consultant's recommendation status of the firm's strategy at "
               "the client level (carried from the wholesale spec). "
               "Drafting assumptions: Service Relationship Status values counted active (Onboarding, Active, Under Notice); "
               "400-day profile currency window; plan year currency (current or prior); Account Status open values; Plan Role "
               "Type values Recordkeeper and Advisor of Record; Relationship Type value Services Plan. "
               "Decisions: CW-202, CW-133, CW-132, CW-125, CW-146, CW-147, CW-150, CW-138. "
               "WP1 re-scope (CW-202): name unchanged; owning domain 02 -> 12; owner Head of Institutional Client Data -> Head "
               "of Institutional Client Service; primary function FN-75. Upstream DP-002 (retired) becomes DP-001; DP-240 "
               "added. Inputs added: 12 Institutional Client, Investment Policy Statement and Service Relationship; 05 "
               "Consultant Profile and Consultant Advisory Relationship; 16 Plan Sponsor Profile, Recordkeeper Profile, "
               "Retirement Plan Profile, Plan Role Assignment and Plan Service Provider; 02 Regulatory Classification FINRA "
               "Institutional Account Indicator. Continuity rule (lead, F4 fix pass): every attribute a live logical model or "
               "semantic table reads is kept. Kept for live readers: 02 Organization Legal Form and Primary Regulator (SM-00 "
               "institutional_client), 02 Regulatory Classification Investor Category and FINRA Institutional Investor "
               "Indicator (SM-00 institutional_client_classification), 15 Account Account Open Date and Account Close Date "
               "(SM-00 institutional_account), 02 Legal Entity Hierarchy Direct Parent, Parent Relationship Basis and "
               "Hierarchy Effective From and 02 Party Role Role Effective From (models_f1.py DP-003 pks), 02 Party Identifier "
               "with LEI Record and 02 Investor Qualification on their pk attributes (models_f1.py DP-003 'Party Identifier' "
               "and 'Investor Qualification' entities). Inputs dropped, with reader and successor: 02 US Regulatory Identifier "
               "Employer Identification Number (no live reader; Sponsor EIN is read from 02 Retirement Plan), 02 Party "
               "Identifier Identifier Status, 02 LEI Record LEI Registration Status, 02 Investor Qualification Qualification "
               "Basis and Determination Date (no live reader; successor DP-240). Readers that name attributes the wealth "
               "taxonomy no longer holds (pre-existing, for the lineage pass): SM-04 plan_provider 'Plan Service Role' (now 16 "
               "Plan Role Assignment Plan Role Type) and SM-04 retirement_plan 'Form 5500 Filing Year' and 'Fiduciary "
               "Investment Adviser Type' (now 16 Retirement Plan Profile Profile Plan Year; the fiduciary adviser is a 16 Plan "
               "Role Assignment of Plan Role Type 3(21) or 3(38)). "
               "Measures kept by name: Consultant-Advised Client Count (now on 05 Consultant Advisory Relationship "
               "instead of 02 Party Relationship 'Consults For'; SM-00 metric source), Recordkeeper Plan Count (now distinct "
               "over 16 Plan Role Assignment and 02 'Services Plan'; SM-00 metric source), Client Profile Completeness % "
               "(redefined on 12 Institutional Client). The wholesale measure Consultant-Advised Assets is restored as "
               "Consultant-Advised Client Investable Assets, renamed so it cannot be read as the certified Advised Assets "
               "(DP-008). Entities for the lineage pass: 'Institutional Client' (12 conformers; SM-00, SM-04) is now backed by "
               "12 Institutional Client and its key changes from 02 Party ID to Institutional Client Party (the same PTY- "
               "value); the party columns SM-00 institutional_client reads (Party Display Name, Party Type, Legal Form, Legal "
               "Jurisdiction, Industry Classification, Primary Regulator, Relationship Stage, Party Status) stay on the 02 "
               "Party and Organization objects this product reads, joined on Institutional Client Party = Party ID. "
               "'Investment Mandate' (4) and 'Retirement Plan' (3) keep 01 Investment Mandate and 02 Retirement Plan; SM-04 "
               "'Consultant Advisory Relationship' and 'Plan Service Provider' bridges now have their objects; SM-00 "
               "consultant, recordkeeper and retirement plan dimensions that role-play 'Institutional Client' should take "
               "Consultant Profile, Recordkeeper Profile and Retirement Plan; 'Party Relationship', 'Regulatory "
               "Classification' and 'Account' keep their objects. Earlier stage lines (W1 re-point CW-021, CW-902; W4) are "
               "superseded: the 12, 05 and 16 profiles they deferred are now read."
               " WP2 retirement sweep (CW-209): SM-04, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-005": dict(
        definition=("The register of the thin intermediary channel's agreements and placement: every 05 Distribution "
                    "Agreement (selling, platform, sub-accounting, networking, Rule 22c-2, model provider, SMA sponsor, "
                    "recordkeeper services, data sharing and authorized participant agreements) with its parties, terms, "
                    "amendments, product coverage, distribution scope and linked accounts; the payment arrangements and rate "
                    "schedule headers each agreement carries; and the shelf placements, share class mappings, partner research "
                    "ratings, model program placements, partner programs and memberships, dealer and networking set-up and "
                    "partner data feed arrangements that hang off them. It conforms where and on what terms the firm may "
                    "sell through intermediaries once (CONCEPT_OWNERSHIP rows 'Distribution Agreement' (AGR-), 'Payment "
                    "Arrangement' (PYA-), 'Shelf Placement' (SHF-) and 'Partner Program' (PGM-), 05), shrunk from the "
                    "wholesale register to the IC line (CW-013). It owns no certified metric family."),
        business_questions=[
            "Which agreements are active with each partner, of which type, which products and channels do they cover, and which are up for renewal or under termination notice?",
            "On which partner platforms and programs is each share class on the shelf, on watch or removed, and is any placement trading without a covering agreement?",
            "Which payment arrangements are active by payment type and funding source, do they carry a current rate schedule, and are fund-paid arrangements disclosed in the prospectus?",
            "Which of our models are placed in which sponsor programs, and at what status?",
            "Which dealer set-ups lack a Rule 22c-2 agreement, and which partner data feeds have no governing agreement?",
            "Which omnibus, trading and fee accounts are linked to each agreement, and in what role?",
        ],
        grain=("Shelf placement (partner x platform or program x share class x shelf list type x status effective period), "
               "linked to the governing agreement; agreements, payment arrangements with rate schedule headers, model program "
               "placements, program memberships and dealer set-ups are also published at their own grain x effective period; "
               "SCD type 2"),
        dimensions=["Partner firm (DP-001)", "Partner platform / program", "Agreement", "Agreement type", "Agreement status",
                    "Agreement party role", "Product and share class (DP-004)", "Model portfolio (DP-004)",
                    "Shelf list type", "Placement status", "Eligible account type", "Permitted jurisdiction",
                    "Payment type", "Funding source", "Calculation basis", "Sponsor program type", "Partner tier",
                    "Dealing route", "Networking level", "Account link role", "Linked account (DP-093)", "Effective date"],
        measures=[
            ("Active Agreement Count",
             "Count of Distribution Agreements with Agreement Status = Active and Agreement Effective Date on or before the "
             "as-of date, by Agreement Type.",
             _u("05", "Distribution Agreement", "Agreement ID", "Agreement Status", "Agreement Type")
             + _u("05", "Agreement Term", "Agreement Effective Date")),
            ("Days to Renewal",
             "Next Renewal Date - as-of date for each active agreement; flagged when less than the Renewal Notice Period.",
             _u("05", "Agreement Term", "Next Renewal Date", "Renewal Notice Period")),
            ("Agreements Under Termination",
             "Count of agreements with Agreement Status = Under Notice of Termination, or a Termination Date within the next "
             "90 days, by Agreement Type and Termination Reason.",
             _u("05", "Distribution Agreement", "Agreement Status", "Agreement Type")
             + _u("05", "Agreement Term", "Termination Date", "Termination Reason")),
            ("Active Placement Count",
             "Count of Shelf Placements with Placement Status in (Approved - Available, On Watch, Closed to New Investors) "
             "effective on the as-of date (Placement Status Effective From on or before it, Placement Status Effective To "
             "blank or after it), per Shelf Partner and per Placed Share Class.",
             _u("05", "Shelf Placement", "Shelf Partner", "Placed Share Class", "Placement Status",
                "Placement Status Effective From", "Placement Status Effective To")),
            ("Shelf Coverage %",
             "Per share class: partners whose agreement with Agreement Status = Active covers the share class (Agreement Party "
             "with Firm Contracting Entity Indicator = N; Agreement Product Coverage with Inclusion Type = Include effective on "
             "the as-of date) and that also have an active placement of it (Active Placement Count rule) / partners whose "
             "active agreement covers it. The numerator is a subset of the denominator, so the ratio is at most 100%.",
             _u("05", "Shelf Placement", "Shelf Partner", "Placed Share Class", "Placement Status")
             + _u("05", "Distribution Agreement", "Agreement Status")
             + _u("05", "Agreement Party Role", "Agreement Party", "Firm Contracting Entity Indicator")
             + _u("05", "Agreement Product Coverage", "Covered Share Class", "Inclusion Type", "Coverage Effective From",
                  "Coverage Effective To")),
            ("Placement Without Agreement Flag",
             "Y when an active shelf placement has no agreement with Agreement Status = Active whose Agreement Party (Firm "
             "Contracting Entity Indicator = N) is the Shelf Partner and whose Agreement Product Coverage includes the Placed "
             "Share Class on the same date.",
             _u("05", "Shelf Placement", "Shelf Partner", "Placed Share Class", "Placement Status",
                "Placement Status Effective From")
             + _u("05", "Distribution Agreement", "Agreement Status")
             + _u("05", "Agreement Party Role", "Agreement Party", "Firm Contracting Entity Indicator")
             + _u("05", "Agreement Product Coverage", "Covered Share Class", "Coverage Effective From",
                  "Coverage Effective To")),
            ("Watch List Count",
             "Count of products with Watch List Indicator = Y per Research Provider on the as-of date.",
             _u("05", "Partner Research Rating", "Watch List Indicator", "Research Provider", "Rated Product")),
            ("Overdue Research Reviews",
             "Count of Partner Research Rating rows whose Next Scheduled Review Date is before the as-of date, by Research "
             "Provider and Normalized Research Rating.",
             _u("05", "Partner Research Rating", "Next Scheduled Review Date", "Research Provider",
                "Normalized Research Rating")),
            ("Default Share Class Mappings",
             "Count of Share Class Mapping rows with Default Share Class Indicator = Y per Mapping Partner and Mapped Account "
             "Type, with the share of them where Share Class Conversion Eligible Indicator = Y.",
             _u("05", "Share Class Mapping", "Mapping Partner", "Mapped Account Type", "Mapped Share Class",
                "Default Share Class Indicator", "Share Class Conversion Eligible Indicator")),
            ("Active Payment Arrangements",
             "Count of Payment Arrangements with Payment Arrangement Status = Active and Arrangement Effective From on or "
             "before the as-of date (Arrangement Effective To blank or after it), by Payment Type and Funding Source.",
             _u("05", "Payment Arrangement", "Payment Arrangement ID", "Payment Arrangement Status", "Payment Type",
                "Funding Source", "Arrangement Effective From", "Arrangement Effective To")),
            ("Arrangements Without Current Rate Schedule",
             "Active Payment Arrangements with no Rate Schedule effective on the as-of date (Rate Schedule Effective From on "
             "or before it and Rate Schedule Effective To blank or after it) carrying a Base Rate or Flat Fee Amount.",
             _u("05", "Rate Schedule", "Rate Schedule Effective From", "Rate Schedule Effective To", "Base Rate",
                "Flat Fee Amount") + ["Active Payment Arrangements"]),
            ("Undisclosed Fund-Paid Arrangements",
             "Active Payment Arrangements with Funding Source = Fund - Non-Distribution Services and Prospectus Disclosure "
             "Indicator = N.",
             _u("05", "Payment Arrangement", "Funding Source", "Prospectus Disclosure Indicator")
             + ["Active Payment Arrangements"]),
            ("Active Model Placements",
             "Count of Model Program Placements with Model Placement Status = Approved - Available and Model Placement "
             "Effective From on or before the as-of date, by Sponsor Program Type and Firm Role in Program.",
             _u("05", "Model Program Placement", "Sponsor Program Agreement", "Placed Model Portfolio", "Model Placement Status",
                "Model Placement Effective From", "Sponsor Program Type", "Firm Role in Program")),
            ("Firm Program Memberships by Partner Tier",
             "Count of the firm's open Program Memberships (Member Party = a firm legal entity; Membership Effective To blank "
             "or after the as-of date) in Partner Programs with Program Status = Active, by the program's partner (Program "
             "Sponsor, a DP-001 partner firm), Program Type and Partner Tier.",
             _u("05", "Program Membership", "Member Program", "Member Party", "Partner Tier", "Membership Effective From",
                "Membership Effective To")
             + _u("05", "Partner Program", "Program ID", "Program Sponsor", "Program Type", "Program Status")),
            ("Dealer Setups Without Rule 22c-2 Agreement",
             "Count of Partner Dealer Setups with Dealer Setup Status = Active whose Networking Setup has Rule 22c-2 Agreement "
             "in Place Indicator = N, by Dealing Route and Account Structure.",
             _u("05", "Partner Dealer Setup", "Dealer Setup Partner", "TA Dealer Number", "Dealer Setup Status",
                "Dealing Route", "Account Structure")
             + _u("05", "Networking Setup", "Rule 22c-2 Agreement in Place Indicator")),
            ("Data Feeds Without Governing Agreement",
             "Count of Partner Data Feed Arrangement rows whose Governing Data Agreement is blank or is not a Distribution "
             "Agreement with Agreement Status = Active.",
             _u("05", "Partner Data Feed Arrangement", "Data Feed", "Governing Data Agreement")
             + _u("05", "Distribution Agreement", "Agreement ID", "Agreement Status")),
            ("Linked Account Count",
             "Count of open Agreement Account Link rows (Account Link Effective To null or after the as-of date) per agreement, "
             "by Account Link Role.",
             _u("05", "Agreement Account Link", "Linked Account", "Account Link Role", "Account Link Effective To")),
        ],
        inputs=[
            ("05", "Distribution Agreement", ["Agreement ID", "Agreement Name", "Agreement Type", "Master Agreement",
                                              "Agreement Status", "Governing Law", "Most-Favored-Nation Clause Indicator",
                                              "Exclusivity Indicator", "Distributor Due Diligence Reference",
                                              "Executed Contract"]),
            ("05", "Agreement Party Role", ["Agreement Party", "Agreement Party Role", "Firm Contracting Entity Indicator",
                                            "Party Role Effective From", "Party Role Effective To"]),
            ("05", "Agreement Term", ["Agreement Effective Date", "Term Type", "Initial Term End Date", "Next Renewal Date",
                                      "Renewal Notice Period", "Termination Notice Period", "Termination Date",
                                      "Termination Reason"]),
            ("05", "Agreement Amendment", ["Amendment ID", "Amendment Effective Date"]),
            ("05", "Agreement Product Coverage", ["Covered Product", "Covered Share Class", "Covered Model Portfolio",
                                                  "Covered Vehicle Types", "Inclusion Type", "Coverage Effective From",
                                                  "Coverage Effective To"]),
            ("05", "Agreement Distribution Scope", ["Permitted Channels", "Permitted Jurisdictions", "Permitted Service Models",
                                                    "Covered Account Types"]),
            ("05", "Agreement Account Link", ["Linked Account", "Account Link Role", "Account Link Effective From",
                                              "Account Link Effective To"]),
            ("05", "Payment Arrangement", ["Payment Arrangement ID", "Governing Agreement", "Payment Type", "Payer Entity",
                                           "Payee Entity", "Funding Source", "Services Compensated",
                                           "Payment Arrangement Status", "Arrangement Effective From",
                                           "Arrangement Effective To", "Prospectus Disclosure Indicator",
                                           "Annual Payment Cap"]),
            ("05", "Rate Schedule", ["Calculation Basis", "Base Rate", "Flat Fee Amount", "Tiering Method",
                                     "Rate Schedule Effective From", "Rate Schedule Effective To"]),
            ("05", "Shelf Placement", ["Shelf Placement ID", "Shelf Partner", "Partner Platform / Program Name", "Placed Product",
                                       "Placed Share Class", "Shelf List Type", "Placement Status",
                                       "Placement Status Effective From", "Placement Status Effective To",
                                       "Trade-Enabled Date", "Eligible Account Types", "Model Eligibility Indicator"]),
            ("05", "Share Class Mapping", ["Mapping Partner", "Mapped Account Type", "Mapped Share Class",
                                           "Default Share Class Indicator", "Share Class Conversion Eligible Indicator"]),
            ("05", "Partner Research Rating", ["Research Provider", "Rated Product", "Normalized Research Rating", "Rating Date",
                                               "Last Due Diligence Review Date", "Next Scheduled Review Date",
                                               "Watch List Indicator"]),
            ("05", "Model Program Placement", ["Sponsor Program Agreement", "Placed Model Portfolio", "Sponsor Program Type",
                                               "Firm Role in Program", "Program Minimum Account Size",
                                               "Model Placement Status", "Model Placement Effective From"]),
            ("05", "Partner Program", ["Program ID", "Program Name", "Program Type", "Program Sponsor", "Program Status"]),
            ("05", "Program Membership", ["Member Program", "Member Party", "Partner Tier", "Funding Agreement",
                                          "Membership Effective From", "Membership Effective To"]),
            ("05", "Partner Dealer Setup", ["Dealer Setup Partner", "TA Dealer Number", "Platform Participant ID", "Dealer Setup Status", "Dealer Setup Effective Date",
                                            "Dealing Route", "Account Structure"]),
            ("05", "Networking Setup", ["Networking Level", "Recordkeeping Responsibility",
                                        "Rule 22c-2 Agreement in Place Indicator"]),
            ("05", "Partner Data Feed Arrangement", ["Data Feed", "Governing Data Agreement"]),
        ],
        upstream=["DP-001", "DP-004", "DP-093", "DP-213", "DP-013"],
        refresh="Daily",
        timeliness="By 7am ET each business day; shelf changes reported by partners loaded within 2 business days of receipt",
        history="SCD type 2 on agreements, coverage, payment arrangements, rate schedules and placement status since 2015; terminated agreements retained for the life of the agreement plus 6 years (SEC Rule 17a-4 and Investment Company Act Rule 31a-2 records of the principal underwriter and the funds)",
        classification="Restricted - Commercial Terms",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API", "Reverse ETL to CRM"],
        dq_rules=[
            "Every Agreement Party with Firm Contracting Entity Indicator = N, Shelf Partner, Mapping Partner, Program Sponsor and Dealer Setup Partner resolves to an active partner party in DP-001, every Member Party and every Agreement Party with Firm Contracting Entity Indicator = Y resolves to the DP-240 party of one of the firm's own legal entities (DP-013), every Placed Share Class, Covered Share Class, Mapped Share Class and Placed Model Portfolio to an active share class or model in DP-004, every Linked Account to an open account in DP-093, and every Executed Contract to a contract in DP-213.",
            "Placement status periods for the same partner, platform, share class and shelf list type do not overlap; Rate Schedule periods of one arrangement do not overlap; every effective period ends on or after it starts; and every Payment Arrangement names a Governing Agreement that is active on the arrangement's effective dates.",
            "Placement Without Agreement Flag = Y on no more than 0.5% of active placements, and each one is either covered within 10 business days or set to Placement Status = Restricted / Sell-Only.",
            "Every active agreement has Agreement Type, Agreement Effective Date, a Next Renewal Date or Term Type = Evergreen, and at least one Agreement Party Role with Firm Contracting Entity Indicator = Y; every active Payment Arrangement has Payment Type and Funding Source.",
            "Every Agreement Party, Payer Entity, Payee Entity, Research Provider, Member Party and Program Sponsor published resolves to a party whose DP-240 Party Type is not Individual or Household, so no published column identifies a person; a row failing this test is withheld from the product.",
            "The daily build completes by 7am ET, and each Partner Dealer Setup TA Dealer Number is unique among active setups with at most one Default Share Class Indicator = Y per Mapping Partner, Mapped Account Type and product.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Distribution Agreement' (05, AGR-), 'Payment Arrangement' (05, PYA-), "
               "'Shelf Placement' (05, SHF-), 'Partner Program' (05, PGM-), 'Partner Research Rating' (05) and the W5 sweep rows "
               "for Agreement Party Role, Agreement Amendment, Agreement Product Coverage, Agreement Account Link, Rate "
               "Schedule, Share Class Mapping, Model Program Placement, Program Membership, Partner Dealer Setup and Partner "
               "Data Feed Arrangement. It is the source of the SM-00 distribution_agreement, agreement_party, "
               "agreement_coverage, shelf_placement, partner_program, payment_arrangement and partner_research_rating "
               "dimensions and of SM-03 agreement and partner_program. "
               "Certified numbers: none owned or read. Payment amounts (calculations, invoices, payments, accruals) and the rate "
               "tiers are DP-487's; this product carries the arrangement and rate schedule header so that consumers know which "
               "terms apply. "
               "PII tier: none. Agreement ID, Shelf Placement ID and other keys are flagged PII in the catalog only because "
               "their notes read 'No PII'; Distribution Agreement Business Owner (an employee) is the one personal attribute of "
               "the objects read and it is not read, so pii = N is deliberate and the dp_model warning is accepted. "
               "Boundaries: due diligence, findings, obligations and payment disclosures are DP-486's; model delivery events and "
               "sponsor-reported assets are DP-493's (backlog DP-485); payments and sub-accounting are DP-487's; partner and "
               "advisor masters are DP-001's; the 39 contract record is DP-213's. Platform shelf scope is the intermediary "
               "channel only; the firm's own brokerage platform availability is DP-004 (01 Platform Product Availability). "
               "Authorized participant agreements (Agreement Type = Authorized Participant Agreement) stay in this register, so "
               "the ETF readers that name 'AP agreement (DP-005)' keep resolving. Absorbs the scope of backlog DP-484 Platform "
               "Shelf & Share Class Placement (WAVE_BACKLOG_MERGES). Shelf Placement Placement Opportunity is not read: "
               "placement requests are 05 Sales Opportunity rows read through DP-488. The agreement-to-account link is taken "
               "from 05 Agreement Account Link (rule 2 exception) and the partner-to-feed link from 05 Partner Data Feed "
               "Arrangement, whose Data Feed is mastered in 06. "
               "Partner Dealer Setup NSCC Participant Number is a Derived copy of 02 and is not read: the partner's NSCC "
               "number comes from DP-001 (02 Market Infrastructure & Vendor Identifier); TA Dealer Number is read because it is "
               "part of the set-up's grain. Program Membership is the firm's own membership in a partner's program (Member "
               "Party is a firm legal entity), so the partner side is the Partner Program's Program Sponsor. For the lineage "
               "pass: specs_e2_portfolio_stewardship.py (measure 'Active Placements Reached', about line 476) filters Model "
               "Placement Status = Active, which is not a value of the 05 Placement Status list; the matching value is "
               "'Approved - Available'. SM-03 agreement still reads Distribution Agreement 'Agreement Market', "
               "which the wealth 05 dropped at W4 (CW-905, US only); the lineage pass drops that column (no successor; the US "
               "states are Agreement Distribution Scope Permitted Jurisdictions). "
               "Tailoring lever: payments to intermediaries (05 SME 3). Reference default: platform, sub-accounting and "
               "networking fees; the 12b-1 and revenue-sharing Payment Type and Funding Source values are levers and change no "
               "measure here. "
               "Tailoring lever: model delivery, managed sponsor accounts or both (05 SME 5). Reference default: both; Active "
               "Model Placements counts either by Firm Role in Program. "
               "Tailoring lever: permitted states on agreements (05 SME 8). Reference default: nationwide, so Permitted "
               "Jurisdictions is usually blank. "
               "Taxonomy gap: 05 Shelf Placement has no attribute for the agreement it relies on; the link is derived by "
               "matching Shelf Partner and Placed Share Class to Agreement Party Role and Agreement Product Coverage on the "
               "same date (carried). "
               "Taxonomy gap: 05 Rate Schedule has no attribute naming its Payment Arrangement in the catalog; the link is the "
               "object's grain (payment arrangement x rate schedule effective period) and is taken from its key. "
               "Drafting assumptions: Placement Status values counted active (Approved - Available, On Watch, Closed to New "
               "Investors); 90-day termination window; 0.5% and 10-business-day tolerances in DQ3; Model Placement Status "
               "'Approved - Available'; Dealer Setup Status and Program Status 'Active'. "
               "Decisions: CW-202, CW-013, CW-132, CW-134, CW-136, CW-137, CW-905, CW-240. "
               "WP1 re-scope (CW-202): renamed from 'Distribution Agreements & Shelf Status' to 'Intermediary Agreements & "
               "Platform Placement'; owning domain 05 unchanged; owner Head of Strategic Partnerships Operations -> Head of "
               "Intermediary Distribution; primary function FN-74. Upstream adds DP-093 and DP-213. Inputs added: 05 Agreement "
               "Amendment, Rate Schedule (header terms) and Partner Data Feed Arrangement; attributes Distributor Due Diligence "
               "Reference, Executed Contract, Covered Model Portfolio, Services Compensated, Prospectus Disclosure Indicator, "
               "Annual Payment Cap, Member Party, Dealer Setup Partner, Dealing Route, Account Structure and Mapping Partner. "
               "No input object dropped; the attribute Partner Dealer Setup NSCC Participant Number is no longer read (no live "
               "model or semantic reader; successor DP-001). Measures kept by name: Shelf Coverage % (SM-00; numerator now bounded "
               "to the covered partners), Active Placement Count (its filter rewritten to the 05 Placement "
               "Status values; read by SM-00 metric source), Days to Renewal, Placement Without "
               "Agreement Flag, Watch List Count (SM-00) and Linked Account Count (SM-00 exclusion list). Measures added: "
               "Active Agreement Count, Agreements Under Termination, Overdue Research Reviews, Default Share Class Mappings, "
               "Active Payment Arrangements, Arrangements Without Current Rate Schedule, Undisclosed Fund-Paid Arrangements, "
               "Active Model Placements, Firm Program Memberships by Partner Tier, Dealer Setups Without Rule 22c-2 Agreement and Data "
               "Feeds Without Governing Agreement. Entity names (Distribution Agreement 11 conformers, Shelf Placement 6, "
               "Payment Arrangement 6, Partner Dealer Setup 3, Partner Program 2, Agreement Party Role, Partner Research Rating, "
               "Share Class Mapping) all keep their objects. "
               "W4 re-point (CW-132, CW-905): 05 Intermediary & Institutional Distribution restores the agreement, shelf, "
               "research-rating, dealer and networking objects under their wholesale names; the EU/UK and thin-cut attributes "
               "dropped at W4 stay dropped and Permitted Jurisdictions holds US states."
               " WP2 retirement sweep (CW-209): SM-03, named above as a reader, is retired and its definition file deleted; the live readers are the WP2 models, which publish or exclude every measure."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-480": dict(
        definition=("The firm's cost allocation chain and management hierarchy, conformed once per allocation run: the 10 cost "
                    "pools with their contributing cost centers and cost-to-serve components, the allocation methods, drivers "
                    "and rules, each allocation run with its unallocated residual and the allocated amounts by rule and "
                    "target dimension member, and the governed management hierarchy versions with their nodes, restatements "
                    "and the management P&L line to GL account mapping. It ties every run back to the certified operating "
                    "expense of the contributing cost centers, read from DP-191, so that cost to serve, profitability, client "
                    "lifetime value and Fund 360 read one allocation and one hierarchy instead of each rebuilding them "
                    "(CONCEPT_OWNERSHIP rows 'Allocation Method' (10, ALM-), 'Management Hierarchy Node' (10, MHY-) and "
                    "'Account Mapping' (10, ACM-)). It owns no certified metric family."),
        business_questions=[
            "How much certified operating expense did each cost pool receive this period, and how much of it did the final run allocate and leave unallocated?",
            "What cost did each run allocate to each cost-to-serve component and target dimension (offering, channel, segment, business line)?",
            "Which allocation rules lack a driver or overlap, and do driver shares sum to one?",
            "Which management hierarchy version is active for each hierarchy type, are any nodes orphaned or leaves unmapped, and which restatements changed history?",
            "Which expense GL accounts are not mapped to a management P&L line?",
        ],
        grain=("Allocation run x allocation rule x target dimension member (allocated amount and driver share) for the "
               "unrestricted target dimensions; for Target Dimension = Household, Account, Client or Advisor the published row "
               "is allocation run x allocation rule x target dimension (members summed, CW-243). Cost pools, methods, drivers, "
               "rules, management hierarchy versions and nodes, hierarchy restatements and account mappings are "
               "effective-dated reference; runs are versioned by Run Data Version and never updated after Final"),
        dimensions=["Allocation run and run data version", "Run period (DP-013)", "Cost pool and cost pool type",
                    "Cost-to-serve component", "Allocation method and method type", "Allocation driver and driver type",
                    "Target dimension",
                    "Target dimension member (offering, service tier, product and share class from DP-004; partner firm from DP-001; retirement plan from DP-003; client segment from DP-240; legal entity and region from DP-013)",
                    "Cost center (DP-190)", "GL account (DP-190)", "Management P&L line",
                    "Management hierarchy type and version", "Management hierarchy node", "Operating segment"],
        measures=[
            ("Certified Operating Expense by Cost Center (from DP-191)",
             "Certified Operating Expense from DP-191, taken as published at its cost center grain: Closing Balance - Opening "
             "Balance of GL Account Balance rows with Balance Type = Actual, on ledgers with Ledger Role = Primary, in the "
             "ledger currency (Balance Currency = Ledger Currency), for GL accounts with GL Account Type = Expense and "
             "Financial Statement Class in (Operating Expense - Compensation, Operating Expense - Distribution, Operating "
             "Expense - General and Administrative), for a Balance Fiscal Period = Run Period whose Period Close Status is in "
             "(Hard Close, Permanently Closed) (preliminary before hard close), by the cost center in Balance Segment "
             "Combination. It is read, never recomputed, and must equal DP-191's published value (DQ3).",
             _u("19", "GL Account Balance", "Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period",
                "Balance Type", "Balance Ledger", "Balance Currency", "Opening Balance", "Closing Balance")
             + _u("19", "GL Account", "GL Account ID", "GL Account Type", "Financial Statement Class")
             + _u("19", "Ledger", "Ledger ID", "Ledger Role", "Ledger Currency")
             + _u("19", "Accounting Period Status", "Status Ledger", "Status Fiscal Period", "Period Close Status")
             + _u("10", "Allocation Run", "Run Period")),
            ("Pool Source Cost",
             "Per cost pool and run: sum of Certified Operating Expense by Cost Center (from DP-191) over the pool's "
             "Contributing Cost Centers for the Run Period. A cost center contributes to one pool only (DQ2), so pools do not "
             "double count; Included Expense Categories is published as a pool attribute and does not filter the amount "
             "(no category-to-GL-account mapping exists; see the taxonomy gap).",
             _u("10", "Cost Pool", "Cost Pool ID", "Contributing Cost Centers", "Included Expense Categories")
             + ["Certified Operating Expense by Cost Center (from DP-191)"]),
            ("Pool-to-Pool Transfers",
             "Sum of Allocation Result.Allocated Amount (USD) per run on rows whose Target Dimension Member is a Cost Pool ID "
             "(the intermediate pool-to-pool allocations of rules whose Applied Allocation Method has Allocation Method Type in "
             "(Step-Down, Reciprocal)).",
             _u("10", "Allocation Result", "Allocated Rule", "Target Dimension Member", "Allocated Amount")
             + _u("10", "Cost Pool", "Cost Pool ID") + _u("10", "Allocation Rule", "Applied Allocation Method")
             + _u("10", "Allocation Method", "Allocation Method Type")),
            ("Allocated Cost",
             "Sum of Allocation Result.Allocated Amount (USD) to final targets per Allocation Run ID x Allocated Rule x Target "
             "Dimension, with the Source Cost Pool of the rule; rows counted in Pool-to-Pool Transfers are excluded so that a "
             "Step-Down or Reciprocal chain is counted once.",
             _u("10", "Allocation Result", "Allocated Rule", "Target Dimension Member", "Allocated Amount")
             + _u("10", "Allocation Rule", "Allocation Rule ID", "Source Cost Pool", "Target Dimension")
             + _u("10", "Allocation Run", "Allocation Run ID") + ["Pool-to-Pool Transfers"]),
            ("Unallocated Residual Amount",
             "Allocation Run.Unallocated Residual of each run, by Run Period and Run Data Version.",
             _u("10", "Allocation Run", "Allocation Run ID", "Unallocated Residual", "Run Period", "Run Data Version")),
            ("Allocation Completeness %",
             "Allocated Cost / (Allocated Cost + Unallocated Residual Amount) per run.",
             ["Allocated Cost", "Unallocated Residual Amount"]),
            ("Allocation to Ledger Difference",
             "(Allocated Cost + Unallocated Residual Amount) of a Final run - sum of Pool Source Cost of the pools that "
             "receive ledger cost (pools with Contributing Cost Centers), for the Run Period; pool-to-pool transfers are "
             "excluded from Allocated Cost, so the difference is zero when the chain is complete.",
             _u("10", "Allocation Run", "Run Status") + ["Allocated Cost", "Unallocated Residual Amount", "Pool Source Cost"]),
            ("Allocated Cost by Cost-to-Serve Component",
             "Allocated Cost grouped by the Source Cost Pool's Cost-to-Serve Component and Cost Pool Type and by Target "
             "Dimension; rows whose Target Dimension is Household, Account, Client or Advisor are published summed over "
             "members (member suppressed, CW-243).",
             _u("10", "Cost Pool", "Cost-to-Serve Component", "Cost Pool Type") + _u("10", "Allocation Rule", "Target Dimension")
             + ["Allocated Cost"]),
            ("Driver Share Variance",
             "Per run x Allocated Rule: absolute value of (sum of Driver Share over the rule's target members - 100), in "
             "percentage points (Driver Share is typed Percentage).",
             _u("10", "Allocation Result", "Allocated Rule", "Driver Share", "Target Dimension Member")),
            ("Driver Unit Cost",
             "Per Allocation Driver with Driver Type = Time / Effort or a time-driven method: Capacity Cost Rate x Unit Time "
             "Estimate, the TDABC cost of one driver unit.",
             _u("10", "Allocation Driver", "Allocation Driver ID", "Driver Type", "Capacity Cost Rate", "Unit Time Estimate")),
            ("Active Allocation Rules",
             "Count of Allocation Rules with Rule Effective From on or before the as-of date and Rule Effective To blank or "
             "after it, by Target Dimension and Allocation Method Type of the Applied Allocation Method.",
             _u("10", "Allocation Rule", "Allocation Rule ID", "Rule Effective From", "Rule Effective To", "Target Dimension",
                "Applied Allocation Method") + _u("10", "Allocation Method", "Allocation Method ID", "Allocation Method Type")),
            ("Rules Without Driver",
             "Active Allocation Rules whose Applied Allocation Method has Allocation Method Type in (Driver-Based, "
             "Activity-Based, Time-Driven Activity-Based) and whose Applied Driver is blank.",
             _u("10", "Allocation Rule", "Applied Driver", "Applied Allocation Method")
             + _u("10", "Allocation Method", "Allocation Method Type") + ["Active Allocation Rules"]),
            ("Superseded Runs",
             "Count of Allocation Runs with Run Status = Superseded per Run Period (restated allocations), with the Run Data "
             "Version of the Final run.",
             _u("10", "Allocation Run", "Run Status", "Run Period", "Run Data Version")),
            ("Active Hierarchy Nodes",
             "Count of Management Hierarchy Node rows of hierarchy versions with Hierarchy Status = Active effective on the "
             "as-of date, by Hierarchy Type.",
             _u("10", "Management Hierarchy Node", "Node ID")
             + _u("10", "Management Hierarchy", "Management Hierarchy ID", "Hierarchy Type", "Hierarchy Status",
                  "Hierarchy Effective From", "Hierarchy Effective To")),
            ("Orphan Hierarchy Nodes",
             "Active Hierarchy Nodes whose Parent Node is not a Node ID of the same hierarchy version (the root excepted).",
             _u("10", "Management Hierarchy Node", "Node ID", "Parent Node") + ["Active Hierarchy Nodes"]),
            ("Operating Segment Mapping Coverage %",
             "Leaf nodes (Leaf Member populated) of active versions with Operating Segment Mapping populated / leaf nodes of "
             "active versions.",
             _u("10", "Management Hierarchy Node", "Leaf Member", "Operating Segment Mapping") + ["Active Hierarchy Nodes"]),
            ("Restatements in Period",
             "Count of Hierarchy Restatement rows whose Restated From Period falls in the reporting year, by Restatement "
             "Method and Restatement Trigger.",
             _u("10", "Hierarchy Restatement", "Restatement ID", "Restated From Period", "Restatement Method",
                "Restatement Trigger")),
            ("Account Mapping Coverage %",
             "Active GL accounts with GL Account Type = Expense that have an Account Mapping effective on the as-of date "
             "(Mapping Effective From on or before it, Mapping Effective To blank or after it) / active expense GL accounts "
             "(DP-190).",
             _u("10", "Account Mapping", "GL Natural Account", "Mapping Effective From", "Mapping Effective To")
             + _u("19", "GL Account", "GL Account ID", "GL Account Type")),
        ],
        inputs=[
            ("10", "Cost Pool", ["Cost Pool ID", "Cost Pool Type", "Cost-to-Serve Component", "Contributing Cost Centers",
                                 "Included Expense Categories"]),
            ("10", "Allocation Method", ["Allocation Method ID", "Allocation Method Name", "Allocation Method Type"]),
            ("10", "Allocation Driver", ["Allocation Driver ID", "Driver Type", "Driver Source Measure", "Capacity Cost Rate",
                                         "Unit Time Estimate"]),
            ("10", "Allocation Rule", ["Allocation Rule ID", "Source Cost Pool", "Applied Allocation Method", "Applied Driver",
                                       "Target Dimension", "Allocation Sequence", "Rule Effective From", "Rule Effective To"]),
            ("10", "Allocation Run", ["Allocation Run ID", "Run Period", "Run Data Version", "Run Status",
                                      "Unallocated Residual"]),
            ("10", "Allocation Result", ["Allocated Rule", "Target Dimension Member", "Driver Share", "Allocated Amount"]),
            ("10", "Management Hierarchy", ["Management Hierarchy ID", "Hierarchy Type", "Hierarchy Status",
                                            "Hierarchy Effective From", "Hierarchy Effective To"]),
            ("10", "Management Hierarchy Node", ["Node ID", "Parent Node", "Leaf Member", "Operating Segment Mapping"]),
            ("10", "Hierarchy Restatement", ["Restatement ID", "Restatement Trigger", "Restatement Method",
                                             "Restated From Period", "Restated To Period", "Prior Hierarchy Version"]),
            ("10", "Account Mapping", ["Account Mapping ID", "Management P&L Line", "GL Natural Account", "Applicable Ledger",
                                       "Mapping Effective From", "Mapping Effective To"]),
            ("19", "GL Account Balance", ["Balance GL Account", "Balance Segment Combination", "Balance Fiscal Period",
                                          "Balance Type", "Balance Ledger", "Balance Currency", "Opening Balance",
                                          "Closing Balance"]),
            ("19", "GL Account", ["GL Account ID", "GL Account Type", "Financial Statement Class"]),
            ("19", "Ledger", ["Ledger ID", "Ledger Role", "Ledger Currency"]),
            ("19", "Accounting Period Status", ["Status Ledger", "Status Fiscal Period", "Period Close Status"]),
        ],
        upstream=["DP-191", "DP-190", "DP-004", "DP-240", "DP-001", "DP-003", "DP-093", "DP-009", "DP-013"],
        refresh="Monthly",
        timeliness="Business day 8 after month-end, after the DP-191 hard close; preliminary runs from business day 4",
        history="Every run and Run Data Version kept, Final runs immutable; hierarchy versions and restatements kept with their effective periods; 7 years (financial records), month-end snapshots",
        classification="Confidential - Financial",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "File extract"],
        dq_rules=[
            "Every Source Cost Pool, Applied Allocation Method, Applied Driver and Allocated Rule resolves to its 10 object, every Contributing Cost Center to an active DP-190 cost center, every GL Natural Account to an active DP-190 GL account, and every Leaf Member and Target Dimension Member to the source of its Target Dimension: Service Offering, Service Tier, Product and Share Class to DP-004, Partner Firm to DP-001, Retirement Plan to DP-003, Household, Client and Client Segment to DP-240, Account to DP-093, Advisor to DP-009, Legal Entity and Region to DP-013, Channel and Business Line to their DP-013 code lists, and pool-to-pool rows to a Cost Pool ID.",
            "No cost center is a Contributing Cost Center of two Cost Pools in the same run, for one Source Cost Pool, Target Dimension and Allocation Sequence no two Allocation Rules overlap in effect, one GL Natural Account x Applicable Ledger maps to one Management P&L Line on any date, and only one Management Hierarchy version per Hierarchy Type has Hierarchy Status = Active on any date; every period ends on or after it starts.",
            "For each Final run, Allocation to Ledger Difference is within 0.5% of Pool Source Cost or USD 10,000, whichever is larger, Certified Operating Expense by Cost Center (from DP-191) equals DP-191's published value for the same cost center and period, and Driver Share Variance is below 0.01 percentage points for every rule.",
            "Allocated Amount, Allocated Rule and Target Dimension Member are populated on every Allocation Result row, Cost-to-Serve Component on every Cost Pool other than Cost Pool Type = Corporate Overhead, and Allocation Method Type and Driver Type on every method and driver.",
            "Allocation Result rows whose rule's Target Dimension is Household, Account, Client or Advisor are published only summed to run x rule x Target Dimension; the member-level rows reach only the restricted views of DP-498 and DP-499 (CW-243, CD-344).",
            "Only one Allocation Run per Run Period has Run Status = Final; a Final run is never changed (a correction is a new Run Data Version and the prior run becomes Superseded), and hierarchy changes to closed periods are made only through a Hierarchy Restatement.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Allocation Method' (10, ALM-), 'Management Hierarchy Node' (10, renamed "
               "from Hierarchy Node, CW-159) and 'Account Mapping (management P&L line -> GL account)' (10, ACM-); the cost "
               "pool, rule, run and result keys (CPO-, ARU-, ARN-, MHY-, HRS-) are 10's per CW-159 but have no concept row of "
               "their own. It is the source of the WP2 shared dimensions 'Management hierarchy' and 'Cost pool' (DIS+FDN brief "
               "section 5) for every 10 consumer. "
               "Certified numbers: reads Certified Operating Expense from DP-191 at its cost center grain (CW-011); owns none. "
               "Allocated cost reconciles to it (DQ3) and is never presented as a ledger figure. "
               "PII tier: none in the published output. Allocation Result rows whose target is a Client Household or account "
               "are PII - financial and advisor-target rows carry employee compensation cost (CD-344 tier); they are summed to "
               "the target dimension before publication (DQ5) and released at member grain only through the named restricted "
               "views of DP-498 and DP-499, registered in DP-518 (CW-243; household profitability is restricted by ruling). "
               "pii = N is therefore deliberate; the dp_model warning on Target Dimension Member and Allocated Amount (noted "
               "PII on household rows in 10) is accepted. "
               "Boundaries: cost to serve, lifetime value and acquisition cost are DP-498's (it reads 10 Cost-to-Serve Profile "
               "and this allocation); profitability records are DP-499's; distribution cost items and accruals are DP-487's; "
               "cash program economics DP-497's. Driver volumes (06 measures named by Driver Source Measure) are not read: the "
               "allocation engine applies them and 10 stores the resulting Driver Share. The candidate's 09 Cost & Profit "
               "Center is not read: its Cost Center Code is a Derived copy of 19, and the cost center and its org unit are read "
               "through DP-190 (19 Chart Segment Value, CD-152). DP-192 is not upstream (the candidate listed it): no headcount "
               "or employee attribute is read; a headcount driver's volume comes from the allocation engine. DP-240, DP-001, "
               "DP-003, DP-093 and DP-009 are upstream only as the sources against which target dimension members resolve "
               "(DQ1); none of them lists DP-480, so no cycle arises. "
               "Acceptance question 11: feeds DP-498 with Allocated Cost by Cost-to-Serve Component and the Management "
               "hierarchy and Cost pool dimensions; mastering domain 10. "
               "Tailoring lever: cost-to-serve granularity (10 SME 9). Reference default: pools carry the seven values of the "
               "10 Cost-to-Serve Component list (Advice, Service, Platform, Clearing and Client Asset Custody, Money Movement, "
               "Communications, Regulatory), and 10 Cost-to-Serve Profile stores six amounts with Communications and "
               "Regulatory combined; the lever stores the two separately. "
               "Tailoring lever: TDABC drivers. Reference default: time-driven drivers for service and operations pools, "
               "proportional drivers for platform and overhead. "
               "Tailoring lever: household-level economics visibility (10 SME 7). Reference default: restricted; advisor-facing "
               "household views register in DP-518 and are served by DP-498, never here. "
               "Taxonomy gap: 10 Cost Pool has no amount; Pool Source Cost is derived from DP-191 through Contributing Cost "
               "Centers, and Included Expense Categories (Cost Item Category values) have no mapping to GL accounts, so it does "
               "not filter the amount. "
               "Taxonomy gap: the 10 Profitability Dimension list has no Cost Pool value, so the intermediate pool-to-pool rows "
               "of Step-Down and Reciprocal methods are recognized only by a Target Dimension Member that is a Cost Pool ID. "
               "Taxonomy gap: 10 Allocation Result has no explicit Allocation Run attribute in the catalog; the run is the "
               "parent of the attribute group (grain run x rule x member). "
               "Taxonomy gap: 10 Management Hierarchy Node has no attribute naming its Management Hierarchy version; the version "
               "is the parent of the attribute group. "
               "Drafting assumptions: DQ3 tolerance 0.5% or USD 10,000; Driver Share tolerance 0.01 percentage points; Ledger Role "
               "value Primary and Period Close Status values Hard Close and Permanently Closed (as DP-191 uses them); one pool "
               "per cost center; Run Status values Final "
               "and Superseded; operating-expense Financial Statement Class values as DP-191 defines them; Allocation Method "
               "Type values that need a driver; Target Dimension values treated as restricted (Household, Account, Client, "
               "Advisor). "
               "Decisions: CW-156, CW-157, CW-159, CW-243, CW-011, CD-152, CD-344. "
               "WP1 new (CW-240): foundational product of the DIS+FDN brief, registered in WAVE_WP1F at the WP0 integration; "
               "inputs are the candidate's ten 10 objects plus 19 GL Account Balance, GL Account, Ledger and Accounting Period "
               "Status for the certified operating expense read from DP-191; 09 Cost & Profit Center replaced by DP-190 as stated above."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-481": dict(
        definition=("The master of the firm's competitors and what they charge: each competitor (11 Competitor Profile on a "
                    "02 party), its brokerage, digital and human advice, workplace, cash, trust, fund and ETF offerings (11 "
                    "Competitor Offering) mapped to the comparable own offering, and every observed price component "
                    "(advisory fee rate, commission per trade, account service fee, margin rate, cash sweep yield, expense "
                    "ratio) by balance tier, as-of date and source (11 Competitor Pricing Observation), with the recommended "
                    "fee ranges of the firm's fee studies (11 Pricing Input). It conforms the competitor and competitor "
                    "offering once (CONCEPT_OWNERSHIP rows 'Competitor Profile' (11, CPF-) and 'Competitor Offering' (11, "
                    "COFF-)) so that fee benchmarks, pricing scenarios, product business cases and market watch use one "
                    "competitor and price record. It owns no certified metric family."),
        business_questions=[
            "Which competitors do we track, by tier and type, and which of their offerings contest each of our business lines?",
            "What does each competitor offering charge today for each price component and balance tier, and from which source?",
            "What are the competitor median advisory fee rate, commission per trade and cash sweep yield by offering type?",
            "Which competitor offerings have stale prices, and which prices changed this period?",
            "Which competitor offerings are mapped to a comparable own offering, and what fee range did our latest fee studies recommend?",
        ],
        grain=("Competitor offering x price component x observation as-of date x balance tier lower bound (price observation), "
               "with the competitor profile and offering as SCD type 2 reference and fee study recommendations as companion "
               "rows; observations are append-only"),
        dimensions=["Competitor (DP-240 party)", "Competitor tier", "Competitor type", "Competitor offering",
                    "Competitor offering type", "Contested business line", "Offering status",
                    "Comparable own offering (DP-004)", "Price component", "Price quote basis", "Balance tier",
                    "Price source type", "Observation as-of date (DP-013)", "Fee study"],
        measures=[
            ("Tracked Competitors",
             "Count of distinct Competitor Profile ID whose Competitor Party is an active party, by Competitor Tier and "
             "Competitor Type.",
             _u("11", "Competitor Profile", "Competitor Profile ID", "Competitor Party", "Competitor Tier", "Competitor Type")
             + _u("02", "Party", "Party Status")),
            ("Active Competitor Offerings",
             "Count of Competitor Offerings with Offering Status in (Active, Closed to New Clients), by Competitor Offering "
             "Type and Contested Business Line.",
             _u("11", "Competitor Offering", "Competitor Offering ID", "Offering Status", "Competitor Offering Type",
                "Contested Business Line")),
            ("Latest Observed Rate",
             "Per Priced Offering x Price Component x Balance Tier Lower Bound: Observed Rate of the observation with the "
             "latest Observation As-of Date on or before the as-of date, with its Price Quote Basis (annual percentage of "
             "assets, annual percentage yield or annual interest rate).",
             _u("11", "Competitor Pricing Observation", "Priced Offering", "Price Component", "Balance Tier Lower Bound",
                "Observation As-of Date", "Observed Rate", "Price Quote Basis")),
            ("Latest Observed Amount",
             "Per Priced Offering x Price Component x Balance Tier Lower Bound: Observed Amount (USD) of the latest observation "
             "for amount-quoted components (Price Quote Basis per trade, per contract, per month, per year or per event).",
             _u("11", "Competitor Pricing Observation", "Priced Offering", "Price Component", "Balance Tier Lower Bound",
                "Observation As-of Date", "Observed Amount", "Price Quote Basis")),
            ("Competitor Median Advisory Fee Rate",
             "Median of Latest Observed Rate over Active Competitor Offerings with Price Component = Advisory Fee Rate, by "
             "Competitor Offering Type and Balance Tier Lower Bound.",
             _u("11", "Competitor Pricing Observation", "Price Component", "Balance Tier Lower Bound")
             + _u("11", "Competitor Offering", "Competitor Offering Type")
             + ["Latest Observed Rate", "Active Competitor Offerings"]),
            ("Competitor Median Commission per Trade",
             "Median of Latest Observed Amount over Active Competitor Offerings with Price Component = Commission per Trade, by "
             "Competitor Type.",
             _u("11", "Competitor Pricing Observation", "Price Component") + _u("11", "Competitor Profile", "Competitor Type")
             + ["Latest Observed Amount", "Active Competitor Offerings"]),
            ("Competitor Median Cash Sweep Yield",
             "Median of Latest Observed Rate over Active Competitor Offerings with Price Component = Cash Sweep Yield, by "
             "Competitor Type and Balance Tier Lower Bound.",
             _u("11", "Competitor Pricing Observation", "Price Component", "Balance Tier Lower Bound")
             + _u("11", "Competitor Profile", "Competitor Type") + ["Latest Observed Rate", "Active Competitor Offerings"]),
            ("Offerings With Current Price %",
             "Active Competitor Offerings with at least one Competitor Pricing Observation whose Observation As-of Date is "
             "within 35 days of the as-of date / Active Competitor Offerings.",
             _u("11", "Competitor Pricing Observation", "Priced Offering", "Observation As-of Date")
             + ["Active Competitor Offerings"]),
            ("Stale Price Observations",
             "Count of active offering x Price Component pairs whose latest Observation As-of Date is more than 35 days before "
             "the as-of date.",
             _u("11", "Competitor Pricing Observation", "Priced Offering", "Price Component", "Observation As-of Date")
             + ["Active Competitor Offerings"]),
            ("Price Changes in Period",
             "Count of Priced Offering x Price Component x Balance Tier Lower Bound keys whose observation in the period has an "
             "Observed Rate or Observed Amount different from the key's previous observation, by Price Component.",
             _u("11", "Competitor Pricing Observation", "Priced Offering", "Price Component", "Balance Tier Lower Bound",
                "Observation As-of Date", "Observed Rate", "Observed Amount")),
            ("Mapped to Own Offering %",
             "Active Competitor Offerings with Comparable Own Offering populated / Active Competitor Offerings.",
             _u("11", "Competitor Offering", "Comparable Own Offering") + ["Active Competitor Offerings"]),
            ("Vendor-Sourced Observation Share %",
             "Observations in the period with Price Source Type = Vendor Pricing Dataset / all observations in the period.",
             _u("11", "Competitor Pricing Observation", "Price Source Type", "Observation As-of Date")),
            ("Observations Without Source Document",
             "Count of observations with Price Source Type other than Vendor Pricing Dataset and Source Document Reference "
             "blank.",
             _u("11", "Competitor Pricing Observation", "Price Source Type", "Source Document Reference")),
            ("Recommended Fee Range Midpoint",
             "(Recommended Fee Range Low + Recommended Fee Range High) / 2 per fee study (Fee Study ID), in the study's Fee "
             "Measure Compared, with the Study Date.",
             _u("11", "Pricing Input", "Recommended Fee Range Low", "Recommended Fee Range High")
             + _u("11", "Fee Benchmark Study", "Fee Study ID", "Fee Measure Compared", "Study Date")),
        ],
        inputs=[
            ("11", "Competitor Profile", ["Competitor Profile ID", "Competitor Party", "Competitor Tier", "Competitor Type",
                                          "Vendor Manager Identifiers", "Competing Strategies"]),
            ("11", "Competitor Offering", ["Competitor Offering ID", "Offering Competitor", "Competitor Offering Name",
                                           "Competitor Offering Type", "Contested Business Line", "Account Minimum",
                                           "Offering Features", "Comparable Own Offering", "Offering Status"]),
            ("11", "Competitor Pricing Observation", ["Priced Offering", "Price Component", "Observation As-of Date",
                                                      "Observed Rate", "Observed Amount", "Price Quote Basis",
                                                      "Balance Tier Lower Bound", "Price Source Type",
                                                      "Source Document Reference"]),
            ("11", "Pricing Input", ["Recommended Fee Range Low", "Recommended Fee Range High", "Rationale"]),
            ("11", "Fee Benchmark Study", ["Fee Study ID", "Subject Share Class", "Subject Service Offering",
                                           "Fee Measure Compared", "Study Date"]),
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status"]),
        ],
        upstream=["DP-240", "DP-004", "DP-013"],
        refresh="Monthly",
        timeliness="By business day 5 of each month for the monthly capture; event-triggered observations (Competitor Event 'Cash Yield Change' or 'Pricing Change') loaded the same business day",
        history="Append-only observations kept 10 years; competitor profiles and offerings SCD type 2; source documents retained with the observation for fee study and Section 15(c) evidence",
        classification="Confidential",
        pii="N",
        delivery=["Warehouse table", "BI semantic model", "API"],
        dq_rules=[
            "Every Competitor Party resolves to an active DP-240 party with Party Type other than Individual and Household, every Offering Competitor to a Competitor Profile, every Priced Offering to a Competitor Offering, and every Comparable Own Offering, Subject Service Offering and Subject Share Class to DP-004.",
            "No two observations share Priced Offering, Price Component, Observation As-of Date and Balance Tier Lower Bound, and no Observation As-of Date is after the product's as-of date.",
            "Rate components carry Observed Rate and amount components carry Observed Amount consistent with Price Quote Basis, and Observed Rate is within plausible bounds (Advisory Fee Rate and Expense Ratio 0% to 3%, Cash Sweep Yield and Margin Rate 0% to 15%); breaches are held for analyst review before publication.",
            "Price Component, Observation As-of Date, Price Source Type and either Observed Rate or Observed Amount are populated on every observation, and Competitor Offering Type and Offering Status on every offering.",
            "Observations with Price Source Type = Vendor Pricing Dataset are published only within the permitted use and redistribution terms of their 14 license, and no observation or Source Document Reference carries personal data; example competitor names are hypothetical.",
            "By business day 5 of each month, every Active Competitor Offering has at least one Competitor Pricing Observation with an Observation As-of Date in the prior calendar month or later, and every offering x Price Component with Price Component = Cash Sweep Yield has one dated within the last 35 days.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Competitor Profile' (11, CPF-, on a 02 party, CD-012) and 'Competitor "
               "Offering' (11, COFF-, CW-160). It is the source of the WP2 shared dimensions 'Competitor' and 'Competitor "
               "offering' (DIS+FDN brief section 5) for DP-505, DP-506 and DP-497. "
               "Certified numbers: none owned or read. Competitor Metric Snapshot (reported client assets, net new assets) is "
               "DP-505's and is never compared with the firm's certified Client Assets here. "
               "PII tier: none. Competitors are organization parties; Competitor Personnel Move (PII - identity) is not read "
               "(DP-505). The catalog flags Competitor Profile ID, Competitor Offering ID, Priced Offering, Fee Study ID and Recommended Fee "
               "Range Low as PII only because their notes read 'No PII'; pii = N is deliberate and the dp_model warning is "
               "accepted. The 02 Party attributes read (Party Display Name, Party Type, Party Status) would be personal data "
               "for an individual, but DQ1 admits only competitor parties whose Party Type is not Individual or Household, so "
               "every published row is an organization and pii = N holds. "
               "Boundaries: the firm's own prices are 47 (DP-305) and 01 (DP-004), never held here; fee benchmark statistics "
               "and the comparison with own fees are DP-506's (Fee Benchmark Study is read only for the key and measure of its "
               "Pricing Input). This product is the one publisher of the fee-study recommendation (11 Pricing Input, Recommended "
               "Fee Range Low and High); DP-506 reads it from here and does not publish it a second time. The event-triggered "
               "capture on Competitor Event (Cash Yield Change, Pricing Change) is a source-system rule, not tested here: 11 "
               "Competitor Event is DP-505's read; pricing scenarios are DP-497's (backlog DP-500 folded there); peer funds, peer universes, "
               "ratings and industry flows are DP-014's and DP-505's. Competitor Display Name and Regulatory Identifiers are "
               "Derived copies of 02 and are not read: the name and identifiers come from the DP-240 party. DP-014 is not "
               "upstream (the candidate listed it): no industry or peer attribute is read. DP-014 also reads 11 Competitor "
               "Profile today; once this product is live the lineage pass may point DP-014's competitor join at DP-481. "
               "Tailoring lever: competitor set (11 SME 1). Reference default: direct brokerages, digital and hybrid advice "
               "firms, wirehouses, RIA aggregators, recordkeepers, fund and ETF sponsors, bank wealth managers, trust companies "
               "and OCIO providers, as 02 parties with hypothetical names. "
               "Tailoring lever: price observation sources and cadence (11 SME 2). Reference default: public schedules and "
               "disclosure documents captured monthly plus event-triggered capture; a vendor pricing dataset (Price Source Type "
               "'Vendor Pricing Dataset') moves classification to Confidential - Licensed. "
               "Tailoring lever: cash sweep yield as competitor pricing (11 SME 3). Reference default: yes; Competitor Median "
               "Cash Sweep Yield goes if cash is not a pricing lever. "
               "Taxonomy gap: 02 Party Role Type has no 'Competitor' value, although CD-012 places the competitor on a 02 party "
               "with a Competitor role; Tracked Competitors keys on Competitor Profile instead of a role. "
               "Taxonomy gap: 11 Pricing Input has no attribute naming its Fee Benchmark Study; the link is the parent of the "
               "attribute group. "
               "Drafting assumptions: 35-day currency window; Offering Status values counted active (Active, Closed to New "
               "Clients); plausibility bounds in DQ3; business day 5 capture deadline; Competitor Event types Cash Yield Change "
               "and Pricing Change. "
               "Decisions: CW-160, CW-158, CD-012, CW-240. "
               "WP1 new (CW-240): foundational product of the DIS+FDN brief, registered in WAVE_WP1F at the WP0 integration; "
               "inputs are the candidate's four 11 objects plus 11 Fee Benchmark Study keys and the 02 Party identity of the "
               "competitor."),
    ),
}
