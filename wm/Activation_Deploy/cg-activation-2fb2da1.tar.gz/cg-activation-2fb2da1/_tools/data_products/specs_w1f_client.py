"""Data product specifications, Stage WP1 Products, foundational wave (WP1F), group F1 'client': client and account masters.

Products (owning Data Domain):
- DP-240 Client, Household & Party Master (02), re-scoped in place (CW-204);
- DP-093 Account Master (15), re-scoped in place (CW-204);
- DP-004 Product, Offering & Share Class Reference (01), re-scoped in place and extended, with the DP-380 offering scope
  folded in (CW-202, CW-221);
- DP-381 Client Service Interactions & Requests (13), new (CW-222, CW-229);
- DP-382 Client Document & Delivery Record (13), new (CW-223, CW-229).

WP1 decisions applied (WP1_Method.md section 2): certified numbers are defined once (CW-011); the household, client and
funded account counts are published by DP-008 as 06 measures, so DP-240 and DP-093 publish the masters and stewardship
counts only; the household dimension stays inside DP-240; special-category client facts reach other products only
through DP-322 (CW-213, CD-344), so no product here reads 02 Specified Adult Status or Vulnerability Concern, or the
FINRA Rule 2165 rows of 15 Account Restriction; DP-380 is folded into DP-004, which reads 01 Offering Fee Schedule Link
and Model Portfolio; DP-002 is retired into DP-001 (CW-202).

Upstream graph inside the group (no cycles): DP-004 <- DP-240 <- DP-093; DP-240, DP-093 <- DP-381; DP-240, DP-093,
DP-004 <- DP-382.

Model re-cuts for the lineage pass (when the old specs of DP-240, DP-093 and DP-004 are deleted):
- DP-093 model (models_f4_accounts_plans): Party entity (02 Party, 02 Tax Profile; conformed from DP-001) -> DP-240;
  Share Class entity (01 Share Class) and Service Offering entity (01 Service Offering) -> conformed from DP-004;
  Rep of Record entity (retired DP-002) -> DP-001 (intermediary advisor) or DP-009 (own advisor).
- DP-004 model (models_f1.py): Share Class entity loses 01 Other Ongoing Fees (read by DP-170, DP-506, DP-586);
  superseded by the lineage addition for C-4: Share Class folds 01 Management Fee and Other Ongoing Fees again (DP-586, DP-595).
- Lineage addition for C-4: DP-240 publishes 02 Trusted Contact Designation Account Scope (DP-583).
- DP-240 model (models_e8_foundations): Party entity loses 02 Market Infrastructure & Vendor Identifier -> DP-001.
See CONTRACT.md.
"""


def _u(nn, obj, *attrs):
    return [(nn, obj, a) for a in attrs]


SPECS = {
    # ------------------------------------------------------------------------------------------------------------------
    "DP-240": dict(
        definition=("The one conformed record of every client and household and of every other party the firm deals with: "
                    "the 02 Party identity with its individual or organization profile, the Client Household (a party of type "
                    "Household) and its effective-dated memberships, roles and relationships, identifiers, authority grants, "
                    "trusted contacts and death notifications, the versioned investor profile, KYC, CIP and beneficial "
                    "ownership, tax profile, regulatory classification, segments and service tiers, contact points, privacy "
                    "and consent, and client restrictions. The client household is the primary role family; counterparties, "
                    "issuers, vendors and intermediaries are thinner roles on the same party, and their role profiles stay "
                    "with DP-001, DP-003, DP-098, DP-115 and DP-210. It conforms the CONCEPT_OWNERSHIP rows 'Party' (02, PTY-) "
                    "and 'Household' (02, PTY-HH-) once and is the source of the client, household and party dimension. It "
                    "owns no certified metric family: the counts of households and clients are DP-008's."),
        business_questions=[
            "Which clients and households do we have today, who belongs to each household and since when, and which client individuals belong to no confirmed household?",
            "Which clients lack a verified identity under the CIP program they are onboarded to, a complete KYC profile, a TIN on file or a beneficial ownership certification where one is required?",
            "Which clients have no attested investor profile in force, and which have no Reg BI retail customer classification?",
            "Which deceased clients still hold an active client role, and which clients have no verified primary contact point?",
            "Which consents, privacy opt-outs and client restrictions are in force for each client, and which parties look like duplicates of each other?",
            "Which roles does each party play for the firm, and does every own legal entity have its party mirror?",
        ],
        grain=("Party x role type x role effective period (SCD type 2), with the party profile (individual, organization, "
               "household, tax profile, KYC profile, privacy profile) as a conformed dimension; Household Membership as a "
               "bridge at client household x member party x membership effective period; child tables at party x "
               "identifier scheme x identifier value, investor profile version, identity verification, beneficial "
               "ownership certification x owner x prong, authority grant, trusted contact designation, death notification, "
               "contact point, consent record, client restriction, segment assignment and service tier assignment, each "
               "keyed by the 02 PTY- key and effective dated"),
        dimensions=["Party", "Party type (organization / individual)", "Party status", "Relationship stage",
                    "Role type and role status", "Client household (household dimension, CW-027)",
                    "Household member role", "Party type and legal form", "Legal jurisdiction",
                    "Direct and ultimate parent", "Identifier scheme", "Relationship type", "Party origin",
                    "Investor category and Reg BI retail customer indicator", "Segmentation scheme and segment",
                    "Service tier (DP-004)", "Business line", "Effective date / version"],
        measures=[
            ("Active Parties by Role", "Count of distinct Party ID with Party Status = Active and a Party Role with Role Status = Active and Role Effective From <= as-of date < Role Effective To (or open), by Role Type and Role Business Line.",
             _u("02", "Party", "Party ID", "Party Status") + _u("02", "Party Role", "Role Party", "Role Type", "Role Status",
                                                              "Role Effective From", "Role Effective To", "Role Business Line")),
            ("Multi-Role Parties", "Count of active parties with two or more distinct Role Type values active on the as-of date, by role combination (for example a client who is also a trusted contact of another client).",
             _u("02", "Party Role", "Role Type", "Role Status") + ["Active Parties by Role"]),
            ("Client Individuals Without Household", "Count of parties with Party Type = Individual and an active Party Role of Role Type = Client (Active Parties by Role) that are not the Household Member of any Household Membership with Membership Status = Active and Membership Effective From <= as-of date < Membership Effective To (or open).",
             _u("02", "Party", "Party Type") + _u("02", "Household Membership", "Household Member", "Membership Status",
                                                 "Membership Effective From", "Membership Effective To") + ["Active Parties by Role"]),
            ("Households Without Valid Primary Member %", "Parties with Party Type = Household and Party Status = Active whose Household Primary Member is empty or is not the Household Member of an Active Household Membership of that Household open on the as-of date / parties with Party Type = Household and Party Status = Active. A data quality ratio; the certified household count is DP-008's Households.",
             _u("02", "Party", "Party Type", "Party Status") + _u("02", "Household", "Primary Member")
             + _u("02", "Household Membership", "Household", "Household Member", "Membership Status")),
            ("Unconfirmed Household Memberships", "Count of Household Membership rows open on the as-of date with Membership Status = Proposed, plus Active rows of households whose Household Formation Basis = System Suggested - Unconfirmed or whose Membership Last Confirmed Date is more than 24 months before the as-of date.",
             _u("02", "Household Membership", "Household", "Membership Status", "Membership Effective From", "Membership Effective To")
             + _u("02", "Household", "Household Formation Basis", "Membership Last Confirmed Date")),
            ("Clients Without Active Investor Profile", "Count of parties with an active Client role (Active Parties by Role, Role Type = Client) and Party Type other than Household with no Investor Profile whose Profile Client is the party, Profile Status = Active and Attested Date is populated, by Relationship Stage and Party Type.",
             _u("02", "Investor Profile", "Profile Client", "Profile Status", "Attested Date")
             + _u("02", "Party", "Party Type", "Relationship Stage") + ["Active Parties by Role"]),
            ("KYC Incomplete or Overdue", "Count of parties with an active Client role whose KYC Profile KYC Status is not Complete or whose Next KYC Review Date is before the as-of date, by Due Diligence Level; the split by AML Risk Rating is shown in the restricted onboarding view only.",
             _u("02", "KYC Profile", "KYC Status", "Next KYC Review Date", "Due Diligence Level", "AML Risk Rating")
             + ["Active Parties by Role"]),
            ("CIP Verification Gap", "Count of parties with Relationship Stage in Applicant or Client that are the Verified Party of no Identity Verification with Verification Result in Verified or Verified - Discrepancy Resolved, by CIP Program (one verification per CIP program, 02 SME 4).",
             _u("02", "Party", "Relationship Stage") + _u("02", "Identity Verification", "Identity Verification ID", "Verified Party",
                                                          "Verification Result", "CIP Program")),
            ("Clients Without TIN on File", "Count of parties with an active Client role and Tax Profile US Person Indicator = Y whose Tax Identification Number is empty or whose TIN Type = Applied For, by Tax Classification. The TIN itself is never published (DQ5).",
             _u("02", "Tax Profile", "US Person Indicator", "Tax Identification Number", "TIN Type", "Tax Classification")
             + ["Active Parties by Role"]),
            ("Clients Without Regulatory Classification", "Count of parties with an active Client role that are the Classified Party of no Regulatory Classification row with Reg BI Retail Customer Indicator and FINRA Institutional Account Indicator both populated, by Party Type.",
             _u("02", "Regulatory Classification", "Classified Party", "Reg BI Retail Customer Indicator",
                "FINRA Institutional Account Indicator") + _u("02", "Party", "Party Type") + ["Active Parties by Role"]),
            ("Beneficial Ownership Coverage %", "Active parties with Party Type in Corporation, Partnership / LLC or Nonprofit, an active Client role and Legal Entity Customer Exclusion Basis = Not Excluded that are the Certified Entity of a Beneficial Ownership Certification with Certification Status = Active naming at least one Beneficial Ownership row with Ownership Prong = Control / those parties (31 CFR 1010.230).",
             _u("02", "Party", "Party Type") + _u("02", "Organization", "Legal Entity Customer Exclusion Basis")
             + _u("02", "Beneficial Ownership Certification", "Certified Entity", "Certification Status")
             + _u("02", "Beneficial Ownership", "Ownership Certification", "Beneficial Owner", "Ownership Prong")
             + _u("02", "Party Role", "Role Type", "Role Status")),
            ("Deceased Parties With Active Client Role", "Count of parties with Individual Date of Death populated, or that are the Deceased Party of a Death Notification whose Notification Status is not Rejected or Canceled, that still hold a Party Role with Role Type = Client and Role Status = Active on the as-of date; business days since Notification Received Date shown (DP-013 calendar).",
             _u("02", "Individual", "Date of Death") + _u("02", "Death Notification", "Deceased Party", "Notification Status",
                                                          "Notification Received Date") + _u("02", "Party Role", "Role Type", "Role Status")),
            ("Clients Without Verified Primary Contact Point", "Count of parties with an active Client role that are the Contact Point Party of no Contact Point open on the as-of date (Contact Point Effective From <= as-of date < Contact Point Effective To or open) with Primary Contact Point Indicator = Y and Contact Point Verified Indicator = Y, by Contact Channel.",
             _u("02", "Contact Point", "Contact Point Party", "Primary Contact Point Indicator", "Contact Point Verified Indicator",
                "Contact Point Effective From", "Contact Point Effective To", "Contact Channel") + ["Active Parties by Role"]),
            ("Active Consents by Purpose", "Count of Consent Record rows with Consent Status = Granted, Consent Withdrawn Timestamp empty and Consent Expiry Date empty or on or after the as-of date, by Consent Purpose and Consent Capture Method.",
             _u("02", "Consent Record", "Consent Record ID", "Consent Status", "Consent Withdrawn Timestamp", "Consent Expiry Date",
                "Consent Purpose", "Consent Capture Method")),
            ("Open Client Restrictions", "Count of Client Restriction rows with Restriction Status = Active and Restriction Effective From <= as-of date < Restriction Effective To (or open), by Restriction Category and Restriction Source; rows with Rule 3a-4 Reasonable Restriction Indicator = Y shown separately.",
             _u("02", "Client Restriction", "Client Restriction ID", "Restriction Status", "Restriction Effective From",
                "Restriction Effective To", "Restriction Category", "Restriction Source", "Rule 3a-4 Reasonable Restriction Indicator")),
            ("Client Households Without Service Tier", "Count of parties with Party Type = Household and Party Status = Active that are the Tier Party of no Service Tier Assignment with Assigned Service Tier populated and Tier Effective From <= as-of date < Tier Effective To (or open); assigned rows are shown by Assigned Service Tier and Tier Assignment Method.",
             _u("02", "Party", "Party Type", "Party Status") + _u("02", "Service Tier Assignment", "Tier Party", "Assigned Service Tier",
                                                                  "Tier Effective From", "Tier Effective To", "Tier Assignment Method")),
            ("Organizations Without LEI %", "Active organization parties (Party Type other than Individual and Household) in at least one active role other than Client and Prospect with no LEI Record whose LEI Registration Status = Issued / those parties.",
             _u("02", "Party", "Party Type") + _u("02", "LEI Record", "LEI", "LEI Registration Status")
             + _u("02", "Party Role", "Role Type") + ["Active Parties by Role"]),
            ("Merged Party Records", "Count of parties with Merged Into Party populated, in the period and cumulative, by Party Origin.",
             _u("02", "Party", "Merged Into Party", "Party Origin")),
            ("Potential Duplicate Parties", "Count of pairs of active parties that share an LEI, a Firm CRD Number, an Employer Identification Number or an active Party Identifier (same Identifier Scheme and Identifier Value with Identifier Status = Active); or, for Party Type = Individual, the same Given Name, Family Name and Date of Birth; or, for organizations, the same Legal Name and Legal Jurisdiction. A steward worklist.",
             _u("02", "LEI Record", "LEI") + _u("02", "US Regulatory Identifier", "Firm CRD Number", "Employer Identification Number")
             + _u("02", "Party Identifier", "Identifier Scheme", "Identifier Value", "Identifier Status")
             + _u("02", "Individual", "Given Name", "Family Name", "Date of Birth")
             + _u("02", "Organization", "Legal Name", "Legal Jurisdiction") + _u("02", "Party", "Party Status")),
            ("Own Entity Mirror Coverage %", "09 Internal Legal Entities with Entity Status = active whose Party Master Cross-Reference resolves to an active Party ID / active Internal Legal Entities (CD-010).",
             _u("09", "Internal Legal Entity", "Legal Entity ID", "Entity Status", "Party Master Cross-Reference")
             + _u("02", "Party", "Party ID", "Party Status")),
        ],
        inputs=[
            ("02", "Party", ["Party ID", "Party Type", "Party Display Name", "Party Status", "Relationship Stage", "Party Origin",
                             "Merged Into Party", "Primary Country"]),
            ("02", "Individual", ["Given Name", "Family Name", "Preferred Name", "Date of Birth", "Citizenship Countries",
                                  "Employment Status", "Associated Person Disclosure Indicator", "Date of Death"]),
            ("02", "Organization", ["Legal Name", "Legal Form", "Legal Jurisdiction", "Industry Classification", "Primary Regulator",
                                    "Legal Entity Customer Exclusion Basis"]),
            ("02", "Legal Entity Hierarchy", ["Subsidiary Party", "Direct Parent", "Ultimate Parent", "Parent Relationship Basis",
                                              "Hierarchy Effective From", "Hierarchy Effective To"]),
            ("02", "Party Role", ["Role Party", "Role Type", "Role Status", "Role Business Line", "Role Effective From",
                                  "Role Effective To"]),
            ("02", "Party Identifier", ["Identified Party", "Identifier Value", "Identifier Scheme", "Identifier Status",
                                        "Identifier Effective From"]),
            ("02", "LEI Record", ["LEI", "LEI Registration Status"]),
            ("02", "US Regulatory Identifier", ["Firm CRD Number", "Employer Identification Number"]),
            ("02", "Household", ["Household Name", "Household Formation Basis", "Primary Member", "Membership Last Confirmed Date"]),
            ("02", "Household Membership", ["Household", "Household Member", "Household Member Role", "Membership Status",
                                            "Membership Effective From", "Membership Effective To"]),
            ("02", "Party Relationship", ["From Party", "To Party", "Relationship Type", "Relationship Effective From",
                                          "Relationship Effective To"]),
            ("02", "Authority Grant", ["Authority Grant ID", "Grantor Party", "Authority Holder", "Authority Type", "Authority Scope",
                                       "Accounts Covered", "Grant Effective From", "Revoked Date"]),
            ("02", "Trusted Contact Designation", ["Trusted Contact Designation ID", "Designating Client", "Trusted Contact Person",
                                                   "Designation Status", "Account Scope", "Designation Effective From", "Designation Effective To"]),
            ("02", "Death Notification", ["Death Notification ID", "Deceased Party", "Notification Received Date",
                                          "Notification Status"]),
            ("02", "Investor Profile", ["Investor Profile ID", "Profile Client", "Profile Scope", "Profile Version Number",
                                        "Investment Objective", "Risk Tolerance", "Time Horizon", "Liquidity Need",
                                        "Annual Income Band", "Net Worth Band", "Risk Score", "Attested Date", "Next Review Date",
                                        "Profile Status"]),
            ("02", "Investment Experience", ["Experience Profile", "Product Experience Type", "Years of Experience"]),
            ("02", "Investor Qualification", ["Qualified Party", "Qualification Standard", "Determination Date",
                                              "Qualification Expiry Date"]),
            ("02", "KYC Profile", ["KYC Status", "AML Risk Rating", "Due Diligence Level", "PEP Status", "Sanctions Screening Result",
                                   "Next KYC Review Date"]),
            ("02", "Identity Verification", ["Identity Verification ID", "Verified Party", "CIP Program", "Verification Method",
                                             "Verification Result", "Verification Date"]),
            ("02", "Beneficial Ownership Certification", ["Beneficial Ownership Certification ID", "Certified Entity",
                                                          "Certification Date", "Certification Status", "Recertification Due Date"]),
            ("02", "Beneficial Ownership", ["Ownership Certification", "Beneficial Owner", "Ownership Prong",
                                            "Beneficial Ownership Percentage"]),
            ("02", "Tax Profile", ["US Person Indicator", "Tax Classification", "Tax Identification Number", "TIN Type",
                                   "FATCA Status"]),
            ("02", "Regulatory Classification", ["Classified Party", "Categorization Date", "Reg BI Retail Customer Indicator",
                                                 "FINRA Institutional Account Indicator", "Investor Category"]),
            ("02", "Segment Assignment", ["Segmented Party", "Segmentation Scheme", "Segment", "Assignment Method",
                                          "Segment Effective From", "Segment Effective To"]),
            ("02", "Service Tier Assignment", ["Tier Party", "Assigned Service Tier", "Tier Assignment Method", "Tier Effective From",
                                               "Tier Effective To"]),
            ("02", "Contact Point", ["Contact Point ID", "Contact Point Party", "Contact Channel", "Contact Point Usage",
                                     "Primary Contact Point Indicator", "Contact Point Verified Indicator",
                                     "Contact Point Effective From", "Contact Point Effective To"]),
            ("02", "Postal Address", ["Country Subdivision", "Postal Code", "Country"]),
            ("02", "Privacy Profile", ["Applicable Privacy Regimes", "Nonaffiliated Sharing Opt-Out Indicator",
                                       "Affiliate Marketing Opt-Out Indicator", "Do Not Contact Indicator"]),
            ("02", "Consent Record", ["Consent Record ID", "Consenting Party", "Consent Purpose", "Consent Status",
                                      "Consent Capture Method", "Consent Expiry Date", "Consent Withdrawn Timestamp"]),
            ("02", "Client Restriction", ["Client Restriction ID", "Restricted Party", "Restriction Category", "Restriction Source",
                                          "Rule 3a-4 Reasonable Restriction Indicator", "Restriction Status",
                                          "Restriction Effective From", "Restriction Effective To"]),
            ("09", "Internal Legal Entity", ["Legal Entity ID", "Legal Name", "Entity Status", "Party Master Cross-Reference"]),
        ],
        upstream=["DP-004", "DP-013"],
        refresh="Daily",
        timeliness=("By 6am ET on T+1 for party, household, profile and KYC changes approved by 9pm ET; a party created for an "
                    "account opening, a trade or a vendor onboarding is available through the API within 15 minutes of approval, "
                    "and death notifications and merges are on the event stream within 15 minutes"),
        history=("SCD type 2 on the party, its profiles, roles, identifiers, household memberships, relationships, investor "
                 "profile versions, consents and restrictions since first set-up; merged and inactive parties kept indefinitely "
                 "with their survivor link; customer identification records kept five years after the account closes (31 CFR "
                 "1023.220) and account records at least six years (SEC Rule 17a-4)"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream", "Reverse ETL to CRM"],
        dq_rules=[
            "Every Role Party, Household, Household Member, Identified Party, Profile Client, Verified Party, Certified Entity, Grantor Party, Authority Holder, Designating Client, Trusted Contact Person, Consenting Party, Restricted Party, Segmented Party and Tier Party resolves to a Party ID that is Active or Merged (a merged party is re-pointed to its survivor), every Household resolves to a party with Party Type = Household, and every Assigned Service Tier resolves to an active DP-004 Service Tier Code.",
            "For one party and Role Type, and for one Household and Household Member, the effective periods do not overlap and every effective-to date is on or after its effective-from date; an individual is the Household Member of at most one Active Household Membership on any date, and a party has at most one Investor Profile with Profile Status = Active per Profile Scope.",
            "Every party with Relationship Stage = Client holds a Party Role of Role Type = Client with Role Status = Active and every party holding that role has Relationship Stage = Client (0 exceptions; DP-093 tests that each open account's Role Party is such a party), and every active 09 Internal Legal Entity has a Party Master Cross-Reference to exactly one active party (CD-010).",
            "Every active individual client has Given Name, Family Name, Date of Birth and Citizenship Countries, and a Tax Identification Number when US Person Indicator = Y; every active organization client has Legal Name, Legal Jurisdiction and Legal Entity Customer Exclusion Basis; every Active Investor Profile has Investment Objective, Risk Tolerance, Time Horizon, Annual Income Band and Net Worth Band.",
            "Tax Identification Number is never published (only TIN Type and a TIN-present flag), Date of Birth appears only in the restricted servicing view, AML Risk Rating, PEP Status and Sanctions Screening Result appear only in the restricted onboarding and AML view, and no 02 Specified Adult Status, Vulnerability Concern or Restricted Client Status attribute is read (CD-344, CW-213).",
            "The daily snapshot is complete by 6am ET on T+1 with row counts per object equal to the 02 source control totals, and a Death Notification or party merge recorded in the source is on the event stream within 15 minutes.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Party (organization or individual)' (02, PTY-), 'Household' (02, PTY-HH-), "
               "'Party Identifier' (02), 'Contact Point' (02, CTP-), 'Consent Record' (02, CNS-), 'Client Restriction' (02, CRX-) "
               "and 'Client Segment / Party Classification' (02); the product publishes them for every role and never remasters "
               "them (CD-143, CD-360, CW-005). It is the SM-00 Party dimension (CD-296) and the source of the Client, household "
               "and party dimension of the WP2 conformed set; by the WP0 ruling the household dimension stays inside this product "
               "(CLA-A ruling 5). The household here is the 02 Client Household; the 13 Mailing Household (DP-382) and the 47 Fee "
               "Household (DP-305) are different groupings (CW-027). "
               "Certified numbers: none. The certified Households and Clients counts are DP-008 measures built from these keys "
               "(CW-011, CW-203); every count here is a stewardship count or the denominator of a quality ratio. "
               "PII tier: identity (with financial investor profile bands; special category not read). Publication: the "
               "analytics view carries party keys, types, statuses, household membership, segments, tiers and classifications "
               "without names, addresses or dates of birth; names and contact points are in the servicing view; TIN, date of birth "
               "and the AML attributes as DQ5 states. "
               "Boundaries: role profiles stay with the stewarding domain's product (CD-143): intermediary firms and external "
               "advisors in DP-001 (the restored 05 profiles), institutions, consultants and plans in DP-003 (12 and 02 Retirement "
               "Plan), issuers DP-098, counterparties and brokers DP-115, suppliers DP-210, contract parties DP-213; own advisors "
               "and employees are 03 and 20 (DP-009, DP-192). Specified adult status, vulnerability concerns and Restricted Client "
               "Status are published only by the restricted consumer DP-322 and by DP-077 (CW-213); every other product carries "
               "DP-322's Protection Flag Present indicator. The investor profile currency against recommendations is DP-303 and "
               "DP-334; trusted contact coverage is DP-321; contactability and the contact and communication preferences are "
               "DP-324; privacy requests and opt-out evidence DP-080. Objects with CDEs not read here and their readers: 02 "
               "Onboarding Case (DP-392), Contact Preference and Communication Preference (DP-324, DP-080), Consumer Privacy "
               "Request (DP-080), Restricted Client Status (DP-077), Retirement Plan (DP-003, DP-094), Specified Adult Status and "
               "Vulnerability Concern (DP-322); Market Infrastructure & Vendor Identifier is read by DP-001. 02 Postal Address "
               "Mail Returned Date is a derived copy of 13 and is read from DP-382 instead. 02 Service Tier Assignment Qualifying "
               "Client Assets is a derived copy of 06 and is not read (the amount is DP-008's). "
               "Acceptance question 9: feeds DP-145 and DP-532 with the Client Household dimension (02 Household and Household "
               "Membership as of the measurement date). Acceptance question 7: feeds DP-322 and DP-456 with the 02 party keys the "
               "restricted view joins on. Acceptance question 11: feeds DP-498 with the client segment dimension (Segment "
               "Assignment). "
               "Tailoring lever: household definition (02 SME 2). Reference default: client-defined households; system "
               "suggestions are held as Proposed memberships and excluded from household rollups until confirmed; an individual "
               "belongs to one client household at a time. "
               "Tailoring lever: investor profile scope (02 SME 1). Reference default: per client with a joint or household "
               "Profile Scope; a household-only firm collapses it to Profile Scope = Household. "
               "Tailoring lever: identity verification per CIP program (02 SME 4). Reference default: one record per program "
               "sharing evidence; with an outsourced transfer agent the fund CIP is oversight data in 29. "
               "Tailoring lever: prospects as parties (02 SME 9). Reference default: a prospect becomes a party once identity is "
               "captured (Relationship Stage = Prospect); anonymous leads stay in 04. "
               "Tailoring lever: trustees and executors (02 SME 7). Reference default: related parties unless they hold their own "
               "accounts. "
               "Tailoring lever: state privacy regimes (02 SME 8). Reference default: GLBA / Regulation S-P plus the state laws "
               "listed in Applicable Privacy Regimes. "
               "Taxonomy gap: 02 Party Role has no attribute naming the stewarding Data Domain or function of the role (CD-143); "
               "it is derived from the Role Type value. "
               "Taxonomy gap: 02 Party Identifier has no effective-to date; identifier history is kept as SCD type 2. "
               "Taxonomy gap: 02 Household has no household status or formation date of its own; the household's lifecycle is the "
               "Party Status of the Household party and its first Membership Effective From. "
               "Taxonomy gap: 02 KYC Profile and Tax Profile are attribute groups with no as-of or review-version key; KYC history is "
               "kept as SCD type 2 on the party. "
               "Drafting assumptions: Role Type = Client and Relationship Stage values Applicant and Client as the client "
               "population; the 24-month household reconfirmation window; legal entity customers taken as Party Type Corporation, "
               "Partnership / LLC and Nonprofit; the 15-minute event latency. "
               "Decisions: CW-005, CW-011, CW-024, CW-026, CW-027, CW-030, CW-203, CW-204, CW-213; CD-001, CD-010, CD-143, CD-296, "
               "CD-344, CD-360. "
               "W1 re-point (CW-902, CW-021): Organization Type is read from Party Type; Regulated Entity Indicator from Organization "
               "Primary Regulator; Deceased Indicator from Individual Date of Death; Role Source from Party Origin; Control Person "
               "Indicator from Beneficial Ownership Ownership Prong = Control, with owners hung from Beneficial Ownership "
               "Certification (Certified Entity); SEC Central Index Key and Business Identifier Code from Party Identifier rows of "
               "Identifier Scheme = SEC CIK and BIC. W1: Trading Name and Formation Date (Organization) dropped, no successor in the "
               "wealth 02 (CW-902). "
               "WP1 re-scope (CW-204): renamed from Enterprise Party & Role Master to Client, Household & Party Master; owner Head "
               "of Enterprise Data Management -> Head of Client Data; primary function FN-49 -> FN-62. Inputs added: 02 Household, "
               "Household Membership, Authority Grant, Trusted Contact Designation, Death Notification, Investor Profile, "
               "Investment Experience, Investor Qualification, KYC Profile, Identity Verification, Tax Profile, Regulatory "
               "Classification, Segment Assignment, Service Tier Assignment, Contact Point, Postal Address, Privacy Profile, "
               "Consent Record and Client Restriction; Individual Date of Birth, Citizenship Countries, Employment Status and "
               "Associated Person Disclosure Indicator. Inputs dropped: 02 Market Infrastructure & Vendor Identifier (read by "
               "DP-001 in specs_w1f_channels), LEI Record Registration Authority ID (no live reader; a non-CDE attribute left unread) "
               "and US Regulatory Identifier SEC File Number (read by DP-001 and the retired DP-037). Model re-cut for lineage: the "
               "DP-240 Party entity (models_e8_foundations) loses 02 Market Infrastructure & Vendor Identifier, now published by "
               "DP-001. Measures kept by name: Active Parties by Role (SM-00 metric source), "
               "Multi-Role Parties (SM-00 metric source), Organizations Without LEI %, Merged Party Records, Beneficial Ownership "
               "Coverage % (now on legal entity clients), Own Entity Mirror Coverage %. Measures dropped: 'Lapsed LEI Count' and "
               "'Ultimate Parent Coverage %' (read only by the SM-00 not-published list, sm_00_shared_dimensions.py lines 1607 and "
               "1608); renamed 'Potential Duplicate Organizations' -> 'Potential Duplicate Parties' (SM-00 not-published list line "
               "1609). Dimension names kept; added Relationship stage, Client household, Household member role, Investor category, "
               "Segmentation scheme and segment, Service tier and Business line. Objects behind conformed entities kept: Party "
               "(models_e8_masters Party, Counterparty, Vendor; models_e8_foundations Issuer; SM-00 and SM-12 Party), Legal Entity "
               "Hierarchy, Party Role, Party Identifier and Party Relationship (SM-00 bridges). Upstream adds DP-004 (service tier)."
               "WP1 lineage addition (CW-264, C-4 fix pass): 02 Trusted Contact Designation Account Scope is now read and published (DP-583 reads it for register holds on protected clients). No measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-093": dict(
        definition=("The conformed brokerage and advisory account record: every account of every line (brokerage, fund-only, "
                    "managed advisory, participant, plan, fiduciary, institutional separate and omnibus) by registration type "
                    "(individual, joint, IRA and Roth IRA, SEP and SIMPLE, 529, UTMA / UGMA, trust, estate, entity, HSA), with "
                    "identifiers, hierarchy links, party roles and beneficiaries, account investment profile, features (margin, "
                    "options, cash sweep, DRIP, checkwriting), agreements, advisory program enrollment, alternative investment "
                    "subscriptions, tax certification, cost-basis method election, RMD status, standing and bank instructions, "
                    "restrictions and the lifecycle from application to closure. It conforms the CONCEPT_OWNERSHIP row 'Account' "
                    "(15, ACC-) once for every line (plan section 4 item 2) and is the source of the client account dimension. It "
                    "holds no quantity, value, lot or balance (CW-007) and owns no certified metric family: the funded account "
                    "count is DP-008's."),
        business_questions=[
            "Which accounts are open today, of which type, registration and business line, who owns them, and how do omnibus, plan, participant and inherited accounts link together?",
            "Which open accounts lack a primary identifier, an owner role, a certified TIN or a current account investment profile, or are subject to backup withholding?",
            "Which accounts are enrolled in which advisory programs, and which enrollments or margin, options and lending features have no executed agreement behind them?",
            "Which accounts carry an open restriction, which IRAs have an RMD outstanding this year, and which custodial accounts reach the age of majority in the next 90 days?",
            "How long does an account take from application to good order, by application channel and carrying entity, and which accounts closed in the period, to which firm and why?",
            "Which alternative investment subscriptions are awaiting acceptance, and which beneficiary designations do not allocate 100%?",
        ],
        grain=("Account x effective period (SCD type 2 version), with identifier, hierarchy link, party role, beneficiary, "
               "investment profile, feature, sweep election, agreement, program enrollment, subscription, tax certification, "
               "cost basis election, RMD record, standing instruction, bank instruction, lifecycle event, status period and "
               "restriction as child tables keyed on Account ID"),
        dimensions=["Account type and registration type", "Account status", "Account business line", "Reg T account type",
                    "Networking level", "Dealer, branch and rep of record (DP-001)", "Account hierarchy link type",
                    "Retirement plan and participant", "Related mandate, custodian and governing contract",
                    "Enrolled service offering (DP-004)", "Account feature type", "Sweep vehicle type",
                    "Application channel and carrying entity", "Tax classification, tax residence and reporting regime",
                    "Restriction type", "Client and household (DP-240)", "Effective date"],
        measures=[
            ("Active Accounts", "Count of distinct Account ID with Account Status = Open on the as-of date, by Account Type, Account Registration Type and Account Business Line. A stewardship count and the denominator of the ratios here; the certified Funded Accounts count is DP-008's (CW-011).",
             _u("15", "Account", "Account ID", "Account Status", "Account Type", "Account Registration Type", "Account Business Line")),
            ("Primary Identifier Completeness %", "Active accounts with exactly one Account Identifier with Primary Identifier Indicator = Y and Account Identifier Status = active on the as-of date / Active Accounts.",
             _u("15", "Account Identifier", "Identified Account", "Primary Identifier Indicator", "Account Identifier Status",
                "Identifier Effective From", "Identifier Effective To") + ["Active Accounts"]),
            ("Omnibus Link Completeness %", "Open Account Hierarchy Link rows with Account Link Type = Omnibus to Sub-Account whose Parent Account and Child Account both resolve to accounts with Account Status = Open on the as-of date / all open Omnibus to Sub-Account links.",
             _u("15", "Account", "Account Status") + _u("15", "Account Hierarchy Link", "Parent Account", "Child Account",
                                                        "Account Link Type", "Link Effective From", "Link Effective To")),
            ("Owner Role Completeness %", "Active accounts with at least one Account Party Role open on the as-of date with Account Role Type = Primary Owner and a Role Party / Active Accounts.",
             _u("15", "Account Party Role", "Role Account", "Account Role Type", "Role Party", "Account Role Effective From",
                "Account Role Effective To") + ["Active Accounts"]),
            ("TIN Certification Gap", "Count of active accounts with no Account Tax Certification with TIN Certification Status = Certified and Certification Expiry Date on or after the as-of date, plus active accounts with Backup Withholding Indicator = Y, by Backup Withholding Reason.",
             _u("15", "Account Tax Certification", "Certified Account", "TIN Certification Status", "Certification Expiry Date")
             + _u("15", "Account Tax Reporting Status", "Backup Withholding Indicator", "Backup Withholding Reason") + ["Active Accounts"]),
            ("Unverified Bank Instructions", "Count of Bank Instruction rows with Bank Instruction Status = active and Bank Verification Status not Verified on the as-of date; shown separately for Third-Party Bank Indicator = Y.",
             _u("15", "Bank Instruction", "Bank Instruction Status", "Bank Verification Status", "Third-Party Bank Indicator")),
            ("Beneficiary Allocation Check", "Sum of Beneficiary Allocation Percentage per Designated Account x Beneficiary Designation Type x Beneficiary Type over designations effective on the as-of date; flagged when not equal to 100%.",
             _u("15", "Beneficiary Designation", "Designated Account", "Beneficiary Designation Type", "Beneficiary Type",
                "Beneficiary Allocation Percentage", "Designation Effective From", "Designation Effective To")),
            ("Open Restrictions", "Count of Account Restriction rows with Account Restriction Effective From on or before the as-of date and no Account Restriction Lifted Date, by Account Restriction Type, Imposed By and Restriction Scope, excluding Account Restriction Type = Financial Exploitation (FINRA Rule 2165 holds, published only through DP-322 and DP-403); Review Overdue Flag = Y when Restriction Review Due Date is before the as-of date.",
             _u("15", "Account Restriction", "Account Restriction Effective From", "Account Restriction Lifted Date",
                "Account Restriction Type", "Imposed By", "Restriction Scope", "Restriction Review Due Date")),
            ("Good Order Cycle Time (Days)", "Business days (DP-013 calendar) from Application Received Date to Good Order Date for accounts with an Account Open Date in the period, by Application Channel and Carrying Entity; accounts with no Good Order Date are counted as not in good order with their Opening NIGO Reasons.",
             _u("15", "Account Opening", "Application Received Date", "Good Order Date", "Application Channel", "Opening NIGO Reasons")
             + _u("15", "Account", "Carrying Entity", "Account Open Date")),
            ("Custodial Terminations Due (90 Days)", "Count of accounts with Custodianship Termination Date within the next 90 days and no Termination Notice Sent Date.",
             _u("15", "Custodial Account Detail", "Custodianship Termination Date", "Termination Notice Sent Date")),
            ("Accounts Closed in Period", "Count of accounts with Account Close Date in the period, by Closure Reason and Transfer-Out Receiving Firm; Reopen Eligible Indicator shown alongside.",
             _u("15", "Account", "Account Close Date") + _u("15", "Account Closure", "Closure Reason", "Transfer-Out Receiving Firm",
                                                            "Reopen Eligible Indicator")),
            ("Active Program Enrollments", "Count of Program Enrollment rows with Enrollment Status = Active, Enrollment Effective Date on or before the as-of date and Enrollment Termination Date empty or after it, by Enrolled Service Offering and Discretionary Authority Indicator.",
             _u("15", "Program Enrollment", "Program Enrollment ID", "Enrollment Status", "Enrollment Effective Date",
                "Enrollment Termination Date", "Enrolled Service Offering", "Discretionary Authority Indicator")),
            ("Enrollments Without Active Advisory Agreement", "Count of the Active Program Enrollments whose Advisory Agreement is empty or does not resolve to an Account Agreement of the Enrolled Account (Agreement Account) with Account Agreement Type = Investment Advisory Agreement and Agreement Status = Active.",
             _u("15", "Program Enrollment", "Advisory Agreement", "Enrolled Account")
             + _u("15", "Account Agreement", "Account Agreement ID", "Agreement Account", "Account Agreement Type", "Agreement Status")
             + ["Active Program Enrollments"]),
            ("Active Features Without Required Agreement", "Count of Account Feature rows with Feature Status = Active open on the as-of date (Feature Effective From <= as-of date < Feature Effective To or open) whose Feature Account has no Account Agreement with Agreement Status = Active of the required Account Agreement Type: Margin Agreement for Feature Type Margin and Short Selling, Options Agreement for Options Trading (and Margin Agreement as well where Options Approval Level is Level 3 or Level 4), Fully Paid Lending Agreement for Fully Paid Securities Lending; by Feature Type.",
             _u("15", "Account Feature", "Feature Account", "Feature Type", "Feature Status", "Feature Effective From",
                "Feature Effective To") + _u("15", "Options Approval Detail", "Options Approval Level")
             + _u("15", "Account Agreement", "Agreement Account", "Account Agreement Type", "Agreement Status")),
            ("Cost Basis Default Method Applied %", "Active Accounts whose Cost Basis Election with Cost Basis Election Scope = Account Default - Securities open on the as-of date (Election Effective From <= as-of date < Election Effective To or open) has Default Method Applied Indicator = Y / Active Accounts, by Cost Basis Method. Lots and basis are 49's (DP-300).",
             _u("15", "Cost Basis Election", "Election Account", "Cost Basis Election Scope", "Default Method Applied Indicator",
                "Cost Basis Method", "Election Effective From", "Election Effective To") + ["Active Accounts"]),
            ("RMDs Outstanding", "Count of RMD Record rows for the current RMD Distribution Year with RMD Status in Due, Partially Satisfied or Missed, and the sum of their RMD Required Amount (USD), by RMD Status and RMD Aggregation Indicator. The satisfied amount is 50's (DP-302) and the plan RMD is 16's.",
             _u("15", "RMD Record", "RMD Account", "RMD Distribution Year", "RMD Status", "RMD Required Amount", "RMD Aggregation Indicator")),
            ("Alternative Investment Subscriptions in Review", "Count, and sum of Subscription Amount (USD), of Alternative Investment Subscription rows with Subscription Status in Submitted or Pending Qualification Review on the as-of date, by Feeder Product and Offering Window; rows with Investor Qualification Relied On empty shown separately.",
             _u("15", "Alternative Investment Subscription", "Subscription ID", "Subscription Status", "Subscription Amount",
                "Feeder Product", "Offering Window", "Investor Qualification Relied On")),
            ("Accounts Without Current Investment Profile", "Count of Active Accounts with no Account Investment Profile row open on the as-of date (Account Profile Effective From <= as-of date < Account Profile Effective To or open), or whose open row has no Investor Profile Version Applied (SEC Rule 17a-3(a)(17)); open rows with Differs From Client Profile Indicator = Y shown separately.",
             _u("15", "Account Investment Profile", "Profile Account", "Account Profile Effective From", "Account Profile Effective To",
                "Investor Profile Version Applied", "Differs From Client Profile Indicator") + ["Active Accounts"]),
            ("Sweep Election Coverage %", "Accounts with Account Status = Open and Account Type in Brokerage Account or Managed Advisory Account that have exactly one Cash Sweep Election open on the as-of date (Sweep Election Effective From <= as-of date < Sweep Election Effective To or open) / those accounts, by Sweep Vehicle Type.",
             _u("15", "Account", "Account Type", "Account Status") + _u("15", "Cash Sweep Election", "Sweep Election Account",
                                                                        "Sweep Vehicle Type", "Sweep Election Effective From",
                                                                        "Sweep Election Effective To")),
        ],
        inputs=[
            ("15", "Account", ["Account ID", "Account Type", "Account Name", "External Account Number", "Account Registration Type",
                               "Account Status", "Account Open Date", "Account Close Date", "Reg T Account Type", "Carrying Entity",
                               "Account Purpose", "Account Business Line"]),
            ("15", "Account Identifier", ["Account Identifier ID", "Identified Account", "Account Identifier Scheme",
                                          "Account Identifier Value", "Issuing Party", "Primary Identifier Indicator",
                                          "Account Identifier Status", "Identifier Effective From", "Identifier Effective To"]),
            ("15", "Account Hierarchy Link", ["Parent Account", "Child Account", "Account Link Type", "Link Source",
                                              "Link Effective From", "Link Effective To"]),
            ("15", "Account Party Role", ["Account Role Type", "Role Party", "Role Account", "Role Allocation Percentage",
                                          "Account Role Effective From", "Account Role Effective To"]),
            ("15", "Account Registration Detail", ["Registration Line 1", "Registration Line 2", "Entity Account Indicator",
                                                   "Governing Trust", "Registration Change Date"]),
            ("15", "Account Investment Profile", ["Profile Account", "Account Investment Objective", "Account Risk Tolerance",
                                                  "Account Time Horizon", "Investor Profile Version Applied",
                                                  "Differs From Client Profile Indicator", "Account Profile Effective From",
                                                  "Account Profile Effective To"]),
            ("15", "Custodial Account Detail", ["Custodial Statute", "Custodial State", "Age of Majority",
                                                "Custodianship Termination Date", "Successor Custodian", "Termination Notice Sent Date"]),
            ("15", "Retirement Account Detail", ["Inherited IRA Decedent", "Beneficiary Class", "Required Beginning Date",
                                                 "Ten-Year Period End Date", "IRA Custodian Entity", "Rollover Source Plan"]),
            ("15", "Education & Health Savings Account Detail", ["529 Plan Portfolio", "529 Plan State", "HSA Coverage Type"]),
            ("15", "Beneficiary Designation", ["Beneficiary Designation ID", "Designated Account", "Beneficiary",
                                               "Beneficiary Designation Type", "Beneficiary Type", "Beneficiary Allocation Percentage",
                                               "Beneficiary Relationship", "Per Stirpes Indicator", "Spousal Consent Obtained Indicator",
                                               "Designation Effective From", "Designation Effective To"]),
            ("15", "Account Feature", ["Account Feature ID", "Feature Account", "Feature Type", "Feature Status",
                                       "Feature Approval Date", "Feature Approved By", "Feature Profile Version Used",
                                       "Feature Agreements", "Feature Effective From", "Feature Effective To"]),
            ("15", "Options Approval Detail", ["Options Approval Level", "Approved Options Strategies", "Options Disclosure Delivery"]),
            ("15", "Margin Account Detail", ["Portfolio Margin Indicator", "Margin Disclosure Delivery"]),
            ("15", "Cash Sweep Election", ["Sweep Election Account", "Sweep Vehicle Type", "Elected Sweep Program",
                                           "Elected Sweep Fund", "Sweep Election Effective From", "Sweep Election Effective To"]),
            ("15", "Account Agreement", ["Account Agreement ID", "Agreement Account", "Account Agreement Type", "Agreement Version",
                                         "Agreement Signed Date", "Signature Method", "Predispute Arbitration Clause Indicator",
                                         "Agreement Status"]),
            ("15", "Program Enrollment", ["Program Enrollment ID", "Enrolled Account", "Enrolled Service Offering",
                                          "Enrollment Status", "Enrollment Effective Date", "Enrollment Termination Date",
                                          "Enrollment Termination Reason", "Source Recommendation",
                                          "Discretionary Authority Indicator", "Advisory Agreement", "Reasonable Restrictions"]),
            ("15", "Alternative Investment Subscription", ["Subscription ID", "Subscribing Account", "Feeder Product",
                                                           "Offering Window", "Subscription Amount",
                                                           "Investor Qualification Relied On", "Subscription Documents Status",
                                                           "Subscription Status", "Subscription Accepted Date"]),
            ("15", "Account Tax Certification", ["Tax Certification ID", "Certified Account", "Certifying Party", "Tax Form Type",
                                                 "TIN Certification Status", "Certification Signed Date",
                                                 "Certification Expiry Date", "Certification Status"]),
            ("15", "Account Tax Reporting Status", ["Account Tax Classification", "Backup Withholding Indicator",
                                                    "Backup Withholding Reason", "Backup Withholding Effective From",
                                                    "Backup Withholding Effective To", "B-Notice Count", "Tax Reporting Regimes"]),
            ("15", "Cost Basis Election", ["Cost Basis Method", "Default Method Applied Indicator", "Election Account",
                                           "Cost Basis Election Scope", "Election Share Class", "Election Effective From",
                                           "Election Effective To"]),
            ("15", "RMD Record", ["RMD Account", "RMD Distribution Year", "RMD Required Amount", "RMD Aggregation Indicator",
                                  "RMD Status"]),
            ("15", "Account Standing Instruction", ["Standing Instruction ID", "Instruction Type", "Instruction Account",
                                                    "Instruction Status", "Instruction Effective From", "Instruction Frequency",
                                                    "Instruction Amount", "Linked Bank Instruction", "Next Run Date",
                                                    "Instruction Effective To"]),
            ("15", "Bank Instruction", ["Bank Instruction ID", "Bank Instruction Account", "Bank Instruction Purposes",
                                        "Bank Routing Identifier", "Bank Account Number (Masked)", "Bank Account Type",
                                        "Third-Party Bank Indicator", "Bank Verification Status", "Bank Verification Method",
                                        "Bank Instruction Status", "Bank Instruction Effective From", "Bank Instruction Effective To"]),
            ("15", "Account Preference", ["Statement Frequency", "Confirmation on Statement Indicator",
                                          "Redemption Proceeds Default Method", "Default Bank Instruction", "Preference Effective From"]),
            ("15", "Account Opening", ["Application Channel", "Application Received Date", "Good Order Date", "Opening NIGO Reasons",
                                       "Opening KYC Case", "Opening Identity Verification", "Originating Recommendation",
                                       "Account Approval Date"]),
            ("15", "Account Lifecycle Event", ["Lifecycle Event ID", "Event Account", "Lifecycle Event Type", "Event Timestamp",
                                               "Event Effective Date", "Event Source", "Triggering Service Request"]),
            ("15", "Account Status History", ["Status Account", "Historical Account Status", "Status Reason",
                                              "Status Effective From", "Status Effective To", "Status Set By Event"]),
            ("15", "Account Closure", ["Closure Reason", "Closure Initiated By", "Transfer-Out Receiving Firm",
                                       "Reopen Eligible Indicator", "Records Retention End Date"]),
            ("15", "Account Restriction", ["Account Restriction ID", "Restricted Account", "Account Restriction Type", "Imposed By",
                                           "Account Restriction Effective From", "Account Restriction Lifted Date",
                                           "Restriction Review Due Date", "Restriction Scope"]),
            ("15", "Plan Participant Account", ["Participant", "Retirement Plan", "Plan Account", "Participant Plan Membership",
                                                "Money Sources Held"]),
            ("15", "Institutional Account", ["Related Mandate", "Related Retirement Plan", "Custodian", "Governing Agreement"]),
            ("15", "Intermediary Account Servicing", ["Networking Level", "Dealer of Record", "Branch of Record", "Rep of Record"]),
        ],
        upstream=["DP-240", "DP-001", "DP-004", "DP-013"],
        refresh="Daily",
        timeliness=("By 6am ET on T+1 for account changes of the prior business day; account openings, status changes and "
                    "restrictions on the event stream within 15 minutes of the source commit; participant and institutional "
                    "account changes within one business day of the recordkeeping or servicing confirmation"),
        history=("SCD type 2 on the account and every child table since account opening; lifecycle events, status periods and "
                 "closed accounts kept to the Records Retention End Date, at least six years after closure (SEC Rule 17a-4(c)) "
                 "and five years for advisory account records (Advisers Act Rule 204-2)"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Role Party, Beneficiary, Successor Custodian, Inherited IRA Decedent, Certifying Party and Investor Qualification Relied On resolves to a DP-240 party that is Active or Merged (re-pointed to its survivor), every Dealer of Record and Rep of Record resolves to DP-001, every Enrolled Service Offering, Election Share Class, Elected Sweep Fund, Feeder Product and Offering Window resolves to DP-004, and every Parent Account, Child Account, Plan Account, Linked Bank Instruction, Default Bank Instruction and Advisory Agreement resolves inside this product, with no account its own parent.",
            "For one key the effective periods of Account Identifier (per Account Identifier Scheme with Primary Identifier Indicator = Y), Account Party Role, Account Hierarchy Link, Beneficiary Designation, Account Feature (per Feature Type), Cash Sweep Election, Cost Basis Election (per Cost Basis Election Scope), Account Investment Profile, Program Enrollment (at most one Enrollment Status = Active per account) and Account Standing Instruction do not overlap, and every end date is on or after its start date.",
            "Account Status History periods are contiguous from Account Open Date and the open period's Historical Account Status equals Account Status; Account Close Date is present exactly when Account Status = Closed and is on or after Account Open Date; every open account with Account Type = Managed Advisory Account has exactly one Program Enrollment with Enrollment Status = Active.",
            "Every account has Account ID, Account Type, Account Registration Type, Account Status, Account Open Date, Carrying Entity and Account Business Line; every open Brokerage Account has a Reg T Account Type; every Account Registration Type Traditional IRA, Rollover IRA, SEP IRA or SIMPLE IRA past its Required Beginning Date has an RMD Record for the current RMD Distribution Year; every active Account Tax Certification with TIN Certification Status = Certified has a Certification Signed Date on or before its Certification Expiry Date.",
            "Bank Routing Identifier is read only to test the ABA check digit and is never published, Bank Account Number (Masked) shows only the last four digits and only in the money movement servicing view, Account Name, External Account Number and Registration Lines appear only in the servicing view, and no Account Restriction row with Account Restriction Type = Financial Exploitation, Account Restriction Reason or Source Vulnerability Concern is read (CD-344, CW-213).",
            "The daily snapshot is complete by 6am ET on T+1 with account row counts by Account Type equal to the 15 source control totals, and Account Opening, Account Restriction and Account Status History changes reach the event stream within 15 minutes.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Account' (15, ACC-), 'Account Identifier' (15, ACI-), 'Account Hierarchy "
               "Link', 'Account Party Role', 'Beneficiary Designation' (15, ABD-), 'Plan Participant Account', 'Account Tax "
               "Certification / Account Tax Reporting Status' (15, ATC-), 'Cost Basis Election', 'Standing Instruction' (15, "
               "SIN-), 'Bank Instruction' (15, ABI-), 'Account Lifecycle Event / Account Status History' (15, ALE-), 'Account "
               "Restriction' (15, ARX-) and 'Networking Level (account)'. It is the source of the Client account dimension of the "
               "WP2 conformed set (and of SM-00's account dimension once proposed). Every account kind is a 15 account (CW-035); a "
               "retail managed account is a 15 account managed in 46, never an 18 portfolio. "
               "Certified numbers: none. Funded Accounts is a DP-008 measure built from these keys (CW-011, CW-203); Active Accounts "
               "is a stewardship count only. "
               "Operating model (CD-297, CD-331): fund-only accounts are serviced by the in-house transfer agent (29) and are 15 "
               "accounts here at operational grain; with an outsourced transfer agent the same grain is received from the "
               "provider's account master. "
               "PII tier: financial. Publication: the analytics view carries account keys, types, statuses, features, enrollments, "
               "elections and restriction types without names, registration lines, external numbers or bank detail; the servicing "
               "view adds them; bank detail as DQ5 states. FINRA Rule 2165 hold rows and their reasons and vulnerability links are "
               "special category and reach products only through DP-322 and DP-403. "
               "Boundaries: client-level facts (name, date of birth, TIN, citizenship) are read from DP-240, never here; 02 Party, "
               "02 Tax Profile, 01 Share Class and 01 Service Offering are no longer read to validate references (the keys resolve "
               "through DP-240 and DP-004, DQ1). Client holdings, client tax lots, cost basis and cash balances are 49 (DP-300); "
               "money movements, RMD satisfied amounts and funding are 50 (DP-302); the recommendation behind an enrollment or an "
               "opening is 45 (DP-303), the model assignment 46 (DP-304) and the fee schedule 47 (DP-305): those products read this "
               "one, so the references (Source Recommendation, Originating Recommendation, Elected Sweep Program, Rollover Source "
               "Plan) resolve downstream and DP-303, DP-304, DP-305 and DP-431 are not upstream (one direction per edge). "
               "Participant membership, status and balances are 16 (DP-094, DP-430); the Plan Participant Account status "
               "attributes other than Money Sources Held (mastered in 15 and read here for DP-094 and DP-095) are 16 derived copies "
               "and are not read. Institutional relationships and mandates are DP-003; "
               "Related Mandate, Related Retirement Plan, Custodian and Governing Agreement are carried as keys. Opening "
               "pipelines, feature disclosures, RMD trackers and tax certification status views are CLA-A consumers (DP-327 to "
               "DP-332). 15 objects with CDEs not read here and their readers: Account Disclosure Delivery (DP-399, DP-334; read "
               "beside DP-382, CW-223), Retirement Distribution Election (DP-329), New Issue Eligibility (DP-077). "
               "Acceptance question 8: feeds DP-346 with Program Enrollment (Enrolled Service Offering, Enrollment Status, "
               "Advisory Agreement) and Account Agreement keys. Acceptance question 10: feeds DP-467 with Account Opening "
               "Application Channel = Rollover from Workplace Plan and Retirement Account Detail Rollover Source Plan. "
               "Tailoring lever: program enrollment grain (15 SME 1). Reference default: per account, one active enrollment; "
               "the alternative adds a household reference to Program Enrollment. "
               "Tailoring lever: features offered (15 SME 2; plan section 15 item 3). Reference default: every Feature Type value, "
               "margin, options and fully paid lending included; a firm without margin or fully paid lending drops those rows "
               "from Active Features Without Required Agreement. "
               "Tailoring lever: trust line (TR). Reference default: trust registrations reference 51 Governing Trust; without "
               "51 the trustees are Primary Owner roles (15 SME 11). "
               "Tailoring lever: feeder subscriptions (15 SME 8). Reference default: held in the brokerage account. "
               "Tailoring lever: legacy fund-only accounts (15 SME 9). Reference default: stay open, no new ones. "
               "Tailoring lever: RMD scope (15 SME 6). Reference default: computed for every IRA past its Required Beginning "
               "Date, aggregation flagged. "
               "Taxonomy gap: 15 Account carries no base currency or domicile of its own; currency is read from the holdings in 49. "
               "Taxonomy gap: 15 Program Enrollment Advisory Agreement is typed as a reference but no key rule names 15 Account "
               "Agreement as its target; the measure assumes it is the Account Agreement ID. "
               "Taxonomy gap: 15 Account Feature has no attribute naming the required agreement type; the Feature Type to Account "
               "Agreement Type map in Active Features Without Required Agreement follows the 15 relationship table. "
               "Drafting assumptions: Account Status = Open as the active state; the 90-day custodial window; the Feature Type to "
               "Agreement Type map; RMD Status values Due, Partially Satisfied and Missed as outstanding; Subscription Status "
               "values Submitted and Pending Qualification Review as in review; the 15-minute event latency. "
               "Decisions: CW-006, CW-007, CW-011, CW-021, CW-024, CW-026, CW-032, CW-035, CW-202, CW-203, CW-204, CW-213, CW-930; "
               "CD-297, CD-344. "
               "W1 re-point (CW-021): Platform Program Enrollment is read from Program Enrollment (Enrolled Service Offering, "
               "Enrollment Effective Date, Enrollment Termination Date); Account Privilege and Standing Instruction Distribution "
               "Option from Account Feature; Account Investment Objective from the versioned Account Investment Profile; Omnibus "
               "Parent Account from Account Hierarchy Link (Account Link Type = Omnibus to Sub-Account); Opening Servicing Provider "
               "from Account Carrying Entity. Institutional Account Governing Agreement references 39 Contract (DP-213 downstream). "
               "W1: Platform Program Enrollment Program Account Type and Assigned Model Portfolio, Intermediary Account Servicing "
               "Nominee Designation and the CRS self-certification attributes dropped, no successor in the wealth 15 (CW-021, "
               "CW-915), with the measure Self-Certification Gap. "
               "WP1 re-scope (CW-204): the brokerage and advisory Account Master; name kept; owner Head of Account Data "
               "(Transfer Agency) -> Head of Account Data; primary function FN-15 -> FN-62; upstream DP-002 (retired, CW-202) "
               "replaced by DP-240, with DP-001 kept for dealer and rep of record. Inputs added: 15 Retirement Account Detail, "
               "Education & Health Savings Account Detail, Options Approval Detail, Margin Account Detail, Cash Sweep Election, "
               "Account Agreement, Alternative Investment Subscription (taken from the retired DP-116 and DP-136, CW-930) and RMD "
               "Record; Account Reg T Account Type, Account Purpose and Account Business Line; Program Enrollment Source "
               "Recommendation, Advisory Agreement and Reasonable Restrictions. Inputs dropped: 02 Party, 02 Tax Profile, 01 Share "
               "Class and 01 Service Offering (read through DP-240 and DP-004); Registration Jurisdiction and Trust or Agreement "
               "Date (now 51 derived copies); the Plan Participant Account attributes Participant Account Status, Participant Account "
               "Status Effective From, Participant Enrollment Date, Default Investment Indicator and Terminated Participant "
               "Indicator (16 derived copies; read by DP-094 and DP-095, which lineage moves to their 16 masters), while Money "
               "Sources Held, mastered in 15, is kept; Opening Intermediary (a Reference (Party) to 02) and Initial Funding "
               "Transaction, Triggering Transaction and Final Transaction (References (Money Movement) to 50); Account Standing "
               "Instruction Instruction Share Class and Account Tax Reporting Status Tax Status Last Reviewed Date (no live reader); "
               "Rep Code at Transfer Agent; the treaty, exempt payee, FATCA exemption and backup withholding rate attributes; "
               "Lifecycle Event Event Reason, Account Restriction Account Restriction Reason (special category on Rule 2165 rows); "
               "Account Preference Statement Language and Duplicate Statement Recipient; Bank Name and Bank Account Holder Name. "
               "All eleven wholesale measure names kept (no semantic reader keys on them); eight measures added. Dimension names "
               "kept, two with a source suffix ('Dealer, branch and rep of record (DP-001)', 'Enrolled service offering (DP-004)'; "
               "no reader keys on them); added Account business line, Reg T account type, Sweep vehicle type and Client and household. Objects behind "
               "conformed entities kept: Account (models_e8_masters, models_f4_accounts_plans) and Beneficiary Designation "
               "(models_f4_accounts_plans). Model re-cut for lineage (models_f4_accounts_plans, DP-093 model): the Party entity "
               "(conformed from DP-001, backed by 02 Party and 02 Tax Profile) re-points to DP-240; the Share Class entity (01 "
               "Share Class) and the Service Offering entity (01 Service Offering) become conformed from DP-004 with no DP-093 "
               "object; the Rep of Record entity (conformed from the retired DP-002) re-points to DP-001 (the intermediary "
               "advisor) or DP-009 (the firm's own advisor). The newly read 15 objects need placing in the re-cut model. "
               "Content item for the W5 leftovers: 15 Account Identifier Account Identifier Value is flagged as a derived copy "
               "owned by 28, which looks like a content-flag error (15 masters the account identifier); it is read here as the "
               "master."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-004": dict(
        definition=("Everything the firm offers, conformed once: every strategy, own fund, ETF, CIT, feeder and share class with "
                    "identifiers, legal structure, classifications, fund fee terms, eligibility, lifecycle and product "
                    "relationships; every model portfolio; the advice and service offerings with their features, eligibility "
                    "rules, links to the 47 fee schedules and the firm-wide service tiers; the brokerage platform's tradable "
                    "universe rules, platform features and the availability of own share classes and third-party funds; the "
                    "firm risk rating of each share class; and the feeder access terms and offering windows. It conforms the "
                    "CONCEPT_OWNERSHIP rows 'Investment Product' (01, PRD-), 'Share Class' (01, SHC-), 'Model Portfolio' (01, "
                    "MDL-) and 'Service Offering' (01, OFFR-) so that advice, managed accounts, billing, the platform and the "
                    "fund products name the same offering. It is the source of the offering, program, product and share class "
                    "dimension and owns no certified metric family."),
        business_questions=[
            "Which advice and service offerings are active, with which delivery mode, discretion, advisory capacity, features, minimums and fee schedule, and which active advisory offerings have no standard fee schedule linked?",
            "Which own share classes and third-party funds are available on the brokerage platform, at what transaction fee category, and which third-party products are available without a due diligence approval on record?",
            "Which share classes are open, soft-closed, merging or liquidating and from what date, and which products are feeders, clones or successors of another product?",
            "Which ISIN, CUSIP, Fund/SERV code, SEC series and class identifiers and firm risk rating does each share class carry, and which active classes are missing one?",
            "Which feeder, tender-offer and interval fund offering windows are open, and what investor qualification does each require?",
            "Which tradable universe rules and platform features are in force, and which features require a disclosure or client activation?",
        ],
        grain=("Share class x effective period (SCD type 2), with the investment product and strategy as parents; companion "
               "tables at service offering x effective period (features, eligibility rules, fee schedule links), service tier, "
               "model portfolio, tradable universe rule, platform feature x feature effective date, platform product availability "
               "(own share class or third-party instrument x availability effective date), offering window, lifecycle event, "
               "product relationship, source system code and portfolio manager assignment"),
        dimensions=["Investment strategy", "Investment product", "Share class", "Vehicle type", "Legal form / regulatory regime",
                    "Fund domicile", "Business line", "Asset class", "External category", "Eligible investor type",
                    "Share class status", "Currency", "Portfolio manager", "Product relationship type", "Model portfolio",
                    "Service offering (offering and program)", "Offering type, delivery mode and discretion type",
                    "Advisory capacity", "Service tier", "Firm risk rating", "Platform availability status and transaction fee category",
                    "Tradable universe rule type", "Platform feature type", "Offering window", "Distribution channel"],
        measures=[
            ("Active Share Class Count", "Count of share classes with Share Class Status = Active on the as-of date, by Parent Product Vehicle Type and Business Line.",
             _u("01", "Share Class", "Share Class ID", "Share Class Status", "Parent Product") + _u("01", "Investment Product", "Vehicle Type")
             + _u("01", "Firm Product Classification", "Business Line")),
            ("Identifier Completeness %", "Active share classes with ISIN populated and, for classes of products with Regulatory Regime = US 1940 Act Registered or US Bank CIT, CUSIP and DTCC Fund/SERV Code populated / Active Share Class Count.",
             _u("01", "External Cross-Reference", "DTCC Fund/SERV Code") + _u("01", "Security Identifier", "CUSIP", "ISIN")
             + _u("01", "Fund Legal Structure", "Regulatory Regime")
             + ["Active Share Class Count"]),
            ("SEC Identifier Completeness %", "Active share classes of products with Regulatory Regime = US 1940 Act Registered with SEC Investment Company File Number, SEC Series ID and SEC Class / Contract ID populated / those share classes.",
             _u("01", "Regulatory Filing Identifier", "SEC Investment Company File Number", "SEC Series ID", "SEC Class / Contract ID")
             + _u("01", "Fund Legal Structure", "Regulatory Regime") + ["Active Share Class Count"]),
            ("Net Expense Ratio Gap", "Gross Expense Ratio - Net Expense Ratio at the latest Cost Reference Date, per share class (the prospectus fee-table waiver in effect, Form N-1A Item 3); a reference attribute, not the certified expense ratio family, which stays DP-165's.",
             _u("01", "Cost Disclosure", "Gross Expense Ratio", "Net Expense Ratio", "Cost Reference Date")),
            ("Days to Lifecycle Event", "Event Effective Date - as-of date for the next pending Lifecycle Event per share class or service offering.",
             _u("01", "Lifecycle Event", "Event Effective Date", "Lifecycle Event Type")),
            ("Portfolio Manager Change Flag", "Y when a Portfolio Manager Assignment for the product has PM Start Date or PM End Date in the last 12 months.",
             _u("01", "Portfolio Manager Assignment", "Portfolio Manager", "PM Start Date", "PM End Date")),
            ("Portfolio Manager Count", "Count of open Portfolio Manager Assignment rows (PM End Date null or after the as-of date) per product.",
             _u("01", "Portfolio Manager Assignment", "Portfolio Manager", "PM End Date")),
            ("Related Product Count", "Count of open Product Relationship rows (Relationship Effective To null or after the as-of date) per Source Product, by Relationship Type.",
             _u("01", "Product Relationship", "Source Product", "Relationship Type", "Relationship Effective To")),
            ("Share Classes Without Firm Risk Rating %", "Active share classes whose Product Risk Indicator Firm Risk Rating is empty or Not Rated / Active Share Class Count; the 1 to 5 scale that 45 matches to the investor profile.",
             _u("01", "Product Risk Indicator", "Firm Risk Rating") + ["Active Share Class Count"]),
            ("Active Service Offerings", "Count of Service Offering rows with Offering Status = Active on the as-of date, by Offering Type, Delivery Mode, Discretion Type and Advisory Capacity, with Wrap Fee Program Indicator and Rule 3a-4 Program Indicator as flags.",
             _u("01", "Service Offering", "Offering ID", "Offering Status", "Offering Type", "Delivery Mode", "Discretion Type",
                "Advisory Capacity", "Wrap Fee Program Indicator", "Rule 3a-4 Program Indicator")),
            ("Offerings Without Standard Fee Schedule Link", "Count of Active Service Offerings with Advisory Capacity in Investment Adviser, Dual Capacity or Trust Company Fiduciary that are the Linked Offering of no Offering Fee Schedule Link with Fee Schedule Link Type = Standard, a Linked Fee Schedule and Link Effective From <= as-of date < Link Effective To (or open).",
             _u("01", "Offering Fee Schedule Link", "Linked Offering", "Linked Fee Schedule", "Fee Schedule Link Type",
                "Link Effective From", "Link Effective To") + _u("01", "Service Offering", "Advisory Capacity")
             + ["Active Service Offerings"]),
            ("Offerings Without Minimum Assets Rule", "Count of Active Service Offerings with Offering Type other than Brokerage and Planning Only that are the Eligibility Offering of no Offering Eligibility Rule with Eligibility Criterion = Minimum Assets open on the as-of date (Eligibility Effective From <= as-of date < Eligibility Effective To or open); for the others the current minimum is that rule's Criterion Threshold.",
             _u("01", "Offering Eligibility Rule", "Eligibility Offering", "Eligibility Criterion", "Criterion Threshold",
                "Eligibility Effective From", "Eligibility Effective To") + _u("01", "Service Offering", "Offering Type")
             + ["Active Service Offerings"]),
            ("Models Not Used by an Active Offering", "Count of Model Portfolio ID values that appear in the Model Portfolios Used of no Service Offering with Offering Status = Active on the as-of date.",
             _u("01", "Model Portfolio", "Model Portfolio ID") + _u("01", "Service Offering", "Model Portfolios Used", "Offering Status")),
            ("Platform Availability by Status", "Count of own share classes (Available Share Class) and third-party instruments (Available Third-Party Instrument) by Platform Availability Status and Transaction Fee Category, taking for each the Platform Product Availability row with the latest Availability Effective From on or before the as-of date.",
             _u("01", "Platform Product Availability", "Platform Availability ID", "Available Share Class",
                "Available Third-Party Instrument", "Platform Availability Status", "Transaction Fee Category",
                "Availability Effective From")),
            ("Third-Party Products Available Without Due Diligence Approval", "Count of third-party instruments whose current availability row (as in Platform Availability by Status) has Platform Availability Status = Available or Closed to New Investors and no Due Diligence Approval; whether the referenced 52 approval is still current is DP-383's check.",
             _u("01", "Platform Product Availability", "Available Third-Party Instrument", "Platform Availability Status",
                "Due Diligence Approval") + ["Platform Availability by Status"]),
            ("Active Tradable Universe Rules", "Count of Tradable Universe Policy Rule rows with Rule Status = Active and Rule Effective From <= as-of date < Rule Effective To (or open), by Universe Rule Type.",
             _u("01", "Tradable Universe Policy Rule", "Policy Rule ID", "Rule Status", "Rule Effective From", "Rule Effective To",
                "Universe Rule Type")),
            ("Platform Features Requiring Disclosure", "Count of Platform Feature Type values whose latest Platform Feature row with Feature Effective From on or before the as-of date has Required Disclosure Type populated, by Required Disclosure Type and Client Activation Required Indicator, with the number of Eligible Offerings.",
             _u("01", "Platform Feature", "Platform Feature Type", "Feature Effective From", "Required Disclosure Type",
                "Client Activation Required Indicator", "Eligible Offerings")),
            ("Open Offering Windows", "Count of Offering Window rows with Window Status = Open and Window Open Date <= as-of date <= Window Close Date, by Window Feeder Product, with Window Capacity and the days to Window Close Date.",
             _u("01", "Offering Window", "Offering Window ID", "Window Feeder Product", "Window Status", "Window Open Date",
                "Window Close Date", "Window Capacity")),
            ("Feeder Products Without Access Terms", "Count of Investment Products with Vehicle Type in Feeder Fund, Tender-Offer Fund or Interval Fund whose Feeder Access Terms have no Required Investor Qualification, or whose Feeder Access Structure = Feeder Fund with no Underlying Fund Instrument.",
             _u("01", "Investment Product", "Product ID", "Vehicle Type")
             + _u("01", "Feeder Access Terms", "Required Investor Qualification", "Feeder Access Structure", "Underlying Fund Instrument")),
        ],
        inputs=[
            ("01", "Investment Strategy", ["Strategy ID", "Strategy Name", "Strategy Inception Date", "Strategy Status"]),
            ("01", "Strategy Classification", ["Asset Class", "Sub-Asset Class", "Investment Approach", "Geographic Focus"]),
            ("01", "Investment Product", ["Product ID", "Product Legal Name", "Product Marketing Name", "Vehicle Type",
                                          "Implemented Strategy", "Base Currency", "Product Inception Date", "Product Range"]),
            ("01", "Fund Legal Structure", ["Legal Form", "Regulatory Regime", "Fund Domicile", "Fund LEI", "Umbrella Fund",
                                            "Fund Openness", "Master-Feeder Role", "Master Fund"]),
            ("01", "Model Portfolio", ["Model Portfolio ID", "Model Portfolio Name", "Implemented Strategy",
                                       "Model Sponsor / Platform", "Rebalance Frequency", "Model Delivery Method"]),
            ("01", "Product Relationship", ["Source Product", "Target Product", "Relationship Type", "Relationship Effective From",
                                            "Relationship Effective To"]),
            ("01", "Share Class", ["Share Class ID", "Parent Product", "Share Class Legal Name", "Share Class Designation",
                                   "Share Class Type", "Share Class Currency", "Share Class Launch Date", "Share Class Status"]),
            ("01", "Investor Eligibility", ["Eligible Investor Type", "Minimum Initial Investment", "Minimum Subsequent Investment",
                                            "Eligibility Restriction"]),
            ("01", "Security Identifier", ["ISIN", "CUSIP", "FIGI"]),
            ("01", "Regulatory Filing Identifier", ["SEC Investment Company File Number", "SEC Series ID", "SEC Class / Contract ID"]),
            ("01", "External Cross-Reference", ["Morningstar SecId", "Morningstar FundId", "Lipper ID", "Bloomberg Ticker",
                                                "DTCC Fund/SERV Code"]),
            ("01", "System Cross-Reference", ["Source System", "Source System Code", "Cross-Reference Effective From",
                                              "Cross-Reference Effective To"]),
            ("01", "Firm Product Classification", ["Business Line", "Product Asset Class", "Product Investment Approach",
                                                   "AUM Reporting Category"]),
            ("01", "External Classification", ["Morningstar Category", "ICI Investment Category", "Classification Effective Date"]),
            ("01", "Product Risk Indicator", ["Firm Risk Rating", "Derivatives Risk Category"]),
            ("01", "Performance Fee", ["Performance Fee Indicator", "Performance Fee Rate"]),
            ("01", "Cost Disclosure", ["Gross Expense Ratio", "Net Expense Ratio", "Expense Cap Rate", "Waiver Expiry Date",
                                       "Cost Reference Date"]),
            ("01", "Management Fee", ["Management Fee Rate", "Maximum Management Fee Rate", "Fee Accrual Basis",
                                      "Fee Breakpoint Schedule", "Fund-Paid Sub-TA Fee Cap", "Fund-Paid Sub-TA Fee Cap Per Account",
                                      "Approving Board Resolution"]),
            ("01", "Other Ongoing Fees", ["Administration / Operating Fee Rate", "Distribution (12b-1) Fee Rate",
                                          "Shareholder Servicing Fee Rate"]),
            ("01", "Distribution Availability", ["Distribution Channel", "Sales Restriction"]),
            ("01", "Lifecycle Event", ["Lifecycle Status", "Status Effective Date", "Lifecycle Event Type", "Event Effective Date",
                                       "Successor Product / Share Class", "Event Reason"]),
            ("01", "Portfolio Manager Assignment", ["Portfolio Manager", "Portfolio Manager Role", "PM Start Date", "PM End Date"]),
            ("01", "Service Offering", ["Offering ID", "Offering Name", "Offering Type", "Delivery Mode", "Discretion Type",
                                        "Advisory Capacity", "Sponsoring Entity", "Wrap Fee Program Indicator",
                                        "Rule 3a-4 Program Indicator", "Model Portfolios Used", "Offering Status"]),
            ("01", "Offering Feature", ["Offering Feature Type", "Feature Setting"]),
            ("01", "Offering Eligibility Rule", ["Eligibility Rule ID", "Eligibility Offering", "Eligibility Criterion",
                                                 "Criterion Operator", "Criterion Threshold", "Eligibility Effective From",
                                                 "Eligibility Effective To"]),
            ("01", "Offering Fee Schedule Link", ["Linked Offering", "Linked Fee Schedule", "Fee Schedule Link Type",
                                                  "Link Effective From", "Link Effective To"]),
            ("01", "Service Tier", ["Service Tier Code", "Service Tier Name", "Tier Asset Threshold", "Tier Measurement Basis",
                                    "Tier Benefits"]),
            ("01", "Tradable Universe Policy Rule", ["Policy Rule ID", "Rule Name", "Universe Rule Type", "Rule Criteria",
                                                     "Rule Effective From", "Rule Effective To", "Rule Status"]),
            ("01", "Platform Product Availability", ["Platform Availability ID", "Available Share Class",
                                                     "Available Third-Party Instrument", "Platform Availability Status",
                                                     "Transaction Fee Category", "Due Diligence Approval",
                                                     "Availability Effective From"]),
            ("01", "Platform Feature", ["Platform Feature Type", "Eligible Offerings", "Eligible Account Registration Types",
                                        "Required Disclosure Type", "Client Activation Required Indicator",
                                        "Feature Governing Policy Rule", "Feature Effective From"]),
            ("01", "Feeder Access Terms", ["Feeder Access Structure", "Underlying Fund Instrument", "Required Investor Qualification"]),
            ("01", "Offering Window", ["Offering Window ID", "Window Feeder Product", "Window Open Date", "Window Close Date",
                                       "Window Capacity", "Window Status"]),
        ],
        upstream=["DP-013"],
        refresh="Daily",
        timeliness=("By 6am ET each business day; new share classes, service offerings and platform availability rows are "
                    "published at least 5 business days before Share Class Launch Date or Availability Effective From"),
        history=("SCD type 2 on every attribute since product or offering inception; closed and merged share classes and retired "
                 "offerings kept indefinitely with their successor link"),
        classification="Internal",
        pii="N",
        delivery=["Warehouse table", "API", "BI semantic model", "File extract"],
        dq_rules=[
            "Every share class has exactly one Parent Product, every product and Model Portfolio exactly one Implemented Strategy; every Linked Offering, Eligibility Offering and Eligible Offerings value resolves to an Offering ID, every Model Portfolios Used value to a Model Portfolio ID and every Window Feeder Product to a product with Vehicle Type Feeder Fund, Tender-Offer Fund or Interval Fund; exactly one of Available Share Class and Available Third-Party Instrument is populated on each Platform Product Availability row.",
            "Product Relationship, System Cross-Reference, Offering Fee Schedule Link (per Linked Offering and Fee Schedule Link Type), Offering Eligibility Rule (per Eligibility Offering and Eligibility Criterion), Tradable Universe Policy Rule and Portfolio Manager Assignment periods do not overlap for the same key, and Relationship Effective To, Cross-Reference Effective To, Link Effective To, Eligibility Effective To, Rule Effective To, PM End Date and Window Close Date are on or after their start dates.",
            "ISIN is unique across active share classes and passes the ISIN check digit, CUSIP is unique where populated, each Source System + Source System Code maps to one share class on any date, Net Expense Ratio is less than or equal to Gross Expense Ratio for every Cost Reference Date, and every product with Master-Feeder Role = Feeder names a Master Fund that matches its open Product Relationship of Relationship Type Master - Feeder.",
            "Every active share class has ISIN, Share Class Type, Firm Risk Rating and a Cost Disclosure whose Cost Reference Date is no older than the latest prospectus update, and every active Service Offering has Offering Type, Delivery Mode, Discretion Type, Advisory Capacity and Sponsoring Entity populated.",
            "Lifecycle Event rows with Lifecycle Status Proposed or In Development and Service Offering rows with Offering Status Proposed or In Development are withheld from the Internal view until announced (they stay Restricted - MNPI in the source), and no 01 Investment Commentary or Commentary Approval attribute (author and sign-off names, personal data) is read.",
            "The daily publication is complete by 6am ET with share class and offering row counts equal to the 01 source control totals, and no share class, offering or availability row is first published fewer than 5 business days before its Share Class Launch Date or Availability Effective From.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Investment Strategy' (01, STR-), 'Investment Product / Vehicle' (01, PRD-), "
               "'Share Class' (01, SHC-), 'Model Portfolio' (01, MDL-), 'Service Offering' (01, OFFR-; added at WP0, CW-221) and "
               "'Product Lifecycle Event' (01). It is the SM-00 share class, product, strategy and model portfolio dimension "
               "(CD-296) and the source of the Offering, program, product and share class dimension of the WP2 conformed set (plan "
               "section 8.4); no other product conforms an offering (CW-221). "
               "Certified numbers: none. Fund and class net assets, NAV per share and the certified expense ratios are DP-165's; "
               "Cost Disclosure is read as the prospectus fee-table reference terms and Net Expense Ratio Gap is a reference "
               "attribute. AUM Reporting Category is the Firm AUM reporting category of a product (Firm AUM is DP-241's). "
               "PII tier: none. pii = N although the validator warns that Platform Product Availability Platform Availability ID is "
               "flagged personal data: the content module states 'Object PII tier: No PII' for that object (the flag comes from "
               "the word PII in the note; the 01 owner is asked to reword that note). Portfolio Manager Assignment Portfolio Manager is "
               "an employee reference (20) and is published under a stated exception: portfolio manager names are disclosed in "
               "the prospectus (Form N-1A Item 5), so the column is public. "
               "Boundaries: an offering is not an enrollment (15, DP-093), a model assignment (46, DP-304), a fee (47, DP-305) or a "
               "recommendation (45, DP-303) (CW-032, CW-036). Offering Fee Schedule Link Linked Fee Schedule resolves to DP-305, "
               "Platform Product Availability Due Diligence Approval to DP-306, and Available Third-Party Instrument and Underlying "
               "Fund Instrument to DP-097; DP-305, DP-306 and DP-097 all list DP-004 upstream, so they are not upstream here (one "
               "direction per edge; DP-097 listed by the WP0 candidate would form a cycle) and the keys are checked by those "
               "products. Model Sponsor / Platform resolves to DP-001's intermediary partners downstream. Model weights and lineups "
               "are DP-530's; the shelf and due diligence status view is DP-383; intermediary shelf placement is DP-005 (05); 01 "
               "Distribution Availability Platform Availability is the 05 shelf copy and is not read. Fund dealing, valuation, "
               "listing, income distribution, currency hedging, transaction charges and tax status are DP-079 (re-scoped in place); "
               "Investment Mandate is DP-003; Benchmark and Product Benchmark Assignment DP-144 and DP-145; Product Document and "
               "commentary DP-383; Product Governance DP-385; Investment Restriction DP-161; Management Fee and Other Ongoing "
               "Fees DP-170, DP-506 and DP-586; GIPS Composite DP-158; Regulatory Authorization DP-246. The DP-380 offering scope "
               "drafted by CLA-B is folded in (CW-221); the firm risk rating comes from the retired DP-156 and the feeder terms from "
               "the retired DP-116 (CW-207, CW-930). "
               "Acceptance question 4: feeds DP-341 and DP-342 with the Model Portfolio and Service Offering dimension. "
               "Acceptance question 8: feeds DP-346 with Offering Fee Schedule Link (the schedule each offering bills under). "
               "Tailoring lever: advice offerings run (01 SME 1). Reference default: digital, hybrid, personal advisor, wealth "
               "management, planning only, workplace managed account and OCIO; a self-directed-only firm drops the offering "
               "family. "
               "Tailoring lever: service tiers (01 SME 2). Reference default: firm-wide relationship tiers measured on household "
               "client assets. "
               "Tailoring lever: curated third-party platform (01 SME 4). Reference default: curated, with the 52 approval "
               "referenced; an open platform leaves Due Diligence Approval empty and drops that measure. "
               "Tailoring lever: alternatives offered (01 SME 6). Reference default: feeders, tender-offer and interval funds only. "
               "Tailoring lever: firm risk rating (01 SME 8). Reference default: a product attribute on the 1 to 5 scale. "
               "Tailoring lever: promotional pricing (01 SME 9). Reference default: an Offering Fee Schedule Link of type "
               "Promotional. "
               "Tailoring lever: trust line (TR). Reference default: offered as Offering Type Trust Services with Advisory "
               "Capacity Trust Company Fiduciary. "
               "Taxonomy gap: 01 Offering Feature and Offering Window carry no effective period; feature history is SCD type 2. "
               "Taxonomy gap: 01 Service Offering has no offering-level effective dates; launches and closes are Lifecycle Events. "
               "Drafting assumptions: the 5-business-day lead time; Lifecycle Status Active as Share Class Status = Active; Offering "
               "Types Brokerage and Planning Only exempt from the minimum assets rule; Advisory Capacity values that require a fee "
               "schedule. "
               "Decisions: CW-028, CW-032, CW-036, CW-037, CW-038, CW-161, CW-202, CW-207, CW-221, CW-901, CW-930; CD-023, CD-296. "
               "W1 re-point (CW-901, CW-902): Country Registration dropped, no successor in the wealth 01 (US only), with the measure "
               "Registered Country Count. W1: SEDOL, IA Sector, EFAMA category, Trail Commission Indicator and OCF dropped (CW-901). "
               "WP1 re-scope (CW-202, CW-221): renamed from Product & Share Class Distribution Reference to Product, Offering & Share "
               "Class Reference; primary function FN-78 kept, supporting functions re-pointed to the wealth set. Inputs added: 01 "
               "Product Risk Indicator, Performance Fee, Service Offering, Offering Feature, Offering Eligibility Rule, Offering Fee "
               "Schedule Link, Service Tier, Tradable Universe Policy Rule, Platform Product Availability, Platform Feature, Feeder "
               "Access Terms and Offering Window. Input dropped: 01 Other Ongoing Fees (Distribution (12b-1) Fee Rate and "
               "Shareholder Servicing Fee Rate, read by DP-170, DP-506 and DP-586; intermediary payment terms), and with it the "
               "wholesale business question on 12b-1 rates. All eight wholesale measure names kept (Active Share Class Count is an "
               "SM-00 metric source; Net Expense Ratio Gap, Days to Lifecycle Event and Portfolio Manager Change Flag are SM-00 "
               "share class attributes; the others are on the SM-00 not-published list); eleven measures added. Dimension names "
               "kept; offering, tier, risk rating, platform and window dimensions added. Objects behind conformed entities kept: "
               "Share Class, Investment Product, Investment Strategy, Model Portfolio, Lifecycle Event and Cost Disclosure; models "
               "still conforming 'Country Registration' (models_c2_marketing_product) have had no backing object since W1 and are "
               "for the lineage pass. Model re-cut for lineage: the DP-004 model's Share Class entity (models_f1.py) loses 01 Other "
               "Ongoing Fees (now read by DP-170, DP-506 and DP-586, not by DP-004). Upstream: DP-097 from the WP0 candidate is not listed (cycle, above)."
               "WP1 lineage addition (CW-261, C-4 fix pass): the share class record now publishes the fund fee terms that DP-586 and DP-595 read: 01 Management Fee (Management Fee Rate, Maximum Management Fee Rate, Fee Accrual Basis, Fee Breakpoint Schedule, Fund-Paid Sub-TA Fee Cap, Fund-Paid Sub-TA Fee Cap Per Account, Approving Board Resolution) and 01 Other Ongoing Fees (Administration / Operating Fee Rate, Distribution (12b-1) Fee Rate, Shareholder Servicing Fee Rate), folded into Share Class, and Cost Disclosure Expense Cap Rate. This reverses the WP1 re-scope's drop of 01 Other Ongoing Fees; the earlier 'Input dropped: 01 Other Ongoing Fees' sentence and the Share Class re-cut note are superseded. No measure changed."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-381": dict(
        definition=("Every client service request and every assisted-service interaction (phone, chat, secure message, video, "
                    "email, branch) for every account type, with request controls, maintenance and ownership-transfer detail, "
                    "the authentication of each interaction and the quality assurance review sample. It conforms the "
                    "CONCEPT_OWNERSHIP row 'Service Request' (13, SRQ-) and the 13 Interaction Authentication once, keyed to the "
                    "02 party and 15 account, so that contact center, complaint, fraud, cost-to-serve and Household 360 products "
                    "read one count of contacts and requests (CW-222). It owns no certified metric family."),
        business_questions=[
            "How many service requests did we receive and complete by type, channel and business line, how many were not in good order and why, and how long did they take?",
            "Which open requests have aged past the service standard, and which requests were escalated to a complaint?",
            "How many assisted interactions did we handle by channel, queue and contact reason, with what handle time, wait time and first-contact resolution?",
            "How often did authentication fail, require step-up or raise a Regulation S-ID red flag, and which high-risk maintenance changes were completed without a call-back?",
            "Which estate and ownership-transfer requests are waiting on documents, and what did the QA sample find?",
            "How many service events does each account generate in a period?",
        ],
        grain=("Service request (account x request type x received timestamp) with its request controls, maintenance change and "
               "ownership-transfer detail; companion facts at assisted-service interaction, interaction x authentication attempt "
               "and QA review x reviewed item; immutable event facts with status changes as SCD type 2 on the request"),
        dimensions=["Service request type", "Request status and good order status", "Intake channel / interaction channel",
                    "Interaction queue", "Contact reason", "Requester role", "Authentication method and result",
                    "Account (DP-093)", "Client and household (DP-240)", "Advisor (DP-009)", "Contact center agent (DP-192)",
                    "Servicing provider (DP-240)", "Business line", "Calendar date (DP-013)"],
        measures=[
            ("Service Requests Received", "Count of Service Request rows with Received Timestamp in the period, by Request Type, Intake Channel and Request Business Line.",
             _u("13", "Service Request", "Service Request ID", "Received Timestamp", "Request Type", "Intake Channel", "Request Business Line")),
            ("Service Requests Completed", "Count of Service Request rows with Request Status in Resolved / Completed or Closed and Completed Timestamp in the period, by Request Type.",
             _u("13", "Service Request", "Service Request ID", "Request Status", "Completed Timestamp", "Request Type")),
            ("Not In Good Order Rate %", "Service requests received in the period with Good Order Status = Not In Good Order / Service Requests Received, by NIGO Reason and Intake Channel.",
             _u("13", "Service Request", "Good Order Status", "NIGO Reason") + ["Service Requests Received"]),
            ("Request Cycle Time (Business Days)", "Median business days (DP-013 calendar) from Received Timestamp to Completed Timestamp of requests completed in the period, by Request Type and Servicing Provider.",
             _u("13", "Service Request", "Received Timestamp", "Completed Timestamp", "Request Type", "Servicing Provider")),
            ("Open Requests Past Service Standard", "Count of Service Request rows with Request Status not in Resolved / Completed, Closed, Rejected or Canceled whose Received Timestamp is more than 5 business days before the as-of date, by Request Type and Request Status; the contractual SLA targets are DP-405's.",
             _u("13", "Service Request", "Service Request ID", "Request Status", "Received Timestamp", "Request Type")),
            ("Requests Escalated to Complaint", "Count of Service Request rows received in the period with Escalated Complaint populated, and that count / Service Requests Received; the complaint itself is 08's (CW-070).",
             _u("13", "Service Request", "Escalated Complaint") + ["Service Requests Received"]),
            ("Assisted Interactions", "Count of Contact Center Interaction rows with Interaction Start Timestamp in the period, by Interaction Channel, Interaction Queue and Contact Reason.",
             _u("13", "Contact Center Interaction", "Interaction ID", "Interaction Start Timestamp", "Interaction Channel",
                "Interaction Queue", "Contact Reason")),
            ("Average Handle Time (Seconds)", "Mean Handle Time (Seconds) of the Assisted Interactions, by Interaction Channel and Interaction Queue.",
             _u("13", "Contact Center Interaction", "Handle Time (Seconds)", "Interaction Channel", "Interaction Queue") + ["Assisted Interactions"]),
            ("Average Wait Time (Seconds)", "Mean Wait Time (Seconds) of the Assisted Interactions, by Interaction Channel and Interaction Queue.",
             _u("13", "Contact Center Interaction", "Wait Time (Seconds)", "Interaction Channel", "Interaction Queue") + ["Assisted Interactions"]),
            ("First Contact Resolution Rate %", "Assisted Interactions with First Contact Resolution Indicator = Y / Assisted Interactions, by Contact Reason.",
             _u("13", "Contact Center Interaction", "First Contact Resolution Indicator", "Contact Reason") + ["Assisted Interactions"]),
            ("Dissatisfaction Expressed Rate %", "Assisted Interactions with Dissatisfaction Expressed Indicator = Y / Assisted Interactions, by Interaction Queue; the interactions are the candidates DP-414 checks against the Rule 4530 complaint definition.",
             _u("13", "Contact Center Interaction", "Dissatisfaction Expressed Indicator", "Interaction Queue") + ["Assisted Interactions"]),
            ("Authentication Failure Rate %", "Interaction Authentication attempts in the period with Authentication Result = Failed / all attempts (Authenticated Interaction x Authentication Attempt Number), by Authentication Method and Authentication Assurance Level; attempts with Step-Up Required Indicator = Y shown alongside.",
             _u("13", "Interaction Authentication", "Authenticated Interaction", "Authentication Attempt Number", "Authentication Result",
                "Authentication Method", "Authentication Assurance Level", "Step-Up Required Indicator", "Authentication Timestamp")),
            ("Authentication Red Flags", "Count of Interaction Authentication attempts with Red Flag Raised Indicator = Y or Authentication Result = Bypassed - Supervisor Override in the period, by Authentication Method, with Failed Attempt Count summed (Regulation S-ID red flags).",
             _u("13", "Interaction Authentication", "Red Flag Raised Indicator", "Authentication Result", "Authentication Method",
                "Failed Attempt Count", "Authentication Timestamp")),
            ("High-Risk Maintenance Without Call-Back", "Count of Service Requests with Request Status in Resolved / Completed or Closed and an Account Maintenance Change whose Maintained Data Element is Mailing Address, Email Address, Phone Number or Bank Instruction and whose Request Controls Call-Back Verification Indicator is not Y, by Maintained Data Element; account takeover monitoring is DP-085's.",
             _u("13", "Account Maintenance Change", "Maintained Data Element", "Updated Master Record")
             + _u("13", "Request Controls", "Call-Back Verification Indicator") + _u("13", "Service Request", "Request Status")),
            ("Estate Requests With Documents Outstanding", "Count of Service Requests with a Transfer of Ownership & Estate detail whose Estate Documents Outstanding is populated and whose Request Status is not Resolved / Completed, Closed, Rejected or Canceled, with business days since Received Timestamp.",
             _u("13", "Transfer of Ownership & Estate", "Estate Documents Outstanding", "Related Death Notification")
             + _u("13", "Service Request", "Request Status", "Received Timestamp")),
            ("QA Pass Rate %", "QA Review rows with QA Outcome in Pass or Pass with Coaching / QA Review rows in the period, with the mean QA Score.",
             _u("13", "QA Review", "Reviewed Item", "QA Outcome", "QA Score")),
            ("Service Events per Account", "(Service Requests Received + Assisted Interactions) / distinct Account and Interaction Account values with at least one request or interaction in the period, by Request Business Line; the household rollup uses DP-240 Household Membership as of the period end.",
             _u("13", "Service Request", "Account") + _u("13", "Contact Center Interaction", "Interaction Account")
             + ["Service Requests Received", "Assisted Interactions"]),
        ],
        inputs=[
            ("13", "Service Request", ["Service Request ID", "Request Type", "Request Business Line", "Account", "Requesting Party",
                                       "Requester Role", "Assisting Advisor", "Intake Channel", "Received Timestamp",
                                       "Servicing Provider", "Good Order Status", "NIGO Reason", "Request Status",
                                       "Completed Timestamp", "Resulting Order", "Resulting Client Account Activity",
                                       "Resulting Money Movement", "Escalated Complaint"]),
            ("13", "Request Controls", ["Signature Guarantee Type", "Call-Back Verification Indicator"]),
            ("13", "Account Maintenance Change", ["Maintained Data Element", "Updated Master Record", "Change Notification Document"]),
            ("13", "Transfer of Ownership & Estate", ["Ownership Transfer Reason", "Related Death Notification",
                                                      "Estate Documents Outstanding", "Claimed Beneficiary Designation",
                                                      "Estate Settlement Case", "Deceased-Account Restriction"]),
            ("13", "Contact Center Interaction", ["Interaction ID", "Interaction Channel", "Interaction Party", "Interaction Account",
                                                  "Interaction Agent", "Interaction Queue", "Interaction Start Timestamp",
                                                  "Wait Time (Seconds)", "Handle Time (Seconds)", "Contact Reason",
                                                  "First Contact Resolution Indicator", "Linked Service Request",
                                                  "Dissatisfaction Expressed Indicator"]),
            ("13", "Interaction Authentication", ["Authenticated Interaction", "Authentication Attempt Number",
                                                  "Authenticated Party", "Authentication Method", "Authentication Result",
                                                  "Authentication Assurance Level", "Authentication Timestamp",
                                                  "Step-Up Required Indicator", "Failed Attempt Count", "Red Flag Raised Indicator"]),
            ("13", "QA Review", ["Reviewed Item", "QA Score", "QA Outcome"]),
        ],
        upstream=["DP-240", "DP-093", "DP-009", "DP-192", "DP-013"],
        refresh="Daily",
        timeliness=("By 6am ET on T+1 for the prior day's requests, interactions and authentication attempts; interactions and "
                    "authentication red flags on the event stream within 15 minutes"),
        history=("Every request, interaction, authentication attempt and QA review kept as an immutable fact, with request status "
                 "changes as SCD type 2; kept at least six years (SEC Rule 17a-4) and longer where the request is linked to a "
                 "complaint or an estate settlement"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Account and Interaction Account resolves to an Account ID in DP-093, every Requesting Party, Interaction Party, Authenticated Party and Servicing Provider to a DP-240 party, every Interaction Agent to an active DP-192 employee, every Assisting Advisor to a DP-009 advisor, every Linked Service Request and Authenticated Interaction to a row of this product, and every Escalated Complaint to an 08 Complaint ID.",
            "Completed Timestamp is populated exactly when Request Status is Resolved / Completed or Closed (the shared Case Status values that count as closed) and is on or after Received Timestamp, every Authentication Timestamp falls on the date of its interaction's Interaction Start Timestamp, and Authentication Attempt Number runs from 1 without gaps for each Authenticated Interaction.",
            "Every Linked Service Request on a Contact Center Interaction resolves to a Service Request whose Account equals the Interaction Account, every Authenticated Interaction resolves to a Contact Center Interaction, and every Service Request with Request Type Deceased Client Notification, Estate / Death Claim or Transfer on Death Claim has a Transfer of Ownership & Estate detail with Related Death Notification populated.",
            "Every Service Request has Request Type, Account, Intake Channel, Received Timestamp, Good Order Status and Request Status, every request with Good Order Status = Not In Good Order has a NIGO Reason, every interaction has Interaction Channel, Interaction Start Timestamp and Handle Time (Seconds), and every authentication attempt has Authentication Method and Authentication Result.",
            "Recording Reference and authentication evidence are never read, the analytics view carries party and account keys but no names, and the Ownership Transfer Reason value Incapacity / Guardianship is excluded at read (published as no reason) so that no special-category fact is held here (CD-344, CW-213); the Deceased-Account Restriction key is published, never the restriction detail.",
            "The prior day is complete by 6am ET on T+1, and interactions and authentication attempts with Red Flag Raised Indicator = Y reach the event stream within 15 minutes of the source commit.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP row 'Service Request' (13, SRQ-; added at WP0 with CW-222) and the 13 Interaction "
               "Authentication (assisted-service authentication, CW-086). It is the conformed service fact behind the service "
               "dimensions of the WP2 conformed set (CW-229). "
               "Certified numbers: none read or owned. "
               "Operating model (CD-297, CD-331): in-house contact center and transfer agent; with an outsourced contact center the "
               "grain is the same, received from the provider (Servicing Provider), and the QA sample is the provider's. "
               "PII tier: identity. Special category is not read: the Ownership Transfer Reason value Incapacity / Guardianship (13 content, CD-344) is excluded at read, as DP-093 excludes the Rule 2165 rows, and incapacity and guardianship facts reach consumers only through DP-322 (CW-213), which is not upstream because it is a consumer product. Publication: the "
               "analytics view carries keys, types, channels, timestamps and durations; requester names and interaction notes are "
               "never published. "
               "Boundaries: complaints are 08 and referenced, never copied (CW-070; DP-414); the resulting fund order (29), client "
               "account activity (49) and money movement (50) are keys resolved downstream by DP-580, DP-300 and DP-302, which do "
               "not depend on this product; digital logins are 04 (CW-086) and CIP verification 02 (DP-240); account maintenance "
               "results are 15 (DP-093); SLA definitions and measurements, staffing and the contact center scorecard are DP-405; "
               "request fulfillment detail DP-406 (backlog); account takeover monitoring DP-085; voice of client DP-397 (backlog). "
               "DP-498 (cost to serve) and DP-320 (Household 360) read service facts from here. "
               "Acceptance question 11: feeds DP-498 with Service Events per Account, Assisted Interactions and Service Requests "
               "Received by account (rolled to household and segment through DP-240). "
               "Tailoring lever: one service request master (13 SME 1). Reference default: yes, for brokerage, fund-only and "
               "participant accounts; a recordkeeper with its own case tool keeps participant requests in 16 and this product "
               "drops them. "
               "Tailoring lever: advisor personal recognition as an authentication method (13 SME 8). Reference default: listed "
               "but limited by policy. "
               "Tailoring lever: oral grievances (CW-070). Reference default: recorded as complaints by firm policy and flagged on "
               "the interaction (Dissatisfaction Expressed Indicator). "
               "Taxonomy gap: 13 QA Review has no review date or reviewer; the period is taken from the reviewed item's timestamp. "
               "Taxonomy gap: 13 Service Request has no target completion date or SLA reference; the service standard is a drafting "
               "threshold. "
               "Drafting assumptions: the 5-business-day service standard; the high-risk Maintained Data Element values; the 0.5% "
               "Request Status values Rejected and Canceled treated as closed beside the Case Status closed values Resolved / Completed and Closed; the 15-minute event "
               "latency. "
               "Decisions: CW-070, CW-086, CW-088, CW-222, CW-229; CD-297, CD-344. "
               "WP1 new (CW-222): registered in WAVE_WP1F by the WP0 integration from the CLA-B candidate (CW-229); all seven "
               "candidate objects read."),
    ),
    # ------------------------------------------------------------------------------------------------------------------
    "DP-382": dict(
        definition=("Every statement, confirmation delivery, tax form, regulatory communication and notice produced for a client "
                    "or fund shareholder, with its production run, its distribution, the recipient-level delivery record (method, "
                    "date, returned mail), the e-delivery election and mail hold in force and the mailing household (13 "
                    "Householding Group). It conforms the CONCEPT_OWNERSHIP rows 'Investor Document' (13, STMT-) and 'Shareholder "
                    "Communication' (13, COMM-) once, so that disclosure, statement, proxy, privacy and tax products cite one "
                    "delivery record instead of each rebuilding it (CW-223). It owns no certified metric family."),
        business_questions=[
            "How many statements, confirmations and other client documents did we issue by category and delivery method, how many were electronic, and how many were delivered late?",
            "Which deliveries bounced, failed or came back as returned mail, and which accounts are now on mail hold?",
            "Which trade confirmations were sent after settlement, and which tax forms were furnished or filed after their due dates or corrected?",
            "Which regulatory communications missed their delivery deadline, and which production runs did not reconcile?",
            "Which accounts have an electronic delivery election in force with consent evidence, and which mailing households must resume individual delivery?",
        ],
        grain=("Investor document (definition x account x recipient x period end x version) and recipient delivery record (distribution "
               "job x recipient account, or investor document x recipient); companion facts at confirmation delivery, tax form "
               "(account x tax document type x tax year x form version), production run, shareholder communication and "
               "communication distribution; e-delivery election with mail hold and householding group as SCD type 2"),
        dimensions=["Investor document category and statement type", "Document regulatory basis", "Delivery method and delivery status",
                    "Shareholder communication type and regulatory basis", "Audience basis", "Tax document type and tax year",
                    "Election document scope and delivery preference", "Mailing household (13 Householding Group, CW-027)",
                    "Account (DP-093)", "Client and household (DP-240)", "Share class (DP-004)", "Issuing entity (DP-013)",
                    "Calendar date (DP-013)"],
        measures=[
            ("Documents Issued", "Count of Investor Document rows with Period End Date in the period, by Investor Document Category, Statement Type and Delivery Method.",
             _u("13", "Investor Document", "Investor Document ID", "Period End Date", "Delivery Method", "Document Definition")
             + _u("13", "Investor Document Definition", "Document Definition Code", "Investor Document Category", "Statement Type")),
            ("Electronic Delivery Rate %", "Documents Issued with Delivery Method in Electronic - Email Notification, Electronic - Email Attachment or Electronic - Portal Posting / Documents Issued less those with Suppression Reason populated.",
             _u("13", "Investor Document", "Delivery Method", "Suppression Reason") + ["Documents Issued"]),
            ("Documents Delivered Late", "Count of Documents Issued whose Delivered Date is later than Period End Date plus the days set by the definition's Recipient Furnish Deadline Rule, by Investor Document Category and Document Regulatory Basis (for example FINRA Rule 2231 statements, Advisers Act Rule 206(4)-2).",
             _u("13", "Investor Document", "Delivered Date", "Period End Date")
             + _u("13", "Investor Document Definition", "Recipient Furnish Deadline Rule", "Document Regulatory Basis", "Investor Document Category")
             + ["Documents Issued"]),
            ("Failed or Returned Deliveries", "Count of Recipient Delivery Record rows in the period with Recipient Delivery Status in Email Bounced, Returned Undeliverable or Failed, by Return Reason and Recipient Delivery Method; and that count / all Recipient Delivery Record rows in the period.",
             _u("13", "Recipient Delivery Record", "Recipient Delivery Status", "Return Reason", "Recipient Delivery Method",
                "Distribution Job", "Delivered Investor Document")),
            ("Accounts With Returned Mail", "Count of distinct Recipient Account with a Returned Mail Date in the last 12 months, and of those the accounts that are the Election Account of an E-Delivery Election with Mail Hold Indicator = Y; the lost securityholder process is DP-418's.",
             _u("13", "Recipient Delivery Record", "Recipient Account", "Returned Mail Date") + _u("13", "Mail Hold", "Mail Hold Indicator")
             + _u("13", "E-Delivery Election", "Election Account")),
            ("Confirmations Sent After Settlement", "Count of Confirmation Delivery rows with Confirmation Timing = Immediate whose Confirmation Sent Date is after the Confirmed Settlement Date of the 48 Client Trade Confirmation, and that count / Confirmation Delivery rows with Confirmation Timing = Immediate sent in the period (SEC Rule 10b-10).",
             _u("13", "Confirmation Delivery", "Client Trade Confirmation", "Confirmation Timing", "Confirmation Sent Date")
             + _u("48", "Client Trade Confirmation", "Client Trade Confirmation ID", "Confirmed Settlement Date")),
            ("Tax Forms Furnished Late", "Count of distinct tax forms (Tax Form Account x Tax Document Type x Tax Year x Tax Form Version) with Furnished Date after Recipient Furnish Due Date, and of those with Authority Filing Date after Authority Filing Due Date, by Tax Document Type and Payer Entity.",
             _u("13", "Tax Form Record", "Tax Form Account", "Tax Document Type", "Tax Year", "Tax Form Version", "Furnished Date",
                "Recipient Furnish Due Date", "Authority Filing Date", "Authority Filing Due Date", "Payer Entity")),
            ("Corrected Tax Forms", "Count of distinct tax forms with Tax Form Version = Corrected, by Tax Document Type and Tax Year, and that count / distinct forms with Tax Form Version = Original; forms with Reclassification Pending Indicator = Y shown separately.",
             _u("13", "Tax Form Record", "Tax Form Account", "Tax Document Type", "Tax Year", "Tax Form Version",
                "Reclassification Pending Indicator")),
            ("Communication Distributions Missing Deadline", "Count of Communication Distribution rows with Mail Date in the period and Deadline Met Indicator = N, by Communication Type and Communication Regulatory Basis of the Distributed Communication, with business days past Required Delivery Deadline.",
             _u("13", "Communication Distribution", "Distribution Job ID", "Distributed Communication", "Mail Date", "Deadline Met Indicator")
             + _u("13", "Shareholder Communication", "Communication ID", "Communication Type", "Communication Regulatory Basis",
                  "Required Delivery Deadline")),
            ("Production Runs Not Reconciled", "Count of Production Run rows with Run Date in the period and Run Reconciliation Status other than Reconciled, by Print / Delivery Vendor, with Documents Produced Count and Documents Suppressed Count summed.",
             _u("13", "Production Run", "Production Run ID", "Run Date", "Run Reconciliation Status", "Print / Delivery Vendor",
                "Documents Produced Count", "Documents Suppressed Count")),
            ("Suppressed Documents by Reason", "Count of Documents Issued with Suppression Reason populated, by Suppression Reason (householded, e-delivery elected, returned mail, mail hold and others).",
             _u("13", "Investor Document", "Suppression Reason") + ["Documents Issued"]),
            ("E-Delivery Election Coverage %", "Distinct Document Account with Investor Document Category = Periodic Statement in the period that are the Election Account of an E-Delivery Election with Delivery Preference = Electronic, Election Document Scope in All Documents or Statements and no Election Revoked Timestamp / distinct Document Account with a Periodic Statement in the period.",
             _u("13", "E-Delivery Election", "Election Account", "Delivery Preference", "Election Document Scope", "Election Revoked Timestamp")
             + _u("13", "Investor Document", "Document Account") + _u("13", "Investor Document Definition", "Investor Document Category")),
            ("Electronic Elections Without Consent Evidence", "Count of E-Delivery Election rows with Delivery Preference = Electronic and no Election Revoked Timestamp whose E-Delivery Consent Type = Not Given or whose Consent Captured Timestamp is empty, by Election Basis.",
             _u("13", "E-Delivery Election", "Delivery Election ID", "Delivery Preference", "Election Revoked Timestamp",
                "E-Delivery Consent Type", "Consent Captured Timestamp", "Election Basis")),
            ("Active Mailing Households", "Count of Householding Group rows with Householding Status = Active on the as-of date and the count of their Member Accounts, by Householded Document Scope and Householding Consent Type. The mailing household is not the 02 client household or the 47 fee household (CW-027).",
             _u("13", "Householding Group", "Householding Group ID", "Householding Status", "Member Accounts",
                "Householded Document Scope", "Householding Consent Type")),
            ("Householding Revocations Overdue", "Count of Householding Group rows with Householding Revocation Date populated whose Householding Status is still Active after their Individual Delivery Resume Due Date (SEC Rule 30e-1(f)).",
             _u("13", "Householding Group", "Householding Revocation Date", "Householding Status", "Individual Delivery Resume Due Date")),
            ("Accounts on Mail Hold", "Count of E-Delivery Election rows with Mail Hold Indicator = Y, Mail Hold Start Date on or before the as-of date and Mail Hold End Date empty or after it, by Mail Hold Reason, with days since Mail Hold Start Date.",
             _u("13", "Mail Hold", "Mail Hold Indicator", "Mail Hold Start Date", "Mail Hold End Date", "Mail Hold Reason")
             + _u("13", "E-Delivery Election", "Election Account")),
        ],
        inputs=[
            ("13", "Investor Document Definition", ["Document Definition Code", "Investor Document Category", "Statement Type",
                                                    "Document Regulatory Basis", "Recipient Furnish Deadline Rule"]),
            ("13", "Investor Document", ["Investor Document ID", "Document Definition", "Document Account", "Document Recipient",
                                         "Issuing Entity", "Period End Date", "Delivery Method", "Delivery Status",
                                         "Delivered Date", "Suppression Reason", "Original Document"]),
            ("13", "Confirmation Delivery", ["Client Trade Confirmation", "Confirmed Fund Order", "Confirmation Timing",
                                             "Confirmation Sent Date"]),
            ("13", "Tax Form Record", ["Tax Form Account", "Tax Document Type", "Tax Year", "Payer Entity", "Tax Form Version",
                                       "Recipient Furnish Due Date", "Furnished Date", "Authority Filing Due Date",
                                       "Authority Filing Date", "Reclassification Pending Indicator"]),
            ("13", "Production Run", ["Production Run ID", "Print / Delivery Vendor", "Run Date", "Documents Produced Count",
                                      "Documents Suppressed Count", "Run Reconciliation Status"]),
            ("13", "Shareholder Communication", ["Communication ID", "Communication Type", "Communication Regulatory Basis",
                                                 "Communicating Entity", "Covered Share Classes", "Report Period End Date",
                                                 "Required Delivery Deadline", "Communication Status"]),
            ("13", "Communication Distribution", ["Distribution Job ID", "Distributed Communication", "Audience Basis",
                                                  "Audience Record Date", "Notice-and-Access Indicator", "Mail Date",
                                                  "Deadline Met Indicator", "Suppression Rules Applied"]),
            ("13", "Recipient Delivery Record", ["Distribution Job", "Delivered Investor Document", "Recipient Account",
                                                 "Recipient Delivery Method", "Recipient Delivery Status", "Returned Mail Date",
                                                 "Return Reason"]),
            ("13", "E-Delivery Election", ["Delivery Election ID", "Election Account", "Election Document Scope", "Election Basis",
                                           "Delivery Preference", "E-Delivery Consent Type", "Consent Captured Timestamp",
                                           "Tax Form Electronic Consent Indicator", "Election Revoked Timestamp",
                                           "Linked Consent Record"]),
            ("13", "Householding Group", ["Householding Group ID", "Member Accounts", "Householding Address",
                                          "Householded Document Scope", "Householding Consent Type", "Householding Notice Sent Date",
                                          "Householding Status", "Householding Revocation Date",
                                          "Individual Delivery Resume Due Date"]),
            ("13", "Mail Hold", ["Mail Hold Indicator", "Mail Hold Reason", "Mail Hold Start Date", "Mail Hold End Date"]),
            ("48", "Client Trade Confirmation", ["Client Trade Confirmation ID", "Confirmation Account", "Confirmed Trade Date",
                                                 "Confirmed Settlement Date"]),
        ],
        upstream=["DP-240", "DP-093", "DP-004", "DP-301", "DP-013"],
        refresh="Daily",
        timeliness=("By 6am ET on T+1 for documents, deliveries and elections of the prior business day; returned mail and mail "
                    "holds on the event stream within one hour of capture"),
        history=("Every document, delivery record, distribution and tax form version kept as an immutable fact; elections, mail "
                 "holds and householding groups as SCD type 2; kept at least six years (SEC Rule 17a-4), three years after "
                 "the tax year for tax forms where longer, and five years for advisory account statements (Advisers Act Rule 204-2)"),
        classification="Confidential - Personal Data",
        pii="Y",
        delivery=["Warehouse table", "BI semantic model", "API", "Event stream"],
        dq_rules=[
            "Every Document Account, Recipient Account, Election Account, Tax Form Account, Member Accounts value and Confirmation Account resolves to a DP-093 Account ID, every Document Recipient, Householding Address and Linked Consent Record to DP-240, every Covered Share Classes value to DP-004, every Client Trade Confirmation to a DP-301 confirmation of the same account, and every Document Definition, Distributed Communication, Distribution Job and Delivered Investor Document to a row of this product.",
            "For one Election Account and Election Document Scope the E-Delivery Election periods (Consent Captured Timestamp to Election Revoked Timestamp) do not overlap, Mail Hold End Date and Householding Revocation Date are on or after Mail Hold Start Date and Householding Notice Sent Date, and an account is a Member Accounts value of at most one Householding Group with Householding Status = Active per Householded Document Scope.",
            "Every Communication Distribution with Mail Date populated is the Distribution Job of at least one Recipient Delivery Record, every Recipient Delivery Record with Delivered Investor Document populated names an Investor Document whose Document Account equals its Recipient Account, every Production Run with Run Reconciliation Status = Reconciled has Documents Produced Count and Documents Suppressed Count populated, and every Investor Document with Delivery Status = Delivered has a Delivered Date on or after its Period End Date.",
            "Every Investor Document has Document Definition, Document Account, Period End Date and Delivery Method, every Recipient Delivery Record has Recipient Account and Recipient Delivery Status and a Returned Mail Date when the status is Returned Undeliverable, and every Tax Form Record has Tax Document Type, Tax Year, Tax Form Version and Recipient Furnish Due Date.",
            "Recipient names and Householding Address appear only in the servicing view, Tax Form Record Reported Amount and Recipient TIN (Masked) and Document Repository Reference are not read, and the analytics view carries account keys, categories, methods, statuses and dates only.",
            "The prior day's documents and deliveries are complete by 6am ET on T+1 with Investor Document and Recipient Delivery Record row counts equal to the 13 source control totals, and returned mail and mail holds reach the event stream within one hour.",
        ],
        notes=("Master concept: CONCEPT_OWNERSHIP rows 'Investor Document' (13, STMT-; added at WP0 with CW-223), 'Shareholder "
               "Communication' (13, COMM-) and the 13 Mailing Household (Householding Group, MHG-). 13 masters delivery; 48 masters "
               "the trade confirmation (CW-081); 15 masters the opening disclosure deliveries and 47 the fee disclosure deliveries, "
               "which are read beside this product from their masters (CW-087, CW-223). "
               "Certified numbers: none read or owned. "
               "Operating model (CD-297, CD-331): statements, confirmations and tax forms produced in house and printed by a vendor "
               "(Print / Delivery Vendor), with the vendor's run reconciliation; with an outsourced transfer agent the fund-only "
               "documents are received from the agent at the same grain. "
               "PII tier: financial (client documents and tax forms; recipient and address keys are identity). Publication as DQ5 "
               "states. "
               "Boundaries: the mailing household is not the 02 client household (DP-240) or the 47 fee household (DP-305) "
               "(CW-027). Returned mail is mastered here (13 Recipient Delivery Record); 02 Postal Address Mail Returned Date is a "
               "derived copy (CW-089). Document content (statement lines, tax form amounts) is not published here: holdings are "
               "DP-300 and tax form amounts are read by DP-417 (backlog) and DP-355. Shareholder communications of own funds feed "
               "DP-069 (re-scoped; replaces DP-069 as DP-106's upstream, CLA-B RESPEC), proxy delivery DP-408, Form CRS and Reg BI "
               "delivery control DP-399, statement and confirmation delivery DP-407 (backlog), escheatment DP-418. The confirmed "
               "fund order (29) key resolves to DP-580 downstream. "
               "Tailoring lever: household statements (13 SME 5). Reference default: one statement per account, household "
               "consolidation optional (Statement Type = Consolidated Household Statement). "
               "Tailoring lever: annual privacy notice (13 SME 6). Reference default: not sent while the Regulation S-P annual "
               "notice exception applies; sent on a change in practices. "
               "Tailoring lever: returned mail master (13 SME 7). Reference default: 13 Recipient Delivery Record; a CRM that "
               "masters returned mail flips the derived flag and this product reads it from there. "
               "Tailoring lever: householding offered (Rule 30e-1, Rule 154). Reference default: offered for prospectuses, "
               "shareholder reports and proxy materials with implied consent. "
               "Taxonomy gap: 13 Investor Document has no link to its Production Run, and no attribute holds the print vendor's control total; run reconciliation is the vendor-reported Run Reconciliation Status only. "
               "Taxonomy gap: 13 Investor Document Definition Recipient Furnish Deadline Rule is text, not a number of days; Documents "
               "Delivered Late needs it parsed into days per definition. "
               "Taxonomy gap: 13 Householding Group has no individual delivery resumed date; Householding Revocations Overdue uses "
               "Householding Status. "
               "Drafting assumptions: the Electronic Delivery Method values; the 12-month returned mail window; Confirmation Timing "
               "= Immediate as the Rule 10b-10 population; the one-hour event latency. "
               "Decisions: CW-027, CW-081, CW-087, CW-089, CW-098, CW-223, CW-229; CD-297. "
               "WP1 new (CW-223): registered in WAVE_WP1F by the WP0 integration from the CLA-B candidate (CW-229); all ten "
               "candidate objects read, plus 13 Tax Form Record (its readers DP-417 and DP-330 are backlog) and 48 Client Trade "
               "Confirmation for the Rule 10b-10 timing: Client Trade Confirmation ID and Confirmed Settlement Date are read as "
               "DP-301 publishes them (DP-301 upstream, the confirmations fact); the read is needed because the delivery-to-"
               "settlement relationship lives only in the 13 Confirmation Delivery reference."),
    ),
}
