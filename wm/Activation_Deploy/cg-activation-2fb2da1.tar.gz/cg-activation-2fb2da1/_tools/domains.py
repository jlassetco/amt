"""The Data Domain register: number, name and two-letter L1 code of every Data Domain, in one place.

01-16 are the distribution taxonomy (frozen at git tag distribution-v0.4). 17-44 are the enterprise expansion
domains from 00_Program/Enterprise_Expansion_Plan.md section 3 (numbered provisionally, in stage order). 45-52 are the
wealth-manager sibling's new domains (00_Program/Wealth_Manager_Rework_Plan.md section 5.2); the wholesale model is
frozen at git tag wholesale-v1.0.
The wealth model's dispositions (keep, adapt, replace, retire, new), the decisions that rule them and the retired numbers
are registered below DD_NAMES (DISPOSITION, DISPOSITION_DECISION, RETIRED_DOMAINS, WEALTH_DOMAINS; CW-019).
taxonomy_builder.py re-exports DD_NAMES and L1_CODE; ownership.py and enrichment/check_enrichment.py read them from here.
"""
import re

DD_NAMES = {
    # Distribution (distribution-v0.4); 01 and 02 renamed at the wealth model's W1 merge (CW-021, CW-040), 03 to 06, 08, 10
    # and 13 at the W2-W4 merge (CW-062, CW-904, CW-131, CW-141, CW-066, CW-156, CW-081); wholesale names at tag
    # wholesale-v1.0. 07 and 30 retired at W4 (CW-907, CW-930): their names stay registered for history (RETIRED_DOMAINS).
    "01": "Investment Product & Service Offering", "02": "Client & Household",
    "03": "Advisor Organization, Coverage & Supervision", "04": "Marketing, Digital & Client Engagement",
    "05": "Intermediary & Institutional Distribution", "06": "Client Assets, Flows & Channel Attribution",
    "07": "Compensation & Territory", "08": "Retail Conduct & Supervision", "09": "Shared & Enterprise Reference Data",
    "10": "Client Revenue, Pricing Economics & Profitability", "11": "Market & Competitive Intelligence",
    "12": "Institutional Client Servicing & Reporting", "13": "Client Service & Communications",
    "14": "Third-Party Data & Licensing", "15": "Account", "16": "Retirement Plan Administration",
    # Stage 1: enterprise anchors
    "17": "Instrument & Issuer Reference", "18": "Portfolio & Investment Book of Record", "19": "Finance & Accounting",
    "20": "Human Capital", "21": "Data Governance & Analytics",
    # Stage 2: investment value chain and fund operations
    "22": "Market Data & Pricing", "23": "Investment Research", "24": "Portfolio Management & Construction",
    "25": "Portfolio Trading & Execution", "26": "Trade Operations, Settlement & Collateral", "27": "Fund Accounting & Valuation",
    "28": "Fund Custody & Asset Servicing", "29": "Transfer Agency Operations", "30": "Private Markets",
    # Stage 3: investment oversight and product governance
    "31": "Investment Risk", "32": "Performance & Attribution", "33": "Investment Compliance",
    "34": "Stewardship & Sustainable Investing", "35": "Fund Governance & Regulatory Reporting",
    "36": "Product Development & Lifecycle",
    # Stage 4: corporate and support functions
    "37": "Enterprise & Operational Risk", "38": "Corporate Compliance & Regulatory Affairs",
    "39": "Legal & Corporate Governance", "40": "Procurement & Vendor Management",
    "41": "Technology & Information Security", "42": "Corporate Communications & Public Affairs",
    "43": "Corporate Treasury & Capital", "44": "Workplace & Corporate Services",
    # Wealth-manager sibling (Wealth_Manager_Rework_Plan.md section 5.2; CW-002): registered at W0, modules follow in
    # Stages W2 and W3. Replaced domains keep their numbers and are renamed at their stage; 07 and 30 retire at W4.
    "45": "Financial Planning & Advice", "46": "Managed Portfolios & Rebalancing", "47": "Pricing, Fees & Billing",
    "48": "Brokerage Orders & Execution", "49": "Clearing, Settlement & Client Asset Custody",
    "50": "Money Movement, Cash & Sweep", "51": "Trust & Estate Services",
    "52": "External Manager & Sub-Adviser Oversight",
}

L1_CODE = {"01": "PR", "02": "HH", "03": "AO", "04": "MK", "05": "DI", "06": "TX", "07": "CT", "08": "RC", "09": "SR",
           "10": "DF", "11": "MI", "12": "IS", "13": "SV", "14": "TD", "15": "AC", "16": "RP",
           "17": "IN", "18": "IB", "19": "FI", "20": "HC", "21": "DG", "22": "MD", "23": "RS", "24": "PM", "25": "TR",
           "26": "TO", "27": "FA", "28": "CU", "29": "TA", "30": "PV", "31": "RK", "32": "PF", "33": "IC", "34": "ST",
           "35": "FG", "36": "PD", "37": "ER", "38": "CO", "39": "LG", "40": "VM", "41": "IT", "42": "CP", "43": "TY",
           "44": "WS",
           "45": "AV", "46": "MA", "47": "FB", "48": "BR", "49": "BC", "50": "MM", "51": "TE", "52": "EM"}

DISTRIBUTION_DOMAINS = [f"{i:02d}" for i in range(1, 17)]       # the distribution-v0.4 baseline
EXPANSION_DOMAINS = [n for n in DD_NAMES if n not in DISTRIBUTION_DOMAINS]
WHOLESALE_DOMAINS = [f"{i:02d}" for i in range(1, 45)]          # the wholesale model at wholesale-v1.0 (01-44)

# ---- Wealth-manager sibling (Wealth_Manager_Rework_Plan.md sections 5.1, 5.2 and 9; CW-019) -------------------------
# Retired Data Domains: number -> the CW- decision that retired it. A retired number is never reused (CW-002). Its
# module is removed at its stage; validators still accept the number in historical decisions and prefixes, no builder
# renders it, and check_baseline.py reports it as "retired by CW-nnn" rather than as a removal. 07 (CW-013) and 30
# (CW-016) were retired at the W2-W4 merge, when their modules were removed (CW-907, CW-930); DD_NAMES, L1_CODE (CT, PV)
# and DISPOSITION keep their entries so historical decisions and prefixes validate.
RETIRED_DOMAINS = {"07": "CW-907", "30": "CW-930"}

# Disposition of every Data Domain in the wealth model: number -> (disposition, target name or "").
#   keep     carried with the US-only pass (CW-003) and perspective text only; a target name is a rename
#   adapt    families added or re-cut, boundary moved; keeps its L1 code; a target name is the new name
#   replace  a new module under the same number with a new L1 code (02 HH, 03 AO, 05 DI, 08 RC), applied at its stage;
#            check_baseline.py compares it by counts only once the replacement lands
#   retire   removed at its stage; the number is never reused
#   new      a wealth-model domain (45 onward)
# DD_NAMES and L1_CODE keep the wholesale names and codes until each domain's stage applies its target (applied for every
# domain at the W2-W4 merge; 38 became 'adapt' with its W4 adaptation, CW-938).
DISPOSITION = {
    "01": ("adapt", "Investment Product & Service Offering"), "02": ("replace", "Client & Household"),
    "03": ("replace", "Advisor Organization, Coverage & Supervision"),
    "04": ("adapt", "Marketing, Digital & Client Engagement"),
    "05": ("replace", "Intermediary & Institutional Distribution"),
    "06": ("adapt", "Client Assets, Flows & Channel Attribution"), "07": ("retire", ""),
    "08": ("replace", "Retail Conduct & Supervision"), "09": ("keep", ""),
    "10": ("adapt", "Client Revenue, Pricing Economics & Profitability"), "11": ("adapt", ""), "12": ("adapt", ""),
    "13": ("adapt", "Client Service & Communications"), "14": ("keep", ""), "15": ("replace", "Account"),
    "16": ("adapt", ""), "17": ("keep", ""), "18": ("keep", ""), "19": ("keep", ""), "20": ("keep", ""),
    "21": ("keep", ""), "22": ("keep", ""), "23": ("keep", ""), "24": ("adapt", ""),
    "25": ("keep", "Portfolio Trading & Execution"), "26": ("keep", ""), "27": ("keep", ""),
    "28": ("keep", "Fund Custody & Asset Servicing"), "29": ("adapt", ""), "30": ("retire", ""), "31": ("keep", ""),
    "32": ("adapt", ""), "33": ("keep", ""), "34": ("keep", ""), "35": ("keep", ""), "36": ("adapt", ""),
    "37": ("keep", ""), "38": ("adapt", ""), "39": ("keep", ""), "40": ("keep", ""), "41": ("keep", ""),
    "42": ("keep", ""), "43": ("keep", ""), "44": ("keep", ""),
    "45": ("new", "Financial Planning & Advice"), "46": ("new", "Managed Portfolios & Rebalancing"),
    "47": ("new", "Pricing, Fees & Billing"), "48": ("new", "Brokerage Orders & Execution"),
    "49": ("new", "Clearing, Settlement & Client Asset Custody"), "50": ("new", "Money Movement, Cash & Sweep"),
    "51": ("new", "Trust & Estate Services"), "52": ("new", "External Manager & Sub-Adviser Oversight"),
}

# The W0 decision that rules each disposition (the domain's own US-only or rework decision is logged at its stage).
# CW-003 is the US-only pass of the kept domains; CW-001 frames the adapted domains with no specific W0 ruling.
DISPOSITION_DECISION = {
    "01": "CW-008", "02": "CW-005", "03": "CW-013", "04": "CW-001", "05": "CW-013", "06": "CW-007", "07": "CW-013",
    "08": "CW-015", "10": "CW-012", "11": "CW-013", "12": "CW-012", "13": "CW-001", "15": "CW-006", "16": "CW-006",
    "24": "CW-009", "25": "CW-010", "28": "CW-007", "29": "CW-006", "30": "CW-016", "32": "CW-011", "36": "CW-001",
    "45": "CW-008", "46": "CW-009", "47": "CW-012", "48": "CW-010", "49": "CW-007", "50": "CW-016", "51": "CW-017",
    "52": "CW-014",
}
DISPOSITION_DECISION = {n: DISPOSITION_DECISION.get(n, "CW-003") for n in DISPOSITION}

# L1 codes the replaced domains take when their replacement module lands (the wholesale codes SL, DA and DC retired with the
# modules at the W2-W4 merge; applied in L1_CODE above)
REPLACEMENT_L1_CODE = {"02": "HH", "03": "AO", "05": "DI", "08": "RC"}

WEALTH_DOMAINS = [n for n in DD_NAMES if n not in RETIRED_DOMAINS]   # every Data Domain the wealth model renders
NEW_DOMAINS = [n for n, (d, _) in DISPOSITION.items() if d == "new"]  # 45-52

assert set(DISPOSITION) == set(DD_NAMES) == set(L1_CODE), "DISPOSITION, DD_NAMES and L1_CODE must cover the same domains"
assert all(DISPOSITION[n][0] == "retire" for n in RETIRED_DOMAINS), "a retired domain must have disposition 'retire'"
assert all(L1_CODE[n] == c for n, c in REPLACEMENT_L1_CODE.items()), "a replaced domain carries its replacement L1 code"

# A Data Domain number written in free text, e.g. "Reference (Party, 02)"
DOMAIN_NUMBER = re.compile(r"\b(" + "|".join(sorted(DD_NAMES, reverse=True)) + r")\b")

# Folder names of the distribution domains, as they exist (01 predates the convention)
_FOLDERS = {"01": "01_Product",
            # Adapted domains renamed at the W2-W4 merge keep their wholesale folders and output paths (04, 06, 10, 13);
            # the replaced 03, 05 and 08 have new folders under the convention
            "04": "04_Marketing_and_Digital", "06": "06_Sales_Transactions_and_AUM_Attribution",
            "10": "10_Distribution_Finance_and_Profitability", "13": "13_Investor_Servicing_and_Shareholder_Communications",
            # W1b renames (CW-925, CW-928) keep their wholesale folders and output paths
            "25": "25_Trading_and_Execution", "28": "28_Custody_and_Asset_Servicing",
            # retired at W4 (CW-907, CW-930): folders removed; names kept for history
            "07": "07_Compensation_and_Territory", "30": "30_Private_Markets"}


def folder(n):
    """Domain folder name: NN_Name_With_Underscores ('&' -> 'and'; hyphens and commas dropped), e.g. 17_Instrument_and_Issuer_Reference."""
    if n in _FOLDERS:
        return _FOLDERS[n]
    words = re.sub(r"[-,]", " ", DD_NAMES[n].replace("&", "and")).split()
    return f"{n}_" + "_".join(words)
