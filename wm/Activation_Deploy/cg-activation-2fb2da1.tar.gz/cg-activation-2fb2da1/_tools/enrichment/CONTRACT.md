# Enrichment contract (v0.4): grain, ownership flags, domain summaries

There is one file per Data Domain: `enrich_NN.py` (NN = "01" … "14"). Keys use the names exactly as they appear in the content module:
- **Family** = the content module's Domain name (tuple element 0 of each `T` entry)
- **Object** = its Concept name
- **Attribute** = the attribute name

```python
# Every Data Business Object (concept) in the Data Domain must appear exactly once.
GRAIN = {
  ("Share Class", "Share Class"): ("share class", "Business Object", ""),
  ("Share Class", "Currency Hedging"): ("share class", "Attribute Group", "Share Class"),
  ("Attribution", "Attribution Record"): ("attributed flow or asset amount x distributor hierarchy node x period", "Business Object", ""),
}
#  value = (grain, kind, parent)
#   grain  - what one row/instance represents, as a short noun phrase ("one row = <grain>"); use " x " for compound grains
#   kind   - "Business Object" (an independently identified record) or "Attribute Group" (fields that describe a parent object)
#   parent - for an Attribute Group, the Business Object it belongs to (may live in another family of the same domain); "" otherwise

# Attributes that hold a COPY of a value mastered in another Data Domain without being typed "Reference (...)",
# e.g. a party legal name or LEI copied onto a product party role. Value = owning Data Domain number.
DERIVED = {("Product Parties & Roles", "Product Party Role", "Party Legal Name"): "02"}

# Corrections to the automatic reference resolver (ownership.py): "" = mastered here; "NN" = reference to that Data Domain.
OWNERSHIP_OVERRIDES = {("Investment Strategy", "Investment Strategy", "Investment Team"): "09"}

# Optional (Step 5, CD-289; plan section 4 item 9): where one attribute holds rows mastered here and rows copied from or owned
# by another Data Domain, the rule that says which rows are which. Documentation only: the Ownership flag stays as declared
# (ownership.py never reads it). The builders show it in a "Row Ownership Rule" column (Taxonomy tab, enterprise workbook,
# Taxonomy Index). check_enrichment.py checks that each key is an attribute in the content module.
ROW_OWNERSHIP = {("Contract", "Contract", "Contract Status"):
                 "Row rule (CD-257): owner = domain of the typed link ...; mastered in 39 on untyped rows."}

# One sentence each, American spelling.
SUMMARY = {
  "masters": "Masters ... (what this Data Domain produces and maintains, and is accountable for)",
  "references": "References ... (what it uses from other Data Domains, naming them)",
}
```

Validate with `python check_enrichment.py NN`. It must print `OK` before you finish.
