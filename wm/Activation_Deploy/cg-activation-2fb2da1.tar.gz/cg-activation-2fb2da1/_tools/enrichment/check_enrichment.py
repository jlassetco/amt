"""Validates enrich_NN.py against its content module and prints the ownership review list.  Usage: python check_enrichment.py NN [--review]"""
import importlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); TOOLS = os.path.dirname(HERE)
sys.dont_write_bytecode = True
sys.path[:0] = [HERE, TOOLS, os.path.join(TOOLS, "content")]
import ownership as ow
n = sys.argv[1]; review = "--review" in sys.argv
# the content module: the one domains.py names for the Data Domain (content_<folder(n) lower-cased>), else the first match in
# sorted order, so the choice never depends on directory order; the run says which module it checked
import domains
cands = sorted(f[:-3] for f in os.listdir(os.path.join(TOOLS, "content")) if f.startswith(f"content_{n}_") and f.endswith(".py"))
if not cands:
    raise SystemExit(f"{n}: no content module content_{n}_*.py")
pref = f"content_{domains.folder(n).lower()}" if n in domains.DD_NAMES else ""
modname = pref if pref in cands else cands[0]
mod = importlib.import_module(modname)
print(f"{n}: checking {modname}.py against enrich_{n}.py"
      + (f" (other candidates ignored: {', '.join(c for c in cands if c != modname)})" if len(cands) > 1 else "")
      + ("" if modname == pref else f" (domains.py names {pref or 'no module'}; not found, first in sorted order used)"))
enr = importlib.import_module(f"enrich_{n}")
objs, attrs, errs = {}, set(), []
for dn, dc, dd, subs in mod.T:
    for sn, sd, cs in subs:
        for cn, al in cs:
            objs[(dn, cn)] = al
            for a in al: attrs.add((dn, cn, a[0]))
G = getattr(enr, "GRAIN", {}); names = {cn for _, cn in objs}
for k in objs:
    if k not in G: errs.append(f"GRAIN missing object {k}")
for k, v in G.items():
    if k not in objs: errs.append(f"GRAIN key is not an object in content: {k}")
    if not (isinstance(v, tuple) and len(v) == 3): errs.append(f"GRAIN value must be (grain, kind, parent): {k}"); continue
    g, kind, parent = v
    if not g or not g.strip(): errs.append(f"empty grain {k}")
    if g.lower().startswith("one row"): errs.append(f"grain should be the phrase only, without 'one row': {k}")
    if kind not in ("Business Object", "Attribute Group"): errs.append(f"bad kind {kind!r} at {k}")
    if kind == "Attribute Group" and parent not in names: errs.append(f"Attribute Group parent {parent!r} is not an object in this domain: {k}")
    if kind == "Business Object" and parent: errs.append(f"Business Object must have empty parent: {k}")
from domains import DD_NAMES
VALID = set(DD_NAMES)
for name in ("DERIVED", "OWNERSHIP_OVERRIDES"):
    for k, v in getattr(enr, name, {}).items():
        if k not in attrs: errs.append(f"{name} key is not an attribute in content: {k}")
        if not (v in VALID or (name == "OWNERSHIP_OVERRIDES" and v == "")): errs.append(f"{name} bad domain {v!r} at {k}")
        if name == "DERIVED" and v == n: errs.append(f"DERIVED must point to another domain: {k}")
for k, v in getattr(enr, "ROW_OWNERSHIP", {}).items():   # optional (CD-289): rule text only; the flag stays as declared
    if k not in attrs: errs.append(f"ROW_OWNERSHIP key is not an attribute in content: {k}")
    if not (isinstance(v, str) and v.strip()): errs.append(f"ROW_OWNERSHIP rule must be non-empty text: {k}")
S = getattr(enr, "SUMMARY", {})
if not S.get("masters", "").startswith("Masters") or not S.get("references", "").startswith("References"):
    errs.append("SUMMARY needs 'masters' starting 'Masters' and 'references' starting 'References'")
unres = []
for (dn, cn), al in objs.items():
    for a in al:
        fl, o = ow.resolve(n, dn, cn, a, enr)
        if fl.startswith("Unresolved"): unres.append((dn, cn, a[0], a[3]))
        if review and fl in ("Reference", "Derived copy"): print(f"  {fl:13} -> {o}  {dn} / {cn} / {a[0]}  [{a[3]}] e.g. {a[5]}")
for u in unres: errs.append(f"unresolved reference, add an OWNERSHIP_OVERRIDES entry: {u}")
kinds = [v[1] for v in G.values() if isinstance(v, tuple) and len(v) == 3]
print(f"{n}: {len(objs)} objects ({kinds.count('Business Object')} business objects, {kinds.count('Attribute Group')} attribute groups), "
      f"{len(getattr(enr, 'DERIVED', {}))} derived copies, {len(getattr(enr, 'OWNERSHIP_OVERRIDES', {}))} overrides"
      + (f", {len(getattr(enr, 'ROW_OWNERSHIP', {}))} row ownership rules" if getattr(enr, 'ROW_OWNERSHIP', None) else ""))
print("OK" if not errs else "ERRORS:\n  " + "\n  ".join(errs[:60]))
sys.exit(1 if errs else 0)
