"""Enrichment for Data Domain 01 - Investment Product & Service Offering (wealth manager; contract v0.4): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Investment Strategy
    ("Investment Strategy", "Investment Strategy"): ("investment strategy", BO, ""),
    ("Investment Strategy", "Strategy Classification"): ("investment strategy", AG, "Investment Strategy"),
    ("Investment Strategy", "GIPS Composite"): ("GIPS composite", BO, ""),
    # Product & Vehicle
    ("Product & Vehicle", "Investment Product"): ("investment product (fund, sub-fund, ETF, CIT or other pooled vehicle)", BO, ""),
    ("Product & Vehicle", "Fund Legal Structure"): ("investment product", AG, "Investment Product"),
    ("Product & Vehicle", "Investment Mandate"): ("investment mandate (institutional separate account or sponsor-program strategy)", BO, ""),
    ("Product & Vehicle", "Model Portfolio"): ("model portfolio", BO, ""),
    ("Product & Vehicle", "Product Relationship"): ("source product x target product x relationship type x effective period", BO, ""),
    # Share Class
    ("Share Class", "Share Class"): ("share class", BO, ""),
    ("Share Class", "Currency Hedging"): ("share class", AG, "Share Class"),
    ("Share Class", "Income Distribution"): ("share class", AG, "Share Class"),
    ("Share Class", "Investor Eligibility"): ("share class", AG, "Share Class"),
    # Identifiers & Cross-References
    ("Identifiers & Cross-References", "Security Identifier"): ("share class", AG, "Share Class"),
    ("Identifiers & Cross-References", "Regulatory Filing Identifier"): ("share class", AG, "Share Class"),
    ("Identifiers & Cross-References", "External Cross-Reference"): ("share class", AG, "Share Class"),
    ("Identifiers & Cross-References", "System Cross-Reference"): ("product or share class x source system x effective period", BO, ""),
    # Product Classification
    ("Product Classification", "Firm Product Classification"): ("investment product", AG, "Investment Product"),
    ("Product Classification", "External Classification"): ("share class", AG, "Share Class"),
    ("Product Classification", "Regulatory Classification"): ("investment product", AG, "Investment Product"),
    ("Product Classification", "ESG Classification"): ("investment product", AG, "Investment Product"),
    # Investment Policy & Risk
    ("Investment Policy & Risk", "Investment Objective & Policy"): ("investment product", AG, "Investment Product"),
    ("Investment Policy & Risk", "Investment Restriction"): ("investment restriction on a product or mandate", BO, ""),
    ("Investment Policy & Risk", "Product Risk Indicator"): ("share class", AG, "Share Class"),
    # Benchmark & Performance Reference
    ("Benchmark & Performance Reference", "Benchmark"): ("benchmark (single or blended index)", BO, ""),
    ("Benchmark & Performance Reference", "Product Benchmark Assignment"): ("product or share class x benchmark x benchmark role x effective period", BO, ""),
    ("Benchmark & Performance Reference", "Performance Track Record"): ("share class", AG, "Share Class"),
    # Fees, Charges & Costs
    ("Fees, Charges & Costs", "Management Fee"): ("share class", AG, "Share Class"),
    ("Fees, Charges & Costs", "Other Ongoing Fees"): ("share class", AG, "Share Class"),
    ("Fees, Charges & Costs", "Performance Fee"): ("share class", AG, "Share Class"),
    ("Fees, Charges & Costs", "Investor Transaction Charge"): ("share class", AG, "Share Class"),
    ("Fees, Charges & Costs", "Cost Disclosure"): ("share class x cost reference date", BO, ""),
    # Dealing, Valuation & Listing
    ("Dealing, Valuation & Listing", "Dealing Terms"): ("investment product", AG, "Investment Product"),
    ("Dealing, Valuation & Listing", "Valuation Terms"): ("investment product", AG, "Investment Product"),
    ("Dealing, Valuation & Listing", "Listing"): ("share class x listing exchange", BO, ""),
    ("Dealing, Valuation & Listing", "ETF Characteristics"): ("investment product (ETF)", AG, "Investment Product"),
    # Product Parties & Roles
    ("Product Parties & Roles", "Product Party Role"): ("product x party x party role type x effective period", BO, ""),
    ("Product Parties & Roles", "Portfolio Manager Assignment"): ("product or mandate x portfolio manager x effective period", BO, ""),
    # Distribution & Registration
    ("Distribution & Registration", "Distribution Availability"): ("share class", AG, "Share Class"),
    # Regulatory, Tax & Disclosure
    ("Regulatory, Tax & Disclosure", "Regulatory Authorization"): ("investment product", AG, "Investment Product"),
    ("Regulatory, Tax & Disclosure", "Product Document"): ("product or share class x document type x language x jurisdiction x version date", BO, ""),
    ("Regulatory, Tax & Disclosure", "Product Tax Status"): ("investment product", AG, "Investment Product"),
    # Investment Commentary
    ("Investment Commentary", "Investment Commentary"): ("commentary (one subject x period x language)", BO, ""),
    ("Investment Commentary", "Commentary Approval"): ("commentary", AG, "Investment Commentary"),
    # Lifecycle & Governance
    ("Lifecycle & Governance", "Lifecycle Event"): ("product, share class or service offering x lifecycle event type x event effective date", BO, ""),
    ("Lifecycle & Governance", "Product Governance"): ("investment product", AG, "Investment Product"),
    # Advice & Service Offerings (CW-036, CW-028)
    ("Advice & Service Offerings", "Service Offering"): ("service offering", BO, ""),
    ("Advice & Service Offerings", "Offering Feature"): ("service offering x offering feature type", AG, "Service Offering"),
    ("Advice & Service Offerings", "Offering Eligibility Rule"): ("eligibility rule of a service offering", BO, ""),
    ("Advice & Service Offerings", "Offering Fee Schedule Link"): ("service offering x 47 fee schedule x link effective period", BO, ""),
    ("Advice & Service Offerings", "Service Tier"): ("service tier", BO, ""),
    # Brokerage Platform Offering (CW-037)
    ("Brokerage Platform Offering", "Tradable Universe Policy Rule"): ("tradable-universe or trading-feature policy rule", BO, ""),
    ("Brokerage Platform Offering", "Platform Product Availability"): ("own share class or third-party instrument x availability effective date", BO, ""),
    ("Brokerage Platform Offering", "Platform Feature"): ("platform feature (15 Feature Type) x feature effective date", BO, ""),
    # Alternative Investment Access (CW-038)
    ("Alternative Investment Access", "Feeder Access Terms"): ("investment product (feeder, tender-offer or interval fund); underlying fund instrument only for a feeder fund", AG, "Investment Product"),
    ("Alternative Investment Access", "Offering Window"): ("offering window of a feeder product", BO, ""),
}

DERIVED = {
    # CD-028: copied from the 02 party master; display only
    ("Product Parties & Roles", "Product Party Role", "Party Legal Name"): "02",
    ("Product Parties & Roles", "Product Party Role", "Party LEI"): "02",
    # CD-025: derived from the linked 13 shareholder communication once the notice is issued
    ("Lifecycle & Governance", "Lifecycle Event", "Investor Notice Date"): "13",
    # CD-218 option A (Stage 3): roll-up of 32 Composite Membership through 18 Portfolio Implementation Link
    ("Investment Strategy", "GIPS Composite", "Composite Member"): "32",
}

OWNERSHIP_OVERRIDES = {
    # Investment team is an internal org unit (OU-)
    ("Investment Strategy", "Investment Strategy", "Investment Team"): "09",
    # Own portfolio managers are employees (CD-122); EMP- is mastered in 20 Human Capital (CD-151)
    ("Investment Strategy", "Investment Strategy", "Lead Portfolio Manager"): "20",
    ("Product Parties & Roles", "Portfolio Manager Assignment", "Portfolio Manager"): "20",
    # Group boutiques are internal legal entities (LEN-, CD-010)
    ("Investment Strategy", "Investment Strategy", "Investment Affiliate / Boutique"): "09",
    # Fee tiers belong to the 01 fee schedule (FSCH-, CD-023)
    ("Fees, Charges & Costs", "Management Fee", "Fee Breakpoint Schedule"): "",
    # Platform availability is shelf placement status mastered in 05
    ("Distribution & Registration", "Distribution Availability", "Platform Availability"): "05",
    # Product owner is an internal employee (EMP-, 20 Human Capital, CD-151)
    ("Lifecycle & Governance", "Product Governance", "Product Owner"): "20",
    # Governing body is the fund board or the CIT trustee's committee, an internal legal entity (LEN-)
    ("Lifecycle & Governance", "Product Governance", "Governing Body"): "09",
}

ROW_OWNERSHIP = {
    ("Product & Vehicle", "Model Portfolio", "Model Sponsor / Platform"):
        "Row rule (W5, proposals_w4_05 READERS): filled with the 05 Distributor Firm (PTY- key) when the model is delivered to an "
        "intermediary platform or sponsor (IC line); blank when the model serves only the firm's own advice programs (46 Model "
        "Assignment); the sponsor program placement itself is 05 Model Program Placement.",
    ("Brokerage Platform Offering", "Platform Product Availability", "Available Share Class"):
        "Row rule (CW-037): each row is for either an own share class (this attribute, mastered here) or a third-party "
        "fund or ETF (Available Third-Party Instrument, 17 INS-); exactly one of the two is filled.",
}

SUMMARY = {
    "masters": "Masters the firm's investment product reference data: investment strategies and GIPS composites, products and "
               "vehicles (funds, ETFs, CITs, feeder funds, institutional mandates, model portfolios), share classes and their features, product identifiers and "
               "classifications (including the Morningstar category of own share classes), investment policy and restrictions, "
               "benchmarks and benchmark assignments, prospectus fee and expense terms (FSCH-; client fees are 47), dealing, valuation and listing terms, product "
               "party roles, US channel availability, product documents, tax status, market and investment commentary, "
               "lifecycle events and product governance; and the firm's service offerings (advice programs, planning, "
               "brokerage, trust, workplace managed accounts, OCIO) with their features, eligibility rules and fee "
               "schedule links, service tiers, the brokerage platform's tradable-universe policy rules and product "
               "availability, and the access terms and offering windows of feeder funds.",
    "references": "References external parties (mandate clients, service providers, model sponsors, placement agents, "
                  "benchmark administrators and regulators) from Client & Household (02), employees acting as portfolio "
                  "managers and product owners from Human Capital (20), intermediary platform shelf placement from "
                  "Intermediary & Institutional Distribution (05), dealing calendars, internal legal entities (offering sponsors) and "
                  "investment-team org units from Shared & Enterprise Reference Data (09), shareholder notices from Client "
                  "Service & Communications (13), third-party and underlying fund instruments from Instrument & "
                  "Issuer Reference (17), client fee schedules from Pricing, Fees & Billing (47) and third-party product "
                  "due diligence from External Manager & Sub-Adviser Oversight (52).",
}
