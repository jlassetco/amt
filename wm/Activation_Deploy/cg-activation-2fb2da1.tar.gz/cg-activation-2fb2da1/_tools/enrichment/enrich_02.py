"""Enrichment for Data Domain 02 - Client & Household (wealth-manager model, W1; contract v0.4): grain, ownership flags, summary.

Rewritten in place for content_02_client_and_household.py (CW-005, CW-021). The wholesale enrichment stays at tag wholesale-v1.0.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Party Master
    ("Party Master", "Party"): ("party (one real-world external individual, Client Household or entity; PTY-, households PTY-HH-)", BO, ""),
    ("Party Master", "Individual"): ("party (individual)", AG, "Party"),
    ("Party Master", "Organization"): ("party (entity)", AG, "Party"),
    ("Party Master", "Legal Entity Hierarchy"): ("subsidiary party x direct parent party x relationship basis x effective period", BO, ""),
    ("Party Master", "Party Role"): ("party x role type x role effective period", BO, ""),
    ("Party Master", "Retirement Plan"): ("party (retirement plan; sponsor EIN x plan number)", AG, "Party"),
    # Party Identifiers
    ("Party Identifiers", "Party Identifier"): ("party x identifier scheme x identifier value x effective period", BO, ""),
    ("Party Identifiers", "LEI Record"): ("party identifier (LEI scheme)", AG, "Party Identifier"),
    ("Party Identifiers", "US Regulatory Identifier"): ("party (US regulatory identifiers)", AG, "Party"),
    ("Party Identifiers", "Market Infrastructure & Vendor Identifier"): ("party (market infrastructure and vendor identifiers)", AG, "Party"),
    # Households & Relationships
    ("Households & Relationships", "Household"): ("party (Client Household, PTY-HH-)", AG, "Party"),
    ("Households & Relationships", "Household Membership"): ("Client Household x member party x membership effective period", BO, ""),
    ("Households & Relationships", "Party Relationship"): ("from party x to party x relationship type x effective period", BO, ""),
    # Authorized Persons & Life Events
    ("Authorized Persons & Life Events", "Authority Grant"): ("grantor party x authority holder x authority type x grant period (AGNT-)", BO, ""),
    ("Authorized Persons & Life Events", "Trusted Contact Designation"): ("client x trusted contact person x designation period (TCNT-)", BO, ""),
    ("Authorized Persons & Life Events", "Death Notification"): ("death notification (deceased party x notification received; DTHN-)", BO, ""),
    # Investor Profile
    ("Investor Profile", "Investor Profile"): ("client x investor profile version (INPR-)", BO, ""),
    ("Investor Profile", "Investment Experience"): ("investor profile version x product experience type", BO, ""),
    ("Investor Profile", "Investor Qualification"): ("party x qualification standard (latest determination; keyed by PTY- and the standard)", AG, "Party"),
    # KYC, Identity & Tax
    ("KYC, Identity & Tax", "Onboarding Case"): ("onboarding or review case (ONB-)", BO, ""),
    ("KYC, Identity & Tax", "KYC Profile"): ("party (current due diligence state)", AG, "Party"),
    ("KYC, Identity & Tax", "Identity Verification"): ("party x CIP program x verification (KYCV-)", BO, ""),
    ("KYC, Identity & Tax", "Beneficial Ownership Certification"): ("legal entity customer x certification (BOWN-)", BO, ""),
    ("KYC, Identity & Tax", "Beneficial Ownership"): ("beneficial ownership certification x beneficial owner x prong", BO, ""),
    ("KYC, Identity & Tax", "Tax Profile"): ("party (US tax status)", AG, "Party"),
    # Classification & Segmentation
    ("Classification & Segmentation", "Regulatory Classification"): ("party x categorization date", BO, ""),
    ("Classification & Segmentation", "Segment Assignment"): ("party or Client Household x segmentation scheme x segment effective period", BO, ""),
    ("Classification & Segmentation", "Service Tier Assignment"): ("Client Household or party x service tier x tier effective period", BO, ""),
    # Contact Points & Preferences
    ("Contact Points & Preferences", "Contact Point"): ("party x contact channel x value x usage x effective period (CTP-)", BO, ""),
    ("Contact Points & Preferences", "Postal Address"): ("contact point (postal address)", AG, "Contact Point"),
    ("Contact Points & Preferences", "Contact Preference"): ("party x preference effective period", BO, ""),
    ("Contact Points & Preferences", "Communication Preference"): ("party x subscription topic x channel", BO, ""),
    # Privacy & Consent
    ("Privacy & Consent", "Privacy Profile"): ("party (privacy regimes and opt-outs)", AG, "Party"),
    ("Privacy & Consent", "Consent Record"): ("party x consent purpose x capture event (CNS-)", BO, ""),
    ("Privacy & Consent", "Consumer Privacy Request"): ("party x privacy request received", BO, ""),
    # Restrictions & Protections
    ("Restrictions & Protections", "Client Restriction"): ("client restriction (party x restriction category x effective period; CRX-)", BO, ""),
    ("Restrictions & Protections", "Restricted Client Status"): ("party x status effective period", BO, ""),
    ("Restrictions & Protections", "Specified Adult Status"): ("party x specified adult basis x effective period (FINRA Rule 2165)", AG, "Party"),
    ("Restrictions & Protections", "Vulnerability Concern"): ("vulnerability concern (party x concern raised; VCON-)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Classification & Segmentation", "Service Tier Assignment", "Qualifying Client Assets"): "06",     # future owner 06, W4
    ("Classification & Segmentation", "Service Tier Assignment", "Qualifying Assets As-Of Date"): "06",
    ("Restrictions & Protections", "Vulnerability Concern", "Agency Referral Date"): "08",   # earliest 08 External Protection Report (CW-071)
    ("Contact Points & Preferences", "Postal Address", "Mail Returned Date"): "13",          # 13 Recipient Delivery Record (CW-089)
}

OWNERSHIP_OVERRIDES = {}

# CD-289 row rule: which rows are mastered here and which are copies.
ROW_OWNERSHIP = {
    ("Households & Relationships", "Party Relationship", "Relationship Type"):
        "Row rule (CW-075, CD-289): for a trust with a 51 Trust record, 'Trustee Of' rows are Derived from 51 Trust Role (Trust Role Type "
        "Trustee, Co-Trustee, Directed Trustee or a serving Successor Trustee with Role Effective From set), 'Grantor Of' rows from Trust "
        "Role Type Grantor / Settlor and 'Trust Beneficiary Of' rows from current 51 Beneficial Interest rows; only rows whose holder is a 02 "
        "party (Role Holder Party) derive a 02 row, and rows held by the trust company (09 internal legal entity) derive nothing. Mastered "
        "in 02 on every other row, including trust relationships of trusts without a 51 record.",
    ("KYC, Identity & Tax", "Identity Verification", "Verification Result"):
        "Row rule (CW-025): mastered in 02 on every row. Until the W3 re-cut of 29 CIP Verification (CIP-), rows of CIP Program "
        "'Mutual Fund CIP' for legacy fund-direct accounts may also exist as 29 records; from W3 29 references KYCV- and holds no result.",
    ("Party Master", "Retirement Plan", "Sponsor EIN"):
        "Row rule: on every row the value is the plan sponsor party's US Regulatory Identifier 'Employer Identification Number' "
        "(both in 02); it is carried on the plan only as part of the Form 5500 plan key (EIN + plan number).",
}

SUMMARY = {
    "masters": (
        "Masters the client master of the wealth manager and the party core for every external party: parties, individuals, "
        "organizations, legal entity hierarchy, party roles, a thin retirement plan identity and party identifiers (LEI, CRD, SEC, "
        "NSCC, DTC); Client Households and their membership and party relationships; authority grants, trusted contact designations "
        "and death notifications; the versioned investor profile, investment experience and investor qualification; onboarding cases, "
        "KYC profiles, identity verification for every CIP program, beneficial ownership certifications and owners, and the tax "
        "profile; regulatory classification, segment and service tier assignment; contact points, postal addresses, contact and "
        "communication preferences; privacy profiles, consent records and consumer privacy requests; client restrictions, restricted "
        "client status, specified adult status and vulnerability concerns."
    ),
    "references": (
        "References accounts, account restrictions and account tax certifications from 15 Account; service tiers from 01 Investment "
        "Product & Service Offering; qualifying client assets from 06 (Derived copy, future owner at W4); service requests and "
        "shareholder communications from 13; subscription topics from 04; internal legal entities from 09 Shared & Enterprise "
        "Reference Data; employees from 20 Human Capital; instruments from 17 Instrument & Issuer Reference; AML cases from 38; "
        "senior investor cases and the agency referral date from 08; returned mail dates from 13 (Derived copy); and trust roles and "
        "beneficial interests from 51 (Derived relationship rows)."
    ),
}
