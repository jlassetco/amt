"""Enrichment for Data Domain 03 - Advisor Organization, Coverage & Supervision (wealth-manager model, W2; contract v0.4):
grain, ownership flags, summary.

Rewritten in place for content_03_advisor_organization_coverage_and_supervision.py (CW-013, CW-061 to CW-065). The wholesale
enrichment for content_03_sales.py stays at tag wholesale-v1.0.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Advisors & Teams
    ("Advisors & Teams", "Advisor"): ("employee as advisor (profile of the 20 employee, keyed by EMP-)", BO, ""),
    ("Advisors & Teams", "Advisor Role Assignment"): ("advisor x advisor role x role effective period", BO, ""),
    ("Advisors & Teams", "Advisor Credential"): ("advisor x credential type x credential period", BO, ""),
    ("Advisors & Teams", "License & Registration Reference"): ("advisor (registration summary copied from 08)", AG, "Advisor"),
    ("Advisors & Teams", "Coverage Team"): ("coverage team (SLT-)", BO, ""),
    ("Advisors & Teams", "Coverage Team Membership"): ("coverage team x advisor x membership role x membership effective period", BO, ""),
    # Branches & Supervisory Structure
    ("Branches & Supervisory Structure", "Firm Branch Office"): ("office as branch x designation period (profile of the 09 Office Location; key SITE- + Branch Designation Effective From, one row per designation)", BO, ""),
    ("Branches & Supervisory Structure", "Supervisory Hierarchy Link"): ("child supervisory unit x parent supervisory unit x link effective period", BO, ""),
    ("Branches & Supervisory Structure", "Principal Designation"): ("principal x designation type x office or function scope x designation effective period", BO, ""),
    ("Branches & Supervisory Structure", "Supervisory Assignment"): ("supervised person x supervisor x assignment type x assignment effective period", BO, ""),
    # Coverage & Service Models
    ("Coverage & Service Models", "Coverage Model"): ("coverage model code", BO, ""),
    ("Coverage & Service Models", "Call Frequency Standard"): ("coverage model x service tier x contact type x standard effective period", BO, ""),
    ("Coverage & Service Models", "Coverage Assignment Rule"): ("coverage assignment rule (ASRL-)", BO, ""),
    ("Coverage & Service Models", "Coverage Assignment Rule Criterion"): ("coverage assignment rule x criterion sequence", AG, "Coverage Assignment Rule"),
    # Client Assignment & Capacity
    ("Client Assignment & Capacity", "Party Coverage Assignment"): ("covered party or household x advisor or coverage team x coverage role x coverage period (CVA-)", BO, ""),
    ("Client Assignment & Capacity", "Coverage Reassignment"): ("coverage reassignment event (REAS-)", BO, ""),
    ("Client Assignment & Capacity", "Coverage Reassignment Item"): ("coverage reassignment event x reassigned household", AG, "Coverage Reassignment"),
    ("Client Assignment & Capacity", "Advisor Capacity Snapshot"): ("advisor or coverage team x capacity as-of date", BO, ""),
    # Advisor Activities & Interactions
    ("Advisor Activities & Interactions", "Advisor Activity"): ("advisor activity (ACT-)", BO, ""),
    ("Advisor Activities & Interactions", "Internal Participant"): ("advisor activity x internal participant employee", AG, "Advisor Activity"),
    ("Advisor Activities & Interactions", "External Participant"): ("advisor activity x external participant (matched party or unmatched attendee)", AG, "Advisor Activity"),
    ("Advisor Activities & Interactions", "Discussion Content"): ("advisor activity (content)", AG, "Advisor Activity"),
    ("Advisor Activities & Interactions", "Outcome & Follow-Up"): ("advisor activity (outcome)", AG, "Advisor Activity"),
    ("Advisor Activities & Interactions", "Activity Capture"): ("advisor activity (capture and record-keeping)", AG, "Advisor Activity"),
    # Channel Referrals
    ("Channel Referrals", "Channel Referral"): ("channel referral (RFRL-)", BO, ""),
    ("Channel Referrals", "Referral Status History"): ("channel referral x status x status change timestamp", AG, "Channel Referral"),
    # Incentive & Recognition
    ("Incentive & Recognition", "Incentive Compensation Plan"): ("incentive compensation plan (ICP-)", BO, ""),
    ("Incentive & Recognition", "Incentive Plan Component"): ("incentive compensation plan x component (ICP-n-Cnn)", BO, ""),
    ("Incentive & Recognition", "Incentive Plan Participation"): ("advisor x incentive compensation plan x participation period", BO, ""),
    ("Incentive & Recognition", "Compensation Statement"): ("advisor x statement period (CPS-)", BO, ""),
    ("Incentive & Recognition", "Incentive Earnings Line"): ("compensation statement x plan component", AG, "Compensation Statement"),
    ("Incentive & Recognition", "Recognition Award"): ("recognition award (RECG-)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Advisors & Teams", "License & Registration Reference", "Registered Representative Indicator"): "08",
    ("Advisors & Teams", "License & Registration Reference", "Investment Adviser Representative Indicator"): "08",
    ("Advisors & Teams", "License & Registration Reference", "Registered States"): "08",
    ("Advisors & Teams", "License & Registration Reference", "Individual CRD Number"): "08",
    ("Client Assignment & Capacity", "Advisor Capacity Snapshot", "Assigned Client Count"): "02",
    ("Client Assignment & Capacity", "Advisor Capacity Snapshot", "Assigned Account Count"): "15",
    ("Client Assignment & Capacity", "Advisor Capacity Snapshot", "Book Client Assets"): "06",   # future owner 06, W4
}

# Corrections to the automatic resolver. CVA- and ICP- are still registered to 07 in decisions.PREFIXES until the W2 merge
# moves them to 03 (CW-062, CW-080): references to this domain's own objects are forced "mastered here". Composite keys
# that start with another domain's prefix are forced to the owner of the referenced object.
OWNERSHIP_OVERRIDES = {
    # Reference (Advisor): the EMP- key resolves to 20 by prefix, but the referenced object is this domain's Advisor profile
    # (CD-144); references to staff who need not be advisors stay Reference (Employee) and resolve to 20.
    ("Advisors & Teams", "Advisor Role Assignment", "Role Advisor"): "",
    ("Advisors & Teams", "Advisor Credential", "Credential Holder"): "",
    ("Advisors & Teams", "Coverage Team", "Lead Advisor"): "",
    ("Advisors & Teams", "Coverage Team Membership", "Member Advisor"): "",
    ("Coverage & Service Models", "Coverage Assignment Rule", "Target Advisor"): "",
    ("Client Assignment & Capacity", "Party Coverage Assignment", "Covering Advisor"): "",
    ("Client Assignment & Capacity", "Coverage Reassignment", "From Advisor"): "",
    ("Client Assignment & Capacity", "Coverage Reassignment", "To Advisor"): "",
    ("Client Assignment & Capacity", "Advisor Capacity Snapshot", "Capacity Subject Advisor"): "",
    ("Channel Referrals", "Channel Referral", "Target Advisor"): "",
    ("Incentive & Recognition", "Incentive Plan Participation", "Plan Participant"): "",
    ("Incentive & Recognition", "Compensation Statement", "Statement Participant"): "",
    ("Incentive & Recognition", "Recognition Award", "Award Recipient"): "",
}

# CD-289 row rules.
ROW_OWNERSHIP = {
    ("Client Assignment & Capacity", "Party Coverage Assignment", "Primary Coverage Indicator"):
        "Row rule (CW-063): mastered in 03 on every row. At most one primary row per scope per date (household, client, or account "
        "where Covered Account is filled). The advisor of record for an account on a date, read by 06 attribution, 47 billing and "
        "45 engagements, resolves at account scope first, then client, then household; no other domain holds a copy.",
    ("Branches & Supervisory Structure", "Supervisory Assignment", "Assigned Supervisor"):
        "Row rule (program-lead ruling, W2 review): mastered in 03 on every row, including rows of type Heightened Supervision "
        "Supervisor; 08 Heightened Supervision Plan holds the plan's supervisor as a Derived copy of those rows.",
}

SUMMARY = {
    "masters": (
        "Masters the advice organization of the wealth manager: the advisor profile of each 20 employee who advises or services "
        "clients (roles, credentials, languages, specialties, entities represented), coverage teams and their memberships, the "
        "broker-dealer's branch offices and OSJs as profiles of 09 offices with the supervisory hierarchy, principal designations "
        "and the assignment of every registered person to a supervisor (FINRA Rule 3110), coverage models, contact standards and "
        "assignment rules, Party Coverage Assignment as the one advisor-of-record master with its reassignments and capacity "
        "snapshots, advisor activities with clients and their participants, content, outcomes and capture, channel referrals, and "
        "incentive compensation plans, components, participation, compensation statements and recognition awards in reduced form."
    ),
    "references": (
        "References employees, job profiles and payroll results from 20 Human Capital; offices, org units, internal legal entities "
        "and geographic groups from 09; parties and Client Households from 02 Client & Household; accounts and program enrollments "
        "from 15 Account; service tiers, service offerings and investment products from 01; individual and branch registrations, "
        "heightened supervision plans, captured communications, gifts, complaints and incentive conflict reviews from 08 Retail "
        "Conduct & Supervision; advice engagements, advice reviews and recommendations from 45; service requests and recipient "
        "delivery records from 13; campaigns, content assets and marketing leads from 04; trusts from 51; and holds Derived copies "
        "of registration status (08), client and account counts (02, 15) and book client assets (06, future owner at W4)."
    ),
}
