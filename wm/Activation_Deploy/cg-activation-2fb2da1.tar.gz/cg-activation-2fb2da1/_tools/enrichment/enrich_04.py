"""Enrichment for Data Domain 04 - Marketing, Digital & Client Engagement (wealth-manager model, W2; contract v0.4): grain,
derived copies, ownership overrides, row rules and summary.

Rewritten in place for the adapted content_04_marketing_and_digital.py (CW-001, CW-904). The wholesale enrichment stays at
tag wholesale-v1.0.
"""

B, A = "Business Object", "Attribute Group"

GRAIN = {
    # Brand & Messaging
    ("Brand & Messaging", "Marketing Theme"): ("marketing theme (THM-)", B, ""),
    ("Brand & Messaging", "Messaging Pillar"): ("marketing theme x key message", A, "Marketing Theme"),
    # Campaign Management
    ("Campaign Management", "Campaign"): ("campaign node (program, campaign, wave or tactic; CAM-)", B, ""),
    ("Campaign Management", "Campaign Targeting"): ("campaign", A, "Campaign"),
    ("Campaign Management", "Campaign Product"): ("campaign x product, share class or service offering", A, "Campaign"),
    ("Campaign Management", "Campaign Budget"): ("campaign x budget currency", A, "Campaign"),
    ("Campaign Management", "Spend Line"): ("campaign x spend category x spend line", A, "Campaign"),
    ("Campaign Management", "Campaign Tracking Code"): ("campaign x tracked URL (UTM parameter combination)", A, "Campaign"),
    ("Campaign Management", "Campaign Member"): ("campaign x member party or lead", B, ""),
    # Content & Digital Assets
    ("Content & Digital Assets", "Content Asset"): ("content asset (AST-)", B, ""),
    ("Content & Digital Assets", "Audience Restriction"): ("content asset", A, "Content Asset"),
    ("Content & Digital Assets", "Asset Classification"): ("content asset", A, "Content Asset"),
    ("Content & Digital Assets", "Asset Version"): ("content asset x version", B, ""),
    ("Content & Digital Assets", "Asset Compliance Reference"): ("content asset version x compliance review", A, "Asset Version"),
    ("Content & Digital Assets", "Asset Rights"): ("content asset x rights grant (licensed component)", A, "Content Asset"),
    ("Content & Digital Assets", "Asset Accessibility & Rendition"): ("content asset x rendition", A, "Content Asset"),
    # Client Events & Webinars
    ("Client Events & Webinars", "Marketing Event"): ("marketing event (EVT-)", B, ""),
    ("Client Events & Webinars", "Event Session"): ("marketing event x session", B, ""),
    ("Client Events & Webinars", "Event Speaker"): ("event session x speaker (employee or external party)", A, "Event Session"),
    ("Client Events & Webinars", "Event Registration"): ("marketing event x registrant", B, ""),
    # Digital Properties & Martech
    ("Digital Properties & Martech", "Digital Property"): ("digital property (website, client website or app; WEB-)", B, ""),
    ("Digital Properties & Martech", "Web Page"): ("web page URL", B, ""),
    ("Digital Properties & Martech", "Web Form"): ("web form (FRM-)", B, ""),
    ("Digital Properties & Martech", "Marketing System"): ("marketing system (profile of a 41 application)", B, ""),
    # Digital Identity & Engagement
    ("Digital Identity & Engagement", "Web Visitor / Known User"): ("visitor identifier x identity namespace (VIS-)", B, ""),
    ("Digital Identity & Engagement", "Digital Profile"): ("party x online login profile (DIGP-)", B, ""),
    ("Digital Identity & Engagement", "Tracking Consent Choice"): ("visitor x tracking choice x choice timestamp", B, ""),
    ("Digital Identity & Engagement", "Session"): ("web or app session", B, ""),
    ("Digital Identity & Engagement", "Engagement Event"): ("visitor or party x engagement event type x event timestamp", B, ""),
    ("Digital Identity & Engagement", "Email Send"): ("email deployment (one send of a template)", B, ""),
    ("Digital Identity & Engagement", "Email Interaction"): ("email recipient x deployment", B, ""),
    ("Digital Identity & Engagement", "Media Engagement"): ("media view engagement event (viewer x video, webcast or podcast asset x view)", A, "Engagement Event"),
    ("Digital Identity & Engagement", "Engagement Score"): ("party x engagement score model x score as-of date", B, ""),
    # Audiences, Subscriptions & Suppression
    ("Audiences, Subscriptions & Suppression", "Marketing Segment"): ("marketing audience (SEG-)", B, ""),
    ("Audiences, Subscriptions & Suppression", "Segment Membership"): ("party x marketing segment x effective period", B, ""),
    ("Audiences, Subscriptions & Suppression", "Subscription Topic"): ("subscription topic (SUB-)", B, ""),
    ("Audiences, Subscriptions & Suppression", "Suppression Entry"): ("suppressed identifier (hashed email or phone) x suppression reason x scope x effective period", B, ""),
    # Leads & Acquisition Funnel
    ("Leads & Acquisition Funnel", "Marketing Lead"): ("marketing lead (LEAD-)", B, ""),
    ("Leads & Acquisition Funnel", "Lead Qualification"): ("marketing lead (current qualification)", A, "Marketing Lead"),
    ("Leads & Acquisition Funnel", "Lead Assignment"): ("marketing lead x assignment to an advisor or coverage team", A, "Marketing Lead"),
    ("Leads & Acquisition Funnel", "Lead Conversion"): ("marketing lead (conversion outcome)", A, "Marketing Lead"),
    ("Leads & Acquisition Funnel", "Application Journey"): ("applicant party x journey type x journey start (JRNY-)", B, ""),
    ("Leads & Acquisition Funnel", "Acquisition Milestone"): ("party x acquisition milestone type x milestone date (account where applicable)", B, ""),
    # Personalization & Experiments
    ("Personalization & Experiments", "Nudge Definition"): ("nudge x version (NUDG-)", B, ""),
    ("Personalization & Experiments", "Nudge Delivery"): ("nudge x party x delivered timestamp", B, ""),
    ("Personalization & Experiments", "Experiment"): ("experiment (EXPMT-)", B, ""),
    ("Personalization & Experiments", "Experiment Assignment"): ("experiment x visitor or party", B, ""),
    # Referrals, Promotions & Voice of Client
    ("Referrals, Promotions & Voice of Client", "Promotion Offer"): ("promotion offer (PROMO-)", B, ""),
    ("Referrals, Promotions & Voice of Client", "Promotion Enrollment"): ("promotion offer x party (x account)", B, ""),
    ("Referrals, Promotions & Voice of Client", "Client Referral"): ("referrer x referee x referral code (CRFL-)", B, ""),
    ("Referrals, Promotions & Voice of Client", "Client Survey"): ("client survey (CSVY-)", B, ""),
    ("Referrals, Promotions & Voice of Client", "Survey Response"): ("survey x respondent x response (SRSP-)", B, ""),
    # Social & Paid Media
    ("Social & Paid Media", "Social Media Account"): ("social media account (platform x handle; SOC-)", B, ""),
    ("Social & Paid Media", "Social Post"): ("social post (platform post)", B, ""),
    ("Social & Paid Media", "Social Engagement Metrics"): ("social post x metrics as-of date", A, "Social Post"),
    ("Social & Paid Media", "Social Listening Mention"): ("third-party social mention", B, ""),
    ("Social & Paid Media", "Media Placement"): ("paid media placement (PLC-)", B, ""),
    ("Social & Paid Media", "Paid Media Delivery"): ("media placement x delivery date", A, "Media Placement"),
    # Performance & Attribution
    ("Performance & Attribution", "Marketing Touchpoint"): ("party x touchpoint type x touchpoint timestamp", B, ""),
    ("Performance & Attribution", "Attribution Model"): ("attribution model version", B, ""),
    ("Performance & Attribution", "Attributed Outcome"): ("acquisition milestone x campaign x attribution model", B, ""),
}

DERIVED = {
    # Stage 4 consolidation (CD-264): copy of the 41 Application Name.
    ("Digital Properties & Martech", "Marketing System", "System Name"): "41",
    ("Content & Digital Assets", "Asset Compliance Reference", "Approval Status (Mirrored)"): "08",
    ("Digital Identity & Engagement", "Email Interaction", "Recipient Email Address"): "02",
    # CW-085: 06 applies the 04 weights to its flows; future owner 06 (W4).
    ("Performance & Attribution", "Attributed Outcome", "Attributed Amount"): "06",
    # Mirrored from the 08 Compliance Review; marketing does not set it.
    ("Content & Digital Assets", "Audience Restriction", "FINRA Communication Category"): "08",
    # 08 determines the class under the Nudge Compliance Review (CW-091).
    ("Personalization & Experiments", "Nudge Definition", "Recommendation Risk Class"): "08",
}

OWNERSHIP_OVERRIDES = {
    # Source events are mainly 04 engagement events (evt_ IDs); 03 advisor activities are the secondary case.
    ("Performance & Attribution", "Marketing Touchpoint", "Source Event"): "",
}

# CD-289 row rules: which rows are mastered here and which are copies.
ROW_OWNERSHIP = {
    ("Leads & Acquisition Funnel", "Acquisition Milestone", "Milestone Date"):
        "Row rule (CW-085): the milestone is a journey read of facts other domains record. Mastered in 04 only for Application "
        "Started and Application Submitted (Application Journey events). Derived copy of 02 for Prospect Created (Relationship "
        "Stage set to Prospect); of 15 for Account Opened (Account Lifecycle Event) and Advice Enrolled (Program Enrollment); of "
        "50 Money Movement for Account Funded, Rollover Completed and Recurring Investment Set Up (W3; until then the 15 date).",
    ("Digital Identity & Engagement", "Web Visitor / Known User", "Applied Tracking Consent"):
        "Row rule (CW-084): the cookie and tracking categories (Strictly Necessary, Functional, Analytics, Marketing / "
        "Advertising) are mastered in 04 per visitor (device), matched or not, from the latest Tracking Consent Choice. Only "
        "the sale or sharing opt-out of a visitor matched to a party is a copy of 02 Privacy Profile, which holds no cookie "
        "categories.",
    ("Audiences, Subscriptions & Suppression", "Suppression Entry", "Suppression Reason"):
        "Row rule (CW-084): rows Do Not Contact and Deceased are copies of 02 (Privacy Profile, Death Notification). Rows TCPA "
        "Consent Revoked are captured in 04 and written to the 02 Consent Record (Revoked Consent Record); 02 masters the "
        "consent. Hard Bounce, Spam Complaint, Global Unsubscribe, National Do Not Call Registry, Firm-Specific Do-Not-Call, "
        "Reassigned Number, Competitor and Internal Employee rows are mastered in 04.",
}

SUMMARY = {
    "masters": (
        "Masters the marketing, digital and client engagement data of the wealth manager: marketing themes and key messages, "
        "campaigns with their business line, targeting, products and offerings, budgets, spend lines, tracking codes and "
        "members; content assets with their audience restrictions, classification, versions, rights and renditions; client "
        "events, sessions and registrations; digital properties, pages, forms and the martech inventory; web visitors, the "
        "client's Digital Profile, visitor tracking choices, sessions, engagement events, email sends and interactions and "
        "engagement scores; marketing audiences, subscription topics and suppression lists; leads with their qualification, "
        "assignment and conversion, application journeys to submission and acquisition milestones; nudges and their "
        "deliveries, experiments and assignments; promotion offers and enrollments, client referrals, client surveys and "
        "responses; social media accounts, posts and listening, paid media placements and delivery; and touchpoints, "
        "attribution models and attributed outcomes."
    ),
    "references": (
        "References parties, onboarding cases and each party's communication preferences and privacy opt-outs from 02 Client "
        "& Household; accounts from 15 Account; products, share classes, strategies, investment commentary and service "
        "offerings from 01; advisors, coverage teams and advisor activities from 03; co-marketing agreements from 05; "
        "compliance reviews, approval status and complaints from 08; internal legal entities (the publishing entity) from 09; contact "
        "center interactions from 13; employees from 20; metric definitions from 21; applications from 41; brands from 42; "
        "recommendations from 45; fee waivers from 47; consent records for TCPA revocations from 02; the 08 Marketing Rule determinations, FINRA communication category and nudge recommendation determination (Derived copies); and net new assets by campaign "
        "from 06 (Derived copy, W4)."
    ),
}
