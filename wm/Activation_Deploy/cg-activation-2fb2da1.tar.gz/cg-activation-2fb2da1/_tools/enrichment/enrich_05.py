"""Enrichment for Data Domain 05 - Intermediary & Institutional Distribution (wealth-manager model, W4; contract v0.4): grain,
ownership flags, summary.

Rewritten in place for content_05_intermediary_and_institutional_distribution.py (CW-013, CW-131). The wholesale enrichment
(05 Distribution Agreements & Partners) stays at tag wholesale-v1.0. Composite keys follow GRAIN_KEY_FORMATS in
consolidation/proposals_w4_channels.py.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Intermediary Firms & Hierarchy (profiles keyed by the 02 party, CW-132)
    ("Intermediary Firms & Hierarchy", "Distributor Firm"): ("partner firm party (role profile keyed by 02 PTY-)", BO, ""),
    ("Intermediary Firms & Hierarchy", "Form ADV Profile"): ("partner firm (latest Form ADV filing)", AG, "Distributor Firm"),
    ("Intermediary Firms & Hierarchy", "Hierarchy Node"): ("node party x hierarchy type x node effective period", BO, ""),
    ("Intermediary Firms & Hierarchy", "Branch / Office"): ("partner branch or office party (role profile keyed by 02 PTY-)", BO, ""),
    ("Intermediary Firms & Hierarchy", "Advisor Team"): ("external advisor team party (role profile keyed by 02 PTY-)", BO, ""),
    ("Intermediary Firms & Hierarchy", "Team Membership"): ("advisor team x member party x membership effective period", BO, ""),
    ("Intermediary Firms & Hierarchy", "Gatekeeper Profile"): ("home-office gatekeeper party (role profile keyed by 02 PTY-)", BO, ""),
    # External Advisors & Coverage
    ("External Advisors & Coverage", "Financial Professional"): ("external advisor party (role profile keyed by 02 PTY-)", BO, ""),
    ("External Advisors & Coverage", "Advisor Practice"): ("external advisor (practice profile as of the practice data date)", AG, "Financial Professional"),
    ("External Advisors & Coverage", "Employment Affiliation"): ("external advisor x employing firm x affiliation start date", BO, ""),
    ("External Advisors & Coverage", "External Classification"): ("classified party x data vendor x classification as-of date", BO, ""),
    ("External Advisors & Coverage", "Partner Coverage Assignment"): ("covered partner party x covering employee x partner coverage role x coverage effective period (PCVG-)", BO, ""),
    # Selling & Platform Agreements
    ("Selling & Platform Agreements", "Distribution Agreement"): ("distribution agreement (master or schedule, one AGR- ID)", BO, ""),
    ("Selling & Platform Agreements", "Agreement Party Role"): ("agreement x party x agreement party role x role effective period", BO, ""),
    ("Selling & Platform Agreements", "Agreement Term"): ("distribution agreement (effective, renewal and termination terms)", AG, "Distribution Agreement"),
    ("Selling & Platform Agreements", "Agreement Amendment"): ("agreement amendment or side letter (AGR-n-Ann)", BO, ""),
    ("Selling & Platform Agreements", "Agreement Product Coverage"): ("agreement x product, share class or model portfolio x inclusion type x coverage effective period", BO, ""),
    ("Selling & Platform Agreements", "Agreement Distribution Scope"): ("distribution agreement (permitted channels, account programs and account structures)", AG, "Distribution Agreement"),
    ("Selling & Platform Agreements", "Agreement Account Link"): ("agreement x account x account link role x link effective period", BO, ""),
    # Partner Payments
    ("Partner Payments", "Payment Arrangement"): ("payment arrangement (one PYA- ID under a governing agreement)", BO, ""),
    ("Partner Payments", "Rate Schedule"): ("payment arrangement x rate schedule effective period", BO, ""),
    ("Partner Payments", "Rate Tier"): ("rate schedule x tier sequence", BO, ""),
    ("Partner Payments", "Sub-Accounting Fee Terms"): ("payment arrangement (sub-accounting fee terms and fund-paid cap)", AG, "Payment Arrangement"),
    ("Partner Payments", "Payment Calculation"): ("payment arrangement x calculation period (one PCL- calculation)", BO, ""),
    ("Partner Payments", "Partner Invoice"): ("partner invoice (invoicing partner x partner invoice number)", BO, ""),
    ("Partner Payments", "Partner Payment"): ("partner payment (one PMT- payment)", BO, ""),
    ("Partner Payments", "Intermediary Communication Fee Invoice"): ("intermediary communication fee invoice (one IFI- invoice)", BO, ""),
    # Shelf, Programs & Model Delivery
    ("Shelf, Programs & Model Delivery", "Shelf Placement"): ("partner x platform or program x share class x shelf list type x placement status effective period (SHF-)", BO, ""),
    ("Shelf, Programs & Model Delivery", "Share Class Mapping"): ("mapping partner x mapped account type x mapped share class", BO, ""),
    ("Shelf, Programs & Model Delivery", "Partner Research Rating"): ("research provider x rated product x rating date", BO, ""),
    ("Shelf, Programs & Model Delivery", "Model Program Placement"): ("sponsor program agreement x model portfolio x model placement status effective date", BO, ""),
    ("Shelf, Programs & Model Delivery", "Model Delivery Event"): ("model portfolio x sponsor program agreement x delivery (MDEV-)", BO, ""),
    ("Shelf, Programs & Model Delivery", "Partner Program"): ("partner program (one PGM- program)", BO, ""),
    ("Shelf, Programs & Model Delivery", "Program Membership"): ("member program x member party x membership effective from", BO, ""),
    # Partner Operations & Oversight
    ("Partner Operations & Oversight", "Partner Dealer Setup"): ("partner firm x TA dealer number (dealer set-up)", BO, ""),
    ("Partner Operations & Oversight", "Networking Setup"): ("partner dealer setup (networking level and servicing responsibilities)", AG, "Partner Dealer Setup"),
    ("Partner Operations & Oversight", "Partner Data Feed Arrangement"): ("data feed x governing data agreement", BO, ""),
    ("Partner Operations & Oversight", "Distributor Due Diligence"): ("partner firm x due diligence review (one DDQ- review)", BO, ""),
    ("Partner Operations & Oversight", "Due Diligence Finding"): ("due diligence review x finding (DDQ-n-Fnn)", BO, ""),
    ("Partner Operations & Oversight", "Agreement Obligation"): ("agreement obligation (AGR-n-OBnn)", BO, ""),
    ("Partner Operations & Oversight", "Payment Disclosure"): ("disclosing party x disclosure type x publication date", BO, ""),
    # Consultant Relations & Databases
    ("Consultant Relations & Databases", "Consultant Profile"): ("consultant party (role profile keyed by 02 PTY-)", BO, ""),
    ("Consultant Relations & Databases", "Consultant Advisory Relationship"): ("consultant party x advised party x engagement effective period", BO, ""),
    ("Consultant Relations & Databases", "Database Profile"): ("strategy or product x manager database (one DBS- profile)", BO, ""),
    ("Consultant Relations & Databases", "Database Submission"): ("database profile x submission period end", AG, "Database Profile"),
    ("Consultant Relations & Databases", "Consultant Rating"): ("rating provider x rated strategy or product x rating date", BO, ""),
    # Pipeline & RFPs
    ("Pipeline & RFPs", "Sales Opportunity"): ("sales opportunity (one OPP- ID)", BO, ""),
    ("Pipeline & RFPs", "Pipeline Status"): ("sales opportunity (current stage)", AG, "Sales Opportunity"),
    ("Pipeline & RFPs", "Opportunity Value"): ("sales opportunity (expected value)", AG, "Sales Opportunity"),
    ("Pipeline & RFPs", "Placement & Plan Detail"): ("sales opportunity (placement target or prospect plan)", AG, "Sales Opportunity"),
    ("Pipeline & RFPs", "Win / Loss"): ("sales opportunity (outcome)", AG, "Sales Opportunity"),
    ("Pipeline & RFPs", "RFP Request"): ("RFP, RFI or DDQ request (one RFP- ID)", BO, ""),
    ("Pipeline & RFPs", "RFP Submission"): ("RFP request (submitted response and outcome)", AG, "RFP Request"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Intermediary Firms & Hierarchy", "Branch / Office", "Branch CRD Number"): "02",           # 02 Party Identifier, scheme FINRA CRD - Branch
    ("Partner Operations & Oversight", "Partner Dealer Setup", "TA Dealer Number"): "02",         # 02 Market Infrastructure & Vendor Identifier
    ("Partner Operations & Oversight", "Partner Dealer Setup", "NSCC Participant Number"): "02",  # 02 Market Infrastructure & Vendor Identifier
    ("Partner Payments", "Sub-Accounting Fee Terms", "Fund-Paid Sub-TA Cap"): "01",              # 01 fund fee term (merge edit, proposals NOTES)
    ("Intermediary Firms & Hierarchy", "Distributor Firm", "Partner Status"): "02",              # 02 Party Role.Role Status
    ("Intermediary Firms & Hierarchy", "Distributor Firm", "Partner Since Date"): "02",          # 02 Party Role.Role Effective From
    ("Partner Payments", "Payment Calculation", "Basis Value"): "06",                            # Fund Shareholder Position / feed counts (CW-136)
}

# Corrections to the automatic reference resolver: "" = mastered here; "NN" = reference to that Data Domain.
OWNERSHIP_OVERRIDES = {
    # Partner Invoice numbers are partner-assigned (no prefix); the object is mastered here.
    ("Partner Payments", "Partner Payment", "Invoices Settled"): "",
}

# CD-289 row rules: which rows are mastered here and which are copies.
ROW_OWNERSHIP = {
    ("Partner Payments", "Payment Calculation", "Basis Value"):
        "Row rule (CW-136): asset-based rows are a Derived copy of 06 Fund Shareholder Position (Omnibus Look-Through, Plan Position, "
        "Sponsor-Reported Assets) as of the Basis Snapshot; per-account and per-participant rows are counts Derived from the 06 Data Feed "
        "loads of the partner's sub-accounting file; flat-fee rows hold no basis. No row is mastered in 05.",
}

SUMMARY = {
    "masters": (
        "Masters the commercial record of the intermediary channel and of institutional and plan sponsor sales: role profiles keyed by 02 "
        "parties (Distributor Firm with its Form ADV Profile, Hierarchy Node, Branch / Office, Advisor Team, Team Membership, Gatekeeper "
        "Profile, Financial Professional with Advisor Practice, Employment Affiliation, External Classification, Consultant Profile and "
        "Consultant Advisory Relationship); Partner Coverage Assignment; distribution agreements with their parties, terms, amendments, "
        "product coverage, distribution scope and account links; payment arrangements, rate schedules, rate tiers and sub-accounting fee "
        "terms, payment calculations, partner invoices, partner payments and intermediary communication fee invoices; shelf placements, "
        "share class mappings, partner research ratings, model program placements, model delivery events, partner programs and "
        "memberships; partner dealer and networking set-up, partner data feed arrangements, distributor due diligence and findings, "
        "agreement obligations and payment disclosures; consultant database profiles and submissions and consultant ratings; and sales "
        "opportunities with their pipeline status, value, placement and plan detail and outcome, and RFP requests and submissions."
    ),
    "references": (
        "References parties, retirement plans, party identifiers and the partner role lifecycle from 02 Client & Household (TA dealer, "
        "NSCC and branch CRD numbers, Partner Status and Partner Since Date as Derived copies); products, share classes, model portfolios, strategies, composites and the fund-paid sub-accounting cap from "
        "01 Investment Product & Service Offering; accounts from 15 Account; snapshots, data feeds and the payment basis (Derived copy) "
        "from 06 Client Assets, Flows & Channel Attribution; recordkeeper profiles from 16; competitor profiles from 11; compliance "
        "reviews from 08; executed contracts from 39; employees from 20; campaigns from 04; proxy campaigns and shareholder communications from 13."
    ),
}
