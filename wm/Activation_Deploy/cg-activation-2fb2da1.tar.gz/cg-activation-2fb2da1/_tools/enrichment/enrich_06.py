"""Enrichment for Data Domain 06: Client Assets, Flows & Channel Attribution (wealth manager; adapted from Sales Transactions &
AUM Attribution, CW-141; contract v0.4)."""

BO, AG = "Business Object", "Attribute Group"

_TRN, _POS, _MEA, _ATT = "Transactions", "Positions & Client Asset Balances", "Flow & Client Asset Measures", "Channel Attribution"
_IDR, _FED, _DQR, _SNP = ("Identity Resolution & Rep Matching", "Data Sources & Feeds", "Data Quality & Reconciliation",
                          "Reporting Periods, Snapshots & Restatements")

GRAIN = {
    # Transactions
    (_TRN, "Transaction"): ("flow transaction (flow source book x source transaction reference x cancel/correct version: one external flow of a firm client account, own-fund purchase, redemption, exchange or transfer leg, or generated inter-channel transfer)", BO, ""),
    (_TRN, "Transaction Dates"): ("flow transaction", AG, "Transaction"),
    (_TRN, "Transaction Amounts"): ("flow transaction", AG, "Transaction"),
    (_TRN, "Order Source"): ("flow transaction (source book and source record)", AG, "Transaction"),
    (_TRN, "Intermediary As Delivered"): ("flow transaction (intermediary codes as delivered by an intermediary feed)", AG, "Transaction"),
    (_TRN, "Linked Transaction"): ("flow transaction x linked contra transaction (exchange, transfer, rollover or conversion pair)", AG, "Transaction"),
    (_TRN, "ETF Creation / Redemption"): ("ETF primary-market transaction (creation or redemption order by an authorized participant)", AG, "Transaction"),
    (_TRN, "SMA Flow"): ("third-party sponsor program transaction", AG, "Transaction"),
    (_TRN, "Transaction Status"): ("flow transaction x status version (cancel / correct)", AG, "Transaction"),
    # Positions & Client Asset Balances
    (_POS, "Fund Shareholder Position"): ("account x own-fund share class x valuation date x position source (End of Day view; trade-date quantity unless Position Basis = Settlement Date)", BO, ""),
    (_POS, "Omnibus Look-Through"): ("intermediary omnibus parent account x sub-account x share class x valuation date", AG, "Fund Shareholder Position"),
    (_POS, "ETF Holding"): ("own-ETF share class x external holding custodian / broker (DTC participant) x as-of date", AG, "Fund Shareholder Position"),
    (_POS, "Plan Position"): ("third-party recordkept retirement plan x share class x valuation date", AG, "Fund Shareholder Position"),
    (_POS, "Sponsor-Reported Assets"): ("sponsor program x share class or model x advisor x as-of date", AG, "Fund Shareholder Position"),
    (_POS, "Account Asset Summary"): ("firm client account x as-of date x holding type", BO, ""),
    # Flow & Client Asset Measures
    (_MEA, "Measure Definition"): ("certified measure (definition version)", BO, ""),
    (_MEA, "Flow Treatment Rule"): ("measure definition", AG, "Measure Definition"),
    (_MEA, "Measure Value"): ("measure x period end x dimension type x dimension key x data basis x snapshot", BO, ""),
    (_MEA, "Flow Measures"): ("measure value (own-fund flow measure set)", AG, "Measure Value"),
    (_MEA, "Asset Measures"): ("measure value (own-fund assets by channel)", AG, "Measure Value"),
    (_MEA, "Client Asset Measures"): ("measure value (client asset measure set)", AG, "Measure Value"),
    # Channel Attribution
    (_ATT, "Account Channel Assignment"): ("account x distribution channel x effective period", BO, ""),
    (_ATT, "Attribution Record"): ("attributed amount x source transaction, position or asset summary x dimension combination x effective date", BO, ""),
    (_ATT, "Distributor Hierarchy"): ("attribution record (05 firm > office > team > financial professional path as of hierarchy version date)", AG, "Attribution Record"),
    (_ATT, "Market & Client Dimensions"): ("attribution record", AG, "Attribution Record"),
    (_ATT, "Salesperson Credit"): ("attribution record x credited employee x credit role (IC and IA only)", AG, "Attribution Record"),
    (_ATT, "Attribution Method"): ("attribution record", AG, "Attribution Record"),
    (_ATT, "Unattributed Item"): ("suspense item (UNA-): unattributed amount x lowest resolved level x reason x first seen date", BO, ""),
    (_ATT, "Attribution Override"): ("override scope value (e.g. rep code, account or channel assignment) x effective period", BO, ""),
    # Identity Resolution & Rep Matching
    (_IDR, "Identifier Crosswalk"): ("intermediary feed x source identifier type x source identifier value x effective period", BO, ""),
    (_IDR, "Match Rule"): ("match rule (version)", BO, ""),
    (_IDR, "Match Result"): ("identifier crosswalk entry x candidate party x match evaluation date", AG, "Identifier Crosswalk"),
    # Data Sources & Feeds
    (_FED, "Data Feed"): ("data feed (provider or internal book x content x layout)", BO, ""),
    (_FED, "Load"): ("feed file load (feed x business date x file)", BO, ""),
    # Data Quality & Reconciliation
    (_DQR, "Reconciliation"): ("reconciliation definition (left source x right source x comparison grain x measure)", BO, ""),
    (_DQR, "Reconciliation Run"): ("reconciliation x run business date", AG, "Reconciliation"),
    (_DQR, "Break"): ("reconciliation break (reconciliation run x comparison key x break type)", BO, ""),
    # Reporting Periods, Snapshots & Restatements
    (_SNP, "Reporting Period"): ("flow and client asset reporting period (period type x period)", BO, ""),
    (_SNP, "Snapshot"): ("snapshot (reporting period x snapshot type x version)", BO, ""),
    (_SNP, "Restatement"): ("restatement event", BO, ""),
}

DERIVED = {
    # Row rule (CD-199): copies of 29 Fund Order on own-fund orders the firm's transfer agent processed; mastered here otherwise.
    (_TRN, "Order Source", "Order Entry Channel"): "29",
    (_TRN, "Order Source", "Order Message Type"): "29",
    (_TRN, "Order Source", "Contribution Source Type"): "16",
    (_TRN, "ETF Creation / Redemption", "Basket Type"): "29",
    (_POS, "Fund Shareholder Position", "Register Account Category"): "29",
    (_POS, "Account Asset Summary", "Advised Assets Indicator"): "15",
    # Metric certification is mastered in 21 Data Governance & Analytics (CD-163)
    (_MEA, "Measure Definition", "Certified Indicator"): "21",
    # Identifiers mastered in 02 (Market Participant.DTC Participant Number; US Regulatory Identifier CRD numbers)
    (_POS, "ETF Holding", "DTC Participant Number"): "02",
    (_IDR, "Identifier Crosswalk", "Resolved CRD Number"): "02",
    (_ATT, "Salesperson Credit", "Credit Role"): "05",
    (_ATT, "Market & Client Dimensions", "Campaign Attribution Weight"): "04",
    (_FED, "Data Feed", "License Use Restriction"): "14",
}

OWNERSHIP_OVERRIDES = {
    (_MEA, "Measure Value", "Reporting Period"): "",   # 06 Reporting Period is mastered here (CD-139)
}

SUMMARY = {
    "masters": "Masters the firm-wide conformed flow record (Flow Transaction) with its source links, the Fund Shareholder Position and Account Asset Summary views of the books of record, intermediary look-through, ETF, third-party plan and sponsor-reported assets as delivered, the effective-dated Account Channel Assignment, the attribution of flows and assets to channel, business line, offering, advisor, household, campaign, plan, institution and intermediary, the certified Client Assets, Net New Assets and Advised Assets definitions and the fund flow measures with their treatment rules, values, snapshots and restatements, identity resolution for intermediary feeds, data feeds and loads, and reconciliations of 06 data to its sources.",
    "references": "References accounts and program enrollments from Account (15); parties and households from Client & Household (02); share classes, products, models and service offerings from Investment Product (01); client holdings, account activity and account transfers from Clearing, Settlement & Client Asset Custody (49); sweep allocations from Money Movement, Cash & Sweep (50); register postings, share register balances and fund orders from Transfer Agency Operations (29); participant ledger postings, participant balances and recordkeeper profiles from Retirement Plan Administration (16); portfolio capital activity and holdings from Portfolio & Investment Book of Record (18); share class NAVs from Fund Accounting & Valuation (27); firm advisors and their client coverage from Advisor Organization, Coverage & Supervision (03); campaigns and attribution weights from Marketing, Digital & Client Engagement (04); intermediary firms, financial professionals, consultants, partner coverage and agreements from Intermediary & Institutional Distribution (05); institutional clients from Institutional Client Servicing & Reporting (12); data license restrictions from Third-Party Data & Licensing (14); employees from Human Capital (20); and metric certification from Data Governance & Analytics (21).",
}

# Row Ownership Rule (CD-289): where one attribute holds rows Derived from a book of record and rows mastered here.
_RR_FLOW = ("Row rule (CW-141, CD-289): on rows whose Flow Source Book is 49, 29, 16 or 18 this is a Derived copy of the source record "
            "named in Order Source (49 Client Account Activity, 29 Register Transaction, 16 Participant Ledger Posting, 18 Portfolio "
            "Capital Activity); computed here on generated inter-channel transfer rows; mastered here, as delivered, on "
            "intermediary-feed rows.")
_RR_POS = ("Row rule (CW-122, CW-141, CD-289): brokerage, managed and trust accounts are a Derived copy of 49 Client Holding (End of "
           "Day) valued at the 49 Client Holding Valuation; every registered account is a Derived copy of 29 Share Register Balance "
           "valued at the 27 Share Class NAV; mastered here, as delivered, only on intermediary look-through rows. Which rows are "
           "summed is the Aggregation Role.")
_RR_AGG = ("Row rule (program-lead ruling on the 06 review): Counted - Firm Client Account = 49 rows and 29 rows of Fund-Only and "
           "Institutional Direct accounts; Counted - Intermediary = Networked register rows and intermediary look-through rows; Excluded "
           "- Omnibus or Nominee = Broker-Dealer Omnibus, DTC Nominee, Intermediary Omnibus aggregate and Plan Omnibus rows (control "
           "only); Excluded - Firm Proprietary = seed and error accounts; Attribution Only = Sponsor-Reported Assets.")
ROW_OWNERSHIP = {
    (_TRN, "Transaction", "Transaction Type"): _RR_FLOW,
    (_TRN, "Transaction", "Account"): _RR_FLOW,
    (_TRN, "Transaction Dates", "Trade Date"): _RR_FLOW,
    (_TRN, "Transaction Dates", "Settlement Date"): _RR_FLOW,
    (_TRN, "Transaction Dates", "As-Of Date"):
        "Row rule (CD-199 as amended by CW-122): on rows with a Source Register Transaction this is a Derived copy of the 29 posting's as-of date; mastered here for intermediary-feed rows.",
    (_TRN, "Transaction Amounts", "Units"): _RR_FLOW,
    (_TRN, "Transaction Amounts", "Gross Amount"): _RR_FLOW,
    (_TRN, "Transaction Amounts", "Net Amount"): _RR_FLOW,
    (_TRN, "Order Source", "Order Entry Channel"):
        "Row rule (CD-199, plan section 4 item 9): on rows processed by the firm's transfer agent (Originating Fund Order set) this is a Derived copy of 29 Order Routing Detail.Dealing Route; mastered here for every other source.",
    (_TRN, "Order Source", "Order Message Type"):
        "Row rule (CD-199, plan section 4 item 9): on rows processed by the firm's transfer agent (Originating Fund Order set) this is a Derived copy of 29 Order Routing Detail.Order Message Type; mastered here for every other source.",
    (_POS, "Fund Shareholder Position", "Units Held"): _RR_POS,
    (_POS, "Fund Shareholder Position", "Market Value"): _RR_POS,
    (_POS, "Account Asset Summary", "Summary Market Value"):
        "Row rule (CW-141, CD-289): computed here on every row, for firm client accounts only, by summing the book named in Summary Source Book (49 Client Holding Valuation and Account Cash Balance with 50 Sweep Allocation, 06 Fund Shareholder Position for 29 register rows, 16 Participant Balance, 18 Portfolio Holding); net equity (margin debit deducted from Cash and Sweep); never edited here.",
    (_POS, "Fund Shareholder Position", "Aggregation Role"): _RR_AGG,
    (_MEA, "Client Asset Measures", "Ending Client Assets"):
        "Summing rule: sum of Account Asset Summary over firm client accounts (49 for brokerage, managed and trust; 29 via Fund Shareholder Position for direct registered; 16 Participant Balance for participant accounts; 18 for IA mandates) plus Fund Shareholder Position rows with Aggregation Role Counted - Intermediary and omnibus residuals; Account Asset Summary holds no intermediary assets, so nothing is added twice; Firm Proprietary excluded.",
    (_TRN, "Transaction", "Flow Direction"): _RR_FLOW,
    (_TRN, "Transaction Amounts", "Price"): _RR_FLOW,
    (_TRN, "Transaction Amounts", "Transaction Currency"): _RR_FLOW,
    (_TRN, "Transaction Amounts", "FX Rate Applied"): _RR_FLOW,
    (_TRN, "Order Source", "Systematic Plan Indicator"): _RR_FLOW,
    (_TRN, "Order Source", "Flow Source Book"):
        "Rule (program-lead ruling on the 06 review): one flow book per account book: 49 Client Account Activity (brokerage, managed, trust), 29 Register Transaction (Fund-Only, Institutional Direct, Networked), 16 Participant Ledger Posting (participant accounts), 18 Portfolio Capital Activity (IA mandates), intermediary feed (intermediary sub-accounts), 06 Account Channel Assignment (inter-channel transfers); 29 omnibus and nominee postings and 50 instructions are never loaded.",
    (_TRN, "Linked Transaction", "Transfer Type"): "Row rule: Derived copy of 49 Account Transfer.Transfer Channel (49 rows) or the 16 distribution (16 rows); mastered as delivered on intermediary rows.",
    (_TRN, "Linked Transaction", "Contra Firm"): "Row rule: Derived copy of 49 Account Transfer.Contra Firm on rows with a Source Account Transfer; mastered as delivered on intermediary-feed rows.",
    (_TRN, "Linked Transaction", "From Distribution Channel"): "Copy of 06 Account Channel Assignment.Assigned Distribution Channel (predecessor assignment).",
    (_TRN, "Linked Transaction", "To Distribution Channel"): "Copy of 06 Account Channel Assignment.Assigned Distribution Channel (new assignment).",
    (_TRN, "Transaction Status", "Transaction Status"): _RR_FLOW,
    (_TRN, "Intermediary As Delivered", "Resolved Distributor Firm"): "Row rule: TA-processed rows copy 29 Order Routing Detail.Resolved Dealer; intermediary-feed rows are resolved here through Identifier Crosswalk.",
    (_TRN, "Intermediary As Delivered", "Resolved Advisor / Rep"): "Row rule: TA-processed rows copy 29 Order Routing Detail.Resolved Representative; intermediary-feed rows are resolved here through Identifier Crosswalk.",
    (_POS, "Account Asset Summary", "Summary Distribution Channel"): "Copy of 06 Account Channel Assignment.Assigned Distribution Channel in force on the as-of date.",
    (_ATT, "Market & Client Dimensions", "Distribution Channel"): "Copy of 06 Account Channel Assignment.Assigned Distribution Channel on the effective date.",
    (_ATT, "Market & Client Dimensions", "Business Line"): "Copy of 06 Account Channel Assignment.Assigned Business Line on the effective date.",
    (_ATT, "Salesperson Credit", "Credit Role"): "Row rule: copied from 05 Partner Coverage Assignment (IC and consultant-led) or 03 Party Coverage Assignment.Party Coverage Role (IA direct).",
}
