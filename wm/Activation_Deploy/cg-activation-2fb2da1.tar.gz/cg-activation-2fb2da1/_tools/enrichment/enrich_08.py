"""Enrichment for Data Domain 08 - Retail Conduct & Supervision (wealth-manager model, W2; contract v0.4): grain, ownership
flags, summary.

Rewritten in place for content_08_retail_conduct_and_supervision.py (CW-015, CW-066, CW-067). The wholesale enrichment
(Distribution Compliance) stays at tag wholesale-v1.0.
"""

BO, AG = "Business Object", "Attribute Group"

F1, F2, F3 = "Reg BI & Principal Review", "Surveillance & Corrective Action", "Supervisory System"
F4, F5, F6 = "Communications Review", "Communications Capture & Surveillance", "Complaints"
F7, F8, F9 = "Senior & Vulnerable Investor Protection", "Registration & Licensing", "Gifts & Non-Cash Compensation"

GRAIN = {
    # Reg BI & Principal Review
    (F1, "Supervisory Review"): ("supervisory review (one principal review of one subject; PRNR-)", BO, ""),
    (F1, "Best Interest Review Detail"): ("supervisory review (Reg BI, fiduciary and PTE 2020-02 evidence checks)", AG, "Supervisory Review"),
    (F1, "Disclosure Delivery Check"): ("account or retail investor x disclosure trigger x check date", BO, ""),
    (F1, "Incentive Conflict Review"): ("incentive plan component (03 ICP-) or recognition award (03 RECG-) x review date", BO, ""),
    # Surveillance & Corrective Action
    (F2, "Surveillance Scenario"): ("surveillance scenario version (SCEN-)", BO, ""),
    (F2, "Sales Practice Alert"): ("sales practice alert (SPA-)", BO, ""),
    (F2, "Frequent Trading Case"): ("frequent trading case (account x own-fund share class x look-back window; FTC-)", BO, ""),
    (F2, "Conduct Corrective Action"): ("conduct corrective action (CORAC-)", BO, ""),
    # Supervisory System
    (F3, "Supervisory Control"): ("WSP policy (38 POLCY-) x supervisory control number", BO, ""),
    (F3, "Supervisory Control Test"): ("supervisory control x test period", BO, ""),
    (F3, "Branch Inspection"): ("branch inspection (office x inspection; BRIN-)", BO, ""),
    (F3, "Supervisory Finding"): ("supervisory finding (SFND-)", BO, ""),
    (F3, "Heightened Supervision Plan"): ("heightened supervision plan (representative x plan period; HSPL-)", BO, ""),
    # Communications Review
    (F4, "Compliance Review"): ("communication review x asset version (REV-)", BO, ""),
    (F4, "US Communication Classification"): ("communication review (US classification and required disclosures)", AG, "Compliance Review"),
    (F4, "Performance Presentation"): ("communication review (performance shown)", AG, "Compliance Review"),
    (F4, "Review Step"): ("communication review x review step sequence", AG, "Compliance Review"),
    (F4, "Compliance Approval"): ("communication review x approval decision", AG, "Compliance Review"),
    (F4, "FINRA Advertising Filing"): ("communication review x filing submission", AG, "Compliance Review"),
    # Communications Capture & Surveillance
    (F5, "Approved Communication Channel"): ("firm channel or advisor account x approval period", BO, ""),
    (F5, "Captured Communication Record"): ("captured communication (ARC-)", BO, ""),
    (F5, "Surveillance Alert"): ("communications surveillance alert (SURV-)", BO, ""),
    # Complaints
    (F6, "Complaint"): ("complaint (CPL-)", BO, ""),
    (F6, "Complaint Classification"): ("complaint (classification)", AG, "Complaint"),
    (F6, "Complaint Handling"): ("complaint (handling and resolution)", AG, "Complaint"),
    (F6, "Complaint Regulatory Report"): ("complaint (regulatory reporting)", AG, "Complaint"),
    # Senior & Vulnerable Investor Protection
    (F7, "Senior Investor Case"): ("senior investor case (SNRC-)", BO, ""),
    (F7, "Senior Investor Case Action"): ("senior investor case x protective action x action date", AG, "Senior Investor Case"),
    (F7, "External Protection Report"): ("senior investor case x recipient x report", BO, ""),
    # Registration & Licensing
    (F8, "Individual Registration"): ("person x registration category x jurisdiction (LIC-)", BO, ""),
    (F8, "Exam Result"): ("person x qualification exam x attempt sequence", BO, ""),
    (F8, "Registration Filing"): ("person x uniform form filing", BO, ""),
    (F8, "Disclosure Event"): ("person (20 EMP-) x disclosure event; optional link to one registration", BO, ""),
    (F8, "CE Requirement"): ("person x registration (LIC-) x CE element x cycle", BO, ""),
    (F8, "Branch Registration"): ("branch office (03 SITE-) x Form BR filing; the registration-level facts (branch CRD number, closing date) repeat on each filing row", BO, ""),
    # Gifts & Non-Cash Compensation
    (F9, "Gift / Entertainment Item"): ("gift, entertainment or non-cash compensation item (GNE-)", BO, ""),
    (F9, "Benefit Valuation"): ("item (valuation against limits)", AG, "Gift / Entertainment Item"),
    (F9, "G&E Approval"): ("item (approval)", AG, "Gift / Entertainment Item"),
    (F9, "Training / Education Meeting"): ("item (sponsor-paid training or education meeting)", AG, "Gift / Entertainment Item"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    (F3, "Branch Inspection", "Branch Type at Inspection"): "03",        # branch type as held on 03 Firm Branch Office
    (F7, "Senior Investor Case", "Specified Adult Basis"): "02",
    (F3, "Supervisory Control Test", "Rule 3120 Report Date"): "38",  # 38 Compliance Program Review (38 review ruling 3)         # 02 Specified Adult Status at case opening
    (F5, "Captured Communication Record", "Legal Hold Indicator"): "39", # CD-258: Y while a 39 Legal Hold Scope covers it
    (F8, "Branch Registration", "Registered Branch Type"): "03",       # 03 masters Branch Type (03 fix pass ruling)
    (F3, "Heightened Supervision Plan", "Heightened Supervisor"): "03", # 03 Supervisory Assignment, type Heightened Supervision Supervisor
    (F7, "Senior Investor Case", "Trusted Contact Contacted Date"): "02", # 02 Vulnerability Concern; the contact fact stays 02's
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rules (documentation only).
ROW_OWNERSHIP = {
    (F1, "Supervisory Review", "Supervisory Review Type"):
        "Row rule: each review fills exactly the subject reference its type requires - Reviewed Recommendation (45) for recommendation, "
        "advisory, rollover and account type reviews; Reviewed Account and, for options and margin approval reviews, Reviewed Account "
        "Feature (15); Reviewed Client Order (48) for transaction reviews; Reviewed Correspondence (08 ARC-) for correspondence reviews; "
        "Reviewed Routing Rule or Reviewed Execution Venue (48) for best-execution reviews; none for a digital advice population review "
        "(the population is stated in the exception description). The subject is mastered in its own domain on every row.",
    (F1, "Disclosure Delivery Check", "Check Result"):
        "Row rule: every check carries Checked Account or Checked Retail Investor, and at least one evidence reference (Account Delivery "
        "Evidence 15, Client-Level Delivery Evidence 45, Communication Delivery Evidence 13 or Fee Disclosure Evidence 47) unless the "
        "result is Not Delivered or Not Required; the delivery facts stay mastered in the evidencing domain, the result here.",
}

SUMMARY = {
    "masters": (
        "Masters the retail conduct and supervision record of the broker-dealer and the adviser: supervisory reviews of "
        "recommendations, rollovers, account types, approvals, transactions and correspondence with their best-interest evidence "
        "checks; Form CRS and Reg BI disclosure delivery checks; Reg BI reviews of incentive plan components; surveillance "
        "scenarios, sales practice alerts, frequent trading cases and conduct corrective actions; supervisory controls, Rule 3120 "
        "control tests, branch inspections, supervisory findings and heightened supervision plans; communications review, approval "
        "and FINRA filing; approved channels, captured communications and their surveillance alerts; complaints with their FINRA "
        "Rule 4530 classification, handling and reporting; senior investor cases, their protective actions and external protection "
        "reports; individual registrations, exams, Forms U4 and U5, disclosure events, continuing education and Form BR branch "
        "registrations; gifts, entertainment and non-cash compensation."
    ),
    "references": (
        "References recommendations, best interest evidence and rollover analyses from 45 Financial Planning & Advice; parties, "
        "investor profiles, trusted contact designations and vulnerability concerns from 02 Client & Household (specified adult "
        "basis as a Derived copy); accounts, account features, account disclosure deliveries and account restrictions from 15 "
        "Account; advisors, branch offices and incentive plan components from 03 Advisor Organization, Coverage & Supervision; "
        "employees, lifecycle events and learning completions from 20 Human Capital; policies, conflicts, conflict mitigations, "
        "examination findings, AML cases and Form CRS filings from 38; content assets, campaigns, events and social media accounts "
        "from 04; service requests and remediations from 13; legal matters from 39 (legal hold as a "
        "Derived copy); the retention schedule from 21; fee disclosure deliveries from 47; models from 37; recognition awards from 03; share classes, products "
        "and service offerings from 01; legal entities from 09; agreements from 05; routing rules, execution venue profiles and client orders (CLORD-) "
        "from 48, client account activity (CLACT-) from 49 and money movement holds (MMHLD-) from 50."
    ),
}
