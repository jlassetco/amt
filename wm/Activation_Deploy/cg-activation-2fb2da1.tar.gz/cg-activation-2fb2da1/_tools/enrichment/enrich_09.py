"""Enrichment for Data Domain 09 - Shared & Enterprise Reference Data (contract v0.3): grain, ownership flags, summary.
Wealth model (W1, CW-909): UK & EU geography objects and the BMR status copy removed; summary rewritten to the US wealth manager."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Geography
    ("Geography", "Country"): ("country (ISO 3166-1)", BO, ""),
    ("Geography", "Country Subdivision"): ("country subdivision (ISO 3166-2)", BO, ""),
    ("Geography", "US County"): ("geographic unit of type US county", AG, "Geographic Unit"),
    ("Geography", "Core Based Statistical Area"): ("geographic unit of type CBSA x delineation vintage", AG, "Geographic Unit"),
    ("Geography", "ZIP Code & ZCTA"): ("geographic unit of type ZIP code", AG, "Geographic Unit"),
    ("Geography", "Geographic Unit"): ("geographic unit (geographic scheme x scheme code x scheme vintage)", BO, ""),
    ("Geography", "Geographic Hierarchy"): ("hierarchy type x parent geographic unit x child geographic unit x effective period", BO, ""),
    ("Geography", "Geographic Group"): ("geographic group", BO, ""),
    ("Geography", "Geographic Group Membership"): ("geographic group x member geographic unit x effective period", BO, ""),
    # Time Zones & Calendars
    ("Time Zones & Calendars", "Time Zone"): ("IANA time zone", BO, ""),
    ("Time Zones & Calendars", "Calendar"): ("calendar", BO, ""),
    ("Time Zones & Calendars", "Composite Calendar"): ("composite calendar x component calendar", BO, ""),
    ("Time Zones & Calendars", "Calendar Date"): ("calendar x date", BO, ""),
    ("Time Zones & Calendars", "Dealing Calendar Rule"): ("calendar of type fund dealing", AG, "Calendar"),
    ("Time Zones & Calendars", "Fiscal Calendar"): ("calendar of type fiscal", AG, "Calendar"),
    ("Time Zones & Calendars", "Fiscal Period"): ("fiscal calendar x fiscal period", BO, ""),
    ("Time Zones & Calendars", "Reporting Period Definition"): ("reporting period definition (e.g. MTD, QTD, YTD)", BO, ""),
    # Currency & FX Reference
    ("Currency & FX Reference", "Currency"): ("currency (ISO 4217)", BO, ""),
    ("Currency & FX Reference", "Currency Pair Convention"): ("currency pair", BO, ""),
    ("Currency & FX Reference", "FX Rate Source"): ("FX rate type", AG, "FX Rate Type"),
    ("Currency & FX Reference", "FX Rate Type"): ("FX rate type", BO, ""),
    # Languages, Locales & Units
    ("Languages, Locales & Units", "Language"): ("language (ISO 639)", BO, ""),
    ("Languages, Locales & Units", "Locale"): ("locale (BCP 47 tag)", BO, ""),
    ("Languages, Locales & Units", "Unit of Measure"): ("unit of measure", BO, ""),
    ("Languages, Locales & Units", "Number & Date Convention"): ("locale", AG, "Locale"),
    # Internal Legal Entities
    ("Internal Legal Entities", "Internal Legal Entity"): ("internal legal entity (or branch)", BO, ""),
    ("Internal Legal Entities", "Legal Entity Identifier"): ("internal legal entity", AG, "Internal Legal Entity"),
    ("Internal Legal Entities", "Entity Ownership Relationship"): ("child entity x parent entity x relationship type x effective period", BO, ""),
    ("Internal Legal Entities", "Entity Distribution Role"): ("legal entity x distribution role x market scope x effective period", BO, ""),
    # Internal Organization
    ("Internal Organization", "Org Unit"): ("org unit", BO, ""),
    ("Internal Organization", "Cost & Profit Center"): ("org unit", AG, "Org Unit"),
    ("Internal Organization", "Office Location"): ("office location", BO, ""),
    ("Internal Organization", "Org Hierarchy Link"): ("hierarchy type x parent org unit x child org unit x effective period", BO, ""),
    ("Internal Organization", "Reorganization Event"): ("reorganization event", BO, ""),
    # Industry Classification
    ("Industry Classification", "Classification Scheme"): ("classification scheme version (e.g. NAICS 2022, US SIC 1987)", BO, ""),
    ("Industry Classification", "Classification Code"): ("classification scheme version x classification code", BO, ""),
    ("Industry Classification", "Classification Concordance"): ("source classification code x target classification code", BO, ""),
    # Enterprise Code List Registry
    ("Enterprise Code List Registry", "Code List"): ("code list (registry entry)", BO, ""),
    ("Enterprise Code List Registry", "Code List Consumer"): ("code list x consuming domain x consuming attribute", BO, ""),
    ("Enterprise Code List Registry", "Code List Version"): ("code list version", BO, ""),
    ("Enterprise Code List Registry", "Code Value"): ("code list version x code value", BO, ""),
    ("Enterprise Code List Registry", "Code Mapping"): ("source system x source value x target code list", BO, ""),
    ("Enterprise Code List Registry", "Code List Change Request"): ("code list change request", BO, ""),
    # Reference Data Management
    ("Reference Data Management", "Reference Data Subscription"): ("reference data set x subscribing system", BO, ""),
}

DERIVED = {
    # CD-152 (amending CD-083 and CD-084): cost and profit center codes are now typed references to 19 Chart Segment Value;
    # fiscal period status and the accounting company code are copies of 19 values
    ("Time Zones & Calendars", "Fiscal Period", "Fiscal Period Status"): "19",
    ("Internal Legal Entities", "Internal Legal Entity", "Accounting Company Code"): "19",
}

OWNERSHIP_OVERRIDES = {
    # Concordances link codes within the 09 industry classification schemes
    ("Industry Classification", "Classification Concordance", "Source Classification Code"): "",
    ("Industry Classification", "Classification Concordance", "Target Classification Code"): "",
}

SUMMARY = {
    "masters": "Masters the shared reference data of the US wealth manager: countries, subdivisions, US statistical and postal geography (counties, CBSAs, ZIP codes and ZCTAs), geographic units, hierarchies and groups, time zones, business, holiday, exchange, bond market, payment system, fund dealing and fiscal calendars (US and the foreign markets the funds invest in) and reporting period definitions, currencies and FX rate types and sources, languages, locales and units, the firm's internal legal entities (parent, investment adviser, self-clearing broker-dealer, fund adviser and fund trusts, transfer agent, recordkeeper, optional national trust company) with their identifiers, ownership and distribution roles (their regulatory registrations moved to 38 under CD-250), internal org units, offices, org hierarchies and reorganizations, industry classification schemes and concordances, and the enterprise code list registry with its versions, values, mappings and change control.",
    "references": 'References the party master mirror of each internal legal entity from Client & Household (02), org unit heads and code list owners as employees from Human Capital (20; the employee master moved there under CD-151), cost and profit center codes, the accounting company code and fiscal period status from Finance & Accounting (19), licensed FX rate datasets from Third-Party Data & Licensing (14), and source and subscribing systems from the application inventory (41).',
}
