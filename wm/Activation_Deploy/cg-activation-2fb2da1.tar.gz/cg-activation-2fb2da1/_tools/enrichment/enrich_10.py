"""Enrichment for Data Domain 10 - Client Revenue, Pricing Economics & Profitability (wealth manager; adapted in place from
the wholesale 10 Distribution Finance & Profitability, CW-012, CW-156 to CW-159; contract v0.4)."""

BO, AG = "Business Object", "Attribute Group"

_REV, _FWS, _EXP, _COA = "Revenue & Recognition", "Fund Expense Support", "Cost Accounting & Contract Costs", "Ledger Mapping & Controls"
_ALC, _PNL, _CLE = "Cost Allocation", "Profitability & Cost to Serve", "Client Economics & Pricing"
_HIR, _BUD, _ICT = "Management Hierarchies", "Budgets & Forecasts", "Intercompany & Transfer Pricing"

GRAIN = {
    # Revenue & Recognition
    (_REV, "Revenue Contract"): ("revenue contract (one RVC- contract with an identified customer)", BO, ""),
    (_REV, "Performance Obligation"): ("revenue contract x performance obligation", AG, "Revenue Contract"),
    (_REV, "Fee Revenue Record"): ("own-fund share class x revenue accounting period (one FRR- record)", BO, ""),
    (_REV, "Performance Fee Record"): ("share class or mandate x performance period (one PFR- record)", BO, ""),
    (_REV, "Distribution Revenue Record"): ("paying share class x receiving legal entity x distribution revenue type x accounting period", BO, ""),
    (_REV, "Client Revenue Record"): ("account (or 47 Fee Household, or 16 plan service arrangement) x revenue stream x month (one CLREV- record; its source records are multi-valued)", BO, ""),
    (_REV, "Cash Program Economics"): ("sweep program x program bank x period", BO, ""),
    # Fund Expense Support
    (_FWS, "Waiver Record"): ("supported share class x waiver type x accounting period (one WVR- record)", BO, ""),
    (_FWS, "Adviser-Borne Cost"): ("adviser-borne cost type x payment arrangement or fund x accounting period", BO, ""),
    # Cost Accounting & Contract Costs
    (_EXP, "Distribution Cost Item"): ("cost item: source record x cost center x service period (one DCO- item)", BO, ""),
    (_EXP, "Accrual"): ("cost item x accrual accounting period (one ACR- accrual)", BO, ""),
    (_EXP, "Contract Cost Asset"): ("capitalized contract cost asset (one CCA- asset per revenue contract and cost source)", BO, ""),
    (_EXP, "Capitalization Assessment"): ("contract cost asset policy x assessed cost source (incentive plan component or payment arrangement)", AG, "Contract Cost Asset"),
    # Ledger Mapping & Controls
    (_COA, "Account Mapping"): ("management P&L line x GL natural account x ledger x mapping effective period", BO, ""),
    (_COA, "Control"): ("reconciliation type x control period (control execution)", BO, ""),
    # Cost Allocation
    (_ALC, "Cost Pool"): ("cost pool", BO, ""),
    (_ALC, "Allocation Method"): ("allocation method", BO, ""),
    (_ALC, "Allocation Driver"): ("allocation driver", BO, ""),
    (_ALC, "Allocation Rule"): ("source cost pool x method x driver x target dimension x rule effective period", BO, ""),
    (_ALC, "Allocation Run"): ("allocation run: run period x data version", BO, ""),
    (_ALC, "Allocation Result"): ("allocation run x allocation rule x target dimension member", AG, "Allocation Run"),
    # Profitability & Cost to Serve
    (_PNL, "Profitability Record"): ("dimension combination (channel, business line, offering, tier, product, advisor, household or account, segment) x profitability period x data version x hierarchy version", BO, ""),
    (_PNL, "Profitability Measure"): ("profitability record (its revenue, cost and margin measures)", AG, "Profitability Record"),
    (_PNL, "Profitability Measure Definition"): ("profitability measure code", BO, ""),
    (_PNL, "Cost-to-Serve Profile"): ("profitability record (served subject x period)", AG, "Profitability Record"),
    # Client Economics & Pricing
    (_CLE, "Client Acquisition Cost Record"): ("acquisition channel x campaign (or ALL) x cohort month", BO, ""),
    (_CLE, "Lifetime Value Model"): ("lifetime value model x version (one LTVM- model)", BO, ""),
    (_CLE, "Client Lifetime Value Estimate"): ("Client Household x model version x as-of date", BO, ""),
    (_CLE, "Pricing Scenario"): ("priced subject x scenario (one PRSC- scenario)", BO, ""),
    (_CLE, "Pricing Scenario Result"): ("pricing scenario x projection year", AG, "Pricing Scenario"),
    # Management Hierarchies
    (_HIR, "Management Hierarchy"): ("management hierarchy version (hierarchy type x version)", BO, ""),
    (_HIR, "Management Hierarchy Node"): ("hierarchy version x node", AG, "Management Hierarchy"),
    (_HIR, "Hierarchy Restatement"): ("hierarchy restatement event (one HRS- restatement)", BO, ""),
    # Budgets & Forecasts
    (_BUD, "Plan Version"): ("plan version: plan type x scenario x fiscal year x version", BO, ""),
    (_BUD, "Plan Line"): ("plan version x plan P&L line x cost center x dimension members x plan period", AG, "Plan Version"),
    (_BUD, "Flow & Revenue Forecast"): ("plan version x offering, product or share class x channel x plan period", AG, "Plan Version"),
    (_BUD, "Variance"): ("compared plan version x P&L line x dimension members x period", AG, "Plan Version"),
    # Intercompany & Transfer Pricing
    (_ICT, "Intercompany Agreement"): ("intercompany agreement (one ICA- agreement)", BO, ""),
    (_ICT, "TP Policy"): ("intercompany agreement x policy effective period (its transfer pricing method, remuneration and arm's length range)", AG, "Intercompany Agreement"),
    (_ICT, "Intercompany Charge"): ("intercompany agreement x charge period (one ICC- charge)", BO, ""),
}

DERIVED = {
    # CD-188: the fund-side waiver and reimbursement amounts are mastered in 27 Expense Cap & Waiver Accrual.
    (_FWS, "Waiver Record", "Waived Fee Amount"): "27",
    (_FWS, "Waiver Record", "Reimbursed Expense Amount"): "27",
    (_REV, "Revenue Contract", "Contract Inception Date"): "15",          # default: the 15 account agreement; row rule names 35, 16, 51, 01
    (_REV, "Revenue Contract", "Termination Notice Period"): "15",        # default: the 15 account agreement; row rule names 35, 16, 51, 01
    (_REV, "Fee Revenue Record", "Fee Basis Average Assets"): "27",       # fund average net assets (Fee Basis Source 'Fund Accounting NAV')
    (_REV, "Fee Revenue Record", "Applied Gross Fee Rate"): "27",         # 27 Fund Expense Accrual.Fee Rate Applied (management fee)
    (_REV, "Fee Revenue Record", "Gross Fee Revenue"): "27",              # 27 Fund Expense Accrual.Accrued Expense Amount summed (CW-156)
    (_REV, "Distribution Revenue Record", "Amount Passed Through"): "05", # 12b-1 pass-through calculated in 05
    (_REV, "Client Revenue Record", "Revenue Channel"): "06",             # 06 Account Channel Assignment (CHASG-) at period end
    (_REV, "Client Revenue Record", "Client Segment at Period End"): "02",
    (_REV, "Client Revenue Record", "Revenue Business Line"): "06",       # 06 Account Channel Assignment.Assigned Business Line at period end
    (_REV, "Cash Program Economics", "Average Swept Balance"): "50",      # 50 Program Bank Daily Total averaged
    (_REV, "Cash Program Economics", "Average Client Rate Paid"): "50",   # 50 Sweep Rate Tier, balance-weighted
    (_EXP, "Contract Cost Asset", "CDSC Recovery Offset"): "06",          # CDSC collected on 06 redemption transactions (legacy)
    (_PNL, "Profitability Record", "Average AUM Reference"): "06",        # 06 Client Asset Measures (CW-011)
    (_PNL, "Profitability Record", "Client Segment"): "02",
    (_CLE, "Client Acquisition Cost Record", "New Households Acquired"): "04",
    (_CLE, "Pricing Scenario", "Affected Client Assets"): "06",
}

OWNERSHIP_OVERRIDES = {
    # Fiscal periods are mastered by 09 (CD-083); these codes identify a 09 period and are not typed Reference
    (_REV, "Fee Revenue Record", "Revenue Accounting Period"): "09",
    (_REV, "Client Revenue Record", "Client Revenue Period"): "09",
    (_REV, "Cash Program Economics", "Economics Period"): "09",
    (_EXP, "Accrual", "Accrual Period"): "09",
    (_COA, "Control", "Control Period"): "09",
    (_ALC, "Allocation Run", "Run Period"): "09",
    (_PNL, "Profitability Record", "Profitability Period"): "09",
    (_HIR, "Hierarchy Restatement", "Restated From Period"): "09",
    (_HIR, "Hierarchy Restatement", "Restated To Period"): "09",
    (_BUD, "Plan Version", "Plan Fiscal Year"): "09",
    (_BUD, "Plan Line", "Plan Period"): "09",
    (_ICT, "Intercompany Charge", "Charge Period"): "09",
    # Driver measure is a 06 certified measure code (MSR-, CD-043)
    (_ALC, "Allocation Driver", "Driver Source Measure"): "06",
}

ROW_OWNERSHIP = {
    (_REV, "Revenue Contract", "Underlying Agreement"):
        "Row rule (CD-232, CW-156): owner = 35 on 'Investment Advisory Agreement (Fund)' rows (ADVA-) and on 'Principal Underwriting / "
        "Distribution Agreement' rows (the underwriting contract the board approves under Investment Company Act section 15(b)); 15 on "
        "'Advisory Agreement (Client)' and 'Brokerage Customer Agreement' rows (AAG-); 16 on 'Plan Recordkeeping Agreement' rows (PSVA-); "
        "51 on 'Trust Agreement' rows (TRUST-); 01 on mandate rows (MND-); 05 on intermediary selling and servicing agreement rows (AGR-).",
    (_REV, "Revenue Contract", "Contract Inception Date"):
        "Row rule: copied from the Underlying Agreement's owner: 15 (default, client agreements), 35 (fund advisory and underwriting), "
        "16 (plan recordkeeping), 51 (trust), 01 (mandate), 05 (intermediary servicing).",
    (_REV, "Revenue Contract", "Termination Notice Period"):
        "Row rule: copied from the Underlying Agreement's owner as for Contract Inception Date; fund advisory rows carry the 60 days of "
        "Investment Company Act section 15(a)(3).",
    (_REV, "Client Revenue Record", "Source Calculation Record"):
        "Row rule (CW-156; program-lead rulings 1 and 4): owner = 47 on advisory, wrap, planning, subscription, OCIO, plan recordkeeping and "
        "trust fee rows (Account Fee Calculation or Fee Invoice; 16 and 51 hold only the terms), on account service charge rows (Fee Debit) "
        "and on correction rows (Fee Adjustment); 48 on commission and markup rows (Client Trade Confirmation.Commission Charged and Markup "
        "Markdown Amount) with the 49 Client Account Activity posting as a second source; 49 on margin interest rows (Client Account "
        "Activity) and fully paid lending rows (Fully Paid Securities Loan: 49 holds only the client's rate, so the firm share is derived "
        "here from the loan's quantity, collateral and client rate by the documented lending revenue rule until 49 holds it; proposals NOTES); "
        "50 on Bank Sweep Fee rows (Sweep Allocation balance used to allocate Cash Program Economics.Program Bank Fee Earned). Multi-valued: "
        "the row amount is the month's sum of its sources.",
    (_REV, "Client Revenue Record", "Revenue Account / Household"):
        "Row rule: owner = 15 on account-grain rows (ACC-, default); 47 on household-grain rows (Fee Household, FHHG-; lever); 16 on "
        "plan-paid rows (Service Arrangement, PSVA-).",
    (_REV, "Performance Fee Record", "Performance Fee Terms Reference"):
        "Row rule (CW-051, CW-156; program-lead ruling: 47 owns mandate performance fee terms): owner = 01 on own-fund share class rows "
        "(fund fee terms, FSCH-); 47 on mandate rows (Fee Schedule with Performance Fee Terms, CLFEE-; amount from the Performance Fee "
        "Calculation).",
    (_FWS, "Adviser-Borne Cost", "Adviser-Borne Amount"):
        "Row rule: Derived copy of the 05 Payment Calculation excess on 'Sub-TA Fee Above Fund Cap' and 'Revenue Sharing (Own Resources)' "
        "rows; mastered here on 'Fund Expense Above Cap', 'Fund Organization and Offering Costs' and 'Seed Capital Cost' rows.",
    (_EXP, "Distribution Cost Item", "Funding Source"):
        "Row rule: on intermediary partner payment rows a Derived copy of 05 Payment Arrangement.Funding Source; mastered here ('Adviser - Own "
        "Resources') on every other row.",
    (_EXP, "Distribution Cost Item", "Source Record"):
        "Row rule (CW-159; program-lead ruling 3): owner = 05 on intermediary partner payment rows (Payment Calculation PCL-, Partner Payment "
        "PMT-); 03 on advisor compensation rows (all Compensation Statements of the cost center and period, never one advisor's alone); 04 "
        "on marketing rows (campaign spend); 14 on data license rows; 19 or 40 on supplier invoice rows.",
    (_EXP, "Capitalization Assessment", "Assessed Cost Source"):
        "Row rule (CW-062, CW-159): owner = 03 on incentive plan component rows (ICP-n-Cnn); 05 on payment arrangement rows (PYA-).",
    (_ALC, "Allocation Result", "Target Dimension Member"):
        "Row rule: owner by member type: 02 on Client Household and client rows (PTY-HH-, PTY-; PII - financial, restricted); 15 on account "
        "rows (ACC-); 01 on offering, tier, product and share class rows (OFFR-, SHC-, PRD-); 03 on advisor rows (restricted, CD-344); 05 on "
        "partner firm rows; 09 on legal entity and region rows; mastered here on channel and business line codes and 10 cost pools.",
    (_HIR, "Management Hierarchy Node", "Leaf Member"):
        "Row rule: owner by member type: 01 (OFFR-, SHC-, PRD-), 09 (OU-, LEN-), 19 (chart segment values); channel and business line codes "
        "are shared-list codes held here.",
    (_BUD, "Plan Line", "Plan Dimension Members"):
        "Row rule: owner by member type: 01 (OFFR-, SHC-, PRD-), 05 (partner firm), 09 (LEN-); channel and business line codes are "
        "shared-list codes held here.",
    (_CLE, "Pricing Scenario", "Priced Subject"):
        "Row rule: owner = 01 on service offering rows (OFFR-) and share class rows (SHC-).",
    (_CLE, "Pricing Scenario", "Proposed Schedule Version"):
        "Row rule (CW-158; program-lead ruling 2): owner = 47 on client-fee scenarios (Fee Schedule version, CLFEE-, status Proposed); 36 on "
        "fund expense scenarios (Proposed Term Change, LCHG- / term; 01 holds the value only once the change is effective).",
    (_PNL, "Profitability Record", "Client / Account"):
        "Row rule: owner = 02 on Client Household and client rows (PTY-HH-, PTY-); 15 on account rows (ACC-).",
    (_PNL, "Profitability Record", "Average AUM Reference"):
        "Row rule (CW-011): Derived copy of 06 Client Asset Measures.Average Client Assets (mean of daily values over the period) on "
        "client, household, offering, channel and segment rows; of 27 fund average net assets on product and share class rows.",
}

SUMMARY = {
    "masters": "Masters, for the wealth manager's US entities, revenue contracts and performance obligations, booked own-fund fee, performance fee and distribution revenue records, client revenue records per account, offering, stream and period, cash program economics, fund-level waivers and adviser-borne costs, cost items and accruals, contract cost assets and capitalization assessments, mappings of management P&L lines to 19 GL accounts and reconciliation controls, cost pools, allocation methods, drivers, rules, runs and results, profitability records, measures and cost-to-serve profiles, client acquisition cost records, lifetime value models and household estimates, pricing scenarios and their results, management hierarchies and restatements, budget and forecast plan versions, plan lines, flow and revenue forecasts and variances, and intercompany agreements, transfer pricing policies and charges.",
    "references": "References fund fee terms, products, share classes, mandates, service offerings and tiers from 01 Investment Product & Service Offering; parties, Client Households and segments from 02 Client & Household; advisors, compensation statements and incentive plan components from 03 Advisor Organization, Coverage & Supervision; campaigns and acquisition milestones from 04; distributor firms, payment arrangements and calculations from 05 (intermediary channel only); flow transactions, client asset measures and channel and business line assignments from 06; legal entities, org units and fiscal periods from 09; competitor pricing observations from 11; service requests from 13; accounts and account agreements from 15; plan service arrangements and plan fee schedules from 16; GL accounts, ledgers, cost centers, plan versions and transfer pricing documentation from 19; the management fee accruals, waived and reimbursed amounts and fund net assets (Derived copies) from 27; fund advisory agreements from 35; product change initiatives and proposed term changes from 36; fee schedules, Fee Households, calculations, invoices, debits, adjustments and performance fee calculations from 47; client trade confirmations from 48; client account activity and fully paid securities loans from 49; sweep programs, program banks, daily totals, sweep allocations, swept balances and client rates from 50; program bank agreements from 39; trusts from 51; and sub-adviser engagements from 52.",
}
