"""Enrichment for Data Domain 11 Market & Competitive Intelligence (wealth-manager reference model, W4 adaptation; CW-013,
CW-160; contract v0.4): grain, derived copies, ownership overrides, row ownership, summary."""

B, A = "Business Object", "Attribute Group"

_FLW = "Industry Flow & Asset Data"
_MSH = "Market Share"
_CMP = "Competitor Intelligence"
_PEER = "Peer Universes & Peer Funds"
_RAT = "Ratings & Awards"
_FEE = "Fee & Price Benchmarking"
_MSZ = "Market Sizing"
_MKS = "Market Research & Trends"
_WLI = "Institutional Search & Win/Loss"
_HZN = "News & Horizon Scanning"
_SRC = "Data Sourcing Controls"

GRAIN = {
    # Industry Flow & Asset Data
    (_FLW, "Industry Dataset Profile"): ("licensed industry flow, asset or household wealth dataset", B, ""),
    (_FLW, "Industry Data Release"): ("industry dataset x release (as-of date, publication version)", B, ""),
    (_FLW, "Industry Flow Observation"): ("data release x category x channel x vehicle type x market x distributor firm x fund manager x fund or share class", B, ""),
    (_FLW, "Category Mapping"): ("category scheme x external category value x own share class x effective period", B, ""),
    # Market Share
    (_MSH, "Market Share Definition"): ("market share definition", B, ""),
    (_MSH, "Market Share Record"): ("share definition x period end date x period type x category or segment x channel x distributor firm x market x vehicle type", B, ""),
    (_MSH, "Industry Ranking"): ("market share record x ranked firm", A, "Market Share Record"),
    # Competitor Intelligence
    (_CMP, "Competitor Profile"): ("competitor firm or group (02 party)", B, ""),
    (_CMP, "Competitor Metric Snapshot"): ("competitor x as-of date", A, "Competitor Profile"),
    (_CMP, "Competitor Distribution Footprint"): ("competitor x channel", A, "Competitor Profile"),
    (_CMP, "Competitor Offering"): ("competitor x offering", B, ""),
    (_CMP, "Competitor Pricing Observation"): ("competitor offering x price component x observation as-of date [x balance tier lower bound when tiered]", B, ""),
    (_CMP, "Competitor Event"): ("competitor strategic event", B, ""),
    (_CMP, "Competitor Personnel Move"): ("individual x move date (from competitor to competitor)", B, ""),
    # Peer Universes & Peer Funds
    (_PEER, "Peer Universe"): ("peer universe x effective period", B, ""),
    (_PEER, "Peer Universe Member"): ("peer universe x member fund or share class", A, "Peer Universe"),
    (_PEER, "Peer Fund"): ("peer fund or share class (competitor product)", B, ""),
    (_PEER, "Peer Metric Snapshot"): ("peer fund or own share class x snapshot date x return period x peer universe", B, ""),
    # Ratings & Awards
    (_RAT, "Rating Scheme"): ("rating scheme", B, ""),
    (_RAT, "Rating Observation"): ("rated share class or peer fund x rating scheme x rating time period x rating date", B, ""),
    (_RAT, "Medalist Rating Detail"): ("rating observation (Medalist scheme)", A, "Rating Observation"),
    (_RAT, "Sustainability Rating Detail"): ("rating observation (sustainability scheme)", A, "Rating Observation"),
    (_RAT, "Award"): ("award program x award category x recipient x award date", B, ""),
    # Fee & Price Benchmarking
    (_FEE, "Fee Benchmark Study"): ("study subject (own share class, service offering or fee schedule) x comparison set x fee measure x study date", B, ""),
    (_FEE, "Fee Benchmark Result"): ("fee benchmark study (result statistics)", A, "Fee Benchmark Study"),
    (_FEE, "Pricing Input"): ("fee benchmark study (pricing recommendation)", A, "Fee Benchmark Study"),
    # Market Sizing
    (_MSZ, "Market Sizing Record"): ("sizing subject x sizing metric x channel x wealth band x age band x geography x asset class x as-of date", B, ""),
    (_MSZ, "Opportunity Potential"): ("target intermediary firm or advisor x potential as-of date", B, ""),
    (_MSZ, "Plan Market Record"): ("retirement plan x Form 5500 plan year", B, ""),
    # Market Research & Trends
    (_MKS, "Market Research Report"): ("market research report", B, ""),
    (_MKS, "Market Trend"): ("market trend x indicator as-of date", B, ""),
    # Institutional Search & Win/Loss
    (_WLI, "Mandate Search Event"): ("mandate search event (asset owner x mandate x event date)", B, ""),
    (_WLI, "Win/Loss Analysis"): ("analysis segment x analysis period end", B, ""),
    # News & Horizon Scanning
    (_HZN, "Intelligence Item"): ("news or intelligence item", B, ""),
    (_HZN, "Regulatory Horizon Item"): ("regulator x regulatory initiative (updated in place as news items arrive)", B, ""),
    # Data Sourcing Controls
    (_SRC, "Redistribution Restriction"): ("industry dataset profile (redistribution use flag)", A, "Industry Dataset Profile"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    (_CMP, "Competitor Profile", "Competitor Display Name"): "02",
    (_CMP, "Competitor Profile", "Regulatory Identifiers"): "02",
    (_WLI, "Win/Loss Analysis", "Opportunities Decided"): "05",
    # CW-160: the firm's own values in market and benchmark records are Derived copies with their as-of dates.
    (_MSH, "Market Share Record", "Firm Value"): "06",
    (_FEE, "Fee Benchmark Result", "Own Fee Rate"): "01",
    (_MSZ, "Opportunity Potential", "Firm Assets with Party"): "06",
    (_FLW, "Industry Dataset Profile", "Industry Data Provider"): "14",
    (_FLW, "Industry Dataset Profile", "Publication Frequency"): "14",
    (_MKS, "Market Research Report", "Research Publisher"): "14",
    (_SRC, "Redistribution Restriction", "Redistribution Permitted Indicator"): "14",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

ROW_OWNERSHIP = {
    (_PEER, "Peer Metric Snapshot", "Expense Ratio"):
        "Row rule (CD-289): peer fund rows (PFD-) are mastered here from the vendor dataset; own share class rows (SHC-) copy the "
        "01 Share Class Net Expense Ratio as of the snapshot date.",
    (_PEER, "Peer Metric Snapshot", "Total Return"):
        "Row rule (CD-289): peer fund rows (PFD-) are mastered here from the vendor dataset; own share class rows (SHC-) copy the "
        "32 Performance Return for the return period.",
    (_PEER, "Peer Metric Snapshot", "Estimated Net Flow"):
        "Row rule (CD-289): the vendor's published estimate on every row, kept with its release; for own share classes it is an "
        "external observation, never the 06 certified flow measure.",
    (_FEE, "Fee Benchmark Result", "Own Fee Rate"):
        "Row rule (CD-289): copied from the 01 share class net expense ratio when Subject Share Class is set; copied from the "
        "47 Fee Schedule version (Subject Fee Schedule, CLFEE-) when Subject Service Offering is set.",
    (_MSH, "Market Share Record", "Firm Value"):
        "Row rule (CD-289): copied from the 06 certified Measure Value when Numerator Source = 06 Certified Measure; taken from "
        "the licensed industry dataset (14) with the denominator when Numerator Source = Same Industry Dataset.",
}

SUMMARY = {
    "masters": "Masters industry flow and asset dataset profiles, releases and observations, external category mappings and dataset redistribution flags, market share definitions and records and industry rankings, competitor profiles, metrics, channel footprints, competitor offerings and pricing observations (advisory fee rates, commissions, account fees, margin rates, cash sweep yields, expense ratios), strategic events and personnel moves, peer universes, peer funds and peer metrics, rating schemes, fund ratings and industry awards, fee and price benchmark studies and pricing inputs, market sizing by investor segment, wealth and age band and plan market, thin intermediary opportunity potential, market research reports and trends, institutional mandate search events and win/loss analyses, and news and regulatory horizon items.",
    "references": "References own strategies, products, share classes, service offerings and fund expense ratios from 01 Investment Product & Service Offering; competitor, provider, plan, asset owner, recordkeeper and individual parties, segment schemes and vendor identifiers from 02 Client & Household; intermediary firms, consultants and sales opportunities from 05 Intermediary & Institutional Distribution; the certified measures and loads from 06 Client Assets, Flows & Channel Attribution; client fee schedules from 47 Pricing, Fees & Billing; compliance approval of rating and award citations from 08 Retail Conduct & Supervision; geographic units from 09 Shared & Enterprise Reference Data; and licensed datasets, providers, publication frequency and redistribution rights from 14 Third-Party Data & Licensing.",
}
