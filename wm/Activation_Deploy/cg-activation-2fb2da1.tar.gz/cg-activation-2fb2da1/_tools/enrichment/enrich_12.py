"""Enrichment for Data Domain 12: Institutional Client Servicing & Reporting (contract v0.3; wealth-manager adaptation, CW-145)."""

BO, AG = "Business Object", "Attribute Group"

_CLT = "Institutional Client Profile"
_SVC = "Client Service Model"
_RDF = "Report Definition & Content"
_PPR = "Performance & Holdings Presentation"
_RPD = "Report Production & Delivery"
_GBR = "Guideline Monitoring & Breach Reporting"
_CSR = "Client Service Requests & Instructions"
_CRV = "Client Reviews & Relationship Health"
_MOS = "Mandate Operational Set-Up"
_TRM = "Termination & Offboarding"

GRAIN = {
    # Institutional Client Profile
    (_CLT, "Institutional Client"): ("institutional client party (02 PTY- with the Institutional Client role)", BO, ""),
    (_CLT, "Investment Policy Statement"): ("institutional client x IPS version (IPSV-)", BO, ""),
    # Client Service Model
    (_SVC, "Service Relationship"): ("institutional service relationship (institutional client x servicing segment)", BO, ""),
    (_SVC, "OCIO Service Detail"): ("service relationship (OCIO segment: delegation and fiduciary terms)", AG, "Service Relationship"),
    (_SVC, "Plan Sponsor Servicing Detail"): ("plan sponsor service relationship x retirement plan (SVR- / plan PTY-)", BO, ""),
    (_SVC, "Institutional Service Tier"): ("institutional service tier", BO, ""),
    (_SVC, "Service Standard"): ("service standard (SLA metric) x institutional service tier or service relationship x effective date", BO, ""),
    (_SVC, "Service Team"): ("institutional client service team", BO, ""),
    (_SVC, "Service Coverage Assignment"): ("service staff member x service relationship (optionally mandate) x service role x effective period", BO, ""),
    # Report Definition & Content
    (_RDF, "Report Definition"): ("client report definition (catalog entry)", BO, ""),
    (_RDF, "Report Component"): ("reusable report component (content block)", BO, ""),
    (_RDF, "Report Template"): ("report layout and branding template", BO, ""),
    (_RDF, "Report Package"): ("report package (service relationship x set of report definitions x effective period)", BO, ""),
    # Performance & Holdings Presentation
    (_PPR, "Presentation Profile"): ("performance presentation profile x report package or mandate", BO, ""),
    (_PPR, "Portfolio Holdings Presentation"): ("presentation profile (portfolio holdings and look-through settings)", AG, "Presentation Profile"),
    (_PPR, "GIPS Report Provision"): ("report definition (GIPS report settings)", AG, "Report Definition"),
    # Report Production & Delivery
    (_RPD, "Report Schedule"): ("report package or report definition (production calendar offsets)", AG, "Report Package"),
    (_RPD, "Report Run"): ("report run (report package or report definition x reporting period end x version)", BO, ""),
    (_RPD, "Distribution List"): ("report package x recipient x delivery channel", BO, ""),
    (_RPD, "Report Delivery"): ("report run x recipient delivery event", BO, ""),
    # Guideline Monitoring & Breach Reporting
    (_GBR, "Guideline Monitoring Arrangement"): ("client-facing guideline monitoring arrangement per mandate", BO, ""),
    (_GBR, "Breach Notification"): ("guideline breach notification (mandate x restriction x breach detection date)", BO, ""),
    (_GBR, "Compliance Certificate"): ("compliance certificate (certified mandate x certificate period end)", BO, ""),
    # Client Service Requests & Instructions
    (_CSR, "Client Service Request"): ("institutional client service request (case)", BO, ""),
    (_CSR, "Cash Flow Notification"): ("cash flow notification (CFN-)", BO, ""),
    # Client Reviews & Relationship Health
    (_CRV, "Client Review"): ("client review meeting (service relationship x review date)", BO, ""),
    (_CRV, "Relationship Health Score"): ("service relationship x health score date", BO, ""),
    # Mandate Operational Set-Up
    (_MOS, "Mandate Onboarding"): ("mandate onboarding (MND- x onboarding start date)", BO, ""),
    (_MOS, "Client Custodian Account"): ("client custodian account set-up (mandate x custodian x safekeeping account; CUA-)", BO, ""),
    (_MOS, "Cash Flow Arrangement"): ("mandate cash flow notification terms (one per mandate)", BO, ""),
    (_MOS, "Client Data Feed"): ("outbound client data feed (recipient party x content set x transport)", BO, ""),
    (_MOS, "Transition Event"): ("transition event (TRN-)", BO, ""),
    # Termination & Offboarding
    (_TRM, "Mandate Termination"): ("mandate termination (mandate x termination notice)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # CD-013, CD-194: the BIC is the 02 Party Identifier (scheme BIC) of the account provider of the created safekeeping account.
    (_MOS, "Client Custodian Account", "Custodian BIC"): "02",
    # CD-194 option A: the safekeeping account number is mastered on the 28 Safekeeping Account the set-up created.
    (_MOS, "Client Custodian Account", "Safekeeping Account Number"): "28",
    # CD-222: the breach facts are mastered on the 33 Investment Breach (Related Investment Breach).
    (_GBR, "Breach Notification", "Breach Type"): "33",
    (_GBR, "Breach Notification", "Breach Detected Date"): "33",
    (_GBR, "Breach Notification", "Cure Action"): "33",
    (_GBR, "Breach Notification", "Cure Date"): "33",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the institutional client profile of the firm's OCIO, institutional mandate and plan sponsor clients and their "
        "investment policy statement versions; the service model (service relationships with OCIO and plan sponsor servicing "
        "detail, institutional service tiers, service standards, service teams and servicing coverage assignments); the client "
        "reporting catalog and its production (report definitions, components, templates, packages, presentation profiles, "
        "schedules, report runs, distribution lists and deliveries); client-facing guideline monitoring, breach notifications and "
        "compliance certificates; institutional service requests and cash flow notifications; client reviews and relationship "
        "health scores; mandate onboarding and operational set-up (client custodian account set-up, cash flow arrangements, outbound client "
        "data feeds, transitions); and mandate terminations."
    ),
    "references": (
        "References the party core of institutional clients, recipients, signatories, custodians and transition managers, the thin "
        "retirement plan identity, contact points and party identifiers such as BICs from 02 Client & Household; mandates, investment "
        "restrictions, the OCIO service offering, products, benchmarks, GIPS composites and investment commentary from 01; "
        "institutional separate accounts from 15; the relationship manager of record and meeting activities from 03; surveys and "
        "the client portal from 04; consultant advisory relationships, won sales opportunities and data-sharing agreements from 05 "
        "(W4); flow transactions from 06; complaints and compliance reviews from 08; business calendars and internal legal entities "
        "from 09; plan role assignments and recordkeeping service arrangements from 16 (CW-146); employees from 20; the strategic "
        "asset allocation from 24 and external manager engagements from 52 (CW-147); standing settlement instructions from 26 "
        "(CD-155) and safekeeping accounts from 28 (CD-194); investment breaches from 33 (CD-222); contracts from 39; brands from "
        "42; and fee invoices from 47 Pricing, Fees & Billing (CW-012, CW-054)."
    ),
}
