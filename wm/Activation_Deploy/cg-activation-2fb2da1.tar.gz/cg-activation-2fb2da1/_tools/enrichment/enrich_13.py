"""Enrichment for Data Domain 13: Client Service & Communications (wealth-manager reference model, W2 adaptation; contract v0.4)."""

BO, AG = "Business Object", "Attribute Group"

_SRQ = "Client Service Requests & Interactions"
_STM = "Statements, Confirmations & Tax Documents"
_COM = "Regulatory Client Communications"
_DEL = "Delivery Elections & Householding"
_PRX = "Proxy, Voting Choice & Shareholder Meetings"
_BOC = "Intermediary Beneficial-Owner Communications"
_ESC = "Escheatment, Unclaimed Property & Dormancy"
_TAO = "Service Quality, Errors & Remediation"

GRAIN = {
    # Client Service Requests & Interactions
    (_SRQ, "Service Request"): ("client service request (account x request type x received timestamp)", BO, ""),
    (_SRQ, "Request Controls"): ("client service request (signature guarantee and call-back control evidence)", AG, "Service Request"),
    (_SRQ, "Account Maintenance Change"): ("client service request (account maintenance type) x maintained data element", AG, "Service Request"),
    (_SRQ, "Transfer of Ownership & Estate"): ("client service request (ownership transfer, estate or beneficiary claim type)", AG, "Service Request"),
    (_SRQ, "Contact Center Interaction"): ("assisted-service interaction (phone, chat, secure message, video, email or branch)", BO, ""),
    (_SRQ, "Interaction Authentication"): ("contact center interaction x authentication attempt", BO, ""),
    (_SRQ, "QA Review"): ("quality assurance review x reviewed service request or interaction", BO, ""),
    # Statements, Confirmations & Tax Documents
    (_STM, "Investor Document Definition"): ("client document definition (catalog entry)", BO, ""),
    (_STM, "Investor Document"): ("client document issued (document definition x account x recipient x period end x version)", BO, ""),
    (_STM, "Confirmation Delivery"): ("investor document (confirmation subtype) x confirmed client trade confirmation or fund order", AG, "Investor Document"),
    (_STM, "Tax Form Record"): ("information return amount as filed (account x payer x tax year x tax document type x form version x form box)", BO, ""),
    (_STM, "Production Run"): ("document production run (vendor x run date x batch)", BO, ""),
    # Regulatory Client Communications
    (_COM, "Shareholder Communication"): ("client communication (communication type x audience x period or event)", BO, ""),
    (_COM, "Tailored Shareholder Report"): ("shareholder communication (tailored shareholder report subtype)", AG, "Shareholder Communication"),
    (_COM, "Prospectus Delivery"): ("shareholder communication (prospectus delivery subtype)", AG, "Shareholder Communication"),
    (_COM, "Shareholder Notice"): ("shareholder communication (notice to fund shareholders subtype)", AG, "Shareholder Communication"),
    (_COM, "Communication Distribution"): ("communication distribution job (communication x audience x mail date)", BO, ""),
    (_COM, "Recipient Delivery Record"): ("delivery to one recipient: communication distribution job x recipient account, or investor document x recipient", BO, ""),
    # Delivery Elections & Householding
    (_DEL, "E-Delivery Election"): ("delivery election (account or party x document scope x effective period)", BO, ""),
    (_DEL, "Householding Group"): ("Mailing Household (shared address x member accounts)", BO, ""),
    (_DEL, "Mail Hold"): ("account delivery election (mail hold status)", AG, "E-Delivery Election"),
    (_DEL, "Beneficial Owner Disclosure Election"): ("brokerage account x effective period (OBO / NOBO election)", BO, ""),
    # Proxy, Voting Choice & Shareholder Meetings
    (_PRX, "Proxy Campaign"): ("proxy campaign (own fund or trust x shareholder meeting)", BO, ""),
    (_PRX, "Proxy Proposal"): ("proxy proposal (proxy campaign x proposal)", BO, ""),
    (_PRX, "Vote Tally"): ("proxy proposal x tally as-of date", BO, ""),
    (_PRX, "Intermediary Vote Instruction"): ("proxy proposal x voting intermediary x as-of date", BO, ""),
    (_PRX, "Voting Choice Election"): ("shareholder account x own fund x effective period (voting choice)", BO, ""),
    (_PRX, "Issuer Proxy Pass-Through"): ("third-party issuer meeting x brokerage account", BO, ""),
    # Escheatment, Unclaimed Property & Dormancy
    (_ESC, "Lost Shareholder Status"): ("account x lost episode (from First Returned Mail Date until cleared)", BO, ""),
    (_ESC, "Dormancy Assessment"): ("account x reporting state x dormancy assessment cycle", BO, ""),
    (_ESC, "Escheatment Report & Remittance"): ("escheatment report and remittance (reporting state x report year)", BO, ""),
    (_ESC, "Unclaimed Property Reclaim"): ("unclaimed property reclaim (claimant x reclaim case)", BO, ""),
    # Service Quality, Errors & Remediation
    (_TAO, "Service Level Definition"): ("service level definition (client service level or provider SLA metric)", BO, ""),
    (_TAO, "Service Level Measurement"): ("service level definition x measurement period", AG, "Service Level Definition"),
    (_TAO, "Servicing Error"): ("servicing error event (processing, as-of or NAV error)", BO, ""),
    (_TAO, "Shareholder Remediation"): ("servicing error x remediated account", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # CD-189: the NAV error case and its impact are mastered in 27 NAV Error Case / NAV Error Impact.
    (_TAO, "Servicing Error", "NAV Error Magnitude"): "27",
    (_TAO, "Servicing Error", "Materiality Threshold Exceeded Indicator"): "27",
    # Masked TIN as printed; the certified TIN is on the 02 Tax Profile.
    (_STM, "Tax Form Record", "Recipient TIN (Masked)"): "02",
    # CW-122: the fund share register is 29 (Share Register Balance).
    (_PRX, "Proxy Campaign", "Shares Outstanding at Record Date"): "29",
    # CW-082: the option type is the chosen 34 policy's own value.
    (_PRX, "Voting Choice Election", "Chosen Option Type"): "34",
    # CW-090: record-date entitled quantity from 49 Client Corporate Action Entitlement (CLCAE-).
    (_PRX, "Issuer Proxy Pass-Through", "Record Date Entitled Quantity"): "49",
    (_ESC, "Dormancy Assessment", "Owner State of Last Known Address"): "02",
}

OWNERSHIP_OVERRIDES = {
    # Investor documents and their definitions are mastered here (STMT- and document catalog).
    (_STM, "Investor Document", "Document Definition"): "",
    (_STM, "Investor Document", "Original Document"): "",
}

ROW_OWNERSHIP = {
    (_ESC, "Lost Shareholder Status", "First Returned Mail Date"):
        "Row rule (CW-089): mastered here; the value is the earliest Returned Mail Date of the account's 13 Recipient Delivery "
        "Records in the lost episode (every delivery, communications and Investor Documents alike, has one). 02 Postal "
        "Address.Mail Returned Date is a Derived copy of 13.",
    (_SRQ, "Contact Center Interaction", "Interaction ID"):
        "Row rule (03 boundary): 13 masters contact-center and digital service interactions handled by service representatives; "
        "an advisor's own calls and meetings are 03 Advisor Activity; a service case opened from an advisor contact is a 13 "
        "Service Request referencing the 03 activity (Originating Advisor Activity).",
    (_STM, "Investor Document", "Delivery Status"):
        "Summary of the document's Recipient Delivery Record, which masters the outcome and returned mail (CW-089).",
}

SUMMARY = {
    "masters": (
        "Masters client service requests for every account type with their controls, maintenance, ownership-transfer and estate "
        "detail; assisted-service interactions, their authentication attempts and quality reviews; the client document catalog, "
        "issued statements, confirmation delivery, information returns as filed and production runs; periodic and event-driven "
        "regulatory client communications with their distribution jobs and recipient delivery outcomes, including returned mail; "
        "e-delivery elections, Mailing Households, mail holds and beneficial owner disclosure elections; own-fund proxy campaigns, "
        "proposals, tallies and intermediary vote instructions, fund shareholders' voting-choice elections and the pass-through of "
        "third-party issuer proxies to brokerage clients; lost-client, dormancy, escheatment and reclaim records; client service "
        "levels, servicing errors and client remediation. Servicing provider oversight and intermediary beneficial-owner "
        "distribution moved to 29 and intermediary communication fee invoices to 05 at the W2-W4 merge (CW-088)."
    ),
    "references": (
        "References parties, death notifications, identity verifications, consent records, contact points and the masked TIN from "
        "02 Client & Household; accounts, beneficiary designations and account restrictions from 15 Account; advisors and advisor activities from 03; "
        "digital logins and surveys from 04 only by boundary; complaints from 08; internal legal entities from 09; products, share "
        "classes, product documents and lifecycle events from 01; plan notices from 16; issuer meetings from 17 Corporate Action "
        "Event; employees from 20; NAV error cases and their magnitude (derived copies) from 27; fund orders, register transactions and the share register balance (shares outstanding, derived) from 29 (CD-199, CW-122); "
        "voting policies and the chosen option type (derived) from 34; estate settlement cases from 51; client trade confirmations (CCONF-) from 48, client account activity (CLACT-) and "
        "the record-date entitled quantity of the client corporate action entitlement (CLCAE-, derived) from 49, and money movements "
        "(MMVMT-) from 50 (W3); and fee agreements from 05."
    ),
}
