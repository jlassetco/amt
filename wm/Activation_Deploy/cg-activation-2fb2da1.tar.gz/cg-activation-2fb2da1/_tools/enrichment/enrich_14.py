"""Enrichment for Data Domain 14 - Third-Party Data & Licensing (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Data Vendor Relationship
    ("Data Vendor Relationship", "Data Vendor"): ("data vendor (vendor party)", BO, ""),
    ("Data Vendor Relationship", "Vendor Contact Role"): ("data vendor x contact party x contact role type x effective period", BO, ""),
    ("Data Vendor Relationship", "Vendor Performance Review"): ("data vendor x review period", BO, ""),
    # Vendor Risk & Resilience
    ("Vendor Risk & Resilience", "Vendor Risk Assessment"): ("vendor risk assessment (vendor x assessment)", BO, ""),
    ("Vendor Risk & Resilience", "Assurance Report"): ("data vendor x assurance report type x report period", BO, ""),
    # Dataset & Data Product Catalog
    ("Dataset & Data Product Catalog", "Dataset"): ("dataset (licensed vendor data product)", BO, ""),
    ("Dataset & Data Product Catalog", "Dataset Coverage"): ("dataset (coverage and structure)", AG, "Dataset"),
    ("Dataset & Data Product Catalog", "Dataset Key Field"): ("dataset x key field", BO, ""),
    ("Dataset & Data Product Catalog", "Dataset Delivery"): ("dataset (delivery method and technical feed)", AG, "Dataset"),
    ("Dataset & Data Product Catalog", "Dataset Consumption"): ("dataset x consuming application x use case x consumption effective period", BO, ""),
    # Data License Agreement
    ("Data License Agreement", "Data License Agreement"): ("data license agreement (master agreement or order form)", BO, ""),
    ("Data License Agreement", "Licensed Dataset Schedule"): ("data license agreement x licensed dataset x scope effective period", BO, ""),
    ("Data License Agreement", "Termination Obligations"): ("data license agreement (termination and exit terms)", AG, "Data License Agreement"),
    ("Data License Agreement", "Compliance Clauses"): ("data license agreement (audit and usage reporting terms)", AG, "Data License Agreement"),
    # Permitted Use & Rights
    ("Permitted Use & Rights", "Permitted Use Grant"): ("data license agreement x dataset x permitted use category x grant effective period", BO, ""),
    ("Permitted Use & Rights", "Attribution Requirement"): ("data license agreement x attribution and disclaimer requirement (per output type set)", BO, ""),
    # Index & Benchmark Licensing
    ("Index & Benchmark Licensing", "Index Use"): ("index license agreement x licensed index x index use type", BO, ""),
    ("Index & Benchmark Licensing", "Index Product Coverage"): ("licensed index use x covered product or share class x coverage effective period", BO, ""),
    # Entitlements & Access
    ("Entitlements & Access", "Entitlement"): ("entitlement (user, client subscriber or application x dataset x governing license)", BO, ""),
    ("Entitlements & Access", "Market Data Subscriber"): ("client subscriber x status effective date", BO, ""),
    ("Entitlements & Access", "Consuming Application"): ("consuming application", BO, ""),
    # Usage & License Compliance
    ("Usage & License Compliance", "Usage Declaration"): ("usage declaration (data license agreement x declaration type x declaration period)", BO, ""),
    ("Usage & License Compliance", "License Audit"): ("license audit (vendor x audit scope period)", BO, ""),
    ("Usage & License Compliance", "License Compliance Finding"): ("license audit x finding", BO, ""),
    # Data Cost & Commercials
    ("Data Cost & Commercials", "Commercial Terms"): ("data license agreement (commercial terms)", AG, "Data License Agreement"),
    ("Data Cost & Commercials", "Data Invoice"): ("vendor invoice (data license agreement x service period)", BO, ""),
    ("Data Cost & Commercials", "Data Cost Allocation"): ("data license agreement x org unit x allocation effective period", BO, ""),
    ("Data Cost & Commercials", "Renewal Case"): ("renewal case (data license agreement x renewal term)", BO, ""),
    # Vendor Data Quality & Service Levels
    ("Vendor Data Quality & Service Levels", "Vendor Data SLA"): ("dataset x SLA metric x measurement period", BO, ""),
    ("Vendor Data Quality & Service Levels", "Vendor Data Issue"): ("vendor data issue", BO, ""),
}

DERIVED = {
    # Stage 4 consolidation (stage4_consolidation_notes §1): copies of 37-43 masters; row rules in the attribute notes.
    ("Entitlements & Access", "Consuming Application", "Application Name"): "41",
    ("Data Vendor Relationship", "Data Vendor", "Procurement Supplier ID"): "40",
    # Copy of the 19 Payable Invoice ID (CD-158)
    ("Data Cost & Commercials", "Data Invoice", "AP Document Reference"): "19",
    # Vendor name copied from the party master.
    ("Data Vendor Relationship", "Data Vendor", "Vendor Display Name"): "02",
    # AUM declared to the index provider is a copy of AUM measured in 06.
    ("Usage & License Compliance", "Usage Declaration", "Declared AUM"): "06",
}

SUMMARY = {
    "masters": ("Masters the wealth manager's data vendor relationships and vendor risk assessments, the catalog of "
                "licensed datasets with their coverage, key fields, delivery and consumption lineage, the data license "
                "agreements the firm buys with their licensed scope, permitted use, attribution, index use and "
                "termination terms, entitlements (of employees, applications and client subscribers to real-time quotes) and consuming applications, usage declarations and license audits, data "
                "cost (commercial terms, invoices, allocations and renewals), and vendor data SLAs and issues."),
    "references": ("References vendor, contact and index provider parties, client subscribers and the vendor display name from Client & "
                   "Household (02), licensed benchmarks, products and share classes from "
                   "Investment Product & Service Offering (01), employees from Human Capital (20), technical feeds and declared client assets from Client "
                   "Assets, Flows & Channel Attribution (06), internal legal entities and org units from Shared & Enterprise "
                   "Reference Data (09), allocation methods from Client Revenue, Pricing Economics & Profitability (10), and the payable invoice ID "
                   "of each data invoice from Finance & Accounting (19, CD-158)."),
}

OWNERSHIP_OVERRIDES = {
    # CD-264: the 14 profile is keyed by the 41 APPL- key; these reference the 14 profile, so they stay mastered here.
    ("Dataset & Data Product Catalog", "Dataset Consumption", "Consuming Application"): "",
    ("Entitlements & Access", "Entitlement", "Entitled Application"): "",
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    # The two CD-261 row rules on ICT Third-Party Register Entry left with the object (W1b, CW-914).
}
