"""Enrichment for Data Domain 15 - Account (wealth manager, CW-006; contract v0.4): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Account Master
    ("Account Master", "Account"): ("account", BO, ""),
    ("Account Master", "Account Identifier"): ("account x identifier scheme x identifier value x effective period", BO, ""),
    ("Account Master", "Account Hierarchy Link"): ("parent account x child account x link type x effective period", BO, ""),
    ("Account Master", "Account Party Role"): ("account x party x account role type x role effective period", BO, ""),
    # Registration, Ownership & Beneficiaries
    ("Registration, Ownership & Beneficiaries", "Account Registration Detail"): ("account (registration title and legal detail)", AG, "Account"),
    ("Registration, Ownership & Beneficiaries", "Account Investment Profile"): ("account x profile effective period (one row per version, SEC Rule 17a-3(a)(17))", BO, ""),
    ("Registration, Ownership & Beneficiaries", "Custodial Account Detail"): ("account (UTMA / UGMA or guardianship detail)", AG, "Account"),
    ("Registration, Ownership & Beneficiaries", "Retirement Account Detail"): ("account (IRA-family and inherited IRA detail)", AG, "Account"),
    ("Registration, Ownership & Beneficiaries", "Education & Health Savings Account Detail"): ("account (529, Coverdell or HSA detail)", AG, "Account"),
    ("Registration, Ownership & Beneficiaries", "Beneficiary Designation"): ("account x beneficiary party x beneficiary type x effective period", BO, ""),
    # Features & Agreements
    ("Features & Agreements", "Account Feature"): ("account x feature type x effective period", BO, ""),
    ("Features & Agreements", "Options Approval Detail"): ("account feature (options approval)", AG, "Account Feature"),
    ("Features & Agreements", "Margin Account Detail"): ("account feature (margin approval: portfolio margin and margin disclosure)", AG, "Account Feature"),
    ("Features & Agreements", "Cash Sweep Election"): ("account x sweep vehicle x effective period", BO, ""),
    ("Features & Agreements", "Account Agreement"): ("account x agreement type x agreement version", BO, ""),
    ("Features & Agreements", "Account Disclosure Delivery"): ("account x disclosure type x disclosure version x delivery", BO, ""),
    # Programs & Subscriptions
    ("Programs & Subscriptions", "Program Enrollment"): ("account x service offering x enrollment period", BO, ""),
    ("Programs & Subscriptions", "Alternative Investment Subscription"): ("account x feeder product x offering window", BO, ""),
    # Tax, Cost Basis & Distributions
    ("Tax, Cost Basis & Distributions", "Account Tax Certification"): ("account x certifying party x tax form x signed date", BO, ""),
    ("Tax, Cost Basis & Distributions", "Account Tax Reporting Status"): ("account (current withholding and reporting position)", AG, "Account"),
    ("Tax, Cost Basis & Distributions", "Cost Basis Election"): ("account x election scope (account default, fund shares, DRIP shares or share class) x effective period", BO, ""),
    ("Tax, Cost Basis & Distributions", "RMD Record"): ("account (IRA) x distribution year", BO, ""),
    ("Tax, Cost Basis & Distributions", "Retirement Distribution Election"): ("account x withholding election type x effective period", BO, ""),
    # Standing Instructions, Bank Instructions & Preferences
    ("Standing Instructions, Bank Instructions & Preferences", "Account Standing Instruction"): ("standing instruction (account x instruction type x effective period)", BO, ""),
    ("Standing Instructions, Bank Instructions & Preferences", "Bank Instruction"): ("bank instruction (account x bank account on file x effective period)", BO, ""),
    ("Standing Instructions, Bank Instructions & Preferences", "Account Preference"): ("account (servicing preferences)", AG, "Account"),
    # Account Lifecycle & Status
    ("Account Lifecycle & Status", "Account Opening"): ("account (opening, approval and initial funding)", AG, "Account"),
    ("Account Lifecycle & Status", "Account Lifecycle Event"): ("account lifecycle event (account x event type x event timestamp)", BO, ""),
    ("Account Lifecycle & Status", "Account Status History"): ("account x account status x status effective period", BO, ""),
    ("Account Lifecycle & Status", "Account Closure"): ("account (closure detail)", AG, "Account"),
    # Account Restrictions & Eligibility
    ("Account Restrictions & Eligibility", "Account Restriction"): ("account restriction (account x restriction type x effective period)", BO, ""),
    ("Account Restrictions & Eligibility", "New Issue Eligibility"): ("account (FINRA Rule 5130 and 5131 status)", AG, "Account"),
    # Participant, Institutional & Intermediary Accounts
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account"): ("account (participant account of a recordkept plan: participant x plan)", AG, "Account"),
    ("Participant, Institutional & Intermediary Accounts", "Institutional Account"): ("account (institutional separate account)", AG, "Account"),
    ("Participant, Institutional & Intermediary Accounts", "Intermediary Account Servicing"): ("account (intermediary channel servicing)", AG, "Account"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Row rule (CD-194 option A): custodian account numbers of institutional separate accounts are 28 safekeeping numbers.
    ("Account Master", "Account Identifier", "Account Identifier Value"): "28",
    # Values computed from Client Holdings (49) and money movements (50) (CW-007, CW-034, CW-035).
    ("Tax, Cost Basis & Distributions", "RMD Record", "Prior Year-End Value"): "49",
    ("Tax, Cost Basis & Distributions", "RMD Record", "RMD Satisfied Amount"): "50",
    ("Programs & Subscriptions", "Alternative Investment Subscription", "Funded Amount"): "50",
    # Participant facts mastered on 16 investment elections and employment events.
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account", "Default Investment Indicator"): "16",
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account", "Terminated Participant Indicator"): "16",
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account", "Participant Account Status"): "16",          # CW-125
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account", "Participant Account Status Effective From"): "16",
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account", "Participant Enrollment Date"): "16",
    # Trust registration facts of accounts with a Governing Trust (row rules below, CW-075).
    ("Registration, Ownership & Beneficiaries", "Account Registration Detail", "Trust or Agreement Date"): "51",
    ("Registration, Ownership & Beneficiaries", "Account Registration Detail", "Registration Jurisdiction"): "51",
    # The Rule 3a-4 annual contact is the 45 Advice Review (CW-044).
    ("Programs & Subscriptions", "Program Enrollment", "Rule 3a-4 Annual Contact Date"): "45",
}

# Corrections to the automatic resolver.
OWNERSHIP_OVERRIDES = {
    # The participant of a participant account is a reference to the 16 Participant Plan Membership (program lead ruling 4,
    # review B): its PTY- example would otherwise resolve to 02.
    ("Participant, Institutional & Intermediary Accounts", "Plan Participant Account", "Participant"): "16",
}

# Row Ownership Rule (CD-289): where one attribute holds rows mastered here and rows copied from another Data Domain.
ROW_OWNERSHIP = {
    ("Registration, Ownership & Beneficiaries", "Account Registration Detail", "Trust or Agreement Date"):
        "Row rule (CW-075): for an account with a Governing Trust, a Derived copy of 51 Trust Instrument Document.Execution Date of "
        "instrument version 1 of that trust; mastered in 15 for every other registration (partnership agreement, corporate resolution, "
        "plan document).",
    ("Registration, Ownership & Beneficiaries", "Account Registration Detail", "Registration Jurisdiction"):
        "Row rule (CW-075): for an account with a Governing Trust, a Derived copy of 51 Trust.Situs Jurisdiction; mastered in 15 for "
        "every other registration (UTMA state, community property state).",
    ("Account Master", "Account Identifier", "Account Identifier Value"):
        "Row rule (CD-194 option A): where the scheme is 'Custodian Account Number' and the account is an institutional separate account, the value is a Derived copy of 28 Safekeeping Account.Safekeeping Account Number of the SKA- assigned to the account; every other row, including brokerage, transfer agent and recordkeeper numbers, is mastered here.",
}

SUMMARY = {
    "masters": (
        "Masters the account for every account kind the wealth manager carries (brokerage, fund-only, managed advisory, "
        "participant and plan, fiduciary, institutional separate, omnibus, firm proprietary and networked accounts): account "
        "identifiers, hierarchy links and party roles, registration detail, the account investment profile, custodial, IRA, "
        "inherited IRA, 529 and HSA detail, beneficiary designations, account features with options and margin "
        "approval detail, Regulation T account type and intraday margin standard, cash sweep elections, account agreements and opening-disclosure delivery, advisory program enrollment, "
        "alternative-investment subscriptions, account tax certification and reporting status, cost-basis elections, IRA RMD "
        "records and retirement withholding elections, standing and bank instructions, account preferences, opening, lifecycle "
        "events, status history and closure, account restrictions and new-issue eligibility."
    ),
    "references": (
        "References parties, investor profile versions, onboarding cases, identity verifications, client restrictions, investor "
        "qualifications and vulnerability concerns from 02 Client & Household; participant plan memberships, the participant on them and plan role assignments from 16; service offerings, feeder products, offering "
        "windows, share classes and mandates from 01; internal legal entities from 09; employees from 20; service requests from "
        "13; 529 portfolios from 17; contracts from 39; recommendations from 45; account "
        "transfers from 49 and Client Holding values; money movements, sweep programs and program banks from 50; trusts from 51; "
        "and the safekeeping account numbers of institutional separate accounts from 28."
    ),
}
