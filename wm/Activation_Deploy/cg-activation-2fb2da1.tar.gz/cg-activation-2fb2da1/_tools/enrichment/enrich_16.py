"""Enrichment for Data Domain 16: Retirement Plan Administration (contract v0.3)."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Plan Document & Provisions
    ("Plan Document & Provisions", "Plan Document"): ("plan document version (recordkept plan x document type x effective date)", BO, ""),
    ("Plan Document & Provisions", "Plan Amendment"): ("plan amendment (plan document x amendment)", BO, ""),
    ("Plan Document & Provisions", "Plan Type Detail"): ("plan document (plan type, ERISA coverage, safe harbor design and plan year)", AG, "Plan Document"),
    ("Plan Document & Provisions", "Eligibility Provisions"): ("plan document (eligibility and entry provisions)", AG, "Plan Document"),
    ("Plan Document & Provisions", "Deferral & Automatic Features"): ("plan document (deferral, automatic enrollment and catch-up provisions)", AG, "Plan Document"),
    ("Plan Document & Provisions", "Employer Contribution Formula"): ("plan document x employer money source x effective period", AG, "Plan Document"),
    ("Plan Document & Provisions", "Vesting Schedule"): ("plan document x employer money source x effective period", AG, "Plan Document"),
    ("Plan Document & Provisions", "Withdrawal & Forfeiture Provisions"): ("plan document (hardship, cash-out and forfeiture provisions)", AG, "Plan Document"),
    ("Plan Document & Provisions", "SIMPLE IRA & SEP Program Detail"): ("plan document (SIMPLE IRA or SEP program elections)", AG, "Plan Document"),
    # Plan Sponsor, Fiduciaries, Service Roles & Fees
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Plan Sponsor Profile"): ("plan sponsor party (02 PTY-; role profile, CD-143)", BO, ""),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Recordkeeper Profile"): ("recordkeeper party (02 PTY-; role profile, CD-143)", BO, ""),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Retirement Plan Profile"): ("retirement plan (02 PTY-) x plan year", BO, ""),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Plan Service Provider"): ("plan role assignment (Schedule C detail of the provider role)", AG, "Plan Role Assignment"),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Plan Role Assignment"): ("party x plan x plan role type x effective period", BO, ""),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Service Arrangement"): ("recordkeeping service arrangement (one active per plan)", BO, ""),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Plan Fee Schedule"): ("plan fee schedule line (PFEE-: service arrangement x fee component x effective from)", BO, ""),
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Plan Notice"): ("plan notice instance (plan x notice type x due date)", BO, ""),
    # Plan Investment Menu
    ("Plan Investment Menu", "Plan Investment Option"): ("plan menu entry (plan x share class x menu role)", BO, ""),
    ("Plan Investment Menu", "Fund Change Event"): ("plan fund change event", BO, ""),
    ("Plan Investment Menu", "Plan Managed Account Service"): ("retirement plan x service offering (01 OFFR-) x effective period", BO, ""),
    # Participant Eligibility, Enrollment & Elections
    ("Participant Eligibility, Enrollment & Elections", "Participant Plan Membership"): ("participant party x plan", BO, ""),
    ("Participant Eligibility, Enrollment & Elections", "Employment Event"): ("membership x employment event type x event date", BO, ""),
    ("Participant Eligibility, Enrollment & Elections", "Deferral Election"): ("membership x deferral election effective period", BO, ""),
    ("Participant Eligibility, Enrollment & Elections", "Investment Election"): ("membership x plan investment option x election effective period", BO, ""),
    ("Participant Eligibility, Enrollment & Elections", "Participant Distribution Election"): ("membership x distribution election type x effective period", BO, ""),
    ("Participant Eligibility, Enrollment & Elections", "Participant Service Election"): ("membership x service election type x effective period", BO, ""),
    # Contributions & Limits
    ("Contributions & Limits", "Payroll Contribution Batch"): ("sponsor payroll remittance (plan x payroll date x submission)", BO, ""),
    ("Contributions & Limits", "Contribution Record"): ("contribution (CONT-): membership x contribution source x receipt (payroll batch or non-payroll receipt)", BO, ""),
    ("Contributions & Limits", "Rollover Contribution Detail"): ("contribution record (incoming rollover detail)", AG, "Contribution Record"),
    ("Contributions & Limits", "Annual Limit Tracking"): ("membership x limit type x plan year", BO, ""),
    ("Contributions & Limits", "Late Deposit Case"): ("late deposit case (one per late contribution batch)", BO, ""),
    # Participant Loans
    ("Participant Loans", "Plan Loan Provisions"): ("plan document (loan provisions)", AG, "Plan Document"),
    ("Participant Loans", "Participant Loan"): ("participant loan", BO, ""),
    ("Participant Loans", "Loan Repayment"): ("loan x repayment date", BO, ""),
    ("Participant Loans", "Loan Default & Offset"): ("participant loan (default, deemed distribution and offset dates)", AG, "Participant Loan"),
    # Vesting & Forfeitures
    ("Vesting & Forfeitures", "Vesting Service Record"): ("membership x vesting plan year", BO, ""),
    ("Vesting & Forfeitures", "Vested Balance by Source"): ("membership x employer money source x as-of date", BO, ""),
    ("Vesting & Forfeitures", "Forfeiture Record"): ("forfeiture (plan x forfeiting membership x forfeiture date)", BO, ""),
    # Participant Balances & Ledger (CW-915, CW-125)
    ("Participant Balances & Ledger", "Participant Balance"): ("membership x money source x plan investment option x valuation date", BO, ""),
    ("Participant Balances & Ledger", "Participant Ledger Posting"): ("participant ledger posting (PLPST-)", BO, ""),
    ("Participant Balances & Ledger", "Participant Investment Transfer"): ("participant investment transfer (PEXC-: membership x from option x to option x request)", BO, ""),
    # Distributions, Rollovers & Tax Reporting
    ("Distributions, Rollovers & Tax Reporting", "Distribution Request"): ("distribution request", BO, ""),
    ("Distributions, Rollovers & Tax Reporting", "Tax Withholding & 1099-R Detail"): ("distribution request (withholding and Form 1099-R reporting detail)", AG, "Distribution Request"),
    ("Distributions, Rollovers & Tax Reporting", "RMD Calculation"): ("membership x RMD distribution year", BO, ""),
    ("Distributions, Rollovers & Tax Reporting", "QDRO Case"): ("QDRO case (participant membership x domestic relations order)", BO, ""),
    # Rollover Capture & Retail Hand-Off (CW-126)
    ("Rollover Capture & Retail Hand-Off", "Participant Retail Hand-Off"): ("membership x trigger event (PRTHO-)", BO, ""),
    # Compliance Testing & Plan Corrections
    ("Compliance Testing & Plan Corrections", "Nondiscrimination Test"): ("plan x test type x plan year (latest run)", BO, ""),
    ("Compliance Testing & Plan Corrections", "Test Correction"): ("nondiscrimination test x correction method", BO, ""),
    ("Compliance Testing & Plan Corrections", "Plan Correction"): ("plan correction case (plan x failure)", BO, ""),
    # Government Filings & Plan Audit
    ("Government Filings & Plan Audit", "Government Filing"): ("plan x filing form type x plan year", BO, ""),
    ("Government Filings & Plan Audit", "Form 5500 Detail"): ("government filing (Form 5500 series counts and assets)", AG, "Government Filing"),
    ("Government Filings & Plan Audit", "Separated Participant Entry"): ("government filing (Form 8955-SSA) x reported membership", AG, "Government Filing"),
    ("Government Filings & Plan Audit", "Plan Audit"): ("plan x audit plan year", BO, ""),
    # Plan Onboarding, Conversion & Termination
    ("Plan Onboarding, Conversion & Termination", "Plan Conversion"): ("plan conversion project (plan x conversion type)", BO, ""),
    ("Plan Onboarding, Conversion & Termination", "Plan Termination"): ("plan termination (one per plan)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Payroll Employee ID is mastered here: the sponsor's payroll key as delivered by the payroll feed (02 holds no such scheme).
    ("Participant Balances & Ledger", "Participant Balance", "Unit Value Applied"): "27",
    ("Participant Balances & Ledger", "Participant Ledger Posting", "Posting Unit Value"): "27",
    # Form 5500 Detail.Total Plan Assets at Year End and Participants with Balances at Year End, Separated Participant Entry.
    # Deferred Vested Benefit Amount, Retirement Plan Profile.Plan Assets and QDIA Type, Participant Balance.Vested Amount are
    # calculated within 16 from Participant Balance and the menu (CW-125): mastered here, flagged "Calculated from" in Notes.
    # The wholesale DERIVED entry Total Plan Assets at Year End -> 06 is removed (06 no longer holds participant positions).
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# Rows of one attribute that are mastered here and rows that are not (CD-289).
ROW_OWNERSHIP = {
    ("Contributions & Limits", "Contribution Record", "Contribution Batch"):
        "Row rule: filled for payroll contributions only; blank on incoming rollover, automatic portability and corrective "
        "contribution rows, which are keyed by the CONT- id without a batch.",
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Recordkeeper Profile", "Recordkeeper Party"):
        "Row rule: rows for any recordkeeper the firm deals with, mastered here: the firm's own entity, conversion "
        "counterparties, third-party recordkeepers carrying the firm's funds (read by 06) and incumbents of prospect plans "
        "(read by 05).",
    ("Plan Sponsor, Fiduciaries, Service Roles & Fees", "Retirement Plan Profile", "Profile Plan"):
        "Row rule: rows only for plans the firm recordkeeps. Statistics of plans recordkept elsewhere are 11 Plan Market "
        "Record (public Form 5500); no row is held here for them. The same applies to Plan Service Provider.",
    ("Plan Investment Menu", "Plan Managed Account Service", "Fiduciary Basis"):
        "Row rule (29 CFR 2550.404c-5(e)(3)): where Service Availability is a default (QDIA) value, Fiduciary Basis is "
        "ERISA 3(38) Investment Manager, Trustee Fiduciary or Plan Sponsor Fiduciary.",
    ("Participant Balances & Ledger", "Participant Ledger Posting", "Posting Source Record"):
        "Row rule: always a 16 record (contribution, loan, repayment, distribution, forfeiture, fund change, investment transfer or "
        "plan correction); blank on earnings, dividend and fee postings. A transfer sourced from a 46 Trade Proposal keeps the 46 key "
        "on Participant Investment Transfer.Source Trade Proposal, never here.",
}

SUMMARY = {
    "masters": (
        "Masters the workplace retirement recordkeeping of the wealth manager's in-house defined contribution recordkeeper: plan "
        "documents, amendments and design provisions; the plan sponsor, recordkeeper and retirement plan profiles and plan service "
        "provider detail (moved from 02, CW-023); fiduciary and service role assignments, recordkeeping service arrangements, plan fee "
        "schedule lines and statutory notices; the plan investment menu, fund change events and the plan managed account service; "
        "participant plan memberships with employment events and deferral, investment, distribution and service elections; payroll "
        "contribution batches, contribution records with incoming rollover detail, limit tracking and late deposit cases; participant "
        "loans and repayments; vesting service, vested balances and forfeitures; participant balances and participant ledger postings, "
        "the recordkeeping book of record (CW-915, CW-125), and participant investment transfers; distribution requests with "
        "withholding and Form 1099-R detail, RMD calculations and QDRO cases; the participant retail hand-off that measures rollover "
        "capture (CW-126); nondiscrimination tests, test corrections and EPCRS plan corrections; Form 5500 series and 8955-SSA filings, "
        "plan audit support, and plan conversions and terminations."
    ),
    "references": (
        "References the retirement plan identity, sponsors, participants, beneficiaries, alternate payees, fiduciaries, TPAs, external "
        "advisors of record, payroll providers, auditors, recordkeepers and consent records from 02 Client & Household; participant, "
        "receiving IRA and alternate payee accounts and beneficiary designations from 15 Account; share classes, model portfolios and "
        "service offerings from 01; unit values from 27; plan-level fund orders from 29; managed account trade proposals from 46; "
        "client fee schedules from 47; advice engagements from 45; contact center interactions and Form 1099-R documents from 13 Client "
        "Service & Communications; recordkeeping contracts from 39; complaints from 08; and employees from 20."
    ),
}
