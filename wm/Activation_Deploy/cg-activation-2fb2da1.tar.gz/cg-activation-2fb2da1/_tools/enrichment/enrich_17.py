"""Enrichment for Data Domain 17 - Instrument & Issuer Reference (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Instrument Master
    ("Instrument Master", "Instrument"): ("instrument", BO, ""),
    ("Instrument Master", "Instrument Identifier"): ("instrument x identifier scheme x identifier value x effective period", BO, ""),
    ("Instrument Master", "Instrument Relationship"): ("subject instrument x related instrument (or index) x relationship type x effective period", BO, ""),
    ("Instrument Master", "Instrument Setup Request"): ("instrument setup request", BO, ""),
    # Instrument Classification
    ("Instrument Classification", "Instrument Classification Assignment"): ("instrument x classification scheme x classification code x effective period", BO, ""),
    ("Instrument Classification", "Issuer Classification Assignment"): ("issuer party x classification scheme x sector code x effective period", BO, ""),
    ("Instrument Classification", "Regulatory Instrument Classification"): ("instrument x effective period (US regulatory eligibility classifications)", BO, ""),
    # Equity & Fund Terms
    ("Equity & Fund Terms", "Equity Terms"): ("instrument (equity, depositary receipt and preferred terms)", AG, "Instrument"),
    ("Equity & Fund Terms", "Fund Instrument Terms"): ("instrument (terms of a held fund or own share class)", AG, "Instrument"),
    ("Equity & Fund Terms", "Municipal Fund Security Terms"): ("instrument (529 or ABLE plan portfolio issued as a municipal fund security)", AG, "Instrument"),
    # Debt Terms
    ("Debt Terms", "Debt Terms"): ("instrument (debt terms)", AG, "Instrument"),
    ("Debt Terms", "Coupon Schedule"): ("instrument x coupon period", BO, ""),
    ("Debt Terms", "Redemption Schedule"): ("instrument x redemption event type x redemption start date", BO, ""),
    ("Debt Terms", "Municipal Security Terms"): ("instrument (US municipal bond or note terms)", AG, "Instrument"),
    ("Debt Terms", "Securitized Product Terms"): ("instrument (MBS, ABS, CMBS or CLO deal, tranche and collateral terms)", AG, "Instrument"),
    # Derivative Terms
    ("Derivative Terms", "Listed Derivative Contract Terms"): ("instrument (exchange-traded futures or options contract)", AG, "Instrument"),
    ("Derivative Terms", "OTC Derivative Product Terms"): ("instrument (OTC derivative product definition at UPI level)", AG, "Instrument"),
    # Private Market Instruments
    ("Private Market Instruments", "Private Asset Terms"): ("instrument (private equity interest, loan or real asset)", AG, "Instrument"),
    ("Private Market Instruments", "Fund Interest Terms"): ("instrument (limited partner interest in an underlying fund)", AG, "Instrument"),
    # Listings
    ("Listings", "Instrument Listing"): ("instrument x venue MIC x effective period", BO, ""),
    # Issuers & Ratings
    ("Issuers & Ratings", "Issuer Profile"): ("issuer party (issuer role profile keyed by 02 PTY-)", BO, ""),
    ("Issuers & Ratings", "Issuer Relationship"): ("issuer party x related party x relationship type x effective period", BO, ""),
    ("Issuers & Ratings", "Credit Rating Assignment"): ("rated instrument (issue rating) or rated issuer (issuer rating) x credit rating agency x credit rating type x action date", BO, ""),
    # Corporate Action Events
    ("Corporate Action Events", "Corporate Action Event"): ("announced corporate action event on one instrument", BO, ""),
    ("Corporate Action Events", "Corporate Action Option"): ("corporate action event x option number", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
# Own Fund Share Class instruments (CD-154, program lead decision on the review): every fact 01 holds about an own share class
# is a Derived copy owned by 01. For third-party instruments the same attributes are populated by the security master; the
# definitions say so ("Copied from 01 for own share classes; mastered here for third-party and other instruments").
_OWN_01 = "01"
DERIVED = {
    ("Instrument Master", "Instrument", "Instrument Name"): _OWN_01,
    ("Instrument Master", "Instrument", "FISN"): _OWN_01,
    ("Instrument Master", "Instrument", "CFI Code"): _OWN_01,
    ("Instrument Master", "Instrument", "Denomination Currency"): _OWN_01,
    ("Instrument Master", "Instrument", "Country of Issue"): _OWN_01,
    ("Instrument Master", "Instrument", "Issue Date"): _OWN_01,
    ("Equity & Fund Terms", "Fund Instrument Terms", "Fund Vehicle Type"): _OWN_01,
    ("Equity & Fund Terms", "Fund Instrument Terms", "Fund Regulatory Regime"): _OWN_01,
    ("Equity & Fund Terms", "Fund Instrument Terms", "Fund Domicile"): _OWN_01,
    ("Equity & Fund Terms", "Fund Instrument Terms", "Fund Dealing Frequency"): _OWN_01,
    ("Equity & Fund Terms", "Fund Instrument Terms", "Fund Distribution Policy"): _OWN_01,
    ("Equity & Fund Terms", "Fund Instrument Terms", "Money Market Fund Type"): _OWN_01,
    # Scheme node labels and levels are copied from the 09 Classification Scheme register.
    ("Instrument Classification", "Instrument Classification Assignment", "Instrument Classification Label"): "09",
    ("Instrument Classification", "Instrument Classification Assignment", "Instrument Classification Level"): "09",
    ("Instrument Classification", "Issuer Classification Assignment", "Issuer Sector Label"): "09",
    ("Instrument Classification", "Issuer Classification Assignment", "Issuer Sector Level"): "09",
}

# Per-row ownership (CD-289): 529 and ABLE plan portfolios. Rule text only; the flag stays as declared.
_MFS_RULE = ("Where the firm is the plan's program manager, the plan's portfolios are its own products (01) and this value is a "
             "Derived copy of 01; otherwise 17 masters it for the third-party plan portfolio.")
ROW_OWNERSHIP = {("Equity & Fund Terms", "Municipal Fund Security Terms", a): _MFS_RULE
                 for a in ("Municipal Fund Security Type", "Plan Sponsoring State", "Program Manager", "Plan Sales Channel",
                           "Plan Portfolio Allocation Type", "Target Enrollment Year")}

# Every reference resolves without help since the Stage 1 consolidation registered the 17-21 prefixes and EMP- to 20.
OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    "masters": (
        "Masters the security master of the wealth manager for every instrument its funds and institutional portfolios hold, "
        "trade, price or reference as an underlying and every instrument its clients can buy or hold on the brokerage platform "
        "(equity, depositary receipts, fixed income including municipal securities and brokered certificates of deposit, money "
        "market instruments, third-party funds, own share classes, 529 and ABLE portfolios as municipal fund securities, listed "
        "futures and options at OCC series level, OTC derivative products at UPI level, private assets and LP fund interests): "
        "instrument identifiers across schemes (including the OSI option symbol), instrument relationships, new-instrument setup "
        "requests, instrument and issuer classification assignments and US regulatory instrument classifications, equity, fund, "
        "municipal fund security, debt, municipal, securitized, derivative, private asset and fund-interest terms with coupon and "
        "redemption schedules, the instrument-level fractional and extended-hours trading eligibility flags, listings of "
        "third-party instruments, issuer profiles and issuer relationships (the issuer role on a 02 party), credit ratings by "
        "NRSROs, and corporate action event reference with event options."
    ),
    "references": (
        "References issuers, guarantors, bond insurers, depositary and agent banks, 529 program managers, fund managers and general "
        "partners, collateral managers, clearing houses, offerors and numbering agencies as parties from the 02 party core; own "
        "share classes, products and benchmarks from 01 Investment Product (for own share classes held as instruments, "
        "identifiers, name, FISN, CFI, currency, issue date, vehicle, regime, domicile, dealing and distribution terms are derived "
        "copies of 01) and the 01 Tradable Universe Policy Rule that sets the fractional and extended-hours flags (CW-037); "
        "calendars, classification schemes and scheme node labels from 09 Shared & Enterprise Reference Data; licensed datasets "
        "from 14 Third-Party Data & Licensing; peer funds from 11 Market & Competitive Intelligence; and employees from 20 Human "
        "Capital. Fund and institutional portfolio holdings in 18, client holdings in 49, client orders in 48, and prices (22), "
        "fund desk trades (25, 26) and corporate action entitlements (28, 49) reference the instruments and events mastered here."
    ),
}
