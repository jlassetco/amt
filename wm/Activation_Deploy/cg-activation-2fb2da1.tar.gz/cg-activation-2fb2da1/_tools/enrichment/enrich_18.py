"""Enrichment for Data Domain 18 - Portfolio & Investment Book of Record (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Portfolio Master
    ("Portfolio Master", "Portfolio"): ("portfolio (managed book)", BO, ""),
    ("Portfolio Master", "Portfolio Identifier"): ("portfolio x identifier scheme x identifier value x effective period", BO, ""),
    ("Portfolio Master", "Portfolio Implementation Link"): ("portfolio x implemented product / mandate / account / model x link type x effective period", BO, ""),
    ("Portfolio Master", "Portfolio Hierarchy Link"): ("parent portfolio x child portfolio x link type x effective period", BO, ""),
    ("Portfolio Master", "Portfolio Accounting Basis"): ("portfolio (IBOR conventions)", AG, "Portfolio"),
    ("Portfolio Master", "Portfolio Lifecycle Event"): ("portfolio x lifecycle event type x event effective date", BO, ""),
    # Business-Line Detail
    ("Business-Line Detail", "Fund Portfolio Detail"): ("portfolio (pooled fund book)", AG, "Portfolio"),
    ("Business-Line Detail", "SMA Portfolio Detail"): ("portfolio (institutional separate account book or its sleeve, IA line; or sponsor program account book, IC line; CW-009)", AG, "Portfolio"),
    ("Business-Line Detail", "Private Fund Portfolio Detail"): ("portfolio (private fund book)", AG, "Portfolio"),
    # Holdings
    ("Holdings", "Portfolio Holding"): ("portfolio x instrument x holding date x holding view", BO, ""),
    ("Holdings", "Holding Valuation"): ("portfolio holding (IBOR valuation)", AG, "Portfolio Holding"),
    ("Holdings", "Derivative Holding Detail"): ("portfolio holding (derivative exposure)", AG, "Portfolio Holding"),
    ("Holdings", "Fund Interest Holding Detail"): ("portfolio holding (private fund interest)", AG, "Portfolio Holding"),
    # Tax Lots
    ("Tax Lots", "Tax Lot"): ("portfolio x instrument x acquisition lot (current state; history through Lot Relief)", BO, ""),
    ("Tax Lots", "Lot Relief"): ("tax lot x closing portfolio transaction", BO, ""),
    # Cash
    ("Cash", "Cash Balance"): ("portfolio x currency x cash account x balance date x balance type", BO, ""),
    ("Cash", "Projected Cash Movement"): ("portfolio x currency x projected value date x source item", BO, ""),
    ("Cash", "Portfolio Capital Activity"): ("portfolio x (share class or investor class, or client account) x trade date x capital activity type", BO, ""),
    # Portfolio Activity
    ("Portfolio Activity", "Portfolio Transaction"): ("portfolio transaction as booked in the IBOR", BO, ""),
    ("Portfolio Activity", "Transaction Cost & Charge"): ("portfolio transaction (explicit cost components)", AG, "Portfolio Transaction"),
    ("Portfolio Activity", "Portfolio Transaction Event"): ("portfolio transaction x event type x event timestamp", BO, ""),
    # Book Control
    ("Book Control", "Portfolio Position Snapshot"): ("portfolio x snapshot type x as-of timestamp (members: holdings and cash of the business date and holding view)", BO, ""),
    ("Book Control", "Position Adjustment"): ("portfolio x instrument x adjustment date x adjusting portfolio transaction", BO, ""),
    ("Book Control", "Portfolio Valuation Summary"): ("portfolio x valuation as-of date x valuation view", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)". The notes on each attribute name the source
# object and attribute and any row rule (Stage 2 consolidation: CD-167, CD-168, CD-170, CD-174, CD-181).
DERIVED = {
    # Stage 4 consolidation (stage4_consolidation_notes §1): copies of 37-43 masters; row rules in the attribute notes.
    ("Portfolio Master", "Portfolio", "Proprietary Capital Indicator"): "43",
    # 22 Market Data & Pricing: Approved Price, Pricing Analytics Observation, FX Rate Observation, Fair Value Determination
    ("Holdings", "Holding Valuation", "Price Used"): "22",
    ("Holdings", "Holding Valuation", "Price Date"): "22",
    ("Holdings", "Holding Valuation", "Price Source"): "22",
    ("Holdings", "Holding Valuation", "Holding FX Rate"): "22",
    ("Holdings", "Derivative Holding Detail", "Delta Used"): "22",
    ("Holdings", "Fund Interest Holding Detail", "Adjusted NAV"): "22",
    ("Cash", "Cash Balance", "Cash FX Rate"): "22",
    # Row rule: 22 FX Rate Observation for market-rate rows, 25 Execution for executed FX trades (CD-168).
    ("Portfolio Activity", "Portfolio Transaction", "Trade FX Rate"): "22",
    # Row rule: 25 Allocation Cost Detail on rows booked from a trade allocation (CD-174).
    ("Portfolio Activity", "Transaction Cost & Charge", "Commission Amount"): "25",
    ("Portfolio Activity", "Transaction Cost & Charge", "Research Payment Component"): "25",
    # 26 Trade Operations, Settlement & Collateral (CD-181); Encumbered Quantity adds 28 on-loan quantity (row rule).
    ("Holdings", "Portfolio Holding", "Encumbered Quantity"): "26",
    ("Holdings", "Derivative Holding Detail", "Initial Margin Posted"): "26",
    ("Portfolio Activity", "Portfolio Transaction", "Settlement Confirmed Indicator"): "26",
    # ETF transparency (daily holdings publication) is a product term mastered in 01.
    ("Business-Line Detail", "Fund Portfolio Detail", "Daily Holdings Publication Indicator"): "01",
}

# Every reference resolves without help since the Stage 1 consolidation registered the 17-21 prefixes and EMP- to 20.
OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    # W1b (CW-918): rewritten to the wealth model (US direct wealth manager; three books of record, CW-007).
    "masters": (
        "Masters the investment book of record for every portfolio the US wealth manager runs: its own mutual funds, ETFs "
        "and CITs (PF line) and its institutional separate accounts and mandates (IA line). It holds the portfolio master and "
        "its identifiers, implementation links to products, institutional mandates, institutional separate accounts and models, "
        "portfolio hierarchy links, IBOR accounting basis and lifecycle events, business-line detail (pooled fund, institutional "
        "separate account and private fund books), portfolio holdings by holding view with their IBOR valuation and derivative "
        "and fund interest detail, tax lots and lot relief, cash balances, projected cash movements and portfolio capital "
        "activity, portfolio transactions with their costs and booking events, position snapshots, position adjustments and "
        "the IBOR valuation summary. It is one of three books of record (CW-007): client holdings, client tax lots and cash in "
        "brokerage and advisory accounts, including retail managed accounts, are 49; fund shareholder positions are 06."
    ),
    "references": (
        "References products, share classes, mandates and model portfolios from 01 Investment Product & Service Offering; "
        "brokers, counterparties, custodians, middle office providers and other providers from 02 Client & Household (party "
        "core); sponsor and consultant program agreements from 05 Intermediary & Institutional Distribution; Fund Shareholder Positions "
        "from 06 Client Assets, Flows & Channel Attribution; legal entities, calendars and FX rate types from 09 Shared & Enterprise "
        "Reference Data; transition events and cash flow notifications from 12 Institutional Client Servicing & Reporting; "
        "institutional separate accounts and mandate accounts from 15 Account; instruments and corporate action events from 17 "
        "Instrument & Issuer Reference; employees from 20 Human Capital; trade allocations from 25 Portfolio Trading & "
        "Execution; and safekeeping accounts from 28 Fund Custody & Asset Servicing. Prices, FX rates, deltas and approved fair "
        "values (22), commissions and soft dollar research components on allocated trades (25), settlement confirmation, "
        "encumbrance and initial margin (26, with 28 on-loan quantity) and the ETF daily-holdings term (01) are held as derived copies."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Portfolio Master", "Portfolio", "Proprietary Capital Indicator"):
        "Derived copy (43) since the Stage 4 consolidation (CD-276). Row rule: 'Y' while the portfolio is the Seed Book of a 43 Seed Capital Commitment whose Seed Commitment Status is Approved, Funded or Partially Redeemed; 'N' otherwise. The only place 18 records seed status.",
    ("Holdings", "Portfolio Holding", "Encumbered Quantity"):
        "Derived copy (CD-181 rule c, row rule): sum of 26 Collateral Balance.Balance Quantity over rows with Balance Direction 'Posted' for the holding's portfolio, instrument and date, across all agreements",
    ("Portfolio Activity", "Portfolio Transaction", "Trade FX Rate"):
        "Row rule (CD-168): for market-rate rows, Derived copy of 22 FX Rate Observation.Spot Rate (or its inverse or a cross); for rows booked from an executed FX trade, derived from 25 Execution.Executed FX Rate converted to base currency (the executed rate, its inverse, or a cross through base with the 22 observation of one leg; far legs use Far Leg FX Rate).",
    ("Portfolio Activity", "Transaction Cost & Charge", "Commission Amount"):
        "Row rule (CD-174): Derived copy of 25 Allocation Cost Detail.Commission Amount on rows booked from a trade allocation; mastered here otherwise.",
    ("Portfolio Activity", "Transaction Cost & Charge", "Research Payment Component"):
        "Row rule (CD-174): Derived copy of 25 Allocation Cost Detail.Research Payment Component on rows booked from a trade allocation; mastered here otherwise.",
}
