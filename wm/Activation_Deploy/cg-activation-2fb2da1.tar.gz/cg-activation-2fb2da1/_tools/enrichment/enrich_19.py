"""Enrichment for Data Domain 19 - Finance & Accounting (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"
_COA, _JNL, _CLS = "Chart of Accounts & Ledgers", "Journals & Balances", "Period Close & Consolidation"
_AP, _AR, _RPT, _PLN, _TAX = "Payables", "Receivables", "Financial & Regulatory Reporting", "Planning & Forecasting", "Corporate Tax"

GRAIN = {
    # Chart of Accounts & Ledgers
    (_COA, "Chart of Accounts"): ("chart of accounts", BO, ""),
    (_COA, "GL Account"): ("chart of accounts x natural account", BO, ""),
    (_COA, "Chart Segment Value"): ("chart of accounts x chart segment x segment value x effective period", BO, ""),
    (_COA, "Ledger"): ("legal entity x accounting basis x ledger currency x ledger role", BO, ""),
    (_COA, "Financial Statement Line"): ("reporting framework x statement line", BO, ""),
    (_COA, "Financial Statement Line Mapping"): ("GL account x statement line x effective period", BO, ""),
    # Journals & Balances
    (_JNL, "Journal Entry"): ("journal entry", BO, ""),
    (_JNL, "GL Posting"): ("journal entry x journal line", BO, ""),
    (_JNL, "GL Account Balance"): ("ledger x account combination x fiscal period x balance type x balance currency", BO, ""),
    # Period Close & Consolidation
    (_CLS, "Accounting Period Status"): ("ledger x fiscal period", BO, ""),
    (_CLS, "Close Task"): ("close cycle (fiscal period) x ledger x close task", BO, ""),
    (_CLS, "Consolidation Scope Entity"): ("consolidation group x consolidated unit (legal entity, fund product or seed portfolio) x fiscal period", BO, ""),
    (_CLS, "Intercompany Balance"): ("reporting entity x counterparty entity x intercompany GL account x fiscal period", BO, ""),
    # Payables
    (_AP, "Payable Invoice"): ("supplier invoice, credit note or prepayment request (AP voucher)", BO, ""),
    (_AP, "Payable Invoice Line"): ("payable invoice x invoice line", BO, ""),
    (_AP, "Indirect Tax Detail"): ("payable invoice line x indirect tax type (sales and use tax, or a foreign VAT or GST)", AG, "Payable Invoice Line"),
    (_AP, "Supplier Payment"): ("payment run item (one outgoing payment)", BO, ""),
    (_AP, "Supplier Payment Application"): ("supplier payment x payable invoice", BO, ""),
    # Receivables
    (_AR, "Receivable Item"): ("debtor (customer party or fund product) x source document", BO, ""),
    (_AR, "Cash Receipt Application"): ("cash receipt x receivable item", BO, ""),
    # Financial & Regulatory Reporting
    (_RPT, "Financial Statement"): ("reporting entity or group x reporting framework x period x statement type", BO, ""),
    (_RPT, "Financial Statement Line Value"): ("financial statement x statement line", BO, ""),
    (_RPT, "Regulatory Financial Return"): ("legal entity x regulator x return type x reporting period", BO, ""),
    # Planning & Forecasting
    (_PLN, "Financial Plan Version"): ("plan cycle x scenario x version", BO, ""),
    (_PLN, "Financial Plan Line"): ("plan version x legal entity x account combination x fiscal period", BO, ""),
    # Corporate Tax
    (_TAX, "Entity Tax Registration"): ("legal entity x tax jurisdiction x tax type x effective period", BO, ""),
    (_TAX, "Tax Return"): ("legal entity x tax jurisdiction x tax type x tax period", BO, ""),
    (_TAX, "Tax Provision"): ("legal entity x fiscal period x tax jurisdiction x provision component", BO, ""),
    (_TAX, "Transfer Pricing Documentation"): ("documented legal entity or group x fiscal year x documentation type", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # 10 holds the TP Policy -> TP Documentation link (10 review ruling 5).
    (_TAX, "Transfer Pricing Documentation", "Covered Intercompany Agreements"): "10",
    # Stage 4 consolidation (stage4_consolidation_notes §1): copies of 37-43 masters; row rules in the attribute notes.
    ("Financial & Regulatory Reporting", "Regulatory Financial Return", "Capital Requirement Amount"): "43",
    ("Financial & Regulatory Reporting", "Regulatory Financial Return", "Capital Resources Amount"): "43",
    # Applied FX rates are copies of 22 FX Rate Observation (CD-153, CD-168).
    (_JNL, "GL Posting", "Applied Exchange Rate"): "22",
    (_JNL, "GL Account Balance", "Applied Exchange Rate"): "22",
}

# Fiscal periods and FX rate types are 09 reference data carried as codes, not typed "Reference (...)" (as in 10), so the
# resolver cannot see them; they are forced to 09. (Employee and journal references resolve without help since the Stage 1
# consolidation registered EMP- to 20 and JNL- to 19, CD-151 and CD-152.)
_FP09 = [
    (_JNL, "Journal Entry", "Posting Accounting Period"),
    (_JNL, "GL Account Balance", "Balance Fiscal Period"),
    (_CLS, "Accounting Period Status", "Status Fiscal Period"),
    (_CLS, "Accounting Period Status", "Translation Rate Type"),
    (_CLS, "Accounting Period Status", "Balance Sheet Translation Rate Type"),
    (_CLS, "Close Task", "Close Cycle Period"),
    (_CLS, "Consolidation Scope Entity", "Scope Fiscal Period"),
    (_CLS, "Intercompany Balance", "Intercompany Period"),
    (_PLN, "Financial Plan Version", "Plan Fiscal Year"),
    (_PLN, "Financial Plan Version", "Actuals Through Period"),
    (_PLN, "Financial Plan Line", "Plan Line Period"),
    (_TAX, "Tax Return", "Return Tax Period"),
    (_TAX, "Tax Provision", "Provision Fiscal Period"),
    (_TAX, "Transfer Pricing Documentation", "TP Documentation Fiscal Year"),
]
OWNERSHIP_OVERRIDES = {k: "09" for k in _FP09}

SUMMARY = {
    "masters": (
        "Masters the corporate books of every legal entity of the US wealth manager group (holding company, advisers, self-clearing broker-dealer, transfer agent, recordkeeper, service company and optional trust company): charts of accounts, GL accounts (GLA-) and chart segment "
        "values including cost and profit center codes, ledgers by entity, accounting basis, currency and role (LDG-), with the "
        "accounting company code mastered as the Company segment value, financial statement lines and line mapping, journal entries (JNL-) and GL postings from every subledger, GL account balances, accounting "
        "period status and close tasks, consolidation scope and intercompany balances, payable invoices (APV-), invoice lines, "
        "indirect tax, supplier payments and their application to invoices, receivable items and cash receipt application, financial statements, statement "
        "line values and regulatory financial returns (FOCUS, Form ADV financial items, Call Report), enterprise financial plan versions (FPL-) and plan lines, and corporate "
        "tax registrations, tax returns (TAXR-), tax provisions and transfer pricing documentation (master files, local files "
        "and country-by-country reports)."
    ),
    "references": (
        "References internal legal entities, org units, fiscal calendars and periods and FX rate types from 09 Shared & "
        "Enterprise Reference Data; suppliers, customers, auditors and tax authorities from 02 Client & Household; fee revenue "
        "records, waiver records, cost items, accruals, contract cost assets, allocation runs and intercompany agreements and "
        "charges, client revenue records and cash program economics from 10 Client Revenue, Pricing Economics & Profitability; partner "
        "invoices and payments and intermediary communication fee invoices from 05 Intermediary & Institutional Distribution; fee "
        "invoices from 47 Pricing, Fees & Billing; data invoices from 14 Third-Party Data & Licensing; "
        "consolidated funds and fund debtors from 01 Investment Product & Service Offering; employees and payroll run identifiers from 20 Human Capital; and seed portfolios from "
        "18 Portfolio & Investment Book of Record."
    ),
}
