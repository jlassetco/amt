"""Enrichment for Data Domain 20 - Human Capital (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Employee Master
    ("Employee Master", "Employee"): ("employee (EMP-), HR-mastered", BO, ""),
    ("Employee Master", "Employee Reporting Line"): ("reporting employee x line manager x reporting line type x effective period", BO, ""),
    ("Employee Master", "Employee Personal Detail"): ("employee (personal and work-authorization detail)", AG, "Employee"),
    ("Employee Master", "Employee Diversity Profile"): ("employee (self-identified diversity data)", AG, "Employee"),
    ("Employee Master", "Contingent Worker Detail"): ("employee of type contractor, consultant or inbound secondee (current engagement only)", AG, "Employee"),
    # Jobs, Positions & Assignments
    ("Jobs, Positions & Assignments", "Job Profile"): ("job profile (JOB-)", BO, ""),
    ("Jobs, Positions & Assignments", "Workforce Position"): ("authorized workforce position (WFP-) x effective period", BO, ""),
    ("Jobs, Positions & Assignments", "Employee Job Assignment"): ("employee x workforce position (or job profile) x assignment type x effective period", BO, ""),
    ("Jobs, Positions & Assignments", "Org Unit Assignment"): ("employee x org unit x effective period", BO, ""),
    # Lifecycle & Recruiting
    ("Lifecycle & Recruiting", "Employee Lifecycle Event"): ("employee lifecycle event (ELE-: employee x event type x effective date)", BO, ""),
    ("Lifecycle & Recruiting", "Leave of Absence"): ("employee x leave type x leave period", BO, ""),
    ("Lifecycle & Recruiting", "Job Requisition"): ("job requisition (JRQ-)", BO, ""),
    ("Lifecycle & Recruiting", "Candidate Application"): ("candidate (ATS candidate ID) x job requisition", BO, ""),
    ("Lifecycle & Recruiting", "Background Screening"): ("employee or candidate application x screening type x screening completed date", BO, ""),
    # Compensation, Benefits & Payroll
    ("Compensation, Benefits & Payroll", "Base Pay Record"): ("employee x pay component x effective period", BO, ""),
    ("Compensation, Benefits & Payroll", "Variable Compensation Award"): ("variable compensation award (VPA-)", BO, ""),
    ("Compensation, Benefits & Payroll", "Deferred Award Tranche"): ("variable compensation award x vesting tranche", BO, ""),
    ("Compensation, Benefits & Payroll", "Benefit Plan"): ("benefit plan offered by an employing entity x plan year", BO, ""),
    ("Compensation, Benefits & Payroll", "Benefit Enrollment"): ("employee x benefit plan x coverage period", BO, ""),
    ("Compensation, Benefits & Payroll", "Payroll Run"): ("payroll run (legal entity x pay period x run sequence)", BO, ""),
    ("Compensation, Benefits & Payroll", "Payroll Result"): ("employee x payroll run", BO, ""),
    # Performance & Talent
    ("Performance & Talent", "Performance Review"): ("employee x review cycle x review type", BO, ""),
    ("Performance & Talent", "Performance Objective"): ("employee x review cycle x objective", BO, ""),
    ("Performance & Talent", "Succession Plan Entry"): ("workforce position x successor employee", BO, ""),
    # Learning & Competence
    ("Learning & Competence", "Learning Item"): ("learning item (course, curriculum or qualification)", BO, ""),
    ("Learning & Competence", "Learning Completion"): ("employee x learning item x assignment (due date) or completion", BO, ""),
    ("Learning & Competence", "Mandatory Training Requirement"): ("mandatory training requirement x applicable population x effective period", BO, ""),
    # Workforce Analytics
    ("Workforce Analytics", "Human Capital Metric Value"): ("metric definition x org unit or legal entity or country x breakdown x period", BO, ""),
}

# No attribute holds an untyped copy of a value mastered in another Data Domain.
DERIVED = {}

# Candidate Application, Benefit Plan, Learning Item and Mandatory Training Requirement are objects of this domain keyed by
# source-system codes without an enterprise prefix or a concept ownership row, so references to them are forced local.
# (Employee, job, position, payroll run and journal references resolve without help since the Stage 1 consolidation.)
OWNERSHIP_OVERRIDES = {
    # Kept (W5): same-domain references to 20 objects with no registered prefix or concept row; mastered here.
    ("Lifecycle & Recruiting", "Background Screening", "Screened Candidate Application"): "",
    ("Compensation, Benefits & Payroll", "Benefit Enrollment", "Enrolled Benefit Plan"): "",
    ("Learning & Competence", "Learning Completion", "Completed Learning Item"): "",
    ("Learning & Competence", "Learning Completion", "Satisfied Training Requirement"): "",
    ("Learning & Competence", "Mandatory Training Requirement", "Required Learning Item"): "",
}

SUMMARY = {
    "masters": (
        "Masters the enterprise employee master (EMP-, moved from 09 under CD-151) of the US wealth manager, with personal, "
        "work-authorization, self-identified diversity and contingent-worker detail, line-management reporting lines and org "
        "unit assignments, job profiles (with the FINRA registration categories and investment adviser representative status a "
        "role requires), budgeted workforce positions and job assignments, employee lifecycle events and leaves of absence, job "
        "requisitions, candidate applications and background screening, base pay, variable compensation awards (bonus, deferred "
        "awards) with deferral tranches, malus and clawback, benefit plans and enrollments, "
        "payroll runs and payroll results, performance reviews and objectives, succession plan entries, learning items, "
        "completions and mandatory training requirements, and human capital metric values. US only: the EU/UK remuneration "
        "codes and material risk taker identification left under CW-920."
    ),
    "references": (
        "References internal legal entities, org units, office locations and reorganizations from 09 Shared & Enterprise "
        "Reference Data; staffing agencies, screening vendors, benefit and learning providers and the client role of an employee "
        "from 02 Client & Household; products behind fund-linked awards from 01 Investment Product & Service "
        "Offering; compensation statements whose incentive payouts payroll pays from 03 Advisor Organization, Coverage & Supervision; individual registrations "
        "from 08 Retail Conduct & Supervision; the firm's own 401(k) participant plan memberships from 16 Retirement Plan "
        "Administration; cost centers, financial plan lines and the journal entries that post each payroll run from 19 Finance & Accounting; and metric "
        "definitions from 21 Data Governance & Analytics."
    ),
}
