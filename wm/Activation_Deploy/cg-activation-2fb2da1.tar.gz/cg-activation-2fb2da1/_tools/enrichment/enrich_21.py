"""Enrichment for Data Domain 21 - Data Governance & Analytics (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Ownership & Stewardship
    ("Ownership & Stewardship", "Data Governance Body"): ("data governance body (council, committee or working group)", BO, ""),
    ("Ownership & Stewardship", "Data Ownership Assignment"): ("governed scope x governance role x employee x effective period", BO, ""),
    # Glossary & Taxonomy Registry
    ("Glossary & Taxonomy Registry", "Business Term"): ("business term", BO, ""),
    ("Glossary & Taxonomy Registry", "Business Term Relationship"): ("business term x related term or taxonomy element x relationship type", BO, ""),
    ("Glossary & Taxonomy Registry", "Taxonomy Element"): ("taxonomy element (L1 to L4), stable across releases", BO, ""),
    ("Glossary & Taxonomy Registry", "Taxonomy Release"): ("taxonomy release", BO, ""),
    ("Glossary & Taxonomy Registry", "Taxonomy Element Registration"): ("taxonomy element x taxonomy release", BO, ""),
    ("Glossary & Taxonomy Registry", "Governance Decision"): ("governance decision (decision log entry)", BO, ""),
    # CDEs & Classification
    ("CDEs & Classification", "Critical Data Element"): ("taxonomy element (L4) x CDE scope x scoped data product or regulatory driver x effective period", BO, ""),
    ("CDEs & Classification", "Data Classification Assignment"): ("taxonomy element or data asset x classification scheme x effective period", BO, ""),
    # Data Quality
    ("Data Quality", "Data Quality Rule"): ("data quality rule", BO, ""),
    ("Data Quality", "Data Quality Result"): ("data quality rule x execution timestamp x tested scope (data asset or feed load)", BO, ""),
    ("Data Quality", "Data Quality Issue"): ("data quality issue", BO, ""),
    # Catalog & Lineage
    ("Catalog & Lineage", "Data Asset"): ("cataloged data asset", BO, ""),
    ("Catalog & Lineage", "Analytics Report & Dashboard Detail"): ("data asset of type analytics report or dashboard", AG, "Data Asset"),
    ("Catalog & Lineage", "Data Element Mapping"): ("data asset x physical element x taxonomy element (L4)", BO, ""),
    ("Catalog & Lineage", "Lineage Link"): ("source asset (or element) x target asset, client feed or client report (or element) x transformation", BO, ""),
    ("Catalog & Lineage", "System of Record Designation"): ("taxonomy object or attribute x system x designation type x business line scope x effective period", BO, ""),
    # Record Governance Metadata
    ("Record Governance Metadata", "Retention Rule"): ("retention rule (record class x governing requirement x effective period; RET-)", BO, ""),
    ("Record Governance Metadata", "Object Governance Profile"): ("L3 Data Business Object x effective period", BO, ""),
    ("Record Governance Metadata", "Record Governance Metadata"): ("governed record (Data Domain x object x record key) x record version", BO, ""),
    # Metrics, Data Products & Contracts
    ("Metrics, Data Products & Contracts", "Metric Definition"): ("metric definition", BO, ""),
    ("Metrics, Data Products & Contracts", "Data Product"): ("data product", BO, ""),
    ("Metrics, Data Products & Contracts", "Data Product Input"): ("data product x taxonomy element", BO, ""),
    ("Metrics, Data Products & Contracts", "Data Contract"): ("data product x consumer x contract version", BO, ""),
    ("Metrics, Data Products & Contracts", "Semantic Model Binding"): ("data product (publication in a semantic model)", AG, "Data Product"),
    # AI & Model Data Governance
    ("AI & Model Data Governance", "AI Use Case"): ("AI use case", BO, ""),
    ("AI & Model Data Governance", "AI Risk Classification"): ("AI use case (risk classification)", AG, "AI Use Case"),
    ("AI & Model Data Governance", "AI Data Usage Approval"): ("AI use case x data asset x approval", BO, ""),
}

# No attribute holds an untyped copy of a value mastered elsewhere: element names and definitions on Taxonomy Element
# Registration are the registered (published) form of the element, which this domain masters as a governed record.
DERIVED = {}

_F = {
    "OWN": "Ownership & Stewardship", "GLS": "Glossary & Taxonomy Registry", "CDE": "CDEs & Classification",
    "DQM": "Data Quality", "CAT": "Catalog & Lineage", "RGM": "Record Governance Metadata",
    "ANL": "Metrics, Data Products & Contracts", "AIG": "AI & Model Data Governance",
}

# References to objects of this domain that carry no prefix and have no concept ownership row (Taxonomy Release, Data
# Governance Body, Data Quality Result, Critical Data Element), so the resolver cannot see them; they are forced local.
# (Employee references and references to the prefixed 21 masters resolve without help since the Stage 1 consolidation.)
_INTERNAL = [
    ('OWN', 'Data Governance Body', 'Parent Governance Body'),
    ('OWN', 'Data Ownership Assignment', 'Governed Element Registered In Release'),
    ('OWN', 'Data Ownership Assignment', 'Appointing Governance Body'),
    ('GLS', 'Taxonomy Release', 'Predecessor Release'),
    ('GLS', 'Taxonomy Element', 'First Registered Release'),
    ('GLS', 'Business Term Relationship', 'Related Element Registered In Release'),
    ('GLS', 'Governance Decision', 'Applied In Release'),
    ('GLS', 'Taxonomy Element Registration', 'Registering Release'),
    ('CDE', 'Critical Data Element', 'CDE Registered In Release'),
    ('CDE', 'Data Classification Assignment', 'Classified Element Registered In Release'),
    ('DQM', 'Data Quality Rule', 'DQ Rule Target Registered In Release'),
    ('DQM', 'Data Quality Issue', 'Raising DQ Result'),
    ('DQM', 'Data Quality Issue', 'Affected CDE'),
    ('CAT', 'System of Record Designation', 'Designated Element Registered In Release'),
    ('CAT', 'Data Element Mapping', 'Mapped Attribute Registered In Release'),
    ('RGM', 'Record Governance Metadata', 'Governed Record Object Release'),
    ('RGM', 'Object Governance Profile', 'Profile Registered In Release'),
    ('ANL', 'Data Product Input', 'Input Registered In Release'),
]

OWNERSHIP_OVERRIDES = {(_F[f], o, a): "" for f, o, a in _INTERNAL}

SUMMARY = {
    "masters": (
        "Masters the governance metadata about the wealth manager's data across its eight business lines (CW-004), stewarded by the Chief Data Office: data governance bodies and "
        "effective-dated data ownership and stewardship assignments; the business glossary and term relationships; the "
        "stable taxonomy element register, taxonomy releases, the per-release registration of every element and the decision log (CD-); Critical Data Elements and "
        "data classification assignments; data quality rules (including the DQR- rules moved from 06), results and issues (DQI-); "
        "the internal data catalog of data assets (DAS-) with analytics report and dashboard detail, physical-to-taxonomy element "
        "mappings, lineage links and element-level system-of-record and authoritative source designations; the records retention schedule (Retention Rule, RET-, moved from 08, CW-068); object governance profiles and the record-level governance "
        "metadata pattern that every Data Domain attaches by reference; the metric and KPI registry (KPI-) with units, aggregation and direction, the data product catalog (DP-) with inputs and upstream products, "
        "data contracts and semantic model bindings; and AI use cases (AIU-), their internal risk tier and NIST AI RMF profile, and AI data usage approvals."
    ),
    "references": (
        "References employees from 20 Human Capital; code lists and org units from 09 Shared & Enterprise Reference Data; data "
        "feeds, loads and flow and client asset measure definitions from 06 Client Assets, Flows & Channel Attribution; licensed datasets and "
        "permitted use grants and vendor data issues from 14 Third-Party Data & Licensing; outbound client data feeds and client report definitions from 12 Institutional Client "
        "Servicing & Reporting; records policies from 38 Corporate Compliance & Regulatory Affairs; profitability measure definitions from "
        "10 Client Revenue, Pricing Economics & Profitability; market share definitions from 11 Market & Competitive Intelligence; and AI "
        "model providers, data providers and external contract consumers as parties from 02 Client & Household. Elements of every other Data Domain are referenced as registered "
        "taxonomy elements, not directly."
    ),
}
