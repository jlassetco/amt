"""Enrichment for Data Domain 22 - Market Data & Pricing (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Pricing Policy
    ("Pricing Policy", "Pricing Policy"): ("pricing policy x version", BO, ""),
    ("Pricing Policy", "Pricing Source Hierarchy Rule"): ("pricing policy x instrument scope x source rank x effective period", BO, ""),
    ("Pricing Policy", "Price Tolerance Rule"): ("pricing policy x instrument scope x tolerance check type x effective period", BO, ""),
    ("Pricing Policy", "Pricing Point"): ("pricing point", BO, ""),
    # Price Observations
    ("Price Observations", "Price Observation"): ("instrument x price type x price origin x source dataset or quoting broker x as-of timestamp", BO, ""),
    ("Price Observations", "Evaluated Price Detail"): ("price observation (evaluated price)", AG, "Price Observation"),
    ("Price Observations", "Broker Quote Detail"): ("price observation (broker quote)", AG, "Price Observation"),
    # Approved Prices & Controls
    ("Approved Prices & Controls", "Approved Price"): ("instrument x pricing point x price date x version (one current version per instrument x pricing point x price date)", BO, ""),
    ("Approved Prices & Controls", "Price Validation Exception"): ("approved price version x tolerance rule x raised timestamp", BO, ""),
    ("Approved Prices & Controls", "Price Override"): ("approved price (instrument x pricing point x price date) x override sequence", BO, ""),
    ("Approved Prices & Controls", "Price Challenge"): ("price challenge", BO, ""),
    # Fair Value & Valuation Governance
    ("Fair Value & Valuation Governance", "Valuation Committee"): ("valuation committee", BO, ""),
    ("Fair Value & Valuation Governance", "Valuation Committee Member"): ("valuation committee x employee x effective period", BO, ""),
    ("Fair Value & Valuation Governance", "Valuation Committee Meeting"): ("valuation committee x meeting date", BO, ""),
    ("Fair Value & Valuation Governance", "Fair Value Determination"): ("fair value determination (FVD-); at most one approved per instrument x valuation date x pricing point x portfolio, the portfolio being mandatory for private fund interests", BO, ""),
    ("Fair Value & Valuation Governance", "Valuation Input"): ("fair value determination x valuation input type", BO, ""),
    ("Fair Value & Valuation Governance", "Fair Value Trigger Event"): ("trigger event x affected market, issuer or instrument x event date", BO, ""),
    ("Fair Value & Valuation Governance", "Fair Value Factor"): ("fair value factor: instrument x pricing date x pricing point x factor source dataset", BO, ""),
    ("Fair Value & Valuation Governance", "Valuation Back-Test"): ("approved price version (and its fair value determination, if any) x comparison type x comparison date", BO, ""),
    # FX & Reference Rates
    ("FX & Reference Rates", "FX Rate Observation"): ("09 FX rate type x currency pair as quoted x rate basis x tenor x as-of timestamp", BO, ""),
    ("FX & Reference Rates", "Reference Rate Fixing"): ("reference rate or inflation index x tenor x fixing value type x fixing date", BO, ""),
    # Curves & Surfaces
    ("Curves & Surfaces", "Curve Definition"): ("curve or volatility surface", BO, ""),
    ("Curves & Surfaces", "Curve Point Observation"): ("curve x as-of date x tenor", BO, ""),
    ("Curves & Surfaces", "Volatility Surface Point"): ("volatility surface x as-of date x expiry x strike", BO, ""),
    # Index Data
    ("Index Data", "Index Level Observation"): ("01 benchmark x level date x index level variant x level currency", BO, ""),
    ("Index Data", "Index Constituent"): ("01 benchmark x instrument x effective date", BO, ""),
    ("Index Data", "Index Change Announcement"): ("01 benchmark x instrument x change type x effective date x announcement date", BO, ""),
    # Instrument Market Data
    ("Instrument Market Data", "Pricing Analytics Observation"): ("instrument x as-of date x source x analytic measure (one approved row per instrument x as-of date x measure)", BO, ""),
    ("Instrument Market Data", "Instrument Factor Observation"): ("instrument x factor type x effective date", BO, ""),
    ("Instrument Market Data", "ETF Market Statistic"): ("own ETF instrument x statistic date", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Row rule (CD-167, plan section 4 item 9): Own Fund Share Class rows copy the 27 share class NAV; other rows are mastered here.
    ("Approved Prices & Controls", "Approved Price", "Approved Price Value"): "27",
    ("Approved Prices & Controls", "Approved Price", "Approved Price Currency"): "27",
    # The swung price exists only on Own Fund Share Class rows: 27 Share Class NAV 'Swung NAV per Share'.
    ("Approved Prices & Controls", "Approved Price", "Own Fund Swung Price"): "27",
    # Ranked Data Provider is the provider of the ranked 14 dataset (program lead decision 8).
    ("Pricing Policy", "Pricing Source Hierarchy Rule", "Ranked Data Provider"): "14",
}

OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    "masters": (
        "Masters the market data and pricing record of the wealth manager (approved prices value its proprietary funds, CITs, advice model portfolios and institutional separate accounts, and the Client Holdings (49)): pricing policies, source hierarchy rules, tolerance rules and pricing "
        "points; price observations from every source with evaluated price and broker quote detail; the Approved Price of every "
        "instrument at every pricing point and date, with its validation exceptions, overrides and vendor price challenges; "
        "valuation committees, members and meetings and the fair value determinations they approve, with private asset "
        "valuation detail, valuation inputs, trigger events, fair value factors and back-tests; FX rate observations and "
        "reference rate fixings; curves and volatility surfaces; index levels, constituents and change announcements; approved "
        "pricing analytics, instrument factors and the Rule 6c-11 market statistics of own ETFs."
    ),
    "references": (
        "References benchmarks from 01 Investment Product & Service Offering; outsourced pricing providers, quoting brokers, challenged vendors, "
        "rate administrators, factor publishers and valuation agents from 02 Client & Household; FX rate types, calendars and legal entities from 09 Shared & "
        "Enterprise Reference Data; datasets and vendor data issues from 14 Third-Party Data & Licensing; instruments, listings "
        "and corporate action events from 17 Instrument & Issuer Reference; portfolios and portfolio transactions from 18 "
        "Portfolio & Investment Book of Record; employees from 20 Human Capital; data quality rules from 21 Data Governance & "
        "Analytics; share class NAV records and swing pricing decisions from 27 Fund Accounting & Valuation (the approved price, currency "
        "and swung price of own fund share classes are derived copies of 27). The GP reported NAV and statement date of fund "
        "interests are derived copies of 18, and the data provider of a hierarchy rank is derived from the 14 dataset."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Approved Prices & Controls", "Approved Price", "Approved Price Value"):
        "Row rule (CD-167): for an instrument of 17 Instrument Type 'Own Fund Share Class' the value is a Derived copy from the 27 Share Class NAV record whose parent Fund NAV Calculation is the latest version with NAV Status 'Final' (Original or Re-Strike) for the latest valuation point at or before the pricing point; a later Restatement creates a new Approved Price version and never overwrites the one already used; for every other instrument it is mastered here.",
    ("Approved Prices & Controls", "Approved Price", "Approved Price Currency"):
        "Row rule (CD-167): for an instrument of 17 Instrument Type 'Own Fund Share Class' the value is a Derived copy from the 27 Share Class NAV record whose parent Fund NAV Calculation is the latest version with NAV Status 'Final' (Original or Re-Strike) for the latest valuation point at or before the pricing point; a later Restatement creates a new Approved Price version and never overwrites the one already used; for every other instrument it is mastered here.",
}
