"""Enrichment for Data Domain 23 - Investment Research (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Research Coverage
    ("Research Coverage", "Research Coverage Assignment"): ("analyst x coverage subject (issuer, instrument, sector or country) x coverage role x effective period", BO, ""),
    ("Research Coverage", "Research Universe"): ("research universe", BO, ""),
    ("Research Coverage", "Research Universe Member"): ("research universe x member subject x effective period", BO, ""),
    # Recommendations & Credit Views
    ("Recommendations & Credit Views", "Research Recommendation"): ("subject (issuer, instrument, sector, country or rates market) x recommending analyst x rating scale x recommendation timestamp", BO, ""),
    ("Recommendations & Credit Views", "Recommendation Valuation Basis"): ("research recommendation (valuation basis)", AG, "Research Recommendation"),
    ("Recommendations & Credit Views", "Internal Credit Assessment"): ("assessed party (issuer or trading counterparty) or instrument x credit analyst x internal credit rating scale x effective date", BO, ""),
    # Estimates, Models & Signals
    ("Estimates, Models & Signals", "Analyst Estimate"): ("issuer x analyst x estimate metric x fiscal period x adjusted or reported basis x estimate date", BO, ""),
    ("Estimates, Models & Signals", "Research Model"): ("research model x version", BO, ""),
    ("Estimates, Models & Signals", "Economic Forecast"): ("geography x economic indicator x forecast period x forecast date", BO, ""),
    ("Estimates, Models & Signals", "Research Signal Definition"): ("research signal x version", BO, ""),
    ("Estimates, Models & Signals", "Research Signal Score"): ("research signal version x instrument x as-of date", BO, ""),
    # Research Publications
    ("Research Publications", "Research Publication"): ("research publication x version", BO, ""),
    ("Research Publications", "Publication Subject"): ("research publication x subject", BO, ""),
    ("Research Publications", "Publication Review"): ("research publication version (supervisory review and external release)", AG, "Research Publication"),
    # Issuer Meetings
    ("Issuer Meetings", "Issuer Meeting"): ("issuer meeting", BO, ""),
    ("Issuer Meetings", "Issuer Meeting Participant"): ("issuer meeting x participant x participant role", BO, ""),
    ("Issuer Meetings", "Issuer Meeting Topic"): ("issuer meeting x topic sequence", BO, ""),
    ("Issuer Meetings", "Meeting MNPI Assessment"): ("issuer meeting (MNPI assessment)", AG, "Issuer Meeting"),
    # Third-Party Research
    ("Third-Party Research", "Research Provider Profile"): ("research provider party (role profile keyed by 02 PTY-)", BO, ""),
    ("Third-Party Research", "Research Service Subscription"): ("research provider x research service type x subscribing team x subscription start date", BO, ""),
    ("Third-Party Research", "Research Consumption Record"): ("employee x research provider x interaction type x interaction timestamp", BO, ""),
    ("Third-Party Research", "Research Evaluation Round"): ("research provider x evaluation period x evaluator", BO, ""),
    ("Third-Party Research", "Evaluation Criterion Score"): ("research evaluation round x evaluation criterion", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Price at the recommendation timestamp, copied from the 22 Approved Price (brief §13; CD-167 row rule applies in 22).
    ("Recommendations & Credit Views", "Recommendation Valuation Basis", "Price at Recommendation"): "22",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the investment research record of the wealth manager's investment management arm (proprietary funds, advice model portfolios and institutional separate accounts): research coverage assignments and research universes with their "
        "members; research recommendations (firm-scale rating, change type, conviction, price target, fair value estimate, "
        "horizon) and their valuation basis; internal credit assessments of issuers, trading counterparties and instruments, including Rule 2a-7 minimal credit risk and first "
        "tier determinations; analyst estimates, research models, economic forecasts, quantitative signal definitions and "
        "scores; research publications, their subjects and supervisory review; issuer meetings with participants (including "
        "per-person wall crossing), topics and the MNPI flag; and research provider profiles, research service subscriptions, research consumption records and "
        "research evaluation rounds (the broker vote) with their criterion scores."
    ),
    "references": (
        "References issuers, trading counterparties, research providers, expert networks, corporate access brokers, issuer executives and provider "
        "contacts as parties from 02 Client & Household; instruments from 17 Instrument & Issuer Reference (issuer profiles, "
        "sectors and agency ratings are read there, never copied); classification schemes, geographic units and research "
        "teams as org units from 09 Shared & Enterprise Reference Data; investment strategies and investment commentary from "
        "01 Investment Product & Service Offering; content assets from 04 Marketing, Digital & Client Engagement; licensed datasets and data license agreements from "
        "14 Third-Party Data & Licensing; employees from 20 Human Capital; AI use cases from 21 Data Governance & Analytics; "
        "and approved prices from 22 Market Data & Pricing (price at recommendation is a derived copy). House views are 24 "
        "Investment Committee Decisions and are not recorded here. 24 Investment Decision, 25 Research Payment and Counterparty Review, "
        "Later, 34 Engagement and 38 restricted-list entries reference the records mastered here."
    ),
}
