"""Enrichment for Data Domain 24 - Portfolio Management & Construction (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Investment Governance
    ("Investment Governance", "Investment Committee"): ("investment committee", BO, ""),
    ("Investment Governance", "Investment Committee Member"): ("investment committee x employee x member role x effective period", BO, ""),
    ("Investment Governance", "Investment Committee Meeting"): ("investment committee x meeting date", BO, ""),
    ("Investment Governance", "Investment Committee Decision"): ("investment committee x meeting date x decision item number", BO, ""),
    # Portfolio Management Assignment
    ("Portfolio Management Assignment", "Portfolio Management Assignment"): ("portfolio x manager (employee) or investment team x portfolio management role x effective period", BO, ""),
    # Capital Market Assumptions (CW-128)
    ("Capital Market Assumptions", "Capital Market Assumption Set"): ("capital market assumption set (CMASET-) x set version", BO, ""),
    ("Capital Market Assumptions", "Asset Class Return Assumption"): ("assumption set version x asset class x sub-class", BO, ""),
    ("Capital Market Assumptions", "Asset Class Correlation Assumption"): ("assumption set version x unordered pair of its return assumption lines (diagonal not stored)", BO, ""),
    # Asset Allocation
    ("Asset Allocation", "Asset Allocation Policy"): ("strategy, product, model portfolio or investment mandate x policy version", BO, ""),
    ("Asset Allocation", "Asset Allocation Policy Line"): ("asset allocation policy version x asset class x sub-class", BO, ""),
    ("Asset Allocation", "Glide Path Point"): ("glide path policy version x years to target date x asset class x sub-class", BO, ""),
    ("Asset Allocation", "Tactical Allocation View"): ("view scope (house or strategy) x asset class x segment x view date", BO, ""),
    # Advice Model Construction (CW-128)
    ("Advice Model Construction", "Model Lineup"): ("model lineup (MLNUP-) x lineup version", BO, ""),
    ("Advice Model Construction", "Model Lineup Position"): ("model lineup version x 01 model portfolio", BO, ""),
    ("Advice Model Construction", "Model Building Block"): ("01 model portfolio x share class or instrument x building block role x effective period", BO, ""),
    # Targets & Constraints
    ("Targets & Constraints", "Target Allocation Set"): ("target subject (portfolio or model portfolio) x target set version", BO, ""),
    ("Targets & Constraints", "Target Allocation Line"): ("target allocation set x component (for classification lines: scheme x node)", BO, ""),
    ("Targets & Constraints", "Model Change Summary"): ("target allocation set (model change; model portfolio subjects only)", AG, "Target Allocation Set"),
    ("Targets & Constraints", "Portfolio Construction Constraint"): ("portfolio or model portfolio x constraint type x constraint scope x effective period", BO, ""),
    # Investment Decisions
    ("Investment Decisions", "Investment Decision"): ("investment decision", BO, ""),
    ("Investment Decisions", "Decision Rationale"): ("investment decision (rationale)", AG, "Investment Decision"),
    ("Investment Decisions", "Investment Decision Scope"): ("investment decision x portfolio or model portfolio", BO, ""),
    # Rebalancing & Trade Proposals
    ("Rebalancing & Trade Proposals", "Rebalance Run"): ("rebalance run", BO, ""),
    ("Rebalancing & Trade Proposals", "Rebalance Index Change Trigger"): ("rebalance run x index change announcement", BO, ""),
    ("Rebalancing & Trade Proposals", "Rebalance Portfolio Result"): ("rebalance run x portfolio", BO, ""),
    ("Rebalancing & Trade Proposals", "Proposed Trade"): ("proposed trade of an 18 portfolio (run-generated or manual; portfolio x instrument x side within a run)", BO, ""),
    ("Rebalancing & Trade Proposals", "Proposed Lot Selection"): ("proposed trade x 18 tax lot", BO, ""),
    ("Rebalancing & Trade Proposals", "Tax Budget"): ("18 portfolio of an institutional separate account (or of one of its sleeves) x tax year", BO, ""),
    # Cash Planning
    ("Cash Planning", "Investable Cash Forecast"): ("portfolio x forecast date x value date x currency", BO, ""),
    ("Cash Planning", "Cash Forecast Adjustment"): ("investable cash forecast x adjustment source x adjustment sequence", BO, ""),
    # ETF Baskets
    ("ETF Baskets", "ETF Basket"): ("ETF basket (share class x basket date x basket purpose x basket type; several custom baskets a day are told apart by Basket ID)", BO, ""),
    ("ETF Baskets", "ETF Basket Constituent"): ("ETF basket x instrument", BO, ""),
    ("ETF Baskets", "Custom Basket Approval"): ("ETF basket (custom basket approval; custom baskets only)", AG, "ETF Basket"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Decision Algorithm Code (Derived copy of 37) was replaced by the typed reference Decision Algorithm (CW-128, CW-924).
    # CD-246 completed 2026-10-14 (GAP-37-001): the optimizer name is a copy of the referenced Model Inventory Entry.Model Name.
    ("Rebalancing & Trade Proposals", "Rebalance Run", "Optimizer Used"): "37",
    # Neutral weights are read from the 01 blended policy benchmark (row rule: mastered here when there is none).
    ("Asset Allocation", "Asset Allocation Policy Line", "Neutral Weight"): "01",
    # Decision Supervising Branch Country (RTS 22 field 58, Derived copy of 20) was removed (CW-924).
    # CW-128: the product list status of a third-party building block is 52's.
    ("Advice Model Construction", "Model Building Block", "Building Block Product List Status"): "52",
    # CD-178: the forecast copies 18 cash projections and adds only 24 adjustments, the cash target and the investable result.
    ("Cash Planning", "Investable Cash Forecast", "Opening Cash"): "18",
    ("Cash Planning", "Investable Cash Forecast", "Projected Cash Net"): "18",
    # Realized gains are summed from the 18 Lot Relief of the budget portfolio.
    ("Rebalancing & Trade Proposals", "Tax Budget", "Realized Gain to Date"): "18",
    # CD-177: creation unit size is an 01 ETF term; NAV per creation unit is 27 NAV per Share x creation unit size.
    ("ETF Baskets", "ETF Basket", "Creation Unit Size"): "01",
    ("ETF Baskets", "ETF Basket", "NAV per Creation Unit"): "27",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the record of investment intent of the wealth manager's own funds, advice models and institutional separate "
        "accounts: capital market assumption sets (CMASET-) with their return and correlation assumptions; investment "
        "committees, their members, meetings and decisions (CMA and model lineup approvals, manager hires and terminations, "
        "third-party product approvals); operational portfolio management assignments at "
        "portfolio grain; asset allocation policies, policy lines, glide path points and tactical views; advice model lineups "
        "(MLNUP-), lineup positions and model building blocks; target allocation sets and lines for portfolios and models with "
        "the model change summary; portfolio construction constraints; investment decisions with "
        "their scope and rationale; rebalance runs of 18 portfolios, their index change triggers, per-portfolio results, "
        "proposed trades and lot selections; tax budgets of institutional separate accounts; investable cash forecasts and "
        "adjustments; and ETF baskets with their cash balancing amount, constituents and custom basket approvals. Client "
        "managed accounts are 46 (CW-009, CW-048)."
    ),
    "references": (
        "References strategies, products, share classes, model portfolios, mandates, service offerings, investment restrictions "
        "and benchmarks from 01 Investment Product & Service Offering; parties giving tax budget instructions from 02 Client & Household; org units, "
        "legal entities, calendars and classification schemes from 09 Shared & Enterprise Reference Data; transition events "
        "from 12 Institutional Client Servicing & Reporting; instruments from 17 Instrument & Issuer Reference; portfolios and "
        "tax lots from 18 Portfolio & Investment Book of Record; employees from 20 Human Capital; index change announcements "
        "from 22 Market Data & Pricing; research recommendations from 23 Investment Research; and model inventory entries (capital-market models, decision algorithms, optimizers) from 37. "
        "Policy neutral weights and creation unit size (01), cash projections and realized gains (18), NAV per creation unit "
        "(27) and the product list status of third-party building blocks (52) are held as derived copies."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Asset Allocation", "Asset Allocation Policy Line", "Neutral Weight"):
        "Row rule: mastered here for policies without a blended policy benchmark.",
    ("Advice Model Construction", "Model Building Block", "Building Block Product List Status"):
        "Row rule: Derived copy (52) on third-party instrument rows; blank on own share class rows.",
}
