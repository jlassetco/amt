"""Enrichment for Data Domain 25 - Portfolio Trading & Execution (contract v0.3): grain, ownership flags, summary. W1b (CW-925): MiFIR Transaction Report removed; wealth perspective."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Order Management
    ("Order Management", "Trade Order"): ("trade order (one portfolio x one instrument x side)", BO, ""),
    ("Order Management", "Order Handling Instruction"): ("trade order (handling instructions)", AG, "Trade Order"),
    ("Order Management", "Trade Order Event"): ("trade order x event type x event timestamp", BO, ""),
    # Execution
    ("Execution", "Block Order"): ("block order (orders aggregated in one instrument and side)", BO, ""),
    ("Execution", "Block Order Membership"): ("block order x trade order", BO, ""),
    ("Execution", "Broker Placement"): ("block order x broker x placement sequence", BO, ""),
    ("Execution", "Execution"): ("broker placement x execution (fill, correction or cancellation)", BO, ""),
    # Allocation
    ("Allocation", "Trade Allocation"): ("block order (or cross trade) x executing broker (none for crosses) x trade order x allocated portfolio or institutional separate account", BO, ""),
    ("Allocation", "Allocation Cost Detail"): ("trade allocation (commission, fees and taxes)", AG, "Trade Allocation"),
    ("Allocation", "Cross Trade"): ("cross trade (buying portfolio x selling portfolio x instrument x cross timestamp)", BO, ""),
    ("Allocation", "Trade Error"): ("trade error", BO, ""),
    # New Issues
    ("New Issues", "New Issue Offering"): ("new issue offering (instrument or instrument setup request)", BO, ""),
    ("New Issues", "New Issue Indication"): ("offering x portfolio or institutional separate account x indication timestamp", BO, ""),
    ("New Issues", "New Issue Allocation"): ("offering x portfolio or institutional separate account", BO, ""),
    ("New Issues", "Rule 10f-3 Purchase"): ("offering x purchasing fund x purchase trade allocation", BO, ""),
    ("New Issues", "New Issue Eligibility Certification"): ("portfolio or institutional separate account x certification date", BO, ""),
    # Counterparty Approval
    ("Counterparty Approval", "Approved Counterparty Profile"): ("counterparty (role profile keyed by 02 party)", BO, ""),
    ("Counterparty Approval", "Counterparty Approval Scope"): ("counterparty x approved activity x trading entity x fund (optional) x effective period", BO, ""),
    ("Counterparty Approval", "Counterparty Trading Limit"): ("counterparty x limit type x trading entity x fund (optional) x effective period", BO, ""),
    ("Counterparty Approval", "Counterparty Review"): ("counterparty x review date", BO, ""),
    # Commissions & Research Payments
    ("Commissions & Research Payments", "Commission Schedule"): ("broker x asset class x market x effective period", BO, ""),
    ("Commissions & Research Payments", "Commission Sharing Arrangement"): ("executing broker x arrangement x effective period", BO, ""),
    ("Commissions & Research Payments", "Commission Sharing Balance"): ("commission sharing arrangement x statement date", BO, ""),
    ("Commissions & Research Payments", "Research Budget"): ("budget legal entity x strategy scope x budget year", BO, ""),
    ("Commissions & Research Payments", "Research Payment"): ("research provider x payment period x payment source", BO, ""),
    # Best Execution & TCA
    ("Best Execution & TCA", "Best Execution Policy"): ("policy x asset class x legal entity x version", BO, ""),
    ("Best Execution & TCA", "TCA Result"): ("trade order, block order or execution x TCA provider x measurement date", BO, ""),
    ("Best Execution & TCA", "TCA Benchmark Result"): ("TCA result x benchmark", BO, ""),
    ("Best Execution & TCA", "Broker Execution Review"): ("broker x review period x asset class", BO, ""),
    ("Best Execution & TCA", "Best Execution Review"): ("committee review x period x asset class x legal entity", BO, ""),
}

# Values copied from another Data Domain without a Reference data type.
DERIVED = {
    # Stage 4 consolidation (stage4_consolidation_notes §1): copies of 37-43 masters; row rules in the attribute notes.
    ("Order Management", "Order Handling Instruction", "Large Trader ID"): "38",
    ("Order Management", "Trade Order Event", "Compliance Check Outcome"): "33",           # pre-trade compliance (Stage 3)
    ("Allocation", "Cross Trade", "Independent Current Market Price"): "22",
    ("Commissions & Research Payments", "Research Payment", "Research Payment Status"): "19",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    # W1b (CW-925): wealth model; fund and institutional portfolio orders only, client orders are 48 (CW-010).
    "masters": (
        "Masters the portfolio trading record of the US wealth manager's own funds and institutional portfolios, from order to "
        "allocation: trade orders (TORD-) with their handling instructions and event trail, block orders (BLOCK-) and block "
        "membership, broker placements, executions (EXEC-) including the executed FX rate, trade allocations (ALLOC-) from blocks "
        "and internal crosses to portfolios and institutional separate accounts with commission and fee detail, Rule 17a-7 cross "
        "trades and trade errors; new issue offerings, indications, allocations, Rule 10f-3 purchases and FINRA 5130 / 5131 "
        "eligibility certifications; the approved broker and counterparty profile with its approval scope, trading limits and "
        "reviews; commission schedules, Section 28(e) commission sharing arrangements with dated research credit balances, "
        "research budgets and research payments; and best execution evidence (policy, TCA results (TCA-) with benchmark "
        "comparisons, broker execution reviews and committee reviews). Client orders, their executions, allocations to client "
        "accounts and CAT reporting are 48 (CW-010). The large trader ID is a Derived copy of the 38 Entity Authorization (CD-250)."),
    "references": (
        "References share classes, products and strategies (01), parties such as brokers, counterparties, bookrunners, research "
        "and TCA providers (02 party core), sponsor and consultant program agreements (05), legal entities and org units (09), "
        "transition events (12), institutional separate accounts (15), instruments and setup requests (17), portfolios (18), "
        "payable invoices (19), employees (20), price observations (22), internal credit assessments and research evaluation "
        "rounds (23), investment decisions and proposed trades (24), trading agreements (26) and AP creation and redemption orders "
        "(29), and copies independent prices (22), research payment status (19) and the compliance check outcome (33)."),
}
