"""Enrichment for Data Domain 26 - Trade Operations, Settlement & Collateral (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

F_CNF = "Confirmation & Matching"
F_STL = "Settlement"
F_SSI = "Settlement Instructions & Cycles"
F_OTC = "OTC Derivative & Financing Lifecycle"
F_AGR = "Trading Agreements"
F_COL = "Margin & Collateral"

GRAIN = {
    # Confirmation & Matching
    (F_CNF, "Trade Confirmation"): ("trade allocation x confirmation channel x confirmation version", BO, ""),
    (F_CNF, "Confirmation Match Exception"): ("trade confirmation x mismatched field x exception raised timestamp", BO, ""),
    # Settlement
    (F_STL, "Settlement Instruction"): ("settlement instruction", BO, ""),
    (F_STL, "Cash Payment Detail"): ("settlement instruction (cash-only payment, FX settlement)", AG, "Settlement Instruction"),
    (F_STL, "Loan Settlement Detail"): ("settlement instruction (syndicated loan trade)", AG, "Settlement Instruction"),
    (F_STL, "Settlement Status Event"): ("settlement instruction x status advice timestamp", BO, ""),
    (F_STL, "Settlement Fail"): ("settlement instruction x fail start date", BO, ""),
    (F_STL, "Buy-In Notice"): ("settlement fail (buy-in)", AG, "Settlement Fail"),
    (F_STL, "Settlement Penalty"): ("settlement penalty (settlement instruction x penalty type x penalty date)", BO, ""),
    # Settlement Instructions & Cycles
    (F_SSI, "Standing Settlement Instruction"): ("instruction owner (client mandate, fund, portfolio or counterparty) x market (or settlement currency for cash SSIs) x asset class x effective period", BO, ""),
    (F_SSI, "SSI Verification"): ("standing settlement instruction (verification)", AG, "Standing Settlement Instruction"),
    (F_SSI, "Settlement Cycle Rule"): ("market x instrument type x settlement type x effective period", BO, ""),
    # OTC Derivative & Financing Lifecycle
    (F_OTC, "OTC Derivative Trade"): ("OTC derivative trade", BO, ""),
    (F_OTC, "Clearing Detail"): ("OTC derivative trade (clearing)", AG, "OTC Derivative Trade"),
    (F_OTC, "OTC Trade Leg"): ("OTC derivative trade x leg number", BO, ""),
    (F_OTC, "OTC Lifecycle Event"): ("OTC derivative trade x event date x event sequence", BO, ""),
    (F_OTC, "OTC Cash Flow"): ("OTC derivative trade x leg number x payment date x cash flow type", BO, ""),
    (F_OTC, "Repo Trade"): ("repo or reverse repo (firm repo trade reference), opening to closing leg", BO, ""),
    (F_OTC, "Derivative Trade Report"): ("reported OTC derivative trade x trade report regime x report submission timestamp", BO, ""),
    # Trading Agreements
    (F_AGR, "Trading Agreement"): ("trading agreement", BO, ""),
    (F_AGR, "Credit Support Terms"): ("trading agreement x margin type x collateral direction x effective period", BO, ""),
    (F_AGR, "Eligible Collateral Schedule"): ("trading agreement x margin type x collateral direction x collateral type x effective period", BO, ""),
    (F_AGR, "Termination Event Trigger"): ("trading agreement x termination trigger type x trigger applies to x measurement period (tier) x effective period", BO, ""),
    # Margin & Collateral
    (F_COL, "Margin Call"): ("margin call (trading agreement x call valuation date x margin type x collateral direction)", BO, ""),
    (F_COL, "Margin Call Dispute"): ("margin call (dispute)", AG, "Margin Call"),
    (F_COL, "Collateral Movement"): ("collateral movement (trading agreement x collateral movement reference x value date)", BO, ""),
    (F_COL, "Collateral Balance"): ("trading agreement x source portfolio x balance date x margin type x collateral direction x collateral asset (instrument, or currency for cash)", BO, ""),
    (F_COL, "Initial Margin Calculation"): ("trading agreement x calculation date x collateral direction", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Row rule: trade settlements copy the 25 allocation; collateral, repo and in-kind rows take the value from 26 / 29 records
    # (see ROW_RULES). The Trade Confirmation's confirmed values are the broker's, mastered here as received (review A).
    (F_STL, "Settlement Instruction", "Settlement Quantity"): "25",
    (F_STL, "Settlement Instruction", "Settlement Amount"): "25",
    (F_STL, "Loan Settlement Detail", "Loan Trade Date"): "25",
    (F_OTC, "OTC Derivative Trade", "OTC Trade Date"): "25",
}

# Per-row ownership and exclusive-attribute rules (Enterprise_Expansion_Plan.md section 4 item 9). Documentation only:
# the builder does not read it; the same rules are in each attribute's Notes.
ROW_RULES = {
    (F_STL, "Settlement Instruction", "Settlement Quantity"):
        "Settlement Type = Trade: Derived copy (25) of the allocation quantity. Collateral: mastered on 26 Collateral Movement. "
        "Repo legs: mastered on 26 Repo Trade. In-Kind Creation / Redemption: 29 Basket Settlement Line.",
    (F_STL, "Settlement Instruction", "Settlement Amount"): "As for Settlement Quantity.",
    (F_SSI, "Standing Settlement Instruction", "Safekeeping Account"):
        "Set only when SSI Owner Type = Client Mandate (12 CUA-). Exactly one of Safekeeping Account, Own Safekeeping Account "
        "and Counterparty Safekeeping Account Number is set. Re-typing to 28 SKA- is a CD-194 consequence.",
    (F_SSI, "Standing Settlement Instruction", "Own Safekeeping Account"):
        "Set only when SSI Owner Type = Fund or Portfolio (28 SKA-).",
    (F_SSI, "Standing Settlement Instruction", "Counterparty Safekeeping Account Number"):
        "Set only when SSI Owner Type = Counterparty.",
    (F_STL, "Settlement Instruction", "Settlement Instrument"):
        "CDE for securities and loan settlement types; blank for FX Settlement, Derivative Payment and cash Collateral.",
    (F_STL, "Settlement Instruction", "Instructed Place of Settlement"):
        "CDE for CSD-settled securities types; blank for cash-only and Syndicated Loan Trade types.",
}

# SSI- is registered to 26 since the Stage 2 consolidation (CD-155 option A), so every reference resolves without help.
OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    # W1b (CW-926): wealth model; fund-side settlement only (client trades clear and settle in 49, plan section 5.1).
    "masters": (
        "Masters fund-side trade support, settlement and collateral records of the US wealth manager's funds and institutional "
        "portfolios: trade confirmations, affirmations and match exceptions; trade-level settlement instructions (securities, "
        "cash-only and FX payments, syndicated loan settlement), settlement status events, fails, buy-in notices (FINRA Rule "
        "11810, Regulation SHO Rule 204, contract) and settlement penalties (US fails charges, cash penalties of foreign CSDs); "
        "standing settlement instructions for institutional mandates, funds, portfolios and counterparties with their "
        "verification (CD-155 option A) and settlement cycle rules; OTC derivative trades after execution (UTI, confirmed "
        "economics, legs, clearing detail, lifecycle events and cash flows), repo trades, and CFTC Part 45 and SEC Regulation "
        "SBSR trade reports where the fund reports; trading agreements (ISDA Master, CSA, GMRA, MRA, MSFTA, clearing and give-up "
        "agreements) with credit support terms, eligible collateral schedules and termination event triggers; and margin calls "
        "and disputes, collateral movements, collateral balances and initial margin calculations. Clearance and settlement of "
        "client trades in brokerage and advisory accounts are 49."
    ),
    "references": (
        "References investment products and mandates from 01 Investment Product & Service Offering; counterparties, brokers, "
        "custodians, CSDs, CCPs, clearing members, swap data repositories, tri-party agents and segregation custodians from 02 "
        "Client & Household (party core); internal legal entities and settlement calendars from 09 Shared & Enterprise Reference "
        "Data; custody account set-up from 12 Institutional Client Servicing & Reporting; institutional separate accounts and "
        "mandate accounts from 15 Account; instruments and OTC products from 17 Instrument & Issuer Reference; portfolios and "
        "portfolio transactions from 18 Portfolio & Investment Book of Record; employees from 20 Human Capital; approved prices "
        "and reference rate fixings from 22 Market Data & Pricing; trade allocations and trade economics from 25 Portfolio "
        "Trading & Execution; safekeeping accounts from 28 Fund Custody & Asset Servicing; and ETF authorized participant orders from "
        "29 Transfer Agency Operations. 18 holds Settlement Confirmed Indicator, Initial Margin Posted and the collateral case "
        "of Encumbered Quantity as values derived from 26, and 27 and 28 reference its settlement instructions."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Settlement", "Settlement Instruction", "Settlement Quantity"):
        "Row rule: Derived copy (25) of the allocation quantity for trade settlements; for collateral, repo and in-kind settlements the quantity comes from the 26 Collateral Movement, the 26 Repo Trade or the 29 basket line, and is mastered there.",
    ("Settlement", "Settlement Instruction", "Settlement Amount"):
        "Row rule as for Settlement Quantity; for trade rows it equals the affirmed confirmation amount.",
}
