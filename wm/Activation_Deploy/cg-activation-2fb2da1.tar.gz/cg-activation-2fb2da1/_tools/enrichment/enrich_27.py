"""Enrichment for Data Domain 27 - Fund Accounting & Valuation (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Fund Books & Ledgers
    ("Fund Books & Ledgers", "Fund Accounting Book"): ("fund (01 series-level product) x accounting basis", BO, ""),
    ("Fund Books & Ledgers", "Fund Book Operating Period"): ("fund accounting book x operating period (effective from)", BO, ""),
    ("Fund Books & Ledgers", "Fund Book Portfolio Link"): ("fund accounting book x 18 portfolio x link effective period", BO, ""),
    ("Fund Books & Ledgers", "Fund Ledger Account"): ("fund chart of accounts x fund ledger account number", BO, ""),
    ("Fund Books & Ledgers", "Fund Journal Entry"): ("fund journal entry (FJNL-)", BO, ""),
    ("Fund Books & Ledgers", "Fund Journal Line"): ("fund journal entry x line number", BO, ""),
    ("Fund Books & Ledgers", "Fund Trial Balance"): ("fund accounting book x fund ledger account x share class (or fund level) x balance date", BO, ""),
    # ABOR Investment Accounting
    ("ABOR Investment Accounting", "ABOR Valuation Record"): ("fund accounting book x instrument x valuation date", BO, ""),
    ("ABOR Investment Accounting", "ABOR to IBOR Reconciliation"): ("fund accounting book x 18 portfolio x instrument x reconciliation date", BO, ""),
    ("ABOR Investment Accounting", "Income Accrual"): ("fund accounting book x instrument x income type x accrual date", BO, ""),
    # NAV Calculation
    ("NAV Calculation", "Fund NAV Calculation"): ("fund accounting book x valuation date x NAV calculation source x NAV version", BO, ""),
    ("NAV Calculation", "Share Class NAV"): ("share class x fund NAV calculation (valuation date x calculation source x version) (NAV-)", BO, ""),
    ("NAV Calculation", "CIT Unit Value Detail"): ("share class NAV of a CIT unit class (unit value detail)", AG, "Share Class NAV"),
    ("NAV Calculation", "Class Allocation"): ("fund NAV calculation x share class x allocation item", BO, ""),
    ("NAV Calculation", "NAV Dissemination"): ("share class NAV x release sequence (NAV release; per-channel transmission is 29)", BO, ""),
    # Swing Pricing & Anti-Dilution
    ("Swing Pricing & Anti-Dilution", "Swing Pricing Parameter"): ("fund x parameter effective period", BO, ""),
    ("Swing Pricing & Anti-Dilution", "Swing Pricing Decision"): ("fund x valuation date (SWG-)", BO, ""),
    # Fund Expenses
    ("Fund Expenses", "Fund Expense Budget"): ("fund x expense type x fiscal year", BO, ""),
    ("Fund Expenses", "Fund Expense Accrual"): ("fund (or share class) x expense type x accrual date", BO, ""),
    ("Fund Expenses", "Expense Cap & Waiver Accrual"): ("share class x waiver type x accrual date", BO, ""),
    ("Fund Expenses", "Fund Expense Payment"): ("fund x payee x payment", BO, ""),
    # Income & Distributions
    ("Income & Distributions", "Distribution Declaration"): ("share class x distribution type x ex-date (FDIV-)", BO, ""),
    ("Income & Distributions", "Distribution Character"): ("distribution declaration x tax character x character data basis (estimated or final)", AG, "Distribution Declaration"),
    ("Income & Distributions", "Distributable Income Estimate"): ("fund x distribution requirement period x estimate date", BO, ""),
    # Fund Tax
    ("Fund Tax", "Fund Tax Year Record"): ("fund x tax year x jurisdiction (FTAX-)", BO, ""),
    ("Fund Tax", "Book-Tax Difference"): ("fund tax year record x difference type x instrument (where instrument-specific)", BO, ""),
    ("Fund Tax", "RIC Test Result"): ("fund x RIC test type x test date", BO, ""),
    # NAV Errors & Corrections
    ("NAV Errors & Corrections", "NAV Error Case"): ("NAV error case (NEC-)", BO, ""),
    ("NAV Errors & Corrections", "NAV Error Impact"): ("NAV error case x share class x valuation date", BO, ""),
    # NAV Controls & Fund Reporting
    ("NAV Controls & Fund Reporting", "NAV Control Check"): ("fund NAV calculation or share class NAV x check type x check run sequence", BO, ""),
    ("NAV Controls & Fund Reporting", "Fund Financial Statement"): ("fund accounting book x fiscal period end x statement set", BO, ""),
    ("NAV Controls & Fund Reporting", "Financial Highlights"): ("fund financial statement set x share class (per-share data and ratios)", AG, "Fund Financial Statement"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Business line is mastered on the 18 portfolio that implements the fund.
    ("Fund Books & Ledgers", "Fund Accounting Book", "Business Line"): "18",
    # Book currency is the 01 Product Base Currency.
    ("Fund Books & Ledgers", "Fund Accounting Book", "Book Reporting Currency"): "01",
    # IBOR side of the ABOR to IBOR reconciliation (ABOR Quantity itself is mastered here).
    ("ABOR Investment Accounting", "ABOR to IBOR Reconciliation", "IBOR Quantity"): "18",
    # Row rule (plan §4 item 9): 17 coupon rate for fixed and step instruments; computed here for floating-rate rows.
    ("ABOR Investment Accounting", "Income Accrual", "Coupon Rate Applied"): "17",
    # NAV currency is the 01 share class currency.
    ("NAV Calculation", "Share Class NAV", "NAV Currency"): "01",
    # Row rule: 01 rate for flat schedules; blended breakpoint rate computed here for tiered schedules.
    ("Fund Expenses", "Fund Expense Accrual", "Fee Rate Applied"): "01",
    # Expense cap rate copied from 01 Cost Disclosure.
    ("Fund Expenses", "Expense Cap & Waiver Accrual", "Expense Cap Rate Applied"): "01",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)
# 'Related Income Collection' (key starts with SKA-) resolves to 28 without help since SKA- was registered (CD-210).

SUMMARY = {
    # W1b (CW-927): wealth model (US wealth manager's own funds; US-only pass).
    "masters": (
        "Masters the official books (ABOR) of every fund the US wealth manager sponsors and runs (own mutual funds, money "
        "market funds, ETFs and CITs), in house or at an administrator: fund accounting books by accounting basis, their "
        "operating model and administrator over time and the 18 portfolios they account for, the fund chart of accounts, fund "
        "journal entries and lines, fund trial balances, ABOR valuation records (with the book's own quantity), ABOR to IBOR "
        "reconciliations and income accruals, fund NAV calculations by source and version, share class NAVs (including CIT unit "
        "values), Rule 18f-3 class allocation, NAV releases, Rule 22c-1(a)(3) swing pricing parameters and decisions, fund "
        "expense budgets, accruals, cap and waiver accruals and payments, distribution declarations and their tax character, "
        "distributable income estimates, fund tax year records, book-tax differences, Subchapter M RIC test results, NAV error "
        "cases and their impact, NAV-level control checks, and fund financial statement sets with financial highlights."
    ),
    "references": (
        "References funds, share classes, fee schedules and their cap, swing, distribution and valuation terms from 01 Investment "
        "Product & Service Offering; administrators, auditors, payees and NAV recipients from 02 Client & Household (party "
        "core); legal entities from 09 Shared & Enterprise Reference Data; instruments, coupon schedules and corporate action "
        "events from 17 Instrument & Issuer Reference; portfolios, holdings, portfolio transactions and business line from 18 "
        "Portfolio & Investment Book of Record; adviser receivables and payables from 19 Finance & Accounting; employees from 20 "
        "Human Capital; approved prices, reference rate fixings, fair value determinations and FX rate observations from 22 "
        "Market Data & Pricing; fund-side settlement instructions from 26; safekeeping accounts and income collection from 28 "
        "Fund Custody & Asset Servicing; fund orders, ETF AP orders and TA control checks (capital stock proof) from 29 Transfer "
        "Agency Operations. 10, 13, 28 and 29 reference the waiver accruals, NAV error cases, ABOR records and NAV "
        "releases mastered here."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("ABOR Investment Accounting", "Income Accrual", "Coupon Rate Applied"):
        "Row rule: for fixed and step instruments it is the 17 coupon rate of the period (copy); for floating-rate instruments it is computed here from the applied 22 fixing plus the 17 spread. Flagged Derived copy (17); mastered here for floating-rate rows (plan §4 item 9).",
    ("Fund Expenses", "Fund Expense Accrual", "Fee Rate Applied"):
        "Row rule: for a flat-rate schedule it is the 01 rate (copy); for a tiered schedule it is the blended effective rate computed here across breakpoints; blank for fixed and budgeted expenses. Flagged Derived copy (01); mastered here for blended breakpoint rows (plan §4 item 9).",
}
