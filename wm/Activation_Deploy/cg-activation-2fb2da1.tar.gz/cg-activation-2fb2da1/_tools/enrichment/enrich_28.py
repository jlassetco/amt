"""Enrichment for Data Domain 28 - Fund Custody & Asset Servicing (contract v0.3): grain, ownership flags, summary.

Wealth model (W1b, CW-928): the Client Assets & Money family and Client Asset Designation (UK CASS) were removed with their
grain entries; client-asset custody is 49 (CW-007)."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Custody Network
    ("Custody Network", "Custody Provider Profile"): ("provider (party, or internal legal entity for a self-custodying CIT trustee) x custody provider role x effective period", BO, ""),
    ("Custody Network", "Sub-Custodian Network Arrangement"): ("global custodian x market x sub-custodian x effective period", BO, ""),
    ("Custody Network", "Foreign Custody Assessment"): ("assessed arrangement or depository x assessment type x assessment date", BO, ""),
    ("Custody Network", "Custodian Service Review"): ("custody provider x provider role x review period", BO, ""),
    # Safekeeping Accounts
    ("Safekeeping Accounts", "Safekeeping Account"): ("account at a custodian, sub-custodian, bank or securities depository holding fund or institutional separate account assets (SKA-)", BO, ""),
    ("Safekeeping Accounts", "Safekeeping Account Assignment"): ("safekeeping account x owner (fund, portfolio or institutional separate account) x assignment purpose x effective period", BO, ""),
    # Custodian Statements & Reconciliation
    ("Custodian Statements & Reconciliation", "Custodian Statement"): ("safekeeping account x custodian statement type x statement date x statement number", BO, ""),
    ("Custodian Statements & Reconciliation", "Custodian Holding Statement Line"): ("custodian statement x custodian security identifier x place of safekeeping x custodian balance type", BO, ""),
    ("Custodian Statements & Reconciliation", "Custodian Cash Statement Entry"): ("custodian statement x custodian entry reference", BO, ""),
    ("Custodian Statements & Reconciliation", "Custody Reconciliation Run"): ("reconciliation scope (portfolio or safekeeping account) x custody reconciliation type x business date (CUREC-)", BO, ""),
    ("Custodian Statements & Reconciliation", "Custody Reconciliation Break"): ("custody reconciliation run x break number (CUREC-n-Bnn)", BO, ""),
    # Corporate Action Processing
    ("Corporate Action Processing", "Corporate Action Notification Receipt"): ("custodian notification message (custodian message reference) for one corporate action event x safekeeping account", BO, ""),
    ("Corporate Action Processing", "Corporate Action Entitlement"): ("corporate action event x safekeeping account x entitled portfolio (CAEN-)", BO, ""),
    ("Corporate Action Processing", "Corporate Action Election"): ("entitlement x option x instruction (ELECT-)", BO, ""),
    ("Corporate Action Processing", "Corporate Action Payment"): ("entitlement x payment confirmation reference", BO, ""),
    # Income & Tax Recovery
    ("Income & Tax Recovery", "Income Collection"): ("income entitlement (dividend, interest or other income CAEN-)", BO, ""),
    ("Income & Tax Recovery", "Tax Relief Documentation"): ("fund (beneficial owner) x market x tax relief method x effective period", BO, ""),
    ("Income & Tax Recovery", "Withholding Tax Reclaim"): ("withholding tax reclaim on one corporate action payment (WHTR-)", BO, ""),
    ("Income & Tax Recovery", "Class Action Claim"): ("class action claim (SCAC-): class action event x claiming fund or institutional separate account", BO, ""),
    # Securities Lending
    ("Securities Lending", "Securities Lending Program"): ("lending fund or portfolio x agent lender x effective period", BO, ""),
    ("Securities Lending", "Securities Lending Agreement"): ("lending program x agent lender x counterparty (borrower; none for the authorization agreement)", BO, ""),
    ("Securities Lending", "Securities Loan"): ("securities loan (SBL-), current state at the latest mark", BO, ""),
    ("Securities Lending", "Lending Collateral Received"): ("loan (or borrower collateral pool) x collateral item x mark date", BO, ""),
    ("Securities Lending", "Loan Regulatory Report"): ("securities loan x reporting regime", BO, ""),
    ("Securities Lending", "Lending Revenue Allocation"): ("lending program x revenue period", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Expected income: accrued income balance less withholding accrued on the 27 Income Accrual row of the ex-date.
    ("Income & Tax Recovery", "Income Collection", "Expected Net Income Amount"): "27",
    # Due date: the 17 Corporate Action Payment Date of the entitlement's event (every row has a 17 event).
    ("Income & Tax Recovery", "Income Collection", "Income Due Date"): "17",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters fund custody oversight and asset servicing for the wealth manager's proprietary mutual funds, ETFs and CITs and "
        "the institutional separate accounts it manages: custody provider profiles by role, sub-custodian network arrangements, "
        "foreign custody and depository assessments (Rules 17f-5 and 17f-7) and custodian service reviews; every safekeeping "
        "account (SKA-) at a custodian, sub-custodian, bank or securities depository and its effective-dated assignment to funds, "
        "portfolios and institutional separate accounts; custodian holding and cash statements as received, custody reconciliation "
        "runs (CUREC-) and breaks; per-account corporate action notifications, entitlements (CAEN-), elections (ELECT-) and "
        "payments, which hold income received and tax withheld; income collection control, tax relief documentation, withholding "
        "tax reclaims (WHTR-) and class action claims (SCAC-); and securities lending programs, lending agreements, loans (SBL-), "
        "collateral received, Rule 10c-1a loan reports and revenue allocation. Fund assets only: custody of client assets at the "
        "firm's self-clearing broker-dealer, client holdings and the Rule 15c3-3 records are 49 (CW-007)."
    ),
    "references": (
        "References funds from 01 Investment Product & Service Offering; custodians, sub-custodians, depositories, banks, agent "
        "lenders, borrowers and filing agents from the 02 party core (CD-143); internal legal entities (including a self-custodying "
        "CIT trustee) from 09 Shared & Enterprise Reference Data; institutional separate accounts from 15 Account; instruments, "
        "corporate action events (including class actions) and options from 17 Instrument & Issuer Reference; fund and "
        "institutional portfolios, portfolio holdings, cash balances and portfolio transactions from 18 Portfolio & Investment "
        "Book of Record; employees from 20 Human Capital; approved prices (22), investment decisions (24), settlement instructions "
        "(26), ABOR valuation records, income accruals and fund journal entries (27), ETF creation and redemption orders (29) and "
        "custody agreements (39). Expected income (27) and the income due date (17) are derived copies."
    ),
}
