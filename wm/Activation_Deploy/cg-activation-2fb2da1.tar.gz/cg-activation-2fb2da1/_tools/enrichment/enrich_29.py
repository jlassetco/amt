"""Enrichment for Data Domain 29 - Transfer Agency Operations (contract v0.4): grain, ownership flags, summary.

W3 wealth adaptation (2026-10-14): CIP Verification removed (CW-124); Shareholder Register family added with Share Register
Balance and Register Transaction (CW-122); Brokerage Omnibus Order Detail added (CW-097, CW-123); Servicing Provider
Engagement, Intermediary Distribution Request and NOBO List Request moved in from 13 (CW-088). Family renames: Investor
Identity & Financial Crime -> Shareholder Account Monitoring (TA-FCC kept), TA Controls -> TA Controls & Oversight (TA-OVS kept).
"""

BO, AG = "Business Object", "Attribute Group"

_ORC, _STL, _ETF, _REG = "Fund Order Capture", "Order Settlement", "ETF Primary Market", "Shareholder Register"
_FCC, _OVS, _IOI = "Shareholder Account Monitoring", "TA Controls & Oversight", "Intermediary Order Interfaces"

GRAIN = {
    # Fund Order Capture
    (_ORC, "Fund Order"): ("fund order as received by the transfer agent (FNDO-)", BO, ""),
    (_ORC, "Order Routing Detail"): ("fund order (routing and intermediary codes as delivered)", AG, "Fund Order"),
    (_ORC, "As-Of Order Detail"): ("fund order (as-of or correction detail)", AG, "Fund Order"),
    (_ORC, "Brokerage Omnibus Order Detail"): ("fund order on the broker-dealer omnibus account (aggregation of 48 client orders per share class and dealing cycle)", AG, "Fund Order"),
    (_ORC, "Order Event"): ("fund order x order event type x event timestamp", BO, ""),
    (_ORC, "Order Exception"): ("fund order x order exception type x exception raised timestamp", BO, ""),
    (_ORC, "Exchange Link"): ("outgoing-leg fund order x incoming-leg fund order (exchange, conversion or Fund Share Transfer)", BO, ""),
    # Order Settlement
    (_STL, "Settlement Obligation"): ("fund order or AP order x settlement obligation sequence", BO, ""),
    (_STL, "Intermediary Settlement Batch"): ("settling party x settlement date x currency x data basis (FBAT-)", BO, ""),
    (_STL, "Cash Movement"): ("fund-side cash movement (firm-assigned cash movement ID)", BO, ""),
    (_STL, "Settlement Exception"): ("settlement obligation or settlement batch x settlement exception type x exception detected date", BO, ""),
    # ETF Primary Market
    (_ETF, "AP Creation / Redemption Order"): ("authorized participant order (ECR-)", BO, ""),
    (_ETF, "AP Order Fee"): ("AP order (transaction fees and collateral)", AG, "AP Creation / Redemption Order"),
    (_ETF, "Basket Settlement Line"): ("AP order x basket constituent", BO, ""),
    # Shareholder Register
    (_REG, "Share Register Balance"): ("registered account (15) x share class (01) x business date", BO, ""),
    (_REG, "Register Transaction"): ("posted share movement on the TA register (RGTX-)", BO, ""),
    (_REG, "Intermediary Distribution Request"): ("intermediary distribution request (communication x intermediary, BOD-)", BO, ""),
    (_REG, "NOBO List Request"): ("intermediary distribution request (NOBO list request detail)", AG, "Intermediary Distribution Request"),
    # Shareholder Account Monitoring
    (_FCC, "Account Monitoring Alert"): ("account monitoring alert (AMA-)", BO, ""),
    (_FCC, "Alert Disposition"): ("account monitoring alert (review and decision)", AG, "Account Monitoring Alert"),
    (_FCC, "Shareholder Information Request"): ("request x intermediary x request period", BO, ""),
    # TA Controls & Oversight
    (_OVS, "TA Control Check"): ("TA control type x share class (or fund) x business date (TACK-)", BO, ""),
    (_OVS, "TA Control Exception"): ("TA control check x control exception number", BO, ""),
    (_OVS, "TA Processing Calendar Event"): ("dealing calendar (optionally one share class) x business date x processing calendar event type", BO, ""),
    (_OVS, "Servicing Provider Engagement"): ("servicing provider x servicing role x engagement start date", BO, ""),
    # Intermediary Order Interfaces
    (_IOI, "Order Interface Session"): ("dealing route x business date x interface cycle (interface session key)", BO, ""),
    (_IOI, "Price & Rate Transmission"): ("27 NAV dissemination x transmission channel x attempt (price transmission key)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Quantity required by the 24 basket (quantity per creation unit x units ordered) (CD-200).
    (_ETF, "Basket Settlement Line", "Basket Quantity"): "24",
    # 24 ETF Basket Cash Component / Estimated Cash Component scaled by units ordered.
    (_ETF, "AP Creation / Redemption Order", "Estimated Cash Component Amount"): "24",
    # Row rule: 27 shares outstanding for Capital Stock Proof rows (the main use); 28 for Cash Proof rows (Custodian Cash Statement Entry amounts
    # for Cash Proof rows; blank for threshold controls. See the attribute note.
    (_OVS, "TA Control Check", "Comparison Value"): "27",
    # Resolved Dealer and Resolved Representative are mastered in 29 from the Fund/SERV and Networking feed fields; 06 copies
    # them from 29 (program-lead ruling on the 29 review; the former Derived copy of 06 was circular).
    # Aggregates of the 48 client orders whose Order Route references this fund order (CW-097, CW-123); for Cash Sweep Run rows
    # the 50 Sweep Run allocations (row rule in ROW_OWNERSHIP). The flag names the main source.
    (_ORC, "Brokerage Omnibus Order Detail", "Aggregated Client Order Count"): "48",
    (_ORC, "Brokerage Omnibus Order Detail", "Aggregated Purchase Amount"): "48",
    (_ORC, "Brokerage Omnibus Order Detail", "Aggregated Redemption Amount"): "48",
    (_ORC, "Brokerage Omnibus Order Detail", "Aggregated Redemption Units"): "48",
    # Registration number of the provider party, copied as in 13 before the move (CW-088).
    (_OVS, "Servicing Provider Engagement", "SEC Transfer Agent Registration Number"): "02",
}
# Removed at W3: Settlement Obligation.Obligation Amount (06): fund-order rows now carry the 29 Register Transaction net
# amount (CW-122), so every row is mastered here.

# The resolver reads "Reference (X)" by the example prefix first, then the concept register. Servicing Provider Engagement
# is registered to 13 until the W3 merge (CW-088), and the Service Level Definition example SVL- resolves to 13 correctly.
# Nothing in 29 references Servicing Provider Engagement or Intermediary Distribution Request by type, so no override is needed.
OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    "masters": (
        "Masters the in-house transfer agent's operational records and the share register of the firm's own mutual funds, ETFs "
        "and CITs: fund orders as received and processed (receipt timestamp, cut-off result, trade date assigned, status, "
        "origin, routing detail as delivered, the aggregation detail of the broker-dealer omnibus order, as-of corrections and "
        "dilution), order events and exceptions, exchange links, settlement obligations, intermediary settlement batches, "
        "fund-side cash movements and settlement exceptions, ETF authorized participant creation and redemption orders with "
        "their cash component, basket settlement lines and fees, the share register (Share Register Balances and Register "
        "Transactions for every account registered at the TA), intermediary beneficial-owner distribution and NOBO list "
        "requests, dealing-triggered monitoring alerts on shareholder accounts and their dispositions, Rule 22c-2 shareholder "
        "information requests, daily TA control checks and exceptions, TA processing calendar events, the oversight of the "
        "TA's service providers, order interface sessions and the per-channel transmission of prices and rates released by 27."
    ),
    "references": (
        "References registered accounts, standing instructions and account restrictions from 15 Account; shareholders, "
        "intermediaries, authorized participants, network operators and service providers from 02 Client & Household; share "
        "classes and funds from 01; the client orders aggregated into omnibus fund orders (derived counts and amounts) from 48; "
        "the omnibus reconciliation and fund-only tax lots in 49; client money movements and sweep runs from 50; payroll "
        "contribution batches from 16; dealer, AP and shareholder information agreements and loads from 05 and 06 until their W4 "
        "replacement; frequent trading cases from 08; dealing calendars from 09; "
        "service requests, shareholder communications, service levels and servicing errors from 13; employees from 20; ETF "
        "baskets and constituents from 24; settlement instructions for in-kind basket deliveries from 26; share class NAVs, NAV "
        "disseminations, distribution declarations and NAV error cases from 27; fund safekeeping accounts from 28; and AML "
        "cases from 38."
    ),
}

# Row Ownership Rule (CD-289): where one attribute holds rows mastered here and rows copied from (or owned by) another Data
# Domain, the rule says which rows are which. The Ownership flag stays as declared.
_AGG = ("Row rule: for Affiliated Broker-Dealer Omnibus rows, a Derived copy of the 48 client orders whose Order Route references this "
        "fund order; for Cash Sweep Run rows, a Derived copy of the 50 Sweep Run allocations of the cycle (CW-108).")

ROW_OWNERSHIP = {
    **{(_ORC, "Brokerage Omnibus Order Detail", a): _AGG for a in ("Aggregated Client Order Count", "Aggregated Purchase Amount",
                                                                 "Aggregated Redemption Amount", "Aggregated Redemption Units")},
    (_REG, "Share Register Balance", "Register Account Category"):
        "Row rule: set at register setup from the 15 Account Type and Networking Level by the map in the attribute note (Direct Institutional Fund Account, DTC Nominee Account and CIT Unitholder Account added to 15 at the W3 merge); mastered here as the register classification.",
    (_OVS, "TA Control Check", "Comparison Value"):
        "Row rule: copy of 27 Share Class NAV / Shares Outstanding for Capital Stock Proof; copy of the 28 Custodian Cash Statement Entry amounts for Cash Proof; blank for Unprocessed Items and As-Of Dilution Review, whose threshold is Control Tolerance.",
    (_STL, "Settlement Exception", "Return Reason Code"):
        "Row rule: for a returned client payment of a fund-only account, a copy of the 50 Money Movement return reason (CW-107); for fund-side payments with intermediaries, NSCC or authorized participants, mastered here.",
}
