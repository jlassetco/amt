"""Enrichment for Data Domain 31 - Investment Risk (contract v0.3): grain, ownership flags, summary.

Wealth model (W1b, CW-931): the Product Risk Indicators family (PRIIPs SRI, UCITS SRRI, PRIIPs performance scenarios) was
removed with its grain and derived entries."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Risk Models & Factors
    ("Risk Models & Factors", "Risk Model"): ("risk model code x version", BO, ""),
    ("Risk Models & Factors", "Risk Factor"): ("risk model version x factor code", BO, ""),
    ("Risk Models & Factors", "Risk Factor Return"): ("risk factor x return date", BO, ""),
    ("Risk Models & Factors", "Instrument Factor Loading"): ("risk model version x instrument x risk factor x loading date", BO, ""),
    # Risk Measurement
    ("Risk Measurement", "Risk Calculation Run"): ("risk model version x as-of date x run scope", BO, ""),
    ("Risk Measurement", "Portfolio Risk Measure"): ("calculation run x portfolio x risk measure x horizon days x confidence level x benchmark (blank for absolute); portfolio-keyed measure", BO, ""),
    ("Risk Measurement", "Risk Decomposition"): ("portfolio risk measure (calculation run x portfolio x risk measure x horizon days x confidence level x benchmark) x risk dimension x bucket", BO, ""),
    ("Risk Measurement", "VaR Back-Test"): ("portfolio x risk model version x back-test date x P&L basis", BO, ""),
    # Exposures
    ("Exposures", "Portfolio Exposure"): ("portfolio x as-of date x calculation run (blank when no model is used) x exposure dimension x bucket x exposure measure x benchmark (blank for absolute); portfolio-keyed measure", BO, ""),
    ("Exposures", "Counterparty Exposure"): ("counterparty x exposure date x counterparty exposure measure x scope (portfolio, trading entity, or blank for firm) x netting set agreement (blank when not netted)", BO, ""),
    ("Exposures", "Leverage & Exposure Measurement"): ("fund x measurement date x exposure method (Rule 18f-4 derivatives exposure or Section 18 asset coverage); fund-keyed program result measured on the fund's whole 18 book", BO, ""),
    # Stress Testing
    ("Stress Testing", "Stress Scenario"): ("stress scenario (STRESS-) x version", BO, ""),
    ("Stress Testing", "Stress Scenario Shock"): ("stress scenario version x shocked factor, curve and tenor, or market variable", BO, ""),
    ("Stress Testing", "Stress Test Result"): ("stress scenario version x portfolio x stress test date", BO, ""),
    ("Stress Testing", "Liquidity Stress Detail"): ("stress test result (liquidity scenario)", AG, "Stress Test Result"),
    # Liquidity Risk
    ("Liquidity Risk", "Liquidity Classification"): ("fund x instrument x classification date x classification portion; fund-keyed program result", BO, ""),
    ("Liquidity Risk", "Highly Liquid Investment Minimum"): ("fund x effective period", BO, ""),
    ("Liquidity Risk", "Fund Liquidity Profile"): ("fund x measurement date; fund-keyed program result", BO, ""),
    ("Liquidity Risk", "Liquidity Horizon Bucket"): ("fund x measurement date x liquidity horizon bucket", BO, ""),
    # Derivatives Risk
    ("Derivatives Risk", "Designated Reference Portfolio"): ("fund x effective period", BO, ""),
    ("Derivatives Risk", "VaR Test Result"): ("fund x test date x VaR test regime; fund-keyed program result", BO, ""),
    # Risk Programs & Limits
    ("Risk Programs & Limits", "Risk Program Designation"): ("fund x risk program type x effective period", BO, ""),
    ("Risk Programs & Limits", "Risk Limit"): ("risk limit (RLMT-)", BO, ""),
    ("Risk Programs & Limits", "Risk Limit Utilization"): ("risk limit (RLMT-) or 25 counterparty trading limit x utilization date x portfolio (blank only for fund-, entity- or firm-level measurements)", BO, ""),
    ("Risk Programs & Limits", "Risk Limit Exceedance"): ("risk limit exceedance (RLEX-)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)". Row rules are in the attribute notes.
DERIVED = {
    # CD-215: sum of 26 Collateral Balance 'Collateral Value' on Received rows of the agreement, portfolio and date.
    ("Exposures", "Counterparty Exposure", "Counterparty Exposure Amount"): "26",  # row rule: Collateral Held rows only
    # Funds copy 27 Fund Net Assets Amount.
    ("Exposures", "Leverage & Exposure Measurement", "Net Assets Used"): "27",
    ("Liquidity Risk", "Fund Liquidity Profile", "Profile Net Assets"): "27",
    # Row rule: Actual rows copy 27 (funds with a NAV) or 18 (other portfolios); Hypothetical rows are computed here.
    ("Risk Measurement", "VaR Back-Test", "Realized Daily P&L"): "27",  # row rule governs: 27 or 18 on Actual rows
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the independent investment risk record of the wealth manager's own funds and its fund and institutional "
        "portfolios: risk models, factors, factor returns and instrument factor loadings; risk calculation runs, ex-ante "
        "portfolio risk measures (tracking error, volatility, VaR, expected shortfall, beta), their decomposition and VaR "
        "back-tests; portfolio exposures, counterparty exposures by measure (including every measure a 25 counterparty trading "
        "limit caps) and fund leverage measurements (Rule 18f-4 derivatives exposure and Section 18 asset coverage); stress scenarios (STRESS-), shocks, results and "
        "liquidity stress detail, including climate scenarios; Rule 22e-4 liquidity classifications, highly liquid investment "
        "minimums, fund liquidity profiles and horizon buckets; Rule 18f-4 designated reference portfolios and VaR test "
        "results; risk program designations (Rule 22e-4, Rule 18f-4, Rule 2a-7, firm risk appetite); and risk limits "
        "(RLMT-), their utilization and exceedances (RLEX-), including utilization and exceedances of 25 counterparty trading "
        "limits. Client risk profiles (02, 45) and client managed accounts (46) are not measured here."
    ),
    "references": (
        "References products, share classes, benchmarks and strategies from 01 Investment Product & Service Offering; "
        "counterparties and model vendors from the 02 party core; classification schemes from 09 Shared & Enterprise "
        "Reference Data; datasets from 14 Third-Party Data & Licensing; instruments from 17 Instrument & Issuer Reference; "
        "fund and institutional portfolios and holdings from 18 Portfolio & Investment Book of Record; employees from 20 "
        "Human Capital; curves, ETF market statistics and fair value determinations from 22 Market Data & Pricing; internal "
        "credit assessments from 23 Investment Research; counterparty trading limits from 25 Portfolio Trading & Execution; "
        "trading agreements from 26 Trade Operations, Settlement & Collateral (collateral held rows are derived copies of 26); "
        "fund NAV calculations from 27 Fund Accounting & Valuation (net assets are derived copies of 27, and realized P&L of 27 "
        "or 18); feeder access terms of the feeder funds from 01 (Form PF buckets, CW-166); "
        "portfolio climate metrics from 34 Stewardship & Sustainable Investing; board resolutions, board meetings and officer "
        "appointments from 35 Fund Governance & Regulatory Reporting; and model inventory entries from 37."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Risk Measurement", "VaR Back-Test", "Realized Daily P&L"):
        "Row rule: on Actual rows of funds with a 27 NAV it is a Derived copy (27) of the day's change in Fund Net Assets Amount excluding capital activity; on other Actual rows a Derived copy (18) of the day's change in Portfolio Valuation Summary Total IBOR Market Value excluding Portfolio Capital Activity; on Hypothetical rows it is computed here from 18 holdings and 22 approved prices.",
    ("Exposures", "Counterparty Exposure", "Counterparty Exposure Amount"):
        "Row rule: on 'Collateral Held' rows a Derived copy (26): sum of 26 Collateral Balance 'Collateral Value' on Received rows of the agreement, portfolio and date with Balance Margin Type Variation Margin, Cleared Variation Margin or Repo Collateral (regulatory initial margin held in segregation is excluded); every other measure is computed here from 18 holdings, 25 executions and 26 settlement and OTC records.",
}
