"""Enrichment for Data Domain 32 - Performance & Attribution (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Measurement Setup
    ("Measurement Setup", "Performance Calculation Policy"): ("calculation policy code x policy version", BO, ""),
    ("Measurement Setup", "Performance Measurement Profile"): ("measured subject x profile effective period", BO, ""),
    # Returns & Statistics
    ("Returns & Statistics", "Performance Return"): ("performance return (RETURN-): subject x period start x period end x fee basis x net fee basis x calculation type x price basis x tax basis x sales charge basis x currency x version", BO, ""),
    ("Returns & Statistics", "Return Component Detail"): ("performance return version (components)", AG, "Performance Return"),
    ("Returns & Statistics", "Hypothetical Performance Detail"): ("performance return version of a model or back-tested result (hypothetical detail)", AG, "Performance Return"),
    ("Returns & Statistics", "Benchmark Return"): ("01 benchmark x period start x period end x return type x currency x hedged basis x version", BO, ""),
    ("Returns & Statistics", "Ex-Post Risk Statistic"): ("subject x ex-post statistic type x period start x period end x observation frequency x fee basis x price basis x currency x comparison benchmark x version", BO, ""),
    # Client Account Performance (CW-129)
    ("Client Account Performance", "Client Performance Profile"): ("15 client account or household performance group x profile effective period", BO, ""),
    ("Client Account Performance", "Household Performance Group"): ("02 Client Household x household performance group (HPGRP-)", BO, ""),
    ("Client Account Performance", "Household Performance Group Member"): ("household performance group x 15 account x inclusion period", BO, ""),
    ("Client Account Performance", "Personal Rate of Return"): ("personal rate of return (PRROR-): subject (account or group) x period start x period end x method x fee basis x version", BO, ""),
    ("Client Account Performance", "Client Return Exception"): ("15 account x exception date x exception type", BO, ""),
    # GIPS & Composites
    ("GIPS & Composites", "GIPS Firm"): ("GIPS firm definition x effective period", BO, ""),
    ("GIPS & Composites", "GIPS Firm Assets"): ("GIPS firm x period end", AG, "GIPS Firm"),
    ("GIPS & Composites", "Composite Membership"): ("01 composite (CMP-) x 18 portfolio (PORT-) x membership start date", BO, ""),
    ("GIPS & Composites", "Composite Period Statistic"): ("01 composite x period end x period type", BO, ""),
    ("GIPS & Composites", "Significant Cash Flow Event"): ("18 portfolio x 01 composite x flow date (joined to the membership whose dates contain the flow date)", BO, ""),
    ("GIPS & Composites", "Carve-Out Allocation"): ("carve-out 18 portfolio x carve-out period", BO, ""),
    ("GIPS & Composites", "GIPS Verification"): ("GIPS verification engagement (GVER-)", BO, ""),
    # Attribution
    ("Attribution", "Attribution Model"): ("attribution model code x model version", BO, ""),
    ("Attribution", "Attribution Result"): ("attribution result (PAAN-): portfolio return version x benchmark return version x model version x result version", BO, ""),
    ("Attribution", "Attribution Segment Result"): ("attribution result x segment", BO, ""),
    ("Attribution", "Attribution Effect"): ("attribution result x segment x effect type", BO, ""),
    ("Attribution", "Contribution to Return"): ("portfolio return version x segment or instrument x calculation basis", BO, ""),
    # Performance Governance
    ("Performance Governance", "Performance Period Close"): ("close group x period end x period type", BO, ""),
    ("Performance Governance", "Performance Restatement"): ("performance return x restatement sequence", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)". Row rules are in the attribute notes.
DERIVED = {
    # Row rule: 01 highest fee of the applicable fee schedule on Highest Fee rows; set here on Model Fees rows.
    ("Measurement Setup", "Performance Measurement Profile", "Model Fee Rate"): "01",
    # Portfolio and account rows only: 18 Portfolio Valuation Summary Total IBOR Market Value (an IBOR estimate).
    # Blank on share class rows (27 NAV is referenced) and composite rows (composite assets live on Composite Period Statistic).
    ("Returns & Statistics", "Return Component Detail", "Beginning Portfolio Value"): "18",
    ("Returns & Statistics", "Return Component Detail", "Ending Portfolio Value"): "18",
    ("Returns & Statistics", "Return Component Detail", "Net External Cash Flow"): "18",
    # Row rule: 47 Fee Invoice (and Performance Fee Calculation) on net-of-actual-fee institutional separate account rows (CW-054); computed here on model fee rows.
    ("Returns & Statistics", "Return Component Detail", "Fees Deducted Amount"): "47",
    # 01 Benchmark Blend Components in effect for the period (blend rows only).
    ("Returns & Statistics", "Benchmark Return", "Blend Components Applied"): "01",
    # CW-129: client values and flows are copies of 49 (29 for fund-only accounts, 16 for plan accounts); fees of 47 (16 for plan accounts).
    # One owner is declared per attribute (the majority source); ROW_OWNERSHIP lists every source domain.
    ("Client Account Performance", "Personal Rate of Return", "Beginning Market Value"): "49",
    ("Client Account Performance", "Personal Rate of Return", "Ending Market Value"): "49",
    ("Client Account Performance", "Personal Rate of Return", "Net External Flows"): "49",
    ("Client Account Performance", "Personal Rate of Return", "Fees Deducted"): "47",
    # 18 Portfolio Capital Activity Activity Amount Base.
    ("GIPS & Composites", "Significant Cash Flow Event", "Significant Flow Amount"): "18",
    # Threshold in 01 GIPS Composite Significant Cash Flow Policy on the flow date.
    ("GIPS & Composites", "Significant Cash Flow Event", "Applied Significant Flow Threshold"): "01",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": "Masters the wealth manager's official performance record: the performance calculation policy and measurement profiles; performance returns (RETURN-) of portfolios, share classes, institutional separate accounts, GIPS composites, managed account composites and model portfolios with their components and hypothetical detail; the certified Personal Rate of Return (PRROR-) of client accounts and household performance groups (HPGRP-) with client performance profiles, group members and client return exceptions; benchmark returns; ex-post risk statistics; the GIPS firm and firm assets, composite membership, composite period statistics, significant cash flow events, carve-outs and GIPS verifications (GVER-); attribution models, results (PAAN-), segment results, effects and contribution to return; and the performance period close and restatements.",
    "references": "References composites, benchmarks, share classes, products, model portfolios and track record terms (01), households, verifiers and parties (02), compliance reviews (08), classification schemes, FX rate types and legal entities (09), datasets (14), accounts (15), instruments (17), portfolios, valuation summaries and capital activity (18), employees (20), index levels, ETF market statistics and fair value determinations (22), target allocations (24), share class NAVs and NAV error cases (27), risk models (31), product change initiatives (36), model inventory entries (37) and managed account composites (46). Client values and flows are derived copies of 49 (Client Holding Valuation, Account Cash Balance including sweep balances, Margin Balance Snapshot, Client Account Activity), 29 (Share Register Balance, Register Transaction) for fund-only accounts and 16 (Participant Balance, Participant Ledger Posting) for plan accounts; fees are derived copies of 47 (Fee Debit, Fee Invoice, Performance Fee Calculation) and, for plan accounts, of fees charged under 16 Plan Fee Schedule.",
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Measurement Setup", "Performance Measurement Profile", "Model Fee Rate"):
        "Row rule: on Highest Fee rows copied from the highest rate of the applicable 01 fee schedule (Share Class Management Fee Rate for share classes; Fee Schedule / Fee Terms (FSCH-) of the strategy or mandate for institutional separate account, account and composite rows); on Model Fees rows set by the performance team and mastered here.",
    ("Returns & Statistics", "Return Component Detail", "Ending Portfolio Value"):
        "Derived copy (18), same row rule as Beginning Portfolio Value.",
    ("Returns & Statistics", "Return Component Detail", "Fees Deducted Amount"):
        "Derived copy (47), row rule: on net-of-actual-fee institutional separate account rows copied from the 47 Fee Invoice of the account for the period (and its Performance Fee Calculation where one applies; CW-054); on model and highest fee rows computed here from the profile Model Fee Rate; blank on gross rows and on share class rows (NAV returns are already net).",
    ("Client Account Performance", "Personal Rate of Return", "Beginning Market Value"):
        "Row rule by account kind: brokerage and managed accounts copy 49 Client Holding Valuation plus 49 Account Cash Balance (Sweep Balance rows of the 50 sweep program included) less the 49 Margin Balance Snapshot Margin Debit Balance; fund-only accounts registered at the transfer agent copy 29 Share Register Balance valued at the 27 NAV; plan participant accounts copy 16 Participant Balance; group rows sum the member rows.",
    ("Client Account Performance", "Personal Rate of Return", "Ending Market Value"):
        "Row rule: as Beginning Market Value, at the period end.",
    ("Client Account Performance", "Personal Rate of Return", "Net External Flows"):
        "Row rule: brokerage and managed accounts sum 49 Client Account Activity external deposits, withdrawals and transfers; fund-only accounts sum 29 Register Transaction purchases, redemptions and transfers that cross the account boundary; plan accounts sum 16 Participant Ledger Posting contributions and distributions; group rows net transfers between members to zero.",
    ("Client Account Performance", "Personal Rate of Return", "Fees Deducted"):
        "Row rule: brokerage and advisory accounts copy 47 Fee Debit (or 47 Fee Invoice where the fee is billed); plan accounts take the fees charged under 16 Plan Fee Schedule as posted to the participant; blank on gross rows.",
    ("Client Account Performance", "Household Performance Group Member", "Member Account"):
        "Row rule: on Default (All Household Accounts) groups the member rows are derived from 02 Household Membership and 15 account ownership as of each date; on Client-Defined Subset groups they are mastered here.",
}
