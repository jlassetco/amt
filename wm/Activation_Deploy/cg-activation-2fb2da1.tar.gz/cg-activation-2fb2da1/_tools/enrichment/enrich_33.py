"""Enrichment for Data Domain 33 - Investment Compliance (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Rule Library
    ("Rule Library", "Regulatory Limit Provision"): ("regulatory provision citation x limit component x effective period", BO, ""),
    ("Rule Library", "Rule Library"): ("rule library code x library version", BO, ""),
    ("Rule Library", "Rule Library Membership"): ("rule library version x compliance rule version", BO, ""),
    ("Rule Library", "Compliance Rule"): ("compliance rule (CRULE-) x rule version", BO, ""),
    ("Rule Library", "Rule Source Link"): ("compliance rule version x source (investment restriction, client restriction, regulatory limit provision or firm policy)", BO, ""),
    # Rule Coding & Assignment
    ("Rule Coding & Assignment", "Rule Assignment"): ("library version or rule version x portfolio x effective period", BO, ""),
    ("Rule Coding & Assignment", "Rule Instrument List"): ("rule instrument list code x list version", BO, ""),
    ("Rule Coding & Assignment", "Rule Instrument List Member"): ("firm-maintained rule instrument list x instrument or issuer x effective period", BO, ""),
    ("Rule Coding & Assignment", "Rule Coding Request"): ("rule coding request", BO, ""),
    ("Rule Coding & Assignment", "Restriction Coding Status"): ("source restriction (investment restriction or client restriction) x effective period", BO, ""),
    # Checks & Results
    ("Checks & Results", "Compliance Check Run"): ("compliance check run (CCHK-)", BO, ""),
    ("Checks & Results", "Pre-Trade Check Subject"): ("compliance check run (the one pre-trade subject)", AG, "Compliance Check Run"),
    ("Checks & Results", "Check Subject Member"): ("pre-trade compliance check run x tested trade order", BO, ""),
    ("Checks & Results", "Compliance Rule Result"): ("compliance check run x portfolio x compliance rule version x evaluated issuer, instrument or group (blank for whole-portfolio rules)", BO, ""),
    # Alerts & Overrides
    ("Alerts & Overrides", "Compliance Alert"): ("compliance alert (CALERT-)", BO, ""),
    ("Alerts & Overrides", "Alert Disposition"): ("compliance alert x disposition sequence", BO, ""),
    ("Alerts & Overrides", "Pre-Trade Override Approval"): ("compliance alert x override approval sequence", BO, ""),
    # Breaches & Remediation
    ("Breaches & Remediation", "Investment Breach"): ("investment breach (BREACH-): portfolio x compliance rule x issuer, instrument or group x breach start date", BO, ""),
    ("Breaches & Remediation", "Breached Source Restriction"): ("investment breach x additional source restriction", BO, ""),
    ("Breaches & Remediation", "Breach Remediation Action"): ("investment breach x remediation action sequence", BO, ""),
    ("Breaches & Remediation", "Breach Loss Calculation"): ("investment breach x loss calculation version", BO, ""),
    ("Breaches & Remediation", "Breach Review"): ("investment breach x breach review sequence", BO, ""),
    # Waivers & Program Oversight
    ("Waivers & Program Oversight", "Guideline Waiver"): ("guideline waiver (compliance rule x portfolio x scope x waiver period)", BO, ""),
    ("Waivers & Program Oversight", "Periodic Rule Review"): ("compliance rule or rule library x rule review date", BO, ""),
    ("Waivers & Program Oversight", "Manual Compliance Check"): ("source restriction x portfolio x check period", BO, ""),
}

# Attributes that hold a copy of a value mastered elsewhere without a Reference type. None: Limit Applied is test-time
# evidence read from this domain's own rule version or guideline waiver, Tested Quantity is the quantity as tested (not
# the 25 order quantity after amendment), and Denominator Value is the engine's own computation. Cure Action and Alert
# disposition links are derived within 33, not copies from another domain.
DERIVED = {
    # CD-237 (program lead ruling, Stage 3 consolidation): the board approval is held on 35 Resolution Subject Link.
    ("Waivers & Program Oversight", "Guideline Waiver", "Board Approval Date"): "35",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the investment compliance program of the wealth manager's own funds, CITs and institutional separate accounts: "
        "its coded rule base and its evidence: regulatory limit provisions (the "
        "single home of statutory limit values), rule libraries and their membership by version, compliance rules (CRULE-) "
        "with logic, limits, warning levels, applicability and effective-dated approved versions, rule source links, rule "
        "assignments of pinned versions to portfolios, rule instrument lists and the members of firm-maintained lists, rule "
        "coding requests and restriction coding status, compliance check runs (CCHK-) with the pre-trade check subject and "
        "per-order check subject members carrying the outcome that 25 copies, compliance rule results, compliance alerts "
        "(CALERT-) with their dispositions and pre-trade override approvals, investment breaches (BREACH-) with their source "
        "restrictions, remediation actions, loss calculations and reviews, guideline waivers, periodic rule reviews and "
        "manual compliance checks. Client-account checks of the brokerage and advice businesses are 45, 46 and 48."
    ),
    "references": (
        "References investment restrictions, mandates and products from 01 Investment Product & Service Offering; client "
        "restrictions, issuers and client approvers from 02 Client & Household; licensed datasets from 14 Third-Party Data & Licensing; instruments "
        "from 17 Instrument & Issuer Reference; portfolios from 18 Portfolio & Investment Book of Record; employees from 20 "
        "Human Capital; data quality issues from 21 Data Governance & Analytics; proposed trades from 24 Portfolio Management "
        "& Construction; trade orders, block orders and trade errors from 25 Portfolio Trading & Execution; NAV error cases from 27 Fund "
        "Accounting & Valuation; risk measurements from 31 Investment Risk; sustainability "
        "exclusion lists from 34 Stewardship & Sustainable Investing; reportable fund events and board approval dates (read through Resolution Subject Link) from 35 "
        "Fund Governance & Regulatory Reporting; product change initiatives from 36 Product Development & Lifecycle; and legal "
        "entities from 09 Shared & Enterprise Reference Data. 12 Breach Notification, 25 Trade Order Event and 35 board "
        "reporting reference the breaches and check outcomes mastered here."
    ),
}
