"""Enrichment for Data Domain 34 - Stewardship & Sustainable Investing (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Stewardship Policies
    ("Stewardship Policies", "Voting Policy"): ("voting policy x version (VPOL-)", BO, ""),
    ("Stewardship Policies", "Voting Guideline"): ("voting policy version x guideline code", BO, ""),
    ("Stewardship Policies", "Voting Authority Arrangement"): ("portfolio (PORT-) or client account (ACC-) x authority effective period", BO, ""),
    # Investee Meetings & Votes
    ("Investee Meetings & Votes", "Investee Meeting Agenda Item"): ("investee meeting (17 CAE-) x agenda item number", BO, ""),
    ("Investee Meetings & Votes", "Proxy Advisor Recommendation"): ("agenda item x proxy advisor (PTY-) x advisor policy", BO, ""),
    ("Investee Meetings & Votes", "Ballot"): ("meeting (17 CAE-, or 13 PRX- for an own fund) x safekeeping account (28 SKA-)", BO, ""),
    ("Investee Meetings & Votes", "Vote Rationale"): ("vote decision: agenda item (or 13 proxy proposal) x voting policy applied", BO, ""),
    ("Investee Meetings & Votes", "Vote Instruction"): ("vote instruction (VOTE-): ballot x agenda item (or 13 proxy proposal)", BO, ""),
    ("Investee Meetings & Votes", "Lending Recall Decision"): ("investee meeting (17 CAE-) x securities loan (28 SBL-)", BO, ""),
    # Engagement
    ("Engagement", "Engagement"): ("engagement case (ENGM-)", BO, ""),
    ("Engagement", "Engagement Objective"): ("engagement x objective sequence", BO, ""),
    ("Engagement", "Engagement Interaction"): ("engagement interaction (interaction ID: engagement x interaction number)", BO, ""),
    ("Engagement", "Escalation Action"): ("engagement x escalation sequence", BO, ""),
    ("Engagement", "Collaborative Initiative Membership"): ("initiative (PTY-) x firm legal entity (LEN-) x membership effective period", BO, ""),
    # ESG Data & Assessments
    ("ESG Data & Assessments", "Sustainability Indicator Definition"): ("indicator code x version (one indicator level per code)", BO, ""),
    ("ESG Data & Assessments", "Issuer Sustainability Observation"): ("issuer (PTY-) or instrument (INS-) x issuer-level indicator x reporting period end x source dataset x as-of date", BO, ""),
    ("ESG Data & Assessments", "ESG Rating Observation"): ("issuer x rating source dataset x ESG rating type x rating as-of date", BO, ""),
    ("ESG Data & Assessments", "Firm ESG Assessment"): ("firm ESG assessment version (ESGA-): issuer x strategy scope x assessment date", BO, ""),
    ("ESG Data & Assessments", "Sustainability Exclusion List"): ("exclusion list code x version", BO, ""),
    ("ESG Data & Assessments", "Exclusion List Member"): ("exclusion list code x issuer or instrument x member effective period", BO, ""),
    # Portfolio Sustainability Metrics & Product Outcomes
    ("Portfolio Sustainability Metrics & Product Outcomes", "Portfolio Sustainability Metric"): ("portfolio, product or legal entity x period end x portfolio-level indicator x emission scopes x measurement basis", BO, ""),
    # Financed Emissions & Climate Targets
    ("Financed Emissions & Climate Targets", "Financed Emissions Holding Detail"): ("portfolio sustainability metric (financed emissions) x portfolio holding (HLD-)", AG, "Portfolio Sustainability Metric"),
    ("Financed Emissions & Climate Targets", "Climate Target"): ("climate target code", BO, ""),
    # Stewardship Disclosure & Reporting
    ("Stewardship Disclosure & Reporting", "Proxy Voting Report"): ("proxy voting report (report ID): reporting person (fund series PRD-, manager LEN- or client account ACC-) x report type x period", BO, ""),
    ("Stewardship Disclosure & Reporting", "Stewardship Report"): ("stewardship report (report ID): framework x reporting entity (or product) x period", BO, ""),
    ("Stewardship Disclosure & Reporting", "Reported Engagement"): ("stewardship report x engagement", AG, "Stewardship Report"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Eligible Balance of the referenced 28 Corporate Action Entitlement; own-fund meetings without an entitlement: 18 holding.
    ("Investee Meetings & Votes", "Ballot", "Record Date Shares"): "28",
    # 28 Securities Loan quantity on loan at the record date and not returned before it (needs a dated loan quantity in 28).
    ("Investee Meetings & Votes", "Ballot", "Shares on Loan Not Recalled"): "28",
    # Market value of the 18 portfolio holding at the measurement date.
    ("Financed Emissions & Climate Targets", "Financed Emissions Holding Detail", "Holding Value Used"): "18",
    # Owner by row: 22 pricing analytics (listed EVIC, primary), 14 vendor dataset (vendor EVIC), 22 fair value determinations
    # (private companies held through 17 private market instruments), 14 sovereign dataset (PPP-adjusted GDP).
    ("Financed Emissions & Climate Targets", "Financed Emissions Holding Detail", "Attribution Denominator Value"): "22",
}

# Composite keys of 34 records start with another domain's prefix (CAE-, PORT-, LEN-), so the resolver would point them
# elsewhere; force "mastered here".
OWNERSHIP_OVERRIDES = {
    # 13 own-fund meeting records (examples blank because most ballots are investee meetings)
    ("Investee Meetings & Votes", "Ballot", "Own Fund Proxy Campaign"): "13",
    ("Investee Meetings & Votes", "Vote Rationale", "Rationale Fund Proxy Proposal"): "13",
    ("Investee Meetings & Votes", "Vote Instruction", "Voted Fund Proxy Proposal"): "13",
}

SUMMARY = {
    "masters": "Masters the US wealth manager's stewardship and sustainable investment record: voting policies, guidelines, the investor choice voting options offered to fund shareholders and voting authority arrangements; investee meeting agenda items, proxy advisor recommendations, ballots, vote decisions and rationale, vote instructions and lending recall decisions; engagements with their objectives, interactions and escalations, and collaborative initiative memberships; sustainability indicator definitions, issuer sustainability and ESG rating observations, firm ESG assessments and sustainability exclusion lists; portfolio sustainability metrics in one indicator vocabulary, financed emissions attribution and climate targets; and proxy voting report and stewardship report content. US only: SFDR, PAI, EU Taxonomy, UK SDR and UK Stewardship Code content left under CW-934.",
    "references": "References products, ESG characteristics and restrictions (01), issuers, proxy advisors and initiatives (02), client accounts (15), licensed datasets (14), meeting events, instruments and sustainable bond labels (17), own-fund proxy campaigns and proposals and fund shareholders' investor choice elections (13), portfolios and holdings (18), legal entities, geography and units of measure (09), employees (20), issuer meetings (23), investment decisions (24), safekeeping accounts, entitlements and securities loans (28), EVIC inputs (22), with hand-offs to 12 (client reporting), 31 (climate stress), 33 (coded rules) and 35 (board approval and N-PX filing, held by 35).",
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Investee Meetings & Votes", "Ballot", "Record Date Shares"):
        "Derived copy (28). Row rule: the Eligible Balance of the referenced 28 Corporate Action Entitlement; where no entitlement exists (own-fund meetings), the 18 portfolio holding quantity on the record date.",
    ("Investee Meetings & Votes", "Ballot", "Shares on Loan Not Recalled"):
        "Derived copy (28). Row rule: quantity of the meeting instrument lent from the account under 28 Securities Loans that was on loan at the record date and not returned before it. Needs a dated on-loan quantity in 28 (requested in proposals_34); the 34 recall decision is not an input.",
}
