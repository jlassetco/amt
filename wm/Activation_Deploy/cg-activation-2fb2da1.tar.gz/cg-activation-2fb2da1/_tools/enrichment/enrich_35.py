"""Enrichment for Data Domain 35 - Fund Governance & Regulatory Reporting (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Governing Bodies
    ("Governing Bodies", "Fund Governing Body"): ("fund governing body or board committee (BOARD-)", BO, ""),
    ("Governing Bodies", "Governed Fund Coverage"): ("governing body x governed product x coverage effective period", BO, ""),
    ("Governing Bodies", "Governing Body Membership"): ("governing body x member (party or employee) x member role x membership effective period", BO, ""),
    ("Governing Bodies", "Fund Officer Appointment"): ("registrant or entity x fund officer role x officer x appointment effective period", BO, ""),
    ("Governing Bodies", "Governance Standards Profile"): ("governing body x standards assessment date", AG, "Fund Governing Body"),
    # Board Meetings & Reports
    ("Board Meetings & Reports", "Board Meeting"): ("governing body x meeting date x sequence (BMEET-), including actions by written consent", BO, ""),
    ("Board Meetings & Reports", "Board Agenda Item"): ("board meeting x agenda item number", BO, ""),
    ("Board Meetings & Reports", "Board Report Received"): ("board meeting x board report type x report period x reported funds or 31 risk program", BO, ""),
    ("Board Meetings & Reports", "Board Report Source Item"): ("board report x source record", AG, "Board Report Received"),
    ("Board Meetings & Reports", "Board Self-Assessment"): ("governing body x assessment year", BO, ""),
    # Board Approvals & Resolutions
    ("Board Approvals & Resolutions", "Board Resolution"): ("board resolution (RESO-): board meeting x resolution", BO, ""),
    ("Board Approvals & Resolutions", "Resolution Subject Link"): ("board resolution x approved subject", BO, ""),
    ("Board Approvals & Resolutions", "Resolution Vote Count"): ("board resolution (vote counts)", AG, "Board Resolution"),
    ("Board Approvals & Resolutions", "Fund Fidelity Bond"): ("fidelity bond policy x coverage period", BO, ""),
    # Advisory Contract Oversight
    ("Advisory Contract Oversight", "Fund Advisory Agreement"): ("fund advisory agreement (ADVA-)", BO, ""),
    ("Advisory Contract Oversight", "Agreement Fund Schedule"): ("advisory agreement x covered fund x approval cycle (initial approval or RENEW- renewal)", BO, ""),
    ("Advisory Contract Oversight", "Advisory Contract Renewal"): ("advisory agreement x renewal year (RENEW-)", BO, ""),
    ("Advisory Contract Oversight", "Renewal Material Item"): ("advisory contract renewal x renewal material type x source record", BO, ""),
    ("Advisory Contract Oversight", "Board 15(c) Finding"): ("advisory contract renewal x 15(c) factor", BO, ""),
    # Regulatory Filings & Disclosures
    ("Regulatory Filings & Disclosures", "Filing Obligation"): ("filer (product or entity) x form type x filing state (state notice filings only) x obligation effective period", BO, ""),
    ("Regulatory Filings & Disclosures", "Fund Regulatory Filing"): ("fund regulatory filing (REGF-): filer x form type x filing state (state notice filings only) x reporting period end or event / as-of date x event reference x submission sequence", BO, ""),
    ("Regulatory Filings & Disclosures", "Filing Document"): ("fund regulatory filing x filed document", AG, "Fund Regulatory Filing"),
    ("Regulatory Filings & Disclosures", "Filing Certification"): ("fund regulatory filing x certification type x certifying officer", AG, "Fund Regulatory Filing"),
    ("Regulatory Filings & Disclosures", "Filing Data Source"): ("fund regulatory filing x filing data source type x source record selection", BO, ""),
    ("Regulatory Filings & Disclosures", "Fund Public Disclosure"): ("product or share class x public disclosure type x disclosure as-of date", BO, ""),
    # Fund Regulatory Status
    ("Fund Regulatory Status", "RIC Qualification Determination"): ("fund x tax year", BO, ""),
    ("Fund Regulatory Status", "Reportable Fund Event"): ("fund x reportable event type x event date", BO, ""),
    ("Fund Regulatory Status", "Exemptive Relief Reliance"): ("fund x exemptive relief (order or rule) x reliance effective period", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # CD-209: the business line of a fund is mastered on the 18 Portfolio that implements it.
    ("Governing Bodies", "Governed Fund Coverage", "Covered Business Line"): "18",
    # 13 Proxy Campaign meeting date of the proxy proposal that approved the agreement for the fund.
    ("Advisory Contract Oversight", "Agreement Fund Schedule", "Shareholder Approval Date"): "13",
    # Row rule: on 'Shareholder Report Website Availability' rows a copy of 13 Website Availability Date; other rows mastered here.
    ("Regulatory Filings & Disclosures", "Fund Public Disclosure", "Publication Timestamp"): "13",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the governance record and the regulatory filings of the wealth manager's own US funds: fund governing bodies "
        "(registrant boards and committees, CIT trustee fiduciary committees), "
        "governed fund coverage, memberships and independence status, fund officer appointments and governance standards; board "
        "meetings, agenda items, reports received with their source items, and self-assessments; board resolutions, their "
        "subject links (the only record of what a board approved), vote counts, and fund fidelity bonds; fund "
        "advisory agreements, their per-fund schedules and Section 15(c) renewals, materials and findings; filing obligations, "
        "fund regulatory filings with their documents, certifications and data sources, and fund public website disclosures; "
        "RIC qualification determinations, reportable fund events and exemptive relief reliance. Firm-level filings of the "
        "adviser and broker-dealer are 38 and 19."
    ),
    "references": (
        "References funds, share classes, fee schedules, service-provider roles and product documents from 01 Investment Product & "
        "Service Offering; external members, counsel, insurers, third-party CIT trustees, sub-advisers and filing agents from the "
        "02 party core; "
        "legal entities and calendars from 09; profitability records from 10; fee benchmark studies and peer universes from 11; "
        "proxy proposals and shareholder communications from 13; employees from 20; data quality results from 21; fair value "
        "determinations and ETF market statistics from 22; ETF baskets from 24; RIC test results, fund tax years and fund "
        "financial statements from 27; deals from 30 (private funds, left for W4); liquidity, VaR, risk program and risk limit records from 31, returns from "
        "32, breaches, guideline waivers and rule results from 33, proxy voting reports and voting policies from 34, and product "
        "proposals, change initiatives and reviews from 36."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Advisory Contract Oversight", "Fund Advisory Agreement", "Termination Reason"):
        "Row rule (CW-121): for a sub-advisory agreement ended by a 52 Manager Termination, a Derived copy of Manager "
        "Termination.Termination Reason; mastered in 35 on every other row (adviser agreements, board or shareholder terminations).",
    ("Regulatory Filings & Disclosures", "Fund Public Disclosure", "Publication Timestamp"):
        "Row rule: on 'Shareholder Report Website Availability' rows a Derived copy of 13 Shareholder Communication.Website Availability Date; every other row is mastered here.",
}
