"""Enrichment for Data Domain 36 - Product Development & Lifecycle (contract v0.3): grain, ownership flags, summary.

Wealth-manager adaptation (W4, CW-161, CW-936): Target Market Review Result and Value Assessment Criterion Result are
removed; Service Offering Specification, Platform Feature Specification and Product Review Criterion Result are added.
Fix pass (program-lead ruling 2): every kept object keeps its wholesale kind, because keys_e7_30_36 keys the kept business
objects without a fold flag and an attribute group may not sit under an attribute group; the two new specifications are
attribute groups of Product Change Initiative and the criterion result is a business object (18 BO, 6 AG).
"""

BO, AG = "Business Object", "Attribute Group"

F_IDE = "Product Ideas & Proposals"
F_GOV = "Product Governance"
F_CHG = "Product Change & Lifecycle Events"
F_LCH = "Launch & Readiness"
F_PRV = "Product Reviews"

GRAIN = {
    # Product Ideas & Proposals
    (F_IDE, "Product Proposal"): ("product proposal (PPSL-): fund, share class range, service offering or platform feature proposal", BO, ""),
    (F_IDE, "Proposal Stage History"): ("proposal x proposal stage x stage entered date", BO, ""),
    (F_IDE, "Product Business Case"): ("proposal x business case version", BO, ""),
    (F_IDE, "Business Case Market Evidence"): ("business case version x evidence sequence", AG, "Product Business Case"),
    # Product Governance
    (F_GOV, "Product Governance Committee"): ("product governance committee (committee code)", BO, ""),
    (F_GOV, "Product Committee Membership"): ("committee x member employee x role x effective period", BO, ""),
    (F_GOV, "Product Committee Meeting"): ("committee x meeting date x meeting sequence", BO, ""),
    (F_GOV, "Product Approval Decision"): ("product approval decision (PAPR-): meeting x agenda item", BO, ""),
    # Product Change & Lifecycle Events
    (F_CHG, "Product Change Initiative"): ("product change initiative (LCHG-)", BO, ""),
    (F_CHG, "Changed Product Scope"): ("change initiative x product, share class, model portfolio, service offering or service tier x scope role", BO, ""),
    (F_CHG, "Proposed Term Change"): ("change initiative x product term x product, share class, model portfolio, service offering or service tier", BO, ""),
    (F_CHG, "Share Class Specification"): ("change initiative x product x proposed share class designation", BO, ""),
    (F_CHG, "Service Offering Specification"): ("change initiative x offering specification sequence", AG, "Product Change Initiative"),
    (F_CHG, "Platform Feature Specification"): ("change initiative x specified feature type", AG, "Product Change Initiative"),
    (F_CHG, "Fund Reorganization Detail"): ("change initiative (merger or shell reorganization, including an ETF shell conversion)", AG, "Product Change Initiative"),
    (F_CHG, "ETF Conversion Detail"): ("change initiative (mutual fund to ETF conversion)", AG, "Product Change Initiative"),
    (F_CHG, "Liquidation Detail"): ("change initiative (liquidation)", AG, "Product Change Initiative"),
    (F_CHG, "Change Impact Assessment"): ("change initiative x impact area", BO, ""),
    (F_CHG, "Change Regulatory Requirement"): ("change initiative x regulatory requirement type x requirement product x requirement country", BO, ""),
    # Launch & Readiness
    (F_LCH, "Product Readiness Plan"): ("change initiative x readiness plan version", BO, ""),
    (F_LCH, "Readiness Check"): ("readiness plan version x workstream x check", BO, ""),
    # Product Reviews
    (F_PRV, "Product Review"): ("product review (PRVW-): product, share class, model portfolio, service offering or platform feature specification x review type x review period", BO, ""),
    (F_PRV, "Product Review Criterion Result"): ("product review x product review criterion x share class (or the reviewed subject as a whole)", BO, ""),
    (F_PRV, "Review Action"): ("product review x action sequence", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Stage 4 consolidation (stage4_consolidation_notes §1): copies of 37-43 masters; row rules in the attribute notes.
    (F_CHG, "Product Change Initiative", "Launch Project Code"): "41",
    # CD-236 row rule: the 01 value as at the proposal date, kept as evidence; never the current value.
    (F_CHG, "Proposed Term Change", "Current Term Rate"): "01",
    (F_CHG, "Proposed Term Change", "Current Term Text"): "01",
    # AUM read from 06 Asset Measures or Client Asset Measures. (Account counts are computed here from 15 and flagged mastered here.)
    (F_CHG, "Change Impact Assessment", "Affected AUM"): "06",
    # Row Ownership Rule: one source per evidence group of the requirement type. Primary derived owner 35 (four of the
    # seven groups are 35 or derived the same way); the 38, 13 and 47 groups and the mastered-here FINRA prior approval are
    # stated in ROW_OWNERSHIP and in the attribute notes.
    (F_CHG, "Change Regulatory Requirement", "Requirement Status"): "35",
    (F_CHG, "Change Regulatory Requirement", "Requirement Satisfied Date"): "35",
    # CD-238 (CW-161): review evidence counts, never re-mastered. Complaints: 08 Complaint.Product / Share Class, or
    # Complaint.Account -> 15 Program Enrollment.Enrolled Service Offering at Received Date. Drift: 46 Drift Assessment
    # Tolerance Breached Indicator of the Assessed Account enrolled (15) in the reviewed offering.
    (F_PRV, "Product Review Criterion Result", "Complaint Evidence Count"): "08",
    (F_PRV, "Product Review Criterion Result", "Drift Exception Evidence Count"): "46",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the product development and product governance record of the wealth manager's range of funds, advice and "
        "service offerings and brokerage platform features: product proposals with their stage history, business cases and "
        "market evidence citations; product committees, memberships, meetings and product approval decisions; product change "
        "initiatives of every type (fund and share class launches, closes, fee, name, objective and benchmark changes, mergers, "
        "ETF conversions, liquidations, advice program launches, program and pricing changes and closures, service tier changes, "
        "platform feature launches, changes and retirements) with the products, share classes, model portfolios and service "
        "offerings they touch, proposed term values, share class, service offering and platform feature specifications, "
        "reorganization, conversion and liquidation details, impact assessments and regulatory, board and client-notice "
        "requirements; launch readiness plans and checks; and product reviews with their criterion results and review actions."
    ),
    "references": (
        "References strategies, products, share classes, model portfolios, service offerings, tradable universe policy rules, "
        "platform product availability, benchmarks, listings and product documents (and copies current term values as at the "
        "proposal date) from 01 Investment Product & Service Offering; seed investors from 02; agreements, shelf placements "
        "and model program placements from 05 (IC line); fund and client asset measures from 06; complaint counts from 08; "
        "legal entities from 09; profitability records, flow and revenue forecasts and pricing scenarios from 10; peer "
        "universes, fee benchmark studies, competitor pricing observations, market sizing records and competitor events from "
        "11; shareholder and client communications and proxy proposals from 13; index uses from 14; account registration types, "
        "feature and disclosure types (and account counts) from 15; seed portfolios from 18; employees from 20; metric "
        "definitions from 21; pricing policies from 22; fund accounting books from 27; safekeeping accounts from 28; TA control "
        "checks from 29; fund liquidity profiles from 31; performance and benchmark returns from 32; rule coding requests from "
        "33; fund regulatory filings (including state notice filings), exemptive relief reliance and board and trustee "
        "approvals (through 35 Resolution Subject Link) from 35; firm regulatory filings and policies from 38; releases and "
        "projects from 41; drift assessment counts from 46; and client fee schedules and fee change notice deliveries from 47."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
_REQ_RULE = ("One source per evidence group of the Regulatory Requirement Type: Board or Trustee Approval -> 35 Resolution "
             "Subject Link / Board Resolution; Fund Filing (including State Notice Filing) -> 35 Fund Regulatory Filing in "
             "Satisfying Filing; Exemptive Relief -> 35 Exemptive Relief Reliance; Firm Filing (Form ADV, Form CRS) -> 38 Firm "
             "Regulatory Filing in Satisfying Firm Filing; Shareholder or Client Notice or Vote -> 13 Communication "
             "Distribution or Proxy Proposal; Client Fee Notice -> 47 Fee Disclosure Delivery rows for the proposed schedule; "
             "Regulator Prior Approval (FINRA Continuing Membership Application) -> mastered here. Full mapping in the "
             "Requirement Change Initiative notes.")
ROW_OWNERSHIP = {
    (F_CHG, "Proposed Term Change", "Current Term Rate"):
        "Derived copy (01) as at Term Proposed Date (row rule, CD-236); never refreshed and never used as the current value.",
    (F_CHG, "Proposed Term Change", "Current Term Text"):
        "Derived copy (01) as at Term Proposed Date (row rule, CD-236). Exactly one of the rate, text, benchmark and fee schedule values is filled, per the Product Term Name.",
    (F_CHG, "Change Regulatory Requirement", "Requirement Status"): _REQ_RULE,
    (F_CHG, "Change Regulatory Requirement", "Requirement Satisfied Date"): _REQ_RULE,
}
