"""Enrichment for Data Domain 37 - Enterprise & Operational Risk (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Risk Framework & Register
    ("Risk Framework & Register", "Risk Taxonomy Category"): ("risk category code x taxonomy version", BO, ""),
    ("Risk Framework & Register", "Enterprise Risk"): ("enterprise risk (RISK-)", BO, ""),
    ("Risk Framework & Register", "Risk Assessment"): ("enterprise risk x assessment date", BO, ""),
    ("Risk Framework & Register", "Risk Appetite Statement"): ("appetite statement code x scope entity (blank for firm-wide) x effective period", BO, ""),
    # Risk & Control Self-Assessment
    ("Risk & Control Self-Assessment", "RCSA Campaign"): ("campaign code x assessed org unit", BO, ""),
    ("Risk & Control Self-Assessment", "Control"): ("control (CNTRL-) x control version", BO, ""),
    ("Risk & Control Self-Assessment", "Risk Control Link"): ("enterprise risk x control x effective period", BO, ""),
    ("Risk & Control Self-Assessment", "Control Test"): ("control version x test date x test sequence", BO, ""),
    # Operational Incidents & Losses
    ("Operational Incidents & Losses", "Operational Incident"): ("operational incident (OPINC-)", BO, ""),
    ("Operational Incidents & Losses", "Incident Source Record"): ("operational incident x source record (one typed source per row)", BO, ""),
    ("Operational Incidents & Losses", "Incident Classification"): ("operational incident (classification)", AG, "Operational Incident"),
    ("Operational Incidents & Losses", "Incident Regulatory Notification"): ("operational incident x authority x notification regime x notification stage", BO, ""),
    ("Operational Incidents & Losses", "Operational Loss Event"): ("operational loss event (LOSS-)", BO, ""),
    ("Operational Incidents & Losses", "Loss Event Amount"): ("operational loss event x amount sequence", BO, ""),
    # Key Risk Indicators
    ("Key Risk Indicators", "Key Risk Indicator"): ("KRI code x KRI version", BO, ""),
    ("Key Risk Indicators", "KRI Threshold"): ("KRI version (thresholds)", AG, "Key Risk Indicator"),
    ("Key Risk Indicators", "KRI Observation"): ("KRI version x observation date", BO, ""),
    # Issues & Actions
    ("Issues & Actions", "Risk Issue"): ("risk issue (ISSUE-)", BO, ""),
    ("Issues & Actions", "Issue Action"): ("risk issue x action sequence", BO, ""),
    # Operational Resilience & Continuity
    ("Operational Resilience & Continuity", "Critical or Important Function"): ("critical function code x designating entity x effective period", BO, ""),
    ("Operational Resilience & Continuity", "Resilience Resource Mapping"): ("critical or important function x resource x effective period", BO, ""),
    ("Operational Resilience & Continuity", "Business Impact Analysis"): ("business process x analysis date", BO, ""),
    ("Operational Resilience & Continuity", "Business Continuity Plan"): ("plan code x plan version", BO, ""),
    ("Operational Resilience & Continuity", "Resilience Test"): ("resilience test reference x test date", BO, ""),
    # Third-Party Risk
    ("Third-Party Risk", "Third-Party Risk Assessment"): ("third party x 40 supplier engagement x assessment cycle", BO, ""),
    ("Third-Party Risk", "Third-Party Risk Domain Result"): ("third-party risk assessment x risk domain", BO, ""),
    # Model Risk Management
    ("Model Risk Management", "Model Inventory Entry"): ("model (MODEL-) x model version", BO, ""),
    ("Model Risk Management", "Model Tier Assignment"): ("model x effective period", BO, ""),
    ("Model Risk Management", "Model Validation"): ("model version x validation sequence", BO, ""),
    ("Model Risk Management", "Model Performance Monitoring"): ("model version x monitoring test x monitoring period end date", BO, ""),
    # Internal Audit
    ("Internal Audit", "Auditable Entity"): ("audit universe entry x effective period", BO, ""),
    ("Internal Audit", "Audit Plan"): ("plan year x plan version", BO, ""),
    ("Internal Audit", "Audit Engagement"): ("audit engagement (AUDIT-)", BO, ""),
    ("Internal Audit", "Audit Finding"): ("audit finding (AUDF-)", BO, ""),
    ("Internal Audit", "Finding Closure Validation"): ("audit finding x validation attempt sequence", BO, ""),
}

# Row rules (plan §4 item 9). One owner per attribute is required here, so the primary source is named; the attribute
# notes state every source and the rows mastered in 37.
DERIVED = {
    # Gross loss borne by the firm: 25 Reimbursement Amount, 27 firm-borne Fund Loss Amount, 33 Compensation Amount,
    # 26 firm-absorbed Penalty Amount; mastered here on rows with no source.
    ("Operational Incidents & Losses", "Loss Event Amount", "Loss Amount"): "25",
    # Client or portfolio impact: 25 Error Gain or Loss Amount, 27 Fund Loss Amount, 33 Breach Loss Amount, or the sum of
    # 13 Shareholder Remediation Compensation Amount by servicing error; mastered here otherwise.
    ("Operational Incidents & Losses", "Operational Loss Event", "Impact Amount"): "27",
    # Approvals are linked only from 39 Corporate Resolution Subject Link (program lead ruling 1).
    ("Risk Framework & Register", "Risk Appetite Statement", "Appetite Approval Date"): "39",
    ("Internal Audit", "Audit Plan", "Audit Plan Approval Status"): "39",
    # Copied from 21 Metric Definition when the KRI has a Source Metric Definition; mastered here otherwise.
    ("Key Risk Indicators", "Key Risk Indicator", "KRI Definition"): "21",
    ("Key Risk Indicators", "KRI Threshold", "KRI Threshold Direction"): "21",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the US wealth manager's non-financial risk and internal audit record: the risk taxonomy, enterprise risks (RISK-), "
        "their assessments and risk appetite statements; RCSA campaigns, the control library (CNTRL-), risk control links and "
        "control tests by the first line, compliance monitoring and risk; operational incidents (OPINC-) with their source "
        "records, Basel classification and notifications by regime and stage (Regulation S-P customer and state breach notifications; FINRA Rule 4530 reports where a 4530 event is involved); "
        "operational loss events (LOSS-) and the firm-borne loss and impact amounts that have no source record; key risk indicators, thresholds and "
        "observations; risk issues (ISSUE-) and actions, including risk acceptances; critical or important functions, resource "
        "mappings, business impact analyses, business continuity plans (FINRA Rule 4370) and resilience tests; third-party "
        "residual risk assessments; the model inventory (MODEL-) with tiers, validations and "
        "monitoring; and the audit universe, audit plans, engagements (AUDIT-), findings (AUDF-) and closure validations. US only: "
        "DORA, the UK important business services and impact tolerances and FCA notifications left under CW-937."
    ),
    "references": (
        "References parties from 02 Client & Household; legal entities, org units and office locations from 09; employees and "
        "workforce positions from 20; products from 01 and portfolios from 18; trade errors (25), NAV error cases (27), "
        "investment breaches (33), risk limit exceedances (31), servicing errors and shareholder remediation (13), settlement "
        "penalties and fails charges (26), plan corrections (16), AP orders and account monitoring alerts (29), "
        "model portfolios (01) and health and safety incidents (44) as incident and loss sources, copying loss and impact amounts from them; journal entries from 19; metric definitions (copying KRI definitions and directions) and data "
        "assets from 21; vendor risk assessments and assurance reports from 14; VaR back-tests from 31; examination findings "
        "and compliance program reviews from 38; legal matters from 39 (and approval dates from its corporate resolutions); supplier engagements from 40 (whose outsourcing arrangements reference the critical functions); applications, IT services, IT incidents, "
        "vulnerability findings and security and resilience tests from 41; and physical security incidents from 44."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Operational Incidents & Losses", "Operational Loss Event", "Impact Amount"):
        "Row rule (program lead ruling 3): where the event's Gross Loss row references a source, Derived copy of 25 Trade Error.Error Gain or Loss Amount (sign reversed), 27 NAV Error Case.Fund Loss Amount or 33 Breach Loss Calculation.Breach Loss Amount (latest approved version); where Impact Source Servicing Error is filled, the sum of 13 Shareholder Remediation.Compensation Amount over the remediation rows of that error (a sum by incident, not a per-row copy); otherwise mastered here.",
    ("Operational Incidents & Losses", "Loss Event Amount", "Loss Amount"):
        "Row rule (CD-244, program lead ruling 3): Derived copy where a typed source column is filled: 25 Trade Error.Reimbursement Amount, 27 NAV Error Case.Fund Loss Amount where the Reimbursing Entity is an internal legal entity (the firm-borne cost), 33 Breach Loss Calculation.Compensation Amount where the Compensating Entity is internal, 26 Settlement Penalty.Penalty Amount where Penalty Absorbed by Firm Indicator is Y.",
    ("Key Risk Indicators", "Key Risk Indicator", "KRI Definition"):
        "Row rule: Derived copy (21) of Metric Definition.Metric Definition Text when Source Metric Definition is filled; mastered here otherwise.",
    ("Key Risk Indicators", "KRI Threshold", "KRI Threshold Direction"):
        "Row rule: Derived copy (21) of Metric Definition.Metric Direction when the KRI has a Source Metric Definition; mastered here otherwise, on the 21 list.",
    ("Third-Party Risk", "Third-Party Risk Assessment", "Assessed Third Party"):
        "Row rule: Derived copy (40) of the supplier of the Assessed Supplier Engagement; mastered here only for onboarding assessments of a prospective supplier with no engagement yet.",
}
