"""Enrichment for Data Domain 38 - Corporate Compliance & Regulatory Affairs (contract v0.4): grain, ownership flags, summary.

Wealth-manager adaptation (W4, CW-162, CW-163, CW-168, CW-938).
"""

BO, AG = "Business Object", "Attribute Group"

REG, RCH, EXM, POL = "Registrations & Firm Filings", "Regulatory Obligations & Change", "Examinations & Inquiries", "Policies, Attestations & Program Reviews"
COE, PAY, CNF, AML, MKT = "Code of Ethics & Personal Trading", "Political Contributions", "Conflicts & Outside Activities", "AML & Sanctions Program", "Market Conduct & Information Barriers"

GRAIN = {
    # Registrations & Firm Filings
    (REG, "Entity Authorization"): ("entity authorization (AUTH-): legal entity x regulator x authorization type x authorization jurisdiction (one row per state for state registrations and notice filings)", BO, ""),
    (REG, "Firm Regulatory Filing"): ("firm filing submission (FILNG-): filer entity x form type x period x submission sequence", BO, ""),
    (REG, "Form CRS Filing Detail"): ("firm regulatory filing of type Form CRS", AG, "Firm Regulatory Filing"),
    (REG, "Ownership Disclosure Determination"): ("issuer (security class) x disclosure regime x aggregation entity x determination date", BO, ""),
    # Regulatory Obligations & Change
    (RCH, "Regulatory Obligation"): ("regulatory obligation (OBL-)", BO, ""),
    (RCH, "Regulatory Change Item"): ("regulatory change item (REGCH-)", BO, ""),
    (RCH, "Regulatory Change Impact"): ("change item x impacted scope (legal entity, business line or Data Domain)", AG, "Regulatory Change Item"),
    # Examinations & Inquiries
    (EXM, "Regulatory Examination"): ("examination, sweep or inquiry (EXAM-)", BO, ""),
    (EXM, "Regulator Request Item"): ("examination x request sequence", AG, "Regulatory Examination"),
    (EXM, "Examination Finding"): ("examination x finding sequence", AG, "Regulatory Examination"),
    # Policies, Attestations & Program Reviews
    (POL, "Policy"): ("firm policy (POLCY-)", BO, ""),
    (POL, "Policy Version"): ("policy x version number", AG, "Policy"),
    (POL, "Attestation"): ("attester x attestation type x attestation period x attested policy version (or attestation campaign where no version is attested)", BO, ""),
    (POL, "Compliance Program Review"): ("reviewed entity (or fund complex) x program review type x review period", BO, ""),
    (POL, "Adviser Custody Profile"): ("adviser entity (LEN-) x profile effective from (Rule 206(4)-2 custody status)", BO, ""),
    (POL, "Custody Surprise Examination"): ("adviser entity (LEN-) x surprise examination date", BO, ""),
    # Code of Ethics & Personal Trading
    (COE, "Conduct Population Designation"): ("employee x designation type x designating entity x effective period", BO, ""),
    (COE, "Personal Trading Account"): ("personal trading account (firm account key): employee x reportable account at a broker", BO, ""),
    (COE, "Personal Securities Report"): ("access person x report type (initial, annual holdings or quarterly transaction) x as-of date", BO, ""),
    (COE, "Reported Personal Holding"): ("holdings report x account x security line", AG, "Personal Securities Report"),
    (COE, "Personal Transaction"): ("personal trading account x broker transaction reference", BO, ""),
    (COE, "Pre-Clearance Request"): ("employee x request timestamp", BO, ""),
    (COE, "Code of Ethics Violation"): ("employee x violation detected date x violation sequence", BO, ""),
    # Political Contributions
    (PAY, "Political Contribution"): ("political contribution (Political Contribution ID): contributor (covered associate or firm) x recipient x contribution date", BO, ""),
    (PAY, "Pay-to-Play Review"): ("political contribution (pay-to-play review)", AG, "Political Contribution"),
    # Conflicts & Outside Activities
    (CNF, "Conflict of Interest"): ("firm conflict register entry (CONFL-)", BO, ""),
    (CNF, "Conflict Mitigation"): ("conflict x mitigation sequence (key CONFL-<n> / M<nn>, read by 08 Incentive Conflict Review)", AG, "Conflict of Interest"),
    (CNF, "Outside Business Activity"): ("employee x outside activity or Rule 3240 / 3241 declaration x effective period", BO, ""),
    # AML & Sanctions Program
    (AML, "AML Program Assessment"): ("assessed legal entity or fund x assessment year", BO, ""),
    (AML, "AML Case"): ("AML case (restricted firm case number, no prefix)", BO, ""),
    (AML, "AML and Sanctions Report"): ("AML or sanctions report (AML Report Key, restricted firm key without a prefix); within a case, case x report sequence", BO, ""),
    # Market Conduct & Information Barriers
    (MKT, "Firm Restricted List"): ("restricted, watch or insider (wall-crossing) list", BO, ""),
    (MKT, "Restricted List Entry"): ("restricted list entry (RLIST-): list x issuer x added timestamp", BO, ""),
    (MKT, "MNPI Escalation"): ("MNPI escalation (MNPI-)", BO, ""),
    (MKT, "Insider List Entry"): ("insider list x section (MNPI escalation, or standing access) x person x access obtained timestamp", BO, ""),
    (MKT, "Trade Surveillance Alert"): ("trade surveillance alert (TRSV-)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Row rule: on insider entries sourced from a 23 issuer meeting, a copy of 23 Issuer Meeting Participant.Wall-Crossing
    # Timestamp; mastered here for engagement and other sources.
    (MKT, "Insider List Entry", "Access Obtained Timestamp"): "23",
    # Row rule: where an entity board approved the version, a copy of the 39 Corporate Resolution date (39 Subject Link holds the link).
    (POL, "Policy Version", "Version Approval Date"): "39",
}

# Sibling references carry the domain number in the type (48 Client Order and Client Execution, 50 Money Movement Monitoring
# Alert); the resolver needs no correction.
OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    "masters": (
        "Masters the firm-level compliance programs of the wealth manager's regulated entities (adviser, broker-dealer, funds, "
        "transfer agent and trust company): entity authorizations, memberships and state notice filings, firm regulatory filings "
        "with Form CRS filing detail and ownership disclosure determinations, the regulatory obligations register, regulatory "
        "change items and impacts, regulatory examinations with request items and findings, the policy library and policy "
        "versions, attestations and compliance program reviews, the adviser custody profile and custody surprise examinations "
        "under Rule 206(4)-2, conduct population designations, personal trading accounts, holdings reports, personal transactions, "
        "pre-clearance requests and code of ethics violations, political contributions and pay-to-play reviews, the firm conflicts "
        "register, conflict mitigations and outside business activities, AML program assessments, AML cases and SAR, OFAC and "
        "314(a) reports, restricted, watch and insider lists and their entries, MNPI escalations, and market-abuse trade "
        "surveillance alerts."
    ),
    "references": (
        "References internal legal entities from 09; parties (issuers, brokers, accountants, political recipients, AML subjects) "
        "and KYC profiles from 02; accounts from 15; employees and training requirements from 20; funds from 01; instruments from "
        "17; issuer meetings from 23; portfolio orders and executions from 25; client orders and executions from 48; employee accounts at the firm's broker-dealer from 15; "
        "engagements from 34; regulatory horizon "
        "items from 11; communications surveillance alerts from 08; controls from 37; officer appointments from 39; and supplier "
        "onboarding cases from 40. Links to 39 legal matters and resolutions, 37 risk issues, 41 projects and information "
        "security programs, 21 retention rules, 29, 50 and 08 escalations to AML cases, 47 fee deduction authorizations and 15 and 13 Form CRS deliveries are held once "
        "on their side."
    ),
}

# Row Ownership Rule (CD-289): where one attribute holds rows mastered here and rows copied from another Data Domain.
_INHOUSE = ("Row rule (CW-007): on in-house rows (the Personal Trading Account has a Firm Brokerage Account, Personal Trading Data "
            "Source 'Firm Books and Records'), a Derived copy of {src}; mastered here, as reported, on outside-broker (Rule 3210 duplicate "
            "statement or broker feed) and self-reported rows.")
ROW_OWNERSHIP = {
    (COE, "Reported Personal Holding", "Held Security"): _INHOUSE.format(src="the 49 Client Holding instrument"),
    (COE, "Reported Personal Holding", "Held Quantity"): _INHOUSE.format(src="49 Client Holding quantity at the report as-of date"),
    **{(COE, "Personal Transaction", a): _INHOUSE.format(src="the 48 Client Execution named by Broker Transaction Reference")
       for a in ("Personal Trade Date", "Traded Security", "Personal Trade Side", "Personal Trade Quantity", "Personal Trade Price")},
    (POL, "Policy Version", "Version Approval Date"):
        "Row rule: where an entity board approved the version, a Derived copy (39) of the Corporate Resolution date (39 Corporate Resolution Subject Link holds the approval link); mastered here for committee and officer approvals.",
    (MKT, "Insider List Entry", "Access Obtained Timestamp"):
        "Row rule: on rows sourced from a 23 issuer meeting, a Derived copy of 23 Issuer Meeting Participant.Wall-Crossing Timestamp; mastered here otherwise.",
}
