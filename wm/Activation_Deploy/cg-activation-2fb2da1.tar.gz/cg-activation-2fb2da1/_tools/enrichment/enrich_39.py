"""Enrichment for Data Domain 39 - Legal & Corporate Governance (contract v0.3): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Contract Repository
    ("Contract Repository", "Contract"): ("contract: one executed legal instrument (CTRCT-)", BO, ""),
    ("Contract Repository", "Typed Contract Link"): ("contract (the typed record a business domain masters for it)", AG, "Contract"),
    ("Contract Repository", "Contract Party"): ("contract x party x contract party role x effective period", BO, ""),
    ("Contract Repository", "Contract Signatory"): ("contract x signatory", BO, ""),
    ("Contract Repository", "Contract Document Version"): ("contract x document version number x document sequence (main agreement, exhibit, counterpart)", BO, ""),
    ("Contract Repository", "Contract Key Date"): ("contract x key date type x key date sequence", BO, ""),
    ("Contract Repository", "Contract Clause Position"): ("contract x clause type", BO, ""),
    ("Contract Repository", "Legal Service Request"): ("legal service request (year x sequence)", BO, ""),
    # Legal Matters & Litigation
    ("Legal Matters & Litigation", "Legal Matter"): ("legal matter (LMAT-)", BO, ""),
    ("Legal Matters & Litigation", "Matter Party"): ("legal matter x party x matter party role", BO, ""),
    ("Legal Matters & Litigation", "Matter Event"): ("legal matter x event sequence", BO, ""),
    ("Legal Matters & Litigation", "Matter Financial Assessment"): ("legal matter x reporting entity x assessment date", BO, ""),
    ("Legal Matters & Litigation", "Outside Counsel Engagement"): ("engagement letter (CTRCT-) x legal matter (empty for general advisory)", BO, ""),
    ("Legal Matters & Litigation", "Outside Counsel Invoice Review"): ("outside counsel engagement x counsel invoice number", BO, ""),
    # Legal Holds & Preservation
    ("Legal Holds & Preservation", "Legal Hold"): ("legal hold (LHOLD-)", BO, ""),
    ("Legal Holds & Preservation", "Legal Hold Custodian"): ("legal hold x custodian employee", BO, ""),
    ("Legal Holds & Preservation", "Legal Hold Scope"): ("legal hold x hold scope type x data source x date range", BO, ""),
    # Corporate Entity Governance
    ("Corporate Entity Governance", "Corporate Governing Body"): ("corporate governing body or committee of an internal legal entity (CGOV-)", BO, ""),
    ("Corporate Entity Governance", "Corporate Body Membership"): ("corporate governing body x member x corporate member role x membership effective period", BO, ""),
    ("Corporate Entity Governance", "Corporate Officer Appointment"): ("internal legal entity x corporate officer role x officer x appointment effective period", BO, ""),
    ("Corporate Entity Governance", "Corporate Board Meeting"): ("corporate governing body x meeting date x sequence, including written consents", BO, ""),
    ("Corporate Entity Governance", "Corporate Resolution"): ("corporate resolution (CGRES-)", BO, ""),
    ("Corporate Entity Governance", "Corporate Resolution Subject Link"): ("corporate resolution x approved subject", BO, ""),
    ("Corporate Entity Governance", "Entity Statutory Filing"): ("internal legal entity x statutory filing type x filing period end", BO, ""),
    # Signing Authority
    ("Signing Authority", "Power of Attorney"): ("power of attorney (POWER-)", BO, ""),
    ("Signing Authority", "Signing Authority Grant"): ("employee x authority type x internal legal entity x grant effective period", BO, ""),
    # Intellectual Property
    ("Intellectual Property", "Trademark Registration"): ("mark x jurisdiction x IP office (TMARK-)", BO, ""),
    ("Intellectual Property", "Trademark Docket Deadline"): ("trademark registration x docket deadline type x due date", BO, ""),
    ("Intellectual Property", "Trademark License Grant"): ("trademark registration x licensee x license effective period", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
# The six Contract attributes follow the CD-257 row rule stated in each note (program lead ruling 4): owner = domain of the
# typed link; mastered in 39 on untyped rows and rows typed only by a 40 Supplier Contract Profile. "05" is a placeholder
# owner because the contract allows one owner per attribute; the note is the authority until the catalog has a per-row
# owner mechanism (plan §4 item 9).
DERIVED = {
    ("Contract Repository", "Contract", "Contract Status"): "05",
    ("Contract Repository", "Contract", "Contract Effective Date"): "05",
    ("Contract Repository", "Contract", "Contract Expiry Date"): "05",
    ("Contract Repository", "Contract", "Governing Law"): "05",
    ("Contract Repository", "Contract Party", "Contract Party Role"): "05",
    ("Contract Repository", "Contract Key Date", "Key Date Value"): "05",
    # 19 Payable Invoice gross amount of the booked invoice.
    ("Legal Matters & Litigation", "Outside Counsel Invoice Review", "Billed Fees Amount"): "19",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the legal record of the US wealth manager and its group companies: the enterprise contract record (CTRCT-) for every "
        "executed instrument with its typed link, parties, signatories, document versions, key dates and clause positions, and "
        "legal service requests; legal matters (LMAT-) including regulatory enforcement, with their parties, events, ASC 450 / "
        "IAS 37 assessments, outside counsel engagements and invoice reviews; legal holds (LHOLD-), custodians and scope; "
        "corporate governing bodies (CGOV-) of internal entities other than fund, fund-management and general partner boards, memberships, officer appointments, "
        "meetings, corporate resolutions (CGRES-) and their subject links (the only record of what a corporate body approved), and entity statutory filings; powers of attorney "
        "(POWER-) and signing authority grants; trademark registrations (TMARK-), docket deadlines and license grants. US only: UK "
        "Companies Act and PSC filings, Luxembourg registers, SM&CR roles, ICARA approvals and GDPR processor terms left under CW-939."
    ),
    "references": (
        "References products and mandates from 01; parties, contact points and counterparties from 02; distribution "
        "agreements and agreement documents from 05; retention rules from 08; internal legal entities and org units from 09; "
        "intercompany agreements from 10; data license agreements from 14; recordkeeping service arrangements from 16; payable "
        "invoices and journal entries from 19; employees from 20; data assets from 21; trading agreements from 26; securities "
        "lending agreements from 28; fund advisory "
        "agreements from 35; risk appetite statements and audit plans from 37; regulatory examinations, policy versions and firm "
        "filings from 38; applications from 41; corporate publications from 42; debt "
        "facilities, bank accounts, insurance policies, capital transactions from 43; and "
        "brands from 04 (moving to 42)."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Contract Repository", "Contract", "Contract Status"):
        "Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a 40 Supplier Contract Profile.",
    ("Contract Repository", "Contract", "Contract Effective Date"):
        "Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a 40 Supplier Contract Profile.",
    ("Contract Repository", "Contract", "Contract Expiry Date"):
        "Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a 40 Supplier Contract Profile.",
    ("Contract Repository", "Contract", "Governing Law"):
        "Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a 40 Supplier Contract Profile.",
    ("Contract Repository", "Contract Party", "Contract Party Role"):
        "Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a 40 Supplier Contract Profile.",
    ("Contract Repository", "Contract Party", "External Contract Party"):
        "Row rule (CD-257): on typed rows it must agree with the typed record's counterparty, which the typed owner masters; mastered here on untyped rows.",
    ("Contract Repository", "Contract Party", "Internal Contract Party"):
        "Row rule (CD-257): on typed rows it must agree with the typed record, which the typed owner masters; mastered here on untyped rows.",
    ("Contract Repository", "Contract Key Date", "Key Date Value"):
        "Row rule (CD-257): owner = domain of the typed link (01, 05, 10, 14, 16, 26, 28, 35, 43 or 44, as named by Typed Record Type; for 44 leases the link is 44 Lease.Lease Contract); mastered in 39 on untyped rows (custody, administration, TA service, NDA, engagement letter, bank mandate, constitutional documents) and on rows typed only by a 40 Supplier Contract Profile.",
}
