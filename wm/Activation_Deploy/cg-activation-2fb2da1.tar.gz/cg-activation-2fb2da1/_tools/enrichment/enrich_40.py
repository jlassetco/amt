"""Enrichment for Data Domain 40 - Procurement & Vendor Management (contract v0.3): grain, ownership flags, summary.
Wealth model (direct), scope US: the DORA register of information and the EU/UK outsourcing notifications removed (CW-940)."""

BO, AG = "Business Object", "Attribute Group"
SUP, SRC, PUR, CON, PRF, OUT = ("Supplier Management", "Sourcing", "Purchasing", "Supplier Contracts",
                                "Supplier Performance & Spend", "Criticality & Outsourcing")

GRAIN = {
    # Supplier Management
    (SUP, "Supplier Profile"): ("party (PTY-) in the supplier role", BO, ""),
    (SUP, "Supplier Remittance Detail"): ("supplier x remittance account (remittance sequence) x effective period", AG, "Supplier Profile"),
    (SUP, "Supplier Onboarding Case"): ("supplier x onboarding sequence", BO, ""),
    (SUP, "Supplier Engagement"): ("supplier engagement (VENG-)", BO, ""),
    (SUP, "Supplier Category Assignment"): ("engagement x procurement category x effective period", BO, ""),
    # Sourcing
    (SRC, "Sourcing Event"): ("sourcing event issued by the firm (SRCG-)", BO, ""),
    (SRC, "Sourcing Award"): ("sourcing event x awarded supplier", BO, ""),
    (SRC, "Sourcing Invitation"): ("sourcing event x invited supplier", BO, ""),
    # Purchasing
    (PUR, "Purchase Requisition"): ("purchase requisition (PREQ-)", BO, ""),
    (PUR, "Purchase Order"): ("purchase order (PURCH-)", BO, ""),
    (PUR, "Purchase Order Line"): ("purchase order x line number", BO, ""),
    (PUR, "Goods and Service Receipt"): ("purchase order line x receipt sequence", BO, ""),
    (PUR, "Invoice Match Result"): ("19 payable invoice line x purchase order line (latest match run)", BO, ""),
    # Supplier Contracts
    (CON, "Supplier Contract Profile"): ("39 contract (CTRCT-) of a supplier engagement", BO, ""),
    (CON, "Contracted Service Level"): ("contract x service level metric x effective period", BO, ""),
    # Supplier Performance & Spend
    (PRF, "Supplier Performance Review"): ("engagement x review period", BO, ""),
    (PRF, "Service Level Measurement Result"): ("contracted service level x measurement period", BO, ""),
    (PRF, "Supplier Spend Summary"): ("supplier x buying legal entity x fiscal period", BO, ""),
    # Criticality & Outsourcing
    (OUT, "Supplier Risk Tiering"): ("engagement x tier effective period", BO, ""),
    (OUT, "Outsourcing Arrangement"): ("outsourcing arrangement (OUTS-)", BO, ""),
    (OUT, "Exit Plan"): ("outsourcing arrangement (exit plan)", AG, "Outsourcing Arrangement"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    (PUR, "Invoice Match Result", "Matched Invoice Line Number"): "19",
    (PUR, "Invoice Match Result", "Invoice Status at Match"): "19",
    (CON, "Supplier Contract Profile", "Contract Status"): "39",
    (PRF, "Supplier Spend Summary", "Invoiced Amount"): "19",
    (PRF, "Supplier Spend Summary", "Paid Amount"): "19",
    (OUT, "Outsourcing Arrangement", "Critical or Important Outsourcing Indicator"): "37",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the procurement and third-party record of every group entity of the wealth manager (investment adviser, "
        "self-clearing broker-dealer, fund complex, optional trust company): supplier profiles of 02 parties (ERP supplier "
        "number, dated supplier status, default terms, diversity certifications, tax form on file), supplier remittance details, "
        "onboarding cases, supplier engagements and category assignments; sourcing events the firm issues, invitations, bids and "
        "awards per supplier; purchase requisitions, purchase orders and lines, goods and service receipts and invoice match results; supplier "
        "contract profiles typed on 39 contracts and contracted service levels; supplier performance reviews, service level "
        "results and spend summaries; and the inherent criticality tier and the outsourcing register with exit plans that evidence "
        "the supervision of outsourced broker-dealer functions (FINRA Rule 3110, Regulatory Notice 21-29), fund service provider "
        "oversight (SEC Rule 38a-1), service-provider oversight under Regulation S-P and the trust company's third-party risk management."
    ),
    "references": (
        "References parties from 02 Client & Household (the party core for every external party); legal entities, org units and fiscal periods from 09; "
        "payable invoices, supplier payments, GL accounts and cost centers from 19 Finance & Accounting; employees from 20 Human "
        "Capital; data assets from 21; data vendors from 14, servicing provider engagements from 13, custody provider profiles "
        "from 28 and fund service provider roles from 01 as specializations of the engagement; recordkeeping service arrangements from 16; critical or important functions from 37 Enterprise & Operational Risk; AML "
        "cases and conflicts of interest from 38 Corporate Compliance & Regulatory Affairs; and contracts from 39 Legal & Corporate "
        "Governance."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Supplier Performance & Spend", "Supplier Spend Summary", "Invoiced Amount"):
        "Derived copy (19): sum of Payable Invoice Line.Line Net Amount for the supplier and entity, signed by Payable Invoice.Payable Document Type (credit notes negative), assigned to the period by Invoice Date and translated at the 22 FX rate of that date (row rule: all invoices, with or without a purchase order).",
}
