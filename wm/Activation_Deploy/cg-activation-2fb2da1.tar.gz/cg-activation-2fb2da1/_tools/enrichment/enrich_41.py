"""Enrichment for Data Domain 41 - Technology & Information Security (contract v0.3): grain, ownership flags, summary.
Wealth model (direct), scope US: DORA, EU AI Act, UK and GDPR content removed; Regulation S-P and S-ID programs added (CW-941)."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Application Portfolio
    ("Application Portfolio", "Application"): ("application (APPL-)", BO, ""),
    ("Application Portfolio", "Application Ownership Assignment"): ("application x ownership role x employee x effective period", BO, ""),
    ("Application Portfolio", "Application Capability Mapping"): ("application x business capability x effective period", BO, ""),
    ("Application Portfolio", "Application Lifecycle Assessment"): ("application x assessment date", BO, ""),
    ("Application Portfolio", "Application Interface"): ("interface (source x target application or external endpoint x interface code)", BO, ""),
    ("Application Portfolio", "Application Recovery Profile"): ("application (recovery profile)", AG, "Application"),
    ("Application Portfolio", "AI System Profile"): ("application that is an AI system (deployment facts)", AG, "Application"),
    ("Application Portfolio", "AI System Use Case Link"): ("application x AI use case (AIU-) x effective period", BO, ""),
    ("Application Portfolio", "AI System Model Deployment"): ("application (AI system) x model (37 MODEL-) x effective period", BO, ""),
    # Infrastructure & IT Assets
    ("Infrastructure & IT Assets", "Configuration Item"): ("configuration item (CFGI-)", BO, ""),
    ("Infrastructure & IT Assets", "Configuration Item Relationship"): ("parent configuration item x child configuration item x relationship type x effective period", BO, ""),
    ("Infrastructure & IT Assets", "IT Asset Assignment"): ("configuration item (end-user device) x assignee x assignment period", BO, ""),
    ("Infrastructure & IT Assets", "Software License Position"): ("application (software product) x licensing metric x measurement date", BO, ""),
    # Identity & Access
    ("Identity & Access", "Digital Identity"): ("directory account (digital identity)", BO, ""),
    ("Identity & Access", "Application Access Role"): ("application x access role code", BO, ""),
    ("Identity & Access", "System Access Grant"): ("digital identity x application access role x effective period (ACSG-)", BO, ""),
    ("Identity & Access", "Access Review Campaign"): ("access review campaign", BO, ""),
    ("Identity & Access", "Access Review Decision"): ("access review campaign x system access grant", BO, ""),
    # IT Service & Incident Management
    ("IT Service & Incident Management", "IT Service"): ("IT service", BO, ""),
    ("IT Service & Incident Management", "IT Incident"): ("IT incident (ITINC-)", BO, ""),
    ("IT Service & Incident Management", "Security Incident Detail"): ("IT incident of class Security Event (security detail)", AG, "IT Incident"),
    ("IT Service & Incident Management", "Information Security Program"): ("information security program (program code)", BO, ""),
    ("IT Service & Incident Management", "Problem Record"): ("problem", BO, ""),
    # Change & Release
    ("Change & Release", "Change Request"): ("change request (CHRQ-)", BO, ""),
    ("Change & Release", "Change Approval"): ("change request x approval step", BO, ""),
    ("Change & Release", "Release"): ("application x release (RLSE-)", BO, ""),
    ("Change & Release", "Release Deployment"): ("release x environment x deployment timestamp", BO, ""),
    # Change & Project Portfolio
    ("Change & Project Portfolio", "Change Program"): ("change program", BO, ""),
    ("Change & Project Portfolio", "Project"): ("project (PRJT-)", BO, ""),
    ("Change & Project Portfolio", "Project Milestone"): ("project x milestone", BO, ""),
    ("Change & Project Portfolio", "Project Status Report"): ("project x status reporting date", BO, ""),
    ("Change & Project Portfolio", "Project Scope Link"): ("project x delivered object x effective period", BO, ""),
    # Security Testing & Vulnerabilities
    ("Security Testing & Vulnerabilities", "Security & Resilience Test"): ("security or resilience test", BO, ""),
    ("Security Testing & Vulnerabilities", "Vulnerability Finding"): ("vulnerability finding (VULN-): vulnerability x configuration item or application x detection", BO, ""),
}

# No attribute copies a value mastered in another Data Domain: every cross-domain fact is a typed reference.
DERIVED = {}

OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    "masters": (
        "Masters the enterprise application inventory (APPL-) with its ownership assignments, business capability mappings, dated "
        "lifecycle assessments, interfaces, recovery profiles, AI system profiles, links to AI use cases and dated model deployments; configuration items "
        "(CFGI-) and their relationships, IT asset assignments and software license positions; digital identities, application "
        "access roles, system access grants (ACSG-) and access reviews; IT services; the information security programs of the wealth "
        "manager's broker-dealer, adviser, funds and trust company (Regulation S-P safeguards and incident response, Regulation S-ID "
        "identity theft red flags, the NIST CSF program); IT incidents (ITINC-) with the security incident detail, the Regulation S-P "
        "customer notification determination and the identity theft red flag, and problem records; change requests (CHRQ-), "
        "their approval steps, releases (RLSE-) and deployments; change programs, projects (PRJT-), milestones, status reports and the "
        "project scope link; and security and resilience tests and vulnerability findings (VULN-)."
    ),
    "references": (
        "References employees and lifecycle events from 20 Human Capital; vendors, providers, testers and external client-portal users from 02 "
        "Client & Household; org units, office locations, legal entities and calendars from 09; licensed-data entitlements from 14; "
        "data feeds from 06; financial plan versions from 19; AI use cases, data products and data quality issues from 21; product "
        "change initiatives from 36; model inventory entries from 37; policies and regulatory change items from 38; "
        "and contracts from 39. 37 Operational Incident, Risk Issue, Resilience Test and Resilience Resource Mapping, "
        "21 System of Record Designation and every system reference in 01-36 reference the records mastered here."
    ),
}
