"""Enrichment for Data Domain 42 - Corporate Communications & Public Affairs (contract v0.3): grain, ownership flags, summary.
Wealth model (direct), scope US: EU Transparency Register, UK lobbying and UK publication duties removed (CW-942)."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Brand Governance
    ("Brand Governance", "Brand"): ("brand (BRD-)", BO, ""),
    ("Brand Governance", "Brand Standard Version"): ("brand x guideline version", BO, ""),
    ("Brand Governance", "Brand Use Authorization"): ("brand x licensee (legal entity or party) x effective period", BO, ""),
    ("Brand Governance", "Reputation Measurement"): ("brand x reputation measure x provider x stakeholder group x measurement period start x period end", BO, ""),
    # Media Relations
    ("Media Relations", "Media Contact Profile"): ("media party (journalist or outlet, PTY-) x effective period", BO, ""),
    ("Media Relations", "Media Inquiry"): ("media inquiry (MEDQ-)", BO, ""),
    ("Media Relations", "Press Release"): ("press release (NEWS-)", BO, ""),
    ("Media Relations", "Media Coverage Item"): ("media coverage item (MCOV-)", BO, ""),
    ("Media Relations", "Spokesperson Authorization"): ("employee x authorization effective period", BO, ""),
    # Corporate Publications
    ("Corporate Publications", "Corporate Publication"): ("corporate publication version (Corporate Publication ID = type x publishing entity x period end x version)", BO, ""),
    ("Corporate Publications", "Publication Source Link"): ("corporate publication x source record", BO, ""),
    # Internal Communications
    ("Internal Communications", "Internal Communication"): ("internal communication", BO, ""),
    ("Internal Communications", "Internal Communication Audience"): ("internal communication x audience segment", BO, ""),
    ("Internal Communications", "Internal Communication Engagement"): ("internal communication x channel x measurement date", BO, ""),
    # Issues & Crisis Communications
    ("Issues & Crisis Communications", "Communications Issue"): ("communications issue (CRIS-)", BO, ""),
    ("Issues & Crisis Communications", "Issue Statement"): ("communications issue x statement type x audience x statement version", BO, ""),
    ("Issues & Crisis Communications", "Crisis Communication Plan"): ("crisis communication plan (Crisis Plan Code) x version", BO, ""),
    # Government Relations & Public Policy
    ("Government Relations & Public Policy", "Public Policy Position"): ("public policy position (PUBP-) x version", BO, ""),
    ("Government Relations & Public Policy", "Consultation Response"): ("consultation x responding entity", BO, ""),
    ("Government Relations & Public Policy", "Government Official Contact"): ("government official contact event (Official Contact ID)", BO, ""),
    ("Government Relations & Public Policy", "Trade Association Membership"): ("trade association x member entity x effective period", BO, ""),
    # Lobbying Disclosure
    ("Lobbying Disclosure", "Lobbying Registration"): ("registrant or client entity x lobbying regime x registration", BO, ""),
    ("Lobbying Disclosure", "Registered Lobbyist"): ("employee x lobbying registration x effective period", BO, ""),
    ("Lobbying Disclosure", "Lobbying Disclosure Report"): ("lobbying registration x filer (registrant, or lobbyist on LD-203 lobbyist rows) x report type x period x amendment sequence (LOBR-)", BO, ""),
    ("Lobbying Disclosure", "Lobbying Report Issue Line"): ("lobbying disclosure report x general issue area", BO, ""),
    # Corporate Events & Recognition
    ("Corporate Events & Recognition", "Corporate Event"): ("corporate event (Corporate Event ID)", BO, ""),
    ("Corporate Events & Recognition", "Corporate Award Entry"): ("award program x category x year x entrant", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Completion date of the media training learning item, copied from the 20 Learning Completion.
    ("Media Relations", "Spokesperson Authorization", "Media Training Completion Date"): "20",
    # Board approval date read through the 39 Corporate Resolution Subject Link (39 holds the only approval link).
    ("Corporate Publications", "Corporate Publication", "Publication Board Approval Date"): "39",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the corporate message of the wealth manager as a company: the brand register (moved from 04 under CD-271), brand standard versions, "
        "brand use authorizations and reputation measurements; media contact profiles, media inquiries, press releases, media "
        "coverage items and spokesperson authorizations; corporate publications (the broker-dealer statement of financial condition, "
        "the corporate responsibility report, the annual review) and their source links; internal communications, "
        "audiences and aggregate engagement; communications issues, issue statements and crisis communication plans; public "
        "policy positions, consultation responses, government official contacts and trade association memberships; lobbying "
        "registrations under the federal Lobbying Disclosure Act and state registers, registered lobbyists, lobbying disclosure "
        "reports (LD-2, LD-203, state reports) and their issue lines; corporate events and corporate "
        "award entries."
    ),
    "references": (
        "References journalists, outlets, officials, agencies, trade associations, award organizers and vendors from 02 Client & "
        "Household (the party core for every external party); products from 01 Investment Product & Service Offering; digital properties and social listening mentions from 04 Marketing, Digital & Client Engagement; "
        "compliance reviews and gift and entertainment items from 08 Retail Conduct & Supervision; fund and manager award results from "
        "11 Market & Competitive Intelligence; shareholder communications from 13 Client Service & Communications; "
        "legal entities, org units and office locations from 09 Shared & Enterprise Reference Data; employees and job profiles from 20 Human "
        "Capital; human capital metric values from 20, net capital calculations from 43 and "
        "operational emission records from 44 as publication sources; product change initiatives from 36; operational "
        "incidents and business continuity plans from 37; policies and political contributions from 38; legal matters, "
        "contracts and board approval dates (through the Corporate Resolution Subject Link) from 39; IT incidents from 41; and health and safety and physical security incidents from 44."
    ),
}
