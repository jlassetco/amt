"""Wealth model (direct), scope US: ICARA, MIFIDPRU, UCITS and AIFMD own funds and IFRS removed; net capital additions (CW-943).
Enrichment for Data Domain 43 - Corporate Treasury & Capital (contract v0.3): grain, ownership flags, summary.

Every object is a Business Object. Folding rule (CD-278): if 43 folds into 19, these keys move unchanged with the family
names; only the domain number in the derived-copy and override values that point at 19 become "" (mastered here).
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Bank Accounts & Relationships
    ("Bank Accounts & Relationships", "Corporate Bank Account"): ("corporate bank account (BKAC-)", BO, ""),
    ("Bank Accounts & Relationships", "Bank Account Signatory"): ("corporate bank account x signatory (employee or party) x authority level x effective period", BO, ""),
    ("Bank Accounts & Relationships", "Cash Pool Membership"): ("participant bank account x header bank account x effective period", BO, ""),
    ("Bank Accounts & Relationships", "Bank Relationship Profile"): ("bank party x effective period", BO, ""),
    ("Bank Accounts & Relationships", "Bank Fee Statement"): ("corporate bank account x billing period", BO, ""),
    # Cash Management & Forecasting
    ("Cash Management & Forecasting", "Bank Statement"): ("corporate bank account x statement type (camt.052 intraday or camt.053 end-of-day) x statement date x statement sequence number", BO, ""),
    ("Cash Management & Forecasting", "Bank Statement Entry"): ("bank statement x entry sequence", BO, ""),
    ("Cash Management & Forecasting", "Cash Position"): ("corporate bank account x value date x position version x data basis", BO, ""),
    ("Cash Management & Forecasting", "Cash Forecast"): ("cash forecast version (name x as-of date x version)", BO, ""),
    ("Cash Management & Forecasting", "Cash Forecast Line"): ("cash forecast x legal entity x currency x cash flow category x value date bucket", BO, ""),
    ("Cash Management & Forecasting", "Short-Term Investment"): ("short-term investment placement", BO, ""),
    # Funding & Intercompany
    ("Funding & Intercompany", "Debt Facility"): ("corporate debt facility (DEBT-)", BO, ""),
    ("Funding & Intercompany", "Debt Facility Drawdown"): ("debt facility x drawdown reference", BO, ""),
    ("Funding & Intercompany", "Corporate Covenant Test"): ("debt facility x covenant metric x test date", BO, ""),
    ("Funding & Intercompany", "Intercompany Loan"): ("intercompany loan (ICLN-)", BO, ""),
    ("Funding & Intercompany", "Intra-Group Capital Transaction"): ("intra-group capital transaction", BO, ""),
    # Seed & Co-Investment Capital
    ("Seed & Co-Investment Capital", "Seed Capital Commitment"): ("seed or co-investment capital commitment (SDCAP-)", BO, ""),
    ("Seed & Co-Investment Capital", "Seed Capital Movement"): ("seed capital commitment x movement reference", BO, ""),
    ("Seed & Co-Investment Capital", "Seed Position Valuation"): ("seed capital commitment x valuation date", BO, ""),
    ("Seed & Co-Investment Capital", "Seed Product Holding"): ("seeded product x ownership measurement date", BO, ""),
    # Regulatory Capital & Liquidity
    ("Regulatory Capital & Liquidity", "Regulated Entity Capital Profile"): ("legal entity x capital regime x effective period", BO, ""),
    ("Regulatory Capital & Liquidity", "Capital Requirement Calculation"): ("legal entity x capital regime x as-of date x version (RCAP-)", BO, ""),
    ("Regulatory Capital & Liquidity", "Capital Requirement Component"): ("capital requirement calculation x component sequence", BO, ""),
    ("Regulatory Capital & Liquidity", "Capital Adequacy Notification"): ("legal entity x notification trigger x notification sent timestamp", BO, ""),
    # Corporate FX & Hedging
    ("Corporate FX & Hedging", "Corporate Exposure"): ("legal entity x exposure type x currency x rate index (rate rows) x seed commitment or debt facility (where linked) x exposure period", BO, ""),
    ("Corporate FX & Hedging", "Treasury Deal"): ("treasury deal (TDEAL-)", BO, ""),
    ("Corporate FX & Hedging", "Treasury Deal Valuation"): ("treasury deal x valuation date", BO, ""),
    ("Corporate FX & Hedging", "Hedge Relationship"): ("hedge relationship designation (HEDG-)", BO, ""),
    ("Corporate FX & Hedging", "Hedge Effectiveness Test"): ("hedge relationship x test date", BO, ""),
    # Insurance Program
    ("Insurance Program", "Corporate Insurance Policy"): ("corporate insurance policy x policy period (INPOL-)", BO, ""),
    ("Insurance Program", "Insurance Coverage Layer"): ("corporate insurance policy x layer number x carrier", BO, ""),
    ("Insurance Program", "Insurance Claim"): ("insurance claim (policy x claim sequence)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)". Row rules are in the attribute notes.
DERIVED = {
    # 22 Reference Rate Fixing 'Fixing Value' for the facility reference rate and fixing date.
    ("Funding & Intercompany", "Debt Facility Drawdown", "Reference Rate Fixing Value"): "22",
    # Fund rows: 06 Fund Shareholder Position 'Units Held' of the seed account and share class (CD-276).
    ("Seed & Co-Investment Capital", "Seed Position Valuation", "Seed Units Held"): "06",
    # Fund rows: 27 Share Class NAV 'NAV per Share'.
    ("Seed & Co-Investment Capital", "Seed Position Valuation", "Seed NAV per Share"): "27",
    # Row rule: on rows approved by a 39 corporate governing body, the date of the Corporate Resolution that names the
    # commitment through 39 Corporate Resolution Subject Link; mastered here for treasury or seed committee approvals.
    ("Seed & Co-Investment Capital", "Seed Capital Commitment", "Commitment Approval Date"): "39",
    # 27 Fund NAV 'Fund Net Assets Amount' on the measurement date.
    ("Seed & Co-Investment Capital", "Seed Product Holding", "Product Net Assets Used"): "27",
    # 22 FX Rate Observation 'Spot Rate' of the referenced observation.
    ("Corporate FX & Hedging", "Treasury Deal Valuation", "Valuation Spot Rate"): "22",
    # Alternative standard rows: aggregate debit items of the 49 customer Reserve Computation (RESRV-) named in Reserve Computation (CW-943).
    ("Regulatory Capital & Liquidity", "Capital Requirement Calculation", "Aggregate Debit Items Amount"): "49",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

SUMMARY = {
    "masters": (
        "Masters the wealth manager's own treasury and capital records: corporate bank accounts of every group entity with their "
        "signatories, cash pool memberships, bank relationship profiles and bank fee statements; bank statements and entries, "
        "cash positions, cash forecasts and short-term investments of corporate cash; corporate debt facilities, drawdowns and "
        "covenant tests, intercompany loans and intra-group capital transactions; seed capital commitments "
        "(the only master of firm seed status), their movements and valuations, and the group's ownership share of each seeded product; regulated entity capital profiles, capital "
        "requirement calculations (broker-dealer net capital under SEC Rule 15c3-1 with aggregate indebtedness or the alternative "
        "standard, excess net capital and the Rule 17a-11 early-warning level; the trust company's capital) and components, and "
        "capital adequacy notifications; corporate exposures, "
        "treasury deals and valuations, hedge relationships and effectiveness tests; and corporate insurance policies, coverage "
        "layers and claims."
    ),
    "references": (
        "References internal legal entities from 09 Shared & Enterprise Reference Data and entity authorizations from 38; "
        "banks, lenders, insurers, brokers and independent-director signatories from 02 Client & Household; GL accounts, "
        "journals, transfer pricing documentation, financial plan versions and regulatory returns from 19 Finance & "
        "Accounting; intercompany agreements from 10; products and share classes from 01; seed and money market fund "
        "accounts from 15; seed books from 18; shareholder positions from 06; fund orders and AP orders from 29; "
        "NAVs from 27; FX rate observations, reference rate fixings and "
        "curves from 22; trading agreements and OTC trades from 26 and executions from 25; product change initiatives from "
        "36; the fund fidelity bond from 35; employees from 20; the customer reserve computation from 49 (read for the alternative net capital standard, never computed here); and, from the Stage 4 siblings, operational loss events and "
        "risk appetite statements (37), legal matters (39) and IT incidents (41). Contracts and corporate resolutions (39) "
        "link to 43 records from the 39 side."
    ),
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Seed & Co-Investment Capital", "Seed Capital Commitment", "Commitment Approval Date"):
        "Row rule: where a 39 Corporate Resolution Subject Link names the commitment (approval by a corporate governing body), Derived copy (39) of that resolution's date; mastered here where a treasury or seed committee outside 39 approved it (SME question 3).",
}
