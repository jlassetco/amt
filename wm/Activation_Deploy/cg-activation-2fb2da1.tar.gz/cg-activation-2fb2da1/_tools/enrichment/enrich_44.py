"""Enrichment for Data Domain 44 - Workplace & Corporate Services (contract v0.3): grain, ownership flags, summary.
Wealth model (direct), scope US: RIDDOR, UK workplace regulations, IFRS 16, CSRD, UK SECR and EU/UK factor sources removed (CW-944)."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Real Estate & Sites
    ("Real Estate & Sites", "Site Profile"): ("09 site (SITE-) x profile effective period", BO, ""),
    ("Real Estate & Sites", "Building Space"): ("space (building, floor, zone, room or desk)", BO, ""),
    ("Real Estate & Sites", "Space Assignment"): ("space x org unit x assignment effective period", BO, ""),
    ("Real Estate & Sites", "Site Occupancy Measurement"): ("site or space x measurement date (aggregate)", BO, ""),
    # Leases
    ("Leases", "Lease"): ("lease (LEASE-)", BO, ""),
    ("Leases", "Leased Space"): ("lease x site or space x effective period", BO, ""),
    ("Leases", "Lease Payment Schedule Line"): ("lease x payment period x charge type", BO, ""),
    ("Leases", "Lease Option & Critical Date"): ("lease x option or critical event", BO, ""),
    ("Leases", "Lease Accounting Measurement"): ("lease x 19 ledger x measurement date; row ownership: every row produced by the 19 Controller (CD-279), moves to 19 unchanged if lease accounting runs in the ERP", AG, "Lease"),
    # Facilities & Workplace Services
    ("Facilities & Workplace Services", "Facility Asset"): ("facility asset (tag)", BO, ""),
    ("Facilities & Workplace Services", "Planned Maintenance Schedule"): ("facility asset x maintenance task", BO, ""),
    ("Facilities & Workplace Services", "Facility Work Order"): ("work order (FMWO-)", BO, ""),
    ("Facilities & Workplace Services", "Space Reservation"): ("space x reservation period x booker", BO, ""),
    # Physical Security
    ("Physical Security", "Access Badge"): ("badge (BADGE-)", BO, ""),
    ("Physical Security", "Physical Access Zone Grant"): ("badge x site x access zone x space (blank for site-wide zones) x effective period", BO, ""),
    ("Physical Security", "Visitor Registration"): ("visit", BO, ""),
    ("Physical Security", "Physical Security Incident"): ("physical security incident", BO, ""),
    # Health & Safety
    ("Health & Safety", "Health & Safety Incident"): ("health and safety incident (HSEI-)", BO, ""),
    ("Health & Safety", "Workplace Risk Assessment"): ("site, workstation or employee (by assessment type: employee on ergonomic workstation and workplace accommodation assessments) x assessment type x assessment date", BO, ""),
    ("Health & Safety", "Emergency Role Assignment"): ("employee x site x emergency role x effective period", BO, ""),
    # Travel & Expense
    ("Travel & Expense", "Expense Report"): ("expense report (EXPR-)", BO, ""),
    ("Travel & Expense", "Expense Line"): ("expense report x line number", BO, ""),
    ("Travel & Expense", "Corporate Card"): ("corporate card account (issuer card account ID or token)", BO, ""),
    ("Travel & Expense", "Card Transaction"): ("card account x issuer transaction reference", BO, ""),
    ("Travel & Expense", "Travel Booking"): ("trip (TRIP-)", BO, ""),
    ("Travel & Expense", "Expense Policy Limit"): ("expense type x location band x job level x effective period", BO, ""),
    # Operational Sustainability
    ("Operational Sustainability", "Utility Consumption Record"): ("site x meter x resource x consumption period", BO, ""),
    ("Operational Sustainability", "Operational Emission Record"): ("reporting entity x record level (Entity Total, or Site with the 09 site) x reporting year x GHG scope category x calculation method", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    # Row rule (CD-280, program lead): AP rows (02 party payee) copy 19 Supplier Payment.Outgoing Payment Status; Payroll rows
    # are a copy of 20 (Payroll Run.Pay Date of the run holding the payroll result). One owner per key: 19 is named.
    ("Travel & Expense", "Expense Report", "Reimbursement Status"): "19",
}

# The resolver reads every reference here correctly (own objects carry ', 44'; sibling objects carry their number).
OWNERSHIP_OVERRIDES = {}

SUMMARY = {
    "masters": "Masters the US wealth manager's workplace record as occupier and employer (offices, branch and advice centers): effective-dated site profiles keyed by the 09 site, building spaces, space assignments and aggregate occupancy; leases (LEASE-) with leased spaces, payment schedules, options and critical dates, and the ASC 842 lease accounting measurement produced by the 19 Controller (CD-279); facility assets, planned maintenance, work orders (FMWO-) and space reservations; access badges (BADGE-), physical access zone grants, visitor registrations and physical security incidents; health and safety incidents (HSEI-) with their OSHA recordkeeping status, workplace risk assessments and emergency role assignments; expense reports (EXPR-) and lines, corporate cards, card transactions, travel bookings (TRIP-) and expense policy limits; and the utility consumption and operational Scope 1-3 emissions of the firm's own operations.",
    "references": "References sites, legal entities, org units and units of measure (09), employees, lifecycle events, payroll results and learning completions (20), landlords, vendors, card issuers, agencies and known visitors (02 Client & Household), payable invoices, supplier payments, journals, ledgers and cost centers (19), gift and entertainment items (08), funds recharged (01), marketing events (04), sustainability indicator definitions (34), policies (38), contracts (39), purchase orders (40) and corporate events (42).",
}

# Row Ownership Rule (plan section 4 item 9, ratified at Step 5, CD-289): where one attribute holds rows mastered here and
# rows copied from (or owned by) another Data Domain, the rule says which rows are which. The Ownership flag stays as declared.
ROW_OWNERSHIP = {
    ("Travel & Expense", "Expense Report", "Reimbursement Status"):
        "Row rule: Accounts Payable rows copy 19 Supplier Payment.Outgoing Payment Status; Payroll rows are set to 'Paid / Settled' from 20 Payroll Run.Pay Date of the run holding the Reimbursement Payroll Result; blank on Not Reimbursable rows.",
}
