"""Enrichment for Data Domain 45 - Financial Planning & Advice (wealth-manager model, W2; contract v0.4): grain, ownership flags, summary.

New domain (CW-008). Content module: content_45_financial_planning_and_advice.py.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Advice Engagements
    ("Advice Engagements", "Advice Engagement"): ("client or Client Household x advice engagement (ADENG-)", BO, ""),
    ("Advice Engagements", "Engagement Participant"): ("advice engagement x party x participant role x effective period", BO, ""),
    ("Advice Engagements", "Advice Review"): ("advice engagement x review (AVREV-)", BO, ""),
    # Goals
    ("Goals", "Financial Goal"): ("financial goal (FGOAL-; owned by a client or Client Household)", BO, ""),
    ("Goals", "Goal Funding Link"): ("financial goal x funding source (15 account or aggregated account) x effective period", BO, ""),
    ("Goals", "Retirement Income Goal Detail"): ("financial goal (retirement income)", AG, "Financial Goal"),
    ("Goals", "Education Goal Detail"): ("financial goal (education)", AG, "Financial Goal"),
    ("Goals", "Goal Progress Snapshot"): ("financial goal x snapshot as-of date", BO, ""),
    # Client Financial Plans
    ("Client Financial Plans", "Client Financial Plan"): ("client financial plan (FPLAN-)", BO, ""),
    ("Client Financial Plans", "Client Financial Plan Version"): ("client financial plan x version (FPLAN-<n>-<vv>)", BO, ""),
    ("Client Financial Plans", "Client Planning Assumptions"): ("client financial plan version (client tax and longevity assumptions)", AG, "Client Financial Plan Version"),
    ("Client Financial Plans", "Plan Goal Inclusion"): ("client financial plan version x financial goal", BO, ""),
    # Planning Inputs & Assumptions
    ("Planning Inputs & Assumptions", "Planning Cash Flow Input"): ("client financial plan version x cash-flow item number", BO, ""),
    ("Planning Inputs & Assumptions", "Planning Balance Sheet Item"): ("client financial plan version x balance-sheet item number", BO, ""),
    ("Planning Inputs & Assumptions", "Planning Assumption Set"): ("firm planning assumption set x version (keyed by Assumption Set Code)", BO, ""),
    ("Planning Inputs & Assumptions", "Aggregated Account"): ("party x external account at another institution (AGAC-)", BO, ""),
    ("Planning Inputs & Assumptions", "Aggregated Account Balance"): ("aggregated account x balance as-of date", BO, ""),
    # Projections & Scenarios
    ("Projections & Scenarios", "Planning Scenario"): ("client financial plan version x scenario (PLNSC-)", BO, ""),
    ("Projections & Scenarios", "Goal Projection Result"): ("planning scenario x financial goal", BO, ""),
    ("Projections & Scenarios", "Projection Year Result"): ("planning scenario x projection year", BO, ""),
    # Recommendations
    ("Recommendations", "Recommendation"): ("recommendation (RECOM-)", BO, ""),
    ("Recommendations", "Recommendation Rationale"): ("recommendation (rationale)", AG, "Recommendation"),
    ("Recommendations", "Recommendation Alternative"): ("recommendation x alternative number", BO, ""),
    ("Recommendations", "Best Interest Evidence"): ("recommendation x obligation component", BO, ""),
    ("Recommendations", "Recommendation Implementation Link"): ("recommendation x implementing record", BO, ""),
    # Rollover Analyses
    ("Rollover Analyses", "Rollover Analysis"): ("rollover recommendation x analysis (ROLV-)", BO, ""),
    ("Rollover Analyses", "PTE 2020-02 Documentation"): ("rollover analysis (PTE 2020-02 conditions)", AG, "Rollover Analysis"),
    ("Rollover Analyses", "Rollover Option Comparison"): ("rollover analysis x rollover option", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Planning Inputs & Assumptions", "Planning Assumption Set", "General Inflation Rate"): "24",   # 24 Inflation Assumption (row rule)
    ("Goals", "Goal Progress Snapshot", "Firm Assets Assigned to Goal"): "49",          # future owner 49, W3
    ("Goals", "Goal Progress Snapshot", "Contributions to Date"): "50",                 # 16 on participant-account rows; see ROW_OWNERSHIP
    ("Client Financial Plans", "Client Planning Assumptions", "Planning Federal Marginal Tax Rate"): "02",   # CW-024
    ("Rollover Analyses", "Rollover Analysis", "Rollover Amount"): "16",                # recordkept-plan rows; see ROW_OWNERSHIP
    ("Recommendations", "Recommendation", "Recommendation Engine Version"): "37",       # Model Version at the presented timestamp
    # Recommendation Implementation Link is a derived index (ruling 3, CW-032): the link is mastered on the implementing side.
    ("Recommendations", "Recommendation Implementation Link", "Implementing Enrollment"): "15",
    ("Recommendations", "Recommendation Implementation Link", "Implementing Account"): "15",
    ("Recommendations", "Recommendation Implementation Link", "Implementing Model Assignment"): "46",
    ("Recommendations", "Recommendation Implementation Link", "Implementing Client Order"): "48",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rule: which rows are mastered here and which are copies.
ROW_OWNERSHIP = {
    ("Planning Inputs & Assumptions", "Planning Assumption Set", "General Inflation Rate"):
        "Row rule (24/32 merge item): a Derived copy of the Inflation Assumption of the referenced 24 Capital Market Assumption Set "
        "version; mastered in 45 only on rows that record a flagged planning override of the house rate.",
    ("Rollover Analyses", "Rollover Analysis", "Rollover Amount"):
        "Row rule (CW-045): on rows with a Source Plan Membership (a plan the firm recordkeeps) the value is a Derived copy of the "
        "16 vested balance as of the Analysis Completed Date; on rows with a Source Aggregated Account or no 16 membership (a plan "
        "recordkept elsewhere) it is mastered in 45 from the client's plan statement or the aggregated balance on that date.",
    ("Goals", "Goal Progress Snapshot", "External Assets Assigned to Goal"):
        "Row rule: mastered in 45 on every row (computed from 45 Aggregated Account Balances); never includes 49 Client Holding "
        "values, which are held in Firm Assets Assigned to Goal as a Derived copy.",
    ("Goals", "Goal Progress Snapshot", "Contributions to Date"):
        "Row rule: Derived copy of 50 money movements for brokerage, IRA and advisory funding accounts; Derived copy of 16 "
        "Contribution Records where the funding account is a recordkept participant account.",
    ("Recommendations", "Recommendation Implementation Link", "Implementing Record Type"):
        "Row rule (CW-032): derived index. Rows of type Program Enrollment, Account Opening, Model Assignment and Client Order are "
        "copies of the links mastered on 15 Program Enrollment.Source Recommendation, 15 Account Opening.Originating Recommendation, "
        "46 Model Assignment.Source Recommendation and the 48 Client Order source; rows of type Plan Distribution are mastered in 45 "
        "(16 holds no recommendation link).",
    ("Recommendations", "Recommendation Alternative", "Alternative Description"):
        "Row rule (ruling 7): no rows for a Recommendation of type Rollover; its alternatives are Rollover Option Comparison rows "
        "of the Supporting Rollover Analysis. Likewise Recommendation Rationale.Rationale Basis is blank for a rollover (Rollover "
        "Analysis.Best Interest Reasons) and the PTE attestation is held only on PTE 2020-02 Documentation.",
    ("Recommendations", "Best Interest Evidence", "Client-Level Form CRS Delivered Date"):
        "Row rule: filled only when Evidence Disclosure Delivery (15, account-keyed) is blank, for a Form CRS delivered before an "
        "account exists or not keyed to an account (SEC Rule 17a-3(a)(24)); mastered in 45 on those rows.",
}

SUMMARY = {
    "masters": (
        "Masters the advice record of the wealth manager: advice engagements, their participants and advice reviews including "
        "the Rule 3a-4 annual contact; financial goals, goal funding links, retirement-income and education goal detail and goal "
        "progress snapshots; client financial plans, plan versions and the goals they include; planning cash-flow inputs, balance-sheet "
        "items, client planning assumptions and firm planning assumption sets; aggregated external accounts and their balances; planning scenarios and their goal and "
        "yearly projection results; recommendations with their rationale, alternatives, Reg BI and Advisers Act best-interest "
        "evidence and the implementation index (Derived from 15, 46 and 48); and rollover analyses, option comparisons and PTE 2020-02 documentation."
    ),
    "references": (
        "References clients, households, retirement plan identities, investor profile versions and consent records from 02 Client "
        "& Household; accounts, program enrollments, account agreements and disclosure deliveries from 15 Account; service "
        "offerings, model portfolios and share classes from 01; instruments from 17; plan memberships, plan fee schedules and "
        "distribution requests from 16; employees from 20; planning and advice engines from 37; data license agreements from 14; "
        "service interactions and communications from 13; model assignments from 46, client fee schedules from 47 and trusts from 51 (W2); "
        "recipient delivery records from 13; and, from W3 domains, client orders (48), capital-market assumption sets (24) and client account performance (32), "
        "with Derived copies of Client Holding values (49), money movements (50), the 02 tax rate and the 16 rollover amount."
    ),
}
