"""Enrichment for Data Domain 46 - Managed Portfolios & Rebalancing (wealth-manager model, W2; contract v0.4): grain,
ownership flags, summary. New domain (CW-009); content module content_46_managed_portfolios_and_rebalancing.py.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Model Assignment
    ("Model Assignment", "Model Assignment"): ("account x model portfolio x assignment period (MASGN-)", BO, ""),
    ("Model Assignment", "Tax Management Setting"): ("model assignment (tax management parameters)", AG, "Model Assignment"),
    ("Model Assignment", "Sleeve Assignment"): ("model assignment x sleeve x sleeve period", BO, ""),
    ("Model Assignment", "Household Managed Group"): ("Client Household x member account x membership period", BO, ""),
    # Targets & Constraints
    ("Targets & Constraints", "Managed Account Target"): ("model assignment x account target version", BO, ""),
    ("Targets & Constraints", "Account Target Override Line"): ("managed account target version x asset class or instrument", BO, ""),
    ("Targets & Constraints", "Account Investment Constraint"): ("account x source restriction or trust term x constraint type x effective period", BO, ""),
    # Drift Monitoring
    ("Drift Monitoring", "Rebalance Trigger Rule"): ("program (or program x model) x trigger type x rule period", BO, ""),
    ("Drift Monitoring", "Drift Assessment"): ("account x assessment timestamp (DRFT-)", BO, ""),
    ("Drift Monitoring", "Drift Assessment Line"): ("drift assessment x asset class or instrument", BO, ""),
    # Rebalancing
    ("Rebalancing", "Account Rebalance Event"): ("account x rebalance event (ARBE-)", BO, ""),
    ("Rebalancing", "Model Change Implementation"): ("model portfolio x from target set version x to target set version", BO, ""),
    # Tax Management
    ("Tax Management", "Account Tax Budget"): ("account x tax year", BO, ""),
    ("Tax Management", "Tax-Loss Harvest Decision"): ("account x harvest opportunity (TLH-)", BO, ""),
    ("Tax Management", "Substantially Identical Security Group"): ("security group x member instrument x membership period", BO, ""),
    ("Tax Management", "Wash Sale Control Window"): ("household managed group or account x security group x window start (loss sales of one group on the same day merge into one window)", BO, ""),
    ("Tax Management", "Asset Location Decision"): ("Client Household x asset class x account x placement period", BO, ""),
    # Trade Proposals
    ("Trade Proposals", "Trade Proposal Batch"): ("trade proposal batch (TPBAT-)", BO, ""),
    ("Trade Proposals", "Trade Proposal"): ("proposal line: account x instrument x side within a batch (TRPR-)", BO, ""),
    ("Trade Proposals", "Proposed Client Lot Selection"): ("trade proposal x client tax lot (49)", BO, ""),
    ("Trade Proposals", "Trade Proposal Exception"): ("trade proposal x pre-trade check x exception raised", BO, ""),
    # Cash Management
    ("Cash Management", "Managed Account Cash Instruction"): ("account x cash instruction (CSHI-)", BO, ""),
    # Managed Account Composites
    ("Managed Account Composites", "Managed Account Composite"): ("managed account composite (program x model; MACP-)", BO, ""),
    ("Managed Account Composites", "Managed Account Composite Membership"): ("composite x account x membership start date", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)". 49 is the brokerage book of record (W3).
DERIVED = {
    ("Model Assignment", "Tax Management Setting", "Applied Federal Marginal Tax Rate"): "02",
    ("Drift Monitoring", "Drift Assessment", "Account Market Value"): "49",
    ("Drift Monitoring", "Drift Assessment", "Pending Activity Indicator"): "49",
    ("Drift Monitoring", "Drift Assessment Line", "Actual Weight"): "49",
    ("Drift Monitoring", "Drift Assessment Line", "Line Target Weight"): "24",
    ("Tax Management", "Account Tax Budget", "Realized Net Gain to Date"): "49",
    ("Tax Management", "Account Tax Budget", "Realized Short-Term Gain to Date"): "49",
    ("Tax Management", "Tax-Loss Harvest Decision", "Unrealized Loss at Scan"): "49",
    ("Trade Proposals", "Proposed Client Lot Selection", "Lot Holding Period Term"): "49",
    ("Cash Management", "Managed Account Cash Instruction", "Available Cash Used"): "49",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rules.
ROW_OWNERSHIP = {
    ("Drift Monitoring", "Drift Assessment Line", "Line Target Weight"):
        "Row rule (CW-047): (1) where the assessed account target version has an Account Target Override Line for the line's "
        "asset class or instrument, the value is that line's Override Weight (mastered in 46); (2) otherwise, on an asset class "
        "line, it is the sum of the Target Weights of the 24 Target Allocation Lines of the Applied Model Target Set (TGT-) whose "
        "Target Asset Class equals the line's Instrument Asset Class, plus the 24 instrument lines whose 17 Instrument carries that "
        "asset class (Derived copy, 24; no cross-list map is needed because 24, 49 and 46 all use 17 Instrument Asset Class); (3) "
        "on an instrument line it is the 24 instrument line weight, or 0 when the model does not hold the instrument. "
        "Classification, country and currency lines of 24 are not used for retail models.",
    ("Targets & Constraints", "Account Investment Constraint", "Constraint Limit Value"):
        "Row rule: mastered in 46 on program-imposed rows (Constraint Type 'Minimum Cash' with no source); on rows with a Source "
        "Client Restriction (02 CRX-) or Source Trust Term Provision (51) the limit is the coded reading of that restriction, "
        "whose text and terms stay mastered in 02 or 51.",
    ("Model Assignment", "Household Managed Group", "Account Tax Treatment"):
        "Row rule: on every row the value is set by rule from the member account's 15 Account Registration Type; it is a 46 "
        "classification until 15 adopts it (proposals_w2_46 SHARED_CANDIDATES), never entered by hand.",
}

SUMMARY = {
    "masters": (
        "Masters the managed account operations of the wealth manager's discretionary programs: model assignments per account "
        "with sleeves, household managed groups and tax management settings (including the tax-loss-harvesting election); "
        "versioned managed account targets, account target override lines and account investment constraints; rebalance trigger "
        "rules, drift assessments and their lines, account rebalance events and model change implementations; account tax "
        "budgets, tax-loss harvest decisions, substantially identical security groups, wash sale control windows and asset "
        "location decisions; trade proposal batches, trade proposals, proposed client lot selections and trade proposal "
        "exceptions up to release; managed account cash instructions; and managed account composites and their membership."
    ),
    "references": (
        "References model portfolios, service offerings and GIPS composites from 01 Investment Product & Service Offering; "
        "target allocation sets from 24 Portfolio Management & Construction; accounts, program enrollments, standing instructions "
        "and RMD records from 15 Account; Client Households, client restrictions and investor profiles from 02 Client & "
        "Household (with the applied tax rate as a Derived copy); recommendations from 45; client orders from 48; participant "
        "investment transfers from 16; Client Tax Lots and, as Derived copies, holding values, realized gains, pending activity "
        "and cash from 49 (50 money movements and 47 fee debits reference the cash instruction from their side); trust term provisions from 51; sub-adviser engagements from 52; instruments from 17; benchmarks "
        "from 01; rebalancing engines from 37 Model Inventory Entry; and employees from 20 Human Capital."
    ),
}
