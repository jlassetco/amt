"""Enrichment for Data Domain 47 - Pricing, Fees & Billing (wealth-manager model, W2; contract v0.4): grain, ownership flags, summary.

New domain (CW-012). The five objects moved from 12 Fee Billing & Invoicing (CW-054) keep their names; their grains follow the
wholesale enrich_12.py, with the billing arrangement now carried on the Performance Fee Calculation.
"""

BO, AG = "Business Object", "Attribute Group"

F_SCH, F_ASN, F_CAL = "Fee Schedules & Pricing", "Fee Assignment & Householding", "Fee Calculation"
F_COL, F_ADJ, F_INS, F_DSC = "Fee Collection", "Waivers, Credits & Disputes", "Institutional Billing", "Disclosure & Custody-Rule Evidence"

GRAIN = {
    # Fee Schedules & Pricing
    (F_SCH, "Fee Schedule"): ("client fee schedule x version (CLFEE-)", BO, ""),
    (F_SCH, "Performance Fee Terms"): ("fee schedule version (institutional mandate performance fee terms)", AG, "Fee Schedule"),
    (F_SCH, "Fee Schedule Tier"): ("fee schedule version x tier sequence", BO, ""),
    (F_SCH, "Commission & Transaction Charge Rate"): ("fee schedule version x instrument charge category x charge channel", BO, ""),
    (F_SCH, "Account Service Fee Item"): ("fee schedule version x account service type", BO, ""),
    (F_SCH, "Fee Discount Rule"): ("fee schedule version x discount rule code", BO, ""),
    # Fee Assignment & Householding
    (F_ASN, "Fee Schedule Assignment"): ("billed subject (program enrollment, account, advice engagement or plan service arrangement) x fee schedule version x assignment period (FEASG-)", BO, ""),
    (F_ASN, "Fee Rate Override"): ("fee schedule assignment x override effective period", BO, ""),
    (F_ASN, "Fee Household"): ("fee household (FHHG-)", BO, ""),
    (F_ASN, "Fee Household Membership"): ("fee household x member account x membership effective period", BO, ""),
    # Fee Calculation
    (F_CAL, "Fee Calculation Run"): ("fee calculation run (billing period x run sequence; FCRUN-)", BO, ""),
    (F_CAL, "Account Fee Calculation"): ("fee calculation run x billed subject (fee schedule assignment, or billing arrangement for a mandate)", BO, ""),
    (F_CAL, "Billable Asset Exclusion"): ("account fee calculation x exclusion category x excluded Client Holding or balance", BO, ""),
    (F_CAL, "Fee Calculation Exception"): ("account fee calculation x fee exception type x exception raised", BO, ""),
    # Fee Collection
    (F_COL, "Fee Debit"): ("account fee calculation or event-based service charge x debited account (FDBT-)", BO, ""),
    (F_COL, "Fee Invoice"): ("fee invoice (billing arrangement or fee schedule assignment x billing period; BIL-)", BO, ""),
    # Waivers, Credits & Disputes
    (F_ADJ, "Fee Waiver"): ("fee schedule assignment or billing arrangement x waiver x waiver period (FWV-)", BO, ""),
    (F_ADJ, "Fee Adjustment"): ("fee adjustment (FADJ-, proposed; adjusted invoice or account fee calculation x adjustment type x adjustment)", BO, ""),
    (F_ADJ, "Billing Dispute"): ("billing dispute (disputed invoice or account fee calculation x dispute case; BDP-)", BO, ""),
    # Institutional Billing
    (F_INS, "Billing Arrangement"): ("billing arrangement (mandate x bill-to party x effective period; BLA-)", BO, ""),
    (F_INS, "Performance Fee Calculation"): ("billing arrangement x calculation period end", BO, ""),
    # Disclosure & Custody-Rule Evidence
    (F_DSC, "Fee Disclosure Delivery"): ("recipient party (or account) x fee disclosure type x fee schedule version x delivered date", BO, ""),
    (F_DSC, "Fee Deduction Authorization"): ("authorized account x authorizing account agreement", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    (F_CAL, "Account Fee Calculation", "Account Valuation"): "49",          # 49 Client Holding Valuation; mandate rows 18 (ROW_OWNERSHIP)
    (F_CAL, "Billable Asset Exclusion", "Excluded Amount"): "49",
    (F_COL, "Fee Invoice", "Payment Status"): "19",                          # 19 Receivable Status (CD-158)
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rules: which rows are mastered here and which are copies.
ROW_OWNERSHIP = {
    (F_COL, "Fee Invoice", "Billable Assets"):
        "Row rule: mastered here as the billed figure on every row. On invoices billed under a fee schedule assignment it is the "
        "Billable Assets of the Account Fee Calculations the invoice bills (inputs from 49 Client Holding Valuation); on "
        "institutional mandate invoices it is computed on the schedule's Billing Basis (or the arrangement's override) from the 18 "
        "Portfolio Holding valuations of the mandate's portfolio as of the billing period end.",
    (F_CAL, "Account Fee Calculation", "Account Valuation"):
        "Row rule: rows whose billed subject is a fee schedule assignment (accounts carried by the broker-dealer) copy 49 Client "
        "Holding Valuation (CLHLD-) as of the run's Valuation As-Of Date; rows whose subject is a Billing Arrangement (institutional "
        "mandate) copy the 18 Portfolio Holding valuations (HLD-) of the mandate's portfolio as of the period end. Flag Derived copy (49) "
        "is the majority source.",
    (F_CAL, "Billable Asset Exclusion", "Excluded Amount"):
        "Row rule: as Account Fee Calculation.Account Valuation: 49 Client Holding Valuation for broker-dealer accounts, 18 Portfolio "
        "Holding valuation for mandates.",
    (F_COL, "Fee Invoice", "Invoice Bill-To Party"):
        "Row rule: on mandate invoices the value equals Billing Arrangement.Bill-To Party at the invoice date (a copy within 47, "
        "kept as the addressee of the issued document); on other invoices it is mastered here from the assignment's client.",
    (F_CAL, "Account Fee Calculation", "Fee Household Assets"):
        "Row rule: calculated in 47 as the sum of Billable Assets of the member accounts' calculations in the same run; the inputs "
        "are Derived copies of 49.",
}

SUMMARY = {
    "masters": (
        "Masters the client fee and billing record of the wealth manager: client fee schedules and their versions (CLFEE-), tiers, "
        "commission and transaction charge rates, account service fee items and fee discount rules; fee schedule assignments "
        "(FEASG-) with the fee-paying account and fee rate overrides; fee households (FHHG-) and their membership; fee calculation "
        "runs (FCRUN-), account fee calculations, billable asset exclusions and calculation exceptions; fee debits (FDBT-) and fee "
        "invoices (BIL-); fee waivers (FWV-), fee adjustments (FADJ-) and billing disputes (BDP-); institutional billing arrangements (BLA-) "
        "with the qualified-client basis of the contract, mandate performance fee terms and performance fee calculations; fee disclosure "
        "deliveries after account opening and fee deduction authorizations under the custody rule."
    ),
    "references": (
        "References service offerings, service tiers, mandates, benchmarks and the transaction-fee category from 01 Investment "
        "Product & Service Offering; parties, client households and investor qualifications from 02 Client & Household; accounts, "
        "program enrollments and account agreements from 15 Account; plan service arrangements from 16 Retirement Plan "
        "Administration; statements, communications and service requests from 13; internal legal entities from 09; employees from "
        "20 Human Capital; complaints and supervisory reviews from 08; advice engagements from 45; managed account cash "
        "instructions from 46; Client Holdings, valuations, account transfers and client account activity from 49 (W3); mandate "
        "valuations from 18 Portfolio & Investment Book of Record; money movements from 50 (W3); the invoice payment status from 19 "
        "Finance & Accounting (Derived copy)."
    ),
}
