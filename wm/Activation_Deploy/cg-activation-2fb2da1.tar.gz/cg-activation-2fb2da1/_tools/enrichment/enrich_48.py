"""Enrichment for Data Domain 48 - Brokerage Orders & Execution (wealth-manager model, W3; new domain, CW-010; contract v0.4):
grain, ownership flags, summary.

Written for content_48_brokerage_orders_and_execution.py. Key formats of the six reserved prefixes (CLORD-, ROUTE-, CLEXE-,
CLBLK-, CCONF-, TCORR-) and the composite keys are in proposals_w3_brokerage.py (PREFIX_FORMATS, GRAIN_KEY_FORMATS).
"""

BO, AG = "Business Object", "Attribute Group"

F_ORD, F_CHK, F_RTE = "Client Orders", "Order-Time Checks", "Routing & Venues"
F_EXE, F_CNF, F_COR = "Execution & Allocation", "Confirmations & Trade Reporting", "Corrections & Errors"
F_OPT, F_EXQ = "Options Lifecycle", "Execution Quality & Audit Trail"

GRAIN = {
    # Client Orders
    (F_ORD, "Client Order"): ("client order (one 15 account's order in one instrument; CLORD-)", BO, ""),
    (F_ORD, "Order Instruction Detail"): ("client order (pricing, time in force, session and handling instructions)", AG, "Client Order"),
    (F_ORD, "Fixed Income Order Detail"): ("client order (debt security and brokered CD orders)", AG, "Client Order"),
    (F_ORD, "Fund Order Detail"): ("client order (mutual fund and 529 portfolio orders in a brokerage account)", AG, "Client Order"),
    (F_ORD, "Option Order Leg"): ("client order x leg sequence", BO, ""),
    (F_ORD, "Client Order Event"): ("client order x event sequence", BO, ""),
    # Order-Time Checks
    (F_CHK, "Order Eligibility Check"): ("client order x eligibility check type", BO, ""),
    (F_CHK, "Pre-Trade Risk Limit"): ("limit scope x scope account, segment or channel x instrument class x pre-trade limit type x limit effective period", BO, ""),
    # Routing & Venues
    (F_RTE, "Execution Venue Profile"): ("venue party (02 PTY-) x profile effective period", BO, ""),
    (F_RTE, "Routing Rule"): ("routing rule version (rule code x effective period)", BO, ""),
    (F_RTE, "Order Route"): ("client order or client block order x route sequence (ROUTE-)", BO, ""),
    # Execution & Allocation
    (F_EXE, "Client Block Order"): ("client block order (CLBLK-)", BO, ""),
    (F_EXE, "Client Execution"): ("client execution (one fill on one order route; CLEXE-)", BO, ""),
    (F_EXE, "Client Allocation"): ("client block order or client order x allocated account", BO, ""),
    # Confirmations & Trade Reporting
    (F_CNF, "Client Trade Confirmation"): ("client allocation x confirmation version (CCONF-)", BO, ""),
    (F_CNF, "Confirmation Remuneration Disclosure"): ("client trade confirmation version (markup and remuneration disclosure)", AG, "Client Trade Confirmation"),
    (F_CNF, "Regulatory Trade Report"): ("client execution x trade reporting facility x submission", BO, ""),
    # Corrections & Errors
    (F_COR, "Trade Correction"): ("trade correction (TCORR-)", BO, ""),
    (F_COR, "Trade Error Case"): ("trade error case (case number; covers one client order, a whole client block order or a missed instruction)", BO, ""),
    # Options Lifecycle
    (F_OPT, "Option Exercise Instruction"): ("account x option series x exercise date", BO, ""),
    (F_OPT, "Option Assignment Allocation"): ("OCC assignment notice x account", BO, ""),
    # Execution Quality & Audit Trail
    (F_EXQ, "Execution Quality Measure"): ("measurement period x order class x client order type x venue", BO, ""),
    (F_EXQ, "Rule 605 Report Line"): ("reporting broker-dealer x month x security x Rule 605 order type x size bucket", BO, ""),
    (F_EXQ, "Rule 606 Report Line"): ("reporting broker-dealer x quarter x month x Rule 606 order class x venue", BO, ""),
    (F_EXQ, "Order Routing Disclosure Request"): ("customer request under Rule 606(b)(1) or (b)(3) (party x account x request received date)", BO, ""),
    (F_EXQ, "CAT Reportable Event"): ("CAT reportable event record (firm CAT record ID, firmROEID; one per client order, route, execution or allocation event)", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    (F_ORD, "Fund Order Detail", "Transaction Fee Category Applied"): "01",
    (F_CHK, "Order Eligibility Check", "Buying Power At Entry"): "49",
    (F_CHK, "Order Eligibility Check", "Buying Power As-Of Timestamp"): "49",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rules.
ROW_OWNERSHIP = {
    (F_CHK, "Order Eligibility Check", "Buying Power At Entry"):
        "Row rule (CW-007, CW-099): filled only on rows of Eligibility Check Type 'Buying Power', where the value is a copy of the 49 "
        "Margin Balance Snapshot of Margin Snapshot Type Intraday, with its Margin Snapshot As-Of Timestamp (margin accounts), or Account Cash Balance of type cash available to invest (cash accounts) "
        "as of Buying Power As-Of Timestamp; blank on every other row. 48 masters the check result, never the balance.",
    (F_RTE, "Order Route", "Resulting Fund Order"):
        "Row rule (CW-097): filled only on routes to the in-house transfer agent (own funds), where the 29 Fund Order on the brokerage "
        "omnibus account is mastered in 29; third-party fund routes carry the Fund/SERV Control Number instead.",
    (F_RTE, "Execution Venue Profile", "Venue Party"):
        "Row rule (CD-143): the party, its name, LEI and CRD number are mastered in 02 on every row; the venue role profile (type, MIC, "
        "Rule 606 name, payment for order flow terms) is mastered here.",
}

SUMMARY = {
    "masters": (
        "Masters the client order flow of the self-clearing broker-dealer at account grain: client orders with their instruction, "
        "fixed income and fund detail, option order legs and client order events; order-time eligibility checks and Rule 15c3-5 "
        "pre-trade risk limits; execution venue profiles, routing rules and order routes; client block orders, client executions and "
        "client allocations; the client trade confirmation (Rule 10b-10 content) and its remuneration disclosure; regulatory trade "
        "reports; trade corrections and trade error cases; option exercise instructions and assignment allocations; execution quality "
        "measures, Rule 605 and Rule 606 report lines, order routing disclosure requests and CAT reportable events."
    ),
    "references": (
        "References accounts, account features, account restrictions, standing instructions and firm accounts from 15 Account; parties, "
        "authority grants and client restrictions from 02 Client & Household; tradable universe policy rules and share classes from 01; "
        "instruments and option series from 17; platform transaction-fee categories (Derived copy) from 01; approved prices from 22; trade proposals and "
        "batches from 46; recommendations from 45; client tax lots, client account activity (exercise and assignment bookings) and "
        "buying power (Derived copy) from 49; fund orders from 29; fee schedules from 47; supervisory reviews from 08; investor documents from 13; "
        "restricted list entries from 38; operational loss events from 37; employees from 20; and internal legal entities from 09."
    ),
}
