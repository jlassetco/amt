"""Enrichment for Data Domain 49 - Clearing, Settlement & Client Asset Custody (wealth-manager model, W3; contract v0.4):
grain, ownership flags, summary. New domain (CW-007); decisions CW-101 to CW-106 and CW-112 to CW-115 (proposals_w3_brokerage.py)."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Client Holdings
    ("Client Holdings", "Client Holding"): ("account x instrument x holding date x Holding View (CLHLD-)", BO, ""),
    ("Client Holdings", "Client Holding Valuation"): ("client holding (valuation)", AG, "Client Holding"),
    # Tax Lots & Cost Basis
    ("Tax Lots & Cost Basis", "Client Tax Lot"): ("account x instrument x acquisition lot (CTLOT-)", BO, ""),
    ("Tax Lots & Cost Basis", "Client Lot Relief"): ("client tax lot x closing activity (49 CLACT-) or closing register transaction (29 RGTX-)", BO, ""),
    ("Tax Lots & Cost Basis", "Cost Basis Adjustment"): ("client tax lot x adjustment sequence", BO, ""),
    ("Tax Lots & Cost Basis", "Cost Basis Transfer Statement"): ("account transfer x statement direction x statement version (IRC section 6045A)", BO, ""),
    # Activity & Cash
    ("Activity & Cash", "Client Account Activity"): ("account x posting (CLACT-)", BO, ""),
    ("Activity & Cash", "Account Cash Balance"): ("account x currency x cash balance type x balance basis x business date", BO, ""),
    # Clearance & Settlement
    ("Clearance & Settlement", "Street Settlement Obligation"): ("settling broker-dealer x clearing channel x instrument x contractual settlement date", BO, ""),
    ("Clearance & Settlement", "Client Settlement Fail"): ("client account activity x fail type", BO, ""),
    # Customer Protection
    ("Customer Protection", "Reserve Computation"): ("broker-dealer x computation date x Reserve Computation Type (RESRV-)", BO, ""),
    ("Customer Protection", "Reserve Computation Line"): ("reserve computation x Exhibit A formula item", BO, ""),
    ("Customer Protection", "Possession or Control Determination"): ("instrument x business date x deficit source (one row per deficit and source)", BO, ""),
    ("Customer Protection", "Control Location"): ("control location party (02 PTY-) x effective period", BO, ""),
    # Margin & Securities Lending
    ("Margin & Securities Lending", "Margin Balance Snapshot"): ("margin account x business date x snapshot type x as-of timestamp", BO, ""),
    ("Margin & Securities Lending", "Client Margin Call"): ("account x margin call (MGCL-)", BO, ""),
    ("Margin & Securities Lending", "Fully Paid Securities Loan"): ("account x borrowing entity x instrument x loan (CSLN-)", BO, ""),
    ("Margin & Securities Lending", "Loan Reporting Detail"): ("fully paid securities loan (reporting)", AG, "Fully Paid Securities Loan"),
    # Account Transfers
    ("Account Transfers", "Account Transfer"): ("account transfer (ACXF-)", BO, ""),
    ("Account Transfers", "Account Transfer Asset Line"): ("account transfer x asset line sequence", BO, ""),
    # Corporate Actions & Income
    ("Corporate Actions & Income", "Client Corporate Action Entitlement"): ("17 corporate action event x account (CLCAE-)", BO, ""),
    ("Corporate Actions & Income", "Dividend Reinvestment Allocation"): ("client corporate action entitlement (reinvestment)", AG, "Client Corporate Action Entitlement"),
    ("Corporate Actions & Income", "Client Voluntary Election"): ("client corporate action entitlement x corporate action option x election", BO, ""),
    # Controls & Books
    ("Controls & Books", "Security Count"): ("broker-dealer x quarter x control location x count date", BO, ""),
    ("Controls & Books", "Stock Record Reconciliation"): ("reconciliation type x business date x control location or sweep program", BO, ""),
    ("Controls & Books", "Stock Record Break"): ("stock record reconciliation x break sequence", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Client Holdings", "Client Holding", "Own Share Class Indicator"): "17",          # from 17 Instrument.Own Share Class
    ("Activity & Cash", "Client Account Activity", "Commission Amount"): "48",          # 48 Client Trade Confirmation.Commission Charged
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

ROW_OWNERSHIP = {
    ("Activity & Cash", "Account Cash Balance", "Cash Balance Amount"):
        "Row rule (CW-102): mastered in 49 on every row. On Sweep Balance rows the 50 Sweep Allocations (account x program bank x "
        "business date) explain the amount and must sum to it; a difference is a Stock Record Reconciliation break of type "
        "Program-Bank Sweep, never a 50 override.",
    ("Customer Protection", "Reserve Computation", "Aggregate Debit Items Amount"):
        "Row rule (CW-103): mastered in 49 on Customer and PAB rows; 43 Capital Requirement Calculation copies the Customer row "
        "only (Derived copy in 43) for the alternative net capital standard.",
    ("Corporate Actions & Income", "Client Corporate Action Entitlement", "Record Date Client Holding Quantity"):
        "Row rule (CW-090): mastered here as the entitlement's eligible balance, set from the account's own Client Holding at the "
        "record date; 13 Issuer Proxy Pass-Through copies it as Record Date Entitled Quantity (Derived copy in 13).",
    ("Tax Lots & Cost Basis", "Client Tax Lot", "Acquisition Register Transaction"):
        "Row rule (CW-034, CW-122, CW-141): exactly one of Acquisition Activity (49, brokerage accounts) or Acquisition Register "
        "Transaction (29, fund-only TA-registered accounts) is filled. The lot is mastered in 49 on every row; the 29 register holds "
        "the shares only.",
    ("Tax Lots & Cost Basis", "Client Lot Relief", "Closing Register Transaction"):
        "Row rule (CW-141): exactly one of Closing Activity (49) or Closing Register Transaction (29) is filled; the relief is "
        "mastered in 49 on every row.",
    ("Clearance & Settlement", "Street Settlement Obligation", "Net Settlement Amount"):
        "Row rule (CW-097): mastered in 49 on street channel rows; blank on Own-Fund Omnibus rows, where the referenced 29 "
        "Settlement Obligation holds the quantity, amount and dates.",
    ("Controls & Books", "Stock Record Break", "External Quantity"):
        "Row rule (CW-122): read from the external record and never mastered here; on Stock Record to Own-Fund Omnibus runs it is "
        "the 29 Share Register Balance quantity.",
    ("Margin & Securities Lending", "Margin Balance Snapshot", "Margin Debit Balance"):
        "Row rule: on End of Day snapshots it equals the Account Cash Balance row of type Margin Debit Balance (the ledger balance); "
        "intraday snapshots carry the margin engine figure at the As-Of Timestamp.",
}

SUMMARY = {
    "masters": "Masters the brokerage book of record of the self-clearing broker-dealer at account grain: Client Holdings, Client Tax Lots of brokerage and fund-only accounts and their valuation, lot relief, cost basis adjustments, covered-security status and IRC section 6045A transfer statements, Client Account Activity and Account Cash Balances including the Sweep Balance, street settlement obligations and client settlement fails, the Rule 15c3-3 customer and PAB Reserve Computation, possession or control determinations and control locations, margin balances and calls, fully paid securities loans, account transfers, client corporate action entitlements, elections and dividend reinvestment, and the security counts and stock record reconciliations that prove the books.",
    "references": "References accounts, features, elections, agreements and restrictions from 15; parties, contra firms and control location parties from 02; instruments, corporate action events and options from 17; approved prices from 22; internal legal entities and calendars from 09; employees from 20; reserve bank accounts from 43; fund orders, register transactions (fund-only account lots), settlement obligations and share register balances from 29; service requests from 13; and, from the W2 and W3 siblings, client orders and allocations from 48 (with the confirmed commission as a Derived copy), money movements and sweep programs from 50, and fee debits from 47.",
}
