"""Enrichment for Data Domain 50 - Money Movement, Cash & Sweep (wealth-manager model, W3; contract v0.4): grain, ownership
flags, summary. New domain (CW-016); content module content_50_money_movement_cash_and_sweep.py.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Money Movements
    ("Money Movements", "Money Movement"): ("money movement (MMVMT-)", BO, ""),
    ("Money Movements", "Money Movement Event"): ("money movement x event", BO, ""),
    ("Money Movements", "ACH Entry Detail"): ("money movement (ACH rail)", AG, "Money Movement"),
    ("Money Movements", "Wire Transfer Detail"): ("money movement (Fedwire or international wire rail)", AG, "Money Movement"),
    ("Money Movements", "Check Detail"): ("money movement (check rail)", AG, "Money Movement"),
    ("Money Movements", "Internal Transfer Detail"): ("money movement (internal journal)", AG, "Money Movement"),
    # Returns & Exceptions
    ("Returns & Exceptions", "Money Movement Return"): ("money movement x return sequence", BO, ""),
    ("Returns & Exceptions", "Money Movement Exception"): ("money movement x exception", BO, ""),
    # Verification, Holds & Fraud
    ("Verification, Holds & Fraud", "Bank Account Verification Event"): ("bank instruction (15 ABI-) x verification attempt", BO, ""),
    ("Verification, Holds & Fraud", "Money Movement Hold"): ("money movement hold (MMHLD-)", BO, ""),
    ("Verification, Holds & Fraud", "Fraud Risk Assessment"): ("money movement x assessment timestamp", BO, ""),
    # Monitoring & Sanctions
    ("Monitoring & Sanctions", "Money Movement Monitoring Alert"): ("money movement monitoring alert (MMALT-)", BO, ""),
    ("Monitoring & Sanctions", "Payment Sanctions Screening"): ("money movement x screening run", BO, ""),
    # Sweep Programs & Program Banks
    ("Sweep Programs & Program Banks", "Sweep Program"): ("sweep program (SWEEP-)", BO, ""),
    ("Sweep Programs & Program Banks", "Program Bank"): ("bank party (02 PTY-) in the program bank role x role period (PGBNK-)", BO, ""),
    ("Sweep Programs & Program Banks", "Program Bank Participation"): ("sweep program x program bank x effective period", BO, ""),
    ("Sweep Programs & Program Banks", "Sweep Rate Tier"): ("sweep program x rate tier basis x balance tier x effective period", BO, ""),
    # Sweep Operations & Deposit Insurance
    ("Sweep Operations & Deposit Insurance", "Sweep Run"): ("sweep program x business date x run cycle", BO, ""),
    ("Sweep Operations & Deposit Insurance", "Sweep Allocation"): ("account x program bank x business date", BO, ""),
    ("Sweep Operations & Deposit Insurance", "Program Bank Daily Total"): ("sweep program x program bank x business date", BO, ""),
    ("Sweep Operations & Deposit Insurance", "FDIC Coverage Assessment"): ("party x FDIC ownership category x program bank x assessment date", BO, ""),
    # Cards & Checks
    ("Cards & Checks", "Debit Card"): ("debit card instance (DCARD-)", BO, ""),
    ("Cards & Checks", "Card Transaction Detail"): ("money movement (debit card rail)", AG, "Money Movement"),
    ("Cards & Checks", "Card Dispute"): ("card money movement x dispute", BO, ""),
    # Cash Forecasting
    ("Cash Forecasting", "Client Cash Forecast"): ("client cash forecast version (as-of date x version)", BO, ""),
    ("Cash Forecasting", "Client Cash Forecast Line"): ("client cash forecast x value date x client cash flow category x sweep program", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Verification, Holds & Fraud", "Fraud Risk Assessment", "Account Age Days"): "15",   # from 15 Account.Account Open Date, as of Assessment Timestamp
    # Facts of the 02 bank party (proposal to 02 at W5: FDIC Certificate Number identifier scheme and charter class).
    ("Sweep Programs & Program Banks", "Program Bank", "FDIC Certificate Number"): "02",
    ("Sweep Programs & Program Banks", "Program Bank", "Bank Charter Type"): "02",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rules.
ROW_OWNERSHIP = {
    ("Verification, Holds & Fraud", "Bank Account Verification Event", "Verification Result"):
        "Row rule (CW-033): every verification attempt is mastered here, coded in the 15 Bank Verification Method and Bank "
        "Verification Status lists. 15 Bank Instruction.Bank Verification Status and Bank Verification Method hold the current "
        "state of the instruction and are set from the latest event whose result is Verified, Failed or Returned (values copied "
        "as they are; no map needed); 15 never records attempts.",
    ("Sweep Operations & Deposit Insurance", "Sweep Allocation", "Allocated Balance"):
        "Row rule (CW-102): mastered here per account x program bank x business date. The account total for the date is the 49 "
        "Account Cash Balance of balance type Sweep Balance; the sum of the account's allocations must equal it, and a difference "
        "is a break in the 49 Stock Record Reconciliation of type Program-Bank Sweep. Money market sweep shares are 49 Client "
        "Holdings and have no allocation row.",
    ("Verification, Holds & Fraud", "Money Movement Hold", "Hold Type"):
        "Row rule (CW-109, CW-115, CD-344): a row is 'PII - special category (CD-344)', with a restricted view, when Hold Type is "
        "FINRA Rule 2165 Disbursement Hold or FINRA Rule 2166 Temporary Delay, OR when Hold Reason is Suspected Financial "
        "Exploitation, Diminished Capacity Concern, Undue Influence or Scam Victim - Specified Adult; every other row is 'PII - "
        "financial'. A Rule 2165 hold must carry one of those four reasons and its cause is the 02 Vulnerability Concern in "
        "Source Vulnerability Concern. A hold on securities transactions or the whole account is a 15 Account Restriction, "
        "never a row here.",
    ("Monitoring & Sanctions", "Money Movement Monitoring Alert", "Monitoring Scenario"):
        "Row rule (CD-344): alerts whose scenario is Elder Exploitation Pattern record suspected exploitation of a specified "
        "adult and are 'PII - special category (CD-344)' in addition to the AML restriction (31 CFR 1023.320(e)); every other "
        "alert is 'PII - financial (restricted)'.",
    ("Sweep Programs & Program Banks", "Sweep Program", "Eligible Sweep Funds"):
        "Row rule: the program lists its eligible money market funds here; 15 Cash Sweep Election.Elected Sweep Fund holds the "
        "client's choice and must be one of the program's eligible funds.",
}

SUMMARY = {
    "masters": (
        "Masters every money movement into, out of and between client accounts (ACH, wire, check, internal journal, debit card, "
        "bill pay) with its rail detail and event trail, returns and exceptions; bank account verification events; money movement "
        "holds and fraud risk assessments; money movement monitoring alerts and payment sanctions screening; sweep programs, "
        "program banks, program bank participation and sweep rate tiers; sweep runs, sweep allocations, program bank daily "
        "totals and FDIC coverage assessments; debit cards, card transaction detail and Regulation E card disputes; and client "
        "cash forecasts."
    ),
    "references": (
        "References accounts, standing instructions, bank instructions, account features and account restrictions from 15 "
        "Account; parties, authority grants, trusted contacts, vulnerability concerns, contact points and death notifications "
        "(and, as Derived copies, the FDIC certificate number and charter of the bank party) from 02 Client & Household; account "
        "cash balances from 49; corporate bank accounts and the cash forecast from 43; fund orders from 29; AML cases, AML and "
        "sanctions reports and policies from 38; senior investor cases from 08; contracts from 39; managed account cash "
        "instructions from 46, fee debits from 47, trust distribution requests from 51, promotion enrollments from 04, service "
        "requests from 13 and distribution requests from 16; share classes from 01; models and loss events from 37; licensed "
        "datasets from 14; employees from 20; and internal legal entities from 09."
    ),
}
