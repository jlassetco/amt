"""Enrichment for Data Domain 51 - Trust & Estate Services (wealth-manager model, W2; contract v0.4): grain, ownership flags, summary.

New, optional, Light-tier domain (CW-017, CW-075 to CW-079). Content module: content_51_trust_and_estate_services.py.
"""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Trust Instruments & Terms
    ("Trust Instruments & Terms", "Trust"): ("trust (TRUST-)", BO, ""),
    ("Trust Instruments & Terms", "Trust Instrument Document"): ("trust x instrument version", AG, "Trust"),
    ("Trust Instruments & Terms", "Trust Term Provision"): ("trust x provision type x provision sequence x instrument version", BO, ""),
    # Fiduciary Roles & Interests
    ("Fiduciary Roles & Interests", "Trust Role"): ("trust x role holder (02 party or 09 internal legal entity) x trust role type x role effective from", BO, ""),
    ("Fiduciary Roles & Interests", "Beneficial Interest"): ("trust x beneficiary party x beneficial interest type x interest effective from", BO, ""),
    # Discretionary Distributions
    ("Discretionary Distributions", "Trust Distribution Request"): ("trust distribution request (TDRQ-)", BO, ""),
    ("Discretionary Distributions", "Distribution Decision"): ("trust distribution request (latest decision; an interim deferral is replaced)", AG, "Trust Distribution Request"),
    # Trust Accounting
    ("Trust Accounting", "Principal and Income Allocation"): ("trust x source event (49 client account activity or 50 money movement) x allocation sequence", BO, ""),
    ("Trust Accounting", "Fiduciary Accounting Statement"): ("trust x accounting period end date", BO, ""),
    # Fiduciary Reviews
    ("Fiduciary Reviews", "Fiduciary Account Review"): ("fiduciary account review (FIRV-; trust x review type x due date)", BO, ""),
    ("Fiduciary Reviews", "Fiduciary Review Exception"): ("fiduciary account review x exception sequence", AG, "Fiduciary Account Review"),
    # Estate Settlement
    ("Estate Settlement", "Estate Settlement Case"): ("estate settlement case (ESTATE-; one per decedent's estate the trust company acts for)", BO, ""),
    ("Estate Settlement", "Estate Settlement Task"): ("estate settlement case x estate milestone x task sequence", AG, "Estate Settlement Case"),
    # Fiduciary Tax
    ("Fiduciary Tax", "Fiduciary Tax Return"): ("trust or estate x tax year end date x return (TXRT-)", BO, ""),
    ("Fiduciary Tax", "Beneficiary Tax Allocation"): ("fiduciary tax return x beneficiary (Schedule K-1)", AG, "Fiduciary Tax Return"),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Trust Instruments & Terms", "Trust", "Trust Name"): "02",                                   # Organization.Legal Name of the Trust Party
    ("Trust Accounting", "Fiduciary Accounting Statement", "Closing Market Value"): "49",          # future owner 49, W3
    ("Fiduciary Reviews", "Fiduciary Account Review", "Client Holding Valuation Date"): "49",     # future owner 49, W3
    ("Fiduciary Tax", "Fiduciary Tax Return", "Filer EIN"): "02",                                 # US Regulatory Identifier.Employer Identification Number
    ("Trust Accounting", "Fiduciary Accounting Statement", "Trustee Report Delivered Date"): "13",  # delivery date of the 13 communication
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# CD-289 row rules.
ROW_OWNERSHIP = {
    ("Fiduciary Roles & Interests", "Trust Role", "Trust Role Type"):
        "Row rule (CW-075): mastered in 51 on every row. For trusts that have a 51 Trust record, 02 Party Relationship rows of "
        "type 'Trustee Of' (from Trustee, Co-Trustee, Directed Trustee and serving Successor Trustee rows, i.e. with Role Effective "
        "From set) and 'Grantor Of' (from Grantor / Settlor rows) are a Derived copy of this attribute, but only for rows with a "
        "Role Holder Party (02). Rows held by the trust company (Role Holder Entity, 09) derive no 02 row: they are the firm's "
        "fiduciary appointment, held once here. For trusts without a 51 record (no trust services, lever) the 02 rows are mastered in 02.",
    ("Fiduciary Roles & Interests", "Beneficial Interest", "Beneficial Interest Type"):
        "Row rule (CW-075, program lead ruling: 51 masters every trust relationship): mastered in 51 on every row. For trusts that "
        "have a 51 Trust record, 02 Party Relationship rows of type 'Trust Beneficiary Of' are a Derived copy of the current "
        "Beneficial Interest rows (one 02 row per beneficiary party and trust party); for trusts without a 51 record they are mastered in 02.",
    ("Trust Instruments & Terms", "Trust Instrument Document", "Certification of Trust Received Date"):
        "Row rule (CW-035, CW-075, program lead ruling): mastered in 51 for every trust with a 51 Trust record, including "
        "certification-only trusts (client trustee, no Trust Role row held by the trust company). The same rule covers Execution "
        "Date of instrument version 1 and Trust Situs and Governing Law Jurisdiction: 15 Account Registration Detail Trust or "
        "Agreement Date and Registration Jurisdiction are Derived copies of 51 for those trusts (15 merge edit).",
}

SUMMARY = {
    "masters": (
        "Masters the fiduciary record of the optional trust company: the Trust (TRUST-) and its instrument documents and versioned "
        "term provisions; trust roles (grantor, trustee, co-trustee, successor trustee, trust protector, directed advisers, agent) "
        "and beneficial interests; trust distribution requests (TDRQ-) and distribution decisions; principal and income "
        "allocations and fiduciary accounting statements; 12 CFR 9.6 fiduciary account reviews (FIRV-) and their exceptions; estate "
        "settlement cases (ESTATE-) and their milestones; and fiduciary tax returns (TXRT-) with Schedule K-1 beneficiary allocations."
    ),
    "references": (
        "References parties, authority grants and death notifications from 02 Client & Household (with the trust name and EIN as "
        "Derived copies); the trust company from 09 Shared & Enterprise Reference Data; fiduciary accounts from 15 Account; client "
        "account activity and Client Holding values from 49 (W3, Derived copies) and money movements from 50 (W3); service requests "
        "and the trustee report delivery date (Derived) from 13; trust officers from 03 and employees from 20 Human Capital; trust committees and legal matters from 39; and "
        "conflicts of interest from 38."
    ),
}
