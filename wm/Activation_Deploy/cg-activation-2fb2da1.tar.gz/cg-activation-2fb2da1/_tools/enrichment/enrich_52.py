"""Enrichment for Data Domain 52 - External Manager & Sub-Adviser Oversight (wealth manager, new domain, CW-014; contract
v0.4): grain, ownership flags, summary."""

BO, AG = "Business Object", "Attribute Group"

GRAIN = {
    # Manager Universe
    ("Manager Universe", "External Manager Profile"): ("external manager (02 party, PTY-) in its research role", BO, ""),
    ("Manager Universe", "Manager Key Person"): ("external manager x individual (02 party) x key person role x role period", BO, ""),
    ("Manager Universe", "External Manager Strategy"): ("external manager x strategy researched (EMSTR-)", BO, ""),
    # Manager Search & Selection
    ("Manager Search & Selection", "Manager Search"): ("manager search (MSRCH-)", BO, ""),
    ("Manager Search & Selection", "Search Outcome"): ("manager search (recommended outcome)", AG, "Manager Search"),
    ("Manager Search & Selection", "Search Candidate"): ("manager search x external manager strategy", BO, ""),
    # Manager Due Diligence
    ("Manager Due Diligence", "Due Diligence Questionnaire Template"): ("questionnaire template x version", BO, ""),
    ("Manager Due Diligence", "Manager Due Diligence Review"): ("manager due diligence review (MDILG-)", BO, ""),
    ("Manager Due Diligence", "Due Diligence Score"): ("manager due diligence review x scoring factor", BO, ""),
    ("Manager Due Diligence", "Onsite Visit"): ("manager due diligence review x visit date", BO, ""),
    ("Manager Due Diligence", "Background Check Result"): ("manager key person x background check type x check date", BO, ""),
    # Sub-Advisory Engagements
    ("Sub-Advisory Engagements", "Sub-Adviser Engagement"): ("sub-adviser x fund or mandate x sleeve x engagement period (SADV-)", BO, ""),
    ("Sub-Advisory Engagements", "Manager-of-Managers Hire Condition"): ("sub-adviser engagement (hire under a manager-of-managers order)", AG, "Sub-Adviser Engagement"),
    ("Sub-Advisory Engagements", "Sub-Adviser Guideline Set"): ("sub-adviser engagement x guideline version (GDLN-)", BO, ""),
    ("Sub-Advisory Engagements", "Guideline Rule Inclusion"): ("guideline set version x 33 compliance rule version or 01 investment restriction", BO, ""),
    ("Sub-Advisory Engagements", "Sub-Adviser Compliance Certification"): ("certification subject (external manager for firm-level types; sub-adviser engagement for quarterly guideline compliance) x certification type x certification period", BO, ""),
    # Oversight Reviews
    ("Oversight Reviews", "Oversight Review"): ("oversight review (OVRVW-) of an engagement or an approved product", BO, ""),
    ("Oversight Reviews", "Oversight Metric Reading"): ("oversight review x oversight metric", BO, ""),
    ("Oversight Reviews", "Oversight Metric Threshold"): ("sub-adviser engagement x oversight metric x threshold effective period", BO, ""),
    ("Oversight Reviews", "Sub-Adviser Watch Status"): ("sub-adviser engagement x watch status effective period", BO, ""),
    ("Oversight Reviews", "Section 15(c) Renewal Submission"): ("sub-adviser engagement x 35 advisory contract renewal (RENEW-)", BO, ""),
    # Findings & Remediation
    ("Findings & Remediation", "Oversight Finding"): ("oversight finding (OVFND-)", BO, ""),
    ("Findings & Remediation", "Remediation Action"): ("oversight finding x action sequence", BO, ""),
    # Product Due Diligence
    ("Product Due Diligence", "Product Due Diligence"): ("third-party product (17 INS-) x review (TPDUE-)", BO, ""),
    ("Product Due Diligence", "Product Due Diligence Criterion Result"): ("product due diligence x criterion", BO, ""),
    ("Product Due Diligence", "Fund of Funds Use Detail"): ("product due diligence x acquiring fund of funds", BO, ""),
    ("Product Due Diligence", "Product List Status"): ("third-party product x list scope x status effective period", BO, ""),
    # Termination & Transition
    ("Termination & Transition", "Manager Termination"): ("sub-adviser engagement x termination", BO, ""),
}

# Copies of values mastered in another Data Domain, not typed "Reference (...)".
DERIVED = {
    ("Manager Universe", "External Manager Profile", "Reported Firm AUM"): "14",
    ("Manager Universe", "External Manager Profile", "Firm AUM As-Of Date"): "14",
    ("Manager Universe", "External Manager Strategy", "Reported Strategy AUM"): "14",
    ("Manager Universe", "External Manager Strategy", "Strategy AUM As-Of Date"): "14",
    # Board approval read through 35 Resolution Subject Link (CD-237).
    ("Sub-Advisory Engagements", "Sub-Adviser Engagement", "Board Approval Date"): "35",
    ("Sub-Advisory Engagements", "Manager-of-Managers Hire Condition", "Information Statement Sent Date"): "13",
    # Numbers are read, not computed (CW-119); owner per row in ROW_OWNERSHIP.
    ("Oversight Reviews", "Oversight Metric Reading", "Metric Value"): "32",
    ("Product Due Diligence", "Product Due Diligence Criterion Result", "Criterion Value"): "14",
    # Interim status is the 35 agreement type; the return version is the 32 record read.
    ("Manager Search & Selection", "Search Outcome", "Interim Contract Indicator"): "35",
    ("Oversight Reviews", "Oversight Metric Reading", "Source Return Version"): "32",
}

OWNERSHIP_OVERRIDES = {}   # W5: every override was redundant once the resolver honors an explicit domain (CW-172)

# Row Ownership Rule (CD-289).
ROW_OWNERSHIP = {
    ("Oversight Reviews", "Oversight Metric Reading", "Metric Value"):
        "Row rule (CW-119 as amended, CW-119-AM1): by Oversight Metric. Excess Return 1, 3, 5 Years: computed here as the annualized "
        "32 Performance Return (Source Performance Return at Source Return Version) minus the annualized 32 Benchmark Return (Source "
        "Benchmark Return, version in its key) over the same period, in percentage points; owner of the inputs 32. Peer Percentile: read "
        "from 11 Peer Metric Snapshot.Category Percentile Rank (Source Peer Metric Snapshot). Tracking Error, Information Ratio: read "
        "from 32 Ex-Post Risk Statistic. Ex-Ante Tracking Error: read from 31 Portfolio Risk Measure. Fee versus Peers: read from 11 "
        "Fee Benchmark Result.Own Fee Percentile (Source Fee Benchmark Result). Turnover: read from 27 Financial Highlights.Portfolio "
        "Turnover Rate (fund level, fiscal year; sleeve turnover is a lever). Breach Count: computed here as the count of Source "
        "Investment Breaches, the 33 Investment Breach rows on rules included in Breach Count Guideline Set and detected in the review "
        "period. Style Drift and Active Share: mastered here (52 oversight computations) from 18 Portfolio Holding of the Sleeve "
        "Portfolio and 22 Index Constituent of the benchmark at Holdings As-Of Date; W5 shared candidate for 32.",
    ("Product Due Diligence", "Product Due Diligence Criterion Result", "Criterion Value"):
        "Row rule (CW-120): vendor fund data (14 dataset) for expense ratio, assets, liquidity and track record; peer percentiles from "
        "11 Peer Metric Snapshot; tracking difference from 32 Ex-Post Risk Statistic (Tracking Difference) where 32 measures the "
        "product, else 14; leverage or inverse features from 17 instrument terms. Sponsor Due Diligence rows carry no value (the result "
        "reads the 52 sponsor review).",
    ("Sub-Advisory Engagements", "Sub-Adviser Engagement", "Governing Fund Agreement"):
        "Row rule: filled (35 ADVA-) on Sleeve and Whole Fund scopes; blank on OCIO Mandate, Trust Mandate and Retail Managed Account "
        "Sleeve scopes, where Governing Contract (39) is the governing document. Engaged Fund and Board Approval Date follow the same rule.",
    ("Sub-Advisory Engagements", "Sub-Adviser Engagement", "Board Approval Date"):
        "Row rule (CD-237): Derived copy of the date of the earliest 35 Board Resolution linked through Resolution Subject Link to the "
        "Governing Fund Agreement (initial approval); continuances are read through the 35 Advisory Contract Renewal.",
}

SUMMARY = {
    "masters": (
        "Masters the research and oversight of external managers: external manager role profiles, key persons with background-check "
        "outcomes and strategies; manager searches, candidates and outcomes; due diligence questionnaire templates, manager due "
        "diligence reviews, scores and onsite visits; sub-adviser engagements, manager-of-managers hire conditions, guideline sets "
        "and their rule inclusions, compliance certifications; oversight reviews with metric thresholds and flags, watch status and "
        "Section 15(c) renewal submissions; oversight findings and remediation actions; third-party Product Due Diligence, criterion "
        "results, fund of funds use detail and product list status; manager terminations."
    ),
    "references": (
        "References parties from 02; sub-advisory agreements, renewals, exemptive relief and board approval dates from 35; contracts "
        "from 39; products, mandates, restrictions and model data from 01; instruments from 17; sleeve portfolios and holdings "
        "from 18; transition events from 12; committee decisions from 24; returns and ex-post statistics from 32; ex-ante risk from 31; compliance rules and "
        "breaches from 33; peer metric snapshots and fee benchmark results from 11; information statements from 13; fund turnover from 27; index constituents from 22; employees "
        "from 20; internal legal entities from 09; and vendor manager and fund data from 14."
    ),
}
