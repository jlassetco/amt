"""Home page copy of the Brokerage & Workplace Operations view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Brokerage & Workplace",
    "eyebrow": "",
    "title": "How brokerage and workplace operations data fits together",
    "lede": "The client back office: taking client orders to market, keeping the brokerage book of record, clearing, "
            "settling and safeguarding client assets, moving clients' money and sweeping their cash, and recordkeeping "
            "the workplace plans whose participants become direct clients. Written for the heads of brokerage operations, "
            "money movement and workplace solutions and the financial and operations principal.",
    "ladder": "Subject areas of the client back office, from the client order to the book of record, the cash and the "
              "plan, and the shared foundations, each with an accountable owner.",
    "bands": "The client operations value chain, from trading and clearing to safeguarding client assets, moving money "
             "and running the plans we recordkeep",
    "away": ["15", "29", "13"],
    "roles": [
        ("A head of brokerage operations",
         "Opens the Brokerage & Workplace Operations view: client orders, executions and confirmations beside the "
         "brokerage book of record, clearing, customer protection, account transfers and margin. Accounts and their "
         "elections flow in from Client & Advice, prices and instruments from Investment Operations and the Foundations "
         "band, and fund orders go out to transfer agency in Fund Operations. The capability view lists the brokerage and "
         "clearing capabilities, each with its mastering domain."),
        ("A head of money movement",
         "Reads Move money: ACH, wire, check and card activity, sweep programs and program banks, holds, returns and "
         "fraud. The flows show the standing instructions and accounts it reads from Client & Advice, the settlement cash "
         "of the brokerage book of record and the firm's own bank accounts in Corporate Functions."),
        ("A head of workplace solutions",
         "Starts from Workplace: the plans the firm recordkeeps, their participants, contributions and distributions, the "
         "plan sponsor relationship and the rollovers that bring participants into the direct business. The capability "
         "view shows rollover capture next to the rollover analysis that advice documents in Client & Advice."),
    ],
}
