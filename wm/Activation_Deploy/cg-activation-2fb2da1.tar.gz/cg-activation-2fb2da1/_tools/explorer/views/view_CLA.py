"""Home page copy of the Client & Advice view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Client & Advice",
    "eyebrow": "",
    "title": "How client and advice data fits together",
    "lede": "The center of the wealth manager: what the firm offers, the clients and households it serves and the "
            "accounts they hold, the goals, plans and recommendations behind its advice, the accounts it manages to "
            "models, the advisors who deliver advice, how clients are acquired, served and billed, and the conduct rules "
            "around every recommendation. Written for the heads of advice, client service, digital and product.",
    "ladder": "Subject areas of the client relationship, from the offering to the client, the account, the advice and the "
              "bill, and the shared foundations, each with an accountable owner.",
    "bands": "The client value chain, from what we offer and who we serve to how we advise, engage and serve them, with "
             "the pricing and conduct rules that protect them",
    "away": ["05", "06", "10", "12"],
    "roles": [
        ("A head of advice",
         "Opens the Client & Advice view: the client and household, the investor profile, the account and its program "
         "enrollment beside the plans, recommendations and best-interest evidence of advice and the models that managed "
         "accounts follow. The flows show the client holdings taken in from Brokerage & Workplace Operations and the "
         "model portfolios taken in from Investment. The capability view lists planning, recommendations, rollovers and "
         "managed accounts, each with the domain that masters its data."),
        ("A head of client service and digital",
         "Starts from How we engage and serve: acquisition and digital engagement, service interactions, statements, "
         "confirmations and tax documents. The flows show what service reads from the brokerage book of record and "
         "money movement, and what the intermediary channel and client economics in Distribution, Channels & Client "
         "Economics take from the client master. The capability view lists the service, communications and digital "
         "capabilities and the domains each one reads."),
        ("A head of product",
         "Reads What we offer: the funds and share classes, the advice programs and service tiers and the brokerage "
         "platform, and how the range changes. Fee schedules and conduct rules sit in the same view; fund data used by "
         "fund accounting and performance appears as flows out to Fund Operations and Investment Operations."),
    ],
}
