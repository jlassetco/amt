"""Home page copy of the Corporate Functions view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Corporate Functions",
    "eyebrow": "",
    "title": "How the data that runs the firm fits together",
    "lede": "Running the firm itself: the corporate books and the firm's own money and capital, including the "
            "broker-dealer's net capital, its people and workplace, risk, compliance and legal, suppliers and "
            "technology, and the corporate voice. Written for the chief financial officer, the chief operating officer "
            "and the heads of risk, compliance, legal, HR and technology.",
    "ladder": "Subject areas of the corporate functions and the shared foundations, each with an accountable owner.",
    "bands": "Running the firm, from its books, capital and people to the risk, compliance and legal controls around "
             "them, the suppliers and technology it depends on, and its reputation",
    "roles": [
        ("A chief operating officer",
         "Opens the Corporate Functions view: people, risk, compliance, legal, suppliers, technology and the workplace "
         "in one place. The flows show the employee master that every area references, and the trade errors, NAV "
         "errors, breaches and brokerage and money movement incidents that risk reads from the operating areas. The "
         "capability view lists the risk, legal, people and technology capabilities, each with its mastering domain."),
        ("A chief financial officer",
         "Reads the money and capital band: the corporate books, cash, funding, seed capital and the broker-dealer's net "
         "capital. The flows show the client fee revenue that comes in from Client & Advice and the prices, rates and "
         "fund NAVs the books and seed positions use. The capability view lists close, tax, planning and treasury "
         "capabilities."),
    ],
    "away": ["02", "01", "22", "25"],
}
