"""Home page copy of the Distribution, Channels & Client Economics view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Channels & Economics",
    "eyebrow": "",
    "title": "How channel and client economics data fits together",
    "lede": "Channels and what they earn: the intermediary and institutional channel that sells the firm's funds, models "
            "and mandates through third parties, client assets and net new assets across every channel, market "
            "intelligence, and revenue, cost to serve and profitability by client segment, channel and offering. Written "
            "for the heads of intermediary distribution, institutional advisory and client analytics and the head of "
            "client economics.",
    "ladder": "Subject areas of the channels and their economics, and the shared foundations, each with an accountable "
              "owner.",
    "bands": "From the intermediary and institutional channel to the client assets and flows every channel produces and "
             "what they earn and cost",
    "away": ["02", "01", "03", "08"],
    "roles": [
        ("A head of intermediary distribution",
         "Opens the Distribution, Channels & Client Economics view: partners, platforms and consultants, selling and "
         "platform agreements, model delivery and partner payments. The secondary channel is kept thin by design; funds "
         "and share classes flow in from Client & Advice and the model portfolios from Investment. The capability view "
         "lists the intermediary and institutional capabilities and the domains each one reads."),
        ("A head of client and channel analytics",
         "Reads Client assets and flows: client assets and net new assets by channel, advisor, campaign and plan, "
         "summarized from the brokerage book of record, transfer agency and plan recordkeeping. The flows show how much "
         "of the area's data is taken in from Client & Advice and Fund Operations; client revenue and cost to serve "
         "build on the same counts."),
        ("A head of institutional advisory",
         "Starts from the institutional channel: OCIO and institutional clients and plan sponsors, their service model, "
         "mandates and client reports. Performance, holdings and guideline results flow in from Investment Operations; "
         "institutional fee billing is mastered in Client & Advice."),
    ],
}
