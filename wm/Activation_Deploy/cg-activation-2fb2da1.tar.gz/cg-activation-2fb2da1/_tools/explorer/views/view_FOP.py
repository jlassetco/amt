"""Home page copy of the Fund Operations view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Fund Operations",
    "eyebrow": "",
    "title": "How fund operations data fits together",
    "lede": "The back office of the fund complex: keeping each fund's books and striking the NAV, safekeeping the fund "
            "assets, keeping the shareholder register and processing fund orders from the brokerage platform, the plans "
            "and intermediaries, and reporting to the fund boards and regulators. Written for the head of fund "
            "operations and the fund treasurer.",
    "ladder": "Subject areas of fund operations and the shared foundations, each with an accountable owner.",
    "bands": "The fund operations value chain, from the fund's books and assets through shareholder processing, with the "
             "board oversight and filings that govern the funds",
    "roles": [
        ("A head of fund operations",
         "Opens the Fund Operations view: fund accounting, fund custody, transfer agency and fund governance together. "
         "Accounts, client service and plan recordkeeping, which the wholesale sibling model runs here, now sit in Client & Advice "
         "and Brokerage & Workplace Operations and appear as flows; the brokerage platform's omnibus position is the "
         "largest account on the register. The capability view lists what the fund back office runs, from NAV to "
         "transfer agency oversight, each with its mastering domain."),
        ("A fund treasurer",
         "Follows the NAV from the holdings and approved prices taken in from Investment Operations through fund "
         "expenses, distributions, fund tax and NAV errors to board reporting, advisory and sub-advisory agreement "
         "renewals and fund filings. The capability view shows which domain masters each and that fair value oversight "
         "sits with Investment Operations."),
    ],
    "away": ["15", "13", "16"],
}
