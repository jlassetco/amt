"""Home page copy of the Investment view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Investment",
    "eyebrow": "",
    "title": "How investment data fits together",
    "lede": "The front office on its own: the research behind each investment view, the capital-market assumptions and "
            "allocations that shape the funds, mandates and advice models, the external managers the firm hires, the "
            "portfolio orders that carry decisions out and the votes and engagement that follow as an owner. Written for "
            "the chief investment officer and the heads of research, portfolio management, manager research and "
            "trading.",
    "ladder": "Subject areas of the front office, from research to stewardship, and the shared foundations, each with "
              "an accountable owner.",
    "bands": "The investment value chain, from forming a view to deciding, hiring managers, executing and acting as owner",
    "away": ["18", "01", "02"],
    "roles": [
        ("A chief investment officer",
         "Opens the Investment view: research, allocation and portfolio decisions, trading and stewardship in one chain, "
         "taking in positions from Investment Operations, funds and model definitions from Client & Advice and people "
         "from Corporate Functions, and handing portfolio orders to Investment Operations for settlement and oversight. "
         "Client orders are not here: they run in Brokerage & Workplace Operations. The capability view lists the "
         "research, portfolio management and trading capabilities the front office runs."),
        ("A head of manager research",
         "Reads Hire managers: manager search and due diligence, sub-advisory agreements and the guidelines given to each "
         "sub-adviser, oversight reviews and the approved list of third-party funds for the platform and advice models. "
         "The capability view shows how investment compliance codes those guidelines and how the fund boards in Fund "
         "Operations approve the sub-advisers."),
    ],
}
