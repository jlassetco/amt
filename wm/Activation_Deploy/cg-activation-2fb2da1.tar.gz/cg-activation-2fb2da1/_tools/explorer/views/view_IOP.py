"""Home page copy of the Investment Operations view of the explorer (read by build_explorer.py)."""

VIEW = {
    "short": "Investment Operations",
    "eyebrow": "",
    "title": "How investment operations data fits together",
    "lede": "The middle office: the investment book of record of the funds and institutional portfolios, and the "
            "pricing, settlement, risk, performance and compliance work that keeps it right and measures what the front "
            "office does, including the personal rates of return clients earn. Firms draw this boundary differently, so "
            "the view shows whichever of these the firm runs as investment operations.",
    "ladder": "Subject areas of investment operations, from pricing and recording positions to settling and checking "
              "them, and the shared foundations, each with an accountable owner.",
    "bands": "The middle-office value chain, from pricing and recording positions to settling trades and measuring and "
             "checking what the front office does",
    "away": ["25", "01", "02", "27"],
    "roles": [
        ("A head of investment operations",
         "Opens the Investment Operations view: its domains, the Foundations band, and the flows in from Client & Advice "
         "(funds, mandates, counterparties), Investment (portfolio trades) and Fund Operations (NAVs, custody), and out "
         "mainly to Fund Operations and Investment. The investment book of record here holds the funds' and mandates' "
         "positions; client holdings are kept in the brokerage book of record in Brokerage & Workplace Operations. The "
         "capability view, filtered to the area, lists the capabilities the function runs and the domains each one "
         "reads."),
        ("A head of performance measurement",
         "Reads Measure and control: fund, composite and benchmark returns and attribution beside the client account "
         "performance that turns the brokerage book of record into each household's personal rate of return. The "
         "capability view shows which domain masters each return and which domains it reads."),
    ],
}
