"""Exports the consolidated taxonomy to _tools/review_app/data.json for the interactive review page.

Usage: python export_review_data.py   (run after taxonomy_builder.py --all)
"""
import importlib, json, os, re, sys
from taxonomy_builder import CONTENT, CONSOLIDATION, Consolidated, load_consolidation, model, dd_label

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
scl = load_consolidation()
sys.path.insert(0, CONSOLIDATION)
dec = importlib.import_module("decisions")
mods = [Consolidated(importlib.import_module(f[:-3]), scl)
        for f in sorted(os.listdir(CONTENT)) if f.startswith("content_") and f.endswith(".py")]


def short(title):
    return re.sub(r" (Reference )?(Data )?Taxonomy$", "", title).replace("Investment Product", "Investment Product")


bds, attrs, hier, local_lists = [], [], [], {}
for m in mods:
    n = m.__name__.split("_")[1]
    ov = dict(m.META["overview"])
    bds.append({"n": n, "name": short(m.META["title"]), "purpose": ov.get("Purpose", ""), "scope": ov.get("Scope", ""),
                "workbook": m.META["output"]})
    local_lists[n] = {k: [v[0], [list(x) for x in v[1]]] for k, v in m.CL.items() if not k.startswith("Shared: ")}
    for f in model(m):
        hier.append({"bd": n, "level": "D", "code": f["code"], "domain": f["name"], "def": f["def"]})
        for o in f["objects"]:
            g = f"One row = {o['grain']}" + (f" ({o['kind']}" + (f" of {o['parent']}" if o["parent"] else "") + ")" if o["kind"] else "") if o["grain"] else ""
            hier.append({"bd": n, "level": "S", "code": o["code"], "domain": f["name"], "sub": o["name"],
                         "def": " ".join(x for x in [o["group_def"], g] if x)})
            for x in o["attrs"]:
                a = x["a"]
                attrs.append([n, x["id"], f["name"], o["name"], o["name"], a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7],
                              a[8], a[9] if len(a) > 9 else "", x["flag"], dd_label(x["owner"]) if x["owner"] and x["owner"] != n else "",
                              o["grain"], o["kind"], o["parent"]])

shared = [{"name": s["name"], "steward": s["steward"], "definition": s["definition"], "source": s["source"],
           "values": [list(v) for v in s["values"]], "members": [list(x) for x in s["members"]],
           "map": [[d, l, v, c] for (d, l, v), c in s["value_map"].items()]} for s in scl.SHARED]

rels = []
owner_of = {p: o for p, _, o, st, _ in dec.PREFIXES if not str(st).startswith("Retired")}
for m in mods:
    n = m.__name__.split("_")[1]
    for row in m.REL:
        text = " ".join(map(str, row))
        others = sorted({owner_of[p + "-"] for p in re.findall(r"\b([A-Z]{2,5})-", text) if owner_of.get(p + "-") not in (None, n)})
        rels.append([n, *row, others])

data = {
    "version": "v0.2 (consolidated)", "asOf": "2026-10-01",
    "businessDomains": bds, "attributes": attrs, "hierarchy": hier, "localLists": local_lists, "sharedLists": shared,
    "renames": [list(r) for r in scl.LOCAL_RENAMES], "notMerged": [list(r) for r in scl.NOT_MERGED],
    "decisions": dec.DECISIONS,
    "ownership": [[c, o, p, r, note] for c, o, p, r, note in dec.CONCEPT_OWNERSHIP],
    "prefixes": [list(p) for p in sorted(dec.PREFIXES)],
    "terms": [{"term": t["term"], "usages": [list(u) for u in t["usages"]], "rec": t["recommendation"]} for t in dec.TERM_CONFLICTS],
    "relationships": rels,
}
os.makedirs(os.path.join(HERE, "review_app"), exist_ok=True)
out = os.path.join(HERE, "review_app", "data.json")
with open(out, "w") as f:
    json.dump(data, f, separators=(",", ":"), ensure_ascii=False)
print("saved", out, f"{os.path.getsize(out)/1e6:.2f} MB", "| attributes", len(attrs), "| decisions", len(dec.DECISIONS),
      "| shared lists", len(shared))
