"""Resolves, for every attribute, whether it is mastered in its own Data Domain or references a concept mastered elsewhere.

The optional enrichment ROW_OWNERSHIP rules (CD-289) are documentation only: they say which rows of an attribute are
mastered here and which are copied from or owned by another Data Domain. resolve() never reads them, so the flag stays as
declared (one flag per attribute); the builders show the rule in the "Row Ownership Rule" column.

Rules, in order:
  0. record-level governance metadata (Data Owner, Data Steward, ...) is always mastered here
  1. enrichment/enrich_NN.py OWNERSHIP_OVERRIDES[(family, object, attribute)] = "NN" | "" (force a reference / force mastered here)
  2. data type "Reference (X)": owner from an explicit domain number written after a comma in X (e.g. "Reference (Personal
     Rate of Return, 32)"; wealth merge-prep ruling 4), else from an ID prefix in the example (e.g. PTY-0457 -> 02; prefixes of
     2 to 6 letters, retired prefixes never resolve), else from X matched to the concept ownership register, else from any
     other "(NN ...)" domain number in X; same-domain targets count as mastered here
  3. enrichment DERIVED[(family, object, attribute)] = "NN": a copied value mastered elsewhere ("Derived copy")
  4. otherwise mastered here
"""
import importlib, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "consolidation"))
sys.path.insert(0, os.path.join(HERE, "enrichment"))
_dec = importlib.import_module("decisions")
sys.path.insert(0, HERE)
from domains import DOMAIN_NUMBER, DD_NAMES  # noqa: E402
# Every status starting with "Retired" ("Retired", "Retired (sibling)") is skipped: a retired prefix never resolves (W2-W4 merge).
PREFIX_OWNER = {p.rstrip("-"): o for p, _, o, st, _ in _dec.PREFIXES if not str(st).startswith("Retired")}
PREFIX_PATTERN = re.compile(r"\b([A-Z]{2,6})-[A-Z0-9]")    # 2 to 6 letters (ESTATE-, CMASET-; W2-W4 merge)
EXPLICIT_DOMAIN = re.compile(r",\s*(\d{2})\b")             # "Reference (X, NN)": the explicit domain wins (ruling 4)
_norm = lambda s: re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()
CONCEPT_OWNER = {}
for c, o, p, refs, note in _dec.CONCEPT_OWNERSHIP:
    if note.startswith("Retired"):      # retired register rows (kept for traceability) never resolve a reference
        continue
    for name in re.split(r"\s*/\s*|\s*\(|\)", c):
        if name.strip():
            CONCEPT_OWNER.setdefault(_norm(name), o)
ALIASES = {"party": "02", "account": "15", "participant account": "15", "retirement plan": "02", "plan participant": "02", "employee": "20", "share class": "01", "product": "01",
           "strategy": "01", "benchmark": "01", "mandate": "01", "model portfolio": "01", "calendar": "09", "legal entity": "09",
           "org unit": "09", "geographic unit": "09", "agreement": "05",
           "data feed": "06", "campaign": "04", "content asset": "04", "event": "04", "opportunity": "05", "activity": "03",
           "compliance review": "08", "licence": "08", "license": "08", "dataset": "14", "data license agreement": "14",
           # Stage 1 masters (CD-151, CD-152, CD-154, CD-145, CD-156, CD-160)
           "instrument": "17", "portfolio": "18", "portfolio holding": "18", "tax lot": "18", "gl account": "19", "ledger": "19",
           "journal entry": "19", "taxonomy element": "21", "data product": "21", "metric definition": "21",
           "data quality rule": "21",
           # Stage 2 masters (CD-167, CD-168, CD-170, CD-180, CD-155, CD-186, CD-187, CD-194, CD-199, CD-203 to CD-205, CD-210).
           # 'Distribution' and 'order' stay unaliased: both are qualified everywhere (term conflicts Order, Distribution).
           "price": "22", "approved price": "22", "fx rate observation": "22", "fair value determination": "22",
           "research recommendation": "23", "investment decision": "24", "etf basket": "24",
           "trade order": "25", "block order": "25", "execution": "25", "trade allocation": "25",
           "settlement instruction": "26", "standing settlement instruction": "26",
           "fund journal entry": "27", "nav": "27", "share class nav": "27", "safekeeping account": "28", "fund order": "29",
           # W5 (2026-10-16): 'salesperson' (20) dropped: the firm's advisors are 03 Advisor and a wholesale salesperson is
           # gone with 07; bare 'transaction' and 'position' (06) dropped: positions are 49 Client Holding, 18 Portfolio
           # Holding, 06 Fund Shareholder Position and 29 Share Register Balance, transactions 49, 29 and 16 (CW-007,
           # CW-122), so a bare word names no one master. 06 Transaction (TXN-, the conformed flow record) still resolves
           # through CONCEPT_OWNERSHIP and its prefix.
           # W2-W4 merge: 'territory' (07) and the 30 aliases (commitment, investor commitment, capital account, investor
           # capital account, capital call, deal) were deleted with their domains (CW-907, CW-930); 'opportunity' moved
           # 03 -> 05 with the restored Sales Opportunity (CW-134).
           # Stage 3 masters (CD-241). Bare 'resolution' and 'filing' stay unaliased: both are qualified everywhere (term
           # conflicts Resolution, Filing); 'board', 'breach', 'vote' and 'engagement' follow the term conflict entries.
           "risk limit": "31", "risk limit exceedance": "31", "exceedance": "31",
           "performance return": "32", "composite membership": "32",
           "compliance rule": "33", "investment breach": "33", "breach": "33",
           "vote": "34", "vote instruction": "34", "engagement": "34", "exclusion list": "34",
           "sustainability exclusion list": "34",
           "board": "35", "fund governing body": "35", "board resolution": "35", "fund regulatory filing": "35",
           "regulatory filing": "35", "advisory agreement": "35", "fund advisory agreement": "35",
           "product proposal": "36", "change initiative": "36", "product change initiative": "36",
           # Stage 4 masters (CD-283). Bare 'engagement' stays 34 and bare 'event' stays 04 (term conflicts Engagement, Event).
           "risk": "37", "enterprise risk": "37", "control": "37", "incident": "37", "operational incident": "37",
           "loss event": "37", "operational loss event": "37", "risk issue": "37", "model": "37", "model inventory entry": "37",
           "audit": "37", "audit engagement": "37", "audit finding": "37",
           "policy": "38", "restricted list": "38", "firm restricted list": "38", "restricted list entry": "38",
           "examination": "38", "regulatory examination": "38", "filing": "38", "firm regulatory filing": "38",
           "entity authorization": "38", "regulatory obligation": "38", "aml case": "38", "mnpi escalation": "38",
           "conflict of interest": "38", "trade surveillance alert": "38",
           "contract": "39", "legal matter": "39", "legal hold": "39", "resolution": "39", "corporate resolution": "39",
           "corporate governing body": "39",
           "supplier": "40", "supplier engagement": "40", "purchase order": "40", "outsourcing arrangement": "40",
           "application": "41", "it incident": "41", "project": "41", "it service": "41",
           "brand": "42", "publication": "42", "corporate publication": "42", "press release": "42",
           "bank account": "43", "corporate bank account": "43", "seed": "43", "seed capital commitment": "43",
           "lease": "44", "site": "44", "site profile": "44", "expense": "44", "expense report": "44"}


def load_enrichment(n):
    try:
        return importlib.import_module(f"enrich_{n}")
    except ModuleNotFoundError:
        return None


GOVERNANCE_METADATA = {"Data Owner", "Data Steward", "System of Record", "Record Effective From", "Record Effective To",
                       "Last Updated Timestamp", "Data Quality Status", "Data Classification"}


def resolve(n, family, obj, a, enr=None):
    """Return (flag, owner_domain) for attribute tuple a in data domain n."""
    key = (family, obj, a[0])
    if a[0] in GOVERNANCE_METADATA:          # record-level governance metadata is always local to the record
        return "Mastered here", n
    if enr is not None and key in getattr(enr, "OWNERSHIP_OVERRIDES", {}):
        o = enr.OWNERSHIP_OVERRIDES[key]
        return ("Reference", o) if o and o != n else ("Mastered here", n)
    dtype, example = a[3], str(a[5])
    if dtype.startswith("Reference"):
        target = re.sub(r"^Reference\s*\(?|\)?\s*(\(multi\))?$", "", dtype).strip()
        owner = None
        m = EXPLICIT_DOMAIN.search(target)
        if m and m.group(1) in DD_NAMES:
            owner = m.group(1)
        m = None if owner else PREFIX_PATTERN.search(example)
        if m and m.group(1) in PREFIX_OWNER:
            owner = PREFIX_OWNER[m.group(1)]
        if not owner:
            for part in re.split(r"\s*/\s*|\s*\+\s*|,", target):
                t = _norm(re.sub(r"\(.*?\)", "", part))
                owner = CONCEPT_OWNER.get(t) or ALIASES.get(t)
                if owner:
                    break
        if not owner:
            m = DOMAIN_NUMBER.search(target)
            owner = m.group(1) if m else None
        if owner and owner != n:
            return "Reference", owner
        if owner == n:
            return "Mastered here", n
        return "Unresolved reference", ""
    if enr is not None and key in getattr(enr, "DERIVED", {}):
        return "Derived copy", enr.DERIVED[key]
    return "Mastered here", n
