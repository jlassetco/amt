#!/usr/bin/env bash
# Publish the Taxonomy Explorer to github.com/jlassetco/amt. Wrapper around publish_to_amt.sh.
#   _tools/publish_explorer.sh wm/WM_Taxonomy_Explorer.html   (wealth-manager model)
#   _tools/publish_explorer.sh Taxonomy_Explorer.html         (asset-manager model, repo root)
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
exec "$here/publish_to_amt.sh" "$here/../00_Program/Taxonomy_Explorer.html" "${1:?usage: publish_explorer.sh <path in amt>}"
