#!/usr/bin/env bash
# Publish one file, and nothing else, to github.com/jlassetco/amt (branch main).
#   _tools/publish_to_amt.sh <local file> <path in amt>
# Examples:
#   _tools/publish_to_amt.sh 00_Program/Taxonomy_Explorer.html wm/WM_Taxonomy_Explorer.html
#   _tools/publish_to_amt.sh 00_Program/Wealth_Manager_Foundational_Talktrack.pptx wm/Wealth_Manager_Foundational_Talktrack.pptx
# Only the named file is written; everything else in amt is left as it is.
# amt is a PUBLIC repo: check the document for internal framing before publishing.
set -euo pipefail

REMOTE="https://github.com/jlassetco/amt.git"
BRANCH="main"
SRC="${1:?usage: publish_to_amt.sh <local file> <path in amt>}"
DEST="${2:?usage: publish_to_amt.sh <local file> <path in amt>}"

[ -f "$SRC" ] || { echo "Not found: $SRC" >&2; exit 1; }
SRC="$(cd "$(dirname "$SRC")" && pwd)/$(basename "$SRC")"

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

git clone -q --depth 1 --branch "$BRANCH" "$REMOTE" "$tmp"
cd "$tmp"
mkdir -p "$(dirname "$DEST")"
cp "$SRC" "$DEST"
git add -- "$DEST"

if git diff --cached --quiet; then
  echo "amt $DEST is already up to date."
  exit 0
fi

git commit -qm "Update $DEST ($(date +%Y-%m-%d))"
git push -q origin "$BRANCH"
echo "Pushed $DEST to $REMOTE ($BRANCH)."
