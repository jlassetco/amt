# Semantic model definition contract

A **semantic model** publishes data products to analytical tools (BI dashboards, Excel, AI assistants) as one governed set of tables, joins, metrics, hierarchies and access rules. It exposes certified numbers; it never defines a concept the taxonomy or a product spec does not already define.

- **Register:** `register.py` lists the models (`MODELS`), the products each one publishes, the certified metrics and who owns them (`CERTIFIED`), and the products proposed but not yet approved for the semantic layer (`PROPOSED`).
- **Definitions:** `models/sm_nn_<name>.py`, one per model, each defining `MODEL = dict(...)`.
- **Example:** `models/sm_04_institutional_retirement.py` grew out of `examples/institutional_book.yaml`; read that example and its walkthrough (`examples/institutional_book.md`) for the reasoning behind each choice.
- **Validate:** `python semantic_model/sm_model.py` from `_tools/` (or `... sm_model.py SM-20` for one model). Fix every ERROR; fix or justify every WARNING in `open_decisions`.

## Fields

| Field | Type | Content |
|---|---|---|
| `id` | str | `SM-nn`, as in the register |
| `status` | str | `Draft` until the model owner confirms it, then `Confirmed` |
| `description` | str | 2–3 sentences: who uses the model and for what kind of question |
| `questions` | list[str] | 3–6 business questions the model answers **across rows** (many advisors, clients, partners or periods) |
| `tables` | list[dict] | The product entities the model reads (below) |
| `shared` | list[str] | SM-00 dimensions this model joins to, as `"DP-nnn/<Entity>"` (an entity of that SM-00 product's logical model) |
| `relationships` | list[dict] | `dict(frm=, to=, on=, type=, warning="")`. `frm` / `to` are table names in this model or entries of `shared`. `type` is `many-to-one`, `one-to-one` or `many-to-many`. A `many-to-many` join needs a `warning` saying what overcounts. |
| `hierarchies` | list[dict] | `dict(name=, levels=["table.dimension", ...])`, top level first |
| `metrics` | list[dict] | Below |
| `excluded` | list[tuple] | `(product, measure name, reason)` for every product measure deliberately not published |
| `access` | dict | `dict(classification=, roles=[dict(role=, rows=, columns=, hidden=[dimension names])])` |
| `verified_questions` | list[dict] | 3–6 `dict(question=, answer=, sql="")`. `answer` names the metrics, dimensions and filters used; `sql` is optional |
| `cannot_answer` | list[dict] | `dict(question=, why=, gap="GAP-NN-###" or "")` |
| `open_decisions` | list[str] | Decisions the product owners still need to make |

### Tables

```python
dict(name="flows_aum",                # snake_case, unique in the model
     product="DP-008",                 # see "Which products a table may read"
     entity="Measure Value",           # an entity name in that product's logical model (data_models/)
     kind="Fact",                      # Fact | Dimension | Bridge
     grain="client x share class x month x snapshot",
     always_filter=["dimension_type = 'Institutional Client'"],   # filters users cannot remove (optional)
     default_filter="",                # a filter users can change, e.g. the latest as-of date (optional)
     dimensions=[dict(name="client_type", attr="Institutional Client Type", note="")],
     facts=[dict(name="ending_aum", attr="Ending AUM")],
     hidden=[("Firm AUM with Client", "A copy of DP-008 Ending AUM; AUM metrics read DP-008.")])
```

- `attr` is an attribute of the entity in the product's logical model, exactly as named there. Product measures appear on the entity that holds them (`measures=True` in the model), so a row-level measure such as a flag or score can be a dimension.
- **Which products a table may read:** the model's own products, its `PROPOSED` products, SM-00 products (for dimensions), and the source products of `CERTIFIED` metrics (DP-008, DP-012) when a model needs their fact to slice a referenced metric.
- Expose only what a cross-row question needs. Names of people belong in a dimension only when a role needs them, and the access rules must hide them from everyone else.

### Metrics

```python
dict(name="Share of Investable Assets %", aggregation="ratio",
     numerator="[Ending AUM] for clients whose assets_as_of_date is within 12 months",
     denominator="sum(client.total_investable_assets) for the same clients",
     source=("DP-092", "Share of Investable Assets %"),
     description="One sentence a business reader understands.",
     time_rule="", note="")
dict(name="Net Flows", ref="SM-20/Net Flows")           # a certified metric owned by another model
```

- `aggregation` is one of `register.AGGREGATION`: `additive`, `semi_additive`, `ratio`, `count_distinct`, `non_additive`.
  - `ratio` needs `numerator` and `denominator`; every other aggregation needs `expr`.
  - `semi_additive` needs a `time_rule` (usually "last period in the selected range").
- `source` is `(product, name)`, where `name` is a measure in the product's spec or an attribute in its spec `inputs`. It records which product definition the metric publishes. A metric that combines products names the main one, and says what it combines in `note`.
- **Certified metrics are defined once.** A name in `register.CERTIFIED` is defined (with `source` matching the register) only in its owning model; every other model uses `ref="SM-nn/<name>"`. Don't redefine a certified number under another name either: "Firm AUM" in a client model is a `ref` to `SM-20/Client Assets`, sliced by client.
- **One name, one definition.** No two models define a metric with the same name. When two products define the same idea differently (for example Wallet Share % in DP-017, DP-018 and DP-049), publish one, normally from the product that owns the idea, and record the conflict in `open_decisions`.

### Coverage

Every measure in the spec of every product the model publishes must be accounted for exactly once:
- as a metric `source`,
- as a dimension or fact `attr` of a table that reads that product,
- or in `excluded`, with a reason.

The validator lists any measure left unaccounted for.

## Rules

1. Do not edit product specs, logical models or the register. Record what they should change in `open_decisions`.
2. Do not invent formulas. A metric restates the product measure's formula as an aggregation rule; if the spec's formula cannot be aggregated, say so and choose `non_additive`.
3. Keep the double-counting traps closed. DP-008 rows exist at many dimension grains, period types and snapshots: any table reading it pins `dimension_type`, `period_type` and `snapshot_status = 'Locked'` in `always_filter`.
4. Write for a business reader. Use US spelling and plain sentences, and keep the taxonomy's terms: Data Domain, data product, advisor (not adviser, except in official UK names).

**Retired models (wealth-manager branch).** `register.PENDING` is empty since WP2: SM-01 to SM-07 and SM-13 retired (CW-041, CW-209, CW-930) once SM-20 Client Assets & Flows and SM-28 Client Economics took the certified families; the register lists them as history. A model held in `PENDING` (the mechanism stays for future re-scopes) keeps its file in `models/` but is not validated, built or published, and a live model that references a metric defined in a pending model fails.
