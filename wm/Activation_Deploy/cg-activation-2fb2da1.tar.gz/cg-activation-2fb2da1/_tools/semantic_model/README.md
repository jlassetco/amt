# Semantic models

The semantic layer publishes data products to dashboards, Excel and AI assistants. It is split into subject-area **semantic models** that share one set of dimensions. Each metric is defined once and points to the product and taxonomy definition it publishes.

| File | Contents |
|---|---|
| `register.py` | The models (SM-00 shared dimensions; the carried SM-08 to SM-12 and SM-14 to SM-17; the wealth subject areas SM-20 to SM-31), the products each publishes, the certified metrics with their owning model, and the retired SM-01 to SM-07 and SM-13 as history |
| `CONTRACT.md` | The definition standard for a model |
| `models/sm_nn_<name>.py` | One hand-finished definition per model: tables, joins, hierarchies, metrics, access, verified questions |
| `sm_model.py` | Validates the register and models against the product specs, logical models and gap register |
| `show_product.py` | Prints a product's spec and logical model in the exact names the validator checks, for authors |
| `build_semantic_model.py` | Generates `out/`: per-product starting drafts, the shared-dimension spine, the sizing report and the finished models as YAML |
| `examples/` | The institutional-book worked example and its walkthrough (the pattern the retired SM-04 grew out of; SM-27 carries the institutional channel now) |

```bash
python semantic_model/sm_model.py               # validate every model (or pass SM-20 for one)
python semantic_model/show_product.py DP-016    # spec + logical model for an author
python semantic_model/build_semantic_model.py   # regenerate out/
python build_explorer.py                        # publish the models in the explorer (#/semantic)
```

## Rules that hold across models

- **Every product that lists the BI semantic model as a delivery belongs to exactly one model.** A product proposed for the layer but not yet approved in its spec is listed in `register.PROPOSED` and raises a warning.
- **Certified metrics are defined once.** The client-asset and flow family lives in SM-20 (from DP-008), client fee revenue in SM-28 (from DP-012), Personal Rate of Return in SM-08 (DP-145) and Firm AUM with its slices in SM-11 (DP-241). Other models use `ref="SM-20/Net Flows"`.
- **One name, one definition.** No two models define a metric with the same name. The explorer's metric glossary also lists measure names that more than one product spec defines, so owners can align them.
- **Every product measure is accounted for.** It is a metric, a dimension, or excluded with a reason.

## In the explorer

`build_explorer.py` publishes the models when they validate:
- **Semantic models** in the top navigation (`#/semantic`): the shared dimensions and the subject-area models
- a page per model: products, metrics and how each adds up, tables with their always-on filters, joins, hierarchies, access, verified questions and questions it cannot answer yet
- the **metric glossary** (`#/semantic/metrics`)
- product cards and pages that link to the model each product is published in
- domain pages that list the models publishing them

Open decisions in the model files are working notes and stay out of the explorer.

## Generated outputs in `out/`

- `products/DP-nnn.yaml`: the generated starting draft for each product, before a person's decisions
- `spine.yaml`: the shared dimensions and the products that use them
- `models/SM-nn.yaml`: the finished models, as a tool would import them
- `SIZING.md`: the size of the job, the dashboards outside the semantic layer for owner review, and a per-model summary
