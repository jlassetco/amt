"""SKETCH. Drafts a tool-neutral semantic model from the data product specs and logical models, and sizes the work of
building one. Nothing here is hand-authored: every table, join, metric and access rule is derived from data_products/
and data_models/, so the draft shows how much of a semantic model the catalog already defines and how much needs a
human decision.

Usage (from _tools/):  python semantic_model/build_semantic_model.py
Writes semantic_model/out/: spine.yaml (shared conformed dimensions), products/DP-nnn.yaml (one per product published
through the BI semantic model) and SIZING.md.
"""
import os, re, shutil, sys
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(HERE)
for p in (TOOLS, os.path.join(TOOLS, "data_models"), os.path.join(TOOLS, "data_products")):
    sys.path.insert(0, p)
sys.dont_write_bytecode = True

import dm_model  # noqa: E402
import framework as fw  # noqa: E402

OUT = os.path.join(HERE, "out")
SEM = "BI semantic model"
REG = {p[0]: p for p in fw.PRODUCTS}

# How a measure aggregates decides whether the semantic layer has work to do. Rules are tried in order on the
# measure name and definition; the first match wins.
AGG = [
    ("row_attribute", "flag", lambda n, d: re.match(r"(Y|High) (when|for|where)\b", d) or re.search(r"\b(Flag|Indicator)$", n)),
    ("row_attribute", "score, rank or band", lambda n, d: re.search(r"\b(Rank|Percentile|Score|Tier|Band|Grade|Segment|Status)\b", n)
     or d.startswith("0-100")),
    ("row_attribute", "date or duration", lambda n, d: re.search(r"^(Days|Next|Last|Tenure|Age)\b|\(Years\)|\(months\)|\bDate$"
                                                                 r"|Cycle Time|Turnaround|Lag Days|Months$", n)),
    ("non_additive", "mean or median", lambda n, d: re.match(r"(Mean|Median|Average)\b", d) or re.search(r"\b(Median|Average|Mean)\b", n)),
    ("ratio", "ratio", lambda n, d: re.search(r"%|\b(Rate|Ratio|Margin|Yield|Share|Penetration|Utilization|per)\b|\(bps\)", n)
     or re.search(r"[A-Za-z)] / [A-Za-z(]", d)),
    ("count_distinct", "distinct count", lambda n, d: re.search(r"\b[Dd]istinct\b", d[:60])),
    ("semi_additive", "balance at a point in time", lambda n, d: re.search(r"\b(AUM|Assets|Balance|Outstanding|Headcount|Accrued|Exposure|Backlog|Open)\b", n)),
    ("additive", "difference of sums", lambda n, d: re.search(r"\b(Variance|Gap|Difference|Impact|Movement|Mismatch|Headroom|Outturn)\b", n)),
    ("additive", "sum or count", lambda n, d: re.match(r"(Sum|Count|Number|Total)\b", d) or re.search(r"\b(Count|Amount|Cost|Revenue|Sales|Flows?|Expense|Payments?)\b", n)),
]
AGG_RULE = {
    "additive": "sum",
    "semi_additive": "sum across dimensions; last value over time",
    "ratio": "sum(numerator) / sum(denominator), never an average of row ratios",
    "count_distinct": "count distinct at query time from detail rows; not summable",
    "non_additive": "recompute from detail rows, or publish only at the product grain",
    "row_attribute": "a column on the row, filtered and grouped by; not aggregated",
    "review": "needs a decision",
}
CERTIFIED = re.compile(r"\bcertified\b|\bfrom (DP-\d{3})\b|\b(DP-\d{3})\b", re.I)


SLASHED = []   # taxonomy names containing " / " ("Prospect / Client"); set in main, longest first


def classify(name, definition):
    # A name like "Revenue Share Class / Mandate" is not a division; blank such names out before testing for one.
    plain = definition
    for s in SLASHED:
        plain = plain.replace(s, "X")
    for cls, why, test in AGG:
        if test(name, plain):
            return cls, why
    return "review", "no rule matched"


def snake(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


def table(pid, ent):
    return f"{snake(pid)}.{snake(ent)}"      # placeholder physical name; the logical models carry none


def hierarchies(spec):
    """Hierarchy candidates from spec dimensions written as 'X hierarchy (level, level)'."""
    out = []
    for d in spec["dimensions"]:
        m = re.search(r"(.*?hierarch\w*)\s*\(([^)]+)\)", d, re.I)
        if m:
            out.append({"name": m.group(1).strip(), "levels": [x.strip() for x in m.group(2).split(",")]})
    return out


def build_product(pid, spec, model):
    """One product's draft: tables, joins, metrics and access rules."""
    ents = {e["name"]: e for e in model["entities"]}
    home = next((e for e in model["entities"] if any(a["derived"] for a in e["attrs"])), None)
    tables, dims_conformed = [], []
    for e in model["entities"]:
        if e["conformed"]:
            dims_conformed.append({"name": e["name"], "spine": f'{e["conformed"][0]} {e["conformed"][1]}'})
            continue
        kind = e["role"] if e["role"] != "Entity" else ("Fact" if e is home else "Dimension")
        cols = [a for a in e["attrs"] if not a["derived"]]
        tables.append({"name": e["name"], "kind": kind, "table": table(pid, e["name"]), "grain": e["grain"] or None,
                       "key": [a["name"] for a in cols if a["pk"]],
                       "columns": len(cols),
                       "personal_data_columns": [a["name"] for a in cols if a["pii"]] or None})
    joins = [{"from": r["child"], "to": r["parent"], "on": r["fk"], "type": r["card"],
              **({"optional": True} if r["optional"] else {})} for r in model["relationships"]]
    metrics, counts, reuse = [], Counter(), []
    for name, definition, _ in spec["measures"]:
        cls, why = classify(name, definition)
        counts[cls] += 1
        refs = sorted({m for g in CERTIFIED.findall(definition) for m in g if m.startswith("DP-") and m != pid})
        certified = bool(re.search(r"\bcertified\b", definition, re.I))
        m = {"name": name, "aggregation": cls, "rule": AGG_RULE[cls], "on": home["name"] if home else None,
             "definition": definition}
        if refs or certified:
            m["source"] = "reuse certified metric from " + (", ".join(refs) if refs else "an upstream product")
            reuse.append(name)
        metrics.append(m)
    dims_text = " ".join(spec["dimensions"]).lower()
    access = {"classification": spec["classification"], "personal_data": spec["pii"] == "Y"}
    if spec["pii"] == "Y":
        access["row_security"] = "required: restrict rows to the viewer's own scope (e.g. territory, firm, client)"
        access["hide_from_broad_roles"] = sorted({a["name"] for e in model["entities"] for a in e["attrs"] if a["pii"]}) or \
            ["(no taxonomy attribute flagged PII; confirm which columns identify a person)"]
    if "snapshot" in dims_text or any(d["name"] == "Snapshot" for d in dims_conformed):
        access["default_filter"] = "one snapshot version per query (preliminary or locked), never both"
    p = REG[pid]
    doc = {"product": f"{pid} {p[1]}", "tier": p[2], "type": p[3], "wave": fw.WAVE.get(pid, "Wave 1"), "owner": p[5],
           "grain": spec["grain"], "tables": tables, "conformed_dimensions": dims_conformed, "joins": joins,
           "hierarchies": hierarchies(spec) or None, "metrics": metrics, "access": access}
    return doc, counts, reuse


# ---------------------------------------------------------------------------------------------------------------- YAML
def _scalar(v):
    if v is None: return "null"
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, (int, float)): return str(v)
    if isinstance(v, (set, frozenset)):   # e.g. the validator's _cols: sorted so every build writes the same text (Step 5)
        v = "{" + ", ".join(repr(x) for x in sorted(v, key=str)) + "}"
    s = str(v)
    if s == "" or re.search(r"[:#\[\]{},&*!|>'\"%@`]|^[-?\s]|\s$", s) or s.lower() in ("yes", "no", "true", "false", "null", "y", "n"):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return s


def yaml(v, ind=0):
    pad = "  " * ind
    if isinstance(v, dict):
        lines = []
        for k, x in v.items():
            if x is None: continue
            if isinstance(x, (dict, list)) and x:
                lines.append(f"{pad}{k}:"); lines.append(yaml(x, ind + 1))
            else:
                lines.append(f"{pad}{k}: {_scalar(x) if not isinstance(x, (dict, list)) else '[]'}")
        return "\n".join(lines)
    if isinstance(v, list):
        lines = []
        for x in v:
            if isinstance(x, dict):
                body = yaml(x, ind + 1).split("\n")
                lines.append(f"{pad}- {body[0].lstrip()}"); lines += body[1:]
            elif isinstance(x, list):
                lines.append(f"{pad}- [" + ", ".join(_scalar(y) for y in x) + "]")
            else:
                lines.append(f"{pad}- {_scalar(x)}")
        return "\n".join(lines)
    return pad + _scalar(v)


def write(path, header, doc):
    with open(path, "w", encoding="utf-8") as f:
        f.write(header + yaml(doc) + "\n")


# ---------------------------------------------------------------------------------------------------------------- main
def main():
    models, errs, _ = dm_model.validate()
    if errs:
        raise SystemExit("Logical model validation failed:\n  " + "\n  ".join(errs[:20]))
    objs, specs, _, _, _ = dm_model.load_all()
    SLASHED[:] = sorted({n for (_, on), o in objs.items() for n in [on, *o["attrs"]] if " / " in n}, key=len, reverse=True)
    order = [p[0] for p in fw.PRODUCTS if p[0] in specs and not dm_model.dp_model.is_pending(p[0])]   # pending WP0 re-scope (CW-041) left out
    scope = [pid for pid in order if SEM in specs[pid]["delivery"] and pid in models]
    if os.path.isdir(OUT):
        shutil.rmtree(OUT)
    os.makedirs(os.path.join(OUT, "products"))
    gen = "# GENERATED SKETCH by semantic_model/build_semantic_model.py. Do not edit; change the specs or models.\n"

    docs, agg, reuse_by = {}, Counter(), {}
    spine_use = defaultdict(list)
    for pid in scope:
        doc, counts, reuse = build_product(pid, specs[pid], models[pid])
        docs[pid], reuse_by[pid] = doc, reuse
        agg.update(counts)
        for d in doc["conformed_dimensions"]:
            spine_use[d["spine"]].append(pid)
        write(os.path.join(OUT, "products", f"{pid}.yaml"), gen, doc)

    # The spine: each conformed dimension once, with the attributes its foundational model gives it.
    spine = []
    for key, users in sorted(spine_use.items(), key=lambda kv: -len(kv[1])):
        src, ent = key.split(" ", 1)
        e = next(x for x in models[src]["entities"] if x["name"] == ent)
        cols = [a for a in e["attrs"] if not a["derived"] and a["type"] != "Foreign key"]
        spine.append({"dimension": ent, "source_product": f"{src} {REG[src][1]}", "table": table(src, ent),
                      "key": [a["name"] for a in cols if a["pk"]], "attributes": [a["name"] for a in cols],
                      "personal_data_columns": [a["name"] for a in cols if a["pii"]] or None,
                      "used_by": len(users), "products": users})
    write(os.path.join(OUT, "spine.yaml"), gen, {"conformed_dimensions": spine})
    sizing(specs, order, scope, docs, agg, reuse_by, spine)
    print(f"wrote semantic_model/out: {len(scope)} product drafts, {len(spine)} spine dimensions, SIZING.md")
    publish_models(gen)


def publish_models(gen):
    """Write each hand-finished model in models/ as YAML (the form a semantic-layer tool takes in) and add a per-model
    summary to SIZING.md. Skipped while the models do not validate."""
    import sm_model, register as rg
    models, _, _, _, errs, _ = sm_model.load()
    if errs:
        print(f"models not published: {len(errs)} validation error(s); run semantic_model/sm_model.py")
        return
    os.makedirs(os.path.join(OUT, "models"), exist_ok=True)
    L = ["\n## Semantic models (hand-finished)\n",
         "| Model | Status | Products | Tables | Metrics defined | Certified refs | Ratios | Excluded measures | Open decisions |",
         "|---|---|---|---|---|---|---|---|---|"]
    held = [m[0] for m in rg.MODELS if m[0] in sm_model.PENDING]     # pending WP0 re-scope (CW-041): not published
    for mid, name, owner, fns, prods, purpose in rg.MODELS:
        if mid in sm_model.PENDING:
            continue
        m = models[mid]
        doc = {k: v for k, v in m.items() if not k.startswith("_")}
        doc = {"model": f"{mid} {name}", "owner": owner, "products": prods + rg.PROPOSED.get(mid, []), **doc}
        plain = lambda v: {k: plain(x) for k, x in v.items()} if isinstance(v, dict) else \
            [plain(x) for x in v] if isinstance(v, (list, tuple)) else v
        doc = plain(doc)
        write(os.path.join(OUT, "models", f"{mid}.yaml"), gen.replace("Do not edit; change the specs or models.",
              "Do not edit; change models/ instead."), doc)
        own = [x for x in m["metrics"] if not x.get("ref")]
        L.append(f"| {mid} {name} | {m['status']} | {len(prods) + len(rg.PROPOSED.get(mid, []))} | {len(m['tables'])} | {len(own)} | "
                 f"{len(m['metrics']) - len(own)} | {sum(x['aggregation'] == 'ratio' for x in own)} | {len(m.get('excluded', []))} | "
                 f"{len(m.get('open_decisions', []))} |")
    if held:
        L.append(f"\nNot published: {', '.join(held)}, pending WP0 re-scope (CW-041).")
    with open(os.path.join(OUT, "SIZING.md"), "a", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    # Open decisions are working notes the explorer leaves out; this is the owners' review list.
    D = ["# Semantic model open decisions (generated)\n",
         "Decisions the model and product owners still need to make before a model moves from Draft to Confirmed. "
         "Generated from `semantic_model/models/`; rebuild rather than edit.\n"]
    for mid, name, owner, fns, prods, purpose in rg.MODELS:
        if mid in sm_model.PENDING:
            continue
        m = models[mid]
        D.append(f"## {mid} {name} ({m['status']})\n\nOwner: {owner}\n")
        D += [f"{i}. {x}" for i, x in enumerate(m.get("open_decisions", []), 1)] + [""]
    with open(os.path.join(OUT, "OPEN_DECISIONS.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(D))
    print(f"wrote semantic_model/out/models: {len(models)} models; OPEN_DECISIONS.md: "
          f"{sum(len(m.get('open_decisions', [])) for m in models.values())} decisions")


def sizing(specs, order, scope, docs, agg, reuse_by, spine):
    n_metrics = sum(agg.values())
    needs = n_metrics - agg["row_attribute"]
    waves = ["Wave 1", "Wave 2", "Wave 3", "Wave 4"]
    by_wave = {w: [p for p in scope if docs[p]["wave"] == w] for w in waves}
    # spine dimensions each wave needs for the first time
    seen, new_dims = set(), {}
    for w in waves:
        need = {d["spine"] for p in by_wave[w] for d in docs[p]["conformed_dimensions"]}
        new_dims[w] = sorted(need - seen); seen |= need
    top = [s for s in spine if s["used_by"] >= 5]
    covered = [p for p in scope if {d["spine"] for d in docs[p]["conformed_dimensions"]} <= {f'{s["source_product"].split()[0]} {s["dimension"]}' for s in top}]
    direct = [p for p in order if p not in scope]
    review = [(p, m["name"]) for p in scope for m in docs[p]["metrics"] if m["aggregation"] == "review"]
    reused = sum(len(v) for v in reuse_by.values())
    pii = [p for p in scope if docs[p]["access"]["personal_data"]]
    multi_fact = [p for p in scope if sum(t["kind"] == "Fact" for t in docs[p]["tables"]) > 1]
    pct = lambda a, b: f"{round(100 * a / b)}%" if b else "0%"

    L = []
    w = L.append
    w("# Semantic model sizing (generated sketch)\n")
    w("Generated by `semantic_model/build_semantic_model.py` from the product specs and logical models. Figures change "
      "when the catalog changes; rebuild rather than edit.\n")
    w("## Scope\n")
    w(f"- **{len(scope)} of {len(order)} products** list *{SEM}* as a delivery channel "
      f"({sum(REG[p][2] == 'Foundational' for p in scope)} foundational, {sum(REG[p][2] != 'Foundational' for p in scope)} consumer-aligned).")
    w(f"- **{len(direct)} products never touch it.** Their consumers are systems or processes (payroll, CRM, regulators, "
      "files), so they go by direct delivery.\n")
    w("## What the catalog already supplies\n")
    w("| Semantic model element | Source in the catalog | Generated |")
    w("|---|---|---|")
    w(f"| Tables and keys | Logical model entities | {sum(len(d['tables']) for d in docs.values())} product tables + {len(spine)} shared dimensions |")
    w(f"| Joins | Logical model relationships | {sum(len(d['joins']) for d in docs.values())} |")
    w(f"| Metrics and formulas | Spec measures | {n_metrics} |")
    w(f"| Hierarchies | Spec dimensions naming a hierarchy | {sum(len(d['hierarchies'] or []) for d in docs.values())} candidates |")
    w(f"| Access rules | Spec classification and PII flag; taxonomy PII attributes | {len(pii)} products need row-level security |")
    w(f"| Business names and descriptions | Taxonomy attribute definitions | every column |\n")
    w("## The shared spine\n")
    w(f"{len(spine)} conformed dimensions are used across the {len(scope)} products. Build these once; every product reuses them.\n")
    w("| Dimension | From | Products using it |")
    w("|---|---|---|")
    for s in spine[:15]:
        w(f"| {s['dimension']} | {s['source_product']} | {s['used_by']} |")
    w(f"\nThe {len(top)} dimensions used by 5 or more products cover every conformed join of **{len(covered)} of {len(scope)}** "
      "products. The rest of the spine is long-tail dimensions used by one to four products, built when those products are.\n")
    w("## Metrics: where the real work is\n")
    w(f"The {n_metrics} spec measures sort into how they aggregate. Only aggregation needs semantic-layer logic; "
      "row attributes are already computed by the product. The sort is a keyword heuristic on each measure's name and "
      "formula: a spot check puts it right for most measures, but every class needs a human pass before a build.\n")
    w("| Aggregation | Measures | Share | Semantic layer work |")
    w("|---|---|---|---|")
    for cls in ["additive", "semi_additive", "ratio", "count_distinct", "non_additive", "row_attribute", "review"]:
        w(f"| {cls} | {agg[cls]} | {pct(agg[cls], n_metrics)} | {AGG_RULE[cls]} |")
    w(f"\n- **{needs} measures need an aggregation rule**; {agg['row_attribute']} are row attributes (flags, scores, ranks, dates).")
    w(f"- **{agg['ratio']} ratios** are the main risk: each needs its numerator and denominator exposed separately, and "
      "the specs state them as one formula. That split is manual work.")
    w(f"- **{agg['count_distinct'] + agg['non_additive']} distinct counts, means and medians** cannot be rolled up from "
      "product rows. Each needs a decision: recompute from detail rows, or publish only at the product grain.")
    w(f"- **{reused} measures cite a certified upstream figure** (\"certified\", or another DP-nnn). They should bind to the "
      "upstream product's metric rather than be redefined, which is the guide's Net Flows rule.")
    w(f"- {len(review)} measures matched no rule and need a person to classify them.\n")
    w("## By wave\n")
    w("| Wave | Products | Metrics | Need aggregation logic | New spine dimensions |")
    w("|---|---|---|---|---|")
    for wv in waves:
        ps = by_wave[wv]
        m = sum(len(docs[p]["metrics"]) for p in ps)
        n = sum(1 for p in ps for x in docs[p]["metrics"] if x["aggregation"] != "row_attribute")
        w(f"| {wv} | {len(ps)} | {m} | {n} | {len(new_dims[wv])} |")
    w(f"\nWave 1 needs {len(new_dims['Wave 1'])} spine dimensions; later waves add "
      f"{len(new_dims['Wave 2'])} and {len(new_dims['Wave 3'])}. The spine is mostly built by the first wave, and each later "
      "product adds mainly its own facts and metrics.\n")
    w("## Other things a person has to decide\n")
    w(f"- **Multi-fact products ({len(multi_fact)}).** These have more than one fact table, so a metric must say which fact it reads "
      "and which dimensions are safe to combine. DP-016 has six.")
    w("- **Physical names.** The logical models carry none; the drafts use placeholders (`dp_016.fact_territory_scorecard`).")
    w("- **Row-level security predicates.** The drafts say *where* security is needed, not the rule (own territory, own firm, own client).")
    w("- **Tool syntax.** The drafts are tool-neutral. Translating them to Snowflake semantic views, dbt or a BI tool is mechanical once a tool is chosen.\n")
    # Dashboards that bypass the semantic layer compute their own totals and rates unless they only list rows.
    dash = []
    for p in direct:
        if "Dashboard" not in specs[p]["delivery"]:
            continue
        mix = Counter(classify(n, d)[0] for n, d, _ in specs[p]["measures"])
        dash.append((p, mix))
    dash.sort(key=lambda x: (-x[1]["ratio"], -(x[1]["additive"] + x[1]["semi_additive"]), x[0]))
    w("## Dashboards outside the semantic layer: owner review\n")
    w(f"{len(dash)} products list a Dashboard but not the {SEM}. A dashboard that only lists rows (an exception queue, a "
      "review list) is fine as direct delivery. One that shows totals or rates defines those metrics inside the dashboard, "
      "where no other tool can reuse them. Ask each owner which it is. Sorted by ratio measures, the strongest sign of "
      "dashboard-side metric logic.\n")
    w("| Product | Type | Owner | Ratios | Sums | Row attributes |")
    w("|---|---|---|---|---|---|")
    for p, mix in dash:
        w(f"| {p} {REG[p][1]} | {REG[p][3]} | {REG[p][5]} | {mix['ratio']} | {mix['additive'] + mix['semi_additive']} | {mix['row_attribute']} |")
    w("")
    if review:
        w("## Measures to classify by hand\n")
        for p, n in review:
            w(f"- {p}: {n}")
        w("")
    with open(os.path.join(OUT, "SIZING.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L))


if __name__ == "__main__":
    main()
