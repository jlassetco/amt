# Worked example: the institutional book

[institutional_book.yaml](institutional_book.yaml) is a hand-finished semantic model built over **DP-092 Institutional Client 360** and **DP-008 Certified Flows & AUM**. This note explains the choices behind it.

## Same data, different question

DP-092 answers questions about **one client**: what does the State Teachers' pension hold with us, who covers it, and is its review overdue? It is delivered into the CRM, and its spec says it does not go through the semantic layer. That is correct for its purpose.

Leadership asks questions **across clients**:
- How much AUM do we have with public pensions?
- How much of it sits with clients whose relationship is red?
- What is our share of the endowment market?

Those questions need the same facts added up, which is what a semantic model does. So the example reads DP-092's daily warehouse snapshots and DP-008's certified numbers, and publishes them for cross-client analysis. The product stays the same; the semantic model is a second way to consume it. (Adding *BI semantic model* to DP-092's delivery list is an open decision for its owner.)

## What is in it

| | Read from | What it contributes |
|---|---|---|
| `flows_aum` | DP-008 | AUM, gross sales, redemptions and net flows by client, share class and month |
| `client_daily` | DP-092 | Health status, at-risk and review-overdue flags, mandate and service-request counts, per client per day |
| `mandate_revenue` | DP-092 (from DP-012) | Fee revenue by mandate |
| `open_pipeline` | DP-092 (from 03 Sales) | Open opportunities and expected amounts |
| `client`, `consultant`, `mandate`, `strategy`, `share_class`, `salesperson` | DP-003, DP-004, DP-009 | Who and what to slice by |
| `consultant_engagement`, `primary_coverage` | DP-092 bridges | Which consultant advises a client, and who covers it |

It has 13 metrics, 4 access roles and 4 verified questions.

## The decisions the catalog did not make

The generator can draft the tables and joins. These decisions had to be made by hand, and each one belongs to the product owner.

1. **AUM comes from DP-008, not from DP-092.** DP-092 carries "Firm AUM with Client", which is a copy. The model hides it and reads DP-008, so there is only one AUM number. Its T12M net flows and share-of-assets columns are hidden for the same reason.

2. **DP-008 has three hidden ways to double count, all closed with fixed filters.** It holds:
   - the same money at many grains (firm, territory, channel, client)
   - both monthly and rolling-12-month rows
   - preliminary and locked snapshots

   The model fixes `dimension_grain = 'Institutional Client'`, `period_type = 'MONTH'` and `snapshot_status = 'Locked'`, and users cannot remove those filters.

3. **AUM is semi-additive.** Summing AUM across clients is right. Summing it across months is not: March AUM plus April AUM is meaningless. The metric takes the last month in the selected range.

4. **Ratios are recomputed as a ratio of sums.** DP-092 computes Share of Investable Assets % per client. Averaging those would weight a $50M foundation the same as a $50B pension. The model sums AUM and sums investable assets, and applies the same staleness filter (assets figure under 12 months old) to both sides.

5. **Many-to-many joins are marked.** A client can have both a general consultant and an OCIO, so "AUM by consultant" counts that client under each one, and the rows add up to more than the firm total. The model calculates the total separately and flags the join. Coverage avoids the problem by using only the primary salesperson, which keeps it one-to-one.

6. **Metrics from different products are lined up by client, not joined row to row.** At-Risk AUM takes the at-risk flag from DP-092 (latest day) and AUM from DP-008 (latest locked month-end), and lines them up by client. It uses DP-042's definition of At-Risk AUM (the flag only, not RED status) rather than writing a new one. Joining the two fact tables directly would repeat each client's AUM once per share class row. The two dates differ, and the dashboard shows both.

7. **Access follows the product's classification.** DP-092 is *Confidential - Client* with personal data:
   - Sales and service see only the clients they cover.
   - Leadership sees all clients.
   - Everyone else (finance, product, marketing) sees aggregates without client, mandate or salesperson names.

## What was left out, and why

Stakeholders, meeting participants, activity detail, RFP detail, restrictions and KYC, and account plans stay in the CRM view, one client at a time. None of them answers a cross-client question. Most carry personal data or confidentiality rules that the CRM already enforces. Adding them would add risk without adding value. RFPs can come in later from DP-023, which owns them, if a cross-client RFP question comes up.

This is the main lesson: **the semantic model is much smaller than the products under it.**

| | Generator draft of DP-092 | Hand-finished model |
|---|---|---|
| Tables | 18 own + 14 conformed | 12 |
| Joins | 44 | 11 |
| Metrics | 13 DP-092 measures, as written | 13: 5 bound to DP-008, 1 bound to DP-042 (At-Risk AUM), 6 reworked from DP-092, 1 new (Client Count) |
| DP-092 measures dropped | none | 5 (AUM and flow copies, days since last interaction, open RFPs, restriction count) |
| Restricted columns | 12 personal-data columns | 3 role-restricted: salesperson name (personal data), client and mandate names (client-confidential) |

## Questions it cannot answer yet

- **AUM or fee yield by segregated mandate.** Certified AUM is not held by mandate (GAP-06-011). Revenue exists by mandate but AUM does not, so yield cannot be calculated.
- **Mandate performance against benchmark.** No Data Domain holds it (GAP-01-004).
- **AUM by primary consultant.** The consultant relationship has no primary indicator, so this needs either a taxonomy change or a business rule.

These are taxonomy gaps that the model makes visible. Writing verified questions is a cheap way to find them before anyone builds a dashboard.
