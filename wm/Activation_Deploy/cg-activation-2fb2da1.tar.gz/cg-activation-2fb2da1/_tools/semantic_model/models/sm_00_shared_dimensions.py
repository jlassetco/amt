"""Semantic model SM-00 Shared Dimensions: the conformed dimensions every subject-area model joins to. See CONTRACT.md."""

# Most foundational entities are effective-dated. Unless a consuming model joins on the fact's own date, a dimension
# shows the version in force on the as-of date.
CURRENT = "effective on the as-of date (today unless the user picks one)"

# DP-005 is Restricted - Commercial Terms: these columns stay with partnership, finance and data management roles.
COMMERCIAL = ["agreement_name", "agreement_type", "agreement_permitted_jurisdictions", "agreement_status", "governing_law",
              "most_favored_nation", "exclusivity", "term_type", "next_renewal_date", "agreement_party_role",
              "inclusion_type", "days_to_renewal", "placement_without_agreement", "payment_type",
              "funding_source", "payment_arrangement_status", "normalized_rating", "watch_list", "rating_date"]
# Personal data about intermediary advisors (DP-001; DP-002 retired into it, CW-202) and the firm's own advisors (DP-009).
ADVISOR_PII = ["advisor_name", "individual_crd_number", "contactable", "team_name", "recent_move", "tenure_at_firm_years",
               "affiliation_type", "affiliation_change_reason", "affiliation_start_date"]
# ---- Wave E9 enterprise dimensions --------------------------------------------------------------------------------
# DP-192 flags every Employee attribute as personal data: only HR and the data management role see these columns;
# everyone else joins through the pseudonymized Employee ID, org unit and legal entity.
EMPLOYEE_PII = ["employee_name", "employee_job_title", "employee_job_family", "employee_employment_type",
                "employee_employment_status", "employee_legal_entity", "employee_home_org_unit", "employee_work_location",
                "contingent_worker_type"]
# Names of individual parties and households (DP-240 Party Display Name, Household Name) and client-identifying portfolio
# and mandate names (DP-140).
ENTERPRISE_CLIENT = ["party_name", "household_name", "portfolio_name", "parent_portfolio_name", "portfolio_mandate_name"]
# ---- WP2 wealth dimensions -------------------------------------------------------------------------------------------
# The analytics views of DP-240 and DP-093 carry keys, types, statuses, memberships, segments, tiers, enrollments, features
# and elections without names, registration lines, external numbers or bank detail; those are never published here.
# Client-level attributes the analytics view does carry but broad roles do not need (account opening and closure detail,
# networking level and the per-account role type) stay with client data, service, advice and conduct roles.
CLIENT_DETAIL = ["application_channel", "application_received_date", "good_order_date", "closure_reason",
                 "networking_level", "account_role_type", "household_member_role", "enrollment_termination_reason"]
# DP-213 is Restricted - Legal: contract terms stay with legal, procurement, finance and data management roles.
LEGAL = ["contract_title", "parent_contract_title", "contract_subtype", "contract_governing_law", "contract_expiry_date",
         "contract_party_role", "key_date_type", "key_date_value", "key_date_action_status", "clause_type", "clause_position",
         "exit_assistance_period"]
# Agency rating values and identifiers licensed for internal investment use (DP-097, DP-098: Confidential - Licensed).
LICENSED = ["credit_rating_value", "instrument_identifier_value", "cusip_issuer_number"]
# Counterparty credit terms (DP-115): limits and review conclusions stay with trading, risk and operations.
COUNTERPARTY_TERMS = ["limit_amount", "maximum_tenor_months", "credit_view", "counterparty_review_outcome", "status_after_review"]

MODEL = dict(
    id="SM-00",
    status="Draft",
    description=("The conformed dimensions every subject-area model joins to. For the wealth manager (WP2, plan section 8.4): "
                 "households, clients and client accounts with their owners, program enrollments, features and sweep "
                 "elections; the firm's advisors, coverage teams, household coverage and service tiers; service offerings, "
                 "programs, service tiers and model portfolios; the account channel; products, share classes and platform "
                 "availability; the thin intermediary channel's partner firms, branches, advisors and agreements; "
                 "institutional clients, consultants and plans; calendars and reference data; and the enterprise masters "
                 "(parties, instruments, issuers and ratings, counterparties, portfolios, custody, the chart of accounts, "
                 "employees, vendors, applications, models and contracts). It is built first and is not queried on its own: "
                 "analysts reach it through SM-08 to SM-31, which slice their facts by these tables. Its own metrics are "
                 "counts of the reference data itself; the certified counts of accounts, clients and households are SM-20's."),
    questions=[
        "How many client accounts are open by business line, account type, registration type and channel, and how many are enrolled in each advisory program?",
        "How many producing advisors does the firm have in each division, how many households does each cover as primary coverage, and how many tiered households have no primary advisor?",
        "How many service offerings are active by delivery mode and discretion type, and how many products are available on the platform by transaction fee category?",
        "How many accounts closed in the period, by closure reason and receiving firm, and how long did new accounts take to reach good order by application channel?",
        "How many intermediary partner firms, branches and advisors are active by distribution channel, and how many active firms have no primary coverage?",
        "How many instruments, issuers and approved counterparties are active by asset class, rating and parent group, and how much counterparty limit is approved per group?",
    ],

    tables=[
        # --- DP-001 Intermediary Partner Master: the thin intermediary channel (plan section 4 item 9) -------------------
        # One 02 party table role-played as partner firm, branch and advisor team (names and identifiers), with the restored
        # 05 profiles (Distributor Firm, Branch / Office, Employment Affiliation, Partner Coverage Assignment; CW-132) read
        # by WP1 for the channel, registration and coverage attributes.
        dict(name="distributor_firm", product="DP-001", entity="Party", kind="Dimension",
             always_filter=["Party ID has a Party Role with Role Type = 'Distributor Firm'"],
             dimensions=[dict(name="firm_name", attr="Party Display Name"),
                         dict(name="firm_party_type", attr="Party Type", note="Read in place of Organization Type (CW-902)"),
                         dict(name="legal_jurisdiction", attr="Legal Jurisdiction"),
                         dict(name="firm_primary_regulator", attr="Primary Regulator",
                              note="Read in place of the Regulated Entity Indicator (CW-902)"),
                         dict(name="firm_status", attr="Party Status"),
                         dict(name="relationship_stage", attr="Relationship Stage"),
                         dict(name="firm_crd_number", attr="Firm CRD Number", note="Public firm identifier, for lookup")],
             hidden=[("Primary Country", "Flagged as personal data on the shared party table; firm location is Legal Jurisdiction.")]),
        # The firm's legal parent, from the restored DP-001 Legal Entity Hierarchy (CW-902); shown by name through parent_group.
        dict(name="distributor_firm_parent", product="DP-001", entity="Legal Entity Hierarchy", kind="Bridge",
             grain="subsidiary party x direct parent x relationship basis x effective period",
             always_filter=["Parent Relationship Basis = 'Accounting Consolidation'"],   # one legal parent chain per firm
             default_filter=f"Hierarchy row {CURRENT}",
             dimensions=[dict(name="firm_ultimate_parent", attr="Ultimate Parent",
                              note="Party ID of the ultimate parent; shown by name through parent_group"),
                         dict(name="firm_direct_parent", attr="Direct Parent"),
                         dict(name="firm_parent_relationship_basis", attr="Parent Relationship Basis")]),
        dict(name="distributor_office", product="DP-001", entity="Party", kind="Dimension",
             always_filter=["Party ID has a Party Role with Role Type = 'Branch / Office'"],
             dimensions=[dict(name="office_name", attr="Party Display Name")]),
        dict(name="advisor_team", product="DP-001", entity="Party", kind="Dimension",
             always_filter=["Party ID has a Party Role with Role Type = 'Advisor Team'"],
             dimensions=[dict(name="team_name", attr="Party Display Name",
                              note="Teams are often named after their advisors; treated as personal data")]),

        # --- Intermediary advisors (DP-001; WP1 re-point CW-202: DP-002 retired into DP-001) ---------------------------
        # The identity columns stay on DP-001 'Party' (02 Party, Individual, US Regulatory Identifier, Privacy Profile); the
        # advisor rows are the parties with a 05 Financial Professional profile (Financial Professional Party = Party ID).
        # Contactable Flag is a DP-001 measure on Party. Household Name left with DP-002 (households are DP-240's).
        dict(name="advisor", product="DP-001", entity="Party", kind="Dimension",
             always_filter=["Party Type = 'Individual' and Party ID has a 05 Financial Professional row (Financial Professional Party = Party ID)"],
             default_filter=f"Profile {CURRENT}",
             dimensions=[dict(name="advisor_name", attr="Party Display Name", note="Personal data; entitled roles only"),
                         dict(name="individual_crd_number", attr="Individual CRD Number", note="Personal data; entitled roles only"),
                         dict(name="advisor_status", attr="Party Status"),
                         dict(name="relationship_stage", attr="Relationship Stage"),
                         dict(name="contactable", attr="Contactable Flag",
                              note="Derived from privacy preferences, so treated as personal data"),
                         dict(name="recent_move", attr="Recent Move Flag",
                              note="Y when the advisor moved firm in the last 90 days; personal data, entitled roles only"),
                         dict(name="tenure_at_firm_years", attr="Tenure at Firm (Years)",
                              note="Per advisor, on the open affiliation; for banding, never summed or averaged across firms")],
             hidden=[("Given Name", "Personal data; Party Display Name serves entitled roles."),
                     ("Family Name", "Personal data; Party Display Name serves entitled roles."),
                     ("Preferred Name", "Personal data; Party Display Name serves entitled roles."),
                     ("Do Not Contact Indicator", "Summarized by the Contactable Flag."),
                     ("Date of Death", "Personal data; Party Status answers whether an advisor is active.")]),
        # The vendor advisor segment (05 External Classification) replaces the retired DP-002 02 Segment Assignment (F4 notes).
        dict(name="advisor_segment", product="DP-001", entity="External Classification", kind="Bridge",
             grain="classified party x classification vendor x vendor classification as-of date",
             default_filter="latest Vendor Classification As-Of Date per party and vendor",
             dimensions=[dict(name="segmentation_scheme", attr="Classification Vendor"),
                         dict(name="advisor_segment", attr="Vendor Advisor Segment")]),
        # WP1 (CW-132): the restored 05 profiles. A partner firm's channel and registration type, its branches, where each
        # external advisor works, and which of the firm's employees covers each partner.
        dict(name="distributor_firm_profile", product="DP-001", entity="Distributor Firm", kind="Dimension",
             default_filter=f"Profile {CURRENT}",
             dimensions=[dict(name="firm_distribution_channel", attr="Distribution Channel",
                              note="The partner's channel code (Distribution Channel code list, DP-013)"),
                         dict(name="firm_registration_type", attr="Firm Registration Type"),
                         dict(name="firm_operating_model", attr="Firm Operating Model"),
                         dict(name="advisory_client_types", attr="Advisory Client Types"),
                         dict(name="form_adv_filing_date", attr="Form ADV Filing Date")],
             facts=[dict(name="registered_representatives", attr="Number of Registered Representatives",
                         note="Per firm, as filed; sums across firms only")],
             hidden=[("Regulatory Assets Under Management", "The partner's Form ADV figure, flagged personal data; never "
                                                           "compared with the firm's Client Assets or Firm AUM.")]),
        dict(name="intermediary_branch", product="DP-001", entity="Branch / Office", kind="Dimension",
             dimensions=[dict(name="branch_type", attr="Branch Type"),
                         dict(name="supervising_osj", attr="Supervising OSJ", note="Party ID of the supervising OSJ branch")]),
        dict(name="advisor_affiliation", product="DP-001", entity="Employment Affiliation", kind="Bridge",
             grain="external advisor x employing firm x affiliation start date",
             default_filter=f"Affiliation {CURRENT} (Affiliation End Date blank or after the as-of date)",
             dimensions=[dict(name="affiliation_type", attr="Affiliation Type", note="Personal data; entitled roles only"),
                         dict(name="affiliation_start_date", attr="Affiliation Start Date", note="Personal data; entitled roles only"),
                         dict(name="affiliation_end_date", attr="Affiliation End Date"),
                         dict(name="affiliation_change_reason", attr="Affiliation Change Reason", note="Personal data; entitled roles only")],
             hidden=[("Move Detected Date", "Summarized by the advisor's Recent Move Flag.")]),
        dict(name="partner_coverage", product="DP-001", entity="Partner Coverage Assignment", kind="Bridge",
             grain="covered partner party x covering employee x partner coverage role x coverage period",
             default_filter=f"Coverage {CURRENT}",
             dimensions=[dict(name="partner_coverage_role", attr="Partner Coverage Role"),
                         dict(name="partner_primary_coverage", attr="Primary Coverage Indicator")]),

        # --- DP-003 Institutional, Consultant & Plan Relationships: one party table role-played by Party Role --------
        # The client, consultant and recordkeeper profiles are 12 Institutional Client (CW-133), 05 Consultant Profile and
        # Consultant Advisory Relationship (CW-132) and 16 Recordkeeper Profile and Plan Service Provider (W3). DP-003 reads
        # them at its WP0 re-scope (CW-013); until then plans are party rows (Party Type = Retirement Plan) and consultant
        # and provider links are 02 Party Relationship rows.
        dict(name="institutional_client", product="DP-003", entity="Party", kind="Dimension",   # WP1 re-point (CW-202): the party columns are on DP-003 Party
             always_filter=["Party ID has a 12 Institutional Client row (Institutional Client Party = Party ID)"],
             dimensions=[dict(name="client_name", attr="Party Display Name", note="Client-confidential; named-client roles only"),
                         dict(name="client_party_type", attr="Party Type",
                              note="12 Institutional Client Type replaces it when DP-003 reads 12 Institutional Client (WP0, CW-013, CW-133)"),
                         dict(name="client_legal_form", attr="Legal Form"),
                         dict(name="client_jurisdiction", attr="Legal Jurisdiction"),
                         dict(name="industry_classification", attr="Industry Classification"),
                         dict(name="client_primary_regulator", attr="Primary Regulator"),
                         dict(name="client_relationship_stage", attr="Relationship Stage"),
                         dict(name="client_status", attr="Party Status")]),
        dict(name="institutional_client_classification", product="DP-003", entity="Regulatory Classification", kind="Dimension",
             always_filter=["Categorization Date = the latest categorization date on or before the as-of date, per party"],
             dimensions=[dict(name="investor_category", attr="Investor Category",
                              note="US investor category; replaces the dropped MiFID Client Category (US only)"),
                         dict(name="finra_institutional_investor", attr="FINRA Institutional Investor Indicator")]),
        dict(name="consultant", product="DP-003", entity="Party", kind="Dimension",   # WP1 re-point (CW-202): the party columns are on DP-003 Party
             always_filter=["Party ID has a 05 Consultant Profile row (Consultant Party = Party ID)"],
             dimensions=[dict(name="consultant_name", attr="Party Display Name")]),
        dict(name="recordkeeper", product="DP-003", entity="Party", kind="Dimension",   # WP1 re-point (CW-202): the party columns are on DP-003 Party
             always_filter=["Party ID has a 16 Recordkeeper Profile row (Recordkeeper Party = Party ID)"],
             dimensions=[dict(name="recordkeeper_name", attr="Party Display Name")]),
        dict(name="consultant_relationship", product="DP-003", entity="Party Relationship", kind="Bridge",
             grain="consultant party x advised client party x effective period",
             always_filter=["Relationship Type = 'Consults For'"],
             default_filter=f"Relationship {CURRENT}"),
        dict(name="retirement_plan", product="DP-003", entity="Party", kind="Dimension",   # WP1 re-point (CW-202): the party columns are on DP-003 Party
             always_filter=["Party Type = 'Retirement Plan'"],   # plan rows of the party table (one row per plan)
             dimensions=[dict(name="plan_name", attr="Plan Name", note="Client-confidential; named-client roles only"),
                         dict(name="plan_type", attr="Plan Type"),
                         dict(name="plan_number", attr="Plan Number"),
                         dict(name="sponsor_ein", attr="Sponsor EIN")]),
        dict(name="plan_provider_relationship", product="DP-003", entity="Party Relationship", kind="Bridge",
             grain="service provider party x retirement plan party x effective period",
             always_filter=["Relationship Type = 'Services Plan'"],
             default_filter=f"Relationship {CURRENT}"),
        dict(name="investment_mandate", product="DP-003", entity="Investment Mandate", kind="Dimension",
             dimensions=[dict(name="mandate_name", attr="Mandate Name", note="Client-confidential; named-client roles only"),
                         dict(name="mandate_type", attr="Mandate Type")]),
        # WP1: the 12 Institutional Client profile and the institutional service relationship (DP-003 reads them).
        dict(name="institutional_client_profile", product="DP-003", entity="Institutional Client", kind="Dimension",
             dimensions=[dict(name="institutional_client_type", attr="Institutional Client Type"),
                         dict(name="client_primary_business_line", attr="Primary Business Line"),
                         dict(name="governance_model", attr="Governance Model"),
                         dict(name="government_entity", attr="Government Entity Indicator",
                              note="The Advisers Act Rule 206(4)-5 population"),
                         dict(name="erisa_plan", attr="ERISA Plan Indicator"),
                         dict(name="upmifa_applicable", attr="UPMIFA Applicability Indicator"),
                         dict(name="client_fiscal_year_end", attr="Fiscal Year End")],
             hidden=[("Total Investable Assets", "Client-reported and dated per client; not the firm's Client Assets or Firm "
                                                 "AUM, so it is not published as a fact."),
                     ("Funded Status", "Pension funded status as reported by the client; a servicing detail.")]),
        dict(name="institutional_service_relationship", product="DP-003", entity="Service Relationship", kind="Bridge",
             grain="institutional client x service relationship (servicing segment and business line)",
             always_filter=["Service Relationship Status in ('Onboarding', 'Active', 'Under Notice') unless the user picks another status"],
             dimensions=[dict(name="servicing_segment", attr="Servicing Segment"),
                         dict(name="relationship_business_line", attr="Relationship Business Line"),
                         dict(name="service_relationship_status", attr="Service Relationship Status"),
                         dict(name="institutional_service_tier", attr="Service Tier"),
                         dict(name="service_relationship_start_date", attr="Relationship Start Date")]),
        dict(name="institutional_account", product="DP-003", entity="Account", kind="Dimension",
             dimensions=[dict(name="account_type", attr="Account Type"),
                         dict(name="account_status", attr="Account Status"),
                         dict(name="account_open_date", attr="Account Open Date")],
             hidden=[("Account Close Date", "Account Status shows closed accounts; the date is per-account detail.")]),

        # --- DP-004 Product & Share Class Distribution Reference ----------------------------------------------------
        dict(name="share_class", product="DP-004", entity="Share Class", kind="Dimension",
             default_filter=f"Share class version {CURRENT}",
             dimensions=[dict(name="share_class_name", attr="Share Class Legal Name"),
                         dict(name="share_class_designation", attr="Share Class Designation"),
                         dict(name="share_class_type", attr="Share Class Type"),
                         dict(name="share_class_currency", attr="Share Class Currency"),
                         dict(name="share_class_status", attr="Share Class Status"),
                         dict(name="share_class_launch_date", attr="Share Class Launch Date"),
                         dict(name="isin", attr="ISIN"),
                         dict(name="cusip", attr="CUSIP"),
                         dict(name="morningstar_category", attr="Morningstar Category"),
                         dict(name="eligible_investor_type", attr="Eligible Investor Type"),
                         dict(name="share_class_channel", attr="Distribution Channel"),
                         dict(name="expense_waiver_gap", attr="Net Expense Ratio Gap",
                              note="Per share class (the waiver in effect); for filtering, never summed"),
                         dict(name="days_to_lifecycle_event", attr="Days to Lifecycle Event",
                              note="Days to the next pending closure, merger or other lifecycle event"),
                         dict(name="pm_change_flag", attr="Portfolio Manager Change Flag"),
                         dict(name="firm_risk_rating", attr="Firm Risk Rating",
                              note="The firm's 1 to 5 product risk scale matched to the investor profile (45)")]),
        dict(name="investment_product", product="DP-004", entity="Investment Product", kind="Dimension",
             dimensions=[dict(name="product_name", attr="Product Marketing Name"),
                         dict(name="product_legal_name", attr="Product Legal Name"),
                         dict(name="vehicle_type", attr="Vehicle Type"),
                         dict(name="business_line", attr="Business Line"),
                         dict(name="product_asset_class", attr="Product Asset Class"),
                         dict(name="product_investment_approach", attr="Product Investment Approach"),
                         dict(name="aum_reporting_category", attr="AUM Reporting Category"),
                         dict(name="fund_domicile", attr="Fund Domicile"),
                         dict(name="legal_form", attr="Legal Form"),
                         dict(name="regulatory_regime", attr="Regulatory Regime"),
                         dict(name="product_range", attr="Product Range"),
                         dict(name="base_currency", attr="Base Currency"),
                         dict(name="product_inception_date", attr="Product Inception Date")]),
        dict(name="investment_strategy", product="DP-004", entity="Investment Strategy", kind="Dimension",
             dimensions=[dict(name="strategy_name", attr="Strategy Name"),
                         dict(name="asset_class", attr="Asset Class"),
                         dict(name="sub_asset_class", attr="Sub-Asset Class"),
                         dict(name="investment_approach", attr="Investment Approach"),
                         dict(name="geographic_focus", attr="Geographic Focus"),
                         dict(name="strategy_status", attr="Strategy Status")]),
        dict(name="model_portfolio", product="DP-004", entity="Model Portfolio", kind="Dimension",
             dimensions=[dict(name="model_portfolio_name", attr="Model Portfolio Name"),
                         dict(name="model_sponsor_platform", attr="Model Sponsor / Platform"),
                         dict(name="model_delivery_method", attr="Model Delivery Method"),
                         dict(name="rebalance_frequency", attr="Rebalance Frequency")]),
        # --- WP2 Offering and Program (DP-004 Service Offering, Service Tier; plan section 8.4) --------------------------
        # A program is a service offering an account enrolls in (DP-093 Program Enrollment -> DP-004 Service Offering); the
        # program table is the same entity role-played for the advisory, managed and trust programs.
        dict(name="service_offering", product="DP-004", entity="Service Offering", kind="Dimension",
             default_filter=f"Offering {CURRENT}",
             dimensions=[dict(name="offering_name", attr="Offering Name"),
                         dict(name="offering_type", attr="Offering Type"),
                         dict(name="offering_delivery_mode", attr="Delivery Mode", note="Digital, human or hybrid advice"),
                         dict(name="discretion_type", attr="Discretion Type"),
                         dict(name="advisory_capacity", attr="Advisory Capacity"),
                         dict(name="sponsoring_entity", attr="Sponsoring Entity", note="Legal Entity ID; shown through internal_legal_entity"),
                         dict(name="wrap_fee_program", attr="Wrap Fee Program Indicator"),
                         dict(name="rule_3a4_program", attr="Rule 3a-4 Program Indicator"),
                         dict(name="offering_status", attr="Offering Status")]),
        dict(name="program", product="DP-004", entity="Service Offering", kind="Dimension",
             always_filter=["Offering Type not in ('Brokerage', 'Planning Only') (the advisory, managed and trust programs an "
                            "account enrolls in)"],
             default_filter=f"Offering {CURRENT}",
             dimensions=[dict(name="program_name", attr="Offering Name"),
                         dict(name="program_type", attr="Offering Type"),
                         dict(name="program_delivery_mode", attr="Delivery Mode"),
                         dict(name="program_discretion_type", attr="Discretion Type"),
                         dict(name="program_wrap_fee", attr="Wrap Fee Program Indicator"),
                         dict(name="program_rule_3a4", attr="Rule 3a-4 Program Indicator")]),
        dict(name="offering_service_tier", product="DP-004", entity="Service Tier", kind="Dimension",
             dimensions=[dict(name="service_tier_code", attr="Service Tier Code"),
                         dict(name="service_tier_name", attr="Service Tier Name"),
                         dict(name="tier_asset_threshold", attr="Tier Asset Threshold",
                              note="The entry threshold of the tier; for banding, never summed"),
                         dict(name="tier_measurement_basis", attr="Tier Measurement Basis")],
             hidden=[("Tier Benefits", "Free-text description of the tier's benefits; no cross-row question needs it.")]),
        dict(name="platform_availability", product="DP-004", entity="Platform Product Availability", kind="Bridge",
             grain="own share class or third-party instrument x availability effective date",
             always_filter=["Availability Effective From = the latest on or before the as-of date, per share class or instrument"],
             dimensions=[dict(name="platform_availability_status", attr="Platform Availability Status"),
                         dict(name="transaction_fee_category", attr="Transaction Fee Category",
                              note="No-transaction-fee, transaction-fee and other platform pricing categories")]),

        # --- DP-005 Intermediary Agreements & Platform Placement (Restricted - Commercial Terms) ------------------------
        dict(name="distribution_agreement", product="DP-005", entity="Distribution Agreement", kind="Dimension",
             default_filter=f"Agreement version {CURRENT}",
             dimensions=[dict(name="agreement_name", attr="Agreement Name"),
                         dict(name="agreement_type", attr="Agreement Type"),
                         dict(name="agreement_permitted_jurisdictions", attr="Permitted Jurisdictions",
                              note="US states; replaces Agreement Market, dropped with Agreement Paper at W4 (CW-905)"),
                         dict(name="agreement_status", attr="Agreement Status"),
                         dict(name="governing_law", attr="Governing Law"),
                         dict(name="most_favored_nation", attr="Most-Favored-Nation Clause Indicator"),
                         dict(name="exclusivity", attr="Exclusivity Indicator"),
                         dict(name="term_type", attr="Term Type"),
                         dict(name="next_renewal_date", attr="Next Renewal Date")]),
        dict(name="agreement_party", product="DP-005", entity="Agreement Party Role", kind="Bridge",
             grain="agreement x party x agreement party role x role effective period",
             always_filter=["Firm Contracting Entity Indicator = 'N'"],   # the partner side only; the firm's own entities are not partners
             default_filter=f"Party role {CURRENT}",
             dimensions=[dict(name="agreement_party_role", attr="Agreement Party Role")]),
        dict(name="agreement_coverage", product="DP-005", entity="Agreement Product Coverage", kind="Bridge",
             grain="agreement x covered product, share class or vehicle type x inclusion type x coverage effective period",
             default_filter=f"Coverage {CURRENT}",
             dimensions=[dict(name="inclusion_type", attr="Inclusion Type")]),   # Coverage Basis dropped at W4 (CW-905)
        dict(name="shelf_placement", product="DP-005", entity="Shelf Placement", kind="Bridge",
             grain="partner x platform or program x share class x shelf list type x placement status effective period",
             default_filter=f"Placement status {CURRENT}",
             dimensions=[dict(name="platform_program_name", attr="Partner Platform / Program Name",
                              note="Text only: no partner program key (GAP-05-006)"),
                         dict(name="shelf_list_type", attr="Shelf List Type"),
                         dict(name="placement_status", attr="Placement Status"),
                         dict(name="trade_enabled_date", attr="Trade-Enabled Date"),
                         dict(name="eligible_account_types", attr="Eligible Account Types"),
                         dict(name="model_eligible", attr="Model Eligibility Indicator"),
                         dict(name="days_to_renewal", attr="Days to Renewal",
                              note="Days until the governing agreement's next renewal date"),
                         dict(name="placement_without_agreement", attr="Placement Without Agreement Flag")]),
        dict(name="partner_program", product="DP-005", entity="Partner Program", kind="Dimension",
             dimensions=[dict(name="program_name", attr="Program Name"),
                         dict(name="program_type", attr="Program Type"),
                         dict(name="program_status", attr="Program Status")]),
        dict(name="payment_arrangement", product="DP-005", entity="Payment Arrangement", kind="Dimension",
             default_filter=f"Arrangement {CURRENT}",
             dimensions=[dict(name="payment_type", attr="Payment Type"),
                         dict(name="funding_source", attr="Funding Source"),
                         dict(name="payment_arrangement_status", attr="Payment Arrangement Status")]),
        dict(name="partner_research_rating", product="DP-005", entity="Partner Research Rating", kind="Bridge",
             grain="research provider x rated product x rating date",
             always_filter=["Rating Date = the latest rating date on or before the as-of date, per provider and product"],
             dimensions=[dict(name="normalized_rating", attr="Normalized Research Rating"),
                         dict(name="watch_list", attr="Watch List Indicator"),
                         dict(name="rating_date", attr="Rating Date")]),

        # --- DP-009 Advisor Organization & Coverage (W2-W4, CW-062, CW-063): the firm's own advisors, coverage teams and
        # household coverage, from the 03 Advisor Organization objects. Territories, the territory hierarchy, party-to-
        # territory alignment and salesperson assignments were dropped with no successor (no territories in the wealth
        # model; CW-013, CW-064; 07 retired, CW-907). Intermediary partner coverage is 05 Partner Coverage Assignment.
        dict(name="firm_advisor", product="DP-009", entity="Employee", kind="Dimension",
             always_filter=["the employee holds an 03 Advisor record (Advisor Status is not blank)"],
             dimensions=[dict(name="firm_advisor_name", attr="Preferred Name",
                              note="Personal data; other roles see the pseudonymized Employee ID"),
                         dict(name="job_title", attr="Job Title"),
                         dict(name="employment_status", attr="Employment Status"),
                         dict(name="advisor_status", attr="Advisor Status", note="Replaces Sales Profile Status (CW-062)"),
                         dict(name="client_facing_title", attr="Client-Facing Title"),
                         dict(name="advice_channels_offered", attr="Advice Channels Offered"),
                         dict(name="advisor_business_lines", attr="Advisor Business Lines"),
                         dict(name="work_location", attr="Work Location")],
             hidden=[("Legal Last Name", "Personal data; Preferred Name serves entitled roles."),
                     ("Business Email Address", "Personal data; no cross-row question needs it."),
                     ("Hire Date", "Personal data; tenure questions are HR's, not distribution's."),
                     ("Termination Date", "Personal data; Employment Status shows leavers."),
                     ("Entities Represented", "Registration detail per advisor; no cross-row question needs it.")]),
        dict(name="advisor_role", product="DP-009", entity="Advisor Role Assignment", kind="Bridge",
             grain="advisor x advisor role x role effective period",
             always_filter=["Primary Role Indicator = 'Y'"],   # one primary role per advisor keeps advisor_role one-to-one
             default_filter=f"Role {CURRENT}",
             dimensions=[dict(name="advisor_role", attr="Advisor Role", note="Replaces Primary Sales Role and Sales Function (CW-062)"),
                         dict(name="producing", attr="Producing Indicator")]),
        dict(name="coverage_team", product="DP-009", entity="Coverage Team", kind="Dimension",
             default_filter=f"Team {CURRENT}",
             dimensions=[dict(name="coverage_team_name", attr="Coverage Team Name",
                              note="Teams can be named after advisors; treated as personal data"),
                         dict(name="coverage_team_type", attr="Coverage Team Type"),
                         dict(name="coverage_team_status", attr="Team Status")]),
        dict(name="coverage_team_membership", product="DP-009", entity="Coverage Team Membership", kind="Bridge",
             grain="advisor x coverage team x membership role x membership effective period",
             default_filter=f"Membership {CURRENT}",
             dimensions=[dict(name="membership_role", attr="Membership Role")],
             facts=[dict(name="capacity_allocation_percentage", attr="Capacity Allocation Percentage")]),
        dict(name="coverage_model", product="DP-009", entity="Coverage Model", kind="Dimension",
             always_filter=["Coverage Model Status = 'Active'"],
             dimensions=[dict(name="coverage_model_code", attr="Coverage Model Code"),
                         dict(name="delivery_mode", attr="Delivery Mode")]),
        dict(name="coverage_assignment", product="DP-009", entity="Coverage Assignment", kind="Bridge",
             grain="covered party or account x covering advisor or coverage team x party coverage role x effective period",
             default_filter=f"Coverage {CURRENT}",
             dimensions=[dict(name="party_coverage_role", attr="Party Coverage Role"),
                         dict(name="primary_coverage", attr="Primary Coverage Indicator"),
                         dict(name="assignment_basis", attr="Assignment Basis"),
                         dict(name="relationship_start_date", attr="Relationship Start Date"),
                         dict(name="registration_gap", attr="Registration Gap Flag",
                              note="Y when the covering advisor lacks an active registration the assignment needs")]),
        dict(name="service_tier", product="DP-009", entity="Service Tier Assignment", kind="Bridge",
             grain="party x assigned service tier x tier effective period",
             default_filter=f"Tier {CURRENT}",
             dimensions=[dict(name="assigned_service_tier", attr="Assigned Service Tier",
                              note="02 Service Tier Assignment; replaces 07 Coverage Tier Assignment (CW-062)")]),

        # --- DP-013 Enterprise Reference & Calendars -----------------------------------------------------------------
        # Calendar Date holds one row per calendar per date; pinning the reporting calendar makes it one row per date.
        dict(name="calendar_date", product="DP-013", entity="Calendar Date", kind="Dimension",
             always_filter=["Calendar Key = the enterprise reporting calendar (Calendar Type = 'Reporting')"],
             dimensions=[dict(name="calendar_date", attr="Calendar Date"),
                         dict(name="calendar_year", attr="Calendar Date", note="Year of the date, derived in the view"),
                         dict(name="calendar_quarter", attr="Calendar Date", note="Year and quarter of the date, derived in the view"),
                         dict(name="calendar_month", attr="Calendar Date", note="Year and month of the date, derived in the view"),
                         dict(name="day_type", attr="Day Type"),
                         dict(name="holiday_name", attr="Holiday Name"),
                         dict(name="business_day", attr="Business Day Indicator")]),
        dict(name="fiscal_quarter", product="DP-013", entity="Fiscal Period", kind="Dimension",
             always_filter=["Calendar Key = the firm fiscal calendar (Calendar Type = 'Fiscal')", "Fiscal Period Type = 'Quarter'"],
             dimensions=[dict(name="fiscal_year", attr="Fiscal Year"),
                         dict(name="fiscal_quarter", attr="Fiscal Period ID"),
                         dict(name="fiscal_quarter_status", attr="Fiscal Period Status")]),
        dict(name="fiscal_month", product="DP-013", entity="Fiscal Period", kind="Dimension",
             always_filter=["Calendar Key = the firm fiscal calendar (Calendar Type = 'Fiscal')", "Fiscal Period Type = 'MONTH'"],
             dimensions=[dict(name="fiscal_month", attr="Fiscal Period ID"),
                         dict(name="fiscal_month_status", attr="Fiscal Period Status")]),
        dict(name="internal_legal_entity", product="DP-013", entity="Internal Legal Entity", kind="Dimension",
             dimensions=[dict(name="legal_entity_name", attr="Legal Name"),
                         dict(name="entity_category", attr="Entity Category"),
                         dict(name="jurisdiction_of_formation", attr="Jurisdiction of Formation"),
                         dict(name="entity_status", attr="Entity Status"),
                         dict(name="branch_indicator", attr="Branch Indicator"),
                         dict(name="accounting_company_code", attr="Accounting Company Code")]),
        dict(name="org_unit", product="DP-013", entity="Org Unit", kind="Dimension",
             dimensions=[dict(name="org_unit_name", attr="Org Unit Name"),
                         dict(name="org_unit_type", attr="Org Unit Type"),
                         dict(name="business_function", attr="Business Function")]),
        dict(name="org_division", product="DP-013", entity="Org Unit", kind="Dimension",
             always_filter=["Org Unit Type = 'Division'"],
             dimensions=[dict(name="org_division_name", attr="Org Unit Name")]),
        dict(name="org_hierarchy_link", product="DP-013", entity="Org Hierarchy Link", kind="Bridge",
             grain="hierarchy type x parent org unit x child org unit x effective period",
             always_filter=["Org Hierarchy Type = 'Distribution Organization'"],
             default_filter=f"Link {CURRENT}"),
        dict(name="country", product="DP-013", entity="Country", kind="Dimension",
             dimensions=[dict(name="country_code", attr="Country Code (Alpha-2)"),
                         dict(name="country_name", attr="Country Short Name")]),
        dict(name="currency", product="DP-013", entity="Currency", kind="Dimension",
             dimensions=[dict(name="currency_code", attr="Currency Code"),
                         dict(name="currency_name", attr="Currency Name"),
                         dict(name="group_reporting_currency", attr="Group Reporting Currency Indicator")]),
        dict(name="geographic_unit", product="DP-013", entity="Geographic Unit", kind="Dimension",
             default_filter=f"Geographic unit {CURRENT}",
             dimensions=[dict(name="geographic_unit_name", attr="Geographic Unit Name"),
                         dict(name="geographic_unit_type", attr="Geographic Unit Type"),
                         dict(name="geographic_scheme", attr="Geographic Scheme"),
                         dict(name="scheme_code", attr="Scheme Code"),
                         dict(name="cbsa_title", attr="CBSA Title")]),
        dict(name="code_value", product="DP-013", entity="Code Value", kind="Dimension",
             always_filter=["Code Value Status = 'Active' or the code is still referenced by history"],
             dimensions=[dict(name="code", attr="Code"),
                         dict(name="code_label", attr="Code Label")]),

        # ===== Wave E9 (CD-296, CD-315, CD-342): the enterprise dimensions =========================================
        # Every enterprise master is SCD type 2: unless a consuming model joins on its fact's own date, a dimension shows
        # the version in force on the as-of date (CURRENT).

        # --- DP-240 Enterprise Party & Role Master: the one 02 party (PTY-) behind every external organization role ---
        dict(name="party", product="DP-240", entity="Party", kind="Dimension",
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="party_name", attr="Party Display Name",
                              note="Personal data where Party Type = individual; broad roles see organization names through "
                                   "the issuer, counterparty, custodian and vendor tables"),
                         dict(name="party_type", attr="Party Type"),
                         dict(name="party_status", attr="Party Status"),
                         dict(name="party_origin", attr="Party Origin"),
                         dict(name="party_legal_name", attr="Legal Name"),
                         dict(name="party_legal_form", attr="Legal Form"),
                         dict(name="party_legal_jurisdiction", attr="Legal Jurisdiction"),
                         dict(name="party_industry_classification", attr="Industry Classification"),
                         dict(name="primary_regulator", attr="Primary Regulator",
                              note="Also answers the dropped Regulated Entity Indicator (blank = not regulated; CW-902)")],
             hidden=[("Primary Country", "Flagged as personal data; organization location is Legal Jurisdiction."),
                     ("Given Name", "Personal data about individual parties; no cross-row question needs it."),
                     ("Family Name", "Personal data about individual parties; no cross-row question needs it."),
                     ("Preferred Name", "Personal data about individual parties; no cross-row question needs it."),
                     ("Date of Death", "Personal data; a servicing detail, not a slicer."),
                     ("Merged Into Party", "Survivorship plumbing: merged records are excluded by Party Status.")]),
        # The legal parent chain: the same party table role-played as ultimate parent (group) and direct parent.
        dict(name="parent_group", product="DP-240", entity="Party", kind="Dimension",
             always_filter=["Party ID is the Ultimate Parent of at least one party, or a party with no parent (its own group)"],
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="parent_group_name", attr="Party Display Name"),
                         dict(name="parent_group_jurisdiction", attr="Legal Jurisdiction")]),
        dict(name="direct_parent", product="DP-240", entity="Party", kind="Dimension",
             always_filter=["Party ID is the Direct Parent of at least one party"],
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="direct_parent_name", attr="Party Display Name")]),
        # The legal parent chain, from the DP-240 Legal Entity Hierarchy entity (CW-902): one row per subsidiary and parent.
        dict(name="legal_entity_hierarchy", product="DP-240", entity="Legal Entity Hierarchy", kind="Bridge",
             grain="subsidiary party x direct parent x relationship basis x effective period",
             always_filter=["Parent Relationship Basis = 'Accounting Consolidation'"],   # one legal parent chain per party
             default_filter=f"Hierarchy row {CURRENT}",
             dimensions=[dict(name="party_ultimate_parent", attr="Ultimate Parent",
                              note="Party ID of the ultimate legal parent; shown by name through parent_group"),
                         dict(name="party_direct_parent", attr="Direct Parent",
                              note="Party ID of the direct legal parent; shown by name through direct_parent"),
                         dict(name="parent_relationship_basis", attr="Parent Relationship Basis")]),
        dict(name="party_role", product="DP-240", entity="Party Role", kind="Bridge",
             grain="party x role type x role effective period",
             default_filter=f"Role {CURRENT}",
             dimensions=[dict(name="role_type", attr="Role Type"),
                         dict(name="role_status", attr="Role Status"),
                         dict(name="role_business_line", attr="Role Business Line")]),
        dict(name="party_identifier", product="DP-240", entity="Party Identifier", kind="Bridge",
             grain="party x identifier scheme x identifier value",
             always_filter=["Identifier Status = 'Active'"],
             dimensions=[dict(name="party_identifier_scheme", attr="Identifier Scheme",
                              note="LEI, SEC CIK, BIC and the other schemes; CIK and BIC are Party Identifier rows (CW-902)"),
                         dict(name="party_identifier_value", attr="Identifier Value", note="For lookup (LEI, CIK, BIC, CRD); not a slicer"),
                         dict(name="lei_registration_status", attr="LEI Registration Status")]),
        dict(name="party_relationship", product="DP-240", entity="Party Relationship", kind="Bridge",
             grain="from party x to party x relationship type x effective period",
             default_filter=f"Relationship {CURRENT}",
             dimensions=[dict(name="party_relationship_type", attr="Relationship Type")]),

        # ===== WP2 wealth dimensions (plan section 8.4): Household, Client, Client Account, Program and Channel ==========
        # --- Household and client (DP-240; the household is a 02 party of Party Type Household, PTY-HH-; CLA-A ruling 5) ---
        dict(name="household", product="DP-240", entity="Party", kind="Dimension",
             always_filter=["Party Type = 'Household'"],
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="household_name", attr="Household Name", note="Personal data; client-facing roles only"),
                         dict(name="household_formation_basis", attr="Household Formation Basis"),
                         dict(name="household_status", attr="Party Status"),
                         dict(name="household_relationship_stage", attr="Relationship Stage")],
             hidden=[("Primary Member", "Party ID of an individual (personal data); the member roles are on household_membership."),
                     ("Membership Last Confirmed Date", "A stewardship date; household data quality is the product's own check.")]),
        # Household to client is many-to-many and effective dated: a household metric counts the membership in force on its
        # own measurement date (the period end for snapshot facts), never every historical membership.
        dict(name="household_membership", product="DP-240", entity="Household Membership", kind="Bridge",
             grain="household x household member x membership effective period",
             always_filter=["Membership Status = 'Active'",
                            "Membership Effective From <= the measurement date < Membership Effective To (or open): the "
                            "membership in force on the fact's own date (period end for snapshots, the as-of date otherwise)"],
             dimensions=[dict(name="household_member_role", attr="Household Member Role")]),
        dict(name="client", product="DP-240", entity="Party", kind="Dimension",
             always_filter=["Party Type <> 'Household' and the party holds a Party Role with Role Type = 'Client' open on the as-of date"],
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="client_party_type", attr="Party Type", note="Individual, trust, corporation and the other client types"),
                         dict(name="client_status", attr="Party Status"),
                         dict(name="client_relationship_stage", attr="Relationship Stage"),
                         dict(name="client_party_origin", attr="Party Origin")],
             hidden=[("Date of Birth", "Personal data; age bands are derived in the consumer models (SM-21), never the date."),
                     ("Tax Identification Number", "Never published (DP-240 DQ5)."),
                     ("Citizenship Countries", "Personal data; no cross-row question needs it in the shared layer."),
                     ("AML Risk Rating", "Restricted onboarding view only (DP-240)."),
                     ("PEP Status", "Restricted onboarding view only (DP-240)."),
                     ("Sanctions Screening Result", "Restricted onboarding view only (DP-240)."),
                     ("KYC Status", "A stewardship status; KYC quality is the product's own check.")]),
        dict(name="client_segment", product="DP-240", entity="Segment Assignment", kind="Bridge",
             grain="party x segmentation scheme x segment effective period",
             default_filter=f"Segment {CURRENT}",
             dimensions=[dict(name="client_segmentation_scheme", attr="Segmentation Scheme"),
                         dict(name="client_segment", attr="Segment"),
                         dict(name="segment_assignment_method", attr="Assignment Method")]),
        dict(name="client_regulatory_classification", product="DP-240", entity="Regulatory Classification", kind="Dimension",
             always_filter=["Categorization Date = the latest categorization date on or before the as-of date, per party"],
             dimensions=[dict(name="reg_bi_retail_customer", attr="Reg BI Retail Customer Indicator"),
                         dict(name="finra_institutional_account", attr="FINRA Institutional Account Indicator"),
                         dict(name="client_investor_category", attr="Investor Category")]),

        # --- Client Account (DP-093 Account Master; every account kind is a 15 account, CW-035) ------------------------
        dict(name="client_account", product="DP-093", entity="Account", kind="Dimension",
             default_filter=f"Account version {CURRENT}",
             dimensions=[dict(name="account_type", attr="Account Type"),
                         dict(name="account_registration_type", attr="Account Registration Type"),
                         dict(name="account_status", attr="Account Status"),
                         dict(name="account_business_line", attr="Account Business Line"),
                         dict(name="account_purpose", attr="Account Purpose"),
                         dict(name="reg_t_account_type", attr="Reg T Account Type"),
                         dict(name="entity_account", attr="Entity Account Indicator"),
                         dict(name="carrying_entity", attr="Carrying Entity", note="Legal Entity ID; shown through internal_legal_entity"),
                         dict(name="account_open_date", attr="Account Open Date"),
                         dict(name="account_close_date", attr="Account Close Date"),
                         dict(name="application_channel", attr="Application Channel",
                              note="How the account was applied for (web, phone, advisor, rollover); not the distribution channel"),
                         dict(name="application_received_date", attr="Application Received Date"),
                         dict(name="good_order_date", attr="Good Order Date"),
                         dict(name="closure_reason", attr="Closure Reason"),
                         dict(name="networking_level", attr="Networking Level", note="Intermediary-held fund accounts only"),
                         dict(name="tax_reporting_regimes", attr="Tax Reporting Regimes"),
                         dict(name="custodial_state", attr="Custodial State", note="UTMA and UGMA accounts"),
                         dict(name="plan_529_state", attr="529 Plan State")],
             hidden=[("Account Name", "Personal data; never published in the semantic layer (DP-093 analytics view)."),
                     ("External Account Number", "Personal data; never published in the semantic layer."),
                     ("Registration Line 1", "Personal data (registration title); servicing view only."),
                     ("Registration Line 2", "Personal data (registration title); servicing view only."),
                     ("Successor Custodian", "Personal data; servicing view only."),
                     ("Inherited IRA Decedent", "Personal data about a deceased individual; servicing view only."),
                     ("Account Tax Classification", "Personal tax data; tax reporting reads DP-093 directly."),
                     ("Rep of Record", "An external advisor (personal data); intermediary accounts join advisor through DP-001.")]),
        # Joint and entity accounts have several owners: the role bridge is the client-to-account join.
        dict(name="account_party_role", product="DP-093", entity="Account Party Role", kind="Bridge",
             grain="account x party x account role type x role effective period",
             default_filter=f"Role {CURRENT}",
             dimensions=[dict(name="account_role_type", attr="Account Role Type",
                              note="Primary Owner, Joint Owner, Trustee, Custodian and the other account roles")],
             hidden=[("Role Allocation Percentage", "Ownership split per owner (personal data); account facts are not split by it here.")]),
        dict(name="program_enrollment", product="DP-093", entity="Program Enrollment", kind="Bridge",
             grain="account x service offering x enrollment period (ENRL-)",
             default_filter=("Enrollment in force on the measurement date: Enrollment Effective Date <= date and Enrollment "
                             "Termination Date blank or after it"),
             dimensions=[dict(name="enrollment_status", attr="Enrollment Status"),
                         dict(name="enrollment_effective_date", attr="Enrollment Effective Date"),
                         dict(name="enrollment_termination_date", attr="Enrollment Termination Date"),
                         dict(name="enrollment_termination_reason", attr="Enrollment Termination Reason"),
                         dict(name="discretionary_authority", attr="Discretionary Authority Indicator")],
             hidden=[("Reasonable Restrictions", "Client-imposed restrictions (personal data); SM-23's Rule 3a-4 view."),
                     ("Source Recommendation", "Key to the DP-303 recommendation; joined in SM-22, not here.")]),
        dict(name="account_feature", product="DP-093", entity="Account Feature", kind="Bridge",
             grain="account x feature type x effective period (AFEA-)",
             default_filter=f"Feature {CURRENT} and Feature Status = 'Active'",
             dimensions=[dict(name="feature_type", attr="Feature Type", note="Margin, options, short selling, fully paid lending and others"),
                         dict(name="feature_status", attr="Feature Status"),
                         dict(name="feature_approval_date", attr="Feature Approval Date")],
             hidden=[("Feature Approved By", "A named principal (personal data); supervision is SM-29's."),
                     ("Options Approval Level", "Flagged personal data; options approvals are reviewed in SM-29."),
                     ("Portfolio Margin Indicator", "Flagged personal data; margin analytics are SM-24's.")]),
        dict(name="account_sweep_election", product="DP-093", entity="Cash Sweep Election", kind="Bridge",
             grain="account x sweep vehicle type x election effective period",
             default_filter=f"Election {CURRENT}",
             dimensions=[dict(name="sweep_vehicle_type", attr="Sweep Vehicle Type",
                              note="Bank deposit sweep or money market fund sweep"),
                         dict(name="elected_sweep_program", attr="Elected Sweep Program",
                              note="Key of the sweep program; the program banks behind it are DP-431's (SM-24)")]),

        # --- Channel (no channel master exists: the account's channel is the 06 Account Channel Assignment of DP-008, a
        # certified source product read here as the account-to-channel bridge; the channel members are the shared
        # Distribution Channel code list in DP-013) --------------------------------------------------------------------
        dict(name="account_channel", product="DP-008", entity="Account Channel Assignment", kind="Bridge",
             grain="account x assigned distribution channel x channel effective period (CHASG-)",
             always_filter=["Channel Effective From <= the measurement date and Channel Effective To blank or on or after it: "
                            "the channel in force on the fact's own date, one per account"],
             dimensions=[dict(name="distribution_channel", attr="Assigned Distribution Channel",
                              note="A Distribution Channel code (for example Direct - Digital Advice, Direct - Human Advice, "
                                   "Direct - Trust); named through distribution_channel"),
                         dict(name="channel_business_line", attr="Assigned Business Line")]),
        dict(name="distribution_channel", product="DP-013", entity="Code Value", kind="Dimension",
             always_filter=["Code List Key = the Distribution Channel code list"],
             dimensions=[dict(name="channel_code", attr="Code"),
                         dict(name="channel_name", attr="Code Label"),
                         dict(name="channel_group", attr="Parent Code", note="The channel roll-up one level up (for example Direct)"),
                         dict(name="channel_code_status", attr="Code Value Status")]),

        # --- DP-097 Security Master & Identifiers (Confidential - Licensed) ------------------------------------------
        dict(name="instrument", product="DP-097", entity="Instrument", kind="Dimension",
             default_filter=f"Instrument version {CURRENT}",
             dimensions=[dict(name="instrument_name", attr="Instrument Name"),
                         dict(name="fisn", attr="FISN"),
                         dict(name="instrument_type", attr="Instrument Type"),
                         dict(name="instrument_asset_class", attr="Asset Class"),
                         dict(name="cfi_code", attr="CFI Code"),
                         dict(name="denomination_currency", attr="Denomination Currency"),
                         dict(name="country_of_issue", attr="Country of Issue"),
                         dict(name="instrument_status", attr="Instrument Status"),
                         dict(name="issue_date", attr="Issue Date"),
                         dict(name="private_instrument", attr="Private Instrument Indicator"),
                         dict(name="primary_data_provider", attr="Primary Data Provider"),
                         dict(name="instrument_issuer", attr="Issuer", note="Party ID of the issuer; shown through issuer"),
                         dict(name="own_share_class", attr="Own Share Class", note="Set only for the firm's own share classes"),
                         dict(name="fund_vehicle_type", attr="Fund Vehicle Type"),
                         dict(name="coupon_type", attr="Coupon Type"),
                         dict(name="coupon_rate", attr="Coupon Rate", note="Per instrument; for banding, never summed"),
                         dict(name="maturity_date", attr="Maturity Date"),
                         dict(name="debt_seniority", attr="Debt Seniority"),
                         dict(name="callable", attr="Callable Indicator"),
                         dict(name="tax_exempt", attr="Tax-Exempt Indicator"),
                         dict(name="inflation_linked", attr="Inflation-Linked Indicator"),
                         dict(name="in_default", attr="In Default Indicator"),
                         dict(name="sustainable_bond_label", attr="Sustainable Bond Label"),
                         dict(name="securitized_collateral_type", attr="Securitized Collateral Type"),
                         dict(name="expiry_date", attr="Expiry Date"),
                         dict(name="otc_asset_class", attr="OTC Asset Class"),
                         dict(name="private_asset_type", attr="Private Asset Type"),
                         dict(name="vintage_year", attr="Vintage Year")],
             hidden=[("Amount Outstanding", "A per-issue vendor figure on a dimension; holdings and exposures come from the fact models."),
                     ("Shares Outstanding", "A per-issue vendor figure; fund shares outstanding are the certified SM-11 metric.")]),
        dict(name="instrument_identifier", product="DP-097", entity="Instrument Identifier", kind="Bridge",
             grain="instrument x identifier scheme x identifier value x effective period",
             always_filter=["Instrument Identifier Status = 'Active'"],
             default_filter=f"Identifier {CURRENT}",
             dimensions=[dict(name="instrument_identifier_scheme", attr="Instrument Identifier Scheme"),
                         dict(name="instrument_identifier_value", attr="Instrument Identifier Value",
                              note="ISIN, CUSIP, SEDOL, FIGI or ticker for lookup; CUSIP and SEDOL are licensed"),
                         dict(name="primary_identifier", attr="Primary Identifier Indicator")]),
        dict(name="instrument_listing", product="DP-097", entity="Instrument Listing", kind="Bridge",
             grain="instrument x venue MIC x effective period",
             default_filter=f"Listing {CURRENT} and Listing Status = 'Active'",
             dimensions=[dict(name="listing_venue_mic", attr="Listing Venue MIC"),
                         dict(name="listing_ticker", attr="Listing Ticker"),
                         dict(name="listing_trading_currency", attr="Listing Trading Currency"),
                         dict(name="primary_listing", attr="Primary Listing Indicator")]),
        dict(name="instrument_classification", product="DP-097", entity="Instrument Classification Assignment", kind="Bridge",
             grain="instrument x classification scheme x classification code x effective period",
             default_filter=f"Instrument Classification Scheme = the firm asset-class scheme and assignment {CURRENT}",
             dimensions=[dict(name="instrument_classification_scheme", attr="Instrument Classification Scheme"),
                         dict(name="instrument_classification_code", attr="Instrument Classification Code"),
                         dict(name="classification_override", attr="Instrument Classification Override Indicator")]),
        dict(name="instrument_regulatory", product="DP-097", entity="Regulatory Instrument Classification", kind="Dimension",
             default_filter=f"Regulatory classification {CURRENT}",   # one row per instrument on the as-of date
             dimensions=[dict(name="rule_2a7_eligible", attr="Rule 2a-7 Eligible Security Indicator"),
                         dict(name="rule_144a", attr="Rule 144A Indicator"),
                         dict(name="regulation_s", attr="Regulation S Indicator"),
                         dict(name="restricted_security", attr="Restricted Security Indicator"),
                         dict(name="naic_designation", attr="NAIC Designation Category")]),
        dict(name="instrument_relationship", product="DP-097", entity="Instrument Relationship", kind="Bridge",
             grain="subject instrument x related instrument or index x relationship type x effective period",
             default_filter=f"Relationship {CURRENT}",
             dimensions=[dict(name="instrument_relationship_type", attr="Instrument Relationship Type")],
             facts=[dict(name="relationship_ratio", attr="Relationship Ratio", note="Per link (conversion or underlying ratio); never summed"),
                    dict(name="basket_weight", attr="Basket Weight", note="Sums to 1 within one basket only")]),

        # --- DP-098 Issuer Hierarchy, Classifications & Ratings (Confidential - Licensed) ---------------------------
        dict(name="issuer", product="DP-098", entity="Issuer", kind="Dimension",
             always_filter=["An Issuer Profile exists for the party"],
             default_filter=f"Issuer profile {CURRENT}",
             dimensions=[dict(name="issuer_name", attr="Party Display Name"),
                         dict(name="issuer_type", attr="Issuer Type"),
                         dict(name="issuer_status", attr="Issuer Profile Status"),
                         dict(name="country_of_risk", attr="Country of Risk"),
                         dict(name="country_of_risk_basis", attr="Country of Risk Basis"),
                         dict(name="issuer_legal_jurisdiction", attr="Legal Jurisdiction"),
                         dict(name="cusip_issuer_number", attr="CUSIP Issuer Number", note="Licensed identifier, for lookup"),
                         dict(name="composite_rating_notch", attr="Composite Agency Rating Notch",
                              note="The issuer's composite long-term notch (middle of three, lower of two); for banding, never summed"),
                         dict(name="investment_grade", attr="Investment Grade Flag", note="Y, N or blank when unrated")],
             hidden=[("Primary Country", "Flagged as personal data on the party; issuer location is Country of Risk."),
                     ("Given Name", "Issuers are organizations; the party name fields for individuals are not used."),
                     ("Family Name", "Issuers are organizations; the party name fields for individuals are not used.")]),
        # The credit parent (who stands behind the debt) can differ from the legal ultimate parent: a separate role table.
        dict(name="credit_parent", product="DP-098", entity="Issuer", kind="Dimension",
             always_filter=["Party ID is the Related Party of an open Issuer Relationship with Issuer Relationship Type = 'Credit Parent'"],
             dimensions=[dict(name="credit_parent_name", attr="Party Display Name")]),
        dict(name="issuer_credit_parent_link", product="DP-098", entity="Issuer Relationship", kind="Bridge",
             grain="issuer x related party x issuer relationship type x effective period",
             always_filter=["Issuer Relationship Type = 'Credit Parent'"],   # guarantor and other types would double count
             default_filter=f"Relationship {CURRENT}",
             dimensions=[dict(name="guarantee_coverage", attr="Guarantee Coverage"),
                         dict(name="credit_parent_override_reason", attr="Override Reason")]),
        dict(name="issuer_sector", product="DP-098", entity="Issuer Classification Assignment", kind="Bridge",
             grain="issuer x classification scheme x sector code x effective period",
             always_filter=["Primary Sector Scheme Indicator = 'Y'"],   # one primary sector per issuer
             default_filter=f"Classification {CURRENT}",
             dimensions=[dict(name="issuer_sector_scheme", attr="Issuer Classification Scheme"),
                         dict(name="issuer_sector_code", attr="Issuer Sector Code")]),
        dict(name="current_credit_rating", product="DP-098", entity="Credit Rating Assignment", kind="Bridge",
             grain="rated instrument or issuer x credit rating agency x credit rating type (current rating)",
             always_filter=["Credit Rating Effective To is blank (the rating in force)"],
             dimensions=[dict(name="credit_rating_agency", attr="Credit Rating Agency"),
                         dict(name="credit_rating_type", attr="Credit Rating Type"),
                         dict(name="credit_rating_value", attr="Credit Rating Value", note="Agency scale; licensed"),
                         dict(name="normalized_rating_notch", attr="Normalized Credit Rating Notch"),
                         dict(name="credit_rating_outlook", attr="Credit Rating Outlook"),
                         dict(name="credit_rating_watch", attr="Credit Rating Watch Status")]),
        dict(name="credit_rating_action", product="DP-098", entity="Credit Rating Assignment", kind="Fact",
             grain="rated instrument or issuer x credit rating agency x credit rating type x action date",
             dimensions=[dict(name="rating_action_agency", attr="Credit Rating Agency"),
                         dict(name="rating_action_type", attr="Credit Rating Type"),
                         dict(name="credit_rating_action", attr="Credit Rating Action"),
                         dict(name="credit_rating_action_date", attr="Credit Rating Action Date")]),

        # --- DP-115 Approved Broker & Counterparty Master (CD-315) ---------------------------------------------------
        dict(name="counterparty", product="DP-115", entity="Counterparty", kind="Dimension",
             always_filter=["An approved counterparty profile exists for the party"],
             default_filter=f"Counterparty profile {CURRENT}",
             dimensions=[dict(name="counterparty_name", attr="Party Display Name"),
                         dict(name="counterparty_tier", attr="Counterparty Tier"),
                         dict(name="counterparty_approval_status", attr="Counterparty Approval Status"),
                         dict(name="next_review_due_date", attr="Next Review Due Date"),
                         dict(name="review_frequency", attr="Review Frequency"),
                         dict(name="counterparty_legal_jurisdiction", attr="Legal Jurisdiction"),
                         dict(name="counterparty_lei_status", attr="LEI Registration Status"),
                         dict(name="counterparty_ultimate_parent", attr="Ultimate Parent",
                              note="Parent group for limits; shown through parent_group")],
             hidden=[("Primary Country", "Flagged as personal data on the party; location is Legal Jurisdiction."),
                     ("Given Name", "Counterparties are organizations; the individual name fields are not used."),
                     ("Family Name", "Counterparties are organizations; the individual name fields are not used.")]),
        dict(name="counterparty_scope", product="DP-115", entity="Counterparty Approval Scope", kind="Bridge",
             grain="counterparty x approved activity x trading entity x fund (optional) x effective period",
             default_filter=f"Scope {CURRENT}",
             dimensions=[dict(name="approved_activity", attr="Approved Activity"),
                         dict(name="scope_status", attr="Scope Status"),
                         dict(name="scope_countries", attr="Scope Countries"),
                         dict(name="trading_agreement_required", attr="Trading Agreement Required Indicator")]),
        dict(name="counterparty_limit", product="DP-115", entity="Counterparty Trading Limit", kind="Fact",
             grain="counterparty x limit type x trading entity x fund (optional) x effective period",
             always_filter=["Limit Effective From <= the as-of date < Limit Effective To (or open)"],   # one version per limit
             dimensions=[dict(name="limit_type", attr="Limit Type"),
                         dict(name="maximum_tenor_months", attr="Maximum Tenor Months")],
             facts=[dict(name="limit_amount", attr="Limit Amount", note="No currency attribute; see open decisions")]),
        dict(name="counterparty_review", product="DP-115", entity="Counterparty Review", kind="Fact",
             grain="counterparty x review date",
             dimensions=[dict(name="counterparty_review_date", attr="Counterparty Review Date"),
                         dict(name="credit_view", attr="Credit View"),
                         dict(name="counterparty_review_outcome", attr="Counterparty Review Outcome"),
                         dict(name="status_after_review", attr="Status After Review")],
             hidden=[("Counterparty Reviewer", "A named employee (personal data); no cross-row question needs it.")]),

        # --- DP-140 Portfolio Master & Mandate Link (CD-324: the only portfolio-to-fund mapping) --------------------
        dict(name="portfolio", product="DP-140", entity="Portfolio", kind="Dimension",
             default_filter=f"Portfolio version {CURRENT}",
             dimensions=[dict(name="portfolio_name", attr="Portfolio Name",
                              note="Can name a client (flagged personal data); entitled roles only"),
                         dict(name="portfolio_type", attr="Portfolio Type"),
                         dict(name="portfolio_business_line", attr="Business Line"),
                         dict(name="portfolio_status", attr="Portfolio Status"),
                         dict(name="portfolio_base_currency", attr="Base Currency"),
                         dict(name="portfolio_inception_date", attr="Inception Date"),
                         dict(name="portfolio_termination_date", attr="Termination Date"),
                         dict(name="ibor_operating_model", attr="IBOR Operating Model"),
                         dict(name="middle_office_provider", attr="Middle Office Provider", note="Party ID; shown through party"),
                         dict(name="proprietary_capital", attr="Proprietary Capital Indicator"),
                         dict(name="full_discretion", attr="Full Discretion Indicator"),
                         dict(name="tax_aware_management", attr="Tax-Aware Management Indicator")]),   # Vintage Year removed with 30 (CW-930)
        dict(name="parent_portfolio", product="DP-140", entity="Portfolio", kind="Dimension",
             always_filter=["Portfolio ID is the Parent Portfolio of an effective 'Sleeve Of' Portfolio Hierarchy Link"],
             default_filter=f"Portfolio version {CURRENT}",
             dimensions=[dict(name="parent_portfolio_name", attr="Portfolio Name", note="Entitled roles only, as portfolio_name")]),
        dict(name="portfolio_sleeve_link", product="DP-140", entity="Portfolio Hierarchy Link", kind="Bridge",
             grain="parent portfolio x child portfolio x link type x effective period",
             always_filter=["Portfolio Hierarchy Link Type = 'Sleeve Of'"],   # carve-out, aggregation and successor links would double count
             default_filter=f"Link {CURRENT}",
             dimensions=[dict(name="look_through_roll_up", attr="Look-Through Roll-Up Indicator")]),
        dict(name="portfolio_implementation", product="DP-140", entity="Portfolio Implementation Link", kind="Bridge",
             grain="portfolio x implemented product, mandate, account or model x link type x effective period",
             default_filter=f"Link {CURRENT}",
             dimensions=[dict(name="implementation_link_type", attr="Implementation Link Type"),
                         dict(name="primary_implementation", attr="Primary Implementation Indicator")]),
        dict(name="portfolio_mandate", product="DP-140", entity="Investment Mandate", kind="Dimension",
             dimensions=[dict(name="portfolio_mandate_name", attr="Mandate Name", note="Client-confidential; named-client roles only"),
                         dict(name="portfolio_mandate_type", attr="Mandate Type")]),

        # --- DP-167 Custody Network & Safekeeping Accounts -----------------------------------------------------------
        dict(name="safekeeping_account", product="DP-167", entity="Safekeeping Account", kind="Dimension",
             default_filter=f"Account version {CURRENT}",
             dimensions=[dict(name="safekeeping_account_type", attr="Safekeeping Account Type"),
                         dict(name="account_holding_model", attr="Account Holding Model"),
                         dict(name="safekeeping_account_currency", attr="Account Currency"),
                         dict(name="safekeeping_account_status", attr="Safekeeping Account Status"),
                         dict(name="safekeeping_opened_date", attr="Account Opened Date"),
                         dict(name="safekeeping_closed_date", attr="Account Closed Date")],
             hidden=[("Safekeeping Account Number", "Personal data where the account is a client's; operational lookups only."),
                     ("Safekeeping Account Name", "Can name a client (personal data); operational lookups only."),
                     ("Cash Account IBAN", "Personal data; payment detail, not a slicer.")]),
        dict(name="safekeeping_assignment", product="DP-167", entity="Safekeeping Account Assignment", kind="Bridge",
             grain="safekeeping account x owner (fund, portfolio or client account) x purpose x effective period",
             default_filter=f"Assignment {CURRENT}",
             dimensions=[dict(name="account_assignment_purpose", attr="Account Assignment Purpose")],
             hidden=[("Owning Client Account", "Personal data; client accounts are joined in the client models, not shown here.")]),
        dict(name="custodian", product="DP-167", entity="Custodian", kind="Dimension",
             always_filter=["Provider Profile Status = 'Active'"],
             default_filter=f"Profile {CURRENT}",
             dimensions=[dict(name="custody_provider_role", attr="Custody Provider Role"),
                         dict(name="services_provided", attr="Services Provided"),
                         dict(name="supported_message_standards", attr="Supported Message Standards")]),
        # Custody providers are 02 parties: DP-167's conformed Party role-played as the account provider / global
        # custodian and as the sub-custodian, so the network can be drilled by name.
        dict(name="custody_provider", product="DP-167", entity="Party", kind="Dimension",
             always_filter=["Party ID is the Account Provider of a safekeeping account, a Custodian Provider Party or an Arrangement Global Custodian"],
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="custodian_name", attr="Party Display Name"),
                         dict(name="custodian_jurisdiction", attr="Legal Jurisdiction")]),
        dict(name="sub_custodian", product="DP-167", entity="Party", kind="Dimension",
             always_filter=["Party ID is the Sub-Custodian of a Sub-Custodian Network Arrangement"],
             default_filter=f"Party version {CURRENT}",
             dimensions=[dict(name="sub_custodian_name", attr="Party Display Name")]),
        dict(name="sub_custody_arrangement", product="DP-167", entity="Sub-Custodian Network Arrangement", kind="Bridge",
             grain="global custodian x market x sub-custodian x effective period",
             default_filter=f"Arrangement {CURRENT}",
             dimensions=[dict(name="arrangement_market", attr="Arrangement Market"),
                         dict(name="market_holding_model", attr="Market Holding Model"),
                         dict(name="arrangement_status", attr="Arrangement Status")]),

        # --- DP-190 Chart of Accounts & Ledger (Confidential - Financial) --------------------------------------------
        dict(name="chart_of_accounts", product="DP-190", entity="Chart of Accounts", kind="Dimension",
             dimensions=[dict(name="chart_code", attr="Chart of Accounts Code"),
                         dict(name="chart_name", attr="Chart of Accounts Name"),
                         dict(name="chart_status", attr="Chart Status")]),
        dict(name="gl_account", product="DP-190", entity="GL Account", kind="Dimension",
             default_filter=f"GL account version {CURRENT}",
             dimensions=[dict(name="natural_account_number", attr="Natural Account Number"),
                         dict(name="gl_account_name", attr="GL Account Name"),
                         dict(name="gl_account_type", attr="GL Account Type"),
                         dict(name="normal_balance", attr="Normal Balance"),
                         dict(name="financial_statement_class", attr="Financial Statement Class"),
                         dict(name="subledger_control", attr="Subledger Control Account Indicator"),
                         dict(name="gl_account_status", attr="GL Account Status")]),
        dict(name="gl_summary_account", product="DP-190", entity="GL Account", kind="Dimension",
             always_filter=["GL Account ID is the Parent Summary Account of at least one GL account"],
             default_filter=f"GL account version {CURRENT}",
             dimensions=[dict(name="summary_account_number", attr="Natural Account Number"),
                         dict(name="summary_account_name", attr="GL Account Name")]),
        # Model gap: DP-190's Cost Center entity holds every chart segment; the cost center table pins the segment.
        dict(name="cost_center", product="DP-190", entity="Cost Center", kind="Dimension",
             always_filter=["Chart Segment = 'Cost Center'"],
             default_filter=f"Segment value {CURRENT}",
             dimensions=[dict(name="cost_center_code", attr="Segment Value Code"),
                         dict(name="cost_center_name", attr="Segment Value Name"),
                         dict(name="cost_center_status", attr="Segment Value Status")]),
        dict(name="parent_cost_center", product="DP-190", entity="Cost Center", kind="Dimension",
             always_filter=["Chart Segment = 'Cost Center'", "the value is the Parent Segment Value of at least one cost center"],
             default_filter=f"Segment value {CURRENT}",
             dimensions=[dict(name="parent_cost_center_code", attr="Segment Value Code"),
                         dict(name="parent_cost_center_name", attr="Segment Value Name")]),
        dict(name="chart_segment_value", product="DP-190", entity="Cost Center", kind="Dimension",
             always_filter=["Chart Segment <> 'Cost Center'"],   # company, profit center, product, channel, intercompany
             default_filter=f"Segment value {CURRENT}",
             dimensions=[dict(name="chart_segment", attr="Chart Segment"),
                         dict(name="segment_value_code", attr="Segment Value Code"),
                         dict(name="segment_value_name", attr="Segment Value Name"),
                         dict(name="segment_value_status", attr="Segment Value Status")]),
        dict(name="ledger", product="DP-190", entity="Ledger", kind="Dimension",
             dimensions=[dict(name="ledger_code", attr="Ledger ID"),
                         dict(name="accounting_basis", attr="Accounting Basis"),
                         dict(name="ledger_role", attr="Ledger Role"),
                         dict(name="ledger_currency", attr="Ledger Currency")]),
        dict(name="financial_statement_line", product="DP-190", entity="Financial Statement Line", kind="Dimension",
             dimensions=[dict(name="statement_line_code", attr="Statement Line Code"),
                         dict(name="reporting_framework", attr="Line Reporting Framework"),
                         dict(name="statement_type", attr="Line Statement Type"),
                         dict(name="external_reporting_line", attr="External Reporting Line")]),
        dict(name="statement_line_mapping", product="DP-190", entity="Financial Statement Line Mapping", kind="Bridge",
             grain="GL account x statement line x effective period",
             default_filter=f"Mapping {CURRENT}, for one reporting framework at a time",
             dimensions=[dict(name="revenue_disaggregation_category", attr="Revenue Disaggregation Category")]),
        dict(name="accounting_period_status", product="DP-190", entity="Accounting Period Status", kind="Bridge",
             grain="ledger x fiscal period",
             dimensions=[dict(name="period_close_status", attr="Period Close Status"),
                         dict(name="hard_close_date", attr="Hard Close Date")]),

        # --- DP-192 Employee & Position Master: read for the Employee dimension (CD-342). DP-192 sits in SM-15, which
        # owns the certified headcount; SM-00 reads its Employee entity as a certified-metric source (CONTRACT.md).
        dict(name="employee", product="DP-192", entity="Employee", kind="Dimension",
             default_filter=f"Worker version {CURRENT}",
             dimensions=[dict(name="employee_name", attr="Preferred Name", note="Personal data; HR and entitled roles only"),
                         dict(name="employee_job_title", attr="Job Title", note="Flagged personal data in DP-192"),
                         dict(name="employee_job_family", attr="Job Family", note="Flagged personal data in DP-192"),
                         dict(name="employee_employment_type", attr="Employment Type", note="Flagged personal data in DP-192"),
                         dict(name="employee_employment_status", attr="Employment Status", note="Flagged personal data in DP-192"),
                         dict(name="employee_legal_entity", attr="Employing Legal Entity",
                              note="Join key to internal_legal_entity; flagged personal data in DP-192"),
                         dict(name="employee_home_org_unit", attr="Home Org Unit",
                              note="Join key to org_unit; flagged personal data in DP-192"),
                         dict(name="employee_work_location", attr="Work Location", note="Flagged personal data in DP-192"),
                         dict(name="contingent_worker_type", attr="Contingent Worker Type",
                              note="Blank for employees; contingent workers are outside Certified Headcount")],
             hidden=[("Legal First Name", "Personal data; Preferred Name serves entitled roles."),
                     ("Legal Last Name", "Personal data; Preferred Name serves entitled roles."),
                     ("Business Email Address", "Personal data; no cross-row question needs it."),
                     ("National Identifier", "Special category of identifier; never published in the semantic layer."),
                     ("Work Authorization Expiry Date", "Restricted HR detail (DP-192 restricted extension view only)."),
                     ("Hire Date", "Personal data; tenure and movement questions are SM-15's."),
                     ("Termination Date", "Personal data; Employment Status shows leavers.")]),

        # --- DP-210 Vendor Master ----------------------------------------------------------------------------------
        dict(name="vendor", product="DP-210", entity="Vendor", kind="Dimension",
             always_filter=["A supplier profile exists for the party"],
             default_filter=f"Supplier profile {CURRENT}",
             dimensions=[dict(name="vendor_name", attr="Party Display Name"),
                         dict(name="supplier_status", attr="Supplier Status"),
                         dict(name="erp_supplier_number", attr="ERP Supplier Number"),
                         dict(name="vendor_legal_jurisdiction", attr="Legal Jurisdiction"),
                         dict(name="vendor_lei_status", attr="LEI Registration Status"),
                         dict(name="default_payment_terms", attr="Default Payment Terms")],
             hidden=[("Diversity Certifications", "Can identify individual owners (personal data); answered in the supplier diversity report."),
                     ("Supplier Relationship Manager", "A named employee (personal data)."),
                     ("Primary Country", "Flagged as personal data on the party; location is Legal Jurisdiction.")]),
        dict(name="supplier_engagement", product="DP-210", entity="Supplier Engagement", kind="Dimension",
             default_filter=f"Engagement version {CURRENT}",
             dimensions=[dict(name="service_description", attr="Service Description"),
                         dict(name="engagement_status", attr="Engagement Status"),
                         dict(name="engagement_start_date", attr="Engagement Start Date"),
                         dict(name="engagement_end_date", attr="Engagement End Date"),
                         dict(name="engagement_business_lines", attr="Engagement Business Lines"),
                         dict(name="fund_paid", attr="Fund-Paid Indicator"),
                         dict(name="fund_service_provider_role", attr="Fund Service Provider Role")],
             hidden=[("Engagement Business Owner", "A named employee (personal data); joined to employee for entitled roles.")]),
        dict(name="supplier_risk_tier", product="DP-210", entity="Supplier Risk Tiering", kind="Dimension",
             default_filter=f"Tier {CURRENT}",   # one tier per engagement on the as-of date
             dimensions=[dict(name="criticality_tier", attr="Third-Party Criticality Tier"),
                         dict(name="criticality_drivers", attr="Criticality Drivers"),
                         dict(name="due_diligence_depth", attr="Due-Diligence Depth")]),
        dict(name="supplier_category", product="DP-210", entity="Supplier Category Assignment", kind="Bridge",
             grain="engagement x procurement category x effective period",
             default_filter=f"Category {CURRENT}",
             dimensions=[dict(name="procurement_category", attr="Procurement Category"),
                         dict(name="unspsc_code", attr="UNSPSC Code")]),
        dict(name="supplier_contract_profile", product="DP-210", entity="Supplier Contract Profile", kind="Bridge",
             grain="contract with a supplier contract profile (lists the engagements it governs)",
             dimensions=[dict(name="exit_assistance_period", attr="Exit Assistance Period")]),

        # --- DP-211 Application & System Inventory --------------------------------------------------------------------
        dict(name="application", product="DP-211", entity="Application", kind="Dimension",
             default_filter=f"Application version {CURRENT}",
             dimensions=[dict(name="application_name", attr="Application Name"),
                         dict(name="application_type", attr="Application Type"),
                         dict(name="hosting_model", attr="Hosting Model"),
                         dict(name="software_product_name", attr="Software Product Name"),
                         dict(name="application_status", attr="Application Status"),
                         dict(name="application_criticality_tier", attr="Criticality Tier"),
                         dict(name="confidentiality_impact", attr="Confidentiality Impact Level"),
                         dict(name="integrity_impact", attr="Integrity Impact Level"),
                         dict(name="availability_impact", attr="Availability Impact Level"),
                         dict(name="internet_facing", attr="Internet-Facing Indicator"),
                         dict(name="production_go_live_date", attr="Production Go-Live Date"),
                         dict(name="decommission_date", attr="Decommission Date"),
                         dict(name="recovery_tier", attr="Recovery Tier"),
                         dict(name="recovery_time_objective_hours", attr="Recovery Time Objective Hours",
                              note="Per application; for banding, never summed")],
             hidden=[("Human Oversight Assignee", "A named employee (personal data); AI oversight is reported in SM-17.")]),
        dict(name="application_ownership", product="DP-211", entity="Application Ownership Assignment", kind="Bridge",
             grain="application x ownership role x role holder x effective period",
             default_filter=f"Ownership {CURRENT}",
             dimensions=[dict(name="application_ownership_role", attr="Application Ownership Role")],
             hidden=[("Application Role Holder", "Employee ID of the holder; names come from employee for entitled roles.")]),
        dict(name="application_capability", product="DP-211", entity="Application Capability Mapping", kind="Bridge",
             grain="application x business capability x effective period",
             default_filter=f"Mapping {CURRENT}",
             dimensions=[dict(name="business_capability", attr="Supported Business Capability", note="Text until GAP-41-001 is resolved"),
                         dict(name="capability_support_role", attr="Capability Support Role"),
                         dict(name="business_lines_served", attr="Business Lines Served")]),
        dict(name="application_lifecycle", product="DP-211", entity="Application Lifecycle Assessment", kind="Dimension",
             always_filter=["Lifecycle Assessment Date = the latest assessment of the application"],   # one row per application
             dimensions=[dict(name="time_rating", attr="TIME Rating"),
                         dict(name="lifecycle_assessment_date", attr="Lifecycle Assessment Date"),
                         dict(name="target_retirement_date", attr="Target Retirement Date")]),
        dict(name="it_service", product="DP-211", entity="IT Service", kind="Dimension",
             dimensions=[dict(name="it_service_name", attr="IT Service Name"),
                         dict(name="it_service_category", attr="IT Service Category"),
                         dict(name="ict_service_type", attr="ICT Service Type"),
                         dict(name="it_service_status", attr="IT Service Status")],
             hidden=[("IT Service Owner", "A named employee (personal data).")]),

        # --- DP-212 Model Inventory & Validation ----------------------------------------------------------------------
        dict(name="model_version", product="DP-212", entity="Model", kind="Dimension",
             dimensions=[dict(name="model_name", attr="Model Name"),
                         dict(name="model_version_number", attr="Model Version"),
                         dict(name="model_type", attr="Model Type"),
                         dict(name="model_purpose", attr="Model Purpose"),
                         dict(name="model_vendor", attr="Model Vendor"),
                         dict(name="model_use_status", attr="Model Use Status")],
             hidden=[("Model Owner", "A named employee (personal data); joined to employee for entitled roles.")]),
        dict(name="model_tier", product="DP-212", entity="Model Tier Assignment", kind="Dimension",
             default_filter=f"Tier {CURRENT}",   # one tier per model on the as-of date
             dimensions=[dict(name="model_tier", attr="Model Tier"),
                         dict(name="model_materiality", attr="Model Materiality"),
                         dict(name="model_complexity", attr="Model Complexity"),
                         dict(name="model_uncertainty", attr="Model Uncertainty")]),
        dict(name="model_validation", product="DP-212", entity="Model Validation", kind="Fact",
             grain="model version x validation sequence",
             dimensions=[dict(name="model_validation_type", attr="Model Validation Type"),
                         dict(name="model_validation_outcome", attr="Model Validation Outcome"),
                         dict(name="model_validation_completed_date", attr="Model Validation Completed Date"),
                         dict(name="external_validator", attr="External Validator")],
             hidden=[("Internal Validator", "A named employee (personal data).")]),
        dict(name="latest_model_validation", product="DP-212", entity="Model Validation", kind="Dimension",
             always_filter=["Model Validation Sequence = the highest sequence for the model version"],   # one row per version
             dimensions=[dict(name="latest_validation_outcome", attr="Model Validation Outcome"),
                         dict(name="latest_validation_date", attr="Model Validation Completed Date")]),
        dict(name="model_monitoring", product="DP-212", entity="Model Performance Monitoring", kind="Fact",
             grain="model version x monitoring test x period end date",
             dimensions=[dict(name="monitoring_test", attr="Monitoring Test"),
                         dict(name="monitoring_period_end_date", attr="Monitoring Period End Date"),
                         dict(name="monitoring_breached", attr="Monitoring Threshold Breached Indicator")]),
        dict(name="model_deployment", product="DP-212", entity="AI System Model Deployment", kind="Bridge",
             grain="AI system (application) x model version x effective period",
             default_filter=f"Deployment {CURRENT}",
             dimensions=[dict(name="model_deployment_from", attr="Model Deployment Effective From")]),

        # --- DP-213 Enterprise Contract Register (Restricted - Legal) ---------------------------------------------------
        dict(name="contract", product="DP-213", entity="Contract", kind="Dimension",
             default_filter=f"Contract version {CURRENT}",
             dimensions=[dict(name="contract_title", attr="Contract Title"),
                         dict(name="contract_family", attr="Contract Family"),
                         dict(name="contract_subtype", attr="Contract Subtype"),
                         dict(name="contract_hierarchy_role", attr="Contract Hierarchy Role"),
                         dict(name="contract_status", attr="Contract Status"),
                         dict(name="contract_effective_date", attr="Contract Effective Date"),
                         dict(name="contract_expiry_date", attr="Contract Expiry Date"),
                         dict(name="contract_governing_law", attr="Governing Law"),
                         dict(name="typed_record_type", attr="Typed Record Type"),
                         dict(name="contract_business_lines", attr="Contract Business Lines")],
             hidden=[("Legal Owner", "A named employee (personal data); joined to employee for legal roles.")]),
        dict(name="parent_contract", product="DP-213", entity="Contract", kind="Dimension",
             always_filter=["Contract ID is the Parent Contract of at least one contract"],
             default_filter=f"Contract version {CURRENT}",
             dimensions=[dict(name="parent_contract_title", attr="Contract Title"),
                         dict(name="parent_contract_family", attr="Contract Family")]),
        dict(name="contract_party", product="DP-213", entity="Contract Party", kind="Bridge",
             grain="contract x party role x party (external or internal) x effective period",
             default_filter=f"Contract party {CURRENT}",
             dimensions=[dict(name="contract_party_role", attr="Contract Party Role")],
             hidden=[("External Contract Party", "Party ID of an external party, flagged personal data (can be an individual); "
                                                 "organization names come from party for legal roles."),
                     ("Notice Contact Point", "Personal data; a servicing detail.")]),
        dict(name="contract_key_date", product="DP-213", entity="Contract Key Date", kind="Fact",
             grain="contract x key date type x sequence",
             dimensions=[dict(name="key_date_type", attr="Key Date Type"),
                         dict(name="key_date_value", attr="Key Date Value"),
                         dict(name="key_date_action_status", attr="Key Date Action Status")]),
        dict(name="contract_clause", product="DP-213", entity="Contract Clause Position", kind="Bridge",
             grain="contract x clause type",
             dimensions=[dict(name="clause_type", attr="Clause Type"),
                         dict(name="clause_position", attr="Clause Position")]),
    ],

    # The menu other models join to. DP-240 Party, DP-001 Party and DP-004 Service Offering are each published here in
    # several roles (household, client; firm, office, team; offering, program); a consuming model names the entity and
    # the role table in its relationship.
    shared=[
        # ---- WP2 wealth dimensions (plan section 8.4) -------------------------------------------------------------------
        # Household: DP-240/Party (Party Type = Household) with DP-240/Household Membership; Client: DP-240/Party (Client
        # role); Client Account: DP-093/Account with DP-093/Account Party Role and DP-093/Program Enrollment; Advisor:
        # DP-009/Employee with DP-009/Coverage Assignment; Offering and Program: DP-004/Service Offering, DP-004/Service
        # Tier, DP-004/Model Portfolio; Channel: DP-008/Account Channel Assignment named through DP-013/Code Value.
        "DP-240/Household Membership", "DP-240/Segment Assignment", "DP-240/Regulatory Classification",
        "DP-093/Account", "DP-093/Account Party Role", "DP-093/Program Enrollment", "DP-093/Account Feature",
        "DP-093/Cash Sweep Election",
        "DP-004/Service Offering", "DP-004/Service Tier", "DP-004/Platform Product Availability",
        "DP-008/Account Channel Assignment",
        # ---- Intermediary and institutional parties ---------------------------------------------------------------------
        "DP-001/Party", "DP-001/Legal Entity Hierarchy",
        "DP-001/Financial Professional", "DP-001/External Classification",   # WP1 re-point (CW-202)
        "DP-001/Distributor Firm", "DP-001/Branch / Office", "DP-001/Employment Affiliation",
        "DP-001/Partner Coverage Assignment",
        "DP-003/Institutional Client", "DP-003/Party Relationship", "DP-003/Regulatory Classification",
        "DP-003/Investment Mandate", "DP-003/Account", "DP-003/Service Relationship",
        "DP-004/Share Class", "DP-004/Investment Product", "DP-004/Investment Strategy", "DP-004/Model Portfolio",
        "DP-005/Distribution Agreement", "DP-005/Agreement Party Role", "DP-005/Agreement Product Coverage",
        "DP-005/Shelf Placement", "DP-005/Partner Program", "DP-005/Payment Arrangement", "DP-005/Partner Research Rating",
        "DP-009/Employee", "DP-009/Advisor Role Assignment", "DP-009/Coverage Team", "DP-009/Coverage Team Membership",
        "DP-009/Coverage Model", "DP-009/Coverage Assignment", "DP-009/Service Tier Assignment",
        "DP-013/Calendar Date", "DP-013/Fiscal Period", "DP-013/Internal Legal Entity", "DP-013/Org Unit",
        "DP-013/Org Hierarchy Link", "DP-013/Country", "DP-013/Currency", "DP-013/Geographic Unit", "DP-013/Code Value",
        # Wave E9 enterprise dimensions (CD-296). DP-192 Employee is published as the employee table but cannot be listed
        # here because DP-192 is an SM-15 product (see open decisions).
        "DP-240/Party", "DP-240/Legal Entity Hierarchy", "DP-240/Party Role", "DP-240/Party Identifier", "DP-240/Party Relationship",
        "DP-097/Instrument", "DP-097/Instrument Identifier", "DP-097/Instrument Listing",
        "DP-097/Instrument Classification Assignment", "DP-097/Regulatory Instrument Classification",
        "DP-097/Instrument Relationship",
        "DP-098/Issuer", "DP-098/Issuer Relationship", "DP-098/Issuer Classification Assignment", "DP-098/Credit Rating Assignment",
        "DP-115/Counterparty", "DP-115/Counterparty Approval Scope", "DP-115/Counterparty Trading Limit", "DP-115/Counterparty Review",
        "DP-140/Portfolio", "DP-140/Portfolio Implementation Link", "DP-140/Portfolio Hierarchy Link", "DP-140/Investment Mandate",
        "DP-167/Safekeeping Account", "DP-167/Safekeeping Account Assignment",
        "DP-167/Custodian", "DP-167/Sub-Custodian Network Arrangement",
        "DP-190/Chart of Accounts", "DP-190/GL Account", "DP-190/Cost Center", "DP-190/Ledger",
        "DP-190/Financial Statement Line", "DP-190/Financial Statement Line Mapping", "DP-190/Accounting Period Status",
        "DP-210/Vendor", "DP-210/Supplier Engagement", "DP-210/Supplier Risk Tiering", "DP-210/Supplier Category Assignment",
        "DP-210/Supplier Contract Profile",
        "DP-211/Application", "DP-211/Application Ownership Assignment", "DP-211/Application Capability Mapping",
        "DP-211/Application Lifecycle Assessment", "DP-211/IT Service",
        "DP-212/Model", "DP-212/Model Tier Assignment", "DP-212/Model Validation", "DP-212/Model Performance Monitoring",
        "DP-212/AI System Model Deployment",
        "DP-213/Contract", "DP-213/Contract Party", "DP-213/Contract Key Date", "DP-213/Contract Clause Position",
    ],

    relationships=[
        # Partner firm and its legal parent. Advisors reach their firm and office through advisor_affiliation (05 Employment
        # Affiliation, CW-132); the 05 Hierarchy Node and Team Membership are not published (thin intermediary channel).
        dict(frm="distributor_firm_parent", to="distributor_firm", on="distributor_firm_parent.subsidiary_party = distributor_firm.party_id",
             type="one-to-one", warning="One open Accounting Consolidation row per firm; a firm with no row is its own group."),
        dict(frm="distributor_firm_parent", to="parent_group", on="distributor_firm_parent.ultimate_parent = parent_group.party_id",
             type="many-to-one"),
        # WP1 re-point (CW-202): the segment is DP-001's 05 External Classification, keyed by Classified Party.
        dict(frm="advisor_segment", to="advisor", on="advisor_segment.classified_party = advisor.party_id",
             type="many-to-many",
             warning="One row per classification vendor. With one vendor selected each advisor has one segment; with several "
                     "selected, each advisor is counted once per vendor."),
        # WP1 (CW-132): the restored 05 profiles
        dict(frm="distributor_firm_profile", to="distributor_firm", on="distributor_firm_profile.distributor_firm_party = distributor_firm.party_id",
             type="one-to-one"),
        dict(frm="intermediary_branch", to="distributor_office", on="intermediary_branch.branch_party = distributor_office.party_id",
             type="one-to-one"),
        dict(frm="advisor_affiliation", to="advisor", on="advisor_affiliation.affiliated_professional = advisor.party_id",
             type="many-to-one", warning="An advisor dually affiliated (for example a BD and an RIA) has two open rows; "
                                        "filter affiliation_type to count each advisor once."),
        dict(frm="advisor_affiliation", to="distributor_firm", on="advisor_affiliation.employing_firm = distributor_firm.party_id",
             type="many-to-one"),
        dict(frm="advisor_affiliation", to="intermediary_branch", on="advisor_affiliation.office_of_record = intermediary_branch.branch_party",
             type="many-to-one"),
        dict(frm="partner_coverage", to="distributor_firm", on="partner_coverage.covered_party = distributor_firm.party_id",
             type="many-to-one", warning="Coverage can also be set on a branch or advisor party; this join keeps firm coverage."),
        dict(frm="partner_coverage", to="employee", on="partner_coverage.covering_employee = employee.employee_id",
             type="many-to-one"),

        # Institutional parties: consultant and plan provider links are 02 Party Relationship rows (CW-902)
        dict(frm="institutional_client_classification", to="institutional_client",
             on="institutional_client_classification.classified_party = institutional_client.party_id", type="one-to-one"),
        dict(frm="consultant_relationship", to="institutional_client", on="consultant_relationship.to_party = institutional_client.party_id",
             type="many-to-one",
             warning="A client can have several current consultants (e.g. a general consultant and an OCIO). Grouping client facts "
                     "by consultant counts that client under each one; consultant rows do not add up to the total."),
        dict(frm="consultant_relationship", to="consultant", on="consultant_relationship.from_party = consultant.party_id",
             type="many-to-one"),
        dict(frm="retirement_plan", to="institutional_client", on="retirement_plan.plan_sponsor = institutional_client.party_id",
             type="many-to-one", warning="Only sponsors that also hold the Institutional Client role match; other sponsors drop out."),
        dict(frm="plan_provider_relationship", to="retirement_plan", on="plan_provider_relationship.to_party = retirement_plan.party_id",
             type="many-to-one"),
        dict(frm="plan_provider_relationship", to="recordkeeper", on="plan_provider_relationship.from_party = recordkeeper.party_id",
             type="many-to-one",
             warning="A plan can have several service providers; joining to recordkeeper keeps only providers in the Recordkeeper "
                     "role, but a plan with two recordkeepers (e.g. during a conversion) counts under each."),
        dict(frm="investment_mandate", to="institutional_client", on="investment_mandate.client = institutional_client.party_id",
             type="many-to-one"),
        dict(frm="institutional_account", to="retirement_plan", on="institutional_account.related_retirement_plan = retirement_plan.(sponsor_ein, plan_number)",
             type="many-to-one"),
        dict(frm="institutional_client_profile", to="institutional_client",
             on="institutional_client_profile.institutional_client_party = institutional_client.party_id", type="one-to-one"),
        dict(frm="institutional_service_relationship", to="institutional_client",
             on="institutional_service_relationship.client = institutional_client.party_id", type="many-to-one",
             warning="A client can hold several service relationships (for example OCIO and a CIT-only plan); filter one "
                     "servicing_segment to count each client once."),
        dict(frm="institutional_service_relationship", to="consultant",
             on="institutional_service_relationship.advising_consultant = consultant.party_id", type="many-to-one"),
        dict(frm="investment_mandate", to="investment_strategy", on="investment_mandate.implemented_strategy = investment_strategy.strategy_id",
             type="many-to-one"),

        # Products
        dict(frm="share_class", to="investment_product", on="share_class.parent_product = investment_product.product_id", type="many-to-one"),
        dict(frm="investment_product", to="investment_strategy", on="investment_product.implemented_strategy = investment_strategy.strategy_id",
             type="many-to-one"),
        dict(frm="model_portfolio", to="investment_strategy", on="model_portfolio.implemented_strategy = investment_strategy.strategy_id",
             type="many-to-one"),
        dict(frm="share_class", to="currency", on="share_class.share_class_currency = currency.currency_code", type="many-to-one"),

        # Agreements and shelf
        dict(frm="agreement_party", to="distribution_agreement", on="agreement_party.distribution_agreement_key = distribution_agreement.agreement_id",
             type="many-to-one"),
        dict(frm="agreement_party", to="distributor_firm", on="agreement_party.agreement_party = distributor_firm.party_id",
             type="many-to-one",
             warning="An agreement can name several partner parties (e.g. selling dealer and clearing firm); agreement rows "
                     "grouped by partner repeat under each."),
        dict(frm="agreement_coverage", to="distribution_agreement", on="agreement_coverage.distribution_agreement_key = distribution_agreement.agreement_id",
             type="many-to-one"),
        dict(frm="agreement_coverage", to="share_class", on="agreement_coverage.covered_share_class = share_class.share_class_id",
             type="many-to-one", warning="Coverage stated by product or vehicle type has no share class; it is expanded to the share classes it covers."),
        dict(frm="shelf_placement", to="distributor_firm", on="shelf_placement.shelf_partner = distributor_firm.party_id", type="many-to-one"),
        dict(frm="shelf_placement", to="share_class", on="shelf_placement.placed_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="shelf_placement", to="distribution_agreement", on="shelf_placement.distribution_agreement_key = distribution_agreement.agreement_id",
             type="many-to-one", warning="The key is derived by matching partner and share class to agreement coverage on the same date (GAP-05-006); null where no agreement matches."),
        dict(frm="payment_arrangement", to="distribution_agreement", on="payment_arrangement.governing_agreement = distribution_agreement.agreement_id",
             type="many-to-one"),
        dict(frm="partner_program", to="distributor_firm", on="partner_program.program_sponsor = distributor_firm.party_id", type="many-to-one"),
        dict(frm="partner_research_rating", to="distributor_firm", on="partner_research_rating.research_provider = distributor_firm.party_id",
             type="many-to-one"),
        dict(frm="partner_research_rating", to="investment_product", on="partner_research_rating.rated_product = investment_product.product_id",
             type="many-to-one"),

        # The firm's advisors, coverage teams and household coverage (DP-009, CW-062)
        dict(frm="advisor_role", to="firm_advisor", on="advisor_role.role_advisor = firm_advisor.employee_id", type="one-to-one"),
        dict(frm="firm_advisor", to="org_unit", on="firm_advisor.home_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="firm_advisor", to="internal_legal_entity", on="firm_advisor.employing_legal_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="coverage_team_membership", to="firm_advisor", on="coverage_team_membership.member_advisor = firm_advisor.employee_id",
             type="many-to-one"),
        dict(frm="coverage_team_membership", to="coverage_team", on="coverage_team_membership.member_coverage_team = coverage_team.coverage_team_id",
             type="many-to-many",
             warning="An advisor can sit on more than one coverage team (e.g. a pod and a pairing). Grouping advisor facts by "
                     "team counts that advisor under each team; use capacity_allocation_percentage to split."),
        dict(frm="coverage_team", to="coverage_model", on="coverage_team.coverage_model_key = coverage_model.coverage_model_code",
             type="many-to-one"),
        dict(frm="coverage_assignment", to="firm_advisor", on="coverage_assignment.covering_advisor = firm_advisor.employee_id",
             type="many-to-one"),
        dict(frm="coverage_assignment", to="coverage_team", on="coverage_assignment.covering_coverage_team = coverage_team.coverage_team_id",
             type="many-to-one"),
        dict(frm="coverage_assignment", to="party", on="coverage_assignment.covered_party = party.party_id", type="many-to-many",
             warning="A household or client can be covered by several advisors in different roles. Filter primary_coverage = 'Y' "
                     "and one party_coverage_role to count each covered party once."),
        dict(frm="coverage_assignment", to="service_tier", on="coverage_assignment.service_tier_assignment_key = service_tier.(tier_party, assigned_service_tier, tier_effective_from)",
             type="many-to-one"),

        # Calendars and reference
        dict(frm="calendar_date", to="fiscal_month",
             on="calendar_date.calendar_date between fiscal_month.period_start_date and fiscal_month.period_end_date", type="many-to-one"),
        dict(frm="fiscal_month", to="fiscal_quarter",
             on="fiscal_month.period_start_date between fiscal_quarter.period_start_date and fiscal_quarter.period_end_date",
             type="many-to-one"),
        dict(frm="org_hierarchy_link", to="org_unit", on="org_hierarchy_link.child_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="org_unit", to="org_division",
             on="the Division-type ancestor of org_unit reached through org_hierarchy_link (recursive until flattened; see open decisions)",
             type="many-to-one"),
        dict(frm="org_unit", to="internal_legal_entity", on="org_unit.employing_booking_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="internal_legal_entity", to="country", on="internal_legal_entity.jurisdiction_of_formation = country.country_code",
             type="many-to-one"),
        dict(frm="geographic_unit", to="country", on="geographic_unit.country = country.country_code", type="many-to-one"),
        dict(frm="country", to="currency", on="country.default_currency = currency.currency_code", type="many-to-one"),

        # ===== WP2 wealth dimensions ==================================================================================
        # Household and client (DP-240). Household to client to account is many-to-many and effective dated (CW-011).
        dict(frm="household", to="party", on="household.party_id = party.party_id (a household is a 02 party, PTY-HH-)",
             type="one-to-one"),
        dict(frm="client", to="party", on="client.party_id = party.party_id", type="one-to-one"),
        dict(frm="household_membership", to="household", on="household_membership.household = household.party_id",
             type="many-to-one"),
        dict(frm="household_membership", to="client", on="household_membership.household_member = client.party_id",
             type="many-to-many",
             warning="A household has several members, and a client can sit in two households while a re-householding is "
                     "open or across dates. Grouping client or account facts by household repeats a client under each "
                     "household it belongs to on that date; household metrics count the membership in force on their own "
                     "measurement date (always filter) and count households, not member rows."),
        dict(frm="client_segment", to="client", on="client_segment.segmented_party = client.party_id", type="many-to-one",
             warning="One row per segmentation scheme; filter one client_segmentation_scheme before grouping."),
        dict(frm="client_segment", to="household", on="client_segment.segmented_party = household.party_id", type="many-to-one",
             warning="Households are segmented as parties too; filter one client_segmentation_scheme before grouping."),
        dict(frm="client_regulatory_classification", to="client",
             on="client_regulatory_classification.classified_party = client.party_id", type="one-to-one"),
        # Client Account (DP-093)
        dict(frm="account_party_role", to="client_account", on="account_party_role.role_account = client_account.account_id",
             type="many-to-one"),
        dict(frm="account_party_role", to="client", on="account_party_role.role_party = client.party_id", type="many-to-many",
             warning="A joint or entity account has several owners and a client has many accounts. Grouping account facts "
                     "by client counts a joint account under each owner; filter account_role_type = 'Primary Owner' to "
                     "count each account once."),
        dict(frm="client_account", to="household",
             on="the household of the account's Primary Owner: account_party_role (Primary Owner, open on the measurement "
                "date) to household_membership (in force on the measurement date) to household",
             type="many-to-many",
             warning="Household-to-account is many-to-many and effective dated: an account whose owners sit in different "
                     "households appears under each, and membership changes move accounts between households over time. "
                     "Pin the membership as of the fact's measurement date; household totals do not add up to the firm "
                     "total where owners span households."),
        dict(frm="client_account", to="internal_legal_entity", on="client_account.carrying_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="client_account", to="distributor_firm", on="client_account.dealer_of_record = distributor_firm.party_id",
             type="many-to-one", warning="Intermediary-held and networked fund accounts only; direct accounts have no dealer of record."),
        dict(frm="client_account", to="intermediary_branch", on="client_account.branch_of_record = intermediary_branch.branch_party",
             type="many-to-one", warning="Intermediary accounts only."),
        dict(frm="program_enrollment", to="client_account", on="program_enrollment.enrolled_account = client_account.account_id",
             type="many-to-one",
             warning="An account can hold an advice enrollment and a trust or planning enrollment at once; account facts "
                     "grouped by program repeat under each open enrollment. Filter one program_type to count each account once."),
        dict(frm="program_enrollment", to="program", on="program_enrollment.enrolled_service_offering = program.offering_id",
             type="many-to-one"),
        dict(frm="program", to="service_offering", on="program.offering_id = service_offering.offering_id (one OFFR- key)",
             type="one-to-one"),
        dict(frm="account_feature", to="client_account", on="account_feature.feature_account = client_account.account_id",
             type="many-to-one", warning="Several features per account (margin and options); filter one feature_type before grouping."),
        dict(frm="account_sweep_election", to="client_account",
             on="account_sweep_election.sweep_election_account = client_account.account_id", type="many-to-one",
             warning="One open election per account is the rule (DP-093 Sweep Election Coverage %); accounts with none have no row."),
        dict(frm="institutional_account", to="client_account", on="institutional_account.account_id = client_account.account_id (one 15 ACC- key)",
             type="one-to-one", warning="DP-003 Account is the institutional view of the same 15 account (CW-035)."),
        dict(frm="portfolio_implementation", to="client_account", on="portfolio_implementation.managed_account = client_account.account_id",
             type="many-to-one", warning="Only managed-account links carry an account; other link types have none."),
        # Advisor and coverage of households and accounts (DP-009)
        dict(frm="coverage_assignment", to="household", on="coverage_assignment.covered_party = household.party_id",
             type="many-to-many",
             warning="A household can be covered by several advisors in different roles; filter primary_coverage = 'Y' and one "
                     "party_coverage_role to count each household once."),
        dict(frm="coverage_assignment", to="client_account", on="coverage_assignment.covered_account = client_account.account_id",
             type="many-to-one", warning="Account-level coverage only; most coverage is set on the household or client."),
        dict(frm="service_tier", to="household", on="service_tier.tier_party = household.party_id", type="many-to-one",
             warning="Tiers are assigned to households and to clients without a household; the household join keeps households only."),
        dict(frm="service_tier", to="offering_service_tier", on="service_tier.assigned_service_tier = offering_service_tier.service_tier_code",
             type="many-to-one"),
        # Offering and Program (DP-004)
        dict(frm="offering_service_tier", to="service_offering", on="offering_service_tier.service_offering_key = service_offering.offering_id",
             type="many-to-one", warning="Blank for firm-wide tiers that are not tied to one offering."),
        dict(frm="service_offering", to="model_portfolio", on="model_portfolio.model_portfolio_id in service_offering.model_portfolios_used",
             type="many-to-many",
             warning="An offering uses several model portfolios and a model serves several offerings; the list is expanded to "
                     "one row per model, so offering counts grouped by model repeat."),
        dict(frm="service_offering", to="internal_legal_entity", on="service_offering.sponsoring_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="platform_availability", to="share_class", on="platform_availability.available_share_class = share_class.share_class_id",
             type="many-to-one", warning="Third-party instruments have no share class; they join instrument instead."),
        dict(frm="platform_availability", to="instrument", on="platform_availability.available_third_party_instrument = instrument.instrument_id",
             type="many-to-one", warning="Own share classes join share_class; this join keeps third-party products only."),
        # Channel
        dict(frm="account_channel", to="client_account", on="account_channel.assigned_account = client_account.account_id",
             type="many-to-one",
             warning="One channel per account on a date is the rule; overlapping assignments (a DP-007 quality measure) would "
                     "count the account under both channels."),
        dict(frm="account_channel", to="distribution_channel", on="account_channel.assigned_distribution_channel = distribution_channel.code",
             type="many-to-one"),
        dict(frm="distributor_firm_profile", to="distribution_channel", on="distributor_firm_profile.distribution_channel = distribution_channel.code",
             type="many-to-one"),

        # ===== Wave E9 enterprise dimensions ==========================================================================
        # Party and its legal parent chain (all 02 PTY- keys)
        dict(frm="legal_entity_hierarchy", to="party", on="legal_entity_hierarchy.subsidiary_party = party.party_id", type="one-to-one",
             warning="One open Accounting Consolidation row per party; a party with no row is its own group (the view "
                     "coalesces the group key to the party itself)."),
        dict(frm="legal_entity_hierarchy", to="parent_group", on="legal_entity_hierarchy.ultimate_parent = parent_group.party_id",
             type="many-to-one"),
        dict(frm="legal_entity_hierarchy", to="direct_parent", on="legal_entity_hierarchy.direct_parent = direct_parent.party_id",
             type="many-to-one"),
        dict(frm="direct_parent", to="parent_group",
             on="the direct parent's own legal_entity_hierarchy row: ultimate_parent = parent_group.party_id", type="many-to-one"),
        dict(frm="party_role", to="party", on="party_role.party_key = party.party_id", type="many-to-one",
             warning="A party holds several roles (CD-296 role-played dimension). Grouping party facts by role_type counts a "
                     "multi-role party under each role; pick one role_type to count each party once."),
        dict(frm="party_identifier", to="party", on="party_identifier.party_key = party.party_id", type="many-to-one",
             warning="One row per identifier scheme and value; filter one party_identifier_scheme before grouping."),
        dict(frm="party_relationship", to="party", on="party_relationship.from_party = party.party_id", type="many-to-one"),
        dict(frm="distributor_firm", to="party", on="distributor_firm.party_id = party.party_id (both 02 PTY- keys)", type="one-to-one"),
        dict(frm="institutional_client", to="party", on="institutional_client.party_id = party.party_id (both 02 PTY- keys)",
             type="one-to-one"),
        dict(frm="internal_legal_entity", to="party", on="internal_legal_entity.party_master_cross_reference = party.party_id",
             type="one-to-one", warning="The firm's own entities are mastered in DP-013 (LEN-); the 02 party is their mirror (CD-010)."),

        # Instruments and issuers
        dict(frm="instrument", to="issuer", on="instrument.issuer = issuer.party_id", type="many-to-one",
             warning="Own fund share classes and derivative contracts usually have no issuer profile; they fall into an 'Unknown issuer' member."),
        dict(frm="instrument", to="share_class", on="instrument.own_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="instrument", to="investment_product", on="instrument.own_investment_product = investment_product.product_id",
             type="many-to-one"),
        dict(frm="instrument", to="currency", on="instrument.denomination_currency = currency.currency_code", type="many-to-one"),
        dict(frm="instrument", to="country", on="instrument.country_of_issue = country.country_code", type="many-to-one"),
        dict(frm="instrument_identifier", to="instrument", on="instrument_identifier.identified_instrument = instrument.instrument_id",
             type="many-to-one", warning="Several identifiers per instrument; filter one scheme or primary_identifier = 'Y' before grouping."),
        dict(frm="instrument_listing", to="instrument", on="instrument_listing.listed_instrument = instrument.instrument_id",
             type="many-to-one", warning="Several listings per instrument; filter primary_listing = 'Y' to keep one."),
        dict(frm="instrument_classification", to="instrument",
             on="instrument_classification.classified_instrument = instrument.instrument_id", type="many-to-one",
             warning="One row per scheme. With the default firm asset-class scheme each instrument has one code; with "
                     "several schemes selected an instrument counts once per scheme."),
        dict(frm="instrument_regulatory", to="instrument",
             on="instrument_regulatory.regulatory_classified_instrument = instrument.instrument_id", type="one-to-one"),
        dict(frm="instrument_relationship", to="instrument", on="instrument_relationship.subject_instrument = instrument.instrument_id",
             type="many-to-many",
             warning="A derivative or basket links to several underlyings and an underlying to many derivatives. Grouping "
                     "instrument facts by related instrument counts the subject under each one."),
        dict(frm="issuer", to="party", on="issuer.party_id = party.party_id (an issuer is a 02 party)", type="one-to-one"),
        dict(frm="issuer", to="parent_group",
             on="legal_entity_hierarchy.ultimate_parent = parent_group.party_id for legal_entity_hierarchy.subsidiary_party = issuer.party_id",
             type="many-to-one", warning="Through the DP-240 legal_entity_hierarchy row of the issuer's party (CW-902)."),
        dict(frm="issuer", to="country", on="issuer.country_of_risk = country.country_code", type="many-to-one"),
        dict(frm="issuer_credit_parent_link", to="issuer", on="issuer_credit_parent_link.subject_issuer = issuer.party_id",
             type="one-to-one", warning="Issuers without a credit parent override roll up to their legal ultimate parent instead."),
        dict(frm="issuer_credit_parent_link", to="credit_parent", on="issuer_credit_parent_link.related_party = credit_parent.party_id",
             type="many-to-one"),
        dict(frm="issuer_sector", to="issuer", on="issuer_sector.classified_issuer = issuer.party_id", type="one-to-one"),
        dict(frm="current_credit_rating", to="instrument", on="current_credit_rating.rated_instrument = instrument.instrument_id",
             type="many-to-many",
             warning="One current rating per agency and rating type. Grouping instrument facts by agency counts the instrument "
                     "under each agency; use issuer.composite_rating_notch for one rating per issuer."),
        dict(frm="current_credit_rating", to="issuer", on="current_credit_rating.rated_issuer = issuer.party_id", type="many-to-many",
             warning="One current issuer rating per agency and rating type; filter one agency or use composite_rating_notch."),
        dict(frm="credit_rating_action", to="issuer", on="credit_rating_action.rated_issuer = issuer.party_id", type="many-to-one"),
        dict(frm="credit_rating_action", to="instrument", on="credit_rating_action.rated_instrument = instrument.instrument_id",
             type="many-to-one"),

        # Counterparties (CD-315)
        dict(frm="counterparty", to="party", on="counterparty.party_id = party.party_id", type="one-to-one"),
        dict(frm="counterparty", to="parent_group", on="counterparty.ultimate_parent = parent_group.party_id", type="many-to-one"),
        dict(frm="counterparty", to="issuer", on="counterparty.party_id = issuer.party_id", type="one-to-one",
             warning="Only counterparties that also issue securities have an issuer row."),
        dict(frm="counterparty_scope", to="counterparty", on="counterparty_scope.scope_counterparty = counterparty.party_id",
             type="many-to-one"),
        dict(frm="counterparty_scope", to="internal_legal_entity", on="counterparty_scope.scope_trading_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="counterparty_scope", to="investment_product", on="counterparty_scope.scope_fund = investment_product.product_id",
             type="many-to-one", warning="Blank for firm-wide scopes; those sit under an 'All funds' member."),
        dict(frm="counterparty_limit", to="counterparty", on="counterparty_limit.limit_counterparty = counterparty.party_id",
             type="many-to-one"),
        dict(frm="counterparty_limit", to="internal_legal_entity", on="counterparty_limit.limit_trading_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="counterparty_limit", to="investment_product", on="counterparty_limit.limit_fund = investment_product.product_id",
             type="many-to-one"),
        dict(frm="counterparty_review", to="counterparty", on="counterparty_review.reviewed_counterparty = counterparty.party_id",
             type="many-to-one"),

        # Portfolios (CD-324)
        dict(frm="portfolio", to="internal_legal_entity", on="portfolio.legal_owner_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="portfolio", to="application", on="portfolio.book_of_record_system = application.application_id", type="many-to-one"),
        dict(frm="portfolio", to="safekeeping_account", on="portfolio.safekeeping_custody_account = safekeeping_account.safekeeping_account_id",
             type="many-to-one"),
        dict(frm="portfolio", to="currency", on="portfolio.base_currency = currency.currency_code", type="many-to-one"),
        dict(frm="portfolio_sleeve_link", to="portfolio", on="portfolio_sleeve_link.child_portfolio = portfolio.portfolio_id",
             type="one-to-one"),
        dict(frm="portfolio_sleeve_link", to="parent_portfolio", on="portfolio_sleeve_link.parent_portfolio = parent_portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="portfolio_implementation", to="portfolio", on="portfolio_implementation.implementing_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="portfolio_implementation", to="investment_product", on="portfolio_implementation.implemented_product = investment_product.product_id",
             type="many-to-many",
             warning="A product can be implemented by more than one portfolio (a master book and shadow or sleeve books) and a "
                     "portfolio can implement a product and a mandate. Filter implementation_link_type and primary_implementation "
                     "= 'Y' to keep one portfolio per product (CD-324)."),
        dict(frm="portfolio_implementation", to="portfolio_mandate", on="portfolio_implementation.implemented_mandate = portfolio_mandate.mandate_id",
             type="many-to-one"),
        dict(frm="portfolio_implementation", to="model_portfolio", on="portfolio_implementation.followed_model_portfolio = model_portfolio.model_portfolio_id",
             type="many-to-one"),
        dict(frm="portfolio_mandate", to="party", on="portfolio_mandate.client = party.party_id", type="many-to-one"),
        dict(frm="portfolio_mandate", to="investment_strategy", on="portfolio_mandate.implemented_strategy = investment_strategy.strategy_id",
             type="many-to-one"),
        dict(frm="portfolio_mandate", to="investment_mandate", on="portfolio_mandate.mandate_id = investment_mandate.mandate_id",
             type="one-to-one", warning="The same mandate is published by DP-003 and DP-140 (see open decisions)."),

        # Custody
        dict(frm="safekeeping_account", to="custody_provider", on="safekeeping_account.account_provider = custody_provider.party_id",
             type="many-to-one", warning="Blank where the firm's own entity safekeeps (Internal Account Provider)."),
        dict(frm="safekeeping_account", to="internal_legal_entity", on="safekeeping_account.internal_account_provider = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="safekeeping_account", to="currency", on="safekeeping_account.account_currency = currency.currency_code", type="many-to-one"),
        dict(frm="safekeeping_assignment", to="safekeeping_account", on="safekeeping_assignment.assigned_safekeeping_account = safekeeping_account.safekeeping_account_id",
             type="many-to-one"),
        dict(frm="safekeeping_assignment", to="portfolio", on="safekeeping_assignment.owning_portfolio = portfolio.portfolio_id",
             type="many-to-many",
             warning="A portfolio holds several accounts (main safekeeping, cash, collateral). Filter account_assignment_purpose "
                     "= 'Main Safekeeping' to keep one account per portfolio."),
        dict(frm="safekeeping_assignment", to="investment_product", on="safekeeping_assignment.owning_fund = investment_product.product_id",
             type="many-to-many", warning="A fund holds several accounts; filter one account_assignment_purpose before grouping."),
        dict(frm="custodian", to="custody_provider", on="custodian.provider_party = custody_provider.party_id", type="many-to-one",
             warning="One profile per provider role (global custodian, sub-custodian, depositary); filter custody_provider_role "
                     "to count each provider once."),
        dict(frm="custodian", to="contract", on="custodian.service_agreement_reference = contract.contract_id", type="many-to-one"),
        dict(frm="sub_custody_arrangement", to="custody_provider", on="sub_custody_arrangement.arrangement_global_custodian = custody_provider.party_id",
             type="many-to-one"),
        dict(frm="sub_custody_arrangement", to="sub_custodian", on="sub_custody_arrangement.sub_custodian = sub_custodian.party_id",
             type="many-to-one"),
        dict(frm="sub_custody_arrangement", to="country", on="sub_custody_arrangement.arrangement_market = country.country_code",
             type="many-to-one"),
        dict(frm="custody_provider", to="party", on="custody_provider.party_id = party.party_id", type="one-to-one"),

        # Chart of accounts and ledger (CD-296)
        dict(frm="gl_account", to="chart_of_accounts", on="gl_account.gl_account_chart = chart_of_accounts.chart_of_accounts_code",
             type="many-to-one"),
        dict(frm="gl_account", to="gl_summary_account", on="gl_account.parent_summary_account = gl_summary_account.gl_account_id",
             type="many-to-one", warning="One hop only until the summary chain is flattened (see open decisions)."),
        dict(frm="cost_center", to="chart_of_accounts", on="cost_center.segment_value_chart = chart_of_accounts.chart_of_accounts_code",
             type="many-to-one"),
        dict(frm="cost_center", to="parent_cost_center", on="cost_center.parent_segment_value = parent_cost_center.segment_value_code",
             type="many-to-one", warning="One hop only until the cost center chain is flattened (see open decisions)."),
        dict(frm="cost_center", to="org_unit", on="cost_center.represented_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="cost_center", to="internal_legal_entity", on="cost_center.represented_legal_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="chart_segment_value", to="internal_legal_entity", on="chart_segment_value.represented_legal_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="chart_segment_value", to="investment_product", on="chart_segment_value.represented_product = investment_product.product_id",
             type="many-to-one"),
        dict(frm="ledger", to="internal_legal_entity", on="ledger.ledger_legal_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="ledger", to="chart_of_accounts", on="ledger.ledger_chart_of_accounts = chart_of_accounts.chart_of_accounts_code",
             type="many-to-one"),
        dict(frm="ledger", to="currency", on="ledger.ledger_currency = currency.currency_code", type="many-to-one"),
        dict(frm="statement_line_mapping", to="gl_account", on="statement_line_mapping.mapped_gl_account = gl_account.gl_account_id",
             type="many-to-many",
             warning="A GL account maps to one line per reporting framework. Grouping balances by statement line across "
                     "frameworks counts each balance once per framework; filter one reporting_framework."),
        dict(frm="statement_line_mapping", to="financial_statement_line", on="statement_line_mapping.mapped_statement_line = financial_statement_line.statement_line_code",
             type="many-to-one"),
        dict(frm="accounting_period_status", to="ledger", on="accounting_period_status.status_ledger = ledger.ledger_id", type="many-to-one"),
        dict(frm="accounting_period_status", to="fiscal_month", on="accounting_period_status.status_fiscal_period = fiscal_month.fiscal_period_id",
             type="many-to-one", warning="Only ledgers on the firm fiscal calendar's monthly periods match fiscal_month."),

        # Employee (CD-342): DP-192 is the firm's employee; firm_advisor is the DP-009 advisor view of the same worker
        dict(frm="employee", to="org_unit", on="employee.home_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="employee", to="internal_legal_entity", on="employee.employing_legal_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="firm_advisor", to="employee", on="firm_advisor.employee_id = employee.employee_id (one EMP- key)", type="one-to-one"),

        # Vendors
        dict(frm="vendor", to="party", on="vendor.party_id = party.party_id", type="one-to-one"),
        dict(frm="vendor", to="parent_group",
             on="legal_entity_hierarchy.ultimate_parent = parent_group.party_id for legal_entity_hierarchy.subsidiary_party = vendor.party_id",
             type="many-to-one", warning="Through the DP-240 legal_entity_hierarchy row of the supplier's party (CW-902)."),
        dict(frm="supplier_engagement", to="vendor", on="supplier_engagement.engaged_supplier = vendor.party_id", type="many-to-one"),
        dict(frm="supplier_engagement", to="internal_legal_entity", on="supplier_engagement.engagement_buying_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="supplier_engagement", to="org_unit", on="supplier_engagement.requesting_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="supplier_engagement", to="employee", on="supplier_engagement.engagement_business_owner = employee.employee_id",
             type="many-to-one"),
        dict(frm="supplier_risk_tier", to="supplier_engagement", on="supplier_risk_tier.tiered_engagement = supplier_engagement.supplier_engagement_id",
             type="one-to-one"),
        dict(frm="supplier_category", to="supplier_engagement", on="supplier_category.categorized_engagement = supplier_engagement.supplier_engagement_id",
             type="many-to-many",
             warning="An engagement can sit in several procurement categories; grouping spend by category counts it under each."),
        dict(frm="supplier_contract_profile", to="contract", on="supplier_contract_profile.profiled_contract = contract.contract_id",
             type="one-to-one"),
        dict(frm="supplier_contract_profile", to="supplier_engagement",
             on="supplier_engagement.supplier_engagement_id in supplier_contract_profile.contracted_engagements", type="many-to-many",
             warning="A contract governs several engagements and an engagement can sit under several contracts; the list is "
                     "expanded to one row per engagement. Engagement rows grouped by contract repeat under each."),

        # Applications and models
        dict(frm="application", to="vendor", on="application.software_vendor = vendor.party_id", type="many-to-one",
             warning="Matched on the vendor party, not the supplier engagement (GAP-40-001)."),
        dict(frm="application", to="org_unit", on="application.owning_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="application", to="internal_legal_entity", on="application.owning_legal_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="application_ownership", to="application", on="application_ownership.owned_application = application.application_id",
             type="many-to-one", warning="Several ownership roles per application; filter one application_ownership_role."),
        dict(frm="application_ownership", to="employee", on="application_ownership.application_role_holder = employee.employee_id",
             type="many-to-one"),
        dict(frm="application_capability", to="application", on="application_capability.mapped_application = application.application_id",
             type="many-to-many",
             warning="An application supports several capabilities; grouping application counts by capability counts it under each."),
        dict(frm="application_lifecycle", to="application", on="application_lifecycle.assessed_application = application.application_id",
             type="one-to-one"),
        dict(frm="it_service", to="application", on="application.application_id in it_service.supporting_applications", type="many-to-many",
             warning="A service runs on several applications and an application supports several services."),
        dict(frm="it_service", to="vendor", on="it_service.third_party_service_provider = vendor.party_id", type="many-to-one"),
        dict(frm="model_version", to="employee", on="model_version.model_owner = employee.employee_id", type="many-to-one"),
        dict(frm="model_version", to="model_tier", on="model_version.model_id = model_tier.tiered_model", type="many-to-one",
             warning="The tier is set per model and applies to each of its versions."),
        dict(frm="model_validation", to="model_version", on="model_validation.validated_model = model_version.(model_id, model_version)",
             type="many-to-one"),
        dict(frm="latest_model_validation", to="model_version", on="latest_model_validation.validated_model = model_version.(model_id, model_version)",
             type="one-to-one"),
        dict(frm="model_monitoring", to="model_version", on="model_monitoring.monitored_model = model_version.(model_id, model_version)",
             type="many-to-one"),
        dict(frm="model_deployment", to="model_version", on="model_deployment.deployed_model = model_version.(model_id, model_version)",
             type="many-to-one"),
        dict(frm="model_deployment", to="application", on="model_deployment.model_deploying_ai_system = application.application_id",
             type="many-to-one", warning="A model version can be deployed in several AI systems; counts by application repeat the model."),

        # Contracts
        dict(frm="contract", to="parent_contract", on="contract.parent_contract = parent_contract.contract_id", type="many-to-one"),
        dict(frm="contract", to="internal_legal_entity", on="contract.contracting_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="contract", to="investment_product", on="contract.contracting_product = investment_product.product_id", type="many-to-one"),
        dict(frm="contract", to="employee", on="contract.legal_owner = employee.employee_id", type="many-to-one"),
        dict(frm="contract_party", to="contract", on="contract_party.party_contract = contract.contract_id", type="many-to-one",
             warning="A contract has several parties; filter one contract_party_role before grouping contracts by party."),
        dict(frm="contract_party", to="party", on="contract_party.external_contract_party = party.party_id", type="many-to-one"),
        dict(frm="contract_party", to="internal_legal_entity", on="contract_party.internal_contract_party = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="contract_key_date", to="contract", on="contract_key_date.key_date_contract = contract.contract_id", type="many-to-one"),
        dict(frm="contract_clause", to="contract", on="contract_clause.clause_contract = contract.contract_id", type="many-to-one"),
    ],

    hierarchies=[
        # WP2 wealth hierarchies
        dict(name="Client account by registration",
             levels=["client_account.account_business_line", "client_account.account_type", "client_account.account_registration_type"]),
        dict(name="Offering and program",
             levels=["service_offering.offering_type", "service_offering.offering_delivery_mode", "service_offering.offering_name"]),
        dict(name="Channel",
             levels=["distribution_channel.channel_group", "distribution_channel.channel_name"]),
        dict(name="Intermediary firm by channel",
             levels=["distributor_firm_profile.firm_distribution_channel", "distributor_firm_profile.firm_registration_type",
                     "distributor_firm.firm_name"]),
        # The partner firm by channel hierarchy is above; the wholesale distributor hierarchy (firm, office, team) is not
        # rebuilt for the thin intermediary channel. The Sales territory hierarchy was dropped with the territories (CW-064).
        dict(name="Advisor organization",
             levels=["org_division.org_division_name", "org_unit.org_unit_name", "firm_advisor.firm_advisor_name"]),
        dict(name="Coverage team",
             levels=["coverage_team.coverage_team_type", "coverage_team.coverage_team_name", "firm_advisor.firm_advisor_name"]),
        dict(name="Product by business line",
             levels=["investment_product.business_line", "investment_product.product_asset_class",
                     "investment_product.product_name", "share_class.share_class_name"]),
        dict(name="Product by strategy",
             levels=["investment_strategy.asset_class", "investment_strategy.strategy_name",
                     "investment_product.product_name", "share_class.share_class_name"]),
        dict(name="Calendar",
             levels=["calendar_date.calendar_year", "calendar_date.calendar_quarter", "calendar_date.calendar_month",
                     "calendar_date.calendar_date"]),
        dict(name="Fiscal calendar",
             levels=["fiscal_quarter.fiscal_year", "fiscal_quarter.fiscal_quarter", "fiscal_month.fiscal_month",
                     "calendar_date.calendar_date"]),
        # Wave E9 enterprise hierarchies. Parent chains roll up one hop until the products publish flattened paths.
        dict(name="Party legal parent chain",
             levels=["parent_group.parent_group_name", "direct_parent.direct_parent_name", "party.party_name"]),
        dict(name="Issuer legal parent chain",
             levels=["parent_group.parent_group_name", "issuer.issuer_name", "instrument.instrument_name"]),
        dict(name="Issuer credit parent",
             levels=["credit_parent.credit_parent_name", "issuer.issuer_name", "instrument.instrument_name"]),
        dict(name="Issuer by sector",
             levels=["issuer_sector.issuer_sector_code", "issuer.issuer_name"]),
        dict(name="Instrument by asset class",
             levels=["instrument.instrument_asset_class", "instrument.instrument_type", "instrument.instrument_name"]),
        dict(name="Counterparty parent group",
             levels=["parent_group.parent_group_name", "counterparty.counterparty_name"]),
        dict(name="Portfolio by business line",
             levels=["portfolio.portfolio_business_line", "portfolio.portfolio_type", "portfolio.portfolio_name"]),
        dict(name="Portfolio hierarchy",
             levels=["parent_portfolio.parent_portfolio_name", "portfolio.portfolio_name"]),
        dict(name="Custody network",
             levels=["custody_provider.custodian_name", "sub_custody_arrangement.arrangement_market", "sub_custodian.sub_custodian_name"]),
        dict(name="Chart of accounts",
             levels=["chart_of_accounts.chart_name", "gl_account.financial_statement_class", "gl_summary_account.summary_account_name",
                     "gl_account.gl_account_name"]),
        dict(name="Cost center by org unit",
             levels=["org_division.org_division_name", "org_unit.org_unit_name", "cost_center.cost_center_name"]),
        dict(name="Cost center roll-up",
             levels=["parent_cost_center.parent_cost_center_name", "cost_center.cost_center_name"]),
        dict(name="Ledger by legal entity",
             levels=["internal_legal_entity.legal_entity_name", "ledger.accounting_basis", "ledger.ledger_code"]),
        dict(name="Enterprise organization",
             levels=["org_division.org_division_name", "org_unit.org_unit_name", "employee.employee_name"]),
        dict(name="Supplier by criticality",
             levels=["supplier_risk_tier.criticality_tier", "vendor.vendor_name", "supplier_engagement.service_description"]),
        dict(name="Application by criticality",
             levels=["application.application_criticality_tier", "application.application_type", "application.application_name"]),
        dict(name="Model by tier",
             levels=["model_tier.model_tier", "model_version.model_type", "model_version.model_name"]),
        dict(name="Contract hierarchy",
             levels=["contract.contract_family", "parent_contract.parent_contract_title", "contract.contract_title"]),
    ],

    metrics=[
        # DP-001
        dict(name="Active Distributor Firm Count", aggregation="count_distinct",
             expr="count(distinct distributor_firm.party_id) where the 'Distributor Firm' Party Role is active and firm_status = 'Active' on the as-of date",
             source=("DP-001", "Active Firm Count"),
             description="Distributor firms we can do business with today: an active firm role and an active party record."),
        # WP1 re-point (CW-202): the advisor metrics are DP-001's (it absorbs the retired DP-002)
        dict(name="Active Advisor Count", aggregation="count_distinct",
             expr="count(distinct advisor.party_id) where advisor_status = 'Active', the 05 Financial Professional Registration "
                  "Status is Active - BD, Active - IA or Active - BD and IA, the Financial Advisor Party Role is open on the "
                  "as-of date, and an advisor_affiliation row is open on that date with an active employing firm",
             source=("DP-001", "Active Advisor Count"),
             description="External financial professionals who are registered, hold an active Financial Advisor role and work "
                         "at an active partner firm today.",
             note="By firm or office through advisor_affiliation; a dually affiliated advisor counts once in the total and "
                  "once under each firm."),
        dict(name="Advisor Profile Completeness %", aggregation="ratio",
             numerator="sum over the selected advisors of the critical profile items populated (Professional Type, "
                       "Registration Status, Individual CRD Number, an open Employment Affiliation with an Office of Record, "
                       "and a Business Model with Practice Data As-Of Date within 180 days)",
             denominator="5 x count(distinct advisor.party_id) for the same advisors",
             source=("DP-001", "Profile Completeness %"),
             description="Share of the five critical advisor profile attributes that are filled in, across the selected advisors.",
             note="Ratio of sums: each advisor weighs the same, so the result equals the average of the per-advisor scores."),
        # WP1 (CW-132): the intermediary channel counts on the restored 05 profiles
        dict(name="Active Intermediary Branches", aggregation="count_distinct",
             expr="count(distinct intermediary_branch.branch_party) whose distributor_office party holds an active Branch / "
                  "Office Party Role open on the as-of date, by branch_type and by the firm the branch's open Hierarchy Node "
                  "rolls up to",
             source=("DP-001", "Active Branch Count"),
             description="Partner branches and offices active today, by branch type and partner firm."),
        dict(name="Intermediary Advisor Moves", aggregation="additive",
             expr="count of advisor_affiliation rows with affiliation_end_date in the selected period and "
                  "affiliation_change_reason in ('Moved to Another Firm', 'Breakaway to Independent RIA', 'Joined Hybrid / "
                  "Independent BD', 'Team Lift-Out')",
             source=("DP-001", "Advisor Moves in Period"),
             description="External advisors who left a partner firm in the period, by the firm left and the reason.",
             note="Grouped by firm, a move counts under the firm the advisor left."),
        dict(name="Active Intermediary Advisor Teams", aggregation="count_distinct",
             expr="count(distinct advisor_team.party_id) with at least one Team Membership open on the as-of date",
             source=("DP-001", "Active Advisor Teams"),
             description="Advisor teams at partner firms with at least one current member.",
             note="The spec's average members per team is a roster figure and is not published (team rosters name people)."),
        dict(name="Covered Intermediary Partners", aggregation="count_distinct",
             expr="count(distinct partner_coverage.covered_party) with partner_primary_coverage = 'Y' open on the as-of date, "
                  "by partner_coverage_role",
             source=("DP-001", "Covered Partner Count"),
             description="Partner firms, branches and advisors with a primary coverage owner at the firm today."),
        dict(name="Intermediary Firms Without Primary Coverage", aggregation="count_distinct",
             expr="Active Distributor Firm Count minus the active firms that are the covered_party of a partner_coverage row "
                  "with partner_primary_coverage = 'Y' open on the as-of date",
             source=("DP-001", "Active Firms Without Primary Coverage"),
             description="Active partner firms nobody at the firm covers as primary coverage, by distribution channel."),
        # DP-003
        dict(name="Consultant-Advised Client Count", aggregation="count_distinct",
             expr="count(distinct consultant_relationship.to_party) for Consults For relationships open on the as-of date",
             source=("DP-003", "Consultant-Advised Client Count"),
             description="Clients with at least one open consultant relationship; by consultant, the clients each one advises.",
             note="A client with two consultants counts once in the total and once under each consultant."),
        dict(name="Recordkeeper Plan Count", aggregation="count_distinct",
             expr="count(distinct plan_provider_relationship.to_party) for Services Plan relationships open on the as-of date "
                  "whose from_party joins recordkeeper (an open Recordkeeper Party Role)",
             source=("DP-003", "Recordkeeper Plan Count"),
             description="Retirement plans served by a recordkeeper, by recordkeeper."),
        dict(name="Institutional Client Profile Completeness %", aggregation="ratio",
             numerator="count(distinct institutional_client.party_id) with client_party_type, client_jurisdiction, "
                       "industry_classification and institutional_client_classification.finra_institutional_investor populated",
             denominator="count(distinct institutional_client.party_id) (parties with an open Institutional Client role)",
             source=("DP-003", "Client Profile Completeness %"),
             description="Share of active institutional clients whose core profile is complete."),
        dict(name="Active Institutional Clients", aggregation="count_distinct",
             expr="count(distinct institutional_client.party_id) with party status Active, an open Institutional Client "
                  "Party Role and at least one institutional_service_relationship in ('Onboarding', 'Active', 'Under Notice'), "
                  "by institutional_client_profile.institutional_client_type and servicing_segment",
             source=("DP-003", "Active Institutional Clients"),
             description="Institutions the firm serves today, by client type and servicing segment.",
             note="A client with two servicing segments counts once in the total and once under each segment."),
        dict(name="Government Entity Clients", aggregation="count_distinct",
             expr="Active Institutional Clients with institutional_client_profile.government_entity = 'Y'",
             source=("DP-003", "Government Entity Clients"),
             description="Active institutional clients that are government entities (the pay-to-play population), by client type."),
        dict(name="ERISA Plan Clients", aggregation="count_distinct",
             expr="Active Institutional Clients with institutional_client_profile.erisa_plan = 'Y'",
             source=("DP-003", "ERISA Plan Clients"),
             description="Active institutional clients that are ERISA plans, by servicing segment."),
        dict(name="Consultant-Led Relationship %", aggregation="ratio",
             numerator="count of institutional_service_relationship rows in ('Onboarding', 'Active', 'Under Notice') with an "
                       "Advising Consultant",
             denominator="count of institutional_service_relationship rows in ('Onboarding', 'Active', 'Under Notice')",
             source=("DP-003", "Consultant-Led Relationship %"),
             description="Share of active institutional service relationships that a consultant advises on, by servicing segment."),
        dict(name="Institutional Mandate Count", aggregation="count_distinct",
             expr="count(distinct investment_mandate.mandate_id) per institutional client, by mandate_type; the share linked "
                  "to an open 15 account through institutional_account.related_mandate is a filter on the same rows",
             source=("DP-003", "Institutional Mandate Count"),
             description="Investment mandates held by institutional clients, by mandate type."),
        # DP-004
        dict(name="Active Share Class Count", aggregation="count_distinct",
             expr="count(distinct share_class.share_class_id) where share_class_status = 'Active' on the as-of date",
             source=("DP-004", "Active Share Class Count"),
             description="Share classes open for business, by product, vehicle type or any product attribute."),
        dict(name="Active Service Offerings", aggregation="count_distinct",
             expr="count(distinct service_offering.offering_id) where offering_status = 'Active' on the as-of date, by "
                  "offering_type, offering_delivery_mode, discretion_type and advisory_capacity",
             source=("DP-004", "Active Service Offerings"),
             description="Advice, managed, brokerage, planning and trust offerings open to clients today, by delivery mode "
                         "and discretion type."),
        dict(name="Platform Available Products", aggregation="count_distinct",
             expr="count of distinct own share classes and third-party instruments on their latest platform_availability row "
                  "on or before the as-of date, by platform_availability_status and transaction_fee_category",
             source=("DP-004", "Platform Availability by Status"),
             description="Own funds and third-party products on the brokerage platform, by availability status and "
                         "transaction fee category.",
             note="Own share classes and third-party instruments are counted together; filter one to compare like with like."),
        # DP-005
        dict(name="Active Shelf Placement Count", aggregation="count_distinct",
             expr="count(distinct shelf_placement.shelf_placement_id) with an active placement status on the as-of date "
                  "(the spec's 'approved, recommended, focus list'; code mapping in open decisions)",
             source=("DP-005", "Active Placement Count"),
             description="Partner shelf placements where a share class is currently approved for sale, by partner, list type or share class."),
        dict(name="Shelf Coverage %", aggregation="ratio",
             numerator="count of distinct (partner, share class) pairs with an active shelf_placement on the as-of date",
             denominator="count of distinct (partner, share class) pairs covered by an open agreement_coverage row of an active "
                         "distribution_agreement with that partner (agreement_party)",
             source=("DP-005", "Shelf Coverage %"),
             description="Of the partners whose agreement lets them sell a share class, the share that actually have it on a shelf.",
             note="Can exceed 100% where a placement has no covering agreement; placement_without_agreement flags those rows."),
        dict(name="Partner Watch List Product Count", aggregation="count_distinct",
             expr="count(distinct partner_research_rating.rated_product) where watch_list = 'Y' on the latest rating date",
             source=("DP-005", "Watch List Count"),
             description="Products a partner's research team has on its watch list, by research provider."),
        dict(name="Active Intermediary Agreements", aggregation="count_distinct",
             expr="count(distinct distribution_agreement.agreement_id) with agreement_status = 'Active' and Agreement "
                  "Effective Date on or before the as-of date, by agreement_type",
             source=("DP-005", "Active Agreement Count"),
             description="Selling, servicing and platform agreements with intermediary partners in force today, by type."),
        dict(name="Active Payment Arrangements", aggregation="count_distinct",
             expr="count(distinct payment_arrangement rows) with payment_arrangement_status = 'Active' and the arrangement "
                  "effective on the as-of date, by payment_type and funding_source",
             source=("DP-005", "Active Payment Arrangements"),
             description="Payment arrangements with intermediary partners in force today, by payment type and funding source.",
             note="Restricted - Commercial Terms: partnerships, finance and data management roles only."),
        # DP-009 (W2-W4, CW-062: the advisor and household coverage forms of the measures)
        dict(name="Active Producing Advisors", aggregation="count_distinct",
             expr="count(distinct firm_advisor.employee_id) where advisor_status = 'Active', employment_status = 'Active' "
                  "and advisor_role.producing = 'Y' on the as-of date",
             source=("DP-009", "Active Producing Advisors"),
             description="The firm's advisors currently employed, active as advisors and carrying a producing role."),
        dict(name="Uncovered Tiered Households", aggregation="count_distinct",
             expr="count(distinct service_tier.tier_party) with a tier open on the as-of date and no coverage_assignment "
                  "with primary_coverage = 'Y' open on the as-of date",
             source=("DP-009", "Uncovered Tiered Households"),
             description="Households and clients with a service tier but no primary advisor today."),
        dict(name="Coverage Span", aggregation="count_distinct",
             expr="count(distinct coverage_assignment.covered_party) where primary_coverage = 'Y' on the as-of date",
             source=("DP-009", "Coverage Span"),
             description="Parties an advisor covers as primary coverage, by advisor and assigned service tier."),
        dict(name="Rule-Based Assignment Share", aggregation="ratio",
             numerator="count of coverage_assignment rows with primary_coverage = 'Y' open on the as-of date that have a Source Assignment Rule",
             denominator="count of coverage_assignment rows with primary_coverage = 'Y' open on the as-of date",
             source=("DP-009", "Rule-Based Assignment Share"),
             description="Share of primary household coverage made by an assignment rule rather than by exception, referral or hand."),
        # DP-093 (WP2): the Client Account counts. Stewardship counts, not the certified Funded Accounts, Clients or
        # Households (SM-20, CW-011), which count funded accounts from DP-008.
        dict(name="Open Client Accounts", aggregation="count_distinct",
             expr="count(distinct client_account.account_id) where account_status = 'Open' on the as-of date, by account_type, "
                  "account_registration_type and account_business_line",
             source=("DP-093", "Active Accounts"),
             description="Accounts open in the account master today, funded or not, by type, registration and business line.",
             note="Not the certified Funded Accounts (SM-20): an open account with no assets counts here and not there."),
        dict(name="Accounts Closed in Period", aggregation="additive",
             expr="count of client_account rows (one per account, the closing version) with account_close_date in the "
                  "selected period, by closure_reason and the Transfer-Out Receiving Firm",
             source=("DP-093", "Accounts Closed in Period"),
             description="Accounts closed in the period, by closure reason and the firm the assets went to."),
        dict(name="Active Program Enrollments", aggregation="count_distinct",
             expr="count(distinct program_enrollment rows) with enrollment_status = 'Active', enrollment_effective_date on or "
                  "before the as-of date and enrollment_termination_date blank or after it, by program and discretionary_authority",
             source=("DP-093", "Active Program Enrollments"),
             description="Accounts enrolled in each advisory, managed or trust program today, by discretion."),
        dict(name="Account Good Order Cycle Time (Days)", aggregation="ratio",
             numerator="sum over accounts with account_open_date in the period and a good_order_date of the business days "
                       "(calendar_date, business_day = 'Y') from application_received_date to good_order_date",
             denominator="count of those accounts",
             source=("DP-093", "Good Order Cycle Time (Days)"),
             description="Average business days from application to good order for accounts opened in the period, by "
                         "application channel and carrying entity.",
             note="Accounts with no good order date are not in the average; they are counted as not in good order by "
                  "filtering good_order_date blank."),
        # DP-013
        dict(name="Business Days in Period", aggregation="count_distinct",
             expr="count(distinct calendar_date.calendar_date) where business_day = 'Y' in the selected period",
             source=("DP-013", "Business Days in Period"),
             description="Business days in the selected months, quarters or years on the enterprise reporting calendar.",
             note="Counts the reporting calendar only; dealing or exchange calendars need their own calendar pinned."),
        # ===== Wave E9 enterprise masters: the headline counts. Data quality and control measures are excluded below.
        # DP-240
        dict(name="Active Parties by Role", aggregation="count_distinct",
             expr="count(distinct party.party_id) where party_status = 'Active' and a party_role with role_status = 'Active' is "
                  "open on the as-of date, by party_role.role_type",
             source=("DP-240", "Active Parties by Role"),
             description="External organizations and individuals the firm deals with today, by the role they hold (client, "
                         "counterparty, supplier, issuer, custodian and others).",
             note="A party with two roles counts once in the total and once under each role."),
        dict(name="Multi-Role Parties", aggregation="count_distinct",
             expr="count(distinct party.party_id) among Active Parties by Role with two or more distinct role_type values open "
                  "on the as-of date",
             source=("DP-240", "Multi-Role Parties"),
             description="Active parties that hold more than one role at once, for example a bank that is both a counterparty "
                         "and a custodian."),
        # DP-097
        dict(name="Active Instruments", aggregation="count_distinct",
             expr="count(distinct instrument.instrument_id) where instrument_status = 'Active' on the as-of date",
             source=("DP-097", "Active Instruments"),
             description="Securities and contracts set up in the security master and active today, by instrument type and asset class."),
        # DP-098
        dict(name="Active Issuers", aggregation="count_distinct",
             expr="count(distinct issuer.party_id) where issuer_status = 'Active' on the as-of date",
             source=("DP-098", "Active Issuers"),
             description="Issuers with an active issuer profile, by issuer type, country of risk, sector or parent group."),
        dict(name="Rating Actions in Period", aggregation="additive",
             expr="count of credit_rating_action rows with credit_rating_action_date in the selected period",
             source=("DP-098", "Rating Actions in Period"),
             description="Agency rating actions (upgrades, downgrades, affirmations, new and withdrawn ratings) in the period, "
                         "by action and agency."),
        dict(name="Ratings on Watch", aggregation="count_distinct",
             expr="count of distinct current_credit_rating rows (rated object x agency x rating type) with credit_rating_watch "
                  "other than 'None' or credit_rating_outlook = 'Negative'",
             source=("DP-098", "Ratings on Watch"),
             description="Ratings in force that an agency has placed on watch or on negative outlook, by agency.",
             note="Current ratings only, so it is a position on the as-of date, not summed over dates."),
        # DP-115
        dict(name="Approved Counterparties", aggregation="count_distinct",
             expr="count(distinct counterparty.party_id) where counterparty_approval_status in ('Approved', 'Approved - "
                  "Restricted', 'Closing Only') on the as-of date",
             source=("DP-115", "Approved Counterparties"),
             description="Brokers and counterparties the firm may trade with today, by tier or parent group."),
        dict(name="Active Approval Scopes", aggregation="count_distinct",
             expr="count(distinct counterparty_scope rows) with scope_status in ('Approved', 'Approved - Restricted') open on "
                  "the as-of date",
             source=("DP-115", "Active Approval Scopes"),
             description="Approved combinations of counterparty, activity, trading entity and fund, by approved activity and trading entity."),
        dict(name="Approved Limit by Parent Group", aggregation="semi_additive",
             expr="sum(counterparty_limit.limit_amount) for limits in force on the as-of date, grouped by parent_group, limit_type "
                  "and trading entity",
             time_rule="as-of date only: the limits in force on the selected date; never summed over dates",
             source=("DP-115", "Approved Limit by Parent Group"),
             description="Counterparty limits approved for each parent group, by limit type and trading entity.",
             note="The spec sums only within one currency, but Counterparty Trading Limit has no currency attribute; until it "
                  "does, totals are valid only where every limit is set in the firm's base currency (see open decisions). "
                  "Exposure against the limits is DP-153 in SM-09 and limit exceedances DP-154 in SM-10 (CD-215)."),
        dict(name="Adverse Review Outcomes", aggregation="additive",
             expr="count of counterparty_review rows with counterparty_review_date in the period and status_after_review in "
                  "('Approved - Restricted', 'Suspended', 'Closing Only', 'Terminated') or counterparty_review_outcome in "
                  "('Reduce Scope or Limits', 'Watch List', 'Suspend', 'Terminate')",
             source=("DP-115", "Adverse Review Outcomes"),
             description="Counterparty reviews in the period that restricted, suspended or ended the relationship, by tier."),
        # DP-140
        dict(name="Active Portfolios", aggregation="count_distinct",
             expr="count(distinct portfolio.portfolio_id) where portfolio_status in ('Active', 'Closed to New Money', "
                  "'Liquidating') on the as-of date",
             source=("DP-140", "Active Portfolios"),
             description="Managed books the firm runs today, by business line, portfolio type and IBOR operating model."),
        dict(name="Outsourced Book Share", aggregation="ratio",
             numerator="Active Portfolios with ibor_operating_model in ('Outsourced Middle Office', 'Hybrid', 'Shadow of Client "
                       "Custodian Record')",
             denominator="Active Portfolios for the same selection",
             source=("DP-140", "Outsourced Book Share"),
             description="Share of active portfolios whose book of record is run or shadowed outside the firm, by middle office "
                         "provider and business line."),
        # DP-167
        dict(name="Open Safekeeping Accounts", aggregation="count_distinct",
             expr="count(distinct safekeeping_account.safekeeping_account_id) where safekeeping_account_status = 'Open' on the as-of date",
             source=("DP-167", "Open Safekeeping Accounts"),
             description="Custody and safekeeping accounts open today, by custodian, account type and currency."),
        dict(name="Active Sub-Custody Markets", aggregation="count_distinct",
             expr="count(distinct sub_custody_arrangement.arrangement_market) with arrangement_status = 'Active' on the as-of "
                  "date, by global custodian; the markets with more than one active sub-custodian are a filter on the same rows",
             source=("DP-167", "Active Sub-Custody Markets"),
             description="Markets each global custodian covers through an active sub-custodian today."),
        # DP-190
        dict(name="Active GL Accounts", aggregation="count_distinct",
             expr="count(distinct gl_account.gl_account_id) where gl_account_status = 'Active' on the as-of date",
             source=("DP-190", "Active GL Accounts"),
             description="Natural accounts open for posting today, by chart and account type."),
        dict(name="Active Cost Centers", aggregation="count_distinct",
             expr="count(distinct cost_center.cost_center_code) where cost_center_status = 'Active' on the as-of date",
             source=("DP-190", "Active Cost Centers"),
             description="Cost centers open today, by legal entity and org unit."),
        # DP-210
        dict(name="Approved Suppliers", aggregation="count_distinct",
             expr="count(distinct vendor.party_id) where supplier_status in ('Approved', 'Restricted') on the as-of date",
             source=("DP-210", "Approved Suppliers"),
             description="Suppliers the firm may buy from today, by parent group or jurisdiction."),
        dict(name="Active Engagements by Tier", aggregation="count_distinct",
             expr="count(distinct supplier_engagement rows) with engagement_status = 'Active' on the as-of date, by "
                  "supplier_risk_tier.criticality_tier in force on that date and buying legal entity",
             source=("DP-210", "Active Engagements by Tier"),
             description="Supplier engagements in force today, by third-party criticality tier and buying entity."),
        # DP-211
        dict(name="Applications in Production", aggregation="count_distinct",
             expr="count(distinct application.application_id) where application_status = 'In Production' on the as-of date",
             source=("DP-211", "Applications in Production"),
             description="Applications live in production, by type, hosting model, criticality tier, owning org unit or capability."),
        # DP-212
        dict(name="Models in Use", aggregation="count_distinct",
             expr="count(distinct model_version (model_id, model_version)) where model_use_status = 'Active', by model_type and "
                  "the model_tier in force on the as-of date",
             source=("DP-212", "Models in Use"),
             description="Model versions in active use, by model type and tier."),
        dict(name="Conditional Approval Share %", aggregation="ratio",
             numerator="Models in Use whose latest_model_validation.latest_validation_outcome = 'Approved with Conditions'",
             denominator="Models in Use for the same selection",
             source=("DP-212", "Conditional Approval Share %"),
             description="Share of models in use whose latest validation approved them only with conditions, by model tier."),
        dict(name="Monitoring Breaches", aggregation="additive",
             expr="count of model_monitoring rows with monitoring_breached = 'Y'",
             source=("DP-212", "Monitoring Breaches"),
             description="Model monitoring tests that breached their threshold, by period end date, test and model tier."),
        # DP-213
        dict(name="Contracts in Force", aggregation="count_distinct",
             expr="count(distinct contract.contract_id) where contract_status = 'Active', contract_effective_date <= the as-of "
                  "date and contract_expiry_date is blank or after it",
             source=("DP-213", "Contracts in Force"),
             description="Contracts in force today, by contract family, contracting entity and typed record type."),
        dict(name="Contracts Expiring (90 Days)", aggregation="count_distinct",
             expr="Contracts in Force with contract_expiry_date within 90 days after the as-of date",
             source=("DP-213", "Contracts Expiring (90 Days)"),
             description="Contracts in force that expire in the next 90 days, by contract family."),
        dict(name="Open Notice Deadlines (90 Days)", aggregation="additive",
             expr="count of contract_key_date rows with key_date_type in ('Renewal Notice Deadline', 'Termination Notice "
                  "Deadline', 'Option Exercise Deadline'), key_date_value within 90 days after the as-of date and "
                  "key_date_action_status = 'Open', on Contracts in Force",
             source=("DP-213", "Open Notice Deadlines (90 Days)"),
             description="Notice and option deadlines falling due in the next 90 days that nobody has acted on yet.",
             note="A fixed look-ahead from the as-of date; not summed over as-of dates."),
        dict(name="Non-Standard Clause Share %", aggregation="ratio",
             numerator="Contracts in Force with at least one contract_clause row where clause_position = 'Non-Standard - Approved'",
             denominator="Contracts in Force with any contract_clause rows",
             source=("DP-213", "Non-Standard Clause Share %"),
             description="Share of contracts in force that carry an approved non-standard clause position, by clause type."),
    ],

    excluded=[
        ("DP-001", "Identifier Coverage %", "Data quality check on firm identifiers; monitored in the product's quality checks."),
        ("DP-001", "Ultimate Parent Coverage %", "Master-data quality check on the restored legal hierarchy; monitored in the product's quality checks."),
        ("DP-004", "Identifier Completeness %", "Data quality check on share class identifiers; monitored in the product's quality checks."),
        ("DP-004", "SEC Identifier Completeness %", "Data quality check on SEC identifiers; monitored in the product's quality checks."),
        ("DP-004", "Portfolio Manager Count", "A per-product count held on share class rows, so any sum repeats it per share class; "
                                              "pm_change_flag answers the cross-row question."),
        ("DP-004", "Related Product Count", "Product relationship navigation (feeders, clones, successors), answered per product."),
        ("DP-005", "Linked Account Count", "Agreement-to-account links are operational (Agreement Account Link is not published); "
                   "intermediary accounts join their dealer of record through client_account."),
        ("DP-009", "Allocation Check", "Data quality check (team capacity allocations must not exceed 100%); a worklist for advisor operations."),
        ("DP-009", "Active Assignment Exceptions", "Coverage assignment administration worklist, not an analytical measure."),
        ("DP-009", "Expiring Exceptions (30 Days)", "Coverage assignment administration worklist with a fixed look-ahead; not an analytical measure."),
        ("DP-009", "Coverage Team Size", "Coverage team rosters name people and are not published here; a per-team operational figure."),
        ("DP-009", "Reorganization-Affected Advisors", "A per-reorganization change-management list, not a measure analysts slice."),
        ("DP-013", "Unmapped Source Values", "Reference data stewardship check; monitored in the product's quality checks."),
        ("DP-013", "LEI Renewal Due", "Legal entity administration worklist for the reference data team."),
        ("DP-013", "Geographic Coverage Completeness %", "Data quality check on the geographic hierarchy."),
        ("DP-013", "ZIP-to-County Coverage %", "Data quality check on the US geography roll-up."),
        ("DP-013", "Authorizations Due for Filing", "Regulatory filing worklist for compliance; not a distribution analytics measure."),
        ("DP-013", "Concordance Coverage %", "Data quality check on classification concordances."),
        ("DP-013", "Open Code List Change Requests", "Code list governance worklist for the reference data team."),
        ("DP-013", "Supported Locale Count", "A fixed reference count with no cross-row question behind it."),
        # Wave E9 enterprise masters: completeness, control and stewardship measures. Each is a master-data quality or
        # control measure about the reference data itself; it is published in the catalog's data quality view (DP-103, SM-17)
        # or worked in the owning team's tool, not sliced across analytical models.
        ("DP-240", "Organizations Without LEI %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-240", "Merged Party Records", "Master-data stewardship measure, published in the owning area's model or the catalog."),
        ("DP-240", "Beneficial Ownership Coverage %", "Built on beneficial owners, who are personal data and stay out of the semantic layer; "
                                                      "a KYC quality measure for the financial crime team."),
        ("DP-240", "Own Entity Mirror Coverage %", "Master-data quality measure (CD-010 mirror check), published in the owning area's model or the catalog."),
        ("DP-097", "Instruments Without ISIN", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-097", "Primary Identifier Coverage %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-097", "Duplicate Identifier Count", "Master-data quality measure (identifier collision worklist), published in the owning area's model or the catalog."),
        ("DP-097", "Own Share Class Identifier Mismatches", "Master-data quality measure (DP-004 reconciliation, target 0), published in the owning area's model or the catalog."),
        ("DP-097", "Own Share Class Status Breaks", "Master-data quality measure (DP-004 reconciliation), published in the owning area's model or the catalog."),
        ("DP-097", "Asset Class Classification Coverage %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-097", "Classification Overrides Open", "Security master stewardship worklist, published in the owning area's model or the catalog."),
        ("DP-097", "Debt Terms Completeness %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-097", "Coupon Schedule Gaps", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-097", "Matured or Expired Still Active", "Master-data quality measure (status maintenance worklist), published in the owning area's model or the catalog."),
        ("DP-097", "Primary Listing Breaks", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-098", "Instruments Without Issuer Profile", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-098", "Issuers Without LEI %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-098", "Ultimate Parent Coverage %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-098", "Credit Parent Overrides Open", "Issuer stewardship worklist; the overrides themselves are published as issuer_credit_parent_link."),
        ("DP-098", "Primary Sector Coverage %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-098", "Rated Issuer Coverage %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-115", "Scopes Missing Required Agreement", "Counterparty onboarding control worklist, published in the owning area's model or the catalog."),
        ("DP-115", "Overdue Counterparty Reviews", "Counterparty review control worklist, published in the owning area's model or the catalog; "
                                                   "next_review_due_date on counterparty answers the cross-row question."),
        ("DP-115", "Approved Counterparties Without LEI %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-115", "Approved Scopes Without Limit", "Counterparty control worklist, published in the owning area's model or the catalog."),
        ("DP-115", "Issuer Counterparties Without Agency Rating", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-140", "Unlinked Active Books", "Master-data quality measure (CD-324 link completeness), published in the owning area's model or the catalog."),
        ("DP-140", "Implementation Link Completeness %", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-140", "Live Products Without Portfolio", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-140", "Open Mandates Without Portfolio", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-140", "Multiple Primary Implementation Flag", "Per-object data quality flag; primary_implementation answers the join question."),
        ("DP-140", "Sleeves Without Parent", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-140", "Pending Lifecycle Events", "Investment operations approval worklist; not an analytical measure."),
        ("DP-140", "Books Without Custody Account", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-167", "Unassigned Open Accounts", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-167", "Portfolios Without Main Safekeeping Account", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-167", "Portfolio Custody Account Mismatch", "Master-data quality measure (DP-140 reconciliation), published in the owning area's model or the catalog."),
        ("DP-167", "Custodian Appointment Mismatch", "Master-data quality measure (DP-004 product party role reconciliation), published in the owning area's model or the catalog."),
        ("DP-190", "Unmapped Active GL Accounts", "Master-data quality measure (statement mapping), published in the owning area's model or the catalog."),
        ("DP-190", "Cost Centers Without Org Unit", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-190", "Company Code Mismatches", "Master-data quality measure (DP-013 reconciliation), published in the owning area's model or the catalog."),
        ("DP-190", "Entities Without One Primary Ledger", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-190", "Overdue Open Periods", "Close control worklist; accounting_period_status answers the cross-row question and close "
                                          "progress is DP-193 in SM-14."),
        ("DP-190", "Chart Changes in Period", "Chart maintenance stewardship measure, published in the owning area's model or the catalog."),
        ("DP-210", "Untiered Active Engagements", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-210", "Critical Engagements Without Active Contract", "Third-party risk control worklist; third-party oversight is DP-219 in SM-16."),
        ("DP-210", "Suppliers Without Completed Onboarding", "Procurement onboarding control worklist, published in the owning area's model or the catalog."),
        ("DP-210", "Engagements With Departed Owner", "Ownership stewardship worklist (names people), published in the owning area's model or the catalog."),
        ("DP-210", "Uncategorized Active Engagements", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-210", "Critical Suppliers Without LEI", "Master-data quality measure (critical third-party identification), published in the owning area's model or the catalog."),
        ("DP-210", "Unlinked Specialized Providers", "Master-data quality measure (cross-master reconciliation), published in the owning area's model or the catalog."),
        ("DP-211", "Applications Without Business Owner", "Ownership stewardship worklist, published in the owning area's model or the catalog."),
        ("DP-211", "Critical Applications Without Recovery Profile", "Master-data quality measure; resilience is DP-217 in SM-16."),
        ("DP-211", "Applications Without Capability Mapping", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-211", "Stale Lifecycle Assessments", "Application portfolio stewardship worklist, published in the owning area's model or the catalog."),
        ("DP-211", "Overdue Retirements", "Application portfolio control worklist; application_lifecycle.target_retirement_date answers the cross-row question."),
        ("DP-211", "Interfaces to Retiring Applications", "Interface stewardship worklist, published in the owning area's model or the catalog."),
        ("DP-211", "Configuration Items Past Vendor Support", "Configuration management worklist; configuration items are not published as a dimension."),
        ("DP-211", "Vendor Applications Without Approved Supplier", "Cross-master quality measure (DP-210 reconciliation), published in the owning area's model or the catalog."),
        ("DP-212", "Models in Use Without Approving Validation", "Model risk control measure, published in the owning area's model or the catalog."),
        ("DP-212", "Models in Use After Rejection", "Model risk control measure, published in the owning area's model or the catalog."),
        ("DP-212", "Tier 1 Validations Overdue", "Model risk control worklist, published in the owning area's model or the catalog."),
        ("DP-212", "Untiered Models in Use", "Master-data quality measure, published in the owning area's model or the catalog."),
        ("DP-212", "Breached Models in Production Deployment", "Model risk control worklist, published in the owning area's model or the catalog."),
        ("DP-212", "Deployments of Unvalidated Versions", "Model risk control worklist, published in the owning area's model or the catalog."),
        ("DP-213", "Contracts Without Executed Document", "Contract register quality measure, published in the owning area's model or the catalog."),
        ("DP-213", "Contracts Without Counterparty", "Contract register quality measure, published in the owning area's model or the catalog."),
        ("DP-213", "Missing Governing Law", "Contract register quality measure, published in the owning area's model or the catalog."),
        ("DP-213", "Employee Signatures Without Authority", "Built on signatories, who are personal data; a legal control worklist."),
        ("DP-213", "Typed Link Completeness %", "Contract register quality measure, published in the owning area's model or the catalog."),
        ("DP-213", "Contracts With Departed Legal Owner", "Ownership stewardship worklist (names people), published in the owning area's model or the catalog."),
        # ---- WP2: the WP1 measures of the SM-00 products, each resolved (published above, or excluded with its reason) ----
        # DP-001 Intermediary Partner Master
        ("DP-001", "Active Firms by Distribution Channel", "The same count as Active Firm Count (published as Active Distributor "
                   "Firm Count) grouped by distributor_firm_profile.firm_distribution_channel and firm_registration_type; one "
                   "number, one name."),
        ("DP-001", "Form ADV Currency %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-001", "Orphan Node Count", "Partner hierarchy stewardship check (Hierarchy Node is not published as a dimension); "
                   "master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-001", "Home-Office Contacts by Function", "Home-office contacts are named individuals at partner firms (every "
                   "Gatekeeper Profile attribute is personal data); the count by function is a contact-list figure for the "
                   "intermediary team, and Gatekeeper Profile is not a dimension other models slice by."),
        ("DP-001", "Vendor Classification Currency %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        # DP-003 Institutional, Consultant & Plan Relationships
        ("DP-003", "IPS Currency %", "An OCIO governance control on IPS review dates, worked per client by institutional client "
                   "service; IPS versions are not published as a shared dimension."),
        ("DP-003", "Overdue IPS Reviews", "An IPS review worklist (per IPS version) for institutional client service; not an "
                   "analytical measure."),
        ("DP-003", "Consultant-Advised Client Investable Assets", "Sums client-reported Total Investable Assets with differing "
                   "as-of dates: not the firm's assets, and a dollar total in the shared layer would be read against the "
                   "certified Client Assets (SM-20) and Firm AUM (SM-11). Consultant reach is Consultant-Advised Client Count."),
        ("DP-003", "Plans With Advisor of Record", "Plan Role Assignment is not published as a shared dimension; plan servicing "
                   "and advisor-of-record analysis belongs to the workplace model (SM-26), which reads plans through DP-430."),
        ("DP-003", "Plan Sponsor Profile Coverage %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-003", "Plan Profile Currency %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-003", "Mandates Without Open Account", "Mandate-to-account link completeness check (target zero); master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-003", "FINRA Institutional Classification Coverage %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        # DP-004 Product, Offering & Share Class Reference
        ("DP-004", "Share Classes Without Firm Risk Rating %", "Completeness check on the firm risk rating, which is published "
                   "as share_class.firm_risk_rating; master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-004", "Offerings Without Standard Fee Schedule Link", "Offering set-up control (fee schedule links); fee schedules "
                   "and billing are SM-28's (DP-305). Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-004", "Offerings Without Minimum Assets Rule", "Offering set-up control on eligibility rules; master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-004", "Models Not Used by an Active Offering", "Model lineup stewardship check; model lineups are SM-23's. Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-004", "Third-Party Products Available Without Due Diligence Approval", "A shelf governance exception list (target "
                   "zero); whether the approval is still current is DP-383's check in SM-30."),
        ("DP-004", "Active Tradable Universe Rules", "A count of policy rules administered by product governance; the "
                   "tradable universe is SM-30's (DP-384), and rules are not a dimension other models slice by."),
        ("DP-004", "Platform Features Requiring Disclosure", "A disclosure governance list per platform feature; disclosure "
                   "delivery is SM-29's (Form CRS and Reg BI)."),
        ("DP-004", "Open Offering Windows", "A short operational list of open alternative-fund subscription windows with "
                   "capacity, worked per window by alternatives operations; no cross-row question."),
        ("DP-004", "Feeder Products Without Access Terms", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        # DP-005 Intermediary Agreements & Platform Placement (Restricted - Commercial Terms)
        ("DP-005", "Agreements Under Termination", "An agreement renewal and termination worklist for the intermediary team; "
                   "distribution_agreement.agreement_status and next_renewal_date answer the cross-row question."),
        ("DP-005", "Overdue Research Reviews", "A partner research review worklist; partner_research_rating.rating_date "
                   "answers the cross-row question."),
        ("DP-005", "Default Share Class Mappings", "Per-platform share class set-up (Share Class Mapping is not published as "
                   "a dimension); the thin intermediary channel does not slice facts by it."),
        ("DP-005", "Arrangements Without Current Rate Schedule", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-005", "Undisclosed Fund-Paid Arrangements", "A compliance exception list (target zero) on prospectus disclosure "
                   "of fund-paid arrangements, worked by intermediary oversight; not an analytical measure."),
        ("DP-005", "Active Model Placements", "The thin intermediary channel (plan section 4 item 9) does not slice facts by "
                   "partner sponsor-program model placements; Model Program Placement stays in the product's warehouse view."),
        ("DP-005", "Firm Program Memberships by Partner Tier", "The firm's own memberships in a handful of partner programs; "
                   "Program Membership is not a dimension other models slice by."),
        ("DP-005", "Dealer Setups Without Rule 22c-2 Agreement", "A compliance exception list (Rule 22c-2, target zero) worked "
                   "by intermediary oversight; dealer set-ups are not published as a dimension."),
        ("DP-005", "Data Feeds Without Governing Agreement", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        # DP-240 Enterprise Party & Role Master: the client and household quality measures. The product's own notes make
        # every count a stewardship count; the certified Clients and Households are SM-20's (DP-008, CW-011).
        ("DP-240", "Client Individuals Without Household", "Householding stewardship check; the certified Households and "
                   "Clients counts are SM-20's (CW-011). Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-240", "Households Without Valid Primary Member %", "Householding stewardship ratio (DP-240 calls it a data quality "
                   "ratio); master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-240", "Unconfirmed Household Memberships", "Householding stewardship worklist (proposed and stale memberships); "
                   "household_membership publishes only active memberships."),
        ("DP-240", "Clients Without Active Investor Profile", "Investor profile capture control; profile currency against "
                   "recommendations is DP-303 and DP-334 (SM-22)."),
        ("DP-240", "KYC Incomplete or Overdue", "KYC control worked by onboarding and financial crime; its AML split is "
                   "restricted (DP-240), so it is not published to analytical roles."),
        ("DP-240", "CIP Verification Gap", "Customer identification program control (31 CFR 1023.220) worked by onboarding; "
                   "verifications are personal data and not published."),
        ("DP-240", "Clients Without TIN on File", "Tax identification control; TINs are never published (DP-240 DQ5)."),
        ("DP-240", "Clients Without Regulatory Classification", "Classification completeness check; the classification "
                   "itself is published as client_regulatory_classification. Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-240", "Deceased Parties With Active Client Role", "Estate servicing worklist on death notifications (personal "
                   "data), worked per party by client service."),
        ("DP-240", "Clients Without Verified Primary Contact Point", "Contact data stewardship check; contactability is "
                   "DP-324's. Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-240", "Active Consents by Purpose", "Consent records are personal data; marketing consent and audiences are "
                   "SM-25's, and privacy evidence is DP-080's."),
        ("DP-240", "Open Client Restrictions", "Client restrictions are personal data worked case by case; managed-account "
                   "reasonable restrictions are SM-23's Rule 3a-4 view and exploitation holds are restricted (CD-344)."),
        ("DP-240", "Client Households Without Service Tier", "Tiering stewardship check; Uncovered Tiered Households (DP-009) "
                   "and service_tier answer the coverage question. Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-240", "Potential Duplicate Parties", "Data steward matching worklist (pairs of parties, some matched on name and "
                   "date of birth); not a measure analysts slice."),
        # DP-093 Account Master (WP2): the stewardship and control measures. Accounts are counted by Open Client Accounts.
        ("DP-093", "Primary Identifier Completeness %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-093", "Omnibus Link Completeness %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-093", "Owner Role Completeness %", "Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-093", "TIN Certification Gap", "Tax certification and backup withholding control worked by tax operations; "
                   "certifications are personal tax data and not published."),
        ("DP-093", "Unverified Bank Instructions", "Money movement fraud control on bank instructions; bank detail is never "
                   "published in the semantic layer (DP-093 DQ5)."),
        ("DP-093", "Beneficiary Allocation Check", "Per-designation data quality flag (allocations must total 100%); "
                   "beneficiaries are personal data. Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
        ("DP-093", "Open Restrictions", "Account restrictions are worked per account; the restriction rows are not published "
                   "here, holds are SM-24's and senior investor holds are restricted views only (DP-322, DP-403; CD-344)."),
        ("DP-093", "Custodial Terminations Due (90 Days)", "A UTMA and UGMA termination notice worklist with a fixed look-ahead; "
                   "not an analytical measure."),
        ("DP-093", "Enrollments Without Active Advisory Agreement", "An enrollment control (target zero) worked by advisory "
                   "operations; supervision of advice is SM-29's."),
        ("DP-093", "Active Features Without Required Agreement", "A margin, options and lending agreement control (target "
                   "zero) worked by brokerage operations; approvals are reviewed in SM-29."),
        ("DP-093", "Cost Basis Default Method Applied %", "Cost basis election stewardship for tax reporting; Cost Basis "
                   "Method is personal tax data, and lots and basis are DP-300's (SM-24)."),
        ("DP-093", "RMDs Outstanding", "Required minimum distributions are a client-level tracker of SM-21 Client & Household "
                   "360; the shared layer does not publish client-level amounts, and the satisfied amount is DP-302's."),
        ("DP-093", "Alternative Investment Subscriptions in Review", "An alternatives operations queue (subscriptions awaiting "
                   "qualification review); not an analytical measure."),
        ("DP-093", "Accounts Without Current Investment Profile", "SEC Rule 17a-3(a)(17) record-keeping control worked by "
                   "account operations; investor profiles are personal financial data."),
        ("DP-093", "Sweep Election Coverage %", "Sweep set-up completeness check (one election per account); sweep balances "
                   "and program banks are SM-24's. Master-data quality measure about the reference data itself; worked in the product's quality checks and the catalog's data quality view (DP-103, SM-17), not sliced across analytical models."),
    ],

    access=dict(
        classification=("Confidential - Personal Data (DP-093, DP-240, DP-001, DP-009, DP-167; DP-192 read for the employee "
                        "dimension; DP-008 Account Channel Assignment read for the account channel); Confidential - Client "
                        "(DP-003, DP-140); Restricted - Commercial Terms (DP-005); "
                        "Restricted - Legal (DP-213); Confidential - Licensed (DP-097, DP-098); Confidential - Financial "
                        "(DP-190); Confidential (DP-115, DP-210, DP-211, DP-212); Internal (DP-004, DP-013)"),
        roles=[
            dict(role="enterprise_data_management",   # Head of Enterprise Data Management and the master data stewards
                 rows="all", columns="all", hidden=[]),
            dict(role="distribution_data_management",
                 rows="all", columns="all distribution columns; enterprise dimensions without employee personal data or contract terms",
                 hidden=EMPLOYEE_PII + LEGAL),
            dict(role="sales_and_service",   # advisors, client service, intermediary and institutional sales, sales operations
                 rows="all dimension rows; household, client and account rows and fact rows are restricted by each "
                      "subject-area model's coverage rules (an advisor sees the households and accounts they cover)",
                 columns="all except agreement terms, payment arrangements, research ratings, contract terms, counterparty "
                         "credit terms and employee personal data",
                 hidden=COMMERCIAL + EMPLOYEE_PII + LEGAL + LICENSED + COUNTERPARTY_TERMS + ["party_name"]),
            dict(role="partnerships_and_finance",   # intermediary partnerships, client revenue finance
                 rows="all", columns="all agreement and shelf columns; no advisor, client or employee personal data",
                 hidden=ADVISOR_PII + EMPLOYEE_PII + LEGAL + COUNTERPARTY_TERMS + ["household_name"] + CLIENT_DETAIL),
            dict(role="investment_and_operations",   # portfolio management, trading, investment risk, investment and fund operations, custody
                 rows="all",
                 columns="instruments, issuers, ratings, counterparties and limits, portfolios and mandates, custody, products "
                         "and reference data; no advisor or employee personal data, no distribution commercial terms",
                 hidden=ADVISOR_PII + EMPLOYEE_PII + COMMERCIAL + ["household_name"] + CLIENT_DETAIL),
            dict(role="finance_procurement_and_legal",   # finance, procurement, third-party risk, legal and compliance
                 rows="all",
                 columns="chart of accounts, ledgers, cost centers, vendors, contracts and reference data; no advisor or "
                         "employee personal data",
                 hidden=ADVISOR_PII + EMPLOYEE_PII + ["portfolio_name", "parent_portfolio_name", "portfolio_mandate_name",
                                                       "household_name"] + CLIENT_DETAIL),
            dict(role="technology_and_model_risk",   # IT, information security, architecture, model risk, data governance
                 rows="all",
                 columns="applications, IT services, models, vendors and reference data; no advisor, client or employee "
                         "personal data, no contract terms",
                 hidden=ADVISOR_PII + EMPLOYEE_PII + ENTERPRISE_CLIENT + LEGAL + COMMERCIAL + COUNTERPARTY_TERMS + CLIENT_DETAIL),
            dict(role="people_analytics",   # HR and people analytics (SM-15 owner)
                 rows="all employee rows; other dimensions as broad_internal",
                 columns="employee columns in full; no advisor or client names, contract terms or commercial terms",
                 hidden=ADVISOR_PII + ENTERPRISE_CLIENT + LEGAL + COMMERCIAL + COUNTERPARTY_TERMS + LICENSED + CLIENT_DETAIL),
            dict(role="broad_internal",   # product, marketing analytics, executives and AI assistants
                 rows="all",
                 columns=("households, clients and accounts by type, status, segment, tier, program and channel (keys "
                          "pseudonymized, no names); firms, offices, products, offerings, coverage teams, calendars and "
                          "reference data; enterprise masters by organization name and type; the firm's advisors and employees "
                          "as pseudonymized Employee IDs; no advisor, client, household, individual party or employee personal "
                          "data, no account opening or closure detail, no DP-005 commercial columns, no contract terms, "
                          "counterparty credit terms or licensed rating values"),
                 hidden=ADVISOR_PII + ["firm_advisor_name", "coverage_team_name", "client_name", "plan_name", "mandate_name"] + COMMERCIAL
                        + EMPLOYEE_PII + ENTERPRISE_CLIENT + LEGAL + LICENSED + COUNTERPARTY_TERMS + CLIENT_DETAIL),
        ],
    ),

    verified_questions=[
        dict(question="How many client accounts are open by business line and account type, how are they split by channel, and how many are enrolled in each advisory program?",
             answer="Open Client Accounts by client_account.account_business_line and client_account.account_type; by "
                    "distribution_channel.channel_name through account_channel (the channel in force on the as-of date); "
                    "Active Program Enrollments by program.program_name and program_enrollment.discretionary_authority. "
                    "Not the certified Funded Accounts (SM-20)."),
        dict(question="How many producing advisors does the firm have in each division, how many households does each cover, and how many service-tiered households have no primary advisor?",
             answer="Active Producing Advisors by org_division.org_division_name (Advisor organization hierarchy); Coverage "
                    "Span by firm_advisor through coverage_assignment to household (primary_coverage = 'Y'); Uncovered "
                    "Tiered Households by offering_service_tier.service_tier_name through service_tier; all on the as-of date."),
        dict(question="How many service offerings are active by delivery mode and discretion type, and how many products are on the platform by transaction fee category?",
             answer="Active Service Offerings by service_offering.offering_delivery_mode and service_offering.discretion_type; "
                    "Platform Available Products by platform_availability.transaction_fee_category, filtered to "
                    "platform_availability_status = 'Available'."),
        dict(question="How many accounts closed this quarter by closure reason, and how many business days did new accounts take to reach good order by application channel?",
             answer="Accounts Closed in Period by client_account.closure_reason for the fiscal quarter (fiscal_quarter); Account "
                    "Good Order Cycle Time (Days) by client_account.application_channel for accounts opened in the quarter "
                    "(client data and service roles only)."),
        dict(question="How many intermediary partner firms are active by distribution channel, and how many have no primary coverage?",
             answer="Active Distributor Firm Count and Intermediary Firms Without Primary Coverage by "
                    "distributor_firm_profile.firm_distribution_channel, joined distributor_firm_profile to distributor_firm."),
        dict(question="How much counterparty limit is approved for each parent group, by limit type, and how many approved counterparties sit in each group?",
             answer="Approved Limit by Parent Group and Approved Counterparties by parent_group.parent_group_name and "
                    "counterparty_limit.limit_type, joined counterparty to parent_group on the ultimate parent; limits in "
                    "force on the as-of date (always filter). Valid only where all limits share one currency (see open decisions)."),
    ],

    cannot_answer=[
        dict(question="Program bank deposits and sweep balances by program bank",
             why="Program banks are DP-431's (SM-24) and are not an SM-00 product; the shared layer carries only the "
                 "account's Elected Sweep Program key.", gap=""),
        dict(question="Client assets and flows by external manager or sub-adviser",
             why="Managers are DP-306's (SM-31) and are not an SM-00 product; a model that needs the manager slice joins "
                 "SM-31's manager table.", gap=""),
        dict(question="Channel attributes beyond the code (channel owner, channel P&L line, effective-dated channel definitions)",
             why="No channel master entity exists in any foundational model: the channel is a Distribution Channel code "
                 "(DP-013) assigned to accounts by the 06 Account Channel Assignment.", gap=""),
        dict(question="Which agreement governs each shelf placement, and which partner program the placement sits in",
             why="Shelf Placement carries no agreement reference and names its platform only as text; the agreement link is derived.",
             gap="GAP-05-006"),
        dict(question="Partner tier of each firm in a partner program",
             why="Program Membership has no member partner firm, so tiers cannot be attached to firms.", gap="GAP-05-004"),
        dict(question="Coverage span against each advisor's household capacity",
             why="03 Advisor Capacity Snapshot now holds the capacity (the 07 gap closed, CW-907), but DP-009 does not read "
                 "it yet; it is a WP0 candidate input.", gap=""),
        dict(question="Party coverage and advisors by sales territory",
             why="The wealth model has no territories (CW-013, CW-064); coverage is by advisor, coverage team and service tier.",
             gap=""),
        dict(question="Institutional clients by consultant recommendation status",
             why="No client-level consultant recommendation status exists.", gap="GAP-03-002"),
        dict(question="Counterparty limits added up across currencies, or in one reporting currency",
             why="Counterparty Trading Limit has no currency attribute and no FX rate observation object exists, so limit "
                 "amounts in different currencies cannot be converted or kept apart.", gap="GAP-09-005"),
        dict(question="Issuer concentration by the firm's default parent roll-up (legal ultimate parent or credit parent)",
             why="No attribute names which parent the firm uses for concentration limits; SM-00 offers both chains.",
             gap="GAP-17-004"),
        dict(question="Total value of contracts in force, by contract family or counterparty",
             why="The enterprise contract record carries no contract value (CD-257).", gap="GAP-39-001"),
        dict(question="Which supplier engagement (and its criticality tier) supplies each application",
             why="Supplier Engagement and Application are not linked; applications match vendors only by party.", gap="GAP-40-001"),
        dict(question="Applications by business capability on the governed capability map",
             why="Supported Business Capability is free text until the capability map is registered as data.", gap="GAP-41-001"),
        dict(question="GL balances by cost center",
             why="Ledger segments are held as text on the balance, with no structured cost center reference, so the "
                 "cost_center dimension cannot be joined to balances.", gap="GAP-19-001"),
    ],

    open_decisions=[
        "Shelf Coverage % and Partner Watch List Product Count (DP-005) overlapped with DP-021 in SM-03, which was "
        "retired (CW-041, CW-209); the conflicts closed with it. Revisit if an intermediary shelf product returns in SM-27.",
        "DP-013 holds its organization hierarchy as parent-child links. Publish a flattened path per node (DP-013 "
        "'Distribution Organization': division to team) so BI tools can drill without recursive joins. Until then SM-00 "
        "resolves org units to their division recursively. DP-009 Coverage Team Parent Coverage Team is a second parent-child "
        "chain; SM-00 does not roll it up.",
        "W2-W4 (CW-062, CW-063, CW-064): DP-009 now reads the 03 Advisor Organization objects. salesperson becomes "
        "firm_advisor (Employee with the 03 Advisor attributes), sales_role becomes advisor_role (Advisor Role Assignment), "
        "sales_team and sales_team_membership become coverage_team and coverage_team_membership, coverage_tier becomes "
        "service_tier (02 Service Tier Assignment), and coverage_model is added. territory_model, territory, region, division, "
        "territory_hierarchy, territory_assignment and party_alignment, the Sales territory hierarchy and the shared DP-009 "
        "Territory entities are removed with no successor; coverage_assignment now joins covered parties through party "
        "(DP-240), because intermediary partner coverage is 05 Partner Coverage Assignment, not DP-009. Metrics renamed with "
        "their measures: Active Producing Advisors, Uncovered Tiered Households, Rule-Based Assignment Share; Territory "
        "Coverage Completeness % is removed. SM-01 and SM-07 dropped their territory joins (both since retired, CW-209).",
        # ---- W1 merge (CW-021, CW-902, CW-909, CW-917): re-point at W4 ------------------------------------------------
        # ---- WP2 (plan section 8.4): the wealth dimensions -------------------------------------------------------------
        "WP2: SM-00 adds the wealth conformed dimensions. Household is DP-240 Party with Party Type = Household and the "
        "DP-240 Household Membership bridge (many-to-many, the membership in force on the measurement date pinned in "
        "always_filter); Client is DP-240 Party in the Client role; Client Account is DP-093 Account with Account Party "
        "Role, Program Enrollment, Account Feature and Cash Sweep Election; Advisor stays DP-009 Employee (the 03 Advisor) "
        "with Coverage Assignment, now joined to household and client_account; Offering and Program are DP-004 Service "
        "Offering (program is the same entity role-played for the offerings an account enrolls in), Service Tier and "
        "Model Portfolio. Consuming models name them as DP-240/Party, DP-240/Household Membership, DP-093/Account, "
        "DP-093/Account Party Role, DP-093/Program Enrollment, DP-009/Employee, DP-009/Coverage Assignment, "
        "DP-004/Service Offering, DP-004/Service Tier, DP-004/Model Portfolio and DP-008/Account Channel Assignment.",
        "Channel: no foundational model has a Channel entity. SM-00 publishes the account's channel from DP-008's 06 "
        "Account Channel Assignment (account_channel), read under the certified-source rule because DP-008 is the source of "
        "SM-20's certified client-asset family and the register lets any model read it; the channel members are the "
        "Distribution Channel code list of DP-013 (distribution_channel, Code List Key pinned). DP-007 holds the fuller "
        "assignment (Channel Assignment Basis, Basis Program Enrollment) but is an SM-20 product and not a certified source, "
        "so SM-00 cannot read it. Decide whether 06 Account Channel Assignment should be mastered in a foundational SM-00 "
        "product (DP-093 or DP-013) so the channel dimension stops depending on a fact product, and confirm the code list "
        "ID SM-00 pins. Channel stays the Dimension Type of the certified DP-008 Measure Value rows (SM-20).",
        "Program Bank and Manager: the plan's conformed set includes them, but program banks are DP-431 (SM-24) and "
        "external managers and sub-advisers DP-306 (SM-31), which are not SM-00 products. They stay model-local in SM-24 "
        "and SM-31 unless the register moves DP-431 and DP-306 (or a program bank and manager master) into SM-00; until "
        "then client_account carries only the Elected Sweep Program key (account_sweep_election) and no manager key.",
        "Service Tier Assignment (02) is read by both DP-009 (service_tier here, the coverage view) and DP-240 (read by "
        "SM-21 as DP-240/Service Tier Assignment). The same 02 rows reach two shared names; agree that one product publishes "
        "the household tier and the other conforms it.",
        "DP-093 Account is now the conformed Client Account (GAP-02-010 for the wealth model): every account kind is a 15 "
        "account (CW-035). DP-003 Account stays as the institutional view of the same ACC- key and joins client_account "
        "one-to-one; decide whether DP-003 should conform its Account from DP-093 so the institutional table becomes a "
        "role view. DP-140 Portfolio Implementation Link's Managed Account now joins client_account.",
        "SM-00's account, client and household counts (Open Client Accounts, the DP-240 stewardship measures) are "
        "stewardship counts; the certified Funded Accounts, Clients and Households are SM-20's on DP-008 (CW-011). Open "
        "Client Accounts is named apart from Funded Accounts on purpose; consuming models reference SM-20's certified "
        "counts, never this one, for client reporting.",
        "DP-093 Application Channel, Closure Reason, Networking Level and Account Role Type, and DP-240 Household Member "
        "Role, are flagged personal data in the logical models although the DP-093 and DP-240 analytics views carry types "
        "and statuses. SM-00 publishes them as dimensions and hides them from broad, investment, finance, technology and "
        "people roles (CLIENT_DETAIL). Confirm with the DP-093 and DP-240 owners which can be unflagged.",
        "The program table pins Offering Type not in ('Brokerage', 'Planning Only'), the codes DP-004's Offerings Without "
        "Minimum Assets Rule uses. Confirm with the DP-004 owner, or add a Program Indicator to 01 Service Offering.",
        "SM-00 does not publish 15 Account Restriction: restriction rows can carry the FINRA Rule 2165 exploitation holds "
        "that reach products only through DP-322 and DP-403 (CD-344). Restriction analytics stay in SM-24 and SM-29's "
        "restricted views.",
        "WP1 (CW-132): DP-001 now reads the restored 05 profiles. SM-00 adds distributor_firm_profile (Distributor Firm), "
        "intermediary_branch (Branch / Office), advisor_affiliation (Employment Affiliation) and partner_coverage (Partner "
        "Coverage Assignment), so advisors group by partner firm and office again; DP-003 adds institutional_client_profile "
        "(12 Institutional Client) and institutional_service_relationship. The firm, office and team Party role views stay "
        "for names. Hierarchy Node and Team Membership are not published (the thin intermediary channel does not drill a "
        "partner hierarchy below firm).",
        "SM-00 pins Parent Relationship Basis = 'Accounting Consolidation' on the DP-001 and DP-240 Legal Entity Hierarchy "
        "tables so each party has one legal parent chain. Confirm the basis with the DP-240 owner (the DP-001 spec reads "
        "majority ownership from the same attribute), or publish one table per basis. Issuer and vendor groups now join to "
        "parent_group through DP-240 legal_entity_hierarchy, because DP-098 and DP-210 no longer carry Ultimate Parent.",
        "W1 removals with no successor (US only, CW-902, CW-909, CW-917): DP-004 Country Registration and its bridge "
        "(registration country, marketing basis), Trail Commission Indicator and Registered Country Count; DP-013 EU "
        "Member State and EEA Member indicators; DP-097 UCITS eligibility, MiFID II complex and Solvency II CIC columns; "
        "DP-240 Organization Type (read as Party Type), Regulated Entity Indicator (read as Primary Regulator), Ownership "
        "Percentage, Role Source and LEI Entity Category. Restore through the jurisdiction register if a UK or EU extension "
        "is taken.",
        "DP-013: add Calendar Year, Quarter and Month to Calendar Date (SM-00 derives them from the date), and name the enterprise "
        "reporting calendar and firm fiscal calendar IDs that SM-00 pins (Calendar Type 'Reporting' and 'Fiscal').",
        "Measures sit on the wrong entity in several logical models: all ten DP-013 measures are on Calendar Date though eight "
        "concern code lists, geography, legal entities and locales; DP-005 Days to Renewal, Watch List Count and Linked Account "
        "Count are on Shelf Placement; DP-004 Portfolio Manager Count and Change Flag (per product) are on Share Class; all ten "
        "DP-009 measures are on Coverage Assignment. Move each to the entity it describes.",
        "DP-005 Active Placement Count lists 'approved, recommended, focus list', which mixes Placement Status and Shelf List Type "
        "codes. Confirm the rule; the proposal is Placement Status = 'Approved - Available' on any Shelf List Type except "
        "'Sell-Only / Hold List'.",
        "DP-009 Uncovered Tiered Households counts every party with an open Service Tier Assignment. Confirm whether "
        "households only (Party Type = Household) or every tiered client party is meant.",
        "SM-00 treats advisor names and DP-001 team names (the Party Display Name of Advisor Team parties; teams are often "
        "named after advisors) as personal data. Confirm with the DP-001 owner.",
        "DP-003 holds clients, consultants, recordkeepers, plan sponsors and plans in one party table (GAP-02-009); SM-00 "
        "role-plays it by Party Role and Party Type. Plan sponsors without an Institutional Client role drop out of the "
        "retirement_plan to institutional_client join.",
        "Morningstar Category and CUSIP are licensed (Data Domain 14). Confirm the licenses cover BI distribution to every role, "
        "or hide them from broad_internal.",
        "Confirm 'Advisor Value Tier' as the default advisor segmentation scheme.",
        "Advisor Profile Completeness % is published as a ratio of sums (the mean per-advisor score). Confirm this rather than "
        "'share of advisors with all five attributes'.",
        "DP-005 is Restricted - Commercial Terms but shelf status is needed by sales: SM-00 shows shelf list type and placement "
        "status to sales_and_service and hides agreement, payment and rating columns. Confirm with the DP-005 owner.",
        # ---- Wave E9 enterprise dimensions ----------------------------------------------------------------------------
        "Employee dimension (CD-342): SM-00 now publishes employee from DP-192 Employee & Position Master as the firm's "
        "employee dimension and keeps firm_advisor from DP-009 as the advisor view of the same worker (one-to-one on "
        "Employee ID). The DP-192 employee complements DP-009's rather than replacing it: firm_advisor carries the advisor "
        "status, channels and producing role that DP-192 does not, and the client and advice models join to firm_advisor. "
        "Enterprise models join to employee.",
        "DP-192 is an SM-15 product, so the validator rejects 'DP-192/Employee' in any model's shared list (shared must "
        "name an SM-00 product). SM-00 reads it as a certified-metric source. Either add DP-192 to the shared-dimension "
        "spine in the validator (a dimension source without moving the product) or have enterprise models read DP-192 "
        "Employee directly as a table; the register owner should choose before SM-08 to SM-17 are confirmed.",
        "DP-192 flags every Employee attribute as personal data, including Job Title, Employment Type, Employing Legal "
        "Entity and Home Org Unit. SM-00 therefore hides all employee columns from every role but HR and enterprise data "
        "management; other roles reach org unit and legal entity through the joins. Confirm with the SM-15 owner whether "
        "org placement and employment type can be unflagged, as DP-009 does for the firm's advisors.",
        "Two party dimensions: DP-001 (distribution firms, offices, teams) and DP-240 (the enterprise party, CD-296) share "
        "the 02 PTY- key and SM-00 joins them one-to-one. Decide when DP-001 conforms its Party from DP-240 so the "
        "distribution tables become role views of one party table.",
        "Investment Mandate is published by both DP-003 (investment_mandate, institutional) and DP-140 (portfolio_mandate, "
        "linked to portfolios). SM-00 joins them one-to-one on the mandate ID; choose one owner of the conformed mandate.",
        "Parent chains are parent-child links: DP-240 Direct / Ultimate Parent (two levels published), DP-098 credit parent, "
        "DP-190 Parent Summary Account and Parent Segment Value, and DP-140 Sleeve Of. SM-00 rolls each up one hop. Publish "
        "flattened paths in DP-190 (summary account levels, cost center levels) and DP-240 (each parent level) so BI tools "
        "can drill without recursive joins.",
        "DP-140 Portfolio Hierarchy Link has four types (Sleeve Of, Carve-Out Of, Aggregation, Successor Of); SM-00 pins "
        "Sleeve Of for the portfolio hierarchy. Add an Aggregation view if a model needs aggregate-book roll-ups.",
        "DP-190's Cost Center entity holds every chart segment (Model gap); SM-00 pins Chart Segment = 'Cost Center' for "
        "cost_center and publishes the other segments as chart_segment_value. Confirm the code value of the cost center segment.",
        "DP-115 Approved Limit by Parent Group sums limits 'only within one currency' but Counterparty Trading Limit has no "
        "currency attribute. Add Limit Currency to 25 Counterparty Trading Limit (and to DP-115's inputs); until then the "
        "metric is valid only where all limits are set in one currency.",
        "Ultimate Parent Coverage % is a measure of both DP-240 and DP-098 with different populations (all organizations vs "
        "active issuers). Both are excluded here; if either is published, rename it to make the scope explicit.",
        "Measures sit on the wrong entity in the enterprise logical models: all DP-190 measures are on GL Account though "
        "they concern cost centers, ledgers and periods; DP-210 Approved Suppliers is on Supplier Engagement though it "
        "counts suppliers; all DP-167 measures are on Safekeeping Account including Active Sub-Custody Markets. Move each "
        "to the entity it describes.",
        "SM-00 publishes only the headline counts of the eleven enterprise masters and excludes their 80-odd quality and "
        "control measures. DP-212's model risk controls, DP-213's contract register checks and DP-115's counterparty "
        "controls are governance measures their owners report: if an area model (SM-10, SM-16) should publish them, the "
        "register needs to let it read the master, or the masters' quality measures belong in DP-103 (SM-17).",
        "DP-097 and DP-098 are Confidential - Licensed: SM-00 hides agency rating values, CUSIP issuer numbers and "
        "instrument identifier values from broad and sales roles. Confirm the vendor and agency licenses for BI "
        "distribution of normalized notches and the investment grade flag to every role.",
        "W4 (CW-930): portfolio_vintage_year (DP-140 Vintage Year) removed with 18 Private Fund Portfolio Detail; DP-005 "
        "agreement_paper, agreement_market and coverage_basis removed with their attributes (CW-905); "
        "agreement_permitted_jurisdictions (US states) added in place of the agreement market.",
        "W1b: client_asset_designation table (DP-167 Client Asset Designation: CASS Account Designation, Statutory Trust "
        "Indicator) and its two joins removed, no US successor (CW-928); the excluded measure Client Accounts Without CASS "
        "Designation leaves with it. The US customer-protection record of client assets is 49's (CW-007).",
        "W1b: supplier_contract_profile.ict_arrangement_type (DP-210 ICT Contractual Arrangement Type) removed, no US successor "
        "(CW-940); the excluded ICT Suppliers Without LEI is replaced by Critical Suppliers Without LEI, still excluded as a "
        "master-data quality measure.",
        "W1b: model_version.trading_algorithm_code (DP-212 Trading Algorithm Code) removed, no US successor (CW-937); the "
        "excluded measure Trading Algorithms Without Code leaves with it.",
    ],
)
