"""Semantic model SM-08 Investment Book, Performance & Stewardship. See CONTRACT.md.

Publishes the investment book of record (DP-141 Portfolio Transactions, DP-142 Holdings, Tax Lots & Cash), the official
returns (DP-145), attribution and ex-post analytics (DP-157), GIPS composites (DP-158), the performance scorecard
(DP-159), investment decisions and governance (DP-126), asset allocation policy (DP-127), and stewardship: proxy voting
(DP-132), engagement (DP-133), ESG data (DP-134) and sustainability metrics (DP-135). Owns the certified Official Return
and Benchmark Return (CD-293, CD-320), which every other model references with ref="SM-08/<name>".

W4 (CW-930, CW-167): the private markets content left with 30 and the 32 private markets performance family. The DP-145
private_measure table and the certified Private Fund IRR and Multiples, the DP-160 investor performance and PME tables and
metrics and the DP-127 commitment pacing plan are removed.

WP2 (CW-011, CW-129, CW-209): SM-08 owns the certified Personal Rate of Return (DP-145 Personal Return Value) on the
personal_return fact, keyed by client account or household performance group, with the method pinned per query; it also
publishes the household and account performance view (DP-532) and the personal return exception, suppression and
restatement controls (DP-533). Client assets and flows are SM-20's, client fee revenue SM-28's, referenced only.

Double-counting rules kept closed here:
- Returns, benchmark returns, attribution results and ex-post statistics are versioned: each table pins the version of record (highest version, Final or Restated status).
- Holdings and the valuation summary pin the End of Day view; cash pins the Settled balance type.
- Portfolio Market Value (IBOR), GIPS Total Firm Assets and Composite Assets are never labeled or summed as AUM
  (CD-292, CD-320). AUM is SM-11's Firm AUM; client assets are SM-20's Client Assets; both referenced only, never added.
- Portfolio Capital Activity is a book cash flow, never net flows (CD-292); flows are SM-20's.
- Personal Rate of Return is one method per query (time-weighted or money-weighted, pinned in always_filter); it is never
  summed, averaged or chained across accounts, and a household return is its own DP-145 row, never built from members.
"""

_CURRENT = "effective_from <= :as_of_date and (effective_to is null or effective_to > :as_of_date)"
_RETURN_OF_RECORD = ["Return Status in ('Final', 'Restated')",
                     "Return Version = the highest Return Version of the same return key (subject, period, fee basis, "
                     "net fee basis, calculation type, price basis, tax basis, sales charge basis, currency)"]

MODEL = dict(
    id="SM-08",
    status="Draft",
    description=(
        "Holdings, transactions and the certified official returns of every portfolio, share class and composite, "
        "with attribution, ex-post risk, GIPS composites and the firm performance scorecard, plus investment decisions and governance, asset allocation against policy, proxy voting, "
        "engagement, ESG data coverage and sustainability metrics. Used by performance measurement, portfolio "
        "management, investment governance, the stewardship team, product and client reporting for questions across "
        "portfolios, products, composites, issuers and periods. Owns the certified return metrics."),
    questions=[
        "Which share classes and composites beat their primary benchmark over 1, 3 and 5 years net of fees, and what "
        "share of fund assets (certified class net assets) is ahead of benchmark?",
        "Where did active return come from last quarter, by portfolio, attribution effect and segment, and how does "
        "realized tracking error compare with ex-ante tracking error?",
        "Are our GIPS composites complete: members, assets, missing statistics, open significant cash flow removals "
        "and unassigned discretionary portfolios?",
        "Are portfolios within their asset allocation policy ranges, and is every portfolio covered by a decision "
        "authority and an approved manager assignment?",
        "How did we vote and engage across issuers, how much of the book is covered by ESG assessments, and what are "
        "the portfolios' sustainability metrics and financed emissions?",
        "What personal rate of return did each household and account earn, time- or money-weighted and net of fees, "
        "how many returns are suppressed, restated or missing a profile, and how complete is household coverage?",
    ],

    tables=[
        # ================= DP-145 Official Returns (certified) =======================================================
        dict(name="performance_return", product="DP-145", entity="Performance Return", kind="Fact",
             grain="return subject x period start x period end x fee basis x net fee basis x calculation type x price "
                   "basis x tax basis x sales charge basis x currency (version of record)",
             always_filter=_RETURN_OF_RECORD,
             default_filter="Hypothetical Indicator = 'N'",
             dimensions=[dict(name="return_subject_type", attr="Return Subject Type",
                              note="Portfolio, Share Class, Account, GIPS Composite or Model Portfolio; always fix it"),
                         dict(name="return_period_start", attr="Return Period Start Date"),
                         dict(name="return_period_end", attr="Return Period End Date"),
                         dict(name="return_period_basis", attr="Return Period Basis"),
                         dict(name="return_calculation_type", attr="Return Calculation Type"),
                         dict(name="return_calculation_method", attr="Return Calculation Method"),
                         dict(name="return_fee_basis", attr="Return Fee Basis"),
                         dict(name="return_net_fee_basis", attr="Return Net Fee Basis"),
                         dict(name="price_basis", attr="Price Basis"),
                         dict(name="return_tax_basis", attr="Return Tax Basis"),
                         dict(name="sales_charge_adjusted", attr="Sales Charge Adjusted Indicator"),
                         dict(name="return_currency", attr="Return Currency"),
                         dict(name="annualized", attr="Annualized Indicator"),
                         dict(name="return_status", attr="Return Status"),
                         dict(name="return_version", attr="Return Version"),
                         dict(name="return_source", attr="Return Source"),
                         dict(name="hypothetical", attr="Hypothetical Indicator"),
                         dict(name="hypothetical_category", attr="Hypothetical Performance Category"),
                         dict(name="return_account", attr="Return Account",
                              note="Institutional separate accounts only (CW-129); client personal returns are on "
                                   "personal_return. Entitled roles only"),
                         dict(name="return_managed_account_composite", attr="Return Managed Account Composite",
                              note="Managed account composite subjects; read with [Official Return]")],
             facts=[dict(name="return_value", attr="Return Value", note="Read only through [Official Return]"),
                    dict(name="income_return", attr="Income Return"),
                    dict(name="capital_return", attr="Capital Return")],
             hidden=[("Beginning Portfolio Value", "A derived copy of the 18 value the calculation used; not a published "
                                                   "value and never AUM. Portfolio values are Portfolio Market Value (IBOR)."),
                     ("Ending Portfolio Value", "As Beginning Portfolio Value; read only by the GIPS composite tie-out."),
                     ("Net External Cash Flow", "A calculation input, not net flows; flows are SM-20's certified Net Flows."),
                     ("Fees Deducted Amount", "A calculation input on each return row; fee revenue is SM-28's and SM-14's."),
                     ("Hypothetical Methodology Description", "Free text for the compliance reviewer.")]),
        dict(name="benchmark_return", product="DP-145", entity="Benchmark Return", kind="Fact",
             grain="benchmark x period x return type x currency x hedged basis (version of record)",
             always_filter=["Benchmark Return Status in ('Final', 'Restated')",
                            "Benchmark Return Version = the highest version of the same benchmark, period, return type, "
                            "currency and hedged basis"],
             dimensions=[dict(name="benchmark_period_start", attr="Benchmark Period Start Date"),
                         dict(name="benchmark_period_end", attr="Benchmark Period End Date"),
                         dict(name="benchmark_period_basis", attr="Benchmark Period Basis"),
                         dict(name="benchmark_return_type", attr="Benchmark Return Type"),
                         dict(name="benchmark_return_currency", attr="Benchmark Return Currency"),
                         dict(name="benchmark_hedged", attr="Benchmark Hedged Basis Indicator"),
                         dict(name="benchmark_return_source", attr="Benchmark Return Source")],
             facts=[dict(name="benchmark_return_value", attr="Benchmark Return Value",
                         note="Read only through [Benchmark Return]")]),
        dict(name="benchmark", product="DP-145", entity="Benchmark", kind="Dimension",
             dimensions=[dict(name="benchmark_name", attr="Benchmark Name"),
                         dict(name="benchmark_administrator", attr="Benchmark Administrator"),
                         dict(name="benchmark_currency", attr="Benchmark Currency"),
                         dict(name="benchmark_index_return_type", attr="Return Type"),
                         dict(name="blended_benchmark", attr="Blended Benchmark Indicator")]),   # BMR Register Status removed at W1 (EU / UK only, CW-901)
        # Primary role only: one primary benchmark per share class on a date keeps the join many-to-one.
        dict(name="primary_benchmark", product="DP-145", entity="Product Benchmark Assignment", kind="Bridge",
             grain="share class x primary benchmark x effective period",
             always_filter=["Benchmark Role = 'Primary'"],
             default_filter="assignment effective at the return period end date",
             dimensions=[dict(name="benchmark_role", attr="Benchmark Role"),
                         dict(name="assignment_effective_from", attr="Assignment Effective From")]),
        dict(name="period_close", product="DP-145", entity="Performance Period Close", kind="Fact",
             grain="close group x period end date x period type",
             dimensions=[dict(name="close_group", attr="Close Group"),
                         dict(name="close_period_end", attr="Close Period End Date"),
                         dict(name="close_period_type", attr="Close Period Type"),
                         dict(name="period_close_status", attr="Period Close Status"),
                         dict(name="final_release_timestamp", attr="Final Release Timestamp")]),
        dict(name="restatement", product="DP-145", entity="Performance Restatement", kind="Fact",
             grain="restated return x restatement sequence",
             dimensions=[dict(name="restatement_cause", attr="Restatement Cause"),
                         dict(name="restatement_date", attr="Restatement Date"),
                         dict(name="material_error", attr="Material Error Indicator"),
                         dict(name="gips_disclosure_required", attr="GIPS Disclosure Required Indicator"),
                         dict(name="client_notification_required", attr="Client Notification Required Indicator")],
             facts=[dict(name="restatement_return_difference", attr="Restatement Return Difference",
                         note="Signed per restatement; averaged as an absolute value only")]),

        # ================= DP-145 Personal Rate of Return (certified, CW-011, CW-129) =================================
        # One method per query: time-weighted and money-weighted returns are different numbers and never share a metric.
        dict(name="personal_return", product="DP-145", entity="Personal Rate of Return", kind="Fact",
             grain="client account or household performance group x period start x period end x method x fee basis "
                   "(version of record)",
             always_filter=["Personal Return Status in ('Final', 'Restated')",
                            "Personal Return Version = the highest version of the same Personal Rate of Return ID",
                            "Personal Return Method = :personal_return_method (Time-Weighted or Money-Weighted; one "
                            "method per query, required)"],
             default_filter="Personal Return Fee Basis = 'Net of Fees'",
             dimensions=[dict(name="personal_return_id", attr="Personal Rate of Return ID"),
                         dict(name="personal_return_subject_type", attr="Personal Return Subject Type",
                              note="Account or Household Performance Group; always fix it"),
                         dict(name="personal_return_account", attr="Personal Return Account",
                              note="Personal data; client, advisor-of-record and performance roles only"),
                         dict(name="personal_return_group", attr="Personal Return Group",
                              note="Personal data; client, advisor-of-record and performance roles only"),
                         dict(name="personal_return_period_start", attr="Personal Return Period Start Date"),
                         dict(name="personal_return_period_end", attr="Personal Return Period End Date"),
                         dict(name="personal_return_period_basis", attr="Personal Return Period Basis"),
                         dict(name="personal_return_method", attr="Personal Return Method"),
                         dict(name="personal_return_calculation_method", attr="Personal Return Calculation Method"),
                         dict(name="personal_return_fee_basis", attr="Personal Return Fee Basis"),
                         dict(name="personal_return_annualized", attr="Personal Return Annualized Indicator"),
                         dict(name="personal_return_status", attr="Personal Return Status"),
                         dict(name="personal_return_version", attr="Personal Return Version")],
             facts=[dict(name="personal_return_value", attr="Personal Return Value",
                         note="Read only through [Personal Rate of Return]; null where suppressed")],
             hidden=[("Beginning Market Value", "A Derived copy of the 49, 29 or 16 book value the calculation used; "
                                                "not Client Assets (SM-20) and never summed across accounts."),
                     ("Ending Market Value", "As Beginning Market Value; checked by DP-145's ending value tie-out."),
                     ("Net External Flows", "A calculation input, not Net Flows or Net New Assets (SM-20)."),
                     ("Fees Deducted", "A calculation input; client fee revenue is SM-28's.")]),
        dict(name="client_performance_profile", product="DP-145", entity="Client Performance Profile", kind="Dimension",
             always_filter=["the profile in force on the period end: the latest Client Profile Effective From on or "
                            "before the period end per account or household performance group"],
             dimensions=[dict(name="client_profile_subject_type", attr="Client Profile Subject Type"),
                         dict(name="client_profile_account", attr="Client Profile Account"),
                         dict(name="client_profile_group", attr="Client Profile Group"),
                         dict(name="performance_start_date", attr="Performance Start Date"),
                         dict(name="client_methods_produced", attr="Client Methods Produced"),
                         dict(name="client_fee_bases_produced", attr="Client Fee Bases Produced"),
                         dict(name="client_comparison_benchmark", attr="Client Comparison Benchmark"),
                         dict(name="client_applied_calculation_policy", attr="Client Applied Calculation Policy"),
                         dict(name="return_suppression_reason", attr="Return Suppression Reason"),
                         dict(name="client_profile_effective_from", attr="Client Profile Effective From")]),
        dict(name="calculation_policy", product="DP-145", entity="Performance Calculation Policy", kind="Dimension",
             dimensions=[dict(name="calculation_policy_code", attr="Calculation Policy Code"),
                         dict(name="calculation_policy_version", attr="Calculation Policy Version"),
                         dict(name="external_cash_flow_timing", attr="External Cash Flow Timing"),
                         dict(name="policy_effective_from", attr="Policy Effective From")],
             facts=[dict(name="large_cash_flow_threshold", attr="Large Cash Flow Threshold")]),
        dict(name="household_performance_group", product="DP-145", entity="Household Performance Group", kind="Dimension",
             dimensions=[dict(name="household_performance_group_id", attr="Household Performance Group ID"),
                         dict(name="group_household", attr="Group Household",
                              note="The 02 Client Household (DP-240 Party of type Household); personal data"),
                         dict(name="performance_group_type", attr="Performance Group Type"),
                         dict(name="performance_group_status", attr="Performance Group Status")]),
        dict(name="household_group_member", product="DP-145", entity="Household Performance Group Member", kind="Bridge",
             grain="household performance group x client account x inclusion period",
             default_filter="Member Inclusion Date <= the period end and (Member Exclusion Date is null or > the period end)",
             dimensions=[dict(name="member_performance_group", attr="Member Performance Group"),
                         dict(name="member_account", attr="Member Account"),
                         dict(name="member_inclusion_date", attr="Member Inclusion Date"),
                         dict(name="member_exclusion_date", attr="Member Exclusion Date")]),

        # ================= DP-532 Household & Account Performance View (presentation of DP-145) ======================
        dict(name="displayed_personal_return", product="DP-532", entity="Fact Personal Return", kind="Fact",
             grain="personal return subject x period start x period end x method x fee basis x version, as displayed on "
                   "the publication date (one monthly snapshot)",
             always_filter=["Publication Date Key = :publication_date (one publication snapshot per query)",
                            "the current version of each Personal Rate of Return ID on that snapshot"],
             dimensions=[dict(name="publication_date", attr="Publication Date Key"),
                         dict(name="displayed_return_id", attr="Personal Rate of Return ID"),
                         dict(name="displayed_subject_type", attr="Personal Return Subject Type"),
                         dict(name="displayed_account", attr="Personal Return Account", note="Personal data"),
                         dict(name="displayed_group", attr="Personal Return Group", note="Personal data"),
                         dict(name="displayed_period_end", attr="Personal Return Period End Date"),
                         dict(name="displayed_period_basis", attr="Personal Return Period Basis"),
                         dict(name="displayed_method", attr="Personal Return Method"),
                         dict(name="displayed_calculation_method", attr="Personal Return Calculation Method"),
                         dict(name="displayed_fee_basis", attr="Personal Return Fee Basis"),
                         dict(name="displayed_annualized", attr="Personal Return Annualized Indicator"),
                         dict(name="displayed_status", attr="Personal Return Status"),
                         dict(name="displayed_supersedes", attr="Supersedes Personal Return")],
             hidden=[("Personal Return Value", "The displayed value is DP-145's certified number; read it as [Personal "
                                               "Rate of Return] from personal_return (CW-251)."),
                     ("Beginning Market Value", "DP-145's input as displayed to the client; row-level only, never summed."),
                     ("Ending Market Value", "As Beginning Market Value."),
                     ("Net External Flows", "As Beginning Market Value; not Net Flows (SM-20)."),
                     ("Fees Deducted", "As Beginning Market Value; client fee revenue is SM-28's.")]),

        # ================= DP-533 Personal Return Exceptions, Suppression & Restatements ==============================
        dict(name="client_return_exception", product="DP-533", entity="Fact Client Return Exception", kind="Fact",
             grain="client account x exception date x exception type, per daily as-of snapshot",
             always_filter=["As-Of Date Key = :as_of_date (one daily snapshot per query)"],
             dimensions=[dict(name="exception_as_of_date", attr="As-Of Date Key"),
                         dict(name="exception_account", attr="Exception Account", note="Personal data"),
                         dict(name="exception_date", attr="Exception Date"),
                         dict(name="client_return_exception_type", attr="Client Return Exception Type"),
                         dict(name="return_exception_status", attr="Return Exception Status"),
                         dict(name="suppresses_return", attr="Suppresses Return Indicator")],
             hidden=[("Exception Resolution", "Free text for performance operations.")]),
        dict(name="personal_return_version", product="DP-533", entity="Fact Personal Return Version", kind="Fact",
             grain="personal rate of return version (PRROR-); a restating version carries Supersedes Personal Return",
             default_filter="Personal Return Status = 'Restated' and Supersedes Personal Return is not null",
             dimensions=[dict(name="version_return_id", attr="Personal Rate of Return ID"),
                         dict(name="version_number", attr="Personal Return Version"),
                         dict(name="version_subject_type", attr="Personal Return Subject Type"),
                         dict(name="version_account", attr="Personal Return Account", note="Personal data"),
                         dict(name="version_group", attr="Personal Return Group", note="Personal data"),
                         dict(name="version_period_end", attr="Personal Return Period End Date"),
                         dict(name="version_method", attr="Personal Return Method"),
                         dict(name="version_fee_basis", attr="Personal Return Fee Basis"),
                         dict(name="version_status", attr="Personal Return Status"),
                         dict(name="version_supersedes", attr="Supersedes Personal Return"),
                         dict(name="version_restatement_cause", attr="Personal Return Restatement Cause"),
                         dict(name="version_client_notification", attr="Personal Return Client Notification Indicator")],
             facts=[dict(name="version_return_value", attr="Personal Return Value",
                         note="Read only as the change against the superseded version; never as a return (the "
                              "certified number is [Personal Rate of Return])")],
             hidden=[("Beginning Market Value", "A calculation input of the version; used only by the large flow check."),
                     ("Ending Market Value", "A calculation input of the version; never Client Assets."),
                     ("Fees Deducted", "A calculation input; client fee revenue is SM-28's.")]),

        # ================= DP-141 Portfolio Transactions =============================================================
        dict(name="portfolio_transaction", product="DP-141", entity="Portfolio Transaction", kind="Fact",
             grain="one portfolio transaction as booked (PTXN-)",
             always_filter=["latest Portfolio Transaction Event Type in ('Booked', 'Amended'); canceled transactions and "
                            "originals replaced by a Rebooked As Transaction are excluded"],
             dimensions=[dict(name="transaction_type", attr="Portfolio Transaction Type"),
                         dict(name="trade_date", attr="Trade Date"),
                         dict(name="contractual_settlement_date", attr="Contractual Settlement Date"),
                         dict(name="transaction_currency", attr="Transaction Currency"),
                         dict(name="settlement_confirmed", attr="Settlement Confirmed Indicator"),
                         dict(name="costs_capitalized", attr="Costs Capitalized Indicator"),
                         dict(name="source_allocation_id", attr="Source Allocation ID"),
                         dict(name="explicit_cost_tie_out_flag", attr="Explicit Cost Tie-Out Flag",
                              note="Y where Total Explicit Cost differs from its components by more than 0.01")],
             facts=[dict(name="net_amount_base", attr="Net Amount Base"),
                    dict(name="total_explicit_cost", attr="Total Explicit Cost", note="Transaction currency"),
                    dict(name="trade_fx_rate", attr="Trade FX Rate", note="Per row; never summed")],
             hidden=[("Commission Amount", "Commission Spend is certified in SM-09 from DP-122; reference it there."),
                     ("Research Payment Component", "Research Spend is certified in SM-09 from DP-122."),
                     ("Transaction Counterparty", "A join key to DP-115 Counterparty, not a column.")]),
        dict(name="transaction_event", product="DP-141", entity="Portfolio Transaction Event", kind="Fact",
             grain="portfolio transaction x event type x event timestamp",
             dimensions=[dict(name="event_type", attr="Portfolio Transaction Event Type"),
                         dict(name="event_timestamp", attr="Event Timestamp"),
                         dict(name="amendment_reason", attr="Amendment Reason"),
                         dict(name="event_source_system", attr="Event Source System"),
                         dict(name="back_dated", attr="Back-Dated Indicator")]),
        dict(name="capital_activity", product="DP-141", entity="Portfolio Capital Activity", kind="Fact",
             grain="portfolio x share class or client account x trade date x capital activity type",
             dimensions=[dict(name="capital_activity_type", attr="Capital Activity Type"),
                         dict(name="activity_trade_date", attr="Activity Trade Date"),
                         dict(name="activity_settlement_date", attr="Activity Settlement Date"),
                         dict(name="activity_data_basis", attr="Activity Data Basis"),
                         dict(name="capital_activity_source", attr="Capital Activity Source"),
                         dict(name="in_kind_activity", attr="In-Kind Activity Indicator")],
             facts=[dict(name="activity_amount_base", attr="Activity Amount Base",
                         note="A book cash flow in portfolio base currency; never net flows (CD-292)")],
             hidden=[("Activity Account", "Client account key: personal data for SMA books; joins only.")]),

        # ================= DP-142 Holdings, Tax Lots & Cash ==========================================================
        dict(name="holding", product="DP-142", entity="Portfolio Holding", kind="Fact",
             grain="portfolio x instrument x holding date (End of Day view)",
             always_filter=["Holding View = 'End of Day'"],      # Start of Day rows would count every position twice
             default_filter="holding_date = latest business date with a locked End of Day snapshot",
             dimensions=[dict(name="holding_date", attr="Holding Date"),
                         dict(name="holding_view", attr="Holding View"),
                         dict(name="long_short", attr="Long / Short Indicator"),
                         dict(name="price_source", attr="Price Source"),
                         dict(name="price_date", attr="Price Date"),
                         dict(name="quantity_unit", attr="Quantity Unit")],
             facts=[dict(name="market_value_base", attr="Market Value Base", note="Short positions negative"),
                    dict(name="holding_cost_base", attr="Holding Cost Base"),
                    dict(name="accrued_income_base", attr="Accrued Income Base"),
                    dict(name="holding_quantity", attr="Holding Quantity", note="Summed only within one instrument"),
                    dict(name="delta_adjusted_exposure_base", attr="Delta-Adjusted Exposure Base"),
                    dict(name="notional_amount_base", attr="Notional Amount Base"),
                    dict(name="unfunded_commitment", attr="Unfunded Commitment"),
                    dict(name="adjusted_nav", attr="Adjusted NAV", note="Fund-interest holdings")],
             hidden=[("Holding Weight", "A per-portfolio ratio stored on the row; weights are recomputed from market "
                                        "value so they add up for any selection."),
                     ("Corresponding Shareholder Position", "A key to the 06 shareholder position; client assets are SM-20's and Firm AUM SM-11's.")]),
        dict(name="approved_price", product="DP-142", entity="Approved Price", kind="Dimension",
             always_filter=["Price Approval Status = 'Approved'"],
             dimensions=[dict(name="approved_pricing_point", attr="Approved Pricing Point"),
                         dict(name="approved_price_date", attr="Price Date")],
             facts=[dict(name="approved_price_value", attr="Approved Price Value", note="Compared, never summed")]),
        dict(name="tax_lot", product="DP-142", entity="Tax Lot", kind="Fact",
             grain="portfolio x instrument x acquisition lot (current state)",
             dimensions=[dict(name="lot_open_date", attr="Lot Open Date"),
                         dict(name="lot_closed", attr="Lot Closed Indicator"),
                         dict(name="holding_period_start", attr="Holding Period Start Date")],
             facts=[dict(name="remaining_quantity", attr="Remaining Quantity"),
                    dict(name="adjusted_cost_basis_base", attr="Adjusted Cost Basis Base")]),
        dict(name="lot_relief", product="DP-142", entity="Lot Relief", kind="Fact",
             grain="tax lot x closing portfolio transaction",
             dimensions=[dict(name="relief_method_applied", attr="Relief Method Applied"),
                         dict(name="holding_period_term", attr="Holding Period Term")],
             facts=[dict(name="realized_gain_loss_base", attr="Realized Gain / Loss Base"),
                    dict(name="wash_sale_loss_disallowed", attr="Wash-Sale Loss Disallowed"),
                    dict(name="relief_proceeds_base", attr="Relief Proceeds Base")]),
        dict(name="cash_balance", product="DP-142", entity="Cash Balance", kind="Fact",
             grain="portfolio x currency x cash account x balance date (Settled balances)",
             always_filter=["Cash Balance Type = 'Settled'"],    # trade-date and projected balances would double count
             default_filter="balance_date = latest business date",
             dimensions=[dict(name="balance_date", attr="Balance Date"),
                         dict(name="balance_currency", attr="Balance Currency"),
                         dict(name="cash_balance_type", attr="Cash Balance Type"),
                         dict(name="cash_account_purpose", attr="Cash Account Purpose")],
             facts=[dict(name="balance_amount_base", attr="Balance Amount Base"),
                    dict(name="balance_amount_local", attr="Balance Amount Local", note="Summed within one currency only")]),
        dict(name="projected_cash", product="DP-142", entity="Projected Cash Movement", kind="Fact",
             grain="portfolio x currency x projected value date x source item",
             default_filter="projected_value_date within the next five business days",
             dimensions=[dict(name="projected_currency", attr="Projected Currency"),
                         dict(name="projected_value_date", attr="Projected Value Date"),
                         dict(name="projected_cash_source", attr="Projected Cash Source"),
                         dict(name="projected_flow_direction", attr="Projected Flow Direction"),
                         dict(name="projection_data_basis", attr="Projection Data Basis")],
             facts=[dict(name="projected_amount", attr="Projected Amount", note="Projected currency; sum within one currency")]),
        dict(name="position_snapshot", product="DP-142", entity="Portfolio Position Snapshot", kind="Fact",
             grain="portfolio x snapshot type x as-of timestamp",
             dimensions=[dict(name="snapshot_type", attr="Snapshot Type"),
                         dict(name="snapshot_business_date", attr="Snapshot Business Date"),
                         dict(name="snapshot_locked", attr="Snapshot Locked Indicator"),
                         dict(name="snapshot_control_status", attr="Snapshot Control Status"),
                         dict(name="snapshot_restated", attr="Snapshot Restated Indicator")]),
        dict(name="valuation_summary", product="DP-142", entity="Portfolio Valuation Summary", kind="Fact",
             grain="portfolio x valuation as-of date (End of Day view, locked snapshot)",
             always_filter=["Valuation View = 'End of Day'",
                            "Summary Snapshot refers to a Portfolio Position Snapshot with Snapshot Locked Indicator = 'Y'"],
             default_filter="valuation_as_of_date = latest",
             dimensions=[dict(name="valuation_as_of_date", attr="Valuation As-Of Date"),
                         dict(name="valuation_period_type", attr="Valuation Period Type"),
                         dict(name="summary_data_basis", attr="Summary Data Basis")],
             facts=[dict(name="total_ibor_market_value", attr="Total IBOR Market Value",
                         note="Read only through [Portfolio Market Value (IBOR)]; never AUM"),
                    dict(name="total_holdings_market_value", attr="Total Holdings Market Value"),
                    dict(name="total_cash_balance", attr="Total Cash Balance"),
                    dict(name="total_accrued_income", attr="Total Accrued Income")]),

        # ================= DP-157 Performance Attribution & Ex-Post Analytics ========================================
        dict(name="attribution_result", product="DP-157", entity="Fact Attribution Result", kind="Fact",
             grain="portfolio return version x benchmark return version x attribution model version (final result)",
             always_filter=["Attribution Status = 'Final'",
                            "Attribution Version = the highest version per Portfolio Return Record, Benchmark Return "
                            "Record and Applied Attribution Model"],
             dimensions=[dict(name="attribution_status", attr="Attribution Status")],
             facts=[dict(name="active_return", attr="Active Return"),
                    dict(name="attribution_residual", attr="Attribution Residual")]),
        dict(name="attribution_effect", product="DP-157", entity="Fact Attribution Effect", kind="Fact",
             grain="final attribution result x segment x effect type",
             always_filter=["Effect Attribution Result is a row of attribution_result (final result, highest version)"],
             dimensions=[dict(name="effect_segment_code", attr="Effect Segment Code"),
                         dict(name="attribution_effect_type", attr="Attribution Effect Type")],
             facts=[dict(name="attribution_effect_value", attr="Attribution Effect Value")]),
        dict(name="attribution_segment", product="DP-157", entity="Fact Attribution Segment", kind="Fact",
             grain="final attribution result x segment",
             always_filter=["Segment Attribution Result is a row of attribution_result (final result, highest version)"],
             dimensions=[dict(name="attribution_segment_code", attr="Attribution Segment Code")],
             facts=[dict(name="portfolio_segment_weight", attr="Portfolio Segment Weight"),
                    dict(name="benchmark_segment_weight", attr="Benchmark Segment Weight",
                         note="Derived from licensed index constituents"),
                    dict(name="portfolio_segment_return", attr="Portfolio Segment Return"),
                    dict(name="benchmark_segment_return", attr="Benchmark Segment Return")]),
        dict(name="attribution_model", product="DP-157", entity="Attribution Model", kind="Dimension",
             dimensions=[dict(name="attribution_model_code", attr="Attribution Model Code"),
                         dict(name="attribution_model_version", attr="Attribution Model Version"),
                         dict(name="attribution_method", attr="Attribution Method"),
                         dict(name="attribution_linking_method", attr="Attribution Linking Method"),
                         dict(name="attribution_calculation_basis", attr="Attribution Calculation Basis"),
                         dict(name="segment_classification_scheme", attr="Segment Classification Scheme"),
                         dict(name="currency_attribution_method", attr="Currency Attribution Method")]),
        # Instrument-level rows of one calculation basis: segment rows and other bases restate the same return.
        dict(name="contribution", product="DP-157", entity="Fact Contribution to Return", kind="Fact",
             grain="portfolio return version x instrument (one calculation basis)",
             always_filter=["Contribution Instrument is not null",
                            "Contribution Calculation Basis = the Attribution Calculation Basis of the portfolio's model"],
             dimensions=[dict(name="contribution_calculation_basis", attr="Contribution Calculation Basis"),
                         dict(name="contribution_classification_scheme", attr="Contribution Classification Scheme"),
                         dict(name="contribution_segment_code", attr="Contribution Segment Code")],
             facts=[dict(name="contribution_to_return_value", attr="Contribution to Return Value"),
                    dict(name="contribution_average_weight", attr="Contribution Average Weight")]),
        dict(name="ex_post_statistic", product="DP-157", entity="Fact Ex-Post Risk Statistic", kind="Fact",
             grain="subject x statistic type x period x observation frequency x fee basis x price basis x currency x "
                   "comparison benchmark (version of record)",
             always_filter=["Statistic Status = 'Final'",
                            "Statistic Version = the highest version of the same statistic key"],
             dimensions=[dict(name="statistic_subject_type", attr="Statistic Subject Type"),
                         dict(name="ex_post_statistic_type", attr="Ex-Post Statistic Type"),
                         dict(name="statistic_period_start", attr="Statistic Period Start Date"),
                         dict(name="statistic_period_end", attr="Statistic Period End Date"),
                         dict(name="observation_frequency", attr="Observation Frequency"),
                         dict(name="statistic_fee_basis", attr="Statistic Fee Basis"),
                         dict(name="statistic_price_basis", attr="Statistic Price Basis"),
                         dict(name="statistic_currency", attr="Statistic Currency")],
             facts=[dict(name="statistic_value", attr="Statistic Value")]),

        # ================= DP-158 GIPS Composites & Verification =====================================================
        dict(name="gips_composite", product="DP-158", entity="GIPS Composite", kind="Dimension",
             dimensions=[dict(name="composite_name", attr="Composite Name"),
                         dict(name="composite_creation_date", attr="Composite Creation Date"),
                         dict(name="composite_inception_date", attr="Composite Inception Date"),
                         dict(name="significant_cash_flow_policy", attr="Significant Cash Flow Policy")],
             facts=[dict(name="minimum_portfolio_size", attr="Minimum Portfolio Size", note="Per composite; never summed")],
             hidden=[("Composite Definition", "Long text for the GIPS report, not a slicer.")]),
        dict(name="gips_firm", product="DP-158", entity="GIPS Firm", kind="Dimension",
             always_filter=["the GIPS Firm definition effective on the period end (Firm Definition Effective From)"],
             dimensions=[dict(name="gips_firm_name", attr="GIPS Firm Name"),
                         dict(name="compliance_claim_date", attr="Compliance Claim Date")],
             hidden=[("GIPS Compliance Officer", "A named employee (personal data); no cross-row question needs it.")]),
        dict(name="composite_statistic", product="DP-158", entity="Fact Composite Period Statistic", kind="Fact",
             grain="GIPS composite x period end x period type",
             always_filter=["Composite Period Type = 'Annual'"],      # monthly and annual rows of the same year would mix
             dimensions=[dict(name="composite_period_end", attr="Composite Period End Date"),
                         dict(name="composite_period_type", attr="Composite Period Type"),
                         dict(name="internal_dispersion_method", attr="Internal Dispersion Method"),
                         dict(name="standard_deviation_fee_basis", attr="Standard Deviation Fee Basis")],
             facts=[dict(name="number_of_portfolios", attr="Number of Portfolios"),
                    dict(name="composite_assets_value", attr="Composite Assets",
                         note="A GIPS figure, read only through [Composite Assets]; never AUM"),
                    dict(name="internal_dispersion", attr="Internal Dispersion"),
                    dict(name="composite_3y_std_dev", attr="Composite 3-Year Ex-Post Standard Deviation"),
                    dict(name="benchmark_3y_std_dev", attr="Benchmark 3-Year Ex-Post Standard Deviation"),
                    dict(name="non_fee_paying_assets_pct", attr="Non-Fee-Paying Assets Percentage")]),
        dict(name="composite_membership", product="DP-158", entity="Fact Composite Membership", kind="Fact",
             grain="composite x member portfolio x membership start date",
             dimensions=[dict(name="member_portfolio", attr="Member Portfolio",
                              note="Can identify an individual's SMA book; entitled roles only"),
                         dict(name="membership_start_date", attr="Membership Start Date"),
                         dict(name="membership_end_date", attr="Membership End Date"),
                         dict(name="composite_exclusion_reason", attr="Composite Exclusion Reason"),
                         dict(name="fee_paying", attr="Fee-Paying Indicator"),
                         dict(name="membership_approval_status", attr="Membership Approval Status")],
             hidden=[("Membership Approver", "A named employee (personal data).")]),
        dict(name="significant_flow", product="DP-158", entity="Fact Significant Cash Flow", kind="Fact",
             grain="portfolio x composite x significant flow date",
             dimensions=[dict(name="significant_flow_date", attr="Significant Flow Date"),
                         dict(name="removal_start_date", attr="Removal Start Date"),
                         dict(name="return_to_composite_date", attr="Return to Composite Date")],
             facts=[dict(name="significant_flow_amount", attr="Significant Flow Amount"),
                    dict(name="flow_pct_of_portfolio_value", attr="Flow Percentage of Portfolio Value",
                         note="Per event; never summed"),
                    dict(name="applied_significant_flow_threshold", attr="Applied Significant Flow Threshold")]),
        dict(name="carve_out", product="DP-158", entity="Fact Carve-Out Allocation", kind="Fact",
             grain="carve-out portfolio x carve-out period",
             dimensions=[dict(name="carve_out_period_start", attr="Carve-Out Period Start Date"),
                         dict(name="carve_out_period_end", attr="Carve-Out Period End Date"),
                         dict(name="own_cash_balance", attr="Own Cash Balance Indicator")]),
        dict(name="gips_firm_assets", product="DP-158", entity="Fact GIPS Firm Assets", kind="Fact",
             grain="GIPS firm definition x period end",
             dimensions=[dict(name="firm_assets_period_end", attr="Firm Assets Period End Date"),
                         dict(name="firm_assets_currency", attr="Firm Assets Currency")],
             facts=[dict(name="gips_total_firm_assets", attr="Total Firm Assets",
                         note="The GIPS-defined firm assets; never labeled or summed as AUM (CD-320)")]),
        dict(name="gips_verification", product="DP-158", entity="Fact GIPS Verification", kind="Fact",
             grain="one GIPS verification engagement (GVER-)",
             dimensions=[dict(name="verification_period_start", attr="Verification Period Start Date"),
                         dict(name="verification_period_end", attr="Verification Period End Date"),
                         dict(name="verification_report_date", attr="Verification Report Date")]),

        # ================= DP-159 Investment Performance Scorecard (peer data: Confidential - Licensed) ===============
        dict(name="peer_snapshot", product="DP-159", entity="Fact Peer Metric Snapshot", kind="Fact",
             grain="peer fund x snapshot date x return period x peer universe",
             default_filter="snapshot_date = latest month-end",
             dimensions=[dict(name="peer_snapshot_date", attr="Snapshot Date"),
                         dict(name="peer_return_period", attr="Return Period"),
                         dict(name="category_percentile_rank", attr="Category Percentile Rank",
                              note="Vendor-published rank of one fund; never averaged"),
                         dict(name="quartile_rank", attr="Quartile Rank")],
             facts=[dict(name="published_peer_return", attr="Total Return",
                         note="Published Peer Return (vendor); never mixed with own returns (CD-217)")],
             hidden=[("Expense Ratio", "Peer fees are not a performance read; the scorecard reads returns and ranks only. The "
                                       "firm's own expense ratios are SM-11's certified Net and Gross Expense Ratio."),
                     ("Estimated Net Flow", "A vendor flow estimate, not a firm number; firm flows are SM-20's Net Flows.")]),
        dict(name="peer_universe", product="DP-159", entity="Peer Universe", kind="Dimension",
             default_filter="universe " + _CURRENT.replace("effective_", "universe_effective_"),
             dimensions=[dict(name="peer_universe_name", attr="Peer Universe Name"),
                         dict(name="universe_type", attr="Universe Type"),
                         dict(name="base_category_value", attr="Base Category Value")]),
        dict(name="peer_universe_member", product="DP-159", entity="Peer Universe Member", kind="Bridge",
             grain="peer universe x member fund",
             dimensions=[dict(name="member_manual_override", attr="Manual Override Indicator")]),
        dict(name="peer_fund", product="DP-159", entity="Peer Fund", kind="Dimension",
             dimensions=[dict(name="peer_fund_name", attr="Peer Fund Name"),
                         dict(name="peer_fund_isin", attr="ISIN", note="The only link to an own share class (GAP-11-007)"),
                         dict(name="peer_managing_firm", attr="Managing Firm"),
                         dict(name="peer_morningstar_category", attr="Peer Morningstar Category")]),


        # ================= DP-126 Investment Decisions & Governance ===================================================
        dict(name="decision_scope", product="DP-126", entity="Fact Investment Decision Scope", kind="Bridge",
             grain="investment decision x scoped portfolio or model portfolio",
             dimensions=[dict(name="scope_model_portfolio", attr="Scope Model Portfolio")],
             hidden=[("Scope Portfolio", "A join key to DP-140 Portfolio, not a column.")]),
        dict(name="investment_decision", product="DP-126", entity="Investment Decision", kind="Fact",
             grain="one investment decision (IDEC-)",
             dimensions=[dict(name="decision_action", attr="Decision Action"),
                         dict(name="decision_timestamp", attr="Decision Timestamp"),
                         dict(name="decision_cause", attr="Decision Cause"),
                         dict(name="decision_algorithm", attr="Decision Algorithm",
                              note="24 Decision Algorithm, a Model key (W3 24); replaces Decision Algorithm Code"),
                         dict(name="rationale_recorded_timestamp", attr="Rationale Recorded Timestamp")],
             hidden=[("Decision Maker", "A named employee (personal data); decisions are counted, not listed by person."),
                     ("Investment Thesis", "Free text; the rationale check reads whether it is filled.")]),
        dict(name="investment_committee", product="DP-126", entity="Investment Committee", kind="Dimension",
             default_filter="committee " + _CURRENT.replace("effective_", "committee_effective_"),
             dimensions=[dict(name="committee_name", attr="Investment Committee Name"),
                         dict(name="committee_type", attr="Investment Committee Type"),
                         dict(name="meeting_frequency", attr="Meeting Frequency"),
                         dict(name="quorum_requirement", attr="Quorum Requirement"),
                         dict(name="committee_status", attr="Committee Status")]),
        dict(name="committee_meeting", product="DP-126", entity="Investment Committee Meeting", kind="Fact",
             grain="investment committee x meeting date",
             dimensions=[dict(name="meeting_date", attr="Meeting Date"),
                         dict(name="written_resolution", attr="Written Resolution Indicator"),
                         dict(name="quorum_met", attr="Quorum Met Indicator")],
             facts=[dict(name="voting_members_present", attr="Voting Members Present", note="Per meeting; never summed")]),
        dict(name="committee_decision", product="DP-126", entity="Fact Committee Decision", kind="Fact",
             grain="investment committee x meeting date x decision item number",
             dimensions=[dict(name="committee_decision_type", attr="Committee Decision Type"),
                         dict(name="committee_decision_outcome", attr="Committee Decision Outcome"),
                         dict(name="decision_effective_date", attr="Decision Effective Date"),
                         dict(name="decision_instrument_type", attr="Decision Instrument Type")],
             hidden=[("Decision Summary", "Free text in the minutes; not a slicer.")]),
        dict(name="committee_membership", product="DP-126", entity="Fact Committee Membership", kind="Fact",
             grain="investment committee x employee x member role x effective period",
             default_filter="member " + _CURRENT.replace("effective_", "member_effective_"),
             dimensions=[dict(name="committee_member_role", attr="Committee Member Role")],
             hidden=[("Committee Member", "A join key to DP-192 Employee (personal data).")]),
        # SCD type 2: a filter on the as-of date keeps one effective row per portfolio, manager and role.
        dict(name="pm_assignment", product="DP-126", entity="Fact Portfolio Management Assignment", kind="Fact",
             grain="portfolio x manager or investment team x portfolio management role x effective period",
             always_filter=["assignment " + _CURRENT.replace("effective_", "assignment_effective_")],
             dimensions=[dict(name="portfolio_management_role", attr="Portfolio Management Role"),
                         dict(name="decision_authority", attr="Decision Authority Indicator"),
                         dict(name="independent_release_authority", attr="Independent Release Authority Indicator"),
                         dict(name="assignment_approval_status", attr="Assignment Approval Status"),
                         dict(name="assignment_effective_from_date", attr="Assignment Effective From"),
                         dict(name="assigned_manager", attr="Assigned Manager",
                              note="Employee key (personal data); entitled roles only")],
             hidden=[("Assignment Approved By", "A named employee (personal data).")]),
        dict(name="disclosed_pm_assignment", product="DP-126", entity="Portfolio Manager Assignment", kind="Fact",
             grain="investment product x disclosed portfolio manager x effective period (01, as DP-004 publishes it)",
             always_filter=["PM Start Date <= :as_of_date and (PM End Date is null or PM End Date > :as_of_date)"],
             dimensions=[dict(name="disclosed_pm_role", attr="Portfolio Manager Role")]),

        # ================= DP-127 Asset Allocation, Glide Paths & Pacing =============================================
        dict(name="policy_allocation", product="DP-127", entity="Fact Policy Allocation", kind="Fact",
             grain="implementing portfolio x effective policy version x policy line x as-of date",
             always_filter=["Line Allocation Policy is the policy version effective on the as-of date"],
             default_filter="as_of_date = latest month-end",
             dimensions=[dict(name="policy_as_of_date", attr="As-of Date Key"),
                         dict(name="policy_asset_class", attr="Policy Asset Class"),
                         dict(name="policy_sub_class", attr="Policy Sub-Class")],
             facts=[dict(name="neutral_weight", attr="Neutral Weight", note="Per line; never summed across portfolios"),
                    dict(name="minimum_weight", attr="Minimum Weight"),
                    dict(name="maximum_weight", attr="Maximum Weight")]),
        dict(name="allocation_policy", product="DP-127", entity="Asset Allocation Policy", kind="Dimension",
             dimensions=[dict(name="allocation_policy_name", attr="Allocation Policy Name"),
                         dict(name="allocation_policy_type", attr="Allocation Policy Type"),
                         dict(name="policy_version_number", attr="Policy Version Number"),
                         dict(name="policy_rebalance_frequency", attr="Policy Rebalance Frequency"),
                         dict(name="policy_status", attr="Policy Status"),
                         dict(name="policy_effective_from", attr="Policy Effective From")]),
        dict(name="glide_path_point", product="DP-127", entity="Fact Glide Path Point", kind="Fact",
             grain="glide path policy version x years to target date x asset class x sub-class",
             dimensions=[dict(name="years_to_target_date", attr="Years to Target Date"),
                         dict(name="glide_path_asset_class", attr="Glide Path Asset Class"),
                         dict(name="glide_path_sub_class", attr="Glide Path Sub-Class"),
                         dict(name="landing_point", attr="Landing Point Indicator")],
             facts=[dict(name="glide_path_weight", attr="Glide Path Weight"),
                    dict(name="glide_path_minimum_weight", attr="Glide Path Minimum Weight"),
                    dict(name="glide_path_maximum_weight", attr="Glide Path Maximum Weight")]),
        dict(name="tactical_view", product="DP-127", entity="Fact Tactical View", kind="Fact",
             grain="view scope (house or strategy) x asset class x segment x view date",
             default_filter="views effective on the as-of date (View Date <= as-of and View Effective To null or later)",
             dimensions=[dict(name="view_asset_class", attr="View Asset Class"),
                         dict(name="view_segment", attr="View Segment"),
                         dict(name="tactical_stance", attr="Tactical Stance"),
                         dict(name="view_date", attr="View Date"),
                         dict(name="view_horizon_months", attr="View Horizon Months")],
             facts=[dict(name="tilt_magnitude", attr="Tilt Magnitude")]),

        # ================= DP-132 Proxy Voting ========================================================================
        dict(name="vote_instruction", product="DP-132", entity="Fact Vote Instruction", kind="Fact",
             grain="ballot (meeting x safekeeping account) x agenda item",
             dimensions=[dict(name="vote_cast", attr="Vote Cast"),
                         dict(name="against_management", attr="Against Management Indicator"),
                         dict(name="against_policy", attr="Against Policy Indicator"),
                         dict(name="vote_decision_source", attr="Vote Decision Source"),
                         dict(name="instructed_timestamp", attr="Instructed Timestamp"),
                         dict(name="vote_confirmation_status", attr="Vote Confirmation Status"),
                         dict(name="vote_decision_maker", attr="Vote Decision Maker",
                              note="Employee key (personal data); stewardship team only")],
             facts=[dict(name="shares_voted", attr="Shares Voted")]),
        dict(name="ballot", product="DP-132", entity="Fact Ballot", kind="Fact",
             grain="investee meeting x safekeeping account",
             dimensions=[dict(name="vote_deadline_timestamp", attr="Vote Deadline Timestamp"),
                         dict(name="share_blocking", attr="Share Blocking Indicator"),
                         dict(name="ballot_status", attr="Ballot Status")],
             facts=[dict(name="record_date_shares", attr="Record Date Shares", note="Derived copy (28), read as given"),
                    dict(name="shares_on_loan_not_recalled", attr="Shares on Loan Not Recalled")],
             hidden=[("Ballot Safekeeping Account", "Join key; an individual's safekeeping account is personal data."),
                     ("Ballot Control Number", "Operational voting reference; not a slicer.")]),
        dict(name="vote_rationale", product="DP-132", entity="Fact Vote Rationale", kind="Fact",
             grain="agenda item x voting policy",
             dimensions=[dict(name="pre_declared_vote", attr="Pre-Declared Vote Indicator"),
                         dict(name="linked_engagement", attr="Linked Engagement")],
             hidden=[("Vote Rationale Text", "Free text; published in the stewardship report, not a slicer."),
                     ("Override Approved By", "A named employee (personal data); Unapproved Overrides counts blanks.")]),
        dict(name="advisor_recommendation", product="DP-132", entity="Fact Proxy Advisor Recommendation", kind="Fact",
             grain="agenda item x proxy advisor x advisor policy",
             dimensions=[dict(name="advisor_policy", attr="Advisor Policy"),
                         dict(name="advisor_recommended_vote", attr="Advisor Recommended Vote"),
                         dict(name="recommendation_revised", attr="Recommendation Revised Indicator")]),
        dict(name="recall_decision", product="DP-132", entity="Fact Lending Recall Decision", kind="Fact",
             grain="investee meeting x securities loan",
             dimensions=[dict(name="recall_decided", attr="Recall Decided Indicator"),
                         dict(name="materiality_assessment", attr="Materiality Assessment"),
                         dict(name="recall_requested_date", attr="Recall Requested Date")],
             hidden=[("Recall Decision Maker", "A named employee (personal data).")]),
        dict(name="voting_report", product="DP-132", entity="Fact Proxy Voting Report", kind="Fact",
             grain="proxy voting report per fund series, manager or client account and period",
             dimensions=[dict(name="proxy_voting_report_type", attr="Proxy Voting Report Type"),
                         dict(name="voting_report_period_end", attr="Voting Report Period End"),
                         dict(name="voting_report_approval_status", attr="Voting Report Approval Status"),
                         dict(name="no_votes", attr="No Votes Indicator")],
             hidden=[("Reporting Client Account", "An SMA client account (personal data); joins only.")]),
        dict(name="investee_meeting", product="DP-132", entity="Investee Meeting", kind="Dimension",
             dimensions=[dict(name="meeting_type", attr="Corporate Action Event Type"),
                         dict(name="investee_meeting_date", attr="Meeting Date"),
                         dict(name="investee_record_date", attr="Record Date")]),
        dict(name="agenda_item", product="DP-132", entity="Investee Meeting Agenda Item", kind="Dimension",
             dimensions=[dict(name="proposal_category", attr="Proposal Category"),
                         dict(name="agenda_item_proponent", attr="Agenda Item Proponent"),
                         dict(name="management_recommendation", attr="Management Recommendation")],
             hidden=[("Proposal Text", "Long text; shown in the voting record, not a slicer.")]),
        dict(name="voting_policy", product="DP-132", entity="Voting Policy", kind="Dimension",
             dimensions=[dict(name="voting_policy_name", attr="Voting Policy Name"),
                         dict(name="voting_policy_type", attr="Voting Policy Type"),
                         dict(name="adopted_benchmark_policy", attr="Adopted Benchmark Policy Name")],
             hidden=[("Policy Client", "A client's custom policy names the client (personal data).")]),
        dict(name="voting_authority", product="DP-132", entity="Voting Authority Arrangement", kind="Dimension",
             default_filter="authority " + _CURRENT.replace("effective_", "authority_effective_"),
             dimensions=[dict(name="voting_authority_holder", attr="Voting Authority Holder")],
             hidden=[("Authority Account", "An SMA client account (personal data); joins only.")]),

        # ================= DP-133 Engagement & Stewardship Reporting =================================================
        dict(name="engagement", product="DP-133", entity="Fact Engagement", kind="Fact",
             grain="engagement case x as-of date (weekly snapshot)",
             default_filter="as_of_date = latest weekly snapshot",
             always_filter=["Engagement Information Classification is not restricted, or the viewer is entitled to "
                            "MNPI-restricted engagements (DP-121 control)"],
             dimensions=[dict(name="engagement_as_of_date", attr="As-of Date Key"),
                         dict(name="engagement_theme", attr="Engagement Theme"),
                         dict(name="engagement_start_date", attr="Engagement Start Date"),
                         dict(name="engagement_status", attr="Engagement Status"),
                         dict(name="engagement_outcome", attr="Engagement Outcome"),
                         dict(name="passive_status_review", attr="Passive Status Review Indicator"),
                         dict(name="engagement_information_classification", attr="Engagement Information Classification"),
                         dict(name="engagement_lead", attr="Engagement Lead",
                              note="Employee key (personal data); stewardship team only")],
             hidden=[("Engagement Headline", "Can name issuer contacts; shown in the case, not across rows.")]),
        dict(name="engagement_objective", product="DP-133", entity="Fact Engagement Objective", kind="Fact",
             grain="engagement x objective sequence",
             dimensions=[dict(name="engagement_milestone_stage", attr="Engagement Milestone Stage"),
                         dict(name="objective_target_date", attr="Objective Target Date"),
                         dict(name="objective_achieved_date", attr="Objective Achieved Date")]),
        dict(name="engagement_interaction", product="DP-133", entity="Fact Engagement Interaction", kind="Fact",
             grain="one engagement interaction",
             dimensions=[dict(name="contact_medium", attr="Contact Medium"),
                         dict(name="interaction_date", attr="Interaction Date"),
                         dict(name="interaction_issuer_meeting", attr="Interaction Issuer Meeting")],
             hidden=[("Interaction Employee", "A named employee (personal data).")]),
        dict(name="escalation_action", product="DP-133", entity="Fact Escalation Action", kind="Fact",
             grain="engagement x escalation sequence",
             dimensions=[dict(name="escalation_action_type", attr="Escalation Action Type"),
                         dict(name="escalation_date", attr="Escalation Date"),
                         dict(name="escalation_agenda_item", attr="Escalation Agenda Item"),
                         dict(name="resulting_investment_decision", attr="Resulting Investment Decision")],
             hidden=[("Escalation Approver", "A named employee (personal data).")]),
        dict(name="reported_engagement", product="DP-133", entity="Fact Reported Engagement", kind="Fact",
             grain="stewardship report x engagement reported",
             dimensions=[dict(name="case_study", attr="Case Study Indicator"),
                         dict(name="issuer_named", attr="Issuer Named Indicator")]),
        dict(name="stewardship_report", product="DP-133", entity="Stewardship Report", kind="Dimension",
             dimensions=[dict(name="stewardship_framework", attr="Stewardship Framework"),
                         dict(name="stewardship_report_period_end", attr="Stewardship Report Period End"),
                         dict(name="stewardship_report_approval_status", attr="Stewardship Report Approval Status"),
                         dict(name="framework_assessment_result", attr="Framework Assessment Result")]),
        dict(name="initiative_membership", product="DP-133", entity="Fact Initiative Membership", kind="Fact",
             grain="collaborative initiative x legal entity x membership period",
             dimensions=[dict(name="initiative_membership_status", attr="Membership Status"),
                         dict(name="initiative_membership_from", attr="Membership Effective From")]),

        # ================= DP-134 ESG Data, Assessments & Exclusions (Confidential - Licensed) ========================
        dict(name="firm_esg_assessment", product="DP-134", entity="Fact Firm ESG Assessment", kind="Fact",
             grain="one firm ESG assessment of an issuer",
             always_filter=["Assessment Approval Status = 'Approved'"],
             default_filter="assessment effective on the as-of date (Assessment Effective To null or later)",
             dimensions=[dict(name="assessment_date", attr="Assessment Date"),
                         dict(name="firm_controversy_view", attr="Firm Controversy View"),
                         dict(name="assessment_approval_status", attr="Assessment Approval Status"),
                         dict(name="firm_esg_score", attr="Firm ESG Score", note="Per issuer; band it, never sum it"),
                         dict(name="environmental_pillar_score", attr="Environmental Pillar Score"),
                         dict(name="social_pillar_score", attr="Social Pillar Score"),
                         dict(name="governance_pillar_score", attr="Governance Pillar Score")]),
        dict(name="esg_rating", product="DP-134", entity="Fact ESG Rating Observation", kind="Fact",
             grain="issuer x source dataset x ESG rating type x as-of date",
             default_filter="latest Rating As-Of Date per issuer, source and rating type",
             dimensions=[dict(name="esg_rating_type", attr="ESG Rating Type"),
                         dict(name="esg_rating_value", attr="ESG Rating Value"),
                         dict(name="esg_rating_numeric_score", attr="ESG Rating Numeric Score"),
                         dict(name="rating_as_of_date", attr="Rating As-Of Date")]),
        dict(name="sustainability_observation", product="DP-134", entity="Fact Sustainability Observation", kind="Fact",
             grain="issuer or instrument x indicator x period end x source dataset x as-of date",
             default_filter="latest Observation As-Of Date per issuer, indicator, period end and source",
             dimensions=[dict(name="reporting_period_end", attr="Reporting Period End Date"),
                         dict(name="observation_data_basis", attr="Observation Data Basis"),
                         dict(name="observation_as_of_date", attr="Observation As-Of Date")],
             facts=[dict(name="observed_value", attr="Observed Value", note="Units differ by indicator; never summed across indicators")]),
        dict(name="exclusion_member", product="DP-134", entity="Fact Exclusion List Member", kind="Bridge",
             grain="exclusion list version x member (issuer or instrument) x effective period",
             default_filter="member " + _CURRENT.replace("effective_", "member_effective_"),
             dimensions=[dict(name="member_inclusion_type", attr="Member Inclusion Type"),
                         dict(name="member_effective_from", attr="Member Effective From"),
                         dict(name="member_effective_to", attr="Member Effective To")],
             facts=[dict(name="measured_revenue_percentage", attr="Measured Revenue Percentage", note="Per member; never summed")]),
        dict(name="exclusion_list", product="DP-134", entity="Sustainability Exclusion List", kind="Dimension",
             always_filter=["List Approval Status = 'Approved'"],
             dimensions=[dict(name="exclusion_list_name", attr="Exclusion List Name"),
                         dict(name="exclusion_list_version", attr="Exclusion List Version"),
                         dict(name="exclusion_policy_basis", attr="Exclusion Policy Basis"),
                         dict(name="revenue_threshold_percentage", attr="Revenue Threshold Percentage")]),
        dict(name="esg_indicator", product="DP-134", entity="Sustainability Indicator Definition", kind="Dimension",
             dimensions=[dict(name="esg_indicator_name", attr="Indicator Name"),
                         dict(name="esg_indicator_level", attr="Indicator Level"),
                         dict(name="esg_indicator_scope", attr="Sustainability Indicator Scope")]),

        # ================= DP-135 Sustainability Metrics & Disclosures (Confidential - Licensed) ======================
        dict(name="sustainability_metric", product="DP-135", entity="Fact Portfolio Sustainability Metric", kind="Fact",
             grain="portfolio, product or legal entity x period end x indicator x emission scopes x measurement basis",
             default_filter="Metric Portfolio is not null (portfolio scope); product and legal entity rows restate it",
             dimensions=[dict(name="metric_period_end", attr="Metric Period End Date"),
                         dict(name="emission_scopes_included", attr="Emission Scopes Included"),
                         dict(name="metric_measurement_basis", attr="Metric Measurement Basis"),
                         dict(name="metric_framework", attr="Metric Framework"),
                         dict(name="metric_calculation_standard", attr="Metric Calculation Standard"),
                         dict(name="metric_unit", attr="Metric Unit"),
                         dict(name="normalization_currency", attr="Normalization Currency"),
                         dict(name="metric_data_basis", attr="Metric Data Basis")],
             facts=[dict(name="metric_value", attr="Metric Value", note="Units differ by indicator; read through metrics"),
                    dict(name="metric_coverage_percentage", attr="Metric Coverage Percentage"),
                    dict(name="weighted_pcaf_data_quality_score", attr="Weighted PCAF Data Quality Score")]),
        dict(name="financed_emissions_holding", product="DP-135", entity="Fact Financed Emissions Holding", kind="Fact",
             grain="financed emissions metric (portfolio scope) x portfolio holding",
             always_filter=["the parent sustainability_metric row has Metric Portfolio not null (portfolio scope)"],
             dimensions=[dict(name="pcaf_asset_class", attr="PCAF Asset Class"),
                         dict(name="attribution_basis", attr="Attribution Basis"),
                         dict(name="pcaf_data_quality_score", attr="PCAF Data Quality Score", note="1 to 5; band it")],
             facts=[dict(name="holding_value_used", attr="Holding Value Used"),
                    dict(name="attribution_denominator_value", attr="Attribution Denominator Value"),
                    dict(name="attribution_factor", attr="Attribution Factor", note="Per holding; never summed"),
                    dict(name="attributed_emissions", attr="Attributed Emissions", note="tCO2e")]),
        dict(name="climate_target", product="DP-135", entity="Fact Climate Target", kind="Fact",
             grain="one climate target",
             dimensions=[dict(name="climate_target_type", attr="Climate Target Type"),
                         dict(name="target_emission_scopes", attr="Target Emission Scopes"),
                         dict(name="baseline_year", attr="Baseline Year"),
                         dict(name="target_year", attr="Target Year"),
                         dict(name="target_progress_status", attr="Target Progress Status"),
                         dict(name="target_status", attr="Target Status")],
             facts=[dict(name="baseline_value", attr="Baseline Value"),
                    dict(name="target_reduction_percentage", attr="Target Reduction Percentage")],
             hidden=[("AUM in Scope Percentage", "Not tied to certified Firm AUM (GAP-34-003); not published under an "
                                                 "AUM name until it is.")]),
        dict(name="sustainability_indicator", product="DP-135", entity="Sustainability Indicator Definition", kind="Dimension",
             dimensions=[dict(name="indicator_name", attr="Indicator Name"),
                         dict(name="indicator_level", attr="Indicator Level")]),
    ],

    shared=["DP-140/Portfolio", "DP-140/Portfolio Implementation Link", "DP-097/Instrument", "DP-098/Issuer",
            "DP-240/Party", "DP-115/Counterparty", "DP-004/Share Class", "DP-004/Investment Product",
            "DP-004/Investment Strategy", "DP-004/Model Portfolio", "DP-013/Calendar Date",
            "DP-013/Internal Legal Entity", "DP-013/Org Unit", "DP-167/Safekeeping Account",
            "DP-167/Safekeeping Account Assignment", "DP-212/Model", "DP-212/Model Validation", "DP-192/Employee",
            # WP2: the wealth client dimensions behind personal returns
            "DP-093/Account", "DP-093/Account Party Role", "DP-240/Household Membership", "DP-009/Coverage Assignment",
            "DP-009/Employee"],

    relationships=[
        # --- Official returns (DP-145) -------------------------------------------------------------------------------
        dict(frm="performance_return", to="DP-140/Portfolio", on="performance_return.return_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="performance_return", to="DP-004/Share Class",
             on="performance_return.return_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="performance_return", to="DP-004/Model Portfolio",
             on="performance_return.return_model_portfolio = model_portfolio.model_portfolio_id", type="many-to-one"),
        dict(frm="performance_return", to="gips_composite",
             on="performance_return.return_composite = gips_composite.composite_id", type="many-to-one"),
        dict(frm="performance_return", to="DP-013/Calendar Date",
             on="performance_return.return_period_end_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="restatement", to="performance_return",
             on="restatement.restated_return = performance_return.performance_return_id", type="many-to-one",
             warning=""),
        dict(frm="primary_benchmark", to="DP-004/Share Class",
             on="primary_benchmark.assigned_product_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="primary_benchmark", to="benchmark", on="primary_benchmark.assigned_benchmark = benchmark.benchmark_id",
             type="many-to-one"),
        dict(frm="benchmark_return", to="benchmark", on="benchmark_return.return_benchmark = benchmark.benchmark_id",
             type="many-to-one"),
        dict(frm="benchmark_return", to="DP-013/Calendar Date",
             on="benchmark_return.benchmark_period_end_date = calendar_date.calendar_date", type="many-to-one"),
        # --- Personal returns (DP-145, DP-532, DP-533) ---------------------------------------------------------------
        dict(frm="personal_return", to="DP-093/Account", on="personal_return.personal_return_account = account.account_id",
             type="many-to-one"),
        dict(frm="personal_return", to="household_performance_group",
             on="personal_return.personal_return_group = household_performance_group.household_performance_group_id",
             type="many-to-one"),
        dict(frm="personal_return", to="DP-013/Calendar Date",
             on="personal_return.personal_return_period_end_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="client_performance_profile", to="DP-093/Account",
             on="client_performance_profile.client_profile_account = account.account_id", type="many-to-one"),
        dict(frm="client_performance_profile", to="household_performance_group",
             on="client_performance_profile.client_profile_group = household_performance_group.household_performance_group_id",
             type="many-to-one"),
        dict(frm="client_performance_profile", to="calculation_policy",
             on="client_performance_profile.client_applied_calculation_policy = calculation_policy (code, version)",
             type="many-to-one"),
        dict(frm="client_performance_profile", to="benchmark",
             on="client_performance_profile.client_comparison_benchmark = benchmark.benchmark_id", type="many-to-one"),
        dict(frm="household_performance_group", to="DP-240/Party",
             on="household_performance_group.group_household = party.party_id (Party Type Household)", type="many-to-one"),
        dict(frm="household_group_member", to="household_performance_group",
             on="household_group_member.member_performance_group = household_performance_group.household_performance_group_id",
             type="many-to-one"),
        dict(frm="household_group_member", to="DP-093/Account",
             on="household_group_member.member_account = account.account_id", type="many-to-one"),
        dict(frm="DP-240/Household Membership", to="DP-093/Account Party Role",
             on="household_membership.household_member = account_party_role.role_party (Account Role Type Primary Owner "
                "or Joint Owner, both effective on the period end)",
             type="many-to-many",
             warning="Household to account is many-to-many and effective dated: a joint account belongs to every member's "
                     "household and a member's accounts change over time. Pin both memberships as of the period end "
                     "and count households or accounts with count(distinct); never sum account values through it."),
        dict(frm="displayed_personal_return", to="personal_return",
             on="displayed_personal_return.personal_rate_of_return_id = personal_return.personal_rate_of_return_id and "
                "the same version",
             type="many-to-one"),
        dict(frm="displayed_personal_return", to="DP-093/Account",
             on="displayed_personal_return.personal_return_account = account.account_id", type="many-to-one"),
        dict(frm="displayed_personal_return", to="household_performance_group",
             on="displayed_personal_return.personal_return_group = household_performance_group.household_performance_group_id",
             type="many-to-one"),
        dict(frm="DP-009/Coverage Assignment", to="DP-093/Account",
             on="coverage_assignment.covered_account = account.account_id (Primary Coverage Indicator = 'Y', Party "
                "Coverage Role = 'Primary Advisor', effective on the period end)",
             type="many-to-one"),
        dict(frm="client_return_exception", to="DP-093/Account",
             on="client_return_exception.exception_account = account.account_id", type="many-to-one"),
        dict(frm="client_return_exception", to="household_group_member",
             on="client_return_exception.exception_account = household_group_member.member_account (members in force on "
                "the as-of date)",
             type="many-to-many",
             warning="An account can sit in several household performance groups (the default group and client-defined "
                     "subsets): count groups or exceptions with count(distinct), never sum across the join."),
        dict(frm="personal_return_version", to="personal_return_version",
             on="personal_return_version.supersedes_personal_return = the superseded version (same Personal Rate of "
                "Return ID, lower version)",
             type="many-to-one"),
        # --- Book of record (DP-141, DP-142) --------------------------------------------------------------------------
        dict(frm="portfolio_transaction", to="DP-140/Portfolio",
             on="portfolio_transaction.transaction_portfolio = portfolio.portfolio_id", type="many-to-one"),
        dict(frm="portfolio_transaction", to="DP-097/Instrument",
             on="portfolio_transaction.transaction_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="portfolio_transaction", to="DP-115/Counterparty",
             on="portfolio_transaction.executing_broker = counterparty.party_id", type="many-to-one"),
        dict(frm="transaction_event", to="portfolio_transaction",
             on="transaction_event.event_transaction = portfolio_transaction.portfolio_transaction_id",
             type="many-to-one"),
        dict(frm="capital_activity", to="DP-140/Portfolio", on="capital_activity.activity_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="capital_activity", to="DP-004/Share Class",
             on="capital_activity.activity_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="holding", to="DP-140/Portfolio", on="holding.holding_portfolio = portfolio.portfolio_id", type="many-to-one"),
        dict(frm="holding", to="DP-097/Instrument", on="holding.held_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="holding", to="DP-013/Calendar Date", on="holding.holding_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="holding", to="approved_price",
             on="holding.held_instrument = approved_price.priced_instrument and holding.price_date = "
                "approved_price.price_date and approved_price.approved_pricing_point = the portfolio's business line "
                "pricing point (GAP-18-002)", type="many-to-one"),
        dict(frm="DP-097/Instrument", to="DP-098/Issuer", on="instrument.issuer = issuer.party_id", type="many-to-one"),
        dict(frm="tax_lot", to="DP-140/Portfolio", on="tax_lot.lot_portfolio = portfolio.portfolio_id", type="many-to-one"),
        dict(frm="tax_lot", to="DP-097/Instrument", on="tax_lot.lot_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="lot_relief", to="tax_lot", on="lot_relief.relieved_tax_lot = tax_lot.tax_lot_id", type="many-to-one"),
        dict(frm="lot_relief", to="portfolio_transaction",
             on="lot_relief.closing_transaction = portfolio_transaction.portfolio_transaction_id", type="many-to-one"),
        dict(frm="cash_balance", to="DP-140/Portfolio", on="cash_balance.cash_balance_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="cash_balance", to="DP-167/Safekeeping Account",
             on="cash_balance.cash_safekeeping_account = safekeeping_account.safekeeping_account_id", type="many-to-one"),
        dict(frm="projected_cash", to="DP-140/Portfolio", on="projected_cash.projection_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="position_snapshot", to="DP-140/Portfolio", on="position_snapshot.snapshot_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="valuation_summary", to="DP-140/Portfolio", on="valuation_summary.valued_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="valuation_summary", to="position_snapshot",
             on="valuation_summary.summary_snapshot = position_snapshot.(snapshot_portfolio, snapshot_type, "
                "snapshot_as_of_timestamp)", type="many-to-one"),
        dict(frm="DP-140/Portfolio Implementation Link", to="DP-140/Portfolio",
             on="portfolio_implementation_link.implementing_portfolio = portfolio.portfolio_id", type="many-to-one",
             warning=""),
        dict(frm="DP-140/Portfolio Implementation Link", to="DP-004/Investment Product",
             on="portfolio_implementation_link.implemented_product = investment_product.product_id and "
                "primary_implementation_indicator = 'Y'", type="many-to-one"),
        # --- Attribution and ex-post (DP-157) ------------------------------------------------------------------------
        dict(frm="attribution_result", to="performance_return",
             on="attribution_result.portfolio_return_record = performance_return.(performance_return_id, return_version)",
             type="many-to-one"),
        dict(frm="attribution_result", to="benchmark_return",
             on="attribution_result.benchmark_return_record = benchmark_return key", type="many-to-one"),
        dict(frm="attribution_result", to="attribution_model",
             on="attribution_result.applied_attribution_model = attribution_model.(attribution_model_code, "
                "attribution_model_version)", type="many-to-one"),
        dict(frm="attribution_effect", to="attribution_result",
             on="attribution_effect.effect_attribution_result = attribution_result.attribution_result_id",
             type="many-to-one"),
        dict(frm="attribution_segment", to="attribution_result",
             on="attribution_segment.segment_attribution_result = attribution_result.attribution_result_id",
             type="many-to-one"),
        dict(frm="attribution_model", to="DP-212/Model",
             on="attribution_model.model_inventory_reference = model.(model_id, model_version)", type="many-to-one"),
        dict(frm="DP-212/Model Validation", to="DP-212/Model",
             on="model_validation.validated_model = model.(model_id, model_version)", type="many-to-one",
             warning=""),
        dict(frm="contribution", to="performance_return",
             on="contribution.contribution_portfolio_return_record = performance_return.(performance_return_id, "
                "return_version)", type="many-to-one"),
        dict(frm="contribution", to="DP-097/Instrument", on="contribution.contribution_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="ex_post_statistic", to="DP-140/Portfolio", on="ex_post_statistic.statistic_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="ex_post_statistic", to="DP-004/Share Class",
             on="ex_post_statistic.statistic_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="ex_post_statistic", to="gips_composite",
             on="ex_post_statistic.statistic_composite = gips_composite.composite_id", type="many-to-one"),
        dict(frm="ex_post_statistic", to="benchmark", on="ex_post_statistic.comparison_benchmark = benchmark.benchmark_id",
             type="many-to-one"),
        # --- GIPS (DP-158) -------------------------------------------------------------------------------------------
        dict(frm="composite_statistic", to="gips_composite",
             on="composite_statistic.statistic_composite = gips_composite.composite_id", type="many-to-one"),
        dict(frm="gips_composite", to="benchmark", on="gips_composite.composite_benchmark = benchmark.benchmark_id",
             type="many-to-one"),
        dict(frm="composite_membership", to="gips_composite",
             on="composite_membership.membership_composite = gips_composite.composite_id", type="many-to-one"),
        dict(frm="composite_membership", to="DP-140/Portfolio",
             on="composite_membership.member_portfolio = portfolio.portfolio_id", type="many-to-one",
             warning="A portfolio can belong to more than one composite (for example a strategy composite and a broader "
                     "one). Grouping portfolios by composite counts it under each; composite member counts do not add "
                     "up to a count of portfolios."),
        dict(frm="significant_flow", to="gips_composite", on="significant_flow.flow_composite = gips_composite.composite_id",
             type="many-to-one"),
        dict(frm="significant_flow", to="DP-140/Portfolio", on="significant_flow.flow_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="carve_out", to="DP-140/Portfolio", on="carve_out.carve_out_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="gips_firm_assets", to="gips_firm", on="gips_firm_assets.gips_firm_key = gips_firm.gips_firm_code",
             type="many-to-one"),
        dict(frm="gips_verification", to="gips_firm", on="gips_verification.verified_gips_firm = gips_firm.gips_firm_code",
             type="many-to-one"),
        dict(frm="gips_verification", to="DP-240/Party", on="gips_verification.verifier = party.party_id",
             type="many-to-one"),
        # --- Scorecard peers (DP-159) --------------------------------------------------------------------------------
        dict(frm="peer_snapshot", to="peer_fund", on="peer_snapshot.peer_fund_key = peer_fund.peer_fund_id",
             type="many-to-one"),
        dict(frm="peer_snapshot", to="peer_universe", on="peer_snapshot.peer_universe = peer_universe.peer_universe_id",
             type="many-to-one"),
        dict(frm="peer_universe_member", to="peer_universe",
             on="peer_universe_member.peer_universe_key = peer_universe.peer_universe_id", type="many-to-one"),
        dict(frm="peer_universe_member", to="peer_fund", on="peer_universe_member.member_fund = peer_fund.peer_fund_id",
             type="many-to-one"),
        dict(frm="peer_universe", to="DP-004/Investment Strategy",
             on="peer_universe.own_strategy_compared = investment_strategy.strategy_id", type="many-to-one"),
        dict(frm="peer_fund", to="DP-004/Share Class", on="peer_fund.isin = share_class.isin", type="many-to-many",
             warning="ISIN match only (GAP-11-007): a peer fund record can match no own share class or, after an "
                     "identifier reuse, more than one. Use it to place own share classes in peer ranks, never to add up "
                     "peer values by share class."),
        # --- Decisions and governance (DP-126) -----------------------------------------------------------------------
        dict(frm="decision_scope", to="investment_decision",
             on="decision_scope.scoped_decision = investment_decision.investment_decision_id", type="many-to-one"),
        dict(frm="decision_scope", to="DP-140/Portfolio", on="decision_scope.scope_portfolio = portfolio.portfolio_id",
             type="many-to-one",
             warning="A decision can scope many portfolios. Grouping decisions by portfolio counts the decision once "
                     "per portfolio; count decisions with count(distinct investment_decision_id)."),
        dict(frm="investment_decision", to="DP-004/Investment Strategy",
             on="investment_decision.decision_strategy = investment_strategy.strategy_id", type="many-to-one"),
        dict(frm="investment_decision", to="DP-097/Instrument",
             on="investment_decision.decision_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="investment_decision", to="DP-013/Org Unit",
             on="investment_decision.decision_investment_team = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="investment_decision", to="DP-212/Model",
             on="investment_decision.decision_algorithm = model.model_id (the 24 Decision Algorithm's model)", type="many-to-one"),
        dict(frm="investment_decision", to="committee_decision",
             on="investment_decision.linked_committee_decision = committee_decision key", type="many-to-one"),
        dict(frm="committee_decision", to="investment_committee",
             on="committee_decision.decision_committee = investment_committee.investment_committee_code",
             type="many-to-one"),
        dict(frm="committee_decision", to="committee_meeting",
             on="committee_decision.(decision_committee, decision_meeting_date) = committee_meeting.(meeting_committee, "
                "meeting_date)", type="many-to-one"),
        dict(frm="committee_meeting", to="investment_committee",
             on="committee_meeting.meeting_committee = investment_committee.investment_committee_code",
             type="many-to-one"),
        dict(frm="committee_membership", to="investment_committee",
             on="committee_membership.member_committee = investment_committee.investment_committee_code",
             type="many-to-one"),
        dict(frm="committee_membership", to="DP-192/Employee",
             on="committee_membership.committee_member = employee.employee_id", type="many-to-one"),
        dict(frm="pm_assignment", to="DP-140/Portfolio", on="pm_assignment.assigned_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="pm_assignment", to="DP-192/Employee", on="pm_assignment.assigned_manager = employee.employee_id",
             type="many-to-one"),
        dict(frm="pm_assignment", to="DP-013/Org Unit", on="pm_assignment.assigned_investment_team = org_unit.org_unit_id",
             type="many-to-one"),
        dict(frm="disclosed_pm_assignment", to="DP-004/Investment Product",
             on="disclosed_pm_assignment.investment_product_key = investment_product.product_id", type="many-to-one"),
        dict(frm="disclosed_pm_assignment", to="DP-192/Employee",
             on="disclosed_pm_assignment.portfolio_manager = employee.employee_id", type="many-to-one"),
        # --- Asset allocation (DP-127) -------------------------------------------------------------------------------
        dict(frm="policy_allocation", to="allocation_policy",
             on="policy_allocation.line_allocation_policy = allocation_policy key", type="many-to-one"),
        dict(frm="policy_allocation", to="DP-140/Portfolio", on="policy_allocation.portfolio_key = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="policy_allocation", to="DP-013/Calendar Date",
             on="policy_allocation.as_of_date_key = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="allocation_policy", to="benchmark", on="allocation_policy.policy_benchmark = benchmark.benchmark_id",
             type="many-to-one"),
        dict(frm="allocation_policy", to="DP-004/Investment Strategy",
             on="allocation_policy.policy_strategy = investment_strategy.strategy_id", type="many-to-one"),
        dict(frm="allocation_policy", to="committee_decision",
             on="allocation_policy.approving_committee_decision = committee_decision key", type="many-to-one"),
        dict(frm="glide_path_point", to="allocation_policy",
             on="glide_path_point.glide_path_policy = allocation_policy key", type="many-to-one"),
        dict(frm="tactical_view", to="DP-004/Investment Strategy",
             on="tactical_view.view_strategy = investment_strategy.strategy_id", type="many-to-one"),
        dict(frm="tactical_view", to="committee_decision",
             on="tactical_view.view_committee_decision = committee_decision key", type="many-to-one"),
        # --- Proxy voting (DP-132) -----------------------------------------------------------------------------------
        dict(frm="vote_instruction", to="ballot", on="vote_instruction.voted_ballot = ballot key", type="many-to-one"),
        dict(frm="vote_instruction", to="agenda_item", on="vote_instruction.voted_agenda_item = agenda_item key",
             type="many-to-one"),
        dict(frm="vote_instruction", to="vote_rationale", on="vote_instruction.applied_vote_rationale = vote_rationale key",
             type="many-to-one"),
        dict(frm="ballot", to="investee_meeting",
             on="ballot.ballot_meeting = investee_meeting.corporate_action_event_id", type="many-to-one"),
        dict(frm="ballot", to="voting_authority", on="ballot.governing_voting_authority = voting_authority key",
             type="many-to-one"),
        dict(frm="ballot", to="DP-167/Safekeeping Account",
             on="ballot.ballot_safekeeping_account = safekeeping_account.safekeeping_account_id", type="many-to-one"),
        dict(frm="DP-167/Safekeeping Account Assignment", to="DP-167/Safekeeping Account",
             on="safekeeping_account_assignment.assigned_safekeeping_account = safekeeping_account.safekeeping_account_id",
             type="many-to-one"),
        dict(frm="voting_authority", to="DP-140/Portfolio", on="voting_authority.authority_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="voting_authority", to="voting_policy",
             on="voting_authority.applied_voting_policy = voting_policy.voting_policy_id", type="many-to-one"),
        dict(frm="vote_rationale", to="voting_policy",
             on="vote_rationale.rationale_voting_policy = voting_policy.voting_policy_id", type="many-to-one"),
        dict(frm="vote_rationale", to="engagement",
             on="vote_rationale.linked_engagement = engagement.engagement_id (latest snapshot)", type="many-to-one"),
        dict(frm="advisor_recommendation", to="agenda_item",
             on="advisor_recommendation.recommended_agenda_item = agenda_item key", type="many-to-one"),
        dict(frm="advisor_recommendation", to="DP-240/Party", on="advisor_recommendation.proxy_advisor = party.party_id",
             type="many-to-one"),
        dict(frm="agenda_item", to="investee_meeting",
             on="agenda_item.agenda_meeting = investee_meeting.corporate_action_event_id", type="many-to-one"),
        dict(frm="investee_meeting", to="DP-097/Instrument", on="investee_meeting.event_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="recall_decision", to="investee_meeting",
             on="recall_decision.recall_meeting = investee_meeting.corporate_action_event_id", type="many-to-one"),
        dict(frm="voting_report", to="DP-004/Investment Product",
             on="voting_report.reporting_fund_series = investment_product.product_id", type="many-to-one"),
        dict(frm="voting_report", to="DP-013/Internal Legal Entity",
             on="voting_report.reporting_manager_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        # --- Engagement (DP-133) -------------------------------------------------------------------------------------
        dict(frm="engagement", to="DP-240/Party", on="engagement.engaged_party = party.party_id", type="many-to-one"),
        dict(frm="engagement", to="DP-192/Employee", on="engagement.engagement_lead = employee.employee_id",
             type="many-to-one"),
        dict(frm="engagement_objective", to="engagement",
             on="engagement_objective.objective_engagement = engagement.engagement_id (one as-of snapshot)",
             type="many-to-one"),
        dict(frm="engagement_interaction", to="engagement",
             on="engagement_interaction.interaction_engagement = engagement.engagement_id (one as-of snapshot)",
             type="many-to-one"),
        dict(frm="escalation_action", to="engagement",
             on="escalation_action.escalated_engagement = engagement.engagement_id (one as-of snapshot)",
             type="many-to-one"),
        dict(frm="reported_engagement", to="engagement",
             on="reported_engagement.reported_engagement_case = engagement.engagement_id (one as-of snapshot)",
             type="many-to-one"),
        dict(frm="reported_engagement", to="stewardship_report",
             on="reported_engagement.stewardship_report_key = stewardship_report.stewardship_report_id",
             type="many-to-one"),
        dict(frm="stewardship_report", to="DP-013/Internal Legal Entity",
             on="stewardship_report.stewardship_reporting_entity = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="initiative_membership", to="DP-240/Party",
             on="initiative_membership.membership_initiative = party.party_id", type="many-to-one"),
        dict(frm="initiative_membership", to="DP-013/Internal Legal Entity",
             on="initiative_membership.member_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="DP-098/Issuer", to="DP-240/Party", on="issuer.party_id = party.party_id", type="one-to-one"),
        # --- ESG data (DP-134) ---------------------------------------------------------------------------------------
        dict(frm="firm_esg_assessment", to="DP-098/Issuer", on="firm_esg_assessment.assessed_issuer = issuer.party_id",
             type="many-to-one"),
        dict(frm="firm_esg_assessment", to="DP-212/Model",
             on="firm_esg_assessment.assessment_methodology_name = model.(model_id, model_version)", type="many-to-one"),
        dict(frm="esg_rating", to="DP-098/Issuer", on="esg_rating.rated_issuer = issuer.party_id", type="many-to-one"),
        dict(frm="sustainability_observation", to="DP-098/Issuer",
             on="sustainability_observation.observed_issuer = issuer.party_id", type="many-to-one"),
        dict(frm="sustainability_observation", to="esg_indicator",
             on="sustainability_observation.observed_indicator = esg_indicator.(indicator_code, indicator_version)",
             type="many-to-one"),
        dict(frm="exclusion_member", to="exclusion_list",
             on="exclusion_member.member_list = exclusion_list.(exclusion_list_code, exclusion_list_version)",
             type="many-to-one"),
        dict(frm="exclusion_member", to="DP-098/Issuer", on="exclusion_member.excluded_issuer = issuer.party_id",
             type="many-to-one",
             warning="An issuer can sit on several exclusion lists. Grouping excluded holdings by list counts a holding "
                     "under each list it is caught by; the total of excluded holdings is computed once per holding."),
        dict(frm="exclusion_member", to="DP-097/Instrument",
             on="exclusion_member.excluded_instrument = instrument.instrument_id", type="many-to-one"),
        # --- Sustainability metrics (DP-135) -------------------------------------------------------------------------
        dict(frm="sustainability_metric", to="DP-140/Portfolio", on="sustainability_metric.metric_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="sustainability_metric", to="DP-004/Investment Product",
             on="sustainability_metric.metric_product = investment_product.product_id", type="many-to-one"),
        dict(frm="sustainability_metric", to="DP-013/Internal Legal Entity",
             on="sustainability_metric.metric_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="sustainability_metric", to="sustainability_indicator",
             on="sustainability_metric.metric_indicator = sustainability_indicator.(indicator_code, indicator_version)",
             type="many-to-one"),
        dict(frm="sustainability_metric", to="DP-212/Model",
             on="sustainability_metric.metric_model_name = model.(model_id, model_version)", type="many-to-one"),
        dict(frm="financed_emissions_holding", to="sustainability_metric",
             on="financed_emissions_holding.fact_portfolio_sustainability_metric_key = sustainability_metric key",
             type="many-to-one"),
        dict(frm="financed_emissions_holding", to="holding",
             on="financed_emissions_holding.detail_holding = holding.holding_id", type="many-to-one"),
        dict(frm="financed_emissions_holding", to="DP-098/Issuer",
             on="financed_emissions_holding.detail_issuer = issuer.party_id", type="many-to-one"),
        dict(frm="climate_target", to="DP-140/Portfolio", on="climate_target.target_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="climate_target", to="DP-013/Internal Legal Entity",
             on="climate_target.target_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="climate_target", to="sustainability_indicator",
             on="climate_target.target_indicator = sustainability_indicator.(indicator_code, indicator_version)", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Return basis", levels=["performance_return.return_subject_type", "performance_return.return_fee_basis",
                                          "performance_return.return_currency"]),
        dict(name="Personal return basis", levels=["personal_return.personal_return_subject_type",
                                                   "personal_return.personal_return_fee_basis",
                                                   "personal_return.personal_return_period_basis"]),
        dict(name="Attribution model", levels=["attribution_model.attribution_method",
                                               "attribution_model.attribution_model_code",
                                               "attribution_model.attribution_model_version"]),
        dict(name="Attribution effect", levels=["attribution_effect.attribution_effect_type",
                                                "attribution_effect.effect_segment_code"]),
        dict(name="Policy line", levels=["allocation_policy.allocation_policy_type", "allocation_policy.allocation_policy_name",
                                         "policy_allocation.policy_asset_class", "policy_allocation.policy_sub_class"]),
        dict(name="Proposal", levels=["agenda_item.agenda_item_proponent", "agenda_item.proposal_category"]),
        dict(name="Sustainability indicator", levels=["sustainability_indicator.indicator_level", "sustainability_indicator.indicator_name"]),
    ],

    metrics=[
        # ================= Certified, owned here (CD-293, CD-320; source DP-145) ======================================
        dict(name="Official Return", aggregation="non_additive",
             expr="performance_return.return_value of the version of record (Return Status Final or Restated, highest "
                  "Return Version per return key), with subject, period, fee basis, net fee basis, calculation type, "
                  "price basis, tax basis, sales charge basis and currency all fixed",
             source=("DP-145", "Official Return"),
             description="The firm's certified return for a portfolio, share class, account, composite or model "
                         "portfolio over a period, on a stated fee, price and tax basis.",
             note="Never summed, averaged or chained across rows in the tool: a longer period is a separate published "
                  "row. Preliminary rows are not certified and are outside the always-on filter. Every other model and "
                  "product reads this metric (CD-320)."),
        dict(name="Benchmark Return", aggregation="non_additive",
             expr="benchmark_return.benchmark_return_value of the version of record (Final or Restated, highest version) "
                  "for one benchmark, period, return type, currency and hedged basis",
             source=("DP-145", "Benchmark Return"),
             description="The certified return of a benchmark over a period, in a stated currency and hedged basis.",
             note="Paired with an Official Return on the same period end, period basis and currency; the share class "
                  "pairing uses primary_benchmark effective at the period end, a composite its Composite Benchmark."),

        dict(name="Personal Rate of Return", aggregation="non_additive",
             expr="personal_return.personal_return_value of the version of record (Personal Return Status Final or "
                  "Restated, highest Personal Return Version per Personal Rate of Return ID), with the subject (account or "
                  "household performance group), period start and end, Personal Return Method (pinned in always_filter), "
                  "calculation method and fee basis all fixed",
             source=("DP-145", "Personal Return Value"),
             description="The certified personal rate of return of a client account or household over a period, "
                         "time-weighted or money-weighted, net or gross of fees.",
             note="Certified (CW-011, CW-129). One method per query: the method is a required always_filter parameter, "
                  "so a time-weighted and a money-weighted return never share a result. Never summed, averaged or "
                  "chained across accounts or periods; a household return is DP-145's own household-group row (the "
                  "default group follows 02 Household Membership on the period end), never built from member accounts. "
                  "Null where DP-145 suppresses it (see [Suppressed Personal Returns]). DP-532 displays it and DP-533 "
                  "tests it; neither recalculates it, and every other model references it as SM-08/Personal Rate of "
                  "Return."),

        # ================= Certified, owned elsewhere =================================================================
        dict(name="Firm AUM", ref="SM-11/Firm AUM",
             note="Shown beside returns and composite assets; Portfolio Market Value (IBOR) and GIPS figures are never "
                  "substituted for it (CD-292)."),
        dict(name="Class Net Assets", ref="SM-11/Class Net Assets",
             note="The weight in Fund Assets Ahead of Benchmark %; NAV of record at the as-of month-end."),
        dict(name="Fund Total Net Assets", ref="SM-11/Fund Total Net Assets"),
        dict(name="NAV per Share", ref="SM-11/NAV per Share",
             note="The NAV behind share class returns; Share Class Returns on NAV of Record % checks the link."),
        dict(name="Ex-Ante Tracking Error", ref="SM-10/Ex-Ante Tracking Error",
             note="Read for the scorecard (DP-159) and the ex-ante versus ex-post comparison (DP-157), by the portfolio "
                  "whose primary implementation link names the fund (CD-324)."),
        dict(name="Ex-Ante VaR", ref="SM-10/Ex-Ante VaR"),
        dict(name="Net Flows", ref="SM-20/Net Flows",
             note="Own-fund flows shown beside share class returns by share class and month; Portfolio Net Capital "
                  "Activity is a book cash flow and is never net flows."),
        dict(name="Client Assets", ref="SM-20/Client Assets",
             note="Client assets by account, household or offering, shown beside personal returns; never added to Firm "
                  "AUM (the two overlap by design, CW-011), and Ending Market Value on a return row is never substituted "
                  "for it."),

        # ================= DP-145 Official Returns (other) ============================================================
        dict(name="Excess Return", aggregation="non_additive",
             expr="[Official Return] of a share class - [Benchmark Return] of its primary benchmark (primary_benchmark "
                  "effective at return_period_end) for the same period and currency (arithmetic)",
             source=("DP-145", "Excess Return"),
             description="How far a share class's official return was above or below its primary benchmark.",
             note="Share class subjects only; composites use Composite Excess Return (DP-158). Derived from two certified "
                  "numbers; not itself certified."),
        dict(name="Share Class Returns on NAV of Record %", aggregation="ratio",
             numerator="count of share class Official Returns whose Start and End NAV Records resolve to an approved, "
                       "highest-version, non-shadow NAV",
             denominator="count of share class Official Returns in the selection",
             source=("DP-145", "Share Class Returns on NAV of Record %"),
             description="Share of share class returns calculated on the NAV of record."),
        dict(name="Benchmark Return Tie-Out", aggregation="non_additive",
             expr="per unblended benchmark and period: benchmark_return_value - (End Index Level / Start Index Level - 1); "
                  "flagged beyond 0.0001",
             source=("DP-145", "Benchmark Return Tie-Out"),
             description="Checks a benchmark return against the index levels it was computed from."),
        dict(name="Return Component Tie-Out", aggregation="non_additive",
             expr="per single-period time-weighted return: return_value - (income_return + capital_return); flagged "
                  "beyond 0.0001",
             source=("DP-145", "Return Component Tie-Out"),
             description="Checks that income and capital components add up to the return."),
        dict(name="Periods Closed On Time %", aggregation="ratio",
             numerator="count of period_close rows with Period Close Status = 'Final' and final_release_timestamp by "
                       "business day 7 after close_period_end",
             denominator="count of period_close rows due in the selection",
             source=("DP-145", "Periods Closed On Time %"),
             description="Share of performance closes released as final by the deadline.",
             note="Business day 7 is a drafting assumption until 32 records the deadline (GAP-32-001)."),
        dict(name="Material Restatements", aggregation="additive",
             expr="count(restatement rows) where material_error = 'Y' and restatement_date in range",
             source=("DP-145", "Material Restatements"),
             description="Number of material restatements of official returns, by cause.",
             note="The mean absolute Restatement Return Difference is shown beside it as avg(abs(restatement_return_"
                  "difference)) over the same rows."),
        dict(name="Unreviewed Hypothetical Returns", aggregation="count_distinct",
             expr="count(distinct performance_return_id) where hypothetical = 'Y' and Hypothetical Compliance Review is "
                  "null (the hypothetical default filter removed)",
             source=("DP-145", "Unreviewed Hypothetical Returns"),
             description="Number of hypothetical returns without a compliance review."),

        # ================= DP-145 Personal Rate of Return controls ==================================================
        dict(name="Suppressed Personal Returns", aggregation="count_distinct",
             expr="count(distinct personal_return subject: personal_return_account or personal_return_group) whose "
                  "personal_return_value is null for the period, by client_performance_profile.return_suppression_reason "
                  "and, for open exceptions, client_return_exception.client_return_exception_type",
             source=("DP-145", "Suppressed Personal Returns"),
             description="Client accounts and households whose personal return is withheld for the period, by reason.",
             note="DP-145's suppression rule: a Return Suppression Reason on the subject's profile, or an open Client "
                  "Return Exception with Suppresses Return Indicator = Y. DP-532 and DP-533 read this number as "
                  "published."),
        dict(name="Households Without Default Performance Group", aggregation="count_distinct",
             expr="count(distinct DP-240 Client Households) with a member (Household Membership effective on the period "
                  "end) owning an account that has a client_performance_profile but no active household_performance_group "
                  "of performance_group_type = 'Default (All Household Accounts)'; plus default groups whose "
                  "household_group_member accounts differ from the accounts of the household members on the period end",
             source=("DP-145", "Households Without Default Performance Group"),
             description="Households that cannot show a household return because their default performance group is "
                         "missing or out of step with the household's accounts.",
             note="Household membership is pinned as of the period end (many-to-many, effective dated)."),
        dict(name="Restated Personal Returns Requiring Notification", aggregation="count_distinct",
             expr="count(distinct personal_return_version.personal_rate_of_return_id, personal_return_version) with "
                  "version_status = 'Restated', version_supersedes populated and version_client_notification = 'Y', by "
                  "version_restatement_cause",
             source=("DP-145", "Restated Personal Returns Requiring Notification"),
             description="Restated personal returns that clients must be told about, by restatement cause.",
             note="Counted on DP-533's version table, which holds every version; DP-533 publishes the same population "
                  "by method and fee basis with the size of each change."),

        # ================= DP-532 Household & Account Performance View ==============================================
        dict(name="Displayed Personal Returns", aggregation="count_distinct",
             expr="count(distinct displayed_personal_return.personal_rate_of_return_id) on the publication snapshot with "
                  "a [Personal Rate of Return] value, by displayed_subject_type, displayed_method, displayed_fee_basis and "
                  "displayed_period_basis",
             source=("DP-532", "Displayed Personal Returns"),
             description="Account and household returns shown to clients and advisors for the period."),
        dict(name="Preliminary Returns Withheld", aggregation="count_distinct",
             expr="count(distinct displayed_personal_return.personal_rate_of_return_id) of current versions with "
                  "displayed_status = 'Preliminary' withheld from display ('not yet final'), by displayed_period_basis",
             source=("DP-532", "Preliminary Returns Withheld"),
             description="Personal returns held back from clients because they are not yet final."),
        dict(name="Return Method and Basis Disclosure", aggregation="ratio",
             numerator="count of displayed rows with displayed_method, displayed_calculation_method, displayed_fee_basis, "
                       "displayed_period_basis and displayed_annualized all populated and the profile's "
                       "calculation_policy (External Cash Flow Timing, Large Cash Flow Threshold) resolved",
             denominator="count of displayed rows on the publication snapshot",
             source=("DP-532", "Return Method and Basis Disclosure"),
             description="Share of displayed personal returns printed with their full method, basis and policy "
                         "disclosure."),
        dict(name="Personal Return Less Comparison Benchmark", aggregation="non_additive",
             expr="per displayed row: [Personal Rate of Return] - [Benchmark Return] of the profile's "
                  "client_comparison_benchmark for the same period start and end and annualization (Benchmark Return Type "
                  "'Net Total Return'), in percentage points; blank where either is blank",
             source=("DP-532", "Personal Return Less Comparison Benchmark"),
             description="How far a client's personal return was above or below its comparison benchmark.",
             note="A presentation difference of two certified numbers, not a return; never summed or averaged across "
                  "clients."),
        dict(name="Profiles Without Comparison Benchmark", aggregation="count_distinct",
             expr="count(distinct client_performance_profile subject) in force on the period end with "
                  "client_comparison_benchmark blank, by client_profile_subject_type",
             source=("DP-532", "Profiles Without Comparison Benchmark"),
             description="Client performance profiles with no benchmark to compare the personal return with."),
        dict(name="Account Return Coverage %", aggregation="ratio",
             numerator="count(distinct open DP-093 accounts opened before the period start) with a displayed account row "
                       "(a [Personal Rate of Return] value or a suppression label) for the period",
             denominator="count(distinct open accounts) with a client_performance_profile whose performance_start_date is "
                         "on or before the period start",
             source=("DP-532", "Account Return Coverage %"),
             description="Share of profiled open accounts that show a personal return or a suppression label.",
             note="By Account Type and Account Business Line (DP-093/Account)."),
        dict(name="Household Return Coverage %", aggregation="ratio",
             numerator="count(distinct DP-240 Client Households) with an active member (Household Membership effective on "
                       "the period end) owning a profiled account (Account Party Role Primary Owner or Joint Owner) whose "
                       "Default (All Household Accounts) household_performance_group has a displayed household row",
             denominator="count(distinct such households)",
             source=("DP-532", "Household Return Coverage %"),
             description="Share of households with profiled accounts that show a household return.",
             note="Household membership and account roles pinned as of the period end."),
        dict(name="Household Group Members Shown", aggregation="count_distinct",
             expr="count(distinct household_group_member.member_account) in force on the period end for each displayed "
                  "household group, by performance_group_type",
             source=("DP-532", "Household Group Members Shown"),
             description="The accounts a displayed household return covers, as printed beside it.",
             note="Per household group; an account in two groups is counted in each, never summed across groups."),
        dict(name="Rows Without Advisor of Record", aggregation="count_distinct",
             expr="count(distinct displayed rows) with no primary DP-009 Coverage Assignment (Primary Coverage Indicator "
                  "= 'Y', Party Coverage Role = 'Primary Advisor', effective on the period end) under the 03 precedence: "
                  "the account itself, else an owner of the account (Account Party Role Primary Owner or Joint Owner) "
                  "with Covered Account blank, else the account's Client Household; for a household row, the household's "
                  "assignment",
             source=("DP-532", "Rows Without Advisor of Record"),
             description="Displayed personal returns with no advisor of record, visible to the client and service roles "
                         "only."),
        dict(name="Restated Returns Displayed", aggregation="count_distinct",
             expr="count(distinct displayed_personal_return.personal_rate_of_return_id) with displayed_status = "
                  "'Restated', by displayed_period_end",
             source=("DP-532", "Restated Returns Displayed"),
             description="Restated personal returns shown to clients, with the superseded value available to service "
                         "roles."),

        # ================= DP-533 Personal Return Exceptions, Suppression & Restatements ============================
        dict(name="Open Return Exceptions", aggregation="count_distinct",
             expr="count(distinct client_return_exception rows: account, exception date, type) with "
                  "return_exception_status = 'Open' on the as-of snapshot, by client_return_exception_type and "
                  "suppresses_return, with business-day age from exception_date to the as-of date in buckets (0-2, 3-5, "
                  "6-10, over 10)",
             source=("DP-533", "Open Return Exceptions"),
             description="Open personal return exceptions by type, suppression effect and age."),
        dict(name="Exceptions Aged Over 5 Business Days", aggregation="count_distinct",
             expr="[Open Return Exceptions] with business-day age over 5, by client_return_exception_type and the owning "
                  "queue (Missing Price: pricing, DP-148; Unposted Corporate Action: client asset servicing, DP-452; Large "
                  "External Flow and Conversion Gap: performance operations)",
             source=("DP-533", "Exceptions Aged Over 5 Business Days"),
             description="Open return exceptions past the 5-business-day service level, by owning queue."),
        dict(name="Household Groups Affected by Open Exceptions", aggregation="count_distinct",
             expr="count(distinct household_performance_group_id) with performance_group_status = 'Active' and a member "
                  "account in force on the as-of date carrying an open client_return_exception with suppresses_return = "
                  "'Y', by performance_group_type and client_return_exception_type",
             source=("DP-533", "Household Groups Affected by Open Exceptions"),
             description="Household returns held back by an open exception on one of their accounts."),
        dict(name="Suppressed Returns Published as Values", aggregation="count_distinct",
             expr="count(distinct personal_return_id) of current versions (Final or Restated, highest version) with "
                  "personal_return_value populated whose subject DP-145's suppression rule marks as suppressed for the "
                  "period end (the subjects of [Suppressed Personal Returns])",
             source=("DP-533", "Suppressed Returns Published as Values"),
             description="Control, zero expected: personal returns published although they should be suppressed."),
        dict(name="Profiles Missing Start Date or Policy", aggregation="count_distinct",
             expr="count(distinct client_performance_profile subject) in force with performance_start_date blank, "
                  "client_applied_calculation_policy blank, or a policy that resolves to no calculation_policy (code and "
                  "version) with policy_effective_from on or before the as-of date",
             source=("DP-533", "Profiles Missing Start Date or Policy"),
             description="Client performance profiles that cannot produce a return because a start date or policy is "
                         "missing."),
        dict(name="Profiles on Superseded Policy Version", aggregation="count_distinct",
             expr="count(distinct client_performance_profile subject) in force whose client_applied_calculation_policy "
                  "names a calculation_policy_version lower than the highest version of the same calculation_policy_code "
                  "effective on the as-of date",
             source=("DP-533", "Profiles on Superseded Policy Version"),
             description="Client performance profiles still on an old calculation policy version."),
        dict(name="Open Accounts Without Performance Profile", aggregation="count_distinct",
             expr="count(distinct DP-093 accounts) with Account Status 'Open', Account Open Date more than one month "
                  "before the as-of date and Account Type in (Brokerage Account, Fund-Only Account, Managed Advisory "
                  "Account, Participant Account, Fiduciary Account) with no client_performance_profile, by Account Type "
                  "and Account Business Line",
             source=("DP-533", "Open Accounts Without Performance Profile"),
             description="Open client accounts that get no personal return because no performance profile exists."),
        dict(name="Exceptions on Closed Accounts", aggregation="count_distinct",
             expr="count(distinct open client_return_exception rows) whose exception_account has Account Status "
                  "'Closed' and an Account Close Date before exception_date",
             source=("DP-533", "Exceptions on Closed Accounts"),
             description="Open return exceptions raised on accounts already closed."),
        dict(name="Large Flow Exceptions Below Policy Threshold", aggregation="count_distinct",
             expr="count(distinct client_return_exception rows) with client_return_exception_type = 'Large External "
                  "Flow' whose account's monthly personal_return_version row containing exception_date has |Net External "
                  "Flows| / Beginning Market Value below the large_cash_flow_threshold of the profile's calculation_policy",
             source=("DP-533", "Large Flow Exceptions Below Policy Threshold"),
             description="Large flow exceptions raised although the flow was below the policy threshold.",
             note="A check on the exception trigger, not a return calculation; it reads DP-145's own value and flow "
                  "copies on the version row."),
        dict(name="Restated Personal Returns", aggregation="count_distinct",
             expr="count(distinct personal_return_version rows) with version_status = 'Restated' and version_supersedes "
                  "populated whose version_period_end falls in a closed period, by version_restatement_cause; shown with "
                  "avg(abs(version_return_value - the superseded version's value))",
             source=("DP-533", "Restated Personal Returns"),
             description="Personal returns restated after their period closed, by cause, with the typical size of the "
                         "change.",
             note="Personal Return has no restatement date (DP-533 taxonomy gap): restatements are dated by the period "
                  "they restate."),

        # ================= DP-141 Portfolio Transactions ==============================================================
        dict(name="Booked Transactions", aggregation="count_distinct",
             expr="count(distinct portfolio_transaction.portfolio_transaction_id)",
             source=("DP-141", "Booked Transactions"),
             description="Number of portfolio transactions booked and not canceled, a rebooking counted once."),
        dict(name="Explicit Transaction Cost Base", aggregation="additive",
             expr="sum(portfolio_transaction.total_explicit_cost x trade_fx_rate where transaction_currency differs from "
                  "the portfolio base currency)",
             source=("DP-141", "Explicit Transaction Cost Base"),
             description="Explicit costs of booked transactions (commissions, fees, taxes) in portfolio base currency.",
             note="Commission and research components are SM-09's certified Commission Spend and Research Spend."),
        dict(name="Portfolio Transaction Amendment Rate", aggregation="ratio",
             numerator="count(distinct portfolio_transaction_id) with a transaction_event of type Amended, Canceled or "
                       "Rebooked",
             denominator="count(distinct portfolio_transaction_id) of all transactions booked in the period, canceled "
                         "ones included",
             source=("DP-141", "Amendment Rate"),
             description="Share of booked transactions that were later amended, canceled or rebooked."),
        dict(name="Back-Dated Bookings", aggregation="additive",
             expr="count(transaction_event rows) where back_dated = 'Y'",
             source=("DP-141", "Back-Dated Bookings"),
             description="Number of booking events back-dated, by source system and portfolio."),
        dict(name="Unsettled Past Contractual Date", aggregation="count_distinct",
             expr="count(distinct portfolio_transaction_id) where contractual_settlement_date < :as_of_date and "
                  "settlement_confirmed = 'N'",
             source=("DP-141", "Unsettled Past Contractual Date"),
             description="Number of transactions past their contractual settlement date and not confirmed settled.",
             note="The net amount is shown beside it as sum(net_amount_base) over the same transactions."),
        dict(name="Trades Without Allocation Reference", aggregation="count_distinct",
             expr="count(distinct portfolio_transaction_id) where transaction_type in (Buy, Sell, Short Sale, Buy to "
                  "Cover, Open Derivative, Close Derivative, FX Spot, FX Forward) and source_allocation_id is null",
             source=("DP-141", "Trades Without Allocation Reference"),
             description="Number of booked trades with no link to the order allocation that produced them."),
        dict(name="Portfolio Net Capital Activity", aggregation="additive",
             expr="sum(capital_activity.activity_amount_base) for inflow types (Subscription, ETF Creation, Client "
                  "Contribution, Capital Call Proceeds, Seed Investment) - sum for outflow types (Redemption, ETF "
                  "Redemption, Client Withdrawal, Distribution to Investors, Seed Redemption)",
             source=("DP-141", "Portfolio Net Capital Activity"),
             description="Net cash coming into portfolios from their investors, as booked in the investment book.",
             note="A book cash flow in portfolio base currency, never net flows (CD-292); for flows use [Net Flows]. "
                  "Sums across portfolios in one base currency only."),
        dict(name="In-Kind Capital Activity Share", aggregation="ratio",
             numerator="sum(capital_activity.activity_amount_base) where in_kind_activity = 'Y'",
             denominator="sum(capital_activity.activity_amount_base)",
             source=("DP-141", "In-Kind Capital Activity Share"),
             description="Share of capital activity settled in kind rather than in cash."),
        dict(name="Estimated Capital Activity Share", aggregation="ratio",
             numerator="sum(capital_activity.activity_amount_base) where activity_data_basis = 'Estimated'",
             denominator="sum(capital_activity.activity_amount_base) for the trade date",
             source=("DP-141", "Estimated Capital Activity Share"),
             description="Share of a day's capital activity the book has not yet confirmed."),

        # ================= DP-142 Holdings, Tax Lots & Cash ===========================================================
        dict(name="Holdings Market Value Base", aggregation="semi_additive",
             expr="sum(holding.market_value_base)", time_rule="single holding_date (latest in the selected range)",
             source=("DP-142", "Holdings Market Value Base"),
             description="Market value of portfolio holdings in base currency, short positions negative.",
             note="Not AUM. Sums across portfolios in one base currency only; a fund-of-funds and the funds it holds "
                  "both appear."),
        dict(name="Portfolio Market Value (IBOR)", aggregation="semi_additive",
             expr="sum(valuation_summary.total_ibor_market_value)",
             time_rule="single valuation_as_of_date (latest in the selected range)",
             source=("DP-142", "Portfolio Market Value (IBOR)"),
             description="Total IBOR market value of a portfolio (holdings, cash and accrued income) from the locked "
                         "end-of-day snapshot.",
             note="Not certified and never labeled AUM (CD-320); an input to SM-11's Firm AUM reconciliation. Summing "
                  "across portfolios double counts sleeves and portfolios that hold other portfolios' funds."),
        dict(name="Valuation Summary Tie-Out", aggregation="non_additive",
             expr="per portfolio and date: total_ibor_market_value - (total_holdings_market_value + total_cash_balance + "
                  "total_accrued_income), and total_holdings_market_value - [Holdings Market Value Base]; flagged beyond "
                  "0.01",
             source=("DP-142", "Valuation Summary Tie-Out"),
             description="Checks that the valuation summary agrees with the holdings and cash beneath it."),
        dict(name="Holdings at Approved Price %", aggregation="ratio",
             numerator="count of priced holding rows whose price_used = approved_price.approved_price_value for the "
                       "instrument, price date and the portfolio's pricing point",
             denominator="count of priced holding rows",
             source=("DP-142", "Holdings at Approved Price %"),
             description="Share of end-of-day holdings valued at the approved price.",
             note="The pricing point comes from the business line convention until 18 records it (GAP-18-002)."),
        dict(name="Stale Priced Holdings", aggregation="count_distinct",
             expr="count(distinct holding_id) where price_date < holding_date or price_source = 'Prior Price Carried "
                  "Forward'",
             source=("DP-142", "Stale Priced Holdings"),
             description="Number of end-of-day holdings valued on a stale price.",
             note="Their market value is shown beside it as sum(market_value_base) over the same rows."),
        dict(name="Unrealized Gain / Loss Base", aggregation="semi_additive",
             expr="sum(holding.market_value_base - holding.holding_cost_base)",
             time_rule="single holding_date (latest in the selected range)",
             source=("DP-142", "Unrealized Gain / Loss Base"),
             description="Unrealized gain or loss on holdings in base currency."),
        dict(name="Realized Gain / Loss Base", aggregation="additive",
             expr="sum(lot_relief.realized_gain_loss_base) where the closing transaction's trade_date is in range",
             source=("DP-142", "Realized Gain / Loss Base"),
             description="Gain or loss realized on lots closed in the period, by holding period term.",
             note="Wash-Sale Loss Disallowed is shown beside it as sum(wash_sale_loss_disallowed)."),
        dict(name="Lot to Holding Quantity Break", aggregation="count_distinct",
             expr="count(distinct portfolio x instrument) where abs(sum(tax_lot.remaining_quantity of open lots) - "
                  "holding.holding_quantity) > 0",
             source=("DP-142", "Lot to Holding Quantity Break"),
             description="Number of positions whose open tax lots do not add up to the holding quantity."),
        dict(name="Delta-Adjusted Exposure Base", aggregation="semi_additive",
             expr="sum(holding.delta_adjusted_exposure_base) over derivative holdings",
             time_rule="single holding_date (latest in the selected range)",
             source=("DP-142", "Delta-Adjusted Exposure Base"),
             description="Delta-adjusted exposure of derivative holdings in base currency, with notional beside it.",
             note="Notional is shown beside it as sum(notional_amount_base). Regulatory derivative exposure is SM-10's."),
        dict(name="Unfunded Commitments Held", aggregation="semi_additive",
             expr="sum(holding.unfunded_commitment) over fund-interest holdings",
             time_rule="single holding_date (latest in the selected range)",
             source=("DP-142", "Unfunded Commitments"),
             description="Commitments to private funds the portfolios hold that have not yet been called.",
             note="Named for the holder's side: the portfolio's commitments to external private funds (18 Fund Interest "
                  "Holding Detail), not investor commitments to the firm's own funds, which left with 30 (CW-930)."),
        dict(name="Overdrawn Cash Accounts", aggregation="count_distinct",
             expr="count(distinct portfolio x currency x cash account) where cash_balance.balance_amount_local < 0",
             source=("DP-142", "Overdrawn Cash Accounts"),
             description="Number of settled cash accounts overdrawn on the balance date.",
             note="The overdrawn amount is shown beside it as sum(balance_amount_base) over the same rows."),
        dict(name="Projected Net Cash", aggregation="additive",
             expr="sum(projected_cash.projected_amount where direction = 'Inflow') - sum(where direction = 'Outflow')",
             source=("DP-142", "Projected Net Cash"),
             description="Expected net cash movement by portfolio, currency and value date over the next five business "
                         "days.",
             note="In projected currency: always group by projected_currency."),
        dict(name="Locked Snapshot Coverage %", aggregation="ratio",
             numerator="count(distinct portfolio) with an End of Day position_snapshot, snapshot_locked = 'Y' and "
                       "control status Reconciled or Reconciled within Tolerance for the business date",
             denominator="count(distinct portfolio) with holdings on that date",
             source=("DP-142", "Locked Snapshot Coverage %"),
             description="Share of portfolios whose end-of-day book is locked and reconciled."),

        # ================= DP-157 Attribution & Ex-Post ===============================================================
        dict(name="Active Return", aggregation="non_additive",
             expr="attribution_result.active_return of the final, highest-version result",
             source=("DP-157", "Active Return"),
             description="Portfolio return minus benchmark return as explained by the attribution model.",
             note="Per result only; never summed across portfolios or periods (linking is the model's)."),
        dict(name="Attribution Effect by Type", aggregation="non_additive",
             expr="sum(attribution_effect.attribution_effect_value) over the segments of one final result, by "
                  "attribution_effect_type",
             source=("DP-157", "Attribution Effect by Type"),
             description="Allocation, selection, interaction, currency and factor effects of one attribution result.",
             note="Sums across segments and effect types within one result only; never across portfolios or periods."),
        dict(name="Effects Sum Tie-Out", aggregation="non_additive",
             expr="per result: active_return - (sum of attribution_effect_value + attribution_residual); flagged beyond "
                  "0.0001",
             source=("DP-157", "Effects Sum Tie-Out"),
             description="Checks that the attribution effects and residual add up to the active return."),
        dict(name="Return Tie-Out", aggregation="non_additive",
             expr="per result: active_return - ([Official Return] - [Benchmark Return]) of the returns it references "
                  "(geometric models: (1 + portfolio) / (1 + benchmark) - 1); flagged beyond 0.0001",
             source=("DP-157", "Return Tie-Out"),
             description="Checks the attribution active return against the certified returns it explains."),
        dict(name="Residual Share %", aggregation="non_additive",
             expr="per result: abs(attribution_residual) / abs(active_return); above 10% listed for review",
             source=("DP-157", "Residual Share %"),
             description="How much of the active return the attribution model leaves unexplained.",
             note="Per result; averaging it across results answers no question asked."),
        dict(name="Segment Weight Sum Check", aggregation="non_additive",
             expr="per result: sum(portfolio_segment_weight) and sum(benchmark_segment_weight); flagged when not 100% "
                  "within 0.01%",
             source=("DP-157", "Segment Weight Sum Check"),
             description="Checks that segment weights of an attribution result sum to 100%."),
        dict(name="Top Contributors and Detractors", aggregation="non_additive",
             expr="the ten highest and ten lowest contribution.contribution_to_return_value per portfolio return, with "
                  "contribution_average_weight",
             source=("DP-157", "Top Contributors and Detractors"),
             description="The holdings that added most to and took most from a portfolio's return."),
        dict(name="Contribution Tie-Out", aggregation="non_additive",
             expr="per portfolio return, scheme and basis: sum(contribution_to_return_value) - return_value; flagged "
                  "beyond 0.0005",
             source=("DP-157", "Contribution Tie-Out"),
             description="Checks that instrument contributions add up to the portfolio's return."),
        dict(name="Ex-Post Risk Statistics", aggregation="non_additive",
             expr="ex_post_statistic.statistic_value of the final, highest-version row, by ex_post_statistic_type "
                  "(Ex-Post Tracking Error, Information Ratio, Sharpe Ratio, Ex-Post Beta, Maximum Drawdown)",
             source=("DP-157", "Ex-Post Risk Statistics"),
             description="Realized risk statistics of a portfolio, share class or composite over a period.",
             note="Published, not certified; always filter one statistic type. Ex-ante values are SM-10's."),
        dict(name="Ex-Ante vs Ex-Post Tracking Error Ratio", aggregation="non_additive",
             expr="ex-post tracking error (trailing 12 months, monthly) / [Ex-Ante Tracking Error] from the approved run "
                  "at the start of the window, same portfolio and benchmark; flagged outside 0.5 to 2.0",
             source=("DP-157", "Ex-Ante vs Ex-Post Tracking Error Ratio"),
             description="How realized tracking error compares with the tracking error the risk model expected.",
             note="The ex-ante value is SM-10's certified number, read and never recalculated."),
        dict(name="Attribution Coverage %", aggregation="ratio",
             numerator="count(distinct portfolio) with a final or restated monthly Official Return, a primary benchmark "
                       "and a final attribution result for the month",
             denominator="count(distinct portfolio) with a final or restated monthly Official Return and a primary "
                         "benchmark",
             source=("DP-157", "Attribution Coverage %"),
             description="Share of benchmarked portfolios that have a final attribution for the month, by business line."),
        dict(name="Results on Unvalidated Models", aggregation="count_distinct",
             expr="count(distinct attribution_result_id) whose attribution model's inventory entry is not in use or has "
                  "no approved model validation",
             source=("DP-157", "Results on Unvalidated Models"),
             description="Number of final attribution results produced by a model that is not validated."),

        # ================= DP-158 GIPS ================================================================================
        dict(name="Composite Members", aggregation="count_distinct",
             expr="count(distinct composite_membership.member_portfolio) effective on the date, approved, and not in an "
                  "open significant cash flow removal",
             source=("DP-158", "Composite Members"),
             description="Number of portfolios in a composite on a date.",
             note="A portfolio in two composites counts in each; across composites the distinct count is lower."),
        dict(name="Unassigned Discretionary Portfolios", aggregation="count_distinct",
             expr="count(distinct portfolio_id) active, standalone, managed by a GIPS firm legal entity, not marked "
                  "non-discretionary, with no effective composite membership and no exclusion reason",
             source=("DP-158", "Unassigned Discretionary Portfolios"),
             description="Number of discretionary portfolios that belong to no composite and are not excluded.",
             note="Pooled funds and institutional books count as discretionary unless excluded (GAP-18-004)."),
        dict(name="Pending Membership Approvals", aggregation="count_distinct",
             expr="count(distinct composite_membership row) where membership_approval_status = 'Pending'",
             source=("DP-158", "Pending Membership Approvals"),
             description="Number of composite membership changes awaiting approval, by days pending."),
        dict(name="Composite Assets", aggregation="non_additive",
             expr="composite_statistic.composite_assets_value for one composite and period end; Number of Portfolios "
                  "beside it",
             source=("DP-158", "Composite Assets"),
             description="Assets of a GIPS composite at a period end, as reported in the GIPS composite report.",
             note="A GIPS figure, never labeled or summed as AUM (CD-320); composites overlap, so the sum across "
                  "composites is not firm assets."),
        dict(name="Composite Statistic Tie-Out", aggregation="non_additive",
             expr="per composite and period end: number_of_portfolios - [Composite Members]; composite_assets - sum of "
                  "members' Ending Portfolio Value on final monthly returns ending that date (within 0.5%)",
             source=("DP-158", "Composite Statistic Tie-Out"),
             description="Checks the composite's reported portfolio count and assets against its members."),
        dict(name="Composite Share of Firm Assets %", aggregation="non_additive",
             expr="per composite and period end: composite_assets_value / gips_firm_assets.gips_total_firm_assets for "
                  "the same period end",
             source=("DP-158", "Composite Share of Firm Assets %"),
             description="A composite's assets as a share of GIPS total firm assets.",
             note="Both GIPS figures; shown per composite because composites overlap."),
        dict(name="Composite Excess Return", aggregation="non_additive",
             expr="[Official Return] of the composite (return_subject_type = 'GIPS Composite') - [Benchmark Return] of "
                  "its Composite Benchmark for the same annual period, fee basis and currency",
             source=("DP-158", "Composite Excess Return"),
             description="How far a composite's official return was above or below its composite benchmark."),
        dict(name="Missing Required Statistics", aggregation="additive",
             expr="count(composite_statistic rows) where number_of_portfolios >= 6 and internal_dispersion is null, plus "
                  "rows with 36 or more monthly composite returns and a null 3-year standard deviation",
             source=("DP-158", "Missing Required Statistics"),
             description="Number of composite annual periods missing a statistic GIPS requires."),
        dict(name="Significant Flow Removals Open", aggregation="count_distinct",
             expr="count(distinct significant_flow row) where removal_start_date is not null and return_to_composite_"
                  "date is null",
             source=("DP-158", "Significant Flow Removals Open"),
             description="Number of portfolios temporarily removed from a composite for a significant cash flow.",
             note="The flow amount is shown beside it as sum(significant_flow_amount)."),
        dict(name="Unrecorded Significant Flows", aggregation="count_distinct",
             expr="count(distinct capital activity row of a member portfolio) whose |activity_amount_base| / the month's "
                  "Beginning Portfolio Value >= the composite's threshold and with no significant_flow row on that date",
             source=("DP-158", "Unrecorded Significant Flows"),
             description="Number of large capital movements in member portfolios not recorded as significant flows."),
        dict(name="Carve-Outs Without Own Cash", aggregation="count_distinct",
             expr="count(distinct carve_out row) where own_cash_balance = 'N', carve_out_period_end >= 2010-01-01 and "
                  "the carve-out portfolio is a composite member",
             source=("DP-158", "Carve-Outs Without Own Cash"),
             description="Number of composite carve-outs since 2010 without their own cash."),
        dict(name="Verification Lag Months", aggregation="non_additive",
             expr="per GIPS firm: months between max(verification_period_end) and max(firm_assets_period_end); flagged "
                  "above 15",
             source=("DP-158", "Verification Lag Months"),
             description="How many months the latest GIPS verification trails the latest firm assets period."),

        # ================= DP-159 Scorecard ===========================================================================
        dict(name="Peer Median Return", aggregation="non_additive",
             expr="median(peer_snapshot.published_peer_return) over the peer universe members for one snapshot date and "
                  "return period",
             source=("DP-159", "Peer Median Return"),
             description="Median vendor-published return of the funds in a peer universe.",
             note="Vendor returns, never mixed into own returns (CD-217); may differ from the vendor's own published "
                  "median (GAP-11-020)."),
        dict(name="Excess vs Peer Median", aggregation="non_additive",
             expr="[Official Return] - [Peer Median Return] for the same period",
             source=("DP-159", "Excess vs Peer Median"),
             description="How far a share class's official return was above or below its peer median.",
             note="Own return is official and peer returns vendor-published; the basis note is always shown."),
        dict(name="Peer Percentile Rank", aggregation="non_additive",
             expr="peer_snapshot.category_percentile_rank and quartile_rank of the peer fund whose ISIN equals the own "
                  "share class ISIN, for the snapshot date and return period",
             source=("DP-159", "Peer Percentile Rank and Quartile"),
             description="Vendor-published percentile and quartile rank of an own share class in its category.",
             note="Not recomputed; the ISIN match is the only link (GAP-11-007)."),
        dict(name="Composite Risk Ratio", aggregation="non_additive",
             expr="composite_3y_std_dev / benchmark_3y_std_dev of the composite's latest annual statistic",
             source=("DP-159", "Composite Risk Ratio"),
             description="A composite's 3-year volatility relative to its benchmark's."),
        dict(name="Share Classes Ahead of Benchmark %", aggregation="ratio",
             numerator="count(distinct share class) with [Excess Return] > 0 for the standard period",
             denominator="count(distinct share class) with an [Official Return] for the period",
             source=("DP-159", "Share Classes Ahead of Benchmark %"),
             description="Share of share classes whose official return beat their primary benchmark, by period and "
                         "vehicle type."),
        dict(name="Fund Assets Ahead of Benchmark %", aggregation="ratio",
             numerator="[Class Net Assets] at the as-of month-end of share classes with [Excess Return] > 0",
             denominator="[Class Net Assets] at the as-of month-end of all share classes measured",
             source=("DP-159", "Fund Assets Ahead of Benchmark %"),
             description="Share of fund assets in share classes that beat their primary benchmark.",
             note="Weights are SM-11's certified class net assets, never Client Assets, Firm AUM or Portfolio Market Value (IBOR)."),
        dict(name="Share Classes in Top Half of Peers %", aggregation="ratio",
             numerator="count(distinct share class) with category_percentile_rank <= 50",
             denominator="count(distinct share class) with a peer rank for the return period",
             source=("DP-159", "Share Classes in Top Half of Peers %"),
             description="Share of ranked share classes in the top half of their peer category."),
        dict(name="Scorecard Coverage %", aggregation="ratio",
             numerator="count(distinct active share class launched before the period start) with a final or restated "
                       "[Official Return] for the period",
             denominator="count(distinct active share class launched before the period start)",
             source=("DP-159", "Scorecard Coverage %"),
             description="Share of eligible share classes that have an official return for the period."),


        # ================= DP-126 Investment Decisions & Governance ===================================================
        dict(name="Portfolios Without Decision Authority", aggregation="count_distinct",
             expr="count(distinct portfolio_id) active (Active, Closed to New Money, Liquidating; not Sleeve) with no "
                  "effective approved pm_assignment where decision_authority = 'Y'",
             source=("DP-126", "Portfolios Without Decision Authority"),
             description="Number of active portfolios with no approved manager holding decision authority."),
        dict(name="Disclosed Managers Without Operational Assignment", aggregation="count_distinct",
             expr="count(distinct disclosed_pm_assignment row) whose portfolio manager has no effective pm_assignment on "
                  "a portfolio implementing the product",
             source=("DP-126", "Disclosed Managers Without Operational Assignment"),
             description="Number of disclosed portfolio managers not assigned to any portfolio of the product (CD-311)."),
        dict(name="Operational Lead Managers Not Disclosed", aggregation="count_distinct",
             expr="count(distinct pm_assignment row) with decision_authority = 'Y' on a primary product-implementing "
                  "portfolio whose manager is not a disclosed manager of the product",
             source=("DP-126", "Operational Lead Managers Not Disclosed"),
             description="Number of lead managers with decision authority who are not disclosed for the product.",
             note="Sleeve and backup roles are shown separately by portfolio_management_role."),
        dict(name="Manager Reconciliation Rate %", aggregation="ratio",
             numerator="(effective disclosed rows + effective decision-authority assignments on product-implementing "
                       "portfolios) - ([Disclosed Managers Without Operational Assignment] + [Operational Lead Managers "
                       "Not Disclosed])",
             denominator="effective disclosed rows + effective decision-authority assignments on product-implementing "
                         "portfolios",
             source=("DP-126", "Manager Reconciliation Rate %"),
             description="Share of disclosed and operational manager records that agree with each other."),
        dict(name="Assignments to Departed Employees", aggregation="count_distinct",
             expr="count(distinct effective pm_assignment and committee_membership rows) whose employee is not active "
                  "or has a termination date on or before the as-of date",
             source=("DP-126", "Assignments to Departed Employees"),
             description="Number of manager assignments and committee seats still held by employees who have left."),
        dict(name="Unapproved Effective Assignments", aggregation="count_distinct",
             expr="count(distinct pm_assignment row) effective on the as-of date with assignment_approval_status <> "
                  "'Approved'",
             source=("DP-126", "Unapproved Effective Assignments"),
             description="Number of effective manager assignments not yet approved, by days since effective."),
        dict(name="Meetings With Quorum %", aggregation="ratio",
             numerator="count(committee_meeting rows) in the period with quorum_met = 'Y' (and, for meetings that are "
                       "not written resolutions, voting_members_present >= quorum_requirement)",
             denominator="count(committee_meeting rows) in the period",
             source=("DP-126", "Meetings With Quorum %"),
             description="Share of investment committee meetings that were quorate."),
        dict(name="Committees Behind Meeting Frequency", aggregation="count_distinct",
             expr="count(distinct active investment_committee) whose latest meeting_date is older than its meeting "
                  "frequency interval",
             source=("DP-126", "Committees Behind Meeting Frequency"),
             description="Number of active committees that have not met as often as their charter requires."),
        dict(name="Committee Decisions", aggregation="additive",
             expr="count(committee_decision rows) with decision_effective_date in range",
             source=("DP-126", "Committee Decisions"),
             description="Number of investment committee decisions, by type and outcome."),
        dict(name="Decisions Without Rationale", aggregation="count_distinct",
             expr="count(distinct investment_decision) in the period with no rationale or thesis, or with the rationale "
                  "recorded more than one business day after the decision",
             source=("DP-126", "Decisions Without Rationale"),
             description="Number of investment decisions without a timely recorded rationale."),
        dict(name="Decisions Without Scope", aggregation="count_distinct",
             expr="count(distinct investment_decision) with no decision strategy and no decision_scope portfolio or "
                  "model portfolio",
             source=("DP-126", "Decisions Without Scope"),
             description="Number of investment decisions that name no strategy, portfolio or model portfolio."),

        # ================= DP-127 Asset Allocation ====================================================================
        dict(name="Actual Asset Class Weight", aggregation="ratio",
             numerator="sum(holding.market_value_base) of holdings whose instrument asset class maps to the policy asset "
                       "class (and sub-class) on the as-of date",
             denominator="[Portfolio Market Value (IBOR)] of the same portfolios on the same date",
             source=("DP-127", "Actual Asset Class Weight"),
             description="Share of a portfolio's market value held in a policy asset class.",
             note="Across portfolios it is the pooled weight. Portfolios resolve to the policy subject only through "
                  "DP-140 links (CD-324)."),
        dict(name="Active Weight vs Policy", aggregation="non_additive",
             expr="[Actual Asset Class Weight] - policy_allocation.neutral_weight, per portfolio and line",
             source=("DP-127", "Active Weight vs Policy"),
             description="How far a portfolio is over or under the policy's neutral weight in an asset class."),
        dict(name="Lines Outside Policy Range", aggregation="count_distinct",
             expr="count(distinct portfolio x policy line) where [Actual Asset Class Weight] < minimum_weight or > "
                  "maximum_weight of the effective policy version",
             source=("DP-127", "Lines Outside Policy Range"),
             description="Number of portfolio policy lines outside their allowed range."),
        dict(name="Tilt Implementation Gap", aggregation="non_additive",
             expr="per portfolio and view asset class: [Active Weight vs Policy] - signed tilt_magnitude of the effective "
                  "tactical view",
             source=("DP-127", "Tilt Implementation Gap"),
             description="How far portfolios have implemented the house or strategy tactical tilt."),
        dict(name="Glide Path Deviation", aggregation="non_additive",
             expr="per target-date portfolio and asset class: [Actual Asset Class Weight] - glide_path_weight at its "
                  "years to target date (interpolated), flagged outside the glide path range",
             source=("DP-127", "Glide Path Deviation"),
             description="How far a target-date portfolio sits from its glide path.",
             note="Years to target date are derived from the product until 01 records a target date (GAP-01-024)."),
        dict(name="Policy-Relative Return", aggregation="non_additive",
             expr="[Official Return] of the portfolio (or share class for a fund policy) - [Benchmark Return] of the "
                  "policy benchmark for the same period, currency and return type",
             source=("DP-127", "Policy-Relative Return"),
             description="A portfolio's official return relative to its allocation policy benchmark.",
             note="A labeled product measure, not an official return (CD-217)."),
        dict(name="Neutral Weight Tie-Out to Benchmark Blend", aggregation="non_additive",
             expr="per policy with a blended benchmark: sum over lines of |neutral_weight - blend component weight|; "
                  "zero expected",
             source=("DP-127", "Neutral Weight Tie-Out to Benchmark Blend"),
             description="Checks that policy neutral weights match the policy benchmark's blend."),
        dict(name="Policies Without Committee Approval", aggregation="count_distinct",
             expr="count(distinct effective allocation_policy version) with no approving committee decision, or whose "
                  "decision outcome is not an approval",
             source=("DP-127", "Policies Without Committee Approval"),
             description="Number of effective allocation policies not approved by an investment committee."),

        # ================= DP-132 Proxy Voting ========================================================================
        dict(name="Ballots Voted %", aggregation="ratio",
             numerator="count(distinct ballot) under firm voting authority with a confirmed vote instruction for every "
                       "agenda item",
             denominator="count(distinct ballot) under firm voting authority with vote_deadline_timestamp in range",
             source=("DP-132", "Ballots Voted %"),
             description="Share of ballots the firm was entitled to vote that it voted in full."),
        dict(name="Missed Votes", aggregation="count_distinct",
             expr="count(distinct ballot) under firm authority with no confirmed instruction by the deadline, or "
                  "instructed after it",
             source=("DP-132", "Missed Votes"),
             description="Number of ballots the firm did not vote in time, by reason."),
        dict(name="Against Management %", aggregation="ratio",
             numerator="count(vote_instruction rows) where against_management = 'Y'",
             denominator="count(vote_instruction rows)",
             source=("DP-132", "Against Management %"),
             description="Share of votes cast against management's recommendation, by proposal category and proponent."),
        dict(name="Against Policy Votes", aggregation="count_distinct",
             expr="count(distinct vote_instruction) where against_policy = 'Y'",
             source=("DP-132", "Against Policy Votes"),
             description="Number of votes cast against the applied voting policy, by decision source."),
        dict(name="Unapproved Overrides", aggregation="count_distinct",
             expr="count(distinct vote_instruction) where against_policy = 'Y' and the applied vote rationale has no "
                  "override approver",
             source=("DP-132", "Unapproved Overrides"),
             description="Number of policy overrides without a recorded approval."),
        dict(name="Shares Voted %", aggregation="ratio",
             numerator="sum(vote_instruction.shares_voted)",
             denominator="sum(ballot.record_date_shares) for the same ballots and agenda items",
             source=("DP-132", "Shares Voted %"),
             description="Share of record-date shares voted, by portfolio and meeting."),
        dict(name="Shares on Loan Not Voted", aggregation="additive",
             expr="sum(ballot.shares_on_loan_not_recalled)",
             source=("DP-132", "Shares on Loan Not Voted"),
             description="Shares out on loan and not recalled, so not voted, at investee meetings.",
             note="Read as given; not tied out to the loan book (GAP-28-010)."),
        dict(name="Recall Decisions", aggregation="count_distinct",
             expr="count(distinct recall_decision row) where recall_decided = 'Y'",
             source=("DP-132", "Recall Decisions"),
             description="Number of decisions to recall lent shares to vote, by materiality."),
        dict(name="Proxy Advisor Alignment %", aggregation="ratio",
             numerator="count(vote_instruction rows) whose vote_cast = advisor_recommended_vote of the applied policy's "
                       "benchmark proxy advisor",
             denominator="count(vote_instruction rows) with such a recommendation",
             source=("DP-132", "Proxy Advisor Alignment %"),
             description="Share of votes that followed the proxy advisor's recommendation."),
        dict(name="Ballot Coverage of Holdings", aggregation="count_distinct",
             expr="count(distinct holding) of the meeting instrument at the record date under firm voting authority "
                  "with no ballot on a safekeeping account assigned to that portfolio",
             source=("DP-132", "Ballot Coverage of Holdings"),
             description="Number of voting-authority holdings that received no ballot."),
        dict(name="Voting Reports Pending", aggregation="count_distinct",
             expr="count(distinct fund series or client account) with votes in the period and no approved voting_report "
                  "of the period",
             source=("DP-132", "Voting Reports Pending"),
             description="Number of fund series and accounts whose proxy voting report is not yet approved."),

        # ================= DP-133 Engagement ==========================================================================
        dict(name="Active Stewardship Engagements", aggregation="count_distinct",
             expr="count(distinct engagement_id) open on one engagement_as_of_date",
             source=("DP-133", "Active Engagements"),
             description="Number of engagements open on the as-of date, by theme and milestone reached."),
        dict(name="Objectives Achieved %", aggregation="ratio",
             numerator="count(engagement_objective rows) with objective_achieved_date <= objective_target_date",
             denominator="count(engagement_objective rows) with objective_target_date in range",
             source=("DP-133", "Objectives Achieved %"),
             description="Share of engagement objectives due in the period that were achieved on time."),
        dict(name="Dormant Engagements", aggregation="count_distinct",
             expr="count(distinct active engagement) with no interaction in the last 180 days",
             source=("DP-133", "Dormant Engagements"),
             description="Number of open engagements with no contact in six months."),
        dict(name="Engagement Interactions", aggregation="additive",
             expr="count(engagement_interaction rows) with interaction_date in range",
             source=("DP-133", "Interactions"),
             description="Number of engagement interactions, by contact medium."),
        dict(name="Escalated Engagements", aggregation="count_distinct",
             expr="count(distinct engagement) with at least one escalation_action, by escalation_action_type",
             source=("DP-133", "Escalated Engagements"),
             description="Number of engagements escalated, and those leading to a vote or an investment decision."),
        dict(name="Votes Linked to Engagements", aggregation="count_distinct",
             expr="count(distinct vote_rationale) with linked_engagement filled in the period",
             source=("DP-133", "Votes Linked to Engagements"),
             description="Number of vote decisions linked to an engagement, and those voted against management."),
        dict(name="Engagement Outcomes", aggregation="count_distinct",
             expr="count(distinct engagement) closed in the period, by engagement_outcome",
             source=("DP-133", "Engagement Outcomes"),
             description="Number of engagements closed, by outcome, with the successful share."),
        dict(name="Holdings in Engaged Issuers %", aggregation="ratio",
             numerator="sum(holding.market_value_base) whose instrument's issuer is the engaged party of an active "
                       "engagement",
             denominator="sum(holding.market_value_base)",
             source=("DP-133", "Holdings in Engaged Issuers %"),
             description="Share of portfolio market value invested in issuers the firm is engaging."),
        dict(name="Reported Engagements and Case Studies", aggregation="count_distinct",
             expr="count(distinct reported_engagement row) per stewardship report, and those with case_study = 'Y' and "
                  "issuer_named = 'Y'",
             source=("DP-133", "Reported Engagements and Case Studies"),
             description="Number of engagements reported in each stewardship report, and named case studies."),
        dict(name="Stewardship Reports Not Approved", aggregation="count_distinct",
             expr="count(distinct stewardship_report.stewardship_framework) whose stewardship report for the latest "
                  "stewardship_report_period_end has stewardship_report_approval_status <> 'Approved', by reporting entity",
             source=("DP-133", "Stewardship Reports Not Approved"),
             description="Number of stewardship frameworks whose latest report is not yet approved, by reporting entity."),
        dict(name="Active Initiative Memberships", aggregation="count_distinct",
             expr="count(distinct initiative_membership row) active and effective on the as-of date",
             source=("DP-133", "Active Initiative Memberships"),
             description="Number of collaborative initiatives the firm's entities are members of."),

        # ================= DP-134 ESG Data ============================================================================
        dict(name="Firm Assessment Coverage %", aggregation="ratio",
             numerator="sum(holding.market_value_base) of corporate-issuer holdings whose issuer has an approved, "
                       "effective firm ESG assessment",
             denominator="sum(holding.market_value_base) of corporate-issuer holdings",
             source=("DP-134", "Firm Assessment Coverage %"),
             description="Share of corporate holdings covered by the firm's own ESG assessment."),
        dict(name="Vendor Rating Coverage %", aggregation="ratio",
             numerator="sum(holding.market_value_base) of corporate-issuer holdings whose issuer has a vendor rating "
                       "dated in the last 12 months",
             denominator="sum(holding.market_value_base) of corporate-issuer holdings",
             source=("DP-134", "Vendor Rating Coverage %"),
             description="Share of corporate holdings with a current vendor ESG rating, by source and rating type."),
        dict(name="Stale Firm Assessments", aggregation="count_distinct",
             expr="count(distinct held issuer) whose latest approved assessment_date is more than 12 months old",
             source=("DP-134", "Stale Firm Assessments"),
             description="Number of held issuers whose firm ESG assessment is over a year old."),
        dict(name="Assessment Divergence", aggregation="non_additive",
             expr="per issuer: |percentile rank of firm_esg_score - percentile rank of the primary vendor "
                  "esg_rating_numeric_score|; above 40 points listed",
             source=("DP-134", "Assessment Divergence"),
             description="How far the firm's ESG view of an issuer differs from the main vendor's."),
        dict(name="Excluded Holdings", aggregation="semi_additive",
             expr="sum(holding.market_value_base) of holdings whose instrument, or issuer, is an effective member of an "
                  "approved exclusion list, each holding counted once",
             time_rule="single holding_date (latest in the selected range)",
             source=("DP-134", "Excluded Holdings"),
             description="Market value held in issuers or instruments on an exclusion list, with the count of holdings.",
             note="A monitoring view; coded rules and breaches are SM-10's (CD-221)."),
        dict(name="Exclusion List Changes", aggregation="count_distinct",
             expr="count(distinct exclusion_member row) whose member_effective_from or member_effective_to is in range",
             source=("DP-134", "Exclusion List Changes"),
             description="Number of additions to and removals from exclusion lists, by list and inclusion type."),
        dict(name="Members Below Revenue Threshold", aggregation="count_distinct",
             expr="count(distinct revenue-based exclusion_member) with measured_revenue_percentage < the list's "
                  "revenue_threshold_percentage",
             source=("DP-134", "Members Below Revenue Threshold"),
             description="Number of revenue-based exclusion list members now below the list's threshold."),
        dict(name="Observation Freshness", aggregation="ratio",
             numerator="count(distinct observed issuer) whose latest observation for the indicator has a reporting "
                       "period end within 18 months",
             denominator="count(distinct observed issuer) for the indicator",
             source=("DP-134", "Observation Freshness"),
             description="Share of issuers with recent data for a sustainability indicator.",
             note="The share on an estimated basis is shown beside it, filtered on observation_data_basis."),
        dict(name="Observations From Inactive Datasets", aggregation="count_distinct",
             expr="count(distinct current observation or rating) whose source dataset is not active",
             source=("DP-134", "Observations From Inactive Datasets"),
             description="Number of current ESG observations and ratings from datasets no longer active."),
        dict(name="Assessments on Unvalidated Methodology", aggregation="count_distinct",
             expr="count(distinct approved, effective firm_esg_assessment) whose methodology model is not in use or has "
                  "no approved validation",
             source=("DP-134", "Assessments on Unvalidated Methodology"),
             description="Number of firm ESG assessments produced with a methodology that is not validated."),

        # ================= DP-135 Sustainability Metrics ==============================================================
        dict(name="Sustainability Metric Value", aggregation="non_additive",
             expr="sustainability_metric.metric_value for the scope (portfolio, product or legal entity) and "
                  "metric_period_end, by indicator, metric_framework and metric_measurement_basis, with "
                  "metric_coverage_percentage and metric_unit",
             source=("DP-135", "Sustainability Metric Value"),
             description="The sustainability and climate metrics of a portfolio, product or entity for a period end.",
             note="One value per scope, indicator and period; never summed across indicators or scopes."),
        dict(name="Low Coverage Indicators", aggregation="count_distinct",
             expr="count(distinct sustainability_metric row) with metric_coverage_percentage < 50%",
             source=("DP-135", "Low Coverage Indicators"),
             description="Number of sustainability and climate metric values based on less than half the portfolio."),
        dict(name="Financed Emissions", aggregation="additive",
             expr="sum(financed_emissions_holding.attributed_emissions)",
             source=("DP-135", "Financed Emissions"),
             description="Greenhouse gas emissions attributed to portfolio holdings (tCO2e), by scope and PCAF asset "
                         "class.",
             note="Always fix emission_scopes_included; portfolio-scope rows only, so a holding is counted once."),
        dict(name="Financed Emissions Tie-Out", aggregation="non_additive",
             expr="per financed emissions metric: metric_value - [Financed Emissions]; zero expected",
             source=("DP-135", "Financed Emissions Tie-Out"),
             description="Checks the reported financed emissions against the holding detail."),
        dict(name="Attribution Factor Check", aggregation="non_additive",
             expr="per holding detail: attribution_factor - holding_value_used / attribution_denominator_value; flagged "
                  "beyond 0.0001",
             source=("DP-135", "Attribution Factor Check"),
             description="Checks each holding's emissions attribution factor."),
        dict(name="Holding Value Tie-Out", aggregation="non_additive",
             expr="per holding detail: holding_value_used - holding.market_value_base; for listed EVIC rows, "
                  "attribution_denominator_value - the approved EVIC of the issuer's primary instrument",
             source=("DP-135", "Holding Value Tie-Out"),
             description="Checks the holding values and EVIC used for financed emissions against their sources."),
        dict(name="Weighted PCAF Data Quality Check", aggregation="non_additive",
             expr="per metric: sum(pcaf_data_quality_score x holding_value_used) / sum(holding_value_used) - "
                  "weighted_pcaf_data_quality_score; zero expected",
             source=("DP-135", "Weighted PCAF Data Quality Check"),
             description="Checks the reported PCAF data quality score against the holding detail."),
        dict(name="ESG Products Without Metrics", aggregation="count_distinct",
             expr="count(distinct investment_product) whose ESG Investment Approach is not 'None' or whose ESG Term in "
                  "Name Indicator = 'Y', with no sustainability_metric for the latest metric_period_end on the product "
                  "or on a portfolio that implements it (primary implementation link effective at the period end)",
             source=("DP-135", "ESG Products Without Metrics"),
             description="Number of ESG-approach or ESG-named products with no sustainability metric for the latest period."),
        dict(name="Climate Target Progress %", aggregation="non_additive",
             expr="per target: (baseline_value - latest metric value of the target indicator) / baseline_value / "
                  "target_reduction_percentage, against the straight-line path from baseline year to target year",
             source=("DP-135", "Climate Target Progress %"),
             description="How far a climate target has progressed toward its reduction goal."),
    ],

    excluded=[
        ("DP-159", "Official Return", "The certified number is published once from DP-145 as [Official Return]; the "
                                      "scorecard selects the final return of each subject and does not restate it."),
        ("DP-159", "Benchmark Return", "Published once from DP-145 as [Benchmark Return]; the scorecard's primary "
                                       "benchmark pairing is primary_benchmark (share classes) or the Composite "
                                       "Benchmark (composites)."),
        ("DP-159", "Excess Return", "The same difference as DP-145 Excess Return (share classes) and DP-158 Composite "
                                    "Excess Return (composites), both published; strategy rows have no official return "
                                    "(GAP-32-004)."),
        ("DP-159", "Ex-Post Risk", "A selection of DP-157 Ex-Post Risk Statistics (Information Ratio, Sharpe Ratio, "
                                   "Ex-Post Tracking Error), published from DP-157."),
        ("DP-159", "Ex-Ante Tracking Error", "Certified in DP-146; referenced as SM-10/Ex-Ante Tracking Error."),
        # WP2: the DP-145 personal return measures are published above; these stay inside the product.
        ("DP-145", "Personal Return Ending Value Tie-Out",
         "A row-level control DP-145 runs against its Derived copies of the 49 brokerage book, the 29 register and the 16 "
         "participant balances. Publishing it would put three books of record in one model (CW-007); the books are "
         "published by SM-24, SM-12 and SM-26, and the performance team reads the flagged rows in DP-145."),
        ("DP-145", "Personal Return Flow Tie-Out",
         "As the ending value tie-out: a row-level check against the 49, 29 and 16 activity copies held inside DP-145, "
         "whose flows of record are SM-20's and the book models'."),
        ("DP-145", "Personal Return Fee Tie-Out",
         "A row-level check against DP-145's copies of the 47 fee debits and invoices; client fee revenue and billing are "
         "SM-28's (DP-012, DP-305), so the model does not publish a second fee figure."),
        ("DP-145", "Managed Account Composite Return",
         "The Official Return of subjects with Return Subject Type 'Managed Account Composite'; published as [Official "
         "Return] sliced by performance_return.return_managed_account_composite. The composite's member account count is "
         "SM-23's (DP-304 managed account composite membership)."),
        # DP-532 presents DP-145's certified numbers; its copies are not published a second time (CW-251).
        ("DP-532", "Personal Return Value (from DP-145)",
         "A display copy of the certified Personal Return Value; published once, as [Personal Rate of Return] from DP-145."),
        ("DP-532", "Suppressed Personal Returns (from DP-145)",
         "DP-145's Suppressed Personal Returns as published; published once from DP-145 as [Suppressed Personal Returns]."),
        ("DP-532", "Personal Return Inputs Shown (from DP-145)",
         "DP-145's beginning and ending values, flows and fees shown row by row to the client; personal data, never summed "
         "across subjects, and not Client Assets (SM-20), Net Flows (SM-20) or client fee revenue (SM-28)."),
        ("DP-532", "Comparison Benchmark Return (from DP-145)",
         "The certified Benchmark Return of the profile's comparison benchmark; published once as [Benchmark Return] from "
         "DP-145 and read through client_performance_profile.client_comparison_benchmark."),
        # DP-533 reads DP-145's control numbers as published.
        ("DP-533", "Suppressed Personal Returns (from DP-145)",
         "DP-145's Suppressed Personal Returns as published; published once from DP-145 as [Suppressed Personal Returns]."),
        ("DP-533", "Restated Personal Returns Requiring Notification (from DP-145)",
         "DP-145's measure as published; published once from DP-145 as [Restated Personal Returns Requiring "
         "Notification], with the change size from [Restated Personal Returns]."),
        ("DP-533", "Material Restatements (from DP-145), Institutional Accounts",
         "DP-145's Material Restatements sliced to Return Subject Type 'Account' (institutional separate accounts, "
         "CW-129); published as [Material Restatements] with performance_return.return_subject_type = 'Account'."),
    ],

    access=dict(
        classification="Confidential - Personal Data (account, household and SMA returns, client performance "
                       "profiles and return exceptions, member portfolios, employee keys; financial PII, no "
                       "special-category data); peer data, index-derived weights, ESG data and sustainability metrics are "
                       "Confidential - Licensed",
        roles=[
            dict(role="performance_measurement",
                 rows="all subjects, including account, household, SMA and preliminary-to-final history through the "
                      "restatement and personal return version tables",
                 columns="all", hidden=[]),
            dict(role="advisor_and_client_service",
                 rows="personal returns, profiles and exceptions of the accounts and households where the viewer is the "
                      "advisor of record (DP-009 primary coverage on the period end) or serves the client; rows without "
                      "an advisor of record go to client service only",
                 columns="personal return, profile and exception tables; no portfolio, stewardship or peer tables",
                 hidden=[]),
            dict(role="portfolio_management",
                 rows="portfolios where the viewer has an effective pm_assignment, plus all share classes, composites and "
                      "benchmarks; no account-level returns",
                 columns="all except personal keys",
                 hidden=["return_account", "member_portfolio", "vote_decision_maker",
                         "engagement_lead", "personal_return_account", "personal_return_group", "displayed_account", "displayed_group", "exception_account", "version_account", "version_group", "client_profile_account", "client_profile_group", "member_account", "group_household"]),
            dict(role="investment_governance_risk",
                 rows="all portfolios, decisions, committees, assignments and policies; account and household returns "
                      "as aggregates only",
                 columns="all", hidden=["return_account", "personal_return_account", "personal_return_group", "displayed_account", "displayed_group", "exception_account", "version_account", "version_group", "client_profile_account", "client_profile_group", "member_account", "group_household"]),
            dict(role="stewardship_team",
                 rows="all votes, engagements, ESG data and sustainability metrics; MNPI-restricted engagements only "
                      "for viewers entitled under the DP-121 control",
                 columns="all", hidden=["return_account", "member_portfolio", "personal_return_account", "personal_return_group", "displayed_account", "displayed_group", "exception_account", "version_account", "version_group", "client_profile_account", "client_profile_group", "member_account", "group_household"]),
            dict(role="broad_internal",          # product, distribution, marketing, client reporting
                 rows="share class, composite, model portfolio and fund-portfolio rows only (no account, household or "
                      "SMA rows; personal return controls as counts only); peer columns only under the vendor licenses' "
                      "permitted use",
                 columns="aggregates by product, strategy, composite, benchmark, business line, asset class and issuer",
                 hidden=["return_account", "member_portfolio", "assigned_manager",
                         "vote_decision_maker", "engagement_lead", "income_return", "capital_return",
                         "personal_return_value", "version_return_value", "personal_return_account", "personal_return_group", "displayed_account", "displayed_group", "exception_account", "version_account", "version_group", "client_profile_account", "client_profile_group", "member_account", "group_household"]),
        ]),

    verified_questions=[
        dict(question="Which share classes beat their primary benchmark over 3 years net of fees, and what share of "
                      "fund assets is ahead?",
             answer="[Excess Return] from performance_return (return_subject_type = 'Share Class', return_fee_basis = "
                    "'Net', return_period_basis = '3 Years', latest month-end, version of record) paired with "
                    "[Benchmark Return] through primary_benchmark effective at the period end; [Share Classes Ahead of "
                    "Benchmark %] and [Fund Assets Ahead of Benchmark %] weighted by [Class Net Assets] (SM-11).",
             sql="select r.return_share_class, r.return_value - b.benchmark_return_value as excess_return "
                 "from dp_145.performance_return r "
                 "join dp_145.product_benchmark_assignment a on a.assigned_product_share_class = r.return_share_class "
                 " and a.benchmark_role = 'Primary' and a.assignment_effective_from <= r.return_period_end_date "
                 " and (a.assignment_effective_to is null or a.assignment_effective_to > r.return_period_end_date) "
                 "join dp_145.benchmark_return b on b.return_benchmark = a.assigned_benchmark "
                 " and b.benchmark_period_start_date = r.return_period_start_date "
                 " and b.benchmark_period_end_date = r.return_period_end_date "
                 " and b.benchmark_return_currency = r.return_currency "
                 " and b.benchmark_return_status in ('Final', 'Restated') "
                 " and b.benchmark_return_version = (select max(benchmark_return_version) from dp_145.benchmark_return x "
                 "  where x.return_benchmark = b.return_benchmark and x.benchmark_period_start_date = "
                 "  b.benchmark_period_start_date and x.benchmark_period_end_date = b.benchmark_period_end_date "
                 "  and x.benchmark_return_type = b.benchmark_return_type and x.benchmark_return_currency = "
                 "  b.benchmark_return_currency and x.benchmark_hedged_basis_indicator = b.benchmark_hedged_basis_indicator) "
                 "where r.return_subject_type = 'Share Class' and r.return_fee_basis = 'Net' "
                 "and r.return_status in ('Final', 'Restated') and r.hypothetical_indicator = 'N' "
                 "and r.return_version = (select max(return_version) from dp_145.performance_return y "
                 " where y.performance_return_id = r.performance_return_id)"),
        dict(question="What drove active return for our equity portfolios last quarter, by effect type?",
             answer="[Active Return] and [Attribution Effect by Type] from attribution_result and attribution_effect "
                    "(final, highest version), per portfolio for the quarter's portfolio return, grouped by "
                    "attribution_effect_type; portfolios selected by portfolio business line and the model's segment "
                    "scheme. Effects are not summed across portfolios."),
        dict(question="Which GIPS composites are missing required statistics or have open significant cash flow "
                      "removals?",
             answer="[Missing Required Statistics] from composite_statistic (Annual rows) and [Significant Flow Removals "
                    "Open] from significant_flow, grouped by gips_composite.composite_name for the latest period end."),
        dict(question="How many portfolios have policy lines outside their allowed range this month-end?",
             answer="[Lines Outside Policy Range] from policy_allocation at the latest month-end (effective policy "
                    "version), weights from [Actual Asset Class Weight] over holding (End of Day) and [Portfolio Market "
                    "Value (IBOR)], grouped by allocation_policy.allocation_policy_type."),
        dict(question="What was the money-weighted, net-of-fees personal return of each household last year, and how "
                      "many households could not be shown one?",
             answer="[Personal Rate of Return] from personal_return with the method pin = 'Money-Weighted', "
                    "personal_return_subject_type = 'Household Performance Group', personal_return_fee_basis = 'Net of "
                    "Fees', personal_return_period_basis = '1 Year', the default household_performance_group "
                    "(performance_group_type = 'Default (All Household Accounts)'); [Household Return Coverage %], "
                    "[Suppressed Personal Returns] by return_suppression_reason and [Households Without Default "
                    "Performance Group] for the same period end. Returns are listed per household, never averaged."),
        dict(question="What share of our votes went against management last proxy season, by proposal category?",
             answer="[Against Management %] from vote_instruction with investee_meeting.investee_meeting_date in the "
                    "season, grouped by agenda_item.proposal_category."),
    ],

    cannot_answer=[
        dict(question="Official returns at strategy level, or a strategy's representative composite",
             why="Performance Return has no strategy subject and no attribute names a strategy's representative "
                 "composite or share class.",
             gap="GAP-32-004"),
        dict(question="Asset-weighted performance of mandates and SMAs alongside funds",
             why="Mandates and SMAs are shown through their composites; certified AUM is not carried by mandate, and the "
                 "scorecard weights only funds by class net assets.",
             gap="GAP-06-011"),
        dict(question="How long do personal return exceptions take to resolve, and were clients notified of restated "
                      "returns?",
             why="32 Client Return Exception has no resolved date or owner, so only open age is published; no attribute "
                 "links a 13 client communication to a restated 32 version (DP-533 taxonomy gaps).",
             gap=""),
        dict(question="Climate target AUM in scope as a share of Firm AUM",
             why="Climate Target AUM in Scope Percentage is not tied to certified Firm AUM.",
             gap="GAP-34-003"),
        dict(question="How promptly were ballots voted after they opened?",
             why="Ballot has no voted or confirmation timestamp of its own; only instruction timestamps exist.",
             gap="GAP-34-004"),
        dict(question="Which engagement objectives were abandoned rather than still open?",
             why="Engagement Objective has no status other than its achieved date.",
             gap="GAP-34-005"),
    ],

    open_decisions=[
        "W1b: tax_lot.pooled_lot (DP-142 Pooled Lot Indicator) and lot_relief.uk_matching_rule (UK Matching Rule Applied) "
        "removed, no US successor (CW-918).",
        "W1b: metric MiFIR Decision Maker Completeness % (DP-126) removed, no US successor (CW-925). W3 (24): "
        "decision_supervising_branch_country dropped with its attribute; decision_algorithm_code re-pointed to the 24 "
        "Decision Algorithm, joined to DP-212 Model by model ID (closes the model gap noted in the DP-126 logical model).",
        "W4 retirement of 07 and 30 (CW-907, CW-930, CW-167), done: the private markets return table, the certified "
        "Private Fund IRR and Multiples and its tie-out, the private investor performance, commitment, capital account "
        "and PME tables and metrics, the pacing plan table and its three metrics and the private markets role are "
        "removed; those products retired with 30. The external fund-interest holdings of DP-142 (Unfunded Commitments "
        "Held) stay.",
        "WP2 (CW-011, CW-129, CW-209): the certified Personal Rate of Return is defined here on personal_return (DP-145 "
        "Personal Return Value), with the method pinned as a required always_filter parameter; return_account stays for "
        "institutional separate accounts. Added the DP-145 client tables (client_performance_profile, calculation_policy, "
        "household_performance_group, household_group_member), DP-532's displayed_personal_return and DP-533's "
        "client_return_exception and personal_return_version, the wealth shared dimensions (DP-093 Account and Account "
        "Party Role, DP-240 Household Membership, DP-009 Coverage Assignment and Employee) and an advisor_and_client_service "
        "role. The SM-01 refs are re-pointed to SM-20 (Net Flows; Ending AUM becomes Client Assets); the SM-06 and SM-07 "
        "mentions are re-pointed or removed. The DP-145 tie-outs stay in the product (three books, CW-007) and the "
        "'(from DP-145)' copies in DP-532 and DP-533 are excluded as reads of the published number.",
        "Personal Rate of Return method pin: confirm the parameter values ('Time-Weighted', 'Money-Weighted') and whether "
        "client-facing tools should default to money-weighted (the DP-532 reference default for the retail headline) "
        "while program reporting defaults to time-weighted.",
        "W1b: signatory_status table (DP-133 Fact Signatory Status) and its two joins removed, no US successor (CW-934); the "
        "metric Current Signatory Statuses is replaced by Stewardship Reports Not Approved, its report-approval half.",
        "W1b: sustainable_determination table (DP-134 Fact Sustainable Investment Determination) and the metric "
        "Determination Coverage % removed, no US successor (CW-934).",
        "W1b: DP-135 pai_calculation and product_outcome tables, sustainability_metric.pai_actions_taken, the PAI version "
        "pin on sustainability_metric, the SFDR PAI table and indicator number levels (the PAI indicator hierarchy is now "
        "Sustainability indicator: level, name; the table is renamed sustainability_indicator) and the metrics Commitment "
        "Met, Products Missing Outcome and EET Achieved Values removed, no US successor (CW-934). PAI Indicator Value is "
        "replaced by Sustainability Metric Value, and ESG Products Without Metrics is added. DP-135 is a WP0 re-scope "
        "candidate (CW-041): confirm at WP0 whether the firm reports these voluntary climate and ESG-named fund metrics.",
        "Official Return is certified on Final and Restated rows. Confirm whether hypothetical returns (Hypothetical "
        "Indicator = Y) are ever official; the model removes them by a default filter, which users can lift for the "
        "compliance count (Unreviewed Hypothetical Returns). If they are never official, the spec should say so and the "
        "filter becomes always-on.",
        "DP-145 notes say share class and composite returns become public once released; confirm the release rule so "
        "broad_internal can see released returns without the Confidential - Personal Data account rows.",
        "Excess return is defined three times: DP-145 Excess Return (share classes), DP-158 Composite Excess Return "
        "(composites) and DP-159 Excess Return (both, plus strategies). The model publishes the first two and excludes "
        "DP-159's; DP-159's spec should reference them. Any other model that needs an excess return references "
        "SM-08/Excess Return (one idea, one definition).",
        "DP-159 restates Official Return, Benchmark Return, Ex-Post Risk and Ex-Ante Tracking Error under measure names "
        "that collide with certified names. Rename them in the specs (for "
        "example 'Scorecard Official Return Selection') or drop them as measures, since they are reads, not definitions.",
        "DP-142 measure 'Unfunded Commitments' is published as 'Unfunded Commitments Held' (the holder's side); confirm "
        "the name with the Head of Investment Operations.",
        "DP-157 holds every measure on Fact Attribution Effect although most are computed at result, contribution or "
        "statistic grain; the logical model should place them on the entities at their grain.",
        "Confirm the Holding View and Cash Balance Type code values the model pins ('End of Day', 'Settled'), the "
        "Composite Period Type value 'Annual'.",
        "Contribution to Return holds instrument and segment rows of several calculation bases; the model pins "
        "instrument rows of the model's own calculation basis. Confirm this is the basis the contribution tie-out uses.",
        "The model reads DP-159's copies of DP-014 peer data and DP-165 NAV. Confirm with SM-11 that these "
        "conformed reads stay here, not in their models.",
        "DP-133's Fact Engagement is a weekly snapshot; joins from objectives, interactions and escalations need one "
        "as-of snapshot pinned. Confirm whether a current-state engagement entity should be added so those joins are "
        "exact.",
        "Composite membership can place a portfolio in more than one composite; confirm whether the firm allows that "
        "and whether a 'primary composite' flag is wanted for counts across composites.",
    ],
)
