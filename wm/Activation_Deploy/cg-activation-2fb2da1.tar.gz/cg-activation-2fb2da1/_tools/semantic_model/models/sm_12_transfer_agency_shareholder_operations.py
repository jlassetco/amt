"""SM-12 Transfer Agency & Shareholder Operations: fund orders and cut-off control, settlement with intermediaries, ETF
creations and redemptions, shareholder identity verification (CIP), AML and fraud alerts, and the transfer agent's daily
controls, with the 29 fund share register and the proxy pass-through and voting choice programs.
Products DP-177 to DP-181 (Wave E9), DP-580 and DP-408 (WP2). See ../CONTRACT.md.

Four rules shape the model:
- Orders, obligations and AP orders are operational records, never flows (CD-199, CD-200). Flows and AUM are the
  certified SM-20 numbers (CW-203), referenced and read from DP-008 on its own pinned table; shares created and
  redeemed are the capital stock change fund accounting books, not a flow.
- NAV per Share, Class Net Assets and Shares Outstanding are the certified SM-11 numbers from the NAV of record (CD-330);
  the NAV table pins the NAV of record so a re-strike or a shadow NAV never doubles a share class and date.
- An outsourced transfer agent is the base case (CD-297, CD-331): the processing provider is a dimension on orders, AP
  orders and control checks, never a reason for a second table.
- The 29 share register (DP-580) is its own book of record (CW-007): it publishes shares, never market value, Client
  Assets or AUM. Register Account Categories are never added together (omnibus, nominee, networked and plan rows look
  through to owners counted in 49, 16 or 06; Firm Proprietary rows are firm assets, never client assets). DP-408's
  record-date positions are derived copies of 49 or 29, never 06.
"""

# DP-008 rows exist for many dimension types, period types, data bases and snapshots; the flow table pins all of them.
# W4 (CW-141): Measure Value is keyed by Dimension Type and Dimension Key (the dimension_grain pin's successor), and the
# lock status is the Snapshot Type.
_LOCKED = "snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type = 'Locked')"
_DP008_PINS = ["dimension_type = 'Share Class' (replaces the dimension_grain pin, CW-141)", "period_type = 'MONTH'", _LOCKED,
               "data_basis = 'REPORTED'"]

# The NAV of record (CD-330): approved, latest version, official calculation source; never a Firm Shadow row.
_NAV_OF_RECORD = "nav_of_record_flag = 'Y'"

_PII_PARTY = [("Given Name", "Personal data; the party roles here are firms (TAs, intermediaries, custodians)."),
              ("Family Name", "Personal data; not needed for any cross-row question."),
              ("Preferred Name", "Personal data; not needed for any cross-row question."),
              ("Primary Country", "Flagged personal data in DP-240; not needed here.")]

MODEL = dict(
    id="SM-12",
    status="Draft",
    description=(
        "Fund order processing, settlement with intermediaries, ETF creations and redemptions, shareholder CIP, AML and "
        "fraud alerts, the transfer agent's daily controls, the fund share register and own-fund proxy and pass-through "
        "voting, for the Head of Transfer Agency, ETF operations, the BSA / AML Officer, proxy operations and fund "
        "oversight. It answers questions across orders, intermediaries, share classes, register categories, campaigns, "
        "processing providers and days; it never counts flows from orders or postings, which stay the certified SM-20 "
        "numbers, and never presents register shares as Client Assets."),
    questions=[
        "How many orders arrive after the cut-off, break forward pricing or are processed as of an earlier date, by dealing "
        "route, intermediary and transfer agent, and how much does as-of dilution cost each share class?",
        "Which intermediaries settle late or leave cash unmatched, and how much is outstanding in open settlement exceptions?",
        "How many ETF shares did authorized participants create and redeem, at what value at NAV, and how concentrated are they?",
        "How large and how old is the AML, sanctions and fraud alert backlog, and how quickly are alerts dispositioned?",
        "Does the transfer agent run and pass every daily control, does the share register roll forward from its postings, "
        "and do the capital stock proofs agree with the NAV of record?",
        "Are own-fund proxy campaigns on track for quorum, and are issuer pass-through materials and voting instructions "
        "handled on time?",
    ],

    tables=[
        # --- Certified facts read only to slice referenced metrics ----------------------------------------------
        dict(name="share_class_flows", product="DP-008", entity="Measure Value", kind="Fact",
             grain="share class x month (locked snapshot, reported basis)",
             always_filter=_DP008_PINS,
             dimensions=[dict(name="flow_share_class", attr="Dimension Key", note="The share class ID on Share Class rows"),
                         dict(name="period_end_date", attr="Period End Date")],
             facts=[dict(name="gross_sales", attr="Gross Sales"),
                    dict(name="redemptions", attr="Redemptions"),
                    dict(name="net_flows", attr="Net Flows (Net Sales)")]),
        dict(name="nav_of_record", product="DP-165", entity="Share Class NAV", kind="Fact",
             grain="share class x valuation date (NAV of record only)",
             always_filter=[_NAV_OF_RECORD],      # one row per share class and date; re-strikes and shadow NAVs excluded
             dimensions=[dict(name="share_class_nav_id", attr="Share Class NAV ID"),
                         dict(name="nav_share_class", attr="NAV Share Class"),
                         dict(name="parent_nav_calculation", attr="Parent NAV Calculation"),
                         dict(name="nav_currency", attr="NAV Currency")],
             facts=[dict(name="nav_per_share", attr="NAV per Share"),
                    dict(name="class_net_assets", attr="Class Net Assets Amount"),
                    dict(name="shares_outstanding", attr="Shares Outstanding")]),
        dict(name="nav_calculation", product="DP-165", entity="Fund NAV Calculation", kind="Dimension",
             always_filter=["NAV Approval Status approved, latest NAV Version Number, official NAV Calculation Source "
                            "(CD-330)"],
             dimensions=[dict(name="valuation_date", attr="Valuation Date"),
                         dict(name="nav_calculation_source", attr="NAV Calculation Source"),
                         dict(name="nav_version_number", attr="NAV Version Number"),
                         dict(name="nav_approval_status", attr="NAV Approval Status")]),

        # --- Shared and role-played dimensions ------------------------------------------------------------------
        dict(name="fund", product="DP-004", entity="Investment Product", kind="Dimension",
             dimensions=[dict(name="fund_id", attr="Product ID"),
                         dict(name="fund_name", attr="Product Marketing Name"),
                         dict(name="vehicle_type", attr="Vehicle Type"),
                         dict(name="business_line", attr="Business Line"),
                         dict(name="fund_domicile", attr="Fund Domicile")]),
        dict(name="share_class", product="DP-004", entity="Share Class", kind="Dimension",
             dimensions=[dict(name="share_class_id", attr="Share Class ID"),
                         dict(name="parent_product", attr="Parent Product"),
                         dict(name="share_class_name", attr="Share Class Legal Name"),
                         dict(name="share_class_type", attr="Share Class Type"),
                         dict(name="share_class_status", attr="Share Class Status"),
                         dict(name="fund_serv_code", attr="DTCC Fund/SERV Code")]),
        # Dealing terms fold into the product in DP-177 (cut-off, time zone, dealing calendar).
        dict(name="dealing_terms", product="DP-177", entity="Investment Product", kind="Dimension",
             dimensions=[dict(name="dealing_product_id", attr="Product ID"),
                         dict(name="dealing_frequency", attr="Dealing Frequency"),
                         dict(name="dealing_cut_off_time", attr="Dealing Cut-off Time"),
                         dict(name="cut_off_time_zone", attr="Cut-off Time Zone"),
                         dict(name="dealing_calendar", attr="Dealing Calendar")]),
        dict(name="settlement_terms", product="DP-178", entity="Investment Product", kind="Dimension",
             dimensions=[dict(name="settlement_product_id", attr="Product ID"),
                         dict(name="subscription_settlement_period", attr="Subscription Settlement Period"),
                         dict(name="redemption_settlement_period", attr="Redemption Settlement Period")]),
        dict(name="etf_terms", product="DP-179", entity="Investment Product", kind="Dimension",
             dimensions=[dict(name="etf_product_id", attr="Product ID"),
                         dict(name="replication_method", attr="Replication Method")],
             facts=[dict(name="creation_unit_size", attr="Creation Unit Size")]),
        # One party table per role: the transfer agent (or custodian, or portal) that processed the record.
        dict(name="processing_provider", product="DP-240", entity="Party", kind="Dimension",
             dimensions=[dict(name="provider_id", attr="Party ID"),
                         dict(name="provider_name", attr="Party Display Name"),
                         dict(name="provider_type", attr="Party Type")],
             hidden=_PII_PARTY),
        dict(name="intermediary", product="DP-001", entity="Party", kind="Dimension",   # WP1 re-point (CW-204): NSCC and TA dealer numbers are DP-001's
             always_filter=["party_type = 'Organization'"],    # receiving, settling and session parties are firms or networks
             dimensions=[dict(name="intermediary_id", attr="Party ID"),
                         dict(name="intermediary_name", attr="Party Display Name"),
                         dict(name="nscc_participant_number", attr="NSCC Participant Number"),
                         dict(name="ta_dealer_number", attr="Transfer Agent Dealer Number")],
             hidden=_PII_PARTY),
        dict(name="resolved_dealer", product="DP-001", entity="Party", kind="Dimension",
             dimensions=[dict(name="dealer_id", attr="Party ID"),
                         dict(name="dealer_name", attr="Party Display Name"),
                         dict(name="dealer_party_type", attr="Party Type")]),
        dict(name="authorized_participant", product="DP-179", entity="Authorized Participant", kind="Dimension",
             dimensions=[dict(name="ap_id", attr="Party ID"),
                         dict(name="ap_name", attr="Party Display Name"),
                         dict(name="ap_counterparty_party", attr="Counterparty Party"),
                         dict(name="ap_approval_status", attr="Counterparty Approval Status"),
                         dict(name="ap_tier", attr="Counterparty Tier")],
             hidden=_PII_PARTY),
        # Shareholder account and restrictions (DP-093 conformed, read through DP-180, which tests CIP on every opening
        # through 15 Account Opening.Opening Identity Verification).
        dict(name="account", product="DP-180", entity="Account", kind="Dimension",
             dimensions=[dict(name="account_id", attr="Account ID"),
                         dict(name="account_type", attr="Account Type"),
                         dict(name="account_registration_type", attr="Account Registration Type"),
                         dict(name="account_status", attr="Account Status"),
                         dict(name="account_open_date", attr="Account Open Date"),
                         dict(name="networking_level", attr="Networking Level"),
                         dict(name="opening_identity_verification", attr="Opening Identity Verification",
                              note="Key to the 02 Identity Verification of the opening (W3, 29 CIP Verification retired)")],
             hidden=[("Account Name", "Personal data; no cross-row question needs it."),
                     ("External Account Number", "Personal data; no cross-row question needs it."),
                     ("Registration Line 1", "Personal data."),
                     ("Registration Line 2", "Personal data.")]),
        dict(name="account_restriction", product="DP-180", entity="Account Restriction", kind="Dimension",
             dimensions=[dict(name="account_restriction_id", attr="Account Restriction ID"),
                         dict(name="restricted_account", attr="Restricted Account"),
                         dict(name="account_restriction_type", attr="Account Restriction Type"),
                         dict(name="account_restriction_lifted_date", attr="Account Restriction Lifted Date")]),
        # Alert subject and CIP-verified party, with the current KYC profile folded in (read from DP-077, never republished).
        dict(name="subject_party", product="DP-180", entity="Party", kind="Dimension",
             dimensions=[dict(name="subject_party_id", attr="Party ID"),
                         dict(name="subject_party_type", attr="Party Type"),
                         dict(name="aml_risk_rating", attr="AML Risk Rating"),
                         dict(name="pep_status", attr="PEP Status", note="Personal data; AML unit only.")],
             hidden=_PII_PARTY),

        # --- DP-177 Fund Order Processing & Cut-Off Control -----------------------------------------------------
        dict(name="fund_order", product="DP-177", entity="Fact Fund Order", kind="Fact",
             grain="fund order (FNDO-), current version as processed; as-of detail folded in",
             always_filter=["fund_order_type is not null"],     # interface-session-only routes are on interface_session
             dimensions=[dict(name="fund_order_id", attr="Fund Order ID"),
                         dict(name="fund_order_type", attr="Fund Order Type"),
                         dict(name="order_share_class", attr="Order Share Class"),
                         dict(name="order_account", attr="Order Account", note="Key only; AML unit and TA operations."),
                         dict(name="order_currency", attr="Order Currency"),
                         dict(name="order_received_timestamp", attr="Order Received Timestamp"),
                         dict(name="ta_received_timestamp", attr="TA Received Timestamp"),
                         dict(name="receiving_party", attr="Receiving Party"),
                         dict(name="cut_off_result", attr="Cut-Off Result"),
                         dict(name="trade_date_assigned", attr="Trade Date Assigned"),
                         dict(name="fund_order_status", attr="Fund Order Status"),
                         dict(name="order_origin", attr="Order Origin"),
                         dict(name="resulting_transaction", attr="Resulting Transaction",
                              note="Key to the 29 Register Transaction (RGTX-), published at WP2 in register_transaction (DP-580); "
                                   "used to test the hand-off, never to turn an order into a flow (CD-199)."),
                         dict(name="processing_provider_id", attr="Processing Provider"),
                         dict(name="dealing_route", attr="Dealing Route"),
                         dict(name="order_message_standard", attr="Order Message Standard"),
                         dict(name="resolved_dealer_id", attr="Resolved Dealer"),
                         dict(name="receiving_interface_session", attr="Receiving Interface Session"),
                         dict(name="original_fund_order", attr="Original Fund Order"),
                         dict(name="as_of_trade_date", attr="As-Of Trade Date"),
                         dict(name="as_of_reason", attr="As-Of Reason"),
                         dict(name="related_nav_error_case", attr="Related NAV Error Case"),
                         dict(name="related_servicing_error", attr="Related Servicing Error"),
                         dict(name="dilution_cost_bearer", attr="Dilution Cost Bearer"),
                         dict(name="dilution_threshold_exceeded", attr="Dilution Threshold Exceeded Indicator"),
                         dict(name="as_of_approver", attr="As-Of Approver", note="Employee key; personal data.")],
             facts=[dict(name="estimated_order_value", attr="Estimated Order Value",
                         note="An operational estimate, never a flow (CD-199)."),
                    dict(name="dilution_amount", attr="Dilution Amount")],
             hidden=[("Requested Amount", "Personal data at account level; Estimated Order Value serves the aggregates."),
                     ("Requested Units", "Personal data at account level."),
                     ("Representative Number As Delivered", "Personal data; Resolved Dealer serves the aggregates."),
                     ("Resolved Representative", "Personal data; representative analysis is not this model's (the advisor "
                                                 "models read the advisor of record from DP-093)."),
                     ("Fund/SERV Control Number", "Message-level identifier; no cross-row question needs it."),
                     ("Dealer Number As Delivered", "Raw code; Resolved Dealer is the conformed dealer.")]),
        dict(name="order_exception", product="DP-177", entity="Fact Order Exception", kind="Fact",
             grain="fund order x order exception type x exception raised timestamp",
             dimensions=[dict(name="exception_fund_order", attr="Exception Fund Order"),
                         dict(name="order_exception_type", attr="Order Exception Type"),
                         dict(name="exception_raised_timestamp", attr="Exception Raised Timestamp"),
                         dict(name="blocking_account_restriction", attr="Blocking Account Restriction"),
                         dict(name="exception_status", attr="Exception Status"),
                         dict(name="exception_resolved_timestamp", attr="Exception Resolved Timestamp"),
                         dict(name="trade_date_moved", attr="Trade Date Moved Indicator")]),
        dict(name="interface_session", product="DP-177", entity="Fact Order Interface Session", kind="Fact",
             grain="order interface session (dealing route x business date x interface cycle)",
             dimensions=[dict(name="interface_session_key", attr="Interface Session Key"),
                         dict(name="session_dealing_route", attr="Session Dealing Route"),
                         dict(name="session_business_date", attr="Session Business Date"),
                         dict(name="interface_cycle", attr="Interface Cycle"),
                         dict(name="session_counterparty", attr="Session Counterparty"),
                         dict(name="session_balance_status", attr="Session Balance Status")],
             facts=[dict(name="session_orders_received_count", attr="Orders Received Count"),
                    dict(name="session_control_total", attr="Session Control Total")]),
        dict(name="processing_calendar_event", product="DP-177", entity="Fact TA Processing Calendar Event", kind="Fact",
             grain="dealing calendar (optionally one share class) x business date x processing calendar event type",
             dimensions=[dict(name="governing_dealing_calendar", attr="Governing Dealing Calendar"),
                         dict(name="event_share_class", attr="Event Share Class"),
                         dict(name="event_business_date", attr="Event Business Date"),
                         dict(name="processing_calendar_event_type", attr="Processing Calendar Event Type"),
                         dict(name="revised_cut_off_time", attr="Revised Cut-Off Time")],
             facts=[dict(name="orders_affected_count", attr="Orders Affected Count")]),
        dict(name="exchange_link", product="DP-177", entity="Exchange Link", kind="Bridge",
             grain="outgoing-leg fund order x incoming-leg fund order",
             dimensions=[dict(name="exchange_out_order", attr="Exchange Out Order"),
                         dict(name="exchange_in_order", attr="Exchange In Order"),
                         dict(name="switch_order_reference", attr="Switch Order Reference")]),

        # --- DP-178 Shareholder Settlement with Intermediaries ---------------------------------------------------
        # One obligation table for fund orders and AP cash legs; DP-179's copy of the AP cash legs is not read, so
        # an AP obligation is never counted twice.
        dict(name="settlement_obligation", product="DP-178", entity="Fact Settlement Obligation", kind="Fact",
             grain="settlement obligation (fund order or AP order x obligation sequence)",
             dimensions=[dict(name="settlement_obligation_id", attr="Settlement Obligation ID"),
                         dict(name="obligation_fund_order", attr="Obligation Fund Order"),
                         dict(name="obligation_ap_order", attr="Obligation AP Order"),
                         dict(name="obligation_flow_direction", attr="Obligation Flow Direction"),
                         dict(name="contractual_settlement_date", attr="Contractual Settlement Date"),
                         dict(name="order_settlement_method", attr="Order Settlement Method"),
                         dict(name="settling_party", attr="Settling Party"),
                         dict(name="obligation_settlement_batch", attr="Obligation Settlement Batch"),
                         dict(name="obligation_settlement_status", attr="Obligation Settlement Status"),
                         dict(name="actual_settlement_date", attr="Actual Settlement Date")],
             facts=[dict(name="obligation_amount", attr="Obligation Amount",
                         note="Lineage is 29 (the Fund Order's settlement obligation, W3); never a flow (CD-199).")]),
        dict(name="settlement_batch", product="DP-178", entity="Fact Settlement Batch", kind="Fact",
             grain="intermediary settlement batch (settling party x settlement date x currency x data basis)",
             always_filter=["batch_data_basis = 'Final'"],     # estimated and final batches of one day would double count
             dimensions=[dict(name="settlement_batch_id", attr="Settlement Batch ID"),
                         dict(name="batch_settling_party", attr="Batch Settling Party"),
                         dict(name="batch_settlement_date", attr="Batch Settlement Date"),
                         dict(name="batch_currency", attr="Batch Currency"),
                         dict(name="batch_data_basis", attr="Batch Data Basis"),
                         dict(name="net_settlement_direction", attr="Net Settlement Direction"),
                         dict(name="batch_settlement_method", attr="Batch Settlement Method"),
                         dict(name="batch_settlement_status", attr="Batch Settlement Status")],
             facts=[dict(name="gross_inflow_amount", attr="Gross Inflow Amount"),
                    dict(name="gross_outflow_amount", attr="Gross Outflow Amount"),
                    dict(name="net_settlement_amount", attr="Net Settlement Amount"),
                    dict(name="batch_obligation_count", attr="Batch Obligation Count")]),
        dict(name="cash_movement", product="DP-178", entity="Fact Cash Movement", kind="Fact",
             grain="cash movement",
             dimensions=[dict(name="cash_movement_id", attr="Cash Movement ID"),
                         dict(name="settled_batch", attr="Settled Batch"),
                         dict(name="settled_obligation", attr="Settled Obligation"),
                         dict(name="payment_flow_direction", attr="Payment Flow Direction"),
                         dict(name="payment_currency", attr="Payment Currency"),
                         dict(name="payment_value_date", attr="Payment Value Date"),
                         dict(name="payment_method", attr="Payment Method"),
                         dict(name="fund_cash_account", attr="Fund Cash Account"),
                         dict(name="payment_settlement_status", attr="Payment Settlement Status"),
                         dict(name="payment_screening_result", attr="Payment Screening Result")],
             facts=[dict(name="payment_amount", attr="Payment Amount",
                         note="Personal data on individual payments; broad roles see it aggregated by batch only.")],
             hidden=[("Payment Reference", "Personal data (spec note); the intermediary batch view leaves it out."),
                     ("Client Money Movement", "Key to the 50 Money Movement of the shareholder's cash (replaces Investor "
                                               "Bank Instruction, W3); personal bank details stay in 50.")]),
        dict(name="settlement_exception", product="DP-178", entity="Fact Settlement Exception", kind="Fact",
             grain="settlement obligation or settlement batch x settlement exception type x exception detected date",
             dimensions=[dict(name="exception_settlement_obligation", attr="Exception Settlement Obligation"),
                         dict(name="exception_settlement_batch", attr="Exception Settlement Batch"),
                         dict(name="settlement_exception_type", attr="Settlement Exception Type"),
                         dict(name="exception_detected_date", attr="Exception Detected Date"),
                         dict(name="return_reason_code", attr="Return Reason Code"),
                         dict(name="canceled_for_non_payment", attr="Order Canceled for Non-Payment Indicator"),
                         dict(name="settlement_exception_status", attr="Settlement Exception Status")],
             facts=[dict(name="shortfall_amount", attr="Shortfall Amount")]),

        # --- DP-179 ETF Creation & Redemption Operations ---------------------------------------------------------
        dict(name="ap_order", product="DP-179", entity="Fact AP Order", kind="Fact",
             grain="authorized participant creation or redemption order (ECR-); AP order fee folded in",
             dimensions=[dict(name="ap_order_id", attr="AP Order ID"),
                         dict(name="ap_order_type", attr="AP Order Type"),
                         dict(name="authorized_participant_id", attr="Authorized Participant"),
                         dict(name="ap_agreement", attr="AP Agreement"),
                         dict(name="etf_share_class", attr="ETF Share Class"),
                         dict(name="basket_settlement_form", attr="Basket Settlement Form"),
                         dict(name="applied_etf_basket", attr="Applied ETF Basket",
                              note="Degenerate key into DP-131 (model gap)."),
                         dict(name="ap_order_received_timestamp", attr="AP Order Received Timestamp"),
                         dict(name="ap_order_cut_off_result", attr="AP Order Cut-Off Result"),
                         dict(name="ap_order_trade_date", attr="AP Order Trade Date"),
                         dict(name="ap_order_status", attr="AP Order Status"),
                         dict(name="ap_cash_component_direction", attr="AP Cash Component Direction"),
                         dict(name="ap_order_channel", attr="AP Order Channel"),
                         dict(name="ap_order_processing_provider", attr="AP Order Processing Provider"),
                         dict(name="ap_order_settlement_date", attr="AP Order Settlement Date"),
                         dict(name="ap_resulting_transaction", attr="AP Resulting Transaction",
                              note="Key to the 29 Register Transaction (RGTX-) in register_transaction (DP-580); used to test the "
                                   "hand-off, never to turn an AP order into a flow (CD-200)."),
                         dict(name="variable_transaction_fee_rate", attr="Variable Transaction Fee Rate",
                              note="A rate; never summed.")],
             facts=[dict(name="creation_units_ordered", attr="Creation Units Ordered"),
                    dict(name="estimated_cash_component_amount", attr="Estimated Cash Component Amount"),
                    dict(name="ap_cash_component_amount", attr="AP Cash Component Amount"),
                    dict(name="fixed_transaction_fee", attr="Fixed Transaction Fee"),
                    dict(name="variable_transaction_fee_amount", attr="Variable Transaction Fee Amount"),
                    dict(name="collateral_posted_amount", attr="Collateral Posted Amount")]),
        dict(name="basket_line", product="DP-179", entity="Fact Basket Settlement Line", kind="Fact",
             grain="AP order x basket constituent",
             dimensions=[dict(name="line_ap_order", attr="Line AP Order"),
                         dict(name="basket_constituent", attr="Basket Constituent",
                              note="Degenerate key into DP-131; the instrument (DP-097) cannot be reached (model gap)."),
                         dict(name="line_settlement_status", attr="Line Settlement Status"),
                         dict(name="line_delivery_settlement", attr="Line Delivery Settlement")],
             facts=[dict(name="basket_quantity", attr="Basket Quantity"),
                    dict(name="delivered_quantity", attr="Delivered Quantity"),
                    dict(name="cash_in_lieu_amount", attr="Cash in Lieu Amount")]),

        # --- DP-180 Shareholder CIP, AML & Fraud Alerts (Restricted - Legal) ------------------------------------
        dict(name="monitoring_alert", product="DP-180", entity="Fact Account Monitoring Alert", kind="Fact",
             grain="account monitoring alert (AMA-) with its disposition",
             dimensions=[dict(name="account_monitoring_alert_id", attr="Account Monitoring Alert ID"),
                         dict(name="monitoring_alert_category", attr="Monitoring Alert Category"),
                         dict(name="monitoring_scenario", attr="Monitoring Scenario"),
                         dict(name="alert_account", attr="Alert Account"),
                         dict(name="alert_subject_party", attr="Alert Subject Party"),
                         dict(name="triggering_fund_order", attr="Triggering Fund Order"),
                         dict(name="triggering_cash_movement", attr="Triggering Cash Movement"),
                         dict(name="alert_generated_timestamp", attr="Alert Generated Timestamp"),
                         dict(name="alert_priority", attr="Alert Priority"),
                         dict(name="sanctions_match_result", attr="Sanctions Match Result"),
                         dict(name="matched_sanctions_list", attr="Matched Sanctions List"),
                         dict(name="alert_status", attr="Alert Status", note="Restricted - Legal; AML unit only."),
                         dict(name="alert_reviewer", attr="Alert Reviewer"),
                         dict(name="alert_disposition", attr="Alert Disposition",
                              note="Restricted - Legal; AML unit only."),
                         dict(name="disposition_date", attr="Disposition Date"),
                         dict(name="second_reviewer", attr="Second Reviewer"),
                         dict(name="escalation_case_reference", attr="Escalation Case Reference",
                              note="Restricted - Legal (31 CFR 1024.320(e)); AML unit only."),
                         dict(name="disposition_information_classification", attr="Disposition Information Classification"),
                         dict(name="alert_resulting_account_restriction", attr="Alert Resulting Account Restriction")],
             facts=[dict(name="fraud_loss_amount", attr="Fraud Loss Amount")],
             hidden=[("Disposition Rationale", "Restricted - Legal free text; never published outside the AML case system."),
                     ("Alerted Amount", "Personal data at account level; no cross-row question needs it.")]),
        # W3 (29): the 29 CIP Verification is retired; DP-180 reads the 02 Identity Verification of direct shareholders.
        dict(name="identity_verification", product="DP-180", entity="Fact Identity Verification", kind="Fact",
             grain="02 identity verification of a party (direct shareholders)",
             dimensions=[dict(name="identity_verification_id", attr="Identity Verification ID"),
                         dict(name="verified_party", attr="Verified Party"),
                         dict(name="cip_program", attr="CIP Program"),
                         dict(name="verification_method", attr="Verification Method"),
                         dict(name="verification_result", attr="Verification Result"),
                         dict(name="verification_date", attr="Verification Date"),
                         dict(name="government_list_check_date", attr="Government List Check Date")]),
        # --- DP-181 TA Daily Controls & Capital Stock Proof ------------------------------------------------------
        dict(name="control_check", product="DP-181", entity="Fact TA Control Check", kind="Fact",
             grain="TA control check (TACK-): TA control type x share class (or fund) x business date",
             dimensions=[dict(name="ta_control_check_id", attr="TA Control Check ID"),
                         dict(name="ta_control_type", attr="TA Control Type"),
                         dict(name="control_share_class", attr="Control Share Class"),
                         dict(name="control_fund", attr="Control Fund"),
                         dict(name="control_business_date", attr="Control Business Date"),
                         dict(name="control_measure_unit", attr="Control Measure Unit"),
                         dict(name="control_currency", attr="Control Currency"),
                         dict(name="compared_nav_record", attr="Compared NAV Record"),
                         dict(name="control_result", attr="Control Result"),
                         dict(name="control_processing_provider", attr="Control Processing Provider"),
                         dict(name="control_signed_off_by", attr="Control Signed Off By")],
             facts=[dict(name="ta_control_value", attr="TA Control Value",
                         note="Mixed units (shares, amounts, counts) by control type; read only within one TA Control Type."),
                    dict(name="comparison_value", attr="Comparison Value"),
                    dict(name="control_difference", attr="Control Difference"),
                    dict(name="control_tolerance", attr="Control Tolerance")]),
        dict(name="control_exception", product="DP-181", entity="Fact TA Control Exception", kind="Fact",
             grain="TA control check x control exception number",
             dimensions=[dict(name="exception_control_check", attr="Exception Control Check"),
                         dict(name="control_exception_number", attr="Control Exception Number"),
                         dict(name="control_exception_cause", attr="Control Exception Cause"),
                         dict(name="control_exception_severity", attr="Control Exception Severity"),
                         dict(name="control_exception_owner", attr="Control Exception Owner"),
                         dict(name="exception_related_fund_order", attr="Exception Related Fund Order"),
                         dict(name="exception_servicing_error", attr="Exception Servicing Error",
                              note="Key to the 13 Servicing Error, analyzed in DP-409 Servicing Errors & Client Remediation "
                                   "(DP-043 retired, CW-220); not joined here (CD-333)."),
                         dict(name="control_exception_status", attr="Control Exception Status"),
                         dict(name="control_exception_resolved_date", attr="Control Exception Resolved Date")],
             facts=[dict(name="exception_difference_value", attr="Exception Difference Value")]),

        # --- DP-580 Fund Share Register & Postings (29 register book, WP2) -------------------------------------
        # Shares only, by Register Account Category; never market value, Client Assets or AUM. DP-580's Fund Order and
        # Settlement Obligation are the same 29 records DP-177's fund_order and DP-178's settlement_obligation already
        # read, so they are not read twice.
        dict(name="register_position", product="DP-580", entity="Register Position", kind="Fact",
             grain="registered account x share class x register business date (daily snapshot)",
             default_filter="register_business_date = the last business date in the selected range",
             dimensions=[dict(name="register_account", attr="Register Account",
                              note="Account key; personal data. TA operations and proxy operations only."),
                         dict(name="register_share_class", attr="Register Share Class"),
                         dict(name="register_business_date", attr="Register Business Date"),
                         dict(name="register_account_category", attr="Register Account Category",
                              note="The book selector: every share metric is read within a category, never summed across them."),
                         dict(name="governing_account_restriction", attr="Governing Account Restriction",
                              note="The 15 restriction key only; its type is not read (Rule 2165 holds are DP-583's)."),
                         dict(name="last_register_transaction", attr="Last Register Transaction"),
                         dict(name="register_keeper", attr="Register Keeper")],
             facts=[dict(name="registered_shares", attr="Registered Shares", note="Shares, semi-additive over dates."),
                    dict(name="collected_shares", attr="Collected Shares"),
                    dict(name="uncollected_shares", attr="Uncollected Shares"),
                    dict(name="escrowed_or_pledged_shares", attr="Escrowed or Pledged Shares"),
                    dict(name="restricted_shares", attr="Restricted Shares")]),
        dict(name="register_transaction", product="DP-580", entity="Register Transaction", kind="Fact",
             grain="posted share movement on the TA register (RGTX-), append-only",
             dimensions=[dict(name="register_transaction_id", attr="Register Transaction ID",
                              note="Posting key; personal data at account level."),
                         dict(name="register_transaction_type", attr="Register Transaction Type"),
                         dict(name="posting_account", attr="Posting Account", note="Account key; personal data."),
                         dict(name="posting_share_class", attr="Posting Share Class"),
                         dict(name="register_trade_date", attr="Register Trade Date"),
                         dict(name="register_settlement_date", attr="Register Settlement Date"),
                         dict(name="posting_date", attr="Posting Date"),
                         dict(name="as_of_posting_indicator", attr="As-Of Posting Indicator"),
                         dict(name="share_movement_direction", attr="Share Movement Direction"),
                         dict(name="applied_nav_record", attr="Applied NAV Record"),
                         dict(name="price_per_share_applied", attr="Price per Share Applied", note="A price; never summed."),
                         dict(name="register_transaction_currency", attr="Register Transaction Currency"),
                         dict(name="originating_fund_order", attr="Originating Fund Order"),
                         dict(name="originating_ap_order", attr="Originating AP Order"),
                         dict(name="originating_distribution_declaration", attr="Originating Distribution Declaration",
                              note="Key into DP-171 distributions; not joined here."),
                         dict(name="register_transaction_status", attr="Register Transaction Status"),
                         dict(name="reversed_register_transaction", attr="Reversed Register Transaction")],
             facts=[dict(name="shares_posted", attr="Shares Posted", note="Signed by share_movement_direction."),
                    dict(name="gross_amount", attr="Gross Amount",
                         note="An operational posted amount, never a flow or Net New Assets (those are DP-006 and DP-008)."),
                    dict(name="sales_charge_amount", attr="Sales Charge Amount"),
                    dict(name="redemption_fee_amount", attr="Redemption Fee Amount"),
                    dict(name="tax_withheld_amount", attr="Tax Withheld Amount"),
                    dict(name="net_amount", attr="Net Amount")]),

        # --- DP-408 Proxy Solicitation, Pass-Through & Voting Choice (13, WP2) ----------------------------------
        dict(name="proxy_campaign", product="DP-408", entity="Proxy Campaign", kind="Dimension",
             dimensions=[dict(name="proxy_campaign_id", attr="Proxy Campaign ID"),
                         dict(name="meeting_type", attr="Meeting Type"),
                         dict(name="registrant_fund", attr="Registrant / Fund"),
                         dict(name="campaign_record_date", attr="Record Date"),
                         dict(name="campaign_meeting_date", attr="Meeting Date"),
                         dict(name="proxy_mailing_date", attr="Proxy Mailing Date"),
                         dict(name="solicitation_agent", attr="Solicitation Agent"),
                         dict(name="quorum_requirement", attr="Quorum Requirement", note="A rate; never summed."),
                         dict(name="meeting_status", attr="Meeting Status"),
                         dict(name="adjourned_to_date", attr="Adjourned To Date")],
             facts=[dict(name="shares_outstanding_at_record_date", attr="Shares Outstanding at Record Date",
                         note="Per campaign; never summed across campaigns.")]),
        dict(name="proxy_proposal", product="DP-408", entity="Proxy Proposal", kind="Dimension",
             dimensions=[dict(name="proposal_campaign", attr="Proxy Campaign Key"),
                         dict(name="proposal_id", attr="Proposal ID"),
                         dict(name="proposal_type", attr="Proposal Type"),
                         dict(name="vote_standard", attr="Vote Standard"),
                         dict(name="proposal_outcome", attr="Proposal Outcome")]),
        # Tallies are immutable snapshots: every vote metric reads the latest tally of each proposal.
        dict(name="vote_tally", product="DP-408", entity="Vote Tally", kind="Fact",
             grain="own-fund proxy proposal x tally as-of date (immutable snapshot)",
             default_filter="the latest tally_as_of_date of each proposal on or before the as-of date",
             dimensions=[dict(name="tally_proposal", attr="Proxy Proposal Key"),
                         dict(name="tally_as_of_date", attr="Tally As-Of Date"),
                         dict(name="quorum_achieved_indicator", attr="Quorum Achieved Indicator"),
                         dict(name="percent_of_outstanding_voted", attr="Percent of Outstanding Voted",
                              note="A row-level percent; never summed or averaged across proposals.")],
             facts=[dict(name="shares_voted_for", attr="Shares Voted For"),
                    dict(name="shares_voted_against", attr="Shares Voted Against"),
                    dict(name="broker_non_votes", attr="Broker Non-Votes"),
                    dict(name="mirror_echo_voted_shares", attr="Mirror / Echo Voted Shares")]),
        dict(name="intermediary_vote_instruction", product="DP-408", entity="Intermediary Vote Instruction", kind="Fact",
             grain="proxy proposal x voting intermediary",
             dimensions=[dict(name="instruction_proposal", attr="Proxy Proposal Key"),
                         dict(name="voting_intermediary", attr="Voting Intermediary"),
                         dict(name="instruction_discretionary_vote_permitted",
                              attr="Broker Discretionary Vote Permitted Indicator")],
             facts=[dict(name="instructions_received_count", attr="Instructions Received Count"),
                    dict(name="shares_instructed", attr="Shares Instructed")]),
        dict(name="issuer_pass_through", product="DP-408", entity="Issuer Proxy Pass-Through", kind="Fact",
             grain="issuer meeting (17 corporate action event) x brokerage account",
             dimensions=[dict(name="issuer_meeting", attr="Issuer Meeting"),
                         dict(name="pass_through_account", attr="Pass-Through Account", note="Account key; personal data."),
                         dict(name="pass_through_delivery_method", attr="Pass-Through Delivery Method"),
                         dict(name="materials_delivered_date", attr="Materials Delivered Date"),
                         dict(name="voting_instruction_status", attr="Voting Instruction Status"),
                         dict(name="voting_instruction_received_timestamp", attr="Voting Instruction Received Timestamp"),
                         dict(name="voting_instruction_transmitted_timestamp", attr="Voting Instruction Transmitted Timestamp"),
                         dict(name="pass_through_discretionary_vote_permitted",
                              attr="Broker Discretionary Vote Permitted Indicator")],
             facts=[dict(name="record_date_entitled_quantity", attr="Record Date Entitled Quantity",
                         note="A derived copy of the 49 Client Holding quantity at the record date; shares, never Client Assets.")]),
        dict(name="disclosure_election", product="DP-408", entity="Beneficial Owner Disclosure Election", kind="Fact",
             grain="brokerage account x OBO / NOBO election effective period",
             dimensions=[dict(name="disclosure_election_account", attr="Disclosure Election Account",
                              note="Account key; personal data."),
                         dict(name="beneficial_owner_disclosure_status", attr="Beneficial Owner Disclosure Status",
                              note="Personal data at account level; broad roles see the rate only."),
                         dict(name="disclosure_election_effective_from", attr="Disclosure Election Effective From"),
                         dict(name="disclosure_election_effective_to", attr="Disclosure Election Effective To"),
                         dict(name="disclosure_default_applied", attr="Disclosure Default Applied Indicator")]),
        dict(name="voting_choice_election", product="DP-408", entity="Voting Choice Election", kind="Fact",
             grain="account x fund x voting choice effective period",
             dimensions=[dict(name="voting_choice_election_id", attr="Voting Choice Election ID"),
                         dict(name="voting_choice_account", attr="Voting Choice Account", note="Account key; personal data."),
                         dict(name="voting_choice_fund", attr="Voting Choice Fund"),
                         dict(name="chosen_voting_policy", attr="Chosen Voting Policy"),
                         dict(name="voting_choice_effective_from", attr="Voting Choice Effective From"),
                         dict(name="voting_choice_effective_to", attr="Voting Choice Effective To"),
                         dict(name="voting_choice_default_applied", attr="Voting Choice Default Applied Indicator")]),
        dict(name="issuer_meeting_event", product="DP-408", entity="Corporate Action Event", kind="Dimension",
             dimensions=[dict(name="corporate_action_event_id", attr="Corporate Action Event ID"),
                         dict(name="event_instrument", attr="Event Instrument"),
                         dict(name="corporate_action_event_type", attr="Corporate Action Event Type"),
                         dict(name="event_record_date", attr="Record Date"),
                         dict(name="event_meeting_date", attr="Meeting Date")]),
        # DP-408's record-date copy of 49 (DP-300 is SM-24's); read only for the entitlement test and coverage, never
        # with any 06 position. DP-408's copy of the 29 register is not read: register_position (DP-580) is the book.
        dict(name="record_date_client_holding", product="DP-408", entity="Client Holding", kind="Fact",
             grain="brokerage client holding (49, derived copy) x issuer meeting record date",
             dimensions=[dict(name="client_holding_id", attr="Client Holding ID", note="Personal data."),
                         dict(name="holding_account", attr="Holding Account", note="Account key; personal data."),
                         dict(name="held_instrument", attr="Held Instrument"),
                         dict(name="client_holding_date", attr="Client Holding Date")],
             facts=[dict(name="settled_quantity", attr="Settled Quantity",
                         note="A quantity for the entitlement test; never valued, never Client Assets.")]),
    ],

    shared=["DP-013/Calendar Date", "DP-004/Investment Product", "DP-115/Counterparty", "DP-005/Distribution Agreement",
            "DP-167/Safekeeping Account", "DP-240/Party", "DP-192/Employee"],

    relationships=[
        # Product spine
        dict(frm="share_class", to="fund", on="share_class.parent_product = fund.fund_id", type="many-to-one"),
        dict(frm="fund", to="DP-004/Investment Product", on="fund.fund_id = investment_product.product_id",
             type="one-to-one"),
        dict(frm="dealing_terms", to="fund", on="dealing_terms.dealing_product_id = fund.fund_id", type="one-to-one"),
        dict(frm="settlement_terms", to="fund", on="settlement_terms.settlement_product_id = fund.fund_id",
             type="one-to-one"),
        dict(frm="etf_terms", to="fund", on="etf_terms.etf_product_id = fund.fund_id", type="one-to-one"),
        dict(frm="processing_provider", to="DP-240/Party", on="processing_provider.provider_id = party.party_id",
             type="one-to-one"),
        dict(frm="intermediary", to="DP-240/Party", on="intermediary.intermediary_id = party.party_id",
             type="one-to-one"),
        dict(frm="authorized_participant", to="DP-115/Counterparty",
             on="authorized_participant.ap_counterparty_party = counterparty.party_id", type="many-to-one",
             warning="Optional: an authorized participant that is not also an approved trading counterparty has no "
                     "DP-115 row; use an outer join so its AP orders are not dropped."),

        # Certified facts
        dict(frm="share_class_flows", to="share_class", on="share_class_flows.flow_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="share_class_flows", to="DP-013/Calendar Date", on="share_class_flows.period_end_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="nav_of_record", to="share_class", on="nav_of_record.nav_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="nav_of_record", to="nav_calculation", on="nav_of_record.parent_nav_calculation = nav_calculation (fund "
             "accounting book, valuation date, calculation source, version)", type="many-to-one"),

        # DP-177 orders
        dict(frm="fund_order", to="share_class", on="fund_order.order_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="fund_order", to="account", on="fund_order.order_account = account.account_id", type="many-to-one"),
        dict(frm="fund_order", to="processing_provider", on="fund_order.processing_provider_id = processing_provider.provider_id",
             type="many-to-one"),
        dict(frm="fund_order", to="intermediary", on="fund_order.receiving_party = intermediary.intermediary_id",
             type="many-to-one"),
        dict(frm="fund_order", to="resolved_dealer", on="fund_order.resolved_dealer_id = resolved_dealer.dealer_id",
             type="many-to-one"),
        dict(frm="fund_order", to="DP-013/Calendar Date", on="fund_order.trade_date_assigned = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="fund_order", to="nav_of_record",
             on="fund_order.order_share_class = nav_of_record.nav_share_class and fund_order.as_of_trade_date = "
                "nav_calculation.valuation_date", type="many-to-one",
             warning="For As-Of Dilution % of Class Net Assets only; join through nav_calculation and keep the NAV of "
                     "record pin, or a share class and date matches several NAV versions."),
        dict(frm="fund_order", to="DP-192/Employee", on="fund_order.as_of_approver = employee.employee_id",
             type="many-to-one"),
        dict(frm="fund_order", to="interface_session",
             on="fund_order.receiving_interface_session = interface_session.interface_session_key", type="many-to-one"),
        dict(frm="order_exception", to="fund_order", on="order_exception.exception_fund_order = fund_order.fund_order_id",
             type="many-to-one"),
        dict(frm="order_exception", to="account_restriction",
             on="order_exception.blocking_account_restriction = account_restriction.account_restriction_id",
             type="many-to-one"),
        dict(frm="exchange_link", to="fund_order", on="exchange_link.exchange_out_order = fund_order.fund_order_id "
             "(and a second role on exchange_in_order)", type="many-to-many",
             warning="Each link joins two orders; summing order values through the link counts both legs of an exchange. "
                     "Use it only to count links (Unmatched Exchange Legs)."),
        dict(frm="interface_session", to="intermediary", on="interface_session.session_counterparty = intermediary.intermediary_id",
             type="many-to-one"),
        dict(frm="interface_session", to="DP-013/Calendar Date",
             on="interface_session.session_business_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="processing_calendar_event", to="share_class",
             on="processing_calendar_event.event_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="processing_calendar_event", to="DP-013/Calendar Date",
             on="processing_calendar_event.event_business_date = calendar_date.calendar_date", type="many-to-one"),

        # DP-178 settlement
        dict(frm="settlement_obligation", to="fund_order", on="settlement_obligation.obligation_fund_order = fund_order.fund_order_id",
             type="many-to-one"),
        dict(frm="settlement_obligation", to="ap_order", on="settlement_obligation.obligation_ap_order = ap_order.ap_order_id",
             type="many-to-one"),
        dict(frm="settlement_obligation", to="settlement_batch",
             on="settlement_obligation.obligation_settlement_batch = settlement_batch.settlement_batch_id", type="many-to-one"),
        dict(frm="settlement_obligation", to="intermediary", on="settlement_obligation.settling_party = intermediary.intermediary_id",
             type="many-to-one"),
        dict(frm="settlement_obligation", to="DP-013/Calendar Date",
             on="settlement_obligation.contractual_settlement_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="settlement_batch", to="intermediary", on="settlement_batch.batch_settling_party = intermediary.intermediary_id",
             type="many-to-one"),
        dict(frm="cash_movement", to="settlement_batch", on="cash_movement.settled_batch = settlement_batch.settlement_batch_id",
             type="many-to-one"),
        dict(frm="cash_movement", to="settlement_obligation",
             on="cash_movement.settled_obligation = settlement_obligation.settlement_obligation_id", type="many-to-one"),
        dict(frm="cash_movement", to="DP-167/Safekeeping Account",
             on="cash_movement.fund_cash_account = safekeeping_account.safekeeping_account_id", type="many-to-one"),
        dict(frm="settlement_exception", to="settlement_obligation",
             on="settlement_exception.exception_settlement_obligation = settlement_obligation.settlement_obligation_id",
             type="many-to-one"),
        dict(frm="settlement_exception", to="settlement_batch",
             on="settlement_exception.exception_settlement_batch = settlement_batch.settlement_batch_id", type="many-to-one"),

        # DP-179 ETF primary market
        dict(frm="ap_order", to="share_class", on="ap_order.etf_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="ap_order", to="authorized_participant", on="ap_order.authorized_participant_id = authorized_participant.ap_id",
             type="many-to-one"),
        dict(frm="ap_order", to="DP-005/Distribution Agreement", on="ap_order.ap_agreement = distribution_agreement.agreement_id",
             type="many-to-one"),
        dict(frm="ap_order", to="processing_provider", on="ap_order.ap_order_processing_provider = processing_provider.provider_id",
             type="many-to-one"),
        dict(frm="ap_order", to="DP-013/Calendar Date", on="ap_order.ap_order_trade_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="ap_order", to="nav_of_record",
             on="ap_order.etf_share_class = nav_of_record.nav_share_class and ap_order.ap_order_trade_date = "
                "nav_calculation.valuation_date", type="many-to-one",
             warning="Keep the NAV of record pin; without it a trade date matches every NAV version and the order value "
                     "is multiplied."),
        dict(frm="basket_line", to="ap_order", on="basket_line.line_ap_order = ap_order.ap_order_id", type="many-to-one"),

        # DP-180 CIP and alerts
        dict(frm="monitoring_alert", to="account", on="monitoring_alert.alert_account = account.account_id", type="many-to-one"),
        dict(frm="monitoring_alert", to="subject_party", on="monitoring_alert.alert_subject_party = subject_party.subject_party_id",
             type="many-to-one"),
        dict(frm="monitoring_alert", to="fund_order", on="monitoring_alert.triggering_fund_order = fund_order.fund_order_id",
             type="many-to-one"),
        dict(frm="monitoring_alert", to="cash_movement",
             on="monitoring_alert.triggering_cash_movement = cash_movement.cash_movement_id", type="many-to-one"),
        dict(frm="monitoring_alert", to="account_restriction",
             on="monitoring_alert.alert_resulting_account_restriction = account_restriction.account_restriction_id",
             type="many-to-one"),
        dict(frm="monitoring_alert", to="DP-192/Employee",
             on="monitoring_alert.alert_reviewer = employee.employee_id (second role: second_reviewer)", type="many-to-one"),
        dict(frm="account", to="identity_verification",
             on="account.opening_identity_verification = identity_verification.identity_verification_id", type="many-to-one"),
        dict(frm="identity_verification", to="subject_party",
             on="identity_verification.verified_party = subject_party.subject_party_id", type="many-to-one"),        dict(frm="account_restriction", to="account", on="account_restriction.restricted_account = account.account_id",
             type="many-to-one"),

        # DP-181 controls
        dict(frm="control_check", to="share_class", on="control_check.control_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="control_check", to="fund", on="control_check.control_fund = fund.fund_id", type="many-to-one"),
        dict(frm="control_check", to="nav_of_record", on="control_check.compared_nav_record = nav_of_record.share_class_nav_id",
             type="many-to-one"),
        dict(frm="control_check", to="processing_provider",
             on="control_check.control_processing_provider = processing_provider.provider_id", type="many-to-one"),
        dict(frm="control_check", to="DP-192/Employee", on="control_check.control_signed_off_by = employee.employee_id",
             type="many-to-one"),
        dict(frm="control_check", to="DP-013/Calendar Date",
             on="control_check.control_business_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="control_exception", to="control_check",
             on="control_exception.exception_control_check = control_check.ta_control_check_id", type="many-to-one"),
        dict(frm="control_exception", to="DP-192/Employee", on="control_exception.control_exception_owner = employee.employee_id",
             type="many-to-one"),

        # DP-580 register
        dict(frm="register_position", to="share_class", on="register_position.register_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="register_position", to="account", on="register_position.register_account = account.account_id",
             type="many-to-one"),
        dict(frm="register_position", to="processing_provider",
             on="register_position.register_keeper = processing_provider.provider_id", type="many-to-one",
             warning="Optional: in house the keeper may be empty; use an outer join so register rows are not dropped."),
        dict(frm="register_position", to="account_restriction",
             on="register_position.governing_account_restriction = account_restriction.account_restriction_id",
             type="many-to-one"),
        dict(frm="register_position", to="register_transaction",
             on="register_position.last_register_transaction = register_transaction.register_transaction_id",
             type="many-to-one"),
        dict(frm="register_position", to="DP-013/Calendar Date",
             on="register_position.register_business_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="register_transaction", to="share_class",
             on="register_transaction.posting_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="register_transaction", to="account", on="register_transaction.posting_account = account.account_id",
             type="many-to-one"),
        dict(frm="register_transaction", to="nav_of_record",
             on="register_transaction.applied_nav_record = nav_of_record.share_class_nav_id", type="many-to-one",
             warning="Optional: a posting whose Applied NAV Record is not the NAV of record finds no row; use an outer join."),
        dict(frm="register_transaction", to="fund_order",
             on="register_transaction.originating_fund_order = fund_order.fund_order_id", type="many-to-one",
             warning="Optional; one order can post more than once (reversal and correction), so never sum order values "
                     "through this join."),
        dict(frm="register_transaction", to="ap_order", on="register_transaction.originating_ap_order = ap_order.ap_order_id",
             type="many-to-one"),
        dict(frm="register_transaction", to="register_transaction",
             on="register_transaction.reversed_register_transaction = register_transaction.register_transaction_id "
                "(second role)", type="many-to-one"),
        dict(frm="register_transaction", to="DP-013/Calendar Date",
             on="register_transaction.register_trade_date = calendar_date.calendar_date", type="many-to-one"),

        # DP-408 proxy, pass-through and voting choice
        dict(frm="vote_tally", to="proxy_proposal", on="vote_tally.tally_proposal = proxy_proposal.proposal_id",
             type="many-to-one",
             warning="One row per tally as-of date: keep the latest-tally filter or a proposal's votes are counted once "
                     "per tally."),
        dict(frm="vote_tally", to="DP-013/Calendar Date", on="vote_tally.tally_as_of_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="proxy_proposal", to="proxy_campaign", on="proxy_proposal.proposal_campaign = proxy_campaign.proxy_campaign_id",
             type="many-to-one"),
        dict(frm="proxy_campaign", to="fund", on="proxy_campaign.registrant_fund = fund.fund_id", type="many-to-one"),
        dict(frm="proxy_campaign", to="DP-240/Party", on="proxy_campaign.solicitation_agent = party.party_id",
             type="many-to-one"),
        dict(frm="proxy_campaign", to="DP-013/Calendar Date",
             on="proxy_campaign.campaign_record_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="proxy_campaign", to="register_position",
             on="share_class.parent_product = proxy_campaign.registrant_fund and register_position.register_share_class = "
                "share_class.share_class_id and register_position.register_business_date = proxy_campaign.campaign_record_date",
             type="many-to-many",
             warning="For Own-Fund Record Date Share Breaks only: each campaign reads every register row of its fund on "
                     "the record date. Two campaigns of one fund on one record date read the same rows, so register "
                     "shares are never added across campaigns."),
        dict(frm="intermediary_vote_instruction", to="proxy_proposal",
             on="intermediary_vote_instruction.instruction_proposal = proxy_proposal.proposal_id", type="many-to-one"),
        dict(frm="intermediary_vote_instruction", to="DP-240/Party",
             on="intermediary_vote_instruction.voting_intermediary = party.party_id", type="many-to-one"),
        dict(frm="issuer_pass_through", to="issuer_meeting_event",
             on="issuer_pass_through.issuer_meeting = issuer_meeting_event.corporate_action_event_id", type="many-to-one"),
        dict(frm="issuer_pass_through", to="account", on="issuer_pass_through.pass_through_account = account.account_id",
             type="many-to-one"),
        dict(frm="issuer_pass_through", to="record_date_client_holding",
             on="issuer_pass_through.pass_through_account = record_date_client_holding.holding_account and "
                "issuer_meeting_event.event_instrument = record_date_client_holding.held_instrument and "
                "issuer_meeting_event.event_record_date = record_date_client_holding.client_holding_date",
             type="one-to-one",
             warning="Optional: an entitled account with no holding row on the record date is itself an entitlement break; "
                     "use an outer join."),
        dict(frm="disclosure_election", to="account", on="disclosure_election.disclosure_election_account = account.account_id",
             type="many-to-one"),
        dict(frm="voting_choice_election", to="account", on="voting_choice_election.voting_choice_account = account.account_id",
             type="many-to-one"),
        dict(frm="voting_choice_election", to="fund", on="voting_choice_election.voting_choice_fund = fund.fund_id",
             type="many-to-one"),
        dict(frm="record_date_client_holding", to="account",
             on="record_date_client_holding.holding_account = account.account_id", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Fund and share class", levels=["fund.business_line", "fund.fund_name", "share_class.share_class_name"]),
        dict(name="Dealing route", levels=["fund_order.dealing_route", "fund_order.order_message_standard"]),
        dict(name="Alert category", levels=["monitoring_alert.monitoring_alert_category", "monitoring_alert.monitoring_scenario"]),
        dict(name="TA control", levels=["control_check.ta_control_type", "control_check.control_result"]),
        dict(name="Register book", levels=["register_position.register_account_category", "register_position.register_keeper"]),
        dict(name="Proxy campaign", levels=["proxy_campaign.meeting_type", "proxy_campaign.proxy_campaign_id",
                                            "proxy_proposal.proposal_id"]),
    ],

    metrics=[
        # --- Certified, owned elsewhere ------------------------------------------------------------------------
        dict(name="Net Flows", ref="SM-20/Net Flows",
             note="Read from share_class_flows (Share Class grain, MONTH, Locked, Reported). Orders, obligations and AP "
                  "orders in this model are never flows (CD-199, CD-200)."),
        dict(name="Gross Sales", ref="SM-20/Gross Sales", note="Read from share_class_flows."),
        dict(name="Redemptions", ref="SM-20/Redemptions", note="Read from share_class_flows."),
        dict(name="NAV per Share", ref="SM-11/NAV per Share", note="Read from nav_of_record (NAV of record only)."),
        dict(name="Class Net Assets", ref="SM-11/Class Net Assets", note="Read from nav_of_record (NAV of record only)."),
        dict(name="Shares Outstanding", ref="SM-11/Shares Outstanding",
             note="Read from nav_of_record; the comparison value of the capital stock proof."),

        # --- DP-177 Fund orders and cut-off --------------------------------------------------------------------
        dict(name="Orders Received", aggregation="additive",
             expr="count(fund_order.fund_order_id)",
             source=("DP-177", "Orders Received"),
             description="Number of fund orders the transfer agent received, by trade date assigned, order type, route "
                         "and processing provider.",
             note="Routes that deliver batch totals only are counted in interface_session, not here."),
        dict(name="Estimated Order Value", aggregation="additive",
             expr="sum(fund_order.estimated_order_value)",
             source=("DP-177", "Estimated Order Value"),
             description="The transfer agent's estimate of the value of orders received; an operational estimate, not a flow.",
             note="Never compare to or substitute for Gross Sales or Redemptions (CD-199); sum within one order currency."),
        dict(name="Orders After Cut-Off", aggregation="additive",
             expr="count(fund_order.fund_order_id) where fund_order.cut_off_result = 'After Cut-Off'",
             source=("DP-177", "Orders After Cut-Off"),
             description="Orders received after the dealing cut-off, which must take the next dealing day's price."),
        dict(name="Forward Pricing Breaks", aggregation="additive",
             expr="count(fund_order.fund_order_id) where cut_off_result = 'Before Cut-Off' and the order received "
                  "timestamp (TA received timestamp where the receiving party is not the fund's designated agent) is "
                  "later than dealing_terms.dealing_cut_off_time in cut_off_time_zone on trade_date_assigned, or later "
                  "than processing_calendar_event.revised_cut_off_time where one revises it",
             source=("DP-177", "Forward Pricing Breaks"),
             description="Orders priced as if received before the cut-off although they arrived after it; each is Rule "
                         "22c-1 evidence to investigate.",
             note="Uses the fund cut-off only: intermediary cut-offs and the designated-agent flag are not modeled (GAP-29-001)."),
        dict(name="Trade Date Assignment Breaks", aggregation="additive",
             expr="count(fund_order.fund_order_id) where trade_date_assigned is not a business day of the dealing "
                  "calendar, or is not the dealing day on or after receipt that cut_off_result implies",
             source=("DP-177", "Trade Date Assignment Breaks"),
             description="Orders given a trade date that is not a dealing day or not the one their receipt time implies."),
        dict(name="Open Order Exceptions", aggregation="semi_additive",
             expr="count(order_exception) where exception_status is open at the as-of time; age buckets under 4, 4 to 24 "
                  "and over 24 hours from exception_raised_timestamp; also the count with a blocking_account_restriction",
             time_rule="as-of time (latest in the selected range); never summed over days",
             source=("DP-177", "Open Order Exceptions"),
             description="Order exceptions still open, by type and age."),
        dict(name="Order Exception Resolution Time", aggregation="non_additive",
             expr="median and 90th percentile of (exception_resolved_timestamp - exception_raised_timestamp) in hours for "
                  "exceptions resolved in the period; share with trade_date_moved = 'Y'",
             source=("DP-177", "Exception Resolution Time"),
             description="How long order exceptions take to resolve, and how often the fix moves the trade date.",
             note="Named apart from DP-181's control exception resolution time (one name, one definition). Percentiles "
                  "are recomputed from exception rows, never averaged."),
        dict(name="Straight-Through Processing %", aggregation="ratio",
             numerator="count(fund_order) with no row in order_exception",
             denominator="[Orders Received] for the same selection",
             source=("DP-177", "Straight-Through Processing %"),
             description="Share of orders processed with no exception, by route, dealer and processing provider."),
        dict(name="As-Of Orders", aggregation="additive",
             expr="count(fund_order.fund_order_id) where as_of_trade_date is not null; also the count with "
                  "dilution_threshold_exceeded = 'Y'",
             source=("DP-177", "As-Of Orders and Dilution"),
             description="Orders processed at an earlier trade date than their processing date (as-of and corrections), "
                         "by reason and cost bearer."),
        dict(name="As-Of Dilution Amount", aggregation="additive",
             expr="sum(fund_order.dilution_amount) where as_of_trade_date is in the period",
             source=("DP-177", "Dilution Amount"),
             description="Dilution the as-of orders caused to the remaining shareholders, by reason and cost bearer.",
             note="Sum within one share class currency."),
        dict(name="As-Of Dilution % of Class Net Assets", aggregation="ratio",
             numerator="[As-Of Dilution Amount] by share class and as_of_trade_date",
             denominator="[Class Net Assets] (SM-11) of the same share class at the NAV of record for that valuation date, "
                         "counted once per share class and date",
             source=("DP-177", "As-Of Dilution % of Class Net Assets"),
             description="As-of dilution as a share of the share class's net assets on the as-of trade date.",
             note="Combines DP-177 and the certified DP-165 class net assets, lined up by share class and date."),
        dict(name="Unapproved or Unexplained As-Of Orders", aggregation="additive",
             expr="count(fund_order) where as_of_trade_date is not null and (as_of_approver is null or (as_of_reason "
                  "requires a cause record and related_nav_error_case and related_servicing_error are both null))",
             source=("DP-177", "Unapproved or Unexplained As-Of Orders"),
             description="As-of orders with no approver, or with no NAV error or servicing error recorded as their cause."),
        dict(name="Interface Session Imbalance", aggregation="additive",
             expr="count(interface_session) where session_orders_received_count - count(fund_order whose "
                  "receiving_interface_session = interface_session_key) <> 0 or session_balance_status is not balanced",
             source=("DP-177", "Interface Session Imbalance"),
             description="Batch interface sessions whose order count does not agree with the orders loaded, by route "
                         "and counterparty."),
        dict(name="Unmatched Exchange Legs", aggregation="additive",
             expr="count(exchange_link) where the two legs have different trade_date_assigned, or one leg is rejected "
                  "or canceled and the other is not",
             source=("DP-177", "Unmatched Exchange Legs"),
             description="Exchanges whose outgoing and incoming orders do not line up."),
        dict(name="Processed Orders Without Transaction", aggregation="additive",
             expr="count(fund_order) where fund_order_status = 'Processed' and resulting_transaction is null at the end "
                  "of the business day after trade_date_assigned",
             source=("DP-177", "Processed Orders Without Transaction"),
             description="Processed orders with no 29 Register Transaction (DP-580) by the next business day: the hand-off gap."),

        # --- DP-178 Settlement with intermediaries -------------------------------------------------------------
        dict(name="Obligations Due", aggregation="additive",
             expr="count(settlement_obligation.settlement_obligation_id) by contractual_settlement_date, direction, "
                  "settling party, settlement method",
             source=("DP-178", "Obligations Due"),
             description="Number of settlement obligations falling due, fund orders and AP cash legs together."),
        dict(name="Obligation Amount Due", aggregation="additive",
             expr="sum(settlement_obligation.obligation_amount)",
             source=("DP-178", "Obligation Amount"),
             description="Value of settlement obligations falling due; a settlement amount, never a flow.",
             note="Sum within one currency (batch currency). Gross Sales and Redemptions stay the SM-20 refs."),
        dict(name="On-Time Settlement %", aggregation="ratio",
             numerator="count(settlement_obligation) with actual_settlement_date <= contractual_settlement_date",
             denominator="count(settlement_obligation) whose contractual_settlement_date has passed",
             source=("DP-178", "On-Time Settlement %"),
             description="Share of obligations settled on or before the contractual date, by settling party and method.",
             note="Not available for rows received only at batch grain (NSCC net settlement)."),
        dict(name="Late Settlement Days", aggregation="non_additive",
             expr="business days from contractual_settlement_date to actual_settlement_date (or the as-of date if "
                  "unsettled) per late obligation; mean and maximum by settling party",
             source=("DP-178", "Late Settlement Days"),
             description="How late late obligations are, in business days."),
        dict(name="Contractual Date Breaks", aggregation="additive",
             expr="count(settlement_obligation) with an obligation_fund_order whose contractual_settlement_date differs "
                  "from trade_date_assigned plus the subscription (inflow) or redemption (outflow) settlement period in "
                  "business days",
             source=("DP-178", "Contractual Date Breaks"),
             description="Fund-order obligations set to the wrong contractual settlement date."),
        dict(name="Batch Tie-Out Breaks", aggregation="additive",
             expr="count(settlement_batch) where net_settlement_amount, signed by net_settlement_direction, differs from "
                  "gross_inflow_amount - gross_outflow_amount, or the gross amounts or batch_obligation_count differ "
                  "from the batch's obligations",
             source=("DP-178", "Batch Tie-Out"),
             description="Intermediary settlement batches whose net, gross amounts or obligation count do not tie out."),
        dict(name="Unmatched Cash", aggregation="additive",
             expr="sum(settlement_batch.net_settlement_amount - settled cash_movement.payment_amount of the batch); "
                  "plus count and sum of cash_movement with neither settled_batch nor settled_obligation",
             source=("DP-178", "Unmatched Cash"),
             description="Cash that does not match a settlement batch or obligation.",
             note="Sum within one currency; never across currencies."),
        dict(name="Open Settlement Exceptions", aggregation="semi_additive",
             expr="count(settlement_exception) and sum(shortfall_amount) where settlement_exception_status is open, by "
                  "type and settling party, with age in days from exception_detected_date",
             time_rule="as-of date (latest in the selected range); never summed over days",
             source=("DP-178", "Open Settlement Exceptions"),
             description="Settlement exceptions still open and the shortfall they carry."),
        dict(name="Orders Canceled for Non-Payment", aggregation="additive",
             expr="count(settlement_exception) where canceled_for_non_payment = 'Y'",
             source=("DP-178", "Orders Canceled for Non-Payment"),
             description="Orders canceled because the intermediary did not pay, by settling party and return reason."),
        dict(name="Payments Held by Screening", aggregation="semi_additive",
             expr="count(cash_movement) and sum(payment_amount) where payment_screening_result is not cleared and "
                  "payment_settlement_status is not settled",
             time_rule="as-of date (latest in the selected range)",
             source=("DP-178", "Payments Held by Screening"),
             description="Payments held because screening has not cleared them, by direction."),
        dict(name="Cash Through Non-Fund Accounts", aggregation="additive",
             expr="count(cash_movement) where fund_cash_account is not a DP-167 safekeeping account open on payment_value_date",
             source=("DP-178", "Cash Through Non-Fund Accounts"),
             description="Shareholder cash moved through an account that is not an open fund cash account."),
        dict(name="Late Payer Ranking", aggregation="non_additive",
             expr="rank of settling parties over the trailing 90 days by count of late obligations, then by sum of "
                  "shortfall_amount on their exceptions",
             source=("DP-178", "Late Payer Ranking"),
             description="Intermediaries ranked by how often and how much they settle late."),

        # --- DP-179 ETF creations and redemptions --------------------------------------------------------------
        dict(name="AP Orders", aggregation="additive",
             expr="count(ap_order.ap_order_id) where ap_order_status not in ('Rejected', 'Canceled')",
             source=("DP-179", "AP Orders and Creation Units"),
             description="Creation and redemption orders from authorized participants, by type, ETF, AP and basket form."),
        dict(name="Creation Units Ordered", aggregation="additive",
             expr="sum(ap_order.creation_units_ordered) where ap_order_status not in ('Rejected', 'Canceled')",
             source=("DP-179", "Creation Units Ordered"),
             description="Creation units ordered by authorized participants.",
             note="Sum within one AP order type or sign it by type; creations and redemptions are separate."),
        dict(name="Shares Created and Redeemed", aggregation="additive",
             expr="sum(ap_order.creation_units_ordered * etf_terms.creation_unit_size), positive for creations and "
                  "negative for redemptions, for settled orders by ap_order_settlement_date",
             source=("DP-179", "Shares Created and Redeemed"),
             description="Net ETF shares created and redeemed: the capital stock change fund accounting books, not a flow.",
             note="Never a flow (CD-200): ETF primary-market flows are the SM-20 refs from DP-008 via DP-006."),
        dict(name="Order Value at NAV", aggregation="additive",
             expr="sum(shares created and redeemed per order * nav_of_record.nav_per_share on ap_order_trade_date)",
             source=("DP-179", "Order Value at NAV"),
             description="Value of AP orders at the ETF's NAV of record on the trade date.",
             note="Uses the certified NAV per Share (SM-11). An operational value, not a flow."),
        dict(name="Cash Component Variance", aggregation="non_additive",
             expr="per order: ap_cash_component_amount - estimated_cash_component_amount, both signed by "
                  "ap_cash_component_direction; absolute variance as % of [Order Value at NAV], flagged above tolerance",
             source=("DP-179", "Cash Component Variance"),
             description="Difference between the actual and estimated cash component of each AP order.",
             note="Count of flagged orders adds up; the per-order percentage does not."),
        dict(name="Late or Rejected AP Orders", aggregation="additive",
             expr="count(ap_order) where ap_order_cut_off_result = 'After Cut-Off' or ap_order_status = 'Rejected'",
             source=("DP-179", "Late or Rejected AP Orders"),
             description="AP orders received after the cut-off or rejected, by AP and channel.",
             note="The AP cut-off is read as delivered and not re-tested (GAP-29-005)."),
        dict(name="Transaction Fees Collected", aggregation="additive",
             expr="sum(ap_order.fixed_transaction_fee + ap_order.variable_transaction_fee_amount); fee check flags "
                  "orders whose variable fee differs from variable_transaction_fee_rate x [Order Value at NAV] by more "
                  "than one currency unit",
             source=("DP-179", "Transaction Fees Collected"),
             description="Creation and redemption fees charged to authorized participants, by ETF and AP."),
        dict(name="Basket Delivery Completion %", aggregation="ratio",
             numerator="count(basket_line) with delivered_quantity >= basket_quantity, or the shortfall covered by "
                       "cash_in_lieu_amount",
             denominator="count(basket_line) of orders past ap_order_settlement_date",
             source=("DP-179", "Basket Delivery Completion %"),
             description="Share of in-kind basket lines delivered in full by the settlement date."),
        dict(name="Failed Basket Deliveries", aggregation="semi_additive",
             expr="count(basket_line) where line_settlement_status in ('Failed', 'Pending') after ap_order_settlement_date; "
                  "undelivered quantity basket_quantity - delivered_quantity and age in business days",
             time_rule="as-of date (latest in the selected range)",
             source=("DP-179", "Failed Basket Deliveries"),
             description="Basket lines not delivered after the settlement date, by AP and constituent."),
        dict(name="Collateral Coverage of Shortfall", aggregation="ratio",
             numerator="sum(ap_order.collateral_posted_amount) of orders with an open failed-basket exception",
             denominator="sum(settlement_exception.shortfall_amount) of open exceptions of type Failed Basket Delivery on "
                         "those orders' AP cash-leg obligations",
             source=("DP-179", "Collateral Coverage of Shortfall"),
             description="How much of the failed-delivery shortfall the AP's posted collateral covers; orders under 100% flagged.",
             note="Read through settlement_obligation (obligation_ap_order filled) and settlement_exception from DP-178."),
        dict(name="Cash in Lieu Share", aggregation="ratio",
             numerator="sum(basket_line.cash_in_lieu_amount) for in-kind orders",
             denominator="[Order Value at NAV] of the same orders",
             source=("DP-179", "Cash in Lieu Share"),
             description="Share of in-kind order value delivered as cash in lieu, by ETF and month."),
        dict(name="AP Cash Leg On-Time %", aggregation="ratio",
             numerator="count(settlement_obligation) with obligation_ap_order filled and actual_settlement_date <= "
                       "contractual_settlement_date",
             denominator="count(settlement_obligation) with obligation_ap_order filled and due",
             source=("DP-179", "AP Cash Leg On-Time %"),
             description="Share of AP cash-leg obligations settled on time, by authorized participant.",
             note="Read from DP-178's obligations; DP-179's copy of the cash legs is not read, so nothing doubles."),
        dict(name="Settled AP Orders Without Transaction", aggregation="additive",
             expr="count(ap_order) where ap_order_status = 'Settled' and ap_resulting_transaction is null at the end of "
                  "the business day after ap_order_settlement_date",
             source=("DP-179", "Settled Orders Without Transaction"),
             description="Settled AP orders with no 29 Register Transaction (DP-580) by the next business day: the hand-off gap."),
        dict(name="AP Concentration", aggregation="non_additive",
             expr="per ETF share class: share of [Creation Units Ordered] over the trailing 12 months from the largest "
                  "authorized participant and from the largest three",
             source=("DP-179", "AP Concentration"),
             description="How dependent each ETF is on its largest authorized participants."),

        # --- DP-180 CIP, AML and fraud (Restricted - Legal) ----------------------------------------------------
        dict(name="Identity Verifications", aggregation="additive",
             expr="count(identity_verification) with verification_date in the period, by cip_program and verification_method",
             source=("DP-180", "Identity Verifications and Pass Rate"),
             description="Identity verifications of direct shareholders completed, by CIP program and method."),
        dict(name="Identity Verification Pass Rate %", aggregation="ratio",
             numerator="count(identity_verification) with verification_result = 'Verified' in the period",
             denominator="[Identity Verifications]",
             source=("DP-180", "Verification Result"),
             description="Share of identity verifications in the period whose result is verified."),
        dict(name="Accounts Opened Without Verification", aggregation="count_distinct",
             expr="count(distinct account.account_id) with account_open_date in the period, registration type in CIP "
                  "scope, and no opening_identity_verification or one whose verification_result is not verified",
             source=("DP-180", "Accounts Opened Without Verification"),
             description="New accounts in CIP scope whose opening has no verified identity verification."),
        dict(name="Verification Turnaround", aggregation="non_additive",
             expr="business days from account.account_open_date to identity_verification.verification_date of the "
                  "opening verification; median and share over 30 days, by verification_method",
             source=("DP-180", "Verification Turnaround"),
             description="How long identity verification takes after an account opens."),
        dict(name="Unverified Accounts Not Restricted", aggregation="count_distinct",
             expr="count(distinct account.account_id) open whose opening identity verification is missing or not "
                  "verified and which has no account_restriction with account_restriction_lifted_date empty",
             source=("DP-180", "Unverified Accounts Not Restricted"),
             description="Accounts that failed or have not completed identity verification and can still transact."),
        dict(name="Government List Check Coverage %", aggregation="ratio",
             numerator="count(identity_verification) completed with government_list_check_date filled",
             denominator="count(identity_verification) completed",
             source=("DP-180", "Government List Check Coverage %"),
             description="Share of shareholder identity verifications checked against government lists, by month."),        dict(name="Alerts Generated", aggregation="additive",
             expr="count(monitoring_alert) by date of alert_generated_timestamp, category and scenario",
             source=("DP-180", "Alerts Generated"),
             description="AML, sanctions and fraud alerts generated on shareholder accounts."),
        dict(name="Alerts per 1,000 Open Accounts", aggregation="ratio",
             numerator="[Alerts Generated] x 1,000",
             denominator="count(distinct account.account_id) with account_status open in the period",
             source=("DP-180", "Account Status"),
             description="Alert rate per thousand open shareholder accounts (part of DP-180's Alerts Generated)."),
        dict(name="Open Alert Backlog", aggregation="semi_additive",
             expr="count(monitoring_alert) open at the as-of date by category and priority, aged 0 to 10, 11 to 30 and "
                  "over 30 calendar days from alert_generated_timestamp",
             time_rule="as-of date (latest in the selected range); never summed over days",
             source=("DP-180", "Open Alert Backlog"),
             description="Alerts awaiting disposition, by category, priority and age.",
             note="The one DP-180 metric the TA management backlog view sees, de-identified (no status, account or party columns)."),
        dict(name="Disposition Time", aggregation="non_additive",
             expr="calendar days from alert_generated_timestamp to disposition_date per dispositioned alert; median, "
                  "90th percentile and share within 30 days, by category",
             source=("DP-180", "Disposition Time"),
             description="How quickly alerts are decided, against the 30-day SAR decision clock."),
        dict(name="Escalation Rate", aggregation="ratio",
             numerator="count(dispositioned monitoring_alert) with escalation_case_reference filled",
             denominator="count(dispositioned monitoring_alert)",
             source=("DP-180", "Escalation Rate"),
             description="Share of decided alerts escalated to an AML case, by scenario; AML unit only."),
        dict(name="Second Review Coverage %", aggregation="ratio",
             numerator="count(dispositioned monitoring_alert in scope) with second_reviewer filled",
             denominator="count(dispositioned monitoring_alert) of high priority, escalated, or first reviewed by an "
                         "external (TA) reviewer",
             source=("DP-180", "Second Review Coverage %"),
             description="Share of the alerts that need a second review that received one."),
        dict(name="Open Sanctions Matches", aggregation="semi_additive",
             expr="count(monitoring_alert) in the sanctions category with sanctions_match_result potential or true match "
                  "and open, by matched sanctions list; true matches without an alert_resulting_account_restriction flagged",
             time_rule="as-of date (latest in the selected range)",
             source=("DP-180", "Open Sanctions Matches"),
             description="Open potential and true sanctions matches, and true matches with no account restriction."),
        dict(name="Released Before Disposition", aggregation="additive",
             expr="count(monitoring_alert) in the sanctions and fraud categories whose triggering fund order was "
                  "processed, or triggering cash movement settled, before disposition_date",
             source=("DP-180", "Released Before Disposition"),
             description="Sanctions and fraud alerts whose order or payment went through before the alert was decided."),
        dict(name="Fraud Loss", aggregation="additive",
             expr="sum(monitoring_alert.fraud_loss_amount) for alerts dispositioned in the period",
             source=("DP-180", "Fraud Loss"),
             description="Losses from shareholder account fraud, by scenario and account type; published only here (CD-332)."),
        dict(name="Alerts on High-Risk Parties", aggregation="additive",
             expr="count(monitoring_alert) whose alert subject party has aml_risk_rating = 'High' or pep_status = 'Y'",
             source=("DP-180", "Alerts on High-Risk Parties"),
             description="Alerts on parties rated high AML risk or politically exposed, by category.",
             note="Reads the current KYC profile, not the profile at alert time (see open decisions)."),

        # --- DP-181 TA daily controls --------------------------------------------------------------------------
        dict(name="Control Coverage %", aggregation="ratio",
             numerator="count of (active share class x required TA control type x business day) with a control_check",
             denominator="count of active share classes x required control types x business days",
             source=("DP-181", "Control Coverage %"),
             description="Share of required daily TA controls actually run for active share classes."),
        dict(name="Control Pass Rate %", aggregation="ratio",
             numerator="count(control_check) with control_result = 'Pass'",
             denominator="count(control_check)",
             source=("DP-181", "Control Pass Rate %"),
             description="Share of TA control checks that passed, by control type, provider and month."),
        dict(name="Control Difference Check", aggregation="additive",
             expr="count(control_check) where ta_control_value - comparison_value - control_difference <> 0, or "
                  "abs(control_difference) > control_tolerance while control_result = 'Pass'",
             source=("DP-181", "Control Difference Check"),
             description="Control checks whose difference is miscalculated or wrongly passed."),
        dict(name="Capital Stock Proof Difference", aggregation="additive",
             expr="count and sum(abs(control_difference)) of capital stock proofs whose difference exceeds control_tolerance",
             source=("DP-181", "Capital Stock Proof Difference"),
             description="Capital stock proofs out of tolerance, in shares, per share class and business date.",
             note="The share sum adds up within one share class only; across share classes read the count."),
        dict(name="Proofs Not Against NAV of Record", aggregation="additive",
             expr="count(control_check) of type capital stock proof whose compared_nav_record finds no row in "
                  "nav_of_record for the share class and control_business_date, or whose comparison_value differs from "
                  "that row's shares_outstanding",
             source=("DP-181", "Proofs Not Against NAV of Record"),
             description="Capital stock proofs compared with something other than the certified NAV of record."),
        dict(name="Cash Proof Difference", aggregation="additive",
             expr="sum(abs(control_difference)) of cash proofs beyond control_tolerance, in control_currency",
             source=("DP-181", "Cash Proof Difference"),
             description="Cash proof differences out of tolerance, per share class or fund and day.",
             note="Sum within one control currency only."),
        dict(name="Unprocessed Items and As-Of Dilution Days Over Threshold", aggregation="additive",
             expr="count of business days with the unprocessed items control (count) or the as-of dilution control "
                  "(amount) above control_tolerance, per share class",
             source=("DP-181", "Unprocessed Items and As-Of Dilution"),
             description="Days on which unprocessed items or as-of dilution exceeded their thresholds.",
             note="The daily control values themselves are read per share class and day, never summed."),
        dict(name="Open Control Exceptions", aggregation="semi_additive",
             expr="count(control_exception) open at the as-of date by severity and cause, aged in business days from "
                  "the check's control_business_date",
             time_rule="as-of date (latest in the selected range)",
             source=("DP-181", "Open Control Exceptions"),
             description="TA control exceptions still open, by severity, cause and age."),
        dict(name="Control Exception Resolution Time", aggregation="non_additive",
             expr="business days from control_business_date to control_exception_resolved_date for exceptions resolved "
                  "in the period; median and maximum by cause and owner",
             source=("DP-181", "Exception Resolution Time"),
             description="How long TA control exceptions take to resolve."),
        dict(name="Exception Explanation Tie-Out", aggregation="additive",
             expr="count(failed control_check) where control_difference - sum(control_exception.exception_difference_value) <> 0",
             source=("DP-181", "Exception Explanation Tie-Out"),
             description="Failed checks whose difference the recorded exceptions do not fully explain."),
        dict(name="Daily Sign-Off Completion %", aggregation="ratio",
             numerator="count(control_check) with control_signed_off_by filled by 10am ET on the next business day",
             denominator="count(control_check) of the business date",
             source=("DP-181", "Daily Sign-Off Completion %"),
             description="Share of daily control checks the firm signed off on time, by processing provider.",
             note="Measured from the sign-off's load time; there is no sign-off timestamp (GAP-29-006)."),

        # --- DP-580 Fund share register and postings (shares, never Client Assets or AUM) -----------------------
        dict(name="Registered Shares", aggregation="semi_additive",
             expr="sum(register_position.registered_shares) on the register business date, by register_share_class, "
                  "register_account_category and register_keeper; always read within one Register Account Category",
             time_rule="last business date in the selected range; never summed over dates",
             source=("DP-580", "Registered Shares"),
             description="Shares on the transfer agent's register by share class, register category and register keeper.",
             note="Each category is a different book: omnibus, nominee, networked and plan rows look through to owners "
                  "counted elsewhere, and Firm Proprietary rows are firm assets. No total across categories is published; "
                  "shares outstanding stay SM-11's."),
        dict(name="Fund-Only Registered Shares", aggregation="semi_additive",
             expr="sum(register_position.registered_shares) where register_account_category in ('Fund-Only', "
                  "'Institutional Direct'), by register_share_class",
             time_rule="last business date in the selected range; never summed over dates",
             source=("DP-580", "Fund-Only Registered Shares"),
             description="Shares held in the directly registered client accounts, the source the 06 Fund Shareholder "
                         "Position view reads (CW-122).",
             note="Shares, not Client Assets: valuing them and adding them to client assets is SM-20's, from DP-008."),
        dict(name="Look-Through Category Registered Shares", aggregation="semi_additive",
             expr="sum(register_position.registered_shares) where register_account_category in ('Broker-Dealer Omnibus', "
                  "'Plan Omnibus', 'DTC Nominee', 'Intermediary Omnibus', 'Networked', 'CIT Unitholder'), by "
                  "register_share_class and register_account_category",
             time_rule="last business date in the selected range; never summed over dates",
             source=("DP-580", "Look-Through Category Registered Shares"),
             description="Shares on omnibus, nominee, networked and unitholder rows whose owners are counted in another book.",
             note="Never added to Fund-Only Registered Shares; the owners are counted in 49 (DP-300), 16 (DP-430), the DTC "
                  "participants' books or the 06 look-through. Firm Proprietary rows are not in this selection."),
        dict(name="Uncollected Shares", aggregation="semi_additive",
             expr="sum(register_position.uncollected_shares) on the register business date, by register_share_class",
             time_rule="last business date in the selected range; never summed over dates",
             source=("DP-580", "Uncollected Shares"),
             description="Registered shares whose purchase payment has not yet been collected."),
        dict(name="Escrowed, Pledged or Restricted Shares", aggregation="semi_additive",
             expr="sum(register_position.escrowed_or_pledged_shares + register_position.restricted_shares) on the register "
                  "business date; with count(register_position) where governing_account_restriction is filled",
             time_rule="last business date in the selected range; never summed over dates",
             source=("DP-580", "Escrowed, Pledged or Restricted Shares"),
             description="Registered shares that are escrowed, pledged or restricted, and the register rows under an "
                         "account restriction.",
             note="Reads the 15 restriction key only; Rule 2165 restrictions are DP-583's."),
        dict(name="Register Roll-Forward Breaks", aggregation="additive",
             expr="count of (register_account x register_share_class) on day D where registered_shares on D minus "
                  "registered_shares on the prior business day differs from sum(register_transaction.shares_posted, signed "
                  "by share_movement_direction) of transactions with register_transaction_status = 'Posted' and "
                  "posting_date = D by more than 0.001 shares",
             source=("DP-580", "Register Roll-Forward Breaks"),
             description="Register positions whose day-on-day change is not explained by the day's postings.",
             note="Adds over days as break-days; read by share class and keeper, not by account, outside TA operations."),
        dict(name="Register Transactions Posted", aggregation="additive",
             expr="count(register_transaction) where register_transaction_status = 'Posted' and register_trade_date in the "
                  "period, by register_transaction_type and share_movement_direction",
             source=("DP-580", "Register Transactions Posted"),
             description="Share movements posted to the register, by transaction type and direction.",
             note="DP-580's measure is a count and a sum of Shares Posted; the sum is Register Shares Posted."),
        dict(name="Register Shares Posted", aggregation="additive",
             expr="sum(register_transaction.shares_posted, signed by share_movement_direction) where "
                  "register_transaction_status = 'Posted' and register_trade_date in the period, within one share class",
             source=("DP-580", "Shares Posted"),
             description="Net shares posted to the register in the period, by share class and transaction type.",
             note="Part of DP-580's Register Transactions Posted. A share movement, never a flow (flows are SM-20's)."),
        dict(name="Gross Amount Posted", aggregation="additive",
             expr="sum(register_transaction.gross_amount) of posted transactions in the period, by "
                  "register_transaction_type, within one register_transaction_currency",
             source=("DP-580", "Gross Amount Posted"),
             description="Gross value of the postings on the register: an operational amount, never a flow or Net New "
                         "Assets figure.",
             note="Gross Sales, Redemptions and Net New Assets stay the SM-20 refs from DP-008; never compare or substitute."),
        dict(name="Charges and Withholding Posted", aggregation="additive",
             expr="sum(sales_charge_amount), sum(redemption_fee_amount), sum(tax_withheld_amount) and sum(net_amount) of "
                  "posted register_transaction rows in the period, within one register_transaction_currency",
             source=("DP-580", "Charges and Withholding Posted"),
             description="Sales charges, redemption fees and tax withheld on register postings, with the net amount."),
        dict(name="As-Of Posting Rate", aggregation="ratio",
             numerator="[Register Transactions Posted] with as_of_posting_indicator = 'Y'",
             denominator="[Register Transactions Posted] for the same selection",
             source=("DP-580", "As-Of Posting Rate"),
             description="Share of register postings made as of an earlier trade date, by trade date month."),
        dict(name="Reversed or Corrected Register Transactions", aggregation="additive",
             expr="count(register_transaction) where register_transaction_status in ('Reversed', 'Corrected') and "
                  "posting_date in the period, each linked to its reversed_register_transaction",
             source=("DP-580", "Reversed or Corrected Register Transactions"),
             description="Register postings reversed or corrected in the period."),
        dict(name="Price Applied Differs From NAV", aggregation="additive",
             expr="count(posted register_transaction) where sales_charge_amount = 0 and abs(price_per_share_applied - "
                  "nav_of_record.nav_per_share of the applied_nav_record) > 0.00005",
             source=("DP-580", "Price Applied Differs From NAV"),
             description="No-load postings priced at something other than the NAV per share they name.",
             note="Read against the NAV of record (SM-11); a posting whose applied NAV record is a superseded version finds "
                  "no row and is listed for review (see open decisions)."),

        # --- DP-408 Proxy solicitation, pass-through and voting choice ------------------------------------------
        dict(name="Active Proxy Campaigns", aggregation="semi_additive",
             expr="count(proxy_campaign) where meeting_status in ('Scheduled', 'Soliciting', 'Adjourned') at the as-of "
                  "date, by meeting_type",
             time_rule="as-of date (latest in the selected range); never summed over days",
             source=("DP-408", "Active Proxy Campaigns"),
             description="Own-fund proxy campaigns still open, by meeting type."),
        dict(name="Percent of Outstanding Voted", aggregation="non_additive",
             expr="vote_tally.percent_of_outstanding_voted of the latest tally_as_of_date of each proxy proposal, shown "
                  "with shares_voted_for and shares_voted_against of that tally",
             source=("DP-408", "Percent of Outstanding Voted"),
             description="How much of the fund's outstanding shares has voted on each proposal so far.",
             note="Read per proposal; never summed or averaged across proposals or tallies."),
        dict(name="Campaigns Below Quorum Near Meeting", aggregation="semi_additive",
             expr="count([Active Proxy Campaigns]) with campaign_meeting_date within 10 calendar days of the as-of date "
                  "whose latest vote_tally has quorum_achieved_indicator <> 'Y'; with shares still needed = "
                  "quorum_requirement x shares_outstanding_at_record_date - shares voted on that tally",
             time_rule="as-of date (latest in the selected range); never summed over days",
             source=("DP-408", "Campaigns Below Quorum Near Meeting"),
             description="Open campaigns that have not reached quorum with the meeting ten days away or less.",
             note="Shares still needed are read per campaign, never added across campaigns."),
        dict(name="Adjourned Meetings", aggregation="additive",
             expr="count(proxy_campaign) with adjourned_to_date in the period, by solicitation_agent",
             source=("DP-408", "Adjourned Meetings"),
             description="Shareholder meetings adjourned in the period, by proxy solicitation agent."),
        dict(name="Proposal Pass Rate %", aggregation="ratio",
             numerator="count(proxy_proposal) with proposal_outcome = 'Passed' decided in the period",
             denominator="count(proxy_proposal) decided in the period",
             source=("DP-408", "Proposal Pass Rate %"),
             description="Share of decided own-fund proposals that passed, by proposal type and vote standard.",
             note="A proposal is decided in the period of its campaign's meeting (or adjourned) date; the proposal carries "
                  "no decision date."),
        dict(name="Broker Non-Vote Share %", aggregation="ratio",
             numerator="sum(vote_tally.broker_non_votes) of the latest tally of each proposal",
             denominator="sum(shares_voted_for + shares_voted_against + broker_non_votes) of the same tallies",
             source=("DP-408", "Broker Non-Vote Share %"),
             description="Share of votes cast that are broker non-votes, with mirror or echo voted shares shown beside it."),
        dict(name="Intermediary Instructions Received", aggregation="additive",
             expr="sum(intermediary_vote_instruction.shares_instructed) and sum(instructions_received_count) by "
                  "voting_intermediary for each proposal; with the share where "
                  "instruction_discretionary_vote_permitted = 'Y'",
             source=("DP-408", "Intermediary Instructions Received"),
             description="Voting instructions and shares instructed by each intermediary for own-fund proposals.",
             note="Shares add within one proposal; across proposals read the instruction count."),
        dict(name="Pass-Through Materials Delivered On Time %", aggregation="ratio",
             numerator="count(issuer_pass_through) with materials_delivered_date at least 15 calendar days before "
                       "issuer_meeting_event.event_meeting_date",
             denominator="count(issuer_pass_through) of issuer meetings in the period",
             source=("DP-408", "Pass-Through Materials Delivered On Time %"),
             description="Share of client accounts that received issuer proxy materials on time, by delivery method."),
        dict(name="Pass-Through Instructions Transmitted Late", aggregation="additive",
             expr="count(issuer_pass_through) with voting_instruction_status = 'Received' whose "
                  "voting_instruction_transmitted_timestamp is empty, more than 1 business day after "
                  "voting_instruction_received_timestamp, or after event_meeting_date",
             source=("DP-408", "Pass-Through Instructions Transmitted Late"),
             description="Client voting instructions on issuer meetings passed on late or not at all."),
        dict(name="Pass-Through Entitlement Breaks", aggregation="additive",
             expr="count(issuer_pass_through) whose record_date_entitled_quantity differs from "
                  "record_date_client_holding.settled_quantity of the pass-through account in the event instrument on "
                  "the event record date (or has no holding row)",
             source=("DP-408", "Pass-Through Entitlement Breaks"),
             description="Client accounts whose voting entitlement does not match their settled holding on the record date.",
             note="Reads DP-408's record-date copy of 49 Client Holding; never 06."),
        dict(name="Own-Fund Record Date Share Breaks", aggregation="additive",
             expr="count(proxy_campaign) where abs(shares_outstanding_at_record_date - sum(register_position."
                  "registered_shares) of the fund's share classes on register_business_date = campaign_record_date) "
                  "exceeds 0.01% of shares_outstanding_at_record_date",
             source=("DP-408", "Own-Fund Record Date Share Breaks"),
             description="Own-fund campaigns whose record-date shares outstanding do not agree with the share register.",
             note="The one test that adds the whole register across every Register Account Category: a share-count proof "
                  "against shares outstanding, published only as a break count. Reads DP-580's register, not DP-408's copy."),
        dict(name="NOBO Election Rate %", aggregation="ratio",
             numerator="count(distinct disclosure_election_account) with an election in force at the as-of date and "
                       "beneficial_owner_disclosure_status = 'NOBO'",
             denominator="count(distinct disclosure_election_account) with an election in force at the as-of date",
             source=("DP-408", "NOBO Election Rate %"),
             description="Share of brokerage accounts that allow their name to be disclosed to issuers, with the share "
                         "set by default.",
             note="In force: disclosure_election_effective_from on or before the as-of date and effective_to empty or after it."),
        dict(name="Active Voting Choice Elections", aggregation="semi_additive",
             expr="count(voting_choice_election) in force at the as-of date (voting_choice_effective_from on or before "
                  "it, voting_choice_effective_to empty or after it), by voting_choice_fund and chosen_voting_policy; "
                  "with the share where voting_choice_default_applied = 'Y'",
             time_rule="as-of date (latest in the selected range); never summed over days",
             source=("DP-408", "Active Voting Choice Elections"),
             description="Voting choice elections in force, by fund and chosen voting policy."),
        dict(name="Voting Choice Coverage %", aggregation="ratio",
             numerator="count(distinct voting_choice_account) with an [Active Voting Choice Elections] row in the fund",
             denominator="count(distinct account) holding the fund on the as-of date: brokerage accounts from "
                         "record_date_client_holding (49) and registered accounts from register_position (29), each "
                         "account counted once",
             source=("DP-408", "Voting Choice Coverage %"),
             description="Share of the fund's holders that have made a voting choice election.",
             note="Holders are counted as accounts, never as shares or assets. DP-408's 49 copy is held at record dates, "
                  "so the brokerage holders are those of the latest record date (see open decisions)."),
    ],

    excluded=[],

    access=dict(
        classification="Confidential - Personal Data (DP-177, DP-178, DP-181, DP-580); Confidential - Financial "
                       "(DP-179); Confidential - Client (DP-408); Restricted - Legal (DP-180)",
        roles=[
            dict(role="aml_unit", rows="all rows of every table, including monitoring_alert and identity_verification",
                 columns="all", hidden=[]),
            dict(role="ta_operations",
                 rows="all orders, settlement, AP orders, control checks, register positions and postings; no "
                      "monitoring_alert or identity_verification rows",
                 columns="all except the Restricted - Legal and AML columns",
                 hidden=["alert_status", "alert_disposition", "escalation_case_reference", "pep_status",
                         "aml_risk_rating"]),
            dict(role="ta_management_backlog",
                 rows="monitoring_alert as counts and ages by category and priority only (de-identified backlog view)",
                 columns="Open Alert Backlog and Alerts Generated by category, priority and age",
                 hidden=["alert_status", "alert_disposition", "escalation_case_reference", "alert_account",
                         "alert_subject_party", "triggering_fund_order", "triggering_cash_movement", "alert_reviewer",
                         "second_reviewer", "pep_status", "aml_risk_rating", "matched_sanctions_list",
                         "verified_account", "verified_party", "verified_by"]),
            dict(role="proxy_operations",        # Head of Client Communications (DP-408 owner)
                 rows="DP-408 campaigns, tallies, instructions, pass-through and elections, with register_position at "
                      "campaign record dates",
                 columns="all on those tables, including the account keys the pass-through and election tests need",
                 hidden=["register_transaction_id", "posting_account", "governing_account_restriction"]),
            dict(role="etf_operations",
                 rows="ap_order, basket_line and the settlement obligations and exceptions with obligation_ap_order filled",
                 columns="all on those tables", hidden=[]),
            dict(role="fund_oversight",          # fund boards support, fund accounting, provider scorecard (DP-176), risk
                 rows="orders, settlement, AP orders, control checks, the share register and postings, and proxy "
                      "campaigns; no DP-180 rows",
                 columns="aggregates by route, intermediary, share class, register category and keeper, campaign, "
                         "processing provider and day; no account, payment or employee columns",
                 hidden=["order_account", "as_of_approver", "alert_account", "control_signed_off_by",
                         "control_exception_owner", "cash_movement_id", "fund_cash_account", "payment_amount",
                         "estimated_order_value", "obligation_amount", "shortfall_amount",
                         "register_account", "posting_account", "register_transaction_id", "last_register_transaction",
                         "governing_account_restriction", "pass_through_account", "disclosure_election_account",
                         "beneficial_owner_disclosure_status", "voting_choice_account", "voting_choice_election_id",
                         "client_holding_id", "holding_account"]),
        ]),

    verified_questions=[
        dict(question="How many orders arrived after the cut-off, and how many forward pricing breaks did each transfer "
                      "agent have last month, by dealing route?",
             answer="[Orders Received], [Orders After Cut-Off] and [Forward Pricing Breaks] from fund_order for "
                    "trade_date_assigned in last month, grouped by processing_provider.provider_name and "
                    "fund_order.dealing_route."),
        dict(question="Which intermediaries settled late most often over the last 90 days, and how much shortfall is open?",
             answer="[Late Payer Ranking] and [On-Time Settlement %] by intermediary.intermediary_name (settling party), "
                    "with [Open Settlement Exceptions] at today's date."),
        dict(question="How many ETF shares were created and redeemed this quarter by ETF, and how does that compare with "
                      "certified net flows?",
             answer="[Shares Created and Redeemed] and [Order Value at NAV] from ap_order (settled orders, NAV of record) "
                    "by share_class.share_class_name, beside [Net Flows] (SM-20 ref) from share_class_flows for the "
                    "same months. The two are shown side by side and never added or netted."),
        dict(question="How large and how old is the open AML and fraud alert backlog?",
             answer="[Open Alert Backlog] at today's date by monitoring_alert.monitoring_alert_category and "
                    "alert_priority, in age buckets; the TA management role sees it de-identified."),
        dict(question="Did every active share class get its capital stock proof every business day last month, did "
                      "the proofs use the NAV of record, and did the register roll forward from its postings?",
             answer="[Control Coverage %] for ta_control_type = capital stock proof, [Capital Stock Proof Difference] "
                    "and [Proofs Not Against NAV of Record], by fund.fund_name and processing_provider.provider_name, "
                    "with [Register Roll-Forward Breaks] by register_position.register_account_category and "
                    "register_keeper for the same business dates."),
        dict(question="Which own-fund proxy campaigns are short of quorum with the meeting less than ten days away, and "
                      "does each campaign's record-date share count agree with the register?",
             answer="[Campaigns Below Quorum Near Meeting] and [Percent of Outstanding Voted] (latest tally per proposal) "
                    "by proxy_campaign.proxy_campaign_id and fund.fund_name at today's date, with [Own-Fund Record Date "
                    "Share Breaks] for the same campaigns."),
    ],

    cannot_answer=[
        dict(question="Forward pricing breaks measured against each intermediary's own cut-off or designated-agent status",
             why="Dealing Terms hold one fund cut-off; intermediary cut-offs and the designated-agent flag are not modeled.",
             gap="GAP-29-001"),
        dict(question="How many DP-085 fraud signals became alerts?",
             why="An Account Monitoring Alert has no link to the pattern flag or maintenance event that prompted it.",
             gap="GAP-29-002"),
        dict(question="What did late payment by intermediaries cost the funds?",
             why="There is no interest claim or late-payment charge attribute.",
             gap="GAP-29-004"),
        dict(question="Were AP orders accepted after the AP cut-off?",
             why="The AP order cut-off time is not an attribute; the cut-off result is read as delivered.",
             gap="GAP-29-005"),
        dict(question="Orders, cut-off breaks and settlement by distribution channel",
             why="A fund order carries no distribution channel; the resolved dealer's channel is the nearest proxy.",
             gap="GAP-29-007"),
        dict(question="Failed basket deliveries by constituent instrument, issuer or asset class",
             why="Basket Constituent is a degenerate key into DP-131; the spec reads no 24 basket attribute, so DP-097 "
                 "Instrument cannot be reached. No gap is registered; it is a logical model gap.",
             gap=""),
    ],

    open_decisions=[
        "Re-point at W4 (CW-021, CW-902): DP-001 Party no longer carries Distribution Channel (Distributor Firm moved to "
        "05), so resolved_dealer drops dealer_channel. DP-093 carries no dealer channel either (Program Enrollment names "
        "the client's service offering, not the dealer's channel), so orders cannot be grouped by dealer channel until the "
        "05 distributor profile is published at W4.",
        "Fund order versions: the DP-177 spec grain names an order version, but no input carries a version number, so "
        "fund_order holds the current version of each order (logical model gap). Adding an order version attribute "
        "would let the model pin the version as processed.",
        "Batch-only routes: rows received only at the Order Interface Session or settlement batch grain have no "
        "per-order cut-off, STP or obligation-level measures (spec notes, 29 SME questions 2 and 11). The model "
        "counts their orders from interface_session and does not add them to Orders Received; confirm with the Head "
        "of Transfer Agency whether a combined order count is wanted.",
        "settlement_batch pins Batch Data Basis = 'Final' so an estimated and a final batch of the same day do not "
        "double count; the value list for Batch Data Basis should be confirmed with the DP-178 owner.",
        "Alerts on High-Risk Parties reads the current KYC profile folded into DP-180's Party, while the spec asks for "
        "the profile at Alert Generated Timestamp; an effective-dated KYC history from DP-077 is needed for the "
        "point-in-time test.",
        "Exception Resolution Time is defined by both DP-177 (order exceptions, hours) and DP-181 (control exceptions, "
        "business days) under the same name; the model publishes them as Order Exception Resolution Time and Control "
        "Exception Resolution Time. The product owners may wish to rename the spec measures to match.",
        "DP-177 Orders Received and DP-179 AP Orders and Creation Units each define a count and a sum; the model splits "
        "each into two metrics (Orders Received and Estimated Order Value; AP Orders and Creation Units Ordered). "
        "DP-178 Obligations Due likewise becomes Obligations Due and Obligation Amount Due, DP-180 Identity "
        "Verifications and Pass Rate becomes Identity Verifications and Identity Verification Pass Rate %, and Alerts Generated's rate per 1,000 open "
        "accounts is its own ratio.",
        "W3-W4 (29, CW-088, CW-141): the cip_verification table, its four joins and the CIP metrics are replaced by "
        "identity_verification (02 Identity Verification) joined from account.opening_identity_verification, with the "
        "DP-180 measures renamed (Identity Verifications, Accounts Opened Without Verification, Verification Turnaround); "
        "verified-by, regime, exemption reason and customer notice are not on the 02 object. Resulting Transaction and AP "
        "Resulting Transaction are 29 Register Transaction keys; Investor Bank Instruction is replaced by the 50 Client "
        "Money Movement key; Obligation Amount lineage is 29. share_class_flows reads DP-008 by Dimension Type and "
        "Dimension Key.",
        "Capital stock proof ownership (29 SME question 6): the model publishes the proof from DP-181 as a TA control; "
        "if fund accounting also runs one, DP-168 should reference these results rather than define a second proof.",
        "WP2 (CW-203, CW-209, CW-220): Net Flows, Gross Sales and Redemptions are re-pointed from the retired SM-01 to "
        "SM-20 (same names; share_class_flows still reads DP-008 Share Class rows, now the client-asset and own-fund "
        "flow book). The model publishes DP-580 (register_position, register_transaction; 13 metrics) and DP-408 (eight "
        "tables; 14 metrics). DP-580's Fund Order and Settlement Obligation are the same 29 records as DP-177's "
        "fund_order and DP-178's settlement_obligation and are not read twice; DP-177 and DP-178 should read them "
        "'from DP-580' at their re-spec. The servicing error key now points at DP-409 (DP-043 retired); representative "
        "analysis is no longer attributed to the retired SM-02.",
        "DP-580 book rule: no metric adds Register Account Categories, except Own-Fund Record Date Share Breaks, which "
        "proves the whole register against record-date shares outstanding and is published only as a break count. The "
        "register publishes shares only; valuing Fund-Only Registered Shares as client assets is SM-20's (DP-008 via "
        "DP-007), never this model's. Firm Proprietary rows appear only in Registered Shares.",
        "DP-580 Price Applied Differs From NAV joins Applied NAV Record to the NAV of record (SM-11) table; a posting "
        "priced from a superseded NAV version finds no row. Confirm with the DP-580 owner whether such postings count as "
        "breaks or are listed separately.",
        "DP-408 gaps: Vote Tally and Intermediary Vote Instruction carry no Proxy Proposal key in the taxonomy (the "
        "proposal is taken from the row key, spec note); Proxy Proposal carries no decision date, so Proposal Pass Rate % "
        "dates a proposal by its campaign's meeting; DP-408's 49 Client Holding copy is held at record dates, so Voting "
        "Choice Coverage % counts brokerage holders of the latest record date rather than the as-of date. Coverage "
        "counts registered holders from register_position; whether omnibus and Firm Proprietary rows count as holders "
        "(the model counts accounts, not shares) needs the DP-408 owner. DP-408's copy of the 29 register is not read; "
        "register_position (DP-580) is the book.",
        "PII on Estimated Order Value, Obligation Amount, Shortfall Amount and Payment Amount: the logical models tag "
        "them personal data at account level; the fund_oversight role sees the metrics aggregated by route, "
        "intermediary and share class but not the columns. Confirm with the data protection officer.",
    ],
)
