"""SM-15 People & Workplace: workforce, pay and benefits, deferred awards and clawback, talent and training, diversity and pay
equity, real estate, workplace services and travel and expense. Owns the certified headcount, FTE and compensation paid
(CD-341, CD-347) and publishes DP-192's Employee as the firm's employee dimension. See CONTRACT.md."""

# DP-192 is SCD type 2: a worker, assignment, position or reporting line has one version effective on any date.
_AT_DATE = "the version effective on the selected period end (or as-of) date"
# CD-341, as ruled 2026-10-14: every employed status counts; contingent workers are reported separately.
_EMPLOYED = "employment_status in ('Active', 'Leave of Absence', 'Notice Period', 'Garden Leave')"
_HEADCOUNT_FILTER = _EMPLOYED + " and contingent_worker_type is null"
_LAST = "last period end (or as-of date) in the selected range; never summed over periods"

# Column groups hidden by role (access below).
NAMES = ["employee_name", "line_manager_name"]
EMPLOYEE_DETAIL = ["hire_date", "termination_date", "job_title", "country_of_residence",
                   "secondment_home_entity", "engagement_end_date"]
WORK_AUTHORIZATION = ["work_authorization_type", "work_authorization_expiry_date"]
PAY = ["gross_pay_amount", "net_pay_amount", "employer_social_charges_amount", "payroll_currency", "pay_component",
       "pay_component_amount", "pay_currency", "pay_amount_basis", "pay_change_reason", "award_amount", "award_currency",
       "variable_award_type", "deferred_portion_percentage", "award_instrument",
       "net_payable_amount", "coverage_level", "enrollment_event"]
DEFERRED_AWARDS = ["tranche_amount", "malus_clawback_status", "malus_clawback_adjustment_amount"]
TALENT = ["proposed_rating", "calibrated_rating", "conduct_adjustment", "objective_achievement_rating",
          "successor_readiness", "emergency_successor"]
RESTRICTED_HR = ["leave_type", "background_screening_result", "screening_finding_severity", "hs_incident_type",
                 "injury_outcome", "days_away_from_work"]
CLAIMANT = ["merchant_name", "card_issuer", "travel_class", "booking_agency"]
LANDLORD = ["lease_counterparty"]

MODEL = dict(
    id="SM-15",
    status="Draft",
    description=(
        "Headcount, FTE, workforce movement, pay, benefits, deferred awards and clawback, training and performance, "
        "diversity and pay equity aggregates, real estate and occupancy, workplace services and travel and expense, for "
        "HR and people analytics, Reward and payroll, the remuneration committee secretariat, facilities and real estate, "
        "health and safety and the Finance Controller. It answers questions across employees, org units, legal "
        "entities, sites and periods; questions about one employee stay in the HR systems. It owns the certified "
        "Certified Headcount, Certified FTE and Gross Pay Paid, and publishes the firm's employee dimension from DP-192."),
    questions=[
        "What are certified headcount and FTE by legal entity, org unit, work location and employment type, against "
        "authorized FTE, and how many contingent workers sit beside them?",
        "How fast are we hiring and losing people: hires, leavers, turnover, internal mobility and time to fill by org "
        "unit and job level?",
        "How much did we pay through payroll by legal entity and run type, and does every run tie to its journals?",
        "How much variable pay is deferred, unvested, reduced by malus or still under clawback, by entity and vesting year?",
        "Is mandatory training completed on time, and do key-person positions have ready successors?",
        "How much space, rent, energy and emissions does each site carry per head, and where are T&E policy breaches "
        "concentrated?",
    ],

    tables=[
        # =============================================================================================================
        # DP-192 Employee & Position Master: the firm's employee dimension and the certified headcount and FTE
        # =============================================================================================================
        dict(name="employee", product="DP-192", entity="Employee", kind="Dimension",
             default_filter=f"Worker: {_AT_DATE} (latest version when no date is selected)",
             dimensions=[dict(name="employee_id", attr="Employee ID",
                              note="Pseudonymized for every role but HR; the key all other models join to"),
                         dict(name="employee_name", attr="Preferred Name", note="HR roles only"),
                         dict(name="job_title", attr="Job Title"),
                         dict(name="job_family", attr="Job Family"),
                         dict(name="employing_legal_entity", attr="Employing Legal Entity"),
                         dict(name="home_org_unit", attr="Home Org Unit"),
                         dict(name="work_location", attr="Work Location"),
                         dict(name="employment_type", attr="Employment Type"),
                         dict(name="employment_status", attr="Employment Status"),
                         dict(name="hire_date", attr="Hire Date"),
                         dict(name="termination_date", attr="Termination Date"),
                         dict(name="contingent_worker_type", attr="Contingent Worker Type",
                              note="Blank for employees; populated contingent workers are outside Certified Headcount"),
                         dict(name="engagement_end_date", attr="Engagement End Date"),
                         dict(name="secondment_home_entity", attr="Secondment Home Entity"),
                         dict(name="country_of_residence", attr="Country of Residence",
                              note="Restricted - Personal Data extension (CD-344)"),
                         dict(name="work_authorization_type", attr="Work Authorization Type",
                              note="Restricted - Personal Data extension (CD-344)"),
                         dict(name="work_authorization_expiry_date", attr="Work Authorization Expiry Date",
                              note="Restricted - Personal Data extension (CD-344)")],
             hidden=[("HR Employee Number", "A second personal identifier; Employee ID is the join key."),
                     ("Legal First Name", "Legal name; Preferred Name serves the HR roles."),
                     ("Legal Last Name", "Legal name; Preferred Name serves the HR roles."),
                     ("Business Email Address", "Contact detail; no cross-row question needs it."),
                     ("Business Phone Number", "Contact detail; no cross-row question needs it."),
                     ("National Identifier Type", "Payroll and registration only (restricted extension); never in the "
                                                  "semantic layer."),
                     ("National Identifier", "Payroll and registration only (restricted extension); never in the "
                                             "semantic layer."),
                     ("Supplier Agency", "A key to the 02 agency party, carried as a key only (DP-192 must not "
                                         "depend on DP-210)."),
                     ("Supplier Contract Reference", "A key to the 39 contract, carried as a key only."),
                     ("Engagement Start Date", "No cross-row question needs it; Engagement End Date drives the control.")]),
        dict(name="job_assignment", product="DP-192", entity="Employee Job Assignment", kind="Bridge",
             grain="worker x primary assignment x effective period",
             always_filter=["assignment_type = 'Primary'"],   # one primary assignment per worker on a date keeps joins many-to-one
             default_filter=f"Assignment: {_AT_DATE}",
             dimensions=[dict(name="working_pattern", attr="Working Pattern"),
                         dict(name="assignment_effective_from", attr="Assignment Effective From"),
                         dict(name="assignment_effective_to", attr="Assignment Effective To")],
             facts=[dict(name="assignment_fte", attr="Assignment FTE")],
             hidden=[("Assignment Type", "Pinned to Primary in always_filter: Certified FTE counts primary assignments only.")]),
        dict(name="job_profile", product="DP-192", entity="Job Profile", kind="Dimension",
             dimensions=[dict(name="job_profile_name", attr="Job Profile Name"),
                         dict(name="job_profile_family", attr="Job Profile Family"),
                         dict(name="job_level", attr="Job Level"),
                         dict(name="eeo1_job_category", attr="EEO-1 Job Category"),
                         dict(name="flsa_status", attr="FLSA Status"),
                         dict(name="regulated_role_category", attr="Regulated Role Category")]),
        dict(name="workforce_position", product="DP-192", entity="Workforce Position", kind="Dimension",
             default_filter=f"Position: {_AT_DATE}",
             dimensions=[dict(name="position_id", attr="Workforce Position ID"),
                         dict(name="position_status", attr="Position Status"),
                         dict(name="key_person_risk", attr="Key-Person Risk Indicator"),
                         dict(name="position_cost_center", attr="Position Cost Center"),
                         dict(name="position_org_unit", attr="Position Org Unit"),
                         dict(name="position_legal_entity", attr="Position Legal Entity"),
                         dict(name="position_effective_from", attr="Position Effective From"),
                         dict(name="position_effective_to", attr="Position Effective To")],
             facts=[dict(name="authorized_fte", attr="Authorized FTE")],
             hidden=[("Budget Plan Line", "A key to the 19 Financial Plan Line; planned FTE is SM-14's.")]),
        dict(name="reporting_line", product="DP-192", entity="Employee Reporting Line", kind="Bridge",
             grain="reporting employee x solid-line manager x effective period",
             always_filter=["reporting_line_type = 'Solid-Line Manager'"],   # dotted lines would double count a team
             default_filter=f"Reporting line: {_AT_DATE}",
             dimensions=[dict(name="reporting_effective_from", attr="Reporting Effective From"),
                         dict(name="reporting_effective_to", attr="Reporting Effective To")],
             hidden=[("Reporting Line Type", "Pinned to Solid-Line Manager in always_filter.")]),
        # A second Employee table, role-played as the line manager (names for HR and line managers only).
        dict(name="line_manager", product="DP-192", entity="Employee", kind="Dimension",
             default_filter=f"Worker: {_AT_DATE}",
             dimensions=[dict(name="line_manager_id", attr="Employee ID"),
                         dict(name="line_manager_name", attr="Preferred Name")]),
        dict(name="lifecycle_event", product="DP-192", entity="Employee Lifecycle Event", kind="Fact",
             grain="lifecycle event (hire, rehire, conversion, transfer, promotion, job change, leave, termination)",
             dimensions=[dict(name="lifecycle_event_type", attr="Lifecycle Event Type"),
                         dict(name="event_effective_date", attr="Event Effective Date"),
                         dict(name="event_fiscal_period", attr="Fiscal Period Key"),
                         dict(name="termination_reason", attr="Termination Reason"),
                         dict(name="voluntary_termination", attr="Voluntary Termination Indicator"),
                         dict(name="regulatory_notification_required", attr="Regulatory Notification Required Indicator"),
                         dict(name="notice_period_end_date", attr="Notice Period End Date")],
             hidden=[("Related Reorganization", "A key to the 09 Reorganization Event, read by DP-009.")]),

        # =============================================================================================================
        # DP-197 Workforce Movement, Hiring & Screening (event-level children; rates recomputed, never summed)
        # =============================================================================================================
        dict(name="leave_of_absence", product="DP-197", entity="Fact Leave of Absence", kind="Fact",
             grain="employee x leave type x leave period",
             dimensions=[dict(name="leave_type", attr="Leave Type",
                              note="Medical Leave and Long-Term Disability values visible in the restricted HR view only"),
                         dict(name="leave_start_date", attr="Leave Start Date"),
                         dict(name="expected_return_date", attr="Expected Return Date"),
                         dict(name="actual_return_date", attr="Actual Return Date"),
                         dict(name="job_protected_leave", attr="Job-Protected Leave Indicator")]),
        dict(name="job_requisition", product="DP-197", entity="Fact Job Requisition", kind="Fact",
             grain="job requisition",
             dimensions=[dict(name="requisition_id", attr="Job Requisition ID"),
                         dict(name="requisition_reason", attr="Requisition Reason"),
                         dict(name="requisition_status", attr="Requisition Status"),
                         dict(name="requisition_opened_date", attr="Requisition Opened Date"),
                         dict(name="requisition_filled_date", attr="Requisition Filled Date")],
             hidden=[("Hiring Manager", "A named employee; joined to employee for HR roles only when needed.")]),
        dict(name="candidate_application", product="DP-197", entity="Fact Candidate Application", kind="Fact",
             grain="candidate x job requisition",
             dimensions=[dict(name="candidate_source", attr="Candidate Source"),
                         dict(name="application_stage", attr="Application Stage"),
                         dict(name="candidate_retention_end_date", attr="Candidate Data Retention End Date")],
             hidden=[("Candidate Application ID", "Counted, never shown."),
                     ("Candidate ID", "A candidate is a private individual; counted, never shown."),
                     ("Internal Candidate Employee", "Join key to employee for Internal Fill Rate %; not shown."),
                     ("Hired As Employee", "Join key to employee for hires; not shown.")]),
        dict(name="background_screening", product="DP-197", entity="Fact Background Screening", kind="Fact",
             grain="employee or candidate application x screening type x screening completed date",
             dimensions=[dict(name="screening_type", attr="Screening Type"),
                         dict(name="screening_completed_date", attr="Screening Completed Date"),
                         dict(name="background_screening_result", attr="Background Screening Result",
                              note="Criminal record data (FCRA and state law limits): restricted HR view only"),
                         dict(name="screening_finding_severity", attr="Screening Finding Severity",
                              note="Restricted HR view only")],
             hidden=[("Screening Vendor", "A key to the 02 vendor party, carried as a key."),
                     ("Related Individual Registration", "A key to 08; registration filing stays DP-039's.")]),

        # =============================================================================================================
        # DP-198 Pay, Payroll & Benefits (Confidential - Compensation)
        # =============================================================================================================
        dict(name="payroll_result", product="DP-198", entity="Fact Payroll Result", kind="Fact",
             grain="employee x payroll run",
             dimensions=[dict(name="payroll_currency", attr="Payroll Currency")],
             facts=[dict(name="gross_pay_amount", attr="Gross Pay Amount"),
                    dict(name="net_pay_amount", attr="Net Pay Amount"),
                    dict(name="employer_social_charges_amount", attr="Employer Social Charges Amount")],
             hidden=[("Income Tax Withheld Amount", "Employee tax; no cross-row question in this model needs it."),
                     ("Employee Social Security Amount", "Employee deduction; no cross-row question needs it."),
                     ("Incentive Payout Statements", "Keys to compensation statements; used only inside Incentive "
                                                     "Statements Unpaid.")]),
        dict(name="payroll_run", product="DP-198", entity="Fact Payroll Run", kind="Dimension",
             dimensions=[dict(name="payroll_run_id", attr="Payroll Run Identifier"),
                         dict(name="payroll_run_legal_entity", attr="Payroll Run Legal Entity"),
                         dict(name="payroll_run_type", attr="Payroll Run Type"),
                         dict(name="pay_period_start_date", attr="Pay Period Start Date"),
                         dict(name="pay_period_end_date", attr="Pay Period End Date"),
                         dict(name="pay_date", attr="Pay Date"),
                         dict(name="payroll_provider", attr="Payroll Provider"),
                         dict(name="payroll_run_status", attr="Payroll Run Status")],
             hidden=[("Payroll Journal Entries", "A list of journal keys; the run-to-journal tie-out reads gl_posting "
                                                 "by Source Payroll Run.")]),
        dict(name="base_pay", product="DP-198", entity="Fact Base Pay Record", kind="Fact",
             grain="employee x pay component x effective period",
             default_filter=f"Base pay record: {_AT_DATE}",
             dimensions=[dict(name="pay_component", attr="Pay Component"),
                         dict(name="pay_currency", attr="Pay Currency"),
                         dict(name="pay_amount_basis", attr="Pay Amount Basis"),
                         dict(name="pay_change_reason", attr="Pay Change Reason"),
                         dict(name="pay_effective_from", attr="Pay Effective From"),
                         dict(name="pay_effective_to", attr="Pay Effective To")],
             facts=[dict(name="pay_component_amount", attr="Pay Component Amount")]),
        # Read from DP-199's conformed copy, which adds Linked Fund to DP-198's award (Carried Interest Points left with
        # 30 at W4, CW-930).
        dict(name="variable_award", product="DP-199", entity="Variable Compensation Award", kind="Fact",
             grain="variable compensation award",
             dimensions=[dict(name="variable_award_type", attr="Variable Award Type"),
                         dict(name="performance_year", attr="Performance Year"),
                         dict(name="award_currency", attr="Award Currency"),
                         dict(name="award_instrument", attr="Award Instrument"),
                         dict(name="award_grant_date", attr="Award Grant Date"),
                         dict(name="remco_approval_date", attr="Remuneration Committee Approval Date"),
                         dict(name="linked_fund", attr="Linked Fund", note="The fund-linked part of an instrument award")],
             facts=[dict(name="award_amount", attr="Award Amount"),
                    dict(name="deferred_portion_percentage", attr="Deferred Portion Percentage")],
             hidden=[("Variable Compensation Award ID", "Counted, never shown.")]),
        dict(name="benefit_enrollment", product="DP-198", entity="Fact Benefit Enrollment", kind="Fact",
             grain="employee x benefit plan x coverage period",
             dimensions=[dict(name="coverage_level", attr="Coverage Level"),
                         dict(name="enrollment_event", attr="Enrollment Event"),
                         dict(name="coverage_start_date", attr="Coverage Start Date"),
                         dict(name="coverage_end_date", attr="Coverage End Date")],
             hidden=[("Own Plan Membership", "A key to the firm's own 401(k) membership (DP-094); not read here.")]),
        dict(name="benefit_plan", product="DP-198", entity="Benefit Plan", kind="Dimension",
             dimensions=[dict(name="benefit_plan_name", attr="Benefit Plan Name"),
                         dict(name="benefit_plan_year", attr="Benefit Plan Year"),
                         dict(name="benefit_type", attr="Benefit Type"),
                         dict(name="offering_legal_entity", attr="Offering Legal Entity"),
                         dict(name="benefit_provider", attr="Benefit Provider"),
                         dict(name="firm_recordkept_plan", attr="Firm-Recordkept Plan Indicator"),
                         dict(name="benefit_plan_status", attr="Benefit Plan Status")]),
        # W4 (CW-907, CW-062): 03 Compensation Statement (CPS-), absorbed from 07; 07 Payroll Payment Instruction dropped
        # (payment is the 20 Payroll Result), so paid versus earned per statement is not measurable (taxonomy gap).
        dict(name="compensation_statement", product="DP-198", entity="Fact Compensation Statement", kind="Fact",
             grain="advisor x compensation period statement (CPS-)",
             dimensions=[dict(name="statement_id", attr="Statement ID"),
                         dict(name="statement_period_end", attr="Statement Period End"),
                         dict(name="statement_status", attr="Statement Status"),
                         dict(name="statement_issued_date", attr="Statement Issued Date")],
             facts=[dict(name="net_payable_amount", attr="Net Payable Amount",
                         note="The 03 statement's number, read only to test payment through payroll; never restated")],
             hidden=[("Total Earned", "Incentive earned is the 03 statement's (CD-347); published by SM-29 from DP-390 "
                                      "(Incentive Earned by Component; DP-033 superseded, CW-207)."),
                     ("Payroll Result Reference", "A key to the paying 20 Payroll Result; used only inside Incentive "
                                                  "Statements Unpaid.")]),
        # DP-191 is the certified source of compensation expense; its postings are read only to tie runs to journals.
        dict(name="gl_posting", product="DP-191", entity="GL Posting", kind="Fact",
             grain="journal entry x journal line",
             always_filter=["journal_id in (select journal_id from journal_entry where journal_status = 'Posted')"],
             dimensions=[dict(name="debit_credit_indicator", attr="Debit Credit Indicator"),
                         dict(name="source_payroll_run", attr="Source Payroll Run"),
                         dict(name="posted_account", attr="Posted Account")],
             facts=[dict(name="posted_amount", attr="Posted Amount")]),
        dict(name="journal_entry", product="DP-191", entity="Journal Entry", kind="Dimension",
             dimensions=[dict(name="journal_source", attr="Journal Source"),
                         dict(name="journal_status", attr="Journal Status"),
                         dict(name="posting_accounting_period", attr="Posting Accounting Period"),
                         dict(name="posting_legal_entity", attr="Posting Legal Entity")],
             hidden=[("Journal Prepared By", "A named employee; journal controls are SM-14's."),
                     ("Journal Approved By", "A named employee; journal controls are SM-14's.")]),

        # =============================================================================================================
        # DP-199 Deferred Awards & Clawback (Confidential - Compensation)
        # =============================================================================================================
        dict(name="deferred_tranche", product="DP-199", entity="Fact Deferred Award Tranche", kind="Fact",
             grain="variable compensation award x vesting tranche",
             dimensions=[dict(name="tranche_number", attr="Tranche Number"),
                         dict(name="vesting_basis", attr="Vesting Basis"),
                         dict(name="vesting_date", attr="Vesting Date"),
                         dict(name="tranche_vesting_status", attr="Tranche Vesting Status"),
                         dict(name="malus_clawback_status", attr="Malus / Clawback Status"),
                         dict(name="clawback_period_end_date", attr="Clawback Period End Date")],
             facts=[dict(name="tranche_amount", attr="Tranche Amount"),
                    dict(name="malus_clawback_adjustment_amount", attr="Malus / Clawback Adjustment Amount")]),
        # =============================================================================================================
        # DP-200 Talent, Training & Succession
        # =============================================================================================================
        dict(name="learning_completion", product="DP-200", entity="Fact Learning Completion", kind="Fact",
             grain="employee x learning item x assignment due date",
             dimensions=[dict(name="completion_due_date", attr="Completion Due Date"),
                         dict(name="completion_status", attr="Completion Status"),
                         dict(name="completion_date", attr="Completion Date")],
             hidden=[("Assessment Score", "An individual's test score; no cross-row question needs it.")]),
        dict(name="learning_item", product="DP-200", entity="Learning Item", kind="Dimension",
             dimensions=[dict(name="learning_item_title", attr="Learning Item Title"),
                         dict(name="learning_item_type", attr="Learning Item Type"),
                         dict(name="regulatory_credit_type", attr="Regulatory Credit Type"),
                         dict(name="learning_item_status", attr="Learning Item Status")],
             hidden=[("Learning Provider", "A key to the 02 provider party, carried as a key.")]),
        dict(name="training_requirement", product="DP-200", entity="Mandatory Training Requirement", kind="Dimension",
             default_filter="Requirement effective on the due date",
             dimensions=[dict(name="training_requirement_name", attr="Training Requirement Name"),
                         dict(name="training_requirement_type", attr="Training Requirement Type"),
                         dict(name="requirement_regulator", attr="Requirement Regulator"),
                         dict(name="requirement_recurrence", attr="Requirement Recurrence"),
                         dict(name="requirement_effective_from", attr="Requirement Effective From"),
                         dict(name="requirement_effective_to", attr="Requirement Effective To")],
             hidden=[("Applicable Population Rule", "Free text evaluated outside the taxonomy (GAP-20-012); its "
                                                    "result is Population Coverage Gaps.")]),
        # The pre-aggregated talent fact is read only for the one measure that cannot be recomputed from detail rows.
        dict(name="talent_aggregate", product="DP-200", entity="Fact Talent Aggregate", kind="Fact",
             grain="org unit x employing legal entity x training requirement x fiscal period",
             always_filter=["Mandatory Training Requirement Key is not null (requirement rows only, not review-cycle rows)"],
             facts=[dict(name="population_coverage_gaps", attr="Population Coverage Gaps")]),
        dict(name="performance_review", product="DP-200", entity="Fact Performance Review", kind="Fact",
             grain="employee x review cycle x review type",
             dimensions=[dict(name="review_cycle", attr="Review Cycle"),
                         dict(name="review_type", attr="Review Type"),
                         dict(name="proposed_rating", attr="Proposed Rating"),
                         dict(name="calibrated_rating", attr="Calibrated Rating"),
                         dict(name="conduct_adjustment", attr="Conduct Adjustment Indicator"),
                         dict(name="review_status", attr="Review Status")],
             hidden=[("Reviewer", "A named employee; no cross-row question needs it.")]),
        dict(name="performance_objective", product="DP-200", entity="Fact Performance Objective", kind="Fact",
             grain="employee x review cycle x objective",
             dimensions=[dict(name="objective_review_cycle", attr="Objective Review Cycle"),
                         dict(name="objective_category", attr="Objective Category"),
                         dict(name="objective_achievement_rating", attr="Objective Achievement Rating")],
             facts=[dict(name="objective_weight", attr="Objective Weight")],
             hidden=[("Objective Title", "Free text about an individual's work; never shown."),
                     ("Linked Metric Definition", "A key to the 21 Metric Definition (DP-101), not joined here.")]),
        dict(name="succession_entry", product="DP-200", entity="Fact Succession Plan Entry", kind="Fact",
             grain="workforce position x successor employee",
             dimensions=[dict(name="successor_readiness", attr="Successor Readiness"),
                         dict(name="emergency_successor", attr="Emergency Successor Indicator"),
                         dict(name="succession_review_date", attr="Succession Review Date")]),
        dict(name="ce_requirement", product="DP-200", entity="Fact CE Requirement", kind="Fact",
             grain="registration x CE element x due date",
             dimensions=[dict(name="ce_element", attr="CE Element"),
                         dict(name="ce_due_date", attr="CE Due Date"),
                         dict(name="ce_status", attr="CE Status")]),
        dict(name="individual_registration", product="DP-200", entity="Individual Registration", kind="Dimension",
             dimensions=[dict(name="license_id", attr="License ID")],
             hidden=[("Registered Person", "Join key to employee; registrations themselves are DP-039's.")]),

        # =============================================================================================================
        # DP-201 Diversity, Inclusion & Pay Equity: aggregates only; no employee-level row is read (CD-344)
        # =============================================================================================================
        dict(name="hc_metric_value", product="DP-201", entity="Fact Human Capital Metric Value", kind="Fact",
             grain="metric definition x legal entity, org unit or country x breakdown x period end",
             always_filter=["published cells only: cells under the minimum size (10, or the jurisdiction's stricter "
                            "limit) are withheld by the product and never reach the model"],
             default_filter="metric_period_end_date = latest published period end",
             dimensions=[dict(name="metric_definition", attr="Metric Definition",
                              note="Pick one metric definition per query; values of different metrics never add"),
                         dict(name="metric_org_unit", attr="Metric Org Unit"),
                         dict(name="metric_legal_entity", attr="Metric Legal Entity"),
                         dict(name="metric_country", attr="Metric Country"),
                         dict(name="metric_breakdown", attr="Metric Breakdown"),
                         dict(name="metric_period_type", attr="Metric Period Type"),
                         dict(name="metric_period_end_date", attr="Metric Period End Date"),
                         dict(name="disclosure_classification", attr="Disclosure Classification")],
             facts=[dict(name="metric_value", attr="Metric Value")]),

        # =============================================================================================================
        # DP-207 Real Estate, Occupancy & Sustainability
        # =============================================================================================================
        dict(name="site_profile", product="DP-207", entity="Site Profile", kind="Dimension",
             default_filter=f"Site profile: {_AT_DATE}",
             dimensions=[dict(name="site_type", attr="Site Type"),
                         dict(name="tenure_type", attr="Tenure Type"),
                         dict(name="site_area_unit", attr="Site Area Unit"),
                         dict(name="building_certification", attr="Building Certification"),
                         dict(name="finra_branch_office", attr="FINRA Branch Office Indicator"),
                         dict(name="profile_effective_from", attr="Profile Effective From"),
                         dict(name="profile_effective_to", attr="Profile Effective To")],
             facts=[dict(name="site_gross_area", attr="Site Gross Area"),
                    dict(name="workstation_capacity", attr="Workstation Capacity")]),
        dict(name="building_space", product="DP-207", entity="Building Space", kind="Dimension",
             dimensions=[dict(name="space_id", attr="Space ID"),
                         dict(name="space_level", attr="Space Level"),
                         dict(name="space_type", attr="Space Type")],
             facts=[dict(name="space_area", attr="Space Area"),
                    dict(name="space_capacity", attr="Space Capacity")]),
        dict(name="space_assignment", product="DP-207", entity="Space Assignment", kind="Bridge",
             grain="building space x org unit x effective period",
             default_filter=f"Space assignment: {_AT_DATE}",
             dimensions=[dict(name="assigned_org_unit", attr="Assigned Org Unit"),
                         dict(name="chargeback_cost_center", attr="Chargeback Cost Center"),
                         dict(name="space_assignment_from", attr="Assignment Effective From"),
                         dict(name="space_assignment_to", attr="Assignment Effective To")]),
        dict(name="occupancy", product="DP-207", entity="Fact Occupancy Measurement", kind="Fact",
             grain="site (space blank) x measurement date",
             always_filter=["measured_space is null"],   # site-level rows only; space rows would double count attendance
             dimensions=[dict(name="occupancy_date", attr="Occupancy Measurement Date")],
             facts=[dict(name="attendance_count", attr="Attendance Count"),
                    dict(name="peak_occupancy_count", attr="Peak Occupancy Count"),
                    dict(name="utilization_percentage", attr="Utilization Percentage")]),
        dict(name="space_reservation", product="DP-207", entity="Fact Space Reservation", kind="Fact",
             grain="reserved space x reservation start (booker not read)",
             dimensions=[dict(name="reservation_start", attr="Reservation Start"),
                         dict(name="reservation_end", attr="Reservation End"),
                         dict(name="checked_in", attr="Checked In Indicator")]),
        dict(name="lease", product="DP-207", entity="Lease", kind="Dimension",
             dimensions=[dict(name="lease_id", attr="Lease ID"),
                         dict(name="lease_role", attr="Lease Role"),
                         dict(name="lease_counterparty", attr="Lease Counterparty",
                              note="Landlord party; can be an individual (personal data)"),
                         dict(name="firm_legal_entity", attr="Firm Legal Entity"),
                         dict(name="lease_commencement_date", attr="Lease Commencement Date"),
                         dict(name="lease_expiry_date", attr="Lease Expiry Date"),
                         dict(name="lease_currency", attr="Lease Currency"),
                         dict(name="lease_status", attr="Lease Status")],
             facts=[dict(name="rent_free_period_months", attr="Rent-Free Period Months")],
             hidden=[("Head Lease", "Sublease link; Sublease Income is a charge type on the payment schedule.")]),
        dict(name="leased_space", product="DP-207", entity="Leased Space", kind="Bridge",
             grain="lease x site x building space x effective period",
             default_filter=f"Leased space: {_AT_DATE}",
             facts=[dict(name="contractual_rentable_area", attr="Contractual Rentable Area")]),
        dict(name="lease_payment", product="DP-207", entity="Fact Lease Payment Schedule Line", kind="Fact",
             grain="lease x payment period x charge type",
             dimensions=[dict(name="lease_charge_type", attr="Lease Charge Type"),
                         dict(name="payment_period_start", attr="Payment Period Start"),
                         dict(name="payment_period_end", attr="Payment Period End"),
                         dict(name="escalation_basis", attr="Escalation Basis"),
                         dict(name="variable_payment", attr="Variable Payment Indicator")],
             facts=[dict(name="scheduled_payment_amount", attr="Scheduled Payment Amount")]),
        dict(name="lease_critical_date", product="DP-207", entity="Fact Lease Critical Date", kind="Fact",
             grain="lease x option type x option effective date",
             dimensions=[dict(name="lease_option_type", attr="Lease Option Type"),
                         dict(name="notice_deadline_date", attr="Notice Deadline Date"),
                         dict(name="option_effective_date", attr="Option Effective Date"),
                         dict(name="option_exercised", attr="Option Exercised Indicator"),
                         dict(name="exercise_decision_date", attr="Exercise Decision Date")],
             facts=[dict(name="option_penalty_amount", attr="Option Penalty Amount")]),
        # Lease measurements are versioned by measurement date: one version of record per lease, ledger and month end.
        dict(name="lease_measurement", product="DP-207", entity="Fact Lease Accounting Measurement", kind="Fact",
             grain="lease x ledger x month end (latest measurement on or before it)",
             always_filter=["lease_measurement_date = the latest Lease Measurement Date of the lease and ledger on or "
                            "before the selected month end",
                            "recognition_exemption = 'None'"],
             dimensions=[dict(name="lease_measurement_date", attr="Lease Measurement Date"),
                         dict(name="lease_classification", attr="Lease Classification"),
                         dict(name="recognition_exemption", attr="Recognition Exemption"),
                         dict(name="remeasurement_reason", attr="Remeasurement Reason")],
             facts=[dict(name="right_of_use_asset_amount", attr="Right-of-Use Asset Amount"),
                    dict(name="lease_liability_amount", attr="Lease Liability Amount")],
             hidden=[("Discount Rate", "An accounting input; lease accounting detail stays with the Controller."),
                     ("Assessed Lease Term Months", "An accounting input; Weighted Average Lease Term Remaining uses "
                                                    "the contractual expiry.")]),
        dict(name="gl_balance", product="DP-191", entity="GL Account Balance", kind="Fact",
             grain="ledger x GL account x segment combination x fiscal period (Actual)",
             always_filter=["balance_type = 'Actual'",
                            "balance_gl_account in the lease liability and right-of-use accounts the Controller "
                            "designates (outside the taxonomy, GAP-44-004)"],
             dimensions=[dict(name="balance_fiscal_period", attr="Balance Fiscal Period"),
                         dict(name="balance_currency", attr="Balance Currency")],
             facts=[dict(name="closing_balance", attr="Closing Balance")]),
        dict(name="utility_consumption", product="DP-207", entity="Fact Utility Consumption", kind="Fact",
             grain="site x meter x utility resource x consumption period",
             dimensions=[dict(name="utility_resource", attr="Utility Resource"),
                         dict(name="consumption_period_start", attr="Consumption Period Start"),
                         dict(name="consumption_period_end", attr="Consumption Period End"),
                         dict(name="consumption_unit", attr="Consumption Unit"),
                         dict(name="consumption_data_basis", attr="Consumption Data Basis")],
             facts=[dict(name="consumption_quantity", attr="Consumption Quantity"),
                    dict(name="renewable_share", attr="Renewable Share")]),
        # Two tables over one fact: entity totals and site rows would double count if mixed (Site-to-Entity Emission
        # Difference compares them).
        dict(name="emission_entity", product="DP-207", entity="Fact Operational Emission", kind="Fact",
             grain="reporting entity x reporting year x GHG scope category x calculation method (entity total)",
             always_filter=["emission_record_level = 'Entity Total'"],
             dimensions=[dict(name="reporting_year", attr="Reporting Year"),
                         dict(name="ghg_scope_category", attr="GHG Scope Category"),
                         dict(name="calculation_method", attr="Calculation Method",
                              note="Scope 2 location-based and market-based are shown side by side, never added"),
                         dict(name="emission_data_basis", attr="Emission Data Basis"),
                         dict(name="assurance_level", attr="Assurance Level")],
             facts=[dict(name="emissions_tco2e", attr="Emissions tCO2e")],
             hidden=[("Reported Indicator", "A key to the 34 indicator that copies these rows."),
                     ("Emission Factor Source", "Calculation detail; no cross-row question needs it."),
                     ("Emission Factor Version", "Calculation detail; no cross-row question needs it.")]),
        dict(name="emission_site", product="DP-207", entity="Fact Operational Emission", kind="Fact",
             grain="reporting entity x site x reporting year x GHG scope category x calculation method (site rows)",
             always_filter=["emission_record_level = 'Site'"],
             dimensions=[dict(name="site_reporting_year", attr="Reporting Year"),
                         dict(name="site_ghg_scope_category", attr="GHG Scope Category"),
                         dict(name="site_calculation_method", attr="Calculation Method")],
             facts=[dict(name="site_emissions_tco2e", attr="Emissions tCO2e"),
                    dict(name="activity_quantity", attr="Activity Quantity")],
             hidden=[("Activity Unit", "Shown only with activity_quantity in the product's own view.")]),

        # =============================================================================================================
        # DP-208 Workplace Services, Security & Health and Safety
        # =============================================================================================================
        dict(name="facility_asset", product="DP-208", entity="Facility Asset", kind="Dimension",
             dimensions=[dict(name="facility_asset_class", attr="Facility Asset Class"),
                         dict(name="facility_asset_status", attr="Facility Asset Status"),
                         dict(name="install_date", attr="Install Date")],
             hidden=[("Fixed Asset Number", "A key to the 19 fixed asset register."),
                     ("Asset Lease", "A key to the DP-207 lease; not joined.")]),
        dict(name="planned_maintenance", product="DP-208", entity="Fact Planned Maintenance", kind="Fact",
             grain="facility asset x maintenance task type",
             dimensions=[dict(name="maintenance_task_type", attr="Maintenance Task Type"),
                         dict(name="maintenance_frequency", attr="Maintenance Frequency"),
                         dict(name="statutory_requirement", attr="Statutory Requirement"),
                         dict(name="next_due_date", attr="Next Due Date")]),
        dict(name="work_order", product="DP-208", entity="Fact Facility Work Order", kind="Fact",
             grain="facility work order",
             dimensions=[dict(name="work_order_type", attr="Work Order Type"),
                         dict(name="work_order_priority", attr="Work Order Priority"),
                         dict(name="sla_completion_due", attr="SLA Completion Due Timestamp"),
                         dict(name="completed_timestamp", attr="Completed Timestamp"),
                         dict(name="work_order_status", attr="Work Order Status")],
             hidden=[("Vendor Invoice", "A key to the 19 invoice; supplier spend is SM-16's."),
                     ("Work Order Purchase Order", "A key to the 40 purchase order.")]),
        dict(name="access_badge", product="DP-208", entity="Fact Access Badge", kind="Fact",
             grain="access badge",
             dimensions=[dict(name="badge_type", attr="Badge Type"),
                         dict(name="badge_status", attr="Badge Status"),
                         dict(name="badge_expiry_date", attr="Badge Expiry Date")],
             hidden=[("Badge ID", "Counted, never shown."),
                     ("Badge Visit", "Join key to the visit for visitor badges.")]),
        dict(name="zone_grant", product="DP-208", entity="Fact Zone Grant", kind="Fact",
             grain="badge x site x access zone x space x effective period",
             default_filter=f"Grant: {_AT_DATE}",
             dimensions=[dict(name="access_zone", attr="Access Zone"),
                         dict(name="grant_effective_from", attr="Grant Effective From"),
                         dict(name="grant_effective_to", attr="Grant Effective To")],
             hidden=[("Grant Approver", "A named employee; used only inside Restricted Zone Grants Without Approver.")]),
        dict(name="visitor_registration", product="DP-208", entity="Fact Visitor Registration", kind="Fact",
             grain="visit",
             dimensions=[dict(name="visit_purpose", attr="Visit Purpose"),
                         dict(name="arrival_timestamp", attr="Arrival Timestamp"),
                         dict(name="departure_timestamp", attr="Departure Timestamp")],
             hidden=[("Visit Reference", "Counted, never shown."),
                     ("Visitor Party", "A known visitor is a 02 party (personal data); not shown."),
                     ("Host Employee", "Join key to employee for the host's org unit; the name is not shown.")]),
        dict(name="security_incident", product="DP-208", entity="Fact Physical Security Incident", kind="Fact",
             grain="physical security incident",
             dimensions=[dict(name="physical_incident_type", attr="Physical Incident Type"),
                         dict(name="security_incident_occurred", attr="Security Incident Occurred Timestamp"),
                         dict(name="security_incident_severity", attr="Security Incident Severity"),
                         dict(name="security_incident_status", attr="Security Incident Status")],
             hidden=[("Involved Badge", "Links an incident to a person's badge; not shown.")]),
        dict(name="hs_incident", product="DP-208", entity="Fact Health & Safety Incident", kind="Fact",
             grain="health and safety incident (restricted view)",
             dimensions=[dict(name="hs_incident_type", attr="H&S Incident Type"),
                         dict(name="injury_outcome", attr="Injury Outcome"),
                         dict(name="hs_incident_occurred", attr="H&S Incident Occurred Timestamp"),
                         dict(name="osha_recordable", attr="OSHA Recordable Indicator"),
                         dict(name="regulatory_report_date", attr="Regulatory Report Date")],
             facts=[dict(name="days_away_from_work", attr="Days Away From Work")],
             hidden=[("H&S Incident ID", "Counted, never shown."),
                     ("Affected Employee", "Health data about a named person (special category); never shown.")]),
        dict(name="risk_assessment", product="DP-208", entity="Fact Workplace Risk Assessment", kind="Fact",
             grain="workplace risk assessment",
             dimensions=[dict(name="risk_assessment_type", attr="Risk Assessment Type"),
                         dict(name="assessed_workstation", attr="Assessed Workstation"),
                         dict(name="assessment_date", attr="Assessment Date"),
                         dict(name="overall_risk_rating", attr="Overall Risk Rating"),
                         dict(name="next_review_date", attr="Next Review Date")]),
        dict(name="emergency_role", product="DP-208", entity="Fact Emergency Role Assignment", kind="Fact",
             grain="role holder x site x emergency role x effective period",
             default_filter=f"Emergency role: {_AT_DATE}",
             dimensions=[dict(name="emergency_role", attr="Emergency Role"),
                         dict(name="emergency_role_floor", attr="Emergency Role Floor"),
                         dict(name="emergency_role_from", attr="Emergency Role Effective From"),
                         dict(name="emergency_role_to", attr="Emergency Role Effective To")],
             hidden=[("Certifying Learning Completion", "Join key to the DP-200 learning completion.")]),

        # =============================================================================================================
        # DP-209 Travel & Expense (an operational measure reconciled to DP-191, not certified expense)
        # =============================================================================================================
        dict(name="expense_line", product="DP-209", entity="Fact Expense Line", kind="Fact",
             grain="expense report x line number",
             dimensions=[dict(name="expense_type", attr="Expense Type"),
                         dict(name="expense_date", attr="Expense Date"),
                         dict(name="merchant_name", attr="Merchant Name")],
             facts=[dict(name="transaction_amount", attr="Transaction Amount"),
                    dict(name="reimbursable_amount", attr="Reimbursable Amount")],
             hidden=[("Business Purpose", "Free text written by the claimant; tested for blanks only."),
                     ("External Attendees", "Names of people outside the firm (personal data); never shown."),
                     ("Related Gift / Entertainment Items", "Keys to 08 GNE- records; compliance facts stay DP-038's."),
                     ("Matched Card Transaction", "Join key to card_transaction.")]),
        dict(name="expense_report", product="DP-209", entity="Fact Expense Report", kind="Dimension",
             dimensions=[dict(name="expense_report_id", attr="Expense Report ID"),
                         dict(name="expense_approval_status", attr="Expense Approval Status"),
                         dict(name="cost_owner_org_unit", attr="Cost Owner Org Unit"),
                         dict(name="reimbursement_route", attr="Reimbursement Route"),
                         dict(name="reimbursement_status", attr="Reimbursement Status")],
             facts=[dict(name="expense_report_total_amount", attr="Expense Report Total Amount")],
             hidden=[("Report Purpose", "Free text written by the claimant."),
                     ("Expense Approver", "A named employee; used only inside Self-Approved or Off-Chain Reports."),
                     ("Reimbursement Payroll Result", "A key to the payroll result; pay amounts are not read (CD-344)."),
                     ("Reimbursement Supplier Payment", "A key to the 19 supplier payment, read in DP-209's own view."),
                     ("Posting Journal Entry", "Join key to journal_entry for the subledger tie-out.")]),
        dict(name="card_transaction", product="DP-209", entity="Fact Card Transaction", kind="Fact",
             grain="card x issuer transaction",
             dimensions=[dict(name="card_posting_date", attr="Card Posting Date"),
                         dict(name="merchant_category_code", attr="Merchant Category Code"),
                         dict(name="personal_spend", attr="Personal Spend Indicator")],
             facts=[dict(name="billed_amount", attr="Billed Amount")],
             hidden=[("Issuer Transaction Reference", "Counted, never shown.")]),
        dict(name="corporate_card", product="DP-209", entity="Corporate Card", kind="Dimension",
             dimensions=[dict(name="card_status", attr="Card Status"),
                         dict(name="card_issuer", attr="Card Issuer"),
                         dict(name="card_billing_entity", attr="Card Billing Entity")],
             hidden=[("Card Account ID", "A payment card account number; never shown."),
                     ("Card Credit Limit", "An individual's credit limit; no cross-row question needs it.")]),
        dict(name="travel_booking", product="DP-209", entity="Fact Travel Booking", kind="Fact",
             grain="trip",
             dimensions=[dict(name="trip_start_date", attr="Trip Start Date"),
                         dict(name="trip_end_date", attr="Trip End Date"),
                         dict(name="travel_class", attr="Travel Class"),
                         dict(name="booking_agency", attr="Booking Agency")],
             facts=[dict(name="air_distance", attr="Air Distance")],
             hidden=[("Destination Countries", "A list (many-to-many); shown in DP-209's own view to avoid double "
                                               "counting trips across countries.")]),
        dict(name="expense_policy_limit", product="DP-209", entity="Expense Policy Limit", kind="Dimension",
             default_filter="Limit effective on the Expense Date",
             dimensions=[dict(name="limited_expense_type", attr="Limited Expense Type"),
                         dict(name="location_band", attr="Location Band"),
                         dict(name="applicable_job_level", attr="Applicable Job Level"),
                         dict(name="governing_policy", attr="Governing Policy")],
             facts=[dict(name="limit_amount", attr="Limit Amount"),
                    dict(name="per_diem_rate", attr="Per Diem Rate")]),
    ],

    shared=[
        "DP-013/Org Unit", "DP-013/Internal Legal Entity", "DP-013/Office Location", "DP-013/Fiscal Period",
        "DP-013/Calendar Date", "DP-013/Currency", "DP-013/Country", "DP-013/Unit of Measure",
        "DP-190/GL Account", "DP-190/Cost Center", "DP-190/Ledger",
        "DP-210/Vendor", "DP-213/Contract", "DP-240/Party", "DP-004/Investment Product",
    ],

    relationships=[
        # --- Employee dimension (DP-192) -----------------------------------------------------------------------
        dict(frm="employee", to="DP-013/Internal Legal Entity",
             on="employee.employing_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="employee", to="DP-013/Org Unit", on="employee.home_org_unit = org_unit.org_unit_id", type="many-to-one"),
        dict(frm="employee", to="DP-013/Office Location", on="employee.work_location = office_location.office_id",
             type="many-to-one"),
        dict(frm="job_assignment", to="employee",
             on="job_assignment.assigned_worker = employee.employee_id (versions effective on the same date)",
             type="one-to-one"),
        dict(frm="job_assignment", to="job_profile", on="job_assignment.assigned_job_profile = job_profile.job_profile_id",
             type="many-to-one"),
        dict(frm="job_assignment", to="workforce_position",
             on="job_assignment.assigned_workforce_position = workforce_position.position_id", type="many-to-one"),
        dict(frm="workforce_position", to="DP-190/Cost Center",
             on="workforce_position.position_cost_center = cost_center.segment_value_code", type="many-to-one"),
        dict(frm="workforce_position", to="DP-013/Org Unit", on="workforce_position.position_org_unit = org_unit.org_unit_id",
             type="many-to-one"),
        dict(frm="reporting_line", to="employee", on="reporting_line.reporting_employee = employee.employee_id",
             type="one-to-one"),
        dict(frm="reporting_line", to="line_manager", on="reporting_line.line_manager = line_manager.line_manager_id",
             type="many-to-one"),
        dict(frm="lifecycle_event", to="employee", on="lifecycle_event.event_employee = employee.employee_id "
                                                       "(worker version effective on the event date)",
             type="many-to-one"),
        dict(frm="lifecycle_event", to="DP-013/Fiscal Period",
             on="lifecycle_event.event_fiscal_period = fiscal_period.fiscal_period_id", type="many-to-one"),
        # --- Movement and hiring (DP-197) ----------------------------------------------------------------------
        dict(frm="leave_of_absence", to="employee", on="leave_of_absence.leave_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="job_requisition", to="workforce_position",
             on="job_requisition.requisition_position = workforce_position.position_id", type="many-to-one"),
        dict(frm="candidate_application", to="job_requisition",
             on="candidate_application.applied_requisition = job_requisition.requisition_id", type="many-to-one"),
        dict(frm="background_screening", to="employee", on="background_screening.screened_employee = employee.employee_id",
             type="many-to-one"),
        # --- Pay and benefits (DP-198) -------------------------------------------------------------------------
        dict(frm="payroll_result", to="payroll_run", on="payroll_result.payroll_run = payroll_run.payroll_run_id",
             type="many-to-one"),
        dict(frm="payroll_result", to="employee", on="payroll_result.payroll_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="payroll_result", to="DP-013/Currency", on="payroll_result.payroll_currency = currency.currency_code",
             type="many-to-one"),
        dict(frm="payroll_run", to="DP-013/Internal Legal Entity",
             on="payroll_run.payroll_run_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="gl_posting", to="payroll_run", on="gl_posting.source_payroll_run = payroll_run.payroll_run_id",
             type="many-to-one"),
        dict(frm="gl_posting", to="journal_entry", on="gl_posting.journal_id = journal_entry.journal_id", type="many-to-one"),
        dict(frm="gl_posting", to="DP-190/GL Account", on="gl_posting.posted_account = gl_account.gl_account_id",
             type="many-to-one"),
        dict(frm="journal_entry", to="DP-013/Fiscal Period",
             on="journal_entry.posting_accounting_period = fiscal_period.fiscal_period_id", type="many-to-one"),
        dict(frm="base_pay", to="employee", on="base_pay.paid_employee = employee.employee_id", type="many-to-one"),
        dict(frm="variable_award", to="employee", on="variable_award.award_recipient = employee.employee_id",
             type="many-to-one"),
        dict(frm="variable_award", to="DP-004/Investment Product",
             on="variable_award.linked_fund = investment_product.product_id", type="many-to-one"),
        dict(frm="benefit_enrollment", to="benefit_plan",
             on="benefit_enrollment.enrolled_benefit_plan = benefit_plan.benefit_plan_id", type="many-to-one"),
        dict(frm="benefit_enrollment", to="employee", on="benefit_enrollment.enrolled_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="compensation_statement", to="employee",
             on="compensation_statement.statement_participant = employee.employee_id", type="many-to-one"),
        dict(frm="payroll_result", to="compensation_statement",
             on="compensation_statement.statement_id in payroll_result.incentive_payout_statements", type="many-to-many",
             warning="A payroll result can pay several statements and a statement can be paid over several runs. Never "
                     "sum gross pay through this join; it is used only to find unpaid statements."),
        # --- Deferred awards (DP-199) ------------------------------------------------------------------------
        dict(frm="deferred_tranche", to="variable_award",
             on="deferred_tranche.tranche_award = variable_award.variable_compensation_award_id", type="many-to-one"),
        # --- Talent (DP-200) -----------------------------------------------------------------------------------
        dict(frm="learning_completion", to="employee", on="learning_completion.learner_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="learning_completion", to="learning_item",
             on="learning_completion.completed_learning_item = learning_item.learning_item_id", type="many-to-one"),
        dict(frm="learning_completion", to="training_requirement",
             on="learning_completion.satisfied_training_requirement = training_requirement.training_requirement_id",
             type="many-to-one"),
        dict(frm="talent_aggregate", to="training_requirement",
             on="talent_aggregate.mandatory_training_requirement_key = training_requirement.training_requirement_id",
             type="many-to-one"),
        dict(frm="talent_aggregate", to="DP-013/Org Unit", on="talent_aggregate.org_unit_key = org_unit.org_unit_id",
             type="many-to-one"),
        dict(frm="talent_aggregate", to="DP-013/Fiscal Period",
             on="talent_aggregate.fiscal_period_key = fiscal_period.fiscal_period_id", type="many-to-one"),
        dict(frm="performance_review", to="employee", on="performance_review.reviewed_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="performance_objective", to="employee",
             on="performance_objective.objective_employee = employee.employee_id", type="many-to-one"),
        dict(frm="succession_entry", to="workforce_position",
             on="succession_entry.succession_position = workforce_position.position_id", type="many-to-one"),
        dict(frm="succession_entry", to="employee", on="succession_entry.successor_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="ce_requirement", to="individual_registration",
             on="ce_requirement.individual_registration_key = individual_registration.license_id", type="many-to-one"),
        dict(frm="individual_registration", to="employee",
             on="individual_registration.registered_person = employee.employee_id", type="many-to-one"),
        # --- Diversity aggregates (DP-201) ---------------------------------------------------------------------
        dict(frm="hc_metric_value", to="DP-013/Internal Legal Entity",
             on="hc_metric_value.metric_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="hc_metric_value", to="DP-013/Org Unit", on="hc_metric_value.metric_org_unit = org_unit.org_unit_id",
             type="many-to-one"),
        dict(frm="hc_metric_value", to="DP-013/Country", on="hc_metric_value.metric_country = country.country_code",
             type="many-to-one"),
        # --- Real estate (DP-207) ------------------------------------------------------------------------------
        dict(frm="site_profile", to="DP-013/Office Location", on="site_profile.profiled_site = office_location.office_id",
             type="one-to-one"),
        dict(frm="building_space", to="DP-013/Office Location", on="building_space.space_site = office_location.office_id",
             type="many-to-one"),
        dict(frm="space_assignment", to="building_space", on="space_assignment.assigned_space = building_space.space_id",
             type="many-to-one"),
        dict(frm="space_assignment", to="DP-190/Cost Center",
             on="space_assignment.chargeback_cost_center = cost_center.segment_value_code", type="many-to-one"),
        dict(frm="space_assignment", to="DP-013/Org Unit", on="space_assignment.assigned_org_unit = org_unit.org_unit_id",
             type="many-to-one"),
        dict(frm="occupancy", to="DP-013/Office Location", on="occupancy.measured_site = office_location.office_id",
             type="many-to-one"),
        dict(frm="space_reservation", to="building_space", on="space_reservation.reserved_space = building_space.space_id",
             type="many-to-one"),
        dict(frm="lease", to="DP-240/Party", on="lease.lease_counterparty = party.party_id", type="many-to-one"),
        dict(frm="lease", to="DP-213/Contract", on="lease.lease_contract = contract.contract_id", type="many-to-one"),
        dict(frm="lease", to="DP-013/Internal Legal Entity",
             on="lease.firm_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="leased_space", to="lease", on="leased_space.space_lease = lease.lease_id", type="many-to-one"),
        dict(frm="leased_space", to="DP-013/Office Location", on="leased_space.leased_site = office_location.office_id",
             type="many-to-one",
             warning="A lease can cover several sites; site-level rent per area uses the lease's area at that site only."),
        dict(frm="lease_payment", to="lease", on="lease_payment.schedule_lease = lease.lease_id", type="many-to-one"),
        dict(frm="lease_critical_date", to="lease", on="lease_critical_date.option_lease = lease.lease_id",
             type="many-to-one"),
        dict(frm="lease_measurement", to="lease", on="lease_measurement.measured_lease = lease.lease_id",
             type="many-to-one"),
        dict(frm="lease_measurement", to="DP-190/Ledger", on="lease_measurement.measurement_ledger = ledger.ledger_id",
             type="many-to-one"),
        dict(frm="gl_balance", to="DP-190/Ledger", on="gl_balance.balance_ledger = ledger.ledger_id", type="many-to-one"),
        dict(frm="gl_balance", to="DP-013/Fiscal Period",
             on="gl_balance.balance_fiscal_period = fiscal_period.fiscal_period_id", type="many-to-one"),
        dict(frm="utility_consumption", to="DP-013/Office Location",
             on="utility_consumption.consumption_site = office_location.office_id", type="many-to-one"),
        dict(frm="utility_consumption", to="DP-013/Unit of Measure",
             on="utility_consumption.consumption_unit = unit_of_measure.unit_code", type="many-to-one"),
        dict(frm="emission_entity", to="DP-013/Internal Legal Entity",
             on="emission_entity.emission_reporting_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="emission_site", to="DP-013/Office Location", on="emission_site.emission_site = office_location.office_id",
             type="many-to-one"),
        # --- Workplace services (DP-208) -----------------------------------------------------------------------
        dict(frm="facility_asset", to="DP-013/Office Location", on="facility_asset.asset_site = office_location.office_id",
             type="many-to-one"),
        dict(frm="planned_maintenance", to="facility_asset",
             on="planned_maintenance.maintained_asset = facility_asset.facility_asset_tag", type="many-to-one"),
        dict(frm="planned_maintenance", to="DP-210/Vendor", on="planned_maintenance.maintenance_vendor = vendor.party_id",
             type="many-to-one"),
        dict(frm="work_order", to="DP-013/Office Location", on="work_order.work_order_site = office_location.office_id",
             type="many-to-one"),
        dict(frm="work_order", to="DP-210/Vendor", on="work_order.assigned_vendor = vendor.party_id", type="many-to-one"),
        dict(frm="access_badge", to="employee", on="access_badge.badge_holder = employee.employee_id", type="many-to-one"),
        dict(frm="access_badge", to="lifecycle_event",
             on="access_badge.deactivating_lifecycle_event = lifecycle_event.lifecycle_event_id", type="many-to-one"),
        dict(frm="zone_grant", to="access_badge", on="zone_grant.granted_badge = access_badge.badge_id", type="many-to-one"),
        dict(frm="visitor_registration", to="DP-013/Office Location",
             on="visitor_registration.visited_site = office_location.office_id", type="many-to-one"),
        dict(frm="visitor_registration", to="employee", on="visitor_registration.host_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="security_incident", to="DP-013/Office Location",
             on="security_incident.security_incident_site = office_location.office_id", type="many-to-one"),
        dict(frm="hs_incident", to="DP-013/Office Location", on="hs_incident.hs_incident_site = office_location.office_id",
             type="many-to-one"),
        dict(frm="risk_assessment", to="DP-013/Office Location", on="risk_assessment.assessed_site = office_location.office_id",
             type="many-to-one"),
        dict(frm="emergency_role", to="DP-013/Office Location",
             on="emergency_role.emergency_role_site = office_location.office_id", type="many-to-one"),
        dict(frm="emergency_role", to="employee", on="emergency_role.role_holder = employee.employee_id", type="many-to-one"),
        # --- Travel and expense (DP-209) -----------------------------------------------------------------------
        dict(frm="expense_line", to="expense_report", on="expense_line.line_expense_report = expense_report.expense_report_id",
             type="many-to-one"),
        dict(frm="expense_line", to="card_transaction",
             on="expense_line.matched_card_transaction = card_transaction.issuer_transaction_reference", type="many-to-one"),
        dict(frm="expense_line", to="DP-004/Investment Product",
             on="expense_line.recharge_fund = investment_product.product_id", type="many-to-one"),
        dict(frm="expense_line", to="expense_policy_limit",
             on="expense_line.expense_type = expense_policy_limit.limited_expense_type and the claimant's location band "
                "and job level, limit effective on expense_date", type="many-to-many",
             warning="The logical model joins on expense type only. Without the location band, job level and date "
                     "conditions one line meets several limits and spend is counted once per limit; use only inside "
                     "Out-of-Policy Lines."),
        dict(frm="expense_report", to="employee", on="expense_report.claimant = employee.employee_id", type="many-to-one"),
        dict(frm="expense_report", to="DP-013/Org Unit", on="expense_report.cost_owner_org_unit = org_unit.org_unit_id",
             type="many-to-one"),
        dict(frm="expense_report", to="journal_entry", on="expense_report.posting_journal_entry = journal_entry.journal_id",
             type="many-to-one"),
        dict(frm="card_transaction", to="corporate_card", on="card_transaction.transaction_card = corporate_card.card_account_id",
             type="many-to-one"),
        dict(frm="corporate_card", to="employee", on="corporate_card.cardholder = employee.employee_id", type="many-to-one"),
        dict(frm="travel_booking", to="employee", on="travel_booking.traveler = employee.employee_id", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Job architecture", levels=["job_profile.job_profile_family", "job_profile.job_level",
                                              "job_profile.job_profile_name"]),
        dict(name="Benefit plan", levels=["benefit_plan.benefit_type", "benefit_plan.benefit_plan_name"]),
        dict(name="Building space", levels=["building_space.space_level", "building_space.space_type",
                                            "building_space.space_id"]),
        dict(name="Training", levels=["training_requirement.training_requirement_type",
                                      "training_requirement.training_requirement_name"]),
        dict(name="Emission scope", levels=["emission_entity.ghg_scope_category", "emission_entity.calculation_method"]),
    ],

    metrics=[
        # =============================================================================================================
        # Certified, owned here (CD-341, CD-347)
        # =============================================================================================================
        dict(name="Certified Headcount", aggregation="semi_additive",
             expr=f"count(distinct employee.employee_id) on the worker version effective on the period end date where "
                  f"{_HEADCOUNT_FILTER}",
             time_rule=_LAST,
             source=("DP-192", "Certified Headcount"),
             description="Employees in any employed status (active, on leave, on notice or garden leave) at the period "
                         "end, excluding contingent workers.",
             note="CD-341 as ruled 2026-10-14. Adds across legal entity, org unit, work location and employment type "
                  "because a worker has one version on a date; never sum over periods. DP-194, DP-197, DP-201 and "
                  "DP-207 read this number; Site Headcount and DP-201 Snapshot Population are this metric sliced."),
        dict(name="Certified FTE", aggregation="semi_additive",
             expr="sum(job_assignment.assignment_fte) of primary assignments effective on the period end date, for "
                  "workers counted in [Certified Headcount]",
             time_rule=_LAST,
             source=("DP-192", "Certified FTE"),
             description="Full-time equivalent of the certified headcount, from each employee's primary assignment.",
             note="Sliced by position cost center, org unit and legal entity through workforce_position. FTE is taken "
                  "as recorded until Standard Weekly Hours is populated (CD-364)."),
        dict(name="Gross Pay Paid", aggregation="additive",
             expr="sum(payroll_result.gross_pay_amount) where payroll_run.pay_date in range and "
                  "payroll_run.payroll_run_status in ('Paid', 'Posted to GL')",
             source=("DP-198", "Gross Pay Paid"),
             description="Gross pay paid through payroll in the period, by legal entity, run type and payroll currency.",
             note="The certified compensation paid number (CD-347). Amounts are in Payroll Currency with no conversion: "
                  "keep payroll_currency on the axis or filter one currency. Compensation expense is SM-14's [Certified "
                  "Compensation Expense] and incentive earned is DP-390's (DP-033 superseded); this metric is compared with both, never "
                  "substituted for them."),

        # --- Certified, owned elsewhere ------------------------------------------------------------------------
        dict(name="Certified Compensation Expense", ref="SM-14/Certified Compensation Expense",
             note="Compensation expense by cost center and period (DP-191). Payroll posts in summary per run, so it "
                  "cannot be sliced by employee; compare with [Gross Pay Paid] by legal entity and period only."),

        # =============================================================================================================
        # DP-192 workforce structure
        # =============================================================================================================
        dict(name="Contingent Worker Count", aggregation="semi_additive",
             expr=f"count(distinct employee.employee_id) on the version effective on the period end date where "
                  f"{_EMPLOYED} and contingent_worker_type is not null",
             time_rule=_LAST, source=("DP-192", "Contingent Worker Count"),
             description="Contingent workers engaged at the period end, by contingent worker type; never added to "
                         "headcount."),
        dict(name="Authorized FTE", aggregation="semi_additive",
             expr="sum(workforce_position.authorized_fte) of positions effective on the period end date with "
                  "position_status <> 'Closed'",
             time_rule=_LAST, source=("DP-192", "Authorized FTE"),
             description="FTE the firm has authorized in open and filled positions, an authorization, not a headcount."),
        dict(name="FTE Variance to Authorized", aggregation="semi_additive",
             expr="[Certified FTE] - [Authorized FTE], both by position cost center and position org unit at the period end",
             time_rule=_LAST, source=("DP-192", "FTE Variance to Authorized"),
             description="Certified FTE above (positive) or below (negative) authorized FTE.",
             note="Workers without a position assignment are in Certified FTE but in no position; slice by position "
                  "attributes only."),
        dict(name="Vacant Positions", aggregation="semi_additive",
             expr="count(distinct workforce_position.position_id) effective on the as-of date with position_status = "
                  "'Open' or no primary job_assignment effective on that date",
             time_rule=_LAST, source=("DP-192", "Vacant Positions"),
             description="Positions open or without a primary incumbent, split by key-person risk."),
        dict(name="Joiner, Mover and Leaver Events", aggregation="additive",
             expr="count(lifecycle_event) with event_effective_date in range, grouped as joiners (Hire, Rehire, "
                  "Conversion), movers (Transfer, Promotion, Demotion, Job Change) and leavers (Termination, by "
                  "voluntary_termination)",
             source=("DP-192", "Joiners, Movers and Leavers"),
             description="Lifecycle events of all workers in the period, grouped as joiners, movers and leavers.",
             note="Includes contingent workers; [Hires] and [Leavers] (DP-197) are the employee-only counts used in rates."),
        dict(name="Leavers Requiring Regulatory Notification", aggregation="additive",
             expr="count(lifecycle_event) where lifecycle_event_type = 'Termination' and regulatory_notification_required "
                  "= 'Y' and event_effective_date in range",
             source=("DP-192", "Leavers Requiring Regulatory Notification"),
             description="Leavers whose departure must be notified to a regulator, by termination reason."),
        dict(name="Workers Without Solid-Line Manager", aggregation="semi_additive",
             expr="count(distinct employee.employee_id) counted in [Certified Headcount] or [Contingent Worker Count] "
                  "with no reporting_line effective on the as-of date",
             time_rule=_LAST, source=("DP-192", "Workers Without Solid-Line Manager"),
             description="Workers with no solid-line manager on the as-of date."),
        dict(name="Contingent Engagements Past End Date", aggregation="semi_additive",
             expr=f"count(distinct employee.employee_id) where {_EMPLOYED} and contingent_worker_type is not null and "
                  "engagement_end_date < as-of date",
             time_rule=_LAST, source=("DP-192", "Contingent Engagements Past End Date"),
             description="Contingent workers still active after their engagement end date."),
        dict(name="Work Authorizations Expiring (90 Days)", aggregation="semi_additive",
             expr=f"count(distinct employee.employee_id) where {_EMPLOYED} and work_authorization_expiry_date between "
                  "as-of date and as-of date + 90 days",
             time_rule=_LAST, source=("DP-192", "Work Authorizations Expiring (90 Days)"),
             description="Workers whose right to work expires in the next 90 days, by authorization type.",
             note="Restricted - Personal Data extension: HR restricted role only."),

        # =============================================================================================================
        # DP-197 movement, hiring and screening
        # =============================================================================================================
        dict(name="Average Headcount", aggregation="semi_additive",
             expr="([Certified Headcount] at the opening period end + [Certified Headcount] at the closing period end) / 2 "
                  "for the same breakdown; for a rolling 12 months, the mean of the 13 month-end values",
             time_rule="opening and closing period ends of the selected range (13 month-ends for rolling 12 months)",
             source=("DP-197", "Average Headcount"),
             description="Average certified headcount over the period, the denominator of every turnover rate.",
             note="Derived from [Certified Headcount], never recomputed."),
        dict(name="Hires", aggregation="additive",
             expr="count(lifecycle_event) where lifecycle_event_type in ('Hire', 'Rehire', 'Conversion') and "
                  "event_effective_date in range and the worker has no contingent_worker_type",
             source=("DP-197", "Hires"),
             description="Employees who joined in the period."),
        dict(name="Leavers", aggregation="additive",
             expr="count(lifecycle_event) where lifecycle_event_type = 'Termination' and event_effective_date in range "
                  "and the worker has no contingent_worker_type",
             source=("DP-197", "Leavers"),
             description="Employees who left in the period, by voluntary or involuntary and termination reason.",
             note="Death and Transfer to Affiliate are counted here but excluded from turnover rates."),
        dict(name="Turnover Rate %", aggregation="ratio",
             numerator="[Leavers] excluding termination_reason in ('Death', 'Transfer to Affiliate'), x 12 / months in "
                       "the period when shorter than a year",
             denominator="[Average Headcount] for the same breakdown and period",
             source=("DP-197", "Turnover Rate %"),
             description="Annualized share of the average workforce that left."),
        dict(name="Voluntary Turnover Rate %", aggregation="ratio",
             numerator="[Leavers] with voluntary_termination = 'Y', annualized as Turnover Rate %",
             denominator="[Average Headcount] for the same breakdown and period",
             source=("DP-197", "Voluntary Turnover Rate %"),
             description="Annualized share of the average workforce that chose to leave."),
        dict(name="First-Year Turnover %", aggregation="ratio",
             numerator="[Leavers] in the trailing 12 months whose termination_date is less than 365 days after hire_date",
             denominator="[Hires] in the 12 months before the end of that window",
             source=("DP-197", "First-Year Turnover %"),
             description="Share of recent hires who left within their first year."),
        dict(name="Internal Mobility Rate %", aggregation="ratio",
             numerator="count(lifecycle_event) with lifecycle_event_type in ('Transfer', 'Promotion', 'Job Change') in "
                       "range, annualized",
             denominator="[Average Headcount] for the same breakdown and period",
             source=("DP-197", "Internal Mobility Rate %"),
             description="Annualized internal moves as a share of the average workforce."),
        dict(name="Time to Fill (Days)", aggregation="non_additive",
             expr="median(requisition_filled_date - requisition_opened_date) for job_requisition with requisition_status "
                  "= 'Filled' and requisition_filled_date in range",
             source=("DP-197", "Time to Fill (Days)"),
             description="Median days from opening a requisition to filling it, by reason and job family.",
             note="A median is recomputed from requisition rows for each selection."),
        dict(name="Open Requisitions", aggregation="semi_additive",
             expr="count(job_requisition) with requisition_status in ('Open', 'On Hold') at the as-of date, banded by "
                  "days open (0-30, 31-60, 61-90, over 90)",
             time_rule=_LAST, source=("DP-197", "Open Requisitions and Age"),
             description="Requisitions open or on hold at the as-of date, by age band."),
        dict(name="Internal Fill Rate %", aggregation="ratio",
             numerator="requisitions filled in range whose hired candidate_application has internal_candidate_employee "
                       "populated",
             denominator="requisitions filled in range",
             source=("DP-197", "Internal Fill Rate %"),
             description="Share of filled requisitions filled by an existing employee."),
        dict(name="Source of Hire Mix %", aggregation="ratio",
             numerator="count(candidate_application) with hired_as_employee populated in range, for the candidate_source",
             denominator="count(candidate_application) with hired_as_employee populated in range (all sources)",
             source=("DP-197", "Source of Hire Mix %"),
             description="Share of hires coming from each candidate source.",
             note="Applications per hire (also in the spec measure) = applications on filled requisitions / hires."),
        dict(name="Vacancy Rate %", aggregation="ratio",
             numerator="[Vacant Positions] at the as-of date",
             denominator="count(distinct workforce_position) effective on the as-of date with position_status <> 'Closed'",
             source=("DP-197", "Vacancy Rate %"),
             description="Share of open and filled positions that are vacant, by key-person risk."),
        dict(name="Vacant Positions Without Open Requisition", aggregation="semi_additive",
             expr="[Vacant Positions] with no job_requisition for the position in status ('Pending Approval', 'Open', "
                  "'On Hold')",
             time_rule=_LAST, source=("DP-197", "Vacant Positions Without Open Requisition"),
             description="Vacant positions nobody is recruiting for, by key-person risk and org unit."),
        dict(name="Regulated Hires Screened Before Start %", aggregation="ratio",
             numerator="[Hires] into a regulated_role_category other than 'Not Regulated' with every required "
                       "background_screening completed on or before the hire date with result in ('Clear', 'Clear with "
                       "Discrepancy')",
             denominator="[Hires] into a regulated_role_category other than 'Not Regulated' in range",
             source=("DP-197", "Regulated Hires Screened Before Start %"),
             description="Share of regulated hires fully screened before they started.",
             note="The required screening types come from the firm's screening policy outside the taxonomy (GAP-20-007)."),
        dict(name="Adverse Screening Results Open", aggregation="semi_additive",
             expr="count(background_screening) with background_screening_result = 'Adverse - Under Adjudication'",
             time_rule=_LAST, source=("DP-197", "Adverse Screening Results Open"),
             description="Adverse screening results still under adjudication, by type and severity.",
             note="Restricted HR view only (criminal record data)."),
        dict(name="Regulated Leavers Not Flagged", aggregation="additive",
             expr="count(lifecycle_event) of Termination in range for workers in a regulated role whose "
                  "regulatory_notification_required is 'N' or blank",
             source=("DP-197", "Regulated Leavers Not Flagged"),
             description="Regulated leavers not flagged for regulatory notification."),
        dict(name="Leaves Past Expected Return", aggregation="semi_additive",
             expr="count(leave_of_absence) with expected_return_date < as-of date and actual_return_date is null",
             time_rule=_LAST, source=("DP-197", "Leaves Past Expected Return"),
             description="Leaves of absence past their expected return with no return recorded.",
             note="Medical Leave and Long-Term Disability breakdowns only in the restricted HR view."),
        dict(name="Candidate Records Past Retention", aggregation="semi_additive",
             expr="count(candidate_application) with hired_as_employee null and candidate_retention_end_date < as-of date",
             time_rule=_LAST, source=("DP-197", "Candidate Records Past Retention"),
             description="Unsuccessful candidate records held past their retention date."),

        # =============================================================================================================
        # DP-198 pay, payroll and benefits
        # =============================================================================================================
        dict(name="Net Pay Paid", aggregation="additive",
             expr="sum(payroll_result.net_pay_amount) for the payroll results in [Gross Pay Paid]",
             source=("DP-198", "Net Pay Paid"),
             description="Net pay paid through payroll in the period, by payroll currency."),
        dict(name="Employer Social Charges", aggregation="additive",
             expr="sum(payroll_result.employer_social_charges_amount) for the payroll results in [Gross Pay Paid]",
             source=("DP-198", "Employer Social Charges"),
             description="Employer social charges paid through payroll in the period, by payroll currency."),
        dict(name="Run-to-Journal Difference", aggregation="non_additive",
             expr="per payroll_run: sum(gross_pay_amount + employer_social_charges_amount) - sum(gl_posting.posted_amount) "
                  "where debit_credit_indicator = 'Debit' and source_payroll_run = the run",
             source=("DP-198", "Run-to-Journal Difference"),
             description="Difference between a payroll run and its posted debits; expected zero.",
             note="Shown per run: summing differences across runs lets them offset."),
        dict(name="Runs Not Reconciled", aggregation="count_distinct",
             expr="count(distinct payroll_run) with payroll_run_status in ('Paid', 'Posted to GL') and pay_date more than "
                  "2 business days before the as-of date whose [Run-to-Journal Difference] <> 0 or with no postings",
             source=("DP-198", "Runs Not Reconciled"),
             description="Paid payroll runs not tied to their journals two business days after pay date."),
        dict(name="Incentive Statements Unpaid", aggregation="semi_additive",
             expr="count(compensation_statement) with statement_status = 'Issued' and statement_issued_date <= as-of date "
                  "that no payroll_result.incentive_payout_statements lists in a run with pay_date >= statement_issued_date, "
                  "or whose Payroll Result Reference is empty",
             time_rule=_LAST, source=("DP-198", "Incentive Statements Unpaid"),
             description="Issued advisor compensation statements not yet paid through payroll."),
        dict(name="Incentive Statements Unpaid Amount", aggregation="semi_additive",
             expr="sum(compensation_statement.net_payable_amount) of the statements in [Incentive Statements Unpaid]",
             time_rule=_LAST, source=("DP-198", "Incentive Statements Unpaid"),
             description="Net payable of issued compensation statements not yet paid through payroll."),        dict(name="Payments to Leavers", aggregation="additive",
             expr="sum(payroll_result.gross_pay_amount) in Regular runs where employee.termination_date < "
                  "payroll_run.pay_period_start_date (count of results shown beside it)",
             source=("DP-198", "Payments to Leavers"),
             description="Regular payroll paid to people who had already left."),
        dict(name="Active Employees Not Paid", aggregation="count_distinct",
             expr=f"count(distinct employee x Regular run) where {_HEADCOUNT_FILTER} throughout the pay period, "
                  "employing_legal_entity = payroll_run_legal_entity and no payroll_result in the run",
             source=("DP-198", "Active Employees Not Paid"),
             description="Employees employed through a regular run's pay period who received no payroll result."),
        dict(name="Annualized Base Pay", aggregation="semi_additive",
             expr="sum over employees of base_pay.pay_component_amount effective on the as-of date annualized by "
                  "pay_amount_basis (Annual x1, Monthly x12, Per Pay Period x periods per year, Hourly x the firm's "
                  "standard annual hours x assignment_fte)",
             time_rule="single as-of date (latest in the selected range)",
             source=("DP-198", "Annualized Base Pay"),
             description="The annual base pay bill on the as-of date, by entity, org unit and job level, in pay currency.",
             note="Hourly pay uses a firm parameter until Standard Weekly Hours is populated (CD-364). Sum within one "
                  "pay currency."),
        dict(name="Pay Review Increase %", aggregation="ratio",
             numerator="sum(new annualized base pay - annualized base pay on the day before pay_effective_from) for "
                       "base_pay records with a review-cycle pay_change_reason effective in the cycle",
             denominator="sum(annualized base pay on the day before pay_effective_from) for the same records",
             source=("DP-198", "Pay Review Increase %"),
             description="Pay review increase as a share of pre-review base pay, by reason, job level and org unit."),
        dict(name="Variable Awards Granted", aggregation="additive",
             expr="sum(variable_award.award_amount) with award_grant_date in range, by variable_award_type, "
                  "performance_year and award_currency",
             source=("DP-198", "Variable Awards Granted"),
             description="Variable compensation awarded in the period; the upfront portion is award x (1 - deferred %).",
             note="Sum within one award currency. Deferred tranches are DP-199's."),
        dict(name="Awards Granted Without Committee Approval", aggregation="additive",
             expr="count(variable_award) with award_grant_date populated and remco_approval_date null or after "
                  "award_grant_date",
             source=("DP-198", "Awards Granted Without Committee Approval"),
             description="Awards granted before or without remuneration committee approval."),
        dict(name="Benefit Enrollment Rate %", aggregation="ratio",
             numerator="count(distinct employee) with a benefit_enrollment in the active plan, coverage_level <> "
                       "'Waived', coverage effective on the as-of date",
             denominator=f"count(distinct employee) where {_EMPLOYED} and employing_legal_entity = "
                         "benefit_plan.offering_legal_entity",
             source=("DP-198", "Benefit Enrollment Rate %"),
             description="Share of eligible employees enrolled in each active benefit plan."),
        dict(name="Leavers With Active Coverage", aggregation="semi_additive",
             expr="count(benefit_enrollment) whose coverage_end_date is null or after the end of the month of the "
                  "employee's termination_date",
             time_rule=_LAST, source=("DP-198", "Leavers With Active Coverage"),
             description="Benefit enrollments of leavers still covered beyond the default end of coverage."),

        # =============================================================================================================
        # DP-199 deferred awards and clawback
        # =============================================================================================================
        dict(name="Total Variable Remuneration", aggregation="additive",
             expr="sum(variable_award.award_amount) per award recipient and performance_year, converted from "
                  "award_currency to the reporting currency of the recipient's employing legal entity",
             source=("DP-199", "Total Variable Remuneration"),
             description="Variable remuneration awarded for a performance year, by employee and entity."),
        dict(name="Fixed Remuneration", aggregation="additive",
             expr="sum(base_pay.pay_component_amount annualized and prorated to the days of the performance year each "
                  "record was effective), converted to the reporting currency, per employee",
             source=("DP-199", "Fixed Remuneration"),
             description="Fixed remuneration of each employee for a performance year."),
        dict(name="Variable-to-Fixed Ratio", aggregation="non_additive",
             expr="per employee and performance year: [Total Variable Remuneration] / [Fixed Remuneration]",
             source=("DP-199", "Variable-to-Fixed Ratio"),
             description="Each employee's variable pay as a multiple of fixed pay, compared with the firm's policy ratio.",
             note="A per-person test; the policy cap is a parameter outside the taxonomy (GAP-20-004)."),
        dict(name="Instrument Share %", aggregation="non_additive",
             expr="per employee and year: sum(award_amount) with award_instrument in ('Shares', 'Units in Managed Funds', "
                  "'Share-Linked Instrument') / [Total Variable Remuneration]; the fund-linked part (linked_fund not "
                  "null) shown separately",
             source=("DP-199", "Instrument Share %"),
             description="Share of each employee's variable pay awarded in shares, fund units or share-linked instruments."),
        dict(name="Tranche Schedule Breaks", aggregation="count_distinct",
             expr="count(distinct variable_award) with deferred_portion_percentage > 0 where |sum(deferred_tranche."
                  "tranche_amount) - award_amount x deferred_portion_percentage| > 1",
             source=("DP-199", "Tranche Schedule Breaks"),
             description="Deferred awards whose tranches do not add up to the deferred amount."),
        dict(name="Unvested Deferred Remuneration", aggregation="semi_additive",
             expr="sum(deferred_tranche.tranche_amount) where tranche_vesting_status = 'Unvested'",
             time_rule=_LAST, source=("DP-199", "Unvested Deferred Remuneration"),
             description="Deferred remuneration not yet vested, by vesting year, basis and entity."),
        dict(name="Vesting With Unassessed Conduct Flag", aggregation="semi_additive",
             expr="count(deferred_tranche) Unvested with vesting_date in the next 90 days whose recipient has a "
                  "performance_review with conduct_adjustment = 'Y' after award_grant_date and malus_clawback_status = "
                  "'Not Applied'",
             time_rule=_LAST, source=("DP-199", "Vesting With Unassessed Conduct Flag"),
             description="Tranches about to vest for people with a conduct flag not yet assessed for malus."),
        dict(name="Malus and Clawback Applied", aggregation="additive",
             expr="sum(deferred_tranche.malus_clawback_adjustment_amount) by malus_clawback_status",
             source=("DP-199", "Malus and Clawback Applied"),
             description="Remuneration reduced or recovered through malus and clawback."),
        dict(name="Remuneration Under Clawback", aggregation="semi_additive",
             expr="sum(deferred_tranche.tranche_amount) with tranche_vesting_status = 'Vested' and "
                  "clawback_period_end_date >= as-of date",
             time_rule=_LAST, source=("DP-199", "Remuneration Under Clawback"),
             description="Vested remuneration still within its clawback period."),
        # WP2 (CW-209): the WP1 DP-199 measures, published here (SM-15 stays DP-199's home; no wealth model takes it).
        dict(name="Unvested Tranches of Leavers", aggregation="semi_additive",
             expr="sum(deferred_tranche.tranche_amount) where tranche_vesting_status = 'Unvested' and the award "
                  "recipient's employee.employment_status = 'Terminated' with employee.termination_date before the as-of "
                  "date, by vesting_basis",
             time_rule=_LAST, source=("DP-199", "Unvested Tranches of Leavers"),
             description="Unvested deferred pay of people who have left, a forfeiture not yet booked unless good-leaver terms keep it.",
             note="The count of tranches is shown beside the amount; the tranche carries no leaver reason (DP-199 gap)."),
        dict(name="Awards Without Committee Approval", aggregation="additive",
             expr="sum(variable_award.award_amount) where variable_award_type in ('Deferred Award', 'Retention Award', "
                  "'Sign-On Award', 'Buy-Out Award') and (remco_approval_date is null or remco_approval_date > "
                  "award_grant_date), within one award_currency",
             source=("DP-199", "Awards Without Committee Approval"),
             description="Deferred, retention, sign-on and buy-out awards granted before or without remuneration committee approval.",
             note="The count of awards is shown beside the amount; must be zero."),
        dict(name="Own-Fund Deferral by Fund", aggregation="semi_additive",
             expr="sum(deferred_tranche.tranche_amount) where tranche_vesting_status = 'Unvested' and the award's "
                  "award_instrument = 'Units in Managed Funds', by variable_award.linked_fund and year(vesting_date)",
             time_rule=_LAST, source=("DP-199", "Own-Fund Deferral by Fund"),
             description="The firm's deferred co-investment of employee pay in its own funds, by fund and vesting year.",
             note="An employee compensation amount, never Client Assets or Firm AUM."),
        # =============================================================================================================
        # DP-200 talent, training and succession
        # =============================================================================================================
        dict(name="Mandatory Training On-Time Completion %", aggregation="ratio",
             numerator="count(learning_completion) of a required learning item due in range with completion_status = "
                       "'Completed' and completion_date <= completion_due_date",
             denominator="count(learning_completion) of a required learning item due in range, excluding 'Waived'",
             source=("DP-200", "Mandatory Training On-Time Completion %"),
             description="Share of mandatory training assignments completed by their due date."),
        dict(name="Overdue Mandatory Training", aggregation="semi_additive",
             expr="count(learning_completion) of a required learning item with completion_due_date < as-of date and "
                  "completion_status not in ('Completed', 'Waived'), banded by days overdue",
             time_rule=_LAST, source=("DP-200", "Overdue Mandatory Training"),
             description="Mandatory training assignments past due, by days overdue and requirement type."),
        dict(name="Employees With Overdue Mandatory Training", aggregation="count_distinct",
             expr="count(distinct learning_completion.learner_employee) with at least one assignment in [Overdue "
                  "Mandatory Training]",
             source=("DP-200", "Overdue Mandatory Training"),
             description="Employees with at least one overdue mandatory training assignment."),
        dict(name="Population Coverage Gaps", aggregation="semi_additive",
             expr="sum(talent_aggregate.population_coverage_gaps)",
             time_rule="last fiscal period in the selected range",
             source=("DP-200", "Population Coverage Gaps"),
             description="Employees in a requirement's population with no assignment in the current cycle.",
             note="Read from the product's aggregate: the population rule is free text evaluated outside the taxonomy "
                  "(GAP-20-012)."),
        dict(name="New Joiner Training On Time %", aggregation="ratio",
             numerator="employees hired in range whose mandatory assignments due in their first 90 days were all "
                       "completed by the due date",
             denominator="employees hired in range",
             source=("DP-200", "New Joiner Training On Time %"),
             description="Share of new joiners who completed their onboarding mandatory training on time."),
        dict(name="Rating Distribution %", aggregation="ratio",
             numerator="count(performance_review) with review_status in ('Completed', 'Acknowledged') at each "
                       "calibrated_rating",
             denominator="count(performance_review) with review_status in ('Completed', 'Acknowledged') in the same "
                         "review cycle and breakdown, excluding 'Too New to Rate'",
             source=("DP-200", "Rating Distribution %"),
             description="Distribution of calibrated ratings within a review cycle."),
        dict(name="Calibration Change %", aggregation="ratio",
             numerator="completed performance_review rows with calibrated_rating <> proposed_rating (split up and down)",
             denominator="completed performance_review rows",
             source=("DP-200", "Calibration Change %"),
             description="Share of ratings changed at calibration, moved up or down."),
        dict(name="Reviews Open After Cycle Close", aggregation="semi_additive",
             expr="count(performance_review) of review_type 'Year-End' for employees employed at cycle end with "
                  "review_status not in ('Completed', 'Acknowledged') after the HR-set cycle close date",
             time_rule="review cycle selected",
             source=("DP-200", "Reviews Open After Cycle Close"),
             description="Year-end reviews still open after the cycle closed.",
             note="The cycle close date is set by HR outside the taxonomy (GAP-20-012)."),
        dict(name="Conduct Adjustments", aggregation="additive",
             expr="count(performance_review) with conduct_adjustment = 'Y'",
             source=("DP-200", "Conduct Adjustments"),
             description="Performance reviews with a conduct adjustment, by review cycle and org unit."),
        dict(name="Objective Weighting Breaks", aggregation="count_distinct",
             expr="count(distinct employee x objective_review_cycle) where sum(objective_weight) <> 100% or, for a "
                  "regulated job profile, no objective with objective_category = 'Risk & Conduct'",
             source=("DP-200", "Objective Weighting Breaks"),
             description="Employee review cycles whose objectives do not weigh 100% or lack a risk and conduct objective."),
        dict(name="Key-Person Succession Cover %", aggregation="ratio",
             numerator="key-person positions (key_person_risk = 'Y', position_status <> 'Closed') with at least one "
                       "succession_entry at successor_readiness = 'Ready Now' whose successor is employed",
             denominator="key-person positions effective on the as-of date with position_status <> 'Closed'",
             source=("DP-200", "Key-Person Succession Cover %"),
             description="Share of key-person positions with a ready-now successor."),
        dict(name="Key Positions Without Emergency Successor", aggregation="semi_additive",
             expr="count(key-person positions) with no succession_entry where emergency_successor = 'Y' and the "
                  "successor is employed",
             time_rule=_LAST, source=("DP-200", "Key Positions Without Emergency Successor"),
             description="Key-person positions with no employed emergency successor."),
        dict(name="Stale Succession Plans", aggregation="semi_additive",
             expr="count(key-person positions) whose latest succession_review_date is more than 12 months before the "
                  "as-of date, or with no succession_entry",
             time_rule=_LAST, source=("DP-200", "Stale Succession Plans"),
             description="Key-person positions whose succession plan is missing or over a year old."),
        dict(name="Successor Concentration", aggregation="count_distinct",
             expr="count(distinct succession_entry.successor_employee) named 'Ready Now' for three or more key-person "
                  "positions",
             source=("DP-200", "Successor Concentration"),
             description="Employees named as ready-now successor for three or more key positions."),
        dict(name="CE Requirements With Unrecorded Firm Element", aggregation="semi_additive",
             expr="count(ce_requirement) not complete whose registered person has a completed learning_completion of a "
                  "learning_item with regulatory_credit_type = 'FINRA CE - Firm Element' on or before ce_due_date",
             time_rule=_LAST, source=("DP-200", "CE Requirements With Unrecorded Firm Element"),
             description="Continuing education requirements where a completed Firm Element has not reached the "
                         "registration record.",
             note="CE status itself stays DP-039's."),

        # =============================================================================================================
        # DP-201 diversity and pay equity: values as published by the product (aggregates, minimum cell size)
        # =============================================================================================================
        dict(name="Self-Identification Rate %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Self-Identification Rate %",
             source=("DP-201", "Self-Identification Rate %"),
             description="Share of employees who have self-identified diversity data, by jurisdiction and entity.",
             note="Every DP-201 metric is shown at the product's own grain: cells were computed and suppressed in the "
                  "product and cannot be added or re-averaged."),
        dict(name="Representation %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Representation %",
             source=("DP-201", "Representation %"),
             description="Share of employees in each diversity category, by job level, org unit and entity; small "
                         "cells suppressed."),
        dict(name="Women in Senior Leadership %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Women in Senior Leadership %",
             source=("DP-201", "Women in Senior Leadership %"),
             description="Share of Managing Director and Executive roles held by women."),
        dict(name="Gender Pay Gap (Indicative) %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Gender Pay Gap (Mean and Median) %, "
                  "metric_breakdown = mean or median",
             source=("DP-201", "Gender Pay Gap (Mean and Median) %"),
             description="Indicative mean and median gender pay gap per legal entity on FTE-adjusted annual pay.",
             note="Indicative (CD-364): not the statutory hourly figure until Standard Weekly Hours and Hours Worked "
                  "are populated; never published as a statutory number."),
        dict(name="Pay Quartile Composition (Indicative) %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Pay Quartile Composition %",
             source=("DP-201", "Pay Quartile Composition %"),
             description="Indicative share of women and men in each pay quartile per legal entity.",
             note="Indicative (CD-364)."),
        dict(name="Bonus Gap and Bonus Receipt %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Bonus Gap and Bonus Receipt %",
             source=("DP-201", "Bonus Gap and Bonus Receipt %"),
             description="Mean and median bonus gap and the share of men and women receiving a bonus, per entity.",
             note="Bonus is taken by Award Grant Date, not payment date (GAP-20-002)."),
        dict(name="Ethnicity Pay Gap (Indicative) %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Ethnicity Pay Gap %",
             source=("DP-201", "Ethnicity Pay Gap %"),
             description="Indicative median pay gap of White employees against the other declared US race / ethnicity "
                         "categories, per legal entity.",
             note="Indicative (CD-364); not published where either group has fewer than 10 employees."),
        dict(name="Worker Categories With Gap of 5% or More (Indicative)", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Worker Categories With Gap of 5% or More",
             source=("DP-201", "Worker Categories With Gap of 5% or More"),
             description="Indicative count of job levels per legal entity with a mean gender pay gap of 5% or more.",
             note="Indicative (CD-364); the firm's pay equity review trigger, a policy parameter."),
        dict(name="EEO-1 Component 1 Counts", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = EEO-1 Component 1 Counts",
             source=("DP-201", "EEO-1 Component 1 Counts"),
             description="US employees by EEO-1 job category, race or ethnicity and sex, by establishment."),
        dict(name="Age Band Distribution %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Age Band Distribution %",
             source=("DP-201", "Age Band Distribution %"),
             description="Share of employees under 30, 30 to 50 and over 50, by entity and country."),
        dict(name="Turnover by Gender %", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Turnover by Gender %",
             source=("DP-201", "Turnover by Gender %"),
             description="DP-197's turnover rate by legal gender and entity.",
             note="Only DP-201 may combine turnover with gender, so this is not recomputed from lifecycle_event."),
        dict(name="Published Value Mismatches", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Published Value Mismatches",
             source=("DP-201", "Published Value Mismatches"),
             description="Published human capital values that disagree with [Certified Headcount], [Certified FTE] or "
                         "the product's own values."),
        dict(name="Suppressed Cells", aggregation="non_additive",
             expr="hc_metric_value.metric_value where metric_definition = Suppressed Cells",
             source=("DP-201", "Suppressed Cells"),
             description="Aggregate cells withheld because they hold fewer than the minimum number of employees."),

        # =============================================================================================================
        # DP-207 real estate, occupancy and sustainability
        # =============================================================================================================
        dict(name="Site Gross Area", aggregation="semi_additive",
             expr="sum(site_profile.site_gross_area) of profiles effective on the as-of date",
             time_rule=_LAST, source=("DP-207", "Site Gross Area and Capacity"),
             description="Gross floor area of the firm's sites, by site type, tenure and country.",
             note="Sum within one site_area_unit."),
        dict(name="Workstation Capacity", aggregation="semi_additive",
             expr="sum(site_profile.workstation_capacity) of profiles effective on the as-of date",
             time_rule=_LAST, source=("DP-207", "Site Gross Area and Capacity"),
             description="Workstations available across the firm's sites."),
        dict(name="Area per Head", aggregation="ratio",
             numerator="[Site Gross Area] at the month end",
             denominator="[Certified Headcount] with employee.work_location = the site at the same month end",
             source=("DP-207", "Area per Head"),
             description="Gross area per certified employee at each site."),
        dict(name="Desks per Head", aggregation="ratio",
             numerator="[Workstation Capacity] at the month end",
             denominator="[Certified Headcount] with employee.work_location = the site at the same month end",
             source=("DP-207", "Desks per Head"),
             description="Workstations per certified employee at each site."),
        dict(name="Average Utilization %", aggregation="non_additive",
             expr="avg(occupancy.utilization_percentage) over the business days of the month, per site; peak occupancy "
                  "% = max(peak_occupancy_count) / workstation_capacity",
             source=("DP-207", "Average Utilization %"),
             description="Average daily utilization of each site's workstations, and peak occupancy.",
             note="A mean of daily percentages per site; recomputed for each selection, never summed."),
        dict(name="Booking No-Show Rate %", aggregation="ratio",
             numerator="count(space_reservation) ending in range with checked_in = 'N'",
             denominator="count(space_reservation) ending in range",
             source=("DP-207", "Booking No-Show Rate %"),
             description="Share of space bookings nobody checked in to, by site and space type."),
        dict(name="Unassigned Space %", aggregation="ratio",
             numerator="sum(building_space.space_area) at each site's lowest space level with no space_assignment "
                       "effective on the as-of date, excluding Circulation, Plant Room and Reception",
             denominator="sum(building_space.space_area) at that level with the same exclusions",
             source=("DP-207", "Unassigned Space %"),
             description="Share of usable space not assigned to any org unit."),
        dict(name="Assigned Area by Cost Center", aggregation="semi_additive",
             expr="sum(building_space.space_area) of spaces with an effective space_assignment, by assigned_org_unit "
                  "and chargeback_cost_center",
             time_rule=_LAST, source=("DP-207", "Assigned Area by Cost Center"),
             description="Space assigned to each org unit and cost center, the basis of occupancy chargeback."),
        dict(name="Contracted Rent Commitment", aggregation="semi_additive",
             expr="sum(lease_payment.scheduled_payment_amount) with payment_period_start after the as-of date on "
                  "active leases, undiscounted, by charge type and calendar year; Sublease Income separately",
             time_rule="single as-of date (latest in the selected range)",
             source=("DP-207", "Contracted Rent Commitment"),
             description="Future contracted lease payments, undiscounted.",
             note="Sum within one lease_currency."),
        dict(name="Base Rent per Area", aggregation="ratio",
             numerator="sum(lease_payment.scheduled_payment_amount) with lease_charge_type = 'Base Rent' for the 12 "
                       "months from the as-of date",
             denominator="sum(leased_space.contractual_rentable_area) effective on the as-of date for the same leases "
                         "and sites",
             source=("DP-207", "Base Rent per Area"),
             description="Annual base rent per unit of contracted rentable area."),
        dict(name="Critical Dates Due (180 Days)", aggregation="semi_additive",
             expr="count(lease_critical_date) with notice_deadline_date between the as-of date and 180 days after and "
                  "no exercise_decision_date",
             time_rule=_LAST, source=("DP-207", "Critical Dates Due (180 Days)"),
             description="Lease options and notice dates falling due in the next 180 days without a decision."),
        dict(name="Missed Notice Deadlines", aggregation="semi_additive",
             expr="count(lease_critical_date) on active leases with notice_deadline_date < as-of date, no "
                  "exercise_decision_date and option_exercised blank",
             time_rule=_LAST, source=("DP-207", "Missed Notice Deadlines"),
             description="Lease notice deadlines passed with no decision recorded."),
        dict(name="Weighted Average Lease Term Remaining", aggregation="ratio",
             numerator="sum((lease.lease_expiry_date - as-of date, in years) x leased_space.contractual_rentable_area) "
                       "over active lessee leases",
             denominator="sum(leased_space.contractual_rentable_area) over the same leases",
             source=("DP-207", "Weighted Average Lease Term Remaining"),
             description="Area-weighted years left on the firm's leases; leases expiring within 12 and 24 months shown "
                         "separately."),
        dict(name="Lease Liability", aggregation="semi_additive",
             expr="sum(lease_measurement.lease_liability_amount)",
             time_rule="month end selected (the latest measurement on or before it is pinned in the table)",
             source=("DP-207", "Lease Liability and ROU Asset"),
             description="Lease liability of the firm's leases by entity, ledger and classification."),
        dict(name="Right-of-Use Asset", aggregation="semi_additive",
             expr="sum(lease_measurement.right_of_use_asset_amount)",
             time_rule="month end selected (the latest measurement on or before it is pinned in the table)",
             source=("DP-207", "Lease Liability and ROU Asset"),
             description="Right-of-use asset of the firm's leases by entity, ledger and classification."),
        dict(name="Active Leases Without Measurement", aggregation="count_distinct",
             expr="count(distinct lease) active, Lessee, commenced by the month end, with no lease_measurement for a "
                  "primary ledger of the firm legal entity",
             source=("DP-207", "Active Leases Without Measurement"),
             description="Active leases missing a lease accounting measurement in a primary ledger."),
        dict(name="Lease Balance to GL Difference", aggregation="non_additive",
             expr="per ledger and fiscal period: ([Lease Liability] + [Right-of-Use Asset] by account) - "
                  "sum(gl_balance.closing_balance) on the designated accounts",
             source=("DP-207", "Lease Balance to GL Difference"),
             description="Difference between lease measurements and the general ledger; expected zero.",
             note="Account designation is a Controller list outside the taxonomy (GAP-44-004)."),
        dict(name="Energy Consumption", aggregation="additive",
             expr="sum(utility_consumption.consumption_quantity) prorated by days to the months in range, by site, "
                  "utility resource and consumption unit",
             source=("DP-207", "Energy Consumption and Renewable Share"),
             description="Energy and utilities consumed, by site and resource.",
             note="Sum within one consumption unit: no unit conversion factors exist (GAP-44-005)."),
        dict(name="Renewable Electricity Share %", aggregation="ratio",
             numerator="sum(consumption_quantity x renewable_share) for utility_resource = 'Electricity'",
             denominator="sum(consumption_quantity) for utility_resource = 'Electricity'",
             source=("DP-207", "Energy Consumption and Renewable Share"),
             description="Share of electricity from renewable sources; the estimated share is shown beside it."),
        dict(name="Energy Intensity per Area", aggregation="ratio",
             numerator="sum(energy consumption converted to kWh) per site per year",
             denominator="[Site Gross Area]",
             source=("DP-207", "Energy Intensity per Area"),
             description="Energy consumed per unit of gross area per year.",
             note="kWh conversion applied outside the taxonomy (GAP-44-005)."),
        dict(name="Operational Emissions", aggregation="additive",
             expr="sum(emission_entity.emissions_tco2e) by reporting entity, year, scope category and calculation method",
             source=("DP-207", "Operational Emissions"),
             description="Scope 1, 2 and business-travel emissions of the firm's operations, in tCO2e.",
             note="Never add across calculation_method: Scope 2 location-based and market-based are alternatives."),
        dict(name="Emissions per Employee", aggregation="ratio",
             numerator="[Operational Emissions] for Scope 1 + Scope 2 market-based, by entity and year",
             denominator="[Certified Headcount] of the entity at the reporting year end",
             source=("DP-207", "Emissions per Employee"),
             description="Scope 1 and market-based Scope 2 emissions per certified employee."),
        dict(name="Site-to-Entity Emission Difference", aggregation="non_additive",
             expr="per entity, year, scope and method: sum(emission_site.site_emissions_tco2e) - "
                  "emission_entity.emissions_tco2e",
             source=("DP-207", "Site-to-Entity Emission Difference"),
             description="Emissions in an entity total not allocated to any site."),

        # =============================================================================================================
        # DP-208 workplace services, security and health and safety
        # =============================================================================================================
        dict(name="Overdue Statutory Maintenance", aggregation="semi_additive",
             expr="count(planned_maintenance) with statutory_requirement populated and next_due_date < as-of date",
             time_rule=_LAST, source=("DP-208", "Overdue Statutory Maintenance"),
             description="Statutory maintenance tasks past due, by site, asset class and vendor."),
        dict(name="Statutory Maintenance Compliance %", aggregation="ratio",
             numerator="statutory planned_maintenance on active assets not overdue",
             denominator="statutory planned_maintenance on assets with facility_asset_status active",
             source=("DP-208", "Overdue Statutory Maintenance"),
             description="Share of statutory maintenance up to date."),
        dict(name="Work Orders Within SLA %", aggregation="ratio",
             numerator="count(work_order) completed in range with completed_timestamp <= sla_completion_due",
             denominator="count(work_order) completed in range",
             source=("DP-208", "Work Orders Within SLA %"),
             description="Share of facility work orders completed within SLA, by priority, type, site and vendor."),
        dict(name="Open Work Orders Past SLA", aggregation="semi_additive",
             expr="count(work_order) with no completed_timestamp and sla_completion_due before the as-of timestamp",
             time_rule=_LAST, source=("DP-208", "Open Work Orders Past SLA"),
             description="Open facility work orders already past their SLA."),
        dict(name="Leavers With Active Badge", aggregation="semi_additive",
             expr="count(access_badge) with badge_status = 'Active' whose holder is Terminated with termination_date "
                  "before the as-of date, or a contingent worker past engagement_end_date",
             time_rule=_LAST, source=("DP-208", "Leavers With Active Badge"),
             description="Active building badges held by people who have left."),
        dict(name="Leaver Badges Deactivated by Event %", aggregation="ratio",
             numerator="badges of holders with a Termination in range with badge_status = 'Deactivated' and "
                       "deactivating_lifecycle_event = that termination",
             denominator="badges of those holders active the day before the termination",
             source=("DP-208", "Leaver Badges Deactivated by Event %"),
             description="Share of leavers' badges deactivated by their termination event.",
             note="Tested at day grain: badges carry no deactivation timestamp (GAP-44-003)."),
        dict(name="Restricted Zone Grants Without Approver", aggregation="semi_additive",
             expr="count(zone_grant) effective on the as-of date with access_zone <> 'General Office' and grant approver "
                  "blank or equal to the badge holder",
             time_rule=_LAST, source=("DP-208", "Restricted Zone Grants Without Approver"),
             description="Restricted-zone access grants with no independent approver."),
        dict(name="Visits Without Departure", aggregation="semi_additive",
             expr="count(visitor_registration) with arrival before the start of the as-of day and no departure_timestamp",
             time_rule=_LAST, source=("DP-208", "Visits Without Departure"),
             description="Visitors signed in on an earlier day with no recorded departure, by site and host org unit."),
        dict(name="Physical Security Incidents", aggregation="additive",
             expr="count(security_incident) occurred in range, by site, type and severity; open = status not closed",
             source=("DP-208", "Physical Security Incidents"),
             description="Physical security incidents at the firm's sites."),
        dict(name="Recordable and Reportable Incidents", aggregation="additive",
             expr="count(hs_incident) occurred in range with osha_recordable = 'Y', and separately with "
                  "regulatory_report_date not null (reported to OSHA or the state plan as a fatality or severe injury); "
                  "lost days = sum(days_away_from_work)",
             source=("DP-208", "Recordable and Reportable Incidents"),
             description="OSHA-recordable and OSHA-reported health and safety incidents, and days lost.",
             note="Site counts only for broad roles; type, outcome and days lost in the restricted view."),
        dict(name="Late OSHA Severe Injury Reports", aggregation="additive",
             expr="count(hs_incident) with injury_outcome = 'Death' and regulatory_report_date blank or more than one "
                  "calendar day after hs_incident_occurred, plus incidents with a regulatory_report_date more than one "
                  "calendar day after the occurrence (29 CFR 1904.39)",
             source=("DP-208", "Late OSHA Severe Injury Reports"),
             description="Fatality and severe injury reports made to OSHA late or not at all."),
        dict(name="Recordable Incident Rate", aggregation="ratio",
             numerator="OSHA recordable hs_incident at US sites in range x 200,000",
             denominator="average [Certified FTE] of workers whose work_location is a US site x 2,000 x months in "
                         "range / 12",
             source=("DP-208", "Recordable Incident Rate"),
             description="Approximate OSHA recordable incident rate per 100 full-time workers.",
             note="Uses Certified FTE x 2,000 hours until Hours Worked is populated (CD-364, GAP-20-001)."),
        dict(name="Risk Assessments Overdue", aggregation="semi_additive",
             expr="count(latest risk_assessment per site or workstation and type) with next_review_date < as-of date",
             time_rule=_LAST, source=("DP-208", "Risk Assessments Overdue"),
             description="Workplace risk assessments past their review date, by type and risk rating."),
        dict(name="Emergency Role Gaps", aggregation="semi_additive",
             expr="count(site x emergency_role_floor) of active sites with no effective Fire Warden or First Aider "
                  "whose holder is employed and certified by a completed learning completion",
             time_rule=_LAST, source=("DP-208", "Emergency Role Gaps"),
             description="Site floors without a certified fire warden or first aider.",
             note="Tests at least one of each per floor (GAP-44-002)."),
        dict(name="Emergency Role Holders Who Have Left", aggregation="semi_additive",
             expr="count(emergency_role) effective on the as-of date whose holder is Terminated or whose work_location "
                  "is not the emergency role site",
             time_rule=_LAST, source=("DP-208", "Emergency Role Holders Who Have Left"),
             description="Emergency roles held by people who have left or moved site."),

        # =============================================================================================================
        # DP-209 travel and expense
        # =============================================================================================================
        dict(name="T&E Spend", aggregation="additive",
             expr="sum(expense_line.transaction_amount) on expense_report with expense_approval_status = 'Approved', by "
                  "expense_date month, expense type, cost owner org unit and claimant",
             source=("DP-209", "T&E Spend"),
             description="Approved travel and expense spend, an operational measure reconciled to the ledger.",
             note="Not certified expense: SM-14's [Certified Operating Expense] is the expense number (CD-340)."),
        dict(name="Out-of-Policy Lines", aggregation="additive",
             expr="count(expense_line) whose transaction_amount (per night for lodging, per day for travel meals) exceeds "
                  "the limit_amount or per_diem_rate of the policy limit effective on expense_date for its type, the "
                  "claimant's location band and job level",
             source=("DP-209", "Out-of-Policy Lines"),
             description="Expense lines above the policy limit; the amount is shown beside the count."),
        dict(name="Out-of-Policy Spend %", aggregation="ratio",
             numerator="sum(transaction_amount) of [Out-of-Policy Lines]",
             denominator="[T&E Spend]",
             source=("DP-209", "Out-of-Policy Spend %"),
             description="Share of approved spend above policy limits, by org unit and expense type.",
             note="Travel lines are tested against the highest location band (GAP-44-001)."),
        dict(name="Self-Approved or Off-Chain Reports", aggregation="additive",
             expr="count(expense_report) Approved whose approver is the claimant or not in the claimant's solid-line "
                  "reporting chain effective on the latest expense date",
             source=("DP-209", "Self-Approved or Off-Chain Reports"),
             description="Approved expense reports approved by the claimant or outside their management chain."),
        dict(name="Unmatched Card Transactions", aggregation="semi_additive",
             expr="count(card_transaction) with personal_spend <> 'Y' referenced by no expense_line, by age (over 30, "
                  "over 60 days); billed amount beside it",
             time_rule=_LAST, source=("DP-209", "Unmatched Card Transactions"),
             description="Corporate card transactions not yet claimed on an expense report."),
        dict(name="Personal Spend on Corporate Cards", aggregation="additive",
             expr="sum(card_transaction.billed_amount) with personal_spend = 'Y'",
             source=("DP-209", "Personal Spend on Corporate Cards"),
             description="Personal spend charged to corporate cards, by month."),
        dict(name="Active Cards of Leavers", aggregation="semi_additive",
             expr="count(corporate_card) with card_status = 'Active' whose cardholder is Terminated before the as-of date",
             time_rule=_LAST, source=("DP-209", "Active Cards of Leavers"),
             description="Corporate cards still active for people who have left."),
        dict(name="Potential Duplicate Claims", aggregation="additive",
             expr="count(expense_line) sharing claimant, expense_date, merchant_name and transaction_amount with a line "
                  "on a different expense report",
             source=("DP-209", "Potential Duplicate Claims"),
             description="Expense lines that may have been claimed twice."),
        dict(name="Entertainment Lines Without G&E Record", aggregation="additive",
             expr="count(expense_line) approved with expense_type in ('Client Entertainment', 'Gift to External Party') "
                  "and no related gift and entertainment record, or one with another giver",
             source=("DP-209", "Entertainment Lines Without G&E Record"),
             description="Entertainment and gift spend not recorded in the gifts and entertainment register."),
        dict(name="Fund Recharges", aggregation="additive",
             expr="sum(expense_line.transaction_amount) approved with recharge_fund populated, by fund and month",
             source=("DP-209", "Fund Recharges"),
             description="Expenses recharged to funds; lines with no business purpose counted separately."),
        dict(name="Approved Reports Not Reimbursed", aggregation="semi_additive",
             expr="count(expense_report) Approved with reimbursement_route in ('Accounts Payable', 'Payroll') not yet "
                  "paid, by age; expense_report_total_amount beside it",
             time_rule=_LAST, source=("DP-209", "Approved Reports Not Reimbursed"),
             description="Approved expense reports not yet reimbursed."),
        dict(name="T&E Subledger to GL Difference", aggregation="non_additive",
             expr="per legal entity and fiscal period: sum(expense_report_total_amount) of approved reports posted in the "
                  "period - sum(gl_posting.posted_amount) debits on journal_entry with journal_source = 'Travel & "
                  "Expense' in the same period",
             source=("DP-209", "T&E Subledger to GL Difference"),
             description="Difference between approved T&E and the T&E journals; expected zero."),
        dict(name="Premium Travel Share %", aggregation="ratio",
             numerator="count(travel_booking) with trip_start_date in range and travel_class in ('Business', 'First', "
                       "'Rail - First')",
             denominator="count(travel_booking) with trip_start_date in range",
             source=("DP-209", "Premium Travel Share %"),
             description="Share of trips booked in premium classes, by traveler job level and org unit."),
    ],

    excluded=[
        ("DP-201", "Snapshot Population", "The same number as [Certified Headcount] at the snapshot date (CD-341); "
                                          "Published Value Mismatches tests that they agree."),
        ("DP-201", "FTE-Adjusted Pay", "Per-employee pay that never leaves DP-201 (CD-344); only the gaps built on it "
                                       "are published."),
        ("DP-207", "Site Headcount", "[Certified Headcount] sliced by employee.work_location; not a second definition."),
    ],

    access=dict(
        classification=("Confidential - Personal Data (DP-192, DP-197, DP-200, DP-208, DP-209); Confidential - "
                        "Compensation (DP-198, DP-199); Restricted - Personal Data aggregates (DP-201); Confidential "
                        "(DP-207)"),
        roles=[
            dict(role="hr_people_analytics",
                 rows="all workers, movement, hiring, talent and training; DP-201 aggregates; no pay or awards",
                 columns="employee columns except the restricted extension; no compensation or deferred awards",
                 hidden=WORK_AUTHORIZATION + PAY + DEFERRED_AWARDS + RESTRICTED_HR),
            dict(role="hr_restricted",       # named HR roles: screening, medical leave, right to work, H&S with H&S team
                 rows="all", columns="all employee and restricted HR columns; no pay",
                 hidden=PAY + DEFERRED_AWARDS),
            dict(role="reward_and_payroll",  # Reward, payroll and the Controller's payroll accounting role
                 rows="all payroll runs, pay, awards and benefits; workers for joins",
                 columns="DP-198 and DP-199 columns and employee identity; no restricted HR detail, ratings or diversity",
                 hidden=WORK_AUTHORIZATION + RESTRICTED_HR + TALENT),
            dict(role="remuneration_committee",   # Compliance remuneration specialists and committee secretariat
                 rows="variable award recipients and their awards, deferred tranches and conduct flags",
                 columns="DP-199 columns, awards and conduct adjustment; no other pay detail",
                 hidden=WORK_AUTHORIZATION + RESTRICTED_HR + ["gross_pay_amount", "net_pay_amount",
                                                              "employer_social_charges_amount", "coverage_level"]),
            dict(role="line_manager",
                 rows="the viewer's own reports (solid-line chain) for training, reviews, leave and T&E",
                 columns="names, training, reviews and T&E of their reports; no pay, restricted HR or deferred awards",
                 hidden=EMPLOYEE_DETAIL + WORK_AUTHORIZATION + PAY + DEFERRED_AWARDS + RESTRICTED_HR),
            dict(role="workplace_and_real_estate",   # facilities, real estate, security, sustainability
                 rows="all sites, leases, occupancy, work orders, badges and incidents; H&S as site counts only",
                 columns="site, space, lease and workplace columns; no employee names or restricted HR detail",
                 hidden=NAMES + EMPLOYEE_DETAIL + WORK_AUTHORIZATION + PAY + DEFERRED_AWARDS + TALENT + RESTRICTED_HR),
            dict(role="finance_controller",
                 rows="payroll runs and journals, lease accounting, T&E and its journals",
                 columns="run-level payroll totals, lease and T&E columns; no individual pay, names or restricted detail",
                 hidden=NAMES + EMPLOYEE_DETAIL + WORK_AUTHORIZATION + DEFERRED_AWARDS + TALENT + RESTRICTED_HR +
                        ["pay_component_amount", "award_amount", "net_payable_amount"]),
            dict(role="budget_holder",
                 rows="T&E and headcount of the org units the viewer owns",
                 columns="aggregates by org unit, expense type and month; no claimant names",
                 hidden=NAMES + EMPLOYEE_DETAIL + WORK_AUTHORIZATION + PAY + DEFERRED_AWARDS + TALENT +
                        RESTRICTED_HR + CLAIMANT),
            dict(role="broad_internal",   # executives, FP&A, other models' users and AI assistants
                 rows="all; headcount, FTE, turnover, site, emissions and DP-201 published aggregates",
                 columns="aggregates by legal entity, org unit, work location, job level and period only",
                 hidden=NAMES + EMPLOYEE_DETAIL + WORK_AUTHORIZATION + PAY + DEFERRED_AWARDS + TALENT +
                        RESTRICTED_HR + CLAIMANT + LANDLORD),
        ]),

    verified_questions=[
        dict(question="What were certified headcount and FTE by legal entity and employment type at the last quarter end, "
                      "against authorized FTE?",
             answer="[Certified Headcount] and [Certified FTE] at the quarter-end period end date (worker and primary "
                    "assignment versions effective on that date), grouped by employee.employing_legal_entity and "
                    "employee.employment_type; [Authorized FTE] and [FTE Variance to Authorized] by "
                    "workforce_position.position_legal_entity. [Contingent Worker Count] shown beside, never added.",
             sql="select e.employing_legal_entity, e.employment_type, count(distinct e.employee_id) as certified_headcount, "
                 "sum(a.assignment_fte) as certified_fte "
                 "from dp_192.employee e join dp_192.employee_job_assignment a on a.assigned_worker = e.employee_id "
                 "and a.assignment_type = 'Primary' and a.assignment_effective_from <= :period_end "
                 "and (a.assignment_effective_to is null or a.assignment_effective_to > :period_end) "
                 "where e.employment_status in ('Active', 'Leave of Absence', 'Notice Period', 'Garden Leave') "
                 "and e.contingent_worker_type is null and :period_end between e.effective_from and "
                 "coalesce(e.effective_to, date '9999-12-31') group by 1, 2"),
        dict(question="What was annualized voluntary turnover by org unit over the last 12 months?",
             answer="[Voluntary Turnover Rate %]: [Leavers] with voluntary_termination = 'Y' (employees only, Death and "
                    "Transfer to Affiliate excluded) over the trailing 12 months / [Average Headcount] as the mean of the "
                    "13 month-end [Certified Headcount] values, grouped by employee.home_org_unit."),
        dict(question="How much gross pay did we pay by legal entity and payroll currency this year, and which runs do "
                      "not tie to their journals?",
             answer="[Gross Pay Paid] (pay_date this year, run status Paid or Posted to GL) grouped by "
                    "payroll_run.payroll_run_legal_entity and payroll_result.payroll_currency; [Runs Not Reconciled] and "
                    "[Run-to-Journal Difference] per payroll_run. [Certified Compensation Expense] from SM-14 by legal "
                    "entity and period is the comparison, not a substitute."),
        dict(question="How much deferred remuneration is still unvested by vesting year and entity, and how much "
                      "vested pay is still under clawback?",
             answer="[Unvested Deferred Remuneration] by year of deferred_tranche.vesting_date and the recipient's "
                    "employing legal entity, with [Remuneration Under Clawback] at the latest as-of date."),
        dict(question="Which sites have the most area per head and the lowest utilization?",
             answer="[Area per Head] ([Site Gross Area] / [Certified Headcount] by employee.work_location at the latest "
                    "month end) and [Average Utilization %] for that month, by site (DP-013 Office Location) and "
                    "site_profile.site_type."),
        dict(question="What were Scope 1 and market-based Scope 2 emissions per employee by entity last year?",
             answer="[Emissions per Employee]: [Operational Emissions] from emission_entity (entity totals only) for "
                    "Scope 1 and Scope 2 market-based / [Certified Headcount] of the entity at the year end."),
    ],

    cannot_answer=[
        dict(question="The gender pay gap on hourly pay (state pay data reporting or voluntary disclosure)",
             why="Standard Weekly Hours and Hours Worked are defined (CD-364) but not yet populated, so DP-201's gaps "
                 "are indicative on FTE-adjusted annual pay and no statutory figure is published.",
             gap="GAP-20-001"),
        dict(question="How much incentive or bonus was paid through payroll, by employee or period",
             why="Payroll Result has no pay component breakdown, so incentive paid cannot be separated from gross pay.",
             gap="GAP-20-002"),
        dict(question="What do benefits cost the firm per plan or per employee?",
             why="Benefit Plan and Benefit Enrollment carry no premium or employer cost; benefit cost sits in DP-191 "
                 "expense accounts.",
             gap="GAP-20-009"),
        dict(question="Compa-ratio or position in pay range by job level",
             why="Job Profile has no pay grade or pay range.",
             gap="GAP-20-010"),
        dict(question="Training hours per employee (ISO 30414)",
             why="Learning Item has no duration or hours.",
             gap="GAP-20-003"),
        dict(question="Time from offer to start, or reimbursement cycle time for expenses",
             why="Job Requisition has no offer accepted or planned start date (GAP-20-008), and Expense Report has no "
                 "submission or approval date (GAP-44-001).",
             gap="GAP-20-008"),
    ],

    open_decisions=[
        "W1b: employee.off_payroll_determination (DP-192 Off-Payroll Working Determination) removed, no US successor (CW-920).",
        "W1b: DP-199 mrt_identification and remuneration_conflict tables, their three joins, "
        "deferred_tranche.retention_period_end_date and the metrics Identified MRTs, Identifications Not Approved, Senior "
        "Managers Not Identified, Deferral Shortfalls, Invalid Deferral Exemptions, Early Releases Before Retention End and "
        "Identified Staff Copy Mismatches removed, no US successor (CW-920). Total Variable Remuneration, Fixed "
        "Remuneration, Variable-to-Fixed Ratio and Instrument Share % are re-pointed to award recipient and performance "
        "year (variable_award.linked_fund added for the fund-linked part); Remuneration Under Clawback reads Vested only. "
        "The REMUNERATION_CODE column group becomes DEFERRED_AWARDS.",
        "W1b: hs_incident.riddor_reportable (DP-208 RIDDOR Reportable Indicator) removed, no US successor (CW-944); "
        "Recordable and Reportable Incidents counts OSHA-reported incidents by regulatory_report_date and Late RIDDOR "
        "Reports is replaced by Late OSHA Severe Injury Reports (29 CFR 1904.39).",
        "W1b re-point (CW-920): DP-201 Ethnicity Pay Gap and Worker Categories With Gap of 5% or More are described on US "
        "race / ethnicity categories and the firm's pay equity trigger; the UK and EU statutory pay gap wording is removed.",
        "Employee dimension: SM-00 publishes employee from DP-192 for the other models; SM-15 publishes the same entity "
        "as its own employee table with the HR columns. Both must stay in step (same Employee ID, same SCD2 version "
        "rule). Agree with the SM-00 owner whether SM-00's copy should drop its columns in favor of SM-15's, or SM-15 "
        "should join to 'DP-192/Employee' through SM-00 once the access rules are aligned.",
        "SM-00 hides every employee column from all roles but HR because DP-192 flags all of them PII. This model shows "
        "employing legal entity, home org unit, work location, employment type and job level to broad roles as grouping "
        "columns only (no names, no row-level export). Confirm with the Data Protection Officer that org placement and "
        "employment type may be shown in aggregates; otherwise hide them in broad_internal and budget_holder.",
        "DP-192 Employee, Workforce Position and Employee Job Assignment are SCD type 2, but the logical model lists no "
        "validity columns on Employee (only on assignments, positions and reporting lines). Certified Headcount needs "
        "the worker version effective on the period end; add the effective-from and effective-to columns to the "
        "Employee entity in models_e8_masters.py.",
        "CD-341 says 'Employment Status active'; it is applied as every employed status (Active, Leave of Absence, "
        "Notice Period, Garden Leave) as ruled 2026-10-14. Still Proposed in the decision register: confirm with the "
        "CHRO before the model is Confirmed.",
        "DP-192 Joiners, Movers and Leavers counts every worker's events (contingent included); DP-197 Hires and "
        "Leavers count employees only. The model publishes both, the first as 'Joiner, Mover and Leaver Events'. "
        "Decide whether DP-192's measure should exclude contingent workers so the two agree.",
        "W4 (CW-907, CW-930): DP-198 reads 03 Compensation Statement; the payment_instruction table and the metrics "
        "Incentive Instructions Unpaid, Incentive Instructions Unpaid Amount and Incentive Paid vs Earned Difference are "
        "replaced by Incentive Statements Unpaid and its amount (paid versus earned per statement needs a paid amount per "
        "statement on 20 Payroll Result: taxonomy gap). variable_award.carried_interest_points removed with 20 Carried "
        "Interest Points.",
        "Incentive earned: DP-033 is superseded by DP-390 (CW-207), published by SM-29, whose Incentive Earned by "
        "Component reads 03 Compensation Statement. WP2 (CW-209): once SM-29's file lands, add a ref to it beside Gross "
        "Pay Paid (CD-347) so firm-wide incentive earned and pay paid sit side by side; not added now because SM-29 is "
        "still being written.",
        "Gross Pay Paid is held in Payroll Currency with no conversion. Decide the reporting-currency rule (rate type "
        "and date) so firm-wide totals can be shown; until then the metric must be grouped or filtered by currency.",
        "DP-201's measures are cells of Human Capital Metric Value, identified by Metric Definition (a 21 KPI- key from "
        "DP-101, an SM-17 product this model cannot read). The model filters by metric definition key; confirm the KPI- "
        "ids for each DP-201 measure and whether DP-101's Metric Definition should be a shared SM-00 dimension.",
        "Four DP-201 pay gap metrics carry '(Indicative)' in their names (CD-364). Rename them to the spec names once "
        "Standard Weekly Hours and Hours Worked are populated and the measures re-specify on hourly pay.",
        "DP-209's logical model joins Expense Line to Expense Policy Limit on expense type only (many-to-many); Out-of-"
        "Policy Lines also needs location band, job level and the effective date. Add those to the join in the DP-209 "
        "logical model.",
        "DP-207 Fact Operational Emission holds site rows and entity totals in one fact; the model reads it twice with a "
        "pinned record level. Confirm the Emission Record Level values ('Site', 'Entity Total').",
        "DP-207 Lease Accounting Measurement is versioned by measurement date; the model pins the latest on or before "
        "the month end. If lease accounting moves to the ERP (CD-345, 44 SME Q2) the table moves to DP-193 (SM-14).",
        "DP-207 and DP-208 are withdrawn if the client drops Data Domain 44 (CD-345); DP-209 then moves to 19. Revisit "
        "this model's scope at that decision.",
        "Background screening results, medical leave types and health and safety incident detail are visible only to "
        "hr_restricted; name the HR and Health & Safety roles that hold it (CD-344).",
    ],
)
