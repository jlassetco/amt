"""Semantic model SM-20 Client Assets & Flows. See CONTRACT.md.

Publishes DP-008 Client Assets & Net New Assets, DP-006 Client Flow Transactions, DP-007 Client Asset Positions, DP-490
Client Assets & Flows Executive Scorecard, DP-491 Net New Assets by Channel, Offering & Advisor, DP-492 Net New Assets by
Campaign & Acquisition Cohort, DP-495 Client Asset Data Supply Chain, Reconciliation & Suspense and DP-496 Client Asset
Mix & Own-Fund Penetration (WP2, CW-209). Owns the CW-011 client-asset family in register.CERTIFIED (Client Assets,
Beginning and Average Client Assets, Net New Assets, Advised Assets, Client Market Movement and Other, Net Inter-Channel
Transfers, Client Organic Growth Rate, Own-Fund Overlap, Gross Sales, Redemptions, Net Flows, Funded Accounts, Clients,
Households); every other model references them with ref="SM-20/<name>". Firm AUM and its slices are SM-11's (DP-241),
and the reconciliation between Client Assets and Firm AUM is DP-241's: both are referenced here, never summed.
"""

# DP-008 Measure Value is keyed by measure x period end x Dimension Type x Dimension Key x data basis x snapshot, one
# dimension per row (CW-141, CW-203). The rows of one Dimension Type, unattributed members included, add up to the firm
# total (except the distinct counts, which are Non-Additive), so every query pins exactly one Dimension Type: mixing two
# types counts the same money twice.
DIMENSION_TYPES = ["Total", "Channel", "Holding Type", "Business Line", "Advisor", "Campaign", "Share Class", "Segment"]
DIMENSION_TYPE_PIN = ("dimension_type = one of " + ", ".join(f"'{t}'" for t in DIMENSION_TYPES) +
                      ", single select, default 'Channel' (one dimension per row, CW-141)")
PERIOD_TYPE_PIN = ("period_type = one value per query (single select, default 'Month'); quarter and year-to-date rows "
                   "are never added to the months they contain")
# Locked snapshot of record: Snapshot Type Final or Restated (the monthly locked versions) and not superseded by a later
# locked version after a restatement; Flash (daily) snapshots are never read by this table.
CURRENT_LOCKED = ("locked snapshot only: snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in "
                  "('Final', 'Restated') and snapshot_id not in (select supersedes_snapshot from dp_008.snapshot where "
                  "snapshot_type in ('Final', 'Restated') and supersedes_snapshot is not null))")

_LAST = "last period end in the selected range"
_CODE = "code_value.code (DP-013 code list: {})"

MODEL = dict(
    id="SM-20",
    status="Draft",
    description=("Certified client assets, net new assets, advised assets and the counts of funded accounts, clients and "
                 "households, by channel, business line, holding type, share class, segment, advisor and campaign, with "
                 "the client flow transactions and asset summaries behind them, the executive scorecard and the health "
                 "of the client asset data supply chain. Used by channel and business-line leadership, client and channel "
                 "analytics, finance and the Data Office. Owns the certified client-asset family that every other model "
                 "references; Firm AUM is SM-11's and is shown beside Client Assets, never added to it."),
    questions=[
        "What were Client Assets at the month-end by channel and by holding type, and how do they reconcile to Firm AUM?",
        "What were net new assets last quarter by channel, advisor of record and campaign, and how much came from deposits, transfers and rollovers?",
        "How did Client Assets move from the start of the year to now: net new assets, inter-channel transfers and market movement, by channel?",
        "How many funded accounts, clients and households does each channel have, and how is the household count changing?",
        "What share of client assets is in our own funds, by channel and offering, and where does the rest go?",
        "Can the month-end client asset figures be relied on: loads, reconciliation breaks and unattributed suspense?",
    ],

    tables=[
        # =========================== DP-008 certified client assets and flows ===========================================
        dict(name="client_assets_flows", product="DP-008", entity="Measure Value", kind="Fact",
             grain="measure row x one dimension type x dimension key x period end x data basis (locked snapshot of record)",
             always_filter=[DIMENSION_TYPE_PIN, PERIOD_TYPE_PIN, CURRENT_LOCKED],
             default_filter="period_end_date = the latest locked month-end",
             dimensions=[
                 dict(name="period_end_date", attr="Period End Date"),
                 dict(name="period_start_date", attr="Period Start Date"),
                 dict(name="period_type", attr="Period Type", note="Pinned to one value per query (always filter)."),
                 dict(name="reporting_period", attr="Reporting Period"),
                 dict(name="dimension_type", attr="Dimension Type", note="Pinned to one value per query (always filter)."),
                 dict(name="dimension_key", attr="Dimension Key",
                      note=("Channel, holding type, business line or segment code (DP-013 code lists), share class "
                            "(DP-004), advisor (DP-009 EMP-) or campaign (DP-011, through DP-492) per dimension_type; "
                            "'ALL' on Total rows; includes the unattributed member, so the rows of one type add up to Total.")),
                 dict(name="data_basis", attr="Data Basis", note="Actual or estimated."),
                 dict(name="snapshot", attr="Snapshot"),
                 dict(name="measure", attr="Measure", note="The 06 Measure Definition (MSR-) of the row."),
             ],
             facts=[
                 dict(name="ending_client_assets", attr="Ending Client Assets"),
                 dict(name="beginning_client_assets", attr="Beginning Client Assets"),
                 dict(name="average_client_assets", attr="Average Client Assets"),
                 dict(name="net_new_assets", attr="Net New Assets"),
                 dict(name="advised_assets", attr="Advised Assets"),
                 dict(name="client_market_movement_other", attr="Client Market Movement and Other"),
                 dict(name="net_inter_channel_transfers", attr="Net Inter-Channel Transfers"),
                 dict(name="client_organic_growth_rate", attr="Client Organic Growth Rate",
                      note="Row ratio; the metric recomputes it as a ratio of sums."),
                 dict(name="client_assets_excl_intermediary", attr="Client Assets Excluding Intermediary-Held"),
                 dict(name="own_fund_overlap_amount", attr="Own-Fund Overlap Amount"),
                 dict(name="gross_sales", attr="Gross Sales"),
                 dict(name="redemptions", attr="Redemptions"),
                 dict(name="net_exchanges", attr="Net Exchanges"),
                 dict(name="net_flows", attr="Net Flows"),
                 dict(name="funded_accounts", attr="Funded Accounts"),
                 dict(name="clients", attr="Clients"),
                 dict(name="households", attr="Households"),
                 dict(name="restatement_impact", attr="Restatement Impact"),
             ],
             hidden=[
                 ("Measure Amount", "The long form of the same values; the model reads the named measure columns."),
                 ("Attributed Share %", "Attribution weight of the row; no cross-row question reads it."),
                 ("Beginning AUM", "06 Asset Measures own-fund view kept as a DP-008 input; no measure is named AUM (CW-203)."),
                 ("Ending AUM", "06 Asset Measures own-fund view; Client Assets is read instead."),
                 ("Average AUM", "06 Asset Measures own-fund view; Average Client Assets is read instead."),
                 ("Market Movement", "06 Asset Measures own-fund view; Client Market Movement and Other is read instead."),
                 ("Organic Growth Rate", "06 Asset Measures own-fund view; Client Organic Growth Rate is read instead."),
                 ("Net Flows (Net Sales)", "The same number as Net Flows; published once."),
                 ("Reinvested Distributions", "Excluded from Gross Sales by the certified rule; no published question uses it."),
                 ("Distribution Channel", "Read through dimension_key on Channel rows (one dimension per row)."),
                 ("Business Line", "Read through dimension_key on Business Line rows."),
                 ("Service Offering", "Not a DP-008 Dimension Type; offering cuts come from DP-491 and DP-496."),
                 ("Covering Advisor", "Personal data; read through dimension_key on Advisor rows (restricted)."),
                 ("Advisor Coverage Assignment", "Lineage of the Advisor rows; not a reporting column."),
                 ("Client Household", "Personal data; DP-008 has no household Dimension Type (household assets are DP-320's, SM-21)."),
                 ("Attributed Campaign", "Read through dimension_key on Campaign rows."),
                 ("Campaign Attribution Weight", "Already applied in the Campaign rows' amounts."),
             ]),
        dict(name="snapshot", product="DP-008", entity="Snapshot", kind="Dimension",
             dimensions=[
                 dict(name="snapshot_id", attr="Snapshot ID"),
                 dict(name="snapshot_type", attr="Snapshot Type", note="Flash (daily), Final or Restated (locked)."),
                 dict(name="snapshot_as_of_date", attr="As-Of Date",
                      note="Shown on every view so readers know which locked version they see."),
                 dict(name="supersedes_snapshot", attr="Supersedes Snapshot"),
             ],
             hidden=[("Approved By", "Names an employee; kept in DP-008.")]),
        dict(name="reporting_period", product="DP-008", entity="Reporting Period", kind="Dimension",
             dimensions=[
                 dict(name="reporting_period_id", attr="Reporting Period ID"),
                 dict(name="rp_period_type", attr="Period Type"),
                 dict(name="final_close_date", attr="Final Close Date"),
             ]),
        dict(name="measure_definition", product="DP-008", entity="Measure Definition", kind="Dimension",
             dimensions=[
                 dict(name="measure_id", attr="Measure ID"),
                 dict(name="measure_name", attr="Measure Name"),
                 dict(name="aggregation_behavior", attr="Aggregation Behavior",
                      note="Non-Additive for the distinct counts: their keys do not add to Total."),
                 dict(name="certified_indicator", attr="Certified Indicator"),
                 dict(name="income_treatment", attr="Income Treatment"),
                 dict(name="fee_treatment", attr="Fee Treatment"),
                 dict(name="transfer_treatment", attr="Transfer Treatment"),
                 dict(name="rollover_treatment", attr="Rollover Treatment"),
                 dict(name="inter_channel_transfer_treatment", attr="Inter-Channel Transfer Treatment"),
                 dict(name="exchange_treatment", attr="Exchange Treatment"),
             ]),

        # =========================== DP-006 client flow transactions ====================================================
        # The flow rows behind the NNA attribution rows (DP-491, DP-492) and the inter-channel transfers. Pre-treatment
        # amounts are never NNA: the certified rule is applied in DP-008 only (one NNA rule, lead ruling).
        dict(name="flow_transactions", product="DP-006", entity="Transaction", kind="Fact",
             grain="transaction leg x cancel / correct version (current version only)",
             always_filter=["current version of each transaction only: the highest version per Flow Source Book and "
                            "Source Transaction Reference, transaction_status not in ('Canceled', 'Reversed', 'Rejected')"],
             dimensions=[
                 dict(name="transaction_id", attr="Transaction ID"),
                 dict(name="trade_date", attr="Trade Date"),
                 dict(name="transaction_type", attr="Transaction Type"),
                 dict(name="flow_direction", attr="Flow Direction"),
                 dict(name="flow_scope", attr="Flow Scope",
                      note="Client Asset Flow, Fund Flow, Client Asset and Fund Flow or Inter-Channel Transfer."),
                 dict(name="txn_holding_type", attr="Holding Type"),
                 dict(name="txn_share_class", attr="Share Class"),
                 dict(name="flow_source_book", attr="Flow Source Book"),
                 dict(name="order_entry_channel", attr="Order Entry Channel"),
                 dict(name="contribution_source_type", attr="Contribution Source Type"),
                 dict(name="transaction_status", attr="Transaction Status"),
                 dict(name="txn_account", attr="Account", note="Client account (DP-093); restricted to analytics and stewards."),
                 dict(name="source_client_account_activity", attr="Source Client Account Activity",
                      note="The 49 activity copied by the row; its Source Money Movement names the 50 movement."),
             ],
             facts=[
                 dict(name="reporting_currency_amount", attr="Reporting Currency Amount"),
                 dict(name="gross_amount", attr="Gross Amount",
                      note="Carries the amount of inter-channel transfer rows (the account's summary total for generated rows)."),
             ],
             hidden=[
                 ("Resolved Advisor / Rep", "Intermediary representative; personal data."),
                 ("Dealer / Firm Number", "Intermediary feed identifier; resolution quality is DP-495's."),
                 ("Authorized Participant", "ETF creation counterparty; not a client asset question."),
                 ("Sponsor Program", "SMA sponsor; intermediary partner flows are SM-27's (DP-493)."),
                 ("Units", "Share quantities; amounts are read in USD."),
             ]),
        dict(name="flow_linked_transactions", product="DP-006", entity="Linked Transaction", kind="Fact",
             grain="transaction x linked contra transaction (exchange, transfer, journal, rollover or conversion pair)",
             dimensions=[
                 dict(name="linked_transaction_key", attr="Transaction Key"),
                 dict(name="linked_transaction_id", attr="Linked Transaction ID"),
                 dict(name="transfer_type", attr="Transfer Type"),
                 dict(name="same_owner_indicator", attr="Same-Owner Indicator"),
                 dict(name="from_distribution_channel", attr="From Distribution Channel"),
                 dict(name="to_distribution_channel", attr="To Distribution Channel"),
             ]),

        # =========================== DP-007 client asset positions ======================================================
        # Account Asset Summary: the copy of each account's book (49, 16, 29, 18) that DP-008 sums into Client Assets.
        dict(name="account_asset_summary", product="DP-007", entity="Account Asset Summary", kind="Fact",
             grain="firm client account x as-of date x holding type",
             always_filter=["summary_as_of_date is a month-end business day (the DP-008 period ends)"],
             default_filter="summary_as_of_date = the latest locked month-end",
             dimensions=[
                 dict(name="summary_as_of_date", attr="Summary As-Of Date"),
                 dict(name="summary_holding_type", attr="Summary Holding Type"),
                 dict(name="summary_source_book", attr="Summary Source Book"),
                 dict(name="summary_distribution_channel", attr="Summary Distribution Channel"),
                 dict(name="own_product_indicator", attr="Own-Product Indicator"),
                 dict(name="advised_assets_indicator", attr="Advised Assets Indicator"),
                 dict(name="summary_account", attr="Summary Account", note="Client account (DP-093); restricted."),
             ],
             facts=[dict(name="summary_market_value", attr="Summary Market Value",
                         note="Net equity under DP-007's client cash rule.")],
             hidden=[("Source As-Of Timestamp", "Staleness test of DP-007 (Stale Summaries), not a reporting column.")]),
        # Fund Shareholder Positions held through intermediaries only. Positions of firm client accounts are views of
        # Client Holding (49) or the register (29) (CW-007) and are already in account_asset_summary: they are filtered out.
        dict(name="intermediary_positions", product="DP-007", entity="Position", kind="Fact",
             grain="intermediary or omnibus position: account or sub-account x own share class x valuation date x position source",
             always_filter=["aggregation_role = 'Counted - Intermediary', or the row carries an Omnibus Residual Amount; "
                            "rows of firm client accounts (Counted - Firm Client Account: views of 49 and 29, CW-007) and "
                            "every Excluded and Attribution Only role are left out",
                            "positions from the source that wins under Source Precedence Rank only (derived until GAP-06-007)",
                            "valuation_date is a month-end business day (the DP-008 period ends)"],
             default_filter="valuation_date = the latest locked month-end",
             dimensions=[
                 dict(name="position_id", attr="Position ID"),
                 dict(name="pos_share_class", attr="Share Class"),
                 dict(name="valuation_date", attr="Valuation Date"),
                 dict(name="position_source_book", attr="Position Source Book"),
                 dict(name="aggregation_role", attr="Aggregation Role"),
                 dict(name="omnibus_parent_account", attr="Omnibus Parent Account", note="Restricted (account key)."),
             ],
             facts=[
                 dict(name="position_market_value", attr="Market Value"),
                 dict(name="omnibus_residual_amount", attr="Omnibus Residual Amount",
                      note="Taken once per omnibus parent account x share class x valuation date."),
             ],
             hidden=[("Account", "Sub-account key of the intermediary row; personal data."),
                     ("Units Held", "Unit reconciliation is DP-007's and DP-241's; amounts are read in USD.")]),

        # =========================== DP-496 client asset mix =============================================================
        dict(name="asset_attribution", product="DP-496", entity="Fact Attribution Record", kind="Fact",
             grain="attribution record of a month-end account summary or intermediary position (split by channel and offering)",
             always_filter=["source summary or position is on a month-end business day"],
             dimensions=[
                 dict(name="asset_attribution_id", attr="Attribution Record ID"),
                 dict(name="source_position", attr="Source Position"),
                 dict(name="source_account_asset_summary", attr="Source Account Asset Summary"),
                 dict(name="asset_distribution_channel", attr="Distribution Channel"),
                 dict(name="asset_service_offering", attr="Service Offering"),
             ],
             facts=[dict(name="asset_attributed_amount", attr="Attributed Amount")]),
        # Client Holding (49) for the own-fund tie-out and the third-party wallet; never added to account_asset_summary,
        # whose 49 rows are copies of the same book.
        dict(name="brokerage_client_holdings", product="DP-496", entity="Fact Client Holding", kind="Fact",
             grain="brokerage client holding x holding date (End of Day view)",
             always_filter=["client_holding_view = 'End of Day'",
                            "client_holding_date is a month-end business day (the DP-008 period ends)"],
             dimensions=[
                 dict(name="client_holding_date", attr="Client Holding Date"),
                 dict(name="client_holding_view", attr="Client Holding View"),
                 dict(name="held_instrument", attr="Held Instrument"),
                 dict(name="own_share_class_indicator", attr="Own Share Class Indicator"),
                 dict(name="holding_account", attr="Holding Account", note="Client account (DP-093); restricted."),
             ],
             facts=[dict(name="holding_market_value_usd", attr="Market Value in USD")],
             hidden=[("Client Holding ID", "Row key of the 49 book; not a reporting column.")]),

        # =========================== DP-491 NNA by channel, offering and advisor =========================================
        # The attribution records DP-008 counts in MSR-NNA (inter-channel transfer rows excluded), as DP-491 publishes them.
        dict(name="nna_attribution", product="DP-491", entity="Fact Attribution Record", kind="Fact",
             grain="attribution record counted in Net New Assets (transaction x channel, offering, advisor and household)",
             always_filter=["only the rows DP-491 publishes as NNA Attribution Rows (from DP-008) for the locked snapshot "
                            "of the period (no attribute marks them; see cannot_answer)",
                            "source_record_type = 'Transaction'",
                            "the source transaction's flow_scope <> 'Inter-Channel Transfer'"],
             dimensions=[
                 dict(name="nna_attribution_id", attr="Attribution Record ID"),
                 dict(name="nna_source_transaction", attr="Source Transaction"),
                 dict(name="nna_source_record_type", attr="Source Record Type"),
                 dict(name="nna_effective_date", attr="Attribution Effective Date"),
                 dict(name="nna_distribution_channel", attr="Distribution Channel"),
                 dict(name="nna_business_line", attr="Business Line"),
                 dict(name="nna_service_offering", attr="Service Offering"),
                 dict(name="nna_covering_advisor", attr="Covering Advisor", note="Advisor of record (DP-009 EMP-); restricted."),
                 dict(name="nna_coverage_assignment", attr="Advisor Coverage Assignment"),
                 dict(name="nna_client_household", attr="Client Household",
                      note="Grouping key only (household movement); household rows are never shown."),
                 dict(name="nna_attribution_method", attr="Attribution Method"),
             ],
             facts=[dict(name="nna_attributed_amount", attr="Attributed Amount", note="Signed by Flow Direction.")]),
        dict(name="salesperson_credit", product="DP-491", entity="Salesperson Credit", kind="Bridge",
             grain="NNA attribution record x credited salesperson x credit role (IC and IA lines only)",
             dimensions=[
                 dict(name="credit_attribution_record", attr="Fact Attribution Record Key"),
                 dict(name="credited_salesperson", attr="Credited Salesperson", note="Employee; restricted."),
                 dict(name="source_partner_coverage", attr="Source Partner Coverage Assignment"),
                 dict(name="credit_role", attr="Credit Role"),
             ],
             facts=[dict(name="credit_split_pct", attr="Credit Split %")]),
        dict(name="client_account_activity", product="DP-491", entity="Client Account Activity", kind="Dimension",
             dimensions=[
                 dict(name="client_account_activity_id", attr="Client Account Activity ID"),
                 dict(name="activity_type", attr="Activity Type"),
                 dict(name="source_money_movement", attr="Source Money Movement"),
             ],
             hidden=[("Activity Net Amount", "Amounts are read from the flow row; the 49 activity is a lineage key."),
                     ("Activity Account", "Client account key; personal data.")]),
        dict(name="money_movement", product="DP-491", entity="Money Movement", kind="Dimension",
             dimensions=[
                 dict(name="money_movement_id", attr="Money Movement ID"),
                 dict(name="money_movement_type", attr="Money Movement Type"),
                 dict(name="payment_rail", attr="Payment Rail"),
             ],
             hidden=[("Movement Amount", "Lineage only; never a flow (DP-008 convention)."),
                     ("Beneficiary Bank Identifier", "Payment detail; personal data, kept in DP-302."),
                     ("Bank Instruction Used", "Payment detail; personal data, kept in DP-302.")]),

        # =========================== DP-492 NNA by campaign and acquisition cohort =======================================
        # DP-011 Campaign is not an SM-00 product: the campaign cut is DP-492's own conformed Campaign dimension.
        dict(name="campaign", product="DP-492", entity="Campaign", kind="Dimension",
             dimensions=[
                 dict(name="campaign_id", attr="Campaign ID"),
                 dict(name="campaign_name", attr="Campaign Name"),
                 dict(name="campaign_level", attr="Campaign Level"),
                 dict(name="parent_campaign", attr="Parent Campaign"),
                 dict(name="campaign_type", attr="Campaign Type"),
                 dict(name="campaign_status", attr="Campaign Status"),
                 dict(name="campaign_business_line", attr="Campaign Business Line"),
                 dict(name="marketing_theme", attr="Marketing Theme"),
             ]),
        dict(name="campaign_attribution", product="DP-492", entity="Fact Attribution Record", kind="Fact",
             grain="NNA attribution record with its attributed campaign and weight",
             always_filter=["only the rows DP-008 counts in MSR-NNA for the locked snapshot (as DP-492 publishes them)",
                            "the source transaction's flow_scope <> 'Inter-Channel Transfer'"],
             dimensions=[
                 dict(name="campaign_attribution_id", attr="Attribution Record ID"),
                 dict(name="campaign_source_transaction", attr="Source Transaction"),
                 dict(name="campaign_source_record_type", attr="Source Record Type"),
                 dict(name="campaign_distribution_channel", attr="Distribution Channel"),
                 dict(name="attributed_campaign", attr="Attributed Campaign"),
                 dict(name="source_attributed_outcome", attr="Source Attributed Outcome"),
             ],
             facts=[
                 dict(name="campaign_attributed_amount", attr="Attributed Amount"),
                 dict(name="campaign_attribution_weight", attr="Campaign Attribution Weight"),
             ]),
        dict(name="attributed_outcome", product="DP-492", entity="Fact Attributed Outcome", kind="Fact",
             grain="acquisition milestone x campaign x attribution model",
             default_filter="attribution model = the primary model (Primary Model Indicator Y)",
             dimensions=[
                 dict(name="outcome_type", attr="Outcome Type"),
                 dict(name="attributed_milestone", attr="Attributed Milestone"),
                 dict(name="outcome_campaign", attr="Attributed Campaign"),
                 dict(name="applied_attribution_model", attr="Applied Attribution Model"),
             ],
             facts=[
                 dict(name="attribution_weight", attr="Attribution Weight"),
                 dict(name="outcome_attributed_amount", attr="Attributed Amount"),
             ]),
        dict(name="attribution_model", product="DP-492", entity="Attribution Model", kind="Dimension",
             dimensions=[
                 dict(name="attribution_model_key", attr="Attribution Model Key"),
                 dict(name="attribution_model_id", attr="Attribution Model ID"),
                 dict(name="attribution_model_type", attr="Attribution Model Type"),
                 dict(name="lookback_window", attr="Lookback Window"),
                 dict(name="primary_model_indicator", attr="Primary Model Indicator"),
             ]),
        dict(name="acquisition_milestone", product="DP-492", entity="Fact Acquisition Milestone", kind="Fact",
             grain="party x milestone type x milestone date x account",
             dimensions=[
                 dict(name="milestone_party", attr="Milestone Party", note="Grouping key to the household; never shown."),
                 dict(name="milestone_type", attr="Milestone Type"),
                 dict(name="milestone_date", attr="Milestone Date"),
                 dict(name="milestone_account", attr="Milestone Account", note="Grouping key; never shown."),
             ]),
        dict(name="marketing_touchpoint", product="DP-492", entity="Fact Marketing Touchpoint", kind="Fact",
             grain="party x touchpoint timestamp x touchpoint type",
             dimensions=[
                 dict(name="touchpoint_party", attr="Touchpoint Party", note="Grouping key to the household; never shown."),
                 dict(name="touchpoint_timestamp", attr="Touchpoint Timestamp"),
                 dict(name="touchpoint_type", attr="Touchpoint Type"),
                 dict(name="touchpoint_campaign", attr="Touchpoint Campaign"),
             ]),

        # =========================== DP-490 executive scorecard: plan and forecast ======================================
        dict(name="plan_version", product="DP-490", entity="Plan Version", kind="Dimension",
             default_filter="plan_version_status = 'Approved' and plan_fiscal_year = the current fiscal year",
             dimensions=[
                 dict(name="plan_version_id", attr="Plan Version ID"),
                 dict(name="plan_type", attr="Plan Type", note="Annual Budget or Rolling Forecast."),
                 dict(name="scenario", attr="Scenario"),
                 dict(name="plan_fiscal_year", attr="Plan Fiscal Year"),
                 dict(name="plan_version_status", attr="Plan Version Status"),
             ]),
        dict(name="flow_revenue_forecast", product="DP-490", entity="Fact Flow & Revenue Forecast", kind="Fact",
             grain="plan version x forecast share class or product x forecast channel",
             always_filter=["one plan version per side of a comparison (Rolling Forecast current version, Annual Budget)"],
             dimensions=[
                 dict(name="forecast_plan_version", attr="Plan Version Key"),
                 dict(name="forecast_channel", attr="Forecast Channel"),
             ],
             facts=[
                 dict(name="forecast_gross_sales", attr="Forecast Gross Sales"),
                 dict(name="forecast_redemptions", attr="Forecast Redemptions"),
                 dict(name="forecast_net_revenue", attr="Forecast Net Revenue"),
                 dict(name="forecast_net_fee_rate", attr="Forecast Net Fee Rate"),
                 dict(name="forecast_average_client_assets", attr="Forecast Average AUM",
                      note="10 catalog name; the forecast's average client asset basis, not Firm AUM."),
             ]),
        dict(name="plan_line", product="DP-490", entity="Fact Plan Line", kind="Fact",
             grain="plan version x P&L line x dimension members x plan period",
             always_filter=["one plan version per query"],
             dimensions=[
                 dict(name="line_plan_version", attr="Plan Version Key"),
                 dict(name="plan_pl_line", attr="Plan P&L Line"),
                 dict(name="plan_dimension_members", attr="Plan Dimension Members"),
                 dict(name="plan_period", attr="Plan Period"),
                 dict(name="plan_reporting_period", attr="Reporting Period Key"),
             ],
             facts=[dict(name="planned_amount", attr="Planned Amount")]),
        dict(name="plan_variance", product="DP-490", entity="Fact Plan Variance", kind="Fact",
             grain="plan version x compared plan version x variance line",
             dimensions=[
                 dict(name="variance_plan_version", attr="Plan Version Key"),
                 dict(name="compared_plan_version", attr="Compared Plan Version"),
                 dict(name="variance_driver", attr="Variance Driver"),
                 dict(name="variance_commentary", attr="Variance Commentary"),
             ],
             facts=[dict(name="variance_amount", attr="Variance Amount")]),

        # =========================== DP-495 client asset data supply chain ==============================================
        dict(name="feed_load", product="DP-495", entity="Fact Load", kind="Fact",
             grain="data feed x business date load",
             dimensions=[
                 dict(name="load_id", attr="Load ID"),
                 dict(name="load_feed", attr="Feed"),
                 dict(name="business_date", attr="Business Date"),
                 dict(name="load_status", attr="Load Status"),
             ],
             facts=[
                 dict(name="record_count", attr="Record Count"),
                 dict(name="rejected_record_count", attr="Rejected Record Count"),
                 dict(name="control_total", attr="Control Total"),
             ]),
        dict(name="data_feed", product="DP-495", entity="Data Feed", kind="Dimension",
             dimensions=[
                 dict(name="feed_id", attr="Feed ID"),
                 dict(name="feed_name", attr="Feed Name"),
                 dict(name="data_provider", attr="Data Provider"),
                 dict(name="feed_type", attr="Feed Type"),
                 dict(name="delivery_frequency", attr="Delivery Frequency"),
                 dict(name="feed_status", attr="Feed Status"),
                 dict(name="governing_agreement", attr="Governing Agreement"),
             ]),
        dict(name="reconciliation", product="DP-495", entity="Reconciliation", kind="Dimension",
             dimensions=[
                 dict(name="reconciliation_id", attr="Reconciliation ID"),
                 dict(name="reconciliation_name", attr="Reconciliation Name"),
                 dict(name="reconciliation_type", attr="Reconciliation Type"),
                 dict(name="left_source", attr="Left Source"),
                 dict(name="right_source", attr="Right Source"),
                 dict(name="absolute_tolerance", attr="Absolute Tolerance"),
                 dict(name="relative_tolerance_pct", attr="Relative Tolerance %"),
             ]),
        dict(name="reconciliation_run", product="DP-495", entity="Fact Reconciliation Run", kind="Fact",
             grain="reconciliation x run business date",
             default_filter="latest run of each reconciliation on the business date",
             dimensions=[
                 dict(name="run_reconciliation", attr="Reconciliation Key"),
                 dict(name="run_business_date", attr="Run Business Date"),
             ],
             facts=[dict(name="matched_pct", attr="Matched %")]),
        dict(name="reconciliation_break", product="DP-495", entity="Fact Break", kind="Fact",
             grain="reconciliation break",
             dimensions=[
                 dict(name="break_id", attr="Break ID"),
                 dict(name="break_run", attr="Fact Reconciliation Run Key"),
                 dict(name="break_type", attr="Break Type"),
                 dict(name="root_cause_category", attr="Root Cause Category"),
                 dict(name="break_status", attr="Break Status"),
                 dict(name="break_age_days", attr="Break Age (Days)"),
                 dict(name="resolution_date", attr="Resolution Date"),
             ],
             facts=[dict(name="difference_amount", attr="Difference Amount")]),
        dict(name="unattributed_item", product="DP-495", entity="Fact Unattributed Item", kind="Fact",
             grain="unattributed (suspense) item",
             dimensions=[
                 dict(name="unattributed_item_id", attr="Unattributed Item ID"),
                 dict(name="lowest_resolved_level", attr="Lowest Resolved Level"),
                 dict(name="unattributed_reason", attr="Unattributed Reason"),
                 dict(name="suspense_channel", attr="Suspense Channel"),
                 dict(name="first_seen_date", attr="First Seen Date"),
                 dict(name="resolution_status", attr="Resolution Status"),
             ],
             facts=[dict(name="unattributed_amount", attr="Unattributed Amount")]),
        dict(name="attribution_override", product="DP-495", entity="Fact Attribution Override", kind="Fact",
             grain="attribution override",
             dimensions=[
                 dict(name="override_id", attr="Override ID"),
                 dict(name="override_scope", attr="Override Scope"),
                 dict(name="override_reason", attr="Override Reason"),
                 dict(name="override_effective_from", attr="Override Effective From"),
                 dict(name="override_effective_to", attr="Override Effective To"),
             ],
             hidden=[("Approved By", "Names an employee; the metric counts overrides with no approver without showing names.")]),
        dict(name="identifier_crosswalk", product="DP-495", entity="Identifier Crosswalk", kind="Dimension",
             dimensions=[
                 dict(name="crosswalk_id", attr="Crosswalk ID"),
                 dict(name="crosswalk_source_feed", attr="Source Feed"),
                 dict(name="source_identifier_type", attr="Source Identifier Type"),
                 dict(name="crosswalk_effective_from", attr="Crosswalk Effective From"),
                 dict(name="crosswalk_effective_to", attr="Crosswalk Effective To"),
             ],
             hidden=[("Source Identifier Value", "Rep codes and account numbers of intermediary feeds; steward drill-down only."),
                     ("Resolved Party", "Resolves to an external advisor or client; personal data."),
                     ("Resolved Account", "Client account key; personal data.")]),
        dict(name="match_result", product="DP-495", entity="Fact Match Result", kind="Fact",
             grain="crosswalk entry x match date",
             dimensions=[
                 dict(name="match_crosswalk", attr="Identifier Crosswalk Key"),
                 dict(name="match_status", attr="Match Status"),
                 dict(name="match_source", attr="Match Source"),
                 dict(name="match_rule_applied", attr="Match Rule Applied"),
                 dict(name="match_date", attr="Match Date"),
             ],
             facts=[dict(name="match_score", attr="Match Score")]),
        dict(name="match_rule", product="DP-495", entity="Match Rule", kind="Dimension",
             dimensions=[
                 dict(name="match_rule_id", attr="Match Rule ID"),
                 dict(name="match_rule_type", attr="Match Rule Type"),
                 dict(name="auto_accept_threshold", attr="Auto-Accept Threshold"),
                 dict(name="review_threshold", attr="Review Threshold"),
             ]),
        dict(name="restatement", product="DP-495", entity="Fact Restatement", kind="Fact",
             grain="restatement of a locked period",
             dimensions=[
                 dict(name="restatement_id", attr="Restatement ID"),
                 dict(name="restatement_snapshot", attr="Snapshot Key"),
                 dict(name="restatement_reason", attr="Restatement Reason"),
                 dict(name="affected_periods", attr="Affected Periods", note="Free text (GAP-06-005)."),
             ],
             facts=[dict(name="net_impact_amount", attr="Net Impact Amount")],
             hidden=[("Restatement Approved By", "Names an employee; kept in DP-008.")]),
        dict(name="dq_result", product="DP-495", entity="Fact DQ Result", kind="Fact",
             grain="data quality rule execution on a 06 load",
             dimensions=[
                 dict(name="dq_result_id", attr="DQ Result ID"),
                 dict(name="tested_dq_rule", attr="Tested DQ Rule"),
                 dict(name="tested_load", attr="Tested Load"),
                 dict(name="dq_execution_timestamp", attr="DQ Execution Timestamp"),
                 dict(name="threshold_met_indicator", attr="Threshold Met Indicator"),
             ],
             facts=[
                 dict(name="records_tested", attr="Records Tested"),
                 dict(name="records_failed", attr="Records Failed"),
                 dict(name="dq_result_pct", attr="DQ Result %"),
             ]),
        dict(name="vendor_data_issue", product="DP-495", entity="Fact Vendor Data Issue", kind="Fact",
             grain="vendor data issue",
             dimensions=[
                 dict(name="vendor_data_issue_id", attr="Vendor Data Issue ID"),
                 dict(name="issue_dataset", attr="Issue Dataset"),
                 dict(name="issue_type", attr="Issue Type"),
                 dict(name="issue_severity", attr="Issue Severity"),
                 dict(name="issue_status", attr="Issue Status"),
                 dict(name="detected_date", attr="Detected Date"),
                 dict(name="resolved_date", attr="Resolved Date"),
             ]),
    ],

    shared=["DP-013/Calendar Date", "DP-013/Code Value",
            "DP-004/Share Class", "DP-004/Investment Product", "DP-004/Service Offering",
            "DP-009/Employee", "DP-009/Coverage Assignment",
            "DP-093/Account", "DP-093/Account Party Role", "DP-093/Program Enrollment",
            "DP-240/Party", "DP-240/Household Membership",
            "DP-097/Instrument"],

    relationships=[
        # --- certified measure values ----------------------------------------------------------------------------------
        dict(frm="client_assets_flows", to="snapshot", on="client_assets_flows.snapshot = snapshot.snapshot_id", type="many-to-one"),
        dict(frm="client_assets_flows", to="reporting_period",
             on="client_assets_flows.reporting_period = reporting_period.reporting_period_id", type="many-to-one"),
        dict(frm="client_assets_flows", to="measure_definition",
             on="client_assets_flows.measure = measure_definition.measure_id", type="many-to-one"),
        dict(frm="client_assets_flows", to="DP-013/Calendar Date",
             on="client_assets_flows.period_end_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="client_assets_flows", to="DP-013/Code Value",
             on=("client_assets_flows.dimension_key = " + _CODE.format("distribution channel, holding type, business line "
                 "or client segment, by dimension_type") + " where dimension_type in ('Channel', 'Holding Type', "
                 "'Business Line', 'Segment')"),
             type="many-to-one"),
        dict(frm="client_assets_flows", to="DP-004/Share Class",
             on="client_assets_flows.dimension_key = share_class.share_class_id where dimension_type = 'Share Class'",
             type="many-to-one"),
        dict(frm="client_assets_flows", to="DP-009/Employee",
             on="client_assets_flows.dimension_key = employee.employee_id where dimension_type = 'Advisor'",
             type="many-to-one"),
        dict(frm="client_assets_flows", to="campaign",
             on="client_assets_flows.dimension_key = campaign.campaign_id where dimension_type = 'Campaign'",
             type="many-to-one"),
        # --- flow rows -------------------------------------------------------------------------------------------------
        dict(frm="flow_transactions", to="DP-093/Account", on="flow_transactions.txn_account = account.account_id (version in force on trade_date)",
             type="many-to-one"),
        dict(frm="flow_transactions", to="DP-004/Share Class", on="flow_transactions.txn_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="flow_transactions", to="DP-013/Calendar Date", on="flow_transactions.trade_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="flow_transactions", to="client_account_activity",
             on="flow_transactions.source_client_account_activity = client_account_activity.client_account_activity_id",
             type="many-to-one"),
        dict(frm="client_account_activity", to="money_movement",
             on="client_account_activity.source_money_movement = money_movement.money_movement_id", type="many-to-one"),
        dict(frm="flow_linked_transactions", to="flow_transactions",
             on="flow_linked_transactions.linked_transaction_key = flow_transactions.transaction_id", type="many-to-one"),
        dict(frm="flow_transactions", to="DP-093/Program Enrollment",
             on=("flow_transactions.txn_account = program_enrollment.enrolled_account and enrollment_status = 'Active' and "
                 "trade_date between enrollment_effective_date and coalesce(enrollment_termination_date, trade_date)"),
             type="many-to-many",
             warning=("An account can hold more than one enrollment in force on a date (for example planning and a managed "
                      "program). Grouping NNA by offering through this join repeats the flow under each enrollment; NNA by "
                      "Offering and Program takes one enrollment per account and date (the advice or managed program "
                      "first) and shows accounts with none as Self-Directed.")),
        # --- NNA attribution (DP-491) -----------------------------------------------------------------------------------
        dict(frm="nna_attribution", to="flow_transactions",
             on="nna_attribution.nna_source_transaction = flow_transactions.transaction_id", type="many-to-one"),
        dict(frm="nna_attribution", to="DP-009/Employee", on="nna_attribution.nna_covering_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="nna_attribution", to="DP-009/Coverage Assignment",
             on="nna_attribution.nna_coverage_assignment = coverage_assignment.coverage_assignment_id", type="many-to-one"),
        dict(frm="nna_attribution", to="DP-004/Service Offering",
             on="nna_attribution.nna_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="nna_attribution", to="DP-240/Party", on="nna_attribution.nna_client_household = party.party_id (Party Type Household)",
             type="many-to-one"),
        dict(frm="salesperson_credit", to="nna_attribution",
             on="salesperson_credit.credit_attribution_record = nna_attribution.nna_attribution_id", type="many-to-one"),
        dict(frm="salesperson_credit", to="DP-009/Employee", on="salesperson_credit.credited_salesperson = employee.employee_id",
             type="many-to-one"),
        # --- campaign attribution and acquisition (DP-492) --------------------------------------------------------------
        dict(frm="campaign_attribution", to="flow_transactions",
             on="campaign_attribution.campaign_source_transaction = flow_transactions.transaction_id", type="many-to-one"),
        dict(frm="campaign_attribution", to="campaign", on="campaign_attribution.attributed_campaign = campaign.campaign_id",
             type="many-to-one"),
        dict(frm="campaign_attribution", to="attributed_outcome",
             on=("campaign_attribution.source_attributed_outcome = attributed_outcome (attributed_milestone, outcome_campaign, "
                 "applied_attribution_model)"),
             type="many-to-one"),
        dict(frm="attributed_outcome", to="campaign", on="attributed_outcome.outcome_campaign = campaign.campaign_id", type="many-to-one"),
        dict(frm="attributed_outcome", to="attribution_model",
             on="attributed_outcome.applied_attribution_model = attribution_model.attribution_model_key", type="many-to-one"),
        dict(frm="attributed_outcome", to="acquisition_milestone",
             on="attributed_outcome.attributed_milestone = acquisition_milestone (milestone_party, milestone_type, milestone_date, milestone_account)",
             type="many-to-one"),
        dict(frm="acquisition_milestone", to="DP-240/Party", on="acquisition_milestone.milestone_party = party.party_id", type="many-to-one"),
        dict(frm="acquisition_milestone", to="DP-093/Account", on="acquisition_milestone.milestone_account = account.account_id",
             type="many-to-one"),
        dict(frm="acquisition_milestone", to="DP-013/Calendar Date", on="acquisition_milestone.milestone_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="marketing_touchpoint", to="DP-240/Party", on="marketing_touchpoint.touchpoint_party = party.party_id", type="many-to-one"),
        dict(frm="marketing_touchpoint", to="campaign", on="marketing_touchpoint.touchpoint_campaign = campaign.campaign_id",
             type="many-to-one"),
        dict(frm="campaign", to="campaign", on="campaign.parent_campaign = campaign.campaign_id", type="many-to-one"),
        # --- household path (stated once, as in DP-492): account -> owner party -> household in force -----------------
        dict(frm="DP-093/Account Party Role", to="DP-093/Account", on="account_party_role.role_account = account.account_id",
             type="many-to-one"),
        dict(frm="DP-093/Account Party Role", to="DP-240/Party", on="account_party_role.role_party = party.party_id",
             type="many-to-one"),
        dict(frm="DP-240/Household Membership", to="DP-240/Party",
             on=("household_membership.household = party.party_id (Party Type Household, PTY-HH-) and "
                 "membership_status = 'Active' and the measurement date between membership_effective_from and "
                 "coalesce(membership_effective_to, the measurement date)"),
             type="many-to-many",
             warning=("Household to account is many-to-many and effective dated: an account has joint owners who can sit in "
                      "different households, and members move. Pin the membership (and the owner Account Party Role) as of "
                      "the measurement date (the period end, or the Milestone Date for cohorts); summing amounts through this "
                      "path repeats a joint account under each household. Household counts are distinct counts; household "
                      "amounts are DP-320's (SM-21), never summed here.")),
        # --- asset positions and mix -----------------------------------------------------------------------------------
        dict(frm="account_asset_summary", to="DP-093/Account",
             on="account_asset_summary.summary_account = account.account_id (version in force on summary_as_of_date)", type="many-to-one"),
        dict(frm="account_asset_summary", to="DP-013/Calendar Date",
             on="account_asset_summary.summary_as_of_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="account_asset_summary", to="DP-013/Code Value",
             on=("account_asset_summary.summary_distribution_channel or summary_holding_type = "
                 + _CODE.format("distribution channel; holding type")), type="many-to-one"),
        dict(frm="intermediary_positions", to="DP-004/Share Class",
             on="intermediary_positions.pos_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="intermediary_positions", to="DP-093/Account",
             on="intermediary_positions.omnibus_parent_account = account.account_id", type="many-to-one"),
        dict(frm="intermediary_positions", to="DP-013/Calendar Date",
             on="intermediary_positions.valuation_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="DP-004/Share Class", to="DP-004/Investment Product",
             on="share_class.parent_product = investment_product.product_id", type="many-to-one"),
        dict(frm="asset_attribution", to="intermediary_positions",
             on="asset_attribution.source_position = intermediary_positions.position_id", type="many-to-one"),
        dict(frm="asset_attribution", to="account_asset_summary",
             on=("asset_attribution.source_account_asset_summary = account_asset_summary (summary_account, "
                 "summary_as_of_date, summary_holding_type)"),
             type="many-to-one"),
        dict(frm="asset_attribution", to="DP-004/Service Offering",
             on="asset_attribution.asset_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="brokerage_client_holdings", to="DP-097/Instrument",
             on="brokerage_client_holdings.held_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="brokerage_client_holdings", to="DP-093/Account",
             on="brokerage_client_holdings.holding_account = account.account_id", type="many-to-one"),
        dict(frm="brokerage_client_holdings", to="DP-013/Calendar Date",
             on="brokerage_client_holdings.client_holding_date = calendar_date.calendar_date", type="many-to-one"),
        # --- plan and forecast -----------------------------------------------------------------------------------------
        dict(frm="flow_revenue_forecast", to="plan_version",
             on="flow_revenue_forecast.forecast_plan_version = plan_version.plan_version_id", type="many-to-one"),
        dict(frm="flow_revenue_forecast", to="DP-013/Code Value",
             on="flow_revenue_forecast.forecast_channel = " + _CODE.format("distribution channel"), type="many-to-one"),
        dict(frm="plan_line", to="plan_version", on="plan_line.line_plan_version = plan_version.plan_version_id", type="many-to-one"),
        dict(frm="plan_line", to="reporting_period", on="plan_line.plan_reporting_period = reporting_period.reporting_period_id",
             type="many-to-one"),
        dict(frm="plan_variance", to="plan_version", on="plan_variance.variance_plan_version = plan_version.plan_version_id",
             type="many-to-one"),
        # --- supply chain ----------------------------------------------------------------------------------------------
        dict(frm="feed_load", to="data_feed", on="feed_load.load_feed = data_feed.feed_id", type="many-to-one"),
        dict(frm="feed_load", to="DP-013/Calendar Date", on="feed_load.business_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="reconciliation_run", to="reconciliation", on="reconciliation_run.run_reconciliation = reconciliation.reconciliation_id",
             type="many-to-one"),
        dict(frm="reconciliation_break", to="reconciliation_run",
             on="reconciliation_break.break_run = reconciliation_run (run_reconciliation, run_business_date)", type="many-to-one"),
        dict(frm="reconciliation", to="data_feed", on="reconciliation.left_source = data_feed.feed_id (and right_source likewise)",
             type="many-to-one"),
        dict(frm="identifier_crosswalk", to="data_feed", on="identifier_crosswalk.crosswalk_source_feed = data_feed.feed_id",
             type="many-to-one"),
        dict(frm="match_result", to="identifier_crosswalk", on="match_result.match_crosswalk = identifier_crosswalk.crosswalk_id",
             type="many-to-one"),
        dict(frm="match_result", to="match_rule", on="match_result.match_rule_applied = match_rule.match_rule_id", type="many-to-one"),
        dict(frm="dq_result", to="feed_load", on="dq_result.tested_load = feed_load.load_id", type="many-to-one"),
        dict(frm="unattributed_item", to="DP-013/Calendar Date", on="unattributed_item.first_seen_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="restatement", to="snapshot", on="restatement.restatement_snapshot = snapshot.snapshot_id", type="many-to-one"),
        dict(frm="restatement", to="reporting_period", on="restatement.affected_periods mentions reporting_period.reporting_period_id",
             type="many-to-many",
             warning=("Affected Periods is free text (GAP-06-005): one restatement can name several periods. Grouping Net "
                      "Impact Amount by period repeats the restatement under each period it names; sum restatements by "
                      "approval period or reason only.")),
    ],

    hierarchies=[
        dict(name="Campaign", levels=["campaign.campaign_type", "campaign.parent_campaign", "campaign.campaign_id"]),
        dict(name="Client Asset Mix", levels=["account_asset_summary.summary_distribution_channel",
                                               "account_asset_summary.summary_holding_type"]),
        dict(name="Flow Type", levels=["flow_transactions.flow_scope", "flow_transactions.transaction_type"]),
        dict(name="Reconciliation", levels=["reconciliation.reconciliation_type", "reconciliation.reconciliation_id"]),
        dict(name="Plan", levels=["plan_version.plan_fiscal_year", "plan_version.plan_type", "plan_version.plan_version_id"]),
    ],

    metrics=[
        # ================= Certified client assets (DP-008): additive across one dimension type, not over time =========
        dict(name="Client Assets", aggregation="semi_additive", expr="sum(client_assets_flows.ending_client_assets)",
             time_rule=_LAST, source=("DP-008", "Ending Client Assets"),
             description=("The market value of every client account at the firm on the last business day of the period "
                          "(net equity), plus own-fund assets held through intermediaries, under the certified CW-011 rule."),
             note=("Overlaps Firm AUM by design (own-fund holdings in client accounts are in both): never added to Firm AUM; "
                   "the two are reconciled in DP-241 (SM-11). Read at one Dimension Type per query.")),
        dict(name="Beginning Client Assets", aggregation="semi_additive", expr="sum(client_assets_flows.beginning_client_assets)",
             time_rule="first period in the selected range", source=("DP-008", "Beginning Client Assets"),
             description="Client Assets at the start of the period: the prior period's locked Ending Client Assets."),
        dict(name="Average Client Assets", aggregation="semi_additive", expr="sum(client_assets_flows.average_client_assets)",
             time_rule=("sum across dimension keys within each period, then the mean of the period values over the selected "
                        "range (monthly averages of business days)"),
             source=("DP-008", "Average Client Assets"),
             description="The mean of the daily Client Assets over the period; the asset basis for basis-point revenue measures."),
        dict(name="Advised Assets", aggregation="semi_additive", expr="sum(client_assets_flows.advised_assets)",
             time_rule=_LAST, source=("DP-008", "Advised Assets"),
             description=("Client Assets of accounts with an active fee-based advice, managed or trust enrollment at the period "
                          "end (Direct - Digital Advice, Direct - Human Advice and Direct - Trust channels)."),
             note="The rule is DP-008's only; DP-007's account-level advised value is an input, not published."),
        dict(name="Own-Fund Overlap", aggregation="semi_additive", expr="sum(client_assets_flows.own_fund_overlap_amount)",
             time_rule=_LAST, source=("DP-008", "Own-Fund Overlap Amount"),
             description=("Own mutual fund, ETF and CIT assets inside Client Assets that are also in the own funds slice of "
                          "Firm AUM."),
             note="Reported, never netted here: it is subtracted only in DP-241's reconciliation (SM-11)."),
        dict(name="Client Assets Excluding Intermediary-Held", aggregation="semi_additive",
             expr="sum(client_assets_flows.client_assets_excl_intermediary)", time_rule=_LAST,
             source=("DP-008", "Client Assets Excluding Intermediary-Held"),
             description="Client Assets of firm client accounts only, without own-fund assets held through intermediaries.",
             note=("Marked Certified (CW-011) in DP-008's spec but not in register.CERTIFIED; published under its spec name "
                   "until the register decides (open decision).")),

        # ================= Certified flows and roll-forward (DP-008): additive over time and across one type ===========
        dict(name="Net New Assets", aggregation="additive", expr="sum(client_assets_flows.net_new_assets)",
             source=("DP-008", "Net New Assets"),
             description=("Client asset inflows less outflows under the certified flow treatment rule: income, fees and "
                          "same-owner transfers excluded, inter-channel transfers never counted."),
             note=("By channel, advisor of record (primary coverage on the trade date) and campaign (at its attribution "
                   "weight) through dimension_type; the DIS cuts in DP-491 and DP-492 tie to the Total row.")),
        dict(name="Net Inter-Channel Transfers", aggregation="additive", expr="sum(client_assets_flows.net_inter_channel_transfers)",
             source=("DP-008", "Net Inter-Channel Transfers"),
             description=("Client assets moved into a channel from another channel of the firm less those moved out "
                          "(advice enrollments, journals, firm-plan rollovers); zero for the firm."),
             note="Zero at Dimension Type Total; meaningful by Channel and Business Line."),
        dict(name="Client Market Movement and Other", aggregation="additive",
             expr="sum(client_assets_flows.client_market_movement_other)",
             source=("DP-008", "Client Market Movement and Other"),
             description=("The change in Client Assets not explained by net new assets or inter-channel transfers: market "
                          "appreciation, income and fees."),
             note=("Additive over periods: a quarter's movement is the sum of its months. Beginning Client Assets + Net New "
                   "Assets + Net Inter-Channel Transfers + Client Market Movement and Other = Client Assets.")),
        dict(name="Client Organic Growth Rate", aggregation="ratio",
             numerator=("sum(client_assets_flows.net_new_assets) over the selected periods, annualized (x 12 / number of "
                        "months for monthly periods)"),
             denominator="[Beginning Client Assets] at the first period in the range, for the same dimension keys",
             source=("DP-008", "Client Organic Growth Rate"),
             description="Annualized net new assets as a share of the client assets we started the period with.",
             note="Ratio of sums; channel or advisor rates are never averaged. Simple annualization (open decision)."),
        dict(name="Gross Sales", aggregation="additive", expr="sum(client_assets_flows.gross_sales)",
             source=("DP-008", "Gross Sales"),
             description=("Purchases of our own funds and ETFs across every channel under the certified own-fund flow rule, "
                          "excluding reinvested distributions."),
             note="Own-fund flows (CW-203), not client flows: Gross Sales and Net New Assets measure different things."),
        dict(name="Redemptions", aggregation="additive", expr="sum(client_assets_flows.redemptions)",
             source=("DP-008", "Redemptions"),
             description="Own-fund redemptions, exchanges out and ETF redemptions under the same rules, shown as a positive amount."),
        dict(name="Net Exchanges", aggregation="additive", expr="sum(client_assets_flows.net_exchanges)",
             source=("DP-008", "Net Exchanges"),
             description="Exchanges into our funds from our other funds less exchanges out, where the exchange treatment is net only."),
        dict(name="Net Flows", aggregation="additive", expr="sum(client_assets_flows.net_flows)",
             source=("DP-008", "Net Flows"),
             description="Gross Sales minus Redemptions, plus Net Exchanges where the exchange treatment is net only."),
        dict(name="Restatement Impact", aggregation="additive", expr="sum(client_assets_flows.restatement_impact)",
             source=("DP-008", "Restatement Impact"),
             description="How much restatements approved after a period was locked changed its figures.",
             note="The certified metrics always show the latest locked version; the first-locked figures stay in DP-008."),

        # ================= Certified counts (DP-008): distinct counts, never summed ====================================
        dict(name="Funded Accounts", aggregation="non_additive",
             expr="client_assets_flows.funded_accounts at the selected dimension_key and the last period end in the range",
             source=("DP-008", "Funded Accounts"),
             description="Open firm client accounts with a market value above zero at the period end.",
             note="A distinct count: an account counts once at Total, and channel values do not add up to Total."),
        dict(name="Clients", aggregation="non_additive",
             expr="client_assets_flows.clients at the selected dimension_key and the last period end in the range",
             source=("DP-008", "Clients"),
             description=("People and entities that own a funded account, or are participants with a funded plan account, at "
                          "the period end."),
             note="Distinct count; workplace participants included (CW-011 lever). Never summed across channels or periods."),
        dict(name="Households", aggregation="non_additive",
             expr="client_assets_flows.households at the selected dimension_key and the last period end in the range",
             source=("DP-008", "Households"),
             description=("Client households (PTY-HH-) with at least one client as an active member on the period end."),
             note=("Membership pinned as of the period end by the certified rule; the 02 household, never the mailing or "
                   "fee household. Distinct count: never summed across channels or periods.")),

        # ================= Referenced: Firm AUM and the reconciliation (SM-11, DP-241) =================================
        dict(name="Firm AUM", ref="SM-11/Firm AUM",
             note="Shown beside Client Assets in its own section, never added to it (own funds in client accounts are in both)."),
        dict(name="Firm AUM - Own Funds at NAV", ref="SM-11/Firm AUM - Own Funds at NAV"),
        dict(name="Firm AUM - Managed Accounts", ref="SM-11/Firm AUM - Managed Accounts"),
        dict(name="Firm AUM - Institutional & OCIO", ref="SM-11/Firm AUM - Institutional & OCIO"),
        dict(name="AUM Gross Difference", ref="SM-11/AUM Gross Difference",
             note="DP-241's Firm AUM less Client Assets at the firm total; the reconciliation is DP-241's, read, never recomputed."),
        dict(name="AUM Unexplained Residual", ref="SM-11/AUM Unexplained Residual"),
        dict(name="AUM Explained %", ref="SM-11/AUM Explained %"),
        dict(name="Net Fee Revenue", ref="SM-28/Net Fee Revenue",
             note="Read by the scorecard's Revenue vs Plan and Forecast; the revenue family is SM-28's."),

        # ================= DP-496 client asset mix and own-fund penetration ===========================================
        dict(name="Client Assets by Channel and Holding Type", aggregation="semi_additive",
             expr=("sum(account_asset_summary.summary_market_value) by summary_distribution_channel x summary_holding_type "
                   "+ sum(intermediary_positions.position_market_value where aggregation_role = 'Counted - Intermediary') at "
                   "the asset_attribution channel and the share class's vehicle holding type (Own Mutual Fund, Own ETF, Own "
                   "CIT) + the omnibus_residual_amount taken once per omnibus_parent_account x pos_share_class x "
                   "valuation_date at the parent's channel and the same holding type"),
             time_rule=_LAST, source=("DP-496", "Client Assets by Channel and Holding Type"),
             description=("The channel by holding type cross-tab of Client Assets: the rows DP-008 counts, summed by cell; both "
                          "margins equal the certified Client Assets by Channel and by Holding Type."),
             note=("A decomposition, not a second Client Assets: the certified figure is [Client Assets] at Dimension Type "
                   "Channel or Holding Type (DP-008 keeps one dimension per row). Ties to both margins (DP-496 DQ3).")),
        dict(name="Client Assets by Holding Type Group", aggregation="semi_additive",
             expr=("[Client Assets by Channel and Holding Type] collapsed to the four CW-011 groups: Own Funds (Own Mutual Fund, "
                   "Own ETF, Own CIT), Third-Party Funds (Third-Party Mutual Fund, Third-Party ETF, Alternative Feeder), "
                   "Securities (Equity, Fixed Income and CDs, Options, Other) and Cash (Cash and Sweep)"),
             time_rule=_LAST, source=("DP-496", "Client Assets by Holding Type Group"),
             description="Client Assets in own funds, third-party funds, securities and cash, by channel.",
             note="No holding type group attribute exists; the 11-to-4 mapping is the CW-011 tailoring lever, stated here."),
        dict(name="Own-Fund Share of Client Assets %", aggregation="ratio",
             numerator="sum(account_asset_summary.summary_market_value) where own_product_indicator = 'Y', at the period end",
             denominator="sum(account_asset_summary.summary_market_value) for the same accounts, channels and period end",
             source=("DP-496", "Own-Fund Share of Client Assets %"),
             description="The share of client account assets held in our own mutual funds, ETFs and CITs, by channel and offering.",
             time_rule=_LAST),
        dict(name="Own-Fund Share Change (bps)", aggregation="non_additive",
             expr=("([Own-Fund Share of Client Assets %] at the period end - the same at the prior period end, same cut) x 100"),
             source=("DP-496", "Own-Fund Share Change (bps)"),
             description="The change in own-fund share since the prior period end, in basis points.",
             note="A difference of two ratios at the query grain; never summed across channels or periods."),
        dict(name="Client Assets by Offering", aggregation="semi_additive",
             expr=("sum(asset_attribution.asset_attributed_amount) where source_account_asset_summary is a period-end summary, "
                   "by asset_service_offering and the summary's summary_holding_type"),
             time_rule=_LAST, source=("DP-496", "Client Assets by Offering"),
             description="Client account assets by service offering (self-directed, digital advice, human advice, managed, trust).",
             note="Attribution records split a summary across offerings; never added to summary_market_value (same money)."),
        dict(name="Advised Assets Share %", aggregation="ratio",
             numerator="[Advised Assets] at the period end", denominator="[Client Assets] at the same period end and dimension keys",
             source=("DP-496", "Advised Assets Share % (from DP-008)"),
             description="Advised Assets as a share of Client Assets, by channel, both from the locked DP-008 snapshot.",
             time_rule=_LAST),
        dict(name="Own-Fund Client Holdings Market Value", aggregation="semi_additive",
             expr="sum(brokerage_client_holdings.holding_market_value_usd) where own_share_class_indicator = 'Y'",
             time_rule=_LAST, source=("DP-496", "Own-Fund Client Holdings Market Value (from DP-300)"),
             description=("Own-fund holdings in brokerage accounts from the brokerage book of record, against the own-fund "
                          "summary rows with source book 49."),
             note="A tie-out from the 49 book; never added to Client Assets or to the summary rows (they copy the same book)."),
        dict(name="Third-Party and Securities Wallet Share by Instrument Type", aggregation="ratio",
             numerator=("sum(brokerage_client_holdings.holding_market_value_usd) where own_share_class_indicator = 'N', by "
                        "DP-097 instrument type and asset class"),
             denominator=("sum(account_asset_summary.summary_market_value) where summary_source_book = 'Brokerage Book of "
                          "Record (49)', same period end"),
             source=("DP-496", "Third-Party and Securities Wallet Share by Instrument Type"),
             description="Where brokerage client assets go other than our own funds, as a share of the brokerage book's client assets.",
             time_rule=_LAST,
             note="Drill-across: each side is summed on its own table and lined up by period end."),

        # ================= DP-007 =========================================================================================
        dict(name="Intermediary-Held Own-Fund Value", aggregation="semi_additive",
             expr=("sum(intermediary_positions.position_market_value where aggregation_role = 'Counted - Intermediary') + "
                   "the omnibus_residual_amount taken once per omnibus_parent_account x pos_share_class x valuation_date"),
             time_rule=_LAST, source=("DP-007", "Intermediary-Held Own-Fund Value"),
             description="Own-fund assets held through intermediaries and omnibus accounts that are counted in Client Assets.",
             note="The difference between Client Assets and Client Assets Excluding Intermediary-Held."),

        # ================= DP-006 =========================================================================================
        dict(name="Inter-Channel Transfer Amount", aggregation="additive",
             expr=("sum(flow_transactions.gross_amount signed by flow_direction) where flow_scope = 'Inter-Channel Transfer', "
                   "by flow_linked_transactions.from_distribution_channel x to_distribution_channel"),
             source=("DP-006", "Inter-Channel Transfer Amount"),
             description="Client assets moved between channels of the firm, by the channel they left and the channel they joined.",
             note=("Pre-treatment from-to view; the certified net by channel is Net Inter-Channel Transfers. Zero firm-wide.")),

        # ================= DP-491 NNA by channel, offering and advisor =================================================
        dict(name="NNA by Offering and Program", aggregation="additive",
             expr=("sum(nna_attribution.nna_attributed_amount) by the DP-004 service offering of the account's DP-093 program "
                   "enrollment in force on the trade date (one per account and date; none = Self-Directed), and by channel"),
             source=("DP-491", "NNA by Offering and Program"),
             description="Net new assets by service offering and program, tying to the certified Net New Assets in total.",
             note="Rolls up DP-008's own NNA rows; no treatment rule is applied here (one NNA rule)."),
        dict(name="Gross Client Inflows", aggregation="additive",
             expr="sum(nna_attribution.nna_attributed_amount) where flow_transactions.flow_direction = 'Inflow'",
             source=("DP-491", "Gross Client Inflows"),
             description="The inflows counted in net new assets, by transaction type and channel."),
        dict(name="Gross Client Outflows", aggregation="additive",
             expr="-sum(nna_attribution.nna_attributed_amount) where flow_transactions.flow_direction = 'Outflow'",
             source=("DP-491", "Gross Client Outflows"),
             description="The outflows counted in net new assets, by transaction type and channel, shown as a positive amount."),
        dict(name="NNA Components by Flow Type", aggregation="additive",
             expr=("[Gross Client Inflows] - [Gross Client Outflows] grouped into deposits and withdrawals, ACATS and in-kind "
                   "transfers, rollovers, plan contributions and distributions (contribution_source_type), mandate funding and "
                   "withdrawal and SMA flows; 49 deposits and withdrawals split by money_movement.money_movement_type and "
                   "payment_rail through client_account_activity"),
             source=("DP-491", "NNA Components by Flow Type"),
             description="What net new assets are made of: deposits, transfers, rollovers, contributions and withdrawals."),
        dict(name="NNA Without Advisor of Record", aggregation="additive",
             expr=("[Net New Assets] at dimension_type 'Total' - sum([Net New Assets]) over dimension_type 'Advisor' rows with an "
                   "advisor key, for the same periods"),
             source=("DP-491", "NNA Without Advisor of Record"),
             description="Net new assets of households with no primary advisor on the trade date (self-directed, digital-only, unassigned).",
             note="Reads two Dimension Types side by side, each on its own; the rows are never added together."),
        dict(name="Advisors With Net Outflows", aggregation="count_distinct",
             expr=("count distinct client_assets_flows.dimension_key where dimension_type = 'Advisor' and net_new_assets < 0 for "
                   "the period and DP-009 employee advisor status = 'Active'"),
             source=("DP-491", "Advisors With Net Outflows"),
             description="How many active advisors had negative net new assets in the period (with the sum of their outflow)."),
        dict(name="Advisor Attribution Coverage %", aggregation="ratio",
             numerator=("sum(abs(nna_attribution.nna_attributed_amount)) where nna_covering_advisor is set, "
                        "nna_attribution_method = 'Account-Keyed' and the coverage assignment is in force on nna_effective_date"),
             denominator="sum(abs(nna_attribution.nna_attributed_amount)) of households with a primary coverage on that date",
             source=("DP-491", "Advisor Attribution Coverage %"),
             description="The share of covered households' flow value credited to their advisor of record.",
             note="Unsigned amounts, so outflows do not offset inflows."),
        dict(name="NNA Moved by Coverage Changes", aggregation="additive",
             expr=("sum(nna_attribution.nna_attributed_amount) in the period of households whose primary DP-009 coverage "
                   "assignment started in the period, split before and after the change"),
             source=("DP-491", "NNA Moved by Coverage Changes"),
             description="Net new assets of households that changed advisor in the period, credited to the advisor in force on each trade date."),
        dict(name="Salesperson-Credited NNA", aggregation="additive",
             expr="sum(nna_attribution.nna_attributed_amount x salesperson_credit.credit_split_pct / 100) by credited_salesperson and credit_role",
             source=("DP-491", "Salesperson-Credited NNA"),
             description="Net new assets credited to salespeople of the intermediary and institutional advisory lines.",
             note="Credit splits sum to 100 per record and role; sum within one credit_role only, or credit is counted twice."),
        dict(name="Same-Owner Transfers Excluded", aggregation="additive",
             expr=("sum(flow_transactions.reporting_currency_amount) of current transfer rows whose flow_linked_transactions."
                   "same_owner_indicator = 'Y', by transfer_type and from / to channel"),
             source=("DP-491", "Same-Owner Transfers Excluded"),
             description="Transfers between accounts of the same owner that the certified rule leaves out of net new assets.",
             note="Shown beside Net New Assets for explanation; never added back."),
        dict(name="Rollover Flows by Source", aggregation="additive",
             expr=("sum(nna_attribution.nna_attributed_amount) of Rollover In rows (plans the firm does not recordkeep, counted "
                   "in NNA), beside sum(flow_transactions.gross_amount) of Inter-Channel Transfer rows with transfer_type "
                   "'Direct Rollover' from 'Workplace - Recordkept Plan', by receiving channel"),
             source=("DP-491", "Rollover Flows by Source"),
             description="Rollovers into the firm's IRAs: from outside plans (new money) and from firm-recordkept plans (inter-channel)."),

        # ================= DP-492 NNA by campaign and acquisition cohort ===============================================
        dict(name="Campaign-Attributed Share of NNA %", aggregation="ratio",
             numerator="sum([Net New Assets]) over dimension_type 'Campaign' rows with a campaign key",
             denominator="[Net New Assets] at dimension_type 'Total' for the same periods",
             source=("DP-492", "Campaign-Attributed Share of NNA %"),
             description="The share of net new assets attributed to a marketing campaign."),
        dict(name="Funded Households Attributed by Campaign", aggregation="additive",
             expr=("sum(attributed_outcome.attribution_weight) where outcome_type = 'Account Funded', the model is primary and "
                   "the household's first Account Funded milestone_date is in the period, by campaign"),
             source=("DP-492", "Funded Households Attributed by Campaign"),
             description="Newly funded households credited to each campaign; fractional by campaign and whole in total.",
             note="Weights of one household sum to 1 under the primary model; never mix attribution models."),
        dict(name="NNA per Funded Household by Campaign", aggregation="ratio",
             numerator="sum([Net New Assets]) over dimension_type 'Campaign' rows of the campaign",
             denominator="[Funded Households Attributed by Campaign] for the same campaign and period",
             source=("DP-492", "NNA per Funded Household by Campaign"),
             description="Net new assets a campaign brought in per household it helped fund."),
        dict(name="Funded Households by Acquisition Cohort", aggregation="count_distinct",
             expr=("count distinct DP-240 client households (through household membership in force on the milestone date) "
                   "whose earliest acquisition_milestone of milestone_type 'Account Funded' falls in the cohort month"),
             source=("DP-492", "Funded Households by Acquisition Cohort"),
             description="How many households first funded an account in each month."),
        dict(name="Cohort NNA Since Funding", aggregation="semi_additive",
             expr=("cumulative sum(campaign_attribution.campaign_attributed_amount) on the cohort households' accounts (owner "
                   "account party role to household membership) from the cohort milestone date to the period end"),
             time_rule=("the value at the selected months since funding; summed across cohort months, never across months "
                        "since funding"),
             source=("DP-492", "Cohort NNA Since Funding"),
             description="Net new assets brought in by each acquisition cohort since it funded, by months since funding.",
             note="Rolls up DP-008's NNA rows by funding cohort; never re-selected from DP-006."),
        dict(name="Twelve-Month NNA per Acquired Household by Campaign", aggregation="ratio",
             numerator=("[Cohort NNA Since Funding] at 12 months since funding of the households attributed to the campaign, "
                        "weighted by their attribution_weight"),
             denominator="[Funded Households Attributed by Campaign] for the cohort",
             source=("DP-492", "Twelve-Month NNA per Acquired Household by Campaign"),
             description="First-year net new assets per household a campaign acquired; the basis of lifetime value by acquisition channel."),
        dict(name="Attribution Model Sensitivity", aggregation="non_additive",
             expr=("sum(attributed_outcome.outcome_attributed_amount) under the primary model - the same under each alternative "
                   "attribution_model, per campaign and period"),
             source=("DP-492", "Attribution Model Sensitivity"),
             description="How much a campaign's credit changes under the alternative attribution models.",
             note="Shown per campaign and model; the alternative weights are 04's and are never summed with the primary."),
        dict(name="Funded Households Without Campaign Attribution", aggregation="count_distinct",
             expr=("count distinct households with an Account Funded milestone in the period and no attributed_outcome under "
                   "the primary model, by the funded account's channel"),
             source=("DP-492", "Funded Households Without Campaign Attribution"),
             description="Newly funded households no campaign can claim."),
        dict(name="Touchpoints per Funded Household", aggregation="ratio",
             numerator=("count(marketing_touchpoint) of household members within the primary model's lookback_window before the "
                        "funding milestone_date"),
             denominator="[Funded Households by Acquisition Cohort] for the same period",
             source=("DP-492", "Touchpoints per Funded Household"),
             description="Marketing touchpoints it took to fund a household, by campaign and touchpoint type."),
        dict(name="Campaign Weight Copy Breaks", aggregation="count_distinct",
             expr=("count distinct campaign_attribution.campaign_attribution_id where abs(campaign_attribution_weight - "
                   "attributed_outcome.attribution_weight) > 0.0001"),
             source=("DP-492", "Campaign Weight Copy Breaks"),
             description="Attribution records whose campaign weight no longer matches the marketing attribution it copies."),

        # ================= DP-490 executive scorecard ==================================================================
        dict(name="Net Household Change", aggregation="non_additive",
             expr="[Households] at the period end - [Households] at the prior period end, at the same dimension_key",
             source=("DP-490", "Net Household Change"),
             description="How many households the firm (or a channel) gained or lost in the period.",
             note="A difference of two distinct counts; never summed across channels."),
        dict(name="NNA Forecast vs Plan", aggregation="additive",
             expr=("sum(flow_revenue_forecast.forecast_gross_sales - forecast_redemptions) of the current Rolling Forecast "
                   "version - the same of the Annual Budget version, by forecast_channel; [Net New Assets] year to date shown beside"),
             source=("DP-490", "NNA Forecast vs Plan"),
             description="Forecast net new assets against the budget, with the certified year-to-date figure beside them.",
             note="Forecasts are labeled and not certified; each side is summed on its own and lined up by channel."),
        dict(name="Revenue vs Plan and Forecast", aggregation="additive",
             expr=("[Net Fee Revenue] year to date - sum(plan_line.planned_amount) of the revenue plan P&L lines of the Annual "
                   "Budget for the plan period; and against sum(flow_revenue_forecast.forecast_net_revenue) of the current "
                   "Rolling Forecast, by channel"),
             source=("DP-490", "Revenue vs Plan and Forecast"),
             description="Net fee revenue year to date against the budget and the current forecast.",
             note="Combines SM-28's certified Net Fee Revenue (referenced) with DP-490's plan lines."),
        dict(name="Plan Variance by Driver", aggregation="additive",
             expr="sum(plan_variance.variance_amount) for the compared plan version, by variance_driver",
             source=("DP-490", "Plan Variance by Driver"),
             description="Why NNA and revenue differ from plan, by variance driver, with commentary."),

        # ================= DP-495 supply chain, reconciliation and suspense ============================================
        dict(name="Loads Received On Time %", aggregation="ratio",
             numerator="count(feed_load) with load_status in ('Received', 'Loaded', 'Loaded with Warnings') for the business date",
             denominator="count(feed_load) expected for the business date (including Expected, Missing, Partial and Received Late)",
             source=("DP-495", "Loads Received On Time %"),
             description="The share of expected client asset feed loads that arrived on time.",
             note="On time is judged by load status; 06 Load has no expected arrival time (GAP-06-012)."),
        dict(name="Missing, Partial or Rejected Loads", aggregation="additive",
             expr="count(feed_load) where load_status in ('Missing', 'Partial', 'Rejected')",
             source=("DP-495", "Missing, Partial or Rejected Loads"),
             description="Feed loads that did not arrive whole in the period, by feed and provider."),
        dict(name="Load Reject Rate %", aggregation="ratio",
             numerator="sum(feed_load.rejected_record_count)", denominator="sum(feed_load.record_count)",
             source=("DP-495", "Load Reject Rate %"),
             description="The share of delivered records rejected at load."),
        dict(name="DQ Rule Pass Rate %", aggregation="ratio",
             numerator="sum(dq_result.records_tested - dq_result.records_failed)", denominator="sum(dq_result.records_tested)",
             source=("DP-495", "DQ Rule Pass Rate %"),
             description="The share of tested records that pass the data quality rules on 06 loads, by rule.",
             note="A ratio of sums rather than DP-495's mean of DQ Result % (open decision); threshold misses counted beside it."),
        dict(name="Reconciliation Match Rate %", aggregation="non_additive",
             expr="reconciliation_run.matched_pct of the latest run of each reconciliation on the business date",
             source=("DP-495", "Reconciliation Match Rate %"),
             description="How fully each client asset reconciliation matched on the business date, by reconciliation type.",
             note="A per-reconciliation rate; never averaged across reconciliations."),
        dict(name="Open Breaks by Age", aggregation="semi_additive",
             expr=("count and sum(abs(reconciliation_break.difference_amount)) where break_status in ('Open', 'Investigating'), "
                   "by break_age_days bucket (0-5, 6-30, over 30)"),
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Open Breaks by Age"),
             description="Open client asset reconciliation breaks and their value, by age."),
        dict(name="Breaks Over Tolerance", aggregation="semi_additive",
             expr=("count(reconciliation_break) open with abs(difference_amount) > reconciliation.absolute_tolerance or relative "
                   "difference > relative_tolerance_pct"),
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Breaks Over Tolerance"),
             description="Open breaks larger than their reconciliation's tolerance."),
        dict(name="Breaks Resolved in Period", aggregation="additive",
             expr="count(reconciliation_break) with resolution_date in the period, by root_cause_category",
             source=("DP-495", "Breaks Resolved in Period"),
             description="Breaks closed in the period by root cause, with the mean days to resolve."),
        dict(name="Unattributed Suspense Amount", aggregation="semi_additive",
             expr=("sum(unattributed_item.unattributed_amount) where resolution_status in ('New', 'Under Investigation', "
                   "'Awaiting Source')"),
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Unattributed Suspense Amount"),
             description="Client flows and assets held in suspense because they could not be attributed, by channel and reason.",
             note="Reported, never re-attributed here (CW-144)."),
        dict(name="Suspense Aged Over 30 Days", aggregation="semi_additive",
             expr="[Unattributed Suspense Amount] where first_seen_date is more than 30 days before the as-of date",
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Suspense Aged Over 30 Days"),
             description="Suspense older than 30 days."),
        dict(name="Suspense Share of Client Assets %", aggregation="ratio",
             numerator="[Unattributed Suspense Amount] by suspense_channel",
             denominator="[Client Assets] at dimension_type 'Channel' for the same channel and period end",
             source=("DP-495", "Suspense Share of Client Assets %"),
             description="Suspense as a share of the channel's certified Client Assets.",
             time_rule=_LAST),
        dict(name="Items Written Off to House", aggregation="additive",
             expr="sum(unattributed_item.unattributed_amount) and count of items moved to resolution_status 'Written Off to House' in the period",
             source=("DP-495", "Items Written Off to House"),
             description="Suspense written off to the house in the period, by channel."),
        dict(name="Intermediary Identity Match Rate %", aggregation="ratio",
             numerator=("count(identifier_crosswalk) in force whose latest match_result has match_status in ('Matched - Auto', "
                        "'Matched - Manual')"),
             denominator="count(identifier_crosswalk) in force",
             source=("DP-495", "Intermediary Identity Match Rate %"),
             description="The share of intermediary feed identifiers resolved to a party or account, by feed.",
             note="Intermediary feeds only; internal books are account-keyed (CW-144)."),
        dict(name="Suggested Matches Awaiting Review", aggregation="semi_additive",
             expr=("count(match_result) with match_status 'Suggested' and match_score between match_rule.review_threshold and "
                   "auto_accept_threshold"),
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Suggested Matches Awaiting Review"),
             description="Fuzzy identity matches waiting for a steward, by rule type and age."),
        dict(name="Active Attribution Overrides", aggregation="semi_additive",
             expr="count(attribution_override) in force on the as-of date, and the count with no approver",
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Active Attribution Overrides"),
             description="Manual attribution overrides in force, by scope and reason."),
        dict(name="Restatements and Net Impact", aggregation="additive",
             expr="count(restatement) approved in the period and sum(restatement.net_impact_amount), by restatement_reason",
             source=("DP-495", "Restatements and Net Impact"),
             description="Restatements of locked periods approved in the period and their net effect.",
             note="Grouped by reason or approval period, never by affected period (GAP-06-005)."),
        dict(name="Open Vendor Data Issues on Client Asset Feeds", aggregation="semi_additive",
             expr="count(vendor_data_issue) with issue_status not 'Resolved' whose dataset is delivered through a 06 feed",
             time_rule="as of the last business date in the selected range",
             source=("DP-495", "Open Vendor Data Issues"),
             description="Unresolved vendor data issues affecting client asset feeds, by type and severity."),
        dict(name="Period Reliance Flag", aggregation="non_additive",
             expr=("Y for a reporting period when, at the DP-008 lock, [Loads Received On Time %] = 100 for the month-end, "
                   "[Breaks Over Tolerance] = 0, [Suspense Share of Client Assets %] < 0.5 in every channel and no High "
                   "vendor data issue is open; N otherwise"),
             source=("DP-495", "Period Reliance Flag"),
             description="Whether a month-end's client asset figures passed every supply-chain test when they were locked.",
             note="One value per reporting period; the thresholds are the reference defaults (tailoring lever)."),
    ],

    excluded=[
        # ---- DP-008 ----
        # (every DP-008 measure is published)
        # ---- DP-006: the flow rows are inputs to DP-008's certified rule ----
        ("DP-006", "Flow Transactions Loaded", "A load count for the 06 stewards; the cross-feed load health is DP-495's Missing, Partial or Rejected Loads."),
        ("DP-006", "Client Asset Flow Amount (Pre-Treatment)", "The input DP-008 applies the flow treatment rule to; publishing it beside Net New Assets would invite a second NNA (one NNA rule, lead ruling)."),
        ("DP-006", "Own-Fund Flow Amount (Pre-Treatment)", "The input of the certified Gross Sales, Redemptions and Net Flows; published only through them."),
        ("DP-006", "Inter-Channel Transfer Pairing Breaks", "A pairing control for the 06 stewards in DP-006's own views; reconciliation health is published through DP-495."),
        ("DP-006", "Flows Without Source Record", "A lineage control for the 06 stewards; DP-495 publishes the source-book reconciliations across feeds."),
        ("DP-006", "Source Book Reconciliation Variance", "A per-book, per-date variance (non-additive) for stewards; the reconciliation runs and breaks are published through DP-495."),
        ("DP-006", "Duplicate Source Records", "A row-level control for the 06 stewards; not a cross-row business question."),
        ("DP-006", "Same-Owner Movement Flag", "A row flag; the same rows are published as DP-491's Same-Owner Transfers Excluded through the Linked Transaction indicator."),
        ("DP-006", "Late Correction Flag", "A row flag for stewards; the effect of late corrections on locked periods is published as Restatement Impact and Restatements and Net Impact."),
        ("DP-006", "Attributed Amount (Reporting Currency)", "Attribution split amounts of every flow row; the NNA-counted split amounts are published through DP-491 and DP-492 attribution rows, so the pre-treatment amount is not published again."),
        ("DP-006", "Attribution Rate %", "Advisor attribution of NNA flows is published as DP-491's Advisor Attribution Coverage %; intermediary attribution belongs to SM-27."),
        ("DP-006", "Unattributed Amount", "Suspense is published once, as DP-495's Unattributed Suspense Amount over the 06 Unattributed Items."),
        ("DP-006", "Flows Without Channel Assignment", "A steward control; flows without a channel reach this model as unattributed suspense (DP-495)."),
        ("DP-006", "Advisor and Campaign Attributed Flow Amount", "Pre-treatment keys that DP-008, DP-491 and DP-492 read; NNA by advisor and campaign is published from DP-008's Advisor and Campaign rows."),
        ("DP-006", "Intermediary Rows Resolved %", "Intermediary identity resolution is published as DP-495's Intermediary Identity Match Rate %."),
        # ---- DP-007: the position rows are inputs to DP-008 and DP-496 ----
        ("DP-007", "Account Asset Summary Market Value", "The input DP-008 certifies; its channel x holding type decomposition is published once as Client Assets by Channel and Holding Type (DP-496), which ties to the certified margins. A second sum of the same rows would be a rival Client Assets."),
        ("DP-007", "Own-Product Summary Market Value", "The same rows are published as the numerator of Own-Fund Share of Client Assets % and, certified, as Own-Fund Overlap."),
        ("DP-007", "Advised Account Summary Market Value", "An account-level input without the enrollment rule; the certified Advised Assets rule is DP-008's alone (spec)."),
        ("DP-007", "Counted Fund Shareholder Position Value", "Mixes firm-account positions (views of Client Holding 49 and the register 29, CW-007) with intermediary rows; only the intermediary rows are published (Intermediary-Held Own-Fund Value)."),
        ("DP-007", "Look-Through Coverage %", "Omnibus look-through quality for the 06 stewards; intermediary partner coverage is SM-27's question."),
        ("DP-007", "Attributed Position Value", "Position value by advisor and household; household Client Assets are DP-320's (SM-21) and the offering split is published from DP-496 (Client Assets by Offering)."),
        ("DP-007", "Unattributed Position Amount", "Suspense is published once, as DP-495's Unattributed Suspense Amount."),
        ("DP-007", "Source Reconciliation Variance", "Per share class and date, non-additive; the unit coverage rule's result reaches DP-241 (SM-11) and the reconciliation runs DP-495 publishes."),
        ("DP-007", "Summary to Book Variance", "Per account and date, non-additive; the Client Asset Summary vs Source Book reconciliation is published through DP-495's Reconciliation Match Rate %."),
        ("DP-007", "Accounts Without Channel Assignment", "A steward control in DP-007's own views; unassigned accounts reach this model as suspense (DP-495)."),
        ("DP-007", "Overlapping Channel Assignments", "A steward control in DP-007's own views; not a cross-row business question."),
        ("DP-007", "Stale Summaries", "A freshness control for stewards; feed timeliness is published as DP-495's Loads Received On Time %."),
        ("DP-007", "Loads Not Received", "Published once across feeds as DP-495's Missing, Partial or Rejected Loads."),
        ("DP-007", "Open Reconciliation Breaks", "Published once across feeds as DP-495's Open Breaks by Age."),
        ("DP-007", "Plan, ETF and Sponsor Reported Value", "Intermediary-reported and Attribution Only values (model-delivery assets are outside Client Assets and Firm AUM); intermediary partner assets are SM-27's (DP-493)."),
        # ---- DP-490: certified reads are published once from DP-008, DP-241 and DP-012 ----
        ("DP-490", "Ending Client Assets (from DP-008)", "A read of the certified Client Assets; published once as Client Assets."),
        ("DP-490", "Net New Assets (from DP-008)", "A read of the certified Net New Assets; published once."),
        ("DP-490", "Client Organic Growth Rate (from DP-008)", "A read of the certified Client Organic Growth Rate; published once."),
        ("DP-490", "Client Market Movement and Other (from DP-008)", "A read of the certified Client Market Movement and Other; published once."),
        ("DP-490", "Advised Assets (from DP-008)", "A read of the certified Advised Assets; published once."),
        ("DP-490", "Households, Clients and Funded Accounts (from DP-008)", "Reads of the certified Households, Clients and Funded Accounts; published once."),
        ("DP-490", "Own-Fund Net Flows (from DP-008)", "Reads of the certified Gross Sales, Redemptions and Net Flows; published once."),
        ("DP-490", "Firm AUM and Slices (from DP-241)", "Certified by SM-11 (DP-241); referenced as SM-11/Firm AUM and its slice metrics, shown in its own section and never added to Client Assets."),
        ("DP-490", "Net Fee Revenue (from DP-012)", "Certified by SM-28 (DP-012); referenced as SM-28/Net Fee Revenue."),
        ("DP-490", "Client Revenue Yield (from DP-497)", "DP-497 is SM-28's product; its yield is read there (reference once SM-28's definition lands)."),
        ("DP-490", "Operating Margin by Business Line (from DP-499)", "DP-499 is SM-28's product; read there."),
        ("DP-490", "Channel Market Share (from DP-505)", "DP-505 is SM-27's product; read there."),
        ("DP-490", "Restatement Impact (from DP-008)", "The same number as DP-008 Restatement Impact; published once."),
        # ---- DP-491 ----
        ("DP-491", "Net New Assets (from DP-008)", "A read of the certified Net New Assets at Dimension Type Total; published once."),
        ("DP-491", "NNA by Channel (from DP-008)", "Certified Net New Assets at Dimension Type Channel; the same metric with dimension_type 'Channel'."),
        ("DP-491", "NNA by Business Line (from DP-008)", "Certified Net New Assets at Dimension Type Business Line."),
        ("DP-491", "NNA by Advisor of Record (from DP-008)", "Certified Net New Assets at Dimension Type Advisor (restricted rows)."),
        ("DP-491", "NNA by Holding Type and Share Class (from DP-008)", "Certified Net New Assets at Dimension Types Holding Type and Share Class."),
        ("DP-491", "NNA by Client Segment (from DP-008)", "Certified Net New Assets at Dimension Type Segment."),
        ("DP-491", "NNA Attribution Rows (from DP-008)", "The row set itself, published as the nna_attribution table; its sum equals Net New Assets, so no second metric is defined."),
        ("DP-491", "Net Inter-Channel Transfers by Channel (from DP-008)", "Certified Net Inter-Channel Transfers at Dimension Type Channel; published once."),
        ("DP-491", "Client Organic Growth Rate by Channel and Advisor (from DP-008)", "Certified Client Organic Growth Rate at Dimension Types Channel and Advisor; published once."),
        # ---- DP-492 ----
        ("DP-492", "Net New Assets (from DP-008)", "A read of the certified Net New Assets; published once."),
        ("DP-492", "NNA by Campaign (from DP-008)", "Certified Net New Assets at Dimension Type Campaign, joined to the campaign dimension."),
        ("DP-492", "Cohort Client Assets (from DP-320)", "DP-320's Household Client Assets, published by SM-21 (being written at WP2); referenced once its metric name is fixed (open decision)."),
        ("DP-492", "Cohort Household Retention %", "Needs DP-320's Household Client Assets (SM-21); published once that reference exists (open decision)."),
        ("DP-492", "Cohort Asset Retention %", "Needs DP-320's Household Client Assets (SM-21); published once that reference exists (open decision)."),
        # ---- DP-495 ----
        ("DP-495", "Ending Client Assets (from DP-008)", "A read of the certified Client Assets (the suspense denominator); published once."),
        # ---- DP-496 ----
        ("DP-496", "Ending Client Assets (from DP-008)", "A read of the certified Client Assets (the cross-tab margins); published once."),
        ("DP-496", "Client Assets by Segment (from DP-008)", "Certified Client Assets at Dimension Type Segment; published once."),
        ("DP-496", "Own-Fund Overlap Amount (from DP-008)", "A read of the certified Own-Fund Overlap; published once."),
        ("DP-496", "Firm AUM (from DP-241)", "Certified by SM-11 (DP-241); referenced as SM-11/Firm AUM and its slices, never added to Client Assets."),
        ("DP-496", "Own Funds Outside Client Assets (from DP-241)", "DP-241's reconciling line (own funds slice less the overlap, netted there only); SM-11 publishes DP-241 (open decision)."),
        ("DP-496", "Own-Fund Share by Share Class Vehicle", "Needs counted Fund Shareholder Positions of firm client accounts, which are views of Client Holding 49 (CW-007) and would mix books with the 49 holdings table; the vehicle split is read from the Own Mutual Fund, Own ETF and Own CIT holding types instead."),
    ],

    access=dict(
        classification=("Confidential - Client (DP-008); Confidential - Personal Data (DP-006, DP-007, DP-491, DP-495); "
                        "Confidential - Financial (DP-490, DP-492, DP-496). Client-level and account-level rows are "
                        "Confidential - Personal Data; outputs are aggregates."),
        roles=[
            dict(role="channel_and_business_leadership", rows=("client_assets_flows at every Dimension Type, including "
                                                                "Advisor and Campaign rows; plan, forecast and mix tables"),
                 columns="certified and DP-490, DP-491, DP-492 and DP-496 metrics; no account, household or party key",
                 hidden=["txn_account", "summary_account", "holding_account", "omnibus_parent_account", "nna_client_household",
                         "milestone_party", "milestone_account", "touchpoint_party", "credited_salesperson"]),
            dict(role="client_and_channel_analytics", rows="all",
                 columns="all, with account and household keys for grouping only (never displayed)",
                 hidden=["credited_salesperson"]),
            dict(role="advisor_and_line_manager",
                 rows=("client_assets_flows rows of dimension_type 'Advisor' for the advisor and their reports, plus Total and "
                       "Channel rows; nna_attribution rows of their own coverage"),
                 columns="Net New Assets, Client Organic Growth Rate and the DP-491 advisor metrics",
                 hidden=["txn_account", "summary_account", "holding_account", "nna_client_household", "credited_salesperson",
                         "milestone_party", "touchpoint_party"]),
            dict(role="marketing_analytics",
                 rows=("Campaign and Total rows of client_assets_flows; DP-492 tables aggregated to campaign and cohort, with a "
                       "10-household minimum cell"),
                 columns="campaign and cohort metrics",
                 hidden=["milestone_party", "milestone_account", "touchpoint_party", "txn_account", "nna_covering_advisor"]),
            dict(role="client_asset_data_stewards",
                 rows="DP-495 tables, flow_transactions, intermediary_positions and account_asset_summary",
                 columns="all supply-chain columns; intermediary identifiers in the steward drill-down only",
                 hidden=["nna_client_household", "milestone_party", "touchpoint_party", "credited_salesperson"]),
            dict(role="broad_internal",
                 rows=("client_assets_flows rows of dimension_type in ('Total', 'Channel', 'Holding Type', 'Business Line', "
                       "'Share Class', 'Segment'); no Advisor or Campaign rows; no transaction, attribution, position, "
                       "holding or supply-chain table"),
                 columns="certified client asset, flow and count metrics and the referenced Firm AUM",
                 hidden=["dimension_key on Advisor rows", "txn_account", "summary_account", "holding_account",
                         "omnibus_parent_account", "nna_covering_advisor", "nna_client_household", "credited_salesperson",
                         "milestone_party", "milestone_account", "touchpoint_party"]),
        ]),
    # No table exposes a name, address, tax identifier or special-category attribute (CD-344): account, household and party
    # keys are grouping keys for analytics and are hidden from every display role; the special-category holds live in
    # SM-24 and SM-29 restricted views. Advisor (EMP-) rows are performance data about employees and are restricted.

    verified_questions=[
        dict(question="What were Client Assets at last month-end by channel and by holding type, and how do they reconcile to Firm AUM?",
             answer=("Client Assets with dimension_type = 'Channel' (then 'Holding Type'), latest locked period_end_date; Client "
                     "Assets by Channel and Holding Type for the cross-tab, whose margins equal those two reads; Own-Fund "
                     "Overlap at Total. Beside them, in a separate section, Firm AUM and its three slices (SM-11) and the "
                     "DP-241 reconciliation by reference: AUM Gross Difference, AUM Unexplained Residual and AUM Explained %. "
                     "Client Assets and Firm AUM are never added."),
             sql=("select cv.code_label as channel, sum(f.ending_client_assets)\n"
                  "from dp_008.measure_value f join dp_013.code_value cv on f.dimension_key = cv.code\n"
                  "where f.dimension_type = 'Channel' and f.period_type = 'Month'\n"
                  "  and <locked snapshot of record> and f.period_end_date = <latest locked month-end>\n"
                  "group by 1")),
        dict(question="What were net new assets last quarter by channel, by advisor of record and by campaign?",
             answer=("Net New Assets summed over the three locked months of the quarter (period_type 'Month'), once with "
                     "dimension_type = 'Channel', once with 'Advisor' (joined to DP-009 Employee; restricted rows) and once "
                     "with 'Campaign' (joined to the DP-492 campaign dimension); each type adds up to the Total row. NNA "
                     "Without Advisor of Record and Campaign-Attributed Share of NNA % show what the advisor and campaign "
                     "rows leave out; NNA Components by Flow Type explains the channel figure.")),
        dict(question="How did Client Assets move from the start of the year to the latest month, by channel?",
             answer=("Beginning Client Assets (first month of the year), Net New Assets, Net Inter-Channel Transfers and Client "
                     "Market Movement and Other (summed over the months) and Client Assets (last month), dimension_type "
                     "'Channel'. Beginning + NNA + Net Inter-Channel Transfers + Market Movement = Ending; transfers net to "
                     "zero at Total. Client Organic Growth Rate annualizes NNA over Beginning Client Assets.")),
        dict(question="How many funded accounts, clients and households does each channel have, and how did households change?",
             answer=("Funded Accounts, Clients and Households at the latest locked month-end with dimension_type 'Channel' and "
                     "'Total'; channel values are distinct counts and do not add to Total. Net Household Change compares "
                     "Households with the prior month-end at the same dimension_key.")),
        dict(question="What share of client assets is in our own funds by channel, and where does the brokerage wallet go?",
             answer=("Own-Fund Share of Client Assets % by summary_distribution_channel at the month-end (account_asset_summary); "
                     "Client Assets by Holding Type Group; Third-Party and Securities Wallet Share by Instrument Type from "
                     "brokerage_client_holdings (End of Day) against the 49 summary rows.")),
        dict(question="Can last month-end's client asset figures be relied on?",
             answer=("Period Reliance Flag for the reporting period, with Loads Received On Time %, Breaks Over Tolerance, "
                     "Suspense Share of Client Assets % by suspense_channel and Open Vendor Data Issues on Client Asset Feeds at the lock date.")),
    ],

    cannot_answer=[
        dict(question="Client Assets or Net New Assets by two dimensions at once (for example channel by advisor or holding type by segment) as certified figures",
             why=("DP-008 keeps one dimension per Measure Value row (CW-141); stored cross-tabs are a tailoring lever not "
                  "built. Channel by holding type is available as DP-496's decomposition, which ties to the certified margins."),
             gap=""),
        dict(question="Client Assets by household, or the household totals of a cohort",
             why=("DP-008 has no household Dimension Type (taxonomy gap noted in DP-008); household Client Assets are DP-320's "
                  "and are published by SM-21."),
             gap=""),
        dict(question="Which restatement explains the change in a given month",
             why="Restatement Affected Periods is free text, so a restatement cannot be tied to the periods and snapshots it replaced.",
             gap="GAP-06-005"),
        dict(question="Which 06 attribution records are counted in Net New Assets, from the records themselves",
             why=("06 Attribution Record has no Measure or Snapshot reference, so the NNA-counted set is identified by "
                  "DP-008's publication (DP-491 and DP-492), not by an attribute; an NNA-counted flag would close it."),
             gap=""),
        dict(question="Whether a feed load was late against its expected arrival time",
             why="06 Data Feed has no expected arrival time and Load no load timestamp; on time is read from the load status.",
             gap="GAP-06-012"),
        dict(question="Which position source won for an intermediary position",
             why="No attribute records the source chosen under Source Precedence Rank; the filter derives it.",
             gap="GAP-06-007"),
    ],

    open_decisions=[
        ("DP-008 Measure Value holds Measure in its key and also the wide certified measure columns. This model reads the "
         "wide columns and assumes each is populated only on its own Measure's row (or one row per cell); if every row "
         "repeats the wide columns, the table must also pin measure. Confirm with the Head of Client & Channel Analytics."),
        ("DP-008: confirm a locked snapshot holds one Data Basis per cell (actual or estimated). If both can exist for the "
         "same cell, the model must prefer actual to avoid double counting."),
        ("DP-008: confirm that Final and Restated are the only locked Snapshot Types and that a restatement creates a "
         "Restated snapshot that supersedes the Final one (the always filter reads the latest locked version)."),
        ("DP-008 and register: 'Client Assets Excluding Intermediary-Held' is marked Certified (CW-011) in DP-008's spec but "
         "is not in register.CERTIFIED. Either register it (SM-20, DP-008) or drop 'Certified' from the spec; it is "
         "published here under its spec name."),
        ("DP-008: Client Organic Growth Rate says 'annualized' without a method; this model uses simple annualization "
         "(x 12 / months). Record the method in the Measure Definition."),
        ("Firm AUM reconciliation by reference: this model references SM-11's AUM Gross Difference, AUM Unexplained Residual "
         "and AUM Explained %, which still describe DP-241's wholesale 'Attributed AUM' bridge in SM-11's file. When SM-11 "
         "re-points DP-241 to Client Assets (Gross Difference = Firm AUM - Ending Client Assets) and publishes 'Own Funds "
         "Outside Client Assets', update these references (and reference that line for DP-496)."),
        ("DP-492 cohort measures (Cohort Client Assets, Cohort Household Retention %, Cohort Asset Retention %) need DP-320's "
         "Household Client Assets, published by SM-21. Reference SM-21's metric once its name is fixed, then publish the "
         "two retention ratios here."),
        ("DP-490 reads Client Revenue Yield (DP-497) and Operating Margin (DP-499) from SM-28 and Channel Market Share "
         "(DP-505) from SM-27; add the refs when those definitions land."),
        ("DP-491 and DP-492 identify the NNA-counted attribution rows only by DP-008's publication. Add an NNA-counted "
         "indicator (or Measure and Snapshot references) to 06 Attribution Record so the semantic filter can be enforced on "
         "a column."),
        ("DP-007 Position: confirm which rows carry the Omnibus Residual Amount (the counted intermediary rows or an omnibus "
         "parent row of another Aggregation Role); the intermediary_positions filter keeps both and takes the residual once "
         "per omnibus parent x share class x valuation date."),
        ("DP-495 DQ Rule Pass Rate % is defined as a mean of DQ Result %; this model publishes a ratio of sums (records "
         "passed / records tested) so large loads weigh more. Confirm with the product owner."),
        ("Holding type groups: the 11-to-4 CW-011 mapping is stated in the metric expression because no attribute holds it; "
         "add a Holding Type Group to the 06 holding type code list."),
        ("Clients and Households count workplace participants of recordkept plans (CW-011 reference default); the lever is "
         "owners of non-plan accounts only."),
    ],
)
