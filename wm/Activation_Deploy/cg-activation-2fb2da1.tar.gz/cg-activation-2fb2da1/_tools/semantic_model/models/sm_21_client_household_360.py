"""Semantic model SM-21 Client & Household 360. See CONTRACT.md.

Publishes DP-320 Household 360 (the household view: members, accounts, the household decomposition of client assets,
advised and held-away assets, plan, goal, coverage, tier and service exceptions), DP-307 Trust Fiduciary Record (trusts,
roles, beneficial interests, distribution requests, principal and income allocations, fiduciary returns and estate
cases) and DP-351 Fiduciary Account Review Compliance (12 CFR 9.6 reviews and their exceptions). DP-093 Account Master is
the Client Account shared dimension of SM-00; DP-321, DP-324 and DP-329 do not list the BI semantic model delivery and are
not published here (register note, WP2).

Owns no certified metric. It references SM-20 Client Assets, Households and Advised Assets and SM-08 Personal Rate of
Return (CW-011), and slices them by household.

Double-counting rules kept closed here:
- Household Client Assets is an operational decomposition of the certified Client Assets (SM-20), never a second
  definition: summed over every household and added to Non-Household Client Assets it ties to Client Assets at the DP-008
  Total, and the tie-out variance is published (CW-211). Client Assets are never added to Firm AUM or to held-away assets
  (CW-024).
- A household is a DP-240 Party of Party Type Household (PTY-HH-). Household to account is many-to-many and effective
  dated (Household Membership, then Account Party Role): every path through it pins the membership and the owner role in
  effect on the as-of date, and assigns each account once, to the household of its Primary Owner.
- Personal Rate of Return pins its method in the table filter and in the metric name: one time-weighted table and one
  money-weighted table, never one metric over a mixed basis; Final or Restated rows, highest version.
- Trust assets are client holdings of the trust's accounts and count in Client Assets; nothing on a trust row is summed
  as assets. The special-needs values (Trust Instrument Type, Provision Type, Distribution Standard) are blanked in the
  published rows and the special-category distribution purposes never reach this model (CW-213, CD-344).
"""

# Household membership and account ownership in effect on the measurement date (CW-011: household metrics pin the
# membership as of the measurement date).
_MEMBERSHIP_IN_EFFECT = ("membership_status = 'Active' and membership_effective_from <= :as_of_date and "
                         "(membership_effective_to is null or membership_effective_to > :as_of_date)")
_OWNER_IN_EFFECT = ("account_role_effective_from <= :as_of_date and "
                    "(account_role_effective_to is null or account_role_effective_to > :as_of_date)")
# Personal Rate of Return rows of record for a household (DP-145 Personal Return Value rule)
_PRR_OF_RECORD = ["personal_return_subject_type = 'Household Performance Group'",
                  "personal_return_status in ('Final', 'Restated')",
                  "personal_return_version = (select max(v.personal_return_version) from dp_145.personal_rate_of_return v "
                  "where v.personal_rate_of_return_id = personal_rate_of_return_id and v.personal_return_status in "
                  "('Final', 'Restated'))"]

# Names and identity of people: only client data, advisor and trust roles see them.
_PERSON_PII = ["household_name", "primary_member", "client_display_name", "given_name", "family_name", "date_of_birth",
               "date_of_death", "summary_account", "fund_position_account", "role_holder_party", "beneficiary_party",
               "request_beneficiary", "filing_entity_party", "filer_ein", "decedent", "personal_representative",
               "trust_party", "reviewer"]
# Trust detail that is special category for some values (CD-344) or sensitive by nature: hidden from broad roles, who see
# the trust measures as aggregates only.
_TRUST_SENSITIVE = ["trust_instrument_type", "provision_type", "distribution_standard", "investment_constraint_indicator",
                    "requested_amount", "request_status", "request_received_date", "interest_share_percentage",
                    "beneficial_interest_type", "qualified_beneficiary_indicator"]

MODEL = dict(
    id="SM-21",
    status="Draft",
    description=(
        "Households, their member clients and accounts, for client data stewards, advice and service leadership, "
        "advisors and the trust company: who is in each household, what it holds with the firm (as a decomposition of "
        "certified Client Assets), what it holds elsewhere, its personal rate of return, and where its plan, coverage, "
        "service tier or fee household is out of line. The trust panel adds the fiduciary record of the trusts the firm "
        "administers and the 12 CFR 9.6 review compliance of those trusts."),

    questions=[
        "What is each household's personal rate of return, and how is it computed? (acceptance question 9)",
        "How do household client assets add up to the certified Client Assets, and what sits outside any household?",
        "Which households with advised assets have no primary advisor, no current financial plan or goals off track?",
        "Which households sit in the wrong service tier for their assets, and which bill in a different fee household?",
        "How many trusts does the firm administer by situs and revocability, and which lack a trustee, an instrument or a "
        "linked account?",
        "Which fiduciary account reviews are late or overdue, and which review exceptions are open, aged or conflicts?",
    ],

    tables=[
        # ---- DP-320 Household 360 ----------------------------------------------------------------------------------
        dict(name="household_360", product="DP-320", entity="Fact Household 360", kind="Fact",
             grain="Client Household (02 PTY-HH-) x as-of date (daily snapshot)",
             default_filter="as_of_date_key = latest business-day as-of date",
             dimensions=[
                 dict(name="household_key", attr="Household Key"),
                 dict(name="as_of_date_key", attr="As-Of Date Key"),
                 dict(name="protection_flag_present", attr="Protection Flag Present (from DP-322)",
                      note="Y or N as DP-322 publishes it for any member party or household account; no reason, basis "
                           "or date is carried (CW-213, CD-344). Hidden from broad roles."),
             ],
             facts=[
                 dict(name="households_in_view", attr="Households in View"),
                 dict(name="household_members", attr="Household Members"),
                 dict(name="household_client_assets", attr="Household Client Assets",
                      note="Decomposition of SM-20 Client Assets (CW-211); never a second definition."),
                 dict(name="non_household_client_assets", attr="Non-Household Client Assets",
                      note="The firm-level reconciling item for the as-of date (omnibus residual and accounts with no "
                           "household owner); not a household value, never summed over household rows."),
                 dict(name="household_client_assets_tie_out_variance", attr="Household Client Assets Tie-Out Variance"),
                 dict(name="household_advised_assets", attr="Household Advised Assets",
                      note="Decomposition of SM-20 Advised Assets."),
                 dict(name="managed_share_of_household_assets_pct", attr="Managed Share of Household Assets %"),
                 dict(name="held_away_assets", attr="Held-Away Assets",
                      note="Aggregated outside balances; never Client Assets and never added to them (CW-024)."),
                 dict(name="households_without_current_plan", attr="Households Without Current Plan"),
                 dict(name="household_goals_off_track", attr="Household Goals Off Track"),
                 dict(name="fee_household_alignment_breaks", attr="Fee Household Alignment Breaks"),
                 dict(name="households_without_primary_advisor", attr="Households Without Primary Advisor"),
                 dict(name="service_tier_qualification_mismatch", attr="Service Tier Qualification Mismatch"),
                 dict(name="recent_service_contacts", attr="Recent Service Contacts"),
                 dict(name="trust_linked_households", attr="Trust-Linked Households"),
             ],
             hidden=[
                 ("Households (from DP-008)", "A copy of the certified count; read with ref='SM-20/Households'."),
                 ("Ending Client Assets (from DP-008)", "A copy of the certified number; read with ref='SM-20/Client Assets'."),
                 ("Advised Assets (from DP-008)", "A copy of the certified number; read with ref='SM-20/Advised Assets'."),
                 ("Household Personal Rate of Return (from DP-145)",
                  "A copy of the certified return; read with ref='SM-08/Personal Rate of Return' through the "
                  "household_return tables, which pin the method."),
             ]),
        dict(name="household_client_assets", product="DP-320", entity="Fact Household Client Assets", kind="Fact",
             grain="member account x as-of date x holding type (DP-007 account asset summary rows DP-008 counts)",
             always_filter=["summary_source_book in the DP-008 Client Assets scope (the rows DP-008 counts; rule applied "
                            "by reference, never restated)"],
             default_filter="summary_as_of_date = latest business-day as-of date",
             dimensions=[
                 dict(name="summary_account", attr="Summary Account"),
                 dict(name="summary_as_of_date", attr="Summary As-Of Date"),
                 dict(name="summary_holding_type", attr="Summary Holding Type"),
                 dict(name="summary_source_book", attr="Summary Source Book"),
                 dict(name="advised_assets_indicator", attr="Advised Assets Indicator"),
             ],
             facts=[dict(name="summary_market_value", attr="Summary Market Value",
                         note="Account-level drill of Household Client Assets; with the Counted - Intermediary fund "
                              "positions below it makes up the household value.")]),
        dict(name="fund_position_view", product="DP-320", entity="Fact Fund Position View", kind="Fact",
             grain="06 fund shareholder position (a view), Counted - Intermediary rows only",
             always_filter=["aggregation_role = 'Counted - Intermediary'"],
             dimensions=[
                 dict(name="position_id", attr="Position ID"),
                 dict(name="fund_position_account", attr="Account"),
                 dict(name="share_class", attr="Share Class"),
                 dict(name="valuation_date", attr="Valuation Date"),
                 dict(name="aggregation_role", attr="Aggregation Role"),
             ],
             facts=[dict(name="position_market_value", attr="Market Value",
                         note="Only the intermediary-held positions DP-008 adds beyond the summary rows; the direct "
                              "positions are already in the summary rows (a view of 49) and are filtered out.")],
             hidden=[("Omnibus Parent Account", "The omnibus residual is a firm-level reconciling item, read only "
                                                "through Non-Household Client Assets."),
                     ("Omnibus Residual Amount", "Read only through Non-Household Client Assets; never by household.")]),
        # Household and client are role-played views of the SM-00 DP-240 Party.
        dict(name="household", product="DP-240", entity="Party", kind="Dimension",
             always_filter=["party_type = 'Household'"],
             dimensions=[
                 dict(name="household_id", attr="Party ID"),
                 dict(name="household_name", attr="Household Name"),
                 dict(name="household_formation_basis", attr="Household Formation Basis"),
                 dict(name="primary_member", attr="Primary Member"),
                 dict(name="membership_last_confirmed_date", attr="Membership Last Confirmed Date"),
                 dict(name="household_status", attr="Party Status"),
                 dict(name="household_relationship_stage", attr="Relationship Stage"),
             ]),
        dict(name="client", product="DP-240", entity="Party", kind="Dimension",
             always_filter=["party_type <> 'Household'"],
             dimensions=[
                 dict(name="client_id", attr="Party ID"),
                 dict(name="client_party_type", attr="Party Type"),
                 dict(name="client_display_name", attr="Party Display Name"),
                 dict(name="given_name", attr="Given Name"),
                 dict(name="family_name", attr="Family Name"),
                 dict(name="date_of_birth", attr="Date of Birth"),
                 dict(name="date_of_death", attr="Date of Death"),
                 dict(name="client_status", attr="Party Status"),
                 dict(name="client_relationship_stage", attr="Relationship Stage"),
             ]),
        dict(name="household_membership", product="DP-240", entity="Household Membership", kind="Bridge",
             grain="household x member party x membership effective period",
             always_filter=[_MEMBERSHIP_IN_EFFECT],
             dimensions=[
                 dict(name="membership_household", attr="Household"),
                 dict(name="household_member", attr="Household Member"),
                 dict(name="household_member_role", attr="Household Member Role"),
                 dict(name="membership_status", attr="Membership Status"),
                 dict(name="membership_effective_from", attr="Membership Effective From"),
                 dict(name="membership_effective_to", attr="Membership Effective To"),
             ]),
        dict(name="account_owner", product="DP-093", entity="Account Party Role", kind="Bridge",
             grain="account x party x account role type x effective period, owner role in effect",
             always_filter=[_OWNER_IN_EFFECT],
             default_filter="account_role_type = 'Primary Owner' (each account assigned once, to its Primary Owner's "
                            "household, as DP-320 assigns it; lift to see joint owners)",
             dimensions=[
                 dict(name="role_account", attr="Role Account"),
                 dict(name="role_party", attr="Role Party"),
                 dict(name="account_role_type", attr="Account Role Type"),
                 dict(name="account_role_effective_from", attr="Account Role Effective From"),
                 dict(name="account_role_effective_to", attr="Account Role Effective To"),
             ]),
        # ---- Personal Rate of Return (DP-145, the certified source; read to slice SM-08's metric by household) ----------
        dict(name="household_performance_group", product="DP-145", entity="Household Performance Group",
             kind="Dimension",
             always_filter=["performance_group_type = 'Default (All Household Accounts)'",
                            "performance_group_status = 'Active'"],
             dimensions=[
                 dict(name="household_performance_group_id", attr="Household Performance Group ID"),
                 dict(name="group_household", attr="Group Household"),
                 dict(name="performance_group_type", attr="Performance Group Type"),
                 dict(name="performance_group_status", attr="Performance Group Status"),
             ]),
        dict(name="household_performance_group_member", product="DP-145", entity="Household Performance Group Member",
             kind="Bridge", grain="household performance group x member account x inclusion period",
             always_filter=["member_inclusion_date <= personal_return_period_end_date and (member_exclusion_date is "
                            "null or member_exclusion_date > personal_return_period_start_date)"],
             dimensions=[
                 dict(name="member_performance_group", attr="Member Performance Group"),
                 dict(name="member_account", attr="Member Account"),
                 dict(name="member_inclusion_date", attr="Member Inclusion Date"),
                 dict(name="member_exclusion_date", attr="Member Exclusion Date"),
             ]),
        dict(name="household_return_twr", product="DP-145", entity="Personal Rate of Return", kind="Fact",
             grain="household performance group x period start x period end x fee basis (time-weighted, version of "
                   "record)",
             always_filter=_PRR_OF_RECORD + ["personal_return_method = 'Time-Weighted'"],
             default_filter="personal_return_fee_basis = 'Net of Fees'",
             dimensions=[
                 dict(name="personal_rate_of_return_id", attr="Personal Rate of Return ID"),
                 dict(name="personal_return_version", attr="Personal Return Version"),
                 dict(name="personal_return_subject_type", attr="Personal Return Subject Type"),
                 dict(name="personal_return_group", attr="Personal Return Group"),
                 dict(name="period_start_date", attr="Personal Return Period Start Date"),
                 dict(name="period_end_date", attr="Personal Return Period End Date"),
                 dict(name="period_basis", attr="Personal Return Period Basis"),
                 dict(name="return_method", attr="Personal Return Method"),
                 dict(name="calculation_method", attr="Personal Return Calculation Method"),
                 dict(name="fee_basis", attr="Personal Return Fee Basis"),
                 dict(name="annualized_indicator", attr="Personal Return Annualized Indicator"),
                 dict(name="return_status", attr="Personal Return Status"),
                 dict(name="restatement_cause", attr="Personal Return Restatement Cause"),
             ],
             facts=[
                 dict(name="personal_return_value", attr="Personal Return Value",
                      note="Read by SM-08/Personal Rate of Return; null where DP-145 suppresses it."),
                 dict(name="beginning_market_value", attr="Beginning Market Value",
                      note="Input of the return, shown to explain it; never summed as Client Assets."),
                 dict(name="ending_market_value", attr="Ending Market Value",
                      note="Input of the return; never summed as Client Assets."),
                 dict(name="net_external_flows", attr="Net External Flows",
                      note="Input of the return; never Net New Assets (SM-20)."),
                 dict(name="fees_deducted", attr="Fees Deducted",
                      note="Input of net-of-fee returns; never Client Fee Revenue (SM-28)."),
             ]),
        dict(name="household_return_mwr", product="DP-145", entity="Personal Rate of Return", kind="Fact",
             grain="household performance group x period start x period end x fee basis (money-weighted, version of "
                   "record)",
             always_filter=_PRR_OF_RECORD + ["personal_return_method = 'Money-Weighted (IRR)'"],
             default_filter="personal_return_fee_basis = 'Net of Fees'",
             dimensions=[
                 dict(name="personal_rate_of_return_id", attr="Personal Rate of Return ID"),
                 dict(name="personal_return_version", attr="Personal Return Version"),
                 dict(name="personal_return_group", attr="Personal Return Group"),
                 dict(name="period_start_date", attr="Personal Return Period Start Date"),
                 dict(name="period_end_date", attr="Personal Return Period End Date"),
                 dict(name="period_basis", attr="Personal Return Period Basis"),
                 dict(name="return_method", attr="Personal Return Method"),
                 dict(name="calculation_method", attr="Personal Return Calculation Method"),
                 dict(name="fee_basis", attr="Personal Return Fee Basis"),
                 dict(name="annualized_indicator", attr="Personal Return Annualized Indicator"),
                 dict(name="return_status", attr="Personal Return Status"),
             ],
             facts=[
                 dict(name="personal_return_value", attr="Personal Return Value"),
                 dict(name="beginning_market_value", attr="Beginning Market Value"),
                 dict(name="ending_market_value", attr="Ending Market Value"),
                 dict(name="net_external_flows", attr="Net External Flows"),
                 dict(name="fees_deducted", attr="Fees Deducted"),
             ]),
        # ---- DP-307 Trust Fiduciary Record ---------------------------------------------------------------------------
        dict(name="trust", product="DP-307", entity="Trust", kind="Dimension",
             default_filter="the current SCD type 2 status period of each trust",
             dimensions=[
                 dict(name="trust_id", attr="Trust ID"),
                 dict(name="trust_party", attr="Trust Party"),
                 dict(name="trust_instrument_type", attr="Trust Instrument Type",
                      note="The Special Needs / Supplemental Needs Trust value is blanked in every published row "
                           "(CD-344); hidden from broad roles."),
                 dict(name="revocability", attr="Revocability"),
                 dict(name="situs_jurisdiction", attr="Situs Jurisdiction"),
                 dict(name="governing_law_jurisdiction", attr="Governing Law Jurisdiction"),
                 dict(name="administering_trust_officer", attr="Administering Trust Officer"),
                 dict(name="trust_status", attr="Trust Status"),
                 dict(name="trust_termination_date", attr="Trust Termination Date"),
             ]),
        dict(name="trust_role", product="DP-307", entity="Trust Role", kind="Bridge",
             grain="trust x role holder x trust role type x role period",
             default_filter="role_effective_from <= :as_of_date and (role_effective_to is null or role_effective_to > "
                            ":as_of_date)",
             dimensions=[
                 dict(name="role_trust", attr="Role Trust"),
                 dict(name="trust_role_type", attr="Trust Role Type"),
                 dict(name="role_holder_party", attr="Role Holder Party"),
                 dict(name="role_holder_entity", attr="Role Holder Entity"),
                 dict(name="appointment_source", attr="Appointment Source"),
                 dict(name="role_acceptance_date", attr="Role Acceptance Date"),
                 dict(name="role_effective_from", attr="Role Effective From"),
                 dict(name="role_effective_to", attr="Role Effective To"),
             ]),
        dict(name="beneficial_interest", product="DP-307", entity="Beneficial Interest", kind="Bridge",
             grain="trust x beneficiary x interest type x effective period",
             default_filter="interest in effect on the as-of date (Interest Effective From / To)",
             dimensions=[
                 dict(name="interest_trust", attr="Interest Trust"),
                 dict(name="beneficiary_party", attr="Beneficiary Party"),
                 dict(name="beneficial_interest_type", attr="Beneficial Interest Type"),
                 dict(name="qualified_beneficiary_indicator", attr="Qualified Beneficiary Indicator"),
                 dict(name="interest_effective_from", attr="Interest Effective From"),
                 dict(name="interest_effective_to", attr="Interest Effective To"),
             ],
             facts=[dict(name="interest_share_percentage", attr="Interest Share Percentage",
                         note="Summed only within one trust and one interest test (Beneficial Interest Share Gaps).")]),
        dict(name="trust_term_provision", product="DP-307", entity="Trust Term Provision", kind="Dimension",
             always_filter=["provision_type and distribution_standard carry the blanked special-needs values only as "
                            "blanks (CD-344); no relabeled value is published"],
             dimensions=[
                 dict(name="provision_trust", attr="Provision Trust"),
                 dict(name="provision_type", attr="Provision Type"),
                 dict(name="provision_sequence", attr="Provision Sequence"),
                 dict(name="provision_instrument_version", attr="Provision Instrument Version"),
                 dict(name="distribution_standard", attr="Distribution Standard"),
                 dict(name="investment_constraint_indicator", attr="Investment Constraint Indicator"),
                 dict(name="provision_effective_from", attr="Provision Effective From"),
                 dict(name="provision_effective_to", attr="Provision Effective To"),
             ]),
        dict(name="distribution_request", product="DP-307", entity="Trust Distribution Request", kind="Fact",
             grain="trust distribution request (TDRQ-), non-special-category rows only",
             always_filter=["distribution_purpose not in ('Health / Medical', 'Disability Care', 'Hardship / "
                            "Emergency') (excluded at extraction; DP-352 is the only restricted view, CW-213)"],
             dimensions=[
                 dict(name="distribution_request_id", attr="Distribution Request ID"),
                 dict(name="request_trust", attr="Request Trust"),
                 dict(name="request_beneficiary", attr="Request Beneficiary"),
                 dict(name="request_received_date", attr="Request Received Date"),
                 dict(name="request_status", attr="Request Status"),
             ],
             facts=[dict(name="requested_amount", attr="Requested Amount")],
             hidden=[("Distribution Purpose", "Used only as the extraction filter and never published (CW-213, "
                                              "CD-344).")]),
        dict(name="principal_income_allocation", product="DP-307", entity="Principal and Income Allocation",
             kind="Fact", grain="trust x source event (49 account activity or 50 money movement) x allocation sequence",
             dimensions=[
                 dict(name="allocation_trust", attr="Allocation Trust"),
                 dict(name="source_account_activity", attr="Source Account Activity"),
                 dict(name="source_money_movement", attr="Source Money Movement"),
                 dict(name="allocation_date", attr="Allocation Date"),
                 dict(name="allocation_sequence", attr="Allocation Sequence"),
                 dict(name="receipt_or_disbursement_type", attr="Receipt or Disbursement Type"),
                 dict(name="allocation_character", attr="Allocation Character"),
                 dict(name="allocation_rule", attr="Allocation Rule"),
             ],
             facts=[dict(name="principal_amount", attr="Principal Amount",
                         note="A principal and income ledger amount, not a book of record (CW-076); never assets."),
                    dict(name="income_amount", attr="Income Amount")]),
        dict(name="fiduciary_tax_return", product="DP-307", entity="Fiduciary Tax Return", kind="Fact",
             grain="trust or estate x tax year (TXRT-)",
             dimensions=[
                 dict(name="fiduciary_tax_return_id", attr="Fiduciary Tax Return ID"),
                 dict(name="return_trust", attr="Return Trust"),
                 dict(name="return_estate_case", attr="Return Estate Case"),
                 dict(name="filing_entity_party", attr="Filing Entity Party"),
                 dict(name="filer_ein", attr="Filer EIN"),
                 dict(name="tax_year_end_date", attr="Tax Year End Date"),
                 dict(name="fiduciary_return_type", attr="Fiduciary Return Type"),
                 dict(name="extended_due_date", attr="Extended Due Date"),
                 dict(name="return_filed_date", attr="Return Filed Date"),
                 dict(name="return_status", attr="Return Status"),
             ],
             facts=[dict(name="distributable_net_income", attr="Distributable Net Income")]),
        dict(name="estate_settlement_case", product="DP-307", entity="Estate Settlement Case", kind="Fact",
             grain="estate settlement case (ESTATE-)",
             dimensions=[
                 dict(name="estate_settlement_case_id", attr="Estate Settlement Case ID"),
                 dict(name="decedent", attr="Decedent"),
                 dict(name="case_death_notification", attr="Case Death Notification"),
                 dict(name="firm_estate_role", attr="Firm Estate Role"),
                 dict(name="fiduciary_entity", attr="Fiduciary Entity"),
                 dict(name="personal_representative", attr="Personal Representative"),
                 dict(name="probate_status", attr="Probate Status"),
                 dict(name="testamentary_trust", attr="Testamentary Trust"),
                 dict(name="case_status", attr="Case Status"),
                 dict(name="case_closed_date", attr="Case Closed Date"),
             ]),
        # ---- DP-351 Fiduciary Account Review Compliance -------------------------------------------------------------
        dict(name="fiduciary_review", product="DP-351", entity="Fact Fiduciary Review", kind="Fact",
             grain="fiduciary account review (FIRV-; trust x review type x due date)",
             default_filter="the current calendar year's daily rows; prior years read from the January-locked snapshot",
             dimensions=[
                 dict(name="fiduciary_review_id", attr="Fiduciary Review ID"),
                 dict(name="review_trust", attr="Review Trust"),
                 dict(name="fiduciary_review_type", attr="Fiduciary Review Type"),
                 dict(name="investment_discretion_indicator", attr="Investment Discretion Indicator"),
                 dict(name="accounts_reviewed", attr="Accounts Reviewed"),
                 dict(name="reviewer", attr="Reviewer"),
                 dict(name="reviewing_committee", attr="Reviewing Committee"),
                 dict(name="review_due_date", attr="Review Due Date"),
                 dict(name="review_completed_date", attr="Review Completed Date"),
                 dict(name="review_conclusion", attr="Review Conclusion"),
             ]),
        dict(name="review_exception", product="DP-351", entity="Fact Review Exception", kind="Fact",
             grain="fiduciary review x exception sequence",
             dimensions=[
                 dict(name="exception_review", attr="Exception Review"),
                 dict(name="exception_sequence", attr="Exception Sequence"),
                 dict(name="review_exception_type", attr="Review Exception Type"),
                 dict(name="exception_severity", attr="Exception Severity"),
                 dict(name="required_action", attr="Required Action"),
                 dict(name="related_conflict", attr="Related Conflict"),
                 dict(name="exception_resolved_date", attr="Exception Resolved Date"),
             ]),
    ],

    shared=[
        "DP-240/Party", "DP-240/Household Membership", "DP-240/Service Tier Assignment", "DP-240/Segment Assignment",
        "DP-240/Consent Record", "DP-240/Authority Grant", "DP-240/Trusted Contact Designation",
        "DP-093/Account", "DP-093/Account Party Role", "DP-093/Program Enrollment", "DP-093/RMD Record",
        "DP-009/Employee", "DP-009/Coverage Assignment",
        "DP-004/Service Offering", "DP-004/Service Tier",
        "DP-013/Calendar Date",
        "DP-192/Employee",
    ],

    relationships=[
        # Household spine
        dict(frm="household_360", to="household", on="household_360.household_key = household.household_id",
             type="many-to-one"),
        dict(frm="household_360", to="DP-013/Calendar Date", on="household_360.as_of_date_key = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="household_membership", to="household", on="household_membership.membership_household = household.household_id",
             type="many-to-one"),
        dict(frm="household_membership", to="client", on="household_membership.household_member = client.client_id",
             type="many-to-one"),
        dict(frm="household", to="client", on="household.household_id = household_membership.membership_household and "
                                              "household_membership.household_member = client.client_id",
             type="many-to-many",
             warning="Through the Household Membership bridge, effective dated: pin the membership in effect on the "
                     "as-of date. A party in two households over a range, or a household counted once per member, "
                     "overcounts; count households with count distinct."),
        dict(frm="account_owner", to="client", on="account_owner.role_party = client.client_id", type="many-to-one"),
        dict(frm="account_owner", to="DP-093/Account", on="account_owner.role_account = account.account_id",
             type="many-to-one"),
        dict(frm="household", to="DP-093/Account",
             on="household.household_id = household_membership.membership_household and household_membership."
                "household_member = account_owner.role_party and account_owner.role_account = account.account_id",
             type="many-to-many",
             warning="Household to account runs Household Membership -> Party -> Account Party Role, both effective "
                     "dated and many-to-many (joint owners, members of two households). Summing account values through "
                     "it double counts joint accounts unless account_owner is pinned to the Primary Owner (the default "
                     "filter), which assigns each account once, as DP-320 does; Household Client Assets on "
                     "household_360 is already assigned that way."),
        dict(frm="household_client_assets", to="DP-093/Account",
             on="household_client_assets.summary_account = account.account_id", type="many-to-one"),
        dict(frm="household_client_assets", to="DP-013/Calendar Date",
             on="household_client_assets.summary_as_of_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="fund_position_view", to="DP-093/Account", on="fund_position_view.fund_position_account = account.account_id",
             type="many-to-one"),
        dict(frm="DP-093/Program Enrollment", to="DP-093/Account", on="program_enrollment.enrolled_account = account.account_id",
             type="many-to-one", warning="Effective dated: pin Enrollment Status = Active in force on the as-of date."),
        dict(frm="DP-093/Program Enrollment", to="DP-004/Service Offering",
             on="program_enrollment.enrolled_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="DP-093/RMD Record", to="DP-093/Account", on="rmd_record.rmd_account = account.account_id",
             type="many-to-one"),
        # Tier, segment, coverage, consent and authority (effective dated; pin in effect on the as-of date)
        dict(frm="DP-240/Service Tier Assignment", to="household", on="service_tier_assignment.tier_party = household.household_id",
             type="many-to-one", warning="Effective dated: pin the tier in effect on the as-of date."),
        dict(frm="DP-240/Service Tier Assignment", to="DP-004/Service Tier",
             on="service_tier_assignment.assigned_service_tier = service_tier.service_tier_code", type="many-to-one"),
        dict(frm="DP-240/Segment Assignment", to="client", on="segment_assignment.segmented_party = client.client_id",
             type="many-to-one", warning="One row per segmentation scheme: filter one scheme, and the segment in effect."),
        dict(frm="DP-009/Coverage Assignment", to="household", on="coverage_assignment.covered_party = household.household_id",
             type="many-to-one",
             warning="Effective dated and several roles per party: pin Primary Coverage Indicator = Y and Party Coverage "
                     "Role = Primary Advisor in effect to get one advisor per household."),
        dict(frm="DP-009/Coverage Assignment", to="DP-009/Employee",
             on="coverage_assignment.covering_advisor = employee.employee_id", type="many-to-one"),
        dict(frm="DP-240/Consent Record", to="client", on="consent_record.consenting_party = client.client_id",
             type="many-to-one"),
        dict(frm="DP-240/Authority Grant", to="client", on="authority_grant.grantor_party = client.client_id",
             type="many-to-one"),
        dict(frm="DP-240/Trusted Contact Designation", to="client",
             on="trusted_contact_designation.designating_client = client.client_id", type="many-to-one"),
        # Personal Rate of Return
        dict(frm="household_performance_group", to="household",
             on="household_performance_group.group_household = household.household_id", type="one-to-one"),
        dict(frm="household_return_twr", to="household_performance_group",
             on="household_return_twr.personal_return_group = household_performance_group.household_performance_group_id",
             type="many-to-one"),
        dict(frm="household_return_mwr", to="household_performance_group",
             on="household_return_mwr.personal_return_group = household_performance_group.household_performance_group_id",
             type="many-to-one"),
        dict(frm="household_performance_group_member", to="household_performance_group",
             on="household_performance_group_member.member_performance_group = household_performance_group."
                "household_performance_group_id", type="many-to-one"),
        dict(frm="household_performance_group_member", to="DP-093/Account",
             on="household_performance_group_member.member_account = account.account_id", type="many-to-one"),
        # Trust panel
        dict(frm="trust", to="client", on="trust.trust_party = client.client_id", type="many-to-one",
             warning="One trust party per trust; many rows only across the trust's SCD type 2 status periods."),
        dict(frm="trust", to="DP-009/Employee", on="trust.administering_trust_officer = employee.employee_id",
             type="many-to-one"),
        dict(frm="DP-093/Account", to="trust", on="account.governing_trust = trust.trust_id", type="many-to-one"),
        dict(frm="trust_role", to="trust", on="trust_role.role_trust = trust.trust_id", type="many-to-one"),
        dict(frm="trust_role", to="client", on="trust_role.role_holder_party = client.client_id", type="many-to-one"),
        dict(frm="beneficial_interest", to="trust", on="beneficial_interest.interest_trust = trust.trust_id",
             type="many-to-one"),
        dict(frm="beneficial_interest", to="client", on="beneficial_interest.beneficiary_party = client.client_id",
             type="many-to-one"),
        dict(frm="trust_term_provision", to="trust", on="trust_term_provision.provision_trust = trust.trust_id",
             type="many-to-one"),
        dict(frm="distribution_request", to="trust", on="distribution_request.request_trust = trust.trust_id",
             type="many-to-one"),
        dict(frm="principal_income_allocation", to="trust", on="principal_income_allocation.allocation_trust = trust.trust_id",
             type="many-to-one"),
        dict(frm="fiduciary_tax_return", to="trust", on="fiduciary_tax_return.return_trust = trust.trust_id",
             type="many-to-one"),
        dict(frm="fiduciary_tax_return", to="estate_settlement_case",
             on="fiduciary_tax_return.return_estate_case = estate_settlement_case.estate_settlement_case_id",
             type="many-to-one"),
        dict(frm="estate_settlement_case", to="client", on="estate_settlement_case.decedent = client.client_id",
             type="many-to-one"),
        dict(frm="estate_settlement_case", to="trust", on="estate_settlement_case.testamentary_trust = trust.trust_id",
             type="many-to-one"),
        dict(frm="fiduciary_review", to="trust", on="fiduciary_review.review_trust = trust.trust_id", type="many-to-one"),
        dict(frm="fiduciary_review", to="DP-093/Account", on="fiduciary_review.accounts_reviewed contains account.account_id",
             type="many-to-many",
             warning="Accounts Reviewed is a multi reference: a review covers several accounts. Counting reviews by "
                     "account overcounts; count reviews with count distinct on fiduciary_review_id."),
        dict(frm="fiduciary_review", to="DP-192/Employee", on="fiduciary_review.reviewer = employee.employee_id",
             type="many-to-one"),
        dict(frm="fiduciary_review", to="DP-013/Calendar Date",
             on="fiduciary_review.review_due_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="review_exception", to="fiduciary_review",
             on="review_exception.exception_review = fiduciary_review.fiduciary_review_id", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Household", levels=["household.household_formation_basis", "household.household_id",
                                       "household_membership.household_member_role", "client.client_id"]),
        dict(name="Client asset holding", levels=["household_client_assets.summary_source_book",
                                                  "household_client_assets.summary_holding_type",
                                                  "household_client_assets.summary_account"]),
        dict(name="Personal return period", levels=["household_return_twr.period_basis",
                                                    "household_return_twr.period_end_date"]),
        dict(name="Trust", levels=["trust.situs_jurisdiction", "trust.revocability", "trust.trust_id"]),
        dict(name="Fiduciary review", levels=["fiduciary_review.fiduciary_review_type",
                                              "fiduciary_review.investment_discretion_indicator",
                                              "fiduciary_review.fiduciary_review_id"]),
    ],

    metrics=[
        # ---- Certified, referenced (CW-011) --------------------------------------------------------------------------
        dict(name="Client Assets", ref="SM-20/Client Assets",
             note="The certified total; Household Client Assets decomposes it by household and Non-Household Client "
                  "Assets is the reconciling item."),
        dict(name="Advised Assets", ref="SM-20/Advised Assets",
             note="The certified total; Household Advised Assets decomposes it by household."),
        dict(name="Households", ref="SM-20/Households",
             note="The certified count; Households in View differs from it by the households with no funded account."),
        dict(name="Household Personal Rate of Return - Time-Weighted", ref="SM-08/Personal Rate of Return",
             note="Read from household_return_twr (Personal Return Method = Time-Weighted, Final or Restated, highest "
                  "version, the household's default performance group); not aggregated across households or periods."),
        dict(name="Household Personal Rate of Return - Money-Weighted", ref="SM-08/Personal Rate of Return",
             note="Read from household_return_mwr (Personal Return Method = Money-Weighted (IRR)); never mixed with the "
                  "time-weighted rows."),

        # ---- DP-320 Household 360 ------------------------------------------------------------------------------------
        dict(name="Households in View", aggregation="count_distinct",
             expr="count(distinct household_360.household_key) where households_in_view = 1 on the last as-of date in "
                  "the range",
             source=("DP-320", "Households in View"),
             time_rule="last as-of date in the selected range",
             description="Active households with at least one member in effect and a complete household record; the "
                         "difference to the certified Households is the households with no funded account.",
             note="The count with Membership Last Confirmed Date over 12 months old is the same metric filtered on "
                  "household.membership_last_confirmed_date."),
        dict(name="Household Members", aggregation="semi_additive",
             expr="sum(household_360.household_members)",
             source=("DP-320", "Household Members"),
             time_rule="last as-of date in the selected range",
             description="Active household memberships, by member role; a party in two households counts in each."),
        dict(name="Household Client Assets", aggregation="semi_additive",
             expr="sum(household_360.household_client_assets)",
             source=("DP-320", "Household Client Assets"),
             time_rule="last as-of date in the selected range",
             description="Each household's part of the certified Client Assets, under DP-008's rule applied by "
                         "reference, each account assigned once to its Primary Owner's household.",
             note="A decomposition of SM-20/Client Assets, never a second definition (CW-211). Summed over all "
                  "households plus Non-Household Client Assets it ties to Client Assets; never added to Firm AUM or "
                  "Held-Away Assets."),
        dict(name="Non-Household Client Assets", aggregation="non_additive",
             expr="the as-of date's household_360.non_household_client_assets, taken once per as-of date (a firm-level "
                  "value carried on every household row; never summed over households or sliced by household)",
             source=("DP-320", "Non-Household Client Assets"),
             time_rule="last as-of date in the selected range",
             description="The client assets that belong to no household: the omnibus residual and the accounts with no "
                         "household owner on the date; the reconciling item between the households and Client Assets."),
        dict(name="Household Client Assets Tie-Out Variance", aggregation="non_additive",
             expr="at each month-end: sum of Household Client Assets over all households + Non-Household Client Assets "
                  "- [Client Assets] (SM-20, DP-008 Total row); shown at the firm Total only",
             source=("DP-320", "Household Client Assets Tie-Out Variance"),
             description="How far the household decomposition is from the certified Client Assets; zero when the "
                         "decomposition ties."),
        dict(name="Household Advised Assets", aggregation="semi_additive",
             expr="sum(household_360.household_advised_assets)",
             source=("DP-320", "Household Advised Assets"),
             time_rule="last as-of date in the selected range",
             description="Each household's part of the certified Advised Assets: its accounts with a fee-based "
                         "advice, managed or trust enrollment in force.",
             note="A decomposition of SM-20/Advised Assets; the households' advised assets plus those of accounts with "
                  "no household owner tie to it."),
        dict(name="Managed Share of Household Assets %", aggregation="ratio",
             numerator="Household Client Assets of the household accounts with an active DP-304 Model Assignment in "
                       "effect",
             denominator="Household Client Assets of the same households",
             source=("DP-320", "Managed Share of Household Assets %"),
             time_rule="last as-of date in the selected range",
             description="The share of a household's assets with the firm that sits in managed (model-assigned) "
                         "accounts."),
        dict(name="Held-Away Assets", aggregation="semi_additive",
             expr="sum(household_360.held_away_assets)",
             source=("DP-320", "Held-Away Assets"),
             time_rule="last as-of date in the selected range",
             description="Balances households hold at other firms, from consented and connected account aggregation; "
                         "never Client Assets and never added to them (CW-024)."),
        dict(name="Households Without Current Plan", aggregation="count_distinct",
             expr="count(distinct household_360.household_key) where households_without_current_plan = 1",
             source=("DP-320", "Households Without Current Plan"),
             time_rule="last as-of date in the selected range",
             description="Households in an active advice engagement with no accepted financial plan, or one whose "
                         "data is more than 12 months old."),
        dict(name="Household Goals Off Track", aggregation="semi_additive",
             expr="sum(household_360.household_goals_off_track)",
             source=("DP-320", "Household Goals Off Track"),
             time_rule="last as-of date in the selected range",
             description="Active financial goals of households and their members whose latest progress is At Risk or "
                         "Off Track."),
        dict(name="Fee Household Alignment Breaks", aggregation="semi_additive",
             expr="sum(household_360.fee_household_alignment_breaks)",
             source=("DP-320", "Fee Household Alignment Breaks"),
             time_rule="last as-of date in the selected range",
             description="Household accounts that bill in a fee household anchored to another household, and "
                         "households whose accounts bill in more than one fee household."),
        dict(name="Households Without Primary Advisor", aggregation="count_distinct",
             expr="count(distinct household_360.household_key) where households_without_primary_advisor = 1",
             source=("DP-320", "Households Without Primary Advisor"),
             time_rule="last as-of date in the selected range",
             description="Households with advised assets and no primary advisor coverage in effect."),
        dict(name="Service Tier Qualification Mismatch", aggregation="count_distinct",
             expr="count(distinct household_360.household_key) where service_tier_qualification_mismatch = 1, by the "
                  "assigned service tier",
             source=("DP-320", "Service Tier Qualification Mismatch"),
             time_rule="last as-of date in the selected range",
             description="Rule-assigned households whose assets are below their tier's threshold or at or above the "
                         "next tier's; overrides without an approver are counted separately."),
        dict(name="Recent Service Contacts", aggregation="semi_additive",
             expr="sum(household_360.recent_service_contacts)",
             source=("DP-320", "Recent Service Contacts"),
             time_rule="last as-of date in the selected range (a trailing 90-day count; never summed over dates)",
             description="Contact center interactions of household members in the trailing 90 days, with those where "
                         "dissatisfaction was expressed."),
        dict(name="Trust-Linked Households", aggregation="count_distinct",
             expr="count(distinct household_360.household_key) where trust_linked_households = 1, by revocability",
             source=("DP-320", "Trust-Linked Households"),
             time_rule="last as-of date in the selected range",
             description="Households with a member that is the party of an active trust the firm records."),

        # ---- DP-307 Trust Fiduciary Record ---------------------------------------------------------------------------
        dict(name="Administered Trusts", aggregation="count_distinct",
             expr="count(distinct trust.trust_id) where trust_status = 'Active' and a trust_role of Trustee, Co-Trustee, "
                  "Directed Trustee or Agent for Trustee held by a Role Holder Entity is in effect on the as-of date; "
                  "any slice under 10 trusts is suppressed",
             source=("DP-307", "Administered Trusts"),
             time_rule="as-of date",
             description="Active trusts for which the trust company holds a trustee or agent role, by revocability and "
                         "situs."),
        dict(name="Trusts Without Current Trustee", aggregation="count_distinct",
             expr="count(distinct trust.trust_id) where trust_status = 'Active' and no Trustee, Co-Trustee, Directed "
                  "Trustee or Successor Trustee role is in effect on the as-of date",
             source=("DP-307", "Trusts Without Current Trustee"), time_rule="as-of date",
             description="Active trusts with no trustee of any kind in effect."),
        dict(name="Trusts Without Instrument Document", aggregation="count_distinct",
             expr="count(distinct trust.trust_id) over Administered Trusts with no trust agreement, declaration, will "
                  "or certification of trust on file",
             source=("DP-307", "Trusts Without Instrument Document"), time_rule="as-of date",
             description="Administered trusts with no governing instrument or certification of trust received."),
        dict(name="Trusts Without Linked Account", aggregation="count_distinct",
             expr="count(distinct trust.trust_id) over Administered Trusts with no open account whose Governing Trust "
                  "is the trust",
             source=("DP-307", "Trusts Without Linked Account"), time_rule="as-of date",
             description="Administered trusts with no open account registered to them."),
        dict(name="Beneficial Interest Share Gaps", aggregation="count_distinct",
             expr="count(distinct trust.trust_id) over Administered Trusts failing the income or the principal test: "
                  "the in-effect interest shares of the test's interest types sum above 0 and differ from 100% by more "
                  "than 0.01",
             source=("DP-307", "Beneficial Interest Share Gaps"), time_rule="as-of date",
             description="Administered trusts whose current income or principal interests do not add up to 100%."),
        dict(name="Investment Constraint Provisions", aggregation="count_distinct",
             expr="count(distinct trust_term_provision rows) with investment_constraint_indicator = 'Y' in effect on "
                  "the as-of date, of Administered Trusts, by provision_type (the special-needs value blanked)",
             source=("DP-307", "Investment Constraint Provisions"), time_rule="as-of date",
             description="Trust terms in effect that constrain how the trust's accounts may be invested."),
        dict(name="Open Distribution Requests", aggregation="count_distinct",
             expr="count(distinct distribution_request.distribution_request_id) where request_status not in "
                  "('Resolved / Completed', 'Closed', 'Rejected', 'Canceled') on the as-of date; sum(requested_amount) "
                  "shown beside it; published rows only",
             source=("DP-307", "Open Distribution Requests"), time_rule="as-of date",
             description="Beneficiary distribution requests still open, with the amount requested; special-category "
                         "purposes never reach this model."),
        dict(name="Distribution Request Age Days", aggregation="non_additive",
             expr="median(as-of date - request_received_date) over Open Distribution Requests, with the count older than "
                  "30 days",
             source=("DP-307", "Distribution Request Age Days"), time_rule="as-of date",
             description="How long open distribution requests have been waiting."),
        dict(name="Overdue Fiduciary Reviews", aggregation="count_distinct",
             expr="count(distinct fiduciary_review.fiduciary_review_id) where review_due_date < as-of date and "
                  "review_completed_date is null",
             source=("DP-307", "Overdue Fiduciary Reviews"), time_rule="as-of date",
             description="Fiduciary account reviews past their due date and not completed, by review type and "
                         "discretion.",
             note="Read through DP-351's review fact, which carries the same review rows; DP-351 does not redefine it."),
        dict(name="Principal Allocated", aggregation="additive",
             expr="sum(principal_income_allocation.principal_amount) where allocation_date in the period",
             source=("DP-307", "Principal Allocated"),
             description="Receipts and disbursements allocated to trust principal in the period (USD); a ledger amount, "
                         "never assets."),
        dict(name="Income Allocated", aggregation="additive",
             expr="sum(principal_income_allocation.income_amount) where allocation_date in the period",
             source=("DP-307", "Income Allocated"),
             description="Receipts and disbursements allocated to trust income in the period (USD)."),
        dict(name="Inconsistent Allocation Character", aggregation="additive",
             expr="count(principal_income_allocation rows) where character Principal has a nonzero income amount, "
                  "character Income has a nonzero principal amount, or character Split has either amount blank",
             source=("DP-307", "Inconsistent Allocation Character"),
             description="Principal and income allocations whose amounts contradict their stated character."),
        dict(name="Fiduciary Returns Due Not Filed", aggregation="count_distinct",
             expr="count(distinct fiduciary_tax_return.fiduciary_tax_return_id) where return_filed_date is null and the "
                  "extended due date, or else the 15th day of the fourth month after tax_year_end_date, has passed",
             source=("DP-307", "Fiduciary Returns Due Not Filed"), time_rule="as-of date",
             description="Trust and estate income tax returns past due and not filed, by return type."),
        dict(name="Distributable Net Income Reported", aggregation="additive",
             expr="sum(fiduciary_tax_return.distributable_net_income) where return_filed_date is populated, by return "
                  "type and tax year",
             source=("DP-307", "Distributable Net Income Reported"),
             description="Distributable net income on filed fiduciary returns (USD)."),
        dict(name="Open Estate Settlement Cases", aggregation="count_distinct",
             expr="count(distinct estate_settlement_case.estate_settlement_case_id) where case_status not in "
                  "('Resolved / Completed', 'Closed', 'Rejected', 'Canceled')",
             source=("DP-307", "Open Estate Settlement Cases"), time_rule="as-of date",
             description="Estates the firm is settling as executor or agent, by role and probate status."),
        dict(name="Estate Cases Without Death Notification", aggregation="count_distinct",
             expr="count(distinct estate_settlement_case_id) over Open Estate Settlement Cases with "
                  "case_death_notification blank",
             source=("DP-307", "Estate Cases Without Death Notification"), time_rule="as-of date",
             description="Open estate cases with no recorded death notification."),

        # ---- DP-351 Fiduciary Account Review Compliance --------------------------------------------------------------
        dict(name="Reviews Due", aggregation="count_distinct",
             expr="count(distinct fiduciary_review.fiduciary_review_id) where review_due_date in the period",
             source=("DP-351", "Reviews Due"),
             description="Fiduciary account reviews falling due in the period, by review type and discretion."),
        dict(name="Late Review Rate %", aggregation="ratio",
             numerator="Reviews Due completed after review_due_date, plus those not completed by the as-of date after "
                       "their due date",
             denominator="Reviews Due",
             source=("DP-351", "Late Review Rate %"),
             description="The share of reviews due in the period that were completed late or are still overdue."),
        dict(name="Discretionary Trusts Without Annual Review", aggregation="count_distinct",
             expr="count(distinct trust.trust_id) of active trusts with a trust company trustee role in effect and a "
                  "discretionary review in their history, with no Annual Investment Review (9.6(c)) completed in the "
                  "calendar year",
             source=("DP-351", "Discretionary Trusts Without Annual Review"), time_rule="as-of date",
             description="Discretionary trusts missing the annual investment review that 12 CFR 9.6(c) requires."),
        dict(name="Late Post-Acceptance Reviews", aggregation="count_distinct",
             expr="count(distinct trust company appointments) whose Initial Post-Acceptance Review (9.6(b)) was completed, "
                  "or is still not completed, more than 60 days after role_acceptance_date",
             source=("DP-351", "Late Post-Acceptance Reviews"),
             description="Trust company appointments whose post-acceptance review missed the 60-day deadline."),
        dict(name="Acceptances Without Pre-Acceptance Review", aggregation="count_distinct",
             expr="count(distinct trust company appointments) with role_acceptance_date in the period and no "
                  "Pre-Acceptance Review (9.6(a)) completed on or before it",
             source=("DP-351", "Acceptances Without Pre-Acceptance Review"),
             description="Trust appointments accepted in the period without a pre-acceptance review."),
        dict(name="Open Review Exceptions", aggregation="semi_additive",
             expr="count(review_exception rows) where exception_resolved_date is null, by exception type and severity; "
                  "the median days since the review was completed shown beside it",
             source=("DP-351", "Open Review Exceptions"),
             time_rule="as-of date (the open count is a stock)",
             description="Findings of fiduciary reviews not yet resolved."),
        dict(name="Aged High-Severity Exceptions", aggregation="semi_additive",
             expr="count(review_exception rows) of Open Review Exceptions with exception_severity in ('High', "
                  "'Critical') more than 90 days after the review was completed",
             source=("DP-351", "Aged High-Severity Exceptions"),
             time_rule="as-of date (the open count is a stock)",
             description="High and critical review findings open for more than 90 days."),
        dict(name="Exception Resolution Days", aggregation="non_additive",
             expr="median(exception_resolved_date - fiduciary_review.review_completed_date) for exceptions resolved in "
                  "the period, by exception type",
             source=("DP-351", "Exception Resolution Days"),
             description="How long review findings take to resolve."),
        dict(name="Conflict Exceptions", aggregation="additive",
             expr="count(review_exception rows) with review_exception_type = 'Self-Dealing or Conflict' or "
                  "related_conflict populated, open and raised in the period",
             source=("DP-351", "Conflict Exceptions"),
             description="Review findings of self-dealing or conflicts of interest (12 CFR 9.12)."),
        dict(name="Constraint Provisions Not Implemented", aggregation="count_distinct",
             expr="count(distinct trust_term_provision rows) with investment_constraint_indicator = 'Y' in effect and "
                  "no active DP-304 Account Investment Constraint on an open account of the trust sourced from it",
             source=("DP-351", "Constraint Provisions Not Implemented"), time_rule="as-of date",
             description="Trust investment constraints that no account of the trust enforces."),
        dict(name="Discretionary Reviews Without Committee", aggregation="count_distinct",
             expr="count(distinct fiduciary_review.fiduciary_review_id) where review_completed_date is populated, "
                  "investment_discretion_indicator = 'Y' and reviewing_committee or review_conclusion is blank",
             source=("DP-351", "Discretionary Reviews Without Committee"),
             description="Completed discretionary reviews with no reviewing committee or no recorded conclusion."),
        dict(name="Overdue Share per Trust Officer %", aggregation="ratio",
             numerator="Reviews Due past review_due_date and not completed, by trust.administering_trust_officer",
             denominator="Reviews Due, by trust.administering_trust_officer",
             source=("DP-351", "Reviews Due per Trust Officer"),
             description="Each trust officer's reviews due and the share of them overdue.",
             note="The count half of the DP-351 measure is Reviews Due grouped by trust.administering_trust_officer."),
    ],

    excluded=[
        # Every measure is published or carried as a hidden column of household_360 (the certified copies).
    ],

    access=dict(
        classification="Confidential - Personal Data (household, client, account and trust rows; PII tiers identity "
                       "and financial). Special-category data (CD-344) is not read: DP-322's protection flag arrives "
                       "as Y or N only, the special-needs trust values are blanked and the special-category "
                       "distribution purposes are excluded at extraction (DP-352 holds the restricted view).",
        roles=[
            dict(role="client_data_stewardship",
                 rows="all households, clients, accounts and trusts", columns="all", hidden=[]),
            dict(role="advisor",
                 rows="households and clients where the viewer has a Party Coverage Assignment in effect; trusts whose "
                      "party is a member of such a household; no estate cases, fiduciary returns or review exceptions",
                 columns="all except trust provision and distribution request detail",
                 hidden=["provision_type", "distribution_standard", "requested_amount", "request_status",
                         "request_received_date", "trust_instrument_type"]),
            dict(role="client_service",
                 rows="households and clients the viewer is serving on an open interaction or case; no trust panel rows",
                 columns="household, membership, account, tier and service columns",
                 hidden=["date_of_birth", "protection_flag_present", "held_away_assets"] + _TRUST_SENSITIVE),
            dict(role="trust_officer",
                 rows="trusts the viewer administers (Administering Trust Officer) or holds a role on, their parties, "
                      "accounts, reviews and estate cases",
                 columns="all", hidden=[]),
            dict(role="fiduciary_compliance",       # trust committee, fiduciary audit, trust compliance
                 rows="all trusts, roles, reviews, exceptions, returns and estate cases; households only through a trust",
                 columns="all trust and review columns; household assets as aggregates",
                 hidden=["held_away_assets", "given_name", "family_name", "date_of_birth"]),
            dict(role="broad_internal",             # executives, finance, product, marketing, analytics
                 rows="aggregates only, with a minimum cell size of 10 households, clients or trusts; no named row",
                 columns="the metrics by tier, segment, offering, formation basis, holding type, revocability, situs, "
                         "review type and period",
                 hidden=_PERSON_PII + _TRUST_SENSITIVE + ["protection_flag_present", "household_id", "client_id",
                                                          "trust_id", "administering_trust_officer",
                                                          "personal_rate_of_return_id", "personal_return_group",
                                                          "group_household", "member_account", "role_account",
                                                          "role_party", "household_member", "membership_household",
                                                          "household_key", "position_id"]),
        ]),

    verified_questions=[
        dict(question="What is each household's personal rate of return, and how is it computed? (acceptance question 9)",
             answer="[Household Personal Rate of Return - Time-Weighted] and [Household Personal Rate of Return - "
                    "Money-Weighted], both ref SM-08/Personal Rate of Return (certified, CW-011; DP-145 Personal Return "
                    "Value), read from household_return_twr and household_return_mwr joined to "
                    "household_performance_group (the household's Default (All Household Accounts) group, Active) and "
                    "to household, by period_basis and period_end_date, with fee_basis (default Net of Fees). Each row "
                    "is the highest version with status Final or Restated, and is blank where DP-145 suppresses it. How "
                    "it is computed: calculation_method names the method (Modified Dietz linked monthly or daily "
                    "valuation for time-weighted; internal rate of return for money-weighted), from "
                    "beginning_market_value, ending_market_value, net_external_flows and, on net rows, fees_deducted "
                    "(copied from the 49 brokerage book, the 29 register and 16 participant balances and 47 fee debits, "
                    "and checked by DP-145's three tie-outs); household_performance_group_member lists the accounts in "
                    "the group for the period. Mastering domains 32, 02 and 49.",
             sql="select h.household_name, r.period_basis, r.period_end_date, r.fee_basis, r.calculation_method, "
                 "r.personal_return_value as twr, r.beginning_market_value, r.ending_market_value, r.net_external_flows, "
                 "r.fees_deducted from household_return_twr r join household_performance_group g on "
                 "r.personal_return_group = g.household_performance_group_id join household h on g.group_household = "
                 "h.household_id where r.fee_basis = 'Net of Fees' and r.period_basis = 'Year to Date'"),
        dict(question="Do the household client assets tie to the certified Client Assets at month-end?",
             answer="[Household Client Assets] summed over all households plus [Non-Household Client Assets] against "
                    "[Client Assets] (ref SM-20) at the month-end as-of date; [Household Client Assets Tie-Out "
                    "Variance] shows the difference at the firm Total. Drill by "
                    "household_client_assets.summary_holding_type and summary_account (plus fund_position_view for the "
                    "Counted - Intermediary positions)."),
        dict(question="Which households with advised assets have no primary advisor, and which have no current plan?",
             answer="[Households Without Primary Advisor] and [Households Without Current Plan] on household_360 at the "
                    "latest as-of date, by household and, through DP-240/Service Tier Assignment, by service tier; "
                    "[Household Advised Assets] shown beside them."),
        dict(question="How many trusts does the trust company administer by situs and revocability, and how many lack a "
                      "trustee or a linked account?",
             answer="[Administered Trusts], [Trusts Without Current Trustee] and [Trusts Without Linked Account] by "
                    "trust.situs_jurisdiction and trust.revocability at the as-of date; slices under 10 trusts are "
                    "suppressed."),
        dict(question="Which fiduciary reviews are late, and which review exceptions are open and high severity?",
             answer="[Reviews Due], [Late Review Rate %] and [Overdue Fiduciary Reviews] by "
                    "fiduciary_review.fiduciary_review_type and investment_discretion_indicator; [Open Review "
                    "Exceptions] and [Aged High-Severity Exceptions] by review_exception.review_exception_type and "
                    "exception_severity; [Overdue Share per Trust Officer %] by trust.administering_trust_officer."),
    ],

    cannot_answer=[
        dict(question="Certified Client Assets per household as DP-008 publishes them",
             why="DP-008 publishes no Household Dimension Type, so household client assets are a decomposition from "
                 "DP-007 rows tied to the certified Total, not a certified household value (DP-320 taxonomy gap).",
             gap=""),
        dict(question="How long trust distribution requests take to decide or pay, and the purposes requested",
             why="Trust Distribution Request has no decided or paid date outside the restricted Distribution Decision "
                 "group, and the special-category purposes stay in DP-352's restricted view (CW-213, CD-344).",
             gap=""),
        dict(question="Special-needs trusts and their provisions",
             why="The special-needs values of Trust Instrument Type, Provision Type and Distribution Standard are blanked "
                 "in every published row (CD-344); only DP-352's restricted view holds them.",
             gap=""),
        dict(question="When the reviewing committee decided a fiduciary review, and how many exceptions it raised",
             why="51 Fiduciary Account Review has no exception count or committee decision date (DP-351 taxonomy gap); "
                 "exceptions are counted from their own rows.",
             gap=""),
        dict(question="Authorized-person, trusted-contact and beneficiary coverage rates and RMD shortfalls across "
                      "households",
             why="Those measures belong to DP-321, DP-324 and DP-329, whose specs do not list the BI semantic model "
                 "delivery; this model joins only the DP-240 and DP-093 dimension rows (Authority Grant, Trusted "
                 "Contact Designation, RMD Record).",
             gap=""),
    ],

    open_decisions=[
        "SM-08 must define 'Personal Rate of Return' on DP-145 Personal Return Value (register.CERTIFIED names SM-08 as "
        "owner, but the interim SM-08 file still excludes the measure). The two household refs here read it through "
        "household_return_twr and household_return_mwr; once SM-08 publishes its own household fact, confirm both models "
        "pin the same version, status and default group rules.",
        "The register's SM-21 purpose names authorized persons, contact permissions and required minimum distributions, "
        "which are DP-321, DP-324 and DP-329 measures. Those products do not list the BI semantic model delivery, so only "
        "their DP-240 and DP-093 dimension rows are joined here. Product owners: add the delivery to bring their "
        "measures in, or narrow the register's purpose.",
        "DP-320 Fact Household Return carries no Personal Return Version, so the household return tables read DP-145's "
        "Personal Rate of Return (a certified source) to pin the highest version. DP-320's logical model should add the "
        "version, or say that consumers read DP-145 directly.",
        "Non-Household Client Assets and Household Client Assets Tie-Out Variance sit on the household x as-of date fact "
        "although they are firm-level values. DP-320's logical model should give them an as-of-date grain (or a Total "
        "household row) so that they cannot be summed over households by mistake; until then the metrics are "
        "non_additive and taken once per as-of date.",
        "DP-320's Household Client Assets includes the Counted - Intermediary fund positions; the account-level drill "
        "needs household_client_assets and fund_position_view together to tie. Confirm DP-320 can publish one account "
        "fact that already combines them.",
        "Overdue Fiduciary Reviews (DP-307) is read through DP-351's Fact Fiduciary Review, which carries the same review "
        "rows; the model does not read DP-307's Fiduciary Account Review entity separately, so the two cannot diverge.",
        "DP-351 'Reviews Due per Trust Officer' is published as the ratio 'Overdue Share per Trust Officer %' with the "
        "count half read as Reviews Due by trust officer; the spec should name the share as its own measure.",
        "The trust panel is a tailoring lever (trust services offered, CW-018): without it DP-307 and DP-351 drop and "
        "the trust tables, metrics, roles and questions leave this model.",
    ],
)
