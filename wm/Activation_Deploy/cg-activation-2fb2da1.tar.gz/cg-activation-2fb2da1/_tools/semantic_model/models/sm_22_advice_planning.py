"""SM-22 Advice & Planning: engagements, plans, goals and recommendations with their best-interest and PTE 2020-02
evidence, the advice funnel and hand-offs, advisor capacity, goal progress and advice program reviews. See CONTRACT.md.

WP2 (CW-209, plan section 8.4). Products: DP-303 (foundational advice master), DP-333 (advice funnel), DP-334 (Reg BI
file), DP-335 (rollover and PTE 2020-02 evidence), DP-337 (goal progress), DP-385 (program outcomes evidence), DP-387
(advisor capacity and book health) and DP-393 (channel referrals and hand-offs). Answers acceptance question 3 with the
DP-334 Evidence Gap Flag and the DP-335 PTE Documentation Gap Flag as the single definitions (DP-404 in SM-29 and DP-467
in SM-26 reference them). Owns no certified metric: client assets, net new assets, advised assets and inter-channel
transfers are SM-20's (DP-008), returns SM-08's (DP-145) and client fee revenue SM-28's (DP-012).
"""

# DP-008 rows exist at many dimension types, period types and snapshots; every DP-008 table pins all three. The wealth
# snapshot of record is the locked one: Snapshot Type Final, or Restated where a restatement superseded it.
_LOCKED_MONTHS = ["period_type = 'MONTH'",
                  "snapshot = the locked snapshot of record for the period (Snapshot Type Final, or the latest Restated "
                  "snapshot that supersedes it); preliminary snapshots are excluded"]
_ASOF = "effective on the as-of date (effective from on or before it, effective to blank or after it)"
# Household rollup (DP-303 notes, CW-005): a row owned by a Client Household party counts once at household grain and is
# never also counted at member grain; rows owned by an individual roll up through DP-240 Household Membership effective
# on the as-of date.
_HH_RULE = ("Household rollup: a row owned by a household party (Party Type = Household) counts once at household grain; "
            "a row owned by an individual rolls up through DP-240 Household Membership effective on the as-of date")
# Client-identifying columns of this model hidden from roles that see aggregates only.
_CLIENT_COLUMNS = ["recommended_amount", "rollover_amount", "goal_target_amount", "planned_retirement_age",
                   "desired_annual_retirement_income", "annual_education_cost", "aggregated_balance_amount",
                   "summary_market_value", "lead_source", "conversion_timestamp", "referral_reason",
                   "client_level_form_crs_delivered_date", "qualification_standard", "qualification_basis",
                   "profile_version_number", "gross_distribution_amount", "estimated_annual_total_cost"]
# Names of people come only from the shared dimensions (DP-240 Party, DP-009 Employee); hidden from broad roles.
_PEOPLE_NAMES = ["party_display_name", "given_name", "family_name", "household_name", "preferred_name",
                 "legal_last_name", "business_email_address"]

MODEL = dict(
    id="SM-22",
    status="Draft",
    description=(
        "Advice delivery across every client, household, advisor, program and period, for the Head of Advice, advice "
        "supervision and conduct, product governance of advice programs and the advisor workforce team. It answers "
        "questions across many recommendations, engagements, goals, advisors and programs: which recommendations and "
        "rollovers lack their best-interest or PTE 2020-02 evidence, how the advice funnel converts, whether goals are on "
        "track, how full advisors' books are and whether programs serve clients. One client's plan is shown in the CRM "
        "and DP-320 (SM-21), not here."),
    questions=[
        "Which recommendations lack best-interest evidence, and which rollovers lack PTE 2020-02 documentation, by "
        "advisor, gap element and supervisory review outcome? (acceptance question 3)",
        "How does the advice funnel convert from referral or lead hand-off to engagement, plan, program recommendation "
        "and enrollment, by channel, offering and advisor, and how long does each step take?",
        "How full is each advisor's and coverage team's book, and what client assets, net new assets and advised assets "
        "does it hold?",
        "Are clients' financial goals on track and funded, and how current are the plans and assumptions behind them?",
        "Do advice programs serve their clients: overdue reviews, terminations, drift, returns, complaints and actions?",
        "Which channel referrals and participant hand-offs reach an advice engagement or enrollment, and where do they "
        "leak?",
    ],

    tables=[
        # ================= DP-303 Advice Plans & Recommendations (foundational master) ===========================
        # SCD type 2 tables pin one status period per key, so a count on the as-of date sees each record once.
        dict(name="advice_engagement", product="DP-303", entity="Advice Engagement", kind="Fact",
             grain="advice engagement (ADENG-) x status period, one period per engagement on the as-of date",
             always_filter=["status period " + _ASOF + " (SCD type 2: one row per engagement)"],
             dimensions=[dict(name="engagement_type", attr="Engagement Type"),
                         dict(name="engagement_advice_capacity", attr="Engagement Advice Capacity"),
                         dict(name="engagement_delivery_channel", attr="Engagement Delivery Channel",
                              note="Digital or human advice is an attribute, not a separate record (CW-044)"),
                         dict(name="engagement_business_line", attr="Engagement Business Line"),
                         dict(name="engagement_status", attr="Engagement Status"),
                         dict(name="engagement_start_date", attr="Engagement Start Date"),
                         dict(name="engagement_end_date", attr="Engagement End Date"),
                         dict(name="agreed_review_frequency", attr="Agreed Review Frequency")]),
        dict(name="engagement_participant", product="DP-303", entity="Engagement Participant", kind="Bridge",
             grain="engagement x participant party x participant role x effective period",
             always_filter=["participant " + _ASOF],
             dimensions=[dict(name="engagement_participant_role", attr="Engagement Participant Role"),
                         dict(name="decision_authority", attr="Decision Authority Indicator"),
                         dict(name="participant_effective_from", attr="Participant Effective From"),
                         dict(name="participant_effective_to", attr="Participant Effective To")]),
        dict(name="advice_review", product="DP-303", entity="Advice Review", kind="Fact",
             grain="one advice review (AVREV-), including the Rule 3a-4 annual contact",
             dimensions=[dict(name="advice_review_type", attr="Advice Review Type"),
                         dict(name="review_due_date", attr="Review Due Date"),
                         dict(name="review_held_date", attr="Review Held Date"),
                         dict(name="review_channel", attr="Review Channel"),
                         dict(name="review_outcome", attr="Review Outcome"),
                         dict(name="next_review_due_date", attr="Next Review Due Date")]),
        # Goals are read from DP-337's conformed copy of DP-303 Financial Goal, which adds the retirement and education
        # detail; one goal table serves both products' measures.
        dict(name="financial_goal", product="DP-337", entity="Financial Goal", kind="Dimension",
             always_filter=["status period " + _ASOF + " (SCD type 2: one row per goal)"],
             dimensions=[dict(name="goal_type", attr="Goal Type"),
                         dict(name="goal_priority", attr="Goal Priority"),
                         dict(name="goal_status", attr="Goal Status"),
                         dict(name="goal_target_date", attr="Goal Target Date"),
                         dict(name="planned_retirement_age", attr="Planned Retirement Age"),
                         dict(name="income_needed_through_age", attr="Income Needed Through Age"),
                         dict(name="education_start_year", attr="Education Start Year"),
                         dict(name="years_of_education", attr="Years of Education"),
                         dict(name="percentage_of_cost_to_fund", attr="Percentage of Cost to Fund")],
             facts=[dict(name="goal_target_amount", attr="Goal Target Amount", note="USD as recorded; " + _HH_RULE),
                    dict(name="desired_annual_retirement_income", attr="Desired Annual Retirement Income"),
                    dict(name="annual_education_cost", attr="Annual Education Cost")]),
        dict(name="financial_plan", product="DP-303", entity="Financial Plan", kind="Dimension",
             always_filter=["status period " + _ASOF + " (SCD type 2: one row per plan)"],
             dimensions=[dict(name="client_financial_plan_type", attr="Client Financial Plan Type"),
                         dict(name="client_financial_plan_status", attr="Client Financial Plan Status")]),
        dict(name="plan_version", product="DP-303", entity="Financial Plan Version", kind="Fact",
             grain="one client financial plan version (every version kept as recorded)",
             dimensions=[dict(name="plan_version_number", attr="Plan Version Number"),
                         dict(name="plan_version_status", attr="Client Financial Plan Version Status"),
                         dict(name="plan_data_as_of_date", attr="Plan Data As-Of Date"),
                         dict(name="plan_presented_date", attr="Plan Presented Date"),
                         dict(name="plan_accepted_date", attr="Plan Accepted Date")]),
        dict(name="planning_assumption_set", product="DP-303", entity="Planning Assumption Set", kind="Dimension",
             dimensions=[dict(name="assumption_set_status", attr="Assumption Set Status"),
                         dict(name="assumption_set_effective_from", attr="Assumption Set Effective From"),
                         dict(name="assumption_set_effective_to", attr="Assumption Set Effective To"),
                         dict(name="general_inflation_rate", attr="General Inflation Rate")]),
        # The CMA set version a plan's house assumptions point to, read through DP-303's conformed copy of DP-530
        # (DP-530 itself is SM-23's product).
        dict(name="plan_cma_set", product="DP-303", entity="Capital Market Assumption Set", kind="Dimension",
             dimensions=[dict(name="cma_set_version", attr="CMA Set Version"),
                         dict(name="cma_set_status", attr="CMA Set Status"),
                         dict(name="cma_as_of_date", attr="CMA As-Of Date"),
                         dict(name="cma_purposes", attr="CMA Purposes")]),
        dict(name="planning_scenario", product="DP-303", entity="Planning Scenario", kind="Fact",
             grain="one planning scenario run on a plan version",
             dimensions=[dict(name="planning_scenario_type", attr="Planning Scenario Type"),
                         dict(name="projection_method", attr="Projection Method"),
                         dict(name="scenario_run_timestamp", attr="Scenario Run Timestamp",
                              note="The run date of the projection forecast (CD-294)"),
                         dict(name="accepted_scenario", attr="Accepted Scenario Indicator")]),
        dict(name="recommendation", product="DP-303", entity="Recommendation", kind="Fact",
             grain="one recommendation (RECOM-) x client x presented timestamp",
             dimensions=[dict(name="recommendation_type", attr="Recommendation Type"),
                         dict(name="recommendation_capacity", attr="Recommendation Capacity"),
                         dict(name="recommendation_source", attr="Recommendation Source"),
                         dict(name="recommendation_channel", attr="Recommendation Channel"),
                         dict(name="recommendation_presented_timestamp", attr="Recommendation Presented Timestamp"),
                         dict(name="client_decision", attr="Client Decision"),
                         dict(name="client_decision_date", attr="Client Decision Date"),
                         dict(name="recommendation_status", attr="Recommendation Status")],
             facts=[dict(name="recommended_amount", attr="Recommended Amount", note="USD as recorded")],
             hidden=[("Rationale Basis", "Free text of the advisor's reasoning; read only by DP-334's Missing Rationale "
                                         "Flag, never shown across rows."),
                     ("Profile Factors Considered", "Free text; tested for presence by DP-334's Missing Rationale Flag."),
                     ("Recommendation Accounts", "A multi-valued account key; account slicing goes through "
                                                 "implementation_link or DP-334's evidence rows (see relationships).")]),
        # Implementation links: DP-335's conformed copy adds the implementing plan distribution, so it serves both
        # DP-303 / DP-333 (enrollments) and DP-335 (rollover distributions).
        dict(name="implementation_link", product="DP-335", entity="Recommendation Implementation Link", kind="Bridge",
             grain="recommendation x implementing record (enrollment, account, model assignment, client order or plan "
                   "distribution)",
             dimensions=[dict(name="implementing_record_type", attr="Implementing Record Type"),
                         dict(name="implementation_date", attr="Implementation Date")]),

        # ================= DP-334 Plan Quality & Recommendation Evidence (Reg BI file): acceptance question 3 =========
        # The evidence flags are row-level measures of the recommendation, published as dimensions so they slice and
        # filter. The Evidence Gap Flag is defined here only; DP-404 (SM-29) references it.
        dict(name="recommendation_evidence", product="DP-334", entity="Fact Recommendation Evidence", kind="Fact",
             grain="one recommendation in file (Recommendation Status not Draft) with its evidence flags; locked once "
                   "Client Decision is not Pending, flags re-evaluated daily until the supervisory review closes",
             always_filter=["recommendation_status <> 'Draft' (Recommendations in File)"],
             dimensions=[dict(name="evidence_gap_flag", attr="Evidence Gap Flag",
                              note="Acceptance question 3; the single definition (CW-215)"),
                         dict(name="missing_rationale_flag", attr="Missing Rationale Flag"),
                         dict(name="required_component_missing_flag", attr="Required Component Missing Flag"),
                         dict(name="unsatisfied_or_unattested_flag", attr="Unsatisfied or Unattested Component Flag"),
                         dict(name="stale_profile_flag", attr="Stale Profile Flag"),
                         dict(name="costs_considered", attr="Costs Considered Indicator"),
                         dict(name="alternatives_considered", attr="Alternatives Considered Indicator"),
                         dict(name="series_of_transactions_considered", attr="Series of Transactions Considered Indicator"),
                         dict(name="evidence_recommendation_status", attr="Recommendation Status")],
             hidden=[("Rationale Basis", "Free text; the Missing Rationale Flag carries the test."),
                     ("Profile Factors Considered", "Free text; the Missing Rationale Flag carries the test.")]),
        dict(name="best_interest_evidence", product="DP-334", entity="Fact Best Interest Evidence", kind="Fact",
             grain="recommendation x best interest component",
             dimensions=[dict(name="best_interest_component", attr="Best Interest Component"),
                         dict(name="evidence_type", attr="Evidence Type"),
                         dict(name="component_satisfied", attr="Component Satisfied Indicator"),
                         dict(name="evidence_attested_date", attr="Evidence Attested Date"),
                         dict(name="client_level_form_crs_delivered_date", attr="Client-Level Form CRS Delivered Date")]),
        dict(name="recommendation_alternative", product="DP-334", entity="Fact Recommendation Alternative", kind="Fact",
             grain="recommendation x alternative considered",
             dimensions=[dict(name="alternative_number", attr="Alternative Number")],
             facts=[dict(name="alternative_estimated_annual_cost", attr="Alternative Estimated Annual Cost")],
             hidden=[("Reason Not Selected", "Free text; tested for presence by Alternatives Without Cost.")]),
        dict(name="disclosure_delivery", product="DP-334", entity="Fact Disclosure Delivery", kind="Fact",
             grain="account x disclosure type x version x delivered date",
             dimensions=[dict(name="disclosure_type", attr="Disclosure Type"),
                         dict(name="disclosure_version", attr="Disclosure Version"),
                         dict(name="disclosure_delivered_date", attr="Disclosure Delivered Date")]),
        dict(name="alternative_investment_subscription", product="DP-334", entity="Fact Alternative Investment Subscription",
             kind="Fact", grain="one alternative investment subscription",
             always_filter=["subscription_status not in ('Draft', 'Rejected', 'Withdrawn')"],
             dimensions=[dict(name="subscription_status", attr="Subscription Status"),
                         dict(name="subscription_accepted_date", attr="Subscription Accepted Date")]),
        dict(name="investor_qualification", product="DP-334", entity="Investor Qualification", kind="Dimension",
             dimensions=[dict(name="qualification_standard", attr="Qualification Standard"),
                         dict(name="qualification_basis", attr="Qualification Basis"),
                         dict(name="determination_date", attr="Determination Date"),
                         dict(name="qualification_expiry_date", attr="Qualification Expiry Date")]),
        dict(name="investor_profile", product="DP-334", entity="Investor Profile", kind="Dimension",
             dimensions=[dict(name="profile_scope", attr="Profile Scope"),
                         dict(name="profile_version_number", attr="Profile Version Number"),
                         dict(name="profile_attested_date", attr="Attested Date"),
                         dict(name="profile_next_review_date", attr="Next Review Date"),
                         dict(name="profile_status", attr="Profile Status")],
             hidden=[("Annual Income Band", "Financial personal data; the Stale Profile Flag carries the test."),
                     ("Net Worth Band", "Financial personal data; no cross-row question needs it.")]),
        # The 08 supervisory review outcome as DP-398 publishes it (CW-215), carried as recorded and never re-scored.
        dict(name="supervisory_review", product="DP-334", entity="Supervisory Review (DP-398)", kind="Dimension",
             dimensions=[dict(name="supervisory_review_type", attr="Supervisory Review Type"),
                         dict(name="review_completed_date", attr="Review Completed Date"),
                         dict(name="supervisory_review_outcome", attr="Review Outcome"),
                         dict(name="standard_of_conduct_applied", attr="Standard of Conduct Applied"),
                         dict(name="profile_current", attr="Profile Current Indicator"),
                         dict(name="alternatives_evidence_present", attr="Alternatives Evidence Present Indicator"),
                         dict(name="cost_evidence_present", attr="Cost Evidence Present Indicator"),
                         dict(name="pte_documentation_present", attr="PTE Documentation Present Indicator")],
             hidden=[("Evidence Exceptions", "Reviewer free text; tested for presence only (Reviews Finding "
                                             "Documentation Missing)."),
                     ("Reviewing Principal", "Employee key; principal names are for the supervision role only, through "
                                             "the shared Employee dimension.")]),

        # ================= DP-335 Rollover Recommendations & PTE 2020-02 Evidence: acceptance question 3 =========
        # One row per rollover analysis with its PTE 2020-02 documentation; the PTE Documentation Gap Flag is defined
        # here only (DP-467 in SM-26 references it).
        dict(name="rollover_evidence", product="DP-335", entity="Fact Rollover Evidence", kind="Fact",
             grain="rollover analysis (ROLV-) x rollover recommendation; locked at the client decision, PTE documentation "
                   "re-evaluated daily until complete",
             dimensions=[dict(name="pte_documentation_gap_flag", attr="PTE Documentation Gap Flag",
                              note="Acceptance question 3; the single definition (CW-215)"),
                         dict(name="fiduciary_status_basis", attr="Fiduciary Status Basis"),
                         dict(name="plan_fee_data_source", attr="Plan Fee Data Source"),
                         dict(name="collected_fee_disclosure_date", attr="Collected Fee Disclosure Date"),
                         dict(name="rollover_analysis_status", attr="Rollover Analysis Status"),
                         dict(name="analysis_completed_date", attr="Analysis Completed Date"),
                         dict(name="fiduciary_acknowledgment_delivered_date", attr="Fiduciary Acknowledgment Delivered Date"),
                         dict(name="services_and_conflicts_delivered_date",
                              attr="Services and Conflicts Disclosure Delivered Date"),
                         dict(name="rollover_reasons_delivered_date", attr="Rollover Reasons Delivered Date"),
                         dict(name="impartial_conduct_attestation", attr="Impartial Conduct Standards Attestation")],
             facts=[dict(name="rollover_amount", attr="Rollover Amount",
                         note="A Derived copy held as recorded, in USD; the certified money moved is SM-20's "
                              "Net Inter-Channel Transfers")],
             hidden=[("Best Interest Reasons", "Free text; tested for presence by the PTE Documentation Gap Flag."),
                     ("Documentation Delivery Record", "A key into the delivery record; tested for presence only.")]),
        dict(name="rollover_option", product="DP-335", entity="Fact Rollover Option Comparison", kind="Fact",
             grain="rollover analysis x rollover option",
             dimensions=[dict(name="rollover_option", attr="Rollover Option"),
                         dict(name="recommended_option", attr="Recommended Option Indicator")],
             facts=[dict(name="estimated_annual_total_cost", attr="Estimated Annual Total Cost")],
             hidden=[("Option Fee Schedule", "A key to the fee schedule used; not needed across rows.")]),
        dict(name="plan_distribution", product="DP-335", entity="Fact Plan Distribution", kind="Fact",
             grain="one 16 plan distribution request (the implementing rollover)",
             dimensions=[dict(name="rollover_direction", attr="Rollover Direction"),
                         dict(name="payment_date", attr="Payment Date"),
                         dict(name="distribution_status", attr="Distribution Status")],
             facts=[dict(name="gross_distribution_amount", attr="Gross Distribution Amount")]),
        # DP-335's view of the hand-off adds the linked distribution request DP-393's view lacks; used only to split
        # Unrecorded Rollovers Into Firm Accounts by whether a hand-off named an advice engagement.
        dict(name="handoff_distribution_link", product="DP-335", entity="Fact Retail Hand-Off", kind="Bridge",
             grain="participant retail hand-off x linked distribution request",
             dimensions=[]),
        dict(name="retirement_plan", product="DP-335", entity="Retirement Plan", kind="Dimension",
             dimensions=[dict(name="plan_name", attr="Plan Name"),
                         dict(name="plan_type", attr="Plan Type")]),
        dict(name="plan_membership", product="DP-335", entity="Participant", kind="Dimension",
             dimensions=[dict(name="membership_status", attr="Membership Status")],
             hidden=[("Highly Compensated Employee Indicator", "Compensation-derived personal data; not needed.")]),

        # ================= DP-337 Goal Progress & Funded Status ==================================================
        dict(name="goal_progress", product="DP-337", entity="Fact Goal Progress", kind="Fact",
             grain="financial goal (FGOAL-) x snapshot as-of date; daily, month-end kept",
             default_filter="latest snapshot of each goal on or before the as-of date",
             dimensions=[dict(name="snapshot_as_of_date", attr="Snapshot As-Of Date"),
                         dict(name="on_track_status", attr="On-Track Status"),
                         dict(name="goal_funded_ratio", attr="Goal Funded Ratio",
                              note="Per goal; weighted by target amount in Target-Weighted Funded Ratio, never averaged"),
                         dict(name="snapshot_probability_of_success", attr="Snapshot Probability of Success")]),
        dict(name="goal_projection", product="DP-337", entity="Fact Goal Projection", kind="Fact",
             grain="planning scenario x goal",
             always_filter=["result_scenario is the goal's latest planning scenario with Accepted Scenario Indicator = Y"],
             dimensions=[dict(name="probability_of_success", attr="Probability of Success",
                              note="A forecast of the planning projection model (DP-212); per goal, never summed")],
             facts=[dict(name="projected_shortfall_amount", attr="Projected Shortfall Amount"),
                    dict(name="required_additional_annual_saving", attr="Required Additional Annual Saving"),
                    dict(name="median_projected_outcome", attr="Median Projected Outcome"),
                    dict(name="tenth_percentile_projected_outcome", attr="Tenth Percentile Projected Outcome")]),
        dict(name="projection_year", product="DP-337", entity="Fact Projection Year", kind="Fact",
             grain="planning scenario x projection year",
             dimensions=[dict(name="projection_year", attr="Projection Year"),
                         dict(name="primary_client_age_in_year", attr="Primary Client Age in Year")],
             facts=[dict(name="projected_income", attr="Projected Income"),
                    dict(name="projected_spending", attr="Projected Spending"),
                    dict(name="median_projected_portfolio_value", attr="Median Projected Portfolio Value"),
                    dict(name="tenth_percentile_portfolio_value", attr="Tenth Percentile Projected Portfolio Value")]),
        dict(name="goal_funding_link", product="DP-337", entity="Goal Funding Link", kind="Bridge",
             grain="goal x funding account or aggregated account x effective period",
             always_filter=["funding link " + _ASOF],
             dimensions=[dict(name="funding_allocation_percentage", attr="Funding Allocation Percentage"),
                         dict(name="planned_contribution_frequency", attr="Planned Contribution Frequency"),
                         dict(name="funding_effective_from", attr="Funding Effective From"),
                         dict(name="funding_effective_to", attr="Funding Effective To")],
             facts=[dict(name="planned_contribution_amount", attr="Planned Contribution Amount")]),
        dict(name="plan_goal_inclusion", product="DP-337", entity="Plan Goal Inclusion", kind="Bridge",
             grain="plan version x included goal",
             facts=[dict(name="version_goal_target_amount", attr="Version Goal Target Amount")]),
        dict(name="held_away_balance", product="DP-337", entity="Fact Held-Away Balance", kind="Fact",
             grain="aggregated (held-away) account x balance date",
             default_filter="latest balance of each aggregated account on or before the as-of date",
             dimensions=[dict(name="balance_as_of_date", attr="Balance As-Of Date")],
             facts=[dict(name="aggregated_balance_amount", attr="Aggregated Balance Amount",
                         note="Outside assets; never Client Assets (CW-024)")]),
        # DP-007's account asset summary (one value per account x holding type x date, already resolved across the books
        # of record); it values goal funding accounts and enrolled accounts. Operational values, never Client Assets.
        dict(name="account_asset_summary", product="DP-337", entity="Fact Funding Account Assets", kind="Fact",
             grain="client account x as-of date x holding type (DP-007 Account Asset Summary)",
             dimensions=[dict(name="summary_as_of_date", attr="Summary As-Of Date"),
                         dict(name="summary_holding_type", attr="Summary Holding Type"),
                         dict(name="summary_source_book", attr="Summary Source Book")],
             facts=[dict(name="summary_market_value", attr="Summary Market Value",
                         note="Operational; Client Assets is SM-20's certified number and is never recomputed from it")]),
        dict(name="projection_model", product="DP-337", entity="Model", kind="Dimension",
             dimensions=[dict(name="projection_model_name", attr="Model Name"),
                         dict(name="projection_model_version", attr="Model Version"),
                         dict(name="projection_model_use_status", attr="Model Use Status")]),

        # ================= DP-385 Advice Program Outcomes Evidence ===============================================
        dict(name="program_review", product="DP-385", entity="Program Review", kind="Dimension",
             always_filter=["review_service_offering is populated (advice program reviews only; fund reviews are DP-109's)"],
             dimensions=[dict(name="product_review_type", attr="Product Review Type"),
                         dict(name="review_period_start", attr="Review Period Start"),
                         dict(name="review_period_end", attr="Review Period End"),
                         dict(name="product_review_status", attr="Review Status"),
                         dict(name="product_review_outcome", attr="Review Outcome"),
                         dict(name="program_next_review_due_date", attr="Next Review Due Date")]),
        dict(name="program_review_criterion", product="DP-385", entity="Program Review Criterion", kind="Fact",
             grain="advice program review x product review criterion; immutable per review version",
             dimensions=[dict(name="product_review_criterion", attr="Product Review Criterion"),
                         dict(name="criterion_rating", attr="Criterion Rating"),
                         dict(name="evidence_metric_definition", attr="Evidence Metric Definition")],
             facts=[dict(name="complaint_evidence_count", attr="Complaint Evidence Count"),
                    dict(name="drift_exception_evidence_count", attr="Drift Exception Evidence Count")],
             hidden=[("Criterion Conclusion", "Reviewer free text; tested for presence by Program Criteria Without "
                                              "Evidence.")]),
        dict(name="review_action", product="DP-385", entity="Review Action", kind="Fact",
             grain="program review x action sequence",
             dimensions=[dict(name="review_action_sequence", attr="Review Action Sequence"),
                         dict(name="review_action_type", attr="Review Action Type"),
                         dict(name="review_action_due_date", attr="Review Action Due Date"),
                         dict(name="review_action_completed_date", attr="Review Action Completed Date"),
                         dict(name="review_action_status", attr="Review Action Status")]),
        # DP-385's own read of the 46 drift assessments (DP-304 is SM-23's product); used only for the program ratio.
        dict(name="program_drift_assessment", product="DP-385", entity="Drift Assessment", kind="Fact",
             grain="one drift assessment of an account",
             dimensions=[dict(name="program_assessment_timestamp", attr="Assessment Timestamp"),
                         dict(name="program_tolerance_breached", attr="Tolerance Breached Indicator")]),
        dict(name="program_complaint", product="DP-385", entity="Program Complaint", kind="Fact",
             grain="one complaint on an enrolled account (counted and classified by DP-414)",
             dimensions=[dict(name="complaint_received_date", attr="Received Date")]),

        # ================= DP-387 Advisor Capacity & Book Health =================================================
        dict(name="advisor_capacity", product="DP-387", entity="Advisor Capacity", kind="Fact",
             grain="advisor or coverage team x capacity as-of date (monthly snapshot)",
             default_filter="capacity_as_of_date = latest month-end",
             dimensions=[dict(name="capacity_as_of_date", attr="Capacity As-Of Date")],
             facts=[dict(name="assigned_household_count", attr="Assigned Household Count"),
                    dict(name="assigned_client_count", attr="Assigned Client Count"),
                    dict(name="assigned_account_count", attr="Assigned Account Count"),
                    dict(name="household_capacity_limit", attr="Household Capacity Limit"),
                    dict(name="available_household_capacity", attr="Available Household Capacity")],
             hidden=[("Book Client Assets", "The 03 copy of the advisor's book value; Book Client Assets references "
                                            "SM-20/Client Assets through advisor_client_assets, so there is one client "
                                            "assets number (CW-226).")]),
        dict(name="advisor_profile", product="DP-387", entity="Advisor", kind="Dimension",
             dimensions=[dict(name="advisor_status", attr="Advisor Status"),
                         dict(name="accepting_new_clients", attr="Accepting New Clients Indicator"),
                         dict(name="advice_channels_offered", attr="Advice Channels Offered"),
                         dict(name="advisor_specialties", attr="Advisor Specialties")],
             hidden=[("Preferred Name", "Advisor names come from the shared DP-009 Employee dimension."),
                     ("Legal Last Name", "Advisor names come from the shared DP-009 Employee dimension."),
                     ("Business Email Address", "Contact data; not needed across rows.")]),
        dict(name="coverage_model", product="DP-387", entity="Coverage Model", kind="Dimension",
             dimensions=[dict(name="coverage_delivery_mode", attr="Delivery Mode"),
                         dict(name="target_households_per_advisor", attr="Target Households per Advisor"),
                         dict(name="maximum_households_per_advisor", attr="Maximum Households per Advisor")]),
        # Primary coverage only keeps the household-to-advisor join many-to-one, so book totals add up.
        dict(name="book_coverage", product="DP-387", entity="Book Coverage Assignment", kind="Bridge",
             grain="coverage assignment of a household to an advisor or team for an effective period",
             always_filter=["primary_coverage = 'Y'"],
             default_filter="coverage " + _ASOF,
             dimensions=[dict(name="party_coverage_role", attr="Party Coverage Role"),
                         dict(name="primary_coverage", attr="Primary Coverage Indicator"),
                         dict(name="coverage_effective_from", attr="Coverage Effective From"),
                         dict(name="coverage_effective_to", attr="Coverage Effective To")]),
        dict(name="household_reassignment", product="DP-387", entity="Household Reassignment", kind="Fact",
             grain="household reassigned in a coverage reassignment",
             dimensions=[dict(name="reassignment_reason", attr="Reassignment Reason"),
                         dict(name="reassignment_effective_date", attr="Reassignment Effective Date"),
                         dict(name="planned_client_notice_date", attr="Planned Client Notice Date"),
                         dict(name="client_notice_sent_date", attr="Client Notice Sent Date")]),
        dict(name="advisor_credential", product="DP-387", entity="Advisor Credential", kind="Fact",
             grain="advisor x credential type (current credential)",
             dimensions=[dict(name="credential_type", attr="Credential Type"),
                         dict(name="credential_status", attr="Credential Status"),
                         dict(name="credential_effective_to", attr="Credential Effective To")]),
        dict(name="household_service_request", product="DP-387", entity="Household Service Request", kind="Fact",
             grain="one service request on a client account (DP-381's request, counted here per household)",
             dimensions=[dict(name="service_request_received", attr="Received Timestamp")]),
        dict(name="account_owner_role", product="DP-387", entity="Account Party Role", kind="Bridge",
             grain="account x party x role type x effective period",
             always_filter=["account_role_type in ('Primary Owner', 'Joint Owner', 'Inherited IRA Owner')",
                            "account role " + _ASOF],
             dimensions=[dict(name="account_role_type", attr="Account Role Type")]),
        dict(name="book_service_tier", product="DP-387", entity="Service Tier Assignment", kind="Bridge",
             grain="household x service tier x tier effective period",
             always_filter=["tier assignment " + _ASOF],
             dimensions=[dict(name="tier_assignment_method", attr="Tier Assignment Method")]),
        dict(name="service_tier", product="DP-387", entity="Service Tier", kind="Dimension",
             dimensions=[dict(name="service_tier_code", attr="Service Tier Code"),
                         dict(name="service_tier_name", attr="Service Tier Name")]),

        # ================= DP-393 Channel Referrals & Advice Hand-Offs ===========================================
        dict(name="channel_referral", product="DP-393", entity="Channel Referral", kind="Fact",
             grain="one channel referral (RFRL-), carried to its current status",
             dimensions=[dict(name="referral_date", attr="Referral Date"),
                         dict(name="referral_source_channel", attr="Referral Source Channel"),
                         dict(name="referral_target_channel", attr="Referral Target Channel"),
                         dict(name="referral_reason", attr="Referral Reason"),
                         dict(name="referral_status", attr="Referral Status"),
                         dict(name="referral_incentive_eligible", attr="Referral Incentive Eligible Indicator")],
             hidden=[("Source Service Request", "A key to the originating service request; not needed across rows."),
                     ("Resulting Trust", "Trust key (DP-307, optional); tested for presence by Trust Referrals "
                                         "Resulting in Trust.")]),
        dict(name="referral_status_history", product="DP-393", entity="Referral Status History", kind="Fact",
             grain="channel referral x status x status change timestamp",
             dimensions=[dict(name="history_referral_status", attr="History Referral Status"),
                         dict(name="status_change_timestamp", attr="Status Change Timestamp")]),
        dict(name="retail_handoff", product="DP-393", entity="Participant Retail Hand-Off", kind="Fact",
             grain="participant plan membership x hand-off trigger event (PRTHO-); DP-430's hand-off facts",
             dimensions=[dict(name="hand_off_trigger", attr="Hand-Off Trigger"),
                         dict(name="trigger_date", attr="Trigger Date"),
                         dict(name="hand_off_outcome", attr="Hand-Off Outcome"),
                         dict(name="outcome_date", attr="Outcome Date")],
             hidden=[("Hand-Off Rollover Amount", "DP-430's published hand-off fact; SM-26 publishes it with the rollover "
                                                  "capture rate (acceptance question 10), so it is not republished here."),
                     ("Contact Consent", "A key to the DP-240 consent record; tested for presence only.")]),
        dict(name="lead_handoff", product="DP-333", entity="Fact Lead Hand-Off", kind="Fact",
             grain="marketing lead of an advice type whose converted party opened an advice engagement",
             always_filter=["lead_type in ('Advice Prospect', 'Trust & Estate Prospect')"],
             dimensions=[dict(name="lead_type", attr="Lead Type"),
                         dict(name="lead_source", attr="Lead Source"),
                         dict(name="conversion_outcome", attr="Conversion Outcome"),
                         dict(name="conversion_timestamp", attr="Conversion Timestamp")]),

        # ================= Certified facts read only to slice referenced metrics (SM-20, SM-28, SM-08) ==========
        # One DP-008 table per dimension type, because a table can pin only one.
        dict(name="advisor_client_assets", product="DP-008", entity="Measure Value", kind="Fact",
             grain="DP-008 measure value x advisor (advisor of record) x month-end (locked snapshot)",
             always_filter=["dimension_type = 'Advisor'"] + _LOCKED_MONTHS,
             dimensions=[dict(name="advisor_period_end_date", attr="Period End Date"),
                         dict(name="advisor_measure", attr="Measure"),
                         dict(name="advisor_data_basis", attr="Data Basis")],
             facts=[dict(name="advisor_measure_amount", attr="Measure Amount",
                         note="Read only through the referenced SM-20 metrics")]),
        dict(name="channel_client_assets", product="DP-008", entity="Measure Value", kind="Fact",
             grain="DP-008 measure value x distribution channel x month-end (locked snapshot)",
             always_filter=["dimension_type = 'Channel'"] + _LOCKED_MONTHS,
             dimensions=[dict(name="channel_period_end_date", attr="Period End Date"),
                         dict(name="channel_measure", attr="Measure"),
                         dict(name="channel_dimension_key", attr="Dimension Key",
                              note="The distribution channel (Direct - Digital Advice, Direct - Human Advice, "
                                   "Direct - Trust, ...)")],
             facts=[dict(name="channel_measure_amount", attr="Measure Amount",
                         note="Read only through the referenced SM-20 metrics")]),
        dict(name="program_revenue", product="DP-012", entity="Client Revenue Record", kind="Fact",
             grain="client revenue record (account or household x client fee stream x service offering x revenue period)",
             always_filter=["client_revenue_stream is a 47 client fee stream (the SM-28 Client Fee Revenue rule)"],
             dimensions=[dict(name="client_revenue_period", attr="Client Revenue Period"),
                         dict(name="client_revenue_stream", attr="Client Revenue Stream")],
             facts=[dict(name="recognized_revenue_amount", attr="Recognized Revenue Amount",
                         note="Read only through [Program Client Fee Revenue]")],
             hidden=[("Revenue Account / Household", "Personal key; revenue is published at program grain only.")]),
        # Personal returns of record, one methodology only (time-weighted, net of fees) so no metric mixes bases.
        dict(name="personal_return", product="DP-145", entity="Personal Rate of Return", kind="Fact",
             grain="personal rate of return of a client account x period (version of record)",
             always_filter=["personal_return_status in ('Final', 'Restated'), highest Personal Return Version per account "
                            "and period", "personal_return_subject_type = 'Account'",
                            "personal_return_method = 'Time-Weighted'", "personal_return_fee_basis = 'Net of Fees'"],
             dimensions=[dict(name="personal_return_period_start", attr="Personal Return Period Start Date"),
                         dict(name="personal_return_period_end", attr="Personal Return Period End Date"),
                         dict(name="personal_return_method", attr="Personal Return Method"),
                         dict(name="personal_return_fee_basis", attr="Personal Return Fee Basis")],
             facts=[dict(name="personal_return_value", attr="Personal Return Value",
                         note="SM-08's certified value; never summed, averaged or chained here")]),
    ],

    shared=["DP-240/Party", "DP-240/Household Membership", "DP-093/Account", "DP-093/Program Enrollment",
            "DP-009/Employee", "DP-009/Coverage Team", "DP-004/Service Offering", "DP-004/Model Portfolio",
            "DP-004/Share Class", "DP-097/Instrument", "DP-013/Calendar Date"],

    relationships=[
        # --- Engagements, participants, reviews ----------------------------------------------------------------
        dict(frm="advice_engagement", to="DP-240/Party", on="advice_engagement.engagement_client = party.party_id "
             "(a client or a household party)", type="many-to-one"),
        dict(frm="advice_engagement", to="DP-009/Employee", on="advice_engagement.engagement_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="advice_engagement", to="DP-004/Service Offering",
             on="advice_engagement.engagement_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="engagement_participant", to="advice_engagement",
             on="engagement_participant.participant_engagement = advice_engagement.advice_engagement_id",
             type="many-to-one",
             warning="An engagement has several participants (primary client, spouse, trustee). Grouping by participant "
                     "counts the engagement once per participant; count engagements from advice_engagement."),
        dict(frm="engagement_participant", to="DP-240/Party",
             on="engagement_participant.participant_party = party.party_id", type="many-to-one"),
        dict(frm="advice_review", to="advice_engagement",
             on="advice_review.reviewed_engagement = advice_engagement.advice_engagement_id", type="many-to-one"),
        dict(frm="advice_review", to="DP-009/Employee", on="advice_review.review_conducted_by = employee.employee_id",
             type="many-to-one"),
        dict(frm="advice_review", to="DP-093/Program Enrollment",
             on="advice_review.reviewed_program_enrollments contains program_enrollment.program_enrollment_id",
             type="many-to-many",
             warning="One review (for example a Rule 3a-4 annual contact) can cover several enrollments. Grouping by "
                     "enrollment or program counts the review under each; count reviews from advice_review."),
        dict(frm="advice_review", to="investor_profile",
             on="advice_review.profile_version_confirmed = investor_profile.investor_profile_id", type="many-to-one"),
        # --- Goals, plans, scenarios ---------------------------------------------------------------------------
        dict(frm="financial_goal", to="DP-240/Party", on="financial_goal.goal_owner = party.party_id "
             "(" + _HH_RULE + ")", type="many-to-one"),
        dict(frm="financial_goal", to="advice_engagement",
             on="financial_goal.goal_source_engagement = advice_engagement.advice_engagement_id", type="many-to-one"),
        dict(frm="financial_plan", to="DP-240/Party", on="financial_plan.plan_subject = party.party_id", type="many-to-one"),
        dict(frm="financial_plan", to="advice_engagement",
             on="financial_plan.plan_engagement = advice_engagement.advice_engagement_id", type="many-to-one"),
        dict(frm="plan_version", to="financial_plan",
             on="plan_version.versioned_plan = financial_plan.client_financial_plan_id", type="many-to-one"),
        dict(frm="plan_version", to="planning_assumption_set",
             on="plan_version.version_assumption_set = planning_assumption_set.assumption_set_code", type="many-to-one"),
        dict(frm="plan_version", to="investor_profile",
             on="plan_version.plan_profile_version_relied_on = investor_profile.investor_profile_id", type="many-to-one"),
        dict(frm="planning_assumption_set", to="plan_cma_set",
             on="planning_assumption_set.capital_market_assumption_set = plan_cma_set.capital_market_assumption_set_id "
                "and plan_cma_set.cma_set_version", type="many-to-one"),
        dict(frm="planning_scenario", to="plan_version",
             on="planning_scenario.scenario_plan_version = plan_version.client_financial_plan_version_id",
             type="many-to-one"),
        dict(frm="planning_scenario", to="projection_model",
             on="planning_scenario.projection_engine = projection_model.model_id and model_version", type="many-to-one"),
        dict(frm="goal_progress", to="financial_goal", on="goal_progress.snapshot_goal = financial_goal.financial_goal_id",
             type="many-to-one"),
        dict(frm="goal_progress", to="planning_scenario",
             on="goal_progress.snapshot_scenario = planning_scenario.planning_scenario_id", type="many-to-one"),
        dict(frm="goal_progress", to="DP-013/Calendar Date",
             on="goal_progress.snapshot_as_of_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="goal_projection", to="financial_goal", on="goal_projection.result_goal = financial_goal.financial_goal_id",
             type="many-to-one"),
        dict(frm="goal_projection", to="planning_scenario",
             on="goal_projection.result_scenario = planning_scenario.planning_scenario_id", type="many-to-one"),
        dict(frm="projection_year", to="planning_scenario",
             on="projection_year.year_result_scenario = planning_scenario.planning_scenario_id", type="many-to-one"),
        dict(frm="plan_goal_inclusion", to="plan_version",
             on="plan_goal_inclusion.inclusion_plan_version = plan_version.client_financial_plan_version_id",
             type="many-to-one"),
        dict(frm="plan_goal_inclusion", to="financial_goal",
             on="plan_goal_inclusion.included_goal = financial_goal.financial_goal_id", type="many-to-one",
             warning="A goal is included in every plan version that names it. Use the latest accepted version only "
                     "(Goals on Stale Plan or Assumptions, Goal Target Changes) or the goal counts once per version."),
        dict(frm="goal_funding_link", to="financial_goal", on="goal_funding_link.funded_goal = financial_goal.financial_goal_id",
             type="many-to-one",
             warning="A goal can be funded by several accounts and an account can fund several goals. Funding values "
                     "are apportioned by funding_allocation_percentage; never add an account's full value to each goal."),
        dict(frm="goal_funding_link", to="DP-093/Account", on="goal_funding_link.funding_account = account.account_id",
             type="many-to-one"),
        dict(frm="goal_funding_link", to="held_away_balance",
             on="goal_funding_link.funding_aggregated_account = held_away_balance.balance_aggregated_account "
                "(latest balance on or before the as-of date)", type="many-to-many",
             warning="An aggregated account has a balance per date. Take the latest balance on or before the as-of date "
                     "before applying the allocation, or the balance is counted once per date."),
        dict(frm="account_asset_summary", to="DP-093/Account", on="account_asset_summary.summary_account = account.account_id",
             type="many-to-one"),
        dict(frm="account_asset_summary", to="DP-013/Calendar Date",
             on="account_asset_summary.summary_as_of_date = calendar_date.calendar_date", type="many-to-one"),
        # --- Recommendations, evidence, implementation ---------------------------------------------------------
        dict(frm="recommendation", to="DP-240/Party", on="recommendation.recommended_client = party.party_id",
             type="many-to-one"),
        dict(frm="recommendation", to="DP-009/Employee", on="recommendation.recommending_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="recommendation", to="advice_engagement",
             on="recommendation.recommendation_engagement = advice_engagement.advice_engagement_id", type="many-to-one"),
        dict(frm="recommendation", to="plan_version",
             on="recommendation.supporting_plan_version = plan_version.client_financial_plan_version_id",
             type="many-to-one"),
        dict(frm="recommendation", to="investor_profile",
             on="recommendation.recommendation_profile_version = investor_profile.investor_profile_id",
             type="many-to-one"),
        dict(frm="recommendation", to="DP-004/Service Offering",
             on="recommendation.recommended_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="recommendation", to="DP-004/Model Portfolio",
             on="recommendation.recommended_model_portfolio = model_portfolio.model_portfolio_id", type="many-to-one"),
        dict(frm="recommendation", to="DP-004/Share Class",
             on="recommendation.recommended_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="recommendation", to="DP-097/Instrument",
             on="recommendation.recommended_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="recommendation", to="DP-093/Account",
             on="recommendation.recommendation_accounts contains account.account_id", type="many-to-many",
             warning="A recommendation can cover several accounts (a household rebalance or a multi-account rollover). "
                     "Grouping by account counts it once per account; count recommendations from recommendation."),
        dict(frm="recommendation_evidence", to="recommendation",
             on="recommendation_evidence.recommendation_id = recommendation.recommendation_id", type="one-to-one"),
        dict(frm="recommendation_evidence", to="supervisory_review",
             on="recommendation_evidence.supervisory_review_dp_398_key = supervisory_review.supervisory_review_id",
             type="many-to-one"),
        dict(frm="best_interest_evidence", to="recommendation",
             on="best_interest_evidence.evidence_recommendation = recommendation.recommendation_id", type="many-to-one",
             warning="One row per best interest component. Count components here; count recommendations from "
                     "recommendation_evidence, never from evidence rows."),
        dict(frm="best_interest_evidence", to="disclosure_delivery",
             on="best_interest_evidence.evidence_disclosure_delivery = disclosure_delivery key", type="many-to-one"),
        dict(frm="best_interest_evidence", to="DP-009/Employee",
             on="best_interest_evidence.evidence_attester = employee.employee_id", type="many-to-one"),
        dict(frm="recommendation_alternative", to="recommendation",
             on="recommendation_alternative.alternative_recommendation = recommendation.recommendation_id",
             type="many-to-one"),
        dict(frm="disclosure_delivery", to="DP-093/Account", on="disclosure_delivery.disclosure_account = account.account_id",
             type="many-to-one"),
        dict(frm="alternative_investment_subscription", to="DP-093/Account",
             on="alternative_investment_subscription.subscribing_account = account.account_id", type="many-to-one"),
        dict(frm="alternative_investment_subscription", to="investor_qualification",
             on="alternative_investment_subscription.investor_qualification_relied_on = investor_qualification key",
             type="many-to-one"),
        dict(frm="investor_qualification", to="DP-240/Party", on="investor_qualification.qualified_party = party.party_id",
             type="many-to-one"),
        dict(frm="investor_profile", to="DP-240/Party", on="investor_profile.profile_client = party.party_id",
             type="many-to-one"),
        dict(frm="implementation_link", to="recommendation",
             on="implementation_link.implemented_recommendation = recommendation.recommendation_id", type="many-to-one",
             warning="A recommendation can be implemented by several records (an enrollment and the orders that fund it). "
                     "Use the link to test whether one exists, filtered by implementing_record_type; never count "
                     "recommendations through it."),
        dict(frm="implementation_link", to="DP-093/Program Enrollment",
             on="implementation_link.implementing_enrollment = program_enrollment.program_enrollment_id",
             type="many-to-one"),
        dict(frm="implementation_link", to="plan_distribution",
             on="implementation_link.implementing_distribution = plan_distribution.distribution_id", type="many-to-one"),
        dict(frm="DP-093/Program Enrollment", to="recommendation",
             on="program_enrollment.source_recommendation = recommendation.recommendation_id", type="many-to-one"),
        dict(frm="DP-093/Program Enrollment", to="DP-093/Account",
             on="program_enrollment.enrolled_account = account.account_id", type="many-to-one"),
        dict(frm="DP-093/Program Enrollment", to="DP-004/Service Offering",
             on="program_enrollment.enrolled_service_offering = service_offering.offering_id", type="many-to-one"),
        # --- Rollovers ------------------------------------------------------------------------------------------
        dict(frm="rollover_evidence", to="recommendation",
             on="rollover_evidence.rollover_recommendation = recommendation.recommendation_id", type="many-to-one"),
        dict(frm="rollover_evidence", to="supervisory_review",
             on="rollover_evidence.supervisory_review_dp_398_key = supervisory_review.supervisory_review_id",
             type="many-to-one"),
        dict(frm="rollover_evidence", to="retirement_plan",
             on="rollover_evidence.source_retirement_plan = retirement_plan.party_id", type="many-to-one"),
        dict(frm="rollover_evidence", to="plan_membership",
             on="rollover_evidence.source_plan_membership = plan_membership.membership_id", type="many-to-one"),
        dict(frm="rollover_option", to="rollover_evidence",
             on="rollover_option.comparison_analysis = rollover_evidence.rollover_analysis_id", type="many-to-one",
             warning="Three or more options per analysis. Sum option costs per option, never across options of one "
                     "analysis."),
        dict(frm="plan_distribution", to="plan_membership",
             on="plan_distribution.distribution_membership = plan_membership.membership_id", type="many-to-one"),
        dict(frm="plan_distribution", to="DP-093/Account", on="plan_distribution.receiving_account = account.account_id",
             type="many-to-one"),
        dict(frm="handoff_distribution_link", to="retail_handoff",
             on="handoff_distribution_link.hand_off_id = retail_handoff.hand_off_id", type="one-to-one"),
        dict(frm="handoff_distribution_link", to="plan_distribution",
             on="handoff_distribution_link.linked_distribution_request = plan_distribution.distribution_id",
             type="many-to-one"),
        # --- Program reviews ------------------------------------------------------------------------------------
        dict(frm="program_review", to="DP-004/Service Offering",
             on="program_review.review_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="program_review", to="DP-004/Model Portfolio",
             on="program_review.review_model_portfolio = model_portfolio.model_portfolio_id", type="many-to-one"),
        dict(frm="program_review", to="DP-013/Calendar Date",
             on="program_review.review_period_end = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="program_review_criterion", to="program_review",
             on="program_review_criterion.criterion_review = program_review.product_review_id", type="many-to-one"),
        dict(frm="review_action", to="program_review", on="review_action.action_review = program_review.product_review_id",
             type="many-to-one"),
        dict(frm="program_drift_assessment", to="DP-093/Account",
             on="program_drift_assessment.assessed_account = account.account_id", type="many-to-one"),
        dict(frm="program_complaint", to="DP-093/Account", on="program_complaint.account = account.account_id",
             type="many-to-one"),
        dict(frm="program_revenue", to="DP-004/Service Offering",
             on="program_revenue.revenue_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="personal_return", to="DP-093/Account", on="personal_return.personal_return_account = account.account_id",
             type="many-to-one"),
        # --- Advisor capacity and book --------------------------------------------------------------------------
        dict(frm="advisor_capacity", to="DP-009/Employee", on="advisor_capacity.capacity_subject_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="advisor_capacity", to="DP-009/Coverage Team",
             on="advisor_capacity.capacity_subject_team = coverage_team.coverage_team_id", type="many-to-one"),
        dict(frm="advisor_capacity", to="coverage_model",
             on="advisor_capacity.coverage_model_key = coverage_model.coverage_model_code", type="many-to-one"),
        dict(frm="advisor_capacity", to="DP-013/Calendar Date",
             on="advisor_capacity.capacity_as_of_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="advisor_profile", to="DP-009/Employee", on="advisor_profile.employee_id = employee.employee_id",
             type="one-to-one"),
        dict(frm="book_coverage", to="DP-240/Party", on="book_coverage.covered_party = party.party_id (the household)",
             type="many-to-one"),
        dict(frm="book_coverage", to="DP-009/Employee", on="book_coverage.covering_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="book_coverage", to="DP-009/Coverage Team",
             on="book_coverage.covering_coverage_team = coverage_team.coverage_team_id", type="many-to-one"),
        dict(frm="household_reassignment", to="DP-240/Party",
             on="household_reassignment.reassigned_household = party.party_id", type="many-to-one"),
        dict(frm="household_reassignment", to="DP-009/Employee",
             on="household_reassignment.to_advisor = employee.employee_id (role-played: from_advisor on a second join)",
             type="many-to-one"),
        dict(frm="advisor_credential", to="DP-009/Employee", on="advisor_credential.credential_holder = employee.employee_id",
             type="many-to-one"),
        dict(frm="household_service_request", to="DP-093/Account",
             on="household_service_request.account = account.account_id", type="many-to-one"),
        dict(frm="account_owner_role", to="DP-093/Account", on="account_owner_role.role_account = account.account_id",
             type="many-to-one",
             warning="Joint accounts have several owners in different households. Counting service requests per "
                     "household through owners counts a joint-account request in each owner's household."),
        dict(frm="account_owner_role", to="DP-240/Party", on="account_owner_role.role_party = party.party_id",
             type="many-to-one"),
        dict(frm="DP-240/Household Membership", to="DP-240/Party",
             on="household_membership.household_member = party.party_id (membership effective on the as-of date)",
             type="many-to-many",
             warning="Household-to-member is many-to-many and effective dated: a client can belong to more than one "
                     "household over time. Pin the membership as of the measurement date, and count household-owned "
                     "rows at household grain only; otherwise a household's members and the household both count."),
        dict(frm="book_service_tier", to="DP-240/Party", on="book_service_tier.tier_party = party.party_id",
             type="many-to-one"),
        dict(frm="book_service_tier", to="service_tier",
             on="book_service_tier.assigned_service_tier = service_tier.service_tier_code", type="many-to-one"),
        # --- Referrals and hand-offs ----------------------------------------------------------------------------
        dict(frm="channel_referral", to="DP-240/Party", on="channel_referral.referred_party = party.party_id",
             type="many-to-one"),
        dict(frm="channel_referral", to="DP-009/Employee", on="channel_referral.target_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="channel_referral", to="DP-009/Coverage Team",
             on="channel_referral.target_coverage_team = coverage_team.coverage_team_id", type="many-to-one"),
        dict(frm="channel_referral", to="advice_engagement",
             on="channel_referral.resulting_advice_engagement = advice_engagement.advice_engagement_id",
             type="many-to-one"),
        dict(frm="channel_referral", to="DP-093/Program Enrollment",
             on="channel_referral.resulting_program_enrollment = program_enrollment.program_enrollment_id",
             type="many-to-one"),
        dict(frm="channel_referral", to="DP-013/Calendar Date", on="channel_referral.referral_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="referral_status_history", to="channel_referral",
             on="referral_status_history.channel_referral_key = channel_referral.referral_id", type="many-to-one",
             warning="Several status rows per referral; use the history to test whether a status was reached, never to "
                     "count referrals."),
        dict(frm="retail_handoff", to="plan_membership", on="retail_handoff.hand_off_membership = plan_membership.membership_id",
             type="many-to-one"),
        dict(frm="retail_handoff", to="advice_engagement",
             on="retail_handoff.referral_advice_engagement = advice_engagement.advice_engagement_id", type="many-to-one"),
        dict(frm="retail_handoff", to="DP-009/Employee", on="retail_handoff.referred_advisor = employee.employee_id",
             type="many-to-one"),
        dict(frm="lead_handoff", to="DP-240/Party", on="lead_handoff.converted_party = party.party_id", type="many-to-one"),
        dict(frm="lead_handoff", to="advice_engagement",
             on="lead_handoff.converted_party = advice_engagement.engagement_client and engagement_start_date within 90 "
                "days after conversion_timestamp (matched by party and date; no direct key)", type="many-to-many",
             warning="A converted party can open more than one engagement in the window. Use the match to count hand-off "
                     "leads once, never to count engagements."),
        # --- Certified facts ------------------------------------------------------------------------------------
        dict(frm="advisor_client_assets", to="DP-009/Employee",
             on="advisor_client_assets.dimension_key = employee.employee_id (advisor of record)", type="many-to-one"),
        dict(frm="advisor_client_assets", to="DP-013/Calendar Date",
             on="advisor_client_assets.advisor_period_end_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="channel_client_assets", to="DP-013/Calendar Date",
             on="channel_client_assets.channel_period_end_date = calendar_date.calendar_date", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Advice engagement", levels=["advice_engagement.engagement_business_line",
                                               "advice_engagement.engagement_delivery_channel",
                                               "advice_engagement.engagement_type"]),
        dict(name="Recommendation", levels=["recommendation.recommendation_capacity", "recommendation.recommendation_type",
                                            "recommendation.recommendation_source"]),
        dict(name="Financial goal", levels=["financial_goal.goal_type", "financial_goal.goal_priority"]),
        dict(name="Referral route", levels=["channel_referral.referral_source_channel",
                                            "channel_referral.referral_target_channel"]),
        dict(name="Program review", levels=["program_review.product_review_type",
                                            "program_review_criterion.product_review_criterion",
                                            "program_review_criterion.criterion_rating"]),
    ],

    metrics=[
        # ================= Certified, owned elsewhere; sliced here by advisor, channel, program or account ========
        dict(name="Book Client Assets", ref="SM-20/Client Assets",
             note="Read from advisor_client_assets (Dimension Type Advisor, advisor of record from the primary 03 coverage "
                  "assignment as DP-008 applies it); DP-387's Book Client Assets by Advisor (from DP-008)."),
        dict(name="Book Net New Assets", ref="SM-20/Net New Assets",
             note="advisor_client_assets summed over the months of the period; DP-387's Book Net New Assets by Advisor and "
                  "DP-333's Net New Assets (from DP-008) beside the advisor's funnel; never recomputed from enrollments."),
        dict(name="Book Advised Assets", ref="SM-20/Advised Assets",
             note="advisor_client_assets at the month-end; DP-387's Book Advised Assets by Advisor and DP-333's Advised "
                  "Assets (from DP-008). Assets Enrolled is operational and never presented as Advised Assets."),
        dict(name="Advice Channel Advised Assets", ref="SM-20/Advised Assets",
             note="channel_client_assets at the advice channels (Direct - Digital Advice, Direct - Human Advice, Direct - "
                  "Trust) at the review period end: DP-385's program evidence. DP-008 has no offering slice of Advised "
                  "Assets (see open decisions)."),
        dict(name="Net Inter-Channel Transfers", ref="SM-20/Net Inter-Channel Transfers",
             note="channel_client_assets for the distribution channel of the referral target channel, shown beside the "
                  "hand-off counts (DP-393); never recomputed."),
        dict(name="Funding Account Personal Return", ref="SM-08/Personal Rate of Return",
             note="personal_return of the goal funding accounts (goal_funding_link.funding_account), trailing 12 months, "
                  "time-weighted and net of fees only (always_filter); shown beside the goal, never blended into a goal "
                  "return (DP-337)."),
        dict(name="Program Client Fee Revenue", ref="SM-28/Client Fee Revenue",
             note="program_revenue by Revenue Service Offering over the client revenue periods of the review period "
                  "(DP-385's Net Fee Revenue by Program; see open decisions on the name)."),

        # ================= DP-334 Reg BI file: acceptance question 3 (first half) ================================
        dict(name="Recommendations in File", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence.recommendation_id) with recommendation.recommendation_presented_"
                  "timestamp in the period",
             source=("DP-334", "Recommendations in File"),
             description="Recommendations presented in the period that are part of the Reg BI file (not drafts)."),
        dict(name="Recommendations Without Best-Interest Evidence", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence.recommendation_id) where evidence_gap_flag = 'Y', presented in "
                  "the period",
             source=("DP-334", "Recommendations Without Best-Interest Evidence"),
             description="Recommendations in the file with at least one best-interest evidence gap: missing rationale, a "
                         "required component missing, an unsatisfied or late-attested component, or a stale profile.",
             note="Acceptance question 3. Sliced by the four flags (the gap element), recommendation type and capacity, "
                  "advisor and supervisory_review.supervisory_review_outcome as DP-398 publishes it. DP-404 (SM-29) "
                  "references the Evidence Gap Flag and does not redefine it."),
        dict(name="Evidence Gap Rate %", aggregation="ratio",
             numerator="[Recommendations Without Best-Interest Evidence]",
             denominator="[Recommendations in File]",
             source=("DP-334", "Evidence Gap Rate %"),
             description="Share of recommendations in the file that have a best-interest evidence gap, by advisor and month."),
        dict(name="Disclosure Not Delivered Before Recommendation", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence) with recommendation_capacity = 'Broker-Dealer Reg BI' and no "
                  "disclosure_delivery of type Form CRS or Regulation Best Interest Disclosure on a recommendation account "
                  "delivered on or before the presented date, and no client_level_form_crs_delivered_date on or before it",
             source=("DP-334", "Disclosure Not Delivered Before Recommendation"),
             description="Brokerage recommendations made before the client received Form CRS or the Reg BI disclosure."),
        dict(name="Alternatives Without Cost", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence) with alternatives_considered = 'Y' and no "
                  "recommendation_alternative with an estimated annual cost, or with a Reason Not Selected blank",
             source=("DP-334", "Alternatives Without Cost"),
             description="Recommendations that say alternatives were considered but hold no costed alternative."),
        dict(name="Unreviewed Recommendations", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence) presented more than 30 days before the as-of date with no "
                  "completed supervisory_review of a recommendation review type",
             source=("DP-334", "Unreviewed Recommendations"),
             description="Recommendations older than 30 days that no principal has reviewed yet."),
        dict(name="Evidence Gaps Approved in Review", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence) with evidence_gap_flag = 'Y' whose completed supervisory review "
                  "has Review Outcome = No Exception, or whose reviewer indicators (alternatives, cost, profile current) "
                  "say present while the matching flag is Y",
             source=("DP-334", "Evidence Gaps Approved in Review"),
             description="Recommendations with an evidence gap that a supervisory review nevertheless passed.",
             note="The review outcome is carried as recorded and never re-scored (CW-215)."),
        dict(name="Plan Input Completeness Score", aggregation="non_additive",
             expr="DP-334's score per client financial plan version presented or accepted (0 to 100: attested profile, "
                  "income cash flows, balance sheet items, marginal tax rate, plan data within 12 months)",
             source=("DP-334", "Plan Input Completeness Score"),
             description="How complete the inputs of a financial plan version were, from 0 to 100.",
             note="Shown per plan version or as a distribution (count of versions by score band); never averaged across "
                  "versions as a firm score."),
        dict(name="Recommendations on Weak Plan", aggregation="count_distinct",
             expr="count(distinct recommendation_evidence) whose supporting plan version scored below 80 or was "
                  "Superseded at the presented timestamp",
             source=("DP-334", "Recommendations on Weak Plan"),
             description="Recommendations resting on an incomplete or superseded financial plan, by plan type."),
        dict(name="Unqualified Alternative Investment Subscriptions", aggregation="count_distinct",
             expr="count(distinct alternative_investment_subscription) whose investor qualification is blank, None "
                  "Evidenced, undated, or expired before the subscription was accepted",
             source=("DP-334", "Unqualified Alternative Investment Subscriptions"),
             description="Alternative investment subscriptions accepted without a valid investor qualification, by "
                         "feeder product."),

        # ================= DP-335 rollovers and PTE 2020-02: acceptance question 3 (second half) ================
        dict(name="Rollover Recommendations", aggregation="count_distinct",
             expr="count(distinct recommendation.recommendation_id) where recommendation_type = 'Rollover', presented in "
                  "the period",
             source=("DP-335", "Rollover Recommendations"),
             description="Rollover recommendations presented in the period, by capacity, advisor and recommended option."),
        dict(name="Rollovers Without PTE 2020-02 Documentation", aggregation="count_distinct",
             expr="count(distinct rollover recommendation) with pte_documentation_gap_flag = 'Y', or with no "
                  "rollover_evidence row at all",
             source=("DP-335", "Rollovers Without PTE 2020-02 Documentation"),
             description="Rollover recommendations missing their analysis or any PTE 2020-02 element (acknowledgment, "
                         "disclosure, reasons, impartial conduct attestation or best-interest reasons).",
             note="Acceptance question 3. Sliced by missing element, advisor and supervisory_review_outcome as DP-398 "
                  "publishes it. DP-467 (SM-26) references the flag."),
        dict(name="Rollovers Without PTE 2020-02 Documentation Amount", aggregation="additive",
             expr="sum(rollover_evidence.rollover_amount) of the rollovers counted in [Rollovers Without PTE 2020-02 "
                  "Documentation]",
             source=("DP-335", "Rollovers Without PTE 2020-02 Documentation"),
             description="Rollover amount (USD as recorded) of the rollovers missing PTE 2020-02 documentation."),
        dict(name="PTE Documentation Gap Rate %", aggregation="ratio",
             numerator="[Rollovers Without PTE 2020-02 Documentation]", denominator="[Rollover Recommendations]",
             source=("DP-335", "PTE Documentation Gap Rate %"),
             description="Share of rollover recommendations missing PTE 2020-02 documentation, by month and advisor."),
        dict(name="Documentation Delivered After Decision", aggregation="count_distinct",
             expr="count(distinct rollover_evidence) with any of the three PTE delivery dates after the recommendation's "
                  "client_decision_date, or with the dates populated and no delivery record",
             source=("DP-335", "Documentation Delivered After Decision"),
             description="Rollover analyses whose PTE documents reached the client only after the client decided."),
        dict(name="Incomplete Option Comparisons", aggregation="count_distinct",
             expr="count(distinct rollover_evidence) Completed or Presented lacking a costed rollover_option for each of "
                  "Leave in Current Plan, Roll Over to IRA and Take a Distribution",
             source=("DP-335", "Incomplete Option Comparisons"),
             description="Rollover analyses that do not compare the cost of all three options."),
        dict(name="Recommended Option Cost Premium", aggregation="non_additive",
             expr="per analysis: estimated_annual_total_cost of the option with recommended_option = 'Y' minus that of "
                  "Leave in Current Plan",
             source=("DP-335", "Recommended Option Cost Premium"),
             description="How much more a year (USD) the recommended rollover option costs than staying in the plan.",
             note="Per analysis; shown as a distribution, never summed across analyses."),
        dict(name="Costlier Rollovers Without Reasons", aggregation="count_distinct",
             expr="count(distinct rollover_evidence) with a positive [Recommended Option Cost Premium] and Best Interest "
                  "Reasons blank",
             source=("DP-335", "Recommended Option Cost Premium"),
             description="Rollovers recommended into a costlier option with no recorded best-interest reasons."),
        dict(name="Benchmark Fee Data Share %", aggregation="ratio",
             numerator="count(distinct rollover_evidence) completed in the period with plan_fee_data_source = 'Industry "
                       "Benchmark'",
             denominator="count(distinct rollover_evidence) completed in the period",
             source=("DP-335", "Benchmark Fee Data Share %"),
             description="Share of rollover analyses built on industry benchmark fees instead of the plan's own fees."),
        dict(name="Non-Fiduciary Rollover Determinations", aggregation="count_distinct",
             expr="count(distinct rollover_evidence) with fiduciary_status_basis = 'Non-Fiduciary - Five-Part Test Not Met'",
             source=("DP-335", "Non-Fiduciary Rollover Determinations"),
             description="Rollover analyses that concluded the advice was not fiduciary; expected zero by default."),
        dict(name="Unrecorded Rollovers Into Firm Accounts", aggregation="count_distinct",
             expr="count(distinct plan_distribution) Direct Rollover Out, Paid in the period, into a firm IRA account, "
                  "with no rollover_evidence for the membership completed before the payment date; split by whether a "
                  "linked hand-off (handoff_distribution_link) named an advice engagement",
             source=("DP-335", "Unrecorded Rollovers Into Firm Accounts"),
             description="Plan money rolled into firm IRAs without a recorded rollover analysis."),
        dict(name="Unrecorded Rollover Amount", aggregation="additive",
             expr="sum(plan_distribution.gross_distribution_amount) of [Unrecorded Rollovers Into Firm Accounts]",
             source=("DP-335", "Unrecorded Rollovers Into Firm Accounts"),
             description="Gross amount of plan distributions rolled into firm IRAs without a recorded rollover analysis."),
        dict(name="Rollover Implementation Rate", aggregation="ratio",
             numerator="accepted rollover recommendations with an implementation_link of type Plan Distribution to a Paid "
                       "plan_distribution",
             denominator="accepted rollover recommendations (client_decision in Accepted, Accepted with Changes)",
             source=("DP-335", "Rollover Implementation Rate"),
             description="Share of accepted rollover recommendations whose plan distribution was paid."),
        dict(name="Retrospective Review Coverage %", aggregation="ratio",
             numerator="rollover recommendations of the calendar year with a Rollover Recommendation Review supervisory "
                       "review that names the rollover analysis",
             denominator="rollover recommendations of the calendar year",
             source=("DP-335", "Retrospective Review Coverage %"),
             description="Share of the year's rollover recommendations covered by the PTE 2020-02 retrospective review."),
        dict(name="Reviews Finding Documentation Missing", aggregation="count_distinct",
             expr="count(distinct completed rollover supervisory_review) with pte_documentation_present <> 'Y' or "
                  "Evidence Exceptions populated; with the count where the PTE Documentation Gap Flag disagrees",
             source=("DP-335", "Reviews Finding Documentation Missing"),
             description="Completed rollover reviews in which the reviewer found PTE documentation missing."),

        # ================= DP-303 engagements, plans, goals and recommendations ==================================
        dict(name="Active Advice Engagements", aggregation="count_distinct",
             expr="count(distinct advice_engagement.advice_engagement_id) with engagement_status = 'Active', started on or "
                  "before and not ended before the as-of date",
             source=("DP-303", "Active Advice Engagements"),
             description="Advice engagements in force on the as-of date, by type, capacity, delivery channel and business line.",
             note=_HH_RULE + "."),
        dict(name="Engagements Without Primary Client", aggregation="count_distinct",
             expr="count(distinct active advice_engagement) with no engagement_participant of role Primary Client "
                  "effective on the as-of date",
             source=("DP-303", "Engagements Without Primary Client"),
             description="Active engagements that name no primary client."),
        dict(name="Overdue Advice Reviews", aggregation="count_distinct",
             expr="count(distinct advice_review.advice_review_id) of active engagements with review_due_date before the "
                  "as-of date and review_held_date blank",
             source=("DP-303", "Overdue Advice Reviews"),
             description="Advice reviews past their due date and not yet held, by review type and channel."),
        dict(name="Rule 3a-4 Annual Contacts On Time %", aggregation="ratio",
             numerator="advice_review of type Rule 3a-4 Annual Contact due in the trailing 12 months and held on or "
                       "before the due date",
             denominator="advice_review of type Rule 3a-4 Annual Contact due in the trailing 12 months",
             source=("DP-303", "Rule 3a-4 Annual Contacts On Time %"),
             description="Share of Rule 3a-4 annual client contacts held on time.",
             note="SM-23's Annual Contact Overdue (DP-332) combines this with the enrollment; it is not redefined there."),
        dict(name="Reviews Without Profile Confirmation", aggregation="count_distinct",
             expr="count(distinct advice_review) held in the period with Profile Version Confirmed blank",
             source=("DP-303", "Reviews Without Profile Confirmation"),
             description="Reviews held in the period that did not confirm or update the client's investor profile."),
        dict(name="Active Financial Goals", aggregation="count_distinct",
             expr="count(distinct financial_goal.financial_goal_id) with goal_status = 'Active' on the as-of date",
             source=("DP-303", "Active Financial Goals"),
             description="Financial goals in force on the as-of date, by goal type and priority.",
             note=_HH_RULE + "."),
        dict(name="Active Goal Target Amount", aggregation="semi_additive",
             expr="sum(financial_goal.goal_target_amount) of [Active Financial Goals], at the goal owner's grain",
             time_rule="single as-of date (latest in the selected range)",
             source=("DP-303", "Active Goal Target Amount"),
             description="Total target amount (USD as recorded) of active goals, by goal type and target year.",
             note="A household-owned goal counts once at household grain and never also at member grain."),
        dict(name="Current Accepted Plans", aggregation="count_distinct",
             expr="count(distinct financial_plan) Active whose latest plan_version is Accepted with plan_accepted_date on "
                  "or before the as-of date",
             source=("DP-303", "Current Accepted Plans"),
             description="Active financial plans whose latest version the client has accepted, by plan type."),
        dict(name="Accepted Plans With Stale Data", aggregation="count_distinct",
             expr="count(distinct [Current Accepted Plans]) whose accepted version has plan_data_as_of_date more than 12 "
                  "months before the as-of date",
             source=("DP-303", "Accepted Plans With Stale Data"),
             description="Accepted plans built on client data more than a year old."),
        dict(name="Plan Versions Without Accepted Scenario", aggregation="count_distinct",
             expr="count(distinct plan_version) Presented or Accepted, presented in the period, with no planning_scenario "
                  "with accepted_scenario = 'Y'",
             source=("DP-303", "Plan Versions Without Accepted Scenario"),
             description="Presented plan versions with no scenario marked as the accepted one."),
        dict(name="Plan Versions on Inactive Assumptions", aggregation="count_distinct",
             expr="count(distinct plan_version) presented in the period whose planning_assumption_set is not Active or "
                  "not effective on plan_data_as_of_date, or whose plan_cma_set is not Active",
             source=("DP-303", "Plan Versions on Inactive Assumptions"),
             description="Plan versions presented on house or capital market assumptions that were not in force."),
        dict(name="Recommendations Presented", aggregation="count_distinct",
             expr="count(distinct recommendation.recommendation_id) presented in the period",
             source=("DP-303", "Recommendations Presented"),
             description="Recommendations presented to clients in the period, by type, capacity, source and channel.",
             note="Includes drafts' successors only once presented; the Reg BI file count is [Recommendations in File]."),
        dict(name="Recommendation Acceptance Rate", aggregation="ratio",
             numerator="[Recommendations Presented] with client_decision in ('Accepted', 'Accepted with Changes')",
             denominator="[Recommendations Presented] with client_decision other than 'Pending'",
             source=("DP-303", "Recommendation Acceptance Rate"),
             description="Share of decided recommendations the client accepted, by type and source."),
        dict(name="Accepted Recommendations Implemented %", aggregation="ratio",
             numerator="accepted [Recommendations Presented] with at least one implementation_link dated on or before the "
                       "as-of date",
             denominator="accepted [Recommendations Presented]",
             source=("DP-303", "Accepted Recommendations Implemented %"),
             description="Share of accepted recommendations that have been implemented, by implementing record type."),
        dict(name="Unattested Evidence Components", aggregation="additive",
             expr="count(best_interest_evidence rows) of recommendations presented in the period with Evidence Attester "
                  "or evidence_attested_date blank",
             source=("DP-303", "Unattested Evidence Components"),
             description="Best-interest evidence components that nobody has attested, by component and evidence type.",
             note="Component-level completeness only; the recommendation-level gap is [Recommendations Without "
                  "Best-Interest Evidence]."),
        dict(name="Rollover Recommendations Without Analysis", aggregation="count_distinct",
             expr="count(distinct recommendation) of type Rollover presented in the period with no Supporting Rollover "
                  "Analysis and no rollover_evidence naming it",
             source=("DP-303", "Rollover Recommendations Without Analysis"),
             description="Rollover recommendations made without a rollover analysis on record."),
        dict(name="Rollover Amount Analyzed", aggregation="additive",
             expr="sum(rollover_evidence.rollover_amount) with rollover_analysis_status in ('Completed', 'Presented') and "
                  "analysis_completed_date in the period",
             source=("DP-303", "Rollover Amount Analyzed"),
             description="Plan assets (USD as recorded) covered by rollover analyses completed in the period.",
             note="A Derived copy held as recorded; not certified money moved (SM-20 Net Inter-Channel Transfers)."),

        # ================= DP-333 advice funnel (at the engagement; DP-392's acquisition funnel is SM-25's) =======
        dict(name="Advice Referrals", aggregation="count_distinct",
             expr="count(distinct channel_referral.referral_id) with referral_date in the period and referral_target_channel "
                  "in ('Digital Advice', 'Human Advice', 'Trust Company')",
             source=("DP-333", "Advice Referrals"),
             description="Referrals into an advice channel in the period: the first entry point of the advice funnel."),
        dict(name="Leads Handed Off to Advice", aggregation="count_distinct",
             expr="count(distinct lead_handoff.lead_id) whose converted party opened an advice engagement within 90 days "
                  "after the conversion",
             source=("DP-333", "Leads Handed Off to Advice"),
             description="Advice-type marketing leads that became an advice engagement: the hand-off from the "
                         "acquisition funnel (DP-392, SM-25), by lead source.",
             note="The only DP-333 measure that reads the 04 lead; lead qualification and account opening rates are "
                  "DP-392's and are not published here."),
        dict(name="Advice Funnel Referral to Engagement Rate %", aggregation="ratio",
             numerator="[Advice Referrals] of the entry cohort month with a resulting advice engagement (or status Converted)",
             denominator="[Advice Referrals] of the same cohort month",
             source=("DP-333", "Referral to Engagement Rate"),
             description="Share of a month's advice referrals that opened an advice engagement (cohort view).",
             note="Advice channels and cohorts only; [Referral to Engagement Rate %] (DP-393) covers every referral by "
                  "referral month. See open decisions."),
        dict(name="Advice Engagements Opened", aggregation="count_distinct",
             expr="count(distinct advice_engagement.advice_engagement_id) with engagement_start_date in the period",
             source=("DP-333", "Advice Engagements Opened"),
             description="Advice engagements started in the period, by type, capacity, channel, advisor and offering."),
        dict(name="Engagement to Plan Presented Rate", aggregation="ratio",
             numerator="engagements of the cohort (excluding Brokerage Recommendations) with a plan_version presented "
                       "within 90 days of engagement_start_date",
             denominator="[Advice Engagements Opened] in the cohort, excluding Brokerage Recommendations engagements",
             source=("DP-333", "Engagement to Plan Presented Rate"),
             description="Share of new engagements that were presented a financial plan within 90 days."),
        dict(name="Plan Acceptance Rate", aggregation="ratio",
             numerator="plan_version presented in the period with plan_accepted_date populated",
             denominator="plan_version presented in the period",
             source=("DP-333", "Plan Acceptance Rate"),
             description="Share of presented plan versions the client accepted, by the engagement type of the plan."),
        dict(name="Program Recommendations Accepted", aggregation="count_distinct",
             expr="count(distinct recommendation) of type Program Enrollment with an engagement, accepted with "
                  "client_decision_date in the period",
             source=("DP-333", "Program Recommendations Accepted"),
             description="Program enrollment recommendations made in an engagement that the client accepted, by offering."),
        dict(name="Program Recommendations Accepted Amount", aggregation="additive",
             expr="sum(recommendation.recommended_amount) of [Program Recommendations Accepted]",
             source=("DP-333", "Program Recommendations Accepted"),
             description="Amount (USD as recorded) the accepted program recommendations proposed to enroll."),
        dict(name="Days Accepted to Enrolled", aggregation="non_additive",
             expr="median(implementation_link.implementation_date - recommendation.client_decision_date) over implemented "
                  "[Program Recommendations Accepted] with implementing_record_type = 'Program Enrollment'",
             source=("DP-333", "Days Accepted to Enrolled"),
             description="Median days from the client's acceptance to the program enrollment."),
        dict(name="Enrollments From Advice", aggregation="count_distinct",
             expr="count(distinct program_enrollment.program_enrollment_id) effective in the period with "
                  "source_recommendation populated",
             source=("DP-333", "Enrollments From Advice"),
             description="Program enrollments in the period that came from a recommendation, by offering."),
        dict(name="Enrollments From Advice Share %", aggregation="ratio",
             numerator="[Enrollments From Advice]",
             denominator="count(distinct program_enrollment) effective in the period",
             source=("DP-333", "Enrollments From Advice"),
             description="Share of all new program enrollments that came from a recommendation."),
        dict(name="Assets Enrolled", aggregation="additive",
             expr="sum(account_asset_summary.summary_market_value) of the enrolled accounts of [Enrollments From Advice] at "
                  "the end of each enrollment month",
             source=("DP-333", "Assets Enrolled"),
             description="Operational value (USD) of the accounts enrolled from advice, at the end of the enrollment month.",
             note="Each enrollment is valued once, at its own month-end, so cohorts add up. Never presented as Advised "
                  "Assets or Net New Assets (SM-20)."),
        dict(name="End-to-End Conversion Rate", aggregation="ratio",
             numerator="[Advice Referrals] and [Leads Handed Off to Advice] of the cohort that reached an [Enrollments From "
                       "Advice] row for the same party within 180 days",
             denominator="[Advice Referrals] and [Leads Handed Off to Advice] of the cohort",
             source=("DP-333", "End-to-End Conversion Rate"),
             description="Share of advice funnel entries that enrolled in a program within 180 days."),
        dict(name="Days Referral to Enrollment", aggregation="non_additive",
             expr="median(program_enrollment.enrollment_effective_date - referral_date or conversion_timestamp) over the "
                  "entries that enrolled",
             source=("DP-333", "Days Referral to Enrollment"),
             description="Median days from the first advice touch to program enrollment, by engagement type and advisor."),
        dict(name="Engagements Ended Without Enrollment", aggregation="count_distinct",
             expr="count(distinct advice_engagement) Ended in the period with no accepted program recommendation, by the "
                  "last stage reached",
             source=("DP-333", "Engagements Ended Without Enrollment"),
             description="Advice engagements that ended without the client enrolling, by the last funnel stage reached."),
        dict(name="Advisors Accepting New Clients", aggregation="count_distinct",
             expr="count(distinct advisor_profile.employee_id) with advisor_status active and accepting_new_clients = 'Y'",
             source=("DP-333", "Advisors Accepting New Clients"),
             description="Active advisors open to new clients, shown beside their engagements opened in the period."),

        # ================= DP-337 goal progress ==================================================================
        dict(name="Goals With Current Snapshot %", aggregation="ratio",
             numerator="[Active Financial Goals] with a goal_progress snapshot within 31 days of the as-of date",
             denominator="[Active Financial Goals]",
             source=("DP-337", "Goals With Current Snapshot %"),
             description="Share of active goals the planning engine has assessed in the last month."),
        dict(name="Goals On Track %", aggregation="ratio",
             numerator="active goals whose latest goal_progress has on_track_status = 'On Track'",
             denominator="active goals whose latest goal_progress is not 'Not Assessed'",
             source=("DP-337", "Goals On Track %"),
             description="Share of assessed active goals that are on track, by goal type and priority."),
        dict(name="Goals Moved Off Track", aggregation="count_distinct",
             expr="count(distinct active goal) whose latest snapshot is At Risk or Off Track and previous snapshot was "
                  "On Track, in the period",
             source=("DP-337", "Goals Moved Off Track"),
             description="Active goals that slipped from on track to at risk or off track in the period."),
        dict(name="Target-Weighted Funded Ratio", aggregation="ratio",
             numerator="sum(goal_progress.goal_funded_ratio x financial_goal.goal_target_amount) over active goals with a "
                       "latest snapshot",
             denominator="sum(financial_goal.goal_target_amount) over the same goals",
             source=("DP-337", "Target-Weighted Funded Ratio"),
             description="How funded active goals are, weighted by their target amounts, by goal type."),
        dict(name="Median Probability of Success", aggregation="non_additive",
             expr="median(goal_projection.probability_of_success) of each goal's latest accepted scenario",
             source=("DP-337", "Median Probability of Success"),
             description="Median modeled probability that goals succeed, by goal type and projection method.",
             note="A forecast of the planning projection model (projection_model, DP-212) with scenario_run_timestamp as "
                  "the run date (CD-294)."),
        dict(name="Projected Shortfall", aggregation="semi_additive",
             expr="sum(goal_projection.projected_shortfall_amount) of active goals' accepted-scenario projections, with "
                  "sum(required_additional_annual_saving) beside it",
             time_rule="latest accepted scenario of each goal as of the selected date",
             source=("DP-337", "Projected Shortfall"),
             description="Modeled shortfall (USD) of active goals and the extra yearly saving needed to close it.",
             note="A forecast of the same model and run as Median Probability of Success (CD-294)."),
        dict(name="Firm Assets Funding Goals", aggregation="semi_additive",
             expr="sum over goal_funding_link in effect with a funding account of account_asset_summary.summary_market_value "
                  "on the as-of date x funding_allocation_percentage",
             time_rule="single as-of date (latest in the selected range)",
             source=("DP-337", "Firm Assets Funding Goals"),
             description="Value (USD) of firm accounts assigned to goals, apportioned by allocation percentage.",
             note="Operational DP-007 values, never Client Assets restated."),
        dict(name="Outside Assets Funding Goals", aggregation="semi_additive",
             expr="sum over goal_funding_link in effect with an aggregated account of the latest "
                  "held_away_balance.aggregated_balance_amount x funding_allocation_percentage",
             time_rule="single as-of date (latest balance on or before it)",
             source=("DP-337", "Outside Assets Funding Goals"),
             description="Value (USD) of held-away accounts assigned to goals; never Client Assets (CW-024)."),
        dict(name="Goals Without Funding Link", aggregation="count_distinct",
             expr="count(distinct active goal) other than Debt Payoff with no goal_funding_link in effect, or with "
                  "planned_contribution_amount blank on every link",
             source=("DP-337", "Goals Without Funding Link"),
             description="Active goals with no account funding them or no planned contribution."),
        dict(name="Retirement Income Replacement %", aggregation="non_additive",
             expr="per Retirement Income goal: projection_year.projected_income in the first year primary_client_age_in_year "
                  "reaches planned_retirement_age / desired_annual_retirement_income",
             source=("DP-337", "Retirement Income Replacement %"),
             description="Share of desired retirement income the accepted plan projects to replace, per goal.",
             note="Per goal; shown as a distribution, never averaged across goals."),
        dict(name="Retirement Goals Below 80% Replacement", aggregation="count_distinct",
             expr="count(distinct Retirement Income goal) with [Retirement Income Replacement %] below 80%",
             source=("DP-337", "Retirement Income Replacement %"),
             description="Retirement income goals projected to replace less than 80% of the desired income."),
        dict(name="Education Funding Gap", aggregation="semi_additive",
             expr="sum over Education goals of annual_education_cost x years_of_education x percentage_of_cost_to_fund - "
                  "[Firm Assets Funding Goals] - [Outside Assets Funding Goals]",
             time_rule="single as-of date (latest in the selected range)",
             source=("DP-337", "Education Funding Gap"),
             description="Undiscounted education cost still unfunded (USD), by education start year."),
        dict(name="Goals on Stale Plan or Assumptions", aggregation="count_distinct",
             expr="count(distinct active goal) included in the latest accepted plan_version whose data is over 12 months "
                  "old or whose planning_assumption_set is not Active or not effective",
             source=("DP-337", "Goals on Stale Plan or Assumptions"),
             description="Active goals whose accepted plan rests on old data or assumptions no longer in force."),
        dict(name="Off-Track Goals With Overdue Review", aggregation="count_distinct",
             expr="count(distinct goal) moved off track or Off Track whose source engagement has an overdue advice_review",
             source=("DP-337", "Off-Track Goals With Overdue Review"),
             description="Off-track goals whose engagement also has an overdue review."),
        dict(name="Goal Target Changes", aggregation="count_distinct",
             expr="count(distinct goal) whose plan_goal_inclusion.version_goal_target_amount differs between the latest two "
                  "accepted plan versions that include it",
             source=("DP-337", "Goal Target Changes"),
             description="Goals whose target changed between the last two accepted plans."),
        dict(name="Goal Target Net Change", aggregation="additive",
             expr="sum(latest accepted version_goal_target_amount - prior accepted version_goal_target_amount) of "
                  "[Goal Target Changes]",
             source=("DP-337", "Goal Target Changes"),
             description="Net change (USD) in goal targets between the last two accepted plans."),

        # ================= DP-385 advice program outcomes ========================================================
        dict(name="Program Reviews Overdue", aggregation="count_distinct",
             expr="count(distinct service offering) whose latest program_review has program_next_review_due_date before the "
                  "as-of date and no later review of the same type",
             source=("DP-385", "Program Reviews Overdue"),
             description="Advice programs whose periodic review is overdue."),
        dict(name="Programs Concluded Not Serving Clients", aggregation="count_distinct",
             expr="count(distinct program_review) in the period with product_review_outcome in ('Changes Required', "
                  "'Not Providing Value') or any criterion_rating at the lowest level",
             source=("DP-385", "Programs Concluded Not Serving Clients"),
             description="Program reviews that found the program needs changes or does not provide value."),
        dict(name="Program Criterion Ratings", aggregation="additive",
             expr="count(program_review_criterion rows) by product_review_criterion and criterion_rating",
             source=("DP-385", "Program Criterion Rating Distribution"),
             description="How program review criteria were rated, by criterion, rating and review period end."),
        dict(name="Program Criteria Without Evidence", aggregation="additive",
             expr="count(program_review_criterion rows) whose criterion needs evidence and whose evidence column is empty, "
                  "or with no Evidence Metric Definition or Criterion Conclusion",
             source=("DP-385", "Program Criteria Without Evidence"),
             description="Program review criteria rated without the evidence they require."),
        dict(name="Program Enrolled Accounts", aggregation="count_distinct",
             expr="count(distinct program_enrollment.enrolled_account) Active at review_period_end",
             source=("DP-385", "Enrolled Accounts"),
             description="Accounts enrolled in each advice program at the end of the review period."),
        dict(name="Program Termination Rate %", aggregation="ratio",
             numerator="program_enrollment rows with enrollment_termination_date in the review period",
             denominator="[Program Enrolled Accounts] at review_period_start",
             source=("DP-385", "Program Termination Rate %"),
             description="Share of a program's enrolled accounts that left during the review period, by reason."),
        dict(name="Program Accounts Outside Drift Tolerance %", aggregation="ratio",
             numerator="[Program Enrolled Accounts] whose latest program_drift_assessment on or before review_period_end has "
                       "program_tolerance_breached = 'Y'",
             denominator="[Program Enrolled Accounts] with a drift assessment in the period",
             source=("DP-385", "Accounts Outside Drift Tolerance % (from DP-304)"),
             description="Share of a program's assessed accounts outside drift tolerance at the review period end.",
             note="The drift assessment is DP-304's, read as published; the account-level answer to acceptance question "
                  "4 is SM-23's Accounts Outside Drift Tolerance."),
        dict(name="Median Personal Return by Program", aggregation="non_additive",
             expr="median(personal_return.personal_return_value) over the program's enrolled accounts for the review "
                  "period, with the 25th and 75th percentiles beside it; cells under 10 accounts suppressed",
             source=("DP-385", "Median Personal Return by Program (from DP-145)"),
             description="Median time-weighted, net-of-fees personal return of the accounts in an advice program.",
             note="A distribution of SM-08's certified Personal Rate of Return values (method pinned in personal_return's "
                  "always_filter); each value is read, never recomputed."),
        dict(name="Complaints per 1,000 Enrolled Accounts", aggregation="ratio",
             numerator="count(distinct program_complaint) received in the review period on the program's enrolled accounts "
                       "x 1,000",
             denominator="[Program Enrolled Accounts]",
             source=("DP-385", "Complaints per 1,000 Enrolled Accounts (from DP-414)"),
             description="Complaints on a program's accounts per thousand enrolled accounts.",
             note="Complaints are counted and classified by DP-414 (SM-29), never reclassified here."),
        dict(name="Program Review Actions Overdue", aggregation="count_distinct",
             expr="count(distinct review_action) with review_action_due_date before the as-of date and no completed date",
             source=("DP-385", "Program Review Actions Overdue"),
             description="Actions from program reviews past their due date, by action type."),
        dict(name="Program Actions Converted to Change %", aggregation="ratio",
             numerator="review_action of a change type with a Resulting Change Initiative",
             denominator="review_action of a change type",
             source=("DP-385", "Program Actions Converted to Change %"),
             description="Share of program review change actions that became a change initiative."),

        # ================= DP-387 advisor capacity and book health ===============================================
        dict(name="Assigned Households", aggregation="semi_additive",
             expr="sum(advisor_capacity.assigned_household_count)",
             time_rule="last capacity_as_of_date in the selected range",
             source=("DP-387", "Assigned Households"),
             description="Households in the book of each advisor or coverage team at the month-end.",
             note="Advisor rows and team rows are separate subjects; add up advisors or teams, never both."),
        dict(name="Assigned Clients", aggregation="semi_additive",
             expr="sum(advisor_capacity.assigned_client_count)", time_rule="last capacity_as_of_date in the selected range",
             source=("DP-387", "Assigned Client Count"),
             description="Clients in each advisor's or team's book at the month-end."),
        dict(name="Assigned Accounts", aggregation="semi_additive",
             expr="sum(advisor_capacity.assigned_account_count)", time_rule="last capacity_as_of_date in the selected range",
             source=("DP-387", "Assigned Account Count"),
             description="Accounts in each advisor's or team's book at the month-end."),
        dict(name="Capacity Utilization %", aggregation="ratio",
             numerator="sum(advisor_capacity.assigned_household_count)",
             denominator="sum(advisor_capacity.household_capacity_limit, else coverage_model.maximum_households_per_advisor "
                         "of the matching delivery mode) for the same snapshots",
             source=("DP-387", "Capacity Utilization %"),
             description="How full books are: assigned households as a share of household capacity."),
        dict(name="Advisors Over Capacity", aggregation="count_distinct",
             expr="count(distinct advisor_capacity.capacity_subject_advisor) with [Capacity Utilization %] above 100%",
             source=("DP-387", "Advisors Over Capacity"),
             description="Advisors whose books exceed their household capacity, by coverage team."),
        dict(name="Advisors Near Capacity", aggregation="count_distinct",
             expr="count(distinct advisor_capacity.capacity_subject_advisor) with [Capacity Utilization %] between 90% and "
                  "100%",
             source=("DP-387", "Advisors Over Capacity"),
             description="Advisors whose books are between 90% and 100% of capacity."),
        dict(name="Advisors Open to New Clients With Capacity", aggregation="count_distinct",
             expr="count(distinct advisor) with advisor_status Active, accepting_new_clients = 'Y' and "
                  "available_household_capacity > 0 at the snapshot",
             source=("DP-387", "Advisors Open to New Clients With Capacity"),
             description="Advisors who accept new clients and still have room in their book."),
        dict(name="Available Household Capacity", aggregation="semi_additive",
             expr="sum(advisor_capacity.available_household_capacity) of [Advisors Open to New Clients With Capacity]",
             time_rule="last capacity_as_of_date in the selected range",
             source=("DP-387", "Available Household Capacity"),
             description="Households that open advisors can still take on."),
        dict(name="Book Households Without Primary Advisor", aggregation="count_distinct",
             expr="count(distinct household party) with no book_coverage primary assignment effective on the as-of date, "
                  "by the coverage team of the last assignment",
             source=("DP-387", "Households Without Primary Advisor"),
             description="Client households with no primary advisor today."),
        dict(name="Advice Review Completion %", aggregation="ratio",
             numerator="advice_review due in the period and held on or before the due date",
             denominator="advice_review due in the period",
             source=("DP-387", "Advice Review Completion %"),
             description="Share of due advice reviews held on time, by advisor (review conducted by) and review type."),
        dict(name="Service Requests per Household", aggregation="ratio",
             numerator="count(distinct household_service_request) received in the period on accounts owned by members of "
                       "the advisor's book households",
             denominator="[Assigned Households]",
             source=("DP-387", "Service Requests per Household (from DP-381)"),
             description="Service requests per household in each advisor's book.",
             note="Joint accounts owned across households count in each owner's household (see relationships)."),
        dict(name="Household Attrition Rate %", aggregation="ratio",
             numerator="households whose primary book_coverage to the advisor ended in the period without a "
                       "household_reassignment or a later primary assignment",
             denominator="[Assigned Households] at period start",
             source=("DP-387", "Household Attrition Rate %"),
             description="Share of an advisor's households that left without being reassigned."),
        dict(name="Households Reassigned In", aggregation="count_distinct",
             expr="count(distinct household_reassignment) to the advisor effective in the period",
             source=("DP-387", "Households Reassigned In"),
             description="Households reassigned to the advisor in the period, by reason and previous advisor."),
        dict(name="Reassignment Notice Timeliness %", aggregation="ratio",
             numerator="household_reassignment effective in the period with client_notice_sent_date on or before "
                       "planned_client_notice_date",
             denominator="household_reassignment effective in the period",
             source=("DP-387", "Reassignment Notice Timeliness %"),
             description="Share of reassigned households told about the change by the planned date."),
        dict(name="Book Service Tier Mix", aggregation="count_distinct",
             expr="count(distinct household) in the advisor's book by service_tier in force on the as-of date",
             source=("DP-387", "Book Service Tier Mix"),
             description="Households in each advisor's book by service tier."),
        dict(name="Protected Households in Book", aggregation="count_distinct",
             expr="count(distinct household) in the advisor's book with at least one member whose DP-322 Protection Flag "
                  "Present = Y, as DP-387 publishes it; shown only where the count is 10 or more",
             source=("DP-387", "Protected Households in Book (from DP-322)"),
             description="Households in a book with a protected member (specified adult, diminished capacity or a hold).",
             note="Special-category data (CD-344): an aggregate only, from DP-387's published count; no protection flag "
                  "or member is exposed in this model, and cells under 10 are suppressed."),
        dict(name="Advisors With Lapsed Credentials", aggregation="count_distinct",
             expr="count(distinct advisor_credential.credential_holder) with a Lapsed or Expired credential, or one past "
                  "credential_effective_to, among credentials named in advisor_specialties",
             source=("DP-387", "Advisors With Lapsed Credentials"),
             description="Advisors holding out a credential that has lapsed or expired, by credential type."),

        # ================= DP-393 channel referrals and hand-offs ================================================
        dict(name="Referrals Made", aggregation="count_distinct",
             expr="count(distinct channel_referral.referral_id) with referral_date in the period",
             source=("DP-393", "Referrals Made"),
             description="Channel referrals made in the period, by source channel, target channel and reason."),
        dict(name="Referral Acceptance Rate %", aggregation="ratio",
             numerator="[Referrals Made] that reached Accepted, Engaged or Enrolled in referral_status_history",
             denominator="[Referrals Made]",
             source=("DP-393", "Referral Acceptance Rate %"),
             description="Share of referrals the target channel accepted, by target channel."),
        dict(name="Referral to Engagement Rate %", aggregation="ratio",
             numerator="[Referrals Made] with a resulting advice engagement",
             denominator="[Referrals Made]",
             source=("DP-393", "Referral to Engagement Rate %"),
             description="Share of referrals that opened an advice engagement, by source and target channel."),
        dict(name="Referral to Enrollment Rate %", aggregation="ratio",
             numerator="[Referrals Made] whose resulting program enrollment is Active",
             denominator="[Referrals Made]",
             source=("DP-393", "Referral to Enrollment Rate %"),
             description="Share of referrals that ended in an active program enrollment, by offering."),
        dict(name="Referral Leakage %", aggregation="ratio",
             numerator="[Referrals Made] whose final referral_status is Declined, Expired or No Contact",
             denominator="[Referrals Made]",
             source=("DP-393", "Referral Leakage %"),
             description="Share of referrals lost without contact or engagement, by target channel and coverage team."),
        dict(name="Median Days Referral to Engagement", aggregation="non_additive",
             expr="median(advice_engagement.engagement_start_date - channel_referral.referral_date) over referrals with a "
                  "resulting engagement",
             source=("DP-393", "Median Days Referral to Engagement"),
             description="Median days from a referral to the start of the advice engagement, by target channel."),
        dict(name="Referrals Open Past 30 Days", aggregation="count_distinct",
             expr="count(distinct channel_referral) not in a terminal status whose last status_change_timestamp is more "
                  "than 30 days before the as-of date",
             source=("DP-393", "Referrals Open Past 30 Days"),
             description="Referrals still open with no status change for over 30 days, by target advisor."),
        dict(name="Participant Hand-Offs Triggered", aggregation="count_distinct",
             expr="count(distinct retail_handoff.hand_off_id) with trigger_date in the period",
             source=("DP-393", "Participant Hand-Offs Triggered"),
             description="Plan participant events (for example separation) handed to the retail business, by trigger "
                         "and plan.",
             note="The hand-off facts are DP-430's; the rollover capture rate (acceptance question 10) is SM-26's."),
        dict(name="Hand-Offs With Contact Consent %", aggregation="ratio",
             numerator="[Participant Hand-Offs Triggered] with Contact Consent populated",
             denominator="[Participant Hand-Offs Triggered]",
             source=("DP-393", "Hand-Offs With Contact Consent %"),
             description="Share of participant hand-offs where the participant agreed to be contacted."),
        dict(name="Hand-Off to Advice Engagement Rate %", aggregation="ratio",
             numerator="[Participant Hand-Offs Triggered] with a referral advice engagement",
             denominator="[Participant Hand-Offs Triggered]",
             source=("DP-393", "Hand-Off to Advice Engagement Rate %"),
             description="Share of participant hand-offs that opened an advice engagement, by trigger and advisor channel.",
             note="Owned here; DP-467 (SM-26) reads it as defined here (C-3 ruling)."),
        dict(name="Hand-Off Outcomes", aggregation="count_distinct",
             expr="count(distinct retail_handoff) with outcome_date in the period by hand_off_outcome",
             source=("DP-393", "Hand-Off Outcome Mix"),
             description="Participant hand-offs by outcome: rolled to a firm IRA, stayed in plan, left or no response."),
        dict(name="Referral Incentive Eligible Referrals", aggregation="count_distinct",
             expr="count(distinct [Referrals Made]) with referral_incentive_eligible = 'Y'",
             source=("DP-393", "Referral Incentive Eligible Referrals"),
             description="Referrals eligible for a referral incentive, by the referring employee's channel.",
             note="The incentive itself is a DP-390 plan component (SM-29)."),
        dict(name="Trust Referrals Resulting in Trust", aggregation="count_distinct",
             expr="count(distinct [Referrals Made]) with referral_target_channel = 'Trust' and a Resulting Trust",
             source=("DP-393", "Trust Referrals Resulting in Trust"),
             description="Trust referrals that led to a trust relationship (trust is a tailoring lever)."),
        dict(name="Trust Referral Conversion %", aggregation="ratio",
             numerator="[Trust Referrals Resulting in Trust]",
             denominator="[Referrals Made] with referral_target_channel = 'Trust'",
             source=("DP-393", "Trust Referrals Resulting in Trust"),
             description="Share of trust referrals that led to a trust relationship."),
    ],

    excluded=[
        ("DP-333", "Advised Assets (from DP-008)",
         "Certified (CW-011): published as Book Advised Assets = ref SM-20/Advised Assets on the Advisor dimension type "
         "(advisor_client_assets), so there is one Advised Assets definition."),
        ("DP-333", "Net New Assets (from DP-008)",
         "Certified (CW-011): published as Book Net New Assets = ref SM-20/Net New Assets by advisor."),
        ("DP-337", "Funding Account Personal Return (from DP-145)",
         "Certified (CW-011, CW-251): published as Funding Account Personal Return = ref SM-08/Personal Rate of Return "
         "through personal_return, method pinned."),
        ("DP-385", "NNA by Offering and Program (from DP-491)",
         "DP-491's operational decomposition of Net New Assets by offering; DP-491 is an SM-20 product and SM-20 publishes "
         "it. Read there beside the program review, not republished here (see open decisions)."),
        ("DP-385", "Advice Channel Advised Assets (from DP-008)",
         "Certified: published as Advice Channel Advised Assets = ref SM-20/Advised Assets at the Channel dimension type."),
        ("DP-385", "Net Fee Revenue by Program (from DP-012)",
         "Certified: published as Program Client Fee Revenue = ref SM-28/Client Fee Revenue by Revenue Service Offering "
         "(program_revenue); see open decisions on Net versus Client Fee Revenue."),
        ("DP-387", "Book Client Assets by Advisor (from DP-008)",
         "Certified (CW-011): published as Book Client Assets = ref SM-20/Client Assets by advisor of record."),
        ("DP-387", "Book Net New Assets by Advisor (from DP-008)",
         "Certified: published as Book Net New Assets = ref SM-20/Net New Assets by advisor of record."),
        ("DP-387", "Book Advised Assets by Advisor (from DP-008)",
         "Certified: published as Book Advised Assets = ref SM-20/Advised Assets by advisor of record."),
        ("DP-393", "Hand-Off Rollover Amount (from DP-430)",
         "DP-430's published hand-off amount; SM-26 publishes DP-430 with the rollover capture rate (acceptance question "
         "10), so it is read there and not given a second definition here."),
        ("DP-393", "Net Inter-Channel Transfers by Target Channel (from DP-008)",
         "Certified (CW-142): published as Net Inter-Channel Transfers = ref SM-20/Net Inter-Channel Transfers at the "
         "Channel dimension type (channel_client_assets)."),
    ],

    access=dict(
        classification="Confidential - Personal Data (client, household, recommendation and plan rows); program-level "
                       "aggregates Confidential - Client",
        roles=[
            dict(role="advice_leadership",
                 rows="all engagements, recommendations, goals, programs and advisors",
                 columns="all except the special-category count below its 10-household cell",
                 hidden=[]),
            dict(role="advice_supervision",          # principals, Reg BI and PTE 2020-02 review, retail conduct
                 rows="all recommendations, rollovers, evidence rows and supervisory review outcomes",
                 columns="all", hidden=[]),
            dict(role="advisor",
                 rows="engagements, recommendations, goals and referrals where the viewer is the engagement, recommending, "
                      "target or covering advisor; the viewer's own capacity and book rows",
                 columns="all for the viewer's own clients; other advisors' rows as aggregates only",
                 hidden=[]),
            dict(role="advisor_workforce",
                 rows="all advisor capacity, coverage, credential, reassignment and referral rows",
                 columns="advisor-level; client and household detail as counts only",
                 hidden=_CLIENT_COLUMNS + ["party_display_name", "given_name", "family_name", "household_name"]),
            dict(role="product_governance",          # advice program reviews (DP-385, read by DP-109)
                 rows="program reviews, criteria, actions and program-level aggregates; no account, client or advisor rows",
                 columns="program, model, review and criterion columns",
                 hidden=_CLIENT_COLUMNS + _PEOPLE_NAMES),
            dict(role="broad_internal",              # finance, marketing, digital, executive reporting
                 rows="aggregates by channel, offering, program, engagement type, recommendation type and month only",
                 columns="no client, household, account or advisor identifiers; cells under 10 suppressed",
                 hidden=_CLIENT_COLUMNS + _PEOPLE_NAMES + ["recommendation_presented_timestamp", "client_decision_date",
                                                           "engagement_start_date", "referral_date", "trigger_date"]),
        ]),

    verified_questions=[
        dict(question="Which recommendations presented last quarter lack best-interest evidence, by advisor and gap "
                      "element, and what did the supervisory review conclude?",
             answer="[Recommendations Without Best-Interest Evidence] and [Evidence Gap Rate %] for recommendations "
                    "presented in the quarter, grouped by DP-009 Employee (recommending advisor) and by the four flags "
                    "missing_rationale_flag, required_component_missing_flag, unsatisfied_or_unattested_flag and "
                    "stale_profile_flag, with supervisory_review.supervisory_review_outcome as DP-398 publishes it; "
                    "[Evidence Gaps Approved in Review] beside it.",
             sql="select e.employee_id, r.missing_rationale_flag, r.required_component_missing_flag, "
                 "r.unsatisfied_or_unattested_component_flag, r.stale_profile_flag, s.review_outcome, "
                 "count(distinct r.recommendation_id) as recommendations_without_evidence "
                 "from dp_334.fact_recommendation_evidence r "
                 "join dp_303.recommendation rec on rec.recommendation_id = r.recommendation_id "
                 "left join dp_334.supervisory_review_dp_398 s on s.supervisory_review_id = r.supervisory_review_dp_398_key "
                 "join dp_009.employee e on e.employee_id = rec.recommending_advisor "
                 "where r.recommendation_status <> 'Draft' and r.evidence_gap_flag = 'Y' "
                 "and rec.recommendation_presented_timestamp >= date_trunc('quarter', current_date) - interval '3 months' "
                 "and rec.recommendation_presented_timestamp < date_trunc('quarter', current_date) "
                 "group by 1, 2, 3, 4, 5, 6"),
        dict(question="Which rollovers lack PTE 2020-02 documentation, and how much money do they involve?",
             answer="[Rollovers Without PTE 2020-02 Documentation], [Rollovers Without PTE 2020-02 Documentation Amount] "
                    "and [PTE Documentation Gap Rate %] for rollover recommendations presented in the period, by "
                    "recommending advisor and missing element (the PTE delivery dates and the attestation on "
                    "rollover_evidence), with supervisory_review_outcome; [Unrecorded Rollovers Into Firm Accounts] for "
                    "rollovers with no analysis at all."),
        dict(question="How did the advice funnel convert this year by delivery channel?",
             answer="[Advice Referrals], [Leads Handed Off to Advice], [Advice Engagements Opened], [Engagement to Plan "
                    "Presented Rate], [Plan Acceptance Rate], [Program Recommendations Accepted], [Enrollments From "
                    "Advice] and [End-to-End Conversion Rate], grouped by advice_engagement.engagement_delivery_channel "
                    "and entry cohort month; [Book Net New Assets] (ref SM-20) beside each advisor's funnel, never "
                    "derived from enrollments."),
        dict(question="Which advisors are over capacity, and how much client assets and advised assets do their books "
                      "hold?",
             answer="[Advisors Over Capacity] and [Capacity Utilization %] at the latest capacity_as_of_date by DP-009 "
                    "Coverage Team, with [Book Client Assets] and [Book Advised Assets] (refs to SM-20 through "
                    "advisor_client_assets at the same month-end, locked snapshot) and [Assigned Households]."),
        dict(question="What share of retirement goals are on track, and which are on stale plans?",
             answer="[Goals On Track %] and [Target-Weighted Funded Ratio] with financial_goal.goal_type = 'Retirement "
                    "Income', latest goal_progress per goal; [Goals on Stale Plan or Assumptions] and [Retirement Goals "
                    "Below 80% Replacement] beside them; household-owned goals counted once at household grain."),
    ],

    cannot_answer=[
        dict(question="Which best-interest component is missing because the capacity requires it, read from the taxonomy",
             why="45 holds no record of which Best Interest Component values a Recommendation Capacity requires; the "
                 "rule sits in DP-334's Required Component Missing Flag. No gap is registered for it yet.",
             gap=""),
        dict(question="The gap element of each recommendation as one column",
             why="DP-334 publishes the first flag met as the gap element, but its logical model has no Evidence Gap "
                 "Element attribute; the model derives it from the four flags in order (see open decisions).",
             gap=""),
        dict(question="Net new assets and advised assets by advice program (service offering) as certified numbers",
             why="DP-008 Measure Value has no Service Offering dimension type; Advised Assets is shown at the advice "
                 "channel and the offering decomposition of NNA is DP-491's operational view (SM-20).",
             gap=""),
        dict(question="Which marketing lead led to which advice engagement, exactly",
             why="04 Lead Conversion has no link to an advice engagement, so the hand-off is matched by party and a "
                 "90-day window.",
             gap=""),
        dict(question="Why a household left an advisor's book",
             why="03 Party Coverage Assignment has no end reason; attrition is inferred from the absence of a "
                 "reassignment or later assignment.",
             gap=""),
        dict(question="When a channel referral expired or closed",
             why="03 Channel Referral has no closed or expiry date; open age is taken from the last status change.",
             gap=""),
        dict(question="When an advice program review was completed",
             why="36 Product Review has no completion date; overdue reviews use Next Review Due Date only.",
             gap="GAP-36-001"),
    ],

    open_decisions=[
        "Acceptance question 3: the DP-334 Evidence Gap Flag and the DP-335 PTE Documentation Gap Flag are published "
        "here as row-level dimensions and are the single definitions. SM-29 (DP-404) and SM-26 (DP-467) must reference "
        "Recommendations Without Best-Interest Evidence and Rollovers Without PTE 2020-02 Documentation with "
        "ref='SM-22/...', and never re-derive the flags.",
        "DP-334 publishes 'the first flag met' as the gap element but its logical model has no Evidence Gap Element "
        "column. Add the attribute to Fact Recommendation Evidence; until then the gap element is the first Y among "
        "missing_rationale_flag, required_component_missing_flag, unsatisfied_or_unattested_flag and stale_profile_flag.",
        "Two referral conversion rates: DP-333 Referral to Engagement Rate (advice target channels, entry cohort) and "
        "DP-393 Referral to Engagement Rate % (all referrals, by referral month). Published as 'Advice Funnel Referral to "
        "Engagement Rate %' and 'Referral to Engagement Rate %'; the Head of Advice and the Head of Advisor Workforce "
        "should agree whether DP-333 reads DP-393's rate with a channel filter instead.",
        "DP-385 names its revenue evidence 'Net Fee Revenue by Program (from DP-012)', but its formula reads the "
        "Recognized Revenue Amount of 10 Client Revenue Records by Revenue Service Offering, which is SM-28's certified "
        "Client Fee Revenue (no fund waivers apply at program grain). The model references SM-28/Client Fee Revenue; "
        "rename the DP-385 measure or confirm Net Fee Revenue has a program slice.",
        "DP-385 NNA by Offering and Program (from DP-491) is excluded until SM-20 publishes DP-491's offering "
        "decomposition under a name this model can reference (ref='SM-20/<name>'). DP-008 has no Service Offering "
        "dimension type for certified Net New Assets or Advised Assets; adding one would let programs read certified "
        "numbers directly.",
        "advisor_client_assets reads DP-008 at Dimension Type 'Advisor' and channel_client_assets at 'Channel'. Confirm "
        "the Dimension Type values DP-008 writes, that the advisor of record is the primary 03 coverage assignment as "
        "DP-008 applies it, and the snapshot of record (Final, else the latest Restated) that SM-20 certifies.",
        "DP-009 Employee carries no Accepting New Clients Indicator or Advisor Specialties; the model reads them from "
        "DP-387's conformed Advisor (advisor_profile, one-to-one with DP-009 Employee). Add both attributes to DP-009 "
        "so every model reads them from the shared Advisor dimension.",
        "Book coverage reads DP-387's Book Coverage Assignment with primary coverage pinned rather than the shared "
        "DP-009 Coverage Assignment. Confirm each household has exactly one effective primary assignment; otherwise the "
        "join to advisors becomes many-to-many and book totals overcount.",
        "Goals, plans and engagements are SCD type 2; the tables pin the status period in effect on the as-of date. "
        "Confirm the as-of date users pick is applied to every SCD table in one query (a dashboard date control), so "
        "goal and engagement counts on different dates are never mixed.",
        "Protected Households in Book is published only as DP-387's aggregate count with a minimum cell of 10 (CD-344). "
        "Confirm with the Head of Retail Conduct that advisors may see this count for their own book.",
        "Hand-Off Rollover Amount and the participant hand-off facts are DP-430's (SM-26). DP-393 republishes them; "
        "Participant Hand-Offs Triggered and Hand-Off to Advice Engagement Rate % are defined here (C-3 ruling), the "
        "amount is left to SM-26. SM-26 should reference these two metrics rather than define its own.",
        "Retirement plan names (retirement_plan.plan_name) are organization names but carry a personal-data flag in the "
        "conformed DP-094 entity. Confirm they may be shown to the advisor workforce role.",
        "Three definitions of uncovered households: DP-387 Households Without Primary Advisor (published here as 'Book "
        "Households Without Primary Advisor': no effective primary assignment, by the team of the last assignment), "
        "DP-320 Households Without Primary Advisor (SM-21: households with advised assets and no primary coverage) and "
        "DP-009 Uncovered Tiered Households (SM-00). The Head of Client Data and the Head of Advisor Workforce should "
        "agree one definition and the others reference it.",
        "Hand-Off to Advice Engagement Rate % is owned by DP-393 (C-3 ruling) and defined here; SM-26 currently defines "
        "a metric of the same name from DP-467 '(from DP-393)'. SM-26 should use ref='SM-22/Hand-Off to Advice "
        "Engagement Rate %' and exclude DP-467's copy.",
        "A sub-adviser cut is not needed for advice (it is SM-23's); Manager (DP-306) stays SM-31's.",
    ],
)
