"""Semantic model SM-24 Brokerage Activity & Execution Quality. See CONTRACT.md.

Publishes the brokerage book of record (DP-300 Client Holdings, Lots & Cost Basis, the 49 Client Holding book), client
orders and executions (DP-301), money movement (DP-302), the sweep program and program bank masters (DP-431), the venue
and routing rule masters with the Rule 605 lines (DP-432), execution quality and Rules 605 and 606 (DP-436), trade
corrections and errors (DP-437), the customer reserve and possession-or-control control pack (DP-445), ACATS transfers
(DP-448) and the cash sweep and program bank allocation (DP-457).

DP-435 Order Lifecycle & CAT Completeness, DP-447 Settlement & Fails and DP-456 Senior Investor & Fraud Holds do not list
the BI semantic model delivery and are not published (register note, WP2); their questions are in cannot_answer.

Double-counting and disclosure rules kept closed here:
- One table per taxonomy object. Several products read the same 48, 49 and 50 rows (Trade Correction in DP-301 and
  DP-437; Account Transfer and Cost Basis Transfer Statement in DP-300 and DP-448; Rule 605 Report Line in DP-432 and
  DP-436; Sweep Allocation in DP-302 and DP-457; Program Bank Daily Total and FDIC Coverage Assessment in DP-431 and
  DP-457; Account Cash Balance and Client Holding in DP-300, DP-445 and DP-457). Each object is read once, from the
  product that carries the attributes the metrics need; a metric keeps the product that defines it as its source.
- Measures a consumer product copies "(from DP-nnn)" are excluded; the owning product's metric is published once.
- Books of record (CW-007): every holding, lot and cash table here is the 49 Client Holding book. No table reads an 18
  Portfolio Holding or an 06 Fund Shareholder Position, and no relationship joins a 49 table to one. Own-Fund Client
  Holdings Market Value is the 49 view; the 06 position for brokerage accounts is a view of 49 and is not published.
- Client Holdings Market Value, Sweep Balances, Sweep Allocated Balance, Settled Inflow and Outflow Amount, Posted
  Activity Net Amount and Transfer Value are operational book values: never labeled or summed as Client Assets or Net
  New Assets, which are SM-20's and are referenced only (CW-011, CW-230). Nothing here touches Firm AUM.
- Snapshots: Client Holding pins the End of Day view; cash balances pin the Settlement Date basis; margin pins the End of
  Day snapshot; masters (venues, routing rules, programs, banks, participations, rate tiers) pin the version in force.
- Special category (CD-344): DP-302 publishes non-special holds only. Special-category and AML holds are filtered out at
  ingestion and must not be inferable; the access rules apply complementary suppression to hold and status cells.
"""

_IN_FORCE = "{p}effective_from <= :as_of_date and ({p}effective_to is null or {p}effective_to > :as_of_date)"
_EOD = ["client_holding_view = 'End of Day'"]
_SETTLED_BASIS = ["balance_basis = 'Settlement Date'"]
_PUBLISHED_HOLDS = ("hold_type in ('Funds Availability', 'Fraud', 'Legal Process', 'Sanctions', 'Deceased Owner') "
                    "and hold_reason is neither a special-category reason nor 'AML Investigation' (DP-302 DQ5)")
_ACCOUNT = "DP-093/Account"
_ACCOUNT_AS_OF = "and the client_account version in force on the row's date (DP-093 is SCD type 2)"

MODEL = dict(
    id="SM-24",
    status="Draft",
    description=(
        "Brokerage holdings and activity, client orders and execution quality, trade corrections and errors, money "
        "movement and holds, ACATS transfers, the cash sweep and program banks, and the customer reserve and "
        "possession-or-control control pack, for brokerage operations, the best-execution committee, money movement "
        "and fraud operations, cash programs and the Financial and Operations Principal. It answers questions across "
        "accounts, venues, programs, banks and days; a single account's activity is answered in the operational "
        "products. Client Assets and Net New Assets are read from SM-20 and never restated here."),
    questions=[
        "What was execution quality by venue and order type last month (price improvement, effective over quoted "
        "spread, Rule 605 and Rule 606), and how much order flow went to affiliated venues?",
        "Which client orders were corrected or busted, by correction type, reason, order source and venue, and what "
        "did trade errors cost the firm?",
        "What is today's customer reserve requirement, is a deposit due before the deadline, and which client "
        "securities are out of possession or control?",
        "How much money moved by rail and direction, what were the ACH return rates, and which non-special holds "
        "(fraud, funds availability, legal process, sanctions, deceased owner) are active or past expiry?",
        "How is swept cash allocated across program banks, how close is each bank to capacity, and what share of "
        "certified cash Client Assets sits at program banks?",
        "How many ACATS transfers came in and went out, how fast were they validated and settled, and what share of "
        "Net New Assets did transfers carry?",
    ],

    tables=[
        # ================= DP-300 Client Holdings, Lots & Cost Basis (49 Client Holding book) =====================
        dict(name="client_holding", product="DP-300", entity="Client Holding", kind="Fact",
             grain="client account x instrument x holding date (End of Day view), with its valuation",
             always_filter=_EOD,
             default_filter="client_holding_date = the latest business date",
             dimensions=[dict(name="holding_account", attr="Holding Account"),
                         dict(name="held_instrument", attr="Held Instrument"),
                         dict(name="client_holding_date", attr="Client Holding Date"),
                         dict(name="own_share_class_indicator", attr="Own Share Class Indicator"),
                         dict(name="valuation_currency", attr="Valuation Currency"),
                         dict(name="valuation_price_record", attr="Valuation Price Record")],
             facts=[dict(name="market_value_usd", attr="Market Value in USD"),
                    dict(name="trade_date_quantity", attr="Trade-Date Quantity"),
                    dict(name="settled_quantity", attr="Settled Quantity"),
                    dict(name="short_quantity", attr="Short Quantity"),
                    dict(name="segregated_quantity", attr="Segregated Quantity"),
                    dict(name="on_loan_quantity", attr="On-Loan Quantity"),
                    dict(name="total_cost_basis", attr="Total Cost Basis"),
                    dict(name="unrealized_gain_loss", attr="Unrealized Gain or Loss")],
             hidden=[("Client Holding View", "Pinned to End of Day in always_filter; intraday views would double count."),
                     ("Market Value", "Local-currency value; metrics read Market Value in USD so currencies never mix."),
                     ("Principal Control Location", "A possession-or-control input; the determination is DP-445's.")]),
        dict(name="client_tax_lot", product="DP-300", entity="Client Tax Lot", kind="Fact",
             grain="account x instrument x acquisition lot (current state)",
             dimensions=[dict(name="lot_account", attr="Lot Account"),
                         dict(name="lot_instrument", attr="Lot Instrument"),
                         dict(name="lot_acquisition_method", attr="Lot Acquisition Method"),
                         dict(name="covered_security_class", attr="Covered Security Class"),
                         dict(name="covered_security_indicator", attr="Covered Security Indicator"),
                         dict(name="noncovered_basis_source", attr="Noncovered Basis Source"),
                         dict(name="client_tax_lot_status", attr="Client Tax Lot Status")],
             facts=[dict(name="remaining_quantity", attr="Remaining Quantity"),
                    dict(name="adjusted_cost_basis", attr="Adjusted Cost Basis"),
                    dict(name="wash_sale_deferred_loss", attr="Wash Sale Deferred Loss")]),
        dict(name="lot_relief", product="DP-300", entity="Client Lot Relief", kind="Fact",
             grain="client tax lot x closing activity or closing register transaction",
             dimensions=[dict(name="relieved_client_tax_lot", attr="Relieved Client Tax Lot"),
                         dict(name="holding_period_term", attr="Holding Period Term"),
                         dict(name="form_1099b_reporting_category", attr="Form 1099-B Reporting Category"),
                         dict(name="relief_method_applied", attr="Relief Method Applied"),
                         dict(name="relief_method_source", attr="Relief Method Source")],
             facts=[dict(name="relieved_cost_basis", attr="Relieved Cost Basis"),
                    dict(name="relief_proceeds", attr="Relief Proceeds"),
                    dict(name="realized_gain_loss", attr="Realized Gain or Loss"),
                    dict(name="wash_sale_loss_disallowed", attr="Wash Sale Loss Disallowed")]),
        dict(name="account_activity", product="DP-300", entity="Client Account Activity", kind="Fact",
             grain="account x posting (CLACT-); append-only",
             always_filter=["reversed postings and their reversals both stay; metrics net them through Activity Net Amount"],
             dimensions=[dict(name="activity_account", attr="Activity Account"),
                         dict(name="activity_type", attr="Activity Type"),
                         dict(name="activity_status", attr="Activity Status"),
                         dict(name="activity_trade_date", attr="Trade Date"),
                         dict(name="activity_settlement_date", attr="Settlement Date"),
                         dict(name="activity_currency", attr="Activity Currency")],
             facts=[dict(name="activity_net_amount", attr="Activity Net Amount")],
             hidden=[("Source Fee Debit", "A billing key (DP-305); fee revenue is SM-28's.")]),
        dict(name="cash_balance", product="DP-300", entity="Cash Balance", kind="Fact",
             grain="account x currency x cash balance type x business date (settlement-date basis)",
             always_filter=_SETTLED_BASIS,
             default_filter="cash_balance_business_date = the latest business date",
             dimensions=[dict(name="cash_balance_account", attr="Cash Balance Account"),
                         dict(name="cash_balance_type", attr="Cash Balance Type"),
                         dict(name="cash_balance_currency", attr="Cash Balance Currency"),
                         dict(name="cash_balance_business_date", attr="Cash Balance Business Date"),
                         dict(name="balance_sweep_program", attr="Balance Sweep Program")],
             facts=[dict(name="cash_balance_amount", attr="Cash Balance Amount")],
             hidden=[("Balance Basis", "Pinned to Settlement Date, the book of record; the trade-date rows would double count.")]),
        dict(name="margin_snapshot", product="DP-300", entity="Margin Balance Snapshot", kind="Fact",
             grain="margin account x business date (End of Day snapshot)",
             always_filter=["margin_snapshot_type = 'End of Day'"],
             default_filter="margin_snapshot_business_date = the latest business date",
             dimensions=[dict(name="margin_snapshot_account", attr="Margin Snapshot Account"),
                         dict(name="margin_snapshot_business_date", attr="Margin Snapshot Business Date")],
             facts=[dict(name="margin_debit_balance", attr="Margin Debit Balance"),
                    dict(name="account_equity", attr="Account Equity"),
                    dict(name="maintenance_requirement", attr="Maintenance Requirement"),
                    dict(name="maintenance_excess_or_deficit", attr="Maintenance Excess or Deficit"),
                    dict(name="margin_interest_accrued", attr="Margin Interest Accrued")]),
        dict(name="ca_entitlement", product="DP-300", entity="Client Corporate Action Entitlement", kind="Fact",
             grain="corporate action event x account",
             dimensions=[dict(name="entitled_account", attr="Entitled Account"),
                         dict(name="entitlement_status", attr="Entitlement Status"),
                         dict(name="entitlement_payment_date", attr="Entitlement Payment Date")],
             facts=[dict(name="entitled_cash_amount", attr="Entitled Cash Amount")]),
        dict(name="securities_loan", product="DP-300", entity="Fully Paid Securities Loan", kind="Fact",
             grain="account x borrowing entity x instrument x loan",
             dimensions=[dict(name="lending_account", attr="Lending Account"),
                         dict(name="loaned_instrument", attr="Loaned Instrument"),
                         dict(name="borrowing_entity", attr="Borrowing Entity"),
                         dict(name="loan_status", attr="Loan Status")],
             facts=[dict(name="loan_quantity", attr="Loan Quantity"),
                    dict(name="collateral_amount", attr="Collateral Amount")]),

        # ================= DP-301 Client Orders & Executions (48) ==================================================
        dict(name="client_order", product="DP-301", entity="Client Order", kind="Fact",
             grain="client order (CLORD-; one account's order in one instrument)",
             dimensions=[dict(name="order_account", attr="Order Account"),
                         dict(name="order_instrument", attr="Order Instrument"),
                         dict(name="order_side", attr="Order Side"),
                         dict(name="order_source", attr="Order Source"),
                         dict(name="order_entry_channel", attr="Order Entry Channel"),
                         dict(name="solicited_indicator", attr="Solicited Indicator"),
                         dict(name="discretionary_order_indicator", attr="Discretionary Order Indicator"),
                         dict(name="order_received_timestamp", attr="Order Received Timestamp"),
                         dict(name="client_order_status", attr="Client Order Status"),
                         dict(name="order_rejection_reason", attr="Order Rejection Reason"),
                         dict(name="client_order_type", attr="Client Order Type"),
                         dict(name="time_in_force", attr="Time in Force"),
                         dict(name="trading_session", attr="Trading Session"),
                         dict(name="parent_client_block_order", attr="Parent Client Block Order"),
                         dict(name="executing_broker_dealer", attr="Executing Broker-Dealer")],
             facts=[dict(name="order_quantity", attr="Order Quantity"),
                    dict(name="order_notional_amount", attr="Order Notional Amount")],
             hidden=[("Entering Employee", "An employee key; trading analytics need the channel, not the person."),
                     ("Source Recommendation", "Advice evidence is SM-22's; carried as a key only."),
                     ("Limit Price", "Order instruction detail read by DP-436 and DP-435, not a cross-order measure.")]),
        dict(name="order_route", product="DP-301", entity="Order Route", kind="Fact",
             grain="client order or client block order x route sequence (ROUTE-)",
             dimensions=[dict(name="routed_client_order", attr="Routed Client Order"),
                         dict(name="routed_client_block_order", attr="Routed Client Block Order"),
                         dict(name="route_venue", attr="Route Venue"),
                         dict(name="applied_routing_rule", attr="Applied Routing Rule"),
                         dict(name="routing_decision_basis", attr="Routing Decision Basis"),
                         dict(name="routed_timestamp", attr="Routed Timestamp"),
                         dict(name="order_route_status", attr="Order Route Status")],
             facts=[dict(name="routed_quantity", attr="Routed Quantity")]),
        # The NBBO at route is held on DP-436's view of the same ROUTE- rows; one-to-one, quote columns only, so
        # Routed Quantity is read from order_route alone and never counted twice.
        dict(name="route_quote", product="DP-436", entity="Fact Order Route", kind="Fact",
             grain="order route (ROUTE-), with the NBBO at route",
             dimensions=[dict(name="quote_order_route_id", attr="Order Route ID")],
             facts=[dict(name="nbbo_bid_at_route", attr="NBBO Bid At Route"),
                    dict(name="nbbo_offer_at_route", attr="NBBO Offer At Route")],
             hidden=[("Routed Quantity", "Read from order_route (DP-301); a second copy would double count.")]),
        dict(name="client_execution", product="DP-301", entity="Client Execution", kind="Fact",
             grain="client execution (one fill on one order route; CLEXE-)",
             dimensions=[dict(name="execution_order_route", attr="Execution Order Route"),
                         dict(name="execution_trade_date", attr="Execution Trade Date"),
                         dict(name="execution_venue_mic", attr="Execution Venue MIC"),
                         dict(name="execution_capacity", attr="Execution Capacity"),
                         dict(name="execution_currency", attr="Execution Currency"),
                         dict(name="extended_hours_execution", attr="Extended-Hours Execution Indicator")],
             facts=[dict(name="executed_quantity", attr="Executed Quantity"),
                    dict(name="execution_price", attr="Execution Price"),
                    dict(name="price_improvement_per_share", attr="Price Improvement Per Share")]),
        dict(name="client_block_order", product="DP-301", entity="Client Block Order", kind="Fact",
             grain="client block order (CLBLK-)",
             dimensions=[dict(name="block_origin", attr="Block Origin"),
                         dict(name="block_created_timestamp", attr="Block Created Timestamp")],
             facts=[dict(name="aggregate_quantity", attr="Aggregate Quantity")],
             hidden=[("Block Advisor", "An employee key; not needed for cross-block questions.")]),
        dict(name="client_allocation", product="DP-301", entity="Client Allocation", kind="Fact",
             grain="client block order or client order x allocated account",
             dimensions=[dict(name="allocation_client_block_order", attr="Allocation Client Block Order"),
                         dict(name="allocated_client_order", attr="Allocated Client Order"),
                         dict(name="allocated_account", attr="Allocated Account"),
                         dict(name="allocation_timestamp", attr="Allocation Timestamp")],
             facts=[dict(name="allocated_quantity", attr="Allocated Quantity"),
                    dict(name="fractional_remainder_quantity", attr="Fractional Remainder Quantity")]),
        dict(name="trade_confirmation", product="DP-301", entity="Client Trade Confirmation", kind="Fact",
             grain="client allocation x confirmation version (CCONF-)",
             always_filter=["current version only for amounts: no later version names this one in Superseded "
                            "Confirmation (metrics that test versions read the history through trade_correction)"],
             dimensions=[dict(name="confirmation_type", attr="Confirmation Type"),
                         dict(name="confirmed_trade_date", attr="Confirmed Trade Date"),
                         dict(name="confirmed_capacity", attr="Confirmed Capacity"),
                         dict(name="confirmed_client_allocation", attr="Confirmed Client Allocation"),
                         dict(name="superseded_confirmation", attr="Superseded Confirmation"),
                         dict(name="originating_trade_correction", attr="Originating Trade Correction")],
             facts=[dict(name="confirmed_net_amount", attr="Net Amount"),
                    dict(name="commission_charged", attr="Commission Charged")]),

        # ================= DP-437 Trade Corrections & Errors (48) ===================================================
        # Trade Correction is read once, from DP-437, which adds Fields Corrected and Related Trade Error Case to the
        # 48 rows DP-301 publishes; the DP-301 correction metrics run on this table.
        dict(name="trade_correction", product="DP-437", entity="Fact Trade Correction", kind="Fact",
             grain="trade correction (TCORR-); append-only",
             dimensions=[dict(name="corrected_client_execution", attr="Corrected Client Execution"),
                         dict(name="corrected_client_allocation", attr="Corrected Client Allocation"),
                         dict(name="correction_type", attr="Correction Type"),
                         dict(name="trade_correction_reason", attr="Trade Correction Reason"),
                         dict(name="as_of_trade_indicator", attr="As-Of Trade Indicator"),
                         dict(name="resulting_confirmation", attr="Resulting Confirmation"),
                         dict(name="related_trade_error_case", attr="Related Trade Error Case")],
             hidden=[("Correction Approved By", "An employee key; Corrections Without Approver tests it for blank only."),
                     ("Fields Corrected", "Free-form detail of one correction; not a cross-row dimension.")]),
        dict(name="trade_error_case", product="DP-437", entity="Fact Trade Error Case", kind="Fact",
             grain="trade error case (case number); latest monthly snapshot of each case",
             default_filter="the latest monthly snapshot",
             dimensions=[dict(name="error_client_order", attr="Error Client Order"),
                         dict(name="error_client_block_order", attr="Error Client Block Order"),
                         dict(name="error_detected_date", attr="Error Detected Date"),
                         dict(name="trade_error_cause", attr="Trade Error Cause"),
                         dict(name="error_severity", attr="Error Severity"),
                         dict(name="error_account", attr="Error Account"),
                         dict(name="client_made_whole_indicator", attr="Client Made Whole Indicator"),
                         dict(name="related_loss_event", attr="Related Loss Event"),
                         dict(name="error_case_status", attr="Error Case Status")],
             facts=[dict(name="error_gain_or_loss_amount", attr="Error Gain or Loss Amount")],
             hidden=[("Missed Instruction Description", "Free text that can name the client; case detail stays in 48.")]),
        dict(name="loss_event", product="DP-437", entity="Operational Loss Event", kind="Dimension",
             dimensions=[dict(name="loss_event_id", attr="Loss Event ID"),
                         dict(name="loss_status", attr="Loss Status")],
             facts=[dict(name="loss_impact_amount", attr="Impact Amount",
                         note="Read only to tie trade error losses to 37; losses are booked and reported in 37 (DP-215).")]),

        # ================= DP-432 Execution Venues & Routing Rules ==================================================
        dict(name="execution_venue", product="DP-432", entity="Execution Venue", kind="Dimension",
             always_filter=[_IN_FORCE.format(p="venue_profile_")],
             dimensions=[dict(name="venue_party", attr="Venue Party"),
                         dict(name="venue_type", attr="Venue Type"),
                         dict(name="venue_mic", attr="Venue MIC"),
                         dict(name="rule_606_venue_name", attr="Rule 606 Venue Name"),
                         dict(name="affiliated_venue", attr="Affiliated Venue Indicator"),
                         dict(name="payment_for_order_flow", attr="Payment for Order Flow Indicator"),
                         dict(name="order_flow_payment_terms", attr="Order Flow Payment Terms"),
                         dict(name="venue_profile_status", attr="Venue Profile Status")]),
        dict(name="routing_rule", product="DP-432", entity="Routing Rule", kind="Dimension",
             always_filter=[_IN_FORCE.format(p="routing_rule_")],
             dimensions=[dict(name="routing_rule_code", attr="Routing Rule Code"),
                         dict(name="rule_instrument_class", attr="Rule Instrument Class"),
                         dict(name="rule_order_types", attr="Rule Order Types"),
                         dict(name="rule_trading_sessions", attr="Rule Trading Sessions"),
                         dict(name="primary_venue", attr="Primary Venue"),
                         dict(name="fallback_venues", attr="Fallback Venues"),
                         dict(name="approving_review", attr="Approving Review")]),
        # Rule 605 lines are read once, from DP-432, the foundation; DP-436's ratios run on this table.
        dict(name="rule_605_line", product="DP-432", entity="Rule 605 Report Line", kind="Fact",
             grain="reporting broker-dealer x report month x security x Rule 605 order type x size bucket",
             default_filter="rule_605_report_month = the latest published month",
             dimensions=[dict(name="rule_605_reporting_entity", attr="Rule 605 Reporting Entity"),
                         dict(name="rule_605_report_month", attr="Rule 605 Report Month"),
                         dict(name="rule_605_security", attr="Rule 605 Security"),
                         dict(name="rule_605_order_type", attr="Rule 605 Order Type"),
                         dict(name="rule_605_order_size_bucket", attr="Rule 605 Order Size Bucket"),
                         dict(name="rule_605_notional_size_range", attr="Rule 605 Notional Size Range")],
             facts=[dict(name="covered_order_count", attr="Covered Order Count"),
                    dict(name="covered_order_shares", attr="Covered Order Shares"),
                    dict(name="average_effective_spread", attr="Average Effective Spread"),
                    dict(name="price_improved_shares", attr="Price Improved Shares"),
                    dict(name="average_time_to_execution", attr="Average Time To Execution")]),

        # ================= DP-436 Execution Quality & Routing (605/606) =============================================
        dict(name="execution_quality", product="DP-436", entity="Fact Execution Quality Measure", kind="Fact",
             grain="measurement period x order class x client order type x venue (as 48 computes it)",
             default_filter="the latest measurement period",
             dimensions=[dict(name="measure_period_start", attr="Measure Period Start"),
                         dict(name="measure_period_end", attr="Measure Period End"),
                         dict(name="measure_order_class", attr="Measure Order Class"),
                         dict(name="measure_client_order_type", attr="Measure Client Order Type"),
                         dict(name="measured_venue", attr="Measured Venue"),
                         dict(name="reviewing_committee_review", attr="Reviewing Committee Review")],
             facts=[dict(name="measured_order_count", attr="Measured Order Count"),
                    dict(name="price_improvement_rate", attr="Price Improvement Rate"),
                    dict(name="average_price_improvement_per_share", attr="Average Price Improvement Per Share"),
                    dict(name="effective_over_quoted_spread", attr="Effective Over Quoted Spread")]),
        dict(name="rule_606_line", product="DP-436", entity="Fact Rule 606 Report Line", kind="Fact",
             grain="reporting broker-dealer x quarter x month x Rule 606 order class x venue",
             default_filter="rule_606_report_quarter = the latest published quarter",
             dimensions=[dict(name="rule_606_reporting_entity", attr="Rule 606 Reporting Entity"),
                         dict(name="rule_606_report_quarter", attr="Rule 606 Report Quarter"),
                         dict(name="rule_606_report_month", attr="Rule 606 Report Month"),
                         dict(name="rule_606_order_class", attr="Rule 606 Order Class"),
                         dict(name="rule_606_venue", attr="Rule 606 Venue"),
                         dict(name="non_directed_order_pct", attr="Non-Directed Order Percentage"),
                         dict(name="market_order_pct", attr="Market Order Percentage"),
                         dict(name="marketable_limit_order_pct", attr="Marketable Limit Order Percentage"),
                         dict(name="non_marketable_limit_order_pct", attr="Non-Marketable Limit Order Percentage"),
                         dict(name="other_order_pct", attr="Other Order Percentage"),
                         dict(name="material_aspects_discussion", attr="Material Aspects Discussion")],
             facts=[dict(name="net_order_flow_payment_amount", attr="Net Order Flow Payment Amount")]),
        dict(name="routing_disclosure_request", product="DP-436", entity="Fact Routing Disclosure Request", kind="Fact",
             grain="customer request under Rule 606(b)(1) or (b)(3)",
             dimensions=[dict(name="routing_disclosure_request_type", attr="Routing Disclosure Request Type"),
                         dict(name="request_received_date", attr="Request Received Date"),
                         dict(name="response_delivered_date", attr="Response Delivered Date")],
             hidden=[("Requesting Party", "The requesting customer (identity tier, DP-436 DQ5); counts need no name."),
                     ("Request Account", "Account key of the requester; not needed for the timeliness count.")]),
        dict(name="quote_observation", product="DP-436", entity="Fact Quote Observation", kind="Fact",
             grain="instrument x price type (Bid, Ask) x price origin x source x as-of timestamp (22 consolidated feed)",
             always_filter=["observed_price_type in ('Bid', 'Ask')",
                            "observation_price_origin = 'Composite / Consolidated Price'"],
             dimensions=[dict(name="observed_instrument", attr="Observed Instrument"),
                         dict(name="observed_price_type", attr="Observed Price Type"),
                         dict(name="observation_as_of_timestamp", attr="Observation As-Of Timestamp")],
             facts=[dict(name="observed_price_value", attr="Observed Price Value")]),
        dict(name="committee_review", product="DP-436", entity="Committee Review", kind="Dimension",
             always_filter=["supervisory_review_type = the best-execution review type"],
             dimensions=[dict(name="supervisory_review_id", attr="Supervisory Review ID"),
                         dict(name="reviewed_routing_rule", attr="Reviewed Routing Rule"),
                         dict(name="reviewed_execution_venue", attr="Reviewed Execution Venue"),
                         dict(name="review_completed_date", attr="Review Completed Date"),
                         dict(name="review_outcome", attr="Review Outcome")]),

        # ================= DP-302 Money Movement Transactions (50) =================================================
        dict(name="money_movement", product="DP-302", entity="Money Movement", kind="Fact",
             grain="money movement (MMVMT-), with its rail detail",
             always_filter=["money_movement_status is the published status: for a movement held only under a "
                            "suppressed hold, the status before the hold (DP-302 DQ5)"],
             dimensions=[dict(name="movement_account", attr="Movement Account"),
                         dict(name="money_movement_type", attr="Money Movement Type"),
                         dict(name="payment_rail", attr="Payment Rail"),
                         dict(name="movement_direction", attr="Movement Direction"),
                         dict(name="movement_currency", attr="Movement Currency"),
                         dict(name="requested_date", attr="Requested Date"),
                         dict(name="value_date", attr="Value Date"),
                         dict(name="initiation_channel", attr="Initiation Channel"),
                         dict(name="movement_source_type", attr="Movement Source Type"),
                         dict(name="third_party_indicator", attr="Third-Party Indicator"),
                         dict(name="money_movement_status", attr="Money Movement Status"),
                         dict(name="bank_instruction_used", attr="Bank Instruction Used"),
                         dict(name="standard_entry_class_code", attr="Standard Entry Class Code"),
                         dict(name="same_day_ach", attr="Same Day ACH Indicator"),
                         dict(name="travel_rule_record_complete", attr="Travel Rule Record Complete Indicator"),
                         dict(name="redeeming_fund_order", attr="Redeeming Fund Order"),
                         dict(name="same_owner_indicator", attr="Same Owner Indicator"),
                         dict(name="retirement_tax_coding", attr="Retirement Tax Coding"),
                         dict(name="journal_approval_status", attr="Journal Approval Status"),
                         dict(name="card_settlement_date", attr="Card Settlement Date"),
                         dict(name="atm_indicator", attr="ATM Indicator"),
                         dict(name="foreign_transaction_indicator", attr="Foreign Transaction Indicator")],
             facts=[dict(name="movement_amount", attr="Movement Amount"),
                    dict(name="exchange_rate_applied", attr="Exchange Rate Applied")],
             hidden=[("Initiating Party", "Personal data (financial tier); the channel answers cross-row questions."),
                     ("ACH Trace Number", "Payment identifier; operational lookup only."),
                     ("IMAD", "Payment identifier; operational lookup only."),
                     ("UETR", "Payment identifier; operational lookup only."),
                     ("Beneficiary Bank Identifier", "Restricted column (DP-302 masks it)."),
                     ("Check Number", "Payment identifier; operational lookup only."),
                     ("Destination Account", "Counterparty account of an internal journal; personal data."),
                     ("Transaction Debit Card", "Card key; card analytics and Regulation E are DP-459's."),
                     ("Merchant Category Code", "Card spending detail; not needed for the card totals."),
                     ("Drawn-On Program Bank", "Program bank of a check draft; sweep balances are read from sweep_allocation.")]),
        dict(name="movement_event", product="DP-302", entity="Money Movement Event", kind="Fact",
             grain="money movement x event sequence",
             always_filter=["the Held and Released events of a movement held only under a suppressed hold are omitted "
                            "(DP-302 DQ5)"],
             dimensions=[dict(name="event_movement", attr="Event Movement"),
                         dict(name="money_movement_event_type", attr="Money Movement Event Type"),
                         dict(name="event_timestamp", attr="Event Timestamp")]),
        dict(name="movement_return", product="DP-302", entity="Money Movement Return", kind="Fact",
             grain="money movement x return sequence",
             dimensions=[dict(name="returned_movement", attr="Returned Movement"),
                         dict(name="return_type", attr="Return Type"),
                         dict(name="return_reason_code", attr="Return Reason Code"),
                         dict(name="return_received_date", attr="Return Received Date"),
                         dict(name="unauthorized_return_indicator", attr="Unauthorized Return Indicator")]),
        dict(name="movement_exception", product="DP-302", entity="Money Movement Exception", kind="Fact",
             grain="money movement x exception sequence",
             dimensions=[dict(name="exception_movement", attr="Exception Movement"),
                         dict(name="exception_type", attr="Exception Type"),
                         dict(name="exception_raised_date", attr="Exception Raised Date"),
                         dict(name="exception_status", attr="Exception Status")]),
        # Non-special holds only (DP-302 DQ5). The special-category holds (CD-344) live in the restricted DP-322 and
        # DP-403 views (SM-29) and the AML holds in DP-226; none of them is a table here.
        dict(name="movement_hold", product="DP-302", entity="Money Movement Hold", kind="Fact",
             grain="money movement hold (MMHLD-), published hold types only",
             always_filter=[_PUBLISHED_HOLDS],
             dimensions=[dict(name="held_movement", attr="Held Movement"),
                         dict(name="hold_type", attr="Hold Type"),
                         dict(name="hold_reason", attr="Hold Reason"),
                         dict(name="hold_status", attr="Hold Status"),
                         dict(name="hold_placed_date", attr="Hold Placed Date"),
                         dict(name="hold_expiry_date", attr="Hold Expiry Date"),
                         dict(name="hold_released_date", attr="Hold Released Date")]),
        dict(name="fraud_assessment", product="DP-302", entity="Fraud Risk Assessment", kind="Fact",
             grain="money movement x assessment timestamp",
             always_filter=["resulting_hold is blank unless it names a published hold (DP-302 DQ5)"],
             dimensions=[dict(name="assessed_movement", attr="Assessed Movement"),
                         dict(name="assessment_timestamp", attr="Assessment Timestamp"),
                         dict(name="fraud_model", attr="Fraud Model"),
                         dict(name="fraud_decision", attr="Fraud Decision"),
                         dict(name="resulting_hold", attr="Resulting Hold"),
                         dict(name="confirmed_fraud_indicator", attr="Confirmed Fraud Indicator")],
             facts=[dict(name="fraud_risk_score", attr="Fraud Risk Score")]),
        dict(name="monitoring_alert", product="DP-302", entity="Money Movement Monitoring Alert", kind="Fact",
             grain="money movement monitoring alert (MMALT-), non-special scenarios only",
             always_filter=["monitoring_scenario <> 'Elder Exploitation Pattern' (DP-302 DQ5)",
                            "alert_disposition published as escalated or closed only"],
             dimensions=[dict(name="monitoring_scenario", attr="Monitoring Scenario"),
                         dict(name="alert_generated_timestamp", attr="Alert Generated Timestamp"),
                         dict(name="alert_status", attr="Alert Status"),
                         dict(name="alert_disposition", attr="Alert Disposition")],
             hidden=[("Alert Accounts", "Many-to-many account list; alert counts are published by scenario only."),
                     ("Movements in Scope", "Many-to-many movement list; joining it would repeat each alert.")]),
        # Sweep Allocation is read once, from DP-302; DP-457's allocation metrics run on this table.
        dict(name="sweep_allocation", product="DP-302", entity="Sweep Allocation", kind="Fact",
             grain="account x program bank x business date (daily snapshot)",
             default_filter="allocation_business_date = the latest business date",
             dimensions=[dict(name="allocation_account", attr="Allocation Account"),
                         dict(name="allocation_program_bank", attr="Allocation Program Bank"),
                         dict(name="allocation_business_date", attr="Allocation Business Date"),
                         dict(name="bank_exclusion_applied", attr="Bank Exclusion Applied")],
             facts=[dict(name="allocated_balance", attr="Allocated Balance"),
                    dict(name="interest_accrued_amount", attr="Interest Accrued Amount")]),
        dict(name="bank_instruction", product="DP-093", entity="Bank Instruction", kind="Dimension",
             always_filter=["the bank instruction version in force on the movement's Requested Date"],
             dimensions=[dict(name="bank_instruction_id", attr="Bank Instruction ID"),
                         dict(name="bank_verification_status", attr="Bank Verification Status"),
                         dict(name="third_party_bank_indicator", attr="Third-Party Bank Indicator")]),

        # ================= DP-431 Sweep Programs & Program Banks (50) ==============================================
        dict(name="sweep_program", product="DP-431", entity="Sweep Program", kind="Dimension",
             always_filter=["the Sweep Program version in force on :as_of_date (SCD type 2)"],
             dimensions=[dict(name="sweep_program_id", attr="Sweep Program ID"),
                         dict(name="sweep_program_name", attr="Sweep Program Name"),
                         dict(name="sweep_program_type", attr="Sweep Program Type"),
                         dict(name="sponsoring_broker_dealer", attr="Sponsoring Broker-Dealer"),
                         dict(name="program_status", attr="Program Status"),
                         dict(name="program_effective_from", attr="Program Effective From"),
                         dict(name="program_change_notice_date", attr="Program Change Notice Date"),
                         dict(name="program_change_effective_date", attr="Program Change Effective Date")],
             facts=[dict(name="maximum_program_insured_coverage", attr="Maximum Program Insured Coverage")]),
        dict(name="program_bank", product="DP-431", entity="Program Bank", kind="Dimension",
             always_filter=["the Program Bank role period in force on :as_of_date"],
             dimensions=[dict(name="program_bank_id", attr="Program Bank ID"),
                         dict(name="bank_party", attr="Bank Party"),
                         dict(name="fdic_certificate_number", attr="FDIC Certificate Number"),
                         dict(name="bank_charter_type", attr="Bank Charter Type"),
                         dict(name="program_bank_status", attr="Program Bank Status"),
                         dict(name="bank_approval_status", attr="Bank Approval Status"),
                         dict(name="bank_onboarding_date", attr="Bank Onboarding Date"),
                         dict(name="bank_exit_date", attr="Bank Exit Date")],
             hidden=[("Bank Approved By", "An employee key; the approval status answers the control question.")]),
        dict(name="participation", product="DP-431", entity="Program Bank Participation", kind="Bridge",
             grain="sweep program x program bank x effective period (in force on the date)",
             always_filter=[_IN_FORCE.format(p="participation_")],
             dimensions=[dict(name="participation_sweep_program", attr="Participation Sweep Program"),
                         dict(name="participating_program_bank", attr="Participating Program Bank"),
                         dict(name="allocation_priority", attr="Allocation Priority"),
                         dict(name="program_bank_agreement", attr="Program Bank Agreement"),
                         dict(name="primary_purpose_exception_basis", attr="Primary Purpose Exception Basis"),
                         dict(name="exception_notice_filed_date", attr="Exception Notice Filed Date")],
             facts=[dict(name="bank_capacity_amount", attr="Bank Capacity Amount")],
             hidden=[("Omnibus Account Titling", "Account titling text; not a cross-row dimension."),
                     ("Bank Rate Formula", "Contract term; program economics are SM-28's (DP-012).")]),
        dict(name="rate_tier", product="DP-431", entity="Sweep Rate Tier", kind="Dimension",
             always_filter=[_IN_FORCE.format(p="tier_")],
             dimensions=[dict(name="tier_sweep_program", attr="Tier Sweep Program"),
                         dict(name="rate_tier_basis", attr="Rate Tier Basis"),
                         dict(name="tier_lower_bound", attr="Tier Lower Bound"),
                         dict(name="tier_upper_bound", attr="Tier Upper Bound"),
                         dict(name="client_interest_rate", attr="Client Interest Rate")]),
        # Program Bank Daily Total is read once, from DP-431; DP-457's capacity metric runs on this table.
        dict(name="program_bank_daily", product="DP-431", entity="Program Bank Daily Total", kind="Fact",
             grain="sweep program x program bank x business date",
             default_filter="daily_total_business_date = the latest business date",
             dimensions=[dict(name="daily_total_sweep_program", attr="Daily Total Sweep Program"),
                         dict(name="daily_total_program_bank", attr="Daily Total Program Bank"),
                         dict(name="daily_total_business_date", attr="Daily Total Business Date")],
             facts=[dict(name="aggregate_customer_deposits", attr="Aggregate Customer Deposits"),
                    dict(name="net_flow_amount", attr="Net Flow Amount"),
                    dict(name="interest_paid_by_bank", attr="Interest Paid by Bank")]),
        # FDIC Coverage Assessment is read once, from DP-431. Party-level rows are personal data (financial tier):
        # the party key is hidden from every role except client service (DP-457).
        dict(name="fdic_assessment", product="DP-431", entity="FDIC Coverage Assessment", kind="Fact",
             grain="party x FDIC ownership category x program bank x assessment date",
             default_filter="assessment_date = the latest assessment date",
             dimensions=[dict(name="assessed_party", attr="Assessed Party"),
                         dict(name="fdic_ownership_category", attr="FDIC Ownership Category"),
                         dict(name="assessed_program_bank", attr="Assessed Program Bank"),
                         dict(name="assessment_date", attr="Assessment Date"),
                         dict(name="pass_through_recordkeeping_basis", attr="Pass-Through Recordkeeping Basis")],
             facts=[dict(name="deposits_through_firm", attr="Deposits Through Firm"),
                    dict(name="client_declared_direct_deposits", attr="Client-Declared Direct Deposits"),
                    dict(name="insured_amount", attr="Insured Amount"),
                    dict(name="uninsured_amount", attr="Uninsured Amount")],
             hidden=[("Accounts Assessed", "Many-to-many account list; joining it would repeat each assessment.")]),

        # ================= DP-457 Cash Sweep & Program Bank Allocation ==============================================
        dict(name="sweep_run", product="DP-457", entity="Fact Sweep Run", kind="Fact",
             grain="sweep program x business date x run cycle",
             dimensions=[dict(name="run_sweep_program", attr="Run Sweep Program"),
                         dict(name="run_business_date", attr="Run Business Date"),
                         dict(name="run_cycle_number", attr="Run Cycle Number"),
                         dict(name="sweep_run_status", attr="Sweep Run Status")],
             facts=[dict(name="net_sweep_amount", attr="Net Sweep Amount")]),
        dict(name="cash_forecast", product="DP-457", entity="Client Cash Forecast", kind="Dimension",
             dimensions=[dict(name="client_cash_forecast_id", attr="Client Cash Forecast ID"),
                         dict(name="forecast_as_of_date", attr="Forecast As-Of Date"),
                         dict(name="forecast_approval_status", attr="Forecast Approval Status")]),
        dict(name="cash_forecast_line", product="DP-457", entity="Fact Client Cash Forecast Line", kind="Fact",
             grain="client cash forecast x value date x cash flow category x sweep program",
             always_filter=["line_client_cash_forecast = the latest approved forecast (Forecast Approval Status = "
                            "'Approved', latest Forecast As-Of Date before the value date); earlier forecasts of the "
                            "same value date would double count"],
             dimensions=[dict(name="line_client_cash_forecast", attr="Line Client Cash Forecast"),
                         dict(name="line_value_date", attr="Line Value Date"),
                         dict(name="line_cash_flow_category", attr="Line Cash Flow Category"),
                         dict(name="line_sweep_program", attr="Line Sweep Program"),
                         dict(name="line_data_basis", attr="Line Data Basis")],
             facts=[dict(name="expected_inflow_amount", attr="Expected Inflow Amount"),
                    dict(name="expected_outflow_amount", attr="Expected Outflow Amount")]),
        # Read through DP-457, whose conformed view of the DP-093 election carries Excluded Program Banks.
        dict(name="sweep_election", product="DP-457", entity="Cash Sweep Election", kind="Dimension",
             always_filter=[_IN_FORCE.format(p="sweep_election_")],
             dimensions=[dict(name="sweep_election_account", attr="Sweep Election Account"),
                         dict(name="sweep_vehicle_type", attr="Sweep Vehicle Type"),
                         dict(name="elected_sweep_program", attr="Elected Sweep Program"),
                         dict(name="excluded_program_banks", attr="Excluded Program Banks")]),

        # ================= DP-448 ACATS In and Out (49) ============================================================
        # Account Transfer and Cost Basis Transfer Statement are read once, from DP-448, which adds the reject
        # reason, debit balance and originating request to the 49 rows DP-300 publishes; DP-300's transfer metrics
        # run on these tables.
        dict(name="account_transfer", product="DP-448", entity="Fact Account Transfer", kind="Fact",
             grain="account transfer (ACXF-), ACATS or non-ACATS; current state",
             dimensions=[dict(name="transfer_account", attr="Transfer Account"),
                         dict(name="transfer_direction", attr="Transfer Direction"),
                         dict(name="transfer_channel", attr="Transfer Channel"),
                         dict(name="contra_firm", attr="Contra Firm"),
                         dict(name="validation_date", attr="Validation Date"),
                         dict(name="transfer_settlement_date", attr="Transfer Settlement Date"),
                         dict(name="transfer_reject_reason", attr="Transfer Reject Reason"),
                         dict(name="transfer_status", attr="Transfer Status"),
                         dict(name="originating_service_request", attr="Originating Service Request")],
             facts=[dict(name="debit_balance_transferred", attr="Debit Balance Transferred")],
             hidden=[("ACATS Control Number", "Transfer identifier; operational lookup only.")]),
        dict(name="transfer_asset_line", product="DP-448", entity="Fact Account Transfer Asset Line", kind="Fact",
             grain="account transfer x asset line sequence",
             dimensions=[dict(name="line_account_transfer", attr="Line Account Transfer"),
                         dict(name="transfer_asset_instrument", attr="Transfer Asset Instrument"),
                         dict(name="non_transferable_reason", attr="Non-Transferable Reason"),
                         dict(name="line_cost_basis_transfer_statement", attr="Line Cost Basis Transfer Statement"),
                         dict(name="resulting_activity", attr="Resulting Activity")],
             facts=[dict(name="transfer_asset_quantity", attr="Transfer Asset Quantity"),
                    dict(name="transfer_cash_amount", attr="Transfer Cash Amount")]),
        dict(name="cost_basis_statement", product="DP-448", entity="Fact Cost Basis Transfer Statement", kind="Fact",
             grain="account transfer x statement direction x statement version (IRC section 6045A)",
             dimensions=[dict(name="statement_account_transfer", attr="Statement Account Transfer"),
                         dict(name="transfer_statement_direction", attr="Transfer Statement Direction"),
                         dict(name="statement_version", attr="Statement Version"),
                         dict(name="statement_counterparty_firm", attr="Statement Counterparty Firm"),
                         dict(name="statement_due_date", attr="Statement Due Date"),
                         dict(name="statement_sent_or_received_date", attr="Statement Sent or Received Date"),
                         dict(name="noncovered_security_notice", attr="Noncovered Security Notice Indicator")]),
        # The originating request's Received Timestamp, conformed in DP-448 from DP-381 (SM-25 owns the requests).
        dict(name="transfer_request", product="DP-448", entity="Service Request", kind="Dimension",
             dimensions=[dict(name="service_request_id", attr="Service Request ID"),
                         dict(name="request_type", attr="Request Type"),
                         dict(name="received_timestamp", attr="Received Timestamp")]),
        dict(name="transfer_price", product="DP-448", entity="Approved Price", kind="Dimension",
             always_filter=["price_approval_status = 'Approved'",
                            "approved_pricing_point = the brokerage pricing point; highest Approved Price Version"],
             dimensions=[dict(name="priced_instrument", attr="Priced Instrument"),
                         dict(name="price_date", attr="Price Date")],
             facts=[dict(name="approved_price_value", attr="Approved Price Value")]),

        # ================= DP-445 Customer Reserve & Possession-and-Control =======================================
        dict(name="reserve_computation", product="DP-445", entity="Fact Reserve Computation", kind="Fact",
             grain="computing broker-dealer x computation date x Reserve Computation Type (Customer, PAB)",
             default_filter="computation_date = the latest computation date",
             dimensions=[dict(name="computing_broker_dealer", attr="Computing Broker-Dealer"),
                         dict(name="reserve_computation_type", attr="Reserve Computation Type"),
                         dict(name="computation_date", attr="Computation Date"),
                         dict(name="reserve_computation_frequency", attr="Reserve Computation Frequency"),
                         dict(name="deposit_deadline_timestamp", attr="Deposit Deadline Timestamp"),
                         dict(name="computation_approval_status", attr="Computation Approval Status")],
             facts=[dict(name="average_total_credits", attr="Average Total Credits"),
                    dict(name="total_credits", attr="Total Credits"),
                    dict(name="total_debits", attr="Total Debits"),
                    dict(name="aggregate_debit_items_amount", attr="Aggregate Debit Items Amount"),
                    dict(name="debit_items_reduction_pct", attr="Debit Items Reduction Percentage"),
                    dict(name="reserve_requirement_amount", attr="Reserve Requirement Amount"),
                    dict(name="deposit_or_withdrawal_amount", attr="Deposit or Withdrawal Amount")],
             hidden=[("Reserve Bank Accounts", "Many-to-many list of reserve bank accounts; read through reserve_bank_account.")]),
        dict(name="reserve_line", product="DP-445", entity="Fact Reserve Computation Line", kind="Fact",
             grain="reserve computation x Exhibit A formula item",
             dimensions=[dict(name="line_reserve_computation", attr="Line Reserve Computation"),
                         dict(name="exhibit_a_formula_item", attr="Exhibit A Formula Item"),
                         dict(name="supporting_cash_balance_type", attr="Supporting Cash Balance Type")],
             facts=[dict(name="line_amount", attr="Line Amount")]),
        dict(name="reserve_bank_account", product="DP-445", entity="Reserve Bank Account", kind="Dimension",
             always_filter=["bank_account_status = active"],
             dimensions=[dict(name="corporate_bank_account_id", attr="Corporate Bank Account ID"),
                         dict(name="account_holder_entity", attr="Account Holder Entity"),
                         dict(name="bank_account_status", attr="Bank Account Status")]),
        dict(name="capital_calculation", product="DP-445", entity="Fact Capital Requirement Calculation", kind="Fact",
             grain="legal entity x capital regime x as-of date x version (43), the approved version only",
             always_filter=["calculation_approval_status = 'Approved'"],
             dimensions=[dict(name="calculation_entity", attr="Calculation Entity"),
                         dict(name="calculation_as_of_date", attr="Calculation As-Of Date"),
                         dict(name="capital_reserve_computation", attr="Reserve Computation")],
             facts=[dict(name="capital_aggregate_debit_items", attr="Aggregate Debit Items Amount",
                         note="43's Derived copy, read only for the tie to the 49 figure (CW-103); net capital is SM-14's.")]),
        dict(name="possession_control", product="DP-445", entity="Fact Possession or Control Determination", kind="Fact",
             grain="instrument x business date x deficit source",
             default_filter="determination_business_date = the latest business date",
             dimensions=[dict(name="determination_instrument", attr="Determination Instrument"),
                         dict(name="determination_business_date", attr="Determination Business Date"),
                         dict(name="deficit_source", attr="Deficit Source"),
                         dict(name="deficit_age_days", attr="Deficit Age Days"),
                         dict(name="action_deadline_date", attr="Action Deadline Date")],
             facts=[dict(name="fully_paid_quantity_required", attr="Fully Paid Quantity Required"),
                    dict(name="excess_margin_quantity_required", attr="Excess Margin Quantity Required"),
                    dict(name="quantity_at_good_control_locations", attr="Quantity at Good Control Locations"),
                    dict(name="deficit_quantity", attr="Possession or Control Deficit Quantity")],
             hidden=[("Control Locations Counted", "Many-to-many location list; read through control_location.")]),
        dict(name="control_location", product="DP-445", entity="Control Location", kind="Dimension",
             dimensions=[dict(name="control_location_party", attr="Control Location Party"),
                         dict(name="control_location_type", attr="Control Location Type"),
                         dict(name="location_country", attr="Location Country"),
                         dict(name="control_location_approval_status", attr="Control Location Approval Status"),
                         dict(name="location_effective_from", attr="Location Effective From"),
                         dict(name="location_effective_to", attr="Location Effective To")]),
    ],

    shared=[_ACCOUNT, "DP-240/Party", "DP-097/Instrument", "DP-013/Calendar Date", "DP-013/Internal Legal Entity"],

    relationships=[
        # --- 49 book: every holding, lot, cash and activity table joins the client account and instrument only -------
        dict(frm="client_holding", to=_ACCOUNT,
             on=f"client_holding.holding_account = client_account.account_id {_ACCOUNT_AS_OF}", type="many-to-one"),
        dict(frm="client_holding", to="DP-097/Instrument", on="client_holding.held_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="client_holding", to="DP-013/Calendar Date",
             on="client_holding.client_holding_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="client_tax_lot", to=_ACCOUNT, on=f"client_tax_lot.lot_account = client_account.account_id "
             "and the current client_account version", type="many-to-one"),
        dict(frm="client_tax_lot", to="DP-097/Instrument", on="client_tax_lot.lot_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="lot_relief", to="client_tax_lot",
             on="lot_relief.relieved_client_tax_lot = client_tax_lot.client_tax_lot_id", type="many-to-one"),
        dict(frm="account_activity", to=_ACCOUNT,
             on=f"account_activity.activity_account = client_account.account_id {_ACCOUNT_AS_OF}", type="many-to-one"),
        dict(frm="account_activity", to="DP-013/Calendar Date",
             on="account_activity.activity_trade_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="cash_balance", to=_ACCOUNT,
             on=f"cash_balance.cash_balance_account = client_account.account_id {_ACCOUNT_AS_OF}", type="many-to-one"),
        dict(frm="cash_balance", to="sweep_program",
             on="cash_balance.balance_sweep_program = sweep_program.sweep_program_id", type="many-to-one"),
        dict(frm="margin_snapshot", to=_ACCOUNT,
             on=f"margin_snapshot.margin_snapshot_account = client_account.account_id {_ACCOUNT_AS_OF}",
             type="many-to-one"),
        dict(frm="ca_entitlement", to=_ACCOUNT,
             on=f"ca_entitlement.entitled_account = client_account.account_id {_ACCOUNT_AS_OF}", type="many-to-one"),
        dict(frm="securities_loan", to=_ACCOUNT,
             on=f"securities_loan.lending_account = client_account.account_id {_ACCOUNT_AS_OF}", type="many-to-one"),
        dict(frm="securities_loan", to="DP-013/Internal Legal Entity",
             on="securities_loan.borrowing_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        # --- 48 orders, routes, executions, allocations, confirmations ----------------------------------------------
        dict(frm="client_order", to=_ACCOUNT,
             on="client_order.order_account = client_account.account_id and the client_account version in force on "
                "the order's received date", type="many-to-one"),
        dict(frm="client_order", to="DP-097/Instrument", on="client_order.order_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="client_order", to="client_block_order",
             on="client_order.parent_client_block_order = client_block_order.client_block_order_id", type="many-to-one"),
        dict(frm="order_route", to="client_order", on="order_route.routed_client_order = client_order.client_order_id",
             type="many-to-one"),
        dict(frm="order_route", to="client_block_order",
             on="order_route.routed_client_block_order = client_block_order.client_block_order_id", type="many-to-one"),
        dict(frm="order_route", to="execution_venue",
             on="order_route.route_venue = execution_venue.venue_party (profile in force on the routed date)",
             type="many-to-one"),
        dict(frm="order_route", to="routing_rule",
             on="order_route.applied_routing_rule = routing_rule.routing_rule_code (version in force on the routed date)",
             type="many-to-one"),
        dict(frm="route_quote", to="order_route", on="route_quote.quote_order_route_id = order_route.order_route_id",
             type="one-to-one"),
        dict(frm="client_execution", to="order_route",
             on="client_execution.execution_order_route = order_route.order_route_id", type="many-to-one"),
        dict(frm="client_execution", to="DP-013/Calendar Date",
             on="client_execution.execution_trade_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="client_allocation", to="client_order",
             on="client_allocation.allocated_client_order = client_order.client_order_id", type="many-to-one"),
        dict(frm="client_allocation", to="client_block_order",
             on="client_allocation.allocation_client_block_order = client_block_order.client_block_order_id",
             type="many-to-one"),
        dict(frm="trade_confirmation", to="client_allocation",
             on="trade_confirmation.confirmed_client_allocation = the client_allocation identified by its block order "
                "or client order and allocated account (Client Allocation has no identifier; DP-301 taxonomy gap)",
             type="many-to-one"),
        # --- 48 corrections and errors (DP-437) ---------------------------------------------------------------------
        dict(frm="trade_correction", to="client_execution",
             on="trade_correction.corrected_client_execution = client_execution.client_execution_id", type="many-to-one"),
        dict(frm="trade_correction", to="client_allocation",
             on="trade_correction.corrected_client_allocation = the client_allocation it names", type="many-to-one"),
        dict(frm="trade_correction", to="trade_confirmation",
             on="trade_correction.resulting_confirmation = trade_confirmation.client_trade_confirmation_id",
             type="many-to-one"),
        dict(frm="trade_correction", to="trade_error_case",
             on="trade_correction.related_trade_error_case = trade_error_case.trade_error_case_number",
             type="many-to-one"),
        dict(frm="trade_error_case", to="client_order",
             on="trade_error_case.error_client_order = client_order.client_order_id", type="many-to-one"),
        dict(frm="trade_error_case", to="loss_event", on="trade_error_case.related_loss_event = loss_event.loss_event_id",
             type="many-to-one"),
        # --- venues, routing rules, execution quality, Rules 605 and 606 -------------------------------------------
        dict(frm="execution_venue", to="DP-240/Party", on="execution_venue.venue_party = party.party_id",
             type="many-to-one"),
        dict(frm="routing_rule", to="execution_venue",
             on="routing_rule.primary_venue = execution_venue.venue_party", type="many-to-one"),
        dict(frm="routing_rule", to="committee_review",
             on="routing_rule.approving_review = committee_review.supervisory_review_id", type="many-to-one"),
        dict(frm="rule_605_line", to="DP-013/Internal Legal Entity",
             on="rule_605_line.rule_605_reporting_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="rule_605_line", to="DP-097/Instrument", on="rule_605_line.rule_605_security = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="execution_quality", to="execution_venue",
             on="execution_quality.measured_venue = execution_venue.venue_party (profile in force at the period end)",
             type="many-to-one"),
        dict(frm="execution_quality", to="committee_review",
             on="execution_quality.reviewing_committee_review = committee_review.supervisory_review_id",
             type="many-to-one"),
        dict(frm="rule_606_line", to="execution_venue",
             on="rule_606_line.rule_606_venue = execution_venue.venue_party (profile in force at the quarter end)",
             type="many-to-one"),
        dict(frm="rule_606_line", to="DP-013/Internal Legal Entity",
             on="rule_606_line.rule_606_reporting_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="quote_observation", to="DP-097/Instrument",
             on="quote_observation.observed_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="route_quote", to="quote_observation",
             on="the order's instrument = quote_observation.observed_instrument and observation_as_of_timestamp within "
                "one second before order_route.routed_timestamp (latest Bid and latest Ask)", type="many-to-many",
             warning="Several observations can fall in the one-second window; take the latest Bid and the latest Ask "
                     "per route, or the quote counts repeat each route."),
        # --- 50 money movement ----------------------------------------------------------------------------------------
        dict(frm="money_movement", to=_ACCOUNT,
             on="money_movement.movement_account = client_account.account_id and the client_account version in force "
                "on the requested date", type="many-to-one"),
        dict(frm="money_movement", to="DP-013/Calendar Date",
             on="money_movement.value_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="money_movement", to="bank_instruction",
             on="money_movement.bank_instruction_used = bank_instruction.bank_instruction_id", type="many-to-one"),
        dict(frm="movement_event", to="money_movement", on="movement_event.event_movement = money_movement.money_movement_id",
             type="many-to-one"),
        dict(frm="movement_return", to="money_movement",
             on="movement_return.returned_movement = money_movement.money_movement_id", type="many-to-one"),
        dict(frm="movement_exception", to="money_movement",
             on="movement_exception.exception_movement = money_movement.money_movement_id", type="many-to-one"),
        dict(frm="movement_hold", to="money_movement", on="movement_hold.held_movement = money_movement.money_movement_id",
             type="many-to-one",
             warning="A movement can carry more than one published hold; Held Amount counts each held movement once "
                     "(distinct Held Movement), never once per hold."),
        dict(frm="fraud_assessment", to="money_movement",
             on="fraud_assessment.assessed_movement = money_movement.money_movement_id", type="many-to-one"),
        dict(frm="fraud_assessment", to="movement_hold",
             on="fraud_assessment.resulting_hold = movement_hold.money_movement_hold_id", type="many-to-one"),
        dict(frm="sweep_allocation", to=_ACCOUNT,
             on=f"sweep_allocation.allocation_account = client_account.account_id {_ACCOUNT_AS_OF}", type="many-to-one"),
        dict(frm="sweep_allocation", to="program_bank",
             on="sweep_allocation.allocation_program_bank = program_bank.program_bank_id", type="many-to-one"),
        dict(frm="sweep_allocation", to="sweep_election",
             on="sweep_allocation.allocation_account = sweep_election.sweep_election_account (election in force on the "
                "business date)", type="many-to-many",
             warning="An account can hold more than one election row in force (one per vehicle type); count allocations "
                     "distinct by account, bank and date, or allocations repeat per election."),
        # --- 50 sweep programs and program banks ------------------------------------------------------------------
        dict(frm="program_bank", to="DP-240/Party", on="program_bank.bank_party = party.party_id", type="many-to-one"),
        dict(frm="sweep_program", to="DP-013/Internal Legal Entity",
             on="sweep_program.sponsoring_broker_dealer = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="participation", to="sweep_program",
             on="participation.participation_sweep_program = sweep_program.sweep_program_id", type="many-to-one"),
        dict(frm="participation", to="program_bank",
             on="participation.participating_program_bank = program_bank.program_bank_id", type="many-to-one"),
        dict(frm="rate_tier", to="sweep_program", on="rate_tier.tier_sweep_program = sweep_program.sweep_program_id",
             type="many-to-one"),
        dict(frm="program_bank_daily", to="sweep_program",
             on="program_bank_daily.daily_total_sweep_program = sweep_program.sweep_program_id", type="many-to-one"),
        dict(frm="program_bank_daily", to="program_bank",
             on="program_bank_daily.daily_total_program_bank = program_bank.program_bank_id", type="many-to-one"),
        dict(frm="program_bank_daily", to="participation",
             on="same sweep program and program bank, participation in force on daily_total_business_date",
             type="many-to-one"),
        dict(frm="fdic_assessment", to="program_bank",
             on="fdic_assessment.assessed_program_bank = program_bank.program_bank_id", type="many-to-one"),
        dict(frm="fdic_assessment", to="DP-240/Party", on="fdic_assessment.assessed_party = party.party_id",
             type="many-to-one"),
        dict(frm="sweep_run", to="sweep_program", on="sweep_run.run_sweep_program = sweep_program.sweep_program_id",
             type="many-to-one"),
        dict(frm="cash_forecast_line", to="cash_forecast",
             on="cash_forecast_line.line_client_cash_forecast = cash_forecast.client_cash_forecast_id",
             type="many-to-one"),
        dict(frm="cash_forecast_line", to="sweep_program",
             on="cash_forecast_line.line_sweep_program = sweep_program.sweep_program_id", type="many-to-one"),
        # --- 49 transfers (DP-448) -------------------------------------------------------------------------------
        dict(frm="account_transfer", to=_ACCOUNT,
             on=f"account_transfer.transfer_account = client_account.account_id and the current client_account version",
             type="many-to-one"),
        dict(frm="account_transfer", to="DP-240/Party", on="account_transfer.contra_firm = party.party_id",
             type="many-to-one"),
        dict(frm="account_transfer", to="transfer_request",
             on="account_transfer.originating_service_request = transfer_request.service_request_id",
             type="many-to-one"),
        dict(frm="transfer_asset_line", to="account_transfer",
             on="transfer_asset_line.line_account_transfer = account_transfer.account_transfer_id", type="many-to-one"),
        dict(frm="transfer_asset_line", to="DP-097/Instrument",
             on="transfer_asset_line.transfer_asset_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="transfer_asset_line", to="transfer_price",
             on="transfer_asset_line.transfer_asset_instrument = transfer_price.priced_instrument and "
                "transfer_price.price_date = account_transfer.transfer_settlement_date", type="many-to-one"),
        dict(frm="cost_basis_statement", to="account_transfer",
             on="cost_basis_statement.statement_account_transfer = account_transfer.account_transfer_id",
             type="many-to-one"),
        # --- DP-445 reserve and possession or control: firm-level, never joined to account rows ----------------
        dict(frm="reserve_computation", to="DP-013/Internal Legal Entity",
             on="reserve_computation.computing_broker_dealer = internal_legal_entity.legal_entity_id",
             type="many-to-one"),
        dict(frm="reserve_computation", to="DP-013/Calendar Date",
             on="reserve_computation.computation_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="reserve_line", to="reserve_computation",
             on="reserve_line.line_reserve_computation = reserve_computation.reserve_computation_id",
             type="many-to-one"),
        dict(frm="reserve_computation", to="reserve_bank_account",
             on="reserve_computation.reserve_bank_accounts contains reserve_bank_account.corporate_bank_account_id",
             type="many-to-many",
             warning="A computation names several reserve bank accounts; Reserve Deposit on Hand is a computation "
                     "figure and must not be summed over the accounts it lists."),
        dict(frm="capital_calculation", to="reserve_computation",
             on="capital_calculation.capital_reserve_computation = reserve_computation.reserve_computation_id",
             type="many-to-one"),
        dict(frm="possession_control", to="DP-097/Instrument",
             on="possession_control.determination_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="possession_control", to="control_location",
             on="possession_control.control_locations_counted contains control_location.control_location_party "
                "(location version in force on the business date)", type="many-to-many",
             warning="A determination counts several control locations; deficit quantities must not be summed over "
                     "the locations it lists."),
        dict(frm="control_location", to="DP-240/Party", on="control_location.control_location_party = party.party_id",
             type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Execution venue", levels=["execution_venue.venue_type", "execution_venue.venue_mic"]),
        dict(name="Trade correction", levels=["trade_correction.correction_type", "trade_correction.trade_correction_reason"]),
        dict(name="Payment", levels=["money_movement.payment_rail", "money_movement.money_movement_type"]),
        dict(name="Sweep program", levels=["sweep_program.sweep_program_type", "sweep_program.sweep_program_name"]),
        dict(name="Rule 605 line", levels=["rule_605_line.rule_605_order_type", "rule_605_line.rule_605_order_size_bucket"]),
    ],

    metrics=[
        # ======================= Certified numbers, referenced (SM-20) =========================================
        dict(name="Client Assets", ref="SM-20/Client Assets"),
        dict(name="Net New Assets", ref="SM-20/Net New Assets"),

        # ======================= DP-300 Client holdings, lots, activity and cash (49) ===========================
        dict(name="Client Holdings Market Value", aggregation="semi_additive",
             expr="sum(client_holding.market_value_usd)", time_rule="last holding date in the selected range",
             source=("DP-300", "Client Holdings Market Value"),
             description="Market value in US dollars of client holdings in the brokerage book of record at the end of "
                         "the day.",
             note="The 49 book value that DP-007 and DP-008 copy; never labeled, added to or compared as Client Assets "
                  "(SM-20) or Firm AUM (SM-11)."),
        dict(name="Open Client Holdings", aggregation="semi_additive",
             expr="count(client_holding rows with trade_date_quantity, settled_quantity or short_quantity not zero)",
             time_rule="last holding date in the selected range", source=("DP-300", "Open Client Holdings"),
             description="Number of account and instrument positions open at the end of the day."),
        # The same 49 number SM-20 publishes through DP-496's copy; referenced, not redefined (one name, one definition).
        dict(name="Own-Fund Client Holdings Market Value", ref="SM-20/Own-Fund Client Holdings Market Value"),
        dict(name="Holdings Valued at Unapproved Price %", aggregation="ratio",
             numerator="[Open Client Holdings] whose valuation_price_record is blank, or names an approved price with "
                       "Price Approval Status other than Approved or Price Date before the valuation date",
             denominator="[Open Client Holdings]", source=("DP-300", "Holdings Valued at Unapproved Price %"),
             description="Share of open positions valued without a current approved price."),
        dict(name="Client Holding to Client Tax Lot Quantity Breaks", aggregation="semi_additive",
             expr="count(open client_holding rows whose trade_date_quantity differs from sum(client_tax_lot."
                  "remaining_quantity) of open lots of the same account and instrument by more than 0.0001 shares)",
             time_rule="last holding date in the selected range",
             source=("DP-300", "Client Holding to Client Tax Lot Quantity Breaks"),
             description="Positions whose quantity does not agree with their open tax lots."),
        dict(name="Open Lots Without Usable Cost Basis", aggregation="additive",
             expr="count(client_tax_lot where client_tax_lot_status = 'Open' and ((covered_security_indicator = 'Y' and "
                  "adjusted_cost_basis is null) or (covered_security_class = 'Noncovered' and noncovered_basis_source = "
                  "'Unknown')))",
             source=("DP-300", "Open Lots Without Usable Cost Basis"),
             description="Open tax lots that cannot be reported with a cost basis, by acquisition method.",
             note="Tax lots are current state (no as-of snapshot, DP-300 taxonomy gap)."),
        dict(name="Realized Gain or Loss", aggregation="additive", expr="sum(lot_relief.realized_gain_loss)",
             source=("DP-300", "Realized Gain or Loss"),
             description="Realized gain or loss on lots closed in the tax year, by holding period term and Form 1099-B "
                         "category.",
             note="The closing date is the trade date of the closing activity or register transaction."),
        dict(name="Wash Sale Loss Disallowed", aggregation="additive", expr="sum(lot_relief.wash_sale_loss_disallowed)",
             source=("DP-300", "Wash Sale Loss Disallowed"),
             description="Losses disallowed under the wash sale rule on lots closed in the tax year."),
        dict(name="Relief Method Differs From Election", aggregation="additive",
             expr="count(lot_relief where relief_method_source = 'Account Default Election' and relief_method_applied "
                  "differs from the DP-093 Cost Basis Election of the lot's account effective on the closing date)",
             source=("DP-300", "Relief Method Differs From Election"),
             description="Lot reliefs that did not follow the account's cost basis election."),
        dict(name="Pending Activity Net Amount", aggregation="semi_additive",
             expr="sum(account_activity.activity_net_amount) where activity_status = 'Pending', within one activity_currency",
             time_rule="as of the last date in the selected range", source=("DP-300", "Pending Activity Net Amount"),
             description="Net amount of postings still pending, by activity type and settlement date."),
        dict(name="Posted Activity Net Amount", aggregation="additive",
             expr="sum(account_activity.activity_net_amount) where activity_status = 'Posted' and activity_trade_date in "
                  "the period, within one activity_currency (with the count of postings)",
             source=("DP-300", "Posted Activity Net Amount"),
             description="Net amount of postings booked in the period, by activity type.",
             note="The brokerage flow source DP-006 copies; never Net New Assets (SM-20)."),
        dict(name="Activities Without Source Record", aggregation="additive",
             expr="count(posted account_activity of a sourced type whose matching source key is blank; Interest excluded)",
             source=("DP-300", "Activities Without Source Record"),
             description="Postings that cannot be traced to the trade, payment, fee, entitlement, transfer or fund order "
                         "that caused them."),
        dict(name="Free Credit Balances", aggregation="semi_additive",
             expr="sum(cash_balance.cash_balance_amount) where cash_balance_type = 'Free Credit Balance', within one "
                  "cash_balance_currency",
             time_rule="last business date in the selected range", source=("DP-300", "Free Credit Balances"),
             description="Client free credit balances on the settlement-date book.",
             note="The input DP-445 reads for the reserve computation; never a reserve figure here."),
        dict(name="Sweep Balances", aggregation="semi_additive",
             expr="sum(cash_balance.cash_balance_amount) where cash_balance_type = 'Sweep Balance'",
             time_rule="last business date in the selected range", source=("DP-300", "Sweep Balances"),
             description="Client cash held in sweep programs on the settlement-date book, by sweep program.",
             note="An operational balance, never Client Assets; the tie to Sweep Allocated Balance is DP-446's."),
        dict(name="Margin Debit Balances", aggregation="semi_additive", expr="sum(margin_snapshot.margin_debit_balance)",
             time_rule="last business date in the selected range", source=("DP-300", "Margin Debit Balances"),
             description="Client margin debit balances at the end of the day, with equity, maintenance requirement and "
                         "accrued margin interest."),
        dict(name="Accounts in Maintenance Deficit", aggregation="semi_additive",
             expr="count distinct margin_snapshot.margin_snapshot_account where maintenance_excess_or_deficit < 0 (with "
                  "the sum of the deficit)",
             time_rule="last business date in the selected range", source=("DP-300", "Accounts in Maintenance Deficit"),
             description="Margin accounts below their maintenance requirement at the end of the day.",
             note="Margin calls are DP-600's."),
        dict(name="On-Loan Quantity Breaks", aggregation="semi_additive",
             expr="count(account x instrument pairs where sum(securities_loan.loan_quantity) of loans Open or Recalled "
                  "differs from client_holding.on_loan_quantity)",
             time_rule="last holding date in the selected range", source=("DP-300", "On-Loan Quantity Breaks"),
             description="Positions whose on-loan quantity does not agree with the open fully paid securities loans."),
        dict(name="Overdue Corporate Action Entitlements", aggregation="semi_additive",
             expr="count and sum(ca_entitlement.entitled_cash_amount) where (entitlement_status in ('Projected', "
                  "'Confirmed') and entitlement_payment_date < :as_of_date) or (entitlement_status = 'Paid' and the "
                  "payment activity is blank)",
             time_rule="as of the last date in the selected range",
             source=("DP-300", "Overdue Corporate Action Entitlements"),
             description="Client corporate action entitlements past their payment date and not paid or not booked."),
        dict(name="Account Transfers by Status", aggregation="non_additive",
             expr="count(account_transfer where transfer_status in ('Requested', 'Validated', 'Settlement Pending') on "
                  ":as_of_date, with age since validation_date) and count(account_transfer where transfer_status = "
                  "'Settled' and transfer_settlement_date in the period)",
             source=("DP-300", "Account Transfers by Status"),
             description="Transfers open on the date and transfers settled in the period, by direction and channel.",
             note="Two counts with different time rules (open on the date; settled in the period), so shown at the "
                  "product's grain only. Runs on the DP-448 account_transfer table (the same 49 rows)."),
        dict(name="Late Cost Basis Transfer Statements", aggregation="semi_additive",
             expr="count(cost_basis_statement where transfer_statement_direction = 'Sent' and (statement_sent_or_"
                  "received_date > statement_due_date or (statement_sent_or_received_date is null and statement_due_date "
                  "< :as_of_date)))",
             time_rule="as of the last date in the selected range",
             source=("DP-300", "Late Cost Basis Transfer Statements"),
             description="Outgoing cost basis transfer statements sent late or still owed (IRC section 6045A).",
             note="Runs on the DP-448 cost_basis_statement table (the same 49 rows)."),

        # ======================= DP-301 Client orders and executions (48) ======================================
        dict(name="Client Orders Received", aggregation="additive",
             expr="count(client_order) where order_received_timestamp in the period",
             source=("DP-301", "Client Orders Received"),
             description="Client orders received, by source, channel, order type, side, solicitation and instrument type."),
        dict(name="Client Orders Filled %", aggregation="ratio",
             numerator="[Client Orders Received] where client_order_status = 'Filled'",
             denominator="[Client Orders Received] where client_order_status <> 'Rejected'",
             source=("DP-301", "Client Orders Filled %"),
             description="Share of accepted client orders that were filled."),
        dict(name="Client Orders Rejected", aggregation="additive",
             expr="count(client_order) where client_order_status = 'Rejected' and order_received_timestamp in the period",
             source=("DP-301", "Client Orders Rejected"),
             description="Client orders rejected, by rejection reason."),
        dict(name="Day Orders Without Terminal Status", aggregation="semi_additive",
             expr="count(client_order where time_in_force = 'Day' and order_received_timestamp before the current "
                  "trade date and client_order_status in ('Pending New', 'New', 'Partially Filled', 'Pending Cancel', "
                  "'Pending Replace'))",
             time_rule="as of the current trade date", source=("DP-301", "Day Orders Without Terminal Status"),
             description="Day orders from earlier trade dates still not filled, canceled or expired."),
        dict(name="Executed Quantity and Notional", aggregation="additive",
             expr="sum(client_execution.executed_quantity) and sum(executed_quantity x execution_price), within one "
                  "execution_currency", source=("DP-301", "Executed Quantity and Notional"),
             description="Shares executed and their notional value, by trade date, venue and capacity."),
        dict(name="Price Improvement Amount", aggregation="additive",
             expr="sum(client_execution.price_improvement_per_share x client_execution.executed_quantity)",
             source=("DP-301", "Price Improvement Amount"),
             description="Dollars of price improvement clients received over the quote, by venue and session.",
             note="DP-436 shows the same figure by route venue and client order type; that copy is excluded, and this "
                  "metric is sliced through order_route and client_order."),
        dict(name="Route Fill Ratio", aggregation="ratio",
             numerator="sum(client_execution.executed_quantity) of executions on the route",
             denominator="sum(order_route.routed_quantity)", source=("DP-301", "Route Fill Ratio"),
             description="Share of routed shares that were executed, by venue and routing rule."),
        dict(name="Receipt to First Route Latency", aggregation="non_additive",
             expr="median over client orders of (min(order_route.routed_timestamp) - client_order.order_received_"
                  "timestamp) in milliseconds", source=("DP-301", "Receipt to First Route Latency"),
             description="Median time from receiving a client order to its first route, by channel and session.",
             note="A median: recomputed from detail rows for each slice, never averaged."),
        dict(name="Routes Off Routing Rule Default %", aggregation="ratio",
             numerator="count(order_route) where routing_decision_basis in ('Fallback - Venue Unavailable', 'Manual "
                       "Trader Handling')",
             denominator="count(order_route) routed in the period", source=("DP-301", "Routes Off Routing Rule Default %"),
             description="Share of routes that did not follow the routing rule's primary venue."),
        dict(name="Unallocated Block Quantity", aggregation="additive",
             expr="sum over client_block_order created before the current trade date of (executed quantity on its "
                  "routes - sum(client_allocation.allocated_quantity + fractional_remainder_quantity)), nonzero blocks only",
             source=("DP-301", "Unallocated Block Quantity"),
             description="Executed block shares not yet allocated to client accounts, by block origin."),
        dict(name="Allocations Without Confirmation", aggregation="additive",
             expr="count(client_allocation on trade date T with no trade_confirmation of type 'Original' by the end of T+1)",
             source=("DP-301", "Allocations Without Confirmation"),
             description="Allocations not confirmed to the client by the end of the next day (SEC Rule 10b-10)."),
        dict(name="Confirmed Net Amount", aggregation="additive", expr="sum(trade_confirmation.confirmed_net_amount)",
             source=("DP-301", "Confirmed Net Amount"),
             description="Net amount of current client trade confirmations, by trade date and capacity."),
        dict(name="Commission Charged on Confirmations", aggregation="additive",
             expr="sum(trade_confirmation.commission_charged)", source=("DP-301", "Commission Charged on Confirmations"),
             description="Commissions charged on current confirmations, by trade date.",
             note="An operational billed amount, never Client Fee Revenue (SM-28)."),
        dict(name="Trade Corrections", aggregation="additive", expr="count(trade_correction) in the period",
             source=("DP-301", "Trade Corrections"),
             description="Trade corrections, by correction type, reason and as-of indicator.",
             note="Runs on the DP-437 trade_correction table (the same 48 rows); the correction month is the resulting "
                  "confirmation's trade date (DP-437 taxonomy gap)."),
        dict(name="Corrections per 10,000 Allocations", aggregation="ratio",
             numerator="[Trade Corrections] x 10,000",
             denominator="count(client_allocation) with allocation_timestamp in the period",
             source=("DP-301", "Corrections per 10,000 Allocations"),
             description="Trade corrections per 10,000 client allocations."),
        dict(name="Corrections Without Resulting Confirmation", aggregation="additive",
             expr="count(trade_correction where correction_type in ('Correct', 'Cancel and Rebill', 'As-Of Trade') and "
                  "(resulting_confirmation is null or the resulting confirmation's originating_trade_correction does "
                  "not name the correction))",
             source=("DP-301", "Corrections Without Resulting Confirmation"),
             description="Corrections that did not produce a confirmation pointing back to them."),

        # ======================= DP-437 Trade corrections and errors ==========================================
        dict(name="Corrected Client Orders", aggregation="count_distinct",
             expr="count distinct client_allocation.allocated_client_order of corrected allocations with a "
                  "trade_correction in the period",
             source=("DP-437", "Corrected Client Orders"),
             description="Client orders with at least one correction in the period, by order source, order type and "
                         "correction type."),
        dict(name="As-Of Trade Share", aggregation="ratio",
             numerator="count(trade_correction) where as_of_trade_indicator = 'Y'", denominator="[Trade Corrections]",
             source=("DP-437", "As-Of Trade Share"),
             description="Share of corrections booked as as-of trades, by month."),
        dict(name="Corrections Without Approver", aggregation="additive",
             expr="count(trade_correction) where Correction Approved By is blank",
             source=("DP-437", "Corrections Without Approver"),
             description="Corrections with no recorded approver, by correction type."),
        dict(name="Resulting Confirmations Not Superseding", aggregation="additive",
             expr="count(trade_correction whose resulting confirmation has confirmation_type not in ('Corrected', "
                  "'Cancel', 'As-Of'), or a blank superseded_confirmation, or an originating_trade_correction that does "
                  "not name the correction)",
             source=("DP-437", "Resulting Confirmations Not Superseding"),
             description="Corrections whose new confirmation does not properly replace the old one."),
        dict(name="Venue Busts by Venue", aggregation="additive",
             expr="count(trade_correction where correction_type = 'Venue Bust' or trade_correction_reason = 'Clearly "
                  "Erroneous Execution')", source=("DP-437", "Venue Busts by Venue"),
             description="Executions broken by the venue or as clearly erroneous, by the venue of the corrected "
                         "execution."),
        dict(name="Trade Error Cases Opened", aggregation="additive",
             expr="count(trade_error_case) where error_detected_date in the period",
             source=("DP-437", "Trade Error Cases Opened"),
             description="Trade error cases opened, by cause and severity."),
        dict(name="Trade Error Gain or Loss", aggregation="additive",
             expr="sum(trade_error_case.error_gain_or_loss_amount), losses (negative) and gains shown separately",
             source=("DP-437", "Trade Error Gain or Loss"),
             description="Gains and losses from trade errors, by cause.",
             note="An operational amount; losses are booked in 37 (DP-215), never here."),
        dict(name="Client Made Whole Rate", aggregation="ratio",
             numerator="count(trade_error_case) where error_account is not null and client_made_whole_indicator = 'Y'",
             denominator="count(trade_error_case) where error_account is not null and error_case_status is closed",
             source=("DP-437", "Client Made Whole Rate"),
             description="Share of closed client error cases where the client was made whole."),
        dict(name="Open Error Cases by Age", aggregation="semi_additive",
             expr="count(trade_error_case) where error_case_status is not closed, by age bucket from error_detected_date "
                  "(0 to 5, 6 to 30, over 30 days) and error_severity",
             time_rule="latest monthly snapshot in the selected range", source=("DP-437", "Open Error Cases by Age"),
             description="Open trade error cases by how long they have been open."),
        dict(name="Error Losses Without Loss Event", aggregation="additive",
             expr="count and sum(error_gain_or_loss_amount) of trade_error_case with error_gain_or_loss_amount < 0 and "
                  "no resolving loss_event; and [Trade Error Gain or Loss] - sum(loss_event.loss_impact_amount) of the "
                  "linked loss events",
             source=("DP-437", "Error Losses Without Loss Event"),
             description="Trade error losses not recorded as operational loss events, and the difference to tie."),
        dict(name="Error Cases Without Correction", aggregation="additive",
             expr="count(trade_error_case on a client order or block that no trade_correction.related_trade_error_case "
                  "names)", source=("DP-437", "Error Cases Without Correction"),
             description="Trade error cases on orders that were never corrected, by cause."),

        # ======================= DP-432 Venues, routing rules and Rule 605 lines ==============================
        dict(name="Active Execution Venues", aggregation="count_distinct",
             expr="count distinct execution_venue.venue_party where venue_profile_status = 'Active'",
             source=("DP-432", "Active Execution Venues"),
             description="Execution venues the firm can route to on the date, by venue type."),
        dict(name="Market Venues Without MIC", aggregation="count_distinct",
             expr="count distinct execution_venue.venue_party where venue_profile_status = 'Active' and venue_type in "
                  "('National Securities Exchange', 'Options Exchange', 'Alternative Trading System') and venue_mic is null",
             source=("DP-432", "Market Venues Without MIC"),
             description="Active exchanges and ATSs with no market identifier code."),
        dict(name="Affiliated Venues", aggregation="count_distinct",
             expr="count distinct execution_venue.venue_party where venue_profile_status = 'Active' and affiliated_venue = 'Y'",
             source=("DP-432", "Affiliated Venues"),
             description="Active venues affiliated with the firm."),
        dict(name="Venues Accepting Payment for Order Flow", aggregation="count_distinct",
             expr="count distinct execution_venue.venue_party where venue_profile_status = 'Active' and "
                  "payment_for_order_flow = 'Y'", source=("DP-432", "Venues Accepting Payment for Order Flow"),
             description="Active venues the firm accepts payment for order flow from (zero under the reference default)."),
        dict(name="Active Routing Rules", aggregation="count_distinct",
             expr="count distinct routing_rule.routing_rule_code in force on the date",
             source=("DP-432", "Active Routing Rules"),
             description="Routing rules in force, by instrument class, order types and sessions."),
        dict(name="Routing Rules Without Approving Review", aggregation="count_distinct",
             expr="count distinct routing_rule.routing_rule_code where approving_review is null",
             source=("DP-432", "Routing Rules Without Approving Review"),
             description="Routing rules in force without a best-execution committee approval."),
        dict(name="Routing Rules Without Fallback Venue", aggregation="count_distinct",
             expr="count distinct routing_rule.routing_rule_code where fallback_venues is null",
             source=("DP-432", "Routing Rules Without Fallback Venue"),
             description="Routing rules in force with no fallback venue."),
        dict(name="Routing Rules Pointing at Inactive Venue", aggregation="count_distinct",
             expr="count distinct routing_rule.routing_rule_code whose primary venue or any fallback venue has no active "
                  "execution_venue profile on the date",
             source=("DP-432", "Routing Rules Pointing at Inactive Venue"),
             description="Routing rules that send orders to a venue that is not active."),
        dict(name="Instrument Classes Without Active Routing Rule", aggregation="non_additive",
             expr="count of Routing Instrument Class values with no routing_rule in force on the date",
             source=("DP-432", "Instrument Classes Without Active Routing Rule"),
             description="Instrument classes the firm trades with no routing rule in force.",
             note="Counted against the full code list; shown for the firm only."),
        dict(name="Rule 605 Covered Orders", aggregation="additive",
             expr="sum(rule_605_line.covered_order_count) and sum(rule_605_line.covered_order_shares)",
             source=("DP-432", "Rule 605 Covered Orders"),
             description="Covered orders and shares in the Rule 605 report, by reporting entity, order type, size "
                         "bucket and notional range."),
        dict(name="Rule 605 Price-Improved Shares", aggregation="additive", expr="sum(rule_605_line.price_improved_shares)",
             source=("DP-432", "Rule 605 Price-Improved Shares"),
             description="Shares executed with price improvement in the Rule 605 report, as reported."),
        dict(name="Rule 605 Report Lines Published", aggregation="additive",
             expr="count(rule_605_line) (with count distinct rule_605_security)",
             source=("DP-432", "Rule 605 Report Lines Published"),
             description="Lines and securities in the monthly Rule 605 report: its completeness count."),

        # ======================= DP-436 Execution quality and Rules 605 and 606 ================================
        dict(name="Price Improvement Rate by Venue", aggregation="ratio",
             numerator="sum(execution_quality.price_improvement_rate x execution_quality.measured_order_count)",
             denominator="sum(execution_quality.measured_order_count)",
             source=("DP-436", "Price Improvement Rate by Venue"),
             description="Share of orders that received price improvement, by venue, order class and order type.",
             note="Published as 48 computes it (CW-100), weighted by measured orders, never recomputed."),
        dict(name="Average Price Improvement Per Share by Venue", aggregation="ratio",
             numerator="sum(execution_quality.average_price_improvement_per_share x execution_quality.measured_order_count)",
             denominator="sum(execution_quality.measured_order_count)",
             source=("DP-436", "Average Price Improvement Per Share by Venue"),
             description="Average price improvement per share, by venue, order class and order type."),
        dict(name="Effective Over Quoted Spread by Venue", aggregation="ratio",
             numerator="sum(execution_quality.effective_over_quoted_spread x execution_quality.measured_order_count)",
             denominator="sum(execution_quality.measured_order_count)",
             source=("DP-436", "Effective Over Quoted Spread by Venue"),
             description="Effective spread as a share of the quoted spread, by venue and order class; below 100 percent "
                         "means executions inside the quote."),
        dict(name="Quoted Spread at Route", aggregation="ratio",
             numerator="sum(route_quote.nbbo_offer_at_route - route_quote.nbbo_bid_at_route) over routes of NMS stock orders",
             denominator="count(route_quote) of NMS stock orders", source=("DP-436", "Quoted Spread at Route"),
             description="Average quoted spread at the moment of routing, in dollars per share (and as a share of the "
                         "midpoint), by venue and order type."),
        dict(name="Execution Price Versus Quote at Route", aggregation="ratio",
             numerator="sum(client_execution.executed_quantity x (for buys nbbo_offer_at_route - execution_price; for "
                       "sells execution_price - nbbo_bid_at_route))",
             denominator="sum(client_execution.executed_quantity)",
             source=("DP-436", "Execution Price Versus Quote at Route"),
             description="How far inside the quote at routing clients were filled, per share, by venue: an independent "
                         "check of the 48 price improvement statistics."),
        dict(name="Routed Quotes Without 22 Quote Snapshot", aggregation="additive",
             expr="count(route_quote of NMS stock orders with no Bid and Ask quote_observation of the instrument within "
                  "one second before the routed timestamp)",
             source=("DP-436", "Routed Quotes Without 22 Quote Snapshot"),
             description="Routes whose quote at routing cannot be evidenced from the consolidated feed."),
        dict(name="Routed NBBO Differs From 22 Quote", aggregation="additive",
             expr="count(route_quote whose nbbo_bid_at_route or nbbo_offer_at_route differs by more than USD 0.005 from "
                  "the matching quote_observation)", source=("DP-436", "Routed NBBO Differs From 22 Quote"),
             description="Routes whose recorded quote differs from the consolidated feed, by venue."),
        dict(name="Rule 605 Price-Improved Share %", aggregation="ratio",
             numerator="sum(rule_605_line.price_improved_shares)", denominator="sum(rule_605_line.covered_order_shares)",
             source=("DP-436", "Rule 605 Price-Improved Share %"),
             description="Share of covered shares that were price improved in the Rule 605 report, by order type and "
                         "size bucket.",
             note="Runs on the DP-432 rule_605_line table (the same 48 lines)."),
        dict(name="Rule 605 Effective Spread and Time to Execution", aggregation="ratio",
             numerator="sum(rule_605_line.average_effective_spread x rule_605_line.covered_order_shares) (and the same "
                       "for average_time_to_execution)",
             denominator="sum(rule_605_line.covered_order_shares)",
             source=("DP-436", "Rule 605 Effective Spread and Time to Execution"),
             description="Covered-share-weighted effective spread and time to execution in the Rule 605 report."),
        dict(name="Rule 606 Non-Directed Order Share by Venue", aggregation="non_additive",
             expr="rule_606_line.non_directed_order_pct with the market, marketable limit, non-marketable limit and other "
                  "order percentages, as reported", source=("DP-436", "Rule 606 Non-Directed Order Share by Venue"),
             description="Share of non-directed orders routed to each venue in the quarterly Rule 606 report.",
             note="Reported percentages: shown at the line's grain (quarter, month, order class, venue), never summed."),
        dict(name="Rule 606 Net Payment for Order Flow", aggregation="additive",
             expr="sum(rule_606_line.net_order_flow_payment_amount)",
             source=("DP-436", "Rule 606 Net Payment for Order Flow"),
             description="Net payment for order flow disclosed in the Rule 606 report, by quarter, order class and venue "
                         "(zero under the reference default).",
             note="A disclosure figure, not revenue."),
        dict(name="Rule 606 Venues Without Material Aspects Discussion", aggregation="additive",
             expr="count(rule_606_line of the quarter for venues receiving non-directed orders where "
                  "material_aspects_discussion is blank)",
             source=("DP-436", "Rule 606 Venues Without Material Aspects Discussion"),
             description="Rule 606 venue lines missing the required discussion of material aspects."),
        dict(name="Routed Quantity Share by Venue", aggregation="ratio",
             numerator="sum(order_route.routed_quantity) for the venue",
             denominator="sum(order_route.routed_quantity) for the month",
             source=("DP-436", "Routed Quantity Share by Venue"),
             description="Share of routed shares sent to each venue, by instrument class, with affiliated venues flagged."),
        dict(name="Venues Without Current Committee Review", aggregation="non_additive",
             expr="count of measured venues of the latest quarter with no committee review or a review completed before "
                  "the quarter end, plus routing rules in force without an approving review",
             source=("DP-436", "Venues Without Current Committee Review"),
             description="Venues and routing rules not covered by a current best-execution committee review (FINRA "
                         "Rule 5310.09)."),
        dict(name="Committee Reviews With Exceptions", aggregation="count_distinct",
             expr="count distinct committee_review.supervisory_review_id where review_outcome is other than no exception",
             source=("DP-436", "Committee Reviews With Exceptions"),
             description="Best-execution committee reviews that found exceptions, by routing rule and venue."),
        dict(name="Routing Disclosure Requests Answered Late", aggregation="additive",
             expr="count(routing_disclosure_request where response_delivered_date is null or more than seven business "
                  "days after request_received_date)",
             source=("DP-436", "Routing Disclosure Requests Answered Late"),
             description="Customer Rule 606(b) routing requests answered late or not yet answered, by request type."),

        # ======================= DP-302 Money movement (50) ======================================================
        dict(name="Money Movement Count", aggregation="additive",
             expr="count(money_movement) where requested_date in the period",
             source=("DP-302", "Money Movement Count"),
             description="Money movements requested, by type, rail, direction, channel, source and published status."),
        dict(name="Settled Inflow Amount", aggregation="additive",
             expr="sum(money_movement.movement_amount) where money_movement_status = 'Settled' and movement_direction = "
                  "'Inflow' and payment_rail <> 'Internal Journal' and value_date in the period, within one movement_currency",
             source=("DP-302", "Settled Inflow Amount"),
             description="Money received into client accounts, by rail.",
             note="An operational payment amount, never Net New Assets (SM-20)."),
        dict(name="Settled Outflow Amount", aggregation="additive",
             expr="sum(money_movement.movement_amount) where money_movement_status = 'Settled' and movement_direction = "
                  "'Outflow' and payment_rail <> 'Internal Journal' and value_date in the period, within one "
                  "movement_currency", source=("DP-302", "Settled Outflow Amount"),
             description="Money paid out of client accounts, by rail.",
             note="An operational payment amount, never Net New Assets (SM-20)."),
        dict(name="Settled ACH Movements", aggregation="additive",
             expr="count(money_movement) where payment_rail = 'ACH' and money_movement_status = 'Settled' and value_date "
                  "in the period", source=("DP-302", "Settled ACH Movements"),
             description="Settled ACH movements, by direction and SEC code: the base of the return rates."),
        dict(name="Movements Settled After Value Date", aggregation="additive",
             expr="count(settled money_movement whose movement_event of type 'Settled' has an event date after value_date)",
             source=("DP-302", "Movements Settled After Value Date"),
             description="Movements that settled later than their value date, by rail."),
        dict(name="ACH Return Rate %", aggregation="ratio",
             numerator="count(movement_return) with return_received_date in the period on ACH movements",
             denominator="[Settled ACH Movements]", source=("DP-302", "ACH Return Rate %"),
             description="ACH returns as a share of settled ACH movements, by return reason and SEC code."),
        dict(name="Unauthorized Return Rate %", aggregation="ratio",
             numerator="count(movement_return) where unauthorized_return_indicator = 'Y'",
             denominator="[Settled ACH Movements] where movement_direction = 'Inflow' and standard_entry_class_code in "
                         "('PPD', 'WEB', 'TEL')",
             source=("DP-302", "Unauthorized Return Rate %"),
             description="Unauthorized ACH returns on debits the firm originated, tested against the NACHA 0.5 percent "
                         "threshold."),
        dict(name="Open Money Movement Exceptions", aggregation="semi_additive",
             expr="count(movement_exception) where exception_status is not closed, by exception type and age in business "
                  "days", time_rule="as of the last date in the selected range",
             source=("DP-302", "Open Money Movement Exceptions"),
             description="Open payment exceptions, by type and age."),
        dict(name="Active Money Movement Holds", aggregation="semi_additive",
             expr="count(movement_hold) where hold_status in ('Active', 'Extended') on :as_of_date (published hold types "
                  "only)", time_rule="as of the last date in the selected range",
             source=("DP-302", "Active Money Movement Holds"),
             description="Active holds on cash movements for funds availability, fraud, legal process, sanctions or a "
                         "deceased owner, by hold type and reason.",
             note="Special-category and AML holds are not in the table and cannot be inferred (complementary "
                  "suppression in access)."),
        dict(name="Held Amount", aggregation="semi_additive",
             expr="sum(money_movement.movement_amount) of distinct held movements of [Active Money Movement Holds], "
                  "within one movement_currency", time_rule="as of the last date in the selected range",
             source=("DP-302", "Held Amount"),
             description="Value of the cash movements under an active published hold.",
             note="The whole movement amount: Money Movement Hold has no held amount, so a partial hold cannot be shown."),
        dict(name="Holds Past Expiry", aggregation="semi_additive",
             expr="count([Active Money Movement Holds] where hold_expiry_date < :as_of_date and hold_released_date is "
                  "null), with age since hold_placed_date", time_rule="as of the last date in the selected range",
             source=("DP-302", "Holds Past Expiry"),
             description="Active published holds past their expiry date, by hold type."),
        dict(name="Fraud Decisions", aggregation="additive",
             expr="count(fraud_assessment) where assessment_timestamp in the period (with the mean fraud_risk_score)",
             source=("DP-302", "Fraud Decisions"),
             description="Fraud screening decisions on cash movements, by decision and model.",
             note="Scores come from the 37 model named in Fraud Model (DP-212)."),
        dict(name="Fraud Missed Rate %", aggregation="ratio",
             numerator="count(fraud_assessment) where fraud_decision = 'Allow' and confirmed_fraud_indicator = 'Y'",
             denominator="count(fraud_assessment) where fraud_decision = 'Allow'",
             source=("DP-302", "Fraud Missed Rate %"),
             description="Share of allowed movements later confirmed as fraud, by model."),
        dict(name="Open Monitoring Alerts", aggregation="semi_additive",
             expr="count(monitoring_alert) where alert_status is open, by scenario and age",
             time_rule="as of the last date in the selected range", source=("DP-302", "Open Monitoring Alerts"),
             description="Open money movement monitoring alerts, by scenario (elder exploitation scenarios excluded)."),
        dict(name="Outgoing Wires Without Complete Travel Rule Record", aggregation="additive",
             expr="count(money_movement where movement_direction = 'Outflow' and payment_rail in ('Fedwire Funds', "
                  "'International Wire') and the USD amount >= 3,000 and travel_rule_record_complete <> 'Y')",
             source=("DP-302", "Outgoing Wires Without Complete Travel Rule Record"),
             description="Outgoing wires of USD 3,000 or more without a complete Travel Rule record (31 CFR "
                         "1010.410(f))."),
        dict(name="Movements to Unverified Bank Instructions", aggregation="additive",
             expr="count(ACH and wire money_movement requested in the period whose bank_instruction has "
                  "bank_verification_status <> 'Verified')",
             source=("DP-302", "Movements to Unverified Bank Instructions"),
             description="ACH and wire movements to bank accounts not currently verified, by third-party indicator."),
        dict(name="Sweep Allocated Balance", aggregation="semi_additive", expr="sum(sweep_allocation.allocated_balance)",
             time_rule="last business date in the selected range", source=("DP-302", "Sweep Allocated Balance"),
             description="Swept client cash allocated to each program bank, with interest accrued.",
             note="An operational allocated balance, never Client Assets; DP-457's copy is excluded and its "
                  "count of accounts allocated is count distinct allocation_account."),
        dict(name="Debit Card Transaction Amount", aggregation="additive",
             expr="count and sum(money_movement.movement_amount) where payment_rail = 'Debit Card Network' and "
                  "card_settlement_date in the period", source=("DP-302", "Debit Card Transaction Amount"),
             description="Debit card transactions, by ATM and foreign indicators."),
        dict(name="Checkwriting Drafts Without Redeeming Fund Order", aggregation="additive",
             expr="count(money_movement where money_movement_type = 'Checkwriting Draft' and money_movement_status = "
                  "'Settled' and redeeming_fund_order is null)",
             source=("DP-302", "Checkwriting Drafts Without Redeeming Fund Order"),
             description="Settled check drafts on money market funds with no fund redemption behind them."),
        dict(name="Internal Journals Pending Approval", aggregation="semi_additive",
             expr="count(money_movement) where payment_rail = 'Internal Journal' and journal_approval_status = 'Pending'",
             time_rule="as of the last date in the selected range", source=("DP-302", "Internal Journals Pending Approval"),
             description="Internal journals waiting for approval, by same-owner indicator and retirement tax coding."),

        # ======================= DP-431 Sweep programs and program banks (50) ===============================
        dict(name="Active Sweep Programs", aggregation="count_distinct",
             expr="count distinct sweep_program.sweep_program_id where program_status = 'Active' and "
                  "program_effective_from <= :as_of_date", source=("DP-431", "Active Sweep Programs"),
             description="Sweep programs in operation, by type and sponsoring broker-dealer."),
        dict(name="Active Program Banks", aggregation="count_distinct",
             expr="count distinct program_bank.program_bank_id where program_bank_status = 'Active' and onboarded and not "
                  "exited on :as_of_date", source=("DP-431", "Active Program Banks"),
             description="Banks taking swept deposits, by charter type."),
        dict(name="Program Banks Active Without Approval", aggregation="count_distinct",
             expr="count distinct [Active Program Banks] where bank_approval_status <> 'Approved'",
             source=("DP-431", "Program Banks Active Without Approval"),
             description="Active program banks without an approval on record."),
        dict(name="Active Participations", aggregation="count_distinct",
             expr="count distinct (participation_sweep_program, participating_program_bank) in force on :as_of_date at "
                  "active program banks", source=("DP-431", "Active Participations"),
             description="Bank places in sweep programs, by program and allocation priority."),
        dict(name="Program Capacity", aggregation="semi_additive", expr="sum(participation.bank_capacity_amount) of "
             "[Active Participations]", time_rule="as of the last date in the selected range",
             source=("DP-431", "Program Capacity"),
             description="Deposit capacity of the banks in each sweep program."),
        dict(name="Aggregate Customer Deposits", aggregation="semi_additive",
             expr="sum(program_bank_daily.aggregate_customer_deposits)",
             time_rule="last business date in the selected range", source=("DP-431", "Aggregate Customer Deposits"),
             description="Client deposits held at each program bank, as the bank reports them."),
        dict(name="Program Bank Capacity Utilization %", aggregation="ratio",
             numerator="sum(program_bank_daily.aggregate_customer_deposits) on the business date",
             denominator="sum(participation.bank_capacity_amount) of the participation in force for the same program "
                         "and bank", source=("DP-431", "Program Bank Capacity Utilization %"),
             description="How full each program bank is against its agreed capacity."),
        dict(name="Program Banks Over Capacity", aggregation="semi_additive",
             expr="count(program x bank pairs where [Program Bank Capacity Utilization %] > 100)",
             time_rule="last business date in the selected range", source=("DP-431", "Program Banks Over Capacity"),
             description="Program banks holding more than their agreed capacity."),
        dict(name="Daily Net Flow to Program Banks", aggregation="additive", expr="sum(program_bank_daily.net_flow_amount)",
             source=("DP-431", "Daily Net Flow to Program Banks"),
             description="Net cash moved to or from program banks, by program and bank.",
             note="An operational bank movement, never a client flow."),
        dict(name="Interest Paid by Program Banks", aggregation="additive",
             expr="sum(program_bank_daily.interest_paid_by_bank)", source=("DP-431", "Interest Paid by Program Banks"),
             description="Interest paid by program banks, as reported by the bank.",
             note="Program revenue is SM-28's (DP-012), never computed here."),
        dict(name="Programs Overstating Insured Coverage", aggregation="count_distinct",
             expr="count distinct [Active Sweep Programs] whose maximum_program_insured_coverage > [Active "
                  "Participations] x USD 250,000", source=("DP-431", "Programs Overstating Insured Coverage"),
             description="Sweep programs that advertise more FDIC coverage than their banks can provide (12 CFR "
                         "330.1(o))."),
        dict(name="Client Interest Rate by Tier", aggregation="non_additive",
             expr="rate_tier.client_interest_rate of each tier in force, by program, tier basis and balance band",
             source=("DP-431", "Client Interest Rate by Tier"),
             description="The interest rate clients earn in each sweep balance tier.",
             note="A published rate: shown at the tier's grain, never summed or averaged."),
        dict(name="Rate Tier Gaps or Overlaps", aggregation="non_additive",
             expr="count of program x rate_tier_basis sets whose tiers in force, ordered by tier_lower_bound, have a "
                  "tier_upper_bound that is not the next tier's lower bound",
             source=("DP-431", "Rate Tier Gaps or Overlaps"),
             description="Sweep rate tier schedules with gaps or overlaps."),
        dict(name="Participations Without Active Agreement", aggregation="count_distinct",
             expr="count distinct [Active Participations] whose program_bank_agreement is blank or resolves to a DP-213 "
                  "contract not active or expired", source=("DP-431", "Participations Without Active Agreement"),
             description="Bank participations without an agreement in force."),
        dict(name="Primary Purpose Notices Missing", aggregation="count_distinct",
             expr="count distinct [Active Participations] where primary_purpose_exception_basis in ('25 Percent Test "
                  "Notice', 'Enabling Transactions Notice') and exception_notice_filed_date is null",
             source=("DP-431", "Primary Purpose Notices Missing"),
             description="Participations relying on a primary purpose exception notice that was not filed."),
        dict(name="Program Changes With Short Notice", aggregation="count_distinct",
             expr="count distinct sweep_program.sweep_program_id where program_change_effective_date - "
                  "program_change_notice_date < 30 days", source=("DP-431", "Program Changes With Short Notice"),
             description="Sweep program changes made with less than 30 days' customer notice (SEC Rule "
                         "15c3-3(j)(2)(ii))."),
        dict(name="Uninsured Deposits", aggregation="semi_additive", expr="sum(fdic_assessment.uninsured_amount)",
             time_rule="latest assessment date in the selected range", source=("DP-431", "Uninsured Deposits"),
             description="Client deposits above FDIC insurance limits, by program bank and ownership category."),
        dict(name="Parties With Uninsured Deposits", aggregation="count_distinct",
             expr="count distinct fdic_assessment.assessed_party where uninsured_amount > 0 at the latest assessment date",
             source=("DP-431", "Parties With Uninsured Deposits"),
             description="Clients with deposits above FDIC insurance limits, by program bank."),
        dict(name="Insured Share of Deposits Through Firm %", aggregation="ratio",
             numerator="sum(fdic_assessment.insured_amount)", denominator="sum(fdic_assessment.deposits_through_firm)",
             source=("DP-431", "Insured Share of Deposits Through Firm %"),
             description="Share of deposits placed through the firm that are FDIC insured, by bank and recordkeeping "
                         "basis."),

        # ======================= DP-457 Cash sweep and program bank allocation ==================================
        dict(name="Sweep Runs by Status", aggregation="additive",
             expr="count(sweep_run) by run_business_date, run_sweep_program and sweep_run_status",
             source=("DP-457", "Sweep Runs by Status"),
             description="Sweep runs by status; Failed and Completed with Exceptions are exceptions."),
        dict(name="Net Sweep Amount", aggregation="additive",
             expr="sum(sweep_run.net_sweep_amount) of completed runs", source=("DP-457", "Net Sweep Amount"),
             description="Net cash swept into (positive) or out of each sweep program, by business date."),
        dict(name="Program Bank Concentration %", aggregation="ratio",
             numerator="[Sweep Allocated Balance] at the bank", denominator="[Sweep Allocated Balance] of the program on "
             "the business date", source=("DP-457", "Program Bank Concentration %"),
             description="Share of a program's allocated sweep cash at each bank; the largest bank is flagged above 40 "
                         "percent."),
        dict(name="Program Banks Near Capacity", aggregation="semi_additive",
             expr="count(participation in force whose bank's aggregate_customer_deposits >= 95 percent of "
                  "bank_capacity_amount)", time_rule="last business date in the selected range",
             source=("DP-457", "Program Banks Near Capacity"),
             description="Program banks at or above 95 percent of capacity, by program and allocation priority."),
        dict(name="Balance-Weighted Client Interest Rate", aggregation="ratio",
             numerator="sum(sweep_allocation.allocated_balance x the client_interest_rate of the rate_tier in force whose "
                       "bounds bracket the account's balance)",
             denominator="sum(sweep_allocation.allocated_balance)",
             source=("DP-457", "Balance-Weighted Client Interest Rate"),
             description="Average interest rate clients earn on swept cash, weighted by balance, by sweep program."),
        dict(name="Allocations Against Bank Exclusion or Election", aggregation="semi_additive",
             expr="count distinct (allocation_account, allocation_program_bank) with allocated_balance > 0 at a bank in "
                  "the account's excluded_program_banks, or on an account whose election in force is a money market "
                  "fund sweep; and the count with bank_exclusion_applied = 'Y'",
             time_rule="last business date in the selected range",
             source=("DP-457", "Allocations Against Bank Exclusion or Election"),
             description="Sweep allocations that break a client's bank exclusion or sweep vehicle election."),
        dict(name="Client Cash Forecast Error %", aggregation="ratio",
             numerator="abs(sum(expected_inflow_amount - expected_outflow_amount) of the latest approved forecast - "
                       "[Net Sweep Amount])", denominator="abs([Net Sweep Amount])",
             source=("DP-457", "Client Cash Forecast Error %"),
             description="How far the approved client cash forecast missed the actual net sweep, by program and value "
                         "date.",
             note="Actuals are swept cash only (DP-457 taxonomy gap)."),
        dict(name="Forecast Inflow and Outflow by Category", aggregation="additive",
             expr="sum(cash_forecast_line.expected_inflow_amount) and sum(cash_forecast_line.expected_outflow_amount) for "
                  "the next ten business days", source=("DP-457", "Forecast Inflow and Outflow by Category"),
             description="Forecast client cash in and out, by cash flow category and value date."),
        dict(name="Bank Sweep Share of Cash Client Assets", aggregation="ratio",
             numerator="[Sweep Balances] at the period end",
             denominator="[Client Assets] (SM-20) at Holding Type Cash and Sweep for the same period end, locked snapshot",
             source=("DP-457", "Bank Sweep Share of Cash Client Assets"),
             description="Share of certified cash Client Assets held at program banks.",
             note="A ratio shown beside the certified figure; the operational balance is never added to Client Assets."),

        # ======================= DP-448 ACATS in and out ===================================================
        dict(name="Transfers Initiated", aggregation="additive",
             expr="count(account_transfer) by month of transfer_request.received_timestamp",
             source=("DP-448", "Transfers Initiated"),
             description="Account transfers started, by direction and channel."),
        dict(name="Transfer Reject Rate %", aggregation="ratio",
             numerator="count(account_transfer) where transfer_status = 'Rejected'", denominator="[Transfers Initiated]",
             source=("DP-448", "Transfer Reject Rate %"),
             description="Share of transfers rejected, by reject reason, contra firm and direction."),
        dict(name="Transfers In Validated Within One Business Day %", aggregation="ratio",
             numerator="ACATS Transfer In rows whose validation_date is no later than one business day after the "
                       "originating request's received_timestamp",
             denominator="ACATS Transfer In rows validated",
             source=("DP-448", "Transfers In Validated Within One Business Day %"),
             description="Share of incoming ACATS transfers validated within one business day of the client's request "
                         "(receiving side only)."),
        dict(name="Settled Within Three Business Days of Validation %", aggregation="ratio",
             numerator="ACATS transfers settled in the period with transfer_settlement_date no later than three business "
                       "days after validation_date",
             denominator="ACATS transfers settled in the period",
             source=("DP-448", "Settled Within Three Business Days of Validation %"),
             description="Share of ACATS transfers completed within three business days of validation (FINRA Rule "
                         "11870)."),
        dict(name="Transfer Cycle Days", aggregation="non_additive",
             expr="median and 90th percentile of business days from transfer_request.received_timestamp to "
                  "transfer_settlement_date", source=("DP-448", "Transfer Cycle Days"),
             description="How long transfers take from request to settlement, by channel and direction.",
             note="Percentiles: recomputed from detail rows for each slice."),
        dict(name="Transfer Value by Direction", aggregation="additive",
             expr="sum(transfer_asset_line.transfer_asset_quantity x transfer_price.approved_price_value + "
                  "transfer_asset_line.transfer_cash_amount) of settled transfers",
             source=("DP-448", "Transfer Value by Direction"),
             description="Value of assets moved by settled transfers, by direction and channel.",
             note="An operational transfer value, never labeled Net New Assets (CW-230)."),
        dict(name="Net Transfer Value", aggregation="additive",
             expr="[Transfer Value by Direction] of Transfer In - that of Transfer Out, excluding Internal Re-Registration",
             source=("DP-448", "Net Transfer Value"),
             description="Value transferred in minus value transferred out."),
        dict(name="Net Transfer Value Share of Net New Assets", aggregation="ratio",
             numerator="[Net Transfer Value] for the period",
             denominator="[Net New Assets] (SM-20) for the same period, firm total (Dimension Type Total), locked snapshot",
             source=("DP-448", "Net Transfer Value Share of Net New Assets"),
             description="Share of Net New Assets carried by account transfers, firm total only.",
             note="Transfer value has no channel, so no channel cut; shown beside the certified figure, never added to it."),
        dict(name="Non-Transferable Asset Lines", aggregation="additive",
             expr="count(transfer_asset_line) where non_transferable_reason is not null (with transfer_asset_quantity)",
             source=("DP-448", "Non-Transferable Asset Lines"),
             description="Transfer asset lines that could not move, by reason and direction."),
        dict(name="Debit Balances Transferred", aggregation="additive",
             expr="count and sum(account_transfer.debit_balance_transferred) where it is not zero",
             source=("DP-448", "Debit Balances Transferred"),
             description="Transfers that carried a debit balance, by direction."),
        dict(name="Asset Lines Without Resulting Activity", aggregation="additive",
             expr="count(transfer_asset_line of settled transfers whose resulting_activity is blank one business day "
                  "after transfer_settlement_date)", source=("DP-448", "Asset Lines Without Resulting Activity"),
             description="Transferred assets not yet booked to the client account."),
        dict(name="Inbound Cost Basis Statements Late or Missing", aggregation="additive",
             expr="count(cost_basis_statement received late or missing after statement_due_date) + count(settled "
                  "Transfer In transfers with an asset line whose line_cost_basis_transfer_statement is blank 15 days "
                  "after settlement)", source=("DP-448", "Inbound Cost Basis Statements Late or Missing"),
             description="Cost basis statements the firm is still owed by delivering firms (Treas. Reg. 1.6045A-1), by "
                         "counterparty firm."),

        # ======================= DP-445 Customer reserve and possession or control ===========================
        dict(name="Customer Reserve Requirement", aggregation="semi_additive",
             expr="sum(reserve_computation.reserve_requirement_amount) where reserve_computation_type = 'Customer' and "
                  "computation_approval_status = 'Approved'",
             time_rule="latest computation date in the selected range",
             source=("DP-445", "Customer Reserve Requirement"),
             description="The customer reserve requirement of the latest approved computation, by computing "
                         "broker-dealer (SEC Rule 15c3-3(e) and Exhibit A).",
             note="The one published reserve requirement; DP-600 and DP-205 read it and never recompute it (CW-262)."),
        dict(name="PAB Reserve Requirement", aggregation="semi_additive",
             expr="sum(reserve_computation.reserve_requirement_amount) where reserve_computation_type = 'PAB' and "
                  "computation_approval_status = 'Approved'",
             time_rule="latest computation date in the selected range", source=("DP-445", "PAB Reserve Requirement"),
             description="The reserve requirement for proprietary accounts of broker-dealers (usually zero)."),
        dict(name="Reserve Deposit on Hand", aggregation="semi_additive",
             expr="sum(Reserve Deposit on Hand) of the approved computation of each reserve_computation_type (never "
                  "summed across Customer and PAB, never over the bank accounts listed)",
             time_rule="latest computation date in the selected range", source=("DP-445", "Reserve Deposit on Hand"),
             description="Cash and qualified securities on deposit in the special reserve bank accounts."),
        dict(name="Required Reserve Deposit or Withdrawal", aggregation="semi_additive",
             expr="sum(reserve_computation.deposit_or_withdrawal_amount) of the approved computation (positive: deposit "
                  "due by deposit_deadline_timestamp; negative: withdrawal permitted)",
             time_rule="latest computation date in the selected range",
             source=("DP-445", "Required Reserve Deposit or Withdrawal"),
             description="The deposit due or withdrawal allowed after the latest computation, with its deadline."),
        dict(name="Reserve Excess or Deficiency", aggregation="semi_additive",
             expr="[Reserve Deposit on Hand] - sum(reserve_requirement_amount) of the same approved computation",
             time_rule="latest computation date in the selected range", source=("DP-445", "Reserve Excess or Deficiency"),
             description="Reserve on deposit above (or below, a deficiency) the requirement."),
        dict(name="Deposits Not Evidenced by Next Computation", aggregation="additive",
             expr="count(approved reserve_computation with deposit_or_withdrawal_amount > 0 whose next approved computation "
                  "of the same broker-dealer and type shows Reserve Deposit on Hand below the prior requirement)",
             source=("DP-445", "Deposits Not Evidenced by Next Computation"),
             description="Required deposits that the next computation does not show were made."),
        dict(name="Computations Not Approved Before Deadline", aggregation="additive",
             expr="count(reserve_computation where computation_approval_status <> 'Approved' when "
                  "deposit_deadline_timestamp passes)", source=("DP-445", "Computations Not Approved Before Deadline"),
             description="Reserve computations still unapproved when the deposit deadline passed."),
        dict(name="Exhibit A Line Totals", aggregation="semi_additive",
             expr="sum(reserve_line.line_amount) by exhibit_a_formula_item of the approved computation",
             time_rule="latest computation date in the selected range", source=("DP-445", "Exhibit A Line Totals"),
             description="The Exhibit A credit and debit items of the reserve computation."),
        dict(name="Exhibit A Tie-Out Breaks", aggregation="additive",
             expr="count(approved reserve_computation where credit lines <> total_credits, or debit lines reduced by "
                  "debit_items_reduction_pct <> total_debits, or reserve_requirement_amount <> max(0, total_credits - "
                  "total_debits), by more than USD 1)", source=("DP-445", "Exhibit A Tie-Out Breaks"),
             description="Reserve computations whose lines do not add up to their totals."),
        dict(name="Free Credit Balances to Exhibit A Item 1 Difference", aggregation="non_additive",
             expr="[Free Credit Balances] on the computation date - the line_amount of the customer computation's line "
                  "with supporting_cash_balance_type = 'Free Credit Balance'",
             source=("DP-445", "Free Credit Balances to Exhibit A Item 1 Difference"),
             description="Difference between client free credit balances and the reserve computation's item 1.",
             note="The 49 balances are read aggregated, never by account."),
        dict(name="Margin Debits to Exhibit A Item 10 Difference", aggregation="non_additive",
             expr="sum(cash_balance.cash_balance_amount) where cash_balance_type = 'Margin Debit Balance' on the "
                  "computation date - the line_amount of the line with supporting_cash_balance_type = 'Margin Debit "
                  "Balance'", source=("DP-445", "Margin Debits to Exhibit A Item 10 Difference"),
             description="Difference between client debit balances on the settlement-date cash book and Exhibit A "
                         "item 10."),
        dict(name="Aggregate Debit Items Tie to Net Capital", aggregation="non_additive",
             expr="capital_calculation.capital_aggregate_debit_items - reserve_computation.aggregate_debit_items_amount "
                  "of the customer computation it names", source=("DP-445", "Aggregate Debit Items Tie to Net Capital"),
             description="Check that net capital uses the same aggregate debit items as the reserve computation (must "
                         "be zero)."),
        dict(name="Daily Computation Required", aggregation="non_additive",
             expr="flag per computing_broker_dealer: average_total_credits (customer plus PAB) >= USD 250 million and "
                  "reserve_computation_frequency <> 'Daily'", source=("DP-445", "Daily Computation Required"),
             description="Broker-dealers whose credits require a daily reserve computation but that compute weekly (SEC "
                         "Rule 15c3-3(e)(3)(i))."),
        dict(name="Securities Out of Possession or Control", aggregation="semi_additive",
             expr="count distinct possession_control.determination_instrument and sum(deficit_quantity) where "
                  "deficit_source <> 'No Deficit'", time_rule="latest determination business date in the selected range",
             source=("DP-445", "Securities Out of Possession or Control"),
             description="Client securities the firm does not hold in good control locations, by deficit source (SEC "
                         "Rule 15c3-3(d) and (h))."),
        dict(name="Possession or Control Deficit Market Value", aggregation="semi_additive",
             expr="sum(deficit_quantity x (sum(client_holding.market_value_usd) / sum(client_holding.trade_date_quantity) "
                  "of End of Day holdings in the instrument on the date))",
             time_rule="latest determination business date in the selected range",
             source=("DP-445", "Possession or Control Deficit Market Value"),
             description="Market value of the client securities out of possession or control, by deficit source.",
             note="Unit value from the 49 Client Holding book (DP-300), aggregated by instrument; the determination "
                  "carries no price."),
        dict(name="Deficits Past Action Deadline", aggregation="semi_additive",
             expr="[Securities Out of Possession or Control] where action_deadline_date < determination_business_date, by "
                  "age bucket of deficit_age_days (0 to 5, 6 to 30, 31 to 45, over 45)",
             time_rule="latest determination business date in the selected range",
             source=("DP-445", "Deficits Past Action Deadline"),
             description="Possession-or-control deficits not cured by their action deadline, by age."),
        dict(name="Determination Arithmetic Breaks", aggregation="additive",
             expr="count(possession_control where max(0, fully_paid_quantity_required + excess_margin_quantity_required - "
                  "quantity_at_good_control_locations) differs from the instrument and date's total deficit_quantity)",
             source=("DP-445", "Determination Arithmetic Breaks"),
             description="Possession-or-control determinations whose arithmetic does not hold."),
        dict(name="Segregated Quantity Below Requirement", aggregation="semi_additive",
             expr="count(instruments where sum(client_holding.segregated_quantity) < fully_paid_quantity_required + "
                  "excess_margin_quantity_required by more than 0.0001 shares)",
             time_rule="latest determination business date in the selected range",
             source=("DP-445", "Segregated Quantity Below Requirement"),
             description="Instruments where client holdings segregated are below the quantity the firm must control."),
        dict(name="Determinations Counting Unapproved Locations", aggregation="additive",
             expr="count(possession_control whose counted locations include a control_location not Approved or outside "
                  "its effective period on the date)", source=("DP-445", "Determinations Counting Unapproved Locations"),
             description="Determinations that count securities at locations that are not good control locations."),
    ],

    excluded=[
        ("DP-300", "Own-Fund Client Holdings Market Value",
         "The same 49 number is published in SM-20 from DP-496's copy (from DP-300) and referenced here as "
         "SM-20/Own-Fund Client Holdings Market Value; it reads client_holding.market_value_usd where "
         "own_share_class_indicator = 'Y' and is never joined to an 06 Fund Shareholder Position."),
        # Copies a consumer product republishes "(from DP-nnn)": the owning product's metric is published once.
        ("DP-436", "Price Improvement Amount (from DP-301)",
         "A copy of DP-301 Price Improvement Amount, published once from DP-301 and sliced by route venue and client "
         "order type through order_route and client_order."),
        ("DP-437", "Trade Corrections (from DP-301)", "A copy of DP-301 Trade Corrections, published once from DP-301."),
        ("DP-437", "Corrections per 10,000 Allocations (from DP-301)",
         "A copy of DP-301 Corrections per 10,000 Allocations, published once from DP-301 and sliceable by correction "
         "reason and order source."),
        ("DP-448", "Account Transfers by Status (from DP-300)",
         "A copy of DP-300 Account Transfers by Status, published once from DP-300."),
        ("DP-448", "Late Cost Basis Transfer Statements (from DP-300)",
         "A copy of DP-300 Late Cost Basis Transfer Statements, published once from DP-300."),
        ("DP-448", "Net New Assets (from DP-008)",
         "A copy of the certified Net New Assets; referenced as SM-20/Net New Assets."),
        ("DP-457", "Sweep Allocated Balance (from DP-302)",
         "A copy of DP-302 Sweep Allocated Balance, published once from DP-302; the count of accounts allocated is count "
         "distinct allocation_account on sweep_allocation."),
        ("DP-457", "Daily Net Flow to Program Banks (from DP-431)",
         "A copy of DP-431 Daily Net Flow to Program Banks, published once from DP-431; the Settlement Wire IMAD is a "
         "payment identifier and not published."),
        ("DP-457", "Sweep Balances (from DP-300)", "A copy of DP-300 Sweep Balances, published once from DP-300."),
        ("DP-457", "Uninsured Deposits (from DP-431)",
         "A copy of DP-431 Uninsured Deposits, published once from DP-431; Insured Amount sits beside it on fdic_assessment."),
        ("DP-457", "Parties With Uninsured Deposits (from DP-431)",
         "A copy of DP-431 Parties With Uninsured Deposits, published once from DP-431; the party list is visible to the "
         "client service role only."),
        ("DP-457", "Client Assets in Cash and Sweep (from DP-008)",
         "A copy of the certified Client Assets at Holding Type Cash and Sweep; referenced as SM-20/Client Assets."),
        ("DP-457", "Net Spread (from DP-012)",
         "Cash program economics are DP-012's, published in SM-28 (Client Economics); referenced from there once SM-28 "
         "defines a Net Spread metric (open decision)."),
    ],

    access=dict(
        classification="Confidential - Client (account-level holdings, lots, activity, orders, executions, "
                       "allocations, confirmations, movements, holds, allocations to banks, transfers and FDIC party "
                       "rows: personal data, financial tier); Confidential - Financial (DP-445 reserve and "
                       "possession-or-control figures); Confidential (DP-432 venues, routing rules and Rule 605 lines)",
        roles=[
            dict(role="brokerage_operations",
                 rows="all accounts, holdings, lots, activity, orders, allocations, confirmations, corrections, error "
                      "cases and transfers; money movement and holds as for money_movement_operations",
                 columns="all published columns",
                 hidden=["assessed_party"]),
            dict(role="money_movement_operations",            # money movement, fraud operations and the payments desk
                 rows="all money movements, events, returns, exceptions, published holds, fraud assessments and "
                      "non-special monitoring alerts. Special-category (CD-344) and AML holds and alerts are not in the "
                      "model. Complementary suppression: hold counts, held amounts and movement status counts are shown "
                      "only where a cell holds at least the minimum cell size of movements, and a second cell is "
                      "suppressed with any suppressed cell, so that a suppressed hold cannot be derived by subtracting "
                      "published holds or statuses from a total (DP-302 publishes the pre-hold status for a movement "
                      "held only under a suppressed hold)",
                 columns="all published money movement columns; account keys for case work",
                 hidden=["holding_account", "lot_account", "order_account", "allocated_account", "assessed_party"]),
            dict(role="best_execution_committee",              # trading, best execution and the committee
                 rows="all orders, routes, executions, venues, routing rules, execution quality, Rule 605 and Rule 606 "
                      "lines, committee reviews, corrections and error cases; account rows only as aggregates",
                 columns="all trading, venue and quality columns; no account or party keys",
                 hidden=["order_account", "allocated_account", "error_account", "holding_account", "movement_account"]),
            dict(role="financial_operations_principal",        # FINOP, regulatory reporting and treasury
                 rows="all reserve computations, Exhibit A lines, capital ties, possession-or-control determinations and "
                      "control locations; client holdings and cash balances as aggregates by instrument, balance type "
                      "and date only",
                 columns="all DP-445 columns; client tables without account keys",
                 hidden=["holding_account", "cash_balance_account", "margin_snapshot_account", "allocation_account",
                         "movement_account", "assessed_party"]),
            dict(role="cash_programs",
                 rows="all sweep programs, program banks, participations, rate tiers, daily totals, sweep runs, "
                      "forecasts and allocations; FDIC assessments as aggregates by bank and ownership category",
                 columns="all sweep columns except party and account keys",
                 hidden=["assessed_party", "allocation_account", "cash_balance_account", "sweep_election_account"]),
            dict(role="client_service",
                 rows="accounts the viewer services; the FDIC party list (Parties With Uninsured Deposits with deposits "
                      "through the firm and client-declared direct deposits) for those clients only",
                 columns="account-level activity, holdings, transfers, movement status and published holds of the "
                         "serviced accounts; no fraud scores, monitoring alerts or trading quality detail",
                 hidden=["fraud_risk_score", "fraud_model", "monitoring_scenario", "alert_disposition",
                         "hold_reason"]),
            dict(role="broad_internal",                        # leadership, finance, product and analytics
                 rows="aggregates only: no row for a single account, client, movement, order or transfer; the "
                      "complementary suppression of money_movement_operations applies to every hold and status cell",
                 columns="aggregates by channel, account type, business line, instrument type, venue, program, bank, "
                         "rail and date",
                 hidden=["holding_account", "held_instrument", "lot_account", "relieved_client_tax_lot",
                         "activity_account", "cash_balance_account", "margin_snapshot_account", "entitled_account",
                         "lending_account", "order_account", "routed_client_order", "allocated_account",
                         "allocated_client_order", "error_account", "error_client_order", "movement_account",
                         "bank_instruction_used", "held_movement", "hold_reason", "assessed_movement", "resulting_hold",
                         "fraud_risk_score", "allocation_account", "assessed_party", "transfer_account", "contra_firm",
                         "originating_service_request", "sweep_election_account"]),
        ]),

    verified_questions=[
        dict(question="What was execution quality by venue and order type last month, and how did the Rule 605 report "
                      "compare? (acceptance question 5)",
             answer="[Price Improvement Rate by Venue], [Average Price Improvement Per Share by Venue] and [Effective Over "
                    "Quoted Spread by Venue] from execution_quality for the latest measurement period, by "
                    "execution_venue.venue_type, venue_mic, measure_order_class and measure_client_order_type; [Price "
                    "Improvement Amount] from client_execution through order_route.route_venue and "
                    "client_order.client_order_type; [Rule 605 Price-Improved Share %] and [Rule 605 Effective Spread "
                    "and Time to Execution] from rule_605_line for the latest report month by rule_605_order_type and "
                    "rule_605_order_size_bucket; [Routed NBBO Differs From 22 Quote] as the quote-evidence check.",
             sql="select v.venue_mic, q.measure_client_order_type, "
                 "sum(q.price_improvement_rate * q.measured_order_count) / sum(q.measured_order_count) as pi_rate "
                 "from dp_436.fact_execution_quality_measure q "
                 "join dp_432.execution_venue v on v.venue_party = q.measured_venue "
                 " and v.venue_profile_effective_from <= q.measure_period_end "
                 " and (v.venue_profile_effective_to is null or v.venue_profile_effective_to > q.measure_period_end) "
                 "where q.measure_period_end = (select max(measure_period_end) from dp_436.fact_execution_quality_measure) "
                 "group by v.venue_mic, q.measure_client_order_type"),
        dict(question="Which client orders were corrected last month, by correction type and order source? "
                      "(acceptance question 5)",
             answer="[Corrected Client Orders] and [Trade Corrections] from trade_correction joined to client_allocation "
                    "and client_order, by correction_type, trade_correction_reason, client_order.order_source and "
                    "client_order_type, the month taken from the resulting confirmation's confirmed_trade_date; "
                    "[Corrections per 10,000 Allocations] for the rate and [Venue Busts by Venue] through "
                    "client_execution.execution_venue_mic."),
        dict(question="What is today's customer reserve requirement, and is a deposit due? (acceptance question 6)",
             answer="[Customer Reserve Requirement], [Reserve Deposit on Hand], [Reserve Excess or Deficiency] and "
                    "[Required Reserve Deposit or Withdrawal] with deposit_deadline_timestamp from reserve_computation "
                    "for the latest computation_date, reserve_computation_type = 'Customer', computation_approval_status "
                    "= 'Approved', by computing_broker_dealer (DP-013 Internal Legal Entity); [Exhibit A Tie-Out Breaks] "
                    "and [Aggregate Debit Items Tie to Net Capital] as the controls. DP-445 is the single owner: no other "
                    "model restates the requirement.",
             sql="select c.computing_broker_dealer, c.reserve_requirement_amount, c.deposit_or_withdrawal_amount, "
                 "c.deposit_deadline_timestamp from dp_445.fact_reserve_computation c "
                 "where c.reserve_computation_type = 'Customer' and c.computation_approval_status = 'Approved' "
                 "and c.computation_date = (select max(computation_date) from dp_445.fact_reserve_computation "
                 " where reserve_computation_type = 'Customer' and computation_approval_status = 'Approved')"),
        dict(question="Are any client securities out of possession or control today, and for how long? (acceptance "
                      "question 6)",
             answer="[Securities Out of Possession or Control], [Possession or Control Deficit Market Value] and "
                    "[Deficits Past Action Deadline] from possession_control for the latest determination_business_date, "
                    "by deficit_source and the DP-097 instrument type; [Segregated Quantity Below Requirement] and "
                    "[Determinations Counting Unapproved Locations] as the controls. The unit value reads End of Day "
                    "client_holding rows aggregated by instrument (49 only)."),
        dict(question="Which cash movements are on hold for fraud review, and which holds are past expiry? (acceptance "
                      "question 7, published holds)",
             answer="[Active Money Movement Holds], [Held Amount] and [Holds Past Expiry] from movement_hold where "
                    "hold_type = 'Fraud', joined to money_movement by payment_rail and movement_direction; [Fraud "
                    "Decisions] and [Fraud Missed Rate %] from fraud_assessment by fraud_model. Elder-exploitation and "
                    "other special-category holds are not in this model: they are DP-403's restricted view in SM-29, "
                    "which owns the Rule 2165 clock."),
        dict(question="What share of certified cash Client Assets sits at program banks, and how close is each bank to "
                      "capacity?",
             answer="[Bank Sweep Share of Cash Client Assets] ([Sweep Balances] over [Client Assets] from SM-20 at Holding "
                    "Type Cash and Sweep, same period end); [Program Bank Capacity Utilization %], [Program Banks Near "
                    "Capacity] and [Program Bank Concentration %] by sweep_program_name and program_bank through "
                    "DP-240 Party."),
    ],

    cannot_answer=[
        dict(question="Which cash movements are on hold for elder-exploitation or other special-category review, and is "
                      "each within the FINRA Rule 2165 hold period?",
             why="Special-category holds (CD-344) are filtered out of DP-302 at ingestion and held only in the restricted "
                 "views DP-322, DP-456 and DP-403; the Rule 2165 clock is DP-403's in SM-29 (aggregates only for broad "
                 "roles). This model contributes the published fraud and other holds to acceptance question 7.",
             gap=""),
        dict(question="Which fails to deliver and receive are open, and how much do they cost?",
             why="Street settlement and fails are DP-447 Settlement & Fails, whose spec does not list the BI semantic "
                 "model delivery, so it is not published here.", gap=""),
        dict(question="Are all client orders reported to CAT on time, and are pre-trade limits reviewed annually?",
             why="CAT completeness and market access (SEC Rule 15c3-5) are DP-435 Order Lifecycle & CAT Completeness, "
                 "which does not list the BI semantic model delivery.", gap=""),
        dict(question="Is the NBBO recorded at routing evidenced by one consolidated quote record?",
             why="22 has no consolidated quote snapshot; the quote is approximated by 22 Price Observation Bid and Ask "
                 "rows within one second and compared with the 48 NBBO at route.", gap="GAP-48-001"),
        dict(question="How does execution quality compare across venues for the same order size outside Rule 605?",
             why="Execution Quality Measure has no measured order count by size bucket or notional size (DP-436 "
                 "taxonomy gap), so venue comparisons cannot be size-adjusted outside the Rule 605 lines.", gap=""),
        dict(question="Were outgoing ACATS transfers validated within one business day (FINRA Rule 11870(b))?",
             why="Account Transfer has no ACATS transfer initiation receipt timestamp, so Transfer Out rows, where the "
                 "carrying firm's validation duty falls, cannot be timed (DP-448 taxonomy gap).", gap=""),
        dict(question="What were a client's open tax lots on a past date?",
             why="Client Tax Lot has no as-of snapshot; past lot state must be rebuilt from acquisition dates and lot "
                 "reliefs (DP-300 taxonomy gap).", gap=""),
        dict(question="Can program banks be matched to the party master by FDIC certificate number?",
             why="02 has no FDIC certificate scheme or bank charter attribute; DP-431 keeps them on the Program Bank "
                 "profile as copies.", gap="GAP-50-001"),
    ],

    open_decisions=[
        "Own-Fund Client Holdings Market Value is owned by DP-300 but defined in SM-20 from DP-496's copy '(from "
        "DP-300)'; SM-24 references it. The register owners may prefer to move the definition here (source DP-300) "
        "and have SM-20 reference it, consistent with the rule that copies are excluded.",
        "Copies labeled '(from DP-nnn)': DP-436, DP-437, DP-448 and DP-457 republish 13 measures of DP-300, DP-301, "
        "DP-302, DP-431, DP-008 and DP-012 under suffixed names. The model publishes each once from its owner and "
        "excludes the copies; the product owners should decide whether the consumer specs keep them as display items "
        "or drop them as measures.",
        "One table per taxonomy object: Trade Correction is read from DP-437 (not DP-301), Account Transfer and Cost "
        "Basis Transfer Statement from DP-448 (not DP-300), Rule 605 lines from DP-432 (not DP-436), Sweep Allocation "
        "from DP-302 (not DP-457), Program Bank Daily Total and FDIC Coverage Assessment from DP-431 (not DP-457), and "
        "cash balances and client holdings from DP-300 (not DP-445 or DP-457). The order route is read from DP-301 with "
        "DP-436's NBBO columns as a one-to-one companion. Confirm with the Head of Brokerage Trading and the Head of "
        "Brokerage Operations.",
        "Net Spread (from DP-012) in DP-457 is excluded: cash program economics belong to SM-28. When SM-28 defines a "
        "Net Spread metric on DP-012 Cash Program Economics, add it here as ref='SM-28/Net Spread' beside "
        "Balance-Weighted Client Interest Rate.",
        "Complementary suppression of hold and status cells: the minimum cell size (a drafting assumption of 11 "
        "movements) and the choice of the second suppressed cell are for the privacy office and the Head of Retail "
        "Conduct to set, together with SM-29's aggregate release of the special-category holds, so that the published "
        "holds here and the aggregates there cannot be differenced.",
        "Hold Reason: DP-302 reads Hold Reason to apply its row filter and its measures are 'by Hold Type and Hold "
        "Reason' over published rows. The model publishes hold_reason over published rows to brokerage and money "
        "movement operations only; the Head of Money Movement should confirm that no published reason value can point "
        "to a suppressed case.",
        "Account Transfers by Status (DP-300) combines a count open on the date and a count settled in the period, so "
        "it is non_additive at the product grain; the DP-300 owner may split it into two measures.",
        "Reserve Computation has no version or supersedes attribute (DP-445 taxonomy gap): a correction overwrites the "
        "49 row and the published history is DP-445's own daily snapshot. Until 49 versions the computation, a "
        "reserve requirement shown for a past date is the last approved state, not the state as first reported.",
        "Trade Error Case is a monthly snapshot of open cases with no snapshot date attribute and no closed date "
        "(DP-437 taxonomy gap); the model takes the latest snapshot by default. The DP-437 owner should add a snapshot "
        "date so age and trend metrics can pin it in always_filter.",
        "Client Account (DP-093) is SCD type 2: every join to the shared Client Account pins the version in force on "
        "the row's date. It depends on SM-00 publishing DP-093 Account as the Client Account dimension (sibling work "
        "in progress at WP2).",
    ],
)
