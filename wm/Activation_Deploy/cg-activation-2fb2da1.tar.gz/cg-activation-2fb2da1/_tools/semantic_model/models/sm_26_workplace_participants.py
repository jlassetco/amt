"""SM-26 Workplace & Participants: recordkept plans and participants, balances and ledger activity, participant outcomes,
the separation-to-rollover funnel and plan sponsor servicing. See CONTRACT.md.

WP2 (CW-209; plan section 8.4). Products: DP-430 Participant Balances & Ledger (the recordkeeping book, 16), DP-466 Participant
Outcomes, DP-467 Rollover Capture and DP-514 Plan Sponsor Servicing & Plan Reviews. DP-094 Recordkept Plan & Participant Core,
DP-095 and DP-096 do not list the BI semantic model delivery, so their entities (plan, membership, elections, plan document,
menu, loans, distributions) are read through the logical models of DP-466 and DP-467, which conform them.
"""

# DP-008 rows exist at many dimension types, period types and snapshots; the channel table pins all three (CONTRACT rule 3).
_DP008_CHANNEL_QUARTER = [
    "dimension_type = 'Channel'",
    "period_type = 'QUARTER'",
    "snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in ('Final', 'Restated')) (locked snapshot only)",
]
# Participant-level identifiers: personal financial data (DP-430, DP-467: Confidential - Personal Data). Only participant
# services see them; every other role reads aggregates.
_PARTICIPANT_IDS = ["membership_id", "participant_party", "participant_account", "balance_membership", "hand_off_id",
                    "hand_off_membership", "contact_consent", "referral_advice_engagement", "referred_advisor",
                    "distribution_id", "distribution_membership", "receiving_account", "contribution_id",
                    "contribution_membership", "recommendation_id", "recommendation_engagement", "rollover_analysis_id",
                    "event_membership", "loan_id", "loan_membership", "assigned_account", "personal_return_account",
                    "personal_return_value", "highly_compensated_employee", "beneficiary_designation_on_file"]
# Special category (CD-344, CW-231, GAP-16-002): the Hardship and Disability values of Distribution Type disclose financial
# hardship and a health condition. Distribution type is never shown at row level to anyone; it is released only as a grouping
# of aggregate cells of at least 10 participants, with complementary suppression.
_SPECIAL_CATEGORY = ["withdrawal_distribution_type", "rollover_distribution_type"]
_PLAN_NAMES = ["plan_name", "plan_sponsor", "sponsor_ein", "external_institution_name"]

MODEL = dict(
    id="SM-26",
    status="Draft",
    description=(
        "Recordkept plans and their participants across every plan the firm recordkeeps: balances and ledger activity from the "
        "participant book (DP-430), participation, savings behavior and leakage (DP-466), the separation-to-rollover funnel "
        "into the direct business (DP-467) and plan sponsor servicing (DP-514), for workplace leadership, participant services, "
        "sponsor relationship managers and the advice and conduct teams. Participant facts are personal financial data: every "
        "role except participant services reads plan and cohort aggregates only, and hardship and disability distributions "
        "only as suppressed aggregates. Certified Client Assets, Net New Assets and Net Inter-Channel Transfers are read from "
        "SM-20; recordkept balances are a book value, never Client Assets."),
    questions=[
        "Which plan participants separated this quarter, and what share of their rollovers went into the direct business, "
        "set against the certified workplace-to-direct Net Inter-Channel Transfers? (acceptance question 10)",
        "How do participation, deferral rates, default investment and automatic-feature design compare across plans and "
        "plan entry cohorts?",
        "Where do participants leak retirement savings (loans, pre-retirement withdrawals, cash-outs at separation), shown "
        "only as plan and cohort aggregates?",
        "How healthy is the hand-off funnel from separation to consent, advice engagement and rollover, and how many referred "
        "rollovers lack PTE 2020-02 documentation?",
        "How well are plan sponsors serviced: plan reviews to cadence, open requests, conversions and blackout notices, and "
        "line-up changes?",
        "How large are recordkept balances by plan, money source and investment option, and how do they sit beside certified "
        "workplace Client Assets?",
    ],

    tables=[
        # --- DP-430 Participant Balances & Ledger: the recordkeeping book of record (16; not one of the CW-007 books) -------
        dict(name="participant_balance", product="DP-430", entity="Participant Balance", kind="Fact",
             grain="participant plan membership x money source x plan investment option x valuation date (daily snapshot)",
             default_filter="valuation_date = latest month-end valuation date in the selected range",
             dimensions=[dict(name="balance_membership", attr="Balance Membership"),
                         dict(name="valuation_date", attr="Valuation Date"),
                         dict(name="balance_contribution_source", attr="Balance Contribution Source")],
             facts=[dict(name="balance_market_value", attr="Balance Market Value"),
                    dict(name="vested_amount", attr="Vested Amount"),
                    dict(name="unit_balance", attr="Unit Balance")],
             hidden=[("Unit Value Applied", "A unit price used by the recordkeeping controls; no cross-row question needs it.")]),
        dict(name="ledger_posting", product="DP-430", entity="Participant Ledger Posting", kind="Fact",
             grain="one participant ledger posting (PLPST-), append-only",
             dimensions=[dict(name="posting_type", attr="Posting Type"),
                         dict(name="posting_trade_date", attr="Posting Trade Date"),
                         dict(name="posting_contribution_source", attr="Posting Contribution Source")],
             facts=[dict(name="posted_amount", attr="Posted Amount"),
                    dict(name="posted_units", attr="Posted Units")],
             hidden=[("Posting Source Record", "A multi-type source reference (GAP-16-001) used by the DP-430 controls only."),
                     ("Resulting Plan Fund Order", "Plan fund order key used by the DP-430 transfer-agent control only.")]),
        dict(name="investment_transfer", product="DP-430", entity="Participant Investment Transfer", kind="Fact",
             grain="one participant investment transfer (PEXC-)",
             dimensions=[dict(name="transfer_source", attr="Transfer Source"),
                         dict(name="transfer_status", attr="Transfer Status"),
                         dict(name="transfer_request_timestamp", attr="Transfer Request Timestamp")],
             facts=[dict(name="requested_transfer_amount", attr="Requested Transfer Amount")]),

        # --- Plan, membership and menu (DP-094 entities as DP-466 conforms them) ---------------------------------------
        dict(name="recordkept_plan", product="DP-466", entity="Recordkept Plan", kind="Dimension",
             dimensions=[dict(name="plan_name", attr="Plan Name"),
                         dict(name="plan_number", attr="Plan Number"),
                         dict(name="plan_type", attr="Plan Type"),
                         dict(name="plan_sponsor", attr="Plan Sponsor"),
                         dict(name="sponsor_ein", attr="Sponsor EIN")]),
        dict(name="plan_document", product="DP-466", entity="Plan Document", kind="Dimension",
             always_filter=["document_status = 'Active' (one active plan document per plan, so plan design is counted once)"],
             dimensions=[dict(name="administered_plan_type", attr="Administered Plan Type"),
                         dict(name="erisa_covered", attr="ERISA Covered Indicator"),
                         dict(name="safe_harbor_design", attr="Safe Harbor Design"),
                         dict(name="automatic_enrollment_type", attr="Automatic Enrollment Type"),
                         dict(name="default_deferral_rate", attr="Default Deferral Rate"),
                         dict(name="automatic_escalation_increment", attr="Automatic Escalation Increment"),
                         dict(name="loans_permitted", attr="Loans Permitted Indicator"),
                         dict(name="mandatory_cash_out_threshold", attr="Mandatory Cash-Out Threshold")]),
        dict(name="participant", product="DP-466", entity="Participant", kind="Dimension",
             always_filter=["the membership version in force on the as-of date (DP-094 memberships are SCD type 2)"],
             dimensions=[dict(name="membership_id", attr="Membership ID"),
                         dict(name="participant_party", attr="Participant"),
                         dict(name="participant_account", attr="Participant Account"),
                         dict(name="membership_status", attr="Membership Status"),
                         dict(name="eligibility_date", attr="Eligibility Date"),
                         dict(name="plan_entry_date", attr="Plan Entry Date",
                              note="Grouped by year it is the plan entry cohort of DP-466."),
                         dict(name="enrollment_method", attr="Enrollment Method"),
                         dict(name="automatic_enrollment_opt_out_date", attr="Automatic Enrollment Opt-Out Date"),
                         dict(name="highly_compensated_employee", attr="Highly Compensated Employee Indicator"),
                         dict(name="beneficiary_designation_on_file", attr="Beneficiary Designation on File")]),
        dict(name="deferral_election", product="DP-466", entity="Deferral Election", kind="Dimension",
             always_filter=["deferral election effective on the as-of date (Deferral Election Effective From / To)"],
             dimensions=[dict(name="election_source", attr="Election Source"),
                         dict(name="catch_up_election_type", attr="Catch-Up Election Type")],
             facts=[dict(name="pre_tax_deferral_pct", attr="Pre-Tax Deferral Percentage"),
                    dict(name="roth_deferral_pct", attr="Roth Deferral Percentage")]),
        dict(name="investment_election", product="DP-466", entity="Investment Election", kind="Bridge",
             grain="membership x plan investment option x election effective period",
             always_filter=["election effective on the as-of date (Investment Election Effective From / To)"],
             dimensions=[dict(name="default_election", attr="Default Election Indicator")],
             facts=[dict(name="allocation_pct", attr="Allocation Percentage")]),
        dict(name="plan_investment_option", product="DP-466", entity="Plan Investment Option", kind="Dimension",
             dimensions=[dict(name="menu_role", attr="Menu Role"),
                         dict(name="option_status", attr="Option Status"),
                         dict(name="option_added_date", attr="Option Added Date")]),
        dict(name="vested_balance", product="DP-466", entity="Vested Balance by Source", kind="Fact",
             grain="membership x employer money source x vested balance as-of date",
             default_filter="vested_balance_as_of_date = latest per membership and source",
             dimensions=[dict(name="vested_contribution_source", attr="Vested Contribution Source"),
                         dict(name="vested_balance_as_of_date", attr="Vested Balance As-Of Date")],
             facts=[dict(name="vested_pct", attr="Vested Percentage")]),

        # --- Savings behavior and leakage (16 records DP-466 reads directly; no foundation publishes them) --------------
        dict(name="participant_loan", product="DP-466", entity="Fact Participant Loan", kind="Fact",
             grain="one participant loan",
             dimensions=[dict(name="loan_id", attr="Loan ID"),
                         dict(name="loan_membership", attr="Loan Membership"),
                         dict(name="loan_status", attr="Loan Status")],
             facts=[dict(name="outstanding_principal_balance", attr="Outstanding Principal Balance"),
                    dict(name="original_principal_amount", attr="Original Principal Amount")]),
        # All paid distributions, including hardship and disability (special category): aggregates only, see access.
        dict(name="withdrawal", product="DP-466", entity="Restricted Distribution Request", kind="Fact",
             grain="one distribution request",
             always_filter=["distribution_status = 'Paid'"],
             dimensions=[dict(name="withdrawal_distribution_type", attr="Distribution Type",
                              note="Special category for Hardship and Disability (CD-344, GAP-16-002): a grouping of "
                                   "suppressed aggregate cells only, never shown at row level."),
                         dict(name="withdrawal_rollover_direction", attr="Rollover Direction"),
                         dict(name="withdrawal_payment_date", attr="Payment Date")],
             facts=[dict(name="withdrawal_gross_amount", attr="Gross Distribution Amount")],
             hidden=[("Distribution ID", "Row-level key of a special-category record; aggregates only."),
                     ("Distribution Membership", "Joins the distribution to the participant for counting; never displayed.")]),
        dict(name="annual_limit", product="DP-466", entity="Fact Annual Limit Tracking", kind="Fact",
             grain="membership x limit type x plan year",
             dimensions=[dict(name="limit_plan_year", attr="Limit Plan Year"),
                         dict(name="limit_type", attr="Limit Type")],
             facts=[dict(name="statutory_limit_amount", attr="Statutory Limit Amount"),
                    dict(name="year_to_date_amount", attr="Year-to-Date Amount")]),
        # Personal returns are DP-145's certified values (CW-011), read here only for the plan median; the methodology is
        # pinned in each metric's name (time-weighted or money-weighted), never mixed.
        dict(name="participant_return", product="DP-466", entity="Fact Personal Rate of Return", kind="Fact",
             grain="personal rate of return (account x period x method x fee basis x version), from DP-145",
             always_filter=["personal_return_status = 'Final'", "personal_return_subject_type = 'Account'",
                            "trailing 12-month period (Personal Return Period Start Date to Period End Date)"],
             dimensions=[dict(name="personal_return_account", attr="Personal Return Account"),
                         dict(name="personal_return_method", attr="Personal Return Method"),
                         dict(name="personal_return_fee_basis", attr="Personal Return Fee Basis"),
                         dict(name="personal_return_period_end", attr="Personal Return Period End Date")],
             facts=[dict(name="personal_return_value", attr="Personal Return Value")]),
        dict(name="managed_account_service", product="DP-466", entity="Plan Managed Account Service", kind="Bridge",
             grain="retirement plan x service offering x effective period",
             always_filter=["service in force on the as-of date (Service Effective From / To)"],
             dimensions=[dict(name="service_availability", attr="Service Availability"),
                         dict(name="fiduciary_basis", attr="Fiduciary Basis")]),
        dict(name="service_election", product="DP-466", entity="Participant Service Election", kind="Fact",
             grain="membership x service election type x effective period",
             always_filter=["election in force on the as-of date (Service Election Effective From / To)"],
             dimensions=[dict(name="service_election_type", attr="Service Election Type")]),
        dict(name="model_assignment", product="DP-466", entity="Model Assignment", kind="Dimension",
             always_filter=["assignment_status = 'Active' and in force on the as-of date (Assignment Effective From / To)"],
             dimensions=[dict(name="assigned_account", attr="Assigned Account"),
                         dict(name="assignment_status", attr="Assignment Status")]),

        # --- DP-467 Rollover Capture: separation, hand-off, rollover and recommendation (acceptance question 10) --------
        dict(name="separation", product="DP-467", entity="Fact Separation Event", kind="Fact",
             grain="membership x employment event type x event date (Termination and Retirement only)",
             always_filter=["employment_event_type in ('Termination', 'Retirement')"],
             dimensions=[dict(name="event_membership", attr="Event Membership"),
                         dict(name="employment_event_type", attr="Employment Event Type"),
                         dict(name="employment_event_date", attr="Employment Event Date")]),
        dict(name="hand_off", product="DP-467", entity="Fact Participant Retail Hand-Off", kind="Fact",
             grain="one participant retail hand-off (PRTHO-; membership x trigger); the DP-430 hand-off rows as DP-467 publishes them",
             dimensions=[dict(name="hand_off_id", attr="Hand-Off ID"),
                         dict(name="hand_off_membership", attr="Hand-Off Membership"),
                         dict(name="hand_off_trigger", attr="Hand-Off Trigger"),
                         dict(name="trigger_date", attr="Trigger Date"),
                         dict(name="contact_consent", attr="Contact Consent"),
                         dict(name="referral_advice_engagement", attr="Referral Advice Engagement"),
                         dict(name="referred_advisor", attr="Referred Advisor"),
                         dict(name="hand_off_outcome", attr="Hand-Off Outcome"),
                         dict(name="outcome_date", attr="Outcome Date")],
             facts=[dict(name="hand_off_rollover_amount", attr="Hand-Off Rollover Amount")],
             hidden=[("Linked Distribution Request", "Join key to the paid distribution; the join uses Originating Hand-Off.")]),
        # Rollovers out only: the withdrawal table holds every paid distribution; the two are never added together.
        dict(name="rollover_out", product="DP-467", entity="Fact Distribution Request", kind="Fact",
             grain="one paid distribution request rolled out of a firm-recordkept plan",
             always_filter=["distribution_status = 'Paid'",
                            "rollover_direction in ('Direct Rollover Out', 'Indirect Rollover Out')"],
             dimensions=[dict(name="distribution_id", attr="Distribution ID"),
                         dict(name="distribution_membership", attr="Distribution Membership"),
                         dict(name="rollover_distribution_type", attr="Distribution Type",
                              note="Special category for Hardship and Disability (CD-344, GAP-16-002): suppressed "
                                   "aggregate cells only."),
                         dict(name="rollover_direction", attr="Rollover Direction"),
                         dict(name="payment_date", attr="Payment Date"),
                         dict(name="receiving_account", attr="Receiving Account"),
                         dict(name="receiving_institution", attr="Receiving Institution"),
                         dict(name="auto_rollover_ira_provider", attr="Auto-Rollover IRA Provider"),
                         dict(name="originating_hand_off", attr="Originating Hand-Off")],
             facts=[dict(name="rollover_gross_amount", attr="Gross Distribution Amount")],
             hidden=[("Distribution Account", "The participant's plan account; the plan is reached through the membership.")]),
        dict(name="receiving_channel", product="DP-467", entity="Account Channel Assignment", kind="Bridge",
             grain="account x distribution channel x effective period (06, read through DP-008)",
             always_filter=["channel assignment in force on the distribution's Payment Date (Channel Effective From / To)"],
             dimensions=[dict(name="assigned_distribution_channel", attr="Assigned Distribution Channel"),
                         dict(name="assigned_business_line", attr="Assigned Business Line")]),
        dict(name="external_institution", product="DP-467", entity="External Institution", kind="Dimension",
             always_filter=["party_type is an organization (receiving institutions and IRA providers are firms)"],
             dimensions=[dict(name="external_institution_name", attr="Party Display Name"),
                         dict(name="external_institution_type", attr="Party Type")]),
        dict(name="rollover_contribution", product="DP-467", entity="Fact Rollover Contribution", kind="Fact",
             grain="one contribution record with incoming rollover detail",
             always_filter=["contribution_source in ('Rollover In', 'Roth Rollover In')"],
             dimensions=[dict(name="contribution_id", attr="Contribution ID"),
                         dict(name="contribution_membership", attr="Contribution Membership"),
                         dict(name="contribution_source", attr="Contribution Source"),
                         dict(name="rollover_source_type", attr="Rollover Source Type"),
                         dict(name="automatic_portability", attr="Automatic Portability Indicator"),
                         dict(name="distributing_institution", attr="Distributing Institution")],
             facts=[dict(name="contribution_amount", attr="Contribution Amount"),
                    dict(name="roth_basis_amount", attr="Roth Basis Amount")]),
        dict(name="rollover_recommendation", product="DP-467", entity="Fact Rollover Recommendation", kind="Fact",
             grain="one recommendation (RECOM-) of type Rollover, from DP-303",
             always_filter=["recommendation_type = 'Rollover'"],
             dimensions=[dict(name="recommendation_id", attr="Recommendation ID"),
                         dict(name="recommendation_engagement", attr="Recommendation Engagement"),
                         dict(name="recommendation_presented_timestamp", attr="Recommendation Presented Timestamp"),
                         dict(name="client_decision", attr="Client Decision"),
                         dict(name="client_decision_date", attr="Client Decision Date")]),
        # The PTE 2020-02 documentation columns feed only the DP-335 gap flag (SM-22's definition); they are not
        # re-scored here.
        dict(name="rollover_analysis", product="DP-467", entity="Fact Rollover Analysis", kind="Fact",
             grain="rollover recommendation x analysis (ROLV-), from DP-303",
             dimensions=[dict(name="rollover_analysis_id", attr="Rollover Analysis ID"),
                         dict(name="fiduciary_status_basis", attr="Fiduciary Status Basis"),
                         dict(name="rollover_analysis_status", attr="Rollover Analysis Status"),
                         dict(name="fiduciary_ack_delivered_date", attr="Fiduciary Acknowledgment Delivered Date"),
                         dict(name="conflicts_disclosure_delivered_date", attr="Services and Conflicts Disclosure Delivered Date"),
                         dict(name="rollover_reasons_delivered_date", attr="Rollover Reasons Delivered Date"),
                         dict(name="impartial_conduct_attestation", attr="Impartial Conduct Standards Attestation")],
             facts=[dict(name="rollover_amount", attr="Rollover Amount")],
             hidden=[("Best Interest Reasons", "Free text read only for the DP-335 flag condition (blank or not)."),
                     ("Analysis Completed Date", "Read by SM-22's DP-335 measures, not by a question here.")]),
        dict(name="best_interest_evidence", product="DP-467", entity="Fact Best Interest Evidence", kind="Fact",
             grain="recommendation x best interest obligation component",
             dimensions=[dict(name="best_interest_component", attr="Best Interest Component"),
                         dict(name="component_satisfied", attr="Component Satisfied Indicator")]),
        dict(name="referral_engagement", product="DP-467", entity="Advice Engagement", kind="Dimension",
             dimensions=[dict(name="engagement_delivery_channel", attr="Engagement Delivery Channel"),
                         dict(name="engagement_business_line", attr="Engagement Business Line"),
                         dict(name="engagement_status", attr="Engagement Status")]),

        # --- DP-008 certified values, read only to slice the referenced SM-20 metrics by channel --------------------------
        dict(name="channel_client_assets", product="DP-008", entity="Measure Value", kind="Fact",
             grain="channel x quarter end (locked snapshot); workplace and direct-business channels",
             always_filter=_DP008_CHANNEL_QUARTER,
             dimensions=[dict(name="channel_period_end_date", attr="Period End Date"),
                         dict(name="channel_dimension_key", attr="Dimension Key"),
                         dict(name="channel_business_line", attr="Business Line")],
             facts=[dict(name="ending_client_assets", attr="Ending Client Assets"),
                    dict(name="net_new_assets", attr="Net New Assets"),
                    dict(name="net_inter_channel_transfers", attr="Net Inter-Channel Transfers")]),

        # --- DP-514 Plan Sponsor Servicing & Plan Reviews ------------------------------------------------------------
        dict(name="plan_servicing", product="DP-514", entity="Fact Plan Servicing", kind="Fact",
             grain="recordkept plan x plan sponsor service relationship x quarter-end (monthly refresh)",
             default_filter="quarter-end = latest",
             dimensions=[dict(name="plan_review_cadence", attr="Plan Review Cadence"),
                         dict(name="sponsor_portal_access", attr="Sponsor Portal Access Indicator")],
             hidden=[("Plan Fiduciary Committee", "A plan role key; the committee members are not a cross-plan question.")]),
        dict(name="sponsor_relationship", product="DP-003", entity="Service Relationship", kind="Dimension",
             always_filter=["servicing_segment = 'Plan Sponsor - Recordkept'"],
             dimensions=[dict(name="servicing_segment", attr="Servicing Segment"),
                         dict(name="service_tier", attr="Service Tier"),
                         dict(name="service_relationship_status", attr="Service Relationship Status")]),
        dict(name="plan_sponsor_profile", product="DP-003", entity="Plan Sponsor Profile", kind="Dimension",
             dimensions=[dict(name="sponsor_employee_count", attr="Employee Count",
                              note="Banded into plan size bands for Sponsor Portal Adoption %.")]),
        dict(name="service_arrangement", product="DP-514", entity="Service Arrangement", kind="Dimension",
             always_filter=["arrangement_status = 'Active'"],
             dimensions=[dict(name="recordkeeping_program", attr="Recordkeeping Program"),
                         dict(name="payroll_integration_type", attr="Payroll Integration Type")]),
        dict(name="plan_review", product="DP-514", entity="Fact Plan Review", kind="Fact",
             grain="one plan review (12 Client Review of the sponsor relationship)",
             always_filter=["review_type in ('Plan Review', 'Fiduciary Committee Meeting')"],
             dimensions=[dict(name="review_type", attr="Review Type"),
                         dict(name="review_held_date", attr="Review Held Date"),
                         dict(name="review_outcome", attr="Review Outcome")]),
        dict(name="sponsor_request", product="DP-514", entity="Fact Sponsor Request", kind="Fact",
             grain="one plan sponsor service request",
             dimensions=[dict(name="request_type", attr="Request Type"),
                         dict(name="request_status", attr="Request Status"),
                         dict(name="request_sla_due", attr="Request SLA Due Timestamp")]),
        dict(name="sponsor_coverage", product="DP-514", entity="Service Coverage Assignment", kind="Bridge",
             grain="service employee x sponsor relationship x effective period",
             always_filter=["assignment in force at the quarter-end (Assignment Effective From / To)"],
             dimensions=[dict(name="primary_contact", attr="Primary Contact Indicator")],
             hidden=[("Assigned Service Employee", "Employee key; used for row access, names come from DP-009 for "
                                                   "workplace leadership only.")]),
        dict(name="fund_change", product="DP-514", entity="Fact Fund Change Event", kind="Fact",
             grain="one plan fund change event",
             dimensions=[dict(name="fund_change_type", attr="Fund Change Type"),
                         dict(name="mapping_effective_date", attr="Mapping Effective Date")]),
        dict(name="plan_conversion", product="DP-514", entity="Fact Plan Conversion", kind="Fact",
             grain="one plan conversion",
             dimensions=[dict(name="conversion_type", attr="Conversion Type"),
                         dict(name="conversion_status", attr="Conversion Status"),
                         dict(name="blackout_period_start", attr="Blackout Period Start"),
                         dict(name="blackout_period_end", attr="Blackout Period End"),
                         dict(name="blackout_notice_sent_date", attr="Blackout Notice Sent Date")]),
    ],

    shared=["DP-013/Calendar Date", "DP-004/Share Class", "DP-004/Service Offering", "DP-093/Account", "DP-240/Party",
            "DP-009/Employee", "DP-003/Institutional Client"],

    relationships=[
        # Book and ledger to the membership, menu and plan
        dict(frm="participant_balance", to="participant", on="participant_balance.balance_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="participant_balance", to="plan_investment_option",
             on="participant_balance.balance_investment_option = plan_investment_option.investment_option_id", type="many-to-one"),
        dict(frm="participant_balance", to="DP-013/Calendar Date",
             on="participant_balance.valuation_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="ledger_posting", to="participant", on="ledger_posting.posting_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="ledger_posting", to="plan_investment_option",
             on="ledger_posting.posting_investment_option = plan_investment_option.investment_option_id", type="many-to-one"),
        dict(frm="investment_transfer", to="participant", on="investment_transfer.transfer_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="participant", to="recordkept_plan", on="participant.membership_plan = recordkept_plan.party_id",
             type="many-to-one"),
        dict(frm="participant", to="DP-093/Account", on="participant.participant_account = account.account_id",
             type="many-to-one"),
        dict(frm="participant", to="DP-240/Party", on="participant.participant_party = party.party_id", type="many-to-one"),
        dict(frm="plan_investment_option", to="recordkept_plan", on="plan_investment_option.menu_plan = recordkept_plan.party_id",
             type="many-to-one"),
        dict(frm="plan_investment_option", to="DP-004/Share Class",
             on="plan_investment_option.offered_share_class = share_class.share_class_id", type="many-to-one"),
        dict(frm="plan_document", to="recordkept_plan", on="plan_document.administered_plan = recordkept_plan.party_id",
             type="one-to-one"),
        dict(frm="deferral_election", to="participant", on="deferral_election.election_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="investment_election", to="participant",
             on="investment_election.investment_election_membership = participant.membership_id", type="many-to-one"),
        dict(frm="investment_election", to="plan_investment_option",
             on="investment_election.elected_investment_option = plan_investment_option.investment_option_id",
             type="many-to-one",
             warning="A participant elects several options; count participants with count(distinct membership), never by "
                     "summing election rows."),
        dict(frm="vested_balance", to="participant", on="vested_balance.vested_balance_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="participant_loan", to="participant", on="participant_loan.loan_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="withdrawal", to="participant", on="withdrawal.distribution_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="annual_limit", to="participant", on="annual_limit.limit_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="participant_return", to="DP-093/Account", on="participant_return.personal_return_account = account.account_id",
             type="many-to-one"),
        dict(frm="participant_return", to="participant", on="participant_return.personal_return_account = participant.participant_account",
             type="many-to-one",
             warning="Reaches the plan through the participant account; an account that served two plan memberships "
                     "would appear under each."),
        dict(frm="managed_account_service", to="recordkept_plan",
             on="managed_account_service.managed_account_service_plan = recordkept_plan.party_id", type="many-to-one"),
        dict(frm="managed_account_service", to="DP-004/Service Offering",
             on="managed_account_service.managed_account_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="service_election", to="participant", on="service_election.service_election_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="model_assignment", to="DP-093/Account", on="model_assignment.assigned_account = account.account_id",
             type="many-to-one"),
        # Rollover funnel (DP-467)
        dict(frm="separation", to="participant", on="separation.event_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="hand_off", to="participant", on="hand_off.hand_off_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="hand_off", to="DP-013/Calendar Date", on="hand_off.trigger_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="hand_off", to="referral_engagement",
             on="hand_off.referral_advice_engagement = referral_engagement.advice_engagement_id", type="many-to-one"),
        dict(frm="hand_off", to="DP-009/Employee", on="hand_off.referred_advisor = employee.employee_id", type="many-to-one"),
        dict(frm="rollover_out", to="participant", on="rollover_out.distribution_membership = participant.membership_id",
             type="many-to-one"),
        dict(frm="rollover_out", to="hand_off", on="rollover_out.originating_hand_off = hand_off.hand_off_id",
             type="many-to-one"),
        dict(frm="rollover_out", to="DP-093/Account", on="rollover_out.receiving_account = account.account_id",
             type="many-to-one"),
        dict(frm="rollover_out", to="receiving_channel",
             on="rollover_out.receiving_account = receiving_channel.assigned_account and rollover_out.payment_date between "
                "receiving_channel.channel_effective_from and coalesce(receiving_channel.channel_effective_to, '9999-12-31')",
             type="many-to-one",
             warning="One channel assignment is in force per account on a date; without the date condition an account "
                     "that changed channel would count its rollover under each channel."),
        dict(frm="rollover_out", to="external_institution",
             on="rollover_out.receiving_institution = external_institution.party_id", type="many-to-one"),
        dict(frm="rollover_contribution", to="participant",
             on="rollover_contribution.contribution_membership = participant.membership_id", type="many-to-one"),
        dict(frm="rollover_contribution", to="external_institution",
             on="rollover_contribution.distributing_institution = external_institution.party_id", type="many-to-one"),
        dict(frm="rollover_recommendation", to="referral_engagement",
             on="rollover_recommendation.recommendation_engagement = referral_engagement.advice_engagement_id",
             type="many-to-one"),
        dict(frm="rollover_analysis", to="rollover_recommendation",
             on="rollover_analysis.rollover_recommendation = rollover_recommendation.recommendation_id", type="many-to-one"),
        dict(frm="best_interest_evidence", to="rollover_recommendation",
             on="best_interest_evidence.evidence_recommendation = rollover_recommendation.recommendation_id",
             type="many-to-one"),
        dict(frm="channel_client_assets", to="DP-013/Calendar Date",
             on="channel_client_assets.channel_period_end_date = calendar_date.calendar_date", type="many-to-one"),
        # Sponsor servicing (DP-514)
        dict(frm="plan_servicing", to="recordkept_plan", on="plan_servicing.serviced_retirement_plan = recordkept_plan.party_id",
             type="many-to-one"),
        dict(frm="plan_servicing", to="sponsor_relationship",
             on="plan_servicing.sponsor_service_relationship = sponsor_relationship.service_relationship_id", type="many-to-one"),
        dict(frm="plan_servicing", to="service_arrangement",
             on="plan_servicing.recordkeeping_service_arrangement = service_arrangement.service_arrangement_id",
             type="many-to-one"),
        dict(frm="sponsor_relationship", to="DP-003/Institutional Client",
             on="sponsor_relationship.client = institutional_client.institutional_client_party", type="many-to-one"),
        dict(frm="recordkept_plan", to="plan_sponsor_profile", on="recordkept_plan.plan_sponsor = plan_sponsor_profile.sponsor_party",
             type="many-to-one"),
        dict(frm="plan_review", to="sponsor_relationship",
             on="plan_review.reviewed_relationship = sponsor_relationship.service_relationship_id", type="many-to-one",
             warning="12 Client Review has no plan attribute: a review reaches the plan through the sponsor relationship, so "
                     "a sponsor with several recordkept plans counts the review under each plan."),
        dict(frm="sponsor_request", to="sponsor_relationship",
             on="sponsor_request.request_service_relationship = sponsor_relationship.service_relationship_id",
             type="many-to-one"),
        dict(frm="sponsor_coverage", to="sponsor_relationship",
             on="sponsor_coverage.covered_service_relationship = sponsor_relationship.service_relationship_id",
             type="many-to-many",
             warning="A relationship has several service employees; filter primary_contact = 'Y' before grouping by "
                     "employee, or plans count under each covering employee."),
        dict(frm="sponsor_coverage", to="DP-009/Employee", on="sponsor_coverage.assigned_service_employee = employee.employee_id",
             type="many-to-one"),
        dict(frm="fund_change", to="recordkept_plan", on="fund_change.change_plan = recordkept_plan.party_id",
             type="many-to-one"),
        dict(frm="plan_conversion", to="recordkept_plan", on="plan_conversion.converted_plan = recordkept_plan.party_id",
             type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Recordkept plan", levels=["recordkept_plan.plan_type", "recordkept_plan.plan_name"]),
        dict(name="Participant cohort", levels=["participant.membership_status", "participant.plan_entry_date"]),
        dict(name="Hand-off funnel", levels=["hand_off.hand_off_trigger", "hand_off.hand_off_outcome"]),
        dict(name="Receiving channel", levels=["receiving_channel.assigned_business_line",
                                               "receiving_channel.assigned_distribution_channel"]),
        dict(name="Plan menu", levels=["plan_investment_option.menu_role", "plan_investment_option.option_status"]),
    ],

    metrics=[
        # --- Certified, owned by SM-20; sliced here by the workplace and direct-business channels -----------------------
        dict(name="Client Assets", ref="SM-20/Client Assets",
             note="Read from channel_client_assets at Dimension Type Channel = Workplace - Recordkept Plan: DP-514's "
                  "Workplace Client Assets. Shown beside Participant Balance Market Value, never added to it."),
        dict(name="Net New Assets", ref="SM-20/Net New Assets",
             note="A rollover from a firm plan into a firm IRA is not Net New Assets (CW-142); it is an inter-channel transfer."),
        dict(name="Net Inter-Channel Transfers", ref="SM-20/Net Inter-Channel Transfers",
             note="Read from channel_client_assets for the quarter: the workplace channel outflow and the direct-business "
                  "channels' inflow. DP-467's Net Inter-Channel Transfers (from DP-008)."),

        # --- Recordkeeping book (DP-430) ---------------------------------------------------------------------------
        dict(name="Participant Balance Market Value", aggregation="semi_additive",
             expr="sum(participant_balance.balance_market_value)",
             time_rule="last valuation_date in the selected range (month-end by default)",
             source=("DP-430", "Participant Balance Market Value"),
             description="Recordkept balance of the selected participants, by plan, money source and investment option.",
             note="The recordkeeping book (16), never certified Client Assets and never compared to Firm AUM. DP-466 and "
                  "DP-514 (Plan Assets Recordkept) read this number; it is published once."),
        dict(name="Participant Vested Amount", aggregation="semi_additive",
             expr="sum(participant_balance.vested_amount)",
             time_rule="last valuation_date in the selected range",
             source=("DP-430", "Participant Vested Amount"),
             description="Vested part of the recordkept balance, by plan and money source."),
        dict(name="Participants With Balance", aggregation="count_distinct",
             expr="count(distinct participant_balance.balance_membership) where balance_market_value > 0 on the valuation date",
             source=("DP-430", "Participants With Balance"),
             description="Number of plan memberships holding a balance on the valuation date, by plan and membership status."),
        dict(name="Ledger Posted Amount", aggregation="additive",
             expr="sum(ledger_posting.posted_amount) where posting_trade_date in range",
             source=("DP-430", "Ledger Posted Amount"),
             description="Amount posted to participant ledgers in the period, by posting type and plan.",
             note="The participant flow source DP-006 copies; never Net New Assets. Count postings with count(*)."),
        dict(name="Pending Investment Transfers", aggregation="count_distinct",
             expr="count(distinct investment_transfer.investment_transfer_id) where transfer_status in ('Received', "
                  "'Pending Trade Date') and the as-of date is more than one business day after transfer_request_timestamp",
             source=("DP-430", "Pending Investment Transfers"),
             description="Participant fund exchanges still not traded more than one business day after they were requested.",
             note="The requested amount is sum(investment_transfer.requested_transfer_amount) over the same rows."),
        dict(name="Transfers Rejected for Excessive Trading", aggregation="count_distinct",
             expr="count(distinct investment_transfer.investment_transfer_id) where transfer_status = "
                  "'Rejected - Excessive Trading Restriction' and transfer_request_timestamp in range",
             source=("DP-430", "Transfers Rejected for Excessive Trading"),
             description="Participant fund exchanges rejected under the plan's excessive trading restriction."),
        dict(name="Memberships Without Participant Account", aggregation="count_distinct",
             expr="count(distinct participant.membership_id) where participant_account is null or does not resolve to an "
                  "open DP-093 account",
             source=("DP-430", "Memberships Without Participant Account"),
             description="Plan memberships with no open participant account in the account master."),
        dict(name="Separated Participants Without Hand-Off", aggregation="count_distinct",
             expr="count(distinct participant.membership_id) where membership_status in ('Terminated with Balance', "
                  "'Retired with Balance') and the membership is in [Participants With Balance] and has no hand_off row",
             source=("DP-430", "Separated Participants Without Hand-Off"),
             description="Separated participants with a balance whom no retail hand-off has reached.",
             note="A status-based queue, not limited to the quarter's Separations (DP-467 reads it as DP-430 defines it)."),
        dict(name="Hand-Offs Open Past 90 Days", aggregation="count_distinct",
             expr="count(distinct hand_off.hand_off_id) where hand_off_outcome = 'Open' and trigger_date is more than "
                  "90 days before the as-of date",
             source=("DP-430", "Hand-Offs Open Past 90 Days"),
             description="Retail hand-offs still open more than 90 days after they were triggered, by trigger."),
        dict(name="Referrals Without Contact Consent", aggregation="count_distinct",
             expr="count(distinct hand_off.hand_off_id) where (referral_advice_engagement is not null or referred_advisor "
                  "is not null) and contact_consent is null",
             source=("DP-430", "Referrals Without Contact Consent"),
             description="Hand-offs referred to advice or an advisor without a recorded consent to contact."),
        dict(name="Hand-Off Rollover Amount", aggregation="additive",
             expr="sum(hand_off.hand_off_rollover_amount) where outcome_date in range",
             source=("DP-430", "Hand-Off Rollover Amount"),
             description="Amount rolled over on hand-offs whose outcome fell in the period, by outcome.",
             note="An operational amount, never the certified Net Inter-Channel Transfers."),

        # --- Participant outcomes (DP-466); published only in cells of at least 10 participants ---------------------------
        dict(name="Active Participants", aggregation="count_distinct",
             expr="count(distinct participant.membership_id) where membership_status = 'Active' on the as-of date",
             source=("DP-466", "Active Participants (from DP-094)"),
             description="Plan memberships active on the as-of date, by plan and plan entry cohort.",
             note="DP-094's definition, read exactly; DP-466 adds only the cohort cut."),
        dict(name="Participation Rate %", aggregation="ratio",
             numerator="count(distinct participant.membership_id) active on the as-of date with a deferral_election in "
                       "force whose pre_tax_deferral_pct + roth_deferral_pct > 0",
             denominator="[Active Participants]",
             source=("DP-466", "Participation Rate % (from DP-094)"),
             description="Share of active participants who are deferring on the as-of date.",
             note="DP-094's definition. DP-514 restates the rate on eligibility and plan entry dates; that version is not "
                  "published (see open decisions)."),
        dict(name="Average Deferral Rate %", aggregation="ratio",
             numerator="sum(deferral_election.pre_tax_deferral_pct + deferral_election.roth_deferral_pct) over deferring "
                       "active participants on the as-of date",
             denominator="count(distinct participant.membership_id) of the same deferring active participants",
             source=("DP-466", "Average Deferral Rate % (from DP-094)"),
             description="Mean deferral percentage of active participants who defer, by plan and election source."),
        dict(name="Automatic Enrollment Opt-Out Rate", aggregation="ratio",
             numerator="count(distinct participant.membership_id) where enrollment_method = 'Automatic Enrollment' and "
                       "automatic_enrollment_opt_out_date is not null",
             denominator="count(distinct participant.membership_id) where enrollment_method = 'Automatic Enrollment'",
             source=("DP-466", "Automatic Enrollment Opt-Out Rate"),
             description="Share of automatically enrolled participants who opted out, by plan and plan entry year."),
        dict(name="Default Investment Share %", aggregation="ratio",
             numerator="count(distinct participant.membership_id) active whose investment_election rows in force all have "
                       "default_election = 'Y'",
             denominator="[Active Participants]",
             source=("DP-466", "Default Investment Share % (from DP-094)"),
             description="Share of active participants invested entirely by default."),
        dict(name="QDIA Balance Share", aggregation="ratio",
             numerator="sum(participant_balance.balance_market_value) where plan_investment_option.menu_role = 'QDIA' at "
                       "the month-end valuation date",
             denominator="sum(participant_balance.balance_market_value) of the same plans at the same date",
             source=("DP-466", "QDIA Balance Share"),
             description="Share of plan balances held in the qualified default investment alternative."),
        dict(name="Single-Option Concentration", aggregation="ratio",
             numerator="count(distinct balance_membership) whose largest option other than a target date series member or "
                       "QDIA holds 90 percent or more of the membership's balance_market_value",
             denominator="[Participants With Balance]",
             source=("DP-466", "Single-Option Concentration"),
             description="Share of participants with a balance concentrated in one non-default option."),
        dict(name="Average Balance per Participant", aggregation="ratio",
             numerator="[Participant Balance Market Value]",
             denominator="[Participants With Balance]",
             source=("DP-466", "Average Balance per Participant"),
             description="Mean recordkept balance per participant with a balance, by plan and cohort.",
             note="DP-466 also shows the median per participant; a median is recomputed from detail rows, never averaged."),
        dict(name="Average Vested Percentage", aggregation="ratio",
             numerator="sum(vested_balance.vested_pct) of the latest row per membership and employer money source",
             denominator="count of the same rows",
             source=("DP-466", "Average Vested Percentage"),
             description="Average vesting of employer money, by plan and cohort."),
        dict(name="Participants With Outstanding Loan %", aggregation="ratio",
             numerator="count(distinct participant_loan.loan_membership) where loan_status in ('Active', 'Delinquent')",
             denominator="[Participants With Balance]",
             source=("DP-466", "Loan Usage and Leakage"),
             description="Share of participants with a balance who have an active or delinquent plan loan."),
        dict(name="Outstanding Loans to Balance %", aggregation="ratio",
             numerator="sum(participant_loan.outstanding_principal_balance) where loan_status in ('Active', 'Delinquent')",
             denominator="[Participant Balance Market Value] of the same participants",
             source=("DP-466", "Loan Usage and Leakage"),
             description="Outstanding loan principal as a share of the borrowers' balances: the leakage half of DP-466's measure."),
        dict(name="Pre-Retirement Withdrawals", aggregation="count_distinct",
             expr="count(distinct withdrawal.distribution_id) where withdrawal_distribution_type in ('Hardship', "
                  "'Emergency Personal Expense', 'In-Service Age 59 1/2') and withdrawal_payment_date in range",
             source=("DP-466", "Pre-Retirement Withdrawals"),
             description="Paid in-service and hardship withdrawals in the period, by plan.",
             note="Special category (CD-344, CW-231): shown only in cells of at least 10 participants with complementary "
                  "suppression, never by Hardship Reason (not read) and never at row level."),
        dict(name="Pre-Retirement Withdrawal Amount", aggregation="additive",
             expr="sum(withdrawal.withdrawal_gross_amount) over the rows of [Pre-Retirement Withdrawals]",
             source=("DP-466", "Pre-Retirement Withdrawals"),
             description="Gross amount of paid in-service and hardship withdrawals in the period, by plan.",
             note="The same suppression as Pre-Retirement Withdrawals."),
        dict(name="Cash-Out at Separation Rate", aggregation="ratio",
             numerator="count(distinct withdrawal.distribution_id) where withdrawal_distribution_type in ('Termination Lump "
                       "Sum', 'Mandatory Cash-Out') and withdrawal_rollover_direction = 'Not a Rollover' in range",
             denominator="count(distinct withdrawal.distribution_id) of all paid termination distributions in range",
             source=("DP-466", "Cash-Out at Separation Rate"),
             description="Share of termination distributions taken in cash rather than rolled over."),
        dict(name="Participants at Deferral Limit", aggregation="count_distinct",
             expr="count(distinct annual_limit.limit_membership) where limit_type = '402(g) Elective Deferral' and "
                  "year_to_date_amount >= statutory_limit_amount for the plan year",
             source=("DP-466", "Participants at Deferral Limit"),
             description="Participants who have reached the 402(g) elective deferral limit for the plan year."),
        dict(name="Median Participant Personal Return (Time-Weighted)", aggregation="non_additive",
             expr="median(participant_return.personal_return_value) where personal_return_method = 'Time-Weighted', by "
                  "personal_return_fee_basis",
             source=("DP-466", "Median Personal Return Value (from DP-145)"),
             description="Median trailing 12-month time-weighted personal return of the plan's participant accounts.",
             note="A statistic over DP-145's certified Personal Rate of Return values (ref SM-08), never recomputed; "
                  "always grouped by fee basis; recomputed from rows for each plan, never averaged across plans."),
        dict(name="Median Participant Personal Return (Money-Weighted)", aggregation="non_additive",
             expr="median(participant_return.personal_return_value) where personal_return_method = 'Money-Weighted', by "
                  "personal_return_fee_basis",
             source=("DP-466", "Median Personal Return Value (from DP-145)"),
             description="Median trailing 12-month money-weighted personal return of the plan's participant accounts.",
             note="As the time-weighted median; the two methods are never shown as one metric."),
        dict(name="Plans Offering Managed Accounts", aggregation="count_distinct",
             expr="count(distinct managed_account_service.managed_account_service_plan) in force on the as-of date",
             source=("DP-466", "Plans Offering Managed Accounts"),
             description="Plans with a participant managed account service in force, by availability and fiduciary basis."),
        dict(name="Participant Managed Account Enrollment Rate", aggregation="ratio",
             numerator="count(distinct participant.membership_id) whose participant_account has an active model_assignment "
                       "in force on the as-of date",
             denominator="[Participants With Balance] in plans with a managed_account_service in force",
             source=("DP-466", "Participant Managed Account Enrollment Rate"),
             description="Share of participants with a balance enrolled in the plan's managed account service.",
             note="Enrollment is inferred from a 46 Model Assignment (DP-466 taxonomy gap); not Advised Assets."),
        dict(name="Participant Service Elections per 1,000", aggregation="ratio",
             numerator="1000 x count(service_election) in force on the as-of date",
             denominator="count(distinct participant.membership_id) of the same plans",
             source=("DP-466", "Participant Service Elections"),
             description="Participant service elections (in-plan Roth conversion, PLESA, portability opt-out and others) "
                         "per 1,000 memberships, by election type."),

        # --- Rollover capture (DP-467): acceptance question 10 --------------------------------------------------------
        dict(name="Separations", aggregation="count_distinct",
             expr="count(distinct separation.event_membership) where employment_event_date in range",
             source=("DP-467", "Separations"),
             description="Plan participants who left employment or retired in the period, by plan.",
             note="Event-based; differs by design from DP-430's status-based Separated Participants Without Hand-Off."),
        dict(name="Participant Hand-Offs Triggered", ref="SM-22/Participant Hand-Offs Triggered",
             note="DP-393's definition, owned by SM-22; read here over the hand_off table by trigger and plan (DP-467 "
                  "reads it as DP-393 defines it)."),
        dict(name="Hand-Offs With Contact Consent %", ref="SM-22/Hand-Offs With Contact Consent %",
             note="DP-467's Contact Consent Rate restates this DP-393 rate; published once, from SM-22."),
        dict(name="Hand-Off to Advice Engagement Rate %", ref="SM-22/Hand-Off to Advice Engagement Rate %",
             note="DP-393's rate, owned by SM-22; DP-467 reads it as defined there."),
        dict(name="Hand-Off Capture Rate", aggregation="ratio",
             numerator="count(distinct hand_off.hand_off_id) where hand_off_outcome = 'Rolled to Firm IRA' and outcome_date in range",
             denominator="count(distinct hand_off.hand_off_id) where hand_off_outcome <> 'Open' and outcome_date in range",
             source=("DP-467", "Hand-Off Capture Rate"),
             description="Share of decided hand-offs that rolled into a firm IRA: the operational funnel capture rate.",
             note="Not a certified family; DP-008 publishes no certified rollover capture rate."),
        dict(name="Rollovers Out Paid", aggregation="additive",
             expr="sum(rollover_out.rollover_gross_amount) where payment_date in range",
             source=("DP-467", "Rollovers Out Paid"),
             description="Gross amount of paid direct and indirect rollovers out of firm-recordkept plans, by plan.",
             note="Count with count(distinct rollover_out.distribution_id)."),
        dict(name="Rollovers Into the Direct Business", aggregation="additive",
             expr="sum(rollover_out.rollover_gross_amount) where payment_date in range and receiving_account resolves to a "
                  "firm account whose receiving_channel in force on payment_date is a direct-business channel "
                  "(self-directed, advised or managed: lines DB, DA, HA and directly held fund accounts PF)",
             source=("DP-467", "Rollovers Into the Direct Business"),
             description="Rollovers out of firm plans that landed in the firm's direct business, by receiving business line.",
             note="An operational funnel value, never labeled Net New Assets or Client Assets (CW-230)."),
        dict(name="Direct Business Rollover Share", aggregation="ratio",
             numerator="[Rollovers Into the Direct Business] of memberships in [Separations] of the quarter",
             denominator="[Rollovers Out Paid] of the same memberships",
             source=("DP-467", "Direct Business Rollover Share"),
             description="Share of separated participants' rollovers that went into the direct business: acceptance question 10."),
        dict(name="Rollover Capture to Inter-Channel Transfer Difference", aggregation="non_additive",
             expr="[Rollovers Into the Direct Business] for the quarter minus the workplace-channel outflow of [Net "
                  "Inter-Channel Transfers] for the same quarter",
             source=("DP-467", "Rollover Capture to Inter-Channel Transfer Difference"),
             description="The residual between the funnel's rollovers into the direct business and the certified "
                         "workplace-to-direct transfers, explained by timing, indirect rollovers and non-rollover moves.",
             note="Shown only for the whole workplace channel by quarter: DP-008 has no plan dimension type."),
        dict(name="Rollovers to External Institutions", aggregation="additive",
             expr="sum(rollover_out.rollover_gross_amount) where payment_date in range and receiving_account is not a firm account",
             source=("DP-467", "Rollovers to External Institutions"),
             description="Rollovers out of firm plans to other institutions, by receiving institution and auto-rollover provider."),
        dict(name="Rollover Contributions Received", aggregation="additive",
             expr="sum(rollover_contribution.contribution_amount) where the contribution was received in range",
             source=("DP-467", "Rollover Contributions Received (from DP-095)"),
             description="Incoming rollovers into firm-recordkept plans, by rollover source type, automatic portability and "
                         "distributing institution.",
             note="DP-095's definition, read exactly; Roth basis is sum(roth_basis_amount)."),
        dict(name="Referred Rollover Recommendations", aggregation="count_distinct",
             expr="count(distinct rollover_recommendation.recommendation_id) where recommendation_presented_timestamp in "
                  "range and recommendation_engagement is the referral_advice_engagement of a hand_off",
             source=("DP-467", "Referred Rollover Recommendations"),
             description="Rollover recommendations made in engagements that began with a participant hand-off.",
             note="DP-335's Rollover Recommendations with the hand-off filter only."),
        dict(name="Referred Rollovers Without PTE 2020-02 Documentation", aggregation="count_distinct",
             expr="count(distinct rollover_recommendation.recommendation_id) of [Referred Rollover Recommendations] whose "
                  "DP-335 PTE Documentation Gap Flag = 'Y'",
             source=("DP-467", "Referred Rollovers Without PTE 2020-02 Documentation (from DP-335)"),
             description="Referred rollover recommendations that lack the PTE 2020-02 documentation, by plan and trigger.",
             note="The flag is SM-22's DP-335 definition (PTE Documentation Gap Flag), read exactly and never re-scored; "
                  "the rollover_analysis and best_interest_evidence columns are the inputs DP-335 names."),
        dict(name="Rollovers Without PTE 2020-02 Documentation", ref="SM-22/Rollovers Without PTE 2020-02 Documentation",
             note="All rollover recommendations with SM-22's DP-335 gap flag; the referred subset is the metric above."),
        dict(name="Referred Rollover PTE Gap Share %", aggregation="ratio",
             numerator="[Referred Rollovers Without PTE 2020-02 Documentation]",
             denominator="[Referred Rollover Recommendations]",
             source=("DP-467", "Referred Rollovers Without PTE 2020-02 Documentation (from DP-335)"),
             description="Share of referred rollover recommendations without PTE 2020-02 documentation."),
        dict(name="Days From Separation to Rollover", aggregation="non_additive",
             expr="median(hand_off.outcome_date - hand_off.trigger_date) where hand_off_outcome in ('Rolled to Firm IRA', "
                  "'Rolled to Firm-Recordkept Plan')",
             source=("DP-467", "Days From Separation to Rollover"),
             description="Median days from the hand-off trigger to the rollover into a firm account, by trigger and plan."),

        # --- Plan sponsor servicing (DP-514) ---------------------------------------------------------------------------
        dict(name="Serviced Recordkept Plans", aggregation="count_distinct",
             expr="count(distinct plan_servicing.serviced_retirement_plan) where sponsor_relationship.service_relationship_status "
                  "= 'Active' and service_arrangement is active",
             source=("DP-514", "Serviced Recordkept Plans"),
             description="Recordkept plans with an active sponsor service relationship, by service tier and recordkeeping program."),
        dict(name="New Participants by Enrollment Method", aggregation="count_distinct",
             expr="count(distinct participant.membership_id) where plan_entry_date in the quarter, by enrollment_method",
             source=("DP-514", "New Participants by Enrollment Method"),
             description="Participants who entered the plan in the quarter, by automatic or affirmative enrollment.",
             note="Automatic enrollments opted out in the quarter: the same count where automatic_enrollment_opt_out_date "
                  "is in the quarter."),
        dict(name="Plan Reviews Held to Cadence %", aggregation="ratio",
             numerator="[Serviced Recordkept Plans] whose latest plan_review.review_held_date is within the plan's "
                       "plan_review_cadence",
             denominator="[Serviced Recordkept Plans]",
             source=("DP-514", "Plan Reviews Held to Cadence %"),
             description="Share of serviced plans whose plan review or fiduciary committee meeting is up to date."),
        dict(name="Plans Due a Review in 60 Days", aggregation="count_distinct",
             expr="count(distinct plan_servicing.serviced_retirement_plan) whose latest review_held_date plus "
                  "plan_review_cadence falls within 60 days of the as-of date (overdue shown separately)",
             source=("DP-514", "Plans Due a Review in 60 Days"),
             description="Serviced plans with a review due in the next 60 days, and those already overdue."),
        dict(name="Line-Up Changes in Period", aggregation="count_distinct",
             expr="count(distinct fund_change.fund_change_id) where mapping_effective_date in range, by fund_change_type; "
                  "plus plan_investment_option rows added or closed in range, by menu_role",
             source=("DP-514", "Line-Up Changes in Period"),
             description="Fund changes and menu additions or closures in the period."),
        dict(name="Active Menu Options", aggregation="count_distinct",
             expr="count(distinct plan_investment_option.investment_option_id) where option_status = 'Active', by menu_role",
             source=("DP-514", "Active Menu Options"),
             description="Active investment options on plan menus, by menu role; plans with no QDIA option shown separately."),
        dict(name="Plan Conversions In Progress", aggregation="count_distinct",
             expr="count(distinct plan_conversion.conversion_id) where conversion_status <> 'Complete'",
             source=("DP-514", "Plan Conversions In Progress"),
             description="Plan conversions not yet complete, by conversion type, with their blackout periods."),
        dict(name="Blackout Notices Sent Late", aggregation="count_distinct",
             expr="count(distinct plan_conversion.conversion_id) where blackout_notice_sent_date is less than 30 days before "
                  "blackout_period_start, or is empty within 30 days of the start",
             source=("DP-514", "Blackout Notices Sent Late"),
             description="Conversions whose ERISA section 101(i) blackout notice was late or is missing."),
        dict(name="Open Sponsor Requests Past Standard", aggregation="count_distinct",
             expr="count(distinct sponsor_request.service_request_id) where request_status not in ('Resolved', 'Closed', "
                  "'Canceled') and request_sla_due is before the as-of timestamp",
             source=("DP-514", "Open Sponsor Requests Past Standard"),
             description="Plan sponsor requests open past their service standard, by request type."),
        dict(name="Sponsor Portal Adoption %", aggregation="ratio",
             numerator="[Serviced Recordkept Plans] with plan_servicing.sponsor_portal_access = 'Y'",
             denominator="[Serviced Recordkept Plans]",
             source=("DP-514", "Sponsor Portal Adoption %"),
             description="Share of serviced plans whose sponsor uses the portal, by plan size band (sponsor employee count)."),
        dict(name="Plans Without Primary Relationship Manager", aggregation="count_distinct",
             expr="count(distinct plan_servicing.serviced_retirement_plan) whose sponsor relationship has no sponsor_coverage "
                  "row with primary_contact = 'Y' in force at the quarter-end",
             source=("DP-514", "Plans Without Primary Relationship Manager"),
             description="Serviced plans with no primary relationship manager assigned."),
    ],

    excluded=[
        # DP-430 recordkeeping controls: row-level reconciliation checks run in the warehouse, no cross-row business question
        ("DP-430", "Unit Value Differs From NAV", "A recordkeeping control that compares each balance row with DP-165's "
                                                  "official NAV; it stays in the DP-430 operations dashboard at row level."),
        ("DP-430", "Balance Value Arithmetic Breaks", "A row-level arithmetic control of the book; operations dashboard only."),
        ("DP-430", "Balance Roll-Forward Breaks", "A unit roll-forward control of the book; operations dashboard only."),
        ("DP-430", "Postings Without Source Record", "Needs Posting Source Record, a multi-type reference (GAP-16-001); "
                                                     "operations dashboard only."),
        ("DP-430", "Postings Without Plan Fund Order", "Needs the DP-580 transfer-agent register, which this model does "
                                                       "not read; operations dashboard only."),
        # Copies published once from their owner
        ("DP-466", "Participant Balance Market Value (from DP-430)", "Published once as Participant Balance Market Value "
                                                                     "from DP-430."),
        ("DP-466", "Participation by Automatic Feature Design", "A grouping, not a new number: Participation Rate % and "
                                                                "Average Deferral Rate % by plan_document.automatic_enrollment_type, "
                                                                "default_deferral_rate and automatic_escalation_increment."),
        ("DP-467", "Separated Participants Without Hand-Off (from DP-430)", "Published once from DP-430."),
        ("DP-467", "Hand-Off Rollover Amount (from DP-430)", "Published once from DP-430."),
        ("DP-467", "Hand-Offs Open Past 90 Days (from DP-430)", "Published once from DP-430."),
        ("DP-467", "Participant Hand-Offs Triggered (from DP-393)", "DP-393's count, published once by SM-22: ref "
                                                                     "SM-22/Participant Hand-Offs Triggered."),
        ("DP-467", "Contact Consent Rate", "The same formula as DP-393's Hand-Offs With Contact Consent %: published once "
                                           "by SM-22 (ref)."),
        ("DP-467", "Hand-Off to Advice Engagement Rate % (from DP-393)", "DP-393's rate, published once by SM-22: ref "
                                                                         "SM-22/Hand-Off to Advice Engagement Rate %."),
        ("DP-467", "Net Inter-Channel Transfers (from DP-008)", "A certified number: published as ref SM-20/Net "
                                                                 "Inter-Channel Transfers, sliced by channel_client_assets."),
        ("DP-514", "Workplace Client Assets (from DP-008)", "A certified number: published as ref SM-20/Client Assets at "
                                                            "the Workplace - Recordkept Plan channel (channel_client_assets)."),
        ("DP-514", "Plan Assets Recordkept (from DP-430)", "Published once as Participant Balance Market Value (DP-430), "
                                                           "grouped by plan at the quarter-end valuation date."),
        ("DP-514", "Active Participants", "Published once from DP-466 (DP-094's definition); the 'with a balance' half is "
                                          "Participants With Balance."),
        ("DP-514", "Participation Rate % (from DP-094)", "DP-514 restates the rate on eligibility and plan entry dates, "
                                                         "which is not DP-094's definition; Participation Rate % is "
                                                         "published from DP-466 (see open decisions)."),
    ],

    access=dict(
        classification="Confidential - Personal Data (DP-430, DP-467); DP-466 and DP-514 publish aggregates "
                       "(Confidential - Client); hardship and disability distributions are special category (CD-344)",
        roles=[
            dict(role="participant_services",       # hand-off, rollover and participant operations
                 rows="all memberships of firm-recordkept plans",
                 columns="participant-level columns for case work; distribution type only as aggregates",
                 hidden=_SPECIAL_CATEGORY + ["highly_compensated_employee", "beneficiary_designation_on_file",
                                             "personal_return_value"]),
            dict(role="workplace_leadership",
                 rows="all plans",
                 columns="plan, cohort, channel and trigger aggregates; DP-466 cells of at least 10 participants with "
                         "complementary suppression; distribution type only as a grouping of suppressed cells",
                 hidden=_PARTICIPANT_IDS + _SPECIAL_CATEGORY),
            dict(role="sponsor_relationship_manager",
                 rows="plans whose sponsor relationship the viewer covers (sponsor_coverage in force)",
                 columns="plan-level aggregates and DP-514 servicing facts; no participant rows",
                 hidden=_PARTICIPANT_IDS + _SPECIAL_CATEGORY),
            dict(role="advice_and_conduct",          # rollover supervision and PTE 2020-02 review (reads SM-22 and SM-29)
                 rows="referred rollover recommendations and their hand-offs",
                 columns="recommendation and analysis columns; no balances, loans or withdrawals",
                 hidden=_SPECIAL_CATEGORY + ["highly_compensated_employee", "beneficiary_designation_on_file",
                                             "personal_return_value", "personal_return_account"]),
            dict(role="broad_internal",              # finance, product, marketing
                 rows="all plans",
                 columns="aggregates by plan type, size band, cohort, channel and quarter only, cells of at least 10 "
                         "participants with complementary suppression; no plan or institution names",
                 hidden=_PARTICIPANT_IDS + _SPECIAL_CATEGORY + _PLAN_NAMES),
        ]),

    verified_questions=[
        dict(question="Which plan participants separated this quarter, and what share of their rollovers went into the "
                      "direct business? (acceptance question 10)",
             answer="[Separations] for the quarter by recordkept_plan.plan_name (participant services see the memberships "
                    "through separation.event_membership); [Rollovers Out Paid] and [Rollovers Into the Direct Business] for "
                    "those memberships, and [Direct Business Rollover Share], with receiving_channel in force on payment_date; "
                    "beside them [Net Inter-Channel Transfers] (ref SM-20) for the quarter from channel_client_assets and "
                    "[Rollover Capture to Inter-Channel Transfer Difference]; [Referred Rollovers Without PTE 2020-02 "
                    "Documentation] uses SM-22's DP-335 flag.",
             sql="select p.plan_name, count(distinct s.event_membership) as separations, "
                 "sum(r.gross_distribution_amount) as rollovers_out_paid, "
                 "sum(case when c.assigned_distribution_channel in (select channel from direct_business_channels) "
                 "then r.gross_distribution_amount end) as into_direct_business "
                 "from dp_467.fact_separation_event s "
                 "join dp_466.participant m on s.event_membership = m.membership_id "
                 "join dp_466.recordkept_plan p on m.membership_plan = p.party_id "
                 "left join dp_467.fact_distribution_request r on r.distribution_membership = s.event_membership "
                 "and r.distribution_status = 'Paid' and r.rollover_direction in ('Direct Rollover Out', 'Indirect Rollover Out') "
                 "left join dp_467.account_channel_assignment c on r.receiving_account = c.assigned_account "
                 "and r.payment_date >= c.channel_effective_from and (c.channel_effective_to is null or r.payment_date < c.channel_effective_to) "
                 "where s.employment_event_type in ('Termination', 'Retirement') "
                 "and s.employment_event_date between :quarter_start and :quarter_end group by 1"),
        dict(question="How do participation and deferral rates compare by automatic enrollment design?",
             answer="[Participation Rate %] and [Average Deferral Rate %] on the as-of date grouped by "
                    "plan_document.automatic_enrollment_type and default_deferral_rate, cells of at least 10 participants."),
        dict(question="How much are participants leaking through loans, pre-retirement withdrawals and cash-outs, by plan type?",
             answer="[Participants With Outstanding Loan %], [Outstanding Loans to Balance %], [Pre-Retirement Withdrawals] "
                    "and [Pre-Retirement Withdrawal Amount] for the year, and [Cash-Out at Separation Rate], grouped by "
                    "recordkept_plan.plan_type; cells under 10 participants and their complements are suppressed and no "
                    "hardship reason is shown."),
        dict(question="How healthy is the hand-off funnel this quarter, by trigger?",
             answer="[Participant Hand-Offs Triggered], [Hand-Offs With Contact Consent %], [Hand-Off to Advice Engagement Rate %], [Hand-Off "
                    "Capture Rate], [Hand-Offs Open Past 90 Days] and [Days From Separation to Rollover], grouped by "
                    "hand_off.hand_off_trigger."),
        dict(question="Which plans are behind on reviews or have late blackout notices, by service tier?",
             answer="[Plan Reviews Held to Cadence %], [Plans Due a Review in 60 Days] and [Blackout Notices Sent Late] at "
                    "the latest quarter-end, grouped by sponsor_relationship.service_tier."),
        dict(question="How do recordkept balances compare with certified workplace Client Assets at quarter-end?",
             answer="[Participant Balance Market Value] at the quarter-end valuation date summed over all recordkept plans, "
                    "shown beside [Client Assets] (ref SM-20) at the Workplace - Recordkept Plan channel for the same "
                    "quarter-end; the two are compared, never added."),
    ],

    cannot_answer=[
        dict(question="Are participants on track for retirement income (projected income or replacement ratio)?",
             why="16 holds no projected retirement income or income replacement ratio; DP-466 shows readiness through "
                 "behavior and balance measures only. No gap is registered for it yet.",
             gap=""),
        dict(question="The certified rollover capture rate, or Net Inter-Channel Transfers by plan",
             why="DP-008 publishes no certified rollover capture rate, and 06 Measure Value has no plan dimension type, so "
                 "the certified transfers are shown for the whole workplace channel only. No gap is registered for it yet.",
             gap=""),
        dict(question="How many disability distributions were paid, by plan?",
             why="The Disability value of Distribution Type discloses a health condition and is not yet marked special "
                 "category; the model releases distribution types only as suppressed aggregates until 16 resolves it.",
             gap="GAP-16-002"),
        dict(question="Can participant units be proved to the transfer agent's plan omnibus register by key?",
             why="16 has no link from a plan or plan investment option to the 29 plan omnibus register account (DP-430 "
                 "taxonomy gap). No gap is registered for it yet.",
             gap=""),
        dict(question="What share of each plan's menu and balances is in the firm's own funds?",
             why="16 Plan Investment Option has no own-fund indicator (DP-514 taxonomy gap); share classes resolve through "
                 "DP-004, but the rule is not defined in the product. No gap is registered for it yet.",
             gap=""),
    ],

    open_decisions=[
        "Participation Rate %: DP-466 reads DP-094's definition (active participants deferring above zero / active "
        "participants); DP-514 states 'Participation Rate % (from DP-094)' as active memberships with a plan entry date / "
        "memberships eligible by the quarter-end, which is a different formula. The model publishes DP-466's. The DP-514 "
        "owner should restate the measure as DP-094 defines it or rename it (for example Eligible Enrollment Rate %).",
        "DP-514 Active Participants restates DP-094 Active Participants with a 'with a balance' variant; the model "
        "publishes DP-466's Active Participants and DP-430's Participants With Balance. Align DP-514's wording.",
        "DP-467 restates DP-393's Contact Consent Rate under its own name (Contact Consent Rate); the model publishes "
        "SM-22's Hand-Offs With Contact Consent % once. DP-467's spec should name it '(from DP-393)'.",
        "Referred Rollovers Without PTE 2020-02 Documentation is SM-22's Rollovers Without PTE 2020-02 Documentation "
        "filtered to recommendations in hand-off referral engagements; it keeps its own name because DP-467 defines the "
        "hand-off filter. Confirm with SM-22 that the 'no rollover_evidence row' branch of its definition is applied the same way.",
        "Special category: DP-466 Restricted Distribution Request and DP-467 Fact Distribution Request carry Distribution "
        "Type with the Hardship and Disability values. The model hides distribution type at row level from every role and "
        "releases it only as a grouping of cells of at least 10 participants with complementary suppression. GAP-16-002 "
        "should mark Disability special category (or route it through DP-322); confirm whether DP-467 should read "
        "rollover rows only so that Distribution Type is never Hardship or Disability there.",
        "DP-466 publishes cells of at least 10 participants (CW-225). Confirm that the semantic layer's suppression "
        "(minimum cell and complementary suppression) applies to every DP-466 metric for every role except participant "
        "services, including derived cells such as plan totals minus one cohort.",
        "Median Personal Return: DP-466 publishes it by Personal Return Method and Fee Basis; the model publishes one "
        "metric per method (the CW-011 rule on methodology) and always groups by fee basis. Confirm with SM-08 that a median "
        "over certified participant returns is an acceptable statistic of the certified Personal Rate of Return.",
        "The DP-467 hand-off fact is the DP-430 Participant Retail Hand-Off; the model reads it once, from DP-467, and "
        "computes DP-430's three hand-off measures over it. DP-467's logical model should mark the entity as conformed "
        "from DP-430/Participant Retail Hand-Off.",
        "Confirm the Dimension Key values of the direct-business channels and of Workplace - Recordkept Plan in DP-008, "
        "and that DP-008 locks quarterly rows (period_type = 'QUARTER'); otherwise the channel table reads month rows and "
        "the quarter is the sum of locked months for flows and the last month for Client Assets.",
        "Reviews reach plans only through the sponsor relationship (12 Client Review has no plan attribute); a sponsor "
        "with several plans counts one review under each. Add a reviewed plan to 12 Client Review, or accept the rule.",
        "DP-430's five recordkeeping controls are excluded as row-level operations checks; confirm with the DP-430 owner "
        "that no cross-plan dashboard needs them through the semantic layer.",
    ],
)
